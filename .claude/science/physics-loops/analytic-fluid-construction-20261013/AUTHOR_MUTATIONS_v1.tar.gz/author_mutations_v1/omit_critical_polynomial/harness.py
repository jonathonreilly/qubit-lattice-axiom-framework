import runpy,json,sys
from pathlib import Path
p=Path(sys.argv[1]);scope={'__file__':str(Path(sys.argv[2])),'__name__':'mutant_subject'}
exec(compile(p.read_text(),str(p),'exec'),scope)
scope['mode_controls']()
v=scope['CHECKS'];out={'passed':sum(x['passed']for x in v),'failed':sum(not x['passed']for x in v),'checks':v}
Path(sys.argv[3]).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'failed':out['failed']}))
sys.exit(0 if not out['failed'] else 1)
