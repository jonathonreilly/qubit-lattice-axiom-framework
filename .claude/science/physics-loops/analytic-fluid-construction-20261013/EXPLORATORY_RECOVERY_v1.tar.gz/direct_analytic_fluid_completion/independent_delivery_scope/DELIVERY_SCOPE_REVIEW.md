# Delivery scope of the analytic three-field construction

This is focused independent source-readiness advice, dated 2026-10-13. It is
not a formal audit, a final review-loop verdict, an N1-N8 packet, or permission
to treat the result as retained. The parent remains the scientific author.

## Finding

**There is a genuinely constructive conditional theorem here that can form an
independently reviewable unit. The unchanged mixed packet is not yet a
publication-ready instance of that unit.** Its positive content is the explicit
analytic positive-metric action, the exact supplied-fluid trajectory, and
global future convergence of its finite-energy homogeneous solutions. These
statements have a complete argument within their declared model and substantive
independent checks. They do not require the older combined packet to acquire a
publication PASS first merely because both are cosmology work.

That scientific separability does not waive input closure, canonical packaging,
negative-claim discipline, or final independent source confirmation. In
particular, the present v2 text also asserts a history-selection limitation
derived from the free modes. It is not enough to call the unchanged collection
a positive theorem and declare N1-N8 inapplicable. The exact claim inventory of
the proposed final source must determine its gates.

## Source and instruction identity

The selected main revision was
`516cb69d8487ff04f8a48e065d3dcbe71d7dd237`. Available local `origin/main`
matched it when the input pin was made; there was no difference to reconcile.
No fetch was performed. The worktree HEAD was
`947dacb58e82eeb9359b066787d89f380ee56cf0`. Main's `AGENTS.md` is a pointer,
so the available standing instructions were also read from
`origin/ai/execution` at `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`.
That planning source is identified separately rather than represented as part
of the main commit. Remote freshness beyond the available refs was not checked.

[INPUT_PIN.json](INPUT_PIN.json) binds 135 pre-existing source/evidence files
and the selected instruction snapshots. It is an inventory, not a claim that
every evidence byte was independently rederived. The complete v2 handwritten
argument, parent runner, fixtures, calibration/protocol/correction records,
parent scope note, and both full independent reports and derivations were read.
The large parent result was parsed in full for record counts, failures, family
coverage, source identities and final-energy range; this was not a new
integration or independent repetition of all its arithmetic.

The later parent [CHECKED_OUTCOME_v1.md](../CHECKED_OUTCOME_v1.md) was read and
pinned separately in [ADDITIONAL_INPUTS_v1.json](ADDITIONAL_INPUTS_v1.json).
It correctly supplies the current review disposition. The earlier
`RESULTS_AND_SCOPE_v1.md` statement that numerical review was pending is a
historical statement at its first-execution checkpoint, not a current failure.
Preserve that frozen record; use the checked outcome when writing current prose.

Principal scientific identities are:

| Source | SHA-256 |
| --- | --- |
| `HAND_DERIVATION_v2.md` | `322a932eef3ede5de4d963aae2c623693d12a5942828f971335cc7a6c03ef7d2` |
| `check_analytic_fluid_v1.py` | `d247f6dc0143d2548a46c59abaec09cb2521c03fe3de73691a5f1f85293c41ef` |
| `evidence_v1/RESULTS.json` | `82e04b99fcc878d267a7c82ec92d9aeb238015cc65f98947ecd60fb6cf274160` |
| Mathematical review receipt | `f200ebecc01fb9daba787eb748adef1a38261e88adc4e3e0bc5b13e08677b39f` |
| Numerical review receipt | `7a5eeb9ea7359b429098a65fe48eacee69cd3652595012e35146e9105a2a0975` |

The review receipt artifact/source references were checked against current
bytes: all 42 mathematical and 144 numerical reference checks matched. Those
are reference checks, not unique-file or independent-experiment counts. See
[REVIEW_IDENTITY_CHECK.json](REVIEW_IDENTITY_CHECK.json).

## The positive theorem and its actual dependency boundary

A defensible target statement is:

> For each fixed `a, nu, H_v > 0`, the specified three-field Einstein model
> with universal conformal dust coupling and nonnegative ideal dust/radiation
> densities has a real-analytic positive field metric, admits the displayed
> exact fluid reconstruction, and every finite-energy flat homogeneous
> Einstein-expanding initial state has a global future proper-time solution
> converging to its unique vacuum, with `H -> H_v`, `A -> 1` and `H_J -> H_v`.

This implication has its own closed proof structure:

1. `D >= 1` and `a > 0` give analyticity and positivity at every finite field
   point. A uniform lower metric eigenvalue over all unbounded field space is
   not asserted or needed.
2. The gradient-velocity identity and covariant Hessian establish both `x,y`
   scalar equations individually. The `u` potential derivative cancels its
   dust source; Friedmann, Raychaudhuri and fluid conservation also hold.
3. Off the exact trajectory, the two matter-exchange terms cancel in
   `E_dot = -3 H (T + sigma + 4r/3)`. This is a statement about the full
   specified homogeneous equations, not just a manufactured exact orbit.
4. The coercive potential bounds fields on each finite-energy sublevel;
   positivity of the metric on that compact field set bounds velocities.
   Nonnegative densities and the sublevel are invariant, and smooth
   continuation gives global future existence before LaSalle is used.
5. The unique invariant zero-dissipation state is the vacuum. Bounded `u`
   bounds the conformal factor away from zero, giving future physical
   proper-time completeness and the stated limiting physical Hubble rate.

The action, curved field metric, third scalar, positive restoring parameter,
Einstein gravity, universal coupling, flat homogeneity and ideal fluids are
declared model assumptions. They are not derived framework premises. The
user's explicit authorization to explore new theory permits studying this
model; it does not adopt it into the premise registry or ratify its physical
identification. The registered framework primitives remain separate, with no
registry update proposed here.

The exact reconstruction permits arbitrary real `x0,y0`, with zero amplitudes
giving the invariant fluid boundaries. The observed-photon benchmark is one
exposed numerical specialization. `H0`, `m`, `Omega_gamma`, `H_v` and the
initial amplitudes are supplied/calibrated in the stated roles. The imported
`G_N=(1+a)G_*` normalization is not established as a viable local measurement
bridge for the new action. The theorem itself does not depend on the numerical
photon temperature or on a FIRAS likelihood.

Consequently an independent theorem unit may state arbitrary supplied
amplitudes and retain the benchmark as an explicitly exposed illustration.
It must not silently change calibrated data into a prediction. If the
published unit asserts the calibration's physical derivation, its actual
upstream source and inputs join the unit's reviewed dependency closure.

The strict parameter inequalities, zero-density boundaries, and frame
distinction must survive packaging. No zero-parameter limiting theorem is
inherited. Einstein expansion is the hypothesis: transient physical-frame
contraction is permitted. The result concerns homogeneous proper time, not
general geodesic completeness, inhomogeneous spacetime stability or quantum
vacuum selection. Finite-history selection, abundances, neutrino content,
primordial perturbations, entropy and the small supplied vacuum scale remain
outside the positive theorem's established conclusions.

## What the independent checks support

The mathematical report checks the full argument, including compactness and
continuation rather than only the dissipation identity. It preserves the
original critical-`nu=9/4` mode omission and the physical-frame expansion
qualification, and confirms their v2 correction. The exact symbolic review
retains its actual failed executions: the frozen-v1 mode defect remains a
failed source assertion, and a separate radical-simplification failure was
resolved by justified factorization. An independent rational momentum route
reports 402 successful assertions across 80 fixtures; 18 affected-v2 checks
confirm the corrections. Those controls supplement the written proof.

The numerical report separately checks the implementation without importing
parent helpers as positive oracles. High-precision Hamiltonian differentiation,
an oscillator power series and canonical-momentum Radau evolution provide
different paths from the parent implementations. It records 15,068 successful
row/force/mode checks and 470 successful history checks. Its four deliberate
omissions produce 216 actual failed assertions, including a restoring-force
omission invisible on the exact `u=0` trajectory. These failures must remain
available with their original execution records.

The parsed parent evidence has 1,492 passing checks and zero failures, 72
off-trajectory fixtures, 25 free-mode rows, 12 tracking families with two
refinements each, and 48 disturbed histories. Final sampled energies range
from `1.5` to `1.5000343063189137`. The finite numerical histories support the
implementation; they neither replace the infinite-future proof nor establish
a new empirical test. [EVIDENCE_SUMMARY.json](EVIDENCE_SUMMARY.json) records the
limited mechanical checks performed in this advice pass.

## N-gate disposition: hypotheses, coverage, and a negative conclusion differ

Ordinary explicit hypotheses of a proved implication are not automatically a
claim that every route to the physical target fails. Similarly, identifying
inhomogeneous or quantum questions as outside a homogeneous classical proof
does not assert their impossibility. The pinned gate code expressly recognizes
honest proof-coverage disclaimers, with semantic vetoes where the sentence
actually asserts an authority boundary.

There is nevertheless a concrete issue to disposition in the supplied v2:
the paragraph starting at line 129 moves from the slow radiation mode and
critical dust mode to “A vacuum attractor does not select the observed
matter/radiation trajectory, their abundances or their primordial
perturbations.” The pinned detector identifies that paragraph; the numerical
review also carries a non-selection conclusion. See
[N_GATE_DIAGNOSTIC.json](N_GATE_DIAGNOSTIC.json). This diagnostic is not an
N1-N8 review, and detector silence elsewhere is not semantic approval.

Two honest delivery shapes are available in principle:

- **Carry the derived negative boundary as a result.** Retain its exact
  quantifiers and evidence and satisfy the applicable N1-N8 contract. The
  current schema requires five materially distinct mathematical route
  families. Proof styles, independent implementations, agents, solver choices,
  parameter fixtures and omission mutants are not five route families against
  that scientific claim. No qualifying five-family record for this new unit
  was established by this review, and no packet PASS is supplied.
- **Define a genuinely narrower constructive theorem unit.** Preserve the
  exact free-mode basis, the explicit frame witness, supplied-initial-data
  accounting and unproved history/inhomogeneous/quantum extensions. State the
  theorem's actual quantified conclusions and the proof's coverage. Do not
  carry a residual sentence that still asserts universal non-selection or
  foreclosure under another name. Any broader negative result remains
  explicitly deferred with its evidence and pending gate, rather than erased.
  The final independent reviewer must assess this substantive scope, across
  note, runner, report and metadata. This report does not preapprove a future
  rewrite or direct a word substitution to bypass the detector.

The second option follows the conformance specification's explicit distinction
between a positive existence witness and a retained no-go assertion. It is not
a license to retitle the unchanged mixed packet. If retaining the necessary
mode discussion in the final proposed source still amounts to a derived
negative boundary, the first option controls. Preserve the older combined
packet's stated pending five-family obligation independently; nothing here
clears, inherits or alters its publication standing.

There is also a procedural distinction inside the pinned validator:
`source_requires_no_go_discipline` always requires the heavy packet for
explicit no-go artifacts, and applies its wall/negative-boundary source
detector in forensic mode. The development-tier implementation leaves other
semantic judgments to the auditor; it does not waive the author/review skill's
pre-publication negative-claim contract. Choosing a tier or filename is not a
delivery workaround.

## Exact remaining delivery gates

The current files are research evidence. No final canonical source tree has
been submitted to this advice pass. The following work remains with the author
and final reviewer; “not run here” is not a failed mathematical theorem.

| Gate | Required application to this construction |
| --- | --- |
| Target, type, status and trace | Freeze the exact conditional theorem, domains, proof obligations, explicit inputs and nonclaims. A conservative repository classification is `target_claim_type: bounded_theorem` with `actual_current_surface_status: conditional-support`; constructive mathematical content does not require a `positive_theorem` label to be valuable. Keep type, support status, review and audit distinct. Use frontier-discovery/support trace unless an actual current blocker closure is established. No retained or empirical-success promotion follows. |
| Novelty/value | Check the statement and closest current-main/open-proposal results before claiming novelty, and record the searched revisions and scope comparisons. This advice did not perform that search. The V1-V5 promotion record applies if retained-positive movement is proposed; an explicit frontier question is legitimate without inventing an audit obstruction. |
| Self-contained canonical source | Put the actual theorem/proof, required runner, fixtures and all load-bearing inputs in the reviewed delta or rely on matching landed content. A clean clone plus the delta must reproduce. Absolute campaign paths and an unlanded sibling result cannot be required scientific inputs. Historical documents may remain recovery evidence, with explicit dispositions. |
| Frozen reader coverage | Preserve source/input hashes and the independent reports, original failed checks and v2 correction history. Reuse valid unchanged mathematical/numerical coverage at its stated scope. Any port, formula/input change or new interaction requires the affected final source to be independently confirmed; prior scientific checks are not a blanket publication verdict. |
| Runner contract | The present exploratory runner has no declared `AUDIT_TIMEOUT_SEC` or `AUDIT_INPUT_PATHS`, requires `--output-json`, and writes a raw JSON result. Adapt the canonical execution contract, declare actual input closure and timeout, and generate current SHA/input-bound cache evidence through `execute_and_write_cache`. Raw output is not that cache. Preserve expected nonzero historical/mutant runs honestly. |
| Independent math and mutation controls | Retain the distinct derivations and implementations already available. Map their exact coverage to the final runner. The four omission tests establish their named force/exchange controls, not every future check family; final author preflight must address any new or uncovered load-bearing family without claiming exhaustive certification. |
| Negative assertions | Apply the disposition above to the final claim inventory. If triggered, the honest N1-N8 checklist must land in the source note or linked sidecar, and the primary cached stdout must carry the five substantive N5 resolution lines. Unexercised resolutions must say so; do not fabricate scope, route families or retained prior authority. |
| Publication/input discovery | Before final execution, verify actual note discovery, claim identity, primary/helper binding and input reachability. Every load-bearing helper must be reachable through the primary runner or the reviewed helper mechanism. A local receipt's presence is not packet reachability. |
| Author conformance | Complete sections 1–12 of the pinned conformance specification with explicit reasons for genuine non-applicability. Write current scientific naming and scope, portable links, proof/import/computation/interpretation/review content, vocabulary checks and a cold complete diff read. Preserve historical records rather than rewriting past outcomes. |
| Final source review | Obtain the independent source verdict for the actual final unit and affected corrections in the appropriate reviewer session. Bind complete source/claim dispositions and current-main preservation; this advice and the earlier focused checks do not grant that final verdict. |
| Combined validation and topology | One exact integrated-candidate pass must run the pipeline, strict audit lint and changed-evidence readiness (`--include-worktree` for uncommitted bytes), followed by required diff checks. New `docs` nodes or dependency-edge changes require intended citation-manifest acknowledgment. Strip generated audit/status residue, preserving only allowed reviewed source/controlled changes. No full pipeline or landing validation was run here. |

The parent should first draft the bounded constructive claim and source/input
map, including an explicit disposition for the mode/frame witnesses and any
deferred negative assertion. That makes the exact canonical delta reviewable
before spending another full execution on packaging. A coherent regular
milestone PR is possible once its applicable author gates are satisfied;
landing additionally requires final independent source confirmation and the
combined gate. No formal audit is authorized or invoked by this assessment.

## Governing source distinctions and limits

The relevant pinned authorities are the science workflow; physics-loop
`SKILL.md`, `DELIVERY.md`, `DISCOVERY.md` and `CLAIM_STATUS.md`; review-loop
`SKILL.md`, `PREFLIGHT.md`, `REVIEW_UNITS.md`, `AUDIT_COMPATIBILITY.md` and
`COMBINED_VALIDATION.md`; and no-go-discipline `SKILL.md`. Their exact selected
bytes are preserved under `instruction_snapshot/` and bound by the input pin.
The no-go detector functions were inspected and used only for the local
diagnostic. Saved reference files not cited as read are recovery inputs, not
additional claimed review coverage.

Two apparent instruction tensions must not distort this result. First, the
general no-new-axiom language cannot revoke the user's explicit permission to
test new assumptions in this campaign; it still prevents silent framework
adoption. Second, the conformance restatement's phrase that fewer than five
routes makes the no-go “premature” is qualified by the owning current no-go
skill: it is a packet limitation, not a disproof of a scoped theorem. The
specification itself says its cited owners control disagreements. Neither
tension authorizes weakening an applicable publication gate.

No science runner was executed, no parent source was edited, and no worktree,
Git mutation, PR, scheduler action, audit or external publication was created.
Only this `independent_delivery_scope/` directory was written. The report
supports a packaging decision under pinned local evidence, not a new empirical,
formal-proof, novelty, publication-readiness or audit certification.
