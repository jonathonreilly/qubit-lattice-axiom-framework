#!/usr/bin/env python3
"""Focused source-port/recovery controls. No full science rerun or Git writes."""
from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
from fractions import Fraction
import ast,contextlib,difflib,hashlib,io,json,math,shutil,subprocess,sys,tarfile,time,traceback
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
AP=OUT.parent
ROOT=AP.parents[3]
CHECKS=[]
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blobsha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,value):
    with p.open('x')as f:json.dump(value,f,indent=2);f.write('\n')
def check(name,condition,detail=None):CHECKS.append(dict(name=name,passed=bool(condition),detail=detail))
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def snapshot(path):
    rel=path.relative_to(ROOT);dest=OUT/'source_snapshot'/rel
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    return dict(path=str(path),relative_path=str(rel),sha256=sha(path),snapshot=str(dest),bytes=path.stat().st_size)
def read_archive(path,manifest):
    data={};members=[]
    with tarfile.open(path)as archive:
        for item in archive.getmembers():
            pp=PurePosixPath(item.name)
            if not item.isfile() or pp.is_absolute() or '..'in pp.parts:raise ValueError('Unexpected unsafe archive member '+item.name)
            raw=archive.extractfile(item).read();data[item.name]=raw
            members.append(dict(member=item.name,bytes=len(raw),sha256=blobsha(raw)))
    declared={r['member']:(r['bytes'],r['sha256'])for r in manifest}
    actual={r['member']:(r['bytes'],r['sha256'])for r in members}
    check(path.name+' all member names unique',len(data)==len(members)==len(declared))
    check(path.name+' exact complete member set and bytes',actual==declared)
    return data,members
def functions(src):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(src).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}

def synthetic_io(canonical):
    # Exercise only changed main I/O with inert scientific stubs. These returns
    # are conspicuously labelled synthetic and supply NO physics evidence.
    folder=OUT/'synthetic_io';folder.mkdir()
    results=[]
    def one(label,args):
        namespace={'__name__':'synthetic_io_only','__file__':str(canonical)}
        exec(compile(canonical.read_text(),str(canonical),'exec'),namespace)
        calls=[]
        def stub(name,value):
            def run():calls.append(name);return value
            return run
        for fn in ['symbolic_controls','frame_witness_controls']:
            namespace[fn]=stub(fn,{'SYNTHETIC_IO_ONLY':True})
        for fn in ['off_trajectory_controls','mode_controls','tracking_histories','disturbed_histories']:
            namespace[fn]=stub(fn,[])
        argv=sys.argv;stdout=io.StringIO();stderr=io.StringIO();exception=None;code=None
        try:
            sys.argv=[str(canonical),*args]
            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=namespace['main']()
        except Exception as exc:exception=type(exc).__name__+': '+str(exc)
        finally:sys.argv=argv
        record=dict(label=label,scope='Synthetic I/O only; all scientific computations replaced by labelled inert stubs.',
                    args=args,returncode=code,exception=exception,stub_calls=calls,stdout=stdout.getvalue(),stderr=stderr.getvalue())
        results.append(record);return record
    for label in ['default_first','default_repeat_fresh_module']:
        r=one(label,[]);check(label+' succeeds without sidecar',r['returncode']==0 and r['exception']is None and len(r['stub_calls'])==6)
    unique=folder/'synthetic_result.json'
    r=one('unique_explicit_sidecar',['--output-json',str(unique)])
    check('unique sidecar preserves labelled synthetic payload',r['returncode']==0 and load(unique)['symbolic']=={'SYNTHETIC_IO_ONLY':True})
    digest=sha(unique)
    r=one('existing_sidecar_collision',['--output-json',str(unique)])
    check('sidecar collision preserved before any science work',r['exception'].startswith('FileExistsError:') and r['stub_calls']==[] and sha(unique)==digest)
    dump(folder/'CONTROLS.json',dict(scope='I/O controls only, not a scientific execution or empirical test.',cases=results))
    return dict(cases=4,scope='Synthetic I/O only',controls_sha256=sha(folder/'CONTROLS.json'))

def main():
    unit=load(AP/'SOURCE_UNIT_v1.json')
    paths=[ROOT/r['path']for r in unit['paths']]
    extras=[AP/'SOURCE_UNIT_v1.json',AP/'PORT_v1.diff',AP/'CANONICAL_EXECUTION_v1.json',AP/'PARENT_PRIOR_ART_RECEIPT_v1.json',AP/'prior_art_review/PRIOR_ART_SOURCE_SCOPE_REVIEW.md']
    extras+=list((ROOT/'logs/runner-cache').glob('analytic_fluid_cosmology_2026_10_13*'))
    frozen=[snapshot(p)for p in paths+extras if p.is_file()]
    dump(OUT/'INPUT_FREEZE_v1.json',dict(created_at=now(),scope='16-member source unit plus explicit port/cache/context evidence',inputs=frozen))
    dump(OUT/'PRE_EXECUTION_PLAN_v1.json',dict(created_at=now(),scope='Source/recovery/port and changed I/O only; reuse valid archived independent science by exact identity.',
         checks=['All16 source paths match declared frozen tree and current bytes.','Both complete archives match every regular-file member and SHA.','Original eligible source/evidence inventory recovered.','All14 old function ASTs and fixture bytes identical.','All4 fresh actual author mutant payloads/executions checked without rerunning.','New frame witness checked by independent exact arithmetic; synthetic repeated default and sidecar-collision I/O only.'],
         full_positive_scientific_rerun=False,mechanical_gate='Parent/coordinator responsibility; record identities separately.'))
    refs={r:git('rev-parse',r).decode().strip()for r in ['HEAD','origin/main','origin/ai/execution']}
    check('pinned main and HEAD match source base',refs['HEAD']==refs['origin/main']==unit['base']=='516cb69d8487ff04f8a48e065d3dcbe71d7dd237')
    for row in unit['paths']:
        path=ROOT/row['path'];check('frozen source '+row['path'],sha(path)==row['sha256']and path.stat().st_size==row['bytes'])
        check('frozen tree source '+row['path'],blobsha(git('show',unit['tree']+':'+row['path']))==row['sha256'])
    recovery=load(AP/'RECOVERY_v1.json');archive=ROOT/recovery['archive']
    check('exploratory archive digest',sha(archive)==recovery['archive_sha256'])
    old,members=read_archive(archive,recovery['members'])
    check('174 exploratory regular members',len(members)==recovery['member_count']==174)
    original_base=Path(recovery['members'][0]['path']).parent
    eligible={str(p)for p in original_base.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.suffix.lower()not in {'.pdf','.png'}}
    declared={r['path']for r in recovery['members']}
    check('complete current eligible original inventory',eligible==declared,{'extra_original_paths':sorted(eligible-declared),'missing_original_paths':sorted(declared-eligible)})
    changed=[r['path']for r in recovery['members']if sha(r['path'])!=r['sha256']]
    check('all174 recovered members match original bytes',not changed,changed)
    original_name='direct_analytic_fluid_completion/check_analytic_fluid_v1.py'
    canonical=ROOT/'scripts/analytic_fluid_cosmology_2026_10_13.py'
    before=functions(old[original_name].decode());after=functions(canonical.read_text())
    port=load(AP/'PORT_FUNCTION_IDENTITY_v1.json')
    astrows={name:before[name]==after.get(name)for name in before if name!='main'}
    check('all14 original function ASTs identical',len(astrows)==14 and all(astrows.values())and astrows==port['unchanged_function_ast'])
    check('only new function is frame witness',set(after)-set(before)=={'frame_witness_controls'})
    check('fixture exact recovered original bytes',(ROOT/'outputs/analytic_fluid_cosmology_2026_10_13/fixtures.json').read_bytes()==old['direct_analytic_fluid_completion/NUMERICAL_FIXTURES_v1.json'])
    check('port source identity record exact',port['original_runner_sha256']==blobsha(old[original_name])and port['canonical_runner_sha256']==sha(canonical))
    observed=''.join(difflib.unified_diff(old[original_name].decode().splitlines(True),canonical.read_text().splitlines(True),fromfile='exploratory/check_analytic_fluid_v1.py',tofile='scripts/analytic_fluid_cosmology_2026_10_13.py'))
    (OUT/'REVIEWED_PORT.diff').write_text(observed)
    check('full port diff exact',observed==(AP/'PORT_v1.diff').read_text())
    instructions=[]
    prefix='direct_analytic_fluid_completion/independent_delivery_scope/instruction_snapshot/'
    for name,raw in old.items():
        if name.startswith(prefix):
            rel=name[len(prefix):];current=ROOT/rel
            if current.is_file():
                same=sha(current)==blobsha(raw);check('prior-read instruction still exact '+rel,same)
                instructions.append(dict(path=rel,sha256=sha(current),same_as_previous_read=same))
    ma=load(AP/'AUTHOR_MUTATIONS_v1.json');check('fresh author mutation archive digest',sha(ROOT/ma['archive'])==ma['sha256'])
    fresh,freshmembers=read_archive(ROOT/ma['archive'],ma['members'])
    mutation_summaries=[]
    for declared in ma['summary']['mutations']:
        name=declared['name'];base='author_mutations_v1/'+name+'/'
        source=fresh[base+'mutant.py'];harness=fresh[base+'harness.py'];result=json.loads(fresh[base+'RESULTS.json']);execution=json.loads(fresh[base+'EXECUTION.json'])
        check(name+' exact executed source and harness',blobsha(source)==declared['source_sha256']and blobsha(harness)==declared['harness_sha256'])
        check(name+' receipt execution matches',all(execution.get(k)==declared.get(k)for k in ['source_sha256','harness_sha256','fixture_sha256','exit_code','passed','failed']))
        failed=[r for r in result['checks']if not r['passed']]
        check(name+' actual nonzero assertion outcome',declared['exit_code']==1 and len(failed)==declared['failed']>0 and sum(r['passed']for r in result['checks'])==declared['passed'])
        check(name+' no stderr exception substitution',fresh[base+'stderr.txt']==b'')
        difference=''.join(difflib.unified_diff(canonical.read_text().splitlines(True),source.decode().splitlines(True),fromfile='canonical',tofile=name))
        (OUT/(name+'.diff')).write_text(difference)
        (OUT/(name+'_harness.py')).write_bytes(harness)
        mutation_summaries.append(dict(name=name,selected_families=declared['selected_families'],passed=declared['passed'],failed=declared['failed'],exit_code=declared['exit_code'],source_sha256=blobsha(source),harness_sha256=blobsha(harness),failed_check_names=[r['name']for r in failed],diff_sha256=sha(OUT/(name+'.diff'))))
    # Independent arithmetic from the stated action at the exact new witness.
    T=Fraction(9);V=Fraction(3,2);E=T/2+V;h2=2*E/3
    H=Fraction(math.isqrt(h2.numerator),math.isqrt(h2.denominator));HJ=H-3
    check('independent exact physical-frame witness',(T,V,E,h2,H,HJ)==(9,Fraction(3,2),6,4,2,-1))
    io_result=synthetic_io(canonical)
    current_run=load(AP/'CANONICAL_EXECUTION_v1.json')
    cache=Path(current_run['cache_path'])
    check('canonical actual result exits0 and1497/0',current_run['result']['exit_code']==0 and'TOTAL: PASS=1497 FAIL=0'in current_run['result']['stdout']and current_run['result']['stderr']=='')
    check('canonical result bound to exact source unit and runner',current_run['source_unit_sha256']==sha(AP/'SOURCE_UNIT_v1.json')and current_run['runner_sha256']==sha(canonical))
    check('canonical cache exact digest',sha(cache)==current_run['cache_sha256']=='5cf14bd0b8f22432f142778c183705823530ddc16cc8c132db3ca4ce75a4b7aa')
    final=[r for r in frozen if sha(r['path'])!=r['sha256']or sha(r['snapshot'])!=r['sha256']]
    check('all frozen input bytes unchanged after checks',not final,final)
    result=dict(created_at=now(),scope='Focused source/recovery controls; mathematical source reasoning in REPORT_v1.md; no full science rerun.',
                refs=refs,source_unit_sha256=sha(AP/'SOURCE_UNIT_v1.json'),source_unit_tree=unit['tree'],source_paths=unit['paths'],
                exploratory_members=members,author_mutation_members=freshmembers,unchanged_functions=astrows,instruction_reuse=instructions,
                mutation_results=mutation_summaries,synthetic_io=io_result,exact_frame_witness={k:str(v)for k,v in dict(T=T,V=V,E=E,H_squared=h2,H=H,H_J=HJ).items()},
                canonical_execution_sha256=sha(AP/'CANONICAL_EXECUTION_v1.json'),checks=CHECKS,passed=sum(r['passed']for r in CHECKS),failed=sum(not r['passed']for r in CHECKS),failed_checks=[r for r in CHECKS if not r['passed']],
                combined_mechanical_gate='Pending coordinator final base/tree identities; this script does not run or certify it.',formal_audit=False)
    dump(OUT/'SOURCE_CHECKS_v1.json',result)
    print(json.dumps({k:result[k]for k in ['passed','failed','failed_checks','source_unit_tree']},indent=2))
    return int(bool(result['failed']))

if __name__=='__main__':
    start=now();clock=time.perf_counter();code=2
    with(OUT/'stdout_v1.txt').open('x')as out,(OUT/'stderr_v1.txt').open('x')as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        try:code=main()
        except BaseException:traceback.print_exc()
    dump(OUT/'EXECUTION_v1.json',dict(started_at=start,ended_at=now(),wall_seconds=time.perf_counter()-clock,returncode=code,script_sha256=sha(__file__),
         outputs=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)for p in [OUT/'stdout_v1.txt',OUT/'stderr_v1.txt',OUT/'SOURCE_CHECKS_v1.json']if p.exists()]))
    print((OUT/'stdout_v1.txt').read_text());print((OUT/'stderr_v1.txt').read_text(),file=sys.stderr);sys.exit(code)
