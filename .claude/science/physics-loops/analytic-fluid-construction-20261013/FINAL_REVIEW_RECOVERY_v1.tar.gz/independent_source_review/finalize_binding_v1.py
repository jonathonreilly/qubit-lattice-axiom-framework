"""Reviewer-owned identity binding only. Does not execute science or mutate Git."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/jonBridger/.codex/worktrees/analytic-fluid-construction-20261013/New Axioms Lets Go')
AP = ROOT / '.claude/science/physics-loops/analytic-fluid-construction-20261013'
OUT = AP / 'independent_source_review'
BASE = '516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
COMMIT = 'eb22c212bd0feeff27525453cbe21fc925bb667f'
TREE = '815c161466910010e9da84b4adf899cafd6d2746'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def save(name, data):
    with (OUT / name).open('x') as f:
        json.dump(data, f, indent=2)
        f.write('\n')


unit = json.loads((AP / 'SOURCE_UNIT_v1.json').read_text())
freeze = json.loads((OUT / 'INPUT_FREEZE_v1.json').read_text())
prior_checks = json.loads((OUT / 'SOURCE_CHECKS_v1.json').read_text())
checks = []

def check(name, ok, detail=None):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})

refs = {n: git('rev-parse', n).decode().strip() for n in ['HEAD', 'HEAD^{tree}', 'HEAD^', 'origin/main']}
check('original parent-authored commit identity', refs['HEAD'] == COMMIT, refs['HEAD'])
check('same reviewed source tree after parent commit', refs['HEAD^{tree}'] == TREE, refs['HEAD^{tree}'])
check('original commit parent equals pinned base', refs['HEAD^'] == BASE, refs['HEAD^'])
check('available origin/main equals pinned base without fetch', refs['origin/main'] == BASE, refs['origin/main'])
delta = git('diff', '--name-only', '--no-renames', BASE, COMMIT).decode().splitlines()
check('original commit delta exactly all16 frozen paths', sorted(delta) == sorted(e['path'] for e in unit['paths']) and len(delta) == 16, delta)
source_bindings = []
for entry in unit['paths']:
    rel = entry['path']
    live = identity(ROOT / rel)
    committed = git('show', COMMIT + ':' + rel)
    staged = git('show', ':' + rel)
    check('source disk/index/commit sha: ' + rel, live['sha256'] == sha(committed) == sha(staged) == entry['sha256'])
    source_bindings.append({**entry, 'absolute_path': str(ROOT / rel), 'commit': COMMIT, 'snapshot': str(OUT / 'source_snapshot' / rel)})
for entry in freeze['inputs']:
    live = identity(entry['path'])
    snapshot = identity(entry['snapshot'])
    check('all frozen live/snapshot bytes unchanged: ' + entry['relative_path'], live['sha256'] == snapshot['sha256'] == entry['sha256'])
context = []
for entry in prior_checks['instruction_reuse']:
    bound = identity(ROOT / entry['path'])
    check('reused instruction current identity: ' + entry['path'], bound['sha256'] == entry['sha256'])
    context.append({**bound, 'relative_path': entry['path'], 'basis': 'Full prior read reused only after exact source identity check.'})
unit_instruction = 'docs/ai_methodology/skills/review-loop/references/UNIT_RECEIPT.md'
current_instruction = identity(ROOT / unit_instruction)
check('receipt instruction equals pinned-main source', current_instruction['sha256'] == sha(git('show', BASE + ':' + unit_instruction)))
context.append({**current_instruction, 'relative_path': unit_instruction, 'basis': 'Full direct read for preflight chronology and final binding obligations.'})

binding = {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'Read-only final identity verification; no scientific rerun or Git mutation.',
    'original_source_base': BASE, 'original_source_commit': COMMIT, 'original_source_tree': TREE,
    'refs': refs, 'source_bindings': source_bindings, 'frozen_inputs': freeze['inputs'],
    'context_bindings': context, 'checks': checks,
    'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks),
    'failed_checks': [c for c in checks if not c['passed']],
    'pending': ['Full current UNIT_RECEIPT helper with --cache', 'Final combined mechanical validation and affected binding for later changes'],
}
save('FINAL_BINDING_v1.json', binding)
if binding['failed']:
    raise SystemExit('Final binding has genuine identity failures; preserved before stopping.')

judgments = {
    'AUTHOR_MUTATIONS_v1.json': 'Retain as reviewed execution/provenance evidence for four actual affected-function source mutants; all four fail assertions. No exhaustive mutation or negative-family coverage inferred.',
    'AUTHOR_MUTATIONS_v1.tar.gz': 'Retain intact: all25 regular members checked by exact names, sizes and hashes, including mutated source, harnesses, complete results and execution evidence.',
    'CLAIM_STATUS_CERTIFICATE.md': 'Retain as scope/status metadata for an independent conditional constructive source unit. It grants no retained/audit status or final mechanical gate success.',
    'DISCOVERY_PREFLIGHT_v1.json': 'Retain as actual pre-execution discovery, declared-input and timeout evidence. It is not a full UNIT_RECEIPT invocation; the omitted earlier full helper is a recorded process timing deviation.',
    'EXPLORATORY_RECOVERY_v1.tar.gz': 'Retain intact: all174 eligible original regular files match original inventory and bytes. Reuse identical positive proof/numerical content; preserve original failures and defer broader negative history-selection delivery and its five-family obligation.',
    'GOAL.md': 'Retain as process scope: genuinely separate positive conditional model construction with explicit limitations, not a relabeled mixed positive/negative publication packet.',
    'HANDOFF.md': 'Retain as honest source handoff describing portable constructive scope, full recovery and deferred broader negative obligation; final gate status remains pending at this original identity.',
    'PORT_FUNCTION_IDENTITY_v1.json': 'Retain: all14 scientific function AST identities and byte-identical fixture independently verified; port changes reviewed in full with no material issue.',
    'RECOVERY_v1.json': 'Retain: complete original-member receipt verified against archive and original files. Deferred negative material remains recoverable and is not a hidden premise or publication PASS.',
    'REVIEW_HISTORY.md': 'Retain as historical chronology and review planning metadata. Subsequent canonical execution, reviewer binding and gate outcomes must be recorded separately, not projected into these earlier bytes.',
    'STATE.yaml': 'Retain as original process state for the conditional constructive milestone. This historical state does not certify subsequent mechanical delivery or audit status.',
    'TRACE_GATE.md': 'Retain as scope and trace metadata preserving limitations and the separate broader negative gate. It is not proof that the current full final gate has run.',
    'ANALYTIC_FLUID_COSMOLOGY_CONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md': 'Accept as bounded constructive source after complete equation/proof/premise review: analytic positive metric, full supplied-fluid reconstruction, and global future homogeneous convergence for the stated classical action/domain. Retain free modes, physical-frame contraction witness, explicit assumptions, and finite-history/inhomogeneous/quantum limitations. No empirical, framework-derivation, novelty, or publication-status claim.',
    'fixtures.json': 'Retain as exposed supplied benchmark data, byte-identical to the fully reviewed original. It supplies numerical controls and is not independent observational evidence or a derived abundance/vacuum scale.',
    'imports.json': 'Retain as explicit supplied-model and benchmark scope declaration; reviewed in full with no hidden load-bearing repository theorem or observation claim.',
    'analytic_fluid_cosmology_2026_10_13.py': 'Accept for the bounded controls: full runner and diff reviewed;14 scientific function ASTs unchanged; new frame witness independently checked; output handling and assertion integrity checked. Reuse source-bound original independent math/numerics and actual1497/0 canonical cache; no exhaustive scientific coverage inferred.',
}
rows = []
for entry in unit['paths']:
    rel = entry['path']
    rows.append({
        'original_path': rel, 'original_sha256': entry['sha256'],
        'disposition': judgments[Path(rel).name],
        'recovery': 'Exact original commit ' + COMMIT + ':' + rel + '; identical reviewer snapshot ' + str(OUT / 'source_snapshot' / rel),
        'final_path': rel, 'final_sha256': entry['sha256'],
    })
save('ORIGINAL_DISPOSITIONS_v1.json', {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/launch_check',
    'kind': 'Immutable reviewer-owned original16-path source dispositions; not a full review_receipt.py unit record.',
    'original_source_base': BASE, 'original_source_commit': COMMIT, 'original_source_tree': TREE,
    'report': identity(OUT / 'REPORT_v1.md'),
    'final_binding': identity(OUT / 'FINAL_BINDING_v1.json'),
    'original_dispositions': rows,
    'later_changes': 'Final paths/hashes here are the original unchanged source identities. Any later process or scientific change needs a separate affected confirmation/mapping; do not rewrite this record.'
})

# All previously written reviewer artifacts are immutable receipt inputs, including
# this script, original frozen snapshots, actual failed evidence, and synthetic labels.
evidence = [identity(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
receipt = {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'kind': 'Independent constructive source review receipt; no formal audit or delivery authorization.',
    'reviewer': '/root/launch_check', 'author': '/root',
    'source_disposition': 'PASS WITH BOUNDED CLAIMS for the exact frozen constructive source.',
    'new_material_scientific_findings': [],
    'process_observation': {
        'issue': 'Full cheap UNIT_RECEIPT helper was not run before canonical execution.',
        'instruction': current_instruction,
        'actual_earlier_evidence': identity(AP / 'DISCOVERY_PREFLIGHT_v1.json'),
        'judgment': 'Discovery checks do not establish a full earlier helper invocation. Preserve timing deviation. No demonstrated source/math/cache defect and no unchanged science rerun required solely to restamp chronology.',
        'required_next': 'Complete current source/report/dispositions/cache record and actual helper --cache, then combined final gates. Preserve and address any actual errors. A later pass cannot retroactively establish earlier compliance.'
    },
    'source_unit': identity(AP / 'SOURCE_UNIT_v1.json'),
    'original_source_base': BASE, 'original_source_commit': COMMIT, 'original_source_tree': TREE,
    'review_report': identity(OUT / 'REPORT_v1.md'),
    'original_dispositions': identity(OUT / 'ORIGINAL_DISPOSITIONS_v1.json'),
    'final_identity_verification': identity(OUT / 'FINAL_BINDING_v1.json'),
    'sources': source_bindings, 'frozen_inputs': freeze['inputs'], 'context_bindings': context,
    'review_execution': identity(OUT / 'EXECUTION_v1.json'),
    'focused_check_counts': {'pass': 93, 'fail': 0, 'exit_code': 0, 'meaning': 'Source/recovery/port/I-O controls and exact frame witness; not independent empirical tests.'},
    'canonical_execution': identity(AP / 'CANONICAL_EXECUTION_v1.json'),
    'canonical_cache': identity(ROOT / 'logs/runner-cache/analytic_fluid_cosmology_2026_10_13.txt'),
    'canonical_counts': {'pass': 1497, 'fail': 0, 'exit_code': 0, 'authorship': 'Actual parent execution; reviewed by identity, not rerun here.'},
    'original_science_reuse': 'Only exact14 function ASTs, identical fixtures, and source-bound complete original independent proof/numerical reports within their stated domain. All genuine original failures and corrections preserved.',
    'archive_member_identity_reference': {'evidence': identity(OUT / 'SOURCE_CHECKS_v1.json'), 'exploratory_json_pointer': '/exploratory_members', 'exploratory_member_count':174, 'mutation_json_pointer':'/author_mutation_members', 'mutation_member_count':25},
    'fresh_author_mutant_failed_counts': {'physical_clock_sign':1, 'omit_critical_polynomial':4, 'metric_connection_component':60, 'coercive_potential_square':392},
    'full_positive_science_rerun': False, 'independent_empirical_tests':0, 'scientific_source_edits':0,
    'git_mutations_by_reviewer':0, 'audit_calls':0, 'registry_or_status_changes':0,
    'pending_mechanical_gates': binding['pending'],
    'formal_audit_or_publication_pass': False,
    'reviewer_evidence': evidence,
}
save('RECEIPT_v1.json', receipt)
print(json.dumps({'final_identity_checks':{'passed':binding['passed'],'failed':binding['failed']}, 'source_paths':len(rows), 'frozen_inputs':len(freeze['inputs']), 'reviewer_evidence_files':len(evidence), 'report':identity(OUT/'REPORT_v1.md'), 'dispositions':identity(OUT/'ORIGINAL_DISPOSITIONS_v1.json'), 'receipt':identity(OUT/'RECEIPT_v1.json')},indent=2))
