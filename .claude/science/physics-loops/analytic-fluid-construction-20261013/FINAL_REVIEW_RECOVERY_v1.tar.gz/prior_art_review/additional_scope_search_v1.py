#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, os, subprocess

P=Path(__file__).resolve().parent
AW=P.parents[4]
BASE='516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
rows=[]
for key,pattern in [('attractors','de[ -]?Sitter|no.hair|Lyapunov|LaSalle|quintessence|quintom|cosmological.*attractor|homogeneous.*attractor|scaling.*attractor'),('field_metrics','field.space metric|K_AB|K_\\{AB\\}|sigma.model|conformal.*scalar'),('exact_fingerprint','4a/\\(9D\\)|4.a/\\(9.D\\)|nu.u\\^2/2|global homogeneous future|analytic fluid completion')]:
    command=['git','grep','--threads=1','-n','-i','-E',pattern,BASE,'--','docs','scripts',':(exclude)docs/audit',':(exclude)docs/work_history',':(exclude)docs/ai_methodology']
    r=subprocess.run(command,cwd=AW,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),capture_output=True,timeout=90)
    stem=P/'commands'/('main_additional_'+key)
    out=Path(str(stem)+'.stdout.txt');err=Path(str(stem)+'.stderr.txt')
    out.write_bytes(r.stdout);err.write_bytes(r.stderr)
    rows.append({'command':command,'exit_code':r.returncode,'stdout':str(out),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':str(err),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()})
    print(key,len(r.stdout.splitlines()),r.returncode,flush=True)
extra=['docs/COSMOLOGY_FRW_KINEMATIC_REDUCTION_THEOREM_NOTE_2026-04-24.md','docs/DARK_ENERGY_EOS_RETAINED_COROLLARY_THEOREM_NOTE.md','docs/FRW_C3_KINETIC_COMPONENT_PERFECT_FLUID_LIFT_BOUNDED_SUPPORT_NOTE_2026-06-18.md']
for name in extra:
    command=['git','show',BASE+':'+name]
    r=subprocess.run(command,cwd=AW,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),capture_output=True,timeout=90)
    assert r.returncode==0,(name,r.stderr)
    out=P/'source_snapshot'/'main'/Path(name).name
    out.write_bytes(r.stdout)
    rows.append({'command':command,'exit_code':r.returncode,'source_path':name,'commit':BASE,'snapshot':str(out),'sha256':hashlib.sha256(r.stdout).hexdigest(),'bytes':len(r.stdout)})
(P/'ADDITIONAL_SEARCH_v1.json').write_text(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':rows},indent=2)+'\n')
