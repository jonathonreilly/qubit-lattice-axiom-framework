#!/usr/bin/env python3
"""Read pinned Git blobs (or GitHub contents at a pinned SHA); write review only."""
from pathlib import Path
import base64, datetime, hashlib, json, os, re, subprocess

P = Path(__file__).resolve().parent
AW = P.parents[4]
BASE = '516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
REPO = 'repos/jonathonreilly/qubit-lattice-axiom-framework'
records = []

def capture(commit, source_path, group, local=True):
    target = P / 'source_snapshot' / group / source_path
    target.parent.mkdir(parents=True, exist_ok=True)
    if local:
        command = ['git', 'show', commit + ':' + source_path]
    else:
        command = ['gh', 'api', REPO + '/contents/' + source_path + '?ref=' + commit]
    before = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(command, cwd=AW, env=dict(os.environ, GIT_NO_LAZY_FETCH='1'), capture_output=True, timeout=90)
    if result.returncode:
        raise RuntimeError((command, result.returncode, result.stderr.decode()))
    data = result.stdout if local else base64.b64decode(json.loads(result.stdout)['content'])
    target.write_bytes(data)
    records.append({'commit': commit, 'source_path': source_path, 'snapshot': str(target), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'command': command, 'read_at': before, 'exit_code': result.returncode})
    print(group, source_path, len(data), flush=True)
    return data

prs = json.loads((P / 'OPEN_PR_SOURCE_SELECTION_v1.json').read_text())
for pr in prs:
    group = 'pr_' + str(pr['number'])
    local = pr['number'] != 9510
    for source_path in pr['candidate_canonical_notes']:
        capture(pr['headRefOid'], source_path, group, local)
    if pr['number'] in (9501, 9505, 9507, 9509):
        manifest = (P / 'commands' / (group + '_canonical_delta.stdout.txt')).read_text()
        for line in manifest.splitlines():
            source_path = line.split('\t')[-1]
            if source_path.startswith('scripts/') and source_path.endswith('.py') and 'frontier' not in source_path:
                capture(pr['headRefOid'], source_path, group, local)

main_sources = json.loads((P / 'MAIN_SELECTED_SOURCES_v1.json').read_text())
for row in main_sources:
    if any(fragment in row['source_path'] for fragment in ('SINGLE_RATIO', 'ADMISSIBILITY_RULE_THE_LATTICE_EXPANDS')):
        body = Path(row['snapshot']).read_text()
        paths = list(dict.fromkeys(re.findall(r'scripts/[A-Za-z0-9_./-]+\.py', body)))
        for source_path in paths:
            capture(BASE, source_path, 'main_runners')
(P / 'COMPARISON_SOURCES_v1.json').write_text(json.dumps(records, indent=2) + '\n')
