#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess
P=Path(__file__).resolve().parent
AW=P.parents[4]
BASE='516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
REPO='repos/jonathonreilly/qubit-lattice-axiom-framework'
LOG=[]
def run(name,cmd,limit=90):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=AW,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),capture_output=True,text=True,timeout=limit)
 out=P/'commands'/f'{name}.stdout.txt';err=P/'commands'/f'{name}.stderr.txt';out.write_text(r.stdout);err.write_text(r.stderr)
 LOG.append({'name':name,'command':cmd,'cwd':str(AW),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':str(out),'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr':str(err),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest()})
 return r
patterns=[('dynamics','LaSalle|homogeneous.*(converg|attract)|Einstein.*expan|dust.*radiation|radiation.*dust'),('reconstruction','tracking solution|scaling solution|field.space metric|multiscalar|multi.scalar|reconstruct.*cosmolog|cosmolog.*reconstruct'),('specific','analytic.fluid|global.*(de.Sitter|vacuum)|finite.energy.*homogeneous|homogeneous.*finite.energy|coercive.*potential|Jordan.frame'),('fluid_scopes','Friedmann|FLRW|FRW|scalar.tens|sigma.model')]
for key,pattern in patterns:
 r=run('main_'+key,['git','grep','--threads=1','-l','-i','-E',pattern,BASE,'--','docs','scripts',':(exclude)docs/audit',':(exclude)docs/work_history',':(exclude)docs/ai_methodology'])
 print(key,r.returncode,len(r.stdout.splitlines()),flush=True)
r=run('open_prs_with_bases',['gh','pr','list','--state','open','--limit','100','--json','number,title,url,headRefOid,baseRefOid,baseRefName,headRefName,updatedAt'])
prs=json.loads(r.stdout);(P/'OPEN_PRS_WITH_BASES_v1.json').write_text(json.dumps(prs,indent=2)+'\n')
for pr in prs:
 sha=pr['headRefOid'];number=pr['number']
 exists=run('pr_'+str(number)+'_local_head',['git','cat-file','-e',sha+'^{commit}'])
 if exists.returncode==0:
  diff=run('pr_'+str(number)+'_canonical_delta',['git','diff','--name-status',pr['baseRefOid']+'...'+sha,'--','docs','scripts'])
  paths=[line.split('\t')[-1]for line in diff.stdout.splitlines()if line and line[0]!='D']
 else:
  api=run('pr_'+str(number)+'_files',['gh','api','--paginate',REPO+'/pulls/'+str(number)+'/files?per_page=100'])
  pages=json.JSONDecoder();data=api.stdout;rows=[]
  while data.strip():
   rows1,index=pages.raw_decode(data.lstrip());rows+=rows1;data=data.lstrip()[index:]
  paths=[z['filename']for z in rows if z['filename'].startswith(('docs/','scripts/'))and z['status']!='removed']
 selected=[z for z in paths if z.startswith('docs/')and z.endswith('.md')and not z.startswith(('docs/audit/','docs/work_history/','docs/ai_methodology/'))]
 pr['candidate_canonical_notes']=selected
 print('pr',number,sha,'candidate_notes',selected,flush=True)
(P/'OPEN_PR_SOURCE_SELECTION_v1.json').write_text(json.dumps(prs,indent=2)+'\n')
(P/'SOURCE_SEARCH_COMMANDS_v1.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_sha':BASE,'commands':LOG},indent=2)+'\n')
