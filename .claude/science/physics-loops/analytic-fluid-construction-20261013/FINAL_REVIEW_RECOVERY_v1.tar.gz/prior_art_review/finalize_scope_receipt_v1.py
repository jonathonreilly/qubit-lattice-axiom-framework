#!/usr/bin/env python3
"""Freeze this read-only repository comparison's source and evidence receipt."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess

P=Path(__file__).resolve().parent
AW=P.parents[4]
BASE='516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,obj):
    (P/path).write_text(json.dumps(obj,indent=2)+'\n')
start=json.loads((P/'SEARCH_START_v1.json').read_text())
rows=json.loads((P/'MAIN_SELECTED_SOURCES_v1.json').read_text())
rows+=json.loads((P/'COMPARISON_SOURCES_v1.json').read_text())
rows+=[r for r in json.loads((P/'ADDITIONAL_SEARCH_v1.json').read_text())['records'] if 'snapshot' in r]
rows.append(json.loads((P/'ADDITIONAL_CANONICAL_GRAVITY_SOURCE_v1.json').read_text()))
rows+=json.loads((P/'NEW_PR9511_SOURCES_v1.json').read_text())['records']
candidate=start['candidate_source']
rows.append({'source_path':candidate['path'],'snapshot':candidate['snapshot'],'sha256':sha(candidate['snapshot']),'commit':None,'role':'candidate comparison source'})
partial_main={
    'SIGNED_GRAVITY_APS_LOCKED_SOURCE_ACTION_PROPOSAL_NOTE.md':150,
    'D3Q27_NONLINEAR_FLUID_LIMIT_BOUNDED_THEOREM_NOTE_2026-10-11.md':145,
    'DARK_ENERGY_EOS_RETAINED_COROLLARY_THEOREM_NOTE.md':160,
    'NONLINEAR_CANONICAL_GRAVITY_ANALYTIC_APPROXIMATION_BOUNDED_THEOREM_NOTE_2026-09-30.md':150,
}
complete_pr=(9501,9505,9507,9509)
dispositions=[]
for r in rows:
    path=Path(r['snapshot']); actual=sha(path)
    assert actual==r['sha256'],r
    lines=len(path.read_text().splitlines());name=Path(r['source_path']).name
    if name=='frontier_cosmology_single_ratio_inverse_reconstruction.py':
        mode='complete source read for scope; not executed';ranges=[[1,lines]]
    elif name.startswith('admissibility_rule_the_lattice_expands'):
        mode='action and primary algebra controls read; not executed';ranges=[[1,160]]
    elif name=='metric_clock_reconstruction_2026_10_13.py':
        mode='operator and constant-K example code read, plus function/keyword outline; not executed';ranges=[[1,115]]
    elif name.endswith('.py'):
        mode='captured only; no new complete runner read or execution claimed';ranges=[]
    elif '/pr_9511/' in str(path):
        mode='source scope/model screen and full-file targeted keyword scan; not full proof review';ranges=[[1,140]]
    elif '/pr_' in str(path) and not any('/pr_'+str(k)+'/' in str(path) for k in complete_pr):
        mode='source scope/model screen and full-file targeted keyword scan; not full proof review';ranges=[[1,min(120,lines)]]
    elif name in partial_main:
        mode='source premises, statement and initial law read; not complete proof review';ranges=[[1,partial_main[name]]]
    else:
        mode='complete note read for comparison scope; no new mathematical proof certification';ranges=[[1,lines]]
    dispositions.append({'original_path':r['source_path'],'origin_commit':r.get('commit'),'original_sha256':actual,'disposition':'unchanged comparison source; byte-exact review snapshot preserved','recovery':str(path.relative_to(P)),'final_path':r['source_path'],'final_sha256':actual,'bytes':path.stat().st_size,'total_lines':lines,'coverage':mode,'read_ranges':ranges,'capture_command':r.get('command'),'role':r.get('role','repository comparison')})
assert len(dispositions)==44
assert sha(candidate['path'])==sha(candidate['snapshot'])=='322a932eef3ede5de4d963aae2c623693d12a5942828f971335cc7a6c03ef7d2'
dump('SOURCE_DISPOSITIONS_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_commit':BASE,'source_count':len(dispositions),'sources':dispositions})
dump('READ_ATTEMPTS_v1.json',{'failures':[{'command_kind':'cat','path':'commands/main_fluid_scopes.stdout','exit_code':1,'error':'No such file or directory','cause':'Display command omitted the .txt suffix.','resolution':'Read commands/main_fluid_scopes.stdout.txt completely.'},{'command_kind':'cat','path':'commands/main_additional_attractors.stdout.txt','exit_code':1,'error':'No such file or directory','cause':'Collector was still running and had not written this output.','resolution':'Collector completed successfully; output preserved and relevant source hits read.'},{'command_kind':'cat','path':'commands/main_additional_field_metrics.stdout.txt','exit_code':1,'error':'No such file or directory','cause':'Collector was still running and had not written this output.','resolution':'Collector completed successfully; output preserved and relevant source hits read.'}],'scientific_failures':'No scientific execution occurred in this source-scope task.','normal_no_match_exit':'Exact-fingerprint git grep exit1 is an ordinary no-match result, not a failed scientific test.'})
cmd=['gh','pr','list','--state','open','--limit','100','--json','number,title,url,headRefOid,baseRefOid,baseRefName,headRefName,updatedAt']
r=subprocess.run(cmd,cwd=AW,capture_output=True,timeout=90)
(P/'commands/confirmed_open_prs.stdout.txt').write_bytes(r.stdout)
(P/'commands/confirmed_open_prs.stderr.txt').write_bytes(r.stderr)
assert r.returncode==0,r.stderr
current=json.loads(r.stdout);earlier=json.loads((P/'commands/final_open_prs.stdout.txt').read_text())
c={x['number']:x['headRefOid'] for x in current};e={x['number']:x['headRefOid'] for x in earlier}
assert c==e,('open heads changed',c,e)
initial=json.loads((P/'OPEN_PRS_WITH_BASES_v1.json').read_text())
old={x['number']:x['headRefOid'] for x in initial}
assert all(c.get(n)==v for n,v in old.items())
dump('FINAL_REMOTE_IDENTITY_v2.json',{'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_identity_receipt':'FINAL_REMOTE_IDENTITY_v1.json','main_commit':BASE,'initial_twelve_heads_unchanged':True,'new_PR9511_head':'bd831ffb14c7d7f12bf1b8165596a0db85f838ef','all_thirteen_pinned_heads_match_final_query':True,'heads':c,'command':cmd,'stdout':'commands/confirmed_open_prs.stdout.txt','stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'exit_code':r.returncode})
source_counts={'candidate':1,'main_notes':15,'main_runners':2,'open_pr_notes':22,'open_pr_runners':4}
dump('SOURCE_COMPARISON_RESULT_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'source/premise comparison only; not a proof audit or literature novelty result','main_commit':BASE,'sources':source_counts,'total_sources':44,'exact_snapshot_hashes_match':True,'candidate_current_hash_matches_snapshot':True,'matching_AN_construction_found':False,'matching_claim_absence_proved':False,'scientific_runners_executed':0,'overlap_findings':['Standard dust/radiation/vacuum curve, inverse identities and de Sitter asymptotic are already explicit on main.','Known positive constant-K Einstein/multiscalar universal-metric action is already explicit in open PR9509.','The searched sources do not supply the particular nonlinear curved K,V,A construction plus all finite-energy homogeneous Einstein-expanding future convergence statement.'],'scope_limits':['No external-literature, closed-PR or complete-history search.','Distant notes received a source-level screen, not complete proof validation.','No physical-history, observational, nonlinear inhomogeneous-stability or priority claim follows.']})
artifacts=[]
for path in sorted(P.rglob('*')):
    if path.is_file() and path.name!='FINAL_RECEIPT_v1.json':
        artifacts.append({'path':str(path.relative_to(P)),'bytes':path.stat().st_size,'sha256':sha(path)})
dump('FINAL_RECEIPT_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_directory':str(P),'task':'Focused current-main/open-PR prior-art and source-scope check','main_commit':BASE,'candidate_sha256':sha(candidate['snapshot']),'source_count':44,'open_pr_count':13,'canonical_pr_note_count':22,'report':'PRIOR_ART_SOURCE_SCOPE_REVIEW.md','source_dispositions':'SOURCE_DISPOSITIONS_v1.json','artifacts':artifacts,'artifact_count':len(artifacts),'scientific_execution_count':0,'write_boundary':'This review directory only. No Git or PR mutation; earlier reviews unchanged.'})
print(json.dumps({'receipt_sha256':sha(P/'FINAL_RECEIPT_v1.json'),'report_sha256':sha(P/'PRIOR_ART_SOURCE_SCOPE_REVIEW.md'),'artifact_count':len(artifacts),'source_count':44,'open_pr_count':13},indent=2))
