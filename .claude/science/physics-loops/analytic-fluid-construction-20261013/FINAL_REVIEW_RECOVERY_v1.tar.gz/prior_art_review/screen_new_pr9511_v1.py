#!/usr/bin/env python3
from pathlib import Path
import base64,datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent
AW=P.parents[4]
HEAD='bd831ffb14c7d7f12bf1b8165596a0db85f838ef'
REPO='repos/jonathonreilly/qubit-lattice-axiom-framework'
command=['gh','api','--paginate',REPO+'/pulls/9511/files?per_page=100']
r=subprocess.run(command,cwd=AW,capture_output=True,timeout=90)
(P/'commands/pr9511_files.stdout.txt').write_bytes(r.stdout)
(P/'commands/pr9511_files.stderr.txt').write_bytes(r.stderr)
assert r.returncode==0,r.stderr
data=r.stdout.decode();decoder=json.JSONDecoder();rows=[]
while data.strip():
    page,index=decoder.raw_decode(data.lstrip());rows.extend(page);data=data.lstrip()[index:]
paths=[x['filename'] for x in rows if x['filename'].startswith('docs/') and x['filename'].endswith('.md') and not x['filename'].startswith(('docs/audit/','docs/work_history/')) and x['status']!='removed']
records=[]
for name in paths:
    cmd=['gh','api',REPO+'/contents/'+name+'?ref='+HEAD]
    q=subprocess.run(cmd,cwd=AW,capture_output=True,timeout=90)
    assert q.returncode==0,q.stderr
    source=base64.b64decode(json.loads(q.stdout)['content'])
    out=P/'source_snapshot/pr_9511'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source)
    records.append({'commit':HEAD,'source_path':name,'snapshot':str(out),'sha256':hashlib.sha256(source).hexdigest(),'bytes':len(source),'command':cmd})
    print(name,len(source),flush=True)
(P/'NEW_PR9511_SOURCES_v1.json').write_text(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files_command':command,'file_list_sha256':hashlib.sha256(r.stdout).hexdigest(),'records':records},indent=2)+'\n')
