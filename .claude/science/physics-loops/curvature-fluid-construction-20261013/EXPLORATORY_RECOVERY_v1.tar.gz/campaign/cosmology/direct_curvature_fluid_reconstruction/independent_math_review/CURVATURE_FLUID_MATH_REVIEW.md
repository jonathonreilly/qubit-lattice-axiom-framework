# Focused curvature-fluid handwritten review

The frozen handwritten action and equations are consistent within their stated classical and conditional local-readout premises. I found no source correction in this scope. The independent calculation recorded **103 passing checks and zero failed assertions**. This is a focused mathematical review, not a formal audit, retained claim promotion, implementation review or empirical validation.

## Exact scope and recovery

The complete current subject is `HAND_DERIVATION_v1.md`, SHA-256 `2ee1ebdbb34462010b8c9e34fa90466f173948a1ab5fbb940231b20c701db04f`, frozen before calculation in `INPUT_FREEZE_v1.json` and copied byte-for-byte under `source_snapshot/`. The four exact AN, induced-curvature, weak-field-inverse and AUX handwritten premises listed in `PARENT_PREMISE_PINS_v1.json` were pinned and copied as well. Prior same-session checks of those exact sources are reused only for their stated premises; the new completion is independently derived here. `SOURCE_DISPOSITIONS_v1.json` provides all five original paths, hashes, dispositions and recovery paths.

The parent's subsequent implementation and reported first execution are outside this assignment. No parent code was imported or executed, no implementation pass count is adopted, and no parent source was changed. No new empirical data or primary-source claim is introduced. The thermal constants are independently checked as ideal-statistics assumptions supplied by the handwritten note.

## Findings and required scope

1. **The added operators do repair the ideal orbit at the action level.** Direct variation gives the nonminimal Ricci u source, the added V1 force and the matter trace with the stated signs. Both metric equations and all three scalar equations vanish on the supplied orbit. The x/y proof includes the field-metric connection, separately from the Friedmann constraint. The coefficient D_b is a field function in the action, not an inserted time-dependent Hubble rate.

2. **b remains an independent action constant during q variation.** The new zeta terms have no explicit q derivative. The original form constraint uses L0 only. Selecting b=k afterward is a sector calibration; substituting k(q,zeta) into the original action changes its q equation. The independent off-orbit countercheck produces an extra -8/225 term for a fixed rational fixture. Holding s=zeta/q fixed during original q variation is similarly invalid. The note states the correct distinction.

3. **Positivity and masses have the stated local scope.** The full Einstein-frame scalar metric is positive on a,b in (0,1/3), s>=0 and finite fields. Completing the x^2-coefficient square establishes its strict all-u lower bound. Differentiating the fixed-sector potential before evaluation reproduces all three physical vacuum masses and zero mixed entries. Positive local masses and an all-u coefficient bound do not recover the earlier global-attraction theorem: the transformed potential has a finite-distance endpoint for s>0. The note explicitly declines that inheritance.

4. **The measured-G_N elimination is conditional.** The vacuum bridge yields k=a/[1+(1-3a)s] and G_N=(1+k)/[8pi(q+zeta)]. Its use during a fluid epoch assumes a local frozen-background, sufficiently high-momentum light-scalar regime with relevant background and mixing effects controlled. The homogeneous equations do not prove an apparatus response or a viable perturbation theory throughout history. Subject to that bridge, S^2=(1+b)/(1+k) follows exactly. S compares the fluid contribution at fixed physical densities and G_N; the total expansion ratio retains the vacuum term.

5. **The two parameter branches have different roles.** On the earlier null weak-field family, the restriction b=a gives S^2=(5-3k)/4. The enlarged action permits b=k to reproduce the supplied reference fluid coefficient. That equality is a calibration, not a prediction or evidence for an actual thermal fit. The 24 independent rational inverse targets retain six admissible and eighteen excluded cases, including all eight exact b=0 or b=1/3 boundary rows.

6. **Flux and thermal limits are retained correctly.** The finite form-flux ratio is a volume average strictly above 3H_v^2 when positive fluids contribute on a set of positive measure; its regulated future limit does not specify two finite absolute fluxes or enforce an entire finite history. The pre/post ideal thermal translations differ and are not a BBN/CMB likelihood or a common extra free-streaming-neutrino component. Actual annihilation has a nonzero trace and changing entropy laws, so extending the ideal orbit through it is not established.

These are limits of the established result, not objections to introducing the explicitly supplied new operators. The source appropriately identifies the new off-orbit coefficient 2a/b, the independent b, the new zeta completion and the local bridge as premises. It makes no uniqueness, quantum-coefficient, naturalness, global-stability or thermal-fit claim.

One reduction phrase needs its contextual interpretation: b=a and zeta=0 reproduce the AN field functions K,V,A, while the unreduced auxiliary/form sector remains. The old AN local equations also require C=0, which is already imposed on the selected orbit by C=3sH_v^2/2 at s=0. This does not invalidate the displayed solution or require a changed calculation; equality to bare AN should not be extended to the entire unreduced action.

## Independent methods and evidence

`INDEPENDENT_DERIVATION.md` gives the full original-action variation, conformal kinetic normalization, complete scalar and metric equations, fixed-sector Hessian, density normalization, inverse domain and ideal-statistics derivation. `independent_action_check_v1.py` implements distinct original-frame Euler-Lagrange covectors, direct proper-time differentiation, exact rational target arithmetic and Fermi/Bose quadrature. It imports SymPy and mpmath, not parent functions.

The preserved first execution used Python 3.12.8, SymPy 1.14.0 and mpmath 1.3.0 at 80 decimal digits. `INDEPENDENT_RESULTS_v1.json` contains every assertion and every result row. Its script hash is `a1afb10a496b075031de09041a084f49ddb3f3d1aa64af44e59c17c7fcd87616`. The tool returned exit 0; stderr is empty. The result and stdout agree exactly for every repeated row class.

| Independent evidence | Coverage and result |
| --- | --- |
| Exact action identities | Original q/Lambda variations, vacuum shift, Weyl factors, metric equations, three scalar equations, conservation, orbit L0, square bound, vacuum gradient/Hessian and local normalization |
| Proper-time residuals | Five dust/radiation/mixed/small-b/vacuum fixtures; 25 x/y/u/metric residuals; maximum normalized magnitude 4.686725e-80 |
| Omission controls | Five exact action/calibration mutations and one connection omission; every intended error is exposed |
| Inverse targets | All 24 exact rational rows consumed; 6 admitted, 18 excluded; strict boundaries retained |
| Thermal rows | Six branch/parameter rows plus independent Fermi/Bose energy ratio and entropy count; all checked |

The controls have substantive sensitivity. At a=1/4, b=1/5, s=q=H_v=1, x=1, y=2, omitting the induced Ricci u source gives -36/5, omitting the new V1 u source gives 1/5, and omitting the matter trace gives 2. Omitting the zeta transverse completion gives a Friedmann residual 2. Omitting the scalar connection gives x/y residuals 11.4 and 30.4 on the same mixed fixture. None is repaired by retuning the orbit or its matter inputs.

For example, at k=10^-5 on b=a, the independent thermal translation is S=1.1180306346428974, Delta N_pre=1.5356682142857143, and Delta N_post=1.850745641579648. On b=k all three tested k values give S=1 and zero increments by construction. These numbers remain ideal conditional diagnostics.

## Failures, interruption and final disposition

No mathematical assertion failed in this bounded task. A stream disconnect interrupted reporting after successful evidence had been written; the parent identified request `33864de9-6f77-4fa4-82e7-6190cbb37381`. `STREAM_DISCONNECT_v1.json` preserves that transport failure. The successful calculation was not rerun or overwritten after resumption. The negative controls and excluded inverse rows remain in the original result.

All five original source identities and exact recovery copies are unchanged at the final check. The report, derivation, execution record, source dispositions and full evidence hashes are bound by `FINAL_RECEIPT_v1.json`. No conclusion here relies on the parent's later numerical execution or extends the note to empirical thermal history, finite-history selection, full perturbations, or global convergence.
