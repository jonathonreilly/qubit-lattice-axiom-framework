# Independent action and ideal-fluid derivation

This derivation checks the exact handwritten source frozen in `INPUT_FREEZE_v1.json`. It is a focused mathematical check of supplied classical operators. It does not review the parent's numerical implementation or establish an empirical cosmological model. The independent calculation is `independent_action_check_v1.py`; it imports no parent helpers.

## Original variables and variation

Use signature (-+++), dimensionless fields (u,x,y), alpha=sqrt(a), A=exp(alpha u), a,b in (0,1/3), and q,nu,H_v>0, zeta>=0. In mass units q and zeta have dimension two, H_v dimension one, V0,V1,C dimension two, and Lambda and a constant matter vacuum density dimension four. All coefficients a,b,nu,H_v,zeta are independent of the original variable q. The new completion is an explicitly supplied action, not a consequence of the earlier analytic-fluid theorem.

Write M_xx=4b/(9D), M_yy=b/(3D), where D=1+2(1+b)(x^2+y^2)/3. Up to the stipulated boundary term, the Weyl identity is

    sqrt(-g_J) R_J = sqrt(-g) [A^2 R + 6a A^2 (grad u)^2].

Consequently the original local action is F R/2-Z_ij grad(phi^i)grad(phi^j)-2qW, with

    F=q+zeta A^2,
    Z_uu=q-3a zeta A^2,
    Z_xx=(q+zeta)M_xx, Z_yy=(q+zeta)M_yy,
    2qW=2qV0+2zeta V1+(Lambda+rho_vac)A^4.

The three-form variations make q and Lambda constant in the admitted q>0 sector. Before that reduction, variation with respect to q and Lambda gives

    L0 vol_g + (q/M_aux^4) Fhat4=0,
    -A^4 vol_g + F4/mu_aux^4=0,
    L0=R/2-K_b,ij grad(phi^i)grad(phi^j)-2V0.

Neither of the zeta operators contributes an explicit q derivative. The constant shift rho_vac -> rho_vac+delta, Lambda -> Lambda-delta leaves the local action and form equations unchanged. The full action changes by the boundary-sector constant -delta integral(F4)/mu_aux^4. This is a classical fixed-sector compensation, not a quantum naturalness conclusion.

Only after these variations set s=zeta/q and C=(Lambda+rho_vac)/(2q). Holding s fixed while varying q in the reduced expression would instead add s times the zeta-operator density. Nor may a calibration b=k be substituted as a q-dependent function inside the original action: with fixed a,zeta,

    k(q)=a q/[q+(1-3a)zeta],
    dk/dq=a(1-3a)zeta/[q+(1-3a)zeta]^2.

It produces an extra (partial L/partial b)(dk/dq). A concrete off-orbit spatial-x-gradient fixture gives -8/225 for that extra term, so the distinction is operational rather than verbal.

At b=a and zeta=0 the analytic field functions K,V0,A equal the prior AN functions. The unreduced auxiliary/form sector nevertheless remains; the old local AN equations additionally require C=0. This is satisfied on the selected ideal orbit because C=3sH_v^2/2 and s=0. Equality of the supplied field sector is not equality of the entire unreduced auxiliary action to bare AN.

## Einstein variables and finite-field positivity

For ghat=(F/q)g=(1+sA^2)g, the coefficient of the Einstein Ricci scalar is q/2. The scalar metric is

    Khat_ij=Z_ij/F+(3/4)(partial_i ln F)(partial_j ln F).

The 3/4 follows from the kinetic convention -q Khat_ij grad(phi^i)grad(phi^j), without a separate 1/2. Thus, with z=sA^2 and J=1+(1-3a)z,

    Khat_uu=J/(1+z)^2,
    Khat_xx=(1+s)M_xx/(1+z),
    Khat_yy=(1+s)M_yy/(1+z),
    Vhat=(V0+sV1+C A^4)/(1+z)^2,
    B=A/sqrt(1+z), g_J=B^2 ghat.

Here F>0, J>0 and all three scalar kinetic eigenvalues are positive at finite fields. A possibly negative raw Z_uu is not by itself a ghost test, because the Ricci mixing contributes to the physical kinetic matrix. The limit b=0 is excluded; no claim of a regular b=0 theory follows.

For completeness, the local fixed-sector equations before the Weyl change can be written

    F G_mn = T_mn + 2 Z_ij partial_m phi^i partial_n phi^j
             -g_mn[Z_ij grad(phi^i)grad(phi^j)+2qW]
             +nabla_m nabla_n F-g_mn box F,

    2 nabla_m(Z_ij partial^m phi^j)
      -(partial_i Z_jl)grad(phi^j)grad(phi^l)
      -2q partial_i W+(partial_i F)R/2+alpha delta_iu T_m=0.

The matter exchange is nabla_m T^m_n=alpha T_m partial_n u. For homogeneous pressureless matter this gives rho_m_dot+3H rho_m=alpha u_dot rho_m; trace-free ideal radiation gives rho_r_dot+4H rho_r=0. Separate conservation in the original g frame is therefore valid on the proposed u=0 orbit, not a general off-orbit dust identity.

## Independent full ideal-fluid check

Supply C=3sH_v^2/2 and use the proposed history

    u=0, x=x0 exp(-3N/2), y=y0 exp(-2N), H=H_v sqrt(D),
    rho_m=2q(1+s)H_v^2 x^2, rho_r=2q(1+s)H_v^2 y^2.

On this orbit A=1 and u_dot=0, so the original g time, density and scale are physical Jordan quantities. Set X=H_v^2 x^2 and Y=H_v^2 y^2. Direct differentiation gives

    x_dot=-3Hx/2, y_dot=-2Hy,
    T_b=M_xx x_dot^2+M_yy y_dot^2=b(X+4Y/3),
    H_dot=-(1+b)(X+4Y/3),
    R=12H_v^2+2(1+b)X,
    W=(1+s)[3H_v^2/2+bX/2+bY/3].

Since F is constant along the orbit, the complete metric equations reduce to

    3q(1+s)H^2=rho_m+rho_r+q(1+s)T_b+2qW,
    -2q(1+s)H_dot=rho_m+4rho_r/3+2q(1+s)T_b.

Substitution makes both equalities exact, with separately conserved dust and radiation. This alone is insufficient: each scalar equation must also hold.

For x and y, the full Euler-Lagrange covectors after dividing out q+zeta are

    d/dtau(M_ii v^i)+3H M_ii v^i
      -(1/2)sum_j (partial_i M_jj)(v^j)^2
      +partial_i[W/(1+s)]=0.

The field metric must be differentiated. Let D_x=4(1+b)x/3 and D_y=4(1+b)y/3. Raising the index gives the two contracted connection terms

    Gamma^x_jl v^j v^l
      =-D_x v_x^2/(2D)-D_y v_x v_y/D+3D_x v_y^2/(8D)
      =3 H_dot x/2,
    Gamma^y_jl v^j v^l
      =2D_y v_x^2/(3D)-D_x v_x v_y/D-D_y v_y^2/(2D)
      =2 H_dot y.

The acceleration terms are x_ddot=-3H_dot x/2+9H^2x/4 and y_ddot=-2H_dot y+4H^2y. The raised potential forces are 9H^2x/4 and 2H^2y. Acceleration, friction, connection and force cancel separately in each equation. Equivalently the source's lowered-velocity identity means M_ij v^j=-[b/(1+b)] partial_i H. It is not an identity for unlowered coordinate velocities.

For the u equation, partial_u Z_xx=partial_u Z_yy=0 in the original frame. On the orbit its kinetic derivatives vanish, but the Ricci and matter sources do not. Direct differentiation before setting u=0 gives

    W_u=alpha[(sb-1)X+6sH_v^2],
    -2qW_u+alpha q s R-alpha rho_m=0.

The constant terms cancel, and the X coefficient is -2(sb-1)+2s(1+b)-2(1+s)=0. There is no Y source because ideal radiation is trace-free. A realistic fluid with nonzero rho-3p would require a new check.

An independent proper-time numerical route differentiates the N histories with 80-digit mpmath, builds the contracted Christoffel terms separately, and evaluates all five x/y/u/Friedmann/Raychaudhuri residuals. It covers dust, radiation, mixed, small-positive-b and vacuum cases. Its largest normalized residual is 4.686725e-80. These finite samples supplement the exact identities; they are not a cosmological integration or attraction test.

## Auxiliary fluxes on this history

The Lorentzian kinetic contraction is -T_b on the homogeneous orbit. Hence

    L0=R/2+T_b-2V0
      =3H_v^2+(1+b)X+(2b/3)Y.

Writing Phi and Phihat for the integrated forms,

    -q mu_aux^4 Phihat/(M_aux^4 Phi)
      =integral(L0 vol_g)/integral(A^4 vol_g).

Because A=1 on the orbit, this is the spacetime-volume average of L0. It exceeds 3H_v^2 over a finite region with nonzero positive-fluid contribution of positive measure. A regulated expanding future can have average limit 3H_v^2 while the two absolute fluxes diverge. That ratio statement does not equate different finite histories in a common pair of fixed finite absolute-flux sectors. The source explicitly retains this distinction.

## Potential bound and local masses

The x^2 coefficient in (V0+sV1)/H_v^2 is

    f_s(u)=A_q u^2+B_q u+C_q,
    A_q=2a(1+s)/b, B_q=alpha(sb-1), C_q=b(1+s)/2.

Completing the square gives

    f_s=A_q[u+B_q/(2A_q)]^2
        +b[3+(2-b)s][1+(2+b)s]/[8(1+s)].

Every factor in the minimum is strictly positive on the stated domain. Together with nu>0 and the y^2 term, this establishes the stated all-u coefficient bound. At the specified C>=0 it also leaves a positive original-frame potential. It does not establish coercive energy sublevels in ghat. For s>0 and x=y=0, Vhat tends to C/s^2 as u tends to positive infinity, and sqrt(Khat_uu) is asymptotic to sqrt((1-3a)/s) exp(-alpha u), so this endpoint has finite scalar distance. The old global-attractor proof cannot be imported.

Differentiate Vhat holding a,b,s,C,nu,H_v fixed; only afterwards impose u=x=y=0 and C=3sH_v^2/2. The gradient vanishes, so the covariant Hessian equals the ordinary Hessian at this stationary point. The vacuum scalar metric is

    Khat_vac=diag(J0/(1+s)^2,4b/9,b/3),
    J0=1+(1-3a)s.

All mixed Hessian entries vanish. Because g_J=ghat/(1+s) there, the physical squared masses are (1+s)Khat_vac^-1 Hess(Vhat). This yields

    m_u,J^2/H_v^2=[nu(1+s)+12as]/J0,
    m_x,J^2/H_v^2=9/4,
    m_y,J^2/H_v^2=2.

All are positive. They are local vacuum fluctuation masses, not an off-orbit cosmological eigenvalue classification. The supplied coefficient 2a/b grows at small b; nothing in this check removes the need to examine interactions, mixing, or an effective-theory scale there.

## Conditional local-gravity normalization

At u=0, partial_u ln B=alpha/(1+s), and the squared scalar matter coupling is

    k=Khat_uu^-1(partial_u ln B)^2=a/J0.

The stipulated light-scalar weak-body local exchange bridge then gives

    G_N=(1+k)/[8pi q(1+s)].

This is the prior stationary-vacuum bridge. Applying it on an evolving fluid solution additionally assumes a local regime with physical momentum large compared with relevant masses, background variation and mixing rates, and negligible medium/strong-body corrections. Merely knowing the homogeneous solution does not establish that regime or an apparatus response. The source marks this assumption explicitly.

The exact homogeneous equations independently imply

    H_J^2-H_v^2=(1+b)(rho_m+rho_r)/[3q(1+s)].

Combining this equation with the conditional local bridge gives S^2=(1+b)/(1+k). The comparison holds physical densities and the specified local G_N fixed; S^2 is the coefficient ratio for the fluid term. A total-Hubble comparison also needs the reference vacuum term and becomes the stated S only in a fluid-dominated limit.

For the prior eta=0 family a=(1-k)(1+3k)/4 and s=(1+k)/[k(1-3k)], with 0<k<1/3, setting the independent constant b=a gives S^2=(5-3k)/4. The phrase old equality refers to that parameter restriction in the completed action; it does not supply a fluid solution of an uncompleted zeta-only action.

For an imposed target T=S_target^2, the inverse is b=T(1+k)-1. The admitted target interval is strictly

    1/(1+k) < T < 4/[3(1+k)].

Thus T=1 calibrates b=k; it does not predict b. After fixing the sector's a,b,s and a physical G_N, q+zeta=(1+k)/(8pi G_N), q=(q+zeta)/(1+s) and zeta=sq. These calibrations do not redefine original q variation. The independent exact target table preserves all 24 rows, including 18 exclusions and both exact b boundaries.

## Ideal thermal diagnostics

Under the supplied equilibrium idealization, the Bose and Fermi energy integrals have ratio 7/8. Counting two photon, four electron/positron and six neutrino/antineutrino spin states gives g*=2+(7/8)(4+6)=43/4. An additional equal-temperature two-state neutrino species contributes 7/4. The density-equivalent pre-annihilation increment is consequently (43/7)(S^2-1).

With instantaneous decoupling and photon entropy transfer, T_nu/T_gamma=(4/11)^(1/3), so c_nu=(7/8)(4/11)^(4/3)=0.2271073176602389634... . For the supplied N_base=3, equating ideal post-annihilation radiation densities gives Delta N_post=(S^2-1)(1/c_nu+3). At k=10^-5 on b=a the independent numbers are S^2=1.2499925, S=1.1180306346428974, Delta N_pre=1.5356682142857143 and Delta N_post=1.850745641579648. On b=k both increments vanish by calibration.

These are two different background translations of a total-radiation rescaling. They do not imply one constant added neutrino population across annihilation, the same perturbations, or a measured radiation abundance. During actual annihilation the electron trace and entropy transfer invalidate an automatic continuation of u=0 and y proportional to scale^-2. Nuclear reactions, transport, abundances, full thermal evolution and empirical likelihoods are not evaluated here.
