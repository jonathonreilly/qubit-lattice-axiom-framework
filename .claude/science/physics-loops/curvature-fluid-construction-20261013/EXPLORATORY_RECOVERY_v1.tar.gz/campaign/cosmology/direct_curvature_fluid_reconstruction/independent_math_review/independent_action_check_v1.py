#!/usr/bin/env python3
"""Independent original-action, full homogeneous EL and normalization checks.

The author implementation is neither imported nor executed. Exact rational
boundaries are kept distinct; numerical rows use independent differentiation.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
from fractions import Fraction as Q
import datetime,hashlib,json,platform
import sympy as sp
import mpmath as mp
p=Path(__file__).resolve().parent
mp.mp.dps=80
checks=[]
def check(name,value,detail=None):checks.append({'name':name,'pass':bool(value),'detail':detail})
def exact(name,left,right):
    r=sp.factor(sp.together(left-right));check(name,r==0,str(r))
def dec(x):return mp.nstr(x,60)
def mq(x):return mp.mpf(x.numerator)/x.denominator

a,b,s,q,zeta,Hv,nu=sp.symbols('a b s q zeta Hv nu',positive=True)
u,x,y=sp.symbols('u x y',real=True)
C,R,du2,dx2,dy2,Lambda,rho,f4,fh,mu4,M4=sp.symbols('C R du2 dx2 dy2 Lambda rho f4 fh mu4 M4',real=True)
alpha=sp.sqrt(a);A=sp.exp(alpha*u)
Db=1+sp.Rational(2,3)*(1+b)*(x*x+y*y)
Kx=4*b/(9*Db);Ky=b/(3*Db)
V0=Hv**2*(sp.Rational(3,2)+(b/2-alpha*u+2*a*u*u/b)*x*x+b*y*y/3+nu*u*u/2)
V1=Hv**2*((b/2+alpha*b*u+2*a*u*u/b)*x*x+b*y*y/3)
L0=R/2-du2-Kx*dx2-Ky*dy2-2*V0
Lz=A*A*R/2+3*a*A*A*du2-Kx*dx2-Ky*dy2-2*V1
L=q*L0+zeta*Lz-(Lambda+rho)*A**4+Lambda*f4/mu4+q*q*fh/(2*M4)
exact('original q variation retains exactly L0',sp.diff(L,q),L0+q*fh/M4)
exact('new operator has no explicit q derivative',sp.diff(zeta*Lz,q),0)
exact('Lambda form equation',sp.diff(L,Lambda),-A**4+f4/mu4)
delta=sp.symbols('delta',real=True)
exact('constant matter vacuum compensation',L.subs({rho:rho+delta,Lambda:Lambda-delta},simultaneous=True)-L,-delta*f4/mu4)
exact('wrong fixed-s variation extra term',sp.diff(L.subs(zeta,q*s),q)-sp.diff(L,q).subs(zeta,q*s),s*Lz)
kq=a*q/(q+(1-3*a)*zeta)
exact('calibration inserted before q variation has nonzero b derivative',sp.diff(kq,q),a*(1-3*a)*zeta/(q+(1-3*a)*zeta)**2)

z=sp.symbols('z',real=True)
F=q+zeta*A*A
Zuu=q-3*a*zeta*A*A
Khat_u=sp.factor(Zuu/F+sp.Rational(3,4)*(sp.diff(F,u)/F)**2)
exact('complete u kinetic metric',Khat_u.subs(zeta,q*z/A**2),(1+(1-3*a)*z)/(1+z)**2)
exact('transverse metric Weyl factor',((q+zeta)/F).subs(zeta,q*s),(1+s)/(1+s*A*A))
oldV=Hv**2*(sp.Rational(3,2)+(a/2-alpha*u+2*u*u)*x*x+a*y*y/3+nu*u*u/2)
exact('b=a zeta=0 potential reduces to old analytic potential',V0.subs(b,a),oldV)

# Full homogeneous equations are evaluated in original g, where F is constant on u=0.
W=V0+s*V1+C*A**4
Wstar=W.subs(C,sp.Rational(3,2)*s*Hv**2)
Worb=sp.factor(Wstar.subs(u,0))
H=Hv*sp.sqrt(Db)
vx=-sp.Rational(3,2)*H*x;vy=-2*H*y
Dt=lambda f:sp.diff(f,x)*vx+sp.diff(f,y)*vy
X=Hv**2*x*x;Y=Hv**2*y*y
Tb=sp.factor(Kx*vx*vx+Ky*vy*vy)
Hdot=sp.factor(Dt(H))
Rorb=sp.factor(6*(2*H*H+Hdot))
F0=q*(1+s)
rm=2*F0*X;rr=2*F0*Y
exact('orbit scalar kinetic norm',Tb,b*(X+sp.Rational(4,3)*Y))
exact('orbit potential',Worb,(1+s)*(sp.Rational(3,2)*Hv**2+b*X/2+b*Y/3))
exact('Hdot from field velocities',Hdot,-(1+b)*(X+sp.Rational(4,3)*Y))
exact('Ricci scalar has no radiation contribution',Rorb,12*Hv**2+2*(1+b)*X)
exact('full Friedmann equation',3*F0*H*H,rm+rr+F0*Tb+2*q*Worb)
exact('full Raychaudhuri equation',-2*F0*Hdot,rm+sp.Rational(4,3)*rr+2*F0*Tb)
exact('dust conservation on u0',Dt(rm)+3*H*rm,0)
exact('radiation conservation on u0',Dt(rr)+4*H*rr,0)
# Euler-Lagrange covectors include every field-metric derivative.
EL=[]
for fi,ki,vi in [(x,Kx,vx),(y,Ky,vy)]:
    el=Dt(ki*vi)+3*H*ki*vi-sp.Rational(1,2)*(sp.diff(Kx,fi)*vx*vx+sp.diff(Ky,fi)*vy*vy)+sp.diff(Worb,fi)/(1+s)
    EL.append(sp.factor(el))
    exact('complete scalar EL '+str(fi),el,0)
    exact('lowered gradient flow '+str(fi),ki*vi,-b/(1+b)*sp.diff(H,fi))
Wu=sp.factor(sp.diff(Wstar,u).subs(u,0))
exact('u potential source',Wu,alpha*((s*b-1)*X+6*s*Hv**2))
E_u=-2*q*Wu+alpha*q*s*Rorb-alpha*rm
exact('complete u equation including matter and Ricci sources',E_u,0)
L0orb=sp.factor(Rorb/2+Tb-2*V0.subs(u,0))
exact('original q constraint along orbit',L0orb,3*Hv**2+(1+b)*X+2*b*Y/3)

# The all-u lower bound is proven by completing the exact square.
quad=2*a*(1+s)/b;lin=alpha*(s*b-1);const=b*(1+s)/2
fs=quad*u*u+lin*u+const
minimum=sp.factor(const-lin*lin/(4*quad))
exact('positive discriminant gap',4*quad*const-lin*lin,a*(3+(2-b)*s)*(1+(2+b)*s))
exact('explicit minimum of x squared coefficient',minimum,b*(3+(2-b)*s)*(1+(2+b)*s)/(8*(1+s)))
exact('full square decomposition',fs,quad*(u+lin/(2*quad))**2+minimum)

# All field derivatives are taken before specializing to the fixed-constant vacuum.
Vhat=Wstar/(1+s*A*A)**2
vac={u:0,x:0,y:0}
fields=[u,x,y]
hessian=sp.hessian(Vhat,fields).subs(vac)
Kvac=sp.diag((1+(1-3*a)*s)/(1+s)**2,4*b/9,b/3)
mass_physical=sp.simplify((1+s)*Kvac.inv()*hessian/Hv**2)
for i,fi in enumerate(fields):exact('vacuum gradient '+str(fi),sp.diff(Vhat,fi).subs(vac),0)
expected_m=[(nu*(1+s)+12*a*s)/(1+(1-3*a)*s),sp.Rational(9,4),sp.Integer(2)]
for i,fi in enumerate(fields):
    exact('physical vacuum mass '+str(fi),mass_physical[i,i],expected_m[i])
    for j in range(3):
        if i!=j:exact('mixed physical vacuum Hessian '+str(fi)+' '+str(fields[j]),mass_physical[i,j],0)

# Density/force normalization is a separate explicitly imported local bridge.
k,g8,Starget=sp.symbols('k g8 Starget',positive=True)
S2=(1+b)/(1+k)
exact('homogeneous fluid coefficient', (H*H-Hv**2)/(rm+rr),(1+b)/(3*F0))
exact('measured GN eliminates bare coefficient',((1+b)/(3*F0)).subs(q,(1+k)/(g8*(1+s))),g8*S2/3)
nulla=(1-k)*(1+3*k)/4
exact('old equality null ratio',S2.subs(b,nulla),(5-3*k)/4)
exact('calibrated b=k ratio',S2.subs(b,k),1)
exact('inverse fluid normalization',S2.subs(b,Starget*(1+k)-1),Starget)

# Adverse controls on the exact proposed orbit; no retuning of its fields or sources.
mutations=[]
for label,expr in [('omit induced Ricci u source',E_u-alpha*q*s*Rorb),('omit new V1 u source',E_u+2*q*s*sp.diff(V1,u).subs(u,0)),('omit matter trace source',E_u+alpha*rm),('omit zeta transverse completion from Friedmann',q*s*(Tb+2*V1.subs(u,0)))]:
    value=sp.factor(expr.subs({a:sp.Rational(1,4),b:sp.Rational(1,5),s:1,q:1,Hv:1,x:1,y:2}))
    check('mutation exposed '+label,value!=0,str(value))
    mutations.append({'mutation':label,'residual_at_fixed_fixture':str(value)})
wrong_b_extra=sp.factor((-4*(q+zeta)/9)*sp.diff(kq,q))
val=sp.factor(wrong_b_extra.subs({a:sp.Rational(1,4),q:1,zeta:1}))
check('calibration-before-variation mutation exposed',val==sp.Rational(-8,225),str(val))
mutations.append({'mutation':'insert b=k(q) before varying q','extra_term_at_spatial_x_gradient_fixture':str(val)})

# Independent proper-time differentiation along exact N histories, without using symbolic EL outputs.
fixtures=[('dust',Q(1,4),Q(1,10),Q(0),Q(2),Q(0),Q(1)),('radiation',Q(1,9),Q(1,100),Q(2),Q(0),Q(-3),Q(-1)),('mixed',Q(1,4),Q(1,5),Q(1),Q(1),Q(2),Q(0)),('small b',Q(1,4),Q(1,100000),Q(1000),Q(-2),Q(1),Q(1,2)),('vacuum',Q(1,100),Q(1,1000),Q(10),Q(0),Q(0),Q(0))]
numeric=[]
for label,aa,bb,ss,xinit,yinit,nsite in fixtures:
    av,bv,sv,xv0,yv0,n0=map(mq,(aa,bb,ss,xinit,yinit,nsite))
    XX=lambda N:xv0*mp.exp(-3*N/2)
    YY=lambda N:yv0*mp.exp(-2*N)
    DD=lambda N:1+2*(1+bv)*(XX(N)**2+YY(N)**2)/3
    HH=lambda N:mp.sqrt(DD(N))
    xval,yval,hval=XX(n0),YY(n0),HH(n0)
    xdot=lambda N:HH(N)*mp.diff(XX,N)
    ydot=lambda N:HH(N)*mp.diff(YY,N)
    vxv,vyv=xdot(n0),ydot(n0)
    acc=[hval*mp.diff(xdot,n0),hval*mp.diff(ydot,n0)]
    hd=hval*mp.diff(HH,n0)
    dval=DD(n0);Dx=4*(1+bv)*xval/3;Dy=4*(1+bv)*yval/3
    connx=-Dx*vxv**2/(2*dval)-Dy*vxv*vyv/dval+3*Dx*vyv**2/(8*dval)
    conny=2*Dy*vxv**2/(3*dval)-Dx*vxv*vyv/dval-Dy*vyv**2/(2*dval)
    force=[9*dval*xval/4,2*dval*yval]
    ex=acc[0]+3*hval*vxv+connx+force[0]
    ey=acc[1]+3*hval*vyv+conny+force[1]
    Fv=1+sv;Tv=4*bv*vxv**2/(9*dval)+bv*vyv**2/(3*dval)
    wv=(1+sv)*(mp.mpf('1.5')+bv*xval*xval/2+bv*yval*yval/3)
    rmv=2*Fv*xval*xval;rrv=2*Fv*yval*yval
    fried=3*Fv*hval*hval-rmv-rrv-Fv*Tv-2*wv
    ray=-2*Fv*hd-rmv-4*rrv/3-2*Fv*Tv
    ric=6*(2*hval*hval+hd)
    wuv=mp.sqrt(av)*((sv*bv-1)*xval*xval+6*sv)
    eu=-2*wuv+mp.sqrt(av)*sv*ric-mp.sqrt(av)*rmv
    residuals=[ex,ey,eu,fried,ray]
    scale=max(1,abs(rmv),abs(rrv),abs(wv),abs(ric))
    check('proper time full equation fixture '+label,max(map(abs,residuals))/scale<mp.mpf('1e-65'),[dec(v) for v in residuals])
    numeric.append({'label':label,'a':str(aa),'b':str(bb),'s':str(ss),'x0':str(xinit),'y0':str(yinit),'N':str(nsite),'residuals_xyu_Friedmann_Raychaudhuri':list(map(dec,residuals)),'normalized_maximum':dec(max(map(abs,residuals))/scale),'connection_omission_xy_residuals':[dec(-connx),dec(-conny)]})
check('connection omission is detectable on a mixed history',any(abs(mp.mpf(v))>mp.mpf('1e-10') for r in numeric if r['label']=='mixed' for v in r['connection_omission_xy_residuals']))

# Exact inverse target boundaries are retained, including inadmissible rows.
targets=[]
for kk in [Q(1,100000000),Q(1,100000),Q(1,10),Q(3,10)]:
    for st in [Q(1,2),Q(1),Q(5,4),Q(2),1/(1+kk),Q(4,3)/(1+kk)]:
        bt=st*(1+kk)-1;valid=0<bt<Q(1,3)
        check('inverse speed identity '+str(kk)+' '+str(st),(1+bt)/(1+kk)==st)
        if bt in (Q(0),Q(1,3)):check('strict b boundary excluded '+str(kk)+' '+str(bt),not valid)
        targets.append({'k':str(kk),'S_target_squared':str(st),'b':str(bt),'admitted':valid})
check('target rows retain both admissible and excluded results',any(r['admitted'] for r in targets) and any(not r['admitted'] for r in targets))

# Thermal factors follow from supplied equilibrium statistics, not a nuclear-reaction model.
thermal=[]
bose=mp.quad(lambda r:r**3/mp.expm1(r) if r else mp.mpf(0),[0,1,mp.inf])
fermi=mp.quad(lambda r:r**3/(mp.exp(r)+1),[0,1,mp.inf])
check('equilibrium Fermi Bose energy ratio',abs(fermi/bose-mp.mpf(7)/8)<mp.mpf('1e-70'),dec(fermi/bose))
gstar=Q(2)+Q(7,8)*(Q(4)+Q(6));extra=Q(7,8)*2
check('pre annihilation degree count',gstar==Q(43,4) and extra==Q(7,4))
check('ideal photon entropy transfer',Q(2)/(Q(2)+Q(7,8)*4)==Q(4,11))
cn=mp.mpf(7)/8*(mp.mpf(4)/11)**(mp.mpf(4)/3)
for kk in [Q(1,100000),Q(1,10),Q(3,10)]:
    aa=(1-kk)*(1+3*kk)/4
    for label,bb in [('equality b=a',aa),('calibrated b=k',kk)]:
        speed=(1+bb)/(1+kk);pre=Q(43,7)*(speed-1);post=mq(speed-1)*(1/cn+3)
        check('thermal density reconstruction '+str(kk)+' '+label,abs((1+cn*(3+post))-mq(speed)*(1+3*cn))<mp.mpf('1e-70'))
        if bb==kk:check('calibration gives both zero ideal diagnostics '+str(kk),pre==0 and post==0)
        else:check('pre and post diagnostics differ '+str(kk),abs(post-mq(pre))>mp.mpf('1e-3'))
        thermal.append({'k':str(kk),'branch':label,'b':str(bb),'S_squared':str(speed),'S':dec(mp.sqrt(mq(speed))),'Delta_N_pre':str(pre),'Delta_N_pre_decimal':dec(mq(pre)),'Delta_N_post':dec(post)})
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Original auxiliary variation; Weyl normalization; full original-frame EL covectors; fixed-constant Hessian; independent proper-time differentiation; rational inverse targets; ideal Fermi/Bose quadrature.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__,'digits':mp.mp.dps,'checks':checks,'pass_count':sum(c['pass'] for c in checks),'fail_count':sum(not c['pass'] for c in checks),'action_mutations':mutations,'proper_time_rows':numeric,'inverse_targets':targets,'thermal_rows':thermal,'thermal_c_nu':dec(cn),'author_code_imported_or_executed':False}
(p/'INDEPENDENT_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass_count'],'fail':result['fail_count'],'failed':[c for c in checks if not c['pass']],'numeric_rows':numeric,'mutations':mutations,'thermal_rows':thermal},indent=2))
raise SystemExit(bool(result['fail_count']))
