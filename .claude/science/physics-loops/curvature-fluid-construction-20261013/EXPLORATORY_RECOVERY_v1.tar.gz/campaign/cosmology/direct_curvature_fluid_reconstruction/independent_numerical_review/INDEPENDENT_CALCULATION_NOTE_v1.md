# Independent implementation calculation and replay method

This is a checker derivation of the supplied parent action, not a replacement
candidate or an empirical inference. All parameter and data choices remain
the parent's declared premises. The successful calculation is
`independent_recompute_v2.py`; its v1 predecessor and actual failure remain.

## Action and q derivative

Use H_v=1 as the unit of frequency, alpha=sqrt(a), E=exp(2 alpha u),
D=1+2(1+b)(x^2+y^2)/3 and the supplied V0,V1. Before imposing a fixed q
sector the Ricci coefficient is F_raw=q+zeta E. The kinetic entries are
Z_u=q-3a zeta E, Z_x=(q+zeta)4b/(9D) and
Z_y=(q+zeta)b/(3D). Conformal transformation gives

    K_i = Z_i/F_raw + (3/4)(partial_i F_raw/F_raw)^2.

Substitute zeta=sq only after this action differentiation. This produces the
stated Einstein metric. Symbolic differentiation of these expressions supplies
all nine partial_i K_j entries; no author metric-derivative helper supplies an
expected value.

Write the bulk action as q L0+zeta L1 with

    L0=R/2-Q_u-K_b,xx Q_x-K_b,yy Q_y-2V0,
    L1=E R/2+3a E Q_u-K_b,xx Q_x-K_b,yy Q_y-2V1.

Its q derivative at fixed zeta and fixed a,b,nu,H_v is L0. Replacing zeta by
sq and holding s fixed during variation instead adds s L1. On the ideal
history this addition is s[6+(1+b)x^2+2by^2/3] in H_v=1 units. It is strictly
nonzero for s>0, including the empty-fluid limit. Choosing b=k after solving
a sector does not authorize varying b with q in the original action.

The original q L0, form constraints and matter compensation remain conditional
on the supplied auxiliary theory. No quantum or boundary-selection result is
deduced by this numerical check.

## Reference clocks, potential and masses

For each fixed sector define Hhat_v=H_v/sqrt(1+s), F=1+sE and

    U = Vhat/Hhat_v^2 = (1+s)(V0+sV1+3sE^2/2)/F^2.

The symbol U in the checker always denotes this dimensionless potential.
The matter metric is B^2 ghat with B=exp(alpha u)/sqrt(F), so
partial_u ln B=alpha/F. At u=x=y=0 the gradient vanishes and the Hessian is
diagonal; the Christoffel correction to a covariant Hessian therefore vanishes.
Since B0^2=1/(1+s), conversion from Einstein to physical time exactly cancels
the Hhat_v/H_v reference factor. Hence the physical m_i^2/H_v^2 is
U_ii/K_i at the origin, giving

    [nu(1+s)+12as]/[1+(1-3a)s],  9/4,  2.

The independent script differentiates U before evaluating the origin and
compares all 216 stored mass entries. It does not substitute the closed mass
formula into its expected-value producer. The polynomial coefficient of x^2
has quadratic minimum C-B^2/(4A), which is strictly positive on the stated
domain; its derivative gives the stored u_min. These are local/finite-action
statements and do not restore the previous global-convergence proof.

## Independent evolution formulation

Let tau=Hhat_v that, v=dphi/dtau, and define normalized covariant momentum
Pi_i=K_i v_i. Let sm=rhohat_m/(2q Hhat_v^2) and
sr=rhohat_r/(2q Hhat_v^2). With the expanding Einstein branch,

    H^2 = [sum_i Pi_i^2/K_i + 2(U+sm+sr)]/3,
    dphi_i/dtau = Pi_i/K_i,
    dPi_i/dtau = -3H Pi_i + (1/2)sum_j(partial_i K_j)v_j^2
                  -partial_i U - alpha_i sm,
    dsm/dtau = (-3H+alpha_u v_u)sm,
    dsr/dtau = -4H sr,
    dH/dtau = -sum_i K_i v_i^2 - sm - 4sr/3.

These follow directly from the kinetic Euler equation and ideal matter
continuity. Divide by H to integrate in Einstein N. This uses momenta and the
energy form of the constraint, whereas the author integrates p=dphi/dN using
a Christoffel contraction and denominator 3-Kp^2. The independent integration
uses DOP853 with rtol 2e-12, atol 2e-14 and maximum N step .02; the author uses
Radau with different tolerances. Both inspect all 41 times in each of four
supplied histories. No author's evolution helper is called by the independent
integrator.

For comparison of the actual implementation at prescribed p, solve
H^2=2(U+sm+sr)/(3-Kp^2), set v=Hp, compute the proper-time momentum equation,
then form p'_i=vdot_i/H^2-p_i Hdot/H^2. This checks the full eight-component
author RHS by a separately assembled route.

At the ideal u=0 history the original and physical clocks agree. F is a
constant, so Einstein and original N differ only by an arbitrary additive
constant. Also Hhat/Hhat_v=H_g/H_v. The energy equation independently yields
H^2=D rather than putting the time-dependent H into the field metric.

## Finite-field test domain and preserved reviewer error

The derivative/RHS comparison uses all 72 parameter tuples and all five
supplied positivity_u values, with x=.3,y=.5 and sm=.4,sr=.7. The first attempt
used fixed coordinate p=(.11,.03,-.04). At large s and negative u the transverse
K entries can be large, so this does not guarantee Kp^2<3. The author correctly
rejected one such state with Kp^2=3.2827953332595854 and negative H^2.

The preserved v2 fixture uses p_i=seed_i/sqrt(K_i), seed=(.11,.03,-.04).
Its exact kinetic norm is .0146, so every state is inside the expanding
Friedmann chart. Fields, parameters, densities and error tolerances are
unchanged. No finalized successful calculation was rerun: v1 aborted before
writing its result or reference. The corrected script completed 32831 checks.

The author `full_einstein_functions` and `full_n_rhs` are extracted from their
pinned AST only as units under test. They do not supply the independently
differentiated field functions, reference values or momentum integrations.
All 360 finite-field reference records are stored for reuse without rerunning
positive science.

## Inverse and ideal thermal quantities

Rational arithmetic gives k=a/[1+(1-3a)s], the supplied PPN response, and
S^2=(1+b)/(1+k). The null branch is reconstructed from k independently, and
b=S_target^2(1+k)-1 is classified against the open interval (0,1/3). All
30 inverse cases are retained, including 18 exclusions. S rescales the fluid
contribution to H^2; the total Hubble ratio also contains H_v.

The ideal preannihilation count is 2+(7/8)(4+2N_base)=43/4 at N_base=3.
The postannihilation temperature ratio comes from separately conserved plasma
entropy: Tnu/Tgamma=[2/(2+(7/8)4)]^(1/3). The checker computes c_nu from that
ratio, then compares each changed total density with one neutrino species.
This independently reproduces both supplied Delta-N diagnostics. They refer
to different ideal epochs; neither is a nuclear network, transport result,
joint likelihood or observed additional neutrino population.

## Replay and evidence

Replay the independent script only in a fresh copy with its output paths
absent. It exclusively creates output files. Preserve the original source
freeze and the exact copied author functions. `run_mutations_v1.py` runs eight
declared real source changes in separate directories, each with nine fresh
input hashes. `verify_survivors_v1.py` uses the already saved controls to expose
the three survivors; it does not redo the positive calculation.

Full source identities, actual failures, reading scope and every review file
are bound by the final receipt. Solver work counters are inspected as execution
metadata, not asserted equal across different numerical integrators.
