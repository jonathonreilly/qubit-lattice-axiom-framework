# Independent numerical review — curvature/fluid reconstruction v1

**The unmodified scientific output is supported on its complete frozen grid.
Two assertion-coverage repairs are required.** The independent calculation
completed **32831 passed, zero failed**. Three real source mutations still leave
all 5795 author checks passing: forcing the general u acceleration to zero,
zeroing its kinetic derivative, and serializing masses in the wrong physical
frame. The first two share an off-trajectory coverage gap; the third is an
output-binding gap. No error was found in the unmodified values themselves.

This is a focused implementation/numerical check, not a formal audit,
publication gate, new empirical test or alternative research authorship.
The parent is preparing a separate revision. This immutable report concerns
v1 only and must not be relabelled as a review of that future source.

## Pinned source and execution

Runner `check_curvature_fluid_v1.py`:
`2aab63f2e6acca63eecba32d5b1f932abd6fffdfcd964ef3e2e3aea26ebc8f92`.

First result `evidence_v1/RESULTS.json`:
`e58a6d43772f8c6904316ebe1ccaed459619816ee0baac33d655403dce90485b`.

The frozen author execution began at 11:09:59.295596 UTC on October 13, 2026
and completed at 11:10:03.666517, with 5795/0, exit 0 and all nine inputs
unchanged. The local evidence records no failed author run for this version.
The reviewer preserves 14 source/evidence snapshot pairs, including the
complete handwritten source, protocol, fixtures, source ledger, runner, all
four imported files and actual execution outputs.

All current source bytes remained identical through the independent run.
The handwritten construction explicitly changes the action: b is independent
of a, the zeta-dependent transverse kinetic/potential terms are supplied, and
2a/b is a new off-trajectory restoring coefficient. H_v, ideal-fluid amplitudes,
the constant sector C=3sH_v^2/2 and S_target are inputs, not inferred facts.

## Independent numerical calculation

The checker rebuilds the Einstein metric from the unreduced Z/F coefficient
and the Weyl derivative term, differentiates the resulting action symbolically,
and evaluates it at 110 decimal digits. It independently constructs the entire
output grid rather than importing author numerical helpers as value oracles.

For finite-field implementation comparisons, the actual two author functions
are units under test only. Expected derivatives and evolution terms come from
the independent action and covariant-momentum equation. The independent
history integration calls no author function.

| Result family | Checked scope |
|---|---|
| Parameters, Hessians and coefficient minima | 72 tuples; all 216 physical masses |
| Ideal histories and operator omissions | All 360 rows in each section |
| Finite-field metric, all derivatives and full RHS | 360 admitted synthetic states |
| Null-family response and ideal thermal equivalents | All 12 rows |
| Inverse expansion targets | All 30 rows: 12 admitted, 18 excluded |
| Four stored dynamical histories | All 164 sample times and eight state components |

The successful run's **32831** checks include 8643 output comparisons, 9360
finite-field comparisons, 3240 independent ideal-orbit equation controls,
1676 history/metadata comparisons and 9589 inspections of stored author
assertions. Source, action and local-vacuum checks make up the remainder.
These counts are computational checks, not measurements or independent
research routes. A separate exact check also verifies the stored wrong-q
symbolic expression with its declared contraction notation.

The largest normalized discrepancy among high-precision scientific output
values is 4.05e-75; comparison tolerance is 1e-60. The largest normalized
finite-field implementation discrepancy is 3.09e-13, below the predeclared
2e-11 tolerance. The high-precision full ideal-orbit RHS residual is at most
6.51e-104. These are finite numerical controls, not interval bounds or a proof
over all initial data.

The independent history solver evolves covariant momenta with the energy
constraint and DOP853. The author evolves N velocities with a Christoffel
contraction and Radau. Their largest normalized state difference is 3.72e-11,
below the review's 5e-8 comparison threshold. The independent histories' own
maximum departures from the exact orbit are, respectively, 3.33e-16,
1.15e-14, 3.17e-13 and 7.98e-12. The author's stored tracking-error values
are also correctly computed from its actual samples. Solver work counters
are execution metadata and are not expected to match across algorithms.

## Action, frame and variation checks

The action-to-Einstein transformation includes the new (q+zeta) transverse
kinetic factors. Its u metric entry, all mixed coordinate derivatives,
potential gradient and matter force agree with the independent implementation.
The stated positive kinetic domain is respected at every checked finite state.

The orbit's u equation needs all three terms: the scalar potential derivative,
the Ricci contribution and the dust trace. Removing the added potential gives
the stated nonzero residuals. Radiation has zero ideal trace. The full x,y
equations are verified through the independent momentum formulation, not only
through Friedmann conservation.

Varying q in the original action while a,b,zeta and other independent
parameters are fixed gives L0 alone. Holding s=zeta/q fixed prematurely adds
sL1 and is a different variation. The numerical wrong-variation diagnostic
agrees with s[6+(1+b)x^2+2by^2/3]. Its positivity for s>0 is retained even at
zero fluid amplitudes. The calibrated b=k relation is not inserted inside
the original variation.

Canonical Hessians are taken at the stationary origin. Their conversion to
physical time is essential: physical masses use the origin B factor as well
as the Einstein reference-frequency unit. All original physical mass values
are correct. The large coefficient 2a/b at small b remains explicit; the
finite positive minimum does not establish quantum consistency or global
attraction in the changed action.

The exact orbit, local vacuum and measured-gravity bridge remain separate
claims. Along u=0 the physical and original clocks agree, while Einstein
N differs only by a constant. The factor (1+k) in local G_N is required by the
supplied light-scalar weak-body response. Eliminating q+zeta gives the claimed
fluid-contribution ratio (1+b)/(1+k), not an all-epoch total Hubble ratio.

## Observation and thermal scope

The inverse b=S_target^2(1+k)-1 is exact within the stated open b domain.
All inadmissible targets remain visible. The old equality branch gives the
stated speed change; b=k removes that particular ideal background difference
by calibration. The exposed Cassini/LLR material is not a newly independent
early-expansion observation, and no measured S_target or nuclear likelihood
has been silently introduced.

The ideal preannihilation species count agrees with the declared particle
content in [Fields et al., v1, Eqs. 1–2 and the stated standard-BBN assumptions](https://arxiv.org/pdf/1912.01132v1).
This source also makes the required particle/reaction and cosmological inputs
explicit. No abundance or likelihood result from the paper is used here.

The entropy-based temperature ratio and the postannihilation radiation
definition agree with [Pitrou et al., v3, Eqs. 20–32 and 63–66](https://arxiv.org/pdf/1801.08023v3).
The checker independently obtains the ratio from the photon/electron entropy
counts and computes both density equivalents. Different pre/post Delta-N
values do not describe one added neutrino population through the transition.
The source's transport qualifications are consistent with leaving thermal
transitions, reactions and primordial perturbations open.

The new external reading is limited to those specified primary sections.
No raw paper bytes were downloaded or claimed hash-pinned. The earlier PPN
reading and body/scale assumptions are carried forward at their exact local
source identity. Zero independent empirical tests are performed.

## Actual source challenges

Each trial changes a copied source expression and runs with a fresh freeze of
all nine actual input files. All nine source checks pass in every trial, and
all inputs remain unchanged. Assertions and tolerances are untouched. All eight
trials complete with results and no timeout. Thus the failures below are
mathematical/census failures, not stale-hash failures.

| Real copied-source mutation | Passed / failed | Outcome |
|---|---:|---|
| Omit the new sV1 term in the potential producer | 5363 / 432 | Detected |
| Omit the u force in Einstein evolution | 5552 / 243 | Detected |
| Omit scalar exchange from G_N | 5507 / 288 | Detected |
| Add the incorrect fixed-s q derivative | 5555 / 240 | Detected |
| Drop all 18 excluded inverse targets | 5776 / 1 | Census detects omission |
| Force the u acceleration to zero | 5795 / 0 | Survives |
| Set partial_u K_u to zero | 5795 / 0 | Survives |
| Store Einstein masses as physical masses | 5795 / 0 | Survives |

The excluded-target mutant contains 5777 assertions because the 18 deleted
rows also remove their per-row output checks. Its lower total is preserved
rather than reported as a full 5795-check execution.

**R1 — general evolution and derivative coverage.** The exact histories have
u=p_u=0. Forcing u'' to zero therefore escapes their checks, and a wrong
partial_u K_u can disappear from the tested contractions. The independently
saved admitted finite-field controls reject the forced acceleration in all
360 states. They reject the zero metric derivative and resulting u RHS in
240 states, precisely the s>0 cases. The s=0 derivative is genuinely zero.
Add independent finite-field derivative and force controls with nonzero u
velocities, derived from the action/canonical momentum equation rather than
reusing the same producer contraction as the oracle.

**R2 — stored physical mass binding.** Dividing only the serialized mass values
by 1+s leaves every author assertion passing. The independent reference finds
144 incorrect entries, all three masses in the 48 s>0 rows. The underlying
mass calculations are still correct; the output no longer reports them.
Bind every stored mass row and physical frame factor with an independent
parameter-based oracle and complete row identity checks after construction.

These eight tests are selected for actual operators and claims in this block,
not to satisfy a route quota. They do not establish exhaustive corruption
resistance. All original unmodified field equations, derivatives, mass values
and retained inverse classifications agree independently.

## Preserved reviewer failure and disposition

The reviewer's first attempt chose constant coordinate velocities for all
off-trajectory states. At large s a transverse kinetic coefficient made
Kp^2=3.2827953332595854, outside the positive Friedmann chart. The actual author
function correctly raised `Invalid Friedmann chart` with negative H^2.
The first review source, launch, stdout and traceback are preserved unchanged.
There was no completed positive result from that aborted run.

The separate reviewer v2 scales p_i by 1/sqrt(K_i), giving exact norm .0146.
All fields, parameter tuples, densities and tolerances stay unchanged. This
is a reviewer fixture correction, not an author-source repair or a loosened
scientific acceptance threshold. It is recorded before the successful run.

The full independent method, replay recipe and units appear in
`INDEPENDENT_CALCULATION_NOTE_v1.md`. The successful result and saved reference
are `INDEPENDENT_RESULTS_v2.json` and
`INDEPENDENT_SCIENTIFIC_REFERENCE_v2.json`. `OFF_TRAJECTORY_CONTROLS_v2.json`
and `INDEPENDENT_ODE_HISTORY_v2.json` preserve the independent dynamical data.
All eight real trials and the subsequent saved-control survivor comparisons
are retained. No successful positive calculation needs to be rerun for an
affected-source repair check.

The numerical values are supported at this scope. Assertion readiness remains
pending R1 and R2. The original source, report and evidence must remain
immutable while the parent separately repairs them. This review changes no
author file, Git state, campaign deadline or model setting and makes no
global stability, boundary-selection, empirical acceptance or TOE claim.
