#!/usr/bin/env python3
"""Finalize source/evidence hashes only; performs no scientific reruns."""
from pathlib import Path
import datetime, hashlib, json, subprocess

A = Path(__file__).resolve().parent
O = A.parent
B = O.parent
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()

def load(p):
    return json.loads(Path(p).read_text())

def dump(name, obj):
    (A / name).write_text(json.dumps(obj, indent=2) + '\n')

def pin(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return {'path': str(p), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def verified(item):
    actual = pin(item['path'])
    assert actual['sha256'] == item['sha256'], (item, actual)
    return actual

freeze = load(A / 'SOURCE_FREEZE_v1.json')
pairs = []
for item in freeze['sources']:
    original = verified(item)
    snapshot = verified({'path': item['snapshot'], 'sha256': item['sha256']})
    pairs.append({'original': original, 'snapshot': snapshot,
                  'expected_sha256': item['sha256'], 'verified': True})
assert len(pairs) == 29

prior_receipt = verified({'path': str(O / 'FINAL_RECEIPT_v1.json'),
    'sha256': 'f29792f5bca5871a71cd7d829ae0fe2e997289cfc835251b9e488abafb07eebe'})
verified({'path': str(O / 'INDEPENDENT_NUMERICAL_REVIEW_v1.md'),
    'sha256': '45851522b7ee22bf96742c9fad592c13eb9f8665cb05f903e64af366146a75ec'})
prior = load(prior_receipt['path'])
prior_paths = {}
for item in prior['original_snapshot_pairs']:
    for role in ['original', 'snapshot']:
        row = verified(item[role]); prior_paths[row['path']] = row
for item in prior['review_artifacts']:
    row = verified(item); prior_paths[row['path']] = row
assert len(prior_paths) == 197

results = load(A / 'AFFECTED_RESULTS_v1.json')
assert results['counts'] == {'passed': 19083, 'failed': 0, 'total': 19083}
mutations = load(A / 'MUTATION_RESULTS_v1.json')['mutations']
mut_verify = load(A / 'MUTATION_EVIDENCE_VERIFICATION_v1.json')
assert mut_verify['all_verified'] and len(mutations) == 3
for item, failed in zip(mutations, [72, 48, 144]):
    assert item['counts']['failed'] == failed
    assert item['exit_code'] == 1 and not item['timeout']
    assert item['source_checks_count'] == 12 and item['all_source_checks_pass']
    assert item['inputs_unchanged']

owned = [load(A / 'MUTATION_PLAN_v1.json')['driver_pid']]
owned += [load(p)['pid'] for p in sorted((A / 'mutations').glob('*/LAUNCH.json'))]
process_rows = []
for pid in owned:
    check = subprocess.run(['ps', '-p', str(pid), '-o', 'pid=,ppid=,etime=,command='],
                           capture_output=True, text=True)
    process_rows.append({'pid': pid, 'returncode': check.returncode,
                         'stdout': check.stdout, 'stderr': check.stderr,
                         'absent': check.returncode == 1 and not check.stdout.strip()})
assert all(row['absent'] for row in process_rows), process_rows
dump('FINAL_PROCESS_CHECK_v1.json', {'at': NOW, 'scope': 'Only recorded reviewer-owned driver and three mutation PIDs; read-only ps, no signalling.',
     'processes': process_rows, 'all_owned_pids_absent': True,
     'independent_control_job': 'Completed exit 0, tool chunk 5023e1.',
     'mutation_driver_job': 'Completed exit 0, tool chunk 85aba5.',
     'saved_mutation_verification_job': 'Completed exit 0, tool chunk 5ec4f1.'})

dump('READING_LEDGER_v1.json', {'at': NOW, 'scope': 'Affected v2 source and scope clarification only.',
    'complete_changed_source_read': [str(B / n) for n in [
        'check_curvature_fluid_v2.py', 'OUTPUT_AND_GENERAL_EQUATIONS_v2.diff',
        'OUTPUT_AND_GENERAL_EQUATIONS_v2.json', 'OFF_TRAJECTORY_FIXTURES_v2.json',
        'SCIENTIFIC_OUTPUT_IDENTITY_v2.json', 'SCOPE_CLARIFICATION_v2.md']],
    'data_coverage': 'All v2 evidence objects, all 72 new general-state rows/components, all new mass assertions, all original 5786 non-source assertions, all three full failed mutation results and exact input freezes.',
    'prior_source_reuse': 'Unchanged action/derivation/observation lineage and successful original numerical calculations reused under immutable original receipt; all 197 unique identities rechecked. No original positive scientific rerun.',
    'new_oracle_method': '110-digit raw-action metric and potential derivatives plus explicit Christoffel contraction, compared to all stored expected and actual new components; previous independent Hessian values reused for mass controls.',
    'primary_material': 'No new external numerical input or new web reading in affected scope. Original primary-source reading ledger remains receipt-bound.',
    'failures': ['TOOL_READ_FAILURE_v1.json', 'RECEIPT_INSPECTION_FAILURE_v1.json'],
    'scope_limits': ['Finite supplied controls, not universal correctness.', 'No empirical acceptance, thermal transport or abundance likelihood.', 'No global constrained-boundary stability.', 'No formal audit, publication gate or landing authorization.']})

dump('EXECUTION_SUMMARY_v1.json', {'at': NOW, 'no_successful_science_rerun': True,
    'affected_check': {'script': 'verify_affected_v2.py', 'exit_code': 0, 'tool_chunk': '5023e1', 'counts': results['counts']},
    'mutations': [{k: x[k] for k in ['id','started_at','ended_at','seconds','exit_code','timeout','counts','source_checks_count','all_source_checks_pass','inputs_unchanged','source_sha256','result_sha256']} for x in mutations],
    'saved_evidence_check': {'script': 'verify_mutation_evidence_v1.py', 'exit_code': 0, 'tool_chunk': '5ec4f1', 'all_verified': True},
    'non_scientific_errors': ['TOOL_READ_FAILURE_v1.json', 'RECEIPT_INSPECTION_FAILURE_v1.json'],
    'prior_genuine_failure_preserved': 'Original reviewer non-chart velocity fixture, recorded in original immutable receipt. Not overwritten or rerun here.'})

receipt_path = A / 'FINAL_RECEIPT_v1.json'
assert not receipt_path.exists(), 'Refuse to overwrite an existing final receipt.'
artifacts = [pin(p) for p in sorted(A.rglob('*')) if p.is_file() and p != receipt_path]
unique = dict(prior_paths)
for pair in pairs:
    for role in ['original', 'snapshot']:
        row = pair[role]
        if row['path'] in unique: assert unique[row['path']]['sha256'] == row['sha256']
        unique[row['path']] = row
for row in artifacts:
    if row['path'] in unique: assert unique[row['path']]['sha256'] == row['sha256']
    unique[row['path']] = row
for row in unique.values(): verified(row)

receipt = {'schema': 'independent-affected-source-receipt-v1', 'at': NOW,
    'disposition': 'R1 general evolution/metric coverage and R2 stored physical-mass coverage closed for exact v2 and finite supplied controls; original scientific output unchanged.',
    'scope': 'Narrow independent affected numerical/source check. No formal audit or empirical/publication disposition.',
    'author_source': pin(B / 'check_curvature_fluid_v2.py'),
    'author_result': pin(B / 'evidence_v2/RESULTS.json'),
    'report': pin(A / 'AFFECTED_V2_REVIEW_v1.md'),
    'original_receipt': prior_receipt,
    'original_derivation': pin(O / 'INDEPENDENT_CALCULATION_NOTE_v1.md'),
    'new_method_source': pin(A / 'verify_affected_v2.py'),
    'independent_counts': results['counts'], 'category_counts': results['category_counts'],
    'preservation': {'original_non_main_functions': 12, 'original_non_source_assertions': 5786,
        'old_science_reused_passed': 32831, 'old_science_reused_failed': 0,
        'original_unique_paths': 197,
        'allowed_bookkeeping_only': 'symbolic.count 33 to 36, from three added input-hash checks; 24 original symbolic physics assertions unchanged.',
        'added_assertions': 865, 'fresh_source_checks': 12},
    'mutations': [{k: x[k] for k in ['id','exit_code','timeout','counts','source_checks_count','all_source_checks_pass','inputs_unchanged','source_sha256','result_sha256']} for x in mutations],
    'findings': [{'id':'R1','disposition':'closed within exact source/supplied finite-state scope','new_failures':[72,48]},
                 {'id':'R2','disposition':'closed within exact source/stored mass-grid scope','new_failures':144}],
    'failure_history': ['Two non-scientific file-discovery/path-inspection errors preserved and recovered.', 'Three intended mathematical mutation failures preserved with fresh hashes.', 'Original reviewer fixture failure and original surviving mutations remain immutable.'],
    'original_snapshot_pairs': pairs,
    'prior_receipt_bound_paths': sorted(prior_paths.values(), key=lambda x:x['path']),
    'review_artifacts': artifacts,
    'verification': {'unique_paths': len(unique), 'all_verified': True, 'all_owned_pids_absent': True},
    'self_reference': 'Receipt excludes its own bytes; final message supplies its SHA256.'}
dump('FINAL_RECEIPT_v1.json', receipt)
print(json.dumps({'report': pin(A / 'AFFECTED_V2_REVIEW_v1.md'), 'receipt': pin(receipt_path), 'unique_paths': len(unique)}, indent=2))
