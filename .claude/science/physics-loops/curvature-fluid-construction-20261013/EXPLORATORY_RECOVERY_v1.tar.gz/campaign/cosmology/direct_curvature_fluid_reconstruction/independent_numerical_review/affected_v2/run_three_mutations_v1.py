#!/usr/local/bin/python3
"""Actual scoped source corruptions with fresh complete input freezes."""
from pathlib import Path
import datetime as dt,difflib,hashlib,json,os,subprocess,sys,time
O=Path(__file__).resolve().parent;S=O/'snapshots'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
source=(S/'check_curvature_fluid_v2.py').read_text()
freeze=read(S/'evidence_v2/FROZEN_INPUTS.json')
snapshots={r['path']:Path(r['snapshot']) for r in read(O/'SOURCE_FREEZE_v1.json')['sources']}
mutations=[r for r in read(S/'independent_numerical_review/MUTATION_PLAN_v1.json')['mutations'] if r['id'] in ['m6_force_zero_u_acceleration','m7_zero_u_metric_derivative','m8_serialize_Einstein_masses']]
assert len(mutations)==3

save(O/'MUTATION_PLAN_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),driver_pid=os.getpid(),mutations=mutations,scope='Exactly three actual v1 survivors, repeated against frozen v2 with all12 fresh hashes. No assertion or tolerance edits.'))
results=[]
for mu in mutations:
    assert source.count(mu['old'])==1,mu['id']
    changed=source.replace(mu['old'],mu['new'],1)
    case=O/'mutations'/mu['id'];case.mkdir(parents=True)
    with (case/'MUTATION.diff').open('x') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen_v2',tofile=mu['id'])))
    inputs=[]
    for r in freeze['inputs']:
        original=Path(r['path']);snapshot=snapshots[str(original)]
        assert sha(snapshot)==r['sha256']
        dest=case/'sources'/original.parent.name/original.name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(changed.encode() if original.name=='check_curvature_fluid_v2.py' else snapshot.read_bytes())
        inputs.append(dict(path=str(dest),sha256=sha(dest),original_path=str(original),original_sha256=r['sha256']))
        if original.name=='check_curvature_fluid_v2.py':runner=dest
    save(case/'FROZEN_INPUTS.json',dict(inputs=inputs))
    start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
    command=[sys.executable,str(runner),'--freeze',str(case/'FROZEN_INPUTS.json'),'--out',str(case/'RESULTS.json')]
    with (case/'stdout.txt').open('x') as out,(case/'stderr.txt').open('x') as err:
        child=subprocess.Popen(command,stdout=out,stderr=err)
        save(case/'LAUNCH.json',dict(pid=child.pid,started_at=start,command=command))
        try:rc=child.wait(timeout=120);timeout=False
        except subprocess.TimeoutExpired:child.kill();rc=child.wait();timeout=True
    data=read(case/'RESULTS.json') if (case/'RESULTS.json').exists() else None
    sc=[r for r in data['checks'] if r['name'].startswith('source.')] if data else []
    rec=dict(id=mu['id'],started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),seconds=time.monotonic()-tic,exit_code=rc,timeout=timeout,has_result=data is not None,counts=data['counts'] if data else None,source_checks_count=len(sc),all_source_checks_pass=len(sc)==12 and all(r['passed'] for r in sc),inputs_unchanged=all(sha(Path(r['path']))==r['sha256'] for r in inputs),failed_checks=[r for r in data['checks'] if not r['passed']] if data else [],source_sha256=sha(runner),result_sha256=sha(case/'RESULTS.json') if data else None)
    save(case/'EXECUTION.json',rec);results.append(rec)
    print(json.dumps({k:rec[k] for k in ['id','exit_code','counts','all_source_checks_pass','timeout']}),flush=True)
    save(case/'COMPLETE.json',dict(complete=True))
save(O/'MUTATION_RESULTS_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),mutations=results))
