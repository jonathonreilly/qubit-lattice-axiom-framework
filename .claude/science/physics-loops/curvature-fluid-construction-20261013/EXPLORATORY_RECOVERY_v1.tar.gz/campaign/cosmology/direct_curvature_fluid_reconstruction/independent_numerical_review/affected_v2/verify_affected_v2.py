#!/usr/local/bin/python3
"""Affected-source continuity and new controls only; no original science rerun."""
from pathlib import Path
from fractions import Fraction as F
import ast,collections,datetime as dt,difflib,hashlib,itertools,json
import mpmath as mp
O=Path(__file__).resolve().parent;S=O/'snapshots';mp.mp.dps=110;C=[]
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def m(x):
    r=F(str(x));return mp.mpf(r.numerator)/r.denominator
def fmt(x):return mp.nstr(x,90)
def ck(name,p,**extra):C.append(dict(name=name,passed=bool(p),**extra))
def near(name,a,b,tol):
    a,b=m(a),m(b);e=abs(a-b)/max(1,abs(b));ck(name,e<=m(tol),actual=fmt(a),expected=fmt(b),normalized_error=fmt(e),tolerance=str(tol))
def leaves(a,b,p):
    if isinstance(a,dict):
        ck(p+'.keys',isinstance(b,dict) and list(a)==list(b))
        if isinstance(b,dict):
            for k in a:
                if k in b:leaves(a[k],b[k],p+'.'+k)
    elif isinstance(a,list):
        ck(p+'.length',isinstance(b,list) and len(a)==len(b))
        if isinstance(b,list):
            for i,(x,y) in enumerate(zip(a,b)):leaves(x,y,p+'.'+str(i))
    else:ck(p,a==b and type(a) is type(b))

freeze=read(O/'SOURCE_FREEZE_v1.json')
for r in freeze['sources']:ck('source.'+r['path'],sha(Path(r['path']))==r['sha256']==sha(Path(r['snapshot'])))
prior=read(S/'independent_numerical_review/FINAL_RECEIPT_v1.json');bound={}
for p in prior['original_snapshot_pairs']:
    for key in ['original','snapshot']:bound[p[key]['path']]=p[key]['sha256']
for r in prior['review_artifacts']:bound[r['path']]=r['sha256']
for p,h in bound.items():ck('prior_immutable.'+p,sha(Path(p))==h)

oldtext=(S/'check_curvature_fluid_v1.py').read_text();newtext=(S/'check_curvature_fluid_v2.py').read_text()
oldtree,newtree=ast.parse(oldtext),ast.parse(newtext)
oldfn={n.name:n for n in oldtree.body if isinstance(n,ast.FunctionDef)}
newfn={n.name:n for n in newtree.body if isinstance(n,ast.FunctionDef)}
functions=[]
for name,n in oldfn.items():
    if name=='main':continue
    text_equal=ast.get_source_segment(oldtext,n)==ast.get_source_segment(newtext,newfn[name])
    ast_equal=ast.dump(n,include_attributes=False)==ast.dump(newfn[name],include_attributes=False)
    ck('function.text.'+name,text_equal);ck('function.ast.'+name,ast_equal)
    functions.append(dict(name=name,text_identical=text_equal,ast_identical=ast_equal))
newtree.body=[n for n in newtree.body if not(isinstance(n,ast.FunctionDef) and n.name=='additional_general_equation_controls')]
newmain=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
removed=[];kept=[]
for n in newmain.body:
    if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='masses':removed.append('stored_mass_for')
    elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='additional_general_equation_controls':removed.append('general_control_call')
    else:kept.append(n)
newmain.body=kept
ck('source.only_added_controls',removed==['stored_mass_for','general_control_call'] and ast.dump(newtree,include_attributes=False)==ast.dump(oldtree,include_attributes=False))
diff=''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile='check_curvature_fluid_v1.py',tofile='check_curvature_fluid_v2.py'))
ck('source.saved_diff_exact',diff==(S/'OUTPUT_AND_GENERAL_EQUATIONS_v2.diff').read_text())

old=read(S/'evidence_v1/RESULTS.json');new=read(S/'evidence_v2/RESULTS.json')
sections=[]
for key in old:
    if key in ['checks','counts','symbolic']:continue
    aa=json.dumps(old[key],separators=(',',':')).encode();bb=json.dumps(new[key],separators=(',',':')).encode()
    ck('science.byte_identity.'+key,aa==bb);leaves(old[key],new[key],'science.'+key)
    sections.append(dict(name=key,identical=aa==bb,sha256=hashlib.sha256(aa).hexdigest(),bytes=len(aa)))
leaves({k:v for k,v in old['symbolic'].items() if k!='count'},{k:v for k,v in new['symbolic'].items() if k!='count'},'science.symbolic_physics')
ck('bookkeeping.symbolic_count',old['symbolic']['count']==33 and new['symbolic']['count']==36)
def original_check(r):return not r['name'].startswith(('source.','mass_output.','off_trajectory.')) and r['name']!='census.off_trajectory'
oldchecks=[r for r in old['checks'] if not r['name'].startswith('source.')]
newold=[r for r in new['checks'] if original_check(r)]
ck('assertions.original_census',len(oldchecks)==len(newold)==5786)
for i,(a,b) in enumerate(zip(oldchecks,newold)):ck('assertions.original.'+str(i),a==b)
af=read(S/'evidence_v2/FROZEN_INPUTS.json')
sourcechecks=[r for r in new['checks'] if r['name'].startswith('source.')]
ck('assertions.source_census',len(sourcechecks)==12 and {r['name'][7:] for r in sourcechecks}=={r['path'] for r in af['inputs']})
for r in af['inputs']:ck('freeze.'+r['path'],sha(Path(r['path']))==r['sha256'])
ck('assertions.counts',new['counts']==dict(passed=6663,failed=0,total=6663) and len(new['checks'])==6663 and all(r['passed'] is True for r in new['checks']))
checks={r['name']:r for r in new['checks']}
ck('assertions.names_unique',len(checks)==len(new['checks']))

# Changed mass controls compared against the earlier independent Hessian
# calculation, reusing its saved values rather than recomputing that science.
reference=read(S/'independent_numerical_review/INDEPENDENT_SCIENTIFIC_REFERENCE_v2.json')
for expected in reference['local_masses']:
    idx=expected['id'];row=new['local_masses'][idx]
    shape=checks[f'mass_output.{idx}.shape'];ck(f'mass.new_shape.{idx}',shape['passed'] and len(row['physical_mass_squared'])==3)
    for j,val in enumerate(expected['physical_mass_squared']):
        rec=checks[f'mass_output.{idx}.{j}']
        near(f'mass.expected.{idx}.{j}',rec['expected'],val,'1e-60')
        near(f'mass.actual.{idx}.{j}',rec['actual'],row['physical_mass_squared'][j],'1e-70')
        ck(f'mass.passed.{idx}.{j}',rec['passed'] is True and rec['tolerance']=='1e-65')

# Affected generic states: use numerical high-precision differentiation of
# the raw Z/F+Weyl action and an explicit connection contraction.  This route
# is independent of the new parent's symbolic momentum oracle.
def action(phi,pars):
    u,x,y=phi;a,b,s,nu=pars;alpha=mp.sqrt(a);E=mp.exp(2*alpha*u)
    F=1+s*E;Fu=2*alpha*s*E;D=1+mp.mpf(2)/3*(1+b)*(x*x+y*y)
    K=[(1-3*a*s*E)/F+mp.mpf(3)/4*(Fu/F)**2,(1+s)*4*b/(9*D*F),(1+s)*b/(3*D*F)]
    V0=mp.mpf(3)/2+(b/2-alpha*u+2*a*u*u/b)*x*x+b*y*y/3+nu*u*u/2
    V1=(b/2+alpha*b*u+2*a*u*u/b)*x*x+b*y*y/3
    U=(1+s)*(V0+s*V1+mp.mpf(3)/2*s*E**2)/F**2
    logB=alpha*u-mp.log(F)/2
    return K,U,logB
def independent_rhs(st,pars):
    pos=st[:3];pp=st[3:6];sm,sr=st[6:8];K,U,_=action(pos,pars)
    def moved(i,t):
        p=list(pos);p[i]=t;return action(p,pars)
    dk=[[mp.diff(lambda t:moved(i,t)[0][j],pos[i]) for j in range(3)] for i in range(3)]
    dU=[mp.diff(lambda t:moved(i,t)[1],pos[i]) for i in range(3)]
    alpha=mp.diff(lambda t:moved(0,t)[2],pos[0])
    norm=sum(K[i]*pp[i]**2 for i in range(3));H2=2*(U+sm+sr)/(3-norm)
    h=-(sm+mp.mpf(4)/3*sr)/H2-norm
    con=[]
    for i in range(3):
        total=mp.mpf(0)
        for j in range(3):
            for k in range(3):
                gamma=((dk[j][i] if i==k else 0)+(dk[k][i] if i==j else 0)-(dk[i][j] if j==k else 0))/(2*K[i])
                total+=gamma*pp[j]*pp[k]
        con.append(total)
    rhs=pp+[-(3+h)*pp[i]-con[i]-(dU[i]+(alpha*sm if i==0 else 0))/(K[i]*H2) for i in range(3)]+[(-3+alpha*pp[0])*sm,-4*sr]
    return rhs,norm,H2
fixtures=read(S/'OFF_TRAJECTORY_FIXTURES_v2.json');newcontrols=[]
for idx,values in enumerate(itertools.product(fixtures['a'],fixtures['b'],fixtures['s'],fixtures['nu'],fixtures['states'])):
    av,bv,sv,nv,state=values;pars=list(map(m,[av,bv,sv,nv]));st=list(map(m,state))
    wanted,norm,H2=independent_rhs(st,pars)
    ck(f'new_oracle.chart.{idx}',norm<3 and H2>0)
    for j,val in enumerate(wanted):
        rec=checks[f'off_trajectory.{idx}.{j}']
        near(f'new_oracle.expected.{idx}.{j}',rec['expected'],val,'2e-10')
        near(f'new_oracle.actual.{idx}.{j}',rec['actual'],val,'2e-10')
        ck(f'new_oracle.passed.{idx}.{j}',rec['passed'] and rec['normalized_error']<=fixtures['normalized_tolerance'])
    newcontrols.append(dict(id=idx,parameters=[str(v) for v in [av,bv,sv,nv]],state=state,kinetic_norm=fmt(norm),H_squared=fmt(H2),independent_rhs=list(map(fmt,wanted))))
ck('new_oracle.census',len(newcontrols)==72 and checks['census.off_trajectory']['passed'])
added=[r for r in new['checks'] if r['name'].startswith(('mass_output.','off_trajectory.')) or r['name']=='census.off_trajectory']
ck('assertions.added_census',len(added)==865 and sum(r['name'].startswith('mass_output.') for r in added)==288 and sum(r['name'].startswith('off_trajectory.') for r in added)==576)
save(O/'INDEPENDENT_NEW_CONTROL_REFERENCE_v1.json',dict(route='Raw-action high-precision derivatives and explicit Christoffel contraction; no author helper imported.',cases=newcontrols))
summary=dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),scope='Affected v2 additions and identity only. No original positive grid or history rerun.',source_sha256=sha(S/'check_curvature_fluid_v2.py'),author_result_sha256=sha(S/'evidence_v2/RESULTS.json'),old_functions=functions,identical_sections=sections,original_non_source_assertions=len(oldchecks),added_assertions=len(added),source_checks=len(sourcechecks),prior_receipt_unique_paths=len(bound),counts=dict(passed=sum(r['passed'] for r in C),failed=sum(not r['passed'] for r in C),total=len(C)),category_counts=dict(collections.Counter(r['name'].split('.')[0] for r in C)),checks=C)
save(O/'AFFECTED_RESULTS_v1.json',summary)
print(json.dumps({k:summary[k] for k in ['original_non_source_assertions','added_assertions','source_checks','prior_receipt_unique_paths','counts']},indent=2))
raise SystemExit(int(summary['counts']['failed']!=0))
