#!/usr/local/bin/python3
"""Verify saved executions and exact substitutions; no reruns."""
from pathlib import Path
import datetime as dt,hashlib,json
O=Path(__file__).resolve().parent;S=O/'snapshots'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
plan=read(O/'MUTATION_PLAN_v1.json');source=(S/'check_curvature_fluid_v2.py').read_text();records=[]
for mu in plan['mutations']:
    p=O/'mutations'/mu['id'];freeze=read(p/'FROZEN_INPUTS.json');result=read(p/'RESULTS.json');run=read(p/'EXECUTION.json')
    changed=p/'sources/direct_curvature_fluid_reconstruction/check_curvature_fluid_v2.py'
    assert changed.read_text()==source.replace(mu['old'],mu['new'],1)
    sourcechecks=[r for r in result['checks'] if r['name'].startswith('source.')]
    failures=[r for r in result['checks'] if not r['passed']]
    old=[r for r in result['checks'] if not r['name'].startswith(('source.','mass_output.','off_trajectory.')) and r['name']!='census.off_trajectory']
    assert len(freeze['inputs'])==len(sourcechecks)==12 and all(r['passed'] for r in sourcechecks)
    assert all(sha(Path(r['path']))==r['sha256'] for r in freeze['inputs'])
    assert len(old)==5786 and all(r['passed'] for r in old)
    assert run['exit_code']==1 and not run['timeout'] and (p/'stderr.txt').stat().st_size==0
    if mu['id']=='m6_force_zero_u_acceleration':
        assert len(failures)==72 and all(r['name'].startswith('off_trajectory.') and r['name'].endswith('.3') for r in failures)
    elif mu['id']=='m7_zero_u_metric_derivative':
        assert len(failures)==48 and all(r['name'].startswith('off_trajectory.') and r['name'].endswith('.3') for r in failures)
    else:
        assert len(failures)==144 and all(r['name'].startswith('mass_output.') for r in failures)
    records.append(dict(id=mu['id'],counts=result['counts'],fresh_source_checks=12,all_source_hashes_pass=True,old_non_source_assertions_still_pass=5786,mathematical_failure_names=[r['name'] for r in failures],source_sha256=sha(changed),result_sha256=sha(p/'RESULTS.json'),stderr_empty=True))
save(O/'MUTATION_EVIDENCE_VERIFICATION_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),all_verified=True,mutations=records))
print(json.dumps(dict(all_verified=True,mutants=len(records))))
