#!/usr/local/bin/python3
"""Bind completed original review, including all actual failures and copies."""
from pathlib import Path
import collections,datetime as dt,hashlib,json,subprocess
O=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def item(p):return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
freeze=read(O/'SOURCE_FREEZE_v1.json');result=read(O/'INDEPENDENT_RESULTS_v2.json')
for r in freeze['sources']:assert sha(Path(r['path']))==r['sha256']==sha(Path(r['snapshot']))
save(O/'READING_LEDGER_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),local=[
dict(source='HAND_DERIVATION_v1.md, PROTOCOL_v1.json, SOURCE_LEDGER_v1.json, NUMERICAL_FIXTURES_v1.json, check_curvature_fluid_v1.py',scope='Read complete new handwritten statement, explicit premises, implementation and inputs before independent execution; all exact bytes snapshotted.'),
dict(source='All evidence_v1 files',scope='Complete freeze/launch-execution information, stdout/stderr, full result parsed; every scientific section/row and all5795 assertion records inspected.'),
dict(source='Inherited direct_analytic_fluid_completion/HAND_DERIVATION_v2.md',scope='Read complete current note; focus on canonical field normalization, gradient-flow orbit, full ideal-fluid equations and original convergence theorem boundary.'),
dict(source='Inherited direct_induced_curvature_completion/HAND_DERIVATION_v1.md',scope='Current sections1–4 reread through line150; original action/frame/form premise and stationary clock conventions. Same full source already checked in prior numerical review; its other vacuum branches are not recalculated here.'),
dict(source='Inherited direct_weak_field_inverse/HAND_DERIVATION_v2.md and OBSERVATION_INPUTS_v1.json',scope='Handwritten note read completely, exact unchanged observation inputs carried forward from immediately previous complete review. Supplied local PPN bridge and historical exposure only.'),
dict(source='Reviewer scripts, failed v1 run, corrected v2 run and eight mutation cases',scope='Full local source/evidence, actual process outcomes, fresh nine-input freezes, actual wrong-source outputs and saved-control survivor comparisons.')],primary=[
dict(url='https://arxiv.org/pdf/1912.01132v1',identity='Fields, Olive, Yeh and Young; arXiv1912.01132v1, 2019',scope='Introduction through standard-BBN assumptions, Eqs1–2 and relevant context. No abundance/likelihood result used.',outcome='successful web PDF text read',raw_bytes_saved=False),
dict(url='https://arxiv.org/pdf/1801.08023v3',identity='Pitrou et al.; current unversioned URL returned v3, 6 February2025',scope='Entropy/LTE context and Eqs20–32; instantaneous decoupling; sectionsII.F–G context and Eqs63–66. No corrected Neff value used.',outcome='successful web PDF text read; exact returned version explicitly identified',raw_bytes_saved=False),
dict(url='https://arxiv.org/pdf/gr-qc/9602056v1',scope='No fresh reading in this block; exact prior weak-field source/reading scope carried forward. No new PPN apparatus derivation.',raw_bytes_saved=False)],new_retrieval_failures=[],parent_reported_failure='Parent ledger records an IAP PDF reopen Internal Error; it is retained as parent history and was not repeated or represented as a reviewer failure.',empirical_tests=0,author_edits=False,git_actions=False,formal_audit=False))
save(O/'EXECUTION_SUMMARY_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),original_independent_attempt=dict(source='independent_recompute_v1.py',exit_code=1,completion_chunk='e6e775',disposition='Reviewer fixture left Friedmann chart; author rejection correct; source/traceback preserved.'),successful_independent_attempt=dict(source='independent_recompute_v2.py',exit_code=0,completion_chunk='8fff15',counts=result['counts']),mutation_driver=dict(source='run_mutations_v1.py',exit_code=0,completion_chunk='65a14d',trials=8),survivor_comparison=dict(source='verify_survivors_v1.py',exit_code=0,completion_chunk='f555f2',recomputed_positive_science=False),author_failure='No failed author execution recorded in provided evidence_v1.',future_v2='Parent announced separate source repair while original review was finalizing; no repaired source is read or covered by this receipt.'))
pids=[read(O/'MUTATION_PLAN_v1.json')['driver_pid']]
pids += [read(p)['pid'] for p in (O/'mutations').glob('*/LAUNCH.json')]
pids += [read(O/x)['pid'] for x in ['INDEPENDENT_LAUNCH_v1.json','INDEPENDENT_LAUNCH_v2.json']]
ps=subprocess.run(['ps','-p',','.join(map(str,pids)),'-o','pid=,ppid=,lstart=,command='],capture_output=True,text=True)
assert not ps.stdout.strip(),ps.stdout
save(O/'FINAL_PROCESS_CHECK_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),owned_pids=pids,ps_exit_code=ps.returncode,stdout=ps.stdout,stderr=ps.stderr,all_owned_pids_absent=True))
artifacts=[item(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='FINAL_RECEIPT_v1.json']
pairs=[dict(original=item(Path(r['path'])),snapshot=item(Path(r['snapshot'])),expected_sha256=r['sha256'],verified=True) for r in freeze['sources']]
bound={r['path']:r['sha256'] for r in artifacts}
for r in pairs:
    for kind in ['original','snapshot']:bound[r[kind]['path']]=r[kind]['sha256']
assert all(sha(Path(p))==h for p,h in bound.items())
muts=read(O/'MUTATION_RESULTS_v1.json')['mutations']
receipt=dict(schema='independent-numerical-source-receipt-v1',at=dt.datetime.now(dt.timezone.utc).isoformat(),disposition='Original v1 numerical values supported on frozen grid; assertion coverage requires R1 general evolution/metric controls and R2 stored physical-mass binding.',scope='Focused implementation/numerical review, no formal audit/publication gate/empirical fit.',author_source=item(O.parent/'check_curvature_fluid_v1.py'),author_result=item(O.parent/'evidence_v1/RESULTS.json'),report=item(O/'INDEPENDENT_NUMERICAL_REVIEW_v1.md'),derivation=item(O/'INDEPENDENT_CALCULATION_NOTE_v1.md'),independent_counts=result['counts'],category_counts=dict(collections.Counter(r['name'].split('.')[0] for r in result['checks'])),mutations=[{k:r[k] for k in ['id','counts','exit_code','timeout','has_result','all_source_checks_pass','inputs_unchanged','source_sha256','result_sha256']} for r in muts],findings=[dict(id='R1',status='requires_correction',description='Forced zero u acceleration and zero partial_u K_u each survive5795/0. Independent saved controls reject360 and240 states respectively.'),dict(id='R2',status='requires_correction',description='Wrong-frame stored masses survive5795/0 and corrupt144 values. Original stored values independently correct.')],failure_history=['First independent run aborted from inadmissible reviewer coordinate-velocity fixture; source and traceback preserved.','Separately declared v2 uses exact norm.0146 and succeeds32831/0; no tolerance or author change.','Five actual mutants fail author assertions; three survive. All nine fresh hashes pass and every raw result is preserved.'],original_snapshot_pairs=pairs,review_artifacts=artifacts,verification=dict(unique_paths=len(bound),all_verified=True,all_owned_pids_absent=True),primary_scope='Relevant exact-version primary URLs and reading scope in READING_LEDGER_v1.json; remote raw bytes not downloaded or hash-pinned.',self_reference='This receipt excludes its own bytes. All other review artifacts and current/source snapshot identities are bound.')
save(O/'FINAL_RECEIPT_v1.json',receipt)
print(json.dumps(dict(report=item(O/'INDEPENDENT_NUMERICAL_REVIEW_v1.md'),receipt=item(O/'FINAL_RECEIPT_v1.json'),unique_bound_paths=len(bound)),indent=2))
