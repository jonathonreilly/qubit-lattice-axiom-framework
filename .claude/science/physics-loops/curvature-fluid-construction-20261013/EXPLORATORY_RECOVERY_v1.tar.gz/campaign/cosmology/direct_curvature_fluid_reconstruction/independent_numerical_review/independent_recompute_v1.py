#!/usr/local/bin/python3
"""Independent action, complete frozen output, finite-field and momentum checks.

The two extracted author functions are units under test, never value oracles.
All expected functions are differentiated from the unreduced field action.
"""
from pathlib import Path
from fractions import Fraction as F
import ast,datetime as dt,hashlib,itertools,json,os,platform,time
import mpmath as mp
import numpy as np
import scipy
from scipy.integrate import solve_ivp
import sympy as sp
O=Path(__file__).resolve().parent;S=O/'snapshots';mp.mp.dps=110
C=[];start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
def read(p):return json.loads(p.read_text())
def save(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def m(x):
    if isinstance(x,mp.mpf):return x
    r=F(str(x));return mp.mpf(r.numerator)/r.denominator
def fmt(x):return mp.nstr(x,95)
def ck(name,passed,**detail):C.append(dict(name=name,passed=bool(passed),**detail))
def near(name,actual,expected,tol='1e-60',scale=None):
    aa,bb=m(actual),m(expected)
    dd=max(mp.mpf(1),abs(bb)) if scale is None else m(scale)
    err=abs(aa-bb)/dd
    ck(name,err<=m(tol),actual=fmt(aa),expected=fmt(bb),normalized_error=fmt(err),tolerance=str(tol))
def compare(actual,expected,path):
    if isinstance(expected,dict):
        ck(path+'.keys',isinstance(actual,dict) and set(actual)==set(expected))
        if isinstance(actual,dict):
            for key in expected:
                if key in actual:compare(actual[key],expected[key],path+'.'+key)
    elif isinstance(expected,list):
        ck(path+'.length',isinstance(actual,list) and len(actual)==len(expected))
        if isinstance(actual,list):
            for i,(aa,bb) in enumerate(zip(actual,expected)):compare(aa,bb,path+'.'+str(i))
    elif isinstance(expected,mp.mpf):near(path,actual,expected)
    else:ck(path,actual==expected and type(actual) is type(expected))
def encode(x):
    if isinstance(x,mp.mpf):return fmt(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,list):return [encode(v) for v in x]
    return x

fix=read(S/'NUMERICAL_FIXTURES_v1.json');data=read(S/'evidence_v1/RESULTS.json')
freeze=read(O/'SOURCE_FREEZE_v1.json')
for row in freeze['sources']:ck('source.'+row['path'],sha(Path(row['path']))==row['sha256']==sha(Path(row['snapshot'])))
save(O/'INDEPENDENT_LAUNCH_v1.json',dict(pid=os.getpid(),started_at=start,source_sha256=sha(Path(__file__)),author_source_sha256=sha(S/'check_curvature_fluid_v1.py')))

# Obtain the Einstein metric from Z/F plus its Weyl derivative, with the
# unreduced coefficients assembled before fixing q.  Hv=1 is a unit choice.
u,x,y,a,b,s,nu,q,zet=sp.symbols('u x y a b s nu q zeta',real=True)
coords=[u,x,y];al=sp.sqrt(a);E=sp.exp(2*al*u)
D=1+sp.Rational(2,3)*(1+b)*(x*x+y*y)
kb=[sp.Integer(1),4*b/(9*D),b/(3*D)]
v0=sp.Rational(3,2)+(b/2-al*u+2*a*u*u/b)*x*x+b*y*y/3+nu*u*u/2
v1=(b/2+al*b*u+2*a*u*u/b)*x*x+b*y*y/3
Fraw=q+zet*E;Z=[q-3*a*zet*E,(q+zet)*kb[1],(q+zet)*kb[2]]
metric=[]
for i in range(3):
    raw=Z[i]/Fraw+sp.Rational(3,4)*(sp.diff(Fraw,coords[i])/Fraw)**2
    metric.append(sp.factor(raw.subs(zet,s*q)))
ff=1+s*E;W=v0+s*v1+sp.Rational(3,2)*s*E**2
potential=(1+s)*W/ff**2
dk=[[sp.diff(metric[j],coords[i]) for j in range(3)] for i in range(3)]
gradient=[sp.diff(potential,c) for c in coords]
hessian=[[sp.diff(potential,ci,cj) for cj in coords] for ci in coords]
coupling=sp.simplify(sp.diff(sp.log(sp.exp(al*u)/sp.sqrt(ff)),u))
expr=[metric,dk,potential,gradient,coupling,v0,v1,W,ff,D,hessian,sp.diff(W,u),sp.diff(v1,u)]
args=(u,x,y,a,b,s,nu)
field_mp=sp.lambdify(args,expr,'mpmath',cse=True)
field_np=sp.lambdify(args,expr[:5],'numpy',cse=True)

Q=sp.symbols('Q_u Q_x Q_y');R=sp.Symbol('R')
L0=R/2-sum(kb[i]*Q[i] for i in range(3))-2*v0
L1=E*R/2+3*a*E*Q[0]-kb[1]*Q[1]-kb[2]*Q[2]-2*v1
bulk=q*L0+zet*L1
ck('action.original_q_derivative',sp.simplify(sp.diff(bulk,q)-L0)==0)
ck('action.wrong_fixed_s_derivative',sp.simplify(sp.diff(bulk.subs(zet,s*q),q)-L0-s*L1)==0)
ck('action.recovered_old_potential',sp.simplify(v0.subs(b,a)-(sp.Rational(3,2)+(a/2-al*u+2*u*u)*x*x+a*y*y/3+nu*u*u/2))==0)
fc=sp.diff(W,x,2)/2
Ac=sp.diff(fc,u,2)/2;Bc=sp.diff(fc,u).subs(u,0);Cc=fc.subs(u,0)
ck('action.positive_discriminant',sp.factor(4*Ac*Cc-Bc**2-a*(3+(2-b)*s)*(1+(2+b)*s))==0)
fc_coeff=sp.lambdify((a,b,s),(Ac,Bc,Cc),'mpmath')

def momentum_response(fields,p,sm,sr):
    K,der,U,g,alpha=fields[:5]
    kinetic=sum(K[i]*p[i]**2 for i in range(3))
    H2=2*(U+sm+sr)/(3-kinetic);H=mp.sqrt(H2)
    vel=[H*r for r in p];pi=[K[i]*vel[i] for i in range(3)]
    # Proper-time canonical covariant momentum equation, then transform to p.
    pi_dot=[-3*H*pi[i]+sum(der[i][j]*vel[j]**2 for j in range(3))/2-g[i]-(alpha*sm if i==0 else 0) for i in range(3)]
    v_dot=[(pi_dot[i]-vel[i]*sum(der[j][i]*vel[j] for j in range(3)))/K[i] for i in range(3)]
    Hdot=-(sm+mp.mpf(4)/3*sr)-sum(K[i]*vel[i]**2 for i in range(3))
    response=list(p)+[v_dot[i]/H2-p[i]*Hdot/H2 for i in range(3)]+[(-3+alpha*p[0])*sm,-4*sr]
    return response,H2

# Load only actual implementation units to compare with the independent action.
source=(S/'check_curvature_fluid_v1.py').read_text();tree=ast.parse(source)
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['full_einstein_functions','full_n_rhs']]
assert len(nodes)==2
uut={'np':np}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'frozen_author_units_under_test','exec'),uut)

ref={k:[] for k in ['orbit','omissions','local_masses','positivity','null_families','inverse_targets']}
off=[];parameters=list(itertools.product(fix['a'],fix['b'],fix['s'],fix['nu']))
for idx,labels in enumerate(parameters):
    av,bv,sv,nv=map(m,labels);alv=mp.sqrt(av)
    vac=field_mp(0,0,0,av,bv,sv,nv)
    mm=[vac[10][i][i]/vac[0][i] for i in range(3)]
    for i in range(3):near(f'vacuum.stationary.{idx}.{i}',vac[3][i],0)
    ref['local_masses'].append(dict(id=idx,a=labels[0],b=labels[1],s=labels[2],nu=labels[3],physical_mass_squared=mm))
    ac,bc,cc=fc_coeff(av,bv,sv);umin=-bc/(2*ac);fmin=cc-bc*bc/(4*ac)
    ck(f'positive.minimum.{idx}',fmin>0)
    ref['positivity'].append(dict(id=idx,u_min=umin,minimum=fmin,restoring_coefficient=2*av/bv))
    for jdx,(xl,yl) in enumerate(fix['xy']):
        xv,yv=m(xl),m(yl);fields=field_mp(0,xv,yv,av,bv,sv,nv)
        pp=[mp.mpf(0),-mp.mpf(3)*xv/2,-2*yv]
        rhs,H2=momentum_response(fields,pp,xv*xv,yv*yv)
        target=pp+[mp.mpf(0),mp.mpf(9)*xv/4,4*yv,-3*xv*xv,-4*yv*yv]
        for i in range(8):near(f'orbit.full_rhs.{idx}.{jdx}.{i}',rhs[i],target[i])
        near(f'orbit.energy_H.{idx}.{jdx}',H2,fields[9])
        # Frame on u=0: H/Hv = Hhat/Hhat_v; original q is set to one.
        rm=2*(1+sv)*xv*xv;rr=2*(1+sv)*yv*yv
        T=fields[0][1]*H2*pp[1]**2+fields[0][2]*H2*pp[2]**2
        Hdot=-H2*sum(fields[0][i]*pp[i]**2 for i in range(3))-(xv*xv+mp.mpf(4)/3*yv*yv)
        Ricci=6*(2*H2+Hdot)
        L=Ricci/2+T-2*fields[5]
        wrong=sv*(Ricci/2+T-2*fields[6])
        k=av/(1+(1-3*av)*sv);S2=(H2-1)*3/(2*(xv*xv+yv*yv)*(1+k)) if xv*xv+yv*yv else (1+bv)/(1+k)
        fr=3*(1+sv)*H2-rm-rr-(1+sv)*T-2*fields[7]
        ray=-2*(1+sv)*Hdot-rm-mp.mpf(4)/3*rr-2*(1+sv)*T
        ur=-2*fields[11]+alv*sv*Ricci-alv*rm
        ref['orbit'].append(dict(parameter_id=idx,xy_id=jdx,H_squared=H2,rho_m=rm,rho_r=rr,L0=L,S_squared=S2,wrong_fixed_s_q_constraint_addition=wrong,full_residuals=[fr,ray,ur]))
        omfr=sv*T+2*sv*fields[6];omu=2*sv*fields[12]
        ref['omissions'].append(dict(parameter_id=idx,xy_id=jdx,friedmann_without_extra_operators=omfr,u_without_extra_operators=omu,expected_nonzero_metric=bool(sv>0 and xv*xv+yv*yv>0),expected_nonzero_u=bool(sv>0 and xv!=0)))
    for ui,ul in enumerate(fix['positivity_u']):
        phi=list(map(m,[ul,'0.3','0.5']));fields=field_mp(*phi,av,bv,sv,nv)
        K,der,U,grad,alpha=fields[:5]
        params=list(map(float,[av,bv,sv,nv]));af=uut['full_einstein_functions'](np.array(list(map(float,phi))),*params)
        tag=f'finite_field.{idx}.{ui}'
        ck(tag+'.positive_metric',all(k>0 for k in K))
        for j in range(3):
            near(tag+'.K.'+str(j),float(af[0][j]),K[j],'2e-11',scale=abs(K[j]))
            near(tag+'.grad.'+str(j),float(af[3][j]),grad[j],'2e-11',scale=max(1,abs(U),abs(grad[j])))
            for i in range(3):near(tag+f'.dK.{i}.{j}',float(af[1][i,j]),der[i][j],'2e-11',scale=max(abs(K[j]),abs(der[i][j])))
        near(tag+'.U',float(af[2]),U,'2e-11')
        near(tag+'.alpha',float(af[4]),alpha,'2e-11',scale=abs(alpha))
        pp=list(map(m,['.11','.03','-.04']));sm,sr=m('.4'),m('.7')
        erhs,H2=momentum_response(fields,pp,sm,sr)
        state=np.array(list(map(float,phi+pp+[sm,sr])))
        arhs=uut['full_n_rhs'](0.,state,*params)
        for j in range(8):near(tag+'.rhs.'+str(j),float(arhs[j]),erhs[j],'2e-11')
        off.append(dict(parameter_id=idx,u_index=ui,labels=list(labels),phi=list(map(fmt,phi)),p=list(map(fmt,pp)),sm=fmt(sm),sr=fmt(sr),K=list(map(fmt,K)),dK=[[fmt(v) for v in row] for row in der],U=fmt(U),grad=list(map(fmt,grad)),alpha=fmt(alpha),rhs=list(map(fmt,erhs)),actual_rhs=list(map(float,arhs))))
    if idx%12==0:print(json.dumps(dict(stage='parameter_grid',completed=idx+1,total=len(parameters))),flush=True)

# Independent exact inverse and thermal density calibration.
Tnu=(m(2)/(2+m(7)/8*4))**(mp.mpf(1)/3)
cn=(mp.mpf(7)/8)*Tnu**4
for kl in fix['null_k']:
    k=F(kl);aa=(1-k)*(1+3*k)/4;ss=(1+k)/(k*(1-3*k))
    for mode,bb in [('equal',aa),('split',k)]:
        J=1+(1-3*aa)*ss;kn=aa/J
        beta=-aa*(1-3*aa)*ss*(1+ss)/J**2
        dg=-2*kn/(1+kn);db=beta*kn/(2*(1+kn)**2)
        S2=(1+bb)/(1+kn)
        response=dict(k=kn,beta_D=beta,delta_gamma=dg,delta_beta=db,eta=4*db-dg,S_squared=S2,restoring_coefficient=2*aa/bb)
        # Count each relativistic helicity directly; supplied Nbase=3.
        gpre=F(2)+F(7,8)*(4+2*F(fix['thermal_N_base']))
        pre=(S2-1)*gpre/(F(7,8)*2)
        total_post=1+cn*m(fix['thermal_N_base'])
        post=(m(S2)*total_post-1)/cn-m(fix['thermal_N_base'])
        ref['null_families'].append(dict(k=str(k),a=str(aa),s=str(ss),b=str(bb),mode=mode,response={key:str(v) for key,v in response.items()},S=mp.sqrt(m(S2)),Delta_N_pre=str(pre),Delta_N_post=post))
    for st in fix['target_S_squared']:
        bb=F(st)*(1+k)-1
        status='admitted' if bb>0 and 3*bb<1 else 'excluded'
        ref['inverse_targets'].append(dict(k=str(k),target_S_squared=st,b=str(bb),status=status))
ref['thermal_constants']=dict(c_nu=cn,N_base=fix['thermal_N_base'])
for key,val in ref.items():compare(data[key],val,'output.'+key)
save(O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json',encode(ref))
save(O/'OFF_TRAJECTORY_CONTROLS_v1.json',dict(cases=off,units_under_test=['full_einstein_functions','full_n_rhs'],expected_route='Symbolic unreduced Z/F+Weyl action followed by proper-time covariant-momentum response.',count=len(off)))

# A distinct state variable and energy form avoid the author's p-equation
# Christoffel contraction and its Friedmann denominator in the integrator.
ind_ode=[]
for config,record in zip(fix['ode'],data['ode']):
    if 'null_k' in config:
        kr=F(str(config['null_k']));aa=(1-kr)*(1+3*kr)/4;ss=(1+kr)/(kr*(1-3*kr))
    else:aa=config['a'];ss=config['s']
    pars=list(map(float,[aa,config['b'],ss,config['nu']]))
    x0,y0=config['x0'],config['y0'];phi0=np.array([0.,x0,y0]);p0=np.array([0.,-1.5*x0,-2*y0])
    K0=np.asarray(field_np(*phi0,*pars)[0],dtype=float)
    H0=np.sqrt(1+2*(1+pars[1])*(x0*x0+y0*y0)/3)
    initial=np.r_[phi0,K0*H0*p0,x0*x0,y0*y0]
    def ham_rhs(n,z):
        ph,pi=z[:3],z[3:6];sm,sr=z[6:8]
        raw=field_np(*ph,*pars);K=np.asarray(raw[0],float);der=np.asarray(raw[1],float);U=float(raw[2]);grad=np.asarray(raw[3],float);alpha=float(raw[4])
        vel=pi/K;H=np.sqrt((np.dot(pi,vel)+2*(U+sm+sr))/3)
        dpi=np.array([-3*pi[i]+(sum(der[i,j]*vel[j]**2 for j in range(3))/2-grad[i]-(alpha*sm if i==0 else 0))/H for i in range(3)])
        return np.r_[vel/H,dpi,(-3+alpha*vel[0]/H)*sm,-4*sr]
    ns=np.linspace(0,config['N_end'],fix['ode_samples'])
    sol=solve_ivp(ham_rhs,(0,config['N_end']),initial,method='DOP853',rtol=2e-12,atol=2e-14,max_step=.02,t_eval=ns)
    ck('ode.'+config['id']+'.success',sol.success,message=sol.message)
    ck('ode.'+config['id']+'.census',sol.y.shape==(8,41) and len(record['samples'])==41)
    for key,expected in zip(['a','b','s','nu'],pars):near('ode.'+config['id']+'.parameter.'+key,record[key],expected,'1e-14')
    ck('ode.'+config['id']+'.id',record['id']==config['id'])
    ck('ode.'+config['id']+'.metadata',record['success'] is True and type(record['nfev']) is int and record['nfev']>0 and type(record['njev']) is int and record['njev']>=0)
    samples=[];parent_errors=[];own_errors=[]
    for j,n in enumerate(ns):
        z=sol.y[:,j];raw=field_np(*z[:3],*pars);K=np.asarray(raw[0],float);U=float(raw[2]);vel=z[3:6]/K;H=np.sqrt((np.dot(z[3:6],vel)+2*(U+z[6]+z[7]))/3)
        state=np.r_[z[:3],vel/H,z[6:8]]
        xx=x0*np.exp(-1.5*n);yy=y0*np.exp(-2*n)
        ideal=np.array([0,xx,yy,0,-1.5*xx,-2*yy,xx*xx,yy*yy])
        own_error=float(np.max(np.abs(state-ideal)/np.maximum(1,np.abs(ideal))))
        own_errors.append(own_error);ck(f'ode.{config["id"]}.{j}.own_tracking',own_error<5e-9,normalized_error=own_error)
        parent=np.array(record['samples'][j]['state'])
        parent_errors.append(float(np.max(np.abs(parent-ideal)/np.maximum(1,np.abs(ideal)))))
        near(f'ode.{config["id"]}.{j}.N',record['samples'][j]['N'],n,'1e-14')
        for i in range(8):near(f'ode.{config["id"]}.{j}.state.{i}',parent[i],state[i],'5e-8')
        samples.append(dict(N=float(n),state=state.tolist(),covariant_momenta=z[3:6].tolist(),H_squared=float(H*H),own_tracking_error=own_error))
    near('ode.'+config['id']+'.stored_max_tracking',record['max_tracking_error'],max(parent_errors),'1e-15')
    ind_ode.append(dict(id=config['id'],success=sol.success,nfev=sol.nfev,max_own_tracking=max(own_errors),max_parent_tracking=max(parent_errors),samples=samples))
    print(json.dumps(dict(stage='independent_momentum_ode',id=config['id'],max_own_tracking=max(own_errors))),flush=True)
save(O/'INDEPENDENT_ODE_HISTORY_v1.json',dict(method='Canonical covariant momenta in Einstein N, energy-constraint H, DOP853; no author function calls.',histories=ind_ode))

# Inspect all stored author assertions, without treating their PASS as science.
ck('assertions.counts',data['counts']==dict(passed=5795,failed=0,total=5795))
ck('assertions.census',len(data['checks'])==5795 and len({r['name'] for r in data['checks']})==5795)
for row in data['checks']:
    ck('assertions.passed.'+row['name'],row['passed'] is True)
    if 'actual' in row and 'expected' in row:
        err=abs(m(row['actual'])-m(row['expected']))/max(1,abs(m(row['expected'])))
        ck('assertions.numeric.'+row['name'],err<=m(row['tolerance']) and m(row['normalized_error'])<=m(row['tolerance']))
    if row['name'].startswith('symbolic.'):ck('assertions.symbolic.'+row['name'],row['reduced']=='0')
symbolic_rows=[r for r in data['checks'] if r['name'].startswith('symbolic.')]
ck('symbolic.count_scope',data['symbolic']['count']==len(symbolic_rows)+9 and len(symbolic_rows)==24)
symbols={str(v):v for v in [a,b,s,q,x,y,u,R]};symbols['hv']=sp.Symbol('hv')
symfr=sp.sympify(data['symbolic']['omitted_friedmann'],locals=symbols)
symu=sp.sympify(data['symbolic']['omitted_u'],locals=symbols)
ck('symbolic.stored_omitted_friedmann',sp.simplify(symfr-2*b*s*q*symbols['hv']**2*(x*x+y*y))==0)
ck('symbolic.stored_omitted_u',sp.simplify(symu-2*sp.sqrt(a)*b*s*q*symbols['hv']**2*x*x)==0)
for row in freeze['sources']:ck('final_source.'+row['path'],sha(Path(row['path']))==row['sha256'])
result=dict(started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),seconds=time.monotonic()-tic,source_sha256=sha(Path(__file__)),author_source_sha256=sha(S/'check_curvature_fluid_v1.py'),author_result_sha256=sha(S/'evidence_v1/RESULTS.json'),counts=dict(passed=sum(r['passed'] for r in C),failed=sum(not r['passed'] for r in C),total=len(C)),checks=C,versions=dict(python=platform.python_version(),mpmath=mp.__version__,sympy=sp.__version__,numpy=np.__version__,scipy=scipy.__version__),empirical_tests=0)
save(O/'INDEPENDENT_RESULTS_v1.json',result)
print(json.dumps(dict(stage='complete',counts=result['counts'],seconds=result['seconds'])),flush=True)
raise SystemExit(int(result['counts']['failed']!=0))
