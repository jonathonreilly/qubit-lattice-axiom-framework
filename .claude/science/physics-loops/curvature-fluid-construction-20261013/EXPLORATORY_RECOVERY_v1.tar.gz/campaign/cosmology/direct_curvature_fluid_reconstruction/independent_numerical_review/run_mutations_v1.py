#!/usr/local/bin/python3
"""Actual scoped source corruptions with fresh complete input freezes."""
from pathlib import Path
import datetime as dt,difflib,hashlib,json,os,subprocess,sys,time
O=Path(__file__).resolve().parent;S=O/'snapshots'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
source=(S/'check_curvature_fluid_v1.py').read_text()
freeze=read(S/'evidence_v1/FROZEN_INPUTS.json')
snapshots={r['path']:Path(r['snapshot']) for r in read(O/'SOURCE_FREEZE_v1.json')['sources']}
mutations=[
dict(id='m1_omit_new_potential',old='    W=V0+s*V1+mp.mpf("1.5")*s*E*E',new='    W=V0+mp.mpf("1.5")*s*E*E'),
dict(id='m2_omit_u_force',old='    force=dU.copy();force[0]+=alB*sm',new='    force=dU.copy();force[0]=0.0'),
dict(id='m3_omit_GN_scalar_exchange',old='            gn8pi=(1+k)/(1+s)',new='            gn8pi=1/(1+s)'),
dict(id='m4_wrong_fixed_s_q_variation',old='            l0=R/2+Tb-2*V0',new='            l0=R/2+Tb-2*V0+s*(R/2+Tb-2*V1)'),
dict(id='m5_drop_excluded_inverse_targets',old='            inverse.append(dict(k=str(k),target_S_squared=st,**out))',new='            if out["status"]=="admitted":inverse.append(dict(k=str(k),target_S_squared=st,**out))'),
dict(id='m6_force_zero_u_acceleration',old='    acc=-(3+h)*p-con-force/(K*H2)',new='    acc=-(3+h)*p-con-force/(K*H2)\n    acc[0]=0.0'),
dict(id='m7_zero_u_metric_derivative',old='    dk[0,0]=K[0]*2*al*z*((1-3*a)/J-2/F)',new='    dk[0,0]=0.0'),
dict(id='m8_serialize_Einstein_masses',old='physical_mass_squared=mass))',new='physical_mass_squared=[fmt(val(v)/(1+s)) for v in mass]))'),
]
save(O/'MUTATION_PLAN_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),driver_pid=os.getpid(),mutations=mutations,scope='Actual new-operator, force, normalization, original-variation, retained-census, off-trajectory and physical-mass serialization challenges. No quota or assertion edits.'))
results=[]
for mu in mutations:
    assert source.count(mu['old'])==1,mu['id']
    changed=source.replace(mu['old'],mu['new'],1)
    case=O/'mutations'/mu['id'];case.mkdir(parents=True)
    with (case/'MUTATION.diff').open('x') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen_v1',tofile=mu['id'])))
    inputs=[]
    for r in freeze['inputs']:
        original=Path(r['path']);snapshot=snapshots[str(original)]
        assert sha(snapshot)==r['sha256']
        dest=case/'sources'/original.parent.name/original.name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(changed.encode() if original.name=='check_curvature_fluid_v1.py' else snapshot.read_bytes())
        inputs.append(dict(path=str(dest),sha256=sha(dest),original_path=str(original),original_sha256=r['sha256']))
        if original.name=='check_curvature_fluid_v1.py':runner=dest
    save(case/'FROZEN_INPUTS.json',dict(inputs=inputs))
    start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
    command=[sys.executable,str(runner),'--freeze',str(case/'FROZEN_INPUTS.json'),'--out',str(case/'RESULTS.json')]
    with (case/'stdout.txt').open('x') as out,(case/'stderr.txt').open('x') as err:
        child=subprocess.Popen(command,stdout=out,stderr=err)
        save(case/'LAUNCH.json',dict(pid=child.pid,started_at=start,command=command))
        try:rc=child.wait(timeout=120);timeout=False
        except subprocess.TimeoutExpired:child.kill();rc=child.wait();timeout=True
    data=read(case/'RESULTS.json') if (case/'RESULTS.json').exists() else None
    sc=[r for r in data['checks'] if r['name'].startswith('source.')] if data else []
    rec=dict(id=mu['id'],started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),seconds=time.monotonic()-tic,exit_code=rc,timeout=timeout,has_result=data is not None,counts=data['counts'] if data else None,source_checks_count=len(sc),all_source_checks_pass=len(sc)==9 and all(r['passed'] for r in sc),inputs_unchanged=all(sha(Path(r['path']))==r['sha256'] for r in inputs),failed_checks=[r for r in data['checks'] if not r['passed']] if data else [],source_sha256=sha(runner),result_sha256=sha(case/'RESULTS.json') if data else None)
    save(case/'EXECUTION.json',rec);results.append(rec)
    print(json.dumps({k:rec[k] for k in ['id','exit_code','counts','all_source_checks_pass','timeout']}),flush=True)
    save(case/'COMPLETE.json',dict(complete=True))
save(O/'MUTATION_RESULTS_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),mutations=results))
