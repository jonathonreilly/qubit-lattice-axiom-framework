#!/usr/local/bin/python3
"""Inspect completed mutations against already saved independent evidence."""
from pathlib import Path
from fractions import Fraction as F
import ast,datetime as dt,hashlib,json
import numpy as np
import mpmath as mp
import sympy as sp
O=Path(__file__).resolve().parent;S=O/'snapshots';mp.mp.dps=110
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def num(x):
    f=F(str(x));return mp.mpf(f.numerator)/f.denominator
controls=read(O/'OFF_TRAJECTORY_CONTROLS_v2.json')['cases']
reference=read(O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v2.json')
full=[]
for mid in ['m6_force_zero_u_acceleration','m7_zero_u_metric_derivative']:
    source=O/'mutations'/mid/'sources/direct_curvature_fluid_reconstruction/check_curvature_fluid_v1.py'
    tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['full_einstein_functions','full_n_rhs']]
    unit={'np':np};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'actual_saved_mutant_units','exec'),unit)
    rows=[]
    for row in controls:
        pars=[float(F(v)) for v in row['labels']];phi=np.array([float(v) for v in row['phi']]);state=np.array([float(v) for v in row['phi']+row['p']+[row['sm'],row['sr']]])
        f=unit['full_einstein_functions'](phi,*pars);rhs=unit['full_n_rhs'](0.,state,*pars)
        derr=[]
        for i in range(3):
            for j in range(3):
                expected=num(row['dK'][i][j]);scale=max(abs(num(row['K'][j])),abs(expected))
                derr.append(float(abs(num(float(f[1][i,j]))-expected)/scale))
        rerr=[float(abs(num(float(rhs[i]))-num(row['rhs'][i]))/max(1,abs(num(row['rhs'][i])))) for i in range(8)]
        rows.append(dict(parameter_id=row['parameter_id'],u_index=row['u_index'],dK_errors=derr,rhs_errors=rerr,dK_failures=sum(e>2e-11 for e in derr),rhs_failures=sum(e>2e-11 for e in rerr)))
    full.append(dict(id=mid,source_sha256=sha(source),cases=rows,case_count=len(rows),cases_with_dK_failure=sum(r['dK_failures']>0 for r in rows),cases_with_rhs_failure=sum(r['rhs_failures']>0 for r in rows),dK_failure_count=sum(r['dK_failures'] for r in rows),rhs_failure_count=sum(r['rhs_failures'] for r in rows)))
mid='m8_serialize_Einstein_masses';mut=read(O/'mutations'/mid/'RESULTS.json');mass=[]
for actual,expected in zip(mut['local_masses'],reference['local_masses']):
    assert actual['id']==expected['id']
    for i,(av,ev) in enumerate(zip(actual['physical_mass_squared'],expected['physical_mass_squared'])):
        error=abs(num(av)-num(ev))/max(1,abs(num(ev)))
        if error>num('1e-60'):mass.append(dict(id=actual['id'],a=actual['a'],b=actual['b'],s=actual['s'],nu=actual['nu'],component=i,stored=av,independent_expected=ev,normalized_error=mp.nstr(error,80)))
full.append(dict(id=mid,wrong_mass_values=len(mass),rows=mass))
allruns=read(O/'MUTATION_RESULTS_v1.json')['mutations']
for row in allruns:
    frozen=read(O/'mutations'/row['id']/'FROZEN_INPUTS.json')
    assert len(frozen['inputs'])==9 and all(sha(Path(r['path']))==r['sha256'] for r in frozen['inputs'])
    assert row['all_source_checks_pass'] and row['inputs_unchanged'] and row['has_result'] and not row['timeout']
assert full[0]['cases_with_rhs_failure']>0 and full[1]['cases_with_dK_failure']>0 and len(mass)==144
save(O/'SURVIVOR_COMPARISON_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),scope='No original positive science rerun. Frozen mutant units tested against saved independent field/RHS controls; stored mutant masses compared with saved independent reference.',mutations=full,all_fresh_freezes_verified=True))

# Complete the symbolic-string coverage omitted from the main numerical pass.
u,x,y,a,b,s,R=sp.symbols('u x y a b s R',real=True);qu,qx,qy=sp.symbols('Qu Qx Qy')
E=sp.exp(2*sp.sqrt(a)*u);D=1+sp.Rational(2,3)*(1+b)*(x*x+y*y)
kx,ky=4*b/(9*D),b/(3*D)
v1=(b/2+sp.sqrt(a)*b*u+2*a*u*u/b)*x*x+b*y*y/3
locals_={str(v):v for v in [u,x,y,a,b,s]}
locals_.update(RR=R,hv=sp.Integer(1),Qx=kx*qx,Qy=ky*qy,grad_u_sq=qu)
stored=sp.sympify(read(S/'evidence_v1/RESULTS.json')['symbolic']['wrong_q_term'],locals=locals_)
expected=s*(E*R/2+3*a*E*qu-kx*qx-ky*qy-2*v1)
remainder=sp.simplify(stored-expected)
assert remainder==0
save(O/'SYMBOLIC_OUTPUT_COMPLETION_v1.json',dict(scope='Hv=1 units; Qx,Qy in parent stored string denote already-metric-weighted contractions, mapped to independent raw gradients.',wrong_q_term_remainder=str(remainder),passed=True))
print(json.dumps(dict(survivors=[{k:v for k,v in r.items() if k not in ['cases','rows']} for r in full],symbolic_completion=True),indent=2))
