def io_control():
    pa = argparse.ArgumentParser()
    pa.add_argument('--out', type=Path, default=HERE / 'RESULTS.json')
    args = pa.parse_args()
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print('Conditional action: 360 ideal-orbit rows, 72 local Hessians, 72 full off-trajectory equation states, four integrated histories.')
    print('Measured-G normalization and supplied PPN/ideal-species diagnostics are conditional bridges; b=k is calibration, not a prediction.')
    print('TOTAL: PASS=' + str(result['counts']['passed']) + ' FAIL=' + str(result['counts']['failed']))
    return int(result['counts']['failed'] != 0)
