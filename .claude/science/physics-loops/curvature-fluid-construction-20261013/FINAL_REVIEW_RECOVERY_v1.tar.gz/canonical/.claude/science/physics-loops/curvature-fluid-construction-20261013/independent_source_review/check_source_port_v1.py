#!/usr/bin/env python3
"""Independent focused proof/port/IO controls; never executes parent science."""
from pathlib import Path
import argparse, ast, contextlib, copy, datetime, difflib, gzip, hashlib
import io, json, os, subprocess, sys, tarfile
import sympy as sp

R = Path(__file__).resolve().parent
P = R.parent
W = P.parents[3]
B = Path('/Users/jonBridger/.codex/worktrees/observations-to-toe-24h-20261012/New Axioms Lets Go/.claude/science/physics-loops/observations-to-toe-24h-20261012/cosmology/direct_curvature_fluid_reconstruction')
RT = Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/curvature_milestone')
CHECKS = []

def sha(data): return hashlib.sha256(data).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def check(name, condition, **detail):
    row = dict(name=name, passed=bool(condition), **detail)
    CHECKS.append(row)
    if not condition: raise AssertionError(row)
def save(name, data):
    (R/name).write_text(json.dumps(data, indent=2)+'\n')
def pin(p):
    p=Path(p); data=p.read_bytes()
    return dict(path=str(p),sha256=sha(data),bytes=len(data))
def exact(name, expression):
    red=sp.factor(sp.cancel(expression))
    check(name,red==0,reduced=str(red))

def run():
    unit=load(RT/'SOURCE_UNIT_v2.json')
    check('base',unit['base']=='516cb69d8487ff04f8a48e065d3dcbe71d7dd237')
    check('head',subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==unit['head'])
    treecheck=subprocess.run(['git','diff','--cached','--quiet',unit['tree']],cwd=W)
    check('index_tree',treecheck.returncode==0,tree=unit['tree'])
    stage=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=W).decode().split('\0')
    stage=[p for p in stage if p]
    check('source_census',set(stage)=={x['path'] for x in unit['paths']} and len(stage)==15)
    frozen=[]
    for row in unit['paths']:
        path=W/row['path'];data=path.read_bytes(); indexed=subprocess.check_output(['git','show',':'+row['path']],cwd=W)
        check('disk_index.'+row['path'],data==indexed and sha(data)==row['sha256'])
        snap=R/'snapshots_final'/row['path'];snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(data)
        frozen.append(dict(**row,absolute_path=str(path),snapshot=str(snap),bytes=len(data)))
    for name in ['SOURCE_UNIT_v1.json','SOURCE_UNIT_v2.json','VACUUM_LABEL_CORRECTION_v2.diff','CANONICAL_NOTE_before_vacuum_label.md','INITIAL_DIFF_CHECK_v1.json','FINAL_DIFF_CHECK_v1.json']:
        source=RT/name;target=R/'runtime_snapshots'/name;target.parent.mkdir(exist_ok=True);target.write_bytes(source.read_bytes())
    save('SOURCE_FREEZE_FINAL_v2.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),unit=unit,source_paths=frozen))

    # Exhaustive member inventory and exact byte recovery, without unsafe extraction.
    recovery=load(P/'RECOVERY_v1.json');archive=P/recovery['archive']
    check('archive_digest',sha(archive.read_bytes())==recovery['sha256'])
    manifest={x['archive_path']:x for x in recovery['members']}
    check('archive_manifest_unique',len(manifest)==len(recovery['members'])==348)
    archive_rows=[]
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();check('archive_member_census',{m.name for m in members}==set(manifest) and len(members)==348)
        for member in members:
            item=manifest[member.name]
            check('archive_safe.'+member.name,member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts)
            data=tar.extractfile(member).read();original=Path(item['original_path'])
            check('archive_hash.'+member.name,sha(data)==item['sha256'] and len(data)==item['bytes'])
            check('archive_original.'+member.name,original.read_bytes()==data)
            archive_rows.append(dict(**item,archive_mode=member.mode,original_mode=original.stat().st_mode & 0o777,verified=True))
    current={str(x) for x in B.rglob('*') if x.is_file()}
    archived={x['original_path'] for x in recovery['members'] if str(B)+'/' in x['original_path']}
    check('exploratory_complete',current==archived,current_count=len(current),archived_count=len(archived),missing=sorted(current-archived),extra=sorted(archived-current))
    save('RECOVERY_VERIFICATION_v1.json',dict(archive=pin(archive),manifest=pin(P/'RECOVERY_v1.json'),members=archive_rows,complete_exploratory_paths=len(current)))

    original=(B/'check_curvature_fluid_v2.py').read_text()
    canonical=(W/'scripts/curvature_fluid_construction_2026_10_13.py').read_text()
    check('original_runner_pin',sha(original.encode())=='78a801465c3cdb7f580d144ac2b7df33dc92431a1232cf5fe2b1259962108fd8')
    check('canonical_runner_pin',sha(canonical.encode())=='3675d6d0aab39e3898c9d96bce321a7ff8460058b458f6ca9bcf68b72cdd17bb')
    ot,ct=ast.parse(original),ast.parse(canonical)
    of={x.name:x for x in ot.body if isinstance(x,ast.FunctionDef)}
    cf={x.name:x for x in ct.body if isinstance(x,ast.FunctionDef)}
    check('function_census',set(of)==set(cf) and len(of)==14)
    for name in sorted(set(of)-{'main'}):
        check('function_AST.'+name,ast.dump(of[name])==ast.dump(cf[name]))
        check('function_text.'+name,ast.get_source_segment(original,of[name])==ast.get_source_segment(canonical,cf[name]))
    raw=gzip.decompress((P/'PORT_v1.diff.gz').read_bytes()).decode()
    expected=''.join(difflib.unified_diff(original.splitlines(keepends=True),canonical.splitlines(keepends=True),fromfile='exploratory_v2',tofile='canonical_v1'))
    check('port_diff_exact',raw==expected)
    check('port_diff_external_digest',sha(raw.encode())==load(P/'PORT_FUNCTION_IDENTITY_v1.json')['port_diff_content_sha256'])
    # Compare every main statement after excluding only reviewed CLI/source-pin/print handling.
    old_body=of['main'].body
    new_body=cf['main'].body
    start_old=next(i for i,n in enumerate(old_body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Attribute) and n.targets[0].attr=='dps')
    start_new=next(i for i,n in enumerate(new_body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Attribute) and n.targets[0].attr=='dps')
    end_old=next(i for i,n in enumerate(old_body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='write_text')
    end_new=next(i for i,n in enumerate(new_body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='write_text')
    check('complete_main_science_AST',ast.dump(ast.Module(body=old_body[start_old:end_old],type_ignores=[]))==ast.dump(ast.Module(body=new_body[start_new:end_new],type_ignores=[])))
    check('return_status_AST',ast.dump(old_body[-1])==ast.dump(new_body[-1]))
    check('result_write_AST',ast.dump(old_body[end_old])==ast.dump(new_body[end_new]))
    for n in ['NUMERICAL_FIXTURES_v1.json','OFF_TRAJECTORY_FIXTURES_v2.json']:
        x=(B/n).read_bytes();y=(W/'outputs/curvature_fluid_construction_2026_10_13'/n).read_bytes()
        check('fixture_JSON.'+n,json.loads(x)==json.loads(y))
        check('fixture_whitespace_only.'+n,x.rstrip()+b'\n'==y)
    compile(canonical,str(W/'scripts/curvature_fluid_construction_2026_10_13.py'),'exec')
    check('syntax',True)

    # Independently vary the two-field kinetic action to check the expanded proof.
    b,hv,x,y=sp.symbols('b hv x y',positive=True)
    fields=(x,y);D=1+sp.Rational(2,3)*(1+b)*(x*x+y*y)
    K=[4*b/(9*D),b/(3*D)];H=hv*sp.sqrt(D)
    velocity=[-sp.Rational(3,2)*H*x,-2*H*y]
    dt=lambda expression:sum(sp.diff(expression,z)*v for z,v in zip(fields,velocity))
    Hdot=dt(H);V=hv**2*(sp.Rational(3,2)+b*x*x/2+b*y*y/3)
    expected_conn=[sp.Rational(3,2)*x*Hdot,2*y*Hdot]
    expanded={
        (0,0,0):-sp.diff(D,x)/(2*D),(0,0,1):-sp.diff(D,y)/(2*D),
        (0,1,0):-sp.diff(D,y)/(2*D),(0,1,1):3*sp.diff(D,x)/(8*D),
        (1,1,1):-sp.diff(D,y)/(2*D),(1,0,1):-sp.diff(D,x)/(2*D),
        (1,1,0):-sp.diff(D,x)/(2*D),(1,0,0):2*sp.diff(D,y)/(3*D)}
    metric=sp.diag(*K);connection=[]
    for i in range(2):
        c=0
        for j in range(2):
            for k in range(2):
                gamma=(sp.diff(metric[i,k],fields[j])+sp.diff(metric[i,j],fields[k])-sp.diff(metric[j,k],fields[i]))/(2*K[i])
                exact('connection_component.'+str((i,j,k)),gamma-expanded[i,j,k])
                c+=gamma*velocity[j]*velocity[k]
        connection.append(sp.factor(c))
        exact('connection_contraction.'+str(i),c-expected_conn[i])
        covector=dt(K[i]*velocity[i])+3*H*K[i]*velocity[i]-sum(sp.diff(K[j],fields[i])*velocity[j]**2 for j in range(2))/2+sp.diff(V,fields[i])
        exact('direct_Euler_Lagrange.'+str(i),covector)
        exact('gradient_flow.'+str(i),K[i]*velocity[i]+b/(1+b)*sp.diff(H,fields[i]))
        omitted=-c
        check('connection_omission_exposed.'+str(i),omitted.subs({b:sp.Rational(1,5),hv:1,x:1,y:2})!=0,residual=str(omitted.subs({b:sp.Rational(1,5),hv:1,x:1,y:2})))
    exact('acceleration_x',dt(velocity[0])-(sp.Rational(9,4)*H**2-sp.Rational(3,2)*Hdot)*x)
    exact('acceleration_y',dt(velocity[1])-(4*H**2-2*Hdot)*y)
    exact('force_x',sp.diff(V,x)/K[0]-sp.Rational(9,4)*H**2*x)
    exact('force_y',sp.diff(V,y)/K[1]-2*H**2*y)
    q,Lam,rhovac,A,F,V0,V1,s=sp.symbols('q Lambda rho_vac A F V0 V1 s',nonzero=True)
    original_potential_density=(-2*q*(V0+s*V1)-(Lam+rhovac)*A**4)/F**2
    moved=-2*q*(V0+s*V1+(Lam+rhovac)*A**4/(2*q))/F**2
    exact('vacuum_absorbed_once',original_potential_density-moved)
    check('old_ambiguous_Gamma_has_extra_vacuum',sp.factor((moved-rhovac*A**4/F**2)-original_potential_density)==-rhovac*A**4/F**2)
    exact('physical_clock_mass_conversion',(sp.symbols('mE')/sp.sqrt(1/(1+s)))**2-(1+s)*sp.symbols('mE')**2)
    save('FOCUSED_PROOF_REFERENCE_v1.json',dict(method='Independent two-field Euler-Lagrange momentum variation, explicit connection contractions, and vacuum-density accounting.',connection=[str(x) for x in connection],old_vacuum_double_count_density=str(-rhovac*A**4/F**2)))

    # Extract only actual CLI and output statements; no physics function is imported/executed.
    fn=ast.FunctionDef(name='io_control',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),
                       body=copy.deepcopy(new_body[:3]+new_body[end_new:]),decorator_list=[])
    module=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]))
    (R/'IO_EXTRACTED_CONTROL_v1.py').write_text(ast.unparse(module)+'\n')
    io_dir=R/'io_controls';io_dir.mkdir(exist_ok=False)
    ns={'argparse':argparse,'Path':Path,'HERE':io_dir,'json':json}
    exec(compile(module,'<actual CLI/output extraction>','exec'),ns)
    old_argv=sys.argv[:];io_rows=[]
    try:
        for iteration,(custom,passed,failed) in enumerate([(False,1,0),(False,2,0),(True,0,1)]):
            out=io_dir/('CUSTOM.json' if custom else 'RESULTS.json');out.write_text('stale sentinel\n')
            ns['result']={'counts':dict(passed=passed,failed=failed),'synthetic_fixture_only':iteration}
            sys.argv=['canonical_io']+(['--out',str(out)] if custom else [])
            capture=io.StringIO()
            with contextlib.redirect_stdout(capture): code=ns['io_control']()
            check('io_current_result.'+str(iteration),json.loads(out.read_text())==ns['result'])
            check('io_exit_and_total.'+str(iteration),code==int(failed!=0) and f'TOTAL: PASS={passed} FAIL={failed}' in capture.getvalue())
            io_rows.append(dict(iteration=iteration,path=str(out),exit_code=code,stdout=capture.getvalue(),result=ns['result']))
    finally:sys.argv=old_argv
    save('IO_CONTROLS_v1.json',dict(scope='Actual extracted CLI and output statements with synthetic results only. Repeated default output and explicit --out overwrite are intentional; no exclusive-sidecar claim is made.',rows=io_rows))

    # Query repository parser APIs only; never run graph generation or runner execution.
    sys.path[:0]=[str(W/'scripts'),str(W/'docs/audit/scripts'),str(W/'docs/ai_methodology/skills/review-loop/scripts')]
    import runner_cache as cache
    import audit_packet_script_deps as packet
    import build_citation_graph as graph
    import review_receipt as receipt
    note=W/'docs/CURVATURE_FLUID_CONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md'
    body=note.read_text();primary=graph.extract_runner(body,note.relative_to(W/'docs').as_posix());cid=graph.claim_id_from_path(note)
    helpers=graph.helper_runner_paths_for_claim(cid,primary)
    packet_helpers=packet.helper_runner_paths_for_claim(cid,Path(primary).stem)
    check('primary_discovery',primary=='scripts/curvature_fluid_construction_2026_10_13.py')
    check('helper_closure_empty',helpers==packet_helpers==[])
    citations=[p.relative_to(W).as_posix() for p in graph.extract_citations(body,note)]
    check('citations_empty',citations==[])
    inputs=cache.declared_input_paths(primary)
    check('runtime_inputs_exact',list(inputs)==[note.relative_to(W).as_posix()]+['outputs/curvature_fluid_construction_2026_10_13/'+n for n in ['NUMERICAL_FIXTURES_v1.json','OFF_TRAJECTORY_FIXTURES_v2.json','imports.json']])
    check('declared_timeout',receipt.declared_review_timeout_for(W,cache,primary)==120)
    check('declared_input_fingerprint',len(cache.declared_input_fingerprint(primary))==64)
    names=[x for x in W.joinpath('docs').rglob(note.name)]
    check('note_basename_unique',names==[note])
    save('DISCOVERY_v1.json',dict(claim_id=cid,declared_claim_id='curvature-fluid-construction-bounded-theorem-note-2026-10-13',claim_type=graph.extract_claim_type_hint(body),primary=primary,helpers=helpers,packet_helpers=packet_helpers,citations=citations,runtime_inputs=list(inputs),declared_timeout_seconds=120,input_fingerprint=cache.declared_input_fingerprint(primary),repository_dependencies=[],rationale='Full supplied action, local equations and algebraic proof are present in the canonical note; no archived theorem is an implicit premise.'))
    for row in unit['paths']:
        check('final_pin.'+row['path'],sha((W/row['path']).read_bytes())==row['sha256'])
    return dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Focused source port/proof/IO and complete recovery check only; canonical positive science not executed.',counts={'passed':len(CHECKS),'failed':0,'total':len(CHECKS)},checks=CHECKS)

if __name__=='__main__':
    try:
        result=run();save('SOURCE_CHECK_RESULTS_v1.json',result)
        print(json.dumps(result['counts']))
    except BaseException:
        save('SOURCE_CHECK_PARTIAL_FAILURE_v1.json',dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=CHECKS))
        raise
