"""Read-only comparison of completed canonical outputs; never execute science."""
from __future__ import annotations

import ast
import collections
import copy
import datetime as dt
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path('/Users/jonBridger/.codex/worktrees/curvature-fluid-construction-20261013/New Axioms Lets Go')
P = W / '.claude/science/physics-loops/curvature-fluid-construction-20261013'
R = P / 'independent_source_review'
E = Path(__file__).resolve().parent
RT = Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/curvature_milestone')
B = Path('/Users/jonBridger/.codex/worktrees/observations-to-toe-24h-20261012/New Axioms Lets Go/.claude/science/physics-loops/observations-to-toe-24h-20261012/cosmology/direct_curvature_fluid_reconstruction')
BASE = '516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
COMMIT = 'a1401c38a6321540a37a7ae07b6b37b55ddcba16'
TREE = '938abda0610342e552b52ba9634e4e66dc849610'
RUNNER = 'scripts/curvature_fluid_construction_2026_10_13.py'
OUT = W / 'outputs/curvature_fluid_construction_2026_10_13/RESULTS.json'
CACHE = W / 'logs/runner-cache/curvature_fluid_construction_2026_10_13.txt'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, obj):
    with (E / name).open('x') as f:
        json.dump(obj, f, indent=2, allow_nan=False)
        f.write('\n')


def load(p):
    return json.loads(p.read_text())


def main():
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    prior = load(R / 'FINAL_SOURCE_RECEIPT_v1.json')
    paths = [W / row['path'] for row in prior['source_paths']]
    paths += [
        R / 'FINAL_SOURCE_RECEIPT_v1.json', R / 'CANONICAL_SOURCE_REVIEW_v1.md',
        R / 'SOURCE_DISPOSITIONS_v1.json', R / 'SOURCE_CHECK_RESULTS_v1.json',
        B / 'check_curvature_fluid_v2.py',
        B / 'evidence_v2/RESULTS.json', B / 'evidence_v2/FROZEN_INPUTS.json',
        B / 'evidence_v2/EXECUTION.json', B / 'evidence_v2/stdout.txt',
        B / 'evidence_v2/stderr.txt',
        B / 'independent_numerical_review/affected_v2/AFFECTED_V2_REVIEW_v1.md',
        B / 'independent_numerical_review/affected_v2/FINAL_RECEIPT_v1.json',
        RT / 'UNIT_v1.json', RT / 'UNIT_v2.json',
        RT / 'UNIT_PREFLIGHT_v1.json', RT / 'UNIT_PREFLIGHT_v2.json',
        RT / 'SOURCE_COMMIT_v1.json',
        RT / 'first_capture_guard_failure_v1/RESULTS.json',
        RT / 'first_capture_guard_failure_v1/FAILURE.json',
        RT / 'first_capture_guard_failure_v1/TOOL_EXCEPTION_EXCERPT_v1.json',
        P / 'CANONICAL_EXECUTION_v2.json', OUT, CACHE,
        W / 'scripts/runner_cache.py',
        W / 'docs/ai_methodology/skills/review-loop/scripts/review_receipt.py',
    ]
    refs = []
    snap = E / 'snapshots'
    snap.mkdir(exist_ok=True)
    for i, p in enumerate(dict.fromkeys(paths)):
        raw = p.read_bytes()
        target = snap / f'{i:03d}_{p.name}'
        with target.open('xb') as f:
            f.write(raw)
        refs.append({'path': str(p), 'sha256': sha(raw), 'bytes': len(raw),
                     'snapshot': str(target), 'snapshot_sha256': sha(raw)})
    write('SOURCE_FREEZE_v1.json', {'at': started, 'scope': 'Completed output/capture identity only', 'sources': refs})

    checks = []
    def check(name, condition, **details):
        checks.append({'name': name, 'passed': bool(condition), **details})

    commands = []
    def git(*args):
        cmd = ['git', '-C', str(W), *args]
        cp = subprocess.run(cmd, capture_output=True)
        commands.append({'command': cmd, 'exit_code': cp.returncode,
                         'stdout_sha256': sha(cp.stdout), 'stderr': cp.stderr.decode()})
        if cp.returncode:
            raise RuntimeError(cp.stderr.decode())
        return cp.stdout

    check('source.commit_tree', git('rev-parse', f'{COMMIT}^{{tree}}').decode().strip() == TREE)
    check('source.current_head', git('rev-parse', 'HEAD').decode().strip() == COMMIT)
    check('source.commit_parent', git('rev-parse', f'{COMMIT}^').decode().strip() == BASE)
    changed = git('diff', '--name-only', BASE, COMMIT).decode().splitlines()
    check('source.exact_15_path_constituent', sorted(changed) == sorted(x['path'] for x in prior['source_paths']))
    dispositions = []
    for row in prior['source_paths']:
        rel, expected = row['path'], row['sha256']
        blob_sha = sha(git('show', f'{COMMIT}:{rel}'))
        current = sha((W / rel).read_bytes())
        check('source.commit_blob.' + rel, blob_sha == expected)
        check('source.current_bytes.' + rel, current == expected)
        dispositions.append({'original_path': rel, 'original_sha256': expected,
                             'original_commit': COMMIT, 'disposition': 'unchanged',
                             'final_path': rel, 'final_sha256': current,
                             'recovery': {'kind': 'git-blob', 'commit': COMMIT, 'path': rel}})

    original = load(B / 'evidence_v2/RESULTS.json')
    canonical = load(OUT)
    first = load(RT / 'first_capture_guard_failure_v1/RESULTS.json')
    removed = [x for x in original['checks'] if x['name'].startswith('source.')]
    check('bookkeeping.exact_12_removed_source_assertions', len(removed) == 12 and all(x['passed'] is True for x in removed))
    check('bookkeeping.original_counts', original['counts'] == {'passed': 6663, 'failed': 0, 'total': 6663})
    check('bookkeeping.original_symbolic_count', original['symbolic']['count'] == 36)
    expected = copy.deepcopy(original)
    expected['checks'] = [x for x in original['checks'] if not x['name'].startswith('source.')]
    expected['symbolic']['count'] = 24
    expected['counts'] = {'passed': 6651, 'failed': 0, 'total': 6651}
    mismatch = []
    leaves = collections.Counter()
    def strict(a, b, loc, label):
        if type(a) is not type(b):
            mismatch.append({'label': label, 'path': loc, 'reason': 'type', 'a': str(type(a)), 'b': str(type(b))})
            return
        if isinstance(a, dict):
            if list(a) != list(b):
                mismatch.append({'label': label, 'path': loc, 'reason': 'keys/order'})
            for k in a.keys() & b.keys():
                strict(a[k], b[k], loc + '/' + k, label)
        elif isinstance(a, list):
            if len(a) != len(b):
                mismatch.append({'label': label, 'path': loc, 'reason': 'length'})
            for i, (x, y) in enumerate(zip(a, b)):
                strict(x, y, loc + '/' + str(i), label)
        else:
            leaves[(label, loc.split('/')[1], type(a).__name__)] += 1
            same = a.hex() == b.hex() if isinstance(a, float) else a == b
            if not same:
                mismatch.append({'label': label, 'path': loc, 'reason': 'value', 'a': a, 'b': b})
    strict(expected, canonical, '', 'canonical_vs_exploratory_after_declared_bookkeeping')
    strict(expected, first, '', 'first_capture_output_vs_exploratory_after_declared_bookkeeping')
    strict(first, canonical, '', 'second_vs_first_capture_output')
    check('outputs.every_typed_leaf_and_structure_equal', not mismatch, mismatches=mismatch)
    check('outputs.first_and_second_exact_bytes', OUT.read_bytes() == (RT / 'first_capture_guard_failure_v1/RESULTS.json').read_bytes())
    check('outputs.all_6651_pass_objects_retained', len(canonical['checks']) == 6651 and all(c['passed'] is True for c in canonical['checks']))
    check('outputs.canonical_counts', canonical['counts'] == {'passed': 6651, 'failed': 0, 'total': 6651})

    tree = ast.parse((W / RUNNER).read_text())
    literals = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {'AUDIT_INPUT_PATHS', 'AUDIT_TIMEOUT_SEC'}:
                    literals[target.id] = ast.literal_eval(node.value)
    input_paths = literals['AUDIT_INPUT_PATHS']
    check('cache.exact_declared_input_list', list(input_paths) == prior['source_discovery']['runtime_inputs'])
    check('cache.timeout_120', literals['AUDIT_TIMEOUT_SEC'] == 120)
    digest = hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
    for rel in input_paths:
        encoded = rel.encode()
        body = (W / rel).read_bytes()
        digest.update(len(encoded).to_bytes(8, 'big'))
        digest.update(encoded)
        digest.update(len(body).to_bytes(8, 'big'))
        digest.update(body)
    fp = digest.hexdigest()
    cache_body = CACHE.read_text()
    header = {}
    header_text, streams = cache_body.split('----- stdout -----\n', 1)
    for line in header_text.splitlines()[1:]:
        if ': ' in line:
            k, v = line.split(': ', 1)
            header[k] = v
    stdout, stderr = streams.split('----- stderr -----\n', 1)
    execution = load(P / 'CANONICAL_EXECUTION_v2.json')
    check('cache.independent_current_fingerprint', fp == prior['source_discovery']['input_fingerprint'])
    check('cache.header_runner', header['runner'] == RUNNER)
    check('cache.header_source_sha', header['runner_sha256'] == sha((W / RUNNER).read_bytes()))
    check('cache.header_input_fp', header['input_fingerprint_sha256'] == fp)
    check('cache.header_success', header['status'] == 'ok' and header['exit_code'] == '0' and header['timeout_sec'] == '120')
    check('cache.raw_sha_vs_execution', sha(CACHE.read_bytes()) == execution['cache_sha256'])
    check('cache.recorded_path', execution['cache_path'] == str(CACHE))
    check('cache.stdout_vs_execution', stdout == execution['result']['stdout'] + '\n')
    check('cache.empty_stderr', not stderr.strip() and execution['result']['stderr'] == '')
    check('cache.execution_success', execution['capture_exception'] is None and execution['result']['status'] == 'ok' and execution['result']['exit_code'] == 0)
    check('cache.result_count_banner', 'TOTAL: PASS=6651 FAIL=0\n' in stdout)
    check('cache.elapsed_rounded_consistently', header['elapsed_sec'] == f"{execution['result']['elapsed_sec']:.2f}")
    check('cache.no_remaining_live_log', not Path(execution['result']['live_log']).exists())
    sys.path.insert(0, str(W))
    harness = importlib.import_module('scripts.runner_cache')
    api = {'cache_identity_status': harness.cache_identity_status(RUNNER),
           'cache_status': harness.cache_status(RUNNER),
           'declared_input_fingerprint': harness.declared_input_fingerprint(RUNNER)}
    check('cache.read_only_owning_api_agrees', api == {'cache_identity_status': 'fresh', 'cache_status': 'fresh', 'declared_input_fingerprint': fp})

    pf1 = load(RT / 'UNIT_PREFLIGHT_v1.json')
    pf2 = load(RT / 'UNIT_PREFLIGHT_v2.json')
    unit1, unit2 = load(RT / 'UNIT_v1.json'), load(RT / 'UNIT_v2.json')
    pf1body, pf2body = json.loads(pf1['stdout']), json.loads(pf2['stdout'])
    check('preflight.actual_v1_failure_preserved', pf1['exit_code'] == 1 and pf1body['mechanical_status'] == 'invalid' and pf1body['error'] == "'base'")
    check('preflight.actual_v2_success', pf2['exit_code'] == 0 and pf2body['mechanical_status'] == 'ok' and pf2body['cache_checked'] is False)
    check('preflight.v2_record_hash', pf2['record_sha256'] == sha((RT / 'UNIT_v2.json').read_bytes()) == pf2body['record_sha256'])
    check('preflight.v1_record_hash', pf1['record_sha256'] == sha((RT / 'UNIT_v1.json').read_bytes()))
    check('preflight.exact_source', unit2['source']['base'] == BASE and unit2['source']['commit'] == COMMIT and unit2['source']['tree'] == TREE and unit2['source']['paths'] == prior['source_paths'])
    old_corrected = copy.deepcopy(unit1)
    old_corrected['source'].pop('base_commit')
    old_corrected['source']['base'] = BASE
    old_corrected['source']['commit'] = COMMIT
    check('preflight.schema_only_record_change', old_corrected == unit2)
    check('preflight.success_before_completed_capture', dt.datetime.fromisoformat(pf2['finished_at']) < dt.datetime.fromisoformat(execution['started_at']) < dt.datetime.fromisoformat(execution['finished_at']))
    check('preflight.capture_reference', execution['prior_successful_preflight'] == str(RT / 'UNIT_PREFLIGHT_v2.json'))
    check('preflight.source_checker_hash', pf2body['checker_sha256'] == sha((W / 'docs/ai_methodology/skills/review-loop/scripts/review_receipt.py').read_bytes()))

    failure = load(RT / 'first_capture_guard_failure_v1/FAILURE.json')
    excerpt = load(RT / 'first_capture_guard_failure_v1/TOOL_EXCEPTION_EXCERPT_v1.json')
    before = ast.literal_eval(excerpt['directory_token_before'])
    after = ast.literal_eval(excerpt['directory_token_after'])
    check('failure.first_result_hash', sha((RT / 'first_capture_guard_failure_v1/RESULTS.json').read_bytes()) == failure['first_result_sha256'])
    check('failure.selected_tokens_differ_only_size_and_times', before[:4] == after[:4] and before[4] == 160 and after[4] == 192 and before[5:] != after[5:])
    check('failure.excerpt_transcription_label_preserved', 'transcribed' in excerpt['provenance'] and 'not a recovered complete raw log' in excerpt['provenance'])
    check('failure.same_content_identity_in_selected_excerpt', fp in excerpt['both_content_identities'] and sha((W / RUNNER).read_bytes()) in excerpt['both_content_identities'])
    check('failure.no_first_wall_time_reconstruction', excerpt['no_exact_first_run_wall_times_reconstructed'] is True)
    check('failure.exception_exact_class', excerpt['exception_class'] == 'scripts.runner_cache.RunnerIdentityChangedError')

    for ref in refs:
        check('immutability.' + ref['path'], sha(Path(ref['path']).read_bytes()) == ref['sha256'] == sha(Path(ref['snapshot']).read_bytes()))
    counts = {'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks), 'total': len(checks)}
    write('CHECK_RESULTS_v1.json', {
        'scope': 'Read-only exact outputs/cache/source/preflight comparison; no new scientific recomputation or author execution.',
        'started_at': started, 'finished_at': dt.datetime.now(dt.timezone.utc).isoformat(),
        'base': BASE, 'commit': COMMIT, 'tree': TREE, 'checks': checks, 'counts': counts,
        'result_sha256': sha(OUT.read_bytes()), 'cache_sha256': sha(CACHE.read_bytes()),
        'input_fingerprint': fp, 'owning_read_only_api': api,
        'typed_leaf_counts': [{'comparison': k[0], 'section': k[1], 'type': k[2], 'count': v} for k,v in sorted(leaves.items())],
        'removed_assertion_names': [c['name'] for c in removed],
        'mismatches': mismatch,
        'first_failure_evidence_scope': 'Selected tool-output transcription plus retained JSON; complete raw log and exact first-run timing unavailable.',
    })
    write('READ_ONLY_GIT_COMMANDS_v1.json', commands)
    write('ORIGINAL_CONSTITUENT_DISPOSITIONS_v1.json', {
        'original_commit': COMMIT, 'delta_base': BASE, 'tree': TREE,
        'scope': 'The actual 15-path original constituent remains unchanged at this execution confirmation.',
        'original_dispositions': dispositions,
    })
    print(json.dumps({'counts': counts, 'mismatches': len(mismatch),
                      'leaf_comparisons': sum(leaves.values()), 'source_refs': len(refs),
                      'cache_status': api['cache_status']}))
    if counts['failed']:
        sys.exit(1)


if __name__ == '__main__':
    main()
