"""Seal the already completed execution/output review; no science execution."""
from pathlib import Path
import datetime
import hashlib
import json

E = Path(__file__).resolve().parent


def digest(p):
    b = p.read_bytes()
    return {'path': str(p), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}


def write(name, value):
    with (E / name).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


failure = {
    'reviewer_event': {
        'tool_chunk': 'cc642d', 'exit_code': 1,
        'error': 'FileNotFoundError',
        'attempted_path': '/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/curvature_milestone/CANONICAL_EXECUTION_v2.json',
        'cause': 'Reviewer initially interpreted the execution-receipt location as runtime; the receipt was in the canonical packet.',
        'resolution': 'Targeted rg listing and packet glob located the existing receipt; subsequent full read and identity/output checks passed.',
        'evidence_kind': 'Contemporaneous transcription of reviewer tool result, not a separately recovered raw tool-output file.',
        'science_executed': False, 'author_files_changed': False,
    },
    'parent_failures': [
        {'event': 'UNIT_v1 schema preflight', 'disposition': "Preserved actual failure, invalid schema key source.base_commit; corrected record passed before capture."},
        {'event': 'First capture guard rejection', 'disposition': 'Retained successful scientific JSON; no captured cache. Selected exception transcription is labelled, full raw log and exact first-run timings are unavailable.'},
    ],
    'completed_reviewer_check': {'passed': 112, 'failed': 0, 'author_science_rerun': False},
}
write('REVIEWER_FAILURE_HISTORY_v1.json', failure)

freeze = json.loads((E / 'SOURCE_FREEZE_v1.json').read_text())
result = json.loads((E / 'CHECK_RESULTS_v1.json').read_text())
write('READING_LEDGER_v1.json', {
    'scope': 'Affected execution/output/identity only; unchanged mathematical review reused.',
    'complete_reads': [
        'Actual canonical capture receipt and raw cache',
        'Both preserved first-capture JSON artifacts and selected exception excerpt',
        'UNIT_v1/v2 preflight receipts and corresponding records',
        'Every original exploratory/current/first-result JSON section, assertion and typed scalar leaf',
        'Previous source receipt and original constituent path/disposition list',
    ],
    'targeted_code_read': {
        'path': 'scripts/runner_cache.py',
        'scope': 'Declared-input parsing/fingerprint, parent-directory stat guard, capture comparison, cache read/write and freshness functions; complete file pinned.',
    },
    'reused_reviews': [
        'Immutable canonical source review (proof/source/port/IO/helper closure).',
        'Immutable original and affected exploratory numerical reviews (independent physics calculation and actual source mutations).',
    ],
    'no_claim_of_new_science_recomputation': True,
    'source_reference_count': len(freeze['sources']),
})

refs = []
for row in freeze['sources']:
    for path, expected in [(row['path'], row['sha256']), (row['snapshot'], row['snapshot_sha256'])]:
        item = digest(Path(path))
        if item['sha256'] != expected:
            raise RuntimeError('Changed frozen source: ' + path)
        refs.append(item)
for p in sorted(E.rglob('*')):
    if p.is_file():
        refs.append(digest(p))
unique = {}
for item in refs:
    old = unique.setdefault(item['path'], item)
    if old != item:
        raise RuntimeError('Inconsistent path identity: ' + item['path'])

write('FINAL_RECEIPT_v1.json', {
    'schema': 'canonical-execution-confirmation-v1',
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer_session': '/root/direct_quantum_visibility_review',
    'scientific_author': '/root',
    'disposition': 'Completed canonical output/capture matches the independently reviewed exploratory v2 and original 15-path source. Final package/metadata and combined gate remain pending; no audit or landing authority.',
    'source': {'base': result['base'], 'commit': result['commit'], 'tree': result['tree']},
    'report': digest(E / 'EXECUTION_CONFIRMATION_v1.md'),
    'checks': digest(E / 'CHECK_RESULTS_v1.json'),
    'recipe': digest(E / 'check_execution_identity_v1.py'),
    'counts': result['counts'],
    'typed_leaf_comparisons': sum(x['count'] for x in result['typed_leaf_counts']),
    'result_sha256': result['result_sha256'], 'cache_sha256': result['cache_sha256'],
    'input_fingerprint': result['input_fingerprint'],
    'cache_freshness': result['owning_read_only_api'],
    'original_dispositions': {**digest(E / 'ORIGINAL_CONSTITUENT_DISPOSITIONS_v1.json'), 'json_pointer': '/original_dispositions'},
    'scope_limits': [
        'No author module import or science execution; exact results compared after only declared bookkeeping.',
        'First-capture diagnostic has a labelled selected tool-output transcription, not full raw-log recovery.',
        'No exact first-run timing is inferred.',
        'No final metadata/tree confirmation or combined integration gate performed.',
    ],
    'original_source_snapshots': freeze['sources'],
    'all_bound_paths': sorted(unique.values(), key=lambda x: x['path']),
    'verification': {'unique_bound_paths': len(unique), 'all_originals_and_snapshots_rehashed': True},
    'self_reference': 'Receipt excluded from its own manifest; report final receipt hash separately.',
})
print(json.dumps({'receipt': digest(E / 'FINAL_RECEIPT_v1.json'), 'report': digest(E / 'EXECUTION_CONFIRMATION_v1.md'), 'unique_bound_paths': len(unique)}, indent=2))
