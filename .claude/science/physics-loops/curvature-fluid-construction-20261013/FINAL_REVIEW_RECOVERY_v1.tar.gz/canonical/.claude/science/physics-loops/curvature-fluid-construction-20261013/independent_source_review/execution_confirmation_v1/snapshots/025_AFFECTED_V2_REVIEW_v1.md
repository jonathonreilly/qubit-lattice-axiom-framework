# Affected independent check — curvature/fluid reconstruction v2

**The two original assertion-coverage findings are closed for this frozen v2
source and its supplied finite grid.** All three exact surviving mutations
now fail mathematical checks with all 12 fresh input hashes passing. The
original scientific calculations and output are unchanged. This is a narrow
affected-source check, not a formal audit, empirical acceptance, publication
gate or claim of universal corruption resistance.

## Exact source and unchanged science

- V2 runner: `78a801465c3cdb7f580d144ac2b7df33dc92431a1232cf5fe2b1259962108fd8`.
- V2 first result: `00cbf3046793033d3ed96d56fc18a7ea32e1d7ac8b41a13b6eb5cfbaa7cc01da`.
- Original v1 runner: `2aab63f2e6acca63eecba32d5b1f932abd6fffdfcd964ef3e2e3aea26ebc8f92`.
- Original v1 result: `e58a6d43772f8c6904316ebe1ccaed459619816ee0baac33d655403dce90485b`.

The parent's first frozen v2 execution completed in 3.808 seconds, reporting
**6663 passed, zero failed** and unchanged inputs. All 12 original non-main
functions are text- and AST-identical. Removing only the new control function,
the stored-mass checking loop and its call recovers the complete original module
AST. The saved raw diff is exact. No original tolerance, source equation,
numerical producer, history integrator or initial fixture has changed.

All nine complete scope/scientific sections excluding the symbolic summary are
byte-identical under canonical JSON serialization, with every leaf and type
compared. The three symbolic physics strings are also unchanged. The sole
symbolic-summary difference is its bookkeeping count, **33 -> 36**, because
that count includes source hashes and three frozen inputs were added. There
are still 24 original symbolic physics assertions. No scientific change is
hidden in this bookkeeping exception.

All **5786 original non-source assertion objects** are unchanged. V2 adds
288 stored-mass controls, 576 general-state component controls and one new
case census, plus three source-hash checks. This exactly accounts for
5795 -> 6663. Every one of the original review receipt's 197 distinct paths
remains exact. Its source, report, failed reviewer fixture, original mutation
outcomes and successful 32831/0 calculation remain immutable.

## New evolution controls

The parent added 72 states with finite nonzero u and u velocity across the new
fixture Cartesian product. Its oracle independently differentiates the supplied
Einstein field metric and potential with SymPy, then obtains acceleration from
covariant momentum evolution. It calls the production RHS only as the actual
value under test; the production metric-derivative helper does not supply the
oracle's derivatives.

The affected reviewer check uses another route: reconstruct the metric as
Z/F plus its Weyl contribution, numerically differentiate the action at
110-digit precision using mpmath, and form each Christoffel contraction
explicitly. It compares all 576 stored expected components and all 576 actual
components with that independent result. It does not import the parent's new
oracle or repeat the old positive parameter-grid/history calculation.

All 72 new states are in the positive Friedmann chart. The largest kinetic
norm is approximately .0431205, well below three. The maximum normalized
discrepancy for the stored oracle is 5.76e-15, and for the stored production
RHS it is 9.23e-15, below the declared 2e-10 threshold. This is a finite sample
of the general equations, not a claim about all initial states or stability.

## New mass-output controls

The added loop reads the actual constructed mass rows and independently
reconstructs the physical-frame mass formulas with exact rational parameters.
It checks each row's three-entry shape and all 216 values. The affected review
compares those expected values with the previously saved independent action
Hessian calculation rather than rerunning that successful calculation.
The largest normalized difference is 3.52e-75.

The original row-count/identity checks remain. Together with the current
independent output comparison, the new loop binds the displayed physical masses
and detects the demonstrated missing frame conversion. This is not a claim
that arbitrary coordinated corruption of both labels and oracles is impossible.

The affected source/identity/new-oracle check completed **19083 passed, zero
failed**. These include preservation and object-comparison checks; they are
not 19083 additional physical experiments. The complete results and newly
computed 72-case reference are saved in `AFFECTED_RESULTS_v1.json` and
`INDEPENDENT_NEW_CONTROL_REFERENCE_v1.json`.

## Repeated actual survivors

Only the three original surviving substitutions were repeated, once each.
Each copied source uses a fresh complete freeze of all 12 actual inputs.
Assertions and tolerances are untouched. Every trial completes with a full
result, exit code 1, empty stderr and no timeout. All source checks pass, so
these are mathematical failures rather than identity failures.

| Exact repeated source mutation | Passed | Failed | New detection |
|---|---:|---:|---|
| Force u acceleration to zero | 6591 | 72 | All general-state u equations |
| Zero partial_u K_u | 6615 | 48 | General-state u equations for s>0 |
| Serialize Einstein masses as physical masses | 6519 | 144 | Stored physical mass comparisons |

Each trial still passes the original 5786 non-source assertions. Only the new
controls detect these corruptions, confirming the repairs address the original
gaps rather than silently relying on a changed old tolerance or source hash.
The s=0 derivative vanishes, so its 24 general-state cases correctly do not
fail the derivative mutation. The wrong-frame mass mutation affects the three
mass entries in each of the original 48 s>0 rows, explaining 144 failures.

`MUTATION_EVIDENCE_VERIFICATION_v1.json` checks the saved exact substitutions,
all fresh input hashes, unchanged inputs, old assertion outcomes and complete
new failure-name sets without rerunning the trials. Raw failed results and
their source/diff/execution histories remain preserved.

## Scope clarification and final disposition

`SCOPE_CLARIFICATION_v2.md` correctly narrows the earlier b=a,zeta=0 comparison.
The K,V,A functions reduce to the prior analytic-fluid functions. Equality of
local bulk field equations also uses a fixed q sector and C=0; the supplied
orbit condition gives C=0 at s=0. The auxiliary/form action and boundary
constraints are still present. Neither a parameter substitution nor this
clarification removes them. No displayed equation or original evidence is
changed. This is a legitimate scope clarification, not a new action result.

R1 and R2 from the original numerical review are closed at the scope above.
No additional material correction was found. The original numerical reference
continues to support the unchanged science and has not been rerun. All prior
local-action, finite-state, ideal-fluid, weak-body, scale and calibration
limitations remain; there are zero new empirical tests or thermal-network
predictions.

Two non-scientific file-inspection commands returned file-not-found: the first
tried an incorrect correction filename; the final receipt inspection initially
used the parent of an unresolved relative path. Both errors and their concrete
recoveries are preserved. The actual correction and original receipt were then
read successfully. No scientific execution was affected.
No unexpected numerical failure occurred in this affected check. The prior
reviewer's real fixture failure remains bound by the original immutable receipt.

The affected review writes only its own directory. The final receipt binds
current/snapshot source identities, the original review closure, all added
reviewer calculations and all three actual mutation failures. No Git action,
formal audit, source edit, model change or deadline extension was performed.
