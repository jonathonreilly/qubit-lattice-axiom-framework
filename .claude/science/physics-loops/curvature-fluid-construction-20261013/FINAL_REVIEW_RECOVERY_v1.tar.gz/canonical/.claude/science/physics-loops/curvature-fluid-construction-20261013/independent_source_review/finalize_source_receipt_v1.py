#!/usr/bin/env python3
"""Hash/disposition finalization only. No scientific execution."""
from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, sys

R=Path(__file__).resolve().parent
P=R.parent
W=P.parents[3]
NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def load(p):return json.loads(Path(p).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def pin(p):
    p=Path(p).resolve();data=p.read_bytes()
    return dict(path=str(p),sha256=sha(data),bytes=len(data))
def save(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')

initial=load(R/'SOURCE_FREEZE_v1.json')
final=load(R/'SOURCE_FREEZE_FINAL_v2.json')
by_path={x['path']:x for x in final['source_paths']}
unit=final['unit']
for row in final['source_paths']:
    assert pin(W/row['path'])['sha256']==row['sha256']
    assert pin(row['snapshot'])['sha256']==row['sha256']
    assert sha(subprocess.check_output(['git','show',':'+row['path']],cwd=W))==row['sha256']
for row in initial['source_paths']:
    assert pin(row['snapshot'])['sha256']==row['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==unit['head']
assert subprocess.run(['git','diff','--cached','--quiet',unit['tree']],cwd=W).returncode==0

commands=[]
for cmd in [['git','diff','--check'],['git','diff','--cached','--check'],['git','diff',unit['base'],'--check'],['git','ls-remote','origin','refs/heads/main']]:
    result=subprocess.run(cmd,cwd=W,capture_output=True,text=True)
    commands.append(dict(command=cmd,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
    assert result.returncode==0
assert commands[-1]['stdout'].split()[0]==unit['base']
save('FINAL_SOURCE_COMMANDS_v1.json',dict(at=NOW,commands=commands,source_execution='Not run; no cache or pipeline invocation.'))

recovery=load(R/'RECOVERY_VERIFICATION_v1.json')
assert len(recovery['members'])==348 and recovery['complete_exploratory_paths']==344
assert all(x['archive_mode']==x['original_mode'] for x in recovery['members'])
roles={
 'CLAIM_STATUS_CERTIFICATE.md':'Source-status summary only; supplied assumptions and unset audit authority are explicit.',
 'EXPLORATORY_RECOVERY_v1.tar.gz':'Complete historical source/evidence/review recovery, all members verified; no current runtime or implicit proof dependency.',
 'GOAL.md':'Scoped planning target and explicit constructive premises; no independent theorem beyond canonical source.',
 'HANDOFF.md':'Historical execution and review counts, provenance, and pending canonical execution/gates; no inferred canonical PASS.',
 'PORT_FUNCTION_IDENTITY_v1.json':'Port provenance and exact unchanged function inventory, independently checked.',
 'PORT_v1.diff.gz':'Losslessly compressed exact current original-to-canonical diff, independently regenerated.',
 'RECOVERY_v1.json':'Complete exact archive-member path/hash/size map, independently verified.',
 'REVIEW_HISTORY.md':'Historical original failures/corrections and pending canonical checks; no formal audit judgment.',
 'STATE.yaml':'Current source-prepared and canonical-not-run state; later execution requires a new evidence confirmation.',
 'TRACE_GATE.md':'Frontier trace with unknown TOE reachability; no closed observed-TOE dependency.',
 'CURVATURE_FLUID_CONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md':'Corrected complete self-contained local constructive proof; all candidate action and measurement bridges explicit.',
 'NUMERICAL_FIXTURES_v1.json':'Supplied synthetic grid, original JSON values unchanged; one terminal blank line removed.',
 'OFF_TRAJECTORY_FIXTURES_v2.json':'Supplied finite state/velocity controls, exact original bytes retained.',
 'imports.json':'Explicit candidate, calibration, PPN and ideal-species premises; no empirical or framework-derived promotion.',
 'curvature_fluid_construction_2026_10_13.py':'Reviewed canonical port; all 13 non-main functions and complete main scientific computation unchanged. Canonical execution pending.'}
rows=[]
for row in final['source_paths']:
    rows.append(dict(original_path=row['path'],original_sha256=row['sha256'],
        disposition='accepted source preparation; '+roles[Path(row['path']).name],
        recovery='Exact final preparation snapshot: '+row['snapshot'],
        final_path=row['path'],final_sha256=row['sha256']))
initial_rows=[]
for row in initial['source_paths']:
    final_path=row['path']+'.gz' if row['path'].endswith('/PORT_v1.diff') else row['path']
    new=by_path[final_path]
    changed=row['sha256']!=new['sha256'] or row['path']!=final_path
    why='Superseded initial preparation: vacuum-subtraction label corrected or exact port/EOF packaging updated; original bytes preserved.' if changed else 'Accepted unchanged in final preparation.'
    initial_rows.append(dict(original_path=row['path'],original_sha256=row['sha256'],disposition=why,recovery='Exact initial snapshot: '+row['snapshot'],final_path=final_path,final_sha256=new['sha256']))
exploratory=[]
for member in recovery['members']:
    name=Path(member['original_path']).name
    final_path=None
    if member['original_path'].endswith('/direct_curvature_fluid_reconstruction/check_curvature_fluid_v2.py'):
        final_path='scripts/curvature_fluid_construction_2026_10_13.py'
        why='Superseded by reviewed canonical port; unchanged scientific function/main body, changed location/guard/IO.'
    elif member['original_path'].endswith('/direct_curvature_fluid_reconstruction/HAND_DERIVATION_v1.md'):
        final_path='docs/CURVATURE_FLUID_CONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md'
        why='Adopted local constructive mathematics restated in full and expanded, with explicit dynamical-matter split; original historical source preserved.'
    elif any(member['original_path'].endswith('/direct_curvature_fluid_reconstruction/'+n) for n in ['NUMERICAL_FIXTURES_v1.json','OFF_TRAJECTORY_FIXTURES_v2.json']):
        final_path='outputs/curvature_fluid_construction_2026_10_13/'+name
        why='Active synthetic fixture port; JSON content identical, terminal whitespace normalization only where recorded.'
    else:
        why='Preserved complete historical source/evidence/review or failed attempt; reused only within the original exact review scope, not an unstated canonical proof premise or new physical claim.'
    exploratory.append(dict(original_path=member['original_path'],original_sha256=member['sha256'],disposition=why,
        recovery='Archive '+str(P/'EXPLORATORY_RECOVERY_v1.tar.gz')+' SHA256 '+recovery['archive']['sha256']+' member '+member['archive_path'],
        final_path=final_path,final_sha256=by_path[final_path]['sha256'] if final_path else None,
        archive_member=member['archive_path'],original_mode=member['original_mode'],bytes=member['bytes']))
save('SOURCE_DISPOSITIONS_v1.json',dict(at=NOW,reviewer='/root/direct_quantum_visibility_review',
    source_base=unit['base'],source_head_at_review=unit['head'],source_tree=unit['tree'],
    constituent_note='These 15 final-path rows bind staged source, not a fabricated commit. Coordinator supplies the actual original constituent commit endpoint when creating UNIT.',
    original_dispositions=rows,initial_preparation_dispositions=initial_rows,exploratory_dispositions=exploratory))

governance=[
 'AGENTS.md','docs/ai_methodology/SCIENCE_WORKFLOW.md','docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md',
 'docs/ai_methodology/skills/review-loop/SKILL.md',
 *['docs/ai_methodology/skills/review-loop/references/'+n+'.md' for n in ['REVIEW_SETUP','REVIEW_UNITS','UNIT_RECEIPT','SCIENCE_LENSES','FIXES_AND_REPORTING','OPERATIONS','AUDIT_COMPATIBILITY']],
 'docs/ai_methodology/skills/physics-loop/references/proof-search-governance.md',
 'docs/MINIMAL_AXIOMS_2026-06-29.md','docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md',
 'docs/audit/data/axiom_premise_nodes.json','docs/repo/REVIEW_FEEDBACK_WORKFLOW.md',
 'docs/repo/DEFERRED_DECISIONS.md','docs/repo/CONTROLLED_VOCABULARY.md','docs/audit/README.md',
 'docs/repo/ACTIVE_REVIEW_QUEUE.md','docs/CANONICAL_HARNESS_INDEX.md']
tooling=[
 'docs/audit/scripts/build_citation_graph.py','docs/audit/scripts/static_pipeline_checkpoint.py',
 'scripts/runner_cache.py','scripts/audit_packet_script_deps.py','docs/audit/scripts/ledger_io.py',
 'docs/ai_methodology/skills/review-loop/scripts/review_receipt.py',
 'docs/audit/data/doc_authority_registry.json','docs/audit/data/runner_timeout_declarations.json']
save('CONTEXT_AND_TOOLING_PINS_v1.json',dict(at=NOW,governance=[pin(W/p) for p in governance],tooling=[pin(W/p) for p in tooling if (W/p).exists()],
    reading_boundary='Entry point and all routed references, workflow, axiom memo, registry/check and feedback workflow read completely. Remaining governance surfaces inspected for relevant scope/status/reservations/harness rows, not treated as physics evidence. Tool parser functions read and invoked without their main/generation entry points.'))
save('READING_LEDGER_v1.json',dict(at=NOW,
    complete_current_scientific_source=[x['path'] for x in final['source_paths'] if x['path'].startswith(('docs/','scripts/','outputs/'))],
    complete_metadata_read=[x['path'] for x in final['source_paths'] if x['path'].startswith('.claude/') and not x['path'].endswith(('.gz','RECOVERY_v1.json'))],
    full_inventory='All 348 recovery manifest entries and archive payloads verified, including exact original bytes/modes; full 344-file exploratory directory census.',
    prior_review_reuse='Original full action/numerical review and affected v2 review in the same reviewer session reused under exact pins; no original positive rerun.',
    other_review_read='Complete archived handwritten CURVATURE_FLUID_MATH_REVIEW.md and affected_scope_v2/SCOPED_CONFIRMATION.md; complete launch_check PRIOR_SOURCE_SCOPE_REPORT_v1.md, with its original source-search limits preserved.',
    original_dispositions='SOURCE_DISPOSITIONS_v1.json /original_dispositions is the reviewer-owned 15-path UNIT-compatible mapping.',
    new_math='Full manual canonical proof check plus exact independent two-field Euler–Lagrange, expanded connection, acceleration/force and vacuum accounting controls.',
    unchanged_math='Previously independent raw-action derivative, whole-grid/Hessian/normalization/inverse/ideal-species and canonical-momentum history controls reused.',
    no_new_primary_input='No new empirical dataset, external theorem or primary numerical value imported. Read-only git remote baseline check only.',
    unrun=['canonical positive runner','UNIT checker','runner-cache capture','full graph build','combined pipeline/strict lint/changed evidence','formal audit','landing']))
import mpmath, numpy, scipy, sympy
save('EXECUTION_RECORD_v1.json',dict(at=NOW,python=sys.version,executable=sys.executable,platform=platform.platform(),
    packages={m.__name__:m.__version__ for m in [mpmath,numpy,scipy,sympy]},
    source_control=dict(command='PYTHONDONTWRITEBYTECODE=1 /usr/local/bin/python3 check_source_port_v1.py > SOURCE_CHECK_stdout_v1.txt 2> SOURCE_CHECK_stderr_v1.txt',
        first_tool_chunk='ea093f',session_id=39796,completed_tool_chunk='c3e5ab',exit_code=0,counts=load(R/'SOURCE_CHECK_RESULTS_v1.json')['counts']),
    owned_process_state='Only bounded source-check session 39796 was launched by this review; tool confirms final exit 0. No author process launched or interfered with.',
    scientific_execution='No full scientific runner execution; actual extracted IO uses synthetic result objects only.',
    original_preparation_failure=pin(R/'runtime_snapshots/INITIAL_DIFF_CHECK_v1.json'),
    preparation_recovery='Raw diff compressed; canonical EOF whitespace trimmed; original bytes preserved.',
    source_finding='Vacuum double-count notation corrected before execution; explicit Gamma_m^dyn confirmed.',
    focused_check_failures=0))

receipt_path=R/'FINAL_SOURCE_RECEIPT_v1.json'
assert not receipt_path.exists()
refs=[]
for row in initial['source_paths']+final['source_paths']:
    refs.append(dict(path=row['snapshot'],sha256=row['sha256']))
for row in final['source_paths']:refs.append(dict(path=str(W/row['path']),sha256=row['sha256']))
for row in recovery['members']:refs.append(dict(path=row['original_path'],sha256=row['sha256']))
for name in ['PRIOR_SOURCE_SCOPE_REPORT_v1.md','FINAL_RECEIPT_v1.json']:
    refs.append(pin(P/'prior_art_review'/name))
for x in load(R/'CONTEXT_AND_TOOLING_PINS_v1.json').values():
    if isinstance(x,list):refs.extend(x)
artifacts=[pin(p) for p in sorted(R.rglob('*')) if p.is_file() and p!=receipt_path]
unique={}
for row in refs+artifacts:
    actual=pin(row['path']);assert actual['sha256']==row['sha256'],(row,actual)
    if row['path'] in unique:assert unique[row['path']]['sha256']==row['sha256']
    unique[row['path']]=actual
receipt=dict(schema='canonical-pre-execution-source-review-v1',at=NOW,
    reviewer_session='/root/direct_quantum_visibility_review',author='/root',
    disposition='Source-ready for actual cheap UNIT preflight; canonical execution, cache/final confirmation and combined gate pending. No formal audit or landing authority.',
    base=unit['base'],head=unit['head'],staged_tree=unit['tree'],
    source_paths=unit['paths'],report=pin(R/'CANONICAL_SOURCE_REVIEW_v1.md'),
    original_dispositions_reference=dict(**pin(R/'SOURCE_DISPOSITIONS_v1.json'),json_pointer='/original_dispositions'),
    independent_controls=pin(R/'check_source_port_v1.py'),independent_results=pin(R/'SOURCE_CHECK_RESULTS_v1.json'),
    counts=load(R/'SOURCE_CHECK_RESULTS_v1.json')['counts'],
    findings=[dict(id='reduced_matter_vacuum_double_count',kind='source action notation',status='closed',
       original_note_sha256='11cb4fa5764a12aa9978539cfb847c2f50eea790d810777d8381647a1b129b1e',
       final_note_sha256='5bc43c79d36e7eae654be140c778ce562edf6ff49a5d6bbe8492ac6dc03f853d',
       correction=pin(R/'runtime_snapshots/VACUUM_LABEL_CORRECTION_v2.diff'))],
    source_proof_disposition='Conditional proof complete within stated supplied classical action/local exchange/domain; no empirical or retained-grade verdict.',
    source_discovery=load(R/'DISCOVERY_v1.json'),
    expected_canonical_bookkeeping=dict(non_source_assertions=6651,symbolic_count=24,removed_exploratory_hash_assertions=12,execution='not run'),
    recovery=dict(members=348,complete_exploratory_files=344,all_modes_match=True,manifest=pin(P/'RECOVERY_v1.json'),archive=pin(P/'EXPLORATORY_RECOVERY_v1.tar.gz')),
    original_and_context_refs=refs,review_artifacts=artifacts,
    verification=dict(unique_paths=len(unique),all_verified=True,original_reviews_unchanged=True),
    self_reference='This receipt excludes its own bytes; final message supplies its SHA256.')
save('FINAL_SOURCE_RECEIPT_v1.json',receipt)
print(json.dumps(dict(report=pin(R/'CANONICAL_SOURCE_REVIEW_v1.md'),dispositions=pin(R/'SOURCE_DISPOSITIONS_v1.json'),receipt=pin(receipt_path),verified_unique_paths=len(unique)),indent=2))
