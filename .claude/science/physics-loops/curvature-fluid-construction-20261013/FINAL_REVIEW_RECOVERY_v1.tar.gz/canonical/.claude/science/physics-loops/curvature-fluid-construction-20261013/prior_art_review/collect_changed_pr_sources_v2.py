import pathlib,json,subprocess,datetime,hashlib
OUT=pathlib.Path(__file__).resolve().parent
REPO='jonathonreilly/qubit-lattice-axiom-framework'
prs=json.loads((OUT/'OPEN_PRS_INITIAL_v1.json').read_text());by={p['number']:p for p in prs}
records=[];sources=[]
def call(name,args):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,capture_output=True)
 path=OUT/'commands'/name;path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as f:f.write(p.stdout)
 ep=path.with_name(path.name+'.stderr.txt')
 with ep.open('xb') as f:f.write(p.stderr)
 records.append({'command':args,'started_at':t,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':str(path),'sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':str(ep),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
 if p.returncode:raise RuntimeError(p.stderr.decode())
 return p.stdout
try:
 for number in [9512,9513,9514,9515]:
  files=json.loads(call('PR'+str(number)+'_FILES_v2.json',['gh','api','--paginate','--slurp','repos/'+REPO+'/pulls/'+str(number)+'/files?per_page=100']))
  files=[entry for page in files for entry in page]
  wanted=[e for e in files if e['filename'].startswith('docs/') and e['filename'].endswith('.md') and e['filename'].count('/')==1]
  if number==9514:
   wanted += [e for e in files if e['filename']=='outputs/analytic_fluid_cosmology_2026_10_13/imports.json']
  for e in wanted:
   name=e['filename'];head=by[number]['head']['sha'];data=call('PR'+str(number)+'_'+pathlib.Path(name).name,['gh','api','-H','Accept: application/vnd.github.raw+json','repos/'+REPO+'/contents/'+name+'?ref='+head])
   target=OUT/'source_snapshot'/('pr_'+str(number))/name;target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as f:f.write(data)
   sources.append({'pr':number,'head':head,'base':by[number]['base']['sha'],'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'snapshot':str(target),'status':e['status'],'coverage':'captured; reading scope recorded separately'})
  print(number,'changed paths',len(files),'captured canonical notes/imports',len(wanted),flush=True)
finally:
 with (OUT/'CHANGED_PR_COLLECTION_v2.json').open('x') as f:json.dump({'commands':records,'sources':sources},f,indent=2);f.write('\n')
