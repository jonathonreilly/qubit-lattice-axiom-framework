"""One-shot source/receipt bookkeeping; never runs science or changes Git."""
import datetime
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[4]
MAIN = '516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
PLAN = '3a4b2c66a1ead7a1c48b4359627e968f681e3c39'
OLD = pathlib.Path('/Users/jonBridger/.codex/worktrees/analytic-fluid-construction-20261013/New Axioms Lets Go/.claude/science/physics-loops/analytic-fluid-construction-20261013/independent_source_review')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), sha256=digest(data), bytes=len(data))


def write_new(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


checks = []


def check(name, condition, details=None):
    checks.append(dict(name=name, satisfied=bool(condition), details=details))


remote = json.loads((OUT / 'FINAL_REMOTE_IDENTITY_v1.json').read_text())
check('closing remote main is pinned baseline', remote['main_sha'] == MAIN)
check('closing inventory has no new, closed or moved head/base', not any(remote[k] for k in ['new_open_prs', 'no_longer_open_prs', 'changed_head_or_base']))
by_head = {r['head']: r for r in remote['final_heads']}
sources = json.loads((OUT / 'SOURCE_DISPOSITIONS_v1.json').read_text())['source_dispositions']
check('source snapshot labels are unique', len(sources) == len({r['snapshot'] for r in sources}) == 60)
for row in sources:
    snap = pathlib.Path(row['snapshot'])
    data = snap.read_bytes()
    check('snapshot ' + str(snap.relative_to(OUT)), digest(data) == row['sha256'] and len(data) == row['bytes'])
    if row['origin_commit'] == MAIN:
        r = subprocess.run(['git', 'show', MAIN + ':' + row['original_path']], cwd=ROOT, capture_output=True)
        check('pinned-main blob ' + row['original_path'], r.returncode == 0 and digest(r.stdout) == row['sha256'])
    elif row.get('open_pr') is not None:
        check('current-head source ' + row['original_path'], row['origin_commit'] in by_head and by_head[row['origin_commit']]['number'] == row['open_pr'])
    elif pathlib.Path(row['original_path']).is_absolute():
        original = pathlib.Path(row['original_path'])
        check('unchanged local original ' + row['original_path'], original.is_file() and digest(original.read_bytes()) == row['sha256'])

instructions = json.loads((OUT / 'INSTRUCTION_IDENTITIES_v1.json').read_text())['records']
for row in instructions:
    r = subprocess.run(['git', 'show', row['ref'] + ':' + row['path']], cwd=ROOT, capture_output=True)
    check('instruction blob ' + row['ref'] + ':' + row['path'], r.returncode == 0 and digest(r.stdout) == row['sha256'] and digest(pathlib.Path(row['snapshot']).read_bytes()) == row['sha256'])

old_receipt = json.loads((OLD / 'RECEIPT_v1.json').read_text())
old_report = binding(OLD / 'REPORT_v1.md')
old_final = binding(OLD / 'FINAL_BINDING_v1.json')
check('reused canonical review report matches its original receipt', old_report['sha256'] == old_receipt['review_report']['sha256'])
check('reused canonical final binding matches original receipt', old_final['sha256'] == old_receipt['final_identity_verification']['sha256'])
old_science = {r['path']: r for r in old_receipt['sources']}
comparisons = []
for row in sources:
    if row.get('open_pr') == 9514:
        prior = old_science.get(row['original_path'])
        check('PR9514 unchanged reviewed source ' + row['original_path'], prior is not None and prior['sha256'] == row['sha256'])
        comparisons.append(dict(path=row['original_path'], current_pr_head=row['origin_commit'], prior_source_commit=prior['commit'] if prior else None, sha256=row['sha256']))
copied = []
dest = OUT / 'reused_analytic_canonical_review'
dest.mkdir(exist_ok=True)
for name in ['REPORT_v1.md', 'RECEIPT_v1.json', 'FINAL_BINDING_v1.json']:
    original = OLD / name
    path = dest / name
    with path.open('xb') as f:
        f.write(original.read_bytes())
    copied.append(dict(original=binding(original), recovery=binding(path)))
write_new('REUSED_CANONICAL_REVIEW_BINDING_v1.json', dict(created_at=now(), purpose='Recover prior complete exact-note reading for comparison; no PASS or global theorem transferred to changed curvature model.', records=copied, unchanged_scientific_sources=comparisons, recovery_limit='These three reports/bindings are copied exactly. Their entire original supporting-evidence tree is not claimed recovered in this folder.'))

previous_errors = json.loads((OUT / 'READ_FAILURES_v2.json').read_text())
attempts = previous_errors['attempts'] + [dict(command_type='Inline Python inspection of prior canonical review evidence', exit_code=1, actual_error='FileNotFoundError: independent_source_review/FINAL_RECEIPT_v1.json', resolution='Directory inventory supplied the correct RECEIPT_v1.json name. It and FINAL_BINDING_v1.json were read, the full original report re-read, and their exact receipt bindings verified.', scientific_test_failure=False)]
write_new('READ_FAILURES_v3.json', dict(created_at=now(), previous_record=binding(OUT / 'READ_FAILURES_v2.json'), attempts=attempts, all_read_errors_resolved=True, no_scientific_execution=True))

args = ['git', 'rev-parse', 'HEAD', 'origin/main', 'origin/ai/execution']
local = subprocess.run(args, cwd=ROOT, capture_output=True)
check('local ref read succeeded', local.returncode == 0)
refs = local.stdout.decode().splitlines()
check('local science and planning refs match assigned baseline', refs == [MAIN, MAIN, PLAN], refs)
verify = dict(created_at=now(), purpose='Identity/bookkeeping verification only, not mathematical tests or a gate run.', local_ref_command=args, local_ref_exit_code=local.returncode, local_ref_stdout=local.stdout.decode(), local_ref_stderr=local.stderr.decode(), checks=checks, unsatisfied=[r for r in checks if not r['satisfied']])
write_new('FINAL_VERIFICATION_v1.json', verify)

files = []
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name != 'FINAL_RECEIPT_v1.json':
        row = binding(path)
        row['relative_path'] = str(path.relative_to(OUT))
        files.append(row)
check_unique = len(files) == len({r['relative_path'] for r in files})
receipt = dict(created_at=now(), reviewer='/root/launch_check', author='/root', kind='Focused prior-source and constructive-scope advice', disposition='Coherent positive conditional scope can be independently authored; final canonical scientific review and all delivery gates remain pending.', report=binding(OUT / 'PRIOR_SOURCE_SCOPE_REPORT_v1.md'), dispositions=binding(OUT / 'SOURCE_DISPOSITIONS_v1.json'), final_identity_verification=binding(OUT / 'FINAL_VERIFICATION_v1.json'), remote_identity=binding(OUT / 'FINAL_REMOTE_IDENTITY_v1.json'), main=MAIN, planning=PLAN, scientific_source_snapshots=60, prior_source_snapshots_reused=44, preserved_operational_errors=3, unresolved_identity_errors=verify['unsatisfied'], evidence_paths_unique=check_unique, evidence_count=len(files), evidence=files, scientific_execution=False, formal_audit=False, mechanical_gate_execution=False, final_source_readiness_pass=False, literature_novelty_claim=False, transferred_prior_pass=False, git_mutation=False, external_messages=False, writes_limited_to=str(OUT), receipt_self_hash='Excluded by design; supplied externally after creation.')
write_new('FINAL_RECEIPT_v1.json', receipt)
print(json.dumps(dict(report=binding(OUT / 'PRIOR_SOURCE_SCOPE_REPORT_v1.md'), receipt=binding(OUT / 'FINAL_RECEIPT_v1.json'), evidence_count=len(files), scientific_source_count=60, identity_errors=len(verify['unsatisfied'])), indent=2))
if verify['unsatisfied'] or not check_unique:
    raise SystemExit(1)
