"""Author algebraic challenges of the declared classical canonical construction."""
from pathlib import Path
from itertools import product
import hashlib,json,time
import numpy as np
import sympy as s

HERE=Path(__file__).resolve().parent
PAULI=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
SP=[s.Matrix(m) for m in [[[0,1],[1,0]],[[0,-s.I],[s.I,0]],[[1,0],[0,-1]]]]
BASIS=[]
for i in range(3):
 for j in range(i,3):
  b=np.zeros((3,3));b[i,j]=b[j,i]=1;BASIS.append(b)
SB=[s.Matrix(b).applyfunc(s.Rational) for b in BASIS]
rows=[]
def check(name,ok,**detail):
 assert bool(ok),(name,detail)
 rows.append(dict(name=name,**detail))
def near(name,x,y,tol=3e-8):
 err=float(np.max(np.abs(np.asarray(x)-np.asarray(y))))
 check(name,err<tol,max_residual=err,tolerance=tol)
def eq(name,x,y):
 z=x-y
 ok=all(s.simplify(t)==0 for t in z) if isinstance(z,s.MatrixBase) else s.simplify(z)==0
 check(name,ok)
def anti(x):return (x-x.T)/2
def rho(x):return sum((x[a,b]*PAULI[a]@PAULI[b]/4 for a,b in product(range(3),repeat=2)),np.zeros((2,2),complex))
def srho(x):return sum((x[a,b]*SP[a]*SP[b]/4 for a,b in product(range(3),repeat=2)),s.zeros(2))
def smat(prefix):
 x=s.symbols(prefix+'0:6',real=True)
 return s.Matrix([[x[0],x[1],x[2]],[x[1],x[3],x[4]],[x[2],x[4],x[5]]])
def sym(x):return (x+x.T)/2

def geometry(E,W):
 inv=np.linalg.inv(E);g=inv@inv;gi=E@E
 dg=np.array([-inv@w@g-g@w@inv for w in W])
 conn=np.zeros((3,3,3)) # upper, derivative, vector
 for k,i,j,l in product(range(3),repeat=4):
  conn[k,i,j]+=.5*gi[k,l]*(dg[i,l,j]+dg[j,i,l]-dg[l,i,j])
 gam=np.einsum('ia,amn->imn',E,PAULI)
 omega=np.array([inv@(W[j]+conn[:,j,:]@E) for j in range(3)])
 spin=np.array([rho(o) for o in omega]);trace=np.einsum('kkj->j',conn)
 hd=spin-trace[:,None,None]*np.eye(2)/2
 return dict(inv=inv,g=g,gi=gi,dg=dg,conn=conn,gam=gam,omega=omega,spin=spin,hd=hd)

def direct_operator(E,W):
 inv=np.linalg.inv(E);gam=np.einsum('ia,amn->imn',E,PAULI)
 divgam=sum((np.einsum('a,amn->mn',W[i,i,:],PAULI) for i in range(3)),np.zeros((2,2),complex))
 c=0.
 for a,b,cidx,i,j in product(range(3),repeat=5):
  c-=float(s.LeviCivita(a,b,cidx))*E[i,a]*W[i,j,b]*inv[cidx,j]/4
 return gam,-1j*divgam/2+c*np.eye(2)

def run():
 start=time.monotonic()
 # Normal-coordinate variation, with all eighteen first metric-jet components.
 jets=[smat('h'+str(i)) for i in range(3)]
 dw=[s.zeros(3) for _ in range(3)]
 for i,a,b in product(range(3),repeat=3):dw[i][a,b]=(jets[b][i,a]-jets[a][i,b])/2
 spinvar=-s.I*sum((SP[i]*srho(dw[i]) for i in range(3)),s.zeros(2))
 dtrace=s.Matrix([s.trace(jets[i]) for i in range(3)])
 div=s.Matrix([sum(jets[j][i,j] for j in range(3)) for i in range(3)])
 eq('normal_coordinate_spin_connection_variation',spinvar,-s.I*sum(((dtrace[i]-div[i])*SP[i]/4 for i in range(3)),s.zeros(2)))
 eq('half_density_trace_gradient_cancellation',spinvar+s.I*sum((dtrace[i]*SP[i]/4 for i in range(3)),s.zeros(2)),s.I*sum((div[i]*SP[i]/4 for i in range(3)),s.zeros(2)))
 # Darboux calculation at a generic rational positive frame.
 E=s.Matrix([[3,1,0],[1,4,1],[0,1,2]]);inv=E.inv()
 x0,y0,x1,y1=s.symbols('x0 y0 x1 y1',real=True);psi=s.Matrix([x0+s.I*y0,x1+s.I*y1]);psid=s.conjugate(psi).T
 aa=[anti(inv*b) for b in SB];aval=[s.expand((s.I*psid*srho(a)*psi)[0]) for a in aa]
 def pb(f,h):return sum((s.diff(f,x)*s.diff(h,y)-s.diff(f,y)*s.diff(h,x))/2 for x,y in [(x0,y0),(x1,y1)])
 for i in range(6):
  eq('Darboux_momentum_spinor_'+str(i),s.Matrix([-pb(aval[i],z) for z in psi]),srho(aa[i])*psi)
  for j in range(i+1,6):
   deriv=anti(-inv*SB[i]*inv*SB[j])+anti(inv*SB[j]*inv*SB[i])
   curv=deriv+aa[i]*aa[j]-aa[j]*aa[i]
   expected=-(sym(inv*SB[i])*sym(inv*SB[j])-sym(inv*SB[j])*sym(inv*SB[i]))
   eq('connection_curvature_'+str((i,j)),curv,expected)
   eq('Darboux_momentum_curvature_'+str((i,j)),(s.I*psid*srho(deriv)*psi)[0]+pb(aval[i],aval[j]),(s.I*psid*srho(curv)*psi)[0])
 h,k=smat('h'),smat('k')
 eq('identity_metric_curvature',-((-h/2)*(-k/2)-(-k/2)*(-h/2)),-(h*k-k*h)/4)
 # Generic curved-frame challenges. Finite differences are only challenges of P4.
 rng=np.random.default_rng(2026091308)
 for trial in range(8):
  Z=rng.normal(size=(3,3));E=np.eye(3)+Z@Z.T/7
  W=np.array([sym(rng.normal(size=(3,3)))/5 for _ in range(3)])
  V=sym(rng.normal(size=(3,3)))/4;U=np.array([sym(rng.normal(size=(3,3)))/6 for _ in range(3)])
  geo=geometry(E,W);inv=geo['inv'];g=geo['g'];gi=geo['gi'];gam,zero=direct_operator(E,W)
  near('Levi_Civita_frame_skew_'+str(trial),geo['omega']+geo['omega'].transpose(0,2,1),0,tol=3e-12)
  near('scalar_connection_matches_coordinate_geometry_'+str(trial),zero,-1j*sum((gam[i]@geo['hd'][i] for i in range(3)),np.zeros((2,2),complex)),tol=3e-12)
  A=anti(inv@V);dA=np.array([anti(-inv@W[i]@inv@V+inv@U[i]) for i in range(3)])
  eps=2e-5;gp,zp=direct_operator(E+eps*V,W+eps*U);gm,zm=direct_operator(E-eps*V,W-eps*U)
  dgamm=(gp-gm)/(2*eps);dzero=(zp-zm)/(2*eps)
  covgam=np.array([dgamm[i]+rho(A)@gam[i]-gam[i]@rho(A) for i in range(3)])
  covzero=dzero+rho(A)@zero-zero@rho(A)+1j*sum((gam[i]@rho(dA[i]) for i in range(3)),np.zeros((2,2),complex))
  h=-inv@V@g-g@V@inv
  dh=np.array([inv@W[i]@inv@V@g-inv@U[i]@g-inv@V@geo['dg'][i]-geo['dg'][i]@V@inv-g@U[i]@inv+g@V@inv@W[i]@inv for i in range(3)])
  covdh=np.array([dh[k]-geo['conn'][:,k,:].T@h-h@geo['conn'][:,k,:] for k in range(3)])
  divh=np.einsum('jk,kij->i',gi,covdh)
  hi=h@gi
  targetgam=-.5*np.einsum('ij,imn->jmn',hi,gam)
  targetzero=.5j*sum((gam[i]*hi[i,j]@geo['hd'][j] for i,j in product(range(3),repeat=2)),np.zeros((2,2),complex))+.25j*np.einsum('i,imn->mn',divh,gam)
  near('covariant_Dirac_principal_variation_'+str(trial),covgam,targetgam,tol=3e-9)
  near('covariant_Dirac_connection_variation_'+str(trial),covzero,targetzero,tol=3e-9)
  # Polar moment map agrees with intrinsic Kosmann expression at arbitrary jets.
  a=rng.normal(size=3);J=rng.normal(size=(3,3));rhs=J@E-E@J.T
  ev,rot=np.linalg.eigh(E);Om=rot@((rot.T@rhs@rot)/(ev[:,None]+ev[None,:]))@rot.T
  VE=-np.einsum('i,ijk->jk',a,W)+J@E-E@Om
  near('polar_frame_variation_symmetric_'+str(trial),VE,VE.T,tol=3e-12)
  AP=anti(inv@VE);K=anti(inv@J@E)-sum((a[i]*anti(inv@W[i]) for i in range(3)),np.zeros((3,3)))
  near('connection_polar_moment_map_'+str(trial),Om+AP,K,tol=3e-12)
  da=np.array([geo['dg'][i]@a+g@J[:,i] for i in range(3)])
  exterior=anti(da)
  kos=-1j*sum((a[i]*geo['spin'][i] for i in range(3)),np.zeros((2,2),complex))-.25j*sum((gam[i]@gam[j]*exterior[i,j] for i,j in product(range(3),repeat=2)),np.zeros((2,2),complex))
  near('Kosmann_matches_polar_moment_map_'+str(trial),1j*rho(K),kos,tol=3e-12)
  # Time component of the four-dimensional connection at zero shift and unit lapse.
  hdot=-inv@V@g-g@V@inv;Gamma_t=.5*gi@hdot
  omega_t=inv@(V+Gamma_t@E)
  near('spacetime_temporal_connection_'+str(trial),omega_t,A,tol=3e-12)
 # Generic contraction underlying the pure metric bracket, and independent torus witnesses.
 lam=s.symbols('lambda',real=True);mom,Hess=smat('p'),smat('n')
 eq('metric_curvature_lapse_contraction',s.trace((mom-lam*s.trace(mom)*s.eye(3))*(Hess-s.trace(Hess)*s.eye(3))),s.trace(mom*Hess)+(2*lam-1)*s.trace(mom)*s.trace(Hess))
 xx=s.symbols('x',real=True);N=1;M=s.cos(xx);drift=s.diff(M,xx)
 trace_witness=s.integrate(drift*s.diff(s.cos(xx),xx),(xx,0,2*s.pi))
 eq('trace_witness_nonzero',trace_witness,s.pi)
 eq('divergence_witness_coefficient',-2*trace_witness,-2*s.pi)
 # Native shift and spin vertices have the correct values at both node chiralities.
 z=s.symbols('zeta',real=True);v=s.sqrt(1-z*z);kx,ky,kz=s.symbols('kx ky kz',real=True)
 shift=s.Matrix([s.sin(kx),s.sin(ky),(z-s.cos(kz))*s.sin(kz)/v]);spin=s.Matrix([s.sin(kz)/v,s.sin(kz)/v,1])
 om=s.Matrix([[0,s.Symbol('u',real=True),s.Symbol('v0',real=True)],[-s.Symbol('u',real=True),0,s.Symbol('w0',real=True)],[-s.Symbol('v0',real=True),-s.Symbol('w0',real=True),0]])
 for chir in [-1,1]:
  node={kx:0,ky:0,kz:chir*s.acos(z)}
  eq('native_shift_node_'+str(chir),shift.subs(node).applyfunc(s.simplify),s.zeros(3,1))
  eq('native_shift_jet_'+str(chir),shift.jacobian([kx,ky,kz]).subs(node).applyfunc(s.simplify),s.diag(1,1,v))
  tau=[SP[0],SP[1],chir*SP[2]]
  spin_target=sum((om[a,b]*tau[a]*tau[b]/4 for a,b in product(range(3),repeat=2)),s.zeros(2))
  native=sum((s.I*sum(s.LeviCivita(a,b,c)*om[a,b] for a,b in product(range(3),repeat=2))*spin[c]*SP[c]/4 for c in range(3)),s.zeros(2))
  eq('native_temporal_spin_vertex_'+str(chir),native.subs(node).applyfunc(s.simplify),spin_target)
 result=dict(status='ok',check_count=len(rows),checks=rows,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-start,scope='Author exact algebra and finite-jet challenges; classical conditional closure is a written argument. No quantum constraint or axiom-selection claim.')
 (HERE/'BLOCK08_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':run()
