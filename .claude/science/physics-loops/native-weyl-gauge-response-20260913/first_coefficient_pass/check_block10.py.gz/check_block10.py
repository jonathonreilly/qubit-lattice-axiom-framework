"""Author challenges for one-loop cone and photon-medium coefficients.

This checks formal perturbative coefficients of a supplied model, not the
existence of its interacting continuum or a native qubit photon phase.
"""
from pathlib import Path
import hashlib,json,time
from itertools import product
import numpy as np
import sympy as s
from numpy.polynomial.legendre import leggauss
HERE=Path(__file__).resolve().parent
SIG=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
GAM=[np.kron(SIG[0],np.eye(2))]+[-np.kron(SIG[1],p) for p in SIG]
rows=[]
def check(name,ok,**detail):
 assert bool(ok),(name,detail)
 rows.append(dict(name=name,**detail))
def close(name,a,b,tol=1e-10,**detail):
 err=float(np.max(np.abs(np.asarray(a)-np.asarray(b))));check(name,err<tol,error=err,**detail)
def tf(A):return A-np.eye(len(A))*np.trace(A)/len(A)
def sym(A):return (A+A.T)/2
def slash(x):return sum((a*g for a,g in zip(x,GAM)),np.zeros((4,4),complex))
def sphere_grid(nx=32,nz=20,nphi=40):
 j=np.arange(1,nx+1);x=np.cos(np.pi*j/(nx+1));wx=2*np.sin(np.pi*j/(nx+1))**2/(nx+1)
 z,wz=leggauss(nz);phi=2*np.pi*np.arange(nphi)/nphi
 X,Z,P=np.meshgrid(x,z,phi,indexing='ij');rad=np.sqrt(1-X*X)
 n=np.stack([X,rad*np.sqrt(1-Z*Z)*np.cos(P),rad*np.sqrt(1-Z*Z)*np.sin(P),rad*Z],axis=-1).reshape(-1,4)
 w=np.broadcast_to(wx[:,None,None]*wz[None,:,None]/(2*nphi),X.shape).reshape(-1)
 return n,w
def parameter_matrix(E,count=96):
 x,w=leggauss(count);x=(x+1)/2;w=w/2;lam,Q=np.linalg.eigh(E);square=lam*lam
 A=x[:,None]+(1-x[:,None])*square[None,:]
 vals=-np.sum((w*x/np.sqrt(np.prod(A,axis=1)))[:,None]*(2*square-np.sum(square))[None,:]*lam[None,:]/A,axis=0)
 return (Q*vals)@Q.T
def angular_matrix(E,n,w):
 En=n@E.T;q2=np.sum(En*En,axis=1);metric=E.T@E
 avg=np.einsum('n,ni,nj->ij',w/q2**2,n,n)
 inside=E*np.sum(w/q2)-2*E@avg@metric
 return -(2*E@E.T-np.trace(E@E.T)*np.eye(4))@inside
def curl(k):
 x,y,z=k;return np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
def medium_kernel(n,W):
 k=n[1:];out=np.zeros((4,4));out[0,0]=k@W@k;out[0,1:]=-n[0]*(W@k);out[1:,0]=out[0,1:]
 C=curl(k);out[1:,1:]=n[0]**2*W+C.T@W@C
 return out
def metric_medium(V):
 det=np.linalg.det(V);M=V.T@V
 return M/det,det*np.linalg.inv(M)
def native_h(k,zeta=.7):
 return np.sin(k[0])*SIG[0]+np.sin(k[1])*SIG[1]+(2+zeta-np.cos(k[0])-np.cos(k[1])-np.cos(k[2]))*SIG[2]
def native_vertex(k,i,zeta=.7):
 vel=np.sqrt(1-zeta*zeta);D=np.array([1,1,vel]);return ((SIG[i]*np.cos(k[i]) if i<2 else 0)+SIG[2]*np.sin(k[i]))/D[i]

def run():
 start=time.monotonic();rng=np.random.default_rng(2026091310);n,w=sphere_grid()
 close('sphere_measure',w.sum(),1)
 close('sphere_second_moments',np.einsum('n,ni,nj->ij',w,n,n),np.eye(4)/4)
 fourth=np.einsum('n,ni,nj,nk,nl->ijkl',w,n,n,n,n);delta=np.eye(4)
 target=(np.einsum('ij,kl->ijkl',delta,delta)+np.einsum('ik,jl->ijkl',delta,delta)+np.einsum('il,jk->ijkl',delta,delta))/24
 close('sphere_fourth_moments',fourth,target)
 for i,j in product(range(4),repeat=2):close('Clifford_'+str((i,j)),GAM[i]@GAM[j]+GAM[j]@GAM[i],2*np.eye(4)*int(i==j))
 x,r=s.symbols('x r',positive=True);A=x+(1-x)*r*r
 # Substitution t=sqrt(A) gives elementary rational antiderivatives,
 # evaluated here without numerical parameter fitting.
 t=s.symbols('t',positive=True)
 I0=s.simplify(s.integrate(2*(t*t-r*r)/((1-r*r)**2*t*t),(t,r,1)))
 Is=s.simplify(s.integrate(2*(t*t-r*r)/((1-r*r)**2*t**4),(t,r,1)))
 check('time_parameter_integral',s.factor(I0-2/(1+r)**2)==0)
 check('space_parameter_integral',s.factor(Is-2*(2+r)/(3*r*(1+r)**2))==0)
 vd=s.factor(r*((1+r*r)*Is+(1-3*r*r)*I0)/8)
 check('scalar_speed_coefficient',s.factor(vd-(1-r)*(4*r*r+3*r+1)/(6*(1+r)**2))==0)
 cd=(r-1/r)/12;rd=s.factor(vd-r*cd)
 check('scalar_ratio_flow',s.factor(rd+(r-1)*(r**3+11*r*r+9*r+3)/(12*(r+1)**2))==0)
 check('scalar_relative_eigenvalue',s.limit(rd/(r-1),r,1)==-s.Rational(1,2))
 for ratio in [.6,.8,1.,1.3,1.8]:
  E=np.diag([1,ratio,ratio,ratio]);m=parameter_matrix(E)
  expected=np.diag([-(1-3*ratio**2)*2/(1+ratio)**2]+[(1+ratio**2)*2*(2+ratio)/(3*(1+ratio)**2)]*3)
  close('scalar_parameter_matrix_'+str(ratio),m,expected,2e-11)
  close('scalar_angular_matrix_'+str(ratio),angular_matrix(E,n,w),m,2e-8)
 for trial in range(8):
  C=sym(rng.normal(size=(4,4)));C/=np.linalg.norm(C);E=np.eye(4)+.3*C
  close('generic_parameter_angular_'+str(trial),parameter_matrix(E),angular_matrix(E,n,w),2e-10)
  errs=[]
  derivative=-5*C/3+2*np.trace(C)*np.eye(4)/3
  for step in [.008,.004,.002]:
   fd=(parameter_matrix(np.eye(4)+step*C)-parameter_matrix(np.eye(4)-step*C))/(2*step)
   errs.append(float(np.linalg.norm(fd-derivative)))
  check('generic_coframe_derivative_'+str(trial),errs[2]<1e-5 and errs[1]<.27*errs[0] and errs[2]<.27*errs[1],errors=errs)
  # Ward longitudinal insertion is pointwise proportional to the full
  # coframe, so it changes the wavefunction but not the relative metric.
  vec=rng.normal(size=4);vec/=np.linalg.norm(vec);q=E@vec;qs=slash(q);q2=q@q
  for j in range(4):
   deriv=slash(E[:,j])/q2-2*qs*(E.T@E@vec)[j]/q2**2
   close('longitudinal_Ward_'+str((trial,j)),qs@deriv@qs,-slash(E[:,j]),2e-11)
  for j in range(4):
   contracted=sum((slash(E[:,mu])@GAM[j]@slash(E[:,mu]) for mu in range(4)),np.zeros((4,4),complex))
   close('coframe_Clifford_map_'+str((trial,j)),contracted,slash((2*E@E.T-np.trace(E@E.T)*np.eye(4))[:,j]),2e-11)
 # The bubble coefficient is derived from its trace and dimensionally
 # regulated radial integration-by-parts identity.
 d,Delta=s.symbols('d Delta');check('bubble_radial_cancellation',s.simplify((2/d-1)*d/2*(-2*Delta/(d-2))-Delta)==0)
 check('bubble_transverse_coefficient',8*s.integrate(x*(1-x),(x,0,1))/8==s.Rational(1,6))
 for trial in range(6):
  q=rng.normal(size=4);p=rng.normal(size=4)
  trace=np.array([[np.trace(GAM[mu]@slash(q)@GAM[nu]@slash(q+p)) for nu in range(4)] for mu in range(4)])
  close('bubble_gamma_trace_'+str(trial),trace,4*(np.outer(q,q+p)+np.outer(q+p,q)-np.eye(4)*np.dot(q,q+p)),2e-11)
  V=np.eye(3)+.2*sym(rng.normal(size=(3,3)));assert np.linalg.eigvalsh(V).min()>.2
  E=np.zeros((4,4));E[0,0]=1;E[1:,1:]=V;ef,bf=metric_medium(V)
  electric=rng.normal(size=3);magnetic=rng.normal(size=3);F=np.zeros((4,4));F[0,1:]=electric;F[1:,0]=-electric;F[1:,1:]=-curl(magnetic)
  transformed=E@F@E.T;direct=np.sum(transformed**2)/(4*np.linalg.det(E));medium=(electric@ef@electric+magnetic@bf@magnetic)/2
  close('induced_metric_medium_'+str(trial),direct,medium,2e-11)
  close('single_metric_no_birefringence_'+str(trial),ef@bf,np.eye(3),2e-11)
 # All five parity-even birefringent directions have no fermion metric
 # logarithm at linear order. Challenge the tensor and Clifford calculations.
 wbas=[np.diag([1,-1,0]),np.diag([1,1,-2])]
 for i,j in [(0,1),(0,2),(1,2)]:
  W=np.zeros((3,3));W[i,j]=W[j,i]=1;wbas.append(W)
 for idx,W in enumerate(wbas):
  Kavg=np.zeros((4,4))
  # Quadratic kernels are integrated exactly using second moments through
  # a small signed-axis rule independent of the general sphere quadrature.
  for a in range(4):
   vec=np.eye(4)[a];K=medium_kernel(vec,W);Kavg+=K/4
   close('birefringent_transverse_'+str((idx,a)),K@vec,np.zeros(4))
   close('birefringent_trace_'+str((idx,a)),np.trace(K),0)
  close('birefringent_kernel_mean_'+str(idx),Kavg,np.zeros((4,4)))
  for trial in range(2):
   vec=rng.normal(size=4);vec/=np.linalg.norm(vec);K=medium_kernel(vec,W)
   for j in range(4):
    inner=GAM[j]-2*slash(vec)*vec[j]
    actual=sum((K[mu,nu]*GAM[mu]@inner@GAM[nu] for mu,nu in product(range(4),repeat=2)),np.zeros((4,4),complex))
    close('birefringent_Clifford_insertion_'+str((idx,trial,j)),actual,2*slash(K[j]),2e-11)
 # A finite shear produces two different physical photon polarizations.
 shear,weight=s.symbols('shear weight',real=True);V=s.diag(1+shear,1-shear,1);ef=V**2/V.det();bf=V.det()*V.inv()**2
 speed_y=(1+weight*bf[2,2])/(1+weight*ef[1,1]);speed_z=(1+weight*bf[1,1])/(1+weight*ef[2,2])
 split=s.factor(s.diff(speed_y-speed_z,weight).subs(weight,0))
 check('induced_birefringence_exact_split',s.factor(split+shear**2*(4-shear**2)/(1-shear**2))==0)
 for sh in [.1,.2,.4]:
  epsilon=np.eye(3)+.03*np.array(ef.subs(shear,sh)).astype(float);b=np.eye(3)+.03*np.array(bf.subs(shear,sh)).astype(float)
  matrix=-np.linalg.solve(epsilon,curl([1,0,0])@b@curl([1,0,0]));eig=np.linalg.eigvals(matrix).real;positive=np.sort(eig[eig>1e-10])
  expected=np.sort([float(speed_y.subs({shear:sh,weight:.03})),float(speed_z.subs({shear:sh,weight:.03}))])
  close('physical_photon_polarizations_'+str(sh),positive,expected,2e-12)
  check('physical_photon_split_'+str(sh),positive[1]-positive[0]>1e-4, squared_speeds=positive.tolist())
 # Solving the derived truncated RG equations is algebra, separate from
 # the coefficient derivation and not an all-orders interacting theorem.
 ell,e0=s.symbols('ell e0',positive=True);z=1+e0*ell/(6*s.pi**2);charge=e0/z;R=z**-3;W=s.Rational(2,5)*(z**-1-z**-6)
 check('running_charge_equation',s.simplify(s.diff(charge,ell)+charge**2/(6*s.pi**2))==0)
 check('running_relative_metric_equation',s.simplify(s.diff(R,ell)+charge*R/(2*s.pi**2))==0)
 check('running_birefringence_equation',s.simplify(s.diff(1/z,ell)+charge/(6*s.pi**2*z))==0)
 check('generated_shear_memory_equation',s.simplify(s.diff(W,ell)+charge*W/(6*s.pi**2)-2*charge*R**2/(6*s.pi**2))==0)
 # Exact finite-spacing Peierls Ward identity for the specified Wilson
 # matter. Gauge momentum is the link-incidence symbol, not continuum q.
 vel=np.sqrt(1-.7**2);D=np.array([1,1,vel])
 for trial in range(10):
  k=rng.uniform(-np.pi,np.pi,size=3);qmom=rng.uniform(-2,2,size=3);a=.37
  contraction=sum(((2*D[i]/a*np.sin(qmom[i]/2))*native_vertex(k,i) for i in range(3)),np.zeros((2,2),complex))
  close('native_Peierls_Ward_'+str(trial),contraction,(native_h(k+qmom/2)-native_h(k-qmom/2))/a,2e-11)
 # A one-parameter link variation checks the required quadratic contact.
 for axis in range(3):
  k=np.array([.31,-.27,.43]);step=.0005;direction=np.eye(3)[axis]/D[axis]
  fd=(native_h(k+step*direction)-2*native_h(k)+native_h(k-step*direction))/step**2
  target=((-np.sin(k[axis])*SIG[axis] if axis<2 else 0)+np.cos(k[axis])*SIG[2])/D[axis]**2
  close('native_quadratic_Peierls_contact_'+str(axis),fd,target,2e-7)
 result=dict(status='ok',check_count=len(rows),checks=rows,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-start,scope='Formal one-loop coefficients, exact algebra and finite native Ward challenges. No gauge phase, higher-loop or axiom-selection theorem.')
 assert len({r['name'] for r in rows})==len(rows)
 (HERE/'BLOCK10_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':run()
