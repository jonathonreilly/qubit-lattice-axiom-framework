"""Supplemental exact-identity variants; no new ODE or observations, finite120-second cap per process."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

DIRECTORY=Path(__file__).resolve().parent
ROOT=next(p for p in DIRECTORY.parents if (p/'scripts/scalar_cosmological_inverse.py').is_file())
SOURCE=ROOT/'scripts/scalar_cosmological_inverse.py'
PROTOCOL=DIRECTORY/'SYNTHETIC_PROTOCOL_v1.json'
VARIANTS=[
    ('Bianchi_matter_trace','-(rho-3*p)+2*F*derivative(V)/Fd','-(rho-p)+2*F*derivative(V)/Fd'),
    ('tensor_endpoint_orientation','sp.sqrt(Fsrc/Fmid)*sp.sqrt(Fmid/Fobs)-sp.sqrt(Fsrc/Fobs)','sp.sqrt(Fmid/Fsrc)*sp.sqrt(Fmid/Fobs)-sp.sqrt(Fsrc/Fobs)'),
    ('sharp_interface_transmission','transmission = 2*Fsrc/(Fsrc+Fmid)','transmission = 2*Fmid/(Fsrc+Fmid)'),
    ('transverse_potential_force','Uxy = k*x*x*sp.exp(-(1-k)*u/alpha)/2','Uxy = k*x*x*sp.exp(-(1-k)*u/alpha)'),
    ('transverse_kinetic_factor','full_D = radial_D+2*tensor*Tperp','full_D = radial_D+tensor*Tperp'),
]


def main():
    source=SOURCE.read_text()
    work=DIRECTORY/'mutation_variants_supplement_v1'
    work.mkdir(exist_ok=False)
    entries=[]
    for name,before,after in VARIANTS:
        count=source.count(before)
        if count != 1:
            raise ValueError(f'{name}: expected one source location, got {count}')
        variant=work/(name+'.py')
        variant.write_text(source.replace(before,after,1))
        entries.append({'name':name,'before':before,'after':after,'path':str(variant.relative_to(ROOT)),
                        'sha256':hashlib.sha256(variant.read_bytes()).hexdigest()})
    (DIRECTORY/'MUTATION_SUPPLEMENT_FREEZE_v1.json').write_text(json.dumps({
        'frozen_at':datetime.now(timezone.utc).isoformat(),'timeout_seconds_each':120,
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'protocol_sha256':hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),'variants':entries},indent=2)+'\n')
    driver='''import importlib.util,json,sys
from pathlib import Path
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location("variant",p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.exact_controls()
failed=[x for x in r if not x["passed"]]
print(json.dumps({"failed":[x["name"] for x in failed]},sort_keys=True))
assert not failed, "scientific control rejected variant"
'''
    results=[]
    for entry in entries:
        start=time.monotonic()
        try:
            result=subprocess.run([sys.executable,'-c',driver,str(ROOT/entry['path']),str(PROTOCOL)],capture_output=True,text=True,timeout=120)
            kind='assertion' if 'AssertionError: scientific control rejected variant' in result.stderr else ('guard_or_numeric_exception' if result.returncode else 'survived')
            row={**entry,'exit_code':result.returncode,'rejection_kind':kind,'elapsed_seconds':time.monotonic()-start,'stdout':result.stdout,'stderr':result.stderr}
        except subprocess.TimeoutExpired as exc:
            row={**entry,'exit_code':None,'rejection_kind':'timeout_not_scientific_rejection','elapsed_seconds':time.monotonic()-start,'stdout':str(exc.stdout),'stderr':str(exc.stderr)}
        results.append(row)
        (DIRECTORY/'MUTATION_SUPPLEMENT_RESULTS_v1.json').write_text(json.dumps({'results':results},indent=2)+'\n')
    print(json.dumps({'counts':{kind:sum(r['rejection_kind']==kind for r in results) for kind in sorted({r['rejection_kind'] for r in results})},'variants':len(results)},indent=2))


if __name__=='__main__':main()
