#!/usr/bin/env python3
"""Independent reconstruction controls from the supplied action only.
No author action-selection source, observations, fitting library or network.
Exact symbolic/rational checks are distinguished from ordinary floating checks.
"""
import json,sys,traceback,math
import sympy as S

R=S.Rational
records=[]
def check(name,condition,detail,kind='exact'):
    passed=bool(condition)
    records.append(dict(name=name,passed=passed,kind=kind,detail=detail))
    if not passed:raise AssertionError(name)
def zero(name,expr,detail):
    residual=S.factor(S.simplify(expr))
    check(name,residual==0,dict(detail,exact_residual=str(residual)))
def model(k,Q):
    a=(1-k)*(1+3*k)/4
    s=(1+k)/(k*(1-3*k))
    A=Q/(1+s);B=s*A;beta=(1-3*a)/(2*a)
    return a,s,A,B,beta

def basis(F,k,Q):
    a,s,A,B,beta=model(k,Q)
    L0=3*(F**2+s*(F-Q)**2)/Q
    L1=(1+s)*(F-B)**2*S.log((F-B)/A)**2/(4*a*Q)
    return S.simplify(L0),S.simplify(L1)

def infer_pair(F1,Z1,F2,Z2):
    if F1==F2 or Z1<=0 or Z2<=0 or Z1==Z2:
        raise ValueError('distinct F and positive finite distinct Z required')
    beta=S.simplify((F2-F1)/(1/Z2-1/Z1));B=S.simplify(F1-beta/Z1)
    if not (0<beta<R(1,2) and B>0 and F1>B and F2>B):
        raise ValueError('candidate domain failure')
    a=1/(2*beta+3);k=S.simplify((1-2*S.sqrt(1-3*a))/3)
    s=(1+k)/(k*(1-3*k));Q=S.simplify(B*(1+s)/s)
    return beta,B,k,Q,S.simplify(Q/(1+k))

def background(t,F,H,curvature,rho,pressure):
    fd=S.diff(F,t);fdd=S.diff(F,t,2);hd=S.diff(H,t)
    T=S.simplify(-2*F*(hd-curvature)-(rho+pressure)-fdd+H*fd)
    Z=S.simplify(T/fd**2)
    V=S.simplify(3*F*(H**2+curvature)-rho-T/2+3*H*fd)
    E0=S.simplify(3*F*(H**2+curvature)-rho-Z*fd**2/2-V+3*H*fd)
    E2=S.simplify(-2*F*(hd-curvature)-(rho+pressure)-Z*fd**2-fdd+H*fd)
    ES=S.simplify(Z*(fdd+3*H*fd)+S.diff(Z,t)*fd/2+S.diff(V,t)/fd-3*(hd+2*H**2+curvature))
    cons=S.simplify(S.diff(rho,t)+3*H*(rho+pressure))
    return T,Z,V,E0,E2,ES,cons

def run():
    k,Q,E,F=S.symbols('k Q E F',positive=True)
    a,s,A,B,beta=model(k,Q)
    P=1+s*E;J=1+(1-3*a)*s*E;Ku=J/P**2
    CF=(1+s)*E/P;F_original=Q/CF
    Fu_squared=4*a*E**2*S.diff(F_original,E)**2
    zero('conformal_F_derivative',Fu_squared-4*a*(F_original-B)**2,
         {'source':'F=Q/C, E_u=2sqrt(a)E'})
    Z_direct=2*F_original*Ku/Fu_squared-3/(2*F_original)
    zero('Jordan_radial_normalization',Z_direct-beta/(F_original-B),
         {'retained_source_factor':'-Q K(dphi)^2, no 1/2',
          'Ricci_contribution':'+3(dF)^2/(4F)'})
    omega=S.simplify(F_original*Z_direct)
    zero('independent_coupling_normalization',1/(2*omega+3)-a/J,
         {'relation':'Brans-Dicke algebra agrees with source alpha_B^2/K_u=a/J'})

    FF,fd,fdd,H,hd,chi,rho,pressure,Z,ZF,V,VF=S.symbols('F fd fdd H hd chi rho p Z ZF V VF')
    E2=-2*FF*(hd-chi)-(rho+pressure)-Z*fd**2-fdd+H*fd
    ES=Z*(fdd+3*H*fd)+ZF*fd**2/2+VF-3*(hd+2*H**2+chi)
    Edot=3*fd*(H**2+chi)+6*FF*H*hd-6*FF*H*chi+3*H*(rho+pressure)-ZF*fd**3/2-Z*fd*fdd-VF*fd+3*hd*fd+3*H*fdd
    zero('scalar_sufficiency_identity',Edot+3*H*E2+fd*ES,
         {'conditions':'rho_dot=-3H(rho+p), chi_dot=-2Hchi'})
    T=-2*FF*(hd-chi)-(rho+pressure)-fdd+H*fd
    Vrec=3*FF*(H**2+chi)-rho-T/2+3*H*fd
    zero('expanded_potential_formula',Vrec-(FF*(3*H**2+hd+2*chi)-(rho-pressure)/2+R(5,2)*H*fd+fdd/2),
         {'curvature_coefficient':'2F chi','H_Fdot_coefficient':'5/2'})

    t=S.symbols('t',positive=True)
    cases=[('vacuum_open_flat',t,1/t,S.Integer(0),S.Integer(0),S.Integer(0),3/t,R(9,2)/t),
           ('vacuum_curved',t,1/t,1/(4*t*t),S.Integer(0),S.Integer(0),R(7,2)/t,5/t),
           ('radiation_curved_decreasing_F',t**-2,1/t,2/t**2,t**-4,R(1,3)*t**-4,-R(5,6)*t**2,R(11,3)*t**-4)]
    for name,ff,hh,cc,rr,pp,expectedZ,expectedV in cases:
        tt,zz,vv,e0,e2,es,cons=background(t,ff,hh,cc,rr,pp)
        check('exact_history_'+name,
              all(S.simplify(x)==0 for x in [zz-expectedZ,vv-expectedV,e0,e2,es,cons,S.diff(cc,t)+2*hh*cc]),
              {'F':str(ff),'H':str(hh),'curvature':str(cc),'rho':str(rr),'p':str(pp),'Z':str(zz),'V':str(vv)})
    negativeZ=-R(5,6)*t**2
    check('positive_Jordan_Z_is_not_universal',negativeZ<0 and S.simplify(negativeZ+R(3,2)/(t**-2))==R(2,3)*t*t,
          {'example':'radiation_curved_decreasing_F','Einstein_kinetic_coefficient':'2t^2/3>0'})
    tt,zz,vv,e0,e2,es,cons=background(t,t,1/t,S.Integer(0),S.Integer(1),S.Integer(0))
    check('nonconserved_matter_breaks_scalar_sufficiency',e0==e2==0 and es==-3/t and cons==3/t,
          {'metric_equations':'both satisfied by reconstruction','scalar_residual':str(es),'conservation_residual':str(cons)})

    for kk in [R(1,20),R(1,10),R(1,5),R(3,10)]:
        q0=S.Integer(7);qq=q0*(1+kk);aa,ss,AA,BB,be=model(kk,qq)
        Fs=[BB+AA/e for e in [R(1,2),S.Integer(1),S.Integer(3)]]
        Zs=[be/(f-BB) for f in Fs]
        bb,b0,kfit,qfit,q0fit=infer_pair(Fs[0],Zs[0],Fs[1],Zs[1])
        check('two_epoch_parameter_recovery_'+str(kk),
              (bb,b0,kfit,qfit,q0fit)==(be,BB,kk,qq,q0) and 0<be<R(1,2),
              {'k':str(kk),'beta':str(be),'B':str(BB),'Q0':str(q0fit)})
        predicted=bb/(Fs[2]-b0)
        check('third_epoch_shape_check_'+str(kk),predicted==Zs[2] and predicted!=Zs[2]+R(1,100),
              {'third_epoch_Z':str(Zs[2]),'deliberate_incompatible_increment':'1/100'})
    invalid=[('same_F',(R(2),R(1),R(2),R(2))),
             ('same_Z',(R(2),R(1),R(3),R(1))),
             ('beta_too_large',(R(2),R(1),R(3),R(1,2))),
             ('negative_beta',(R(2),R(1),R(3),R(2))),
             ('negative_B',(R(2),R(1,12),R(3),R(1,16))),
             ('nonpositive_Z',(R(2),R(0),R(3),R(1)))]
    for name,values in invalid:
        try:infer_pair(*values)
        except ValueError:rejected=True
        else:rejected=False
        check('identifiability_gate_'+name,rejected,{'exact_inputs':[str(v) for v in values]})

    # Full potential normalization, derived through E=1/r rather than the
    # reconstructed expression. r>0 is the finite field chart variable.
    r,h2,nu=S.symbols('r h2 nu',positive=True)
    ff=B+A*r;ee=1/r;pp=1+s*ee
    u2=S.log(r)**2/(4*a)
    U=R(3,2)+3*s*(ee-1)**2/(2*pp**2)+nu*(1+s)*u2/(2*pp**2)
    direct=2*h2*ff**2*U/Q
    expected=h2/Q*(3*ff**2+3*s*(ff-Q)**2+nu*(1+s)*(ff-B)**2*S.log(r)**2/(4*a))
    zero('full_radial_potential_normalization',direct-expected,
         {'source_potential':'2 Q Hv^2 U before conformal transformation'})
    zero('vacuum_value',expected.subs(r,1)-3*Q*h2,{'F_at_vacuum':'Q'})
    zero('vacuum_first_derivative',(S.diff(expected,r)/A).subs(r,1)-6*h2,
         {'nu_dependence':'zero at r=1'})
    kk=R(1,10);qq=R(77,10);aa,ss,AA,BB,be=model(kk,qq)
    Fs=[qq,BB+2*AA,BB+3*AA]
    rows=[basis(f,kk,qq) for f in Fs]
    theta0=R(3,2);nu0=R(2,5);theta1=theta0*nu0
    vals=[theta0*x+theta1*y for x,y in rows]
    fitted0=S.simplify(vals[0]/rows[0][0])
    determinant=S.simplify(rows[0][0]*rows[1][1]-rows[0][1]*rows[1][0])
    fitted1=S.simplify((vals[1]-fitted0*rows[1][0])/rows[1][1])
    check('potential_two_row_identification',determinant>0 and fitted0==theta0 and fitted1==theta1,
          {'theta0':str(fitted0),'theta1':str(fitted1),'nu':str(fitted1/fitted0),'determinant':str(determinant)})
    third=S.simplify(fitted0*rows[2][0]+fitted1*rows[2][1])
    check('potential_third_row_consistency',S.simplify(third-vals[2])==0 and S.simplify(third-(vals[2]+1))==-1,
          {'deliberate_third_row_potential_increment':'1','not_absorbed_by_two_fitted_coefficients':True})
    check('vacuum_only_row_has_no_nu_information',rows[0][1]==0 and rows[0][0]>0,
          {'basis_row':[str(x) for x in rows[0]]})

    x,y=S.symbols('x y',real=True)
    D=1+2*(1+kk)*(x*x+y*y)/3
    Kx=(1+ss)*4*kk/(9*(1+ss)*D);Ky=(1+ss)*kk/(3*(1+ss)*D)
    valsxy={x:R(3,5),y:-R(4,7)}
    transverse=2*qq*(Kx*R(2,3)**2+Ky*R(1,5)**2)
    transverse=S.factor(transverse.subs(valsxy))
    check('transverse_motion_strictly_raises_reconstructed_Z',transverse>0,
          {'Fdot_squared_fixture':'1','excess_Z':str(transverse),'finite_D':str(D.subs(valsxy))})
    ux=kk*valsxy[x];uy=R(2,3)*kk*valsxy[y]
    vextra=theta0*kk*qq*(valsxy[x]**2+R(2,3)*valsxy[y]**2)
    check('constant_nonzero_transverse_is_not_zero_branch',ux!=0 and uy!=0 and vextra>0,
          {'u':'0','transverse_velocity':'0','same_radial_kinetic_formula':True,
           'U_x':str(ux),'U_y':str(uy),'positive_extra_V':str(vextra)})
    zero('radial_metric_has_no_transverse_connection_force',S.diff(Ku,x),
         {'Gamma_x_uu':'zero because source K_u independent of x,y'})
    zero('zero_transverse_branch_is_stationary',S.diff(kk*x*x/2+kk*y*y/3,x).subs({x:0,y:0})+S.diff(kk*x*x/2+kk*y*y/3,y).subs({x:0,y:0}),
         {'transverse_velocities':'zero','coupling_C_transverse_derivatives':'zero'})

    check('constant_F_metric_only_failure',3*2*1-6==0 and 0-6==-6,
          {'F':'2','H':'1','rho_p_curvature':'0','V':'6 constant',
           'metric_residuals':['0','0'],'scalar_residual':'-6'})
    check('constant_F_requires_independent_potential_slope',6-6==0,
          {'repaired_potential':'6+6(F-2)','Z_value':'arbitrary, background unprobed'})
    qq=R(5);h2val=R(7,3);plateaus=[]
    for kk,nn in [(R(1,20),R(1,5)),(R(1,5),R(4,5)),(R(3,10),R(2))]:
        aa,ss,AA,BB,be=model(kk,qq)
        FF=BB+AA*r
        vv=h2val/qq*(3*FF**2+3*ss*(FF-qq)**2+nn*(1+ss)*(FF-BB)**2*S.log(r)**2/(4*aa))
        val=S.simplify(vv.subs(r,1));slope=S.simplify((S.diff(vv,r)/AA).subs(r,1))
        plateaus.append((kk,nn,S.simplify(qq/(1+kk)),val,slope))
    check('candidate_vacuum_plateau_parameter_degeneracy',all(v==3*qq*h2val and d==6*h2val for _,_,_,v,d in plateaus),
          {'fixed_F':str(qq),'fixed_H_squared':str(h2val),
           'different_k_nu_Q0':[[str(x) for x in row[:3]] for row in plateaus]})

    lam=S.symbols('lambda',positive=True)
    FF,BB,be=S.symbols('FF BB beta',positive=True)
    zero('absolute_normalization_scaling_Z',be/(lam*FF-lam*BB)-be/(FF-BB)/lam,
         {'F_rho_p_scale':'lambda','beta_k':'invariant'})
    kk=R(1,10);qq=R(77,10);aa,ss,AA,BB,be=model(kk,qq)
    FF=BB+AA*r
    v0,v1=basis(FF,kk,qq);w0,w1=basis(lam*FF,kk,lam*qq)
    zero('absolute_normalization_scaling_V',(w0+nu*w1)-lam*(v0+nu*v1),
         {'Q0_V_scale':'lambda','Hv_nu':'unchanged'})

    # Ordinary floating round trip through the original exponential chart.
    for kval,uval in [(.07,-.4),(.16,.3),(.29,1.1)]:
        av=(1-kval)*(1+3*kval)/4;sv=(1+kval)/(kval*(1-3*kval))
        qv=7*(1+kval);ev=math.exp(2*math.sqrt(av)*uval)
        Cv=(1+sv)*ev/(1+sv*ev);fv=qv/Cv
        Av=qv/(1+sv);Bv=sv*Av
        recovered=-math.log((fv-Bv)/Av)/(2*math.sqrt(av))
        check('floating_exponential_chart_round_trip_'+str(kval),abs(recovered-uval)<2e-13,
              {'k':kval,'u':uval,'recovered_u':recovered,'absolute_error':abs(recovered-uval)},'floating_control')

if __name__=='__main__':
    failure=None
    try:run()
    except BaseException as exc:
        failure={'type':type(exc).__name__,'message':str(exc)}
        traceback.print_exc(file=sys.stderr)
    result={'scope':'Independent pre-author-source action reconstruction controls',
            'sympy_version':S.__version__,'author_new_source_opened':False,'observations_opened':False,
            'all_passed':failure is None,'failure':failure,'check_count':len(records),
            'kinds':{k:sum(x['kind']==k for x in records) for k in sorted({x['kind'] for x in records})},
            'checks':records,'limits':['Synthetic exact histories and parameter fixtures are not observations.',
                                     'Floating round trips are controls, not numerical enclosures.',
                                     'No author code or aggregate invoked.']}
    print(json.dumps(result,indent=2));sys.exit(1 if failure else 0)
