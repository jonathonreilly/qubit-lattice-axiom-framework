# Independent M12 inverse precheck, before author exposure

Root remains author. This independent numerical implementation uses only the supplied future-confinement action note and original SYNTHETIC_PROTOCOL_v1.json. No author WORKING, cosmological_inverse, precision_diagnosis or results source has been read. The initial conclusions below and implementation are frozen before running it. Write scope is this directory only.

I restrict the three-field action to the invariant x=y=0 sector. Define Q=Q0(1+k), A=sqrt(C), alpha_B=(log A)_u and K=K_uu as in the note. Let tau=Hv*t_E, v=du/dtau, r=rho_E/(Q Hv²), and h=H_E/Hv. For conserved Jordan dust the coupled original-action equations are

    h²=(K v²+2U+r)/3,
    u'=v,
    v'=-3hv-(K_u/(2K))v²-U_u/K-alpha_B*r/(2K),
    r'=(-3h+alpha_B*v)r,
    h'=-K v²-r/2.

The factor one-half in the dust source follows from the absence of one-half before Q*K in the supplied action. No initial state is selected by these equations; the protocol provides it.

The physical Jordan clock obeys dt_J=A dt_E. The physical gravitational coefficient is F=Q/C, not C or a measured locally calibrated G. Physical readouts are

    H_J=Hv*(h+alpha_B*v)/A,
    rho_J=Q Hv²*r/C²,
    Fdot_J=Hv*F_u*v/A,
    Fddot_J=Hv²/C * [F_uu*v²+F_u*v'-alpha_B*F_u*v²],
    Hdot_J=Hv²/C * [h'+alpha_B,u*v²+alpha_B*v'
                                -alpha_B*v*(h+alpha_B*v)].

Here F_u=-2alpha_B F and F_uu=F*(4alpha_B²-2alpha_B,u). These are analytic source-assembled derivatives at numerical states, not finite differences of measured data.

For a general Jordan action integral sqrt(-g)[FR/2-D(F)(partial F)²/2-V(F)] plus minimally coupled matter, let q=spatial_curvature/a_J². The FLRW constraint and acceleration equations imply, wherever Fdot_J is nonzero,

    D=[-2F*(Hdot_J-q)-(rho_J+P_J)-Fddot_J+H_J*Fdot_J]/Fdot_J²,
    V=3F*(H_J²+q)-rho_J-D*Fdot_J²/2+3H_J*Fdot_J.

The implementation accepts P_J and q as optional supplied readouts; the fixed synthetic cases use dust and q=0. Fdot=0 is an inverse singularity, not permission to choose an extension. Identifying an empirically known F and differentiable readouts remains an external premise.

Conformal transformation of the supplied action gives D=(K/alpha_B²-3)/(2F). Writing a=(1-k)(1+3k)/4 gives

    D(F)=b/(F-Finf), b=(1-3a)/(2a), Finf=Q0*(1+k)²/(4a).

The two fixed calibration epochs determine b=(F6-F0)/(1/D6-1/D0), Finf=F0-b/D0, a=1/(3+2b), k=(1-2sqrt(1-3a))/3 and Q0=4a*Finf/(1+k)² on 0<k<1/3. The other root lies outside that domain. The inverse physical field is u=-log((1+s)F/Q-s)/(2sqrt(a)). For U=U_vac+nu*U_nu, the Jordan potential is V=2Hv² F²(U_vac+nu U_nu)/Q. A two-by-two calibration system gives Hv² and Hv²*nu. Small Fdot and short calibration separation can amplify source rounding and parameter errors; no stability is assumed.

The code integrates the same 12 specified cases with DOP853 in binary64 (rtol 2e-12, atol 2e-14, max_step=duration/16). All modes use these same states. The 17 epochs, calibration indices 0 and 6, later indices 7 through 16, parameter tolerance 5e-7 and residual tolerance 1e-8 are unchanged. Later residuals are relative differences in D and V; no parameter is calibrated on those indices.

Three modes are frozen prospectively: binary64 source assembly and inversion; lifting the resulting rounded physical readouts to 50 digits before inversion; and 50-digit source assembly from the stored double states followed by inversion. The last mode has high-precision algebra and a double-precision trajectory. It is not a high-precision orbit or an observed-precision assumption. In addition to parameter/residual failures, the code retains cancellation diagnostics and local direct-action D,V identity residuals. Results are synthetic development only; this is neither a formal audit nor a physical action-selection result. Each command receives a 120-second in-process alarm; no broad tests are planned.
