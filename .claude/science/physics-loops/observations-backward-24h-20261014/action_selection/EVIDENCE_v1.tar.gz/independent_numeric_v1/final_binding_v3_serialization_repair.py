"""Final source/output/cache receipt check only. No scientific code execution."""
from pathlib import Path
import ast,hashlib,json
import mpmath as mp
from decimal import Decimal,localcontext
from datetime import datetime,timezone
P=Path(__file__).resolve().parent;C=P/'canonical_final_v3';PK=Path('.claude/science/physics-loops/observations-backward-24h-20261014/action_selection')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
manifest=read(P/'FINAL_INPUT_FREEZE_v3.json')
for r in manifest['files']:
 f=Path(r['snapshot']);assert sha(f)==r['sha256'] and f.stat().st_size==r['bytes'];assert sha(Path(r['path']))==r['sha256']
primary=C/'scripts/scalar_cosmological_inverse_check.py'
tree=ast.parse(primary.read_text());assign={t.id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name) and t.id in ['AUDIT_TIMEOUT_SEC','AUDIT_INPUT_PATHS']};paths=assign['AUDIT_INPUT_PATHS'];assert len(paths)==3 and assign['AUDIT_TIMEOUT_SEC']==120
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in paths:
 n=rel.encode();b=(C/rel).read_bytes();h.update(len(n).to_bytes(8,'big'));h.update(n);h.update(len(b).to_bytes(8,'big'));h.update(b)
fp=h.hexdigest();cache=C/'logs/runner-cache/scalar_cosmological_inverse_check.txt';head,rest=cache.read_text().split('----- stdout -----\n',1);header={x.split(': ',1)[0]:x.split(': ',1)[1] for x in head.splitlines() if ': ' in x};stdout,stderr=rest.split('----- stderr -----\n',1)
assert header['runner_sha256']==sha(primary) and header['input_fingerprint_sha256']==fp and header['timeout_sec']=='120' and header['exit_code']=='0'
receipt=read(C/PK/'CANONICAL_EXECUTION_v3.json');run=receipt['result'];assert receipt['cache_status']=='fresh' and receipt['cache_sha256']==sha(cache)
assert run['exit_code']==0 and run['status']=='ok' and run['timeout_sec']==120 and run['elapsed_sec']<120 and not run['stderr'] and not stderr.strip();assert stdout.strip()==run['stdout'].strip()
O=C/'outputs/scalar_cosmological_inverse';summary=read(O/'SUMMARY_v1.json');result=read(O/'RESULTS_v1.json')
assert json.loads(stdout[stdout.index('{\n'):])==summary
projection={k:v for k,v in result.items() if k not in ['histories','checks']};projection['failed_checks']=[x for x in result['checks'] if not x['passed']];assert projection==summary
assert result['primary_sha256']==sha(primary);assert len(result['input_sha256'])==3
for rel,v in result['input_sha256'].items():assert sha(C/rel)==v
for rel,v in read(C/PK/'CANONICAL_SOURCE_FREEZE_v3.json')['files'].items():assert sha(C/rel)==v
assert result['passed']==len(result['checks'])==102 and result['failed']==0 and all(x['passed'] for x in result['checks'])
original=read(P/'author_results_v1/RESULTS_v1.json');oldnames={x['name'] for x in original['checks']};newnames={x['name'] for x in result['checks']};assert oldnames<=newnames
added=sorted(newnames-oldnames);assert len(added)==11
protocol=read(C/PK/'SYNTHETIC_PROTOCOL_v1.json');assert protocol['calibration_indices']==[0,6] and protocol['later_synthetic_residual_indices']==list(range(7,17)) and protocol['sample_count']==17 and protocol['parameter_relative_tolerance']==5e-7 and protocol['residual_relative_tolerance']==1e-8
assert sha(C/PK/'SYNTHETIC_PROTOCOL_v1.json')==original['protocol_sha256']
assert len(result['histories'])==12
own=read(P/'INDEPENDENT_RESULTS_v1.json');maxdelta=Decimal(0)
with localcontext() as ctx:
 ctx.prec=60
 for index,(final,old,my) in enumerate(zip(result['histories'],original['histories'],own['cases'])):
  assert final['case']==old['case']==protocol['synthetic_cases'][index] and len(final['rows'])==17 and final['readout_precision_digits']==50
  for a,b in zip(final['rows'],old['rows']):
   for key in ['source_u','source_velocity','timeE','timeJ']:
    with mp.workdps(50):
     assert a[key]==mp.nstr(mp.mpf(str(b[key])),55),(index,key)
    assert float(a[key])==b[key],(index,key)
  for key in ['k','Q0','nu','Hv']:
   pars=final['kinetic_inverse'] if key in final['kinetic_inverse'] else final['potential_inverse'];a=Decimal(pars[key]);b=Decimal(my['modes']['source_assembled_50']['parameters'][key]);maxdelta=max(maxdelta,abs(a/b-1))
 check=next(x for x in result['checks'] if x['name']=='rounded_measurements_do_not_gain_information_from_precision');assert Decimal(check['detail']['relative_nu_error'])>Decimal('5e-7')
assert original['failed']==1 and own['cases'][9]['modes']['float64']['parameter_tolerance_pass']==False and own['cases'][9]['modes']['rounded_input_lift_50']['parameter_tolerance_pass']==False
v1=P/'canonical_source_v1';v2=P/'canonical_source_v2'
for rel in ['scripts/scalar_cosmological_inverse.py','scripts/scalar_cosmological_inverse_check.py','docs/SCALAR_COSMOLOGICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md']:
 assert (v2/rel).read_bytes()==(C/rel).read_bytes()
a=ast.parse((v1/'scripts/scalar_cosmological_inverse.py').read_text());b=ast.parse((v2/'scripts/scalar_cosmological_inverse.py').read_text());fa={n.name:ast.dump(n,include_attributes=False) for n in a.body if isinstance(n,ast.FunctionDef)};fb={n.name:ast.dump(n,include_attributes=False) for n in b.body if isinstance(n,ast.FunctionDef)};changed=[k for k in fa if fa[k]!=fb[k]];assert changed==['_run']
assert sha(P/'NUMERICAL_REVIEW_v1.md')=='c3cfd208126aec9f1c8c27d7e02f663446ce5e58b9616ca69f1d1b2e782149f8';assert sha(P/'NUMERICAL_IDENTITY_v1.json')=='6eb433215c4de492603d44355bbc797602062bfe9368a97b6e06fd4b45c5e268'
out={'at':datetime.now(timezone.utc).isoformat(),'scope':'Final receipt and source/output comparisons only; no ODE, inverse, sampling or aggregate rerun.','cache_sha256':sha(cache),'input_fingerprint_sha256':fp,'execution':{k:run[k] for k in ['status','exit_code','timeout_sec','elapsed_sec']},'summary_sha256':sha(O/'SUMMARY_v1.json'),'results_sha256':sha(O/'RESULTS_v1.json'),'control_count':102,'failed':0,'control_additions_relative_to_original91':added,'all_204_saved_field_velocity_and_time_coordinates_match_exact_50_digit_conversion_and_original_float':True,'canonical_vs_independent_source_assembled_parameter_max_relative_difference':str(maxdelta),'canonical_rounded_case9_error_preserved':check['detail'],'reviewed_source_v2_equals_final':True,'production_functions_AST_unchanged_since_initial_canonical_review':True,'author_original_failure_and_independent_failures_preserved':True,'open_prose_finding_resolved':True,'formal_audit':False,'independent_empirical_tests':0}
(P/'FINAL_BINDING_RESULTS_v3.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
