"""Independent original-action trajectories, Jordan inverse and precision isolation."""
from pathlib import Path
import hashlib, json, math, signal
import numpy as np
from scipy.integrate import solve_ivp
import mpmath as mp
signal.alarm(120)
P=Path(__file__).resolve().parent
PROTOCOL=P.parent/'SYNTHETIC_PROTOCOL_v1.json'
mp.mp.dps=50

def theory(u,c,m):
 k,nu=c['k'],c['nu'];a=(1-k)*(1+3*k)/4;al=m.sqrt(a);s=(1+k)/(k*(1-3*k));E=m.exp(2*al*u);B=1+s*E;J=1+(1-3*a)*s*E;Ep=2*al*E
 K=J/B**2;Ku=(1-3*a)*s*Ep/B**2-2*J*s*Ep/B**3
 C=(1+s)*E/B;A=al/B;Au=-2*A*(al-A)
 Uv=m.mpf('1.5')+3*s*(E-1)**2/(2*B**2) if m is mp else 1.5+3*s*(E-1)**2/(2*B**2)
 Up=(1+s)*u*u/(2*B**2);U=Uv+nu*Up
 Uu=3*s*(1+s)*(E-1)*Ep/B**3+nu*(1+s)*(u/B**2-u*u*s*Ep/B**3)
 return dict(a=a,al=al,s=s,E=E,B=B,K=K,Ku=Ku,C=C,A=A,Au=Au,U=U,Uu=Uu,Uv=Uv,Up=Up)

def evolution(state,c,m):
 u,v,r=state;z=theory(u,c,m);h=m.sqrt((z['K']*v*v+2*z['U']+r)/3)
 vdot=-3*h*v-z['Ku']*v*v/(2*z['K'])-z['Uu']/z['K']-z['A']*r/(2*z['K'])
 return (v,vdot,(-3*h+z['A']*v)*r),h,-z['K']*v*v-r/2,z

def readout(state,c,m):
 u,v,r=state;d,h,hd,z=evolution(state,c,m);Q=c['Q0']*(1+c['k']);hv=c['Hv'];C=z['C'];A=z['A'];F=Q/C;Fu=-2*A*F;Fuu=F*(4*A*A-2*z['Au'])
 Fdot=hv*Fu*v/m.sqrt(C)
 Fdd=hv*hv/C*(Fuu*v*v+Fu*d[1]-A*Fu*v*v)
 H=hv*(h+A*v)/m.sqrt(C)
 Hdot=hv*hv/C*(hd+z['Au']*v*v+A*d[1]-A*v*(h+A*v))
 rho=Q*hv*hv*r/C**2
 return dict(F=F,Fdot=Fdot,Fddot=Fdd,H=H,Hdot=Hdot,rho=rho)

def inverse(z,P_J=0,spatial_curvature_term=0):
 F,Fd,Fdd,H,Hd,rho=[z[k] for k in ['F','Fdot','Fddot','H','Hdot','rho']]
 D=(-2*F*(Hd-spatial_curvature_term)-rho-P_J-Fdd+H*Fd)/(Fd*Fd)
 V=3*F*(H*H+spatial_curvature_term)-rho-D*Fd*Fd/2+3*H*Fd
 terms=[-2*F*(Hd-spatial_curvature_term),-rho-P_J,-Fdd,H*Fd]
 condition=sum(abs(t) for t in terms)/abs(D*Fd*Fd)
 return D,V,condition

def basis(F,k,Q0,m):
 a=(1-k)*(1+3*k)/4;al=m.sqrt(a);s=(1+k)/(k*(1-3*k));Q=Q0*(1+k)
 E=1/((1+s)*F/Q-s);u=m.log(E)/(2*al);B=1+s*E
 return 3/2+3*s*(E-1)**2/(2*B*B),(1+s)*u*u/(2*B*B)

def recover(rows,m):
 z0,z1=rows[0],rows[6];D0,V0,_=inverse(z0);D1,V1,_=inverse(z1);F0,F1=z0['F'],z1['F']
 b=(F1-F0)/(1/D1-1/D0);Finf=F0-b/D0;a=1/(3+2*b);k=(1-2*m.sqrt(1-3*a))/3;Q0=4*a*Finf/(1+k)**2;Q=Q0*(1+k)
 A0,B0=basis(F0,k,Q0,m);A1,B1=basis(F1,k,Q0,m);w0=V0*Q/(2*F0*F0);w1=V1*Q/(2*F1*F1);det=A0*B1-A1*B0
 hv2=(w0*B1-w1*B0)/det;nu=(A0*w1-A1*w0)/(det*hv2)
 ans={'k':k,'Q0':Q0,'nu':nu,'Hv':m.sqrt(hv2)}
 residual=[]
 for i in range(7,17):
  z=rows[i];D,V,_=inverse(z);F=z['F'];av,bv=basis(F,k,Q0,m);Dp=b/(F-Finf);Vp=2*hv2*F*F/Q*(av+nu*bv)
  residual.append({'index':i,'D_relative':abs(Dp/D-1),'V_relative':abs(Vp/V-1)})
 return ans,residual,{'b':b,'Finf':Finf,'D_fit_reciprocal_difference':1/D1-1/D0,'potential_determinant':det}

def enc(x):
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 if isinstance(x,(mp.mpf,mp.mpc)):return mp.nstr(x,52)
 if isinstance(x,np.generic):return x.item()
 return x

protocol=json.loads(PROTOCOL.read_text());out=[]
for number,c in enumerate(protocol['synthetic_cases']):
 state0=[c['u0'],c['velocity_over_Hv'],c['rhoE_over_QHv2']]
 times=np.linspace(0,c['duration_Hv'],protocol['sample_count'])
 sol=solve_ivp(lambda t,y:evolution(y,c,math)[0],[0,c['duration_Hv']],state0,method='DOP853',t_eval=times,rtol=2e-12,atol=2e-14,max_step=c['duration_Hv']/16)
 assert sol.success
 states=sol.y.T
 raw=[readout(list(y),c,math) for y in states]
 cm={k:mp.mpf(str(v)) for k,v in c.items()}
 assembled=[readout([mp.mpf(str(v)) for v in y],cm,mp) for y in states]
 lifted=[{k:mp.mpf(str(v)) for k,v in z.items()} for z in raw]
 cases={}
 for name,rr,backend in [('float64',raw,math),('rounded_input_lift_50',lifted,mp),('source_assembled_50',assembled,mp)]:
  try:
   params,resid,diagnosis=recover(rr,backend)
   errors={k:abs(params[k]/(cm[k] if backend is mp else c[k])-1) for k in params}
   dcheck=[];vcheck=[]
   for st,z in zip(states,rr):
    D,V,cond=inverse(z);a=cm['k'] if backend is mp else c['k'];a=(1-a)*(1+3*a)/4;Q=(cm['Q0']*(1+cm['k'])) if backend is mp else c['Q0']*(1+c['k']);b=(1-3*a)/(2*a);fi=Q*(1+(cm['k'] if backend is mp else c['k']))/(4*a)
    dcheck.append(abs(D/(b/(z['F']-fi))-1));uv,up=basis(z['F'],cm['k'] if backend is mp else c['k'],cm['Q0'] if backend is mp else c['Q0'],backend);hv=cm['Hv'] if backend is mp else c['Hv'];nu=cm['nu'] if backend is mp else c['nu'];vcheck.append(abs(V/(2*hv*hv*z['F']**2/Q*(uv+nu*up))-1))
   maxres=max(max(r['D_relative'],r['V_relative']) for r in resid)
   cases[name]={'parameters':params,'parameter_relative_errors':errors,'parameter_tolerance_pass':all(e<=protocol['parameter_relative_tolerance'] for e in errors.values()),'later_residuals':resid,'residual_tolerance_pass':maxres<=protocol['residual_relative_tolerance'],'max_later_residual':maxres,'max_local_D_identity_relative_error':max(dcheck),'max_local_V_identity_relative_error':max(vcheck),'max_D_cancellation_condition':max(inverse(z)[2] for z in rr),'calibration_condition_diagnostics':diagnosis,'readouts':rr}
  except Exception as e:cases[name]={'exception':repr(e)}
 out.append({'case':number,'parameters':c,'trajectory_status':sol.message,'nfev':sol.nfev,'states_double':states.tolist(),'dimensionless_Einstein_times':times.tolist(),'modes':cases})
result={'scope':'Independent implementation before author exposure; original 12 cases, fixed 17 epochs and calibration 0,6; double-precision DOP853 trajectory in all modes; high precision only algebraic physical readout/inverse assembly. Synthetic development, not observed precision.','protocol_sha256':hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'precision_digits':50,'cases':out}
(P/'INDEPENDENT_RESULTS_v1.json').write_text(json.dumps(enc(result),indent=2)+'\n')
summary=[]
for r in out:
 summary.append({'case':r['case'],'modes':{n:{k:enc(v) for k,v in q.items() if k in ['parameter_relative_errors','parameter_tolerance_pass','residual_tolerance_pass','max_later_residual','max_D_cancellation_condition','exception']} for n,q in r['modes'].items()}})
(P/'INDEPENDENT_SUMMARY_v1.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
