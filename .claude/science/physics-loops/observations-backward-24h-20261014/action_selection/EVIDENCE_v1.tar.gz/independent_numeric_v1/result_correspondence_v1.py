"""Post-freeze comparison only; no trajectory or source mathematics rerun."""
from pathlib import Path
import json,hashlib,math
P=Path(__file__).resolve().parent
own=json.loads((P/'INDEPENDENT_RESULTS_v1.json').read_text());other=json.loads((P/'author_results_v1/RESULTS_v1.json').read_text());precision=json.loads((P/'author_results_v1/PRECISION_DIAGNOSIS_v1.json').read_text())
assert len(own['cases'])==len(other['histories'])==len(precision['cases'])==12
maxima={};cases=[]
def accum(key,value):maxima[key]=max(maxima.get(key,0),abs(float(value)))
for i,(a,b,c) in enumerate(zip(own['cases'],other['histories'],precision['cases'])):
 assert a['parameters']==b['case']==c['case'] and len(a['states_double'])==len(b['rows'])==17
 case=a['parameters'];Q=case['Q0']*(1+case['k']);hv=case['Hv']
 for t,st,ownrow,ref in zip(a['dimensionless_Einstein_times'],a['states_double'],a['modes']['float64']['readouts'],b['rows']):
  accum('dimensionless_time_absolute',t-ref['timeE']*hv)
  accum('u_absolute',st[0]-ref['source_u']);accum('dimensionless_velocity_absolute',st[1]-ref['source_velocity']/hv)
  accum('dimensionless_density_absolute',st[2]-ref['rho']*ref['source_A']**4/(Q*hv*hv))
  for key in ['F','Fdot','Fddot','H','Hdot','rho']:
   accum(key+'_relative',(ownrow[key]-ref[key])/max(abs(ref[key]),1e-300))
  F,Fd,Fdd,H,Hd,rho=[ownrow[k] for k in ['F','Fdot','Fddot','H','Hdot','rho']]
  stress=-2*F*Hd-rho-Fdd+H*Fd;V=3*F*H*H-rho-stress/2+3*H*Fd
  accum('kinetic_stress_relative',(stress-ref['D'])/abs(ref['D']));accum('potential_relative',(V-ref['V'])/abs(ref['V']))
  accum('geometric_q_relative',(1/(2*F*stress/Fd**2+3)-ref['q'])/abs(ref['q']))
 ac=next(x for x in other['checks'] if x['name']==f'case{i}_parameter_recovery')
 assert a['modes']['float64']['parameter_tolerance_pass']==ac['passed']
 assert a['modes']['rounded_input_lift_50']['parameter_tolerance_pass']==c['lift_stored_readouts_50']['original_threshold_passed']
 assert a['modes']['source_assembled_50']['parameter_tolerance_pass']==c['reassemble_same_states_50']['original_threshold_passed']
 cases.append({'case':i,'author_float_errors':ac['detail'],'independent_float_errors':a['modes']['float64']['parameter_relative_errors'],'author_lifted_50_max_error':c['lift_stored_readouts_50']['maximum_relative_error'],'independent_lifted_50_max_error':max(float(x) for x in a['modes']['rounded_input_lift_50']['parameter_relative_errors'].values()),'author_source_assembled_50_max_error':c['reassemble_same_states_50']['maximum_relative_error'],'independent_source_assembled_50_max_error':max(float(x) for x in a['modes']['source_assembled_50']['parameter_relative_errors'].values()),'parameter_pass_classifications_equal':True})
r={'scope':'All 12 fixed histories and 204 states/readouts compared after independent freeze; differing floating results preserved. Not rerunning author code.','notation_mapping':'author D = independent coefficient D * Fdot^2; author omega = independent coefficient D * F; author c=independent b; author Fc=independent Finf.','maximum_cross_implementation_differences':maxima,'cases':cases,'author_original_failed_controls':[x for x in other['checks'] if not x['passed']],'independent_original_parameter_failed_cases':[x['case'] for x in own['cases'] if not x['modes']['float64']['parameter_tolerance_pass']],'author_precision_maximum_D_condition':max(x['max_D_cancellation_ratio'] for x in precision['cases']),'author_case9_D_condition':precision['cases'][9]['max_D_cancellation_ratio'],'independent_empirical_tests':0}
(P/'RESULT_CORRESPONDENCE_v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='cases'},indent=2))
