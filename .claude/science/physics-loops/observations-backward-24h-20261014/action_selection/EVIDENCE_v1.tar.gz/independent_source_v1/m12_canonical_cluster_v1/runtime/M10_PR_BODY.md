Finite recorded voltages do not identify a physical carrier unless the allowed discrepancy is constrained. This block derives the exact carrier/amplitude feasible set for a supplied error bound and reconstructs the documented Cassini receiver-reference conversion. It then tests those definitions on already exposed observations instead of supplying a physical noise budget.

The fixed 600-second X/Ka window rejects the constant-total-modulus, ideal-quantization-only candidate in all 1200 blocks. The conditional X/reference reconstruction gives 0.0664254 Hz RMS across 600 intervals without an added offset, timing or scale fit. These are exposed development comparisons and dependent archive consistency, not an independent gravity test or a calibrated error bound. Each voltage tone itself fits frequency and complex amplitude.

Independent spectral estimates agree for 1199/1200 blocks. The Ka second-49112 competing peak, original failed comparison and both candidates remain explicit. The registered local estimator is not relabeled globally optimal, and neither candidate is selected as the true carrier. Both historical phase-timing conventions remain unresolved.

- Claim type: `bounded_theorem`. Current status: `conditional-support`. Trace: `upstream_support`; reachability: `supports` the revised-scalar measurement-identification obligation.
- Checked: 63 author controls in the current source-bound run; 76 separately implemented mathematical controls; independent comparison of all 1200 exact cell certificates and 600 tracking intervals; 12 deliberately wrong-source variants rejected by assertions. Full-source, documentary, data and delivery scopes are recorded separately.
- Repaired and preserved: Nyquist frequency/amplitude pairing, exact archived-P integration versus separately rounded frequency fields, circular phase/boundary qualifications and original failed fixtures. A final metadata whitespace repair changes no scientific token or numerical product; previous identities remain historical.
- Open suppliers: physical discrepancy/time calibration, historical receiver implementation, counter/reset interpretation, scalar action/potential, initial field, scales and environmental solution. No scalar-theory assumption is counted as retired.

This is stacked on frozen M9 #9594, branch `codex/observations-backward-channels-20261015`, head `e143a32663ad58483efa73050d9344a700d91508`. Existing decoder/input manifests are exact inherited executable dependencies. The new mathematics is self-contained. No main push, merge, formal audit or integrated-main validation is included; combined landing checks and independent review remain required.

Reviewable sources:

- [Canonical derivation](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/docs/CASSINI_CARRIER_REFERENCE_FEASIBILITY_BOUNDED_THEOREM_NOTE_2026-10-15.md)
- [Primary runner](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/scripts/cassini_carrier_reference_check.py)
- [Review and conformance record](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/REVIEW_RECORD_v1.md)
- [Evidence index](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/EVIDENCE_INDEX_v1.json)
- [Assumptions](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/.claude/science/physics-loops/observations-backward-24h-20261014/ASSUMPTIONS_AND_IMPORTS.md), [trace](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/.claude/science/physics-loops/observations-backward-24h-20261014/TRACE_GATE.md), [handoff](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/18c1fe25210d3a19a8f77530937ae7af124084f0/.claude/science/physics-loops/observations-backward-24h-20261014/HANDOFF.md)

Reproduce after acquiring only the eight pinned public development inputs:

```sh
python3 scripts/cassini_carrier_reference_check.py --fetch-inputs
python3 scripts/cassini_carrier_reference_check.py
```

The second command is offline. Current execution exits 0 in 3.3672 seconds of its 180-second cap. Both numerical ledgers, previous failures, independent implementations and current-source mutation evidence are included in the compressed archive; full third-party documents and raw binaries stay local with public retrieval identities. Final cache SHA256: `8286baf77f5883f1e164313c84a1e718bffb5bc71ae1a891cd0faae956a892e0`.
