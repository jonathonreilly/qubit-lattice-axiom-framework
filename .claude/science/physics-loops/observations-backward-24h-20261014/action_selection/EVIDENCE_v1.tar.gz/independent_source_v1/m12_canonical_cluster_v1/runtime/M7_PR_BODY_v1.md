The supplied scalar vacuum has positive mass and curvature, so the existing massless count response cannot be used without controlling both corrections. This milestone derives explicit operator-error bounds and a four-endpoint coherent radio-count contrast on the supplied expanding vacuum. The contrast removes the stated initial orbit/clock columns without choosing a scalar initial state.

The result includes the exact massless comparison Gram for the curved count weights, the conversion to physical initial-slice energy, and a conditional residual-energy inequality. A separate compact clock example rejects universal massive-versus-massless Gram ordering. Action, vacuum, scales, calibration, nonlinear/source effects and measured error or energy budgets remain conditional.

Validation: 59 author controls and 10 deliberate wrong-source variants rejected. Focused independent derivations check the mass bound, curvature/energy transformation, and original fixed-proper-time trajectory/clock/null equations; a separate exact integration reproduces the curved comparison Gram. The final canonical review also checks the source adaptation and composed inequality. Numerical quadrature is labeled diagnostic. No observational parameters were fitted and no independent empirical test or formal audit is claimed.

Run: `/usr/local/bin/python3 scripts/scalar_mass_curvature_count_check.py`. The source-bound cache, outputs, original working records and immutable review evidence accompany the note. Whitespace-bearing historical originals are preserved byte-for-byte in a gzip archive with extraction hashes.

Stacked on frozen PR #9589. This PR does not merge science or certify integrated current-main landing.

