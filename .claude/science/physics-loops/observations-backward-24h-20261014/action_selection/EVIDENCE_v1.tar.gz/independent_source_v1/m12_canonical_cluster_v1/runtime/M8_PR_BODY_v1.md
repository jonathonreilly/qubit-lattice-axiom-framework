The archived receiver metadata does not justify selecting a bounded, reset-free whole-cycle history. This milestone derives a reduced phase observable that eliminates arbitrary integer histories within supplied segments. It then derives a conditional scalar energy bound and the full correlated Gram-metric lattice minimum, without selecting a physical history or minimum-energy state.

The result also identifies when real-valued projections lose the quotient structure: rational weights require the correct period, and an irrational projection can have dense ambiguity image. The existing curved real contrast therefore cannot automatically be reused as a one-cycle observable. The canonical note contains the proof, explicit counterexamples, information loss and calibration limits.

On the four already exposed archive inputs, all 91,664 Doppler intervals and 91,593 numeric triples agree with a separately implemented raw-bit extraction; both duplicate endpoint variants and nonzero slip diagnostics remain visible. This is consistency between dependent archive products. It supplies no physical noise bound, measured scalar residual, fitted physical parameter or independent empirical test. Fractional errors, segmentation, the physical phase map, action, scales and actual energy budget remain conditional.

Validation: 49 author controls, 13 deliberate wrong-source variants assertion-rejected, 114 original independent mathematical controls, focused primary-document metadata checks, independent complete raw extraction, final source correspondence and exact cache/product identity confirmation. Two executable-domain findings were repaired: approximate rationality is rejected and the error bound must be supplied explicitly. Earlier findings and failed source-binding guards are preserved with their original identities.

Run: `/usr/local/bin/python3 scripts/scalar_phase_quotient_check.py` (180-second cap; final run 7.64 seconds). The source-bound cache, deterministic compressed row evidence, original review reports and a hash-indexed evidence archive accompany the note. Vocabulary and diff checks pass. Claim type: `bounded_theorem`; actual current surface status: `conditional-support`.

Review entry points:

- [Canonical proof and limits](docs/SCALAR_PHASE_QUOTIENT_INTEGER_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-15.md)
- [Review scope and conformance](.claude/science/physics-loops/observations-backward-24h-20261014/calibration_error/REVIEW_RECORD_v1.md)
- [Evidence identities](.claude/science/physics-loops/observations-backward-24h-20261014/calibration_error/EVIDENCE_INDEX_v1.json)
- [Assumptions and remaining suppliers](.claude/science/physics-loops/observations-backward-24h-20261014/ASSUMPTIONS_AND_IMPORTS.md)

Stacked on frozen PR #9591, head `917e147109e58c5bf8b5d4a9d546077d20cfe41c`. Full combined current-main landing validation and formal audit remain pending. This PR does not merge science or grant a retained status.
