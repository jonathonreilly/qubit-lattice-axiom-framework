"""Actual isolated scientific variants, finite120-second cap per process."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

DIRECTORY=Path(__file__).resolve().parent
ROOT=next(p for p in DIRECTORY.parents if (p/'scripts/scalar_cosmological_inverse.py').is_file())
SOURCE=ROOT/'scripts/scalar_cosmological_inverse.py'
PROTOCOL=DIRECTORY/'SYNTHETIC_PROTOCOL_v1.json'
VARIANTS=[
    ('curvature_sign','(Hd - curvature)','(Hd + curvature)'),
    ('pressure_in_kinetic','- rho - pressure - Fdd','- rho + pressure - Fdd'),
    ('pressure_in_potential','(rho - pressure) / 2','(rho + pressure) / 2'),
    ('kinetic_second_derivative','- Fdd + H * Fd','+ Fdd + H * Fd'),
    ('potential_friction','2.5 * H * Fd','1.5 * H * Fd'),
    ('background_coupling','2 * F * D + 3 * Fd**2','2 * F * D + 6 * Fd**2'),
    ('candidate_root_branch','1 - 2 * mp.sqrt(2 * coefficient','1 + 2 * mp.sqrt(2 * coefficient'),
    ('candidate_boundary','Fc = F1 - coefficient * Y1','Fc = F1 + coefficient * Y1'),
    ('potential_Hv_normalization','mp.sqrt(L * parameters["Q"] / 2)','mp.sqrt(L * parameters["Q"])'),
    ('Jordan_first_time','Fdot = -2*F*b*velocity/A','Fdot = -2*F*b*velocity'),
    ('Jordan_second_time','Fddot = -2*F/A**2*','Fddot = -2*F/A*'),
    ('source_kinetic_factor','source_D\':2*F*(K-3*b*b)','source_D\':F*(K-3*b*b)'),
    ('source_potential_factor','source_V\':2*Q*Hv**2','source_V\':Q*Hv**2'),
    ('potential_u_origin','E = Fc / (s * (F - Fc))','E = 2 * Fc / (s * (F - Fc))'),
]


def main():
    source=SOURCE.read_text()
    work=DIRECTORY/'mutation_variants_v1'
    work.mkdir(exist_ok=False)
    entries=[]
    for name,before,after in VARIANTS:
        count=source.count(before)
        if count != 1:
            raise ValueError(f'{name}: expected one source location, got {count}')
        variant=work/(name+'.py')
        variant.write_text(source.replace(before,after,1))
        entries.append({'name':name,'before':before,'after':after,'path':str(variant.relative_to(ROOT)),
                        'sha256':hashlib.sha256(variant.read_bytes()).hexdigest()})
    (DIRECTORY/'MUTATION_FREEZE_v1.json').write_text(json.dumps({
        'frozen_at':datetime.now(timezone.utc).isoformat(),'timeout_seconds_each':120,
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'protocol_sha256':hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),'variants':entries},indent=2)+'\n')
    driver='''import importlib.util,json,sys
from pathlib import Path
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location("variant",p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.run(json.loads(Path(sys.argv[2]).read_text()))
failed=[x for x in r["checks"] if not x["passed"]]
print(json.dumps({"failed":[x["name"] for x in failed]},sort_keys=True))
assert not failed, "scientific control rejected variant"
'''
    results=[]
    for entry in entries:
        start=time.monotonic()
        try:
            result=subprocess.run([sys.executable,'-c',driver,str(ROOT/entry['path']),str(PROTOCOL)],capture_output=True,text=True,timeout=120)
            kind='assertion' if 'AssertionError: scientific control rejected variant' in result.stderr else ('guard_or_numeric_exception' if result.returncode else 'survived')
            row={**entry,'exit_code':result.returncode,'rejection_kind':kind,'elapsed_seconds':time.monotonic()-start,'stdout':result.stdout,'stderr':result.stderr}
        except subprocess.TimeoutExpired as exc:
            row={**entry,'exit_code':None,'rejection_kind':'timeout_not_scientific_rejection','elapsed_seconds':time.monotonic()-start,'stdout':str(exc.stdout),'stderr':str(exc.stderr)}
        results.append(row)
        (DIRECTORY/'MUTATION_RESULTS_v1.json').write_text(json.dumps({'results':results},indent=2)+'\n')
    print(json.dumps({'counts':{kind:sum(r['rejection_kind']==kind for r in results) for kind in sorted({r['rejection_kind'] for r in results})},'variants':len(results)},indent=2))


if __name__=='__main__':main()
