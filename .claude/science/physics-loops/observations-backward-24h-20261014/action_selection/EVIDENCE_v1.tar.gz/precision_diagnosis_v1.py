"""Post-failure diagnosis; preserves original double-precision synthetic run.

This does not improve the precision of any actual measurement or certify the ODE.
It separates rounding of the physical readouts from an exact model inverse.
"""
from pathlib import Path
import hashlib
import json
import mpmath as mp


def number(value):
    return mp.mpf(str(value))


def lift(row):
    return {key: number(value) for key, value in row.items()}


def readout_from_state(row, case):
    """Assemble metric inputs at the same saved states, using extra precision.

    rhoE and aE are recovered from the original saved rounded Jordan row. No
    original parameter answer is supplied to the downstream general inverse.
    """
    k, nu, Q0, Hv = [number(case[key]) for key in ['k', 'nu', 'Q0', 'Hv']]
    Q = Q0 * (1+k)
    u, velocity = number(row['source_u']), number(row['source_velocity'])
    rhoE = number(row['rho']) * number(row['source_A'])**4
    aE = number(row['aJ']) / number(row['source_A'])
    ac = (1-k)*(1+3*k)/4
    alpha = mp.sqrt(ac)
    s = (1+k)/(k*(1-3*k))
    E = mp.exp(2*alpha*u)
    Ep = 2*alpha*E
    W = 1+s*E
    Wp = s*Ep
    J = 1+(1-3*ac)*s*E
    Jp = (1-3*ac)*s*Ep
    K = J/W**2
    Ku = Jp/W**2-2*J*Wp/W**3
    A = mp.sqrt((1+s)*E/W)
    b = alpha/W
    bu = -alpha*Wp/W**2
    U = mp.mpf('1.5')+mp.mpf('1.5')*s*(E-1)**2/W**2+nu*(1+s)*u*u/(2*W**2)
    Uu = 3*s*(E-1)*Ep/W**2-3*s*(E-1)**2*Wp/W**3
    Uu += nu*(1+s)*(u/W**2-u*u*Wp/W**3)
    HE = mp.sqrt((K*velocity**2+2*Hv**2*U+rhoE/Q)/3)
    acceleration = -Ku*velocity**2/(2*K)-3*HE*velocity-Hv**2*Uu/K-b*rhoE/(2*Q*K)
    HEdot = -K*velocity**2-rhoE/(2*Q)
    F = Q/A**2
    Fdot = -2*F*b*velocity/A
    Fddot = -2*F/A**2*(b*acceleration+(bu-3*b*b)*velocity**2)
    H = (HE+b*velocity)/A
    Hdot = (HEdot+b*acceleration+(bu-b*b)*velocity**2-HE*b*velocity)/A**2
    return {'F':F, 'Fdot':Fdot, 'Fddot':Fddot, 'H':H, 'Hdot':Hdot,
            'rho':rhoE/A**4, 'pressure':mp.mpf(0), 'curvature':mp.mpf(0),
            'source_u':u, 'source_velocity':velocity, 'source_A':A,
            'source_D':2*F*(K-3*b*b)*(velocity/A)**2,
            'source_V':2*Q*Hv**2*U/A**4, 'source_q':b*b/K,
            'aJ':A*aE, 'timeE':number(row['timeE']), 'timeJ':number(row['timeJ'])}


def metric(row):
    row = dict(row)
    F, Fd, Fdd, H, Hd, rho, p, curvature = [row[key] for key in
        ['F','Fdot','Fddot','H','Hdot','rho','pressure','curvature']]
    row['D'] = -2*F*(Hd-curvature)-rho-p-Fdd+H*Fd
    row['V'] = F*(3*H**2+Hd+2*curvature)-(rho-p)/2+Fdd/2+mp.mpf('2.5')*H*Fd
    return row


def inverse(rows):
    first, second = rows[0], rows[6]
    Y1, Y2 = [r['Fdot']**2/r['D'] for r in [first, second]]
    c = (second['F']-first['F'])/(Y2-Y1)
    Fc = first['F']-c*Y1
    ac = 1/(2*c+3)
    k = (1-2*mp.sqrt(2*c/(2*c+3)))/3
    Q0 = 4*ac*Fc/(1+k)**2
    Q = Q0*(1+k)
    def basis(row):
        s = (1+k)/(k*(1-3*k))
        E = Fc/(s*(row['F']-Fc))
        u = mp.log(E)/(2*mp.sqrt(ac))
        W = 1+s*E
        return (mp.mpf('1.5')+mp.mpf('1.5')*s*(E-1)**2/W**2,
                (1+s)*u*u/(2*W**2))
    B01, B11 = basis(first)
    B02, B12 = basis(second)
    Z1, Z2 = first['V']/first['F']**2, second['V']/second['F']**2
    determinant = B01*B12-B02*B11
    L = (Z1*B12-Z2*B11)/determinant
    T = (B01*Z2-B02*Z1)/determinant
    return {'c':c,'Fc':Fc,'k':k,'Q0':Q0,'nu':T/L,'Hv':mp.sqrt(L*Q/2)}


def run(original):
    results = []
    for index, history in enumerate(original['histories']):
        case, rows = history['case'], history['rows']
        entry = {'case_index':index,'case':case,
                 'original_potential_condition_number':history['potential_inverse']['condition_number'],
                 'max_D_cancellation_ratio': max(sum(abs(t) for t in [-2*r['F']*r['Hdot'], -r['rho'], -r['Fddot'], r['H']*r['Fdot']])/abs(r['D']) for r in rows)}
        for dps in [50,80]:
            with mp.workdps(dps):
                for mode in ['lift_stored_readouts','reassemble_same_states']:
                    new_rows = [metric(lift(r) if mode=='lift_stored_readouts' else readout_from_state(r,case)) for r in rows]
                    recovered = inverse(new_rows)
                    errors = {key:abs(recovered[key]/number(case[key])-1) for key in ['k','Q0','nu','Hv']}
                    entry[f'{mode}_{dps}'] = {'relative_errors':{key:str(value) for key,value in errors.items()},
                                            'maximum_relative_error':str(max(errors.values())),
                                            'original_threshold_passed':bool(max(errors.values())<mp.mpf('5e-7')),
                                            'parameters':{key:str(value) for key,value in recovered.items()}}
        results.append(entry)
    return {'status':'post_failure_precision_diagnosis','cases':results,
            'original_failure_preserved':True,'threshold_changed':False,
            'scope':'Algebraic readout assembly at saved double-precision synthetic states; no high-precision trajectory or observed-input precision claim.',
            'independent_empirical_tests':0}


if __name__ == '__main__':
    directory=Path(__file__).resolve().parent
    original=directory/'RESULTS_v1.json'
    result=run(json.loads(original.read_text()))
    result['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['original_results_sha256']=hashlib.sha256(original.read_bytes()).hexdigest()
    (directory/'PRECISION_DIAGNOSIS_v1.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'reassembled_passes':{str(dps):sum(row[f'reassemble_same_states_{dps}']['original_threshold_passed'] for row in result['cases']) for dps in [50,80]},'case9':result['cases'][9]},indent=2))
