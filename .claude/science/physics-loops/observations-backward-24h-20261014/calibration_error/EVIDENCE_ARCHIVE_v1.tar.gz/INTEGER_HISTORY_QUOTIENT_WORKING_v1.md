# Integer-history quotient from native radio counts — working v1

Status: conditional-support, unreviewed working derivation. Claim type:
bounded_theorem. Root author, observations-backward campaign, 2026-10-15.
Trace: upstream_support for the count-to-field response; partially eliminates
integer-history inputs for a deliberately reduced observable. No physical
action, field state, scale, receiver error budget, or gravity fit is selected.

## Observation and exact target

The registered day169 archive is already exposed development data. Its ATDF
phase is represented modulo M=2^32 cycles; the prior full-value reconstruction
chose a nonnegative increment below M and no reset. All183329 matched endpoint
occurrences remain preserved, including18393 nonzero item87 diagnostics. Those
diagnostics are not yet a certified signed correction or physical error bound.
The encoding is distinct from the received physical phase.

Target: remove arbitrary integer histories from a usable observable, rather
than infer them from a smoothness rule or choose their minimum-energy lift.
Success is an exact quotient observable, its response/energy inequality, and
all-row precursor agreement without calling a forward-lift function. This is
not recovery of the full unwrapped phase. Later raw products remain unopened.

Primary documentation: the registered PDS label and PDS tdf_unpack guide
(corrected high-part scale), Morabito–Asmar1995 for modulo-M count processing.
TRK-2-34 J-1 note31 describes a software slip estimate in that later format;
its mapping to this ATDF field is not silently adopted. Source-level field
semantics are being checked separately.

## 1. Quotients before fitting a history

Let q_j be native endpoint phase numbers in cycles. On a supplied continuous
segment the candidate identification is

    q_j = phi_j + b_s + n_j + e_j  (mod M),   n_j in Z.

Here phi is the relevant received/reference phase under a separately supplied
transfer map; b_s is an arbitrary real constant per segment; n_j is an
arbitrary integer history; e_j is a real error with no default bound. This
model does NOT cover arbitrary real counter resets or fractional transients
unless they are included in e with a separately justified budget.

Let D be the oriented incidence matrix of consecutive endpoints. Then Db=0
within each segment. x=Dq is represented modulo M. Since M is an integer,
adding arbitrary integer histories leaves exactly the one-cycle classes

    [x]_1 in R^n/Z^n, or z_i=exp(2pi i x_i).

There is no bound on n, no preferred lift, and no monotonicity premise. On a
chain every integer edge history is Dn for an integer endpoint history, by
successive summation. Multiple chains retain their own arbitrary offsets.
Unknown real resets between endpoints are outside this identification, not
eliminated by it. A graph with loops can carry additional shared-endpoint
constraints; independent edge integers are the conservative enlargement.

Without the integer-slip premise the exact native quotient is instead R/MZ.
More generally write the established ambiguity as P Z^n, with P=M or P=1.
For v in Z^n, exp(2pi i v^T x/P) is well-defined. Conversely a linear character
exp(2pi i a^T x) descends precisely when P a_j is an integer for every j:
translate one coordinate by P, and require the phase factor to be one.

This is an algebraic consequence of the stated ambiguity group, not a claim
that all physical receiver error is integer-valued. A nonlinear response
still requires a correct phase transfer model.

## 2. Integer contrasts and a limit of real projections

For adjacent one-second counts, v=(1,-2,1) gives endpoint coefficients
gamma=(-1,3,-3,1). These annihilate every quadratic polynomial in equally
spaced endpoint time, by the finite-difference identity. Thus in a supplied
flat reference model whose initial orbit/clock contributions have that form,
their observable sensitivity vanishes, while the quotient remains defined.
This is an exact nuisance cancellation, not selection of a physical history.
Unequal durations require working in cycles and separately checking the
integer nullspace; averaging frequencies before accounting for durations is
not the same operation. A known baseline p is removed as [x-p]_P.

A real linear projection cannot generally be applied to an arbitrary lift
and then treated modulo one. For a=(1/2,1), adding (1,0) changes its phase by
pi. The projection is instead well-defined modulo1/2; multiplying the row by2
produces an integer character. In general commensurate coefficients generate
a discrete projected period, calculable from their common denominator and
integer gcd. This rescaling also rescales signal and real error and cannot
be treated as free precision.

For a=(1,sqrt(2)), the projected integer group Z+sqrt(2)Z is dense in R.
Pigeonhole approximation gives nonzero group elements arbitrarily close to
zero; their integer multiples approximate any real number. Therefore the
distance of any real value to that group is zero, and any continuous scalar
observable invariant under that group is constant. A noninteger projection
can destroy all continuous one-dimensional information when the full integer
history is left arbitrary. This is a statement about this projection class,
not a no-go for the original torus data, bounded histories, or all inference.

The curved contrast in the preceding block has beta_i=(1-H(t_i-2L))*gamma_i.
For rational t0,L,spacing and an irrational dimensionless H, coefficients can
generate a dense group. In the prior fixture t0=7/5,L=3/5,spacing1,
beta0=-1+H/5 and beta3=1-16H/5; beta0+beta3=-3H, while
15beta0+(beta0+beta3)=-15. Thus its projected ambiguity contains both15Z
and3H Z and is dense if H is irrational. The prior real-valued contrast is
valid for calibrated real counts; it is not automatically a character on
the one-cycle quotient. Finite measurement precision does not derive whether
the physical H is rational. Keep this domain boundary visible.

## 3. Conditional field-energy bound without choosing a lift

Let Hfield be a real Hilbert space with squared norm N, and let A:Hfield->R^n
be a bounded linear observation map. For a scalar integer contrast v define
sigma_v=||A* v||. Suppose the supplied physical observation model obeys

    r = A h + e + P k,   k in Z^n,

where r is any representative after subtracting a specified baseline. If
|v^T e|<=eta_v, put g=gcd(|v_1|,...,|v_n|)>0 and

    d = dist(v^T r, g P Z).

For every admissible h, e, k,

    d <= |v^T A h|+eta_v <= sigma_v sqrt(N)+eta_v,
    N >= max(d-eta_v,0)^2/sigma_v^2.                    (1)

If a separately justified physical-energy conversion is E>=q N, q>0,
multiply (1) by q. There is no inferred actual E, upper energy budget, or
selected minimizing initial state. If sigma_v=0 and d>eta_v the supplied
model is inconsistent; if d<=eta_v there is no positive bound from this row.
The zero contrast carries no information. A phase-error box |e_endpoint,j|
<=epsilon_j supplies eta_v=sum_j |(D^T v)_j| epsilon_j; shared endpoints
must be combined before bounding, rather than counted twice as independent.

For a single nonzero functional, absent real error and without any other
observation constraint, the bound is sharp: choose a nearest integer multiple
and a Riesz-representer field achieving that scalar response. Bezout's identity
realizes the multiple as v^T k. This is a proof of a universal lower bound's
sharpness, not a physical state-selection rule. For the whole observation
vector it can be conservative because the other rows constrain the same h.

When G=A A* is positive definite, the exact infimum over all fields and all
integer histories for error-free data is

    Ninf = min_{k in Z^n} (r+P k)^T G^{-1}(r+P k).      (2)

For each real target y, Hilbert projection gives minimum y^T G^{-1}y.
Positive definiteness makes the lattice objective coercive, so the minimum
exists. If the supplied real-error set is the ellipsoid e^T G^{-1}e<=eta^2,
the exact infimum becomes max(sqrt(Ninf)-eta,0)^2, by triangle inequality and
moving along a nearest lattice representative. The actual error set is not
derived by choosing this ellipsoid. Singular G requires an exact range
condition and separate treatment; the SPD statement is not silently extended.

Componentwise nearest-integer rounding need not minimize (2). In the earlier
exact two-count example G=[[3064,-1871],[-1871,3064]]/(1620pi), take
r=(49/100,49/100). Its positive off-diagonal G^{-1} term favors opposite signs;
a lift with one coordinate decreased by1 beats the componentwise choice.
This is an exact mathematical fixture, not an observed Cassini residual.

## 4. Information and empirical limits

For a primitive scalar contrast d<=P/2, so a one-cycle quotient intentionally
loses all integer-cycle information and its direct lower bound saturates.
That loss is the price of eliminating unrestricted integer histories.
The characteristic period is one native cycle, not one fractional Doppler
unit or one normalized radio frequency. Turnaround ratios, resampling and
frequency normalization must be applied with the correct lattice map.

The all-row check below compares dependent archive products in quotient space.
It can remove the bounded-lift premise from their agreement and test code and
format semantics. It cannot validate phi as sky phase, certify receiver noise,
separate plasma or clock effects, supply a trajectory, or test the scalar
theory. Native third endpoint differences are descriptive data summaries,
not scalar residuals. Zero or nonzero item87 is not used as a selection rule.

Remaining suppliers: correct physical phase transfer and baseline, actual
continuous segments/reset behavior, real error bounds, action/background and
field-energy normalization, nonlinear/source corrections, and an actual
same-environment comparison. These are not retired by quotienting.
