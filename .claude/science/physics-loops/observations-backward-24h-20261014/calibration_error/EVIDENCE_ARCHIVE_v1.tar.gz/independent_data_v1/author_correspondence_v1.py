#!/usr/local/bin/python3
"""Affected artifact correspondence only; no author decoder/runner imports."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import zip_longest
from datetime import datetime,timezone
import gzip,hashlib,json,ast,difflib

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[5]
AUTH=ROOT/'outputs/scalar_phase_quotient'
WORK=OUT.parent
M=2**32
META=(3,12,19,24,29,79,84,85,86,87,88)


def center(x,m=1):return (x+F(m,2))%m-F(m,2)
def digest(x):return hashlib.sha256(x).hexdigest()
def jlines(path):
    op=gzip.open if str(path).endswith('.gz') else open
    with op(path,'rt') as f:
        for line in f:yield json.loads(line)
def load(path):return json.loads(path.read_text())
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def run():
    snapshot=OUT/'author_correspondence_sources_v1'
    snapshot.mkdir(exist_ok=False)
    source_paths=[ROOT/'scripts/cassini_phase_quotient_development.py',ROOT/'scripts/scalar_phase_quotient_check.py',
        WORK/'cassini_quotient_development_v1.py',ROOT/'scripts/scalar_phase_quotient_controls.py',
        WORK/'integer_history_controls_v1.py',ROOT/'scripts/cassini_atdf_decode.py',ROOT/'scripts/cassini_odf_decode.py',
        ROOT/'scripts/cassini_doppler_development_inputs.json',WORK/'DEVELOPMENT_PROTOCOL_v1.json',
        WORK/'QUOTIENT_DEVELOPMENT_RESULTS_v1.json',AUTH/'QUOTIENT_DEVELOPMENT_RESULTS_v1.json',AUTH/'summary.json']
    identities=[]
    for i,p in enumerate(source_paths):
        b=p.read_bytes();name=f'{i:02d}_{p.name}';(snapshot/name).write_bytes(b)
        identities.append({'path':str(p.relative_to(ROOT)),'sha256':digest(b),'bytes':len(b),'snapshot':name})
    data=load(AUTH/'QUOTIENT_DEVELOPMENT_RESULTS_v1.json');summary=load(AUTH/'summary.json');working=load(WORK/'QUOTIENT_DEVELOPMENT_RESULTS_v1.json')
    summary_mismatches=[]
    for p,h in summary['source_sha256'].items():
        if digest((ROOT/p).read_bytes())!=h:summary_mismatches.append(p)
    for p,h in summary['product_sha256'].items():assert digest((AUTH/p).read_bytes())==h
    a=dict(data);b=dict(working)
    a.pop('source_sha256');b.pop('source_sha256');b.pop('created_at')
    assert a==b
    adaptation=''.join(difflib.unified_diff((WORK/'cassini_quotient_development_v1.py').read_text().splitlines(True),
        (ROOT/'scripts/cassini_phase_quotient_development.py').read_text().splitlines(True),fromfile='working',tofile='canonical'))
    (OUT/'AUTHOR_ADAPTATION_DIFF_v1.patch').write_text(adaptation)
    # The only imported math callable on the data path has identical AST.
    def centered_ast(path):
        node=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='centered')
        return ast.dump(node,include_attributes=False)
    assert centered_ast(WORK/'integer_history_controls_v1.py')==centered_ast(ROOT/'scripts/scalar_phase_quotient_controls.py')
    # Reuse the frozen independent extraction. Only newly required metadata
    # words are read directly from the already registered raw ATDF.
    independent_atdf={r['record']:r for r in jlines(OUT/'ATDF_EXTRACTED_FIELDS_v1.jsonl')}
    independent_odf={r['record']:r for r in jlines(OUT/'ODF_EXTRACTED_FIELDS_v1.jsonl')}
    raw=(ROOT/'outputs/cassini_doppler_inputs/c32easc2002_169_0000xmmmv0.tdf').read_bytes()
    assert digest(raw)=='215c2de473fd00b278267ab3ff0431ab4d00e9c3baaa17e949105b964644f4f3'
    extra={79:(1440,8,False),84:(1456,1,False),85:(1457,1,False),86:(1458,8,False),88:(1476,18,True)}
    extra_decoded={}
    def metadata(record):
        row=independent_atdf[record];d={int(k):v for k,v in row['items'].items()}
        if record not in extra_decoded:
            bits=''.join(f'{byte:08b}' for byte in raw[(record-1)*288:record*288])
            extras={}
            for key,(offset,width,signed) in extra.items():
                sub=bits[offset:offset+width];v=int(sub,2)
                extras[key]=v-(1<<width) if signed and sub[0]=='1' else v
            extra_decoded[record]=extras
        d.update(extra_decoded[record]);return tuple(d[k] for k in META)
    calendar=Counter();samples=Counter();flags=Counter();spacecrafts=set()
    for r in independent_atdf.values():
        d=r['items'];calendar[(d['4'],d['5'])]+=1;samples[d['12']]+=1;spacecrafts.add(d['15'])
        if d['12'] in (1,2,7,11,12):flags[(d['5'],d['19'],d['24'],d['87'])]+=1
    assert dict(samples)=={int(k):v for k,v in data['raw_sample_types'].items()}
    assert calendar==Counter({(x['year_mod1900'],x['day']):x['rows'] for x in data['raw_calendar_counts']})
    assert flags==Counter({(x['day'],x['item19'],x['item24'],x['item87']):x['records'] for x in data['raw_doppler_flag_counts']})
    expected_ids={n for n,r in independent_odf.items() if r['items']['10'] in (11,12,13)}
    row_seen=set();numeric_variants=0;metadata_count=0;metadata_occ=Counter();used={};known={};native={};stored={};slip={}
    for a,b in zip_longest(jlines(AUTH/'QUOTIENT_ROWS_v1.jsonl.gz'),jlines(OUT/'ALL_INTERVAL_COMPARISONS_v1.jsonl')):
        assert a is not None and b is not None
        n=a['odf_record'];assert n==b['record'] and n not in row_seen;row_seen.add(n)
        d=independent_odf[n]['items'];dt=F(b['duration']);stored[n]=dt*F(d['4']*10**9+d['5'],10**9)
        assert F(a['stored_representative_cycles'])==stored[n]
        assert (a['left_seconds'],a['right_seconds'])==(int(F(b['start'])),int(F(b['end'])))
        assert F(a['duration_seconds'])==dt and a['outcome']=='quotient_reconstructed'
        assert [a['type'],a['rx'],a['tx'],a['odf_bad']]==[d['10'],d['7'],d['8'],d['14']]
        expected=[[r['start'] for r in b['comparisons']],[r['end'] for r in b['comparisons']]]
        for i in (0,1):
            candidates=a['endpoint_candidates'][i]
            assert [z['record'] for z in candidates]==list(dict.fromkeys(expected[i]))
            for z in candidates:
                meta=metadata(z['record']);assert tuple(z['metadata'])==meta
                metadata_occ[meta]+=1;metadata_count+=1;used[z['record']]=meta
        flat=[z for side in a['endpoint_candidates'] for z in side]
        slip[n]=any(z['metadata'][META.index(87)]>0 for z in flat)
        good=all(z['metadata'][META.index(19)]==z['metadata'][META.index(24)]==0 for z in flat)
        assert a['any_item87_nonzero']==slip[n] and a['all_item19_item24_zero']==good
        for r in b['comparisons']:
            numeric_variants+=1
            delta=F(independent_atdf[r['end']]['phase'])-F(independent_atdf[r['start']]['phase'])
            reference_cycles=F(r['Q_cycles'])-stored[n]
            nativ=delta-reference_cycles
            assert F(a['native_representative_cycles'])==nativ
            assert F(a['native_mod_one_cycles'])==center(nativ)
            assert F(a['error_mod_M_cycles'])==center(-F(r['raw_difference_cycles']),M)
            assert F(a['error_mod_one_cycles'])==center(-F(r['raw_difference_cycles']))
            known[n]=reference_cycles;native[n]=nativ
    assert row_seen==expected_ids
    assert metadata_count==data['counts']['matched_endpoint_occurrences']
    assert metadata_occ==Counter({tuple(x['values']):x['occurrences'] for x in data['endpoint_metadata_occurrences']})
    assert len(used)==data['unique_matched_endpoint_records']
    assert sum(v[META.index(87)]>0 for v in used.values())==data['unique_matched_nonzero_item87']
    assert sum(count for v,count in metadata_occ.items() if v[META.index(87)]>0)==data['counts']['endpoint_occurrences_nonzero_item87']
    # Hash and exact-byte checks establish old/canonical ledger correspondence,
    # without rerunning either raw path.
    ledger=[]
    for name in ['QUOTIENT_ROWS_v1.jsonl.gz','QUOTIENT_TRIPLES_v1.jsonl.gz']:
        ca=(AUTH/name).read_bytes();wo=(WORK/name).read_bytes();assert ca==wo
        unpacked=gzip.decompress(ca);role='rows' if 'ROWS' in name else 'triples'
        assert digest(ca)==data['ledgers'][role]['compressed_sha256']
        assert digest(unpacked)==data['ledgers'][role]['uncompressed_sha256']
        assert ca[4:8]==b'\0\0\0\0' # zero mtime; stable gzip header
        ledger.append({'path':name,'compressed_sha256':digest(ca),'uncompressed_sha256':digest(unpacked),'rows':unpacked.count(b'\n')})
    independent_triples={tuple(r['ODF_records']):r for r in jlines(OUT/'ALL_THIRD_DIFFERENCES_v1.jsonl')}
    seen=set();triple_variants=0;strata=defaultdict(Counter);bins=[F(x) for x in data['third_difference_bins_upper_abs_cycles']]
    for r in jlines(AUTH/'QUOTIENT_TRIPLES_v1.jsonl.gz'):
        key=tuple(r['odf_records']);assert key in independent_triples and key not in seen;seen.add(key)
        assert known[key[0]]-2*known[key[1]]+known[key[2]]==0
        numeric=F(r['native_third_endpoint_mod_one']);reference=F(r['odf_comparison_mod_one']);err=F(r['comparison_error_cycles'])
        assert numeric==center(native[key[0]]-2*native[key[1]]+native[key[2]])
        assert reference==center(stored[key[0]]-2*stored[key[1]]+stored[key[2]])
        for v in independent_triples[key]['comparisons']:
            triple_variants+=1
            assert numeric==center(F(v['third_phase_difference_cycles']))
            assert reference==center(F(v['ODF_cycle_difference']))
            assert err==center(-F(v['mod_one_cycle']))
        flag=any(slip[n] for n in key);assert r['any_recorded_slip_diagnostic']==flag
        edge=next(x for x in bins if abs(numeric)<=x)
        strata[(r['stream'],flag)][str(edge)]+=1
    assert seen==set(independent_triples)
    assert dict(strata)=={(r['stream'],r['any_nonzero_item87']):Counter(r['bin_counts']) for r in data['third_difference_strata']}
    code=ast.parse((ROOT/'scripts/cassini_phase_quotient_development.py').read_text())
    # The data module has no calls to an unwrap, forward-history or scalar-floor
    # function; mathematical toy examples in a different run are not data fits.
    calls=[n.func.id if isinstance(n.func,ast.Name) else n.func.attr for n in ast.walk(code) if isinstance(n,ast.Call) and isinstance(n.func,(ast.Name,ast.Attribute))]
    assert not set(calls)&{'forward_increment','unwrap','scalar_energy_floor','lattice_minimum_2d'}
    results={'scope':'Complete affected source/ledger correspondence; no raw source-suite rerun',
        'interval_rows':len(row_seen),'all_numeric_interval_variants_checked':numeric_variants,
        'all_endpoint_candidate_metadata_occurrences_checked':metadata_count,
        'unique_endpoint_raw_metadata_records_checked':len(extra_decoded),
        'new_metadata_fields_checked_against_raw_bits':list(extra),
        'numeric_triple_rows':len(seen),'independent_endpoint_variant_triple_comparisons':triple_variants,
        'reference_second_difference_exactly_zero_on_all_triples':True,
        'working_and_canonical_results_equal_except_created_at_and_source_identity':True,
        'centered_function_AST_identical':True,'ledgers':ledger,
        'summary_source_mismatches_at_check':summary_mismatches,
        'ATDF_spacecraft_ids':sorted(spacecrafts),'all_numeric_and_metadata_mismatches':0,
        'constant_outputs_verified':{'physical_error_bounds_inferred':summary['physical_error_bounds_inferred'],
            'independent_empirical_tests':summary['independent_empirical_tests'],'fitted_parameters':summary['fitted_parameters']},
        'scientific_claim_boundary':'Stored quotients and dependent archive conversion only; supplied receiver convention and integer-history ambiguity remain explicit.'}
    dump('AUTHOR_CORRESPONDENCE_RESULTS_v1.json',results)
    dump('AUTHOR_CORRESPONDENCE_INPUTS_v1.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'sources':identities})
    print(json.dumps(results,indent=2))

if __name__=='__main__':run()
