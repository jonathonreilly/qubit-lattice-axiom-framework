#!/usr/bin/env python3
"""Read-only identity comparison; no author imports or scientific re-execution."""
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
RUNTIME = Path('/Users/jonBridger/.codex/campaigns/observations-backward-24h-20261014')
OUT = Path(__file__).resolve().parent
PRODUCTS = ROOT/'outputs/scalar_phase_quotient'
SNAP = OUT/'author_correspondence_sources_v1'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def identity(path):
    body = path.read_bytes()
    return {'path': str(path), 'sha256': sha(body), 'bytes': len(body)}


def changes(old, new, path=''):
    if isinstance(old, dict) and isinstance(new, dict):
        answer = []
        for key in sorted(old.keys() | new.keys()):
            if key not in old or key not in new:
                answer.append({'path': path+'/'+key, 'old': old.get(key), 'new': new.get(key)})
            else:
                answer.extend(changes(old[key], new[key], path+'/'+key))
        return answer
    return [] if old == new else [{'path': path, 'old': old, 'new': new}]


cache_path = ROOT/'logs/runner-cache/scalar_phase_quotient_check.txt'
receipt_path = RUNTIME/'M8_CANONICAL_EXECUTION_v2.json'
cache_bytes = cache_path.read_bytes()
receipt_bytes = receipt_path.read_bytes()
summary_bytes = (PRODUCTS/'summary.json').read_bytes()
summary = json.loads(summary_bytes)
receipt = json.loads(receipt_bytes)
assert sha(cache_bytes) == '8e75f43ab810d290e779a792a3b88d2df58e2854ead46783b79318476a1de5f2'
assert sha(receipt_bytes) == '2f1c1e107d3ea8a0594fc4756931936a745ae05161b4193df151e2d1041dbe07'
assert sha(summary_bytes) == '6ca043e5985467092fa3cad22e5faae3082787e4deb1f74d87ba98cb13e2fc46'
header, body = cache_bytes.decode().split('----- stdout -----\n', 1)
stdout, stderr = body.split('----- stderr -----\n', 1)
cached_summary, json_end = json.JSONDecoder().raw_decode(stdout)
assert cached_summary == summary
assert not stderr.strip()
fields = dict(line.split(': ', 1) for line in header.splitlines() if ': ' in line)
assert fields['status'] == 'ok' and fields['exit_code'] == '0'
assert fields['runner'] == 'scripts/scalar_phase_quotient_check.py'
assert fields['timeout_sec'] == '180'
assert 0 < float(fields['elapsed_sec']) < 180
assert receipt['cache_sha256'] == sha(cache_bytes)
assert receipt['cache_status'] == 'fresh'
assert receipt['execution']['status'] == 'ok' and receipt['execution']['exit_code'] == 0
assert receipt['execution']['timeout_sec'] == 180
assert receipt['execution']['elapsed_sec'] == 7.639117002487183
assert round(receipt['execution']['elapsed_sec'], 2) == float(fields['elapsed_sec'])

prior = json.loads((OUT/'AUTHOR_CORRESPONDENCE_IDENTITY_v2.json').read_text())
for old in prior['files']:
    assert identity(ROOT/old['path'])['sha256'] == old['sha256'], old['path']
bound_pairs = {
    'scripts/cassini_phase_quotient_development.py': 'AUTHOR_BOUND_data_v1.py',
    'scripts/scalar_phase_quotient_controls.py': 'AUTHOR_BOUND_math_v1.py',
    'scripts/scalar_phase_quotient_check.py': 'AUTHOR_BOUND_primary_v1.py',
    'docs/SCALAR_PHASE_QUOTIENT_INTEGER_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-15.md': 'AUTHOR_BOUND_note_v1.md',
}
for rel, preserved in bound_pairs.items():
    assert (ROOT/rel).read_bytes() == (OUT/preserved).read_bytes(), rel
for rel, expected in summary['source_sha256'].items():
    assert sha((ROOT/rel).read_bytes()) == expected, rel
assert fields['runner_sha256'] == summary['source_sha256'][fields['runner']]

# Reimplement the documented fingerprint framing, without importing runner_cache.
runner_tree = ast.parse((ROOT/fields['runner']).read_text())
declarations = {}
for node in runner_tree.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ('AUDIT_INPUT_PATHS', 'AUDIT_TIMEOUT_SEC'):
                declarations[target.id] = ast.literal_eval(node.value)
inputs = declarations['AUDIT_INPUT_PATHS']
assert declarations['AUDIT_TIMEOUT_SEC'] == 180
assert len(inputs) == len(set(inputs)) == 7
assert set(summary['source_sha256']) == set(inputs) | {fields['runner']}
digest = hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in inputs:
    rb = rel.encode('utf-8')
    data = (ROOT/rel).read_bytes()
    digest.update(len(rb).to_bytes(8, 'big'))
    digest.update(rb)
    digest.update(len(data).to_bytes(8, 'big'))
    digest.update(data)
assert digest.hexdigest() == fields['input_fingerprint_sha256']
assert digest.hexdigest() == '9cfa7c4e53f17bde6202e927dd31d8d3e28fb6f0ed9c4d5825f3d62286ded2b7'

manifest = json.loads((ROOT/'scripts/cassini_doppler_development_inputs.json').read_text())
assert manifest['inputs'] == summary['external_scientific_inputs_read']
raw_identities = []
for entry in manifest['inputs'].values():
    raw = identity(ROOT/'outputs/cassini_doppler_inputs'/entry['filename'])
    assert raw['sha256'] == entry['sha256'] and raw['bytes'] == entry['bytes']
    raw_identities.append(raw)

product_identities = []
for name, expected in summary['product_sha256'].items():
    product = identity(PRODUCTS/name)
    assert product['sha256'] == expected, name
    product_identities.append(product)

development = json.loads((PRODUCTS/'QUOTIENT_DEVELOPMENT_RESULTS_v1.json').read_text())
historical_development = json.loads((SNAP/'10_QUOTIENT_DEVELOPMENT_RESULTS_v1.json').read_text())
development_changes = changes(historical_development, development)
assert development_changes == [{
    'path': '/source_sha256',
    'old': '1cddc8b9ffd65d511b273c04e2bfab9bed0fdc17484e006f49ac667e8b67cdcd',
    'new': 'ebc2df3069731b47eb446b9ed267008af22a6d53ac230dd0b520c7c951ebc4e5',
}]

expected_ledgers = {
    'QUOTIENT_ROWS_v1.jsonl.gz': ('04b7af8c9911b71ec6fa011441fca25de2eb2ba262caa7f8b7b4f431d8edb59a', '79a0e0dff422559c0620450afdf551dbe2a4dd22c0382ba7dbe0e49873b5ae08', 91664),
    'QUOTIENT_TRIPLES_v1.jsonl.gz': ('f5f6db505b0e142728c445f8f6dc59574854fa9319462b664139ac622f05c973', 'c3c8738eee6c0fae6aaf6f2b11694177839068cc83261cb550d40ececc338ddf', 91593),
}
ledger_identities = []
for name, (compressed_hash, uncompressed_hash, line_count) in expected_ledgers.items():
    assert sha((PRODUCTS/name).read_bytes()) == compressed_hash
    uncompressed = hashlib.sha256()
    lines = 0
    size = 0
    with gzip.open(PRODUCTS/name, 'rb') as stream:
        while chunk := stream.read(1024*1024):
            uncompressed.update(chunk)
            size += len(chunk)
            lines += chunk.count(b'\n')
    assert uncompressed.hexdigest() == uncompressed_hash and lines == line_count
    ledger_identities.append({'filename': name, 'compressed_sha256': compressed_hash,
                              'uncompressed_sha256': uncompressed_hash,
                              'uncompressed_bytes': size, 'rows': lines})

historical_summary = json.loads((SNAP/'11_summary.json').read_text())
summary_changes = changes(historical_summary, summary)
assert {change['path'] for change in summary_changes} == {
    '/checks_passed', '/mathematical_controls',
    '/product_sha256/QUOTIENT_DEVELOPMENT_RESULTS_v1.json',
    '/product_sha256/mathematics.json',
    '/source_sha256/docs/SCALAR_PHASE_QUOTIENT_INTEGER_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-15.md',
    '/source_sha256/scripts/cassini_phase_quotient_development.py',
    '/source_sha256/scripts/scalar_phase_quotient_controls.py',
}
assert historical_summary['checks_passed'] == 45 and historical_summary['mathematical_controls'] == 34
assert summary['checks_passed'] == 49 and summary['mathematical_controls'] == 38
assert summary['development_controls'] == historical_summary['development_controls']
assert len(summary['development_controls']) == 11 and all(summary['development_controls'].values())
math = json.loads((PRODUCTS/'mathematics.json').read_text())
assert math['passed'] == 38 and math['failed'] == 0
assert len(math['checks']) == 38 and all(math['checks'].values())
assert math['two_count_Gram_example'] == summary['two_count_Gram_example']
assert all(summary[key] == 0 for key in ('independent_empirical_tests', 'fitted_parameters',
                                       'physical_energy_estimates', 'physical_error_bounds_inferred'))

checked_paths = [cache_path, receipt_path, PRODUCTS/'summary.json',
                 OUT/'AUTHOR_CORRESPONDENCE_REVIEW_v2.md', OUT/'AUTHOR_CORRESPONDENCE_IDENTITY_v2.json',
                 SNAP/'10_QUOTIENT_DEVELOPMENT_RESULTS_v1.json', SNAP/'11_summary.json']
result = {
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Narrow source/product/cache identity confirmation; no numerical or raw-decoding rerun; no author modules imported.',
    'status': 'All declared identity and unchanged-output comparisons agree.',
    'cache': identity(cache_path), 'execution_receipt': identity(receipt_path),
    'summary': identity(PRODUCTS/'summary.json'),
    'input_fingerprint_sha256': digest.hexdigest(),
    'source_sha256': summary['source_sha256'], 'raw_hash_only_identities': raw_identities,
    'product_identities': product_identities, 'ledgers': ledger_identities,
    'development_changes_from_preliminary': development_changes,
    'summary_changes_from_preliminary': summary_changes,
    'prior_report_identity_files_verified_unchanged': len(prior['files']),
    'checks_reported_by_author_execution': {'mathematics': 38, 'development': 11},
    'mathematical_proof_scope': 'Other reviewer; this supplement binds its reported execution without rerunning or newly reviewing the proof.',
    'boundary': 'Dependent exposed archive products; zero physical noise bounds, scalar-energy estimates, fits or independent empirical tests.',
    'checked_identity_context': [identity(path) for path in checked_paths],
}
# Snapshot the exact small envelope objects only after every check passed.
for name, data in [('FINAL_ENVELOPE_CACHE_v1.txt', cache_bytes),
                   ('FINAL_ENVELOPE_EXECUTION_v1.json', receipt_bytes),
                   ('FINAL_ENVELOPE_SUMMARY_v1.json', summary_bytes)]:
    with (OUT/name).open('xb') as stream:
        stream.write(data)
with (OUT/'FINAL_ENVELOPE_CHECK_v1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'cache', 'summary', 'input_fingerprint_sha256')}, indent=2))
