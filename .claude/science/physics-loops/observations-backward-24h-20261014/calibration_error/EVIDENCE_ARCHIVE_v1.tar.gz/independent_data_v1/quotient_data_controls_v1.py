#!/usr/local/bin/python3
"""Independent raw bit-string + rational quotient comparison; no history lift."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
from itertools import product
import hashlib
import json
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[5]
RAW = ROOT / 'outputs/cassini_doppler_inputs'
MODULUS = 2**32
AUDIT_TIMEOUT_SEC = 240


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def encoded(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, (tuple, list)):
        return [encoded(y) for y in x]
    if isinstance(x, dict):
        return {str(k): encoded(v) for k, v in x.items()}
    return x


def emit(stream, row):
    stream.write(json.dumps(encoded(row), separators=(',', ':')) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bitstring(blob):
    # Separate extraction implementation: indexed binary characters, not
    # the author whole-record integer masks or any imported decoder.
    return ''.join(format(byte, '08b') for byte in blob)


def word(bits, position, width, signed=False):
    section = bits[position:position + width]
    assert len(section) == width
    value = int(section, 2)
    return value - (1 << width) if signed and section[0] == '1' else value


def quotient_residue(value, period):
    # Only a representative of an error coset. Does NOT select a physical
    # increment, history, reset count, or counter rollover.
    return (value + F(period, 2)) % period - F(period, 2)


ATDF_FIELDS = {
    1:(0,32), 3:(40,32), 4:(72,12), 5:(84,16), 6:(100,8),
    7:(108,8), 8:(116,8), 10:(144,10), 11:(154,8), 12:(162,6),
    13:(168,4), 14:(172,4), 15:(176,16), 19:(216,1), 20:(217,18),
    22:(236,1), 23:(237,1), 24:(238,1), 25:(239,1), 26:(240,6),
    27:(246,6), 28:(252,4), 29:(256,32), 30:(288,24),
    31:(312,24), 32:(336,24), 43:(588,32), 44:(620,32), 87:(1466,10),
}
ODF_WIDTHS = [32,10,22,32,32,3,7,7,2,6,2,2,2,1,7,10,1,22,24,20,22,22]
# Every static item except time, observable, duration and station delays.
CHAIN_ITEMS = [6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]


def decode_atdf():
    raw = (RAW / 'c32easc2002_169_0000xmmmv0.tdf').read_bytes()
    assert len(raw) == 160888 * 288
    index = defaultdict(list)
    all_rows = {}
    inventory = Counter()
    with (OUT / 'ATDF_EXTRACTED_FIELDS_v1.jsonl').open('w') as file:
        for rec in range(3, 160873):
            bits = bitstring(raw[(rec-1)*288:rec*288])
            a = {i:word(bits, *spec, signed=(i == 20)) for i,spec in ATDF_FIELDS.items()}
            assert a[1] == 8 and a[3] in (90,91)
            stamp = (date(a[4]+1900, 1, 1) - date(1950, 1, 1)).days*86400
            stamp += (a[5]-1)*86400+a[6]*3600+a[7]*60+a[8]
            phase = F(a[30]*10**14+a[31]*10**7+a[32],10**6)
            reference = F(a[43]*10**9+a[44],10**6)
            key = (stamp,a[10],a[11],a[14],a[13],a[15])
            row = {'record':rec,'items':a,'key':key,'phase':phase,'reference':reference}
            all_rows[rec] = row
            inventory[(a[12],a[14],a[3],a[19],a[24])] += 1
            # The sample identifier selects only the explicit Doppler/phase
            # families. No quality, slip, phase value, or residual cut.
            if a[12] in (1,2,7,11,12):
                index[key].append(row)
            emit(file,row)
    return index,all_rows,inventory


def decode_odf():
    raw = (RAW / 'c32easc2002_169_0000xmmmv0.odf').read_bytes()
    assert len(raw) == 92064*36 and sum(ODF_WIDTHS) == 288
    rows = []
    types = Counter()
    with (OUT / 'ODF_EXTRACTED_FIELDS_v1.jsonl').open('w') as file:
        for rec in range(6,91869):
            bits = bitstring(raw[(rec-1)*36:rec*36])
            cursor = 0
            a = {}
            for i,width in enumerate(ODF_WIDTHS,1):
                a[i] = word(bits,cursor,width,signed=i in (4,5,20))
                cursor += width
            assert a[6] == 2
            types[a[10]] += 1
            row = {'record':rec,'items':a}
            emit(file,row)
            if a[10] not in (11,12,13):
                continue
            middle = F(a[1]*1000+a[2],1000)
            duration = F(a[21],100)
            assert duration > 0
            row.update(start=middle-duration/2,end=middle+duration/2,T=duration,
                       D=F(a[4]*10**9+a[5],10**9),
                       reference=F(a[18]*2**24+a[19],1000),
                       chain=tuple(a[i] for i in CHAIN_ITEMS))
            rows.append(row)
    return rows,types


def endpoint_key(o,stamp):
    a = o['items']
    return (stamp,a[7],a[11],a[10]-10,a[15],a[16])


def cycle_increment(o,start):
    ref = F(880,221)*start['reference']-F(11,3)*o['reference'] if o['items'][10] == 11 else F(0)
    return o['T']*(o['D']+10**6+ref)


def storage_scale(o):
    scale = F(2,10**6)+o['T']*F(1,10**9)
    if o['items'][10] == 11:
        scale += o['T']*(F(11,3)*F(1,1000)+F(880,221)*F(1,10**6))
    return scale


def nominally_good(a):
    return a['items'][19] == 0 and a['items'][24] == 0


def slipped(a):
    return a['items'][87] > 0


def run():
    begin = time.monotonic()
    ids = json.loads((OUT/'INPUT_IDENTITY_v1.json').read_text())
    for item in ids['inputs']:
        path = Path(item['path'])
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    # External exact published count example, fixed before observed comparison.
    assert F(16*10**14+4398198*10**7+1475000,10**6) == F('1643981981.475')
    assert quotient_residue(F(1,4)+MODULUS,MODULUS) == F(1,4)
    assert quotient_residue(F(-3,4),1) == F(1,4)
    idx,atdf,inventory = decode_atdf()
    odf,types = decode_odf()
    matched_records = set()
    match_quality = Counter()
    endpoint_uses = Counter()
    variants = Counter()
    unmatched = []
    maxM = (F(0),None)
    max1 = (F(0),None)
    maxM_coherent = (F(0),None)
    failures = []
    duplicate_rows = []
    interval_good_slip = []
    interval_any_good_slip = []
    ref_change = []
    variant_count = 0
    with (OUT/'ALL_INTERVAL_COMPARISONS_v1.jsonl').open('w') as out:
        for o in odf:
            starts = idx.get(endpoint_key(o,o['start']),[])
            ends = idx.get(endpoint_key(o,o['end']),[])
            o['starts'],o['ends'] = starts,ends
            variants[(len(starts),len(ends))] += 1
            if not starts or not ends:
                unmatched.append(o['record'])
                emit(out,{'record':o['record'],'missing':True,'start_variants':[a['record'] for a in starts],
                          'end_variants':[b['record'] for b in ends]})
                continue
            if len(starts)>1 or len(ends)>1:
                duplicate_rows.append(o['record'])
            interval_flag = False
            any_flag = False
            comps = []
            for a,b in product(starts,ends):
                variant_count += 1
                matched_records.update((a['record'],b['record']))
                endpoint_uses[a['record']] += 1
                endpoint_uses[b['record']] += 1
                qa,qb = a['items'],b['items']
                match_quality[(qa[19],qa[24],qa[87],qb[19],qb[24],qb[87])] += 1
                assert qa[26] == qb[26] == 5
                assert qa[20] == qb[20] == 1000
                assert qa[22] == qb[22] == qa[23] == qb[23] == 1
                if a['reference'] != b['reference']:
                    ref_change.append([o['record'],a['record'],b['record']])
                Q = cycle_increment(o,a)
                raw_difference = b['phase']-a['phase']-Q
                rM = quotient_residue(raw_difference,MODULUS)
                r1 = quotient_residue(raw_difference,1)
                tol = storage_scale(o)
                for residue,name in [(rM,'M'),(r1,'1')]:
                    if abs(residue)>tol:
                        failures.append([o['record'],a['record'],b['record'],name,str(residue),str(tol)])
                if abs(rM)>maxM[0]:maxM = (abs(rM),o['record'])
                if abs(r1)>max1[0]:max1 = (abs(r1),o['record'])
                if o['items'][10] != 11 and abs(rM)>maxM_coherent[0]:maxM_coherent = (abs(rM),o['record'])
                interval_flag |= nominally_good(a) and nominally_good(b) and (slipped(a) or slipped(b))
                any_flag |= (nominally_good(a) and slipped(a)) or (nominally_good(b) and slipped(b))
                comps.append({'start':a['record'],'end':b['record'],'Q_cycles':Q,
                              'raw_difference_cycles':raw_difference,'mod_2pow32_cycles':rM,
                              'mod_one_cycle':r1,'storage_scale_cycles':tol,
                              'quality':[qa[19],qa[24],qa[87],qb[19],qb[24],qb[87]]})
            if interval_flag:interval_good_slip.append(o['record'])
            if any_flag:interval_any_good_slip.append(o['record'])
            emit(out,{'record':o['record'],'start':o['start'],'end':o['end'],'duration':o['T'],
                      'type':o['items'][10],'comparisons':comps})
    strata = defaultdict(list)
    for o in odf:strata[o['chain']].append(o)
    chains = []
    boundaries = Counter()
    for key,rows in sorted(strata.items()):
        rows.sort(key=lambda x:(x['start'],x['end'],x['record']))
        current = []
        for o in rows:
            if current and current[-1]['end'] != o['start']:
                old = current[-1]
                kind = 'duplicate' if (old['start'],old['end']) == (o['start'],o['end']) else ('gap' if o['start']>old['end'] else 'overlap')
                boundaries[kind] += 1
                chains.append((key,current));current = []
            current.append(o)
        if current:chains.append((key,current))
    triples = 0
    triple_variants = 0
    unequal_triples = 0
    triple_max = (F(0),None)
    triple_failures = []
    repeated_shared_variants = []
    with (OUT/'ALL_THIRD_DIFFERENCES_v1.jsonl').open('w') as output:
        for chain_id,(key,rows) in enumerate(chains,1):
            for j in range(len(rows)-2):
                a,b,c = rows[j:j+3]
                if not a['T'] == b['T'] == c['T']:
                    unequal_triples += 1;continue
                triples += 1
                endpoint_sets = [a['starts'],a['ends'],b['ends'],c['ends']]
                assert [x['record'] for x in a['ends']] == [x['record'] for x in b['starts']]
                assert [x['record'] for x in b['ends']] == [x['record'] for x in c['starts']]
                comparisons = []
                for p0,p1,p2,p3 in product(*endpoint_sets):
                    triple_variants += 1
                    phase3 = -p0['phase']+3*p1['phase']-3*p2['phase']+p3['phase']
                    odf3 = cycle_increment(a,p0)-2*cycle_increment(b,p1)+cycle_increment(c,p2)
                    residue = quotient_residue(phase3-odf3,1)
                    scale = storage_scale(a)+2*storage_scale(b)+storage_scale(c)
                    if abs(residue)>triple_max[0]:triple_max=(abs(residue),[a['record'],b['record'],c['record']])
                    if abs(residue)>scale:triple_failures.append([a['record'],b['record'],c['record'],str(residue),str(scale)])
                    comparisons.append({'ATDF_records':[p0['record'],p1['record'],p2['record'],p3['record']],
                                        'third_phase_difference_cycles':phase3,'ODF_cycle_difference':odf3,
                                        'mod_one_cycle':residue,'storage_scale_cycles':scale})
                if len(comparisons)>1:repeated_shared_variants.append([a['record'],b['record'],c['record'],len(comparisons)])
                emit(output,{'chain':chain_id,'ODF_records':[a['record'],b['record'],c['record']],
                             'T':a['T'],'comparisons':comparisons})
    endpoint_good_slip = [atdf[i] for i in sorted(matched_records) if nominally_good(atdf[i]) and slipped(atdf[i])]
    logical_good_slip = set(x['key'] for x in endpoint_good_slip)
    stats = {
        'scope':'Exposed dependent-format quotient comparison, not calibration or an independent gravity test',
        'implementation':'Raw indexed binary-character slices; exact Fraction arithmetic; no imported author code or forward-history lift',
        'raw_ATDF_tracking_rows':len(atdf),'raw_ODF_orbit_rows':sum(types.values()),
        'ODF_types':dict(types),'Doppler_intervals':len(odf),'unmatched_intervals':unmatched,
        'endpoint_variant_multiplicities':[[list(k),v] for k,v in sorted(variants.items())],
        'matched_variant_pairs':variant_count,'duplicate_ODF_rows':duplicate_rows,
        'endpoint_reference_changes':ref_change,
        'distinct_matched_ATDF_records':len(matched_records),
        'distinct_matched_logical_endpoint_keys':len(set(atdf[i]['key'] for i in matched_records)),
        'quality_intervals_all_19_24_zero_any_87_positive':len(interval_good_slip),
        'quality_intervals_any_endpoint_19_24_zero_87_positive':len(interval_any_good_slip),
        'quality_unique_ATDF_records_19_24_zero_87_positive':len(endpoint_good_slip),
        'quality_unique_logical_keys_19_24_zero_87_positive':len(logical_good_slip),
        'quality_endpoint_uses_19_24_zero_87_positive':sum(endpoint_uses[a['record']] for a in endpoint_good_slip),
        'max_distance_mod_2pow32_cycles':encoded(maxM),'max_distance_mod_one_cycles':encoded(max1),
        'max_coherent_distance_mod_2pow32_cycles':encoded(maxM_coherent),
        'interval_storage_comparison_failures':failures,
        'chain_static_items':CHAIN_ITEMS,'static_strata':len(strata),'chains':len(chains),
        'chain_boundaries':dict(boundaries),'adjacent_pairs':sum(max(0,len(x)-1) for _,x in chains),
        'equal_duration_consecutive_triples':triples,'unequal_duration_triples':unequal_triples,
        'third_difference_variant_comparisons':triple_variants,
        'third_difference_duplicate_variants':repeated_shared_variants,
        'max_third_difference_distance_mod_one_cycles':encoded(triple_max),
        'third_difference_storage_comparison_failures':triple_failures,
        'ATDF_groups_sample_mode_rate_quality_lock':[[list(k),v] for k,v in sorted(inventory.items())],
        'matched_pair_quality_groups_19_24_87':[[list(k),v] for k,v in sorted(match_quality.items())],
        'elapsed_seconds':time.monotonic()-begin,
    }
    dump(OUT/'QUALITY_DIAGNOSTICS_v1.json',encoded({
        'interval_all_good_any_slip':interval_good_slip,
        'interval_any_good_slip':interval_any_good_slip,
        'unique_raw_endpoint_records':[x['record'] for x in endpoint_good_slip],
        'unique_logical_endpoint_keys':sorted(logical_good_slip),
        'diagnostic_only':'Item87 is not an inferred error certificate, and nominal quality does not prove physical phase accuracy.'}))
    dump(OUT/'CHAIN_INVENTORY_v1.json',encoded([{'id':i,'static_items':dict(zip(CHAIN_ITEMS,key)),
        'records':[x['record'] for x in rows],'first':rows[0]['start'],'last':rows[-1]['end'],
        'durations':sorted(set(x['T'] for x in rows))} for i,(key,rows) in enumerate(chains,1)]))
    dump(OUT/'RESULTS_v1.json',stats)
    ledger_names = ['ATDF_EXTRACTED_FIELDS_v1.jsonl','ODF_EXTRACTED_FIELDS_v1.jsonl',
                    'ALL_INTERVAL_COMPARISONS_v1.jsonl','ALL_THIRD_DIFFERENCES_v1.jsonl',
                    'QUALITY_DIAGNOSTICS_v1.json','CHAIN_INVENTORY_v1.json','RESULTS_v1.json']
    dump(OUT/'EXECUTION_IDENTITY_v1.json',{
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'code_sha256':sha(Path(__file__)),
        'precheck_sha256':sha(OUT/'PRECHECK_v1.md'),
        'input_identity_sha256':sha(OUT/'INPUT_IDENTITY_v1.json'),
        'products':[{'path':name,'sha256':sha(OUT/name),'bytes':(OUT/name).stat().st_size} for name in ledger_names],
        'observed_errors':{'unmatched':len(unmatched),'interval_failures':len(failures),'triple_failures':len(triple_failures)},
    })
    print(json.dumps({k:v for k,v in stats.items() if k not in ['ATDF_groups_sample_mode_rate_quality_lock','matched_pair_quality_groups_19_24_87']},indent=2))
    assert not unmatched and not failures and not triple_failures

if __name__ == '__main__':
    run()
