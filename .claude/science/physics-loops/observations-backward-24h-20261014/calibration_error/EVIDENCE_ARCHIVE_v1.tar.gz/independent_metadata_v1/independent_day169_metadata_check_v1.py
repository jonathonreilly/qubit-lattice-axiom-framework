#!/usr/local/bin/python3
"""Decode only selected status/identity metadata in the registered day-169 ATDF."""
from pathlib import Path
import hashlib,json,re
from collections import Counter,defaultdict
HERE=Path(__file__).resolve().parent
WT=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
INPUT=WT/'outputs/cassini_doppler_inputs'
LABEL=INPUT/'tdf_c32easc2002_169_0000xmmmv0.lbl'
RAW=INPUT/'c32easc2002_169_0000xmmmv0.tdf'
text=LABEL.read_text();lines=text.splitlines()
root={'kind':'ROOT','attrs':{},'children':[]};stack=[root]
for number,line in enumerate(lines,1):
 m=re.match(r'\s*(\^?\w+)\s*=\s*(.*)',line)
 if not m:continue
 key,value=m.groups();value=value.strip()
 if key=='OBJECT':
  node={'kind':value,'attrs':{},'children':[],'line':number};stack[-1]['children'].append(node);stack.append(node)
 elif key=='END_OBJECT':
  assert stack[-1]['kind']==value;(stack.pop())['end_line']=number
 else:stack[-1]['attrs'][key]=value.strip('"')
assert len(stack)==1
table=next(x for x in root['children'] if x['kind']=='TDF5_TABLE')
fields={}
for col in table['children']:
 a=col['attrs'];base=(int(a['START_BYTE'])-1)*8
 candidates=col['children'] or [col]
 for node in candidates:
  b=node['attrs'];m=re.search(r'Item (\d+):',b.get('DESCRIPTION',''))
  if not m:continue
  item=int(m.group(1));isbit=node['kind']=='BIT_COLUMN'
  offset=base+int(b['START_BIT'])-1 if isbit else base
  width=int(b['BITS']) if isbit else 8*int(b['BYTES'])
  fields[item]={'name':b['NAME'],'bit_offset_zero_based':offset,'width':width,'storage_type':b.get('BIT_DATA_TYPE',b.get('DATA_TYPE')),'label_start_line':node['line'],'label_end_line':node['end_line'],'column_start_byte_one_based':int(a['START_BYTE'])}
selected=[1,3,4,5,6,7,8,10,11,12,13,14,15,19,24,26,28,29,87,127,137]
assert all(i in fields for i in selected)
raw=RAW.read_bytes();record_bytes=int(root['attrs']['RECORD_BYTES']);record_bits=8*record_bytes
file_records=int(root['attrs']['FILE_RECORDS']);assert len(raw)==record_bytes*file_records
pointer=re.search(r'\^TDF5_TABLE\s*=\s*\("[^"]+",(\d+)\)',text)
start=int(pointer.group(1))-1;rows=int(table['attrs']['ROWS'])
assert record_bytes==int(table['attrs']['ROW_BYTES'])==288
assert start==2 and rows==160870

def decode(record,item):
 f=fields[item];v=int.from_bytes(record,'big')>>(record_bits-f['bit_offset_zero_based']-f['width'])&((1<<f['width'])-1)
 if f['storage_type']=='MSB_INTEGER' and v>>(f['width']-1):v-=1<<f['width']
 return v

def bitstring_decode(record,item):
 f=fields[item];bits=''.join(format(b,'08b') for b in record);v=int(bits[f['bit_offset_zero_based']:f['bit_offset_zero_based']+f['width']],2)
 if f['storage_type']=='MSB_INTEGER' and v>>(f['width']-1):v-=1<<f['width']
 return v

def summary(values):
 return {str(k):v for k,v in sorted(Counter(values).items())}
metadata=[]
for idx in range(start,start+rows):
 r=raw[idx*record_bytes:(idx+1)*record_bytes];metadata.append({i:decode(r,i) for i in selected})
spot=[0,1,2,13,1000,rows//2,rows-2,rows-1]
for local in spot:
 r=raw[(start+local)*record_bytes:(start+local+1)*record_bytes]
 for i in selected:assert bitstring_decode(r,i)==metadata[local][i]
assert {x[1] for x in metadata}=={8}
assert all(x[4]==102 and x[15]==82 for x in metadata)
bytype={}
for dtype in sorted({x[12] for x in metadata}):
 subset=[x for x in metadata if x[12]==dtype]
 bytype[str(dtype)]={'rows':len(subset),'record_types':summary(x[3] for x in subset),'days':summary(x[5] for x in subset),'stations':summary(x[10] for x in subset),'receiver_types':summary(x[26] for x in subset),'ground_modes':summary(x[14] for x in subset),'sample_interval_raw_0_01_second':summary(x[29] for x in subset),'item19':summary(x[19] for x in subset),'item24':summary(x[24] for x in subset),'item87':summary(x[87] for x in subset),'status_triples':{','.join(map(str,k)):v for k,v in sorted(Counter((x[19],x[24],x[87]) for x in subset).items())}}
doppler=[x for x in metadata if x[12] in [1,2]]
nonzero=[(i,x) for i,x in enumerate(metadata) if x[12] in [1,2] and x[87]!=0]
result={'scope':'Only registered day169 ATDF metadata decoded; no Doppler values, other samples or ODF record matching. File extends into DOY170; day splits are explicit.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputs':[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in [LABEL,RAW]],'record_bytes':record_bytes,'file_records':file_records,'tracking_start_record_one_based':start+1,'tracking_rows':rows,'field_map':{str(i):fields[i] for i in selected},'bitstring_cross_checks':len(spot)*len(selected),'record_format_histogram':summary(x[1] for x in metadata),'by_sample_type':bytype,'doppler_total':len(doppler),'doppler_by_day':{str(day):{'rows':len(ss),'item19':summary(x[19] for x in ss),'item24':summary(x[24] for x in ss),'item87':summary(x[87] for x in ss),'nonzero_slips':sum(x[87]!=0 for x in ss),'good_lock_with_nonzero_slips':sum(x[19]==0 and x[24]==0 and x[87]!=0 for x in ss)} for day in sorted({x[5] for x in doppler}) for ss in [[x for x in doppler if x[5]==day]]},'nonzero_doppler_slip_examples':[{'file_record_one_based':i+start+1,'year':x[4]+1900,'doy':x[5],'hour':x[6],'minute':x[7],'second':x[8],'station':x[10],'sample_type':x[12],'item19':x[19],'item24':x[24],'item87':x[87]} for i,x in nonzero[:12]],'cautions':['Item87 is unsigned metadata, not established signed correction.','Zero-valued nonapplicable fields must not be interpreted as actual quality/lock evidence.','No physical error bound follows from this metadata inventory.']}
with (HERE/'DAY169_METADATA_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'source_sha256':result['source_sha256'],'tracking_rows':rows,'sample_types':{k:v['rows'] for k,v in bytype.items()},'doppler_by_day':result['doppler_by_day'],'nonzero_examples':result['nonzero_doppler_slip_examples']},indent=2))
