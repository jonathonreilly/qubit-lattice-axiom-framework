#!/usr/local/bin/python3
"""Affected exact-input/scalar-energy closure only; no aggregate or raw-data run."""
from pathlib import Path
from fractions import Fraction as F
from math import floor,sqrt
import ast,importlib.util,hashlib,json,datetime
import sympy as s
OUT=Path(__file__).resolve().parent
source=OUT/'CANONICAL_scalar_phase_quotient_controls.py'
spec=importlib.util.spec_from_file_location('canonical_quotient_math',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def check(name,condition,**data):checks.append({'name':name,'passed':bool(condition),**data})
def raises(name,cls,fn):
    try:fn()
    except cls:check(name,True)
    else:check(name,False)
def funcs(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
old=funcs(OUT/'AUTHOR_integer_history_controls_v1.py');new=funcs(source)
for name in ('centered','lattice_minimum_2d'):
    check('unchanged_function_'+name,ast.dump(old[name],include_attributes=False)==ast.dump(new[name],include_attributes=False))
check('unchanged_rational_period_arithmetic_after_guards',ast.dump(ast.Module(body=old['projected_period'].body[-3:],type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=new['projected_period'].body[-3:],type_ignores=[]),include_attributes=False))
for name,weights,period in [('float_sqrt',[sqrt(2),1],1),('integer_valued_float',[1.0,2],1),('float_period',[1,2],1.0),('sympy_float',[s.Float('0.5'),1],1),('exact_irrational',[s.sqrt(2),1],1),('irrational_period',[1,2],s.sqrt(2))]:
    raises(name+'_rejected',TypeError,lambda w=weights,p=period:m.projected_period(w,p))
for name,weights,period,expected in [('half',[F(1,2),1],1,F(1,2)),('nonprimitive',[2,-4,2],7,F(14)),('sympy_rational',[s.Rational(1,3),s.Rational(5,6)],s.Rational(3,2),F(1,4)),('zero_row',[0,0],1,F(0)),('mixed_sign',[F(-5,12),F(7,18)],6,F(1,6)),('singleton',[s.Rational(5,7)],s.Rational(2,3),F(10,21))]:
    check('exact_period_'+name,m.projected_period(weights,period)==expected)
raises('empty_weights_rejected',ValueError,lambda:m.projected_period([],1))
raises('zero_period_rejected',ValueError,lambda:m.projected_period([1],0))
raises('negative_period_rejected',ValueError,lambda:m.projected_period([1],-1))
fixtures=[(F(3,20),F(1),F(1,20),F(1)),(F(1,20),F(1),F(1,10),F(1)),(F(7,6),F(9,4),F(0),F(1)),(F(-13,4),F(4),F(1,4),F(2)),(F(9,14),F(25,9),F(1,14),F(3,7)),(F(3,2),F(1),F(0),F(1)),(F(3,4),F(1),F(1,4),F(1)),(F(0),F(7),F(0),F(1))]
for i,(value,sigma2,error,period) in enumerate(fixtures):
    center=floor(value/period)
    distance=min(abs(value-period*k) for k in range(center-2,center+4))
    expected=max(F(0),distance-error)**2/sigma2
    check('scalar_floor_exact_'+str(i),m.scalar_energy_floor(value,sigma2,error,period)==expected,expected=str(expected))
for a in (F(2,3),F(-7,2)):
    value,sigma2,error,period=fixtures[3]
    check('scalar_rescaled_observable_'+str(a),m.scalar_energy_floor(a*value,a*a*sigma2,abs(a)*error,abs(a)*period)==m.scalar_energy_floor(value,sigma2,error,period))
check('zero_response_boundary_compatible',m.scalar_energy_floor(F(1,4),0,F(1,4),1)==0)
check('zero_response_larger_error_compatible',m.scalar_energy_floor(F(1,4),0,F(1,3),1)==0)
raises('zero_response_incompatible',ValueError,lambda:m.scalar_energy_floor(F(1,4),0,F(1,5),1))
raises('negative_squared_norm_rejected',ValueError,lambda:m.scalar_energy_floor(0,-1,0,1))
raises('negative_error_rejected',ValueError,lambda:m.scalar_energy_floor(0,1,-1,1))
raises('scalar_zero_period_rejected',ValueError,lambda:m.scalar_energy_floor(0,1,0,0))
res={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'Post-exposure changed canonical closure; not aggregate rerun or empirical test','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'canonical_helper_snapshot_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checks':checks,'counts':{'total':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'author_aggregate_rerun':False,'actual_observations_accessed':False}
with (OUT/'CANONICAL_CHANGED_RESULTS_v1.json').open('x') as f:json.dump(res,f,indent=2);f.write('\n')
print(json.dumps(res['counts']))
if not all(x['passed'] for x in checks):raise SystemExit(1)
