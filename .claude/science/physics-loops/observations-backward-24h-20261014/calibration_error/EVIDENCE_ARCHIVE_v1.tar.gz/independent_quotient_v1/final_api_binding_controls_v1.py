#!/usr/local/bin/python3
"""Narrow final signature/identity binding; no scientific aggregate run."""
from pathlib import Path
from fractions import Fraction as F
import ast,copy,importlib.util,json,hashlib,datetime,inspect
OUT=Path(__file__).resolve().parent
oldsource=OUT/'CANONICAL_scalar_phase_quotient_controls.py'
finalsource=OUT/'FINAL_scalar_phase_quotient_controls.py'
old={n.name:n for n in ast.parse(oldsource.read_text()).body if isinstance(n,ast.FunctionDef)}
new={n.name:n for n in ast.parse(finalsource.read_text()).body if isinstance(n,ast.FunctionDef)}
checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
for name in ('centered','projected_period','lattice_minimum_2d'):
    check('unchanged_final_function_'+name,ast.dump(old[name],include_attributes=False)==ast.dump(new[name],include_attributes=False))
check('scalar_formula_body_unchanged',ast.dump(ast.Module(body=old['scalar_energy_floor'].body,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=new['scalar_energy_floor'].body,type_ignores=[]),include_attributes=False))
spec=importlib.util.spec_from_file_location('final_quotient_math',finalsource)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
params=inspect.signature(m.scalar_energy_floor).parameters
check('error_bound_has_no_default',params['error_bound'].default is inspect.Parameter.empty)
try:m.scalar_energy_floor(F(1,6),F(9,4))
except TypeError:check('omitted_error_rejected',True)
else:check('omitted_error_rejected',False)
check('explicit_zero_nonunit_riesz',m.scalar_energy_floor(F(1,6)+7,F(9,4),F(0))==F(1,81))
run=copy.deepcopy(old['run']);changes=0
for node in ast.walk(run):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='scalar_energy_floor' and len(node.args)==2:
        node.args.append(ast.Call(func=ast.Name(id='F',ctx=ast.Load()),args=[ast.Constant(value=0)],keywords=[]));changes+=1
check('runner_only_adds_explicit_error_zero',changes==1 and ast.dump(run,include_attributes=False)==ast.dump(new['run'],include_attributes=False))
check('declared_timeout_180',m.AUDIT_TIMEOUT_SEC==180)
oldnote=(OUT/'CANONICAL_SCALAR_PHASE_QUOTIENT_INTEGER_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-15.md').read_text()
finalnote=(OUT/'FINAL_SCALAR_PHASE_QUOTIENT_INTEGER_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-15.md').read_text()
addition='Review also identified a zero-error default in the mathematical helper.\nThe canonical scalar bound requires an explicit error argument; the\nerror-free sharpness fixture passes zero as its declared synthetic premise.\nNo physical application inherits a default zero-error budget.\n\n'
check('final_note_only_adds_error_disposition',finalnote.count(addition)==1 and finalnote.replace(addition,'')==oldnote)
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Narrow final source/API binding after changed-closure controls; no aggregate rerun','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'final_helper_sha256':hashlib.sha256(finalsource.read_bytes()).hexdigest(),'final_note_sha256':hashlib.sha256(finalnote.encode()).hexdigest(),'checks':checks,'counts':{'total':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}}
with (OUT/'FINAL_API_BINDING_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result['counts']))
if not all(c['passed'] for c in checks):raise SystemExit(1)
