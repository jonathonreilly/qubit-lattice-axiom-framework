#!/usr/local/bin/python3
"""Independent quotient/history controls; no author or observation file imports."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import gcd, floor, ceil
import datetime, hashlib, json, random, sys, traceback
import sympy as sp
import mpmath as mp

OUT=Path(__file__).resolve().parent
M=2**32
RNG=random.Random(104729)
CHECKS=[]
DETAILS={}

def serial(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [serial(v) for v in x]
    return x

def check(name,ok,**details):
    CHECKS.append({'name':name,'passed':bool(ok),**serial(details)})

def wrap(x,p=F(1)):
    return x-p*floor(x/p)

def circdist(x,p=F(1)):
    a=wrap(x,p)
    return min(a,p-a)

def dot(a,b): return sum((x*y for x,y in zip(a,b)),F(0))

def matvec(A,x): return [dot(row,x) for row in A]

def quad(H,x): return dot(x,matvec(H,x))

def clamp(x,a,b): return max(a,min(b,x))

# Exact two-dimensional quadratic minimization on a box: zero or an edge optimum.
def box_min(H,lo,hi):
    candidates=[]
    if all(a<=0<=b for a,b in zip(lo,hi)):candidates.append((F(0),F(0)))
    for x in (lo[0],hi[0]):
        candidates.append((x,clamp(-H[1][0]*x/H[1][1],lo[1],hi[1])))
    for y in (lo[1],hi[1]):
        candidates.append((clamp(-H[0][1]*y/H[0][0],lo[0],hi[0]),y))
    scored=[(quad(H,r),r) for r in candidates]
    return min(scored,key=lambda t:t[0])

G=((F(2),F(1)),(F(1),F(2)))
GI=((F(2,3),F(-1,3)),(F(-1,3),F(2,3)))
A=((F(1),F(1),F(0)),(F(0),F(1),F(1)))
AT=tuple(zip(*A))

def lattice_min(y,eta,G=G,H=GI):
    # Gershgorin bounds lambda_max(G) by the maximum absolute row sum.
    lmax=max(sum(abs(x) for x in row) for row in G)
    z0=tuple(floor(v+F(1,2)) for v in y)
    r0=tuple(v-z for v,z in zip(y,z0))
    incumbent=quad(H,r0)  # zero error is admissible for this synthetic box.
    radius=0
    while F(radius*radius)<lmax*incumbent:radius+=1
    limits=[(ceil(v-e-radius),floor(v+e+radius)) for v,e in zip(y,eta)]
    rows=[]
    for z in product(*(range(a,b+1) for a,b in limits)):
        lo=tuple(v-k-e for v,k,e in zip(y,z,eta))
        hi=tuple(v-k+e for v,k,e in zip(y,z,eta))
        value,r=box_min(H,lo,hi)
        error=tuple(v-k-t for v,k,t in zip(y,z,r))
        rows.append((value,z,r,error))
    best=min(rows,key=lambda r:r[0])
    return {'value':best[0],'z':best[1],'r':best[2],'error':best[3],
            'incumbent':incumbent,'radius':radius,'lambda_upper':lmax,
            'enumerated_lifts':len(rows),'limits':limits}

def execute():
    B=sp.Matrix([[1,0],[1,0],[1,0],[0,1],[0,1]])
    K=sp.Matrix([[-1,1,0,0,0],[-1,0,1,0,0],[0,0,0,-1,1]])
    L=sp.Matrix([[0,0,0],[1,0,0],[0,1,0],[0,0,0],[0,0,1]])
    check('exact_segment_quotient_rank_kernel_integer_surjectivity',K*B==sp.zeros(3,2) and K.rank()==3 and K*L==sp.eye(3))
    kr=[[F(int(v)) for v in row] for row in K.tolist()]
    segments=(0,0,0,1,1); anchors=(0,3)
    for i in range(24):
        q=[F(RNG.randint(-500,500),RNG.choice([3,5,7,11,13,16])) for _ in range(5)]
        b=[F(RNG.randint(-30,30),7) for _ in range(2)]
        n=[RNG.randint(-3*M,3*M) for _ in range(5)]
        qp=[wrap(v+b[s]+k,F(M)) for v,s,k in zip(q,segments,n)]
        y=matvec(kr,q); yp=matvec(kr,qp)
        check('exact_native_wrap_offset_integer_invariance_%02d'%i,
              all(wrap(a)==wrap(c) for a,c in zip(y,yp)))
        difference=[x-v for x,v in zip(qp,q)]
        recovered_b=[difference[a] for a in anchors]
        recovered_n=[v-recovered_b[s] for v,s in zip(difference,segments)]
        check('exact_quotient_normal_form_reconstruction_%02d'%i,
              all(v.denominator==1 for v in recovered_n) and
              all(qp[j]-q[j]==recovered_b[segments[j]]+recovered_n[j] for j in range(5)))
    # A period-one failure despite segment offset cancellation and native wrap validity.
    w=(F(-1,2),F(1,2)); q=(F(0),F(1,4)); qp=(F(0),F(5,4))
    x=dot(w,q); xp=dot(w,qp)
    check('noninteger_unit_period_witness',sum(w)==0 and wrap(x)!=wrap(xp)
          and all((v*M).denominator==1 for v in w),original=x,shifted=xp)
    check('noninteger_correct_rescaled_period',wrap(x,F(1,2))==wrap(xp,F(1,2)))
    # Incorrect retention of Z after rescaling creates a false energy bound.
    y=F(3,4); T=F(1,2); gram=T*T
    correct=circdist(T*y,T)**2/gram
    wrong=circdist(T*y)**2/gram
    compatible_h=F(-1,4)
    check('rescaled_lattice_false_lower_bound',correct==compatible_h**2==F(1,16) and wrong==F(9,16),correct=correct,wrong=wrong,compatible_h=compatible_h)
    check('nonprimitive_natural_period',circdist(F(3,4),F(2))==F(3,4) and circdist(F(3,4))==F(1,4))
    # Arbitrarily small nonzero shifts in Z+sqrt(2)Z, with exact Pell identity.
    mp.mp.dps=70; p,qv=1,1; pell=[]
    for _ in range(16):
        assert abs(p*p-2*qv*qv)==1
        increment=abs(mp.mpf(p)-mp.sqrt(2)*qv)
        exact_size=1/(mp.mpf(p)+mp.sqrt(2)*qv)
        assert abs(increment-exact_size)<mp.mpf('1e-60')
        pell.append({'p':p,'q':qv,'nonzero_increment':mp.nstr(increment,30)})
        p,qv=p+2*qv,p+qv
    check('irrational_image_has_arbitrarily_small_pell_increments',mp.mpf(pell[-1]['nonzero_increment'])<mp.mpf('1e-5'),last=pell[-1])
    DETAILS['pell_witnesses']=pell
    C=sp.Matrix([1,sp.sqrt(2)]); null=sp.Matrix([sp.sqrt(2),-1])
    check('real_nuisance_nullspace_not_integer_character',sp.simplify((C.T*null)[0])==0 and sp.sqrt(2).is_irrational is True)
    # Independent real resets span every sample and reconstruct any phase vector.
    resets=sp.Matrix([[int(j>=k) for k in range(5)] for j in range(5)])
    qreset=sp.Matrix([sp.Rational(1,7),sp.Rational(-3,5),sp.Rational(4,11),sp.Rational(2,3),sp.Rational(9,2)])
    breset=sp.Matrix([qreset[0]]+[qreset[i]-qreset[i-1] for i in range(1,5)])
    check('arbitrary_real_reset_degeneracy',resets.det()==1 and resets*breset==qreset)
    integer_data=[F(2**31),F(9),F(-123),F(M-1),F(77)]
    check('integer_only_cycles_zero_quotient_zero_field',all(wrap(v)==0 for v in matvec(kr,integer_data)))
    # Adjacent duration-normalized count contrasts: induced phase weights matter.
    durations=(F(2),F(3)); DT=((F(-1,2),F(1,2),F(0)),(F(0),F(-1,3),F(1,3)))
    phase_bad=[sum(DT[i][j] for i in range(2)) for j in range(3)]
    phase_good=[sum(durations[i]*DT[i][j] for i in range(2)) for j in range(3)]
    check('duration_weights_unit_circle_condition',phase_bad==[F(-1,2),F(1,6),F(1,3)] and phase_good==[-1,0,1])
    # Exact raw-offset minimization agrees with the contrast Gram, without floating tolerances.
    for i in range(5):
        R=sp.Matrix(5,5,lambda j,k:RNG.randint(-3,3))
        Fm=R.T*R+sp.eye(5); inv=Fm.inv()
        projected=inv-inv*B*(B.T*inv*B).inv()*B.T*inv
        contrast=K.T*(K*Fm*K.T).inv()*K
        check('exact_spd_offset_elimination_%02d'%i,projected==contrast)
    # Joint Gram metric: componentwise principal wraps need not minimize energy.
    target=(F(49,100),F(-49,100)); eta=(F(0),F(0))
    nearest=lattice_min(target,eta)
    naive=quad(GI,target)
    h=matvec(AT,matvec(GI,nearest['r']))
    check('componentwise_wrap_false_joint_energy_bound',nearest['value']<naive and matvec(A,h)==list(nearest['r']) and dot(h,h)==nearest['value'],correct=nearest['value'],naive=naive,compatible_lift=nearest['z'],compatible_h=h)
    DETAILS['correlated_gram_failure_witness']={**nearest,'naive_componentwise_value':naive,'compatible_h':h}
    fixtures=[((F(23,100),F(41,100)),(F(1,20),F(1,40))),
              ((F(49,100),F(-49,100)),(F(1,25),F(3,100))),
              ((F(3,4),F(2,5)),(F(0),F(0))),
              ((F(1,20),F(-1,25)),(F(1,10),F(1,10))),
              ((F(-11,8),F(7,6)),(F(1,50),F(1,30)))]
    rows=[]
    for i,(target,eta) in enumerate(fixtures):
        result=lattice_min(target,eta)
        h=matvec(AT,matvec(GI,result['r']))
        # Check a larger independently fixed lift box, so an enumeration-region error is exposed.
        candidates=[]
        for z in product(range(-8,9),repeat=2):
            lo=tuple(v-k-e for v,k,e in zip(target,z,eta)); hi=tuple(v-k+e for v,k,e in zip(target,z,eta))
            candidates.append(box_min(GI,lo,hi)[0])
        check('exact_lattice_box_minimum_%02d'%i,result['value']==min(candidates)
              and matvec(A,h)==list(result['r']) and dot(h,h)==result['value']
              and all(abs(e)<=s for e,s in zip(result['error'],eta)),value=result['value'],finite_region=result['limits'],lift_count=result['enumerated_lifts'])
        for shift in ((7,-4),(-3,9)):
            shifted=lattice_min(tuple(v+k for v,k in zip(target,shift)),eta)
            check('integer_lift_invariance_%02d_%s'%(i,shift),shifted['value']==result['value'])
        rows.append({'target':target,'synthetic_error_halfwidths':eta,**result})
    DETAILS['exact_spd_box_fixtures']=rows
    # Unimodular full-coordinate change preserves the quadratic and exact integer lattice.
    U=sp.Matrix([[1,2],[0,1]]); Gs=sp.Matrix(G); Gnew=U*Gs*U.T
    for i in range(6):
        rr=sp.Matrix([sp.Rational(RNG.randint(-20,20),7),sp.Rational(RNG.randint(-20,20),11)])
        z=sp.Matrix([RNG.randint(-9,9),RNG.randint(-9,9)])
        check('unimodular_coordinate_metric_%02d'%i,U.det()==1 and (rr.T*Gs.inv()*rr)[0]==((U*rr).T*Gnew.inv()*(U*rr))[0]
              and all(v.is_integer for v in U*z))
    # Compatible synthetic fields and bounded errors test scalar torus bounds, including nonprimitive rows.
    testells=[(1,0),(0,1),(1,1),(1,-1),(2,4),(-3,6)]
    sigma=(F(1,100),F(1,40),F(1,50))
    for i in range(24):
        field=tuple(F(RNG.randint(-30,30),13) for _ in range(3))
        response=matvec(A,field)
        errors=tuple(s*F(RNG.randint(-10,10),10) for s in sigma)
        projected_errors=(errors[1]-errors[0],errors[2]-errors[0])
        observed=[wrap(a+b) for a,b in zip(response,projected_errors)]
        success=True; maximum=F(0)
        for ell in testells:
            P=F(gcd(*map(abs,ell)))
            phaseweights=(-sum(ell),ell[0],ell[1])
            budget=sum(abs(w)*s for w,s in zip(phaseweights,sigma))
            delta=circdist(dot(ell,observed),P)
            g=quad(G,ell)
            lower=max(F(0),delta-budget)**2/g
            success=success and lower<=dot(field,field)
            maximum=max(maximum,lower)
        check('scalar_bound_on_compatible_field_%02d'%i,success,field_norm=dot(field,field),strongest_of_six=maximum)
    # Scalar sharpness is mathematical only, not a field-selection rule.
    for delta,budget,norm2 in [(F(1,4),F(1,20),F(2)),(F(2,5),F(1,10),F(7)),(F(1,20),F(1,10),F(3))]:
        residual=max(F(0),delta-budget)
        minimum=residual*residual/norm2
        check('scalar_riesz_sharpness_'+str(delta),minimum*norm2==residual**2 and residual+min(delta,budget)==delta)
    delta=F(1,4)
    check('zero_response_requires_feasibility',delta>F(1,10) and delta<=F(3,10))
    incompatible=(F(1,4),F(1,10)); compatible=(F(1,4),F(0))
    check('psd_pseudoinverse_range_guard',wrap(incompatible[1])!=0 and wrap(compatible[1])==0
          and incompatible[0]**2==F(1,16),incompatible_y=incompatible,naive_pseudoinverse_value=F(1,16))
    DETAILS['scope']={'physical_error_budget_selected':False,'actual_observations_read':False,'author_sources_read':False,'mathematical_fixture_error_sets_only':True}

exception=None
try:
    execute()
except Exception:
    exception=traceback.format_exc()
    CHECKS.append({'name':'unexpected_execution_exception','passed':False,'traceback':exception})
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'classification':'Independent pre-author-source synthetic mathematical controls; not empirical calibration or validation',
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'precheck_sha256':hashlib.sha256((OUT/'PRECHECK_v1.md').read_bytes()).hexdigest(),
        'python':sys.version,'sympy':sp.__version__,'mpmath':mp.__version__,
        'checks':CHECKS,'counts':{'total':len(CHECKS),'passed':sum(c['passed'] for c in CHECKS),'failed':sum(not c['passed'] for c in CHECKS)},
        'details':serial(DETAILS),'author_sources_read':False}
with (OUT/'INDEPENDENT_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result['counts']))
if exception:print(exception,file=sys.stderr)
if not all(c['passed'] for c in CHECKS):raise SystemExit(1)
