#!/usr/local/bin/python3
"""Post-exposure scoped helper correspondence, not blind independent science."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import ceil,floor,sqrt
import importlib.util,json,hashlib,datetime
import sympy as s
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_author_quotient',OUT/'AUTHOR_integer_history_controls_v1.py')
author=importlib.util.module_from_spec(spec);spec.loader.exec_module(author)
checks=[]
def check(name,ok,**details):
    checks.append({'name':name,'passed':bool(ok),**details})

def frac(x):return F(int(s.numer(x)),int(s.denom(x)))
def qcost(r,k,period,inv):
    x=[r[i]+period*k[i] for i in range(2)]
    return inv[0][0]*x[0]**2+2*inv[0][1]*x[0]*x[1]+inv[1][1]*x[1]**2

def reference_minimum(r,G,period):
    # Separate exact incumbent and Gershgorin region, unlike author's origin/trace region.
    det=G[0][0]*G[1][1]-G[0][1]*G[1][0]
    inv=((G[1][1]/det,-G[0][1]/det),(-G[1][0]/det,G[0][0]/det))
    k0=[-floor(x/period+F(1,2)) for x in r]
    upper=qcost(r,k0,period,inv)
    lambda_upper=max(sum(abs(x) for x in row) for row in G)
    radius=0
    while F(radius*radius)<upper*lambda_upper:radius+=1
    limits=[range(ceil((-radius-x)/period),floor((radius-x)/period)+1) for x in r]
    candidates=[(qcost(r,k,period,inv),k) for k in product(*limits)]
    best=min(v for v,k in candidates)
    return best,{k for v,k in candidates if v==best},inv

matrices=[((F(2),F(1)),(F(1),F(3))),((F(1),F(0)),(F(0),F(2))),((F(5),F(-2)),(F(-2),F(2)))]
inputs=[((F(4,7),F(-3,8)),F(1)),((F(13,8),F(-11,7)),F(3,2)),((F(-5,9),F(7,10)),F(1,3))]
for j,G in enumerate(matrices):
    for i,(r,P) in enumerate(inputs):
        expected,lifts,inv=reference_minimum(r,G,P)
        got,kg,box=author.lattice_minimum_2d([s.Rational(x.numerator,x.denominator) for x in r],s.Matrix(G),s.Rational(P.numerator,P.denominator))
        check('exact_enumeration_correspondence_%d_%d'%(j,i),frac(got)==expected and {tuple(v) for v in kg}==lifts,
              exact_minimum=str(expected),author_examined=box['examined'])
        incumbent=qcost(r,(0,0),P,inv)
        exact_radius2=incumbent*(G[0][0]+G[1][1])
        R=box['radius'];target_box=[(ceil((-R-x)/P),floor((R-x)/P)) for x in r]
        first_outside=[(target_box[0][0]-1,0),(target_box[0][1]+1,0),(0,target_box[1][0]-1),(0,target_box[1][1]+1)]
        check('exact_complete_box_certificate_%d_%d'%(j,i),s.Rational(str(box['radius_squared']))==s.Rational(exact_radius2.numerator,exact_radius2.denominator)
              and R*R>=exact_radius2 and (R==0 or (R-1)**2<exact_radius2)
              and all(qcost(r,k,P,inv)>incumbent for k in first_outside),radius=R)
# Current helper documentation says exact rational input; demonstrate its actual accepted domain.
floating_period=author.projected_period([sqrt(2),1])
check('floating_approximation_silently_acquires_discrete_period',isinstance(floating_period,F) and floating_period>0,
      actual_return=str(floating_period),finding='Guard/domain mismatch: floating approximation is treated as exact rational; does not justify a period for the intended irrational coefficient.')
H=s.symbols('H',real=True);gamma=(-1,3,-3,1)
beta=[(1-H*(s.Rational(1,5)+i))*gamma[i] for i in range(4)]
check('curved_beta_full_offset_cancellation',s.simplify(sum(beta))==0)
check('curved_beta_generates_H_and_constant',s.expand(beta[0]+beta[3])==-3*H and s.expand(16*beta[0]+beta[3])==-15)
check('curved_beta_irrational_within_chart',s.sqrt(2)/100<s.Rational(5,22) and s.sqrt(2).is_irrational)
# The code strips only the overall pi factor from the displayed physical Gram.
Gtilde=s.Matrix([[3064,-1871],[-1871,3064]])/1620
r=s.Matrix([s.Rational(49,100)]*2);Gphysical=Gtilde/s.pi
check('physical_Gram_pi_bookkeeping',s.simplify((r.T*Gphysical.inv()*r)[0]-s.pi*(r.T*Gtilde.inv()*r)[0])==0)
# Geometric error-ellipsoid consequence in the note; this is not an actual error budget.
rr=s.Matrix([s.Rational(-2,5),s.Rational(2,7)]);norm=s.sqrt((rr.T*rr)[0]);eta=s.Rational(1,7)
e=eta*rr/norm
check('ellipsoid_error_shrinkage_geometry',s.simplify((e.T*e)[0]-eta**2)==0 and s.simplify(((rr-e).T*(rr-e))[0]-(norm-eta)**2)==0)
res={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'Post-author-exposure scoped correspondence and input-domain diagnostics; independent precheck remains separate',
     'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'author_script_sha256':hashlib.sha256((OUT/'AUTHOR_integer_history_controls_v1.py').read_bytes()).hexdigest(),
     'checks':checks,'counts':{'total':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},
     'author_aggregate_invoked_here':False,'actual_data_read':False}
with (OUT/'POSTSOURCE_RESULTS_v1.json').open('x') as f:json.dump(res,f,indent=2);f.write('\n')
print(json.dumps(res['counts']))
if not all(x['passed'] for x in checks):raise SystemExit(1)
