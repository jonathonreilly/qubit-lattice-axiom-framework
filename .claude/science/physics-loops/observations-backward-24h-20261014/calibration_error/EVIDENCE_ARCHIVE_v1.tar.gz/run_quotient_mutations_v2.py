#!/usr/bin/env python3
"""Deliberate source changes on private copies; no canonical mutation."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).parent/'mutation_results_v2'
OUT.mkdir(exist_ok=True)
MATH = ROOT/'scripts/scalar_phase_quotient_controls.py'
DATA = ROOT/'scripts/cassini_phase_quotient_development.py'
CASES = [
    ('history_modulus', 'math', 'return x-period*floor(x/period+F(1,2))', 'return x-2*period*floor(x/(2*period)+F(1,2))'),
    ('polynomial_contrast', 'math', 'gamma=[-1,3,-3,1]', 'gamma=[-1,2,-3,1]'),
    ('projected_gcd', 'math', 'return F(reduce(gcd,[abs(int(x*den)) for x in values]),int(den))', 'return F(1,int(den))'),
    ('nearest_component_history', 'math', 'best=min(vals)', 'best=(r.T*inv*r)[0]'),
    ('curved_projection', 'math', 'b3=1-s.Rational(16,5)*H', 'b3=1-s.Rational(15,5)*H'),
    ('physical_error_sign', 'math', 'max(distance-error_bound, F(0))', 'max(distance+error_bound, F(0))'),
    ('energy_norm_conversion', 'math', '**2/sigma_squared', '**2*sigma_squared'),
    ('rationality_guard', 'math', 'if any(not isinstance(x, (int, F, s.Rational)) for x in [*weights, period]):', 'if False:'),
    ('counter_high_part', 'data', 'd[30]*10**14', 'd[30]*10**12'),
    ('oneway_reference', 'data', 'F(880,221)*cs[1]-F(11,3)*oref', 'F(880,221)*cs[1]+F(11,3)*oref'),
    ('endpoint_metadata', 'data', 'stats[\'endpoint_occurrences_nonzero_item87\']+=sum(z[2][META.index(87)]!=0 for z in flat)', 'stats[\'endpoint_occurrences_nonzero_item87\']+=0'),
    ('third_difference', 'data', 'v=[1,-2,1];z=centered', 'v=[1,-1,1];z=centered'),
    ('one_cycle_observable', 'data', 'native_mod_one_cycles=str(centered(native))', 'native_mod_one_cycles=str(centered(native,2))'),
]


def execute(case):
    name,kind,old,new=case
    path=MATH if kind=='math' else DATA
    source=path.read_text()
    assert source.count(old)==1, (name,source.count(old))
    source=source.replace(old,new)
    folder=Path(tempfile.mkdtemp(prefix='phase-quotient-'+name+'-'))
    target=folder/'candidate.py';target.write_text(source)
    harness='''import importlib.util,sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1]+"/scripts")\nspec=importlib.util.spec_from_file_location("candidate",sys.argv[2])\nm=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\n'''
    if kind=='math':harness+='m.run()\n'
    else:
        harness+='''m.ROOT=Path(sys.argv[1])\nimport scalar_phase_quotient_check as primary\nprimary.development=m\nsys.argv=["check","--output-dir",sys.argv[3]]\nprimary.main()\n'''
    proc=subprocess.run(['/usr/local/bin/python3','-c',harness,str(ROOT),str(target),str(folder/'products')],text=True,capture_output=True,timeout=180)
    (OUT/(name+'.stdout')).write_text(proc.stdout)
    (OUT/(name+'.stderr')).write_text(proc.stderr)
    rejected=proc.returncode!=0 and 'AssertionError' in proc.stderr and 'SyntaxError' not in proc.stderr
    return {'name':name,'kind':kind,'canonical_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mutation_source_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'mutation_path':str(target),'returncode':proc.returncode,'assertion_rejected':rejected,'stderr_sha256':hashlib.sha256(proc.stderr.encode()).hexdigest(),'stderr_tail':proc.stderr.splitlines()[-3:]}


if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(execute,CASES))
    result={'cases':results,'assertion_rejected':sum(x['assertion_rejected'] for x in results),'total':len(results),'canonical_source_modified':False}
    (OUT/'SUMMARY_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not all(x['assertion_rejected'] for x in results):raise SystemExit(1)
