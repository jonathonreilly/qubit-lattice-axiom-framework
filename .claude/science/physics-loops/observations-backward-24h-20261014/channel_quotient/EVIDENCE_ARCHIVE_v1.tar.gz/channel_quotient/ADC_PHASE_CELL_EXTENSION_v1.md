# Finite-resolution phase cells and the large channel character

Root personally derived this extension after the first development results.
It is conditional geometry of a specified ideal ADC cell, not an assertion
that analog voltage phase equals a fitted coherent carrier phase. Independent
review of this new extension is pending. No additional raw data is opened.

Suppose each real ADC component has B signed bits and the corrected complex
center is z=(2*i+1)+i_unit*(2*q+1). Suppose also that an unsaturated code's
entire analog preimage is the square z+[-1,1]^2. These are explicitly supplied
quantizer premises. The documentation supplies the stored representation and
2*k+1 correction; it does not alone establish the complete physical preimage.

The square contains the closed disk of radius1 centered at z. When |z|>1,
the analog phase image therefore contains the interval

    arg(z) +/- asin(1/|z|),

using a continuous lift. The endpoints follow from the tangent lines to that
disk. Its angular width in cycles is at least1/(pi*|z|), since asin(x)>=x.
The B-bit code centers obey |z|<=sqrt(2)*(2^B-1), even including extreme codes
for this upper bound. If a cell includes zero, voltage phase is undefined and
the simple phase observable is already outside its domain.

At any rational relative carrier ratio, the primitive simultaneous-plasma
character has first coefficient N1=L*a with L>=1 and |a|=3007586755. Keeping
the other channels at their centers and varying only the X-channel voltage
inside its admissible disk, the character phase spans an interval of at least

    |N1|/[pi*sqrt(2)*(2^B-1)] cycles.

For B=16 this exceeds1 by a large margin. A completely rational sufficient
certificate uses pi<22/7 and sqrt(2)<3/2:

    |N1|/[pi*sqrt(2)*(2^16-1)]
      > |a|*7/[33*65535] > 1.

Thus the image of that single ideal ADC preimage cell under the primitive
character already covers its entire output circle. No raw code can determine
this pointwise voltage-phase character to a proper arc if that entire cell
remains admissible. Independently admissible cells across endpoints similarly
cover the whole product endpoint quotient and its constant-offset quotient.
This conclusion uses inner admissible disks, not the invalid inference that
a loose outer error box is actually attained.

There are several scope limits. This does not prove physical carrier noise
is large, does not reject coherent carrier fitting, and does not apply after
an independently justified waveform/time correlation restricts the Cartesian
voltage-cell set. Increasing the number of samples while fitting a restricted
coherent signal changes the admissible class. The hypothetical small integer
19/-5 downlink diagnostic is outside the simultaneous-plasma-annihilation
class and has a much smaller ADC-cell image, as the development calculation
illustrates. It still is not a gravity-sensitive signal or a calibrated
carrier measurement.

The exact implication for this route is a supplier requirement: a physical
coherent phase estimator or restricted waveform/error model must bridge the
raw finite-resolution receiver samples to the phase quotient before the large
joint-plasma character can be used as a measurement. A preferred phase lift,
rounded frequency ratio, assigned physical noise bound, or the format's
2*k+1 correction is not that bridge.
