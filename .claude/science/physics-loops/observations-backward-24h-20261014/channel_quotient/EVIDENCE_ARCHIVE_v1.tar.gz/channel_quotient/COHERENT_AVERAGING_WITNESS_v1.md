# Averaging before integer cancellation can change the observable

Root's exact deterministic witness. This is a mathematical example, not an
inference that the recorded receiver noise obeys any distribution.

Let two ideal voltage channels have unit amplitudes and the shared phase law
zX(t)=exp(5*i*theta(t)), zKa(t)=exp(19*i*theta(t)). At each sample,
zX(t)^19 * conjugate(zKa(t))^5=1 exactly. This is the ideal19/-5 contrast
with its common phase rescaled; neither noise nor phase slips are needed.

Take two samples theta0=0 and theta1=pi/10. Their complex means are

    mean(zX)=exp(i*pi/4)*cos(pi/4),
    mean(zKa)=exp(i*19*pi/20)*cos(19*pi/20).

Both means are nonzero. The first cosine is positive and the second negative.
After normalizing each mean to unit modulus, the19/-5character is-1, since
the shared mean phase cancels but the second channel's minus sign is raised
to an odd power. Thus the pointwise contrast is identically+1 while the
contrast of the two independently averaged channels is-1: a half-cycle change.

This explicitly tested construction rules out commuting independent voltage
averaging with integer cancellation for arbitrary shared phase histories. It
does not reject a physical carrier estimator supplied with the appropriate
dechirp, waveform regularity, phase-continuity, time alignment or error bound.
Those restrictions could exclude this fixture. No physical noise level or
phase selector has been introduced to do so here.

For the raw-record route, the practical consequence is to specify and justify
the phase estimator and its interaction with channel transfer before using
averaging as a replacement for the observed instantaneous-voltage contrast.
