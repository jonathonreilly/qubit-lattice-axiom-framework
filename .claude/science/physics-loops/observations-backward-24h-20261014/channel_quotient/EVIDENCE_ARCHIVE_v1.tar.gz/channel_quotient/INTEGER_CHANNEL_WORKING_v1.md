# Joint plasma and integer-phase quotient — working derivation

Author: /root in the user chat. 2026-10-15. Conditional working mathematics,
not a new action, physical calibration, or empirical gravity result. This source
is written from root's own calculations. Independent derivations were frozen
separately; short result messages have now been received, so subsequent edits
will not be called blind independence. TARGET_CONTRACT_v1.json fixes the model.

## 1. Model and the information being discarded

At each matched endpoint i, three received phases in cycles satisfy

    Phi_i = g_i G_i + a_i U_i + d_i D_i + b + n_i + e_i (mod 1),
    g_i = (k1 fX_i, k2 fX_i, k3 fK_i),
    a_i = (k1/fX_i, k2/fX_i, k3/fK_i),
    d_i = (1/(k1 fX_i), 1/(k2 fX_i), 1/(k3 fK_i)),
    k = (880/749, 3344/749, 14/15), rho_i=fK_i/fX_i>0.

The shared uplink/downlink columns use an explicitly supplied leading cold-plasma,
common-ray model. Frequencies are the appropriate supplied matched-event
frequencies; rounded frequency labels do not fix their exact ratio. G, U and D
are scalar endpoint quantities, b is an arbitrary constant three-channel offset
within this segment, n is an arbitrary integer history, and e is fractional error
with no default bound. Shared ray mapping, coherent transfer, clock alignment,
actual reference phases and electronics remain physical premises. Allowing U_i
and D_i arbitrary independently is a deliberately large nuisance class, not an
observed claim about the solar plasma. Relaxing it can restore information.

Every continuous function of the torus phases can be analyzed by its integer
Fourier characters exp(2*pi*i*sum_i N_i dot Phi_i). Invariance under all U_i,D_i
forces N_i dot a_i=N_i dot d_i=0 separately. Invariance under b forces sum_i N_i=0.
Conversely these identities suffice. Fourier averaging/Fejer approximation shows
that these allowed characters describe all continuous invariants. For dense
nuisance orbits the Hausdorff observable quotient is by their closure; no claim
is made about arbitrary discontinuous set-theoretic invariants.

## 2. Endpoint lattice derived from the exact turnaround ratios

Direct cross product, denominator clearing and primitive reduction gives

    (a,b,c)=(-3007586755,305348069,2325375360), gcd(a,b)=1,
    a*k1+b*k2+c*k3=0,
    a/k1+b/k2+c/k3=0, c*k3=2170350336.

The real simultaneous annihilator is N_i=m_i(a,b,c*rho_i).
Since gcd(a,b)=1, integrality of its first two entries forces m_i integer.
The remaining condition is c*rho_i*m_i integer. Thus an irrational rho_i
permits only m_i=0. For reduced rational rho=p/q, its primitive generator is

    N=(a*q/g,b*q/g,c*p/g), g=gcd(q,c).

No decimal approximation to a physical ratio is promoted to this exact premise.
The common signal coefficient is

    N_i dot g_i = c*k3*m_i*fX_i*(rho_i^2-1).

At rho=1 it vanishes. Existence of a nonzero nuisance-invariant character alone
is not sufficient to infer surviving G sensitivity.

## 3. Receiver offsets and time-varying ratios

The exact constant-offset conditions are

    sum_i m_i=0, sum_i m_i*rho_i=0,
    m_i integer, c*rho_i*m_i integer at each endpoint.

Irrational-ratio endpoints have m_i=0. On r rational endpoints the lattice rank
is r-rank_Q([1;rho]), with rank zero when r=0. Denominator restrictions change
the lattice spacing but not its rank. Two distinct ratios leave only zero;
three rational endpoints admit weights proportional to
(rho2-rho3,rho3-rho1,rho1-rho2), with denominators cleared. Equal ratios give
ordinary temporal differences. The surviving functional is the sum of the
G coefficients above; it can still vanish identically. For example ratios
(1,1,2) force the third weight zero, and both others have zero G coefficient.

Changing weights can be written in measured temporal count increments when
their channel-wise sum is zero: sum_i N_i Phi_i = sum_{j=1}^{J-1}
[-sum_{i<=j}N_i] dot (Phi_{j+1}-Phi_j). All coefficients remain integer.
This is an observable construction; it does not select a physical field history.

## 4. Robustness is an additional obligation

A fixed nonzero N cannot cancel both columns for every rho in a nonempty
interval: the constant and reciprocal-rho terms must vanish separately,
forcing N3=0 and then N1=N2=0. At nominal rho0 with N=m(a,b,c*rho0), the
actual leading plasma leakage at rho is exactly

    c*m/fX*(rho0/rho-1)*(k3*U+D/k3).

Without bounds on U,D, no nonzero ratio error guarantees small leakage.

For an integer character and a rectangular error set |e_il|<=epsilon_il,
its phase error ranges over [-eta,eta], eta=sum|N_il|epsilon_il. It covers
the whole output circle once eta>=1/2. This statement for a single character
alone does NOT show that all joint quotient information is lost.

For a sufficient joint statement: at each rational endpoint the primitive
plasma quotient is one circle. If the error box maps onto that entire circle
independently at each endpoint, the product covers the whole endpoint quotient
and therefore also its constant-offset quotient. Irrational endpoints already
have trivial continuous quotient. Uniform first-two-channel error bounds
epsilon>=1/[2*(|a|+|b|)]=1/6625869648 cycles suffice for all rational ratios,
because their primitive m is a positive integer. This is a worst-case allowance,
not a measured physical noise floor. An upper error bound can be conservative;
it is not evidence that actual errors attain its whole box or are independent.

## 5. A small integer contrast with a narrower physical purpose

The exact ratio k2/k1=19/5 gives v=(19,-5,0). It obeys

    v dot g=0, v dot a=0,
    v dot d=15729/(1045*fX).

Hence it removes the shared nondispersive and uplink phase while retaining
downlink plasma/electronics. More generally, if PhiX=k1*Theta+RX+bX+nX+eX
and PhiKa=k2*Theta+RK+bK+nK+eK, then 19*PhiX-5*PhiKa eliminates ANY common
Theta, including its chirp, without a linearized gravity/plasma decomposition.
Temporal differences remove constant 19*bX-5*bK. The corresponding complex
sample character is (zX/|zX|)^19 * conjugate(zKa/|zKa|)^5 after physically
justified reference-phase restoration. It is a nuisance diagnostic, not a
gravity-sensitive measurement. The standard real dual-frequency contrast is
already in Asmar et al. 2005; only its exact integer compatibility and the joint
calibration/phase-history question are being investigated here.

The uniform endpoint phase-error amplification is 24; a two-endpoint contrast
has 48. These factors are mathematical, not assigned instrument uncertainties.

## 6. ADC representation route and its limits

The existing PDS SIS says signed truncated samples k require the 2*k+1
correction. Under an additional unsaturated ideal midrise-quantizer premise,
the unknown analog I/Q at the ADC lies in the square of half-width one about
the corrected odd-integer center z. If |z|>sqrt(2), enclosing that square in a
disk gives angular error <=asin(sqrt(2)/|z|)/(2*pi) cycles. Exact rectangle
extrema can be obtained from its four corner arguments when the origin is
outside the rectangle. Saturated extreme codes do not establish a bounded
cell; any origin-reaching cell needs special handling. A format correction
alone does not prove the quantizer transfer function or absence of clipping.

This would bound representation of total analog complex voltage only. Thermal
noise, plasma, oscillator and receiver error, carrier extraction, reference
phase convention, and time matching remain separate. It is not a carrier
accuracy bound and cannot supply a scalar residual or energy budget.

## Sources and status

Primary ideal transponder ratios: Armstrong, Living Reviews in Relativity
2006 article, revised 2016, section 4.6; Kliore et al. Cassini radio-science
instrument description. Primary dual-link contrast: Asmar et al. 2005,
https://www.issibern.ch/teams/pioneer/public/Asmar_etal_2005.pdf . Primary RSR
fields: existing metadata rsr_c32easc2002_169_1335x54x25d.lbl and casrssis.txt,
hashes in the existing physical_link metadata manifest. Exact full supplier
review will be bound separately. No new raw receiver samples were opened
before this working note. Action, potential, scales, physical initial state,
environment and the real measurement/error map remain open.
