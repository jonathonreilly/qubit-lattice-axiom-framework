# ADC inner-cell extension: focused post-exposure check v1

Reviewer: `/root/force_energy_bridge_check`. This check follows exposure to the author's conditional ADC extension; it is not part of the earlier blind derivation. Root retains authorship. I read the complete 61-line `ADC_PHASE_CELL_EXTENSION_v1.md` and the complete companion `ADC_PHASE_CELL_RESULTS_v1.json`. The exact source SHA256 values are respectively `d8e4ccb325f8d5ede5c1f3e80c0c230a3fc27fac1e354e25d7ae7e6bf39ed8a3` and `0981c522312d7f97c68fa00637f3794c94e73ad8099d3a2189d02c6f628f56b1`. Both sources were copied into this directory before reading; `ADC_EXTENSION_EXPOSURE_v1.json` preserves that chronology. No raw data, author code, metadata, external source or network was accessed.

## Conclusion and exact scope

The extension is a legitimate **conditional supplier requirement** for constructing the large simultaneous-plasma pointwise phase character from the stated raw ADC cells. The inner-cell proof establishes actual surjectivity within the assumed admissible set, not merely that an outer error bound is too large. It does not establish large physical receiver/carrier noise, impossibility of coherent carrier fitting, or loss of full tracking information. Those distinctions are retained in the note.

The mathematical claim is contingent on the entire ideal unsaturated cell remaining admissible, phase being identified pointwise with nonzero complex voltage, and the relevant cells being independently variable. A physical model restricting cross-channel or cross-time voltage waveforms may change the image. The note explicitly leaves such a bridge open. No substantive mathematical discrepancy was found in the checked conditional argument.

## Inner disk and angular interval

Let z be a nonzero complex center, R=|z|, and assume the admissible cell contains the disk |w-z|<=1. For R>1 the disk excludes the origin. The two rays tangent to it make relative angles +/-asin(1/R) with z. Every intermediate ray intersects the disk, so its angular image contains the entire continuous interval between those limits. This is an attained interval under the stated closed-cell premise, not an error upper bound.

The full width is 2 asin(1/R) radians, hence asin(1/R)/pi cycles. Because asin(t)>=t for 0<=t<=1, the width is at least 1/(pi R). This confirms the factor of two and the cycles convention. The argument uses a continuous relative angular lift and is unaffected by a principal-argument branch cut.

For a B-bit signed component, k lies between -2^(B-1) and 2^(B-1)-1. The corrected coordinate 2k+1 therefore has magnitude at most 2^B-1, giving R<=sqrt(2)(2^B-1). This is a statement about corrected center coordinates, not a claim that a saturated code has a bounded analog preimage. The full-cell premise is explicitly additional. If the full square reaches zero, a phase function on its entire set needs special treatment; the inner disk used here still excludes zero for these odd two-component centers, whose minimum R is sqrt(2).

The enormous strict width margin also makes the coverage conclusion insensitive to merely half-open quantizer-bin boundaries: a disk of radius 1/2 lies strictly inside such a cell and gives half the displayed lower-width certificate, which is still greater than one. This observation does not weaken the requirement that the cell interior really be admissible under the physical transfer model.

## Character circle coverage and exact certificate

At a rational carrier ratio, the previously proved primitive plasma quotient row has first coefficient N1=L a, with positive integer L and |a|=3007586755. Hold the other channel voltages at their admissible centers and vary only the first channel within its inner disk. Its lifted character phase is an affine function of the first voltage phase, with slope N1. Consequently the character image contains an interval of length at least

    |N1|/[pi sqrt(2)(2^B-1)] cycles.

Any real interval of length at least one projects onto the whole unit circle. Here the bound is strictly greater than one, so endpoint inclusion is immaterial.

For B=16, using pi<22/7 and sqrt(2)<3/2 yields the strict lower bound

    |N1|/[pi sqrt(2)65535]
      > |a|*7/(33*65535)
      = 4210621457/432531 > 1.

A single exact Fraction calculation checked the companion result's reduced rational certificate. Its decimal is only a display approximation and is not used in the proof. No arithmetic sweep, raw-data analysis or author program was run. The bit depth and ideal-cell interpretation are supplied premises here, not independently verified metadata facts.

The conclusion is that this *one conditional pointwise quotient coordinate* cannot be confined to a proper arc by its raw code when the entire cell remains admissible. At each rational endpoint that primitive coordinate parametrizes the whole continuous plasma quotient. Independent endpoint cells therefore map onto the product of those circles. Composition with the constant-receiver-offset quotient map remains surjective, proving the joint statement. Irrational endpoints have no nontrivial continuous plasma quotient under the already declared unrestricted nuisance model.

This product step needs independent admissibility of the relevant voltage changes, including the ability to vary the chosen channel while holding the others fixed. Componentwise quantizer preimages alone describe the raw inverse map; additional physical channel/time constraints can shrink their intersection. It is exactly that restricted waveform/phase estimator bridge which must be supplied before applying the large character as a useful measured quantity.

## Physical and comparative limits

An inner admissible set avoids the previous logical mistake of interpreting a conservative outer box as attained physical noise. Even so, the resulting set is conditional on the quantizer and unconstrained-voltage premises. It is a set-valued identifiability result, not a stochastic noise estimate or an assertion that the instrument visits all voltages in the cell.

The total analog voltage can contain noise and other components, and its instantaneous phase need not equal a coherent carrier phase. Signal fitting over multiple samples, known waveform structure, calibration, or cross-channel relationships can reduce the admissible set. The note leaves these options open and correctly calls for a supplier instead of selecting a phase lift or assigning an error magnitude.

The small 19/-5 diagnostic belongs to a different class because it retains downlink nuisance and removes the shared G term. Smaller coefficients reduce its lifted angular amplification, but do not by themselves guarantee a proper-arc image for every possible low-amplitude cell. The note's reference to the development calculation is a particular data comparison; that empirical comparison is not checked here. The present large-character theorem does not require it and cannot be read as an information-loss theorem for that diagnostic or all radio tracking.

## Preserved evidence

The original independent precheck, 126 controls, results and first source correspondence remain unchanged. This report addresses only the two newly pinned extension files. No canonical source or implementation is included in its scope. All new files are confined to `channel_quotient/independent_math_v1`; no Git/index, campaign state, lock, source, raw-data or publication changes were made. No formal audit verdict is supplied.
