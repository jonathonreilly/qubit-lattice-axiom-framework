# Combined working-source and coherent-averaging correspondence v1

Reviewer: `/root/force_energy_bridge_check`; main author: `/root`. This is a focused **post-exposure** source correspondence and exact proof check. It does not extend the original blind derivation, launch a new scientific route, certify empirical calibration, or apply a formal audit verdict. The original proof, 126 controls and prior correspondence reports remain unchanged.

## Exact read scope

The requested sources are preserved byte-for-byte in this directory:

| Source | SHA256 | Scope |
| --- | --- | --- |
| `channel_controls_v1.py` | `52f07a4aa69b2b5ebe889493722616bb28a7dbddb2e59b1b06f4f069a0196033` | Complete implementation read |
| `INTEGER_CHANNEL_WORKING_v2.md` | `94f70dacb27bf8274bfee963852d46f0b65724c8781e1eb7cf4e2c7588bbd419` | Exact delta against the previously fully read v1 |
| `COHERENT_AVERAGING_WITNESS_v1.md` | `fb9a809a717ae625f78fc18b6db78434e8d17d3071e716cfb01d14e638aade63` | Complete proof read |

`AUTHOR_IMPLEMENTATION_EXPOSURE_v1.json` records this later exposure. The v1 note was completely read at SHA256 `57f4729a1178ab0a7a2ed267c1a82c7a7764c271ce9ef238623261c404949878`; the complete v1-to-v2 diff is also preserved. No raw data, new metadata, external document, network resource, canonical source or other author implementation was read.

No substantive mathematical or source-correspondence discrepancy was found. The two earlier implementation-domain qualifications are now explicit in the v2 note. The coherent-averaging counterexample has the stated signs and nonzero means, so it correctly disproves unrestricted commutation of those operations. No new arithmetic sweep or author aggregate rerun was needed.

## Exact helper correspondence

The helper implements the exact integer/Fraction domain. It rejects floats, strings, symbolic irrational values and booleans rather than interpreting approximate carrier labels as physical rationality. This intentionally narrower accepted type set need not accept every mathematical rational encoding to implement its declared examples correctly.

`primitive` uses the proved denominator/gcd expression with positive ratio and the author's global sign convention. `columns` implements g, a and d directly; d as the entrywise inverse of g gives exactly the displayed downlink column. Positive absolute and relative frequencies are enforced there. The code's physical-frequency numbers are supplied exact synthetic fixture parameters, not empirical certification of the true ratios.

`temporal` is correctly labeled one three-endpoint construction rather than an entire integer-lattice basis. Its raw coefficients (rho2-rho3,rho3-rho1,rho1-rho2) satisfy the two receiver-sum equations. The LCM includes the denominators of both raw coefficients and C*rho*raw. Thus after scaling, every m_i and C*rho_i*m_i is exactly integral; the subsequent integer conversion in the example does not truncate a noninteger quantity. This construction does not promise a nonzero row at three identical ratios or classify every physical history, and no such claim is needed.

`box_halfwidth` checks matching lengths and nonnegative exact error allowances and then computes the support function of the stated rectangular box. In the current call sites the coefficients are exact integer rows. The single threshold fixture verifies the primitive-base first-two-coordinate interval reaches half a cycle. The previously reviewed analytic argument, using L>=1 and the Cartesian product, supplies the general joint-quotient consequence; one passing threshold assertion alone would not prove that consequence.

The 34 named author controls cover the Bezout/nuisance identities; five exact primitive/null/signal cases; rejection of four unsupported inputs; three-ratio receiver and signal behavior; the two-distinct-ratio obstruction; a nonzero lattice with no G signal; count rewriting; exact small-ratio leakage; the uniform first-two error threshold; and the small 19/-5 diagnostic identities and error amplification. Their formulas agree with the frozen independent derivation and the author's working note. In particular, their nonzero-signal fixture is not substituted for the independent necessary-and-sufficient classification.

The source contains no ADC-cell angular implementation and no coherent-averaging counterexample control. Those new claims have been checked analytically in their own notes; they are not silently counted among the helper's 34 controls. I did not execute this helper or verify its output file in this correspondence. The source inspection establishes formula/fixture correspondence, not a fresh numerical result or a claim that every guard or edge case has been tested.

## v2 closes the earlier domain qualifications

The exact note delta has only two changes. The normalized complex character now explicitly requires nonzero complex samples. The rectangle-corner rule now requires a continuous angular lift relative to the center and rejects naive principal-angle min/max. Both are precisely the qualifications recorded in `AUTHOR_NOTE_CORRESPONDENCE_v1.md`; no other proof or formula changed.

The earlier exact odd-center branch-cut witness remains preserved in that report. This wording closure does not assert that some unexamined phase-extraction implementation already applies the guards. No such implementation was in this read scope.

## Coherent averaging: exact sign and domain check

The witness uses two unit-amplitude channels with zX(t)=exp(5 i theta(t)) and zKa(t)=exp(19 i theta(t)). Here theta is an angular parameter; the common phase can be rescaled into the earlier cycles convention. At every sample, the pointwise character is

    zX^19 conjugate(zKa)^5
      = exp(95 i theta) exp(-95 i theta)=1.

For theta0=0 and theta1=pi/10, the X samples are 1 and i. Their mean is exp(i*pi/4) cos(pi/4), with positive cosine. The Ka samples are 1 and exp(i*19*pi/10), equivalently 1 and exp(-i*pi/10). Their mean is exp(i*19*pi/20) cos(19*pi/20). Its cosine is negative, but nonzero.

After normalizing the means, the phases are therefore

    uX=exp(i*pi/4),
    uKa=-exp(i*19*pi/20)=exp(-i*pi/20).

Both normalizations are valid. Consequently

    uX^19 conjugate(uKa)^5
      = exp(i*(19*pi/4+pi/4))=exp(5*pi*i)=-1.

There is no sign or factor-of-two discrepancy. The phase half-cycle difference is an actual difference of complex characters, not merely a principal-argument branch convention. The example needs no additive noise, integer slips, vanishing average, chosen scalar state or uncertain error magnitude. Computing the two channel means separately is deterministic and does not assume statistical independence of their noises.

It refutes equality between the pointwise character and the character formed after separate complex averaging for arbitrary shared phase histories. It does not say that every averaging estimator fails, that a calibrated dechirp cannot work, or that the ideal fixture describes the observed waveform. A dechirp, coherent signal model, time regularity or other restriction may exclude this history or alter the estimator. Such restrictions are additional physical/estimator suppliers, as the note explicitly states. The exact witness cannot be removed merely by changing a principal phase convention; the character values themselves differ.

## Relation to the already frozen ADC extension review

Before opening these three sources, I froze the ADC extension check in `ADC_EXTENSION_REVIEW_v1.md`, SHA256 `c504590c27231a6a1f64fc7c4650a8821c77422747967197e1d9fa8c5d620e51`, identity `69536dba5513529e0995fb9b4bfdf66c9d22b10b1b21f9832680007d9fd8d270`.

That review confirms the inner-disk angular-interval proof, the exact certificate 4210621457/432531>1, and product quotient descent under independently admissible channel/endpoint cells. It keeps the entire ideal cell and pointwise-voltage identification as premises. The coherent-averaging witness addresses a separate tempting substitution: it prevents one from assuming that replacing pointwise phases by separately averaged-channel phases leaves the character unchanged. Together they identify a real need to specify the physical phase estimator and its admissible waveform/error class. They do not prove broad information loss for carrier tracking or reject a supplied estimator with appropriate conditions.

The ADC review did not validate the referenced data comparison, analog hardware transfer law, actual clipping status or a quantitative receiver-noise budget. This combined source report does not add any such validation.

## Evidence, limits and completion

The independent pre-exposure report remains SHA256 `ffdd9e7de412a67b8d13df50cb7508e7fdf02575aa237f5600358f8a379fe33c`, identity `32be25beb3ba9d6f2079c64657f289ef79b14f47f3329e0bfb893e661a45fcdd`. Its 126 passing controls stay separate from this later static source/proof comparison and from the author's reported 34-control execution. No author aggregate or new arithmetic sweep was executed here, and no execution failure or repair occurred in this correspondence.

The full file identities for this closure are in `AUTHOR_IMPLEMENTATION_CORRESPONDENCE_IDENTITY_v1.json`. Only new immutable files in the assigned independent directory were written. No scientific source, data, index/branch, campaign lock/status, PR, main branch, network resource or formal audit record was changed. This completes the requested scoped working-source check; further canonical or physical calibration validation is outside it.
