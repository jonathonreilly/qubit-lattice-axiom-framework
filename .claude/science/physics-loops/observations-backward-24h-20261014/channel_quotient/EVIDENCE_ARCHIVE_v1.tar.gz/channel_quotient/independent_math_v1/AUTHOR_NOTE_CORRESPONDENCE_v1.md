# Author working-note correspondence v1

Reviewer: `/root/force_energy_bridge_check`. This is a separately labeled **post-author-exposure** mathematical correspondence check. The independent derivation, 126 exact controls and original full report were frozen first and remain unchanged. This is not a formal audit, an implementation review, a new empirical test or a blind derivation of the author's added propositions.

## Read scope and conclusion

I read the complete 155-line `channel_quotient/INTEGER_CHANNEL_WORKING_v1.md`, SHA256 `57f4729a1178ab0a7a2ed267c1a82c7a7764c271ce9ef238623261c404949878`. Its exact bytes are preserved in `AUTHOR_INTEGER_CHANNEL_WORKING_v1.md`, and the exposure record is `AUTHOR_NOTE_EXPOSURE_v1.json`. The only preceding new root source was the target contract; no author code, raw data, instrument metadata, referenced papers, or network source has been read. Source/documentary statements in sections 5–6 and the source list were encountered but not verified.

The quotient classification, receiver cancellation and signal conditions agree with the independently frozen proof. The new joint-quotient error-box proposition is valid for the stated Cartesian admissible error set. The small-coefficient diagnostic is correct and has its explicitly narrower nuisance purpose. The conditional quantizer disk-angle and rectangle-extremum claims are mathematically valid under their supplied cell/domain premises.

I found no substantive hole in these displayed proofs. Two domain/implementation qualifications should remain explicit when implementing or packaging them: normalized complex samples require both samples to be nonzero; rectangle corner arguments must share a continuous angular lift, preferably relative to the center, rather than use a naive principal-angle min/max across the branch cut. A concrete odd-center branch-cut witness is given below. No implementation has yet been checked.

## Correspondence with the pre-exposure derivation

The author's (a,b,c) is exactly minus my (p,q,c). This global orientation changes neither the integer annihilator nor the observable family. Its endpoint divisibility and primitive generator match equations (C)–(D) of my precheck. Arbitrary independent U_i,D_i force local annihilation; arbitrary real b forces the exact vector sum zero. Irrational-ratio endpoints have no nonzero weight, and the denominator restrictions change index/spacing but not the rational-kernel rank.

The two-distinct-ratio obstruction, the three-rational-endpoint construction, the count rewrite, and the (1,1,2) zero-signal exception are all correctly limited. The nominal-ratio leakage agrees exactly with my equation (H); unconstrained U or D prevents a frequency-closeness bound from controlling that leakage. No scalar state, physical rationality or quantitative plasma bound has been silently supplied.

The complete-continuous-invariant statement is justified: a continuous torus function has Fourier coefficients supported on integer characters; invariance under each real nuisance translation forces every coefficient with a nonzero nuisance pairing to vanish. Finite Fejer sums inherit the same support and converge uniformly to the continuous function. Thus the allowed characters describe the continuous invariants, including the need to use the closure of dense nuisance orbits. This does not eliminate discontinuous set-theoretic invariants or physically restricted nuisance models.

## Joint error coverage: a constructive proof

The author's distinction between single-character coverage and all-joint-quotient coverage is essential and correctly retained. A large allowed error for one character alone says nothing about the simultaneous image of an error set under several characters.

For a rational endpoint rho=P/Q, let g=gcd(Q,c), L=Q/g, and the primitive row be N=(La,Lb,cP/g). The plasma plane is the real kernel of N. Its image modulo integers is the connected kernel of the primitive character exp(2 pi i N dot Phi), so its Hausdorff endpoint quotient is exactly one circle. Primitivity matters: it avoids treating multiple character windings as an independent quotient coordinate.

Let S=|a|+|b|=3312934824, and allow a Cartesian box in which the first two endpoint errors independently range over [-epsilon,epsilon]; the third can be fixed to zero. For any desired endpoint quotient representative t in [-1/2,1/2], choose

    e1=sign(a)*t/(L S), e2=sign(b)*t/(L S), e3=0.

Then N dot e=t and |e1|=|e2|<=1/(2 L S)<=1/(2 S). Thus epsilon>=1/6625869648 is a sufficient uniform allowance for all rational rho. This is an exact constructive surjectivity proof; it neither assumes that the primitive third coefficient is small nor treats a rational denominator as rounded.

If those endpoint boxes form a Cartesian product, apply the construction separately at each endpoint. Their image is the entire product of endpoint quotient circles. Passing through the quotient by the common receiver-offset subgroup preserves surjectivity: the image of the whole product under the final quotient map is the whole final quotient. Irrational endpoints contribute no continuous endpoint quotient under the given local nuisance class. Hence the claimed joint statement follows for continuous invariants of this model.

This is a statement about an **admissible uncertainty set**, not stochastic independence, realized noise or an actual physical lower noise floor. A set known only to be contained in the box need not itself project surjectively. A loose conservative outer box can destroy a worst-case exclusion while the actual correlated errors occupy a much smaller subset. The note expressly warns that the upper allowance is not evidence of actual attainment or independence, so it does not make that invalid inference. The proposition does not claim loss of the small diagnostic below, because that diagnostic deliberately retains downlink plasma and is outside the full-plasma invariant class.

## The small (19,-5,0) character

Using the first two channels, which share the supplied X uplink, k2/k1=19/5 yields

    19 k1-5 k2=0,
    19/k1-5/k2=15729/1045.

Therefore (19,-5,0) kills g and a while leaving the stated downlink coefficient 15729/(1045 fX). This is not in the joint a/d annihilator. Its much smaller weights do not contradict the large primitive coefficients for full plasma elimination.

The more general identity with Phi_1=k1 Theta+R1+b1+n1+e1 and Phi_2=k2 Theta+R2+b2+n2+e2 is exact for arbitrary common Theta, including an arbitrary chirp, because the k-weighted common term cancels identically. It needs the same matched Theta in both channels; a physical common transfer/retarded-time identification is still a supplier. The residual is 19R1-5R2 plus receiver/error terms. It is not independently identified as plasma, nor does it retain a common gravitational phase.

Integer exponents make the complex product invariant under arbitrary whole-cycle histories. With nonzero complex samples z1,z2 and a physically justified reference convention, the product (z1/|z1|)^19 conjugate(z2/|z2|)^5 has exactly that character phase. A zero sample has no normalized phase and needs exclusion or a separately defined treatment; assigning it a phase is not licensed. A temporal difference removes constant receiver combination 19b1-5b2. Uniform per-coordinate endpoint phase-error radius epsilon amplifies to 24 epsilon, and an independent two-endpoint box to 48 epsilon, after combining shared endpoints. These are bounds under supplied phase-error sets, not ADC or carrier uncertainty estimates.

The cited precedent and instrument/reference restoration are not checked in this mathematical review. In particular, no raw complex voltage phase is promoted here to an extracted carrier phase.

## Conditional quantization-angle lemma and branch handling

Accept as an extra premise the unsaturated ideal midrise cell: the analog complex voltage w lies in the square of half-width one about corrected odd-integer center z. The representation error then obeys |w-z|<=sqrt(2). If |z|>sqrt(2), that disk excludes zero. Its two tangent rays from the origin make angles +/-asin(sqrt(2)/|z|) relative to z, proving the displayed cycles bound after division by 2 pi. This is geometry conditional on the actual cell premise; a stored odd-center correction does not by itself derive that analog transfer law or clipping status.

For the sharper rectangle statement, a convex rectangle excluding the origin lies in an open half-plane through the origin, so its arguments admit a continuous angular lift spanning less than pi. Along an edge w(t)=u+t v, the angular derivative is det(u,v)/|u+t v|^2. Its numerator has a fixed sign, or is zero on the whole edge. Hence edge extrema occur at endpoints, and the global extrema occur among the four corners. The proof is valid with a coherent lift; it is not a license to subtract arbitrary principal atan2 values.

A useful exact branch-cut witness uses the allowed corrected odd center z=(-3,-1). Its cell [-4,-2] by [-2,0] excludes the origin. Principal corner arguments include +pi at (-4,0) and (-2,0), alongside negative arguments at the lower corners. Their naive min/max gives a spurious almost-full-circle span. Relative arguments

    atan2(det(z,w), dot(z,w))

give the correct corner extrema -atan(1/3) and +atan(1/2). The maximum angular error is atan(1/2), equal in this fixture to asin(sqrt(2)/sqrt(10)). Divide by 2 pi for cycles. This counterexample concerns a branch-handling shortcut, not the geometrical bound itself. It was communicated before code review so the eventual implementation can preserve the correct domain.

If the cell reaches the origin, phase may be undefined and a separate case is necessary. Saturated codes do not establish this bounded ideal cell. Even a correctly derived cell-angle bound describes total analog-voltage representation only; thermal noise, carrier extraction, oscillator/plasma errors and measurement transfer remain outside it, as the note states.

## Execution, exposure and remaining check

No new arithmetic sweep or author aggregate was run for this correspondence. The additional work is a complete source read and the constructive joint-surjectivity, diagnostic and angular proofs above, with one analytic branch-cut witness. The 126 pre-exposure controls and their exact output are unchanged; they must not be relabeled as independent validation of these newly read author propositions.

The original independent report is `INDEPENDENT_REVIEW_v1.md`, SHA256 `ffdd9e7de412a67b8d13df50cb7508e7fdf02575aa237f5600358f8a379fe33c`; identity `32be25beb3ba9d6f2079c64657f289ef79b14f47f3329e0bfb893e661a45fcdd`. The precheck, scripts, results and source contract remain byte-preserved. This source correspondence is limited to the pinned working note. A subsequent implementation, canonical adaptation or changed domain statement will require a separately labeled affected check rather than an assertion that it was already examined here.

Only this assigned independent directory was written. No root scientific source, data, branch/index, lock, campaign state, publication artifact, network resource or formal audit record was changed. No quantitative physical error or noise model was introduced.
