# Independent three-channel quotient precheck v1

Reviewer: `/root/force_energy_bridge_check`. Frozen before author derivation or implementation exposure. The sole new root source read is `channel_quotient/TARGET_CONTRACT_v1.json`, SHA256 `979c4d60a83329ed4781279ac36a4d1e9d24989bbcb2102f03eada3b201030ae`. The task's k ratios and phase law are supplied hypotheses, not physical facts verified here. This is an independent mathematical precheck, not a formal audit or an empirical test. No new observation, network source, author work, or existing numerical data product has been read.

## 1. Full character classification from the stated group

Let there be N endpoints in one supplied continuous receiver segment. The observed phase at each endpoint is an element of T^3=R^3/Z^3. Put x_i=fX_i>0, r_i=fK_i/fX_i>0 and k=(880/749,3344/749,14/15). At endpoint i the signal and independent nuisance columns are

    g_i=x_i (k1,k2,k3 r_i),
    a_i=x_i^(-1) (k1,k2,k3/r_i),
    d_i=x_i^(-1) (1/k1,1/k2,1/(k3 r_i)).

Every continuous torus character on all phases is

    chi_W(Phi)=exp(2 pi i sum_i w_i dot Phi_i),  w_i in Z^3.

Integer entries are necessary: translation of one phase coordinate by one must leave the character unchanged. They are sufficient for integer-history invariance. Because U_i and D_i are arbitrary real and independent at each endpoint, invariance under their shifts holds exactly when

    w_i dot a_i = w_i dot d_i = 0  for every i.       (A)

There is no cancellation of independent U_i across different endpoints. The common arbitrary real receiver vector b is removed exactly when

    sum_i w_i=0 in R^3.                              (B)

An integer-valued nonzero sum is insufficient because b is real. Thus (A), (B), and integrality are already a complete necessary-and-sufficient characterization, before any choice of coordinates or state.

## 2. Exact endpoint annihilator and rationality

The two nuisance columns are linearly independent because k1 != k2. A direct cross product is proportional to

    (k1(k2^2-k3^2), k2(k3^2-k1^2),
     r k3(k1^2-k2^2)).

For the supplied k, choose the exact integer normalization

    p= 3007586755, q=-305348069, c=-2325375360.

Then gcd(p,q)=1 and

    p k1+q k2+c k3=0,
    p/k1+q/k2+c/k3=0.

The real null line is exactly lambda (p,q,c r). The first two components of an integer vector on this line imply lambda is an integer: Bezout supplies integers A,B with A p+B q=1, hence lambda=A w1+B w2. Consequently

    w=lambda (p,q,c r), lambda in Z, lambda c r in Z. (C)

Since c is nonzero, for irrational r the only allowed vector is zero. For r=P/Q>0 in lowest terms, put h=gcd(Q,|c|), L=Q/h. The entire integer annihilator is

    w=m v_r,  m in Z,
    v_r=(L p,L q,c P/h).                            (D)

This generator is primitive: its first-two gcd is L, and gcd(L,cP/h)=1. No finite decimal representation proves the physical r rational. A common synthesis reference could supply exact commensurability, but that would be a new instrument-identification premise, not a numerical rounding step.

For irrational r, the projected real nuisance plane is dense in T^3: its annihilator contains no nonzero torus character. Equivalently, invariance forces every nonzero Fourier coefficient of a continuous function to vanish, and uniform trigonometric approximation forces a constant. This conclusion concerns continuous invariants of this precise unrestricted nuisance group, not all tracking inference, restricted plasma models, or noncontinuous estimators.

## 3. Receiver cancellation for fixed and changing uplinks

Ignore irrational-ratio endpoints, since their w_i must be zero. Let I be the remaining set, with K=|I|. Write w_i=lambda_i(p,q,c r_i), lambda_i in L_i Z. Condition (B) becomes exactly

    sum_i lambda_i=0,  sum_i lambda_i r_i=0.         (E)

These are rational equations with the stated divisibility restrictions. Equivalently, with integer coefficients m_i, take the integer kernel of the two-row matrix whose columns are (L_i,cP_i/h_i); multiplying its first row by p or q merely restores the redundant receiver coordinates. This is an exact description of ALL characters. No claim that an arbitrarily denominator-cleared rational nullspace basis is automatically a full integer-lattice basis is needed.

For K>0 its rank as a free abelian lattice is K-1 if all r_i are equal, and K-2 if at least two distinct r_i occur. Rational divisibility restrictions have finite index in the rational nullspace and do not change that rank. With K=0 the rank is zero. Thus a single endpoint never survives arbitrary b. Two endpoints give a nonzero character precisely when both ratios are the same exact rational number. With three distinct rational ratios, a nonzero receiver-cancelling row always exists: take lambda proportional to (r3-r2,r1-r3,r2-r1), and clear denominators so each lambda_i belongs to L_i Z. Three endpoints with only two distinct ratios can instead carry a difference within a repeated-ratio group; the singleton group's coefficient must vanish.

A changing ratio therefore does not establish a broad obstruction. It rules out a two-endpoint shared-weight cancellation when the two ratios differ, while three or more matched rational endpoints can supply a different integer character. An irrational endpoint does not become useful merely because the same irrational ratio appears elsewhere: its U_i,D_i are independent, so local annihilation is still required.

Every vector W with sum_i w_i=0 is count-derived. In time order, define integer vector t_j=-sum_{i=0}^j w_i for j=0,...,N-2. Then

    sum_i w_i dot Phi_i
       =sum_j t_j dot (Phi_{j+1}-Phi_j).             (F)

Thus the surviving characters can be formed from accumulated cycles. If records are frequency averages, first multiply by their correctly supplied count durations and carry the lattice map; arbitrary normalization does not preserve the same unit period. With multiple independent receiver segments, (B)/(E) must hold separately for each segment.

## 4. Surviving common-phase sensitivity

For an allowed endpoint weight, the signal coefficient is

    s_i=w_i dot g_i
       =lambda_i c k3 x_i (r_i^2-1),
    c k3=-2170350336.                               (G)

The character's signal is exp(2 pi i sum_i s_i G_i). Its functional on arbitrary endpoint histories G_i is nonzero exactly when some nonzero lambda_i has r_i !=1. A ratio r=1 makes g proportional to a, so simultaneous removal of arbitrary U eliminates G at that endpoint too. A nonzero character is not by itself proof of nonzero realized signal: a particular G history may lie in its kernel, and phases remain aliased.

A complete existence condition for a nonzero signal functional is that some rational endpoint with r_i !=1 can participate in the kernel (E). Such an endpoint participates if another endpoint has the same ratio, or if the remaining endpoints contain two distinct ratios. In terms of distinct rational ratio groups:

- One group: at least two endpoints and its ratio !=1.
- Two groups: at least one group with ratio !=1 must contain at least two endpoints; (E) forces the total lambda within each group separately to vanish.
- At least three groups: a nonzero signal functional exists, using a triple of distinct ratios.

This exposes an exception to counting kernel rank alone: ratios (1,1,2) leave a nonzero receiver/plasma-invariant character, but its weights are supported only on the ratio-one endpoints, and it has no G sensitivity.

If instead G is constrained to be one time-independent unknown G0, its coefficient is c k3 sum_i lambda_i x_i(r_i^2-1). Such a scalar survives for some W exactly when the vector with components x_i(r_i^2-1) is not in the real row span of (1,r_i), restricted to the rational endpoints. This follows because the integer lattice spans the rational nullspace over R. Do not conflate a nonzero history functional with sensitivity to a constant G0. For fixed x and fixed r, receiver cancellation removes constant G0. For fixed x and three distinct ratios, a quadratic in r cannot coincide with an affine function at all three points, so constant-G0 sensitivity can survive.

Concrete receiver-free count example: r=(2,3,4), x_i=1, lambda=(1,-2,1). Then w_i=lambda_i(p,q,c r_i), sum_i w_i=0, and the signal coefficients are c k3 times (3,-16,15). Their sum is 2 c k3, nonzero. Equation (F) gives count weights -w0 and w2. This is an exact mathematical example under supplied carrier ratios, not a physical campaign result.

## 5. Rounding, real weights, and exact failure witnesses

A real plasma-free vector (p,q,c r) exists even at irrational r, but it is not an integer torus character. Applying it to a chosen lift and reducing modulo one changes under integer histories. For irrational r its projected integer ambiguity contains an irrational generator alongside the coprime integer p,q, and is dense. No continuous scalar observable can be recovered from that projected quotient alone. The full original data and models with bounded histories remain possible alternative routes.

Dividing an integer vector v by a large integer B does not provide free precision. The resulting rational vector has image period 1/B when v is primitive. If it is incorrectly treated modulo one, a unit slip in a coordinate with coefficient not divisible by B changes the result. Carrying the correct period restores exactly the same character, signal-to-period ratio and error-to-period ratio.

A near-rational ratio is not enough under unbounded plasma amplitudes. Freeze weights w=lambda(p,q,c r0) designed for an exact rational r0, but let the true ratio be r. Direct substitution gives

    w dot a(r)=lambda c k3/x * (r0/r-1),
    w dot d(r)=lambda c/(k3 x) * (r0/r-1).           (H)

If r !=r0, set D=0 and U=(1/2)/(w dot a(r)); this produces a half-cycle nuisance phase while G=b=e=0, regardless of how small r-r0 is. Thus frequency rounding cannot produce a uniform approximate invariant unless an additional quantitative U/D bound is supplied. The numerical control will use r=2+sqrt(2)/10^9 with exact algebraic arithmetic, not infer irrationality from a floating string.

## 6. Finite errors and conditional energy consequences

The surviving character is still multiplied by exp(2 pi i sum_i w_i dot e_i). No error bound is supplied here. If e is allowed to range freely over R^(3N), any observed finite phase vector is compatible with G=U=D=b=n=0 by setting e equal to a representative. Therefore no nonzero physical residual or positive energy lower bound follows from the algebraic cancellation alone. That is an identification limit, not an assertion that actual receiver error is unbounded.

For a separately supplied error set E, its exact projected set is W(E), modulo one. A symmetric absolute bound eta_W=sup_{e in E}|sum_i w_i dot e_i| gives

    circular_distance(observed contrast,signal contrast)
       <=min(eta_W,1/2).                            (I)

For independent endpoint boxes |e_ij|<=epsilon_ij, eta_W=sum_ij |w_ij|epsilon_ij is sharp, since signed endpoint errors attain it. Shared endpoint weights must be combined as W before taking absolute values. If this box projection has eta_W>=1/2, it covers the entire output circle and this scalar character alone supplies no phase exclusion. General correlated errors require their actual projected set, not a chosen box or covariance.

At r=2, the primitive generator has l1 norm 7963685544. A two-endpoint difference has l1 norm 15927371088. Equal independently bounded endpoint errors require epsilon<1/31854742176 cycles merely for the worst-case scalar box to cover less than the full unit circle. This is a synthetic algebraic threshold, not an instrument noise requirement established from data, and not a proof that the route is unusable. Large weights may also amplify the signal. A smaller real normalization cannot change the relevant dimensionless error-to-period ratio.

If a separate physical model supplies a bounded real field functional L_W with squared dual norm sigma_W^2 and Hilbert norm N, then, for the specified baseline-subtracted observation theta,

    N >= max(dist(theta,Z)-eta_W,0)^2/sigma_W^2.

The usual zero-response compatibility condition is required when sigma_W=0. An energy conversion Ephysical>=qN requires a separately supplied positive q. This mathematical inequality neither chooses a state nor supplies eta_W, the physical response map, or q. It is included only to explain the consequence of a valid finite-error supplier.

## 7. Scope retained and next evidence needed

Everything above is conditional on phase in cycles, matched emission endpoints, the supplied k ratios, shared U/D variables within each endpoint, independent U/D across endpoints, exact carrier values, fixed receiver vector within a supplied segment, and the stated leading transfer law. The precheck derives the character conditions; it does not derive that physical model or justify its applicability to archived records.

A useful next physical supplier would establish actual common synthesis/retarded maps and commensurability, or quantitative restricted plasma/history/error information that permits an approximate or non-character route. A raw decimal, an assumed initial state, a minimum-energy lift or an unvalidated real normalization is not that supplier. No full-radio-tracking impossibility is claimed.
