#!/usr/local/bin/python3
"""Independent exact channel-quotient controls; no author source or raw data."""
from fractions import Fraction as F
from math import gcd, lcm, floor
from functools import reduce
from pathlib import Path
import json, hashlib, datetime
import sympy as s

OUT=Path(__file__).resolve().parent
K=(F(880,749),F(3344,749),F(14,15))
P,Q,C=3007586755,-305348069,-2325375360
checks=[]
def check(name,ok,**detail):checks.append(dict(name=name,passed=bool(ok),**detail))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def centered(x,period=F(1)):
    x,period=F(x),F(period)
    return x-period*floor(x/period+F(1,2))
def exact_rational(value):
    if not isinstance(value,(int,F,s.Rational)):
        raise TypeError('An exact rational premise is required; no float rationality inference')
    return F(value)
def prescribed(r):
    r=exact_rational(r)
    if r<=0:raise ValueError('positive ratio required')
    h=gcd(r.denominator,abs(C));L=r.denominator//h
    return (L*P,L*Q,C*r.numerator//h)
def columns(r,x=F(1)):
    r,x=F(r),F(x)
    return ([k*x for k in K[:2]]+[K[2]*r*x],
            [k/x for k in K[:2]]+[K[2]/(r*x)],
            [1/(k*x) for k in K[:2]]+[1/(K[2]*r*x)])
def cross_primitive(r):
    # Separate direct two-column determinant construction, with independent
    # denominator clearing and gcd reduction; no use of P,Q,C here.
    _,a,d=columns(r)
    v=(a[1]*d[2]-a[2]*d[1],a[2]*d[0]-a[0]*d[2],a[0]*d[1]-a[1]*d[0])
    den=lcm(*(z.denominator for z in v));iv=[int(den*z) for z in v]
    common=gcd(*iv);iv=[z//common for z in iv]
    if iv[0]<0:iv=[-z for z in iv]
    return tuple(iv)
def admissible(weights,ratios,xs=None):
    xs=[F(1)]*len(ratios) if xs is None else xs
    return (all(all(isinstance(z,int) for z in w) for w in weights)
            and all(dot(w,columns(r,x)[1])==dot(w,columns(r,x)[2])==0 for w,r,x in zip(weights,ratios,xs))
            and all(sum(w[j] for w in weights)==0 for j in range(3)))
def rational_kernel_samples(ratios):
    # Nullspace vectors span the real kernel. Integer clearing gives valid sample
    # characters; this function does NOT claim a saturated integer-lattice basis.
    if not ratios:return []
    vs=[prescribed(r) for r in ratios]
    mat=s.Matrix([[v[0] for v in vs],[v[2] for v in vs]])
    samples=[]
    for row in mat.nullspace():
        den=lcm(*(int(z.q) for z in row));m=[int(z*den) for z in row]
        samples.append([tuple(mi*z for z in v) for mi,v in zip(m,vs)])
    return samples

g,u,v=s.gcdex(P,Q)
check('first_pair_Bezout',int(g)*P+int(u)*Q==int(v)==1)
check('first_nuisance_identity',P*K[0]+Q*K[1]+C*K[2]==0)
check('second_nuisance_identity',F(P)/K[0]+F(Q)/K[1]+F(C)/K[2]==0)
check('signal_constant_identity',C*K[2]==-2170350336)
ratios=[F(1),F(2),F(3,2),F(4,9),F(1,7),F(47,53),F(13,128),F(749,880),F(10**9+7,10**9+9)]
primitive_rows=[]
for i,r in enumerate(ratios):
    w=prescribed(r);direct=cross_primitive(r);gg,aa,dd=columns(r,F(i+1,3))
    lam=F(w[0],P)
    check('direct_primitive_'+str(i),w==direct and gcd(*w)==1)
    check('direct_annihilation_'+str(i),dot(w,aa)==dot(w,dd)==0)
    check('direct_signal_'+str(i),dot(w,gg)==lam*C*K[2]*F(i+1,3)*(r*r-1))
    primitive_rows.append({'ratio':str(r),'generator':list(w),'lambda_min':str(lam)})
for name,value in [('float_ratio',1.5),('near_integer_float',2.0),('symbolic_irrational',s.sqrt(2))]:
    try:prescribed(value)
    except TypeError:check(name+'_not_rationalized',True)
    else:check(name+'_not_rationalized',False)
try:prescribed(0)
except ValueError:check('zero_ratio_rejected',True)
else:check('zero_ratio_rejected',False)

# Algebraic rational/irrational fixture: split exact Q(sqrt(2)) columns into
# their two rational coordinates. Rank three forces every rational weight zero.
root=s.sqrt(2)
ks=[s.Rational(z.numerator,z.denominator) for z in K]
for i,r in enumerate([root,2+root/s.Integer(10**9),s.Rational(3,2)+root/s.Integer(10**12)]):
    a=[ks[0],ks[1],ks[2]/r];d=[1/ks[0],1/ks[1],1/(ks[2]*r)]
    rows=[]
    for column in [a,d]:
        expr=[s.expand(s.radsimp(z)) for z in column]
        irr=[z.coeff(root) for z in expr];rat=[s.simplify(z-root*t) for z,t in zip(expr,irr)]
        check('quadratic_split_rational_'+str(i)+'_'+str(len(rows)),all(z.is_Rational for z in rat+irr))
        rows.extend([rat,irr])
    check('irrational_annihilator_zero_'+str(i),s.Matrix(rows).rank()==3)

fixtures=[([F(2)],0,False),([F(2),F(2)],1,True),([F(1),F(1)],1,False),
          ([F(2),F(3)],0,False),([F(1),F(1),F(2)],1,False),
          ([F(1),F(2),F(2)],1,True),([F(2),F(3),F(4)],1,True),
          ([F(2),F(2),F(3)],1,True),([F(1),F(1),F(2),F(3)],2,True),
          ([F(3,7),F(5,11),F(13,17)],1,True)]
for i,(rs,rank,signal_exists) in enumerate(fixtures):
    samples=rational_kernel_samples(rs)
    check('receiver_kernel_rank_'+str(i),len(samples)==rank)
    check('receiver_kernel_valid_'+str(i),all(admissible(w,rs) for w in samples))
    signal=any(any(dot(wi,columns(r)[0])!=0 for wi,r in zip(w,rs)) for w in samples)
    check('nonzero_history_signal_'+str(i),signal==signal_exists)
    for label,xs in [('constant',[F(1)]*len(rs)),('varying',[F(j+1) for j in range(len(rs))])]:
        actual=any(sum(dot(wi,columns(r,x)[0]) for wi,r,x in zip(w,rs,xs))!=0 for w in samples)
        row=s.Matrix([[1]*len(rs),rs]);z=[x*(r*r-1) for x,r in zip(xs,rs)]
        predicted=row.col_join(s.Matrix([z])).rank()>row.rank()
        check('constant_G_rowspan_'+str(i)+'_'+label,actual==predicted)

# Two different exact rational ratios do NOT cancel arbitrary receiver phases.
w2,w3=prescribed(F(2)),prescribed(F(3))
bad=[w2,tuple(-z for z in w3)];residual=[sum(w[j] for w in bad) for j in range(3)]
b=[F(0),F(0),F(1,2*residual[2])]
check('changing_two_endpoint_receiver_failure',not admissible(bad,[F(2),F(3)]) and dot(residual,b)==F(1,2))

# A direct forward phase fixture, independent per-endpoint U,D and arbitrary b,n.
rs=[F(2),F(3),F(4)];xs=[F(1),F(2),F(3)];lambdas=[1,-2,1]
W=[tuple(lam*z for z in prescribed(r)) for lam,r in zip(lambdas,rs)]
G=[F(3,7),F(-2,11),F(5,13)];U=[F(5,17),F(7,19),F(-11,23)];D=[F(13,29),F(-17,31),F(19,37)]
b=[F(23,41),F(-29,43),F(31,47)];M=2**32
ns=[[M+3,-M-5,11],[-17,2*M+19,-23],[29,-31,3*M+37]]
phis=[]
for r,x,gi,ui,di,ni in zip(rs,xs,G,U,D,ns):
    cg,ca,cd=columns(r,x)
    phis.append([cg[j]*gi+ca[j]*ui+cd[j]*di+b[j]+ni[j] for j in range(3)])
theta=sum(dot(w,p) for w,p in zip(W,phis))
signal=sum(dot(w,columns(r,x)[0])*gi for w,r,x,gi in zip(W,rs,xs,G))
check('three_ratio_character_exists',admissible(W,rs,xs))
check('direct_forward_model_character',centered(theta)==centered(signal))
stored=[[p%M for p in row] for row in phis]
check('native_M_wrap_preserves_character',centered(sum(dot(w,p) for w,p in zip(W,stored)))==centered(signal))
for i in range(3):
    for name,column in [('uplink',1),('downlink',2)]:
        delta=columns(rs[i],xs[i])[column]
        check('arbitrary_independent_'+name+'_'+str(i),dot(W[i],delta)*F(97,101)==0)
count_weights=[tuple(-sum(W[i][j] for i in range(edge+1)) for j in range(3)) for edge in range(2)]
count_theta=sum(dot(w,[stored[i+1][j]-stored[i][j] for j in range(3)]) for i,w in enumerate(count_weights))
check('count_rewrite_exact',count_theta==sum(dot(w,p) for w,p in zip(W,stored)))
check('constant_G_distinct_ratio_signal',sum(dot(w,columns(r)[0]) for w,r in zip(W,rs))==2*C*K[2]!=0)

# Correct lattice scaling, and a failure witness for period-one normalization.
normal=[F(z,P) for z in w2]
check('normalized_row_wrong_unit_period',centered(normal[1])!=0)
check('normalized_row_correct_period',centered(normal[1],F(1,P))==0)
check('normalized_period_exact',gcd(*w2)==1 and F(1,P)>0)

# Near-rational exact algebraic frequency error can leave arbitrary plasma phase.
r=2+root/s.Integer(10**9)
a=[ks[0],ks[1],ks[2]/r];d=[1/ks[0],1/ks[1],1/(ks[2]*r)]
wa=s.simplify(sum(s.Integer(w2[j])*a[j] for j in range(3)))
wd=s.simplify(sum(s.Integer(w2[j])*d[j] for j in range(3)))
check('near_ratio_u_leak_exact',s.simplify(wa-C*ks[2]*(2/r-1))==0 and wa!=0)
check('near_ratio_d_leak_exact',s.simplify(wd-C/ks[2]*(2/r-1))==0 and wd!=0)
Ubad=1/(2*wa)
check('near_ratio_halfcycle_witness',s.simplify(wa*Ubad)==s.Rational(1,2))

# Exact endpoint-box error amplification, without selecting a physical budget.
flat=[z for row in W for z in row];norm1=sum(abs(z) for z in flat)
eps=F(1,10**13);err=[eps*(1 if z>0 else -1 if z<0 else 0) for z in flat]
eta=norm1*eps
check('box_support_attained',dot(flat,err)==eta and all(abs(z)<=eps for z in err))
check('small_box_circular_error',eta<F(1,2) and abs(centered(dot(flat,err)))==eta)
critical=F(1,2*norm1)
for i,t in enumerate([F(-1,2),F(-1,3),F(0),F(1,7),F(1,2)]):
    er=[2*t*critical*(1 if z>0 else -1 if z<0 else 0) for z in flat]
    check('halfcycle_box_covers_target_'+str(i),all(abs(z)<=critical for z in er) and dot(flat,er)==t)
pair=[tuple(-z for z in w2),w2];pairnorm=sum(abs(z) for row in pair for z in row)
check('pair_weight_norm',sum(abs(z) for z in w2)==7963685544 and pairnorm==15927371088)
check('pair_circle_threshold',F(1,2*pairnorm)==F(1,31854742176))
check('scale_error_ratio_invariant',eta/F(1)==(eta/P)/F(1,P))

# Without a supplied real-error restriction even zero G explains arbitrary data.
observed=[[F(1,7),F(2,11),F(-3,13)],[F(5,17),F(-7,19),F(11,23)]]
zeroG_errors=[row[:] for row in observed]
check('unrestricted_error_zero_signal_witness',all(observed[i][j]==zeroG_errors[i][j] for i in range(2) for j in range(3)))

# Conditional one-coordinate Hilbert fixture: energy norm is h^2, response supplied.
response=dot(w2,columns(F(2))[0]);h=F(1,10*abs(response));sigma2=response*response
for label,error in [('zero',F(0)),('finite',F(1,100)),('covers_circle',F(1,2))]:
    value=response*h+7
    lower=max(abs(centered(value))-error,F(0))**2/sigma2
    check('conditional_energy_'+label,lower<=h*h and (label!='zero' or lower==h*h))

result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'classification':'Independent exact/synthetic controls frozen after independent derivation, before author-source exposure',
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'precheck_sha256':hashlib.sha256((OUT/'PRECHECK_v1.md').read_bytes()).hexdigest(),
        'target_sha256':hashlib.sha256((OUT/'TARGET_CONTRACT_SOURCE_v1.json').read_bytes()).hexdigest(),
        'checks':checks,'counts':{'total':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},
        'primitive_examples':primitive_rows,'changing_ratio_fixture':{'ratios':[str(r) for r in rs],'weights':W,'count_weights':count_weights,'signal_phase_mod_one':str(centered(signal))},
        'error_fixture':{'pair_l1_norm':pairnorm,'uniform_pair_error_circle_threshold':str(F(1,2*pairnorm))},
        'author_sources_accessed':[],'raw_data_accessed':False}
with (OUT/'INDEPENDENT_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result['counts']))
if not all(x['passed'] for x in checks):raise SystemExit(1)
