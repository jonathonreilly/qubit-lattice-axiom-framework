# RSR post-freeze source and artifact correspondence v1

No discrepancy remains in the assigned comparison: all 1,200 corrected-I/Q record digests, all scalar header values and spare bytes, and the requested conditional ADC-cell summaries agree with the frozen independent extraction. This is a focused source/artifact check on exposed development data, not physical phase validation or formal audit. The original independent report, reader, result and preaccess/result identities remain unchanged.

## Source and artifact coverage

After freezing FINAL_IDENTITY_v1.json at 869f984541def9f9103a5063462243a52aa337343fae70af3434c7c6a190f10b, I read the complete author rsr_development_v2.py, its complete difference from v1, the complete saved result and digest list, and every row of both compressed header ledgers. Exact source/output snapshots are under author_sources_v1. No author module was imported or executed; no raw packed file was decoded again. The comparison imported only my own unchanged pre-exposure scalar cell implementation and used its frozen corrected sample arrays.

| Compared author artifact | SHA-256 |
| --- | --- |
| rsr_development_v2.py | a796ec36fbbf1247353555e4f9e6ffd8f4c2022040c80bb833d43f710070141c |
| RSR_WINDOW_DIGESTS_v1.json | 404103e8c376de30b7a38a3e58e4ccebd19c6c755c095ce4583cec909e332a9b |
| X_HEADERS_v1.jsonl.gz | 64cc4ea2933b1fefc1a2b53d11a4974159f134e65cb0f48b4dbcea87bb5177c2 |
| KA_HEADERS_v1.jsonl.gz | 237c9b49a5e7cd708949a5814ee3d91e2571e32a9640404ad5e435c779f15a10 |
| RSR_DEVELOPMENT_RESULTS_v1.json | a83031876f0d04482510caa9ae26d15f5b464886d39617221b30363784acbe92 |

The author uses vectorized unsigned-word extraction and explicit signed conversion; my independent path uses scalar struct/integer parsing. The two paths agree on Q/I halfword order, least-significant-first packed time order, sign extension, 2k+1 centering, and big-endian signed 32-bit I-then-Q output serialization. The author's int32 arithmetic covers all corrected 16-bit endpoints without overflow. Metadata units are consistent: header rate 1 means 1,000 complex samples/second, and the stored model frequency fields are not used to rephase the compared sample arrays.

## Exhaustive header and digest correspondence

All 8,941 header rows per product match the independent row indices. Each has exactly the expected 71 header fields. All 1,251,740 scalar field values match; IEEE doubles were compared after packing to their exact binary64 bytes, not with a numerical tolerance. All 17,882 sixteen-byte spare blocks also match: the author stores each as one unsigned integer, while I retain the sixteen component bytes, and the conversion is lossless on every row. Thus no unnamed spare or status field was omitted from the comparison.

The complete header histograms, file identities, first/last times, rate/resolution and selected counts agree. Every one of the 600 window records in each band has the same time/station/uplink key and corrected-I/Q digest. All 1,200 corresponding hardware-error flags agree. The independent all-header inventory found no duplicate grids or time/sequence discontinuities; there are no unmatched window records. The author's window-key convention omits SPC but the actual products have one identical SPC and separately checked rate/resolution, so there is no ambiguity on these pinned files. Different RSR IDs are retained as channel metadata.

The source does not filter samples by error flag or amplitude. Unsupported widths, duplicate selected timestamps, unequal grids or an incorrect payload/rate relation cause explicit rejection rather than preferred-row selection. The added 1-kilosample/second guard restricts the fixed 1- and 1,000-sample lag diagnostic. These facts describe the checked implementation and inputs; they are not a generic claim that every possible damaged RSR product is fully recoverable.

## Conditional angle-cell summaries

From the frozen independent corrected arrays I reevaluated only the requested amplitudes and lower/upper/width statistics using my scalar corner formula. The formula and 19/-5 endpoint signs were already fixed before raw access. The comparison criterion was fixed before this correspondence execution: absolute tolerances of 1e-9 code units for amplitude quantiles and 1e-12 cycles for the angle summaries. These are floating implementation tolerances, not physical uncertainties. No threshold was adjusted after comparison.

All five quantiles at 0, .01, .5, .99 and 1 agree. The largest amplitude discrepancy is 7.275957614183426e-12 code units. The largest angle discrepancy is 2.7755575615628914e-17 cycles, in the width maximum. Complete values, differences and tolerances are in AUTHOR_CORRESPONDENCE_RESULTS_v1.json. Every summary contains all 600,000 pairs. Both implementations find zero extreme codes and zero origin-touching cells in the selected data, and no full-circle character cell under the supplied ideal transfer law.

The author marks all origin-touching cells invalid, while my independent proof identifies the exact angle limits for their nonzero-voltage subset and separately states that zero analog voltage has undefined phase. This is a conservative domain policy, not a numerical disagreement: no selected sample encounters it, and the author's output reports invalid-cell counts rather than hiding them. For the finite cells, its atan2 numerator/denominator are algebraically the same corner cross/dot products as the independent proof. The character endpoints use 19*lX-5*hK and 19*hX-5*lK, including the required reversal for the negative coefficient.

Both source and output explicitly make the ideal unsaturated midrise law additional to the documented 2k+1 correction. The cell concerns total analog voltage, not the carrier alone; lack of extreme codes is not a clipping-history certificate. The correction does not establish physical carrier phase or a thermal/electronics noise bound.

## Version history and remaining scope

I verified that v1 to v2 changes only the deterministic gzip wrapper, four pinned raw/label hash guards and the 1-kilosample/second guard. The scientific saved result changes in exactly four leaves: the two output header paths and their compressed hashes. Both decompressed header ledgers and the entire record-digest list are byte-identical across versions. AUTHOR_VERSION_CORRESPONDENCE_v1.json and the exact source diff preserve that check. The original v1 evidence was not relabeled as v2.

I read the source portions that write the NCO diagnostic and compute the baseband lags for scope. I did not independently recompute the lag distributions, derive a phase-restoration convention, resolve the 0 versus 0.5 millisecond model argument, or verify a sky-phase/carrier calibration. The checked output correctly states physical_sky_phase_restored=false and zero independent empirical tests. Its circular diagnostics must remain baseband quantities on the nominal recorded grid. No scalar/gravity residual, physical noise floor, state, action or scale follows from this comparison.

The correspondence execution exited 0 in 2.2506376248784363 seconds with empty stderr. It performed no raw-decoding rerun and no author-code import. Only independent_rsr_v1 was written; original independent evidence and all root files remain unchanged. This supplement and AUTHOR_CORRESPONDENCE_IDENTITY_v1.json are separate from the original pre-exposure result freeze.
