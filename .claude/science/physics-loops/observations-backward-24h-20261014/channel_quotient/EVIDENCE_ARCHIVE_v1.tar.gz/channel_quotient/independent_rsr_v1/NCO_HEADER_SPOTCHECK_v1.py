"""Post-exposure exact first-three-join check from original independent headers.
No raw extraction, author import, all-row aggregate, or physical calibration.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib, itertools, json

HERE = Path(__file__).resolve().parent
WT = HERE.parents[5]

def ident(p):
    b=p.read_bytes()
    return {"path": str(p), "bytes":len(b), "sha256":hashlib.sha256(b).hexdigest()}

def main():
    schema_file=HERE/"PRIMARY_LABEL_SCHEMA_v1.json"
    schema=json.loads(schema_file.read_text())
    names={r["NAME"]:r["COLUMN_NUMBER"]-1 for r in schema}
    author_file=WT/"outputs/scalar_channel_calibration/NCO_CONTINUITY_RESULTS_v1.json"
    author=json.loads(author_file.read_text())
    records=[]
    for band,stem in [("X","1a1"),("KA","1b1")]:
        ledger=HERE/(stem+"_HEADERS_v1.jsonl")
        with ledger.open() as stream:
            first=[json.loads(line) for line in itertools.islice(stream,4)]
        vals=[r["header_values_by_column_1_to_71"] for r in first]
        def field(v,name): return Q(v[names[name]])
        for j,(old,new) in enumerate(zip(vals,vals[1:])):
            assert field(new,"SFDU SECOND")-field(old,"SFDU SECOND")==1
            oldp=[field(old,"SUB-CHANNEL PHASE COEF P"+str(k)) for k in range(1,5)]
            newp=[field(new,"SUB-CHANNEL PHASE COEF P"+str(k)) for k in range(1,5)]
            # Expand P_old(1+s) first, independently of the author's evaluator.
            coeff=[field(new,"SUB-CHANNEL ACCUMULATED PHASE")-field(old,"SUB-CHANNEL ACCUMULATED PHASE")+newp[0]-sum(oldp),
                   newp[1]-oldp[1]-2*oldp[2]-3*oldp[3],
                   newp[2]-oldp[2]-3*oldp[3],
                   newp[3]-oldp[3]]
            for pos,s in enumerate([Q(0),Q(1,2000)]):
                value=((coeff[3]*s+coeff[2])*s+coeff[1])*s+coeff[0]
                claimed=Q(author["products"][band]["tests"][pos]["first_three_exact"][j])
                assert value==claimed
                records.append({"band":band,"old_record":j,"new_record":j+1,
                                "shift_seconds":str(s),"join_polynomial_coefficients_cycles":[str(x) for x in coeff],
                                "exact_cycles":str(value),"float_cycles":float(value),"author_exact_match":True})
    result={"scope":"Only first three adjacent joins per band at both supplied shifts; 12 exact checks. Reuses original independent decoded header bytes; no new raw decode and no all-join rerun.",
            "units":"cycles; s in seconds relative to each recorded integer-second origin",
            "arithmetic":"exact rationals for stored binary64 header numbers; not exact physical oscillator phase",
            "physical_phase_identification":False,"fit_or_wrapping_used_in_checked_join":False,
            "inputs":[ident(schema_file),ident(HERE/"1a1_HEADERS_v1.jsonl"),ident(HERE/"1b1_HEADERS_v1.jsonl"),ident(author_file)],
            "checks":records,"checks_passed":len(records)}
    target=HERE/"NCO_HEADER_SPOTCHECK_RESULTS_v1.json"
    with target.open("x") as f: f.write(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"checks_passed":len(records),"result_sha256":ident(target)["sha256"]}))

if __name__=="__main__":main()
