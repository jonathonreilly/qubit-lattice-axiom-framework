#!/usr/bin/env python3
"""Compare author artifacts to frozen independent headers/IQ. No raw decoder rerun."""
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
AUTHOR = Path('/Users/jonBridger/.codex/campaigns/observations-backward-24h-20261014/rsr_development_outputs_v2')
IDENTITY = json.loads((OUT/'FINAL_IDENTITY_v1.json').read_text())
for item in IDENTITY['reviewer_files']:
    assert hashlib.sha256((OUT/item['filename']).read_bytes()).hexdigest() == item['sha256']

# Import only the checker's pre-exposure implementation, never the author's.
spec = importlib.util.spec_from_file_location('independent_original_rsr', OUT/'independent_rsr_reader_v1.py')
independent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(independent)
schema = independent.SCHEMA
own = json.loads((OUT/'RESULTS_v1.json').read_text())
author = json.loads((AUTHOR/'RSR_DEVELOPMENT_RESULTS_v1.json').read_text())
digests = json.loads((AUTHOR/'RSR_WINDOW_DIGESTS_v1.json').read_text())
checks = {'all_scalar_header_values':0,'spare_block_values':0,'window_record_digests':0,'window_error_flags':0}
header_results = []
independent_window = []

for tag, label, record_source in [('1a1','X',own['files'][0]),('1b1','KA',own['files'][1])]:
    with (OUT/f'{tag}_HEADERS_v1.jsonl').open() as f:
        own_headers = [json.loads(line) for line in f]
    with gzip.open(AUTHOR/f'{label}_HEADERS_v1.jsonl.gz','rt') as f:
        root_headers = [json.loads(line) for line in f]
    assert len(own_headers)==len(root_headers)==8941
    for ours,theirs in zip(own_headers,root_headers):
        assert ours['record_index_0based']==theirs['record_index']
        assert set(theirs)=={col['NAME'] for col in schema[:-1]}|{'record_index'}
        for col,value in zip(schema[:-1],ours['header_values_by_column_1_to_71']):
            other = theirs[col['NAME']]
            if 'ITEMS' in col:
                assert bytes(value)==int(other).to_bytes(col['BYTES'],'big')
                checks['spare_block_values']+=1
            elif col['DATA_TYPE']=='IEEE_REAL':
                assert struct.pack('>d',value)==struct.pack('>d',other), (tag,ours['record_index_0based'],col['NAME'])
                checks['all_scalar_header_values']+=1
            else:
                assert value==other, (tag,ours['record_index_0based'],col['NAME'])
                checks['all_scalar_header_values']+=1
    for key,hist in author['products'][len(header_results)]['histograms'].items():
        col_index=next(j for j,col in enumerate(schema) if col['NAME']==key)
        expected=Counter(str(row['header_values_by_column_1_to_71'][col_index]) for row in own_headers)
        assert dict(expected)==hist
    with (OUT/f'{tag}_WINDOW_RECORDS_v1.jsonl').open() as f:
        window = [json.loads(line) for line in f]
    assert len(window)==len(digests)==600
    root_band='X' if label=='X' else 'Ka'
    for ours,theirs in zip(window,digests):
        assert theirs['key']==[ours['year'],ours['doy'],ours['sfdu_seconds'][0]/ours['sfdu_seconds'][1],ours['station'],ours['uplink_band']]
        assert theirs[root_band+'_corrected_iq_sha256']==ours['corrected_iq_sha256']
        assert theirs[root_band+'_error_count']==ours['header_error_count']
        checks['window_record_digests']+=1;checks['window_error_flags']+=1
    assert author['products'][len(header_results)]['sha256']==record_source['source']['sha256']
    assert author['products'][len(header_results)]['record_count']==8941
    assert author['products'][len(header_results)]['window_records']==600
    header_results.append({'channel':root_band,'records':8941,'scalar_columns_per_record':70,'spare_bytes_per_record':16,'exact_scalar_values_match':True,'all_spare_bytes_match':True,'window_digests':600})
    independent_window.append(window)

assert author['matched_window_records']==600 and author['sample_count']==600000
assert not author['X_unmatched_keys'] and not author['Ka_unmatched_keys']
assert author['character']==[19,-5] and author['physical_sky_phase_restored'] is False
assert author['independent_empirical_tests']==0
assert author['flags']=={'X_extreme_code':0,'X_origin_reaching':0,'Ka_extreme_code':0,'Ka_origin_reaching':0}
assert author['ADC_complete_circle_count']==author['ADC_invalid_cell_count']==0

# Only reevaluate the requested derived summaries from the frozen corrected arrays.
# No original RSR file is opened, and no author callable is executed.
iqx=(OUT/'1a1_WINDOW_IQ_i32be_v1.bin').read_bytes()
iqk=(OUT/'1b1_WINDOW_IQ_i32be_v1.bin').read_bytes()
ampx=[];ampk=[];lower=[];upper=[];width=[]
for (ix,qx),(ik,qk) in zip(struct.iter_unpack('>ii',iqx),struct.iter_unpack('>ii',iqk)):
    lx,hx=independent.cell_angles(ix,qx)
    lk,hk=independent.cell_angles(ik,qk)
    lo=(19*lx-5*hk)/(2*math.pi);hi=(19*hx-5*lk)/(2*math.pi)
    ampx.append(math.sqrt(ix*ix+qx*qx));ampk.append(math.sqrt(ik*ik+qk*qk))
    lower.append(lo);upper.append(hi);width.append(hi-lo)
assert len(lower)==600000


def describe(a):
    a=sorted(a);answer=[]
    # Same declared p*(N-1) linear statistic; independent scalar implementation.
    for p in [0,.01,.5,.99,1]:
        x=p*(len(a)-1);j=math.floor(x);k=min(j+1,len(a)-1);f=x-j
        answer.append(a[j]*(1-f)+a[k]*f)
    return answer


numeric=[]
for name,values,tolerance in [
    ('X_corrected_amplitude',ampx,1e-9),
    ('Ka_corrected_amplitude',ampk,1e-9),
    ('character_ADC_lower_error_cycles',lower,1e-12),
    ('character_ADC_upper_error_cycles',upper,1e-12),
    ('character_ADC_width_cycles',width,1e-12),
]:
    expected=describe(values);got=author[name]['quantiles_0_01_50_99_100']
    assert author[name]['finite']==600000 and len(got)==5
    differences=[abs(a-b) for a,b in zip(expected,got)]
    assert max(differences)<=tolerance,(name,differences)
    numeric.append({'name':name,'independent':expected,'author':got,'max_absolute_difference':max(differences),'absolute_comparison_tolerance':tolerance,'interpretation':'Floating arithmetic correspondence only, not an observational error budget.'})

frozen_width=own['cross_channel']['ideal_character_width_cycles']['values']
recomputed_width=describe(width)
for q,value in zip(['0','1/100','1/2','99/100','1'],recomputed_width):
    assert abs(value-frozen_width[q])<1e-12

result={'scope':'Post-freeze complete 1200 record-digest and all scalar-header correspondence; conditional ADC summary comparison from frozen independent IQ only.','checks':checks,'headers':header_results,'numeric_comparisons':numeric,'raw_decoding_reruns':0,'author_code_imports':0,'retained_origin_domain_difference':'Author marks all origin-touching cells invalid. Independent proof gives exact nonzero-voltage angle limits while separately excluding undefined zero voltage. No selected sample touches the origin, so outputs coincide.','out_of_scope':'No independent recomputation of baseband lag statistics or NCO/sky-phase reconstruction; their code was read for scope only. No physical calibration inference.','source':{'author_v2_sha256':hashlib.sha256((OUT.parent/'rsr_development_v2.py').read_bytes()).hexdigest(),'author_results_sha256':hashlib.sha256((AUTHOR/'RSR_DEVELOPMENT_RESULTS_v1.json').read_bytes()).hexdigest(),'original_independent_identity_sha256':hashlib.sha256((OUT/'FINAL_IDENTITY_v1.json').read_bytes()).hexdigest()}}
with (OUT/'AUTHOR_CORRESPONDENCE_RESULTS_v1.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
