#!/usr/bin/env python3
"""Independent metadata-driven RSR reader. Standard library only; no author imports."""
from array import array
import calendar
from collections import Counter, defaultdict
from datetime import date
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import struct

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
RUNTIME = Path('/Users/jonBridger/.codex/campaigns/observations-backward-24h-20261014')
SCHEMA = json.loads((OUT/'PRIMARY_LABEL_SCHEMA_v1.json').read_text())
MANIFEST = json.loads((PACK/'RSR_RAW_SOURCE_MANIFEST_v1.json').read_text())
PROTOCOL = json.loads((PACK/'RSR_PREACCESS_PROTOCOL_v1.json').read_text())
START, STOP = Fraction(48900), Fraction(49500)
YEAR, DOY, RECORD_BYTES, HEADER_BYTES = 2002, 169, 4260, 260


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def frac(value):
    return [value.numerator, value.denominator]


def header(record):
    result = []
    for col in SCHEMA[:-1]:
        a = col['START_BYTE']-1
        field = record[a:a+col['BYTES']]
        typ = col['DATA_TYPE']
        if typ == 'CHARACTER':
            value = field.decode('ascii', errors='backslashreplace')
        elif typ == 'IEEE_REAL':
            assert len(field) == 8
            value = struct.unpack('>d', field)[0]
            if not math.isfinite(value):
                value = {'nonfinite': repr(value), 'raw_hex': field.hex()}
        elif 'ITEMS' in col:
            stride = col['ITEM_OFFSET']; length = col['ITEM_BYTES']
            value = [int.from_bytes(field[j*stride:j*stride+length], 'big', signed=typ=='MSB_INTEGER') for j in range(col['ITEMS'])]
        else:
            value = int.from_bytes(field, 'big', signed=typ=='MSB_INTEGER')
        result.append(value)
    assert len(result) == 71
    return result


def unpack_payload(payload, bits):
    """Return I,Q signed centered values, earliest packed sample first."""
    assert bits in (1, 2, 4, 8, 16) and len(payload) % 4 == 0
    mask = (1 << bits)-1
    sign = 1 << (bits-1)
    modulus = 1 << bits
    for (word,) in struct.iter_unpack('>I', payload):
        qword, iword = word >> 16, word & 65535
        for shift in range(0, 16, bits):
            i = (iword >> shift) & mask
            q = (qword >> shift) & mask
            if i & sign:
                i -= modulus
            if q & sign:
                q -= modulus
            yield 2*i+1, 2*q+1


def cell_slopes(a, b):
    assert isinstance(a, int) and isinstance(b, int) and a % 2 and b % 2
    values = []
    origin_corner = False
    for x in (a-1, a+1):
        for y in (b-1, b+1):
            if x == y == 0:
                origin_corner = True
                continue
            den = a*x+b*y
            assert den > 0
            values.append(Fraction(a*y-b*x, den))
    return min(values), max(values), origin_corner


def cell_angles(a, b):
    angles = []
    for x in (a-1, a+1):
        for y in (b-1, b+1):
            if x or y:
                angles.append(math.atan2(a*y-b*x, a*x+b*y))
    return min(angles), max(angles)


def synthetic_controls():
    checks = []
    assert list(unpack_payload(bytes.fromhex('807fff00'), 8)) == [(1,255),(-1,-255)]
    checks.append('explicit_8bit_Q2_Q1_I2_I1_order')
    assert list(unpack_payload(bytes.fromhex('ffff8000'), 16)) == [(-65535,-1)]
    checks.append('explicit_16bit_sign_and_IQ_output_order')
    for bits in (1,2,4,8,16):
        n = 16//bits
        low, high = -(1 << (bits-1)), (1 << (bits-1))-1
        desired_i = ([low, high, -1, 0]*16)[:n]
        desired_q = ([high, low, 0, -1]*16)[:n]
        iword = sum((v % (1 << bits)) << (j*bits) for j,v in enumerate(desired_i))
        qword = sum((v % (1 << bits)) << (j*bits) for j,v in enumerate(desired_q))
        got = list(unpack_payload(struct.pack('>HH',qword,iword),bits))
        assert got == list(zip([2*v+1 for v in desired_i],[2*v+1 for v in desired_q]))
        checks.append(f'signed_packing_{bits}bit')
    examples = [(1,1),(3,1),(101,101),(-1,1),(1,-1),(-1,-1),(-7,3),(3,-9),(21,13)]
    points = 0
    for a,b in examples:
        lo,hi,origin = cell_slopes(a,b)
        for ix in range(9):
            for iy in range(9):
                x,y = Fraction(a-1)+Fraction(ix,4),Fraction(b-1)+Fraction(iy,4)
                if not x and not y:
                    assert origin
                    continue
                slope = (a*y-b*x)/(a*x+b*y)
                assert lo <= slope <= hi
                points += 1
        angles = cell_angles(a,b)
        assert abs(angles[0]-math.atan(float(lo))) < 1e-15
        assert abs(angles[1]-math.atan(float(hi))) < 1e-15
        if a*a+b*b > 2:
            disk = math.asin(math.sqrt(2/(a*a+b*b)))
            assert max(abs(angles[0]),abs(angles[1])) <= disk+1e-15
        checks.append(f'exact_corner_and_rational_grid_{a}_{b}')
    assert cell_slopes(1,1) == (Fraction(-1),Fraction(1),True)
    assert cell_slopes(3,1) == (Fraction(-1,3),Fraction(1,2),False)
    assert cell_slopes(101,101) == (Fraction(-1,101),Fraction(1,101),False)
    lo,hi = cell_angles(101,101)
    joint = (19*lo-5*hi,19*hi-5*lo)
    assert abs(joint[0]+24*math.atan(1/101)) < 1e-15
    assert abs(joint[1]-24*math.atan(1/101)) < 1e-15
    lo,hi = cell_angles(1,1)
    assert abs((19*hi-5*lo)-(19*lo-5*hi)-12*math.pi) < 1e-13
    checks += ['three_exact_corner_oracles','character_negative_coefficient_endpoints','small_cell_full_character_circle']
    return {'checks':checks,'passed':len(checks),'rational_grid_nonzero_points':points,
            'phase_defined_only_for_nonzero_analog_voltage':True,
            'ideal_midrise_unsaturated_law_is_supplied':True}


def ceil_fraction(x):
    return -((-x.numerator)//x.denominator)


def histogram_summary(counter):
    keys = sorted(counter)
    result = {'distinct':len(keys)}
    if len(keys) <= 32:
        result['all_values_with_counts'] = [{'value':json.loads(k),'count':counter[k]} for k in keys]
    else:
        result['all_values_preserved_in_header_ledger'] = True
    return result


def read_product(entry):
    path = Path(entry['path'])
    raw = path.read_bytes()
    assert len(raw) == entry['bytes'] == RECORD_BYTES*8941
    assert sha(raw) == entry['sha256']
    tag = path.suffix[1:]
    output_names = {k:OUT/f'{tag}_{v}' for k,v in [('headers','HEADERS_v1.jsonl'),('samples','WINDOW_IQ_i32be_v1.bin'),('records','WINDOW_RECORDS_v1.jsonl')]}
    counters = [Counter() for _ in SCHEMA[:-1]]
    anomalies = []
    all_grid = defaultdict(list)
    windows = []
    seen_time = defaultdict(list)
    previous = None
    constants = {1:'NJPL',2:'2',3:'I',5:'C997',6:0,7:4240,8:1,9:232,10:2,11:4,12:21,13:4,15:0,16:104,17:220,70:10,71:4000}
    aggregate = {'selected_records':0,'selected_samples':0,'sum_I':0,'sum_Q':0,'sum_I2':0,'sum_Q2':0,'sum_IQ':0,'potential_clipped_samples':0,'origin_touching_ideal_cells':0}
    limits = {'I_min':None,'I_max':None,'Q_min':None,'Q_max':None,'norm2_min':None,'norm2_max':None}
    header_writer = output_names['headers'].open('x')
    sample_writer = output_names['samples'].open('xb')
    record_writer = output_names['records'].open('x')
    for index in range(8941):
        record = raw[index*RECORD_BYTES:(index+1)*RECORD_BYTES]
        values = header(record)
        get = lambda n: values[n-1]
        reasons = []
        for n,expected in constants.items():
            if get(n) != expected:
                reasons.append({'field':n,'expected':expected,'actual':get(n)})
        for n,v in enumerate(values,1):
            counters[n-1][json.dumps(v,sort_keys=True,allow_nan=False)] += 1
            if isinstance(v,dict) and 'nonfinite' in v:
                reasons.append({'field':n,'nonfinite':v})
        bits,rate,seconds = get(42),get(44)*1000,get(49)
        valid_grid = isinstance(seconds,(int,float)) and math.isfinite(seconds) and bits in (1,2,4,8,16) and rate>0 and 0<=get(71)<=RECORD_BYTES-HEADER_BYTES and get(71)%4==0
        time = Fraction.from_float(seconds) if isinstance(seconds,float) and math.isfinite(seconds) else Fraction(seconds) if isinstance(seconds,int) else None
        absolute = None
        try:
            if time is not None:
                assert 1<=get(48)<=365+int(calendar.isleap(get(47)))
                absolute = Fraction((date(get(47),1,1).toordinal()+get(48)-1)*86400)+time
        except (ValueError,AssertionError):
            reasons.append({'invalid_calendar':[get(47),get(48)]})
            valid_grid = False
        if absolute is not None:
            if not 0<=time<=86400:
                reasons.append({'UTC_second_outside_documented_range':frac(time)})
            tkey = (get(47),get(48),time)
            if seen_time[tkey]:
                reasons.append({'duplicate_time_prior_records':seen_time[tkey].copy()})
            seen_time[tkey].append(index)
            if previous is not None:
                if absolute-previous['absolute'] != 1:
                    reasons.append({'nominal_time_step_not_one_second':frac(absolute-previous['absolute'])})
                if get(21) != (previous['sequence']+1)%65536:
                    reasons.append({'record_sequence_discontinuity':[previous['sequence'],get(21)]})
                if [rate,bits] != previous['rate_bits']:
                    reasons.append({'sample_grid_configuration_changed':[previous['rate_bits'],[rate,bits]]})
            previous = {'absolute':absolute,'sequence':get(21),'rate_bits':[rate,bits]}
        if not valid_grid:
            reasons.append({'unsupported_or_invalid_sample_grid':True})
        if get(43):
            reasons.append({'hardware_error_count':get(43)})
        if get(35):
            reasons.append({'frequency_override_flag':get(35)})
        count = get(71)//4*(16//bits) if valid_grid else None
        if valid_grid and Fraction(count,rate) != 1:
            reasons.append({'nominal_payload_duration_not_one_second':frac(Fraction(count,rate))})
        key = (get(22),get(23),get(47),get(48),time,rate,bits) if valid_grid else None
        if key is not None:
            all_grid[key].append(index)
        row = {'record_index_0based':index,'raw_record_sha256':sha(record),'raw_header_hex':record[:HEADER_BYTES].hex(),'header_values_by_column_1_to_71':values,'anomalies':reasons}
        header_writer.write(json.dumps(row,separators=(',',':'),allow_nan=False)+'\n')
        if reasons:
            anomalies.append({'record_index_0based':index,'findings':reasons})
        if not valid_grid or get(47)!=YEAR or get(48)!=DOY:
            continue
        lower = max(0,ceil_fraction((START-time)*rate))
        upper = min(count,ceil_fraction((STOP-time)*rate))
        if upper <= lower:
            continue
        pairs = []
        clipped = []
        peak_code = (1 << bits)-1
        payload = record[HEADER_BYTES:HEADER_BYTES+get(71)]
        for j,(i,q) in enumerate(unpack_payload(payload,bits)):
            if j < lower or j >= upper:
                continue
            pairs.append((i,q))
            if abs(i)==peak_code or abs(q)==peak_code:
                clipped.append(j)
            aggregate['sum_I']+=i;aggregate['sum_Q']+=q;aggregate['sum_I2']+=i*i;aggregate['sum_Q2']+=q*q;aggregate['sum_IQ']+=i*q
            aggregate['origin_touching_ideal_cells']+=int(abs(i)==abs(q)==1)
            norm2=i*i+q*q
            for k,v in [('I_min',i),('I_max',i),('Q_min',q),('Q_max',q),('norm2_min',norm2),('norm2_max',norm2)]:
                if limits[k] is None or (v<limits[k] if k.endswith('_min') else v>limits[k]):limits[k]=v
        assert len(pairs)==upper-lower
        corrected = b''.join(struct.pack('>ii',i,q) for i,q in pairs)
        offset = sample_writer.tell();sample_writer.write(corrected)
        wr = {'record_index_0based':index,'year':get(47),'doy':get(48),'sfdu_seconds':frac(time),'station':get(23),'spc':get(22),'rsr':get(24),'subchannel':get(25),'uplink_band':get(29),'downlink_band':get(30),'tracking_mode':get(31),'uplink_station':get(32),'bits':bits,'samples_per_second':rate,'header_error_count':get(43),'override_flag':get(35),'sample_indices_half_open':[lower,upper],'selected_samples':len(pairs),'corrected_iq_sha256':sha(corrected),'corrected_binary_offset':offset,'potential_clipped_sample_indices':clipped,'first_four_corrected_IQ':pairs[:4],'last_four_corrected_IQ':pairs[-4:]}
        record_writer.write(json.dumps(wr,separators=(',',':'))+'\n')
        windows.append({'key':key+(lower,upper),'record':index,'bytes':corrected,'bits':bits,'clipped':set(clipped),'lower':lower})
        aggregate['selected_records']+=1;aggregate['selected_samples']+=len(pairs);aggregate['potential_clipped_samples']+=len(clipped)
    header_writer.close();sample_writer.close();record_writer.close()
    duplicates = [{'year':k[0],'doy':k[1],'seconds':frac(k[2]),'records':v} for k,v in seen_time.items() if len(v)>1]
    summaries = [{'column':i+1,'name':SCHEMA[i]['NAME'],**histogram_summary(x)} for i,x in enumerate(counters)]
    result = {'source':entry,'headers_decoded':8941,'all_header_columns_decoded':71,'aggregate':{**aggregate,**limits},'header_histogram_summary':summaries,'anomalies':anomalies,'duplicate_times':duplicates,'products':{k:{'filename':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for k,p in output_names.items()}}
    dump(OUT/f'{tag}_SUMMARY_v1.json',result)
    return result,windows,all_grid


def quantiles(values):
    if not values:return None
    data=sorted(values)
    result={}
    for q in (Fraction(0),Fraction(1,100),Fraction(1,2),Fraction(9,10),Fraction(99,100),Fraction(1)):
        x=q*(len(data)-1);lo=x.numerator//x.denominator;hi=min(lo+1,len(data)-1);f=float(x-lo)
        result[str(q)]=data[lo]*(1-f)+data[hi]*f
    return {'method':'linear interpolation at p*(N-1), floating descriptive values','count':len(data),'values':result}


def cross_channel(left,right,left_grid,right_grid):
    lm,rm=defaultdict(list),defaultdict(list)
    for record in left:lm[record['key']].append(record)
    for record in right:rm[record['key']].append(record)
    keys=sorted(set(lm)&set(rm))
    unpaired={'left':[x['record'] for k in lm.keys()-rm.keys() for x in lm[k]],'right':[x['record'] for k in rm.keys()-lm.keys() for x in rm[k]]}
    widths=array('d');radii=array('d');phase=array('d')
    pair_rows=[];unknown=0;full=0;origin=0;total=0
    for key in keys:
        for l in lm[key]:
            for r in rm[key]:
                n=len(l['bytes'])//8;assert len(r['bytes'])==len(l['bytes']);record_widths=[];bad=[]
                for j,((ix,qx),(ik,qk)) in enumerate(zip(struct.iter_unpack('>ii',l['bytes']),struct.iter_unpack('>ii',r['bytes']))):
                    total+=1
                    phase.append(math.remainder(19*math.atan2(qx,ix)-5*math.atan2(qk,ik),2*math.pi)/(2*math.pi))
                    if j+l['lower'] in l['clipped'] or j+r['lower'] in r['clipped']:
                        bad.append(j);unknown+=1;continue
                    lx,hx=cell_angles(ix,qx);lk,hk=cell_angles(ik,qk)
                    lo,hi=19*lx-5*hk,19*hx-5*lk
                    width=(hi-lo)/(2*math.pi);radius=max(abs(lo),abs(hi))/(2*math.pi)
                    widths.append(width);radii.append(radius);record_widths.append(width)
                    full+=int(width>=1)
                    origin+=int((abs(ix)==abs(qx)==1) or (abs(ik)==abs(qk)==1))
                pair_rows.append({'left_record_0based':l['record'],'right_record_0based':r['record'],'samples':n,'potential_clipped_pair_sample_indices':bad,'ideal_character_width_cycles_min':min(record_widths) if record_widths else None,'ideal_character_width_cycles_max':max(record_widths) if record_widths else None})
    with (OUT/'MATCHED_WINDOW_RECORDS_v1.jsonl').open('x') as f:
        for row in pair_rows:f.write(json.dumps(row,separators=(',',':'))+'\n')
    return {'all_header_common_grid_keys':len(set(left_grid)&set(right_grid)),'all_header_unmatched_left_records':[v for k,vs in left_grid.items() if k not in right_grid for v in vs],'all_header_unmatched_right_records':[v for k,vs in right_grid.items() if k not in left_grid for v in vs],'all_header_duplicate_grid_keys_left':sum(len(v)>1 for v in left_grid.values()),'all_header_duplicate_grid_keys_right':sum(len(v)>1 for v in right_grid.values()),'window_common_grid_keys':len(keys),'window_cartesian_record_pairs':len(pair_rows),'window_unpaired':unpaired,'sample_pairs':total,'pairs_without_ideal_cell_due_to_extreme_code':unknown,'pairs_with_origin_touching_conditional_cell':origin,'full_circle_character_cells':full,'ideal_character_width_cycles':quantiles(widths),'ideal_max_absolute_character_error_cycles':quantiles(radii),'raw_baseband_character_cycles':quantiles(phase),'raw_phase_scope':'atan2 at corrected code centers, modulo one; not unwrapped, sky/carrier/calibrated phase or physical noise','cell_scope':'Supplied unsaturated ideal rectangle and nonzero analog voltage only; clipping flags retained; no thermal/carrier inference.'}


def main():
    freeze=json.loads((OUT/'PREACCESS_FREEZE_v1.json').read_text())
    for item in freeze['reviewer_files']:
        assert sha((OUT/item['filename']).read_bytes())==item['sha256']
    for item in freeze['metadata_inputs']:
        assert sha(Path(item['path']).read_bytes())==item['sha256']
    assert PROTOCOL['analysis_window']=={'year':YEAR,'doy':DOY,'start_utc_second_inclusive':48900,'stop_utc_second_exclusive':49500}
    assert PROTOCOL['frozen_character']==[19,-5]
    controls=synthetic_controls();dump(OUT/'SYNTHETIC_CONTROLS_v1.json',controls)
    decoded=[read_product(entry) for entry in MANIFEST['products']]
    paired=cross_channel(decoded[0][1],decoded[1][1],decoded[0][2],decoded[1][2])
    result={'independence':'Reader frozen before raw access and before author source/results; stdlib struct/int path; no author import.','controls':controls,'files':[x[0] for x in decoded],'cross_channel':paired,'independent_empirical_tests':0,'physical_noise_bounds':0,'fits':0,'scope':'Both full files exposed development. Headers all records; payload decoding only predeclared UTC window. Exact per-record corrected I/Q hashes.'}
    dump(OUT/'RESULTS_v1.json',result)
    print(json.dumps({'controls_passed':controls['passed'],'files':[{'source':x[0]['source']['path'],'headers':x[0]['headers_decoded'],'aggregate':x[0]['aggregate'],'anomalies':len(x[0]['anomalies']),'duplicates':len(x[0]['duplicate_times'])} for x in decoded],'cross_channel':paired},indent=2))


if __name__=='__main__':
    main()
