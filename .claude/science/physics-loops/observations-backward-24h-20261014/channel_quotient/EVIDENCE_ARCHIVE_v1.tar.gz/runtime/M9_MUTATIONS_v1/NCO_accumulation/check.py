from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('m',Path(__file__).with_name('mutated.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=m.run(Path(__file__).with_name('outputs'))
assert [t['shift_seconds'] for t in result['products']['X']['tests']]==['0','1/2000'],'NCOargument'
assert result['products']['X']['tests'][0]['exact_residual_identity_sha256']=='9b3ffb17ecd701e4bbd6b65ff3eb7898253e67e1bac44a2eae0cb326dfb4a24d','NCOidentity'
