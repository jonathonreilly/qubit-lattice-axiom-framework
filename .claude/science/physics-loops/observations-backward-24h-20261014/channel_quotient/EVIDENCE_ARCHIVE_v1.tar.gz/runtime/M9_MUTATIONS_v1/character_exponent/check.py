from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('m',Path(__file__).with_name('mutated.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.controls()
