# Growth/lensing reconstruction — working derivation

Direct author: root. Begun 2026-10-15. This is unfinished conditional research,
not a canonical note, formal audit, or observational parameter fit.

## Exact target and new content

M12 requires an ideal physical history F(t). This block asks whether the
supplied revised scalar's geometric coupling can instead be tested against
lensing and matter velocities without supplying the density perturbation's
initial amplitude, its integration constant, the absolute matter density,
or an F trajectory. The new proposed mechanism is an integrated dust identity
plus the candidate's coupling chart. It is not another receiver correction.

Target: given the explicitly defined ideal functions below, derive the full
set of compatible candidate shape parameters, with rank failures and poles
excluded; use separate epochs/observables to test that set. No uniqueness is
presumed. Passing these necessary reduced equations does not establish the
full background action, its potential, its initial state, or its environment.

Prior art: Amendola et al., arXiv:1210.0439v2, derives observable ratios and
the slip reconstruction. Those ideas are credited, not new here. Its literal
P2 convention is twice the E_G convention used in ACT arXiv:2405.12795v2.
The candidate-specific finite-epoch inverse below is the proposed new step.
Main bbada1fe09b2d10d610560864d86b68c24a59713 is unchanged from M12. Refined
repository searches are saved; the earlier broad E_G search was polluted by
identifier substrings and supplies no absence claim. The finite-mode scalar
inverse on main is a local prescribed-density inverse, not this cosmological
initial-density elimination. The old single-ratio FRW inverse uses a fixed
matter+radiation+Lambda surface, not the present supplied scalar chart.

## Premises and observation definitions

Use Jordan metric ds²=−(1+2Psi)dt²+a²(1−2Phi)dx², N=ln a, H>0,
E=H/H0, physical wave number K=k_com/a. Prime means d/dN at fixed k_com.
The flat-background, linear, pressureless, conserved matter model is supplied.
Galaxy/matter velocity equality, deterministic linear bias cancellation,
common-mode correlations, geometrical calibration, and deprojection into
time and wave number are separate observational bridges. The construction
does not obtain them from a summary E_G estimate.

In the subhorizon dust reduction used here, R=delta', with R nonzero on the
interval, and R'+(2+E'/E)R=−K²Psi/H². The neglected 3Phi' term and any velocity
bias must have an independent error bound before physical use. Define

    L=−a³ K²(Phi+Psi)/(3H0²),  P=L/R,  P3=R'/R.

P is E_G in the ACT normalization. No absolute normalization of delta or R
is required. For real coherent growing-sector tests below take P>0,R>0;
the algebra generalizes only with explicit nonzero denominators.

For the one propagating conformal scalar on the radial candidate branch,
the leading frozen-coefficient quasistatic equations are the *supplied
reduced field model*:

    −2F K²Phi=delta_rho−K²delta_F,
    −2F K²Psi=delta_rho+K²delta_F,
    (K²+m²)delta_F=q delta_rho,  F>0, q>0, m²>=0.

They give Weyl source −K²(Phi+Psi)=delta_rho/F and

    r=(Psi−Phi)/(Psi+Phi)=q K²/(K²+m²).

This sign agrees with Phi−Psi=delta_F/F. The algebra is exact for this
reduced system; its physical replacement of the dynamical scalar equation
is not exact. A homogeneous scalar oscillation need not be negligible just
because K/H is large. Its exclusion, time-variation errors and the actual
effective mass are open. We do not identify a fitted pole with V_FF.

Eliminating the potential amplitudes using the dust equation gives

    r_obs=2 E² a³ (P3+2+E'/E)/(3P)−1.

This is the known observable-slip construction in the stated convention.
Two distinct K² values x1,x2 with finite positive r1,r2 allow

    1/r=b0+b1/x,
    b0=(x1/r1−x2/r2)/(x1−x2), q=1/b0, m²=b1/b0.

Require b0>0,b1>=0 and test additional scales. A zero/negative r, absent
intercept, extra propagating mode or non-quasistatic residual needs a
different branch; it is not silently fitted. Exact equal positive r at
distinct scales corresponds to m²=0 in this family. Finite noisy scales do
not determine an asymptote without a model and uncertainties.

## Candidate chart and the initial-density elimination

Write beta=alpha² in (1/4,1/3), with candidate kappa=(1−2sqrt(1−3beta))/3
in (0,1/3). M12 supplies the checked conditional geometric identity

    q=beta(F−Fc)/(F−3beta Fc),   Fc>0, F>Fc,
    Z_beta(q)=F/Fc=beta(1−3q)/(beta−q),  0<q<beta.

Here q is geometric scalar coupling, NOT M12's background q_rec in a
nonradial history. A radial background is an explicit hypothesis for this
single-scalar reduction; M12's whole-interval equality test can independently
challenge it. No equality at two epochs proves radial truncation.

Let rho=rho0 a^−3 and B=rho0/(3H0² Fc)>0. Weyl sourcing yields

    P R = B delta/Z_beta.

Using delta'=R, obtain the integrated identity

    [Z_beta P R]_{N0}^{Ni} = B Integral_{N0}^{Ni} R dN.             (G1)

Choose Rhat(N0)=1 and Rhat=exp(Integral P3 dN); the unknown common R
normalization cancels from (G1). There is no chosen delta(N0) in the test.
It can be reconstructed after parameters are fixed, up to the same amplitude.
Differentially, (Z_beta P)'+P3 Z_beta P=B. For arbitrary F instead of this
candidate chart, (F P R)'=rho0 R/(3H0²) leaves an integration constant;
the candidate structure, not a general observation theorem, is what restricts it.

For three ordered epochs N0<N1<N2, let Ii=Integral Rhat, I0=0 and
ti=Pi Rhat_i(1−3qi). Eliminate B between two instances of (G1):

    C0/(beta−q0)+C1/(beta−q1)+C2/(beta−q2)=0,
    C0=t0(I2−I1), C1=−t1 I2, C2=t2 I1.

After multiplying the three denominators the polynomial is

    Q(beta)=Sum_i Ci Product_{j!=i}(beta−qj).                     (G2)

Its degree is at most two, not necessarily exactly two. A nonzero Q has
at most two real candidate betas. Keep only beta in (max(1/4,q_i),1/3),
positive B from (G1), and all other domain/epoch constraints. A root at a pole
is invalid. If Q is identically zero there is no finite-candidate conclusion.
For constant q and compatible data the identity can leave a continuum of
beta values; it is a real rank failure, not a choice of preferred beta.

Each surviving candidate predicts (G1) at a fourth epoch and at other modes
with the same beta and B. Calibration epochs and later synthetic test epochs
will be separated explicitly. No primitive, minimum-selection rule or fitted
answer supplies the choice among surviving roots.

## Cross-domain check and remaining absolute scale

If an independently calibrated, unscreened cosmological tensor distance
ratio is available, M12 gives D_i=dL_GW/dL_EM=sqrt(Fobs/Fi). Thus
T=Fj/Fi=Di²/Dj². Define U=T(1−3qi)/(1−3qj). Then

    beta=(U qj−qi)/(U−1),                                     (G3)

provided U!=1 and the domains hold. Local endpoint screening or generation
calibration invalidates that observational identification; equal local F at
the endpoints can erase sensitivity to cosmological F. This is a conditional
extra discriminator, not a claim that GW170817 supplies it.

Once beta,B are identified, F/Fc and rho/Fc are reconstructed, with
rho/Fc=3H0²B a^−3. The transformation (F,Fc,rho0,Q0)->lambda times themselves
preserves this reduced data. Absolute Fc is not derived. Feeding relative
histories into M12's background metric identities can test the radial
kinetic equality and potential basis, potentially recovering dimensionless
nu and Hv/H0, but those checks are a further obligation and are not performed
merely by satisfying (G1). Initial background state and framework action
selection likewise remain open.

## Competing routes and falsifiers

1. Integrated candidate inverse (G2): primary attempt; avoids derivative of
   P or q and the density integration constant. Fails honestly at rank loss,
   invalid chart, or disagreement at later epochs/scales.
2. Unrestricted F reconstruction: gives an explicit integration-constant
   family; useful as a counterfactual showing where candidate selection enters.
3. Tensor-ratio closure (G3): independent conditional discriminator; local
   endpoint and generation suppliers remain required.
4. Full dynamical perturbation inversion: live alternative when quasistatic
   error cannot be bounded. This block does not claim it impossible.

Actual ACT+BOSS summary values are exposed development context. No continuous
P3 or time derivative map has yet been admitted; no fitted scalar parameter,
GR rejection or independent empirical holdout is reported.
