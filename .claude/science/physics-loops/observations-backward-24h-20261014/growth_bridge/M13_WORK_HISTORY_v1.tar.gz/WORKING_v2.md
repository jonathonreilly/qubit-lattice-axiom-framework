# Growth reconstruction: exact ambiguities and conservation correction

Root, 2026-10-15. Supplement to immutable WORKING_v1, not yet canonical.
The v1 48 manufactured histories passed 259 controls. Four retained two
admissible shape roots after the fourth epoch. This is preserved as an
identifiability result; no selector chooses the generating root.

## Physical dust velocity and the exact conservation identity

In the conventions of v1, define the positive dimensionless dust velocity
divergence W=-div(v)/(aH). Linear dust conservation gives

    delta'=W+3Phi',
    W'+(2+h)W=-K^2 Psi/H^2, h=H'/H.

Use P=L/W and P3=W'/W. The Euler reconstruction of r in v1 is unchanged.
Normalize the same mode by W0!=0: What=W/W0, Phihat=Phi/W0, with What0=1.
One may obtain What=exp(integral P3) on its positive, nonzero interval. Define

    J(N)=integral What dN+3[Phihat(N)-Phihat(N0)].

Then delta/W0=J+C, with an undetermined integration constant C. Under the
same supplied reduced Weyl equation as v1,

    Z_beta(q) P What = B(J+C), B=rho0/(3H0^2 Fc)>0.          (1)

The potentials in J must have the same mode normalization as What. They can
be reconstructed algebraically from the ideal Weyl and Euler readouts:

    Phihat=-3 H0^2 a^-3 P What (1-r)/(2K^2).

Thus no independent selection of the initial density or absolute mode amplitude
is needed. The coefficient of the metric correction is 3, not zero. Equation
(1) follows from exact linear dust conservation plus the *conditional reduced*
Weyl source. It does not make the scalar/metric quasistatic equations exact.
The v1 formulas are its leading-continuity specialization Phi'=0; v1 data
must not be relabelled as an exact relativistic perturbation solution.

If instead L=b delta/F+epsilon_L, b=rho0/(3H0^2), the exact endpoint residual
is [F P W]-b[integral W+3 Delta Phi]=[F epsilon_L]. With known endpoint
bounds |epsilon_L,i|<=e_i, its magnitude is at most F_i e_i+F_0 e_0.
Neither these physical errors nor errors in velocities, time and calibration
are estimated by this algebra. A nonconstant velocity gain is not a harmless
mode normalization.

Replace I by J in v1's three-epoch quadratic. Use distinct J values, with a
nonzero chosen J difference when reconstructing B. The full interval tests
do not require J to be increasing. A local description q=q(J) requires
nonconstant J and, for a differentiable inverse, J'!=0 on the subinterval;
W!=0 alone does not guarantee that. Positive P,What,Z,B implies J+C>0.

## A second exact implementation: the linear lift

The focused mathematical checker independently proposed the following lift.
Root is checking it directly rather than counting it as an independent
author derivation. Let u=1/beta, v=1/B and w=u C. Rearranging (1) gives

    [1, -J q, -q, -P What(1-3q)] . [C,u,w,v] = -J.         (2)

Four full-rank rows give one possible lifted tuple. It must also obey
w=u C, 3<u<4, v>0, q<1/u, and all interval/data/model gates. Failure of the
nonlinear compatibility w=u C is a candidate rejection; ignoring it would
enlarge the model. Rank loss does not establish uniqueness or failure of the
theory. The quadratic and this lift provide genuinely different algebraic
implementations of the same conditional constraint.

## Classification of the surviving two-shape ambiguity

Let a real interval have positive P,What and 0<q<min(beta1,beta2), with
beta1!=beta2 in (1/4,1/3). Suppose both tuples (beta_j,B_j,C_j) satisfy (1)
throughout it. Put A_j=B_j/beta_j. Cancelling the common P What(1-3q) gives

    A1(beta1-q)(J+C1)=A2(beta2-q)(J+C2).

The coefficient A1(J+C1)-A2(J+C2) cannot vanish at a point: if it did,
the equality and beta1!=beta2 would force their common value to be zero,
contrary to positive B_j and J+C_j. Consequently

    q(J)=[A1 beta1(J+C1)-A2 beta2(J+C2)] /
          [A1(J+C1)-A2(J+C2)].                            (3)

This is a necessary fractional-linear (Möbius) form. If q is nonconstant,
the determinant of that form is nonzero. Therefore any non-Möbius q(J)
has at most one interval-compatible tuple in beta, conditional on this
reduced model and calibrated input functions. This is not a finite-noise
uniqueness theorem; derivatives and approximate Möbius behavior can be
ill-conditioned.

Conversely suppose candidate 1 is valid and q=(u0 J+v0)/(w0 J+x0), with
u0*x0-v0*w0!=0 and denominator nonzero on the observed interval. A second
distinct finite shape can exist only when

    beta2=(v0-u0 C1)/(x0-w0 C1),
    C2=(beta1 x0-v0)/(beta1 w0-u0),
    B2=B1 (beta2/beta1) (beta1 w0-u0)/(beta2 w0-u0).        (4)

All denominators and physical gates are mandatory. The apparent evaluation
q(-C1) is algebraic continuation of a rational function, not a claim about
an observed epoch or a zero physical density. If x0-w0 C1=0 or
beta1 w0-u0=0, the would-be second solution is not a finite positive-B tuple.
To prove sufficiency, substitute (4) into the common quadratic numerator
after multiplying by w0 J+x0. Its factors exchange the roots -C1 and the
zero of beta1-q. Necessity follows by divisibility of that quadratic by
beta2-q. No other distinct beta can occur. Constant q is separate: for
compatible affine P What in J, all admissible beta rescale B and survive.

For v1's ambiguous profiles, J=N, q=9/50-N/25 and C1=2, so beta2=13/50.
When beta1=29/100 or 8/25, B2=B1 beta2/beta1 and
C2=25(beta1-9/50)>0. Both give exactly the same P,What,q over any common
positive-chart interval. A fourth epoch cannot break this exact ambiguity.
They are two reduced readout assignments, not two established solutions of
the full candidate action or its cosmological background.

An independent tensor ratio with genuinely cosmological endpoint calibration
would distinguish them at two different q values. For fixed distinct qi,qj,
the candidate ratio Z_beta(qj)/Z_beta(qi) is injective in beta away from poles:
its candidate inversion is v1 equation G3. If the physical local endpoints
do not measure cosmological F, that proposed additional observable is absent.

## Returning to the background field equations

This step is personally derived from the complete M12 metric identities.
Let Z=F/Fc, Y=E^2, h=H'/H and omega=(1/q-3)/2 for the radial candidate.
Use spatially flat conserved dust and the same B as (1). Dividing the second
metric equation by Fc H^2 gives the necessary kinetic residual

    -2Z h -3B a^-3/Y -Z''+(1-h)Z'-omega Z'^2/Z=0.         (5)

Equivalently, without dividing by Z',

    (2Z+Z')Y'/2+[Z''-Z'+omega Z'^2/Z]Y+3B a^-3=0.        (6)

For each fixed mode, Euler gives

    Y'/2+(P3+2)Y=(3/2)P a^-3(1+r).                     (7)

Let L1=2Z+Z', L0=Z''-Z'+omega Z'^2/Z and D=P3+2. Eliminating Y' gives

    (L0-L1 D)Y+a^-3[(3/2)L1 P(1+r)+3B]=0.              (8)

This is another candidate gate from a different part of the same supplied
model. If its Y coefficient is nonzero it determines a *necessary* Y; that
function must still satisfy (7), not merely be defined by (8). Zero coefficients
need explicit consistency/rank treatment. An actually measured E(N) can
instead test (5) directly. At constant Z the scalar equation is not recovered
from Bianchi, so the nonzero-F' membership theorem cannot be invoked.

For completeness the relative potential on a flat background is

    V/(Fc H0^2)=Z(3Y+Y'/2)-3B a^-3/2
                +Y Z''/2+Y' Z'/4+(5/2)Y Z'.           (9)

Let k=(1-2sqrt(1-3beta))/3, Q/Fc=4beta/(1+k), and take M12's supplied
potential basis B0(q;beta),B1(q;beta). Then

    [V/(Fc H0^2)]/Z^2 = ell B0+tau B1,
    ell=2(Hv/H0)^2/(Q/Fc)>0, tau=ell nu>0.              (10)

Two independent basis rows calibrate ell,tau; all other times test them.
Combined with the nonzero-F' and full matter premises in M12, exact interval
identities can establish conditional background membership. They do not
validate the quasistatic perturbation closure, its effective mass, a physical
initial state, or the fundamental action choice. Absolute Fc remains free
under the simultaneous F,Fc,rho0,Q0 rescaling. A fitted Hv/H0 is a dimensionless
calibration, not a derivation of an absolute scale or hierarchy.

## Empirical boundary and current execution boundary

Root read the entire independent primary-source report. ACT/BOSS values are
projected, correlated, finite-bin estimators with RSD, bias, fiducial-distance,
transfer and magnification premises. They do not supply the ideal continuous
P3, deprojected common-mode time series or physical F required here. The
factor-two dictionary P_1210=2 E_G is verified against primary papers.
No source posterior, raw map, survey fit, scalar parameter or independent
empirical holdout has been acquired. The legitimate later route is a prediction
through the actual survey windows and joint likelihood, whose exact numerical
release has not yet been admitted. Missing arrays in a bounded search are
not evidence that no public release exists.

The extended mathematical controls and background tests are being implemented;
the 259 v1 controls do not certify these new equations. All failures, including
any manufactured-history rejection by full background closure, must remain
visible. This supplement does not replace the original v1 evidence.
