"""Root-authored exact supplement; original 259-control result is immutable."""
from pathlib import Path
import hashlib
import json
import sympy as s
from growth_inverse_v2 import (coupling_shape as Zshape, integrated_inverse,
    lift_inverse, tensor_inverse, background_residual, relative_potential)

HERE = Path(__file__).resolve().parent


def run():
    checks = []
    def check(name, passed, detail=None):
        checks.append({'name':name,'passed':bool(passed),'detail':detail})
    def zero(name, expr):
        expr = s.factor(s.cancel(expr))
        check(name, expr == 0, str(expr))
    def refusal(name, call):
        try:
            call()
            check(name, False, 'invalid inputs accepted')
        except ValueError as error:
            check(name, True, str(error))

    N = s.Symbol('N', real=True)
    beta, B, C = s.Rational(29,100), s.Rational(1,5), s.Integer(2)
    epochs = [0,s.Rational(1,4),s.Rational(1,2),s.Rational(3,4),s.Integer(1)]
    # q is non-Mobius in J=N, giving a genuinely full-rank comparison.
    q = s.Rational(2,25)+N/30+N**2/100
    P = B*(N+C)/Zshape(beta,q)
    rows = [{'q':q.subs(N,n),'P':P.subs(N,n),'W':1,'J':n} for n in epochs]
    inverse = integrated_inverse(rows[:3]); lift = lift_inverse(rows[:4])
    check('quadratic_includes_generating_tuple', {'beta':beta,'B':B,'C':C} in inverse['candidates'])
    check('independent_lift_rank_four', lift['rank']==4, lift)
    check('lift_exact_recovery', lift['candidate']=={'beta':beta,'B':B,'C':C})
    check('fifth_row_consistency', lift_inverse(rows)['status']=='admitted')
    altered = [dict(x) for x in rows[:4]]; altered[3]['P'] *= s.Rational(101,100)
    check('linear_fit_requires_nonlinear_compatibility',
          lift_inverse(altered)['status']=='nonlinear_incompatibility', lift_inverse(altered))
    # The algebra permits a decreasing primitive as well as increasing one.
    decreasing = [{**x,'J':-x['J']} for x in rows[:3]]
    check('negative_density_slope_not_accepted',integrated_inverse(decreasing)['candidates']==[])
    shifted = [{**x,'J':x['J']+7} for x in rows[:3]]
    check('primitive_origin_does_not_select_state',
          {'beta':beta,'B':B,'C':C-7} in integrated_inverse(shifted)['candidates'])
    # Independent reviewer witness: accepted by v1, refused by v2.
    bad = [{'q':s.Rational(-1,10),'P':s.Rational(27,26),'W':1,'J':0},
           {'q':s.Rational(-39,400),'P':s.Rational(5365,4136),'W':1,'J':s.Rational(1,4)},
           {'q':s.Rational(-19,200),'P':s.Rational(1599,1028),'W':1,'J':s.Rational(1,2)}]
    refusal('negative_q_reported_witness',lambda:integrated_inverse(bad))
    for value in [s.Integer(0),s.Rational(-1,10),s.Rational(1,3),s.oo,s.nan,s.I]:
        changed = [{**x,'q':value} for x in rows[:3]]
        refusal('invalid_q_quadratic_'+str(value),lambda changed=changed:integrated_inverse(changed))
        refusal('invalid_q_tensor_'+str(value),lambda value=value:tensor_inverse(value,s.Rational(1,10),2))
    refusal('tensor_nonpositive_ratio',lambda:tensor_inverse(s.Rational(1,10),s.Rational(1,9),0))
    refusal('equal_q_tensor_rank',lambda:tensor_inverse(s.Rational(1,10),s.Rational(1,10),1))
    refusal('repeated_primitive',lambda:integrated_inverse([rows[0],rows[0],rows[2]]))
    # Exact Möbius second solution, including a nonzero denominator slope.
    x,u,v,w,z,bb,Bb,Cc=s.symbols('x u v w z bb Bb Cc')
    qr=(u*x+v)/(w*x+z)
    b2=(v-u*Cc)/(z-w*Cc)
    C2=(bb*z-v)/(bb*w-u)
    B2=Bb*b2/bb*(bb*w-u)/(b2*w-u)
    flux=Bb*(x+Cc)/Zshape(bb,qr)
    zero('general_second_tuple_sufficiency',Zshape(b2,qr)*flux-B2*(x+C2))
    a1,a2,b1,b2s,c1,c2=s.symbols('a1 a2 b1 b2 c1 c2')
    qnecessary=(a1*b1*(x+c1)-a2*b2s*(x+c2))/(a1*(x+c1)-a2*(x+c2))
    zero('mobius_necessity_cross_multiply',a1*(b1-qnecessary)*(x+c1)-a2*(b2s-qnecessary)*(x+c2))
    exceptional=[]
    for btrue in [s.Rational(29,100),s.Rational(8,25)]:
        qr=s.Rational(9,50)-N/25
        pp=B*(N+C)/Zshape(btrue,qr)
        other=s.Rational(13,50); otherB=B*other/btrue
        otherC=25*(btrue-s.Rational(9,50))
        zero('interval_ambiguity_'+str(btrue),Zshape(other,qr)*pp-otherB*(N+otherC))
        rr=[{'q':qr.subs(N,n),'P':pp.subs(N,n),'W':1,'J':n} for n in epochs]
        got=integrated_inverse(rr[:3])
        check('two_exact_roots_'+str(btrue),len(got['candidates'])==2,got['candidates'])
        check('ambiguous_lift_has_rank_loss_'+str(btrue),lift_inverse(rr)['status']=='rank_failure')
        qi,qj=qr.subs(N,0),qr.subs(N,1)
        ratios=[s.factor(Zshape(b, qj)/Zshape(b,qi)) for b in [btrue,other]]
        check('tensor_ratios_differ_'+str(btrue),ratios[0]!=ratios[1],ratios)
        check('tensor_recovers_both_when_ratio_supplied_'+str(btrue),
              [tensor_inverse(qi,qj,T) for T in ratios]==[btrue,other])
        exceptional.append({'beta1':btrue,'beta2':other,'B2':otherB,'C2':otherC,'tensor_ratios':ratios})
    constant=[{'q':s.Rational(1,10),'P':1+n,'W':1,'J':n} for n in epochs[:3]]
    check('constant_q_continuum_branch',integrated_inverse(constant)['rank_failure'])
    # Exact linear-dust kinematic identity; isolated, not a full gravity solution.
    W=1+N/4; Phi=N/100; J=N+N**2/8+3*Phi; density=J+C
    zero('continuity_with_metric_term',s.diff(density,N)-W-3*s.diff(Phi,N))
    coupling=s.Rational(1,10)+N/50
    P=B*density/(Zshape(beta,coupling)*W)
    zero('corrected_integrated_density_identity',s.diff(Zshape(beta,coupling)*P*W,N)-B*s.diff(J,N))
    omitted=s.factor(s.diff(Zshape(beta,coupling)*P*W,N)-B*W)
    check('omitted_metric_term_is_detectable',omitted!=0,str(omitted))
    # A physical W!=0 need not make J monotone or nonconstant.
    zero('velocity_nonzero_but_density_constant',s.diff(N+3*(-N/3),N))
    # Independent symbolic change from Jordan-time metric equations.
    ZZ,Zp,Zpp,Y,Yp,Fc,H0,BB,Qq=s.symbols('ZZ Zp Zpp Y Yp Fc H0 BB Qq',positive=True)
    H=H0*s.sqrt(Y); Hd=H0**2*Yp/2
    F=Fc*ZZ; Fd=Fc*H*Zp; Fdd=Fc*H0**2*(Y*Zpp+Yp*Zp/2)
    omega=(1/Qq-3)/2; rho=3*H0**2*Fc*BB*s.exp(-3*N)
    raw=-2*F*Hd-rho-Fdd+H*Fd-omega*Fd**2/F
    expected=(2*ZZ+Zp)*Yp/2+(Zpp-Zp+omega*Zp**2/ZZ)*Y+3*BB*s.exp(-3*N)
    zero('background_kinetic_conversion',-raw/(Fc*H0**2)-expected)
    rawV=F*(3*H**2+Hd)-rho/2+Fdd/2+s.Rational(5,2)*H*Fd
    expectedV=ZZ*(3*Y+Yp/2)-3*BB*s.exp(-3*N)/2+Y*Zpp/2+Yp*Zp/4+s.Rational(5,2)*Y*Zp
    zero('background_potential_conversion',rawV/(Fc*H0**2)-expectedV)
    # Neither arbitrary reduced-history branch passes the FULL interval
    # kinetic plus Euler consistency. No observational model exclusion follows.
    q=s.Rational(9,50)-N/25; p=s.Rational(1,5)*(N+2)/Zshape(s.Rational(29,100),q)
    failures=[]
    for br,Br in [(s.Rational(29,100),s.Rational(1,5)),(s.Rational(13,50),s.Rational(26,145))]:
        Z=Zshape(br,q); om=(1/q-3)/2
        L1=2*Z+s.diff(Z,N); L0=s.diff(Z,N,2)-s.diff(Z,N)+om*s.diff(Z,N)**2/Z
        # Y=e^-3N f is necessary after eliminating Y' with Euler, P3=0.
        f=s.factor(-(s.Rational(3,2)*L1*p*(1+q)+3*Br)/(L0-2*L1))
        euler=s.factor((s.diff(f,N)+f)/2-s.Rational(3,2)*p*(1+q))
        value=s.factor(euler.subs(N,0))
        check('background_rejects_manufactured_history_'+str(br),value!=0,str(value))
        check('necessary_expansion_positive_at_origin_'+str(br),f.subs(N,0)>0,str(f.subs(N,0)))
        # The failure is Euler compatibility of the algebraic Y, not the
        # identity used to derive that algebraic Y.
        kinetic=background_residual(N,Z,q,Br,s.exp(-3*N)*f)
        zero('eliminated_system_residual_relation_'+str(br),s.exp(3*N)*kinetic-L1*euler)
        failures.append({'beta':br,'B':Br,'necessary_Y0':f.subs(N,0),'Euler_residual_at_0':value,
                         'meaning':'Manufactured reduced identity is not a full background solution.'})
    result={'scope':'Exact conditional algebra; no empirical fit, no full perturbation solution',
            'checks':checks,'pass':sum(x['passed'] for x in checks),'fail':sum(not x['passed'] for x in checks),
            'exceptional_pairs':exceptional,'background_failures':failures,
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'helper_sha256':hashlib.sha256((HERE/'growth_inverse_v2.py').read_bytes()).hexdigest()}
    with (HERE/'EXTENDED_RESULTS_v1.json').open('x') as stream:json.dump(result,stream,indent=2,default=str);stream.write('\n')
    for x in checks:
        if not x['passed']:print('FAIL',x)
    print(f"TOTAL: PASS={result['pass']} FAIL={result['fail']}")
    print('Preserved manufactured-history background failures:',len(failures))
    return int(result['fail']>0)


if __name__=='__main__':
    raise SystemExit(run())
