"""Personally integrated full radial background plus reduced perturbations.

The background source model was personally read and checked in M12. Its
analytic differentiation is reused here. Perturbation evolution and the
observation-side inverse are authored in this block. r=q is a supplied
light/quasistatic closure; no exact full perturbation solution is claimed.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import mpmath as mp
import numpy as np
from scipy.integrate import solve_ivp

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
spec=importlib.util.spec_from_file_location('previous_background',ROOT/'scripts/scalar_cosmological_inverse.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)


def inverse_rows(rows):
    """Only synthesized observables q,P,What,J enter; no source parameters."""
    vals=[{k:mp.mpf(str(v[k])) for k in ['q','P','What','J']} for v in rows]
    if any(not (0<x['q']<mp.mpf(1)/3 and x['P']>0 and x['What']>0) for x in vals):
        raise ValueError('outside positive candidate inputs')
    q=[x['q'] for x in vals];J=[x['J']-vals[0]['J'] for x in vals]
    if J[1]==0 or J[2]==0 or J[1]==J[2]:raise ValueError('primitive rank failure')
    t=[x['P']*x['What']*(1-3*x['q']) for x in vals]
    C=[t[0]*(J[2]-J[1]),-t[1]*J[2],t[2]*J[1]]
    a=sum(C);b=-sum(C[i]*sum(q[j] for j in range(3) if j!=i) for i in range(3))
    c=sum(C[i]*mp.fprod(q[j] for j in range(3) if j!=i) for i in range(3))
    roots=[]
    if a==0:
        if b==0:raise ValueError('zero polynomial or inconsistent constant')
        roots=[-c/b]
    else:
        disc=b*b-4*a*c
        if disc>=0:roots=[(-b-mp.sqrt(disc))/(2*a),(-b+mp.sqrt(disc))/(2*a)]
    candidates=[]
    for beta in roots:
        if not max(mp.mpf(1)/4,*q)<beta<mp.mpf(1)/3:continue
        Z=lambda qi: beta*(1-3*qi)/(beta-qi)
        B=(Z(q[1])*vals[1]['P']*vals[1]['What']-Z(q[0])*vals[0]['P']*vals[0]['What'])/J[1]
        if B<=0:continue
        offset=Z(q[0])*vals[0]['P']*vals[0]['What']/B-vals[0]['J']
        candidates.append({'beta':float(beta),'B':float(B),'C':float(offset)})
    return {'candidates':candidates,'coefficients':[mp.nstr(x,65) for x in [a,b,c]],
            'q_range':float(max(q)-min(q))}


def run():
    protocol=json.loads((HERE/'FORWARD_PROTOCOL_v1.json').read_text())
    evaluate=previous.source_model()
    checks=[];histories=[]
    def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
    for caseid,case in enumerate(protocol['cases']):
        k,nu,Q0,Hv=[case[n] for n in ['k','nu','Q0','Hv']]
        Q=Q0*(1+k);beta=(1-k)*(1+3*k)/4;alpha=math.sqrt(beta)
        sc=(1+k)/(k*(1-3*k));Fc=Q*sc/(1+sc)
        def background(y):
            u,v,rhoE,aE=y[:4]
            K,Ku,A,b,bu,U,Uu=[float(x) for x in evaluate(u,k,nu)]
            HE=math.sqrt((K*v*v+2*Hv*Hv*U+rhoE/Q)/3)
            vd=-Ku*v*v/(2*K)-3*HE*v-Hv*Hv*Uu/K-b*rhoE/(2*Q*K)
            HEd=-K*v*v-rhoE/(2*Q)
            ndot=HE+b*v;H=ndot/A
            Hd=(HEd+b*vd+(bu-b*b)*v*v-HE*b*v)/(A*A)
            F=Q/(A*A);Fp=-2*F*b*v/ndot
            Fdd=-2*F/(A*A)*(b*vd+(bu-3*b*b)*v*v)
            Fpp=(Fdd-Hd*Fp)/(H*H)
            q=b*b/K;qu=2*b*bu/K-b*b*Ku/(K*K);qp=qu*v/ndot
            return {'K':K,'A':A,'HE':HE,'vd':vd,'ndot':ndot,'H':H,'Hd':Hd,
                    'F':F,'Fp':Fp,'Fpp':Fpp,'rho':rhoE/A**4,'q':q,'qp':qp,
                    'Z':F/Fc,'Zp':Fp/Fc,'Zpp':Fpp/Fc,'U':U,'b':b}
        initial_background=[case['u0'],case['v0_over_Hv']*Hv,
                            case['rhoE_over_QHv2']*Q*Hv*Hv,1.0]
        init=background(initial_background);A0=init['A'];H0=init['H'];B=init['rho']/(3*H0*H0*Fc)
        end=protocol['duration_over_inverse_Hv']/Hv
        for modeid,(K0,dv) in enumerate(zip(protocol['mode_K0_over_H0'],protocol['initial_density_and_velocity'])):
            delta0,W0=dv
            def perturb_read(y):
                bg=background(y);N=math.log(bg['A']*y[3]/A0);aa=math.exp(N)
                K2=(K0*H0/aa)**2
                cphi=bg['rho']*(1-bg['q'])/(2*bg['F']*K2)
                cphip=cphi*(-1-bg['qp']/(1-bg['q'])-bg['Fp']/bg['F'])
                delta,W=y[4:6]
                dp=(W-3*cphip*delta)/(1+3*cphi)
                Wp=bg['rho']*delta*(1+bg['q'])/(2*bg['F']*bg['H']**2)-(2+bg['Hd']/bg['H']**2)*W
                Phi=-cphi*delta
                return bg,N,dp,Wp,Phi
            def ode(t,y):
                bg,N,dp,Wp,Phi=perturb_read(y)
                u,v,rhoE,aE,delta,W,I=y
                return [v,bg['vd'],(-3*bg['HE']+bg['b']*v)*rhoE,bg['HE']*aE,
                        dp*bg['ndot'],Wp*bg['ndot'],W*bg['ndot']]
            y0=initial_background+[delta0,W0,0.0]
            Phi0=perturb_read(y0)[4]
            solution=solve_ivp(ode,[0,end],y0,method=protocol['method'],rtol=protocol['rtol'],
                               atol=protocol['atol'],max_step=end/protocol['max_step_divisor'],dense_output=True)
            check(f'case{caseid}_mode{modeid}_solver',solution.success,solution.message)
            if not solution.success:
                histories.append({'caseid':caseid,'modeid':modeid,'failure':solution.message});continue
            rows=[]
            for frac in protocol['sample_time_fractions']:
                time=frac*end;y=solution.sol(time);bg,N,dp,Wp,Phi=perturb_read(y)
                u,v,rhoE,aE,delta,W,I=map(float,y);aa=math.exp(N)
                Y=(bg['H']/H0)**2;Yp=2*bg['Hd']/H0**2;h=bg['Hd']/bg['H']**2
                # The inverse sees ratios and common-mode integrals, not delta0 or Fc.
                L=aa**3*bg['rho']*delta/(3*H0**2*bg['F']);P=L/W;P3=Wp/W
                qobs=2*Y*aa**3*(P3+2+h)/(3*P)-1
                What=W/W0;J=(I+3*(Phi-Phi0))/W0
                Z,Zp,Zpp=[bg[key] for key in ['Z','Zp','Zpp']]
                omega=(1/bg['q']-3)/2
                kres=-2*Z*h-3*B*aa**-3/Y-Zpp+(1-h)*Zp-omega*Zp*Zp/Z
                vread=Z*(3*Y+Yp/2)-1.5*B*aa**-3+Y*Zpp/2+Yp*Zp/4+2.5*Y*Zp
                vsource=2*Q*Hv*Hv*bg['U']/(bg['A']**4*Fc*H0**2)
                rows.append({'timeE':time,'N':N,'q':qobs,'P':P,'P3':P3,'What':What,'J':J,
                             'E2':Y,'h':h,'Phihat':Phi/W0,'integral_What':I/W0,
                             'source_q':bg['q'],'source_Z':Z,'source_Zp':Zp,'source_Zpp':Zpp,
                             'source_delta_hat':delta/W0,'kinetic_residual':kres,
                             'potential_relative_residual':(vread-vsource)/vsource,
                             'kinematic_error':delta/W0-(J+delta0/W0),
                             'q_readout_error':qobs-bg['q']})
            prefix=f'case{caseid}_mode{modeid}'
            check(prefix+'_positive_chart',all(x['P']>0 and x['What']>0 and 0<x['q']<beta for x in rows))
            check(prefix+'_readout_slip',max(abs(x['q_readout_error']) for x in rows)<protocol['slip_absolute_tolerance'])
            check(prefix+'_exact_dust_continuity',max(abs(x['kinematic_error']) for x in rows)<protocol['integrated_identity_relative_tolerance'])
            check(prefix+'_background_potential',max(abs(x['potential_relative_residual']) for x in rows)<protocol['metric_potential_relative_tolerance'])
            # This residual is dimensionless and its scale is explicitly recorded.
            kscale=max(max(abs(x['source_Z']),abs(3*B*math.exp(-3*x['N'])/x['E2'])) for x in rows)
            check(prefix+'_background_kinetic',max(abs(x['kinetic_residual']) for x in rows)/kscale<protocol['metric_potential_relative_tolerance'])
            with mp.workdps(protocol['inverse_arithmetic_digits']):
                inverse=inverse_rows([rows[i] for i in protocol['calibration_indices']])
            # Truth is used ONLY for recovery diagnostics, never to construct roots.
            candidates=inverse['candidates']
            match=min(candidates,key=lambda x:abs(x['beta']/beta-1)) if candidates else None
            be=abs(match['beta']/beta-1) if match else float('inf')
            Be=abs(match['B']/B-1) if match else float('inf')
            Ce=abs(match['C']/(delta0/W0)-1) if match else float('inf')
            check(prefix+'_shape_in_returned_set',be<protocol['shape_relative_tolerance'],be)
            check(prefix+'_density_ratio_recovery',Be<protocol['B_relative_tolerance'],Be)
            check(prefix+'_initial_density_inferred_not_supplied',Ce<protocol['initial_density_recovery_relative_tolerance'],Ce)
            later=[]
            for candidate in candidates:
                bfit,Bfit,Cfit=[candidate[key] for key in ['beta','B','C']]
                residuals=[]
                for i in protocol['synthetic_test_indices']:
                    row=rows[i];Zfit=bfit*(1-3*row['q'])/(bfit-row['q'])
                    lhs=Zfit*row['P']*row['What'];rhs=Bfit*(row['J']+Cfit)
                    residuals.append((lhs-rhs)/max(abs(lhs),abs(rhs),1e-30))
                later.append({'candidate':candidate,'relative_residuals':residuals,
                              'within_fixed_threshold':max(map(abs,residuals))<protocol['integrated_identity_relative_tolerance']})
            check(prefix+'_later_epoch_admits_candidate',any(x['within_fixed_threshold'] for x in later),later)
            histories.append({'caseid':caseid,'modeid':modeid,'case':case,'K0_over_H0':K0,
                              'source_truth':{'beta':beta,'B':B,'C':delta0/W0,'Fc':Fc,'H0':H0},
                              'rows':rows,'inverse':inverse,'later_tests':later,'nfev':solution.nfev})
    result={'scope':protocol['scope'],'pass':sum(x['passed'] for x in checks),'fail':sum(not x['passed'] for x in checks),
            'checks':checks,'histories':histories,'protocol_sha256':hashlib.sha256((HERE/'FORWARD_PROTOCOL_v1.json').read_bytes()).hexdigest(),
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'reused_background_source_sha256':hashlib.sha256((ROOT/'scripts/scalar_cosmological_inverse.py').read_bytes()).hexdigest()}
    with (HERE/'FORWARD_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    for x in checks:
        if not x['passed']:print('FAIL',x)
    print(f"TOTAL: PASS={result['pass']} FAIL={result['fail']}")
    print('No observations or exact full-action perturbations tested.')
    return int(result['fail']>0)


if __name__=='__main__':
    raise SystemExit(run())
