"""Root-authored exact reduced-model inverse, not an empirical fit."""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path
import sympy as s
import numpy as np

HERE = Path(__file__).resolve().parent


def coupling_shape(beta, q):
    return beta * (1 - 3*q) / (beta-q)


def pole_inverse(x1, r1, x2, r2):
    if min(x1, x2, r1, r2) <= 0 or x1 == x2:
        raise ValueError("distinct positive scales and responses required")
    intercept = (x1/r1 - x2/r2)/(x1-x2)
    slope = x1*(1/r1-intercept)
    if intercept <= 0 or slope < 0:
        raise ValueError("positive coupling and nonnegative pole mass required")
    return s.simplify(1/intercept), s.simplify(slope/intercept)


def slip_from_ratios(P, P3, E2, a, h):
    return 2*E2*a**3*(P3+2+h)/(3*P)-1


def integrated_inverse(rows):
    """Only q,P,Rhat,I at three epochs enter; no generating answer."""
    if len(rows) != 3:
        raise ValueError("three calibration epochs required")
    q = [s.sympify(v['q']) for v in rows]
    if any(v['P'] <= 0 or v['R'] <= 0 for v in rows):
        raise ValueError("positive lensing/velocity branch required")
    I = [s.sympify(v['I']) for v in rows]
    if I[0] != 0 or not 0 < I[1] < I[2]:
        raise ValueError("ordered nonzero interval integrals required")
    t = [v['P']*v['R']*(1-3*v['q']) for v in rows]
    C = [t[0]*(I[2]-I[1]), -t[1]*I[2], t[2]*I[1]]
    b = s.Symbol('beta', real=True)
    Q = s.Poly(s.expand(sum(C[i]*s.prod(b-q[j] for j in range(3) if j != i)
                           for i in range(3))), b)
    if Q.is_zero:
        return {'polynomial':Q, 'rank_failure':True, 'candidates':[]}
    candidates = []
    for root in s.real_roots(Q):
        if root in [v['beta'] for v in candidates]:
            continue
        if not (max(s.Rational(1,4),*q) < root < s.Rational(1,3)):
            continue
        Z = [coupling_shape(root, qi) for qi in q]
        B = s.simplify((Z[1]*rows[1]['P']*rows[1]['R']-
                        Z[0]*rows[0]['P']*rows[0]['R'])/I[1])
        if B > 0:
            candidates.append({'beta':root,'B':B})
    return {'polynomial':Q, 'rank_failure':False, 'candidates':candidates}


def interval_residual(first, row, beta, B):
    return s.simplify(coupling_shape(beta,row['q'])*row['P']*row['R']
          -coupling_shape(beta,first['q'])*first['P']*first['R']
          -B*(row['I']-first['I']))


def tensor_inverse(qi, qj, F_ratio):
    U = F_ratio*(1-3*qi)/(1-3*qj)
    if U == 1:
        raise ValueError("tensor/coupling rank failure")
    beta = s.simplify((U*qj-qi)/(U-1))
    if not max(s.Rational(1,4),qi,qj) < beta < s.Rational(1,3):
        raise ValueError("candidate chart failed")
    return beta


def main():
    protocol=json.loads((HERE/'SYNTHETIC_PROTOCOL_v1.json').read_text())
    checks=[]
    def check(name, passed, detail=None):
        checks.append({'name':name,'passed':bool(passed),'detail':detail})
    def zero(name, expression):
        residual=s.factor(s.cancel(expression))
        check(name, residual==0, str(residual))
    F,K2,dr,dF,q,m2=s.symbols('F K2 dr dF q m2', positive=True)
    Phi,Psi=s.symbols('Phi Psi')
    solution=s.solve([-2*F*K2*Phi-dr+K2*dF,
                      -2*F*K2*Psi-dr-K2*dF],(Phi,Psi))
    zero('Weyl_source_from_metric_system',-K2*(solution[Phi]+solution[Psi])-dr/F)
    zero('metric_slip_sign',solution[Phi]-solution[Psi]-dF/F)
    ratio=((solution[Psi]-solution[Phi])/(solution[Psi]+solution[Phi])).subs(dF,q*dr/(K2+m2))
    zero('one_pole_from_metric_and_scalar_system',ratio-q*K2/(K2+m2))
    for mass in [s.Rational(0),s.Rational(1,7),s.Rational(9)]:
        qa=s.Rational(2,9);x1=s.Rational(3);x2=s.Rational(11)
        got=pole_inverse(x1,qa*x1/(x1+mass),x2,qa*x2/(x2+mass))
        check('pole_recovery_'+str(mass),got==(qa,mass),list(map(str,got)))
    try:
        pole_inverse(s.Rational(2),s.Rational(2,7),s.Rational(5),s.Rational(5,24))
        negative_mass_refused=False
    except ValueError:
        negative_mass_refused=True
    check('negative_mass_refusal',negative_mass_refused)
    N=s.Symbol('N',real=True);b,qp,P,R,rp,HH2,aa,hh=s.symbols('b qp P R rp HH2 aa hh',positive=True)
    delta,H0,rho0=s.symbols('delta H0 rho0',positive=True)
    lens=rho0*delta/(3*H0**2*F)
    growth_force=rho0*delta*(1+q)/(2*aa**3*F*HH2*H0**2)
    zero('slip_ratio_normalization',slip_from_ratios(lens/R,growth_force/R-2-hh,HH2,aa,hh)-q)
    wrong=s.factor(slip_from_ratios(2*lens/R,growth_force/R-2-hh,HH2,aa,hh))
    zero('wrong_lensing_factor_two_witness',wrong-(q-1)/2)
    beta,Fc=s.symbols('beta Fc',positive=True)
    Z=coupling_shape(beta,q)
    zero('candidate_geometric_inverse',beta*(Z-1)/(Z-3*beta)-q)
    zero('candidate_chart_derivative',s.diff(Z,q)-beta*(1-3*beta)/(beta-q)**2)
    B,d0=s.symbols('B d0',positive=True)
    In=s.Function('I')(N);Rn=s.Function('R')(N);qn=s.Function('q')(N)
    Zn=coupling_shape(beta,qn);Pn=B*(d0+In)/(Zn*Rn)
    zero('initial_density_elimination',s.diff(Zn*Pn*Rn,N).subs(s.diff(In,N),Rn)-B*Rn)
    cases=[]
    product=itertools.product(protocol['beta_values'],protocol['B_values'],
              protocol['initial_density_values'],protocol['q_profiles'],protocol['R_profiles'])
    for idx,(bs,Bs,ds,qs,rs) in enumerate(product):
        true_beta,true_B,density0=map(s.Rational,[bs,Bs,ds]); q0=s.Rational(qs['q0']);q_slope=s.Rational(qs['slope']);r_slope=s.Rational(rs['slope'])
        rows=[]
        for value in protocol['epochs']:
            n=s.Rational(value);Rval=1+r_slope*n;Ival=n+r_slope*n*n/2;qval=q0+q_slope*n
            Zval=coupling_shape(true_beta,qval);Pval=true_B*(density0+Ival)/(Zval*Rval)
            rows.append({'N':n,'q':qval,'P':Pval,'R':Rval,'I':Ival})
        fit=integrated_inverse(rows[:3]); roots=fit['candidates']
        match=[v for v in roots if s.simplify(v['beta']-true_beta)==0]
        check(f'case_{idx}_true_shape_in_set',len(match)==1)
        check(f'case_{idx}_density_ratio_recovered',len(match)==1 and match[0]['B']==true_B)
        held=[v for v in roots if interval_residual(rows[0],rows[3],v['beta'],v['B'])==0]
        check(f'case_{idx}_later_epoch_contains_true_shape',any(v['beta']==true_beta for v in held),[str(v['beta']) for v in held])
        tensor_ratio=coupling_shape(true_beta,rows[3]['q'])/coupling_shape(true_beta,rows[0]['q'])
        check(f'case_{idx}_tensor_ratio_inverse',tensor_inverse(rows[0]['q'],rows[3]['q'],tensor_ratio)==true_beta)
        # Raw binary64 roots are diagnostic only: original exact result is not
        # replaced or a tolerance tuned if numerical conditioning fails.
        coeff=np.array([float(v) for v in fit['polynomial'].all_coeffs()]);numeric=np.roots(coeff)
        numeric_error=min(abs(complex(v)-float(true_beta)) for v in numeric)
        check(f'case_{idx}_binary64_root_accuracy',numeric_error<=protocol['numeric_comparison_tolerance'],float(numeric_error))
        cases.append({'index':idx,'true_beta':str(true_beta),'true_B':str(true_B),'density0':str(density0),
                      'q_profile':qs,'R_profile':rs,'rows':rows,'polynomial':str(fit['polynomial'].as_expr()),
                      'candidate_count':len(roots),'candidates':roots,'later_test_candidates':held,
                      'numeric_error':float(numeric_error)})
    # Rank-failure witness: constant q leaves beta free if B is rescaled.
    rank_rows=[]
    for nv in [0,s.Rational(1,4),s.Rational(1,2)]:
        rank_rows.append({'q':s.Rational(1,10),'R':s.Integer(1),'I':nv,'P':1+nv})
    check('constant_q_rank_failure',integrated_inverse(rank_rows)['rank_failure'])
    for br in [s.Rational(13,50),s.Rational(8,25)]:
        zr=coupling_shape(br,s.Rational(1,10))
        check('constant_q_continuum_'+str(br),all(interval_residual(rank_rows[0],x,br,zr)==0 for x in rank_rows[1:]))
    # Nonconstant velocity calibration changes inferred interval density ratio.
    rows=cases[0]['rows'];bb=s.Rational(cases[0]['true_beta']);Bval=s.Rational(cases[0]['true_B'])
    altered=[]
    for row in rows:
        n=row['N'];gain=1+n/2
        altered.append({**row,'R':row['R']*gain,'P':row['P']/gain,'I':n+n*n/4})
    drift=[interval_residual(altered[0],v,bb,Bval) for v in altered[1:]]
    check('nonconstant_velocity_calibration_detected',all(x!=0 for x in drift),list(map(str,drift)))
    # A finite-amplitude homogeneous solution at arbitrary frequency persists.
    t,Omega,amplitude,source=s.symbols('t Omega amplitude source',positive=True)
    field=source/Omega**2+amplitude*s.cos(Omega*t)
    zero('homogeneous_scalar_residual',s.diff(field,t,2)+Omega**2*field-source)
    zero('quasistatic_free_mode_error',field-source/Omega**2-amplitude*s.cos(Omega*t))
    # Global normalization remains unidentifiable in these reduced observables.
    lam=s.symbols('lambda',positive=True)
    zero('absolute_scale_symmetry', (lam*rho0)*delta/(3*H0**2*(lam*F))-lens)
    results={'scope':'Exact algebra and manufactured reduced histories, not observations or full action solutions',
             'protocol_sha256':hashlib.sha256((HERE/'SYNTHETIC_PROTOCOL_v1.json').read_bytes()).hexdigest(),
             'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'checks':checks,'cases':cases,'pass':sum(v['passed'] for v in checks),
             'fail':sum(not v['passed'] for v in checks),'candidate_counts':sorted(set(v['candidate_count'] for v in cases)),
             'later_candidate_counts':sorted(set(len(v['later_test_candidates']) for v in cases))}
    out=HERE/'RESULTS_v1.json'
    with out.open('x') as f:json.dump(results,f,indent=2,default=str);f.write('\n')
    print('Exact reduced-model inverse; no empirical fit or full-action solution test.')
    print('Cases:',len(cases),'calibration candidates:',results['candidate_counts'],'after later epoch:',results['later_candidate_counts'])
    print('Max binary64 root error:',max(v['numeric_error'] for v in cases))
    for item in checks:
        if not item['passed']:print('FAIL',item)
    print(f"TOTAL: PASS={results['pass']} FAIL={results['fail']}")
    return int(results['fail']>0)


if __name__=='__main__':
    raise SystemExit(main())
