"""Exact conditional scalar admission, with physical-domain gates.

v1 is preserved separately. This version uses the continuity-corrected density
primitive J and fixes the independently reported missing positive-q check.
The functions operate on exact finite real SymPy numbers, not a data likelihood.
"""
from __future__ import annotations

import sympy as s


def real_number(value):
    value = s.sympify(value)
    if value.is_real is not True or value.is_finite is not True:
        raise ValueError("finite real inputs required")
    return value


def positive_q(value):
    value = real_number(value)
    if not 0 < value < s.Rational(1, 3):
        raise ValueError("positive candidate coupling below one third required")
    return value


def coupling_shape(beta, q):
    return beta * (1 - 3*q) / (beta-q)


def validate_rows(rows):
    converted = []
    for row in rows:
        out = {k: real_number(row[k]) for k in ('P', 'W', 'J')}
        out['q'] = positive_q(row['q'])
        if out['P'] <= 0 or out['W'] <= 0:
            raise ValueError("positive lensing/velocity branch required")
        converted.append(out)
    return converted


def integrated_inverse(rows):
    if len(rows) != 3:
        raise ValueError("three calibration epochs required")
    rows = validate_rows(rows)
    q = [v['q'] for v in rows]
    J = [v['J']-rows[0]['J'] for v in rows]
    if J[1] == 0 or J[2] == 0 or J[1] == J[2]:
        raise ValueError("three distinct density-primitive values required")
    t = [v['P']*v['W']*(1-3*v['q']) for v in rows]
    C = [t[0]*(J[2]-J[1]), -t[1]*J[2], t[2]*J[1]]
    beta = s.Symbol('beta', real=True)
    poly = s.Poly(s.expand(sum(C[i]*s.prod(beta-q[j] for j in range(3) if j != i)
                              for i in range(3))), beta)
    if poly.is_zero:
        return {'polynomial': poly, 'rank_failure': True, 'candidates': []}
    candidates = []
    for root in s.real_roots(poly):
        if root in [x['beta'] for x in candidates]:
            continue
        if not max(s.Rational(1, 4), *q) < root < s.Rational(1, 3):
            continue
        Z = [coupling_shape(root, v) for v in q]
        B = s.simplify((Z[1]*rows[1]['P']*rows[1]['W']-
                        Z[0]*rows[0]['P']*rows[0]['W'])/J[1])
        if B > 0:
            offset = s.simplify(Z[0]*rows[0]['P']*rows[0]['W']/B-rows[0]['J'])
            candidates.append({'beta': root, 'B': B, 'C': offset})
    return {'polynomial': poly, 'rank_failure': False, 'candidates': candidates}


def lift_inverse(rows):
    rows = validate_rows(rows)
    if len(rows) < 4:
        raise ValueError("at least four rows required for full-rank lift")
    M = s.Matrix([[1, -r['J']*r['q'], -r['q'],
                   -r['P']*r['W']*(1-3*r['q'])] for r in rows])
    rhs = s.Matrix([-r['J'] for r in rows])
    rank = M.rank()
    if M.row_join(rhs).rank() > rank:
        return {'rank': rank, 'status': 'inconsistent', 'candidate': None}
    if rank < 4:
        return {'rank': rank, 'status': 'rank_failure', 'candidate': None}
    C, u, w, v = M.gauss_jordan_solve(rhs)[0]
    compatibility = s.factor(w-u*C)
    if compatibility != 0:
        return {'rank': rank, 'status': 'nonlinear_incompatibility',
                'compatibility': compatibility, 'candidate': None}
    if not 3 < u < 4 or v <= 0 or any(r['q'] >= 1/u for r in rows):
        return {'rank': rank, 'status': 'outside_chart', 'candidate': None}
    return {'rank': rank, 'status': 'admitted',
            'candidate': {'beta': s.simplify(1/u), 'B': s.simplify(1/v), 'C': C}}


def tensor_inverse(qi, qj, F_ratio):
    qi, qj = positive_q(qi), positive_q(qj)
    F_ratio = real_number(F_ratio)
    if F_ratio <= 0:
        raise ValueError("positive physical F ratio required")
    if qi == qj:
        raise ValueError("equal-coupling endpoints do not identify beta")
    U = F_ratio*(1-3*qi)/(1-3*qj)
    if U == 1:
        raise ValueError("no finite shape at this tensor/coupling ratio")
    beta = s.simplify((U*qj-qi)/(U-1))
    if not max(s.Rational(1, 4), qi, qj) < beta < s.Rational(1, 3):
        raise ValueError("candidate chart failed")
    return beta


def background_residual(N, Z, q, B, Y):
    """Undivided flat-dust second metric identity in H0,Fc units."""
    omega = (1/q-3)/2
    return s.factor((2*Z+s.diff(Z, N))*s.diff(Y, N)/2 +
                    (s.diff(Z, N, 2)-s.diff(Z, N)+omega*s.diff(Z, N)**2/Z)*Y +
                    3*B*s.exp(-3*N))


def relative_potential(N, Z, B, Y):
    """V/(Fc H0^2), before any supplied potential-basis fit."""
    return (Z*(3*Y+s.diff(Y, N)/2)-3*B*s.exp(-3*N)/2+
            Y*s.diff(Z, N, 2)/2+s.diff(Y, N)*s.diff(Z, N)/4+
            5*Y*s.diff(Z, N)/2)
