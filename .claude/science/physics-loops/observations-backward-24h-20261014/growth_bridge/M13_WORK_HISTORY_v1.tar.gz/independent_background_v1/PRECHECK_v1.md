# Independent background-plus-Euler reduction, before v2 author exposure

Root retains authorship. This derivation uses the previously checked M12 Jordan metric identities. No growth_bridge WORKING_v2.md or new source has been read. Only this assigned directory is writable. No new ODE campaign or observational fit is proposed.

Let N=ln(a), prime=d/dN, F=Fc Z, rho=3H0² Fc B exp(-3N), pressure=0, Y=H²/H0², and q=1/(2omega+3). Here D denotes M12 kinetic stress: D=omega Fdot²/F. Then omega=(1-3q)/(2q), Fdot=H Fc Z', Fddot=Fc H0²[Y Z''+(Y'/2)Z'], and Hdot=H0²Y'/2. Define

    A=Z+Z'/2,
    M=Z''-Z'+omega Z'^2/Z,
    C=3Z+(5/2)Z'+Z''/2.

The flat-dust kinetic and potential equations become

    A Y' + M Y + 3B exp(-3N)=0,
    V/(Fc H0²)=C Y+(A/2)Y'-(3B/2)exp(-3N).

Equivalently, once the kinetic equation holds,

    V/(Fc H0²)=[3Z+3Z'-(omega/2)Z'^2/Z]Y-3B exp(-3N).

These are identities for the supplied homogeneous matter and single-radial-field action class; arbitrary moving transverse fields need additional kinetic stress and cannot simply use geometric q in place of reconstructed q.

Using the supplied physical dust Euler equation and definitions

    W'+(2+H'/H)W=-K² Psi/H²,
    P=-a³ K²(Phi+Psi)/(3H0² W),
    r=(Psi-Phi)/(Psi+Phi),

one obtains, where W is nonzero,

    Y' + 2L Y=S,
    L=2+W'/W,
    S=3 exp(-3N)(1+r)P.

The factor 1/2 follows from Psi=(1+r)(Phi+Psi)/2. No relation between r and q is needed for this elimination. Combining with the kinetic equation gives

    T Y=3 exp(-3N)[B+A(1+r)P],  T=2LA-M.

If T is nonzero, this reconstructs an algebraic candidate Y_alg. A solution must additionally satisfy the derivative consistency condition Y_alg'+2L Y_alg-S=0. This condition cannot be discarded after eliminating Y'. If T=0, the numerator must vanish and the division is invalid; that branch needs its own equation analysis. Positive Y is required for an expanding nonzero H chart. The potential can then be read out, but changing a potential cannot repair an inconsistent kinetic-plus-Euler pair.

For the supplied radial geometry beta=a_c, Z_beta(q)=beta(1-3q)/(beta-q), 1/4<beta<1/3 and 0<q<beta. The proposed fixture is local near N=0: q=9/50-N/25, W=1, delta1=N+2, beta1=29/100, B1=1/5, P=B1 delta1/Z_beta1(q), beta2=13/50, B2=B1 beta2/beta1. The integrated reduced continuity equation gives delta_beta=(P W Z_beta)/B and delta_beta'=W. Indeed delta2=N+11/4, so both satisfy it while differing by an integration constant.

For the exact fixture computation I will explicitly take r=q, the light radial slip identification used by this type of leading inverse. If r is not identified with q or otherwise specified, the given fixture alone leaves Euler's source unspecified; a claim about full background/Euler membership would then be underdetermined. This conditional assumption must be checked against the authored v2 statement after freezing this result. No wave-number dependence, massive slip or full perturbation-theory sufficiency is assumed.

Set Y_alg=exp(-3N) U. With W=1 the derivative consistency residual is exp(-3N)[U'+U-3(1+q)P]. A single exact nonzero residual at N=0 suffices to show that the prescribed beta,B branch cannot solve both equations on an interval containing that point. It does not exclude other parameters, perturbations or observed universes. The rational q fixture is not asserted physical outside its admissible local interval.
