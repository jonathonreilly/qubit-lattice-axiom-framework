"""Independent exact rational fixture; no author source imports."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,signal
import sympy as s
signal.alarm(120)
PTH=Path(__file__).resolve().parent
N=s.symbols('N', real=True)
q=s.Rational(9,50)-N/25
omega=(1-3*q)/(2*q)
beta1=s.Rational(29,100);beta2=s.Rational(13,50);B1=s.Rational(1,5);B2=B1*beta2/beta1
Z=lambda beta:s.factor(beta*(1-3*q)/(beta-q))
P=s.factor(B1*(N+2)/Z(beta1))
rows=[]
for beta,B in [(beta1,B1),(beta2,B2)]:
 z=Z(beta);zp=s.diff(z,N);zpp=s.diff(zp,N)
 A=z+zp/2;M=zpp-zp+omega*zp*zp/z;T=s.factor(4*A-M)
 U=s.factor(3*(B+A*(1+q)*P)/T)
 residual=s.factor(s.diff(U,N)+U-3*(1+q)*P)
 delta=s.factor(P*z/B)
 cont=s.factor(s.diff(delta,N)-1)
 pot=s.factor((3*z+s.Rational(5,2)*zp+zpp/2)*U+A*(s.diff(U,N)-3*U)/2-3*B/2)
 data={'beta':str(beta),'B':str(B),'Z':str(z),'continuity_delta':str(delta),'continuity_residual':str(cont),'T':str(T),'U_equals_exp3N_Yalg':str(U),'Euler_consistency_residual_without_expminus3N':str(residual),'relative_potential_without_expminus3N':str(pot),'at_N0':{key:str(s.factor(expr.subs(N,0))) for key,expr in [('q',q),('Z',z),('T',T),('Yalg',U),('Euler_consistency_residual',residual)]}}
 assert cont==0
 assert s.factor(residual.subs(N,0))!=0
 assert U.subs(N,0)>0 and T.subs(N,0)!=0
 rows.append(data)
out={'frozen_at':datetime.now(timezone.utc).isoformat(),'scope':'Independent exact arithmetic before author WORKING_v2/source exposure. Local near N=0; r=q explicitly conditional.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'P':str(P),'cases':rows,'conclusion':'Both satisfy integrated reduced continuity. Neither solves the full radial kinetic plus Euler equations on a neighborhood of N=0 under r=q. No expansion history was imposed; each Yalg is forced by algebraic elimination.','formal_audit':False,'independent_empirical_tests':0}
(PTH/'INDEPENDENT_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
