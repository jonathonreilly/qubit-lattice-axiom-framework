# Independent reduced-forward ODE derivation before author-source exposure

Root retains authorship. This directory contains a focused computational check, not full-action perturbation theory or a formal audit. Before reading FORWARD_PROTOCOL_v1.json or either forward_controls script, derive the stated conditional system with N=ln a, prime=d/dN, physical dust delta and W, H'/H=h, and K=k_com/a.

The supplied reduced gravitational closure is

    Phi=-c delta, c=rho(1-q)/(2F K²),
    Psi=-rho(1+q)delta/(2F K²), r=q.

Exact linear dust continuity in these conventions is delta'=W+3Phi'. Differentiating the algebraic Phi equation gives Phi'=-c' delta-c delta'. Solving, rather than dropping that implicit derivative, yields

    delta'=(W-3c' delta)/(1+3c),
    W'=-(2+h)W+rho(1+q)delta/(2F H²),
    I'=W.

For conserved dust rho'/rho=-3 and physical K'/K=-1. Thus

    c'/c=-1-F'/F-q'/(1-q).

The correct sign is minus q'/(1-q). Equivalently the delta numerator is W+3c[1+F'/F+q'/(1-q)]delta. The domain requires K!=0 and nonzero denominator. Positive rho,F and q<1 make c>=0 and 1+3c positive. For any solution with I(N0)=0,

    delta-delta0=I+3[Phi-Phi0].

That identity does not make the supplied Poisson/slip closure an exact perturbation solution of the original action. It only restores the exact dust conservation term within the declared reduced forward system.

For forward-generated readouts let a(N0)=1 and use actual H0=H(N0). Then

    P=-a³K²(Phi+Psi)/(3H0² W)
     =rho0 delta/(3H0² F W)
     =B delta/(Z W),
    F=Fc Z, B=rho0/(3H0² Fc).

If W0 is not unity, use What=W/W0 and Phihat=Phi/W0, giving J=I/W0+3(Phihat-Phihat0) and delta/W0=J+delta0/W0. Treating unnormalized I or Phi as J when W0!=1 is an error. A raw Einstein/Jordan a_J with a_J0!=1 must be converted consistently to a=a_J/a_J0 before using these N, dust and comoving-wave-number formulas. Multiplying the mode amplitude by a constant cancels from P and r; a time-dependent gain does not.

For the supplied homogeneous radial action, let b=dln(sqrt(C))/du, Einstein velocity v_E and Einstein expansion HE. Then

    dN/dt_E=G=HE+b v_E,
    H_J=G/sqrt(C),
    du/dN=v_E/G,
    h=Hdot_J/H_J²,
    F'/F=-2b v_E/G.

Einstein dust obeys rhodot_E=(-3HE+b v_E)rho_E, while rho_J=rho_E/C², giving rho_J'/rho_J=-3 exactly. For beta=a_c and q=beta/Jkin with Jkin=1+(1-3beta)s exp(2sqrt(beta)u),

    dq/du=-2sqrt(beta)q(1-q/beta),
    q'=(dq/du)v_E/G.

Changing a background time coordinate or using Einstein HE in place of physical H_J would alter h and the force source. These formulas provide an independent source-comparison oracle.

No author code, protocol or results were read before this file was frozen. The next scope is complete source inspection and, if useful, a small independent implementation or readout-only check. No new empirical fit or broad M12 rerun is planned. Generated truth parameters may enter the forward generator; a claimed inverse must receive only its documented generated readouts, candidate-domain gates and calibration choices, not the generating answer.
