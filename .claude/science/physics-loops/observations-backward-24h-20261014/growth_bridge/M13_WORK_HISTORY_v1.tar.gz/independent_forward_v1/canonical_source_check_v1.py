"""Focused source equivalence and candidate admission only; no ODE rerun."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import sympy as s
HERE=Path(__file__).resolve().parent
current=HERE/'canonical_source_v1/scalar_growth_lensing_inverse.py'
old=HERE/'author_v2/forward_controls_v2.py'
background=HERE/'REUSED_BACKGROUND_SOURCE.py'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def functions(path):
    text=path.read_text(); tree=ast.parse(text)
    return text,{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
ct,cn=functions(current);ot,on=functions(old);bt,bn=functions(background)
def equal(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
checks=[]
def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
check('source_model_exact_AST_copy',equal(cn['source_model'],bn['source_model']))
check('inverse_rows_exact_AST_copy',equal(cn['inverse_rows'],on['inverse_rows']))
for function in ['background','perturb_read','ode']:
    a=next(x for x in ast.walk(cn['forward_controls']) if isinstance(x,ast.FunctionDef) and x.name==function)
    b=next(x for x in ast.walk(on['run']) if isinstance(x,ast.FunctionDef) and x.name==function)
    check(function+'_exact_AST_copy',equal(a,b))
a=ast.get_source_segment(ot,on['run']);b=ast.get_source_segment(ct,cn['forward_controls'])
delta='\n'.join(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile='working_v2:run',tofile='canonical_v1:forward_controls'))+'\n'
(HERE/'CANONICAL_FORWARD_DELTA_v1.patch').write_text(delta)
wanted={'real_number','candidate_domain','coupling_shape','assess_candidate'}
module=ast.Module(body=[copy.deepcopy(cn[n]) for n in wanted],type_ignores=[])
ns={'s':s};exec(compile(module,str(current),'exec'),ns)
cd=ns['candidate_domain'];ac=ns['assess_candidate'];Z=ns['coupling_shape']
beta=s.Rational(29,100);B=s.Rational(1,5);C=s.Integer(2)
cand={'beta':beta,'B':B,'C':C}
rows=[{'q':s.Rational(1,10),'J':j,'P':B*(j+C)/Z(beta,s.Rational(1,10)),'What':1} for j in (0,1,2)]
check('regular_exact_rows_admitted',cd(rows,cand))
for name,c in [('upper_boundary',{'beta':s.Rational(1,3),'B':B,'C':C}),
               ('lower_boundary',{'beta':s.Rational(1,4),'B':B,'C':C}),
               ('nonfinite_B',{'beta':beta,'B':s.oo,'C':C}),
               ('nonfinite_C',{'beta':beta,'B':B,'C':s.oo})]:
    check(name+'_refused',not cd(rows,c))
check('exact_upper_boundary_neighborhood_admitted',cd(rows,{**cand,'beta':s.Rational(1,3)-s.Rational(1,10**20)}))
check('zero_q_refused',not cd([{**rows[0],'q':0}],cand))
check('negative_density_refused',not cd([{**rows[0],'J':-3}],cand))
# P/What deliberately absent: successful refusal proves no subsequent singular evaluation.
pole=ac([{'q':beta,'J':1}],cand,[0],1e-9)
check('pole_refused_before_response_evaluation',not pole['sampled_domain_passed'] and pole['relative_residuals']==[])
check('empty_rows_refused',not cd([],cand))
valid=ac(rows,cand,[1,2],1e-9)
check('regular_exact_residual_admitted',valid['sampled_domain_passed'] and valid['within_fixed_threshold'] and valid['relative_residuals']==[0,0])
protocol=json.loads((HERE/'author_v2/FORWARD_PROTOCOL_v1.json').read_text())
original=json.loads((HERE/'author_v2/FORWARD_RESULTS_v2.json').read_text())
assessments=[]
for history in original['histories']:
    case=[]
    for candidate in history['inverse']['candidates']:
        result=ac(history['rows'],candidate,protocol['synthetic_test_indices'],protocol['integrated_identity_relative_tolerance'])
        case.append(result)
    old_assessments=history['later_tests']
    check(f"case{history['caseid']}_mode{history['modeid']}_all_candidate_sample_domains",all(x['sampled_domain_passed'] for x in case) and bool(case))
    check(f"case{history['caseid']}_mode{history['modeid']}_unchanged_later_residuals",all(a['relative_residuals']==b['relative_residuals'] and a['within_fixed_threshold']==b['within_fixed_threshold'] for a,b in zip(case,old_assessments)) and len(case)==len(old_assessments))
    assessments.append({'caseid':history['caseid'],'modeid':history['modeid'],'assessments':case})
result={'scope':'Narrow source/AST comparison and candidate gate calls on exact fixtures and previously frozen finite rows; no integration, aggregate, or observations.',
        'source_sha256':sha(current),'reader_sha256':sha(Path(__file__)),
        'original_forward_sha256':sha(old),'original_background_sha256':sha(background),
        'protocol_sha256':sha(HERE/'author_v2/FORWARD_PROTOCOL_v1.json'),
        'original_result_sha256':sha(HERE/'author_v2/FORWARD_RESULTS_v2.json'),
        'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
        'assessments':assessments,
        'separate_material_finding':'NONFINITE_READOUT_WITNESS_v1.json preserves a false acceptance of a later infinite P; this passing bounded source comparison does not override that finding.'}
(HERE/'CANONICAL_SOURCE_CHECK_RESULTS_v1.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['assessments']},indent=2))
assert all(c['passed'] for c in checks)
