"""Source/product/cache identity and retained-row correspondence only."""
from pathlib import Path
import ast,copy,hashlib,json
HERE=Path(__file__).resolve().parent
SNAP=HERE/'final_envelope_v1'
WT=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
GB=Path('.claude/science/physics-loops/observations-backward-24h-20261014/growth_bridge')
primary='scripts/scalar_growth_lensing_inverse_check.py'
helper='scripts/scalar_growth_lensing_inverse.py'
cache='logs/runner-cache/scalar_growth_lensing_inverse_check.txt'
result_path='outputs/scalar_growth_lensing_inverse/RESULTS_v1.json'
summary_path='outputs/scalar_growth_lensing_inverse/SUMMARY_v1.json'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def check(name,value,detail=None):checks.append({'name':name,'passed':bool(value),'detail':detail})
freeze=json.loads((SNAP/GB/'CANONICAL_SOURCE_FREEZE_v2.json').read_text())
for name,expected in freeze['files'].items():
    check('snapshot_and_current_hash:'+name,sha(SNAP/name)==expected and sha(WT/name)==expected)
ptree=ast.parse((SNAP/primary).read_text())
paths=next(ast.literal_eval(n.value) for n in ptree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
digest=hashlib.sha256();digest.update(b'runner-cache-input-fingerprint-v1\0')
for name in paths:
    name_bytes=name.encode();body=(SNAP/name).read_bytes()
    digest.update(len(name_bytes).to_bytes(8,'big'));digest.update(name_bytes)
    digest.update(len(body).to_bytes(8,'big'));digest.update(body)
fingerprint=digest.hexdigest()
cache_text=(SNAP/cache).read_text();header={}
for line in cache_text.split('----- stdout -----')[0].splitlines()[1:]:
    if ': ' in line:
        k,v=line.split(': ',1);header[k]=v
check('cache_expected_hash',sha(SNAP/cache)=='db3e65c51773a98982f9be700b80260ae940de379d79e5ed72372b0d7d4cd464')
check('cache_primary_hash',header['runner_sha256']==sha(SNAP/primary))
check('cache_fingerprint',header['input_fingerprint_sha256']==fingerprint=='ac4c41168ffca07dfeac0974c24f1702093044fcaa22259bd4f55dfef3f04030')
check('execution_success_and_timeout',header['status']=='ok' and header['exit_code']=='0' and float(header['elapsed_sec'])<float(header['timeout_sec'])==120)
stdout=cache_text.split('----- stdout -----',1)[1].split('----- stderr -----',1)[0]
stdout_summary=json.loads(stdout[stdout.index('{'):])
summary=json.loads((SNAP/summary_path).read_text());result=json.loads((SNAP/result_path).read_text())
check('cache_stdout_equals_summary',stdout_summary==summary)
expected_summary={k:v for k,v in result.items() if k not in ['checks','histories']}
expected_summary['failed_checks']=[c for c in result['checks'] if not c['passed']]
check('summary_equals_results_projection',summary==expected_summary)
check('all_143_controls_pass',len(result['checks'])==143 and len(set(c['name'] for c in result['checks']))==143 and all(c['passed'] is True for c in result['checks']) and result['passed']==143 and result['failed']==0)
check('all_declared_input_hashes_match',result['input_sha256']=={name:sha(SNAP/name) for name in paths})
check('result_primary_hash_matches',result['primary_sha256']==sha(SNAP/primary))
check('reviewed_helper_unchanged',sha(SNAP/helper)==sha(HERE/'canonical_source_v2/scalar_growth_lensing_inverse.py'))
check('reviewed_note_unchanged',sha(SNAP/paths[0])==sha(HERE/'canonical_source_v1/SCALAR_GROWTH_LENSING_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md'))
check('frozen_protocol_unchanged',sha(SNAP/paths[2])==sha(HERE/'author_v2/FORWARD_PROTOCOL_v1.json'))
class RemoveFailureMetadata(ast.NodeTransformer):
    def visit_Call(self,node):
        node=self.generic_visit(node)
        node.keywords=[k for k in node.keywords if k.arg!='original_failures']
        return node
old_primary=ast.parse((HERE/'canonical_source_v1/scalar_growth_lensing_inverse_check.py').read_text())
check('primary_change_only_original_failures',ast.dump(RemoveFailureMetadata().visit(copy.deepcopy(ptree)),include_attributes=False)==ast.dump(RemoveFailureMetadata().visit(old_primary),include_attributes=False))
old=json.loads((SNAP/GB/'canonical_v1_before_domain_repairs/RESULTS_v1.json').read_text())
check('historical_original_is_132_run',old['passed']==132 and old['failed']==0 and len(old['checks'])==132)
check('all_36_rows_unchanged_from_132_run',len(result['histories'])==6 and sum(len(h['rows']) for h in result['histories'])==36 and all(a['rows']==b['rows'] for a,b in zip(result['histories'],old['histories'])))
check('all_six_inverses_unchanged_from_132_run',all(a['inverse']==b['inverse'] for a,b in zip(result['histories'],old['histories'])))
check('all_later_assessments_unchanged_from_132_run',all(a['later_tests']==b['later_tests'] for a,b in zip(result['histories'],old['histories'])))
check('whole_histories_unchanged_from_132_run',result['histories']==old['histories'])
oldchecks={c['name']:c for c in old['checks']};newchecks={c['name']:c for c in result['checks']}
added=[n for n in newchecks if n not in oldchecks]
check('132_original_controls_unchanged',set(oldchecks).issubset(newchecks) and all(newchecks[n]==c for n,c in oldchecks.items()))
check('exactly_11_controls_added',len(added)==11,added)
receipt=json.loads((SNAP/GB/'CANONICAL_EXECUTION_v2.json').read_text())
check('receipt_binds_machine_cache',receipt['cache_sha256']==sha(SNAP/cache) and receipt['execution_header']==header)
failure=json.loads((SNAP/GB/'CANONICAL_RECEIPT_SERIALIZATION_FAILURE_v1.json').read_text())
check('serialization_failure_record_binds_same_cache',failure['canonical_cache_sha256']==sha(SNAP/cache))
record={'scope':'Identity and saved numerical-value comparison only; no scientific rerun.',
        'checker_sha256':sha(Path(__file__)),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
        'current_primary_sha256':sha(SNAP/primary),'current_helper_sha256':sha(SNAP/helper),'current_note_sha256':sha(SNAP/paths[0]),
        'current_cache_sha256':sha(SNAP/cache),'input_fingerprint_sha256':fingerprint,'result_sha256':sha(SNAP/result_path),'summary_sha256':sha(SNAP/summary_path),
        'cache_header':header,'original_132_result_sha256':sha(SNAP/GB/'canonical_v1_before_domain_repairs/RESULTS_v1.json'),
        'control_additions':added,'scientific_rerun':False,
        'cache_freshness_basis':'Independently reconstructed declared-input fingerprint and current primary SHA, exact success header and output equality. Cache only reports elapsed time rounded to 1.32 seconds.'}
(HERE/'FINAL_ENVELOPE_CHECK_RESULTS_v1.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='checks'},indent=2))
for c in checks:
    if not c['passed']:print('FAILED',c)
assert all(c['passed'] for c in checks)
