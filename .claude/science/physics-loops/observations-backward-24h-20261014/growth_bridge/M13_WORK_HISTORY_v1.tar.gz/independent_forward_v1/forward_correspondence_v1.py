"""Inspect frozen output correspondence and exact source-only serialization delta."""
from pathlib import Path
import ast,difflib,hashlib,json
from datetime import datetime,timezone
P=Path(__file__).resolve().parent;A=P/'author_v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((A/'FORWARD_RESULTS_v2.json').read_text());b=json.loads((P/'INDEPENDENT_FORWARD_RESULTS_v2.json').read_text());pr=json.loads((A/'FORWARD_PROTOCOL_v1.json').read_text())
assert a['pass']==60 and a['fail']==0 and len(a['checks'])==60 and all(x['passed'] for x in a['checks']);assert len(a['histories'])==len(b['histories'])==6
assert a['source_sha256']==sha(A/'forward_controls_v2.py') and a['protocol_sha256']==sha(A/'FORWARD_PROTOCOL_v1.json')==b['protocol_sha256']
wt=P.parents[5];helper=wt/'scripts/scalar_cosmological_inverse.py';assert sha(helper)==a['reused_background_source_sha256'];(P/'REUSED_BACKGROUND_SOURCE.py').write_bytes(helper.read_bytes())
maximum={};rootmax={};recovery={};later=[]
for x,y in zip(a['histories'],b['histories']):
 assert (x['caseid'],x['modeid'])==(y['caseid'],y['modeid']) and len(x['rows'])==len(y['rows'])==6
 for u,v in zip(x['rows'],y['rows']):
  for key in ['timeE','N','q','P','P3','What','J','E2','h','Phihat','integral_What','source_delta_hat','source_q','source_Z']:
   maximum[key]=max(maximum.get(key,0),abs(u[key]-v[key]))
 xr=sorted(x['inverse']['candidates'],key=lambda z:z['beta']);yr=y['candidates'];assert len(xr)==len(yr)==1
 for u,v in zip(xr,yr):
  for key in ['beta','B','C']:rootmax[key]=max(rootmax.get(key,0),abs(u[key]/v[key]-1))
 for key,val in y['truth_only_recovery_errors'].items():recovery[key]=max(recovery.get(key,0),val)
 assert [z['within_fixed_threshold'] for z in x['later_tests']]==[z['within_fixed_threshold'] for z in y['later_tests']]==[True]
 later.extend(abs(e) for z in y['later_tests'] for e in z['relative_residuals'])
old=(A/'forward_controls_v1.py').read_text();new=(A/'forward_controls_v2.py').read_text();patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='author-v1',tofile='author-v2'));(P/'AUTHOR_SERIALIZATION_DELTA_v1.patch').write_text(patch)
# Frozen author change is exactly filename and JSON default conversion.
expected=old.replace("FORWARD_RESULTS_v1.json","FORWARD_RESULTS_v2.json").replace('json.dump(result,f,indent=2)','json.dump(result,f,indent=2,default=lambda x: x.item() if isinstance(x,np.generic) else str(x))');assert expected==new
# Reviewer change is likewise serialization/output only.
old=(P/'independent_forward_v1.py').read_text();new=(P/'independent_forward_v2.py').read_text();assert new==old.replace('INDEPENDENT_FORWARD_RESULTS_v1.json','INDEPENDENT_FORWARD_RESULTS_v2.json').replace('json.dumps(result,indent=2)','json.dumps(result,indent=2,default=lambda x:x.item())').replace('for h in histories],indent=2))','for h in histories],indent=2,default=lambda x:x.item()))')
try:json.loads((A/'FORWARD_RESULTS_v1.json').read_text());partial_valid=True
except json.JSONDecodeError:partial_valid=False
out={'at':datetime.now(timezone.utc).isoformat(),'scope':'All36 sampled rows and all six candidate sets compared; no author code rerun.','author_controls':{'pass':60,'fail':0},'author_source_sha256':a['source_sha256'],'author_protocol_sha256':a['protocol_sha256'],'reused_background_source_sha256':a['reused_background_source_sha256'],'maximum_absolute_readout_differences':maximum,'maximum_relative_candidate_differences':rootmax,'independent_maximum_truth_recovery_errors':recovery,'independent_maximum_later_relative_residual':max(later),'independent_maximum_continuity_absolute_normalized_residual':max(abs(r['kinematic_error']) for h in b['histories'] for r in h['rows']),'independent_maximum_dust_relative_residual':max(abs(r['rho_relative_conservation_error']) for h in b['histories'] for r in h['rows']),'independent_maximum_slip_absolute_residual':max(abs(r['q_readout_error']) for h in b['histories'] for r in h['rows']),'all_six_single_candidate_sets_and_later_decisions_agree':True,'author_and_reviewer_serialization_only_repairs_verified':True,'original_partial_author_result_is_valid_JSON':partial_valid,'continuity_control_normalization':'Absolute error in normalized delta/W0 despite the protocol tolerance key containing relative; later identity uses a relative error.','formal_audit':False,'independent_empirical_tests':0}
(P/'FORWARD_CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
