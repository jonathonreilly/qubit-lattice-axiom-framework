"""Post-exposure independently coded forward path from the pre-exposure ODE oracle.
No author modules imported. Dimensionless Einstein time; integrate N directly.
"""
from pathlib import Path
import math, json, hashlib, signal
from datetime import datetime,timezone
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp
signal.alarm(120)
PTH=Path(__file__).resolve().parent
protocol=json.loads((PTH/'author_v2/FORWARD_PROTOCOL_v1.json').read_text())

def background(y,c):
 u,v,r=y[:3];k=c['k'];nu=c['nu'];hv=c['Hv'];Q=c['Q0']*(1+k);beta=(1-k)*(1+3*k)/4;al=math.sqrt(beta);s=(1+k)/(k*(1-3*k));E=math.exp(2*al*u);B=1+s*E;J=1+(1-3*beta)*s*E;Ep=2*al*E
 K=J/B**2;Ku=(1-3*beta)*s*Ep/B**2-2*J*s*Ep/B**3;A=math.sqrt((1+s)*E/B);b=al/B;bu=-2*b*(al-b)
 U=1.5+1.5*s*(E-1)**2/B**2+nu*(1+s)*u*u/(2*B**2);Uu=3*s*(1+s)*(E-1)*Ep/B**3+nu*(1+s)*(u/B**2-u*u*s*Ep/B**3)
 he=math.sqrt((K*v*v+2*U+r)/3);vd=-3*he*v-Ku*v*v/(2*K)-Uu/K-b*r/(2*K);hed=-K*v*v-r/2;g=he+b*v
 H=hv*g/A;Hd=hv*hv/A**2*(hed+b*vd+(bu-b*b)*v*v-he*b*v);F=Q/A**2;Fp=-2*F*b*v/g
 q=beta/J;qp=-2*al*q*(1-q/beta)*v/g;rho=Q*hv*hv*r/A**4
 return dict(K=K,A=A,b=b,U=U,he=he,vd=vd,g=g,H=H,Hd=Hd,F=F,Fp=Fp,q=q,qp=qp,rho=rho,Q=Q,beta=beta,Fc=Q*s/(1+s))

def inverse(rows):
 with mp.workdps(60):
  R=[{k:mp.mpf(str(v[k])) for k in ['q','P','What','J']} for v in rows]
  q=[r['q'] for r in R];j=[r['J'] for r in R];t=[r['P']*r['What']*(1-3*r['q']) for r in R]
  def polynomial(x):
   return (t[1]*(x-q[0])-t[0]*(x-q[1]))*(x-q[2])*(j[2]-j[0])-(t[2]*(x-q[0])-t[0]*(x-q[2]))*(x-q[1])*(j[1]-j[0])
  z=polynomial(mp.mpf(0));plus=polynomial(mp.mpf(1));minus=polynomial(mp.mpf(-1));aa=(plus+minus)/2-z;bb=(plus-minus)/2;cc=z
  if aa==0:
   roots=[] if bb==0 else [-cc/bb]
  else:
   disc=bb*bb-4*aa*cc
   if disc<0:roots=[]
   else:
    stable=-(bb+(1 if bb>=0 else -1)*mp.sqrt(disc))/2
    roots=[stable/aa,cc/stable] if stable!=0 else [-bb/(2*aa)]
  ans=[]
  for beta in roots:
   if not max([mp.mpf(1)/4]+q)<beta<mp.mpf(1)/3:continue
   U=[beta*t[i]/(beta-q[i]) for i in range(3)]
   B=(U[1]-U[0])/(j[1]-j[0]);C=U[0]/B-j[0]
   if B>0:ans.append({'beta':float(beta),'B':float(B),'C':float(C)})
  return sorted(ans,key=lambda a:a['beta'])

histories=[]
for ci,c in enumerate(protocol['cases']):
 ybase=[c['u0'],c['v0_over_Hv'],c['rhoE_over_QHv2'],0.0];z0=background(ybase,c);H0=z0['H'];Btrue=z0['rho']/(3*H0*H0*z0['Fc'])
 for mi,(wavenumber,dv) in enumerate(zip(protocol['mode_K0_over_H0'],protocol['initial_density_and_velocity'])):
  delta0,W0=dv
  def read(y):
   z=background(y,c);N=y[3];delta,W,I=y[4:7];K2=(wavenumber*H0)**2*math.exp(-2*N);cp=z['rho']*(1-z['q'])/(2*z['F']*K2);cpp=cp*(-1-z['Fp']/z['F']-z['qp']/(1-z['q']))
   dprime=(W-3*cpp*delta)/(1+3*cp);h=z['Hd']/z['H']**2;wprime=-(2+h)*W+z['rho']*(1+z['q'])*delta/(2*z['F']*z['H']**2)
   phi=-cp*delta;psi=-z['rho']*(1+z['q'])*delta/(2*z['F']*K2)
   return z,dprime,wprime,phi,psi,K2
  y0=ybase+[delta0,W0,0.0];phi0=read(y0)[3]
  def ode(t,y):
   z,dp,wp,phi,psi,K2=read(y);return [y[1],z['vd'],(-3*z['he']+z['b']*y[1])*y[2],z['g'],dp*z['g'],wp*z['g'],y[5]*z['g']]
  duration=protocol['duration_over_inverse_Hv'];times=np.asarray(protocol['sample_time_fractions'])*duration
  sol=solve_ivp(ode,[0,duration],y0,t_eval=times,method=protocol['method'],rtol=protocol['rtol'],atol=protocol['atol'],max_step=duration/protocol['max_step_divisor'])
  assert sol.success
  rows=[]
  for time,y in zip(times,sol.y.T):
   z,dp,wp,phi,psi,K2=read(y);N=y[3];W=y[5];delta=y[4];I=y[6];Y=(z['H']/H0)**2;h=z['Hd']/z['H']**2
   P=-math.exp(3*N)*K2*(phi+psi)/(3*H0*H0*W);What=W/W0;J=(I+3*(phi-phi0))/W0
   qobs=2*Y*math.exp(3*N)*(wp/W+2+h)/(3*P)-1
   rows.append({'timeE':float(time/c['Hv']),'N':float(N),'q':qobs,'P':P,'P3':wp/W,'What':What,'J':J,'E2':Y,'h':h,'Phihat':phi/W0,'integral_What':I/W0,'source_delta_hat':delta/W0,'source_q':z['q'],'source_Z':z['F']/z['Fc'],'direct_potential_slip':(psi-phi)/(psi+phi),'q_readout_error':qobs-z['q'],'kinematic_error':delta/W0-J-delta0/W0,'rho_relative_conservation_error':z['rho']/(z0['rho']*math.exp(-3*N))-1})
  candidates=inverse([rows[i] for i in protocol['calibration_indices']]);tests=[]
  for fit in candidates:
   residuals=[]
   for idx in protocol['synthetic_test_indices']:
    r=rows[idx];Z=fit['beta']*(1-3*r['q'])/(fit['beta']-r['q']);lhs=Z*r['P']*r['What'];rhs=fit['B']*(r['J']+fit['C']);residuals.append((lhs-rhs)/max(abs(lhs),abs(rhs),1e-30))
   tests.append({'candidate':fit,'relative_residuals':residuals,'within_fixed_threshold':max(map(abs,residuals))<protocol['integrated_identity_relative_tolerance']})
  nearest=min(candidates,key=lambda f:abs(f['beta']/z0['beta']-1)) if candidates else None
  histories.append({'caseid':ci,'modeid':mi,'nfev':sol.nfev,'source_truth':{'beta':z0['beta'],'B':Btrue,'C':delta0/W0},'rows':rows,'candidates':candidates,'later_tests':tests,'truth_only_recovery_errors':{k:abs(nearest[k]/v-1) for k,v in {'beta':z0['beta'],'B':Btrue,'C':delta0/W0}.items()} if nearest else None})
result={'at':datetime.now(timezone.utc).isoformat(),'scope':'Post-author-exposure independent implementation of six cases from frozen independent ODE; independent analytic action derivatives, dimensionless Einstein time, N directly integrated, potentials directly assembled for Weyl readout, polynomial evaluated at 0,+1,-1. No author imports or M12 aggregate execution.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((PTH/'author_v2/FORWARD_PROTOCOL_v1.json').read_bytes()).hexdigest(),'histories':histories,'formal_audit':False,'independent_empirical_tests':0}
(PTH/'INDEPENDENT_FORWARD_RESULTS_v2.json').write_text(json.dumps(result,indent=2,default=lambda x:x.item())+'\n')
print(json.dumps([{'caseid':h['caseid'],'modeid':h['modeid'],'roots':len(h['candidates']),'recovery_errors':h['truth_only_recovery_errors'],'max_continuity':max(abs(r['kinematic_error']) for r in h['rows']),'max_slip':max(abs(r['q_readout_error']) for r in h['rows']),'max_dust':max(abs(r['rho_relative_conservation_error']) for r in h['rows']),'later_candidate_flags':[r['within_fixed_threshold'] for r in h['later_tests']]} for h in histories],indent=2,default=lambda x:x.item()))
