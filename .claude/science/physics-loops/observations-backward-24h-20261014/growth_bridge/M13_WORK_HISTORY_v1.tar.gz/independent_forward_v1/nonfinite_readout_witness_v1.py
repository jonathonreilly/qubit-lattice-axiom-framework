"""Narrow post-exposure nonfinite-admission witness. No ODE or aggregate run."""
from pathlib import Path
import ast, hashlib, json, math
import sympy as s
HERE=Path(__file__).resolve().parent
source=HERE/'canonical_source_v1/scalar_growth_lensing_inverse.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='5561f381fd2fd82ae1a979dcd8d79f275f8b4a500f3fbbc607c8a82ad63efecf'
tree=ast.parse(source.read_text())
wanted={'real_number','candidate_domain','coupling_shape','assess_candidate'}
module=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted],type_ignores=[])
ns={'s':s};exec(compile(module,str(source),'exec'),ns)
candidate={'beta':.29,'B':.2,'C':2.}
q=.1;Z=ns['coupling_shape'](candidate['beta'],q)
rows=[{'q':q,'J':0.,'P':candidate['B']*candidate['C']/Z,'What':1.},
      {'q':q,'J':1.,'P':math.inf,'What':1.}]
result=ns['assess_candidate'](rows,candidate,[0,1],1e-9)
assert result['sampled_domain_passed'] is True
assert result['within_fixed_threshold'] is True
assert result['relative_residuals'][0]==0.
assert math.isnan(result['relative_residuals'][1])
record={'scope':'Finite six-case trajectories unaffected; generic candidate assessment admits a nonfinite readout.',
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'reader_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'candidate':candidate,
        'rows':[{**row,'P':repr(row['P']) if not math.isfinite(row['P']) else row['P']} for row in rows],
        'actual_result':{**result,'relative_residuals':[repr(v) if not math.isfinite(v) else v for v in result['relative_residuals']]},
        'expected_generic_admission':False,
        'reason':'max([0.0,nan]) is 0.0; q/J and candidate gates do not check P/What or finite residuals.'}
(HERE/'NONFINITE_READOUT_WITNESS_v1.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps(record,indent=2,allow_nan=False))
