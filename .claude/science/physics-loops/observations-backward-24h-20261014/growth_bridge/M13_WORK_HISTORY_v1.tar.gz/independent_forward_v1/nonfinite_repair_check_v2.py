"""Narrow repair reproduction. Uses frozen functions only; no ODE/aggregate run."""
from pathlib import Path
import ast,copy,hashlib,json,math
import sympy as s
import mpmath as mp
HERE=Path(__file__).resolve().parent
source=HERE/'canonical_source_v2/scalar_growth_lensing_inverse.py'
old=HERE/'canonical_source_v1/scalar_growth_lensing_inverse.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='9c310f719998519c476aa2a28bc79860ff9b11ab59806288f452cf50336a1ae4'

def funcs(path):return {x.name:x for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
newf=funcs(source);oldf=funcs(old)
changed=[name for name in newf if ast.dump(newf[name],include_attributes=False)!=ast.dump(oldf[name],include_attributes=False)]
checks=[]
def check(name,value,detail=None):checks.append({'name':name,'passed':bool(value),'detail':detail})
check('only_affected_functions_changed',set(changed)=={'assess_candidate','inverse_rows','extended_controls'},changed)
for name in ['source_model','forward_controls','candidate_domain']:
    check(name+'_unchanged',ast.dump(newf[name],include_attributes=False)==ast.dump(oldf[name],include_attributes=False))
wanted=['real_number','candidate_domain','coupling_shape','assess_candidate','inverse_rows']
module=ast.Module(body=[copy.deepcopy(newf[name]) for name in wanted],type_ignores=[])
ns={'s':s,'mp':mp};exec(compile(module,str(source),'exec'),ns)
assess=ns['assess_candidate'];inverse=ns['inverse_rows'];Z=ns['coupling_shape']
candidate={'beta':.29,'B':.2,'C':2.};q=.1
valid=[{'q':q,'J':float(j),'P':candidate['B']*(j+candidate['C'])/Z(candidate['beta'],q),'What':1.} for j in range(3)]
witness=[dict(valid[0]),{**valid[1],'P':float('inf')}]
witness_result=assess(witness,candidate,[0,1],1e-9)
check('original_nonfinite_P_witness_refused',not witness_result['within_fixed_threshold'] and not witness_result['sampled_domain_passed'],witness_result)
regular=assess(valid,candidate,[0,1,2],1e-9)
check('positive_finite_rows_still_admitted',regular['within_fixed_threshold'] and regular['sampled_domain_passed'],regular)
for field in ['P','What']:
    for value,label in [(float('inf'),'inf'),(float('-inf'),'negative_inf'),(float('nan'),'nan'),(0.,'zero'),(-1.,'negative')]:
        rows=[dict(r) for r in valid];rows[1][field]=value
        answer=assess(rows,candidate,[0,1,2],1e-9)
        check(field+'_'+label+'_refused',not answer['within_fixed_threshold'] and not answer['sampled_domain_passed'])
for value,label in [(float('inf'),'inf'),(float('nan'),'nan'),(0.,'zero'),(-1.,'negative')]:
    answer=assess(valid,candidate,[0,1],value)
    check('tolerance_'+label+'_refused',not answer['within_fixed_threshold'] and not answer['sampled_domain_passed'])
overflow_rows=[dict(valid[0]),{'q':q,'J':1.,'P':1e308,'What':1e308}]
overflow=assess(overflow_rows,candidate,[0,1],1e-9)
check('finite_inputs_with_overflow_refused',not overflow['within_fixed_threshold'] and overflow['sampled_domain_passed'] and overflow.get('arithmetic_failure')=='nonfinite residual',overflow)
for field in ['q','P','What','J']:
    for value,label in [(float('inf'),'inf'),(float('nan'),'nan')]:
        rows=[dict(r) for r in valid];rows[1][field]=value
        try:
            inverse(rows);refused=False
        except ValueError:
            refused=True
        check('calibration_'+field+'_'+label+'_refused',refused)
for n in [0,1,2,4]:
    rows=(valid+valid)[:n]
    try:
        inverse(rows);refused=False
    except ValueError:refused=True
    check('calibration_row_count_'+str(n)+'_refused',refused)
old_result=json.loads((HERE/'author_v2/FORWARD_RESULTS_v2.json').read_text())
protocol=json.loads((HERE/'author_v2/FORWARD_PROTOCOL_v1.json').read_text())
comparison=[]
for history in old_result['histories']:
    with mp.workdps(protocol['inverse_arithmetic_digits']):
        got=inverse([history['rows'][i] for i in protocol['calibration_indices']])
    same=got==history['inverse']
    check('case%d_mode%d_unchanged_inverse'%(history['caseid'],history['modeid']),same)
    assessments=[assess(history['rows'],candidate,protocol['synthetic_test_indices'],protocol['integrated_identity_relative_tolerance']) for candidate in got['candidates']]
    same_assess=len(assessments)==len(history['later_tests']) and all(a['sampled_domain_passed'] and a['relative_residuals']==b['relative_residuals'] and a['within_fixed_threshold']==b['within_fixed_threshold'] for a,b in zip(assessments,history['later_tests']))
    check('case%d_mode%d_unchanged_finite_assessment'%(history['caseid'],history['modeid']),same_assess)
    comparison.append({'caseid':history['caseid'],'modeid':history['modeid'],'unchanged_inverse':same,'unchanged_assessment':same_assess})
record={'scope':'Narrow repaired-function calls on exact fixtures and reused synthetic rows; no ODE, symbolic aggregate, observations, or source mutation.',
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),
        'original_witness_result':witness_result,'finite_overflow_result':overflow,'reused_histories':comparison,
        'original_finding_preserved_in':'NONFINITE_READOUT_WITNESS_v1.json'}
(HERE/'NONFINITE_REPAIR_RESULTS_v2.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps(record,indent=2,allow_nan=False))
assert all(c['passed'] for c in checks)
