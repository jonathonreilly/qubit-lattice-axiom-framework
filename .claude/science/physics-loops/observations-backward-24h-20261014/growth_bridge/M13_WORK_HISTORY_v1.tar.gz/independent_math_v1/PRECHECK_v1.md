# Independent growth/Weyl inverse: proof checkpoint v1

This is a focused independent mathematical derivation by the checking agent. Root remains scientific author. No new author growth note/code, raw observations, network source, or new empirical data has been read. The supplied M12 action is a conditional candidate, not an observed action. This document makes no novelty claim or formal review verdict.

## Exposure and source

The supplied M12 source is copied as `SUPPLIED_M12_NOTE_v1.md`, SHA256 `dde833e8bcb69f4ab5e03eb911aa534dbf23647d5fb03cd1be469bac2e977122`. Its entire final content was already read through the prior complete review and final affected-source supplements; its action and reconstruction sections were reread for this calculation. Current context base `e2873beca6af9954be49c4a9bbe8d98f05c9e69b` is parent-supplied, not independently verified with Git.

The equations below, including the sufficient rank-four identification condition and its distinction from a necessary condition, were derived before my message to root reporting them. After that message, but before saving this checkpoint, root reported qualitatively that a manufactured example had two admissible three-epoch roots and sometimes four-epoch ambiguity. That qualitative result is an exposure, not an independently blind finding here. No author derivation, values, source, or implementation was opened. This checkpoint does not claim otherwise.

## 1. Physical suppliers and conventions

Let N=ln a, E=H/H0>0, h=H'/H, and K=k_com/a. Primes denote N derivatives. Work with a real Fourier component on a connected interval with R and L nowhere zero. A common fixed complex phase can first be removed if such a coherent mode interpretation is supplied. Define

    R=delta', L= -a^3 K^2(Phi+Psi)/(3H0^2),
    P=L/R, P3=R'/R.

The Newtonian-gauge convention is ds^2=-(1+2Psi)dt^2+a^2(1-2Phi)dx^2. Conserved pressureless matter has rho=rho0 a^-3. Write B=rho0/(3H0^2)>0; B has the units of the Jordan tensor coefficient F and is NOT assumed measured.

The field-to-observable map used here requires supplied linear dust dynamics, negligible matter anisotropic stress, a common physical clock and known H(N), a known Fourier/lensing transfer, and known relative lensing/velocity calibration. At leading subhorizon quasistatic order, in a light coupled scalar regime, require

    -K^2(Phi+Psi)=rho delta/F,
    F(Phi-Psi)=delta F,
    K^2 delta F=q rho delta.                                      (1)

For a single coupled Jordan field, the scalar leading equation is (2omega+3) box delta F=delta T=-rho delta, so q=1/(2omega+3). The 00 constraint is -2F K^2 Phi=rho delta-K^2 delta F, which fixes the signs and factor two. Thus

    -K^2 Psi=rho delta (1+q)/(2F).                               (2)

For the supplied multi-field candidate, using q=q_geom=|d ln sqrt(C)|_K^2 needs a controlled high-momentum response in which the full mass/mixing/time terms are negligible (or another derivation of precisely (1)). It is NOT obtained merely by identifying the background stress inverse q_rec with q_geom. M12 explicitly distinguishes those quantities under transverse motion. Equations (1) are the response premises for this proof; their physical accuracy is not proved by the algebra below.

Finite effective scalar mass can instead give q_eff=q_geom K^2/(K^2+m_eff^2) in a separately supplied one-mode Yukawa approximation. Unknown masses, screening, mixing, extra clustering sources, curvature corrections, and time derivative terms prevent a general identification of q_geom from the algebraic q_obs below. A mismatch then diagnoses the composed candidate-plus-response assumptions, not the full scalar theory alone.

### Velocity qualification

For the usual velocity divergence theta, set V=-theta/(aH). The exact linear dust equations in this gauge give

    delta'=V+3Phi',
    V'+(2+h)V=-K^2 Psi/H^2.

Consequently the task's R=delta' obeys

    R'+(2+h)R=-K^2 Psi/H^2+3[Phi''+(2+h)Phi'].                   (3)

Treating ideal velocities as a direct measurement of R and dropping the last term require the quasistatic approximation or an explicitly corrected observation map. Linear theory alone does not remove this term. Below the reduced growth equation is used conditional on that approximation/correction. A velocity/lensing ratio built directly from V has a force interpretation without this continuity substitution, but it cannot be integrated to delta without the Phi contribution; those are different input problems.

## 2. A force-to-Weyl quotient without rho0 or mode normalization

Under (1) and the reduced growth equation,

    L=B delta/F,
    R'+(2+h)R = [3/(2a^3 E^2)](1+q)L.                         (4)

Hence

    q_obs = [2a^3 E^2/(3P)](P3+2+h)-1.                       (5)

This cancels unknown B, the value of delta, and a common nonzero constant mode amplitude multiplying R and L. It does not cancel independent channel gains, a time-dependent amplitude, unknown clock derivatives, or an incorrectly identified growth tracer. The result is an exact algebraic consequence of the explicitly approximate/supplied response equations, not an exact finite-scale gravity theorem.

If either R or L vanishes, do not use (5) through that point. The undivided equation (4) remains the appropriate form. Ratios and derivative estimation also require nonzero H and sufficient smoothness.

## 3. The unavoidable density integration constant

Choose a reference N* and define I(N)=integral from N* to N of R(s)ds. Conservation of the density derivative gives

    delta=I+d,
    F/B=(I+d)/L.                                              (6)

The real constant d is an unknown initial density contrast in the chosen mode normalization. It has not been chosen, predicted, or measured. Removing it by setting d=0 is an extra state assumption. With only R and L, (6) gives a one-parameter family of relative F histories, and B independently remains an overall normalization freedom.

A common amplitude A rescales R,L,I,d by A and leaves F/B unchanged. Changing the primitive anchor translates I by a constant and d by its negative. Neither operation changes the physics. The inequalities F>0 and any candidate-domain conditions must be checked on the tested interval; they can restrict d without uniquely choosing it.

## 4. Candidate shape inversion and exact interval closure

Use b=alpha^2, 1/4<b<1/3, to distinguish the candidate parameter from the scale factor. M12 supplies

    q=b(F-Fc)/(F-3bFc), Fc>0, F>Fc.

Its inverse and derivative are

    0<q<b,
    r_b(q)=F/Fc=b(1-3q)/(b-q),
    dr_b/dq=b(1-3b)/(b-q)^2.                                 (7)

An isolated q value only restricts b>max(1/4,q); it does not identify b. Write v=Fc/B>0. Combining (6) and (7), the exact reduced closure condition is

    (b-q)(I+d)=b(1-3q)vL.                                    (8)

It is necessary and sufficient for the lensing/conservation/candidate-shape part of this reduced response problem, given smooth supplied inputs and all strict gates. To include the growth part, q must be the quantity (5). Then (4) follows by substitution. This is NOT sufficiency for the full cosmological candidate background: its metric equations, potential, scalar equations, and actual matter solution remain independent obligations.

A convenient linear lift defines u=1/b, w=u d. Then (8) becomes

    [-q I, 1, -q, -(1-3q)L] . (u,d,w,v) = -I,                (9)
    w=u d.                                                   (10)

If four epoch rows in (9) have rank four, there is at most one lifted solution. It must additionally satisfy (10), 3<u<4, v>0, 0<q<1/u and (I+d)/L>v on the interval. A unique linear fit failing (10) is not a candidate solution. If every epoch satisfies (9), (10) and the gates, it is a reduced response solution. Additional sampled epochs test the chosen candidate only on those epochs. They do not establish an interval identity or a full physical history.

Rank four is a sufficient uniqueness gate. It is not asserted necessary: the nonlinear compatibility (10) can isolate a solution in a rank-deficient lift. Conversely, a three-row fit or any rank-deficient interval can have several or continuously many admissible solutions. Neither number of epochs nor a small residual alone establishes uniqueness. One must enumerate/characterize all admissible solutions, retain domains, and test the interval rather than silently select one root.

### Differential form that removes d

Let J=L'/L=P'/P+P3. Differentiating F L/B=delta yields

    B/F=P(F'/F+J).

For a trial b define

    K_b=P[r_b(q)J+r_b,q(q)q']
       =bP[(1-3q)J/(b-q)+(1-3b)q'/(b-q)^2].                (11)

The candidate demands K_b=B/Fc=1/v, a positive constant. Conversely, constant positive K_b on a connected interval gives (r_b L)'=R/v, whose integral is (8) for some d. This is equivalent to interval closure, within the same smooth strict domains. It needs q' (thus additional derivatives of the measured-side inputs); (9) avoids that extra differentiation but still requires a genuine primitive I and q from (5). Finite sampled R values do not uniquely supply either derivatives or an exact primitive without interpolation/error assumptions.

The reconstructed relative history is F/B=v r_b(q). The candidate parameter k in M12 is

    k=(1-2sqrt(1-3b))/3,
    Q0/B=4b v/(1+k)^2,
    Q/B=4b v/(1+k).                                          (12)

These are conditional fitted shape/relative-normalization quantities, not a first-principles selection of them. The perturbative bridge alone does not determine Hv, nu or the potential. The symmetry (F,Fc,Q0,rho0) -> lambda (F,Fc,Q0,rho0), lambda>0, leaves (4), R,L and q unchanged. Absolute F, a measured Newton constant, and an absolute matter/vacuum scale cannot be reconstructed without another calibrated dimensionful input.

## 5. Explicit degeneracy and failed shortcuts

A constant q=q0 in the strict candidate domain means r_b is constant and therefore F is constant in this reduced response model. Then L'/R=B/F=S must be positive and constant. For every admissible b>q0, choose v=1/(S r_b(q0)); these give the same reduced response data. For example q0=1/5, S=1/2, B=1 and F=2 can use either

    b=2/7, r=4/3, Fc=3/2,
    b=3/10, r=6/5, Fc=5/3.

Both give L=delta/2 and the same q. This is a reduced-response identifiability counterexample, not an assertion that both constant-F histories solve the supplied candidate's full background equations with changing dust trace. M12's constant-field scalar compatibility remains separate.

Other failures deliberately retained in this proof:

* F proportional to 1/L assumes fixed delta; delta'=R generally contradicts it.
* Setting d=0 silently supplies initial density information.
* Fitting the four lifted coefficients without w=u d admits spurious candidates.
* A fitted root is not unique merely because the algorithm returned one root.
* Substituting q_rec for q_geom under transverse motion is invalid.
* A finite-mass response can have q_eff different from q_geom even with ideal noiseless measurements.
* Treating velocities as delta' exactly omits the 3Phi' continuity term.
* Setting an unknown observation/model discrepancy to zero by definition does not derive an error budget.

## 6. Admission and scope

No matter normalization, initial density amplitude, F history, scalar state, error bound, or new observation was supplied or inferred in this check. The exact statements concern the reduced equations and candidate shape on a strict smooth domain. With actual finite data, one needs the physical measurement map, correlated calibration and error control, time derivatives/integrals, and bounds on every discarded finite-scale term. Calibration/development data used to choose b, d or v are not independent tests. Pointwise q outside the light positive candidate range refutes the composed reduced assumptions only after their errors are controlled; it is not a universal no-go for radio tracking or the full scalar action.

The forthcoming standalone controls are synthetic algebraic fixtures. They check signs, factors, nonzero d, the compatibility equation, shape identification under an explicit rank gate and non-identification in a counterexample. They do not simulate a solution of the complete candidate background and must not be counted as observational validation.
