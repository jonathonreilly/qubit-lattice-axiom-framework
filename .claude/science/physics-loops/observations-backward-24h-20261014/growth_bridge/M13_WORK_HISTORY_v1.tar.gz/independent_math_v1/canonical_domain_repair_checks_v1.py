"""Only affected canonical domain/assessment functions; no aggregate or ODE."""
from pathlib import Path
import ast,hashlib,json,sympy as s
p=Path(__file__).resolve().parent
src=(p/'canonical_helper_v3.py').read_text()
names={'real_number','coupling_shape','candidate_domain','assess_candidate'}
nodes=[n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name in names]
ns={'s':s};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<frozen repaired domain functions>','exec'),ns)
fn=ns['candidate_domain'];assess=ns['assess_candidate'];checks=[]
def ck(name,ok,detail):checks.append({'name':name,'passed':bool(ok),'detail':detail})
rows=[{'q':s.Rational(1,10),'J':s.Integer(0)}]
beta=s.Rational(1,3)-s.Rational(1,10**20)
near=fn(rows,{'beta':beta,'B':s.Integer(1),'C':s.Integer(1)})
ck('exact_interior_boundary_now_accepted',near,{'beta':str(beta),'accepted':bool(near)})
for key in ['B','C']:
 candidate={'beta':s.Rational(29,100),'B':s.Integer(1),'C':s.Integer(1)};candidate[key]=float('inf')
 result=fn(rows,candidate);ck('infinite_'+key+'_now_refused',not result,{'accepted':bool(result)})
pole=assess([{'q':0.29,'J':0.0,'P':1.0,'What':1.0}],{'beta':0.29,'B':1.0,'C':1.0},[0],1e-9)
ck('same_float_pole_is_recorded_without_division',pole['relative_residuals']==[] and not pole['sampled_domain_passed'] and not pole['within_fixed_threshold'],pole)
valid=assess([{'q':s.Rational(1,5),'J':0,'P':s.Rational(3,4),'What':1}],{'beta':s.Rational(2,7),'B':1,'C':1},[0],s.Rational(1,1000))
ck('valid_exact_candidate_still_evaluated',valid['sampled_domain_passed'] and valid['within_fixed_threshold'] and valid['relative_residuals']==[0],valid)
out={'source_sha256':hashlib.sha256(src.encode()).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Five targeted affected-source controls only; no aggregate, ODE or empirical data','checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}
(p/'canonical_domain_repair_results_v1.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
print(json.dumps({'passed':out['passed'],'failed':out['failed'],'source_sha256':out['source_sha256']},indent=2))
raise SystemExit(bool(out['failed']))
