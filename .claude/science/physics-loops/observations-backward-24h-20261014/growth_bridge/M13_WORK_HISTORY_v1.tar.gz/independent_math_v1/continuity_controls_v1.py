from pathlib import Path
import sympy as s,hashlib,json
p=Path(__file__).resolve().parent
x=s.symbols('x',positive=True); checks=[]
def ck(name,e):
    v=s.factor(s.cancel(e));checks.append({'name':name,'passed':v==0,'residual':str(v)})
D=lambda e:x*s.diff(e,x)
delta=x*x+s.Rational(3,5);Phi=x/100;W=D(delta)-3*D(Phi)
Iw=x*x-1-3*(x-1)/100;J=Iw+3*(Phi-Phi.subs(x,1));d=delta.subs(x,1)
ck('linear_dust_continuity',D(delta)-W-3*D(Phi))
ck('velocity_primitive_derivative',D(Iw)-W)
ck('corrected_density_primitive',J+d-delta)
checks.append({'name':'uncorrected_primitive_fails','passed':s.factor(Iw+d-delta)!=0,'residual':str(s.factor(Iw+d-delta))})
b=s.Rational(2,7);F=2*(1+x);Fc=2;B=s.Rational(3,2);v=Fc/B
q=b*(F-Fc)/(F-3*b*Fc);L=B*delta/F
ck('corrected_candidate_closure',(b-q)*(J+d)-b*(1-3*q)*v*L)
ck('common_mode_amplitude',(-7*J-7*d)/(-7*L)-F/B)
# Derive Phi from the exact Euler potential and Weyl sum, without gravitational field substitutions.
S,Psi,HH,KK,A=s.symbols('S Psi HH KK A',nonzero=True)
euler=-KK*Psi/HH
phi_reconstructed=S+HH*euler/KK
ck('potential_map_sign',phi_reconstructed-(S-Psi))
rb=b*(1-3*q)/(b-q)
ck('corrected_differential_identity',D(rb*L)-(W+3*D(Phi))/v)
out={'scope':'Independent exact synthetic continuity controls; no empirical or full background claim','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'passed':sum(i['passed'] for i in checks),'failed':sum(not i['passed'] for i in checks)}
(p/'CONTINUITY_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'failed':out['failed']},indent=2))
raise SystemExit(bool(out['failed']))
