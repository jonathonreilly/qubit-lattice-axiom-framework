#!/usr/bin/env python3
"""Independent exact synthetic checks; no author imports or empirical inputs."""
from pathlib import Path
import json, hashlib, datetime, sympy as sp
ROOT=Path(__file__).resolve().parent
checks=[]
def record(name, condition, **evidence):
    ok=bool(condition)
    checks.append({'name':name,'passed':ok,'evidence':{k:str(v) for k,v in evidence.items()}})
    return ok

def zero(name, expr):
    val=sp.factor(sp.cancel(expr))
    record(name,val==0,residual=val)

x=sp.symbols('x',positive=True)
b=sp.Rational(2,7); Fc=sp.Integer(2); B=sp.Rational(3,2)
F=Fc*(1+x); delta=x*x+sp.Rational(3,5); R=2*x*x
I=x*x-1; d=sp.Rational(8,5); v=Fc/B
q=sp.cancel(b*(F-Fc)/(F-3*b*Fc)); L=sp.cancel(B*delta/F)
def DN(expr): return sp.factor(x*sp.diff(expr,x))
def rb(bt,qt): return sp.cancel(bt*(1-3*qt)/(bt-qt))
def rbd(bt,qt): return sp.cancel(bt*(1-3*bt)/(bt-qt)**2)
def lift(matI,matq,matL,points):
    rows=[]; rhs=[]
    for point in points:
        ii,qq,ll=[sp.cancel(e.subs(x,point)) for e in (matI,matq,matL)]
        rows.append([-qq*ii,sp.Integer(1),-qq,-(1-3*qq)*ll]);rhs.append(-ii)
    return sp.Matrix(rows),sp.Matrix(rhs)
zero('geometric_q_exact',q-2*x/(7*x+1))
zero('candidate_inverse',rb(b,q)-F/Fc)
zero('density_primitive_retains_offset',DN(I+d)-R)
zero('relative_F_inverse',(I+d)/L-F/B)
zero('growth_kinematic_Weyl',L-B*delta/F)
record('d_zero_shortcut_fails',sp.factor(I/L-F/B)!=0,residual=sp.factor(I/L-F/B))
J=DN(L)/L; P=L/R
Kb=sp.factor(P*(rb(b,q)*J+rbd(b,q)*DN(q)))
zero('differential_constant_B_over_Fc',Kb-B/Fc)
wrongb=sp.Rational(3,10)
Kwrong=sp.factor(P*(rb(wrongb,q)*J+rbd(wrongb,q)*DN(q)))
record('wrong_shape_not_constant',sp.factor(Kwrong.subs(x,1)-Kwrong.subs(x,2))!=0,first=Kwrong.subs(x,1),second=Kwrong.subs(x,2))
points=[sp.Integer(z) for z in (1,2,3,5)]
M,y=lift(I,q,L,points)
record('four_row_rank_gate',M.rank()==4,rank=M.rank(),determinant=M.det())
sol=M.inv()*y if M.det()!=0 else sp.zeros(4,1)
expected=sp.Matrix([1/b,d,d/b,v])
record('exact_lift_recovery',sol==expected,actual=sol,expected=expected)
zero('lift_product_compatibility',sol[2]-sol[0]*sol[1])
row7,rhs7=lift(I,q,L,[sp.Integer(7)])
zero('additional_synthetic_epoch',(row7*sol-rhs7)[0])
Mbad=M.copy(); idx=1; qq=q.subs(x,points[idx]); Mbad[idx,3]-=(1-3*qq)/100
bad=Mbad.inv()*y
record('unconstrained_lift_false_solution',sp.factor(bad[2]-bad[0]*bad[1])!=0,product_residual=sp.factor(bad[2]-bad[0]*bad[1]))
amp=sp.Rational(-3,2); MA,ya=lift(amp*I,q,amp*L,points); sa=MA.inv()*ya
record('common_amplitude_shape_invariance',sa[0]==sol[0] and sa[3]==sol[3] and sa[1]==amp*d,solution=sa)
shift=sp.Rational(9,7); Ms,ys=lift(I+shift,q,L,points); ss=Ms.inv()*ys
record('primitive_anchor_invariance',ss==sp.Matrix([1/b,d-shift,(d-shift)/b,v]),solution=ss)
lam=sp.Rational(11,3)
zero('absolute_scaling_invariance',lam*B*delta/(lam*F)-L)
a3,E2,PP,hh,qq=sp.symbols('a3 E2 PP hh qq',nonzero=True)
p3=3*(1+qq)*PP/(2*a3*E2)-2-hh
zero('force_Weyl_quotient_factor',2*a3*E2*(p3+2+hh)/(3*PP)-1-qq)
record('wrong_growth_factor_fails',sp.factor(a3*E2*(p3+2+hh)/(3*PP)-1-qq)!=0)
rhoD,ff,kk,coup=sp.symbols('rhoD ff kk coup',positive=True)
dF=coup*rhoD/kk
Phi=-(rhoD-kk*dF)/(2*ff*kk); Psi=Phi-dF/ff
zero('metric_lensing_sign',-kk*(Phi+Psi)-rhoD/ff)
zero('metric_force_sign_factor',-kk*Psi-rhoD*(1+coup)/(2*ff))
# Constant-q reduced-system degeneracy; deliberately no full background claim.
q0=sp.Rational(1,5); bb1=sp.Rational(2,7); bb2=sp.Rational(3,10)
Fc1=sp.Rational(3,2); Fc2=sp.Rational(5,3); F0=sp.Integer(2)
zero('constant_q_candidate_one',bb1*(F0-Fc1)/(F0-3*bb1*Fc1)-q0)
zero('constant_q_candidate_two',bb2*(F0-Fc2)/(F0-3*bb2*Fc2)-q0)
MC,yC=lift(I,sp.sympify(q0),delta/2,points)
record('constant_q_rank_deficiency',MC.rank()<4,rank=MC.rank())
# Exact nonconstant interval ambiguity derived separately from lifted fitting.
j=sp.symbols('j',nonnegative=True)
b1=sp.Rational(2,7);b2=sp.Rational(3,10);d1=sp.Integer(1);d2=sp.Integer(2)
v1=sp.Integer(1);v2=sp.Rational(20,9);llambda=sp.cancel(v1*b1/(v2*b2))
qj=(11*j+2)/(40*j+10); Lj=3*(j+1)*(j+2)/(2*(7*j+4))
qmob=((llambda*b2-b1)*j+llambda*b2*d2-b1*d1)/((llambda-1)*j+llambda*d2-d1)
zero('Mobius_family_identity',qj-qmob)
zero('interval_candidate_one',j+d1-v1*Lj*rb(b1,qj))
zero('interval_candidate_two',j+d2-v2*Lj*rb(b2,qj))
record('interval_strict_domains',sp.ask(sp.Q.positive(qj)) and sp.ask(sp.Q.positive(sp.factor(b1-qj))) and sp.ask(sp.Q.positive(sp.factor(b2-qj))),q=qj,b1_minus_q=sp.factor(b1-qj),b2_minus_q=sp.factor(b2-qj))
record('interval_q_varies',sp.factor(sp.diff(qj,j))!=0,derivative=sp.factor(sp.diff(qj,j)))
MM,yy=lift(x,qj.subs(j,x),Lj.subs(j,x),[sp.Integer(z) for z in (0,1,2,3,4)])
record('five_epoch_ambiguity_rank',MM.rank()<4,rank=MM.rank())
qq1=qj.subs(j,0);qq2=qj.subs(j,1)
T1=sp.cancel(rb(b1,qq2)/rb(b1,qq1));T2=sp.cancel(rb(b2,qq2)/rb(b2,qq1))
record('tensor_ratios_separate_shapes',T1==sp.Rational(11,6) and T2==sp.Rational(11,8) and T1!=T2,T1=T1,T2=T2)
for n,(bt,T) in enumerate([(b1,T1),(b2,T2)],1):
    Y=sp.cancel(T*(1-3*qq1)/(1-3*qq2))
    zero('tensor_inverse_'+str(n),(Y*qq2-qq1)/(Y-1)-bt)
zero('constant_q_tensor_nonidentification',rb(b1,q0)/rb(b1,q0)-rb(b2,q0)/rb(b2,q0))
record('finite_mass_changes_response',q0/(1+1)!=q0,q_geom=q0,q_eff=q0/2)
A=sp.symbols('A');Phi_test=x
record('continuity_correction_not_identically_zero',sp.factor(3*(DN(DN(Phi_test))+A*DN(Phi_test)))!=0,correction=sp.factor(3*(DN(DN(Phi_test))+A*DN(Phi_test))))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Independent exact synthetic algebra, not full background dynamics or observations; no author imports','checks':checks,'passed':sum(t['passed'] for t in checks),'failed':sum(not t['passed'] for t in checks)}
(ROOT/'CONTROL_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'source_sha256':result['source_sha256'],'failed_names':[c['name'] for c in checks if not c['passed']]},indent=2))
raise SystemExit(0 if result['failed']==0 else 1)
