"""Focused post-exposure exact checks of the v2 interval classification."""
from pathlib import Path
import sympy as s,json,hashlib
p=Path(__file__).resolve().parent
j,u,v,w,x,b,c,B,bother=s.symbols('j u v w x b c B bother')
D=u*x-v*w
b2=(v-u*c)/(x-w*c)
c2=(b*x-v)/(b*w-u)
B2=B*(b2/b)*(b*w-u)/(b2*w-u)
l1=(b*w-u)*j+b*x-v
l2=(b2*w-u)*j+b2*x-v
checks=[]
def zero(name,expr):
    z=s.factor(s.cancel(expr));checks.append({'name':name,'passed':z==0,'residual':str(z)})
def record(name,ok,detail):checks.append({'name':name,'passed':bool(ok),'detail':str(detail)})
zero('general_sufficiency_polynomial',B/b*l1*(j+c)-B2/b2*l2*(j+c2))
zero('second_denominator_identity',b2*w-u+D/(x-w*c))
other=(bother*w-u)*j+bother*x-v
zero('linear_factor_resultant',(b*w-u)*(bother*x-v)-(bother*w-u)*(b*x-v)-(b-bother)*D)
zero('exchange_first_factor',l2-(b2*w-u)*(j+c))
zero('exchange_second_factor',l1-(b*w-u)*(j+c2))
# A valid first candidate throughout 0<=J<=1 with no finite beta2:
# q=(J/10+1/5)/(J+1), C1=1 makes the rational continuation pole at -C1.
pole={u:s.Rational(1,10),v:s.Rational(1,5),w:1,x:1,b:s.Rational(29,100),c:1,B:1}
record('continuation_pole_edge',(x-w*c).subs(pole)==0 and D.subs(pole)!=0,{'denominator':(x-w*c).subs(pole),'D':D.subs(pole)})
record('pole_has_no_finite_matching_factor',(bother*x-v-bother*w*c+u*c).subs(pole)==-s.Rational(1,10),s.factor((bother*x-v-bother*w*c+u*c).subs(pole)))
# First linear factor is constant: a degree-one polynomial cannot equal a
# distinct beta's degree-two product with finite nonzero B2.
degree={u:s.Rational(29,100),v:s.Rational(1,5),w:1,x:1,b:s.Rational(29,100),c:2,B:1}
record('first_factor_constant_edge',(b*w-u).subs(degree)==0 and D.subs(degree)!=0,D.subs(degree))
record('degree_drop_exact',s.Poly((l1*(j+c)).subs(degree),j).degree()==1,s.Poly((l1*(j+c)).subs(degree),j))
# Repeated root gives only the original beta, not a second distinct candidate.
repeat={u:-s.Rational(9,100),v:s.Rational(1,5),w:0,x:1,b:s.Rational(29,100),c:1,B:1}
record('repeated_root_not_distinct',s.cancel(b2.subs(repeat))==repeat[b] and s.cancel(c2.subs(repeat))==1 and s.cancel(B2.subs(repeat))==1,(b2.subs(repeat),c2.subs(repeat),B2.subs(repeat)))
# Both beta values are within the shape interval and above the observed q,
# but B2<0; retain the positive-B gate.
negative={u:s.Rational(11,40),v:-s.Rational(19,40),w:1,x:-2,b:s.Rational(29,100),c:3,B:1}
record('negative_B_gate_essential',s.cancel(b2.subs(negative))==s.Rational(13,50) and s.cancel(B2.subs(negative))==-s.Rational(26,29),{'beta2':s.cancel(b2.subs(negative)),'B2':s.cancel(B2.subs(negative)),'C2':s.cancel(c2.subs(negative))})
qneg=s.factor(((u*j+v)/(w*j+x)).subs(negative))
record('negative_B_first_candidate_domains',all(0<qneg.subs(j,z)<s.Rational(13,50) for z in [s.Rational(0),s.Rational(1,2),s.Rational(1)]) and all((j+3).subs(j,z)>0 for z in [0,1]),qneg)
# Previously independently derived positive-B, distinct-shape interval fixture.
positive={u:11,v:2,w:40,x:10,b:s.Rational(2,7),c:1,B:1}
record('positive_interval_formula_recovery',s.cancel(b2.subs(positive))==s.Rational(3,10) and s.cancel(c2.subs(positive))==2 and s.cancel(B2.subs(positive))==s.Rational(9,20),(b2.subs(positive),c2.subs(positive),B2.subs(positive)))
# Constant J warning: determinant of a chosen representation alone does not
# ensure a varying observed q. Do not apply degree/divisibility reasoning then.
record('constant_J_scope_witness',D.subs(pole)!=0 and s.cancel(((u*j+v)/(w*j+x)).subs(pole).subs(j,0))==s.Rational(1,5),'At J=0 only, q=1/5 despite nonzero Mobius determinant; constant-q branch applies.')
out={'type':'Post-exposure focused symbolic/source check, not author aggregate','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'passed':sum(t['passed'] for t in checks),'failed':sum(not t['passed'] for t in checks)}
(p/'INTERVAL_V2_CHECK_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'failed':out['failed'],'failed_names':[t['name'] for t in checks if not t['passed']]},indent=2))
raise SystemExit(bool(out['failed']))
