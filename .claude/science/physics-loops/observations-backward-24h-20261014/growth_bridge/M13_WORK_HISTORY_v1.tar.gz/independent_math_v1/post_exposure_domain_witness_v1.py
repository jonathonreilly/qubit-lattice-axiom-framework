"""Reproduce the preserved v1 missing-positive-q domain witness only."""
from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_author_growth_source',p/'AUTHOR_growth_inverse_v1.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=m.s;b=s.Rational(2,7);rows=[]
for n in [s.Rational(0),s.Rational(1,4),s.Rational(1,2)]:
    q=-s.Rational(1,10)+n/100;z=m.coupling_shape(b,q)
    rows.append({'q':q,'P':(1+n)/z,'R':s.Integer(1),'I':n})
result=m.integrated_inverse(rows)
ratio=m.coupling_shape(b,rows[-1]['q'])/m.coupling_shape(b,rows[0]['q'])
tensor=m.tensor_inverse(rows[0]['q'],rows[-1]['q'],ratio)
assert all(r['q']<0 for r in rows)
assert any(v['beta']==b for v in result['candidates'])
assert tensor==b
print(json.dumps({'invalid_domain_accepted':True,'rows':rows,'inverse':result,'tensor':tensor},default=str,indent=2))
