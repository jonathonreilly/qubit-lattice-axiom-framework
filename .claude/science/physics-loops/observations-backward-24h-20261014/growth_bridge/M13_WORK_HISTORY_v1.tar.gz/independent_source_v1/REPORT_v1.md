# Independent empirical-source admission report — growth bridge v1

Reviewer: /root/launch_check. Scope: primary-source and input-admission check only. The independent conclusions were frozen in SOURCE_ADMISSION_FREEZE_v1.json before any new root theory was read. No root growth-bridge theory has been read for this report. This is not a formal audit, an independent survey reanalysis, or a scientific verdict on the root candidate.

The ACT/BOSS measurements support finite, window-weighted constraints on an E_G estimator. They do **not**, by themselves, supply a continuous physical P(N,k)=E_G(N,k), P3=d ln R/dN, their required time/scale derivatives, or F(t). This leaves a legitimate model-conditioned likelihood route: predict the measured statistics through the actual survey windows and calibration model, and propagate their joint uncertainty. It does not justify replacing the needed functions by the published central values or a derivative of an arbitrary interpolant. It is not a universal limitation on future lensing/growth observations.

The exact source versions are [ACT DR6+BOSS, arXiv:2405.12795v2](https://arxiv.org/pdf/2405.12795v2), [Observables and unobservables, arXiv:1210.0439v2](https://arxiv.org/pdf/1210.0439v2), and the necessary estimator/RSD premise [Wenzl et al., arXiv:2401.12971v2](https://arxiv.org/pdf/2401.12971v2). The last source is ACT reference 27. I did not broaden this to unrelated surveys or retrieve chains, raw maps, catalogues, numerical fit products, or posterior samples.

**What is actually reported.** ACT Table II (PDF p21), Figs12–16 and §§VI A–D report:

| Galaxy sample | Redshift selection | Effective redshift | ACT E_G, central 68.27% interval | ACT+Planck E_G |
|---|---|---:|---:|---:|
| CMASS | 0.43<z<0.70 | 0.555 | 0.31 (+0.06, −0.05) | 0.34 (+0.05, −0.05) |
| LOWZ | 0.15<z<0.43 | 0.316 | 0.49 (+0.14, −0.11) | 0.43 (+0.11, −0.09) |

These are exposed published summaries, not holdouts. The ACT-only and ACT+Planck rows share galaxy information and overlapping lensing information; they are not four independent epochs. The paper also plots scale-binned E_G and angular cross-spectra. The cosmological ranges are 48≤ell<420 for CMASS (11 bins) and 48≤ell<233 for LOWZ (8 bins); the larger 40≤ell<922 cross-spectrum range is used for validation and additional reported signal, not all admitted to the baseline E_G cosmology calculation. The angular cut is motivated by k<0.2 Mpc^-1. The separate RSD fit uses kmax=0.2 h/Mpc; these are different stated units. The binned scale-independence tests are consistency tests at finite precision, not evidence that all scale derivatives vanish. [ACT pp7,20–24](https://arxiv.org/pdf/2405.12795v2#page=7)

**Windows and estimator.** The measured quantities are projected angular spectra. The Limber mapping is q=(ell+1/2)/chi(z), integrated over the tracer kernels; it is not a measurement at one three-dimensional wavenumber and one exact time. ACT Eqs1–7 specify the line-of-sight kernels. The galaxy kernel is its weighted, normalized redshift distribution, and the CMB kernel depends on distance to last scattering. The revised estimator is
\[
 \widehat E_G^\ell(z_{\rm eff})\simeq
 \Gamma_\ell\,{\widehat C_\ell^{\kappa g_*}\over
                    \beta\,\widehat C_\ell^{gg}},\quad
 \Gamma_\ell=C_\alpha^\ell {2cH(z_{\rm eff})\over3H_0^2}
               \int dz\,{W_g(z)^2\over\widehat W_\kappa(z)} .
\]
ACT suppresses the star on its cross-weighted galaxy field. Its extra redshift weight matches the effective redshifts of the components. The estimator paper explicitly approximates H and beta as slowly varying across a galaxy sample. Effective-redshift matching reduces projection bias; it does not turn the kernels into delta functions. Mask coupling, binning and pixel/transfer corrections also matter: a theory spectrum must pass through the appropriate bandpower response, rather than simply be evaluated at a bin midpoint. [ACT pp3–4,7–10](https://arxiv.org/pdf/2405.12795v2#page=3), [estimator pp6–8, Eqs14–37](https://arxiv.org/pdf/2401.12971v2#page=6)

**Covariance and calibration.** ACT uses 400 correlated simulated map sets for its baseline angular covariance, including cross-covariance between cross- and auto-spectra. An analytic covariance and a limited jackknife are checks; the latter is not a substitute for the full invertible joint covariance. It carries the ratio distribution into E_G rather than imposing a Gaussian E_G error. The combined ACT+Planck result uses an analytic covariance with overlap/cross-covariance treatment. These are reported methods; this review did not obtain or validate the numerical covariance matrices.

The calibration premises include weighted galaxy selection/FKP and imaging corrections, linear bias cancellation with bounded redshift/footprint differences, a fiducial distance history, CMB-lensing reconstruction normalization and transfer correction, and a magnification correction calculated with a fiducial gravity/cosmology model. The paper budgets 3% and 4% systematic errors for ACT+CMASS and ACT+LOWZ. Its displayed GR expectations, 0.401±0.005 and 0.452±0.005, use external CMB+BAO LambdaCDM information; they are not two extra observations of F. The quoted sub-percent estimator calibration is demonstrated around the stated fiducial setup, not a theorem of unbiasedness for arbitrary rapidly varying scalar histories. [ACT pp4–10,18–24,26–27](https://arxiv.org/pdf/2405.12795v2#page=18)

**Velocity/growth admission.** ACT imports Cgg and beta from the estimator paper. There the BOSS monopole/quadrupole data vectors and window matrices feed an RSD fit with a fiducial linear power spectrum and Planck clustering amplitude; nonlinear bias, Lagrangian perturbation theory, effective-theory counterterms and stochastic contributions enter. Alcock–Paczynski parameters are free. The analysis uses the joint f sigma8/b sigma8 inference to retain their covariance. Its reported beta values are 0.371 (+0.042,−0.055) for CMASS and 0.338 (+0.058,−0.081) for LOWZ, and the E_G calculation uses the beta PDF. These are sample-level fitted summaries, not a measured continuous velocity-divergence field. The original RSD window matrices were supplied to the authors by the BOSS analyst; that acknowledgment is not itself a verified public numerical download. [Estimator pp17–18, Eq60 and Fig7; p31 Fig17](https://arxiv.org/pdf/2401.12971v2#page=17)

Algebraically, beta=f/b does not equal R=G f sigma8 delta0, and
\[
 {d\ln\beta\over dN}={f'\over f}-{b'\over b}
 \ne P_3=f+{f'\over f}.
\]
Even a perfectly known P3 gives an evolution equation for f that needs boundary data. The two sample-level f sigma8 estimates do not furnish a continuous, model-independent R(N,q); differentiating them requires interpolation and cross-epoch covariance assumptions. The observables paper explicitly distinguishes such template-conditioned amplitudes from its ideal observable ratios and derivatives. Its argument assumes linear FLRW perturbations, known/pressureless matter, a galaxy-bias relation, no velocity bias and a matter-geodesic physical frame. Further single-scalar, quasistatic and scalar sound-horizon conditions enter its Horndeski scale-shape test. It explicitly leaves real statistical/systematic limitations aside. It contains no measured P3 data series. [Observables pp1–6, especially Eqs11–15,18–22](https://arxiv.org/pdf/1210.0439v2#page=4)

**Metric, lensing and factor two.** The literal printed definitions must be mapped, not matched by the name “E_G”:

| Quantity | Observables v2 | Standard estimator/ACT normalization |
|---|---|---|
| Metric notation | −(1+2Psi)dt²+a²(1+2Phi)dx² | +(1+2psi)dt²−a²(1+2phi)dx² |
| Slip after matching scalar potentials/signature | eta=−Phi/Psi | gamma=−phi/psi; gamma=eta |
| Lensing modification | Sigma_A=Y(1+eta), hence GR value 2 | Sigma_s=mu(1+gamma)/2, hence GR value 1 |
| Lensing amplitude | L_A=Omega_m0 Sigma_A G sigma8 delta0 | L_s=L_A/2 |
| Lensing/velocity ratio | P2_A=L_A/R | P=E_G=L_s/R=P2_A/2 |
| Log velocity growth | P3=R'/R | unchanged |

The standard spatial-potential convention in a −+++ metric is Phi_std=−Phi, so the Weyl combination is Psi+Phi_std=Psi−Phi. Set mu=Y only after matching the reference gravitational normalization. The observables paper's prose calls P2 “E_G”, but its Eqs9–15 give P2_A^GR=2 Omega_m0/f; ACT Eq13 and estimator Eqs6–7 instead give E_G^GR=Omega_m0/f. The half in Sigma_s resolves this exact factor-two issue.

As a transparent algebraic check, write D=P3+2+E'/E. Substituting P2_A=2P into the observables paper's Eq21 yields
\[
 \eta={3 P a^{-3}\over E^2 D}-1 ,
\]
where the expression is used only on its stated regular domain and within the source assumptions. Retaining a further factor 2 in the denominator after declaring P=ACT E_G is incorrect. This mapping has been checked against rendered pages, not extraction alone.

There is also a literal velocity-sign change between sources: estimator v2 p4 prints theta=−f delta, while ACT v2 pp2,4 prints theta=+f delta. Both fix the positive GR E_G normalization above. Do not transfer an isolated theta symbol or Laplacian sign between them. A usable dictionary may define theta_+=−div(v)/(aH)=f delta for the growing dust mode, use the standard Fourier equation −q²Psi=4 pi G_ref a²rho_m mu delta, and express the lensing numerator consistently as −q²(Psi+Phi_std). This gives E_G=Omega_m0 mu(1+eta)/(2f). I do not certify every intermediate sign in either paper; the operational normalization and factor two are unambiguous. [Observables pp3–5](https://arxiv.org/pdf/1210.0439v2#page=3), [estimator pp3–4](https://arxiv.org/pdf/2401.12971v2#page=3), [ACT pp3–4](https://arxiv.org/pdf/2405.12795v2#page=3)

**Derivatives and F.** Prime must mean a time derivative along the same Fourier mode. To avoid ambiguous “physical k”, declare a fixed comoving label q and, if desired, x=q/(aH). Then x'=−(1+h)x, h=H'/H, and
\[
 {d\over dN}\bigg|_q
 =\partial_N\bigg|_x-(1+h)x\,\partial_x .
\]
A fixed angular ell is not a fixed q across redshift because q=(ell+1/2)/chi(z). Neither a bin-center scale nor finite differences between two effective-redshift measurements remove this issue. The observables paper's Eq22 even uses first through third derivatives with respect to its k² variable; their ideal definition is not evidence of a supplied derivative likelihood.

For illustration only, two exact point values at N1,N2 would still allow an added epsilon(N−N1)(N−N2), changing derivatives while retaining the point values. Actual broad projection windows and correlated errors require an even more explicit forward model. This is an admission argument, not a proof against reconstruction under additional regularity/parameterization assumptions.

E_G fixes a combination Omega_m0 Sigma_s/f. It is not a universal direct F measurement. A scalar inverse needs its separately checked action-to-Sigma mapping, physical-frame and gravitational-normalization calibration, density/boundary information, applicable scale regime, and any derivative regularization priors. No new F trajectory, scalar coefficient, observational fit or exclusion has been inferred here.

**Public products and search limits.** The following were located from primary documentation; numerical data were not downloaded:

- [SDSS DR12 BOSS LSS directory](https://data.sdss.org/sas/dr12/boss/lss/): directory metadata confirms CMASS/LOWZ galaxy and random catalogues, masks, geometry and mock directories. It is not the article's joint E_G likelihood.
- [NASA LAMBDA ACT DR6 lensing documentation](https://lambda.gsfc.nasa.gov/product/act/actadv_dr6_lensing_maps_info.html): maps, masks, filters, noise curves and full-release simulations are described; it links the [NERSC release](https://portal.nersc.gov/project/act/dr6_lensing_v1/) and [ACT tutorials](https://github.com/ACTCollaboration/DR6_Notebooks). Its noise curve is an approximate forecasting product, not the required sample-specific joint covariance.
- [Planck PR4 lensing repository](https://github.com/carronj/planck_PR4_lensing): README links map/chain release products; no release assets were followed.
- [velocileptors](https://github.com/sfschen/velocileptors), [NaMaster](https://github.com/LSSTDESC/NaMaster), and the paper-named [CCL](https://github.com/LSSTDESC/CCL): analysis building blocks, not proof that this paper's complete arrays, response matrices, calibration outputs and joint likelihood have been obtained. Current README identities are documentation snapshots, not verified historical analysis commits.

ACT p27 promises the cross-correlations upon publication. I did not locate and verify a numerical release specifically matching this paper's Cκg/Cgg bandpowers, exact response matrices, joint covariance and beta likelihood in the bounded primary-link search. The official LAMBDA product index inspected does not label a BOSS E_G product. Neither this limited search nor the paper's missing direct link proves absence of a public release. A later likelihood analysis must resolve that provenance explicitly before using numerical arrays.

The web browser tool failed to open the named SDSS directory; the direct TLS-verified documentation request succeeded. Targeted release searches returned irrelevant results and are preserved, not treated as evidence of nonexistence. No mathematical/numerical test was executed or failed: this is source admission. All downloaded papers, extracted texts and renders remain local reviewer material and must not be copied into a publication packet.

Full read scope, exact versions, retrieval times, hashes, page-render coverage, link status and limitations are bound in READ_SCOPE_v1.json and IDENTITY_RECEIPT_v1.json. Unread appendices and unacquired numerical products are not certified.

