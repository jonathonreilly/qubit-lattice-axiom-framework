import importlib.util,json,sys,traceback
spec=importlib.util.spec_from_file_location('variant',sys.argv[1]);m=importlib.util.module_from_spec(spec)
try:
 spec.loader.exec_module(m)
 result=m.run(json.load(open(sys.argv[2])))
 failures=[x for x in result['checks'] if not x['passed']]
 print(json.dumps({'kind':'check_rejection' if failures else 'SURVIVED','failures':failures,'passed':result['passed'],'failed':result['failed']},default=str))
 sys.exit(1 if failures else 0)
except Exception as error:
 print(json.dumps({'kind':'exception_rejection','exception':type(error).__name__,'message':str(error)}))
 sys.exit(2)
