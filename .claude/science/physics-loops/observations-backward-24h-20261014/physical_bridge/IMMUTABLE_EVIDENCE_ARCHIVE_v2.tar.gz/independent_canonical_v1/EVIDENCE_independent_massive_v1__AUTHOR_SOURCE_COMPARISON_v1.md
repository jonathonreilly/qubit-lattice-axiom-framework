# Massive-response author-source comparison v1

This is post-independent source correspondence, not a formal audit. The independent derivation, 120 controls, and complete report were frozen before the new author sources were opened. Their exact identities and exposure order are in INDEPENDENT_REVIEW_FREEZE_v1.json and AUTHOR_EXPOSURE_IDENTITY_v1.json.

## Sources read and scope

I read the complete two working notes and complete two implementation files:

- MASSIVE_RESPONSE_WORKING_v1.md:
  4131181f0d73351ef2eaddf7b24dbcceb5d680351db1ede0ed38badbdf433e8d.
- MASSIVE_REFINEMENT_WORKING_v1.md:
  448ec6ee42a4ae27c087cc05efcf940f047054228862be8fd76952c7493ce6bb.
- massive_response_controls_v1.py:
  226fbb6e5f4ef57359d1758a3fe99d5d212f357331ac2d05c1ce1ca3af74692f.
- massive_refinement_controls_v1.py:
  9674ee5a3ec50361df27f4a63e723931085b9cae2d1dbbbc7418fe8d77a7f451.

Byte-identical snapshots are retained here with AUTHOR_ prefixes. The two author result files were read and pinned as evidence, not rerun: 18 and 13 aggregate author controls report success and their embedded source/note hashes match the supplied files. These author counts are distinct from the independent controls.

The focused scientific check covers the common-energy representation, original and sharpened mass-continuity bounds, quotient/BV suppliers, constant-offset and common-epoch qualifications, count-response composition, angular reduction, tail normalization and conditional energy/Gram perturbation inequalities. The equilateral multi-worldline mass-order route is assigned to another checker; I read its text as part of the full files but did not duplicate its numerical work or issue an independent final finding for that route.

## Findings

No mathematical discrepancy was found in the checked scope at these exact source identities. In particular:

1. The positive-real normalization is correct. With unrestricted complex positive-frequency a, the real field norm equals 4 integral omega^2 |a|^2. Thus p=2 omega a is the common real-Hilbert amplitude and the response contains c/omega and the force factor v=k/omega. The real Gram prefactor is (2pi)^(-3), with angular integration 4pi giving 1/(2pi^2) in isotropic radial bounds. No extra reality constraint is appropriate.

2. The original full-response second integration by parts is valid under its explicitly stronger BV(c), continuous zero-extended W, BV(W') and C3 path assumptions. The root's B1,B2 contain acceleration/jerk suprema; they are exactly the supremum-norm specialization of the independent derivative bounds. The stated V supplier retains both the derivative-of-1/d terms and all zero-extension jumps.

3. The original low-frequency integrand bound is correct. On k<=mu it is bounded by C/k+Z; on k>=mu by mu^2[A/k^3+D/k^2+J/k]. Squaring and integrating with k^2 dk gives exactly the stated L0,L1, including the AD, AJ, DJ cross terms and log(K/mu). A narrow post-source integration of this rational majorant independently matches closed_low.

4. The refinement correctly removes the BV(c) requirement by treating the clock difference globally and reserving the second integration by parts for the force difference. The two radial constants, force-phase coefficient, optimized cutoff K=4V_F/(E mu^2), and coefficient 2mu sqrt(E V_F) match the independent frozen proof.

5. The zero cases are correctly treated as infima of the all-K inequality. For E=0, K can tend to infinity; for V_F=0, K can tend to zero. No claim that a finite minimizing cutoff exists is made. Under the concrete compact continuous weight hypotheses these zero cases also force the relevant force observation to vanish. At exactly mu=0 the response comparison is identically zero.

6. The constant-offset improvement uses the actual aggregate C0=|sum integral c|. The addition of the spatial/time first moment M is necessary and present. A small floating residual is correctly retained as a sqrt(mu) term, not declared exact cancellation.

7. The common-origin qualification for vector counts is essential and correctly stated. Different rowwise time centers correspond to different massive-to-massless Hilbert identifications. The note explicitly forbids combining them as one operator bound. A post-source phase control confirms that separately centering the two translated coherent rows would erase their physical lag phase, while one common origin preserves it.

8. The supplied M6 stationary count weights give exactly the massive coherent endpoint formula. The independent distributional calculation uses
   F_a''=sum beta_j delta_(t_j-a),
   Fhat_a=-P exp(-i omega a)/omega^2,
   Fhat_a'=-i omega Fhat_a,
   where P=sum beta_j exp(i omega t_j).
   Substituting W_s=F_2L+F_0, W_b=-2F_L and c_s=-F_2L'+F_0' reproduces coherent_original, including the sign of the partial-time/velocity response and the k/omega factor. This check uses the frozen M6 weights, not a fitted or chosen new window.

9. The angular expression follows by writing the endpoint bracket as
   2 exp(-ia)[v z(cos a-cos bz)+i(-sin a+v z sin bz)].
   Expanding its square gives the stated I1,I2 formula, including the negative -8v sin(a)I1 cross term. The spherical-Bessel implementation matches the analytic expressions and their b=0 limits on the intended k>0 integration domain.

10. The coherent tail bound is correctly normalized. |P|<=4 and |bracket|<=4 imply |F_i|<=16/omega^2. Hence each Gram-entry tail is at most 128/(pi^2 K), including off-diagonal entries. This proves only the tail bound; the finite numerical quadrature is correctly labeled a floating convergence diagnostic rather than a certified full integral.

11. The conditional energy inequality follows from the triangle inequality on response representers and Cauchy-Schwarz. The vector Gram perturbation formula is the usual algebraic expansion with a common-domain operator difference. Neither argument supplies a field state, an error budget, an energy upper budget, or a mass.

## Exact count-weight suppliers checked after exposure

For the first channel, exact rational piecewise integration gives:

- sum integral c=0;
- integral |c|=4;
- sum integral |W|=4;
- TV(W_s')=8 and TV(W_b')=8, including outer jumps;
- at common origin 9/5, D+M=236/25 and E=716/375;
- at common origin 23/10, D+M=521/50 and E=7579/3000.

The note intentionally uses looser transparent suppliers:
16.8 and 6.4 for the individually centered first row, and 20.8 and 8.4 for both rows at the shared origin 2.3. They safely exceed the exact moments. The second row is a time translation, and reflection about the pair's common center gives the same common-origin moment bounds. No tightening of the author's chosen conservative constants is required.

## Narrow post-source controls

postsource_correspondence_controls_v1.py imports only the frozen author snapshots, without invoking either run() function. It adds 24 targeted source-correspondence controls, all passing:

- the original rational low-frequency integral identity;
- the refined formula and mu/E/V zero cases;
- exact rational count-weight moments and BV jumps;
- the coherent distributional-transform formula;
- the expanded angular formula;
- shared-origin phase invariance and a deliberate wrong rowwise-isometry control.

There were no failed controls or repairs in this supplement. This does not repeat the author's 31 aggregate controls, the independent 120 controls, or the separate triangle check.

The original independent report remains immutable:
INDEPENDENT_REVIEW_v1.md,
SHA-256 8aa2145243f64e3d6b552ed00d08a923282cc7d8fe5f1558fabad91aa222f6d7.

## Limits and exposure

This check establishes correspondence of the specified mathematical response and source implementation. It does not extend the bound to bare H1 force weights, near-null paths without a speed margin, curved spacetime, nonconstant conformal backgrounds, sources, nonlinear dynamics, negative mass-squared, or independently chosen physical Cauchy data across masses.

The action relation mu^2/H^2=B>12 is inherited conditional context, not newly checked by this mass-bound review. The input weights and physical measurement/dynamics map remain supplied. No observations, fits, holdouts, external services, Git/index/lock/publication changes, formal audit verdicts, or state selection occurred.

