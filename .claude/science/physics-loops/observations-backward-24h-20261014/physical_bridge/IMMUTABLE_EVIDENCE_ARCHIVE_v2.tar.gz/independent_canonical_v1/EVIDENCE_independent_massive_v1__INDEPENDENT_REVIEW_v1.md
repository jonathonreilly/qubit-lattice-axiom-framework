# Independent massive-response reasoning and controls v1

This report is frozen before any new author physical_bridge derivation or code is opened. It is a focused mathematical check, not a formal audit or a physical/empirical validation.

## Result and precise scope

A computable positive-mass continuity estimate exists without spatial smearing or a chosen initial state, provided the massless and massive energy spaces are identified using the same positive-frequency amplitude at one fixed common epoch. A sufficiently explicit stronger regularity premise is that every zero-extended force weight is continuous and its first derivative is BV. Bare M6 H1 force weights have not been covered by this particular estimate.

The complete derivation is PRECHECK_v1.md, frozen SHA-256
4e3e9e12ea953e60e3aaf7fd0fa110192e2a90cb5913e901e28c89e79e45719e.
Its two integrations by parts retain the outer and internal BV jumps. It bounds the same joint clock/force observable and all prescribed paths as one common-field functional.

In the notation of that derivation, the operator norm difference is at most

epsilon_mu = [C sqrt((2-pi/2) mu)
             +D sqrt((pi/2-4/3) mu^3)
             +2 mu sqrt(E V)] / [sqrt(2) pi].

Here C=sum ||c||_1, D=sum ||t c||_1+sum ||(1-|u|^2)W||_1, and
E=sum integral (1-|u|^2)(1+|u|)|t||W|.
The explicitly computable V is equation (8) of the frozen precheck, involving beta<1, TV(W'), acceleration, jerk, W and W'. It is a bound for the force part only. Compact L2 clock weights suffice; clock BV is not required by this proof.

There is also a cancellation-aware version: replace C by |sum integral c| and add
M=sum integral |c|(|t|+|x|)
to D. Exact cancellation of the constant-offset column removes the sqrt(mu) term. The resulting total bound is O(mu), while the clock-only part is bounded by O(mu^(3/2)). Neither rate is asserted optimal except that a nonzero-integral stationary clock fixture demonstrates the generic sqrt(mu) leading behavior.

The proof supplies an inequality for every state in the common energy space:
|O_mu(g)-O_0(g)| <= epsilon_mu ||g||.
It does not supply g, its energy budget, a physical mass, an initial condition, a background scalar profile, or a measurement calibration.

## Common epoch and vector-count qualification

All components of a vector of counts must use the SAME reference epoch and the SAME energy-amplitude identification. One cannot choose a different favorable time origin independently in each row, then treat the row bounds as one operator comparison without transporting the row phases back to a common Hilbert space.

For finitely many rows, independently bounded at one common epoch, the rowwise estimates epsilon_i imply
||B_mu-B_0|| <= (sum_i epsilon_i^2)^(1/2).
Thus, with epsilon that row aggregate,
||G_mu-G_0|| <= epsilon (2||B_0||+epsilon).
This follows by expanding B_mu B_mu^* - B_0 B_0^*; it gives no mass-Loewner ordering. It only gives useful spectral invertibility information where the retained massless eigenvalue exceeds the resulting norm-error enclosure.

The spatial origin is common too, but changing it multiplies both momentum representations by the same mass-independent unitary phase. Choosing an origin that improves M is harmless when done consistently. Changing the epoch changes the chosen comparison of massive and massless states and must be stated.

## Edge cases and domains

- mu=0: the operators coincide exactly under the stated identification.
- mu>0 is a real, stable free KG mass. No negative mass-squared/tachyonic extension was considered.
- E=0: since 1-|u|^2>0 and W is an ordinary continuous compact function, W vanishes except possibly at the single epoch, hence vanishes. The force functional is zero; the clock estimate remains.
- V=0: the second integration-by-parts bound forces the force functional to vanish at every nonzero frequency. With the explicit V formula, TV(W')=0 already forces a compact continuous W to vanish. The limiting optimized bound is therefore consistent.
- The fixed-cutoff inequality in the precheck avoids division by E or V in degenerate cases.
- Finite compact support bounds the time and spatial moments. The constants diverge as the speed bound approaches light speed.
- The massless zero-energy constant mode remains excluded by the supplied anchored energy-space convention. If it is physically admitted, it needs its separate nuisance treatment; the b0 contrast removes its response rather than selecting its value.
- Pointwise evaluation of a generic energy-space field is not assumed to exist. The finite observation is defined first on smooth field data and then by its proved bounded extension.
- All multi-path interference remains present in the exact Fourier kernel. Triangle inequalities in the enclosure are conservative, not independent-energy assignments.

## Independent computation

The standalone script independent_massive_controls_v1.py imports no author code and reads no observations. It ran 120 controls, all passing, with exit code 0. Results are preserved exactly in independent_massive_results_v1.json.

The controls include:

1. Both radial constants after the independent substitution k=mu sinh(y), z=exp(-y), reducing them to rational integrands on [0,1].
2. Twenty unrestricted positive-frequency real-energy identities, checking the factor 4 and the denominator omega in the common amplitude g=2 omega a.
3. Five masses each for a stationary nonzero-integral clock box, a zero-integral clock difference, and a triangular force weight. Exact angular integrations and analytic high-momentum tail bounds supplement finite radial quadrature.
4. Finite-difference checks of both quotient derivatives b_v',b_v'', their explicit acceleration/jerk enclosures, and direct-plane-wave versus twice-integrated-by-parts responses on an independent analytic accelerated C3 path.
5. Actual BV variation checks for those accelerated kernels and explicit tests of outer/internal jumps for triangular force weights.
6. Deliberate wrong controls: half energy normalization, missing common-energy omega denominator, omitted u partial_t force, omitted internal jump, and omitted outer jumps. These all differ decisively from the correct independent fixture identities.
7. The cutoff minimizer and its value, compared with perturbed cutoffs.

There were no failing execution controls to repair in this version. No failed result has been discarded or relabeled. A speculative attempt to use an instantaneous massless arrival-variable Parseval identity at v=k/omega was explicitly rejected before implementation because v varies across the radial Fourier integral. A generic mass-Loewner substitution was not used.

At mu=0.003 in unit-duration stationary fixtures:

- Nonzero-integral clock norm is approximately 0.008076589, versus bound 0.008085591. Its squared norm divided by [(2-pi/2)mu/(2pi^2)] is 1.00000233. This demonstrates the sharp generic infrared leading rate rather than just a loose estimate.
- Zero-integral clock numerical upper estimate is 5.0041e-7, versus bound 3.6045e-5. The bound is conservative.
- Triangular force numerical upper estimate is 1.0412e-5, versus bound 0.00157742. Its squared norm divided by [(pi/2-4/3)mu^3/(6pi^2)] is 1.000659. This fixture behaves better than the general O(mu) estimate.

These reported numerical upper estimates combine analytic tail bounds with SciPy's estimated quadrature errors. They are not interval-arithmetic certified enclosures. The analytical proof does not depend on the numerical checks.

## Exposure and source identities

Allowed pre-existing source: complete frozen M6 note,
4d4bb8843d43e24c4184f4f99347766a26805df9a9021e647cb89a6a7fa5fb76.

The parent supplied the base context c6b3c14760d0d2efb5f7eacf3b9ff7ae25cbf0ee.
No new author physical_bridge source has been opened as of this report.
No network, empirical data, holdout, branch/index mutation, audit-state mutation, or outside-directory write was performed.

Code SHA-256:
136a027c9fcaf56f02014e5737959274f57bc169f16f5a9399d0f426895a36c9.

Results SHA-256:
a7997a17417b7f2c98c3e98fe21b43458e467dc847ffe5fbccf3ffa764bf40f6.

INDEPENDENT_FREEZE_v1.json records the exact source, precheck, code, and output identities before author-source access. The complete arguments and explicit constants are in the precheck; this report supplements their scope and evidence.

The separate equilateral multi-worldline mass-order route is owned by another focused checker. I independently noticed the same possible obstruction, informed the parent, and did not implement or duplicate its check.

