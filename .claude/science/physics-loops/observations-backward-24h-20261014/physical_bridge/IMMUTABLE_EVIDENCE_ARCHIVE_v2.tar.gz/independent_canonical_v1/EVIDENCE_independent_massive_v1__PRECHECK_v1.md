# Independent positive-mass comparison: precheck v1

Status: independent mathematical construction, frozen before numerical controls and before access to any new physical_bridge author derivation or implementation. This is not a formal audit, physical calibration, empirical test, or author-source confirmation.

Source: the complete frozen M6 note, SHA-256 4d4bb8843d43e24c4184f4f99347766a26805df9a9021e647cb89a6a7fa5fb76. A byte-identical snapshot and exact provenance are saved alongside this file. The base commit identity c6b3c14760d0d2efb5f7eacf3b9ff7ae25cbf0ee is supplied by the parent, not independently inferred from source.

## 1. Space, convention, and observation

Work in the supplied flat laboratory coordinates and natural units. Fix a common reference time t_* and spatial origin x_*, and write t below for t-t_* and x for x-x_*. The reference time fixes the identification of massive and massless positive-frequency amplitudes; it is not an inferred physical state.

For mu >= 0, k=|kvec|, omega_mu=(k^2+mu^2)^(1/2), use

h_mu(t,x)=(2pi)^(-3/2) integral [a_mu(kvec) exp(i omega_mu t-i kvec.x)+c.c.] d^3k.

There is no redundant a(-k)=conjugate(a(k)) constraint. The real initial-data energy norm is

||h_mu||_mu^2 = integral (p^2+|grad h|^2+mu^2 h^2) d^3x
               =4 integral omega_mu^2 |a_mu|^2 d^3k =2 E_mu.

The common real Hilbert amplitude is g(kvec)=2 omega_mu a_mu(kvec), with real inner product Re integral conjugate(g1)g2. This is a unitary energy-space identification, not equality of physical Cauchy data at different masses. The massless space uses the same anchored homogeneous-Sobolev representative as M6; a freely added spatial constant is not included. k=0 has measure zero.

For finitely many prescribed worldlines, put u_A=x_A', q_A=1-|u_A|^2. Retain exactly the observation

O_mu[h]=sum_A integral [c_A h_mu-q_A W_A.(grad h_mu+u_A partial_t h_mu)](t,x_A(t)) dt.

All c,W are real. No independent energy budget is assigned to different worldlines: they sample one common field. A Fourier plane wave gives

T_mu(k,n)=sum_A integral [c_A+i q_A(k n-omega_mu u_A).W_A]
                         exp(i omega_mu t-i k n.x_A(t)) dt,

F_mu=T_mu/omega_mu, and

O_mu(g)=(2pi)^(-3/2) Re integral g(kvec) F_mu(kvec) d^3k.
||O_mu-O_0||^2=(2pi)^(-3) integral |F_mu-F_0|^2 d^3k.      (1)

Conjugating F merely changes the chosen Riesz-representer convention. All following bounds use its modulus.

## 2. Explicit sufficient regularity

Assume each path is C3 on a compact time interval containing its observation support. There is one uniform beta<1 with |u_A|<=beta. Define a_A=u_A', j_A=u_A''.

Keep M6's compact c_A in L2 (hence L1 with a finite first moment). No bounded-variation condition on c is needed for the difference estimate below.

Strengthen the force weight as follows: its zero extension is continuous, W_A belongs to W^(1,1) with compact support, and its weak derivative W_A' is a vector-valued BV function on the real line. In particular, continuous piecewise C2 weights with finitely many pieces and zero outer traces qualify. The BV norm of zero-extended W' includes its outer jumps and all internal jumps. No jump of W itself is allowed.

These are sufficient assumptions, not a claim that bare M6 H1 weights satisfy the stronger bound. They are also not necessary conditions for massive boundedness.

## 3. Low-momentum comparison

Let Delta=omega_mu-k=mu^2/(omega_mu+k), v=k/omega_mu. Define finite nonnegative quantities

C=sum_A integral |c_A| dt,
C1=sum_A integral |t| |c_A| dt,
A0=sum_A integral q_A |W_A| dt,
E=sum_A integral q_A(1+|u_A|)|t| |W_A| dt,
D=C1+A0.

Because the spatial Fourier momentum is the same in the two operators, their phase difference at fixed t is Delta*t. The elementary bounds |exp(i Delta t)-1|<=Delta |t| and 1-v=Delta/omega_mu give

|F_mu^clock-F_0^clock| <= C Delta/(k omega_mu)+C1 Delta/omega_mu,
|F_mu^force-F_0^force| <= A0 Delta/omega_mu+E Delta.        (2)

The first two radial factors are globally square-integrable. Direct integration gives

integral_0^infty k^2 [Delta/(k omega_mu)]^2 dk
  =(2-pi/2) mu,                                           (3)
integral_0^infty k^2 [Delta/omega_mu]^2 dk
  =(pi/2-4/3) mu^3.                                       (4)

For the final force term, on 0<k<K only,

integral_0^K k^2 Delta^2 dk <= mu^4 K/4.                  (5)

The normalized angular/radial factor is sqrt(4pi/(2pi)^3)=1/(sqrt(2) pi).

## 4. Uniform high-momentum force tail

Define d_v=1-v n.u>=delta:=1-beta, and

b_v=q(v n-u)/d_v.

Unlike the massless arrival-variable argument, v depends on k. Do not apply a massless Parseval identity with v silently held fixed across the radial integral.

For a fixed k and n the phase derivative is omega_mu d_v. The zero trace of W allows one integration by parts:

F_mu^force=-(1/omega_mu) sum_A integral (b_v.W_A)'
                         exp(i omega_mu t-i k n.x_A) dt.

Let f_{A,v,n}=((b_v.W_A)')/d_v, extended by zero. Its BV derivative is a finite signed/vector contraction measure. A second Stieltjes integration by parts, including the endpoint and internal jumps in Df, yields

|F_mu^force| <= V/omega_mu^2,
V=sum_A sup_{0<=v<=1, n in S2} TV(f_{A,v,n}).              (6)

The same inequality at mu=0 gives |F_0^force|<=V/k^2. Consequently

|| (F_mu^force-F_0^force) 1_{k>=K} ||_radial
 <=2V/sqrt(K).                                            (7)

This is a triangle bound, not a Loewner comparison of massive and massless Gram matrices. It keeps interference in the exact observation (1), then conservatively bounds it.

A completely explicit upper bound for V avoids a direction/speed optimization. Put

N=2 beta(1+beta)+1,
B0=(1+beta)/delta,
B1=N/delta+(1+beta)/delta^2,
B2=(2+6beta)/delta+2N/delta^2+2(1+beta)/delta^3.

Direct quotient differentiation gives

|b_v|<=B0,
|b_v'|<=B1 |a|,
|b_v''|<=B2 |a|^2+B1 |j|.

Then, for each path,

V_A <= (B0/delta) TV(W_A')
      +(2B1/delta+B0/delta^2) integral |a_A| |W_A'| dt
      +(B2/delta+B1/delta^2) integral |a_A|^2 |W_A| dt
      +(B1/delta) integral |j_A| |W_A| dt.                 (8)

Take V=sum_A of these right-hand sides. This follows by differentiating
f=(b_v'/d_v).W+(b_v/d_v).W' as a BV product. All boundary jumps are already included in TV(W'). The constants are deliberately conservative and diverge toward the null-speed boundary.

## 5. Explicit small-mass bound

Combining the clock's global estimate with the low/high force split gives, for every K>0,

||O_mu-O_0|| <= 1/(sqrt(2) pi) [
   C sqrt((2-pi/2) mu)
  +D sqrt((pi/2-4/3) mu^3)
  +(E mu^2/2) sqrt(K)+2V/sqrt(K)].                        (9)

For E V>0 choose K=4V/(E mu^2), obtaining

||O_mu-O_0|| <= 1/(sqrt(2) pi) [
   C sqrt((2-pi/2) mu)
  +D sqrt((pi/2-4/3) mu^3)
  +2 mu sqrt(EV)].                                       (10)

The fixed-K version remains valid in degenerate cases. If E=0, take K to infinity; compact ordinary force weights with E=0 vanish almost everywhere (q>0). If V=0, (6) forces the force observation to vanish; again the optimized last term is zero by a limiting argument. At mu=0 the difference is exactly zero.

Units: K,mu,omega have inverse-time units. For example, V/(E mu^2) has inverse-time units. These inequalities concern laboratory natural-unit energy; no direct SI substitution for G or an observational energy budget follows.

For g of norm sqrt(2E_lab), the observable difference is at most sqrt(2E_lab) times (9)/(10). This does not supply E_lab or choose g.

## 6. Constant-offset contrasts improve the infrared estimate

Let Cnet=sum_A integral c_A dt, and let

M=sum_A integral |c_A| (|t|+|x_A(t)|) dt.

The total massless clock numerator C0(k,n) obeys
|C0(k,n)-Cnet|<=k M, since all paths use the same reference epoch and spatial origin.

Rewrite the clock difference as
(1/omega_mu-1/k) C0+(C_mu-C0)/omega_mu.
Thus (9)/(10) also hold with the alternative coefficients

C=|Cnet|,
D=M+C1+A0.                                               (11)

One may take the better of the basic and cancellation-aware bounds. In particular, the independently imposed nuisance contrast Cnet=0 removes the sqrt(mu) term. The resulting bound is O(mu), with a clock-only O(mu^(3/2)) contribution. This is a mathematical consequence of that contrast; it is not evidence that the physical data satisfy it, and it does not justify omitting an unknown constant mode without a contrast or other specified treatment.

## 7. Checks and failure guards planned before author exposure

1. Numerically/exactly verify radial constants (3),(4), quotient derivatives, and BV coefficient enclosure (8).
2. A stationary unit-duration clock box c=1 on [0,1], W=0 has Cnet=1 and tests the non-removable sqrt(mu) infrared rate. Its numerator is (exp(i omega)-1)/(i omega).
3. A stationary zero-mean clock c=+1 on [-1,0] and -1 on [0,1] tests the improved O(mu^(3/2)) bound.
4. A stationary triangular force weight W=e1(1-|t|)_+ has transform 2(1-cos omega)/omega^2, C=0,A0=1,E=1/3,V=4. Its angular integration is exact and tests the force comparison with no arbitrary cutoff masquerading as the full integral.
5. Nonstationary quotient identities and plane-wave observation/IBP consistency will use a separately chosen analytic C3 trajectory and smooth compact force weights.
6. Deliberately omitting the energy-amplitude factor 1/omega, the force time-derivative contribution, or endpoint jumps must not be silently accepted by checks. Any failed controls and repair rationale will be retained, versioned.

No new empirical conclusion is available. The supplied action, linear free KG propagation, trajectories, clock map, measurement weights, finite energy, stronger BV regularity, and reference-epoch identification remain explicit premises. No state selector, environmental solution, physical energy scale, scalar mass, or calibration has been derived here.

