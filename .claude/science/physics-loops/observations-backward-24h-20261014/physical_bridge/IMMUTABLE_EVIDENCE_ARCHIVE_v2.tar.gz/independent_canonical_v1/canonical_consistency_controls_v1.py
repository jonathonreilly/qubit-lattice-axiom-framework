#!/usr/local/bin/python3
"""Focused source-adaptation, analytic-table and normalization controls.
This does not run any canonical aggregate or claim new independent science.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import ast, datetime, hashlib, importlib.util, json, math
import mpmath as mp
import numpy as np

OUT=Path(__file__).resolve().parent
checks=[]
def check(name,ok,**details):
    checks.append({"name":name,"passed":bool(ok),**details})
def tree(path):
    return ast.parse(path.read_text())
def funcs(t):
    return {n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
def norm(n):
    return ast.dump(n,include_attributes=False)
pairs=[("WORKING_massive_response_controls_v1.py","CANONICAL_scalar_massive_response_controls.py"),
       ("WORKING_massive_refinement_controls_v1.py","CANONICAL_scalar_massive_refinement_controls.py"),
       ("WORKING_curved_count_controls_v1.py","CANONICAL_scalar_curved_count_controls.py")]
adaptation=[]
for old,new in pairs:
    fa,fb=funcs(tree(OUT/old)),funcs(tree(OUT/new))
    common=sorted(fa.keys()&fb.keys())
    for name in common:
        check("unchanged_function_"+new+"_"+name,norm(fa[name])==norm(fb[name]))
    oldbody=fa["run"].body
    newbody=fb["run_checks"].body
    # Existing scientific statements end at assignment of result.
    stopa=next(i for i,n in enumerate(oldbody)
               if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="result" for t in n.targets))
    stopb=next(i for i,n in enumerate(newbody)
               if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="result" for t in n.targets))
    prefix_a=oldbody[:stopa]
    prefix_b=newbody[1:stopb] # one new clear() call
    extra=False
    if "curved_count" in new:
        extra=True
        assert isinstance(prefix_b[-1],ast.Assign)
        assert isinstance(prefix_b[-1].value,ast.Call) and prefix_b[-1].value.func.id=="extra_controls"
        prefix_b=prefix_b[:-1]
    check("unchanged_existing_scientific_runner_prefix_"+new,
          [norm(x) for x in prefix_a]==[norm(x) for x in prefix_b],
          old_statement_count=len(prefix_a),new_extra_controls=extra)
    adaptation.append({"old":old,"new":new,"common_functions":common,
                       "added_functions":sorted(fb.keys()-fa.keys())})

# Pure analytic function only; no run_checks(), exact_gram(), ODE or aggregate.
spec=importlib.util.spec_from_file_location("frozen_canonical_curved",OUT/"CANONICAL_scalar_curved_count_controls.py")
curved=importlib.util.module_from_spec(spec);spec.loader.exec_module(curved)
mp.mp.dps=70
table=[]
for ht in ["0.00001","0.0001","0.001","0.01","0.05"]:
    h=mp.mpf(ht);B=mp.mpf(16);T=mp.mpf(22)/5
    mu=mp.sqrt(B-2)*h
    C=mp.mpf(48)/5+mp.mpf(24)/5*h
    W=mp.mpf(24);Wp=mp.mpf(16);VF=mp.mpf(32)+16*h
    S=mu**2*h*T**2/(1-h*T)
    U0=mu**2*((1-h*T)**-2-1)
    U1=2*h*mu**2/(1-h*T)**3
    R=mp.exp(S/mu)
    # Independently construct from the stationary general supplier:
    GF=Wp; VR=Wp;RL=W
    A1=R*U0/mu
    A2=R*(U1/mu+U0+U0**2/mu**2)
    CF=2*(R*VF+A1*(GF+VR)+A2*RL)
    em=((2*T*C+W)*mp.sqrt((mp.pi/2-mp.mpf(4)/3)*mu**3)+2*mu*mp.sqrt(T*W*VF))/(mp.sqrt(2)*mp.pi)
    eu=(R*S*C*mp.sqrt(mp.pi/(4*mu))+2*mp.sqrt(R*S*W*(CF+VF)))/(mp.sqrt(2)*mp.pi)
    g0=(646969*h*h-454020*h+98700)/(16200*mp.pi)
    expected=[mp.sqrt(g0),em,eu,(em+eu)/mp.sqrt(g0)]
    got=curved.propagation_enclosure(float(h))
    vals=[got["massless_reference_norm"],got["epsilon_mass"],got["epsilon_curvature"],got["relative_error_enclosure"]]
    errors=[abs(float(a)-b) for a,b in zip(expected,vals)]
    check("new_analytic_supplier_function_"+ht,max(errors)<2e-13,
          maximum_absolute_difference=max(errors))
    table.append({"H":ht,"expected":[str(x) for x in expected],"computed":vals})
note=(OUT/"CANONICAL_SCALAR_MASS_CURVATURE_COUNT_BOUNDED_THEOREM_NOTE_2026-10-15.md").read_text()
tablerows=[line for line in note.splitlines() if line.startswith("| 0.")]
check("table_has_five_rows",len(tablerows)==5)
for text,row in zip(tablerows,table):
    cells=[c.strip() for c in text.strip("|").split("|")]
    expected=[float(x) for x in row["expected"]]
    check("printed_table_rounding_"+row["H"],
          float(cells[0])==float(row["H"]) and
          all(abs(float(c)-x)<=.5001*10**(-len(c.split(".")[1])) for c,x in zip(cells[1:],expected)),
          printed=cells,calculated=expected)
check("large_rows_remain_non_small",table[3]["computed"][3]>1 and table[4]["computed"][3]>1)

# Domain guards for the pure fixture helper.
for H,B,T in [(0,16,4.4),(-.1,16,4.4),(.1,12,4.4),(.1,16,4.),(.25,16,4.4)]:
    rejected=False
    try:curved.propagation_enclosure(H,B,T)
    except ValueError:rejected=True
    check("enclosure_domain_guard_"+str((H,B,T)),rejected)

# The last step of the composed inequality, as a finite Hilbert diagnostic.
rng=np.random.default_rng(7117)
maxratio=0.
for B in [12.01,16.,50.]:
    rr=1/math.sqrt(B-2)
    M=np.array([[1.,-rr,0.],[-rr,1+3*rr*rr,0.],[0.,0.,1.]])
    eigen,vectors=np.linalg.eigh(M);lminus=eigen[0];Q=1.7
    for j in range(8):
        b0=rng.normal(size=3);dm=.03*rng.normal(size=3);du=.02*rng.normal(size=3)
        actual=b0+dm+du;g=rng.normal(size=3)
        coupling=-.8;noise=.01*(-1 if j%2 else 1);allowance=.01
        observed=coupling*(actual@g)+noise
        denominator=abs(coupling)*(np.linalg.norm(b0)+np.linalg.norm(dm)+np.linalg.norm(du))
        lower=Q*lminus*max(0,abs(observed)-allowance)**2/denominator**2
        energy=Q*(g@M@g)
        maxratio=max(maxratio,lower/energy)
        check("composed_physical_energy_"+str((B,j)),lower<=energy+1e-13)
    # Aligned minimum-eigenvector equality checks the Q*lambda_- normalization.
    g=vectors[:,0];response=g.copy();residual=response@g
    exact_lower=Q*lminus*residual**2/np.linalg.norm(response)**2
    actual_energy=Q*(g@M@g)
    check("initial_energy_normalization_equality_"+str(B),abs(exact_lower-actual_energy)<1e-14)

# Primary package binding is a static source check, not execution.
primary=tree(OUT/"CANONICAL_scalar_mass_curvature_count_check.py")
inputs=None
for node in primary.body:
    if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=="AUDIT_INPUT_PATHS" for x in node.targets):
        inputs=ast.literal_eval(node.value)
check("primary_declares_all_four_other_sources",set(inputs)=={
 "docs/SCALAR_MASS_CURVATURE_COUNT_BOUNDED_THEOREM_NOTE_2026-10-15.md",
 "scripts/scalar_massive_response_controls.py",
 "scripts/scalar_massive_refinement_controls.py",
 "scripts/scalar_curved_count_controls.py"})
for path in ["CANONICAL_scalar_mass_curvature_count_check.py","CANONICAL_scalar_massive_response_controls.py",
             "CANONICAL_scalar_massive_refinement_controls.py","CANONICAL_scalar_curved_count_controls.py"]:
    declarations=[ast.literal_eval(n.value) for n in tree(OUT/path).body
                  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="AUDIT_TIMEOUT_SEC" for t in n.targets)]
    check("declared_timeout_"+path,declarations==[180])
result={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "classification":"Post-exposure canonical source consistency/adaptation controls, not independent derivation or aggregate rerun.",
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks":checks,"counts":{"total":len(checks),"passed":sum(c["passed"] for c in checks),"failed":sum(not c["passed"] for c in checks)},
        "adaptation":adaptation,"analytic_table":table,"energy_diagnostic_maximum_ratio":maxratio}
target=OUT/"canonical_consistency_results_v1.json";assert not target.exists();target.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"counts":result["counts"],"failed":[c for c in checks if not c["passed"]],"energy_diagnostic_maximum_ratio":maxratio},indent=2))
sys.exit(0 if result["counts"]["failed"]==0 else 1)

