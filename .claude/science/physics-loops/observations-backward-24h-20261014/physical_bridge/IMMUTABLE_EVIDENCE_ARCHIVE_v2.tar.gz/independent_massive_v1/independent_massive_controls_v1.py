#!/usr/local/bin/python3
"""Independent synthetic controls. No author implementation imports or data."""
from pathlib import Path
import datetime, hashlib, json, math, sys, warnings
import numpy as np
from scipy.integrate import quad, IntegrationWarning

OUT=Path(__file__).resolve().parent
checks=[]
measurements={}
def check(name, condition, detail=None):
    checks.append({"name":name,"passed":bool(condition),"detail":detail})
def quadreal(f,a,b,**kw):
    val,err=quad(f,a,b,epsabs=2e-11,epsrel=2e-11,limit=300,**kw)
    return val,err
def quadcomplex(f,a,b):
    re,er=quadreal(lambda t:float(np.real(f(t))),a,b)
    im,ei=quadreal(lambda t:float(np.imag(f(t))),a,b)
    return re+1j*im,er+ei
def integrate_pieces(f, points):
    values=[quadreal(f,a,b) for a,b in zip(points[:-1],points[1:]) if b>a]
    return sum(x[0] for x in values),sum(x[1] for x in values)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

# Independently simplify by k=mu*sinh(y), z=exp(-y). The transformed
# radial integrands are rational polynomials on [0,1], avoiding cancellation.
c1=2-math.pi/2
c2=math.pi/2-4/3
# For I1/mu: (1-tanh y)^2 cosh y dy -> 2 z^2/(1+z^2) dz.
j1,e1=quadreal(lambda z:2*z*z/(1+z*z),0.,1.)
# For I2/mu^3: sinh^2 y*(1-tanh y)^2*cosh y dy
# -> (1-z^2)^2/[2(1+z^2)] dz.
j2,e2=quadreal(lambda z:(1-z*z)**2/(2*(1+z*z)),0.,1.)
check("radial_constant_I1",abs(j1-c1)<3e-14,{"quadrature":j1,"exact":c1})
check("radial_constant_I2",abs(j2-c2)<3e-14,{"quadrature":j2,"exact":c2})
measurements["radial_constants"]={"I1":c1,"I2":c2}

# Exact real Fourier-data norm identity for unrestricted positive branches.
rng=np.random.default_rng(2026101501)
for mu in [0.,0.03,0.7,2.]:
    for trial in range(5):
        radii=rng.uniform(.1,3.,size=12)
        # First and second halves are independent amplitudes at opposite k.
        amp=rng.normal(size=24)+1j*rng.normal(size=24)
        omega=np.tile(np.sqrt(radii*radii+mu*mu),2)
        amirror=np.concatenate((amp[12:],amp[:12]))
        hhat=amp+np.conj(amirror)
        phat=1j*omega*(amp-np.conj(amirror))
        norm=float(np.sum(np.abs(phat)**2+omega**2*np.abs(hhat)**2))
        expected=float(4*np.sum(omega**2*np.abs(amp)**2))
        check(f"real_energy_normalization_mu{mu}_trial{trial}",
              abs(norm-expected)<2e-12*expected,
              {"norm":norm,"expected":expected})
        if mu==.7 and trial==0:
            check("mutation_factor_two_rejected",
                  abs(norm-expected/2)>0.4*norm,
                  {"wrong_norm":expected/2,"correct":norm})

# Stationary full-radial fixtures. Analytic tails supplement quadrature.
def sinc_half(s):
    return np.sinc(np.asarray(s)/(2*math.pi))
def clock_box_numerator(s):
    return np.exp(.5j*s)*sinc_half(s)
def triangle_transform(s):
    return sinc_half(s)**2

R=40.
fixture_results=[]
for mu in [.3,.1,.03,.01,.003]:
    points=sorted(set([0.,mu,10*mu,1.,R]))
    points=[x for x in points if 0<=x<=R]
    def box_integrand(k):
        om=math.hypot(k,mu)
        return abs((k/om)*clock_box_numerator(om)-clock_box_numerator(k))**2
    ib,eb=integrate_pieces(box_integrand,points)
    # |d/ds [(exp(is)-1)/(is^2)]| <= 1/s^2+4/s^3.
    tailb=mu**4*(1/(12*R**3)+.5/R**4+.8/R**5)
    nb2=ib/(2*math.pi**2)
    nb_upper=math.sqrt((ib+tailb+eb)/(2*math.pi**2))
    bb=(math.sqrt(c1*mu)+.5*math.sqrt(c2*mu**3))/(math.sqrt(2)*math.pi)
    check(f"clock_box_bound_mu{mu}",nb_upper<=bb,
          {"numerical_norm_upper":nb_upper,"bound":bb,"tail_integral_bound":tailb})
    def zero_clock_integrand(k):
        om=math.hypot(k,mu)
        return k*k*(triangle_transform(om)-triangle_transform(k))**2
    iz,ez=integrate_pieces(zero_clock_integrand,points)
    tailz=mu**4*(1/(3*R**3)+2/R**4+16/(5*R**5))
    nz_upper=math.sqrt((iz+tailz+ez)/(2*math.pi**2))
    bz=2*math.sqrt(c2*mu**3)/(math.sqrt(2)*math.pi)
    check(f"zero_mean_clock_bound_mu{mu}",nz_upper<=bz,
          {"numerical_norm_upper":nz_upper,"bound":bz})
    def force_integrand(k):
        om=math.hypot(k,mu)
        return k*k*((k/om)*triangle_transform(om)-triangle_transform(k))**2
    it,et=integrate_pieces(force_integrand,points)
    tailt=mu**4*(1/(3*R**3)+3/R**4+36/(5*R**5))
    nt2=it/(6*math.pi**2)
    nt_upper=math.sqrt((it+tailt+et)/(6*math.pi**2))
    bt=(math.sqrt(c2*mu**3)+2*mu*math.sqrt(4/3))/(math.sqrt(2)*math.pi)
    check(f"triangle_force_bound_mu{mu}",nt_upper<=bt,
          {"numerical_norm_upper":nt_upper,"bound":bt})
    fixture_results.append({"mu":mu,"box_norm_squared_lower":nb2,
        "box_norm_upper":nb_upper,"box_bound":bb,
        "box_squared_rate_ratio":nb2/(mu*c1/(2*math.pi**2)),
        "zero_mean_clock_norm_upper":nz_upper,"zero_mean_clock_bound":bz,
        "force_norm_squared_lower":nt2,"force_norm_upper":nt_upper,"force_bound":bt,
        "force_squared_rate_ratio":nt2/(mu**3*c2/(6*math.pi**2)),
        "radial_cutoff":R,"box_tail_bound":tailb,"zero_clock_tail_bound":tailz,
        "force_tail_bound":tailt,"quadrature_errors":[eb,ez,et]})
check("clock_box_sqrt_mass_asymptotic",
      abs(fixture_results[-1]["box_squared_rate_ratio"]-1)<.015,
      fixture_results[-1])
check("triangle_force_small_mass_asymptotic",
      abs(fixture_results[-1]["force_squared_rate_ratio"]-1)<.025,
      fixture_results[-1])
measurements["stationary_full_radial_fixtures"]=fixture_results

# Exact endpoint/internal jump accounting for triangular W.
om=math.pi; mu=.7; k=math.sqrt(om*om-mu*mu); v=k/om
jump_transform=v*(np.exp(-1j*om)-2+np.exp(1j*om))
from_jumps=jump_transform/(1j*om*om)
direct=1j*v*triangle_transform(om)
check("triangle_BV_distribution_identity",abs(from_jumps-direct)<2e-15)
wrong_outer_only=v*(np.exp(-1j*om)+np.exp(1j*om))/(1j*om*om)
wrong_internal_only=-2*v/(1j*om*om)
check("mutation_omit_internal_jump_rejected",abs(wrong_outer_only-direct)>.1)
check("mutation_omit_outer_jumps_rejected",abs(wrong_internal_only-direct)>.1)

# Prescribed, independent C3 accelerated trajectory, smooth zero-trace W.
def trajectory(t):
    x=np.array([.22*np.sin(t),.13*np.cos(1.3*t),.08*np.sin(.7*t)])
    u=np.array([.22*np.cos(t),-.169*np.sin(1.3*t),.056*np.cos(.7*t)])
    a=np.array([-.22*np.sin(t),-.2197*np.cos(1.3*t),-.0392*np.sin(.7*t)])
    jerk=np.array([-.22*np.cos(t),.28561*np.sin(1.3*t),-.02744*np.cos(.7*t)])
    return x,u,a,jerk
def weight(t):
    f=(1-t*t)**3; f1=-6*t*(1-t*t)**2; f2=-6+36*t*t-30*t**4
    r=np.array([1+.15*t,-.4+.2*t,.3-.05*t]); r1=np.array([.15,.2,-.05])
    return f*r,f1*r+f*r1,f2*r+2*f1*r1
def b_derivatives(t,v,n):
    x,u,a,jerk=trajectory(t)
    q=1-u@u; q1=-2*u@a; q2=-2*(a@a+u@jerk)
    r=v*n-u; r1=-a; r2=-jerk
    d=1-v*n@u; d1=-v*n@a; d2=-v*n@jerk
    z=q*r; z1=q1*r+q*r1; z2=q2*r+2*q1*r1+q*r2
    b=z/d; b1=z1/d-z*d1/d**2
    b2=z2/d-2*z1*d1/d**2-z*d2/d**2+2*z*d1*d1/d**3
    return b,b1,b2,d,d1
beta=math.sqrt(.22**2+.169**2+.056**2)
delta=1-beta
N=2*beta*(1+beta)+1
B0=(1+beta)/delta
B1=N/delta+(1+beta)/delta**2
B2=(2+6*beta)/delta+2*N/delta**2+2*(1+beta)/delta**3
Vw=quadreal(lambda t:np.linalg.norm(weight(t)[2]),-1,1)[0]
Iaw1=quadreal(lambda t:np.linalg.norm(trajectory(t)[2])*np.linalg.norm(weight(t)[1]),-1,1)[0]
Ia2w=quadreal(lambda t:np.linalg.norm(trajectory(t)[2])**2*np.linalg.norm(weight(t)[0]),-1,1)[0]
Ijw=quadreal(lambda t:np.linalg.norm(trajectory(t)[3])*np.linalg.norm(weight(t)[0]),-1,1)[0]
V_bound=B0/delta*Vw+(2*B1/delta+B0/delta**2)*Iaw1+(B2/delta+B1/delta**2)*Ia2w+B1/delta*Ijw
measurements["accelerated_BV_constants"]={"beta":beta,"B0":B0,"B1":B1,"B2":B2,"V_bound":V_bound,"TV_Wprime":Vw}
directions=rng.normal(size=(8,3)); directions/=np.linalg.norm(directions,axis=1)[:,None]
for i,n in enumerate(directions):
    for v in [0.,.37,1.]:
        t=.77*math.sin(2+i+v)
        b,b1,b2,d,d1=b_derivatives(t,v,n)
        _,u,a,j=trajectory(t)
        check(f"quotient_enclosure_{i}_{v}",
            np.linalg.norm(b)<=B0 and np.linalg.norm(b1)<=B1*np.linalg.norm(a)
            and np.linalg.norm(b2)<=B2*np.linalg.norm(a)**2+B1*np.linalg.norm(j))
        h=1e-4
        bm2=b_derivatives(t-2*h,v,n)[0]; bm=b_derivatives(t-h,v,n)[0]
        bp=b_derivatives(t+h,v,n)[0]; bp2=b_derivatives(t+2*h,v,n)[0]
        db=(bm2-8*bm+8*bp-bp2)/(12*h)
        ddb=(-bp2+16*bp-30*b+16*bm-bm2)/(12*h*h)
        check(f"quotient_derivatives_finite_difference_{i}_{v}",
              np.linalg.norm(db-b1)<1e-9 and np.linalg.norm(ddb-b2)<2e-7,
              {"first_error":float(np.linalg.norm(db-b1)),"second_error":float(np.linalg.norm(ddb-b2))})
for i,n in enumerate(directions[:4]):
    for mu,k in [(.7,.4),(.1,2.),(0.,5.)]:
        om=math.hypot(k,mu); v=k/om
        def phase(t):
            return np.exp(1j*(om*t-k*n@trajectory(t)[0]))
        def jg(t):
            b,b1,_,_,_=b_derivatives(t,v,n); W,W1,_=weight(t)
            return b1@W+b@W1
        def fp(t):
            b,b1,b2,d,d1=b_derivatives(t,v,n); W,W1,W2=weight(t)
            g=b1@W+b@W1
            return (b2@W+2*b1@W1+b@W2)/d-g*d1/d**2
        def direct_integrand(t):
            _,u,_,_=trajectory(t); W=weight(t)[0]
            return 1j*(1-u@u)*(v*n-u)@W*phase(t)
        direct,_=quadcomplex(direct_integrand,-1,1)
        first,_=quadcomplex(lambda t:-jg(t)*phase(t)/om,-1,1)
        second,_=quadcomplex(lambda t:fp(t)*phase(t)/(1j*om*om),-1,1)
        actualV=quadreal(lambda t:abs(fp(t)),-1,1)[0]
        check(f"accelerated_two_IBP_{i}_{mu}_{k}",
              abs(direct-first)<2e-11 and abs(direct-second)<2e-11,
              {"first_error":abs(direct-first),"second_error":abs(direct-second)})
        check(f"accelerated_BV_and_tail_{i}_{mu}_{k}",
              actualV<=V_bound and abs(direct)<=actualV/(om*om)+2e-12,
              {"actual_V":actualV,"explicit_V_bound":V_bound,"amplitude":abs(direct)})
        if i==0 and mu==.7:
            def missing_time_force(t):
                _,u,_,_=trajectory(t); W=weight(t)[0]
                return 1j*(1-u@u)*(v*n)@W*phase(t)
            wrong,_=quadcomplex(missing_time_force,-1,1)
            check("mutation_omit_u_partial_t_rejected",abs(wrong-direct)>1e-3,
                  {"wrong_error":abs(wrong-direct)})
            # Omitting /omega in the common-energy response multiplies by omega.
            check("mutation_missing_energy_denominator_rejected",
                  abs(om*direct-direct)>1e-3,
                  {"wrong_error":abs(om*direct-direct)})

# Optimization checked independently by perturbing the positive cutoff.
for E,V,mu in [(1/3,4.,.03),(.7,13.,.2),(8.,.4,.001)]:
    optimum=4*V/(E*mu*mu)
    f=lambda K:E*mu*mu*math.sqrt(K)/2+2*V/math.sqrt(K)
    exact=2*mu*math.sqrt(E*V)
    check(f"cutoff_optimization_{E}_{V}_{mu}",
          abs(f(optimum)-exact)<1e-12 and f(optimum*.5)>exact and f(optimum*2)>exact)

result={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope":"Independent synthetic controls; no author source imported, no raw data or network.",
        "script_sha256":sha(Path(__file__)),
        "precheck_sha256":sha(OUT/"PRECHECK_v1.md"),
        "counts":{"total":len(checks),"passed":sum(c["passed"] for c in checks),
                  "failed":sum(not c["passed"] for c in checks)},
        "checks":checks,"measurements":measurements,
        "limitations":["Numerical quadrature is not interval arithmetic; analytic tail inequalities are separately given.",
          "Synthetic fixtures only; no supplied physical trajectory, scalar mass, observation residual, calibration or energy budget is inferred.",
          "No triangle multi-worldline mass-order control was run: that route was assigned separately by the parent."]}
target=OUT/"independent_massive_results_v1.json"
if target.exists():
    raise RuntimeError("Refusing to overwrite immutable v1 result")
target.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"counts":result["counts"],"results":str(target),
                  "failed":[c for c in checks if not c["passed"]],
                  "stationary_summary":fixture_results[-1]},indent=2))
sys.exit(0 if result["counts"]["failed"]==0 else 1)

