#!/usr/local/bin/python3
"""Narrow post-independent source correspondence, not a broad suite rerun."""
from pathlib import Path
from fractions import Fraction as Q
import sys, importlib.util, json, hashlib, datetime, math
import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
def load(name,file):
    spec=importlib.util.spec_from_file_location(name,OUT/file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
original=load("independent_frozen_author_massive","AUTHOR_massive_response_controls_v1.py")
refinement=load("independent_frozen_author_refinement","AUTHOR_massive_refinement_controls_v1.py")
checks=[]
def check(name,passed,**detail):
    checks.append({"name":name,"passed":bool(passed),**detail})
# Original closed integral: integrate the explicit rational majorant, not D_mu.
for mu,K,C,W,T,beta in [(.2,3.,4.,4.,2.1,0.),(.03,2.,.3,1.,1.3,.18),(2.,2.,0.,1.,.7,.6)]:
    Z=C*T+W*(1+(1+beta)*mu*T)
    A,D,J=C/2,(C*T+W)/2,W*(1+beta)*T/2
    low=C*C*mu+C*Z*mu*mu+Z*Z*mu**3/3
    high=quad(lambda k:mu**4*k*k*(A/k**3+D/k**2+J/k)**2,mu,K,
              epsabs=1e-10,epsrel=1e-12)[0] if K>mu else 0.
    val=original.closed_low(mu,K,C,W,T,beta)
    check("closed_low_rational_identity_"+str(mu),abs(val-low-high)<2e-10*(1+abs(val)),
          author=val,independent=low+high)
for mu,C,D,E,V in [(.01,0.,20.8,8.4,16.),(.7,1.,.5,0.,0.),(.4,2.,1.,0.,7.),(.4,2.,1.,3.,0.),(0.,2.,1.,3.,4.)]:
    expected=(C*math.sqrt((2-math.pi/2)*mu)+D*math.sqrt((math.pi/2-4/3)*mu**3)+2*mu*math.sqrt(E*V))/(math.sqrt(2)*math.pi)
    check("refinement_and_zero_cases_"+str((mu,E,V)),
          abs(refinement.bound(mu,C,D,E,V)-expected)<3e-15,
          value=float(refinement.bound(mu,C,D,E,V)))

# Exact rational M6 weights and moments.
ts=[Q(7,5),Q(12,5),Q(17,5)]; beta=[1,-2,1]; L=Q(3,5)
breaks=sorted(set(t-a for a in [Q(0),L,2*L] for t in ts))
def hinge(s,a):
    return sum(b*max(t-a-s,Q(0)) for b,t in zip(beta,ts))
def slope(s,a):
    return -sum(b for b,t in zip(beta,ts) if t-a-s>0)
def readout(s):
    return -slope(s,2*L)+slope(s,0),hinge(s,2*L)+hinge(s,0),-2*hinge(s,L)
def exact_integral_linear(vl,vr,l,r,origin=None):
    # Caller splits at the origin, so abs(t-origin) is affine on each cell.
    m=(vr-vl)/(r-l);b=vl-m*l
    if origin is None:
        return m*(r*r-l*l)/2+b*(r-l)
    sign=1 if (l+r)/2>=origin else -1
    return sign*(m*(r**3-l**3)/3+(b-m*origin)*(r*r-l*l)/2-b*origin*(r-l))
net=Q(0);C=Q(0);A0=Q(0)
for l,r in zip(breaks[:-1],breaks[1:]):
    c,_,_=readout((l+r)/2)
    net+=c*(r-l);C+=abs(c)*(r-l)
    wl=readout(l)[1]-readout(l)[2];wr=readout(r)[1]-readout(r)[2]
    A0+=exact_integral_linear(wl,wr,l,r)
check("exact_clock_zero_offset",net==0,exact=str(net))
check("exact_clock_L1",C==4,exact=str(C))
check("exact_force_L1",A0==4,exact=str(A0))
moment_records=[]
for origin,capD,capE in [(Q(9,5),Q(84,5),Q(32,5)),(Q(23,10),Q(104,5),Q(42,5))]:
    bb=sorted(set(breaks+[origin]));C1=Q(0);E=Q(0)
    for l,r in zip(bb[:-1],bb[1:]):
        c,_,_=readout((l+r)/2)
        C1+=exact_integral_linear(abs(c),abs(c),l,r,origin)
        wl=readout(l)[1]-readout(l)[2];wr=readout(r)[1]-readout(r)[2]
        E+=exact_integral_linear(wl,wr,l,r,origin)
    dm=2*C1+A0
    check("exact_common_moments_"+str(origin),dm<=capD and E<=capE,
          actual_D_plus_M=str(dm),author_upper_D_plus_M=str(capD),
          actual_E=str(E),author_upper_E=str(capE))
    moment_records.append({"origin":str(origin),"D_plus_M":str(dm),"E":str(E)})
last_s=Q(0);last_b=Q(0);tv_s=Q(0);tv_b=Q(0)
for l,r in zip(breaks[:-1],breaks[1:]):
    s=(l+r)/2
    ss=slope(s,2*L)+slope(s,0);sb=-2*slope(s,L)
    tv_s+=abs(ss-last_s);tv_b+=abs(sb-last_b)
    last_s,last_b=ss,sb
tv_s+=abs(last_s);tv_b+=abs(last_b)
check("exact_force_outer_and_internal_TV",tv_s==8 and tv_b==8,
      station=str(tv_s),body=str(tv_b))

# Independently use F_a''=sum beta_j delta_(t_j-a).
# Therefore Fhat_a=-P exp(-i omega a)/omega^2 and Fhat'_a=-i omega Fhat_a.
nodes,weights=leggauss(80)
for mu,k,z in [(.01,.02,-.7),(.4,1.2,.3),(2.,.03,1.),(0.,3.,-.4)]:
    om=math.hypot(k,mu);v=k/om
    P=sum(b*np.exp(1j*om*float(t)) for b,t in zip(beta,ts))
    H=lambda a:-P*np.exp(-1j*om*float(a))/om**2
    Ws=H(2*L)+H(0);Wb=-2*H(L)
    cs=1j*om*(H(2*L)-H(0))
    independent=cs/om+1j*v*z*(Ws+Wb*np.exp(-1j*k*z*float(L)))
    author=original.coherent_original(k,mu,z)
    check("coherent_distribution_correspondence_"+str((mu,k,z)),
          abs(author-independent)<2e-12,absolute_error=float(abs(author-independent)))
    a,b=om*float(L),k*float(L)
    # Expanded Re/Im integrand, distinct from endpoint bracket assembly.
    direct=4*np.sum(weights*((v*nodes*(np.cos(a)-np.cos(b*nodes)))**2+
                             (-np.sin(a)+v*nodes*np.sin(b*nodes))**2))
    author_ang=original.angular_expression(k,mu)
    check("coherent_expanded_angular_correspondence_"+str((mu,k)),
          abs(float(author_ang)-direct)<2e-12,absolute_error=float(abs(author_ang-direct)))

# One common epoch is a shared row multiplier; separate centering erases lag.
mu,k,z=.4,1.3,.2;om=math.hypot(k,mu)
F=original.coherent_original(k,mu,z)
common=np.array([F,np.exp(1j*om)*F])*np.exp(-1j*om*2.3)
separate=np.array([F*np.exp(-1j*om*1.8),
                   np.exp(1j*om)*F*np.exp(-1j*om*2.8)])
good_cross=float(np.real(common[0]*np.conj(common[1])))
bad_cross=float(np.real(separate[0]*np.conj(separate[1])))
check("common_epoch_retains_lag_phase",abs(good_cross-abs(F)**2*np.cos(om))<1e-14)
check("mutation_rowwise_isometries_rejected",abs(good_cross-bad_cross)>1e-3,
      correct_cross=good_cross,wrong_cross=bad_cross)

result={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope":"Post-independent source correspondence; imports frozen author snapshots without executing run().",
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks":checks,"counts":{"total":len(checks),"passed":sum(c["passed"] for c in checks),
                                 "failed":sum(not c["passed"] for c in checks)},
        "exact_moments":moment_records,
        "excluded":"No author aggregate suite or triangle mass-ordering computation rerun."}
p=OUT/"postsource_correspondence_results_v1.json"
assert not p.exists();p.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"counts":result["counts"],"exact_moments":moment_records,
                  "failed":[c for c in checks if not c["passed"]]},indent=2))
sys.exit(0 if result["counts"]["failed"]==0 else 1)

