#!/usr/bin/env python3
"""Deliberately wrong canonical variants; every case must fail its concrete assertion."""
from pathlib import Path
import hashlib,json,traceback
ROOT=Path(__file__).resolve().parents[4]
# Explicit repository root discovery, not a background worker.
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'scripts/scalar_mass_curvature_count_check.py').exists())
OUT=Path(__file__).resolve().parent
cases=[
('energy_real_factor','scalar_massive_response_controls.py','expected = 4*np.sum(om**2*abs(a)**2)','expected = 2*np.sum(om**2*abs(a)**2)','run'),
('time_force_omission','scalar_massive_response_controls.py','q = (1-u*u)*(v*z-u)','q = (1-u*u)*v*z','run'),
('coherent_bounce_factor','scalar_massive_response_controls.py','-2*v*z*np.exp(-1j*(om*L+k*L*z))','-v*z*np.exp(-1j*(om*L+k*L*z))','coherent'),
('curvature_mass_shift','scalar_curved_count_controls.py','expected=sp.diff(chi,t,2)+(B-2)*H*H/(1-H*t)**2*chi','expected=sp.diff(chi,t,2)+B*H*H/(1-H*t)**2*chi','run'),
('induced_clock_sign','scalar_curved_count_controls.py','rhs=(c+(1-u*u)*hh*w*u)*chi/a','rhs=(c-(1-u*u)*hh*w*u)*chi/a','run'),
('physical_energy_cross_sign','scalar_curved_count_controls.py','energy=(p-H*q)**2+B*H*H*q*q','energy=(p+H*q)**2+B*H*H*q*q','run'),
('proper_endpoint_lapse','scalar_curved_count_controls.py','ye[2]-ae/ar*yr[2]','ye[2]-yr[2]','curved'),
('curved_contrast_beta','scalar_curved_count_controls.py','beta=(1-H*(times-2*L))*gamma','beta=gamma.copy()','curved'),
('bounce_arrival_shift','scalar_curved_count_controls.py','(ti-length-length*z,-2*gi*z*(1-H*(t+length*z)))','(ti-length,-2*gi*z*(1-H*(t+length*z)))','gram'),
('proper_count_interval','scalar_curved_count_controls.py','coeff=-np.diff(tau)*np.cumsum(beta)[:-1]','coeff=-np.diff(times)*np.cumsum(beta)[:-1]','run'),
]
def evaluate(ns,kind):
    if kind=='run':
        ns['run_checks']()
    elif kind=='coherent':
        error=abs(ns['coherent_original'](2.,.4,.8)-ns['coherent_weights'](2.,.4,.8))
        assert error<3e-12, 'original_coherent_vs_derived_weights: '+str(error)
    elif kind=='curved':
        direct,weighted,_=ns['mode_and_observation'](.05,16.,2.,.8,True)
        assert abs(direct-weighted)<3e-9, 'original_curved_count_vs_weights: '+str(abs(direct-weighted))
    elif kind=='gram':
        gram,H,_=ns['exact_gram']()
        import sympy as sp
        assert sp.simplify(gram-(646969*H**2-454020*H+98700)/(16200*sp.pi))==0, 'independently_reproduced_gram_mismatch: '+str(gram)
rows=[]
for name,filename,old,new,kind in cases:
    path=ROOT/'scripts'/filename
    source=path.read_text()
    assert source.count(old)==1,(name,source.count(old))
    mutated=source.replace(old,new,1)
    ns={'__name__':'controlled_mutant','__file__':str(path)}
    exec(compile(mutated,name+'.py','exec'),ns)
    try:
        evaluate(ns,kind)
        outcome='survived'
        message=''
    except AssertionError as exc:
        outcome='assertion_rejected';message=str(exc)
    except Exception as exc:
        outcome='execution_error_not_rejection';message=traceback.format_exc()
    rows.append({'name':name,'source':str(path.relative_to(ROOT)),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
                 'mutated_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'old':old,'new':new,'target':kind,'outcome':outcome,'message':message})
    (OUT/(name+'_MUTATION_v1.txt')).write_text(message+'\n')
    print(name,outcome,flush=True)
report={'status':'mutation validation only, not independent empirical evidence','cases':rows,
        'assertion_rejected':sum(x['outcome']=='assertion_rejected' for x in rows),'survived':sum(x['outcome']=='survived' for x in rows)}
(OUT/'CANONICAL_MUTATIONS_v1.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(x['outcome']=='assertion_rejected' for x in rows), report

