"""Post-freeze all-row correspondence only; no author module imported."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,math,datetime
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[5]
AUTHOR=OUT.parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rat(v):return F(v['numerator'],v['denominator'])
def rows(p):return [json.loads(s) for s in p.read_text().splitlines()]
def band(s):return s.upper()
def run():
 frozen=json.loads((OUT/'INDEPENDENT_IDENTITY_v1.json').read_text())
 for x in frozen['files']:assert sha(Path(x['path']))==x['sha256']
 own={(x['band'],x['second']):x for x in rows(OUT/'SPECTRAL_ROWS_v1.jsonl')}
 authored=rows(AUTHOR/'development_outputs_v1/CARRIER_ESTIMATES_v1.jsonl');assert len(authored)==len(own)==1200
 delta=[];nco_differences=[];maxpower=0.;maxresidual=0.;allcert=0;headcount=0;frequency_mismatches=[];power_mismatches=[]
 cert_map={'center_energy_integer':'sum_squared_amplitude','ceil_radius_sum_integer':'sum_ceil_amplitude','constant_amplitude_residual_lower_numerator':'N_S_minus_C_squared','max_cell_radius_lower_squared':'max_cell_min_radius_squared','min_cell_radius_upper_squared':'min_cell_max_radius_squared','quantization_only_rejected':'radial_residual_certificate','common_amplitude_intersection_empty':'common_amplitude_interval_disjoint'}
 for a in authored:
  b=own[(band(a['band']),a['second'])];aa=a['amplitude_certificate'];bb=b['exact_cell'];fit=b['fit'];est=a['estimate']
  assert a['record_index']==b['record_index'];assert aa['N']==aa['lower_denominator']==1000 and aa['ideal_cell_energy_limit']==2000
  for ka,kb in cert_map.items():assert aa[ka]==bb[kb],(a['second'],ka)
  allcert+=1;assert est['fit_success']
  df=(est['frequency_Hz']-fit['frequency_Hz']+500)%1000-500
  if abs(df)>2e-5:frequency_mismatches.append({'band':a['band'],'second':a['second'],'difference_Hz':df})
  power=est['fitted_tone_power_fraction']*1000*est['center_energy'];dr=abs(power-fit['correlation_power'])/fit['correlation_power'];maxpower=max(maxpower,dr)
  if dr>5e-10:power_mismatches.append({'band':a['band'],'second':a['second'],'relative_difference':dr})
  rr=abs(est['residual_energy']-fit['residual_squared'])/max(1,abs(fit['residual_squared']));maxresidual=max(maxresidual,rr)
  assert est['center_energy']==bb['sum_squared_amplitude']
  h=b['header'];assert a['error_count']==h['DATA ERROR COUNT'] and a['tracking_mode']==h['TRACKING MODE']
  assert a['origin_reaching_cells']==bb['origin_touching_cells']==0 and a['extreme_codes']==bb['extreme_components']==0
  for key,prefix,length in [('nco_F','SUB-CHANNEL FREQUENCY COEF F',3),('nco_P','SUB-CHANNEL PHASE COEF P',4)]:
   for j in range(length):assert F(a[key][j])==F(h[prefix+str(j+1)]);headcount+=1
  assert F(a['nco_accumulated'])==F(h['SUB-CHANNEL ACCUMULATED PHASE']);headcount+=1
  assert F(a['nominal_LO_Hz'])==(F(h['DDC LO FREQUENCY'])+F(h['RF-IF LO FREQUENCY']))*10**6;headcount+=1
  P=list(map(F,a['nco_P']));freq=list(map(F,a['nco_F']))
  for shift in (F(0),F(1,2000)):
   dp=P[1]+P[2]*(1+2*shift)+P[3]*(1+3*shift+3*shift*shift)
   dfreq=freq[0]+freq[1]*(F(1,2)+shift)+freq[2]*(F(1,3)+shift+shift*shift)
   nco_differences.append({'band':a['band'],'second':a['second'],'shift':str(shift),'P_increment_minus_F_integral':str(dp-dfreq),'approximate':float(dp-dfreq)})
  delta.append({'band':a['band'],'second':a['second'],'frequency_author_minus_independent_Hz':df,'correlation_power_relative_difference':dr,'residual_energy_relative_difference':rr})
 ours={x['ODF']['record']:x for x in rows(OUT/'REFERENCE_ROWS_v1.jsonl')};theirs=rows(AUTHOR/'development_outputs_v1/REFERENCE_COMPARISON_ROWS_v1.jsonl');assert len(ours)==len(theirs)==600
 names=['time_seconds','time_milliseconds','downlink_delay_ns','observable_integer','observable_fraction_billionths','format','rx','tx','network','type','down_band','up_band','exciter_band','bad','item15','spacecraft','independent_receiver','reference_frequency_high_mHz','reference_frequency_low_mHz','item20','compression_centiseconds','uplink_delay_ns']
 odf_fields=0;atdf_fields=0;quality=[];candidate_diffs=[];nonzero_nominal=0;nominal_max=F(0);used79={}
 with (ROOT/'outputs/cassini_doppler_inputs/c32easc2002_169_0000xmmmv0.tdf').open('rb') as raw:
  for a in theirs:
   b=ours[a['odf_record']]
   for item,name in enumerate(names,1):assert a['odf'][name]==b['ODF']['items'][str(item)];odf_fields+=1
   assert a['start_second']==int(F(b['ODF']['start']))-1655510400 # 2002 day169 origin in1950 seconds
   assert a['end_second']==a['start_second']+1
   for side,ownname in [(0,'ATDF_start'),(1,'ATDF_end')]:
    assert len(a['atdf_endpoint_variants'][side])==1
    aa=a['atdf_endpoint_variants'][side][0];bb=b[ownname];assert aa['record']==bb['record']
    for k,v in aa['fields'].items():
     if k=='79':
      raw.seek((aa['record']-1)*288+180);value=raw.read(1)[0];assert v==value;used79[aa['record']]=value
     else:assert bb['items'][k]==v
     atdf_fields+=1
    if aa['fields']['87']>0:quality.append((a['odf_record'],side,aa['record'],aa['fields']['87']))
   assert rat(a['stored_reference_Hz'])==F(b['ATDF_start']['reference'])==F(b['ODF']['ODF_reference'])
   assert rat(a['X_reference_Hz'])==F(b['stored_reference_times_880_over_221_Hz'])
   assert rat(a['ODF_mean_received_sky_Hz'])==F(b['ODF_mean_sky_Hz'])
   assert rat(a['ATDF_mean_received_sky_Hz'])==F(b['conditional_ATDF_mean_sky_Hz'])
   assert rat(a['ODF_minus_ATDF_sky_Hz'])==F(b['countD_minus_ODF_D_Hz'])
   assert a['conditional_count_wraps']==int(F(b['conditional_forward_history_integer']))==0
   for aa,bb in zip(a['candidates'],b['candidates']):
    shift=rat(aa['phase_delta_seconds']);assert shift==F(bb['shift_seconds']) and aa['spectral_sign']==bb['sign']
    ownh=own[('X',a['start_second'])]['header'];freq=[F(ownh['SUB-CHANNEL FREQUENCY COEF F'+str(j)]) for j in range(1,4)]
    fintegral=freq[0]+freq[1]*(F(1,2)+shift)+freq[2]*(F(1,3)+shift*shift+shift)
    expected_difference=F(bb['NCO_phase_increment_cycles'])-fintegral
    actual=rat(aa['nominal_RSR_minus_count_sky_Hz'])-F(bb['exact_offset_to_ODF_before_fitted_frequency_Hz'])
    assert actual==expected_difference
    nonzero_nominal+=int(actual!=0);nominal_max=max(nominal_max,abs(actual))
    difference=aa['RSR_minus_count_sky_Hz']-bb['error_to_ODF_Hz'];assert abs(difference)<2e-5
    candidate_diffs.append({'ODF_record':a['odf_record'],'shift':str(shift),'sign':bb['sign'],'error_author_minus_independent_Hz':difference,'exact_nominal_difference_cycles':str(actual)})
 result={'stage':'post-independent-freeze source/product correspondence; preserved initial tolerance failure', 'frequency_mismatches':frequency_mismatches, 'power_mismatches':power_mismatches,'spectral_rows':len(delta),'maximum_frequency_difference_Hz':max(abs(x['frequency_author_minus_independent_Hz']) for x in delta),'maximum_relative_power_difference':maxpower,'maximum_relative_residual_difference':maxresidual,'exact_amplitude_certificates_identical':allcert,'selected_NCO_header_fields_compared':headcount,'reference_rows':len(theirs),'ODF_fields_exact':odf_fields,'ATDF_endpoint_field_occurrences_exact':atdf_fields,'post_exposure_item79_unique_direct_byte_checks':len(used79),'nonzero_slip_occurrences':len(quality),'unique_nonzero_slip_endpoints':len({x[2] for x in quality}),'nonzero_slip_intervals':len({x[0] for x in quality}),'reference_candidates':len(candidate_diffs),'maximum_reference_error_difference_Hz':max(abs(x['error_author_minus_independent_Hz']) for x in candidate_diffs),'nonidentical_nominal_phase_vs_frequency_terms':nonzero_nominal,'max_abs_phase_vs_frequency_difference_cycles':str(nominal_max),'phase_vs_frequency_note':'Protocol declares phase-polynomial increment; working code integrates archived frequency coefficients. Small exact dyadic/rational differences are retained, not treated as zero.','frequency_tolerance_Hz':2e-5,'power_relative_tolerance':5e-10,'fits_offsets_timeshifts_or_row_removals':0,'independent_empirical_gravity_tests':0}
 for name,values in [('AUTHOR_SPECTRAL_DIFFERENCES_v2.jsonl',delta),('NCO_PHASE_FREQUENCY_DIFFERENCES_v2.jsonl',nco_differences),('AUTHOR_REFERENCE_DIFFERENCES_v2.jsonl',candidate_diffs)]:
  with (OUT/name).open('x') as f:
   for row in values:f.write(json.dumps(row,separators=(',',':'))+'\n')
 with (OUT/'AUTHOR_COMPARISON_RESULTS_v2.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':run()
