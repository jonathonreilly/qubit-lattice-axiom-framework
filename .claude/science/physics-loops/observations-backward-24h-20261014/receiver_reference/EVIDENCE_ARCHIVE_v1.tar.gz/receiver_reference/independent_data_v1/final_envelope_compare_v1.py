"""Read/hash and compare frozen M10 JSON rows only. No scientific runner import."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
import ast, datetime, hashlib, json, math
OUT=Path(__file__).resolve().parent
RR=OUT.parent
WT=OUT.parents[5]
RT=Path('/Users/jonBridger/.codex/campaigns/observations-backward-24h-20261014')
PRODUCT=WT/'outputs/cassini_carrier_reference'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def read(p): return json.loads(p.read_text())
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def rat(v): return F(v['numerator'],v['denominator'])
def changes(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        assert a.keys()==b.keys(),(path,a.keys(),b.keys())
        for k in a: yield from changes(a[k],b[k],path+'/'+str(k))
    elif isinstance(a,list) and isinstance(b,list):
        assert len(a)==len(b),(path,len(a),len(b))
        for k,(x,y) in enumerate(zip(a,b)): yield from changes(x,y,path+'/'+str(k))
    elif a!=b: yield path,a,b

def main():
    # Original evidence stays immutable; no pre-exposure raw source is reopened.
    evidence=[]
    for name in ['INDEPENDENT_IDENTITY_v1.json','AUTHOR_CORRESPONDENCE_IDENTITY_v1.json','CANONICAL_AFFECTED_IDENTITY_v1.json']:
        p=OUT/name; evidence.append(ident(p))
        for x in read(p)['files']:
            q=Path(x['path']); assert sha(q)==x['sha256'],str(q)
    for x in read(OUT/'AUTHOR_INPUTS_v1.json')['files']:
        assert sha(Path(x['path']))==sha(Path(x['snapshot']))==x['sha256']
    primary=WT/'scripts/cassini_carrier_reference_check.py'
    declaration=None
    for n in ast.parse(primary.read_text()).body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets):
            declaration=ast.literal_eval(n.value)
    assert declaration and len(declaration)==len(set(declaration))==13
    fingerprint=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
    sources=[ident(primary)]
    for relative in declaration:
        p=WT/relative; rb=relative.encode(); body=p.read_bytes()
        fingerprint.update(len(rb).to_bytes(8,'big')); fingerprint.update(rb)
        fingerprint.update(len(body).to_bytes(8,'big')); fingerprint.update(body)
        sources.append(ident(p))
    summary=read(PRODUCT/'SUMMARY_v1.json'); receipt=read(RR/'CANONICAL_EXECUTION_v2.json')
    execution=read(RT/'M10_CANONICAL_EXECUTION_v2.json')
    cache=WT/'logs/runner-cache/cassini_carrier_reference_check.txt'
    header,rest=cache.read_text().split('----- stdout -----\n',1)
    stdout,stderr=rest.split('----- stderr -----\n',1)
    h=dict(line.split(': ',1) for line in header.splitlines() if ': ' in line)
    assert h['runner_sha256']==sha(primary)==summary['primary_sha256']
    assert h['input_fingerprint_sha256']==fingerprint.hexdigest()
    assert h['exit_code']=='0' and h['status']=='ok' and h['timeout_sec']=='180'
    assert execution['status']=='ok' and execution['exit_code']==0 and execution['timeout_sec']==180
    assert float(h['elapsed_sec'])==round(execution['elapsed_sec'],2)
    assert execution['stderr']=='' and stderr.strip()==''
    assert json.loads(stdout)==json.loads(execution['stdout'])==summary
    assert receipt['summary_sha256']==sha(PRODUCT/'SUMMARY_v1.json')
    assert receipt['cache_sha256']==sha(cache)
    assert len(summary['geometry_controls'])==42 and all(summary['geometry_controls'].values())
    assert len(summary['carrier_controls'])==9
    assert len(summary['development_checks'])==12 and all(summary['development_checks'].values())
    assert summary['passed']==63 and summary['failed']==0
    assert summary['physical_error_upper_bound_derived'] is False and summary['independent_empirical_gravity_tests']==0
    assert set(summary['source_inputs'])==set(declaration)
    for rel,expected in summary['source_inputs'].items(): assert sha(WT/rel)==expected
    freeze=read(RR/'CANONICAL_SOURCE_FREEZE_v2.json')
    for rel,expected in freeze['identities'].items(): assert sha(WT/rel)==expected
    product_ids=[]
    for name,expected in summary['products'].items():
        p=PRODUCT/name; cp=RR/('CANONICAL_'+name)
        assert sha(p)==sha(cp)==expected==receipt['products'][name]
        product_ids.extend([ident(p),ident(cp)])
    assert sha(RR/'CANONICAL_SUMMARY_v1.json')==sha(PRODUCT/'SUMMARY_v1.json')
    oldreceipt=read(RR/'CANONICAL_EXECUTION_v1.json')
    assert oldreceipt['products']==receipt['products']
    assert sha(RR/'PRE_SCOPE_RUNNER_CACHE_v1.txt')==oldreceipt['cache_sha256']
    assert sha(RR/'PRE_SCOPE_CANONICAL_SUMMARY_v1.json')==oldreceipt['summary_sha256']
    oldsummary=read(RR/'PRE_SCOPE_CANONICAL_SUMMARY_v1.json')
    summary_delta=list(changes(oldsummary,summary))
    assert len(summary_delta)==1 and summary_delta[0][0].endswith('.md')
    assert summary_delta[0][1]=='d751b57ee265a5169fa395056546724875aac46fbe04dfc47872a5c467130895'
    assert summary_delta[0][2]=='79bcdf128d8b0570cc248576ddda09d5f50edbf9851fb9dad0cd920a24f68cd9'
    # Exhaustive final vs old-working row comparison, then original independent rows.
    own={(a['band'],a['second']):a for a in rows(OUT/'SPECTRAL_ROWS_v1.jsonl')}
    old={(a['band'],a['second']):a for a in rows(OUT/'author_sources_v1/CARRIER_ESTIMATES_v1.jsonl')}
    final=rows(PRODUCT/'CARRIER_ESTIMATES_v1.jsonl'); assert len(final)==len(own)==len(old)==1200
    allowed={'/estimate/fitted_complex_amplitude/0','/estimate/fitted_complex_amplitude/1','/estimate/residual_energy','/estimate/fitted_tone_power_fraction'}
    leaf_counts=Counter(); leaf_max=defaultdict(float); changed_rows=0; differences=[]; mismatches=[]; certificates=0; selected_fields=0
    certmap={'center_energy_integer':'sum_squared_amplitude','ceil_radius_sum_integer':'sum_ceil_amplitude','constant_amplitude_residual_lower_numerator':'N_S_minus_C_squared','max_cell_radius_lower_squared':'max_cell_min_radius_squared','min_cell_radius_upper_squared':'min_cell_max_radius_squared','quantization_only_rejected':'radial_residual_certificate','common_amplitude_intersection_empty':'common_amplitude_interval_disjoint'}
    for a in final:
        before=old[a['band'],a['second']]; b=own[a['band'].upper(),a['second']]
        ds=list(changes(before,a)); changed_rows+=bool(ds)
        for path,x,y in ds:
            assert path in allowed,(a['band'],a['second'],path)
            leaf_counts[path]+=1; leaf_max[path]=max(leaf_max[path],abs(y-x))
        assert a['record_index']==b['record_index']
        for x,y in certmap.items(): assert a['amplitude_certificate'][x]==b['exact_cell'][y]
        assert a['amplitude_certificate']['N']==a['amplitude_certificate']['lower_denominator']==1000
        assert a['amplitude_certificate']['ideal_cell_energy_limit']==2000
        certificates+=1; hd=b['header']
        for key,prefix,count in [('nco_F','SUB-CHANNEL FREQUENCY COEF F',3),('nco_P','SUB-CHANNEL PHASE COEF P',4)]:
            for i in range(count): assert F(a[key][i])==F(hd[prefix+str(i+1)]); selected_fields+=1
        assert F(a['nco_accumulated'])==F(hd['SUB-CHANNEL ACCUMULATED PHASE']); selected_fields+=1
        assert a['nominal_LO_Hz']==10**6*(hd['DDC LO FREQUENCY']+hd['RF-IF LO FREQUENCY']); selected_fields+=1
        assert a['error_count']==hd['DATA ERROR COUNT'] and a['tracking_mode']==hd['TRACKING MODE']
        assert a['extreme_codes']==b['exact_cell']['extreme_components']==0
        assert a['origin_reaching_cells']==b['exact_cell']['origin_touching_cells']==0
        df=(a['estimate']['frequency_Hz']-b['fit']['frequency_Hz']+500)%1000-500
        power=a['estimate']['fitted_tone_power_fraction']*1000*a['estimate']['center_energy']
        dp=abs(power-b['fit']['correlation_power'])/b['fit']['correlation_power']
        d={'band':a['band'],'second':a['second'],'frequency_difference_Hz':df,'relative_power_difference':dp}
        differences.append(d)
        if abs(df)>2e-5 or dp>5e-10: mismatches.append(d)
    assert len(mismatches)==1 and (mismatches[0]['band'],mismatches[0]['second'])==('Ka',49112)
    oldref={a['odf_record']:a for a in rows(OUT/'author_sources_v1/REFERENCE_COMPARISON_ROWS_v1.jsonl')}
    ownref={a['ODF']['record']:a for a in rows(OUT/'REFERENCE_ROWS_v1.jsonl')}
    finalref=rows(PRODUCT/'REFERENCE_COMPARISON_ROWS_v1.jsonl'); assert len(finalref)==len(oldref)==len(ownref)==600
    names=['time_seconds','time_milliseconds','downlink_delay_ns','observable_integer','observable_fraction_billionths','format','rx','tx','network','type','down_band','up_band','exciter_band','bad','item15','spacecraft','independent_receiver','reference_frequency_high_mHz','reference_frequency_low_mHz','item20','compression_centiseconds','uplink_delay_ns']
    refchanges=Counter(); phase_changed=0; maxphase=F(0); maxfloat=0.; odf_fields=0; atdf_fields=0; quality=[]; exact_phase_matches=0
    for a in finalref:
        before=oldref[a['odf_record']]; b=ownref[a['odf_record']]
        for path,x,y in changes(before,a):
            assert path.startswith('/candidates/') and '/nominal_RSR_minus_count_sky_Hz/' in path,(a['odf_record'],path)
            refchanges[path]+=1
        for i,name in enumerate(names,1): assert a['odf'][name]==b['ODF']['items'][str(i)]; odf_fields+=1
        for side,ownkey in [(0,'ATDF_start'),(1,'ATDF_end')]:
            assert len(a['atdf_endpoint_variants'][side])==1
            ep=a['atdf_endpoint_variants'][side][0]
            assert ep['record']==b[ownkey]['record']
            for key,value in ep['fields'].items():
                if key!='79': assert b[ownkey]['items'][key]==value
                # Item79 was separately direct-byte checked after exposure; unchanged here.
                assert before['atdf_endpoint_variants'][side][0]['fields'][key]==value
                atdf_fields+=1
            if ep['fields']['87']: quality.append((a['odf_record'],ep['record']))
        assert rat(a['stored_reference_Hz'])==F(b['ODF']['ODF_reference'])==F(b['ATDF_start']['reference'])
        assert rat(a['X_reference_Hz'])==F(b['stored_reference_times_880_over_221_Hz'])
        assert rat(a['ODF_mean_received_sky_Hz'])==F(b['ODF_mean_sky_Hz'])
        assert rat(a['ATDF_mean_received_sky_Hz'])==F(b['conditional_ATDF_mean_sky_Hz'])
        assert rat(a['ODF_minus_ATDF_sky_Hz'])==F(b['countD_minus_ODF_D_Hz'])
        assert a['conditional_count_wraps']==int(F(b['conditional_forward_history_integer']))==0
        assert a['start_second']==int(F(b['ODF']['start']))-1655510400 and a['end_second']==a['start_second']+1
        for oldc,c,ind in zip(before['candidates'],a['candidates'],b['candidates']):
            assert rat(c['phase_delta_seconds'])==F(ind['shift_seconds']) and c['spectral_sign']==ind['sign']
            assert rat(c['nominal_RSR_minus_count_sky_Hz'])==F(ind['exact_offset_to_ODF_before_fitted_frequency_Hz'])
            exact_phase_matches+=1
            d=rat(c['nominal_RSR_minus_count_sky_Hz'])-rat(oldc['nominal_RSR_minus_count_sky_Hz'])
            phase_changed+=bool(d); maxphase=max(maxphase,abs(d))
            maxfloat=max(maxfloat,abs(c['RSR_minus_count_sky_Hz']-ind['error_to_ODF_Hz']))
    assert phase_changed==1588 and exact_phase_matches==2400 and maxfloat<2e-5
    assert len(quality)==54 and len({x[1] for x in quality})==27 and len({x[0] for x in quality})==39
    rs=read(PRODUCT/'REFERENCE_COMPARISON_SUMMARY_v1.json'); cs=read(PRODUCT/'CARRIER_SUMMARY_v1.json')
    assert rs['estimator_ledger_sha256']==cs['ledger_sha256']==sha(PRODUCT/'CARRIER_ESTIMATES_v1.jsonl')
    assert rs['comparison_ledger_sha256']==sha(PRODUCT/'REFERENCE_COMPARISON_ROWS_v1.jsonl')
    assert rs['source_sha256']==sha(WT/'scripts/cassini_receiver_reference.py')
    assert cs['source_sha256']==sha(WT/'scripts/cassini_carrier_estimator.py')
    assert rs['maximum_ODF_ATDF_sky_difference_Hz']==float(max(abs(rat(a['ODF_minus_ATDF_sky_Hz'])) for a in finalref))
    summary_matches={}
    for i in range(4):
        vals=[a['candidates'][i]['RSR_minus_count_sky_Hz'] for a in finalref]
        v=rs['candidates'][str(i)]; computed=math.sqrt(math.fsum(x*x for x in vals)/600)
        assert math.isclose(computed,v['RMS_Hz'],rel_tol=1e-14,abs_tol=1e-16)
        summary_matches[str(i)]={'RMS_Hz':v['RMS_Hz'],'recomputed_from_frozen_rows_Hz':computed}
    assert summary['plus_sign_zero_shift_RMS_Hz']==rs['candidates']['1']['RMS_Hz']
    assert summary['reverse_sign_zero_shift_RMS_Hz']==rs['candidates']['0']['RMS_Hz']
    result={
        'scope':'Frozen row and source/cache envelope comparison only; no raw extraction, spectra, geometry or scientific aggregate rerun',
        'sources':sources,'products':product_ids,
        'cache':ident(cache),'input_fingerprint_sha256':fingerprint.hexdigest(),
        'execution':ident(RT/'M10_CANONICAL_EXECUTION_v2.json'),'execution_elapsed_sec':execution['elapsed_sec'],
        'passed_aggregates':63,'geometry_aggregates':42,'carrier_controls':9,'development_aggregates':12,
        'v1_to_v2_summary_delta':summary_delta,'all_four_numerical_products_identical_to_execution_v1':True,
        'spectral_rows':1200,'frequency_and_grid_selection_identical_to_original_working':1200,
        'rows_with_allowed_alias_roundoff':changed_rows,'alias_roundoff_leaf_counts':dict(leaf_counts),'alias_roundoff_max_abs':dict(leaf_max),
        'independent_comparison_tolerance_Hz':2e-5,'relative_power_tolerance':5e-10,
        'independent_correspondence_rows':1199,'known_retained_mismatch':mismatches,
        'maximum_Hz_difference_excluding_known_Ka':max(abs(v['frequency_difference_Hz']) for v in differences if (v['band'],v['second'])!=('Ka',49112)),
        'maximum_relative_power_difference_excluding_known_Ka':max(v['relative_power_difference'] for v in differences if (v['band'],v['second'])!=('Ka',49112)),
        'exact_certificate_rows':certificates,'exact_selected_NCO_header_fields':selected_fields,
        'reference_rows':600,'exact_ODF_fields':odf_fields,'ATDF_selected_field_occurrences':atdf_fields,
        'ATDF_item79_scope':'601 unique endpoint byte checks from previous post-exposure report reused by unchanged metadata; no new raw read',
        'nonzero_slip_occurrences':len(quality),'unique_nonzero_slip_endpoints':27,'affected_intervals':39,
        'exact_final_P_nominal_candidate_matches':exact_phase_matches,'changed_F_to_P_nominal_candidates':phase_changed,
        'max_exact_F_to_P_nominal_change_Hz':str(maxphase),'maximum_final_reference_minus_independent_error_Hz':maxfloat,
        'reference_leaf_change_counts':dict(refchanges),'candidate_summary_rows':summary_matches,
        'maximum_dependent_storage_difference_Hz':rs['maximum_ODF_ATDF_sky_difference_Hz'],
        'independent_empirical_gravity_tests':0,'physical_error_upper_bound_derived':False,
        'new_fit_or_timing_choice':False,'all_original_reviewed_evidence_hashes_preserved':True,
        'original_identity_inputs':evidence}
    target=OUT/'FINAL_ENVELOPE_COMPARISON_v1.json'
    with target.open('x') as f: json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['sources','products','original_identity_inputs']},indent=2))
if __name__=='__main__': main()
