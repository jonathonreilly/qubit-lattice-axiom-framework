"""Independent M10 computations on previously exposed inputs only."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter
from datetime import date
import numpy as np
import math,json,hashlib,time
OUT=Path(__file__).resolve().parent
PACK=OUT.parents[1]
ROOT=OUT.parents[5]
OLD=PACK/'channel_quotient/independent_rsr_v1'
RAW=ROOT/'outputs/cassini_doppler_inputs'
FS=1000;N=1000;GRID=32768
T=(np.arange(N)-(N-1)/2)/FS
D1=-2j*np.pi*T;D2=D1*D1
ATDF_FIELDS={1:(0,32),3:(40,32),4:(72,12),5:(84,16),6:(100,8),7:(108,8),8:(116,8),10:(144,10),11:(154,8),12:(162,6),13:(168,4),14:(172,4),15:(176,16),19:(216,1),20:(217,18),22:(236,1),23:(237,1),24:(238,1),25:(239,1),26:(240,6),27:(246,6),28:(252,4),29:(256,32),30:(288,24),31:(312,24),32:(336,24),43:(588,32),44:(620,32),87:(1466,10)}
ODF_WIDTHS=[32,10,22,32,32,3,7,7,2,6,2,2,2,1,7,10,1,22,24,20,22,22]
DAY=(date(2002,1,1)-date(1950,1,1)).days*86400+168*86400

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 if isinstance(x,np.generic):return x.item()
 return x
def dump(p,d):
 with p.open('x') as f:f.write(json.dumps(enc(d),indent=2)+'\n')
def emit(f,d):f.write(json.dumps(enc(d),separators=(',',':'))+'\n')
def bits(b):return ''.join(format(x,'08b') for x in b)
def field(b,pos,width,signed=False):
 q=b[pos:pos+width];assert len(q)==width
 v=int(q,2);return v-(1<<width) if signed and q[0]=='1' else v

def correlation(z,f):
 terms=z*np.exp(D1*f)
 C=terms.sum();Cp=(terms*D1).sum();Cpp=(terms*D2).sum()
 power=float(abs(C)**2)
 g=float(2*(Cp*C.conjugate()).real)
 h=float(2*((Cpp*C.conjugate()).real+abs(Cp)**2))
 return C,power,g,h

def estimate(z):
 ft=np.fft.fft(z,n=GRID);j=int(np.argmax(np.abs(ft)))
 base=float(np.fft.fftfreq(GRID,d=1/FS)[j]);step=FS/GRID
 lo=base-step;hi=base+step
 left=correlation(z,lo)[2];right=correlation(z,hi)[2]
 expansion=0
 while not(left>0 and right<0) and expansion<3:
  expansion+=1;lo-=step;hi+=step
  left=correlation(z,lo)[2];right=correlation(z,hi)[2]
 assert left>0 and right<0,'maximum derivative was not bracketed'
 f=base;iterations=0
 for iterations in range(1,61):
  C,p,g,h=correlation(z,f)
  if g>0:lo=f
  else:hi=f
  candidate=f-g/h if h<0 else (lo+hi)/2
  if not lo<candidate<hi:candidate=(lo+hi)/2
  if abs(candidate-f)<1e-11:
   f=candidate;break
  f=candidate
 f=(f+FS/2)%FS-FS/2
 C,p,g,h=correlation(z,f)
 S=float(np.vdot(z,z).real)
 assert h<0
 assert p+1e-12*S*N>=float(abs(ft[j])**2)
 amp=C/N*np.exp(-2j*np.pi*f*(N-1)/(2*FS))
 bound_D=2*np.pi*float(np.sum(np.abs(T)*np.abs(z)))
 upper=min(math.sqrt(N*S),float(abs(ft[j]))+bound_D*FS/(2*GRID))
 return {'frequency_Hz':f,'grid_frequency_Hz':base,'grid_index':j,'grid_size':GRID,
 'grid_peak_abs':float(abs(ft[j])),'refined_peak_abs':float(abs(C)),
 'correlation_power':p,'residual_squared':S-p/N,'amplitude_real':float(amp.real),'amplitude_imag':float(amp.imag),
 'derivative':g,'second_derivative':h,'newton_displacement_Hz':-g/h,
 'iterations':iterations,'bracket_expansions':expansion,
 'analytic_grid_bound_numerical_residual_lower':max(0.,S-upper*upper/N),
 'numerical_bound_is_interval_certificate':False}

def exact_cell(xy):
 q=[int(a)*int(a)+int(b)*int(b) for a,b in xy]
 S=sum(q);C=sum(math.isqrt(n)+(math.isqrt(n)**2<n) for n in q)
 lhs=N*S-C*C;threshold=2*N*N
 low=[max(abs(int(a))-1,0)**2+max(abs(int(b))-1,0)**2 for a,b in xy]
 high=[(abs(int(a))+1)**2+(abs(int(b))+1)**2 for a,b in xy]
 return {'sum_squared_amplitude':S,'sum_ceil_amplitude':C,'N_S_minus_C_squared':lhs,
 'quantization_threshold':threshold,'radial_residual_certificate':lhs>threshold,
 'max_cell_min_radius_squared':max(low),'min_cell_max_radius_squared':min(high),
 'common_amplitude_interval_disjoint':max(low)>min(high),
 'extreme_components':int(np.count_nonzero(np.abs(xy)==65535)),
 'origin_touching_cells':int(np.count_nonzero(np.all(np.abs(xy)==1,axis=1)))}

def synthetic():
 tests=[]
 for f in (-499.99,-123.456789,-.01,0.,.123456789,131.876543,499.99):
  z=(1.3-.2j)*np.exp(2j*np.pi*f*np.arange(N)/FS)
  e=estimate(z);error=((e['frequency_Hz']-f+500)%1000)-500
  assert abs(error)<1e-8
  tests.append({'true_frequency':f,'error':error,'fit':e})
 return tests

def spectral():
 schema=json.loads((OLD/'PRIMARY_LABEL_SCHEMA_v1.json').read_text());names={r['NAME']:r['COLUMN_NUMBER']-1 for r in schema}
 result={};summary={}
 with (OUT/'SPECTRAL_ROWS_v1.jsonl').open('x') as f:
  for band,stem in [('X','1a1'),('KA','1b1')]:
   xy=np.fromfile(OLD/(stem+'_WINDOW_IQ_i32be_v1.bin'),dtype='>i4').reshape(600,N,2)
   with (OLD/(stem+'_HEADERS_v1.jsonl')).open() as h:
    heads=[json.loads(next(h)) for _ in range(600)]
   rows=[]
   for k in range(600):
    vals=heads[k]['header_values_by_column_1_to_71'];header={name:vals[j] for name,j in names.items() if j<71}
    assert header['SFDU SECOND']==48900+k and header['SAMPLE RATE']==1 and header['SAMPLE RESOLUTION']==16
    z=xy[k,:,0].astype(float)+1j*xy[k,:,1].astype(float)
    a=estimate(z);b=exact_cell(xy[k]);row={'band':band,'second':48900+k,'record_index':k,'fit':a,'exact_cell':b,'header':header}
    emit(f,row);rows.append(row);result[(band,48900+k)]=row
   summary[band]={'blocks':len(rows),'radial_rejections':sum(t['exact_cell']['radial_residual_certificate'] for t in rows),
    'amplitude_interval_rejections':sum(t['exact_cell']['common_amplitude_interval_disjoint'] for t in rows),
    'maximum_stationarity_displacement_Hz':max(abs(t['fit']['newton_displacement_Hz']) for t in rows),
    'frequency_min_max':[min(t['fit']['frequency_Hz'] for t in rows),max(t['fit']['frequency_Hz'] for t in rows)],
    'flags':dict(Counter((t['header']['DATA ERROR COUNT'],t['header']['FROV FLAG']) for t in rows))}
 return result,summary

def decode_odf():
 raw=(RAW/'c32easc2002_169_0000xmmmv0.odf').read_bytes();assert len(raw)==92064*36
 rows=[]
 for rec in range(6,91869):
  b=bits(raw[(rec-1)*36:rec*36]);cursor=0;a={}
  for item,width in enumerate(ODF_WIDTHS,1):
   a[item]=field(b,cursor,width,item in (4,5,20));cursor+=width
  assert a[6]==2
  if (a[7],a[8],a[11])!=(25,54,2) or a[10] not in (12,13):continue
  middle=F(a[1]*1000+a[2],1000);duration=F(a[21],100)
  start=middle-duration/2;end=middle+duration/2
  if start<DAY+48900 or end>DAY+49500:continue
  rows.append({'record':rec,'items':a,'start':start,'end':end,'T':duration,'D':F(a[4]*10**9+a[5],10**9),'ODF_reference':F(a[18]*2**24+a[19],1000)})
 return rows

def decode_atdf():
 raw=(RAW/'c32easc2002_169_0000xmmmv0.tdf').read_bytes();assert len(raw)==160888*288
 index=defaultdict(list);selected=[]
 for rec in range(3,160873):
  block=raw[(rec-1)*288:rec*288];b=bits(block[:36])
  short={i:field(b,*pos,signed=i==20) for i,pos in ATDF_FIELDS.items() if pos[0]+pos[1]<=288}
  if (short[4],short[5],short[10],short[11])!=(102,169,25,2) or short[12] not in (1,2,7,11,12):continue
  second=short[6]*3600+short[7]*60+short[8]
  if not 48900<=second<=49500:continue
  b=bits(block);a={i:field(b,*pos,signed=i==20) for i,pos in ATDF_FIELDS.items()}
  phase=F(a[30]*10**14+a[31]*10**7+a[32],10**6);ref=F(a[43]*10**9+a[44],10**6)
  key=(DAY+second,a[10],a[11],a[14],a[13],a[15])
  row={'record':rec,'second':second,'items':a,'key':key,'phase':phase,'reference':ref}
  index[key].append(row);selected.append(row)
 return index,selected

def references(spectra):
 odf=decode_odf();idx,atdf=decode_atdf();variants=[];used=set();slip_occ=[];missing=[];errors=defaultdict(list)
 with (OUT/'ATDF_WINDOW_ROWS_v1.jsonl').open('x') as f:
  for a in atdf:emit(f,a)
 with (OUT/'ODF_WINDOW_ROWS_v1.jsonl').open('x') as f:
  for a in odf:emit(f,a)
 with (OUT/'REFERENCE_ROWS_v1.jsonl').open('x') as out:
  for a in odf:
   o=a['items'];s=a['start'];end=a['end']
   def key(t):return (t,o[7],o[11],o[10]-10,o[15],o[16])
   left=idx.get(key(s),[]);right=idx.get(key(end),[])
   if not left or not right:missing.append(a['record']);continue
   assert a['T']==1 and s.denominator==1
   rsr=spectra[('X',int(s)-DAY)];h=rsr['header'];fit=rsr['fit']['frequency_Hz']
   lo=(F(h['DDC LO FREQUENCY'])+F(h['RF-IF LO FREQUENCY']))*10**6
   p=[F(h['SUB-CHANNEL PHASE COEF P'+str(j)]) for j in range(1,5)]
   for q0 in left:
    for q1 in right:
     used.update([q0['record'],q1['record']]);raw=q1['phase']-q0['phase'];forward=raw%(2**32)
     assert q0['reference']==q1['reference']
     ref=F(880,221)*q0['reference'];skyODF=ref-a['D'];countD=forward/a['T']-10**6;skyATDF=ref-countD
     row={'ODF':a,'ATDF_start':q0,'ATDF_end':q1,'raw_count_increment':raw,'modulo_2pow32_increment':forward,
      'conditional_forward_history_integer':(forward-raw)/2**32,'history_condition':'Modulo representative is not a derived physical history; raw difference also retained.',
      'stored_reference_times_880_over_221_Hz':ref,'ODF_mean_sky_Hz':skyODF,'conditional_ATDF_mean_sky_Hz':skyATDF,
      'raw_ATDF_mean_sky_Hz':ref-(raw/a['T']-10**6),'countD_minus_ODF_D_Hz':countD-a['D'],
      'fitted_baseband_Hz':fit,'candidates':[]}
     for endpoint,q in [('start',q0),('end',q1)]:
      if q['items'][87]>0:slip_occ.append({'ODF':a['record'],'endpoint':endpoint,'ATDF':q['record'],'item87':q['items'][87]})
     for shift in (F(0),F(1,2000)):
      # Exact integral of archived cubic phase derivative, expanded independently.
      dn=p[1]+p[2]*(1+2*shift)+p[3]*(1+3*shift+3*shift*shift)
      for sign in (-1,1):
       offsetODF=lo-dn-skyODF;offsetATDF=lo-dn-skyATDF
       error=float(offsetODF)+sign*fit;errorA=float(offsetATDF)+sign*fit
       cand={'shift_seconds':shift,'sign':sign,'LO_Hz':lo,'NCO_phase_increment_cycles':dn,
        'exact_offset_to_ODF_before_fitted_frequency_Hz':offsetODF,'error_to_ODF_Hz':error,
        'exact_offset_to_ATDF_before_fitted_frequency_Hz':offsetATDF,'error_to_ATDF_Hz':errorA}
       row['candidates'].append(cand);errors[(str(shift),sign)].append(error)
     emit(out,row);variants.append(row)
 hist=Counter((q['items'][19],q['items'][24],q['items'][87],q['items'][26],q['items'][20],q['items'][22],q['items'][23]) for q in atdf if q['record'] in used)
 summaries=[]
 for key,v in errors.items():
  a=np.array(v);summaries.append({'shift_seconds':key[0],'sign':key[1],'count':len(v),'min_median_max_Hz':[float(np.min(a)),float(np.median(a)),float(np.max(a))],'RMS_Hz':float(np.sqrt(np.mean(a*a)))})
 return {'ODF_records':len(odf),'ATDF_window_rows':len(atdf),'matched_variants':len(variants),'missing_ODF':missing,
 'unique_ATDF_used':len(used),'nonzero_slip_endpoint_occurrences':slip_occ,'nonzero_slip_unique_records':sorted({x['ATDF'] for x in slip_occ}),
 'intervals_with_nonzero_slip':len({x['ODF'] for x in slip_occ}),
 'ATDF_quality_and_receiver_histogram':[{'fields19_24_87_26_20_22_23':list(k),'count':v} for k,v in sorted(hist.items())],
 'raw_negative_increment_count':sum(x['raw_count_increment']<0 for x in variants),
 'nonzero_history_integer_count':sum(x['conditional_forward_history_integer']!=0 for x in variants),
 'max_abs_countD_minus_ODF_D_Hz':str(max(abs(x['countD_minus_ODF_D_Hz']) for x in variants)),
 'candidate_summaries':summaries,'scope':'All fixed-window records retained; physical reference and local carrier-frequency identification remain conditional; no fit offset/time/sign selection.'}

def main():
 start=time.monotonic();inputs=json.loads((OUT/'PRECOMPUTE_FREEZE_v1.json').read_text())
 for d in inputs['inputs']:
  assert sha(Path(d['path']))==d['sha256']
 tests=synthetic();dump(OUT/'SYNTHETIC_RESULTS_v1.json',tests)
 spectra,specsum=spectral();refs=references(spectra)
 result={'spectral':specsum,'reference':refs,'synthetic_count':len(tests),'elapsed_seconds':time.monotonic()-start,
 'author_M10_code_or_results_read_before_computation':False,'independent_empirical_tests':0,'physical_noise_bound_inferred':False,
 'spectral_status':'Distinct 32768-bin grid plus direct-correlation safeguarded Newton refinement; a sampled-global then local numerical estimate, not a proof of exact global maximum.'}
 dump(OUT/'RESULTS_v1.json',result);print(json.dumps(enc(result),indent=2))
if __name__=='__main__':main()
