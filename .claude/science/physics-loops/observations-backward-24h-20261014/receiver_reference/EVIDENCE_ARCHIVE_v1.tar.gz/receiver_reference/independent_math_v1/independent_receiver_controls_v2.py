"""Independent exact finite-vector, cell and grid controls; no author import or data."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json


def z(x=0,y=0): return (F(x),F(y))
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def sub(a,b): return (a[0]-b[0],a[1]-b[1])
def mul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def conj(a): return (a[0],-a[1])
def scale(a,q): return (a[0]*q,a[1]*q)
def n2(a): return a[0]**2+a[1]**2
def sumz(a):
    out=z()
    for b in a: out=add(out,b)
    return out

def qturn(k): return (z(1),z(0,1),z(-1),z(0,-1))[k%4]
def norm2(a): return sum((n2(x) for x in a),F(0))
def residual(zs,us,c): return norm2([sub(x,mul(c,u)) for x,u in zip(zs,us)])
def projection(zs,us):
    if not zs or len(zs)!=len(us): raise ValueError('nonempty equal lengths required')
    if any(n2(u)!=1 for u in us): raise ValueError('unit template required')
    a=sumz([mul(conj(u),x) for u,x in zip(us,zs)])
    c=scale(a,F(1,len(zs)))
    e=norm2(zs)-n2(a)/len(zs)
    return c,e

def feasible(zs,us,b2,nonzero=False):
    if b2<0: raise ValueError('negative squared budget')
    c,e=projection(zs,us)
    return e<=b2 and (not nonzero or e<b2 or n2(c)>0)

def ceilroot(k):
    if not isinstance(k,int) or k<0:raise ValueError('nonnegative integer required')
    m=isqrt(k);return m+(m*m<k)

def ceillower(zs):
    if not zs:raise ValueError('N>=1')
    s=norm2(zs)
    if s.denominator!=1 or any(n2(x).denominator!=1 for x in zs):raise ValueError('integer squared radii required')
    c=sum(ceilroot(int(n2(x))) for x in zs)
    return max(F(0),s-F(c*c,len(zs))),c,len(zs)*s-c*c

def radial_bounds2(x):
    a,b=map(abs,x)
    return max(a-1,0)**2+max(b-1,0)**2,(a+1)**2+(b+1)**2

def common_amplitude(zs):
    if not zs:raise ValueError('N>=1')
    vals=[radial_bounds2(x) for x in zs]
    return max(x[0] for x in vals)<=min(x[1] for x in vals)

def cell_contains(center,point):return all(abs(a-b)<=1 for a,b in zip(center,point))
def fixed_quarter_tone_box(zs,turns):
    if not zs or len(zs)!=len(turns):raise ValueError('nonempty equal lengths required')
    centers=[mul(conj(qturn(k)),x) for x,k in zip(zs,turns)]
    lo=(max(x[0]-1 for x in centers),max(x[1]-1 for x in centers))
    hi=(min(x[0]+1 for x in centers),min(x[1]+1 for x in centers))
    return lo,hi,all(a<=b for a,b in zip(lo,hi))

def interval_dist2(a,lo,hi): return max(lo-a,F(0),a-hi)**2

def one_d_cell_distance(intervals):
    # A separate exact active-set construction; endpoints and active-bound means
    # exhaust stationary/boundary candidates of this 1-D convex piecewise quadratic.
    ends=sorted({F(0)}|{F(x) for ab in intervals for x in ab})
    candidates=set(ends)
    for lo,hi in zip(ends,ends[1:]):
        probe=(lo+hi)/2
        active=[a if probe<a else b for a,b in intervals if probe<a or probe>b]
        if active:
            mean=sum(active,F(0))/len(active)
            if lo<=mean<=hi:candidates.add(mean)
    def obj(a):return sum(interval_dist2(a,F(lo),F(hi)) for lo,hi in intervals)
    best=min((obj(a),a) for a in candidates if a>=0)
    return best


def main(out):
    checks=[]
    def ck(name,condition,detail=None):
        assert condition,name
        checks.append({'name':name,'passed':True,**({'detail':detail} if detail else {})})
    def bad(name,fn):
        try:fn()
        except ValueError:ck(name,True)
        else:raise AssertionError(name)
    us=[z(1),z(0,1)];c0=z(2,-1)
    zs=[mul(c0,u) for u in us]
    c,e=projection(zs,us)
    ck('Hermitian correlation recovers complex amplitude',c==c0 and e==0)
    wrong=sumz([mul(u,x) for u,x in zip(us,zs)])
    ck('nonconjugated correlation fails exact complex fixture',wrong!=scale(c0,2))
    orth=[z(3),z(0,-3)]
    zo=[add(x,y) for x,y in zip(zs,orth)]
    c,e=projection(zo,us)
    ck('orthogonal noise leaves amplitude',c==c0)
    ck('orthogonal noise fully enters residual',e==18 and norm2(orth)==18)
    alpha=z(3,2);parallel=[mul(alpha,u) for u in us]
    zp=[add(x,y) for x,y in zip(zs,parallel)]
    c,e=projection(zp,us)
    ck('parallel error shifts amplitude',c==add(c0,alpha))
    ck('parallel noise invisible to fitted residual',e==0 and norm2(parallel)==26)
    mix=[z(7),z(-2,3)]
    cm,em=projection(mix,us)
    ck('mixed error orientation gives known projection',cm==z(5,1) and em==10)
    ck('mixed true error exceeds fitted residual',residual(mix,us,c0)==36)
    for k,candidate in enumerate([z(),z(1),z(1,1),z(-3,2),cm]):
        ck('Pythagorean complex disk identity '+str(k),residual(mix,us,candidate)==em+2*n2(sub(candidate,cm)))
    ck('budget below minimum rejected',not feasible(mix,us,F(9)))
    ck('budget at minimum admitted',feasible(mix,us,F(10)))
    ck('known boundary amplitude is feasible',residual(mix,us,add(cm,z(1)))==12)
    ck('outside disk is infeasible',residual(mix,us,add(cm,z(2)))>12)
    bad('empty vector rejected',lambda:projection([],[]))
    bad('nonunit template rejected',lambda:projection([z(1)],[z(2)]))
    bad('negative error budget rejected',lambda:feasible(zs,us,-1))
    ztrue=[z(1),z(1)];u0=[z(1),z(1)];u1=[z(1),z(-1)]
    ck('fitted exact dc carrier residual zero',projection(ztrue,u0)[1]==0)
    ck('different noisy true carrier has discrepancy squared four',residual(ztrue,u1,z(1))==4)
    ck('true-frequency optimized residual lower than noise',projection(ztrue,u1)[1]==2)
    ck('false fitted-zero noise budget excludes possible truth',not feasible(ztrue,u1,0))
    ck('independently supplied true budget admits it',feasible(ztrue,u1,4,True))
    ck('zero-amplitude edge admitted if allowed',feasible(ztrue,u1,2))
    ck('zero-amplitude edge excluded if nonzero required',not feasible(ztrue,u1,2,True))
    ck('strictly larger bound allows nonzero amplitude',feasible(ztrue,u1,F(201,100),True))
    for k in range(4):
        ck('one sample gives no frequency constraint '+str(k),projection([z(2,3)],[qturn(k)])[1]==0)
    ck('integer-sampling alias fixture',[qturn(k) for k in range(3)]==[qturn(k+4*k) for k in range(3)])
    for k in [0,1,2,16,17,34,10**80,(10**50+1)**2,(10**50+1)**2+1]:
        c=ceilroot(k);ck('exact ceil-square enclosure '+str(k),c*c>=k and (c==0 or (c-1)**2<k))
    bad('negative radius square rejected',lambda:ceilroot(-1))
    identical=[z(3,5),z(3,5)]
    lo,ct,disc=ceillower(identical)
    ck('ceil bound does not reject equal amplitude',lo==0 and disc<=8)
    cf=2*isqrt(34)
    ck('floor radius creates false exclusion witness',2*norm2(identical)-cf*cf>8 and residual(identical,u0,z(3,5))==0)
    boundary=[z(1,1),z(3,3)];q=z(2,2)
    ck('closed cell equality candidate exists',all(cell_contains(x,q) for x in boundary))
    ck('coordinate cell factor is two per sample',residual(boundary,u0,q)==4)
    ck('closed cell equality cannot be strictly rejected',common_amplitude(boundary))
    ck('boundary radial squares touch exactly',radial_bounds2(boundary[0])[1]==radial_bounds2(boundary[1])[0]==8)
    far=[z(1,1),z(9,9)]
    lo,ct,disc=ceillower(far)
    ck('integer ceil certificate exact values',norm2(far)==164 and ct==15 and disc==103 and lo==F(103,2))
    ck('strict aggregate rule excludes all common modulus cells',disc>2*len(far)**2)
    ck('exact radial rule excludes same example',not common_amplitude(far))
    ck('radial interval formula exact',radial_bounds2(far[0])==(0,8) and radial_bounds2(far[1])==(128,200))
    ck('one cell always admits some amplitude',common_amplitude([z(1,1)]))
    ck('origin-containing cell lower bound zero',radial_bounds2(z(1,1))[0]==0)
    ck('origin-centered general geometric cell handled',radial_bounds2(z())==(0,2))
    opposite=[z(3,3),z(-3,-3)]
    ck('amplitude-only test can pass',common_amplitude(opposite))
    ck('same data fail fixed dc phase intersection',not fixed_quarter_tone_box(opposite,[0,0])[2])
    ck('opposite phases admit same underlying complex amplitude',fixed_quarter_tone_box(opposite,[0,2])==(z(2,2),z(4,4),True))
    ck('quarter rotation respects rectangular geometry',fixed_quarter_tone_box([z(3,3),z(-3,3)],[0,1])[2])
    # Normalize the diagonal example by sqrt(2): actual squared distances are 2x.
    minimum,amplitude=one_d_cell_distance([(0,2),(8,10)])
    ck('exact cell-to-common-amplitude distance',minimum==18 and amplitude==5)
    ck('distance gives lower error six not upper bound',2*minimum==36)
    ck('overlapping radial intervals give zero discrepancy',one_d_cell_distance([(0,2),(2,4)])[0]==0)
    ck('nested radial intervals give zero discrepancy',one_d_cell_distance([(1,4),(2,3)])[0]==0)
    ck('active-set boundary minimum checked',one_d_cell_distance([(0,1),(3,4),(5,6)])==(F(8),F(3)))
    ck('interior active-set rational minimum checked',one_d_cell_distance([(0,1),(4,5),(8,9)])==(F(49,2),F(9,2)))
    # Correlations at exact quarter-turn phases, no floating FFT.
    def corr(zs,turns):return sumz([mul(conj(qturn(k)),x) for x,k in zip(zs,turns)])
    off=[z(1),z(-1)]
    g0=corr(off,[0,0]);g1=corr(off,[0,4]);peak=corr(off,[0,2])
    ck('coarse frequency grid both amplitudes zero',n2(g0)==n2(g1)==0)
    ck('off-grid amplitude two exactly',n2(peak)==4)
    ck('naive sampled maximum falsely excludes exact tone',projection(off,[z(1),z(-1)])[1]==0 and norm2(off)-max(n2(g0),n2(g1))/2==2)
    # tau=1/2: sum |t-tau||z| =1, delta=1/2. pi<22/7 yields U<=22/7.
    ck('conservative Lipschitz upper bound covers hidden peak',F(22,7)>=2)
    ck('triangle cap sharpens certified enclosure to two',min(F(22,7),F(2))==2)
    raw0=corr([z(1)],[0]);rawhalf=corr([z(1)],[2])
    ck('centering cannot bound uncentered complex difference by zero',n2(sub(raw0,rawhalf))==4)
    centered0=corr([z(1)],[0]);centeredhalf=corr([z(1)],[0])
    ck('centered complex correlation correctly constant',centered0==centeredhalf)
    ck('magnitude correlation unaffected by time-origin phase',n2(raw0)==n2(rawhalf)==n2(centered0))
    times=[F(0),F(1),F(100)];weights=[F(1),F(10),F(1)]
    cost=lambda tau:sum(abs(t-tau)*ww for t,ww in zip(times,weights))
    ck('weighted median improves ordinary mean L1 bound',cost(1)==100 and cost(1)<cost(F(101,3)))
    ck('weighted-median endpoint slope check',cost(1)<cost(0) and cost(1)<cost(100))
    result={'scope':'exact synthetic controls only; no empirical inference','source_exposure':'only task-announced formulas; no author source read','count':len(checks),'checks':checks,'floating_FFT_or_interval_certificate_claimed':False,'ordinary_pi_upper_bound_used':'pi < 22/7, only in a synthetic conservative enclosure','independent_empirical_tests':0,'new_physical_noise_budget':False,'failure_witnesses':['missing complex conjugation','parallel noise invisible to fitted residual','fitted zero residual excludes possible noisy true carrier','floor rather than ceil radii falsely exclude equal-amplitude centers','non-strict or one-coordinate cell norm threshold falsely rejects boundary','amplitude overlap alone does not ensure a fixed-frequency tone','sampled grid maximum misses exact off-grid peak','centered L applied to uncentered complex A is invalid']}
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'count':len(checks),'all_passed':True,'results':str(out)}))

if __name__=='__main__':main(Path(__file__).with_name('INDEPENDENT_RESULTS_v2.json'))
