import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/scripts')
sys.path.insert(0,'/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/mutation_results_v1/doppler_sign')
import cassini_carrier_estimator as c, cassini_receiver_reference as r, cassini_carrier_geometry_controls as g
c.ROOT=r.ROOT=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
import shutil
o=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/mutation_results_v1/doppler_sign/outputs');o.mkdir(exist_ok=True)
shutil.copyfile('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/development_outputs_v1/CARRIER_ESTIMATES_v1.jsonl',o/'CARRIER_ESTIMATES_v1.jsonl')
a=r.run(r.ROOT/'outputs/cassini_doppler_inputs',o,Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference'))
assert a['X_reference_Hz']['numerator']==1863016320000 and a['X_reference_Hz']['denominator']==221,'documented reference scale'
assert a['maximum_ODF_ATDF_sky_difference_Hz']<5e-7,'dependent storage difference'
assert a['ATDF_endpoint_nonzero_slip_diagnostics']==54,'preserve slip diagnostic'
