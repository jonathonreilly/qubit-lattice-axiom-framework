import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/scripts')
sys.path.insert(0,'/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/receiver_reference/mutation_results_v1/phase_cubic_shift')
import cassini_carrier_estimator as c, cassini_receiver_reference as r, cassini_carrier_geometry_controls as g
c.ROOT=r.ROOT=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
c.controls();g.controls()
