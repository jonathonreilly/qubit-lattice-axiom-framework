# Joint photon/background derivation — first frozen candidate

Root derivation, before executing new controls. Conditional class and full source equations are those of PR9639. Work in the equal-Einstein-potential convention, or a fully recovered full-sky angular sector l>=2; the latter removes the local traceless-Hessian and time-only integration kernels. This is an explicit domain, not a claim that a mask supplies it. Prime means matter-time derivative at fixed comoving position; partial_r is at fixed matter time. h and a are registered, a'=ha; Y=Rz is the same-dust, path/observer-corrected radial redshift. No real observational arrays are inputs.

Set G=x/b, C=R/G, D=-2/G and E=(h-q)D-1. Momentum and Euler imply

    Z'+C Z = D P'+E P = F,
    Z'+a^-1 Z_r=Y.

C,D,E are unknown background functions, not supplied observables. With T=partial_tau+a^-1 partial_r and K=C'+hC, their commutator gives

    K Z = (T+h)F - (partial_tau+C+h)Y = N.

For K!=0 define delta=C-K'/K. Differentiating N/K with the first equation gives

    (partial_tau+delta)N-K F=0.

At an epoch this has an eight-coefficient observed relation with rows

    [P'''+P''_r/a, P'', P'_r/a, P', P_r/a, P, -Y', -Y]

and target Y''. Its coefficients [D,c2,cr,c1,cr0,c0,p,z] are proposed to be

    c2=2D'+E+(h+delta)D,
    cr=D'+E+(delta-h)D,
    c1=D''+E'+h'D+hD'+delta(D'+E+hD)-KD,
    cr0=E'+(delta-h)E,
    c0=E''+h'E+hE'+delta(E'+hE)-KE,
    p=C+h+delta, z=C'+h'+delta(C+h).

The first consistency identity is c2-cr=D'+2hD. Define from extracted coefficients

    Q=p-h-(cr-D'+1)/D.

Then q=Q-C, G=-2/D, R=-2C/D. Dust transport and the z coefficient give the candidate polynomial

    3C^2+(5h-p-D'/D-2Q)C+z-h'-ph+h^2=0.

Raychaudhuri gives a second quadratic

    3C^2+(4h-4Q-D'/D)C+Q'-h'-hQ+Q^2+Q/D=0.

Their difference is linear. Where L=p-h-2Q!=0 the candidate is

    C=-(Q'-hQ+Q^2+Q/D-z+ph-h^2)/L.

If L=0 the quadratics can retain two, one or no roots; none may be selected by preference. All source/background and coefficient residuals must hold over an interval. Rank eight may exclude K=0 because N=0 at such an epoch would give a nonzero null vector among the eight columns. This implication and attainability of rank eight on actual full-equation fields have NOT yet been checked. If physical fields cannot attain the rank, the proposed extraction fails; preserve that result.

From a surviving nonzero q,G with q/G>0 construct b=sign sqrt(q/G), x=q/b, A=A0 exp integral q, phi=phi0+M integral x, V=M^2 A^2[3(h-q)^2-x^2/2-R]. Curvature follows from the original force identity, not a fitted pole: Fbar=-x'-3hx+2qx and kappa=(Fbar'+2qFbar+3(h-q)bR)/x. Enforce every original field equation after reconstructing Z=N/K, J=-P-Z', w=J/b and delta from the Hamiltonian. Failure of any residual rejects the candidate. Absolute normalization, field origin/orientation, action/species, calibration, ideal derivatives and global history remain outside this conditional target.

## Frozen forward protocol

Exact power backgrounds in Einstein time: M=1, H=p/t, phi=c ln t, A=t^s, s=3p-2, aE=t^p, rE=(2p-c^2)t^-2, rho=(2p-c^2)t^-3p, V=(3p^2-2p+c^2/2)t^-2. Require t>0, 2p>c^2, c!=0, s!=0, s+1!=0. Matter time tau=t^(s+1)/(s+1). Primary regular case p=2,c=1; independent variant p=3/2,c=1; exceptional diagnostic p=1,c=1. These are constructed forward cases, not data-fitted environments or selected physical initial states.

Generate exact analytic time jets from the original Einstein momentum/scalar/dust equations at t=1 for k_com^2 in {1,2,3,5}, four state basis seeds (P,u,u_dot,U), and local radial Helmholtz amplitudes (f,f_r)=(1,0),(0,1) at r=1. The Hamiltonian defines dust contrast and its propagation must be checked; do not generate fields from the proposed inverse relation. Angular l>=2 radial solutions with these local values exist on an annulus. No origin regularity, decay or measured spatial spectrum is asserted. Compute exact rational design rank and coefficient/residual consistency; freeze all seeds and parameter choices now. If rank is deficient, do not quietly add handpicked jets. Report the obstruction and revise the observation target explicitly.

No independent proof, successful numerical control, empirical inference or novelty claim is yet asserted. Kinematic differential elimination by itself is insufficient for physical compatibility. This first draft will remain immutable; corrections get a new version.
