# Joint reconstruction with unknown channel gains — root candidate v1

Status: conditional-support candidate; no empirical validation. Root directly derives this extension. It is downstream of the supplied canonical conformal scalar/dust equations and a provisional joint input-output identity, not an action selection. Its hypotheses include registered matter time and radius, known a,h, one complete l>=2 sector or the equal-Einstein-potential convention, same-dust corrected redshift, and rich smooth data on a product annulus. No real arrays are read.

Let X=g P and W=f Y with positive smooth spatially homogeneous gains. Write lambda=g'/g, mu=f'/f, r=f/g. The calibrated relation has coefficients D,c2,cr,c1,cr0,c0,p,z in the frozen joint v2 convention. Conjugating time derivatives yields measured coefficients

    Dt=r D,
    c2t=r(c2-3 lambda D),
    crt=r(cr-2 lambda D),
    c1t=r[c1-2 lambda c2+3(lambda^2-lambda')D],
    cr0t=r[cr0-lambda cr+(lambda^2-lambda')D],
    c0t=r[c0-lambda c1+(lambda^2-lambda')c2+(-lambda^3+3lambda lambda'-lambda'')D],
    pt=p-2mu, zt=z-p mu+mu^2-mu'.

The observed rank-eight design remains [X'''+X''_r/a, X'', X'_r/a, X', X_r/a, X, -W', -W], target W''. The difference identity gives a candidate exact drift extraction

    mu=2h+(Dt'-c2t+crt)/Dt.

Thus f is reconstructed up to one constant. Divide W by this reconstructed f, keeping X as recorded. A common constant amplitude is immaterial in the linear system; it is not an absolute gravitational calibration. The following letters D,E denote the coefficients of Z'+C Z = D X'+E X after this correction, NOT the original calibrated D,E.

From corrected measured coefficients define

    alpha=(cr-D')/D-p+2h,
    Hc=D'-D alpha,
    Bc=D' alpha+D alpha'+D[z-h'-p h+h^2+(p-2h)alpha].

Then E=D(C+alpha) and the transport coefficient z gives

    C'=C^2+(2h-p)C+z-h'-p h+h^2.

The cr0 identity gives Hc C=cr0-Bc. Where Hc!=0, C is therefore determined from the corrected data kinematically. A generic symbolic check already returned zero for this identity; no physical forward controls of this extension have yet run. Hc=0 must remain an explicit exception until other coefficient identities are analyzed. K=C'+hC and all original coefficient residuals remain necessary.

With f corrected to one, put r=1/g and u=r/D (D is the measured coefficient). Let

    S=p-h-(cr-D')/D,
    Q0=C'/C-D'/D+3h-S+C,
    A0=C'/C-2D'/D+3h-2S+2C.

Momentum and the action identification imply q=Q0+u, G=-2u and R=-2C u. Dust transport gives

    u'=u(A0+2u).

Raychaudhuri gives the proposed quadratic

    4u^2+(A0-h+3Q0+C)u+Q0'-h'-h Q0+Q0^2=0.

Consequently at most two smooth local u histories can survive at a regular epoch if the derivation checks: each satisfies this quadratic and a smooth Riccati ODE. It is only an upper bound, not proof of two realizations. Positive gains require uD>0; positive dust requires C u<0; canonical real scalar requires u(Q0+u)<0. Reject all roots that fail any coefficient/background/original perturbation residual; never select a root by preference. Reconstruct P=rX, Z through the commutator inverse, J=-P-Z', and then the scalar history per candidate. The absolute common perturbation amplitude, conformal normalization, field origin/sign, action, scales, observational correction and errors remain supplied or unfixed. This candidate does not establish global theory uniqueness.

## Frozen tests before execution

1. Symbolically conjugate the entire generic relation, recover mu, verify Hc C and the dust/Raychaudhuri identities using arbitrary smooth gains.
2. Use the already declared original-equation backgrounds p=2,c=1 and p=3/2,c=1. Gain choices in Einstein parameter t are g=t^(2/3) exp((t-1)/7), f=t^(-1/4) exp((t-1)/5), and constants g=3/2, f=7/4. These are synthetic development inputs, not empirical calibration or independent validation.
3. Transform original forward state rows analytically, including gain derivatives; extract all eight coefficients by exact linear solve and compare with algebra. Test recovered mu, C, q/G/R and rejected roots. Preserve failures.
4. A rank-deficient physical case remains an exception; do not add invented jets. No new real arrays or fitting.

An initial shell write attempt failed before execution because a Python triple-single-quoted string collided with the notation for P's third derivative. No derivation file or scientific computation was produced by that attempt. This patch-based write preserves the intended candidate without that parser ambiguity.
