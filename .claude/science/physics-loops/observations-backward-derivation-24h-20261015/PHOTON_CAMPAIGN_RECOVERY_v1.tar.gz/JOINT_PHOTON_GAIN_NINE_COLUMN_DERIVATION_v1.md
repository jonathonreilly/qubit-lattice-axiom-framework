# Joint background and two-channel calibration — root integration candidate v1

Status: conditional-support candidate. This combines the focused checker's independently frozen nine-column radial construction with root's two-channel gain derivation. The checker's source is `independent_joint_photon_background/DERIVATION_BEFORE_CODE_v1.md`, SHA be414154d08952ec6b5dfd1252a2103cc66c35ef9b4f4801e0666bef4e59f8f2, frozen before root comparison. Root has read its complete proof, forward-equation source and angular-assembly source and rederived the displayed identities. The combined gain result is not independently checked yet.

The supplied physical class, linearization, known calibrated a,h, corrected same-dust redshift, full recovered l>=2 sector or equal-Einstein-potential convention, product annulus, regularity and nonzero scalar speed/coupling remain. This is an ideal mathematical inverse. It does not establish a measurement protocol, observed derivatives or noise control. No new empirical arrays are used.

Let L=partial_tau+a^-1 partial_r, h=a'/a. Physical quantities obey

    Z'+C Z=-d P'-e P,  LZ=Y,
    C=R/G, d=2/G, e=1+d(h-q), K=C'+hC.

For measured X=gP, W=fY with positive homogeneous matter-time gains, set lambda=g'/g, mu=f'/f, rho=f/g, D=rho d, E=rho(e-lambda d), and V=fZ. Then

    V'+(C-mu)V=-D X'-E X,  (L-mu)V=W,
    K V=-N,
    N=W'+(h+C-mu)W+(L+h-mu)(D X'+E X).

Where K!=0, set k=K'/K. The exact observable relation is

    (L-mu-k)N+K W=0.

Use the actual ordered differential operators in the nine-column row

    [W', L(W), W, L^2(X'), L(X'), X', L^2(X), L(X), X]

and target O=L(W')+h L(W)+h'W. In O+row theta=0, the coefficients are

    theta1=-k-mu,
    theta2=C-mu,
    theta3=2C'+hC-mu'-(k+mu)(h+C-mu),
    theta4=D,
    theta5=2D'+(h-k-2mu)D,
    theta6=D''+(h-k-2mu)D'+[h'-mu'-(k+mu)(h-mu)]D,
    theta7=E,
    theta8=2E'+(h-k-2mu)E,
    theta9=E''+(h-k-2mu)E'+[h'-mu'-(k+mu)(h-mu)]E.

Rank nine uniquely fixes theta. A K=0 candidate would give N=0 as a nonzero column-null relation with coefficient one on W'; therefore this rank excludes K=0 within the stated gain/class domain. D!=0 is required. The following are direct extractions, with no choice of background or gain:

    mu=h+theta1-(theta5-2D')/D,
    C=theta2+mu, k=-theta1-mu.

All coefficient identities, K=C'+hC and k=K'/K are residual tests. This route needs additional radial information compared with root's eight-column route and does not assume that rank eight implies rank nine. Its gain recovery avoids the eight-column auxiliary Hc!=0 condition.

Define entirely from these extracted functions

    T=h-E/D-mu,
    A=C'/C+3h-2T-2D'/D,
    Q=C'/C+3h-T-D'/D.

The remaining unknown is u=-G/2=-rho/D. The momentum identification and physical dust/Raychaudhuri equations imply

    u'=u(A+2u),
    q=Q+u, G=-2u, R=-2C u,
    4u^2+B u+F=0,
    B=A-h+3Q+C, F=Q'-h'-hQ+Q^2.

The leading coefficient four and smooth Riccati uniqueness give at most two local u histories on a connected regular chart. This counts background/calibration histories in the supplied class, not full theories. Existence and attainability of two physical branches are not asserted. Positive gains require -uD>0, positive dust C u<0 and a real nonzero canonical scalar u(Q+u)<0.

Differentiating the quadratic and reducing by it gives

    H1 u+H0=0,
    H1=B'-A B+B^2/2-4F,
    H0=F'+(B/2-2A)F.

Where H1!=0, u=-H0/H1; if H1=0 and H0!=0 there is no solution. If H1 and H0 both vanish identically, retain both possible quadratic branches and all residual tests. A nonzero H1 at any epoch gives at most one smooth surviving history on the connected chart. There is no branch-preference selector.

Recover rho=-uD, lambda=mu-u'/u-D'/D, and f=f0 exp integral mu, g=f/rho. Then P=X/g, Z=V/f with V=-N/K and J=-P-Z'. Reconstruct b,x,A(phi),V(phi) and fixed-bare-density curvature as in the source action, checking every original background and perturbation equation. f0 is a free common perturbation-amplitude calibration; conformal normalization, field origin/reflection, action class, scales, off-trajectory extensions, initial-state origin and observational correspondence remain unfixed.

The pressure-trace equation appears to become independent of u after substituting the dust Riccati and Raychaudhuri quadratic. This possible redundancy will be checked explicitly and must not be counted as an independent branch selector.

## Frozen development tests

Directly expand the generic gain-transformed nine-column operator; verify the coefficient extraction and K=0 null relation; derive the quadratic derivative remainder independently by polynomial division. Generate ordered time/radial jets from the original Einstein-time four-state constrained equations and the radial Helmholtz ODE. Use the previously frozen power backgrounds p=2 and p=3/2, c=1, gain choices from JOINT_PHOTON_GAIN_DERIVATION_v1.md, and 32 local rows with k^2 in {1,2,3,5}, four state basis vectors, radial seeds (1,0)/(0,1), assigned distinct l=2+i. Check actual rank and solve the measured coefficients, then recover the known background and relative gains without inserting them into the inverse. Test extra residuals and preserve failures. All are exposed synthetic development controls after independent nine-column exposure, not new observations or independent validation.
