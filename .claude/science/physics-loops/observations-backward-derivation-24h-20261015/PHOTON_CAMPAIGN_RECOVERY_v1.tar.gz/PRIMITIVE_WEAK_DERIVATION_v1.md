# Primitive-record weak residual: author candidate before execution

Under the plan's flat coordinate measure, integration by parts gives

    Tdagger=-T+h, Ldagger=-L+h,
    Qdagger v=-(1/2)partial_r(r^2 v), Rdagger=R.

The divergence terms are +h because partial_u(1/a)=-h and
(2partial_u+partial_r)(1/a)=-h. Compact support inside the chart removes
all boundary terms. Define, for a test lambda,

    H_W=Tdagger Ldagger lambda
        +Ldagger[(h+theta2)lambda]+Tdagger[theta1 lambda]
        +(h'+theta3)lambda,
    H_X=Tdagger (Ldagger)^2(theta4 lambda)
        +Tdagger Ldagger(theta5 lambda)+Tdagger(theta6 lambda)
        +(Ldagger)^2(theta7 lambda)+Ldagger(theta8 lambda)
        +theta9 lambda+(Tdagger)^2(theta10 lambda),
    H_B=(Tdagger)^3(theta11 lambda)+(Tdagger)^2(theta12 lambda)
        +Tdagger(theta13 lambda)+theta14 lambda,
    H_psi=R H_X+Qdagger[a H_B-2partial_u H_W].

Then the proposed exact identity is

    integral lambda*(A_W W+A_X X+A_B B)
      = integral H_W*z_obs+H_psi*psi_obs.

For fixed smooth candidate coefficients and compact test lambda, errors bounded
pointwise by epsilon_z and epsilon_psi imply

    |delta residual| <= epsilon_z ||H_W||_1+epsilon_psi ||H_psi||_1.

Alternatively use the corresponding L2 dual norms. The standard distributional
equivalence uses all compact test functions, not a finite selected set. This
transfers differentiation to known weights and candidate histories; it does
not derive the coefficient family or certify parameter identification from a
finite number of moments. Candidate regularity is still needed to form the
weights; it is not a fitted selection principle.

Planned exact witness: a=1/(1+u-r), h=-1 on u in (0,1), r in (0,1/2);
psi=(1+u-r)^2*(u^2+r^3+ur), z=u^3+2r^2; test lambda equal to
[u(1-u)r(1/2-r)]^6, extended by zero. This is sufficiently differentiable
with vanishing boundary traces for the finite-order identity, although it is
not a globally C-infinity bump. Theta_i are explicitly chosen nonzero
polynomials, not asserted to satisfy scalar dynamics. This nonzero-residual
witness checks the operator identity rather than matching zero to zero.

This is a candidate derivation pending calculation and focused independent
checking; no mathematical or observational acceptance is preassigned.
