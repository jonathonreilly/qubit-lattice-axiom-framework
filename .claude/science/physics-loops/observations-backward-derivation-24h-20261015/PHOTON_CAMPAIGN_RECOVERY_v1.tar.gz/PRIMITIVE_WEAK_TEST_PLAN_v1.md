# Direct tests on primitive photon records

Root route selected after refreshing main to
4877e93c76b25926ca286bf438cdf76fc82fede1 and execution instructions to
56c5c0ab64f532c5784e895b2f9aa6894fa334e0. The new open preparation PR9640
has no scalar calibration overlap. This route is part of the existing pack,
not a scheduled or replacement author.

Target: construct an exactly equivalent distributional necessary residual for
the reception-gain inverse using primitive lensing and redshift fields only,
with a proved bound for bounded primitive errors at a fixed candidate history.
The result sought is not a finite-data uniqueness theorem, a regularization
selector or an action derivation. Weak/distributional equations are standard;
the scientific gap is the correctly composed photon/gain map and its explicit
error budget in this inverse.

Use coordinates u=eta+r, r>0, flat du dr dOmega measure, compactly supported
smooth test functions and a=a(u-r). Set T=a^-1 partial_u and
L=a^-1(2partial_u+partial_r), h=a_eta/a^2. The already independently checked
fourteen-column necessary relation supplies candidate coefficient histories
theta_i(u,r), with their action/reception restrictions preserved.

Primitive fields are psi_obs and z_obs=f(Y-2I1), after the exact observer/source
correction stated in the canonical note. Let Q=(r^2/2)partial_r|u,
R=(1/2)partial_r|u r^2 partial_r|u. Then X=R psi_obs,
B=a Q psi_obs and W=z_obs+2partial_u Q psi_obs. The complete registered
interior and recovered angular-sector assumptions remain supplied.

The candidate residual is A_W W+A_X X+A_B B, where

    A_W=LT+(h+theta2)L+theta1 T+(h'+theta3),
    A_X=theta4 L^2T+theta5 LT+theta6 T+theta7 L^2
        +theta8 L+theta9+theta10 T^2,
    A_B=theta11 T^3+theta12 T^2+theta13 T+theta14.

First derive all formal adjoints including the variable-measure divergences
and reverse operator order. Transfer every data derivative to weights and
candidate functions. Then compare direct and primitive-only integrals on an
exact nonzero polynomial witness with nonconstant a, arbitrary polynomial
coefficient functions and test functions whose boundary traces vanish. Test
divergence/order/path-adjoint mutations. Apply the same construction to a
declared original-action fixture if computationally tractable, preserving
all quadrature/approximation errors.

Root proposed adjoints and bounds are frozen separately before computation.
Finite sets of moments may leave many candidate histories; do not choose one
by a hidden smoothness or potential selector. The bound is uniform in allowed
input error for each fixed candidate/weight. Parameter fitting and uniform
bounds over a candidate family need additional analysis. Discrete quadrature
requires its own enclosure; sampled values alone do not certify a continuum
noise bound. No new empirical arrays will be opened for this constructed test.
