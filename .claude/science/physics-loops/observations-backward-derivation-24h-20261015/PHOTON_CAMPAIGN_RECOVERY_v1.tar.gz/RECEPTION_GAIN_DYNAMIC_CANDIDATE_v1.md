# Primitive reception gain and joint dynamics — root candidate v1

Root personal derivation after reading the focused reception-gain proof. This is a new conditional candidate, not a checked identifiability theorem. The predecessor homogeneous matter-time gain model is not applied to detector reception gains. No observed arrays are inputs.

Keep known a,h and the original scalar/conformal-dust class, linearization, complete recovered l>=2 sector, registered repeated cones and the same corrected source/path convention. Let u=eta+r be reception conformal time. Assume one positive common primitive-channel multiplier g(u), independent of radius and direction on a reception cone. This common multiplicative detector contract is a new explicit restricted candidate; arbitrary independent transfer functions, source response and unknown observer/clock corrections remain excluded.

From the recorded lensing potential recover X=gP and I_X=(r^2/2)partial_r|u psi_recorded. The path term B=a I_X is directly specified by this same primitive, with the complete required interior/registered convention. The focused checker derived that nominal corrected redshift W=gY+2g_u I_P. Thus, writing beta=g_u/(a g), V=gZ, L=partial_tau+a^-1 partial_r,

    W=gY+2beta B,
    (L-2beta)V=W-2beta B,
    V'+(C-beta)V=-d X'-(e-d beta)X.

Here C=R/G,d=2/G,e=1+d(h-q) remain homogeneous matter-time background functions. The reception form and path definition imply

    L beta=2beta'+h beta,
    L B=2B'-hB+X,
    L(B')=2B''-(h'+h^2)B+X'+hX.

The covariantized commutator is

    K V=-N, K=C'+hC,
    N=(partial_tau-beta+h+C)(W-2beta B)
        +(L-2beta+h)[d(partial_tau-beta)+e]X.

For K!=0, k=K'/K,

    (L-2beta-k)N+K(W-2beta B)=0.

Expand using the two exact B identities and L beta identity into target O=L(W')+hL(W)+h'W and twelve observed columns

    [W', L(W), W, L^2(X'), L(X'), X', L^2(X), L(X), X, B'', B', B].

Proposed decisive coefficients are theta1=-2beta-k, theta2=C-beta, theta4=d, theta7=e-d beta and theta10=-4beta. If all twelve columns can attain full rank on actual physical fields, this would directly give beta=-theta10/4, C=theta2+beta,d=theta4,e=theta7+d beta, with no gain/background selector. Full coefficient, original-equation and reception-shape residuals would still be necessary. The K=0 relation N=0 is a nontrivial column-null relation and would be excluded by full rank. Actual attainability is OPEN until tested. An impossible rank must be preserved and must not be replaced by arbitrary jets.

## Frozen exact original-equation fixture

Search for tractable forward fixtures found a power background with p=3/2,c^2=5/2,sigma=5/2: aE=t^(3/2),phi=c ln t,A=t^(5/2),rE=(1/2)t^-2,V=5t^-2. It is selected only for symbolic tractability, not as a physical prediction. Matter a=t^4 and conformal eta=-2/sqrt(t). The zero-comoving-eigenvalue four-state original dynamics has exponents m in {0,-3/2,-2,-5/2}; corresponding P is proportional to eta^n with n in {0,3,4,5}. This eigenvalue fact will be checked from the original action, not treated as expected data.

Use genuine regular harmonic spatial profiles r^ell P_ell(cos theta), ell>=2, which have spatial Laplacian zero. Eigenvectors determine scalar and velocity fields. Along each ray P_cone=(u-s)^n s^ell, so the complete observer-origin path integral is exactly polynomial and regular. Build up to48 distinct angular modes with n cycling through {0,3,4,5}, ell=2+i. A finite sum is one linear full-field solution. Test at eta=-2,r=1, so t=1,u=-1 and a=1. Use gain g(u)=(u+11)/10, positive on the tested neighborhood. Compute all path integrals, derivative rows and target exactly from these full fields. No arbitrary path-boundary or time jets are allowed. Test actual rank, gain/background recovery and residuals; record a rank deficit honestly. The field amplitudes can all be multiplied by a sufficiently small common nonzero factor on a compact local domain. No decay at infinity is asserted.

This candidate targets the detector-contract gap identified by independent_reception_gain/DERIVATION.md, SHA 8b7c638863a7c1f5df192149bd4931f27b443941964a29c191a66aa01a91f54d. Root has read that complete derivation, runner and18/0 output. It is not an empirical calibration, a proof of the candidate rank, or a derivation of the canonical action class.
