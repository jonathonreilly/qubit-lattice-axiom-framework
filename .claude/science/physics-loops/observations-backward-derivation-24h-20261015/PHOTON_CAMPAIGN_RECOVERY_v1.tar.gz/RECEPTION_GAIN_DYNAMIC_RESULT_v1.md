# Direct reception-gain reconstruction: checked conditional result

Root personally derived the candidate, implemented its original-action fixture, inspected the focused independent proof and all three independent runner sources, and compared every coefficient and recovered value. The common-gain candidate is mathematically supported within its declared observation contract. It does not establish empirical calibration or select the scalar action.

## Statement and reconstruction

On a smooth registered repeated-cone domain with known positive matter scale factor a, h=a'/a, the supplied canonical conformal scalar plus bare-dust equations, the recovered angular sector l>=2, and one positive common primitive multiplier g(u), u=eta+r, define the recorded fields X, W and B exactly as in RECEPTION_GAIN_DYNAMIC_CANDIDATE_v1.md. The path field B must come from the same registered primitive, including its required interior information. It is not an arbitrary integration constant.

On a common shell and time, suppose the twelve stated observed columns have rank twelve across available angular information. Their unique coefficient vector theta then gives

    beta=-theta10/4, C=theta2+beta,
    d=theta4, e=theta7+d beta,
    G=2/d, R=2C/d, q=h-(e-1)/d.

Rank excludes K=C'+hC=0 because at such a point N=0 would be a nonzero observed column relation with coefficient one on W'. The recovered coefficients must obey all their remaining identities, including k=K'/K, radial homogeneity of C,d,e, and the reception integrability condition Lbeta=2beta'+hbeta. This recovers at most one background/gain-drift history in the regular chart; it does not guarantee existence. A valid history must also satisfy the original Einstein, scalar and dust equations and the background equations. Positivity, q/G>0, qG>0, nonzero coupling and monotone scalar are required for the chosen chart.

The reception condition implies a beta is a function of u alone. Thus d(log g)/du=a beta determines g only up to a positive common constant. Rescaling both primitive gains and inversely rescaling all linear physical perturbations leaves every equation and record invariant. The absolute gain constant is not derived. Likewise the canonical action class, absolute conformal normalization, field origin/orientation, absolute units, off-trajectory extension, clock/distance registration and initial-state origin are not derived by this calculation.

Once q,G,R are known, x^2=qG and b^2=q/G reconstruct the background scalar speed and coupling magnitude. A follows by integrating A'/A=q, and the on-trajectory potential obeys V/(M^2 A^2)=3(h-q)^2-qG/2-R. These are conditional reconstructions within the supplied action; they are not new action-selection principles.

## Evidence and preserved failure

The frozen root fixture is a genuine finite sum of regular solid-harmonic original-equation solutions, with the observer-origin path integral evaluated before any derivatives. Its 48 modal rows have rank twelve; the first twelve form a nonzero rational minor. The exact recovered values at eta=-2,r=1 are beta=1/10,C=1/2,d=2,e=4,q=5/2,G=1,R=1/2. Independent angular harmonics convert the modal rank into attainable angular evaluation rank on one common shell/time. Mixing different shells while holding beta-dependent coefficients fixed would be invalid.

Root v1 recorded 40 passing and 8 unresolved zero-check predicates. All eight residuals consisted of powers such as r*r**ell-r**(ell+1) left uncombined by an unconstrained-symbol simplifier. Version 2 explicitly declares the already-required physical domains r>0, eta<0 and positive integral ell. It changes no equation, field, test or tolerance and passes 48/48. The failed output and exact one-line repair remain preserved. The output SHA256 is 1e434314874173b93e602ba319edd159a27d70e9cdf6dbb0c3ec6684796cd9ef; runner SHA256 e5aa7b637c3d715f5398cbb12deb351f04a37d0908e3adc1d8fdd66715e8e70b.

The independent checker read only the frozen candidate before implementing its own commutator, coefficient expansion and 24-mode original-equation fixture. Its 29 checks pass and recover the same full coefficient vector. See independent_reception_gain/CANDIDATE_DERIVATION.md and CANDIDATE_REPORT.md for source-bound evidence. Counts overlap and are not independent observations. Both implementations use the deliberately tractable same declared background; this is an independent calculation, not an independent empirical test.

## Remaining question

The common primitive multiplier is a restricted measurement assumption. It has not been inferred from instruments. Separate lensing and redshift gains, source-dependent transfer functions, unknown observer/clock corrections, incomplete angular recovery, derivative noise and unknown background registration remain outside this result. The next root block challenges the shared-gain assumption directly.
