# Two primitive reception gains — root pre-code candidate

Purpose: challenge the shared-gain assumption, retaining the supplied scalar/dust equations and known background registration. This is a proposed derivation awaiting exact expansion and original-equation rank checks. No measured arrays are used. The separate gain functions and observation contract are candidate premises, not instrument facts.

Use the actual-event redshift convention E=Oobs+Y-2 I1[P], with correctly registered/calibrated observer and extra terms. Let g(u)>0 multiply the lensing perturbation and f(u)>0 the redshift perturbation, with u=eta+r. They are otherwise independent smooth functions of reception time, common over source radius and angle at fixed u. This does not permit arbitrary direction/source-dependent or nonlinear transfer functions. Define

    X=gP, B=a g I0[P],
    W=fY+2(g-f)I1[P]+2g_u I0[P],
    rho=f/g, beta=g_u/(a g), sigma=f_u/(a f), V=fZ,
    rho'=rho(sigma-beta), Lrho=2rho',
    Lbeta=2beta'+hbeta, Lsigma=2sigma'+hsigma.

All primes are matter-time derivatives at fixed comoving radius. The original background C,d,e depend on matter time only. The registered primitive path still satisfies LB=2B'-hB+X. The physical equations become

    (L-2sigma)V=T,
    V'+(C-sigma)V=-F,
    T=W+s B'+v B,
    s=2(rho-1), v=-sh-2rho beta,
    F=D X'+E X, D=rho d, E=rho(e-d beta).

Unlike the shared-gain case, D and E are not generally homogeneous on coeval slices. Never replace LD by D'. The same covariant commutator gives

    N=(partial_tau+h+C-sigma)T+(L+h-2sigma)F=-K V,
    K=C'+hC,
    (L-2sigma-k)N+KT=0, k=K'/K.

Put A=h+C-sigma, m=LD+(h-2sigma)D, n=LE+(h-2sigma)E,
t=s'+As+v, j=v'+Av. Then

    N=W'+A W+D LX'+mX'+E LX+nX+sB''+tB'+jB.

Commuting the exact path identity twice gives

    LB'=2B''-(h'+h^2)B+X'+hX,
    LB''=2B'''+hB''-(h'+h^2)B'
           -[(h'+h^2)'+h(h'+h^2)]B+X''+2hX'+(h'+h^2)X.

Expand relative to O=L(W')+hLW+h'W and fourteen observed columns

    [W',LW,W,L^2X',LX',X',L^2X,LX,X,X'',B''',B'',B',B].

The proposed extraction uses

    theta1=-2sigma-k, theta2=C-sigma,
    theta4=D, theta7=E, theta10=s, theta11=2s,
    theta12=4s'+(h+2theta2+theta1)s-4rho beta.

If rank fourteen is physically attainable at a common shell/time, recover

    rho=1+theta11/4,
    beta=[4s'+(h+2theta2+theta1)s-theta12]/(4rho),
    sigma=beta+rho'/rho,
    C=theta2+sigma, d=theta4/rho, e=theta7/rho+d beta.

The theta10=theta11/2 redundancy is a coefficient check, not an extra datum. It may motivate a smaller design but does not by itself prove that the fourteen observed columns are dependent. An actual rank obstruction must be recorded. All remaining coefficient identities, reception integrability, radial homogeneity of C,d,e, original equations and positivity are still required. Both gains retain a common constant factor after integrating the drifts; the relative gain is proposed to be identified. No broad identifiability or empirical claim is made yet.

Pre-code exact fixture: reuse the personally checked original action p=3/2,c^2=5/2, a=t^4, eta=-2/sqrt(t), four original modes n=0,3,4,5 with regular solid harmonics ell>=2 and observer-origin polynomial integrals. Select g(u)=(u+11)/10 and f(u)=(u+21)/16, positive near u=-1. At eta=-2,r=1 the truth is rho=5/4,beta=1/10,sigma=1/20,C=1/2,d=2,e=4. This fixed tractable fixture is a constructed mathematics control, not a prediction. Use 48 distinct angular modes and evaluate all channels before differentiation; do not prescribe inverse-equation jets.
