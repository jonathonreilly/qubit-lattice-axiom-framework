"""Post-first-run development controls from complete original forward equations."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sympy as s

AUDIT_TIMEOUT_SEC = 180
checks = {}
details = {}


def check(name, value):
    expressions = list(value) if isinstance(value, s.MatrixBase) else [value]
    reduced = [s.simplify(e) for e in expressions]
    checks[name] = all(e == 0 for e in reduced)
    if not checks[name]:
        details[name] = [str(e) for e in reduced]


def case(kind):
    t, k2 = s.symbols('t k2', positive=True)
    if kind == 'power_p2':
        aE, A, phi = t**2, t**4, s.log(t)
    elif kind == 'power_p3_over_2':
        aE, A, phi = t**s.Rational(3,2), t**s.Rational(5,2), s.log(t)
    elif kind == 'varying_coupling':
        # Newly declared stress case, not independent or pre-v1 validation.
        e = s.Rational(1,5)
        aE, A, phi = t*s.exp(e*(t-1)), t*s.exp(3*e*(t-1)), s.log(t)
    else:
        raise ValueError(kind)
    hE = s.diff(aE,t)/aE
    v = s.diff(phi,t)
    b = s.simplify(s.diff(A,t)/(A*v))
    rE = s.simplify(-2*s.diff(hE,t)-v*v)
    rho = rE/A
    V = s.simplify(3*hE*hE-v*v/2-rE)
    dphi = lambda f: s.diff(f,t)/v
    F = s.simplify(dphi(V)+rho*dphi(A))
    mu = s.simplify(dphi(dphi(V))+rho*dphi(dphi(A)))
    check(kind+'/original_background_scalar',s.diff(v,t)+3*hE*v+F)
    check(kind+'/original_bare_dust',s.diff(rho,t)+3*hE*rho)
    check(kind+'/action_curvature_force_identity',s.diff(F,t)-mu*v+3*hE*b*rE)
    P,u,ud,U = ys = s.symbols('P u ud U')
    Pd = (v*u-rE*U)/2-hE*P
    density = (-2*k2/aE**2*P-6*hE*(Pd+hE*P)-v*ud+v*v*P-F*u)/rE
    udd = -3*hE*ud-(k2/aE**2+mu)*u-b*rE*density+4*v*Pd-2*F*P
    Ud = -P-b*u-b*v*U
    dynamics = s.Matrix([Pd,ud,udd,Ud])
    M = dynamics.jacobian(ys).applyfunc(s.simplify)
    total_t = lambda f:s.diff(f,t)+sum(s.diff(f,y)*dy for y,dy in zip(ys,dynamics))
    check(kind+'/original_density_continuity',total_t(density)-3*Pd-k2/aE**2*U)
    check(kind+'/original_Einstein_pressure',2*total_t(Pd)+8*hE*Pd
          +(4*s.diff(hE,t)+6*hE*hE)*P-v*ud+v*v*P+dphi(V)*u)
    dt = lambda f:s.simplify(s.diff(f,t)/A)
    a = s.simplify(aE*A)
    h,q,x = s.simplify(dt(a)/a),s.simplify(dt(A)/A),s.simplify(v/A)
    G,R = s.simplify(x/b),s.simplify(rE/A**2)
    C,D,E = s.simplify(R/G),s.simplify(-2/G),s.simplify((h-q)*(-2/G)-1)
    K=s.simplify(dt(C)+h*C)
    delta=s.simplify(C-dt(K)/K)
    cr=s.simplify(dt(D)+E+(delta-h)*D)
    pc=s.simplify(C+h+delta)
    zc=s.simplify(dt(C)+dt(h)+delta*(C+h))
    Q=s.simplify(pc-h-(cr-dt(D)+1)/D)
    lin=s.simplify(pc-h-2*Q)
    Crec=s.simplify(-(dt(Q)-h*Q+Q*Q+Q/D-zc+pc*h-h*h)/lin)
    qrec=s.simplify(Q-Crec)
    Grec=-2/D
    Rrec=s.simplify(-2*Crec/D)
    brec2=s.simplify(qrec/Grec)
    check(kind+'/C_recovery',Crec-C)
    check(kind+'/q_recovery',qrec-q)
    check(kind+'/R_recovery',Rrec-R)
    check(kind+'/b_squared_recovery',brec2-b*b)
    check(kind+'/recovered_action_potential',A*A*(3*(h-qrec)**2-x*x/2-Rrec)-V)
    Fbar=-dt(x)-3*h*x+2*qrec*x
    kaprec=s.simplify((dt(Fbar)+2*qrec*Fbar+3*(h-qrec)*b*Rrec)/x)
    check(kind+'/recovered_action_curvature',kaprec-mu/A**2)
    adv=lambda row:((row.diff(t)+row*M)/A).applyfunc(s.simplify)
    prow=[s.Matrix([[1,0,0,0]])]
    for _ in range(3):prow.append(adv(prow[-1]))
    for f,fr in [(1,0),(0,1)]:
        tag=f'{kind}/radial_{f}_{fr}'
        pp=prow[0]*f
        yy=s.Matrix([[-f,-b*f,0,fr/aE]])
        force=D*prow[1]+E*prow[0]
        nn=adv(force)*f+h*force*f+force*fr/a-adv(yy)-(C+h)*yy
        zz=(nn/K).applyfunc(s.simplify)
        jj=(-pp-adv(zz)).applyfunc(s.simplify)
        ww=(jj/b).applyfunc(s.simplify)
        den=(-2*k2/a**2*pp-6*(h-q)*(adv(pp)+(h-q)*pp)
             -x*adv(ww)+x*x*pp-Fbar*ww)/R
        den=den.applyfunc(s.simplify)
        check(tag+'/Z_from_photon_records',zz-s.Matrix([[0,0,0,A*f]]))
        check(tag+'/J_from_reconstructed_Z',jj-s.Matrix([[0,b*f,0,0]]))
        check(tag+'/original_momentum',adv(pp)+(h-q)*pp-(x*ww-R*zz)/2)
        check(tag+'/original_Euler',adv(zz)+pp+b*ww)
        check(tag+'/original_continuity',adv(den)-3*adv(pp)-k2/a**2*zz)
        check(tag+'/original_scalar',adv(adv(ww))+(3*h-2*q)*adv(ww)
              +(k2/a**2+kaprec)*ww+b*R*den-4*x*adv(pp)+2*Fbar*pp)
        check(tag+'/original_Hamiltonian',R*den+2*k2/a**2*pp
              +6*(h-q)*(adv(pp)+(h-q)*pp)+x*adv(ww)-x*x*pp+Fbar*ww)
    # Complete original forward rows, no inverse-generated time jets.
    theta=[D,2*dt(D)+E+(h+delta)*D,cr,
           dt(dt(D))+2*dt(E)+dt(h)*D+h*dt(D)+h*E
           +delta*(dt(D)+E+h*D)-K*D,
           dt(E)+(delta-h)*E,
           dt(dt(E))+dt(h)*E+h*dt(E)+delta*(dt(E)+h*E)-K*E,pc,zc]
    rows=[];target=[]
    for kv in [1,2,3,5]:
        for f,fr in [(1,0),(0,1)]:
            yy=[s.Matrix([[-f,-b*f,0,fr/aE]])]
            for _ in range(2):yy.append(adv(yy[-1]))
            for j in range(4):
                row=[prow[3][j]*f+prow[2][j]*fr/a,prow[2][j]*f,
                     prow[1][j]*fr/a,prow[1][j]*f,prow[0][j]*fr/a,
                     prow[0][j]*f,-yy[1][j],-yy[0][j]]
                rows.append([s.simplify(vv.subs({t:1,k2:kv})) for vv in row])
                target.append(s.simplify(yy[2][j].subs({t:1,k2:kv})))
    design=s.Matrix(rows);rhs=s.Matrix(target)
    th=s.Matrix([s.simplify(e.subs(t,1)) for e in theta])
    check(kind+'/input_output_on_original_forward_rows',design*th-rhs)
    rank=design.rank();checks[kind+'/actual_rank_eight']=bool(rank==8)
    indices=list(design.T.rref()[1]);minor=design[indices,:]
    return {'case':kind,'rank':rank,'rows':len(rows),'minor_rows':indices,
            'minor_determinant':str(minor.det()) if rank==8 else None,
            'b':str(b),'C':str(C),'K':str(K),'linear_denominator':str(lin),
            'coefficients_at_t1':[str(e) for e in th],
            'field_realization':'Assign distinct real spherical harmonics l=2+i,m=0 to rows and sum with a common sufficiently small nonzero amplitude on a compact annulus.'}


if __name__=='__main__':
    cases=[case(k) for k in ['power_p2','power_p3_over_2','varying_coupling']]
    print(json.dumps({'scope':'Post-first-execution exact development checks; not independent tests or observations',
                      'checks':checks,'passed':sum(checks.values()),'failed':sum(not v for v in checks.values()),
                      'details':details,'cases':cases,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      'sympy':s.__version__},indent=2,sort_keys=True))
    raise SystemExit(any(not v for v in checks.values()))
