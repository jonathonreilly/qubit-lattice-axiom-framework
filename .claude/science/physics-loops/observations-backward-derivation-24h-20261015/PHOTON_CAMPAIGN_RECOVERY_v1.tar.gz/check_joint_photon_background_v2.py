"""Root checks of the frozen joint input/background candidate; no observed inputs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import sympy as s

AUDIT_TIMEOUT_SEC = 180
checks = {}
details = {}


def zero(name, expr):
    reduced = s.simplify(s.expand(expr))
    checks[name] = bool(reduced == 0)
    if reduced != 0:
        details[name] = str(reduced)


def coefficients(C, D, E, h, dt):
    K = dt(C) + h * C
    delta = C - dt(K) / K
    return [D,
            2 * dt(D) + E + (h + delta) * D,
            dt(D) + E + (delta - h) * D,
            dt(dt(D)) + 2 * dt(E) + dt(h) * D + h * dt(D) + h * E
            + delta * (dt(D) + E + h * D) - K * D,
            dt(E) + (delta - h) * E,
            dt(dt(E)) + dt(h) * E + h * dt(E)
            + delta * (dt(E) + h * E) - K * E,
            C + h + delta,
            dt(C) + dt(h) + delta * (C + h)]


def generic_checks():
    z, r = s.symbols('tau r', real=True)
    a = s.Function('a')(z)
    h = s.diff(a, z) / a
    C, D, E = [s.Function(n)(z) for n in ['C', 'D', 'E']]
    P, Z, Y = [s.Function(n)(z, r) for n in ['P', 'Z', 'Y']]
    dt = lambda f: s.diff(f, z)
    T = lambda f: dt(f) + s.diff(f, r) / a
    K = dt(C) + h * C
    Fz = dt(Z) + C * Z
    Yz = T(Z)
    zero('commutator_direct_unrestricted_Z', T(Fz) + h * Fz - dt(Yz)
         - (C + h) * Yz - K * Z)
    delta = C - dt(K) / K
    F = D * dt(P) + E * P
    N = T(F) + h * F - dt(Y) - (C + h) * Y
    operator = dt(N) + delta * N - K * F
    theta = coefficients(C, D, E, h, dt)
    columns = [dt(dt(dt(P))) + s.diff(dt(dt(P)), r) / a,
               dt(dt(P)), s.diff(dt(P), r) / a, dt(P),
               s.diff(P, r) / a, P, -dt(Y), -Y]
    zero('all_eight_operator_coefficients', operator
         - (sum(c * t for c, t in zip(columns, theta)) - dt(dt(Y))))
    zero('coefficient_difference_identity', theta[1] - theta[2] - dt(D) - 2 * h * D)
    zero('reconstructed_Z_drift_residual',
         (dt(N / K) + C * N / K - F) - operator / K)
    null = [0, D, D, dt(D) + E + h * D, E, dt(E) + h * E, 1, C + h]
    zero('K_zero_implies_nonzero_column_null_vector',
         sum(c * t for c, t in zip(columns, null)) - N)
    q = s.Function('q')(z)
    G = -2 / D
    R = -2 * C / D
    E = (h - q) * D - 1
    theta = coefficients(C, D, E, h, dt)
    cr, pc, zc = theta[2], theta[6], theta[7]
    Q = s.simplify(pc - h - (cr - dt(D) + 1) / D)
    zero('observable_Q_equals_q_plus_C', Q - q - C)
    poly1 = 3*C*C + (5*h-pc-dt(D)/D-2*Q)*C + zc-dt(h)-pc*h+h*h
    transport = dt(R) + (3*h-2*q)*R
    zero('first_quadratic_exact_dust_residual', poly1 + D*transport/2)
    poly2 = 3*C*C+(4*h-4*Q-dt(D)/D)*C+dt(Q)-dt(h)-h*Q+Q*Q+Q/D
    ray_half = dt(q)-dt(h)-h*q+q*q+(q+C)/D
    zero('second_quadratic_exact_raychaudhuri_plus_dust', poly2-poly1-ray_half)
    lin = pc-h-2*Q
    const = dt(Q)-h*Q+Q*Q+Q/D-zc+pc*h-h*h
    zero('quadratic_difference_linear', poly2-poly1-lin*C-const)
    zero('linear_denominator_identity', lin + dt(K)/K + 2*q)


def physical_case(p, c):
    t = s.symbols('t', positive=True)
    k2 = s.symbols('k2', positive=True)
    p, c = s.Rational(p), s.Rational(c)
    sigma = 3*p-2
    A, aE = t**sigma, t**p
    a = A*aE
    tau = t**(sigma+1)/(sigma+1)
    dt = lambda f: s.simplify(s.diff(f, t)/A)
    H, v = p/t, c/t
    b = sigma/c
    rE = (2*p-c*c)/t**2
    rho = rE/A
    V = (3*p*p-2*p+c*c/2)/t**2
    F = c*(1-3*p)/t**2
    mu = (4*(3*p*p-2*p+c*c/2)+sigma*sigma*(2*p-c*c))/(c*c*t*t)
    tag = f'p={p},c={c}'
    zero(tag+'/Friedmann', 3*H*H-v*v/2-V-rE)
    zero(tag+'/Raychaudhuri', -2*s.diff(H,t)-v*v-rE)
    zero(tag+'/bare_dust_transport', s.diff(rho,t)+3*H*rho)
    zero(tag+'/scalar', s.diff(v,t)+3*H*v+F)
    zero(tag+'/fixed_bare_density_mass', s.diff(F,t)-mu*v+3*H*b*rE)
    P, u, ud, U = state = s.symbols('P u ud U')
    Pd = (v*u-rE*U)/2-H*P
    density = (-2*k2/aE**2*P-6*H*(Pd+H*P)-v*ud+v*v*P-F*u)/rE
    udd = -3*H*ud-(k2/aE**2+mu)*u-b*rE*density+4*v*Pd-2*F*P
    Ud = -P-b*u-b*v*U
    equations = s.Matrix([Pd,ud,udd,Ud])
    M = s.simplify(equations.jacobian(state))
    dtotal = lambda f: s.diff(f,t)+sum(s.diff(f,y)*e for y,e in zip(state,equations))
    zero(tag+'/constraint_implies_original_continuity', dtotal(density)-3*Pd-k2/aE**2*U)
    h, q, x = dt(a)/a, dt(A)/A, v/A
    G, R = x/b, rE/A**2
    C, D, E = s.simplify(R/G), s.simplify(-2/G), s.simplify((h-q)*(-2/G)-1)
    K = s.simplify(dt(C)+h*C)
    def advance(row):
        return (row.diff(t)+row*M).applyfunc(lambda f: s.simplify(f/A))
    prow = [s.Matrix([[1,0,0,0]])]
    for _ in range(3):
        prow.append(advance(prow[-1]))
    rows, rhs, identifiers = [], [], []
    for kv in [1,2,3,5]:
        for f, fr in [(1,0),(0,1)]:
            yrow = [s.Matrix([[-f,-b*f,0,fr/aE]])]
            for _ in range(2):
                yrow.append(advance(yrow[-1]))
            for j in range(4):
                vals = [prow[3][j]*f+prow[2][j]*fr/a,
                        prow[2][j]*f,prow[1][j]*fr/a,prow[1][j]*f,
                        prow[0][j]*fr/a,prow[0][j]*f,-yrow[1][j],-yrow[0][j]]
                rows.append([s.simplify(e.subs({t:1,k2:kv})) for e in vals])
                rhs.append(s.simplify(yrow[2][j].subs({t:1,k2:kv})))
                identifiers.append({'k2':kv,'radial':[f,fr],'state_basis_index':j})
    design, target = s.Matrix(rows),s.Matrix(rhs)
    rank, augmented = design.rank(),design.row_join(target).rank()
    report = {'p':str(p),'c':str(c),'tau_at_t1':str(tau.subs(t,1)),
              'C':str(C),'D':str(D),'E':str(E),'K':str(K),
              'rank':rank,'augmented_rank':augmented,'rows':len(rows),
              'row_identifiers':identifiers,'design':[[str(e) for e in row] for row in rows],
              'target':[str(e) for e in rhs]}
    if K != 0:
        theta = [s.simplify(e) for e in coefficients(C,D,E,h,dt)]
        theta_at = s.Matrix([e.subs(t,1) for e in theta])
        zero(tag+'/original_forward_fields_input_output_residual',
             sum(e*e for e in design*theta_at-target))
        report['expected_coefficients'] = [str(e) for e in theta_at]
        checks[tag+'/frozen_forward_design_rank_eight'] = bool(rank==8)
        cr,pc,zc = theta[2],theta[6],theta[7]
        Q = s.simplify(pc-h-(cr-dt(D)+1)/D)
        lin = s.simplify(pc-h-2*Q)
        Crec = s.simplify(-(dt(Q)-h*Q+Q*Q+Q/D-zc+pc*h-h*h)/lin)
        zero(tag+'/background_C_recovery', Crec-C)
        zero(tag+'/background_q_recovery', Q-Crec-q)
        zero(tag+'/background_b_squared_recovery', (Q-Crec)/(-2/D)-b*b)
        zero(tag+'/background_density_recovery', -2*Crec/D-R)
        Fbar = -dt(x)-3*h*x+2*q*x
        kapparec = (dt(Fbar)+2*q*Fbar+3*(h-q)*b*R)/x
        zero(tag+'/force_identity_curvature', kapparec-mu/A**2)
        report['linear_denominator'] = str(lin)
        if rank == 8:
            indices = list(design.T.rref()[1])
            minor = design[indices,:]
            solved = minor.inv()*target[indices,:]
            zero(tag+'/coefficient_recovery_from_original_fields',sum(e*e for e in solved-theta_at))
            report['minor_rows'] = indices
            report['minor_determinant'] = str(minor.det())
            report['recovered_coefficients'] = [str(e) for e in solved]
    else:
        checks[tag+'/K_zero_rank_is_not_eight'] = bool(rank<8)
        null = s.Matrix([0,D,D,dt(D)+E+h*D,E,dt(E)+h*E,1,C+h]).subs(t,1)
        zero(tag+'/K_zero_actual_design_null',sum(e*e for e in design*null))
        report['nonzero_null_vector'] = [str(e) for e in null]
    return report


if __name__ == '__main__':
    generic_checks()
    cases = [physical_case(2,1),physical_case(s.Rational(3,2),1),physical_case(1,1)]
    here = Path(__file__).parent
    output = {'scope':'Exact conditional mathematics and predeclared original-equation forward jets; no observations',
              'checks':checks,'passed':sum(checks.values()),'failed':sum(not x for x in checks.values()),
              'details':details,'physical_cases':cases,'sympy':s.__version__,
              'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'precontrol_derivation_sha256':hashlib.sha256((here/'JOINT_PHOTON_BACKGROUND_DERIVATION_v2.md').read_bytes()).hexdigest()}
    print(json.dumps(output,indent=2,sort_keys=True))
    raise SystemExit(bool(output['failed']))
