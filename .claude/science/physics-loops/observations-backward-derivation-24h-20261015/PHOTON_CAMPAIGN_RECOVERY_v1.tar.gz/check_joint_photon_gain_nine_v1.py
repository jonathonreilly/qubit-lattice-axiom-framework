"""Root integration of independent nine-column inverse and unknown gains."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import sympy as s

checks={};details={}

def zero(name,expr):
    arr=list(expr) if isinstance(expr,s.MatrixBase) else [expr]
    values=[s.factor(s.cancel(s.expand(v))) for v in arr]
    checks[name]=all(v==0 for v in values)
    if not checks[name]:details[name]=[str(v) for v in values]

def theta(C,D,E,h,mu,k,dt):
    j=h-k-2*mu;z=dt(h)-dt(mu)-(k+mu)*(h-mu)
    return [-k-mu,C-mu,2*dt(C)+h*C-dt(mu)-(k+mu)*(h+C-mu),
            D,2*dt(D)+j*D,dt(dt(D))+j*dt(D)+z*D,
            E,2*dt(E)+j*E,dt(dt(E))+j*dt(E)+z*E]

def inverse(th,h,dt):
    D,E=th[3],th[6]
    mu=s.simplify(h+th[0]-(th[4]-2*dt(D))/D)
    C=s.simplify(th[1]+mu)
    T=s.simplify(h-E/D-mu)
    A=s.simplify(dt(C)/C+3*h-2*T-2*dt(D)/D)
    Q=s.simplify(dt(C)/C+3*h-T-dt(D)/D)
    B=s.simplify(A-h+3*Q+C)
    F=s.simplify(dt(Q)-dt(h)-h*Q+Q*Q)
    H1=s.simplify(dt(B)-A*B+B*B/2-4*F)
    H0=s.simplify(dt(F)+(B/2-2*A)*F)
    return {'mu':mu,'C':C,'A':A,'Q':Q,'B':B,'F':F,'H1':H1,'H0':H0}

def generic():
    t,r=s.symbols('tau r',real=True);a=s.Function('a')(t);h=s.diff(a,t)/a
    dt=lambda f:s.diff(f,t);L=lambda f:dt(f)+s.diff(f,r)/a
    C,D,E,mu,k=[s.Function(n)(t) for n in ['C','D','E','mu','k']]
    X,W,V=[s.Function(n)(t,r) for n in ['X','W','V']]
    K=dt(C)+h*C;U=D*dt(X)+E*X
    N=dt(W)+(h+C-mu)*W+L(U)+(h-mu)*U
    cols=[dt(W),L(W),W,L(L(dt(X))),L(dt(X)),dt(X),L(L(X)),L(X),X]
    O=L(dt(W))+h*L(W)+dt(h)*W
    th=theta(C,D,E,h,mu,k,dt)
    zero('full_gain_nine_column_expansion',L(N)-(mu+k)*N+K*W-O-sum(v*q for v,q in zip(cols,th)))
    # Check commutator without using the expanded coefficient formula.
    Uv=-dt(V)-(C-mu)*V;Wv=L(V)-mu*V
    Nv=dt(Wv)+(h+C-mu)*Wv+L(Uv)+(h-mu)*Uv
    zero('gain_commutator_from_arbitrary_V',Nv+K*V)
    zero('gain_drift_extraction',h+th[0]-(th[4]-2*dt(D))/D-mu)
    zero('C_extraction',th[1]+mu-C)
    null=[1,0,h+C-mu,0,D,dt(D)+(h-mu)*D,0,E,dt(E)+(h-mu)*E]
    zero('K_zero_nontrivial_null_relation',sum(v*q for v,q in zip(cols,null))-N)
    # Polynomial derivative closure, with no input from the coefficient code.
    uu=s.symbols('u');AA,BB,FF=[s.Function(n)(t) for n in ['A','B','F']]
    poly=4*uu*uu+BB*uu+FF
    derivative=dt(poly)+s.diff(poly,uu)*uu*(AA+2*uu)
    rem=s.rem(derivative,poly,uu)
    expected=(dt(BB)-AA*BB+BB*BB/2-4*FF)*uu+dt(FF)+(BB/2-2*AA)*FF
    zero('quadratic_derivative_exact_remainder',rem-expected)
    # Root's suspected trace redundancy after the background constraints.
    QQ=s.Function('Q')(t);DD=s.Function('Dtrace')(t)
    X0,X1,X2,Z1,Z2=s.symbols('X Xprime Xsecond Zprime Zsecond')
    ud=uu*(AA+2*uu)
    udd=s.diff(ud,t)+s.diff(ud,uu)*ud
    q=QQ+uu;qd=dt(QQ)+ud;G=-2*uu;Gd=-2*ud
    rr=uu*DD;rd=ud*DD+uu*dt(DD);rdd=udd*DD+2*ud*dt(DD)+uu*dt(dt(DD))
    P=rr*X0;Pd=rr*X1+rd*X0;Pdd=rr*X2+2*rd*X1+rdd*X0
    Ft=Gd+3*(h-q)*G-2*dt(h)+2*qd-2*h*q+2*q*q
    trace=2*Pdd+(8*h-6*q+G)*Pd+(4*dt(h)+6*h*h-4*qd-8*h*q+2*q*q+q*G+Ft)*P+G*Z2+Ft*Z1
    bcoef=AA-h+3*QQ+C;fcoef=dt(QQ)-dt(h)-h*QQ+QQ*QQ
    quotient=s.cancel(trace/uu)
    # Multiplying by u avoids a rational remainder ambiguity.
    reduced=s.cancel(s.rem(s.expand(uu*quotient),4*uu*uu+bcoef*uu+fcoef,uu)/uu)
    # The 1/u contribution is replaced using the quadratic once more.
    reduced=s.cancel(reduced.subs(1/uu,(-4*uu-bcoef)/fcoef))
    zero('pressure_trace_not_an_extra_u_selector',s.diff(reduced,uu))

def physical(power,gain_kind):
    power=s.Rational(power);t,r,k2,ell=s.symbols('t r k2 ell',positive=True)
    B,Br=s.symbols('B Br');sigma=3*power-2
    A=t**sigma;aE=t**power;a=A*aE;H=power/t;v=1/t;b=sigma
    rr=(2*power-1)/t**2;F=(1-3*power)/t**2
    mass=(4*(3*power*power-2*power+s.Rational(1,2))+sigma*sigma*(2*power-1))/t**2
    if gain_kind=='variable':g=t**s.Rational(2,3)*s.exp((t-1)/7);f=t**s.Rational(-1,4)*s.exp((t-1)/5)
    else:g,f=s.Rational(3,2),s.Rational(7,4)
    dt=lambda z:s.simplify(s.diff(z,t)/A)
    h=s.simplify(dt(a)/a);q=s.simplify(dt(A)/A);x=v/A;G=x/b;R=rr/A**2
    C,d,e=map(s.simplify,[R/G,2/G,1+(2/G)*(h-q)])
    mu=dt(f)/f;lm=dt(g)/g;ratio=f/g
    D=s.simplify(ratio*d);E=s.simplify(ratio*(e-lm*d));K=s.simplify(dt(C)+h*C);k=dt(K)/K
    th=[s.simplify(z) for z in theta(C,D,E,h,mu,k,dt)]
    inv=inverse(th,h,dt);tag=f'p={power}/{gain_kind}'
    zero(tag+'/mu',inv['mu']-mu);zero(tag+'/C',inv['C']-C)
    urecovered=s.simplify(-inv['H0']/inv['H1']) if inv['H1']!=0 else None
    checks[tag+'/unique_gain_chart']=urecovered is not None
    u=-G/2
    zero(tag+'/quadratic',4*u*u+inv['B']*u+inv['F'])
    zero(tag+'/Riccati',dt(u)-u*(inv['A']+2*u))
    if urecovered is not None:
        zero(tag+'/u_without_supplied_background',urecovered-u)
        zero(tag+'/q_without_supplied_background',inv['Q']+urecovered-q)
        zero(tag+'/R_without_supplied_background',-2*inv['C']*urecovered-R)
        zero(tag+'/relative_gain',-urecovered*D-ratio)
        zero(tag+'/lensing_gain_drift',inv['mu']-dt(urecovered)/urecovered-dt(D)/D-lm)
    # Independent row-vector realization from the original equations.
    P,w,wd,U=ys=s.symbols('P w wd U')
    Pd=(v*w-rr*U)/2-H*P
    den=(-2*k2/aE**2*P-6*H*(Pd+H*P)-v*wd+v*v*P-F*w)/rr
    wdd=-3*H*wd-(k2/aE**2+mass)*w-b*rr*den+4*v*Pd-2*F*P
    Ud=-P-b*w-b*v*U;M=s.Matrix([Pd,wd,wdd,Ud]).jacobian(ys)
    adv=lambda row:((row.diff(t)+row*M)/A).applyfunc(s.simplify)
    dr=lambda row:(row.diff(r)+row.diff(B)*Br+row.diff(Br)*(-2*Br/r-(k2-ell*(ell+1)/r**2)*B)).applyfunc(s.simplify)
    L=lambda row:(adv(row)+dr(row)/a).applyfunc(s.simplify)
    xx=s.Matrix([[g*B,0,0,0]]);yy=s.Matrix([[-f*B,-f*b*B,0,f*Br/aE]])
    xd=adv(xx);yd=adv(yy);Lx=L(xx);Lxd=L(xd);Ly=L(yy)
    cols=[yd,Ly,yy,L(Lxd),Lxd,xd,L(Lx),Lx,xx]
    target=-(L(yd)+h*Ly+dt(h)*yy)
    # Full symbolic residual tests before selecting numerical rows.
    zero(tag+'/original_fields_nine_column_identity',sum((v*c for v,c in zip(th,cols)),s.zeros(1,4))-target)
    UU=D*xd+E*xx
    NN=yd+(h+C-mu)*yy+L(UU)+(h-mu)*UU
    measuredV=(-NN/K).applyfunc(s.simplify)
    zero(tag+'/hidden_velocity_recovery',measuredV-s.Matrix([[0,0,0,f*A*B]]))
    actualP=xx/g;actualZ=measuredV/f;actualJ=-actualP-adv(actualZ)
    zero(tag+'/slip_recovery',actualJ-s.Matrix([[0,b*B,0,0]]))
    zero(tag+'/physical_momentum',adv(actualZ)+C*actualZ+d*adv(actualP)+e*actualP)
    zero(tag+'/physical_redshift',L(actualZ)-yy/f)
    rows=[];rhs=[];ids=[]
    for kval in [1,2,3,5]:
        for radial in [(1,0),(0,1)]:
            for j in range(4):
                i=len(rows);sub={t:1,r:1,k2:kval,ell:2+i,B:radial[0],Br:radial[1]}
                rows.append([s.simplify(col[j].subs(sub)) for col in cols])
                rhs.append(s.simplify(target[j].subs(sub)))
                ids.append({'ell':2+i,'k2':kval,'radial':list(radial),'state_basis':j})
    matrix=s.Matrix(rows);targetnum=s.Matrix(rhs);rank=matrix.rank()
    checks[tag+'/physical_rank_nine']=bool(rank==9)
    indices=list(matrix.T.rref()[1]);minor=matrix[indices,:]
    th0=s.Matrix([s.simplify(z.subs(t,1)) for z in th])
    if rank==9:zero(tag+'/coefficient_recovery',minor.inv()*targetnum[indices,:]-th0)
    return {'power':str(power),'gain_kind':gain_kind,'rank':rank,
            'minor_determinant':str(minor.det()) if rank==9 else None,
            'selected_rows':indices,'selected_mode_ids':[ids[i] for i in indices],
            'theta_at_t1':[str(z) for z in th0],
            'extracted':{n:str(z) for n,z in inv.items()},'u':str(urecovered),
            'scope':'Original-equation local analytic modes; synthetic development after independent nine-column exposure'}

if __name__=='__main__':
    generic()
    cases=[physical(p,g) for p in [2,s.Rational(3,2)] for g in ['variable','constant']]
    here=Path(__file__).parent
    out={'checks':checks,'passed':sum(checks.values()),'failed':sum(not z for z in checks.values()),
         'details':details,'cases':cases,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'derivation_sha256':hashlib.sha256((here/'JOINT_PHOTON_GAIN_NINE_COLUMN_DERIVATION_v1.md').read_bytes()).hexdigest(),
         'sympy':s.__version__,'scope':'Root integration development; no empirical or independent validation'}
    print(json.dumps(out,indent=2,sort_keys=True));raise SystemExit(bool(out['failed']))
