"""Root development controls of unknown-gain joint inversion; no observed data."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sympy as s
from check_joint_photon_background_v2 import coefficients

checks = {}
details = {}


def zero(name, value):
    terms = list(value) if isinstance(value, s.MatrixBase) else [value]
    reduced = [s.simplify(s.expand(e)) for e in terms]
    checks[name] = all(e == 0 for e in reduced)
    if not checks[name]:
        details[name] = [str(e) for e in reduced]


def gain_transform(th, g, f, dt):
    D, c2, cr, c1, cr0, c0, p, z = th
    lm, mu, ratio = dt(g)/g, dt(f)/f, f/g
    return [ratio*D, ratio*(c2-3*lm*D), ratio*(cr-2*lm*D),
            ratio*(c1-2*lm*c2+3*(lm*lm-dt(lm))*D),
            ratio*(cr0-lm*cr+(lm*lm-dt(lm))*D),
            ratio*(c0-lm*c1+(lm*lm-dt(lm))*c2
                   +(-lm**3+3*lm*dt(lm)-dt(dt(lm)))*D),
            p-2*mu, z-p*mu+mu*mu-dt(mu)]


def operator(P, Y, th, dt, dr, a):
    cols = [dt(dt(dt(P)))+dr(dt(dt(P)))/a, dt(dt(P)),
            dr(dt(P))/a, dt(P), dr(P)/a, P, -dt(Y), -Y]
    return sum(x*y for x,y in zip(cols,th))-dt(dt(Y))


def kinetic_C(th, h, dt):
    D, _, cr, _, cr0, _, p, z = th
    alpha = (cr-dt(D))/D-p+2*h
    Hc = dt(D)-D*alpha
    Bc = dt(D)*alpha+D*dt(alpha)+D*(z-dt(h)-p*h+h*h+(p-2*h)*alpha)
    return s.simplify((cr0-Bc)/Hc), s.simplify(Hc)


def generic():
    t,r=s.symbols('tau r', real=True)
    a=s.Function('a')(t); h=s.diff(a,t)/a
    dt=lambda v:s.diff(v,t);dr=lambda v:s.diff(v,r)
    C,D,E,g,f=[s.Function(n)(t) for n in ['C','D','E','g','f']]
    X,W=s.Function('X')(t,r),s.Function('W')(t,r)
    # Independent direct conjugation of the complete differential operator.
    ds=s.symbols('D c2 cr c1 cr0 c0 p z')
    tild=gain_transform(ds,g,f,dt)
    zero('full_generic_conjugation',operator(X,W,tild,dt,dr,a)
         -f*operator(X/g,W/f,ds,dt,dr,a))
    th=coefficients(C,D,E,h,dt)
    tild=gain_transform(th,g,f,dt)
    mu_rec=2*h+(dt(tild[0])-tild[1]+tild[2])/tild[0]
    zero('redshift_gain_drift',mu_rec-dt(f)/f)
    C_rec,Hc=kinetic_C(th,h,dt)
    zero('kinematic_background_C',C_rec-C)
    zero('kinematic_C_denominator',Hc-(C*D-E+dt(D)))
    # Once the redshift channel is corrected, the two-transport system still
    # holds with a new measured D,E; no physical background is inserted here.
    corrected=gain_transform(th,g,s.S.One,dt)
    same=coefficients(C,D/g,(E-D*dt(g)/g)/g,h,dt)
    zero('corrected_transport_covariance',s.Matrix(corrected)-s.Matrix(same))
    C_rec,Hc=kinetic_C(corrected,h,dt)
    zero('kinematic_C_with_unknown_lensing_gain',C_rec-C)
    S,u=s.Function('S')(t),s.Function('u')(t)
    Q0=dt(C)/C-dt(D)/D+3*h-S+C
    A0=dt(C)/C-2*dt(D)/D+3*h-2*S+2*C
    q=Q0+u;R=-2*C*u
    ric=dt(u)-u*(A0+2*u)
    zero('dust_equals_gain_Riccati',dt(R)+(3*h-2*q)*R+2*C*ric)
    ray=dt(q)-dt(h)-h*q+q*q+(q+C)*u
    poly=4*u*u+(A0-h+3*Q0+C)*u+dt(Q0)-dt(h)-h*Q0+Q0*Q0
    zero('Raychaudhuri_quadratic_modulo_dust',ray-poly-ric)
    relation=q-(S-C+dt(u)/u+dt(D)/D-u)
    zero('momentum_gain_relation_modulo_dust',relation+ric/u)


def physical(p, gain_kind):
    p=s.Rational(p);t,k2=s.symbols('t k2', positive=True)
    sigma=3*p-2;A=t**sigma;aE=t**p;a=A*aE
    dt=lambda e:s.simplify(s.diff(e,t)/A)
    h=dt(a)/a;q=dt(A)/A;x=1/(t*A);b=sigma
    rE=(2*p-1)/t**2;R=rE/A**2;G=x/b
    C,D,E=map(s.simplify,[R/G,-2/G,(h-q)*(-2/G)-1])
    th=coefficients(C,D,E,h,dt)
    if gain_kind=='variable':
        g=t**s.Rational(2,3)*s.exp((t-1)/7)
        f=t**s.Rational(-1,4)*s.exp((t-1)/5)
    else:g,f=s.Rational(3,2),s.Rational(7,4)
    tag=f'p={p}/{gain_kind}'
    measured=[s.simplify(e) for e in gain_transform(th,g,f,dt)]
    zero(tag+'/redshift_drift_recovery',2*h+(dt(measured[0])-measured[1]
         +measured[2])/measured[0]-dt(f)/f)
    corrected=[s.simplify(e) for e in gain_transform(th,g,s.S.One,dt)]
    Crec,Hc=kinetic_C(corrected,h,dt)
    zero(tag+'/C_recovery',Crec-C)
    Dm=corrected[0];cr,pc=corrected[2],corrected[6]
    S=s.simplify(pc-h-(cr-dt(Dm))/Dm)
    Q0=s.simplify(dt(Crec)/Crec-dt(Dm)/Dm+3*h-S+Crec)
    A0=s.simplify(dt(Crec)/Crec-2*dt(Dm)/Dm+3*h-2*S+2*Crec)
    u=s.simplify(1/(g*Dm))
    zero(tag+'/gain_Riccati',dt(u)-u*(A0+2*u))
    zero(tag+'/q_recovery',Q0+u-q)
    zero(tag+'/G_recovery',-2*u-G)
    zero(tag+'/R_recovery',-2*Crec*u-R)
    poly=s.simplify(4*u*u+(A0-h+3*Q0+Crec)*u+dt(Q0)-dt(h)-h*Q0+Q0*Q0)
    zero(tag+'/gain_quadratic',poly)
    # Build observed jets only from original Einstein-time forward equations.
    P,w,wd,U=ys=s.symbols('P w wd U');H=p/t;v=1/t
    F=(1-3*p)/t**2
    mass=(4*(3*p*p-2*p+s.Rational(1,2))+sigma*sigma*(2*p-1))/t**2
    Pd=(v*w-rE*U)/2-H*P
    den=(-2*k2/aE**2*P-6*H*(Pd+H*P)-v*wd+v*v*P-F*w)/rE
    wdd=-3*H*wd-(k2/aE**2+mass)*w-b*rE*den+4*v*Pd-2*F*P
    Ud=-P-b*w-b*v*U
    M=s.Matrix([Pd,wd,wdd,Ud]).jacobian(ys)
    adv=lambda row:((row.diff(t)+row*M)/A).applyfunc(s.simplify)
    xp=[s.Matrix([[g,0,0,0]])]
    for _ in range(3):xp.append(adv(xp[-1]))
    rows=[];rhs=[]
    for kval in [1,2,3,5]:
        for v0,vr in [(1,0),(0,1)]:
            yw=[s.Matrix([[-f*v0,-f*b*v0,0,f*vr/aE]])]
            for _ in range(2):yw.append(adv(yw[-1]))
            for j in range(4):
                vals=[xp[3][j]*v0+xp[2][j]*vr/a,xp[2][j]*v0,
                      xp[1][j]*vr/a,xp[1][j]*v0,xp[0][j]*vr/a,
                      xp[0][j]*v0,-yw[1][j],-yw[0][j]]
                rows.append([s.simplify(e.subs({t:1,k2:kval})) for e in vals])
                rhs.append(s.simplify(yw[2][j].subs({t:1,k2:kval})))
    design=s.Matrix(rows);target=s.Matrix(rhs)
    expected=s.Matrix([s.simplify(e.subs(t,1)) for e in measured])
    zero(tag+'/original_forward_field_relation',design*expected-target)
    rank=design.rank();checks[tag+'/rank_eight']=bool(rank==8)
    indices=list(design.T.rref()[1]);minor=design[indices,:]
    if rank==8:zero(tag+'/coefficients_from_forward_records',minor.inv()*target[indices,:]-expected)
    # Both formal roots are listed, not selected. Test the alternate root against
    # the Riccati equation throughout the interval before any physical claim.
    other=s.simplify(-(A0-h+3*Q0+Crec)/4-u)
    other_res=s.simplify(dt(other)-other*(A0+2*other))
    return {'p':str(p),'gain_kind':gain_kind,'g':str(g),'f':str(f),
            'rank':rank,'minor_determinant':str(minor.det()) if rank==8 else None,
            'mu':str(s.simplify(dt(f)/f)),'C':str(Crec),'Hc':str(Hc),
            'u':str(u),'alternate_quadratic_root':str(other),
            'alternate_dust_residual':str(other_res),
            'measured_coefficients_at_t1':[str(e) for e in expected]}


if __name__=='__main__':
    generic()
    cases=[physical(p,g) for p in [2,s.Rational(3,2)] for g in ['variable','constant']]
    here=Path(__file__).parent
    result={'scope':'Synthetic exact mathematical development; not observed or independent test data',
            'checks':checks,'passed':sum(checks.values()),'failed':sum(not v for v in checks.values()),
            'details':details,'cases':cases,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'premise_source_sha256':hashlib.sha256((here/'check_joint_photon_background_v2.py').read_bytes()).hexdigest(),
            'derivation_sha256':hashlib.sha256((here/'JOINT_PHOTON_GAIN_DERIVATION_v1.md').read_bytes()).hexdigest(),
            'sympy':s.__version__}
    print(json.dumps(result,indent=2,sort_keys=True))
    raise SystemExit(bool(result['failed']))
