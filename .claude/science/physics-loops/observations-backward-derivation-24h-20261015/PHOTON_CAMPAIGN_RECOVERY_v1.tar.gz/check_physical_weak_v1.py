"""Fixed original-action primitive weak discriminator, no observed inputs."""
AUDIT_TIMEOUT_SEC=120
from pathlib import Path
import importlib.util,json,hashlib,time
import sympy as S
start=time.monotonic()
source=Path("/Users/jonBridger/.codex/worktrees/scalar-photon-calibration-20261016/New Axioms Lets Go/scripts/scalar_photon_reception_core.py")
spec=importlib.util.spec_from_file_location("core",source);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
u,r=S.symbols("u r",real=True);eta=u-r
a=256/eta**8
clean=lambda z:S.factor(S.cancel(z))
T=lambda z:clean(S.diff(z,u)/a)
L=lambda z:clean((2*S.diff(z,u)+S.diff(z,r))/a)
h=T(a)/a;C=-eta**7/256;d=-256/eta**7;e=S.Integer(4)
K=clean(T(C)+h*C);k=clean(T(K)/K)
Q=lambda z:clean(r*r*S.diff(z,r)/2)
Qd=lambda z:clean(-S.diff(r*r*z,r)/2)
R=lambda z:clean(S.diff(r*r*S.diff(z,r),r)/2)
Td=lambda z:clean(-T(z)+h*z)
Ld=lambda z:clean(-L(z)+h*z)
g=(u+11)/10;beta=clean(T(g)/g)
P=r*r;Z=128*eta**-7*r*r;J=5*P/2
Y=clean(-P-J+S.diff(Z,r)/a)
psi=g*r*r/3;z=g*Y
X=R(psi);B=clean(a*Q(psi));W=clean(z+2*S.diff(Q(psi),u))
lam=clean(((u+S.Rational(3,2))*(-S.Rational(1,2)-u)*(r-S.Rational(1,2))*(S.Rational(3,2)-r))**6)
checks={}
def zero(n,z): checks[n]=clean(z)==0
def coeff(b):return [clean(v) for v in core.coefficients(C,d,e,h,b,k,K,T,L)]
def strong(th):
    cols=[T(W),L(W),W,L(L(T(X))),L(T(X)),T(X),L(L(X)),L(X),X,T(T(B)),T(B),B]
    return clean(L(T(W))+h*L(W)+T(h)*W+sum(v*c for v,c in zip(th,cols)))
zero("original_Euler",T(Z)+P+J)
zero("original_momentum",T(Z)+C*Z+d*T(P)+e*P)
zero("primitive_lensing",X-g*P)
zero("primitive_path",B-a*g*r**3/3)
true=coeff(beta);wrong=coeff(S.Integer(0))
zero("true_calibration_strong_residual",strong(true))
res=strong(wrong);checks["wrong_calibration_nonzero"]=res!=0
# Independent full adjoint construction for the common-gain specialization.
th=wrong
HW=clean(Td(Ld(lam))+Ld((h+th[1])*lam)+Td(th[0]*lam)+(T(h)+th[2])*lam)
HX=clean(Td(Ld(Ld(th[3]*lam)))+Td(Ld(th[4]*lam))+Td(th[5]*lam)+Ld(Ld(th[6]*lam))+Ld(th[7]*lam)+th[8]*lam)
HB=clean(Td(Td(th[9]*lam))+Td(th[10]*lam)+th[11]*lam)
HP=clean(R(HX)+Qd(a*HB-2*S.diff(HW,u)))
x,y=S.symbols("x y",real=True)
def poly(v):
    return S.Poly(S.cancel(v.subs({u:x-S.Rational(3,2),r:y+S.Rational(1,2)})),x,y,domain=S.QQ)
def integral(v):
    p=poly(v)
    return sum(c/S.Integer((i+1)*(j+1)) for (i,j),c in p.terms())
moment=integral(lam*res);pair=integral(HW*z+HP*psi)
checks["nonzero_weak_discriminator"]=moment!=0
checks["strong_primitive_pairing"]=moment==pair
# Exact L2 bound avoids the coefficientwise monomial L1 cancellation blowup.
normz=integral(HW*HW);normp=integral(HP*HP)
checks["positive_kernel_norms"]=normz>0 and normp>0
# On full sphere data and weight carry P2. For generic bounded angular errors,
# Cauchy yields |delta M| <= sqrt(4pi)*eps * sqrt((4pi/5)*(normz+normp))*sqrt(2).
# Moment is (4pi/5)*moment. Thus eps < |moment|/sqrt(10*(normz+normp)).
eps2=clean(moment*moment/(10*(normz+normp)))
checks["positive_pointwise_error_radius"]=eps2>0
out={"scope":"One fixed wrong common-gain history rejected by one exact weak moment on original-action local photon records. No finite-family uniqueness or empirical validation.",
"source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
"dependency_sha256":{str(source):hashlib.sha256(source.read_bytes()).hexdigest()},
"passed":sum(checks.values()),"failed":sum(not q for q in checks.values()),"checks":checks,
"strong_wrong":str(res),"moment_square_domain":str(moment),"primitive_pair_square_domain":str(pair),
"moment_full_sphere":str(moment*4*S.pi/5),"kernel_L2_squared":{"redshift":str(normz),"lensing":str(normp)},
"max_equal_pointwise_error_squared":str(eps2),"max_equal_pointwise_error":str(S.N(S.sqrt(eps2),20)),
"signal_scope":"P2 angular mode, unit coefficient; scale all signals and error radius together to enter the linear perturbative domain",
"window":{"u":["-3/2","-1/2"],"r":["1/2","3/2"]},"elapsed":time.monotonic()-start}
print(json.dumps(out,indent=2));raise SystemExit(out["failed"]!=0)

