"""Fixed physical weak test: polynomial operator arithmetic after timeout."""
AUDIT_TIMEOUT_SEC=120
from pathlib import Path
import json,hashlib,sys,time
import sympy as S
started=time.monotonic()
eta,r=S.symbols("eta r",real=True);u=eta+r
a=256/eta**8;h=-eta**7/32;C=-eta**7/256;d=-256/eta**7;e=S.Integer(4)
expand=S.expand
T=lambda z:expand(eta**8*S.diff(z,eta)/256)
L=lambda z:expand(eta**8*(S.diff(z,eta)+S.diff(z,r))/256)
D=lambda z:expand(S.diff(z,r)-S.diff(z,eta))
Q=lambda z:expand(r*r*D(z)/2)
Qd=lambda z:expand(-D(r*r*z)/2)
R=lambda z:expand(D(r*r*D(z))/2)
Td=lambda z:expand(-T(z)+h*z)
Ld=lambda z:expand(-L(z)+h*z)
K=expand(T(C)+h*C);k=14*eta**7/256
g=(u+11)/10;P=r*r;Z=128*eta**-7*r*r;J=S.Rational(5,2)*P
Y=expand(-P-J+S.diff(Z,r)/a)
psi=expand(g*r*r/3);z=expand(g*Y)
X=R(psi);B=expand(a*Q(psi));W=expand(z+2*S.diff(Q(psi),eta))
lam=expand(((u+S.Rational(3,2))*(-S.Rational(1,2)-u)*(r-S.Rational(1,2))*(S.Rational(3,2)-r))**6)
checks={}
def zero(n,z):checks[n]=S.cancel(z)==0
def phase(n):print(n,round(time.monotonic()-started,3),file=sys.stderr,flush=True)
zero("original_Euler",T(Z)+P+J);zero("original_momentum",T(Z)+C*Z+d*T(P)+e*P)
zero("primitive_lensing",X-g*P);zero("primitive_path",B-a*g*r**3/3)
# Exact gained first-order equations yield the true candidate necessary residual.
beta=S.diff(g,eta)/a/g;V=g*Z
F=S.cancel(d*(T(X)-beta*X)+e*X)
Tr=S.cancel(W-2*beta*B)
zero("true_temporal",T(V)+(C-beta)*V+F)
zero("true_characteristic",L(V)-2*beta*V-Tr)
N=S.cancel(T(Tr)+(h+C-beta)*Tr+L(F)+(h-2*beta)*F)
zero("true_commutator",N+K*V)
zero("true_calibration_strong_residual",L(N)-(2*beta+k)*N+K*Tr)
phase("true identities")
# Wrong constant common gain, on the same background. Derive its expansion locally.
A=h+C;m=expand(T(d)+h*d);n=expand(L(e)+h*e)
th=[-k,C,expand(L(A)-k*A+K-T(h)),d,expand(T(d)+m-k*d),expand(L(m)-k*m),
e,expand(L(e)+n-k*e),expand(L(n)-k*n),S.Integer(0),S.Integer(0),S.Integer(0)]
cols=[T(W),L(W),W,L(L(T(X))),L(T(X)),T(X),L(L(X)),L(X),X,T(T(B)),T(B),B]
res=expand(L(T(W))+h*L(W)+T(h)*W+sum(v*c for v,c in zip(th,cols)))
checks["wrong_calibration_nonzero"]=res!=0
HW=expand(Td(Ld(lam))+Ld((h+th[1])*lam)+Td(th[0]*lam)+(T(h)+th[2])*lam)
HX=expand(Td(Ld(Ld(th[3]*lam)))+Td(Ld(th[4]*lam))+Td(th[5]*lam)+Ld(Ld(th[6]*lam))+Ld(th[7]*lam)+th[8]*lam)
HP=expand(R(HX)-2*Qd(S.diff(HW,eta)))
phase("adjoint polynomials")
x,y=S.symbols("x y",real=True)
def poly(v):return S.Poly(v.subs({eta:x-y-2,r:y+S.Rational(1,2)}, simultaneous=True).expand(),x,y,domain=S.QQ)
def integpoly(p):return sum(c/S.Integer((i+1)*(j+1)) for (i,j),c in p.terms())
def integral(v):return integpoly(poly(v))
moment=integral(lam*res);pair=integral(HW*z+HP*psi)
checks["nonzero_weak_discriminator"]=moment!=0;checks["strong_primitive_pairing"]=moment==pair
phase("pairing")
pw=poly(HW);pp=poly(HP)
normz=integpoly(pw*pw);normp=integpoly(pp*pp)
checks["positive_kernel_norms"]=normz>0 and normp>0
eps2=S.factor(moment*moment/(10*(normz+normp)))
checks["positive_pointwise_error_radius"]=eps2>0
checks={name:bool(value) for name,value in checks.items()}
out={"scope":"Fixed constructed original-action signal and one wrong constant-gain history. No measured data or finite-family uniqueness.",
"source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"passed":sum(checks.values()),"failed":sum(not q for q in checks.values()),"checks":checks,
"strong_wrong":str(res),"moment_square_domain":str(moment),"primitive_pair_square_domain":str(pair),"moment_full_sphere":str(moment*4*S.pi/5),
"kernel_L2_squared":{"redshift":str(normz),"lensing":str(normp)},
"nominal_record_rejection_error_squared":str(eps2),"nominal_record_rejection_error":str(S.N(S.sqrt(eps2),20)),
"uniform_bounded_noise_rejection_error_squared":str(eps2/4),"uniform_bounded_noise_rejection_error":str(S.N(S.sqrt(eps2)/2,20)),
"error_meaning":"Equal pointwise absolute envelopes in both normalized primitive channels. At the nominal exact record, eps below first threshold rejects wrong candidate. For every record perturbed by eps, eps below half threshold guarantees it is still rejected using its eps feasibility bound. Strict inequalities; no stochastic claim.",
"signal_scope":"P2 angular mode, unit coefficient; scale signals and thresholds together to remain perturbative",
"window":{"u":["-3/2","-1/2"],"r":["1/2","3/2"]},"elapsed":time.monotonic()-started}
print(json.dumps(out,indent=2));raise SystemExit(out["failed"]!=0)

