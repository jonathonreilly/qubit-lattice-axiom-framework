# Joint photon/background gain correspondence

The two frozen author reconstructions agree with the independently frozen gain algebra in their stated domains. I found no incorrect operator identity, sign, or conditional history bound in these versions. The nine-column route supplies additional radial information and directly extracts C; it does not silently equate rank eight with rank nine. The surviving common gain constant, the supplied action and observation map, and the need to test every original equation are retained. This is a focused mathematical/source correspondence check, not a formal audit, empirical validation, action selection, or publication authorization.

## Exposure and exact reproduction

The independent stage was completed before exposure to the author gain sources: `OUTPUT_FREEZE_v1.json`, SHA256 `23a963abb21e296ce004f9e64d9dbfdadb787196225eccbb3b3e1ce2f3481742`. All 31 files bound there remain byte-identical. Its original report SHA256 is `82c8f1a7bb8c6ea76ab3390e4488e2ef96b8755a69df541e7c85fa236c49ff4e`. That stage includes its own original-equation generator, singular rank-eight examples, the extra original-radial gate, a rejected algebraic root, and a continuous lower-rank full-action ambiguity. None has been overwritten or relabeled as an author result.

After root authorized exposure I read both entire gain notes, both entire runners and their entire results, the nine-column provenance proof, and the imported background-v2 helper. Exact copies are under `author_exposure_v1/`, with `AUTHOR_EXPOSURE_v1.json` binding the exposure. The imported helper is used only for the post-exposure author replay; it was not used by my independent derivation or controls.

| Inspected source/result | SHA256 |
| --- | --- |
| JOINT_PHOTON_GAIN_DERIVATION_v1.md | 60fede53839d8286bbadebe7216e638ca81a850688f113e7dd48ace904ef63bf |
| check_joint_photon_gain_v1.py | 735d0093c01b81373db39022f13ce78e7fefe8a7e70387d01f04a07055c357a2 |
| JOINT_PHOTON_GAIN_CONTROLS_v1.json | 3d817199defcd54507a92494cd0eaa4d83f446532c832fa129abd1233658fb1a |
| JOINT_PHOTON_GAIN_NINE_COLUMN_DERIVATION_v1.md | 5efc5202e18db1ce5ddd118da1ddc97ddf69ceea2fd74047eb3deb20455826f9 |
| check_joint_photon_gain_nine_v1.py | 2a9763d72a53623d80d73e332f3a186c4146585b839b52fa270a2c38ccf03eb5 |
| JOINT_PHOTON_GAIN_NINE_CONTROLS_v1.json | e4ca8459dffaaaadb274044dfdc33c44311869be33c535e7556de7cc23f75d8e |
| independent_joint_photon_background/DERIVATION_BEFORE_CODE_v1.md | be414154d08952ec6b5dfd1252a2103cc66c35ef9b4f4801e0666bef4e59f8f2 |
| check_joint_photon_background_v2.py | b29bdd28f89eda3be419957f340f56d4d7c448adf8b9b66ebe777ad61e74dce6 |

The eight-column copied source reproduced 49/0 checks in 5.054 seconds; the nine-column copied source reproduced 75/0 in 7.793 seconds. Both complete stdout files are byte-identical to the supplied control JSON, not merely equal in check counts. Both stderr files are empty. Each subprocess had its own 120-second timeout and disabled bytecode. These are unchanged author-source replays, not independent discoveries or independent empirical tests.

## Eight-column comparison

The full conjugation agrees with my pre-exposure proof after identifying author mu with my beta and author lambda with my rho. In particular, mu=2h+(Dt'-c2t+crt)/Dt. Correcting the W channel by f known up to a constant is legitimate because the remaining constant can be absorbed into the common physical perturbation amplitude and the other gain.

The author Hc is exactly my Lsrc=2D'-cr+(p-2h)D in the corrected-f convention. The displayed C Riccati and algebraic Hc gate agree. The explicit Hc nonzero condition is essential: my original-equation fixtures attain rank eight with Hc=0, and one also makes the second coefficient-only C gate vanish. The author does not claim that rank eight removes this exception. Its old planning sentence saying physical controls had not yet run is historical candidate prose; the paired later results do contain the 49 executed controls. It should not be used as the final validation status.

With author u=-G/2, its A0 equals my T and its Q0 equals my Q. Substituting G=-2u turns my quadratic into twice the author's quadratic. The required Riccati is the same. The nonzero signs q/G>0 and R>0 are correctly retained. Two roots at one epoch give at most two regular initial values, not two physically realized histories. The author lists and rejects the alternate roots using their nonzero dust-evolution residuals. This agrees with my independent example in which an apparently allowed pointwise root fails evolution.

## Nine-column comparison and original residuals

The independent nine-column provenance proof and root's gain integration use the actual ordered L=partial_tau+a^-1 partial_r. Differentiating a^-1 is retained. The commutator remains K=C'+hC after both gains; the gain changes do not replace K by an arbitrary fitted function. In the sign convention Z'+CZ=-dP'-eP, measured D is minus the corresponding positive-right-hand-side coefficient in my precheck.

The displayed theta coefficients, mu=h+theta1-(theta5-2D')/D, C=theta2+mu, and k=-theta1-mu are correct. Rank nine excludes K=0 because N=0 would give an actual nonzero column null vector with coefficient one on W'. D is nonzero on the regular scalar/coupling and gain chart. The assumed rank is a coeval spatial/angular rank of actual records on an open chart. Recovering coefficient derivatives additionally uses the stipulated smooth time history, not a lone rank measurement.

The original forward code uses the canonical Einstein scalar/momentum/Euler generator with density fixed by Hamiltonian, not jets manufactured from the inverse. The formulas agree with my independent generator. It retains the radial Helmholtz second derivative and assigns distinct recovered l>=2 sectors. The selected nine-row minors are nonzero for all four declared development cases; the rows can be components of one local angular superposition. This establishes local attainability of the rank condition, not a global boundary-value or finite-survey realization. The code also reconstructs hidden velocity and slip and explicitly checks the original momentum and redshift equations for the fixtures. It does not replace those checks with coefficient equality alone.

That distinction is mathematically necessary. Write Aop=partial_tau+C-mu, Bop=L-mu, U=D X'+E X, R1=Aop V+U and R2=Bop V-W. Direct operator algebra gives

    N+K V=(Bop+h)R1-(Aop+h)R2.

The nine-column observable equation with V=-N/K gives R2=0. It then gives only (Bop+h)R1=0, which by itself does not imply R1=0. Thus original momentum, scalar, Hamiltonian/continuity, pressure, background and action-response checks remain genuine obligations. The author explicitly requires them. I do not certify generic sufficiency from the extracted coefficients alone, nor claim that my singular eight-column data prove a rank-nine nonidentifiability.

Once C is selected by the nine-column data, the displayed A,Q give the same dust Riccati and Raychaudhuri quadratic as the independent proof. Differentiating the quadratic produces the stated H1 u+H0 remainder. If H1 is nonzero at any epoch, the resulting u value and Riccati uniqueness give at most one regular connected continuation. If both remainders vanish, the upper bound remains two initial values; all physical residuals still apply. A common free gain constant remains, so this count is modulo that calibration and the stated field/conformal freedoms. No existence of two physical branches, global theory uniqueness, or state-origin derivation follows.

## Distinct supplementary controls and pressure trace

`post_exposure_controls_v1.py` is a separate post-exposure implementation with no author imports. It produced 16/0 exact checks, source SHA256 `a76deac5fe8d0976d169d88f4bd435aa5afcba16cd58308df4e7783b64e6a978`, stdout SHA256 `0501ec9a1f5e3f1c428395ece232737b5d95bc8254a5fab84489860a1a8aa451`. Its source was frozen before this supplementary execution. It verifies the history remainder, notation/sign map, and the ordered operator on a separate nonconstant geometry/coefficient fixture at four exact rational points. The arbitrary test fields in that fixture verify an operator identity; they are not asserted to solve the scalar action.

The pressure-trace check uses direct polynomial division without dividing by the quadratic constant F. In notation where P=u Dtrace X and the reconstructed Z derivatives are independent of u, it gives the exact identity

    trace = 2 Z' (4u^2+B u+F) + u T0,

where T0 is independent of u after the dust Riccati substitution. Dtrace absorbs the measured coefficient and the known gain history; it is not identified with the nine-column D without that conversion. The full T0 expression is retained in the output. The certificate remains valid at F=0. This corroborates the author's generic rational check and removes any need to infer an extra F nonzero domain from its intermediate symbolic division. Pressure trace remains a data/compatibility check, but under these substitutions it cannot independently choose between surviving u roots.

No failed computation, exception, relaxed tolerance, overwritten source, or new empirical exposure occurred in this comparison. The original precheck's explicit refinement of its factorization scope remains preserved separately.

## Remaining limits

The author notes expressly assume positive gains. The neutral problem and my precheck allow arbitrary smooth nonzero real gains. The identities extend using logarithmic derivatives and constant signs, but the author condition -uD>0 is specifically the positive-relative-gain branch; it must not be imposed as a consequence of mere nonvanishing. The common f0 is positive within the author's domain and can have either sign in the broader nonzero-gain problem. This is a scope restriction, not an error in the displayed identities.

The supplied canonical action class, same pressureless species, regular nonzero speed/coupling, calibrated a and h, matter-time/spatial registration, full recovered angular sector or equal-potential convention, corrected redshift interpretation, exact sufficiently rich derivatives, and actual rank remain premises. Unknown detector transfers, arbitrary observation-time gains, masked-sky kernels, finite/noisy records, calibration-error propagation, independent absolute scale, off-trajectory action selection and initial-state selection have not been derived here. My continuous full-action ambiguity remains a lower-rank limitation and is not contradicted by the stronger nine-column criterion. This report neither extends the author's rank criterion to those missing domains nor supplies a formal audit verdict.
