# Independent calibration derivation before author exposure

Let a,h be registered and a'=ha, c=1/a. Use the permitted equal-Einstein-potential/nonzero-mode or recovered full-sky l>=2 domain. Original momentum/Euler/redshift give Z'+CZ=DP'+EP and Z'+c Z_r=Y, with D=-2/G, G=x/b, C=R/G, E=(h-q)D-1. All gains are smooth spatially uniform and nonzero on a connected interval. No measured arrays or new author calibration material have been read.

Write X=gP, W=fY, beta=f'/f, rho=g'/g, lambda=f/g, and V=fZ. Define d=lambda D and e=lambda(E-rho D). The original two equations become

    V'+(C-beta)V=dX'+eX,
    V'+c V_r-beta V=W.

For Aop=partial_tau+C-beta and Bop=partial_tau+c partial_r-beta, [Bop,Aop]=h Bop-h Aop+K, K=C'+hC. Hence

    K V=(Bop+h)(dX'+eX)-(Aop+h)W=N,
    (partial_tau+delta_b)N-K(dX'+eX)=0,
    delta_b=C-beta-K'/K.

For the observed eight-column design in the permitted note, denote its coefficients [d,c2,cr,c1,cr0,c0,p,z]. Direct differentiation gives

    c2=2d'+e+(h-beta+delta_b)d,
    cr=d'+e+(delta_b-h)d,
    c1=d''+2e'+(h'-beta')d+(h-beta)d'+(h-beta)e
       +delta_b[d'+e+(h-beta)d]-Kd,
    cr0=e'+(delta_b-h)e,
    c0=e''+(h'-beta')e+(h-beta)e'+delta_b[e'+(h-beta)e]-Ke,
    p=C+h-beta+delta_b,
    z=C'+h'-beta'+delta_b(C+h-beta).

Thus rank eight and d!=0 identify the redshift gain's logarithmic drift directly:

    beta=2h+(d'-c2+cr)/d.

This does not identify its constant scale or sign. At K=0 the commutator equation N=0 gives a nonzero linear relation in the design columns (d is nonzero), so rank eight excludes K=0 in this declared chart. Arbitrary rank loss, b=0, x=0 and R=0 require different arguments.

Let v=h-beta and define

    a0=v^2-pv+z-h'+beta', a1=3h-2beta-p,
    b0=cr-d'+(2h-beta-p)d.

Then e=dC+b0 and the z equation supplies

    C'=C^2+(2h-2beta-p)C+a0.

Two additional coefficient/definition identities are linear in C:

    cr0=Lsrc C+Bsrc,
    Lsrc=2d'-cr+(p-2h)d,
    Bsrc=d a0+b0'+(p+beta-2h)b0;

    Lcom C+Bcom=0,
    Lcom=a1'+h a1, Bcom=a0'+2h a0.

The second follows from K=C'+hC and K'/K=2C+h-2beta-p. If either linear denominator is nonzero at an epoch, C's initial value is fixed there, and the regular Riccati equation gives at most one connected local C history. Other coefficients and all physical residuals remain mandatory. This is stronger than using only the two quadratics in the calibrated note, but cannot be asserted when both gates vanish identically.

When Lsrc=0, e=d'+(C-beta)d, so the source is an Aop derivative and the observed equation factorizes as

    [partial_tau^2+p partial_tau+z]
      [W-(partial_tau+c partial_r-beta)(dX)]=0.

If Lcom=Bcom=0 too, the factorization coefficients alone can retain a continuous Riccati family of C histories. This is a kinematic statement, not a claim that all members satisfy the remaining background and scalar equations.

For a fixed surviving C, set n=d'/d and

    m=p-h-cr/d+2n-C,
    T=C'/C+3h-2m, Q=C'/C+3h-m.

Dust transport and E=(h-q)D-1 imply

    G'=G(T-G), q=Q-G/2.

Raychaudhuri is the algebraic condition

    2G^2+(h-3Q-T-C)G+2(Q'-h'-hQ+Q^2)=0.

Therefore, for a fixed C history, at most two initial G values can survive and each defines at most one local regular history through the Riccati equation. A pointwise root is not a history: it must satisfy that ODE and every later residual. Require CG>0 and q/G>0, with q,G nonzero. Then

    lambda=f/g=-dG/2,
    f=f0 exp integral beta, g=f/lambda,
    b=sign sqrt(q/G), x=q/b.

Relative gain and its drift are reconstructed per surviving branch; the common nonzero constant f0 remains. Rescaling both gains by a constant and all linear physical perturbations by its inverse preserves the observations and every linear equation. No finite/unique complete history claim can ignore this amplitude freedom, A0, field origin/orientation, singular coefficient loci, or failed physical residuals.

A planned exact obstruction uses registered a=1,h=0, sigma=tau-tau0>0, fixed action V=0, b=-1/sqrt(2), conformal A=2/sigma, x=sqrt(2)/sigma, q=-1/sigma, R=2/sigma^2, G=-2/sigma, C=-1/sigma, D=sigma, E=0. For harmonic spatial A0(X),B0(X), define F=A0+tau B0 and

    P=F/sigma, Z=F, J=-B0-F/sigma,
    w=-sqrt(2)J, delta=3F/sigma-3B0,
    Y=B0+partial_r F,
    g=sigma/tau, f=1.

The measured X=F/tau and W=Y are independent of tau0. This family is to be checked against all original equations before asserting it. It is local/synthetic and can use harmonic l>=2 solid polynomials. It will not be presented as a rank-eight counterexample without computing its rank; the simple affine F example already has a lower-order observed relation and hence deficient design. It challenges blanket uniqueness without adequate rank/calibration, not the generic conditional result.

Planned exact power-background diagnostics are p=2,c=1 with gains g=t^2,f=t^-1; p=3/4,c=1/sqrt(2) with unit gains; p=1/2,c=1/sqrt(2) with unit gains. The last two have E=D'+CD, and the last also has both C-identification gates zero, while K!=0. Original-equation rank and every reconstructed identity must be checked, not assumed. All proofs/formulas above precede the new executable and any new author gain source exposure.
