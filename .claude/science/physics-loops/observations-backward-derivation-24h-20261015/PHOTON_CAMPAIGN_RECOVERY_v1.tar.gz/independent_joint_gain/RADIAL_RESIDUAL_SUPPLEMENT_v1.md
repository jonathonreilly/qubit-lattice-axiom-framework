# Independent supplement: keep the original radial residual

This supplements, not overwrites, DERIVATION_BEFORE_AUTHOR_v1.md before any new root calibration exposure. The continuous Riccati family mentioned there is a family of the eliminated coefficient relation, not automatically of the original radial PDE. That distinction is essential even before imposing the scalar equation.

Use the frozen notation and define the observable Lsrc=l, H=V-dX, and

    U=W-(partial_tau+a^-1 partial_r-beta)(dX).

Then Aop H=-lX and Bop H=U. Set

    V0=U'+(h-beta)U+l(X'+a^-1 X_r)+(l'+(h-beta)l)X.

The commutator gives K H=-C U-V0. With the previously derived Riccati identity K=C^2+a1 C+a0, the original radial equation yields the additional pointwise polynomial

    -l X C^2
    +[V0-a^-1 U_r-a1(U+lX)]C
    -a^-1 (V0)_r-a0(U+lX)=0.

For l=0 this is linear in C. It may select the true C even when both earlier background-only linear gates vanish. Its spatial derivatives are not supplied by the original eight-column time-reduced relation alone. A nonzero gate at any spatial point/epoch fixes an initial C; smooth Riccati uniqueness then fixes its interval continuation. If all such gates vanish, existence/uniqueness must still be settled with the remaining full equations, not inferred from root counting.

The frozen p=1/2,c=1/sqrt(2) background has a=1,h=0, C=-1/tau,D=tau,E=0. Both earlier C-gates vanish, K=1/tau^2!=0, yet the independent original-equation design has rank8. Choose its predeclared state seed P=u=u_dot=0,U_E=1, k_com^2=1, radial f=1,f_r=0 at r=1, and an l=2 local Helmholtz completion f_rr=5. At t_E=1, tau=2, H=1 and its time-independent coefficient H/tau=1/2. The measured quantities give U=1/2,U'=0,U_r=5,(V0)_r=5/2. Thus the extra radial equation is -5C-5/2=0. It selects C=-1/2, and rejects the trial family C=-1/(2-shift) by residual 5 shift/[2(2-shift)] when shift!=0. This is an exact original-equation seed calculation, not an extra fitted observation. It avoids overclaiming that the singular eight-coefficient example is a full physical nonidentifiability counterexample.

Conversely, the separately checked continuous lower-rank family in v1 satisfies all original equations and has identical X,W. Its lower-order observed null relation is preserved. It refutes blanket calibration/background uniqueness without the actual rank and residual conditions, not the possible uniqueness of suitably rich full-equation histories.

Even once C is fixed, a pointwise G quadratic root need not be a history. In the regular p=2,c=1 background, Q=33/(40tau),T=-19/(20tau),C=12/(5tau),h=6/(5tau). The roots G=1/(20tau) and G=21/(16tau) both satisfy Raychaudhuri algebraically and have positive R and q/G. Only the first satisfies G'=G(T-G); the second has residual 2121/(1280tau^2). No branch is selected by preference.
