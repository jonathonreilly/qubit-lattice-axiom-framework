# Independent joint gain/background pre-exposure report

The independent derivation and executable results are now frozen, before reading any new root gain/calibration source or result. Only the two permitted notes were read; their bytes are copied under `permitted_sources/`. Root remains author. This is a focused mathematical/source check, not a formal audit, observed-data inference or an independent empirical test.

## Identifiable combinations and surviving freedom

Let `X=gP`, `W=fY`, `beta=f'/f`, `rho=g'/g`, `lambda=f/g`, and `V=fZ`. The calibrated original equations are

    V'+(C-beta)V=dX'+eX,
    V'+a^-1 V_r-beta V=W,
    d=lambda D, e=lambda(E-rho D).

The eight-coefficient time-reduced relation determines

    beta=2h+(d'-c2+cr)/d.

This determines the redshift gain's logarithmic drift, not its constant amplitude or sign. The exact derivation is in `DERIVATION_BEFORE_AUTHOR_v1.md`, together with the full changed coefficients. Its commutator retains `K=C'+hC`; rank eight excludes `K=0` in the stipulated chart, but does not exclude the later algebraic singularities.

Two independent coefficient identities are linear in `C`. Using

    v=h-beta,
    a0=v^2-pv+z-h'+beta', a1=3h-2beta-p,
    b0=cr-d'+(2h-beta-p)d,

one has

    C'=C^2+(2h-2beta-p)C+a0,
    cr0=[2d'-cr+(p-2h)d]C+d a0+b0'+(p+beta-2h)b0,
    (a1'+h a1)C+a0'+2h a0=0.

A nonzero linear coefficient at any epoch selects an initial `C`; the smooth Riccati equation determines at most one connected regular continuation. All other equations remain checks. Neither denominator can be assumed nonzero from rank eight alone.

For a fixed surviving `C` history, define

    m=p-h-cr/d+2d'/d-C,
    T=C'/C+3h-2m, Q=C'/C+3h-m.

Dust transport and the original force coefficient give

    G'=G(T-G), q=Q-G/2,
    2G^2+(h-3Q-T-C)G+2(Q'-h'-hQ+Q^2)=0.

There are at most two initial `G` values for this fixed `C`, hence at most two local regular candidate histories before the other residuals. The branch must satisfy `CG>0`, `q/G>0`, nonzero `q,G`, the Riccati evolution, all coefficient identities and all original field equations. Relative calibration is then

    f/g=-dG/2,
    f=f0 exp(integral beta), g=f/(-dG/2).

The common nonzero constant `f0` is not identifiable from this homogeneous linear system. Scaling both gains by it and all physical linear perturbations inversely leaves every original equation and the observed records unchanged. The usual absolute conformal normalization and field origin/orientation also survive. These formulas concern the supplied matter-time uniform gains, not arbitrary detector/reception-time transfers.

## The original radial equation cannot be dropped

`RADIAL_RESIDUAL_SUPPLEMENT_v1.md` makes explicit a necessary qualification to the first proof's factorization discussion: a continuous family of the eliminated coefficient relation is not automatically a family of the original radial PDE.

Let `l=2d'-cr+(p-2h)d`, `H=V-dX` and

    U=W-(partial_tau+a^-1 partial_r-beta)(dX),
    V0=U'+(h-beta)U+l(X'+a^-1 X_r)+(l'+(h-beta)l)X.

Then `K H=-C U-V0`. The unused original radial residual supplies

    -l X C^2+[V0-a^-1 U_r-a1(U+lX)]C
       -a^-1 (V0)_r-a0(U+lX)=0.

When `l=0` this is another linear gate. A nonzero value of its coefficient at an available spatial point can fix `C` even if both background-only gates vanish. If all available gates vanish, no universal finite/unique-history conclusion is proved here; the remaining physical residuals must still be analyzed. I have not proved nonidentifiability of every rank-eight fully compatible history.

## Exact original-equation controls

The source was frozen before execution. I independently assembled the four-state Einstein scalar/momentum/Euler generator, defined bare density using the Hamiltonian, checked its original dust propagation, and formed exact matter-time output jets. The 32 rows use the predeclared four wavenumber squares, four state basis seeds and two radial value/slope seeds. No jets were chosen from the proposed inverse relation. Truth coefficients were compared after solving the exact design.

| Background and gain case | Rank / augmented rank | Selected minor | Lsrc | Lcom | K at t=1 |
| --- | --- | --- | --- | --- | --- |
| p=2,c=1; g=t^2,f=t^-1 | 8 / 8 | 3/4 | -119 | -22 | 12 |
| p=3/4,c=1/sqrt(2); unit gains | 8 / 8 | -1/512 | 0 | 3/8 | -1/8 |
| p=1/2,c=1/sqrt(2); unit gains | 8 / 8 | 1/256 | 0 | 0 | 1/4 |

All three cases have positive dust and regular nonzero scalar/coupling charts. Thus the singularities are attained by physically admissible original-equation data, not merely arbitrary inverse jets. The eight-column relation in the last case is `[d,c2,cr,c1,cr0,c0,p,z]=[tau,3,2,0,0,0,0,0]`.

The extra radial condition nevertheless selects the true background in a fixed original seed of that last case. At `tau=2`, an `l=2,k^2=1` Helmholtz seed with radial value one and slope zero has second radial derivative five. For `P=u=u_dot=0,U_E=1`, direct original rates give `U_r=5,(V0)_r=5/2`. The radial equation is `-5C-5/2=0`. The trial `C=-1/(2-shift)` fails by `5 shift/[2(2-shift)]` unless `shift=0`. This deliberately prevents interpreting the doubly singular coefficient example as a full-system degeneracy.

A separate root-counting control shows why a pointwise quadratic is insufficient. In the regular p=2 background both `G=1/(20tau)` and `G=21/(16tau)` solve the Raychaudhuri quadratic and meet the sign conditions. The latter fails the required Riccati equation by `2121/(1280tau^2)`. It is rejected as a history rather than selected or discarded by preference.

## A genuine continuous ambiguity with deficient data rank

For registered `a=1,h=0`, fixed `V=0` and exponential coupling `b=-1/sqrt(2)`, put `s=tau-shift>0`, `A=2/s`, `x=sqrt(2)/s`, `q=-1/s`, `R=2/s^2`. With spatial harmonic `A0,B0`, set

    F=A0+tau B0,
    P=F/s, Z=F, J=-B0-F/s,
    w=-sqrt(2)J, delta=3F/s-3B0,
    g=s/tau, f=1.

The measured `X=F/tau` and `W=B0+partial_r F` are independent of `shift`. The explicit solid harmonics `A0=Xcart^2-Ycart^2` and `B0=Zcart^3-3Zcart Xcart^2` have full-sky `l=2,3` and satisfy the original momentum, Hamiltonian, scalar, both dust equations and pressure trace. The homogeneous action equations, fixed-density curvature and dust normalization also hold. A compact regular interval and common small amplitude keep the entire local family in the linear regime.

This is an exact local full-action linear ambiguity in the background epoch and gain, even within one action. It is not a rank-eight counterexample: `W-tau X'-X-tau X_r=0` is a lower-order observed null relation. It also makes no claim of global normalizability, nonlinear stability or measured cosmological relevance.

## Executions, independence and limitations

The separate bounded runs produced: generic gain algebra 15/0; full-action ambiguity 17/0; each of three original-equation cases 51/0; radial/pointwise-history supplement 11/0. These row/identity counts overlap and are not independent experiments. Every attempt finished in under 0.5 seconds with timeout 120 and bytecode disabled. Complete stdout/stderr and hashes are retained. No failed computation, tolerance relaxation or source repair occurred; the factorization domain was explicitly narrowed in a separate preserved supplement before author exposure.

The independent derivation/source/result identities are frozen in `OUTPUT_FREEZE_v1.json`. In particular the main source SHA256 is `43625c5bbcd91bcce3338378d39d4a0da70c0c064b96680406d87065898f3eb1`, its initial proof is `0cfa249e661f1940fd82aeba87503beb876f5ad8124202b803b50c330199e5e0`, and the separate radial control source is `3c843dcc4308ae9934be9b672e901b00170777e5924796b27fa60684f67968e3`.

The original action, flatness, same-dust identification, exact derivatives, coordinate/clock registration, angular sector and actual design rank remain premises. The generic conditional finite bound is per selected `C`, modulo common amplitude and the stated field/scale freedoms. No general theorem resolving all simultaneous gate degeneracies, arbitrary gain models, noisy finite data or physical calibration has been established. No author calibration source/result has yet been read; comparison is the next stage.
