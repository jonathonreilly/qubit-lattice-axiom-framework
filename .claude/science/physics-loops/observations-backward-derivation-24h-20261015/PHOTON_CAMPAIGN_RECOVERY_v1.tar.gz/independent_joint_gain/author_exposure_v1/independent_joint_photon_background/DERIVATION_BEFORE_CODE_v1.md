# Independent joint photon/background derivation before new author exposure

The only source read is the already-known canonical action/linear-equation
note, copied and bound in NEUTRAL_CONTRACT_v1.json. No new joint-background
author note, plan, runner or result has been read. The following nine-column
rank criterion is provisional until its attainability is tested on actual
full-equation solutions. Root retains authorship of the campaign.

## Domain and hidden first-order system

Work with smooth real fields, known registered a>0 and h=a'/a on an open
matter-time/radial/angular product chart with r>0. Spatial radial derivatives
are at fixed matter time. On repeated cones they are partial_r+partial_u;
partial_tau=a^-1 partial_u. The scalar/dust action class, flat background,
linearization and equal-Einstein-potential/integrated-potential convention
are supplied. A recovered full-sky l>=2 sector is an alternative way to
remove the local polynomial metric kernel. A generic masked patch is not.

Retain the regular background chart R>0, b!=0, x!=0. Put q=bx,
G=x/b, ell=h-q and define three homogeneous functions

    c=R/G, d=2/G, e=1+d ell.

Neither J nor c,d,e is observed. Momentum and Euler imply

    Z'+cZ=-U,       U=dP'+eP.

The measured corrected redshift is

    Y=-P-J+Z_r/a=Z'+Z_r/a.

Let L=partial_tau+a^-1 partial_r. Thus LZ=Y, equivalently

    Z_r-a c Z=a(Y+U).

The commutator of the two first-order equations gives

    K Z=-N,             K=c'+h c,
    N=Y'+(h+c)Y+d L(P')+(d'+h d)P'
                   +e L(P)+(e'+h e)P.                    (1)

The coefficient aK is (ac)'. Its vanishing is an actual chart issue and may
not be divided away silently.

## Nine-column observable input-output identity

Where K!=0, put k=K'/K. Applying L to Z=-N/K gives

    (L-k)N+K Y=0.                                      (2)

Define the known target and row

    O=L(Y')+h L(Y)+h'Y,
    X=[Y', L(Y), Y, L^2(P'), L(P'), P', L^2(P), L(P), P].

Then O+X theta=0, where

    theta1=-k,
    theta2=c,
    theta3=2c'+h c-k(h+c),
    theta4=d,
    theta5=2d'+(h-k)d,
    theta6=d''+(h-k)d'+(h'-kh)d,
    theta7=e,
    theta8=2e'+(h-k)e,
    theta9=e''+(h-k)e'+(h'-kh)e.                      (3)

The operator ordering matters: L^2(P') is the repeated actual L operator
on the matter-time derivative, not a commuting constant-coefficient shortcut.
a' terms must be retained.

At each time, collect coeval spatial/angular rows, or separately recovered
full-sky harmonic coefficients because the background and radial operators
preserve angular sectors. Rank nine and exact column-space membership
determine theta and in particular c,d,e. Full rank must be tested on genuine
solutions, not generic arbitrary observable jets.

A useful exceptional-chart fact: if a compatible background had K=0 at the
epoch, (1) would give the homogeneous relation N=0. It is a nontrivial
linear combination of columns of X, with coefficient 1 on Y'. Therefore
rank nine excludes K=0 candidates, even if K vanishes only at that epoch.
If rank nine holds throughout an open time interval, every compatible
regular background lies on the K!=0 chart. Any two such backgrounds have
the same c,d,e and hence the same quantities reconstructed below.

This is only a sufficient rank criterion. Rank loss is not a no-go for
lower-order, nonlinear, integrated or other-chart inference.

## Physical reconstruction and residuals

From extracted c,d,e set

    G=2/d, R=2c/d, ell=(e-1)/d, q=h-ell,
    x^2=qG=2q/d>0, b=q/x,

with one constant field-orientation choice x=+sqrt(qG) or -sqrt(qG).
Require d!=0 and R>0; c is consequently nonzero. The coefficient derivatives
must satisfy every relation (3), with K=c'+hc!=0 and k=K'/K.

Dust transport and Raychaudhuri become the useful direct checks

    c'/c-d'/d=2q-3h,
    R=-2ell'-2q ell-x^2.                              (4)

These are physical constraints, not free fitting identities. They also give

    K=(c/d)[d'-2(e-1)],
    c=-e'-h e+(e-1)(d'+e)/d.

For A0>0 and phi0 construct

    A=A0 exp(integral q d tau),
    phi=phi0+M integral x d tau,
    dt=d tau/A, aE=a/A,
    rE=M^2 A^2 R, rho=M^2 A R,
    V=M^2 A^2[3ell^2-x^2/2-R].

Nonzero x gives local A(phi),V(phi). The constraints and dust transport imply
the original scalar background equation by differentiated Friedmann, with
no arbitrary scalar-force constant. Define

    Fbar=-x'-(3h-2q)x,
    kappa=[Fbar'+2q Fbar+3ell bR]/x.                   (5)

This follows from differentiating F=V_phi+rho A_phi with
rho'/rho=-3ell, holding rho fixed only in the definition of
mu=V_phiphi+rho A_phiphi. It is the response curvature, not a measured pole.

Reconstruct Z=-N/K and J=-P-Z', w=J/b. Test LZ=Y and the first-order momentum
equation explicitly; (2) alone is not full compatibility. Reconstruct bare
delta from Hamiltonian and require its continuity, the original scalar
wave equation, and the original spatial pressure equation. Require all
background equations and equality of (5) to the action-derived fixed-density
response. These checks, not rank alone, establish a local compatible linear
solution in the supplied class.

A0, phi0 and field reflection remain. At fixed registered matter units,
A0 scaling changes rE,V by A0^2 and rho by A0. A supplied bare normalization
or independent absolute gravitational calibration could constrain this
freedom; the photon inputs here do not supply it. Off-trajectory extensions
of A,V and initial-state origin remain undetermined.

## Actual full-equation fixture proposed for the rank test

Use M=1 and Einstein time t>0,

    aE=t^2, phi=ln t, A=exp(4phi)=t^4,
    rho=3t^-6, rE=3t^-2, V=(17/2)exp(-2phi),
    tau=t^5/5, a=t^6, h=6t^-5,
    b=4, x=t^-5, q=4t^-5, G=t^-5/4,
    R=3t^-10, F=-5t^-2, mu=82t^-2, kappa=82t^-10.

Thus c=12t^-5,d=8t^5,e=17 and K=12t^-10 is nonzero.
This differs from the earlier aE=t fixture whose ac is constant.

For each genuine spatial Laplace eigenmode Delta B=-k_com^2 B, integrate
the original Einstein-time first-order system in (P,w,zeta,U_E,delta):

    dot(P)=(v w-rE U_E)/2-H_E P,
    dot(w)=zeta,
    dot(zeta)=-3H_E zeta-(k_com^2/aE^2+mu)w
                    +4v dot(P)-2F P-b rE delta,
    dot(U_E)=-P-bw-bv U_E,
    dot(delta)=3dot(P)+(k_com^2/aE^2)U_E.

Choose P,w,zeta,U_E freely at t=1 and solve Hamiltonian for delta. Check
constraint propagation and the spatial pressure equation explicitly.
Equivalently eliminate delta by Hamiltonian to obtain a four-variable
analytic ODE, then test the continuity residual. Its local solutions are
actual full-equation solutions, not arbitrary independently selected jets.

For full-sky l>=2 fields let the radial profile satisfy

    B''+2B'/r+[k_com^2-l(l+1)/r^2]B=0

with arbitrary finite B(1),B'(1). This has a local analytic solution on an
annulus. Distinct recovered angular sectors can carry independent initial
states, wave numbers and radial Cauchy data. Derive time and radial jets from
these ODEs and evaluate the nine-column design at t=r=1. A nonzero exact
determinant from finitely many such sectors proves local attainability;
continuity then preserves that determinant on a neighborhood.

If the full-equation design has a structural rank deficit, preserve it
plainly and derive the limitation rather than replacing the physical rows
with arbitrary jets. No preselected favorable rank or count is assumed.

## Unconditional non-identifiability and test plan

Even ideal a,h do not identify the homogeneous background without sufficient
perturbation information. For any s in (0,2), the exact family

    aE=t, phi=sqrt(s) ln t,
    A=exp(phi/sqrt(s))=t,
    rho=(2-s)t^-3, rE=(2-s)t^-2,
    V=(1+s/2) exp(-2phi/sqrt(s))

has the same tau=t^2/2, a=2tau, h=1/tau and the full linear solution
P=J=Z=delta=Y=0. Its b=1/sqrt(s), G=s/(2tau),
R=(2-s)/(4tau^2) and kappa=(6+s)/(4s tau^2) differ. This is a continuous
conditional family of different actions/backgrounds at a rank-zero record,
not a claim of ambiguity when the proposed full rank holds.

The executable tests will check (1)-(3) with independent symbolic functions;
all original background and linear equations for the p=2 construction;
exact physical rank and coefficient recovery; the K=0 obstruction on the
p=1 family; and the continuous zero-record family. All subprocesses will
be bounded at 120 seconds with bytecode disabled and full failures retained.

