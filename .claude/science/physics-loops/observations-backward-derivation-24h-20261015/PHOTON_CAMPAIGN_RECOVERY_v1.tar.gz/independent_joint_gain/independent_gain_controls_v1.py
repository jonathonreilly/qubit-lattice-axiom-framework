"""Independent exact gain checks, written before root calibration exposure."""
import sympy as s
import json,sys
checks=[]
def ck(name,expr):
    value=s.factor(s.cancel(s.expand(expr)))
    checks.append({'name':name,'pass':value==0,'residual':str(value)})
def outcome(details):
    print(json.dumps({'checks':checks,'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks),'details':details},indent=2,sort_keys=True))
    raise SystemExit(any(not q['pass'] for q in checks))

def algebra():
    t,r=s.symbols('tau r',real=True)
    a,h,C,beta,d,e,k,de=[s.Function(n)(t) for n in ['a','h','C','beta','d','e','K','db']]
    X=s.Function('X')(t,r);W=s.Function('W')(t,r)
    dt=lambda v:s.diff(v,t)
    F=d*dt(X)+e*X
    A=lambda v:dt(v)+(C-beta)*v
    B=lambda v:dt(v)+s.diff(v,r)/a-beta*v
    # This operator check derives the commutator directly, without row expansion.
    V=s.Function('V')(t,r)
    ck('two calibrated operators preserve K commutator',
       (B(A(V))-A(B(V))-h*B(V)+h*A(V)-(dt(C)+h*C)*V).subs(dt(a),h*a))
    N=B(F)+h*F-A(W)-h*W
    c2=2*dt(d)+e+(h-beta+de)*d
    cr=dt(d)+e+(de-h)*d
    c1=dt(d, ) if False else s.diff(d,t,2)+2*dt(e)+(dt(h)-dt(beta))*d+(h-beta)*dt(d)+(h-beta)*e+de*(dt(d)+e+(h-beta)*d)-k*d
    cr0=dt(e)+(de-h)*e
    c0=s.diff(e,t,2)+(dt(h)-dt(beta))*e+(h-beta)*dt(e)+de*(dt(e)+(h-beta)*e)-k*e
    pp=C+h-beta+de;zz=dt(C)+dt(h)-dt(beta)+de*(C+h-beta)
    target=d*(s.diff(X,t,3)+s.diff(X,t,2,r)/a)+c2*s.diff(X,t,2)+cr*s.diff(X,t,r)/a+c1*dt(X)+cr0*s.diff(X,r)/a+c0*X-pp*dt(W)-zz*W-s.diff(W,t,2)
    ck('full eight-coefficient calibrated expansion',(dt(N)+de*N-k*F-target).subs(dt(a),h*a))
    ck('redshift gain drift identified',2*h+(dt(d)-c2+cr)/d-beta)
    # Independent algebraic elimination with scalar jets rather than functions.
    cv,hv,bv,pv,zv,hp,bp,dv,dp,b0,b0p,A0,A1,A1p,A0p=s.symbols('C h beta p z hp betap d dp b0 b0p a0 a1 a1p a0p')
    ric=cv**2+(2*hv-2*bv-pv)*cv+A0
    ev=dv*cv+b0
    dbv=pv-cv+bv-hv
    cr0v=dp*cv+dv*ric+b0p+(dbv-hv)*ev
    Lsrc=dp-bv*dv-b0
    Bsrc=dv*A0+b0p+(pv+bv-2*hv)*b0
    ck('linear C gate from radial-source coefficient',cr0v-Lsrc*cv-Bsrc)
    crv=dp+ev+(dbv-hv)*dv
    ck('linear C gate observable denominator',2*dp-crv+(pv-2*hv)*dv-Lsrc)
    kval=cv**2+A1*cv+A0
    kp=(2*cv+A1)*ric+A1p*cv+A0p
    expr=kp-(2*cv+hv-2*bv-pv)*kval-(A1p+hv*A1)*cv-A0p-2*hv*A0
    ck('linear C gate from K logarithmic identity',expr.subs(A1,3*hv-2*bv-pv))
    G,Gp,Q,Qp,T=s.symbols('G Gp Q Qp T')
    qv=Q-G/2;qp=Qp-G*(T-G)/2
    ray=2*qp-2*hp-2*hv*qv+2*qv*qv-qv*G
    poly=2*G*G+(hv-3*Q-T-cv)*G+2*(Qp-hp-hv*Q+Q*Q)
    ck('Raychaudhuri becomes G quadratic',ray-cv*G-poly)
    # On the doubly singular gate family the observed operator does not fix C.
    tau,shift=s.symbols('tau shift',real=True)
    cv=-1/(tau-shift);dv=tau;ev=-shift/(tau-shift);hv=bv=s.Integer(0)
    kval=s.diff(cv,tau);db=cv-s.diff(kval,tau)/kval
    coeff=[dv,2*s.diff(dv,tau)+ev+db*dv,s.diff(dv,tau)+ev+db*dv,
       s.diff(dv,tau,2)+2*s.diff(ev,tau)+db*(s.diff(dv,tau)+ev)-kval*dv,
       s.diff(ev,tau)+db*ev,s.diff(ev,tau,2)+db*s.diff(ev,tau)-kval*ev,
       cv+db,s.diff(cv,tau)+db*cv]
    for i,(got,want) in enumerate(zip(coeff,[tau,3,2,0,0,0,0,0])):ck('singular observed coefficient '+str(i),got-want)
    outcome({'singular_coefficients':[str(s.factor(v)) for v in coeff],'scope':'Exact post-neutral independent algebra, no author calibration source.'})

def ambiguity():
    tau,shift,X,Y,Z=s.symbols('tau shift X Y Z',real=True)
    sig=tau-shift
    lap=lambda v:sum(s.diff(v,j,2) for j in [X,Y,Z])
    rr=s.sqrt(X*X+Y*Y+Z*Z)
    rad=lambda v:(X*s.diff(v,X)+Y*s.diff(v,Y)+Z*s.diff(v,Z))/rr
    F0=X*X-Y*Y;F1=Z**3-3*Z*X*X;F=F0+tau*F1
    a=s.Integer(1);h=s.Integer(0);q=-1/sig;b=-1/s.sqrt(2);x=s.sqrt(2)/sig
    ell=-q;R=2/sig**2;kap=1/sig**2;Fb=-s.sqrt(2)/sig**2
    P=F/sig;Zv=F;J=-F1-P;w=J/b;delta=3*P-3*F1
    ck('spatial F0 harmonic',lap(F0));ck('spatial F1 harmonic',lap(F1))
    ck('original momentum',2*(s.diff(P,tau)+ell*P)-x*w+R*Zv)
    ck('original Hamiltonian',R*delta-(2*lap(P)-6*ell*(s.diff(P,tau)+ell*P)-x*s.diff(w,tau)+x*x*P-Fb*w))
    ck('original scalar',s.diff(w,tau,2)-2*q*s.diff(w,tau)-lap(w)+kap*w+b*R*delta-4*x*s.diff(P,tau)+2*Fb*P)
    ck('original dust Euler',s.diff(Zv,tau)+P+J)
    ck('original bare continuity',s.diff(delta,tau)-3*s.diff(P,tau)+lap(Zv))
    ck('original pressure trace',2*s.diff(P,tau,2)+2*(q+4*ell)*s.diff(P,tau)+(4*s.diff(ell,tau)+4*q*ell+6*ell**2+x*x)*P-x*s.diff(w,tau)+(Fb-b*R)*w)
    A=2/sig;HE=A*ell;v=A*x;rE=A*A*R;rho=rE/A;V=s.Integer(0)
    dot=lambda z:A*s.diff(z,tau)
    force=A*A*Fb
    ck('background Friedmann',3*HE*HE-v*v/2-V-rE)
    ck('background Raychaudhuri',-2*dot(HE)-v*v-rE)
    ck('background original scalar',dot(v)+3*HE*v+force)
    ck('background bare dust',dot(rho)+3*HE*rho)
    ck('action force from V0 exponential A',force-b*rE)
    ck('action curvature at fixed bare density',kap-b*b*R)
    gain=sig/tau;Xobs=gain*P;Wobs=s.diff(Zv,tau)+rad(Zv)
    ck('observed X independent of shift',s.diff(Xobs,shift))
    ck('observed W independent of shift',s.diff(Wobs,shift))
    ck('observed first-order relation shows rank loss',Wobs-tau*s.diff(Xobs,tau)-Xobs-tau*rad(Xobs))
    outcome({'domain':'tau>max(0,shift), open annulus, arbitrary common small linear amplitude','background_action':'a=1,h=0,V=0,b=-1/sqrt(2), A(phi)=2exp(-phi/sqrt(2)) with phi=sqrt(2)log(tau-shift)','continuous_parameter':'shift','physical_P_depends_on_shift':str(s.factor(s.diff(P,shift))),'observed_X':str(s.factor(Xobs)),'observed_W':str(s.factor(Wobs)),'rank_scope':'Explicit lower-order observed null relation; not a rank-eight counterexample. Local l>=2 harmonic fields, no global normalizability claim.'})

def forward(case):
    t,k=s.symbols('t k',positive=True)
    cases=[(s.Integer(2),s.Integer(1),s.Integer(2),s.Integer(-1)),(s.Rational(3,4),1/s.sqrt(2),s.Integer(0),s.Integer(0)),(s.Rational(1,2),1/s.sqrt(2),s.Integer(0),s.Integer(0))]
    p,c,gg,ff=cases[case];ex=3*p-2;j=ex+1;b=ex/c
    AA=t**ex;aE=t**p;a=AA*aE;H=p/t;v=c/t;rE=(2*p-c*c)/t**2
    Vcoef=3*p*p-2*p+c*c/2;F=c*(1-3*p)/t**2;mu=(4*Vcoef/c**2+b*b*(2*p-c*c))/t**2
    bases=[s.eye(4)[i,:] for i in range(4)];ep,eu,epi,eU=bases
    pd=(v*eu-rE*eU)/2-H*ep
    den=(-2*k/t**(2*p)*ep-6*H*(pd+H*ep)-v*epi+v*v*ep-F*eu)/rE
    pid=-3*H*epi-(k/t**(2*p)+mu)*eu-b*rE*den+4*v*pd-2*F*ep
    Ud=-ep-b*eu-ex/t*eU
    mat=s.Matrix.vstack(pd,epi,pid,Ud)
    derivative=lambda row:(row.diff(t)+row*mat)/AA
    # Original bare-dust propagation is checked without inverse equations.
    for i,vv in enumerate(den.diff(t)+den*mat-3*pd-k/t**(2*p)*eU):ck('original Hamiltonian/dust propagation component '+str(i),vv)
    xp=[t**gg*ep]
    for order in range(3):xp.append(derivative(xp[-1]).applyfunc(s.expand))
    rows=[];targets=[]
    for valk in [1,2,3,5]:
      for spatial,radial in [(1,0),(0,1)]:
        yy=t**ff*(-spatial*(ep+b*eu)+radial*eU/aE)
        yy1=derivative(yy).applyfunc(s.expand);yy2=derivative(yy1).applyfunc(s.expand)
        cols=[spatial*xp[3]+radial*xp[2]/a,spatial*xp[2],radial*xp[1]/a,spatial*xp[1],radial*xp[0]/a,spatial*xp[0],-yy1,-yy]
        for seed in range(4):
          rows.append([s.simplify(z[seed].subs({t:1,k:valk})) for z in cols]);targets.append(s.simplify(yy2[seed].subs({t:1,k:valk})))
    design=s.Matrix(rows);rhs=s.Matrix(targets);rank=design.rank();aug=design.row_join(rhs).rank()
    dtime=lambda z:s.diff(z,t)/AA
    h=(p+ex)/(AA*t);q=ex/(AA*t);G=c*c/(ex*AA*t);R=(2*p-c*c)/(AA*AA*t*t);C=R/G;D=-2/G;E=(h-q)*D-1
    beta=ff/(AA*t);rho=gg/(AA*t);lam=t**(ff-gg);dd=lam*D;ee=lam*(E-rho*D)
    K=dtime(C)+h*C;db=C-beta-dtime(K)/K
    cc=[dd,2*dtime(dd)+ee+(h-beta+db)*dd,dtime(dd)+ee+(db-h)*dd,
       dtime(dtime(dd))+2*dtime(ee)+(dtime(h)-dtime(beta))*dd+(h-beta)*dtime(dd)+(h-beta)*ee+db*(dtime(dd)+ee+(h-beta)*dd)-K*dd,
       dtime(ee)+(db-h)*ee,dtime(dtime(ee))+(dtime(h)-dtime(beta))*ee+(h-beta)*dtime(ee)+db*(dtime(ee)+(h-beta)*ee)-K*ee,
       C+h-beta+db,dtime(C)+dtime(h)-dtime(beta)+db*(C+h-beta)]
    truth=s.Matrix([s.simplify(z.subs(t,1)) for z in cc])
    for i,rr in enumerate(design*truth-rhs):ck('calibrated original-equation design row '+str(i),rr)
    pp,zz=cc[6:];v0=h-beta
    a0=v0*v0-pp*v0+zz-dtime(h)+dtime(beta);a1=3*h-2*beta-pp
    b0=cc[2]-dtime(dd)+(2*h-beta-pp)*dd
    Lsrc=2*dtime(dd)-cc[2]+(pp-2*h)*dd;Bsrc=dd*a0+dtime(b0)+(pp+beta-2*h)*b0
    Lcom=dtime(a1)+h*a1;Bcom=dtime(a0)+2*h*a0
    ck('case redshift gain beta',2*h+(dtime(dd)-cc[1]+cc[2])/dd-beta)
    ck('case source linear C relation',cc[4]-Lsrc*C-Bsrc)
    ck('case commutator linear C relation',Lcom*C+Bcom)
    n=dtime(dd)/dd;m=pp-h-cc[2]/dd+2*n-C
    TT=dtime(C)/C+3*h-2*m;QQ=dtime(C)/C+3*h-m
    ck('case G logistic',dtime(G)-G*(TT-G))
    ck('case q reconstruction',q-QQ+G/2)
    ck('case G Raychaudhuri quadratic',2*G*G+(h-3*QQ-TT-C)*G+2*(dtime(QQ)-dtime(h)-h*QQ+QQ*QQ))
    ck('case relative gain reconstruction',lam+dd*G/2)
    recovered=None;minor=None
    if rank==8:
      ix=list(design.T.rref()[1]);select=design[ix,:];minor=s.factor(select.det());recovered=select.inv()*rhs[ix,:]
      for i in range(8):ck('extracted coefficient '+str(i),recovered[i]-truth[i])
    record={'case':case,'p':str(p),'c':str(c),'g_t_power':str(gg),'f_t_power':str(ff),'design':[[str(z) for z in row] for row in rows],'target':[str(z) for z in targets],'rank':rank,'augmented_rank':aug,'minor':str(minor),'coefficients':[str(z) for z in truth],'recovered':[str(z) for z in recovered] if recovered is not None else None,'at_t1':{n:str(s.simplify(z.subs(t,1))) for n,z in [('K',K),('C',C),('D',D),('G',G),('q',q),('R',R),('beta',beta),('Lsrc',Lsrc),('Lcom',Lcom),('Bcom',Bcom),('Q',QQ),('T',TT)]},'original_full_system_scope':'Four independent initial states, Hamiltonian-defined density propagated, original scalar/momentum/Euler; exact source-generated matter-time jets. No observed data.'}
    outcome(record)

mode=sys.argv[1]
if mode=='algebra':algebra()
elif mode=='ambiguity':ambiguity()
else:forward(int(mode))
