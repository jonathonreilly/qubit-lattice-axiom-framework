"""Independent post-exposure correspondences; no import of author functions."""
import hashlib,json
from pathlib import Path
import sympy as s
checks={}; details={}
def z(n,x):
    y=s.factor(s.cancel(s.expand(x)));checks[n]=bool(y==0)
    if y!=0:details[n]=str(y)
# Algebraic identities in independent variables; does not divide by quadratic constant.
u,A,Ap,Q,Qp,C,h,hp,D,Dp,Dpp,X0,X1,X2,Z1,Z2=s.symbols('u A Ap Q Qp C h hp D Dp Dpp X0 X1 X2 Z1 Z2')
ud=u*(A+2*u);udd=ud*(A+4*u)+u*Ap
qt=Q+u;qd=Qp+ud;G=-2*u;Gd=-2*ud
B=A-h+3*Q+C;F=Qp-hp-h*Q+Q**2;poly=4*u**2+B*u+F
p=u*D*X0
pd=(ud*D+u*Dp)*X0+u*D*X1
pdd=(udd*D+2*ud*Dp+u*Dpp)*X0+2*(ud*D+u*Dp)*X1+u*D*X2
Ft=Gd+3*(h-qt)*G-2*hp+2*qd-2*h*qt+2*qt**2
trace=2*pdd+(8*h-6*qt+G)*pd+(4*hp+6*h**2-4*qd-8*h*qt+2*qt**2+qt*G+Ft)*p+G*Z2+Ft*Z1
# Eliminate only the monic-in-u quadratic, not F or either candidate root.
qtr,rem=s.div(s.expand(trace),poly,u)
z('trace_remainder_no_constant',rem.subs(u,0))
red=s.cancel(rem/u)
z('trace_remainder_gain_independent',s.diff(red,u))
z('trace_division_free_certificate',trace-poly*qtr-u*red)
z('trace_F_zero_regular_certificate',(trace-poly*qtr-u*red).subs(Qp,hp+h*Q-Q**2))
# Differentiate original quadratic and eliminate u^2 and u^3 directly.
Bp,Fp=s.symbols('Bp Fp')
polyprime=Bp*u+Fp+(8*u+B)*ud
quot,remp=s.div(s.expand(polyprime),poly,u)
H1=Bp-A*B+B**2/s.Integer(2)-4*F;H0=Fp+(B/s.Integer(2)-2*A)*F
z('history_remainder',remp-H1*u-H0)
z('history_division_free_certificate',polyprime-quot*poly-H1*u-H0)
# Both-root exceptional identity, including F=0: no implicit nonzero F premise.
z('zero_constant_history_remainder',(remp-H1*u-H0).subs(Qp,hp+h*Q-Q**2))
# Concrete nonconstant geometry/gain coefficient relation, evaluated as exact rational
# functions at four preregistered nonsingular points. X,W are arbitrary test fields,
# so this checks the operator identity, not a full scalar/dust solution.
t,r=s.symbols('tau r');a=1+t*t;hh=s.diff(a,t)/a;cc=(2+t)/(1+t);dd=3+t*t;ee=2-t+t*t;mu=t/s.Integer(3)
kk=s.diff(cc,t)+hh*cc;kap=s.diff(kk,t)/kk
X=1+t**4+r*t**3+r*r*t;W=2+t*t*r+t*r**3
T=lambda x:s.diff(x,t);L=lambda x:T(x)+s.diff(x,r)/a
U=dd*T(X)+ee*X;N=T(W)+(hh+cc-mu)*W+L(U)+(hh-mu)*U
# Coefficients computed via conjugation of the ungained operator, a different path.
# If f=exp(t^2/6), derivatives conjugate by -mu; measured C is shifted.
gamma=kap+mu
th=[-gamma,cc-mu,2*T(cc)+hh*cc-T(mu)-gamma*(hh+cc-mu),dd,2*T(dd)+(hh-gamma-mu)*dd,T(T(dd))+(hh-gamma-mu)*T(dd)+(T(hh)-T(mu)-gamma*(hh-mu))*dd,ee,2*T(ee)+(hh-gamma-mu)*ee,T(T(ee))+(hh-gamma-mu)*T(ee)+(T(hh)-T(mu)-gamma*(hh-mu))*ee]
row=[T(W),L(W),W,L(L(T(X))),L(T(X)),T(X),L(L(X)),L(X),X]
O=L(T(W))+hh*L(W)+T(hh)*W
identity=L(N)-(mu+kap)*N+kk*W-O-sum(x*y for x,y in zip(th,row))
for i,point in enumerate([(s.Rational(1,3),s.Rational(2,5)),(s.Rational(2,3),s.Rational(3,4)),(s.Rational(4,3),s.Rational(7,5)),(s.Rational(5,3),s.Rational(9,4))]):z('nonconstant_operator_point_'+str(i),identity.subs({t:point[0],r:point[1]}))
z('mu_reconstruction',hh+th[0]-(th[4]-2*T(dd))/dd-mu)
z('C_reconstruction',th[1]+mu-cc)
z('k_reconstruction',-th[0]-mu-kap)
# Exact identification of root's eight-column notation with frozen independent proof.
d,dp,cr,p,cr0,beta=s.symbols('d dp cr p cr0 beta')
alpha=(cr-dp)/d-p+2*h
z('eight_C_gate_correspondence',dp-d*alpha-(2*dp-cr+(p-2*h)*d))
# Sign change from eight positive RHS to nine negative RHS.
z('relative_gain_sign_convention',(-u*(-d))-(-d*(-2*u)/2))
result={'scope':'Post-author-exposure distinct exact correspondence controls; not independent discovery or physical data','passed':sum(checks.values()),'failed':sum(not b for b in checks.values()),'checks':checks,'details':details,'trace_reduced_per_u':str(s.factor(red)),'trace_polynomial_quotient':str(s.factor(qtr)),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sympy':s.__version__}
print(json.dumps(result,sort_keys=True,indent=2));raise SystemExit(bool(result['failed']))
