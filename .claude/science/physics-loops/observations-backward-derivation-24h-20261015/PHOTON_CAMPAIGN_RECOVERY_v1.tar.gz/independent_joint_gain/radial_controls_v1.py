import sympy as s
import json
checks=[]
def ck(name,e,zero=True):
 v=s.factor(s.cancel(s.expand(e)));checks.append({'name':name,'pass':(v==0)==zero,'expected_zero':zero,'residual':str(v)})
C,a0,a1,U,Ur,V,Vr,l,X,c=s.symbols('C a0 a1 U Ur V Vr l X c')
K=C*C+a1*C+a0;N=-C*U-V
rad=c*(-C*Ur-Vr)-C*N-K*(U+l*X)
expected=-l*X*C*C+(V-c*Ur-a1*(U+l*X))*C-c*Vr-a0*(U+l*X)
ck('original radial residual polynomial',rad-expected)
trial,shift=s.symbols('C_trial shift',real=True)
fixed=-5*trial-s.Rational(5,2)
ck('singular power true C satisfies extra radial residual',fixed.subs(trial,-s.Rational(1,2)))
ck('singular power shifted C has declared residual',fixed.subs(trial,-1/(2-shift))-5*shift/(2*(2-shift)))
ck('singular power shifted C is rejected',fixed.subs(trial,-1/(2-shift)),False)
# Compute the same seed's radial quantities directly from original state rates.
p=s.Rational(1,2);b=-1/s.sqrt(2);v=1/s.sqrt(2);r=s.Rational(1,2);ex=-s.Rational(1,2)
P=u=pi=s.Integer(0);UE=s.Integer(1);tau=s.Integer(2);f=1;fr=0;frr=5
Pdot=(v*u-r*UE)/2-p*P;UEdot=-P-b*u-ex*UE
F=tau*P;Fp=P+tau*Pdot
Yr=-(P+b*u)*fr+UE*frr
Yrp=-(Pdot+b*pi)*fr+(UEdot-p*UE)*frr
Ur_value=Yr-Fp*fr-F*frr
V0r_value=Yrp-Fp*frr
ck('direct original seed radial U',Ur_value-5)
ck('direct original seed radial V0',V0r_value-s.Rational(5,2))
t=s.symbols('tau',positive=True);G=s.symbols('G')
Q=s.Rational(33,40)/t;T=-s.Rational(19,20)/t;C=s.Rational(12,5)/t;h=s.Rational(6,5)/t
poly=2*G*G+(h-3*Q-T-C)*G+2*(s.diff(Q,t)-s.diff(h,t)-h*Q+Q*Q)
for name,g in [('true',1/(20*t)),('pointwise_only',s.Rational(21,16)/t)]:
 ck('G quadratic root '+name,poly.subs(G,g))
 residual=s.diff(g,t)-g*(T-g)
 if name=='true':ck('true G history obeys dust-reduced Riccati',residual)
 else:
  ck('spurious G history residual exact',residual-s.Rational(2121,1280)/t**2)
  ck('spurious G history rejected',residual,False)
print(json.dumps({'checks':checks,'passed':sum(z['pass'] for z in checks),'failed':sum(not z['pass'] for z in checks),'scope':'Independent pre-author-source radial compatibility and pointwise-root/history controls'},indent=2,sort_keys=True))
raise SystemExit(any(not z['pass'] for z in checks))
