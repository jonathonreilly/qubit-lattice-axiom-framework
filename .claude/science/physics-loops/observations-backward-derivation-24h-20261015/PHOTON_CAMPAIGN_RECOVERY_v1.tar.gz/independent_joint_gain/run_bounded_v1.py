from pathlib import Path
import subprocess,sys,os,time,json,datetime,hashlib
p=Path(__file__).resolve().parent
mode=sys.argv[1]
t=time.monotonic()
try:
 r=subprocess.run([sys.executable,'-B',str(p/'independent_gain_controls_v1.py'),mode],cwd=p,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,timeout=120)
 out,err,code=r.stdout,r.stderr,r.returncode
except subprocess.TimeoutExpired as e:
 out,err,code=e.stdout or b'',e.stderr or b'',None
(p/(mode+'_attempt01.stdout.json')).write_bytes(out)
(p/(mode+'_attempt01.stderr.txt')).write_bytes(err)
record={'mode':mode,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'elapsed_seconds':time.monotonic()-t,'timeout_seconds':120,'source_sha256':hashlib.sha256((p/'independent_gain_controls_v1.py').read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()}
(p/(mode+'_attempt01.run.json')).write_text(json.dumps(record,indent=2)+'\n')
try:
 d=json.loads(out);record.update(passed=d['passed'],failed=d['failed'],rank=d['details'].get('rank'),at_t1=d['details'].get('at_t1'))
except Exception:record['error_output']=err.decode()[-2000:]
print(json.dumps(record,indent=2))
