# Full-interval closure of the Lroot=0 witness

The witness's finite Taylor computation is not its existence argument. The exact analytic ODE in `POST_EXPOSURE_DERIVATION_v1.md`, with v(1)=1,z(1)=0,aE(1)=1, has a local analytic solution. On a smaller neighborhood v>0, rE=2-v^2>0, aE>0 and b!=0. Define phi by phi_dot=v; its invertibility supplies local single-valued A(phi),V(phi). Take rho=aE^-3, A=rE aE^3 and V=3H^2-v^2/2-rE. Then bare dust conservation, Einstein dust transport, Raychaudhuri and Friedmann hold identically. The scalar equation follows by differentiation with v!=0. These are exact functions on a neighborhood, not a Taylor-polynomial action used outside its truncation order.

For arbitrary regular backgrounds, put r=rE and

    H_dot=-(v^2+r)/2, v_dot=-3Hv-F,
    r_dot=(-3H+bv)r, F_dot=mu v-3Hbr,
    aE_dot=HaE, A_dot=bvA.

The reconstructed potential obeys V_phi=F-br. The fixed-density action curvature is

    V_phiphi+rho A_phiphi = (F_dot+3Hbr)/v = mu,

including variable b. Thus the scalar mass used in the forward generator is the action response and has not been inserted as an unrelated parameter.

Use the original Einstein momentum, scalar, Euler and bare-dust continuity equations. With the Hamiltonian residual

    E=-2k^2P/aE^2-6H(P_dot+HP)-r delta-v zeta+v^2P-Fw,

direct generic differentiation gives E_dot+3HE=0. The Einstein pressure equation follows from differentiated momentum, Euler and these background identities. Solving E=0 for delta with r>0 therefore gives a four-state linear Cauchy system whose solutions satisfy every original linear scalar, dust and Einstein equation over the neighborhood. This is proved without assuming constant b; `general_action_closure_v1.py` checks the exact algebra with arbitrary b_dot. The regular radial Helmholtz ODE supplies the angular l>=2 spatial factors on an annulus, without origin or infinity conditions.

For the special background, C=S/A with S=-2z/v+6H/v^2-3H, so A^2K=S_dot+HS. Its defining ODE sets this equal to 9 identically. Consequently K=9/A^2 is nonzero and Lroot=-K'/K-2q=0 identically. The exact nonzero minors at t=r=1 establish both rank conditions on a smaller neighborhood by continuity. Small common perturbation amplitude preserves those ranks. The evidence concerns local analytic classical solutions, not a measured spectrum, global extension, nonlinear stability or a realized cosmology.
