# Refinement of the post-exposure comparison

The extra exact calculations do not establish that one complete observable rank hypothesis dominates the other.

The eight- and nine-column matrices can differ in rank for a specified angular design at one epoch. The p=2 fixed-l example has root rank eight and independent rank eight at one radius, but exact radial derivative rows restore independent rank nine. It is therefore **not** a counterexample to rank nine on an open annulus. Conversely, restricting every selected mode's scalar velocity perturbation to zero at one epoch yields independent rank nine and root rank six. The original scalar ODE does not preserve this restriction, so this is **not** a counterexample to interval-wide root identification. The complete numerical entries and actual failed first implementation are preserved. No broader incomparability theorem is asserted.

The local analytic witness in `POST_EXPOSURE_DERIVATION_v1.md` has Lroot=0 identically and both designs full rank: exact minors 2781/2 (nine) and 9/16 (eight). The analytic background ODE, rather than finitely many zero jets, proves Lroot=0 on a neighborhood. Exact jets verify the construction and produce actual original-equation perturbation solutions there. Nonzero minors and the regular chart persist on a sufficiently small neighborhood.

This witness shows that the nine-column uniqueness proof needs no extra nonzero Lroot assumption, but does **not** show that all eight-column coefficients fail to identify the background. In fact a coefficient not used in the root's stated quadratic count supplies another conditional linear extraction. Let

    T=D'/D+Q-h+1/D,
    B=(D'/D)(h-Q)+h'-Q'+(p-2h)(h-Q-1/D),
    H1=z-h'-ph+h^2.

The relation E=D(h-Q+C)-1, the cr0 equation and dust transport give

    cr0/D = -3C^2+(2D'/D+3Q-6h+p+1/D)C+B.

Using the root's first quadratic cancels C^2 exactly:

    T C = cr0/D-B-H1.

Hence T nonzero at any epoch is another sufficient uniqueness condition for the eight-column data. This is an attributed, post-exposure algebraic consequence of the root route, not an independent prior discovery or a proposed replacement of the full residual checks.

At the Lroot=0 witness's t=1, D=-12,D'/D=11/2,h=8,h'=-52,Q=12,Q'=-78,p=32,z=161,cr0=-226. The common two quadratics have roots C=6 and 7/6. Both satisfy positive R and qG at that epoch. But T=113/12 and cr0 rejects C=7/6, retaining C=6. This explicitly prevents misreading the conservative two-root bound as an established physical ambiguity. The construction has not proved that either Lroot or T must be nonzero for every rank-eight physical field. The root's stated at-most-two bound remains correct; no claim of sharpness is warranted.

The nine-column route directly extracts c,d,e under its own full-rank hypothesis; the root route uses one fewer column and only first radial derivatives but third time derivatives. It gives the stated finite bound, with uniqueness under Lroot!=0 or the additional T!=0 condition above. Their exact information ordering on all open-strip compatible solutions is left unproved. Both require full original action residuals, ideal registration, the equal-potential/full-sky sector, and the same normalization and action-domain qualifications. This comparison includes no gain extension or empirical claim.
