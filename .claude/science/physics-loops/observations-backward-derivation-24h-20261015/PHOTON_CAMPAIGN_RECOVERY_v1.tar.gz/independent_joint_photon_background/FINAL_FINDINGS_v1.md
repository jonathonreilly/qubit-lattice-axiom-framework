# Focused joint photon/background comparison

The corrected root v2 equations and stated at-most-two background-history bound survive this focused check. The independent nine-column route and root eight-column route enforce different parts of the same hidden-potential compatibility system. The nine-column route directly gives uniqueness under its own rank hypothesis. The complete eight-column data can also give uniqueness beyond the root's stated nonzero-linear-denominator condition; an additional coefficient supplies the explicit condition below. Neither an actual two-history ambiguity nor a general ordering of the complete rank hypotheses has been proved.

This is a source-bound mathematical check, not a formal audit, empirical test, novelty claim, or replacement of root authorship. Gains were excluded.

## Source identity and independence

The independent derivation was frozen before code at 2026-10-16 12:26:57 UTC. Its completed proof, programs, failures and results were frozen at 12:41:13 UTC; root-source exposure began at 12:42:28 UTC. All 30 pre-exposure file bindings remain unchanged. The independent freeze SHA256 is `1a9dbc000a7e0795c5832b832a7d6ac858cfb4feb21cfcba445df3ce79216b1e`. The known action note used before exposure has SHA256 `1e3b1dbdd0f42ebee7a66ce6fd27aeb0c5702baa594438654b564a05f05f8c63`.

The complete authorized root note and both complete programs were read after that freeze. Copied snapshots and current originals match these exact SHA256 identities:

| Root artifact | SHA256 |
|---|---|
| `JOINT_PHOTON_BACKGROUND_DERIVATION_v2.md` | `5edd2ce26ac8ac2aa9e68036c4e5790566c2318d2c6e1f81c07e96a3097eb076` |
| `check_joint_photon_background_v2.py` | `b29bdd28f89eda3be419957f340f56d4d7c448adf8b9b66ebe777ad61e74dce6` |
| `JOINT_PHOTON_BACKGROUND_CONTROLS_v2.json` | `8884d3ca449306951e8e879d83060af651126f9f8454535cd0901bdcf041df39` |
| `check_joint_photon_background_full_residuals_v1.py` | `7e627ecadd46aaac3d65b275312dc86795a7187a1841be5fec8479ddc6ad0d44` |
| `JOINT_PHOTON_BACKGROUND_FULL_RESIDUALS_v1.json` | `7e8970be263556aafc9bb9ef439cb815028b136ba88f1bbe8658d4b9a1c79050` |

`FINAL_BINDING_CHECK_v2.json` records the final drift check; v1 is preserved. The root's earlier v1 coefficient failure is described in its v2 note; this check did not read or replay the historical v1 files. The source error is repaired in the reviewed v2 expansion.

## Exact mathematical relationship

Use the independent c,d,e,U,N and characteristic operator L, with K=c'+hc and k=K'/K. Root C=c,D=-d,E=-e,F=-U,N_root=-N. The root equation, after reversing overall sign, is

    A8=(partial_tau+c-k)N-KU=0.

The independent equation is

    A9=(L-k)N+KY=0.

For Zrec=-N/K, these are respectively -K times its temporal momentum/Euler equation and -K times its photon characteristic equation. Their difference is the radial compatibility equation. Thus one is not simply a column-basis change of the other, and neither alone proves physical existence. Both require all original scalar, dust and Einstein residuals after reconstruction.

The complete corrected eight-column coefficient expansion, its Q=q+C relation, both quadratic polynomials and their difference check exactly. Rank eight excludes K=0. Where extracted D is nonzero, the dust Riccati equation has unique local evolution from C at one epoch. Its first polynomial has leading coefficient 3, giving at most two initial C values and therefore at most two regular C histories. Nonzero root Lroot=p-h-2Q at any epoch makes the surviving history unique. This bound does not establish that two full-action histories exist.

The independent rank-nine coefficients directly identify c,d,e, hence G,R,q and the remaining background modulo the stated normalization/orientation freedoms. Rank nine also excludes K=0. Its full original-equation power fixture attains rank nine, with exact minor 1236; the separately checked single-field angular superposition preserves that rank. The K=0 fixture has rank eight. A continuous positive-dust zero-record family shows why no unconditional identification follows without informative fields.

## What the post-exposure controls add

A local analytic positive-dust action has Lroot=0 identically, K!=0, and both full ranks. It is constructed from H=3-t, v=phi_dot, rE=2-v^2, A=rE aE^3 and a smooth ODE imposing A^2K=9. Its original-equation perturbation rows give exact minors 2781/2 (nine) and 9/16 (eight). Local analyticity, regularity and nonzero minors extend the fixture to a neighborhood; this is not arbitrary observable jet fitting. Details and exact Taylor evidence are in `POST_EXPOSURE_DERIVATION_v1.md` and `zero_denominator_attempt01.stdout.json`. `ANALYTIC_WITNESS_CLOSURE_v1.md` supplies the full-interval action argument, with generic Hamiltonian propagation, pressure and dust continuity checked for arbitrary coupling derivative; the fixture does not rely on finitely many zero Taylor coefficients as its existence proof.

Crucially, that witness does not show the full eight-column data are weaker. The root cr0 coefficient supplies another sufficient condition. Define

    T=D'/D+Q-h+1/D,
    B=(D'/D)(h-Q)+h'-Q'+(p-2h)(h-Q-1/D),
    H1=z-h'-ph+h^2.

Then dust transport, cr0 and the first quadratic imply exactly

    T C = cr0/D-B-H1.

Thus T nonzero at any epoch also gives unique C evolution. This is explicitly a post-exposure consequence of root's route. At the Lroot=0 witness, the common quadratics have two initially positive-chart roots C=6 and 7/6, but T=113/12 and cr0 rejects 7/6. No correction to the conservative two-history upper bound is needed; interpreting it as an attained physical ambiguity would be unjustified.

The fixed-radius rank comparisons also require qualification. One physical angular design gives root rank eight and independent rank eight, but additional radial information restores independent rank nine (minor -480). A different design has rank nine versus six at an epoch with zero scalar-velocity perturbations; that restriction is not time-invariant. These are useful sampling limits, not a proof of interval-wide incomparability. `COMPARISON_REFINEMENT_v1.md` gives the precise conclusions. The nine-column method provides direct uniqueness with more spatial derivatives; the eight-column method uses fewer columns and first radial derivatives, with the correct finite bound and additional uniqueness tests. No general dominance theorem is asserted.

## Executed evidence and limitations

| Execution | Actual result | Interpretation |
|---|---:|---|
| Independent frozen p=2 fixture | 34/0 | Full original-equation rank-nine witness |
| Independent frozen K=0 fixture | 32/0 | Exceptional-chart rank loss; shares common controls with p=2 |
| Independent single-field assembly | 6/0 | Physical angular-superposition rank |
| Post-exposure operator/background algebra | 10/0 | Root correspondence, not a second pre-exposure discovery |
| Post-exposure compact rank comparison | 6/0 | Qualified sampling distinctions |
| Post-exposure analytic Lroot=0 action | 43/0 | Full-equation local witness and exact jet checks |
| Post-exposure unused-coefficient algebra | 9/0 | Additional T condition and rejection of the extra quadratic root |
| Post-exposure generic action closure | 7/0 | Full-interval constraint propagation with variable coupling |
| Unchanged copied root primary | 46/0 | Byte-identical stdout to supplied root receipt |
| Unchanged copied root full-residual runner | 81/0 | Byte-identical stdout to supplied root receipt |

These counts are controls, not independent experiments or empirical validations. Python/SymPy are shared software. No author code was imported by the independent calculations. Root replays are explicitly copied replays. Primary read closure is its own bytes plus the copied derivation; the full-residual runner reads its own bytes. Independent calculators read no repository scientific inputs at runtime except the explicitly declared single-field assembly receipt; wrappers bind their literal local input lists. No network, data, Git or author-file writes were used.

Every executed child was capped at 120 seconds with bytecode disabled, including root copies whose unchanged metadata says 180. Two pre-exposure combined runs and one post-exposure generic rank run actually timed out. Their complete available stdout/stderr and resource records remain intact; empty stdout is not described as a successful run. The underlying symbolic performance cause is unproved. Split completed calculations preserve the physical hypotheses and thresholds. `POST_EXPOSURE_FAILURE_RECOVERY_v1.json` records the later recovery and lossless source-change serialization. All 20 Python sources parse; no bytecode directories were created.

The scripts are portable with this evidence folder intact: wrappers resolve files relative to themselves and accept fresh attempt names. For example, `python3 -B run_comparison_bounded_v1.py --case author_primary --attempt fresh_primary` replays the copied primary under the bound. Historical run records retain original absolute paths as provenance.

The surviving obligations are ideal registration and sufficient derivatives, the same universal action and dust species, positive density and the nonzero regular chart, recovered equal-Einstein-potential or full-sky l>=2 sector, physical source compatibility, and normalization/calibration. The reconstructed curvature is a fixed-density response, not automatically a measured pole. A0, scalar origin/reflection, off-trajectory action extensions, finite noisy inference, boundary/global histories and empirical scale selection remain outside this result. Before using either extraction on a proposed field, verify its actual observable rank and every original residual. No present calculation supplies observed input functions or selects a realized background.
