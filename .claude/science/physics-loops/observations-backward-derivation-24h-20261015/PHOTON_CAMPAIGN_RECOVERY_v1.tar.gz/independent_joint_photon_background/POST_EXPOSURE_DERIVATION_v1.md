# Post-exposure comparison plan and derivation

This supplement follows the independent output freeze. It uses the exposed root eight-column equation; that equation is not claimed as independently originated. Its purpose is to compare the two routes, not to select a background or use observations. The five authorized root files are bound in `AUTHOR_SNAPSHOT_v2.json`.

Write the independently frozen symbols as c,d,e,U=dP'+eP,N and L=partial_tau+a^-1 partial_r. The exact correspondence is root C=c,D=-d,E=-e,F=-U,N_root=-N. Put K=c'+hc and k=K'/K. The root elimination, with overall sign reversed, is

    A8=(partial_tau+c-k)N-KU=0.

The independent elimination is

    A9=(L-k)N+KY=0.

For Zrec=-N/K, A8=-K(Zrec'+cZrec+U) and A9=-K(LZrec-Y). Their difference is

    A9-A8=(a^-1 partial_r-c)N+K(Y+U).

Thus these are complementary temporal and characteristic compatibility conditions. They are not the same coefficient extraction written in a different column basis. A candidate passing only one elimination still needs the other and all original action equations.

Expanding A8 gives the exposed root coefficients including 2E' in c1. With D!=0, root Q=q+C. Substitution of dust transport C'=C(D'/D+2Q-3h-2C) into the z coefficient gives its first quadratic with leading coefficient 3. Substitution in Raychaudhuri gives the second, also leading coefficient 3. Their difference is the displayed linear expression with coefficient Lroot=p-h-2Q=-K'/K-2q. Therefore smooth Riccati evolution gives at most two C histories from one epoch, and at most one if Lroot is nonzero at any epoch on the connected regular interval. Two algebraic roots do not prove two full-action histories exist. Rank eight itself excludes K=0 by the nontrivial N_root=0 column relation.

The independent rank-nine condition instead reads c,d,e directly from three extracted coefficients and gives at most one regular background without imposing Lroot!=0. Both retain A0, field origin/reflection, unobserved extensions and every source-compatibility test.

## Decisive post-exposure tests fixed before their execution

Use the independently frozen positive-dust p=2 power background and its original-equation four-state generator, not root code. At t=r=1 compare the exact two designs on these full-solution seeds:

1. Fix k^2=1,l=4; take four state basis seeds times (B,B_r)=(1,0),(0,1). Assign the eight rows distinct real harmonics in the nine-dimensional l=4 space. Root rank can be eight, whereas the nine-column design has at most eight rows. This is one physical field and remains bounded by eight angular components at each radius/epoch. It is a rank separation at the stated epoch and fixed-radius angular design, not yet a claim about every possible spatial sampling design on the whole annulus.
2. Fix k^2=1 and set the scalar velocity perturbation zeta=0 at the test epoch. Take 36 modes l=2+i, with state basis P,w,U cycling and the two radial seeds cycling every three modes. The root first-radial design spans at most six state/radial combinations; the independent second-radial design also senses l(l+1) and may reach nine. This likewise concerns the specified epoch/design. No rank away from that epoch is assumed before calculation.

A separate optional local analytic background tests whether Lroot=0 can coexist with the nine-column criterion. In Einstein time take H=3-t, v=phi_dot>0, rE=2-v^2>0, aE_dot=HaE, A=rE aE^3, and V=3H^2+v^2/2-2. Let z=v_dot and impose

    z_dot=(v/2)[2z^2/v^2+6Hdot/v^2-12Hz/v^3-3Hdot
                       -2Hz/v+6H^2/v^2-3H^2-9], Hdot=-1.

At t=1 choose v=1,z=0,aE=1. This smooth analytic ODE has a local solution with positive dust and nonzero coupling. It sets T=A^2K=9 identically because, for S=-2z/v+6H/v^2-3H, T=Sdot+HS. Hence Lroot=-(Tdot)/(AT)=0 identically and K!=0. At t=1, A=1,b=6,h=8,x=1,G=1/6,R=1,c=6,d=12,e=25,K=9. Dust, Raychaudhuri and Friedmann are enforced by construction; differentiating Friedmann with v!=0 gives the original scalar equation. Only ODE-generated background jets may be used. This is an existence construction of a local action, not an apparatus or history selection. If its symbolic computation exceeds 120 seconds, preserve the attempt and leave the executable qualification unresolved rather than changing the hypothesis.

All added tests are post-exposure correspondence checks and share Python/SymPy with the original independent programs. Replays of root scripts are copied replays, not independent evidence. Every owned child is capped at 120 seconds, including unchanged root programs whose own metadata says 180 seconds. Gains are outside this comparison.
