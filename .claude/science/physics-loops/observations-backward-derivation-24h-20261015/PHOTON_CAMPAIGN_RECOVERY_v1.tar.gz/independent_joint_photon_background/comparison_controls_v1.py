"""Post-exposure comparison; original-equation generator from independent freeze."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json,sys,time
import sympy as s
checks=[];details={};start=time.monotonic()
def simp(e):return s.factor(s.cancel(s.expand(e)))
def zero(name,e):
    value=simp(e);passed=value==0
    checks.append({'name':name,'pass':passed,'residual':str(value)})
    print(('PASS ' if passed else 'FAIL ')+name,file=sys.stderr,flush=True)
def ok(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
    print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
mode=sys.argv[1]
if mode=='algebra':
    t,r=s.symbols('tau r',positive=True)
    a=s.Function('a')(t);h=s.diff(a,t)/a
    c,d,e=[s.Function(k)(t) for k in ('c','d','e')]
    P,Y,Z=[s.Function(k)(t,r) for k in ('P','Y','Z')]
    L=lambda f:s.diff(f,t)+s.diff(f,r)/a
    K=s.diff(c,t)+h*c;k=s.diff(K,t)/K
    U=d*s.diff(P,t)+e*P;N=s.diff(Y,t)+(h+c)*Y+L(U)+h*U
    A8=s.diff(N,t)+(c-k)*N-K*U;A9=L(N)-k*N+K*Y
    zero('operator difference is radial compatibility',A9-A8-s.diff(N,r)/a+c*N-K*(Y+U))
    Zrec=-N/K
    zero('eight-column residual reconstructs temporal equation',A8+K*(s.diff(Zrec,t)+c*Zrec+U))
    zero('nine-column residual reconstructs characteristic equation',A9+K*(L(Zrec)-Y))
    C,D,E=c,-d,-e;delta=C-k
    coeff=[D,2*s.diff(D,t)+E+(h+delta)*D,
           s.diff(D,t)+E+(delta-h)*D,
           s.diff(D,t,2)+2*s.diff(E,t)+s.diff(h,t)*D+h*s.diff(D,t)+h*E+delta*(s.diff(D,t)+E+h*D)-K*D,
           s.diff(E,t)+(delta-h)*E,
           s.diff(E,t,2)+s.diff(h,t)*E+h*s.diff(E,t)+delta*(s.diff(E,t)+h*E)-K*E,
           C+h+delta,s.diff(C,t)+s.diff(h,t)+delta*(C+h)]
    row=[s.diff(P,t,3)+s.diff(P,t,2,r)/a,s.diff(P,t,2),s.diff(P,t,r)/a,
         s.diff(P,t),s.diff(P,r)/a,P,-s.diff(Y,t),-Y]
    zero('complete root coefficient expansion',A8+s.Add(*[u*v for u,v in zip(coeff,row)])-s.diff(Y,t,2))
    zero('coefficient first consistency',coeff[1]-coeff[2]-s.diff(D,t)-2*h*D)
    Q=simp(coeff[6]-h-(coeff[2]-s.diff(D,t)+1)/D)
    zero('observed Q equals q plus C',Q-(h-(e-1)/d+c))
    zero('root linear denominator equals minus logarithmic A squared K derivative',coeff[6]-h-2*Q+k+2*(h-(e-1)/d))
    # Independent algebraic reduction of the two background equations.
    C,D,Q,h,p,z,Dp,qp,hp,Cp=s.symbols('C D Q h p z Dp Qp hp Cp')
    dust=C*(Dp/D+2*Q-3*h-2*C)
    delta=p-C-h
    eq_z=z-Cp-hp-delta*(C+h)
    poly1=3*C*C+(5*h-p-Dp/D-2*Q)*C+z-hp-p*h+h*h
    zero('dust and z give first quadratic',eq_z.subs(Cp,dust)-poly1)
    q=Q-C;ell=h-q;G=-2/D;R=-2*C/D;x2=q*G
    ray=R+2*(hp-qp+Cp)+2*q*ell+x2
    poly2=3*C*C+(4*h-4*Q-Dp/D)*C+qp-hp-h*Q+Q*Q+Q/D
    zero('dust and Raychaudhuri give second quadratic',-ray.subs(Cp,dust)/2-poly2)
    zero('quadratic difference is root linear relation',poly2-poly1-(p-h-2*Q)*C-(qp-h*Q+Q*Q+Q/D-z+p*h-h*h))
elif mode=='ranks':
    t,r=s.symbols('t r',positive=True);k2,l=s.symbols('k2 l',real=True)
    p,w,z,u,B,Br=s.symbols('P w zeta U B Br',real=True);states=[p,w,z,u]
    aE=t**2;A=t**4;a=t**6;H=2/t;v=1/t;rho=3/t**6;rr=3/t**2
    V=s.Rational(17,2)/t**2;alpha=s.Integer(4);F=-5/t**2;mu=82/t**2
    h=6/t**5;c=12/t**5;d=8*t**5;e=s.Integer(17);K=12/t**10
    fp=(v*w-rr*u)/2-H*p;fu=-p-alpha*w-alpha*v*u
    density=simp((-2*k2*p/aE**2-6*H*(fp+H*p)-v*z+v*v*p-F*w)/rr)
    fz=simp(-3*H*z-(k2/aE**2+mu)*w+4*v*fp-2*F*p-alpha*rr*density)
    rhs=[fp,z,fz,fu]
    D=lambda f:simp(s.diff(f,t)+sum(s.diff(f,xi)*fi for xi,fi in zip(states,rhs)))
    DT=lambda f:simp(D(f)/A)
    DR=lambda f:simp(s.diff(f,r)+s.diff(f,B)*Br+s.diff(f,Br)*(-2*Br/r-(k2-l*(l+1)/r**2)*B))
    L=lambda f:simp(DT(f)+DR(f)/a)
    zero('p2 full dust continuity',D(density)-3*D(p)-k2*u/aE**2)
    zero('p2 full Einstein pressure',2*(D(D(p))+4*H*D(p)+(2*s.diff(H,t)+3*H*H)*p)-v*z+v*v*p+s.diff(V,t)*t*w)
    zero('p2 original scalar',D(z)+3*H*z+(k2/aE**2+mu)*w+alpha*rr*density-4*v*D(p)+2*F*p)
    P=p*B;Y=-(p+alpha*w)*B+u*Br/aE;Z=A*u*B
    zero('p2 temporal momentum',DT(Z)+c*Z+d*DT(P)+e*P)
    zero('p2 characteristic equation',L(Z)-Y)
    cols9=[DT(Y),L(Y),Y,L(L(DT(P))),L(DT(P)),DT(P),L(L(P)),L(P),P]
    cols8=[DT(DT(DT(P)))+DR(DT(DT(P)))/a,DT(DT(P)),DR(DT(P))/a,DT(P),DR(P)/a,P,-DT(Y),-Y]
    base9=[simp(f.subs({t:1,r:1,k2:1})) for f in cols9]
    base8=[simp(f.subs({t:1,r:1,k2:1})) for f in cols8]
    def record(label,seeds):
        rows9=[];rows8=[]
        for seed in seeds:
            sub=dict(zip(states,seed['state']));sub.update({l:seed['l'],B:seed['B'],Br:seed['Br']})
            rows9.append([f.subs(sub) for f in base9]);rows8.append([f.subs(sub) for f in base8])
        M9=s.Matrix(rows9);M8=s.Matrix(rows8)
        data={'seeds':seeds,'rank9':M9.rank(),'rank8':M8.rank(),
              'design9':[[str(v0) for v0 in row] for row in rows9],
              'design8':[[str(v0) for v0 in row] for row in rows8]}
        for nm,M in [('nine',M9),('eight',M8)]:
            if M.rank()==M.cols:
                ids=list(M.T.rref()[1]);det=s.factor(M[ids,:].det())
                data[nm+'_selected_rows']=ids;data[nm+'_determinant']=str(det)
            else:data[nm+'_nullspace']=[[str(v0) for v0 in vec] for vec in M.nullspace()]
        details[label]=data
        return M9,M8
    seeds=[{'l':4,'state':[int(ii==jj) for ii in range(4)],'B':int(rad==0),'Br':int(rad==1)} for rad in range(2) for jj in range(4)]
    M9,M8=record('fixed_radius_fixed_l_all_eight_seeds',seeds)
    ok('fixed radius angular design root rank eight',M8.rank()==8)
    ok('same eight angular components cannot give rank nine',M9.rank()<9)
    # Test whether radial information restores rank nine; use exact radial jets.
    extended=s.Matrix(list(M9.tolist()))
    radialrows=[]
    for seed in seeds:
        sub=dict(zip(states,seed['state']));sub.update({t:1,r:1,k2:1,l:4,B:seed['B'],Br:seed['Br']})
        radialrows.append([simp(DR(f).subs(sub)) for f in cols9])
    ext=extended.col_join(s.Matrix(radialrows))
    details['fixed_l_with_radial_derivative_rows']={'rank9':ext.rank(),'rows':[[str(v0) for v0 in row] for row in radialrows]}
    ok('fixed-l angular-only rank deficiency is not an open-annulus counterexample',ext.rank()==9)
    seeds=[]
    for ii in range(36):
        jj=[0,1,3][ii%3]
        seeds.append({'l':ii+2,'state':[int(vv==jj) for vv in range(4)],'B':int((ii//3)%2==0),'Br':int((ii//3)%2==1)})
    M9,M8=record('vanishing_zeta_test_epoch',seeds)
    ok('vanishing-zeta epoch nine-column rank full',M9.rank()==9,{'actual':M9.rank()})
    ok('vanishing-zeta epoch eight-column rank six',M8.rank()==6,{'actual':M8.rank()})
    # Temporal derivatives are not extra same-epoch design rows; inspect only
    # whether the exceptional restriction is preserved by the original ODE.
    ok('zeta-zero restriction not invariant for all selected states',simp(fz.subs({t:1,k2:1,z:0}))!=0)
else:raise ValueError('Choose algebra or ranks')
out={'stage':'Post-exposure comparison, own generator; no author imports','software':{'python':sys.version.split()[0],'sympy':s.__version__},'checks':checks,'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},'details':details,'wall_seconds':time.monotonic()-start}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
