"""Post-exposure rank comparison, split exact matrix algebra after real timeout."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import json,sys,time
import sympy as s
from sympy.polys.matrices import DomainMatrix
from sympy.polys.domains import QQ
start=time.monotonic();checks=[];details={}
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
    print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
def rank(M):return DomainMatrix.from_Matrix(M).convert_to(QQ).rank()
def pivots(M):return list(DomainMatrix.from_Matrix(M).convert_to(QQ).rref()[1])
t,r=s.symbols('t r',positive=True);ll,B,Br=s.symbols('l B Br',real=True)
# p=2 Einstein-time generator rederived directly from momentum, scalar,
# Hamiltonian and Euler, with k_com^2=1 fixed. Same physical fixture as freeze.
M=s.Matrix([[-2/t,1/(2*t),0,-3/(2*t**2)],
            [0,0,1,0],
            [-2/t**2+8/t**4,-76/t**2-1/t**4,-2/t,-78/t**3],
            [-1,-4,0,-4/t]])
def DT(row):return (row.diff(t)+row*M).applyfunc(lambda x:s.cancel(x/t**4))
p=s.Matrix([[1,0,0,0]]);w=s.Matrix([[0,1,0,0]]);u=s.Matrix([[0,0,0,1]])
p1=DT(p);p2=DT(p1);p3=DT(p2)
yB=-p-4*w;yR=u/t**2;y1B=DT(yB);y1R=DT(yR)
p,p1,p2,p3,yB,yR,y1B,y1R=[row.subs(t,1) for row in [p,p1,p2,p3,yB,yR,y1B,y1R]]
Brr=-2*Br/r-(1-ll*(ll+1)/r**2)*B
Y=yB*B+yR*Br;Yp=y1B*B+y1R*Br
LY=Yp+yB*Br+yR*Brr
LP=p1*B+p*Br;LPp=p2*B+p1*Br
L2P=p2*B+(2*p1-6*p)*Br+p*Brr
L2Pp=p3*B+(2*p2-6*p1)*Br+p1*Brr
cols9=[Yp,LY,Y,L2Pp,LPp,p1*B,L2P,LP,p*B]
cols8=[p3*B+p2*Br,p2*B,p1*Br,p1*B,p*Br,p*B,-Yp,-Y]
def dR(row):return row.diff(r)+row.diff(B)*Br+row.diff(Br)*Brr
drcols9=[dR(row) for row in cols9]
def rows_at(columns,seeds):
    rows=[]
    for seed in seeds:
        sub={r:1,ll:seed['l'],B:seed['B'],Br:seed['Br']}
        rows.append([s.cancel(row[seed['state_basis']].subs(sub)) for row in columns])
    return s.Matrix(rows)
def summarize(M):
    rr=rank(M);out={'rank':rr,'rows':[[str(x) for x in row] for row in M.tolist()]}
    if rr==M.cols:
        ids=pivots(M.T);out.update({'selected_rows':ids,'determinant':str(M[ids,:].det(method='domain-ge'))})
    return out
seeds=[{'l':4,'B':int(rad==0),'Br':int(rad==1),'state_basis':ii} for rad in range(2) for ii in range(4)]
M9=rows_at(cols9,seeds);M8=rows_at(cols8,seeds);MR=rows_at(drcols9,seeds)
details['fixed_radius_fixed_l']={'seeds':seeds,'nine':summarize(M9),'eight':summarize(M8)}
check('fixed radius root rank eight',rank(M8)==8)
check('fixed radius nine-column rank deficient',rank(M9)<9,{'rank':rank(M9)})
extended=M9.col_join(MR)
details['same_field_with_radial_derivative_rows']={'nine':summarize(extended)}
check('radial information restores nine-column rank',rank(extended)==9,{'rank':rank(extended)})
seeds=[{'l':ii+2,'B':int((ii//3)%2==0),'Br':int((ii//3)%2==1),'state_basis':[0,1,3][ii%3]} for ii in range(36)]
M9=rows_at(cols9,seeds);M8=rows_at(cols8,seeds)
details['vanishing_zeta_epoch']={'seeds':seeds,'nine':summarize(M9),'eight':summarize(M8)}
check('zeta-zero epoch nine-column rank nine',rank(M9)==9,{'rank':rank(M9)})
check('zeta-zero epoch eight-column rank six',rank(M8)==6,{'rank':rank(M8)})
# The root columns still occupy at most six radial/state functions at this epoch
# throughout the annulus for the stipulated zeta=0 and common k^2. This is not
# an invariant time restriction; it cannot prove interval-wide rank deficiency.
check('zeta-zero restriction is not invariant',M[2,0].subs(t,1)!=0)
details['original_equation_time_rows_at_t1']={'P_tau':[str(x) for x in p1],'P_tautau':[str(x) for x in p2],'P_tautautau':[str(x) for x in p3]}
print(json.dumps({'stage':'Post-exposure correspondence; preserved earlier timeout','software':{'python':sys.version.split()[0],'sympy':s.__version__},'checks':checks,'summary':{'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)},'details':details,'wall_seconds':time.monotonic()-start},indent=2))
raise SystemExit(int(any(not x['pass'] for x in checks)))
