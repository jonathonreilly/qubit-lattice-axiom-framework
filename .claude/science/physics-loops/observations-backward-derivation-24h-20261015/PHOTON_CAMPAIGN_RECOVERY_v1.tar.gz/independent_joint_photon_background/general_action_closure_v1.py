"""Full-interval action/constraint closure for the analytic Lroot=0 fixture."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import json
import sympy as s
checks=[]
def zero(name,e):
    z=s.factor(s.cancel(s.expand(e)));checks.append({'name':name,'pass':z==0,'residual':str(z)})
H,v,r,F,b,mu,a,A,bd,k2=s.symbols('H v r F b mu a A b_dot k2',nonzero=True)
p,w,z,u,delta=s.symbols('P w zeta U delta')
Hp=-(v*v+r)/2;vp=-3*H*v-F;rp=(-3*H+b*v)*r;Fp=mu*v-3*H*b*r
background={H:Hp,v:vp,r:rp,F:Fp,b:bd,a:H*a,A:b*v*A}
DB=lambda f:s.expand(sum(s.diff(f,xx)*ff for xx,ff in background.items()))
V=3*H*H-v*v/2-r
zero('reconstructed potential gradient is F minus b r',DB(V)/v-(F-b*r))
zero('action fixed-density curvature equals stipulated mu',DB(F-b*r)/v+(r/A)*DB(b*A)/v-mu)
zero('bare density conservation',DB(r/A)+3*H*r/A)
fp=(v*w-r*u)/2-H*p;fu=-p-b*w-b*v*u
fz=-3*H*z-(k2/a**2+mu)*w+4*v*fp-2*F*p-b*r*delta
fd=3*fp+k2*u/a**2
state5={p:fp,w:z,z:fz,u:fu,delta:fd}
D5=lambda f:s.expand(DB(f)+sum(s.diff(f,xx)*ff for xx,ff in state5.items()))
constraint=-2*k2*p/a**2-6*H*(fp+H*p)-r*delta-v*z+v*v*p-F*w
zero('generic full Hamiltonian constraint propagation',D5(constraint)+3*H*constraint)
zero('generic Einstein pressure from momentum and Euler',2*(D5(fp)+4*H*fp+(2*Hp+3*H*H)*p)-v*z+v*v*p+(F-b*r)*w)
recovered_delta=s.solve(constraint,delta)[0]
state4={p:fp,w:z,z:fz.subs(delta,recovered_delta),u:fu}
D4=lambda f:s.expand(DB(f)+sum(s.diff(f,xx)*ff for xx,ff in state4.items()))
zero('generic reduced density satisfies original continuity',D4(recovered_delta)-3*fp-k2*u/a**2)
zero('generic reconstructed Hamiltonian',constraint.subs(delta,recovered_delta))
out={'stage':'Post-exposure full-interval closure of the original-equation generator','checks':checks,'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},'scope':'Generic algebra with background equations, arbitrary b_dot, positive nonzero dust and nonzero scalar speed on the physical chart','sympy':s.__version__}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
