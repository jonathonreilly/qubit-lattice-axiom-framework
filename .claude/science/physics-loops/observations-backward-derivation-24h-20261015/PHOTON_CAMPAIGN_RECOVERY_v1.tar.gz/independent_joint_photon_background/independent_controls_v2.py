"""Independent joint photon/background controls; no new author source reads."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json,sys,time
import sympy as s
checks=[];details={}
def simp(e):return s.factor(s.cancel(s.expand(e)))
def zero(name,e):
    value=simp(e);passed=value==0
    checks.append({"name":name,"pass":passed,"residual":str(value)})
    print(("PASS " if passed else "FAIL ")+name,file=sys.stderr,flush=True)
def ok(name,value,detail=None):
    checks.append({"name":name,"pass":bool(value),"detail":detail})
    print(("PASS " if value else "FAIL ")+name,file=sys.stderr,flush=True)

# General operator algebra, with the time-varying radial coefficient retained.
T,r=s.symbols("tau r",positive=True)
aa=s.Function("a")(T);hh=s.diff(aa,T)/aa
cc=s.Function("c")(T);dd=s.Function("d")(T);ee=s.Function("e")(T)
kk=s.Function("k")(T)
pp=s.Function("P")(T,r);yy=s.Function("Y")(T,r);zz=s.Function("Z")(T,r)
L=lambda f:s.diff(f,T)+s.diff(f,r)/aa
UU=dd*s.diff(pp,T)+ee*pp
KK=s.diff(cc,T)+hh*cc
NN=s.diff(yy,T)+(hh+cc)*yy+L(UU)+hh*UU
E1=s.diff(zz,T)+cc*zz+UU
zero("commutator reconstructs hidden potential",
     (NN+KK*zz).subs(yy,L(zz)).doit()-L(E1)-hh*E1)
row=[s.diff(yy,T),L(yy),yy,L(L(s.diff(pp,T))),L(s.diff(pp,T)),s.diff(pp,T),L(L(pp)),L(pp),pp]
theta=[-kk,cc,2*s.diff(cc,T)+hh*cc-kk*(hh+cc),
       dd,2*s.diff(dd,T)+(hh-kk)*dd,
       s.diff(dd,T,2)+(hh-kk)*s.diff(dd,T)+(s.diff(hh,T)-kk*hh)*dd,
       ee,2*s.diff(ee,T)+(hh-kk)*ee,
       s.diff(ee,T,2)+(hh-kk)*s.diff(ee,T)+(s.diff(hh,T)-kk*hh)*ee]
O=L(s.diff(yy,T))+hh*L(yy)+s.diff(hh,T)*yy
zero("nine-column observable identity",L(NN)-kk*NN+KK*yy-O-sum(a*b for a,b in zip(row,theta)))

# Exact analytic original-equation solutions, encoded by their ODE-generated jets.
t=s.symbols("t",positive=True);rad=s.symbols("r0",positive=True)
k2,j=s.symbols("k2 angular_index",real=True)
p,w,z,u,density=s.symbols("P w zeta U delta",real=True)
B,Br=s.symbols("B Br",real=True)
states=[p,w,z,u]
def physical_fixture(label,power,field_speed):
    power=s.Rational(power);speed=s.sqrt(s.Rational(field_speed))
    coupling_power=3*power-2
    A=t**coupling_power;aE=t**power;a=A*aE
    H=power/t;v=speed/t
    rr=(2*power-speed**2)/t**2
    rho=rr/A;V=(3*power**2-2*power+speed**2/2)/t**2
    alpha=coupling_power/speed
    Dphi=lambda f:t*s.diff(f,t)/speed
    F=simp(Dphi(V)+rho*Dphi(A))
    mass=simp(Dphi(Dphi(V))+rho*Dphi(Dphi(A)))
    h=simp(s.diff(a,t)/(A*a));x=simp(v/A);q=simp(alpha*x)
    G=simp(x/alpha);R=simp(rr/A**2);ell=h-q
    c=simp(R/G);d=simp(2/G);e=simp(1+d*ell)
    DTbg=lambda f:simp(s.diff(f,t)/A)
    K=simp(DTbg(c)+h*c)
    zero(label+" background Friedmann",3*H**2-v*v/2-rr-V)
    zero(label+" background Raychaudhuri",-2*s.diff(H,t)-v*v-rr)
    zero(label+" background original scalar",s.diff(v,t)+3*H*v+F)
    zero(label+" bare dust conservation",s.diff(rho,t)+3*H*rho)
    zero(label+" matter dust transport",DTbg(R)-(2*q-3*h)*R)
    zero(label+" coefficient dust identity",DTbg(c)/c-DTbg(d)/d-(2*q-3*h))
    zero(label+" coefficient Raychaudhuri",R+2*DTbg(ell)+2*q*ell+x*x)
    zero(label+" alternative K expression",K-c*(DTbg(d)-2*(e-1))/d)
    zero(label+" alternative c expression",c+DTbg(e)+h*e-(e-1)*(DTbg(d)+e)/d)
    Fbar=simp(F/A**2);kap=simp(mass/A**2)
    zero(label+" fixed-density curvature reconstruction",(DTbg(Fbar)+2*q*Fbar+3*ell*alpha*R)/x-kap)
    # Five-variable original system and exact propagation before reduction.
    fp=(v*w-rr*u)/2-H*p
    fu=-p-alpha*w-alpha*v*u
    fz5=-3*H*z-(k2/aE**2+mass)*w+4*v*fp-2*F*p-alpha*rr*density
    fd=3*fp+k2*u/aE**2
    fields5=[p,w,z,u,density];rhs5=[fp,z,fz5,fu,fd]
    D5=lambda expr:simp(s.diff(expr,t)+sum(s.diff(expr,var)*rhs for var,rhs in zip(fields5,rhs5)))
    constraint=-2*k2*p/aE**2-6*H*(fp+H*p)-rr*density-v*z+v*v*p-F*w
    zero(label+" full Hamiltonian propagation",D5(constraint)+3*H*constraint)
    delta=simp(s.solve(constraint,density)[0])
    fz=simp(fz5.subs(density,delta))
    rhs=[fp,z,fz,fu]
    D=lambda expr:simp(s.diff(expr,t)+sum(s.diff(expr,var)*rhs0 for var,rhs0 in zip(states,rhs)))
    DT=lambda expr:simp(D(expr)/A)
    DR=lambda expr:simp(s.diff(expr,rad)+s.diff(expr,B)*Br+s.diff(expr,Br)*(-2*Br/rad-(k2-j*(j+1)/rad**2)*B))
    Lop=lambda expr:simp(DT(expr)+DR(expr)/a)
    zero(label+" reduced original Hamiltonian",constraint.subs(density,delta))
    zero(label+" reduced original scalar",D(z)+3*H*z+(k2/aE**2+mass)*w+alpha*rr*delta-4*v*D(p)+2*F*p)
    zero(label+" reduced dust continuity",D(delta)-3*D(p)-k2*u/aE**2)
    zero(label+" reduced spatial Einstein trace",2*(D(D(p))+4*H*D(p)+(2*s.diff(H,t)+3*H*H)*p)-v*z+v*v*p+Dphi(V)*w)
    zero(label+" reduced original Euler",D(u)+p+alpha*w+alpha*v*u)
    P=p*B;Z=A*u*B;J=alpha*w*B;Y=-P-J+u*Br/aE
    zero(label+" observable transport",Lop(Z)-Y)
    zero(label+" hidden first-order momentum",DT(Z)+c*Z+d*DT(P)+e*P)
    N=simp(DT(Y)+(h+c)*Y+d*Lop(DT(P))+(DTbg(d)+h*d)*DT(P)+e*Lop(P)+(DTbg(e)+h*e)*P)
    zero(label+" physical commutator",N+K*Z)
    columns=[DT(Y),Lop(Y),Y,Lop(Lop(DT(P))),Lop(DT(P)),DT(P),Lop(Lop(P)),Lop(P),P]
    target=simp(Lop(DT(Y))+h*Lop(Y)+DTbg(h)*Y)
    columns0=[simp(f.subs({t:1,rad:1})) for f in columns]
    target0=simp(target.subs({t:1,rad:1}))
    # Each row is one genuinely distinct full-sky l>=2 harmonic sector, with
    # local analytic radial and temporal Cauchy data. No arbitrary time jets.
    rows=[];targets=[];fixtures=[]
    for i in range(40):
        init=[s.Integer(int(v0==i%4)) for v0 in range(4)]
        vals={k2:s.Integer(i%7+1),j:s.Integer(i+2),B:s.Integer((i//4)%2==0),Br:s.Integer((i//4)%2==1)}
        vals.update(dict(zip(states,init)))
        rows.append([s.cancel(f.xreplace(vals)) for f in columns0]);targets.append(-s.cancel(target0.xreplace(vals)))
        fixtures.append({"l":i+2,"k2":i%7+1,"state":[int(v0) for v0 in init],"B":int(vals[B]),"Br":int(vals[Br])})
    matrix=s.Matrix(rows);targetmat=s.Matrix(targets)
    rank=matrix.to_DM().rank();rank_aug=matrix.row_join(targetmat).to_DM().rank()
    details[label]={"background":{"a":str(a),"A":str(A),"h":str(h),"c":str(c),"d":str(d),"e":str(e),"K":str(K),"kappa":str(kap)},
        "row_columns":["Y_tau","L Y","Y","L^2 P_tau","L P_tau","P_tau","L^2 P","L P","P"],
        "rows":[[str(v0) for v0 in rr0] for rr0 in rows],"negative_target":[str(v0) for v0 in targets],"fixtures":fixtures,
        "rank":rank,"augmented_rank":rank_aug}
    if K!=0:
        kval=simp(DTbg(K)/K)
        th=[-kval,c,2*DTbg(c)+h*c-kval*(h+c),
            d,2*DTbg(d)+(h-kval)*d,DTbg(DTbg(d))+(h-kval)*DTbg(d)+(DTbg(h)-kval*h)*d,
            e,2*DTbg(e)+(h-kval)*e,DTbg(DTbg(e))+(h-kval)*DTbg(e)+(DTbg(h)-kval*h)*e]
        th0=s.Matrix([s.simplify(v0.subs(t,1)) for v0 in th])
        zero(label+" physical nine-column consistency",sum(v0*v0 for v0 in (matrix*th0-targetmat)))
        ok(label+" proposed rank-nine criterion attainable",rank==9,{"actual_rank":rank})
        if rank==9:
            selected=list(matrix.T.to_DM().rref()[1]);square=matrix[selected,:]
            recovered=square.inv()*targetmat[selected,:]
            determinant=s.factor(square.det())
            ok(label+" exact rank witness determinant nonzero",determinant!=0,str(determinant))
            zero(label+" exact background coefficient recovery",sum(v0*v0 for v0 in (recovered-th0)))
            details[label].update({"selected_row_indices":selected,"determinant":str(determinant),"expected_theta":[str(v0) for v0 in th0],"recovered_theta":[str(v0) for v0 in recovered]})
        else:
            details[label]["right_nullspace"]=[[str(v0) for v0 in vec] for vec in matrix.nullspace()]
    else:
        nullvec=s.Matrix([1,0,h+c,0,d,DTbg(d)+h*d,0,e,DTbg(e)+h*e]).subs(t,1)
        zero(label+" exceptional-chart observable null relation",sum(v0*v0 for v0 in matrix*nullvec))
        ok(label+" K zero forbids rank nine",rank<9,{"actual_rank":rank})
        details[label]["exceptional_null_vector"]=[str(v0) for v0 in nullvec]
    print("FIXTURE_SUMMARY "+json.dumps({"label":label,"rank":rank,"augmented_rank":rank_aug,"determinant":details[label].get("determinant"),"selected_row_indices":details[label].get("selected_row_indices")}),file=sys.stderr,flush=True)
    return matrix

physical_fixture("p2_nonzero_K",2,1)
physical_fixture("p1_zero_K",1,1)

# A continuous same-expansion, zero-record family of physically different actions.
ss=s.symbols("s",positive=True)
speed=s.sqrt(ss);A=t;aE=t;H=1/t;v=speed/t
rho=(2-ss)/t**3;rr=A*rho;V=(1+ss/2)/t**2
DP=lambda f:t*s.diff(f,t)/speed
alpha=1/speed;F=simp(DP(V)+rho*DP(A));mu=simp(DP(DP(V))+rho*DP(DP(A)))
zero("zero-record family Friedmann",3*H*H-v*v/2-rr-V)
zero("zero-record family Raychaudhuri",-2*s.diff(H,t)-v*v-rr)
zero("zero-record family original scalar",s.diff(v,t)+3*H*v+F)
zero("zero-record family bare conservation",s.diff(rho,t)+3*H*rho)
zero("zero-record family response curvature",mu/A**2-(6+ss)/(ss*t**4))
zero("zero-record family common matter expansion",s.diff(A*aE,t)/(A*A*aE)-2/t**2)
ok("zero-record family has positive dust for two distinct choices",
   all((2-vv)>0 for vv in [s.Rational(1,2),s.Rational(3,2)]))
ok("zero-record family has distinct coupling",alpha.subs(ss,s.Rational(1,2))!=alpha.subs(ss,s.Rational(3,2)))
ok("zero perturbations give rank zero",s.zeros(10,9).rank()==0)

out={"stage":"Independent before new joint-background author exposure","new_author_sources_read":False,
     "software":{"python":sys.version.split()[0],"sympy":s.__version__},
     "checks":checks,"summary":{"passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks)},
     "details":details,"scope":"Exact local action-consistent Cauchy solutions, conditional ideal rank; no empirical data or arbitrary physical jets"}
print(json.dumps(out,indent=2))
raise SystemExit(int(out["summary"]["failed"]!=0))

