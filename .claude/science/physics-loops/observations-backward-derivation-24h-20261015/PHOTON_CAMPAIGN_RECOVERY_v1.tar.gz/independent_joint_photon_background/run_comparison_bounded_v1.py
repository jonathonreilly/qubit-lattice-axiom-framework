"""Bounded post-exposure comparison and unchanged copied author replays."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
 'POST_EXPOSURE_DERIVATION_v1.md','comparison_controls_v1.py','run_comparison_bounded_v1.py',
 'AUTHOR_SNAPSHOT_v2.json','author_snapshot_v2/JOINT_PHOTON_BACKGROUND_DERIVATION_v2.md',
 'author_snapshot_v2/check_joint_photon_background_v2.py','author_snapshot_v2/JOINT_PHOTON_BACKGROUND_CONTROLS_v2.json',
 'author_snapshot_v2/check_joint_photon_background_full_residuals_v1.py','author_snapshot_v2/JOINT_PHOTON_BACKGROUND_FULL_RESIDUALS_v1.json',
]
import argparse,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
ap=argparse.ArgumentParser();ap.add_argument('--case',required=True,choices=['algebra','ranks','author_primary','author_residuals']);ap.add_argument('--attempt',required=True);args=ap.parse_args()
if not args.attempt.replace('_','').isalnum():raise ValueError('Fresh simple attempt label required')
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if any(prefix.with_suffix(x).exists() for x in ['.run.json','.stdout.json','.stderr.txt']):raise FileExistsError('Evidence is immutable')
def bind():return {n:{'sha256':hashlib.sha256((here/n).read_bytes()).hexdigest(),'bytes':(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind();expected=None
if args.case=='author_primary':
    script=here/'author_snapshot_v2/check_joint_photon_background_v2.py';argv=[sys.executable,'-B',str(script)];expected=here/'author_snapshot_v2/JOINT_PHOTON_BACKGROUND_CONTROLS_v2.json'
elif args.case=='author_residuals':
    script=here/'author_snapshot_v2/check_joint_photon_background_full_residuals_v1.py';argv=[sys.executable,'-B',str(script)];expected=here/'author_snapshot_v2/JOINT_PHOTON_BACKGROUND_FULL_RESIDUALS_v1.json'
else:script=here/'comparison_controls_v1.py';argv=[sys.executable,'-B',str(script),args.case]
start=time.monotonic();started=datetime.now(timezone.utc).isoformat();r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix('.stdout.json').open('wb') as of,prefix.with_suffix('.stderr.txt').open('wb') as ef:
    try:rc=subprocess.run(argv,cwd=script.parent,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=of,stderr=ef,timeout=AUDIT_TIMEOUT_SEC,check=False).returncode
    except subprocess.TimeoutExpired:rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN)
stdout=prefix.with_suffix('.stdout.json').read_bytes();stderr=prefix.with_suffix('.stderr.txt').read_bytes();after=bind()
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
record={'case':args.case,'argv':argv,'cwd':str(script.parent),'timeout_seconds':AUDIT_TIMEOUT_SEC,'PYTHONDONTWRITEBYTECODE':'1','start_utc':started,'end_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':wall,'returncode':rc,'timed_out':timeout,'child_user_seconds':r1.ru_utime-r0.ru_utime,'child_system_seconds':r1.ru_stime-r0.ru_stime,'child_peak_rss_platform_units':r1.ru_maxrss,'platform':sys.platform,'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'output_parse_error':error,'summary':result.get('summary',{'passed':result.get('passed'),'failed':result.get('failed')}) if result else None,'input_binding_before':before,'input_binding_after':after,'inputs_unchanged':before==after,'copied_author_replay':expected is not None,'author_output_byte_identical':stdout==expected.read_bytes() if expected else None,'author_output_semantically_identical':result==json.loads(expected.read_text()) if expected and result else None}
prefix.with_suffix('.run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['case','wall_seconds','returncode','timed_out','summary','inputs_unchanged','author_output_byte_identical','author_output_semantically_identical']},indent=2))
if rc!=0 or timeout or before!=after:raise SystemExit(1)
