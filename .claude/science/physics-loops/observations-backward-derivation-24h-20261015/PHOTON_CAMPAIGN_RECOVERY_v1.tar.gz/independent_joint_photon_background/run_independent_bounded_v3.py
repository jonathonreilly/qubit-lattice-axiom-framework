"""Bounded split execution with live evidence files; preserve earlier attempts."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "NEUTRAL_CONTRACT_v1.json","KNOWN_ACTION_NOTE_SNAPSHOT.md",
    "DERIVATION_BEFORE_CODE_v1.md","PRE_CODE_FREEZE_v1.json",
    "independent_controls_v3.py","run_independent_bounded_v3.py",
]
import argparse,hashlib,json,os,resource,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument("--attempt",required=True)
ap.add_argument("--case",choices=["p2","p1"],required=True);args=ap.parse_args()
if not args.attempt.replace("_","").isalnum():raise ValueError("Simple fresh attempt label required")
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if any(prefix.with_suffix(suffix).exists() for suffix in (".run.json",".stdout.json",".stderr.txt")):raise FileExistsError("Earlier evidence is immutable")
def bind():
    return {n:{"sha256":hashlib.sha256((here/n).read_bytes()).hexdigest(),"bytes":(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind();script=here/"independent_controls_v3.py";argv=[sys.executable,"-B",str(script),args.case]
started=datetime.now(timezone.utc).isoformat();start=time.monotonic()
r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix(".stdout.json").open("wb") as of, prefix.with_suffix(".stderr.txt").open("wb") as ef:
    try:
        rr=subprocess.run(argv,cwd=here,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=of,stderr=ef,timeout=AUDIT_TIMEOUT_SEC,check=False)
        rc=rr.returncode
    except subprocess.TimeoutExpired:
        rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN)
stdout=prefix.with_suffix(".stdout.json").read_bytes();stderr=prefix.with_suffix(".stderr.txt").read_bytes()
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
after=bind()
record={"case":args.case,"argv":argv,"cwd":str(here),"timeout_seconds":AUDIT_TIMEOUT_SEC,
        "PYTHONDONTWRITEBYTECODE":"1","start_utc":started,"end_utc":datetime.now(timezone.utc).isoformat(),
        "wall_seconds":wall,"returncode":rc,"timed_out":timeout,
        "child_user_seconds":r1.ru_utime-r0.ru_utime,"child_system_seconds":r1.ru_stime-r0.ru_stime,
        "child_peak_rss_platform_units":r1.ru_maxrss,"platform":sys.platform,
        "stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),
        "stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest(),
        "output_parse_error":error,"summary":result["summary"] if result else None,
        "physical_design_ranks":{k:v["rank"] for k,v in result["details"].items()} if result else None,
        "input_binding_before":before,"input_binding_after":after,"inputs_unchanged":before==after,
        "new_author_sources_read":False}
prefix.with_suffix(".run.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:record[k] for k in ("case","wall_seconds","returncode","timed_out","summary","physical_design_ranks","output_parse_error","inputs_unchanged")},indent=2))
if rc!=0 or timeout or before!=after:raise SystemExit(1)

