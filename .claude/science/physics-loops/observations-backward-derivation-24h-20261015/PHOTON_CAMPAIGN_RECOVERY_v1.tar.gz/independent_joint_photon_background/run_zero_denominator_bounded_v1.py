"""Bounded split execution with live evidence files; preserve earlier attempts."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = ["POST_EXPOSURE_DERIVATION_v1.md","AUTHOR_SNAPSHOT_v2.json","zero_linear_denominator_controls_v1.py","run_zero_denominator_bounded_v1.py"]
import argparse,hashlib,json,os,resource,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument("--attempt",required=True)
args=ap.parse_args()
if not args.attempt.replace("_","").isalnum():raise ValueError("Simple fresh attempt label required")
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if any(prefix.with_suffix(suffix).exists() for suffix in (".run.json",".stdout.json",".stderr.txt")):raise FileExistsError("Earlier evidence is immutable")
def bind():
    return {n:{"sha256":hashlib.sha256((here/n).read_bytes()).hexdigest(),"bytes":(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind();script=here/"zero_linear_denominator_controls_v1.py";argv=[sys.executable,"-B",str(script)]
started=datetime.now(timezone.utc).isoformat();start=time.monotonic()
r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix(".stdout.json").open("wb") as of, prefix.with_suffix(".stderr.txt").open("wb") as ef:
    try:
        rr=subprocess.run(argv,cwd=here,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=of,stderr=ef,timeout=AUDIT_TIMEOUT_SEC,check=False)
        rc=rr.returncode
    except subprocess.TimeoutExpired:
        rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN)
stdout=prefix.with_suffix(".stdout.json").read_bytes();stderr=prefix.with_suffix(".stderr.txt").read_bytes()
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
after=bind()
record={"argv":argv,"cwd":str(here),"timeout_seconds":AUDIT_TIMEOUT_SEC,
        "PYTHONDONTWRITEBYTECODE":"1","start_utc":started,"end_utc":datetime.now(timezone.utc).isoformat(),
        "wall_seconds":wall,"returncode":rc,"timed_out":timeout,
        "child_user_seconds":r1.ru_utime-r0.ru_utime,"child_system_seconds":r1.ru_stime-r0.ru_stime,
        "child_peak_rss_platform_units":r1.ru_maxrss,"platform":sys.platform,
        "stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),
        "stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest(),
        "output_parse_error":error,"summary":result["summary"] if result else None,
        "physical_design_ranks":None,
        "input_binding_before":before,"input_binding_after":after,"inputs_unchanged":before==after,
        "new_author_sources_read":True}
prefix.with_suffix(".run.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:record[k] for k in ("wall_seconds","returncode","timed_out","summary","physical_design_ranks","output_parse_error","inputs_unchanged")},indent=2))
if rc!=0 or timeout or before!=after:raise SystemExit(1)

