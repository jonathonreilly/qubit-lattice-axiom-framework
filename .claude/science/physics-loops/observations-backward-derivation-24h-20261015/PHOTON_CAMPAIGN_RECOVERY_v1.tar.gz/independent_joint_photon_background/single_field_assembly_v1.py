"""Assemble the physical rank witness into one finite full-sky scalar field."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = ["independent_attempt03_p2.stdout.json"]
import hashlib,json,sys
from pathlib import Path
import sympy as s
here=Path(__file__).resolve().parent
raw=(here/AUDIT_INPUT_PATHS[0]).read_bytes()
data=json.loads(raw)["details"]["p2_nonzero_K"]
selected=data["selected_row_indices"]
rows=s.Matrix([[s.Rational(v) for v in data["rows"][i]] for i in selected])
target=s.Matrix([s.Rational(data["negative_target"][i]) for i in selected])
theta=s.Matrix([s.Rational(v) for v in data["recovered_theta"]])
ells=[data["fixtures"][i]["l"] for i in selected]
mu=[s.Rational(i,10) for i in range(1,10)]
V=s.Matrix([[s.legendre(l,position) for l in ells] for position in mu])
combined=V*rows;combined_target=V*target
dv=s.factor(V.det());dm=s.factor(combined.det())
checks=[
 {"name":"selected rows are actual full-equation l>=2 modes","pass":len(set(ells))==9 and min(ells)>=2},
 {"name":"exact modal determinant retained","pass":rows.det()==1236},
 {"name":"nine local angular evaluations are independent","pass":dv!=0},
 {"name":"one summed field has exact rank nine","pass":dm!=0 and dm==1236*dv},
 {"name":"one summed field recovers the same coefficients","pass":combined*theta==combined_target},
]
c,d,e=theta[1],theta[3],theta[6]
h=s.Integer(6);G=2/d;R=2*c/d;ell=(e-1)/d;q=h-ell;x=s.sqrt(q*G);b=q/x
checks.append({"name":"coefficient recovery gives physical background at t one","pass":(G,R,q,x,b)==(s.Rational(1,4),s.Integer(3),s.Integer(4),s.Integer(1),s.Integer(4))})
out={"stage":"Independent before new author exposure; assembly of already verified physical Cauchy modes",
     "input_sha256":hashlib.sha256(raw).hexdigest(),"checks":checks,
     "summary":{"passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks)},
     "angular_basis":"Unnormalized real Legendre P_l(cos(theta)), l=2,...,10",
     "mu_points":[str(v) for v in mu],"ell_values":ells,"modal_determinant":str(rows.det()),
     "angular_evaluation_determinant":str(dv),"single_field_design_determinant":str(dm),
     "combined_design":[[str(combined[i,j]) for j in range(9)] for i in range(9)],
     "negative_target":[str(v) for v in combined_target],
     "recovered_background":{"G":str(G),"R":str(R),"q":str(q),"x":str(x),"b":str(b)},
     "scope":"Finite sum of local analytic radial/time full-equation modes. Multiply every perturbation by any sufficiently small nonzero amplitude; rank remains nine. No center, decay or empirical assumption."}
print(json.dumps(out,indent=2))
raise SystemExit(int(out["summary"]["failed"]!=0))

