"""Post-exposure algebraic refinement of the root eight-column count."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import json,sys
import sympy as s
checks=[]
def ck(name,value,detail=None):checks.append({'name':name,'pass':bool(value),'detail':detail})
def ze(name,expr):
    value=s.factor(s.cancel(expr));ck(name,value==0,str(value))
C,D,Dp,h,hp,Q,Qp,p,z,cr0=s.symbols('C D Dp h hp Q Qp p z cr0')
Cp=C*(Dp/D+2*Q-3*h-2*C)
E=D*(h-Q+C)-1
Ep=Dp*(h-Q+C)+D*(hp-Qp+Cp)
predicted_cr0=Ep+(p-C-2*h)*E
B=Dp/D*(h-Q)+hp-Qp+(p-2*h)*(h-Q-1/D)
H1=z-hp-p*h+h*h
T=Dp/D+Q-h+1/D
poly=3*C*C+(5*h-p-Dp/D-2*Q)*C+H1
ze('cr0 plus quadratic gives second linear extraction',predicted_cr0/D+poly-T*C-B-H1)
vals={D:-12,Dp:-66,h:8,hp:-52,Q:12,Qp:-78,p:32,z:161,cr0:-226}
ze('Lroot zero at analytic witness',(p-h-2*Q).subs(vals))
ze('T nonzero at analytic witness',T.subs(vals)-s.Rational(113,12))
ze('first common quadratic explicit',poly.subs(vals)-(3*C*C-s.Rational(43,2)*C+21))
ck('two initial quadratic roots',s.solve(poly.subs(vals),C)==[s.Rational(7,6),s.Integer(6)])
ze('cr0 reconstructs C six',((cr0/D-B-H1)/T).subs(vals)-6)
ze('true C passes cr0',(predicted_cr0-cr0).subs(vals).subs(C,6))
other=(predicted_cr0-cr0).subs(vals).subs(C,s.Rational(7,6))
ck('other quadratic root fails unused coefficient',other!=0,str(other))
ck('both initial roots satisfy the elementary positivity chart',all((-2*cc/vals[D])>0 and (vals[Q]-cc)*(-2/vals[D])>0 for cc in [s.Rational(7,6),s.Integer(6)]))
out={'stage':'Post-exposure root-route refinement','checks':checks,'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},'scope':'Algebraic compatibility only; no claim of two physical histories or empirical evidence','sympy':s.__version__}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
