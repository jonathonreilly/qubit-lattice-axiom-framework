"""Post-exposure Lroot=0 local-action witness using exact truncated jets."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json,sys,time
import sympy as s
N=8;checks=[];details={};start=time.monotonic()
class J:
    def __init__(self,value):
        if isinstance(value,J):self.c=value.c[:]
        elif isinstance(value,(list,tuple)):self.c=[s.Rational(x) for x in value[:N+1]]+[s.S.Zero]*max(0,N+1-len(value))
        else:self.c=[s.Rational(value)]+[s.S.Zero]*N
    def __add__(self,b):
        b=J(b);return J([x+y for x,y in zip(self.c,b.c)])
    __radd__=__add__
    def __neg__(self):return J([-x for x in self.c])
    def __sub__(self,b):return self+-J(b)
    def __rsub__(self,b):return J(b)+-self
    def __mul__(self,b):
        b=J(b);return J([sum(self.c[k]*b.c[n-k] for k in range(n+1)) for n in range(N+1)])
    __rmul__=__mul__
    def inverse(self):
        if self.c[0]==0:raise ZeroDivisionError('Jet constant is zero')
        out=[1/self.c[0]]
        for n in range(1,N+1):out.append(-sum(self.c[k]*out[n-k] for k in range(1,n+1))/self.c[0])
        return J(out)
    def __truediv__(self,b):return self*J(b).inverse()
    def __rtruediv__(self,b):return J(b)*self.inverse()
    def __pow__(self,n):
        if n<0:return self.inverse()**(-n)
        out=J(1)
        for _ in range(n):out=out*self
        return out
    def derivative(self):return J([(n+1)*self.c[n+1] for n in range(N)]+[0])
    def at(self):return self.c[0]
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail});print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
def zerojet(name,value,order=3):
    value=J(value);check(name,all(x==0 for x in value.c[:order+1]),[str(x) for x in value.c[:order+1]])
eps=J([0,1]);H=2-eps;v=J(1);z=J(0);ae=J(1)
for n in range(N):
    fz=(v/2)*(2*z*z/v**2-6/v**2-12*H*z/v**3+3-2*H*z/v+6*H**2/v**2-3*H**2-9)
    v.c[n+1]=z.c[n]/(n+1);z.c[n+1]=fz.c[n]/(n+1)
    ae.c[n+1]=(H*ae).c[n]/(n+1)
r=2-v*v;A=r*ae**3;a=A*ae;sig=A.derivative()/A;b=sig/v
V=3*H*H+v*v/2-2;rho=r/A;F=-z-3*H*v
mu=(F.derivative()+3*H*r*b)/v
Dt=lambda f:J(f).derivative()/A
h=(H+sig)/A;x=v/A;q=b*x;G=x/b;R=r/A**2
c=R/G;d=2/G;e=1+d*(h-q);K=Dt(c)+h*c
S=-2*z/v+6*H/v**2-3*H;T=S.derivative()+H*S
zerojet('analytic ODE enforces A squared K equals nine',A*A*K-9,3)
zerojet('direct S derivative matches A squared K',T-A*A*K,3)
zerojet('linear denominator vanishes to generated order',-Dt(K)/K-2*q,2)
zerojet('positive-dust background Friedmann',3*H*H-v*v/2-r-V,4)
zerojet('background Raychaudhuri',-2*H.derivative()-v*v-r,4)
zerojet('bare density continuity',rho.derivative()+3*H*rho,3)
zerojet('force from action equals original scalar force',V.derivative()/v+rho*A.derivative()/v-F,3)
zerojet('original scalar',z+3*H*v+F,4)
check('regular chart at epoch',r.at()>0 and A.at()>0 and b.at()!=0 and x.at()!=0 and K.at()!=0)
details['background_at_t1']={name:str(obj.at()) for name,obj in [('A',A),('a',a),('h',h),('b',b),('x',x),('q',q),('G',G),('R',R),('c',c),('d',d),('e',e),('K',K),('kappa',mu/A**2)]}
details['background_taylor_coefficients']={name:[str(cc) for cc in obj.c] for name,obj in [('v',v),('v_dot',z),('aE',ae),('A',A)]}

def addrows(*rows):return [sum(col,J(0)) for col in zip(*rows)]
def scale(row,factor):return [factor*el for el in row]
def rowdt(row):return [Dt(el) for el in row]
def evalrow(row):return s.Matrix([[el.at() for el in row]])
allrows9=[];allrows8=[];seeds=[]
for kk in [1,2,3,5]:
    # Original Einstein-time four-state Cauchy system, not inverse-generated jets.
    fp=[-H,v/2,J(0),-r/2];fu=[J(-1),-b,J(0),-b*v]
    delta=[(-2*kk/ae**2+v*v)/r,(-3*H*v-F)/r,-v/r,3*H]
    fz=addrows([J(0),-(kk/ae**2+mu),-3*H,J(0)],scale(fp,4*v),[ -2*F,J(0),J(0),J(0)],scale(delta,-b*r))
    mj=[fp,[J(0),J(0),J(1),J(0)],fz,fu]
    mcoeff=[s.Matrix([[el.c[n] for el in row] for row in mj]) for n in range(4)]
    flow=[s.eye(4)]
    for n in range(4):flow.append(sum((mcoeff[k]*flow[n-k] for k in range(n+1)),s.zeros(4))/(n+1))
    prows=[[J([flow[n][ii,jj] for n in range(5)]) for jj in range(4)] for ii in range(4)]
    pp,ww,zz,uu=prows
    # Sourced constraint and all evolution residuals at this epoch follow from
    # original row propagation, with continuity and pressure checked explicitly.
    density=[sum((delta[ii]*prows[ii][jj] for ii in range(4)),J(0)) for jj in range(4)]
    pd=[el.derivative() for el in pp];pdd=[el.derivative() for el in pd]
    for jj in range(4):
        zerojet('dust continuity k'+str(kk)+' seed'+str(jj),density[jj].derivative()-3*pd[jj]-kk*uu[jj]/ae**2,0)
        zerojet('Einstein pressure k'+str(kk)+' seed'+str(jj),2*(pdd[jj]+4*H*pd[jj]+(2*H.derivative()+3*H*H)*pp[jj])-v*zz[jj]+v*v*pp[jj]+V.derivative()*ww[jj]/v,0)
    p0=evalrow(pp);p1=evalrow(rowdt(pp));p2=evalrow(rowdt(rowdt(pp)));p3=evalrow(rowdt(rowdt(rowdt(pp))))
    yB=scale(addrows(pp,scale(ww,b)),-1);yR=scale(uu,1/ae)
    y0B=evalrow(yB);y0R=evalrow(yR);y1B=evalrow(rowdt(yB));y1R=evalrow(rowdt(yR))
    aa=a.at();hh=h.at()
    for rad in [0,1]:
        BB=int(rad==0);RR=int(rad==1)
        for jj in range(4):
            ll=len(seeds)+2;Brr=-2*RR-(kk-ll*(ll+1))*BB
            Y=y0B*BB+y0R*RR;Yp=y1B*BB+y1R*RR
            LY=Yp+(y0B*RR+y0R*Brr)/aa
            LP=p1*BB+p0*RR/aa;LPp=p2*BB+p1*RR/aa
            L2P=p2*BB+(2*p1-hh*p0)*RR/aa+p0*Brr/aa**2
            L2Pp=p3*BB+(2*p2-hh*p1)*RR/aa+p1*Brr/aa**2
            rows9=[Yp,LY,Y,L2Pp,LPp,p1*BB,L2P,LP,p0*BB]
            rows8=[p3*BB+p2*RR/aa,p2*BB,p1*RR/aa,p1*BB,p0*RR/aa,p0*BB,-Yp,-Y]
            allrows9.append([el[jj] for el in rows9]);allrows8.append([el[jj] for el in rows8])
            seeds.append({'k2':kk,'l':ll,'B':BB,'Br':RR,'state_basis':jj})
M9=s.Matrix(allrows9);M8=s.Matrix(allrows8)
for label,mat in [('nine',M9),('eight',M8)]:
    rank=mat.rank();details[label]={'rank':rank,'design':[[str(el) for el in row] for row in mat.tolist()]}
    check('Lroot zero physical '+label+' design full rank',rank==mat.cols,{'rank':rank})
    if rank==mat.cols:
        ids=list(mat.T.rref()[1]);details[label].update({'selected_rows':ids,'determinant':str(s.factor(mat[ids,:].det()))})
details['seeds']=seeds
out={'stage':'Post-exposure local analytic Lroot=0 witness','software':{'python':sys.version.split()[0],'sympy':s.__version__},'checks':checks,'summary':{'passed':sum(q0['pass'] for q0 in checks),'failed':sum(not q0['pass'] for q0 in checks)},'details':details,'wall_seconds':time.monotonic()-start,'scope':'Local analytic background and exact action-generated jets; no data, no claimed two-history example'}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
