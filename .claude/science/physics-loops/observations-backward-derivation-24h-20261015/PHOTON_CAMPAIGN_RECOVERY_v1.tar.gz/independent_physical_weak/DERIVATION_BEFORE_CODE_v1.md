# Independent fixed-background wrong-constant-gain residual

This derivation uses only root's neutral example and previously known linear/operator conventions. No new check_physical_weak source or output has been read. It is frozen before executable calculations. Root retains authorship of the overall unit. The scope is one necessary test for one fixed-background wrong-gain candidate, not rank, uniqueness or an empirical result.

## Chart, records and strong residual

Write eta=u-r, q0=1/a=eta^8/256, T=q0 partial_u and L=q0(2partial_u+partial_r). The supplied window has eta in [-3,-1], so every inverse power is regular. The background is h=-eta^7/32, C=-eta^7/256, d=-256/eta^7, e=4. Direct differentiation gives

    K=TC+hC=eta^14/65536,
    k=TK/K=14eta^7/256.

For H2=P2(cos theta), define scalar radial/time amplitudes by removing the common H2. The supplied n=0,l=2 mode gives P=r^2, J=5r^2/2, Z=128eta^-7 r^2 and Y=eta r-7r^2/2. The true common reception gain is g=(u+11)/10, positive throughout the window. Since P is independent of conformal time, I1=0. The measured primitives are psi_obs=g r^2/3 and z_obs=gY, both times H2.

At fixed u, Q=(r^2/2)partial_r and Dr=(1/2)partial_r(r^2 partial_r). Hence

    X=g r^2,
    B=a g r^3/3,
    W=g(eta r-7r^2/2)+r^3/15.

The r^3/15 term is the measured primitive path correction 2g_u I0. The wrong candidate takes constant common gain on the SAME background. Its absolute positive gain constant drops out of this homogeneous necessary equation; its logarithmic drift is zero. Thus

    F=dTX+eX=r^2(3eta+4r+44)/10,
    N=(T+h+C)W+(L+h)F=eta^7 n/256,
    n=-eta^2 r/10+11eta r^2/10-11r^2/20-13r^3/20.

Here (partial_eta+partial_r) is the conformal characteristic derivative in (eta,r). Applying L-k to N and adding KW gives the scalar amplitude

    E0 = eta^14/65536 * [-eta^3/10+14eta^2 r/5-44eta r^2/5+64r^3/15]
       = (u-r)^14/1966080 * [-3u^3+93u^2r-441ur^2+479r^3].

The full strong residual is E0 H2. Every term in the last cubic is strictly positive for u<0,r>0; therefore E0>0 on this window. Nonzero E0 rejects this wrong candidate on exact records. It says nothing about another background or about uniqueness of a fitted model.

## Direct formal adjoints and primitive kernels

Use the declared flat coordinate measure du dr dOmega. The divergences of both T and L are -h, so Tdag=-T+h and Ldag=-L+h. The strong wrong-candidate operator factors without expanding fourteen coefficients:

    AW=(L-k)(T+h+C)+K,
    AX=(L-k)(L+h)(dT+e).

For the scalar radial test lambda0=[(u+3/2)(-1/2-u)(r-1/2)(3/2-r)]^6, set

    p0=(Ldag-k)lambda0,
    p1=(Ldag+h)p0,
    hz=(Tdag+h+C)p0+K lambda0,
    hx=Tdag(d p1)+e p1,
    hp=Dr hx + partial_r[r^2 partial_u hz].

The final plus sign follows from W=z_obs+2partial_u Q psi_obs and Qdag v=-(1/2)partial_r(r^2v). The primitive-only weak moment is integral (hz z_obs+hp psi_obs). Coefficients multiply operator outputs, and adjoints reverse composition order; these conventions matter.

For efficient exact independent integration one may eliminate every inverse power before expanding. Let D=2partial_u+partial_r and define

    R0=eta D lambda0+22lambda0,
    S0=eta D R0+23R0.

The same kernels are polynomials:

    hz=eta^14/65536 * [eta partial_u R0+24R0+lambda0],
    hx=eta^14/65536 * [eta partial_u S0+19S0],
    hp=Dr hx + partial_r[r^2 partial_u hz].

The measured-data operator is at most order five. Lambda0 and its derivatives through order five vanish on every edge; its extension by zero is C5, not a globally smooth bump. These traces suffice for the finitely many integrations by parts here. Kernels remain bounded on the regular compact window.

## Angular normalization and deterministic radius

The actual angular test must be lambda=lambda0 H2. If lambda0 alone were used over the full sphere, integral H2=0 and this moment would vanish. Both primitive kernels carry the same H2: HW=hz H2 and Hpsi=hp H2. Define radial/time quantities

    m0=integral_window lambda0 E0,
    nz=integral_window hz^2, np=integral_window hp^2, n0=nz+np.

Then integral_sphere H2^2=4pi/5 and the full weak moment and squared kernel norm are

    M=(4pi/5)m0, Nfull=(4pi/5)n0.

M equals the primitive-only moment by integration by parts. Since the u,r window has area one and each of the two arbitrary pointwise primitive errors is bounded by epsilon on the FULL sphere, their joint L2 norm is at most epsilon sqrt(8pi). Cauchy-Schwarz therefore gives

    |delta M| <= epsilon Q2,
    Q2=sqrt(8pi Nfull)=4pi sqrt(2n0/5).

The resulting nominal exact-record rejection radius is

    epsilon_nom=M/Q2=m0/sqrt(10n0).

With full-integral notation m=M and n=Nfull, the identical formula is m/sqrt(8pi n). Suppressing angular normalization or restricting the errors to H2 without stating that stronger hypothesis gives a different and unjustified prefactor.

The exact pointwise bound is epsilon Q1, Q1=integral(|HW|+|Hpsi|). For reference, integral_sphere |H2|=8pi/(3sqrt(3)), so a sharper valid upper bound using the known angular kernel is Q1 <= (8pi/(3sqrt(3)))(sqrt(nz)+sqrt(np)) <= (8pi/(3sqrt(3)))sqrt(2n0). These are optional conservative refinements; no optimality claim is made for Q2.

For a nominal EXACT supplied record, the necessary feasible condition |M_record|<=epsilon Q2 excludes this candidate whenever epsilon<epsilon_nom. For a guarantee for EVERY record within epsilon of that exact record, |M_record|>=M-epsilon Q2. This bound guarantees rejection under the stricter sufficient condition

    M-epsilon Q2 > epsilon Q2,
    epsilon < epsilon_nom/2.

The factor two accounts for both movement of the measured moment and the acceptance band. Equality does not guarantee rejection. These are fixed-candidate deterministic bounds, not confidence levels, parameter-identification theorems or optimal error radii.

## Predeclared executable calculation

Use independent exact rational polynomial arithmetic in x=u+3/2 and y=r-1/2 on [0,1]^2. Integrating a polynomial is the finite coefficient sum c_ij/[(i+1)(j+1)]. Alternatively m0 is a finite beta-weighted sum after separating lambda0. Compute the displayed residual directly from the original factorized operators; compare against the hand-derived E0, both kernel constructions, and the primitive-only moment. Compute exact rational m0,nz,np if tractable within separately bounded 120-second processes. Preserve any failures/timeouts. Do not change the window or supplied mode to make a test pass.

The true reception-gain branch may serve as a local sign control using Vg=gZ, beta=g_u/(ag), Ftrue=d(TX-beta X)+eX and Ttrue=W-2beta B; its commutator residual should vanish. This does not rerun or purport to establish the complete physical fixture, which was supplied in the neutral contract.
