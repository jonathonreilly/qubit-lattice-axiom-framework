# Independent physical weak-test findings before author exposure

No new root physical-weak code or results were read. The fixed background, mode, primitive records and window came from the neutral task contract. The hand derivation was frozen before code. These are conditional mathematical controls of one wrong constant-gain candidate on the supplied same background, not a rank, uniqueness or empirical result.

The wrong-candidate strong residual is

    E = [(u-r)^14/1966080]
        *[-3u^3+93u^2r-441ur^2+479r^3] H2.

Its scalar amplitude is strictly positive on the declared window, and equals 127/15 at u=-1,r=1. The true reception-gain branch's corresponding necessary residual vanishes exactly. These checks use the given mode; they do not rerun the complete physical fixture.

For the angular test lambda=lambda0 H2, define radial/time m0=integral lambda0 E0 and nz,np as the squared norms of the radial kernel amplitudes. Exact integration gives

    m0 = 82420778194507/517675892882551603200
       = 1.5921308936285801142229894585e-7,

    nz+np =
      11878872363976435942973941984452422164495789
      /24129742769416005705210311400610030430453760000
      = 4.9229171141570074407440370045e-4.

The exact primitive-only integral agrees with m0. A separate beta-weight integration also agrees. Reversing the primitive path-adjoint sign changes the moment by the nonzero value -484743321021209/6507925510523505868800. Individual exact norms are preserved in integrals_attempt02.stdout.json.

Both angular kernels carry H2=P2, so the FULL-sphere moment is M=(4pi/5)m0 and the FULL squared kernel norm is Nfull=(4pi/5)(nz+np). If each arbitrary primitive error is pointwise bounded by epsilon over the full sphere and unit-area u,r window, a conservative deterministic bound is

    |delta M| <= epsilon Q2,
    Q2=sqrt(8pi Nfull)=4pi sqrt[2(nz+np)/5]
      = 0.17634011576012010794... .

Thus nominal exact-record rejection is certified for

    epsilon < m0/sqrt[10(nz+np)]
            = 2.2691724783853541066e-6.

Guaranteed rejection for EVERY epsilon-perturbed record, using the same acceptance band, requires the stricter sufficient condition

    epsilon < m0/[2sqrt(10(nz+np))]
            = 1.1345862391926770533e-6.

The factor two includes both the possible shift in the tested moment and its allowed error band. These bounds are conservative, not optimal confidence radii. Exact angular absolute-norm information gives optional stronger bounds, recorded separately; it does not justify treating generic record errors as a pure H2 mode. If the full-sphere test used lambda0 with no H2 factor, its moment would instead vanish by angular orthogonality.

Execution evidence: algebra v1 passed 24/0 in 2.204 s. The first integral attempt failed in 1.224 s because SymPy scalar division converted a Poly to an Add before .terms(); its source, empty stdout, traceback and receipt are preserved. Version 2 only normalizes the same exact expressions back to Poly. It passed 10/0 in 1.484 s with unchanged equations, mode and window. Both successful and failed processes had a 120-second bound and disabled bytecode writes. Counts include related algebraic controls and are not independent experiments. Python/SymPy are shared software, with no second-CAS claim.

All calculations and metadata are within this owned directory. No author source or previous frozen check was changed. Ready for a bounded comparison after freezing these bytes.
