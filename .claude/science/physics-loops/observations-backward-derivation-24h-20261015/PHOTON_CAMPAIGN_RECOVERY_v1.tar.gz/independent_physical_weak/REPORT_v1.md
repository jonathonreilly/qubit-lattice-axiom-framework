# Focused physical weak-test comparison

The supplied author v3 residual, primitive kernels, exact moment and squared norms agree with the independently frozen derivation and calculations. Its full-sphere error prefactor and factor-two distinction are correct under the stated equal pointwise envelopes in both primitive channels. No mathematical correction is requested for this bounded example. This is one fixed-background candidate rejection test, not a rank, uniqueness, empirical or formal-audit result.

## Exact source and independence boundary

The hand derivation was frozen at 2026-10-16 14:06:30Z before executable calculations. INDEPENDENT_OUTPUT_FREEZE_v1.json freezes all 18 pre-author files before the two author sources were exposed at 14:13:21Z. All those bytes remain unchanged.

| Compared author file | SHA256 |
|---|---|
| check_physical_weak_v3.py | dd11cf15b95cc0c736b7f9e06d5ee5ea747080545f8425cbf2e827417a7c74a7 |
| PHYSICAL_WEAK_CONTROLS_v3.json | 92046952ee1eaba3bcc53ec656e0192afb1a1ebbdcc486355865cf2b8156b51f |

Complete copies and original paths are in author_snapshot_v1 and AUTHOR_SNAPSHOT_v1.json. The full v3 source and output were read. Earlier root v1/v2 programs and recovery receipts were unnecessary for this mathematical comparison and were not inspected; their preservation is not certified here. The author's 105.593-second run was not repeated. No canonical milestone source or other author file was changed.

## Agreement of residual and primitive pairing

Removing the common H2=P2 angular factor, the wrong constant-gain residual on the SAME supplied background is

    E0=(u-r)^14[-3u^3+93u^2r-441ur^2+479r^3]/1966080.

It is positive on the specified window and equals 127/15 at u=-1,r=1. The author eta-coordinate polynomial is exactly this expression. The true reception-gain branch's necessary residual vanishes, providing a separate sign control; neither checker newly establishes the complete supplied action fixture.

The independent route used the reverse-composed adjoints of the factored strong operator. The author's route expanded the common-gain coefficients and then constructed their adjoints. The short post-exposure comparison proves their generic redshift and intermediate lensing kernels equal, and verifies the primitive path-adjoint sign after converting the author's fixed-u derivative D=partial_r-partial_eta. This is post-exposure correspondence, distinct from the prior independent derivation.

Exact radial/time integration gives

    m0=82420778194507/517675892882551603200
      =1.59213089362858011422e-7,

    nz+np=
      11878872363976435942973941984452422164495789
      /24129742769416005705210311400610030430453760000
      =4.92291711415700744074e-4.

The individual nz and np agree exactly with both author fields. A separate beta-weight integral and the primitive-only pairing both give the same m0. The test's vanishing edge traces through order five suffice for these integrations by parts; its zero extension is C5, not a globally smooth bump.

## Sphere factor and deterministic rejection

The test is lambda=lambda0 H2 and both angular kernels carry H2. The JSON kernel norms are radial/time square-domain norms: full-sphere squared norms require the factor 4pi/5. Thus

    M=(4pi/5)m0, Nfull=(4pi/5)(nz+np).

For arbitrary errors in EACH primitive bounded pointwise by epsilon on the full sphere and unit-area u,r window, their joint L2 norm is at most epsilon sqrt(8pi). Therefore

    |delta M|<=epsilon Q2,
    Q2=4pi sqrt[2(nz+np)/5]=0.17634011576012010794... .

Nominal exact-record rejection is certified by the strict sufficient inequality

    epsilon < m0/sqrt[10(nz+np)]
            =2.2691724783853541066e-6.

For EVERY record perturbed from that exact record by errors bounded by epsilon, the tested moment can move by epsilon Q2 and its feasibility band is also epsilon Q2. The corresponding sufficient guarantee is

    epsilon < m0/[2sqrt(10(nz+np))]
            =1.1345862391926770533e-6.

The author squared thresholds and stated strictness agree exactly. These are conservative deterministic certificates, not optimal radii or confidence levels. The errors are not assumed to have H2 angular dependence. Using a radial-only test on the full sphere would give zero by angular orthogonality. The sharper angular estimates in the independent evidence remain optional post-fixed-test refinements; they do not replace or enlarge the author's predeclared fixed-test result.

The unit-coefficient P=r^2 H2 basis mode is not itself a uniformly small perturbation across this window. For a sufficiently small physical amplitude c_signal, all supplied linear perturbations and records scale together. The residual and m0 scale by c_signal; candidate kernels and nz,np remain unchanged. Both absolute epsilon thresholds therefore scale by |c_signal|. The author's explicit small-amplitude caveat is necessary and correct. The quoted numerical bounds are not apparatus noise requirements inferred from observations.

## Execution and read closure

Independent algebra: 24/0 in 2.204 s. First integral attempt: a real Poly-to-Expr interface error in 1.224 s, preserved with its original source, empty stdout, traceback and receipt. Its narrow recovery converts the same exact expressions back to Poly, leaving all mathematics and inputs fixed; recovered integrals: 10/0 in 1.484 s. The post-exposure generic-kernel and exact-output comparison passed 12/0 in 0.515 s. Counts overlap and are not independent experiments.

All child processes were bounded at 120 seconds with bytecode disabled. The independent programs read no repository scientific inputs; their supplied constants are explicit in source and the neutral contract. The post-comparison reads only its declared local snapshots, the frozen independent output and freeze record. The author source, if run, constructs its inputs and reads its own bytes only for integrity; it was inspected, not executed here. Full stdout/stderr, software versions, resource measurements and input identities are preserved. Python/SymPy are shared software; no independent-CAS claim is made.

The pre-author derivation, executable output and failed attempt remain intact. The next physical obligation is a justified primitive record, error envelope, registration convention and small-signal regime. This fixed synthetic rejection certificate does not establish them or select a unique gain/background history.
