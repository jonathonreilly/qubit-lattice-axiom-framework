"""Independent physical weak test from the neutral fixed-action contract.

No root physical-weak code/results read or imported. The full supplied physics
fixture is not rerun; the wrong/true gained necessary equations are checked.
"""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import hashlib,json,sys,time
from functools import lru_cache
import sympy as s
CASE=sys.argv[1];checks=[];details={};start=time.monotonic()
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
    print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
def zero(name,value):
    z=s.factor(s.cancel(s.expand(value)));check(name,z==0,str(z))
def stage(name):print('STAGE '+name,file=sys.stderr,flush=True)
if CASE=='algebra':
    u,r=s.symbols('u r',real=True);eta=u-r
    a=256/eta**8;q0=1/a;h=-eta**7/32;C=-eta**7/256;d=-256/eta**7;e=s.Integer(4)
    T=lambda f:q0*s.diff(f,u);L=lambda f:q0*(2*s.diff(f,u)+s.diff(f,r))
    Dr=lambda f:s.diff(r*r*s.diff(f,r),r)/2;Q=lambda f:r*r*s.diff(f,r)/2
    K=T(C)+h*C;k=T(K)/K
    g=(u+11)/10;P=r*r;Z=128*eta**(-7)*r*r;Y=eta*r-s.Rational(7,2)*r*r
    psi=g*r*r/3;zobs=g*Y;X=Dr(psi);B=a*Q(psi);W=zobs+2*s.diff(Q(psi),u)
    F=d*T(X)+e*X;N=T(W)+(h+C)*W+L(F)+h*F
    residual=L(N)-k*N+K*W
    expected=eta**14*(-3*u**3+93*u*u*r-441*u*r*r+479*r**3)/1966080
    nexp=-eta*eta*r/10+s.Rational(11,10)*eta*r*r-s.Rational(11,20)*r*r-s.Rational(13,20)*r**3
    zero('background commutator K',K-eta**14/65536)
    zero('background logarithmic k',k-14*eta**7/256)
    zero('recorded X primitive extraction',X-g*P)
    zero('recorded W includes reception path term',W-g*Y-r**3/15)
    zero('wrong F hand derivation',F-r*r*(3*eta+4*r+44)/10)
    zero('wrong N hand derivation',N-eta**7*nexp/256)
    zero('wrong strong residual hand polynomial',residual-expected)
    zero('wrong strong residual reference value',residual.subs({u:-1,r:1})-s.Rational(127,15))
    # Supplied true gain branch provides a sign/normalization control.
    beta=s.diff(g,u)/(a*g);Vg=g*Z;Ft=d*(T(X)-beta*X)+e*X;Tt=W-2*beta*B
    Nt=T(Tt)+(h+C-beta)*Tt+L(Ft)+(h-2*beta)*Ft
    zero('true primitive forcing',Tt-g*Y)
    zero('true gained temporal equation',T(Vg)+(C-beta)*Vg+Ft)
    zero('true gained characteristic equation',L(Vg)-2*beta*Vg-Tt)
    zero('true gained commutator',Nt+K*Vg)
    zero('true gained strong residual',L(Nt)-(2*beta+k)*Nt+K*Tt)
    # Adjoints are derived from vector-field divergence in flat du dr measure.
    zero('T divergence fixes adjoint',s.diff(q0,u)+h)
    zero('L divergence fixes adjoint',2*s.diff(q0,u)+s.diff(q0,r)+h)
    lam=s.Function('lambda')(u,r)
    Td=lambda f:-T(f)+h*f;Ld=lambda f:-L(f)+h*f
    p0=Ld(lam)-k*lam;p1=Ld(p0)+h*p0
    hz=Td(p0)+(h+C)*p0+K*lam;hx=Td(d*p1)+e*p1
    D=lambda f:2*s.diff(f,u)+s.diff(f,r)
    R0=eta*D(lam)+22*lam;S0=eta*D(R0)+23*R0
    zero('polynomial hz equals reverse-composed adjoint',hz-eta**14*(eta*s.diff(R0,u)+24*R0+lam)/65536)
    zero('polynomial hx equals reverse-composed adjoint',hx-eta**14*(eta*s.diff(S0,u)+19*S0)/65536)
    v=s.Function('v')(u,r)
    Qd=lambda f:-s.diff(r*r*f,r)/2
    zero('primitive path-adjoint sign',Qd(-2*s.diff(v,u))-s.diff(r*r*s.diff(v,u),r))
    z=s.symbols('z',real=True);H2=(3*z*z-1)/2;z0=1/s.sqrt(3)
    angular2=2*s.pi*s.integrate(H2**2,(z,-1,1))
    angular1=4*s.pi*(-s.integrate(H2,(z,0,z0))+s.integrate(H2,(z,z0,1)))
    zero('full sphere squared H2 normalization',angular2-4*s.pi/5)
    zero('full sphere absolute H2 normalization',angular1-8*s.pi/(3*s.sqrt(3)))
    zero('radial-only angular test would vanish',s.integrate(H2,(z,-1,1)))
    m,n=s.symbols('m n',positive=True)
    zero('full-sphere Cauchy radius conversion',(4*s.pi*m/5)/s.sqrt(8*s.pi*(4*s.pi*n/5))-m/s.sqrt(10*n))
    check('window eta avoids zero',s.Rational(-3)<s.Rational(-1)<0)
    check('true gain positive throughout declared window',s.Rational(19,20)>0)
    details['strong_amplitude']=str(s.factor(expected))
    details['kernel_formula_scope']='Generic lambda; independent direct factorized adjoints, no author coefficient implementation.'
elif CASE=='integrals':
    x,y=s.symbols('x y');P=lambda z:s.Poly(z,x,y,domain=s.QQ)
    eta=P(x-y-2);rr=P(y+s.Rational(1,2));uu=P(x-s.Rational(3,2))
    lam=P((x*(1-x)*y*(1-y))**6)
    D=lambda z:2*z.diff(x)+z.diff(y)
    Dr=lambda z:(rr*rr*z.diff(y).diff(y)+2*rr*z.diff(y))/2
    stage('polynomial kernels')
    R0=eta*D(lam)+22*lam;S0=eta*D(R0)+23*R0
    hz=eta**14*(eta*R0.diff(x)+24*R0+lam)/65536
    hx=eta**14*(eta*S0.diff(x)+19*S0)/65536
    path=(rr*rr*hz.diff(x)).diff(y)
    hp=Dr(hx)+path
    E0=eta**14*(-3*uu**3+93*uu*uu*rr-441*uu*rr*rr+479*rr**3)/1966080
    g=(uu+11)/10;psi=g*rr*rr/3;zobs=g*(eta*rr-s.Rational(7,2)*rr*rr)
    # SymPy Poly/scalar division can return Expr; normalize the exact polynomial interface.
    hz,hx,hp,E0,psi,zobs,path=[P(z) for z in [hz,hx,hp,E0,psi,zobs,path]]
    def integral(poly):
        poly=P(poly)
        den,integer=poly.clear_denoms(convert=True)
        return sum((s.Rational(c,den*(i+1)*(j+1)) for (i,j),c in integer.terms()),s.S.Zero)
    @lru_cache(None)
    def beta6(i):return s.Rational(s.factorial(i+6)*s.factorial(6),s.factorial(i+13))
    stage('exact strong and primitive moments')
    m=integral(lam*E0)
    m_beta=sum((c*beta6(i)*beta6(j) for (i,j),c in E0.terms()),s.S.Zero)
    m_primitive=integral(hz*zobs+hp*psi)
    check('strong moment equals separate beta-weight integration',m==m_beta)
    check('strong equals primitive-only exact moment',m==m_primitive)
    check('exact wrong-candidate moment strictly positive',m>0)
    wrong_sign=integral(hz*zobs+(Dr(hx)-path)*psi)
    check('reversed primitive path-adjoint sign is detected',wrong_sign!=m,{'wrong_minus_right':str(wrong_sign-m)})
    # Edge vanishing through order five is verified before invoking the adjoints.
    for var in [x,y]:
        edge=True
        for order in range(6):
            dv=lam
            for _ in range(order):dv=dv.diff(var)
            edge=edge and dv.eval(var,0).is_zero and dv.eval(var,1).is_zero
        check('test boundary traces through five for '+str(var),edge)
    stage('exact redshift kernel norm')
    nz=integral(hz*hz)
    stage('exact lensing kernel norm')
    np=integral(hp*hp);n=nz+np
    check('redshift kernel squared norm positive',nz>0)
    check('lensing kernel squared norm positive',np>0)
    nom=m/s.sqrt(10*n);robust=nom/2
    angular_l1_bound_radius=3*s.sqrt(3)*m/(10*(s.sqrt(nz)+s.sqrt(np)))
    angular_joint_bound_radius=3*s.sqrt(6)*m/(20*s.sqrt(n))
    check('known angular shape gives at least the conservative full L2 radius',s.N(angular_joint_bound_radius-nom,50)>0)
    check('separate radial Cauchy improves joint radial Cauchy',s.N(angular_l1_bound_radius-angular_joint_bound_radius,50)>0)
    def identity(poly):
        terms=[[[i,j],str(c)] for (i,j),c in poly.terms()]
        return {'terms':len(terms),'total_degree':poly.total_degree(),'degree_x':poly.degree(x),'degree_y':poly.degree(y),'exact_term_encoding_sha256':hashlib.sha256(json.dumps(terms,separators=(',',':')).encode()).hexdigest()}
    details={'window_shift':'x=u+3/2,y=r-1/2 in [0,1]^2','radial_time_moment':str(m),'radial_time_moment_decimal':str(s.N(m,50)),
      'radial_nz':str(nz),'radial_np':str(np),'radial_nz_plus_np':str(n),'radial_norm_sum_decimal':str(s.N(n,50)),
      'full_moment':'(4*pi/5)*m0','full_kernel_squared_norm':'(4*pi/5)*(nz+np)',
      'nominal_conservative_epsilon_radius':str(s.N(nom,50)),'guaranteed_all_perturbations_epsilon_radius':str(s.N(robust,50)),
      'optional_angular_joint_Cauchy_radius':str(s.N(angular_joint_bound_radius,50)),
      'optional_angular_separate_Cauchy_radius':str(s.N(angular_l1_bound_radius,50)),
      'full_L2_error_prefactor_Q2':'4*pi*sqrt(2*(nz+np)/5)','full_L2_error_prefactor_decimal':str(s.N(4*s.pi*s.sqrt(2*n/5),50)),
      'primitive_moment':str(m_primitive),'kernel_hz':identity(hz),'kernel_hp':identity(hp),
      'error_scope':'Each primitive error is arbitrary pointwise <=epsilon over full sphere, not restricted to H2; strict sufficient bounds, not optimal/confidence radii.'}
else:raise ValueError('Choose algebra or integrals')
out={'stage':'Independent before new root physical-weak exposure','root_new_physical_weak_sources_read':False,
 'software':{'python':sys.version.split()[0],'sympy':s.__version__},'checks':checks,
 'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},'details':details,
 'wall_seconds':time.monotonic()-start,'scope':'One fixed-background wrong constant gain, exact supplied records; no rank, uniqueness or empirical claim'}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
