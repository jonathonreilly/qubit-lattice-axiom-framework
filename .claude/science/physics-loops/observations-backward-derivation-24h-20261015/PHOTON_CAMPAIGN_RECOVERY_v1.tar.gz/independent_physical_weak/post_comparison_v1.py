"""Bounded post-exposure correspondence, not replay of the author runner."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[
 'author_snapshot_v1/check_physical_weak_v3.py',
 'author_snapshot_v1/PHYSICAL_WEAK_CONTROLS_v3.json',
 'integrals_attempt02.stdout.json',
 'INDEPENDENT_OUTPUT_FREEZE_v1.json',
]
import hashlib,json,sys,time
from pathlib import Path
import sympy as s
here=Path(__file__).resolve().parent;start=time.monotonic();checks=[]
def check(name,v,detail=None):
    checks.append({'name':name,'pass':bool(v),'detail':detail});print(('PASS ' if v else 'FAIL ')+name,file=sys.stderr,flush=True)
def zero(name,e):
    v=s.factor(s.cancel(s.expand(e)));check(name,v==0,str(v))
author=json.loads((here/AUDIT_INPUT_PATHS[1]).read_text())
ind=json.loads((here/AUDIT_INPUT_PATHS[2]).read_text())['details']
check('author source bound to supplied result',hashlib.sha256((here/AUDIT_INPUT_PATHS[0]).read_bytes()).hexdigest()==author['source_sha256'])
eta,r=s.symbols('eta r',real=True)
published=s.sympify(author['strong_wrong'],locals={'eta':eta,'r':r})
hand=eta**14*(-eta**3/s.Integer(10)+14*eta*eta*r/s.Integer(5)-44*eta*r*r/s.Integer(5)+64*r**3/s.Integer(15))/65536
zero('author strong polynomial equals frozen independent polynomial',published-hand)
m=s.Rational(ind['radial_time_moment']);nz=s.Rational(ind['radial_nz']);np=s.Rational(ind['radial_np'])
check('exact radial moment agrees',s.Rational(author['moment_square_domain'])==m)
check('exact primitive pairing agrees',s.Rational(author['primitive_pair_square_domain'])==m)
check('exact redshift norm agrees',s.Rational(author['kernel_L2_squared']['redshift'])==nz)
check('exact lensing norm agrees',s.Rational(author['kernel_L2_squared']['lensing'])==np)
zero('full-sphere moment normalization agrees',s.sympify(author['moment_full_sphere'])-4*s.pi*m/5)
check('nominal epsilon square agrees',s.Rational(author['nominal_record_rejection_error_squared'])==m*m/(10*(nz+np)))
check('all-perturbations epsilon square agrees',s.Rational(author['uniform_bounded_noise_rejection_error_squared'])==m*m/(40*(nz+np)))
# The following is an exposed coefficient/adjoint transcription, independently
# compared with the pre-exposure reverse-composition kernels for generic lambda.
q=eta**8/256;h=-eta**7/32;C=-eta**7/256;d=-256/eta**7;e=s.Integer(4)
T=lambda z:q*s.diff(z,eta);L=lambda z:q*(s.diff(z,eta)+s.diff(z,r))
Dc=lambda z:s.diff(z,r)-s.diff(z,eta)
R=lambda z:Dc(r*r*Dc(z))/2;Qd=lambda z:-Dc(r*r*z)/2
Td=lambda z:-T(z)+h*z;Ld=lambda z:-L(z)+h*z
K=T(C)+h*C;k=14*eta**7/256;A=h+C;mm=T(d)+h*d;nn=L(e)+h*e
th=[-k,C,L(A)-k*A+K-T(h),d,T(d)+mm-k*d,L(mm)-k*mm,e,L(e)+nn-k*e,L(nn)-k*nn]
lam=s.Function('lambda')(eta,r)
HW=Td(Ld(lam))+Ld((h+th[1])*lam)+Td(th[0]*lam)+(T(h)+th[2])*lam
HX=Td(Ld(Ld(th[3]*lam)))+Td(Ld(th[4]*lam))+Td(th[5]*lam)+Ld(Ld(th[6]*lam))+Ld(th[7]*lam)+th[8]*lam
D=lambda z:s.diff(z,eta)+s.diff(z,r)
R0=eta*D(lam)+22*lam;S0=eta*D(R0)+23*R0
hz=eta**14*(eta*s.diff(R0,eta)+24*R0+lam)/65536
hx=eta**14*(eta*s.diff(S0,eta)+19*S0)/65536
zero('author generic HW equals independent adjoint kernel',HW-hz)
zero('author generic HX equals independent adjoint kernel',HX-hx)
zero('author primitive path-adjoint convention equals independent one',R(hx)-2*Qd(s.diff(hz,eta))-(R(hx)+Dc(r*r*s.diff(hz,eta))))
out={'stage':'Post-exposure source/result correspondence; author full runner not executed','source_bindings':{n:hashlib.sha256((here/n).read_bytes()).hexdigest() for n in AUDIT_INPUT_PATHS},
 'checks':checks,'summary':{'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)},'wall_seconds':time.monotonic()-start,
 'scope':'Current bounded v3 equations/kernels/exact outputs only; earlier root failure/recovery receipts not inspected; optional sharper angular estimates are outside the author predeclared fixed-test result.'}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
