"""Bound and preserve independent physical weak-test evidence."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=['NEUTRAL_CONTRACT_v1.json','DERIVATION_BEFORE_CODE_v1.md','PRE_CODE_FREEZE_v1.json','independent_controls_v2.py','run_bounded_v2.py']
import argparse,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
ap=argparse.ArgumentParser();ap.add_argument('--case',required=True,choices=['algebra','integrals']);ap.add_argument('--attempt',required=True);args=ap.parse_args()
if not args.attempt.replace('_','').isalnum():raise ValueError('Simple unused attempt name required')
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if any(prefix.with_suffix(x).exists() for x in ['.run.json','.stdout.json','.stderr.txt']):raise FileExistsError('Earlier evidence is immutable')
def bind():return {n:{'sha256':hashlib.sha256((here/n).read_bytes()).hexdigest(),'bytes':(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind();argv=[sys.executable,'-B',str(here/'independent_controls_v2.py'),args.case]
started=datetime.now(timezone.utc).isoformat();start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix('.stdout.json').open('wb') as of,prefix.with_suffix('.stderr.txt').open('wb') as ef:
    try:rc=subprocess.run(argv,cwd=here,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=of,stderr=ef,timeout=AUDIT_TIMEOUT_SEC,check=False).returncode
    except subprocess.TimeoutExpired:rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN);after=bind()
stdout=prefix.with_suffix('.stdout.json').read_bytes();stderr=prefix.with_suffix('.stderr.txt').read_bytes()
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
record={'case':args.case,'argv':argv,'cwd':str(here),'timeout_seconds':AUDIT_TIMEOUT_SEC,'PYTHONDONTWRITEBYTECODE':'1',
 'start_utc':started,'end_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':wall,'returncode':rc,'timed_out':timeout,
 'child_user_seconds':r1.ru_utime-r0.ru_utime,'child_system_seconds':r1.ru_stime-r0.ru_stime,'child_peak_rss_platform_units':r1.ru_maxrss,'platform':sys.platform,
 'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
 'output_parse_error':error,'summary':result['summary'] if result else None,'input_binding_before':before,'input_binding_after':after,'inputs_unchanged':before==after,
 'root_new_physical_weak_sources_read':False}
prefix.with_suffix('.run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['case','wall_seconds','returncode','timed_out','summary','inputs_unchanged']},indent=2))
if rc!=0 or timeout or before!=after:raise SystemExit(1)
