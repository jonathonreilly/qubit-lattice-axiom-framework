"""Bound the short correspondence check and preserve complete process output."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=['post_comparison_v1.py','run_post_comparison_v1.py','AUTHOR_SNAPSHOT_v1.json','author_snapshot_v1/check_physical_weak_v3.py','author_snapshot_v1/PHYSICAL_WEAK_CONTROLS_v3.json','integrals_attempt02.stdout.json','INDEPENDENT_OUTPUT_FREEZE_v1.json']
import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
here=Path(__file__).resolve().parent;prefix=here/'post_comparison_attempt01'
if any(prefix.with_suffix(x).exists() for x in ['.run.json','.stdout.json','.stderr.txt']):raise FileExistsError('Evidence exists')
def bind():return {n:hashlib.sha256((here/n).read_bytes()).hexdigest() for n in AUDIT_INPUT_PATHS}
before=bind();argv=[sys.executable,'-B',str(here/'post_comparison_v1.py')];start=time.monotonic();utc=datetime.now(timezone.utc).isoformat();r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix('.stdout.json').open('wb') as out,prefix.with_suffix('.stderr.txt').open('wb') as err:
    try:rc=subprocess.run(argv,cwd=here,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=out,stderr=err,timeout=AUDIT_TIMEOUT_SEC,check=False).returncode
    except subprocess.TimeoutExpired:rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN);after=bind();ob=prefix.with_suffix('.stdout.json').read_bytes();eb=prefix.with_suffix('.stderr.txt').read_bytes()
try:result=json.loads(ob);parse_error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;parse_error=repr(ex)
record={'argv':argv,'cwd':str(here),'start_utc':utc,'end_utc':datetime.now(timezone.utc).isoformat(),'timeout_seconds':AUDIT_TIMEOUT_SEC,'timed_out':timeout,'returncode':rc,'wall_seconds':wall,'PYTHONDONTWRITEBYTECODE':'1','child_user_seconds':r1.ru_utime-r0.ru_utime,'child_system_seconds':r1.ru_stime-r0.ru_stime,'child_peak_rss_platform_units':r1.ru_maxrss,'platform':sys.platform,'stdout_bytes':len(ob),'stdout_sha256':hashlib.sha256(ob).hexdigest(),'stderr_bytes':len(eb),'stderr_sha256':hashlib.sha256(eb).hexdigest(),'parse_error':parse_error,'summary':result['summary'] if result else None,'input_before':before,'input_after':after,'inputs_unchanged':before==after}
prefix.with_suffix('.run.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['wall_seconds','returncode','timed_out','summary','inputs_unchanged']},indent=2))
if rc!=0 or timeout or before!=after:raise SystemExit(1)
