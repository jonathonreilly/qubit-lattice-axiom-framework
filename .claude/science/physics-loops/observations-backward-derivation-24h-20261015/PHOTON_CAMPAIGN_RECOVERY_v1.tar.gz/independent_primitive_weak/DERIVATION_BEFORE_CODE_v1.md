# Independent primitive weak residual before author exposure

Only the neutral plan and the previously read photon note are used. Their exact bytes are copied and bound in INTAKE_v1.json. No new author primitive-weak derivation, runner or result has been read. Root remains lead author. This is conditional mathematical checking, not a formal audit or an empirical test.

## Operators, measure and adjoints

Use u=eta+r, r>0, the stipulated measure dmu=du dr dOmega, and a=a(u-r)>0. Write b=1/a and h=a_eta/a^2. Then b_u=-h and b_r=+h. At fixed angle,

    T=b partial_u,       L=b(2partial_u+partial_r),
    Q=(r^2/2)partial_r,  R=partial_r[(r^2/2)partial_r].

These radial derivatives hold u fixed. The formal adjoints for the flat stipulated measure are

    T*=-T+h,   L*=-L+h,
    Q*=-partial_r[(r^2/2) . ]=-(r^2/2)partial_r-r,
    R*=R.

Both divergence corrections are +h because 2b_u+b_r=-h. The r^2 in Q and R is part of the photon operator, not a radial-volume density in the integration measure. Using du r^2 dr dOmega would change the adjoints. Multiplication by real functions is self-adjoint; (AB)*=B*A*. In particular (L^2T)*=T*(L*)^2 and (LT)*=T*L*. The commutator [T,L]=h(T-L) generally prevents reversing these orders freely.

Take a real smooth compactly supported test weight w inside an open registered time/radial product chart and the available angular sector. No angular derivative occurs here. Compact support in u and r removes all integration-by-parts edges. The theorem uses C-infinity tests; finite-order polynomial controls may instead have the required vanishing edge jets. A moving edge or a nonzero boundary trace needs its explicit flux terms. Compact support does not remove the separate complete-interior/observer/source assumptions in the photon map.

## Reverse the entire source equation

Use the neutral contract's A_W, A_X and A_B. All coefficient functions and h'=T h are evaluated for one supplied smooth admissible candidate. Define

    vW = T* L* w + L*[(h+theta2)w]
                         +T*(theta1 w)+(h'+theta3)w,

    vX = T*(L*)^2(theta4 w)+T*L*(theta5 w)+T*(theta6 w)
                         +(L*)^2(theta7 w)+L*(theta8 w)+theta9 w
                         +(T*)^2(theta10 w),

    vB = (T*)^3(theta11 w)+(T*)^2(theta12 w)
                         +T*(theta13 w)+theta14 w.

Parentheses indicate operator composition on everything to their right. Derivatives act on coefficients as well as the test weight. Candidate functions must be regular enough for these composed kernels (smoothness is sufficient); this is not a claim about a minimal coefficient Sobolev class.

The primitive maps are X=R psi, B=a Q psi, W=z+2 partial_u Q psi. Therefore

    Kz = vW,
    Kpsi = R vX + Q*(a vB) - 2 Q* partial_u vW,

and the exact identity is

    integral w(A_W W+A_X X+A_B B) dmu
        = integral (Kpsi psi+Kz z) dmu.                  (1)

The path term has a minus sign from partial_u*=-partial_u; Q* is then applied to that result. The factor a multiplies vB before Q* acts. Neither may be omitted. Equivalently, writing c=r^2/2,

    Kpsi=partial_r(c partial_r vX)-partial_r(c a vB)
                                  +2partial_r(c partial_u vW).

No derivative of the primitive data is evaluated on the right. Derivatives have moved into known candidate/weight kernels, potentially up to fifth order; their norms may consequently be large.

For locally integrable primitives and smooth coefficients the left is defined distributionally by (1). Vanishing against every smooth compactly supported weight is exactly the distributional necessary residual equation. It is not equivalence to the full scalar/dust solution: all other original equations, reception integrability, cross-shell homogeneity and physical premises remain obligations. Finitely many weak moments are weaker still.

## Deterministic primitive-error bound and feasible candidates

Suppose true and recorded primitives share the registered contract, and on the support

    |psi_obs-psi_true| <= epsilon_psi,
    |z_obs-z_true| <= epsilon_z

pointwise almost everywhere, with known nonnegative envelopes. At each fixed admissible candidate c and weight w, linearity and the triangle inequality give

    |M_obs(c,w)-M_true(c,w)| <= B(c,w),
    B(c,w)=integral [|Kpsi(c,w)|epsilon_psi
                             +|Kz(c,w)|epsilon_z] dmu.   (2)

For constant envelopes this is epsilon_psi||Kpsi||_1+epsilon_z||Kz||_1. It is a valid bound for the recovered angular sector; sharpness under unrestricted independent L-infinity errors does not imply sharpness under additional angular/physical restrictions. This bound is deterministic, not a standard error or a physical-noise model.

For a finite chosen family of weights, define

    F_obs={c in the declared admissible class:
                  |M_obs(c,w_j)|<=B(c,w_j) for every j}.

If c_true is compatible with all original equations and the common continuum envelope holds, then M_true(c_true,w_j)=0 and c_true belongs to F_obs. No statistical independence of the chosen candidate or weights from observed data is needed for this pathwise necessary inclusion: for every realized admissible candidate/kernel, inequality (2) follows from the same error envelope. Data-dependent choices must still yield legitimate kernels and correctly computed bounds. They do not turn feasibility into a selector, a uniqueness proof, coverage probability or physical compatibility certificate.

The bound is per candidate. It does not imply a finite uniform kernel norm, stable parameter recovery or identifiability over the entire candidate class. Uncertainty in the geometry or source map changes the operators and needs additional kernel/input error terms. If one compares uncertain candidate kernels Khat with K, the exact difference includes integral((Khat-K) true_data) as well as the primitive-error term; it cannot be silently called primitive noise.

If only a quadrature estimate Mhat is computed, a certified |Mhat-M_obs|<=q_bound gives the necessary inequality |Mhat|<=B+q_bound; B itself needs a certified upper enclosure. Pointwise errors at sampled nodes alone neither bound continuum errors between nodes nor supply quadrature control. No stochastic confidence interpretation follows without separate assumptions.

Finite moments cannot generally identify a primitive field or candidate. For m kernels choose m+1 disjoint smooth bumps; their m-dimensional moment vectors have a nontrivial linear dependence. Thus a nonzero perturbation can leave all m moments unchanged. This does not prove nonidentifiability within every restricted physical candidate class, but prevents inferring it from finite tests alone. Our concrete single-moment witness will check this limitation without asserting another physical solution.

## Predeclared independent controls

Use u in [0,1], r=1+v with v in [0,1], full sphere, and s=3+u-v=4+eta. Set a=s^-2, h=-2s and h'=T h=-2s^2. This gives nonconstant geometry and noncommuting operators on a regular compact rectangle.

For i=1,...,14 choose

    theta_i=i+(i mod 3-1)u+(i mod 4-2)v+uv/(i+1).

These are arbitrary test coefficients, not asserted to satisfy the scalar background or reception conditions. Let H=P2(cos(theta)), with integral H^2 dOmega=4pi/5 and integral |H| dOmega=8pi/(3sqrt(3)). Use primitive amplitudes

    psi=1+u+u^2 r+r^2+u^3 r,
    z=2-u+r+u^2 r^2,
    w=s^4[u(1-u)v(1-v)]^6,

each multiplied by H for the data/weight. The weight has normal derivatives through order five zero at every rectangle edge; its zero extension is C5, sufficient for the finite-order checks. It is not falsely called a globally C-infinity polynomial bump.

Compute the direct strong integral and independently assembled primitive-kernel integral exactly by polynomial monomial integration, retaining the nonzero value. Check the divergence and observation-map signs and discriminate five fixed mutations: omitted divergence corrections, reversed highest-order adjoint ordering, omitted path term, omitted a factor in the B adjoint, and coefficient multiplication frozen outside the highest-order adjoint.

Use errors delta_psi=(2u-1)H/1000 and delta_z=(2v-1)H/2000. They satisfy the declared constant primitive envelopes. For a polynomial kernel sum c_ij u^i v^j on the unit square, integral |K| <= sum |c_ij|/((i+1)(j+1)). This yields an exact conservative bound after the angular L1 factor, without numeric quadrature. Its looseness will be reported. Also construct a nonzero z perturbation annihilating the one kernel moment and check that its strong residual is nonzero.

An edge countercheck uses w=1, psi=r for R on r in [1,2]: integral(w Rpsi-psi Rw)dr=3/2, exactly the missing boundary flux. Every computation is source-frozen before execution, bytecode disabled and bounded by 120 seconds per attempt. No original-action realization of the arbitrary-coefficient control, new observed array, optimized weight, selector or empirical uncertainty certificate is claimed.
