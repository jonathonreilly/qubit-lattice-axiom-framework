"""Frozen independent primitive weak check; no author imports or observed data."""
from pathlib import Path
from functools import lru_cache
import hashlib,json
import sympy as sp
u,v=sp.symbols('u v',real=True);r=1+v;s=3+u-v
a=1/s**2;h=-2*s;hp=-2*s**2;c=r**2/2
checks={};evidence={}
def normal(e):return sp.cancel(e)
def zero(name,e):
 z=normal(e);checks[name]=bool(z==0)
 if z!=0:evidence[name+'_failure']=str(z)
def test(name,b):checks[name]=bool(b)
@lru_cache(None)
def T(e):return normal(s*s*sp.diff(e,u))
@lru_cache(None)
def L(e):return normal(s*s*(2*sp.diff(e,u)+sp.diff(e,v)))
def Q(e):return normal(c*sp.diff(e,v))
def R(e):return normal(sp.diff(c*sp.diff(e,v),v))
def Qstar(e):return normal(-sp.diff(c*e,v))
@lru_cache(None)
def TS(e):return normal(-T(e)+h*e)
@lru_cache(None)
def LS(e):return normal(-L(e)+h*e)
@lru_cache(None)
def Tbad(e):return normal(-T(e))
@lru_cache(None)
def Lbad(e):return normal(-L(e))
def polynomial(e):return sp.Poly(normal(e),u,v,domain=sp.QQ)
def integral(e):
 p=polynomial(e)
 return sum((coef/sp.Integer((ij[0]+1)*(ij[1]+1)) for ij,coef in p.terms()),sp.S.Zero)
def norm_upper(e):
 p=polynomial(e)
 return sum((abs(coef)/sp.Integer((ij[0]+1)*(ij[1]+1)) for ij,coef in p.terms()),sp.S.Zero)
psi=1+u+u*u*r+r*r+u**3*r
z=2-u+r+u*u*r*r
w=sp.expand(s**4*(u*(1-u)*v*(1-v))**6)
th=[sp.Integer(i)+(i%3-1)*u+(i%4-2)*v+u*v/sp.Integer(i+1) for i in range(1,15)]
X=R(psi);B=normal(a*Q(psi));W=normal(z+2*sp.diff(Q(psi),u))
def AW(e):return normal(L(T(e))+(h+th[1])*L(e)+th[0]*T(e)+(hp+th[2])*e)
def AX(e):return normal(th[3]*L(L(T(e)))+th[4]*L(T(e))+th[5]*T(e)+th[6]*L(L(e))+th[7]*L(e)+th[8]*e+th[9]*T(T(e)))
def AB(e):return normal(th[10]*T(T(T(e)))+th[11]*T(T(e))+th[12]*T(e)+th[13]*e)
def adjoints(ts,ls):
 vw=normal(ts(ls(w))+ls((h+th[1])*w)+ts(th[0]*w)+(hp+th[2])*w)
 vx=normal(ts(ls(ls(th[3]*w)))+ts(ls(th[4]*w))+ts(th[5]*w)+ls(ls(th[6]*w))+ls(th[7]*w)+th[8]*w+ts(ts(th[9]*w)))
 vb=normal(ts(ts(ts(th[10]*w)))+ts(ts(th[11]*w))+ts(th[12]*w)+th[13]*w)
 return vw,vx,vb
def kernels(vw,vx,vb):return normal(R(vx)+Qstar(a*vb)-2*Qstar(sp.diff(vw,u))),vw
zero('T_geometry_divergence',sp.diff(1/a,u)+h)
zero('L_geometry_divergence',2*sp.diff(1/a,u)+sp.diff(1/a,v)+h)
zero('matter_hprime',T(h)-hp)
zero('noncommuting_T_L',T(L(psi))-L(T(psi))-h*(T(psi)-L(psi)))
traces=[sp.diff(w,var,k).subs(var,edge) for var in (u,v) for edge in (0,1) for k in range(6)]
test('all_weight_normal_traces_through_five_vanish',all(normal(x)==0 for x in traces))
strong=normal(AW(W)+AX(X)+AB(B));Id=integral(w*strong)
vw,vx,vb=adjoints(TS,LS);kp,kz=kernels(vw,vx,vb)
Ip=integral(kp*psi+kz*z)
zero('exact_nonzero_strong_weak_equality',Id-Ip)
test('witness_has_nonzero_residual_moment',Id!=0)
zero('separate_AW_adjoint',integral(w*AW(W))-integral(vw*W))
zero('separate_AX_adjoint',integral(w*AX(X))-integral(vx*X))
zero('separate_AB_adjoint',integral(w*AB(B))-integral(vb*B))
zero('separate_primitive_pullback',integral(vw*W+vx*X+vb*B)-Ip)
evidence['strong_square_integral']=str(Id);evidence['primitive_square_integral']=str(Ip)
evidence['full_sphere_integral']=str(Id*4*sp.pi/5)
evidence['full_sphere_integral_numeric']=str(sp.N(Id*4*sp.pi/5,18))
mutations={}
bw,bx,bb=adjoints(Tbad,Lbad);bp,bz=kernels(bw,bx,bb)
mutations['omitted_variable_divergences']=integral((bp-kp)*psi+(bz-kz)*z)
ordered=normal(LS(LS(TS(th[3]*w)))-TS(LS(LS(th[3]*w))))
mutations['reversed_highest_adjoint_order']=integral(R(ordered)*psi)
mutations['omitted_path_adjoint']=integral(2*Qstar(sp.diff(vw,u))*psi)
mutations['omitted_a_in_B_adjoint']=integral((Qstar(vb)-Qstar(a*vb))*psi)
frozen=normal(th[3]*TS(LS(LS(w)))-TS(LS(LS(th[3]*w))))
mutations['coefficient_frozen_outside_adjoint']=integral(R(frozen)*psi)
for name,delta in mutations.items():test('mutation_detected/'+name,delta!=0)
evidence['mutation_square_integral_changes']={k:str(q) for k,q in mutations.items()}
# Certified conservative polynomial L1 envelopes on the unit square.
ep=sp.Rational(1,1000);ez=sp.Rational(1,2000)
dp=ep*(2*u-1);dz=ez*(2*v-1)
actual=integral(kp*dp+kz*dz);np=norm_upper(kp);nz=norm_upper(kz);budget=ep*np+ez*nz
# Removing the common pi, compare squares to avoid any floating inequality.
lhs=sp.Rational(4,5)*abs(actual)
test('bounded_primitive_error_certificate',lhs*lhs<=sp.Rational(64,27)*budget*budget)
test('primitive_error_changes_moment',actual!=0)
evidence['primitive_error_square_moment']=str(actual)
evidence['kernel_square_L1_upper']={'psi':str(np),'z':str(nz)}
evidence['full_error_moment_numeric']=str(sp.N(abs(actual)*4*sp.pi/5,18))
evidence['certified_full_error_bound_numeric']=str(sp.N(budget*8*sp.pi/(3*sp.sqrt(3)),18))
evidence['bound_to_actual_ratio']=str(sp.N((budget*8*sp.pi/(3*sp.sqrt(3)))/(abs(actual)*4*sp.pi/5),18))
# One necessary moment does not imply the strong residual, even at fixed coefficients.
j0=integral(kz);j1=integral(kz*u);dznull=j1-j0*u
zero('finite_moment_null_perturbation',integral(kz*dznull))
test('finite_moment_perturbation_nonzero',normal(dznull)!=0)
test('finite_moment_strong_residual_nonzero',normal(AW(dznull))!=0)
evidence['finite_moment_null_z']=str(dznull)
evidence['finite_moment_strong_residual_at_point']=str(normal(AW(dznull)).subs({u:sp.Rational(1,3),v:sp.Rational(2,5)}))
# Deliberately nonvanishing edge weight: the formal identity needs its flux.
boundary=integral(R(r));flux=(c.subs(v,1)-c.subs(v,0))
zero('noncompact_edge_flux',boundary-flux)
zero('boundary_counterexample_value',boundary-sp.Rational(3,2))
# Explicit angular factors, including the absolute-value split at 1/sqrt(3).
x=sp.symbols('x',real=True);H=(3*x*x-1)/2
zero('angular_L2_factor',sp.integrate(H*H,(x,-1,1))-sp.Rational(2,5))
zero('angular_L1_factor',4*sp.integrate(H,(x,1/sp.sqrt(3),1))-4/(3*sp.sqrt(3)))
# Preserve exact kernel polynomials, not only their moment or a float rendering.
ks={name:{'terms':[[i,j,str(coef)] for (i,j),coef in polynomial(e).terms()],'degree':polynomial(e).total_degree()} for name,e in [('Kpsi',kp),('Kz',kz)]}
kpath=Path(__file__).parent/'KERNEL_POLYNOMIALS_v1.json'
assert not kpath.exists();kb=(json.dumps(ks,sort_keys=True,indent=2)+'\n').encode();kpath.write_bytes(kb)
evidence['kernel_file_sha256']=hashlib.sha256(kb).hexdigest();evidence['kernel_term_counts']={name:len(d['terms']) for name,d in ks.items()}
out={'scope':'Independent pre-author-exposure exact weak-operator test. Arbitrary smooth coefficients, not an original-action realization; no empirical data.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'passed':sum(checks.values()),'failed':sum(not b for b in checks.values()),'checks':checks,'evidence':evidence,'sympy':sp.__version__}
print(json.dumps(out,sort_keys=True,indent=2));raise SystemExit(bool(out['failed']))
