# Independent dynamic-candidate challenge

Read only RECEPTION_GAIN_DYNAMIC_CANDIDATE_v1.md after freezing it, plus previously frozen source and our prior reception-gain work. No new root implementation/output was inspected.

Write D=partial_tau-beta and E=L-2beta, with L=partial_tau+a^-1 partial_r at fixed matter time in the radial part. Since [partial_tau,L]=h(partial_tau-L) and reception form imposes Lbeta=2beta'+hbeta,

  [D,E]=h(D-E).

Put T=W-2beta B and F=[dD+e]X. The candidate equations are EV=T and (D+C)V=-F. Apply D to the first, use the commutator and second equation, and obtain

  (D+h+C)T+(E+h)F=-(C'+hC)V=-KV.

Thus N has exactly the displayed sign and terms. Because K depends only on tau, E(KV)=K EV+K'V, giving (E-K'/K)N+KT=0 for K!=0. The operator's multiplicative terms must not be treated as derivations; this product rule retains K' correctly.

B is not an arbitrary nuisance field. At fixed reception time I_X,r=X, and B=a I_X. Hence LB=2B'-hB+X. Commuting L with partial_tau gives LB'=2B''-(h'+h²)B+X'+hX. These path identities use the primitive and its complete registered interior convention, not an arbitrary boundary for an integral reconstructed from local X alone.

For an explicit full expansion, set

  A=h+C-beta,
  m=d'+(h-2beta)d,
  v=e-d beta,
  n=Lv+(h-2beta)v,
  t=beta'+beta(h+C-beta), k=K'/K.

Then

  N=W'+A W+d LX'+m X'+v LX+nX-2beta B'-2tB.

With target O=L(W')+hL(W)+h'W, the equation is O+sum theta_i column_i=0. The twelve coefficients in the note's order are

  theta1=-2beta-k,
  theta2=C-beta,
  theta3=LA-(2beta+k)A+K-h',
  theta4=d,
  theta5=Ld+m-(2beta+k)d,
  theta6=Lm-(2beta+k)m-2beta,
  theta7=v,
  theta8=Lv+n-(2beta+k)v,
  theta9=Ln-(2beta+k)n-2h beta-2t,
  theta10=-4beta,
  theta11=-2Lbeta+2(2beta+k)beta-4t,
  theta12=2beta(h'+h²)-2Lt+2ht+2(2beta+k)t-2Kbeta.

The five proposed decisive coefficients are therefore correct. At K=0, N=0 itself is a nonzero linear column relation (its W' coefficient is1), so the rank exclusion is justified. K!=0 alone does not guarantee rank.

## Independent original-equation fixture

For the stated power background choose c=sqrt(5/2), H_E=3/(2t), v=c/t, alpha=c, rE=1/(2t²), F=-7c/(2t²), mu=37/(4t²). Direct substitution verifies all four background equations. For P=t^m times a regular harmonic spatial profile, k_com²=0, momentum and Euler give

  U/P=-2(m+2)t/(m+4),
  J/P=(2m²+10m+10)/(m+4).

For m=0,-3/2,-2,-5/2, scalar perturbation is u=J/c and delta/P=-9/2 for m=0, otherwise3. Each mode satisfies momentum, Hamiltonian, scalar, Euler and dust continuity exactly. Their spatial solid harmonics have Delta=0 and l>=2, so no local l=0,1 metric kernel is substituted. This is a local fixture with no decay-at-infinity claim.

Set eta=-2/sqrt(t), P=eta^n r^ell Y_ell0 with n=0,3,4,5 and m=-n/2. Constant mode normalizations are immaterial. With gain(u)=(u+11)/10, build exact polynomial I_P=sum_{j=0}^n binomial(n,j)u^(n-j)(-1)^j r^(ell+j+1)/(ell+j+1). Compute X=gP, B=a g I_P, physical Y=Z_r/a-P-J, and W=gY+2g_u I_P before differentiating. This retains the path correction.

Using24 modes with ell=2,...,25 and n cycling as declared, all12column entries and O are evaluated exactly at eta=-2,r=1. The matrix has rank12, a nonzero rational12x12minor, and no column null vector. The unique solution of O+Mtheta=0 is

  (34/5,2/5,721/25,2,176/5,2484/25,
   19/5,1014/25,6024/125,-2/5,-16/25,77/125).

It agrees with every coefficient in the independent expansion. In particular it recovers beta=1/10,C=1/2,d=2,e=4. Direct background values also give K=1/4 and k=-7. Full matrices, target, minor rows/determinant and checks are in candidate_full_stdout.json. Thus there is no universal rank-destroying identity for these12columns over the declared physical class.

The modal rows are coefficients in independent angular harmonics on one common shell/time, not unrelated arbitrary jets. A finite sum is one original-equation solution. Since these angular functions are linearly independent, rank12 of their coefficient matrix implies some finite set of actual angular evaluation rows also has rank12. Adequate full-sky recovery or appropriate registered angular data are required. Mixing radii or reception times while treating beta-dependent coefficients as common would be invalid.

## Observation-contract limits

The candidate correctly retains W=gY+2beta B rather than replacing it with gY. It requires a single common positive primitive multiplier and calibrated source/path/observer conventions. Raw spectroscopic/redshift readout need not obey that contract without independent justification. Known a,h and registered conformal time remain supplied. Complete angular-sector recovery and the interior convention defining B are stronger than local P recovery alone.

Coefficient recovery at rank12 is a conditional local algebraic step. Original field equations, full coefficient identities, radial homogeneity of C,d,e and the reception-shape/integrability conditions on beta remain essential. They cannot be replaced by freely varying fitted rows. The fixture proves attainability, not generic rank, stability, a finite-data certificate or unique action/calibration selection across all other models. No author implementation/results were used and no empirical input was accessed.
