# Reception-time gain: independent source-bound derivation

Scope: the frozen scalar-metric canonical note's first-order Born/null maps on an open repeated-cone strip. No new JOINT_PHOTON_GAIN source was read. This is kinematic/calibration analysis, not a counterexample to fixed-background same-action uniqueness. Use eta for emission conformal time, u=eta+r for reception time, and a known registered background a(eta), H=a_eta/a. Define Y:=Rz=-Psi+v_r to avoid notation ambiguity; the derivative forcing used in the potential transport equation is W:=-(partial_u+H)Y. All u derivatives below hold cone radius fixed. Gains are positive smooth real multipliers of the indicated perturbation channels; multiplying an absolute raw redshift or an instrument's nonlinear output would require a separate measurement model.

## 1. Exact lensing inversion and its null sectors

Let I0[P](u,r,n)=integral_0^r P(u-s,s n) ds and I1[P]=integral_0^r P_eta(u-s,s n) ds=partial_u I0[P], with calibrated, time-independent integration endpoints/registration. The lensing potential is psi=2 integral_0^r (r-s)/(rs) P(u-s,s n) ds. At fixed u,

  psi_r=2 r^-2 integral_0^r P(u-s,s n) ds,
  (1/2)partial_r(r² psi_r)=P(u-r,r n).

Consequently a reception gain g(u) gives Ptilde_cone=g(u)Pcone exactly: no g derivatives enter this radial inversion. This requires precisely a common gain independent of source radius and direction at fixed u. The local radial kernel c0(u,n)+c1(u,n)/r is still annihilated after multiplication by g(u). It does not determine interior path integrals needed for redshift corrections; those require separately registered interior fields/endpoints. The observer-origin expression retains the source note's regular/subtracted interpretation.

On full sky, g(u) commutes with the angular shear-to-psi map, so l>=2 can be reconstructed in the same manner. Shear's l=0,1 null modes remain null; neither reception gain nor repeated observations recover them. An unknown low-mode addition to psi can produce an unknown low-mode P. Mask leakage and source calibration remain independent obligations. Statements about I0/I1 apply only to calibrated sectors with their requisite interior/path information, not to a silently completed full sky.

## 2. Equal-time fields and differentiation

Under eta=u-r, Ptilde(eta,r,n)=g(eta+r)P(eta,r,n). For any scalar F,

  partial_eta(gF)=g F_eta+g'F,
  partial_r|eta(gF)=g F_r+g'F,
  Delta(gF)=g Delta F+2g' F_r+(g''+2g'/r)F.

Angular derivatives do not differentiate g. Thus g(u) is generally an observer-centered radial calibration field on a coeval slice. If g(eta+r)=h(eta) on an open eta/r product domain, differentiating at fixed eta gives g'=0; only a locally constant reception gain is also a homogeneous equal-matter-time gain. Matter time tau=tau(eta) does not change this argument. At fixed r, matter derivatives are a^-1 partial_u, with the same additional gain terms and the note's H correction at second order.

This does not itself make the wrong gain model observable: the true F is unknown. It proves that the homogeneous-gain coefficient formulas cannot simply be reused on the uncorrected received channels.

## 3. Corrected redshift: order of calibration and correction matters

In the source note's actual-event convention, epsilon=Oobs+Y-2I1[P], where Oobs=Psi_o-n dot v_o. For fixed coordinate endpoint comparison include the stated source-time correction -2H_s I0[P], and any further independently specified clock/source terms. For compactness write the physically calibrated primitive E as

  E=Oobs+Y-2I1[P]-2H_s I0[P]+Cextra.

Here the H_s term is omitted when already using actual-event times; Cextra is not inferred from lensing. It must be subtracted using the same physical calibration. H_s depends on eta=u-r, not merely u.

Suppose the lensing perturbation is multiplied by gL(u) and the primitive redshift perturbation by gZ(u), with observer and Cextra channels correctly carried through their redshift calibration. Applying the nominal correction to the recorded lensing field yields

  Ytilde=gZ Y+2(gL-gZ)(I1[P]+H_s I0[P])+2gL' I0[P].

For a common gain gL=gZ=g, this is

  Ytilde=gY+2g' I0[P].

The extra term follows because I1[Ptilde]=g I1[P]+g'I0[P]. The H_s source correction is algebraic and scales as g; it produces no extra derivative at this stage. Incorrectly calibrated observer, source-clock or path terms add their own residuals and do not disappear by declaring a common gain. Differentiating a source correction for drift also differentiates H_s and its calibrated event map.

If instead the instrument gain is applied to Y *after* all corrections have independently been made, then by definition Ytilde=gY. This is a different observation contract. The two contracts cannot be interchanged.

If Y denotes the redshift-derived forcing W in another notation, then under the common primitive gain:

  Wtilde=gW-g'Y-2g''I0-2g'I1-2H_s g'I0,

where W=-(partial_u+H_s)Y. Thus even a post-correction gain gives Wtilde=gW-g'Y, not pure multiplication. The reception dependence is differentiated at this step.

The cone transport operator is Lc=partial_r+2partial_u+H_s and obeys Lc Psi=-(partial_u+H_s)Y. Naively scaling both Psi and post-corrected Y gives residual g'(2Psi+Y), generally nonzero. A kinematically reconstructed potential therefore need not share Ptilde's gain. Likewise Vtilde=gV, when Euler is enforced, implies Psitilde=gPsi-g'V and Ytilde=gY+2g'V, not an arbitrary common multiplicative gain.

## 4. Remaining calibration freedom in the photon maps

Given primitive cone fields and any positive smooth h(u), redefine calibration and underlying fields by

  g_new=g h, psi_new=psi/h, P_new_cone=Pcone/h, E_new=E/h,
  O_new=Oobs/h, Cextra_new=Cextra/h.

Identical recorded primitives result. Applying the true correction to these redefined fields gives

  Y_new=Y/h-2h' I0[P]/h²

(with the appropriate same calibrated source-path convention). This is a precise kinematic calibration ambiguity. For any such smooth P_new,Y_new on an interior annulus, solve the first-order transport equation for V_new with arbitrary characteristic boundary data, then set Psi_new=-(partial_u+H_s)V_new and Phi_new=2P_new-Psi_new. The photon maps and irrotational Euler relation can be realized locally. This construction does NOT assert scalar/Einstein compatibility for both alternatives or establish nonidentifiability after imposing a jointly specified action/background and all its constraints.

A nonzero explicit example makes the derivative issue visible. Set a=1, angular factor Y20, P=r²Y20, Psi=V=0, hence Phi=2P, physical Y=0 and E=0. Then psi=r²Y20/3 and I0=r³Y20/3. With positive reception gain g=1+beta u, the observed inverse is Ptilde=(1+beta u)r²Y20 and nominally corrected Ytilde=2beta r³Y20/3, although gY=0. The same recorded psi and E are produced by unit gain and fields P2=(1+beta(eta+r))r²Y20, V2=beta r⁴Y20/6, Psi2=0, Phi2=2P2. Indeed Y2=partial_r V2=2beta r³Y20/3 cancels 2I1[P2] in E2. These are kinematic metric/velocity fields on an annulus, not asserted solutions of the canonical scalar action. To avoid any observer-origin smoothness concern, replace r² by a smooth radial profile supported away from0 and define V2=2beta integral_0^r integral_0^q p(s) ds dq; the same cancellation holds and fields vanish near the origin.

## 5. Answer to the observational question

Repeated cones identify local normal derivatives of the *recorded* fields, conditional on registration; they do not by themselves identify the detector calibration. A reception-time gain is radially inhomogeneous at equal matter time and, if corrections use gained primitives, mixes corrected redshift with a path integral. The homogeneous equal-time common-gain assumption is therefore an additional physical/calibration contract. With an independently known true field, calibrated clock/standard or a separately proven joint dynamical identifiability theorem it may be tested or constrained. It cannot be removed solely by the Born/shear/redshift coordinate identities.

The ambiguity above establishes only that photon kinematics and the supplied source/path corrections alone do not separate these factors. It is not a broad impossibility claim for the joint background/action inverse; dynamics, extra observations and calibration priors may rule out alternative decompositions. Degenerate zero fields trivially provide no gain information, while the displayed nonzero example shows why the issue is not confined to zero signal.
