# Focused reception-gain finding

A gain depending on reception conformal time is not generally a common homogeneous matter-time gain after repeated-cone reconstruction. The source note correctly warns about this. The important additional distinction is whether redshift correction precedes or follows the gain.

Define Y=Rz=-Psi+v_r and I0(u,r)=integral_0^r P(u-s,s n)ds. For a common gain g(u) multiplying primitive lensing/redshift perturbations, correctly scaled observer/source terms, and nominal path correction built from the recorded lensing field:

  Ptilde(eta,r)=g(eta+r)P(eta,r),
  Ytilde(u,r)=g(u)Y(u,r)+2g'(u)I0(u,r).

The lensing inverse (1/2)partial_r[r²partial_r psi] holds u fixed, so it commutes exactly with g(u). The time derivative used for the integrated redshift correction does not. A gain applied only after independently completing the redshift correction instead gives Ytilde=gY; that is a separate physical measurement contract. If the reconstructed variable is W=-(partial_u+H_s)Y, additional g',g'' terms are required as displayed in DERIVATION.md. Separate lensing and redshift gains introduce further path terms. Clock/source corrections and incomplete interior calibration cannot be silently canceled.

On a coeval slice Delta(gF)=gDeltaF+2g'F_r+(g''+2g'/r)F. Equality g(eta+r)=h(eta) on an open product domain forces g'=0. This proves that the restricted homogeneous-gain coefficient inverse cannot simply be applied to received channels. It does not prove that a joint dynamical/calibration inverse is impossible.

The photon kinematics alone retain a precise calibration freedom: for any positive h(u), scale the underlying lensing and primitive redshift fields by1/h while multiplying instrument gain by h. Recorded primitives are unchanged, but the correctly reconstructed redshift changes as Y_new=Y/h-2h'I0/h². Local kinematic metric/velocity representatives can be built from the transport equation. No claim is made that both representatives solve the same scalar/Einstein action, or any jointly fixed background/action constraints.

A nonzero l=2 example makes the issue concrete. For a=1, P=r²Y20, Psi=V=0 and gain g=1+beta u, recorded lensing is g r²Y20/3 and raw redshift perturbation is0. Applying the gained-field correction produces Ytilde=2beta r³Y20/3 rather than0. The same raw records admit unit gain with P2=g r²Y20, V2=beta r⁴Y20/6 and Psi2=0: its Doppler term exactly cancels its integrated potential-time term. This is a kinematic annular witness, not a same-action physical counterexample. A smooth profile vanishing near the observer removes any origin regularity issue while preserving the construction.

Angular l=0,1 shear null modes remain missing; g(u) commutes with the angular map only because it is direction independent. Radial integration kernels are still annihilated, but do not certify unknown interior path corrections. Mask/source calibration, observer terms, event-time/proper-clock mapping and repeated-cone registration remain explicit obligations. Repeated cones supply derivatives of recorded fields, not an independent detector calibration. Additional physical calibration or a proved joint dynamical identifiability result is required to remove this ambiguity.

## Evidence and source binding

The complete frozen canonical note was read before this independent derivation. No new JOINT_PHOTON_GAIN source, real array, external source or other author's developing work was read. Frozen source:

- /Users/jonBridger/.codex/worktrees/scalar-metric-inverse-20261016/New Axioms Lets Go/docs/SCALAR_METRIC_RECONSTRUCTION_NOTE_2026-10-16.md: `1e3b1dbdd0f42ebee7a66ce6fd27aeb0c5702baa594438654b564a05f05f8c63`

All18independent exact controls passed: radial Born inversion, local kernel, gain/time differentiation, separate/common channel corrections, coeval Laplacian, redshift transport products, explicit nonzero witness and calibration redefinition. check.py imports no author helper. Full stdout/stderr and execution_receipt.json preserve the bytecode-disabled command with120-second bound. No computational failure occurred. Final source rehash is unchanged. DERIVATION.md contains the complete proof and source/path conventions. This is focused conditional mathematical support, not an audit, empirical validation or broad impossibility claim.
