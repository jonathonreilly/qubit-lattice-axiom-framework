"""Original-equation fixture verification and exact candidate coefficient test."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json,runpy,contextlib,io
from pathlib import Path
buf=io.StringIO()
with contextlib.redirect_stdout(buf):z=runpy.run_path(str(Path(__file__).with_name('candidate_coefficients_check.py')))
checks=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
t=s.symbols('t',positive=True);c=s.sqrt(s.Rational(5,2));A=t**s.Rational(5,2);H=s.Rational(3,2)/t;phi=c*s.log(t);v=c/t;rE=1/(2*t*t);V=5/t**2;F=-7*c/(2*t*t);mu=s.Rational(37,4)/t**2;alpha=c
ck('background_Friedmann',s.simplify(3*H**2-v*v/2-V-rE)==0)
ck('background_Raychaudhuri',s.simplify(-2*s.diff(H,t)-v*v-rE)==0)
ck('background_scalar',s.simplify(s.diff(v,t)+3*H*v+F)==0)
ck('background_bare_dust',s.simplify(s.diff(rE/A,t)+3*H*rE/A)==0)
for n in [0,3,4,5]:
    m=-s.Rational(n,2);P=t**m;j=s.Rational(n*n-10*n+20,8-n);uu=j*P/c;vel=-2*s.Rational(4-n,8-n);U=vel*t**(m+1);delta=(-s.Rational(9,2) if n==0 else s.Integer(3))*P
    residuals=[s.diff(P,t)+H*P-(v*uu-rE*U)/2,-6*H*(s.diff(P,t)+H*P)-(rE*delta+v*s.diff(uu,t)-v*v*P+F*uu),s.diff(uu,t,2)+3*H*s.diff(uu,t)+mu*uu+alpha*rE*delta-4*v*s.diff(P,t)+2*F*P,s.diff(U,t)+P+alpha*uu+alpha*v*U,s.diff(delta,t)-3*s.diff(P,t)]
    for j0,res in enumerate(residuals):ck('original_equation_'+str((n,j0)),s.simplify(res)==0)
# The complete recovered coefficients, not just selected identities.
u,r=z['u'],z['r'];eta=u-r;aa=z['a'];h=z['h'];Dt=z['Dt'];L=z['L'];at=z['at']
beta=1/(aa*(u+11));C=s.Rational(1,2)*(-eta/2)**7;d=2*(-2/eta)**7;e=s.Integer(4);K=Dt(C)+h*C;kap=Dt(K)/K
Ac=h+C-beta;m=Dt(d)+(h-2*beta)*d;vv=e-d*beta
nn=L(vv)+(h-2*beta)*vv;tt=Dt(beta)+beta*(h+C-beta)
coeff=[-2*beta-kap,C-beta,L(Ac)-(2*beta+kap)*Ac+K-Dt(h),d,L(d)+m-(2*beta+kap)*d,L(m)-(2*beta+kap)*m-2*beta,vv,L(vv)+nn-(2*beta+kap)*vv,L(nn)-(2*beta+kap)*nn-2*h*beta-2*tt,-4*beta,-2*L(beta)+2*(2*beta+kap)*beta-4*tt,2*beta*(Dt(h)+h*h)-2*L(tt)+2*h*tt+2*(2*beta+kap)*tt-2*K*beta]
cf=s.Matrix([at(q) for q in coeff]);M=z['M'];target=s.Matrix(z['targets']);ck('full_rank',M.rank()==12);ck('all_twelve_coefficients',cf==z['solution']);ck('all_rows_full_identity',M*cf+target==s.zeros(M.rows,1));ck('reception_beta_identity',s.simplify(L(beta)-2*Dt(beta)-h*beta)==0)
# Constructive existence of an actual angular-row matrix from independent l modes:
# independent Legendre functions imply coefficient rank carries to suitable angular samples.
pivots=M.T.rref()[1];minor=M[list(pivots),:];det=minor.det();ck('explicit_nonzero_minor',det!=0)
result={'summary':{'passed':sum(q['passed'] for q in checks),'failed':sum(not q['passed'] for q in checks)},'checks':checks,'mode_rows':[[str(v) for v in row] for row in z['rows']],'targets':[str(v) for v in z['targets']],'coefficients':[str(v) for v in cf],'minor_rows':list(pivots),'minor_determinant':str(det),'at_point':{'beta':'1/10','C':'1/2','d':'2','e':'4','K':'1/4','Kprime_over_K':'-7'},'author_code_read':False}
print(json.dumps(result,indent=2));assert not result['summary']['failed']
