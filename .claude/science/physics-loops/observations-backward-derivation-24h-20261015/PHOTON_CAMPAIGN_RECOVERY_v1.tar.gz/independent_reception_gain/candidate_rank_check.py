"""Independent exact forward fixture and candidate twelve-column rank."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json
u,r=s.symbols('u r');eta=u-r;ainv=eta**8/256;a=1/ainv;h=4*(-eta/2)**7;gain=(u+11)/10
Dt=lambda f:s.diff(f,u)*ainv
L=lambda f:(s.diff(f,r)+2*s.diff(f,u))*ainv
at=lambda f:s.cancel(f).subs({u:-1,r:1})
rows=[];targets=[]
for i in range(24):
    n=[0,3,4,5][i%4];ell=2+i
    P=eta**n*r**ell;X=s.expand(gain*P)
    integ=sum(s.binomial(n,j)*u**(n-j)*(-1)**j*r**(ell+j+1)/s.Integer(ell+j+1) for j in range(n+1))
    B=a*gain*integ
    vel=-s.Rational(2)*(4-n)/(8-n);slip=s.Rational(n*n-10*n+20,8-n)
    Y=eta**n*(vel*(-eta/2)*ell*r**(ell-1)-(1+slip)*r**ell)
    W=s.expand(gain*Y+integ/5)
    expr=[Dt(W),L(W),W,L(L(Dt(X))),L(Dt(X)),Dt(X),L(L(X)),L(X),X,Dt(Dt(B)),Dt(B),B]
    rows.append([at(z) for z in expr]);targets.append(at(L(Dt(W))+h*L(W)+Dt(h)*W))
M=s.Matrix(rows);null=M.nullspace();result={'rank':M.rank(),'columns':12,'rows':24,'null_vectors':[[str(x) for x in v] for v in null],'augmented_rank':M.row_join(s.Matrix(targets)).rank()}
print(json.dumps(result,indent=2))
