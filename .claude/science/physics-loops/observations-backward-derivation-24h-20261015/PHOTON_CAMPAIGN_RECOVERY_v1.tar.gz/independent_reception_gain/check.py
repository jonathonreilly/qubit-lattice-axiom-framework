"""Independent exact photon/gain identities; no new author-source imports."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json
u,r,t,eta,beta=s.symbols('u r t eta beta',real=True)
g=s.Function('g')(u);gl=s.Function('gL')(u);gz=s.Function('gZ')(u)
rows=[]
def ck(n,expr):
    residual=s.simplify(s.expand(expr));rows.append({'name':n,'passed':residual==0,'residual':str(residual)})
P=(u-r)**2*r*r
psi=2*s.integrate((r-t)/(r*t)*(u-t)**2*t*t,(t,0,r))
Inv=lambda z:s.diff(r*r*s.diff(z,r),r)/2
ck('Born_radial_inverse',Inv(psi)-P)
ck('reception_gain_commutes_radially',Inv(g*psi)-g*P)
c0=s.Function('c0')(u);c1=s.Function('c1')(u)
ck('gained_radial_kernel',Inv(g*(c0+c1/r)))
I=s.integrate((u-t)**2*t*t,(t,0,r));I1=s.diff(I,u)
ck('gain_inside_time_correction',s.diff(g*I,u)-g*I1-s.diff(g,u)*I)
Y=s.Function('Y')(u,r);Obs=s.Function('Obs')(u);H=s.Function('H')(u-r);extra=s.Function('extra')(u,r)
E=Obs+Y-2*I1-2*H*I+extra
Yobs=gz*E-gz*Obs+2*s.diff(gl*I,u)+2*H*gl*I-gz*extra
ck('independent_channel_gains',Yobs-(gz*Y+2*(gl-gz)*(I1+H*I)+2*s.diff(gl,u)*I))
common=Yobs.subs({gl:g,gz:g})
ck('common_primitive_gain_redshift',common-g*Y-2*s.diff(g,u)*I)
T=lambda z:s.diff(z,u)+H*z
ck('redshift_forcing_derivative',-T(common)-(-g*T(Y)-s.diff(g,u)*Y-2*s.diff(g,u,2)*I-2*s.diff(g,u)*I1-2*H*s.diff(g,u)*I))
F=s.Function('F')(eta,r);gg=s.Function('gain')(eta+r)
Lap=lambda z:s.diff(z,r,2)+2*s.diff(z,r)/r-6*z/r**2
ck('coeval_spherical_laplacian',Lap(gg*F)-gg*Lap(F)-2*s.diff(gg,r)*s.diff(F,r)-(s.diff(gg,r,2)+2*s.diff(gg,r)/r)*F)
ck('coeval_temporal_derivative',s.diff(gg*F,eta)-gg*s.diff(F,eta)-s.diff(gg,eta)*F)
# A homogeneous-in-eta gain cannot equal nonconstant reception gain on a product chart.
ck('radial_gain_gradient',s.diff(gg,r)-s.diff(gg,eta))
Psi=s.Function('Psi')(u,r);Lc=lambda z:s.diff(z,r)+2*s.diff(z,u)+H*z
ck('postcorrected_transport_product',Lc(g*Psi)+T(g*Y)-g*(Lc(Psi)+T(Y))-s.diff(g,u)*(2*Psi+Y))
# Explicit nonzero same-primitive ambiguity in an l=2 sector, a=1.
Pg=r*r;psig=r*r/3;gain=1+beta*u
P2=gain*r*r;V2=beta*r**4/6;Y2=s.diff(V2,r)
I2=s.integrate((1+beta*u)*t*t,(t,0,r))
ck('nonzero_example_primitive_lensing',Inv(gain*psig)-P2)
ck('nonzero_example_redshift_cancellation',Y2-2*s.diff(I2,u))
ck('nonzero_example_velocity_Euler',s.diff(V2,u))
ck('nonzero_example_correction_bias',2*s.diff(gain* r**3/3,u)-2*beta*r**3/3)
# Equal-time radial derivative is D=partial_r+partial_u.
D=lambda z:s.diff(z,r)+s.diff(z,u)
ck('equal_time_radial_gain',D(g*P)-g*D(P)-s.diff(g,u)*P)
# General h calibration redefinition and corrected Y.
h=s.Function('h')(u)
Enew=E/h
Ynew=Enew-Obs/h+2*s.diff(I/h,u)+2*H*I/h-extra/h
ck('calibration_gauge_corrected_Y',Ynew-Y/h+2*s.diff(h,u)*I/h**2)
# Full-sky l=2 shear coefficient is sqrt(24)/2, gain commutes, low modes not inferred.
spin=s.sqrt(24)/2
ck('angular_gain_commutes',(g*spin*psi)/spin-g*psi)
result={'summary':{'passed':sum(z['passed'] for z in rows),'failed':sum(not z['passed'] for z in rows)},'checks':rows,'scope':'kinematic identities and calibration ambiguity; no same-action scalar-Einstein counterexample','empirical_validation':False}
print(json.dumps(result,indent=2));assert not result['summary']['failed']
