"""Frozen one-field angular conditioning and derivative-level perturbations."""
AUDIT_TIMEOUT_SEC=120
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss,legval
import mpmath as mp
import sympy as s
import json,runpy,contextlib,io,hashlib
p=Path(__file__).resolve().parent
baseline=json.loads((p/'candidate_full_stdout.json').read_text());mode=np.array([[float(s.Rational(v)) for v in row] for row in baseline['mode_rows']]);target=np.array([float(s.Rational(v)) for v in baseline['targets']]);theta=np.array([float(s.Rational(v)) for v in baseline['coefficients']])
x,w=leggauss(48);train=np.arange(0,48,2);test=np.arange(1,48,2)
amps=np.array([1e-5*np.sqrt((2*(i+2)+1)/2)/(2**([0,3,4,5][i%4])*(i+3)**4) for i in range(24)])
H=np.column_stack([legval(x,[0]*(i+2)+[1])*amps[i] for i in range(24)])
A=H@mode;y=-H@target
weighted=A*np.sqrt(w)[:,None];wy=y*np.sqrt(w)
scale=np.linalg.norm(weighted[train],axis=0);S=weighted/scale
sv=np.linalg.svd(S[train],compute_uv=False);rawsv=np.linalg.svd(weighted[train],compute_uv=False)
basefit=np.linalg.lstsq(S[train],wy[train],rcond=None)
rng=np.random.default_rng(2026101607);noiseA=rng.normal(size=S[train].shape);noiseA/=np.linalg.norm(noiseA,2);noisey=rng.normal(size=len(train));noisey/=np.linalg.norm(noisey)
runs=[]
def recovered(th):return {'beta':float(-th[9]/4),'C':float(th[1]-th[9]/4),'d':float(th[3]),'e':float(th[6]+th[3]*(-th[9]/4))}
for eps in [0.,1e-12,1e-9,1e-6]:
    AA=S[train]+eps*np.linalg.norm(S[train],2)*noiseA;yy=wy[train]+eps*np.linalg.norm(wy[train])*noisey
    z,_,rank,_=np.linalg.lstsq(AA,yy,rcond=None);th=z/scale
    bound=(eps*np.linalg.norm(wy[train])+eps*np.linalg.norm(S[train],2)*np.linalg.norm(scale*theta))/(sv[-1]-eps*np.linalg.norm(S[train],2)) if sv[-1]>eps*np.linalg.norm(S[train],2) else None
    runs.append({'epsilon':eps,'rank':int(rank),'relative_coefficient_error':float(np.linalg.norm(th-theta)/np.linalg.norm(theta)),'max_abs_coefficient_error':float(np.max(abs(th-theta))),'heldout_relative_residual':float(np.linalg.norm(S[test]@z-wy[test])/np.linalg.norm(wy[test])),'recovered':recovered(th),'scaled_error_bound_when_margin_positive':bound,'scaled_actual_error':float(np.linalg.norm(z-scale*theta))})
# Independent80digit arithmetic, preserving the exact mode equations.
mp.mp.dps=80
mm=mp.matrix([[mp.mpf(v) if '/' not in v else mp.mpf(v.split('/')[0])/mp.mpf(v.split('/')[1]) for v in row] for row in baseline['mode_rows']]);tt=mp.matrix([mp.mpf(v) if '/' not in v else mp.mpf(v.split('/')[0])/mp.mpf(v.split('/')[1]) for v in baseline['targets']])
HH=mp.matrix([[mp.legendre(i+2,mp.mpf(float(xx)))*mp.mpf('1e-5')*mp.sqrt(mp.mpf(2*(i+2)+1)/2)/(mp.mpf(2)**([0,3,4,5][i%4])*(i+3)**4) for i in range(24)] for xx in x]);MA=HH*mm;MY=-HH*tt
MT=mp.matrix([[MA[int(j),i]*mp.sqrt(mp.mpf(float(w[j])))/mp.mpf(float(scale[i])) for i in range(12)] for j in train]);YT=mp.matrix([MY[int(j)]*mp.sqrt(mp.mpf(float(w[j]))) for j in train]);zmp=mp.lu_solve(MT.T*MT,MT.T*YT);thmp=[zmp[i]/mp.mpf(float(scale[i])) for i in range(12)];exact=[mp.mpf(v) if '/' not in v else mp.mpf(v.split('/')[0])/mp.mpf(v.split('/')[1]) for v in baseline['coefficients']];mperr=max(abs(v-t) for v,t in zip(thmp,exact))
# Mutation evaluated on the same one-field and frozen baseline column scaling.
buf=io.StringIO()
with contextlib.redirect_stdout(buf):mut=runpy.run_path(str(p/'robustness_mutation_modes.py'))
mmut=np.array(mut['rows'],dtype=float);tmut=np.array(mut['targets'],dtype=float);Amut=(H@mmut)*np.sqrt(w)[:,None]/scale;ymut=(-H@tmut)*np.sqrt(w)
zz,_,rank,ss=np.linalg.lstsq(Amut[train],ymut[train],rcond=None);th=zz/scale;held=float(np.linalg.norm(Amut[test]@zz-ymut[test])/np.linalg.norm(ymut[test]));rec=recovered(th);known={'beta':.1,'C':.5,'d':2.,'e':4.}
mutation={'term_removed':'2*g_u*I_P from W only','exact_modal_rank':mut['result']['rank'],'exact_augmented_rank':mut['result']['augmented_rank'],'numerical_rank':int(rank),'heldout_relative_residual':held,'unused_row_detection_at_1e_8':held>1e-8,'recovered':rec,'known_fixture_differences':{n:rec[n]-known[n] for n in known},'known_fixture_coefficients_detect_at_1e_6':max(abs(rec[n]-known[n]) for n in known)>1e-6,'condition_scaled':float(ss[0]/ss[-1])}
result={'scope':'One finite field; derivative-level perturbations only, not primitive-noise/empirical performance','source_plan_sha256':hashlib.sha256((p/'ROBUSTNESS_PLAN.json').read_bytes()).hexdigest(),'sampling':{'nodes':x.tolist(),'weights':w.tolist(),'train_indices':train.tolist(),'heldout_indices':test.tolist(),'mode_amplitudes':amps.tolist(),'column_scales':scale.tolist()},'singular_values_scaled':sv.tolist(),'condition_scaled':float(sv[0]/sv[-1]),'singular_values_unscaled':rawsv.tolist(),'condition_unscaled':float(rawsv[0]/rawsv[-1]),'noise_runs':runs,'high_precision_noiseless_max_error':str(mperr),'mutation':mutation}
print(json.dumps(result,indent=2));assert mperr<mp.mpf('1e-40')
