"""Unused observable-consistency residuals after the single-shell mutant survives."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json
eta,r=s.symbols('eta r',negative=False)
a=(-2/eta)**8;D=lambda z:s.diff(z,eta)/a;L=lambda z:(s.diff(z,eta)+s.diff(z,r))/a
h=4*(-eta/2)**7;G=(-eta/2)**7;C0=G/2;d=2/G;q0=s.Rational(5,2)*G
# Coefficient functions from exact mutant column expansion: beta_fit=0,
# C_fit=C0-beta_true, d_fit=d, e_fit=4-d*beta_true.
# On reference shell r0=1 these are observable histories; freeze them spatially.
beta=1/(a*(eta+12));C=C0-beta;e=4-d*beta;q=h-(e-1)/d;R=C*G;B=q/G;x=s.sqrt(q*G);b=s.sqrt(B);ell=h-q
A=(-2/eta)**5*(eta+12)/10
HE=A*ell;v=A*x;rE=A*A*R;rho=A*R;VV=A*A*(3*ell**2-x*x/2-R)
F=(D(VV)+rho*D(A))/x
K=D(C)+h*C;kobserved=-7*G+2*beta
at=lambda z:s.simplify(z.subs({eta:-2,r:1}))
background={'Friedmann':at(3*HE**2-v*v/2-VV-rE),'Raychaudhuri':at(-2*A*D(HE)-v*v-rE),'original_scalar':at(A*D(v)+3*HE*v+F),'bare_dust_transport':at(A*D(rho)+3*HE*rho),'coefficient_k_consistency':at(D(K)/K-kobserved)}
# Original linear dust test, using one genuine n0 ell2 mode and the reconstructed
# coefficient history. Full background is frozen in r before spatial operators.
gain=(eta+r+11)/10;P=gain*r*r;W=gain*(eta*r-s.Rational(7,2)*r*r)
N=D(W)+(h+C)*W+L(d*D(P)+e*P)+h*(d*D(P)+e*P)
Z=-N/K;J=d*(D(P)+ell*P)+C*Z
ww=J/b;Fbar=-D(x)-3*h*x+2*q*x
Lap=lambda z:s.diff(z,r,2)+2*s.diff(z,r)/r-6*z/r**2
delta=(2*Lap(P)/a**2-6*ell*(D(P)+ell*P)-x*D(ww)+x*x*P-Fbar*ww)/R
linear={'Euler':at(D(Z)+P+J),'bare_dust_continuity':at(D(delta)-3*D(P)+Lap(Z)/a**2),'corrected_redshift':at(-P-J+s.diff(Z,r)/a-W)}
innerC=s.Rational(79,198);outerC=s.Rational(81,202);innere=s.Rational(376,99);outere=s.Rational(384,101)
result={'scope':'Adaptive unused-residual check of inferred mutant histories; not a known-truth coefficient comparison','cross_shell':{'C_outer_minus_inner':str(outerC-innerC),'e_outer_minus_inner':str(outere-innere),'homogeneity_rejected':outerC!=innerC and outere!=innere},'background_residuals':{k:str(v) for k,v in background.items()},'linear_dust_residuals':{k:str(v) for k,v in linear.items()},'detected_by_unused_residuals':any(v!=0 for v in background.values()) and any(v!=0 for v in linear.values())}
print(json.dumps(result,indent=2))
