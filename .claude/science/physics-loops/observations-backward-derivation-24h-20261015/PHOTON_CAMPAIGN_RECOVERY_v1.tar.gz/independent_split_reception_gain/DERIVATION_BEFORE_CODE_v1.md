# Independent split reception-gain derivation before code

Only the two sources pinned in `NEUTRAL_CONTRACT_v1.json` have been read for this unit. No new root split-reception candidate, program or output has been read. The previous background comparison remains unchanged. This proof is conditional mathematics in the given canonical scalar/conformal-dust class, not an empirical calibration or a formal audit.

## Coordinates, chart and the recorded primitive

Let eta be matter conformal time, u=eta+r reception time, a=a(eta)>0 and H=a_eta/a. A subscript u on a cone field holds r and direction fixed. Write D=2 partial_u+partial_r|u, so D is partial_eta+partial_r|eta. The original background and fields are smooth; work on an open repeated-cone strip with positive Einstein dust and nonzero scalar speed/coupling, in the equal-Einstein-potential/integrated-velocity sector or recovered full-sky l>=2. The calibrated interior path and observer conventions in the question are required. A local annulus alone does not supply its missing interior integrals.

The gains gL(u),gZ(u) are independent positive smooth real functions. Define

    s=(log gL)_u, f=gL/gZ>0,
    X=gL P, B=a gL I0[P],
    W=gZ Y+2(gL-gZ)I1[P]+2 gL_u I0[P].

Since I1=partial_u I0, the observed combination

    Qobs=aW-2B_u+2HB = a gZ(Y-2I1[P])

is the gained primitive redshift with correctly carried observer terms. The H here differentiates the factor a in B. It does **not** add a fixed-coordinate source-time H_s correction to the actual-event redshift convention.

The path identity is B_r|u+HB=aX. It is a necessary registered-path check, not an independent measurement equation for the gains.

## Hidden first-order equations and commutator

Use matter-time background G=x/b, c=R/G, d=2/G, e=1+d(h-q). To avoid confusing a homogeneous conformal coefficient with a reception gain, set

    C=a c, E=a e.

C,d,E depend only on eta. The original momentum and Euler equations give

    Z_eta+C Z=-d P_eta-E P,
    D Z=aY.

With S=gL Z, define

    F=-d X_u+(ds-E)X,
    Gobs=f Qobs+2B_u-2(H+s)B.

Then exactly

    A S=F, L S=Gobs,
    A=partial_u+C-s, L=D-2s.

Although the coefficients depend separately on eta and u, [L,A]=C_eta: D C=C_eta, D s=2s_u, and the gain-derivative terms cancel. Thus

    C_eta S=N := L F-A Gobs.

On C_eta!=0 let k=C_etaeta/C_eta and t=C-s-k. The temporal compatibility equation is

    (partial_u+t)N-C_eta F=0.

This is necessary. After reconstruction the characteristic equation and all original scalar, dust and Einstein equations still need testing.

Expand N using only observed fields:

    N=A0 D X_u+A1 D X+A2 X_u+A3 X
          -2B_uu+A4 B_u+A5 B+A6 Qobs_u+A7 Qobs,

where

    A0=-d,
    A1=ds-E,
    A2=-d_eta+2sd,
    A3=d_eta s+2d s_u-E_eta-2ds^2+2sE,
    A4=2(H+2s-C),
    A5=2[H_eta+s_u+(C-s)(H+s)],
    A6=-f,
    A7=-f_u-(C-s)f.

The coefficient vector theta in the twelve-column observed relation

    [D X_uu,D X_u,D X,X_uu,X_u,X,
     B_uu,B_u,B,Qobs_uu,Qobs_u,Qobs] theta = 2B_uuu

is

    theta0=A0,
    theta1=A0_u+A1+tA0,
    theta2=A1_u+tA1,
    theta3=A2,
    theta4=A2_u+A3+tA2-C_eta A0,
    theta5=A3_u+tA3-C_eta A1,
    theta6=A4-2t,
    theta7=A4_u+A5+tA4,
    theta8=A5_u+tA5,
    theta9=A6,
    theta10=A6_u+A7+tA6,
    theta11=A7_u+tA7.

Coefficient derivatives here are partial_u at fixed r, so they differentiate eta-dependent backgrounds and u-dependent gains as specified. Angular rows at fixed (u,r) share all coefficients. The existence of a full-rank physical design is not assumed from this formal expansion and is the decisive pending control.

If C_eta=0 at an epoch, N=0 is a homogeneous relation among a subset of these twelve observed columns, with coefficient -2 on B_uu. Thus rank twelve excludes C_eta=0 for any compatible candidate, including candidates where the division was initially unavailable.

## Recovery from the extracted coefficient functions

Suppose the observed design has rank twelve on a neighborhood and exact target membership. Extraction determines theta as smooth local functions. Put

    d=-theta0,
    s=(theta3+d_eta)/(2d),
    f=-theta9>0,
    M=-(theta10+2f_u)/f,
    V=-(theta1+d_eta)/d-M.

For compatible fields M=2C-2s-k and V=E/d-C. The denominators require d!=0 (already part of the regular action chart) and f>0. The recovered d and V must be homogeneous functions of eta; the recovered s and f must be functions of u alone. These factorization tests are substantive, not consequences of arbitrary coefficient fitting. The coefficient identity theta6=2H+2s-2M is another residual.

Let y=s-C, and define

    T0=theta7/2-2(H_eta+s_u)-M(H+s).

Direct substitution gives

    T0=y_u+y^2+M y,
    theta2/d=T0+(d_eta/d-V)y-(d_eta/d+M)V-V_eta.

Consequently, on the additional regular chart

    Delta=d_eta/d-V !=0,

one obtains

    y=[theta2/d-T0+(d_eta/d+M)V+V_eta]/Delta,
    C=s-y, E=d(C+V).

Thus full rank plus Delta!=0 yields direct local uniqueness of both reception-gain drifts, the relative gain amplitude, and C,d,E. The second drift is

    (log gZ)_u=s-f_u/f.

Only the common positive constant multiplying both gains remains free: integrate s for gL/gL0, then gZ=gL/f. Since the physical perturbation equations are linear, dividing all perturbations by that same constant preserves all dynamics and recorded channels. This is an actual residual normalization freedom, not a derived absolute calibration.

This proof does not decide the Delta=0 chart. There one retains the un-divided coefficient equations and full physical residuals; no preferred root, no uniqueness assertion and no general obstruction is imposed. Rank loss likewise is not a universal impossibility theorem. Zero records clearly cannot determine independent gains.

The derivatives of extracted coefficients are derivatives of ideal local functions, not quantities determined by twelve isolated samples. The controls below will differentiate the actual matrix equation to recover coefficient jets from observable jets, rather than insert background derivatives as though they were observed.

## Physical compatibility and normalization

Recovered C,d,E must depend only on eta and satisfy all twelve coefficient formulas with k=C_etaeta/C_eta. Convert back using c=C/a,e=E/a,G=2/d,R=2C/(ad), ell=(E/a-1)/d,q=h-ell. Require R>0,qG>0 and nonzero regular fields. The sign choice b=sign sqrt(q/G), x=G b is a global field reflection on a connected regular chart. Reconstruct A=A0 exp integral q d tau, phi=phi0+M integral x d tau and Vphysical=M^2 A^2[3ell^2-x^2/2-R]. Dust transport and Raychaudhuri must hold; differentiating Friedmann with x!=0 then recovers the original scalar equation. The fixed-density curvature follows from the action force identity, not a measured pole.

For the perturbations reconstruct S=N/C_eta,Z=S/gL,P=X/gL, I0=B/(a gL), I1=partial_u I0 and

    Y=Qobs/(a gZ)+2I1,
    J=-P-Z_eta/a, w=J/b.

Obtain delta from the Hamiltonian and enforce the original scalar, dust continuity, momentum, Euler and Einstein equations, the characteristic equation, recorded-channel equations and path identity. On a compatible solution these steps fix the histories locally, apart from common gain normalization, A0, scalar origin/reflection and off-trajectory extensions. This is conditional compatibility, not action selection, nonlinear stability, global history recovery or finite-noise inference.

## Frozen physical test protocol

Use the permitted exact original-action background with M=1, p=3/2, c_phi^2=5/2:

    aE=t^(3/2), phi=c_phi log t, A=t^(5/2),
    rE=(1/2)t^-2, rho=(1/2)t^-9/2, Vphysical=5t^-2,
    b=c_phi, F=-(7/2)c_phi t^-2, mu=(37/4)t^-2,
    eta=-2/sqrt(t)<0, a=256 eta^-8,
    C=-1/eta, d=-256 eta^-7, E=1024 eta^-8, H=-8/eta.

The original k_com^2=0 linear system admits four temporal powers P=t^(-n/2) multiplying any regular solid harmonic r^l Y_lm, with n=0,3,4,5. They have J=j_n P and U=z_n t P:

| n | j_n | z_n |
|---|---|---|
| 0 | 5/2 | -1 |
| 3 | -1/5 | -2/5 |
| 4 | -1 | 0 |
| 5 | -5/3 | 2/3 |

Verify these from every original equation and the Hamiltonian, not from the new elimination. Constant normalization permits P=eta^n r^l Y_lm, Z=-128 z_n eta^(n-7) r^l Y_lm. The solid harmonic has zero spatial Laplacian but nonzero l>=2; no real Fourier wave number is being invented for an angular shell.

For each mode,

    I0=sum_{i=0}^n binomial(n,i) u^(n-i) (-1)^i r^(l+i+1)/(l+i+1),
    I1=partial_u I0,
    Y=-(1+j_n)eta^n r^l-(z_n/2)l eta^(n+1)r^(l-1).

All path fields and observer terms are regular on the chosen interval. Evaluate at u=-1,r=1,eta=-2,t=1, so the whole ray has eta between -2 and -1; it never crosses the eta=0 background singularity. The l>=2 observer potential and velocity terms vanish by actual regularity. Work in fixed reference time/length units, set to one; the numerical scales are stipulated.

Choose the positive primitive gains, with vR=u+1,

    gL=1+vR/3+vR^2/7,
    gZ=2(1-vR/5+vR^2/11).

Both quadratics are positive for all real vR. Their logarithmic drifts are variable. At the test epoch gL=1,gZ=2,s=1/3,f=1/2 and (log gZ)_u=-1/5. The background has d=2,C=1/2,E=4 and Delta=2.

Freeze 32 physical rows: for i=0,...,31 take n=[0,3,4,5][i mod4], l=i+2,m=0. A single real linear field is the sum of these modes with a common small nonzero amplitude; angular projection recovers the rows. Do not add new seeds because of a rank result. Generate the recorded fields from the exact original-equation modes and path integrals, then compute the twelve-column rank and augmented rank. If full, retain an exact selected minor, solve for theta and obtain its first two u derivatives by differentiating M theta=target twice using the same selected rows. Recover d,s,f,C,E and both drift histories from those observed coefficient jets and compare with the forward values. Verify all available extra-row residuals. If rank is deficient, preserve the nullspace and state that this physical fixture does not establish attainability.

All owned computations are capped at 120 seconds with bytecode disabled. Split algebra, original-action fixtures and matrix calculations into bounded processes if needed. Preserve every real failure and all stdout/stderr; do not reinterpret a timeout as a passed check. Freeze the independent proof/source/results before any root split-reception exposure. Python/SymPy are shared software with earlier checks and do not constitute independent computer algebra systems.
