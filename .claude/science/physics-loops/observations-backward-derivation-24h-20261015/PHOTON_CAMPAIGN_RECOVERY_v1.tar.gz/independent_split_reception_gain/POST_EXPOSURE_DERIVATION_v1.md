# Bounded post-exposure comparison, frozen before new controls

This supplement is written after reading the seven files in AUTHOR_SNAPSHOT_v1.json and the subsequently authorized campaign dependency. The earlier DERIVATION_BEFORE_CODE_v1.md, checker and outputs remain unchanged. Root's fourteen-column construction is an exposed author result here; it is not reclassified as independently originated.

## Coordinate and gain conversion

Use independent coordinates (eta,u), with reception u=eta+r. At fixed cone radius, T=partial_eta+partial_u. The flat outgoing characteristic operator in conformal units is D=partial_eta+2 partial_u. Thus matter-time prime=T/a and root L=D/a. Write H=a_eta/a and h=H/a. Let C,E,s,f denote the frozen independent conformal notation; let c,e,beta,sigma,chi denote root's matter-time quantities. Then

    C=a c, E=a e, d=d_root,
    s=(log gL)_u, f=gL/gZ,
    chi=1/f=gZ/gL, beta=s/a, sigma=(log gZ)_u/a,
    K=c'+h c=C_eta/a^2,
    k_root=K'/K=(C_etaeta/C_eta-2H)/a.

The factors a are essential; agreement of numerical point values alone (a=1 at the chosen point) would not verify them.

For independent S=gL Z, F=-d T X+(d s-E)X and G=f Q+2T B-2(H+s)B, where Q=aW-2T B+2HB, the equations are

    (T+C-s)S=F, (D-2s)S=G,
    N=(D-2s)F-(T+C-s)G=C_eta S.

Root's V=gZ Z, Troot=W+2(chi-1)B'+[-2(chi-1)h-2chi beta]B, and Froot=chi d X'+chi(e-d beta)X obey

    V=chi S, Troot=chi G/a, Froot=-chi F/a,
    Nroot=(prime+h+c-sigma)Troot+(L+h-2sigma)Froot
         =-chi N/a^2=-K V.

Therefore the author characteristic compatibility expression transforms exactly to

    (L-2sigma-k_root)Nroot+K Troot
      =-chi/a^3 [(D-2s-C_etaeta/C_eta)N-C_eta G].

The frozen independent twelve-column equation is instead

    (T+C-s-C_etaeta/C_eta)N-C_eta F=0.

These are the two different original first-order residuals after S=N/C_eta. They are not a mere invertible relabeling of column bases. Each is necessary; reconstruction must still test the other first-order equation and all background/Einstein/scalar/dust equations for existence. Neither comparison proves a global relation between the two rank contracts.

## Extraction and rank qualifications

The author columns in order are W', LW, W, L^2X', LX', X', L^2X, LX, X, X'', B''', B'', B', B, with target -[LW'+hLW+h'W]. In one-based coefficient notation,

    chi=1+theta11/4, ss=theta11/2,
    beta=[4ss'+(h+2theta2+theta1)ss-theta12]/(4chi),
    sigma=beta+chi'/chi,
    c=theta2+sigma, d=theta4/chi, e=theta7/chi+d beta.

The equality theta10=theta11/2 is a consistency constraint on recovered coefficients, not an automatic relation between observable columns. Rank fourteen is to be tested on angular rows at a common time/radius. Across different radii the gains and coefficients vary, so pooling them as identical-coefficient rows would be invalid.

The author route uses chi>0, rank fourteen and physical nonzero denominators; K=0 would itself imply a nonzero lower-order column relation from Nroot=0, so this rank excludes K=0. The independent route uses rank twelve and the additional Delta=d_eta/d-(E/d-C) != 0. Both provide conditional identification only. The differing derivative orders and denominator conditions do not establish rank dominance. Rank-loss cases and the independent Delta=0 chart remain unresolved by this comparison.

## Declared post-exposure controls

1. Symbolically check the coordinate/gain map, both commutator numerators, the compatibility conversion and the extraction identities. Use general functions, not merely point values with a=1.
2. Apply the author's fourteen-column inverse to exactly the already frozen 32 regular original-action solid-harmonic rows, eta=-2,r=1,u=-1, and quadratic gains gL=1+(u+1)/3+(u+1)^2/7, gZ=2[1-(u+1)/5+(u+1)^2/11]. Do not add or change rows if rank fails.
3. Generate the fourteen columns and target using the independent forward fields and exact Taylor-jet arithmetic. Reuse the independent jet arithmetic, explicitly disclosed; do not call the author coefficient or forward generator. Recover theta and theta_u from the actual observed matrix and target by M theta=b and M theta_u=b_u-M_u theta. Apply the displayed extraction to these recovered jets. Expected point values are chi=2, beta=1/3, sigma=-1/5, c=1/2, d=2, e=4. Equality is a test, not an imposed fit.
4. Replay copied unchanged author code. For canonical helpers call common run_checks() followed by separate run_checks() so the shared inherited-fixture count matches the stored primary execution context. Compare their full returned units against the authorized cache. This is not a replay/review of the unread canonical primary or conditioning helper.
5. Replay the unchanged campaign split runner with its now-authorized exact dependency. Capture complete stdout/stderr and compare JSON to the stored controls. No author script is executed in its original directory.

The canonical split runner differentiates its exact symbolic coefficient history in the gain-drift extraction; it does not recover those derivatives from differentiated observed matrices. The independent quadratic test will close that specific constructed-fixture gap, without converting it into an empirical derivative measurement claim.

The original-action fixture is local, not globally decaying. The solid harmonics have l>=2 and vanish sufficiently at the observer for the omitted observer terms to be zero. Its path lies in eta<0 and avoids the background singularity. A finite mode superposition can be scaled to remain perturbative on the bounded chart. Common constant gain/amplitude rescaling remains free. The positive action background and the signal/potential registration are stipulated. No measurement, global uniqueness, robustness, nonlinear stability or different-action identification is supplied.
