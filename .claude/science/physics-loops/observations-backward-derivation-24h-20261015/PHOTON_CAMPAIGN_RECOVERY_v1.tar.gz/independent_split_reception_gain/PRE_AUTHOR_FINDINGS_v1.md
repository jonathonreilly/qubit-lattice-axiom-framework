# Independent split-reception findings, before root exposure

In the stated actual-event primitive-channel contract there is a conditional identification route for **both** reception-gain drifts and their relative amplitude, jointly with the homogeneous background. The path terms cannot be discarded or treated as a homogeneous common matter-time gain. The result needs an actual rank-twelve observed design and a further observable nonzero denominator; both occur in the predeclared original-action fixture. It leaves a common positive gain normalization and the usual background field/scale freedoms. No empirical calibration or unconditional identification is established.

The complete proof and frozen protocol are in `DERIVATION_BEFORE_CODE_v1.md` (SHA256 `ada531f89313584687795bf527dda7ad3685b4ac21939a55b5dceb22df98c1a2`). They were frozen at 2026-10-16 13:17:05 UTC, before implementing the controls. No new root split-reception candidate, source or result has been read. Only the two context sources pinned in the neutral contract were used; Python/SymPy are shared software with earlier checks.

Write s=(log gL)_u and f=gL/gZ. The recorded primitive combination is Qobs=aW-2B_u+2HB=a gZ(Y-2I1). Its H term differentiates B's scale factor; it does not insert a fixed-coordinate source-time correction. With homogeneous conformal C=aR/G,d=2/G,E=a[1+d(h-q)] and S=gL Z, momentum/Euler and photon transport become

    (partial_u+C-s)S=-dX_u+(ds-E)X,
    (D-2s)S=fQobs+2B_u-2(H+s)B,
    D=2partial_u+partial_r|u.

Their commutator is C_eta. Eliminating S and applying the temporal equation gives the twelve columns

    [D X_uu,D X_u,D X,X_uu,X_u,X,
     B_uu,B_u,B,Qobs_uu,Qobs_u,Qobs]

with target 2B_uuu. Rank twelve excludes the C_eta=0 chart. The extracted coefficients directly give d,s,f, and two combinations M,V. Where the extracted Delta=d_eta/d-V is nonzero, two remaining coefficients give C,E explicitly. The redshift gain drift is s-f_u/f. All homogeneity/reception-dependence, coefficient, path, positivity and original action residuals remain required.

The exact power background p=3/2,c_phi^2=5/2 and temporal modes n=0,3,4,5 satisfy all original scalar, dust and Einstein equations. Each is multiplied by a regular l>=2 solid harmonic, not an inverse-chosen observable jet. The 32 frozen rows use n cycling through those four modes and l=2,...,33. Their registered path integrals are computed from the physical mode fields. At u=-1,r=1,eta=-2, the entire observer-source ray remains in the regular negative-eta domain. Both primitive gains are positive quadratics with variable logarithmic drifts.

The actual design and augmented design both have rank **12**. Rows 0,...,11 have determinant

    -703157085196156665856 / 11155322223045.

A single real superposition in distinct l,m=0 sectors supplies these rows by angular projection. The original linear solutions, background and path maps are analytic on a neighborhood; the nonzero determinant persists locally. No independent spectrum, boundary normalization or real Fourier wave number was assigned.

The inverse was exercised using the recorded matrix and target and their first two u derivatives. Differentiating M theta=target yielded theta_u and theta_uu; background/gain derivatives were not substituted as observations. All extra-row residuals and the recovered coefficient jets agree. The recovered values are

    d=2, C=1/2, E=4,
    sL=1/3, f=1/2, sZ=-1/5, Delta=2.

The derivatives of both variable logarithmic drifts are also recovered correctly. Full stdout retains the matrices, their derivative matrices, exact coefficient jets and comparisons.

Three bounded executions completed: algebra 11/0, original-action/background 34/0, observed inverse 176/0. The final algebra entry is a tautological drift-definition check and supplies no separate evidence; the other ten algebra identities check the expansion and recovery. Counts are computational assertions, not independent experiments. Actual wall times were approximately 1.96,1.28 and 2.22 seconds, each under a 120-second cap with bytecode disabled. No failed or timed-out execution occurred in this unit. No threshold or physical seed was retuned.

Multiplying both gains by one positive constant and dividing every physical perturbation by it preserves the recorded channels and the linear action equations. Absolute common gain is therefore not identified. The Delta=0 and rank-deficient charts remain unresolved by this route; no general impossibility result is inferred. A0, scalar origin/reflection and off-trajectory action extensions also remain free. Unknown observer/source corrections, missing interior paths or angular sectors, finite noise, derivative conditioning, tracer bias, nonlinear dynamics and realized cosmological history are outside this exact result.

The next obligation is a bounded comparison with root's independently frozen split-reception unit, preserving the chronology and these bytes. Any eventual use on observations must establish the stated input contract, actual rank, nonzero denominator and full physical residuals rather than assume them.
