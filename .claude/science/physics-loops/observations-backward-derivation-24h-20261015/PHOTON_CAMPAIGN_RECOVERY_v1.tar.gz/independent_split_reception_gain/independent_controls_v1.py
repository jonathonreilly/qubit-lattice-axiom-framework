"""Independent split primitive reception-gain controls, before author exposure."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import json,sys,time
import sympy as sp
from sympy.polys.matrices import DomainMatrix
from sympy.polys.domains import QQ
CASE=sys.argv[1];checks=[];details={};start=time.monotonic()
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
    print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
def zero(name,e):
    value=sp.factor(sp.cancel(sp.expand(e)));check(name,value==0,str(value))
if CASE=='algebra':
    eta,u=sp.symbols('eta u',real=True)
    C,d,E,H,k=[sp.Function(q)(eta) for q in ['C','d','E','H','k']]
    s,f=[sp.Function(q)(u) for q in ['s','f']]
    X,B,Q,S=[sp.Function(q)(eta,u) for q in ['X','B','Qobs','S']]
    T=lambda z:sp.diff(z,eta)+sp.diff(z,u)
    D=lambda z:sp.diff(z,eta)+2*sp.diff(z,u)
    A=lambda z:T(z)+(C-s)*z
    L=lambda z:D(z)-2*s*z
    F=-d*T(X)+(d*s-E)*X
    G=f*Q+2*T(B)-2*(H+s)*B
    zero('commutator contains only homogeneous C derivative',L(A(S))-A(L(S))-sp.diff(C,eta)*S)
    aa=[-d,d*s-E,-T(d)+2*s*d,
        T(d)*s+2*d*T(s)-T(E)-2*d*s*s+2*s*E,
        2*(H+2*s-C),2*(T(H)+T(s)+(C-s)*(H+s)),
        -f,-T(f)-(C-s)*f]
    N=aa[0]*D(T(X))+aa[1]*D(X)+aa[2]*T(X)+aa[3]*X-2*T(T(B))+aa[4]*T(B)+aa[5]*B+aa[6]*T(Q)+aa[7]*Q
    zero('expanded path-aware commutator numerator',N-L(F)+A(G))
    tt=C-s-k
    th=[aa[0],T(aa[0])+aa[1]+tt*aa[0],T(aa[1])+tt*aa[1],aa[2],
        T(aa[2])+aa[3]+tt*aa[2]-T(C)*aa[0],T(aa[3])+tt*aa[3]-T(C)*aa[1],
        aa[4]-2*tt,T(aa[4])+aa[5]+tt*aa[4],T(aa[5])+tt*aa[5],
        aa[6],T(aa[6])+aa[7]+tt*aa[6],T(aa[7])+tt*aa[7]]
    cols=[D(T(T(X))),D(T(X)),D(X),T(T(X)),T(X),X,T(T(B)),T(B),B,T(T(Q)),T(Q),Q]
    zero('twelve-column temporal compatibility expansion',T(N)+tt*N-T(C)*F-sum(v*w for v,w in zip(cols,th))+2*T(T(T(B))))
    sr=(th[3]+T(d))/(2*d);fr=-th[9]
    mm=-(th[10]+2*T(fr))/fr
    vv=-(th[1]+T(d))/d-mm
    zero('lensing logarithmic drift extraction',sr-s)
    zero('relative primitive gain extraction',fr-f)
    zero('M coefficient extraction',mm-(2*C-2*s-k))
    zero('homogeneous V combination extraction',vv-(E/d-C))
    zero('redundant Buu coefficient residual',th[6]-2*H-2*s+2*mm)
    T0=th[7]/2-2*(T(H)+T(s))-mm*(H+s)
    yy=s-C
    zero('remaining Riccati identity',T0-T(yy)-yy*yy-mm*yy)
    zero('second coefficient determines y on Delta chart',th[2]/d-T0-(T(d)/d-vv)*yy+(T(d)/d+mm)*vv+T(vv))
    zero('redshift drift from relative gain',(s-T(f)/f)-(s-T(f)/f))
elif CASE=='background':
    t=sp.symbols('t',positive=True);cc=sp.sqrt(sp.Rational(5,2))
    aE=t**sp.Rational(3,2);A=t**sp.Rational(5,2);H=sp.Rational(3,2)/t;v=cc/t
    rr=sp.Rational(1,2)/t**2;rho=rr/A;V=5/t**2
    DP=lambda z:t*sp.diff(z,t)/cc
    b=DP(A)/A;F=DP(V)+rho*DP(A);mu=DP(DP(V))+rho*DP(DP(A))
    zero('background Friedmann',3*H*H-v*v/2-rr-V)
    zero('background Raychaudhuri',-2*sp.diff(H,t)-v*v-rr)
    zero('background original scalar',sp.diff(v,t)+3*H*v+F)
    zero('background bare particle conservation',sp.diff(rho,t)+3*H*rho)
    zero('action coupling',b-cc)
    zero('fixed-density action response',mu-sp.Rational(37,4)/t**2)
    zero('action force',F+sp.Rational(7,2)*cc/t**2)
    fixture=[(0,sp.Rational(5,2),sp.Integer(-1)),(3,-sp.Rational(1,5),-sp.Rational(2,5)),(4,sp.Integer(-1),sp.Integer(0)),(5,-sp.Rational(5,3),sp.Rational(2,3))]
    for n,jj,zz in fixture:
        P=t**(-sp.Rational(n,2));w=jj*P/cc;U=zz*t*P
        delta=(-6*H*(sp.diff(P,t)+H*P)-v*sp.diff(w,t)+v*v*P-F*w)/rr
        zero('n'+str(n)+' original momentum',sp.diff(P,t)+H*P-(v*w-rr*U)/2)
        zero('n'+str(n)+' Hamiltonian',-6*H*(sp.diff(P,t)+H*P)-rr*delta-v*sp.diff(w,t)+v*v*P-F*w)
        zero('n'+str(n)+' original scalar perturbation',sp.diff(w,t,2)+3*H*sp.diff(w,t)+mu*w+b*rr*delta-4*v*sp.diff(P,t)+2*F*P)
        zero('n'+str(n)+' original Euler',sp.diff(U,t)+P+b*w+b*v*U)
        zero('n'+str(n)+' bare dust continuity',sp.diff(delta,t)-3*sp.diff(P,t))
        zero('n'+str(n)+' Einstein pressure',2*(sp.diff(P,t,2)+4*H*sp.diff(P,t)+(2*sp.diff(H,t)+3*H*H)*P)-v*sp.diff(w,t)+v*v*P+DP(V)*w)
    eta=sp.symbols('eta',negative=True)
    av=256/eta**8;C=-1/eta;d=-256/eta**7;E=1024/eta**8
    zero('fixture Delta chart',sp.diff(d,eta)/d-(E/d-C)+4/eta)
    check('observer path avoids background singularity',sp.Integer(-2)<sp.Integer(-1)<0)
    check('frozen gains everywhere positive',sp.Rational(1,9)-sp.Rational(4,7)<0 and sp.Rational(1,25)-sp.Rational(4,11)<0)
elif CASE=='observed':
    # Exact univariate jets at fixed radius. Coefficient c[n] is Taylor/n!,
    # so differentiating the actual observed matrix gives measured jets.
    ORDER=8
    class J:
        def __init__(self,value):
            if isinstance(value,J):self.c=value.c[:]
            elif isinstance(value,(list,tuple)):self.c=[sp.Rational(x) for x in value[:ORDER+1]]+[sp.S.Zero]*max(0,ORDER+1-len(value))
            else:self.c=[sp.Rational(value)]+[sp.S.Zero]*ORDER
        def __add__(self,v):
            v=J(v);return J([x+y for x,y in zip(self.c,v.c)])
        __radd__=__add__
        def __neg__(self):return J([-x for x in self.c])
        def __sub__(self,v):return self+-J(v)
        def __rsub__(self,v):return J(v)+-self
        def __mul__(self,v):
            v=J(v);return J([sum(self.c[k]*v.c[n-k] for k in range(n+1)) for n in range(ORDER+1)])
        __rmul__=__mul__
        def inverse(self):
            if self.c[0]==0:raise ZeroDivisionError('Zero jet constant')
            out=[1/self.c[0]]
            for n in range(1,ORDER+1):out.append(-sum(self.c[k]*out[n-k] for k in range(1,n+1))/self.c[0])
            return J(out)
        def __truediv__(self,v):return self*J(v).inverse()
        def __rtruediv__(self,v):return J(v)*self.inverse()
        def __pow__(self,n):
            if n<0:return self.inverse()**(-n)
            out=J(1)
            for _ in range(n):out=out*self
            return out
        def derivative(self):return J([(n+1)*self.c[n+1] for n in range(ORDER)]+[0])
        def at(self):return self.c[0]
    def zj(name,value,order=2):
        value=J(value);check(name,all(q==0 for q in value.c[:order+1]),[str(q) for q in value.c[:order+1]])
    def rank(mat):return DomainMatrix.from_Matrix(mat).convert_to(QQ).rank()
    def pivots(mat):return list(DomainMatrix.from_Matrix(mat).convert_to(QQ).rref()[1])
    z=J([0,1]);u=-1+z;eta=-2+z
    gl=1+z/3+z*z/7;gz=2*(1-z/5+z*z/11);s=gl.derivative()/gl;f=gl/gz
    a=256/eta**8;H=-8/eta;C=-1/eta;d=-256/eta**7;E=1024/eta**8
    ce=C.derivative();k=ce.derivative()/ce;tt=C-s-k
    aa=[-d,d*s-E,-d.derivative()+2*s*d,
        d.derivative()*s+2*d*s.derivative()-E.derivative()-2*d*s*s+2*s*E,
        2*(H+2*s-C),2*(H.derivative()+s.derivative()+(C-s)*(H+s)),
        -f,-f.derivative()-(C-s)*f]
    th=[aa[0],aa[0].derivative()+aa[1]+tt*aa[0],aa[1].derivative()+tt*aa[1],aa[2],
        aa[2].derivative()+aa[3]+tt*aa[2]-ce*aa[0],aa[3].derivative()+tt*aa[3]-ce*aa[1],
        aa[4]-2*tt,aa[4].derivative()+aa[5]+tt*aa[4],aa[5].derivative()+tt*aa[5],
        aa[6],aa[6].derivative()+aa[7]+tt*aa[6],aa[7].derivative()+tt*aa[7]]
    cases={0:(sp.Rational(5,2),sp.Integer(-1)),3:(-sp.Rational(1,5),-sp.Rational(2,5)),4:(sp.Integer(-1),sp.Integer(0)),5:(-sp.Rational(5,3),sp.Rational(2,3))}
    rows=[];targets=[];seeds=[]
    for ii in range(32):
        n=[0,3,4,5][ii%4];ell=ii+2;jj,zz=cases[n]
        P=eta**n;Z=-128*zz*eta**(n-7)
        I0=sum((sp.binomial(n,k0)*(-1)**k0*u**(n-k0)/sp.Integer(ell+k0+1) for k0 in range(n+1)),J(0))
        I1=I0.derivative()
        I0r=sum((sp.binomial(n,k0)*(-1)**k0*u**(n-k0) for k0 in range(n+1)),J(0))
        Y=-(1+jj)*P-(zz/2)*ell*eta**(n+1)
        X=gl*P;B=a*gl*I0
        W=gz*Y+2*(gl-gz)*I1+2*gl.derivative()*I0
        Q=a*gz*(Y-2*I1)
        zj('mode'+str(ii)+' registered path derivative',I0r-P)
        zj('mode'+str(ii)+' recorded primitive combination',a*W-2*B.derivative()+2*H*B-Q)
        F=-d*X.derivative()+(d*s-E)*X
        G=f*Q+2*B.derivative()-2*(H+s)*B
        S=gl*Z
        zj('mode'+str(ii)+' gained original momentum Euler',S.derivative()+(C-s)*S-F)
        zj('mode'+str(ii)+' gained original photon relation',gl*(Z.derivative()+ell*Z)-G)
        DX=gl*(n*eta**(n-1)+ell*P)+2*gl.derivative()*P
        cols=[DX.derivative().derivative(),DX.derivative(),DX,X.derivative().derivative(),X.derivative(),X,
              B.derivative().derivative(),B.derivative(),B,Q.derivative().derivative(),Q.derivative(),Q]
        target=2*B.derivative().derivative().derivative()
        zj('mode'+str(ii)+' full compatibility row',sum((cc*vv for cc,vv in zip(cols,th)),J(0))-target)
        rows.append(cols);targets.append(target);seeds.append({'n':n,'l':ell,'m':0})
    mats=[sp.Matrix([[sp.factorial(nn)*vv.c[nn] for vv in row] for row in rows]) for nn in range(3)]
    rhs=[sp.Matrix([sp.factorial(nn)*vv.c[nn] for vv in targets]) for nn in range(3)]
    rr=rank(mats[0]);ra=rank(mats[0].row_join(rhs[0]))
    details['physical_design']={'rank':rr,'augmented_rank':ra,'seeds':seeds,
      'rows':[[str(vv) for vv in row] for row in mats[0].tolist()],
      'target':[str(vv) for vv in rhs[0]],'expected_theta':[str(vv.at()) for vv in th]}
    check('physical target lies in actual observed column span',rr==ra,{'rank':rr,'augmented_rank':ra})
    print('ACTUAL PHYSICAL RANK '+str(rr),file=sys.stderr,flush=True)
    if rr==12:
        inds=pivots(mats[0].T);square=mats[0][inds,:];inv=square.inv(method='DM')
        recovered=[inv*rhs[0][inds,:]]
        recovered.append(inv*(rhs[1][inds,:]-mats[1][inds,:]*recovered[0]))
        recovered.append(inv*(rhs[2][inds,:]-2*mats[1][inds,:]*recovered[1]-mats[2][inds,:]*recovered[0]))
        details['physical_design'].update({'selected_rows':inds,'determinant':str(square.det(method='domain-ge')),
          'observed_matrix_first_derivative':[[str(vv) for vv in row] for row in mats[1].tolist()],
          'observed_matrix_second_derivative':[[str(vv) for vv in row] for row in mats[2].tolist()],
          'target_first_derivative':[str(vv) for vv in rhs[1]],'target_second_derivative':[str(vv) for vv in rhs[2]],
          'recovered_theta_jets':[[str(vv) for vv in row] for row in recovered]})
        for nn in range(3):
            expected=sp.Matrix([sp.factorial(nn)*vv.c[nn] for vv in th])
            check('observed coefficient derivative order '+str(nn)+' recovered',recovered[nn]==expected)
        check('all extra-row zeroth residuals',mats[0]*recovered[0]==rhs[0])
        check('all extra-row first residuals',mats[0]*recovered[1]+mats[1]*recovered[0]==rhs[1])
        check('all extra-row second residuals',mats[0]*recovered[2]+2*mats[1]*recovered[1]+mats[2]*recovered[0]==rhs[2])
        thobs=[J([recovered[0][ii],recovered[1][ii],recovered[2][ii]/2]) for ii in range(12)]
        dr=-thobs[0];sr=(thobs[3]+dr.derivative())/(2*dr);fr=-thobs[9]
        mm=-(thobs[10]+2*fr.derivative())/fr
        vv=-(thobs[1]+dr.derivative())/dr-mm
        T0=thobs[7]/2-2*(H.derivative()+sr.derivative())-mm*(H+sr)
        Delta=dr.derivative()/dr-vv
        yy=(thobs[2]/dr-T0+(dr.derivative()/dr+mm)*vv+vv.derivative())/Delta
        Cr=sr-yy;Er=dr*(Cr+vv);sz=sr-fr.derivative()/fr
        for name,actual,expected in [('d',dr,d),('sL',sr,s),('relative gain',fr,f),('C',Cr,C),('E',Er,E),('sZ',sz,gz.derivative()/gz),('Delta',Delta,d.derivative()/d-(E/d-C))]:
            check('recovered '+name,actual.at()==expected.at(),{'recovered':str(actual.at()),'expected':str(expected.at())})
        check('recovered nonconstant lensing drift derivative',sr.derivative().at()==s.derivative().at())
        check('recovered nonconstant redshift drift derivative',sz.derivative().at()==(gz.derivative()/gz).derivative().at())
        details['reconstruction']={name:str(value.at()) for name,value in [('d',dr),('sL',sr),('f',fr),('C',Cr),('E',Er),('sZ',sz),('Delta',Delta)]}
    else:
        details['physical_design']['nullspace']=[[str(vv) for vv in vec] for vec in mats[0].nullspace()]
        details['qualification']='The predeclared physical fixture does not establish rank-twelve attainability; no new rows were added.'
else:raise ValueError('Choose algebra, background or observed')
out={'stage':'Independent before root split-reception author exposure','root_split_sources_read':False,
     'software':{'python':sys.version.split()[0],'sympy':sp.__version__},'checks':checks,
     'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},
     'details':details,'wall_seconds':time.monotonic()-start,
     'scope':'Exact local action/primitive-channel identifiability controls; no observational data or assumed absolute calibration'}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
