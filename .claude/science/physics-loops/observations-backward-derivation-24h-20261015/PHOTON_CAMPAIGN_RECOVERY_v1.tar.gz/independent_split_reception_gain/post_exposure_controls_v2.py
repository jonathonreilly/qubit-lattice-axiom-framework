"""Post-exposure comparison: independent coordinate algebra and observed jets.

The author fourteen-column inverse is exposed. The forward fixture, 32 rows,
quadratic gains and exact Taylor arithmetic were frozen independently earlier.
This file imports no author implementation. No external/repository reads.
"""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[]
import json,sys,time
import sympy as sp
from sympy.polys.matrices import DomainMatrix
from sympy.polys.domains import QQ
CASE=sys.argv[1];checks=[];details={};start=time.monotonic()
def check(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
    print(('PASS ' if value else 'FAIL ')+name,file=sys.stderr,flush=True)
def zero(name,e):
    v=sp.factor(sp.cancel(sp.expand(e)));check(name,v==0,str(v))
if CASE=='algebra':
    eta,u=sp.symbols('eta u',real=True)
    a,C,d,E=[sp.Function(n)(eta) for n in ['a','C','d','E']]
    gl,gz=[sp.Function(n)(u) for n in ['gl','gz']]
    X,B,W,N= [sp.Function(n)(eta,u) for n in ['X','B','W','N']]
    T=lambda z:sp.diff(z,eta)+sp.diff(z,u)
    D=lambda z:sp.diff(z,eta)+2*sp.diff(z,u)
    dt=lambda z:T(z)/a
    L=lambda z:D(z)/a
    H=T(a)/a;h=H/a;s=T(gl)/gl;f=gl/gz
    chi=gz/gl;beta=s/a;sigma=T(gz)/(a*gz);c=C/a;e=E/a
    K=dt(c)+h*c;k=dt(K)/K;kc=T(T(C))/T(C)
    Q=a*W-2*T(B)+2*H*B
    F=-d*T(X)+(d*s-E)*X
    G=f*Q+2*T(B)-2*(H+s)*B
    ss=2*(chi-1);vv=-ss*h-2*chi*beta
    Tr=W+ss*dt(B)+vv*B;Fr=chi*d*dt(X)+chi*(e-d*beta)*X
    zero('relative gain reciprocal',chi*f-1)
    zero('relative gain reception law',L(chi)-2*dt(chi))
    zero('relative gain time law',dt(chi)-chi*(sigma-beta))
    zero('lensing drift reception law',L(beta)-2*dt(beta)-h*beta)
    zero('redshift drift reception law',L(sigma)-2*dt(sigma)-h*sigma)
    zero('curvature commutator denominator conversion',K-T(C)/a**2)
    zero('log denominator derivative conversion',k-(kc-2*H)/a)
    zero('registered forcing conversion',Tr-chi*G/a)
    zero('momentum forcing conversion',Fr+chi*F/a)
    Ni=D(F)-2*s*F-T(G)-(C-s)*G
    Nr=dt(Tr)+(h+c-sigma)*Tr+L(Fr)+(h-2*sigma)*Fr
    zero('complete commutator numerator conversion',Nr+chi*Ni/a**2)
    # Independent arbitrary N suffices for the compatibility-operator map.
    Nr=-chi*N/a**2
    zero('characteristic compatibility coordinate map',L(Nr)-(2*sigma+k)*Nr+K*Tr+chi/a**3*(D(N)-(2*s+kc)*N-T(C)*G))
    theta1=-(2*sigma+k);theta2=c-sigma
    theta12=L(ss)+(h-2*sigma-k)*ss+2*(dt(ss)+(h+c-sigma)*ss+vv)
    br=(4*dt(ss)+(h+2*theta2+theta1)*ss-theta12)/(4*chi)
    sr=br+dt(chi)/chi
    zero('fourteen inverse extracts lensing drift',br-beta)
    zero('fourteen inverse extracts redshift drift',sr-sigma)
    zero('fourteen inverse extracts C',theta2+sr-c)
    zero('fourteen inverse extracts e',chi*(e-d*beta)/chi+d*br-e)
    # Direct differential check, without importing author's path rewrite rules.
    Xpath=(D(B)-2*T(B)+H*B)/a
    J=dt(h)+h*h
    zero('first differentiated path identity',L(dt(B))-2*dt(dt(B))+J*B-dt(Xpath)-h*Xpath)
    zero('second differentiated path identity',L(dt(dt(B)))-2*dt(dt(dt(B)))-h*dt(dt(B))+J*dt(B)+(dt(J)+h*J)*B-dt(dt(Xpath))-2*h*dt(Xpath)-J*Xpath)
    zero('L squared Xprime conversion',L(L(dt(X)))-(D(D(T(X)))-3*H*D(T(X))+(2*H**2-T(H))*T(X))/a**3)
    zero('B third matter derivative conversion',dt(dt(dt(B)))-(T(T(T(B)))-3*H*T(T(B))+(2*H**2-T(H))*T(B))/a**3)
    zero('author target coordinate conversion',L(dt(W))+h*L(W)+dt(h)*W-(D(T(W))-H*T(W)+H*D(W)+(T(H)-H**2)*W)/a**2)
elif CASE=='observed14':
    # Reuse the independently frozen Taylor arithmetic, not author code.
    ORDER=8
    class J:
        def __init__(self,value):
            if isinstance(value,J):self.c=value.c[:]
            elif isinstance(value,(list,tuple)):self.c=[sp.Rational(x) for x in value[:ORDER+1]]+[sp.S.Zero]*max(0,ORDER+1-len(value))
            else:self.c=[sp.Rational(value)]+[sp.S.Zero]*ORDER
        def __add__(self,v):
            v=J(v);return J([x+y for x,y in zip(self.c,v.c)])
        __radd__=__add__
        def __neg__(self):return J([-x for x in self.c])
        def __sub__(self,v):return self+-J(v)
        def __rsub__(self,v):return J(v)+-self
        def __mul__(self,v):
            v=J(v);return J([sum(self.c[k]*v.c[n-k] for k in range(n+1)) for n in range(ORDER+1)])
        __rmul__=__mul__
        def inverse(self):
            if self.c[0]==0:raise ZeroDivisionError('Zero jet constant')
            out=[1/self.c[0]]
            for n in range(1,ORDER+1):out.append(-sum(self.c[k]*out[n-k] for k in range(1,n+1))/self.c[0])
            return J(out)
        def __truediv__(self,v):return self*J(v).inverse()
        def __rtruediv__(self,v):return J(v)*self.inverse()
        def __pow__(self,n):
            if n<0:return self.inverse()**(-n)
            out=J(1)
            for _ in range(n):out=out*self
            return out
        def derivative(self):return J([(n+1)*self.c[n+1] for n in range(ORDER)]+[0])
        def at(self):return self.c[0]
    def zj(name,value,order=1):
        value=J(value);check(name,all(q==0 for q in value.c[:order+1]),[str(q) for q in value.c[:order+1]])
    def rank(mat):return DomainMatrix.from_Matrix(mat).convert_to(QQ).rank()
    def pivots(mat):return list(DomainMatrix.from_Matrix(mat).convert_to(QQ).rref()[1])
    z=J([0,1]);u=-1+z;eta=-2+z
    gl=1+z/3+z*z/7;gz=2*(1-z/5+z*z/11)
    a=256/eta**8;H=-8/eta;Hp=H.derivative();h=H/a
    chi=gz/gl;beta=gl.derivative()/gl/a;sigma=gz.derivative()/gz/a
    C=-1/eta/a;d=-256/eta**7;e=J(4)
    cases={0:(sp.Rational(5,2),sp.Integer(-1)),3:(-sp.Rational(1,5),-sp.Rational(2,5)),4:(sp.Integer(-1),sp.Integer(0)),5:(-sp.Rational(5,3),sp.Rational(2,3))}
    rows=[];targets=[];seeds=[]
    for ii in range(32):
        n=[0,3,4,5][ii%4];ell=ii+2;jj,zz=cases[n]
        P=eta**n;Pe=n*eta**(n-1);Pr=ell*P
        P2=n*(n-1)*eta**(n-2)+2*n*ell*eta**(n-1)+ell*(ell-1)*P
        I0=sum((sp.binomial(n,k0)*(-1)**k0*u**(n-k0)/sp.Integer(ell+k0+1) for k0 in range(n+1)),J(0))
        I1=I0.derivative();I2=I1.derivative()
        Y=-(1+jj)*P-(zz/2)*ell*eta**(n+1)
        DY=-(1+jj)*(Pe+Pr)-(zz/2)*ell*((n+1)*eta**n+(ell-1)*eta**(n+1))
        X=gl*P;B=a*gl*I0
        DX=2*gl.derivative()*P+gl*(Pe+Pr)
        DDX=4*gl.derivative().derivative()*P+4*gl.derivative()*(Pe+Pr)+gl*P2
        W=gz*Y+2*(gl-gz)*I1+2*gl.derivative()*I0
        DW=2*gz.derivative()*Y+gz*DY+4*(gl.derivative()-gz.derivative())*I1+2*(gl-gz)*(2*I2+Pe)+4*gl.derivative().derivative()*I0+2*gl.derivative()*(2*I1+P)
        Xu=X.derivative();Xuu=Xu.derivative();Bu=B.derivative();Buu=Bu.derivative();Buuu=Buu.derivative();Wu=W.derivative()
        cols=[Wu/a,DW/a,W,
              (DDX.derivative()-3*H*DX.derivative()+(2*H*H-Hp)*Xu)/a**3,
              (DX.derivative()-H*Xu)/a**2,Xu/a,
              (DDX-H*DX)/a**2,DX/a,X,
              (Xuu-H*Xu)/a**2,
              (Buuu-3*H*Buu+(2*H*H-Hp)*Bu)/a**3,
              (Buu-H*Bu)/a**2,Bu/a,B]
        target=-(DW.derivative()-H*Wu+H*DW+(Hp-H*H)*W)/a**2
        # Original gained equations, evaluated without a coefficient inversion.
        Z=-128*zz*eta**(n-7);V=gz*Z
        ss=2*(chi-1);vv=-ss*h-2*chi*beta
        Tr=W+ss*Bu/a+vv*B;Fr=chi*d*Xu/a+chi*(e-d*beta)*X
        zj('row'+str(ii)+' primitive forcing',Tr-gz*Y)
        zj('row'+str(ii)+' original gained temporal equation',V.derivative()/a+(C-sigma)*V+Fr)
        zj('row'+str(ii)+' original gained characteristic equation',(gz*(Z.derivative()+ell*Z)+2*gz.derivative()*Z)/a-2*sigma*V-Tr)
        rows.append(cols);targets.append(target);seeds.append({'n':n,'l':ell,'m':0})
    mats=[sp.Matrix([[sp.factorial(nn)*v.c[nn] for v in row] for row in rows]) for nn in range(2)]
    rhs=[sp.Matrix([sp.factorial(nn)*v.c[nn] for v in targets]) for nn in range(2)]
    rr=rank(mats[0]);ra=rank(mats[0].row_join(rhs[0]))
    details['design']={'rank':rr,'augmented_rank':ra,'seeds':seeds,'matrix':[[str(q) for q in row] for row in mats[0].tolist()],
      'matrix_u':[[str(q) for q in row] for row in mats[1].tolist()],'target':[str(q) for q in rhs[0]],'target_u':[str(q) for q in rhs[1]],
      'gains':'Frozen quadratic gains; no changed or additional rows','point':{'eta':-2,'u':-1,'r':1}}
    check('frozen physical rows attain fourteen-column rank',rr==14,rr)
    check('frozen physical target is consistent',rr==ra,{'rank':rr,'augmented_rank':ra})
    if rr==14:
        inds=pivots(mats[0].T);square=mats[0][inds,:];inv=square.inv(method='DM')
        theta=inv*rhs[0][inds,:]
        theta_u=inv*(rhs[1][inds,:]-mats[1][inds,:]*theta)
        check('all 32 observed zeroth-order rows',mats[0]*theta==rhs[0])
        check('all 32 observed first-order rows',mats[0]*theta_u+mats[1]*theta==rhs[1])
        # Extraction uses observed coefficient jets; no truth/history derivatives.
        ch=1+theta[10]/4;ss=theta[10]/2
        chp=theta_u[10]/(4*a.at());ssp=theta_u[10]/(2*a.at())
        br=(4*ssp+(h.at()+2*theta[1]+theta[0])*ss-theta[11])/(4*ch)
        sr=br+chp/ch;Cr=theta[1]+sr;dr=theta[3]/ch;er=theta[6]/ch+dr*br
        check('coefficient consistency theta10=theta11/2',theta[9]==theta[10]/2)
        check('differentiated coefficient consistency',theta_u[9]==theta_u[10]/2)
        for name,value,truth in [('chi',ch,chi.at()),('beta',br,beta.at()),('sigma',sr,sigma.at()),('C',Cr,C.at()),('d',dr,d.at()),('e',er,e.at())]:
            check('observed fourteen inverse '+name,value==truth,{'recovered':str(value),'expected':str(truth)})
        G=2/dr;R=2*Cr/dr;q=h.at()-(er-1)/dr
        check('positive inferred dust R',R>0,str(R));check('positive inferred scalar kinetic qG',q*G>0,str(q*G))
        check('recovered original action background q G R',(q,G,R)==(sp.Rational(5,2),sp.Integer(1),sp.Rational(1,2)))
        details['design'].update({'selected_rows':inds,'minor_determinant':str(square.det(method='domain-ge')),
           'theta':[str(q) for q in theta],'theta_u':[str(q) for q in theta_u]})
        details['recovered']={n:str(v) for n,v in [('chi',ch),('beta',br),('sigma',sr),('C',Cr),('d',dr),('e',er),('q',q),('G',G),('R',R)]}
    else:
        details['limitation']='The predeclared quadratic fixture did not establish rank14; no row selection or gain was changed to force it.'
else:raise ValueError('Choose algebra or observed14')
out={'stage':'Post-exposure comparison; author fourteen route known','case':CASE,'software':{'python':sys.version.split()[0],'sympy':sp.__version__},
     'checks':checks,'summary':{'passed':sum(q['pass'] for q in checks),'failed':sum(not q['pass'] for q in checks)},
     'details':details,'wall_seconds':time.monotonic()-start,
     'scope':'Exact conditional mathematical checks, no observations, no rank dominance, no formal audit'}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
