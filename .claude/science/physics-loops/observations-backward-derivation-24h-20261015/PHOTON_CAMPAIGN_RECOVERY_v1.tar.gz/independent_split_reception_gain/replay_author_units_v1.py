"""Replay only the two authorized unchanged canonical helpers from snapshots."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[
 'author_snapshot_v1/canonical/scripts/scalar_photon_reception_core.py',
 'author_snapshot_v1/canonical/scripts/scalar_photon_separate_gains.py',
 'author_snapshot_v1/canonical/outputs/scalar_photon_calibration/result.json',
]
import json,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'author_snapshot_v1/canonical/scripts'))
import scalar_photon_reception_core as core
import scalar_photon_separate_gains as separate
start=time.monotonic();units={}
for name,module in [('common_reception',core),('separate_reception',separate)]:
    print('START '+name,file=sys.stderr,flush=True)
    checks,details=module.run_checks()
    units[name]={'checks':checks,'details':details,'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)}
    print('FINISH '+name+' '+str(units[name]['passed'])+'/'+str(units[name]['failed']),file=sys.stderr,flush=True)
cache=json.loads((here/AUDIT_INPUT_PATHS[2]).read_text())
# JSON normalization changes integer dict keys to the cache's JSON strings.
normalized=json.loads(json.dumps(units))
comparison={n:normalized[n]==cache['units'][n] for n in units}
out={'scope':'Unchanged authorized helper replay; not full canonical primary/conditioning execution or independent science',
     'units':units,'cache_unit_equality':comparison,'wall_seconds':time.monotonic()-start,
     'summary':{'passed':sum(comparison.values()),'failed':sum(not v for v in comparison.values())+sum(x['failed'] for x in units.values())}}
print(json.dumps(out,indent=2));raise SystemExit(int(out['summary']['failed']!=0))
