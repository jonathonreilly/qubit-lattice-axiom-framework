"""Bound and preserve post-exposure controls/replays, never overwrite evidence."""
AUDIT_TIMEOUT_SEC=120
AUDIT_INPUT_PATHS=[
 'POST_EXPOSURE_DERIVATION_v1.md','POST_ARGUMENT_FREEZE_v1.json',
 'post_exposure_controls_v2.py','replay_author_units_v1.py','run_post_bounded_v2.py',
 'AUTHOR_SNAPSHOT_v1.json','AUTHOR_DEPENDENCY_SNAPSHOT_v1.json',
 'author_snapshot_v1/campaign/SPLIT_RECEPTION_GAIN_CANDIDATE_v1.md',
 'author_snapshot_v1/campaign/check_split_reception_gain_v2.py',
 'author_snapshot_v1/campaign/check_reception_gain_dynamic_v2.py',
 'author_snapshot_v1/campaign/SPLIT_RECEPTION_GAIN_CONTROLS_v2.json',
 'author_snapshot_v1/canonical/docs/SCALAR_PHOTON_CALIBRATION_NOTE_2026-10-16.md',
 'author_snapshot_v1/canonical/scripts/scalar_photon_reception_core.py',
 'author_snapshot_v1/canonical/scripts/scalar_photon_separate_gains.py',
 'author_snapshot_v1/canonical/outputs/scalar_photon_calibration/result.json',
]
import argparse,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
ap=argparse.ArgumentParser();ap.add_argument('--case',required=True,choices=['algebra','observed14','campaign','canonical']);ap.add_argument('--attempt',required=True);args=ap.parse_args()
if not args.attempt.replace('_','').isalnum():raise ValueError('Simple new attempt label required')
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if any(prefix.with_suffix(x).exists() for x in ['.run.json','.stdout.json','.stderr.txt']):raise FileExistsError('Earlier evidence is immutable')
def bind():
    return {n:{'sha256':hashlib.sha256((here/n).read_bytes()).hexdigest(),'bytes':(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind()
if args.case=='campaign':argv=[sys.executable,'-B',str(here/'author_snapshot_v1/campaign/check_split_reception_gain_v2.py')]
elif args.case=='canonical':argv=[sys.executable,'-B',str(here/'replay_author_units_v1.py')]
else:argv=[sys.executable,'-B',str(here/'post_exposure_controls_v2.py'),args.case]
started=datetime.now(timezone.utc).isoformat();start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
with prefix.with_suffix('.stdout.json').open('wb') as of,prefix.with_suffix('.stderr.txt').open('wb') as ef:
    try:rc=subprocess.run(argv,cwd=here,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=of,stderr=ef,timeout=AUDIT_TIMEOUT_SEC,check=False).returncode
    except subprocess.TimeoutExpired:rc=None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN);after=bind()
stdout=prefix.with_suffix('.stdout.json').read_bytes();stderr=prefix.with_suffix('.stderr.txt').read_bytes()
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
summary=None;cache_equality=None;byte_equality=None
if result is not None:
    summary=result.get('summary',{'passed':result.get('passed'),'failed':result.get('failed')})
    if args.case=='campaign':
        frozen=(here/'author_snapshot_v1/campaign/SPLIT_RECEPTION_GAIN_CONTROLS_v2.json').read_bytes()
        cache_equality=result==json.loads(frozen);byte_equality=stdout==frozen
record={'case':args.case,'argv':argv,'cwd':str(here),'timeout_seconds':AUDIT_TIMEOUT_SEC,'PYTHONDONTWRITEBYTECODE':'1',
 'start_utc':started,'end_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':wall,'returncode':rc,'timed_out':timeout,
 'child_user_seconds':r1.ru_utime-r0.ru_utime,'child_system_seconds':r1.ru_stime-r0.ru_stime,'child_peak_rss_platform_units':r1.ru_maxrss,'platform':sys.platform,
 'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
 'output_parse_error':error,'summary':summary,'campaign_json_equality':cache_equality,'campaign_stdout_byte_equality':byte_equality,
 'input_binding_before':before,'input_binding_after':after,'inputs_unchanged':before==after,
 'stage':'Post-exposure comparison; copies of author files used only for replay'}
prefix.with_suffix('.run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['case','wall_seconds','returncode','timed_out','summary','campaign_json_equality','campaign_stdout_byte_equality','inputs_unchanged']},indent=2))
if rc!=0 or timeout or before!=after or cache_equality is False:raise SystemExit(1)
