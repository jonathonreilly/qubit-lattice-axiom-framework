# Targeted neutrino trace controls

Parent /root writes this supplement after the independent reviewer executed
an actual omission of the massive-neutrino trace. The original local stage
retained exactly its 279 passes and four coarse energy-difference failures.
The original raw-action oracle consumed the implementation's already computed
trace; its agreement did not independently test this source contribution.
This is a test gap, not evidence that the unmodified equation omitted it.

The supplement preserves the active v3 runner and all earlier evidence. It
executes independently of history integration against a specified source file.
It uses adaptive momentum integrals, rather than the parent's frozen Laguerre
sum, to calculate each populated species' density, pressure and trace. The
occupation is the same explicit relativistic initial distribution. All
comparisons use the nonzero neutrino contribution as their scale. A denominator
of max(1, abs(tau)) would make a dimensionless late density of order 1e-37
invisible and is expressly inappropriate here.

Freeze L=18,20,22 and the supplied final temperature, both b=k and b=a, and
k=.01,1e-5,1e-6. At these selected late temperatures the electron-pair trace
is negligible in this gas prescription. Retain its actual implementation
value in the subtraction rather than silently changing the matter content.
Compare the independently integrated neutrino source with:

    tau_J - rho_d - tau_e,
    tau_E/(C_B^2 Rstar) - rho_d - tau_e.

Also extract the matter source from the complete implemented u acceleration,
including its connection, damping and potential terms. Normalize the residual
after subtracting dust and electron trace by C_B^2 Rstar tau_nu. This tests
whether the independently specified neutrino trace reaches the field equation,
as well as the reported trace. Use a separate generic state and an
instantaneously matched ideal-fluid state. No history is refitted.

For the latter state, set u=p_u=0, x^2=Rstar rho_d,
y^2=Rstar rho_gas, p_x=-3x/2 and p_y=-2y. Define
D=1+2(1+b)(x^2+y^2)/3 and t=Rstar(tau_e+tau_nu). Substitution into
the fixed action gives the instantaneous identities

    H^2=D,
    p_u'=-sqrt(a)(1+s)t/(J_0 D),
    p_x'=x[9/4+t/(2D)],
    p_y'=y[4+2t/(3D)].

These are identities at a selected state, not a claim that the massive gas
follows the ideal-fluid orbit. The nonzero gas trace drives it away. Check
these separately against the original coordinate acceleration. The target
states are selected after earlier history results and are exposed development
controls; they are neither independent observational tests nor evidence for
the global basin of the selected cosmological history.

Freeze source and thresholds before execution. Preserve any failure. Execute
the unchanged original implementation and the actual one-line omitted-trace
source with fresh input hashes. A mutation's failure counts only when a
scientific residual fails while all source-identity controls pass. Do not
claim a full-history mutation when only these local controls are executed.
