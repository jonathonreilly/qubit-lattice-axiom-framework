#!/usr/bin/env python3
"""Parent authored local source controls; no history or empirical fit."""
from pathlib import Path
import argparse, hashlib, importlib.util, json
import numpy as np
from scipy.integrate import quad


def run(implementation, freeze):
    checks = []

    def check(name, passed, **data):
        checks.append(dict(name=name, passed=bool(passed), **data))

    def relative(name, actual, expected, scale, tolerance):
        error = abs(actual - expected) / scale
        check(name, np.isfinite(error) and error <= tolerance,
              actual=float(actual), expected=float(expected), scale=float(scale),
              normalized_error=float(error), tolerance=tolerance)

    for item in freeze['inputs']:
        check('source.' + item['path'],
              hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'])
    spec = importlib.util.spec_from_file_location('trace_target', implementation)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    inputs = module.INPUTS
    electron_eV = inputs['electron_mass_kg'] * inputs['light_speed_SI']**2 / inputs['eV_J']
    lightest = inputs['lightest_mass_eV']
    masses = np.sqrt([lightest**2,
                      lightest**2 + inputs['delta_m21_squared_eV2'],
                      lightest**2 + inputs['delta_m21_squared_eV2'] + inputs['delta_m32_squared_eV2']]) / electron_eV
    data = []
    for k in [.01, 1e-5, 1e-6]:
      for branch in ['split', 'equal']:
        cfg = module.configuration(dict(id='trace_control', k=k, branch=branch))
        for L in [18., 20., 22., cfg['Lf']]:
          gas = module.gas(L, 256)
          tn = gas['Tnu']
          integrals = []
          for mass in masses:
            r = mass / tn
            occupation = lambda q: np.exp(-q) / (1 + np.exp(-q))
            raw = [quad(lambda q: q*q*np.sqrt(q*q+r*r)*occupation(q), 0, 120,
                        epsabs=1e-11, epsrel=2e-12),
                   quad(lambda q: q**4/np.sqrt(q*q+r*r)*occupation(q), 0, 120,
                        epsabs=1e-11, epsrel=2e-12),
                   quad(lambda q: q*q*r*r/np.sqrt(q*q+r*r)*occupation(q), 0, 120,
                        epsabs=1e-11, epsrel=2e-12)]
            integrals.append([tn**4/np.pi**2*raw[0][0],
                              tn**4/(3*np.pi**2)*raw[1][0],
                              tn**4/np.pi**2*raw[2][0]])
          rho_nu, pressure_nu, trace_nu = np.sum(integrals, axis=0)
          tag = f'{branch}.{k}.{L}'
          for name, expected in [('rho_nu', rho_nu), ('P_nu', pressure_nu), ('tau_nu', trace_nu)]:
            relative(tag+'.gas.'+name, gas[name], expected, abs(expected), 3e-9)
          sx = cfg['xi'] * np.exp(-1.5*gas['NJ'])
          sy = cfg['yi'] * np.exp(-2*gas['NJ'])
          matched_y = np.sqrt(cfg['Rstar']*gas['rho_gas']) / sy
          states = [('matched', np.array([0., 1., matched_y, 0., -1.5, -2*matched_y])),
                    ('generic', np.array([.003, .98, 1.01, .002, -1.49, -2.01]))]
          for label, state in states:
            q = module.quantities(L, state, cfg, 256)
            weight = q['CB']**2 * cfg['Rstar']
            relative(tag+'.'+label+'.jordan_trace',
                     q['tau']-q['rho_dust']-gas['tau_e'], trace_nu, trace_nu, 2e-9)
            relative(tag+'.'+label+'.einstein_trace',
                     q['trace']/weight-q['rho_dust']-gas['tau_e'], trace_nu, trace_nu, 2e-9)
            p = q['p']; K = q['K']; dk = q['dk']
            connection = (p*(p@dk)-dk@(p*p)/2)/K
            recovered = (-K[0]*q['H2']*(q['acc'][0]+(3+q['h'])*p[0]+connection[0])-q['dU'][0])/q['ab']
            relative(tag+'.'+label+'.full_acceleration_trace',
                     recovered-weight*(q['rho_dust']+gas['tau_e']), weight*trace_nu,
                     weight*trace_nu, 2e-6)
            if label == 'matched':
              x, y = q['phi'][1:]
              D = 1+2*(1+cfg['b'])*(x*x+y*y)/3
              t = cfg['Rstar']*(gas['tau_e']+trace_nu)
              J0 = 1+(1-3*cfg['a'])*cfg['s']
              expected = [-np.sqrt(cfg['a'])*(1+cfg['s'])*t/(J0*D),
                          x*(2.25+t/(2*D)), y*(4+2*t/(3*D))]
              relative(tag+'.matched.H2', q['H2'], D, D, 2e-12)
              for i in range(3):
                relative(tag+f'.matched.acc.{i}', q['acc'][i], expected[i],
                         abs(expected[i]), 2e-8)
          data.append(dict(k=k, branch=branch, L=L, independent_neutrino_integrals=integrals,
                           neutrino_trace_fraction=float(trace_nu/(q['rho_dust']+gas['rho_gas']))))
    return dict(scope='Local source/instantaneous acceleration controls only; no ODE rerun or observation test.',
                implementation=str(implementation), checks=checks, data=data,
                counts=dict(passed=sum(x['passed'] for x in checks),
                            failed=sum(not x['passed'] for x in checks), total=len(checks)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--implementation', required=True, type=Path)
    parser.add_argument('--freeze', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    result = run(args.implementation, json.loads(args.freeze.read_text()))
    args.out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result['counts']), flush=True)
    raise SystemExit(bool(result['counts']['failed']))
