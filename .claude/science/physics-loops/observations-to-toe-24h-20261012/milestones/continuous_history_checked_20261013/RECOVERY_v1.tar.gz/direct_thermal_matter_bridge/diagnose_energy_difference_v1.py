from pathlib import Path
import json,datetime,hashlib
import numpy as np
import check_thermal_matter_bridge_v1 as A
P=Path(__file__).resolve().parent
sources=[P/'diagnose_energy_difference_v1.py',P/'check_thermal_matter_bridge_v1.py',P/'FIXTURES_v1.json']
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),reason='Four fixed-step energy finite-difference checks failed in first bridge local controls; equations/trajectory source untouched.',sources=[dict(path=str(f),sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sources],step_schedule=[2e-6,2e-7,2e-8,2e-9,2e-10],rows=[])
for br in ['split','equal']:
 cfg=A.configuration(dict(k=1e-5,branch=br,id='generic'))
 for L in A.FIX['generic_L']:
  for j,st in enumerate(A.FIX['generic_states']):
   st=np.asarray(st);q=A.quantities(L,st,cfg,128);v=A.rhs(L,st,cfg,128);rate=q['gas']['cT']*q['njp']
   normprime=float((q['p']@q['dk'])@(q['p']**2)+2*(q['K']*q['p'])@q['acc'])
   sigmap=-3*(q['sigma']+q['pressure'])+q['ab']*st[3]*q['trace']
   h_exact=.5*((sigmap+q['dU']@q['p'])/(q['sigma']+q['U'])+normprime/(3-q['norm']))
   steps=[]
   for e in record['step_schedule']:
    qm=A.quantities(L-e,st-e*v,cfg,128);qp=A.quantities(L+e,st+e*v,cfg,128)
    hfd=(np.log(qp['H2'])-np.log(qm['H2']))/(4*e)*rate
    steps.append(dict(step=e,h=float(hfd),normalized_error=float(abs(hfd-q['h'])/max(1,abs(q['h'])))))
   record['rows'].append(dict(branch=br,L=L,state=j,target=q['h'],analytic_chain_rule=h_exact,analytic_error=abs(h_exact-q['h'])/max(1,abs(q['h'])),steps=steps))
record['max_analytic_error']=max(r['analytic_error'] for r in record['rows'])
record['max_step_errors']={str(e):max(r['steps'][i]['normalized_error'] for r in record['rows']) for i,e in enumerate(record['step_schedule'])}
record['source_unchanged']=all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in record['sources'])
(P/'ENERGY_DIFFERENCE_DIAGNOSIS_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['max_analytic_error','max_step_errors','source_unchanged']}))
