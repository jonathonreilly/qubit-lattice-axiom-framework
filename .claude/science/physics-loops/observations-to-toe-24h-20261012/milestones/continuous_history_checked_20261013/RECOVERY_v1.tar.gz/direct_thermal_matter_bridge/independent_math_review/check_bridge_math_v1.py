"""Independent handwritten-bridge controls; no parent implementation imported."""
import datetime
import hashlib
import json
import pathlib
import re
import sys
import time
import mpmath as mp
import sympy as S

OUT=pathlib.Path(__file__).resolve().parent
start=time.monotonic()
checks=[]
mp.mp.dps=70
tol=mp.mpf('1e-45')


def exact(name,expr):
    v=S.factor(S.cancel(expr))
    ok=v==0
    checks.append(dict(name=name,kind='exact algebra',passed=bool(ok),residual=str(v)))
    if not ok: print('FAIL',name,v,flush=True)


def numeric(name,actual,expected):
    err=abs(actual-expected)/max(mp.mpf(1),abs(expected))
    ok=err<=tol
    checks.append(dict(name=name,kind='70-digit quadrature',passed=bool(ok),actual=mp.nstr(actual,65),expected=mp.nstr(expected,65),scaled_error=mp.nstr(err,8),tolerance=str(tol)))
    if not ok: print('FAIL',name,mp.nstr(err,12),flush=True)


def predicate(name,condition,details):
    checks.append(dict(name=name,kind='inequality or source identity',passed=bool(condition),details=details))
    if not condition:print('FAIL',name,details,flush=True)


# Generic thermodynamic and conformal conservation route.
A,sigma,P,Q,H2,h,gU=S.symbols('A sigma P Q H2 h gU',real=True)
sigmaprime=4*A*sigma-3*(1+A)*(sigma+P)
exact('Einstein fluid trace exchange',sigmaprime-(-3*(sigma+P)+A*(sigma-3*P)))
Qprime=-2*(3+h)*Q-2*(gU+A*(sigma-3*P))/H2
energyprime=H2*h*Q+H2*Qprime/2+gU+sigmaprime
exact('off-orbit total energy cancellation',energyprime+3*H2*Q+3*(sigma+P))
exact('Friedmann derivative and Raychaudhuri',energyprime-3*H2*(-Q-(sigma+P)/H2))
ct,beta,pu=S.symbols('ct beta pu',real=True)
clock=1+beta*pu
uL=pu/(ct*clock)
exact('Nhat from NJ minus log B',1/ct-beta*uL-1/(ct*clock))
entropy_s,entropy_prime,T,rhop=S.symbols('entropy_s entropy_prime T rhop',positive=True)
cT=3*entropy_s/rhop
exact('entropy clock derivative',T*entropy_prime/(3*entropy_s)-1/cT.subs(rhop,T*entropy_prime))

# Six-coordinate chain rule, without a logarithm of either dynamical field.
sx,sy,X,Y,vx,vy,ax,ay,au=S.symbols('sx sy X Y vx vy ax ay au',real=True)
sxN=-S.Rational(3,2)*clock*sx
syN=-2*clock*sy
XN=vx+S.Rational(3,2)*clock*X
YN=vy+2*clock*Y
vxN=ax/sx+S.Rational(3,2)*clock*vx
vyN=ay/sy+2*clock*vy
exact('x position rescaling',sxN*X+sx*XN-sx*vx)
exact('y position rescaling',syN*Y+sy*YN-sy*vy)
exact('x velocity rescaling',sxN*vx+sx*vxN-ax)
exact('y velocity rescaling',syN*vy+sy*vyN-ay)
exact('temperature-clock u velocity',ct*clock*uL-pu)
exact('temperature-clock transverse acceleration',ct*clock*(vxN/(ct*clock))-vxN)

# Independent full action; all partial derivatives precede u=0 restriction.
r,b,s,nu,u,x,y,Z=S.symbols('r b s nu u x y Z',real=True)
phi=[u,x,y]
F=1+s*S.exp(2*r*u)
J=1+(1-3*r*r)*s*S.exp(2*r*u)
D=1+S.Rational(2,3)*(1+b)*(x*x+y*y)
K=S.diag(J/F**2,(1+s)*4*b/(9*F*D),(1+s)*b/(3*F*D))
Ki=S.diag(*[1/K[i,i] for i in range(3)])
W=(S.Rational(3,2)+(b/2-r*u+2*r*r*u*u/b)*x*x+b*y*y/3+nu*u*u/2
   +s*((b/2+r*b*u+2*r*r*u*u/b)*x*x+b*y*y/3)+3*s*S.exp(4*r*u)/2)
U=(1+s)*W/F**2
alpha=S.Matrix([r/F,0,0])


def on(expr):return S.factor(S.cancel(expr.subs(u,0)))


G=[[[sum(Ki[i,n]*(S.diff(K[n,j],phi[k])+S.diff(K[n,k],phi[j])-S.diff(K[j,k],phi[n]))/2 for n in range(3)) for k in range(3)] for j in range(3)] for i in range(3)]
vv=S.symbols('v0:3',real=True)
metric_work=sum(S.diff(K[i,j],phi[k])*vv[i]*vv[j]*vv[k] for i in range(3) for j in range(3) for k in range(3))
connection_work=2*sum(K[i,i]*vv[i]*G[i][j][k]*vv[j]*vv[k] for i in range(3) for j in range(3) for k in range(3))
exact('full off-orbit metric-connection energy identity',metric_work-connection_work)
p=S.Matrix([0,-3*x/2,-2*y]);K0=K.applyfunc(on);Ki0=Ki.applyfunc(on)
Q0=S.factor((p.T*K0*p)[0]);sig0=x*x+y*y;P0=(y*y-Z)/3
H20=S.factor(2*(sig0+on(U))/(3-Q0))
h0=-(sig0+P0)/H20-Q0
exact('initial Friedmann energy',H20-D)
exact('initial constraint denominator',3-Q0-(3+(2+b)*x*x+(2+2*b/3)*y*y)/D)
ideal_h=-(1+b)*(x*x+S.Rational(4,3)*y*y)/D
exact('initial thermal trace Raychaudhuri shift',h0-ideal_h-Z/(3*D))
acc=[]
for i in range(3):
    force=sum(Ki0[i,j]*(on(S.diff(U,phi[j]))+on(alpha[j])*(sig0-3*P0)) for j in range(3))
    acc.append(S.factor(S.cancel(-(3+h0)*p[i]-sum(on(G[i][j][k])*p[j]*p[k] for j in range(3) for k in range(3))-force/H20)))
J0=1+(1-3*r*r)*s
expected=[-r*(1+s)*Z/(J0*D),9*x/4+x*Z/(2*D),4*y+2*y*Z/(3*D)]
for i in range(3):exact('initial full scalar acceleration '+str(i),acc[i]-expected[i])
exact('initial rescaled vx acceleration',acc[1]/x-S.Rational(9,4)-Z/(2*D))
exact('initial rescaled vy acceleration',acc[2]/y-4-2*Z/(3*D))
for i,val in enumerate([0,9*x/4,4*y]):exact('ideal mixed-fluid orbit '+str(i),acc[i].subs(Z,0)-val)

# Physical clocks and two independent SI/natural-unit normalization routes.
CB,B0,Bnow,H,Hv,q,rv,ru,k,Gsi,c,hbar,Ee=S.symbols('CB B0 Bnow H Hv q rv ru k Gsi c hbar Ee',positive=True)
Hhatv=Hv/S.sqrt(1+s)
exact('physical Hubble clock',((Hhatv*H/Bnow)*clock/Hv)**2-H**2*clock**2/((1+s)*Bnow**2))
exact('physical elapsed age',Hv*Bnow/(Hhatv*H*ct*clock)-S.sqrt((1+s)*Bnow**2)/(H*ct*clock))
exact('Einstein density scale',(Bnow**4*Ee**4/(2*q*Hhatv**2))-((1+s)*Bnow**2)**2*(Ee**4/(2*q*(1+s)*Hv**2)))
qtotal=(1+k)*hbar*c**5/(8*S.pi*Gsi)
Hv2=8*S.pi*Gsi*rv/(3*c*c)
rho_unit=Ee**4/(hbar*c)**3
Rnatural=Ee**4/(2*qtotal*hbar*hbar*Hv2)
exact('SI Rstar by Planck-energy conversion',Rnatural-3*rho_unit/(2*(1+k)*rv))
exact('reference GR density ratio',1+2*(1+k)*(3*ru/(2*(1+k)*rv))*sigma/3-(1+ru*sigma/rv))
exact('physical effective scalar norm',(r/F)**2/(J/F**2)-r*r/J)
exact('physical Newton coefficient ratio',(Bnow**2*(1+r*r/J)/(B0**2*(1+k)))-((1+s)*Bnow**2)*(1+r*r/J)/(1+k)).subs if False else None
exact('physical Newton coefficient ratio',(Bnow**2*(1+r*r/J)/(B0**2*(1+k))-((1+s)*Bnow**2)*(1+r*r/J)/(1+k)).subs(B0**2,1/(1+s)))
print('Exact fixed-action, exchange, initial-state and coordinate identities complete.',flush=True)

# Numerically independent neutrino controls. All mass ratios below are toys.
pieces=[mp.mpf(0),mp.mpf(1),mp.mpf(4),mp.mpf(16),mp.mpf(64),mp.inf]
f=lambda q:1/(mp.exp(q)+1)
n0=mp.quad(lambda q:q*q*f(q),pieces)/mp.pi**2
numeric('decoupled number normalization',n0,3*mp.zeta(3)/(2*mp.pi**2))
nu_rows=[]
for ratio_text in ['0','0.1','1','10','100']:
    m=mp.mpf(ratio_text)
    energy=lambda q:mp.sqrt(q*q+m*m)
    rho=mp.quad(lambda q:q*q*energy(q)*f(q),pieces)/mp.pi**2
    pressure=mp.quad(lambda q:q**4/energy(q)*f(q) if q else mp.mpf(0),pieces)/(3*mp.pi**2)
    trace=mp.quad(lambda q:m*m*q*q/energy(q)*f(q) if q else mp.mpf(0),pieces)/mp.pi**2
    deriv=mp.quad(lambda q:q**3*energy(q)*f(q)*(1-f(q)),pieces)/mp.pi**2
    numeric('decoupled trace r='+ratio_text,rho-3*pressure,trace)
    numeric('decoupled redshift derivative r='+ratio_text,deriv,3*(rho+pressure))
    predicate('decoupled energy bounds r='+ratio_text,rho>=m*n0 and pressure>=0 and trace>=0,'rho >= m n, P >= 0, trace >= 0')
    feq=lambda q:1/(mp.exp(energy(q))+1)
    rhoeq=mp.quad(lambda q:q*q*energy(q)*feq(q),pieces)/mp.pi**2
    Peq=mp.quad(lambda q:q**4/energy(q)*feq(q) if q else mp.mpf(0),pieces)/(3*mp.pi**2)
    neq=mp.quad(lambda q:q*q*feq(q),pieces)/mp.pi**2
    deq=mp.quad(lambda q:q*q*energy(q)**2*feq(q)*(1-feq(q)),pieces)/mp.pi**2
    eq_residual=deq-3*(rhoeq+Peq)
    if m==0:
        numeric('massless eigenstate pair energy',rho,7*mp.pi**2/120)
        numeric('massless equilibrium and frozen occupation agree',rhoeq,rho)
        numeric('massless equilibrium redshift identity',eq_residual,0)
    else:
        predicate('massive equilibrium replacement detected r='+ratio_text,abs(eq_residual)>tol and neq<n0 and rhoeq<rho,'equilibrium has positive redshift-law residual and depleted number/energy at these fixed nonzero toy masses')
    nu_rows.append(dict(r=ratio_text,decoupled_rho=mp.nstr(rho,65),decoupled_P=mp.nstr(pressure,65),decoupled_trace=mp.nstr(trace,65),decoupled_number=mp.nstr(n0,65),equilibrium_rho=mp.nstr(rhoeq,65),equilibrium_P=mp.nstr(Peq,65),equilibrium_number=mp.nstr(neq,65),equilibrium_redshift_residual=mp.nstr(eq_residual,65)))
    print('Neutrino distribution control r='+ratio_text+' complete.',flush=True)

# Frozen primary NIST rows, without certification of any neutrino data.
plan=json.loads((OUT/'PRE_EXECUTION_PLAN_v1.json').read_text())
constants={row['name']:mp.mpf(re.split(r'\s{2,}',row['raw_line'])[1].replace(' ','')) for row in plan['NIST_selected_relevant_rows']}
electron_energy=constants['electron mass']*constants['speed of light in vacuum']**2
predicate('electron SI energy rounding consistency',abs(electron_energy-constants['electron mass energy equivalent'])<mp.mpf('5e-25'),'Within half of the last printed energy-equivalent digit; not an independent measurement.')
hbar_value=constants['Planck constant']/(2*mp.pi)
rho_unit_value=electron_energy**4/(hbar_value*constants['speed of light in vacuum'])**3
Tf=constants['Boltzmann constant']*mp.mpf('2.72548')/electron_energy
NIST_values=dict(electron_rest_energy_J=mp.nstr(electron_energy,65),electron_rest_energy_eV=mp.nstr(electron_energy/constants['electron volt'],65),rho_unit_J_m3=mp.nstr(rho_unit_value,65),supplied_T0_K='2.72548',dimensionless_Tf=mp.nstr(Tf,65),scope='Exposed electron/SI calibration only. No H0 parsec conversion, actual neutrino mass-squared values, final neutrino density or final Rstar has been certified.')

for name,value in [('NEUTRINO_CONTROLS_v1.json',nu_rows),('SI_REFERENCE_VALUES_v1.json',NIST_values),('INITIAL_ACTION_IDENTITIES_v1.json',dict(state='u=pu=0, sigma=x^2+y^2, pi=(y^2-Z)/3; Z=Rstar times non-dust trace',H2=str(H20),Qkin=str(Q0),h=str(S.factor(h0)),accelerations=list(map(str,acc))))]:
    with (OUT/name).open('x') as out:
        json.dump(value,out,indent=2);out.write('\n')
result=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),sympy=S.__version__,mpmath=mp.__version__,mpmath_dps=mp.mp.dps,numerical_tolerance=str(tol),elapsed_seconds=time.monotonic()-start,checks=checks,passed=sum(row['passed'] for row in checks),failed=sum(not row['passed'] for row in checks),nu_mass_inputs_certified=False,parent_implementation_used=False,scope='Independent exact algebra and arbitrary-mass distribution controls, not an evolution or empirical fit.')
with (OUT/'RESULTS_v1.json').open('x') as out:
    json.dump(result,out,indent=2);out.write('\n')
print(f"TOTAL: PASS={result['passed']} FAIL={result['failed']}",flush=True)
raise SystemExit(bool(result['failed']))
