# Direct curvature, fluid and measured-gravity reconstruction — v1

Parent /root, 2026-10-13. Written before this block's numerical execution.
This changes the candidate action explicitly. It does not extend the earlier
analytic-fluid theorem unchanged, supply a new measured early expansion
rate, or establish a TOE. Observations motivate a cross-domain consistency
question: the Newton coefficient used to normalize density is measured
locally, and need not equal the bare cosmological tensor coefficient.

## 1. Separate assumptions exposed by the inverse problem

Use signature (-+++), c=1, fields (u,x,y), alpha=sqrt(a), A=exp(alpha u),
a in (0,1/3), b in (0,1/3), nu,H_v,q>0, and zeta>=0. Unlike the old candidate,
b is now an independent fluid-kinetic coupling; a remains the matter
conformal coupling. The old equality b=a is a special subfamily, not a
measurement. All parameters in the unreduced action, including a,b,H_v,nu
and zeta, are independent of the auxiliary variable q.

Define
  D_b=1+2(1+b)(x^2+y^2)/3,
  K_b=diag(1,4b/(9D_b),b/(3D_b)),
  V0/H_v^2=3/2+[b/2-alpha u+(2a/b)u^2]x^2
                     +(b/3)y^2+(nu/2)u^2,
  V1/H_v^2=[b/2+alpha b u+(2a/b)u^2]x^2+(b/3)y^2.

The b=a,zeta=0 subfamily is exactly the previously checked analytic-fluid
action. The coefficient 2a/b is an explicit new off-trajectory choice,
chosen to keep the quadratic coefficient positive for b much smaller
than a. It is not determined by the ideal expansion curve or measured
here. b=0 is not an admitted field metric; statements about small b are
limits through positive b.

The new unreduced action is
  integral vol_g q [R/2-K_b(grad phi,grad phi)-2V0]
  + zeta/2 integral vol_J R_J
  + zeta integral vol_g [-K_b,xx(grad x)^2-K_b,yy(grad y)^2-2V1]
  - integral vol_g Lambda A^4 + Gamma_m[A^2g,psi]
  + integral (Lambda/mu_aux^4) F4
  + integral [q^2/(2M_aux^4)] Fhat4.

The zeta kinetic and potential operators are supplied new theory. They are
reconstructed to recover the desired ideal-fluid orbit; no quantum-loop
coefficient, naturalness or uniqueness claim is made. Matter vacuum energy
rho_vac in Gamma_m is a constant and combines with Lambda as before.
Real noncompact forms and the prior finite-boundary-sector assumptions are
retained. V1 and K_b are explicitly q-independent before variation.

After form variation q,Lambda are constant. Set
  s=zeta/q, z=s A^2, J=1+(1-3a)z,
  C=(Lambda+rho_vac)/(2q), W=V0+s V1+C A^4.
The reduced action has F=q(1+z), Z_uu=q-3a zeta A^2,
Z_xx=(q+zeta)K_b,xx, Z_yy=(q+zeta)K_b,yy, and potential 2qW.
Choosing ghat=(1+z)g after variation gives
  Khat_uu=J/(1+z)^2,
  Khat_xx=(1+s)K_b,xx/(1+z), similarly for y,
  Vhat=W/(1+z)^2, B=A/sqrt(1+z), g_J=B^2 ghat.
All kinetic eigenvalues are positive for this stated finite-field domain.

## 2. Exact ideal-fluid history from the full equations

Supply flat homogeneous expansion, separately conserved nonnegative ideal
dust/radiation and C/H_v^2=3s/2. Let N=ln(scale_g) and set
  u=0, x=x0 exp(-3N/2), y=y0 exp(-2N),
  rho_m=2(q+zeta)H_v^2 x^2,
  rho_r=2(q+zeta)H_v^2 y^2,
  H=H_v sqrt(D_b).
Since A=1 and udot=0, these are also physical Jordan density, scale and
proper time. x0,y0,H_v are supplied initial/scale inputs.

Let X=H_v^2 x^2, Y=H_v^2 y^2 and T_b=K_b,ij phidot^i phidot^j.
Then
  T_b=b(X+4Y/3),
  W=(1+s)[3H_v^2/2+bX/2+bY/3],
  Hdot=-(1+b)(X+4Y/3),
  R=6(2H^2+Hdot)=12H_v^2+2(1+b)X.
The two independent metric equations reduce exactly to
  3(q+zeta)H^2=rho_m+rho_r+(q+zeta)T_b+2qW,
  -2(q+zeta)Hdot=rho_m+4rho_r/3+2(q+zeta)T_b.

For x,y all kinetic and force terms on u=0 acquire the same factor q+zeta.
The old gradient-flow identity applies with a replaced by b:
v_i=-[b/(1+b)] partial_i(H_v sqrt(D_b)).
Thus the full two scalar equations hold, not just the energy constraint.
The coefficient K_b is a fixed field function D_b(x,y), not the actual
time-dependent H inserted into an action.

The separate u equation on this orbit is
  -2q W_u+alpha zeta R+alpha T_m=0,
  T_m=-rho_m.
Here
  W_u=alpha[(sb-1)X+6sH_v^2].
The constant terms cancel and the coefficient of X is
  -2(sb-1)+2s(1+b)-2(1+s)=0.
Dropping either the zeta Ricci source, the new potential's u term, or the
matter trace would spoil this equality. Radiation's ideal trace is zero.

## 3. Auxiliary constraint and what is held fixed

The q-variation still contains only
  L0=R/2-K_b(grad phi,grad phi)-2V0,
  Fhat4=-M_aux^4 L0 vol_g/q,
  F4=mu_aux^4 A^4 vol_g.
No derivative of s=zeta/q may be omitted by varying an already substituted
fixed-sector action as though s were an independent original variable.
The new terms have no explicit q dependence in the unreduced action.

Along this orbit
  L0=3H_v^2+(1+b)X+(2b/3)Y.
The finite flux ratio remains the volume average of this expression
because A=1. For a finite history with nonzero positive fluids it exceeds
3H_v^2. The future-ratio value 3H_v^2 still needs its separately stipulated
regulated-boundary interpretation; it is not a pair of finite absolute
fluxes on an infinite future. Matter vacuum compensation
rho_vac -> rho_vac+delta, Lambda -> Lambda-delta leaves local fields and
forms unchanged in the same classical sector.

## 4. Off-trajectory and local-vacuum checks

The x^2 coefficient in V0+sV1 is
  f_s(u)=b(1+s)/2+alpha(sb-1)u+[2a(1+s)/b]u^2.
Its leading coefficient is positive and
  4 A_quad C_quad-B_quad^2
    =a[4(1+s)^2-(sb-1)^2]
    =a[3+(2-b)s][1+(2+b)s]>0.
Thus f_s is positive for all real u in the admitted domain. This bound
does not restore the old global convergence proof in the new ghat frame:
for s>0 and x=y=0, Vhat tends to C/s^2 at the finite scalar-distance end.

At u=x=y=0, C/H_v^2=3s/2 and H_J=H_v, the physical local squared masses are
  m_u^2/H_v^2=[nu(1+s)+12as]/[1+(1-3a)s],
  m_x^2/H_v^2=9/4, m_y^2/H_v^2=2.
The extra V1 vanishes on x=y=0 and does not change the prior u vacuum or
matter coupling. Away from that vacuum the mass matrix and cosmological
perturbations must be calculated again; no old eigenvalue theorem is
imported. The large explicit coefficient 2a/b for small b is retained.

## 5. Match density to the measured local Newton coefficient

Under the earlier supplied light-scalar, weak-body, universal-coupling
bridge, freeze a u=0 background over the local experiment. In the vacuum
this is exactly the prior weak-field setup:
  k=alpha_eff^2=a/[1+(1-3a)s],
  G_N=(1+k)/[8pi(q+zeta)].
Applying this normalization during an ideal-fluid epoch additionally
requires wavelengths short compared with cosmological evolution and all
relevant mass/mixing scales, so the locally frozen exchange description
is valid. This is an explicit bridge, not an apparatus or nonlinear
cosmological-perturbation calculation.

Eliminating q+zeta from the exact homogeneous equations gives
  H_J^2=H_v^2+(8pi G_N/3) S^2 (rho_m+rho_r),
  S^2=(1+b)/(1+k).
S is the matter/radiation contribution's expansion ratio against the
specified GR reference at the same physical densities and G_N. The total
Hubble ratio includes H_v and only approaches S when fluids dominate.

On the old equality subfamily b=a and the weak-field eta=0 family,
  s=(1+k)/[k(1-3k)],
  a=(1-k)(1+3k)/4, 0<k<1/3,
one obtains S^2=(5-3k)/4. For small k this is about 1.25, or S about 1.118.
This is a cross-domain response consequence, not a statistical exclusion.
The exposed Cassini/LLR summaries selected diagnostic weak-field ranges;
they are not an independent observation of early expansion.

The enlarged action lets the expansion normalization fix
  b=S_target^2(1+k)-1.
In particular choosing the supplied GR reference S_target=1 gives b=k.
This is a calibration relation between admitted independent constants,
not a prediction of them and not evidence that the enlarged action fits
the actual thermal history. q and zeta can then be normalized using G_N.
When selecting b=k in a sector, b is still held fixed in original
q-variation. It must never be replaced by a(q,zeta) inside that variation.
If S_target gives b<=0 or b>=1/3, this stated positive-b domain does not
admit it, and the excluded result must be retained.

## 6. Early thermal-history comparison and its limits

An ideal radiation background alone is not a nuclear-reaction prediction.
For a deliberately supplied pre-electron-annihilation equilibrium gas,
photons, relativistic electron/positron pairs and three equal-temperature
neutrino species give g_*=43/4; one extra such neutrino contributes 7/4.
A background-only speed ratio can therefore be expressed at that epoch as
  Delta N_pre=(43/7)(S^2-1).
After ideal instantaneous annihilation, write
  c_nu=(7/8)(4/11)^(4/3),
  rho_r/rho_gamma=1+c_nu N_base,
  Delta N_post=(S^2-1)(1/c_nu+N_base).
We supply N_base=3 in the instantaneous idealization, not a measured
neutrino abundance or the precise noninstantaneous standard-model value.
The two numbers generally differ: a fixed rescaling of all radiation is
not one added free-streaming neutrino population through this transition.
Neither is a likelihood score. The reconstructed scalar perturbations are
not established to match free-streaming neutrino perturbations.

The old b=a null branch would require an approximately 25% background
density-equivalent change; the b=k branch removes that particular ideal
background mismatch by calibration. During actual electron annihilation
rho-3p is nonzero, the temperature/entropy laws change, and u=0 with
y proportional to scale^-2 need not remain a solution. The full thermal
equations, neutrino transport, reaction network, abundances and primordial
perturbations remain open. No BBN/CMB exclusion or fit is claimed.

## 7. Check plan and status

Parent will freeze exact rational and high-precision fixture controls:
action-frame coefficients; full Friedmann/Raychaudhuri and all three scalar
equations; q-variation with constants held correctly; explicit off-trajectory
positivity; local canonical Hessians; density/G_N elimination; old equality
and enlarged b=k branches; retained inadmissible inverse targets; pre/post
ideal thermal diagnostics. Separate new-operator-off controls must expose
the actual residual. Independent focused proof and numerical checks follow.
Finite-grid passes will not prove history selection, global stability or
quantum consistency. Primary thermal references and already-exposed
weak-field sources must be recorded with reading scope before execution.

