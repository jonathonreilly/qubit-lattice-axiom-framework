# Scope clarification before v2 execution

In handwritten v1 section1, the b=a,zeta=0 reduction reproduces the prior
analytic-fluid K,V,A functions. Recovering that theory's local bulk field
equations also uses C=0, supplied by the present orbit condition at s=0,
and a fixed q sector. The unreduced auxiliary/form action and its boundary
constraints remain; they are not the earlier action with those terms absent.
This is a qualification of the word action in that comparison. No displayed
formula, original frozen input or numerical physical result is changed.

The focused mathematical reviewer identified this reading distinction.
New version2 computation adds equation and output controls only; original
v1 execution, its source and the actual missed mutations remain preserved.
