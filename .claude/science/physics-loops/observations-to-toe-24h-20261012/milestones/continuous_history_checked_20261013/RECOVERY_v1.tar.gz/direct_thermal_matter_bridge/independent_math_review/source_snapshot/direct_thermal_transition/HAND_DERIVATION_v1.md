# Direct electron–positron transition — handwritten v1

Parent /root, before this block's execution, 2026-10-13. This is a new
conditional physical-history test of the reconstructed action. No candidate
parameter is fitted to the results. It does not run a nuclear network or
predict a light-element abundance.

## 1. Physical input and restricted question

Take the new curvature-fluid action as declared in
../direct_curvature_fluid_reconstruction/HAND_DERIVATION_v1.md, with x=0.
The x=0,xdot=0 surface is invariant. Supply photons, electron/positron
pairs in electromagnetic equilibrium with zero chemical potential, and
three massless neutrino/antineutrino pairs. Neutrinos are stipulated fully
decoupled after an initial common temperature T_i=10 m_e. These species,
their statistics, electron mass and universal Jordan metric are imported
matter physics, not derived by the candidate.

Use hbar=c=k_B=m_e=1 for the thermal integrals. Calling T/m_e the
dimensionless temperature avoids pretending a mass or gravity scale has
been newly measured. Ignore baryons, nuclear binding and reaction energy,
chemical potentials, incomplete neutrino transport, plasma QED corrections,
other massive species and primordial inhomogeneity. These are physical
approximations, not mathematical identities of the real thermal plasma.
T_i and the initial scalar state are supplied development choices.
The endpoint T_f=.01 m_e covers pair disappearance, not recombination.

In physical Jordan units let f(E)=1/(exp(E/T)+1), E=sqrt(p^2+1), g_e=4.
The admitted thermal integrals are
  rho_e=g_e/(2pi^2) integral_0^infinity p^2 E f(E) dp,
  P_e=g_e/(6pi^2) integral_0^infinity p^4/E f(E) dp,
  d rho_e/dT=g_e/(2pi^2 T^2)
                integral_0^infinity p^2 E^2 f(E)[1-f(E)] dp.
Add rho_gamma=pi^2 T^4/15, P_gamma=rho_gamma/3,
rho_nu=3*(7pi^2/120)*T_nu^4, P_nu=rho_nu/3.
The positive pair trace is also independently
  rho_e-3P_e=g_e/(2pi^2) integral p^2/E f(E) dp.
This second integral tests subtraction and sign.

## 2. Entropy and the actual radiation trace

For the photon/pair plasma, s_pl=(rho_pl+P_pl)/T and
d rho_pl/dT=T d s_pl/dT. Thus separate entropy conservation gives
  d ln T/dN_J=-c_T(T),
  c_T=3(rho_pl+P_pl)/(T d rho_pl/dT).
A fully decoupled neutrino temperature obeys d ln T_nu/dN_J=-1.
Consequently T_nu/T at any T is also fixed algebraically:
  T_nu/T=[(s_pl(T)/T^3)/(s_pl(T_i)/T_i^3)]^(1/3).
This formula supplies a separate trajectory/entropy check. For the finite
chosen T_i its late value differs slightly from the infinite-temperature
instantaneous limit (4/11)^(1/3). No corrected Standard Model N_eff value
is substituted into this idealization.

The total fluid trace tau=rho-3P is the electron/positron contribution.
It sources u and changes the temperature versus scale law. A radiation
density forced to decay exactly as scale^-4 would violate this thermodynamics
through the transition. No fixed Delta N equivalent is used as a likelihood.

## 3. Full coupled field system and normalization

Set s=zeta/q, E_A=exp(2sqrt(a)u), z=s E_A, F=1+z,
J=1+(1-3a)z, D=1+2(1+b)y^2/3, B^2=E_A/F.
The fixed-sector Einstein metric is ghat=F g, matter metric g_J=B^2 ghat.
Use Hhat_v=H_v/sqrt(1+s) as the frequency unit, and
  R_star=m_e^4/[2q(1+s)H_v^2],
  C_B=(1+s)B^2.
R_star is supplied; the large values tested make the vacuum contribution
negligible over this thermal window. They are not a calibrated H_v or G_N.
Dimensionless Einstein fluid density and pressure are
  sigma=C_B^2 R_star rho(T,T_nu),
  pi_f=C_B^2 R_star P(T,T_nu).
Here rho and P are the dimensionless integrals above.

The field metric components and normalized potential are
  K_u=J/F^2, K_y=(1+s)b/(3FD),
  U=(1+s)[3/2+nu u^2/2+b(1+s)y^2/3+(3s/2)E_A^2]/F^2.
Write N=ln(scale_hat), p=du/dN, ell=ln y, w=dell/dN.
Use y>0; this is a chart for this positive initial branch only.
Then
  Q=K_u p^2+K_y y^2 w^2,
  Hhat^2/Hhat_v^2 = H2=2(sigma+U)/(3-Q),
  h=dln(Hhat)/dN=-(sigma+pi_f)/H2-Q.
The local matter-gradient component is alpha_B=sqrt(a)/F, and
N_J'=1+alpha_B p. Remain on a positive H2, positive N_J' branch.

Full equations, with derivatives of U at fixed original a,b,s,nu, are
  u'=p, ell'=w,
  p'=-(3+h)p
      -[sqrt(a) z ((1-3a)/J-2/F)]p^2
      -[sqrt(a)z/F]K_y y^2 w^2/K_u
      -[U_u+alpha_B(sigma-3pi_f)]/(K_u H2),
  w'=-(3+h)w+[2sqrt(a)z/F]p w-w^2/D
      -2(1+s)D/(F H2),
  (ln T)'=-c_T(T)(1+alpha_B p),
  (ln T_nu)'=-(1+alpha_B p),
  N_J'=1+alpha_B p.

The u equation uses
  U_u=(1+s)[nu u+6sqrt(a)s E_A^2]/F^2
           -[4sqrt(a)z/F]U.
The w equation includes the derivative from p_y=yw; dropping the extra
-w^2 would give the wrong connection term. These equations come from the
full covariant scalar/Einstein/fluid equations, with neither u nor the
physical gravitational coefficient forced to remain constant.

Initially u=p=0, T=T_nu=T_i,
y^2=R_star rho(T_i,T_i), w=-2.
This supplies the ideal relativistic tracking state using the actual
finite-temperature energy density. It is not an exact equilibrium once
the finite pair trace is retained. No trajectory-selection claim follows.

## 4. Physical observables and reference

The inherited weak-body massless scalar norm, evaluated as a diagnostic, is
  k(u)=a/J.
The normalization at u=0 is G_N0=(1+k0)/[8pi q(1+s)].
Under the same frozen-background, long-range bridge the local ratio is
  G_N(u)/G_N0=C_B(1+k(u))/(1+k0).
This expression alone does not validate PPN during the early plasma.

The physical expansion and the specified GR comparison are
  H_J^2/H_v^2 = H2 [1+alpha_B p]^2/C_B,
  H_GR^2/H_v^2 = 1+(2/3)(1+k0)R_star rho(T,T_nu).
Both use the same actual photon/pair/neutrino temperatures and densities,
and the fixed reference G_N0. The total H ratio is computed from these
expressions, not from the ideal S^2 formula. The prior equation
S^2=(1+b)/(1+k0) is tested only in the massless ideal control.

For the previously defined eta-null family test the old b=a and the new
calibrated b=k0 branches separately. Do not adjust b,a,s,nu after inspecting
the transition. Record the full temperature path, minimum and maximum
H_J/H_GR, extrema and endpoint of u,p, finite kinetic domain and the
gravity diagnostic. H_v remains an imported scale and C is unchanged.

## 5. Validation and limitations

Parent will compute the thermal integrals directly, freeze their table and
interpolation recipe, check independent trace integrals and thermodynamic
derivatives, and integrate the full equations. A massless-plasma control
must recover the ideal solution; exact entropy and total-fluid conservation
provide separate checks. Quadrature/refinement and solver variations must
test accuracy at fixed physical inputs; failed/excluded runs remain visible.
No likelihood or observational bound is assigned to these synthetic runs.

Primary thermodynamic conventions and instantaneous-decoupling limits were
checked in Pitrou et al., https://arxiv.org/pdf/1801.08023, sections II.A–B,
II.F–G (Eqs.20–32,59–66), with further integral details to be read before
execution. The source's precise transport and abundance results are not
recomputed or imported as tests here. The Fields et al. reference,
https://arxiv.org/pdf/1912.01132, Eqs.1–2 and stated standard-BBN assumptions,
motivates comparison at fixed physical density and Newton normalization.
Neither paper's N_eff summary is a ready-made likelihood for this action.

A correct thermal background still leaves weak/nuclear reactions, baryon
density, light-element data, neutrino transport, perturbations, initial
conditions, late-epoch matching and quantum completion unresolved.

