# Independent bridge derivation

Reviewer `/root/bridge_equation_check`; author remains `/root`. This is a
focused mathematical check of the frozen handwritten source, not a review of
the parent's numerical implementation, a global-existence result, an empirical
fit or a formal audit verdict. The parent and checker use separate contexts of
the same model family. The previous checker's script is preserved but not run
or imported. No parent implementation or computed history supplies a result
below. Numerical checks supplement the derivation; they do not prove its
quantified statements.

## 1. Collisionless neutrino gas

Let each mass eigenstate have the supplied two populated states, an isotropic
occupation `f(q)=1/(exp(q)+1)`, and physical momentum `p=Tnu q`. Its phase-space
measure is `2 d^3p/(2pi)^3`, so

    rho = Tnu^4/pi^2 ∫ q² sqrt(q²+r²) f(q) dq,
    P   = Tnu^4/(3pi²) ∫ q⁴/sqrt(q²+r²) f(q) dq,
    n   = Tnu³/pi² ∫ q² f(q) dq,
    r   = m/Tnu.

Subtraction under the integral gives the displayed positive trace, without
subtracting two large computed densities. With `I(r)` the energy integral,
`Tnu rho_Tnu=Tnu^4[4I-r I_r]`. Since
`4sqrt(q²+r²)-r²/sqrt(q²+r²)=3sqrt(q²+r²)+q²/sqrt(q²+r²)`, this is exactly
`3(rho+P)`. The derivative and integrals commute for each finite nonnegative
mass and positive temperature by exponentially integrable bounds. Thus
`Tnu∝a_J^-1` gives the correct collisionless continuity equation even when
the particles are nonrelativistic. Also `a_J³ n` is constant.

For `r=0`, expanding the Fermi factor in its alternating exponential series
gives `∫q³ f dq=(1-2^-3)Gamma(4)zeta(4)=7pi^4/120`. Hence the quoted
`7pi²Tnu^4/120` is per mass eigenstate with its two supplied populated states,
not per single helicity state. In the nonrelativistic limit `rho/(mn)→1` and
`P/rho→[5zeta(5)/zeta(3)]r^-2`. An occupation `f(sqrt(q²+r²))` evolving with
the current `r` would violate the collisionless number/energy laws; its
Boltzmann suppression does not describe the assumed relic population.

The v2 distribution qualification is necessary: initial finite-mass thermal
equilibrium would freeze a function of `sqrt(q²+(m/Ti)²)` instead. Its later
argument must retain that *initial* mass ratio. The v2 approximation is
mathematically well defined, and is not an assertion that finite-mass initial
corrections vanish.

The frozen PDG table uses `dm32²`, so for its assumed normal ordering and
`m1=0`, `m2=sqrt(dm21²)` and `m3=sqrt(dm21²+dm32²)`. Setting
`m3=sqrt(dm32²)` would not reproduce both quoted gaps. Oscillations do not
fix `m1=0` or the relic occupation. I independently read preserved PDG pages
1, 36 and 40 and inspected the page-36 image: the chosen values are the NO,
Ref.181 with SK-ATM column. No other PDG results are certified here.

## 2. Plasma entropy clock and Jordan conservation

For the supplied zero-chemical-potential equilibrium photon/pair plasma,
integration by parts in the pressure integral gives `P_T=(rho+P)/T=s`.
Consequently `T s_T=rho_T`. Separate conservation gives
`rho_T Tdot=-3H_J(rho+P)`, hence

    -d ln T/dN_J = 3(rho+P)/(T rho_T) = c_T > 0.

Conserving `s a_J³` and defining `Sbar=s/T³`, `L=ln(Ti/T)` gives
`N_J=L-(ln Sbar-ln Sbar_i)/3`. Differentiating this expression yields
`dN_J/dL=T rho_T/[3(rho+P)]=1/c_T`; the minus sign is essential.
The neutrino momentum-temperature parameter is `Ti exp(-N_J)` and dust
decays as `exp(-3N_J)`. Their continuity equations together with the plasma
law imply `d rho_total/dN_J=-3(rho_total+P_total)`. Massive decoupled
neutrinos do not transfer their entropy or rest energy to the photon plasma.

## 3. SI and dimensionless normalization

Write `rho_d0^SI` for an SI energy density and `rho_di` for the dimensionless
initial density used in the ODE. With `Ee=m_e c²`, the unit is
`rho_unit=Ee^4/(hbar c)^3`, dimension `J^4/(J m)^3=J/m³`.
`rho_crit0=3c²H0²/(8pi G_N0)` is also an energy density, since
`[c²H²/G]=kg/(m s²)=J/m³`. Therefore the unambiguous initial normalization is

    rho_di=(rho_d0^SI/rho_unit) exp(3Ntotal).

The v1/v2 line `rho_di/rho_unit=...` is correct only if its left-hand
`rho_di` temporarily denotes the SI quantity; this differs from sections 2
and 5. I flagged this notation ambiguity to the author without editing it.
The author supplied v3 with precisely the dimensionless equation above. I
read its narrow diff, confirmed that correction in this same reviewer
session, and preserved the original v1/v2 sources. No dynamical equation
changed.

In natural units the supplied weak-field calibration gives
`q(1+s)=(1+k)/(8pi G_N0)` and
`H_v²=8pi G_N0 rho_v0/3`. Substituting into
`Rstar=rho_unit/[2q(1+s)H_v²]` gives
`Rstar=3rho_unit/[2(1+k)rho_v0]`. With SI energy density the `c²` factors in
the two conversion relations cancel. Thus
`2(1+k)Rstar rho/3=rho_unit rho/rho_v0`, and the GR endpoint equals
`rho_crit0/rho_v0=H0²/H_v²` by construction. This is a calibration identity,
not an empirical prediction of H0, the vacuum scale or the actual theory's
endpoint. The `rho_v0>0` condition is required.

## 4. Full action, field equations and exchange

Start from the supplied fixed-sector action, varying with its original
constants held fixed. Put `alpha=sqrt(a)`, `A=exp(alpha u)`, `z=s A²`,
`F=1+z`, `J=1+(1-3a)z`, `D=1+2(1+b)(x²+y²)/3`. The conformal curvature
term contributes `(3/4)(d ln F/du)²` to the Einstein field metric. Directly,

    Kuu=(1-3az)/F + 3az²/F² = J/F²,
    Kxx=(1+s)4b/(9FD),  Kyy=(1+s)b/(3FD).

All eigenvalues are positive at every finite field in the stated parameter
domain. With `Hhat_v=H_v/sqrt(1+s)`, the dimensionless Einstein potential is

    U=(1+s)/F² [3/2+nu u²/2+f_s(u)x²
                    +b(1+s)y²/3+(3s/2)exp(4alpha u)],
    f_s=b(1+s)/2+alpha(sb-1)u+2a(1+s)u²/b.

These are full coordinate functions; differentiate before substituting an
orbit or a scaled variable. The Einstein action is proportional to
`Rhat/2-Kij ∂phi^i∂phi^j-2Vhat`. Its homogeneous equations, with
`sigma=rhohat/(2q Hhat_v²)`, `pi_f=Phat/(2q Hhat_v²)`, are

    3H² = 2sigma + H² Qkin + 2U,
    h = -(sigma+pi_f)/H²-Qkin,
    p'^i+(3+h)p^i+Gamma^i_jl p^j p^l
       = -K^ij[U_j+alpha_j(sigma-3pi_f)]/H².

Here `rhohat=B^4 rho_J`, `B=A/sqrt(F)`,
`alpha_j=∂j ln B=delta_ju alpha/F`, and therefore
`sigma=C_B² Rstar rho`, `C_B=(1+s)B²`, as in the source. The positive
Friedmann branch uses `H=+sqrt(2(sigma+U)/(3-Qkin))`.

Because `a_J=B ahat`, `N_J'=1+alpha_B p_u`. Transforming the Jordan
continuity equation directly gives
`sigma'=-3(sigma+pi_f)+alpha_B p_u(sigma-3pi_f)`. The sign of this exchange
is opposite the scalar trace work. Metric compatibility gives

    Qkin'=-2(3+h)Qkin-2p^j[U_j+alpha_j(sigma-3pi_f)]/H².

Thus differentiating the Friedmann constraint reproduces Raychaudhuri;
the trace-work terms cancel exactly. This holds off the ideal orbit, not
merely on `u=0`. Conversely omitting a connection term, reversing the scalar
trace sign, or imposing radiation dilution on a traced gas spoils the test.

## 5. Initial energy, scaling and physical readouts

At the supplied initial state let `M=Rstar rho_di`, `R=Rstar rho_gi`,
`x²=M`, `y²=R`, `p_x=-3x/2`, `p_y=-2y`, `u=p_u=0`. Then

    U=3/2+bM/2+bR/3,
    Qkin=b(M+4R/3)/D,
    sigma=M+R,
    2(sigma+U)=D(3-Qkin).

Therefore `H²=D` initially, regardless of the gas pressure. The initial
metric energy matches the ideal orbit but its accelerations generally do
not. If `t=Rstar(rho_gi-3P_gi)`, comparison with ideal radiation gives

    h-h_ideal=t/(3D),
    p'_u=-alpha(1+s)t/(JD),
    p'_x=9x/4+t x/(2D),
    p'_y=4y+2t y/(3D).

In particular the full dust tracking field contributes through both the
connection and potential; its removal is not justified by a small density
ratio. The v2 radiation-only specification correctly removes both the dust
density and the dust field. Setting the field to zero alone is another
initial-value problem.

For `s_x=x_i exp(-3N_J/2)` and `s_y=y_i exp(-2N_J)`, differentiating each
quotient gives exactly `X'=vx+3N_J'X/2`, `Y'=vy+2N_J'Y`, and the corresponding
velocity equations with `acc_x/s_x`, `acc_y/s_y`. All six components divide
by `c_T N_J'` on changing to L. The scale functions are positive for nonzero
positive supplied amplitudes at finite N_J, even when the fields cross zero.
The stated fixed `s_x=1` convention covers the dust-free case. No new force
appears; derivatives of the time-dependent chart must not be inserted as
changes to the original potential.

From `dt_J=B dt_hat` and `a_J=B ahat`, independently,

    H_J/H_v=H N_J'/sqrt(C_B),
    Nhat=N_J-ln(B/B_i),
    H_v dt_J/dL=sqrt(C_B)/(H c_T N_J').

The age integrand is positive only on the chosen expanding positive-clock
branch. `H²>0`, `3-Qkin>0` and `N_J'>0` must not be silently repaired if
lost. Under the separately supplied locally frozen, light-scalar bridge,
`K^ij alpha_i alpha_j=a/J`, so
`G_N/G_N0=C_B(1+a/J)/(1+k)`. This algebra does not establish that a local
experiment satisfies that approximation at every cosmological epoch.

The derived identities do not show that the massive thermal history reaches
the late orbit, that it is stable, or that a numerical interpolator or ODE
solver evaluates these equations correctly. Those remain distinct checks.
This check concerns the local bulk equations after q and Lambda are fixed.
It does not compute finite-history four-form flux integrals or certify that
any separately imposed boundary flux values admit the resulting history.
