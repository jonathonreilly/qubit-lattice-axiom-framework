# Focused independent mathematical review

**Result: the handwritten bridge equations in v3 pass this scoped check,
conditional on the explicitly supplied action, matter population, initial
state and local-gravity bridge.** One SI/dimensionless label ambiguity in v2
was found, reported and corrected by the author in v3; I confirmed the exact
correction in this same reviewer session. This is not a formal audit verdict.

The reviewed v3 SHA256 is
`91c7d14902c8297662cfafe6e3f0961db02d9866cd6f7317b016a0f45b8ce8b1`.
I read complete handwritten v1/v2 and the action and thermal dependency notes;
v3 coverage is the unchanged v2 body plus the inspected narrow dimensional
correction. All sources and recovery copies are listed in the freeze and
final receipt. The original checker's nine files remain unchanged. That
directory contained a plan, primary-source recovery and draft script, but no
execution results or final receipt; I did not run or reuse its script.

## Finding and correction

Sections 2 and 5 use dimensionless `rho_di`, but the v2 normalization line
divided it by the SI density unit. The corrected equation is
`rho_di=(rho_d0^SI/rho_unit) exp(3Ntotal)`, explicitly defining the SI quantity.
This removes the inconsistency while preserving the intended normalization.
The author's statement that its implementation already used this expression
was not checked in this mathematical review.

V2's earlier clarifications are appropriate: its occupation is an initially
relativistic approximation, radiation-only removes both conserved dust and
its field, and the expanding square root is explicit. The neutrino coefficient
`7pi²/120` counts the two stipulated populated states per mass eigenstate.

## Derivation and actual controls

`INDEPENDENT_DERIVATION_v1.md` derives the collisionless phase-space integrals,
their temperature derivative and positive trace; the plasma entropy clock;
SI density and Hubble normalization; the Einstein metric and potential from
the supplied action; all three scalar equations and off-orbit energy exchange;
the initial energy identity and finite-trace acceleration changes; all scaled
coordinate derivatives; and the physical Hubble, local-G and elapsed-age maps.

The independent Python checker imports mpmath and standard-library modules
only. It imports no parent implementation. Direct high-precision quadrature,
temperature differentiation, momentum-form Euler-Lagrange equations and a
differentiated Friedmann constraint supply routes distinct from simply
repeating the displayed final formulas. Tests were frozen before the first
execution; there was one execution, with no failed numerical checks or reruns.

- **154 nominal checks passed, zero failed.** Working precision: 60 decimal
  digits; frozen scaled tolerance: `1e-42`; maximum scaled residual:
  `1.16494e-58`.
- **Nine controlled defects were detected, zero missed.** These replace the
  relic occupation by current equilibrium, reverse the entropy sign, reverse
  scalar trace work, omit the connection, select the negative H root in two
  age fixtures, reverse two chart-scaling signs, and misidentify dm32² as
  dm31². The smallest detected residual was `5.31787e-7`, against the frozen
  `1e-12` threshold. These are algebraic probes of the independent checker,
  not mutations or certification of the parent code.
- Thirteen original source/recovery pairs matched their frozen hashes at
  execution. An in-memory one-byte input change was rejected by the digest
  comparison. The v3 source and recovery are bound by the supplementary and
  final receipts.
- Runtime: 16.28 seconds using Python 3.12.8 and mpmath 1.3.0. Exit code 0;
  stderr empty. Exact command, source hashes and log hashes are in
  `EXECUTION_v1.json`; full values and residuals are in `RESULTS_v1.json`.

The calibrated benchmark independently gives `Ntotal=24.1401832677`,
`Tnu_f/Tf=0.7139301690`, `rho_v0=5.77936556e-10 J/m³>0`, and
`Rstar=3.686447319e33` for k=.001. Its neutrino masses are
`(0,0.008608135687,0.05007094966) eV`, using the specified normal ordering,
zero lightest mass, and PDG Ref.181 with SK-ATM dm21² and dm32². The finite
Ti=10 entropy factor explains the difference from the infinite-temperature
instantaneous-decoupling limit. These are results of supplied calibration
inputs, not independent cosmological predictions or new empirical constraints.

The PDG PDF hash is
`8f010a5e4ae805227a15d977badb8e2d4ddc03fd4865b0c4085665b4f35bd1d8`.
I read preserved pages 1, 36 and 40 and visually inspected the page-36 table.
The raw preserved NIST table was checked at the relevant mass, energy,
G, h, c, k_B and eV rows. The script computes Ee=m_e c² from the rounded
mass row, rather than independently mixing rounded Ee and mass values.

## Limits

This supports using the v3 handwritten local equations for the planned
history test. It does not check the parent's interpolation, derivatives,
step control, numerical evolution, history convergence or late-time claims.
No conclusion about a BBN/CMB fit, perturbations, parameter selection, quantum
completion, trajectory selection or a completed TOE follows. The local-G
formula remains conditional on its stated locally frozen weak-body,
light-scalar approximation. The chosen q,Lambda sector is held fixed in the
local equations; any specified integrated four-form boundary constraints
require a separate calculation on an actual history.

The reviewer created files only within `independent_math_review_fresh`, made
no author-source changes, applied no audit status, and performed no commit,
push or landing. The independent checker uses a separate context of the same
model family as the author; code/derivation separation supplies the described
independence, not a claim of different-model independence.
