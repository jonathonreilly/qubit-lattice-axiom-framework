#!/usr/bin/env python3
"""Independent high-precision controls; no parent implementation imports."""
import datetime
import hashlib
import json
import platform
import sys
from pathlib import Path
import mpmath as mp

HERE = Path(__file__).resolve().parent
mp.mp.dps = 60
TOL = mp.mpf('1e-42')
checks, mutations, values = [], [], {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fmt(x):
    return mp.nstr(x, 52)


def check(name, actual, expected, tol=TOL):
    residual = abs(actual-expected)/max(mp.mpf(1), abs(actual), abs(expected))
    checks.append(dict(name=name, actual=fmt(actual), expected=fmt(expected),
                       scaled_residual=fmt(residual), tolerance=fmt(tol), passed=bool(residual < tol)))
    return residual


def reject(name, residual, threshold=mp.mpf('1e-12')):
    mutations.append(dict(name=name, residual=fmt(abs(residual)),
                          minimum_detectable=fmt(threshold), detected=bool(abs(residual) > threshold)))


def integral(f):
    return mp.quad(f, [0, 1, 4, 16, mp.inf])


def fermion(T, mass, equilibrium=False):
    r = mass/T
    energy = lambda q: mp.sqrt(q*q+r*r)
    f = lambda q: 1/(mp.exp(energy(q) if equilibrium else q)+1)
    rho = T**4/mp.pi**2*integral(lambda q: q*q*energy(q)*f(q))
    pressure = T**4/(3*mp.pi**2)*integral(lambda q: q**4/energy(q)*f(q))
    trace = T**4*r*r/mp.pi**2*integral(lambda q: q*q/energy(q)*f(q)) if r else mp.mpf(0)
    return rho, pressure, trace


def fermion_rho(T, mass, equilibrium=False):
    r = mass/T
    return T**4/mp.pi**2*integral(lambda q: q*q*mp.sqrt(q*q+r*r)/
                                (mp.exp(mp.sqrt(q*q+r*r) if equilibrium else q)+1))


def plasma(T):
    # g_e=4; fermion() has g=2. Electron rest mass is one.
    rho, pressure, trace = fermion(T, mp.mpf(1), equilibrium=True)
    photon = mp.pi**2*T**4/15
    rho = 2*rho+photon
    pressure = 2*pressure+photon/3
    r = 1/T
    def d_integrand(q):
        E = mp.sqrt(q*q+r*r)
        f = 1/(mp.exp(E)+1)
        return q*q*E*E*f*(1-f)
    rho_T = 2*T**3/mp.pi**2*integral(d_integrand)+4*photon/T
    entropy = (rho+pressure)/T
    cT = 3*(rho+pressure)/(T*rho_T)
    return rho, pressure, entropy, rho_T, cT, 2*trace


def evaluate_action(phi, parameters):
    u, x, y = phi
    a, b, s, nu = parameters
    alpha = mp.sqrt(a)
    z = s*mp.exp(2*alpha*u)
    F = 1+z
    J = 1+(1-3*a)*z
    D = 1+2*(1+b)*(x*x+y*y)/3
    K = [J/F**2, 4*(1+s)*b/(9*F*D), (1+s)*b/(3*F*D)]
    fs = b*(1+s)/2+alpha*(s*b-1)*u+2*a*(1+s)*u*u/b
    U = (1+s)/F**2*(mp.mpf('1.5')+nu*u*u/2+fs*x*x+b*(1+s)*y*y/3+
                    3*s*mp.exp(4*alpha*u)/2)
    return K, U, dict(z=z, F=F, J=J, D=D, alpha=alpha,
                      alphaB=alpha/F, B=mp.exp(alpha*u)/mp.sqrt(F),
                      CB=(1+s)*mp.exp(2*alpha*u)/F)


def shift(phi, j, q):
    output = list(phi)
    output[j] = q
    return output


def derivatives(phi, parameters):
    dK = [[mp.diff(lambda t: evaluate_action(shift(phi, j, t), parameters)[0][i], phi[j])
           for j in range(3)] for i in range(3)]
    dU = [mp.diff(lambda t: evaluate_action(shift(phi, j, t), parameters)[1], phi[j])
          for j in range(3)]
    return dK, dU


def equations(phi, p, sigma, pressure, parameters, trace_sign=1, use_connection=True):
    K, U, geo = evaluate_action(phi, parameters)
    dK, dU = derivatives(phi, parameters)
    Q = sum(K[i]*p[i]**2 for i in range(3))
    H2 = 2*(sigma+U)/(3-Q)
    h = -(sigma+pressure)/H2-Q
    connection = []
    for i in range(3):
        term = mp.mpf(0)
        for j in range(3):
            for k in range(3):
                gamma = ((dK[i][j] if i == k else 0)+(dK[i][k] if i == j else 0)
                         -(dK[j][i] if j == k else 0))/(2*K[i])
                term += gamma*p[j]*p[k]
        connection.append(term)
    tau = sigma-3*pressure
    force = [dU[i]+(trace_sign*geo['alphaB']*tau if i == 0 else 0) for i in range(3)]
    acc = [-(3+h)*p[i]-(connection[i] if use_connection else 0)-force[i]/(K[i]*H2)
           for i in range(3)]
    sigma_prime = -3*(sigma+pressure)+geo['alphaB']*p[0]*tau
    NJprime = 1+geo['alphaB']*p[0]
    return dict(K=K,U=U,Q=Q,H2=H2,h=h,dK=dK,dU=dU,force=force,acc=acc,
                connection=connection,sigma_prime=sigma_prime,NJprime=NJprime,**geo)


def constraint_derivative(phi, p, sigma, solution, parameters):
    def along(t):
        field = [phi[i]+t*p[i] for i in range(3)]
        velocity = [p[i]+t*solution['acc'][i] for i in range(3)]
        K, U, _ = evaluate_action(field, parameters)
        return 2*(sigma+t*solution['sigma_prime']+U)/(3-sum(K[i]*velocity[i]**2 for i in range(3)))
    return mp.diff(along, 0)


def main():
    freeze = json.loads((HERE/'FREEZE_v1.json').read_text())
    integrity = []
    for row in freeze['sources']:
        actual = sha(Path(row['source']).read_bytes())
        copied = sha((HERE/row['recovery']).read_bytes())
        ok = actual == copied == row['sha256']
        integrity.append(dict(path=row['source'],passed=ok))
        if not ok:
            raise RuntimeError('Source identity mismatch: '+row['source'])
    original = (HERE/freeze['sources'][0]['recovery']).read_bytes()
    tamper_detected = sha(original+b'\n') != freeze['sources'][0]['sha256']
    if not tamper_detected:
        raise RuntimeError('Digest tamper gate did not reject changed input')
    values['integrity'] = dict(sources=integrity,in_memory_tamper_rejected=tamper_detected)

    fd = []
    for rr in freeze['controls_frozen_before_execution']['FD_r']:
        r = mp.mpf(rr)
        rho, pressure, trace = fermion(mp.mpf(1), r)
        derivative = mp.diff(lambda T: fermion_rho(T, r), mp.mpf(1))
        check(f'FD trace r={r}', rho-3*pressure, trace)
        check(f'FD derivative r={r}', derivative, 3*(rho+pressure))
        fd.append(dict(r=fmt(r),rho=fmt(rho),pressure=fmt(pressure),trace=fmt(trace)))
        if r == 0:
            check('FD massless normalization',rho,7*mp.pi**2/120)
    check('FD number integral',integral(lambda q:q*q/(mp.exp(q)+1)),3*mp.zeta(3)/2)
    eqrho, eqP, _ = fermion(mp.mpf(1),mp.mpf(10),True)
    reject('FD replaced by current equilibrium',mp.diff(lambda T:fermion_rho(T,mp.mpf(10),True),1)-3*(eqrho+eqP))
    values['FD'] = fd

    plasma_values = []
    s_i = plasma(mp.mpf(10))[2]
    Sbar_i = s_i/mp.mpf(10)**3
    for rawT in freeze['controls_frozen_before_execution']['plasma_T']:
        T = mp.mpf(rawT)
        rho,P,entropy,rhoT,cT,trace = plasma(T)
        check(f'plasma trace T={T}',rho-3*P,trace)
        check(f'plasma rho derivative T={T}',mp.diff(lambda t:plasma(t)[0],T),rhoT)
        check(f'plasma entropy derivative T={T}',T*mp.diff(lambda t:plasma(t)[2],T),rhoT)
        def N_from_L(L, wrong=False):
            temp = 10*mp.exp(-L)
            Sb = plasma(temp)[2]/temp**3
            return L+(1 if wrong else -1)*mp.log(Sb/Sbar_i)/3
        L = mp.log(10/T)
        check(f'entropy clock T={T}',mp.diff(N_from_L,L),1/cT)
        plasma_values.append(dict(T=fmt(T),cT=fmt(cT),Sbar=fmt(entropy/T**3)))
        if T == 1:
            reject('entropy-clock logarithm sign reversal',mp.diff(lambda l:N_from_L(l,True),L)-1/cT)
    values['plasma'] = plasma_values

    generic = []
    for idx, raw in enumerate(freeze['controls_frozen_before_execution']['generic_action_fixtures']):
        a,b,s,nu,u,x,y,pu,px,py,sigma,pressure = map(mp.mpf,raw)
        pars,phi,p = [a,b,s,nu],[u,x,y],[pu,px,py]
        sol = equations(phi,p,sigma,pressure,pars)
        K,H2,dK,dU,acc = [sol[key] for key in ['K','H2','dK','dU','acc']]
        for i in range(3):
            # Independent momentum-form Euler-Lagrange residual.
            momentum = K[i]*(acc[i]+(3+sol['h'])*p[i])
            momentum += sum(dK[i][j]*p[j]*p[i] for j in range(3))
            momentum -= sum(dK[j][i]*p[j]**2 for j in range(3))/2
            momentum += (dU[i]+(sol['alphaB']*(sigma-3*pressure) if i == 0 else 0))/H2
            check(f'EL component {i} fixture {idx}',momentum,0)
        check(f'Friedmann derivative fixture {idx}',constraint_derivative(phi,p,sigma,sol,pars),2*sol['h']*H2)
        raw_kuu=(1-3*a*sol['z'])/sol['F']+3*a*sol['z']**2/sol['F']**2
        check(f'Weyl Kuu fixture {idx}',K[0],raw_kuu)
        check(f'B gradient fixture {idx}',mp.diff(lambda uu:mp.log(evaluate_action([uu,x,y],pars)[2]['B']),u),sol['alphaB'])
        check(f'local scalar norm fixture {idx}',sol['alphaB']**2/K[0],a/sol['J'])
        if idx == 0:
            for label,kwargs in [('scalar trace sign reversed',dict(trace_sign=-1)),('connection omitted',dict(use_connection=False))]:
                bad=equations(phi,p,sigma,pressure,pars,**kwargs)
                reject(label,(constraint_derivative(phi,p,sigma,bad,pars)-2*bad['h']*bad['H2'])/(2*bad['H2']))
        # Direct differentiation of scale factor in Einstein proper time.
        H=mp.sqrt(H2);NJp=sol['NJprime'];CB=sol['CB'];B=sol['B']
        HJ=mp.diff(lambda t:mp.log(evaluate_action([u+pu*H*t,x,y],pars)[2]['B'])+H*t,0)/B
        check(f'physical Hubble fixture {idx}',HJ/mp.sqrt(1+s),H*NJp/mp.sqrt(CB))
        cT=mp.mpf('.8')
        proper_time=mp.sqrt(1+s)*B/(H*cT*NJp)
        check(f'physical age fixture {idx}',proper_time,mp.sqrt(CB)/(H*cT*NJp))
        reject(f'negative H violates positive age fixture {idx}',abs(proper_time)+proper_time)
        Nhat_prime=NJp-mp.diff(lambda t:mp.log(evaluate_action([u+pu*t,x,y],pars)[2]['B']),0)
        check(f'Nhat map fixture {idx}',Nhat_prime,1)
        # Time-dependent chart differentiated as quotients before the L conversion.
        for i,weight,scale0 in [(1,mp.mpf('1.5'),mp.mpf('2.3')),(2,mp.mpf(2),mp.mpf('.4'))]:
            scale=lambda t:scale0*mp.exp(-weight*NJp*t)
            field=lambda t:phi[i]+p[i]*t+acc[i]*t*t/2
            velocity=lambda t:p[i]+acc[i]*t
            chart_field=mp.diff(lambda t:field(t)/scale(t),0)
            chart_velocity=mp.diff(lambda t:velocity(t)/scale(t),0)
            check(f'scaled field {i} fixture {idx}',chart_field,p[i]/scale0+weight*NJp*phi[i]/scale0)
            check(f'scaled velocity {i} fixture {idx}',chart_velocity,acc[i]/scale0+weight*NJp*p[i]/scale0)
            # Recover original physical derivative after division by dL/dNhat.
            check(f'L chain rule {i} fixture {idx}',scale0*(chart_field-weight*NJp*phi[i]/scale0)/(cT*NJp),p[i]/(cT*NJp))
            if idx == 0:
                reject(f'scaled field sign reversal component {i}',chart_field-(p[i]/scale0-weight*NJp*phi[i]/scale0))
        generic.append(dict(fixture=idx,Qkin=fmt(sol['Q']),H2=fmt(H2),NJprime=fmt(NJp)))
    values['generic_action'] = generic

    initial_values=[]
    for k in [mp.mpf('.001'),mp.mpf('.01')]:
        a=(1-k)*(1+3*k)/4
        s=(1+k)/(k*(1-3*k))
        for b in [k,a]:
            pars=[a,b,s,mp.mpf(1)]
            for rawM,rawR in freeze['controls_frozen_before_execution']['initial_M_R']:
                M,R=mp.mpf(rawM),mp.mpf(rawR)
                x,y=mp.sqrt(M),mp.sqrt(R)
                phi,p=[mp.mpf(0),x,y],[mp.mpf(0),-3*x/2,-2*y]
                sol=equations(phi,p,M+R,R/3,pars)
                label=f'k={k} b={b} M={M} R={R}'
                check('initial H2 '+label,sol['H2'],sol['D'])
                for i,expected in enumerate([0,9*x/4,4*y]):
                    check('ideal acceleration '+str(i)+' '+label,sol['acc'][i],expected)
                if R:
                    tau=R/5
                    traced=equations(phi,p,M+R,(R-tau)/3,pars)
                    expected=[-mp.sqrt(a)*(1+s)*tau/(traced['J']*traced['D']),
                              9*x/4+tau*x/(2*traced['D']),4*y+2*tau*y/(3*traced['D'])]
                    for i in range(3):
                        check('trace acceleration '+str(i)+' '+label,traced['acc'][i],expected[i])
                initial_values.append(dict(k=fmt(k),b=fmt(b),M=fmt(M),R=fmt(R),H2=fmt(sol['H2'])))
    values['initial_orbits'] = initial_values

    # SI inputs explicitly frozen; rounded measured mass converted to Ee=m_e c².
    me=mp.mpf('9.1093837139e-31');c=mp.mpf(299792458);h=mp.mpf('6.62607015e-34')
    kB=mp.mpf('1.380649e-23');eV=mp.mpf('1.602176634e-19');G=mp.mpf('6.67430e-11')
    Ee=me*c*c;hbar=h/(2*mp.pi);rho_unit=Ee**4/(hbar*c)**3
    # Fixed conventional parsec conversion; astronomical unit 149597870700 m.
    Mpc=mp.mpf(149597870700)*648000/mp.pi*10**6
    H0=mp.mpf(70000)/Mpc;T0=mp.mpf('2.72548');Ti=mp.mpf(10);Tf=kB*T0/Ee
    pl_i=plasma(Ti);pl_f=plasma(Tf)
    Ntotal=mp.log(Ti/Tf)-mp.log((pl_f[2]/Tf**3)/(pl_i[2]/Ti**3))/3
    Tnuf=Ti*mp.exp(-Ntotal)
    dm21=mp.mpf('7.41e-5');dm32=mp.mpf('2.433e-3')
    masses=[mp.mpf(0),mp.sqrt(dm21),mp.sqrt(dm21+dm32)]
    check('mass m2 gap',masses[1]**2-masses[0]**2,dm21)
    check('mass m3 gap',masses[2]**2-masses[1]**2,dm32)
    reject('dm32 misidentified as dm31',abs((mp.sqrt(dm32)**2-masses[1]**2)-dm32))
    nu_f=[fermion(Tnuf,m*eV/Ee) for m in masses]
    nu_i=[fermion(Ti,m*eV/Ee) for m in masses]
    rho_gf=pl_f[0]+sum(n[0] for n in nu_f)
    rho_gi=pl_i[0]+sum(n[0] for n in nu_i)
    rho_crit=3*c*c*H0*H0/(8*mp.pi*G);rho_d0=mp.mpf('.3')*rho_crit
    rho_v0=rho_crit-rho_d0-rho_unit*rho_gf
    Hv2=8*mp.pi*G*rho_v0/(3*c*c)
    k=mp.mpf('.001');Rstar=3*rho_unit/(2*(1+k)*rho_v0)
    rho_di=rho_d0/rho_unit*mp.exp(3*Ntotal)
    rho_df=rho_di*mp.exp(-3*Ntotal)
    check('SI dust transport closure',rho_unit*rho_df/rho_d0,1)
    check('GR endpoint normalization',1+2*(1+k)*Rstar*(rho_df+rho_gf)/3,H0*H0/Hv2)
    check('rho_unit energy over Compton volume',rho_unit,Ee/(hbar*c/Ee)**3)
    a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));M=Rstar*rho_di;R=Rstar*rho_gi
    initial=equations([0,mp.sqrt(M),mp.sqrt(R)],[0,-3*mp.sqrt(M)/2,-2*mp.sqrt(R)],M+R,
                      Rstar*(pl_i[1]+sum(n[1] for n in nu_i)),[a,k,s,1])
    check('physical scale initial H2',initial['H2'],initial['D'])
    values['SI_benchmark']={key:fmt(value) for key,value in dict(Ee_J=Ee,rho_unit_J_m3=rho_unit,
        H0_s_inv=H0,Tf=Tf,Tnu_f=Tnuf,Tnu_over_T=Tnuf/Tf,Ntotal=Ntotal,
        rho_crit_J_m3=rho_crit,rho_v0_J_m3=rho_v0,Rstar_k001=Rstar,
        rho_di=rho_di,initial_M=M,initial_R=R,Hv_s_inv=mp.sqrt(Hv2),
        Omega_nu=sum(n[0] for n in nu_f)*rho_unit/rho_crit,
        largest_initial_neutrino_r=masses[2]*eV/Ee/Ti).items()}
    values['SI_benchmark']['mass_eV']=list(map(fmt,masses))
    values['SI_benchmark']['positive_reference_vacuum']=bool(rho_v0>0)

    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        interpreter=sys.executable,python=platform.python_version(),mpmath=mp.__version__,
        script_sha256=sha(Path(__file__).read_bytes()),freeze_sha256=sha((HERE/'FREEZE_v1.json').read_bytes()),
        scope='Handwritten equations only; no parent implementation imported, called or certified',
        checks=checks,mutations=mutations,values=values,
        totals=dict(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),
                    mutations_detected=sum(x['detected'] for x in mutations),mutations_missed=sum(not x['detected'] for x in mutations)))
    (HERE/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['totals'],sort_keys=True))
    for item in checks:
        if not item['passed']:
            print('FAIL',json.dumps(item))
    for item in mutations:
        if not item['detected']:
            print('MISSED',json.dumps(item))
    print('Maximum scaled nominal residual:',max(mp.mpf(row['scaled_residual']) for row in checks))
    return 1 if result['totals']['failed'] or result['totals']['mutations_missed'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
