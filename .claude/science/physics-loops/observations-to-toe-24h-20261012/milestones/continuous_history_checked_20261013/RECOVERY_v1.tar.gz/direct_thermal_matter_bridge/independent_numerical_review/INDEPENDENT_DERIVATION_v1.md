# Independent derivation for the frozen thermal–matter bridge v1

This calculation checks the supplied classical action and calibration. It neither derives their physical origin nor identifies an observed cosmic history. All implementation below is reviewer-owned; no producer helper is imported as a positive oracle.

## Thermodynamics in a separate clock

Set L=ln(T_i/T) and use the physical Jordan e-fold N_J as the independent variable. Equilibrium plasma entropy conservation gives T^3 sbar(T) exp(3N_J)=constant, hence N_J=L−ln[sbar(T)/sbar(T_i)]/3. Since T ds/dT=d rho_pl/dT, c_T=dL/dN_J=3sbar/heatbar. The independent ODE evolves L rather than substituting the producer's entropy-clock function into its vector field.

A decoupled relic has f(q)=1/(exp(q)+1), q=p/T_nu, T_nu=T_i exp(−N_J), and r=m/T_nu. For each g=2 species,

rho_nu=T_nu^4/pi^2 integral q^2 sqrt(q^2+r^2) f dq,
P_nu=T_nu^4/(3pi^2) integral q^4/sqrt(q^2+r^2) f dq,
tau_nu=T_nu^4 r^2/pi^2 integral q^2/sqrt(q^2+r^2) f dq.

Differentiation gives −d rho_nu/dN_J=T_nu^4/pi^2 integral q^2[4E−r^2/E]f dq=3(rho_nu+P_nu). The positive trace is numerically evaluated by the r^2 integral, not by subtracting rho−3P. Dust contributes rho_di exp(−3N_J) to both density and trace. Plasma, relic and dust traces must all source u. Relic energy density and pressure are not equilibrium Fermi integrals in E after decoupling.

The independent quadrature is 40-point Gauss–Legendre on each of [0,1], [1,4], [4,12], [12,30], [30,60]. It differs from the frozen Laguerre route. Finite controls and exponential-tail suppression support its use here; this is not a uniform rigorous quadrature-error bound. The eight frozen relic-ratio controls and all serialized species rows are consumed. Trace comparisons normalized by total density must not be interpreted as relative-accuracy tests on an arbitrarily small trace.

## Raw action, signs, and momentum evolution

Let alpha=sqrt(a), A=exp(alpha u), F=1+s A^2, J=1+(1−3a)s A^2, D=1+2(1+b)(x^2+y^2)/3 and B=A/sqrt(F). Weyl transformation of the supplied action gives

K_uu=(1−3as A^2)/F +3(F_u/F)^2/4 = J/F^2,
K_xx=4b(1+s)/(9FD), K_yy=b(1+s)/(3FD).

The first expression for K_uu was differentiated and algebraically factored independently. The potential is U=(1+s)[V0+s V1+3s A^4/2]/F^2 with the exact V0,V1 of the frozen hand derivation. Define alpha_B=B_u/B=alpha/F and C_B=(1+s)B^2. In the dimensionless Einstein system the fluid contributions are sigma=C_B^2 Rstar rho, p_f=C_B^2 Rstar P and tau_f=C_B^2 Rstar tau.

For p^i=d phi^i/dNhat, Q=K_ij p^i p^j and Hhat measured in the supplied H_v normalization,

Hhat^2=2(sigma+U)/(3−Q),
h=dlnHhat/dNhat=−(sigma+p_f)/Hhat^2−Q,
p'^i=−(3+h)p^i−Gamma^i_jk p^j p^k−K^ij(U_j+alpha_B tau_f delta_ju)/Hhat^2.

The positive sign of the matter term inside the final parentheses therefore gives a negative matter force. The matter exchange is sigma'=−3(sigma+p_f)+alpha_B p^u tau_f. These signs are mutually fixed by differentiating the Friedmann constraint.

The independent integrator instead evolves lowered momenta pi_i=K_ij p^j. The metric connection reorganizes exactly into

pi'_i=−(3+h)pi_i +(partial_i K_jj)(p^j)^2/2 −(U_i+alpha_B tau_f delta_iu)/Hhat^2.

This construction differentiates the raw action and does not reuse the producer's Christoffel or coordinate-acceleration functions. N_J'=1+alpha_B p^u, so every Einstein-time rate is divided by this factor in the independent clock. Physical states require K>0, Hhat^2>0, 3−Q>0 and N_J'>0; they are checked during the independent integrations and on all stored rows.

To control scale, x=s_x X and y=s_y Y with s_x=xi exp(−3N_J/2), s_y=yi exp(−2N_J). The independent momenta are divided by fixed reference factors K_uu(0), 4b s_x/(9D0), b s_y/(3D0), where D0=1+2(1+b)(s_x^2+s_y^2)/3. The derivative of these factors is explicitly included. The two independently evolved cases have nonzero dust. The implementation's reference-scale derivative is not asserted as a dust-free evolution implementation; the dust-free producer rows were checked only by instantaneous action/readout evaluation.

## Energy and physical readouts

Differentiate Q using momenta: Q'=2p.pi'−sum_i (p^i)^2 K'_ii. Then

h_constraint = [(sigma'+U_i p^i)/(sigma+U) +Q'/(3−Q)]/2.

Substitution of the momentum and fluid equations gives exactly the Raychaudhuri h above. This is the analytic directional conservation control. The original finite-difference diagnostic evaluates the nonlinear state at z±epsilon dz/dL; for the stiff generic u acceleration, epsilon=2e−6 is not necessarily a local tangent displacement. The four original failures remain failures. Analytic conservation does not erase them or certify every scalar component separately.

From a_J=B a_hat and dt_J proportional to B dt_hat, the normalized physical readouts are

H_J^2=Hhat^2(1+alpha_B p^u)^2/C_B,
G_N/G_N,ref=C_B[1+alpha_B^2/K_uu]/(1+k),
H_GR^2=1+2(1+k)Rstar rho/3,
H_v dt_J/dN_J=sqrt(C_B/Hhat^2)/(1+alpha_B p^u).

The independent H_J expression was evaluated directly from B and B_u through the proper-time/scale-factor chain rule. All stored H ratios, G ratios, lapse factors and age integrands are checked against these quantities. The local measured-G relation is the supplied frozen-background weak-field bridge; this review does not extend it to a finite-frequency or nonlinear measurement.

## Calibration and interpretations

E_e=m_e c^2, rho_unit=E_e^4/(hbar c)^3, rho_crit=3c^2 H0^2/(8piG_N), rho_d0=Omega_d0 rho_crit. At the exposed T0, baseline massive-neutrino and plasma densities define rho_v=rho_crit−rho_d0−rho_unit rho_gas(T0), H_v^2=8piG_N rho_v/(3c^2), and Rstar=3rho_unit/[2(1+k)rho_v]. The dust initial density follows entropy expansion, rather than a bare T^3 ratio. Matter variants retain these baseline action constants. H0=70 and Omega_d0=.3 are supplied reference values, not independent fitted observations.

The relic masses use m1=0, m2^2=dm21^2 and m3^2=dm21^2+dm32^2 under the declared normal ordering. Oscillations do not measure the assumed absolute zero mass or the assumed initial relic distribution. Reported elapsed ages integrate from T_i=10m_e to the chosen T0 and are internal predictions conditional on that initial state and calibration.

## Attempted numerical recovery without changing the action

The first independent route uses Radau with rtol=3e−10, atol=2e−12, max physical-clock step .04 and a 180-second case cap. A separately checked complex-step Jacobian differentiates the same lowered-momentum vector field, including analytic plasma derivatives with respect to L. Its 216 coefficient/parity controls compare against 65-digit differentiation of the raw action. BDF was then tried with unchanged tolerances and cap.

A final, separately frozen route regrouped only U_u. With E=exp(2alpha u), F=1+sE and V0+sV1=3/2+P_extra,

U_u=(1+s)[P_u F−4alpha sE P_extra+6alpha sE expm1(2alpha u)]/F^3.

This identity removes the vacuum subtraction of nearby exponentials. Twenty-five relative derivative checks, including tiny nonzero vacuum u, and the 216 Jacobian/parity checks pass. It does not remove every cancellation from the complete momentum force. All four weak-case routes still time out; no new complete weak trajectory is claimed. These failures and the original warning remain in their executed records. None is a proof of physical nonexistence.
