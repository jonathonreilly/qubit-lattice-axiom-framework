# Independent numerical review of the original thermal–matter bridge v1

The frozen equations and serialized physical readouts are supported by the checks below, but the original local controls have a real neutrino-trace blind spot and four of the twelve original histories are incomplete. This review does not certify the complete twelve-case calculation. One independently evolved strong diagnostic agrees closely; the requested independent weak-case trajectory remains incomplete after four preserved bounded attempts.

## Exact scope and lineage

The subject is `evidence_v1/FREEZE.json`, not the current campaign directory or Git state. Its twelve executed input identities include the original bridge runner, hand derivation v3, protocol, fixtures, inputs, ledger, exact upstream thermal/action code and nodes, and three primary calibration files. `INPUT_FREEZE_v1.json` was made before independent calculations; `COMPLETED_EVIDENCE_FREEZE_v1.json` preserves the completed original execution and every original case. Together they cover 55 unique original paths, all copied exactly and rehashed at closeout. Complete original-path, hash, snapshot and disposition records are in `SOURCE_DISPOSITION_v1.json`.

Core identities:

- Hand derivation v3: `91c7d14902c8297662cfafe6e3f0961db02d9866cd6f7317b016a0f45b8ce8b1`.
- Original runner: `483db2fa7cd17cd707f00a46c8fb4f2deba8c93a691c77026851fd31321a6c2d`.
- Fixtures: `be342bccdcb1e2dac97cd7b12c1547b9f11bf25a24d30bc5f9ccb288f8897679`.
- Original complete RESULTS: `b4aa2b0e5a627c071c6677f56d3119ef38a2e6b47674d8a0c0de93d285697b0b`.
- First independent freeze: `4c3871d22b5c1e29a0584e9f8c3f8e1b3059db4e07547cc0893fc25d2281260c`.
- Completed evidence freeze: `6a0ae1dfb672ab90ad3ea3525eb5eee9e95ff28298f05c20169715d483a9e429`.

The full assigned original runner, hand derivation, fixtures, protocol, input roles and ledger were read. All 4,105 original assertion objects, twelve case records, three calibrations, eight relic-ratio controls, twenty generic off-trajectory rows and all 1,928 successful history samples were consumed. The full fresh mathematical report/derivation and its 154 checks/nine mutation dispositions were inspected as prior context, not substituted for independent implementation checks. Exactly unchanged upstream source checks are reused by hash. No author helper is imported as a positive numerical oracle.

Later author v2/v3/v4/v5 recovery sources and the trace supplement are outside this original frozen result. Their reported failures are not silently folded into a repaired original result. A separately requested supplement check will have its own affected-source receipt.

## Material finding: massive-neutrino trace omission survives the local stage

In a complete copy of all twelve actual inputs, the single source change `tau=dust+g['tau_gas']` to `tau=dust+g['tau_e']` removes the massive-neutrino source from the scalar equation. Every freshly computed source identity passes. The actual local-control execution gives 279 pass / 4 fail, with exactly the same four coarse energy failures as the unmodified original local stage and no additional failure.

This is a genuine scientific control gap, not a hash failure. The generic raw readout oracle accepts the implementation's already-computed total trace, while the energy/acceleration checks can mask a small trace contribution behind much larger terms. The exact omitted acceleration contribution has magnitude up to 0.00890966382 in the frozen generic fixtures, even though one split-branch total acceleration is about 8.96e7. At the last generic sites the neutrino contribution is about 0.00422000214 of the total matter trace. A tolerance relative to the full acceleration cannot uniformly certify this component.

The independent raw-action expected accelerations do detect the actual mutant at both equal-branch L=23 sites: normalized differences 1.12526e−6 and 1.07118e−6 exceed the predeclared 3e−8 threshold. The expected values are reused from the independently calculated original controls, not from a mutated producer helper. This comparison is preserved in `MUTATION_COMPARISON_v1.json`.

The necessary correction is a separately normalized trace/source control, including small-source conditioning. A successful total-energy or readout check is insufficient. No claim is made that the full twelve-history mutant was run; this is a demonstrated local-stage survivor. The parent has accepted the finding and is creating separately versioned controls.

## Other actual mutations and the original failures

| Source mutation | Actual local pass / fail | New scientific failures | Fresh identities |
|---|---:|---:|---:|
| Omit massive-neutrino trace | 279 / 4 | 0 | 12 / 12 |
| Omit physical-clock factor from H_J | 259 / 24 | 20 | 12 / 12 |
| Omit entropy correction in N_J(L) | 243 / 40 | 36 | 12 / 12 |

All three retain the original four failures. The H_J mutation fails every generic proper-time readout comparison. The entropy mutation fails early clock, fluid, energy and coordinate-rescaling checks. Actual copied inputs, source diffs, fresh freezes, stdout/stderr, executions and result objects remain under `mutations/`; none has been overwritten.

The parent original execution lasts 879.23 seconds, exits 1, and records 4093 pass / 12 fail with unchanged inputs and empty stderr. Four failures are the fixed-step energy checks. Four timed-out cases each also fail completion and sample-census checks, accounting for the remaining eight failures. These are numerical-route failures, not physical exclusions.

The independent static/readout computation gives 64,327 pass / 4 fail. It reproduces all four coarse energy failures at the original epsilon=2e−6 and tolerance 3e−6: split L=15 gives approximately 6.24e−4 and 2.25e−4 errors; split L=23 gives 8.40e−3 and 3.77e−3. The independently differentiated Friedmann/momentum conservation residual is at most 2.42e−16 over those generic controls. This supports the derivative-step diagnosis but leaves the recorded finite-difference tests failed. An energy identity alone is not an independent control on every force component.

## Independent physical construction and readouts

`INDEPENDENT_DERIVATION_v1.md` gives the independent equations, units and numerical recipe. The implementation uses composite Gauss–Legendre momentum quadrature, differentiates the raw Weyl action, evolves lowered momenta, uses physical N_J as its clock, dynamically evolves plasma temperature and integrates physical age as a state. This differs from the producer's temperature-clock coordinate-acceleration system.

The independent source constructs K_uu from the original Weyl terms, then factors it to J/F^2. It checks all connection contributions through lowered momenta, the full matter trace and sign of energy exchange, the physical-clock chain rule, local G_N normalization and both entropy and collisionless-fluid conservation. No assumption that the late u=0 growth background is connected to the thermal history is made.

Every stored successful row agrees with independent instantaneous action/readout evaluation within the frozen tolerances. This includes field metric, Hhat, H_J, G_N, N_J/Nhat, clock margin, kinetic norm, plasma, dust, all nine per-species density/pressure/trace entries and age integrand. The largest non-coarse generic comparison error is 4.44e−9, within its declared 3e−8 normalized tolerance. Positive domain margins are checked on all 1,928 samples. Finite sample checks do not establish continuous positivity between samples as a theorem.

The density-normalized gas tolerance is 2e−8. In particular, this is not a claim of relative 2e−8 accuracy for tiny traces. The independent strong-history comparison finds an initial electron-trace relative difference of approximately 4.59e−7, while its contribution relative to total density is about 2.14e−10. This is within the actual declared comparison and is explicitly retained rather than mislabeled as a trace-relative pass.

## Complete original case census

The original successful endpoints, all conditional on supplied initial data and calibration, are:

| Original case | Samples/status | H_J/H_GR at endpoint | G_N/G_N,ref | Elapsed Gyr from T_i |
|---|---:|---:|---:|---:|
| split_k0.01 | 241 | 1.0027927678 | 0.999993129653 | 13.3945736571 |
| equal_k0.01 | 241 | 0.999963353617 | 0.999609768522 | 13.4466559106 |
| split_k1e-05 | timeout | — | — | — |
| equal_k1e-05 | 241 | 1.00000882211 | 0.999999999601 | 13.4457252857 |
| split_k1e-06 | 241 | 1 | 1 | 13.4468466398 |
| equal_k1e-06 | 241 | 1.00000881077 | 0.999999999996 | 13.445725969 |
| split_k1e-5_refined | timeout | — | — | — |
| equal_k1e-5_refined | 241 | 1.00000882211 | 0.999999999601 | 13.445725285 |
| split_k1e-5_massless_neutrinos | timeout | — | — | — |
| split_k1e-5_no_dust | 241 | 1.00000003637 | 1 | 39.9516026486 |
| split_k1e-5_initial_pu | timeout | — | — | — |
| split_k1e-5_ideal_gas | 241 | 1 | 1 | 9.17670348254 |

The four timeouts reach approximately L=12.23 (split 1e−5), 10.31 (its refinement), 12.19 (massless-neutrino variant) and 11.09 (initial-p_u variant). Their empty row lists are preserved. The no-dust and ideal-gas variants are different supplied fluid histories with the same baseline normalization, not measurements of our universe's age.

The only complete original refinement pair is equal k=1e−5. Independent recomputation gives maximum normalized differences Hratio=2.88940e−12, G_N ratio=4.44089e−16, N_J'=1.28786e−13 and state=5.98008e−8, all below 3e−5. The split pair is incomplete. The stored age comparison uses two quadratures on one dense solution and therefore does not independently test the dynamics. Its arithmetic and seconds-to-Gyr conversion are correct.

## Independent histories, failed recovery routes, and the remaining limit

The independent equal k=.01 evolution completes in 1.81 seconds with 20,799 RHS evaluations. At all 241 declared temperature sites, the largest normalized state difference is 1.18876e−9, Hratio difference 1.17595e−11, G_N difference 2.06501e−14, and the independently integrated dimensionless age differs by 3.92743e−11. The complete selected-history/refinement comparison contains 6,512 passing checks and no failure.

The requested independent split k=1e−6 trajectory does not complete under the four separately frozen 180-second routes:

| Independent route | Last N_J | RHS evaluations | Outcome |
|---|---:|---:|---|
| Raw-action momentum Radau | 7.37476 | 2,762,600 | timeout |
| Radau with checked explicit Jacobian | 7.41997 | 2,816,200 | timeout |
| BDF with that Jacobian | 8.52828 | 1,983,200 | timeout |
| BDF with exact regrouped potential gradient | 8.51354 | 1,968,100 | timeout |

All use rtol=3e−10, atol=2e−12 and max N_J step .04. No tolerance or resource cap was relaxed. The first independent run's real SciPy finite-difference Jacobian overflow warnings are preserved; the explicit-Jacobian attempts have empty stderr. The 216 explicit-Jacobian coefficient/parity checks pass against 65-digit raw-action differentiation. The final exact gradient regrouping passes 25 additional relative derivative controls and the same 216 Jacobian/parity checks. Neither success converts an unfinished weak trajectory into a completed comparison.

Consequently, the producer's successful split k=1e−6 path has independently checked instantaneous readouts but has not been independently reproduced as a full path here. The remaining cancellation/stiffness limitation is material and must remain visible in later claims. Recovered author routes require their own affected-source review.

## Observational and source boundaries

The PDG Table 14.7 normal-ordering entries dm21^2=7.41e−5 and dm32^2=2.433e−3 eV^2 were independently checked against the preserved page-36 text and rendered page. Their use in m3^2=dm21^2+dm32^2 is correct. Only relevant primary pages and recorded retrieval metadata are claimed read, not all 52 PDF pages. The NuFIT and initial PDG TLS retrieval failures remain preserved; the successful PDG receipt records verified TLS with a valid CA bundle.

NIST values and units, the prior exposed Fixsen temperature identity, and supplied H0=70/Omega_d0=.3 reference are correctly separated. The absolute lightest neutrino mass zero, normal ordering, initial relativistic Fermi momentum distribution, g=2 per species, instantaneous decoupling, dust conservation, zero chemical potential and chosen scalar initial state remain premises. No weak collision, nuclear, recombination, primordial-spectrum or observational likelihood calculation is performed.

Matching Hratio near one or a calibrated endpoint does not establish thermal history selection, connection to the separately studied growth background, or empirical acceptance. Finite internal controls are not observed-history tests. The source already limits these claims; this review retains that scope.

## Preservation and disposition

All original bytes, independent executed versions, true numerical failures, mutation survivors and route warnings are retained. `FINAL_RECEIPT_v1.json` binds this report, the derivation, all independent evidence and the complete original-source disposition map. No parent source, Git state, process ownership, PR, model or formal audit status was changed. The later trace supplement will be separately reviewed without rewriting this record.
