# Affected review: targeted neutrino-trace supplement

The supplement detects the exact original omitted-neutrino-trace mutant. It does not make the unchanged implementation's nine new conditioning failures pass. Both findings are preserved separately from the completed original review.

## Frozen subjects and execution

`INPUT_FREEZE_v1.json` snapshots 38 exact parent source/evidence paths before this check, including the standalone control, its complete explanatory protocol, the original parent v3 supplement result/receipt and its declared inputs. The two executed subjects are (1) an exact copy of original bridge v1 and (2) the exact bytes of the previously executed one-line mutant. The original mutation was not recreated from memory or modified further.

Each execution freezes all twelve actual v1 inputs, plus the standalone control and supplement protocol, for fourteen freshly calculated identities. This includes the actual bridge code, fixtures, input data, upstream thermal/action implementations, quadrature nodes and calibration-source bytes. Both executions pass all fourteen identities; all before/after hashes agree. No field history or fit was run. This is the first execution of these new local controls against these two v1 subjects, not a repeat of the unchanged original positive history run.

The whole standalone source and protocol were read. Every scientific assertion and all 24 output rows were compared. The unchanged-v1 run's 312 scientific assertion objects and all output data are exactly equal to the preserved parent v3 supplement objects, not merely numerically close. Only the number and paths of source-identity assertions differ. Thus the parent's 336 pass / 9 fail and the reviewer's 317 pass / 9 fail represent the same 303 scientific passes and nine scientific failures.

| Subject | All checks pass / fail | Source identities | Scientific pass / fail |
|---|---:|---:|---:|
| Unchanged original v1 | 317 / 9 | 14 / 14 | 303 / 9 |
| Exact previous omitted-trace mutant | 158 / 168 | 14 / 14 | 144 / 168 |

There are 159 additional scientific failures in the mutant. All nine baseline failure names remain failed. Both processes exit 1; both stderr files are empty. Actual sources, fresh freezes, source mappings, commands, stdout/stderr and results are retained in separate subject directories.

## What the new controls establish

The new target grid fixes k=.01,1e−5,1e−6, both b=k and b=a, and L=18,20,22 and the final supplied temperature. It tests a generic state and an instantaneously matched state. The late electron trace is retained as actually evaluated. The test compares direct adaptive relic momentum integrals with the independently normalized neutrino contribution in Jordan trace, Einstein trace and complete implemented u acceleration. Normalization is by the nonzero neutrino signal, not max(1,trace) or the full unrelated acceleration.

| Scientific family | Original pass / fail | Mutant pass / fail |
|---|---:|---:|
| Three relic gas integrals | 72 / 0 | 72 / 0 |
| Jordan trace contribution | 48 / 0 | 0 / 48 |
| Einstein trace contribution | 48 / 0 | 0 / 48 |
| Full acceleration source extraction | 43 / 5 | 0 / 48 |
| Matched H^2 | 24 / 0 | 24 / 0 |
| Matched u acceleration | 20 / 4 | 0 / 24 |
| Matched x and y accelerations | 48 / 0 | 48 / 0 |

The mutation correctly leaves the relic gas integrals intact, so this is specifically a missing coupling/source test. Its trace errors are approximately one relative to the omitted neutrino signal. The targeted controls therefore close the demonstrated omission blind spot in a meaningful sensitivity sense. They do not yet supply a passing numerical implementation at every stated threshold.

## Independent raw-action confirmation of the matched identities

The extra positive evidence does not import the parent's calculation as an oracle. `check_matched_action_v1.py` uses the original independent raw Weyl action, differentiates its metric and potential with SymPy, and evaluates the full lowered-momentum equations in 65-digit arithmetic. It uses the independent composite-Legendre relic/plasma quadrature and original input identities. All 24 new target sites are covered, giving 96 independent comparisons.

At u=p_u=0, x^2=Rstar rho_d, y^2=Rstar rho_gas, p_x=−3x/2 and p_y=−2y, let D=1+2(1+b)(x^2+y^2)/3, t=Rstar(tau_e+tau_nu), and J0=1+(1−3a)s. The independently evaluated raw action gives

H^2=D,
p_u'=−sqrt(a)(1+s)t/(J0 D),
p_x'=x(9/4+t/(2D)),
p_y'=y(4+2t/(3D)).

All 96 comparisons pass the predeclared relative tolerance 3e−11; the largest relative error is 1.63e−18. This confirms signs/factors and both branches under the declared action. A nonzero gas trace changes the instantaneous acceleration, so this calculation does not assert an exact ideal-fluid orbit for a massive gas. It does not prove attraction or selection of any global history.

## Nine failures remain unresolved

Five generic complete-acceleration extraction checks fail the 2e−6 relative-to-neutrino-source tolerance. The largest error is 3.62575e−4 at split k=1e−6 and final L. The extraction subtracts large connection, damping and potential terms to recover a much smaller source, and these failures exhibit that conditioning problem.

Four matched u-acceleration checks fail the 2e−8 relative tolerance. Their errors are 1.53836e−7 for split k=1e−6 at final L, and 2.03044e−7, 5.09439e−8, 2.94715e−7 for equal k=1e−6 at L=18,22,final. These are failures of the actual stored binary64 acceleration at those source-relative thresholds, not merely a source-identity issue. The separate high-precision raw-action calculation supports the proposed identities, but does not erase the implementation failures.

The direct adaptive gas comparisons and direct Jordan/Einstein trace comparisons pass; maximum gas-trace discrepancy is 8.16302e−12 and trace-assembly discrepancy 8.16611e−12 relative to the neutrino signal. This localizes the remaining difficulty to cancellation in force evaluation/extraction, not a demonstrated omission of the original source. A stable force/connection implementation or a suitably independent precision method requires a new frozen affected-source check. The tolerances were not relaxed here.

## Scope and preservation

The supplement is a development control chosen after prior results. It is not an observational test, history likelihood, global stability theorem or full-history mutant result. It does not complete the original independent weak-case integration or alter the twelve original case outcomes.

The original report/receipt and every file they bind remain byte-identical. `COMPARISON_v1.json` records exact original-v1/parent-v3 scientific-object identity, every family count, all nine failures and all new mutant failure names. `SOURCE_DISPOSITION_v1.json` maps the 38 preserved parent inputs/evidence and records final hashes. `FINAL_RECEIPT_v1.json` binds the affected evidence only. No author source, process, Git state, PR or audit status was changed.
