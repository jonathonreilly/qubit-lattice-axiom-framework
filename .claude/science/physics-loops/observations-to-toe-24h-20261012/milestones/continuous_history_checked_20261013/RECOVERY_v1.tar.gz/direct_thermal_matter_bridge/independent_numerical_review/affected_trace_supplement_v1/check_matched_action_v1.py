#!/usr/bin/env python3
from pathlib import Path
import sys,hashlib,json,datetime
import sympy as sp
import mpmath as mp
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent))
import independent_bridge_v1 as own
mp.mp.dps=65;plan=json.loads((P/'MATCHED_ACTION_PLAN_v1.json').read_text());_,expr=own.build_action();symbols=sp.symbols(' '.join(expr['symbols']),real=True);loc=dict(zip(expr['symbols'],symbols));coords=symbols[:3]
K=[sp.sympify(x,locals=loc)for x in expr['K']];U=sp.sympify(expr['U'],locals=loc);B=sp.sympify(expr['B'],locals=loc)
fn=sp.lambdify(symbols,(K,[[sp.diff(k,x)for k in K]for x in coords],U,[sp.diff(U,x)for x in coords],B,sp.diff(B,coords[0])),'mpmath',cse=True)
def m(v):return mp.mpf(str(v))
checks=[];rows=[]
for k in plan['k']:
 for branch in plan['branch']:
  cfg=own.configuration(dict(id='independent_matched',k=k,branch=branch));c={key:m(v)for key,v in cfg.items()if isinstance(v,(int,float))}
  for L in [18.,20.,22.,cfg['Lf']]:
   n=own.entropy_N(L);g=own.gas(n,L,cfg['case']);dust=c['rho_di']*mp.exp(-3*m(n));rho=dust+m(g['rho_gas']);pressure=m(g['P']);trace=dust+m(g['tau_e'])+m(g['tau_nu'])
   x=mp.sqrt(c['Rstar']*dust);y=mp.sqrt(c['Rstar']*m(g['rho_gas']));v=[mp.mpf(0),-mp.mpf('1.5')*x,-2*y]
   kk,dk,U,dU,B,Bu=fn(0,x,y,c['a'],c['b'],c['s'],c['nu']);ab=Bu/B;CB=(1+c['s'])*B*B;sig=CB**2*c['Rstar']*rho;pf=CB**2*c['Rstar']*pressure;tf=CB**2*c['Rstar']*trace
   Q=sum(ki*pi*pi for ki,pi in zip(kk,v));H2=2*(sig+U)/(3-Q);h=-(sig+pf)/H2-Q
   momprime=[-(3+h)*kk[i]*v[i]+sum(dk[i][j]*v[j]**2 for j in range(3))/2-(dU[i]+(ab*tf if i==0 else 0))/H2 for i in range(3)]
   acc=[(momprime[i]-v[i]*sum(v[j]*dk[j][i]for j in range(3)))/kk[i]for i in range(3)]
   D=1+2*(1+c['b'])*(x*x+y*y)/3;t=c['Rstar']*(m(g['tau_e'])+m(g['tau_nu']));J0=1+(1-3*c['a'])*c['s'];expected=[-mp.sqrt(c['a'])*(1+c['s'])*t/(J0*D),x*(mp.mpf('2.25')+t/(2*D)),y*(4+2*t/(3*D))]
   vals=[H2,*acc];wants=[D,*expected];errors=[]
   for j,(got,want)in enumerate(zip(vals,wants)):
    err=abs(got-want)/abs(want);errors.append(float(err));checks.append(dict(name=f'{branch}.{k}.{L}.{j}',actual=str(got),expected=str(want),relative_error=float(err),tolerance=plan['relative_tolerance'],passed=err<=plan['relative_tolerance']))
   rows.append(dict(k=k,branch=branch,L=L,raw_action_values=[str(v)for v in vals],identity_values=[str(v)for v in wants],relative_errors=errors))
obj=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((P/'MATCHED_ACTION_PLAN_v1.json').read_bytes()).hexdigest(),rows=rows,checks=checks,counts=dict(passed=sum(c['passed']for c in checks),failed=sum(not c['passed']for c in checks),total=len(checks)))
with(P/'INDEPENDENT_MATCHED_ACTION_RESULTS_v1.json').open('x')as f:json.dump(obj,f,indent=2);f.write('\n')
print(json.dumps(dict(counts=obj['counts'],maximum_relative_error=max(c['relative_error']for c in checks))))
raise SystemExit(bool(obj['counts']['failed']))
