#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
for label in ['unchanged_original_v1','same_actual_omitted_neutrino_trace']:
 r=P/label;fr=json.loads((r/'FRESH_FREEZE.json').read_text());before={x['path']:sha(x['path'])for x in fr['inputs']};assert all(before[x['path']]==x['sha256']for x in fr['inputs'])
 command=[sys.executable,'-B',str(r/'check_neutrino_trace_controls_v1.py'),'--implementation',str(r/'cosmology/direct_thermal_matter_bridge/check_thermal_matter_bridge_v1.py'),'--freeze',str(r/'FRESH_FREEZE.json'),'--out',str(r/'RESULTS.json')]
 rec=dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,input_hashes_before=before,wrapper_sha256=sha(__file__));start=time.monotonic()
 with(r/'stdout.txt').open('x')as out,(r/'stderr.txt').open('x')as err:run=subprocess.run(command,cwd=r,env=env,stdout=out,stderr=err)
 after={x['path']:sha(x['path'])for x in fr['inputs']};result=json.loads((r/'RESULTS.json').read_text());rec.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,exit_code=run.returncode,input_hashes_after=after,all_inputs_unchanged=before==after,result_sha256=sha(r/'RESULTS.json'),stdout_sha256=sha(r/'stdout.txt'),stderr_sha256=sha(r/'stderr.txt'),counts=result['counts'],source_passes=sum(c['passed']for c in result['checks']if c['name'].startswith('source.')))
 with(r/'EXECUTION.json').open('x')as f:json.dump(rec,f,indent=2);f.write('\n')
 print(json.dumps(dict(subject=label,counts=result['counts'],source_passes=rec['source_passes'],unchanged=rec['all_inputs_unchanged'])),flush=True)
