#!/usr/bin/env python3
"""Parent-authored continuous gas/dust/three-scalar evolution; no empirical fit."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,time,traceback
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp,quad,simpson

HERE=Path(__file__).resolve().parent
CHECKS=[]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

TH=load('bridge_thermal',HERE.parent/'direct_thermal_transition/check_thermal_transition_v2.py')
CL=load('bridge_action',HERE.parent/'direct_curvature_fluid_reconstruction/check_curvature_fluid_v2.py')
INPUTS=json.loads((HERE/'INPUTS_v1.json').read_text())
FIX=json.loads((HERE/'FIXTURES_v1.json').read_text())

def check(name,passed,**detail):CHECKS.append(dict(name=name,passed=bool(passed),**detail))
def compare(name,actual,expected,tol):
    error=abs(actual-expected)/max(abs(expected),1.)
    check(name,np.isfinite(error) and error<=tol,actual=float(actual),expected=float(expected),normalized_error=float(error),tolerance=tol)

def neutrino(T,mu,n):
    node=TH.NODES[str(n)];q=np.asarray(node['x']);wt=np.asarray(node['w'])/(1+np.exp(-q))
    r=mu/T;E=np.sqrt(q*q+r*r)
    rho=T**4/np.pi**2*np.sum(wt*q*q*E)
    pressure=T**4/(3*np.pi**2)*np.sum(wt*q**4/E)
    trace=T**4*r*r/np.pi**2*np.sum(wt*q*q/E)
    return float(rho),float(pressure),float(trace)

def mass_ratios():
    me_ev=INPUTS['electron_mass_kg']*INPUTS['light_speed_SI']**2/INPUTS['eV_J']
    m1=INPUTS['lightest_mass_eV']
    masses=[m1,np.sqrt(m1*m1+INPUTS['delta_m21_squared_eV2']),np.sqrt(m1*m1+INPUTS['delta_m21_squared_eV2']+INPUTS['delta_m32_squared_eV2'])]
    return np.asarray(masses)/me_ev,masses

def gas(L,n,massless_neutrinos=False,ideal=False):
    Ti=INPUTS['Ti_me'];T=Ti*np.exp(-L)
    pl=TH.eos(T,T,n,ideal);initial=TH.eos(Ti,Ti,n,ideal)
    nj=L-np.log(pl['entropy_bar']/initial['entropy_bar'])/3
    tn=Ti*np.exp(-nj);mus,_=mass_ratios()
    ns=[neutrino(tn,0. if massless_neutrinos or ideal else mu,n) for mu in mus]
    rn,pn,tnu=np.sum(ns,axis=0)
    return dict(T=T,Tnu=tn,NJ=nj,cT=pl['cT'],rho_gas=pl['rho_pl']+rn,P=pl['p_pl']+pn,
                tau_gas=pl['trace']+tnu,rho_plasma=pl['rho_pl'],rho_nu=rn,P_nu=pn,tau_nu=tnu,
                tau_e=pl['trace'],species=[list(x) for x in ns],entropy_bar=pl['entropy_bar'])

def calibration(k):
    c=INPUTS['light_speed_SI'];kb=INPUTS['Boltzmann_k_SI'];gn=INPUTS['Newton_G_SI']
    Ee=INPUTS['electron_mass_kg']*c*c;hbar=INPUTS['Planck_h_SI']/(2*np.pi)
    rho_unit=Ee**4/(hbar*c)**3
    H0=INPUTS['H0_km_s_Mpc']*1000/INPUTS['Mpc_m']
    critical=3*c*c*H0*H0/(8*np.pi*gn);dust0=INPUTS['Omega_d0']*critical
    Tf=kb*INPUTS['T0_K']/Ee;Lf=np.log(INPUTS['Ti_me']/Tf)
    end=gas(Lf,256);vacuum=critical-dust0-rho_unit*end['rho_gas']
    if vacuum<=0:raise ValueError('Reference vacuum nonpositive')
    hv2=8*np.pi*gn*vacuum/(3*c*c);rs=3*rho_unit/(2*(1+k)*vacuum)
    dusti=dust0/rho_unit*np.exp(3*end['NJ'])
    return dict(k=k,rho_unit=rho_unit,H0=H0,rho_critical=critical,rho_dust0=dust0,rho_vacuum=vacuum,
                Hv2=hv2,Rstar=rs,rho_di=dusti,Tf=Tf,Lf=Lf,Ntotal=end['NJ'],Tnu_final=end['Tnu'],
                Omega_nu=rho_unit*end['rho_nu']/critical)

def configuration(case):
    k=case['k'];cfg=calibration(k);a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k))
    cfg.update(a=a,s=s,b=k if case['branch']=='split' else a,nu=INPUTS['nu'],case=case)
    if case.get('remove_dust'):cfg['rho_di']=0.
    # Variant matter keeps baseline Rstar/Hv; its initial gas field follows its changed gas.
    g=gas(0,FIX['refinement' if case.get('refined') else 'solver']['nodes'],case.get('massless_neutrinos',False),case.get('ideal_gas',False))
    cfg['xi']=np.sqrt(cfg['Rstar']*cfg['rho_di'])
    cfg['yi']=np.sqrt(cfg['Rstar']*g['rho_gas'])
    return cfg

def quantities(L,state,cfg,n):
    u,X,Y,pu,vx,vy=state;case=cfg['case']
    g=gas(L,n,case.get('massless_neutrinos',False),case.get('ideal_gas',False))
    sx=cfg['xi']*np.exp(-1.5*g['NJ']) if cfg['xi'] else 1.
    sy=cfg['yi']*np.exp(-2*g['NJ']);phi=np.array([u,sx*X,sy*Y]);p=np.array([pu,sx*vx,sy*vy])
    K,dk,U,dU,ab=CL.full_einstein_functions(phi,cfg['a'],cfg['b'],cfg['s'],cfg['nu'])
    E=np.exp(2*np.sqrt(cfg['a'])*u);F=1+cfg['s']*E;J=1+(1-3*cfg['a'])*cfg['s']*E;CB=(1+cfg['s'])*E/F
    dust=cfg['rho_di']*np.exp(-3*g['NJ']);rho=dust+g['rho_gas'];P=g['P'];tau=dust+g['tau_e']
    sig=CB*CB*cfg['Rstar']*rho;pf=CB*CB*cfg['Rstar']*P;tf=CB*CB*cfg['Rstar']*tau
    norm=float(K@(p*p));H2=2*(sig+U)/(3-norm);h=-(sig+pf)/H2-norm;njp=1+ab*pu
    if not np.all(np.isfinite(np.r_[K,H2,njp])) or min(K)<=0 or H2<=0 or njp<=0 or 3-norm<=0:
        raise ValueError(('physical chart',float(L),K.tolist(),float(H2),float(njp),norm))
    con=(p*(p@dk)-dk@(p*p)/2)/K
    force=dU.copy();force[0]+=ab*tf
    acc=-(3+h)*p-con-force/(K*H2)
    hgr2=1+2*(1+cfg['k'])*cfg['Rstar']*rho/3
    HJ2=H2*njp*njp/CB
    return dict(gas=g,sx=sx,sy=sy,phi=phi,p=p,K=K,dk=dk,U=U,dU=dU,ab=ab,CB=CB,F=F,J=J,
                rho=dust+g['rho_gas'],rho_dust=dust,P=P,tau=tau,sigma=sig,pressure=pf,trace=tf,
                norm=norm,H2=H2,h=h,njp=njp,acc=acc,HGR2=hgr2,HJ2=HJ2,
                Hratio=np.sqrt(HJ2/hgr2),GNratio=CB*(1+cfg['a']/J)/(1+cfg['k']))

def rhs(L,state,cfg,n):
    q=quantities(L,state,cfg,n);u,X,Y,pu,vx,vy=state
    rate=q['gas']['cT']*q['njp'];dust_scale_rate=1.5*q['njp'] if cfg['xi'] else 0.
    return np.array([pu,vx+dust_scale_rate*X,vy+2*q['njp']*Y,q['acc'][0],
                     q['acc'][1]/q['sx']+dust_scale_rate*vx,q['acc'][2]/q['sy']+2*q['njp']*vy])/rate

def raw_action_oracle(L,state,cfg,n):
    q=quantities(L,state,cfg,n)
    with mp.workdps(50):
        a,b,s,nu=[mp.mpf(str(cfg[t])) for t in ['a','b','s','nu']];al=mp.sqrt(a)
        coords=list(map(lambda x:mp.mpf(str(x)),q['phi']));p=list(map(lambda x:mp.mpf(str(x)),q['p']))
        def raw(u,x,y):
            A=mp.exp(al*u);F=1+s*A*A;D=1+mp.mpf(2)/3*(1+b)*(x*x+y*y)
            # Original Jordan-Ricci conformal kinetic contribution, independent of J shortcut.
            F_u=2*al*s*A*A
            K=[(1-3*a*s*A*A)/F+mp.mpf(3)/4*(F_u/F)**2,(1+s)*4*b/(9*F*D),(1+s)*b/(3*F*D)]
            v0=mp.mpf(3)/2+(b/2-al*u+2*a*u*u/b)*x*x+b*y*y/3+nu*u*u/2
            v1=(b/2+al*b*u+2*a*u*u/b)*x*x+b*y*y/3
            U=(1+s)*(v0+s*v1+mp.mpf(3)/2*s*A**4)/F**2
            return K,U,A/mp.sqrt(F)
        K,U,B=raw(*coords)
        dk=[[mp.diff(lambda t:raw(*(coords[:i]+[t]+coords[i+1:]))[0][j],coords[i]) for j in range(3)] for i in range(3)]
        du=[mp.diff(lambda t:raw(*(coords[:i]+[t]+coords[i+1:]))[1],coords[i]) for i in range(3)]
        bu=mp.diff(lambda t:raw(t,*coords[1:])[2],coords[0]);ab=bu/B
        CB=(1+s)*B*B;sig=CB*CB*mp.mpf(str(cfg['Rstar']*q['rho']));pres=CB*CB*mp.mpf(str(cfg['Rstar']*q['P']));trace=CB*CB*mp.mpf(str(cfg['Rstar']*q['tau']))
        norm=sum(ki*pi*pi for ki,pi in zip(K,p));H2=2*(sig+U)/(3-norm);h=-(sig+pres)/H2-norm
        acc=[]
        for i in range(3):
            mom=sum(dk[j][i]*p[j]*p[i] for j in range(3))-sum(dk[i][j]*p[j]*p[j] for j in range(3))/2
            acc.append(-(3+h)*p[i]-(mom+(du[i]+(ab*trace if i==0 else 0))/H2)/K[i])
        H=mp.sqrt(H2);Bdot=bu*p[0]*H
        Hphysical=(H/B+Bdot/(B*B))/mp.sqrt(1+s)
        gn=(1+s)*B*B*(1+ab*ab/K[0])/(1+mp.mpf(str(cfg['k'])))
        return dict(acc=[float(v) for v in acc],H2=float(H2),Hratio=float(Hphysical/mp.sqrt(mp.mpf(str(q['HGR2'])))),GNratio=float(gn))

def local_controls():
    eos_rows=[]
    for r in [0.,1e-6,.01,.1,1.,10.,100.,1000.]:
        got=neutrino(1.,r,128)
        f=lambda q:np.exp(-q)/(1+np.exp(-q))
        direct=[quad(lambda q:q*q*np.sqrt(q*q+r*r)*f(q),0,100,epsabs=1e-11,epsrel=2e-12)[0]/np.pi**2,
                quad(lambda q:q**4/np.sqrt(q*q+r*r)*f(q),0,100,epsabs=1e-11,epsrel=2e-12)[0]/(3*np.pi**2),
                quad(lambda q:q*q*r*r/np.sqrt(q*q+r*r)*f(q),0,100,epsabs=1e-11,epsrel=2e-12)[0]/np.pi**2]
        for j in range(3):compare(f'neutrino.{r}.integral.{j}',got[j],direct[j],FIX['gas_quadrature_tolerance'])
        compare(f'neutrino.{r}.trace',got[0]-3*got[1],got[2],2e-12)
        e=2e-5;der=(neutrino(np.exp(e),r,128)[0]-neutrino(np.exp(-e),r,128)[0])/(2*e)
        compare(f'neutrino.{r}.conservation',der,3*(got[0]+got[1]),2e-8)
        eos_rows.append(dict(r=r,quadrature=list(got),adaptive=direct))
    compare('neutrino.massless',neutrino(1,0,128)[0],7*np.pi**2/120,2e-12)
    generic=[]
    for branch in ['split','equal']:
      cfg=configuration(dict(k=1e-5,branch=branch,id='generic'))
      for L in FIX['generic_L']:
        e=FIX['clock_fd_step'];g=gas(L,128)
        compare(f'clock.{branch}.{L}',(gas(L+e,128)['NJ']-gas(L-e,128)['NJ'])/(2*e),1/g['cT'],2e-8)
        for j,st in enumerate(FIX['generic_states']):
            st=np.asarray(st);q=quantities(L,st,cfg,128);v=rhs(L,st,cfg,128);raw=raw_action_oracle(L,st,cfg,128)
            tag=f'generic.{branch}.{L}.{j}';rate=g['cT']*q['njp']
            for z in range(3):compare(tag+f'.momentum.{z}',q['acc'][z]/[1,q['sx'],q['sy']][z],raw['acc'][z]/[1,q['sx'],q['sy']][z],3e-8)
            for key in ['H2','Hratio','GNratio']:compare(tag+'.raw.'+key,q[key],raw[key],3e-10)
            e=FIX['energy_fd_step'];qm=quantities(L-e,st-e*v,cfg,128);qp=quantities(L+e,st+e*v,cfg,128)
            compare(tag+'.energy',(np.log(qp['H2'])-np.log(qm['H2']))/(4*e)*rate,q['h'],FIX['conservation_tolerance'])
            wanted=(-3*(q['sigma']+q['pressure'])+q['ab']*st[3]*q['trace'])/q['sigma']
            compare(tag+'.fluid',(np.log(qp['sigma'])-np.log(qm['sigma']))/(2*e)*rate,wanted,FIX['conservation_tolerance'])
            field_der=(qp['phi']-qm['phi'])/(2*e)*rate
            for z in range(3):compare(tag+f'.rescale.{z}',field_der[z]/[1,q['sx'],q['sy']][z],q['p'][z]/[1,q['sx'],q['sy']][z],2e-8)
            generic.append(dict(branch=branch,L=L,state=st.tolist(),scaled_acceleration=(q['acc']/[1,q['sx'],q['sy']]).tolist(),Hratio=q['Hratio'],GNratio=q['GNratio']))
    return dict(neutrino=eos_rows,generic=generic)

def run_case(case,out):
    cfg=configuration(case);settings=FIX['refinement' if case.get('refined') else 'solver'];n=settings['nodes']
    state=np.array([0.,1.,1.,case.get('initial_pu',0.),-1.5,-2.])
    if case.get('remove_dust'):state[1]=state[4]=0.
    start=time.monotonic();evaluations=0;last_L=0.
    def fun(L,z):
        nonlocal evaluations,last_L
        evaluations+=1;last_L=float(L)
        if evaluations%100==0 and time.monotonic()-start>FIX['case_seconds']:raise TimeoutError('Frozen per-case wall cap')
        return rhs(L,z,cfg,n)
    samples=np.linspace(0,cfg['Lf'],FIX['samples']);rows=[]
    try:
        sol=solve_ivp(fun,(0,cfg['Lf']),state,method=settings['method'],rtol=settings['rtol'],atol=settings['atol'],max_step=settings['max_step'],t_eval=samples,dense_output=True)
        success=sol.success and len(sol.t)==len(samples)
        for i,L in enumerate(sol.t):
            st=sol.y[:,i];q=quantities(L,st,cfg,n);g=q['gas']
            rows.append(dict(L=float(L),state=st.tolist(),T=g['T'],Tnu=g['Tnu'],NJ=g['NJ'],Nhat=g['NJ']-.5*np.log(q['CB']),
                Hratio=q['Hratio'],GNratio=q['GNratio'],H2=q['H2'],HJ2=q['HJ2'],HGR2=q['HGR2'],NJprime=q['njp'],kinetic_norm=q['norm'],
                K=q['K'].tolist(),rho_dust=q['rho_dust'],rho_gas=g['rho_gas'],rho_plasma=g['rho_plasma'],rho_nu=g['rho_nu'],pressure=g['P'],
                trace_fraction=q['tau']/q['rho'],tau_e=g['tau_e'],tau_nu=g['tau_nu'],species=g['species'],
                dimensionless_age_integrand=np.sqrt(q['CB']/q['H2'])/(g['cT']*q['njp'])))
            check(case['id']+f'.{i}.positive',min(q['K'])>0 and 3-q['norm']>0 and q['njp']>0)
            if i%40==0 or i==len(sol.t)-1:
                raw=raw_action_oracle(float(L),st,cfg,n)
                for key in ['H2','Hratio','GNratio']:compare(case['id']+f'.{i}.readout.'+key,q[key],raw[key],3e-9)
            if case.get('ideal_gas'):
                for j,target in enumerate([0,1,1,0,-1.5,-2.]):compare(case['id']+f'.{i}.orbit.{j}',st[j],target,3e-6)
                compare(case['id']+f'.{i}.ideal_H',q['Hratio'],1.,3e-6)
        record=dict(case=case,configuration=cfg,settings=settings,success=success,message=sol.message,nfev=sol.nfev,njev=sol.njev,nlu=sol.nlu,rows=rows)
        if rows:
            # Two distinct integration meshes diagnose quadrature error, not independent dynamics.
            ages=[]
            for size in [961,1921]:
                grid=np.linspace(0,float(sol.t[-1]),size);vals=[]
                for L,st in zip(grid,sol.sol(grid).T):
                    q=quantities(L,st,cfg,n);vals.append(np.sqrt(q['CB']/q['H2'])/(q['gas']['cT']*q['njp']))
                ages.append(float(simpson(vals,x=grid)))
            record['elapsed_age_Hv']=ages[-1];record['age_quadrature_comparison']=ages
            record['elapsed_age_Gyr']=ages[-1]/np.sqrt(cfg['Hv2'])/(365.25*86400*1e9)
            compare(case['id']+'.age_quadrature',ages[0],ages[1],3e-7)
            record['sampled_extrema']={key:dict(minimum=min(r[key] for r in rows),maximum=max(r[key] for r in rows)) for key in ['Hratio','GNratio','NJprime','kinetic_norm']}
    except Exception as exc:
        record=dict(case=case,configuration=cfg,settings=settings,success=False,error=repr(exc),traceback=traceback.format_exc(),last_L=last_L,evaluations=evaluations,rows=rows)
    record['elapsed_seconds']=time.monotonic()-start
    check(case['id']+'.complete',record['success'],error=record.get('error'))
    check(case['id']+'.census',len(rows)==FIX['samples'],actual=len(rows))
    (out/(case['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(case=case['id'],success=record['success'],seconds=record['elapsed_seconds'],last_L=record.get('last_L'),endpoint=rows[-1] if rows else None,error=record.get('error'))),flush=True)
    return record

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--freeze',type=Path,required=True);pa.add_argument('--out',type=Path,required=True);args=pa.parse_args()
    args.out.mkdir(exist_ok=False)
    for row in json.loads(args.freeze.read_text())['inputs']:check('source.'+row['path'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'])
    controls=local_controls();(args.out/'LOCAL_CONTROLS.json').write_text(json.dumps(dict(data=controls,checks=CHECKS),indent=2)+'\n')
    print(json.dumps(dict(local_controls=len(CHECKS),failed=sum(not x['passed'] for x in CHECKS))),flush=True)
    calibrations=[calibration(k) for k in [.01,1e-5,1e-6]]
    for cfg in calibrations:
        g=gas(cfg['Lf'],256);rho=cfg['rho_dust0']/cfg['rho_unit']+g['rho_gas']
        compare('reference.H0.'+str(cfg['k']),cfg['Hv2']*(1+2*(1+cfg['k'])*cfg['Rstar']*rho/3)/cfg['H0']**2,1.,3e-14)
    histories=[run_case(case,args.out) for case in FIX['cases']]
    paired=[]
    for br in ['split','equal']:
        base=next(x for x in histories if x['case']['id']==f'{br}_k1e-05')
        refined=next(x for x in histories if x['case']['id']==f'{br}_k1e-5_refined')
        if base['success'] and refined['success']:
            worst={}
            for field in ['Hratio','GNratio','NJprime']:
                error=max(abs(x[field]-y[field])/max(1,abs(y[field])) for x,y in zip(base['rows'],refined['rows']))
                check('refinement.'+br+'.'+field,error<FIX['refinement_tolerance'],normalized_error=error);worst[field]=error
            err=max(np.max(np.abs(np.asarray(x['state'])-y['state'])/np.maximum(1,np.abs(y['state']))) for x,y in zip(base['rows'],refined['rows']))
            check('refinement.'+br+'.state',err<FIX['refinement_tolerance'],normalized_error=float(err));worst['state']=float(err);paired.append(dict(branch=br,max_normalized_errors=worst))
        else:paired.append(dict(branch=br,status='paired history incomplete'))
    result=dict(scope='Fixed classical action, supplied initial-state/decoupling/masses; continuous background reconstruction, not empirical fit or TOE.',calibrations=calibrations,local_controls=controls,histories=histories,refinements=paired,checks=CHECKS,counts=dict(passed=sum(x['passed'] for x in CHECKS),failed=sum(not x['passed'] for x in CHECKS),total=len(CHECKS)))
    (args.out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts']),flush=True)
    raise SystemExit(bool(result['counts']['failed']))
if __name__=='__main__':main()
