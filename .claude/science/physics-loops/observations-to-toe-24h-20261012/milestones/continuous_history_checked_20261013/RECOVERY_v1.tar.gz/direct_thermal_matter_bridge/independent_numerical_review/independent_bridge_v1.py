#!/usr/bin/env python3
"""Independent physical-clock/lowered-momentum bridge construction."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
from pathlib import Path
from functools import lru_cache
import datetime,hashlib,json,math,time,traceback
import numpy as np
import sympy as sp
from scipy.integrate import quad,solve_ivp
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
P=Path(__file__).resolve().parent;S=P/'source_snapshot'
I=json.loads((S/'INPUTS_v1.json').read_text());FIX=json.loads((S/'FIXTURES_v1.json').read_text());PLAN=json.loads((P/'INDEPENDENT_PLAN_v1.json').read_text())
CHECKS=[]
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def ck(name,ok,**detail):CHECKS.append(dict(name=name,passed=bool(ok),**detail))
def close(name,got,want,tol,scale=None):
    error=abs(float(got)-float(want))/(max(1,abs(float(want))) if scale is None else scale)
    ck(name,math.isfinite(error) and error<=tol,actual=float(got),expected=float(want),normalized_error=error,tolerance=tol)
def save(name,obj):
    f=P/name;f.parent.mkdir(parents=True,exist_ok=True)
    with f.open('x')as out:json.dump(obj,out,indent=2,allow_nan=False);out.write('\n')
nodes,weights=leggauss(40);edges=[0.,1.,4.,12.,30.,60.]
Q=np.concatenate([(b-a)*(nodes+1)/2+a for a,b in zip(edges,edges[1:])]);W=np.concatenate([(b-a)*weights/2 for a,b in zip(edges,edges[1:])]);Q2=Q*Q
occupation=np.exp(-Q)/(1+np.exp(-Q))
MU=np.array([I['lightest_mass_eV'],math.sqrt(I['lightest_mass_eV']**2+I['delta_m21_squared_eV2']),math.sqrt(I['lightest_mass_eV']**2+I['delta_m21_squared_eV2']+I['delta_m32_squared_eV2'])])/(I['electron_mass_kg']*I['light_speed_SI']**2/I['eV_J'])
@lru_cache(maxsize=2048)
def plasma(T,ideal=False):
    r=0. if ideal else 1/T;E=np.hypot(Q,r);f=np.exp(-E)/(1+np.exp(-E));pref=2/np.pi**2
    re=pref*np.dot(W,Q2*E*f);pe=pref/3*np.dot(W,Q2*Q2/E*f)
    tr=pref*r*r*np.dot(W,Q2/E*f);heat=pref*np.dot(W,Q2*E*E*f*(1-f));rg=np.pi**2/15
    entropy=4*rg/3+re+pe;cT=3*entropy/(4*rg+heat)
    return dict(rho=T**4*(rg+re),P=T**4*(rg/3+pe),trace=T**4*tr,entropy_bar=entropy,cT=cT)
@lru_cache(maxsize=2048)
def neutrinos(Tnu,massless=False):
    ratios=np.zeros(3) if massless else MU/Tnu;E=np.hypot(Q[None,:],ratios[:,None]);pref=Tnu**4/np.pi**2
    rho=pref*np.sum(W*Q2*E*occupation,axis=1);pressure=pref/3*np.sum(W*Q2*Q2/E*occupation,axis=1);trace=pref*ratios**2*np.sum(W*Q2/E*occupation,axis=1)
    return np.array([rho,pressure,trace]).T
def gas(NJ,L,case):
    T=I['Ti_me']*math.exp(-L);tn=I['Ti_me']*math.exp(-NJ);pl=plasma(T,bool(case.get('ideal_gas')))
    species=neutrinos(tn,bool(case.get('massless_neutrinos') or case.get('ideal_gas')));rn,pn,taun=species.sum(axis=0)
    return dict(T=T,Tnu=tn,NJ=NJ,cT=pl['cT'],rho_gas=pl['rho']+rn,P=pl['P']+pn,tau_gas=pl['trace']+taun,rho_plasma=pl['rho'],rho_nu=rn,P_nu=pn,tau_nu=taun,tau_e=pl['trace'],species=species.tolist(),entropy_bar=pl['entropy_bar'])
def entropy_N(L,ideal=False):
    return L-math.log(plasma(I['Ti_me']*math.exp(-L),ideal)['entropy_bar']/plasma(I['Ti_me'],ideal)['entropy_bar'])/3
def calibration(k):
    c=I['light_speed_SI'];Ee=I['electron_mass_kg']*c*c;hbar=I['Planck_h_SI']/(2*np.pi);density=Ee**4/(hbar*c)**3
    H0=I['H0_km_s_Mpc']*1000/I['Mpc_m'];critical=3*c*c*H0*H0/(8*np.pi*I['Newton_G_SI']);d0=I['Omega_d0']*critical
    Tf=I['Boltzmann_k_SI']*I['T0_K']/Ee;Lf=math.log(I['Ti_me']/Tf);NJ=entropy_N(Lf);end=gas(NJ,Lf,{})
    vacuum=critical-d0-density*end['rho_gas'];hv2=8*np.pi*I['Newton_G_SI']*vacuum/(3*c*c)
    return dict(k=k,rho_unit=density,H0=H0,rho_critical=critical,rho_dust0=d0,rho_vacuum=vacuum,Hv2=hv2,Rstar=3*density/(2*(1+k)*vacuum),rho_di=d0/density*math.exp(3*NJ),Tf=Tf,Lf=Lf,Ntotal=NJ,Tnu_final=end['Tnu'],Omega_nu=density*end['rho_nu']/critical)
def configuration(case):
    k=case['k'];cfg=calibration(k);a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));b=k if case['branch']=='split' else a
    cfg.update(a=a,s=s,b=b,nu=I['nu'],case=case)
    if case.get('remove_dust'):cfg['rho_di']=0.
    cfg['xi']=math.sqrt(cfg['Rstar']*cfg['rho_di']);cfg['yi']=math.sqrt(cfg['Rstar']*gas(0.,0.,case)['rho_gas'])
    return cfg
def build_action():
    u,x,y,a,b,s,nu=sp.symbols('u x y a b s nu',real=True);al=sp.sqrt(a);A=sp.exp(al*u);F=1+s*A*A;D=1+sp.Rational(2,3)*(1+b)*(x*x+y*y)
    raw=[(1-3*a*s*A*A)/F+sp.Rational(3,4)*(sp.diff(F,u)/F)**2,4*b*(1+s)/(9*F*D),b*(1+s)/(3*F*D)]
    K=[sp.factor(k) for k in raw]
    v0=sp.Rational(3,2)+(b/2-al*u+2*a*u*u/b)*x*x+b*y*y/3+nu*u*u/2
    v1=(b/2+al*b*u+2*a*u*u/b)*x*x+b*y*y/3
    U=(1+s)*(v0+s*v1+sp.Rational(3,2)*s*A**4)/F**2;coords=(u,x,y)
    dk=[[sp.diff(k,c) for k in K]for c in coords];du=[sp.diff(U,c)for c in coords];B=A/sp.sqrt(F)
    args=(u,x,y,a,b,s,nu)
    fn=sp.lambdify(args,(K,dk,U,du,B,sp.diff(B,u)),'numpy',cse=True)
    expr=dict(symbols=[str(z)for z in args],K=[str(z)for z in K],U=str(U),B=str(B),derivative_orientation='dk[coordinate][metric component]')
    return fn,expr
ACTION=None
def basics(NJ,state,cfg):
    u,X,Y,mu,mx,my,L,age=state;case=cfg['case'];g=gas(NJ,L,case)
    sx=cfg['xi']*math.exp(-1.5*NJ) if cfg['xi'] else 1.;sy=cfg['yi']*math.exp(-2*NJ);phi=np.array([u,sx*X,sy*Y])
    kk,dd,U,dU,B,Bu=ACTION(*phi,cfg['a'],cfg['b'],cfg['s'],cfg['nu']);K=np.asarray(kk);dk=np.asarray(dd);dU=np.asarray(dU)
    refD=1+2*(1+cfg['b'])*(sx*sx+sy*sy)/3;ku0=(1+(1-3*cfg['a'])*cfg['s'])/(1+cfg['s'])**2
    normal=np.array([ku0,4*cfg['b']*sx/(9*refD),cfg['b']*sy/(3*refD)])
    mom=normal*np.array([mu,mx,my]);p=mom/K;ab=Bu/B;CB=(1+cfg['s'])*B*B
    dust=cfg['rho_di']*math.exp(-3*NJ);rho=dust+g['rho_gas'];pres=g['P'];tau=dust+g['tau_gas']
    sig=CB*CB*cfg['Rstar']*rho;pf=CB*CB*cfg['Rstar']*pres;tf=CB*CB*cfg['Rstar']*tau
    norm=float(K@(p*p));H2=2*(sig+U)/(3-norm);h=-(sig+pf)/H2-norm;njp=1+ab*p[0]
    if not np.all(np.isfinite(np.r_[K,H2,njp])) or min(K)<=0 or H2<=0 or njp<=0 or 3-norm<=0:raise ValueError(('independent physical chart',NJ,K.tolist(),H2,njp,norm))
    force=dU.copy();force[0]+=ab*tf
    momprime=-(3+h)*mom+dk@(p*p)/2-force/H2
    # Differentiation of reference metric times scale in the physical clock.
    refDprime=-2*(1+cfg['b'])*(3*sx*sx+4*sy*sy)/3
    normlog=np.array([0.,(-1.5 if cfg['xi'] else 0.)-refDprime/refD,-2-refDprime/refD])
    rate=np.r_[p[0]/njp,p[1]/(sx*njp)+(1.5*X if cfg['xi'] else 0.),p[2]/(sy*njp)+2*Y,momprime/(njp*normal)-normlog*np.array([mu,mx,my]),g['cT'],math.sqrt(CB/H2)/njp]
    HGR2=1+2*(1+cfg['k'])*cfg['Rstar']*rho/3
    HJ2=(math.sqrt(H2)/B+Bu*p[0]*math.sqrt(H2)/(B*B))**2/(1+cfg['s'])
    GN=CB*(1+(Bu/B)**2/K[0])/(1+cfg['k'])
    return dict(gas=g,sx=sx,sy=sy,phi=phi,p=p,K=K,dk=dk,U=U,dU=dU,B=B,Bu=Bu,ab=ab,CB=CB,sigma=sig,pressure=pf,trace=tf,norm=norm,H2=H2,h=h,njp=njp,HGR2=HGR2,HJ2=HJ2,Hratio=math.sqrt(HJ2/HGR2),GNratio=GN,rho_dust=dust,rho=rho,tau=tau,normal=normal,mom=mom,momprime=momprime,rate=rate)
def from_parent(L,z,cfg):
    NJ=entropy_N(L,bool(cfg['case'].get('ideal_gas')));u,X,Y,pu,vx,vy=z
    sx=cfg['xi']*math.exp(-1.5*NJ) if cfg['xi'] else 1.;sy=cfg['yi']*math.exp(-2*NJ)
    K=np.array(ACTION(u,sx*X,sy*Y,cfg['a'],cfg['b'],cfg['s'],cfg['nu'])[0]);D0=1+2*(1+cfg['b'])*(sx*sx+sy*sy)/3
    normal=np.array([(1+(1-3*cfg['a'])*cfg['s'])/(1+cfg['s'])**2,4*cfg['b']*sx/(9*D0),cfg['b']*sy/(3*D0)])
    mom=K*np.array([pu,sx*vx,sy*vy])/normal
    return NJ,np.r_[u,X,Y,mom,L,0.]
def readout(NJ,state,cfg):
    q=basics(NJ,state,cfg);g=q['gas'];u,X,Y=state[:3];p=q['p'];physical=np.array([u,X,Y,p[0],p[1]/q['sx'],p[2]/q['sy']])
    return dict(L=float(state[6]),state=physical.tolist(),T=g['T'],Tnu=g['Tnu'],NJ=NJ,Nhat=NJ-.5*math.log(q['CB']),Hratio=q['Hratio'],GNratio=q['GNratio'],H2=q['H2'],HJ2=q['HJ2'],HGR2=q['HGR2'],NJprime=q['njp'],kinetic_norm=q['norm'],K=q['K'].tolist(),rho_dust=q['rho_dust'],rho_gas=g['rho_gas'],rho_plasma=g['rho_plasma'],rho_nu=g['rho_nu'],pressure=g['P'],trace_fraction=q['tau']/q['rho'],tau_e=g['tau_e'],tau_nu=g['tau_nu'],species=g['species'],dimensionless_age_integrand=math.sqrt(q['CB']/q['H2'])/(g['cT']*q['njp']),age_integrated=float(state[7]))
def history(case):
    cfg=configuration(case);settings=PLAN['history_solver'];initial_parent=np.array([0.,1.,1.,case.get('initial_pu',0.),-1.5,-2.]);NJ,z=from_parent(0.,initial_parent,cfg)
    count=0;last=0.;start=time.monotonic()
    def fun(NJ,z):
        nonlocal count,last
        count+=1;last=float(NJ)
        if count%100==0 and time.monotonic()-start>settings['per_case_seconds']:raise TimeoutError('Independent predeclared 180-second route cap')
        return basics(NJ,z,cfg)['rate']
    def endpoint(NJ,z):return z[6]-cfg['Lf']
    endpoint.terminal=True;endpoint.direction=1
    try:
        sol=solve_ivp(fun,(0,cfg['Ntotal']+.25),z,method=settings['method'],rtol=settings['rtol'],atol=settings['atol'],max_step=settings['max_step_NJ'],events=endpoint,dense_output=True)
        success=sol.success and len(sol.t_events[0])==1;rows=[]
        if success:
            end=float(sol.t_events[0][0])
            for i,L in enumerate(np.linspace(0,cfg['Lf'],FIX['samples'])):
                n=0. if i==0 else end if i==FIX['samples']-1 else brentq(lambda t:sol.sol(t)[6]-L,0,end,xtol=1e-13,rtol=1e-14)
                rows.append(readout(n,sol.sol(n),cfg))
        record=dict(case=case,configuration=cfg,settings=settings,success=bool(success),message=sol.message,nfev=sol.nfev,njev=sol.njev,nlu=sol.nlu,rows=rows,endpoint_NJ=float(sol.t[-1]),elapsed_seconds=time.monotonic()-start)
    except Exception as exc:record=dict(case=case,configuration=cfg,settings=settings,success=False,error=repr(exc),traceback=traceback.format_exc(),last_NJ=last,evaluations=count,rows=[],elapsed_seconds=time.monotonic()-start)
    save('independent_histories/'+case['id']+'.json',record)
    print(json.dumps(dict(case=case['id'],success=record['success'],seconds=record['elapsed_seconds'],nfev=record.get('nfev'),error=record.get('error'))),flush=True)
    return record
def main():
    global ACTION
    ACTION,expr=build_action();save('RAW_ACTION_EXPRESSIONS_v1.json',expr)
    selected=[c for name in PLAN['selected_full_histories'] for c in FIX['cases']if c['id']==name]
    records=[history(c) for c in selected]
    result=dict(code_sha256=sha(__file__),plan_sha256=sha(P/'INDEPENDENT_PLAN_v1.json'),histories=records,all_completed=all(r['success']for r in records))
    save('INDEPENDENT_HISTORIES_v1.json',result)
    raise SystemExit(not result['all_completed'])
if __name__=='__main__':main()
