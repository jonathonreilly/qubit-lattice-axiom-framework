#!/usr/bin/env python3
"""Read-only comparisons of separately evolved physical-clock histories."""
from pathlib import Path
import hashlib,json,math,datetime
P=Path(__file__).resolve().parent;S=P/'completed_source_snapshot/evidence_v1/histories';checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def compare(name,x,y,tol):
 e=abs(x-y)/max(1,abs(y));checks.append(dict(name=name,actual=x,expected=y,normalized_error=e,tolerance=tol,passed=math.isfinite(e)and e<=tol));return e
plan=json.loads((P/'INDEPENDENT_PLAN_v1.json').read_text());tol=plan['history_comparison_normalized_tolerance'];records=[];inputs={}
files=[P/'independent_histories/equal_k0.01.json']
for variant in ['stable_route_v4']:
 f=P/variant/'independent_histories/split_k1e-06.json'
 if f.exists() and json.loads(f.read_text()).get('success'):files.append(f)
for f in files:
 independent=json.loads(f.read_text());name=independent['case']['id'];orig=S/(name+'.json');author=json.loads(orig.read_text());inputs[str(f)]=sha(f);inputs[str(orig)]=sha(orig)
 assert independent['success'] and author['success'] and len(independent['rows'])==len(author['rows'])==241
 maxima={};rows=[]
 fields=['T','Tnu','NJ','Nhat','Hratio','GNratio','H2','HJ2','HGR2','NJprime','kinetic_norm','dimensionless_age_integrand','rho_dust','rho_gas','rho_plasma','rho_nu','pressure','trace_fraction','tau_e','tau_nu']
 for i,(got,want)in enumerate(zip(independent['rows'],author['rows'])):
  compare(f'{name}.{i}.L',got['L'],want['L'],1e-11)
  errs={k:compare(f'{name}.{i}.{k}',got[k],want[k],tol)for k in fields}
  errs['state']=max(compare(f'{name}.{i}.state.{j}',v,w,tol)for j,(v,w)in enumerate(zip(got['state'],want['state'])))
  for k,e in errs.items():
   if e>maxima.get(k,{}).get('error',-1):maxima[k]=dict(error=e,L=want['L'],row=i)
  rows.append(dict(L=want['L'],normalized_errors=errs))
 age=independent['rows'][-1]['age_integrated'];age_error=compare(name+'.integrated_age_Hv',age,author['elapsed_age_Hv'],tol)
 records.append(dict(id=name,independent_path=str(f),independent_sha256=sha(f),author_sha256=sha(orig),maxima=maxima,age_Hv=age,author_age_Hv=author['elapsed_age_Hv'],age_normalized_error=age_error,rows=rows))
result=json.loads((S/'RESULTS.json').read_text());inputs[str(S/'RESULTS.json')]=sha(S/'RESULTS.json');refinements=[]
for r in result['refinements']:
 if r['branch']=='split':
  assert not json.loads((S/'split_k1e-05.json').read_text())['success'] and not json.loads((S/'split_k1e-5_refined.json').read_text())['success'];refinements.append(dict(branch='split',status='Both parent trajectories incomplete; no refinement conclusion.'));continue
 coarse=json.loads((S/'equal_k1e-05.json').read_text());fine=json.loads((S/'equal_k1e-5_refined.json').read_text());vals={}
 for key in ['Hratio','GNratio','NJprime']:
  vals[key]=max(abs(a[key]-b[key])/max(1,abs(b[key]))for a,b in zip(coarse['rows'],fine['rows']))
 vals['state']=max(abs(v-w)/max(1,abs(w))for a,b in zip(coarse['rows'],fine['rows'])for v,w in zip(a['state'],b['state']))
 for k,v in vals.items():compare('parent_refinement.'+k,v,r['max_normalized_errors'][k],1e-15)
 refinements.append(dict(branch='equal',values=vals))
obj=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_sha256=sha(__file__),inputs=inputs,records=records,refinements=refinements,checks=checks,counts=dict(passed=sum(c['passed']for c in checks),failed=sum(not c['passed']for c in checks),total=len(checks)))
with(P/'INDEPENDENT_HISTORY_COMPARISON_v1.json').open('x')as out:json.dump(obj,out,indent=2);out.write('\n')
print(json.dumps(dict(counts=obj['counts'],records=[dict(id=r['id'],max_error=max(v['error']for v in r['maxima'].values()),age_error=r['age_normalized_error'],state=r['maxima']['state'])for r in records],refinements=refinements)))
raise SystemExit(bool(obj['counts']['failed']))
