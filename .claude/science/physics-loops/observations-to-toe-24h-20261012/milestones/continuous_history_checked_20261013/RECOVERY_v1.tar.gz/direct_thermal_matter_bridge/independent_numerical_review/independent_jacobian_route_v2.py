#!/usr/bin/env python3
"""Explicit derivative route for the original independent momentum equations."""
from pathlib import Path
import datetime,json,math
import numpy as np
import sympy as sp
import mpmath as mp
import independent_bridge_v1 as own
mp.mp.dps=65
BASE=Path(__file__).resolve().parent;PLAN=json.loads((BASE/'INDEPENDENT_JACOBIAN_ROUTE_v2.json').read_text());OUT=BASE/'jacobian_route_v2';OUT.mkdir(exist_ok=False)
own.P=OUT;own.ACTION,EXPR=own.build_action();own.save('RAW_ACTION_EXPRESSIONS.json',EXPR)
case=next(c for c in own.FIX['cases']if c['id']=='split_k1e-06');cfg=own.configuration(case)
def fluid_derivative(L):
    T=own.I['Ti_me']*np.exp(-L);r=1/T;E=np.hypot(own.Q,r);f=np.exp(-E)/(1+np.exp(-E));ff=f*(1-f);pref=2/np.pi**2;rg=np.pi**2/15
    g=own.plasma(float(T));heat=4*rg+pref*np.dot(own.W,own.Q2*E*E*ff)
    dbar=pref*r*r*np.dot(own.W,own.Q2*ff*(E*(1-2*f)-2))
    ent=g['entropy_bar'];cprime=-g['cT']*(heat/ent-3-dbar/heat)
    return -T**4*heat,-T**4*ent,T**4*(-heat+3*ent),cprime
def complex_rhs(N,z):
    u,X,Y,mu,mx,my,L,age=z;realL=float(np.real(L));g=own.gas(N,realL,cfg['case']);delta=L-realL
    dr,dp,dt,dc=fluid_derivative(realL)
    rho_g=g['rho_gas']+dr*delta;pressure=g['P']+dp*delta;tau_g=g['tau_gas']+dt*delta;cT=g['cT']+dc*delta
    sx=cfg['xi']*np.exp(-1.5*N);sy=cfg['yi']*np.exp(-2*N)
    K,dk,U,dU,B,Bu=own.ACTION(u,sx*X,sy*Y,cfg['a'],cfg['b'],cfg['s'],cfg['nu']);K=np.asarray(K);dk=np.asarray(dk);dU=np.asarray(dU)
    D0=1+2*(1+cfg['b'])*(sx*sx+sy*sy)/3;fu=(1+(1-3*cfg['a'])*cfg['s'])/(1+cfg['s'])**2
    scales=np.array([fu,4*cfg['b']*sx/(9*D0),cfg['b']*sy/(3*D0)]);m=scales*np.array([mu,mx,my]);p=m/K;ab=Bu/B;CB=(1+cfg['s'])*B*B
    dust=cfg['rho_di']*np.exp(-3*N);sig=CB*CB*cfg['Rstar']*(dust+rho_g);pf=CB*CB*cfg['Rstar']*pressure;tf=CB*CB*cfg['Rstar']*(dust+tau_g)
    norm=K@(p*p);H2=2*(sig+U)/(3-norm);h=-(sig+pf)/H2-norm;njp=1+ab*p[0]
    force=dU+np.array([ab*tf,0.,0.]);momprime=-(3+h)*m+dk@(p*p)/2-force/H2
    dD0=-2*(1+cfg['b'])*(3*sx*sx+4*sy*sy)/3;dlogs=np.array([0.,-1.5-dD0/D0,-2-dD0/D0])
    return np.r_[p[0]/njp,p[1]/(sx*njp)+1.5*X,p[2]/(sy*njp)+2*Y,momprime/(njp*scales)-dlogs*np.array([mu,mx,my]),cT,np.sqrt(CB/H2)/njp]
def jacobian(N,z):
    h=1e-24;columns=[]
    for i in range(8):
        zz=np.asarray(z,dtype=complex);zz[i]+=1j*h;columns.append(np.imag(complex_rhs(N,zz))/h)
    return np.array(columns).T
# Separate high-precision action derivatives and full temperature-dependent integrals.
symbols=sp.symbols(' '.join(EXPR['symbols']),real=True);loc=dict(zip(EXPR['symbols'],symbols));coords=symbols[:3]
K=[sp.sympify(t,locals=loc)for t in EXPR['K']];U=sp.sympify(EXPR['U'],locals=loc);B=sp.sympify(EXPR['B'],locals=loc)
MF=sp.lambdify(symbols,(K,[[sp.diff(k,c)for k in K]for c in coords],U,[sp.diff(U,c)for c in coords],B,sp.diff(B,coords[0])),'mpmath',cse=True)
Q=[mp.mpf(str(x))for x in own.Q];W=[mp.mpf(str(x))for x in own.W];mc={k:mp.mpf(str(v))for k,v in cfg.items()if isinstance(v,(int,float))};mTi=mp.mpf(str(own.I['Ti_me']))
def mp_rhs(N,z):
    N=mp.mpf(str(N));u,X,Y,mu,mx,my,L,age=z;T=mTi*mp.exp(-L);r=1/T;g=own.gas(float(N),float(mp.re(L)),cfg['case'])
    rg=mp.pi**2/15;re=mp.mpf(0);pe=mp.mpf(0);tr=mp.mpf(0);heat=4*rg
    for q,w in zip(Q,W):
        E=mp.sqrt(q*q+r*r);f=1/(mp.exp(E)+1);pref=2*w/mp.pi**2
        re+=pref*q*q*E*f;pe+=pref*q**4*f/(3*E);tr+=pref*r*r*q*q/E*f;heat+=pref*q*q*E*E*f*(1-f)
    rho_g=T**4*(rg+re)+mp.mpf(str(g['rho_nu']));pressure=T**4*(rg/3+pe)+mp.mpf(str(g['P_nu']));tau_g=T**4*tr+mp.mpf(str(g['tau_nu']));cT=3*(4*rg/3+re+pe)/heat
    sx=mc['xi']*mp.exp(-mp.mpf('1.5')*N);sy=mc['yi']*mp.exp(-2*N)
    K,dk,U,dU,B,Bu=MF(u,sx*X,sy*Y,mc['a'],mc['b'],mc['s'],mc['nu'])
    D0=1+2*(1+mc['b'])*(sx*sx+sy*sy)/3;fu=(1+(1-3*mc['a'])*mc['s'])/(1+mc['s'])**2
    scales=[fu,4*mc['b']*sx/(9*D0),mc['b']*sy/(3*D0)];m=[v*w for v,w in zip(scales,[mu,mx,my])];p=[v/w for v,w in zip(m,K)];ab=Bu/B;CB=(1+mc['s'])*B*B
    dust=mc['rho_di']*mp.exp(-3*N);sig=CB**2*mc['Rstar']*(dust+rho_g);pf=CB**2*mc['Rstar']*pressure;tf=CB**2*mc['Rstar']*(dust+tau_g)
    norm=sum(ki*pi*pi for ki,pi in zip(K,p));H2=2*(sig+U)/(3-norm);h=-(sig+pf)/H2-norm;njp=1+ab*p[0]
    momprime=[-(3+h)*m[i]+sum(dk[i][j]*p[j]**2 for j in range(3))/2-(dU[i]+(ab*tf if i==0 else 0))/H2 for i in range(3)]
    dD0=-2*(1+mc['b'])*(3*sx*sx+4*sy*sy)/3;dlogs=[0,-mp.mpf('1.5')-dD0/D0,-2-dD0/D0]
    return [p[0]/njp,p[1]/(sx*njp)+mp.mpf('1.5')*X,p[2]/(sy*njp)+2*Y]+[momprime[i]/(njp*scales[i])-dlogs[i]*[mu,mx,my][i]for i in range(3)]+[cT,mp.sqrt(CB/H2)/njp]
controls=[]
for L in PLAN['jacobian_control_L']:
    N,z=own.from_parent(L,own.FIX['generic_states'][PLAN['jacobian_control_state_index']],cfg)
    lhs=own.basics(N,z,cfg)['rate'];rhs=complex_rhs(N,z)
    for i in range(8):own.close(f'real_rhs.{L}.{i}',rhs[i],lhs[i],3e-12)
    jac=jacobian(N,z);mz=[mp.mpf(str(x))for x in z];reference=[]
    for j in range(8):
        col=mp.diff(lambda t:mp.matrix(mp_rhs(N,mz[:j]+[t]+mz[j+1:])),mz[j]);reference.append([float(v)for v in col])
    reference=np.array(reference).T
    for i in range(8):
        for j in range(8):own.close(f'jacobian.{L}.{i}.{j}',jac[i,j],reference[i,j],PLAN['jacobian_normalized_tolerance'])
    controls.append(dict(L=L,NJ=N,complex_jacobian=jac.tolist(),mp65_reference=reference.tolist()))
own.save('JACOBIAN_CONTROLS.json',dict(code_sha256=own.sha(__file__),controls=controls,checks=own.CHECKS,counts=dict(passed=sum(c['passed']for c in own.CHECKS),failed=sum(not c['passed']for c in own.CHECKS),total=len(own.CHECKS))))
if any(not c['passed']for c in own.CHECKS):
    print(json.dumps(dict(stage='jacobian_controls',failed=[c for c in own.CHECKS if not c['passed']])),flush=True);raise SystemExit(1)
original_solve=own.solve_ivp
def explicit(*args,**kw):return original_solve(*args,jac=jacobian,**kw)
own.solve_ivp=explicit
record=own.history(case)
own.save('RESULTS.json',dict(code_sha256=own.sha(__file__),plan_sha256=own.sha(BASE/'INDEPENDENT_JACOBIAN_ROUTE_v2.json'),history=record,jacobian_controls_passed=True))
raise SystemExit(not record['success'])
