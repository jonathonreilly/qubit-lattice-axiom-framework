#!/usr/bin/env python3
"""Consume the complete frozen run with independent gas/action/readout functions."""
from pathlib import Path
import collections,datetime,hashlib,json,math
import numpy as np
from scipy.integrate import quad
import independent_bridge_v1 as own
P=Path(__file__).resolve().parent;R=json.loads((P/'completed_source_snapshot/evidence_v1/histories/RESULTS.json').read_text())
own.ACTION,_=own.build_action();C=own.CHECKS
for name in ['INPUT_FREEZE_v1.json','COMPLETED_EVIDENCE_FREEZE_v1.json']:
    for i,r in enumerate(json.loads((P/name).read_text())['sources']):own.ck(f'source.{name}.{i}',own.sha(r['source_path'])==own.sha(r['snapshot_path'])==r['sha256'])
own.ck('twelve_case_census',len(R['histories'])==len(own.FIX['cases'])==12)
own.ck('original_counts',R['counts']==dict(passed=4093,failed=12,total=4105))
own.ck('all_assertions_consumed',R['counts']==dict(passed=sum(c['passed']for c in R['checks']),failed=sum(not c['passed']for c in R['checks']),total=len(R['checks'])))
cal=[]
for old in R['calibrations']:
    cfg=own.calibration(old['k']);cal.append(cfg)
    for key,v in cfg.items():own.close(f'calibration.{old["k"]}.{key}',old[key],v,2e-10,scale=max(abs(v),1e-300))
    own.ck('positive_vacuum.'+str(old['k']),cfg['rho_vacuum']>0)
    gf=own.gas(cfg['Ntotal'],cfg['Lf'],{});rho=cfg['rho_dust0']/cfg['rho_unit']+gf['rho_gas']
    own.close('reference_H0.'+str(old['k']),cfg['Hv2']*(1+2*(1+old['k'])*cfg['Rstar']*rho/3),cfg['H0']**2,3e-14,scale=cfg['H0']**2)
neutrino=[]
for row in R['local_controls']['neutrino']:
    r=row['r'];E=np.hypot(own.Q,r);base=own.W*own.occupation*own.Q2/np.pi**2
    ours=np.array([np.dot(base,E),np.dot(base,own.Q2/E)/3,r*r*np.dot(base,1/E)])
    er=ours[0]
    for j in range(3):own.close(f'neutrino.{r}.{j}',row['quadrature'][j],ours[j],own.PLAN['gas_comparison_relative_to_total_density_tolerance'],scale=er)
    # Direct derivative of the collisionless energy integral, independent of an evolved orbit.
    derivative=np.dot(base,4*E-r*r/E)
    own.close(f'neutrino.{r}.continuity',derivative,3*(ours[0]+ours[1]),2e-13,scale=er)
    if r:own.ck(f'neutrino.{r}.strict_positive_trace',ours[2]>0)
    neutrino.append(dict(r=r,independent=ours.tolist(),density_log_temperature_derivative=derivative))
generic=[]
for item in R['local_controls']['generic']:
    cfg=own.configuration(dict(k=1e-5,branch=item['branch'],id='generic'));L=item['L'];z=np.array(item['state']);N,Y=own.from_parent(L,z,cfg);q=own.basics(N,Y,cfg)
    p=q['p'];Kdot=p@q['dk'];acc=(q['momprime']-Kdot*p)/q['K'];scales=np.array([1,q['sx'],q['sy']])
    tag=f'generic.{item["branch"]}.{L}.{own.FIX["generic_states"].index(item["state"])}'
    for i in range(3):own.close(tag+f'.acc.{i}',item['scaled_acceleration'][i],acc[i]/scales[i],3e-8)
    for key in ['Hratio','GNratio']:own.close(tag+'.'+key,item[key],q[key],3e-10)
    sigp=-3*(q['sigma']+q['pressure'])+q['ab']*p[0]*q['trace'];Qp=2*p@q['momprime']-(p*p)@Kdot
    hf=.5*((sigp+q['dU']@p)/(q['sigma']+q['U'])+Qp/(3-q['norm']))
    own.close(tag+'.analytic_energy',hf,q['h'],own.PLAN['conservation_tolerance'])
    rate=q['gas']['cT']*q['njp'];v=np.r_[p[0],p[1]/q['sx']+1.5*q['njp']*z[1],p[2]/q['sy']+2*q['njp']*z[2],acc[0],acc[1]/q['sx']+1.5*q['njp']*z[4],acc[2]/q['sy']+2*q['njp']*z[5]]/rate
    e=own.FIX['energy_fd_step'];nm,ym=own.from_parent(L-e,z-e*v,cfg);np_,yp=own.from_parent(L+e,z+e*v,cfg)
    qm=own.basics(nm,ym,cfg);qp=own.basics(np_,yp,cfg);hfrozen=(math.log(qp['H2'])-math.log(qm['H2']))/(4*e)*rate
    # Preserve the actual frozen-step failures as failures, not as positive assertions.
    own.close(tag+'.original_coarse_energy_requirement',hfrozen,q['h'],own.FIX['conservation_tolerance'])
    ec=own.FIX['clock_fd_step'];clock=(own.entropy_N(L+ec)-own.entropy_N(L-ec))/(2*ec)
    own.close(tag+'.entropy_clock',clock,1/q['gas']['cT'],own.PLAN['clock_tolerance'])
    neutrino_force=q['ab']*q['CB']**2*cfg['Rstar']*q['gas']['tau_nu']/(q['K'][0]*q['H2'])
    generic.append(dict(tag=tag,h=q['h'],analytic_h=hf,frozen_step_h=hfrozen,scaled_acceleration=(acc/scales).tolist(),missing_neutrino_trace_acceleration_change=neutrino_force,neutrino_fraction_of_trace=q['gas']['tau_nu']/q['tau']))
hist=[];total=0
for case,record in zip(own.FIX['cases'],R['histories']):
    ident=case['id'];own.ck('case_identity.'+ident,record['case']==case)
    own.ck('percase_identity.'+ident,json.loads((P/'completed_source_snapshot/evidence_v1/histories'/f'{ident}.json').read_text())==record)
    cfg=own.configuration(case)
    for key,want in cfg.items():
        if isinstance(want,(int,float)):
            own.close(f'configuration.{ident}.{key}',record['configuration'][key],want,2e-10,scale=max(abs(want),1e-300))
        else:own.ck(f'configuration.{ident}.{key}',record['configuration'][key]==want)
    maxima={};status=dict(id=ident,success=record['success'],rows=len(record['rows']),error=record.get('error'),last_L=record.get('last_L'))
    if not record['success']:
        own.ck('failed_route_record.'+ident,'TimeoutError' in record.get('error','') and not record['rows']);hist.append(status);continue
    own.ck('complete_rows.'+ident,len(record['rows'])==241)
    for j,row in enumerate(record['rows']):
        total+=1;N,y=own.from_parent(row['L'],row['state'],cfg);q=own.basics(N,y,cfg);got=own.readout(N,y,cfg);fluidscale=q['rho']
        for key in ['T','Tnu','NJ','Nhat','Hratio','GNratio','H2','HJ2','HGR2','NJprime','kinetic_norm','dimensionless_age_integrand']:
            norm=max(abs(got[key]),1.) if key not in ['T','Tnu','H2','HJ2','HGR2','dimensionless_age_integrand']else max(abs(got[key]),1e-300)
            err=abs(row[key]-got[key])/norm;maxima[key]=max(maxima.get(key,0),err)
            own.close(f'row.{ident}.{j}.{key}',row[key],got[key],own.PLAN['instantaneous_readout_normalized_tolerance'],scale=norm)
        for i in range(3):own.close(f'row.{ident}.{j}.K.{i}',row['K'][i],got['K'][i],3e-9,scale=abs(got['K'][i]))
        for key in ['rho_dust','rho_gas','rho_plasma','rho_nu','pressure','tau_e','tau_nu']:
            own.close(f'row.{ident}.{j}.{key}',row[key],got[key],own.PLAN['gas_comparison_relative_to_total_density_tolerance'],scale=fluidscale)
        own.close(f'row.{ident}.{j}.trace_fraction',row['trace_fraction'],got['trace_fraction'],2e-8)
        for i in range(3):
            for k in range(3):own.close(f'row.{ident}.{j}.species.{i}.{k}',row['species'][i][k],got['species'][i][k],2e-8,scale=fluidscale)
        own.ck(f'row.{ident}.{j}.domain',min(got['K'])>0 and got['NJprime']>0 and 3-got['kinetic_norm']>0)
    for key,extrema in record['sampled_extrema'].items():
        own.ck('extrema.'+ident+'.'+key,extrema==dict(minimum=min(r[key]for r in record['rows']),maximum=max(r[key]for r in record['rows'])))
    ages=record['age_quadrature_comparison'];own.ck('age_comparison.'+ident,len(ages)==2 and abs(ages[0]-ages[1])/max(1,abs(ages[1]))<3e-7 and record['elapsed_age_Hv']==ages[-1])
    own.close('age_conversion.'+ident,record['elapsed_age_Gyr'],record['elapsed_age_Hv']/math.sqrt(cfg['Hv2'])/(365.25*86400*1e9),3e-14)
    status.update(maximum_instantaneous_readout_errors=maxima,endpoint=record['rows'][-1],elapsed_age_Gyr=record['elapsed_age_Gyr']);hist.append(status)
own.ck('success_failure_census',sum(h['success']for h in hist)==8 and total==1928)
# Inspect actual negative executions, not hypothetical mutations.
baseline={c['name']for c in R['checks']if not c['passed'] and c['name'].startswith('generic.')};mutations=[]
for name in ['omit_neutrino_trace','omit_physical_clock_readout']:
    root=P/'mutations'/name;ex=json.loads((root/'EXECUTION.json').read_text());mr=json.loads((root/'RESULTS.json').read_text());failed={c['name']for c in mr['checks']if not c['passed']}
    own.ck('mutation_identities.'+name,ex['source_passes']==12 and ex['all_inputs_unchanged'])
    mutations.append(dict(name=name,counts=mr['counts'],source_checks_passed=12,failed_names=sorted(failed),additional_to_original=sorted(failed-baseline),survived_local_stage=failed==baseline))
for name in ['INPUT_FREEZE_v1.json','COMPLETED_EVIDENCE_FREEZE_v1.json']:
    for i,r in enumerate(json.loads((P/name).read_text())['sources']):own.ck(f'final_source.{name}.{i}',own.sha(r['source_path'])==r['sha256'])
result=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_sha256=own.sha(__file__),independent_equations_sha256=own.sha(P/'independent_bridge_v1.py'),source_freeze_sha256=own.sha(P/'INPUT_FREEZE_v1.json'),completed_freeze_sha256=own.sha(P/'COMPLETED_EVIDENCE_FREEZE_v1.json'),calibrations=cal,neutrino=neutrino,generic=generic,histories=hist,mutations=mutations,checks=C,counts=dict(passed=sum(c['passed']for c in C),failed=sum(not c['passed']for c in C),total=len(C)))
own.save('INDEPENDENT_STATIC_RESULTS_v1.json',result)
print(json.dumps(dict(counts=result['counts'],failed=[c for c in C if not c['passed']],mutations=mutations),indent=2))
raise SystemExit(bool(result['counts']['failed']))
