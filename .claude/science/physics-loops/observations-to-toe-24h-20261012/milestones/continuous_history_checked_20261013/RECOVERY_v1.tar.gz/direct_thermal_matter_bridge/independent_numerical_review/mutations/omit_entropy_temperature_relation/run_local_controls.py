from pathlib import Path
import hashlib,importlib.util,json
P=Path(__file__).resolve().parent
r=P/'cosmology/direct_thermal_matter_bridge/check_thermal_matter_bridge_v1.py'
spec=importlib.util.spec_from_file_location('negative_subject',r);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for row in json.loads((P/'FRESH_INPUTS.json').read_text())['inputs']:m.check('source.'+row['path'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'])
data=m.local_controls()
o=dict(data=data,checks=m.CHECKS,counts=dict(passed=sum(c['passed']for c in m.CHECKS),failed=sum(not c['passed']for c in m.CHECKS),total=len(m.CHECKS)))
with(P/'RESULTS.json').open('x')as f:json.dump(o,f,indent=2);f.write('\n')
print(json.dumps(o['counts']))
raise SystemExit(bool(o['counts']['failed']))
