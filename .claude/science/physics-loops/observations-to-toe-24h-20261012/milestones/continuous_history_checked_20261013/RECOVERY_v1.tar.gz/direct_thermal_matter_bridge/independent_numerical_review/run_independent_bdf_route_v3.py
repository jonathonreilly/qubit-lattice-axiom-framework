#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['independent_bridge_v1.py','independent_bdf_route_v3.py','INDEPENDENT_PLAN_v1.json','INDEPENDENT_BDF_ROUTE_v3.json','INPUT_FREEZE_v1.json','COMPLETED_EVIDENCE_FREEZE_v1.json','INDEPENDENT_HISTORIES_v1.json']
paths=[P/n for n in names];before={str(f):sha(f)for f in paths}
record=dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=[sys.executable,'-B',str(P/'independent_bdf_route_v3.py')],input_hashes_before=before,wrapper_sha256=sha(__file__));start=time.monotonic()
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with(P/'bdf_stdout_v3.txt').open('x')as out,(P/'bdf_stderr_v3.txt').open('x')as err:r=subprocess.run(record['command'],cwd=P,env=env,stdout=out,stderr=err)
record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,exit_code=r.returncode,input_hashes_after={str(f):sha(f)for f in paths});record['all_inputs_unchanged']=before==record['input_hashes_after']
for n in ['bdf_stdout_v3.txt','bdf_stderr_v3.txt','bdf_route_v3/JACOBIAN_CONTROLS.json','bdf_route_v3/RESULTS.json']:
 f=P/n
 if f.exists():record[n]=dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)
with(P/'INDEPENDENT_BDF_EXECUTION_v3.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n')
print((P/'bdf_stdout_v3.txt').read_text());print((P/'bdf_stderr_v3.txt').read_text());print(json.dumps(dict(exit_code=r.returncode,seconds=record['elapsed_seconds'],all_inputs_unchanged=record['all_inputs_unchanged'])))
raise SystemExit(r.returncode)
