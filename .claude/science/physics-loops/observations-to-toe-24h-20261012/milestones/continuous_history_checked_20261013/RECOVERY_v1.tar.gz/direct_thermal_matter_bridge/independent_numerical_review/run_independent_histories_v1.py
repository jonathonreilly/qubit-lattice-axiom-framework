#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=set()
for name in ['INPUT_FREEZE_v1.json','COMPLETED_EVIDENCE_FREEZE_v1.json']:
    paths.add(P/name)
    paths.update(Path(r['source_path'])for r in json.loads((P/name).read_text())['sources'])
paths.update([P/'independent_bridge_v1.py',P/'INDEPENDENT_PLAN_v1.json'])
before={str(f):sha(f)for f in sorted(paths)}
record=dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=[sys.executable,'-B',str(P/'independent_bridge_v1.py')],input_hashes_before=before,wrapper_sha256=sha(__file__))
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');t=time.monotonic()
with(P/'histories_stdout_v1.txt').open('x')as out,(P/'histories_stderr_v1.txt').open('x')as err:r=subprocess.run(record['command'],cwd=P,env=env,stdout=out,stderr=err)
record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=r.returncode,input_hashes_after={str(f):sha(f)for f in sorted(paths)})
record['all_inputs_unchanged']=record['input_hashes_before']==record['input_hashes_after']
for name in ['INDEPENDENT_HISTORIES_v1.json','histories_stdout_v1.txt','histories_stderr_v1.txt']:
 f=P/name
 if f.exists():record[name]=dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)
with(P/'INDEPENDENT_HISTORY_EXECUTION_v1.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n')
print((P/'histories_stdout_v1.txt').read_text());print((P/'histories_stderr_v1.txt').read_text());print(json.dumps(dict(exit_code=r.returncode,seconds=record['elapsed_seconds'],all_inputs_unchanged=record['all_inputs_unchanged'])))
raise SystemExit(r.returncode)
