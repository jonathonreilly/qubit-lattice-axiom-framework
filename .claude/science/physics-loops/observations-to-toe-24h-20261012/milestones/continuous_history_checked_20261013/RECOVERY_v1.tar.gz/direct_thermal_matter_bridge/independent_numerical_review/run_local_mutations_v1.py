#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent;S=P/'source_snapshot';decl=json.loads((S/'evidence_v1/FREEZE.json').read_text());B=Path(decl['inputs'][0]['path']).parent;C=B.parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,o):
    with Path(p).open('x')as f:json.dump(o,f,indent=2);f.write('\n')
plan=json.loads((P/'LOCAL_MUTATION_PLAN_v1.json').read_text())
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
for mutation in plan['mutations']:
    root=P/'mutations'/mutation['name'];root.mkdir(parents=True,exist_ok=False);paths=[];mapping=[]
    for row in decl['inputs']:
        src=Path(row['path']);assert sha(src)==row['sha256']
        rel=Path('cosmology')/src.relative_to(C) if src.is_relative_to(C) else Path('external')/src.parent.name/src.name
        dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes());paths.append(dst)
        mapping.append(dict(original_path=str(src),original_sha256=row['sha256'],copy_path=str(dst)))
    run=root/'cosmology/direct_thermal_matter_bridge/check_thermal_matter_bridge_v1.py';source=run.read_text();assert source.count(mutation['old'])==1;run.write_text(source.replace(mutation['old'],mutation['new']))
    fresh=[dict(path=str(f),sha256=sha(f))for f in paths]
    save(root/'FRESH_INPUTS.json',dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs=fresh))
    save(root/'SOURCE_CHANGE.json',dict(**mutation,mapping=mapping,mutant_sha256=sha(run)))
    driver=root/'run_local_controls.py'
    driver.write_text("from pathlib import Path\nimport hashlib,importlib.util,json\nP=Path(__file__).resolve().parent\nr=P/'cosmology/direct_thermal_matter_bridge/check_thermal_matter_bridge_v1.py'\nspec=importlib.util.spec_from_file_location('negative_subject',r);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)\nfor row in json.loads((P/'FRESH_INPUTS.json').read_text())['inputs']:m.check('source.'+row['path'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'])\ndata=m.local_controls()\no=dict(data=data,checks=m.CHECKS,counts=dict(passed=sum(c['passed']for c in m.CHECKS),failed=sum(not c['passed']for c in m.CHECKS),total=len(m.CHECKS)))\nwith(P/'RESULTS.json').open('x')as f:json.dump(o,f,indent=2);f.write('\\n')\nprint(json.dumps(o['counts']))\nraise SystemExit(bool(o['counts']['failed']))\n")
    command=[sys.executable,'-B',str(driver)];record=dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,input_hashes_before=fresh,driver_sha256=sha(driver),runner_sha256=sha(run));start=time.monotonic()
    with(root/'stdout.txt').open('x')as out,(root/'stderr.txt').open('x')as err:r=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=err)
    after=[dict(path=str(f),sha256=sha(f))for f in paths];record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,exit_code=r.returncode,input_hashes_after=after,all_inputs_unchanged=fresh==after)
    if(root/'RESULTS.json').exists():
        result=json.loads((root/'RESULTS.json').read_text());record.update(result_sha256=sha(root/'RESULTS.json'),counts=result['counts'],source_passes=sum(c['passed']for c in result['checks']if c['name'].startswith('source.')),failures=[c for c in result['checks']if not c['passed']])
    save(root/'EXECUTION.json',record);print(json.dumps(dict(mutation=mutation['name'],exit_code=r.returncode,counts=record.get('counts'),source_passes=record.get('source_passes'))),flush=True)
