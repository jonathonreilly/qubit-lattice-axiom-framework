# Focused v5 precision-u helper check

**The actual `precision_u_acceleration` helper implements the full original
u momentum equation.** Its default 34-digit evaluation passed all 108 sampled
comparisons with an independent 80-digit raw-action calculation from the same
binary scaled inputs. This is a focused implementation check, not a complete
v5 history or solver certification.

Reviewed v5 SHA256:
`f2dc269a05798f7d274e81743d2a678aa22767507f5ac98f6c0b7e076c416895`.
The actual v4-to-v5 delta adds the helper and assigns its result to `acc[0]`.
The stable-gradient wrapper and the other five scaled RHS components retain
their existing equations. No matched-orbit acceleration was substituted.

## Equation and connection check

The full diagonal Einstein metric is `K=diag(Ku,Kx,Ky)`, with
`Ku=J/F²`, `J=1+(1-3a)z`, `F=1+z`, `z=s exp(2sqrt(a)u)`. Because Ku
does not depend on x or y, all mixed contributions to the u connection vanish.
Direct differentiation gives

    d_u Ku = Ku 2alpha z[(1-3a)/J-2/F],
    d_u Kx = -2alpha z Kx/F,
    d_u Ky = -2alpha z Ky/F.

Therefore

    Gamma^u_ij p^i p^j
      = (d_u Ku) p_u²/(2Ku)
        + alpha z(Kx p_x²+Ky p_y²)/(F Ku).

This is precisely the helper's connection, including its sign and kinetic
normalization. The remaining terms are the full damping term `-(3+h)p_u`
and `-[U_u+alpha_B trace]/(Ku H²)`, with `alpha_B=alpha/F`.
The helper independently reconstructs the complete kinetic norm,
`H²=2(sigma+U)/(3-Qkin)` and `h=-(sigma+pressure)/H²-Qkin` from all six scaled
state variables and the fixed fluid primitives. Its potential and stable
derivative are the original action already checked in the preceding review.
No assumption `u=p_u=0`, ideal-fluid pressure, or matching of x²/y² to the
fluids occurs inside the helper.

The reviewer reference differentiates the original separate V0 and V1
potentials and the pre-simplification Weyl kinetic expression using mpmath.
It then forms the lowered Euler-Lagrange momentum equation. It does not copy
the helper's closed connection or its factored gradient as the reference.
The independent metric-derivative route agrees with the closed u connection
at every sample; maximum scaled residual was `2.45e-79`.

## Actual numerical comparisons

Before execution, freeze recorded k=.01,1e-5,1e-6; both b=k and b=a;
L=0,12,18,20,22 and the supplied final temperature; and three scaled states
at each point: the earlier matched construction, the original generic state,
and a generic state with a negative transverse field. This gives 108 points.

- **108 helper comparisons passed; zero failed.** The maximum relative
  difference between the returned double and the 80-digit reference was
  `8.50e-17`, below the declared
  `max(1e-28,4e-15*abs(reference))` absolute threshold.
- Every helper result was bit-for-bit equal to `float(reference80)`:
  zero ULP distance at all 108 points.
- Calling the actual helper with 50 internal digits gave the same returned
  double at all 108 points.
- `quantities(...)[acc][0]` was equal to the actual default helper at all
  108 points. This checks the new call site as well as the standalone helper.
- All 108 independently differentiated connection/metric comparisons passed
  their separately declared `1e-65` scaled tolerance.

These controls ran once. No failed check was rerun at a looser tolerance.
The frozen source identities, actual command, script hash, timing, logs,
per-point values and full residuals are preserved in this folder.

## Numerical inputs versus rounded readouts

The helper's numerical inputs are the binary values of `(u,X,Y,p_u,vx,vy)`,
the fixed configuration and the already computed fluid primitives. It converts
those values to multiprecision **before** computing sx, sy, x, y, p_x, p_y,
dust, the metric, potential, Hubble factors and the complete u acceleration.
The reference does the same conversion of primitive inputs, while deriving
the subsequent equation by a different route.

This is the same mathematical field equation as v4, but it is not the same
floating-point operation order. In particular, the double `phi`, `p`,
`rho_dust`, K, H² and dU returned by `quantities` are separately rounded
readouts; they are not the exact intermediate values consumed by the helper.
Taking them as the starting point of a high-precision oracle checks a nearby
rounded state instead. Higher precision after those products cannot undo the
initial rounding.

This distinction matters where the residual force is small. At matched
b=a, k=1e-6, L=12, the reference from scaled primitives gives
`acc_u=-2.351031224063852207e-7`, while the reference started from the rounded
physical-field/dust readouts gives `-2.349564451591483391e-7`: a relative
difference of `6.23885e-4`, despite ordinary floating-point differences in
the underlying fields. That comparison diagnoses conditioning and input
identity; it is not evidence for a new physical force.

The helper retains the precision of supplied primitive inputs: its gas
quadrature values, N_J, couplings, normalization and initial amplitudes are
still the earlier binary doubles. This check establishes the evaluation
accuracy at those inputs; it does not establish higher accuracy for the
gas model or its calibrated parameters.

## Preserved failures and limits

The source-bound parent trace result remains **344 passed, 7 failed**. All
seven failures are the generic full-acceleration source-extraction diagnostics.
They combine the high-precision-derived acceleration, rounded to double, with
separately rounded double K, H², connection and dU, then subtract much larger
terms to recover the small neutrino source. The helper comparisons above do
not make those extraction operations accurate, and none of the seven
failures is closed or relabelled here. The separate parent local result is
recorded as 1190 passed, zero failed; this reviewer did not rerun that suite.

No v5 history was run, no Jacobian-wide certification is supplied, and the
v4 refined-history timeout is not reassessed. This is not a uniform precision
bound over all fields, near a vanishing acceleration or a branch boundary.
It does not validate an empirical fit, late-time behavior or a completed TOE.
Only reviewer-owned files in `independent_precision_force_review_v5` were
created. Parent source and all previous failure records remain unchanged.
