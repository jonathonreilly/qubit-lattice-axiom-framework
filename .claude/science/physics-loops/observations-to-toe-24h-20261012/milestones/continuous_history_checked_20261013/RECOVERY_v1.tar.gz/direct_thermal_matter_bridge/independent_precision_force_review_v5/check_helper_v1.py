#!/usr/bin/env python3
"""Independent raw-action reference for the actual v5 real u helper."""
import sys
sys.dont_write_bytecode=True
import datetime,hashlib,importlib.util,json
from pathlib import Path
import mpmath as mp
import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
mp.mp.dps=80
cv=lambda x:mp.mpf(float(x))
fmt=lambda x:mp.nstr(x,55)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def raw_reference(state,cfg,gas,rounded_q=None):
    # Convert exactly the binary inputs presented to the parent helper.
    a,b,s,nu=[cv(cfg[n]) for n in ['a','b','s','nu']]
    alpha=mp.sqrt(a)
    u,X,Y,pu,vx,vy=map(cv,state)
    scale_x=cv(cfg['xi'])*mp.exp(-mp.mpf(3)*cv(gas['NJ'])/2) if cfg['xi'] else mp.mpf(1)
    scale_y=cv(cfg['yi'])*mp.exp(-2*cv(gas['NJ']))
    field=[u,scale_x*X,scale_y*Y]
    p=[pu,scale_x*vx,scale_y*vy]
    dust=cv(cfg['rho_di'])*mp.exp(-3*cv(gas['NJ']))
    if rounded_q is not None:
        field=list(map(cv,rounded_q['phi']))
        p=list(map(cv,rounded_q['p']))
        dust=cv(rounded_q['rho_dust'])

    def original_action(phi):
        uu,xx,yy=phi
        A=mp.exp(alpha*uu)
        F=1+s*A*A
        F_u=2*alpha*s*A*A
        D=1+mp.mpf(2)/3*(1+b)*(xx*xx+yy*yy)
        # Weyl-reduced original kinetic action before the J/F² shortcut.
        K=[(1-3*a*s*A*A)/F+mp.mpf(3)/4*(F_u/F)**2,
           (1+s)*4*b/(9*F*D),(1+s)*b/(3*F*D)]
        V0=mp.mpf(3)/2+(b/2-alpha*uu+2*a*uu*uu/b)*xx*xx+b*yy*yy/3+nu*uu*uu/2
        V1=(b/2+alpha*b*uu+2*a*uu*uu/b)*xx*xx+b*yy*yy/3
        U=(1+s)*(V0+s*V1+mp.mpf(3)*s*A**4/2)/F**2
        return K,U,A/mp.sqrt(F)

    K,U,B=original_action(field)
    dK=[[mp.diff(lambda t:original_action(field[:i]+[t]+field[i+1:])[0][j],field[i])
         for j in range(3)] for i in range(3)]
    dU=mp.diff(lambda t:original_action([t,field[1],field[2]])[1],field[0])
    ab=mp.diff(lambda t:mp.log(original_action([t,field[1],field[2]])[2]),field[0])
    weight=(1+s)**2*B**4*cv(cfg['Rstar'])
    sigma=weight*(dust+cv(gas['rho_gas']))
    pressure=weight*cv(gas['P'])
    trace=weight*(dust+cv(gas['tau_gas']))
    Q=sum(K[i]*p[i]**2 for i in range(3))
    H2=2*(sigma+U)/(3-Q)
    h=-(sigma+pressure)/H2-Q
    # Lowered Euler-Lagrange momentum route; no closed-form Christoffels.
    metric_momentum=(sum(dK[j][0]*p[j]*p[0] for j in range(3))-
        sum(dK[0][j]*p[j]**2 for j in range(3))/2)
    acc=-(3+h)*p[0]-(metric_momentum+(dU+ab*trace)/H2)/K[0]
    E=mp.exp(2*alpha*field[0]);z=s*E;F=1+z;J=1+(1-3*a)*z
    proposed_du_ku=K[0]*2*alpha*z*((1-3*a)/J-2/F)
    proposed_connection=proposed_du_ku*p[0]**2/(2*K[0])+alpha*z*(K[1]*p[1]**2+K[2]*p[2]**2)/(F*K[0])
    return dict(acc=acc,connection=metric_momentum/K[0],proposed_connection=proposed_connection,
                derivative_metric=proposed_du_ku,differentiated_metric=dK[0][0],H2=H2,Q=Q,
                raw_trace=trace,phi=field,p=p,scale_x=scale_x,scale_y=scale_y)

def main():
    freeze=json.loads((HERE/'FREEZE_v1.json').read_text())
    for row in freeze['sources']:
        assert sha(Path(row['source']))==sha(HERE/row['recovery'])==row['sha256'],row['source']
    spec=importlib.util.spec_from_file_location('precision_review_v5',BASE/'check_thermal_matter_bridge_v5.py')
    target=importlib.util.module_from_spec(spec);spec.loader.exec_module(target)
    mp.mp.dps=80
    rows=[]
    for k in [.01,1e-5,1e-6]:
      for branch in ['split','equal']:
        cfg=target.configuration(dict(id='precision_check',k=k,branch=branch))
        for L in [0.,12.,18.,20.,22.,cfg['Lf']]:
          gas=target.gas(L,256)
          sy=cfg['yi']*np.exp(-2*gas['NJ'])
          matched_Y=np.sqrt(cfg['Rstar']*gas['rho_gas'])/sy
          states=[('matched',[0.,1.,matched_Y,0.,-1.5,-2*matched_Y]),
                  ('generic',[.003,.98,1.01,.002,-1.49,-2.01]),
                  ('signed',[.07,-.3,.5,-.008,.1,-.2])]
          for label,raw in states:
            state=np.asarray(raw)
            oracle=raw_reference(state,cfg,gas)
            reference=oracle['acc']
            actual34=target.precision_u_acceleration(L,state,cfg,256)
            actual50=target.precision_u_acceleration(L,state,cfg,256,digits=50)
            q=target.quantities(L,state,cfg,256)
            err=abs(cv(actual34)-reference)
            limit=max(mp.mpf('1e-28'),mp.mpf('4e-15')*abs(reference))
            relative=err/abs(reference) if reference else err
            reference_float=float(reference)
            ulp=abs(float(actual34)-reference_float)/abs(np.spacing(reference_float)) if reference_float else 0.
            connerr=abs(oracle['connection']-oracle['proposed_connection'])/max(1,abs(oracle['connection']))
            kuerr=abs(oracle['derivative_metric']-oracle['differentiated_metric'])/max(1,abs(oracle['differentiated_metric']))
            rounded=raw_reference(state,cfg,gas,rounded_q=q)
            row=dict(k=k,branch=branch,L=L,state_label=label,state=state.tolist(),
                actual34=actual34,actual50=actual50,reference80=fmt(reference),
                absolute_error=fmt(err),relative_error=fmt(relative),allowed_absolute_error=fmt(limit),
                ulp_distance=ulp,helper_pass=bool(err<=limit),default_equals_50=actual34==actual50,
                quantities_uses_helper=bool(q['acc'][0]==actual34),
                connection_scaled_residual=fmt(connerr),metric_derivative_scaled_residual=fmt(kuerr),
                connection_pass=bool(connerr<mp.mpf('1e-65') and kuerr<mp.mpf('1e-65')),
                reference80_at_rounded_physical_fields=fmt(rounded['acc']),
                rounded_physical_vs_scaled_relative=fmt(abs(rounded['acc']-reference)/abs(reference) if reference else abs(rounded['acc']-reference)))
            rows.append(row)
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),script_sha256=sha(Path(__file__)),
        scope='Actual v5 default34 u helper versus 80-digit raw action from exact-binary scaled inputs; no histories',
        rows=rows,counts=dict(points=len(rows),helper_passed=sum(r['helper_pass'] for r in rows),
            helper_failed=sum(not r['helper_pass'] for r in rows),connection_failed=sum(not r['connection_pass'] for r in rows),
            precision34_vs50_different=sum(not r['default_equals_50'] for r in rows),
            quantities_not_using_helper=sum(not r['quantities_uses_helper'] for r in rows)),
        maxima=dict(relative_helper_error=fmt(max(mp.mpf(r['relative_error']) for r in rows)),
            ulp_distance=max(r['ulp_distance'] for r in rows),
            connection_scaled_residual=fmt(max(mp.mpf(r['connection_scaled_residual']) for r in rows)),
            rounded_physical_vs_scaled_relative=fmt(max(mp.mpf(r['rounded_physical_vs_scaled_relative']) for r in rows))))
    (HERE/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['counts']));print(json.dumps(result['maxima']))
    for r in rows:
        if not r['helper_pass'] or not r['connection_pass']:
            print('FAIL',json.dumps(r))
    return int(result['counts']['helper_failed'] or result['counts']['connection_failed'] or result['counts']['quantities_not_using_helper'])

if __name__=='__main__':
    raise SystemExit(main())
