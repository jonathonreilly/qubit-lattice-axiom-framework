# Stable scalar-force review

The proposed `dUu` rearrangement is **exact**, but changing only that derivative
does **not** make all the original double-precision controls pass. The original
trace-control record remains **336 passed, 9 failed**. This reviewer modified
no parent source, reran no history and loosened no threshold.

## Exact algebra

With `alpha=sqrt(a)`, `E=exp(2alpha u)`, `z=sE`, `F=1+z`, write

    W=3/2+(B0+Lu+Qu²)x²+b(1+s)y²/3+nu u²/2+(3s/2)E²,
    B0=b(1+s)/2, L=alpha(sb-1), Q=2a(1+s)/b,
    U=(1+s)W/F².

Differentiating at fixed original constants gives
`U_u=(1+s)(F W_u-4alpha zW)/F³`. Its x, y and nu terms are precisely
those in the proposed expression. The remaining constant/vacuum terms are

    6alpha s F E² - 6alpha z - 6alpha z s E²
      = 6alpha s E(E-1)
      = 6alpha s E expm1(2alpha u).

Thus the proposed expression has no change of physical premise. SymPy's
exact symbolic difference is zero, using `dE/du=2alpha E`; it is not just
agreement at selected states. In particular, at u=0,

    U_u=-alpha[(1+sb)x²+(4sb/3)y²]/(1+s).

The `expm1` representation avoids subtracting constant/vacuum terms of order
one to obtain a much smaller derivative. It is also an analytic expression
for the complex continuation used for state derivatives wherever F is nonzero.

## Instantaneously matched identities

Let `M=Rstar rho_d`, `R=Rstar rho_gas`, `t=Rstar tau_gas`, and set
`u=p_u=0`, `x²=M`, `y²=R`, `p_x=-3x/2`, `p_y=-2y`. Then

    U=3/2+bM/2+bR/3,
    Qkin=b(M+4R/3)/D,
    sigma=M+R,
    2(sigma+U)=D(3-Qkin).

Hence H²=D. The u connection term is
`alpha s(1+s)b(M+4R/3)/(J0 D)`. The potential plus matter term divided by
`Kuu H²` is
`alpha(1+s)[t-sb(M+4R/3)]/(J0 D)`. Their sum gives exactly

    acc_u=-alpha(1+s)t/(J0 D).

Relative to ideal radiation, Raychaudhuri changes by `delta h=t/(3D)`.
At fixed initial fields the transverse potential and connection terms are
unchanged, so `delta acc_x=-delta h p_x=tx/(2D)` and
`delta acc_y=-delta h p_y=2ty/(3D)`. This proves the other two displayed
identities. These statements concern a selected instantaneous state, not an
invariant thermal trajectory.

Independent 80-digit evaluation from the earlier reviewer's full action
functions tested all four identities at all 24 original k/branch/clock
points. The largest relative residual among these 96 identity comparisons
was `9.54e-73`, below the predeclared `1e-55` threshold. That test constructs
an exactly matched state in high precision from the same rounded fluid
inputs; it does not assume the parent's rounded state is exactly matched.

## What the proposed replacement fixes

The following are the four original matched-u failures. The second numeric
column changes only `dUu` in reviewer-owned expressions; all other parent
double-precision quantities and the original `2e-8` threshold remain fixed.
The last column evaluates the full raw action at 80 digits using the same
rounded fields and primitive inputs, rather than merely recomputing the
final subtraction in high precision.

| State | Original relative error | Stable dUu only | Full high precision at rounded state |
|---|---:|---:|---:|
| split, k=1e-6, final L | 1.53836e-7 | 1.27143e-14 | 2.61002e-14 |
| equal, k=1e-6, L=18 | 2.03044e-7 | **3.80670e-8** | 6.79722e-10 |
| equal, k=1e-6, L=22 | 5.09439e-8 | **2.74823e-8** | 4.49142e-9 |
| equal, k=1e-6, final L | 2.94715e-7 | 1.65878e-8 | 5.72403e-9 |

The derivative rearrangement fixes two original failures, but two remain.
Across all 24 matched states, exactly those two still fail after this
derivative-only substitution. The other original passing states stay passing.

The old derivative error alone contributes approximately `-5.88e-10`,
`-4.83e-10`, `-2.06e-10`, and `+1.14e-9` to acc_u in the four rows above.
It is therefore a material source of the errors. It is not the only one.
For the equal branch at L=18 the two original acceleration contributions are
approximately `-617265.3308586732` and `+617265.3280360888`, leaving only
`-0.00282258`. At L=22 the cancellation is approximately `-596170.7257172278`
plus `+596170.7157933314`. Rounding of the connection, metric, Hubble factor,
derivative and their final subtraction can therefore matter at the unchanged
tolerance. The rounded matching errors are recorded explicitly in RESULTS.

No mathematical defect in the stated instantaneous identities is indicated
by these tests. Conversely, the exact derivative identity alone is not
sufficient evidence that the entire production RHS is accurate enough at
those points. Closing the remaining controls requires a checked treatment
of the complete force/connection cancellation or sufficient arithmetic
precision; using the ideal identity as a general off-orbit force would change
the model and is not justified.

## Generic extraction conditioning

The source-extraction operation first subtracts a large potential derivative
from a large quantity reconstructed from an already rounded acceleration,
then subtracts the dust contribution. At the failing k=1e-6 generic states,
the ratio of the first two operand magnitudes to the neutrino-source signal
is `2.70e12` to `8.90e12`. At k=1e-5, L=20 it is `3.27e10`. A target relative
accuracy of `2e-6` is not reliably attainable by subtracting those rounded
double-precision numbers.

After the derivative-only replacement, four of 24 generic extraction tests
still fail at their unchanged `2e-6` threshold. The k=1e-5 failure passes;
the four k=1e-6 failures do not, and the L=18 one becomes numerically worse
(`6.10e-4` instead of `1.02e-4`). Merely doing the final extraction at high
precision cannot recover bits already lost in the double-precision acc_u.
The complete independent high-precision calculation closes the source
extraction algebra to at most about `1.5e-69` at the original failed points.

That last algebraic closure consumes the already supplied positive fluid
trace. It diagnoses arithmetic conditioning; it does not independently
certify the physical neutrino distribution or a mutation of the parent
trace-production path. The original Jordan/Einstein trace checks and the
separate actual omission tests remain their own evidence. This report does
not turn any original failure into a pass.

## Evidence and scope

`check_stable_force_v1.py` contains the exact symbolic comparison and the
local arithmetic probes. `FREEZE_v1.json` binds 15 input files and their
recovery copies before execution, including the unchanged original
336/9 results. `EXECUTION_v1.json`, stdout/stderr and `RESULTS_v1.json`
record the single actual run. The final receipt verifies that these sources
and prior results stayed unchanged.

The parent bridge's local gas/configuration/quantities functions were read
and called to reproduce its exact selected inputs. No numerical history was
read or integrated. Independent scalar derivatives use the earlier checked
action functions from this reviewer's separate context; the prior checker
main was not rerun. This is a mathematical/conditioning review, not a complete
implementation review, accuracy certificate for the revised RHS, formal
audit or physical validation.
