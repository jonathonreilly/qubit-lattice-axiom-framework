#!/usr/bin/env python3
"""Local mathematical/conditioning review; does not mutate parent modules."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import datetime, hashlib, importlib.util, json
import numpy as np
import mpmath as mp
import sympy as sp

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
mp.mp.dps=80
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cv=lambda f:mp.mpf(float(f))
fmt=lambda x:mp.nstr(x,45)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def proposed_double(phi,cfg):
    u,x,y=phi;a,b,s,nu=[cfg[n] for n in ['a','b','s','nu']]
    alpha=np.sqrt(a);E=np.exp(2*alpha*u);z=s*E;F=1+z
    B0=b*(1+s)/2;L=alpha*(s*b-1);Q=2*a*(1+s)/b
    terms=[(F*(L+2*Q*u)-4*alpha*z*(B0+L*u+Q*u*u))*x*x,
           -4*alpha*z*b*(1+s)*y*y/3,
           nu*u*(F-2*alpha*z*u),6*alpha*s*E*np.expm1(2*alpha*u)]
    return (1+s)/F**3*sum(terms)

def main():
    freeze=json.loads((HERE/'FREEZE_v1.json').read_text())
    for row in freeze['sources']:
        assert sha(Path(row['source']))==sha(HERE/row['recovery'])==row['sha256'],row['source']
    # E is an independent symbol with dE/du=2 alpha E.
    u,x,y,al,b,s,nu,E=sp.symbols('u x y alpha b s nu E',positive=True)
    a=al**2;z=s*E;F=1+z;B0=b*(1+s)/2;L=al*(s*b-1);Q=2*a*(1+s)/b
    W=sp.Rational(3,2)+(B0+L*u+Q*u*u)*x*x+b*(1+s)*y*y/3+nu*u*u/2+sp.Rational(3,2)*s*E*E
    U=(1+s)*W/F**2
    derivative=sp.diff(U,u)+2*al*E*sp.diff(U,E)
    stable=(1+s)/F**3*((F*(L+2*Q*u)-4*al*z*(B0+L*u+Q*u*u))*x*x-
              4*al*z*b*(1+s)*y*y/3+nu*u*(F-2*al*z*u)+6*al*s*E*(E-1))
    symbolic_difference=sp.factor(derivative-stable)
    assert symbolic_difference==0
    zero_value=sp.factor(stable.subs({u:0,E:1}))
    zero_expected=-al*((1+s*b)*x*x+sp.Rational(4,3)*s*b*y*y)/(1+s)
    assert sp.factor(zero_value-zero_expected)==0
    parent=load('stable_review_target',BASE/'check_thermal_matter_bridge_v3.py')
    independent=load('stable_review_independent',BASE/'independent_math_review_fresh/check_math_v1.py')
    # Prior checker sets dps=60 on import; restore the current predeclared precision.
    mp.mp.dps=80
    original=json.loads((BASE/'trace_control_v1/RESULTS.json').read_text())
    by_name={item['name']:item for item in original['checks']}
    matched=[];generic=[]
    for k in [.01,1e-5,1e-6]:
      for branch in ['split','equal']:
        cfg=parent.configuration(dict(id='trace_control',k=k,branch=branch))
        pars=[cv(cfg[n]) for n in ['a','b','s','nu']]
        for Lval in [18.,20.,22.,cfg['Lf']]:
          gas=parent.gas(Lval,256);sx=cfg['xi']*np.exp(-1.5*gas['NJ']);sy=cfg['yi']*np.exp(-2*gas['NJ'])
          ym=np.sqrt(cfg['Rstar']*gas['rho_gas'])/sy
          tag=f'{branch}.{k}.{Lval}'
          for label,state in [('matched',np.array([0.,1.,ym,0.,-1.5,-2*ym])),
                              ('generic',np.array([.003,.98,1.01,.002,-1.49,-2.01]))]:
            q=parent.quantities(Lval,state,cfg,256)
            p,K,dk=q['p'],q['K'],q['dk'];connection=(p*(p@dk)-dk@(p*p)/2)/K
            stable_dU=proposed_double(q['phi'],cfg)
            stable_acc=-(3+q['h'])*p[0]-connection[0]-(stable_dU+q['ab']*q['trace'])/(K[0]*q['H2'])
            field=list(map(cv,q['phi']));velocity=list(map(cv,p));Rstar=cv(cfg['Rstar'])
            cb=independent.evaluate_action(field,pars)[2]['CB']
            rho=cv(q['rho_dust'])+cv(gas['rho_gas']);pressure=cv(gas['P'])
            # Independent scalar solver ordinarily forms tau=sigma-3P; supply a
            # consistent pressure for the independently accumulated positive trace.
            traceJ=cv(q['rho_dust'])+cv(gas['tau_gas'])
            trace_consistent_P=(rho-traceJ)/3
            precise=independent.equations(field,velocity,cb**2*Rstar*rho,cb**2*Rstar*trace_consistent_P,pars)
            exact_du=precise['dU'][0]
            dU_effect=-(cv(q['dU'][0])-exact_du)/(cv(K[0])*cv(q['H2']))
            stable_effect=-(cv(stable_dU)-exact_du)/(cv(K[0])*cv(q['H2']))
            row=dict(tag=tag,label=label,old_acc=float(q['acc'][0]),stable_dU_only_acc=float(stable_acc),
                     raw_action_acc_at_rounded_fields=fmt(precise['acc'][0]),
                     old_dU=float(q['dU'][0]),stable_dU=float(stable_dU),exact_dU=fmt(exact_du),
                     old_dU_error_acc_contribution=fmt(dU_effect),stable_dU_error_acc_contribution=fmt(stable_effect),
                     connection_acc=float(-connection[0]),potential_and_trace_acc=float(-(q['dU'][0]+q['ab']*q['trace'])/(K[0]*q['H2'])))
            if label=='matched':
                reference=by_name[tag+'.matched.acc.0'];expected=reference['expected'];tol=reference['tolerance']
                row.update(old_test_passed=reference['passed'],old_relative_error=reference['normalized_error'],
                           expected=expected,unchanged_tolerance=tol,
                           stable_relative_error=abs(stable_acc-expected)/abs(expected),
                           stable_passes_original_tolerance=bool(abs(stable_acc-expected)/abs(expected)<=tol),
                           high_precision_at_rounded_state_relative_error=fmt(abs(precise['acc'][0]-cv(expected))/abs(cv(expected))))
                # Construct an exact matched state from the same rounded fluid inputs.
                M=Rstar*cv(q['rho_dust']);Rg=Rstar*cv(gas['rho_gas']);t=Rstar*cv(gas['tau_gas'])
                xx,yy=mp.sqrt(M),mp.sqrt(Rg);pp=[mp.mpf(0),-3*xx/2,-2*yy]
                ideal=independent.equations([mp.mpf(0),xx,yy],pp,M+Rg,(Rg-t)/3,pars)
                aa,bb,ss,_=pars;D=1+2*(1+bb)*(M+Rg)/3;J0=1+(1-3*aa)*ss
                expected_exact=[-mp.sqrt(aa)*(1+ss)*t/(J0*D),xx*(mp.mpf(9)/4+t/(2*D)),yy*(4+2*t/(3*D))]
                residuals=[abs(ideal['H2']/D-1)]+[abs(ideal['acc'][i]-expected_exact[i])/abs(expected_exact[i]) for i in range(3)]
                row['exact_matched_identity_relative_residuals']=list(map(fmt,residuals))
                assert max(residuals)<mp.mpf('1e-55')
                row['actual_rounded_state_dust_matching_error']=fmt((field[1]**2-M)/M)
                row['actual_rounded_state_gas_matching_error']=fmt((field[2]**2-Rg)/Rg)
                matched.append(row)
            else:
                reference=by_name[tag+'.generic.full_acceleration_trace'];weight=q['CB']**2*cfg['Rstar']
                recovered=(-K[0]*q['H2']*(stable_acc+(3+q['h'])*p[0]+connection[0])-stable_dU)/q['ab']
                got=recovered-weight*(q['rho_dust']+gas['tau_e'])
                scale=reference['scale'];expected=reference['expected']
                # Isolate rounding in the published extraction itself using exact
                # arithmetic on exactly the same rounded q arrays and old acc.
                pk=list(map(cv,p));kk=list(map(cv,K));dkk=[[cv(v) for v in line] for line in dk]
                con0=(pk[0]*sum(pk[j]*dkk[j][0] for j in range(3))-
                      sum(dkk[0][j]*pk[j]**2 for j in range(3))/2)/kk[0]
                exact_recover=(-kk[0]*cv(q['H2'])*(cv(q['acc'][0])+(3+cv(q['h']))*pk[0]+con0)-cv(q['dU'][0]))/cv(q['ab'])
                exact_extracted=exact_recover-cv(weight)*(cv(q['rho_dust'])+cv(gas['tau_e']))
                # Complete exact-arithmetic extraction from independently computed
                # quantities, before rounding away the small source contribution.
                mpK,mph,mpH2=precise['K'],precise['h'],precise['H2']
                rec=(-mpK[0]*mpH2*(precise['acc'][0]+(3+mph)*velocity[0]+precise['connection'][0])-precise['dU'][0])/precise['alphaB']
                true_expected=cb**2*Rstar*traceJ
                exact_closure=abs(rec-true_expected)/abs(cb**2*Rstar*cv(gas['tau_nu']))
                row.update(old_test_passed=reference['passed'],old_extraction_relative_error=reference['normalized_error'],
                           unchanged_tolerance=reference['tolerance'],stable_extraction_relative_error=abs(got-expected)/scale,
                           stable_extraction_passes_original_tolerance=bool(abs(got-expected)/scale<=reference['tolerance']),
                           high_precision_extraction_of_rounded_acc_relative_error=fmt(abs(exact_extracted-cv(expected))/cv(scale)),
                           independent_high_precision_source_extraction_closure=fmt(exact_closure),
                           extraction_condition_estimate=float((abs(q['dU'][0])+abs(K[0]*q['H2']*(q['acc'][0]+(3+q['h'])*p[0]+connection[0])))/(abs(q['ab'])*scale)))
                assert exact_closure<mp.mpf('1e-55')
                generic.append(row)
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),script_sha256=sha(Path(__file__)),
        symbolic_difference=str(symbolic_difference),zero_u_derivative=str(zero_value),
        old_counts=original['counts'],matched=matched,generic=generic,
        counts=dict(matched=len(matched),generic=len(generic),
                    stable_matched_failed=sum(not r['stable_passes_original_tolerance'] for r in matched),
                    stable_generic_extraction_failed=sum(not r['stable_extraction_passes_original_tolerance'] for r in generic)),
        scope='Diagnostic replacement of dUu in reviewer-owned expressions only; no parent patch, no ODE or history run')
    (HERE/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['counts']))
    for row in matched:
        if not row['old_test_passed'] or not row['stable_passes_original_tolerance']:
            print('MATCHED',row['tag'],'old',row['old_relative_error'],'stable',row['stable_relative_error'],'mp rounded',row['high_precision_at_rounded_state_relative_error'])
    for row in generic:
        if not row['old_test_passed']:
            print('GENERIC',row['tag'],'old',row['old_extraction_relative_error'],'stable',row['stable_extraction_relative_error'],'condition',row['extraction_condition_estimate'])

if __name__=='__main__':
    main()
