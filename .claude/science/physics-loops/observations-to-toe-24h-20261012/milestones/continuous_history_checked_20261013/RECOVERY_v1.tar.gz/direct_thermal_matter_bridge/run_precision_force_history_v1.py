from pathlib import Path
import json,hashlib,datetime,time,importlib.util
p=Path(__file__).resolve().parent
out=p/'precision_force_history_v1'
d=json.loads((out/'FREEZE.json').read_text())
for x in d['inputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
spec=importlib.util.spec_from_file_location('bridge_stable',p/'check_thermal_matter_bridge_v5.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=m.run_case(d['case'],out)
(out/'EXECUTION.json').write_text(json.dumps(dict(started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,checks=m.CHECKS,inputs_unchanged=all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in d['inputs']),scientific_success=r['success']),indent=2)+'\n')
