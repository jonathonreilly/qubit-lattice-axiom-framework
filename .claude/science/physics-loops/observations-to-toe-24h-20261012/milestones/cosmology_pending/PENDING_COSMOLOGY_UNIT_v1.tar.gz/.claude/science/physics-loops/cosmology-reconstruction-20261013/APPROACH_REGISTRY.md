# Mathematical approaches

The actual work includes constrained expansion-square identity, ordered distance integrals and covariance transfer, inverse background equations and endpoint regularity, an added scalar-potential construction, covariant perturbation evolution and homogeneous variation. These are different scientific tasks, not automatically five attacks on each particular negative theorem. No N1 PASS is inferred from listing them.
