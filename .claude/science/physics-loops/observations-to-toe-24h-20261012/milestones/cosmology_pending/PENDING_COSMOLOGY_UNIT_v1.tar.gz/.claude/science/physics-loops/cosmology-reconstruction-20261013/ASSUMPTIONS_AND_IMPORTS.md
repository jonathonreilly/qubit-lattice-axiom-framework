# Explicit premises

Supplied positive metric/scalar action and universal conformal matter coupling; ideal flat fluids; known photon/clock/matter readout; processed Pantheon+ data and covariance; supplied small coupling interval and m=.3 comparison; constructed potential and chosen background; restricted local mass approximation and short-wave matter branch. No microscopic, primordial, quantum or vacuum-energy origin is derived. Full proofs and source ledgers are retained in the constituent recovery archive.
