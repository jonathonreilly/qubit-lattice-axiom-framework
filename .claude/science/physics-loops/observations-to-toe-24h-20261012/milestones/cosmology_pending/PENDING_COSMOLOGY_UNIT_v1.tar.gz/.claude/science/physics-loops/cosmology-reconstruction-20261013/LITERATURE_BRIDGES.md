# Primary inputs

Pantheon+ release c447f0fea703fcd0fff57de5000947b5ca81286b supplies processed distances and covariance. Williams/Turyshev/Boggs supplies an exposed historical drift summary; Reyes et al.1003.2185 supplies an exposed E_G summary with additional calibration and survey assumptions. Ma/Bertschinger and Amendola are equation context; the candidate equations are derived here. Exact source pins, read scopes, failures and external recovery paths are in the archive manifests and original ledgers.
