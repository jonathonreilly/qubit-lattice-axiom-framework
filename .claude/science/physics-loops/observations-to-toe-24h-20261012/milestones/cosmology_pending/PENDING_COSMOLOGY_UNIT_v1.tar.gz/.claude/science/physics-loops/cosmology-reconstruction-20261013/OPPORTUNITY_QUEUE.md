# Next useful science

1. Check unchanged potential against positive conserved radiation, then reconstruct only with explicit new premises.
2. Test nonzero scalar drift against finite-precision local constraints; exact zero is a stronger premise than observation.
3. Determine initial-state selection and primordial transfer before reusing the background as an observationally complete cosmology.
4. Complete genuine claim-specific no-go attack coverage before publication of this negative-boundary packet.
