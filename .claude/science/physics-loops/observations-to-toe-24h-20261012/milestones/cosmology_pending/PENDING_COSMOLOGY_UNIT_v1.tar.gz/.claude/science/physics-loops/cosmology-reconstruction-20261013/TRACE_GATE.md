# Trace gate

trace_class: frontier_discovery
reachability_to_target: unknown_frontier
artifact_role: frontier_probe
source_of_blocker_text: user_goal
next_trace_action: directly test radiation consistency and keep the pending negative-boundary packet visible

No registered framework lane is closed or promoted.
