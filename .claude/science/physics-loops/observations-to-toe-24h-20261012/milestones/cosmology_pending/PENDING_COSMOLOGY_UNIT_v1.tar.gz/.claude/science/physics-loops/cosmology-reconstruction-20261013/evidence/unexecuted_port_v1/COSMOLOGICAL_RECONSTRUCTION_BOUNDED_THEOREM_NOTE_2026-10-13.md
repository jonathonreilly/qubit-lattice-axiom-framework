# Observed distances constrain a metric-scalar model and its reconstructed potential

Date: 2026-10-13.
Claim type: bounded_theorem
Status: conditional-support
Audit authority remains the independent audit lane.

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
target_claim_id: null
target_blocker_text: null
source_of_blocker_text: user_goal
artifact_role: theorem
next_trace_action: "Test early-universe matter/radiation and initial-condition closure with explicit source and survey bridges."
reachability_to_target: unknown_frontier
conditional_surface_status: supplied metric/scalar action, ideal flat fluids, constructed potential and measurement bridges
hypothetical_axiom_status: new candidate premises explored; no registered framework axiom adopted
admitted_observation_status: processed Pantheon+ development transfer and exposed historical drift/lensing summaries
claim_type_reason: exact expansion and inverse-reconstruction theorems with finite coupled-response controls
proposal_allowed: false
proposal_allowed_reason: energy scale, initial conditions, matter and quantum completion remain unresolved
bare_retained_allowed: false
audit_required_before_effective_retained: true
```

Primary runner: [cosmological_reconstruction_2026_10_13.py](../scripts/cosmological_reconstruction_2026_10_13.py).
Paired [canonical cache](../logs/runner-cache/cosmological_reconstruction_2026_10_13.txt).

Observed redshift-distance information drives this reconstruction. First, a
massless positive metric-scalar model forces physical deceleration and a
monotone distance ratio. A frozen processed supernova comparison disagrees
with that mean ordering under explicit source-luminosity and optical bridges.
Second, an added potential and scalar direction reproduce an already exposed
comparison expansion with constant homogeneous gravitational strength. Third,
the coupled linear response and disturbed homogeneous evolution show what
this constructed background does, and does not, determine. Reproducing a
curve used for construction is not a new empirical test.

The common supplied action, with c=1 and signature(-+++), is

    S=[1/(16pi G_*)] integral sqrt(-g_*)
        [R_*-2K_AB partial phi^A.partial phi^B-4V(phi)] d^4x
        +S_m[A^2g_*,matter],
    A=exp(alpha_A phi^A),  G_*>0, K positive constant.

The first block sets V=0 with any finite number of fields. The subsequent
construction uses two canonical fields and the stated V. These are related
candidate classes with different assumptions. Matter couples universally to
the physical metric; its microscopic masses, thermodynamics and quantum
dynamics are not derived. This is known effective-theory architecture, not a
claim of a new fundamental action or unique observational reconstruction.
The constructions and controls were personally developed by the campaign lead.

The range 0<=a<=1/2499, a=alpha^T K^-1 alpha, is a supplied working interval
inherited from an exposed light-bending rectangle under weak, unscreened,
long-range matching assumptions. It is not a fresh posterior or a bound valid
for every potential and environment. The local matching G_N=G_*(1+a) is
examined here within an explicitly limited quadratic diagnostic. No shared
fit to the campaign's separate galaxy, clock, quantum or matter-charge routes
is asserted.

Original proofs, fixtures, code, outputs, failures and focused source checks
are recoverable through
`.claude/science/physics-loops/cosmology-reconstruction-20261013/`.
The proofs below retain block-local equation numbers. Their coordinates are
declared: n is physical log scale in the inverse problem, while N is Einstein
log scale in the perturbation problem. Equal N in disturbed solutions need
not mean equal physical redshift.

## A physical expansion bound and a distance-ratio observable

Direct parent derivation. Type: bounded_theorem. Actual surface status:
conditional-support. The next reconstruction asks what the already supplied
local metric/scalar candidate says about observed redshift-distance relations.
No cosmological constant, dark-energy density or supernova fit is silently
added. The completed comparison is reported below.

### Candidate and physical clock

Keep the positive constant scalar matrix K, constant alpha, Einstein action
and matter metric g_J=A^2 g_*, A=exp(zeta), zeta=alpha.phi. Write
a=alpha^T K^-1 alpha. Use c=1 in the cosmological derivation. Add spatially
flat homogeneous isotropic geometry, positive pressureless matter and
radiation, homogeneous scalars, no scalar potential, and H_*>0. Matter has
the universal metric coupling and the displayed ideal fluid equations of
state; constituent sensitivities and a late-time fluid closure are ignored
at this level. This is an explicit continuum/source assumption.

Let R_* denote the Einstein scale factor, and dot its proper-time derivative.
The physical scale factor and proper time are R_J=A R_* and dt_J=A dt_*.
The physical expansion rate is therefore

    H_J=(H_*+dot zeta)/A=H_*(1+y)/A,
    y=dot zeta/H_*.

The field and continuity equations from the same action are

    3H_*^2=8pi G_* (rho_m+rho_r)+K_AB dot phi^A dot phi^B,
    dot H_*=-4pi G_* (rho_m+4rho_r/3)-K_AB dot phi^A dot phi^B,
    ddot phi^A+3H_* dot phi^A=-4pi G_* (K^-1)^AB alpha_B rho_m,
    dot rho_m+3H_* rho_m=dot zeta rho_m,
    dot rho_r+4H_* rho_r=0.                                  (1)

The sign of the matter trace source follows from T_*=-rho_m and the earlier
Box phi=-4pi G_* K^-1 alpha T_* convention. The minus sign in the time
part of Box reverses it again in the acceleration equation. Radiation has
zero trace. The continuity equation also follows from m_*=A m_J and conserved
comoving particle number. These checks matter when converting frames.

Define nonnegative fractions

    Omega_m=8pi G_*rho_m/(3H_*^2),
    Omega_r=8pi G_*rho_r/(3H_*^2),
    Omega_s=dot phi^T K dot phi/(3H_*^2),
    Omega_m+Omega_r+Omega_s=1.

Then q_*=-1-dot H_*/H_*^2=Omega_m/2+Omega_r+2Omega_s, and Cauchy gives
y^2<=3a Omega_s. The homogeneous velocities orthogonal to the sourced
direction are retained in Omega_s; they are not discarded as unsourced.

Taking two physical-time derivatives of R_J gives

    (d^2 R_J/dt_J^2)/R_J
      = A^-2 [dot H_*+H_*^2+H_* dot zeta+ddot zeta].

Using ddot zeta=-3H_* dot zeta-4pi G_* a rho_m yields

    q_J = [q_*+2y+(3a/2)Omega_m]/(1+y)^2.                    (2)

Replacing q_J by q_* or omitting the trace term would compare observations
to a different model. For0<=a<1/3, Cauchy ensures |y|<1 and H_J>0 on every
permitted state. No scalar-dominated contracting physical branch is hidden
inside this stated domain.

### A quantitative bound, including the equality trajectory

For0<a<1/3, put

    q_b=(1+a)/[2(1-a)].

Substitute Omega_m=1-Omega_r-Omega_s into(2) and complete the square:

    (1+y)^2(q_J-q_b)
      = (1-3a)(y+a)^2/[2a(1-a)]
        +(3/2)(1-a)[Omega_s-y^2/(3a)]
        +(1-3a)Omega_r/2 >=0.                               (3)

Every coefficient and bracket is nonnegative. At a=0, alpha=0 and y=0,
so q_J=1/2+(3/2)Omega_s+Omega_r/2>=1/2 directly. Consequently the whole
supplied range0<=a<=1/2499 obeys q_J>=1/2, with the sharper q_b for known
nonzero a. This is an exact prediction of the stated homogeneous model, not
a global theorem about scalar theories, spatial curvature or other matter.

Equality at a>0 needs y=-a, Omega_s=a/3, Omega_r=0; all scalar velocity is
in the alpha direction. It is dynamically attainable, not just a minimizer
outside the field equations. Take N=ln R_*, x^A=dphi^A/dN. Equations(1) imply

    dx^A/dN=(q_*-2)x^A-(3/2)(K^-1)^AB alpha_B Omega_m,
    dOmega_r/dN=2(q_*-1)Omega_r,
    dln H_*/dN=-(1+q_*).

With x=-K^-1 alpha, Omega_s=a/3 and Omega_m=1-a/3, the right side of the
x equation is zero. Thus A proportional to R_*^-a and

    H_J proportional to R_J^[-(3-a)/(2(1-a))],
    R_J proportional to (t_J-t_origin)^[2(1-a)/(3-a)],
    q_J=q_b.                                                (4)

This supplies a constant-q equality curve. A full global attractor theorem
is not needed or asserted. The a=0 equality case is the ordinary flat dust
trajectory. Neither trajectory is fitted to supernova shape data here.

### A normalization-free necessary distance relation

Supply physical flat optical distances, transparency and distance duality.
For a constant comparison bound q_c>0, define

    B_qc(z)=[1-(1+z)^(-q_c)]/q_c
           =integral_0^z (1+u)^[-1-q_c] du.

For any smooth expanding history with q_J(z)>=q_c,

    dln H_J/dz=(1+q_J)/(1+z),
    j(z)=(1+z)^(1+q_c)/H_J(z)

is nonincreasing. The ratio

    T(z)=[integral_0^z du/H_J(u)]/B_qc(z)

is the weighted average of j over[0,z] with positive weight
w(u)=(1+u)^[-1-q_c]. Its derivative is

    T'(z)=w(z)[j(z)-T(z)]/B_qc(z)<=0.                        (5)

This proof requires the q bound on the whole interval from0 to the observed
redshift, not merely at today's epoch. It does not require knowing H0.

For a constant standardized absolute magnitude, the ideal corrected apparent
magnitude is an additive unknown intercept plus5log10 of luminosity distance.
Using the release's corrected expansion redshift zHD and heliocentric
prefactor zHEL gives the supplied observation map

    m_b_corr = M0+5log10[(1+zHEL) integral_0^zHD du/H_J(u)],
    r_i = m_b_corr_i-5log10[(1+zHEL_i) B_qc(zHD_i)].           (6)

Constants, units and H0 are absorbed in M0. Equation(5) says the ideal mean
r(zHD) is nonincreasing. Every high-redshift point therefore has mean at most
every lower-redshift point. The arithmetic mean of a high group minus that of
a disjoint lower group has predicted mean<=0. Nonnegative weights within
each group are essential; a generalized inverse-covariance mean can have
negative weights and would not inherit this order argument automatically.

The planned q_c=1/2 contrast applies to every a in the supplied weak-coupling
interval under the other model and observation assumptions. It is not limited
to the equality solution. For coefficient vector c with positive equal high
weights and negative equal low weights, sum c=0 removes the intercept, and
the supplied full covariance gives variance c^T C c. This is one processed-
data contrast. It is not independent of the separate transfer residuals.

### Calibration and a correlated reserved comparison

The fixed candidate curves are q=1/2, q=q_b at a=1/2499, and an explicitly
supplied flat-LambdaCDM benchmark with Omega_m=.3. For each, write its shape
prediction g_i=5log10[(1+zHEL_i) integral_0^zHD_i du/E(u)]. Fit only an
additive intercept using the frozen lower-redshift calibration subset L.
Set d_L=m_L-g_L, Q=C_LL^-1 and

    V_M=(1_L^T Q 1_L)^-1,
    Mhat=V_M 1_L^T Q d_L.

For the reserved higher-redshift subset T, retaining the full supplied
cross-covariance and using a flat intercept prior yields

    B=C_TL Q,   v=1_T-B 1_L,
    E[m_T | m_L]=g_T+B d_L+v Mhat,
    S=C_TT-B C_LT+V_M v v^T.                                (7)

Proof: at a fixed M, conditioning a joint Gaussian gives mean
g_T+M1_T+B(d_L-M1_L) and covariance C_TT-B C_LT. The calibration posterior
for M is Gaussian with mean Mhat and variance V_M. Integrating it adds
V_M v v^T. Thus the test data never recalibrate M or a cosmological shape.
The retained calibration residual may predict correlated systematics in the
test mean; suppressing it would discard the released correlations.

The resulting quadratic residual is a conditional processed-summary comparison.
The public data's nuisance training, bias corrections and systematic priors
were not newly blinded or refitted. Raw light curves, events and a new SALT2
calibration are not part of this calculation. Repeated light curves retain
their original correlations and are not counted as independent supernovae.

### Source-luminosity ambiguity is a physical assumption

Universal metric coupling does not by itself make stellar explosions standard
candles when gravitational strength evolves. A model for the standardized
absolute luminosity is therefore a new observational bridge. Under an added
term M(z)=M0+beta log10(1+z), the contrast changes by
beta c^T log10(1+zHD). Its free coefficient can absorb that single contrast.
The frozen beta sensitivity grid and the separately inferred cancelling beta
will make this degeneracy visible; neither estimates actual SN evolution.

The physical local coefficient is G_J=G_* A^2(1+a), so even a supplied
mass/luminosity scaling would need the candidate's full scalar history.
The earlier weak polytropes do not derive thermonuclear luminosities or the
SALT2 correction. No field theory is empirically excluded independently of
these source, geometry and processed-data assumptions.

The primary release README and SN-only likelihood were read in full at
c447f0fea703fcd0fff57de5000947b5ca81286b. The latter uses m_b_corr, zHD, zHEL,
the full covariance, and the luminosity prefactor in(6); this block's explicit
selection differs from its default zHD>.01 selection. The primary cosmology
paper's methodology sections were read, including the fiducial cosmology in
some redshift-error and systematic-response modeling. No raw-photometry
likelihood or independent modern data compilation is claimed.

Repository FRW kinematic and inverse-ratio notes were read as context. They
condition on a different supplied constant-density sector and leave its
normalization open. Their status claims, observational comparators and runners
are not adopted or repeated as premises of equations(1)-(7).

The completed frozen calculation and independent check are reported below;
the observation mismatch motivates the following explicit potential extension.

## Inverse potential and a two-field constant-G expansion trajectory

Direct parent derivation. Type: bounded_theorem. Actual surface status:
conditional-support. This is a candidate extension prompted by the preceding
massless model's distance-order mismatch. The expansion function used below is
the exposed fixed comparison curve, not a new extraction of H(z) from light
curves. The potential and its energy scale are constructed inputs, not a TOE.

### Action, source, and one-field inverse equation

Extend the Einstein action by -4V inside its R-2K(dphi)^2 normalization.
Thus the homogeneous equations, with K=I and positive dust, are

    3H_*^2=8pi G_*rho_*+dot phi^2+2V,
    dot H_*=-4pi G_*rho_*-dot phi^2,
    ddot phi+3H_*dot phi=-grad V-4pi G_*alpha rho_*.

The dot is Einstein proper time. Radiation is omitted in this late-time block.
Keep universal matter metric g_J=A^2g_*, A=exp(alpha.phi). Physical conserved
dust has rho_J=rho_J0 exp(-3n), n=ln R_J, and rho_*=A^4 rho_J. No constituent
sensitivity correction is included in this ideal dust closure.

For one scalar alpha=sqrt(a)>0 set zeta=ln A=sqrt(a)phi and p=dzeta/dn.
Write H_J=H0 E(n), h=dln E/dn. Then

    H_*=A H_J(1-p),       dot phi=A H_J p/sqrt(a).

Supply the particular comparison expansion and density normalization

    E^2=m exp(-3n)+1-m,   0<m<1,
    rho_J0=3H0^2 m/(8pi G_N),   G_N=G_*(1+a),   A(0)=1,
    D=4pi G_* A^2 rho_J/H_J^2
      =3m exp(2zeta-3n)/[2(1+a)E^2].

The G_N relation is a local long-range, weak-body matching premise. A massive
or screened scalar needs that premise checked, not silently reused. The
physical H curve alone does not fix rho_J0 or this source interpretation.

Taking the Einstein Raychaudhuri equation in n yields the inverse system

    zeta'=p,
    p'=(p+h)(1-p)+D+p^2/a
       =h+D+(1-h)p+(1/a-1)p^2.                         (1)

Recover the potential along that trajectory as

    V=(A^2 H_J^2/2)[3(1-p)^2-p^2/a-2D].              (2)

This parameterized expression defines a potential function only where the
field is invertible or repeated-field values and derivatives agree. Equations
(1)-(2) do not automatically grant a globally single-valued C2 potential.

Since D'=D(2p-3-2h), the derivative of(2) and(1) gives

    V_phi=-A^2 H_J^2 C/sqrt(a),
    C=p'+(h+3-2p)p+aD
     =h+(1+a)D+4p+(1/a-3)p^2.                        (3)

Equivalently V'=-(A^2 H_J^2/a)p C. Equation(3) is exactly the scalar
equation, so it is a useful consistency check, not an extra adjustable fit.

### A zero-drift endpoint does not admit a smooth one-field potential

For the displayed target h'=h(-3-2h). At a turning point p=0,
differentiating(3), without dividing by p, gives

    (V_phi)'=-A^2 H_J^2[h+(1-3a)D]/sqrt(a).          (4)

A C2 potential would instead give (V_phi)'=V_phiphi phi'=0 there.
Consequently h+(1-3a)D=0 is a necessary turning-point compatibility
condition. It is not sufficient for a global single-valued potential.

At the supplied present normalization zeta=0, h0=-(1+a)D0 and
D0=3m/[2(1+a)]. If p0=0, equations(1)-(4) give

    p'_0=-a D0,   V_phi(0)=0,
    (V_phi)'_0=4sqrt(a) H0^2 D0 >0.                 (5)

Thus no C2 one-field potential realizes this exact target through this
zero-drift endpoint under the density and local-normalization premises.
This is not an observational exclusion of zero drift or a general scalar
no-go: the exact continuous target, source normalization and one-field
restriction are supplied. With a=0 the derivation dividing by sqrt(a) is
inapplicable, and ordinary constant-potential dust is a regular limit.

The local past branch makes the obstruction explicit:

    phi=-(sqrt(a)D0/2)n^2+O(n^3),
    V_phi=4sqrt(a)H0^2D0 n+O(n^2),
    V=V0+(8H0^2/3)sqrt(2sqrt(a)D0)(-phi)^(3/2)
       +O(phi^2),
    V_phiphi/H0^2=-4/n+O(1),      n approaches0 from below. (6)

The potential can be C1 on this one-sided branch but has divergent curvature.
No numerical smoothing changes the exact endpoint identity.

### A second scalar supplies a constructive alternative

Now use two canonical scalars (u,chi), alpha=(sqrt(a),0), A=exp(sqrt(a)u).
Let V_Lambda>0 be a freely supplied energy scale. Set

    k=sqrt[3(1+a)/(2a)],
    S(chi)=V_Lambda/(1+a) sinh^2[k(chi-chi_c)],
    V(u,chi)=V_Lambda+(S(chi)/2)
                  [(u-sqrt(a))^2+eta u^2].         (7)

Here chi_c is a field-coordinate shift and eta is a dimensionless new theory
choice. For eta>=0, V is globally nonnegative and at least V_Lambda. The
canonical kinetic form is positive. The initial eta=0 form already has the
required background; its transverse stability must still be checked below.

There is an exact expanding trajectory with u=0, hence A=1, satisfying

    S(chi)=4pi G_*rho_J,
    dot chi=+sqrt(a S),
    3H^2=2(1+a)S+2V_Lambda.                         (8)

Take chi-chi_c<0 so S_chi<0. Since the last equation implies
S_chi=-3H sqrt(S/a), the chi equation gives

    ddot chi=-(3/2)H dot chi,
    ddot chi+3H dot chi=+(3/2)H dot chi=-V_chi.

Meanwhile V_u=-sqrt(a)S exactly cancels the dust source
4pi G_*sqrt(a)rho_J. This makes u=0 a solution of its full scalar equation,
not a imposed frozen-field approximation. Equation(8) obeys
dot S=-3HS, dust conservation, Friedmann, and

    dot H=-(1+a)S=-4pi G_N rho_J.

Therefore H^2=(8pi G_N/3)rho_J+2V_Lambda/3 exactly, while
G_J=G_*A^2(1+a)=G_N is constant along the homogeneous solution. The uncoupled
scalar carries positive kinetic energy even though alpha.dot phi=0. This
extra direction is precisely what the one-field endpoint argument omitted.

To realize the displayed m=.3 comparison, supply

    V_Lambda=(3/2)H0^2(1-m),
    t0=asinh sqrt[m/(1-m)],
    chi(n)=chi_c-(1/k)asinh[sqrt(m/(1-m))exp(-3n/2)]. (9)

The shift can be chosen so chi(0)=0. The magnitude of V_Lambda is not
predicted. The matter fraction is a background initial condition, not a
quantized constant. A continuum of a values remains; matching this
background does not identify the local coupling or select a unique theory.

### Preserve the first curvature failure and a declared repair

Put c=V_Lambda/(1+a)>0, so S=c sinh^2[k(chi-chi_c)],
S_chi^2=4k^2 S(c+S), and S_chichi=2k^2(c+2S). At u=0,

    Hess V = [[(1+eta)S, -sqrt(a)S_chi],
              [-sqrt(a)S_chi, (a/2)S_chichi]],

    det Hess V=a k^2 S[(eta-3)c+(2eta-2)S].         (10)

For eta=0, the determinant is negative whenever S>0. The first positive
potential has a negative-curvature direction; positive kinetic energy and
positive potential alone did not establish its curvature stability. Preserve
that failed candidate instead of reporting the repaired form as the first try.

The explicit choice eta=3 gives det=4a k^2 S^2>0, with positive diagonal
entries, for every S>0. This is a globally sufficient constant choice for
nonnegative curvature along the trajectory; for eta<3 the c term is negative
as S tends to zero, so no smaller constant works for the entire expanding
trajectory down to S=0. At S=0 the Hessian is positive semidefinite. This
coefficient does not affect the exact u=0 background or its matter source.
It is a supplied stabilization parameter fixed by this stated curvature
criterion, not a supernova measurement or a derived framework constant.

The theorem concerns the potential Hessian on the homogeneous trajectory.
It is not global convexity of(7) at arbitrary u, a full metric/dust perturbation
stability theorem, a growth-of-structure calculation, or a global attractor.
Ordinary gravitational density instabilities are not excluded by(10).

### Local force and drift have separate matching conditions

As an explicit local quadratic diagnostic, freeze the Hessian M^2=Hess V
and use a flat nearly static patch. This retains potential masses while
omitting curvature and background dust/metric responses of comparable
cosmological order; it is not a full match through order H^2 r^2. Holding
Einstein-frame particle number fixed would additionally contribute the
positive matrix S alpha alpha^T to the instantaneous scalar mass. Both
choices will be displayed; neither solves the full density/metric response.
For the eta=3 trajectory its eigenvalues mu_j^2 are nonnegative. With
orthonormal eigenvectors e_j, residues a_j=(alpha.e_j)^2>=0 and sum a_j=a.
The static Green response of the canonical scalar equations gives

    Phi_pair=-G_* m1 m2/r [1+sum_j a_j exp(-mu_j r)],
    F_pair=-G_* m1 m2/r^2
              [1+sum_j a_j(1+mu_j r)exp(-mu_j r)].  (11)

Units with c=1 are used; dimensional mu_j is an inverse length, or an inverse
time divided by c. The point-source Green normalization is the same as the
earlier massless scalar equation. These are weak zero-sensitivity static
sources, not a screened nonlinear solution or a complete compact-body match.

For x>=0, 0<=1-(1+x)exp(-x)<=x^2/2, by integrating t exp(-t)
from0 to x. Thus the relative force correction to the massless local limit
is bounded by sum a_j(mu_j r)^2/[2(1+a)]. This bounds only the scalar mass
correction in the supplied local diagnostic, not every cosmological correction.
Positive residues prevent a
hidden cancellation from being needed for this bound. At mu_j r<<1 the
earlier G_N and gamma relations apply to leading local order; they are
not exact identities at arbitrary separation for the massive extension.

The homogeneous coefficient has dln G_J/dt_J=2sqrt(a)du/dt_J=0. The
historical LLR Eq9 can therefore be compared with zero only under the added
local-background-tracking and weak-source approximation. Its correlation
with fitted tidal dissipation and shared data with the EP summary must remain
explicit. The earlier exact free massless Minkowski clock spectrum does not
automatically carry over to a massive field in this cosmological state.

This construction replaces the massless model's forced deceleration with a
specified potential and extra scalar direction. It reproduces an already
chosen expansion, leaving the vacuum-energy scale, matter origin, perturbations,
initial conditions, source luminosity, high-energy completion and uniqueness
unresolved. It is a concrete conditional reconstruction route to test further.

## What the reconstructed background predicts for matter and light

Direct parent derivation. Claim type: bounded_theorem. Actual surface status:
conditional-support. The two-field potential, m=.3 expansion, constant local
coupling and ideal weak dust are supplied as in direct_potential_reconstruction.
This note studies the existing candidate; it does not infer a unique potential
or quantum theory from an expansion curve.

### Linear equations with the density variable specified

Use Einstein proper time t, scale factor R, Fourier factor exp(i k.x), and

    ds_*^2=-(1+2P)dt^2+R^2(1-2P)dx^2.

Dust and homogeneous canonical scalars have no linear traceless spatial
stress, so the two Einstein scalar potentials agree. Set alpha=(sqrt(a),0),
v=dot phi=(0,dot chi), sigma=4pi G_*rho_*, and K=k/R>0. On the exact
background u=0, A=1, sigma=S, alpha.v=0. Define d as the contrast in Einstein
proper particle number, not Einstein rest-mass density. If f=delta phi and
zeta=alpha.f, then

    delta_*=d+zeta,     delta_J=d-3zeta,
    Psi_J=P+zeta,       Phi_J=P-zeta.                (1)

The first identity follows from rho_*=m A n_*; the second from n_J=A^-3 n_*.
Let Theta be the physical divergence of peculiar velocity. Number conservation
and the linear particle equation give

    dot d=-Theta+3dot P,
    dot Theta+2H Theta=K^2(P+zeta).                 (2)

The background mass-drift friction vanishes since alpha.v=0. Equivalently,
dot delta_J=-Theta+3dot Phi_J, with acceleration sourced by Psi_J.
This explicitly recovers physical-frame dust conservation.

Write g=grad V+alpha sigma and M=Hess V+sigma alpha alpha^T. Linearizing the
covariant scalar equation, including its lapse perturbation, gives

    ddot f+3H dot f+(K^2 I+M)f
        =4v dot P-2g P-alpha sigma d.              (3)

The added sigma alpha alpha^T follows from the perturbed rest mass at fixed
number; it is not an arbitrary choice of a mass matrix. The term -2gP includes
the perturbed lapse multiplying both the potential gradient and matter source.
In particular its u component vanishes on the exact background. Dropping the
matter part there would leave a spurious source.

The Einstein momentum and energy constraints respectively are

    dot P+H P=sigma Theta/K^2+v.f,                 (4)
    K^2 P+3H(dot P+HP)
        =-[sigma(d+zeta)+v.dot f-v^2P+grad V.f].  (5)

The cancellation sigma zeta+grad V.f=g.f is useful. These equations follow
with scalar energy density (v^2+2V)/(8pi G_*); no factor of two is absorbed
into a redefined field. They include scalar momentum and density responses,
unlike the earlier frozen local quadratic diagnostic.

### A closed system and its constraint propagation

Let N=ln R, h=dln H/dN, D=sigma/H^2, x=dot chi/H and Q=K^2/H^2. Primes in
this section denote N derivatives. Define w=f' and T=Theta/H. Along the
constructed background,

    h=-(1+a)D,  x=sqrt(aD),
    D'=(-3-2h)D, x'=(-3/2-h)x, Q'=-2(1+h)Q,
    g/H^2=(0,-3x/2),
    M/H^2=[[ (1+eta+a)D, 3sqrt(D) ],
            [ 3sqrt(D), 9/4+(3/2)(1+a)D ]].       (6)

The seven real first-order variables are (P,d,T,f_u,f_chi,w_u,w_chi):

    P'=-P+D T/Q+x f_chi,
    d'=-T+3P',
    T'=-(2+h)T+Q(P+sqrt(a)f_u),
    f'=w,
    w'=-(3+h)w-(Q I+M/H^2)f
        +4(0,x)P'-2(g/H^2)P-D alpha d.             (7)

The dimensionless energy constraint is

    C=(Q-x^2)P+D d+3D T/Q+x w_chi+(3/2)x f_chi=0. (8)

Differentiation using(6)-(7) gives the exact identity

    C'=(-3-2h)C.                                  (9)

Thus initially consistent data stay on the constraint surface; unscaled
H^2 C decays as R^-3 even for an off-constraint numerical control. This is a
useful algebraic cross-check of the coupled evolution. It does not test every
u-sector coefficient: C contains neither f_u nor w_u, so changing the u
acceleration leaves this identity unchanged. The direct covariant scalar
variation is needed to check that equation. This identity does not manufacture
an extra dynamical degree of freedom. The spatial trace equation is another
useful consistency check, also insensitive to a change of the u acceleration:

    P''+(4+h)P'+(3+2h)P
       =x w_chi-x^2P+(3/2)x f_chi+D sqrt(a) f_u.   (10)

It follows from(6)-(7). Equations(8)-(9) distinguish integration residuals
from physical modes. The proof and implementation concern k>0; the exactly
homogeneous problem is handled separately, not by dividing by Q=0.

### Short-wavelength matter response and an optical discriminator

For Q>>1, choose the slowly varying matter solution with time derivatives of
order H and no independently large homogeneous scalar waves. On a bounded
N interval with fixed candidate coefficients, (3) and the constraints give

    f_u=-sqrt(a)D d/Q+O(Q^-2 d),
    f_chi=O(Q^-2 d),
    P=-D d/Q+O(Q^-2 d),                            (11)

where constants in the remainder may depend on the fixed coupling and the
chosen interval. Arbitrary free scalar-wave initial data need not obey this
closure; short wavelength alone is insufficient.

Consequently physical acceleration and curvature potentials are

    Psi_J=-(1+a)D d/Q+O(Q^-2 d),
    Phi_J=-(1-a)D d/Q+O(Q^-2 d),
    (Phi_J+Psi_J)/2=P.                             (12)

Since G_N=G_*(1+a), physical dust growth at leading order obeys

    d''+(2+h)d'-(1+a)D d=0,
    (1+a)D=(3/2)Omega_m(N),
    Omega_m(N)=m exp(-3N)/[m exp(-3N)+1-m].         (13)

This is the same growing-mode equation as the chosen flat dust-plus-constant
GR benchmark. Matching the background did not erase every gravitational
signature: the lensing strength in units of G_N is Sigma=1/(1+a), whereas
the acceleration strength is mu=1. The leading slip is (1-a)/(1+a), consistent
with the earlier local optical relation under its separate matching premises.
These are asymptotic response coefficients, not exact finite-k identities.

Define f_g=dln D_g/dln R for the regular growing solution of(13). With the
standard linear, scale-independent galaxy-tracing, velocity and projected
lensing bridges, the theoretical lensing/velocity ratio is

    E_G(z)=m/[(1+a)f_g(z)]                         (14)

to this leading short-wavelength order. One way to obtain it is to divide
-k^2(Phi_J+Psi_J) by 3H0^2 R^-1 f_g delta_J; delta_J=d+O(Q^-1 d).
Bias and amplitude cancellation additionally requires the same tracer and
correlated density mode in the lensing and velocity measurements. The observed
annular/projected statistic has a different operational definition; equation
(14) is its prediction only under the stated bridges and corrections.

For a=1/2499, the ratio to the same-m GR prediction is 2499/2500, a decrease
of .04 percent. This coupling was fixed in earlier working constraints, not
chosen using an E_G measurement. Such a small leading difference does not
by itself predict a detectable discrepancy in a finite survey.

### Homogeneous initial conditions and the future flat direction

The previous background integrations started exactly on the constructed
trajectory. They do not show unique attraction to it. The full potential has
a de Sitter family

    chi=chi_c, u=arbitrary constant, dot phi=0, sigma=0,
    H_*^2=2V_Lambda/3.                             (15)

At its u=0 member, the Hessian eigenvalues are 0 and (9/4)H_*^2. Linear
homogeneous scalar perturbations restricted to delta sigma=0 at this limiting
vacuum satisfy

    delta u=C1+C2 exp(-3H_*t),
    delta chi=(C3+C4 t)exp(-3H_*t/2).              (16)

If dust perturbations are admitted at the exact vacuum boundary,
delta sigma=delta sigma_0 exp(-3H_*t) additionally drives the u equation.
Its particular solution adds

    +sqrt(a)delta sigma_0 t exp(-3H_*t)/(3H_*)

to delta u. Direct substitution into
ddot(delta u)+3H_*dot(delta u)=-sqrt(a)delta sigma verifies the sign.
This decaying resonant term leaves the neutral displacement intact.

There is a neutral u displacement; the isolated point u=0 is not an
asymptotically attracting equilibrium among the full vacuum family. This
does not prove that every finite-dust perturbation has a large late-time
offset or that the background is catastrophically unstable. At each constant
u, the physical Hubble scale is H_*/A and the weak-body G_J is G_*A^2(1+a).
Thus the family cannot be identified with a single physical matter-calibrated
solution merely by ignoring A. Initial-condition selection remains an input.

For actual finite-time homogeneous controls, use state Y=(u,chi,v_u,v_chi,l),
where l=ln sigma, H=sqrt[(2sigma+v^2+2V)/3]. Its full nonlinear equations in
Einstein N are

    phi'=v/H,
    v'=-3v-(grad V+alpha sigma)/H,
    l'=-3+alpha.v/H.                               (17)

At arbitrary Y, the exact first variation uses

    delta H/H=[sigma delta l+v.delta v+grad V.delta phi]/(3H^2),
    delta(phi')=delta v/H-(v/H)(delta H/H),
    delta(v')=-3delta v-(Hess V delta phi+alpha sigma delta l)/H
                       +[(grad V+alpha sigma)/H](delta H/H),
    delta(l')=alpha.delta(phi').                   (18)

This includes the response of the Friedmann-determined Hubble rate. Comparing
it with symmetric nonlinear perturbations checks initial-condition sensitivity
without silently freezing H or the coupled field. Any numeric gain or drift
is tied to its chosen interval, normalization and perturbation fixture; it is
not a prior probability, full nonlinear stability theorem or empirical bound.
The logarithmic density coordinate covers sigma>0 and does not include the
exact vacuum boundary. The finite-time histories are compared at fixed
Einstein N, not automatically at equal physical redshift N_J=N+sqrt(a)u.

The principal scalar kinetic and gradient matrices remain positive identity
matrices and tensor waves retain the Einstein light cone. This rules out a
wrong-sign scalar kinetic or high-frequency scalar gradient term in this
specified classical action. It does not rule out dust gravitational growth,
long-wavelength coupled instabilities, isocurvature histories, or shortcomings
of the matter approximation. CMB initial conditions, radiation, nonlinear
structure, galaxy selection and a quantum origin of fluctuations remain open.

## Expansion reconstruction: executed result and boundary

Direct parent personally derived and executed the calculation. The first frozen
execution passes6,120 controls. The complete independent review has been read and its source identities checked. The full
source, fixtures, logs and results are preserved in evidence_v1; the original
numeric release is recoverable byte for byte from data/*.gz.

For the supplied flat expanding massless scalar/Einstein candidate with positive
dust/radiation and constant positive kinetic form, the completed-square identity
gives q_J>=(1+a)/[2(1-a)] for0<a<1/3, with q_J>=1/2 at a=0. The equality
trajectory solves the full homogeneous equations. The full weak-coupling range
therefore implies a nonincreasing distance ratio to the q=.5 curve. This includes
unsourced homogeneous scalar velocity directions. It is a conditional theorem,
not a general exclusion of scalar gravity, curvature, evolving sources or a TOE.

Controls cover5,775 constrained states, six two-field evolution fixtures at two
ODE refinements,54 physical scale/proper-time derivative sites per refinement,
exact symbolic identities, analytic distance quadratures and monotonic ratios.
Maximum Richardson physical-frame deceleration error is1.54e-9; maximum state
refinement difference6.67e-16. These are observed numerical discrepancies,
not rigorous error bounds. Two explicit false-frame formulas are rejected.

The processed Pantheon+ release contains1,701 light-curve rows. The frozen cut
selects1,358:405 calibration rows and953 reserved transfer rows. Correlated
repeat rows remain. Raw CID uniqueness is separately reported and is not claimed
to count physical supernovae. Raw covariance asymmetry3e-8 is below the frozen
precision threshold; analysis explicitly uses(C+C.T)/2. Cholesky succeeds with
no repair or jitter. The primary likelihood redshift prefactor is retained.

| Fixed expansion shape | Calibration chi-square /404 | Conditional transfer chi-square /953 |
| --- | ---: | ---: |
| q=.5 | 382.0851 | 1468.7771 |
| weak scalar equality, a=1/2499 | 382.0906 | 1469.3813 |
| supplied flat LambdaCDM, Omega_m=.3 | 373.7358 | 834.1212 |

Only the intercept is fitted on the low-redshift calibration subset. Test means
and covariances retain released cross-correlations and calibration-intercept
uncertainty. A separately labelled full-profile calculation verifies the exact
quadratic decomposition algebra; its intercept is not used for prediction.
The benchmark is a supplied comparison curve, not a derivation of dark energy.

The fixed normalization-free class contrast uses469 high-redshift rows versus
405 low rows. Its mean must be<=0 under the theorem plus observation bridges.
The observed contrast is+0.3085345mag with0.0237980mag from the full covariance,
a standardized contrast12.9647. This is a processed-summary discrepancy under
explicit assumptions, not a raw-experiment significance or a globally blind test.
It overlaps the transfer comparison and must not be combined as independent.

The frozen luminosity-evolution sensitivity beta=0,.1,.3,.5 in
M(z)=M0+beta log10(1+z) gives standardized contrasts12.9647,12.3344,11.0739,
9.8133. Freely calibrating beta=2.056979 removes this one contrast by construction.
That number is neither an independent test nor a measured stellar-evolution law.
Universal metric coupling does not derive constant standardized supernova
luminosity when G varies. Raw photometry, SALT2 training, host/selection/bias
corrections and fiducial-model effects in the released covariance are supplied.

Observation-driven consequence: the massless flat dust/radiation candidate
cannot reproduce this distance ordering while all stated measurement bridges
are retained. A next reconstruction must change a declared physical premise,
such as a potential/negative-pressure sector, curvature, fluid closure or source
luminosity. No unique choice is established by these magnitudes. The potential block above
derives what an allowed potential would have to satisfy while preserving
positive kinetic energy and the previously constrained local coupling.

## Checked potential reconstruction

The parent personally derived the one-field endpoint obstruction and the
two-field construction. The complete mathematical and numerical independent
reports have been read. Their exact source and evidence identities were
verified in PARENT_MATH_REVIEW_RECEIPT_v1.json,
PARENT_NUMERICAL_REVIEW_RECEIPT_v1.json and PARENT_AFFECTED_V2_RECEIPT.json.
This is a checked conditional construction, not a formal audit or a TOE.

For the supplied flat dust-plus-constant expansion and exactly zero present
coupling drift, the one-field C2 endpoint is incompatible with its required
gradient derivative. The theorem does not exclude nonzero drift, a different
background or matter normalization, or other one-field theories. The two-field
potential supplies the same expansion with constant homogeneous G. Its eta=0
bare Hessian is indefinite; the explicitly supplied eta=3 has positive bare
Hessian eigenvalues along every finite point of that exact trajectory. This
does not establish full coupled perturbation stability or an attractor.

The original parent runner passed 1,494 controls. The independent numerical
calculation passed 6,926 checks plus 59 lineage checks, using high-precision
endpoint series, analytic matrix projectors and distinct evolution variables.
The mathematical check separately tested the proof and its force bounds.
The independent report identifies cancellation in the smallest one-field
gradient row: a=1e-6, m=.4, n=-1e-4 has relative error about6.61e-7 against
the high-precision calculation. Printed digits beyond this are not precision
claims. The sign, cusp scaling and analytical obstruction are unchanged.

One assertion blind spot was found and repaired. An altered original runner
could set20 tiny nonzero force deficits to zero and still pass all1,494 checks.
The actual original deficits were correct; their absolute-tolerance upper
bound did not sufficiently test small nonzero values. Version2 adds36 relative
positive lower bounds from the integral identity for1-(1+x)exp(-x). It changes
no prediction expression or original tolerance. All1,530 checks pass, all six
science sections and all1,494 original check records remain exactly identical.
The same zero-deficit alteration now fails. The same numerical reviewer
confirmed this affected change with142 checks; its initial stderr-format
matcher failure and subsequent evidence-only correction are preserved.

The force rows concern the specified local flat quadratic closure, including
the stated fixed-number mass correction where chosen. They do not include the
complete cosmological response at order H^2 r^2. Historical lunar-ranging
drift information was exposed before this construction and is a conditional
summary comparison with a local-tracking premise. Neither it nor an expansion
curve determines the vacuum-energy scale, eta, initial conditions, a unique
potential, real material charges or a quantum completion. The perturbation block establishes its equations and controls separately.

## Perturbation response and disturbed initial data: first execution

The parent personally derived and implemented the coupled equations. The
first complete frozen run passes648 checks. Two prior symbolic derivation
diagnostics are separately preserved; no numerical tolerance or fixture was
changed after this run. Its equations evolve the two scalar perturbations,
their velocities, dust number and velocity contrasts, and the metric potential.

The exact symbolic constraint propagation and spatial trace agree. All16
linear basis fixtures (two weak couplings, two eta choices, four wave numbers)
were integrated at two resolutions with six independent constraint-consistent
initial columns. Across160 stored basis constraint checks, the largest scaled
residual is9.490557145539493e-14. All refinement checks pass; the largest
difference is.09940849943410422 of its prefrozen allowed error. These arbitrary
response vectors are not primordial initial conditions or observed spectra.
Eta=0 is retained even though its bare Hessian failed in the preceding block.

Sixteen slowly varying matter-seed fixtures include a separate unexcited-field
GR control and the extra mathematical coupling a=.01. At a=1/2499 and
k/H0=1000, the endpoint coefficients are mu=.9999984619897343,
Sigma=.999598461869058 and gamma=.9991999985282369. Their predicted limiting
values are1,.9996,.9992. Finite-wave-number/gauge terms also appear in the GR
control: its mu and Sigma at the same wave number are.9999984616135558.
Thus the small common finite-scale shift must not be misidentified as a new
gravity effect. The leading matter growth is the supplied GR comparison;
the lensing coefficient retains the separate factor1/(1+a).

The regular growing-mode integral and independent parent ODE agree. For the
fixed m=.3 at z=.32, f_g=.6799577881129883. The corresponding leading E_G
values are.44120385889329516 for GR,.4412034176898775 for a=1e-6, and
.44102737734973785 for a=1/2499. Against the exposed historical submitted
primary-paper summary .392+/-.065, the last standardized residual is.75427.
The candidate-minus-same-m-GR difference is only-.00017648154355731638.
This summary does not discriminate the supplied small coupling. Its extra
approximately5 percent lensing calibration uncertainty is displayed separately,
not silently combined. Geometry, projections, scale-dependent bias and
simulation corrections have not been recomputed for the candidate. These
numbers therefore remain a conditional summary diagnostic, not a new raw
likelihood or an empirical validation of the theory.

For homogeneous response, four backgrounds, five axes and two perturbation
sizes give40 symmetric pairs, each with two signs and two integration settings
(160 nonlinear runs), plus four full variational integrations. The analytic
Jacobian agrees with complex-step derivatives. The largest scaled central-
difference/variational discrepancy is1.171740446593531e-6, below the frozen
.005 comparison threshold; the largest nonlinear refinement difference is
9.947598300641403e-14 in the stated initial-coordinate scales.

The vacuum proof has a neutral u mode. The finite-dust calculations illustrate
that limit. At a=1/2499,eta=3, initial u displacements +/- .001sqrt(a) at
N=-ln2.5 lead to u/sqrt(a) approximately+.0002710910 and-.0002725616 at
N=6. They have damped but have not returned to zero. For eta=0 the analogous
numbers are+.0011427495 and-.0011422647. These gains depend on the chosen
coordinates, interval and initial direction. They are not universal growth
rates, probabilities or observational constraints. The limiting vacuum family,
rather than these finite numeric rows alone, establishes that u=0 is not a
uniquely attracting equilibrium among all vacuum members.

The candidate supplies positive scalar kinetic/gradient terms, an exact
background, a consistent linear initial-value system and an asymptotic optical
discriminator. It does not yet supply realistic primordial fluctuations,
radiation/baryonic transfer, nonlinear structure, raw lensing reconstruction,
global dynamical stability, an initial-condition selection law, a vacuum-energy
scale or a quantum completion. Focused independent checks remain pending.

## Reproduction, observation roles and open obligations

The Pantheon+ arrays are pinned at release
c447f0fea703fcd0fff57de5000947b5ca81286b. The exact compressed data, their raw
hashes and the original selection/fixture files are declared runtime inputs.
The primary source is the
[release and likelihood](https://github.com/PantheonPlusSH0ES/DataRelease/tree/c447f0fea703fcd0fff57de5000947b5ca81286b/Pantheon%2B_Data/4_DISTANCES_AND_COVAR).
The published acceleration interpretation was exposed before development.
An intercept calibrated on405 rows and953 reserved transfer rows do not
make those processed data a blind test or remove their standardization,
selection and fiducial-covariance assumptions. Noisy realizations are not
logically prohibited by a model-mean inequality.

The potential reproduces the previously supplied m=.3 curve by design.
Its background distance score is therefore the same benchmark score already
reported above. It supplies no additional empirical success. The historical
drift row comes from
[Williams, Turyshev and Boggs](https://arxiv.org/abs/gr-qc/0411113);
its quoted correlation and local-tracking premise are preserved. The E_G
row comes from the
[Reyes et al. submitted primary paper](https://arxiv.org/abs/1003.2185).
That paper's own matter fraction .2565 differs from this supplied .3
benchmark; its extra lensing-calibration scale, fiducial geometry, tracer,
projection and simulation corrections were not reprocessed here. These are
exposed compressed-summary diagnostics, not independent empirical validation.

The local positive-residue force has an additional relative check. Put
x_j=mu_j r>=0 and U=sum a_j x_j^2/[2(1+a)]. Then

    deficit=sum a_j x_j^2 integral_0^1 t exp(-x_j t)dt/(1+a),
    exp[-max x_j] U <= deficit <= U.

Bounding the positive exponential in the integral proves this directly.
The relative lower bound exposes a deliberately zeroed tiny force correction
that the original upper-bound-only control missed. It concerns the stated
local mass effect, not a complete correction at cosmological order H^2 r^2.

Every original scientific function is carried into one canonical runner
under a block prefix. Reversing that namespace change recovers its exact
abstract syntax tree. Fixtures and primary arrays retain their exact bytes.
The wrapper exposes complete results with --json or exclusive --output-json
and never rewrites historical output. Its family counts organize controls;
they do not count independent observed predictions. Canonical reproduction,
source mutations and focused port checking have their own actual receipts.
Unfinished checks are not certified by this description.

The expansion has6,692 independent controls and63 lineage checks. The
potential numerical check used high-precision endpoint series, analytic
spectral projectors and distinct evolution variables:6,926 controls plus59
lineage checks, followed by the same reviewer's142-check confirmation of its
tiny-force assertion repair. The perturbation proof check used proper-time
covariant variation,45 exact identities including25 Jacobian entries,
24 complex-step Jacobians and a hypergeometric growing-mode route.
The complete reports, original failures and affected corrections remain
recoverable. Independent numerical perturbation and final canonical-source
checks have separate receipts and scopes.

No formal audit status is claimed. The connected result comprises conditional
constraints, a constructed potential and computable responses. Vacuum-energy
scale, initial-condition and primordial-mode selection, radiation era,
thermonuclear source calibration, raw survey likelihood, nonlinear structure,
realistic material sensitivities and quantum/high-energy completion remain
unresolved. Background reconstruction has not identified a unique TOE.
