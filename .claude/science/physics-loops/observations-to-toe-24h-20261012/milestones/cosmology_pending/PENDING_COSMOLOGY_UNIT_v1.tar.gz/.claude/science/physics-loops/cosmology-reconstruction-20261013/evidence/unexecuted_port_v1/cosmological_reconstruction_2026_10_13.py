#!/usr/bin/env python3
"""Conditional observations-to-expansion reconstruction; no empirical acceptance."""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
import argparse, gzip, hashlib, io, json, math, platform, sys
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.linalg import cho_factor, cho_solve, expm
import sympy as sp
import sympy as sy
ROOT=Path(__file__).resolve().parents[1]
AUDIT_TIMEOUT_SEC=180
AUDIT_INPUT_PATHS=('docs/COSMOLOGICAL_RECONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/co/NUMERICAL_FIXTURES.json', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/co/PRIMARY_DATA.json', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/co/data/Pantheon+SH0ES.dat.gz', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/co/data/Pantheon+SH0ES_STAT+SYS.cov.gz', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/pv/NUMERICAL_FIXTURES.json', '.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/pe/NUMERICAL_FIXTURES.json')
CO_ROOT=ROOT/'.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/co'
CO_FIX=json.loads((CO_ROOT/'NUMERICAL_FIXTURES.json').read_text())
CO_CHECKS=[]
PV_ROOT=ROOT/'.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/pv'
PV_FIX=json.loads((PV_ROOT/'NUMERICAL_FIXTURES.json').read_text())
PV_CHECKS=[]
PE_ROOT=ROOT/'.claude/science/physics-loops/cosmology-reconstruction-20261013/inputs/pe'
PE_FIX=json.loads((PE_ROOT/'NUMERICAL_FIXTURES.json').read_text())
PE_CHECKS=[]


def co_check(name, condition, **evidence):
    ok = bool(condition)
    CO_CHECKS.append({'name': name, 'pass': ok, **evidence})
    assert ok, (name, evidence)

def co_sha(data):
    return hashlib.sha256(data).hexdigest()

def co_qb(a):
    return (1 + a) / (2 * (1 - a))

def co_bq(z, q):
    return -np.expm1(-q * np.log1p(z)) / q

def co_q_physical(a, os, ore, y):
    om = 1 - os - ore
    qe = om / 2 + ore + 2 * os
    return (qe + 2 * y + 1.5 * a * om) / (1 + y) ** 2

def co_square_identity_and_grid(f):
    a, y, os, ore = sp.symbols('a y os ore', real=True)
    om = 1 - os - ore
    qe = om / 2 + ore + 2 * os
    lhs = qe + 2 * y + 3 * a * om / 2 - (1 + y) ** 2 * (1 + a) / (2 * (1 - a))
    rhs = (1 - 3 * a) * (y + a) ** 2 / (2 * a * (1 - a)) + sp.Rational(3, 2) * (1 - a) * (os - y ** 2 / (3 * a)) + (1 - 3 * a) * ore / 2
    co_check('symbolic_square_identity', sp.factor(lhs - rhs) == 0)
    xe, ae = sp.symbols('xe ae', positive=True)
    fixed_rhs = (sp.Rational(1, 2) + ae / 2 - 2) * -xe - sp.Rational(3, 2) * xe * (1 - ae / 3)
    co_check('symbolic_equality_trajectory', sp.expand(fixed_rhs) == 0)
    rows = []
    d = f['simplex_denominator']
    for av in f['couplings']:
        for si in range(d + 1):
            for ri in range(d + 1 - si):
                sv, rv = (si / d, ri / d)
                for ti, t in enumerate(f['projection_fractions']):
                    yv = t * math.sqrt(3 * av * sv)
                    qj = co_q_physical(av, sv, rv, yv)
                    residual = (1 + yv) ** 2 * (qj - co_qb(av))
                    if av:
                        squares = (1 - 3 * av) * (yv + av) ** 2 / (2 * av * (1 - av)) + 1.5 * (1 - av) * (sv - yv ** 2 / (3 * av)) + (1 - 3 * av) * rv / 2
                    else:
                        squares = 1.5 * sv + rv / 2
                    name = f'simplex_a{av}_s{si}_r{ri}_t{ti}'
                    co_check(name, qj >= co_qb(av) - f['identity_atol'] and abs(residual - squares) < f['identity_atol'] and (1 + yv > 0), q_J=qj, q_bound=co_qb(av), square_error=residual - squares)
                    rows.append([av, sv, rv, t, yv, qj, residual, squares])
    return {'columns': ['a', 'Omega_s', 'Omega_r', 'projection_fraction', 'y', 'q_J', 'bound_residual', 'squares'], 'rows': rows, 'row_count': len(rows)}

def co_history(fixture, max_step, f):
    av = fixture['a']
    alpha = np.array([math.sqrt(av), 0.0])
    t = fixture['projection']
    x = math.sqrt(3 * fixture['omega_s']) * np.array([t, math.sqrt(1 - t * t)])
    initial = np.r_[np.zeros(2), x, fixture['omega_r'], 0.0, 0.0]

    def fun(n, state):
        phi, vel, rad = (state[:2], state[2:4], state[4])
        os = np.dot(vel, vel) / 3
        om = 1 - os - rad
        qe = om / 2 + rad + 2 * os
        return np.r_[vel, (qe - 2) * vel - 1.5 * alpha * om, 2 * (qe - 1) * rad, -(1 + qe), math.exp(np.dot(alpha, phi) - state[5])]
    endpoints = f['evolution_interval_N']
    options = dict(method=f['ode_method'], rtol=f['ode_rtol'], atol=f['ode_atol'], max_step=max_step, dense_output=True)
    sols = [solve_ivp(fun, (0, end), initial, **options) for end in endpoints]
    co_check(f'ode_success_{fixture['id']}_{max_step}', all((s.success for s in sols)))

    def at(n):
        return sols[0 if n < 0 else 1].sol(n)

    def physical(n):
        state = at(n)
        return (math.exp(n + np.dot(alpha, state[:2])), state[6])
    rows = []
    for n in f['comparison_N']:
        state = at(n)
        sv, rv = (np.dot(state[2:4], state[2:4]) / 3, state[4])
        om = 1 - sv - rv
        y = np.dot(alpha, state[2:4])
        qj = co_q_physical(av, sv, rv, y)
        co_check(f'ode_state_{fixture['id']}_{max_step}_{n}', min(sv, rv, om) >= -f['simplex_atol'] and 1 + y > 0 and (qj >= co_qb(av) - f['simplex_atol']), Omega_m=om, Omega_r=rv, Omega_s=sv, q_J=qj)
        ra, ta = physical(n)
        estimates = []
        for h in f['derivative_steps']:
            rp, tp = physical(n + h)
            rm, tm = physical(n - h)
            r1, t1 = ((rp - rm) / (2 * h), (tp - tm) / (2 * h))
            r2, t2 = ((rp - 2 * ra + rm) / h ** 2, (tp - 2 * ta + tm) / h ** 2)
            estimates.append(-ra * (r2 - r1 * t2 / t1) / r1 ** 2)
        richardson = (4 * estimates[1] - estimates[0]) / 3
        co_check(f'frame_derivative_{fixture['id']}_{max_step}_{n}', abs(estimates[1] - qj) < f['q_finite_difference_atol'] and abs(richardson - qj) < f['q_refined_richardson_atol'], finite_difference=estimates, richardson=richardson, analytic=qj)
        if fixture['id'] in ['uncoupled_dust', 'weak_equality']:
            co_check(f'equality_evolution_{fixture['id']}_{max_step}_{n}', abs(qj - co_qb(av)) < 1e-10)
        rows.append({'N': n, 'state': state.tolist(), 'Omega_m': om, 'Omega_r': rv, 'Omega_s': sv, 'y': float(y), 'q_J': float(qj), 'scale_J': ra, 'time_J': ta, 'finite_difference_q': estimates, 'richardson_q': richardson})
    return rows

def co_evolution_controls(f):
    results = []
    for fixture in f['evolution']:
        levels = [co_history(fixture, h, f) for h in f['ode_max_steps']]
        error = max((np.max(np.abs(np.array(a['state']) - np.array(b['state']))) for a, b in zip(*levels)))
        co_check(f'ode_refinement_{fixture['id']}', error < f['ode_refinement_atol'], maximum_absolute=error)
        results.append({'fixture': fixture, 'max_state_refinement_error': float(error), 'levels': levels})
    row = results[-1]['levels'][-1][4]
    av = results[-1]['fixture']['a']
    y, om, sv, rv = (row['y'], row['Omega_m'], row['Omega_s'], row['Omega_r'])
    qe = om / 2 + rv + 2 * sv
    false = {'missing_2y': (qe + 1.5 * av * om) / (1 + y) ** 2, 'wrong_trace_sign': (qe + 2 * y - 1.5 * av * om) / (1 + y) ** 2}
    for name, value in false.items():
        co_check('reject_' + name, abs(value - row['richardson_q']) > 0.001, false_q=value, physical_derivative_q=row['richardson_q'])
    return results

def co_distance_controls(f):
    rows = []
    for q in [0.5, co_qb(1 / 2499)]:
        for curvature in [0, 0.3, 1.0]:
            ratios = []
            for z in f['distance_grid']:
                direct_b, err = quad(lambda u: (1 + u) ** (-1 - q), 0, z, epsabs=1e-13, epsrel=1e-13)
                co_check(f'B_integral_{q}_{curvature}_{z}', abs(direct_b - co_bq(z, q)) < 2e-13)
                inverse_h = lambda u: (1 + u) ** (-1 - q - curvature) * math.exp(curvature - curvature / (1 + u))
                distance = quad(inverse_h, 0, z, epsabs=1e-13, epsrel=1e-13)[0]
                ratios.append(distance / co_bq(z, q))
            co_check(f'monotone_distance_ratio_{q}_{curvature}', np.max(np.diff(ratios)) < 2e-12, ratios=ratios)
            rows.append({'q_lower': q, 'q_extra_z_over_1plusz': curvature, 'ratios': ratios})
    return rows

def co_primary_bytes(name, manifest):
    item = manifest['files'][name]
    zipped = (CO_ROOT / item['local_gzip']).read_bytes()
    co_check('gzip_hash_' + name, co_sha(zipped) == item['gzip_sha256'])
    data = gzip.decompress(zipped)
    co_check('primary_hash_' + name, co_sha(data) == item['raw_sha256'] and len(data) == item['raw_bytes'])
    return data

def co_data_comparison(f):
    manifest = json.loads((CO_ROOT / 'PRIMARY_DATA.json').read_text())
    table_bytes = co_primary_bytes('table', manifest)
    cov_bytes = co_primary_bytes('covariance', manifest)
    table = np.genfromtxt(io.BytesIO(table_bytes), names=True, dtype=None, encoding='utf-8')
    entries = np.fromstring(cov_bytes.decode('ascii'), sep=' ')
    n = int(entries[0])
    co_check('covariance_dimension', entries[0] == n and len(table) == n and (len(entries) == 1 + n * n), table_rows=len(table), covariance_n=n, covariance_entries=len(entries) - 1)
    raw_cov = entries[1:].reshape(n, n)
    co_check('covariance_finite', np.isfinite(raw_cov).all())
    asymmetry = float(np.max(np.abs(raw_cov - raw_cov.T)))
    scale = float(np.max(np.diag(raw_cov)))
    co_check('covariance_text_symmetry', asymmetry <= f['covariance_symmetry_relative_to_max_diagonal'] * scale, maximum_asymmetry=asymmetry, diagonal_scale=scale)
    cov = (raw_cov + raw_cov.T) / 2
    all_factor = cho_factor(cov, lower=True, check_finite=True)
    co_check('full_covariance_positive_definite', np.all(np.diag(all_factor[0]) > 0), minimum_cholesky_diagonal=float(np.min(np.diag(all_factor[0]))))
    z, zh, mag = [np.asarray(table[k], dtype=float) for k in ['zHD', 'zHEL', 'm_b_corr']]
    co_check('magnitude_redshift_finite', all((np.isfinite(v).all() for v in [z, zh, mag])))
    selected = np.flatnonzero((table['IS_CALIBRATOR'] == 0) & (z >= 0.0233) & (z <= 1.5))
    z, zh, mag = (z[selected], zh[selected], mag[selected])
    c = cov[np.ix_(selected, selected)]
    low = np.flatnonzero(z < 0.1)
    test = np.flatnonzero(z >= 0.1)
    high = np.flatnonzero((z >= 0.3) & (z <= 1.0))
    co_check('frozen_partition', len(low) > 1 and len(test) > 1 and (len(high) > 1) and (len(low) + len(test) == len(selected)) and (np.min(z[high]) > np.max(z[low])))
    cll, ctl, ctt = (c[np.ix_(low, low)], c[np.ix_(test, low)], c[np.ix_(test, test)])
    factor_l = cho_factor(cll, lower=True)
    one_l = np.ones(len(low))
    qi_one = cho_solve(factor_l, one_l)
    vm = 1 / np.dot(one_l, qi_one)
    b = cho_solve(factor_l, ctl.T).T
    v = np.ones(len(test)) - b @ one_l
    s = ctt - b @ ctl.T + vm * np.outer(v, v)
    s = (s + s.T) / 2
    factor_s = cho_factor(s, lower=True)
    factor_all = cho_factor(c, lower=True)
    co_check('predictive_covariance_positive_definite', np.all(np.diag(factor_s[0]) > 0))
    all_one = np.ones(len(z))
    all_qi_one = cho_solve(factor_all, all_one)
    g_lcdm = []
    max_lcdm_refinement = 0.0
    for zi, zhi in zip(z, zh):
        ds = [quad(lambda u: 1 / math.sqrt(f['lcdm_omega_m'] * (1 + u) ** 3 + 1 - f['lcdm_omega_m']), 0, zi, epsabs=e, epsrel=e)[0] for e in f['distance_quadrature_tolerances']]
        max_lcdm_refinement = max(max_lcdm_refinement, abs(ds[0] - ds[1]))
        g_lcdm.append(5 * math.log10((1 + zhi) * ds[-1]))
    co_check('lcdm_distance_refinement', max_lcdm_refinement < 1e-09, maximum_absolute=max_lcdm_refinement)
    shapes = {'q_half': 5 * np.log10((1 + zh) * co_bq(z, 0.5)), 'weak_equality': 5 * np.log10((1 + zh) * co_bq(z, co_qb(1 / 2499))), 'supplied_LCDM_0.3': np.array(g_lcdm)}
    predictions = {}
    for name, g in shapes.items():
        dl = mag[low] - g[low]
        mhat = vm * np.dot(one_l, cho_solve(factor_l, dl))
        residual_l = dl - mhat
        chi_l = np.dot(residual_l, cho_solve(factor_l, residual_l))
        prediction = g[test] + b @ dl + v * mhat
        residual_t = mag[test] - prediction
        chi_t = np.dot(residual_t, cho_solve(factor_s, residual_t))
        dall = mag - g
        mhat_all = np.dot(all_qi_one, dall) / np.dot(all_qi_one, all_one)
        resall = dall - mhat_all
        chi_all = np.dot(resall, cho_solve(factor_all, resall))
        co_check('conditional_quadratic_identity_' + name, abs(chi_l + chi_t - chi_all) < f['conditional_identity_relative_tolerance'] * max(1, chi_all), calibration_chi2=float(chi_l), conditional_transfer_chi2=float(chi_t), full_profile_algebra_check_only=float(chi_all))
        predictions[name] = {'intercept_calibration_only': float(mhat), 'intercept_standard_error': math.sqrt(vm), 'calibration_chi2': float(chi_l), 'calibration_rank': len(low) - 1, 'conditional_transfer_chi2': float(chi_t), 'transfer_dimension': len(test), 'shape_all_selected': g.tolist(), 'prediction_transfer': prediction.tolist(), 'residual_calibration': residual_l.tolist(), 'residual_transfer': residual_t.tolist(), 'full_profile_identity_is_not_a_test_fit': float(chi_all)}
    weights = np.zeros(len(selected))
    weights[high] = 1 / len(high)
    weights[low] = -1 / len(low)
    co_check('contrast_intercept_cancellation', abs(np.sum(weights)) < 1e-12)
    observed = float(np.dot(weights, mag - shapes['q_half']))
    sigma = math.sqrt(float(weights @ c @ weights))
    log_lever = float(weights @ np.log10(1 + z))
    co_check('contrast_lever_positive', log_lever > 0)
    nuisance = [{'beta': beta, 'corrected_contrast_mag': observed - beta * log_lever, 'standardized_contrast': (observed - beta * log_lever) / sigma} for beta in f['luminosity_evolution_beta']]
    contrast = {'definition': 'equal arithmetic high mean minus equal arithmetic low mean relative to q=.5 distance', 'class_mean_upper_bound_mag': 0, 'observed_mag': observed, 'standard_error_full_covariance_mag': sigma, 'standardized_contrast': observed / sigma, 'high_rows': len(high), 'low_rows': len(low), 'log_luminosity_lever': log_lever, 'beta_to_cancel_single_contrast_calibration_only': observed / log_lever, 'frozen_beta_sensitivity': nuisance, 'weights_all_selected': weights.tolist()}
    ids = np.asarray(table['CID']).astype(str)
    counts = {'all_light_curve_rows': len(table), 'all_distinct_CID': len(set(ids)), 'selected_light_curve_rows': len(selected), 'selected_distinct_CID': len(set(ids[selected])), 'calibration_light_curve_rows': len(low), 'calibration_distinct_CID': len(set(ids[selected[low]])), 'transfer_light_curve_rows': len(test), 'transfer_distinct_CID': len(set(ids[selected[test]])), 'contrast_high_light_curve_rows': len(high), 'contrast_high_distinct_CID': len(set(ids[selected[high]]))}
    return {'counts': counts, 'raw_covariance_asymmetry': asymmetry, 'covariance_diagonal_scale': scale, 'covariance_convention': f['covariance_symmetrization'], 'original_selected_row_indices_zero_based': selected.tolist(), 'selected_CID': ids[selected].tolist(), 'zHD': z.tolist(), 'zHEL': zh.tolist(), 'm_b_corr': mag.tolist(), 'calibration_indices_in_selection': low.tolist(), 'transfer_indices_in_selection': test.tolist(), 'contrast_high_indices_in_selection': high.tolist(), 'fixed_curves': predictions, 'class_contrast': contrast, 'prediction_covariance_sha256_float64_C_order': co_sha(np.asarray(s, dtype='<f8').tobytes()), 'scope': 'Exposed processed-summary comparison. No raw-photometry refit, global blind test, independent reuse of overlapping diagnostics, or luminosity-evolution claim.'}

def pv_check(name, condition, **evidence):
    passed = bool(condition)
    PV_CHECKS.append({'name': name, 'pass': passed, **evidence})
    assert passed, (name, evidence)

def pv_symbolic_checks():
    a, p, h, d = sp.symbols('a p h d', nonzero=True)
    pd = h + d + (1 - h) * p + (1 / a - 1) * p ** 2
    hd = h * (-3 - 2 * h)
    dd = d * (2 * p - 3 - 2 * h)
    c = h + (1 + a) * d + 4 * p + (1 / a - 3) * p ** 2
    f = 3 * (1 - p) ** 2 - p ** 2 / a - 2 * d
    fd = sp.diff(f, p) * pd + sp.diff(f, d) * dd
    pv_check('inverse_potential_KG_identity', sp.factor((p + h) * f + fd / 2 + p * c / a) == 0)
    cd = sp.diff(c, h) * hd + sp.diff(c, p) * pd + sp.diff(c, d) * dd
    turning = sp.factor((-(2 * p + 2 * h) * c - cd).subs(p, 0))
    pv_check('turning_point_derivative_identity', sp.factor(turning + h + (1 - 3 * a) * d) == 0)
    pv_check('present_zero_drift_obstruction', sp.factor(turning.subs(h, -(1 + a) * d) - 4 * a * d) == 0)
    pv_check('present_zero_gradient', sp.factor(c.subs({p: 0, h: -(1 + a) * d})) == 0)
    s, cc, eta, k = sp.symbols('s cc eta k', positive=True)
    sg2, sgg = (4 * k ** 2 * s * (cc + s), 2 * k ** 2 * (cc + 2 * s))
    determinant = (1 + eta) * s * a * sgg / 2 - a * sg2
    expected = a * k ** 2 * s * ((eta - 3) * cc + (2 * eta - 2) * s)
    pv_check('two_field_hessian_determinant', sp.factor(determinant - expected) == 0)
    pv_check('eta_three_positive_determinant', sp.factor(expected.subs(eta, 3) - 4 * a * k ** 2 * s ** 2) == 0)
    k2 = 3 * (1 + a) / (2 * a)
    h2 = sp.Rational(2, 3) * (1 + a) * (cc + s)
    pv_check('tracking_gradient_relation', sp.factor(4 * k2 * s * (cc + s) - 9 * h2 * s / a) == 0)
    pv_check('tracking_friedmann', sp.expand(2 * s + a * s + 2 * (sp.Symbol('v0') + a * s / 2) - (2 * (1 + a) * s + 2 * sp.Symbol('v0'))) == 0)
    return {'inverse_p_prime': str(pd), 'turning_derivative_times_sqrt_a': str(turning), 'hessian_determinant': str(sp.factor(expected))}

def pv_inverse_endpoint(f):
    rows = []
    for a in f['weak_couplings']:
        for m in f['matter_fractions']:
            d0 = 1.5 * m / (1 + a)

            def equations(n, state):
                zeta, p = state
                e2 = m * math.exp(-3 * n) + 1 - m
                h = -1.5 * m * math.exp(-3 * n) / e2
                d = 1.5 * m * math.exp(2 * zeta - 3 * n) / ((1 + a) * e2)
                return [p, h + d + (1 - h) * p + (1 / a - 1) * p * p]
            sol = solve_ivp(equations, (0, min(f['one_field_endpoint_n'])), [0, 0], method='DOP853', rtol=2e-13, atol=2e-16, max_step=0.002, dense_output=True)
            pv_check(f'inverse_endpoint_integration_{a}_{m}', sol.success)
            sites = []
            for n in f['one_field_endpoint_n']:
                zeta, p = sol.sol(n)
                e2 = m * math.exp(-3 * n) + 1 - m
                h = -1.5 * m * math.exp(-3 * n) / e2
                d = 1.5 * m * math.exp(2 * zeta - 3 * n) / ((1 + a) * e2)
                pd = equations(n, [zeta, p])[1]
                hd, dd = (h * (-3 - 2 * h), d * (2 * p - 3 - 2 * h))
                c = h + (1 + a) * d + 4 * p + (1 / a - 3) * p * p
                cd = hd + (1 + a) * dd + (4 + 2 * (1 / a - 3) * p) * pd
                prefactor = math.exp(2 * zeta) * e2
                phi = zeta / math.sqrt(a)
                gradient = -prefactor * c / math.sqrt(a)
                mass2 = -prefactor * ((2 * p + 2 * h) * c + cd) / p
                pv_potential = prefactor / 2 * (3 * (1 - p) ** 2 - p * p / a - 2 * d)
                ratio_phi = phi / (-math.sqrt(a) * d0 * n * n / 2)
                ratio_gradient = gradient / (4 * math.sqrt(a) * d0 * n)
                ratio_mass = mass2 / (-4 / n)
                pv_check(f'inverse_past_branch_{a}_{m}_{n}', phi < 0 and p > 0 and (mass2 > 0) and (pv_potential > 0))
                sites.append({'n': n, 'zeta': float(zeta), 'p': float(p), 'phi': float(phi), 'V_over_H0_squared': float(pv_potential), 'V_phi_over_H0_squared': float(gradient), 'V_phiphi_over_H0_squared': float(mass2), 'phi_leading_ratio': float(ratio_phi), 'gradient_leading_ratio': float(ratio_gradient), 'mass_leading_ratio': float(ratio_mass)})
            last = sites[-1]
            pv_check(f'one_sided_cusp_scaling_{a}_{m}', max((abs(last[k] - 1) for k in ['phi_leading_ratio', 'gradient_leading_ratio', 'mass_leading_ratio'])) < f['one_field_cusp_ratio_tolerance_at_last_site'], last=last)
            rows.append({'a': a, 'm': m, 'endpoint_phi_prime': 0, 'endpoint_gradient_derivative_over_H0_squared': 4 * math.sqrt(a) * d0, 'smooth_C2_necessary_value': 0, 'sites': sites, 'disposition': 'Exact zero-drift endpoint violates necessary one-field C2 compatibility under supplied target and density.'})
    return rows

def pv_constants(a, m):
    v0 = 1.5 * (1 - m)
    cc = v0 / (1 + a)
    k = math.sqrt(3 * (1 + a) / (2 * a))
    chi_c = math.asinh(math.sqrt(m / (1 - m))) / k
    return (v0, cc, k, chi_c)

def pv_potential(u, chi, a, m, eta):
    v0, cc, k, chi_c = pv_constants(a, m)
    t = k * (chi - chi_c)
    sh, ch = (math.sinh(t), math.cosh(t))
    s = cc * sh * sh
    sg = 2 * cc * k * sh * ch
    sgg = 2 * cc * k * k * (ch * ch + sh * sh)
    q = (u - math.sqrt(a)) ** 2 + eta * u * u
    qu = (1 + eta) * u - math.sqrt(a)
    val = v0 + s * q / 2
    grad = np.array([s * qu, sg * q / 2])
    hessian = np.array([[(1 + eta) * s, sg * qu], [sg * qu, sgg * q / 2]])
    return (val, grad, hessian, s, sg, sgg)

def pv_analytic_background(n, a, m):
    v0, cc, k, chi_c = pv_constants(a, m)
    chi = chi_c - math.asinh(math.sqrt(m / (1 - m)) * math.exp(-1.5 * n)) / k
    s = 1.5 * m * math.exp(-3 * n) / (1 + a)
    h = math.sqrt(m * math.exp(-3 * n) + 1 - m)
    velocity = math.sqrt(a * s)
    return (chi, s, h, velocity)

def pv_hessian_and_background_grid(f):
    rows = []
    couplings = f['weak_couplings'] + [f['additional_mathematical_coupling']]
    for a in couplings:
        for m in f['matter_fractions']:
            v0, cc, k, chi_c = pv_constants(a, m)
            for eta in f['eta_choices']:
                for n in f['N_grid']:
                    chi, s, h, velocity = pv_analytic_background(n, a, m)
                    val, grad, mat, spv, sg, sgg = pv_potential(0, chi, a, m, eta)
                    eigs = np.linalg.eigvalsh(mat)
                    det = a * k * k * s * ((eta - 3) * cc + (2 * eta - 2) * s)
                    numeric_det = float(np.linalg.det(mat))
                    name = f'a{a}_m{m}_eta{eta}_n{n}'
                    defects = [spv - s, 3 * h * h - 2 * s - velocity ** 2 - 2 * val, grad[0] + math.sqrt(a) * s, grad[1] + 1.5 * h * velocity, sg * velocity + 3 * h * s]
                    scale = max(1, abs(val), h * h, s)
                    pv_check('background_identities_' + name, max((abs(x) for x in defects)) < 2e-11 * scale, maximum_absolute_defect=max((abs(x) for x in defects)))
                    pv_check('hessian_determinant_' + name, abs(numeric_det - det) < 2e-11 * max(1, abs(det)), direct=numeric_det, analytic=det)
                    if eta == 0:
                        pv_check('preserve_original_negative_curvature_' + name, det < 0 and eigs[0] < 0)
                    if eta >= 3:
                        pv_check('repaired_positive_curvature_' + name, det > 0 and eigs[0] > 0)
                    values = [pv_potential(t * math.sqrt(a), chi, a, m, eta)[0] for t in [-2, -0.5, 0, 0.5, 1, 2]]
                    pv_check('positive_potential_' + name, min(values) >= v0 - 2e-12)
                    rows.append({'a': a, 'm': m, 'eta': eta, 'n': n, 'chi': chi, 'S_over_H0_squared': s, 'H_over_H0': h, 'chi_dot_over_H0': velocity, 'V_over_H0_squared': val, 'hessian_over_H0_squared': mat.tolist(), 'hessian_eigenvalues': eigs.tolist(), 'determinant': det, 'eta_required_at_site': (3 * cc + 2 * s) / (cc + 2 * s), 'positive_curvature_at_site': bool(eigs[0] > 0)})
    return rows

def pv_full_homogeneous_evolution(f):
    results = []
    for index, fixture in enumerate(f['two_field_ode']):
        a, m, eta = [fixture[k] for k in ['a', 'm', 'eta']]
        alpha = np.array([math.sqrt(a), 0.0])
        _, s0, _, vchi0 = pv_analytic_background(0, a, m)
        initial = np.array([0, 0, 0, vchi0, s0, 0.0])

        def func(nstar, state):
            u, chi, vu, vc, sigma, time_j = state
            val, grad, _, _, _, _ = pv_potential(u, chi, a, m, eta)
            v = np.array([vu, vc])
            h = math.sqrt((2 * sigma + np.dot(v, v) + 2 * val) / 3)
            dv = -3 * v - (grad + alpha * sigma) / h
            ds = sigma * (-3 + np.dot(alpha, v) / h)
            return np.r_[v / h, dv, ds, math.exp(math.sqrt(a) * u) / h]
        levels = []
        for lev, max_step in enumerate(f['ode_max_steps']):
            opts = dict(method=f['ode_method'], rtol=f['ode_relative_tolerances'][lev], atol=f['ode_absolute_tolerances'][lev], max_step=max_step, dense_output=True)
            sols = [solve_ivp(func, (0, end), initial, **opts) for end in f['ode_interval_N_star']]
            pv_check(f'two_field_full_ode_success_{index}_{lev}', all((s.success for s in sols)))
            rows = []
            for nstar in f['ode_comparison_N_star']:
                state = sols[0 if nstar < 0 else 1].sol(nstar)
                u, chi, vu, vc, sigma, time_j = state
                aj = math.exp(math.sqrt(a) * u)
                nj = nstar + math.sqrt(a) * u
                val = pv_potential(u, chi, a, m, eta)[0]
                he = math.sqrt((2 * sigma + vu * vu + vc * vc + 2 * val) / 3)
                hj = (he + math.sqrt(a) * vu) / aj
                chi_exact, sig_exact, hj_exact, vc_exact = pv_analytic_background(nj, a, m)
                got = np.array([u, chi, vu, vc, sigma, hj])
                exact = np.array([0, chi_exact, 0, vc_exact, sig_exact, hj_exact])
                error = np.abs(got - exact)
                allowed = f['ode_comparison_absolute_tolerance'] + f['ode_comparison_relative_tolerance'] * np.abs(exact)
                pv_check(f'two_field_analytic_tracking_{index}_{lev}_{nstar}', np.all(error < allowed), maximum_absolute=float(np.max(error)))
                pv_check(f'dust_first_integral_{index}_{lev}_{nstar}', abs(sigma * math.exp(3 * nstar - math.sqrt(a) * u) - s0) < 2e-09)
                rows.append({'N_star': nstar, 'n_J': nj, 'state': state.tolist(), 'H_J_over_H0': hj, 'physical_G_over_present': aj * aj, 'maximum_absolute_tracking_error': float(np.max(error))})
            levels.append(rows)
        deltas = [np.array(x['state']) - np.array(y['state']) for x, y in zip(*levels)]
        refinement = float(np.max(np.abs(deltas)))
        pv_check(f'two_field_ode_refinement_{index}', refinement < 2e-09, maximum_absolute=refinement)
        results.append({'fixture': fixture, 'levels': levels, 'maximum_state_refinement_error': refinement})
    return results

def pv_local_mass_and_force(f):
    rows = []
    for a in f['weak_couplings']:
        m = f['observationally_compared_benchmark_m']
        chi, s, _, _ = pv_analytic_background(0, a, m)
        mat = pv_potential(0, chi, a, m, f['eta_repaired'])[2]
        for choice in f['matrix_choices']:
            current = mat.copy()
            if choice == 'potential_hessian_plus_fixed_number_dust':
                current[0, 0] += a * s
            eigenvalues, eigenvectors = np.linalg.eigh(current)
            weights = a * eigenvectors[0, :] ** 2
            pv_check(f'positive_local_residues_{a}_{choice}', np.all(eigenvalues > 0) and np.all(weights >= 0) and (abs(np.sum(weights) - a) < 1e-15))
            pv_check(f'mass_weighted_sum_rule_{a}_{choice}', abs(weights @ eigenvalues - a * current[0, 0]) < 1e-13)
            scales = [('dimensionless', scale) for scale in f['local_dimensionless_H0_r_over_c_controls']]
            scales += [(f'illustrative_radius_{radius}_m', f['H0_per_second_illustrative'] * radius / f['c_m_per_second']) for radius in f['local_radius_m_illustrative']]
            force_rows = []
            for label, scale in scales:
                xs = np.sqrt(eigenvalues) * scale
                deficits = [float(x * x * quad(lambda t: t * math.exp(-x * t), 0, 1, epsabs=f['force_quadrature_epsabs'], epsrel=f['force_quadrature_epsrel'])[0]) for x in xs]
                deficit = float(weights @ np.array(deficits)) / (1 + a)
                upper = a * current[0, 0] * scale * scale / (2 * (1 + a))
                pv_check(f'Yukawa_force_bound_{a}_{choice}_{label}_{scale}', deficit >= 0 and deficit <= upper * (1 + 2e-12) + 1e-300, actual_mass_correction=deficit, bound=upper)
                if scale > 0:
                    lower_ratio = math.exp(-float(np.max(xs)))
                    ratio = deficit / upper
                    pv_check(f'Yukawa_relative_positive_lower_bound_{a}_{choice}_{label}_{scale}', deficit > 0 and ratio >= lower_ratio * (1 - 2e-12) and (ratio <= 1 + 2e-12), deficit_over_upper=ratio, lower_ratio=lower_ratio)
                if scale >= 0.001:
                    closed = float(weights @ (1 - (1 + xs) * np.exp(-xs))) / (1 + a)
                    pv_check(f'Yukawa_integral_identity_{a}_{choice}_{scale}', abs(closed - deficit) < 1e-15)
                force_rows.append({'label': label, 'H0_r_over_c': scale, 'mu_r': xs.tolist(), 'relative_mass_force_deficit': deficit, 'relative_bound': upper})
            rows.append({'a': a, 'm': m, 'eta': f['eta_repaired'], 'quadratic_diagnostic': choice, 'mass_matrix_over_H0_squared': current.tolist(), 'mass_squared_eigenvalues': eigenvalues.tolist(), 'positive_residues': weights.tolist(), 'force_controls': force_rows})
    return rows

def pe_check(name, passed, **detail):
    PE_CHECKS.append(dict(name=name, passed=bool(passed), **detail))

def pe_bg(N, a, m=PE_FIX['m']):
    matter = m * np.exp(-3 * N)
    H = np.sqrt(matter + 1 - m)
    Om = matter / H ** 2
    D = 1.5 * Om / (1 + a)
    return (H, -1.5 * Om, D, np.sqrt(a * D))

def pe_symbolic_controls():
    s, D, x, Q, eta = sy.symbols('s D x Q eta', nonzero=True)
    P, d, T, u, c, wu, wc = sy.symbols('P d T u c wu wc')
    h = -(1 + s * s) * D
    pp = -P + D * T / Q + x * c
    rhs = {D: (-3 - 2 * h) * D, x: (-sy.Rational(3, 2) - h) * x, Q: -2 * (1 + h) * Q, P: pp, d: -T + 3 * pp, T: -(2 + h) * T + Q * (P + s * u), u: wu, c: wc, wu: -(3 + h) * wu - (Q + (1 + eta + s * s) * D) * u - 3 * x * c / s - D * s * d, wc: -(3 + h) * wc - 3 * x * u / s - (Q + sy.Rational(9, 4) + sy.Rational(3, 2) * (1 + s * s) * D) * c + 4 * x * pp + 3 * x * P}
    derivative = lambda v: sum((sy.diff(v, z) * rz for z, rz in rhs.items()))
    reduce = lambda v: sy.factor(v.subs(D, x * x / (s * s)))
    constraint = (Q - x * x) * P + D * d + 3 * D * T / Q + x * wc + sy.Rational(3, 2) * x * c
    identities = {'constraint_propagation': reduce(derivative(constraint) - (-3 - 2 * h) * constraint), 'spatial_trace': reduce(derivative(pp) + (4 + h) * pp + (3 + 2 * h) * P - x * wc + x * x * P - sy.Rational(3, 2) * x * c - D * s * u), 'Jordan_number_conservation': sy.expand(-T + 3 * pp - 3 * s * wu - (-T + 3 * (pp - s * wu))), 'physical_density_from_rest_density': sy.expand(d + s * u - 4 * s * u - (d - 3 * s * u))}
    for name, value in identities.items():
        pe_check(name, value == 0)
    return {k: str(v) for k, v in identities.items()}

def pe_growing_integral(N, m=PE_FIX['m']):
    R = np.exp(N)
    b = (1 - m) * R ** 3 / m
    J = quad(lambda t: t ** 1.5 / (1 + b * t ** 3) ** 1.5, 0, 1, epsabs=1e-12, epsrel=1e-12)[0]
    I = R ** 2.5 * J / m ** 1.5
    H, h, _, _ = pe_bg(N, 0, m)
    return (2.5 * m * H * I, h + 1 / (R ** 2 * H ** 3 * I))

def pe_growth_controls():

    def rhs(N, z):
        _, h, D, _ = pe_bg(N, 0)
        return [z[1], -(2 + h) * z[1] + D * z[0]]
    sol = solve_ivp(rhs, (PE_FIX['growth_initial_N'], 0), PE_FIX['growth_ode_initial'], method='DOP853', rtol=2e-12, atol=2e-14, max_step=0.02, dense_output=True)
    pe_check('growth_integrator_success', sol.success)
    rows = []
    for N in PE_FIX['linear_sites_N']:
        g, fg = pe_growing_integral(N)
        y = sol.sol(N)
        fgode = y[1] / y[0]
        pe_check('growth_integral_ODE_' + str(N), abs(fg - fgode) < PE_FIX['growth_compare_tolerance'])
        rows.append(dict(N=N, Dg_integral=g, fg_integral=fg, fg_ode=fgode))
    return rows

def pe_linear_rhs(N, z, a, eta, q0):
    H, h, D, x = pe_bg(N, a)
    Q = (q0 / (np.exp(N) * H)) ** 2
    s = np.sqrt(a)
    P, d, T, u, c, wu, wc = z
    pp = -P + D * T / Q + x * c
    out = np.empty_like(z)
    out[0] = pp
    out[1] = -T + 3 * pp
    out[2] = -(2 + h) * T + Q * (P + s * u)
    out[3] = wu
    out[4] = wc
    out[5] = -(3 + h) * wu - (Q + (1 + eta + a) * D) * u - 3 * np.sqrt(D) * c - D * s * d
    out[6] = -(3 + h) * wc - 3 * np.sqrt(D) * u - (Q + 2.25 + 1.5 * (1 + a) * D) * c + 4 * x * pp + 3 * x * P
    return out

def pe_initialize_constraint(N, z, a, q0):
    H, _, D, x = pe_bg(N, a)
    Q = (q0 / (np.exp(N) * H)) ** 2
    z[0] = -(D * z[1] + 3 * D * z[2] / Q + x * z[6] + 1.5 * x * z[4]) / (Q - x * x)
    return z

def pe_constraint_terms(N, z, a, q0):
    H, _, D, x = pe_bg(N, a)
    Q = (q0 / (np.exp(N) * H)) ** 2
    return np.array([(Q - x * x) * z[0], D * z[1], 3 * D * z[2] / Q, x * z[6], 1.5 * x * z[4]])

def pe_solve_linear(z0, a, eta, q0, refinement):
    shape = z0.shape

    def rhs(N, z):
        return pe_linear_rhs(N, z.reshape(shape), a, eta, q0).reshape(-1)
    return solve_ivp(rhs, PE_FIX['linear_interval_N'], z0.reshape(-1), method='DOP853', rtol=PE_FIX['linear_rtol'][refinement], atol=PE_FIX['linear_atol'][refinement], max_step=PE_FIX['linear_max_steps'][refinement], dense_output=True)

def pe_linear_basis_controls():
    rows = []
    Ni = PE_FIX['linear_interval_N'][0]
    sites = np.array(PE_FIX['linear_sites_N'])
    for a in PE_FIX['a_weak']:
        for eta in PE_FIX['linear_eta']:
            for q0 in PE_FIX['linear_q0']:
                z0 = np.zeros((7, 6))
                z0[1:] = np.diag([1, 1, np.sqrt(a), np.sqrt(a), np.sqrt(a), np.sqrt(a)])
                pe_initialize_constraint(Ni, z0, a, q0)
                histories = []
                for r in range(2):
                    sol = pe_solve_linear(z0, a, eta, q0, r)
                    pe_check(f'linear_success_{a}_{eta}_{q0}_{r}', sol.success)
                    ys = sol.sol(sites).reshape(7, 6, len(sites))
                    histories.append(ys)
                    for j, N in enumerate(sites):
                        terms = pe_constraint_terms(N, ys[:, :, j], a, q0)
                        residual = np.abs(terms.sum(axis=0)) / (1 + np.abs(terms).sum(axis=0))
                        pe_check(f'linear_constraint_{a}_{eta}_{q0}_{r}_{j}', np.max(residual) < PE_FIX['constraint_relative_tolerance'], max_scaled_residual=float(np.max(residual)))
                difference = np.abs(histories[1] - histories[0])
                scale = PE_FIX['linear_refinement_atol'] + PE_FIX['linear_refinement_rtol'] * np.maximum(np.abs(histories[0]), np.abs(histories[1]))
                pe_check(f'linear_refinement_{a}_{eta}_{q0}', np.max(difference / scale) <= 1, maximum_tolerance_units=float(np.max(difference / scale)))
                rows.append(dict(a=a, eta=eta, q0=q0, initial=z0.tolist(), sites=sites.tolist(), coarse=histories[0].tolist(), fine=histories[1].tolist(), endpoint_response_singular_values=np.linalg.svd(histories[1][:, :, -1], compute_uv=False).tolist()))
    return rows

def pe_slow_matter_controls():
    rows = []
    Ni = PE_FIX['linear_interval_N'][0]
    sites = np.array(PE_FIX['linear_sites_N'])
    fg0 = pe_growing_integral(Ni)[1]
    for a in PE_FIX['high_k_a']:
        for q0 in PE_FIX['high_k_q0']:
            H, _, D, _ = pe_bg(Ni, a)
            Q = (q0 / (np.exp(Ni) * H)) ** 2
            pl = -D / Q
            u = np.sqrt(a) * pl
            z0 = np.array([0.0, 1.0, -fg0 + 3 * (fg0 - 1) * pl, u, 0.0, (fg0 - 1) * u, 0.0])
            pe_initialize_constraint(Ni, z0, a, q0)
            histories = []
            for r in range(2):
                sol = pe_solve_linear(z0, a, PE_FIX['high_k_eta'], q0, r)
                pe_check(f'slow_matter_success_{a}_{q0}_{r}', sol.success)
                histories.append(sol.sol(sites))
            scale = PE_FIX['linear_refinement_atol'] + PE_FIX['linear_refinement_rtol'] * np.maximum(np.abs(histories[0]), np.abs(histories[1]))
            pe_check(f'slow_matter_refinement_{a}_{q0}', np.max(np.abs(histories[1] - histories[0]) / scale) <= 1)
            points = []
            for j, N in enumerate(sites):
                z = histories[1][:, j]
                zp = pe_linear_rhs(N, z, a, 3, q0)
                H, _, D, _ = pe_bg(N, a)
                Q = (q0 / (np.exp(N) * H)) ** 2
                P, d, T, u, c, wu, wc = z
                zet = np.sqrt(a) * u
                deltaJ = d - 3 * zet
                psi = P + zet
                phi = P - zet
                mu = -Q * psi / ((1 + a) * D * deltaJ)
                Sigma = -Q * P / ((1 + a) * D * deltaJ)
                gamma = phi / psi
                fg = (zp[1] - 3 * np.sqrt(a) * wu) / deltaJ
                terms = pe_constraint_terms(N, z, a, q0)
                pe_check(f'slow_constraint_{a}_{q0}_{j}', abs(terms.sum()) / (1 + abs(terms).sum()) < PE_FIX['constraint_relative_tolerance'])
                points.append(dict(N=float(N), Q=float(Q), mu=float(mu), Sigma=float(Sigma), gamma=float(gamma), fg_J=float(fg), fg_regular_GR=pe_growing_integral(N)[1], state=z.tolist()))
            target = dict(mu=1.0, Sigma=1 / (1 + a), gamma=(1 - a) / (1 + a))
            for k in PE_FIX['high_k_comparisons']:
                err = abs(points[-1][k] - target[k])
                bound = PE_FIX['high_k_endpoint_error_bound_coefficient'] / q0 ** 2
                pe_check(f'finite_asymptotic_control_{a}_{q0}_{k}', err <= bound, absolute_error=err, declared_bound=bound)
            rows.append(dict(a=a, q0=q0, eta=3, initial=z0.tolist(), points=points, limiting_coefficients=target))
    return rows

def pe_potential(phi, a, eta, m=PE_FIX['m']):
    s = np.sqrt(a)
    vl = 1.5 * (1 - m)
    k = np.sqrt(1.5 * (1 + a) / a)
    c = vl / (1 + a)
    chic = np.arcsinh(np.sqrt(m / (1 - m))) / k
    u, ch = phi
    z = k * (ch - chic)
    S = c * np.sinh(z) ** 2
    Sp = c * k * np.sinh(2 * z)
    Spp = 2 * c * k * k * np.cosh(2 * z)
    F = (u - s) ** 2 + eta * u * u
    B = (1 + eta) * u - s
    V = vl + 0.5 * S * F
    grad = np.array([S * B, 0.5 * Sp * F])
    Hess = np.array([[(1 + eta) * S, Sp * B], [Sp * B, 0.5 * Spp * F]])
    return (V, grad, Hess)

def pe_homogeneous_rhs_jac(Y, a, eta):
    phi = Y[:2]
    v = Y[2:4]
    sig = np.exp(Y[4])
    alpha = np.array([np.sqrt(a), 0.0])
    V, gV, Hess = pe_potential(phi, a, eta)
    H = np.sqrt((2 * sig + v @ v + 2 * V) / 3)
    g = gV + alpha * sig
    F = np.concatenate((v / H, -3 * v - g / H, [-3 + alpha @ v / H]))
    dh = np.concatenate((gV, v, [sig])) / (3 * H * H)
    Jac = np.zeros((5, 5), dtype=np.result_type(Y))
    Jac[:2, 2:4] = np.eye(2) / H
    Jac[:2] -= np.outer(v / H, dh)
    Jac[2:4, :2] = -Hess / H
    Jac[2:4, 2:4] = -3 * np.eye(2)
    Jac[2:4, 4] = -alpha * sig / H
    Jac[2:4] += np.outer(g / H, dh)
    Jac[4] = alpha @ Jac[:2]
    return (F, Jac, H)

def pe_homogeneous_initial(N, a):
    m = PE_FIX['m']
    k = np.sqrt(1.5 * (1 + a) / a)
    chic = np.arcsinh(np.sqrt(m / (1 - m))) / k
    chi = chic - np.arcsinh(np.sqrt(m / (1 - m)) * np.exp(-1.5 * N)) / k
    sig = 1.5 * m * np.exp(-3 * N) / (1 + a)
    return np.array([0.0, chi, 0.0, np.sqrt(a * sig), np.log(sig)])

def pe_homogeneous_controls():
    rows = []
    Ni, Nf = PE_FIX['homogeneous_interval_N']
    sites = np.array(PE_FIX['homogeneous_sites_N'])
    for a in PE_FIX['homogeneous_a']:
        for eta in PE_FIX['homogeneous_eta']:
            Y0 = pe_homogeneous_initial(Ni, a)
            F, J, H = pe_homogeneous_rhs_jac(Y0, a, eta)
            cs = np.column_stack([np.imag(pe_homogeneous_rhs_jac(Y0.astype(complex) + 1e-27j * np.eye(5)[j], a, eta)[0]) / 1e-27 for j in range(5)])
            pe_check(f'analytic_homogeneous_jacobian_{a}_{eta}', np.allclose(J, cs, rtol=2e-11, atol=2e-11), max_error=float(np.max(abs(J - cs))))
            scales = np.array([np.sqrt(a), np.sqrt(a), np.sqrt(a) * H, np.sqrt(a) * H, 1.0])

            def vari_rhs(N, z):
                Y = z[:5]
                F, J, _ = pe_homogeneous_rhs_jac(Y, a, eta)
                return np.concatenate((F, (J @ z[5:].reshape(5, 5)).reshape(-1)))
            vsol = solve_ivp(vari_rhs, (Ni, Nf), np.concatenate((Y0, np.diag(scales).reshape(-1))), method='DOP853', rtol=PE_FIX['homogeneous_rtol'][1], atol=PE_FIX['homogeneous_atol'][1], max_step=PE_FIX['homogeneous_max_steps'][1], dense_output=True)
            pe_check(f'variational_success_{a}_{eta}', vsol.success)
            vari = vsol.sol(sites)
            mat = vari[5:].reshape(5, 5, len(sites))
            runs = []
            for axis in range(5):
                for eps in PE_FIX['homogeneous_eps']:
                    results = []
                    for r in range(2):
                        signs = []
                        for sign in [-1, 1]:
                            initial = Y0.copy()
                            initial[axis] += sign * eps * scales[axis]
                            sol = solve_ivp(lambda N, Y: pe_homogeneous_rhs_jac(Y, a, eta)[0], (Ni, Nf), initial, method='DOP853', rtol=PE_FIX['homogeneous_rtol'][r], atol=PE_FIX['homogeneous_atol'][r], max_step=PE_FIX['homogeneous_max_steps'][r], dense_output=True)
                            pe_check(f'homogeneous_success_{a}_{eta}_{axis}_{eps}_{r}_{sign}', sol.success)
                            signs.append(sol.sol(sites))
                        results.append(np.array(signs))
                    central = (results[1][1] - results[1][0]) / (2 * eps)
                    scaled_error = np.max(abs(central - mat[:, axis, :]) / scales[:, None])
                    pe_check(f'homogeneous_variation_{a}_{eta}_{axis}_{eps}', scaled_error < PE_FIX['homogeneous_variation_scaled_error_tolerance'], maximum_scaled_error=float(scaled_error))
                    re = np.max(abs(results[0] - results[1]) / scales[None, :, None])
                    pe_check(f'homogeneous_refinement_{a}_{eta}_{axis}_{eps}', re < PE_FIX['homogeneous_refinement_scaled_tolerance'], maximum_scaled_error=float(re))
                    endpoints = []
                    for ii, sign in enumerate([-1, 1]):
                        Y = results[1][ii, :, -1]
                        A = np.exp(np.sqrt(a) * Y[0])
                        Ff, _, Hf = pe_homogeneous_rhs_jac(Y, a, eta)
                        drift = 2 * np.sqrt(a) * Y[2] / A * PE_FIX['H0_per_second_illustrative'] * PE_FIX['seconds_per_year_supplied']
                        endpoints.append(dict(sign=sign, u=float(Y[0]), u_over_initial_scalar_scale=float(Y[0] / np.sqrt(a)), G_ratio_to_u_zero=float(A * A), drift_per_year=float(drift), H_J_over_H0=float((Hf + np.sqrt(a) * Y[2]) / A)))
                    runs.append(dict(axis=axis, eps=eps, coarse=results[0].tolist(), fine=results[1].tolist(), maximum_scaled_variation_error=float(scaled_error), endpoints=endpoints))
            rows.append(dict(a=a, eta=eta, sites=sites.tolist(), initial=Y0.tolist(), scales=scales.tolist(), variational=vari.tolist(), nonlinear_runs=runs))
    return rows

def pe_de_sitter_controls():
    L = np.sqrt(1 - PE_FIX['m'])
    A = np.array([[0, 1, 0, 0], [0, -3 * L, 0, 0], [0, 0, 0, 1], [0, 0, -2.25 * L * L, -3 * L]])
    rows = []
    for t in [0, 0.1, 1, 4, 8]:
        U = expm(A * t)
        E = np.zeros((4, 4))
        e = np.exp(-3 * L * t)
        f = np.exp(-1.5 * L * t)
        E[:2, :2] = [[1, (1 - e) / (3 * L)], [0, e]]
        E[2:, 2:] = f * np.array([[1 + 1.5 * L * t, t], [-2.25 * L * L * t, 1 - 1.5 * L * t]])
        pe_check('vacuum_modes_' + str(t), np.allclose(U, E, rtol=2e-12, atol=2e-13))
        rows.append(dict(t=t, matrix=U.tolist(), neutral_mode=U[:, 0].tolist()))
    return rows

def pe_empirical_summary():
    N = -np.log1p(PE_FIX['EG_z'])
    _, fg = pe_growing_integral(N)
    rows = []
    for a in [0] + PE_FIX['a_weak']:
        prediction = PE_FIX['m'] / ((1 + a) * fg)
        rows.append(dict(a=a, m=PE_FIX['m'], z=PE_FIX['EG_z'], fg=fg, EG=prediction, difference_from_same_m_GR=prediction - PE_FIX['m'] / fg, observed_summary=PE_FIX['EG_summary'], reported_uncertainty=PE_FIX['EG_reported_uncertainty'], standardized_summary_residual=(prediction - PE_FIX['EG_summary']) / PE_FIX['EG_reported_uncertainty']))
    pe_check('EG_endpoint_fractional_difference', abs(rows[-1]['EG'] / rows[0]['EG'] - 2499 / 2500) < 2e-15)
    return dict(role=PE_FIX['EG_data_role'], source=PE_FIX['EG_source'], rows=rows, additional_lensing_calibration_fraction_not_combined=PE_FIX['EG_additional_lensing_calibration_fraction'], limitations='No raw estimator/covariance or revised geometry/nonlinear corrections. Scale-independent slowly varying matter mode and same-tracer bridges supplied.')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--json',action='store_true')
    ap.add_argument('--output-json',type=Path)
    args=ap.parse_args()
    if args.output_json and args.output_json.exists():raise FileExistsError(args.output_json)
    CO_CHECKS.clear();PV_CHECKS.clear();PE_CHECKS.clear()
    co={}
    for name,fn in [('square_identity_grid',co_square_identity_and_grid),
                    ('direct_evolution',co_evolution_controls),('distance_controls',co_distance_controls),
                    ('processed_data',co_data_comparison)]:co[name]=fn(CO_FIX)
    pv={'symbolic':pv_symbolic_checks()}
    for name,fn in [('single_field_endpoint',pv_inverse_endpoint),('potential_grid',pv_hessian_and_background_grid),
                    ('two_field_evolution',pv_full_homogeneous_evolution),('local_quadratic_force',pv_local_mass_and_force)]:pv[name]=fn(PV_FIX)
    pv['historical_drift']={'prediction_per_year':0,
        'exposed_mean_per_year':PV_FIX['historical_LLR_drift_per_year_mean'],
        'reported_uncertainty_per_year':PV_FIX['historical_LLR_drift_per_year_reported_uncertainty'],
        'standardized_residual':PV_FIX['historical_LLR_drift_per_year_mean']/PV_FIX['historical_LLR_drift_per_year_reported_uncertainty'],
        'reported_tidal_correlation':PV_FIX['historical_LLR_tidal_correlation'],
        'scope':'Historical exposed processed summary; leading homogeneous-to-local tracking assumption. No joint independent likelihood with prior LLR EP result.'}
    pe={}
    for name,fn in [('symbolic',pe_symbolic_controls),('growth',pe_growth_controls),('linear_basis',pe_linear_basis_controls),
                    ('slow_matter',pe_slow_matter_controls),('homogeneous',pe_homogeneous_controls),
                    ('de_sitter',pe_de_sitter_controls),('EG_summary',pe_empirical_summary)]:pe[name]=fn()
    families={
        'expansion_square_bound':len(co['square_identity_grid']['rows'])>0,
        'physical_frame_evolution':len(co['direct_evolution'])==len(CO_FIX['evolution']),
        'distance_order':len(co['distance_controls'])==6,
        'processed_covariance_and_transfer':len(co['processed_data']['fixed_curves'])==3,
        'inverse_endpoint_and_cusp':len(pv['single_field_endpoint'])==len(PV_FIX['weak_couplings'])*len(PV_FIX['matter_fractions']),
        'constructed_background_and_hessian':len(pv['potential_grid'])==315,
        'full_background_tracking':len(pv['two_field_evolution'])==6,
        'local_force_relative_guards':len(pv['local_quadratic_force'])==4,
        'coupled_constraint_and_growth':len(pe['symbolic'])==4 and len(pe['growth'])==5,
        'linear_basis_and_refinement':len(pe['linear_basis'])==16,
        'short_wave_matter_response':len(pe['slow_matter'])==16,
        'nonlinear_initial_data_and_variations':len(pe['homogeneous'])==4,
        'vacuum_scalar_modes':len(pe['de_sitter'])==5,
        'exposed_lensing_velocity_summary':len(pe['EG_summary']['rows'])==3}
    failures=[{'block':name,**c} for name,rows,key in [('expansion',CO_CHECKS,'pass'),('potential',PV_CHECKS,'pass'),('perturbations',PE_CHECKS,'passed')] for c in rows if not c[key]]
    assert not failures,failures
    assert all(families.values()),families
    paths=[Path(__file__),*[ROOT/x for x in AUDIT_INPUT_PATHS]]
    result={'input_identities':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},
        'expansion':co,'potential':pv,'perturbations':pe,
        'checks':{'expansion':CO_CHECKS,'potential':PV_CHECKS,'perturbations':PE_CHECKS},
        'primitive_checks':len(CO_CHECKS)+len(PV_CHECKS)+len(PE_CHECKS),
        'check_families':families,'checks_passed':sum(families.values()),'checks_failed':sum(not x for x in families.values()),
        'scope':'Conditional supplied action and measurement bridges; processed, previously exposed comparisons; no independent empirical validation, audit status or TOE.'}
    encoded=json.dumps(result,indent=2,allow_nan=False)+'\n'
    if args.output_json:
        with args.output_json.open('x') as f:f.write(encoded)
    if args.json:print(encoded,end='')
    else:
        for name in families:print('PASS '+name)
        print('per_element: field equations, covariance entries and explicit source response checks.')
        print('per_site: frozen redshift, time, radius and homogeneous initial-data fixtures.')
        print('per_mode: metric, two scalar, dust and specified short-wave/vacuum sectors.')
        print('per_block: fourteen mathematical and processed-comparison families.')
        print('lattice_wide: checked and not executed; supplied continuum candidate only.')
        print(f'Primitive controls: expansion={len(CO_CHECKS)} potential={len(PV_CHECKS)} perturbations={len(PE_CHECKS)}; no independent observation count.')
        print('TOTAL: PASS=14 FAIL=0; conditional-support, no empirical acceptance.')

if __name__=='__main__':main()
