# Independent perturbation proof check, frozen source v1

This is a focused source and mathematical check of the parent's completed construction, not authorship of replacement theory, a formal audit, empirical acceptance, or a review of the parent's numerical integrations. All reviewer writes are confined to `independent_math_review/`. The parent remains the scientific author.

**Disposition:** the displayed field, fluid, constraint, high-frequency response and homogeneous-variation equations are correct under their stated action and background. Two narrow prose qualifications are needed before treating the source as fully settled: R1 corrects an overstatement of what constraint propagation can test; R2 makes the vacuum-sector restriction of the quoted modes explicit. Neither requires changing the equations or fixture values. Both were sent to the parent and accepted for a separately versioned clarification after this frozen review. This report does not certify the parent's subsequently reported 648 numerical checks.

## 1. Exact scope and identities

The complete `PROTOCOL.md`, `DIRECT_PERTURBATION_RESPONSE.md`, `NUMERICAL_FIXTURES.json` and `PRE_EXECUTION_PLAN_v1.json` were read and snapshotted before this checker was executed. Their exact identities are:

| Source | SHA256 |
|---|---|
| PROTOCOL.md | fdd9621b04c984cc6f1d79760dc4ae5577aa4625110076a49703bb1e58b4af5b |
| DIRECT_PERTURBATION_RESPONSE.md | 2b13996fe19af593273c29f169253c1f8efaaa42d2b7b2f0071cb8459f025bea |
| NUMERICAL_FIXTURES.json | 0d69fbbef11a6af306e9bd131528efe803339e7efd332e40b598239d735c2de5 |
| PRE_EXECUTION_PLAN_v1.json | 05d12794985954a8a781ef0a3bd25a3e8586c73abfc0dd3ef85a57a259dfa5d6 |

The previous potential proof, SHA256 `9954b28362e3e4811e8c697f108e07885fff83bc35af1a7b562782a77e548b09`, is unchanged from the completed independent potential review and is copied as `input_snapshots/PREVIOUS_DIRECT_POTENTIAL_RECONSTRUCTION.md`. Its construction is reused explicitly, not silently inferred from an expansion observation. The proposed benchmark expansion, matter normalization, conformal matter coupling, canonical two-field action and ideal weak dust remain supplied assumptions.

The parent's pre-execution record says its symbolic constraint and spatial-trace development preceded the numerical freeze. This is accurately described analytical development, not preregistration of those symbolic discoveries. The later full-integration runner and outputs were not read, imported or executed here. No approval of their tolerances, numerical accuracy or passing-family count is implied by this proof check.

## 2. Independent covariant starting point

Write b=sqrt(a), alpha=(b,0), sigma=4pi G_* rho_*, and use proper Einstein time. The scalar normalization is fixed by the action: rho_phi=(dot(phi)^2+2V)/(8pi G_*). The background equations consequently include

    dot H = -sigma - dot(phi)^2,
    ddot phi + 3H dot phi = -grad V - alpha sigma,
    dot sigma = (-3H + alpha.dot phi) sigma.

On the supplied trajectory u=0, A=1, sigma=S, v=dot chi=b sqrt(sigma), alpha.dot phi=0. Hence

    dot H=-(1+a)sigma,
    dot sigma=-3H sigma,
    dot v=-(3/2)H v,
    v^2=a sigma.

These are the identities used in the independent proper-time control. They are not general off-trajectory identities.

For the metric ds_*^2=-(1+2P)dt^2+R^2(1-2P)dx^2, homogeneous canonical fields and ideal dust have vanishing first-order traceless spatial stress. Equality of the two Einstein scalar potentials is therefore justified. The sign conventions agree with Ma-Bertschinger's conformal Newtonian metric after converting conformal time to proper time and its velocity divergence theta to the physical divergence Theta=theta/R. The present coupled scalar equation was derived directly rather than imported from that different model.

### Number and physical density

A particle's Einstein mass is m A; Einstein and physical proper number densities satisfy n_J=A^-3 n_*. If d=delta n_*/n_* and zeta=alpha.f, then

    delta rho_*/rho_* = d+zeta,
    delta rho_J/rho_J = d-3zeta,
    Psi_J=P+zeta,   Phi_J=P-zeta.

Thus Eq(1) has the correct powers of A. Confusing number contrast with Einstein rest-mass contrast would change the scalar source and the fixed-number Hessian term.

Particle-number conservation yields dot d=-Theta+3dot P. The spatial particle equation gives dot Theta+2H Theta=K^2(P+zeta). Its usual background mass-drift friction is absent here because alpha.dot(phi)=0. A perturbation of that friction times a first-order peculiar velocity is second order. Substituting delta_J=d-3zeta also gives dot(delta_J)=-Theta+3dot(Phi_J), as required by physical-frame dust conservation. These observations independently check Eq(2), including the factor 2H.

### Scalar lapse and matter source

For this equal-potential metric,

    sqrt(-g)=R^3(1-2P),
    sqrt(-g) g^00=-R^3(1-4P).

The first-order wave operator acting on a homogeneous scalar plus f is

    delta(Box phi)=-ddot f-3H dot f-K^2 f
                  +4 dot(phi) dot P+2P[ddot(phi)+3H dot(phi)].

The background bracket is -(grad V+alpha sigma)=-g. The perturbed matter source is alpha sigma(d+alpha.f), so the full linear equation is

    ddot f+3H dot f+(K^2 I+Hess V+sigma alpha alpha^T)f
       =4 dot(phi) dot P-2gP-alpha sigma d.

This establishes Eq(3), including its source sign, the fixed-number mass term and both parts of the lapse source. In particular g_u=0 on the constructed background. A lapse term containing only grad V would leave a spurious u forcing. This direct variation, rather than constraint propagation alone, carries the check of that cancellation.

## 3. Einstein constraints, trace and the exact limitation of their control

The scalar energy perturbation in these units is

    4pi G_* delta rho_phi = v dot f_chi-v^2 P+grad V.f.

The scalar momentum contributes v f_chi. The proper-time Einstein equations therefore give

    dot P+HP=sigma Theta/K^2+v f_chi,
    K^2P+3H(dot P+HP)
       =-[sigma(d+zeta)+v dot f_chi-v^2P+grad V.f],

which are Eqs(4)-(5) with no hidden field-normalization factor. The spatial trace is

    ddot P+4H dot P+(3H^2+2 dot H)P
       =v dot f_chi-v^2P-grad V.f.

Along this background grad V=(-b sigma,-3Hv/2). This trace becomes Eq(10) after conversion to N. It can also be obtained by differentiating the momentum equation, applying dust Euler and the background identities. That derivation uses no scalar acceleration equation.

Let E=H^2 C. In proper variables the energy-constraint expression is

    E=(K^2-v^2)P+sigma d+3H sigma Theta/K^2
      +v dot f_chi+(3/2)H v f_chi.

The reviewer checker differentiates E using independently assembled proper-time equations and reduces with v^2=a sigma. It obtains exactly

    dot E=-3H E.

Since E=H^2 C and d/dt=H d/dN, this is C'=(-3-2h)C. The identity holds off the energy-constraint surface as a property of the chosen evolution system. It follows that an initially vanishing C stays zero and an unscaled off-constraint E decays as R^-3. It does not make off-constraint initial data physical.

**R1, required wording correction.** The frozen sentence calling this a test of “all source and frame factors” is too strong. E has no f_u or dot f_u term. It therefore has no dependence on the u acceleration in its differentiated identity. The explicit reviewer counter-control replaces the u acceleration by the displayed equation plus an arbitrary jP; both constraint propagation and the spatial trace remain identically unchanged. Conversely adding jP to the chi acceleration changes the energy identity by j v P. This is a concrete blind spot, not a speculative objection or an error in the displayed u equation. Constraint propagation is a useful coupled-system cross-check but cannot independently validate every u-sector coefficient. The parent has agreed to state this limitation. The independent covariant variation above supplies the missing check for the actual displayed equation.

The seven first-order variables, with one energy constraint, encode six physical scalar/dust initial directions at k>0. They do not add a metric scalar propagating degree of freedom. The equations divide by Q>0. Solving the constraint specifically for P would also require Q-x^2 nonzero; that is a choice of initial-data parametrization, not an additional denominator in the stated seven-variable evolution. Exactly homogeneous modes need the separate system and cannot be obtained by setting Q=0 in these formulas.

## 4. Background matrix and normalization to N

Differentiating the supplied potential on u=0 gives

    V_u=-b sigma,
    V_chi=-(3/2)H v,
    V_uu=(1+eta)sigma,
    V_uchi=3H sqrt(sigma),
    V_chichi=(9/4)H^2+(3/2)(1+a)sigma.

Only the uu entry receives the fixed-number term a sigma. Division by H^2 yields exactly the matrix in Eq(6), including the off-diagonal 3sqrt(D) and the added aD. Both eta=0 and eta=3 equations are well defined here; an instantaneous Hessian diagnostic is not being promoted to a full time-dependent perturbation-stability theorem.

The substitutions Theta=HT, dot f=Hw, v=Hx, sigma=H^2D, K^2=H^2Q give all seven rows of Eq(7). In particular the factors (2+h) and (3+h) come from differentiating the normalizations of Theta and dot f. All seven transformations and the dimensionless constraint were checked as exact symbolic identities. The functions D', x', Q' in Eq(6) follow directly from the proper-time background identities.

The narrow potential uses a>0. The fixture with a=0 is explicitly a separate unexcited GR-dust control; it must not be described as a smooth full-potential a-to-zero limit. This distinction is present in the frozen fixtures.

## 5. High-k response, growth and a decisive free-mode control

On a bounded N interval with fixed coefficients, restrict to a sourced matter solution whose time derivatives are of order H and whose independent scalar-wave amplitudes are small enough for that expansion. Balancing the K^2 f term against -alpha sigma d first gives

    f_u=-bD d/Q+O(Q^-2 d),
    f_chi=O(Q^-2 d).

The chi source is of the next order: it comes from off-diagonal mixing and metric terms already proportional to Q^-1 d. The energy constraint then gives P=-Dd/Q+O(Q^-2 d). Consequently

    Psi_J=-(1+a)Dd/Q+O(Q^-2 d),
    Phi_J=-(1-a)Dd/Q+O(Q^-2 d),
    (Phi_J+Psi_J)/2=P.

With the separately stated local weak-body normalization G_N=G_*(1+a), the leading acceleration coefficient is mu=1, the leading lensing coefficient is Sigma=1/(1+a), and the slip is (1-a)/(1+a). Delta_J=d+O(Q^-1 d) only within this sourced-mode expansion. These are not exact finite-k coefficients.

The free-mode limitation is substantive. An explicit constraint-consistent seed at Q=10^8, a=1/2499 and D=.45/(1+a) takes

    d=1, T=f_chi=w_u=w_chi=0,
    f_u=sqrt(a), P=-D/(Q-aD).

It has C=0 to the 60-digit calculation's residual (about 3.9e-62), yet

    -Q(P+sqrt(a)f_u)/[(1+a)D d] = -88923.4590723578...

rather than one. This last expression is deliberately normalized by d and is labelled an apparent coefficient in the raw control. Using the actual physical delta_J=1-3a divides it by 1-3a and still leaves it far from one. Scaling the entire perturbation vector by 10^-6 keeps this ratio and makes every perturbation arbitrarily small; the failure is not a failure of linearization. It shows that the constraint alone and large k do not enforce the slow sourced-mode closure. The source correctly excludes independently large free scalar waves from its conclusion.

Number conservation and Euler reduce at leading order to

    d''+(2+h)d'-(1+a)Dd=0,
    (1+a)D=(3/2)Omega_m,
    Omega_m=m exp(-3N)/[m exp(-3N)+1-m].

For an independent route to the regular growing solution, set z=-(1-m)R^3/m and D_g=R F(z). The differential equation becomes

    z(1-z)F_zz+[11/6-(7/3)z]F_z-F/3=0.

Thus

    D_g=R 2F1(1/3,1;11/6;z),
    f_g=1+(6z/11) 2F1(4/3,2;17/6;z)/2F1(1/3,1;11/6;z).

This uses neither a growth-index approximation nor the parent's integrator. The Gauss-equation reduction is exact. At N=-5,-2,-1,0,1, independent 60-digit differentiated residuals have maximum absolute magnitude 1.17e-61. This does not certify the parent's approximate finite-redshift initial condition, which has a separate stated comparison tolerance in its numerical fixtures.

## 6. E_G: supported mapping and exposed diagnostic only

At leading short-wavelength order, divide -k^2(Phi_J+Psi_J) by 3H0^2 R^-1 f_g delta_J. Since sigma today is normalized relative to the supplied local G_N, the result is

    E_G=m/[(1+a)f_g].

The factor 1/(1+a) is required because lensing responds to G_* while the present matter fraction m is defined with local G_N. Keeping G_* instead of G_N in one place would change this interpretation. The equation assumes the correlated sourced matter mode and the scale and time regime already stated.

The Reyes primary paper reports an annular projected estimator Upsilon_gm/(beta Upsilon_gg), not this Fourier-space ratio itself. Its interpretation requires the stated common tracer and density mode, effectively deterministic scale-independent bias on the used scales, no unmodelled velocity bias, projection and geometry matching, source/lensing calibration and the published correction procedure. These are bridges between theory and the estimator, not consequences of the scalar action. No catalogue or supplemental correction calculation was reproduced.

Using the supplied m=.3 and z=.32 gives independently

    f_g=.6799577881129887825...

| a | E_G | Ratio to same-m GR |
|---|---:|---:|
| 0, separate GR control | .4412038588932949 | 1 |
| 10^-6 | .4412034176898772 | .999999000001 |
| 1/2499 | .4410273773497376 | .9996 |
| .01, extra mathematical fixture | .4368355038547474 | .990099009901 |

For a=1/2499 the difference is exactly .04 percent of the same-m GR prediction. The paper's exposed .392+/-.065 summary gives a raw offset of about .75427 quoted-uncertainty units for this benchmark. This is not a likelihood significance or an acceptance test: the paper separately notes an approximately5 percent lensing-calibration scale, and the present comparison has not propagated the estimator bridges or geometry uncertainty.

The paper's own quoted GR reference is about .408+/-.029, using its different matter fraction .2565+/-.018 and growth rate about .629. The parent's m=.3 benchmark is therefore not the paper's exact GR benchmark. There is no contradiction once that difference is kept explicit, and no reason to fit m to this exposed row during the check. The source protocol correctly calls this a published-summary diagnostic with no independent holdout. CMB, primordial mode selection and survey modelling remain open.

## 7. Vacuum family and its precise sector

At chi=chi_c, the supplied S(chi) and its first derivative vanish. The potential equals V_Lambda for every constant u, with zero gradient. Hence v=0, sigma=0, H_*^2=2V_Lambda/3 is a family of de Sitter solutions. At its u=0 member, the scalar Hessian eigenvalues are 0 and (9/4)H_*^2.

Restricting to delta sigma=0, linear scalar perturbations obey

    ddot(delta u)+3H_* dot(delta u)=0,
    ddot(delta chi)+3H_* dot(delta chi)+(9/4)H_*^2 delta chi=0.

The first has a constant and a decaying mode; the second has a repeated root -3H_*/2. Eq(16) follows exactly. The four listed functions were independently substituted into these equations.

**R2, vacuum-sector qualification.** If the first-order state is allowed to include a dust perturbation at the exact vacuum, then

    delta sigma=delta sigma_0 exp(-3H_*t),
    ddot(delta u)+3H_* dot(delta u)=-sqrt(a)delta sigma.

In addition to the vacuum homogeneous solution, a particular solution is

    +sqrt(a)delta sigma_0 t exp(-3H_*t)/(3H_*).

This resonant term was independently substituted and checked. Therefore Eq(16) is the vacuum scalar-sector spectrum, not the complete solution for every first-order matter perturbation of the limiting state. The parent has agreed to make delta sigma=0 explicit and state the dust-driven term. The constant u mode remains in either case, so the central conclusion about a non-isolated vacuum family is unchanged.

A neutral direction rules out asymptotic attraction to the isolated u=0 member among all neighboring vacuum members. It does not prove a large late-time displacement for every finite-dust disturbance, a probability for initial conditions, or catastrophic instability. The physical matter-calibrated scales H_J=H_*/A and G_J=G_*A^2(1+a) change along the family if particle/atomic standards are held fixed. Simply ignoring A cannot identify the family as a unique measured solution.

The log-density coordinate l=ln sigma used later covers sigma>0 and excludes the exact vacuum boundary. The separate limiting analysis is therefore needed. Nor do homogeneous fixture comparisons at fixed Einstein N automatically compare solutions at fixed physical redshift: N_J=N+ln A=N+sqrt(a)u. They remain initial-state sensitivity controls under the stated time parametrization.

## 8. Full homogeneous variation

For arbitrary positive sigma, define Y=(u,chi,v_u,v_chi,l), sigma=exp(l), and H^2=(2sigma+v^2+2V)/3. Varying this constraint directly gives

    delta H/H=[sigma delta l+v.delta v+grad V.delta phi]/(3H^2).

Varying phi'=v/H, v'=-3v-(grad V+alpha sigma)/H and l'=-3+alpha.v/H then yields exactly all lines of Eq(18). The checker differentiates the full nonlinear vector field with a general symbolic V(u,chi), compares all25 Jacobian entries to Eq(18), and gets zero for each.

Here delta l is an independent Einstein mass-density variation; holding it fixed is different from holding particle number fixed. Thus the field Hessian in the homogeneous variation is Hess V with a separate alpha sigma delta l source. Replacing delta l by d+alpha.f recovers the fixed-number sigma alpha alpha^T term in Eq(3). There is no conflict between the two formulas.

As a distinct numerical control, the reviewer builds the actual previously checked potential and nonlinear homogeneous RHS independently, then compares its analytic Jacobian with complex-step derivatives. The24 points span three couplings (10^-6,1/2499,.01), eta0/3 and four epochs, with small nonzero transverse field/velocity/density offsets. All25 entries are compared at each point. The largest error divided by max(1,abs(J_entry)) is 8.341347443009303e-16, below the pre-execution reviewer threshold2e-12. This is a local derivative check, not an integration of a basin or a global stability proof.

Positive canonical scalar kinetic and principal gradient matrices do exclude a wrong-sign high-frequency scalar kinetic/gradient term in this specified classical action. They do not exclude matter growth, infrared coupled instability, an isocurvature history, a problematic matter approximation or nonlinear evolution. A conformal physical metric shares the Einstein null cone; this cone statement does not establish an observationally complete gravitational-wave or structure-formation model.

## 9. Controls, real failures and reading boundary

`check_independent_perturbations_v1.py` was frozen before execution with SHA256 `67ee52111dabfe605b058dd093c4668a64764ffdcaab96f63f0f4cb3689ed436`. Its first execution returned exit0 with empty stderr. It contains no import or execution of a parent test function. It produced45 exact zero identities,24 complex-step Jacobian rows,5 high-precision growth rows,4 exposed E_G diagnostics, the altered-u/altered-chi controls and the constraint-compatible free-mode seed. The count45 includes the25 individual symbolic Jacobian entries and must not be described as45 independent scientific theorems. No failed scientific assertion was hidden or repaired, and no tolerance was relaxed.

Actual operational events are preserved. The parent's download receipt records an earlier urllib certificate-store failure followed by normal-TLS system-curl recovery; the reviewer used the recovered, hashed local PDFs. A pdftotext executable probe found no path; pypdf and PyMuPDF were already available. Pypdf issued14 offset-zero object warnings for the Reyes PDF. Text extraction completed, selected source pages were visually verified using independent rendering, and a captured extraction replay matched all saved texts exactly. Warnings and recovery are in `PDF_EXTRACTION_RECOVERY_v1.log` and its JSON receipt. These are parser/download events, not rejected mathematical candidates.

Primary reading was deliberately bounded:

- Ma-Bertschinger: text on PDF pages7,10,11,12,13,16; rendered pages7,11,12,16 visually inspected. Used only the metric, stress/velocity, Einstein/fluid and cold-dust conventions. Exact PDF SHA256 `8893f63227cbf374853265e43d62af19a1ba726e7e0b0b575fdeed5fb0c0575a`.
- Reyes et al.: all13 pages of extracted text read, including references and captions; rendered pages4,5,6 visually inspected. No quantitative reading of plotted pixels, catalogue reprocessing or supplemental-correction rerun. Exact PDF SHA256 `3c0f7886c8554ca2711e86b66593281f42f32aae575e26cfca48d5f69c0a5e6a`.
- Amendola: text of pages1-2 only, for title/abstract/introduction and model context. No field equation, parameter bound, attraction result or observed acceptance imported. Exact PDF SHA256 `a8dab6aa76cd1c29759540e34503b93be97ebefc5014b2591b83d10240dbd42a`.

All pages were extracted for navigation; extraction is not a claim that all pages of every paper were read. `SOURCE_READING_AND_OPERATIONS_v1.json` records the distinction, primary URLs, PDF skill path and actual operations. Exact source PDFs, page texts and inspected render images are pinned in the final receipt.

## 10. Source disposition and next bounded action

The present source demonstrates a conditional perturbative response of a supplied reconstructed background. It does not establish a TOE, a unique reconstruction from observations, empirical acceptance, a quantum origin of fluctuations, complete cosmological stability or a universal no-go result. The slow-mode and initial-condition limits are central to what is proved, not cosmetic caveats.

No change to displayed equations, fixtures, coupling values or potential is required by this check. R1 must narrow the claimed coverage of constraint propagation; R2 should explicitly limit Eq(16) to delta sigma=0 and describe the optional resonant dust forcing. The parent has undertaken a separately versioned prose correction that preserves the frozen source and numerical history. This first report remains immutable and does not pre-approve bytes that have not yet been read. A subsequent affected-source check can close those two items without rerunning the unchanged algebra.

The complete exact-source and reviewer-evidence inventory is `REVIEW_RECEIPT_v1.json`. Parent numerical integration validation, combined repository gates, any packaging and any landing remain separate from this source-only check.
