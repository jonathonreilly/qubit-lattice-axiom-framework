# Same-session affected-source confirmation: perturbation proof v2

**Disposition: R1 and R2 are resolved in the exact revised source identified below. No further mathematical or scope correction is required by this narrow check.** This confirms the four agreed prose clarifications and preservation of the prior derivation/evidence; it does not certify the parent's full numerical integrations or any canonical port, combined gate or landing.

The reviewer read the complete `DIRECT_PERTURBATION_RESPONSE_v2.md`, `PROSE_CORRECTIONS_v1_to_v2.diff` and `PROSE_CORRECTION_PLAN_v2.json`. This is the same-session continuation of `INDEPENDENT_DERIVATION_AND_REVIEW_v1.md`, SHA256 `acf12c0952577f2b19816a5e5f46216a0506c34174f26154bc7d032c8535ba0a`, and `REVIEW_RECEIPT_v1.json`, SHA256 `b757f26a75c1d09294ce9cfaae37b581e95b75834d9ab54ad75d25459281e66a`. The original report and its pending-at-that-time findings remain immutable historical records. This confirmation changes the disposition of those findings for v2 only.

## Exact revised identities

| File | SHA256 |
|---|---|
| DIRECT_PERTURBATION_RESPONSE_v2.md | cf564d0735a557c5d45cd36e6268af4b35dfbabbecde6b4d017e0ce4a23da080 |
| PROSE_CORRECTIONS_v1_to_v2.diff | 02e50c15dcfe2b6f3566c3b5914b92a3cdb303766f547be0b368126ac6de72e9 |
| PROSE_CORRECTION_PLAN_v2.json | 5128476da4ea7a1ee7b15f5206dbf886a3c1e9ffff3e2a5c628e6ec0650cf52a |

These three complete files are copied under `input_snapshots/`. The plan's old and new proof hashes match their actual bytes. Independently regenerating the unified diff from the original proof and v2 reproduces the supplied diff byte for byte.

## R1: coverage of constraint and trace checks

The revised paragraph states that the energy identity is a useful coupled-evolution cross-check, that C has no f_u or w_u term, and that changing the u acceleration leaves the identity unchanged. It expressly relies on direct covariant scalar variation to check the u equation. It also identifies the spatial trace's insensitivity to that alteration.

This exactly addresses the earlier preserved arbitrary-jP control: the u acceleration can change while both identities remain unchanged; an analogous chi-acceleration alteration produces a nonzero energy-constraint residual. The source no longer claims that constraint propagation checks every source/frame coefficient. The displayed equations remain those independently verified in the first review. **R1 is closed for v2.**

## R2: vacuum modes and optional dust forcing

The revised source explicitly restricts Eq16 to delta sigma=0 at the limiting vacuum. It then states the first-order dust decay and adds

    +sqrt(a)delta sigma_0 t exp(-3H_*t)/(3H_*)

to delta u, with the forcing equation

    ddot(delta u)+3H_*dot(delta u)=-sqrt(a)delta sigma.

The sign and coefficient agree with the exact independent substitution already preserved in `INDEPENDENT_CONTROLS_v1.json`. This is an added sector qualification and the previously checked particular solution, not a changed vacuum eigenvalue or a changed numerical model. The constant u displacement remains available, so the limited conclusion about lack of attraction to the isolated vacuum member is unchanged. **R2 is closed for v2.**

## Two additional scope clarifications

The added log-density statement correctly limits l=ln sigma to sigma>0 and distinguishes the exact vacuum boundary. No invalid use of that coordinate at sigma=0 is introduced.

The added time-comparison statement correctly warns that a fixed Einstein N is not automatically a fixed physical redshift comparison. N_J=N+sqrt(a)u is the logarithm of the physical scale factor; converting it to redshift also uses a common observation-time normalization. The warning preserves the intended interpretation of finite-time histories as fixture sensitivities, not equal-redshift observational predictions. It does not change the variational equations or promote any gain/drift to an empirical bound.

## Preservation checks and exact scope of those checks

The original proof remains SHA256 `2b13996fe19af593273c29f169253c1f8efaaa42d2b7b2f0071cb8459f025bea`. All47 pre-existing indented mathematical lines are present unchanged and in order in v2. The only added indented mathematical line is the previously checked resonant dust particular solution above. All18 numbered equation groups are unchanged. The correction plan's statement that equations/numerical source are unchanged is therefore read as preservation of the existing equations and numerical source; it separately and accurately lists the added explanatory dust solution.

Every one of the20 files pinned by `AUTHOR_BLOCK_FREEZE_v1.json` matches its original hash, including the original proof, fixtures, protocol, author runner, results, source snapshots and execution records. The freeze receipt itself is copied and pinned here. The unchanged author runner is SHA256 `cd20f3f7361fcc1c2fb0b01ee15636620f102b8e6f16d2a0c9f916141da23519`; the unchanged first result JSON is `5b3d0d04c677b7074e0b0b51d8ce1427fc34e3b9fcd5e7506ae4cd94a37e00cd`. These are byte-preservation checks against the author's original freeze, not a semantic review of that runner or validation of its result rows.

Every one of the106 files inventoried by the previous independent review receipt still matches its recorded byte count and SHA256. The previous receipt itself also retains its exact recorded hash. Thus the first report, independent control source/results, source snapshots, primary-source reading record and actual operational-warning evidence remain intact. The correction requires no rerun of the unchanged algebra, and no algebra or numerical integration was run in this affected-source pass.

`IDENTITY_AND_DIFF_CHECKS_v1.json` contains all compared paths/hashes, diff equality, mathematical-line comparison and counts. All mechanical comparisons passed; no failed assertion or revised threshold was suppressed. New writes are confined to `independent_math_review/affected_v2/`.

## Final boundary

The source-only mathematical disposition is now satisfactory for the supplied action/background and the stated asymptotic, vacuum and estimator premises. Empirical acceptance, a complete primordial history, global coupled stability, a unique observational reconstruction and a TOE remain outside the result. The separate parent numerical review and any future canonical-port/source-composition check retain their own scope. No Git/GitHub action, formal audit, new worker, source mutation, combined validation or landing was performed. The next canonical-port check has not started; it requires the parent's complete frozen source.
