#!/usr/bin/env python3
"""Independent proper-time constraint, variational and growth controls."""
from pathlib import Path
import json,datetime,math
import sympy as sp
import numpy as np
import mpmath as mp
O=Path(__file__).resolve().parent
mp.mp.dps=60
b,H,s,v,k2=sp.symbols("b H s v k2",positive=True)
eta=sp.symbols("eta",real=True)
P,d,th,fu,fc,ru,rc=sp.symbols("P d th fu fc ru rc",real=True)
Y=sp.Matrix([P,d,th,fu,fc,ru,rc])
pdot=-H*P+s*th/k2+v*fc
muu=(1+eta+b*b)*s
muc=3*H*v/b
mcc=sp.Rational(9,4)*H*H+sp.Rational(3,2)*(1+b*b)*s
F=sp.Matrix([pdot,-th+3*pdot,-2*H*th+k2*(P+b*fu),ru,rc,
 -3*H*ru-(k2+muu)*fu-muc*fc-b*s*d,
 -3*H*rc-muc*fu-(k2+mcc)*fc+4*v*pdot+3*H*v*P])
bg={H:-(1+b*b)*s,s:-3*H*s,v:-sp.Rational(3,2)*H*v,k2:-2*H*k2}
def reduce_relation(x):
 n,den=sp.together(sp.expand(x)).as_numer_denom()
 return sp.simplify(sp.rem(n,v*v-b*b*s,v)/den)
def dt(x,flow=F):
 return sum(sp.diff(x,z)*dz for z,dz in zip(Y,flow))+sum(sp.diff(x,z)*dz for z,dz in bg.items())
exact={}
def zero(name,x,reduce=True):
 y=reduce_relation(x) if reduce else sp.simplify(x)
 assert y==0,(name,str(y))
 exact[name]=str(y)
energy=(k2-v*v)*P+s*d+3*H*s*th/k2+v*rc+sp.Rational(3,2)*H*v*fc
zero("proper_time_energy_propagation",dt(energy)+3*H*energy)
zero("proper_time_spatial_trace",dt(pdot)+4*H*pdot+(3*H*H-2*(1+b*b)*s)*P
 -(v*rc-v*v*P+sp.Rational(3,2)*H*v*fc+b*s*fu))
# Verify the lapse source by independent linearized covariant Box expansion.
# delta Box = -fddot-3H fdot-K^2 f+4v Pdot+2P(background ddot phi+3H v).
# Background acceleration is -g, so the lapse coefficient is -2g.
Bg,g,Pot,Src=sp.symbols("Bg g Pot Src")
zero("lapse_includes_potential_and_source",(2*P*Bg).subs(Bg,-Pot-Src)+2*P*(Pot+Src),False)
# Exact change from proper time to N, including velocity normalizations.
D,Q,x,T,wu,wc=sp.symbols("D Q x T wu wc",real=True)
change={s:D*H**2,k2:Q*H**2,v:x*H,th:T*H,ru:wu*H,rc:wc*H}
hh=-(1+b*b)*D
pN=-P+D*T/Q+x*fc
target=sp.Matrix([pN,-T+3*pN,-(2+hh)*T+Q*(P+b*fu),wu,wc,
 -(3+hh)*wu-(Q+(1+eta+b*b)*D)*fu-3*x*fc/b-b*D*d,
 -(3+hh)*wc-3*x*fu/b-(Q+sp.Rational(9,4)+sp.Rational(3,2)*(1+b*b)*D)*fc+4*x*pN+3*x*P])
normalized=sp.Matrix([
(F[0]/H).subs(change),(F[1]/H).subs(change),
(F[2]/H**2).subs(change)-hh*T,
(F[3]/H).subs(change),(F[4]/H).subs(change),
(F[5]/H**2).subs(change)-hh*wu,(F[6]/H**2).subs(change)-hh*wc])
for i in range(7):zero("N_transform_"+str(i),normalized[i]-target[i],False)
C=(Q-x*x)*P+D*d+3*D*T/Q+x*wc+sp.Rational(3,2)*x*fc
zero("dimensionless_constraint",energy.subs(change)/H**2-C,False)
# A concrete blind spot: arbitrary alteration of the u-acceleration is invisible
# to this constraint and spatial trace on v_u=0.
j=sp.symbols("j",real=True)
Fbad=F.copy();Fbad[5]+=j*P
zero("altered_u_keeps_constraint_identity",dt(energy,Fbad)+3*H*energy)
zero("altered_u_keeps_spatial_trace",dt(pdot,Fbad)+4*H*pdot+(3*H*H-2*(1+b*b)*s)*P
 -(v*rc-v*v*P+sp.Rational(3,2)*H*v*fc+b*s*fu))
assert sp.diff(energy,ru)==0 and sp.diff(energy,fu)==0
# A relevant alteration of the chi lapse term is detected.
Fbadchi=F.copy();Fbadchi[6]+=j*P
badchi=reduce_relation(dt(energy,Fbadchi)+3*H*energy)
zero("changed_chi_lapse_residual",badchi-j*v*P)
# Full homogeneous first variation for an arbitrary smooth potential.
U,X,VU,VX,l=sp.symbols("U X VU VX l",real=True)
A=sp.Function("V")(U,X);rho=sp.exp(l)
Hb=sp.sqrt((2*rho+VU**2+VX**2+2*A)/3)
gu=sp.diff(A,U)+b*rho;gc=sp.diff(A,X)
Fhom=sp.Matrix([VU/Hb,VX/Hb,-3*VU-gu/Hb,-3*VX-gc/Hb,-3+b*VU/Hb])
Z=sp.Matrix([U,X,VU,VX,l])
Jdirect=Fhom.jacobian(Z)
for col in range(5):
 e=sp.eye(5)[:,col];dU,dX,dVU,dVX,dl=list(e)
 dHH=(rho*dl+VU*dVU+VX*dVX+sp.diff(A,U)*dU+sp.diff(A,X)*dX)/(3*Hb**2)
 dphi=sp.Matrix([dVU/Hb-VU*dHH/Hb,dVX/Hb-VX*dHH/Hb])
 dvel=sp.Matrix([-3*dVU-(sp.diff(A,U,2)*dU+sp.diff(A,U,X)*dX+b*rho*dl)/Hb+gu*dHH/Hb,
                 -3*dVX-(sp.diff(A,X,U)*dU+sp.diff(A,X,2)*dX)/Hb+gc*dHH/Hb])
 stated=sp.Matrix([dphi[0],dphi[1],dvel[0],dvel[1],b*dphi[0]])
 for row in range(5):zero("homogeneous_J_"+str(row)+"_"+str(col),Jdirect[row,col]-stated[row],False)
# Vacuum spectrum including the optional first-order dust forcing.
time,s0=sp.symbols("time s0",positive=True)
zero("vacuum_u_constant",sp.diff(sp.Integer(1),time,2)+3*H*sp.diff(sp.Integer(1),time),False)
zero("vacuum_u_decay",sp.diff(sp.exp(-3*H*time),time,2)+3*H*sp.diff(sp.exp(-3*H*time),time),False)
for label,mode in [("simple",sp.exp(-sp.Rational(3,2)*H*time)),("repeated",time*sp.exp(-sp.Rational(3,2)*H*time))]:
 zero("vacuum_chi_"+label,sp.diff(mode,time,2)+3*H*sp.diff(mode,time)+sp.Rational(9,4)*H**2*mode,False)
forced=b*s0*time*sp.exp(-3*H*time)/(3*H)
zero("vacuum_dust_resonant_forcing",sp.diff(forced,time,2)+3*H*sp.diff(forced,time)+b*s0*sp.exp(-3*H*time),False)
# Hypergeometric regular growth is derived by substituting D_g=R F(z),
# z=-(1-m)R^3/m into the growth equation, not a growth-index fit.
z,FF,FFz,FFzz=sp.symbols("z FF FFz FFzz")
Om=1/(1-z)
growth=(FF+15*z*FFz+9*z*z*FFzz)+(2-sp.Rational(3,2)*Om)*(FF+3*z*FFz)-sp.Rational(3,2)*Om*FF
gauss=z*(1-z)*FFzz+(sp.Rational(11,6)-sp.Rational(7,3)*z)*FFz-FF/3
zero("growth_to_gauss_equation",(1-z)*growth/(9*z)-gauss,False)
def regular_growth(n,m=mp.mpf("0.3")):
 R=mp.exp(n); zz=-(1-m)*R**3/m
 f0=mp.hyp2f1(mp.mpf(1)/3,1,mp.mpf(11)/6,zz)
 f1=mp.hyp2f1(mp.mpf(4)/3,2,mp.mpf(17)/6,zz)
 return R*f0,1+6*zz*f1/(11*f0)
growth_rows=[]
for n in [-5,-2,-1,0,1]:
 mn=mp.mpf(n)
 value,fg=regular_growth(mn)
 hval=-mp.mpf("1.5")/(1+mp.mpf(7)/3*mp.exp(3*mn))
 deriv=mp.diff(lambda t:regular_growth(t)[0],mn)
 second=mp.diff(lambda t:regular_growth(t)[0],mn,2)
 residual=second+(2+hval)*deriv+hval*value
 assert abs(residual)<mp.mpf("1e-50")
 growth_rows.append({"N":n,"Dg":str(value),"fg":str(fg),"ode_residual":str(residual)})
nobs=-mp.log(mp.mpf("1.32"));dg,fg=regular_growth(nobs)
eg_rows=[]
for av in [mp.mpf(0),mp.mpf("0.000001"),mp.mpf(1)/2499,mp.mpf("0.01")]:
 val=mp.mpf("0.3")/((1+av)*fg)
 eg_rows.append({"a":str(av),"z":"0.32","fg":str(fg),"EG":str(val),"ratio_to_same_m_GR":str(1/(1+av)),
 "offset_in_reported_0p065_units":str((val-mp.mpf("0.392"))/mp.mpf("0.065")),
 "calibration_fraction_separate":"0.05"})
# Constraint-compatible large free-u initial displacement defeats a blanket
# high-k closure even at arbitrarily small overall physical amplitude.
av=mp.mpf(1)/2499;Dv=mp.mpf("0.45")/(1+av);Qv=mp.mpf("1e8")
pv=-Dv/(Qv-av*Dv);fuv=mp.sqrt(av)
cf=(Qv-av*Dv)*pv+Dv
apparent=-Qv*(pv+mp.sqrt(av)*fuv)/((1+av)*Dv)
assert abs(cf)<mp.mpf("1e-50") and abs(apparent-1)>1
# Independent complex-step check of the full nonlinear homogeneous Jacobian.
# These functions are reviewer-owned and do not import the parent.
a0,eta0,m0=sp.symbols("a0 eta0 m0",positive=True)
kap=sp.sqrt(3*(1+a0)/(2*a0));center=sp.asinh(sp.sqrt(m0/(1-m0)))/kap
Sc=sp.Rational(3,2)*(1-m0)/(1+a0)*sp.sinh(kap*(X-center))**2
pot=sp.Rational(3,2)*(1-m0)+Sc*((U-sp.sqrt(a0))**2+eta0*U**2)/2
Hs=sp.sqrt((2*sp.exp(l)+VU**2+VX**2+2*pot)/3)
Rh=sp.Matrix([VU/Hs,VX/Hs,-3*VU-(sp.diff(pot,U)+sp.sqrt(a0)*sp.exp(l))/Hs,
              -3*VX-sp.diff(pot,X)/Hs,-3+sp.sqrt(a0)*VU/Hs])
rhs=sp.lambdify((a0,eta0,m0,U,X,VU,VX,l),Rh,"numpy")
jac=sp.lambdify((a0,eta0,m0,U,X,VU,VX,l),Rh.jacobian(Z),"numpy")
jac_rows=[]
for avf in [1e-6,1/2499,0.01]:
 for etaf in [0.0,3.0]:
  for N in [-1.0,0.0,1.0,3.0]:
   mv=.3;kv=math.sqrt(3*(1+avf)/(2*avf));cc=math.asinh(math.sqrt(mv/(1-mv)))/kv
   sv=1.5*mv/(1+avf)*math.exp(-3*N);hh=math.sqrt(mv*math.exp(-3*N)+1-mv)
   y=np.array([.07*math.sqrt(avf),cc-math.asinh(math.sqrt(mv/(1-mv))*math.exp(-1.5*N))/kv+.03*math.sqrt(avf),
              -.02*math.sqrt(avf)*hh,math.sqrt(avf*sv)*(1.02),math.log(sv)+.02])
   analytic=np.asarray(jac(avf,etaf,mv,*y),float)
   cs=np.empty((5,5))
   for col in range(5):
    cy=y.astype(complex);cy[col]+=1e-25j
    cs[:,col]=np.imag(np.asarray(rhs(avf,etaf,mv,*cy),complex).reshape(5))/1e-25
   err=np.max(np.abs(analytic-cs)/np.maximum(1,np.abs(analytic)))
   assert err<2e-12,(avf,etaf,N,err)
   jac_rows.append({"a":avf,"eta":etaf,"N":N,"max1_normalized_error":float(err)})
result={
"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"scope":"Reviewer derivation/control only; no author imports or full linear/nonlinear author integrations.",
"exact_symbolic_zero_identities":exact,
"constraint_control":{"proper_time":"d(H^2 C)/dt=-3H(H^2 C)","changed_u_acceleration":"Add arbitrary j P to r_u dot; both constraint and trace identities remain unchanged.",
"changed_chi_acceleration":"Add j P to r_chi dot; constraint residual is j v P.",
"required_scope_correction":"Constraint propagation is not an independent check of every u-sector term."},
"vacuum_dust_qualification":"Eq16 is delta sigma=0 vacuum scalar spectrum. Delta sigma=sigma0 exp(-3Ht) adds sqrt(a)sigma0 t exp(-3Ht)/(3H) to delta u.",
"growth_rows":growth_rows,"exposed_EG_diagnostics":eg_rows,
"free_scalar_wave_control":{"a":str(av),"D":str(Dv),"Q":str(Qv),"P":str(pv),"f_u":str(fuv),"C":str(cf),"apparent_mu":str(apparent),"overall_state_can_be_scaled_to_1e_minus_6":True},
"homogeneous_complex_step_rows":jac_rows,
"parent_runner_imported":False,"parent_runner_executed":False,
"empirical_acceptance_claimed":False,"global_stability_claimed":False}
with(O/"INDEPENDENT_CONTROLS_v1.json").open("x") as f:json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
print(json.dumps({"symbolic_identities":len(exact),"homogeneous_complex_step_cases":len(jac_rows),
"max_jacobian_max1_error":max(r["max1_normalized_error"] for r in jac_rows),
"constraint_blind_spot_preserved":True,"EG_rows":eg_rows,
"free_wave_apparent_mu":str(apparent)},indent=2))

