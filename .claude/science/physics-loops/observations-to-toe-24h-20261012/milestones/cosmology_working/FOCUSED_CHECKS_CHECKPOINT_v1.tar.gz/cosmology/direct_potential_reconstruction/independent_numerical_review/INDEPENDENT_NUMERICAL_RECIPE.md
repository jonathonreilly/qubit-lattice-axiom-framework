# Independent numerical recipe for the frozen potential reconstruction

This is a check of the parent's supplied candidate. No author helper is imported
or called by independent_potential_check.py. The separate copied-runner mutation
experiment measures control sensitivity only and is not scientific validation.
The standalone analytic-proof review is a separate task.

I use the exact frozen binary64 fixture values as the inputs to 80-decimal-digit
mpmath calculations. Floats are converted directly to multiprecision values,
retaining their actual binary values. The independent checking plan and tolerances
were saved in REVIEW_PLAN_v1.json before running the numerical comparison.

For the one-field endpoint, rescale the small variables as X=zeta/a and W=p/a.
The parent equation is equivalent to

    X'=W,
    W'=h [a-expm1(2aX)]/[a(1+a)] +(1-h)W +(1-a)W^2,
    h=-(3/2)m exp(-3n)/[m exp(-3n)+1-m].

This removes the direct subtraction h+D between quantities of order unity whose
difference is order a. At n=0, X=W=0 and W'=-D0. The independent implementation
uses implicit Radau rather than the parent's DOP853 integration, with scaled
variables, rtol=5e-14 and atol=1e-18. Two maximum-step caps are recorded; both
produce the same sampled states here. That coincidence alone is not an error
certificate or evidence that the step cap was active.

To check potential derivatives without reproducing the parent's Klein-Gordon
helper formula, define the recovered potential directly as a function F(n,X,W):

    E^2=m exp(-3n)+1-m,
    D=(3/2)m exp(2aX-3n)/[(1+a)E^2],
    F=exp(2aX)E^2 [3(1-aW)^2-aW^2-2D]/2.

Let the flow f=(1,W,W') and g=grad(F). At each of the 42 negative-n sites,
80-digit differentiation gives

    V'=g.f,
    V''=f^T Hess(F) f+g.(Df f),
    phi'=sqrt(a)W,  phi''=sqrt(a)W',
    V_phi=V'/phi',
    V_phiphi=(V''phi'-V'phi'')/(phi')^3.

No division at the turning point itself is made. These expressions independently
check every displayed potential, gradient, Hessian and cusp-ratio row. The exact
endpoint compatibility claim remains a proof statement; the divergent one-sided
curvature is a numerical corroboration, not a replacement for that proof. The
source's endpoint-gradient expression contains a cancellation whose loss of
digits is visible in the comparisons and retained in the report.

For the two-field potential, I evaluate the polynomial in expanded form and
represent S using expm1:

    V=V_Lambda+S[(1+eta)u^2-2sqrt(a)u+a]/2,
    S=V_Lambda {expm1(2t)+expm1(-2t)}/[4(1+a)],
    t=k(chi-chi_c).

All Hessian entries are obtained by 80-digit differentiation of this function,
not by copying the parent's entry formulas. For each of the 315 frozen rows I
compare chi, S, H, chi-dot, V, the full Hessian, both eigenvalues, determinant,
required eta and curvature classification. The scalar equations and Friedmann
constraint are checked with the independent differentiated potential. Six
off-trajectory u samples per row check the displayed nonnegative-potential
behavior; they are finite controls, not a global-convexity proof.

For a symmetric matrix [[A,B],[B,C]], the independent eigenvalue calculation is

    delta=sqrt[(A-C)^2+4B^2],
    lambda_hi=(A+C+delta)/2,
    lambda_lo=(AC-B^2)/lambda_hi.

The product formula avoids subtracting two nearly equal numbers for the small
root. The parent eigenvalues at late grid points show expected double-precision
conditioning; the largest observed relative discrepancy is 3.27e-10. All curvature
classifications agree, including the retained eta=0 failure.

The full homogeneous check uses Einstein proper time tau=H0 t_* rather than the
parent's N_* integration coordinate. State variables are (N,u,chi,v_u,v_chi,
sigma,t_J), where sigma=4pi G_*rho_*/H0^2 and velocities are divided by H0. The
independent equations are

    H=sqrt[(2sigma+v_u^2+v_chi^2+2V)/3],
    dN/dtau=H,
    du/dtau=v_u,  dchi/dtau=v_chi,
    dv/dtau=-3Hv-grad(V)-alpha sigma,
    dsigma/dtau=(-3H+sqrt(a)v_u)sigma,
    dt_J/dtau=exp(sqrt(a)u).

The gradient is evaluated with complex-step derivatives of the independently
expanded potential, not the parent's hand-coded gradient. Radau evolves u as a
degree of freedom. It is never clamped to zero. Starting on the supplied exact
trajectory, the proper-time coordinate corresponding to target N is

    tau(N)=2/[3sqrt(1-m)] times
           {asinh[sqrt((1-m)/m) exp(3N/2)]-asinh[sqrt((1-m)/m)]}.

At these 54 physical times I compare the integrated N, physical clock, dust
first integral and all fields to both sets of stored author states, giving 108
author-state comparisons. Reconstruction uses n_J=N+sqrt(a)u,
H_J=(H+sqrt(a)v_u)/A and G_J/G_J0=A^2. No attraction or perturbed-data robustness
claim follows from starting on the exact solution.

For the local mass diagnostic, the differentiated Hessian is used directly.
At fixed Einstein particle-number density, rho_*(u) is proportional to
exp(sqrt(a)u). Differentiating its effective source potential twice contributes
sigma a to the uu entry, equivalently S alpha alpha^T. Holding another density
or including dynamical dust/metric response is a different closure; this check
does not replace those responses by a fixed-number assumption.

The independent spectral residues follow from projectors instead of numerical
eigenvectors:

    a_lo=a(lambda_hi-A)/(lambda_hi-lambda_lo),
    a_hi=a(A-lambda_lo)/(lambda_hi-lambda_lo).

They are positive for these matrices, sum to a, and satisfy
sum(a_j lambda_j)=a M_uu. The canonical scalar Green equation has mass matrix
Hess(V); there is no extra factor of two in the mass. Consequently the screened
scalar force multiplier is (1+x)exp(-x), x=mu r. The dimensionless x used in the
tables is sqrt(lambda_j) H0 r/c. H0 is the explicitly supplied illustrative scale.

For x<.1 I compute the deficit by the convergent series

    1-(1+x)exp(-x)
      =sum from n=2 to infinity of (-1)^n (n-1)x^n/n!.

For larger x I use the 80-digit closed expression. Every nonzero force row is
compared relatively, with no absolute tolerance floor that could admit zero.
The four zero-radius rows are checked as exact zeros. This avoids unstable
binary64 subtraction of values close to one and independently confirms the
parent's stable scaled-integral approach.

A simple additional bound exposes the original control gap. Since

    f(x)=x^2 integral_0^1 t exp(-xt)dt,
    exp(-x)x^2/2 <= f(x) <= x^2/2,

positive residues imply, with U=sum(a_j x_j^2)/[2(1+a)],

    exp[-max(x_j)] U <= deficit <= U.

For all frozen positive radii U>0 and max(x_j) is finite and modest. A relative
lower-bound assertion therefore rejects a false zero even when U is of order
1e-59. The existing parent checks use only the nonnegative upper bound in that
regime; the independent mutation demonstrates the resulting blind spot. This
proposed guard is a separate author correction, not an edit made by the reviewer.

Finally, the historical LLR row is a scalar arithmetic check of (observed-zero)
divided by the reported uncertainty, namely 4/9. The leading homogeneous
coefficient A^2(1+a) is constant on this solution. That is not a proof of an
exact separation-dependent local force drift or of environmental tracking.
The original PDF's Eq9 and its tidal-parameter correlation statement were read
from the pinned external source. No raw ranges, new fit, independent holdout or
joint score with the prior EP row is supplied by this block.
