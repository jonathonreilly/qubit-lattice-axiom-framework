# Focused independent potential reconstruction numerical review

Reviewer: direct_field_check. Parent remains the author. This review covers
implementation, independent numerical recomputation, control sensitivity, exact
input lineage and the limited empirical readout. The separate focused checker
handles the complete analytic proof. No formal audit or retained-status change
is made here, and no author file has been edited.

There is one required control improvement in the frozen runner, despite correct
current numerical values. At check_potential_reconstruction.py lines249–254, the
tiny-force assertions accept zero for a nonzero positive-radius correction:
only an upper bound is checked below H0*r/c=1e-3. I changed only those reported
deficits to zero in an isolated copied runner. All 1,494 author checks still pass,
while 20 nonzero force rows change, including all 16 illustrative physical-radius
rows. Exact mutated source, output, stdout/stderr and the full patch are preserved
in mutations_v2. This is an assertion-sensitivity defect, not evidence that the
original reported force values are wrong.

The narrow requested correction is to add a stable positive or relative lower
bound for these nonzero radii and require the same mutant to fail. For example,
the integral already used in the source implies

    exp[-max(mu_j*r)] * upper <= force_deficit <= upper.

The lower bound is numerically safe for the frozen controls. A dimensionless
ratio check can enforce it without subtracting nearly equal exponentials or
using a large absolute tolerance. Parent was notified and will preserve v1 before
authoring a new guarded version. That version has not been reviewed here.

All current reported numerical values reproduce. The independent calculation
passes 6,926 checks, and 59 lineage/receipt checks pass. The full comparison was
executed once, in about 5.47 seconds including process startup, using one BLAS
thread. The independent runner never imports or calls the parent's functions.
Its mathematical recipe, tolerances and complete outputs are preserved in
INDEPENDENT_NUMERICAL_RECIPE.md, REVIEW_PLAN_v1.json and INDEPENDENT_RESULTS_v1.json.
The copied-runner mutation is explicitly separate from this independent evidence.

Coverage includes all six one-field histories and all 42 endpoint sites; all 315
potential/background grid rows; six full homogeneous fixtures and all 108 stored
rows across the two author refinements; all four local quadratic matrices; all
40 force rows; every historical-drift numeric field; all 1,494 author trace records;
and all original source, freeze, result and log files. The 18 parent-manifest
members plus the manifest itself are preserved byte for byte under snapshots_v1.
The code, protocol, proof, fixtures, source ledger, scope, certificate and trace
files were read completely. Scientific comparison concerns the displayed result
classes; the author's symbolic expressions are read in context, with the full
analytic proof assessed separately.

The endpoint computation uses X=zeta/a, W=p/a and an expm1 expression for the
canceling inverse source, followed by implicit Radau integration. Independent
80-digit total derivatives of the recovered V(n,X,W), divided by the nonzero
past-branch phi', yield V_phi and V_phiphi. This does not reuse the author's C
formula or gradient/Hessian helper. All signs and cusp ratios agree. At the
closest site n=-1e-4, the independent curvature ratios to -4/n lie between
1.000175004 and 1.000250043, comfortably inside the frozen 0.002 criterion.

There is a numerical conditioning limit worth retaining. At a=1e-6, m=.4,
n=-1e-4, the author's V_phi/H0^2 is -2.4003112216738033e-7; the independent result
is -2.4003096340291887e-7. The relative difference is 6.6143e-7, from subtraction
in the original derivative expression. The largest absolute curvature difference
is 5.971e-5 in a quantity around 4e4. This changes no sign, endpoint inference or
frozen cusp test, and is not a requested source correction. It does mean the
many printed digits in those derivative rows are not all accurate. The scaled
independent route avoids the leading h+D cancellation.

Every potential Hessian is independently differentiated from the expanded
potential at 80-digit precision. A closed-form 2x2 eigenvalue calculation, using
determinant/larger-root for the small root, independently checks the eigensystem.
All 63 eta=0 rows have a negative eigenvalue. The counts with positive minimum
eigenvalue are 0, 0, 21, 63, 63 for eta=0,1,2,3,4 respectively. All315 curvature flags
and eta thresholds agree. The largest absolute grid discrepancy is 2.274e-13;
the largest relative eigenvalue discrepancy, at a small late-time eigenvalue,
is 3.270e-10. The original unstable eta=0 candidate is present in the frozen
protocol, pre-execution evidence and results rather than silently discarded.
These are trajectory-Hessian checks, not global convexity or full cosmological
perturbation stability.

The homogeneous evolution is independently integrated in Einstein proper time,
not the author's e-folding coordinate. The scalar gradient is obtained by
complex-step differentiation of the expanded potential, H by Friedmann, and both
scalar fields remain dynamic. The exact chosen expansion supplies an independent
cosmic-time map for all 54 sample sites. Mapping the integration back to the
author's state representation compares all 108 saved states, H_J, G_J/G_J0,
physical n and the stored diagnostics. The largest state difference is 3.631e-12;
the largest difference between the independently integrated N and its exact
target is 1.466e-14. Dust conservation and the physical clock agree. Relative
differences of roundoff-sized nominally zero u components are not treated as
physical discrepancies. No initial-condition perturbation, basin of attraction
or environmental matching experiment is inferred from these runs.

The local mass residues are obtained independently from analytic spectral
projectors, without using the author's eigenvectors. They are positive, sum to
a, and satisfy the mass-weighted sum rule. The separate fixed-number-dust term
is confirmed by differentiating sigma0 exp(sqrt(a)u) twice, giving a*sigma0 in
the uu entry. This closure holds Einstein particle-number density fixed; it is
not the complete dynamical dust/metric response.

At the supplied weak a=1/2499 and m=.3, the independent masses squared/H0^2 are

| Local quadratic choice | Smaller eigenvalue | Larger eigenvalue |
| --- | ---: | ---: |
| Bare potential Hessian | 0.272835958075991261 | 4.451444041924008647 |
| Plus fixed-number dust | 0.272950202342443540 | 4.451509797657556369 |

For each of the 40 force rows I independently recompute the scale H0*r/c, both
mode arguments, the positive residues, the force deficit and its bound. The
small-argument series for 1-(1+x)exp(-x) and 80-digit arithmetic avoid cancellation.
No absolute comparison floor is used for the nonzero deficits. The largest
relative disagreement with the author is 1.262e-15. At H0=2.3e-18/s and
r=1.5e11m, the two independent deficits are

    bare: 4.7656871874940693067e-34,
    fixed-number dust: 4.7661639469165877211e-34.

The original stable quadrature therefore computes these tiny numbers correctly.
The assertions are what need strengthening. The independent comparison and
positive lower-bound control reject every nonzero zero-deficit mutation.
These scalar-mass corrections bound only the specified frozen flat-patch Green
response. They do not bound omitted curvature, time evolution, density response,
metric effects or every order-H^2*r^2 contribution. Leading massless matching is
not an exact finite-separation gamma or G relation in the massive construction.

The historical LLR numbers and 0.74 tidal-parameter correlation match the pinned
primary PDF, page 3 Eq9 and adjacent text. The observed-minus-zero standardized
residual is 4/9. The PDF SHA256 is
569be464a1e80ae07d6573ad846eff17a7b839e0a750838ec90854d1421c9a53.
It remains solely in the external primary-recovery location, recorded in
EXTERNAL_PRIMARY_PIN_v1.json. No raw LLR ranges or new likelihood were used.
The zero here is the leading homogeneous A^2(1+a) coefficient drift, conditional
on the local tracking/weak-source bridge. It does not establish exact zero drift
of a separation-dependent massive force. The correlation and overlap with the
previous EP analysis preclude treating this as a new independent likelihood.

The empirical scope is correctly limited. The expansion curve with m=.3 was an
already exposed comparison input. The potential, positive energy scale, extra
field, eta, matter normalization and initial conditions are supplied to reproduce
that curve. Other m values and a=.01 are mathematical controls. This block reads
no new supernova target arrays and performs no new shape fit. It cannot inherit
an independent empirical success merely by reproducing its selected benchmark.
Vacuum-scale prediction, source luminosity, full perturbations, compact-body
solutions, local environmental matching and ultraviolet completion remain open.

Lineage checks verify the pre-execution plan, executed-source freeze, all source
snapshots, the 18-file author manifest, source hashes embedded in the original
result, all stdout summary fields, original log disposition and the external
primary hash. The recorded plan at 03:01:14Z precedes the source freeze and first
recorded execution at 03:07:05Z. All 19 current original paths still match the
initial snapshots. Recorded identities do not independently establish the absence
of unrecorded earlier activity; the exposed data role is explicit throughout.

All actual reviewer failures remain preserved. The first mutation harness used a
different copied-runner filename while pointing ROOT at the frozen inputs, so
the author's source-hash loop sought a nonexistent filename and stopped before
numerical checks. Its script, stdout/stderr and HARNESS_FAILURE.json are retained
in mutations_v1. The outer harness then could not read the absent RESULT file;
that was a harness failure, not a physics mismatch. The corrected mutation
harness keeps the original filename and colocates exact input copies, so its
result hashes identify its actually executed mutated source. It exposes the
20-row blind spot while preserving all 1,494 passing assertions. The independent
scientific recomputation itself passes on its first execution.

The frozen author runner SHA256 is
7500db2bc416cce20ea945bfd827b3f45eaf8de2a4d5ea9407fe9e2b1eecac0b;
the original result SHA256 is
ccef4eb39354259528a0135e634232eda965fb5b54557ffd44a89ac5d3a5f9a2.
ORIGINAL_DISPOSITIONS_v1.json provides complete original/final path hashes and
recoveries. RECEIPT.json binds this report, numerical recipe, exact code and
executed sources, independent results, mutation success/failure evidence,
primary-source receipt and all snapshots. The tiny-force assertion gap is the
only requested author change and remains open for the later affected-source
review. Nothing in this report alters the original science bytes or applies an
audit label.
