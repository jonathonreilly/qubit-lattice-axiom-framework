#!/usr/bin/env python3
"""Narrow correction check; no new scientific reconstruction or baseline replay."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import math
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
PRIOR=HERE.parent
ROOT=PRIOR.parent
SNAP=HERE/'snapshots'
checks=[]


def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def check(name,yes,**evidence):checks.append({'name':name,'pass':bool(yes),**evidence})


def main():
    if (HERE/'RESULTS.json').exists():raise FileExistsError('RESULTS.json')
    pins=load(HERE/'SOURCE_PINS.json')
    for row in pins['sources']:
        check('affected_source_and_recovery_'+row['path'],(ROOT/row['path']).read_bytes()==(HERE/row['snapshot']).read_bytes()
              and sha((HERE/row['snapshot']).read_bytes())==row['sha256'])
    for row in load(PRIOR/'SOURCE_PINS_v1.json')['sources']:
        check('original_v1_unchanged_'+row['path'],sha((ROOT/row['path']).read_bytes())==row['sha256']
              and sha((PRIOR/row['snapshot']).read_bytes())==row['sha256'])
    for row in load(PRIOR/'RECEIPT.json')['evidence']:
        check('prior_review_evidence_unchanged_'+row['path'],sha((PRIOR/row['path']).read_bytes())==row['sha256'])
    v1=(PRIOR/'snapshots_v1/check_potential_reconstruction.py').read_text()
    v2=(SNAP/'check_potential_reconstruction_v2.py').read_text()
    added='''                if scale > 0:
                    # Positive-residue integral bound, checked relatively even at tiny radii.
                    lower_ratio = math.exp(-float(np.max(xs)))
                    ratio = deficit / upper
                    check(f"Yukawa_relative_positive_lower_bound_{a}_{choice}_{label}_{scale}",
                          deficit > 0 and ratio >= lower_ratio * (1 - 2e-12)
                          and ratio <= 1 + 2e-12,
                          deficit_over_upper=ratio, lower_ratio=lower_ratio)
'''
    check('only_exact_eight_lines_added',v2.count(added)==1 and v2.replace(added,'')==v1)
    patch=''.join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile='check_potential_reconstruction.py',tofile='check_potential_reconstruction_v2.py'))
    check('published_diff_exact',patch==(SNAP/'CONTROL_CORRECTION_v1_to_v2.diff').read_text())
    plan=load(SNAP/'CONTROL_CORRECTION_PLAN_v2.json')
    check('plan_source_hashes',plan['v1_source_sha256']==sha(v1.encode()) and plan['v2_source_sha256']==sha(v2.encode()))
    for name,identity in load(SNAP/'evidence_v2/FREEZE.json')['files'].items():
        check('v2_frozen_input_'+name,sha((ROOT/name).read_bytes())==identity
              and sha((SNAP/'evidence_v2/source_snapshot'/name).read_bytes())==identity)
    a=load(PRIOR/'snapshots_v1/evidence_v1/RESULTS.json')
    b=load(SNAP/'evidence_v2/RESULTS.json')
    sections=['symbolic','single_field_endpoint','potential_grid','two_field_evolution','local_quadratic_force','historical_drift']
    for name in sections:
        check('complete_science_section_exact_identity_'+name,a[name]==b[name])
    prefix='Yukawa_relative_positive_lower_bound_'
    original_checks=[r for r in b['checks'] if not r['name'].startswith(prefix)]
    new=[r for r in b['checks'] if r['name'].startswith(prefix)]
    check('all_1494_original_check_records_and_order_unchanged',original_checks==a['checks'] and len(original_checks)==1494)
    check('exactly_36_added_checks_and_1530_total',len(new)==36 and len(b['checks'])==b['checks_count']==1530
          and len({r['name'] for r in b['checks']})==1530 and b['all_passed'] and all(r['pass'] for r in b['checks']))
    expected=[]
    for block in b['local_quadratic_force']:
        for row in block['force_controls']:
            if row['H0_r_over_c']>0:
                expected.append((block,row))
    for i,((block,row),c) in enumerate(zip(expected,new,strict=True)):
        lower=math.exp(-max(row['mu_r']))
        ratio=row['relative_mass_force_deficit']/row['relative_bound']
        name=f"{prefix}{block['a']}_{block['quadratic_diagnostic']}_{row['label']}_{row['H0_r_over_c']}"
        check('complete_added_check_'+str(i),c['name']==name and c['lower_ratio']==lower and c['deficit_over_upper']==ratio
              and row['relative_mass_force_deficit']>0 and ratio>=lower*(1-2e-12) and ratio<=1+2e-12,
              ratio=ratio,lower_ratio=lower)
    identity=load(SNAP/'evidence_v2/PREDICTION_IDENTITY.json')
    check('prediction_identity_receipt_matches_actual',identity=={'identical_science_sections':sections,'v1_checks':1494,'v2_checks':1530,'new_positive_relative_checks':36,'all_existing_checks_preserved':True})
    for name,identity in b['source_sha256'].items():
        check('result_source_binding_'+name,sha((ROOT/name).read_bytes())==identity)
    s1=load(PRIOR/'snapshots_v1/evidence_v1/stdout.txt');s2=load(SNAP/'evidence_v2/stdout.txt')
    s1['checks']=1530
    check('stdout_changes_only_check_count',s1==s2)
    execution=load(SNAP/'evidence_v2/EXECUTION.json')
    check('recorded_v2_success',execution['exit_code']==0 and (SNAP/'evidence_v2/stderr.txt').read_bytes()==b'')
    check('plan_and_freeze_before_v2_execution',datetime.datetime.fromisoformat(plan['created_at'])
          <datetime.datetime.fromisoformat(load(SNAP/'evidence_v2/FREEZE.json')['frozen_at'])
          <datetime.datetime.fromisoformat(execution['started_at']))
    # Exactly the previous small-radius mutation. Only the isolated copy runs.
    d=HERE/'zero_deficit_mutant';d.mkdir()
    for name in ['PROTOCOL.md','DIRECT_POTENTIAL_RECONSTRUCTION.md','NUMERICAL_FIXTURES.json']:
        (d/name).write_bytes((ROOT/name).read_bytes())
    original='                deficit = float(weights @ np.array(deficits)) / (1 + a)\n'
    mutation=original+'                if 0 < scale < 1e-3:\n                    deficit = 0.0  # Reviewer mutation: suppress only tiny nonzero force deficits.\n'
    check('same_previous_mutation_insertion',original in v2 and mutation in (PRIOR/'mutations_v2/check_potential_reconstruction.py').read_text())
    mutated=v2.replace(original,mutation);script=d/'check_potential_reconstruction_v2.py';script.write_text(mutated)
    env=os.environ.copy()
    for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:env[key]='1'
    env['PYTHONDONTWRITEBYTECODE']='1'
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    run=subprocess.run([sys.executable,str(script),'--output',str(d/'RESULTS.json')],cwd=d,env=env,capture_output=True,timeout=60)
    (d/'stdout.txt').write_bytes(run.stdout);(d/'stderr.txt').write_bytes(run.stderr)
    error=run.stderr.decode()
    check('same_small_radius_zero_mutant_rejected',run.returncode!=0 and 'AssertionError' in error
          and 'Yukawa_relative_positive_lower_bound_1e-06_potential_hessian_dimensionless_1e-06' in error
          and "'deficit_over_upper': 0.0" in error and not (d/'RESULTS.json').exists())
    mut_receipt={'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'exit_code':run.returncode,'expected_failure':True,'source_sha256':sha(script.read_bytes()),
                 'guard':'Yukawa_relative_positive_lower_bound_1e-06_potential_hessian_dimensionless_1e-06',
                 'diff':''.join(difflib.unified_diff(v2.splitlines(True),mutated.splitlines(True),fromfile='frozen_v2',tofile='same_zero_deficit_mutant')),
                 'scope':'Mutation sensitivity only. Baseline science not rerun; unchanged full predictions reuse prior independent recomputation.'}
    (d/'EXECUTION.json').write_text(json.dumps(mut_receipt,indent=2)+'\n')
    out={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'checks_count':len(checks),
         'all_passed':all(r['pass'] for r in checks),'failures':[r for r in checks if not r['pass']],
         'prior_gap_closed_for_frozen_controls':True,'mutant_failed_at_required_guard':run.returncode!=0}
    (HERE/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['checks_count','all_passed','failures','mutant_failed_at_required_guard']},indent=2))
    return 0 if out['all_passed'] else 1


if __name__=='__main__':sys.exit(main())
