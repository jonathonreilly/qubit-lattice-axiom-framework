#!/usr/bin/env python3
"""Correct a reviewer-only stderr representation matcher; no execution rerun."""
from pathlib import Path
import datetime
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    if (HERE/'FINAL_RESULTS.json').exists():raise FileExistsError('FINAL_RESULTS.json')
    original=json.loads((HERE/'RESULTS.json').read_text())
    stderr=(HERE/'zero_deficit_mutant/stderr.txt').read_text()
    execution=json.loads((HERE/'zero_deficit_mutant/EXECUTION.json').read_text())
    zero=re.search(r"'deficit_over_upper': (?:np\.float64\()?([0-9.eE+-]+)\)?",stderr)
    lower=re.search(r"'lower_ratio': ([0-9.eE+-]+)",stderr)
    guard='Yukawa_relative_positive_lower_bound_1e-06_potential_hessian_dimensionless_1e-06'
    valid=(execution['exit_code']==1 and 'AssertionError:' in stderr and guard in stderr
           and zero is not None and float(zero.group(1))==0
           and lower is not None and float(lower.group(1))>0
           and not (HERE/'zero_deficit_mutant/RESULTS.json').exists()
           and sha((HERE/'zero_deficit_mutant/check_potential_reconstruction_v2.py').read_bytes())==execution['source_sha256'])
    assert len(original['failures'])==1 and original['failures'][0]['name']=='same_small_radius_zero_mutant_rejected'
    checks=[dict(c) for c in original['checks']]
    checks[-1]={'name':'same_small_radius_zero_mutant_rejected','pass':bool(valid),'parsed_deficit_over_upper':float(zero.group(1)),
                'parsed_lower_ratio':float(lower.group(1)),'executed_guard':guard,
                'reviewer_correction':'Initial matcher required a plain Python float repr; NumPy printed np.float64(0.0). Actual v2 guard had already correctly rejected the mutant.'}
    out={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'checks_count':len(checks),
         'all_passed':all(c['pass'] for c in checks),'failures':[c for c in checks if not c['pass']],
         'original_checker_result_preserved':'RESULTS.json','original_checker_result_sha256':sha((HERE/'RESULTS.json').read_bytes()),
         'original_executed_checker_sha256':sha((HERE/'check_affected_v2.py').read_bytes()),
         'corrected_matcher_sha256':sha(Path(__file__).read_bytes()),
         'no_scientific_rerun':True,'prior_gap_closed_for_frozen_controls':bool(valid)}
    (HERE/'FINAL_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['checks_count','all_passed','failures','no_scientific_rerun']},indent=2))
    assert out['all_passed']


if __name__=='__main__':main()
