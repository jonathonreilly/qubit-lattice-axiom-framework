#!/usr/bin/env python3
"""Independent numerical oracles; no author imports or calls."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import time
import sys

import mpmath as mp
import numpy as np
import scipy
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
SNAP = HERE/"snapshots_v1"
mp.mp.dps = 80
CHECKS = []


def sha(b):
    return hashlib.sha256(b).hexdigest()


def check(name, yes, **detail):
    CHECKS.append({"name":name,"pass":bool(yes),**detail})


def compare(name, actual, expected, atol, rtol):
    x,y = np.asarray(actual,dtype=float), np.asarray(expected,dtype=float)
    assert x.shape == y.shape,(name,x.shape,y.shape)
    delta = np.abs(x-y)
    rel = np.divide(delta,np.abs(x),out=np.zeros_like(delta),where=x!=0)
    check(name,np.all(delta <= atol+rtol*np.abs(x)),maximum_absolute=float(np.max(delta)),
          maximum_relative_nonzero=float(np.max(rel)),atol=atol,rtol=rtol,shape=list(x.shape))


def mp_potential(a,m,eta):
    aa,mm,ee = map(mp.mpf,[a,m,eta])
    lam = mp.mpf('1.5')*(1-mm)
    k = mp.sqrt(3*(1+aa)/(2*aa))
    center = mp.asinh(mp.sqrt(mm/(1-mm)))/k

    def value(u,chi):
        # Expanded polynomial and exponential form, independently differentiated.
        t = k*(chi-center)
        S = lam/(4*(1+aa))*(mp.expm1(2*t)+mp.expm1(-2*t))
        polynomial = (1+ee)*u*u-2*mp.sqrt(aa)*u+aa
        return lam + S*polynomial/2
    return value,k,center


def mp_spectrum(matrix,a):
    A,B,C = matrix[0][0],matrix[0][1],matrix[1][1]
    separation = mp.sqrt((A-C)**2+4*B*B)
    hi = (A+C+separation)/2
    lo = (A*C-B*B)/hi
    weights = [mp.mpf(a)*(hi-A)/(hi-lo),mp.mpf(a)*(A-lo)/(hi-lo)]
    return [lo,hi],weights


def inverse_control(f,author):
    outputs = []
    for index, block in enumerate(author["single_field_endpoint"]):
        av,mv = block["a"],block["m"]
        a,m = mp.mpf(av),mp.mpf(mv)
        expected_pair = [(a0,m0) for a0 in f['weak_couplings'] for m0 in f['matter_fractions']][index]
        check("inverse_fixture_identity_"+str(index),(av,mv)==expected_pair)

        def physical_potential(n,r,w):
            E2 = m*mp.exp(-3*n)+1-m
            D = mp.mpf('1.5')*m*mp.exp(2*a*r-3*n)/((1+a)*E2)
            return mp.exp(2*a*r)*E2*(3*(1-a*w)**2-a*w*w-2*D)/2

        def acceleration(n,r,w):
            E2 = m*mp.exp(-3*n)+1-m
            h = -mp.mpf('1.5')*m*mp.exp(-3*n)/E2
            return h*(a-mp.expm1(2*a*r))/(a*(1+a))+(1-h)*w+(1-a)*w*w

        def rhs(n,state):
            r,w = state
            E2 = mv*math.exp(-3*n)+1-mv
            h = -1.5*mv*math.exp(-3*n)/E2
            return [w,h*(av-math.expm1(2*av*r))/(av*(1+av))+(1-h)*w+(1-av)*w*w]

        sols = [solve_ivp(rhs,(0.,-.1),[0.,0.],method='Radau',rtol=5e-14,atol=1e-18,
                          max_step=step,dense_output=True) for step in [.001,.0005]]
        check("scaled_inverse_Radau_success_"+str(index),all(s.success for s in sols))
        rows=[]
        for si,nv in enumerate(f['one_field_endpoint_n']):
            coarse,fine = [s.sol(nv) for s in sols]
            compare("scaled_inverse_refinement_"+str(index)+"_"+str(si),fine,coarse,1e-11,0)
            n,r,w = mp.mpf(nv),mp.mpf(float(fine[0])),mp.mpf(float(fine[1]))
            point = (n,r,w)
            flow = [mp.mpf(1),w,acceleration(*point)]
            orders = [(1,0,0),(0,1,0),(0,0,1)]
            grad = [mp.diff(physical_potential,point,order) for order in orders]
            hess = [[mp.diff(physical_potential,point,tuple(orders[i][k]+orders[j][k] for k in range(3))) for j in range(3)] for i in range(3)]
            acc_grad = [mp.diff(acceleration,point,order) for order in orders]
            flow_derivative = [mp.mpf(0),flow[2],sum(acc_grad[j]*flow[j] for j in range(3))]
            Vprime = sum(grad[i]*flow[i] for i in range(3))
            Vsecond = sum(hess[i][j]*flow[i]*flow[j] for i in range(3) for j in range(3))+sum(grad[i]*flow_derivative[i] for i in range(3))
            phip = mp.sqrt(a)*w
            phipp = mp.sqrt(a)*flow[2]
            phi = mp.sqrt(a)*r
            gradient = Vprime/phip
            mass = (Vsecond*phip-Vprime*phipp)/(phip**3)
            d0 = mp.mpf('1.5')*m/(1+a)
            row={'n':nv,'zeta':float(a*r),'p':float(a*w),'phi':float(phi),
                 'V_over_H0_squared':float(physical_potential(*point)),
                 'V_phi_over_H0_squared':float(gradient),'V_phiphi_over_H0_squared':float(mass),
                 'phi_leading_ratio':float(phi/(-mp.sqrt(a)*d0*n*n/2)),
                 'gradient_leading_ratio':float(gradient/(4*mp.sqrt(a)*d0*n)),
                 'mass_leading_ratio':float(mass/(-4/n))}
            for key,value in row.items():
                compare("inverse_row_"+str(index)+"_"+str(si)+"_"+key,value,block['sites'][si][key],1e-18,5e-6)
            check("inverse_branch_signs_"+str(index)+"_"+str(si),phi<0 and a*w>0 and mass>0 and physical_potential(*point)>0)
            rows.append(row)
        compare("inverse_endpoint_nonzero_derivative_"+str(index),4*math.sqrt(av)*(1.5*mv/(1+av)),block['endpoint_gradient_derivative_over_H0_squared'],1e-18,1e-13)
        check("inverse_endpoint_zero_conditions_"+str(index),block['endpoint_phi_prime']==0 and block['smooth_C2_necessary_value']==0)
        outputs.append({'a':av,'m':mv,'sites':rows,'method':'Scaled Radau plus 80-digit total differentiation of recovered potential'})
    return outputs


def grid_control(f,author):
    out=[]
    expected=[(a,m,e,n) for a in f['weak_couplings']+[f['additional_mathematical_coupling']]
              for m in f['matter_fractions'] for e in f['eta_choices'] for n in f['N_grid']]
    for ix,((av,mv,eta,nv),ar) in enumerate(zip(expected,author['potential_grid'],strict=True)):
        check("complete_grid_fixture_"+str(ix),[av,mv,eta,nv]==[ar[k] for k in ['a','m','eta','n']])
        a,m,n = map(mp.mpf,[av,mv,nv])
        V,k,center = mp_potential(av,mv,eta)
        chi = center-mp.asinh(mp.sqrt(m/(1-m))*mp.exp(-mp.mpf('1.5')*n))/k
        S = mp.mpf('1.5')*m*mp.exp(-3*n)/(1+a)
        H = mp.sqrt(m*mp.exp(-3*n)+1-m)
        velocity = mp.sqrt(a*S)
        matrix = [[mp.diff(V,(mp.mpf(0),chi),order) for order in [(2,0),(1,1)]],
                  [mp.diff(V,(mp.mpf(0),chi),order) for order in [(1,1),(0,2)]]]
        eig,_ = mp_spectrum(matrix,a)
        det=matrix[0][0]*matrix[1][1]-matrix[0][1]**2
        c=mp.mpf('1.5')*(1-m)/(1+a)
        row={'a':av,'m':mv,'eta':eta,'n':nv,'chi':float(chi),'S_over_H0_squared':float(S),
             'H_over_H0':float(H),'chi_dot_over_H0':float(velocity),'V_over_H0_squared':float(V(0,chi)),
             'hessian_over_H0_squared':[[float(x) for x in r] for r in matrix],
             'hessian_eigenvalues':[float(x) for x in eig],'determinant':float(det),
             'eta_required_at_site':float((3*c+2*S)/(c+2*S)), 'positive_curvature_at_site':bool(eig[0]>0)}
        for key,value in row.items():
            compare("grid_row_"+str(ix)+"_"+key,value,ar[key],3e-12,3e-9)
        grad_u,grad_chi=[mp.diff(V,(mp.mpf(0),chi),order) for order in [(1,0),(0,1)]]
        defects=[3*H*H-2*S-velocity**2-2*V(0,chi),grad_u+mp.sqrt(a)*S,grad_chi+mp.mpf('1.5')*H*velocity]
        check("independent_grid_field_equations_"+str(ix),max(abs(x) for x in defects)<mp.mpf('1e-60'))
        check("independent_off_trajectory_positive_potential_"+str(ix),all(V(mp.mpf(t)*mp.sqrt(a),chi)>=mp.mpf('1.5')*(1-m) for t in [-2,-.5,0,.5,1,2]))
        out.append(row)
    return out


def full_time_control(f,author):
    out=[]
    for ix,(fixture,ar) in enumerate(zip(f['two_field_ode'],author['two_field_evolution'],strict=True)):
        av,mv,eta=[fixture[k] for k in ['a','m','eta']]
        check("ODE_fixture_identity_"+str(ix),fixture==ar['fixture'])
        alpha=math.sqrt(av); lam=1.5*(1-mv); k=math.sqrt(3*(1+av)/(2*av))
        center=math.asinh(math.sqrt(mv/(1-mv)))/k

        def V(u,chi):
            t=k*(chi-center)
            S=lam/(4*(1+av))*(np.expm1(2*t)+np.expm1(-2*t))
            return lam+S*((1+eta)*u*u-2*alpha*u+av)/2

        def derivatives(u,chi):
            h=1e-22
            return np.array([V(u+1j*h,chi).imag/h,V(u,chi+1j*h).imag/h])

        def rhs(time,state):
            N,u,chi,vu,vc,sigma,tJ=state
            H=math.sqrt((2*sigma+vu*vu+vc*vc+2*float(V(u,chi)))/3)
            grad=derivatives(u,chi)
            return [H,vu,vc,-3*H*vu-grad[0]-alpha*sigma,
                    -3*H*vc-grad[1],(-3*H+alpha*vu)*sigma,math.exp(alpha*u)]

        def time_at(n):
            q=math.sqrt((1-mv)/mv)
            return 2/(3*math.sqrt(1-mv))*(math.asinh(q*math.exp(1.5*n))-math.asinh(q))

        s0=1.5*mv/(1+av)
        initial=[0,0,0,0,math.sqrt(av*s0),s0,0]
        endpoints=[time_at(n) for n in f['ode_interval_N_star']]
        sols=[solve_ivp(rhs,(0,end),initial,method='Radau',rtol=1e-12,atol=1e-15,
                        max_step=.013,dense_output=True) for end in endpoints]
        check("proper_Einstein_time_Radau_success_"+str(ix),all(s.success for s in sols))
        rows=[]
        for ri,n in enumerate(f['ode_comparison_N_star']):
            tt=time_at(n)
            state=sols[0 if n<0 else 1].sol(tt)
            N,u,chi,vu,vc,sigma,tJ=state
            H=math.sqrt((2*sigma+vu*vu+vc*vc+2*float(V(u,chi)))/3)
            A=math.exp(alpha*u)
            HJ=(H+alpha*vu)/A
            mapped=[u,chi,vu,vc,sigma,tJ]
            compare("independent_N_at_exact_time_"+str(ix)+"_"+str(ri),N,n,3e-10,2e-10)
            compare("independent_clock_at_exact_time_"+str(ix)+"_"+str(ri),tJ,tt,3e-10,2e-10)
            compare("independent_dust_first_integral_"+str(ix)+"_"+str(ri),sigma*math.exp(3*N-alpha*u),s0,3e-10,2e-10)
            for level in [0,1]:
                auth=ar['levels'][level][ri]
                prefix="ODE_row_"+str(ix)+"_"+str(level)+"_"+str(ri)+"_"
                compare(prefix+'state',mapped,auth['state'],3e-10,2e-10)
                compare(prefix+'n_J',N+alpha*u,auth['n_J'],3e-10,2e-10)
                compare(prefix+'H_J',HJ,auth['H_J_over_H0'],3e-10,2e-10)
                compare(prefix+'G_J',A*A,auth['physical_G_over_present'],3e-10,2e-10)
                # Reconstruct the author's diagnostic from its stored numerical state.
                au,ac,av1,av2,asig,atime=auth['state']; an=auth['n_J']
                ech=center-math.asinh(math.sqrt(mv/(1-mv))*math.exp(-1.5*an))/k
                es=1.5*mv*math.exp(-3*an)/(1+av); eh=math.sqrt(mv*math.exp(-3*an)+1-mv)
                defect=max(abs(z) for z in [au,ac-ech,av1,av2-math.sqrt(av*es),asig-es,auth['H_J_over_H0']-eh])
                compare(prefix+'reported_tracking_error',defect,auth['maximum_absolute_tracking_error'],5e-14,0)
            rows.append({'N_target':n,'Einstein_time_H0':tt,'state_including_N':state.tolist(),'mapped_author_state':mapped,'H_J_over_H0':HJ,'physical_G_over_present':A*A})
        refinement=np.max(np.abs(np.array([r['state'] for r in ar['levels'][0]])-np.array([r['state'] for r in ar['levels'][1]])))
        compare("author_refinement_record_"+str(ix),refinement,ar['maximum_state_refinement_error'],0,0)
        out.append({'fixture':fixture,'rows':rows,'proper_time_steps':[len(s.t) for s in sols]})
    return out


def force_series(x):
    if x==0:
        return mp.mpf(0)
    if x>=mp.mpf('.1'):
        return 1-(1+x)*mp.exp(-x)
    # 1-(1+x)e^-x = sum_{n=2}^infinity (-1)^n (n-1)x^n/n!.
    terms=[]
    for n in range(2,100):
        term=(-1)**n*(n-1)*x**n/mp.factorial(n)
        terms.append(term)
        if abs(term)<abs(terms[0])*mp.mpf('1e-75'):
            break
    return mp.fsum(terms)


def force_control(f,author):
    outputs=[]
    for ix,ar in enumerate(author['local_quadratic_force']):
        av,mv,eta=ar['a'],ar['m'],ar['eta']; a=mp.mpf(av)
        expected=[(aa,f['observationally_compared_benchmark_m'],f['eta_repaired'],choice) for aa in f['weak_couplings'] for choice in f['matrix_choices']][ix]
        check("force_fixture_identity_"+str(ix),(av,mv,eta,ar['quadratic_diagnostic'])==expected)
        V,_,_=mp_potential(av,mv,eta)
        matrix=[[mp.diff(V,(mp.mpf(0),mp.mpf(0)),order) for order in [(2,0),(1,1)]],
                [mp.diff(V,(mp.mpf(0),mp.mpf(0)),order) for order in [(1,1),(0,2)]]]
        s=mp.mpf('1.5')*mp.mpf(mv)/(1+a)
        if ar['quadratic_diagnostic']=='potential_hessian_plus_fixed_number_dust':
            # Differentiate sigma(u)=sigma0 exp(sqrt(a)u) at fixed particle number.
            effective=lambda u:s*mp.exp(mp.sqrt(a)*u)
            dust_hessian=mp.diff(effective,mp.mpf(0),2)
            check("fixed_number_dust_second_derivative_"+str(ix),mp.almosteq(dust_hessian,a*s))
            matrix[0][0]+=dust_hessian
        eigen,residues=mp_spectrum(matrix,a)
        compare("independent_mass_matrix_"+str(ix),[[float(z) for z in q] for q in matrix],ar['mass_matrix_over_H0_squared'],0,3e-12)
        compare("independent_mass_eigenvalues_"+str(ix),[float(z) for z in eigen],ar['mass_squared_eigenvalues'],0,3e-12)
        compare("independent_spectral_projector_residues_"+str(ix),[float(z) for z in residues],ar['positive_residues'],0,3e-12)
        check("positive_modes_and_sum_rules_"+str(ix),min(eigen)>0 and min(residues)>0 and mp.almosteq(sum(residues),a)
              and mp.almosteq(sum(eigen[i]*residues[i] for i in range(2)),a*matrix[0][0]))
        labels=[('dimensionless',mp.mpf(x)) for x in f['local_dimensionless_H0_r_over_c_controls']]
        labels += [(f'illustrative_radius_{radius}_m',mp.mpf(f['H0_per_second_illustrative'])*radius/mp.mpf(f['c_m_per_second'])) for radius in f['local_radius_m_illustrative']]
        rows=[]
        for ri,((label,scale),row) in enumerate(zip(labels,ar['force_controls'],strict=True)):
            xs=[mp.sqrt(z)*scale for z in eigen]
            deficit=mp.fsum(residues[i]*force_series(xs[i]) for i in range(2))/(1+a)
            bound=a*matrix[0][0]*scale**2/(2*(1+a))
            compare("force_scale_"+str(ix)+"_"+str(ri),float(scale),row['H0_r_over_c'],0,3e-12)
            compare("force_mode_arguments_"+str(ix)+"_"+str(ri),[float(z) for z in xs],row['mu_r'],0,3e-12)
            compare("force_deficit_no_absolute_floor_"+str(ix)+"_"+str(ri),float(deficit),row['relative_mass_force_deficit'],0,3e-12)
            compare("force_upper_bound_"+str(ix)+"_"+str(ri),float(bound),row['relative_bound'],0,3e-12)
            check("force_label_"+str(ix)+"_"+str(ri),label==row['label'])
            if scale>0:
                ratio=deficit/bound
                check("strict_force_lower_bound_"+str(ix)+"_"+str(ri),ratio>=mp.exp(-max(xs))-mp.mpf('1e-70') and ratio<=1+mp.mpf('1e-70'))
                check("independent_oracle_rejects_zero_mutant_"+str(ix)+"_"+str(ri),float(deficit)>0 and abs(float(deficit)-0)>3e-12*abs(float(deficit)))
            else:
                ratio=mp.mpf(1)
                check("zero_radius_exact_limit_"+str(ix),deficit==bound==0)
            rows.append({'label':label,'scale':float(scale),'mu_r':[mp.nstr(x,45) for x in xs],
                         'deficit':mp.nstr(deficit,50),'bound':mp.nstr(bound,50),'deficit_over_bound':mp.nstr(ratio,40)})
        outputs.append({'a':av,'m':mv,'eta':eta,'matrix_choice':ar['quadratic_diagnostic'],
                        'eigenvalues':[mp.nstr(v,50) for v in eigen],'residues':[mp.nstr(v,50) for v in residues],'rows':rows})
    return outputs


def main():
    dest=HERE/'INDEPENDENT_RESULTS_v1.json'
    if dest.exists(): raise FileExistsError(dest)
    start=time.time(); f=json.loads((SNAP/'NUMERICAL_FIXTURES.json').read_text())
    author=json.loads((SNAP/'evidence_v1/RESULTS.json').read_text())
    for p in json.loads((HERE/'SOURCE_PINS_v1.json').read_text())['sources']:
        check('exact_snapshot_'+p['path'],sha((HERE/p['snapshot']).read_bytes())==p['sha256'])
    check('consume_all_author_check_records',len(author['checks'])==author['checks_count']==1494 and len(set(r['name'] for r in author['checks']))==1494 and all(r['pass'] is True for r in author['checks']) and author['all_passed'])
    out={'reviewer':'direct_field_check','author_helpers_imported_or_called':False,'script_sha256':sha(Path(__file__).read_bytes()),
         'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mp.__version__},'mpmath_decimal_precision':mp.mp.dps}
    out['inverse_endpoint']=inverse_control(f,author)
    out['grid']=grid_control(f,author)
    out['proper_time_evolution']=full_time_control(f,author)
    out['force']=force_control(f,author)
    drift=author['historical_drift']; expected={'prediction_per_year':0,'exposed_mean_per_year':4e-13,'reported_uncertainty_per_year':9e-13,'standardized_residual':float(mp.mpf(4)/9),'reported_tidal_correlation':.74}
    for key,value in expected.items(): compare('historical_LLR_'+key,value,drift[key],0,2e-15)
    out['historical_LLR']={**expected,'supplied_H0_per_year':f['H0_per_second_illustrative']*f['seconds_per_year_supplied'],
                           'no_new_measurement_or_independent_likelihood':True}
    out['checks']=CHECKS;out['checks_count']=len(CHECKS);out['failures']=[c for c in CHECKS if not c['pass']];out['all_passed']=not out['failures']
    out['elapsed_seconds']=time.time()-start;out['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    dest.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'checks':out['checks_count'],'all_passed':out['all_passed'],'failures':out['failures'],'elapsed_seconds':out['elapsed_seconds']},indent=2))
    return 0 if out['all_passed'] else 1


if __name__=='__main__':
    sys.exit(main())
