#!/usr/bin/env python3
"""Reviewer-owned identity checks. No author imports or mutations."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
SNAP=HERE/'snapshots_v1'
checks=[]


def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads((SNAP/p).read_text())
def check(name,yes,**evidence): checks.append({'name':name,'pass':bool(yes),**evidence})


def main():
    for p in ['LINEAGE_RESULTS_v1.json','ORIGINAL_DISPOSITIONS_v1.json','EXTERNAL_PRIMARY_PIN_v1.json']:
        if (HERE/p).exists(): raise FileExistsError(p)
    pins=json.loads((HERE/'SOURCE_PINS_v1.json').read_text())
    dispositions=[]
    for row in pins['sources']:
        b=(ROOT/row['path']).read_bytes(); recovered=(HERE/row['snapshot']).read_bytes()
        check('complete_original_and_recovery_'+row['path'],b==recovered and sha(b)==row['sha256'] and len(b)==row['bytes'])
        detail='Read completely; source/receipt identity checked; original unchanged.'
        if row['path']=='check_potential_reconstruction.py':
            detail='Read completely; numerical values independently checked; tiny-force assertion gap recorded, awaiting separate author correction. Original unchanged.'
        elif row['path']=='evidence_v1/RESULTS.json':
            detail='All numeric result classes independently consumed/compared; all 1494 trace records read; original unchanged.'
        elif row['path']=='DIRECT_POTENTIAL_RECONSTRUCTION.md':
            detail='Read completely for numerical implementation and scope; standalone analytic proof reviewed by separate focused checker. Original unchanged.'
        dispositions.append({'original_path':str(ROOT/row['path']),'original_sha256':row['sha256'],'disposition':detail,
                             'recovery':str(HERE/row['snapshot']),'final_path':str(ROOT/row['path']),'final_sha256':sha(b)})
    for p,key in [('AUTHOR_BLOCK_FREEZE_v1.json','files'),('PRE_EXECUTION_PLAN_v1.json','files'),
                  ('evidence_v1/FREEZE.json','source_hashes'),('evidence_v1/RESULTS.json','source_sha256')]:
        for source,identity in read(p)[key].items():
            check('declared_hash_'+p+'_'+source,sha((SNAP/source).read_bytes())==identity)
    for source,identity in read('evidence_v1/FREEZE.json')['source_hashes'].items():
        check('executed_author_source_snapshot_'+source,sha((SNAP/'evidence_v1/source_snapshot'/source).read_bytes())==identity)
    start=datetime.datetime.fromisoformat(read('evidence_v1/EXECUTION.json')['started_at'])
    pre=datetime.datetime.fromisoformat(read('PRE_EXECUTION_PLAN_v1.json')['frozen_at'])
    frozen=datetime.datetime.fromisoformat(read('evidence_v1/FREEZE.json')['frozen_at'])
    check('recorded_plan_and_source_freeze_precede_execution',pre<frozen<start)
    check('recorded_author_execution_success',read('evidence_v1/EXECUTION.json')['exit_code']==0 and (SNAP/'evidence_v1/stderr.txt').read_bytes()==b'')
    author=read('evidence_v1/RESULTS.json')
    summary={'checks':len(author['checks']),'all_passed':author['all_passed'],'grid_rows':len(author['potential_grid']),
             'eta0_negative_curvature_rows':sum(r['eta']==0 and not r['positive_curvature_at_site'] for r in author['potential_grid']),
             'eta3_positive_curvature_rows':sum(r['eta']==3 and r['positive_curvature_at_site'] for r in author['potential_grid']),
             'max_tracking_error':max(r['maximum_absolute_tracking_error'] for b in author['two_field_evolution'] for level in b['levels'] for r in level),
             'max_refinement_error':max(b['maximum_state_refinement_error'] for b in author['two_field_evolution']),'drift':author['historical_drift']}
    check('all_stdout_fields_match_full_result',summary==json.loads((SNAP/'evidence_v1/stdout.txt').read_text()))
    external=read('SOURCE_LEDGER.json')['primary_sources'][0]
    b=Path(external['recovery_path']).read_bytes()
    check('primary_LLR_pdf_identity',sha(b)==external['sha256'],bytes=len(b))
    external_record={**external,'reviewer_read_scope':'Page 3, Eq9 and adjacent tidal-correlation text extracted/read in this check; earlier body-sensitivity review read the same preserved primary. No raw LLR records or new likelihood read.',
                     'actual_bytes':len(b),'actual_sha256':sha(b),'recovery':'Original external recovery retained; primary PDF not copied into this block.'}
    f=read('NUMERICAL_FIXTURES.json')
    for fk,ek in [('historical_LLR_drift_per_year_mean','drift_mean_per_year'),
                  ('historical_LLR_drift_per_year_reported_uncertainty','reported_uncertainty_per_year'),
                  ('historical_LLR_tidal_correlation','reported_tidal_correlation')]:
        check('LLR_fixture_ledger_'+fk,f[fk]==external[ek])
    out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'checks_count':len(checks),
         'all_passed':all(r['pass'] for r in checks),'failures':[r for r in checks if not r['pass']],
         'original_paths':len(dispositions),'author_manifest_members':len(read('AUTHOR_BLOCK_FREEZE_v1.json')['files']),
         'history_limit':'Recorded identities/timestamps establish source continuity, not independent knowledge of unrecorded prior activity.'}
    for p,data in [('LINEAGE_RESULTS_v1.json',out),('ORIGINAL_DISPOSITIONS_v1.json',dispositions),('EXTERNAL_PRIMARY_PIN_v1.json',external_record)]:
        (HERE/p).write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['checks_count','all_passed','failures','original_paths','author_manifest_members']},indent=2))


if __name__=='__main__': main()
