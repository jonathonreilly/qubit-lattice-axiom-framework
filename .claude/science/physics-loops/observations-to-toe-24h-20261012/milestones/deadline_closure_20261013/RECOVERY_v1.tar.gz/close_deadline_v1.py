from pathlib import Path
import json,datetime,time,subprocess,os,hashlib
r=Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012');w=Path('/Users/jonBridger/.codex/worktrees/observations-to-toe-24h-20261012/New Axioms Lets Go');p=w/'.claude/science/physics-loops/observations-to-toe-24h-20261012';deadline=json.loads((r/'DEADLINE.json').read_text());assert time.time()>=deadline['deadline_epoch'],'Fixed deadline has not arrived; no closure changes made.'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();ps=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True);own={os.getpid(),os.getppid()};rows=[]
for line in ps.splitlines():
 f=line.strip().split(None,2)
 if len(f)!=3:continue
 pid,ppid,cmd=int(f[0]),int(f[1]),f[2]
 if pid in own:continue
 if str(r/'supervisor.py') in cmd or ('01a13108-28bb-7802-b031-dc3a38fb5fc7' in cmd and 'codex' in cmd) or ('toe-observation-inversion-24h-20261012' in cmd and ('supervisor.py' in cmd or 'codex exec' in cmd)):
  rows.append(dict(pid=pid,ppid=ppid,command=cmd))
assert not rows,rows
old=json.loads((r.parent/'toe-observation-inversion-24h-20261012/STATUS.json').read_text());assert old['phase']=='cancelled' and old.get('worker_pid') is None and old.get('supervisor_pid') is None
state=json.loads((r/'DIRECT_AUTHOR.json').read_text());assert state['owner_thread_id']=='01a130f9-fd7f-7d31-9f8f-ac05cdf2c617' and state['restart_detached_author'] is False
record=dict(at=now,deadline_at=deadline['deadline_at'],deadline_reached=True,new_discovery_after_cutoff=False,last_science_execution=json.loads((p/'cosmology/direct_exponential_completion/BOUNDARY_GEOMETRY_EXECUTION_v1.json').read_text()),owned_background_process_matches=rows,terminated_processes=[],research_jobs_already_absent=True,cancelled_campaign_phase=old['phase'],retired_author_restarted=False,scientific_outcome='Timebox completed; a TOE was not established. Conditional mathematics and empirical limitations preserved.',heartbeat_pause='pending tool update')
(r/'FINAL_SHUTDOWN_v1.json').write_text(json.dumps(record,indent=2)+'\n')
stop=dict(at=now,reason='fixed_campaign_deadline',deadline_at=deadline['deadline_at'],restart_allowed=False,author_mode='direct_chat_author',scope='Only observations-to-toe-24h-20261012; prior cancelled campaign remains stopped.')
f=r/'STOP_REQUESTED.json'
if f.exists():raise RuntimeError('Unexpected existing stop marker; preserve and inspect before writing.')
f.write_text(json.dumps(stop,indent=2)+'\n')
state.update(state='completed_at_deadline',completed_at=now,background_processes_absent=True,restart_detached_author=False);(r/'DIRECT_AUTHOR.json').write_text(json.dumps(state,indent=2)+'\n')
for f in [r/'STATUS.json',p/'STATE.yaml']:
 d=json.loads(f.read_text());d.update(phase='completed_at_deadline',status='completed',checked_at=now,completed_at=now,scientific_outcome=record['scientific_outcome'],worker_pid=None,supervisor_pid=None,direct_tool_session=None,direct_compute_driver_pid=None,conflicting_owned_author=False,next_exact_action='No further campaign research. Preserve final report; pause the existing heartbeat and release only this campaign lock.',heartbeat_pause_pending=True)
 f.write_text(json.dumps(d,indent=2)+'\n')
cp=subprocess.run(['/usr/local/bin/python3','scripts/automation_lock.py','release','--owner','physics-loop','--holder-id','observations-to-toe-24h-20261012'],cwd=w,capture_output=True,text=True,timeout=15);(r/'FINAL_LOCK_RELEASE_v1.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=cp.returncode,stdout=cp.stdout,stderr=cp.stderr),indent=2)+'\n');assert cp.returncode==0,cp.stdout+cp.stderr
print('Fixed deadline reached; owned research jobs absent, cancelled campaign stopped, matching lock released. Heartbeat pause still pending.')
