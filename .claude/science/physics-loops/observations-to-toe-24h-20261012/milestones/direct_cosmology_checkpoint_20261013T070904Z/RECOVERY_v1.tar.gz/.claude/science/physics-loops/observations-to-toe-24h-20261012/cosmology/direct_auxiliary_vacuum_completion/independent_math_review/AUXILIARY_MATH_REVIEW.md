# Focused handwritten review of direct_auxiliary_vacuum_completion

No mathematical source correction is required for the frozen note. Independent variation of the specified action reproduces the auxiliary equations, complete trace/flux identity, constant-vacuum shift map, tracking lift, stationary-vacuum relation and all four first-order sensitivities. In particular the physical Hubble sensitivity is 1/12; it requires the conformal clock. The claims remain conditional on the new action, supplied scales and explicit flux/boundary premises. They are not a cosmological-constant value calculation or a general naturalness theorem.

`INDEPENDENT_DERIVATION.md` contains the complete independent argument. `DERIVATION_RESULTS_v3.json` records 108 passing symbolic, inequality and high-precision checks. Two earlier reviewer-script failures are preserved and explained below. No parent implementation was read, imported or executed for this task.

## Frozen and imported source scope

The two primary inputs were frozen before checking:

| Input | SHA-256 |
|---|---|
| HAND_DERIVATION_v1.md | 989e6b051b67e68e188738672bb67eb08f65236c73040b8bd87b04562ccb48b4 |
| PROTOCOL_v1.json | f2b2648d95b4c2aa84a0ee434d495bda67522651d2ef46c61aa62997088bacd3 |

Both were read completely. Their exact copies are in `source_snapshot/`. The imported analytic proof is unchanged at `322a932eef3ede5de4d963aae2c623693d12a5942828f971335cc7a6c03ef7d2` and is separately snapshotted. Its previously checked K,V,A and zero-residual homogeneous convergence theorem are reused by exact identity. The new auxiliary construction is derived independently rather than inferred from that older review.

The external primary PDF is arXiv:1505.01492v2, SHA-256 `4a4f9dfab05e8fa89df3b441b273e1199e53aff55ec2f042e6364ec1df396540`. All nine pages were read by text extraction, especially equations 7-10, footnote 4 and the infinite-volume discussion. No visual-layout verification is claimed. Its original runtime path and exact identity are recorded in `IMPORTED_SOURCE_RECEIPT_v1.json`; no primary PDF/page copy was added to this review tree.

The review covers only the two handwritten inputs and their stated imports. It neither reviews later author code/results nor applies a formal audit, adoption or retained-status label. No empirical data or new likelihood is supplied by this block; the protocol's illustrative parameters and exposed prior calibration are not independent observations.

## Load-bearing checks

The form variations with fixed pullbacks give dLambda=0 and d(q^2)=0. Positive q on a connected component is the needed premise for dq=0. The independent q variation contains all of R/2-Q-2V, including both scalar terms. This yields Fhat=-(M_aux^4/q)L0 vol_g. Replacing L0 by R/2 would already fail by 3H_v^2 at the intended vacuum.

The metric variation contains derivative-q terms until the auxiliary equations are imposed. The on-shell trace is qR=2qQ+8qV-T_ex+4(Lambda+rho)A^4. Substitution in qL0 gives precisely 2qV-T_ex/2+2(Lambda+rho)A^4. Constant Weyl variation supplies a separate trace derivation. Integrating with the stated A^4 denominator gives Lambda+rho=qB_flux/2-q barV+barT/4. All dimensions and signs agree.

For a constant shift of rho compensated by the opposite shift of Lambda, the whole scalar-dependent A^4 operator cancels for arbitrary u. Only the topological action term changes, by a fixed-sector number. This proves a bijection of the declared classical solution sets. It does not show dynamical relaxation at fixed Lambda. Holding Lambda fixed leaves a genuine vacuum operator; making the compensating shift spacetime-dependent violates the form equation dLambda=0. These two exclusions are correctly retained.

The tracking lift at Lambda=-rho is exact. Direct use of curvature and kinetic energy gives L0=3H_v^2+(1+a)sigma+(2a/3)r, agreeing independently with the trace expression. Positive fluid contributions make every corresponding finite-slab average strictly larger than the vacuum endpoint. The finite-slab ratio must therefore be the actual integral. A dust-only closed-form integral provides an independent mathematical check of this distinction.

With a fixed finite initial time and finite comoving volume, the future tracking ratio tends to 3H_v^2: the dust numerator correction grows only linearly in late proper time, the radiation correction has a finite future tail, and volume grows exponentially. For other original zero-residual finite-energy homogeneous solutions, the imported convergence theorem and the on-shell trace supply the same limit. The note does not assert this on arbitrary inhomogeneous spacetimes.

For constant vacua, positivity of the x coefficient forces x=y=0. Eliminating C=Lambda_tilde/(2q) gives the exact flux equation [3+ell(t^2-t)]exp(-4t)=3. The elementary sign argument excludes every nonzero root with t<=1; all other roots have m_u^2=nu H_v^2(1-4t)<0. The origin has canonical scalar masses (nu,9/4,2)H_v^2. The uniqueness statement is therefore correct for positive scalar Hessian at these constant vacua. It is not a general stability or attraction theorem with global boundary constraints.

The independent 80-digit root controls retain 22 roots across the twelve parameter pairs: twelve zero roots and ten nonzero roots. Five parameter pairs have two nonzero roots each. Every additional root is expanding de Sitter in the checked equations and has the negative u-Hessian required by the argument; none was excluded to obtain a desired conclusion. The derivative of the flux function supplies the root-isolating intervals.

At the origin d(B_flux/H_v^2)/dt=-(ell+12). Independent differentiation of C, H_E/A and A^2/q gives exactly the four sensitivities stated in the note. Using H_E alone would miss a contribution 1/(ell+12) to the Hubble slope. The reported G_T,J is the tensor gravitational coefficient; it should not be silently identified with a general measured force including scalar exchange. The source uses the tensor label correctly.

## Boundary and physical scope that must remain attached

The finite classical shift proof depends on fixed form pullbacks/fluxes and an auxiliary Lambda allowed to translate. The imposed metric/q boundary conditions and gravitational boundary terms must be compatible with the bulk variational problem. The note stipulates such a problem; the calculation does not establish solutions for arbitrary independent boundary data.

A lifted finite history determines compatible flux magnitudes. Distinct histories need not have the same finite absolute fluxes. Their common asymptotic ratio is a weaker condition than fixing all pullbacks or absolute fluxes. In particular, a fixed finite c_F cannot support an infinite positive physical four-volume because c_F=mu_aux^4 integral A^4 vol_g. The stated future limit is a regulated sequence with divergent raw fluxes, not a finite flux sector containing an infinite volume. The note explicitly supplies the future ratio as an extra boundary assumption, and its family-compatibility statement is valid at that level.

The fixed finite-slab action shifts are field independent. Their divergent infinite-time limit is not automatically a convergent action or defined quantum phase. The note's quantum-measure/sector caveats are appropriate; the present proof is classical. It supplies no measure over sectors, preferred initial data, physical probability or primordial abundance.

The primary sequestering paper uses a different action and its footnote 4 constrains auxiliary functions for its own freedom to choose finite gravitational scales with arbitrary fluxes. Its radiative-stability argument also has additional assumptions. The present action's linear Lambda coupling fixes a physical-volume flux relation, while q scales the entire scalar/gravity L0. Therefore that paper supplies context, not a theorem for this model. The source explicitly makes this distinction. The observed H_v and q, scalar/graviton loops, induced derivative terms, phase transitions and general infinite-spacetime regulation remain outside the result. No conclusion of general CC or naturalness resolution is supported or claimed.

## Preserved reviewer failures and evidence integrity

The first independent script stopped when SymPy could not solve directly for the composite expression Lambda+rho; `EXECUTION_v1.json`, the executed source and traceback are preserved. Version 2 instead solves for Lambda and adds rho. That execution retained one false check because Python structural equality was applied to an unsimplified symbolic expression. The underlying fixed-Lambda residual was algebraically correct; version 3 uses a simplified zero-residual check. The full failing v2 result remains intact. All other 107 checks and all vacuum-root values are identical between v2 and v3.

These are reviewer-tool defects, not parent mathematical findings. `FAILURE_HISTORY_v1.json` and the exact version diffs make that distinction explicit. No tolerance was loosened and no root was removed. The completed independent source is `derive_auxiliary_v3.py`, SHA-256 `f2140619cbe238943a29c7b8ec39619eacf38e70227d4181ede39a38731993c3`.

All source snapshots, executed versions, actual failures, complete results, derivation, dispositions and the external primary-source identity are bound by `FINAL_RECEIPT_v1.json`. Original author files remain unchanged.
