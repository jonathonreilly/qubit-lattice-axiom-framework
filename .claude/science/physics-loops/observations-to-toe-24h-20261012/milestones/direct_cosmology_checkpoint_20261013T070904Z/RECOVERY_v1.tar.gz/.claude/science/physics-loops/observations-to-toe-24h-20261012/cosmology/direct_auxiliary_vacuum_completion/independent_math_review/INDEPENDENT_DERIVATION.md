# Independent derivation from the auxiliary action

This derivation checks the parent's frozen handwritten construction. It does not supply a replacement physical model, inspect a future implementation, or import the standard sequestering model's conclusions. Use signature (-,+,+,+), a positive volume density, dimensionless scalar fields, and the declared fixed positive parameters.

## Variations before imposing constancy

After separating the matter vacuum coefficient, write

    S_bulk = integral vol_g [q(R/2-Q-2V)-(Lambda+rho)A^4] + Gamma_ex,
    S_forms = integral Lambda F/mu_aux^4 + q^2 Fhat/(2 M_aux^4),
    Q=K_AB partial(phi^A).partial(phi^B).

With fixed pullbacks of the three-form potentials, their integration-by-parts boundary terms vanish. The bulk equations are

    dLambda=0, d(q^2)=0.

Smooth q>0 on each connected component therefore gives dq=0. Independent local variations of Lambda and q give

    F=mu_aux^4 A^4 vol_g,
    Fhat=-(M_aux^4/q)(R/2-Q-2V) vol_g.

The entire L0 multiplies q. Dropping its scalar kinetic or potential terms would be a different action and a different form constraint. In particular, at the desired vacuum R/2=6H_v^2 but L0=3H_v^2. Those are not interchangeable.

Metric variation before using dq=0 has

    q G_mn + (g_mn Box - nabla_m nabla_n)q
      = T_ex,mn + 2q K_AB partial_m phi^A partial_n phi^B
        - q Q g_mn - 2q V g_mn - (Lambda+rho)A^4 g_mn.

Its trace gives

    qR = 2qQ + 8qV - T_ex + 4(Lambda+rho)A^4 + 3 Box q.

A separate check is constant Weyl rescaling: R and Q have weight -2, volume has weight +4, V and A are held fixed, and the matter variation is T_ex times the Weyl parameter. This yields the same trace after q becomes constant. Therefore

    q L0 = 2qV - T_ex/2 + 2(Lambda+rho)A^4.

The scalar equation before constancy also contains (partial q/q).partial phi. Writing alpha_A=partial_A ln A, it becomes

    D_Box phi^A + (partial_m q/q)partial^m phi^A
      = K^AB [partial_B V_eff - alpha_B T_ex/(2q)],
    V_eff=V+C A^4, C=(Lambda+rho)/(2q).

Once the form equations are imposed, the derivative-q terms vanish. This is the original analytic Einstein/scalar/matter system with the stated effective potential and supplied q. It is not legitimate to remove derivative-q terms before varying the action; the note explicitly avoids that shortcut.

The usual gravitational boundary terms and admissible metric/q boundary variations must be chosen consistently. The proof uses the stipulated well-posed boundary problem and arbitrary compactly supported bulk variations. It does not prove existence for every set of boundary pullbacks. If q is supplied by boundary data, that is compatible with the stated conditional branch; fixing Lambda separately would obstruct the proposed shift map.

## Dimensions and exact shift map

L0,V,R and C have mass dimension two; q has dimension two; Lambda,rho and T_ex have dimension four. The four-form component densities have dimension four, so both auxiliary coefficients are dimensionless. B_flux has dimension two. Every term in the integrated identity below has dimension four.

Under rho -> rho+delta, Lambda -> Lambda-delta with constant delta, the bulk matter and auxiliary vacuum operators cancel at every field value, including arbitrary u. The only action difference is

    -delta integral F/mu_aux^4.

Because F=dB and the pullbacks are fixed, the integral is a boundary number rather than a varied bulk observable in that sector. Thus the action changes by a field-independent constant and all classical equations/boundary data that do not separately prescribe Lambda map to themselves. The mapped q, metric, scalars, non-vacuum matter and forms are unchanged. This is a bijection of solution sets with its inverse shift.

At fixed numerical Lambda, the remaining operator is -delta A^4 vol_g. For variable delta(x), choosing Lambda'=Lambda-delta(x) violates dLambda'=0 unless ddelta=0. Neither case is covered by constant-shift covariance.

The result is a conditional classical statement. It does not supply a measure over sectors, convergence of the infinite-volume action, a mechanism selecting the observed H_v, or stability against excluded derivative operators and scalar/graviton loops. A quantum extension needs additional measure and boundary input. A divergent constant action shift on an infinite regulator sequence is not automatically a defined path-integral phase.

## Finite flux identity and the tracking lift

For a finite slab with c_F nonzero, the local auxiliary equations imply

    B_flux=-(q mu_aux^4/M_aux^4)c_hat/c_F
          = (integral L0 vol_g)/(integral A^4 vol_g).

Integrating the on-shell trace expression and using the same denominator for barV and barT gives

    Lambda+rho = q B_flux/2 - q barV + barT/4.

A^4-weighted volume in the denominator matters: these are not conventional unweighted averages unless A is constant or one includes the corresponding normalization. The RHS remains solution-dependent. This algebra neither removes the need for boundary input nor computes a small curvature.

At Lambda=-rho the effective potential is exactly V, so every original solution of the supplied local equations lifts to a solution of the auxiliary bulk equations. In homogeneous coordinates, F=f(t)dt wedge d^3x admits b(t)=b(t0)+integral f(t)dt, and similarly for the hatted form. The endpoint differences determine the compatible finite-slab fluxes. Different histories generally require different flux magnitudes and boundary pullbacks. For a fixed lifted history, rho shifts preserve those fluxes exactly.

For the tracking solution u=0,

    Q=-a(sigma+4r/3),
    V=3H_v^2/2+a sigma/2+a r/3,
    R=12H_v^2+2(1+a)sigma.

Direct substitution in R/2-Q-2V yields

    L0=3H_v^2+(1+a)sigma+(2a/3)r.

The trace formula gives the same result because T_ex=-2q sigma. On every finite positive-volume slab containing positive dust or radiation density, its weighted average is strictly larger than 3H_v^2. Specifying that endpoint value as a finite-slab ratio excludes the exact positive-fluid tracking history.

For finite comoving volume and fixed finite initial time, let N=ln(scale), so sigma=sigma_0 exp(-3N), r=r_0 exp(-4N). The dust contribution to the weighted numerator is proportional to integral dt, and grows linearly at late proper time. The radiation contribution is proportional to integral exp(-N)dt, which has a finite future tail. The denominator integral exp(3N)dt grows exponentially because H -> H_v>0. Their ratio therefore tends to 3H_v^2.

As an independent exact check for dust only, set z=exp(3N), k=2(1+a)sigma_0/(3H_v^2). Then

    integral exp(3N)dt
      = [sqrt(z(z+k))-k asinh(sqrt(z/k))]/(3H_v),
    integral dt = 2 asinh(sqrt(z/k))/(3H_v).

Differences of these primitives at the slab endpoints give the finite volume and dust correction. Differentiating both primitives is checked symbolically. Their asymptotics establish the finite-versus-future distinction without numerical quadrature.

For any original finite-energy homogeneous solution on C=0, the imported convergence theorem gives V -> 3H_v^2/2, T_ex -> 0, A -> 1 and H -> H_v. Thus L0/A^4 -> 3H_v^2 and the positive weighted-volume average has the same limit. This uses the expanding homogeneous branch and a fixed FLRW regulator. It does not define averages on arbitrary inhomogeneous spacetimes.

Both raw fluxes diverge on this future sequence. The ratio condition is weaker than specifying all absolute fluxes or all endpoint pullbacks. A single fixed finite c_F cannot describe an infinite positive-volume history, since c_F=mu_aux^4 integral A^4 vol_g. The note treats the future condition as an extra regulated boundary assumption, not as a finite number assigned to an infinite flux or an initial-value selection law.

## Stationary vacua and physical response

Write f(u)=2(u-sqrt(a)/4)^2+3a/8>0. Since the added C A^4 has no x or y dependence, stationarity forces x=y=0. Define t=sqrt(a)u and ell=nu/a. The u equation is

    C/H_v^2 = -(ell/4)t exp(-4t).

The constant-vacuum metric equation gives

    H_E^2/H_v^2 = 1+ell(2t^2-t)/6.

The form ratio is

    B_flux/H_v^2 = [3+ell(t^2-t)]exp(-4t).

At the supplied ratio 3, t=0 is a solution. For t<0 the bracket exceeds 3 and the exponential exceeds one. For 0<t<=1 the bracket is at most 3; if negative the product is already below 3, otherwise multiplication by exp(-4t)<1 makes it strictly smaller. Thus every other root has t>1.

The canonical u mass is

    m_u^2/H_v^2=nu(1-4t).

Every additional root therefore has a negative u-Hessian eigenvalue. At t=0, the mass eigenvalues are (nu,9/4,2)H_v^2. The x and y Hessian directions are positive at every stationary point; for x this follows directly from f(u)>0 and K_xx>0. Thus the stated unique positive-Hessian constant vacuum is correct. It is not a theorem of stability under all globally constrained perturbations or attraction of every extended-theory history.

For completeness, the derivative of the flux function is exp(-4t)[ell(-4t^2+6t-1)-12]. Its possible maximum for t>1 occurs at (3+sqrt(5-48/ell))/4. This splits all nonzero-root search intervals. The independent high-precision controls retain two nonzero roots for five of the twelve protocol parameter pairs, in addition to each zero root. All ten nonzero roots have the negative u mass required above.

The inverse-function derivative at t=0 is dt/depsilon=-1/(ell+12). The physical de Sitter clock and tensor coefficient are

    H_J/H_v=exp(-t)sqrt[1+ell(2t^2-t)/6],
    G_T,J/G_T,J(0)=exp(2t).

Consequently

    dt/depsilon=-a/(nu+12a),
    d(C/H_v^2)/depsilon=nu/[4(nu+12a)],
    d(H_J/H_v)/depsilon=1/12,
    d[G_T,J/G_T,J(0)]/depsilon=-2a/(nu+12a).

Omitting the conformal clock instead gives ell/[12(ell+12)] for the Hubble slope, and misses 1/(ell+12). The tensor-G statement is a tensor kinetic coefficient in the constant physical frame; it is not automatically a finite-range Newtonian force measurement including scalar exchange.
