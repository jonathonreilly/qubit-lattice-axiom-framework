#!/usr/bin/env python3
"""Independent minimal-action algebra and small high-precision proof controls.

No author implementation import. This is not an implementation review.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sympy as sp
import mpmath as mp
P=Path(__file__).resolve().parent
mp.mp.dps=80
checks=[]
def check(name,condition,**data):checks.append(dict(name=name,passed=bool(condition),**data))
def zero(name,expression):
 result=sp.factor(sp.simplify(expression));check(name,result==0,residual=str(result))
q,mu,M,w,A,R,Q,V,Lam,rho,delta,F,HAT,T=sp.symbols('q mu M w A R Q V Lambda rho delta F Fhat T_ex', nonzero=True)
L0=R/2-Q-2*V
lag=w*(q*L0-(Lam+rho)*A**4)+Lam*F/mu**4+q*q*HAT/(2*M**4)
zero('Lambda Euler derivative',sp.diff(lag,Lam)-(-w*A**4+F/mu**4))
zero('q Euler derivative includes complete L0',sp.diff(lag,q)-(w*L0+q*HAT/M**4))
Fsol=sp.solve(sp.diff(lag,Lam),F)[0];Hsol=sp.solve(sp.diff(lag,q),HAT)[0]
zero('F positive Jordan volume',Fsol-mu**4*A**4*w)
zero('Fhat sign and q factor',Hsol+M**4*L0*w/q)
zero('three-form q coefficient derivative',sp.diff(q*q/(2*M**4),q)-q/M**4)
shifted=lag.subs({rho:rho+delta,Lam:Lam-delta},simultaneous=True)
zero('exact action shift only fixed F term',shifted-lag+delta*F/mu**4)
zero('shift of scalar-dependent vacuum gradient',sp.diff((shifted-lag+delta*F/mu**4),A))
zero('fixed Lambda leaves vacuum term',lag.subs(rho,rho+delta)-lag+delta*w*A**4)
# Constant Weyl rescaling independently supplies the on-shell trace.
z=sp.symbols('z',real=True)
weyl=w*q*(sp.exp(2*z)*(R/2-Q)-2*sp.exp(4*z)*V)-w*(Lam+rho)*A**4*sp.exp(4*z)
trace_equation=sp.diff(weyl,z).subs(z,0)/w+T
Rsol=sp.solve(trace_equation,R)[0]
zero('trace from Weyl scaling',q*Rsol-(2*q*Q+8*q*V-T+4*(Lam+rho)*A**4))
zero('q L0 on shell',q*L0.subs(R,Rsol)-(2*q*V-T/2+2*(Lam+rho)*A**4))
BV,VT,TT=sp.symbols('B_flux barV barT')
residual=sp.solve(q*BV-2*q*VT+TT/2-2*(Lam+rho),Lam)[0]+rho
zero('integrated flux identity',residual-(q*BV/2-q*VT+TT/4))
# Tracking curvature and kinetic energy independently of the trace identity.
a,nu,hv,sm,sr,x,y=sp.symbols('a nu H_v sigma r x y',positive=True)
c=2*(1+a)/3;D=1+c*(x*x+y*y)
Kx=4*a/(9*D);Ky=a/(3*D)
H2=hv**2*D
kin=sp.factor(H2*(Kx*sp.Rational(9,4)*x*x+Ky*4*y*y))
zero('tracking kinetic',kin-a*hv**2*(x*x+sp.Rational(4,3)*y*y))
H2s=hv**2+c*(sm+sr);Hd=-(1+a)*(sm+sp.Rational(4,3)*sr)
curvature=6*(Hd+2*H2s);kin_s=a*(sm+sp.Rational(4,3)*sr)
Vtrack=sp.Rational(3,2)*hv**2+a*sm/2+a*sr/3
trackL0=sp.expand(curvature/2+kin_s-2*Vtrack)
zero('tracking curvature',curvature-(12*hv**2+2*(1+a)*sm))
zero('tracking full L0',trackL0-(3*hv**2+(1+a)*sm+2*a*sr/3))
zero('tracking trace alternative',trackL0-(2*Vtrack+sm))
# Two exact primitives for the dust-only positive-volume check.
s,k=sp.symbols('s k',positive=True)
volume_primitive=sp.sqrt(s*(s+k))-k*sp.asinh(sp.sqrt(s/k))
time_primitive=2*sp.asinh(sp.sqrt(s/k))
zero('dust-only weighted volume primitive',sp.diff(volume_primitive,s)-sp.sqrt(s/(s+k)))
zero('dust-only proper time primitive',sp.diff(time_primitive,s)-1/sp.sqrt(s*(s+k)))
# Vacuum stationarity in the actual original field coordinate.
u,u,C,t,ell=sp.symbols('nu u C t ell',real=True)
sqrt_a=sp.sqrt(a)
f=a/2-sqrt_a*u+2*u*u
V0=hv**2*(sp.Rational(3,2)+f*x*x+a*y*y/3+nu*u*u/2)
Veff=V0+C*sp.exp(4*sqrt_a*u)
zero('x force independent of auxiliary vacuum',sp.diff(Veff,x)-2*hv**2*f*x)
zero('y force independent of auxiliary vacuum',sp.diff(Veff,y)-2*hv**2*a*y/3)
zero('strictly positive x coefficient decomposition',f-(2*(u-sqrt_a/4)**2+3*a/8))
Csol=sp.solve(sp.diff(Veff,u).subs({x:0,y:0}),C)[0]
zero('stationary C',Csol+hv**2*nu*u*sp.exp(-4*sqrt_a*u)/(4*sqrt_a))
mu_u=sp.diff(Veff,u,2).subs({x:0,y:0,C:Csol})
zero('canonical u Hessian',mu_u-hv**2*nu*(1-4*sqrt_a*u))
mx=sp.diff(Veff,x,2).subs({x:0,y:0})/(4*a/9)
my=sp.diff(Veff,y,2).subs({x:0,y:0})/(a/3)
zero('origin x canonical mass',mx.subs(u,0)-sp.Rational(9,4)*hv**2)
zero('origin y canonical mass',my-2*hv**2)
zero('origin u canonical mass',mu_u.subs(u,0)-nu*hv**2)
BE=(2*V0+4*C*sp.exp(4*sqrt_a*u)).subs({x:0,y:0,C:Csol})*sp.exp(-4*sqrt_a*u)/hv**2
B=sp.simplify(BE.subs(u,t/sqrt_a).subs(nu,a*ell))
zero('vacuum flux equation',B-(3+ell*(t*t-t))*sp.exp(-4*t))
Hvac=sp.simplify((2*Veff/3).subs({x:0,y:0,C:Csol})/hv**2).subs(u,t/sqrt_a).subs(nu,a*ell)
zero('Einstein de Sitter H2',Hvac-(1+ell*(2*t*t-t)/6))
Bprime=sp.diff(B,t).subs(t,0);tprime=1/Bprime
zero('inverse regularity derivative',Bprime+ell+12)
zero('t first-order sensitivity',tprime+1/(ell+12))
Ct=sp.simplify(Csol/hv**2).subs(u,t/sqrt_a).subs(nu,a*ell)
zero('C first-order sensitivity',sp.diff(Ct,t).subs(t,0)*tprime-ell/(4*(ell+12)))
HJ=sp.exp(-t)*sp.sqrt(Hvac)
zero('physical H_J first-order sensitivity',sp.diff(HJ,t).subs(t,0)*tprime-sp.Rational(1,12))
zero('tensor Jordan G first-order sensitivity',sp.diff(sp.exp(2*t),t).subs(t,0)*tprime+2/(ell+12))
zero('Einstein-clock-only wrong sensitivity diagnostic',sp.diff(sp.sqrt(Hvac),t).subs(t,0)*tprime-ell/(12*(ell+12)))
zero('derivative shape for all other vacuum roots',sp.diff(B,t)*sp.exp(4*t)-(ell*(-4*t*t+6*t-1)-12))
# Exact rational inequalities covering the elementary uniqueness argument.
ineq=[]
for E in [sp.Rational(1,4),sp.Rational(1),sp.Rational(10),sp.Rational(1000),sp.Rational(1000000)]:
 for tv in [sp.Rational(-2),sp.Rational(-1,10),sp.Rational(1,10),sp.Rational(1),sp.Rational(2)]:
  if tv<0:
   passed=(3+E*(tv*tv-tv))>3 and -4*tv>0;kind='negative t bracket and exponential'
  elif tv<=1:
   passed=(3+E*(tv*tv-tv))<=3 and -4*tv<0;kind='positive t at most one upper bound'
  else:
   passed=(1-4*tv)<0;kind='all additional roots have negative u Hessian'
  check(kind+' '+str((E,tv)),passed)
# High-precision nonzero roots; retain every root located by derivative intervals.
def bisect(fn,lo,hi):
 flo,fhi=fn(lo),fn(hi)
 if flo==0:return lo
 if fhi==0:return hi
 assert flo*fhi<0,(str(lo),str(hi),str(flo),str(fhi))
 for _ in range(400):
  mid=(lo+hi)/2;fm=fn(mid)
  if fm==0:return mid
  if flo*fm<0:hi=mid
  else:lo=mid;flo=fm
 return (lo+hi)/2
root_rows=[]
for av in ['0.000001',str(mp.mpf(1)/2499),'0.01','1']:
 for nv in ['0.25','1','4']:
  aa,nn=mp.mpf(av),mp.mpf(nv);ee=nn/aa
  fun=lambda v:(3+ee*(v*v-v))*mp.exp(-4*v)-3
  roots=[mp.mpf(0)]
  if ee>12:
   maximum=(3+mp.sqrt(5-48/ee))/4
   if fun(maximum)>0:
    roots.append(bisect(fun,mp.mpf(1),maximum));hi=maximum+1
    while fun(hi)>0:hi+=1
    roots.append(bisect(fun,maximum,hi))
  row={'a':mp.nstr(aa,30),'nu':nv,'ell':mp.nstr(ee,30),'roots':[]}
  for rv in roots:
   rr=fun(rv);mh=nn*(1-4*rv);hh=1+ee*(2*rv*rv-rv)/6
   check('vacuum root residual '+str((av,nv,mp.nstr(rv,12))),abs(rr)<mp.mpf('1e-65'),residual=mp.nstr(rr,12))
   check('vacuum root physical/classification '+str((av,nv,mp.nstr(rv,12))),hh>0 and (mh>0 if rv==0 else rv>1 and mh<0))
   row['roots'].append({'t':mp.nstr(rv,60),'residual':mp.nstr(rr,20),'u_mass2_over_Hv2':mp.nstr(mh,40),'H_E2_over_Hv2':mp.nstr(hh,40),'positive_hessian':rv==0})
  root_rows.append(row)
# Fixed-Lambda and dropped-full-L0 controls are meant to be nonzero.
check('fixed Lambda shift produces nonzero operator',sp.diff(lag.subs(rho,rho+delta)-lag,w)==-delta*A**4)
check('dropping scalar terms from q variation is not equivalent',sp.simplify((R/2)-L0)==Q+2*V)
check('dropped-scalar q equation fails at vacuum',sp.simplify((R/2-L0).subs({R:12*hv**2,Q:0,V:sp.Rational(3,2)*hv**2}))==3*hv**2)
check('omitted Jordan clock changes sensitivity',sp.simplify(sp.Rational(1,12)-ell/(12*(ell+12)))==1/(ell+12))
# Constant shifts satisfy dLambda=0. A nonconstant shift does not.
xi=sp.symbols('xi');deltax=sp.Function('delta')(xi)
zero('nonconstant shift leaves forbidden Lambda derivative',sp.diff(Lam-deltax,xi)+sp.diff(deltax,xi))
out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'role':'Independent handwritten proof checks; no parent implementation read/imported.','checks':checks,'vacuum_roots':root_rows,'symbolic_expressions':{'trace':str(Rsol),'tracking_L0':str(trackL0),'vacuum_B_over_Hv2':str(B),'C_over_Hv2':str(Ct),'H_E2_over_Hv2':str(Hvac),'H_J_over_Hv':str(HJ),'t_prime':str(tprime)},'summary':{'total':len(checks),'passed':sum(z['passed']for z in checks),'failed':sum(not z['passed']for z in checks)}}
(P/'DERIVATION_RESULTS_v2.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary']))
for row in root_rows:print(json.dumps({'a':row['a'],'nu':row['nu'],'number_of_roots':len(row['roots']),'nonzero_t':[z['t']for z in row['roots'][1:]]}))
for z in checks:
 if not z['passed']:print(json.dumps(z))
raise SystemExit(int(out['summary']['failed']>0))
