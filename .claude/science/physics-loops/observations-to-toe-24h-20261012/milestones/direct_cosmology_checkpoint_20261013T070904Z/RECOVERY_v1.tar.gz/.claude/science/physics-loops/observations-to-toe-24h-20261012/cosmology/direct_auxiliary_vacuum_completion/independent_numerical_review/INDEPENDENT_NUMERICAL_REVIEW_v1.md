# Independent numerical review — auxiliary vacuum completion v1

Reviewer: /root/direct_quantum_visibility_review. Date: 2026-10-13.
Parent remains the scientific author. This check covers the implementation,
its recorded outputs, input lineage, and concrete mutation sensitivity.
It is not a formal audit, empirical test, publication gate, or replacement
handwritten boundary-value proof.

## Disposition and required corrections

The original scientific outputs independently check. The first independent
run passed **4,666 checks, with zero failures**, including every scientific
output field and coverage of all 1,089 recorded author assertions. No
incorrect original root, flux integral, canonical mass, Hubble factor, or
tensor-coupling value was identified.

The v1 validator nevertheless has two material coverage gaps:

1. **R1 — root completeness.** Disabling the nonzero-root search leaves a
   successful run with 999 passing assertions and only 12 vacua. Ten real
   nonzero roots are silently omitted. The checks certify roots that were
   visited, but do not require the complete expected root set.
2. **R2 — reported-output integrity.** Changing only serialized C, physical
   Hubble, or finite-flux values can leave every one of the 1,089 checks
   passing. The original reported values are correct, but the validator
   does not check these output fields after construction.

These are validation gaps, not counterexamples to the original mathematics.
They should be repaired before treating the runner as sensitive to the
claimed output and root-coverage errors. No author source was edited.

A narrow repair is to check per-parameter root cardinality, distinct root
intervals and row identities independently of the enumeration loop, and to
validate the completed output records against the action/flux equations and
their reported coordinates. A check of a temporary internal value before
serialization does not close R2. The repair should retain the finite-minus-
future residual and account for its printed precision. An affected-source
review can then repeat exactly the surviving mutations without rerunning
unrelated science.

## Frozen identities and scope

| Artifact | SHA-256 |
| --- | --- |
| Parent runner | bed27c87d143cd4c24cdb7477b2cc3e6abde23b3499e5a226810aa5acfbf163b |
| Parent first RESULTS.json | 605fa7902953cc084b6daf529d21f26e34d9f3549f75d171454ecfdada8c4fa6 |
| HAND_DERIVATION_v1.md | 989e6b051b67e68e188738672bb67eb08f65236c73040b8bd87b04562ccb48b4 |
| Reviewer independent_recompute_v1.py | f2fbf383faca933e09104b7580f83800349a5d8e33151e2b148430dad7b049e9 |
| Reviewer INDEPENDENT_RESULTS_v1.json | e7e704142776da1e9e6ac79cbddca78534d038cb2c07b17851d1dd110b4370e0 |

SOURCE_FREEZE_v1.json binds the nine complete inputs and all first-execution
evidence/source snapshots, with exact reviewer recovery copies. All nine
original frozen input identities matched before review. The full action note,
protocol, numerical inputs/details, source ledger, runner, freeze and
execution receipts were read. The inherited analytic and matter-vacuum
derivations were reused by their exact previously reviewed identities.
READING_LEDGER_v1.json distinguishes original source reading, exact-copy
verification, and narrower calibration reading.

The input lineage supplies m=.3 and an already exposed photons-only
Omega_gamma=5.046740289227271e-5. The pointer to the original radiation
result and the original H0/matter-fraction fixture were verified by hash and
selected field. No new radiation fit or data assessment was performed.
There are zero independent empirical tests in this block.

The source ledger's Kaloper et al citation was read as provenance. This
numerical reviewer did not read that PDF and does not use it as a positive
oracle. The separate mathematical reviewer owns the handwritten auxiliary
and boundary-premise assessment. No primary PDF was copied into this review.

## Independent action and trace reconstruction

No author module was imported or executed as positive evidence.
The independent source starts from the action density and a constant metric
Weyl variation. Holding the scalar coordinates fixed,
\[
\delta_\omega S/\sqrt{-g}
 =qR-2qQ-8qV-4(\Lambda+\rho)A^4+T_{\rm ex}.
\]
Thus
\[
qR=2qQ+8qV-T_{\rm ex}+4\widetilde\Lambda A^4,\qquad
qL_0=2qV-T_{\rm ex}/2+2\widetilde\Lambda A^4.
\]
The q and Lambda variations of the auxiliary terms were independently
differentiated, and the constant compensation map was applied directly to
the full density. Its surviving change is
\(-\delta F/\mu_{\rm aux}^4\). The source's signs and q factors agree.

The weighted trace consequently gives
\[
C=\frac{\widetilde\Lambda}{2q}
 =B_{\rm flux}/4-\overline V/2+\overline T/(8q),
\]
equivalent to the recorded Lambda-tilde relation. These algebra controls do
not prove the well-posed boundary variational problem or its physical
selection; those remain explicit premises.

For the shift outputs, the exact unchanged residual is 2/9. The independent
check compared both recorded residual fields and all operator-derivative
assertions against that exact value, including the fixed-Lambda contrast.
At shifts of magnitude 1e40, the original 90-digit subtraction loses
approximately 40 digits. Its frozen 1e-48 tolerance is appropriate for
these particular inputs. The largest normalized discrepancy in the original
stored assertions was 2.6728e-51, below that allowance.

## Independent finite-volume calculation and future distinction

The independent quadrature used inverse scale \(y=e^{-N}\), rather than
the author's N or normalized scale variable:
\[
H(y)^2=1+B_m y^3+B_r y^4,\quad
dt=-\frac{dy}{yH(y)},\quad B_m=m/v,\quad B_r=\Omega_\gamma/v,\quad
v=1-m-\Omega_\gamma.
\]
For endpoint \(y_e=e^{-N_e}\) and initial \(y_i=10^6\), the three scaled
integrals are
\[
I_V=y_e^3\int_{y_e}^{y_i}\frac{dy}{y^4H(y)},\quad
I_d=y_e^3\int_{y_e}^{y_i}\frac{dy}{yH(y)},\quad
I_r=y_e^3\int_{y_e}^{y_i}\frac{dy}{H(y)}.
\]
They were evaluated at 100 digits using piecewise inverse-scale tanh-sinh
quadrature. Independently, the full curvature was calculated from
\(\dot H=-yH\,dH/dy\), and the kinetic norm from the actual x/y field
velocities and K. This reconstructs
\[
L_0=R/2-Q-2V=3+(1+a)\sigma+2ar/3
\]
without importing the author's reduced-integrand function.

The 24 finite-slab rows were rebuilt from these integrals. This covers
B, its standalone excess over three, all three scaled integrals, weighted
V and weighted T/q. The signed form-flux relation and zero-residual
integrated trace agree. The smallest scaled quantities are tested by
relative error; an absolute tolerance of order one is not used to hide them.

At N_end=0, B/H_v^2 ranges approximately from 5.29861781948 to
5.29905349749 over the four a choices. At N_end=20 it is still strictly
greater than three, with the positive excess approximately
3.5034583913e-25 to 3.5034932430e-25. The worst non-shift relative
discrepancy was 1.8919e-66 in the last excess field, below the review's
1e-55 numerical comparison tolerance.

The finite results therefore do not equal the prescribed future ratio.
The raw fluxes were scaled by the same endpoint factor only for numerical
conditioning; that rescaling preserves their ratio. This is not evidence
that the unscaled infinite-time fluxes are finite. The implementation's
future-limit check is consistent with the stated regulated FLRW limit,
not an average over arbitrary infinite spacetimes.

## Every vacuum and neighboring-flux output

Additional roots were counted by a route separate from the author's extrema
formula. For t>1, rearrange the boundary equation as
\[
\ell=\frac{3(e^{4t}-1)}{t(t-1)}=:L(t),\qquad \ell=\nu/a.
\]
The only minimum of L occurs where
\[
g(t)=4t^2-6t+1+(2t-1)e^{-4t}=0.
\]
For t>1,
\(g'(t)=(8t-6)(1-e^{-4t})>0\), with g(1)<0 and g tending positive.
The independent values are
\[
t_*=1.3070780865454137\ldots,\qquad
\ell_*=1386.3181089949893\ldots .
\]
Above this threshold there are two nonzero roots, found separately on the
two monotone branches. Below it there are none. This yields:

| a | nu=.25 | nu=1 | nu=4 |
| --- | ---: | ---: | ---: |
| 1e-6 | 3 roots | 3 roots | 3 roots |
| 1/2499 | 1 root | 3 roots | 3 roots |
| .01 | 1 root | 1 root | 1 root |
| 1 | 1 root | 1 root | 1 root |

The total is 22 roots: 12 origins and 10 nonzero roots. The original output
contains exactly this set. The critical double-root parameter is outside
the supplied grid; this check does not certify arbitrary-grid robustness
at that degenerate threshold.

For each root, the independent calculation reconstructed C from the scalar
force, the full potential at the stationary point, the Einstein Hubble rate,
the Jordan factor H_J=H_E/A, tensor G ratio A^2, and the canonical Hessian.
It compared every reported field, including negative C and the negative
u-Hessian eigenvalue at each nonzero root. Positive-Hessian classification
is distinguished from global boundary-value stability.

All 48 neighboring-flux rows were independently solved using Newton-Halley
on the eliminated boundary equation, rather than importing either of the
author's solvers. The outputs and finite-epsilon secants were reconstructed.
Their exact zero-epsilon derivatives are
\[
t_\epsilon=-\frac1{\ell+12},\quad
C_\epsilon=\frac{\ell}{4(\ell+12)},\quad
(H_J)_\epsilon=\frac1{12},\quad
(G_T)_\epsilon=-\frac2{\ell+12}.
\]
The source's conformal-clock factor is necessary for the third identity.
The numerical comparisons validate the original finite-epsilon outputs;
they do not convert the supplied boundary input into an observed datum.

## Actual source mutations with fresh source identities

Every mutant was a real copy of the complete nine-input source set. Only
the stated source expression was changed; no assertions or tolerances were
weakened. Its FREEZE.json named and hashed the actual copied files, including
the mutated runner. All nine source-hash assertions passed in all seven
cases, so detection cannot be attributed to stale source pins.

| Mutant | Parent failed checks | Exit | Result |
| --- | ---: | ---: | --- |
| Reverse the compensating Lambda sign | 192 | 1 | Detected |
| Replace computed finite B with 3 | 120 | 1 | Detected |
| Disable nonzero-root search | 0 of 999 | 0 | Missed: ten roots omitted |
| Drop H_J=H_E/A clock conversion internally | 40 | 1 | Detected |
| Serialize C=0 for every vacuum | 0 of 1,089 | 0 | Missed: ten C fields wrong |
| Serialize H_E into H_J fields | 0 of 1,089 | 0 | Missed: 58 Hubble fields wrong |
| Serialize B=3 in finite-slab rows | 0 of 1,089 | 0 | Missed: 24 finite B fields wrong |

The independent output reference detects every mutant. For omitted roots,
a length/identity failure is the essential finding; subsequent aligned-list
differences are consequences of missing rows, not separately counted wrong
physical solutions. For the internal clock mutant, additional secant fields
also change. The independent corrected mutation comparison retains every
mismatch and distinguishes these cases.

MUTATION_RESULTS_v1.json records the actual executions. Each mutation
directory contains its source copies, exact diff, fresh freeze, launch
receipt, stdout/stderr, full result and execution receipt. No unmodified
author run was repeated as part of these tests.

## Coverage, real failures, and reproduction

The independent positive result includes all 1,434 output leaves
(parameter labels included), of which 1,018 are computed numerical output
fields, plus shape/row controls. It accounts for every one of the 1,089
author assertion names, their flags and stored actual/expected values
where present. It also checks source-hash and count consistency. The
finite grid is not a substitute for the separate handwritten theorem.

The positive code used Python 3.12.8, mpmath 1.3.0, and SymPy 1.14.0.
INDEPENDENT_EXECUTION_v1.json records its first execution: about 2.33
seconds, exit 0, 4,666 passed and none failed. No passed positive
calculation or author mutant was rerun.

Actual review-side failures were preserved:

- The initial read requested NUMERICAL_DETAILS_v1.md; the file is .json.
  That command's exit 1 and correction are in
  RECOVERY_AND_READ_FAILURE_v1.json.
- Two communication interruptions were reported by the parent:
  696b7d6e-19e9-4bbe-a15e-3055b494e553 and
  4d126682-37d5-4941-8791-64a1a2f853cc. No transport stack trace is
  invented.
- The first independent mutant-output comparator applied the 1e-48
  large-shift rounding allowance only to a baseline prefix. Mutant
  prefixes incorrectly received 1e-55, producing 24 rounding-only
  false positives in six mutation summaries. The original result/code
  are immutable. correct_mutant_comparison_v2.py corrected only that
  comparison bookkeeping, using the saved values; no integral, root,
  author execution, or passing control was rerun.
  MUTANT_OUTPUT_COMPARISON_v2.json retains each reclassification.
  None of the four surviving-mutant findings depends on those false
  positives.

For reproduction, use a separate empty copy of the reviewer scripts and
their snapshot directory. The scripts create outputs exclusively and
intentionally refuse to overwrite existing evidence. A mutation run
executes only its copied source tree. No parent/source edits, repository
operations, external messages, audit actions, or model/settings changes
were performed.

The exact original outputs are independently supported within the declared
conditional candidate and exposed-input scope. Closing R1 and R2 remains
required for the stronger assertion that this validation runner reliably
detects missing roots and wrong reported outputs.

