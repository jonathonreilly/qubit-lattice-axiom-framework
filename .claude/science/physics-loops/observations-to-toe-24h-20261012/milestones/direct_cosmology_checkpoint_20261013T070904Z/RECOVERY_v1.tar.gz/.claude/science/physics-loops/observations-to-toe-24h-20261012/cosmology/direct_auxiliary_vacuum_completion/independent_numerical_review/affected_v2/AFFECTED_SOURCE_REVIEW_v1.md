# AUX v2 affected-source review

Reviewer: /root/direct_quantum_visibility_review. Date: 2026-10-13.
Scope: the v1-to-v2 assertion correction, preservation of original scientific
source/results, and four exact previously surviving mutations. Parent
remains author. No independent positive science, unmodified author run, or
previously completed mutant was rerun.

## Disposition

**R1 and R2 are closed for the identified failure modes and frozen grid.**
The four source mutations that passed v1 now fail mathematical checks in
v2. Every mutated input has its correct fresh source hash; no detection
relies on stale identities or a hash mismatch.

The original valid independent positive result, 4,666 passed and zero
failed, is reused through exact source and output preservation. The
parent's frozen v2 execution records 1,784 passed and zero failed. This
affected check does not add a new empirical test, alter the conditional
candidate's scope, or constitute an audit/publication/landing verdict.

## Exact identities and preservation

| Source or evidence | SHA-256 |
| --- | --- |
| Parent v2 runner | aaeafe7c00dc221896a41c75b2fe56c8fc643e5401dd5d8ea09a1d6b5ff6ee17 |
| Parent correction receipt | 80340fbdd6c0b60265466fc9569e21c2d9e96b9f640b9ce9a2fa24bb9fe46d51 |
| Parent evidence_v2/RESULTS.json | 9343c60c2ed4f5cf5a11d9b457c912b2e6b9d3ecc95d49908ffa4ee405f251a9 |
| Prior parent v1 runner | bed27c87d143cd4c24cdb7477b2cc3e6abde23b3499e5a226810aa5acfbf163b |
| Prior parent v1 result | 605fa7902953cc084b6daf529d21f26e34d9f3549f75d171454ecfdada8c4fa6 |
| Reused independent positive result | e7e704142776da1e9e6ac79cbddca78534d038cb2c07b17851d1dd110b4370e0 |

The complete current runner, correction record, and raw source diff were
read. The ten-input freeze and complete first-execution metadata/logs were
inspected and copied exactly. SOURCE_FREEZE_v1.json binds original and
recovery paths. TRANSFER_IDENTITY_v1.json records these direct comparisons:

- All eleven original non-main functions are text-identical and AST-identical:
  check, exact, number, fmt, close, symbolic_controls,
  constant_shift_controls, flux_integrals, bisect, stationary_data,
  and vacuum_controls.
- The only added function is serialized_controls. Main calls that function
  and changes the result schema to v2. The full diff shows no original
  scientific expression or tolerance change.
- All four scientific sections are exactly equal between the frozen v1 and
  v2 JSON results: 60 shifts, 24 finite slabs, 22 constrained vacua, and
  48 neighboring-flux rows. All 1,434 scientific output leaves, including
  labels, are unchanged.
- All 1,080 original non-source assertion objects are exactly equal.
  The new total comprises those 1,080, ten source checks, and 694 new
  serialized-record/census checks.

These checks justify reuse of the previous independent integrals, root
catalog, Hessians, frame conversions, and source-lineage assessment.
No new literature or calibration claim is introduced here.

## Changed-source mathematical coverage

### R1: nonzero-root completeness

The new census computes the minimum of
\[
L(t)=3\,\operatorname{expm1}(4t)/[t(t-1)],\qquad t>1,
\]
using the root of
\(g(t)=4t^2-6t+1+(2t-1)e^{-4t}\).
This is separate from the enumerator's extrema of the original b(t).
The earlier independently checked derivative
\(g'(t)=(8t-6)(1-e^{-4t})>0\) establishes a unique minimum for t>1.

The new checks require the expected one or three roots for each frozen
(a,nu) pair, exactly one origin, distinctness, both nonzero monotone
branches when required, the total count, and valid parameter identities.
The explicit nondegenerate-grid guard rejects proximity to the critical
double-root threshold; the check does not silently certify that excluded
case. The resulting expected total is the independently established
22, including ten nonzero roots.

Disabling the original nonzero-root search still leaves only twelve
origins. V2 now fails the five affected per-pair counts, five two-branch
checks, and total count: eleven mathematical failures. This closes the
specific enumeration blind spot without relying on the total number of
assertions.

### R2: completed scientific records

The added function reads the completed dictionaries that are placed in the
result, rather than the earlier temporary values from stationary_data.
For each vacuum and neighboring-flux record it reconstructs the scalar
force, C, total potential, physical Hubble rate, tensor coefficient, and
curvature flux; vacuum records also reconstruct all three canonical masses.

The formulas agree with the previously checked action:
\[
u=t/\sqrt a,\quad A^4=e^{4t},\quad
V_{\rm bare}=3/2+\nu u^2/2,\quad
V_{\rm total}=V_{\rm bare}+Ce^{4t},
\]
\[
H_J=\sqrt{2V_{\rm total}/3}\,e^{-t},\quad
G_{T,J}/G_{T,J}(0)=e^{2t},
\]
\[
B=(4V_{\rm total}-2V_{\rm bare})e^{-4t}.
\]
The u force and Hessian retain their direct C dependence, so replacing a
reported C with zero is not masked by substituting the stationary relation
into both sides of every check.

For finite flux records, B is reconstructed from the recorded volume, dust
and radiation integrals with the supplied amplitude coefficients. The
standalone tiny positive excess receives a relative comparison. The reported
B is compared with that excess and must remain strictly greater than its
future value. Thus a report containing B=3 is rejected even while its
separately recorded excess remains correct.

The extreme constant-shift records retain their appropriate 1e-48
comparison budget. The original 1e-65 equation and 1e-55 relative
tolerances are not relaxed. Seventy-five-digit output formatting is
compatible with the chosen finite-excess checks on this fixed grid.

This closes the concrete C, H_J and finite-B serialization failures.
It is not a proof of universal detection of every possible record
corruption. For example, the added function does not itself provide a
full census of sensitivity/flux records or separately check every
stored secant/derivative array or weighted-V/T field. Those original
values remain supported by exact output equality and the prior
independent calculation. No broader claim about arbitrary future
serialization edits is made.

## Exact repeated mutation results

run_affected_mutations_v1.py reads the four replacement specifications from
the immutable prior mutation plan. It applies the same old/new expression
and occurrence count to exact copies of v2, then freezes all ten actual
copied inputs afresh. Assertions and tolerances are unchanged.

| Exact v1 survivor | V2 pass | V2 fail | Exit | New mathematical detection |
| --- | ---: | ---: | ---: | --- |
| Disable nonzero-root search | 1,603 | 11 | 1 | Per-pair branch/count and total census |
| Serialize C=0 | 1,734 | 50 | 1 | Force, C, energy/Hubble, flux and u mass |
| Serialize H_E as H_J | 1,726 | 58 | 1 | Physical-clock energy relation |
| Serialize finite B=3 | 1,712 | 72 | 1 | B integral/excess relations and finite positivity |

All ten source-hash checks pass in each case. Every failed assertion starts
with serialized.; every original non-source check still passes. The lower
total count in the omitted-root mutant reflects its missing root rows, but
its rejection comes from the independent census, not a fixed assertion
quota.

MUTATION_RESULTS_v1.json and each mutation directory preserve the exact
modified source, raw diff, fresh freeze, command/PID launch record,
stdout/stderr, result and execution receipt. Each mutant ran once.
No unmodified v2 runner was rerun for this review.

## Reading, failures, and remaining scope

The inherited initial review remains the source for full input lineage,
independent mathematics and positive numerical coverage. The new reading
is confined to the complete changed runner/diff/correction, frozen v2
inputs and evidence, source/output equality, and these four mutations.

There was no unexpected numerical or tool failure in this affected check.
The four exit-1 mutation results are expected, preserved negative evidence.
A parent-reported stream interruption with request ID
50125d7d-5b7c-4744-84e4-2273c0941051 occurred after the completed mutation
results were communicated. RECOVERY_v1.json records it and confirms that
the reviewer mutation driver had finished before finalization. No
transport stack trace is invented and no completed work was restarted.

The scalar/auxiliary boundary assumptions, supplied H_v and Planck scale,
exposed cosmological inputs, and absence of independent empirical tests
are unchanged. No claim about general topological-sector quantization,
global boundary-value dynamics, observed vacuum energy, or the full
cosmological-constant problem is added by closing these validation gaps.

