#!/usr/local/bin/python3
"""Repeat the four exact v1 survivors against copied v2 source with fresh pins."""
from pathlib import Path
import datetime as dt,hashlib,json,subprocess,time,difflib,os
HERE=Path(__file__).resolve().parent
SNAP=HERE/"snapshots"/"author_inputs"
BASE=SNAP/"direct_auxiliary_vacuum_completion"/"check_auxiliary_vacuum_v2.py"
BASEHASH="aaeafe7c00dc221896a41c75b2fe56c8fc643e5401dd5d8ea09a1d6b5ff6ee17"
PREVIOUS=HERE.parent/"MUTATION_PLAN_v1.json"
wanted={"m3_drop_nonzero_roots","m5_output_C_zero","m6_output_H_as_Einstein","m7_output_finite_flux_as_limit"}
prior=json.loads(PREVIOUS.read_text())
mutations=[x for x in prior["mutations"] if x["id"] in wanted]
assert len(mutations)==4
def digest(data):return hashlib.sha256(data).hexdigest()
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def dump(p,v):
    with p.open("x") as f:json.dump(v,f,indent=2);f.write("\n")
raw=BASE.read_bytes();assert digest(raw)==BASEHASH
dump(HERE/"MUTATION_PLAN_v1.json",{
 "created_at":now(),"driver_pid":os.getpid(),"v2_source_sha256":BASEHASH,
 "prior_plan_path":str(PREVIOUS),"prior_plan_sha256":digest(PREVIOUS.read_bytes()),
 "mutations":mutations,"scope":"Same four exact source replacements. All ten copied input paths freshly hashed; original tests/tolerances unchanged."})
summaries=[]
for item in mutations:
    name=item["id"];old=item["old"];new=item["new"];count=item["replacement_count"]
    case=HERE/"mutations"/name;source=case/"source";start=now();tick=time.monotonic()
    for f in sorted(SNAP.rglob("*")):
        if f.is_file():
            out=source/f.relative_to(SNAP);out.parent.mkdir(parents=True,exist_ok=True)
            with out.open("xb") as h:h.write(f.read_bytes())
    runner=source/"direct_auxiliary_vacuum_completion"/BASE.name
    text=raw.decode();assert text.count(old)==count,(name,text.count(old))
    changed=text.replace(old,new);runner.write_text(changed)
    with (case/"MUTATION.diff").open("x") as f:
        f.write("".join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile=BASE.name,tofile=name+"/"+BASE.name)))
    inputs=[{"path":str(f),"sha256":digest(f.read_bytes())} for f in sorted(source.rglob("*")) if f.is_file()]
    assert len(inputs)==10
    freeze=case/"FREEZE.json";dump(freeze,{"inputs":inputs,"reviewer_mutation":name})
    cmd=["/usr/local/bin/python3",str(runner),"--freeze",str(freeze),"--output-json",str(case/"RESULTS.json")]
    with (case/"stdout.txt").open("xb") as stdout,(case/"stderr.txt").open("xb") as stderr:
        proc=subprocess.Popen(cmd,cwd=runner.parent,stdout=stdout,stderr=stderr)
        dump(case/"LAUNCH.json",{"started_at":start,"pid":proc.pid,"driver_pid":os.getpid(),"command":cmd,
                                "source_sha256":digest(runner.read_bytes())})
        ret=proc.wait()
    result=json.loads((case/"RESULTS.json").read_text()) if (case/"RESULTS.json").exists() else None
    failed=[r for r in result["checks"] if not r["passed"]] if result else []
    rec={"id":name,"started_at":start,"finished_at":now(),"seconds":time.monotonic()-tick,
         "exit_code":ret,"source_sha256":digest(runner.read_bytes()),
         "result_sha256":digest((case/"RESULTS.json").read_bytes()) if result else None,
         "counts":result["counts"] if result else None,
         "source_checks_all_pass":all(r["passed"] for r in result["checks"] if r["name"].startswith("source.")) if result else False,
         "source_check_count":sum(r["name"].startswith("source.") for r in result["checks"]) if result else None,
         "failed_assertions":failed,"failure_names_all_serialized":all(r["name"].startswith("serialized.") for r in failed),
         "original_non_source_checks_all_pass":all(r["passed"] for r in result["checks"] if not r["name"].startswith(("source.","serialized."))) if result else False,
         "scientific_section_lengths":{k:len(result[k]) for k in ["constant_shifts","finite_fluxes","constrained_vacua","flux_sensitivity"]} if result else {}}
    dump(case/"EXECUTION.json",rec);summaries.append(rec)
    print(json.dumps({k:rec[k] for k in ["id","exit_code","counts","source_checks_all_pass","failure_names_all_serialized"]}),flush=True)
dump(HERE/"MUTATION_RESULTS_v1.json",{"created_at":now(),"mutations":summaries})

