#!/usr/local/bin/python3
"""Correct only the mutant comparison's large-shift rounding allowance."""
from pathlib import Path
import json, hashlib, datetime as dt
import mpmath as mp
mp.mp.dps=100
HERE=Path(__file__).resolve().parent
source=HERE/"INDEPENDENT_RESULTS_v1.json"
old=json.loads(source.read_text())
new=[];changes=[]
for case in old["mutant_output_checks"]:
    failures=[];rescued=0
    for row in case["mismatches"]:
        if ".constant_shifts[" in row["name"] and ".local_residual_" in row["name"]:
            actual=mp.mpf(row["actual"]);expected=mp.mpf(row["expected"])
            error=abs(actual-expected)/max(mp.mpf(1),abs(expected))
            passed=error<=mp.mpf("1e-48")
            changes.append({"case":case["id"],"name":row["name"],"old_tolerance":row["tolerance"],
                            "correct_tolerance":"1e-48","error":mp.nstr(error,90),
                            "passes_correct_budget":passed})
            if passed:rescued+=1;continue
            row={**row,"tolerance":"1e-48","pass":False}
        failures.append(row)
    counts=case["independent_output_checks"]
    new.append({**case,"independent_output_checks":{
        "pass":counts["pass"]+rescued,"fail":counts["fail"]-rescued,"total":counts["total"]},
        "mismatches":failures,"rounding_only_false_positives_removed":rescued})
result={"created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
        "scope":"Affected bookkeeping only; no symbolic, integral, root, author or mutant execution rerun.",
        "original_results_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
        "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cause":"compare_tree selected the 1e-48 large-shift allowance only for a baseline prefix; mutant prefixes incorrectly used 1e-55. Scientific reference and original positive results unchanged.",
        "baseline_counts_unchanged":old["baseline_counts"],"reclassified_rows":changes,
        "mutant_output_checks":new}
with (HERE/"MUTANT_OUTPUT_COMPARISON_v2.json").open("x") as f:
    json.dump(result,f,indent=2);f.write("\n")
print(json.dumps([{"id":x["id"],"corrected_counts":x["independent_output_checks"],
                  "rounding_only_false_positives_removed":x["rounding_only_false_positives_removed"]} for x in new],indent=2))

