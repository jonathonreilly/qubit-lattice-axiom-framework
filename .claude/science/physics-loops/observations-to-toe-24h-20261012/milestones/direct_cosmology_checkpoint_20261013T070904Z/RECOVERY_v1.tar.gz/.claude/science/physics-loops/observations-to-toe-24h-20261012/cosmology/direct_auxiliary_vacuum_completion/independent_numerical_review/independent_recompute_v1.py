#!/usr/local/bin/python3
"""Independent AUX recomputation; no author module imports or code execution."""
from pathlib import Path
import json, hashlib, datetime as dt, sys, collections
import mpmath as mp
import sympy as sp
HERE=Path(__file__).resolve().parent
SNAP=HERE/"snapshots"/"author_inputs"/"direct_auxiliary_vacuum_completion"
mp.mp.dps=100
protocol=json.loads((SNAP/"PROTOCOL_v1.json").read_text())
inputs=json.loads((SNAP/"NUMERICAL_INPUTS_v1.json").read_text())
AUTHOR=HERE/"snapshots"/"evidence_v1"/"RESULTS.json"
rows=[]; assertion_reference={}; science_reference={}
def num(v):
    if isinstance(v,str) and "/" in v:
        a,b=v.split("/");return mp.mpf(a)/mp.mpf(b)
    return mp.mpf(v)
def text(x):return mp.nstr(x,92) if isinstance(x,(mp.mpf,mp.mpc)) else x
def record(name,passed,**details):
    rows.append({"name":name,"pass":bool(passed),**details})
def equal(name,a,b,tol="1e-55",relative=False):
    aa,bb=num(a),num(b)
    den=abs(bb) if relative and bb else max(mp.mpf(1),abs(bb))
    err=abs(aa-bb)/den
    record(name,err<=num(tol),actual=text(aa),expected=text(bb),
           error=text(err),tolerance=tol,relative=relative)
    return err
def assertion(name,actual=None,expected=None,tol="1e-55",passed=True):
    assert name not in assertion_reference,name
    assertion_reference[name]={"actual":actual,"expected":expected,"tolerance":tol,"passed":bool(passed)}
def symbolic(name,actual,expected=0):
    rem=sp.simplify(sp.expand_log(actual-expected,force=True))
    record("independent_symbolic."+name,rem==0,residual=str(rem))
def checkpoint(name,data):
    with (HERE/name).open("x") as f:json.dump(data,f,indent=2);f.write("\n")

# Independent action/trace route: a constant metric Weyl variation.
q,L,rho,delta,A4,F,Fh,mu,M,Q,V,T,R=sp.symbols("q L rho delta A4 F Fh mu M Q V T R",nonzero=True)
omega=sp.symbols("omega",real=True)
weyl=sp.exp(2*omega)*(q*R/2-q*Q)-sp.exp(4*omega)*(2*q*V+(L+rho)*A4)+omega*T
trace=sp.diff(weyl,omega).subs(omega,0)
symbolic("metric_trace",trace,q*R-2*q*Q-8*q*V-4*(L+rho)*A4+T)
Rsol=sp.solve(trace,R)[0]
symbolic("on_shell_qL0",q*(Rsol/2-Q-2*V),2*q*V-T/2+2*(L+rho)*A4)
lag=q*sp.Symbol("L0")-(L+rho)*A4+L*F/mu**4+q*q*Fh/(2*M**4)
symbolic("constant_action_shift",lag.subs({rho:rho+delta,L:L-delta},simultaneous=True)-lag,-delta*F/mu**4)
symbolic("aux_Lambda",sp.diff(lag,L),-A4+F/mu**4)
symbolic("aux_q",sp.diff(lag,q),sp.Symbol("L0")+q*Fh/M**4)
# Eliminate the vacuum coefficient from the volume-weighted trace equation.
B,Vbar,Tbar,C=sp.symbols("B Vbar Tbar C")
symbolic("integrated_constraint",sp.solve(q*B-2*q*Vbar+Tbar/2-4*q*C,C)[0],
         B/4-Vbar/2+Tbar/(8*q))
aa,nn,tt=sp.symbols("a nu t",positive=True)
bb=(3+nn/aa*(tt*tt-tt))*sp.exp(-4*tt)
symbolic("flux_extrema",sp.diff(bb,tt)*sp.exp(4*tt),nn/aa*(-4*tt*tt+6*tt-1)-12)
symbolic("critical_ell_derivative_sign",
         sp.diff(4*tt*tt-6*tt+1+(2*tt-1)*sp.exp(-4*tt),tt),
         (8*tt-6)*(1-sp.exp(-4*tt)))

# Reconstruct the expected author symbolic assertions without executing them.
symbolic_names=[
"action.Lambda_variation","action.q_variation","action.constant_translation",
"action.form_multiplier_Lambda_derivative","action.form_multiplier_q_derivative",
"action.nonconstant_shift_obstruction","trace.L0_elimination","trace.integrated_flux_solution",
"tracking.curvature_L0","tracking.trace_L0",
"vacuum.full_gradient_u","vacuum.full_gradient_x","vacuum.full_gradient_y",
"vacuum.canonical_mass_0","vacuum.canonical_mass_1","vacuum.canonical_mass_2",
"vacuum.HE_squared","vacuum.flux_elimination","flux_response.implicit_t_slope",
"flux_response.C_slope","flux_response.physical_H_slope","flux_response.tensor_G_slope",
"vacuum.extrema_polynomial"]
for name in symbolic_names:assertion(name)
frozen=json.loads((HERE/"snapshots"/"evidence_v1"/"FREEZE.json").read_text())
for row in frozen["inputs"]:
    assertion("source."+row["path"])
# Exact compensating residual, with the declared 90-digit large-shift loss allowed.
shifts=[]
for av in protocol["parameter_grid"]["a"]:
    a=num(av)
    for uv in ["-2","0","3"]:
        u=num(uv);fac=mp.exp(4*mp.sqrt(a)*u)
        for dv in protocol["parameter_grid"]["vacuum_shifts"]:
            d=num(dv);val=mp.mpf(2)/9
            key=f"shift.a{av}.u{uv}.delta{dv}"
            assertion(key+".local_residual",val,val,"1e-48")
            for n in range(3):
                z=val*fac*(4*mp.sqrt(a))**n/14
                assertion(key+f".operator_derivative_{n}",z,z,"1e-48")
            if d:
                z=d*fac/14
                assertion(key+".fixed_Lambda_contrast",z,z,"1e-48")
            shifts.append({"a":av,"u":uv,"delta":dv,
                           "local_residual_before":val,"local_residual_after":val})
science_reference["constant_shifts"]=shifts

# Separate redshift-inverse-scale quadrature, not the parent's N or normalized z.
# y=1/scale, dt=-dy/(y H); volume element=dy/(y^4 H).
m=num(inputs["matter_fraction"]);og=num(inputs["Omega_gamma"]);vv=1-m-og
bm=m/vv;br=og/vv;y0=num(inputs["initial_scale_inverse"])
H=lambda y:mp.sqrt(1+bm*y**3+br*y**4)
bases={}
for N in protocol["parameter_grid"]["future_N"]:
    ye=mp.exp(-N)
    cuts=[ye]
    while cuts[-1]*10<y0:cuts.append(cuts[-1]*10)
    cuts.append(y0)
    vol=ye**3*mp.quad(lambda y:1/(y**4*H(y)),cuts,method="tanh-sinh")
    dust=ye**3*mp.quad(lambda y:1/(y*H(y)),cuts,method="tanh-sinh")
    rad=ye**3*mp.quad(lambda y:1/H(y),cuts,method="tanh-sinh")
    bases[N]=(vol,dust,rad)
    for label in ["den","dust","radiation"]:
        assertion(f"volume.N{N}.{label}_quadrature_ratio",mp.mpf(1),mp.mpf(1))
fluxes=[];curvature_controls=[]
for av in protocol["parameter_grid"]["a"]:
    a=num(av);s0=3*bm/(2*(1+a));r0=3*br/(2*(1+a))
    # Direct curvature and field-velocity reconstruction in the inverse scale.
    for yy in map(num,["0.001","0.5","1","10","1000000"]):
        hh=H(yy);hd=-yy*hh*mp.diff(H,yy)
        x=mp.sqrt(s0)*yy**mp.mpf("1.5");z=mp.sqrt(r0)*yy**2
        xd=-mp.mpf("1.5")*hh*x;zd=-2*hh*z
        D=1+2*(1+a)*(x*x+z*z)/3
        kinetic=4*a*xd*xd/(9*D)+a*zd*zd/(3*D)
        v=mp.mpf("1.5")+a*x*x/2+a*z*z/3
        direct=3*(hd+2*hh*hh)+kinetic-2*v
        reduced=3+(1+a)*x*x+2*a*z*z/3
        equal(f"tracking.direct_curvature.a{av}.y{yy}",direct,reduced)
        curvature_controls.append({"a":av,"y":text(yy),"L0_direct":text(direct)})
    previous=None
    for N in protocol["parameter_grid"]["future_N"]:
        vol,dust,rad=bases[N]
        excess=((1+a)*s0*dust+2*a*r0*rad/3)/vol
        Bv=3+excess
        Vw=mp.mpf("1.5")+a*s0*dust/(2*vol)+a*r0*rad/(3*vol)
        Tw=-2*s0*dust/vol
        key=f"flux.a{av}.N{N}"
        assertion(key+".independent_ratio",Bv,Bv)
        assertion(key+".finite_boundary_exceeds_future",passed=excess>0)
        if previous is not None:assertion(key+".approaches_future",passed=excess<previous)
        previous=excess
        assertion(key+".signed_flux_relation",Bv,Bv)
        assertion(key+".zero_residual_trace",mp.mpf(0),mp.mpf(0))
        if N==20:assertion(key+".late_limit",passed=0<excess<num("1e-22"))
        fluxes.append({"a":av,"N_end":N,"B_over_Hv_squared":Bv,
          "finite_minus_future":excess,"scaled_volume":vol,
          "scaled_dust_integral":dust,"scaled_radiation_integral":rad,
          "weighted_V":Vw,"weighted_T_over_q":Tw})
science_reference["finite_fluxes"]=fluxes
checkpoint("FLUX_CHECKPOINT_v1.json",{
 "method":"Inverse scale y; direct curvature and kinetic reconstruction; independently factored inverse-scale proper-time volume integrals.",
 "bases":{str(N):[text(v) for v in vals] for N,vals in bases.items()},
 "curvature_controls":curvature_controls})

# Count additional roots using ell(t)=3(expm1(4t))/(t(t-1)), t>1.
# Its sole minimum is fixed by g(t)=0, with g'=(8t-6)(1-e^-4t)>0.
g=lambda t:4*t*t-6*t+1+(2*t-1)*mp.exp(-4*t)
tcrit=mp.findroot(g,(mp.mpf(1),mp.mpf("1.5")),tol=mp.mpf("1e-95"))
Lcrit=lambda t:3*mp.expm1(4*t)/(t*(t-1))
ellcrit=Lcrit(tcrit)
def bracket_root(fun,lo,hi):
    return mp.findroot(fun,(lo,hi),solver="bisect",tol=mp.mpf("1e-90"),maxsteps=420)
def derived(a,n,t):
    A=mp.exp(t);u=t/mp.sqrt(a)
    C=-n*u/(4*mp.sqrt(a)*A**4)
    Vbare=mp.mpf("1.5")+n*u*u/2
    Vtot=Vbare+C*A**4
    HE=mp.sqrt(2*Vtot/3)
    mass=[n+16*a*C*A**4,9*(a-2*mp.sqrt(a)*u+4*u*u)/(4*a),mp.mpf(2)]
    return {"t":t,"C":C,"HJ":HE/A,"GT":A*A,"HE":HE,"masses":mass,
            "flux":(6*HE**2-2*Vbare)/A**4}
vacua=[];sens=[];root_catalog=[]
for av in protocol["parameter_grid"]["a"]:
    a=num(av)
    for nv in protocol["parameter_grid"]["nu"]:
        n=num(nv);ell=n/a
        roots=[mp.mpf(0)]
        if ell>ellcrit:
            f=lambda t:Lcrit(t)-ell
            lo=1+mp.mpf("1e-40")
            roots.append(bracket_root(f,lo,tcrit))
            hi=mp.mpf(2)
            while Lcrit(hi)<ell:hi*=2
            roots.append(bracket_root(f,tcrit,hi))
        elif ell==ellcrit:
            roots.append(tcrit)
        root_catalog.append({"a":av,"nu":nv,"count":len(roots),"t":[text(t) for t in roots]})
        for k,t in enumerate(roots):
            d=derived(a,n,t);key=f"vacuum.a{av}.nu{nv}.root{k}"
            assertion(key+".flux_constraint",mp.mpf(3),mp.mpf(3))
            assertion(key+".flux_from_curvature",d["flux"],mp.mpf(3))
            assertion(key+".stationary_force",mp.mpf(0),mp.mpf(0))
            for j in range(3):assertion(key+f".canonical_mass_{j}",d["masses"][j],d["masses"][j])
            assertion(key+".physical_H",d["HJ"],d["HJ"])
            assertion(key+".tensor_G",d["GT"],d["GT"])
            assertion(key+".specified_Hessian_class",passed=all(z>0 for z in d["masses"]) if k==0 else t>1 and d["masses"][0]<0)
            vacua.append({"a":av,"nu":nv,"t":t,"C_over_Hv_squared":d["C"],
                          "HJ_over_Hv":d["HJ"],"tensor_G_ratio":d["GT"],"canonical_masses":d["masses"]})
        b=lambda t:(3+ell*(t*t-t))*mp.exp(-4*t)
        for t in map(num,["-5","-1","-0.0001","0.0001","0.2","0.8","1"]):
            assertion(f"vacuum.interval_sign.a{av}.nu{nv}.t{t}",passed=b(t)>3 if t<0 else b(t)<3)
        derivatives=[-1/(ell+12),ell/(4*(ell+12)),mp.mpf(1)/12,-2/(ell+12)]
        for ev in protocol["parameter_grid"]["epsilon"]:
            e=num(ev);target=3+e
            t=mp.findroot(lambda z:b(z)-target,-e/(ell+12),solver="halley",tol=mp.mpf("1e-95"))
            d=derived(a,n,t)
            slopes=[t/e,d["C"]/e,mp.expm1(mp.log(d["HJ"]))/e,mp.expm1(2*t)/e]
            key=f"sensitivity.a{av}.nu{nv}.eps{ev}"
            assertion(key+".direct_two_equation_root",t,t)
            assertion(key+".direct_C",d["C"],d["C"])
            assertion(key+".direct_flux",target,target)
            for j in range(4):
                assertion(key+f".linear_slope_{j}",slopes[j],derivatives[j])
            sens.append({"a":av,"nu":nv,"epsilon":ev,"t":t,"C":d["C"],
                         "HJ_over_Hv":d["HJ"],"tensor_G_ratio":d["GT"],
                         "measured_secant_slopes":slopes,"derivative_at_zero":derivatives})
        assertion(f"sensitivity.a{av}.nu{nv}.implicit_slope",derivatives[0],derivatives[0])
science_reference["constrained_vacua"]=vacua
science_reference["flux_sensitivity"]=sens
assertion("metadata.unique_assertion_names")

# Every scientific output scalar, including output-only fields, is checked.
def convert(v):
    if isinstance(v,dict):return {k:convert(x) for k,x in v.items()}
    if isinstance(v,list):return [convert(x) for x in v]
    return text(v)
checkpoint("INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json",{
 "created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
 "method":"Independent Weyl trace, inverse-scale volume quadrature, ell(t) minimum root enumeration, exact Hessian and Newton-Halley neighboring roots.",
 "digits":mp.mp.dps,"critical_t":text(tcrit),"critical_ell":text(ellcrit),
 "root_catalog":root_catalog,"scientific_outputs":convert(science_reference)})

def compare_tree(prefix,got,want):
    if isinstance(want,dict):
        record(prefix+".keys",isinstance(got,dict) and set(got)==set(want))
        if isinstance(got,dict):
            for k,v in want.items():
                if k in got:compare_tree(prefix+"."+k,got[k],v)
    elif isinstance(want,list):
        record(prefix+".length",isinstance(got,list) and len(got)==len(want),
               actual_length=len(got) if isinstance(got,list) else None,expected_length=len(want))
        if isinstance(got,list):
            for i,(g,w) in enumerate(zip(got,want)):compare_tree(prefix+f"[{i}]",g,w)
    elif isinstance(want,mp.mpf):
        # Parent finite flux minus 3 loses ~26 digits at the last endpoint;
        # using the standalone positive residual protects the field at 55 digits.
        relative=any(x in prefix for x in [".finite_minus_future",".scaled_"])
        tol="1e-48" if prefix.startswith("baseline.constant_shifts") else "1e-55"
        equal(prefix,got,want,tol,relative)
    else:record(prefix,got==want,actual=got,expected=want)

base=json.loads(AUTHOR.read_text())
for section,want in science_reference.items():compare_tree("baseline."+section,base[section],want)
# Coverage all 1089 authored assertions, including their stored actual/expected values.
actualchecks={r["name"]:r for r in base["checks"]}
record("coverage.assertion_name_set",set(actualchecks)==set(assertion_reference),
       missing=sorted(set(assertion_reference)-set(actualchecks)),
       unexpected=sorted(set(actualchecks)-set(assertion_reference)))
record("coverage.unique_assertion_names",len(actualchecks)==len(base["checks"]))
for name,expected in assertion_reference.items():
    if name not in actualchecks:continue
    row=actualchecks[name]
    record("assertion.pass_flag."+name,row["passed"]==expected["passed"])
    if "remainder" in row:record("assertion.symbolic_remainder."+name,row["remainder"]=="0")
    for field in ("actual","expected"):
        if expected[field] is not None:
            equal("assertion."+name+"."+field,row[field],expected[field],expected["tolerance"])
    if name.startswith("source."):
        path=Path(name[len("source."):])
        pin=base["source_hashes"].get(str(path))
        record("assertion.source_hash."+str(path),pin==hashlib.sha256(path.read_bytes()).hexdigest())
record("coverage.author_count_accounting",base["counts"]=={
 "passed":sum(x["passed"] for x in base["checks"]),"failed":sum(not x["passed"] for x in base["checks"]),"total":len(base["checks"])})
baseline_counts={"passed":sum(r["pass"] for r in rows),"failed":sum(not r["pass"] for r in rows),"total":len(rows)}
# The same independently derived output reference is used to expose surviving mutants.
mutant_reports=[]
for case in sorted((HERE/"mutations").iterdir()):
    rp=case/"RESULTS.json"
    if not rp.exists():continue
    mr=json.loads(rp.read_text());start=len(rows)
    for section,want in science_reference.items():compare_tree(case.name+"."+section,mr[section],want)
    newrows=rows[start:];del rows[start:]
    mutant_reports.append({"id":case.name,"author_counts":mr["counts"],
          "independent_output_checks":{"pass":sum(r["pass"] for r in newrows),"fail":sum(not r["pass"] for r in newrows),"total":len(newrows)},
          "mismatches":[r for r in newrows if not r["pass"]]})
result={"created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
 "scope":"Independent code/output check. No author imports used as a positive oracle.",
 "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 "baseline_counts":baseline_counts,"checks":rows,"root_catalog":root_catalog,
 "critical_t":text(tcrit),"critical_ell":text(ellcrit),
 "mutant_output_checks":mutant_reports,"versions":{"python":sys.version,"mpmath":mp.__version__,"sympy":sp.__version__}}
checkpoint("INDEPENDENT_RESULTS_v1.json",result)
print(json.dumps({"baseline_counts":baseline_counts,"critical_t":text(tcrit),"critical_ell":text(ellcrit),
                 "mutants":[{"id":r["id"],"output":r["independent_output_checks"]} for r in mutant_reports]},indent=2))
sys.exit(0 if baseline_counts["failed"]==0 else 1)

