#!/usr/local/bin/python3
"""Actual copied-source mutants; no production author files are modified."""
from pathlib import Path
import datetime as dt, hashlib, json, subprocess, time, difflib, os
HERE=Path(__file__).resolve().parent
SNAP=HERE/"snapshots"/"author_inputs"
BASE=SNAP/"direct_auxiliary_vacuum_completion"/"check_auxiliary_vacuum_v1.py"
BASEHASH="bed27c87d143cd4c24cdb7477b2cc3e6abde23b3499e5a226810aa5acfbf163b"
MUTATIONS=[
 ("m1_translation_sign","after=(lam-delta)+(rho+delta)","after=(lam+delta)+(rho+delta)",1,
  "Wrong auxiliary compensation sign, keeping downstream controls intact."),
 ("m2_finite_flux_replaced_by_limit","B=I_L/den","B=mp.mpf(3)",1,
  "Use the regulated infinite-future value for every finite slab."),
 ("m3_drop_nonzero_roots","if ell>mp.mpf(48)/5:","if False and ell>mp.mpf(48)/5:",1,
  "Skip the nonzero-root search while retaining the origin."),
 ("m4_omit_physical_clock","HJ=HE/A,GT=A*A","HJ=HE,GT=A*A",1,
  "Omit conformal conversion in the stationary physical Hubble rate."),
 ("m5_output_C_zero","C_over_Hv_squared=fmt(d['C'])","C_over_Hv_squared=fmt(mp.mpf(0))",1,
  "Serialize zero residual for every reported vacuum without changing internal C."),
 ("m6_output_H_as_Einstein","HJ_over_Hv=fmt(d['HJ'])","HJ_over_Hv=fmt(d['HE'])",2,
  "Serialize the Einstein rate into the Jordan-H output in vacua and sensitivity."),
 ("m7_output_finite_flux_as_limit","B_over_Hv_squared=fmt(B)","B_over_Hv_squared=fmt(mp.mpf(3))",1,
  "Serialize future-limit flux into each finite-slab B output only.")
]
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def digest(data):return hashlib.sha256(data).hexdigest()
def dump(p,obj):
    with p.open("x") as f:json.dump(obj,f,indent=2);f.write("\n")
raw=BASE.read_bytes();assert digest(raw)==BASEHASH
plan={"created_at":now(),"driver_pid":os.getpid(),"base_sha256":BASEHASH,
      "policy":"All nine inputs copied. Each mutant freeze names and hashes the actual copied files including the modified runner. No assertion/tolerance modifications.",
      "mutations":[{"id":n,"old":old,"new":new,"replacement_count":c,"purpose":d}
                   for n,old,new,c,d in MUTATIONS]}
dump(HERE/"MUTATION_PLAN_v1.json",plan)
summaries=[]
for name,old,new,count,desc in MUTATIONS:
    start=now();tick=time.monotonic();case=HERE/"mutations"/name;srcroot=case/"source"
    for src in sorted(SNAP.rglob("*")):
        if src.is_file():
            dst=srcroot/src.relative_to(SNAP);dst.parent.mkdir(parents=True,exist_ok=True)
            with dst.open("xb") as f:f.write(src.read_bytes())
    runner=srcroot/"direct_auxiliary_vacuum_completion"/BASE.name
    text=raw.decode();assert text.count(old)==count,(name,text.count(old))
    mutated=text.replace(old,new)
    runner.write_text(mutated)
    diff="".join(difflib.unified_diff(text.splitlines(True),mutated.splitlines(True),
                                    fromfile="baseline/"+BASE.name,tofile=name+"/"+BASE.name))
    with (case/"MUTATION.diff").open("x") as f:f.write(diff)
    inputs=[]
    for path in sorted(srcroot.rglob("*")):
        if path.is_file():
            inputs.append({"path":str(path),"sha256":digest(path.read_bytes())})
    assert len(inputs)==9
    freeze=case/"FREEZE.json";dump(freeze,{"inputs":inputs,"reviewer_mutation":name})
    cmd=["/usr/local/bin/python3",str(runner),"--freeze",str(freeze),
         "--output-json",str(case/"RESULTS.json")]
    with (case/"stdout.txt").open("xb") as out,(case/"stderr.txt").open("xb") as err:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,cwd=runner.parent)
        dump(case/"LAUNCH.json",{"started_at":start,"pid":proc.pid,"driver_pid":os.getpid(),
                                "command":cmd,"mutated_source_sha256":digest(runner.read_bytes())})
        ret=proc.wait()
    result=json.loads((case/"RESULTS.json").read_text()) if (case/"RESULTS.json").exists() else None
    rec={"id":name,"purpose":desc,"started_at":start,"finished_at":now(),
         "seconds":time.monotonic()-tick,"exit_code":ret,"counts":result["counts"] if result else None,
         "failed_assertions":[x["name"] for x in result["checks"] if not x["passed"]] if result else [],
         "source_checks_all_pass":all(x["passed"] for x in result["checks"] if x["name"].startswith("source.")) if result else False,
         "output_lengths":{k:len(result[k]) for k in ["constant_shifts","finite_fluxes","constrained_vacua","flux_sensitivity"]} if result else {},
         "mutated_source_sha256":digest(runner.read_bytes()),
         "result_sha256":digest((case/"RESULTS.json").read_bytes()) if result else None}
    dump(case/"EXECUTION.json",rec);summaries.append(rec)
    print(json.dumps({"id":name,"exit_code":ret,"counts":rec["counts"],"source_checks_all_pass":rec["source_checks_all_pass"]}),flush=True)
dump(HERE/"MUTATION_RESULTS_v1.json",{"created_at":now(),"mutations":summaries})

