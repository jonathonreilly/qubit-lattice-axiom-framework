# Focused numerical review of direct_epoch_selection

No scientific implementation discrepancy was found in the frozen execution or the independent computations. The independent positive checks pass: 836 row/force/matrix/lineage checks, 109 history checks, and 134 final coverage/identity checks. Four physically meaningful omission mutations are rejected. This conclusion is confined to the supplied candidate equations, frozen fixtures, declared domains and finite sample sites; these are internal controls, not empirical history tests.

The one record-level limitation is that `RESULTS.json` lists seven source hashes while the execution freeze/wrapper bind eight. The omitted entry is the imported analytic `HAND_DERIVATION_v2.md`. Its exact bytes are preserved in the execution snapshots, and both the original and snapshot match the eight-input freeze. This does not cause a missing executable dependency or an ambiguous numerical result. No original source or result was changed for this review.

## Exact source and execution scope

The new implementation subject is `check_epoch_selection_v1.py`, SHA-256 `88bf2fbeae75c60102ac45855e34ae338513aeb8311fa85973581f417c015268`. The corrected note is `HAND_DERIVATION_v2.md`, `504d273484b5596e61b931214c68bb2561ea2117ceac10bcd717efaf25ee7f99`; the fixture is `93f49f9f8c0989761d375383ddbff3355491c3a15d3f3351b1542265c188f549`. The first result is `7c65c23fd2059d6c42a5ee8b3a19a71266e96a430d390d46fb63eb2b5837a864`.

All 18 initial parent paths were snapshotted at 05:30:45Z before the independent numerical work. This includes both note versions, the narrow domain-correction record, code, fixtures, complete first result, freeze, execution, stdout/stderr and all eight parent source snapshots. Four later scope/trace/certificate/parent-review metadata files were separately frozen before final interpretation review. The three actual imported sibling sources are also individually bound in the final disposition map, giving 25 checked source paths. Complete paths, exact hashes and recovery locations are in `SOURCE_DISPOSITIONS_v1.json`.

The parent freeze preceded its first execution. The execution finished at 05:17:37.042314Z with exit 0, 194 passing checks and zero failures, and its wrapper records all eight sources unchanged. The current original and review snapshots still match. Every result class and every original check record was consumed: 51 symbolic records, 98 array-tolerance comparisons, 30 solver-status records and 15 spectral classifications. The displayed symbolic residual records were inspected and their role read in the complete source; independent force differentiation/matrices replace a claim of replaying every author symbolic expression.

The imported analytic runner is exactly `d247f6dc0143d2548a46c59abaec09cb2521c03fe3de73691a5f1f85293c41ef`, its fixture exactly `24ea85efb6725a97b10ac1618b1ebe1a4a02aef50d9799dc91d836877200a1c9`, and its corrected proof exactly `322a932eef3ede5de4d963aae2c623693d12a5942828f971335cc7a6c03ef7d2`. These match the previously completed analytic implementation review, whose receipt is `7a5eeb9ea7359b429098a65fe48eacee69cd3652595012e35146e9105a2a0975`. Reuse is confined to those unchanged identities. The current positive evidence was independently recomputed, not obtained by importing the parent helpers.

The separate handwritten epoch review remains a separate scope. The later parent math receipt and all 23 paths it references were checked for byte identity; this implementation report does not substitute for or broaden that proof review. The supplied status/trace files retain conditional scope and claim no effective retained result; this review applies no audit label or status change.

## Independent numerical construction and coverage

`INDEPENDENT_NUMERICAL_RECIPE.md` gives the derivation. In brief, the full force is reconstructed from canonical energy, independent high-precision potential and metric differentiation, and explicit scalar matter exchange. The reduced systems are derived in scaled canonical momenta. Their Jacobians are differentiated independently at 70 digits. A scaled Taylor matrix exponential supplies the linear histories. The nonlinear and finite-field histories use Radau with exact fluid conservation in different state variables, rather than the parent's DOP853/RK45 velocity/density formulation.

Coverage is exact to the frozen row set:

- All 15 spectra: E0, E1 and radiation for each of the five frozen a values, including a=100. E0 and the radiation radial matrix have negative real parts; E1 has exactly one positive real part.
- All 60 radial force families: five couplings, two nu values, three dust and three radiation states. Every one of their four field scales is independently recomputed: 240 finite-force vectors, not only the last scale used by the author pass assertion.
- All 10 full-equation transverse slope vectors. Both the field and velocity derivative are compared; the dust values are (-5,-4.5), the radiation values (-5.25,-5).
- All six matrix histories, six central variation comparisons, six nonlinear limiting histories, and twelve finite-field histories at all 41 declared N sites. Twelve independent raw plus/minus variation trajectories are additionally preserved.

Maximum absolute differences from recorded values are 2.28e-15 for finite radial forces, 1.78e-15 for transverse slopes and spectra, 3.20e-14 for matrix histories, 7.48e-13 for nonlinear limiting histories, and 6.84e-12 for full finite-field histories. The central differences disagree by at most 1.244e-8, only .001659 of the frozen variation tolerance. The independently integrated full-versus-limit histories differ by at most 5.89e-12. These are comparisons at declared sites, not interval enclosures or uniform analytic bounds.

At a=1/2499 the independent final/initial distances are .00394081667336 for E0, 22.51395040595 for E1 and .01905724371567 for radiation. At a=.01 they are .00408787432287, 21.97959157492 and .01940173702796. The rounded scope-note ratios are correct. The E1 growth is retained, not discarded or retuned. All twelve finite histories remain in the large-field regime; the smallest sampled field is about 112307.67.

The radiation full runs use u=0 and vanishing dust/x. Consequently nu is inactive in that particular invariant subspace; the two nu-labeled radiation runs do not independently test a nonzero conformal restoring force. Dust off-equilibrium forces and the prior unchanged analytic off-trajectory review provide the separate checks of that force. Likewise a single perturbed direction per equilibrium is a finite selected example, even though each selected linear direction has full Krylov rank.

## Actual failure sensitivity and retained failed attempts

The isolated negative controls execute only the original asymptotic assertions on source copies. They do not overwrite the parent's execution or count mutant failure as positive scientific evidence.

| Removed term | Existing assertions that fail | Why the failure matters |
|---|---:|---|
| Two transverse metric connection entries | 10 transverse checks | The 60 radial checks still pass; the transverse controls supply genuinely additional coverage. |
| Scalar matter source in the full equation | 30 dust force checks | Full dust force and limiting response disagree. |
| Reduced u restoring term proportional to 4U | 20 off-equilibrium dust checks | The constructed U=0 equilibrium alone would be blind. |
| Reduced dust exchange term aV | 20 off-equilibrium dust checks | Nonzero conformal velocity is necessary for this sensitivity. |

All 80 numerical failures and exact mutant bytes/diffs remain preserved. No mutation tolerance was changed. This is a targeted sensitivity demonstration, not a proof that every possible implementation defect is detected.

Two actual reviewer-driver failures are retained: the v1 replacement guard found the restoring expression twice; the v2 guard similarly found the exchange expression twice. Both expressions appear in separate numerical and symbolic code. Each driver stopped before its ambiguous replacement, while earlier successful negative runs were preserved. The v3 follow-up restricts the last replacement to the complete numerical function span. A diagnostic-only summary query also encountered a KeyError when its broad prefix included a solver record without an error metric; the subsequently saved collation filters the metric-bearing records. None of these changes altered a science computation or its tolerances. `FAILURE_HISTORY_v1.json` separates these review-tool failures from the four intended falsifiers.

## Domain, calibration and physical limits

The v1 note's transverse-amplitude-only premise was too broad: a vanishing transverse field need not suppress transverse kinetic energy. V2 adds vanishing transverse velocity ratios, positive limiting denominator and compact-domain qualifications before execution. The numerical radial fixtures already use exact invariant zero-transverse-field/velocity/fluid subspaces and therefore satisfy the corrected domain. Their success does not rehabilitate the broader v1 statement or prove a general small-ratio asymptotic theorem.

The radiation controls test the radial u=0 subspace. The limiting neutral u mode is not selected. A transverse dust-field amplitude may decay while increasing relative to the faster-decaying radiation field. The parent scope note states that caveat correctly. Neither positive local sink classifications nor finite perturbed trajectories establish attraction through radiation–matter equality, primordial amplitude selection or a globally selected observational history. The eight-e-fold histories start at a supplied field value 1e12 and remain synthetic large-field comparisons.

The epoch runner imports the analytic module, which loads its frozen fixture, but the called `n_rhs`/`functions` path does not consume the sibling calibration values. The epoch comparisons explicitly supply H_v=1 and the new frozen coupling/state grid. No photon measurement, supernova array, historical fit or observational likelihood is read or refit here. The originating action and expansion benchmark remain constructed/exposed inputs, and unchanged prior calibration assumptions are not promoted to independent empirical tests.

No author-source correction is required by this focused numerical review. The seven-versus-eight hash-map limitation should remain explicit when describing provenance. Complete evidence, snapshots, failed attempts and source dispositions are bound by the final receipt.
