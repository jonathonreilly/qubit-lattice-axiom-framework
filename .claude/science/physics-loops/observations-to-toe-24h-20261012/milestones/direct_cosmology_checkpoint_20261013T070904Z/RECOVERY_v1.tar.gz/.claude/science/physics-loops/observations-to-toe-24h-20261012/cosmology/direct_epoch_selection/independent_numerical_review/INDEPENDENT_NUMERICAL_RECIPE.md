# Independent numerical reconstruction of the epoch controls

This is a focused implementation check of the frozen epoch block. The parent remains the author of the candidate and its physical interpretation. None of the positive numerical evidence below imports or executes an author helper. The original parent code is executed only in isolated, explicitly negative mutation mirrors.

The calculation plan was frozen in `REVIEW_PLAN_v1.json` before these independent runs. `check_epoch_rows_v1.py` uses 70-digit differentiation and canonical energy; `check_epoch_histories_v1.py` uses scaled canonical momenta and Radau. Both executed byte versions, outputs and execution receipts are preserved.

## Full equations from canonical energy

Set the supplied positive scale H_v to one, as in every epoch fixture; equivalently use dimensionless time H_v t. Write q=(u,x,y), p=dq/dN, s=sqrt(a), c=2(1+a)/3, D=1+c(x²+y²),

    K=diag(1,4a/(9D),a/(3D)),
    V=3/2+[2(u-s/4)²+3a/8]x²+a y²/3+nu u²/2.

For a frozen N-state, compute

    H²=2(sigma+r+V)/(3-p.K.p),
    v=H p, pi=K v,
    E(q,pi)=1/2 sum_i(pi_i²/K_i(q))+V(q)+sigma+r.

Take the derivative of E at fixed pi and fixed instantaneous sigma,r. Matter exchange is then inserted explicitly:

    pi_dot_i=-3H pi_i-partial_i E-s sigma delta_i,u,
    v_dot_i=[pi_dot_i-v_i sum_j(partial_j K_i)v_j]/K_i,
    h=H_N/H=-(sigma+4r/3)/H²-p.K.p,
    p_N=v_dot/H²-h p,
    sigma_N=(-3+s p_u)sigma, r_N=-4r.

The scalar matter term is exactly `-sqrt(a)*sigma` in pi_dot_u. The potential and metric derivatives in the executable are independently differentiated with mpmath; no author Christoffel array or force routine is used. This produces all 240 full radial force vectors and the 10 transverse derivative vectors, including off-equilibrium states.

The scalar kinetic term, source exchange and the derivative of K all enter. In particular, differentiating energy at fixed pi includes the inverse-metric force, while converting pi_dot to v_dot supplies the remaining metric terms. This reproduces the full covariant equations without transcribing the author's connection implementation.

## Limiting dust canonical variables

On y=y_N=r=0 define U=u/s, ell=ln x, V=U_N, P=ell_N, W=sigma/x². Use independent canonical coordinates

    I=pi_u/(s x), J=pi_x, beta=2a/[3(1+a)],
    f0(U)=1/2-U+2U²,
    F=[a I²+J²/beta+2(W+a f0)]/3,
    V=I/sqrt(F), P=J/[beta sqrt(F)].

The limiting flow follows directly from pi_dot and the dust conservation law:

    U_N=V,
    I_N=-(3+P)I-[-1+4U+W]/sqrt(F),
    J_N=-3J-[J²/beta+2a f0]/sqrt(F),
    W_N=W[-3+aV-2P].

Differentiating V and P through F gives the four-component reduced flow. Numerical differentiation of this independently reconstructed flow yields both dust Jacobians for every frozen a. Eigenvalues were recomputed at 70 digits and matched as unordered sets. Matrix evolution was evaluated by an explicit scaled Taylor series with 99 nonconstant terms and repeated squaring, not scipy.linalg.expm. The six frozen directions have nonzero Krylov determinants; they excite the full corresponding linear spaces, though they are still only six finite selected examples.

## Limiting radiation canonical variables

On x=x_N=sigma=u=u_N=0, let ell=ln y, W=r/y², beta=a/[2(1+a)], J=pi_y. Then

    F=[J²/beta+2(W+a/3)]/3,
    P=J/[beta sqrt(F)],
    J_N=-3J-[J²/beta+2a/3]/sqrt(F),
    W_N=W[-4-2P].

Differentiating P through F gives the two-component radial flow and its independently differentiated Jacobian. The numerical full-field comparisons use u=0, a subset of the fixed-finite-u radiation limiting discussion. They do not test selection of the neutral conformal-field amplitude.

## Finite-field histories without fluid integration

For the full dust history let epsilon=exp(-2ell), A_x=4a/9. Eliminate the density by its exact conservation law:

    W=W0 exp[-3N+a(U-U0)+2(ell0-ell)],
    F=[aI²+(c+epsilon)J²/A_x
       +2{W+a f0+(3/2+nu aU²/2)epsilon}]/3,
    V=I/sqrt(F), P=(c+epsilon)J/[A_x sqrt(F)],
    U_N=V,
    I_N=-(3+P)I-[-1+4U+W+nu U epsilon]/sqrt(F),
    J_N=-3J-[cJ²/A_x+2a f0]/sqrt(F),
    ell_N=P.

For radiation A_y=a/3 and

    W=W0 exp[-4N+2(ell0-ell)],
    F=[(c+epsilon)J²/A_y+2(W+a/3+(3/2)epsilon)]/3,
    J_N=-3J-[cJ²/A_y+2a/3]/sqrt(F),
    ell_N=(c+epsilon)J/[A_y sqrt(F)].

These four- and two-state systems differ from the parent's five- and three-state N-velocity/density systems. They avoid directly integrating the exchange density and avoid subtracting a large radial acceleration from P². Initial canonical momenta are obtained from the finite-field Friedmann constraint, not the limiting one.

All histories use Radau, rtol=1e-12, atol=1e-14 and maximum N step .025, fixed before execution. The author uses DOP853 for the limiting histories and RK45 for the full histories. We independently integrate both signs of each epsilon=1e-6 variation, all six .01 nonlinear displacements, and all twelve finite-field histories. All 41 declared sites from N=0 to N=8 are compared. The raw independent plus/minus histories are retained as well as their central differences. The author record retains the central differences rather than the raw pairs.

## Negative controls and interpretation

The four immutable negative mirrors remove: (1) the transverse connection entries, (2) the scalar matter force, (3) the reduced u restoring force proportional to 4U, and (4) the reduced dust exchange term aV. Only the existing author asymptotic controls are executed, with their original tolerances. All four are rejected numerically. Their source bytes, diffs, fixtures, results, stderr/stdout and execution identities remain intact.

The two mutation-driver targeting errors are separate failed review attempts: expressions occurred both in numerical and symbolic source. They stopped before applying the affected replacement. Subsequent drivers restrict the replacement to the numerical return/function span; neither original attempt was rewritten. `FAILURE_HISTORY_v1.json` records these and a later diagnostic-only metric-inspection error.

The finite controls sample corrected positive-denominator domains and exact invariant subspaces. They provide neither uniform error bounds through equality nor observed-history likelihoods. No photon calibration value or new observation enters these numerical equations. The prior action and fixed couplings remain supplied assumptions.
