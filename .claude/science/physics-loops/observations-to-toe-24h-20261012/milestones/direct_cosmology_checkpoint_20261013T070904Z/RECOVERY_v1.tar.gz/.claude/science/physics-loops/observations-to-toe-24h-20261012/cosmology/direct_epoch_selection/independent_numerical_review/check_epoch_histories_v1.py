#!/usr/bin/env python3
"""Independent reduced/full epoch histories in scaled canonical momenta.

No parent helper imports. Finite-field density is eliminated by its exact
conservation law. Radau is used instead of the parent's DOP853/RK45 methods.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import numpy as np
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parent
FIX=json.loads((ROOT/'source_snapshot/NUMERICAL_FIXTURES_v1.json').read_text())
AUTHOR=json.loads((ROOT/'source_snapshot/evidence_v1/RESULTS.json').read_text())
STATIC=json.loads((ROOT/'ROW_CHECKS_v1.json').read_text())
CHECKS=[]


def check(name,passed,**evidence):CHECKS.append({'name':name,'passed':bool(passed),**evidence})


def close(name,x,y,atol,rtol):
    x,y=np.asarray(x,float),np.asarray(y,float)
    ratios=np.abs(x-y)/(atol+rtol*np.maximum(abs(x),abs(y)))
    check(name,x.shape==y.shape and np.all(np.isfinite(ratios)) and np.max(ratios)<=1,
          max_tolerance_units=float(np.max(ratios)),max_absolute_error=float(np.max(abs(x-y))))


def limit_initial(kind,z,a):
    if kind=='radiation':
        P,W=z;beta=a/(2*(1+a));F=2*(W+a/3)/(3-beta*P*P)
        return np.array([beta*math.sqrt(F)*P,W])
    U,V,P,W=z;beta=2*a/(3*(1+a));f=.5-U+2*U*U
    F=2*(W+a*f)/(3-a*V*V-beta*P*P)
    return np.array([U,math.sqrt(F)*V,beta*math.sqrt(F)*P,W])


def limit_rhs_readout(z,a,kind):
    if kind=='radiation':
        J,W=z;beta=a/(2*(1+a));F=(J*J/beta+2*(W+a/3))/3;root=math.sqrt(F)
        P=J/(beta*root)
        return np.array([-3*J-(J*J/beta+2*a/3)/root,W*(-4-2*P)]),np.array([P,W])
    U,I,J,W=z;beta=2*a/(3*(1+a));f=.5-U+2*U*U
    F=(a*I*I+J*J/beta+2*(W+a*f))/3;root=math.sqrt(F)
    V=I/root;P=J/(beta*root)
    rhs=np.array([V,-(3+P)*I-(-1+4*U+W)/root,-3*J-(J*J/beta+2*a*f)/root,W*(-3+a*V-2*P)])
    return rhs,np.array([U,V,P,W])


def full_initial(kind,z,a,nu,ell):
    eps=math.exp(-2*ell);c=2*(1+a)/3
    if kind=='radiation':
        P,W=z;beta=(a/3)/(c+eps);F=2*(W+a/3+1.5*eps)/(3-beta*P*P)
        return np.array([beta*math.sqrt(F)*P,ell])
    U,V,P,W=z;beta=(4*a/9)/(c+eps);f=.5-U+2*U*U
    F=2*(W+a*f+(1.5+nu*a*U*U/2)*eps)/(3-a*V*V-beta*P*P)
    return np.array([U,math.sqrt(F)*V,beta*math.sqrt(F)*P,ell])


def full_rhs_readout(n,z,a,nu,kind,initial,ell0):
    c=2*(1+a)/3
    if kind=='radiation':
        J,ell=z;eps=math.exp(-2*ell);W=initial[1]*math.exp(-4*n+2*(ell0-ell));Ay=a/3
        F=((c+eps)*J*J/Ay+2*(W+a/3+1.5*eps))/3;root=math.sqrt(F)
        P=(c+eps)*J/(Ay*root)
        rhs=np.array([-3*J-(c*J*J/Ay+2*a/3)/root,P])
        return rhs,np.array([P,W,ell])
    U,I,J,ell=z;eps=math.exp(-2*ell);Ax=4*a/9
    W=initial[3]*math.exp(-3*n+a*(U-initial[0])+2*(ell0-ell));f=.5-U+2*U*U
    F=(a*I*I+(c+eps)*J*J/Ax+2*(W+a*f+(1.5+nu*a*U*U/2)*eps))/3;root=math.sqrt(F)
    V=I/root;P=(c+eps)*J/(Ax*root)
    rhs=np.array([V,-(3+P)*I-(-1+4*U+W+nu*U*eps)/root,-3*J-(c*J*J/Ax+2*a*f)/root,P])
    return rhs,np.array([U,V,P,W,ell])


def main():
    cfg=FIX['integration'];sites=np.linspace(0,cfg['N_end'],cfg['sites']);rows=[]
    expected={(a,kind)for a in cfg['a']for kind in ['dust_E0','dust_E1','radiation']}
    index={(r['a'],r['kind']):r for r in AUTHOR['histories']}
    linearindex={(r['a'],r['kind']):r for r in STATIC['linear_histories']}
    check('six complete history fixtures',len(index)==6 and set(index)==expected)
    for a,kind in sorted(expected):
        source=index[a,kind]
        eq=np.array([-2.,1.])if kind=='radiation'else np.array([0.,0.,-1.5,1.])if kind=='dust_E0'else np.array([-.5,0.,-1.5,3.])
        direction=np.array([.7,-.4])if kind=='radiation'else np.array([.3,-.2,.4,-.5])
        close('fixture equilibrium '+str((a,kind)),eq,source['equilibrium'],1e-14,1e-14)
        close('fixture direction '+str((a,kind)),direction,source['direction'],1e-14,1e-14)
        close('fixture sites '+str((a,kind)),sites,source['N'],1e-14,1e-14)
        pairs=[];evaluations=[]
        for sign in [-1,1]:
            initial=limit_initial(kind,eq+sign*cfg['variation_epsilon']*direction,a)
            solution=solve_ivp(lambda n,z:limit_rhs_readout(z,a,kind)[0],(0,cfg['N_end']),initial,
                               method='Radau',rtol=1e-12,atol=1e-14,max_step=.025,dense_output=True)
            check('independent limiting variation solver '+str((a,kind,sign)),solution.success,message=solution.message)
            values=np.array([limit_rhs_readout(z,a,kind)[1]for z in solution.sol(sites).T]);pairs.append(values);evaluations.append(solution.nfev)
        derivative=(pairs[1]-pairs[0])/(2*cfg['variation_epsilon'])
        close('independent central versus matrix '+str((a,kind)),derivative,linearindex[a,kind]['independent_linear'],cfg['variation_atol'],cfg['variation_rtol'])
        close('independent central versus author '+str((a,kind)),derivative,source['central_variation'],cfg['variation_atol'],cfg['variation_rtol'])
        initialphysical=eq+cfg['nonlinear_displacement']*direction
        sol=solve_ivp(lambda n,z:limit_rhs_readout(z,a,kind)[0],(0,cfg['N_end']),limit_initial(kind,initialphysical,a),
                       method='Radau',rtol=1e-12,atol=1e-14,max_step=.025,dense_output=True)
        check('independent limiting nonlinear solver '+str((a,kind)),sol.success,message=sol.message)
        limiting=np.array([limit_rhs_readout(z,a,kind)[1]for z in sol.sol(sites).T])
        close('independent limiting nonlinear '+str((a,kind)),limiting,source['limiting_nonlinear'],cfg['history_atol'],cfg['history_rtol'])
        ell0=math.log(cfg['initial_large_field']);fulls=[]
        check('both nu full histories '+str((a,kind)),[z['nu']for z in source['full_runs']]==FIX['nu'])
        for nu in FIX['nu']:
            initial=full_initial(kind,initialphysical,a,nu,ell0)
            fs=solve_ivp(lambda n,z:full_rhs_readout(n,z,a,nu,kind,initialphysical,ell0)[0],(0,cfg['N_end']),initial,
                          method='Radau',rtol=1e-12,atol=1e-14,max_step=.025,dense_output=True)
            check('independent full solver '+str((a,kind,nu)),fs.success,message=fs.message)
            values=np.array([full_rhs_readout(n,z,a,nu,kind,initialphysical,ell0)[1]for n,z in zip(sites,fs.sol(sites).T)])
            parent=[z for z in source['full_runs']if z['nu']==nu][0]
            close('independent full versus parent '+str((a,kind,nu)),values,parent['states'],cfg['history_atol'],cfg['history_rtol'])
            close('independent full versus limit '+str((a,kind,nu)),values[:,:-1],limiting,cfg['history_atol'],cfg['history_rtol'])
            check('finite fields remain large '+str((a,kind,nu)),min(values[:,-1])>0,minimum_field=float(math.exp(min(values[:,-1]))))
            fulls.append({'nu':nu,'states':values.tolist(),'canonical_states':fs.sol(sites).T.tolist(),'evaluations':fs.nfev})
        rows.append({'a':a,'kind':kind,'N':sites.tolist(),'minus_history':pairs[0].tolist(),'plus_history':pairs[1].tolist(),
                     'variation_evaluations':evaluations,'central_variation':derivative.tolist(),'limiting_nonlinear':limiting.tolist(),
                     'distance_initial':float(np.linalg.norm(limiting[0]-eq)),'distance_final':float(np.linalg.norm(limiting[-1]-eq)),'full_runs':fulls})
        print(json.dumps({'completed':kind,'a':a,'distance_final':rows[-1]['distance_final']}),flush=True)
    out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'formulation':'Scaled canonical momenta; exact finite-field dust/radiation conservation; independent Radau integration, no parent imports.',
         'histories':rows,'checks':CHECKS,'summary':{'total':len(CHECKS),'passed':sum(c['passed']for c in CHECKS),'failed':sum(not c['passed']for c in CHECKS)}}
    (ROOT/'HISTORY_CHECKS_v1.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps(out['summary'],sort_keys=True))
    for c in CHECKS:
        if not c['passed']:print(json.dumps(c,sort_keys=True))
    return int(out['summary']['failed']>0)


if __name__=='__main__':raise SystemExit(main())
