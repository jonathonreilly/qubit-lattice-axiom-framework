#!/usr/bin/env python3
"""Independent canonical-energy force, limiting matrix and complete row checks."""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import math
import mpmath as mp
import numpy as np

ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'source_snapshot'
FIX=json.loads((SNAP/'NUMERICAL_FIXTURES_v1.json').read_text())
AUTHOR=json.loads((SNAP/'evidence_v1/RESULTS.json').read_text())
mp.mp.dps=70
CHECKS=[]


def check(name,passed,**evidence):
    CHECKS.append({'name':name,'passed':bool(passed),**evidence})


def close(name,x,y,atol=2e-10,rtol=2e-10):
    x,y=np.asarray(x,float),np.asarray(y,float)
    units=np.abs(x-y)/(atol+rtol*np.maximum(abs(x),abs(y)))
    check(name,x.shape==y.shape and np.all(np.isfinite(units)) and np.max(units)<=1,
          max_units=float(np.max(units)),max_absolute_error=float(np.max(abs(x-y))))


def dust_canonical_flow(U,I,J,W,a):
    beta=2*a/(3*(1+a));ff=mp.mpf('0.5')-U+2*U*U
    F=(a*I*I+J*J/beta+2*(a*ff+W))/3
    root=mp.sqrt(F);V=I/root;P=J/(beta*root)
    dU=V;dI=-(3+P)*I-(-1+4*U+W)/root
    dJ=-3*J-(J*J/beta+2*a*ff)/root
    dW=W*(-3+a*V-2*P)
    dF=(2*a*(-1+4*U)*dU+2*a*I*dI+2*J*dJ/beta+2*dW)/3
    return [dU,dI,dJ,dW],F,dF


def dust_limit(z,a):
    U,V,P,W=map(mp.mpf,z);a=mp.mpf(a)
    beta=2*a/(3*(1+a));ff=mp.mpf('0.5')-U+2*U*U
    F=2*(W+a*ff)/(3-a*V*V-beta*P*P);root=mp.sqrt(F)
    I=V*root;J=beta*P*root
    flow,Fc,dF=dust_canonical_flow(U,I,J,W,a)
    return mp.matrix([flow[0],flow[1]/root-V*dF/(2*Fc),flow[2]/(beta*root)-P*dF/(2*Fc),flow[3]])


def radiation_limit(z,a):
    P,W=map(mp.mpf,z);a=mp.mpf(a);beta=a/(2*(1+a))
    F=2*(W+a/3)/(3-beta*P*P);root=mp.sqrt(F);J=beta*P*root
    dJ=-3*J-(J*J/beta+2*a/3)/root;dW=W*(-4-2*P)
    dF=(2*J*dJ/beta+2*dW)/3
    return mp.matrix([dJ/(beta*root)-P*dF/(2*F),dW])


def independent_matrix(kind,a):
    point=[0,0,mp.mpf('-1.5'),1] if kind=='dust_E0' else [mp.mpf('-.5'),0,mp.mpf('-1.5'),3] if kind=='dust_E1' else [-2,1]
    func=dust_limit if kind.startswith('dust') else radiation_limit
    return mp.matrix([[mp.diff(lambda z,j=j,i=i:func([z if k==j else point[k] for k in range(len(point))],a)[i],point[j]) for j in range(len(point))]for i in range(len(point))])


def taylor_matrix_action(matrix,t,direction):
    B=matrix*mp.mpf(t);norm=max(sum(abs(B[i,j])for j in range(B.cols))for i in range(B.rows))
    scale=max(0,int(mp.ceil(mp.log(norm,2)))) if norm else 0
    B=B/(2**scale);total=mp.eye(B.rows);term=mp.eye(B.rows)
    for n in range(1,100):
        term=term*B/n;total+=term
    for _ in range(scale):total=total*total
    return list(total*mp.matrix(direction))


def full_action_rhs(state,a,nu):
    q=list(map(mp.mpf,state[:3]));p=list(map(mp.mpf,state[3:6]));sm,sr=map(mp.mpf,state[6:8]);a,nu=mp.mpf(a),mp.mpf(nu)
    s=mp.sqrt(a)
    def metric(q):
        d=1+mp.mpf(2)/3*(1+a)*(q[1]**2+q[2]**2)
        return [mp.mpf(1),4*a/(9*d),a/(3*d)]
    def potential(q):
        u,x,y=q
        return mp.mpf('1.5')+(2*(u-s/4)**2+3*a/8)*x*x+a*y*y/3+nu*u*u/2
    k=metric(q);norm=sum(k[i]*p[i]**2 for i in range(3));h2=2*(sm+sr+potential(q))/(3-norm);H=mp.sqrt(h2)
    vel=[H*v for v in p];pi=[k[i]*vel[i]for i in range(3)]
    def energy(q):
        kk=metric(q)
        return sum(pi[i]**2/(2*kk[i])for i in range(3))+potential(q)+sm+sr
    def diff(fun,j):
        return mp.diff(lambda z:fun([z if l==j else q[l]for l in range(3)]),q[j])
    grad=[diff(energy,j)for j in range(3)]
    dk=[[diff(lambda z,i=i:metric(z)[i],j)for j in range(3)]for i in range(3)]
    pidot=[-3*H*pi[i]-grad[i]-(s*sm if i==0 else 0)for i in range(3)]
    acceleration=[(pidot[i]-vel[i]*sum(dk[i][j]*vel[j]for j in range(3)))/k[i]for i in range(3)]
    hlog=-(sm+4*sr/3)/h2-norm
    pp=[acceleration[i]/h2-p[i]*hlog for i in range(3)]
    return mp.matrix(p+pp+[(-3+s*p[0])*sm,-4*sr])


def force_reduced(kind,state,size,a,nu):
    size,a=mp.mpf(size),mp.mpf(a)
    if kind=='dust':
        U,V,P,W=map(mp.mpf,state)
        full=[mp.sqrt(a)*U,size,0,mp.sqrt(a)*V,size*P,0,size*size*W,0]
        d=full_action_rhs(full,a,nu)
        return [d[0]/mp.sqrt(a),d[3]/mp.sqrt(a),d[4]/size-P*P,d[6]/(size*size)-2*P*W]
    P,W=map(mp.mpf,state)
    d=full_action_rhs([0,0,size,0,0,size*P,0,size*size*W],a,nu)
    return [d[5]/size-P*P,d[7]/(size*size)-2*P*W]


def main():
    freeze=json.loads((SNAP/'evidence_v1/FREEZE.json').read_text());execution=json.loads((SNAP/'evidence_v1/EXECUTION.json').read_text())
    source_rows=[]
    for absolute,expected in freeze['source_sha256'].items():
        source=Path(absolute);snapshot=SNAP/'evidence_v1/source_snapshot'/source.parent.name/source.name
        current=hashlib.sha256(source.read_bytes()).hexdigest();preserved=hashlib.sha256(snapshot.read_bytes()).hexdigest()
        listed=AUTHOR['source_sha256'].get(absolute)
        check('source lineage '+source.parent.name+'/'+source.name,current==preserved==expected and execution['source_unchanged'][absolute] and (listed is None or listed==expected))
        source_rows.append({'source':absolute,'snapshot':str(snapshot),'sha256':current,'listed_in_result_hash_map':listed is not None})
    check('freeze/execution order',freeze['created_at']<execution['started_at']<=AUTHOR['started_at']<=AUTHOR['ended_at']<=execution['ended_at'])
    check('all original checks recorded',len(AUTHOR['checks'])==194 and AUTHOR['passed']==194 and AUTHOR['failed']==0 and all(c['passed']for c in AUTHOR['checks']))
    for i,c in enumerate(AUTHOR['checks']):
        if 'max_tolerance_units' in c:
            name=c['name'];atol=rtol=2e-10
            if name.startswith('numeric dust'):rtol=0
            elif name.startswith('full transverse'):atol=rtol=2e-9
            elif name.startswith('limiting central'):atol,rtol=FIX['integration']['variation_atol'],FIX['integration']['variation_rtol']
            elif name.startswith('full versus'):atol,rtol=FIX['integration']['history_atol'],FIX['integration']['history_rtol']
            x,y=np.array(c['actual']),np.array(c['expected']);units=float(np.max(abs(x-y)/(atol+rtol*np.maximum(abs(x),abs(y)))))
            check('original tolerance arithmetic '+str(i),math.isfinite(units) and units<=1 and abs(units-c['max_tolerance_units'])<2e-14)
        elif 'residual' in c:check('symbolic record '+str(i),c['residual']=='0')
        else:check('recorded solver/spectral status '+str(i),c['passed']is True)

    matrices=[]
    for row in AUTHOR['eigenvalues']:
        kind=('dust_E'+str(row['point'])) if 'point'in row else 'radiation'
        M=independent_matrix(kind,row['a']);values=mp.eig(M,left=False,right=False)
        val=np.array([[float(mp.re(x)),float(mp.im(x))]for x in values])
        recorded=np.array(row.get('eigenvalues',row.get('radiation_eigenvalues')))
        best=min(itertools.permutations(range(len(val))),key=lambda perm:np.max(abs(val[list(perm)]-recorded)))
        close('independent spectrum '+str((row['a'],kind)),val[list(best)],recorded)
        signs=[float(mp.re(x))for x in values]
        check('independent classification '+str((row['a'],kind)),sum(x>0 for x in signs)==(1 if kind=='dust_E1'else 0) and all(x!=0 for x in signs))
        matrices.append({'a':row['a'],'kind':kind,'matrix':[[float(M[i,j])for j in range(M.cols)]for i in range(M.rows)],'eigenvalues':val.tolist()})

    asymptotic=[]
    for i,row in enumerate(AUTHOR['asymptotic']):
        kind,a=row['kind'],row['a']
        if kind in ['dust','radiation']:
            limiting=list((dust_limit if kind=='dust'else radiation_limit)(row['state'],a))
            close('independent limiting force '+str(i),list(map(float,limiting)),row['limiting'])
            series=[]
            for j,z in enumerate(row['series']):
                got=force_reduced(kind,row['state'],z['size'],a,row['nu'])
                close('independent full field force '+str((i,j)),list(map(float,got)),z['full'])
                stored_error=max(abs(x-y)for x,y in zip(z['full'],row['limiting']))
                close('recorded asymptotic error '+str((i,j)),stored_error,z['maximum_error'],atol=1e-25,rtol=1e-12)
                series.append({'size':z['size'],'independent_full':list(map(float,got)),'independent_asymptotic_error':float(max(abs(x-y)for x,y in zip(got,limiting)))})
            asymptotic.append({'original_index':i,'kind':kind,'a':a,'nu':row['nu'],'limiting':list(map(float,limiting)),'series':series})
        else:
            size=mp.mpf(FIX['field_scales'][-1]);step=mp.mpf('1e-4')
            if kind=='transverse_dust':base=[0,size,0,0,-mp.mpf('1.5')*size,0,size*size,0];idx=2;target=[-5,-4.5]
            else:base=[0,0,size,0,0,-2*size,0,size*size];idx=1;target=[-5.25,-5]
            slopes=[]
            for coordinate in [idx,idx+3]:
                plus=list(base);minus=list(base);plus[coordinate]+=step;minus[coordinate]-=step
                slopes.append((full_action_rhs(plus,a,1)[idx+3]-full_action_rhs(minus,a,1)[idx+3])/(2*step))
            close('independent full transverse '+str(i),list(map(float,slopes)),row['actual_slope'],2e-9,2e-9)
            close('independent limiting transverse '+str(i),list(map(float,slopes)),target,2e-9,2e-9)
            asymptotic.append({'original_index':i,'kind':kind,'a':a,'independent_slopes':list(map(float,slopes))})

    linear=[];cfg=FIX['integration']
    for row in AUTHOR['histories']:
        M=independent_matrix(row['kind'],row['a'])
        values=[list(map(float,taylor_matrix_action(M,n,row['direction'])))for n in row['N']]
        close('independent matrix history '+str((row['a'],row['kind'])),values,row['linear'],atol=2e-11,rtol=2e-11)
        close('recorded central variation '+str((row['a'],row['kind'])),row['central_variation'],values,cfg['variation_atol'],cfg['variation_rtol'])
        initial=float(np.linalg.norm(np.array(row['limiting_nonlinear'][0])-row['equilibrium']));final=float(np.linalg.norm(np.array(row['limiting_nonlinear'][-1])-row['equilibrium']))
        close('history initial distance '+str((row['a'],row['kind'])),initial,row['distance_initial'],atol=1e-15,rtol=1e-13)
        close('history final distance '+str((row['a'],row['kind'])),final,row['distance_final'],atol=1e-15,rtol=1e-13)
        for run in row['full_runs']:
            close('recorded full limiting agreement '+str((row['a'],row['kind'],run['nu'])),np.array(run['states'])[:,:-1],row['limiting_nonlinear'],cfg['history_atol'],cfg['history_rtol'])
        krylov=mp.matrix(M.rows,M.cols)
        v=mp.matrix(row['direction'])
        for j in range(M.cols):
            for i in range(M.rows):krylov[i,j]=v[i]
            v=M*v
        check('linear direction spans Krylov space '+str((row['a'],row['kind'])),mp.det(krylov)!=0)
        linear.append({'a':row['a'],'kind':row['kind'],'N':row['N'],'independent_linear':values,'Krylov_determinant':mp.nstr(mp.det(krylov),30)})

    out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_identities':source_rows,
         'source_map_note':'Execution freeze/end wrapper bind eight inputs. RESULTS source map lists seven, omitting the imported analytic proof note; that note remains exactly preserved and wrapper-bound.',
         'matrices':matrices,'asymptotic':asymptotic,'linear_histories':linear,'checks':CHECKS,
         'summary':{'total':len(CHECKS),'passed':sum(c['passed']for c in CHECKS),'failed':sum(not c['passed']for c in CHECKS)}}
    (ROOT/'ROW_CHECKS_v1.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps(out['summary'],sort_keys=True))
    for c in CHECKS:
        if not c['passed']:print(json.dumps(c,sort_keys=True))
    return int(out['summary']['failed']>0)


if __name__=='__main__':raise SystemExit(main())
