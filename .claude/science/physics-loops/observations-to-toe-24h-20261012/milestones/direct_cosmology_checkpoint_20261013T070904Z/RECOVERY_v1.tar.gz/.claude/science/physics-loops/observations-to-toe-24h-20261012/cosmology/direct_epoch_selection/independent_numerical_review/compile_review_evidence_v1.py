#!/usr/bin/env python3
"""Read-only coverage/identity/metric collation; no author imports or solves."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import math
import numpy as np
P=Path(__file__).resolve().parent

def read(name):return json.loads((P/name).read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def check(name,condition,**data):checks.append(dict(name=name,passed=bool(condition),**data))
A=read('source_snapshot/evidence_v1/RESULTS.json');R=read('ROW_CHECKS_v1.json');H=read('HISTORY_CHECKS_v1.json');F=read('source_snapshot/NUMERICAL_FIXTURES_v1.json')
expected_spectra={(a,k)for a in F['eigenvalue_a']for k in ['dust_E0','dust_E1','radiation']}
actual_spectra=[(r['a'],'dust_E'+str(r['point'])if'point'in r else'radiation')for r in A['eigenvalues']]
check('all fifteen unique spectra',len(actual_spectra)==len(set(actual_spectra))==15 and set(actual_spectra)==expected_spectra)
expected_forces={(k,a,nu,tuple(state))for a in F['eigenvalue_a']for nu in F['nu']for k in ['dust','radiation']for state in F[k+'_force_states']}
actual_forces=[(r['kind'],r['a'],r['nu'],tuple(r['state']))for r in A['asymptotic']if r['kind']in['dust','radiation']]
check('all sixty unique radial force fixtures',len(actual_forces)==len(set(actual_forces))==60 and set(actual_forces)==expected_forces)
for i,r in enumerate(A['asymptotic']):
 if 'series'in r:check('all four ordered field scales '+str(i),[z['size']for z in r['series']]==F['field_scales'])
trans=[(r['a'],r['kind'])for r in A['asymptotic']if r['kind'].startswith('transverse')]
check('all ten unique transverse fixtures',len(trans)==len(set(trans))==10 and set(trans)=={(a,k)for a in F['eigenvalue_a']for k in ['transverse_dust','transverse_radiation']})
expected_histories={(a,k)for a in F['integration']['a']for k in ['dust_E0','dust_E1','radiation']}
actual_histories=[(r['a'],r['kind'])for r in A['histories']]
check('all six unique history fixtures',len(actual_histories)==len(set(actual_histories))==6 and set(actual_histories)==expected_histories)
for r in A['histories']:
 dim=2 if r['kind']=='radiation' else 4
 check('all sample arrays '+str((r['a'],r['kind'])),len(r['N'])==41 and all(np.shape(r[k])==(41,dim)for k in ['central_variation','linear','limiting_nonlinear'])and len(r['full_runs'])==2 and all(np.shape(z['states'])==(41,dim+1)for z in r['full_runs']))
identities=[]
for manifest in ['INPUT_FREEZE_v1.json','SUPPLEMENTAL_INPUT_FREEZE_v1.json']:
 for r in read(manifest)['inputs']:
  current=digest(Path(r['source']));snapshot=digest(Path(r['snapshot']))
  check('unchanged original and snapshot '+r['relative_path'],current==snapshot==r['sha256'])
  identities.append(dict(r,current_sha256=current,snapshot_sha256=snapshot))
execution=read('source_snapshot/evidence_v1/FREEZE.json')
for absolute,sha in execution['source_sha256'].items():
 check('eight executed sources remain unchanged '+absolute,digest(Path(absolute))==sha)
metadata=read('supplemental_source_snapshot/PARENT_MATH_REVIEW_RECEIPT_v1.json')
check('parent math receipt has twenty-three unique identities',len(metadata['identities'])==len(set(r['path']for r in metadata['identities']))==23)
for row in metadata['identities']:check('math metadata byte pointer '+row['path'],digest(Path(row['path']))==row['sha256'])
check('math metadata receipt byte pointer',digest(Path(metadata['receipt_path']))==metadata['receipt_sha256'])
# Existing analytic implementation review is reused only by exact identity.
prior=P.parent.parent/'direct_analytic_fluid_completion/independent_numerical_review/FINAL_RECEIPT_v1.json'
if not prior.exists():
 options=list(prior.parent.glob('*RECEIPT*.json'))
 prior=next(z for z in options if digest(z)=='7a5eeb9ea7359b429098a65fe48eacee69cd3652595012e35146e9105a2a0975')
check('prior analytic numerical receipt unchanged',digest(prior)=='7a5eeb9ea7359b429098a65fe48eacee69cd3652595012e35146e9105a2a0975')
metric_prefixes=['independent limiting force','independent full field force','independent full transverse','independent spectrum','independent matrix history','independent full versus parent','independent full versus limit','independent limiting nonlinear','independent central versus author','independent central versus matrix']
metrics={}
for prefix in metric_prefixes:
 selected=[c for c in R['checks']+H['checks']if c['name'].startswith(prefix)and'max_absolute_error'in c]
 metrics[prefix]={'comparisons':len(selected),'maximum_absolute_error':max(c['max_absolute_error']for c in selected),'maximum_tolerance_units':max(c.get('max_units',c.get('max_tolerance_units',0))for c in selected)}
mutations=[]
for glob in ['negative_mutations/*/EXECUTION.json','negative_mutations_v2/*/EXECUTION.json','negative_mutations_v3/*/EXECUTION.json']:
 for path in sorted(P.glob(glob)):
  rec=json.loads(path.read_text());mutations.append(rec)
  values=json.loads((path.parent/'RESULTS.json').read_text())
  check('genuine numerical mutation rejection '+rec['mutation'],rec['exit_code']==1 and rec['detected_by_numeric_failure']and rec['all_sources_unchanged']and rec['failed_checks']==values['failed']and values['failed']>0)
check('four distinct omission mutations',len(mutations)==len(set(r['mutation']for r in mutations))==4)
final_distances=[{'a':r['a'],'kind':r['kind'],'initial':r['distance_initial'],'final':r['distance_final'],'ratio':r['distance_final']/r['distance_initial']}for r in H['histories']]
# Direct substitution checks the scope-note ratios, not an empirical fit.
reported=[('dust_E0',.00394082),('dust_E1',22.51395),('radiation',.01905724)]
for kind,printed in reported:
 actual=next(r['ratio']for r in final_distances if r['kind']==kind and r['a']==1/2499)
 check('scope rounded ratio '+kind,abs(actual-printed)<(5e-6 if kind=='dust_E1' else 5e-9),actual=actual,printed=printed)
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':digest(Path(__file__)),'coverage':{'parent_checks':194,'parent_symbolic_records':51,'parent_solver_records':30,'parent_spectral_classification_records':15,'parent_array_tolerance_records':98,'spectra':15,'radial_force_families':60,'finite_radial_force_vectors':240,'transverse_derivative_vectors':10,'history_families':6,'sites_per_history':41,'independent_limiting_variation_histories':12,'independent_limiting_nonlinear_histories':6,'independent_full_histories':12},'metrics':metrics,'minimum_final_field':min(c['minimum_field']for c in H['checks']if'minimum_field'in c),'final_distances':final_distances,'mutations':mutations,'mutation_failures_total':sum(r['failed_checks']for r in mutations),'reviewer_driver_failures':[{'path':'MUTATION_EXECUTION_v1.json','kind':'assertion target occurs twice; stopped before third mutation'}, {'path':'MUTATION_EXECUTION_v2.json','kind':'second replacement target occurs twice; stopped before fourth mutation'}],'source_identities':identities,'prior_analytic_review':{'path':str(prior),'sha256':digest(prior),'reuse':'Only exact unchanged imported proof, fixtures and runner; current comparisons use independent code.'},'checks':checks,'summary':{'total':len(checks),'passed':sum(c['passed']for c in checks),'failed':sum(not c['passed']for c in checks)}}
(P/'COMPACT_EVIDENCE_v1.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result['summary']));print(json.dumps(metrics,indent=2));print(json.dumps(final_distances,indent=2));print('minimum field',result['minimum_final_field'])
for c in checks:
 if not c['passed']:print(json.dumps(c))
raise SystemExit(int(result['summary']['failed']>0))
