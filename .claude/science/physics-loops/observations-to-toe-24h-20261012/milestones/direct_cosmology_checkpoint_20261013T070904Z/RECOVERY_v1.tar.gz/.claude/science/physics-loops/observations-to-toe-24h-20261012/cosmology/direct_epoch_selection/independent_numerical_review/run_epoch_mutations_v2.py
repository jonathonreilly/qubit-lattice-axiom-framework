#!/usr/bin/env python3
"""Immutable source-copy falsifiers, used only as negative evidence."""
from pathlib import Path
import collections
import datetime
import difflib
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
S=ROOT/'source_snapshot'
EPOCH=(S/'check_epoch_selection_v1.py').read_text()
FULL=(S/'evidence_v1/source_snapshot/direct_analytic_fluid_completion/check_analytic_fluid_v1.py').read_text()
MUTATIONS=[
 ('omit_limiting_u_restoring_force','epoch',[('return np.array([v,-(3+hh)*v-(-1+4*u+w)/f,','return np.array([v,-(3+hh)*v-(-1+w)/f,')]),
 ('omit_limiting_dust_exchange','epoch',[('-(3+hh)*p-2*a*ff/(beta*f),w*(-3+a*v-2*p)])','-(3+hh)*p-2*a*ff/(beta*f),w*(-3-2*p)])')]),
]
CHILD='''from pathlib import Path
import importlib.util,json
p=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location("negative_epoch",p/"direct_epoch_selection/check_epoch_selection_v1.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rows=m.asymptotic_controls()
out={"scope":"Negative sensitivity only", "rows":rows,"checks":m.CHECKS,"passed":sum(c["passed"] for c in m.CHECKS),"failed":sum(not c["passed"] for c in m.CHECKS)}
(p/"RESULTS.json").write_text(json.dumps(out,indent=2,allow_nan=False)+"\\n")
print(json.dumps({"passed":out["passed"],"failed":out["failed"]},sort_keys=True))
raise SystemExit(int(out["failed"]>0))
'''

records=[]
for name,subject,changes in MUTATIONS:
    base=ROOT/'negative_mutations_v2'/name;ep=base/'direct_epoch_selection';fp=base/'direct_analytic_fluid_completion'
    ep.mkdir(parents=True);fp.mkdir()
    original=EPOCH if subject=='epoch' else FULL;modified=original
    for old,new in changes:
        assert modified.count(old)==1,(name,old,modified.count(old))
        modified=modified.replace(old,new,1)
    (ep/'check_epoch_selection_v1.py').write_text(modified if subject=='epoch'else EPOCH)
    (fp/'check_analytic_fluid_v1.py').write_text(modified if subject=='full'else FULL)
    (ep/'NUMERICAL_FIXTURES_v1.json').write_bytes((S/'NUMERICAL_FIXTURES_v1.json').read_bytes())
    (fp/'NUMERICAL_FIXTURES_v1.json').write_bytes((S/'evidence_v1/source_snapshot/direct_analytic_fluid_completion/NUMERICAL_FIXTURES_v1.json').read_bytes())
    (base/'run_asymptotic_only.py').write_text(CHILD)
    (base/'MUTATION.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),modified.splitlines(True),fromfile='frozen_'+subject,tofile=name+'/'+subject)))
    input_paths=[ep/'check_epoch_selection_v1.py',fp/'check_analytic_fluid_v1.py',ep/'NUMERICAL_FIXTURES_v1.json',fp/'NUMERICAL_FIXTURES_v1.json']
    hashes={str(f.relative_to(base)):hashlib.sha256(f.read_bytes()).hexdigest()for f in input_paths}
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    run=subprocess.run([sys.executable,str(base/'run_asymptotic_only.py')],cwd=base,env=env,capture_output=True,text=True,timeout=30)
    (base/'stdout.txt').write_text(run.stdout);(base/'stderr.txt').write_text(run.stderr)
    results=json.loads((base/'RESULTS.json').read_text()) if (base/'RESULTS.json').exists() else None
    failures=[c for c in results['checks']if not c['passed']]if results else []
    families=collections.Counter('transverse' if c['name'].startswith('full transverse')else 'dust limit' if c['name'].startswith('full dust')else 'radiation limit'for c in failures)
    rec={'mutation':name,'subject':subject,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'exit_code':run.returncode,'source_sha256':hashes,'all_sources_unchanged':all(hashlib.sha256(f.read_bytes()).hexdigest()==hashes[str(f.relative_to(base))]for f in input_paths),
         'original_subject_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_subject_sha256':hashlib.sha256(modified.encode()).hexdigest(),
         'failed_checks':len(failures),'failure_families':dict(families),'max_tolerance_units':max((c.get('max_tolerance_units',0)for c in failures),default=0),
         'detected_by_numeric_failure':run.returncode==1 and bool(failures)}
    (base/'EXECUTION.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec);print(json.dumps(rec,sort_keys=True),flush=True)
out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mutations':records,'all_detected':all(z['detected_by_numeric_failure']for z in records)}
(ROOT/'MUTATION_SUMMARY_v2.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(0 if out['all_detected']else 1)
