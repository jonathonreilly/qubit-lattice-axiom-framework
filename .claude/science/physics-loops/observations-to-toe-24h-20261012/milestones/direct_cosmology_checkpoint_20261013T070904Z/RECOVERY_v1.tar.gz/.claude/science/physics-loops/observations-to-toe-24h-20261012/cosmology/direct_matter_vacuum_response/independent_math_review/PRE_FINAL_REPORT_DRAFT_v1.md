# Independent handwritten review: matter vacuum response

Reviewer: /root/direct_quantum_visibility_review. Date: 2026-10-13.
Scope: the parent's matter-vacuum handwritten construction and its same-session
v2 clarification. This is a mathematical and assumption check, not an
implementation review, formal audit, empirical test, publication clearance, or
proof that the candidate describes nature.

## Disposition

The equations in the frozen v1 derivation are correct under their explicit
premises. The v2 clarification is required for unambiguous reading of the
Jordan tensor coefficient and for preserving the classical-action and
Einstein-expanding scope of the convergence theorem. It makes those
qualifications explicit without changing the displayed derivation equations.
There is no remaining material correction identified in this handwritten unit.

The independent first execution passed 831 checks with zero failures. These
are supporting algebra and numerical controls, not 831 independent physical
predictions. The author's newly written implementation and its executions are
outside this review.

The finite free-electron term is a scheme-dependent diagnostic. A residual
positive coefficient is an additional model parameter. Choosing the total
renormalized Jordan vacuum coefficient to vanish is allowed within the stated
prescription, but neither derives that choice nor explains the supplied H_v.
No constraint on a, observed-vacuum prediction, cosmological likelihood,
spacetime-stability result, or history-selection claim follows here.

## Exact source and change scope

The complete v1 proof, v2 proof, protocol, correction receipt, and inherited
analytic action v2 were read. Exact snapshots and original-source paths are in
SOURCE_FREEZE_v1.json and AFFECTED_SOURCE_FREEZE_v2.json.

| Source | SHA-256 |
| --- | --- |
| Matter-vacuum HAND_DERIVATION_v1.md | 0ee11ac89ffeda0e187de84f439a0c5e44576090318ffac24ef5a2eade69fd94 |
| Matter-vacuum HAND_DERIVATION_v2.md | 0c7b3464d46e9c75e8255fff601154d8712bcc6cf0596092b5fdda514a268994 |
| PROTOCOL_v1.json | d034e6c6e5a7e0ae5ae5bc1fbb44a9c44077b1842b4deb95174b83b25218d461 |
| TENSOR_AND_ACTION_SCOPE_CORRECTION_v2.json | e37dc793c6add525eb95a70a44aa9d01f9e13a2cd8a4836beb5b9be4758e5d56 |
| Prior analytic HAND_DERIVATION_v2.md | 322a932eef3ede5de4d963aae2c623693d12a5942828f971335cc7a6c03ef7d2 |
| Reviewer derive_matter_vacuum_v1.py | b3bbf23247c04dacbe232a9ca6f603e60d35943ed406dc0c97fe63cf137a44e0 |

REVIEWED_v1_to_v2.diff contains the complete affected-source difference. The
changes name the inverse tensor coupling, exclude induced derivative
operators from the convergence theorem, and preserve the inherited
Einstein-expanding/Jordan-transient-contraction distinction.

The relevant primary material was the pinned Burgess 2013 v1 PDF, sections
1.3–1.4 (PDF pages 7–15; printed pages 6–14), and selected CODATA 2022 entries.
The PDF was not read in full. Incidental material adjoining these sections
was not used to extend the review's source scope. Burgess supplies context
about renormalized vacuum energy and technical naturalness; it is not used as
a precision derivation of this Dirac finite coefficient or as observational
validation. That coefficient is derived below. The full PDF and full source
text/table snapshots are local-only recovery evidence, outside any publishable
source selection. The reading ledger identifies the exact primary bytes.

## 1. Matter-only operator and its assumptions

The parent action is
\[
S_g=\int\sqrt{-g}\,[M_E^2R/2-M_E^2K_{AB}\partial\phi^A\partial\phi^B
                  -2M_E^2 V],\qquad
\phi=(u,x,y),\quad g_J=A^2g,\quad A=e^{\sqrt a u}.
\]
The inherited parameters obey \(a,\nu,H_v>0\), with
\[
D=1+\frac{2(1+a)}3(x^2+y^2),\quad
K=\operatorname{diag}(1,4a/(9D),a/(3D)),
\]
\[
V_0=H_v^2\{3/2+f(u)x^2+ay^2/3+\nu u^2/2\},\qquad
f(u)=2(u-\sqrt a/4)^2+3a/8.
\]

If matter's masses and couplings are constant in Jordan units and its
functional integral uses a Jordan-covariant measure, regulator, and
counterterms, the matter-only effective action on the external background is
a functional of g_J. At zero derivative order in its *local* expansion the
vacuum operator is \(-\rho_J\int\sqrt{-g_J}\). Pulling it back gives
\[
\Delta V=\frac{\rho_J}{2M_E^2}A^4=C e^{4\sqrt a u}.
\]
This is a statement about the local vacuum operator and the specified
quantization prescription, not every nonlocal or state-dependent part of an
effective action. Scalar/graviton internal lines, mixed loops, finite
temperature, and derivative terms are not covered by this factorization
argument.

All derivatives obey \(\partial_u^n\Delta V=(4\sqrt a)^n\Delta V\).
A Jordan vacuum counterterm has the identical field dependence. Consequently
one condition on its total renormalized coefficient cancels the whole
operator, rather than separately cancelling infinitely many unrelated Taylor
coefficients. By contrast, subtracting its value only at u=0 leaves
\(C(A^4-1)\); its first two derivatives at the origin are \(4\sqrt a C\) and
\(16aC\). The prescribed polynomial classical potential must be enlarged to
allow this exponential operator when matter is quantized. Nothing in this
argument explains a small total coefficient or removes other effective
operators.

## 2. Independent determinant normalization, running, and frame scales

Let \(t=m^2>0\). A four-component free Dirac Grassmann determinant contributes
\(-2\int_p\log(p^2+t)\) to the Euclidean vacuum density. The factor two comes
from the spin determinant, and the minus sign from minus the logarithm of
the fermionic functional integral.

The dimensionally regulated mass derivative uses
\[
I(t)=\frac{\mu^{2\epsilon}t^{1-\epsilon}}{(4\pi)^{2-\epsilon}}
          \Gamma(\epsilon-1)
 =\frac{t}{16\pi^2}\left[-\frac1\epsilon+\gamma_E-\log4\pi+
                    \log(t/\mu^2)-1\right]+O(\epsilon).
\]
Removing the MS-bar pole package leaves
\(I_{\rm fin}=t[\log(t/\mu^2)-1]/(16\pi^2)\).
Thus \(d\rho_1/dt=-2I_{\rm fin}\). Integrating, with the mass-independent
vacuum integration constant assigned to the separate counterterm, gives
\[
\rho_1=-\frac{t^2}{16\pi^2}\{\log(t/\mu^2)-3/2\}.
\]
As an independently convergent sign/factor check,
\[
\frac{d^3\rho_1}{dt^3}=-4\int\frac{d^4p}{(2\pi)^4}(p^2+t)^{-3}
                    =-\frac1{8\pi^2t}.
\]
The reviewer numerically integrated the radial integral at three positive
masses without using the author's implementation.

At \(\mu=m\), the finite part is \(3m^4/(32\pi^2)\). It crosses zero at
\(\mu=m e^{-3/4}\). Holding the free mass fixed gives
\(d\rho_1/d\log\mu=m^4/(8\pi^2)\), offset by the counterterm's negative
running. These individual finite contributions are not scheme-independent
vacuum observables.

For constant A, substituting \(m_E=Am_J,\mu_E=A\mu_J\) into this expression
gives exactly \(A^4\rho_{1,J}\). Holding the same numerical scale instead
gives the difference
\[
\rho_{1,E}(\mu)-A^4\rho_{1,J}(\mu)
    =-\frac{A^4m_J^4\log A}{8\pi^2}.
\]
The opposite finite local term is needed to implement the same Jordan-defined
prescription in that convention. This constant-background algebra does not
license dropping the derivative and measure terms when A varies.

## 3. Canonical field and SI normalization

The u kinetic term is \(-M_E^2(\partial u)^2\). Therefore
\(\chi_u=\sqrt2M_Eu\), and the physical Einstein-frame potential density is
\(2M_E^2V\). Differentiating that density twice with respect to chi gives
\(m_u^2=V_{uu}\), not \(2V_{uu}\) or \(V_{uu}/2\).
For \(\rho_{\rm target}=3M_E^2H_v^2\) and \(R=\rho_J/\rho_{\rm target}\),
the old-origin terms are
\[
\Delta V/H_v^2=3R/2,\quad
\Delta V_u/H_v^2=6\sqrt a R,\quad
\Delta m_u^2/H_v^2=24aR.
\]
The origin normally has a tadpole after the addition. This Hessian is not the
stationary-vacuum mass computed in the next section.

Under the *imported* bridge \(G_N=(1+a)G_*\),
\[
M_{E,\mathrm{energy}}^2=(1+a)\hbar c^5/(8\pi G_N).
\]
Conversion of a natural-units fourth-power energy density divides by
\((\hbar c)^3\). Hence the source's two SI forms are equal:
\[
\rho_{\rm loop}=\frac{3(m_ec^2)^4}{32\pi^2(\hbar c)^3},\qquad
\rho_{\rm target}
 =\frac{3M_{E,\mathrm{energy}}^2(\hbar H_v)^2}{(\hbar c)^3}
 =\frac{3(1+a)c^2H_v^2}{8\pi G_N}.
\]
Both have dimensions kg m^-1 s^-2, or J/m^3. The source's c and hbar powers
are correct. A small electron-mass measurement uncertainty alone yields
\(d\rho_{\rm loop}/\rho_{\rm loop}=4\,dm_e/m_e\). This is not an uncertainty
model for the counterterm, scheme, supplied cosmology, or gravitational bridge.

For orientation only, the reviewer fixture used the already exposed
photons-only \(\Omega_\gamma=5.04674028922726894\times10^{-5}\),
H0=70 km/s/Mpc, matter fraction .3, the declared parsec/AU conversion, and
the pinned CODATA entries. It gives a displayed free-loop finite contribution
\(1.3505247491271172\times10^{22}\) J/m^3 at \(\mu=m_e\);
R is about \(2.33\times10^{31}\) across the small-a grid. These are diagnostic
scale comparisons, not measured vacuum values. The rounded photon fixture
was reused as exposed development input, not remeasured in this review.

## 4. Positive-residual stationary solution and all canonical masses

Now add the *specified* real coupling \(C\ge0\), holding the remaining
classical action fixed. Since f(u)>0, stationarity in x and y forces
x=y=0. The remaining force
\[
F(u)=\nu H_v^2u+4\sqrt a C e^{4\sqrt a u}
\]
has strictly positive derivative \(\nu H_v^2+16aC e^{4\sqrt a u}\).
For C>0 it crosses from negative to positive once, with its root below zero.
Let \(w=-4\sqrt a u_v\). Its equation is
\(we^w=16aC/(\nu H_v^2)=24aR/\nu\), so w is the nonnegative principal
Lambert-W branch. There are no additional real stationary branches for
the positive argument. The C=0 limit gives w=u_v=0.

The root relation also gives
\(Ce^{-w}=\nu H_v^2w/(16a)\). Substitution then yields
\[
V_{\min}/H_v^2=3/2+\nu(w^2+2w)/(32a),\qquad
H_{E,v}^2/H_v^2=1+\nu(w^2+2w)/(48a).
\]
Since \(A_v=e^{-w/4}\) is constant at the vacuum,
\(H_{J,v}=H_{E,v}/A_v\).

At a stationary point the covariant Hessian's connection correction vanishes.
Here \(K_v=\operatorname{diag}(1,4a/9,a/3)\), and the mixed derivatives
vanish. The eigenvalues of \(K_v^{-1}V_{,AB}\) are
\[
m_{u,E}^2/H_v^2=\nu(1+w),\quad
m_{x,E}^2/H_v^2=9/4+9w/(8a)+9w^2/(16a^2),\quad
m_{y,E}^2/H_v^2=2.
\]
These are Einstein canonical mass parameters of the stated action.
Frequencies in constant-vacuum Jordan proper-time units divide by A_v;
this conversion must be included if physical Jordan masses are reported.
A Cavendish measurement additionally needs the scalar ranges, sources, and
readout response. This review does not infer it from the mass table.

For a constant conformal factor the coefficient of the Jordan Ricci action
is \(M_E^2/(2A_v^2)\), or tensor Planck coefficient \(M_E^2/A_v^2\).
Its inverse coupling obeys \(G_{T,J}/G_{T,J}(0)=A_v^2\).
The v1 adjacent use of “gravitational coefficient” could instead be read as
the Ricci coefficient, producing an apparent inverse scaling. V2 now names
both quantities explicitly and resolves that ambiguity.

The independent numerical route solved F(u)=0 directly by a monotone
bracket and 440 bisection iterations, then compared with W. It also
differentiated V along local canonical-coordinate displacements, including
the factor \(2M_E^2\) of the energy density. Across 84 prescribed
(a,nu,R) choices, including the declared electron-loop diagnostic, the
maximum normalized root difference was 2.3681e-96 and the maximum
canonical-Hessian difference was 9.2117e-95 at 95 decimal digits. These
are numerical consistency controls; the symbolic proof establishes the
full positive-parameter identities.

## 5. Homogeneous energy proof and inherited correction

For the classical two-derivative action plus the exponential alone,
metric compatibility gives
\[
\frac{\dot T}{2}=K(v,D_tv)
   =-3HT-v\cdot\nabla V-\sqrt a\,\sigma\,\dot u.
\]
Adding \(\dot V\), dust exchange
\(\dot\sigma=(-3H+\sqrt a\dot u)\sigma\), and separately conserved
radiation \(\dot r=-4Hr\), gives
\[
E=T/2+V+\sigma+r=3H^2/2,\qquad
\dot E=-3H(T+\sigma+4r/3).
\]
The two matter-transfer terms cancel exactly. No new exchange term is
introduced by a field-dependent potential with constant C.

For C>=0, the exponential is nonnegative, and the old lower bound remains:
\[
V\ge 3H_v^2/2+H_v^2(3ax^2/8+ay^2/3+\nu u^2/2).
\]
A finite-energy sublevel therefore bounds all fields, the nonnegative
densities, and H. K has a uniform positive lower eigenvalue on that compact
field set, so it also bounds velocities. H>=H_v makes the Einstein
positive-root Friedmann branch smooth. The density-zero boundaries are
invariant; the proof must use densities themselves, not a singular
log-density chart. These facts give a compact forward-invariant state
region and extend smooth proper-time solutions globally to the future.

The zero-dissipation set has v=sigma=r=0. Its largest invariant subset also
requires grad V=0. The unique root derived above is its only stationary
state. LaSalle's argument therefore gives convergence to that shifted
vacuum for each finite initial homogeneous state on this expanding branch.

As in the inherited corrected action, “expanding” means Einstein H>0.
\(H_J=A^{-1}(H+\sqrt a\dot u)\) may be negative transiently. Bounded u
keeps A bounded above and bounded away from zero, so Jordan proper time
also extends to infinity. At the attractor \(\dot u\to0\) and
\(H_J\to H_{E,v}/A_v>0\).

V2 explicitly confines this theorem to that truncated classical action.
It is not a result for the matter effective action with arbitrary induced
curvature/kinetic/higher-derivative operators, nor a guarantee that such a
truncation is physically accurate at arbitrary initial energies. It does
not imply inhomogeneous spacetime stability, quantum vacuum selection,
or attraction to a chosen finite-time matter/radiation history. The
positive-C proof is not extended to negative C.

## 6. Curvature term and boundary sign

With \(s=\log A\), the four-dimensional conformal identity is
\[
\sqrt{-g_J}R_J=\sqrt{-g}\,A^2
 [R-6\Box s-6(\partial s)^2].
\]
Use
\[
\nabla_\mu(A^2\nabla^\mu s)=A^2\Box s+2A^2(\partial s)^2.
\]
Thus the original integrand equals
\[
\sqrt{-g}\,[\zeta A^2R/2+3\zeta A^2(\partial s)^2]
 -3\zeta\sqrt{-g}\,\nabla_\mu(A^2\nabla^\mu s).
\]
The bulk kinetic sign is positive as written by the parent. The total
divergence supplies the boundary term. An independent arbitrary-FLRW
symbolic check verifies the same identity with unrestricted functions
for the scale factor and s(t), including the boundary derivative.

This new derivative operator is not cancelled by the zero-derivative
vacuum counterterm. No numerical zeta or full kinetic-positivity statement
is supplied. In particular, its isolated kinetic sign cannot be used
without the simultaneous nonminimal Ricci term to classify the full
theory's modes.

## Controls, failures, and reproducibility

The first reviewer execution used Python 3.12.12, SymPy 1.14.0, and
mpmath 1.3.0 at 95 digits; exact installed versions are recorded in the
machine result. The source is derive_matter_vacuum_v1.py and contains no
author helper/runner import.

The 831 rows consist of 45 symbolic/dimensional checks, 3 convergent
determinant integrals, 120 numerical frame/scale identities, 3 numerical
SI identities, and 660 assertions over 84 direct-root/canonical-mass
fixtures. Formula checks are separate from the handwritten compactness
and invariant-set argument. No claim is made that a finite grid proves
a global theorem.

INDEPENDENT_CONTROLS_v1.json contains every row and numerical value.
PRE_EXECUTION_PLAN_v1.json pins the reviewer source before first execution;
EXECUTION_v1.json and its unmodified stdout/stderr record the actual run.
It completed in about 1.24 seconds, exit 0, with no mathematical,
numerical, or tool failure in that execution. No passing run was repeated.

COMMUNICATION_INTERRUPTION_v1.json records the parent-reported stream
interruption with request ID 4208967c-919c-4474-b84d-cbf23fd42a0c.
No inaccessible transport stack trace is invented. Work resumed from
the preserved source snapshots; this was not a restart of the science.

For reproduction, run the reviewer source in a separate empty copy of this
review directory with the same dependencies. Its JSON output uses exclusive
creation and will intentionally refuse to overwrite an existing result.
The parent implementation remains outside this check. No author source,
repository state, publication artifact, or audit record was changed.

