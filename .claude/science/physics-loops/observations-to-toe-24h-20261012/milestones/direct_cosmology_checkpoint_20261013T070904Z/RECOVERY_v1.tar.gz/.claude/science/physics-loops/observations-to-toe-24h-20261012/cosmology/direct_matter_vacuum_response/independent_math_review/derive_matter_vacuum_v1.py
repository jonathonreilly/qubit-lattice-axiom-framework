#!/usr/local/bin/python3
"""Reviewer-owned handwritten-claim checks. No author helpers or runners imported."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys
import platform
import sympy as sp
import mpmath as mp

HERE = Path(__file__).resolve().parent
mp.mp.dps = 95
rows = []
quantitative = {}

def check(name, passed, details=None):
    rows.append({"name": name, "pass": bool(passed), "details": details})

def exact(name, lhs, rhs=0):
    rem = sp.simplify(sp.expand_log(lhs-rhs, force=True))
    check(name, rem == 0, {"residual": str(rem)})

def close(name, actual, expected, tolerance="1e-75"):
    actual, expected = mp.mpf(actual), mp.mpf(expected)
    error = abs(actual-expected)/max(mp.mpf(1), abs(expected))
    check(name, error <= mp.mpf(tolerance),
          {"actual": mp.nstr(actual, 85), "expected": mp.nstr(expected, 85),
           "normalized_error": mp.nstr(error, 15), "tolerance": tolerance})
    return error

a, nu, Hv, ME, rho, C, R, t, mu, A, w = sp.symbols(
    "a nu H_v M_E rho C R t mu A w", positive=True)
u, x, y, ell, zeta = sp.symbols("u x y ell zeta", real=True)
eps = sp.symbols("epsilon", real=True)
chi = sp.symbols("chi", real=True)

# Euclidean determinant: log det_Dirac = 2 log(p^2+m^2).
# Expand the dimensionally regularized mass derivative; the MS-bar
# subtraction is explicit, including the finite Euler/log(4pi) terms.
I = mu**(2*eps)*t**(1-eps)*sp.gamma(eps-1)/(4*sp.pi)**(2-eps)
Is = sp.series(I, eps, 0, 1).removeO()
pole = t/(16*sp.pi**2)*(-1/eps+sp.EulerGamma-sp.log(4*sp.pi))
Ifinite = sp.simplify(Is-pole)
expectedI = t/(16*sp.pi**2)*(sp.log(t/mu**2)-1)
exact("determinant.MSbar_subtracted_tadpole", Ifinite, expectedI)
rhoD = -t**2/(16*sp.pi**2)*(sp.log(t/mu**2)-sp.Rational(3, 2))
exact("determinant.mass_derivative", sp.diff(rhoD,t), -2*expectedI)
exact("determinant.third_mass_squared_derivative", sp.diff(rhoD,t,3),
      -1/(8*sp.pi**2*t))
exact("determinant.log_scale_running", mu*sp.diff(rhoD,mu),
      t**2/(8*sp.pi**2))
exact("determinant.mu_equals_mass", rhoD.subs(mu,sp.sqrt(t)),
      3*t**2/(32*sp.pi**2))
exact("determinant.zero_at_log_mu_m_minus_three_quarters",
      rhoD.subs(mu,sp.sqrt(t)*sp.exp(-sp.Rational(3,4))))
exact("determinant.matched_frame_scale",
      rhoD.subs({t:A*A*t,mu:A*mu},simultaneous=True), A**4*rhoD)
exact("determinant.fixed_frame_scale_difference",
      rhoD.subs(t,A*A*t)-A**4*rhoD, -A**4*t**2*sp.log(A)/(8*sp.pi**2))

deltaV = rho*sp.exp(4*sp.sqrt(a)*u)/(2*ME**2)
for n in range(7):
    exact(f"operator.derivative_{n}", sp.diff(deltaV,u,n),
          (4*sp.sqrt(a))**n*deltaV)
exact("operator.full_Jordan_counterterm", deltaV-deltaV)
constant_only = deltaV-deltaV.subs(u,0)
exact("operator.constant_only_value_at_origin",constant_only.subs(u,0))
exact("operator.constant_only_tadpole",sp.diff(constant_only,u).subs(u,0),
      2*sp.sqrt(a)*rho/ME**2)
exact("operator.constant_only_mass",sp.diff(constant_only,u,2).subs(u,0),
      8*a*rho/ME**2)
canonical_density = rho*sp.exp(4*sp.sqrt(a)*chi/(sp.sqrt(2)*ME))
exact("canonical.mass_from_energy_density",
      sp.diff(canonical_density,chi,2).subs(chi,0),8*a*rho/ME**2)
origin_replace={rho:3*ME**2*Hv**2*R,u:0}
for n,expected in [(0,sp.Rational(3,2)*R),(1,6*sp.sqrt(a)*R),(2,24*a*R)]:
    exact(f"canonical.dimensionless_origin_derivative_{n}",
          sp.diff(deltaV,u,n).subs(origin_replace)/Hv**2,expected)

# Derive stationary potential and the generalized Hessian of the exact action.
D=1+sp.Rational(2,3)*(1+a)*(x*x+y*y)
K=sp.diag(1,4*a/(9*D),a/(3*D))
f=a/2-sp.sqrt(a)*u+2*u*u
V=Hv**2*(sp.Rational(3,2)+f*x*x+a*y*y/3+nu*u*u/2)+C*sp.exp(4*sp.sqrt(a)*u)
uv=-w/(4*sp.sqrt(a))
Cv=nu*Hv**2*w*sp.exp(w)/(16*a)
atvac={u:uv,x:0,y:0,C:Cv}
for field in (u,x,y):
    exact(f"vacuum.gradient_{field}",sp.diff(V,field).subs(atvac))
Vmin=V.subs(atvac)/Hv**2
exact("vacuum.minimum_potential",Vmin,sp.Rational(3,2)+nu*(w*w+2*w)/(32*a))
exact("vacuum.Einstein_Hubble_squared",sp.Rational(2,3)*Vmin,
      1+nu*(w*w+2*w)/(48*a))
hessian=sp.hessian(V,(u,x,y))
mass_matrix=sp.simplify(K.inv()*hessian)
expected_masses=[nu*(1+w),sp.Rational(9,4)+9*w/(8*a)+9*w*w/(16*a*a),sp.Integer(2)]
for i in range(3):
    exact(f"vacuum.mass_squared_{i}",
          mass_matrix[i,i].subs(atvac)/Hv**2,expected_masses[i])
for i in range(3):
    for j in range(i+1,3):
        exact(f"vacuum.mixed_hessian_{i}_{j}",hessian[i,j].subs(atvac))
exact("vacuum.strict_u_force_derivative",sp.diff(V,u,2).subs({x:0,y:0}),
      nu*Hv**2+16*a*C*sp.exp(4*sp.sqrt(a)*u))
exact("vacuum.Lambert_argument",16*a*C/(nu*Hv**2),
      (24*a*R/nu).subs(R,2*C/(3*Hv**2)))

# Homogeneous energy cancellation from covariant kinetic derivative,
# independent of the coordinate form of the Christoffel symbols.
H,T,vdotgrad,sigma,rr,pu,alph = sp.symbols(
    "H T v_dot_gradV sigma radiation p_u alpha",real=True)
half_Tdot=-3*H*T-vdotgrad-alph*sigma*pu
sigmadot=(-3*H+alph*pu)*sigma
rdot=-4*H*rr
exact("energy.covariant_exchange_cancellation",
      half_Tdot+vdotgrad+sigmadot+rdot,-3*H*(T+sigma+sp.Rational(4,3)*rr))
exact("energy.coercive_f_square",f,2*(u-sp.sqrt(a)/4)**2+3*a/8)

# Explicit arbitrary FLRW test of the integration by parts, including boundary.
tau=sp.symbols("tau",real=True)
b=sp.Function("b")(tau)
s=sp.Function("s")(tau)
Rc=sp.Function("R")(tau)
Lpre=zeta*b**3*sp.exp(2*s)/2*(Rc+6*sp.diff(s,tau,2)+
       18*sp.diff(b,tau)/b*sp.diff(s,tau)+6*sp.diff(s,tau)**2)
Lpost=zeta*b**3*sp.exp(2*s)*Rc/2-3*zeta*b**3*sp.exp(2*s)*sp.diff(s,tau)**2
boundary=3*zeta*b**3*sp.exp(2*s)*sp.diff(s,tau)
exact("curvature.FLRW_arbitrary_functions_boundary",Lpre-Lpost,sp.diff(boundary,tau))
exact("tensor.inverse_coefficient_ratio",(ME**2/A**2)**-1/(ME**2)**-1,A**2)

# Independent SI dimensions and algebra.
hbar,c,GN,mass,Hrate=sp.symbols("hbar c GN mass Hrate",positive=True)
MEe2=(1+a)*hbar*c**5/(8*sp.pi*GN)
density_from_energy=3*MEe2*(hbar*Hrate)**2/(hbar*c)**3
density_direct=3*(1+a)*c*c*Hrate**2/(8*sp.pi*GN)
exact("SI.target_energy_density_forms",density_from_energy,density_direct)
loopSI=3*(mass*c*c)**4/(32*sp.pi**2*(hbar*c)**3)
exact("SI.loop_mass_sensitivity",mass*sp.diff(loopSI,mass)/loopSI,4)
# Dimensional exponents (mass, length, time): these checks do not set c=hbar=1.
dims={"hbar":sp.Matrix([1,2,-1]),"c":sp.Matrix([0,1,-1]),
      "G":sp.Matrix([-1,3,-2]),"m":sp.Matrix([1,0,0]),"H":sp.Matrix([0,0,-1])}
check("SI.loop_dimension",4*(dims["m"]+2*dims["c"])-3*(dims["hbar"]+dims["c"])==sp.Matrix([1,-1,-2]))
check("SI.target_dimension",2*dims["c"]+2*dims["H"]-dims["G"]==sp.Matrix([1,-1,-2]))
check("SI.Planck_energy_squared_dimension",dims["hbar"]+5*dims["c"]-dims["G"]==sp.Matrix([2,4,-4]))

# A convergent continuum integral checks the determinant's third derivative.
for tv in ["0.03125","1","17"]:
    tm=mp.mpf(tv)
    radial=mp.quad(lambda p:p**3/(p*p+tm)**3,[0,mp.sqrt(tm),mp.inf])
    d3=-radial/(2*mp.pi**2)
    close(f"quadrature.det_third_derivative_t_{tv}",d3,-1/(8*mp.pi**2*tm))

# Numeric frame/scale controls are direct dimensional functions, not symbolic rewrites.
def rho_num(mm,scale):
    return -mm**4/(16*mp.pi**2)*(mp.log(mm**2/scale**2)-mp.mpf("1.5"))
for av in ["1e-6","0.00040016006402561027","0.01"]:
    aa=mp.mpf(av)
    for uu in ["-2","-0.1","0","0.2","3"]:
        aa_scale=mp.exp(mp.sqrt(aa)*mp.mpf(uu))
        for logscale in ["-2","-0.75","0","1"]:
            mm=mp.mpf("1.7")
            scale=mm*mp.exp(mp.mpf(logscale))
            close(f"frame.matched_a{av}_u{uu}_l{logscale}",
                  rho_num(aa_scale*mm,aa_scale*scale),aa_scale**4*rho_num(mm,scale))
            close(f"frame.fixed_a{av}_u{uu}_l{logscale}",
                  rho_num(aa_scale*mm,scale)-aa_scale**4*rho_num(mm,scale),
                  -aa_scale**4*mm**4*mp.log(aa_scale)/(8*mp.pi**2))

# A deliberately non-empirical SI illustration. The photon number used here
# is the already exposed development calibration, not a new fit/test.
me=mp.mpf("9.1093837139e-31"); ume=mp.mpf("0.0000000028e-31")
cs=mp.mpf("299792458"); hs=mp.mpf("6.62607015e-34"); hbs=hs/(2*mp.pi)
gs=mp.mpf("6.67430e-11")
# Exact astronomical conventional pc relation using AU=149597870700 m.
Mpc=mp.mpf(648000)/mp.pi*mp.mpf(149597870700)*10**6
H0=mp.mpf(70000)/Mpc
Omega=mp.mpf("5.04674028922726894e-5")
Hvs=H0*mp.sqrt(mp.mpf(".7")-Omega)
eloop=3*(me*cs*cs)**4/(32*mp.pi**2*(hbs*cs)**3)
quantitative["SI_illustration"]={
 "input_role":"Supplied benchmark H0=70, matter_fraction=.3, exposed photons-only Omega; no likelihood.",
 "Omega_gamma_used":mp.nstr(Omega,25),
 "electron_loop_J_per_m3":mp.nstr(eloop,50),
 "electron_relative_mass_uncertainty":mp.nstr(ume/me,25),
 "linear_loop_relative_uncertainty_from_me_only":mp.nstr(4*ume/me,25),
 "H_v_per_second":mp.nstr(Hvs,50),
 "parsec_convention":"pc=(648000/pi)*AU; AU=149597870700 m; illustrative dimension conversion only"
}
electron_R={}
for av in ["1e-6","0.00040016006402561027","0.01"]:
    aa=mp.mpf(av)
    pE2=(1+aa)*hbs*cs**5/(8*mp.pi*gs)
    target1=3*pE2*(hbs*Hvs)**2/(hbs*cs)**3
    target2=3*(1+aa)*cs**2*Hvs**2/(8*mp.pi*gs)
    close(f"SI.numeric_target_a{av}",target1,target2)
    electron_R[av]=eloop/target2
quantitative["SI_illustration"]["R_by_a"]={k:mp.nstr(v,50) for k,v in electron_R.items()}

# Monotone direct force in u is solved by bisection; W is only the comparator.
# Explicitly use the potential and independently numerically differentiate
# with respect to local canonical field displacements for all three masses.
vacua=[]
max_root=mp.mpf(0)
max_hessian=mp.mpf(0)
for av in ["1e-6","0.00040016006402561027","0.01"]:
    aa=mp.mpf(av)
    for nv in ["0.25","1","2.25","4"]:
        nn=mp.mpf(nv)
        for rv in ["0","1e-8","0.01","1","1e8","1e20","electron_loop"]:
            rrn=electron_R[av] if rv=="electron_loop" else mp.mpf(rv)
            cc=mp.mpf("1.5")*rrn  # H_v=1, C=3 R/2.
            arg=24*aa*rrn/nn
            force=lambda zz:nn*zz+4*mp.sqrt(aa)*cc*mp.exp(4*mp.sqrt(aa)*zz)
            def pot(uu,xx,yy):
                return (mp.mpf("1.5")+(aa/2-mp.sqrt(aa)*uu+2*uu**2)*xx**2+
                        aa*yy**2/3+nn*uu**2/2+cc*mp.exp(4*mp.sqrt(aa)*uu))
            if rrn:
                lo=-(1+mp.log1p(arg))/(4*mp.sqrt(aa)); hi=mp.mpf(0)
                check(f"root.bracket_a{av}_n{nv}_R{rv}",force(lo)<0<force(hi))
                for _ in range(440):
                    mid=(lo+hi)/2
                    if force(mid)>0:hi=mid
                    else:lo=mid
                ur=(lo+hi)/2
            else:
                ur=mp.mpf(0)
            ww=mp.lambertw(arg)
            ue=-ww/(4*mp.sqrt(aa))
            err=close(f"root.direct_u_a{av}_n{nv}_R{rv}",ur,ue)
            max_root=max(max_root,err)
            mn=mp.matrix([
                mp.diff(lambda q:pot(ur+q/mp.sqrt(2),0,0),0,2)*2,
                mp.diff(lambda q:pot(ur,q/mp.sqrt(2*4*aa/9),0),0,2)*2,
                mp.diff(lambda q:pot(ur,0,q/mp.sqrt(2*aa/3)),0,2)*2])
            em=[nn*(1+ww),mp.mpf(9)/4+9*ww/(8*aa)+9*ww**2/(16*aa**2),mp.mpf(2)]
            for j in range(3):
                er=close(f"canonical.local_Hessian_{j}_a{av}_n{nv}_R{rv}",mn[j],em[j])
                max_hessian=max(max_hessian,er)
            vmin=pot(ur,0,0)
            close(f"vacuum.Vmin_a{av}_n{nv}_R{rv}",vmin,
                  mp.mpf("1.5")+nn*(ww**2+2*ww)/(32*aa))
            he=mp.sqrt(2*vmin/3)
            aa_v=mp.exp(mp.sqrt(aa)*ur)
            close(f"vacuum.Jordan_H_a{av}_n{nv}_R{rv}",he/aa_v,
                  mp.sqrt(1+nn*(ww**2+2*ww)/(48*aa))*mp.exp(ww/4))
            check(f"vacuum.positive_masses_and_H_a{av}_n{nv}_R{rv}",
                  all(v>0 for v in mn) and he>=1 and aa_v>0)
            vacua.append({"a":av,"nu":nv,"R_kind":rv,"R":mp.nstr(rrn,45),
                          "u_direct":mp.nstr(ur,45),"w":mp.nstr(ww,45),
                          "A_v":mp.nstr(aa_v,45),"HE_over_Hv":mp.nstr(he,45),
                          "HJ_over_Hv":mp.nstr(he/aa_v,45),
                          "mass_squared_over_Hv_squared":[mp.nstr(v,45) for v in mn]})
quantitative["vacuum_rows"]=vacua
quantitative["max_normalized_direct_root_error"]=mp.nstr(max_root,20)
quantitative["max_normalized_canonical_Hessian_error"]=mp.nstr(max_hessian,20)

result={
 "schema":"independent_handwritten_math_controls_v1",
 "created_at":dt.datetime.now(dt.timezone.utc).isoformat(),
 "scope":"Independent checks of handwritten matter-vacuum claims only; no author implementation imported/executed.",
 "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 "versions":{"python":platform.python_version(),"sympy":sp.__version__,"mpmath":mp.__version__},
 "mpmath_digits":mp.mp.dps,
 "checks":rows,
 "counts":{"pass":sum(r["pass"] for r in rows),"fail":sum(not r["pass"] for r in rows),"total":len(rows)},
 "quantitative":quantitative
}
with (HERE/"INDEPENDENT_CONTROLS_v1.json").open("x") as handle:
    json.dump(result,handle,indent=2);handle.write("\n")
print(json.dumps(result["counts"]))
sys.exit(0 if result["counts"]["fail"]==0 else 1)

