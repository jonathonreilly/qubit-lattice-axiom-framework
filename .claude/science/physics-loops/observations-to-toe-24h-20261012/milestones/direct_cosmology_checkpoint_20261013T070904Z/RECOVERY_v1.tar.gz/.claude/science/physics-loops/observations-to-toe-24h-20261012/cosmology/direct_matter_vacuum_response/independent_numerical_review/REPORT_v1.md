# Independent implementation, output, and calibration review

2026-10-13. Reviewer: `/root/launch_check`. Parent remains author. This is a focused independent check of the frozen matter-vacuum response block, not a formal mathematical audit, publication verdict, or independent experiment.

## Disposition

No numerical discrepancy was found in the original SI calibration, 60 scheme rows, 15 operator backgrounds through derivative order six, 84 shifted-vacuum rows, canonical masses, tensor/Ricci scaling, or explicit curvature boundary calculation. All 4,697 numerical comparison records in the independent run passed the frozen tolerances. These records include arithmetic consistency controls and repeated comparisons; they are not 4,697 independent physical tests.

The first independent execution is **8,671 passed, 1 failed, exit code 1**. Its failure is real and retained: two original source-hash checks have the identical displayed name `frozen input HAND_DERIVATION_v2.md`. One refers to this block and the other to the inherited analytic-fluid theorem. The full source paths and hashes distinguish them correctly; there is no source substitution or numerical failure. The checker and tolerance policy were not revised to turn that result green.

Actual source mutations demonstrate **two assertion-coverage gaps in the author's runner**: its stored old-origin calibrated mass and tensor-coupling output can each be wrong while the author reports 1,406 passed and zero failed. The originals are correct. The independent comparison detects both wrong outputs. These gaps warrant separately versioned parent corrections and new evidence, preserving the current run and this report.

## Exact reviewed subject and separation of roles

The comparison subject is parent `evidence_v1/RESULTS.json`, SHA-256 `ea4ff2b5b22053e6857fc96292f91a5c1e2e7519348ea47466ba36103369106a`, generated from parent runner SHA-256 `92f7f5873e6697a7b87804550947adcc07fd444b8acee7993b86c332fe2d8fc2`. Its declared 1,406 checks comprise 1,103 numerical checks, 27 symbolic checks, and 276 Boolean checks. Their counts, stored arithmetic, frozen tolerances, and statuses were independently inspected. Checking the recorded symbolic zeros does not itself independently prove all 27 symbolic statements.

The current hand derivation is v2, SHA-256 `0c7b3464d46e9c75e8255fff601154d8712bcc6cf0596092b5fdda514a268994`. The preserved v1 is `0ee11ac89ffeda0e187de84f439a0c5e44576090318ffac24ef5a2eade69fd94`. The pre-execution tensor/action scope correction is `e37dc793c6add525eb95a70a44aa9d01f9e13a2cd8a4836beb5b9be4758e5d56`.

The independent implementation imports mpmath and standard-library modules, **no author module or helper**. Parent results are comparison subjects. Parent code is executed only as the subject of the six source-mutation tests. The separate handwritten proof reviewer was not used as a positive oracle. No author file was edited, and no Git or publication action was taken.

## Independent routes and outcomes

The numerical plan was saved before execution in `PRE_EXECUTION_PLAN_v1.json`. The independent calculation uses 120 decimal digits and retains the parent's normalized tolerance `1e-60`, root comparison tolerance `1e-55`, and CODATA mass-energy absolute allowance `5e-25 J`. No tolerance was relaxed. The largest normalized discrepancy outside the deliberately looser CODATA rounding control is approximately `1.5e-79`.

**SI conversion.** Let the ordinary Compton wavelength be `lambda_C=h/(m_e c)` and electron rest energy be `E=m_e c^2`. The separate route uses

`rho_loop = (3 pi/4) E/lambda_C^3`,

which has units J/m³ without using the author's natural-unit density conversion. The target is critical **mass** density `3H0^2/(8 pi G_N)` times the supplied fraction `1-m-Omega_gamma`, `c^2`, and the imported factor `(1+a)`. The Planck-energy normalization was separately obtained through gravitational time `t_G=sqrt(hbar G_N/c^5)` and `(1+a)hbar^2/(8 pi t_G^2)`.

This yields `rho_loop ≈ 1.350524749127117e22 J/m³`. At `a=1/2499`, the supplied target is `5.79232000706336e-10 J/m³` and the conditional ratio is `2.33157827516477e31`. These agree with the author at the frozen tolerances. The target is a supplied cosmological benchmark, not a newly measured density, and the free-electron finite part is not an observed cosmological constant.

**Scheme and operator checks.** The determinant is recomputed through a spectral-zeta derivative normalized to the same explicitly supplied finite convention, rather than the author's closed logarithmic function. This is computational independence within a shared renormalization convention, not an independent physical choice of that convention. All 60 combinations of `a,u,log(mu/m)` are checked. The running counterterm is obtained by integrating the scale derivative. Fixed and matched scales, their finite local difference, and the nonzero beta function at the zero-finite-part scheme agree.

All 15 operator backgrounds and orders `n=0..6` are checked by a 128-node Cauchy coefficient extraction on a unit circle, separately from the author's symbolic and real-derivative routes. Whole-operator subtraction and the surviving derivatives after constant-only subtraction are distinguished explicitly. This checks the candidate's correlated operator coefficients, not a finite list of independently adjustable Taylor counterterms.

**Canonical stationary solutions.** Set `M_E=H_v=1` for the dimensionless calculation. Around `x=y=0`, use physical canonical coordinates

`u=q0/sqrt(2)`, `x=3q1/sqrt(8a)`, `y=q2 sqrt(3/(2a))`,

and differentiate the full physical potential `U=2V`. With `b=2sqrt(2a)`, stationarity is `nu q0+3R b exp(bq0)=0`. For `R>0`, a separate Newton iteration solves `log(z)+bz=log(3Rb/nu)` for `z=-q0>0`, starting below the unique root. No Lambert-W call or author bisection is used. It converges in at most nine iterations on the full grid. The `R=0` point is handled exactly.

Every one of the 84 rows is checked against this solution, its full canonical Hessian, mixed and first derivatives, potential value, Hubble values, and both tensor/Ricci scalings. The linear canonical coordinates are local at the stationary point; they do not claim a globally constant field-space metric. Vanishing first derivatives justify omitting the connection contribution to the covariant Hessian there. The old-origin `24aR` correction is also obtained independently from the physical exponential potential in the canonical field and SI energy normalization. It is not substituted for the displaced-vacuum mass.

For scale only, the explicit zero-counterterm electron example at `a=1/2499, nu=1` has `u_v≈-792.73061`, `A_v≈1.29733423e-7`, `H_E/H_v≈464.84375`, `H_J/H_v≈3.58306853e9`, tensor-G ratio `≈1.68307610e-14`, and Ricci coefficient ratio `≈5.94150199e13`. These conditional values do not demonstrate observed vacuum relaxation with fixed gravity.

**Tensor and derivative terms.** From the constant Weyl conversion, Jordan volume contributes `A^-4` and Einstein Ricci curvature contributes `A^2`, giving a Jordan Ricci-action coefficient proportional to `A^-2`. The tensor Newton coefficient is its inverse, proportional to `A^2`. The v2 language and original outputs correctly distinguish them. Neither is established as a Cavendish measurement without scalar-range and source/readout calculations.

The curvature test independently constructs `a_J=A a_E`, differentiates in Jordan proper time to obtain `H_J` and `R_J`, and integrates the pulled-back Jordan curvature density. Its boundary difference is `3.099799324856118...`, matching the author. This is the stated dimensionless `zeta=1` identity; no electron-induced numerical curvature coefficient or complete quantum derivative action is inferred.

## Calibration lineage

The full recovered NIST table and its gzip decompression are byte-identical, SHA-256 `77fb90e66c40db3e6eb16630bc9c88e4c7c8beddbe5e71be406f2f26e3f67e67`. Names, values, uncertainties, units, and complete raw lines match CODATA 2022 rows 107, 108, 264, 271, and 330. The selected-row file is `85d6947f5e1debefe42d42862e8aabe10f292e5053549a42e9313e4830395f6b`; the input file is `7db667b755bc236e7ddff9408fecd3891b6547009836e0c129098e194e67938f`.

The mass-derived and tabulated electron energies differ by approximately `3.15498158697668e-25 J`, within the frozen `5e-25 J` rounding allowance. They are correlated representations, not independent calibrations. Electron-mass endpoints and the conditional linear `4 dm/m` propagation agree. The separate G endpoints correctly retain fixed photon density while changing critical density, hence rescale `Omega_gamma` by `G/G0`. No combined Gaussian likelihood is present or inferred.

The exposed photon value is traced to the frozen prior radiation result `8c0bb51294f924530c5068b61fda0ebfca8818870fea0cb68556381faed01fe7`, at `thermal.thermal_rows[1].Omega_gamma`, and its fixture `1c125242e99770a9a3387f2a17358cad8b705c7c82dec9136794e4951218811c`. This review verifies the import and identity, not a new radiation experiment. `H0=70`, `m=0.3`, the Mpc conversion, `a,nu`, and the weak-field bridge remain supplied/imported assumptions.

The recovered Burgess PDF has the ledger's version/hash identity. This numerical review used its ledger role and file identity only; it does not claim to have independently read or proved the entire paper. The recovery copy is review evidence, not a proposed publication attachment or numerical oracle.

## Actual source-mutation evidence

Each mutant changes one anchored source expression, executes its own complete source file, and has a fresh input freeze containing the **mutated** source hash. Source-hash rejection therefore cannot count as numerical detection. All original failures, mutant outputs, stdout, stderr, exact diffs, source files, execution records, and hashes are retained in `mutations_v1/`. All mutant inputs remained unchanged during their runs.

| Actual mutation | Author failed checks / exit | New independent failures beyond the retained baseline metadata failure |
|---|---:|---:|
| Numerical operator exponent `4` to `2` | 102 / 1 | 204 |
| Stored old-origin mass output `24aR` to `12aR` | **0 / 0** | **3** |
| Omit `sqrt(2)` in canonical physical potential | 1 / 1 | 2 |
| Leave the Einstein matching scale numerically fixed | 48 / 1 | 96 |
| Evaluate displaced x mass at the old origin | 72 / 1 | 216 |
| Store `A^-2` as the tensor-G ratio | **0 / 0** | **72** |

The independent failure counts include multiple controls per erroneous value and must not be treated as independent experiments. Every independent mutant run also retains the single baseline duplicate-label failure. The two bold rows are **author false successes on deliberately wrong source**; they are not relabeled as author detections. The original source remains numerically correct.

Concrete parent corrections are: use full path identities in source-check names (current runner line 38); assert the serialized old-origin calibrated mass independently of its output expression (line 136); and assert serialized tensor-G and Ricci coefficient values with their opposite transformation laws (line 219). A corrected runner and new execution must remain separate from this frozen source/evidence. Do not rewrite the prior output or its status.

## Limits and source-bound disposition

The derivation v2 honestly separates the free scheme-dependent loop diagnostic from the extra model choice of a specified nonnegative residual coefficient, including the illustrative zero-counterterm electron choice. One Jordan-covariant vacuum counterterm cancels the whole zero-derivative operator; choosing it does not explain the observed scale, remove derivative terms, or prove ultraviolet completion. The present calculation gives no observational exclusion, bound on `a`, or vacuum-energy prediction.

The global homogeneous convergence extension belongs to the supplied classical two-derivative potential-only model on the Einstein-expanding positive-fluid branch with `a,nu>0` and fixed `C>=0`. This numerical review checks finite-grid stationary/Hessian consequences and the curvature identity. It does not replace the separate proof, cover `C<0`, select a finite cosmological history, establish inhomogeneous stability, or include induced derivative operators, scalar/graviton loops, or a complete quantum theory. Transient Jordan contraction and the shifted tensor normalization remain explicit.

There are zero new independent empirical tests. There is no formal audit or publication PASS, no imported approval from previous blocks, and no new claim of universal quantum stability. The evidence supports numerical agreement of the frozen implementation within its stated assumptions, with the retained metadata failure and two demonstrated author-assertion gaps. `RECEIPT_v1.json` binds the exact source/input identities, all independent and mutant evidence, and the final unchanged-input check.
