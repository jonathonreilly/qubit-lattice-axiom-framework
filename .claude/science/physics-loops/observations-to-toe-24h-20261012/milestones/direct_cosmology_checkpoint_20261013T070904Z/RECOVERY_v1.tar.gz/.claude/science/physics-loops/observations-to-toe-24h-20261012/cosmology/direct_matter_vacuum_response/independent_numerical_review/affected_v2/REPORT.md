# Affected v2 assertion-coverage review

2026-10-13. Reviewer `/root/launch_check`; parent `/root` remains author. Scope: the v2 correction of three findings from the frozen independent numerical review. No formal audit, mathematical-proof verdict, publication gate, or independent experiment is performed here.

## Finding

The affected correction is supported. The first affected review completed **1,529 checks passed, zero failed, exit code 0**. The full-path labels are unique, the scientific source expressions and output values are unchanged, and both previously surviving source mutations now trigger the intended numerical assertions. No remaining issue was found within this affected scope.

This does not rewrite the first review: **8,671 passed, one duplicate-label failure, exit code 1**, and both earlier author false-success mutant results remain preserved and hash-bound. The newly successful affected review and the original failed review have separate identities and dispositions.

## Exact source and output comparison

| Artifact | SHA-256 |
|---|---|
| Parent v1 runner | `92f7f5873e6697a7b87804550947adcc07fd444b8acee7993b86c332fe2d8fc2` |
| Parent v2 runner | `c34e2237062f95310232050f2a5926b088a6ca080287a55e97887d05c8facab6` |
| Parent v1 result | `ea4ff2b5b22053e6857fc96292f91a5c1e2e7519348ea47466ba36103369106a` |
| Parent v2 result | `9cab3e2feaef36aa114a051c33b2b91422d9772ad0c7b54b8b06e8df810f49fa` |
| Earlier independent numerical result | `3327623758e542170b91f77bbbc3488dc8a5c6ba8c578a26f2c4afa681327609` |
| Earlier independent receipt | `50ae73b58b69cc13829539ac92b240aca3d9aa7ea8ece5e73711a21fd3c5a473` |

Removing exactly three added assertion blocks and reversing the output-directory version and full-path display-label replacements restores the v1 source byte for byte. The independently generated diff equals the parent's preserved diff. There is no other source change.

The five full scientific output sections—`symbolic`, `calibration`, `scheme_operator`, `positive_vacua`, and `curvature`—have identical parsed JSON values and identical canonical-serialization hashes in v1 and v2. All 1,393 original nonsource assertion records are also identical, including their numeric values, tolerances, and outcomes. The v2 result contains 1,663 distinct assertion names, including the uniqueness assertion itself. All 14 source assertions identify their full frozen paths.

There are exactly 256 new assertion controls: three serialized canonical-mass checks, 84 inverse-action tensor-G checks, 84 Ricci-action checks, 84 reciprocity checks, and one unique-name check. The additional frozen correction input adds one source-hash check, accounting for the total increase from 1,406 to 1,663.

## Review of the affected controls

The canonical-mass check reads the value actually stored in `old_origin_delta_mass_squared_over_Hv2`. Its reference differentiates the physical SI-energy potential

`U(phi)=rho (hbar c)^3 exp[4 sqrt(a) phi/sqrt(2 M_E,energy^2)]`

twice in the canonical energy-valued field and divides by `(hbar H_v)^2`. This gives a dimensionless mass ratio and retains the required `sqrt(2)` kinetic normalization. It does not merely repeat the serialized `24aR` expression. The three new reference values agree with the previously frozen independent canonical-energy calculation at `1e-60` normalized tolerance.

The action-based reference uses the solved scalar field to evaluate `exp(-2 sqrt(a) u_v)`, the Jordan Ricci-action coefficient ratio. It checks the serialized Ricci value against that coefficient and the serialized tensor-G ratio against its inverse. A further check multiplies the two serialized fields and requires unity. These distinguish `A_v^-2` from `A_v^2` and directly cover the stored output fields. All 84 new action references agree with the prior independent Weyl-volume/curvature calculation at the original `1e-60` tolerance. All 255 added numeric assertions retain that tolerance and their default normalization.

The prior independently recomputed values are reused as frozen references. No author helper was imported as a positive oracle. No full positive numerical recomputation or positive author rerun was performed. The old scheme, units, canonical-vacuum, and curvature calculations were not unnecessarily repeated.

## Exactly two actual source mutations

Each mutation was applied once to an anchored expression in a complete v2 source copy. Each copy received a new freeze containing its **mutated source hash**, alongside the inputs actually read. Both complete mutated runners were executed. All raw result files, full failed-check records, stdout, stderr, source copies, diffs, freezes, and execution receipts are retained under `mutations/`.

| Actual source mutation | v1 author outcome, preserved | v2 author outcome, executed here |
|---|---|---|
| Stored old-origin mass `24aR` to `12aR` | 1,406 passed / 0 failed; exit 0 | **1,660 passed / 3 failed; exit 1** |
| Stored tensor-G `A_v^2` to `A_v^-2` | 1,406 passed / 0 failed; exit 0 | **1,519 passed / 144 failed; exit 1** |

The mass mutation changes precisely the three intended calibrated output fields and fails precisely the three new serialized canonical-mass assertions.

The tensor mutation changes precisely 72 nonzero-residual tensor-G output fields. Each fails its inverse-action and reciprocity assertion, giving 144 failures. The 12 `R=0` rows remain equal to unity. The separate Ricci-output assertions continue to pass because that output was not mutated.

Every failure is numerical at the frozen tolerance. No input-hash rejection, duplicate-name rejection, unrelated assertion failure, or execution exception contributes to mutation detection. Both mutants retain all 1,663 unique labels and unchanged frozen inputs. No other mutants were executed in this affected review.

## Preservation and limits

The 32 reviewed paths, including the 14 parent frozen inputs, earlier failed independent evidence, both earlier false-success mutant receipts, v2 source/evidence, and the parent correction history, were frozen before this check and verified unchanged afterward. Writes were confined to this new `affected_v2/` folder. Existing author and reviewer artifacts were not edited.

The correction strengthens internal output checks; it creates no new physical model, observation, empirical constraint, or proof family. The free electron finite term remains scheme dependent, the zero-counterterm example remains an additional conditional model choice, and the target density and weak-field bridge remain supplied/imported. The prior limitations on finite-history selection, inhomogeneous stability, induced derivative operators, and quantum completion remain unchanged.

The first affected execution, its complete predicate records, both mutation failures, precise input/source identities, and final unchanged-input verification are bound in `RECEIPT.json`. This report closes only the three demonstrated implementation/metadata findings for the exact v2 source hash above; it grants no formal audit or publication PASS.
