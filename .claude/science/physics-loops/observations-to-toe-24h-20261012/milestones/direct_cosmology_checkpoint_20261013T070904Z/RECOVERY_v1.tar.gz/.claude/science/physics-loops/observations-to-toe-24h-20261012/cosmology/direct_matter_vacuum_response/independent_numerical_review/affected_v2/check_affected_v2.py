#!/usr/bin/env python3
"""Only the affected v2 correction: source comparison, saved outputs, two mutants.

There is no positive author execution, no new vacuum solver, and no rerun of the
other four earlier mutants. Numerical references are the frozen independent v1
recomputation already bound by its preserved receipt.
"""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal, localcontext
import contextlib, difflib, hashlib, json, shutil, subprocess, sys, time, traceback

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent.parent
SNAP=HERE/'input_snapshot/direct_matter_vacuum_response'
FROZEN=json.loads((HERE/'INPUT_FREEZE.json').read_text())
SCIENCE=['symbolic','calibration','scheme_operator','positive_vacua','curvature']
CHECKS=[]
TOL=Decimal('1e-60')
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def truth(name,condition,detail=None):CHECKS.append(dict(name=name,passed=bool(condition),detail=detail))
def near(name,got,expected):
    with localcontext() as ctx:
        ctx.prec=120
        g,e=Decimal(str(got)),Decimal(str(expected))
        scale=max(Decimal(1),abs(g),abs(e));err=abs(g-e)/scale
    CHECKS.append(dict(name=name,passed=bool(err<=TOL),got=str(g),expected=str(e),normalization=str(scale),normalized_error=str(err),tolerance=str(TOL)))
def digest_value(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

MASS_BLOCK="""        physical_U=lambda phi:rho*(hb*c)**3*mp.exp(4*mp.sqrt(aa)*phi/mp.sqrt(2*me2))
        mass_from_canonical_energy=mp.diff(physical_U,0,2)/(hb*hv)**2
        near('serialized calibrated canonical mass '+astr,
             number(scales[-1]['old_origin_delta_mass_squared_over_Hv2']),mass_from_canonical_energy)
"""
TENSOR_BLOCK="""                # Action coefficient from the solved scalar, independent of stored A_v.
                ricci_from_action=mp.exp(-2*alpha*uv)
                near('serialized tensor-G from inverse action '+tag,number(rows[-1]['tensor_G_ratio']),1/ricci_from_action)
                near('serialized Ricci coefficient from action '+tag,number(rows[-1]['Jordan_Ricci_coefficient_ratio']),ricci_from_action)
                near('serialized tensor/Ricci reciprocity '+tag,number(rows[-1]['tensor_G_ratio'])*number(rows[-1]['Jordan_Ricci_coefficient_ratio']),1)
"""
NAMES_BLOCK="""    names=[q['name']for q in CHECKS]
    truth('unique assertion names',len(names)==len(set(names)))
"""

def source_and_saved_output_check(v1,v2,independent):
    old=(SNAP/'check_matter_vacuum_v1.py').read_text()
    new=(SNAP/'check_matter_vacuum_v2.py').read_text()
    truth('v1 exact previously reviewed source identity',sha(SNAP/'check_matter_vacuum_v1.py')=='92f7f5873e6697a7b87804550947adcc07fd444b8acee7993b86c332fe2d8fc2')
    truth('v2 exact delegated source identity',sha(SNAP/'check_matter_vacuum_v2.py')=='c34e2237062f95310232050f2a5926b088a6ca080287a55e97887d05c8facab6')
    truth('v2 exact delegated result identity',sha(SNAP/'evidence_v2/RESULTS.json')=='9cab3e2feaef36aa114a051c33b2b91422d9772ad0c7b54b8b06e8df810f49fa')
    reversed_source=new
    for label,block in [('physical canonical mass assertion',MASS_BLOCK),('Weyl serialized assertions',TENSOR_BLOCK),('unique names assertion',NAMES_BLOCK)]:
        truth('exact single new block '+label,reversed_source.count(block)==1)
        reversed_source=reversed_source.replace(block,'',1)
    for label,before,after in [('output-directory version',"HERE/'evidence_v2'","HERE/'evidence_v1'"),('full source path label',"truth('frozen input '+str(path),actual==row['sha256'])","truth('frozen input '+path.name,actual==row['sha256'])")]:
        truth('exact single replacement '+label,reversed_source.count(before)==1)
        reversed_source=reversed_source.replace(before,after,1)
    truth('no other source change: removing allowed corrections restores v1 bytes',reversed_source==old)
    observed=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='check_matter_vacuum_v1.py',tofile='check_matter_vacuum_v2.py'))
    (HERE/'REVIEWED_v1_to_v2.diff').write_text(observed)
    truth('parent preserved diff is exact',observed==(SNAP/'ASSERTION_COVERAGE_v1_to_v2.diff').read_text())
    section_receipts={}
    for section in SCIENCE:
        same=v1[section]==v2[section]
        truth('unchanged full scientific output section '+section,same)
        section_receipts[section]=dict(identical=same,v1_value_sha256=digest_value(v1[section]),v2_value_sha256=digest_value(v2[section]))
    c1={r['name']:r for r in v1['checks'] if not r['name'].startswith('frozen input ')}
    c2={r['name']:r for r in v2['checks']}
    truth('all v2 names unique including the uniqueness check',len(c2)==len(v2['checks'])==1663)
    truth('all1393 original nonsource check records unchanged',len(c1)==1393 and all(c2.get(name)==record for name,record in c1.items()))
    inputs=load(SNAP/'evidence_v2/FREEZE.json')['inputs']
    truth('all14 v2 source check labels contain exact full path',
          all('frozen input '+r['path'] in c2 for r in inputs) and len([n for n in c2 if n.startswith('frozen input ')])==14)
    truth('source manifest output equals14 frozen input identities',[(r['path'],r['sha256']) for r in v2['source_hashes']]==[(r['path'],r['sha256']) for r in inputs])
    truth('parent v2 passed1663 failed0',v2['checks_passed']==1663 and v2['checks_failed']==0 and all(r['passed'] for r in v2['checks']))
    expected_new={'unique assertion names'}
    old_cal={r['a']:r for r in independent['calibration']['a_rows']}
    for row in v2['calibration']['a_rows']:
        name='serialized calibrated canonical mass '+row['a'];expected_new.add(name)
        record=c2[name]
        truth('stored mass is the asserted quantity '+row['a'],record['got']==row['old_origin_delta_mass_squared_over_Hv2'])
        near('new canonical SI mass reference agrees with independent v1 '+row['a'],record['expected'],old_cal[row['a']]['old_origin_delta_mass_squared_over_Hv2'])
    old_vac={(r['a'],r['nu'],r['residual_label']):r for r in independent['positive_vacua']}
    for row in v2['positive_vacua']:
        key=tuple(row[k] for k in ['a','nu','residual_label']);tag=','.join(key);reference=old_vac[key]
        for prefix,field in [('serialized tensor-G from inverse action ','tensor_G_ratio'),('serialized Ricci coefficient from action ','Jordan_Ricci_coefficient_ratio')]:
            name=prefix+tag;expected_new.add(name);record=c2[name]
            truth('serialized field is the asserted quantity '+name,record['got']==row[field])
            near('new expected value agrees with independent v1 '+name,record['expected'],reference[field])
        name='serialized tensor/Ricci reciprocity '+tag;expected_new.add(name)
        with localcontext() as ctx:
            ctx.prec=120;product=Decimal(row['tensor_G_ratio'])*Decimal(row['Jordan_Ricci_coefficient_ratio'])
        near('reciprocity uses serialized fields '+tag,c2[name]['got'],product)
        near('reciprocity expected is unity '+tag,c2[name]['expected'],1)
    actual_new=set(c2)-set(c1)-{'frozen input '+r['path'] for r in inputs}
    truth('exact256 intended new control names',actual_new==expected_new and len(expected_new)==256)
    for name in sorted(expected_new):
        row=c2[name]
        if 'got' in row:
            truth('new control retains1e-60 '+name,Decimal(row['tolerance'])==TOL)
            with localcontext() as ctx:
                ctx.prec=120
                scale=max(Decimal(1),abs(Decimal(row['got'])),abs(Decimal(row['expected'])))
                err=abs(Decimal(row['got'])-Decimal(row['expected']))/Decimal(row['normalization'])
            near('new control default normalization '+name,row['normalization'],scale)
            truth('new control arithmetic predicate '+name,bool(err<=TOL)==row['passed'])
    correction=load(SNAP/'ASSERTION_COVERAGE_CORRECTION_v2.json')
    truth('correction provenance hashes and control count accurate',correction['original_source_sha256']==sha(SNAP/'check_matter_vacuum_v1.py') and correction['corrected_source_sha256']==sha(SNAP/'check_matter_vacuum_v2.py') and correction['new_controls_expected']==256)
    return section_receipts

def scientific_changes(old,new,path=''):
    if type(old)!=type(new):return [path]
    if isinstance(old,dict):
        if old.keys()!=new.keys():return [path]
        return [q for key in old for q in scientific_changes(old[key],new[key],path+'/'+key)]
    if isinstance(old,list):
        if len(old)!=len(new):return [path]
        return [q for i,(a,b) in enumerate(zip(old,new)) for q in scientific_changes(a,b,path+'/'+str(i))]
    return [] if old==new else [path]

def run_mutation(name,before,after,v2):
    folder=HERE/'mutations'/name;folder.mkdir(parents=True,exist_ok=False)
    source=(SNAP/'check_matter_vacuum_v2.py').read_text()
    if source.count(before)!=1:raise ValueError('Mutation anchor not unique: '+name)
    inputs=[];readmap=[]
    for row in load(SNAP/'evidence_v2/FREEZE.json')['inputs']:
        original=Path(row['path'])
        if original.is_relative_to(PARENT):
            rel=original.relative_to(PARENT);executed=folder/rel
            executed.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SNAP/rel,executed)
        else:executed=original
        if sha(executed)!=row['sha256']:raise ValueError('Mutant pre-mutation input mismatch')
        inputs.append(dict(path=str(executed),sha256=row['sha256']))
        readmap.append(dict(original=str(original),executed=str(executed)))
    runner=folder/'check_matter_vacuum_v2.py';mutated=source.replace(before,after,1);runner.write_text(mutated)
    for row in inputs:
        if row['path']==str(runner):row['sha256']=sha(runner)
    (folder/'SOURCE.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),mutated.splitlines(True),fromfile=str(SNAP/'check_matter_vacuum_v2.py'),tofile=str(runner))))
    evidence=folder/'evidence';evidence.mkdir()
    dump(evidence/'FREEZE.json',dict(created_at=now(),inputs=inputs,mutation=name,readmap=readmap))
    cmd=[sys.executable,str(runner),str(evidence)];start=now();clock=time.perf_counter()
    with (evidence/'stdout.txt').open('x') as out,(evidence/'stderr.txt').open('x') as err:
        proc=subprocess.run(cmd,stdout=out,stderr=err,check=False)
    run=dict(command=cmd,started_at=start,ended_at=now(),wall_seconds=time.perf_counter()-clock,returncode=proc.returncode,
             outputs=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in [evidence/'stdout.txt',evidence/'stderr.txt',evidence/'RESULTS.json'] if p.exists()],
             changed_inputs=[r for r in inputs if sha(r['path'])!=r['sha256']])
    dump(evidence/'EXECUTION.json',run)
    result=load(evidence/'RESULTS.json');failed=[r for r in result['checks'] if not r['passed']]
    truth('mutant '+name+' exit1',proc.returncode==1)
    truth('mutant '+name+' all1663 labels unique',len({r['name'] for r in result['checks']})==len(result['checks'])==1663)
    truth('mutant '+name+' source identities pass',all(r['passed'] for r in result['checks'] if r['name'].startswith('frozen input ')))
    truth('mutant '+name+' name uniqueness control passes',next(r['passed'] for r in result['checks'] if r['name']=='unique assertion names'))
    truth('mutant '+name+' all frozen inputs unchanged',not run['changed_inputs'])
    if name=='old_origin_mass_output_24_to_12':
        expected_names={'serialized calibrated canonical mass '+r['a'] for r in v2['calibration']['a_rows']}
        expected_changes={'/calibration/a_rows/'+str(i)+'/old_origin_delta_mass_squared_over_Hv2' for i in range(3)}
    else:
        expected_names={prefix+','.join(row[k] for k in ['a','nu','residual_label']) for row in v2['positive_vacua'] if row['residual_label']!='0' for prefix in ['serialized tensor-G from inverse action ','serialized tensor/Ricci reciprocity ']}
        expected_changes={'/positive_vacua/'+str(i)+'/tensor_G_ratio' for i,row in enumerate(v2['positive_vacua']) if row['residual_label']!='0'}
    truth('mutant '+name+' exact expected failed controls',{r['name'] for r in failed}==expected_names and result['checks_failed']==len(expected_names))
    truth('mutant '+name+' pass/fail totals accurate',result['checks_passed']==1663-len(expected_names))
    for r in failed:
        with localcontext() as ctx:
            ctx.prec=120
            error=abs(Decimal(r['got'])-Decimal(r['expected']))/Decimal(r['normalization'])
        truth('mutant failure is numerical at frozen tolerance '+name+' '+r['name'],Decimal(r['tolerance'])==TOL and error>TOL)
    changes=scientific_changes({k:v2[k] for k in SCIENCE},{k:result[k] for k in SCIENCE})
    truth('mutant '+name+' only intended scientific output changes',set(changes)==expected_changes)
    summary=dict(name=name,source_sha256=sha(runner),diff_sha256=sha(folder/'SOURCE.diff'),
                 author_returncode=proc.returncode,author_passed=result['checks_passed'],author_failed=result['checks_failed'],
                 failed_checks=failed,expected_failed_check_count=len(expected_names),
                 source_identity_rejections=0 if all(r['passed'] for r in result['checks'] if r['name'].startswith('frozen input ')) else 'present',
                 changed_scientific_output_paths=changes,expected_changed_field_count=len(expected_changes),
                 freeze_sha256=sha(evidence/'FREEZE.json'),execution_sha256=sha(evidence/'EXECUTION.json'),result_sha256=sha(evidence/'RESULTS.json'))
    dump(folder/'RECEIPT.json',summary)
    print(json.dumps({k:summary[k] for k in ['name','author_returncode','author_passed','author_failed','expected_changed_field_count','source_identity_rejections']}),flush=True)
    return summary

def main():
    dump(HERE/'HARNESS_FREEZE.json',dict(created_at=now(),inputs=[dict(path=str(p),sha256=sha(p)) for p in [Path(__file__),HERE/'INPUT_FREEZE.json',HERE/'PRE_EXECUTION_PLAN.json']]))
    for row in FROZEN['inputs']:
        truth('live and snapshot identity before '+row['path'],sha(row['path'])==row['sha256']==sha(row['snapshot']))
    v1=load(SNAP/'evidence_v1/RESULTS.json');v2=load(SNAP/'evidence_v2/RESULTS.json')
    prior=load(SNAP/'independent_numerical_review/independent_evidence_v1/RESULTS.json')
    truth('prior independent result identity preserved',sha(SNAP/'independent_numerical_review/independent_evidence_v1/RESULTS.json')=='3327623758e542170b91f77bbbc3488dc8a5c6ba8c578a26f2c4afa681327609')
    truth('prior independent8671/1 still retained',prior['passed']==8671 and prior['failed']==1 and load(SNAP/'independent_numerical_review/independent_evidence_v1/EXECUTION.json')['returncode']==1)
    truth('prior receipt identity preserved',sha(SNAP/'independent_numerical_review/RECEIPT_v1.json')=='50ae73b58b69cc13829539ac92b240aca3d9aa7ea8ece5e73711a21fd3c5a473')
    for name in ['old_origin_mass_output_24_to_12','tensor_G_output_inverted']:
        old=load(SNAP/'independent_numerical_review/mutations_v1'/name/'RECEIPT.json')
        truth('prior false-success retained '+name,old['author_returncode']==0 and old['author_failed']==0 and old['independent_new_failure_count']>0)
    sections=source_and_saved_output_check(v1,v2,prior)
    mutations=[run_mutation('old_origin_mass_output_24_to_12',"'old_origin_delta_mass_squared_over_Hv2':str(24*aa*RR)","'old_origin_delta_mass_squared_over_Hv2':str(12*aa*RR)",v2),
               run_mutation('tensor_G_output_inverted',"'tensor_G_ratio':str(av*av)","'tensor_G_ratio':str(1/(av*av))",v2)]
    for row in FROZEN['inputs']:
        truth('live and snapshot identity after '+row['path'],sha(row['path'])==row['sha256']==sha(row['snapshot']))
    result=dict(created_at=now(),scope='Affected v2 correction only; no full positive numerical recomputation or unrelated rerun.',
                scientific_sections=sections,mutations=mutations,checks=CHECKS,
                passed=sum(r['passed'] for r in CHECKS),failed=sum(not r['passed'] for r in CHECKS),
                failed_checks=[r for r in CHECKS if not r['passed']],
                source_sha256=sha(SNAP/'check_matter_vacuum_v2.py'),parent_result_sha256=sha(SNAP/'evidence_v2/RESULTS.json'),
                independent_reference_sha256=sha(SNAP/'independent_numerical_review/independent_evidence_v1/RESULTS.json'),
                harness_sha256=sha(__file__),plan_sha256=sha(HERE/'PRE_EXECUTION_PLAN.json'),input_freeze_sha256=sha(HERE/'INPUT_FREEZE.json'),
                empirical_tests=0,formal_audit=False,publication_gate=False)
    dump(HERE/'RESULTS.json',result)
    print(json.dumps({k:result[k] for k in ['passed','failed','failed_checks','source_sha256','parent_result_sha256']}),flush=True)
    return int(bool(result['failed']))

if __name__=='__main__':
    started=now();clock=time.perf_counter();code=2
    with (HERE/'stdout.txt').open('x') as out,(HERE/'stderr.txt').open('x') as err,contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        try:code=main()
        except BaseException:traceback.print_exc()
    dump(HERE/'EXECUTION.json',dict(command=[sys.executable,str(Path(__file__).resolve())],started_at=started,ended_at=now(),
                                  wall_seconds=time.perf_counter()-clock,returncode=code,
                                  outputs=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in [HERE/'stdout.txt',HERE/'stderr.txt',HERE/'RESULTS.json'] if p.exists()]))
    print((HERE/'stdout.txt').read_text());print((HERE/'stderr.txt').read_text(),file=sys.stderr)
    sys.exit(code)
