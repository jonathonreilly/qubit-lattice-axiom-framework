#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def info(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def dump(p,obj):
    with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def main():
    inputs=load(HERE/'INPUT_FREEZE.json')['inputs']
    final=[r|{'final_source_sha256':sha(r['path']),'final_snapshot_sha256':sha(r['snapshot']),
              'unchanged':sha(r['path'])==r['sha256']==sha(r['snapshot'])} for r in inputs]
    dump(HERE/'FINAL_INPUT_CHECK.json',dict(created_at=datetime.now(timezone.utc).isoformat(),inputs=final,changed=[r for r in final if not r['unchanged']]))
    result=load(HERE/'RESULTS.json');execution=load(HERE/'EXECUTION.json')
    harness=load(HERE/'HARNESS_FREEZE.json')['inputs']
    manifest=[info(p)|{'relative_path':str(p.relative_to(HERE))} for p in sorted(HERE.rglob('*')) if p.is_file() and p.name not in {'RECEIPT.json','RECEIPT.sha256'}]
    # Include nested mutant receipts, excluding only the to-be-written root receipt.
    for p in sorted((HERE/'mutations').rglob('RECEIPT.json')):
        manifest.append(info(p)|{'relative_path':str(p.relative_to(HERE))})
    receipt=dict(version=1,created_at=datetime.now(timezone.utc).isoformat(),reviewer='/root/launch_check',parent_author='/root',
                 scope='Affected v2 source equivalence, output-assertion coverage, and exactly two prior surviving source mutations.',
                 source_sha256=result['source_sha256'],parent_result_sha256=result['parent_result_sha256'],
                 independent_reference_sha256=result['independent_reference_sha256'],
                 historical_review_receipt_sha256='50ae73b58b69cc13829539ac92b240aca3d9aa7ea8ece5e73711a21fd3c5a473',
                 historical_disposition_retained='Independent v1 8671/1 rc1; two v1 author false-success mutants preserved.',
                 affected_disposition='THREE_TARGETED_FINDINGS_CLOSED_FOR_EXACT_V2_SOURCE',
                 affected_review=dict(passed=result['passed'],failed=result['failed'],returncode=execution['returncode'],result=info(HERE/'RESULTS.json'),execution=info(HERE/'EXECUTION.json')),
                 scientific_sections=result['scientific_sections'],
                 mutations=[{k:r[k] for k in ['name','source_sha256','diff_sha256','author_returncode','author_passed','author_failed','expected_failed_check_count','source_identity_rejections','expected_changed_field_count','freeze_sha256','execution_sha256','result_sha256']} for r in result['mutations']],
                 original_and_snapshot_inputs=final,all32_inputs_unchanged=all(r['unchanged'] for r in final),
                 harness_inputs_changed=[r for r in harness if sha(r['path'])!=r['sha256']],
                 report=info(HERE/'REPORT.md'),evidence_manifest=manifest,
                 full_positive_recomputation_performed=False,other_mutations_executed=False,
                 empirical_tests=0,formal_audit=False,publication_gate=False)
    dump(HERE/'RECEIPT.json',receipt)
    with (HERE/'RECEIPT.sha256').open('x') as f:f.write(sha(HERE/'RECEIPT.json')+'  RECEIPT.json\n')
    print(json.dumps(dict(receipt_sha256=sha(HERE/'RECEIPT.json'),report_sha256=sha(HERE/'REPORT.md'),manifest_files=len(manifest),inputs_unchanged=receipt['all32_inputs_unchanged'],harness_inputs_changed=receipt['harness_inputs_changed']),indent=2))
if __name__=='__main__':main()
