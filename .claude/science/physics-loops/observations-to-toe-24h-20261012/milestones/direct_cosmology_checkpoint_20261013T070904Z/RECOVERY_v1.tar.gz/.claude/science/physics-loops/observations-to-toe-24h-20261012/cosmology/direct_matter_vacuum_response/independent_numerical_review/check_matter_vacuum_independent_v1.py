#!/usr/bin/env python3
"""Independent numerical review. Never imports or executes an author helper.

The author RESULTS file is a comparison subject only. Physical assumptions and
specified renormalization convention are shared; this is not an experiment.
All writes are exclusive and confined to the assigned review directory.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
from itertools import product
import json, hashlib, gzip, re, sys, platform
import mpmath as mp

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot' / 'direct_matter_vacuum_response'
mp.mp.dps = 120
TOL = mp.mpf('1e-60')
ROOT_TOL = mp.mpf('1e-55')
CHECKS = []

def number(x):
    words = str(x).split('/')
    return mp.mpf(words[0]) if len(words) == 1 else mp.mpf(words[0])/mp.mpf(words[1])

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
def load(p): return json.loads(Path(p).read_text())
def truth(name, condition, detail=None):
    CHECKS.append(dict(name=name, passed=bool(condition), detail=detail))
def near(name, value, reference, tolerance=TOL, normalization=None):
    v, r = number(value), number(reference)
    scale = max(mp.mpf(1), abs(v), abs(r)) if normalization is None else number(normalization)
    error = abs(v-r)/scale
    CHECKS.append(dict(name=name, passed=bool(mp.isfinite(error) and error <= tolerance),
                       subject=str(v), independent=str(r), normalization=str(scale),
                       normalized_error=str(error), tolerance=str(tolerance)))

INPUT = load(SNAP / 'INPUTS_v1.json')
NIST = load(SNAP / 'NIST_SELECTED_ROWS_v1.json')

def lineage(subject, subject_freeze):
    frozen = load(HERE / 'INPUT_FREEZE_v1.json')
    for row in frozen['inputs']:
        truth('review snapshot identity: '+row['path'], sha(row['snapshot']) == row['sha256'])
        truth('live reviewed input unchanged: '+row['path'], sha(row['path']) == row['sha256'])
    before = load(subject_freeze)
    expected = [(r['path'], r['sha256']) for r in before['inputs']]
    reported = [(r['path'], r['sha256']) for r in subject['source_hashes']]
    truth('subject input-list identity', reported == expected)
    for path, digest in expected:
        truth('subject exact input identity: '+path, sha(path) == digest)
    raw = gzip.decompress((SNAP / 'primary_recovery/NIST_CODATA_2022.txt.gz').read_bytes())
    truth('recovered NIST equals external original', raw == (HERE/'source_snapshot/external_primary/NIST_CODATA_2022.txt').read_bytes())
    truth('full NIST table digest', hashlib.sha256(raw).hexdigest() == NIST['table_sha256'])
    lines = raw.decode().splitlines(keepends=True)
    for name, row in NIST['selected_rows'].items():
        raw_line = lines[row['line_number']-1]
        truth('NIST source line: '+name, raw_line == row['raw_line'])
        cells = re.split(r'\s{2,}', raw_line.strip())
        truth('NIST parsed name/value/uncertainty/unit: '+name,
              cells == [name, cells[1], cells[2], row['unit']]
              and cells[1].replace(' ', '') == row['value']
              and cells[2].replace(' ', '') == row['uncertainty'])
    radfile = HERE/'source_snapshot/direct_radiation_closure/evidence_v1/RESULTS.json'
    fixture = HERE/'source_snapshot/direct_radiation_closure/NUMERICAL_FIXTURES_v1.json'
    truth('inherited radiation RESULT identity', sha(radfile) == INPUT['radiation_result']['sha256'])
    truth('inherited radiation fixture identity', sha(fixture) == INPUT['radiation_fixture']['sha256'])
    near('inherited photon exact exposed value', INPUT['Omega_gamma'], str(load(radfile)['thermal']['thermal_rows'][1]['Omega_gamma']))
    return {'reviewed_inputs': len(frozen['inputs']), 'subject_inputs': len(expected),
            'calibrations_are_exposed_inputs': True,
            'Burgess_read_scope': 'Ledger/version and recovered PDF identity only in this numerical review. No new full-paper or independent derivation claim.'}

def check_existing_records(subject):
    rows = subject['checks']
    names = [r['name'] for r in rows]
    truth('subject check count fixed at 1406', len(rows) == 1406)
    truth('subject check names unique', len(names) == len(set(names)))
    truth('subject declared pass count accurate', subject['checks_passed'] == sum(r['passed'] for r in rows))
    truth('subject declared fail count accurate', subject['checks_failed'] == sum(not r['passed'] for r in rows))
    kinds = Counter()
    for r in rows:
        truth('subject declared check passes: '+r['name'], r['passed'])
        if 'got' in r:
            kinds['numeric'] += 1
            tol = number(r['tolerance'])
            expected_tol = mp.mpf('5e-25') if r['name'] == 'CODATA mass-energy rounding only' else ROOT_TOL if r['name'].startswith('W versus monotone bisection ') else TOL
            truth('frozen tolerance: '+r['name'], tol == expected_tol)
            err = abs(number(r['got'])-number(r['expected']))/number(r['normalization'])
            truth('recomputed subject predicate: '+r['name'], bool(err <= tol) == bool(r['passed']))
            near('stored normalized error: '+r['name'], r['normalized_error'], err)
        elif 'symbolic_remainder' in r:
            kinds['symbolic'] += 1
            truth('stored symbolic zero: '+r['name'], r['symbolic_remainder'] == '0')
        else:
            kinds['boolean'] += 1
    return dict(kinds)

def independent_calibration(subject):
    c = number(NIST['selected_rows']['speed of light in vacuum']['value'])
    h = number(NIST['selected_rows']['Planck constant']['value'])
    mass = number(NIST['selected_rows']['electron mass']['value'])
    dm = number(NIST['selected_rows']['electron mass']['uncertainty'])
    G = number(NIST['selected_rows']['Newtonian constant of gravitation']['value'])
    dG = number(NIST['selected_rows']['Newtonian constant of gravitation']['uncertainty'])
    hb = h/(2*mp.pi)
    H0 = number(INPUT['H0_km_per_s_Mpc'])*1000/number(INPUT['Mpc_m'])
    omega, matter = number(INPUT['Omega_gamma']), number(INPUT['matter_fraction'])
    Hv = H0*mp.sqrt(1-matter-omega)
    # Ordinary Compton wavelength: (3*pi/4)*(rest energy)/(lambda_C^3).
    # The factors of 2*pi follow from lambda_C=h/(m*c), without natural-unit
    # energy-density conversion or the author's hbar*c denominator.
    def density(mm): return (3*mp.pi/4)*(mm*c*c)/(h/(mm*c))**3
    rho = density(mass)
    exp = {'hbar_Js': hb, 'H0_s_inverse': H0, 'Hv_s_inverse': Hv,
           'electron_energy_J': mass*c*c, 'rho_electron_loop_J_per_m3': rho,
           'electron_mass_relative_sigma': dm/mass,
           'loop_mass_relative_linear_sigma': 4*dm/mass}
    for key, value in exp.items(): near('calibration '+key, subject[key], value)
    near('independent CODATA energy rounding', mass*c*c,
         NIST['selected_rows']['electron mass energy equivalent']['value'],
         tolerance=mp.mpf('5e-25'), normalization=1)
    truth('mass endpoint labels complete', [r['sigma_shift'] for r in subject['loop_mass_endpoints']] == [-1, 1])
    for row in subject['loop_mass_endpoints']:
        near('mass endpoint '+str(row['sigma_shift']), row['rho_J_per_m3'], density(mass+row['sigma_shift']*dm))
    truth('a calibration rows complete', [r['a'] for r in subject['a_rows']] == INPUT['a_values'])
    rows, ratios = [], {}
    for row in subject['a_rows']:
        a = number(row['a'])
        # Critical MASS density times supplied fraction, c^2 and the imported
        # weak-field bridge. Planck energy checked through gravitational time.
        critical_mass = 3*H0**2/(8*mp.pi*G)
        target = critical_mass*(1-matter-omega)*c*c*(1+a)
        grav_time = mp.sqrt(hb*G/c**5)
        ME2 = (1+a)*hb**2/(8*mp.pi*grav_time**2)
        R = rho/target
        ratios[row['a']] = R
        # Physical perturbation U(q)=rho*exp(2*sqrt(2*a)*q/ME),
        # evaluated at q=0, then divided by (hbar*Hv)^2.
        rho_energy4 = rho*(hb*c)**3
        U = lambda q: rho_energy4*mp.exp(2*mp.sqrt(2*a)*q/mp.sqrt(ME2))
        oldmass = mp.diff(U, mp.mpf(0), 2)/(hb*Hv)**2
        expect = dict(M_E_energy_squared_J2=ME2, rho_target_J_per_m3=target,
                      R_electron_mu_equals_m=R, old_origin_delta_mass_squared_over_Hv2=oldmass)
        for key, value in expect.items(): near('calibration a='+row['a']+' '+key, row[key], value)
        truth('G endpoint labels '+row['a'], [r['sigma_shift'] for r in row['G_uncertainty_endpoints']] == [-1,1])
        grows = []
        for gr in row['G_uncertainty_endpoints']:
            gg = G + gr['sigma_shift']*dG
            # Keep photon mass density fixed while critical mass changes.
            critical_shifted = 3*H0**2/(8*mp.pi*gg)
            photon_mass = omega*critical_mass
            om = photon_mass/critical_shifted
            target_g = (1+a)*c*c*(critical_shifted*(1-matter)-photon_mass)
            ge = dict(G_N=gg, Omega_gamma_correlated=om, R=rho/target_g)
            for key,value in ge.items(): near('G endpoint a='+row['a']+',sign='+str(gr['sigma_shift'])+' '+key, gr[key], value)
            grows.append({key: str(value) for key,value in ge.items()} | {'sigma_shift':gr['sigma_shift']})
        rows.append({'a':row['a']} | {key:str(value) for key,value in expect.items()} | {'G_uncertainty_endpoints':grows})
    return ({key:str(value) for key,value in exp.items()} |
            {'ordinary_Compton_wavelength_m':str(h/(mass*c)), 'a_rows':rows,
             'unit_path':'rest energy / ordinary Compton volume; critical mass density * c^2; gravitational time to Planck energy',
             'electron_energy_rounding_difference_J':str(mass*c*c-number(NIST['selected_rows']['electron mass energy equivalent']['value']))}), ratios

def zeta_loop(mass, mu):
    # Spectral-zeta representation with the specified finite convention.
    # The Dirac sign/multiplicity is +2*zeta'(0); local counterterm remains free.
    zeta = lambda z: mass**4*mp.exp(2*z*mp.log(mu/mass))/(16*mp.pi**2*(z-1)*(z-2))
    return 2*mp.diff(zeta, mp.mpf(0))

def independent_scheme(subject, records):
    expected_keys = list(product(INPUT['a_values'], INPUT['u_values'], INPUT['log_mu_over_m']))
    keys = [(r['a'],r['u'],r['log_mu_over_m']) for r in subject]
    truth('all 60 scheme rows complete and ordered', keys == expected_keys)
    mass, ref = mp.mpf('1.7'), mp.mpf('.002')
    by_name = {r['name']:r for r in records}
    rows, derivatives = [], []
    for r in subject:
        a, u, ell = number(r['a']), number(r['u']), number(r['log_mu_over_m'])
        A = mp.exp(mp.sqrt(a)*u); mu = mass*mp.exp(ell)
        j = zeta_loop(mass, mu)
        matched = zeta_loop(A*mass, A*mu)
        fixed = zeta_loop(A*mass, mu)
        matching = matched-fixed
        # Running counterterm from integral of scale derivative, not the
        # author's closed beta subtraction. Finite reference value is supplied.
        running = mp.quadgl(lambda t: mp.diff(lambda s: zeta_loop(mass,mass*mp.exp(s)), t), [0,ell]) if ell else mp.mpf(0)
        ct = ref-zeta_loop(mass,mass)-running
        exp = dict(loop_J=j,matched_E=matched,fixed_E=fixed,finite_matching_term=matching,total_J=j+ct)
        tag = ','.join((r['a'],r['u'],r['log_mu_over_m']))
        for key,value in exp.items(): near('scheme '+tag+' '+key, r[key], value)
        near('independent pulled-back volume '+tag, matched, A**4*j)
        rows.append({k:r[k] for k in ['a','u','log_mu_over_m']} | {k:str(v) for k,v in exp.items()})
    # Cauchy coefficient extraction, unlike symbolic/real mp.diff derivatives
    # used by the subject. Radius=1; n<=6; 128 nodes; largest exponent=.4.
    count = 128
    roots = [mp.exp(2j*mp.pi*j/count) for j in range(count)]
    for a0,u0 in product(INPUT['a_values'],INPUT['u_values']):
        a,u = number(a0),number(u0); k=4*mp.sqrt(a); C=mp.mpf('2.3')
        values = [C*mp.exp(k*(u+z)) for z in roots]
        for n in range(7):
            contour = mp.factorial(n)*mp.fsum(value*z**(-n) for value,z in zip(values,roots))/count
            tag=a0+','+u0+',n='+str(n)
            near('Cauchy imaginary roundoff '+tag, contour.imag, 0)
            for label in ['numeric operator derivative ', 'whole-operator cancellation ']+(['constant-only subtraction derivative '] if n in [1,2] else []):
                reference=0 if label.startswith('whole-') else contour.real
                record=by_name[label+tag]
                near('independent '+label+tag+' actual',record['got'],reference)
                near('independent '+label+tag+' expected',record['expected'],reference)
            derivatives.append(dict(a=a0,u=u0,order=n,cauchy_real=str(contour.real),cauchy_imaginary=str(contour.imag)))
    zero=zeta_loop(mass,mass*mp.exp(-mp.mpf(3)/4))
    beta=mp.diff(lambda ell:zeta_loop(mass,mass*mp.exp(ell)),-mp.mpf(3)/4)
    near('zero finite scheme by spectral derivative',zero,0)
    truth('nonzero running at zero finite scheme', beta>0)
    return dict(rows=rows,operator_derivatives=derivatives,zero_scheme_beta=str(beta),
                cauchy_nodes=count,cauchy_radius='1',
                shared_convention='Free Dirac finite subtraction normalized to stated MS-bar scheme; not an independently selected renormalization prescription.')

def newton_canonical(a,nu,R):
    if R==0:return mp.mpf(0),0,mp.mpf(0)
    b=2*mp.sqrt(2*a); K=3*R*b/nu
    # z=-q0>0 solves log(z)+b*z=log(K). Start below its unique root.
    # The increasing concave function gives positive, monotone Newton iterates.
    z=K/(1+b*K)
    for iteration in range(1,1001):
        residual=mp.log(z)+b*z-mp.log(K)
        next_z=z-residual/(1/z+b)
        if next_z<=0:raise ArithmeticError('canonical Newton left positive domain')
        if abs(next_z-z)<=mp.mpf('1e-110')*max(1,abs(next_z)):
            z=next_z;break
        z=next_z
    else:raise ArithmeticError('canonical Newton did not converge')
    return -z,iteration,mp.log(z)+b*z-mp.log(K)

def independent_vacua(subject,ratios,records):
    keys=[(r['a'],r['nu'],r['residual_label']) for r in subject]
    truth('all 84 vacuum rows complete and ordered', keys==list(product(INPUT['a_values'],INPUT['nu_values'],INPUT['residual_ratios'])))
    by_name={r['name']:r for r in records}
    ans=[]
    for row in subject:
        a,nu=number(row['a']),number(row['nu']); alpha=mp.sqrt(a)
        R=ratios[row['a']] if row['residual_label'].startswith('electron') else number(row['residual_label'])
        q0,iterations,residual=newton_canonical(a,nu,R)
        # ME=Hv=1. These linear coordinates are canonical at x=y=0.
        # The Hessian is of the FULL physical U=2V at the stationary point.
        # Away from it the x/y kinetic metric need not be globally canonical.
        def U(q,r,s):
            u=q/mp.sqrt(2); x=3*r/mp.sqrt(8*a); y=s*mp.sqrt(3/(2*a))
            return 3+2*(a/2-alpha*u+2*u*u)*x*x+2*a*y*y/3+nu*u*u+3*R*mp.exp(4*alpha*u)
        point=(q0,mp.mpf(0),mp.mpf(0))
        hessian=[]
        for i in range(3):
            hr=[]
            for j in range(3):
                orders=[0,0,0];orders[i]+=1;orders[j]+=1
                hr.append(mp.diff(U,point,tuple(orders)))
            hessian.append(hr)
        masses=[hessian[i][i] for i in range(3)]
        uv=q0/mp.sqrt(2); A=mp.exp(alpha*uv); V=U(*point)/2
        HE=mp.sqrt(U(*point)/3); HJ=HE/A
        w=-2*mp.sqrt(2*a)*q0
        # Constant-Weyl Jordan tensor coefficient from A^-4 volume and A^2
        # Ricci conversion. Newton coupling is its inverse, not same scaling.
        ricci=A**(-4)*A**2; tensor=1/ricci
        expected=dict(R=R,w=w,u_v=uv,A_v=A,V_min_over_Hv2=V,H_E_over_Hv=HE,H_J_over_Hv=HJ,
                      tensor_G_ratio=tensor,Jordan_Ricci_coefficient_ratio=ricci)
        tag=','.join((row['a'],row['nu'],row['residual_label']))
        for key,value in expected.items():near('vacuum '+tag+' '+key,row[key],value,ROOT_TOL if key=='w' else TOL)
        for i,value in enumerate(masses):near('vacuum '+tag+' canonical mass '+str(i),row['mass_squared_over_Hv2'][i],value)
        # At a stationary point the connection term in the covariant Hessian
        # vanishes. Explicitly verify all first and mixed derivatives here.
        for i in range(3):
            order=[0,0,0];order[i]=1
            near('independent stationary canonical force '+tag+','+str(i),mp.diff(U,point,tuple(order)),0,
                 normalization=max(1,nu*abs(uv)))
            for j in range(i+1,3):near('independent canonical mixed Hessian '+tag+','+str(i)+str(j),hessian[i][j],0)
        near('independent log stationarity residual '+tag,residual,0,ROOT_TOL)
        truth('independent positive Hessian and potential floor '+tag,all(v>0 for v in masses) and V>=mp.mpf('1.5'))
        for delta in [-1,1]:
            shifted_q=q0+mp.sqrt(2)*delta/alpha
            slope=mp.diff(lambda q:U(q,0,0),shifted_q)
            truth('independent minimum side '+tag+','+str(delta),U(shifted_q,0,0)>U(*point) and delta*slope>0)
        # Compare the subject force and mass/value controls to this route too.
        for label,value in [('vacuum value ',V),('vacuum u mass ',masses[0]),('vacuum x mass ',masses[1]),('vacuum y mass ',masses[2]),('vacuum Hubble ',HE**2),('vacuum A ',A)]:
            for field in ['got','expected']:near('independent '+label+tag+' '+field,by_name[label+tag][field],value)
        ans.append({k:row[k] for k in ['a','nu','residual_label']} |
                   {k:str(v) for k,v in expected.items()} |
                   {'mass_squared_over_Hv2':[str(v) for v in masses],
                    'canonical_hessian':[[str(v) for v in hr] for hr in hessian],
                    'canonical_q0':str(q0),'Newton_iterations':iterations,'log_residual':str(residual)})
    return ans

def independent_curvature(subject):
    H=mp.mpf('.7')
    s=lambda t:mp.mpf('.1')*t*t-mp.mpf('.03')*t*t*t
    A=lambda t:mp.exp(s(t)); aE=lambda t:mp.exp(H*t)
    aJ=lambda t:A(t)*aE(t)
    # Derive H_J and R_J directly using d/dt_J=A^-1 d/dt_E.
    HJ=lambda t:mp.diff(aJ,t)/(A(t)*aJ(t))
    RJ=lambda t:6*(mp.diff(HJ,t)/A(t)+2*HJ(t)**2)
    pulled=lambda t:A(t)**4*aE(t)**3*RJ(t)/2
    integrated=lambda t:A(t)**2*aE(t)**3*(6*H**2-3*mp.diff(s,t)**2)
    value=mp.quadgl(lambda t:pulled(t)-integrated(t),[0,1])
    boundary=lambda t:3*A(t)**2*aE(t)**3*mp.diff(s,t)
    surface=boundary(1)-boundary(0)
    near('independent direct Jordan curvature boundary',value,surface)
    near('subject curvature original minus bulk',subject['original_minus_integrated_bulk'],value)
    near('subject curvature surface',subject['surface_term'],surface)
    return dict(direct_Jordan_integral=str(value),boundary=str(surface),
                scope='Explicit dimensionless zeta=1 check only. No numerical electron-induced zeta or full derivative effective action solved.')

def main():
    subject_path=Path(sys.argv[1]) if len(sys.argv)>1 else SNAP/'evidence_v1/RESULTS.json'
    output_path=Path(sys.argv[2]) if len(sys.argv)>2 else HERE/'independent_evidence_v1/RESULTS.json'
    subject_freeze=Path(sys.argv[3]) if len(sys.argv)>3 else subject_path.with_name('FREEZE.json')
    if not output_path.resolve().is_relative_to(HERE):raise ValueError('write outside assigned review folder')
    if output_path.exists():raise FileExistsError(output_path)
    subject=load(subject_path)
    answer=dict(started_at=stamp(),precision_decimal_digits=mp.mp.dps,
                checker_sha256=sha(__file__),subject_path=str(subject_path.resolve()),subject_sha256=sha(subject_path),
                subject_freeze_path=str(subject_freeze.resolve()),subject_freeze_sha256=sha(subject_freeze),
                pre_execution_plan_sha256=sha(HERE/'PRE_EXECUTION_PLAN_v1.json'),
                review_input_freeze_sha256=sha(HERE/'INPUT_FREEZE_v1.json'))
    answer['lineage']=lineage(subject,subject_freeze)
    answer['subject_check_types']=check_existing_records(subject)
    answer['calibration'],ratios=independent_calibration(subject['calibration'])
    answer['scheme_operator']=independent_scheme(subject['scheme_operator'],subject['checks'])
    answer['positive_vacua']=independent_vacua(subject['positive_vacua'],ratios,subject['checks'])
    answer['curvature']=independent_curvature(subject['curvature'])
    answer['checks']=CHECKS
    answer['passed']=sum(r['passed'] for r in CHECKS)
    answer['failed']=sum(not r['passed'] for r in CHECKS)
    answer['failed_checks']=[r for r in CHECKS if not r['passed']]
    answer['scope']='Focused independent implementation/output/calibration review; shared supplied theory and subtraction convention; no formal audit, publication gate or independent experimental tests.'
    answer['versions']=dict(python=sys.version,mpmath=mp.__version__,platform=platform.platform())
    answer['ended_at']=stamp()
    output_path.parent.mkdir(parents=True,exist_ok=True)
    with output_path.open('x') as f:json.dump(answer,f,indent=2);f.write('\n')
    print(json.dumps(dict(passed=answer['passed'],failed=answer['failed'],
                         failed_checks=answer['failed_checks'],result=str(output_path)),indent=2))
    return bool(answer['failed'])

if __name__=='__main__':sys.exit(main())
