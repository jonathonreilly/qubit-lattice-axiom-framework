#!/usr/bin/env python3
"""Bind source identities, failed first run, mutations, and report without edits."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,data):
    with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def identity(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)

def main():
    inputs=load(HERE/'INPUT_FREEZE_v1.json')
    final_inputs=[]
    for row in inputs['inputs']:
        final_inputs.append(row | {'final_live_sha256':sha(row['path']),
                                  'final_snapshot_sha256':sha(row['snapshot']),
                                  'unchanged':sha(row['path'])==row['sha256']==sha(row['snapshot'])})
    final_check=dict(created_at=datetime.now(timezone.utc).isoformat(),
                     checked_inputs=len(final_inputs),changed_inputs=[r for r in final_inputs if not r['unchanged']],inputs=final_inputs)
    dump(HERE/'FINAL_INPUT_CHECK_v1.json',final_check)
    baseline=load(HERE/'independent_evidence_v1/RESULTS.json')
    execution=load(HERE/'independent_evidence_v1/EXECUTION.json')
    mutations=load(HERE/'mutations_v1/RESULTS.json')
    source_dir=HERE/'source_snapshot/direct_matter_vacuum_response'
    manifest=[identity(p) | {'relative_path':str(p.relative_to(HERE))} for p in sorted(HERE.rglob('*')) if p.is_file() and p.name not in {'RECEIPT_v1.json','RECEIPT_v1.sha256'}]
    receipt=dict(version=1,created_at=datetime.now(timezone.utc).isoformat(),reviewer='/root/launch_check',parent_author='/root',
                 scope='Independent implementation/output/calibration check only. Not formal audit, mathematical proof verdict, or publication gate.',
                 disposition='NUMERIC_AGREEMENT_WITH_RETAINED_METADATA_FAILURE_AND_TWO_SUBJECT_ASSERTION_GAPS',
                 source_dir=str(HERE.parent),allowed_write_dir=str(HERE),
                 reviewed_source=identity(source_dir/'check_matter_vacuum_v1.py'),
                 reviewed_derivation=identity(source_dir/'HAND_DERIVATION_v2.md'),
                 reviewed_scope_correction=identity(source_dir/'TENSOR_AND_ACTION_SCOPE_CORRECTION_v2.json'),
                 parent_execution=identity(source_dir/'evidence_v1/EXECUTION.json'),
                 parent_result=identity(source_dir/'evidence_v1/RESULTS.json'),
                 original_source_and_input_identities=final_inputs,
                 first_independent_execution=dict(returncode=execution['returncode'],passed=baseline['passed'],failed=baseline['failed'],
                                                  failed_checks=baseline['failed_checks'],
                                                  numerical_comparison_records=sum('normalized_error' in c for c in baseline['checks']),
                                                  result=identity(HERE/'independent_evidence_v1/RESULTS.json'),
                                                  execution=identity(HERE/'independent_evidence_v1/EXECUTION.json'),
                                                  checker=identity(HERE/'check_matter_vacuum_independent_v1.py')),
                 actual_mutations=[{k:m[k] for k in ['name','source_sha256','diff_sha256','author_returncode','author_passed','author_failed',
                                                   'independent_returncode','independent_passed','independent_failed','independent_new_failure_count',
                                                   'independent_numerically_detected','frozen_mutant_inputs_changed',
                                                   'author_result_sha256','independent_result_sha256']} for m in mutations['mutations']],
                 mutation_harness_frozen_inputs_changed=mutations['frozen_harness_inputs_changed'],
                 parent_inputs_unchanged=len(final_check['changed_inputs'])==0,
                 report=identity(HERE/'REPORT_v1.md'),
                 empirical_test_count=0,
                 independent_route_limits=['Specified theory, quantization prescription, subtraction convention and measured inputs are shared assumptions.',
                                           'No author helper imports or positive-oracle execution; author code executed only as mutation subject.',
                                           'The 27 stored symbolic zero records are inspected, not all independently proved by this numerical review.',
                                           'No global homogeneous proof replacement, history selection, inhomogeneous stability, full derivative action or quantum completion claim.'],
                 evidence_manifest=manifest)
    dump(HERE/'RECEIPT_v1.json',receipt)
    with (HERE/'RECEIPT_v1.sha256').open('x') as f:f.write(sha(HERE/'RECEIPT_v1.json')+'  RECEIPT_v1.json\n')
    print(json.dumps(dict(receipt=str(HERE/'RECEIPT_v1.json'),receipt_sha256=sha(HERE/'RECEIPT_v1.json'),
                         report_sha256=sha(HERE/'REPORT_v1.md'),evidence_files=len(manifest),
                         unchanged_inputs=len(final_inputs)-len(final_check['changed_inputs']),changed_inputs=len(final_check['changed_inputs'])),indent=2))

if __name__=='__main__':main()
