#!/usr/bin/env python3
"""Preserve the first independent execution, including any genuine failure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, time

HERE=Path(__file__).resolve().parent
OUT=HERE/'independent_evidence_v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def dump(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')

def main():
    OUT.mkdir(exist_ok=False)
    frozen=[]
    for path in [Path(__file__),HERE/'check_matter_vacuum_independent_v1.py',HERE/'INPUT_FREEZE_v1.json',HERE/'PRE_EXECUTION_PLAN_v1.json']:
        frozen.append({'path':str(path),'sha256':sha(path)})
    dump(OUT/'FREEZE.json',{'created_at':now(),'inputs':frozen})
    cmd=[sys.executable,str(HERE/'check_matter_vacuum_independent_v1.py')]
    start=now(); clock=time.perf_counter()
    with (OUT/'stdout.txt').open('x') as out,(OUT/'stderr.txt').open('x') as err:
        result=subprocess.run(cmd,stdout=out,stderr=err,check=False)
    elapsed=time.perf_counter()-clock
    dump(OUT/'EXECUTION.json',{'command':cmd,'started_at':start,'ended_at':now(),'wall_seconds':elapsed,'returncode':result.returncode,
                             'frozen_inputs_changed':[r for r in frozen if sha(r['path'])!=r['sha256']],
                             'outputs':[{ 'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in [OUT/'stdout.txt',OUT/'stderr.txt',OUT/'RESULTS.json'] if p.exists()]})
    print((OUT/'stdout.txt').read_text());print((OUT/'stderr.txt').read_text(),file=sys.stderr)
    return result.returncode
if __name__=='__main__':sys.exit(main())
