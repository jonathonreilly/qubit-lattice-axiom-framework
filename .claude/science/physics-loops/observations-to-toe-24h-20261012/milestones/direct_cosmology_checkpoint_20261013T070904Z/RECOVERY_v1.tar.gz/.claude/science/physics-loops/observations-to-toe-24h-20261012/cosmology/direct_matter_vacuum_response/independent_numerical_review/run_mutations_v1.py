#!/usr/bin/env python3
"""Actual source mutations, each executed in its own exclusive directory.

Author code is a mutation-test subject, never a positive independent oracle.
Every mutant is frozen to its own new source hash so input-identity failures
cannot masquerade as numerical sensitivity. The original baseline failure
(duplicate basename display labels) remains visible in each independent run.
"""
from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, shutil, subprocess, sys, time

HERE=Path(__file__).resolve().parent
SNAP=HERE/'source_snapshot/direct_matter_vacuum_response'
SOURCE=SNAP/'check_matter_vacuum_v1.py'
FREEZE=json.loads((SNAP/'evidence_v1/FREEZE.json').read_text())
ORIGINAL=Path(FREEZE['inputs'][0]['path']).parent
MUTATIONS=[
    ('operator_exponent_4_to_2', 'actual=mp.diff(lambda zz:C*mp.exp(4*alpha*zz),uu,n)',
     'actual=mp.diff(lambda zz:C*mp.exp(2*alpha*zz),uu,n)', 'Actual numerical covariant operator exponent halved.'),
    ('old_origin_mass_output_24_to_12', "'old_origin_delta_mass_squared_over_Hv2':str(24*aa*RR)",
     "'old_origin_delta_mass_squared_over_Hv2':str(12*aa*RR)", 'Stored calibrated canonical old-origin mass coefficient halved.'),
    ('canonical_sqrt2_omitted', 'Uphys=2*ME**2*C*sp.exp(4*sp.sqrt(a)*phi/(sp.sqrt(2)*ME))',
     'Uphys=2*ME**2*C*sp.exp(4*sp.sqrt(a)*phi/ME)', 'Physical scalar potential uses a noncanonical field normalization.'),
    ('matched_scale_omitted', 'matched=loop(A*mm,A*mu);pulled=A**4*loop(mm,mu)',
     'matched=loop(A*mm,mu);pulled=A**4*loop(mm,mu)', 'Einstein renormalization scale left numerically fixed during frame match.'),
    ('displaced_x_mass_at_origin', 'mx=mp.diff(lambda x:pot(uv,x,0),0,2)/(4*aa/9)',
     'mx=mp.diff(lambda x:pot(0,x,0),0,2)/(4*aa/9)', 'Displaced x Hessian evaluated at the old origin.'),
    ('tensor_G_output_inverted', "'tensor_G_ratio':str(av*av)",
     "'tensor_G_ratio':str(1/(av*av))", 'Inverse tensor G field mistakenly stores the Jordan Ricci coefficient scaling.')
]
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def run(cmd,directory):
    started=now(); clock=time.perf_counter()
    with (directory/'stdout.txt').open('x') as out,(directory/'stderr.txt').open('x') as err:
        proc=subprocess.run(cmd,stdout=out,stderr=err,check=False)
    record=dict(command=cmd,started_at=started,ended_at=now(),wall_seconds=time.perf_counter()-clock,returncode=proc.returncode)
    record['outputs']=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in [directory/'stdout.txt',directory/'stderr.txt',directory/'RESULTS.json'] if p.exists()]
    dump(directory/'EXECUTION.json',record)
    return record

def main():
    root=HERE/'mutations_v1';root.mkdir(exist_ok=False)
    source=SOURCE.read_text()
    baseline=load(HERE/'independent_evidence_v1/RESULTS.json')
    existing_failure_names={r['name'] for r in baseline['failed_checks']}
    frozen=[dict(path=str(p),sha256=sha(p)) for p in [Path(__file__),SOURCE,HERE/'check_matter_vacuum_independent_v1.py',HERE/'PRE_EXECUTION_PLAN_v1.json',HERE/'independent_evidence_v1/RESULTS.json']]
    dump(root/'FREEZE.json',dict(created_at=now(),inputs=frozen,baseline_failures=sorted(existing_failure_names)))
    summaries=[]
    for name,before,after,meaning in MUTATIONS:
        if source.count(before)!=1:raise ValueError('Mutation not uniquely anchored: '+name)
        folder=root/name;folder.mkdir()
        # Clone all parent-local frozen sources; siblings remain at the verified
        # original paths actually referenced by unmodified INPUTS_v1.json.
        inputs=[];read_map=[]
        for row in FREEZE['inputs']:
            original=Path(row['path'])
            if original.is_relative_to(ORIGINAL):
                relative=original.relative_to(ORIGINAL)
                destination=folder/relative
                destination.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(SNAP/relative,destination)
            else:destination=original
            if sha(destination)!=row['sha256']:raise ValueError('Original frozen input mismatch before mutation')
            inputs.append(dict(path=str(destination),sha256=row['sha256']))
            read_map.append(dict(original=str(original),executed=str(destination)))
        runner=folder/'check_matter_vacuum_v1.py'
        altered=source.replace(before,after)
        runner.write_text(altered)
        for row in inputs:
            if row['path']==str(runner):row['sha256']=sha(runner)
        (folder/'SOURCE.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),altered.splitlines(True),fromfile=str(SOURCE),tofile=str(runner))))
        author_out=folder/'author_evidence';author_out.mkdir()
        dump(author_out/'FREEZE.json',dict(created_at=now(),inputs=inputs,mutation=name,read_map=read_map))
        subject_run=run([sys.executable,str(runner),str(author_out)],author_out)
        subject=load(author_out/'RESULTS.json')
        independent_out=folder/'independent_evidence';independent_out.mkdir()
        review_run=run([sys.executable,str(HERE/'check_matter_vacuum_independent_v1.py'),str(author_out/'RESULTS.json'),str(independent_out/'RESULTS.json'),str(author_out/'FREEZE.json')],independent_out)
        review=load(independent_out/'RESULTS.json')
        new_failures=[r for r in review['failed_checks'] if r['name'] not in existing_failure_names]
        changed=[row for row in inputs if sha(row['path'])!=row['sha256']]
        summary=dict(name=name,meaning=meaning,source_sha256=sha(runner),diff_sha256=sha(folder/'SOURCE.diff'),
                     author_returncode=subject_run['returncode'],author_passed=subject['checks_passed'],author_failed=subject['checks_failed'],
                     author_failed_checks=[r for r in subject['checks'] if not r['passed']],
                     independent_returncode=review_run['returncode'],independent_passed=review['passed'],independent_failed=review['failed'],
                     independent_new_failure_count=len(new_failures),independent_new_failed_checks=new_failures,
                     unchanged_baseline_failure_names=sorted(existing_failure_names),
                     independent_numerically_detected=bool(new_failures),
                     frozen_mutant_inputs_changed=changed,
                     author_result_sha256=sha(author_out/'RESULTS.json'),independent_result_sha256=sha(independent_out/'RESULTS.json'))
        dump(folder/'RECEIPT.json',summary);summaries.append(summary)
        print(json.dumps({k:summary[k] for k in ['name','author_returncode','author_failed','independent_failed','independent_new_failure_count','independent_numerically_detected','frozen_mutant_inputs_changed']}),flush=True)
    dump(root/'RESULTS.json',dict(created_at=now(),scope='Source-mutation sensitivity, not physical experiments or proof families.',
                                 frozen_harness_inputs_changed=[r for r in frozen if sha(r['path'])!=r['sha256']],mutations=summaries))
    return 0 if all(s['independent_numerically_detected'] and not s['frozen_mutant_inputs_changed'] for s in summaries) else 1
if __name__=='__main__':sys.exit(main())
