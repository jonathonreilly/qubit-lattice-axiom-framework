"""Independent affected metadata/recovery controls; no science execution or Git mutation."""
import datetime, hashlib, json, pathlib, subprocess, tarfile, time
ROOT=pathlib.Path('/Users/jonBridger/.codex/worktrees/analytic-fluid-construction-20261013/New Axioms Lets Go')
AP=ROOT/'.claude/science/physics-loops/analytic-fluid-construction-20261013'
RT=pathlib.Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/analytic_milestone')
OUT=RT/'final_identity_review_v1'
BASE='516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
HEAD='eb22c212bd0feeff27525453cbe21fc925bb667f'
TREE='9dd8453693714184a60279e427995958b101fe8e'
def h(b):return hashlib.sha256(b).hexdigest()
def info(p):
 p=pathlib.Path(p); b=p.read_bytes(); return {'path':str(p),'sha256':h(b),'bytes':len(b)}
def load(p):return json.loads(pathlib.Path(p).read_text())
def save(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2); f.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
start=time.monotonic()
save('PRE_EXECUTION_PLAN_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only affected metadata, new evidence/recovery, current31-path and original16-path mapping; preserve prior scientific review.','checks':['Exact31 disk/index/tree paths and only3 metadata changes among original16.','All213 new recovery members exact and complete45+168 source inventories.','Prior reviewer and parent receipt paths retain exact bytes or explicit original-commit recovery for3 updated metadata files.','Scientific runner/note/fixture/import/cache unchanged.','Final identities rechecked after read-only controls.'],'no_scientific_execution':True,'no_git_mutation':True,'gates':'Full unit receipt/cache and combined mechanical gates pending.'})
candidate=load(RT/'FINAL_CANDIDATE_SOURCE_v1.json')
oldunit=load(AP/'SOURCE_UNIT_v1.json')
oldmap=load(AP/'independent_source_review/ORIGINAL_DISPOSITIONS_v1.json')
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
check('candidate supplied identity',candidate['base']==BASE and candidate['commit']==HEAD and candidate['tree']==TREE)
check('current HEAD and origin/main identity',git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','origin/main').decode().strip()==BASE)
check('current index exactly frozen candidate tree',git('diff','--cached','--name-only',TREE).decode().strip()=='')
check('no unstaged tracked changes',git('diff','--name-only').decode().strip()=='')
delta=git('diff','--cached','--name-only','--no-renames',BASE).decode().splitlines()
check('complete31 staged delta',len(delta)==31 and sorted(delta)==sorted(x['path'] for x in candidate['source_paths']))
check('no staged deletions',git('diff','--cached','--name-only','--diff-filter=D',BASE).decode().strip()=='')
bindings=[]
for e in candidate['source_paths']:
 p=ROOT/e['path']; data=p.read_bytes(); idx=git('show',':'+e['path']); tree=git('show',TREE+':'+e['path'])
 check('candidate disk/index/tree '+e['path'],h(data)==h(idx)==h(tree)==e['sha256'])
 snap=OUT/'source_snapshot'/e['path'];snap.parent.mkdir(parents=True,exist_ok=True)
 with snap.open('xb') as f:f.write(data)
 bindings.append({**e,'absolute_path':str(p),'snapshot':str(snap),'bytes':len(data)})
source_map={e['path']:e for e in candidate['source_paths']}
old_paths={e['path'] for e in oldunit['paths']}
changed=[e['path'] for e in oldunit['paths'] if source_map[e['path']]['sha256']!=e['sha256']]
expected={str(AP.relative_to(ROOT)/n) for n in ['STATE.yaml','HANDOFF.md','REVIEW_HISTORY.md']}
check('exactly three declared original metadata changes',set(changed)==expected,changed)
check('fifteen added paths and no lost original',len(set(source_map)-old_paths)==15 and old_paths<=set(source_map))
check('original immutable16-row mapping intact',h((AP/'independent_source_review/ORIGINAL_DISPOSITIONS_v1.json').read_bytes())=='5f680e261aedab601e2f5da5f9d058935f6f6f1cca61e3499b61a2833f49d537' and len(oldmap['original_dispositions'])==16)
science=[*candidate['runtime_inputs'],'scripts/analytic_fluid_cosmology_2026_10_13.py']
oldh={e['path']:e['sha256'] for e in oldunit['paths']}
check('all four science source/input identities unchanged',all(source_map[p]['sha256']==oldh[p] for p in science))
check('canonical cache remains exact prior reviewed cache',h((ROOT/'logs/runner-cache/analytic_fluid_cosmology_2026_10_13.txt').read_bytes())=='5cf14bd0b8f22432f142778c183705823530ddc16cc8c132db3ca4ce75a4b7aa')
recovery=load(AP/'FINAL_REVIEW_RECOVERY_v1.json');archive=AP/recovery['archive']
check('review recovery archive digest',h(archive.read_bytes())==recovery['archive_sha256'])
member_rows=[]
with tarfile.open(archive,'r:gz') as tf:
 ms=tf.getmembers();regular=[m for m in ms if m.isfile()]
 check('all213 recovery members regular unique and safe',len(ms)==len(regular)==213 and len({m.name for m in ms})==213 and all(not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts for m in ms))
 actual={m.name:(h(tf.extractfile(m).read()),m.size) for m in regular}
 declared={m['member']:(m['sha256'],m['bytes']) for m in recovery['members']}
 check('all213 recovery names hashes and sizes match receipt',actual==declared)
 for e in recovery['members']:
  p=pathlib.Path(e['original_path']);data=p.read_bytes();member_rows.append({**e,'current_matches':h(data)==e['sha256'] and len(data)==e['bytes']})
 check('all213 archive members equal original current evidence',all(x['current_matches'] for x in member_rows))
 inventory={str(p.relative_to(AP)) for dirname in ['independent_source_review','prior_art_review'] for p in (AP/dirname).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 check('complete review directory inventories recovered',inventory==set(actual),{'inventory_count':len(inventory),'missing':sorted(inventory-set(actual)),'extra':sorted(set(actual)-inventory)})
 check('archive preserves45 source and168 prior-art files',sum(n.startswith('independent_source_review/') for n in actual)==45 and sum(n.startswith('prior_art_review/') for n in actual)==168)
parent_references=[]
for name,count in [('PARENT_SOURCE_REVIEW_RECEIPT_v1.json',88),('PARENT_PRIOR_ART_RECEIPT_v1.json',167)]:
 r=load(AP/name);entries=r['verified_identities'];resolved=[]
 for text,digest in entries.items():
  p=pathlib.Path(text);current=h(p.read_bytes());via='unchanged current path'
  if current!=digest:
   rel=str(p.relative_to(ROOT)); via='original commit preserved before explicit metadata update'
   ok=rel in expected and h(git('show',HEAD+':'+rel))==digest
  else:ok=True
  resolved.append({'path':text,'sha256':digest,'verified':ok,'recovery':via})
 check(name+' count and recoverable identities',len(entries)==count and all(e['verified'] for e in resolved),{'count':len(entries),'original_commit_recoveries':[e['path'] for e in resolved if e['recovery'].startswith('original commit')]})
 parent_references.append({'receipt':info(AP/name),'identity_rows':resolved})
prior=load(AP/'prior_art_review/FINAL_RECEIPT_v1.json')
check('all167 prior-art artifact identities intact',len(prior['artifacts'])==167 and all(h((AP/'prior_art_review'/e['path']).read_bytes())==e['sha256'] for e in prior['artifacts']))
vocab=load(RT/'VOCABULARY_FINAL_RUN_v2.json')
check('actual vocabulary fix/report-only zero and no changes',len(vocab['records'])==2 and {r['mode'] for r in vocab['records']}=={'--fix','--report-only'} and all(r['exit_code']==0 and not r['stderr'] for r in vocab['records']) and vocab['changed_by_fix']==[])
for f in ['vocabulary_fix_v2.json','vocabulary_report-only_v2.json']:
 d=load(RT/f);check(f+' actual zero report',d['files']==[] and all(v==0 for v in d['summary'].values()))
metadata_diffs={str(p.relative_to(ROOT)):git('diff','--cached',HEAD,'--',str(p.relative_to(ROOT))).decode() for p in [AP/'STATE.yaml',AP/'HANDOFF.md',AP/'REVIEW_HISTORY.md']}
save('REVIEWED_METADATA_DIFF_v1.json',metadata_diffs)
check('all candidate source bytes unchanged after review controls',all(h(pathlib.Path(e['absolute_path']).read_bytes())==e['sha256'] for e in bindings))
check('staged candidate unchanged after controls',git('diff','--cached','--name-only',TREE).decode().strip()=='')
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Affected metadata/evidence/recovery and identity check only','candidate':info(RT/'FINAL_CANDIDATE_SOURCE_v1.json'),'base':BASE,'head':HEAD,'tree':TREE,'source_bindings':bindings,'changed_original_metadata':changed,'added_paths':sorted(set(source_map)-old_paths),'recovery':{'receipt':info(AP/'FINAL_REVIEW_RECOVERY_v1.json'),'archive':info(archive),'member_rows':member_rows},'parent_references':parent_references,'vocabulary_evidence':[info(RT/f) for f in ['VOCABULARY_FINAL_RUN_v1.json','VOCABULARY_FINAL_RUN_v2.json','VOCABULARY_FINAL_v1.json','vocabulary_fix_v2.json','vocabulary_report-only_v2.json','VOCAB_v1.txt']],'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'failed_checks':[c for c in checks if not c['passed']],'elapsed_seconds':time.monotonic()-start,'science_executions':0,'git_mutations':0,'pending':'Actual full current unit helper --cache, generated citation manifest and combined mechanical gate.'}
save('AFFECTED_CHECKS_v1.json',result)
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':result['failed_checks'],'tree':TREE,'recovery_members':len(member_rows),'elapsed_seconds':result['elapsed_seconds']},indent=2))
raise SystemExit(0 if result['failed']==0 else 1)
