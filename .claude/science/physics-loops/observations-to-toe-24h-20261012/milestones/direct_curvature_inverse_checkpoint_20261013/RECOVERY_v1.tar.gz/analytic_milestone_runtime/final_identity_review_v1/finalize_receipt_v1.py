"""Bind independent affected judgments; do not alter the frozen candidate."""
import datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/Users/jonBridger/.codex/worktrees/analytic-fluid-construction-20261013/New Axioms Lets Go')
AP=ROOT/'.claude/science/physics-loops/analytic-fluid-construction-20261013'
RT=pathlib.Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/analytic_milestone')
OUT=RT/'final_identity_review_v1'
def h(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':h(b),'bytes':len(b)}
def load(p):return json.loads(pathlib.Path(p).read_text())
def save(name,obj):
 with (OUT/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
a=load(OUT/'AFFECTED_CHECKS_v1.json');candidate=load(RT/'FINAL_CANDIDATE_SOURCE_v1.json')
prior=load(AP/'independent_source_review/ORIGINAL_DISPOSITIONS_v1.json')
current={e['path']:e for e in candidate['source_paths']}
updates={
 'STATE.yaml':'Accept affected process-only update to source_reviewed with conditional support and unchanged deadline; full current unit/cache and combined gates remain pending. No scientific/status promotion.',
 'HANDOFF.md':'Accept dated checkpoint appended to original handoff: source review and canonical counts are accurate, original16 files remain preserved at original commit, missed earlier full helper is explicit, final gates remain required.',
 'REVIEW_HISTORY.md':'Accept affected chronology and12-topic conformance record: original text remains historical, completed source work is distinguished from pending full-unit/topology/combined work, and no success or retrospective compliance is fabricated.'}
rows=[]
for old in prior['original_dispositions']:
 row=dict(old);p=row['original_path'];name=pathlib.Path(p).name
 row['final_sha256']=current[p]['sha256']
 if name in updates:row['disposition']=updates[name]
 row['recovery'] += '; current candidate tree '+candidate['tree']+':'+p+'; affected-review snapshot '+str(OUT/'source_snapshot'/p)
 rows.append(row)
added={
 'CANONICAL_EXECUTION_v1.json':'Retain unchanged actual1497/0 parent execution record, distinct from independent science and pending final mechanical checks.',
 'FINAL_REVIEW_RECOVERY_v1.json':'Accept complete per-member213-file recovery receipt, independently checked against archive and all original review evidence.',
 'FINAL_REVIEW_RECOVERY_v1.tar.gz':'Accept exact full45-source-review plus168-prior-art recovery; all213 members checked. Historical failures and evidence retained, no gate success inferred.',
 'PARENT_PRIOR_ART_RECEIPT_v1.json':'Retain parent reading attestation and167 exact verified artifact identities; bounded prior-art scope and genuine earlier read error remain explicit.',
 'PARENT_SOURCE_REVIEW_RECEIPT_v1.json':'Retain parent reading attestation and88 recoverable identities; updated3 metadata originals resolve at original commit, source acceptance remains bounded and final gates pending.',
 'SOURCE_UNIT_v1.json':'Retain immutable historical original16-path source freeze; it does not purport to be the final31-path tree.',
 'EXECUTION_v1.json':'Retain unchanged original independent93/0 execution receipt, with exact outputs and no promotion to experimental evidence.',
 'ORIGINAL_DISPOSITIONS_v1.json':'Retain unchanged immutable original16-row reviewer map. Current3 metadata transitions are covered by this separate new final map.',
 'PRE_EXECUTION_PLAN_v1.json':'Retain unchanged original reviewer control plan and bounded reuse scope.',
 'RECEIPT_v1.json':'Retain unchanged original independent source receipt, including timing deviation and pending gates; no restamping.',
 'REPORT_v1.md':'Retain full original independent constructive source review with explicit assumptions/limitations and pending gates; a review record, not an additional autonomous scientific claim.',
 'SOURCE_CHECKS_v1.json':'Retain unchanged complete93-control results and archive/member/mutation identities, with their limited provenance/control meaning.',
 'FINAL_RECEIPT_v1.json':'Retain unchanged prior-art receipt and167 bound artifacts, contextual bounded search evidence only.',
 'PRIOR_ART_SOURCE_SCOPE_REVIEW.md':'Retain unchanged fully read bounded prior-art/source comparison report. No global novelty claim or load-bearing theorem premise; not an autonomous new scientific claim.',
 'analytic_fluid_cosmology_2026_10_13.txt':'Retain exact input-bound canonical1497/0 cache from actual parent execution; no rerun or synthetic substitution.'}
addedrows=[{'path':p,'sha256':current[p]['sha256'],'disposition':added[pathlib.Path(p).name]} for p in a['added_paths']]
assert len(rows)==16 and len(addedrows)==15 and a['failed']==0
save('ORIGINAL_DISPOSITIONS_FINAL_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/launch_check','original_source_commit':candidate['commit'],'original_delta_base':candidate['base'],'final_candidate_tree':candidate['tree'],'original_map':ident(AP/'independent_source_review/ORIGINAL_DISPOSITIONS_v1.json'),'original_report':ident(AP/'independent_source_review/REPORT_v1.md'),'affected_report':ident(OUT/'REPORT_v1.md'),'original_dispositions':rows,'added_path_dispositions':addedrows,'limits':'Reviewer-owned final source mapping; full current unit helper --cache, generated citation manifest and combined gates remain pending. Original mapping remains immutable.'})
checks=[]
for e in a['source_bindings']:
 checks.append({'path':e['path'],'passed':h(pathlib.Path(e['absolute_path']).read_bytes())==h(pathlib.Path(e['snapshot']).read_bytes())==e['sha256']})
checks.append({'path':'index versus frozen candidate tree','passed':subprocess.check_output(['git','diff','--cached','--name-only',candidate['tree']],cwd=ROOT).strip()==b''})
save('FINAL_UNCHANGED_v1.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)})
if not all(c['passed'] for c in checks):raise SystemExit('Actual final identity failure preserved; stop without acceptance receipt.')
evidence=[ident(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
receipt={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/launch_check','scope':'Affected metadata, additions and complete recovery confirmation; no new scientific review or formal audit.','disposition':'CONFIRMED for exact31-path candidate; original bounded source PASS remains applicable.','candidate':ident(RT/'FINAL_CANDIDATE_SOURCE_v1.json'),'base':candidate['base'],'head':candidate['commit'],'tree':candidate['tree'],'report':ident(OUT/'REPORT_v1.md'),'final_original_dispositions':ident(OUT/'ORIGINAL_DISPOSITIONS_FINAL_v1.json'),'original_report':ident(AP/'independent_source_review/REPORT_v1.md'),'original_receipt':ident(AP/'independent_source_review/RECEIPT_v1.json'),'original_map':ident(AP/'independent_source_review/ORIGINAL_DISPOSITIONS_v1.json'),'source_bindings':a['source_bindings'],'checks':ident(OUT/'AFFECTED_CHECKS_v1.json'),'focused_counts':{'pass':56,'fail':0,'exit_code':0},'final_identity_counts':{'pass':32,'fail':0},'recovery_members':213,'unchanged_science':True,'scientific_executions':0,'git_mutations':0,'source_changes':0,'cache_writes':0,'audit_applications':0,'process_timing_deviation':'Original missing full helper before canonical execution remains explicitly recorded. No retroactive compliance certified.','pending':['Full current UNIT_RECEIPT helper with --cache','Generated citation manifest plus narrow affected confirmation','Combined mechanical pipeline/strict-lint/changed-evidence validation and final identities'],'reviewer_evidence':evidence}
save('RECEIPT_v1.json',receipt)
print(json.dumps({'report':ident(OUT/'REPORT_v1.md'),'final_dispositions':ident(OUT/'ORIGINAL_DISPOSITIONS_FINAL_v1.json'),'receipt':ident(OUT/'RECEIPT_v1.json'),'source_paths':31,'original_rows':len(rows),'added_rows':len(addedrows)},indent=2))
