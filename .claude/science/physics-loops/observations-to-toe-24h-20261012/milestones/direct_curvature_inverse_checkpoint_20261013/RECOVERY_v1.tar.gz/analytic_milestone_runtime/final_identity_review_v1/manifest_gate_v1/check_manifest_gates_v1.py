"""Read-only final manifest/source/input/recorded-gate identity confirmation."""
import datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/Users/jonBridger/.codex/worktrees/analytic-fluid-construction-20261013/New Axioms Lets Go')
RT=pathlib.Path('/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/analytic_milestone')
REVIEW=RT/'final_identity_review_v1'
OUT=REVIEW/'manifest_gate_v1'
BASE='516cb69d8487ff04f8a48e065d3dcbe71d7dd237'
HEAD='eb22c212bd0feeff27525453cbe21fc925bb667f'
TREE31='9dd8453693714184a60279e427995958b101fe8e'
TREE32='9ae2ad5a41716c42cf5a4f10ec8ff23e7935ef33'
MANIFEST='docs/audit/data/citation_graph_manifest.json'
NODE='analytic_fluid_cosmology_construction_bounded_theorem_note_2026-10-13'
def h(b):return hashlib.sha256(b).hexdigest()
def info(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'sha256':h(b),'bytes':len(b)}
def load(p):return json.loads(pathlib.Path(p).read_text())
def git(*args,cwd=ROOT):return subprocess.check_output(['git',*args],cwd=cwd)
def save(name,d):
 with (OUT/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
old=load(RT/'FINAL_CANDIDATE_SOURCE_v1.json');new=load(RT/'FINAL_CANDIDATE_SOURCE_v2.json');src=new['source']
oldpaths={e['path']:e['sha256'] for e in old['source_paths']};newpaths={e['path']:e['sha256'] for e in src['paths']}
check('exact candidate base/head/tree',src['base']==BASE and src['commit']==HEAD and src['tree']==TREE32)
check('only new manifest path and unchanged31 identities',set(newpaths)-set(oldpaths)=={MANIFEST} and len(newpaths)==32 and all(newpaths[p]==digest for p,digest in oldpaths.items()))
check('current head and available main match',git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','origin/main').decode().strip()==BASE)
check('index exactly final32 tree',git('diff','--cached','--name-only',TREE32).strip()==b'')
check('working tracked source equals index',git('diff','--name-only').strip()==b'')
check('full base delta exactly32 paths',set(git('diff','--cached','--name-only','--no-renames',BASE).decode().splitlines())==set(newpaths) and src['deleted_paths']==[])
for p,digest in newpaths.items():check('final disk/index/tree '+p,h((ROOT/p).read_bytes())==h(git('show',':'+p))==h(git('show',TREE32+':'+p))==digest)
oldmanifest=json.loads(git('show',TREE31+':'+MANIFEST));newmanifest=load(ROOT/MANIFEST)
expected=json.loads(json.dumps(oldmanifest));expected['node_count']+=1;expected['nodes'][NODE]={'deps_hash':h(b'')[:12],'out_degree':0}
check('manifest semantic delta exactly one zero-edge node',NODE not in oldmanifest['nodes'] and newmanifest==expected)
check('manifest counts consistent',newmanifest['node_count']==len(newmanifest['nodes'])==7024 and newmanifest['edge_count']==oldmanifest['edge_count']==15805)
with (OUT/'citation_graph_manifest.json').open('xb') as f:f.write((ROOT/MANIFEST).read_bytes())
with (OUT/'MANIFEST.diff').open('xb') as f:f.write(git('diff','--cached',TREE31,'--',MANIFEST))
combined=load(RT/'validation/COMBINED_RECEIPT_v1.json');copy=pathlib.Path(combined['copy'])
check('combined receipt binds reviewed31 and resulting32 trees',combined['base']==BASE and combined['source_tree']==TREE31 and combined['copy_final_staged_tree']==TREE32)
check('validation copy still has final32 index',git('diff','--cached','--name-only',TREE32,cwd=copy).strip()==b'')
check('validation manifest byte-identical to final source',h((copy/MANIFEST).read_bytes())==newpaths[MANIFEST])
copyrec=load(RT/'validation/SOURCE_COPY_IDENTITY_v1.json')
check('copy pre-gate identity exact',copyrec['base']==BASE and copyrec['head']==HEAD and copyrec['tree']==TREE31)
copyrows=[]
for e in copyrec['bindings']:
 p=e['path'];digest=e['sha256'];copyrows.append({**e,'matches':h((ROOT/p).read_bytes())==h((copy/p).read_bytes())==digest})
check('all45 unique pre-gate source/input/tool bytes match both locations',len({e['path'] for e in copyrows})==copyrec['unique_bound_paths']==45 and all(e['matches'] for e in copyrows))
gates=[]
expected_commands=[['bash','docs/audit/scripts/run_pipeline.sh','--stage-citation-manifest'],['/usr/local/bin/python3','docs/audit/scripts/audit_lint.py','--strict'],['/usr/local/bin/python3','docs/audit/scripts/check_changed_audit_evidence.py','--base','origin/main','--include-worktree']]
for n,e in enumerate(combined['gate_receipts'],1):
 p=pathlib.Path(e['path']);r=load(p)
 check('gate'+str(n)+' receipt hash',h(p.read_bytes())==e['sha256'])
 check('gate'+str(n)+' actual command/source/exit identity',r['command']==expected_commands[n-1] and r['exit_code']==0 and r['base']==BASE and r['source_tree']==TREE31 and r['copy']==str(copy))
 for stream in ['stdout','stderr']:
  check('gate'+str(n)+' '+stream+' digest',h(pathlib.Path(r[stream]['path']).read_bytes())==r[stream]['sha256'])
 check('gate'+str(n)+' stderr empty',pathlib.Path(r['stderr']['path']).read_bytes()==b'')
 gates.append({'receipt':info(p),'record':r})
g1=(RT/'validation/gate1.stdout').read_text();g2=(RT/'validation/gate2.stdout').read_text();g3=(RT/'validation/gate3.stdout').read_text()
check('complete pipeline invariant and final checkpoint success',all(s in g1 for s in ['PASS rows=5401 retained_grade=0 link_violations=0 class_f_violations=0 graph_delta=acknowledged (enforced)','finalized full checkpoint 68e4e6cd2318','Pipeline complete.']))
check('strict lint complete output preserves33 warnings1484 notices no errors',g2.startswith('audit_lint: 5546 rows checked\n') and '33 warnings:' in g2 and '1484 notices:' in g2 and g2.rstrip().endswith('OK: no errors'))
# This is the same complete diagnostic body already read in the pipeline log.
check('strict diagnostics exactly equal full read pipeline diagnostic body',g2==g1.split('==> 13/18 audit_lint.py\n',1)[1].split('==> 14/18 render_audit_ledger.py\n',1)[0])
check('changed-evidence exact successful output',g3=='changed-audit-evidence: checked=1 failures=0 control_failures=0\n')
ue=load(RT/'UNIT_EXECUTION_v1.json');u=load(RT/'UNIT_v1.json');up=load(RT/'UNIT_PREFLIGHT_v1.json')
for k in ['record','stdout','stderr']:check('unit prior '+k+' exact digest',info(ue[k]['path'])['sha256']==ue[k]['sha256'])
check('actual full unit cache execution succeeded for31 tree',ue['exit_code']==0 and '--cache' in ue['command'] and up['mechanical_status']=='ok' and up['cache_checked'] is True and up['tree']==TREE31 and u['source']['tree']==TREE31)
check('unit record and checker identities',info(RT/'UNIT_v1.json')['sha256']==up['record_sha256'] and info(ROOT/'docs/ai_methodology/skills/review-loop/scripts/review_receipt.py')['sha256']==up['checker_sha256'])
check('full unit source matches reviewed31 map',{e['path']:e['sha256'] for e in u['source']['paths']}==oldpaths)
check('unit discovered standalone note and empty helper/premise closure',len(up['notes'])==1 and up['notes'][0]['claim_id']==NODE and up['notes'][0]['helpers']==[] and up['notes'][0]['citations']==[] and len(u['notes'])==1 and u['notes'][0]['repository_dependencies']==[])
inputrows=[]
for category,entries in u['inputs'].items():
 for e in entries:inputrows.append({'category':category,**e,'matches':info(ROOT/e['path'])['sha256']==e['sha256']})
check('all17 input-category rows unchanged',len(inputrows)==17 and all(e['matches'] for e in inputrows))
reviewrefs=[u['reviewer']['report'],*u['reviewer']['references'],*[c['dispositions'] for c in u['constituents']]]
check('all prior unit reviewer evidence references unchanged',all(info(e['path'])['sha256']==e['sha256'] for e in reviewrefs))
dispositions=load(REVIEW/'ORIGINAL_DISPOSITIONS_FINAL_v1.json')
check('prior final16-row map unchanged and still valid',info(REVIEW/'ORIGINAL_DISPOSITIONS_FINAL_v1.json')['sha256']=='48e6c3ecdc57ae2e056c274afb532710b3dc5335af51f909ce47455ac0109ace' and len(dispositions['original_dispositions'])==16 and all(newpaths[e['final_path']]==e['final_sha256'] and h(git('show',HEAD+':'+e['original_path']))==e['original_sha256'] for e in dispositions['original_dispositions']))
check('canonical1497/0 cache exact and unchanged',info(ROOT/'logs/runner-cache/analytic_fluid_cosmology_2026_10_13.txt')['sha256']=='5cf14bd0b8f22432f142778c183705823530ddc16cc8c132db3ca4ce75a4b7aa')
check('final32 sources and index remain unchanged',all(info(ROOT/p)['sha256']==digest for p,digest in newpaths.items()) and git('diff','--cached','--name-only',TREE32).strip()==b'')
evidence=[info(p) for p in sorted((RT/'validation').iterdir()) if p.is_file()]+[info(RT/n) for n in ['FINAL_CANDIDATE_SOURCE_v1.json','FINAL_CANDIDATE_SOURCE_v2.json','UNIT_v1.json','UNIT_EXECUTION_v1.json','UNIT_PREFLIGHT_v1.json','UNIT_PREFLIGHT_v1.stderr','PARENT_FINAL_IDENTITY_REVIEW_v1.json']]
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final32-path source/generated manifest/actual gate identity confirmation only','base':BASE,'head':HEAD,'reviewed_tree31':TREE31,'final_tree32':TREE32,'source':src,'manifest':info(ROOT/MANIFEST),'copy':str(copy),'copy_bound_paths':copyrows,'gates':gates,'unit_inputs':inputrows,'prior_review_references':reviewrefs,'original_disposition_map':info(REVIEW/'ORIGINAL_DISPOSITIONS_FINAL_v1.json'),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'failed_checks':[c for c in checks if not c['passed']],'external_evidence':evidence,'science_reruns':0,'pipeline_or_unit_reruns':0,'git_mutations':0,'pending':'Final updated32-path UNIT/cache receipt after this confirmation; future commit/remote-head binding belongs to parent. Historical early full-preflight timing deviation remains.'}
save('MANIFEST_GATE_CHECKS_v1.json',result)
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':result['failed_checks'],'final_tree':TREE32,'original16_map_still_applies':checks[-3]['passed']},indent=2))
raise SystemExit(0 if result['failed']==0 else 1)
