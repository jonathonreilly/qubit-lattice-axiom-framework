# Exact-zero boundary addendum

This addendum preserves the already sealed `INDUCED_CURVATURE_MATH_REVIEW.md` and `FINAL_RECEIPT_v1.json` unchanged. After that receipt was written, the parent reported that a separate numerical implementation review found a strict floating-point negative-mass classification at an exactly zero origin mass. The parent will preserve and correct its implementation separately. I have not inspected or executed that runner or its classification evidence; this addendum independently confirms only the exact mathematical boundary relevant to the handwritten scope.

At a=1/3, nu=4, s=-1/2, t=0, the independently derived origin expression is

    m_J,u²/H_v²=[nu(1+s)+12as]/[1+(1-3a)s]
                =[4(1-1/2)+4(-1/2)]/1=0.

Here F/q=1+s=1/2>0 and J=1>0. It is therefore a positive-kinetic point with exactly zero u quadratic mass, neither a negative-mass example nor a strictly positive local Hessian. It lies exactly at s=-nu/(nu+12a). The strict inequality in the handwritten source is correct and must not be replaced by a floating-point sign test that assigns a tiny residual a physical sign. No conclusion about nonlinear stability at this massless boundary is made.

A separate stdlib `fractions.Fraction` implementation in `exact_zero_boundary_v1.py` checks the boundary and both neighboring rational points without an absolute tolerance or floating arithmetic. It gives m_J,u²/H_v²=-2/25,0,+2/25 at s=-51/100,-1/2,-49/100, respectively; all three have positive kinetic coefficients. Its five assertions pass. Source, all three exact rows, raw output and empty stderr are preserved in the matching results/run files. This check does not validate the parent's planned numerical correction.

The six handwritten source identities remain unchanged. `FINAL_RECEIPT_v2.json` binds this addendum and all prior review artifacts, including the immutable v1 receipt. The main result remains 121 passing independent checks after two separately preserved reviewer failures; the exact-zero addendum is an additional five-assertion stage. No author equation or source correction is requested by this mathematical review.
