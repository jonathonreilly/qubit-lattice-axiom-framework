# Independent induced-curvature derivation

This is a focused check of the parent-authored `HAND_DERIVATION_v1.md`, SHA-256 `b37f6a0bf03a9a178c638266f4d6cffedce4150ed89c03ab6416a71c21ac225e`. It checks the supplied classical action and stated boundaries. It does not review a parent implementation, infer a quantum coefficient, or establish a constrained boundary-value or global stability theorem. All three new source files were frozen before these checks; exact parent premises are copied and identified in `PARENT_SOURCE_PINS_v1.json`.

## Premises and dimensions

Use signature (-,+,+,+), natural units, real dimensionless fields (u,x,y), positive a,nu,H_v,q, and alpha=sqrt(a). The exactly pinned analytic-fluid premise is

    A=exp(alpha u),
    D=1+2(1+a)(x²+y²)/3,
    K=diag(1,4a/(9D),a/(3D)),
    V/H_v²=3/2+(a/2-alpha u+2u²)x²+a y²/3+nu u²/2.

Here q and zeta have mass dimension two; V, H_v² and C have dimension two; Lambda and rho have dimension four. Quantities a,nu,t=alpha u,s=zeta/q,z=s exp(2t),ell=nu/a,c=C/H_v² and b=B_flux/H_v² are dimensionless. The action and all displayed curvature and mass relations are dimensionally consistent with these conventions.

The original auxiliary action, before its equations are used, is

    S=integral vol_g [q L0-Lambda A⁴]+Gamma_m[A²g]
      +integral (Lambda/mu_aux⁴) F4
      +integral [q²/(2M_aux⁴)] Fhat4
      +(zeta/2) integral vol_J R_J,
    L0=R/2-K_AB partial(phi^A).partial(phi^B)-2V.

Split the constant vacuum part of Gamma_m as -rho integral A⁴ vol_g and set Ltilde=Lambda+rho. Zeta is an independent prescribed coefficient in this original action. The exact checks do not replace its variation by a variation of a frame-transformed action with q already fixed. The inherited forms are real and noncompact. Required metric boundary terms and compatible finite-sector form boundary data are premises. No statement about arbitrary boundary data follows from the bulk algebra.

## Weyl transformation and complete kinetic sign

For g_J=A²g, in four dimensions,

    vol_J R_J=vol_g A²[R-6 box ln A-6(partial ln A)²].

Putting d=zeta A² and integrating the box term by parts produces +6a d(partial u)² from that term and -3a d(partial u)² from the last term, leaving +3a d(partial u)². Thus, in a constant-q sector after the original variations,

    L_bulk=F R/2-Z_AB partial(phi^A).partial(phi^B)-U,
    F=q+d,
    Z=qK-3a d e_u e_u,
    U=2qV+Ltilde A⁴.

For F>0, choose ghat=(F/q)g. The bulk action becomes

    q integral vol_hat [Rhat/2-Khat_AB partial(phi^A).partial(phi^B)-2Vhat],
    Khat=Z/F+(3/4) d(ln F) tensor d(ln F),
    Vhat=(V+C A⁴)/(1+z)²,
    C=Ltilde/(2q).

A separate homogeneous Schur-complement check recovers the mixing coefficient without assuming the final kinetic formula. Integration of F R/2 in a spatially flat homogeneous metric gives the velocity form

    -3F H²-3H Fdot+Z_uu udot²
    =-3F[H+Fdot/(2F)]²+Z_uu udot²+3Fdot²/(4F).

Since F_u=2alpha d, the remaining scalar coefficient divided by F is exactly Khat_uu. This yields

    Khat_uu=J/(1+z)²,       J=1+(1-3a)z,
    Khat_xx=K_xx/(1+z),    Khat_yy=K_yy/(1+z).

With a>0 and D>0, positive local tensor and three-scalar kinetic terms are equivalent to 1+z>0 and J>0. This is a statement about the displayed two-derivative gravity/scalar sector, with q>0, not about every possible imported matter sector. For -1<z<0, J=1+z-3az>0. For z>=0, all z are permitted when a<=1/3, while a>1/3 requires z<1/(3a-1). Equality at either kinetic boundary is not a positive-energy point. The normalizing frame is undefined at F=0.

The conformal matter factor is B=A/sqrt(1+z). Therefore

    partial_u ln B=alpha/(1+z),
    alpha_eff²=Khat^{uu}(partial_u ln B)²=a/J,
    G_T,J=B²/(8 pi q)=1/[8 pi(q exp(-2t)+zeta)].

The weak-source Newton factor 1+alpha_eff² requires the scalar to be light at the length scale used and the stated universal ordinary-matter premise. Neither this factor nor G_T,J is a measured calibration here. A bare negative Z_uu is not a ghost criterion: at a=1/5,z=3 it would give -1/5 after division by F, while the complete Khat_uu is 11/80>0.

## Original auxiliary variations and metric trace

The form variations give dLambda=0 and q dq=0; on q>0 this implies dq=0. The algebraic variations give

    F4=mu_aux⁴ A⁴ vol_g,
    Fhat4=-(M_aux⁴/q) L0 vol_g.

The zeta term has no explicit q dependence in the original variables. Omitting part of L0 from the q variation would change the theory. At fixed finite flux sector, rho->rho+delta and Lambda->Lambda-delta leave Ltilde and all local equations, fields and forms unchanged. The action changes by -delta integral(F4)/mu_aux⁴, a sector constant. This is not invariance of an unspecified sum over sectors or a statement about renormalized quantum measures.

Define Q=K_AB partial(phi^A).partial(phi^B), Q_Z=qQ-3a d(partial u)² and let T_ex be the trace of the nonvacuum matter stress with respect to g. Direct inverse-metric variation gives

    F G_mn=2Z_AB partial_m phi^A partial_n phi^B-g_mn Q_Z-g_mn U
           +T_ex,mn+nabla_m nabla_n F-g_mn box F.

Tracing therefore gives

    F R=2Q_Z+4U-T_ex+3 box F.

Substitution into q(R/2-Q-2V) gives

    qL0=-qdQ/F-3qad(partial u)²/F+2q(q-d)V/F
         +2qLtilde A⁴/F-qT_ex/(2F)+3q box F/(2F).

At zeta=0, including box F=0, this reduces to 2qV+2Ltilde A⁴-T_ex/2. The stress term is not -qT_ex/2. The reviewer initially put that extra q only in a comparison oracle; the incorrect assertion and its correction are preserved, as described in the review report. The author's formula is consistent.

The finite flux ratio remains

    B_flux=-(q mu_aux⁴/M_aux⁴)(integral Fhat4/integral F4)
          =integral L0 vol_g/integral A⁴ vol_g.

In a varying-field history the weights and box F in the traced equation are real contributions. The box term cannot be dropped merely because it may be written as part of a boundary expression: the integrand also has a nonconstant 1/F weight, and permitted boundary conditions must be specified. In a control jet q=1,d=1/10,box F=-2/5, omitting this term leaves -6/11 in qL0. The old unweighted AUX trace relation and its exact evolving fluid orbit have not been established for this modified action.

## Constant-vacuum elimination

At x=y=0 and constant u, Q=box F=T_ex=0. Define

    v=3/2+ell t²/2,    h=c exp(4t),    r=R/H_v².

The original scalar equation is F_u R/2-2qV_u-4alpha Ltilde A⁴=0. Together with the metric equation it reduces to

    (1+z)r=8(v+h),
    ell t+4h-zr/2=0.

Solving these two equations for r,h, without differentiating an already-eliminated potential, gives

    h=zv-ell t(1+z)/4,
    r/12=1+ell(t²/3-t/6).

At a constant field the finite ratio is also its pointwise value:

    b=(r/2-2v) exp(-4t)
     =[3+ell(t²-t)] exp(-4t).

Thus b(t), H_g²(t)/H_v² and H_J(t)=H_g(t)exp(-t) are independent of zeta at a given stationary field value. Here t is a field coordinate, not time. Only an allowed root with positive kinetic coefficients and positive H_g² belongs to the expanding constant-vacuum family. The cancellation does not prove unchanged cosmological trajectories, unchanged C, unchanged local mass spectra, or radiative protection.

At the b=3 origin, t=0 gives c=3s/2 and Ltilde=3zeta H_v². Then H_g=H_J=H_v but G_T,J/(1/(8 pi q))=1/(1+s). At fixed c=0 instead, the origin has scalar-equation residual -6s/(1+s), so it is stationary only at s=0. Implicit differentiation on the branch through s=0 gives t=6s/ell+O(s²).

Changing b, selecting among roots at one b, fixing c, and fixing two absolute fluxes with boundary geometry are different problems. At fixed q the ratio constrains one combination of fluxes; it does not specify their individual values. Infinite regulated ratios do not fix finite absolute fluxes. The nonzero-root comparison below generally changes C even at the same q,zeta,b. This does not demonstrate two stable vacua in a single fixed-C or fixed-absolute-flux boundary-value problem.

## Local masses at fixed integration constants

For a local Hessian, hold q,Lambda,rho,zeta,a,nu,H_v fixed. Hence c and s are fixed while h and z vary with the field as h_t=4h,z_t=2z. In the (t,x,y) chart,

    Vhat/H_v²=[3/2+ell t²/2+(a/2-t+2t²/a)x²+a y²/3+h]/(1+z)².

Use D_t=partial_t+2z partial_z+4h partial_h. At a stationary point the field-space connection term in the covariant Hessian vanishes because the full potential gradient vanishes. With x=y=0 the mixed Hessian entries vanish. The kinetic diagonal in this chart is

    [J/(a(1+z)²), 4a/(9(1+z)), a/(3(1+z))].

Taking two derivatives before substituting the stationary h yields

    f_tt=[ell(1-4t)+z{ell(1-6t)+8v}]/(1+z)³,
    mhat_u²/H_v²=[nu(1-4t)+z{nu(1-6t)+8av}]/[(1+z)J],
    mhat_x²/H_v²=[9/4-9t/(2a)+9t²/a²]/(1+z),
    mhat_y²/H_v²=2/(1+z).

The action convention -q Khat(partial phi)²-2q Vhat makes the mass matrix Khat^{-1} Hess(Vhat), with no extra factor of two. At constant B, proper-time/frequency conversion gives m_J²=mhat²/B²; Hhat=H_g/sqrt(1+z) and H_J=H_g exp(-t). Eliminating h before differentiating would follow a changing-C stationary family rather than the fixed-constant potential. The independent symbolic check explicitly rejects that operation.

At the origin,

    m_J,u²/H_v²=[nu(1+s)+12as]/[1+(1-3a)s].

Within the positive kinetic domain its positivity requires s>-nu/(nu+12a). Kinetic positivity alone is insufficient: a=1/5,nu=1,s=-1/2 gives F/q=1/2,J=4/5 and m_J,u²/H_v²=-7/8. For s>=0 the origin mass is positive throughout the allowed domain.

For a nonzero b=3 root, t must exceed one: negative t gives opposite signs in ell(t²-t)=3(exp(4t)-1), and 0<t<=1 cannot satisfy it. The old zeta=0 u mass is then negative. For positive z, write P=nu(1-6t)+8av. The modified numerator is positive exactly when P>0 and z>nu(4t-1)/P, subject to the kinetic inequalities. The x numerator is positive for all real t because its quadratic discriminant is negative, and y is positive in the kinetic domain.

An exact existence control chooses

    t=2, ell=3(exp(8)-1)/2, a=1/10, nu=a ell,
    z=2, s=2 exp(-4), J=12/5.

Then b=3 and the u mass numerator equals a(3ell+24)>0. Direct high-precision differentiation of the fixed-c potential gives

    mhat²/H_v²=(186.58070752344135,1170.75,2/3),
    m_J²/H_v²=(10.25203458781164,64.32910268695662,0.03663127777746836).

This root has H_J/H_v=9.04920257427537 and c=3.74974840302907. At the same s the t=0 root instead has c=0.05494691666620254. These values confirm possible local-Hessian reclassification while making the integration-constant distinction explicit. They do not constitute branch selection or empirical evidence.

## Nearby ratio response

At fixed q,zeta,a,nu,H_v, impose b=3+epsilon on the branch through t=0. Since b_t(0)=-(ell+12),

    t_epsilon=-1/(ell+12),
    c_epsilon=[ell(1+s)+12s]/[4(ell+12)],
    (H_J/H_v)_epsilon=1/12,
    [G_T,J/(1/(8 pi q))]_epsilon=-2/[(ell+12)(1+s)²].

The last derivative is absolute about 1/(1+s); the relative derivative is -2/[(ell+12)(1+s)]. The H_J derivative follows directly from H_J/H_v=exp(-t)sqrt[1+ell(t²/3-t/6)], whose t derivative at zero is -(ell+12)/12. This does not identify zeta from a single expansion response.

A distinct numerical route solved the three original metric, scalar and flux equations simultaneously for (t,c,r), rather than feeding the reduced b(t) expression to a root solver. Five (ell,s) choices, three central-difference step sizes and both signs give 30 roots and 15 derivative pairs. Their maximum original-equation residual was 1.673e-81. Maximum absolute derivative errors at steps 1e-4,1e-6,1e-8 were respectively 6.893e-10,6.893e-14,6.893e-18. These are finite high-precision synthetic checks, not interval proofs or data likelihoods. All equations above also have exact symbolic residual checks.

## Boundary of the prior global theorem

For s>0 and a<1/3, at x=y=0 and u->+infinity,

    Vhat -> C/s²,
    Khat_uu ~ (1-3a) exp(-2alpha u)/s.

Thus the scalar distance integral converges and the displayed potential no longer gives the old coercive sublevel argument. This is enough to prevent importing the previous global convergence proof. It neither proves a runaway nor excludes a future extension or a different global argument. The asymptotic statement has intentionally not been extended to a=1/3, where the leading kinetic term changes, or a>1/3, where the positive kinetic domain ends at finite positive z.

## Reproducible independent evidence

`derive_induced_curvature_v3.py` uses original-frame variation, an independent Schur completion, exact SymPy differentiation, direct 90-digit mpmath differentiation, and simultaneous original-equation roots. It imports no author helper and does not execute an author runner. `INDEPENDENT_RESULTS_v3.json` records 121 passing and zero failed assertions, all 40 domain rows, the explicit second-root witness, and all 15 derivative pairs. `INDEPENDENT_SUMMARY_v1.json` records maxima and current/snapshot/frozen identity agreement for all six inputs. The two earlier reviewer failures and all executed versions are preserved separately; neither was erased or attributed to the author's derivation.
