# Focused independent check of the induced-curvature derivation

I found no correction required in the frozen parent-authored handwritten derivation. The Weyl kinetic domain, original auxiliary constraints, complete traced equation, constant-vacuum elimination, fixed-constant local Hessians, physical-frame conversions and small-flux derivatives agree with the independent derivation in `INDEPENDENT_DERIVATION.md`. This conclusion is limited to the stated classical two-derivative action and boundary premises. It is not a formal audit, a retained status, a review of the subsequent parent implementation, or a global/constrained stability result.

## Source and complete coverage

The exact review subject is `HAND_DERIVATION_v1.md`, SHA-256 `b37f6a0bf03a9a178c638266f4d6cffedce4150ed89c03ab6416a71c21ac225e`, together with the full frozen protocol and source ledger. All three were copied before checks at 2026-10-13T06:56:38.782044Z. The three exact parent handwritten premises are also copied. All six current inputs remained byte-identical to their frozen snapshots when the summary was written. Final identities and dispositions are recorded in `SOURCE_DISPOSITIONS_v1.json` and the final receipt.

The full new note, protocol and ledger were read. The AUX and matter-vacuum notes were read in full for this review. The complete AN note had already been read and independently checked in the same review session history; its exact unchanged source identity and action were reused, with the current copy and current applicable equations checked again. The prior proof result is not substituted for checking the new Ricci operator. No external paper conclusion, measured coefficient or data likelihood was needed or imported. The parent is responsible for the derivation and its later implementation; this is a separate check.

| New source section | Independent coverage |
| --- | --- |
| 1: extra premise and Weyl reduction | Original action, units, integration by parts, independent-zeta q variation, boundary qualification |
| 2: kinetic domain and local coupling | Covariant Weyl expression plus homogeneous Schur completion; full sign inequalities, 40 domain rows, coupling norm and physical tensor normalization |
| 3: forms, compensation and trace | Original q/Lambda/form variations, exact constant-shift action difference, metric trace including box F, zero-zeta reduction and adverse varying-field control |
| 4: constant vacua | Original metric and scalar equations solved jointly; pointwise constant-vacuum flux relation; fixed-C versus imposed-ratio origin distinction |
| 5: local Hessian and branch scope | Fixed-constant full three-field Hessian, mixed entries, canonical and Jordan mass conversions, negative-mass example, exact second-root positive-mass witness, noncoercive endpoint |
| 6: neighboring flux | All five exact derivatives including absolute/relative G; 30 simultaneous original-equation roots and 15 central-difference pairs |
| 7: scope and planned checks | Supplied scales, no fit or quantum coefficient, parent numerical plan separated from this handwritten check, no extension of the old evolving orbit/global theorem |

The protocol's future implementation grid was read as a plan. This handwritten review does not claim to have executed or validated that later parent grid, its root enumeration, or any parent result file.

## Material conclusions and restrictions

1. The raw added +3a d(partial u)² term is not sufficient for a ghost decision. Ricci-scalar mixing restores the 3/4 gradient-ln-F contribution. The full kinetic inequalities are 1+z>0 and J=1+(1-3a)z>0; their zero boundaries must remain excluded. The independent omission control changes the sign at a=1/5,z=3, where the raw value is -1/5 and the complete scalar metric is 11/80.
2. The auxiliary q variation still includes all of L0 and does not differentiate zeta. The new traced q equation needs its field-dependent weights and 3q box F/(2F). General histories do not inherit the old integrated trace simplification or exact fluid orbit. The original finite-sector compensation map remains valid under the given boundary premise; it does not establish a quantum or infinite-action symmetry.
3. The unchanged b(t) and H_J(t) are statements about a stationary field parameter t, not time evolution. At the b=3 origin, C changes to (3s/2)H_v², the tensor coupling changes by 1/(1+s), and the local mass changes. Holding C=0 asks a different question and shifts the stationary field at order s.
4. A permitted positive-zeta nonzero root can have all three positive local scalar masses. An exact independent control is t=2, a=1/10, ell=3(exp(8)-1)/2, z=2, s=2exp(-4). It has b=3 and J=12/5, with physical mass squares/H_v² approximately (10.2520,64.3291,0.0366313). This root and the origin have different C. Consequently it verifies the stated possible local-Hessian reclassification; it does not establish two stable solutions in one fixed-C or fixed-absolute-flux boundary problem.
5. Positive kinetic energy does not suffice for positive local masses. At a=1/5,nu=1,s=-1/2,t=0 the kinetic domain is allowed but m_J,u²/H_v²=-7/8. The extra origin condition s>-nu/(nu+12a) is necessary and sufficient within the kinetic domain.
6. The old homogeneous convergence theorem cannot be imported: for s>0,a<1/3, the potential has a finite limit at a finite scalar-distance end. The source correctly stops short of asserting a runaway or proving new global dynamics. The regulated future ratio also does not fix both finite absolute fluxes or arbitrary boundary geometry.

These restrictions are already stated or respected in the source; I am not requesting a prose or equation change. The familiar local weak-source Newton enhancement remains conditional on scalar range, source and matter/readout assumptions. No observational acceptance, loop-generated value of zeta, radiative stability, branch selection, absolute-scale explanation or full constrained/global stability follows from these checks.

## Independent computations and failure sensitivity

The final reviewer script `derive_induced_curvature_v3.py` imports only standard modules, SymPy and mpmath. It does not import or execute author code. It uses a different Schur-complement route for the kinetic mixing, explicit original-frame variations for constraints, fixed-constant differentiation of the three-field potential, direct high-precision differentiation for the second-root masses, and a simultaneous solver for all three unreduced vacuum equations.

Final evidence: **121 pass, 0 fail**. All 40 domain rows, including invalid and degenerate points, are retained. Fifteen central-difference pairs comprise 30 original-equation roots. The maximum original-equation residual is 1.6723660257243374e-81; the maximum absolute derivative errors at steps 1e-4,1e-6,1e-8 are 6.8929036566e-10,6.8929036458e-14,6.8929036458e-18. They show the expected quadratic central-difference behavior in these fixtures. The numerical roots test stationary equations and derivatives, not stability or an empirical history.

Adverse checks reject three decisive formula errors: dropping Ricci kinetic mixing, omitting box F in the varying-field trace, and differentiating the stationary-family potential after eliminating C instead of holding it fixed. The positive-kinetic/negative-mass example also prevents conflating the two signs. These are reviewer formula controls. They are not mutations of, or sensitivity claims about, any parent runner, which was outside this assignment.

## Preserved reviewer failures

The first executed reviewer file, `derive_induced_curvature_v1.py`, stopped with a syntax error from an extra closing parenthesis before producing a check result. Its exact bytes and raw stderr/stdout remain in place. `RUN_v1_FAILURE.json` and `REVIEWER_SYNTAX_CORRECTION_v2.diff` record the correction into a new file.

The second executed version ran 121 assertions, with 120 pass and one fail. Its zero-zeta comparison oracle incorrectly expected -q T_ex/2 rather than -T_ex/2. This was a reviewer oracle error; the independently derived trace and the author's formula both had the correct coefficient. `RUN_v2_FAILURE.json` records the diagnosis, and `REVIEWER_TRACE_ORACLE_CORRECTION_v3.diff` records the new-version correction. No author source was edited.

The third version passes all 121. `REVIEWER_RESULT_IDENTITY_v2_v3.json` confirms that the four numerical result sections and the other 120 check records are exactly unchanged. The failed v2 assertion, all three executed script versions, both correction diffs, results and all raw outputs remain preserved. No failure was removed to improve a reported count.

## Reproduction and evidence disposition

Run from this review directory, with Python 3.12.8, SymPy 1.14.0 and mpmath 1.3.0:

    python3 -B derive_induced_curvature_v3.py

The script sets numerical library thread counts to one and uses 90-digit arithmetic; its last execution completed in under one second. Reproduction overwrites the named reviewer result, so copy the review directory before rerunning if exact original output preservation is required. No parent numerical implementation is required.

`INPUT_FREEZE_v1.json`, `PARENT_SOURCE_PINS_v1.json`, `SOURCE_DISPOSITIONS_v1.json` and `FINAL_RECEIPT_v1.json` bind sources, copies, executed versions, failures and completed findings. All task writes are confined to this `independent_math_review` directory. No parent file, Git state, PR, model, worker, empirical input or prior review was changed. This review is complete for the frozen handwritten scope.
