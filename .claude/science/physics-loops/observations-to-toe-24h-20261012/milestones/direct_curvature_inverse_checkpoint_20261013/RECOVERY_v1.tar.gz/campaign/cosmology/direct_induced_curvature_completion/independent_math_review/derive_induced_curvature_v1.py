#!/usr/bin/env python3
"""Reviewer-owned action/Schur-complement and fixed-constant Hessian checks.

No author runner or author helper is imported. Natural units H_v=1 are used
for numerical examples; q is an independent positive mass-squared scale.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import datetime, hashlib, json, platform, sys
import mpmath as mp
import sympy as sp

P=Path(__file__).resolve().parent
mp.mp.dps=90
checks=[]
def check(name,ok,detail=None):
    checks.append({'name':name,'pass':bool(ok),'detail':detail})
def exact(name,left,right):
    residual=sp.factor(sp.together(left-right))
    check(name,residual==0,str(residual))
def textn(x):
    return mp.nstr(x,65)

a,q,d,F,H,v,fd,V,Q,du2,Tex,boxF,Lambda,rho,A4,f4,fh,mu4,M4=sp.symbols('a q d F H v fd V Q du2 Tex boxF Lambda rho A4 f4 fh mu4 M4', real=True)
t,z,h,ell,c,s,x,y=sp.symbols('t z h ell c s x y', real=True)
nu=sp.symbols('nu',positive=True)
F=q+d

# Direct FLRW integration by parts and completion of the expansion-rate square.
# The result is also the covariant Weyl scalar metric after the F/q transform.
Zuu=q-3*a*d
Lkin=-3*F*H**2-3*H*fd+Zuu*v**2
completed=-3*F*(H+fd/(2*F))**2+Zuu*v**2+3*fd**2/(4*F)
exact('homogeneous kinetic Schur completion',Lkin,completed)
kuu=sp.factor((Zuu+3*(2*sp.sqrt(a)*d)**2/(4*F))/F)
expected=(1+(1-3*a)*z)/(1+z)**2
exact('full u kinetic metric from Schur complement',kuu.subs(d,q*z),expected)
exact('x and y Weyl kinetic multiplier',q/F,1/(1+d/q))
exact('Jordan Ricci integration-by-parts scalar coefficient',-3*a*d+6*a*d,3*a*d)
exact('matter coupling norm', (sp.sqrt(a)/(1+z))**2/expected,a/(1+(1-3*a)*z))

# Original-frame auxiliary variations retain all of L0, with d independent of q.
L0=sp.Rational(1,2)*sp.Symbol('R')-Q-2*V
R=sp.Symbol('R')
action=q*L0+d*R/2+3*a*d*du2-(Lambda+rho)*A4+Lambda*f4/mu4+q*q*fh/(2*M4)
exact('original q variation',sp.diff(action,q),L0+q*fh/M4)
exact('Lambda variation',sp.diff(action,Lambda),-A4+f4/mu4)
delta=sp.Symbol('delta')
shifted=action.subs({rho:rho+delta,Lambda:Lambda-delta},simultaneous=True)
exact('constant-vacuum shift of complete action',shifted-action,-delta*f4/mu4)

# Metric trace via conformal inverse-metric variation plus the local F derivative.
QZ=q*Q-3*a*d*du2
U=2*q*V+(Lambda+rho)*A4
lam=sp.Symbol('lam',positive=True)
scale_bulk=lam**-2*(F*lam*R/2-lam*QZ-U)
exact('algebraic metric trace by inverse-metric scaling',-2*sp.diff(scale_bulk,lam).subs(lam,1),F*R-2*QZ-4*U)
Rtrace=(2*QZ+4*U-Tex+3*boxF)/F
qL0=sp.factor(q*(Rtrace/2-Q-2*V))
printed=-q*d*Q/F-3*q*a*d*du2/F+2*q*(q-d)*V/F+2*q*(Lambda+rho)*A4/F-q*Tex/(2*F)+3*q*boxF/(2*F)
exact('full traced q constraint',qL0,printed)
exact('trace reduces to AUX at zeta zero',qL0.subs({d:0,boxF:0}),2*q*V+2*(Lambda+rho)*A4-q*Tex/2)

# Work in t=alpha*u; h=c*exp(4t), z=s*exp(2t). This derivative keeps c,s fixed.
def dt(expr):
    return sp.diff(expr,t)+2*z*sp.diff(expr,z)+4*h*sp.diff(expr,h)
vv=sp.Rational(3,2)+ell*t*t/2
potential_full=vv+(a/2-t+2*t*t/a)*x*x+a*y*y/3+h
hat_potential=potential_full/(1+z)**2
metric_eq=(1+z)*R-8*(vv+h)
scalar_eq=ell*t+4*h-z*R/2
solutions=sp.solve([metric_eq,scalar_eq],[R,h],dict=True)
assert len(solutions)==1
station=solutions[0]
hs=sp.factor(station[h]);rs=sp.factor(station[R])
exact('vacuum elimination h',hs,z*vv-ell*t*(1+z)/4)
exact('vacuum H_g squared',rs/12,1+ell*(t*t/3-t/6))
bb=sp.factor((rs/2-2*vv)*sp.exp(-4*t))
exact('vacuum flux ratio',bb,(3+ell*(t*t-t))*sp.exp(-4*t))
grad=dt(hat_potential)
exact('stationary hat potential gradient',grad.subs({x:0,y:0,h:hs}),0)
direct_exp=(vv+c*sp.exp(4*t))/(1+s*sp.exp(2*t))**2
exact('chain derivative agrees with explicit exponential differentiation',dt(dt(hat_potential)).subs({x:0,y:0,z:s*sp.exp(2*t),h:c*sp.exp(4*t)}),sp.diff(direct_exp,t,2))
hess=sp.diag(dt(dt(hat_potential)),sp.diff(hat_potential,x,2),sp.diff(hat_potential,y,2)).subs({x:0,y:0,h:hs})
J=1+(1-3*a)*z
kin=sp.diag(J/(a*(1+z)**2),4*a/(9*(1+z)),a/(3*(1+z)))
masses=sp.simplify(kin.inv()*hess)
mu_print=(a*ell*(1-4*t)+z*(a*ell*(1-6*t)+8*a*vv))/((1+z)*J)
mx_print=(sp.Rational(9,4)-9*t/(2*a)+9*t*t/(a*a))/(1+z)
my_print=2/(1+z)
for i,expected_mass in enumerate((mu_print,mx_print,my_print)):
    exact('fixed-constant canonical Hessian component '+str(i),masses[i,i],expected_mass)
for field in (x,y):
    exact('mixed t/'+str(field)+' Hessian',sp.diff(dt(hat_potential),field).subs({x:0,y:0}),0)
exact('mixed x/y Hessian',sp.diff(hat_potential,x,y),0)
B2=sp.exp(2*t)/(1+z)
physical_u=sp.factor(masses[0,0]/B2)
exact('physical origin u mass',physical_u.subs({t:0,z:s}), (a*ell*(1+s)+12*a*s)/(1+(1-3*a)*s))
exact('origin compensating constant',hs.subs({t:0,z:s}),3*s/2)
exact('fixed C0 origin stationarity failure',scalar_eq.subs({t:0,h:0,R:12/(1+s),z:s}),-6*s/(1+s))
eq_C0=(1+z)*ell*t-4*z*vv
implicit_s=-sp.diff(eq_C0.subs(z,s*sp.exp(2*t)),s).subs({s:0,t:0})/sp.diff(eq_C0.subs(z,s*sp.exp(2*t)),t).subs({s:0,t:0})
exact('fixed C0 small s displacement',implicit_s,6/ell)

# Neighboring ratio changes across sectors at fixed q,zeta,a,nu,H_v.
te=sp.factor(1/sp.diff(bb,t).subs(t,0))
ct=hs.subs(z,s*sp.exp(2*t))*sp.exp(-4*t)
GJ=sp.exp(2*t)/(1+s*sp.exp(2*t))
HJ=sp.sqrt(rs/12)*sp.exp(-t)
exact('t flux derivative',te,-1/(ell+12))
exact('c flux derivative',sp.diff(ct,t).subs(t,0)*te,(ell*(1+s)+12*s)/(4*(ell+12)))
exact('H_J flux derivative',sp.diff(HJ,t).subs(t,0)*te,sp.Rational(1,12))
exact('tensor G absolute flux derivative',sp.diff(GJ,t).subs(t,0)*te,-2/((ell+12)*(1+s)**2))
exact('tensor G relative flux derivative',sp.diff(GJ,t).subs(t,0)*te/GJ.subs(t,0),-2/((ell+12)*(1+s)))

# Decisive adverse controls. These are reviewer formula mutations, not author-runner tests.
adverse=[]
naive=sp.factor((1-3*a*z)/(1+z))
at={a:sp.Rational(1,5),z:3}
adverse.append({'name':'omit Weyl Ricci mixing','naive_uu':str(naive.subs(at)),'complete_uu':str(expected.subs(at))})
check('Weyl mixing omission is detected',naive.subs(at)<0 and expected.subs(at)>0,adverse[-1])
trace_delta=sp.factor(qL0-printed.subs(boxF,0))
exact('boxF omission residual',trace_delta,3*q*boxF/(2*F))
adverse.append({'name':'omit boxF in traced q equation','example_residual':str(trace_delta.subs({q:1,d:sp.Rational(1,10),boxF:sp.Rational(-2,5)}))})
check('boxF omission is nonzero on varying-field jet',trace_delta.subs({q:1,d:sp.Rational(1,10),boxF:sp.Rational(-2,5)})!=0,adverse[-1])
wrong_hessian=dt(dt(hat_potential.subs({x:0,y:0,h:hs}))))
correct_hessian=dt(dt(hat_potential)).subs({x:0,y:0,h:hs})
gap=sp.factor(wrong_hessian-correct_hessian)
check('differentiating after varying-C elimination is rejected',gap.subs({a:sp.Rational(1,10),ell:2,t:0,z:sp.Rational(1,5)})!=0,str(gap))

# Exact local-sign examples and a constructive second root.
negative_mass=physical_u.subs({a:sp.Rational(1,5),ell:5,t:0,z:sp.Rational(-1,2)})
check('positive kinetic negative local mass example',negative_mass==sp.Rational(-7,8),str(negative_mass))
E=mp.e**8
ell_w=3*(E-1)/2
a_w=mp.mpf(1)/10
t_w=mp.mpf(2);z_w=mp.mpf(2);s_w=2*mp.exp(-4)
v_w=mp.mpf('1.5')+ell_w*t_w*t_w/2
c_w=(z_w*v_w-ell_w*t_w*(1+z_w)/4)*mp.exp(-4*t_w)
R_w=8*(v_w+c_w*mp.exp(4*t_w))/(1+z_w)
b_w=(R_w/2-2*v_w)*mp.exp(-4*t_w)
pot=lambda T,X,Y:(mp.mpf('1.5')+ell_w*T*T/2+(a_w/2-T+2*T*T/a_w)*X*X+a_w*Y*Y/3+c_w*mp.exp(4*T))/(1+s_w*mp.exp(2*T))**2
kin_w=[(1+(1-3*a_w)*z_w)/(a_w*(1+z_w)**2),4*a_w/(9*(1+z_w)),a_w/(3*(1+z_w))]
mass_w=[mp.diff(lambda T:pot(T,0,0),t_w,2)/kin_w[0],mp.diff(lambda X:pot(t_w,X,0),0,2)/kin_w[1],mp.diff(lambda Y:pot(t_w,0,Y),0,2)/kin_w[2]]
check('constructed nonzero root has b3',abs(b_w-3)<mp.mpf('1e-80'),textn(b_w-3))
check('constructed nonzero root has full positive kinetic metric',all(k>0 for k in kin_w))
check('independently differentiated second-root masses positive',all(m>0 for m in mass_w))
witness={'a':textn(a_w),'ell':textn(ell_w),'nu':textn(a_w*ell_w),'t':textn(t_w),'z':textn(z_w),'s':textn(s_w),'c':textn(c_w),'b':textn(b_w),'kinetic_txy':list(map(textn,kin_w)),'mhat_squared_over_Hv2':list(map(textn,mass_w)),'mJ_squared_over_Hv2':[textn(m*(1+z_w)*mp.exp(-2*t_w)) for m in mass_w],'HJ_over_Hv':textn(mp.sqrt(R_w/12)*mp.exp(-t_w)),'same_s_origin_c':textn(3*s_w/2)}

# Independent domain samples, including both degeneracies and negative F.
domain=[]
for av in (mp.mpf('0.0001'),mp.mpf('0.1'),mp.mpf(1)/3,mp.mpf('0.5'),mp.mpf(1)):
    for zv in (mp.mpf('-1.1'),mp.mpf('-1'),mp.mpf('-.99'),mp.mpf('-.5'),mp.mpf('0'),mp.mpf('.5'),mp.mpf('2'),mp.mpf('10')):
        Fv=1+zv;Jv=1+(1-3*av)*zv
        expected_domain=Fv>0 and Jv>0
        if Fv!=0:
            raw_kin=(1-3*av*zv)/Fv+3*av*zv*zv/Fv**2
            actual_domain=Fv>0 and raw_kin>0
            check('domain '+textn(av)+' '+textn(zv),expected_domain==actual_domain)
        else:
            actual_domain=False
        domain.append({'a':textn(av),'z':textn(zv),'F_over_q':textn(Fv),'J':textn(Jv),'positive':bool(actual_domain)})

# Solve original metric/scalar/flux equations simultaneously, not the eliminated b(t).
secants=[]
for ell_v,s_v in [(mp.mpf(4),mp.mpf('-.5')),(mp.mpf(4),mp.mpf('1.5')),(mp.mpf(10),mp.mpf(0)),(mp.mpf(10),mp.mpf('.2')),(mp.mpf(100),mp.mpf(3))]:
    derivative=[-1/(ell_v+12),(ell_v*(1+s_v)+12*s_v)/(4*(ell_v+12)),mp.mpf(1)/12,-2/((ell_v+12)*(1+s_v)**2)]
    for step in (mp.mpf('1e-4'),mp.mpf('1e-6'),mp.mpf('1e-8')):
        solutions_numeric=[]
        for eps in (-step,step):
            def eq(T,C,RR):
                zz=s_v*mp.exp(2*T);vv=mp.mpf('1.5')+ell_v*T*T/2
                return ((1+zz)*RR-8*(vv+C*mp.exp(4*T)),ell_v*T+4*C*mp.exp(4*T)-zz*RR/2,(RR/2-2*vv)*mp.exp(-4*T)-3-eps)
            T,C,RR=mp.findroot(eq,(-eps/(ell_v+12),3*s_v/2,mp.mpf(12)),tol=mp.mpf('1e-78'),maxsteps=40)
            residual=max(abs(r) for r in eq(T,C,RR))
            check('simultaneous equations residual '+textn(ell_v)+' '+textn(s_v)+' '+textn(eps),residual<mp.mpf('1e-72'),textn(residual))
            obs=[T,C,mp.sqrt(RR/12)*mp.exp(-T),mp.exp(2*T)/(1+s_v*mp.exp(2*T))]
            solutions_numeric.append(obs)
        slopes=[(solutions_numeric[1][i]-solutions_numeric[0][i])/(2*step) for i in range(4)]
        errors=[abs(slopes[i]-derivative[i]) for i in range(4)]
        check('central derivative convergence '+textn(ell_v)+' '+textn(s_v)+' '+textn(step),max(errors)<step*step, [textn(r) for r in errors])
        secants.append({'ell':textn(ell_v),'s':textn(s_v),'step':textn(step),'minus_observables':list(map(textn,solutions_numeric[0])),'plus_observables':list(map(textn,solutions_numeric[1])),'slopes':list(map(textn,slopes)),'absolute_derivative_errors':list(map(textn,errors))})

# Asymptotic checks keep s positive and a<1/3, as the handwritten statement does.
exact('u kinetic large-z leading coefficient',sp.limit(z*expected,z,sp.oo),1-3*a)
ap,sp_,cp=sp.symbols('ap sp cp',positive=True)
tau=sp.symbols('tau',positive=True)
asym_v=(sp.Rational(3,2)+ell*tau*tau/2+cp*sp.exp(4*tau))/(1+sp_*sp.exp(2*tau))**2
exact('noncoercive potential endpoint',sp.limit(asym_v,tau,sp.oo),cp/sp_**2)

result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Original-frame variations, FLRW kinetic Schur complement, fixed-constant chain differentiation, direct high-precision potential differentiation and simultaneous three-equation roots; no author code imported.','python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__,'digits':mp.mp.dps,'checks':checks,'pass_count':sum(r['pass'] for r in checks),'fail_count':sum(not r['pass'] for r in checks),'adverse_formula_controls':adverse,'nonzero_positive_hessian_witness':witness,'kinetic_domain_rows':domain,'original_equation_secants':secants}
out=P/'INDEPENDENT_RESULTS_v1.json'
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass_count'],'fail':result['fail_count'],'witness':witness},indent=2))
sys.exit(1 if result['fail_count'] else 0)
