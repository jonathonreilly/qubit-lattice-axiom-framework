#!/usr/bin/env python3
"""Exact-rational origin sign classification; no author code imported."""
from fractions import Fraction as Q
from pathlib import Path
import datetime, hashlib, json
p=Path(__file__).resolve().parent
a,nu=Q(1,3),Q(4)
checks=[]
rows=[]
for s,expected in [(Q(-51,100),'negative'),(Q(-1,2),'zero'),(Q(-49,100),'positive')]:
    F=1+s
    J=1+(1-3*a)*s
    numerator=nu*(1+s)+12*a*s
    mass=numerator/J
    classification='negative' if mass<0 else ('positive' if mass>0 else 'zero')
    row={'a':str(a),'nu':str(nu),'s':str(s),'F_over_q':str(F),'J':str(J),'mass_numerator':str(numerator),'mJu_squared_over_Hv2':str(mass),'classification':classification}
    rows.append(row)
    checks.append({'name':'exact rational sign at s='+str(s),'pass':F>0 and J>0 and classification==expected})
checks.append({'name':'middle point is the exact local-mass boundary','pass':Q(-1,2)==-nu/(nu+12*a)})
checks.append({'name':'zero is neither negative nor strictly positive','pass':not Q(0)<0 and not Q(0)>0})
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'stdlib fractions, exact rational evaluation of independently derived origin Hessian','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'checks':checks,'pass_count':sum(x['pass'] for x in checks),'fail_count':sum(not x['pass'] for x in checks),'parent_runner_read_or_executed':False}
(p/'EXACT_ZERO_BOUNDARY_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(bool(result['fail_count']))
