# Independent derivation behind the numerical check

Scope: the frozen v1 two-derivative action, at fixed positive q and H_v,
with supplied a, nu and zeta. This derivation documents the numerical oracle;
the independent handwritten reviewer retains the wider proof assignment.
Set q=H_v=1 for the dimensionless output, and t=sqrt(a)u.

## Off-shell frame transformation and normalization

Write E=exp(2t), F=1+sE and z=sE. The pulled-back Ricci term has coefficient
F R/2 and the u derivative coefficient 1-3az. In t coordinates this is
Z_tt=1/a-3z. Weyl normalization contributes (3/4)(F_t/F)^2.
Consequently

    Khat_tt = (1/a-3z)/F + 3z^2/F^2
            = [1+(1-3a)z]/(a F^2),
    Khat_xx = 4a/(9 D F),
    Khat_yy = a/(3 D F),
    D=1+2(1+a)(x^2+y^2)/3.

The displayed mixing is indispensable; the raw Z_tt sign is not the
propagating kinetic sign. F>0 supplies the positive tensor sector and positive
x,y entries. The remaining condition is J=1+(1-3a)z>0.
For -1<z<0, J=F-3az>F>0.

The physical matter factor obeys B^2=E/F and (ln B)_t=1/F.
Thus its squared norm is (1/F)^2/Khat_tt=a/J. Constant-background inverse
tensor Planck normalization is B^2, not F/E.

The normalized potential as a function of independent (t,x,y,c) is

    U = [3/2 + nu t^2/(2a)
         +(a/2-t+2t^2/a)x^2 +(a/3)y^2+c exp(4t)] / F^2.

It is differentiated with c fixed. The action contains -2qU and kinetic
-qKhat_ii(dphi_i)^2. With canonical increment dvarphi_i=sqrt(2qKhat_ii)dphi_i,
the mass square is U_ii/Khat_ii. There is no extra factor two or one-half.
Off-diagonal potential Hessians vanish at x=y=0. At a stationary point the
connection correction to the potential Hessian vanishes as well.

## Stationarity, physical clocks and flux function

Let ell=nu/a and v=3/2+ell t^2/2. The numerator of U_t is

    [ell t+4c exp(4t)]F -4z[v+c exp(4t)].

Setting it to zero gives

    c(t) exp(4t)=zv-(ell t/4)F.

This relation is substituted only after taking local derivatives. The
constant-frame metric equation gives

    Hhat^2 = 2U/3,
    H_g^2 = F Hhat^2 = 1+ell(t^2/3-t/6),
    H_J^2 = Hhat^2/B^2 = exp(-2t)H_g^2.

The original q constraint uses L0=R/2-2V at a constant vacuum. Since R=12H_g^2,

    b(t)=L0/exp(4t)
        =[6H_g^2-2v]exp(-4t)
        =[3+ell(t^2-t)]exp(-4t).

These constant-field cancellations do not extend the old time-dependent
solution into the new action.

For ell>0, t<0 gives b(t)>3; 0<t<=1 gives b(t)<3.
For t>1 the extrema satisfy

    b_t=exp(-4t)[ell(-4t^2+6t-1)-12],
    t_+=[3+sqrt(5-48/ell)]/4.

The reviewer counts two additional roots only when t_+>1 and b(t_+)>3,
then brackets one root in (1,t_+) and one in (t_+,infinity).
This differs from the author's L(t)-minimum construction.
The tangent boundary is solved independently from b=3 and b_t=0:

    t_critical = 1.3070780865454137277469247075449728016642321904...,
    ell_critical = 1386.318108994989330530572455573736429...

No supplied parameter pair is tangent. A root count does not establish
admissibility; each s still needs F>0 and J>0.

## Local masses and the exact sign exception

At fixed c, differentiate U twice before setting c=c(t).
The t component becomes

    U_tt = [ell(1-4t)+z{ell(1-6t)+8v}]/F^3.

Dividing by Khat_tt gives the u-mode mass in normalized Einstein units,

    mhat_u^2=[nu(1-4t)+z{nu(1-6t)+8av}]/(FJ).

The transverse expressions are

    mhat_x^2=[9/4-9t/(2a)+9t^2/a^2]/F,
    mhat_y^2=2/F.

All physical Jordan mass squares divide these by B^2. Since B^2 is positive
in the retained domain this preserves exact signs, but not their magnitudes.

At t=0, c=3s/2 and

    mJ_u^2=[nu(1+s)+12as]/[1+(1-3a)s].

On the rational input grid the numerator can be classified exactly.
For (a,nu,s)=(1/3,4,-1/2) it vanishes, while F=1/2 and J=1.
A -2.45e-91 numerical canonical Hessian at that point is a rounding residue,
not a negative exact eigenvalue. There are 31 strictly negative admitted
origin cases, one zero, 127 positive, and nine excluded origin parameter sets.

The 19 admitted nonzero positive-Hessian rows are reproduced by differentiating
the off-shell action. They remain local fixed-parameter mass statements:
the constrained boundary problem can limit perturbations, and no global
stability or observed branch-selection conclusion follows.

## Neighboring flux and fixed-C branches

At t=0,

    b_t=-(ell+12),
    c_t=-ell(1+s)/4-3s,
    (H_J)_t=-1-ell/12,
    (B^2)_t=2/(1+s)^2.

Implicit differentiation with b=3+epsilon therefore gives

    t_epsilon=-1/(ell+12),
    c_epsilon=[ell(1+s)+12s]/[4(ell+12)],
    (H_J)_epsilon=1/12,
    (B^2)_epsilon=-2/[(ell+12)(1+s)^2].

The tensor expression is an absolute derivative around B^2(0)=1/(1+s).
Its relative derivative multiplies by (1+s). The review obtains the finite
secants by separately solving b(t)=3+epsilon and recomputing c,U,B at that root.
The declared tolerance 2|epsilon| is only the frozen finite-grid control.

At c=0 the stationarity numerator instead is

    ell t(1+s exp(2t))-4s exp(2t)[3/2+ell t^2/2].

Its derivative with respect to t at (t,s)=(0,0) is ell, while the s derivative
is -6, so t_s=6/ell. This is not the fixed-b origin branch.
The reviewer bracketed the off-shell U_t rather than copying this root helper,
and checked all 42 supplied small-s cases and the declared remainder bound.

## Trace and scope of time-dependent inheritance

For the reduced scalar-tensor action, let Zkin=Z_AB partial phi^A partial phi^B
and W=2qV+Ltilde A^4. The metric trace is

    -F R=-2Zkin-4W+T_ex-3 box F.

Thus F R=2Zkin+8qV+4Ltilde A^4-T_ex+3 box F.
Substituting in the original q L0 yields

    q L0= -q d Q/F -3q a d(partial u)^2/F
          +2q(q-d)V/F +2q Ltilde A^4/F
          -q T_ex/(2F)+3q box F/(2F).

The supplied zeta does not vary with q in the original action. Varying first
therefore leaves the original auxiliary constraints intact, but the new trace
contains the derivative contribution and changed weights. Neither old finite
history integrals nor the old exact fluid orbit may be substituted unchanged.

For positive s and a<1/3, U tends to c/s^2 along x=y=0,t->infinity and
Khat_uu scales as (1-3a)/(s exp(2t)). The canonical distance to that end is
finite. This prevents simply importing the old coercive energy proof; it
does not itself prove a runaway or a new global instability theorem.

