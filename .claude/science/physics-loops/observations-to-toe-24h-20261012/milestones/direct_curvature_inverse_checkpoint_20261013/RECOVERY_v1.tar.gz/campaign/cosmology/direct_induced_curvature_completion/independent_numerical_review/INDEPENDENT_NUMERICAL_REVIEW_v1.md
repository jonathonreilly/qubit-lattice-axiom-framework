# Independent numerical review — induced-curvature completion v1

This is a focused implementation and numerical-source check of the parent's
conditional Ricci-operator block. It is not a formal audit, a publication gate,
or an independent empirical test. The parent remains the scientific author.
All reviewer writes are inside this review directory.

**Disposition: original v1 requires a narrow correction.** Its reported
negative-origin-mass count is 32; the exact supplied grid contains 31 negative
origin masses and one zero. Three meaningful copied-source mutations also
survive the original assertion suite. The original scientific values otherwise
agree with the independent action-based recomputation. The 19 nonzero
positive-local-Hessian grid rows are confirmed within the stated local scope.

## Exact sources and execution

The reviewed author runner is
`check_induced_curvature_v1.py`,
SHA256 `aae87ef2cd5a0891321bdbb42c6be39f9b21affc897137cea9fc2c359c782a64`.
The original result is `evidence_v1/RESULTS.json`,
SHA256 `888eb511c6c857d09d89f145d94c8dfba2420d1f5da69bd87a0a016d84d5cd53`.
The full handwritten note is
`b37f6a0bf03a9a178c638266f4d6cffedce4150ed89c03ab6416a71c21ac225e`.

The first author execution ran from 2026-10-13T07:02:08.819991Z to
07:02:12.002268Z, exited 0, and reported 5195 passed, 0 failed. All eight
frozen inputs were unchanged. This execution is preserved as evidence;
its passing total does not establish the correctness of the rounded sign count.

The complete protocol, numerical details, source ledger, runner, handwritten
note, all original execution evidence, and the three inherited action notes
were read. The 23 original/snapshot pairs in `SOURCE_FREEZE_v1.json` include
all eight author inputs and the draft correction history. The final receipt
binds all these original identities and the entire reviewer evidence tree.

The pre-execution draft changed an unconditional secant admissibility assertion
to a comparison of the two domain criteria. It already retained excluded
response rows. The preserved draft diff is `PRE_EXECUTION_DRAFT_CHANGE.diff`.
The amendment predates the first scientific execution; it is not a failed run.

## Independent method and positive coverage

No author module or helper was imported or executed as positive evidence.
The reviewer used 110-digit mpmath and a separately constructed SymPy action,
working in coordinates (t,x,y), t=sqrt(a)u. The off-shell normalized potential
and kinetic tensor were differentiated before substituting the stationary
C(t). This keeps C, q and zeta fixed in the local Hessian calculation.

Root enumeration used extrema of the boundary function b(t) itself, followed
by signed bracketing on its monotone intervals. The author instead locates the
minimum of L(t)=3(expm1(4t))/(t(t-1)) and brackets its two intersections.
The reviewer obtained the critical point by solving b=3 and b_t=0
simultaneously. The fixed-C=0 branch was found by bracketing the derivative
of the full off-shell normalized potential, instead of invoking the author's
explicit force helper or its local findroot call.

For every retained row the reviewer recalculated the kinetic domain, scalar
coupling norm, stationary C, Hhat, H_J, tensor coupling, canonical and physical
mass squares, and Hessian flags. Every scientific dictionary shape, list
length, parameter label, numerical leaf, exclusion label and aggregate was
compared. Finite-flux derivatives came from implicit differentiation of the
action-derived b and stationary C; finite secants were independently evaluated.

The first independent run, preserved unchanged, took 6.095 seconds and reported
**27092 passed, 1 failed, of 27093 checks**. This total comprises nine symbolic
action identities, 23 snapshot checks, 1800 derivation/approximation controls,
15614 scientific output/shape/leaf comparisons, and 9647 author-assertion and
source-bookkeeping checks. These are implementation checks, not 27093 separate
physical observations. The sole failed comparison was the incorrect negative
origin count. Maximum normalized error in the other numerical output
comparisons was below 5e-75, using abs(actual-expected)/max(1,abs(expected))
and the preselected comparison tolerance 1e-60.

Coverage of the complete supplied grid:

| Section | Rows | Explicit exclusions |
|---|---:|---:|
| Kinetic diagnostic | 280 | 60 |
| Root census | 21 | None; 31 roots across the parameter pairs |
| Constant-vacuum rows | 248 | 34 |
| Neighboring-flux response | 336 | 12 |
| Fixed-C=0 branch | 42 | None |

The 31 roots consist of 21 origins and ten nonzero roots. Five parameter pairs
have three roots: all three nu values at a=1e-6, and nu=1,4 at a=1/2499.
All other supplied pairs have only the origin.

The additional exact-rational origin classification checks all 168 origin
parameter combinations: 127 positive, 31 negative, one zero, and nine outside
the kinetic domain. The stored per-row positive-Hessian flags agree with this
classification; the negative-count aggregate is the error.

## Required finding R1: exact zero counted as negative

At a=1/3, nu=4, s=-1/2, t=0 the physical u mass numerator is exactly

    nu(1+s)+12 a s = 4(1/2)+12(1/3)(-1/2) = 0.

F/q=1/2 and J=1, so this point has positive kinetic energy but a zero u Hessian
eigenvalue. The author numerical second derivative returns

    mhat_u^2/Hv^2 = -2.4545467326488632765...e-91,
    mJ_u^2/Hv^2   = -1.2272733663244316383...e-91.

That residue is harmless as an approximate representation of zero within the
numerical tolerance. It is not evidence of a negative exact eigenvalue.
The subsequent strict floating '<0' count promotes the residue into a
categorical statement and produces 32 instead of 31.

Correction required: use the exact rational sign of the origin numerator for
this rational fixture grid, distinguish zero from negative, and bind the
serialized aggregate to that classification. Preserve the original result.
This correction does not remove the 31 real negative-origin examples, change
the 19 positive nonzero examples, or supply a global stability result.

The actual failed independent run, its stdout/stderr, launch and execution
receipts, and exact-rational supplement are preserved. No passing independent
science was rerun after discovering the count error.

## Mutation coverage and required finding R2

Each copied-source mutant contains all eight actual input files, a newly
generated source freeze, its exact one-site diff, launch and execution
receipts, stdout/stderr, and full result. All eight source identity checks
passed in every mutant. Assertions and tolerances were not weakened. Failures
below therefore arise from the mathematical checks, not a stale-hash rejection.

| Source mutation | Author checks passed / failed | New keyed output discrepancies |
|---|---:|---:|
| Reverse Ricci/Weyl kinetic mixing sign | 4730 / 465 | 430 |
| Omit physical clock conversion H_J=Hhat/B | 5002 / 193 | 193 |
| Serialize canonical masses as physical masses | 5195 / 0 | 578 |
| Drop domain-excluded vacuum rows | 5195 / 0 | 34 missing rows |
| Set every admitted Hessian flag to true | 5195 / 0 | 69 |
| Omit both nonzero-root branches | 4504 / 6 | 91, including 80 missing rows |

The three surviving mutations establish concrete output-assertion gaps.
The unmodified output has the correct physical mass conversion and retains
the 34 excluded vacuum rows; this is a regression-coverage finding, not an
accusation that those unmodified fields are incorrect. Making every flag true
changes 68 flags and the nonzero-positive count from 19 to 55, while the
original existential witness check still passes.

Correction required: after constructing the result data, verify physical
masses against the correct frame relation and action-derived masses, verify
the complete expected row keys including excluded domains, and verify each
Hessian classification and the resulting aggregate counts. A tolerance-only
mass comparison is insufficient for the exact-zero classification in R1.

The first saved mutant comparison uses positional list alignment. Deleting
rows consequently produces cascading positional differences; those raw
diagnostics remain preserved and are not reported as independent errors.
`KEYED_MUTANT_OUTPUT_COMPARISON_v1.json` instead aligns rows by their supplied
parameters/root index. It also separates the original R1 failure from
mutation-induced discrepancies. This changes diagnostic counting only; no
mutant or positive computation was rerun.

The 578 meaningful mass-output differences omit the one exact zero whose tiny
numerical residue remains below the comparison tolerance. The successful
root-removal control shows the independent census catches omitted branches;
it does not repair the distinct output-only gaps.

## Action, frame and physical interpretation

The Ricci operator is a new, real supplied coefficient independent of the
auxiliary q, Lambda and constant matter-vacuum coefficient. It is not an
observed zeta, a computed quantum coefficient, or a fitted calibration.
The three-form constraints are varied in the original frame before fixing q.

The normalized kinetic tensor includes both Z/F and the Weyl mixing term.
The correct domain is F>0 and J>0. The negative sign of an isolated added
derivative term is not enough to diagnose the full kinetic energy. Raw
kinetic numbers outside this domain are diagnostic output, not admissible
physical solutions; all exclusions remain visible in the original data.

The Hessian is local at fixed integration constants. Since the stationary
gradient vanishes, the connection part of the covariant potential Hessian
vanishes there. The action is q[Rhat/2-Khat(dphi)^2-2Vhat], so local canonical
mass squares are Vhat_ii/Khat_ii, not half that value. Physical constant-frame
mass squares additionally divide by B^2. H_J likewise includes the physical
clock; the tensor coupling scales as B^2 rather than its inverse.

The 19 nonzero positive-Hessian rows are genuine local examples in the supplied
grid. For example a=1e-6, nu=.25, s=.01 has a large root
t=3.34816257015649..., positive F and J, and positive three-field Hessian.
Its H_J/Hv=31.33334621156349... and tensor ratio=89.00405100995052... also show
why matching the boundary number alone is not matching the desired observed
vacuum. No branch probability or observed selection follows.

A local bulk Hessian at fixed parameters is not the perturbation stability
of the constrained finite-boundary problem, nor a global homogeneous theorem.
General-history fluxes include the box-F term and changed weights; the old
zero-zeta exact fluid orbit and its coercive energy proof cannot be inherited.
The supplied future-ratio condition is kept distinct from finite fluxes.
There is no new empirical likelihood, independent observation test, or TOE
claim supported by this numerical grid.

## Scope, limitations and disposition

The inherited analytic, auxiliary and matter-vacuum derivations were read to
check the displayed action and normalization. Earlier observational calibrations
were not refitted or recomputed. The present runner operates on dimensionless
synthetic parameters and does not consume CODATA measurements, a photon table,
or a newly measured cosmological coefficient. No external primary paper was
used as an unexamined positive oracle for the new calculation.

This review checks the finite grid and its complete serialized results. It is
not a machine-interval proof over all parameters, an exhaustive corruption
search, or a quantum-consistency analysis. The separate handwritten reviewer
owns the broader proof and boundary-assumption review.

The parent accepted R1/R2 and intends a separately versioned correction. That
future version is outside this immutable report. Original v1 is **numerically
supported except for its zero/negative count, with three demonstrated assertion
coverage gaps requiring repair**. No source-readiness or landing PASS is
conferred by this report.

## Reproduction and evidence

- `independent_recompute_v1.py`: separate action differentiation, roots,
  frame calculations, all-row comparison and stored-assertion consistency.
- `INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json`: complete independently computed
  scientific sections, retaining all exclusions.
- `INDEPENDENT_RESULTS_v1.json`: the actual 27092/1 result, never overwritten.
- `classify_and_compare_v1.py`: exact rational sign supplement and keyed
  comparison of already saved mutant outputs; no positive science rerun.
- `EXACT_ORIGIN_CLASSIFICATION_v1.json`: all 168 exact classifications.
- `run_mutations_v1.py`, `MUTATION_PLAN_v1.json`,
  `MUTATION_RESULTS_v1.json` and `mutations/`: all six actual trials.
- `READING_LEDGER_v1.json`: source-reading and computation roles.
- `FINAL_RECEIPT_v1.json`: original/snapshot identities and complete review
  artifact inventory; receipt does not hash itself.

The replay commands are the indicated Python scripts with Python 3.12.8,
mpmath 1.3.0 and SymPy 1.14.0. They intentionally use exclusive output writes.
Replay in a fresh copy of the review folder without the output filenames,
preserving the original snapshot tree; never delete or overwrite this evidence.

