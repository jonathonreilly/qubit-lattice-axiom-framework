# Affected-source numerical review — induced curvature v2

**R1 and R2 are discharged for the identified original error, the three
demonstrated mutation gaps, and the frozen supplied grid.** The parent v2
correctly reports 31 negative origin masses, one exact zero, and 19 admitted
nonzero positive-local-Hessian rows. All three formerly surviving source
mutations now fail mathematical output checks with fresh full input hashes.

This is a narrow same-session affected-source review. It is not a formal audit,
a publication or landing decision, a new empirical test, or a global stability
claim. The immutable original v1 review, its actual failed count comparison,
and every original failure remain unchanged.

## Exact identities and source reading

The complete v2 runner and correction record were read, together with the full
source delta and original v2 execution evidence.

- Runner SHA256:
  28a5cbdc25910f1af6351e108469c8a2a5664bf8307dcfcd276ea61518f9b01b
- CLASSIFICATION_AND_OUTPUT_CORRECTION_v2.json SHA256:
  9b81ae618007d42c74e5c039b513ca82bf4d51e1f47542b20dbbe0311ad072dc
- First v2 RESULTS.json SHA256:
  e5e00dc0a5a477134918f3e4aa187bb1231c5635de03f42afeb21ac436190714

The author first run lasted 2.946 seconds, exited 0, and reported 9605/0.
All nine frozen inputs remained unchanged. The original action, protocol,
numerical details and inherited action premises are unchanged. The correction
record's statement that the full original review was pending describes its
earlier freeze time; the subsequently completed original report is preserved.

SOURCE_FREEZE_v1.json in this affected folder binds 32 original/snapshot pairs,
including all nine v2 inputs, all first-execution evidence, and the reused
independent v1 reference and review artifacts. All 156 previously bound paths
were checked against the original immutable v1 receipt. Its own identity is
also bound by this affected snapshot.

## Source transfer and permitted output differences

Eleven original functions are text-identical and AST-identical: number, fmt,
check, close, exact, symbolic_controls, kinetic_controls, bisect, boundary_roots,
vacuum_data and full_potential. The new functions are hessian_class and
serialized_controls. The changes in stationary_controls add classification,
record fields and corrected aggregates. main calls the new record checks and
advances the output schema. The original numerical equations, differentiation,
root calculations, fixture values and tolerance declarations are untouched.

Exact comparison of all original scientific fields found:

- 13304 original scientific leaves;
- 13303 retain exactly the same JSON values, including all numerical strings;
- the only altered old field is origin_negative_mass_count, from 32 to 31;
- 214 admitted vacuum rows gain local_Hessian_class;
- one aggregate origin_zero_mass_count=1 is added.

The existing positive_local_Hessian flags are unchanged. The tiny raw numerical
mass residue at the exact zero is also unchanged; the correction classifies
it properly instead of overwriting the historical numerical value.

All 5187 original non-source assertion objects are exactly unchanged.
V2 adds 214 mass-classification resolution checks and 4195 checks of the
constructed output records. Together with nine source checks this gives
5187+214+4195+9=9605. The checks called serialized_controls run on the completed
string-valued result records before the JSON file is written. This review
additionally inspects the actual written JSON.

The reviewer compared v2 with the already saved independent 110-digit scientific
reference. No original root, potential, Hessian, frame or positive numerical
calculation was rerun. The successful affected comparison contains 21325 checks,
all passing; many are value, structure, identity and exact source comparisons,
not distinct scientific experiments.

## R1: exact sign of the origin mass

At t=0 in the positive kinetic domain,

    mJ,u^2/Hv^2 = [nu(1+s)+12as] / [1+(1-3a)s].

The denominator is positive. Therefore exact rational evaluation of the
numerator is sufficient for the sign on these rational fixtures. The v2 helper
uses SymPy Rational on the original parameter labels rather than the rounded
second derivative. The reviewer independently uses Python Fraction and the
previously derived physical mass relation to confirm all admitted origin
classifications.

At (a,nu,s)=(1/3,4,-1/2), the numerator is exactly zero, F=1/2, J=1.
V2 records degenerate, excludes the point from both strictly positive and
strictly negative classes, and separately checks that the raw numerical
canonical-mass residue is within the stated zero tolerance. It reports
31 negative and one zero admitted origin rows, agreeing with the prior exact
independent census. The complete origin parameter grid also has 127 positive
and nine excluded cases.

Using the u sign to classify the full local Hessian is justified here:
the transverse y mass is 2/F>0, and the x numerator is

    9[(t/a-1/4)^2+3/16] > 0.

For nonzero roots v2 refuses to infer a sign if the u mass magnitude is at most
1e-55. The smallest absolute normalized Einstein u mass among the 55 admitted
nonzero rows in the independent reference is 0.000795132390884633...,
well above that threshold. This is adequate for the frozen grid and is not
an interval proof covering every possible parameter choice.

The positive/negative/degenerate classifications and all resulting aggregate
counts agree with the saved independent results. R1 is closed in v2.

## R2: constructed-output assertions and repeated real mutations

The new record validator builds the expected vacuum keys from the protocol and
an independently evaluated boundary-extremum root count. It checks per-parameter
row counts and the complete set of keys, including excluded rows. It recalculates
F and J, verifies kinetic-domain flags and explicit exclusion records, and
checks admitted local classes, flags, stationary C, tensor/scalar coupling,
canonical masses, physical masses, Hhat and physical H_J. It separately verifies
negative, zero and nonzero-positive aggregate counts.

Each repeated trial changed exactly one producer expression in a copied v2
runner. Assertions and tolerances were unchanged. All nine actual copied
inputs were freshly hashed into the trial freeze; all nine source checks passed,
and all inputs remained unchanged during execution.

| Repeated v1 survivor | Passed | Failed | Failure mechanism |
|---|---:|---:|---|
| Serialize canonical masses as physical masses | 9027 | 578 | Physical mass checks apply the B^2 frame conversion |
| Delete domain-excluded vacuum rows | 9410 | 25 | 24 parameter census checks plus complete-key census |
| Set every admitted Hessian flag true | 9536 | 69 | 68 row flags plus the nonzero-positive aggregate |

All three programs exit 1. Every failed assertion belongs to the new
serialized.* family; no failure is caused by source identity. Exact source
diffs, fresh freezes, complete results and raw stdout/stderr are preserved
under mutations/.

The deleted-row trial removes 34 rows. It runs only 9435 assertions because
170 per-row checks disappear with them, but the independent expected census
still detects the missing records. This is the intended reason for a census
test rather than relying on whatever rows happened to be produced.

The physical-mass trial has 578 meaningful failing components; the exact-zero
component remains within the numerical tolerance. Its categorical zero status
is instead protected by R1's exact rational calculation. These controls
complement each other.

R2 is closed for all three identified gaps. The check is not claimed to detect
every possible consistent corruption. For example, producer and validator share
the hessian_class helper; the independent Fraction/reference comparison is
the external check on that helper in this review. No additional mutation family
or universal test-coverage claim is inferred.

## Preserved reviewer failure and recovery

The first affected comparison script failed before any scientific comparison
or result creation: its check helper received the function name both as a
positional argument and inside a metadata dictionary. The exact failed source
verify_affected_source_v1.py and the returned TypeError are retained in
REVIEWER_FAILURE_v1.json.

A new verify_affected_source_v2.py changes only the helper parameter/metadata
key names and the result version filename. REVIEWER_BOOKKEEPING_CORRECTION.diff
records the complete change. The successful saved-data comparison then ran in
0.528 seconds and exited 0. No scientific formula, input, tolerance or cached
independent value was modified, and no completed original positive science
or mutation was repeated during this correction.

The actual mutant failures are intended sensitivity evidence; the bookkeeping
TypeError is a reviewer implementation failure. They are recorded separately.
No parent source or immutable v1 review file was edited.

## Scope retained

The result concerns local fixed-multiplier Hessians in the explicitly supplied
two-derivative action and the frozen synthetic parameter grid. Distinct positive
Hessian vacua at the same imposed ratio can have different C. This does not
establish multiple stable vacua in one fixed-C boundary problem or global
stability under finite absolute-flux constraints. No observed zeta, calculated
quantum Ricci coefficient, empirical fit, new observation test or TOE claim is
supported by this affected check.

The original 19 nonzero positive-Hessian rows are supported; the original
negative-origin count of 32 remains visible as superseded erroneous evidence.
Only the stated v2 correction is accepted here.

## Evidence and replay

SOURCE_AND_OUTPUT_CHECK_v2.json contains the full affected comparison, original
function identities, all permitted field changes, exact-origin controls and
nonzero sign margins. MUTATION_RESULTS_v1.json contains the three actual trials.
READING_LEDGER_v1.json identifies all inspected and reused sources.
FINAL_RECEIPT_v1.json binds the original/current sources, snapshots, failed and
successful reviewer sources, complete mutation evidence and report.

The two executable recipes are repeat_survivors_v1.py and
verify_affected_source_v2.py. The latter consumes saved independent data and
does not recompute the original science. Outputs use exclusive creation.
Any replay must use a fresh copy with uncreated output paths; preserve this
entire evidence tree.

