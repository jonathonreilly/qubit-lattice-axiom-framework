#!/usr/local/bin/python3
"""Repeat only the three actual v1 survivors against the frozen v2 source."""
from pathlib import Path
import datetime as dt, hashlib, json, difflib, os, subprocess, sys, time
O=Path(__file__).resolve().parent
S=O/'snapshots'
freeze=json.loads((S/'evidence_v2/FREEZE.json').read_text())
source=S/'author_inputs/direct_induced_curvature_completion/check_induced_curvature_v2.py'
pinned='28a5cbdc25910f1af6351e108469c8a2a5664bf8307dcfcd276ea61518f9b01b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
assert sha(source)==pinned
mutations=[
 dict(id='m3_output_unconverted_physical_masses',
      old='physical_masses=[fmt(m/(B*B)) for m in mass]',
      new='physical_masses=[fmt(m) for m in mass]',
      purpose='Repeat the surviving physical-frame output error.'),
 dict(id='m4_drop_excluded_vacuum_rows',
      old='vacua.append(row);continue',new='continue',
      purpose='Repeat deletion of all excluded vacuum rows.'),
 dict(id='m5_output_all_Hessians_positive',
      old="positive_local_Hessian=classification=='positive'",
      new='positive_local_Hessian=True',
      purpose='Repeat setting every serialized admitted-Hessian flag to true; producer site reflects v2 classification syntax.')
]
save(O/'MUTATION_PLAN_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
    driver_pid=os.getpid(),author_source_sha256=pinned,mutations=mutations,
    scope='Only the three v1 survivors; all nine copied inputs freshly frozen. No assertion or tolerance changes.'))
results=[]
for mut in mutations:
    case=O/'mutations'/mut['id'];case.mkdir(parents=True)
    inputs=[]
    for r in freeze['inputs']:
        original=Path(r['path'])
        src=S/'author_inputs'/original.parent.name/original.name
        assert sha(src)==r['sha256']
        dst=case/'sources'/original.parent.name/original.name
        dst.parent.mkdir(parents=True,exist_ok=True)
        raw=src.read_bytes()
        if original.name=='check_induced_curvature_v2.py':
            old=raw.decode();assert old.count(mut['old'])==1
            new=old.replace(mut['old'],mut['new'])
            raw=new.encode()
            with (case/'MUTATION.diff').open('x') as f:
                f.write(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen_v2',tofile=mut['id'])))
            run=dst
        with dst.open('xb') as f:f.write(raw)
        inputs.append(dict(path=str(dst),sha256=sha(dst),bytes=len(raw),
                           original_path=str(original),original_sha256=r['sha256']))
    fp=case/'FREEZE.json'
    save(fp,dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),inputs=inputs))
    cmd=[sys.executable,str(run),'--freeze',str(fp),'--output-json',str(case/'RESULTS.json')]
    start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
    with (case/'stdout.txt').open('x') as out,(case/'stderr.txt').open('x') as err:
        child=subprocess.Popen(cmd,stdout=out,stderr=err)
        save(case/'LAUNCH.json',dict(pid=child.pid,started_at=start,command=cmd))
        try:rc=child.wait(timeout=60);timeout=False
        except subprocess.TimeoutExpired:
            child.kill();rc=child.wait();timeout=True
    result=json.loads((case/'RESULTS.json').read_text()) if (case/'RESULTS.json').exists() else None
    source_checks=[q for q in result['checks'] if q['name'].startswith('source.')] if result else []
    failed=[q for q in result['checks'] if not q['passed']] if result else []
    record=dict(id=mut['id'],started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),
        seconds=time.monotonic()-tic,exit_code=rc,timed_out=timeout,source_sha256=sha(run),
        counts=result['counts'] if result else None,
        source_checks_count=len(source_checks),
        source_checks_all_pass=all(q['passed'] for q in source_checks) and len(source_checks)==9,
        post_execution_inputs_unchanged=all(sha(Path(r['path']))==r['sha256'] for r in inputs),
        failed_assertions=failed,
        all_failures_are_serialized_checks=all(q['name'].startswith('serialized.') for q in failed),
        output_sha256=sha(case/'RESULTS.json') if result else None)
    save(case/'EXECUTION.json',record);results.append(record)
    print(json.dumps({k:record[k] for k in ['id','exit_code','counts','source_checks_count','source_checks_all_pass','all_failures_are_serialized_checks']}),flush=True)
save(O/'MUTATION_RESULTS_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),mutations=results))

