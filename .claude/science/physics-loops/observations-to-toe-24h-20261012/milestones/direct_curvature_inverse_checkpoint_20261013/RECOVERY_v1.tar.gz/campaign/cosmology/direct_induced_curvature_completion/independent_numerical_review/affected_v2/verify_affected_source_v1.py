#!/usr/local/bin/python3
"""Affected-source/evidence check. Reads saved independent results; no science rerun."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import ast, copy, datetime as dt, hashlib, json
O=Path(__file__).resolve().parent
P=O.parent;B=P.parent
S=O/'snapshots'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,r):
    with p.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
checks=[]
def check(name,ok,**details):checks.append(dict(name=name,passed=bool(ok),**details))
def leaf_count(x):
    if isinstance(x,dict):return sum(leaf_count(v) for v in x.values())
    if isinstance(x,list):return sum(leaf_count(v) for v in x)
    return 1
oldsrc=(P/'snapshots/author_inputs/direct_induced_curvature_completion/check_induced_curvature_v1.py').read_text()
newsrc=(S/'author_inputs/direct_induced_curvature_completion/check_induced_curvature_v2.py').read_text()
oldtree=ast.parse(oldsrc);newtree=ast.parse(newsrc)
oldfn={x.name:x for x in oldtree.body if isinstance(x,ast.FunctionDef)}
newfn={x.name:x for x in newtree.body if isinstance(x,ast.FunctionDef)}
records=[]
for name,node in oldfn.items():
    current=newfn[name]
    rec=dict(name=name,ast_equal=ast.dump(node,include_attributes=False)==ast.dump(current,include_attributes=False),
             text_equal=ast.get_source_segment(oldsrc,node)==ast.get_source_segment(newsrc,current))
    records.append(rec)
    check('function.'+name,rec['ast_equal']==(name not in ['stationary_controls','main'])
          and rec['text_equal']==(name not in ['stationary_controls','main']),**rec)
check('function.additions',set(newfn)-set(oldfn)=={'hessian_class','serialized_controls'})
# Exact unchanged original output fields, allowing only the declared count
# correction and newly added class/zero-count records.
old=json.loads((P/'snapshots/evidence_v1/RESULTS.json').read_text())
new=json.loads((S/'evidence_v2/RESULTS.json').read_text())
oldscience={k:old[k] for k in ['kinetic_rows','stationary']}
normalized={k:copy.deepcopy(new[k]) for k in ['kinetic_rows','stationary']}
added=[]
for i,row in enumerate(normalized['stationary']['vacua']):
    if row['positive_kinetic_domain']:
        added.append(dict(path=f'stationary.vacua.{i}.local_Hessian_class',value=row.pop('local_Hessian_class')))
    else:check('excluded_no_new_class.'+str(i),'local_Hessian_class' not in row)
added.append(dict(path='stationary.origin_zero_mass_count',
                  value=normalized['stationary'].pop('origin_zero_mass_count')))
changed=dict(path='stationary.origin_negative_mass_count',
             original=oldscience['stationary']['origin_negative_mass_count'],
             current=normalized['stationary']['origin_negative_mass_count'])
normalized['stationary']['origin_negative_mass_count']=oldscience['stationary']['origin_negative_mass_count']
check('science.exact_old_field_equality',oldscience==normalized)
check('science.only_declared_count_change',changed['original']==32 and changed['current']==31)
check('science.new_zero_count',new['stationary']['origin_zero_mass_count']==1)
check('science.nonzero_positive_count',new['stationary']['second_positive_Hessian_count']==19)
check('science.expected_added_class_count',len(added)==215)
oldchecks={r['name']:r for r in old['checks'] if not r['name'].startswith('source.')}
newchecks={r['name']:r for r in new['checks']}
for name,r in oldchecks.items():
    check('old_assertion_exact.'+name,newchecks.get(name)==r)
alladded=[r for r in new['checks'] if r['name'] not in oldchecks and not r['name'].startswith('source.')]
check('assertion.added_families',
      all(r['name'].startswith('serialized.') or r['name'].endswith('.mass_classification_resolved')
          for r in alladded))
check('assertion.unique_names',len(newchecks)==len(new['checks']))
check('assertion.actual_counts',new['counts']==dict(passed=9605,failed=0,total=9605)
      and all(r['passed'] for r in new['checks']))
# Consume the immutable independently calculated reference, not the author
# numerical functions. Add exact rational classification of the new fields.
ref=json.loads((S/'prior_review/INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json').read_text())
origin_controls=[];nonzero_controls=[]
for row in ref['stationary']['vacua']:
    if not row['positive_kinetic_domain']:continue
    if row['root']==0:
        a,nu,s=map(Fraction,(row['a'],row['nu'],row['s']))
        num=nu*(1+s)+12*a*s
        state='positive' if num>0 else 'negative_direction' if num<0 else 'degenerate'
        origin_controls.append(dict(a=row['a'],nu=row['nu'],s=row['s'],
                                    numerator=str(num),expected=state))
    else:
        val=Decimal(row['canonical_masses'][0])
        state='positive' if val>0 else 'negative_direction' if val<0 else 'degenerate'
        check('nonzero.margin.'+'.'.join(str(row[k]) for k in ['a','nu','s','root']),
              abs(val)>Decimal('1e-55'),mass=str(val))
        nonzero_controls.append(dict(a=row['a'],nu=row['nu'],s=row['s'],root=row['root'],
                                     mass=str(val),expected=state))
    row['local_Hessian_class']=state
ref['stationary']['origin_zero_mass_count']=1
def numeric(x):
    if isinstance(x,str) and '/' in x:
        a,b=x.split('/');return Decimal(a)/Decimal(b)
    return Decimal(str(x))
def compare(got,want,path):
    if isinstance(want,dict):
        check(path+'.keys',isinstance(got,dict) and set(got)==set(want))
        if isinstance(got,dict):
            for k,v in want.items():
                if k not in got:check(path+'.missing.'+k,False)
                else:compare(got[k],v,path+'.'+k)
    elif isinstance(want,list):
        check(path+'.length',isinstance(got,list) and len(got)==len(want))
        if isinstance(got,list):
            for i,(x,y) in enumerate(zip(got,want)):compare(x,y,path+'.'+str(i))
    elif isinstance(want,bool) or want is None:
        check(path,got is want,actual=got,expected=want)
    else:
        with localcontext() as ctx:
            ctx.prec=110
            try:
                v=numeric(want);g=numeric(got)
            except Exception:
                check(path,got==want,actual=got,expected=want)
            else:
                er=abs(g-v)/max(Decimal(1),abs(v))
                check(path,er<=Decimal('1e-60'),normalized_error=str(er),
                      actual=got,expected=want)
for k,v in ref.items():compare(new[k],v,'cached_independent.'+k)
# Recheck v1's complete bound inventory; immutable report/receipt itself is pinned.
prior=json.loads((S/'prior_review/FINAL_RECEIPT_v1.json').read_text())
prior_paths={}
for r in prior['review_artifacts']:prior_paths[r['path']]=r['sha256']
for pair in prior['original_snapshot_pairs']:
    for role in ['original','snapshot']:
        r=pair[role];prior_paths[r['path']]=r['sha256']
for path,digest in prior_paths.items():
    check('prior_immutable.'+path,sha(Path(path))==digest)
for r in json.loads((O/'SOURCE_FREEZE_v1.json').read_text())['files']:
    check('affected_source_snapshot.'+r['source'],
          sha(Path(r['source']))==sha(Path(r['snapshot']))==r['sha256'])
# All nine author input hashes come from the actual frozen bytes.
for path,digest in new['source_hashes'].items():
    check('new_bound_input.'+path,sha(Path(path))==digest)
check('new_bound_input_count',len(new['source_hashes'])==9)
summary=dict(schema='induced_curvature_affected_source_check_v1',
             created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
             source_sha256=sha(Path(__file__)),author_source_sha256=sha(S/'author_inputs/direct_induced_curvature_completion/check_induced_curvature_v2.py'),
             counts=dict(passed=sum(c['passed'] for c in checks),failed=sum(not c['passed'] for c in checks),total=len(checks)),
             original_function_comparison=records,added_functions=sorted(set(newfn)-set(oldfn)),
             original_scientific_leaves=leaf_count(oldscience),
             exact_equal_old_leaves_except_corrected_count=leaf_count(oldscience)-1,
             allowed_count_change=changed,added_fields=added,
             original_non_source_assertion_objects_unchanged=len(oldchecks),
             new_assertion_families=dict(serialized=sum(r['name'].startswith('serialized.') for r in alladded),
                                        classifications=sum(r['name'].endswith('.mass_classification_resolved') for r in alladded)),
             exact_origin_controls=origin_controls,nonzero_margin_controls=nonzero_controls,
             prior_bound_paths_verified=len(prior_paths),checks=checks)
save(O/'SOURCE_AND_OUTPUT_CHECK_v1.json',summary)
print(json.dumps({k:summary[k] for k in ['counts','original_scientific_leaves','exact_equal_old_leaves_except_corrected_count','allowed_count_change','original_non_source_assertion_objects_unchanged','new_assertion_families','prior_bound_paths_verified']}))

