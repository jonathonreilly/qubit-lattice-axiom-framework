#!/usr/local/bin/python3
"""Saved-result and exact rational classification supplements; no science rerun."""
from pathlib import Path
import json,hashlib,datetime as dt
import sympy as sp
import mpmath as mp
O=Path(__file__).resolve().parent
mp.mp.dps=110
def n(x):
    if isinstance(x,str) and '/' in x:
        a,b=x.split('/');return mp.mpf(a)/mp.mpf(b)
    return mp.mpf(x)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def rat(x):return sp.Rational(x)
ref=json.loads((O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json').read_text())
orig=json.loads((O/'snapshots/evidence_v1/RESULTS.json').read_text())
protocol=json.loads((O/'snapshots/author_inputs/direct_induced_curvature_completion/PROTOCOL_v1.json').read_text())
controls=[];counts=dict(positive=0,negative=0,zero=0,excluded=0)
for av in protocol['parameter_grid']['a']:
 for nv in protocol['parameter_grid']['nu']:
  for sv in protocol['parameter_grid']['s']:
   aa,nn,ss=map(rat,(av,nv,sv))
   F=1+ss;J=1+(1-3*aa)*ss
   numerator=nn*(1+ss)+12*aa*ss
   valid=F>0 and J>0
   if not valid:state='excluded'
   elif numerator>0:state='positive'
   elif numerator<0:state='negative'
   else:state='zero'
   counts[state]+=1
   actual=next(q for q in orig['stationary']['vacua']
               if q['a']==av and q['nu']==nv and q['s']==sv and q['root']==0)
   check=actual['positive_kinetic_domain']==bool(valid)
   if valid:check=check and actual['positive_local_Hessian']==(state=='positive')
   controls.append(dict(a=av,nu=nv,s=sv,F=str(F),J=str(J),numerator=str(numerator),
                        disposition=state,passed=bool(check),
                        exact_physical_u_mass=str(numerator/J) if valid else None,
                        reported_canonical_u_mass=actual.get('canonical_masses',[None])[0]))
zero=[q for q in controls if q['disposition']=='zero']
failure=dict(name='reported_negative_origin_count',passed=orig['stationary']['origin_negative_mass_count']==counts['negative'],
             actual=orig['stationary']['origin_negative_mass_count'],expected=counts['negative'])
save(O/'EXACT_ORIGIN_CLASSIFICATION_v1.json',
     dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),source_sha256=sha(Path(__file__)),
          counts=counts,controls=controls,zero_rows=zero,reporting_check=failure))
# Keyed comparison avoids cascading list misalignment when a mutant drops rows.
# Existing baseline reporting error is recorded separately, not attributed to mutation.
def key(kind,r):
 fs={'kinetic_rows':['a','s','t'],'root_census':['a','nu'],
     'vacua':['a','nu','s','root'],'flux_response':['a','nu','s','epsilon'],
     'fixed_C':['a','nu','s']}[kind]
 return tuple(str(r[f]) for f in fs)
def compare(a,b,p,out):
 if isinstance(b,dict):
  if not isinstance(a,dict):
   out.append(dict(path=p,kind='type',actual=str(type(a)),expected='dict'));return
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append(dict(path=p+'.'+k,kind='key',actual=k in a,expected=k in b))
   else:compare(a[k],b[k],p+'.'+k,out)
 elif isinstance(b,list):
  if not isinstance(a,list) or len(a)!=len(b):
   out.append(dict(path=p,kind='length',actual=len(a) if isinstance(a,list) else None,expected=len(b)))
  if isinstance(a,list):
   for i,(x,y) in enumerate(zip(a,b)):compare(x,y,p+'.'+str(i),out)
 elif isinstance(b,bool) or b is None:
  if a is not b:out.append(dict(path=p,kind='value',actual=a,expected=b))
 else:
  try:
   er=abs(n(a)-n(b))/max(mp.mpf(1),abs(n(b)))
   ok=er<=mp.mpf('1e-60')
  except (TypeError,ValueError):ok=a==b;er=None
  if not ok:out.append(dict(path=p,kind='value',actual=a,expected=b,
                           normalized_error=mp.nstr(er,100) if er is not None else None))
def keyed(actual):
 out=[]
 for kind in ['kinetic_rows','root_census','vacua','flux_response','fixed_C']:
  aa=actual[kind] if kind=='kinetic_rows' else actual['stationary'][kind]
  bb=ref[kind] if kind=='kinetic_rows' else ref['stationary'][kind]
  ad={key(kind,r):r for r in aa};bd={key(kind,r):r for r in bb}
  if len(ad)!=len(aa):out.append(dict(path=kind,kind='duplicate_key'))
  for k in sorted(set(ad)|set(bd)):
   if k not in ad or k not in bd:
    out.append(dict(path=kind+'.'+repr(k),kind='row',actual=k in ad,expected=k in bd))
   else:compare(ad[k],bd[k],kind+'.'+repr(k),out)
 for f in ['critical_t','critical_ell','second_positive_Hessian_count','origin_negative_mass_count']:
  compare(actual['stationary'][f],ref['stationary'][f],'stationary.'+f,out)
 return out
baseline=keyed(orig)
mut=[]
for p in sorted((O/'mutations').glob('*/RESULTS.json')):
 data=json.loads(p.read_text());bad=keyed(data)
 novel=[r for r in bad if r not in baseline]
 sc=[r for r in data['checks'] if r['name'].startswith('source.')]
 failed=[r for r in data['checks'] if not r['passed']]
 mut.append(dict(id=p.parent.name,path=str(p),sha256=sha(p),author_counts=data['counts'],
                 source_checks_count=len(sc),source_checks_all_pass=all(q['passed'] for q in sc),
                 actual_assertion_failures=len(failed),
                 assertion_failure_names=[q['name'] for q in failed],
                 keyed_mismatches_including_baseline=len(bad),
                 new_keyed_mismatches=len(novel),
                 missing_rows=sum(q['kind']=='row' and not q['actual'] for q in novel),
                 failures=novel))
save(O/'KEYED_MUTANT_OUTPUT_COMPARISON_v1.json',
     dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
          reference_sha256=sha(O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json'),
          preserved_first_positional_comparison=str(O/'MUTANT_OUTPUT_COMPARISON_v1.json'),
          note='Key alignment changes diagnostic counting only. No author or reviewer scientific calculation was rerun.',
          baseline_failures=baseline,mutations=mut))
print(json.dumps(dict(origin_counts=counts,exact_row_checks_passed=sum(r['passed'] for r in controls),
                     reporting_check=failure,mutation_summary=[
                      dict(id=r['id'],new_keyed_mismatches=r['new_keyed_mismatches'],
                           missing_rows=r['missing_rows'],assertion_failures=r['actual_assertion_failures'])
                      for r in mut])))

