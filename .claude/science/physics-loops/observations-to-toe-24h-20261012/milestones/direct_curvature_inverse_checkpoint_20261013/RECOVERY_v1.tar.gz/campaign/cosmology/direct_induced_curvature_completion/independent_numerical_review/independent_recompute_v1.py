#!/usr/local/bin/python3
"""Independent action-based recomputation; no author imports or execution."""
from pathlib import Path
import datetime as dt, hashlib, json, platform, sys
import mpmath as m
import sympy as s

O=Path(__file__).resolve().parent
I=O/'snapshots'/'author_inputs'/'direct_induced_curvature_completion'
R=O/'snapshots'/'evidence_v1'/'RESULTS.json'
m.mp.dps=110
checks=[]
def n(x):
    if isinstance(x,str) and '/' in x:
        a,b=x.split('/');return m.mpf(a)/m.mpf(b)
    return m.mpf(x)
def f(x):return m.nstr(x,100)
def emit(name,ok,**kw):
    checks.append(dict(name=name,passed=bool(ok),**kw))
def close(name,x,y,tol='1e-60'):
    er=abs(n(x)-n(y))/max(m.mpf(1),abs(n(y)))
    emit(name,er<=n(tol),actual=f(n(x)),expected=f(n(y)),error=f(er),tolerance=tol)
def exact(name,x):
    z=s.factor(s.simplify(x))
    emit(name,z==0,remainder=str(z))
def dump(p,x):
    with p.open('x') as q:json.dump(x,q,indent=2);q.write('\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()

# Derive the effective potential and entire kinetic tensor before imposing a
# stationary relation.  Coordinates (t,x,y), with t=sqrt(a)u, avoid huge u.
a,nu,ss,t,x,y,c=s.symbols('a nu s t x y c',real=True)
aa,qq,zz=s.symbols('aa q z',positive=True)
D=1+s.Rational(2,3)*(1+a)*(x*x+y*y)
A2=s.exp(2*t)
FF=1+ss*A2
V=s.Rational(3,2)+nu*t*t/(2*a)+(a/2-t+2*t*t/a)*x*x+a*y*y/3
U=(V+c*A2*A2)/FF**2
# Z/q in t coordinates and Ricci Weyl mixing (3/4)(d ln F)^2.
K=s.diag((1/a-3*ss*A2)/FF,4*a/(9*D*FF),a/(3*D*FF))
K[0,0]+=s.Rational(3,4)*(s.diff(FF,t)/FF)**2
H=s.hessian(U,(t,x,y))
grad=s.diff(U,t).subs({x:0,y:0})
cx=s.solve(s.together(grad),c)[0]  # held fixed in the derivative above
J=1+(1-3*a)*ss*A2
exact('action.kinetic_t',K[0,0]-J/(a*FF**2))
exact('action.matter_coupling',
      s.diff(t-s.log(FF)/2,t)**2/K[0,0]-a/J)
for j in range(3):
    for k in range(j+1,3):
        exact('action.offdiagonal_%s%s'%(j,k),H[j,k].subs({x:0,y:0}))
exact('action.fixed_c_gradient_at_cstar',grad.subs(c,cx))
# Original-frame H derived from the metric equation, then flux scalar L0.
Hg2=s.factor(2*(V.subs({x:0,y:0})+cx*s.exp(4*t))/(3*FF))
boundary=s.factor((6*Hg2-2*V.subs({x:0,y:0}))*s.exp(-4*t))
exact('action.Hg_relation',Hg2-(1+(nu/a)*(t*t/3-t/6)))
exact('action.boundary',boundary-(3+(nu/a)*(t*t-t))*s.exp(-4*t))
# Derivative ratio obtains response coefficients by implicit function theorem.
tensor=A2/FF
HJ2=Hg2/A2
response_sym=[1/s.diff(boundary,t),s.diff(cx,t)/s.diff(boundary,t),
              s.diff(HJ2,t)/(2*s.sqrt(HJ2)*s.diff(boundary,t)),
              s.diff(tensor,t)/s.diff(boundary,t)]
response0=[s.simplify(z.subs(t,0)) for z in response_sym]
rfn=s.lambdify((a,nu,ss),response0,'mpmath')
ufn=s.lambdify((a,nu,ss,c,t),U.subs({x:0,y:0}),'mpmath')
gfn=s.lambdify((a,nu,ss,c,t),grad,'mpmath')
hfn=s.lambdify((a,nu,ss,c,t),[H[j,j].subs({x:0,y:0}) for j in range(3)],'mpmath')
kfn=s.lambdify((a,ss,t),[K[j,j].subs({x:0,y:0}) for j in range(3)],'mpmath')
cfn=s.lambdify((a,nu,ss,t),cx,'mpmath')
hgfn=s.lambdify((a,nu,ss,t),Hg2,'mpmath')
bfn=s.lambdify((a,nu,t),boundary,'mpmath')
# Independent trace check directly contracts scalar-tensor metric equation:
# F G = 2Z dphi dphi -g(Zkin+W) + T + HessF -gBoxF.
Q,du,W0,L,T,boxF=s.symbols('Q du W0 L T boxF')
d=qq*zz;F=qq+d
Zkin=qq*Q-3*aa*d*du
trace_rhs=-2*Zkin-4*(2*qq*W0+L)-3*boxF+T
Rfromtrace=-trace_rhs/F
Lzero=qq*(Rfromtrace/2-Q-2*W0)
target=-qq*d*Q/F-3*qq*aa*d*du/F+2*qq*(qq-d)*W0/F+2*qq*L/F-qq*T/(2*F)+3*qq*boxF/(2*F)
exact('action.trace_contract',Lzero-target)

def bracketroot(fn,lo,hi):
    lo=n(lo);hi=n(hi);fl=fn(lo);fh=fn(hi)
    if fl==0:return lo
    if fh==0:return hi
    if fl*fh>=0:raise ValueError(('independent bracket',f(lo),f(hi),f(fl),f(fh)))
    for _ in range(430):
        mid=(lo+hi)/2;fm=fn(mid)
        if fm==0:return mid
        if fl*fm<0:hi=mid
        else:lo=mid;fl=fm
    return (lo+hi)/2

def roots_by_boundary_extrema(av,nv):
    ell=nv/av
    rr=[m.mpf(0)]
    if ell<=m.mpf(48)/5:return rr
    tmax=(3+m.sqrt(5-48/ell))/4
    if tmax<=1:return rr
    fn=lambda tt:bfn(av,nv,tt)-3
    if fn(tmax)<=0:return rr
    hi=m.mpf(2)
    while fn(hi)>0:hi*=2
    rr += [bracketroot(fn,1,tmax),bracketroot(fn,tmax,hi)]
    return rr

protocol=json.loads((I/'PROTOCOL_v1.json').read_text())
pg=protocol['parameter_grid']
source=json.loads(R.read_text())
freeze=json.loads((O/'SOURCE_FREEZE_v1.json').read_text())
for r in freeze['files']:
    emit('snapshot.'+r['snapshot'],h(Path(r['snapshot']))==r['sha256'])

kin=[]
for av in pg['a']:
    aa=n(av)
    for sv in pg['s']:
        zeta=n(sv)
        for tv in pg['t']:
            tt=n(tv);z=zeta*m.exp(2*tt);F=1+z;j=1+(1-3*aa)*z
            kt=kfn(aa,zeta,tt)
            # t-coordinate kinetic -> u-coordinate by dt/du=sqrt(a).
            ku=[aa*kt[0],kt[1],kt[2]]
            valid=F>0 and all(k>0 for k in kt)
            logmatter_slope=1-(2*z)/(2*F)
            eff=logmatter_slope**2/kt[0] if valid else None
            kin.append(dict(a=av,s=sv,t=tv,F_over_q=f(F),J=f(j),
                            positive_kinetic_domain=bool(valid),
                            transformed_kinetic=[f(v) for v in ku],
                            scalar_coupling_norm=f(eff) if valid else None))

vac=[];census=[];response=[];fixed=[]
for av in pg['a']:
    aa=n(av)
    for nv in pg['nu']:
        nn=n(nv);ell=nn/aa
        rr=roots_by_boundary_extrema(aa,nn)
        census.append(dict(a=av,nu=nv,count=len(rr),t=[f(v) for v in rr]))
        for sv in pg['s']:
            zeta=n(sv)
            for i,tt in enumerate(rr):
                z=zeta*m.exp(2*tt);F=1+z;j=1+(1-3*aa)*z
                cc=cfn(aa,nn,zeta,tt)
                kt=kfn(aa,zeta,tt)
                valid=F>0 and all(k>0 for k in kt)
                row=dict(a=av,nu=nv,s=sv,root=i,t=f(tt),z=f(z),F_over_q=f(F),J=f(j),
                         C_over_Hv_squared=f(cc),positive_kinetic_domain=bool(valid))
                close(f'derivation.boundary.{av}.{nv}.{sv}.{i}',bfn(aa,nn,tt),3)
                if not valid:
                    row['disposition']='excluded by tensor/scalar kinetic domain'
                else:
                    W=ufn(aa,nn,zeta,cc,tt)
                    HH=m.sqrt(2*W/3)
                    B2=m.exp(2*tt)/F
                    HJ=HH/m.sqrt(B2)
                    # Derive mass matrix from off-shell potential; c is a fixed
                    # independent argument, not c(t), throughout differentiation.
                    hes=hfn(aa,nn,zeta,cc,tt)
                    mass=[hes[jj]/kt[jj] for jj in range(3)]
                    massphysical=[mm/B2 for mm in mass]
                    close(f'derivation.gradient.{av}.{nv}.{sv}.{i}',
                          gfn(aa,nn,zeta,cc,tt),0)
                    eff=(1-z/F)**2/kt[0]
                    row.update(HJ_over_Hv=f(HJ),Hhat_over_Hv=f(HH),
                               tensor_G_ratio=f(B2),scalar_coupling_norm=f(eff),
                               canonical_masses=[f(v) for v in mass],
                               physical_masses=[f(v) for v in massphysical],
                               positive_local_Hessian=all(mm>0 for mm in mass))
                vac.append(row)
        for sv in ['-0.1','0','0.1','1']:
            zeta=n(sv)
            rd=rfn(aa,nn,zeta)
            for ev in pg['epsilon']:
                ee=n(ev)
                tt=bracketroot(lambda v:bfn(aa,nn,v)-3-ee,'-0.01','0.01')
                F=1+zeta*m.exp(2*tt);kt=kfn(aa,zeta,tt)
                row=dict(a=av,nu=nv,s=sv,epsilon=ev)
                if not (F>0 and all(k>0 for k in kt)):
                    row['disposition']='outside kinetic domain'
                else:
                    cc=cfn(aa,nn,zeta,tt)
                    W=ufn(aa,nn,zeta,cc,tt)
                    B2=m.exp(2*tt)/F
                    HJ=m.sqrt((2*W/3)/B2)
                    baseC=cfn(aa,nn,zeta,m.mpf(0))
                    sec=[tt/ee,(cc-baseC)/ee,(HJ-1)/ee,(B2-1/(1+zeta))/ee]
                    for j in range(4):
                        close(f'derivation.secant.{av}.{nv}.{sv}.{ev}.{j}',
                              sec[j],rd[j],str(2*abs(ee)))
                    row.update(t=f(tt),C=f(cc),HJ_over_Hv=f(HJ),tensor_G_ratio=f(B2),
                               secants=[f(v) for v in sec],zero_derivatives=[f(v) for v in rd])
                response.append(row)
        for sv in ['-0.00000001','0.00000001']:
            zeta=n(sv)
            # Root of differentiated full Einstein-normalized potential at c=0.
            lead=6*zeta/ell
            rad=10*abs(lead)
            tt=bracketroot(lambda v:gfn(aa,nn,zeta,0,v),-rad,rad)
            bound=200*(1+6/ell)**2*zeta*zeta
            emit(f'derivation.fixedC_bound.{av}.{nv}.{sv}',abs(tt-lead)<=bound)
            fixed.append(dict(a=av,nu=nv,s=sv,C='0',t=f(tt),leading_t=f(lead),
                              remainder_bound=f(bound)))

# Critical point from simultaneous b=3 and db/dt=0, not author's L minimum.
TC,EC=m.findroot(lambda tv,ev:((3+ev*(tv*tv-tv))*m.exp(-4*tv)-3,
                              ev*(-4*tv*tv+6*tv-1)-12),
                 (m.mpf('1.31'),m.mpf('1400')),tol=m.mpf('1e-100'))
reference=dict(kinetic_rows=kin,stationary=dict(root_census=census,vacua=vac,
                flux_response=response,fixed_C=fixed,critical_t=f(TC),critical_ell=f(EC),
                second_positive_Hessian_count=sum(r.get('positive_local_Hessian',False)
                                                  and r['root']>0 for r in vac),
                origin_negative_mass_count=sum(r['root']==0 and r['positive_kinetic_domain']
                                                and n(r['canonical_masses'][0])<0 for r in vac)))
dump(O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json',reference)

# Complete recursive output/shape checks. Every numeric or declarative scientific
# leaf and list/dictionary shape is checked; no requested excluded row is dropped.
def compare(actual,expected,path):
    if isinstance(expected,dict):
        emit(path+'.keys',isinstance(actual,dict) and set(actual)==set(expected),
             actual=sorted(actual) if isinstance(actual,dict) else str(type(actual)),
             expected=sorted(expected))
        if not isinstance(actual,dict):return
        for k,v in expected.items():
            if k in actual:compare(actual[k],v,path+'.'+k)
            else:emit(path+'.missing.'+k,False)
    elif isinstance(expected,list):
        emit(path+'.length',isinstance(actual,list) and len(actual)==len(expected),
             actual=len(actual) if isinstance(actual,list) else str(type(actual)),expected=len(expected))
        if isinstance(actual,list):
            for j,(xx,yy) in enumerate(zip(actual,expected)):compare(xx,yy,path+'.'+str(j))
    elif isinstance(expected,bool) or expected is None:
        emit(path,actual is expected,actual=actual,expected=expected)
    else:
        try:ev=n(expected)
        except (ValueError,TypeError):
            emit(path,actual==expected,actual=actual,expected=expected)
        else:
            try:close(path,actual,ev)
            except (ValueError,TypeError):emit(path,False,actual=actual,expected=expected)

for k,v in reference.items():compare(source[k],v,'original.'+k)
# Verify source assertion bookkeeping and stored numeric assertion consistency
# separately; these counts do not replace the independent science above.
emit('author.counts',source['counts']==dict(passed=5195,failed=0,total=5195))
emit('author.unique_checks',len({q['name'] for q in source['checks']})==len(source['checks']))
for i,q in enumerate(source['checks']):
    emit('author.assertion_pass.'+str(i),q['passed'] is True)
    if 'normalized_error' in q:
        er=abs(n(q['actual'])-n(q['expected']))/max(m.mpf(1),abs(n(q['expected'])))
        # The recorded values have only 75 significant digits; allow their last
        # digit to differ from the 90-digit internal residual.
        emit('author.assertion_arithmetic.'+str(i),
             er<=n(q['tolerance']) and n(q['normalized_error'])<=n(q['tolerance']))
# All frozen original source hashes are compared using saved original bytes.
for p,digest in source['source_hashes'].items():
    matches=[q for q in freeze['files'] if q['source']==p]
    emit('author.bound_source.'+p,len(matches)==1 and matches[0]['sha256']==digest)

out=dict(schema='independent_induced_curvature_review_v1',
         created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
         source_path=str(R),source_sha256=h(R),reviewer_source_sha256=h(Path(__file__)),
         counts=dict(passed=sum(q['passed'] for q in checks),failed=sum(not q['passed'] for q in checks),
                     total=len(checks)),
         category_counts={k:sum(q['name'].startswith(k) for q in checks)
                          for k in ['action.','snapshot.','derivation.','original.','author.']},
         versions=dict(python=platform.python_version(),sympy=s.__version__,mpmath=m.__version__),
         checks=checks)
dump(O/'INDEPENDENT_RESULTS_v1.json',out)
# Reuse only this newly calculated immutable reference to examine saved mutants.
mutation=[]
for p in sorted((O/'mutations').glob('*/RESULTS.json')):
    start=len(checks)
    mr=json.loads(p.read_text())
    for k,v in reference.items():compare(mr[k],v,p.parent.name+'.'+k)
    new=checks[start:];del checks[start:]
    mutation.append(dict(id=p.parent.name,path=str(p),sha256=h(p),counts=mr['counts'],
                         output_checks=dict(passed=sum(q['passed'] for q in new),
                                            failed=sum(not q['passed'] for q in new),total=len(new)),
                         failures=[q for q in new if not q['passed']]))
dump(O/'MUTANT_OUTPUT_COMPARISON_v1.json',mutation)
print(json.dumps(dict(counts=out['counts'],categories=out['category_counts'],
                     mutant_checks=[dict(id=q['id'],**q['output_checks']) for q in mutation])))
sys.exit(int(out['counts']['failed']>0))

