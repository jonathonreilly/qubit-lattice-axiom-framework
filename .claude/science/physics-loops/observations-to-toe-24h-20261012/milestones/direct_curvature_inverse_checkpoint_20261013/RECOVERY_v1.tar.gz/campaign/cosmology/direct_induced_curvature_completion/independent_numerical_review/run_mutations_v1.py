#!/usr/local/bin/python3
"""Copied-source mutation probes with fresh eight-input freezes."""
from pathlib import Path
import json,hashlib,datetime as dt,subprocess,time,difflib,os
HERE=Path(__file__).resolve().parent
SNAP=HERE/"snapshots"/"author_inputs"
BASE=SNAP/"direct_induced_curvature_completion"/"check_induced_curvature_v1.py"
HASH="aae87ef2cd5a0891321bdbb42c6be39f9b21affc897137cea9fc2c359c782a64"
MUT=[
("m1_reverse_Weyl_mixing",
 "direct=(1-3*aa*z)/F+mp.mpf(3)/4*(2*mp.sqrt(aa)*z/F)**2",
 "direct=(1-3*aa*z)/F-mp.mpf(3)/4*(2*mp.sqrt(aa)*z/F)**2",1,
 "Reverse the Ricci-induced kinetic mixing contribution."),
("m2_omit_physical_clock","hj=hh/B","hj=hh",1,
 "Treat normalized Einstein time as the physical Jordan clock."),
("m3_output_unconverted_physical_masses",
 "physical_masses=[fmt(m/(B*B)) for m in mass]",
 "physical_masses=[fmt(m) for m in mass]",1,
 "Report normalized-frame canonical masses as physical mass squares."),
("m4_drop_excluded_vacuum_rows","vacua.append(row);continue","continue",1,
 "Discard domain-excluded vacuum rows rather than preserving their disposition."),
("m5_output_all_Hessians_positive",
 "positive_local_Hessian=all(m>0 for m in mass)","positive_local_Hessian=True",1,
 "Misclassify every admitted vacuum's local Hessian as positive."),
("m6_remove_nonzero_roots",
 "if ell<ellcrit:return [mp.mpf(0)]","if True:return [mp.mpf(0)]",1,
 "Return only the origin while leaving the separate root census unchanged.")]
def sha(x):return hashlib.sha256(x).hexdigest()
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def dump(p,v):
 with p.open("x") as f:json.dump(v,f,indent=2);f.write("\n")
raw=BASE.read_bytes();assert sha(raw)==HASH
dump(HERE/"MUTATION_PLAN_v1.json",{"created_at":now(),"driver_pid":os.getpid(),"source_sha256":HASH,
 "mutations":[{"id":n,"old":a,"new":b,"replacement_count":c,"purpose":d} for n,a,b,c,d in MUT],
 "scope":"All eight actual copied inputs freshly hashed. No assertions or tolerances weakened. Every failure preserved."})
runs=[]
for name,old,new,count,desc in MUT:
 case=HERE/"mutations"/name;srcroot=case/"source";tick=time.monotonic();start=now()
 for f in sorted(SNAP.rglob("*")):
  if f.is_file():
   dst=srcroot/f.relative_to(SNAP);dst.parent.mkdir(parents=True,exist_ok=True)
   with dst.open("xb") as h:h.write(f.read_bytes())
 runner=srcroot/"direct_induced_curvature_completion"/BASE.name
 text=raw.decode();assert text.count(old)==count,(name,text.count(old))
 change=text.replace(old,new);runner.write_text(change)
 with (case/"MUTATION.diff").open("x") as h:
  h.write("".join(difflib.unified_diff(text.splitlines(True),change.splitlines(True),fromfile=BASE.name,tofile=name+"/"+BASE.name)))
 inputs=[{"path":str(f),"sha256":sha(f.read_bytes())} for f in sorted(srcroot.rglob("*")) if f.is_file()]
 assert len(inputs)==8
 freeze=case/"FREEZE.json";dump(freeze,{"inputs":inputs,"mutation":name})
 cmd=["/usr/local/bin/python3",str(runner),"--freeze",str(freeze),"--output-json",str(case/"RESULTS.json")]
 with (case/"stdout.txt").open("xb") as out,(case/"stderr.txt").open("xb") as err:
  proc=subprocess.Popen(cmd,cwd=runner.parent,stdout=out,stderr=err)
  dump(case/"LAUNCH.json",{"started_at":start,"pid":proc.pid,"driver_pid":os.getpid(),"command":cmd,"source_sha256":sha(runner.read_bytes())})
  ret=proc.wait()
 result=json.loads((case/"RESULTS.json").read_text()) if (case/"RESULTS.json").exists() else None
 rec={"id":name,"purpose":desc,"started_at":start,"finished_at":now(),"seconds":time.monotonic()-tick,
      "exit_code":ret,"source_sha256":sha(runner.read_bytes()),
      "counts":result["counts"] if result else None,
      "source_checks_all_pass":all(r["passed"] for r in result["checks"] if r["name"].startswith("source.")) if result else None,
      "failed_assertions":[r for r in result["checks"] if not r["passed"]] if result else [],
      "has_result":result is not None,
      "result_sha256":sha((case/"RESULTS.json").read_bytes()) if result else None,
      "stderr_sha256":sha((case/"stderr.txt").read_bytes())}
 if result:
  rec["output_summary"]={"kinetic_rows":len(result["kinetic_rows"]),
    "vacua":len(result["stationary"]["vacua"]),"response_rows":len(result["stationary"]["flux_response"]),
    "second_positive_Hessian_count":result["stationary"]["second_positive_Hessian_count"],
    "origin_negative_mass_count":result["stationary"]["origin_negative_mass_count"]}
 dump(case/"EXECUTION.json",rec);runs.append(rec)
 print(json.dumps({k:rec[k] for k in ["id","exit_code","counts","source_checks_all_pass","has_result"]}),flush=True)
dump(HERE/"MUTATION_RESULTS_v1.json",{"created_at":now(),"mutations":runs})

