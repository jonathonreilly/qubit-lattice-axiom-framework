# Thermal computation details

Parent uses fixed Gauss–Laguerre integration in momentum divided by T.
Each summand includes exp(y-sqrt(y*y+r*r))/(1+exp(-sqrt(y*y+r*r))) so no
large exp(y) is formed. Base128, comparison256 and diagnostic64 nodes
are generated once, serialized and frozen before physical execution.
This replaces the proposed interpolated EOS table before any trajectory
is computed. It is a computational choice, not a physical premise change.

Direct momentum integrals independently give density, pressure, trace and
heat capacity. mpmath70-digit infinite integrals provide spot references;
float64 node arithmetic is judged using normalized2e-8 tolerance, not by
claiming70-digit trajectory precision. The refinement envelope for full
histories is2e-6; conservation finite directional derivatives use3e-7.
All comparison thresholds and cases are fixed in the fixture before use.

R_star1e30 and variation1e20 are supplied high-density regimes. Report
physical ratios, scalar motion and finite initial-temperature entropy
normalization. No electron mass value, Newton constant, abundance or
neutrino-transport calculation is smuggled into those dimensionless choices.

Independent handwritten reviewer supplied initial-trace acceleration
identities before the first run; these are explicit control imports, not
parent-only derivation claims. The parent's full action/evolution remains
the scientific object under test. No runner from a previous block is imported.

