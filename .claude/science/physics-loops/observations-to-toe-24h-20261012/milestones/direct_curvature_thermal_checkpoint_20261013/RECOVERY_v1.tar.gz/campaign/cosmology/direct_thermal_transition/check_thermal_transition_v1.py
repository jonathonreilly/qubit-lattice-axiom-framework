#!/usr/bin/env python3
"""Parent direct thermal-transition calculation; no abundance likelihood."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,itertools,traceback
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

HERE=Path(__file__).resolve().parent
CHECKS=[]
NODES=json.loads((HERE/"QUADRATURE_NODES_v1.json").read_text())["nodes"]

def check(name,passed,**kw):
    CHECKS.append(dict(name=name,passed=bool(passed),**kw))

def compare(name,a,b,tol):
    er=abs(a-b)/max(1.,abs(b))
    check(name,np.isfinite(er) and er<=tol,actual=float(a),expected=float(b),
          normalized_error=float(er),tolerance=tol)

def eos(T,Tnu,n=128,massless=False):
    row=NODES[str(n)];p=np.asarray(row["x"]);wt=np.asarray(row["w"])
    r=0. if massless else 1./T
    E=np.sqrt(p*p+r*r)
    f=1./(1.+np.exp(-E))
    weight=wt*np.exp(p-E)*f
    pref=2/np.pi**2
    re=pref*np.sum(weight*p*p*E)
    pe=pref/3*np.sum(weight*p**4/E)
    tr=pref*r*r*np.sum(weight*p*p/E)
    heat=pref*np.sum(weight*p*p*E*E*f)
    rg=np.pi**2/15
    rpl=T**4*(rg+re);ppl=T**4*(rg/3+pe)
    rn=3*7*np.pi**2/120*Tnu**4
    return dict(rho=rpl+rn,pressure=ppl+rn/3,trace=T**4*tr,
                rho_pl=rpl,p_pl=ppl,entropy_bar=rg+re+rg/3+pe,
                cT=3*(rg+re+rg/3+pe)/(4*rg+heat),
                electron_density_bar=re,electron_pressure_bar=pe,
                electron_trace_bar=tr,heat_capacity_bar=4*rg+heat)

def reference_eos(T,massless=False):
    T=mp.mpf(str(T));r=mp.mpf(0) if massless else 1/T
    def I(which):
        def f(E):
            p=mp.sqrt(max(mp.mpf(0),E*E-r*r))
            occ=1/(mp.exp(E)+1)
            if which=="rho":return E*E*p*occ
            if which=="pressure":return p**3*occ/3
            if which=="trace":return r*r*p*occ
            if which=="heat":return E**3*p*occ*(1-occ)
        return 2/mp.pi**2*mp.quad(f,[r,r+1,r+5,r+20,mp.inf])
    re,pe,tr,ht=[I(v) for v in ["rho","pressure","trace","heat"]]
    rg=mp.pi**2/15
    return dict(electron_density_bar=re,electron_pressure_bar=pe,
        electron_trace_bar=tr,heat_capacity_bar=4*rg+ht,
        entropy_bar=4*rg/3+re+pe,cT=3*(4*rg/3+re+pe)/(4*rg+ht))

def parameters(k,branch,Rstar,nu):
    a=(1-k)*(1+3*k)/4
    s=(1+k)/(k*(1-3*k))
    return dict(k0=k,a=a,b=a if branch=="equal" else k,s=s,Rstar=Rstar,nu=nu,branch=branch)

def quantities(state,cfg,n,massless=False):
    u,ell,p,w,lt,ltn,NJ=state
    a,b,s,nu=cfg["a"],cfg["b"],cfg["s"],cfg["nu"]
    al=np.sqrt(a);EA=np.exp(2*al*u);z=s*EA;F=1+z;J=1+(1-3*a)*z
    y2=np.exp(2*ell);D=1+2*(1+b)*y2/3
    Ku=J/F**2;Kyy=(1+s)*b*y2/(3*F*D)
    CB=(1+s)*EA/F
    T,Tnu=np.exp(lt),np.exp(ltn)
    fluid=eos(T,Tnu,n,massless)
    sig=CB*CB*cfg["Rstar"]*fluid["rho"]
    pf=CB*CB*cfg["Rstar"]*fluid["pressure"]
    tau=CB*CB*cfg["Rstar"]*fluid["trace"]
    U=(1+s)*(1.5+nu*u*u/2+b*(1+s)*y2/3+1.5*s*EA*EA)/F**2
    Uu=(1+s)*(nu*u+6*al*s*EA*EA)/F**2-4*al*z/F*U
    norm=Ku*p*p+Kyy*w*w
    H2=2*(sig+U)/(3-norm)
    h=-(sig+pf)/H2-norm
    ab=al/F;njp=1+ab*p
    if F<=0 or J<=0 or Ku<=0 or Kyy<=0 or H2<=0 or njp<=0 or not np.isfinite(H2):
        raise ValueError(("physical chart",F,J,Ku,Kyy,H2,njp))
    HJ2=H2*njp*njp/CB
    HGR2=1+2*(1+cfg["k0"])*cfg["Rstar"]*fluid["rho"]/3
    return dict(a=a,b=b,s=s,nu=nu,al=al,z=z,F=F,J=J,D=D,Ku=Ku,Kyy=Kyy,
        CB=CB,U=U,Uu=Uu,sigma=sig,pressure=pf,tau=tau,norm=norm,H2=H2,h=h,
        ab=ab,njp=njp,Hratio=np.sqrt(HJ2/HGR2),
        GNratio=CB*(1+a/J)/(1+cfg["k0"]),T=T,Tnu=Tnu,fluid=fluid)

def rhs(N,state,cfg,n,massless=False):
    u,ell,p,w,lt,ltn,NJ=state
    q=quantities(state,cfg,n,massless)
    A=q["al"]*q["z"]/q["F"]
    pu=-(3+q["h"])*p-q["al"]*q["z"]*((1-3*q["a"])/q["J"]-2/q["F"])*p*p
    pu-=A*q["Kyy"]*w*w/q["Ku"]
    pu-=(q["Uu"]+q["ab"]*q["tau"])/(q["Ku"]*q["H2"])
    wp=-(3+q["h"])*w+2*A*p*w-w*w/q["D"]-2*(1+q["s"])*q["D"]/(q["F"]*q["H2"])
    return np.array([p,w,pu,wp,-q["fluid"]["cT"]*q["njp"],-q["njp"],q["njp"]])

def integrate(cfg,fix,n,rtol,atol,maxstep,massless=False):
    ti,tf=fix["T_initial"],fix["T_final"]
    fluid=eos(ti,ti,n,massless)
    st=np.array([0.,.5*np.log(cfg["Rstar"]*fluid["rho"]),0.,-2.,np.log(ti),np.log(ti),0.])
    def stop(N,state):return state[4]-np.log(tf)
    stop.terminal=True;stop.direction=-1
    sol=solve_ivp(lambda N,y:rhs(N,y,cfg,n,massless),(0,fix["N_max"]),st,
        method=fix["solver"],rtol=rtol,atol=atol,max_step=maxstep,events=stop,dense_output=True)
    rows=[]
    if sol.success and len(sol.t_events[0])==1:
        end=float(sol.t_events[0][0])
        for j,logT in enumerate(np.linspace(np.log(ti),np.log(tf),fix["sample_count"])):
            if j==0:N=0.
            elif j==fix["sample_count"]-1:N=end
            else:N=brentq(lambda t:sol.sol(t)[4]-logT,0,end,xtol=1e-13,rtol=1e-14)
            v=sol.sol(N);q=quantities(v,cfg,n,massless)
            logs=3*(v[4]-np.log(ti))+np.log(q["fluid"]["entropy_bar"]/fluid["entropy_bar"])+3*v[6]
            lognu=v[5]-np.log(ti)+v[6]
            pred_ratio=(q["fluid"]["entropy_bar"]/fluid["entropy_bar"])**(1/3)
            rows.append(dict(N=N,state=v.tolist(),T=q["T"],Tnu=q["Tnu"],Hratio=q["Hratio"],
                GNratio=q["GNratio"],Ku=q["Ku"],F=q["F"],J=q["J"],NJprime=q["njp"],
                fluid_trace_fraction=q["fluid"]["trace"]/q["fluid"]["rho"],
                log_plasma_entropy_ratio=logs,log_neutrino_temperature_invariant=lognu,
                neutrino_temperature_ratio=q["Tnu"]/q["T"],predicted_neutrino_temperature_ratio=pred_ratio))
    init=quantities(st,cfg,n,massless);iv=rhs(0,st,cfg,n,massless)
    Rtau=cfg["Rstar"]*fluid["trace"]
    expected_p=-np.sqrt(cfg["a"])*(1+cfg["s"])*Rtau/(init["J"]*init["D"])
    expected_w=2*Rtau/(3*init["D"])
    return dict(parameters=cfg,nodes=n,massless=massless,success=sol.success,
        reached_endpoint=len(sol.t_events[0])==1,message=sol.message,nfev=sol.nfev,njev=sol.njev,
        initial_pprime=float(iv[2]),initial_wprime=float(iv[3]),expected_initial_pprime=expected_p,
        expected_initial_wprime=expected_w,samples=rows,
        sampled_extrema={key:{"minimum":min(r[key] for r in rows),"maximum":max(r[key] for r in rows)}
                         for key in ["Hratio","GNratio","NJprime"]} if rows else {})

def validate_run(name,r,fix,n,strict_massless=False):
    check(name+".success",r.get("success",False),message=r.get("message",r.get("error","")))
    check(name+".endpoint",r.get("reached_endpoint",False))
    rows=r.get("samples",[])
    check(name+".census",len(rows)==fix["sample_count"])
    if not rows:return
    compare(name+".initial_pprime",r["initial_pprime"],r["expected_initial_pprime"],3e-9)
    compare(name+".initial_wprime",r["initial_wprime"],r["expected_initial_wprime"],3e-9)
    cfg=r["parameters"]
    for j,row in enumerate(rows):
        compare(f"{name}.{j}.plasma_entropy",row["log_plasma_entropy_ratio"],0.,3e-7)
        compare(f"{name}.{j}.neutrino_entropy",row["log_neutrino_temperature_invariant"],0.,3e-9)
        compare(f"{name}.{j}.temperature_ratio",row["neutrino_temperature_ratio"],row["predicted_neutrino_temperature_ratio"],3e-7)
        check(f"{name}.{j}.positive",min(row["F"],row["J"],row["Ku"],row["NJprime"])>0)
        if strict_massless:
            compare(f"{name}.{j}.ideal_expansion",row["Hratio"],np.sqrt((1+cfg["b"])/(1+cfg["k0"])),fix["massless_control_tolerance"])
            compare(f"{name}.{j}.u",row["state"][0],0.,fix["massless_control_tolerance"])
            compare(f"{name}.{j}.w",row["state"][3],-2.,fix["massless_control_tolerance"])
        if j in [0,20,40,60,80,100]:
            st=np.array(row["state"]);v=rhs(row["N"],st,cfg,n,r["massless"])
            eps=fix["finite_difference_step"]
            qm=quantities(st-eps*v,cfg,n,r["massless"]);qp=quantities(st+eps*v,cfg,n,r["massless"])
            q=quantities(st,cfg,n,r["massless"])
            h_num=(np.log(qp["H2"])-np.log(qm["H2"]))/(4*eps)
            compare(f"{name}.{j}.energy_identity",h_num,q["h"],fix["conservation_tolerance"])
            sigma_log=(np.log(qp["sigma"])-np.log(qm["sigma"]))/(2*eps)
            wanted=(-3*(q["sigma"]+q["pressure"])+q["ab"]*st[2]*q["tau"])/q["sigma"]
            compare(f"{name}.{j}.fluid_identity",sigma_log,wanted,fix["conservation_tolerance"])

def main():
    pa=argparse.ArgumentParser();pa.add_argument("--freeze",type=Path,required=True);pa.add_argument("--out",type=Path,required=True)
    args=pa.parse_args()
    if args.out.exists():raise FileExistsError(args.out)
    fix=json.loads((HERE/"NUMERICAL_FIXTURES_v1.json").read_text())
    for row in json.loads(args.freeze.read_text())["inputs"]:
        check("source."+row["path"],hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest()==row["sha256"])
    mp.mp.dps=fix["quadrature_reference_digits"]
    thermal=[]
    for j,T in enumerate(fix["quadrature_temperatures"]):
        ref=reference_eos(T)
        for n in [fix["coarse_nodes"],fix["base_nodes"],fix["refined_nodes"]]:
            got=eos(T,T,n)
            for key,value in ref.items():
                compare(f"thermal.{j}.{n}.{key}",got[key],float(value),fix["quadrature_normalized_tolerance"])
            compare(f"thermal.{j}.{n}.trace_identity",got["electron_density_bar"]-3*got["electron_pressure_bar"],got["electron_trace_bar"],2e-13)
            check(f"thermal.{j}.{n}.positive",got["rho"]>0 and got["pressure"]>0 and got["trace"]>0 and got["cT"]>0)
            thermal.append(dict(T=T,nodes=n,computed=got,reference={k:mp.nstr(v,65) for k,v in ref.items()}))
    for T in [.2,1.,5.]:
        tt=mp.mpf(str(T))
        # Derivative of independent energy-variable quadrature: full plasma.
        der=mp.diff(lambda t:t**4*(mp.pi**2/15+reference_eos(t)["electron_density_bar"]),tt)
        near_ref=reference_eos(tt)["heat_capacity_bar"]*tt**3
        error=abs(der-near_ref)/max(mp.mpf(1),abs(near_ref))
        check(f"thermal.reference_heat_derivative.{T}",error<mp.mpf("1e-55"),normalized_error=mp.nstr(error,65))
    histories=[];controls=[];variations=[]
    for k,branch in itertools.product(fix["k_values"],fix["branches"]):
        cfg=parameters(k,branch,fix["R_star"],fix["nu"])
        for massless,dest,label in [(False,histories,"thermal"),(True,controls,"massless")]:
            name=f"{label}.{k}.{branch}"
            try:r=integrate(cfg,fix,fix["base_nodes"],fix["rtol"],fix["atol"],fix["max_step"],massless)
            except Exception as exc:r=dict(parameters=cfg,success=False,error=str(exc),traceback=traceback.format_exc(),samples=[])
            validate_run(name,r,fix,fix["base_nodes"],massless)
            dest.append(r)
            # Own recoverable per-case file written once, before the final report.
            case=args.out.parent/(name+".json")
            with case.open("x") as f:json.dump(r,f,indent=2,allow_nan=False);f.write("\n")
            print(name,r.get("success"),r.get("sampled_extrema",{}),flush=True)
    for case in fix["refinement_cases"]:
        k,branch=case["k"],case["branch"]
        old=next(r for r in histories if r["parameters"]["k0"]==k and r["parameters"]["branch"]==branch)
        for kind,scale in [("refined",fix["R_star"]),("scale",fix["scale_variation_R_star"])]:
            cfg=parameters(k,branch,scale,fix["nu"])
            name=f"{kind}.{k}.{branch}"
            try:r=integrate(cfg,fix,fix["refined_nodes"],fix["refined_rtol"],fix["refined_atol"],fix["refined_max_step"])
            except Exception as exc:r=dict(parameters=cfg,success=False,error=str(exc),traceback=traceback.format_exc(),samples=[])
            validate_run(name,r,fix,fix["refined_nodes"])
            if len(r.get("samples",[]))==len(old.get("samples",[]))==fix["sample_count"]:
                for j,(v,o) in enumerate(zip(r["samples"],old["samples"])):
                    for key in ["Hratio","GNratio","neutrino_temperature_ratio"]:
                        compare(f"{name}.{j}.{key}_convergence",v[key],o[key],fix["solver_comparison_tolerance"])
                    for idx in [0,2,3]:
                        compare(f"{name}.{j}.state{idx}_convergence",v["state"][idx],o["state"][idx],fix["solver_comparison_tolerance"])
            variations.append(dict(kind=kind,run=r))
            with (args.out.parent/(name+".json")).open("x") as f:json.dump(r,f,indent=2,allow_nan=False);f.write("\n")
            print(name,r.get("success"),r.get("sampled_extrema",{}),flush=True)
    ncase=len(fix["k_values"])*len(fix["branches"])
    check("census.histories",len(histories)==ncase and len(controls)==ncase)
    wanted={(k,b) for k,b in itertools.product(fix["k_values"],fix["branches"])}
    for name,rows in [("histories",histories),("massless",controls)]:
        check("census."+name+"_ids",{(r["parameters"]["k0"],r["parameters"]["branch"]) for r in rows}==wanted)
    check("census.variations",len(variations)==2*len(fix["refinement_cases"]))
    check("unique_check_names",len({r["name"] for r in CHECKS})==len(CHECKS))
    result=dict(scope="Fixed synthetic thermal-history test of a supplied action; not a BBN abundance fit or observational likelihood.",
        quadrature=thermal,histories=histories,massless_controls=controls,variations=variations,checks=CHECKS,
        counts=dict(passed=sum(r["passed"] for r in CHECKS),failed=sum(not r["passed"] for r in CHECKS),total=len(CHECKS)))
    with args.out.open("x") as f:json.dump(result,f,indent=2,allow_nan=False);f.write("\n")
    print(json.dumps(result["counts"]),flush=True)
    return int(result["counts"]["failed"]!=0)

if __name__=="__main__":
    raise SystemExit(main())

