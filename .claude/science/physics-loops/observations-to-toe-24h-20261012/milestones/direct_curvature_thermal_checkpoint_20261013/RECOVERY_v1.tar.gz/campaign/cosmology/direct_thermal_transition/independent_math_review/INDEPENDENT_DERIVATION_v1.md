# Independent derivation of the thermal transition equations

Reviewer `/root/launch_check`, 2026-10-13. The two exact source notes are frozen in `INPUT_FREEZE_v1.json`. This derivation starts with the admitted equilibrium distributions and the supplied fixed-sector action. It does not use an author implementation, interpolate an author table, or import an upstream review verdict.

## Domain and imported model

Take the parent curvature action with fixed sector constants `q,H_v,nu>0`, `0<a,b<1/3`, `s=zeta/q>=0`, and `C/H_v^2=3s/2`. Put `alpha=sqrt(a)`. The original auxiliary variation is not performed here: s is a sector constant for field differentiation, not asserted independent of q in the unreduced action. Write

\[
E_A=e^{2\alpha u},\quad z=sE_A,\quad F=1+z,\quad J=1+(1-3a)z,
\quad D=1+\frac{2(1+b)y^2}{3}.
\]

The restriction x=xdot=0 is invariant: the potential's x derivative and the x derivative of the metric coefficients vanish there; the matter conformal factor has no x dependence. Thus all x forces and connection terms without an x velocity vanish. On this submanifold the supplied Einstein action is

\[
S=q\int\sqrt{-\hat g}\left[\frac{\hat R}{2}
-K_u(\partial u)^2-K_y(\partial y)^2-2\hat V\right]+S_m[B^2\hat g],
\]

with `K_u=J/F^2`, `K_y=(1+s)b/(3FD)`, `B^2=E_A/F` and `hat V=W/F^2`. Positivity is strict throughout finite real fields in this domain. Logarithmic y requires y>0. It covers the supplied positive initial branch and is not a coordinate chart at y=0 or negative y.

For the cooling integration use the positive Einstein expansion root, `Hhat>0`, `3-Q>0`, and `1+alpha_B p>0`. A positive H2 alone is a squared constraint, not a separate sign choice for Hhat; the intended expanding branch fixes that sign. These are finite-trajectory domain conditions. No global continuation theorem for this enlarged action is being assumed.

## 1. Fermi integrals from phase space and thermodynamics

The source's dimensionless physical Jordan variables use `hbar=c=k_B=m_e=1`. With zero chemical potential, `E=sqrt(p^2+1)`, `f=(exp(E/T)+1)^-1`, and electron-plus-positron degeneracy g=4, isotropic phase-space integration gives

\[
\rho_e=\frac{g}{2\pi^2}\int_0^\infty p^2E f\,dp,
\qquad P_e=\frac{g}{6\pi^2}\int_0^\infty\frac{p^4}{E}f\,dp.
\]

The pressure follows from one third of momentum times velocity, `p^2/(3E)`. No chemical-potential contribution has been omitted under the declared assumption. Since

\[
\partial_T f=\frac{E}{T^2}f(1-f),\qquad
\partial_p f=-\frac{p}{ET}f(1-f),
\]

one obtains exactly

\[
\rho_{e,T}=\frac{g}{2\pi^2T^2}\int_0^\infty p^2E^2 f(1-f)\,dp>0,
\quad
\rho_e-3P_e=\frac{g}{2\pi^2}\int_0^\infty\frac{p^2}{E}f\,dp>0.
\]

The trace identity uses `E^2-p^2=1`, so the numerator is the rest-mass squared in general units. Differentiation under the integral is valid on every compact positive-temperature interval: the massive integrands and their temperature derivatives have integrable exponential tails. The boundary term `p^3 E f` vanishes at both endpoints. Integration by parts then gives

\[
P_{e,T}=\frac{g}{6\pi^2T^2}\int p^4f(1-f)dp
=\frac{g}{6\pi^2T}\int(3p^2E+p^4/E)f\,dp
=\frac{\rho_e+P_e}{T}.
\]

An independent thermodynamic starting point is the grand pressure

\[
P_{\rm grand}(T)=\frac{gT}{2\pi^2}\int p^2\log(1+e^{-E/T})dp.
\]

Integration by parts gives the same momentum-flux pressure; differentiation gives `rho=T P_T-P` and `rho_T=T P_TT`. These provide independent routes for the bounded high-precision quadrature controls.

Photons have `rho_gamma=pi^2 T^4/15`, `P_gamma=rho_gamma/3`. One massless neutrino/antineutrino pair has g=2 and hence `rho=7pi^2 T_nu^4/120`; three pairs give the source's factor of three. The massless identity `integral x^3/(exp(x)+1) dx=7pi^4/120` follows from the alternating exponential series, `6(1-2^-3)zeta(4)`. At a common temperature the admitted species give `g_*=2+(7/8)(4+6)=43/4`. Species content and instantaneous decoupling are stipulated physics, not observations or consequences of the scalar action.

## 2. Plasma entropy, decoupled neutrinos and fluid conservation

For the photon/pair plasma set `rho_pl=rho_gamma+rho_e`, `P_pl=P_gamma+P_e`, `s_pl=(rho_pl+P_pl)/T`. The pressure identity above and its photon counterpart imply

\[
T s_{{\rm pl},T}=\rho_{{\rm pl},T}.
\]

Separate Jordan energy conservation,
`d rho_pl/dt_J +3 H_J(rho_pl+P_pl)=0`, is therefore equivalent to conservation of `s_pl b_J^3`. On a positive expanding branch,

\[
\frac{d\ln T}{dN_J}=-\frac{3(\rho_{\rm pl}+P_{\rm pl})}{T\rho_{{\rm pl},T}}
=-c_T(T),\qquad c_T>0.
\]

Massless collisionless neutrinos with the supplied initial Fermi distribution retain its shape with `T_nu b_J=T_i b_{J,i}`, so `d ln T_nu/dN_J=-1`. Eliminating the scale factor between these two conserved quantities gives exactly

\[
\frac{T_\nu}{T}
=\left[\frac{s_{\rm pl}(T)/T^3}{s_{\rm pl}(T_i)/T_i^3}\right]^{1/3}.
\]

The plasma's relativistic entropy degrees are `2+7*4/8=11/2`, while after pair disappearance the value approaches 2. Thus the infinite-initial-temperature limit is `(4/11)^(1/3)`. At finite T_i=10 the denominator is the actual massive-plasma entropy, not its infinite-temperature limit. The endpoint T_f=.01 has exponentially suppressed, rather than mathematically zero, pair density.

The total Jordan fluid satisfies the same total conservation law because the plasma and neutrino sectors are separately conserved. Only the pairs contribute the trace. Enforcing `rho_total proportional b_J^-4` through the transition would replace that conservation law by a different equation and discard the positive pair trace.

## 3. Einstein-frame density, constraint and exchange

With `g_J=B^2 ghat`, a physical matter stress tensor has `rhohat=B^4 m_e^4 rho`, `Phat=B^4 m_e^4 P`. Define

\[
\hat H_v^2=\frac{H_v^2}{1+s},\quad
R_*=\frac{m_e^4}{2q(1+s)H_v^2},\quad C_B=(1+s)B^2.
\]

Consequently

\[
\sigma=\frac{\hat\rho}{2q\hat H_v^2}=C_B^2R_*\rho,
\qquad\pi_f=C_B^2R_*P.
\]

All factors of `1+s` follow from using both a physical density and the fixed vacuum Einstein frequency; R_* is a supplied dimensionless ratio. The normalized potential is

\[
U=\frac{\hat V}{\hat H_v^2}
=\frac{1+s}{F^2}\left[\frac32+\frac{\nu u^2}{2}
+\frac{b(1+s)y^2}{3}+\frac{3s}{2}E_A^2\right].
\]

For `N=ln b_hat`, `p=u'`, `ell=ln y`, `w=ell'`, the normalized velocity squared is `Q=K_u p^2+K_y y^2w^2`. The Einstein equations from the displayed action are

\[
3\hat H^2=\frac{\hat\rho}{q}+K_{ij}\dot\phi^i\dot\phi^j+2\hat V,
\quad \dot{\hat H}=-\frac{\hat\rho+\hat P}{2q}-K_{ij}\dot\phi^i\dot\phi^j.
\]

They yield precisely

\[
H2=\frac{\hat H^2}{\hat H_v^2}=\frac{2(\sigma+U)}{3-Q},
\qquad h=\frac{\hat H'}{\hat H}=-\frac{\sigma+\pi_f}{H2}-Q.
\]

Here `d ln B/du=alpha_B=alpha/F`. Since `b_J=B b_hat`, `N_J'=1+alpha_B p`. Differentiating `sigma proportional B^4 rho` and using the Jordan conservation equation gives the independent trace-exchange check

\[
\sigma'=-3(\sigma+\pi_f)+\alpha_B p(\sigma-3\pi_f).
\]

The positive sign of this exchange term and the positive trace force in the scalar equation are consistent: scalar and fluid energy exchange cancel in the total Einstein energy balance.

## 4. Scalar equations and logarithmic y

The fixed-sector scalar variation gives

\[
D_{\hat t}\dot\phi^i+3\hat H\dot\phi^i
+K^{ij}\left(\hat V_{,j}+\alpha_{B,j}\frac{\hat\rho-3\hat P}{2q}\right)=0,
\]

where `alpha_{B,j}=partial_j ln B=(alpha_B,0)`. In N variables this becomes

\[
v^{i\prime}=-(3+h)v^i-\Gamma^i{}_{jk}v^jv^k
-\frac{K^{ij}}{H2}\left(U_{,j}+\alpha_{B,j}(\sigma-3\pi_f)\right),
\quad v=(p,yw).
\]

Direct differentiation of the diagonal metric gives

\[
\Gamma^u_{uu}=\alpha z\left(\frac{1-3a}{J}-\frac2F\right),\quad
\Gamma^u_{yy}=\frac{\alpha zK_y}{FK_u},\quad
\Gamma^y_{uy}=-\frac{\alpha z}{F},\quad
\Gamma^y_{yy}=-\frac{2(1+b)y}{3D}.
\]

The other mixed force coefficients relevant here vanish. Also

\[
U_u=\frac{1+s}{F^2}(\nu u+6\alpha s E_A^2)-\frac{4\alpha z}{F}U,
\qquad U_y=\frac{2b(1+s)^2y}{3F^2}.
\]

Substituting gives exactly the source's p equation. For y, the extra chain-rule term is essential: `y''/y=w'+w^2`. Hence

\[
w'=-(3+h)w+\frac{2\alpha z}{F}pw
-\left[1-\frac{2(1+b)y^2}{3D}\right]w^2
-\frac{U_y}{K_y y H2}
=-(3+h)w+\frac{2\alpha z}{F}pw-\frac{w^2}{D}
-\frac{2(1+s)D}{F H2}.
\]

Multiplying the plasma/neutrino temperature derivatives by `N_J'` gives the two source temperature equations. The equations neither force u nor the physical Newton diagnostic to be constant.

A further consistency check does not assume the Friedmann constraint stays true. Metric compatibility gives

\[
Q'=-2(3+h)Q-\frac{2}{H2}\left(U'+\alpha_Bp(\sigma-3\pi_f)\right).
\]

Differentiating `3H2-H2 Q-2sigma-2U` and inserting this identity and the independently transformed fluid law leaves `6H2[h+Q+(sigma+pi_f)/H2]`, which vanishes by Raychaudhuri. Thus the scalar, thermodynamic and metric equations preserve the same constraint.

## 5. Initial state and nonzero thermal trace

The supplied initial conditions `u=p=0`, `y_i^2=R_*rho_i`, `w=-2`, `T=T_nu=T_i` give `C_B=1`, `sigma_i=y_i^2`, `K_y=b/(3D_i)` and `U_i=3/2+b y_i^2/3`. Substitution into the constraint gives `H2_i=D_i` for the actual finite-temperature density, independently of the pressure.

Let `tau_i=rho_i-3P_i>0` and `J0=1+(1-3a)s`. Evaluating the full equations then gives the exact independent initial-acceleration checks

\[
p'_i=-\frac{\alpha(1+s)R_*\tau_i}{J0 D_i}<0,
\qquad w'_i=\frac{2R_*\tau_i}{3D_i}>0.
\]

At this point the u connection and potential terms cancel; the finite trace leaves the displayed force. The pressure shift changes h by `R_*tau_i/(3D_i)` relative to its ideal-radiation value, giving the w result. This shows explicitly why the finite-temperature initial data satisfy the Friedmann constraint but are not exact ideal tracking data for subsequent evolution. In the massless control both accelerations vanish, `y proportional exp(-2N)`, `T=T_nu proportional exp(-N)` and u=0 persist.

## 6. Physical Hubble rate and weak-body reference

Physical proper time is `dt_J=B dthat`. Therefore

\[
H_J=\frac{\hat H}{B}(1+\alpha_Bp),\qquad
\frac{H_J^2}{H_v^2}=\frac{H2(1+\alpha_Bp)^2}{C_B}.
\]

With the positive Einstein root and positive `N_J'`, the physically relevant H_J is positive. Squaring alone would lose this sign information; the branch restriction must remain in any numerical result.

Within the explicitly supplied locally frozen, long-range, weak-body scalar bridge, the field-space scalar charge is

\[
k(u)=K^{uu}(\partial_u\ln B)^2=\frac{a}{J},\quad
G_N(u)=\frac{B^2}{8\pi q}(1+k(u)),\quad
G_{N0}=\frac{1+k_0}{8\pi q(1+s)}.
\]

Consequently `G_N/G_N0=C_B(1+k)/(1+k0)`. This is a diagnostic under that bridge, not a thermal-plasma PPN calculation or a proof that the scalar is light on every relevant scale.

The specified GR comparator uses the same physical rho and the fixed reference G_N0:

\[
\frac{H_{\rm GR}^2}{H_v^2}=1+\frac{8\pi G_{N0}m_e^4\rho}{3H_v^2}
=1+\frac23(1+k_0)R_*\rho.
\]

On the ideal u=0 radiation orbit the total squared ratio is `(1+(2/3)(1+b)R_*rho)/(1+(2/3)(1+k0)R_*rho)`. Its fluid-dominated limit is `(1+b)/(1+k0)`. In the actual thermal system u, p, entropy and trace all evolve, so that ideal limiting ratio cannot replace the full expression. The b=a and b=k0 branches are distinct preselected models/calibrations; changing them after looking at trajectories would change the experiment being proposed.

## Scope of this result

The mathematical equations are internally consistent within the declared species, ideal-gas, decoupling, frame and fixed-sector assumptions. This proof does not check the parent's forthcoming integral table, interpolation derivatives, solver, tolerances, domain exclusions or plotted histories. It does not verify the primary-paper reading claims, reproduce precise neutrino transport, estimate abundances, supply an observational likelihood, prove a global stability theorem, derive the admitted matter sector, or grant audit/publication status. Those are distinct obligations.
