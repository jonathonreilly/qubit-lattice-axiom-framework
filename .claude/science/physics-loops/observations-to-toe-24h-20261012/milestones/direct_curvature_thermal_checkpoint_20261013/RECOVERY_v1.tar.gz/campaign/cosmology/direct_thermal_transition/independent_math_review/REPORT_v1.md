# Independent handwritten thermal-transition review

Reviewer `/root/launch_check`, 2026-10-13. Parent `/root` remains the author. This is the requested bounded independent mathematical check, not packaging, an author implementation review, or a formal audit.

**PASS within the displayed assumptions and local branch domain.** I found no material error in the admitted Fermi integrals, entropy laws, full Einstein-frame u/log-y/temperature equations, or physical Hubble/Newton reference transforms. The complete independent argument is in `INDEPENDENT_DERIVATION_v1.md`. This conclusion is bound to the exact source bytes below; it does not certify later implementation or observational adequacy.

| Reviewed source | SHA-256 |
|---|---|
| `direct_thermal_transition/HAND_DERIVATION_v1.md` | `0bd3d91fdec1d11fd9200cce4f910c751baba08e2cf1188089e1f75d9fc5edd8` |
| `direct_curvature_fluid_reconstruction/HAND_DERIVATION_v1.md` | `2ee1ebdbb34462010b8c9e34fa90466f173948a1ab5fbb940231b20c701db04f` |

Both complete notes were read and frozen. The first is the reviewed thermal argument; the second supplies its explicit action and parameter/frame definitions. The upstream unreduced auxiliary variation, its broader local-vacuum results and full action review remain the separate curvature-action check. No verdict from that other reviewer is assumed here. Available origin/main was pinned at `516cb69d8487ff04f8a48e065d3dcbe71d7dd237`; the current science worktree HEAD was `4f349b09c2aff65dc9e55c9e040175c091b32b61`. No fetch or Git mutation was performed.

## Independent reasoning and coverage

The thermal derivation starts with isotropic phase space and the supplied zero-chemical-potential Fermi distribution. It independently differentiates the occupation number, derives the positive pair trace using `E^2-p^2=1`, and proves `dP/dT=(rho+P)/T` by an integration by parts with vanishing endpoint terms. This yields `rho_T=T s_T`, plasma entropy conservation, the positive cooling factor and the algebraic neutrino/photon temperature ratio. The degeneracy factor g=4 for electrons/positrons and the factor `3*(7pi^2/120)` for the three neutrino/antineutrino pairs are consistent.

The separate high-precision thermodynamic route uses the grand pressure integral `gT/(2pi^2) integral p^2 log(1+exp(-E/T)) dp`. Its first and second derivatives supply rho and heat capacity without an author helper or reference table. The massless degree counts give `g_*=43/4` and the asymptotic entropy ratio `(4/11)^(1/3)`. The finite chosen initial temperature must use its actual entropy instead.

For the dynamical system, I derived the Euler-Lagrange/Friedmann/Raychaudhuri equations from the supplied fixed-sector Einstein action. The explicit diagonal-metric Christoffels reproduce all u and y connection terms. In particular, converting `y'=yw` requires the extra `-w^2`; it combines with `Gamma^y_yy` to give precisely `-w^2/D`. The displayed potential gradients, source-force sign and all normalization factors agree.

The physical fluid transformation is `rhohat=B^4 m_e^4 rho`, giving `sigma=C_B^2 R_star rho` with the source's `R_star` and `Hhat_v`. Independently transforming the Jordan conservation law gives `sigma'=-3(sigma+pi_f)+alpha_B p(sigma-3pi_f)`. Its exchange term cancels the scalar work term, and differentiating the Friedmann constraint reduces to the displayed Raychaudhuri equation. This checks the interaction of thermodynamics and scalar dynamics rather than merely inspecting individual equations.

The physical-clock relation gives `H_J=Hhat(1+alpha_B p)/B` and the stated squared expression. The intended positive Einstein expansion root must accompany `H2>0` and `N_J'>0`; those latter inequalities alone do not specify a sign for a squared Hubble variable. This is the source's intended expanding/cooling branch, not a new all-trajectory theorem. The required finite-domain inequalities and the y>0 log chart must remain explicit in implementation outputs.

Under the source's conditional locally frozen, long-range weak-body bridge, the scalar norm is `K^{uu}(partial_u ln B)^2=a/J`, and `G_N=B^2(1+k)/(8pi q)`. This yields the displayed reference ratio and GR expansion formula at the same physical temperatures/densities and fixed G_N0. It does not establish that this bridge is physically valid throughout the early plasma; the source properly calls it a diagnostic.

## Exact initial-state consequence

For the supplied finite-temperature initial data, the Friedmann equation gives `H2_i=D_i` exactly, although the ideal tracking trajectory does not persist. With `tau_i=rho_i-3P_i` and `J0=1+(1-3a)s`, direct substitution gives

\[
p'_i=-\frac{\sqrt a(1+s)R_*\tau_i}{J0D_i},\qquad
w'_i=\frac{2R_*\tau_i}{3D_i}.
\]

The finite pair trace therefore initially drives u toward negative values and changes the log-y velocity toward larger values. Both derivatives vanish in the massless ideal control. These are independent exact consequences usable as implementation checks; no author source mutation was executed in this handwritten review.

## Actual verification and limitations

The first bounded check execution completed in about 11.13 seconds with **62 passed, zero failed, exit code 0**, and empty stderr. It contains 35 exact symbolic identities, 20 thermodynamic cross-route comparisons, four positive-integrand/cooling checks, one finite-initial-entropy consequence and two unchanged-source checks. All full residuals/results and actual execution evidence are preserved. These counts are mathematical/control checks, not independent experiments.

The thermal comparisons used 70-digit arithmetic at `T/m_e=0.05,0.2,1,10` and the predeclared relative tolerance `1e-30`, unchanged throughout. The largest measured cross-route relative discrepancy was about `8.28e-69`. This is consistency of two numerical representations; the analytic integral identities supply the mathematical argument. It is not a certified bound for the parent's quadrature/interpolation table.

The idealized late ratio for finite `T_i/m_e=10` is `T_nu/T=0.71393016904493862656`, compared with the infinite-initial-temperature limit `0.71376585550360817067`. The late value is an asymptotic pair-disappearance limit under the declared entropy model, not an observation or a computed reaction-network result.

All physical matter species/statistics, the electron mass, high-temperature initial state, instantaneous decoupling, universal metric coupling, scalar initial conditions and action parameters remain supplied assumptions. The b=a and b=k0 branches remain separately preselected; nothing is fitted to these checks. No new matter axiom, measured gravity/vacuum scale, exact Standard Model N_eff, BBN/CMB likelihood or light-element prediction is established.

No parent table, interpolation recipe, trajectory solver, numerical stopping rule, refinement study or failure/exclusion log was reviewed. Reaching T_f with a valid positive branch is a later numerical question, not guaranteed by this derivation. The precise primary-paper reading assertions, neutrino transport, QED corrections, omitted species, weak/nuclear reactions, baryon density, perturbations, late matching, global stability and quantum completion remain outside this check. The admitted formulas are derived directly here; no primary paper's numerical summary is used as an oracle.

All writes are confined to `direct_thermal_transition/independent_math_review/`. There were no author edits, original-evidence rewrites, model changes, Git/PR operations, audit applications or other-chat messages. Both exact source notes remain unchanged in the final identity receipt. `RECEIPT_v1.json` binds the source snapshots, derivation, controls, actual outputs and this report.
