"""Independent exact derivation and bounded thermodynamic quadrature; no author imports."""
import datetime, hashlib, json, pathlib, platform, sys, time
import sympy as S
import mpmath as M
OUT=pathlib.Path(__file__).resolve().parent
M.mp.dps=70
checks=[]
def exact(name,expr):
 r=S.factor(S.cancel(S.simplify(expr)))
 checks.append({'name':name,'passed':r==0,'residual':str(r),'kind':'exact symbolic identity'})
def numerical(name,got,expected):
 scale=max(abs(got),abs(expected),M.mpf('1e-70'))
 error=abs(got-expected)/scale
 checks.append({'name':name,'passed':error<M.mpf('1e-30'),'relative_error':M.nstr(error,35),'tolerance':'1e-30','got':M.nstr(got,45),'expected':M.nstr(expected,45),'kind':'independent thermodynamic routes'})
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
u,y=S.symbols('u y',real=True);c,b,s,nu,q,Hv,me=S.symbols('alpha b s nu q Hv me',positive=True)
p,w,h,H2,sigma,pif,R,tau=S.symbols('p w h H2 sigma pif R tau',real=True)
E=S.exp(2*c*u);z=s*E;F=1+z;J=1+(1-3*c*c)*z;D=1+2*(1+b)*y*y/3
Ku=J/F**2;Ky=(1+s)*b/(3*F*D);K=S.diag(Ku,Ky);Ki=S.diag(1/Ku,1/Ky);coords=(u,y)
Gamma={}
for i in range(2):
 for j in range(2):
  for k in range(2):
   Gamma[i,j,k]=sum(Ki[i,l]*(S.diff(K[l,k],coords[j])+S.diff(K[l,j],coords[k])-S.diff(K[j,k],coords[l]))/2 for l in range(2))
U=(1+s)*(S.Rational(3,2)+nu*u*u/2+b*(1+s)*y*y/3+S.Rational(3,2)*s*E**2)/F**2
alphaB=c/F
Uu=(1+s)*(nu*u+6*c*s*E**2)/F**2-4*c*z*U/F
exact('fixed-sector U_u',S.diff(U,u)-Uu)
exact('fixed-sector U_y',S.diff(U,y)-2*b*(1+s)**2*y/(3*F**2))
exact('Gamma_u_uu',Gamma[0,0,0]-c*z*((1-3*c*c)/J-2/F))
exact('Gamma_u_yy',Gamma[0,1,1]-c*z*Ky/(F*Ku))
exact('Gamma_y_uy',Gamma[1,0,1]+c*z/F)
exact('Gamma_y_yy',Gamma[1,1,1]+2*(1+b)*y/(3*D))
exact('Gamma_u_uy zero',Gamma[0,0,1])
exact('Gamma_y_uu zero',Gamma[1,0,0])
v=(p,y*w);du=[S.diff(U,co) for co in coords];matter=(alphaB*(sigma-3*pif),0)
acc=[-(3+h)*v[i]-sum(Gamma[i,j,k]*v[j]*v[k] for j in range(2) for k in range(2))-(du[i]+matter[i])/(K[i,i]*H2) for i in range(2)]
p_written=-(3+h)*p-c*z*((1-3*c*c)/J-2/F)*p*p-c*z*Ky*y*y*w*w/(F*Ku)-(Uu+alphaB*(sigma-3*pif))/(Ku*H2)
w_written=-(3+h)*w+2*c*z*p*w/F-w*w/D-2*(1+s)*D/(F*H2)
exact('u N-equation from covariant equation',acc[0]-p_written)
exact('log-y N-equation including extra -w squared',acc[1]/y-w*w-w_written)
B2=E/F;CB=(1+s)*B2;Hstar2=Hv*Hv/(1+s);Rstar=me**4/(2*q*(1+s)*Hv*Hv)
exact('alpha_B from B squared derivative',S.diff(B2,u)/(2*B2)-alphaB)
exact('normalized density factor',B2**2*me**4/(2*q*Hstar2)-CB**2*Rstar)
Q=(v[0]*v[0]*Ku+v[1]*v[1]*Ky)
Hsol=2*(sigma+U)/(3-Q)
exact('Friedmann solution',3*Hsol-Hsol*Q-2*(sigma+U))
h_written=-(sigma+pif)/H2-Q
exact('Raychaudhuri normalization',h_written+Q+(sigma+pif)/H2)
Qdot=sum(S.diff(Q,coords[i])*v[i] for i in range(2))+2*Ku*p*acc[0]+2*Ky*y*w*acc[1]
# In this derivative Q is a quadratic form in independent coordinate velocities;
# the explicit y derivative must hold y*w fixed. Remove its artificial derivative.
Qdot-=2*Ky*y*w*w*v[1]
Udot=sum(du[i]*v[i] for i in range(2))
exact('covariant scalar kinetic-work identity',Qdot+2*(3+h)*Q+2*(Udot+alphaB*p*(sigma-3*pif))/H2)
sigmadot=-3*(sigma+pif)+alphaB*p*(sigma-3*pif)
constraintdot=2*h*H2*(3-Q)-H2*Qdot-2*sigmadot-2*Udot
exact('constraint derivative agrees with Raychaudhuri',constraintdot.subs(h,h_written))
exact('Jordan fluid to Einstein trace exchange',4*alphaB*p*sigma-3*(sigma+pif)*(1+alphaB*p)-sigmadot)
exact('physical H squared transform',Hstar2*H2*(1+alphaB*p)**2/(B2*Hv*Hv)-H2*(1+alphaB*p)**2/CB)
k=c*c/J;k0=k.subs(u,0)
exact('scalar exchange norm',alphaB**2/Ku-k)
G0=(1+k0)/(8*S.pi*q*(1+s));Gu=B2*(1+k)/(8*S.pi*q)
exact('weak-body Newton reference at zero field',Gu.subs(u,0)-G0)
exact('weak-body Newton ratio',Gu/G0-CB*(1+k)/(1+k0))
rho=S.symbols('rho',positive=True)
exact('GR comparison normalization',1+8*S.pi*G0*me**4*rho/(3*Hv*Hv)-(1+S.Rational(2,3)*(1+k0)*Rstar*rho))
# Initial state: sigma=y^2 and total pressure=(y^2-R*tau)/3.
init={u:0,p:0,w:-2,sigma:y*y,pif:(y*y-R*tau)/3}
Hi=S.simplify(Hsol.subs(init));hi=S.simplify(h_written.subs(init).subs(H2,D))
exact('supplied initial Friedmann state H2=D',Hi-D)
pi=S.simplify(p_written.subs(init).subs(H2,D).subs(h,hi))
wi=S.simplify(w_written.subs(init).subs(H2,D).subs(h,hi))
J0=1+(1-3*c*c)*s
exact('initial finite-trace u acceleration',pi+c*(1+s)*R*tau/(J0*D))
exact('initial finite-trace log-y acceleration',wi-2*R*tau/(3*D))
exact('massless control u acceleration zero',pi.subs(tau,0))
exact('massless control log-y acceleration zero',wi.subs(tau,0))
exact('ideal total H ratio separates vacuum and fluid',D/(1+S.Rational(2,3)*(1+k0)*y*y)-(1+S.Rational(2,3)*(1+b)*y*y)/(1+S.Rational(2,3)*(1+k0)*y*y))
# Pointwise FD differential and integration-by-parts identities (m=1).
t,pr=S.symbols('T momentum',positive=True);en=S.sqrt(1+pr*pr);fd=1/(S.exp(en/t)+1)
exact('Fermi occupation temperature derivative',S.diff(fd,t)-en*fd*(1-fd)/t**2)
exact('Fermi occupation momentum derivative',S.diff(fd,pr)+pr*fd*(1-fd)/(en*t))
exact('rho minus3P trace integrand',pr*pr*en*fd-pr**4*fd/en-pr*pr*fd/en)
exact('pressure derivative IBP primitive',S.diff(pr**3*en,pr)-(3*pr*pr*en+pr**4/en))
# Exact relativistic degeneracy/entropy limits.
exact('fermion massless x cubed integral',(1-S.Rational(1,8))*S.factorial(3)*S.zeta(4)-7*S.pi**4/120)
exact('photon pair neutrino gstar43/4',2+S.Rational(7,8)*(4+6)-S.Rational(43,4))
exact('plasma entropy degree ratio4/11',S.Rational(2,1)/(2+S.Rational(7,8)*4)-S.Rational(4,11))
# A second pressure route from the grand partition function is independent of
# the momentum-flux pressure expression; differentiation yields rho and rho_T.
g=M.mpf(4);segments=[M.mpf(0),M.mpf(1),M.mpf(4),M.mpf(16),M.mpf(64),M.inf]
def parts(T):
 T=M.mpf(T);r=1/T
 def eps(x):return M.sqrt(x*x+r*r)
 def f(x):return 1/(M.exp(eps(x))+1)
 dens=g*T**4/(2*M.pi**2)*M.quad(lambda x:x*x*eps(x)*f(x),segments)
 pressure=g*T**4/(6*M.pi**2)*M.quad(lambda x:x**4/eps(x)*f(x),segments)
 trace=g*T*T/(2*M.pi**2)*M.quad(lambda x:x*x/eps(x)*f(x),segments)
 deriv=g*T**3/(2*M.pi**2)*M.quad(lambda x:x*x*eps(x)**2*f(x)*(1-f(x)),segments)
 return dens,pressure,trace,deriv

def grandP(T):
 r=1/T
 return g*T**4/(2*M.pi**2)*M.quad(lambda x:x*x*M.log1p(M.exp(-M.sqrt(x*x+r*r))),segments)
thermal=[]
for text in ['0.05','0.2','1','10']:
 T=M.mpf(text);de,pe,tr,dr=parts(T);gp=grandP(T);gp1=M.diff(grandP,T);gp2=M.diff(grandP,T,2)
 numerical('T='+text+' pressure grand-potential route',pe,gp)
 numerical('T='+text+' density grand-potential derivative',de,T*gp1-gp)
 numerical('T='+text+' heat capacity grand-potential derivative',dr,T*gp2)
 numerical('T='+text+' independent trace integral',de-3*pe,tr)
 numerical('T='+text+' entropy equals pressure derivative',(de+pe)/T,gp1)
 photon=M.pi**2*T**4/15;rho_pl=photon+de;P_pl=photon/3+pe;dr_pl=4*photon/T+dr
 cT=3*(rho_pl+P_pl)/(T*dr_pl)
 checks.append({'name':'T='+text+' positive trace/cooling/domain','passed':de>0 and pe>0 and tr>0 and dr>0 and cT>0,'kind':'finite positive-integrand control'})
 thermal.append({'T':text,'rho_e':M.nstr(de,45),'P_e':M.nstr(pe,45),'trace_e':M.nstr(tr,45),'rho_e_T':M.nstr(dr,45),'s_pl_over_T3':M.nstr((rho_pl+P_pl)/T**4,45),'c_T':M.nstr(cT,45)})
r10=thermal[-1];s_i=M.mpf(r10['s_pl_over_T3']);limit=(4*M.pi**2/45/s_i)**(M.mpf(1)/3)
ideal=(M.mpf(4)/11)**(M.mpf(1)/3)
checks.append({'name':'finite Ti10 late neutrino ratio above asymptotic4/11 value','passed':limit>ideal,'kind':'finite initial entropy consequence','finite_Ti_ratio':M.nstr(limit,45),'infinite_Ti_ratio':M.nstr(ideal,45)})
freeze=json.loads((OUT/'INPUT_FREEZE_v1.json').read_text())
for e in freeze['inputs']:
 if 'path' in e:
  got=hashlib.sha256(pathlib.Path(e['path']).read_bytes()).hexdigest()
  checks.append({'name':'source unchanged '+e['path'],'passed':got==e['sha256'],'kind':'identity','actual_sha256':got})
result={'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'precision_digits':M.mp.dps,'python':sys.version,'sympy':S.__version__,'mpmath':M.__version__,'checks':checks,'passed':sum(bool(c['passed']) for c in checks),'failed':sum(not bool(c['passed']) for c in checks),'failed_checks':[c for c in checks if not c['passed']],'thermal_rows':thermal,'finite_Ti10_late_Tnu_T':M.nstr(limit,45),'infinite_Ti_Tnu_T':M.nstr(ideal,45),'author_helper_imports':0,'parent_implementation_reviewed':False,'independent_empirical_tests':0}
with (OUT/'CHECK_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':result['failed_checks'],'elapsed_seconds':result['elapsed_seconds'],'finite_Ti10_late_Tnu_T':result['finite_Ti10_late_Tnu_T']},indent=2))
raise SystemExit(0 if result['failed']==0 else 1)
