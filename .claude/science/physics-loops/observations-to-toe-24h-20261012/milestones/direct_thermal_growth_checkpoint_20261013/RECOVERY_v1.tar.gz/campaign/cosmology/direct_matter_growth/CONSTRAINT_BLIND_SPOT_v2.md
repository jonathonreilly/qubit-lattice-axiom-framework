# Preserved first operator check and independent scalar control

The first frozen execution produced31 passed/1 failed. All full operator,
constraint and continuity identities passed. The deliberate omitted dust source
in the u acceleration was not detected by energy-constraint propagation.
The failed assertion that this check must detect every omission was wrong:
u has zero background velocity, so the linear constraint has no u-prime
coefficient and is blind to its acceleration row. This is not evidence that
the dust source can be omitted. Both the original code and31/1 evidence remain.

Version2 keeps the physical operator unchanged and independently linearizes the
lowered Euler-Lagrange momenta from the raw kinetic and potential action.
It compares every coefficient of both scalar equations, including the density
source, against the coordinate-connection operator. Actual equation omissions
are recorded against both controls; no conservation-only success is promoted
to a full field-equation check. No trajectory or observation has yet been run.

The handwritten reviewer independently encountered a different surviving
mistake: substituting sigma=x² before differentiating. That changes an entry
in the same u acceleration row, also unseen by the energy constraint and
rejected by the lowered equation. That independent evidence is preserved by
the reviewer, and is not counted as an author test here.
