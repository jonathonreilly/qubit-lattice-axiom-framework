# Parent direct matter, scalar and metric perturbations — handwritten v1

Written before code or comparison. This tests a new obligation in the same
curvature/fluid action, keeping its constants fixed. All earlier qualifications
remain: supplied action, ideal dust, flat background, chosen sector and initial
state, light weak-body local G_N bridge. No observed perturbation data have been
opened for this block. Later comparisons must distinguish exposed development
benchmarks from independent tests. No radiation, nonlinear structure, screening,
bias, neutrino transport or CMB transfer function is supplied by this block.

## 1. Background and units

Take the already independently checked curvature/fluid action and set y=0,
radiation=0, C=3s H_v^2/2. The y-odd linear sector decouples on this background;
this block treats scalar metric modes, u,x and pressureless matter only.
Use Einstein proper time in units Hhat_v=H_v/sqrt(1+s), N=ln(a_E/a_E0),
H=Hhat/Hhat_v, U=Vhat/Hhat_v^2, sigma=rho_E/(2q Hhat_v^2).
The exact background is
  u=0, x=x0 exp(-3N/2), p=(u',x')=(0,-3x/2),
  sigma=x^2, H^2=D=1+2(1+b)x^2/3,
  h=H'/H=-(1+b)x^2/D.
K is the u,x block of Khat. A prime denotes d/dN, an overdot normalized
Einstein proper-time differentiation. B=exp(sqrt(a)u)/sqrt(1+s exp(2sqrt(a)u)),
alpha_i=partial_i log B=(alpha_B,0), alpha_B=sqrt(a)/F.

For the k parameter of the earlier diagnostic eta=0 family, specify
  a=(1-k)(1+3k)/4, s=(1+k)/[k(1-3k)], 0<k<1/3.
The primary calibrated branch b=k and a diagnostic old branch b=a remain
separate. Let Q be the physical Einstein wavenumber divided by Hhat_v,
Q^2(N)=Q0^2 exp(-2N). This Q is not the auxiliary variable q.

## 2. Full linear equations in Newtonian gauge

Write
  ds_E^2=-(1+2Phi)dt_E^2+a_E^2(1-2Phi)dX^2.
The equality of the two Einstein potentials uses zero linear anisotropic
stress of the specified scalar fields and dust. Fourier perturbations are
v=(dphi^i,w^i,delta,Theta,Phi), with dphi=(du,dx), w=dphi/dN,
delta=delta rho_E/rho_E and Theta=theta_E/Hhat. theta_E is the divergence of
peculiar velocity divided by a_E. All are first-order amplitudes.

Let f^i=K^{ij}(U_j+alpha_j sigma) and f^i_,j mean partial derivative at fixed
sigma, before substituting the background. With the complete connection of
K(u,x), scalar perturbation equations are
  dphi'^i=w^i,
  w'^i=-(3+h)w^i-2 Gamma^i_jl p^j w^l
       -[Q^2/H^2 delta^i_j+(partial_j Gamma^i_lm)p^l p^m
          +(partial_j f^i)/H^2] dphi^j
       -K^{ij}alpha_j sigma delta/H^2
       +4p^i Phi' -2f^i Phi/H^2.
The force includes the dust trace before its derivative. Keeping only the
potential Hessian would omit both the connection and matter coupling.

Particle number conservation and varying Einstein rest mass give
  delta'=-Theta+3Phi'+alpha_i w^i+(partial_j alpha_i)p^i dphi^j,
  Theta'=-(2+h+alpha_i p^i)Theta+(Q^2/H^2)(Phi+alpha_i dphi^i).
On this exact background alpha_i p^i=0 and the last derivative term in delta'
vanishes, but derivatives of the scalar force must still be retained.

The Einstein momentum constraint supplies
  Phi'=-Phi+K_ij p^i dphi^j+sigma Theta/Q^2.
The independently imposed energy constraint is
  C=Q^2 Phi/H^2+3(Phi'+Phi)+sigma delta/H^2
    +K_ij p^i w^j
    +[0.5(partial_l K_ij)p^i p^j+U_l/H^2]dphi^l
    -Phi K_ij p^i p^j=0.
The scalar energy perturbation includes the lapse term -Phi Kpp.
For a correct full system the unnormalized residual H^2 C propagates as
  (H^2 C)'=-3 H^2 C,
so C'=-(3+2h)C. This is a proposed independent load-bearing control, to be
checked against conservation/Bianchi and the actual matrix before reliance.
The background, force, connection and all their partials must come from the
fixed original action; do not differentiate an already on-orbit substitution.

## 3. Physical readout

On the background B0 is constant, but its perturbation is not. The physical
Jordan potentials and density contrast in the shared background coordinates are
  Psi_J=Phi+alpha_B du, Phi_J=Phi-alpha_B du,
  delta_J=delta-4alpha_B du, Theta_J=Theta.
Thus delta_J'=-Theta+3Phi_J'. This is a useful independent number/clock check.
The two lensing potentials sum to 2Phi. With the supplied measured-G bridge,
  mu=-Q^2 Psi_J/[(1+k)sigma delta_J],
  Sigma=-Q^2 Phi/[(1+k)sigma delta_J],
  gamma=Phi_J/Psi_J,
  f_density=delta_J'/delta_J, f_velocity=-Theta/delta_J.
The Poisson ratios above are finite-wavenumber diagnostic transfer functions;
relativistic terms need not vanish. They are not a quasistatic approximation.
If an E_G-like diagnostic is used, it is Omega_m0 Sigma/f_velocity with the
physical Omega_m0=2(1+k)x0^2/(3D0). Observational estimator, tracer bias and
window functions are additional bridges, not generated here.

## 4. Supplied normalization and initial response

Supply Omega_m0=.3 as an already exposed development benchmark, not a newly
measured parameter. For each branch choose
  x0^2=3 Omega_m0/[2(1+k-Omega_m0(1+b))],
  D0=1+2(1+b)x0^2/3, Q0=kappa sqrt(D0).
On b=k this gives the ordinary supplied dust-plus-constant-vacuum expansion
curve. On b=a its curve differs; do not compare the two as identical backgrounds.
Keep a,b,s,nu fixed during every integration.

The primary initial response is dphi=w=0, delta=1, Theta=-1 at a supplied
N_i in matter domination. These are unit linear transfer amplitudes: physical
perturbations multiply all variables by an arbitrarily small epsilon.
Solve the energy constraint algebraically for Phi using its full coefficient
Q^2/H^2-Kpp; retain domain failures. These are deliberately specified initial
conditions, not a claim to have derived the primordial adiabatic growing mode.
A second initial scalar response d x=x delta/2, d u=0 with w_x=-d x/2
can test memory of a different supplied initial mode. It is a diagnostic seed,
not automatically an exact adiabatic eigenmode. Shift N_i for convergence and
initial-mode sensitivity rather than quietly selecting a favorable endpoint.

## 5. Planned checks before interpretation

Derive the action-based matrix independently of any target growth rate. Check
connection/force derivatives, energy-constraint propagation as a row-operator
identity, physical density continuity, exact linearity, the separate standard-GR
dust control, and source/clock omission controls. Integrate complete coupled
system and retain full sample records, chart failures and constraint drift.
Refine preselected cases and compare different initial times/modes. Report
oscillations and instability if present; no fitting after output inspection.
The strongest next test is whether matching ideal H and local G can still
produce the requisite scale-dependent matter and lensing response.
