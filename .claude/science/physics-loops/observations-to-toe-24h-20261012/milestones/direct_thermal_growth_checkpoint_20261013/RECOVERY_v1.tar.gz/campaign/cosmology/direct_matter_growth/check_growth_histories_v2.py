#!/usr/bin/env python3
"""Parent direct fixed-action finite-wave transfer histories; no growth fit."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import time
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp
from check_growth_operator_v2 import action_operator

HERE = Path(__file__).resolve().parent
CHECKS = []


def check(name, passed, **detail):
    CHECKS.append(dict(name=name, passed=bool(passed), **detail))


def ratio(numerator, denominator, label):
    if not np.isfinite(denominator) or abs(denominator) < 1e-14:
        return None, label+" denominator outside declared chart"
    value = float(numerator/denominator)
    return (value, None) if np.isfinite(value) else (None, label+" nonfinite")


def parameters(k, branch, omega, kappa, nu):
    a = (1-k)*(1+3*k)/4
    s = (1+k)/(k*(1-3*k))
    b = k if branch == "split" else a
    denominator = 1+k-omega*(1+b)
    if not (0 < k < 1/3 and 0 < b < 1/3 and denominator > 0 and kappa > 0):
        raise ValueError("Invalid parameter/wavenumber chart")
    x02 = 3*omega/(2*denominator)
    D0 = 1+2*(1+b)*x02/3
    return dict(k=k, a=a, alpha=np.sqrt(a), b=b, s=s, nu=nu, omega=omega,
                x02=x02, D0=D0, kappa=kappa, Q02=kappa*kappa*D0)


def gr_history(kappa, ni, count, rtol, atol):
    """Independent GR dust/metric control plus second-order Phi equation."""
    omega = 0.3
    def background(n):
        sm = 1.5*omega*np.exp(-3*n)
        h2 = omega*np.exp(-3*n)+1-omega
        return sm, h2, -sm/h2, kappa*kappa*np.exp(-2*n)
    def matrix(n):
        sm, h2, h, q2 = background(n)
        return np.array([[0, -1+3*sm/q2, -3],
                         [0, -(2+h), q2/h2], [0, sm/q2, -1.]])
    sm, h2, h, q2 = background(ni)
    initial = np.array([1., -1., -(sm/h2-3*sm/q2)/(q2/h2)])
    sites = np.linspace(ni, 0, count)
    solution = solve_ivp(lambda n,z: matrix(n)@z, (ni,0), initial,
                         method="DOP853", rtol=rtol, atol=atol,
                         max_step=.02, t_eval=sites)
    def potential_rhs(n,z):
        _, _, h, _ = background(n)
        return [z[1], -(4+h)*z[1]-(3+2*h)*z[0]]
    phi0 = initial[2]
    phip0 = sm*initial[1]/q2-phi0
    other = solve_ivp(potential_rhs, (ni,0), [phi0, phip0], method="DOP853",
                      rtol=rtol, atol=atol*.01, max_step=.02, t_eval=sites)
    check(f"gr.{kappa}.{ni}.complete", solution.success and other.success and len(solution.t)==count and len(other.t)==count)
    rows=[]
    for j,n in enumerate(sites):
        sm,h2,h,q2 = background(n)
        phi,phip = other.y[:,j]
        independent = np.array([-(q2*phi+3*h2*(phip+phi))/sm, q2*(phip+phi)/sm, phi])
        z=solution.y[:,j]
        error=np.abs(z-independent)/np.maximum(1,np.abs(independent))
        for i in range(3):
            check(f"gr.{kappa}.{ni}.potential_control.{j}.{i}", error[i]<2e-8,
                  normalized_error=float(error[i]))
        residual=q2*z[2]/h2+3*sm*z[1]/q2+sm*z[0]/h2
        scale=max(1,abs(q2*z[2]/h2)+abs(3*sm*z[1]/q2)+abs(sm*z[0]/h2))
        check(f"gr.{kappa}.{ni}.constraint.{j}", abs(residual)/scale<2e-9)
        dz=matrix(n)@z
        rows.append(dict(N=float(n),delta=float(z[0]),theta=float(z[1]),Phi=float(z[2]),
                         growth=float(z[0]),f_density=float(dz[0]/z[0]),f_velocity=float(-z[1]/z[0]),
                         mu=float(-q2*z[2]/(sm*z[0]))))
    return dict(kappa=kappa,initial_N=ni,scope="Supplied GR Omega_m0=.3 reference, finite-wave Newtonian-gauge density; independent potential equation control.",
                nfev=solution.nfev,rows=rows)


def physical_readouts(z,dz,q2,x,pars,omega):
    dj=z[4]-4*z[0];djp=dz[4]-4*dz[0]
    psi=z[6]+z[0];phi=z[6]-z[0]
    errors=[]
    values={}
    for label,num,den in [('mu',-q2*psi,(1+pars['k'])*x*x*dj),
                          ('Sigma',-q2*z[6],(1+pars['k'])*x*x*dj),
                          ('gamma',phi,psi),('f_density',djp,dj),('f_velocity',-z[5],dj)]:
        value,error=ratio(num,den,label);values[label]=value
        if error:errors.append(error)
    if values['Sigma'] is not None and values['f_velocity'] is not None:
        eg,err=ratio(omega*values['Sigma'],values['f_velocity'],'E_G_proxy')
        if err:errors.append(err)
    else:eg=None
    return dj,djp,psi,phi,eg,errors,values


def raw_readout_controls(label,z,dz,q2,x,h2,pars,omega,reported):
    """Separate Euler force and dimensional 4pi G rho normalization.

    This oracle does not call the response ratio helper or copy its (1+k)
    denominator. It constructs GN from the action metric, and force from the
    pressureless-fluid acceleration. Generic states need not solve constraints.
    """
    dj,djp,psi,phi,eg,errors,values=reported
    q_total=7.3
    hv=1.7
    j0=1+(1-3*pars['a'])*pars['s']
    gn=(1+pars['a']/j0)/(8*np.pi*q_total)
    rho_d=2*q_total*hv*hv*x*x
    d_density=z[4]-4*z[0]
    density_rate=-z[5]+3*(dz[6]-dz[0])
    h=-(1+pars['b'])*x*x/h2
    q_physical2=q2*hv*hv
    force_potential=h2/q2*(dz[5]+(2+h)*z[5])
    physical_lensing_sum=(z[6]-z[0])+force_potential
    norm=4*np.pi*gn*rho_d*d_density
    direct={
        'mu':-q_physical2*force_potential/norm,
        'Sigma':-q_physical2*physical_lensing_sum/(2*norm),
        'gamma':(z[6]-z[0])/force_potential,
        'f_density':density_rate/d_density,
        'f_velocity':-z[5]/d_density,
    }
    direct['E_G_proxy']=(-omega*q_physical2*physical_lensing_sum*d_density/
                         (2*norm*(-z[5])))
    actual=dict(values,E_G_proxy=eg)
    for field,expected in direct.items():
        value=actual[field]
        error=abs(value-expected)/max(1,abs(expected)) if value is not None else None
        check(label+'.raw_physical_readout.'+field,error is not None and error<3e-10,
              normalized_error=error,expected=float(expected))
    check(label+'.physical_density',abs(dj-d_density)<1e-12*max(1,abs(d_density)))
    check(label+'.physical_force',abs(psi-force_potential)<3e-12*max(1,abs(force_potential)))


def run_case(case, fix, matrix_fn, constraint_fn, out):
    pars=parameters(case['k'],case['branch'],fix['omega_m0'],case['kappa'],fix['nu'])
    ni=case['initial_N']; sites=np.linspace(ni,0,fix['sample_count'])
    start=time.monotonic(); evaluations=0; last_n=ni
    def background(n):
        x=np.sqrt(pars['x02'])*np.exp(-1.5*n)
        q2=pars['Q02']*np.exp(-2*n)
        return x,q2,1+2*(1+pars['b'])*x*x/3
    def args(n):
        x,q2,_=background(n)
        return x,q2,pars['alpha'],pars['b'],pars['s'],pars['nu']
    def matrix(n):return np.asarray(matrix_fn(*args(n)),float)
    def constraint(n):return np.asarray(constraint_fn(*args(n)),float).ravel()
    def rhs(n,z):
        nonlocal evaluations,last_n
        evaluations+=1;last_n=float(n)
        if evaluations%1000==0 and time.monotonic()-start>fix['per_case_seconds']:
            raise TimeoutError("Frozen per-case wall bound reached")
        return matrix(n)@z
    # Physical scaled variables: dln B, dx/x, dln B prime, dx prime/x,
    # delta_E, velocity divergence/H, Einstein Phi.
    initial=np.array([0.,0.,0.,0.,1.,-1.,0.])
    if case['seed']=='scalar_fraction':initial[1]=.5;initial[3]=-.25
    c0=constraint(ni)
    if abs(c0[6])<1e-12:raise ValueError("Initial energy-constraint chart singular")
    initial[6]=-float(c0@initial)/c0[6]
    check(case['id']+'.initial_constraint', abs(float(c0@initial))<1e-12)
    settings=fix['refinement'] if case.get('refined') else fix['solver']
    try:
        sol=solve_ivp(rhs,(ni,0),initial,method=settings['method'],jac=lambda n,z:matrix(n),
                      rtol=settings['rtol'],atol=settings['atol'],max_step=settings['max_step'],t_eval=sites)
    except Exception as exc:
        record=dict(case=case,parameters=pars,success=False,error=repr(exc),last_N=last_n,
                    evaluations=evaluations,elapsed_seconds=time.monotonic()-start)
        (out/(case['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')
        check(case['id']+'.complete',False,error=repr(exc),last_N=last_n)
        return record
    complete=sol.success and len(sol.t)==len(sites)
    check(case['id']+'.complete',complete,message=sol.message)
    rows=[]
    for j,n in enumerate(sol.t):
        z=sol.y[:,j];dz=matrix(n)@z;x,q2,h2=background(n)
        reported=physical_readouts(z,dz,q2,x,pars,fix['omega_m0'])
        dj,djp,psi,phi,eg,errors,values=reported
        raw_readout_controls(case['id']+f'.{j}',z,dz,q2,x,h2,pars,fix['omega_m0'],reported)
        c=constraint(n);residual=float(c@z);scale=max(1.,float(np.sum(np.abs(c*z))))
        continuity=float(djp+z[5]-3*(dz[6]-dz[0]))
        check(case['id']+f'.finite.{j}',bool(np.all(np.isfinite(z))))
        check(case['id']+f'.constraint.{j}',abs(residual)/scale<fix['constraint_tolerance'],normalized_error=abs(residual)/scale)
        check(case['id']+f'.physical_continuity.{j}',abs(continuity)/max(1,abs(djp))<1e-11)
        rows.append(dict(N=float(n),state=z.tolist(),derivative=dz.tolist(),x=float(x),Q2=float(q2),H2=float(h2),
                         delta_J=float(dj),delta_J_prime=float(djp),Psi_J=float(psi),Phi_J=float(phi),
                         growth=float(dj),constraint_residual=residual,constraint_normalized=abs(residual)/scale,
                         E_G_proxy=eg,diagnostic_chart_errors=errors,**values))
    record=dict(case=case,parameters=pars,settings=settings,success=complete,message=sol.message,
                nfev=sol.nfev,njev=sol.njev,nlu=sol.nlu,elapsed_seconds=time.monotonic()-start,
                initial_state=initial.tolist(),rows=rows)
    (out/(case['id']+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    return record


def main():
    pa=argparse.ArgumentParser();pa.add_argument('--freeze',type=Path,required=True);pa.add_argument('--out',type=Path,required=True)
    args=pa.parse_args()
    if args.out.exists():raise FileExistsError(args.out)
    args.out.mkdir()
    fix=json.loads((HERE/'HISTORY_FIXTURES_v1.json').read_text())
    frozen=json.loads(args.freeze.read_text())
    for row in frozen['inputs']:
        check('source.'+row['path'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'])
    op=action_operator();mf=sp.lambdify(op['symbols'],op['Ms'],'numpy',cse=True);cf=sp.lambdify(op['symbols'],op['Cs'],'numpy',cse=True)
    generic=json.loads((HERE/'READOUT_FIXTURES_v2.json').read_text())
    for i,item in enumerate(generic['rows']):
        pars=parameters(item['k'],item['branch'],fix['omega_m0'],item['kappa'],fix['nu'])
        n=item['N'];x=np.sqrt(pars['x02'])*np.exp(-1.5*n);q2=pars['Q02']*np.exp(-2*n)
        h2=1+2*(1+pars['b'])*x*x/3;z=np.asarray(item['state'],float)
        dz=np.asarray(mf(x,q2,pars['alpha'],pars['b'],pars['s'],pars['nu']),float)@z
        reported=physical_readouts(z,dz,q2,x,pars,fix['omega_m0'])
        raw_readout_controls('generic.'+str(i),z,dz,q2,x,h2,pars,fix['omega_m0'],reported)
    histories=[]
    for case in fix['cases']:
        result=run_case(case,fix,mf,cf,args.out);histories.append(result)
        print(json.dumps(dict(case=case['id'],success=result['success'],seconds=result['elapsed_seconds'],nfev=result.get('nfev'),endpoint=result.get('rows',[None])[-1] if result.get('rows') else None)),flush=True)
    references=[]
    for kappa,ni in sorted({(c['kappa'],c['initial_N']) for c in fix['cases']}):
        references.append(gr_history(kappa,ni,fix['sample_count'],fix['refinement']['rtol'],fix['refinement']['atol']))
    byid={r['case']['id']:r for r in histories};variations=[]
    for item in fix['comparisons']:
        left,right=(byid[item[k]] for k in ('base','variant'))
        if not left['success'] or not right['success']:
            variations.append(dict(**item,status='incomplete paired histories'));continue
        if item['kind']=='refinement':
            fields=['growth','mu','Sigma','gamma','f_density','f_velocity','E_G_proxy']
            worst={}
            for field in fields:
                errs=[abs(a[field]-b[field])/max(1,abs(b[field])) for a,b in zip(left['rows'],right['rows']) if a[field] is not None and b[field] is not None]
                worst[field]=max(errs) if errs else None
                check('refinement.'+item['base']+'.'+field,bool(errs) and max(errs)<fix['refinement_tolerance'],normalized_error=worst[field])
            variations.append(dict(**item,status='compared',max_normalized_errors=worst))
        else:
            # Initial-condition dependence is a result, never a required agreement.
            variations.append(dict(**item,status='diagnostic only',endpoint_changes={f:right['rows'][-1][f]-left['rows'][-1][f] if right['rows'][-1][f] is not None and left['rows'][-1][f] is not None else None for f in ['growth','mu','Sigma','gamma','f_density','f_velocity']}))
    scope={'status':'Conditional finite-wave transfer calculation; no observed growth/lensing data used.','Omega_m0':'0.3 exposed and supplied','branch':'b=k calibrated to homogeneous measured-G normalization; b=a diagnostic has different background.','initial_modes':'Supplied responses, not primordial adiabatic modes.','E_G_proxy':'Requires additional estimator, bias and window bridges before data comparison.','constraint_limit':'Energy propagation does not check u acceleration; separately checked lowered-momentum equations are required.','normalization':'Unit first-order amplitudes represent arbitrary small common physical epsilon.'}
    result=dict(scope=scope,histories=histories,gr_references=references,comparisons=variations,checks=CHECKS,
                counts=dict(passed=sum(c['passed'] for c in CHECKS),failed=sum(not c['passed'] for c in CHECKS),total=len(CHECKS)))
    (args.out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['counts']),flush=True)
    raise SystemExit(bool(result['counts']['failed']))


if __name__=='__main__':main()
