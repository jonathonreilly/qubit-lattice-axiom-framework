#!/usr/bin/env python3
"""Direct-author finite-wave scalar/dust/metric operator from the fixed action."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import sympy as sp

HERE = Path(__file__).resolve().parent
CHECKS = []


def check(name, passed, **detail):
    CHECKS.append(dict(name=name, passed=bool(passed), **detail))


def reduce(expr):
    return sp.factor(sp.cancel(expr))


def action_operator():
    """Differentiate at fixed matter density before restricting the orbit."""
    u, x = sp.symbols("u x", real=True)
    al, b, s, nu, sigma, Q2 = sp.symbols("alpha b s nu sigma Q2", positive=True)
    coords = (u, x)
    E = sp.exp(2*al*u)
    F = 1+s*E
    D = 1+sp.Rational(2, 3)*(1+b)*x*x
    K = sp.Matrix([(1+(1-3*al**2)*s*E)/F**2, 4*b*(1+s)/(9*F*D)])
    V0 = sp.Rational(3, 2)+(b/2-al*u+2*al**2*u*u/b)*x*x+nu*u*u/2
    V1 = (b/2+al*b*u+2*al**2*u*u/b)*x*x
    U = (1+s)*(V0+s*V1+sp.Rational(3, 2)*s*E**2)/F**2
    alpha = sp.Matrix([al/F, 0])
    dK = sp.Matrix(2, 2, lambda l, i: sp.diff(K[i], coords[l]))
    dU = sp.Matrix([sp.diff(U, c) for c in coords])
    gamma = [[[sum((sp.diff((K[i] if i == m else 0), coords[j])
                         +sp.diff((K[i] if i == j else 0), coords[m])
                         -sp.diff((K[j] if j == m else 0), coords[i]))
                         / (2*K[i]) for _ in (0,))
               for m in range(2)] for j in range(2)] for i in range(2)]
    force = sp.Matrix([(dU[i]+alpha[i]*sigma)/K[i] for i in range(2)])
    dforce = force.jacobian(coords)
    orbit = {u: 0, sigma: x*x}
    on = lambda expr: reduce(expr.subs(orbit, simultaneous=True))
    ko = K.applyfunc(on)
    dko = dK.applyfunc(on)
    duo = dU.applyfunc(on)
    fo = force.applyfunc(on)
    dfo = dforce.applyfunc(on)
    go = [[[on(gamma[i][j][m]) for m in range(2)] for j in range(2)] for i in range(2)]
    dgo = [[[[on(sp.diff(gamma[i][j][m], c)) for c in coords]
              for m in range(2)] for j in range(2)] for i in range(2)]
    po = sp.Matrix([0, -sp.Rational(3, 2)*x])
    h = -(1+b)*x*x/D
    ab = al/(1+s)
    # z = (du, dx, du', dx', delta_E, Theta, Phi).
    M = sp.zeros(7)
    M[0, 2] = M[1, 3] = 1
    momentum = sp.Matrix([[ko[0]*po[0], ko[1]*po[1], 0, 0, 0, x*x/Q2, -1]])
    M[6, :] = momentum
    for i in range(2):
        for j in range(2):
            M[i+2, j] = -(Q2/D if i == j else 0)-dfo[i, j]/D-sum(
                dgo[i][l][m][j]*po[l]*po[m] for l in range(2) for m in range(2))
            M[i+2, j+2] = (-(3+h) if i == j else 0)-2*sum(
                go[i][l][j]*po[l] for l in range(2))
        M[i+2, 4] = -(ab*x*x/(ko[0]*D) if i == 0 else 0)
        M[i+2, 6] -= 2*fo[i]/D
        M[i+2, :] += 4*po[i]*momentum
    M[4, :] = 3*momentum
    M[4, 2] += ab
    M[4, 5] -= 1
    M[5, 0] = Q2*ab/D
    M[5, 5] = -(2+h)
    M[5, 6] = Q2/D
    M = M.applyfunc(reduce)
    C = sp.zeros(1, 7)
    for i in range(2):
        C[i] = 3*ko[i]*po[i]+sum(dko[i, j]*po[j]**2/2 for j in range(2))+duo[i]/D
        C[i+2] = ko[i]*po[i]
    C[4] = x*x/D
    C[5] = 3*x*x/Q2
    C[6] = Q2/D-sum(ko[i]*po[i]**2 for i in range(2))
    C = C.applyfunc(reduce)
    # Scale scalar response to (dln B, dx/x, (dln B)', dx'/x).
    S = sp.diag(ab, 1/x, ab, 1/x, 1, 1, 1)
    Ms = (S*M*S.inv()+sp.diag(0, sp.Rational(3, 2), 0, sp.Rational(3, 2), 0, 0, 0)).applyfunc(reduce)
    Cs = (C*S.inv()).applyfunc(reduce)
    return dict(symbols=(x, Q2, al, b, s, nu), M=M, C=C, Ms=Ms, Cs=Cs,
                H2=D, h=h, K=ko, dK=dko, dU=duo, force=fo, dforce=dfo,
                gamma=go, dgamma=dgo, p=po, alpha_B=ab)


def momentum_residuals(op, matrix):
    """Independent lowered-momentum variation; no connection or inverse-force use.

    delta P_i/H = K_i w_i + (partial_l K_i) p_i delta phi_l.
    Vary dP_i/dt + 3HP_i - partial_i K_j v_j^2/2 + U_i + alpha_i sigma.
    Add the spatial gradient and the lapse/potential metric forcing explicitly.
    """
    x, Q2, al, b, s, nu = op["symbols"]
    u = sp.Symbol("u", real=True)
    coords = (u, x)
    E = sp.exp(2*al*u); F = 1+s*E
    B = sp.exp(al*u)/sp.sqrt(F)
    D = 1+sp.Rational(2, 3)*(1+b)*x*x
    kvals = [(1-3*al**2*s*E)/F+sp.Rational(3, 4)*(sp.diff(F,u)/F)**2,
             4*b*(1+s)/(9*F*D)]
    W = sp.Rational(3, 2)+(b*(1+s)/2+al*(s*b-1)*u+2*al**2*(1+s)*u*u/b)*x*x+nu*u*u/2+sp.Rational(3, 2)*s*E**2
    U = (1+s)*W/F**2
    alpha = [sp.diff(sp.log(B), c) for c in coords]
    on = lambda v: reduce(v.subs(u, 0))
    p = [0, -sp.Rational(3, 2)*x]
    residuals = []
    for i in range(2):
        L = sp.zeros(1,7)
        L[i+2] = on(kvals[i])
        for j in range(2): L[j] = on(sp.diff(kvals[i],coords[j]))*p[i]
        R = L.diff(x)*(-sp.Rational(3,2)*x)+L*matrix+(3+op["h"])*L
        for j in range(2):
            R[j] += (Q2*on(kvals[i])/D if i==j else 0)
            R[j] += on(sp.diff(U,coords[i],coords[j])+x*x*sp.diff(alpha[i],coords[j]))/D
            R[j] -= sum(on(sp.diff(kvals[m],coords[i],coords[j]))*p[m]**2/2 for m in range(2))
            R[j+2] -= on(sp.diff(kvals[j],coords[i]))*p[j]
        R[4] += on(alpha[i])*x*x/D
        R -= 4*on(kvals[i])*p[i]*matrix[6,:]
        R[6] += 2*on(sp.diff(U,coords[i])+alpha[i]*x*x)/D
        residuals.append(R.applyfunc(reduce))
    return residuals


def main():
    pa = argparse.ArgumentParser()
    pa.add_argument("--freeze", type=Path, required=True)
    pa.add_argument("--out", type=Path, required=True)
    args = pa.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    freeze = json.loads(args.freeze.read_text())
    for row in freeze["inputs"]:
        p = Path(row["path"])
        check("source."+str(p), hashlib.sha256(p.read_bytes()).hexdigest() == row["sha256"])
    start = time.monotonic()
    op = action_operator()
    x, Q2, al, b, s, nu = op["symbols"]
    identities = []
    for label, matrix, constraint in (("coordinate", op["M"], op["C"]), ("scaled", op["Ms"], op["Cs"])):
        derivative = constraint.diff(x)*(-sp.Rational(3, 2)*x)+constraint.diff(Q2)*(-2*Q2)
        residual = derivative+constraint*matrix+(3+2*op["h"])*constraint
        for i, expr in enumerate(residual):
            red = reduce(expr)
            check(f"constraint.{label}.{i}", red == 0, residual=str(red))
            identities.append(dict(name=f"constraint.{label}.{i}", residual=str(red)))
    # The physical density and potential are exact row maps in the scaled chart.
    density = sp.Matrix([[-4, 0, 0, 0, 1, 0, 0]])
    spatial_potential = sp.Matrix([[-1, 0, 0, 0, 0, 0, 1]])
    theta = sp.Matrix([[0, 0, 0, 0, 0, 1, 0]])
    continuity = density*op["Ms"]+theta-3*spatial_potential*op["Ms"]
    for i, expr in enumerate(continuity):
        red = reduce(expr)
        check(f"physical_continuity.{i}", red == 0, residual=str(red))
    # Independent background acceleration from differentiated exact velocities.
    p = op["p"]
    for i in range(2):
        acceleration = sum(sp.diff(p[i], c)*p[j] for j, c in enumerate((sp.Symbol("u"), x)))+op["h"]*p[i]
        con = sum(op["gamma"][i][j][m]*p[j]*p[m] for j in range(2) for m in range(2))
        red = reduce(acceleration+3*p[i]+con+op["force"][i]/op["H2"])
        check(f"background_scalar.{i}", red == 0, residual=str(red))
    # The energy constraint is blind to the u acceleration row when p_u=0.
    # Independently vary lowered momenta to check that full scalar row too.
    for i, row in enumerate(momentum_residuals(op, op["M"])):
        for j, red in enumerate(row):
            check(f"lowered_momentum.{i}.{j}", red == 0, residual=str(red))
    # Actual omissions are checked against conservation AND the scalar action.
    base = op["M"]
    mutants = {}
    derivative = op["C"].diff(x)*(-sp.Rational(3, 2)*x)+op["C"].diff(Q2)*(-2*Q2)
    m = base.copy(); m[2, 4] = 0
    mutants["omit_dust_scalar_source"] = m
    m = base.copy(); m[5, 0] = 0
    mutants["omit_scalar_physical_force"] = m
    m = base.copy(); m[4, 2] -= op["alpha_B"]
    mutants["omit_mass_exchange"] = m
    m = base.copy(); m[6, 5] = 0
    mutants["omit_dust_momentum"] = m
    mutation_rows = []
    for name, m in mutants.items():
        residual = (derivative+op["C"]*m+(3+2*op["h"])*op["C"]).applyfunc(reduce)
        nonzero = [i for i, expr in enumerate(residual) if expr != 0]
        variational = momentum_residuals(op, m)
        scalar_nonzero = [(i,j) for i,row in enumerate(variational) for j,v in enumerate(row) if v != 0]
        check("mutation."+name, bool(nonzero or scalar_nonzero), constraint_nonzero_components=nonzero, scalar_nonzero_components=scalar_nonzero)
        mutation_rows.append(dict(name=name, constraint_detects=bool(nonzero), scalar_detects=bool(scalar_nonzero), residual=[str(v) for v in residual], scalar_residuals=[[str(v) for v in row] for row in variational]))
    result = dict(scope="Fixed-action linear operator identities; no observation comparison or trajectory run.",
                  symbols=[str(v) for v in op["symbols"]],
                  coordinate_matrix=[[str(v) for v in row] for row in op["M"].tolist()],
                  scaled_matrix=[[str(v) for v in row] for row in op["Ms"].tolist()],
                  coordinate_constraint=[str(v) for v in op["C"]],
                  scaled_constraint=[str(v) for v in op["Cs"]],
                  identities=identities, mutations=mutation_rows, checks=CHECKS,
                  counts=dict(passed=sum(c["passed"] for c in CHECKS), failed=sum(not c["passed"] for c in CHECKS), total=len(CHECKS)),
                  elapsed_seconds=time.monotonic()-start)
    args.out.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result["counts"]))
    raise SystemExit(bool(result["counts"]["failed"]))


if __name__ == "__main__":
    main()
