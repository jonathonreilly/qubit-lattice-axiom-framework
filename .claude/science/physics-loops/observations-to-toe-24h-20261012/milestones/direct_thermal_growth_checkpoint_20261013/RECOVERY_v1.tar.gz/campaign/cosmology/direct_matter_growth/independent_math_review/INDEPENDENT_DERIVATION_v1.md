# Independent derivation of the coupled scalar–dust perturbation system

This checks the frozen parent handwritten proposal, SHA-256 `61481fff5c81ac2cfbc6e62c25c981cd212f172d48feb1403a931c1037a26d52`. Parent `/root` remains the scientific author. The independent calculation below uses the stated action, not a parent implementation or a target growth curve. It is an ordinary mathematical check with exact symbolic controls, not formal verification or an empirical comparison.

## 1. Action, normalization and background

Work in the fixed auxiliary sector and in the Einstein metric. Set the odd field `y` and radiation to zero. The action is

    S = q ∫ sqrt(-g) [R/2 - K_ij ∂phi^i ∂phi^j - 2 Vhat]
        + S_m[B(phi)^2 g, psi],

with `phi=(u,x)`, `q>0`. In time units `Hhat_v^-1`, write `U=Vhat/Hhat_v^2` and `sigma=rho_E/(2q Hhat_v^2)`. Below all proper-time derivatives and frequencies use these units. Constants remain fixed before differentiation.

For `r=sqrt(a)`, define

    F = 1+s exp(2ru),       J = 1+(1-3r^2)s exp(2ru),
    D = 1+2(1+b)x^2/3,
    K_uu = J/F^2,          K_xx = (1+s)4b/(9DF),   K_ux=0,
    B = exp(ru)/sqrt(F),   alpha_i = ∂_i log B = (r/F,0).

The dimensionless potential used independently in the check is

    U = (1+s)/F^2 * {
          3/2 + [b/2-ru+(2r^2/b)u^2]x^2 + nu u^2/2
          + s[b/2+rbu+(2r^2/b)u^2]x^2
          + (3s/2) exp(4ru) }.

This substitutes the fixed-sector value `C=3s H_v^2/2` only after the original variation. The earlier scope correction remains applicable: recovering old `K,V,A` functions is different from deleting the auxiliary/form theory; old local bulk equations additionally require `C=0` and fixed `q` in the zero-curvature limit.

Let `v^i=dot phi^i`, `T=K_ij v^i v^j`. The homogeneous scalar equation and dust mass law are

    D_t v^i + 3H v^i + f^i = 0,
    f^i = K^ij(U_j+alpha_j sigma),
    dot sigma + 3H sigma = sigma alpha_i v^i.

The scalar source sign follows directly from `delta S_m/delta phi^i = sqrt(-g) alpha_i T_m` and `T_m=-rho_E`. The scalar kinetic normalization supplies the factor `2q`, so the dimensionless source is `alpha_i sigma`, not twice or half that quantity.

Define total energy and pressure divided by `2q Hhat_v^2`:

    epsilon = T/2 + U + sigma,
    P = T/2 - U,
    3H^2 = 2 epsilon,       dot H = -(epsilon+P)=-(T+sigma).

On the stated exact orbit, `u=0`, `p=phi'=(0,-3x/2)`, `sigma=x^2`, `H^2=D`. Therefore `K_ij p^i p^j=b x^2/D` and

    h=H'/H=-(1+b)x^2/D.

The two background scalar equations, Friedmann equation and Raychaudhuri equation were verified from the full field functions before any orbit restriction of their derivatives. The admitted finite-field domain is `0<a,b<1/3`, `s>=0`, `nu>0`; all kinetic denominators are positive. The supplied matter benchmark has nonzero dust density. A density contrast itself requires a nonzero background density.

The `y`-odd sector consistently decouples at linear order: the action and dust coupling are invariant under `y -> -y`, and the background has `y=dot y=0`. Odd perturbations cannot linearly source the even metric/`u,x`/dust variables. This does not assert nonlinear decoupling or the stability of all sectors.

## 2. Einstein constraint signs from ADM geometry

Write the perturbed line element with initially distinct potentials,

    ds^2 = -(1+2Psi) dt^2 + a_E^2(1-2Phi) dX^2.

Dust has no first-order anisotropic stress, and homogeneous scalar backgrounds have no first-order off-diagonal spatial-gradient stress. The nonzero-wavenumber scalar traceless equation consequently sets `Psi=Phi`.

With the convention `K^i_j=-H delta^i_j` on the background, the perturbed spatial curvature and mixed extrinsic curvature are

    delta R^(3) = -4 Q^2 Phi,
    K^i_j = -[H-dot Phi-H Psi] delta^i_j.

The Hamiltonian constraint `R^(3)+K^2-K^i_j K^j_i=2 rho/q` gives, after subtraction of its background,

    Q^2 Phi + 3H(dot Phi+H Psi) = -delta epsilon.       (E1)

Here `Q` is physical Einstein wavenumber divided by `Hhat_v`; it is not the auxiliary `q`. The scalar energy perturbation includes the lapse contribution:

    delta epsilon = K_ij v^i delta dot phi^j
                  + (1/2)K_ij,l v^i v^j delta phi^l
                  - T Psi + U_l delta phi^l + sigma delta.       (E2)

`delta` denotes `delta rho_E/rho_E`. Omitting `-T Psi` changes the physical energy constraint.

Let `theta` be the divergence of peculiar velocity divided by `a_E`, with Fourier Laplacian `-Q^2`. Define normalized total momentum potential

    M = K_ij v^i delta phi^j + sigma theta/Q^2.

In physical time, the matter momentum density is `j_i=-2q Hhat_v ∂_i M`; the physical extrinsic-curvature side carries the same `Hhat_v` factor. After dividing it out, `D_j(K^j_i-delta^j_i K)=-2∂_i(dot Phi+H Psi)` in normalized time and the normalized matter side is `-2∂_i M`. The nonzero Fourier mode gives

    dot Phi+H Psi = M.                                  (E3)

Thus, with `Theta=theta/H` and `p=phi'`,

    Phi' = -Phi + K_ij p^i delta phi^j + sigma Theta/Q^2.

Dividing (E1) by `H^2` and using (E2) yields precisely the proposed energy row

    C = (Q^2/H^2)Phi + 3(Phi'+Phi) + sigma delta/H^2
        + K_ij p^i w^j
        + [K_ij,l p^i p^j/2 + U_l/H^2]delta phi^l
        - Phi K_ij p^i p^j,

where `w=delta phi'`. This independently fixes both momentum-source signs, the scalar kinetic factors, and the lapse term.

## 3. Scalar and dust evolution

Linearizing the covariant scalar equation about the homogeneous background, with equal metric potentials, gives

    delta ddot phi^i + 3H delta dot phi^i
      + 2 Gamma^i_jl v^j delta dot phi^l
      + [Q^2 delta^i_j + (partial_j Gamma^i_lm)v^l v^m
                         + partial_j f^i]delta phi^j
      + K^ij alpha_j sigma delta
      - 4v^i dot Phi + 2f^i Phi = 0.                     (S1)

The force partial is at fixed `sigma`. All field dependence of `K^-1`, `U_j` and `alpha_j` participates. The coefficient `2f Phi` contains the full background force including its dust part; it follows after using the background scalar equation in the lapse variation.

Since `delta ddot phi=H^2(w'+h w)`, division by `H^2` gives the parent equation verbatim:

    w'^i = -(3+h)w^i - 2 Gamma^i_jl p^j w^l
      - [Q^2/H^2 delta^i_j + (partial_j Gamma^i_lm)p^l p^m
                              + partial_j f^i/H^2]delta phi^j
      - K^ij alpha_j sigma delta/H^2
      + 4p^i Phi' - 2f^i Phi/H^2.

An independent symbolic route used the lowered-index Euler–Lagrange residual

    R_i = K_ij[a^j+(3+h)v^j]
        + [partial_k K_ij-(1/2)partial_i K_jk]v^j v^k
        + (U_i+alpha_i sigma)/H^2,

where `phi,v,a,sigma,h,H^2` were independent while taking partial derivatives. After that differentiation, substitute `v=p`, `a=p'` and the background. Its linearization, plus

    (Q^2/H^2)K_ij delta phi^j
       - 4K_ij p^j Phi' + 2(U_i+alpha_i sigma)Phi/H^2,

determines `w'` after multiplication by `-K^-1`. This calculation does not use the Christoffel or raised-force helpers. All 14 resulting scalar matrix entries agree exactly with (S1).

For dust, number conservation and varying Einstein rest mass are separate facts:

    ∇_mu(n_E U^mu)=0,         m_E=m_J B(phi),
    delta = delta_n + alpha_i delta phi^i.

The number contrast obeys `delta_n'=-Theta+3Phi'`. Differentiating the mass perturbation gives

    delta' = -Theta+3Phi' + alpha_i w^i
             +(partial_j alpha_i)p^i delta phi^j.

The particle equation from `-m_J ∫ B ds_E` is

    U^mu ∇_mu U^nu = -(g^nu_mu+U^nu U_mu)∂^mu log B.

Its linear spatial divergence is

    dot theta = -(2H+alpha_i v^i)theta
                + Q^2(Phi+alpha_i delta phi^i),

and hence

    Theta' = -(2+h+alpha_i p^i)Theta
               +(Q^2/H^2)(Phi+alpha_i delta phi^i).

On the specified background `alpha_i p^i=0` and the derivative term in `delta'` vanishes. These simplifications must not be applied before the scalar-force partials are taken.

A useful independent force check follows from the number-fixed mass Hessian:

    B_ij/B = partial_j alpha_i + alpha_i alpha_j.

At fixed number contrast, varying `alpha_i sigma` therefore gives
`sigma[partial_j alpha_i+alpha_i alpha_j]delta phi^j + sigma alpha_i delta_n`.
Converting to the energy contrast `delta_n=delta-alpha_j delta phi^j` cancels the extra `alpha_i alpha_j` term. This leaves exactly the fixed-`sigma` derivative and the separately displayed dust-density source. In particular,

    coefficient of delta in w'_u
      = -r(1+s)x^2 / {D[1+(1-3r^2)s]}.

This coefficient is independently checked even though constraint propagation cannot test it on this background.

## 4. Constraint propagation from total conservation

The total pressure perturbation is

    delta P = K_ij v^i delta dot phi^j
              + K_ij,l v^i v^j delta phi^l/2
              - T Phi - U_l delta phi^l.

Combining the full scalar and dust equations cancels their mutual energy exchange and yields

    delta dot epsilon + 3H(delta epsilon+delta P)
        = 3(epsilon+P)dot Phi - Q^2 M.                  (C1)

Independently differentiating `M`, using the background scalar equation and dust Euler equation, gives

    dot M + 3H M = delta P + (epsilon+P)Phi.             (C2)

For example, the scalar momentum derivative contributes
`-3H M_scalar - (U_i+sigma alpha_i)delta phi^i`
plus the kinetic variation. The dust contribution adds
`-3H M_dust + sigma Phi + sigma alpha_i delta phi^i`.
The exchange terms cancel; the remainder is exactly (C2).

Let the energy residual be

    E = Q^2 Phi + 3H M + delta epsilon = H^2 C.

Use `dot Q^2=-2H Q^2`, `dot H=-(epsilon+P)`, (C1), (C2), and the imposed momentum constraint `dot Phi=M-H Phi`. Direct differentiation gives

    dot E = -3H E.

No perturbed energy constraint was assumed in deriving this identity. Therefore

    E'=-3E,       C'=-(3+2h)C.

The proposed propagation law is correct. Differentiating the momentum constraint and using (C2) also supplies the standard scalar spatial-trace equation

    ddot Phi + 4H dot Phi + (2 dot H+3H^2)Phi = delta P.

This explains why the momentum constraint can be used as an evolution equation in the nonzero Fourier chart with consistent matter evolution.

The fixed-action symbolic matrix independently confirms all seven entries of

    L_N + L M_evolution + (3+2h)L = 0,

where `C=L v_state`, and `L_N` differentiates both `x'=-3x/2` and `(Q^2)'=-2Q^2`.

## 5. A genuine blind spot in this constraint test

For state order `(du,dx,w_u,w_x,delta,Theta,Phi)`, the exact energy row simplifies to

    L = (
      -r x^2(1+2bs)/[(1+s)D],
      -b x(2D-1)/D^2,
       0,
      -2b x/(3D),
       x^2/D,
       3x^2/Q^2,
       (Q^2-bx^2)/D ).

In particular, `L_wu=0`. Consequently **any change confined to the `w'_u` row is invisible to `L M_evolution` and to this constraint-propagation identity**. This is structural: the background has zero transverse velocity, so first-order energy conservation does not contract the transverse acceleration.

The actual independent control that differentiated the force after incorrectly substituting `sigma=x^2` changes the `w'_u,dx` coefficient by

    -2rx(1+s) / {D[1+(1-3r^2)s]}.

All seven constraint residuals still vanish identically. The independent lowered-action scalar check detects the changed entry. At the preselected rational witness `r=1/3,b=1/7,s=2,nu=5/4,x=3/2,Q^2=11`, its discrepancy is exactly `-9/19`. The second rational witness also detects it. This surviving control is preserved, not counted as successful constraint sensitivity.

Reversing the momentum dust sign, reversing the scalar lapse-force sign, and omitting the scalar energy lapse each produce nonzero constraint residuals. The last deliberately changes the constraint itself, so an unchanged scalar-equation check correctly does not detect it. These tests have distinct coverage.

The parent later disclosed its separate `31/1` result for an omitted transverse dust source that likewise survives the constraint-only check. That disclosure arrived after this review's primary exact run. No parent implementation or raw outputs were opened; that numerical report is recorded as parent-reported context, not independently verified evidence. The subsequent number-fixed mass and GR checks are explicitly later supplements.

## 6. Jordan readout and measured-G normalization

The background factor is constant, `B0^2=1/(1+s)`. At linear order `delta log B=beta du`, with `beta=r/(1+s)`. Using the background coordinate rescaling `dt_J=B0 dt_E`, `a_J=B0 a_E`, the Jordan metric has

    Psi_J = Phi+beta du,       Phi_J = Phi-beta du.

Dust number density transforms as `n_E=B^3 n_J`, while `m_E=B m_J`. Therefore `rho_E=B^4 rho_J` and

    delta_J = delta-4beta du.

The peculiar velocity is unchanged by the constant background scale/time rescaling; its divergence and Hubble rate each acquire `1/B0`. Their dimensionless ratio obeys `Theta_J=Theta`. Products of a perturbed conformal factor with a first-order peculiar velocity are second order and do not change this statement. Also `d/dN_J=d/dN_E` on the background.

Thus

    delta_J' = -Theta+3Phi_J',
    Psi_J+Phi_J = 2Phi.

All seven coefficients of the continuity identity were checked against the matrix.

With the explicitly supplied weak-body/light-scalar bridge,

    k = a/[1+(1-3a)s],
    G_N = (1+k)/[8pi q(1+s)],

we have `rho_J=2q Hhat_v^2 sigma/B0^4` and physical Jordan wavenumber squared `k_J^2=Hhat_v^2 Q^2/B0^2`. Hence

    k_J^2/(4pi G_N rho_J) = Q^2/[(1+k)sigma].

The parent's transfer ratios follow:

    mu = -Q^2 Psi_J/[(1+k)sigma delta_J],
    Sigma = -Q^2 Phi/[(1+k)sigma delta_J],
    gamma = Phi_J/Psi_J,
    f_density = delta_J'/delta_J,
    f_velocity = -Theta/delta_J.

In particular `f_density-f_velocity=3Phi_J'/delta_J`; these two growth ratios are generally different at finite wavelength. `mu` and `Sigma` use Newtonian-gauge density contrasts and are diagnostic ratios, not automatically gauge-invariant observed estimators or quasistatic gravitational constants.

The physical density parameter is

    Omega_m0 = 8pi G_N rho_J0/(3H_J0^2)
             = 2(1+k)x0^2/(3D0).

Its inverse gives exactly the supplied `x0^2` formula. On `b=k`, `D0=1/(1-Omega_m0)`. The old `b=a` branch need not have the same background. The optional product `Omega_m0 Sigma/f_velocity` is an E_G-like mathematical readout only; bias, estimator definition and window/selection functions are additional empirical bridges.

## 7. An exact, separate GR dust control

For Einstein–de Sitter dust in ordinary GR, let `z=Q^2/H^2`, `z'=z`, `h=-3/2`, `sigma=3H^2/2`. The exact constant-potential solution is

    Phi=P0,
    Theta=(2/3)z P0,
    delta=-2P0-(2/3)z P0.

It satisfies the momentum and energy constraints, continuity and Euler equations exactly. Its finite-wavenumber ratios are

    mu=Sigma=f_velocity=f_density=z/(z+3),

approaching one in the subhorizon limit. Thus a finite-wavelength ratio different from one is not by itself evidence of modified gravity. This is a separate GR theory control; it does not take the inadmissible `b=0` field-metric limit of the new action. It does not reinterpret the parent's supplied seeds as primordial growing modes.

## 8. Chart and interpretation limits

The momentum evolution chart assumes `Q0>0`. The zero Fourier mode requires a different constraint/gauge treatment. Density ratios also require nonzero background dust, and the diagnostic denominators must be checked individually: `delta_J`, `Psi_J`, and, for the E_G-like division, `f_velocity`.

For the primary supplied seed, the coefficient of the algebraically solved potential is `(Q^2-bx^2)/D`. The exact solution is

    Phi_i = x^2(3D-Q^2)/[Q^2(Q^2-bx^2)].

At `Q^2=bx^2`, its remaining constraint source equals `-[3+(2+b)x^2]/(bD)`, so these particular seed values cannot satisfy that singular chart equation. Record the domain failure; do not regularize the denominator into a chosen answer. Other seed choices have their own compatibility condition.

These are unit linear amplitudes whose physical realization requires a small overall multiplier. Neither seed is established here as a primordial adiabatic growing mode. The proposed system is a classical, linear, homogeneous-background perturbation calculation for ideal dust and a specified action. It does not establish nonlinear stability, radiation/thermal transfer, screening, primordial state selection, observational likelihoods, or a TOE.
