# Independent mathematical check: coupled matter-growth proposal

The frozen handwritten equations are correct in their stated fixed-action, linear dust/scalar setting, with the nonzero-wavenumber and diagnostic-denominator domains made explicit. I found no substantive formula correction. The proposed energy-constraint propagation law is correct. It is also insufficient as a complete scalar-equation check: every error confined to the transverse `u`-acceleration row survives that particular control on this background.

Reviewer `/root/launch_check`; parent `/root` remains author. This is a focused independent mathematical check, not an implementation review, formal audit, observed-growth fit or final delivery gate. No parent scientific source was edited, and no parent code or raw numerical output was opened. The exact proposal is `HAND_DERIVATION_v1.md`, SHA-256 `61481fff5c81ac2cfbc6e62c25c981cd212f172d48feb1403a931c1037a26d52`. Its underlying curvature action (`2ee1ebdbb34462010b8c9e34fa90466f173948a1ab5fbb940231b20c701db04f`) and mandatory scope correction (`5705e9018b91c893cd183f60eb9a774443c87183414a987176ec2f2c56879666`) are frozen alongside it.

## Independent mathematical findings

`INDEPENDENT_DERIVATION_v1.md` gives the complete normalization, ADM constraint derivation, scalar and dust variation, conservation proof, conformal readout and domain analysis. `EXACT_ACTION_MATRIX_v1.json` preserves every entry of the independently formed seven-variable matrix, the full energy row, connection partials and fixed-density force partials.

The Einstein-frame action has scalar kinetic normalization `2q K` and dust density `rho_E=2q Hhat_v^2 sigma`. The ADM Hamiltonian constraint therefore has the proposed negative density source, the momentum constraint has the positive `sigma Theta/Q^2` source, and the scalar energy perturbation contains exactly `-Phi K_ij p^i p^j`. Zero first-order anisotropic stress permits equal Einstein potentials for the nonzero Fourier scalar mode.

Varying the full covariant scalar equation produces the proposed connection terms, force partials at fixed `sigma`, separate dust-density force, `4p Phi'`, and `-2f Phi/H^2`. An independent lowered-index Euler–Lagrange linearization, constructed without the Christoffel or raised-force helper, agrees with all 14 scalar acceleration matrix entries. The two scalar background equations and both background metric equations also hold from the full field functions.

Dust number conservation and the worldline action `-m_J ∫B ds_E` produce the proposed continuity and Euler equations. A number-fixed mass Hessian contains `B_ij/B=partial_j alpha_i+alpha_i alpha_j`; converting number contrast to the Einstein energy contrast cancels the extra product. This independently confirms the separate transverse density source

    M[w_u,delta] = -sqrt(a)(1+s)x^2 / {D[1+(1-3a)s]}.

From total energy/momentum conservation, with `E=Q^2 Phi+3H M+delta epsilon=H^2 C`, I derive `dot E=-3H E`, hence `C'=-(3+2h)C`. The independent exact matrix confirms every coefficient of `L_N+LM+(3+2h)L=0`. This establishes the proposed identity without imposing `C=0` during its derivation.

The Jordan formulas also agree: `Psi_J=Phi+alpha_B du`, `Phi_J=Phi-alpha_B du`, `delta_J=delta-4alpha_B du`, and `Theta_J=Theta`. They follow from the metric transformation, `rho_E=B^4 rho_J`, and the equal background rescaling of velocity divergence and Hubble rate. The matrix satisfies `delta_J'=-Theta+3Phi_J'` coefficient by coefficient. The measured-G normalization gives the displayed `mu`, `Sigma` and `Omega_m0`; it retains the supplied local light-scalar/weak-body bridge rather than deriving it anew.

## Preserved constraint-control blind spot

The exact energy row has `L[w_u]=0` because `p_u=0`. Therefore a change to any entry of the `w'_u` evolution row cannot change the energy-constraint propagation row. This is an algebraic limitation, not a problem with the proposed equations.

Four deliberately false formulas were actually tested, with their complete symbolic residuals and two fixed rational witnesses retained:

| Intentional change | Constraint propagation detects it | Independent scalar action comparison detects it |
|---|---|---|
| Reverse momentum dust sign | Yes | Yes |
| Reverse scalar lapse-force sign | Yes | Yes |
| Substitute `sigma=x^2` before taking the force partial | **No: all seven residuals stay exactly zero** | Yes |
| Omit the scalar energy lapse term | Yes | No: this changes the constraint, not the scalar equation |

The surviving derivative error changes the transverse `dx` coefficient by `-2sqrt(a)x(1+s)/{D[1+(1-3a)s]}`. At the first preselected rational witness the scalar discrepancy is exactly `-9/19`. It is preserved as a real failure of constraint-only sensitivity, not presented as a detected mutation or deleted from the results.

The primary independent run completed at 12:14:06 UTC. Afterwards the parent disclosed a separate operator run reporting `31/1`: deleting its transverse dust-source entry also survives its constraint-only sensitivity assertion. I have not inspected that implementation or its raw result, so this remains parent-reported corroborating context. The subsequent mass-variation/GR supplement is honestly recorded as following that disclosure. No independence claim is based on merely agreeing with the parent's reported count.

The implementation should retain an independently justified transverse scalar equation/force check; passing energy and Jordan-continuity identities alone cannot replace it. The parent has already identified and is addressing this limitation. No parent v1 failure should be overwritten by a later corrected check.

## Domains and interpretation

- Require `Q0>0` for this momentum-constraint chart. The zero Fourier mode needs separate treatment. Require nonzero background dust for a fractional dust contrast.
- Preserve failures where the initial potential coefficient `(Q^2-bx^2)/D` vanishes. For the specified primary seed, the remaining constraint source there is `-[3+(2+b)x^2]/(bD)`, so the seed cannot be assigned a potential by a numerical denominator regularization.
- Track zeros of `delta_J`, `Psi_J`, and, where divided by, `f_velocity`. Report the underlying linear amplitudes even when a ratio is undefined or ill-conditioned.
- `f_density-f_velocity=3Phi_J'/delta_J`. Finite-wavelength Poisson ratios and growth ratios use the stated Newtonian-gauge density and are not automatically observed estimators. In a separate exact ordinary-GR dust solution, `Phi=P0`, `Theta=(2/3)zP0`, `delta=-2P0-(2/3)zP0`, with `z=Q^2/H^2`, all four ratios `mu,Sigma,f_density,f_velocity` equal `z/(z+3)` and approach one only in the subhorizon limit. This is a useful independent GR control, not a singular `b=0` limit of the supplied field metric.
- The supplied seeds, `Omega_m0=.3`, fixed parameter family and local measured-G bridge remain assumptions. The check does not identify a primordial growing adiabatic mode, prove perturbative/nonlinear stability, fit growth or lensing data, or supply a bias/window-calibrated E_G estimator.

## Actual execution and receipt scope

The pre-execution plan froze the three source files before reviewer computation. The primary exact-symbolic run reports **52 passed, zero failed**, exit 0, about 2.14 seconds including process overhead. The later mass-variation/GR supplement reports **14 passed, zero failed**, exit 0, about 0.89 seconds. These are 66 algebra assertions, not 66 independent experiments. The four deliberate false-formula controls, including the surviving constraint-only control, are separate and fully retained. Both stderr files are empty. No tolerance was adjusted, and no numerical integration or observational comparison was performed.

The derivation, scripts, exact matrix, full result records, command/timing receipts, stdout/stderr, frozen sources and final source-identity recheck are bound by `FINAL_RECEIPT_v1.json`. All three original source identities remain unchanged at that recheck. This report supports the equations and names the control limitation; it does not certify the parent's forthcoming differentiated matrix, integration, final source packet or mechanical gates.
