"""Additional exact checks, with the v1 matrix and its surviving control retained.

Before this run the parent disclosed an independent 31/1 outcome: omitting
the u-equation dust source survives its constraint-only test. No parent code
or raw outputs have been read. This supplements, not repeats, the completed
independent 52/0 run. Its planned controls are number-vs-energy dust variation,
the transverse force coefficient, a separate exact GR dust solution, and
the explicit chart/calibration identities. No empirical result is asserted.
"""
import datetime
import hashlib
import json
import pathlib
import sympy as S
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent
start = time.monotonic()
rows = []


def ck(name, expr):
    value = S.factor(S.cancel(expr))
    rows.append(dict(name=name, passed=value == 0, residual=str(value)))
    if value != 0:
        print('FAIL', name, value)


r,b,s,nu,u,x,Q2 = S.symbols('r b s nu u x Q2', real=True)
F = 1+s*S.exp(2*r*u)
B = S.exp(r*u)/S.sqrt(F)
beta = S.diff(S.log(B),u)
ck('number-fixed mass Hessian', S.diff(B,u,2)/B-S.diff(beta,u)-beta**2)
dn,drho,du,sigma = S.symbols('dn drho du sigma', real=True)
number_variation = sigma*beta*dn+sigma*S.diff(B,u,2)/B*du
energy_variation = sigma*beta*drho+sigma*S.diff(beta,u)*du
ck('number-to-energy contrast cancellation', number_variation.subs(dn,drho-beta*du)-energy_variation)
matrix = json.loads((OUT/'EXACT_ACTION_MATRIX_v1.json').read_text())
local = {str(z):z for z in [r,b,s,nu,u,x,Q2]}
M = S.Matrix([[S.sympify(v,locals=local) for v in row] for row in matrix['evolution_matrix']])
D = 1+S.Rational(2,3)*(1+b)*x*x
J0 = 1+(1-3*r*r)*s
expected_mass_source = -r*(1+s)*x*x/(J0*D)
ck('transverse dust force from mass variation', M[2,4]-expected_mass_source)

# Independent GR Einstein-de Sitter control, not b=0 in a degenerate metric.
z,P,H2 = S.symbols('z P H2', real=True)
sig_gr = S.Rational(3,2)*H2
q2_gr = z*H2
theta = S.Rational(2,3)*z*P
delta = -2*P-S.Rational(2,3)*z*P
phiprime = 0
h = -S.Rational(3,2)
ck('GR constant-potential momentum', phiprime+P-sig_gr*theta/q2_gr)
ck('GR dust continuity', z*S.diff(delta,z)+theta-3*phiprime)
ck('GR dust Euler', z*S.diff(theta,z)+(2+h)*theta-z*P)
ck('GR energy constraint', z*P+3*(phiprime+P)+sig_gr*delta/H2)
mu = -q2_gr*P/(sig_gr*delta)
fdensity = z*S.diff(delta,z)/delta
fvelocity = -theta/delta
ck('GR finite-wavenumber mu and Sigma', mu-z/(z+3))
ck('GR finite-wavenumber velocity growth', fvelocity-z/(z+3))
ck('GR fixed-potential density growth', fdensity-fvelocity)
ck('GR subhorizon limit', S.limit(mu,z,S.oo)-1)

k = S.symbols('k', real=True)
aval = (1-k)*(1+3*k)/4
sval = (1+k)/(k*(1-3*k))
ck('eta-family weak scalar relation', aval/(1+(1-3*aval)*sval)-k)
ck('eta-family strict-a upper gap', S.Rational(1,3)-aval-(1-3*k)**2/12)
L = [S.sympify(v,locals=local) for v in matrix['energy_constraint_row']]
chart_source = S.factor((L[4]-L[5]).subs(Q2,b*x*x))
ck('primary seed chart source', chart_source+(3+(2+b)*x*x)/(b*D))
receipt = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), sympy=S.__version__, script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), matrix_input_sha256=hashlib.sha256((OUT/'EXACT_ACTION_MATRIX_v1.json').read_bytes()).hexdigest(), elapsed_seconds=time.monotonic()-start, checks=rows, passed=sum(r['passed'] for r in rows), failed=sum(not r['passed'] for r in rows), transverse_mass_source=str(expected_mass_source), GR_control=dict(background='Einstein-de Sitter; separate GR dust theory', z='Q^2/H^2', zprime='z', Phi='P constant', Theta=str(theta), delta=str(delta), mu_Sigma='z/(z+3)', f_velocity='z/(z+3)'), primary_seed_chart_source=str(chart_source), correlation_scope='The primary 52/0 derivation and actual surviving off-orbit derivative control preceded the parent disclosure. This supplementary mass/GR control was written after that disclosure; it is not claimed source-excluded from the disclosed finding.')
with (OUT/'SUPPLEMENT_RESULTS_v1.json').open('x') as f:
    json.dump(receipt,f,indent=2)
    f.write('\n')
print(f"TOTAL: PASS={receipt['passed']} FAIL={receipt['failed']}")
print('Independent number-fixed dust mass variation and exact separate GR dust benchmark; no observational estimator.')
raise SystemExit(bool(receipt['failed']))
