"""Independent action/constraint algebra. No parent code or result is imported."""
import datetime
import hashlib
import json
import pathlib
import platform
import sys
import time
import sympy as S

OUT = pathlib.Path(__file__).resolve().parent
started = time.monotonic()
checks = []
controls = []
artifacts = {}


def simp(e):
    return S.factor(S.cancel(e))


def check(name, expr):
    residual = simp(expr)
    good = residual == 0
    checks.append(dict(name=name, passed=bool(good), residual=str(residual)))
    if not good:
        print('FAIL ' + name + ': ' + str(residual), flush=True)
    return residual


def check_matrix(name, mat):
    return mat.applyfunc(lambda _: _) if False else S.Matrix(mat.rows, mat.cols, lambda i, j: check(f'{name}[{i},{j}]', mat[i, j]))


r, b, s, nu, u, x, sig, Q2 = S.symbols('r b s nu u x sig Q2', real=True)
phi = [u, x]
F = 1 + s*S.exp(2*r*u)
J = 1 + (1-3*r*r)*s*S.exp(2*r*u)
D = 1 + S.Rational(2, 3)*(1+b)*x*x
K = S.diag(J/F**2, (1+s)*4*b/(9*D*F))
Ki = S.diag(1/K[0, 0], 1/K[1, 1])
W = (S.Rational(3, 2) + (b/2-r*u+2*r*r*u*u/b)*x*x + nu*u*u/2
     + s*(b/2+r*b*u+2*r*r*u*u/b)*x*x + 3*s*S.exp(4*r*u)/2)
U = (1+s)*W/F**2
B = S.exp(r*u)/S.sqrt(F)
alpha = S.Matrix([r/F, 0])
p = S.Matrix([0, -3*x/2])
acc = p.diff(x)*p[1]
H2 = D
h = -(1+b)*x*x/D


def on(e):
    return simp(e.subs(u, 0).subs(sig, x*x))


def on_matrix(mat):
    return mat.applyfunc(on)


K0 = on_matrix(K)
Ki0 = on_matrix(Ki)
Ugrad = S.Matrix([S.diff(U, z) for z in phi])
alpha0 = on_matrix(alpha)
force = Ki*(Ugrad + alpha*sig)
force0 = on_matrix(force)
df0 = S.Matrix(2, 2, lambda i, j: on(S.diff(force[i], phi[j])))
Gamma = [[[sum(Ki[i, n]*(S.diff(K[n, j], phi[k]) + S.diff(K[n, k], phi[j]) - S.diff(K[j, k], phi[n]))/2 for n in range(2)) for k in range(2)] for j in range(2)] for i in range(2)]
G0 = [[[on(Gamma[i][j][k]) for k in range(2)] for j in range(2)] for i in range(2)]
dG0 = [[[[on(S.diff(Gamma[i][j][k], phi[l])) for l in range(2)] for k in range(2)] for j in range(2)] for i in range(2)]
Tn = simp((p.T*K0*p)[0])
print('Fixed-action derivatives constructed before the orbit substitution.', flush=True)
check('Friedmann background', 3*H2 - H2*Tn - 2*on(U) - 2*x*x)
check('Raychaudhuri background', h + Tn + x*x/H2)
for i in range(2):
    check(f'scalar background {i}', acc[i] + (3+h)*p[i] + sum(G0[i][j][k]*p[j]*p[k] for j in range(2) for k in range(2)) + force0[i]/H2)
check('mass conformal gradient', on(S.diff(B, u)/B) - alpha0[0])

e = [S.zeros(1, 7) for _ in range(7)]
for i in range(7):
    e[i][i] = 1


def construct(momentum_sign=1, lapse_force_factor=-2, bad_sigma_derivative=False, omit_energy_lapse=False):
    M = S.zeros(7, 7)
    M[0, 2] = 1
    M[1, 3] = 1
    P = -e[6] + momentum_sign*x*x/Q2*e[5]
    for j in range(2):
        P += (K0*p)[j]*e[j]
    M[6, :] = P
    for i in range(2):
        row = S.zeros(1, 7)
        for j in range(2):
            deriv = df0[i, j]
            if bad_sigma_derivative and j == 1:
                deriv += (Ki0*alpha0)[i]*2*x
            row += (-Q2/H2*S.KroneckerDelta(i, j) - sum(dG0[i][l][m][j]*p[l]*p[m] for l in range(2) for m in range(2)) - deriv/H2)*e[j]
            row += (-(3+h)*S.KroneckerDelta(i, j) - 2*sum(G0[i][l][j]*p[l] for l in range(2)))*e[j+2]
        row -= (Ki0*alpha0)[i]*x*x/H2*e[4]
        row += 4*p[i]*P + lapse_force_factor*force0[i]/H2*e[6]
        M[i+2, :] = row
    M[4, :] = -e[5] + 3*P
    for i in range(2):
        M[4, i+2] += alpha0[i]
        for j in range(2):
            M[4, j] += on(S.diff(alpha[i], phi[j]))*p[i]
    M[5, :] = -(2+h+(alpha0.T*p)[0])*e[5] + Q2/H2*e[6]
    for j in range(2):
        M[5, j] += Q2/H2*alpha0[j]
    energy = x*x/H2*e[4]
    if not omit_energy_lapse:
        energy -= Tn*e[6]
    for j in range(2):
        energy += (K0*p)[j]*e[j+2]
        energy += (sum(on(S.diff(K[l, m], phi[j]))*p[l]*p[m]/2 for l in range(2) for m in range(2)) + on(Ugrad[j])/H2)*e[j]
    L = Q2/H2*e[6] + 3*(P+e[6]) + energy
    return M.applyfunc(simp), L.applyfunc(simp)


def Nder(mat):
    return mat.diff(x)*p[1] - 2*Q2*mat.diff(Q2)


def constraint_residual(M, L):
    return (Nder(L) + L*M + (3+2*h)*L).applyfunc(simp)


M, L = construct()
check_matrix('constraint propagation', constraint_residual(M, L))
check('constraint chart coefficient', L[6] - (Q2/H2-Tn))
check('constraint lacks transverse acceleration weight', L[2])

# Independent lowered-index Euler-Lagrange linearization. No Christoffel
# or raised-force helper is used to form these coefficients.
vv = S.Matrix(S.symbols('v_u v_x', real=True))
aa = S.Matrix(S.symbols('a_u a_x', real=True))
hh, hh2 = S.symbols('hh hh2', real=True)
R = S.zeros(2, 1)
for i in range(2):
    R[i] = sum(K[i, j]*(aa[j]+(3+hh)*vv[j]) for j in range(2))
    R[i] += sum((S.diff(K[i, j], phi[k])-S.diff(K[j, k], phi[i])/2)*vv[j]*vv[k] for j in range(2) for k in range(2))
    R[i] += (Ugrad[i]+alpha[i]*sig)/hh2
bg = {u: 0, sig: x*x, hh: h, hh2: H2, vv[0]: p[0], vv[1]: p[1], aa[0]: acc[0], aa[1]: acc[1]}


def ELon(expr):
    return simp(expr.subs(bg, simultaneous=True))


Erows = S.zeros(2, 7)
for i in range(2):
    for j in range(2):
        Erows[i, j] = ELon(S.diff(R[i], phi[j])) + Q2/H2*K0[i, j]
        Erows[i, j+2] = ELon(S.diff(R[i], vv[j]))
    Erows[i, 4] = alpha0[i]*x*x/H2
    Erows[i, 6] = 2*on(Ugrad[i]+alpha[i]*sig)/H2
    Erows[i, :] -= 4*(K0*p)[i]*M[6, :]
EL_acc = (-Ki0*Erows).applyfunc(simp)
check_matrix('coordinate vs independent Euler-Lagrange scalar matrix', M[2:4, :] - EL_acc)
print('Full action matrix and constraint propagation identities checked.', flush=True)

# Generic conservation/Bianchi route, separate from the fixed-action matrix.
Ht, kd, mt, Et, Pt, phi_t, Rho = S.symbols('Ht kd mt Et Pt phi_t Rho', real=True)
phidot = mt-Ht*phi_t
mdot = -3*Ht*mt + Pt + Rho*phi_t
edot = -3*Ht*(Et+Pt) + 3*Rho*phidot - kd*mt
ham = kd*phi_t + 3*Ht*mt + Et
hamdot = -2*Ht*kd*phi_t + kd*phidot - 3*Rho*mt + 3*Ht*mdot + edot
check('generic total-conservation energy-residual law', hamdot + 3*Ht*ham)

# Exact Jordan readout and density normalization controls.
beta = alpha0[0]
dJ = e[4]-4*beta*e[0]
PhiJ = e[6]-beta*e[0]
PsiJ = e[6]+beta*e[0]
check_matrix('Jordan dust continuity', dJ*M + e[5] - 3*PhiJ*M)
check_matrix('Jordan lensing sum', PhiJ+PsiJ-2*e[6])
qaux, hvhat, kval, omega = S.symbols('qaux hvhat kval omega', positive=True)
B02 = 1/(1+s)
rhoE = 2*qaux*hvhat**2*sig
rhoJ = rhoE/B02**2
GN = (1+kval)/(8*S.pi*qaux*(1+s))
kphysJ2 = hvhat**2*Q2/B02
check('physical Poisson prefactor', kphysJ2/(4*S.pi*GN*rhoJ) - Q2/((1+kval)*sig))
HJ2 = hvhat**2*D/B02
check('physical Omega normalization', 8*S.pi*GN*rhoJ/(3*HJ2) - 2*(1+kval)*sig/(3*D))
x02 = 3*omega/(2*(1+kval-omega*(1+b)))
check('supplied density calibration inverse', (2*(1+kval)*x*x/(3*D)-omega).subs(x*x, x02))
check('calibrated GR-shaped curve', D.subs(b, kval).subs(x*x, x02.subs(b, kval)) - 1/(1-omega))
check('primary-seed constraint coefficient', L[6] - (Q2-b*x*x)/D)
primary_phi = simp(-(L[4]-L[5])/L[6])
check('primary-seed independent solved potential', primary_phi - x*x*(3*D-Q2)/(Q2*(Q2-b*x*x)))
check('primary-seed exact energy constraint', (L*S.Matrix([0,0,0,0,1,-1,primary_phi]))[0])

witnesses = [
    {r:S.Rational(1,3), b:S.Rational(1,7), s:S.Integer(2), nu:S.Rational(5,4), x:S.Rational(3,2), Q2:S.Integer(11)},
    {r:S.Rational(1,2), b:S.Rational(1,100), s:S.Integer(17), nu:S.Rational(4,3), x:S.Integer(2), Q2:S.Integer(3)},
]
specs = [
    ('momentum dust sign', dict(momentum_sign=-1)),
    ('scalar lapse force sign', dict(lapse_force_factor=2)),
    ('differentiate sigma=x^2 before force partial', dict(bad_sigma_derivative=True)),
    ('omit scalar energy lapse', dict(omit_energy_lapse=True)),
]
for name, changes in specs:
    Mm, Lm = construct(**changes)
    closure = constraint_residual(Mm, Lm)
    action_diff = (Mm[2:4, :]-EL_acc).applyfunc(simp)
    fixed = []
    for w in witnesses:
        cr = [simp(v.subs(w)) for v in closure]
        ar = [simp(v.subs(w)) for v in action_diff]
        fixed.append(dict(parameters={str(k):str(v) for k,v in w.items()}, closure_residuals=list(map(str, cr)), scalar_action_residuals=list(map(str, ar)), closure_detected=any(v != 0 for v in cr), scalar_action_detected=any(v != 0 for v in ar)))
    controls.append(dict(name=name, intentional_false_formula=True, closure_residuals=list(map(str, closure)), scalar_action_residuals=list(map(str, action_diff)), closure_identically_zero=all(v==0 for v in closure), scalar_action_difference_identically_zero=all(v==0 for v in action_diff), exact_witnesses=fixed))
    print('CONTROL '+name+': closure_detected='+str(not all(v==0 for v in closure))+', scalar_action_detected='+str(not all(v==0 for v in action_diff)), flush=True)

# Assert the actual blind spot rather than concealing the surviving mutation.
blind = next(z for z in controls if z['name']=='differentiate sigma=x^2 before force partial')
check('transverse force error survives constraint-only check', S.Integer(not blind['closure_identically_zero']))
check('independent action check exposes transverse force error', S.Integer(blind['scalar_action_difference_identically_zero']))

artifacts.update(K=K.applyfunc(str).tolist(), U=str(U), alpha=alpha.applyfunc(str).tolist(), force_on_orbit=force0.applyfunc(str).tolist(), force_partial_at_fixed_sigma=df0.applyfunc(str).tolist(), connection_on_orbit=G0, connection_partials_on_orbit=dG0, state_order=['du','dx','w_u','w_x','delta','Theta','Phi'], evolution_matrix=M.applyfunc(str).tolist(), energy_constraint_row=list(map(str,L)), lowered_action_acceleration=EL_acc.applyfunc(str).tolist(), primary_seed_phi=str(primary_phi))
for name, value in [('EXACT_ACTION_MATRIX_v1.json', artifacts), ('CONTROL_RESIDUALS_v1.json', controls)]:
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2, default=str)
        f.write('\n')
record = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), interpreter=sys.executable, python=platform.python_version(), sympy=S.__version__, elapsed_seconds=time.monotonic()-started, check_scope='Exact symbolic source mathematics; no author implementation or empirical oracle.', checks=checks, passed=sum(c['passed'] for c in checks), failed=sum(not c['passed'] for c in checks), controlled_false_formula_count=len(controls), constraint_only_blind_spot_preserved=blind, script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
with (OUT/'RESULTS_v1.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(f"TOTAL: PASS={record['passed']} FAIL={record['failed']}", flush=True)
print('Controlled false formulas and the genuine constraint-only blind spot are retained separately.', flush=True)
raise SystemExit(bool(record['failed']))
