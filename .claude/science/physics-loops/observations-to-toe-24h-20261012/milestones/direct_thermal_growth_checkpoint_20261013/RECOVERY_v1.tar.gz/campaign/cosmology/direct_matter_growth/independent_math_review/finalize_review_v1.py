"""One-shot immutable source and review-evidence binding; no science rerun."""
import datetime
import hashlib
import json
import pathlib

OUT = pathlib.Path(__file__).resolve().parent


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def write_new(name, obj):
    with (OUT/name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


checks = []


def check(name, good):
    checks.append(dict(name=name, satisfied=bool(good)))


plan = json.loads((OUT/'PRE_EXECUTION_PLAN_v1.json').read_text())
for row in plan['sources']:
    check('original source unchanged: '+row['original_path'], bind(pathlib.Path(row['original_path']))['sha256'] == row['sha256'])
    check('snapshot intact: '+row['snapshot'], bind(pathlib.Path(row['snapshot']))['sha256'] == row['sha256'])

for name,script,result_name,counts in [
    ('EXECUTION_v1.json','check_perturbation_math_v1.py','RESULTS_v1.json',(52,0)),
    ('SUPPLEMENT_EXECUTION_v1.json','check_mass_and_gr_supplement_v1.py','SUPPLEMENT_RESULTS_v1.json',(14,0)),
]:
    receipt = json.loads((OUT/name).read_text())
    result = json.loads((OUT/result_name).read_text())
    check(name+' actual successful exit', receipt['exit_code'] == 0 and not receipt['timed_out'])
    check(name+' immutable executed script', bind(OUT/script)['sha256'] == receipt['script_sha256'] == result['script_sha256'])
    check(name+' results retain all checks', (result['passed'],result['failed']) == counts and len(result['checks']) == sum(counts))
    for row in receipt['outputs']:
        check('raw execution output intact: '+row['path'], bind(pathlib.Path(row['path']))['sha256'] == row['sha256'])

control = json.loads((OUT/'CONTROL_RESIDUALS_v1.json').read_text())
survivor = next(x for x in control if x['name']=='differentiate sigma=x^2 before force partial')
check('actual constraint-only surviving control preserved', survivor['closure_identically_zero'] and not survivor['scalar_action_difference_identically_zero'] and all(not x['closure_detected'] and x['scalar_action_detected'] for x in survivor['exact_witnesses']))
supplement = json.loads((OUT/'SUPPLEMENT_RESULTS_v1.json').read_text())
check('supplement binds exact original matrix', supplement['matrix_input_sha256'] == bind(OUT/'EXACT_ACTION_MATRIX_v1.json')['sha256'])
identity = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='Receipt/source identity only; no repeated mathematical or empirical execution.', checks=checks, unsatisfied=[r for r in checks if not r['satisfied']])
write_new('FINAL_IDENTITY_CHECK_v1.json', identity)

records = []
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name!='FINAL_RECEIPT_v1.json':
        record = bind(p)
        record['relative_path'] = str(p.relative_to(OUT))
        records.append(record)
assert len({r['relative_path'] for r in records}) == len(records)
receipt = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='Focused independent handwritten mathematical review', reviewer='/root/launch_check', author='/root', verdict='No substantive formula error in frozen proposal; correct constraint law with a preserved transverse-acceleration blind spot and explicit chart/diagnostic domains.', report=bind(OUT/'REPORT_v1.md'), complete_derivation=bind(OUT/'INDEPENDENT_DERIVATION_v1.md'), source_freeze=bind(OUT/'PRE_EXECUTION_PLAN_v1.json'), final_source_identity_check=bind(OUT/'FINAL_IDENTITY_CHECK_v1.json'), main_science_revision='516cb69d8487ff04f8a48e065d3dcbe71d7dd237', primary_exact_checks=dict(passed=52,failed=0,execution=bind(OUT/'EXECUTION_v1.json')), supplement_exact_checks=dict(passed=14,failed=0,execution=bind(OUT/'SUPPLEMENT_EXECUTION_v1.json')), controlled_false_formulas=4, actual_constraint_only_survivor=bind(OUT/'CONTROL_RESIDUALS_v1.json'), parent_reported_context='Parent disclosed 31/1 operator sensitivity result after the primary independent run and before the supplementary mass/GR check. No parent implementation or raw output was read; that count is not independently verified here.', source_inputs_unchanged=not identity['unsatisfied'], evidence_paths_unique=True, evidence_count=len(records), evidence=records, author_implementation_review=False, time_integration=False, independent_empirical_tests=0, formal_audit=False, mechanical_gates=False, git_mutations=False, parent_source_edits=False, registry_or_status_mutations=False, external_chat_messages=False, allowed_write_directory=str(OUT), receipt_self_hash='Excluded; supplied externally after writing.')
write_new('FINAL_RECEIPT_v1.json', receipt)
print(json.dumps(dict(report=bind(OUT/'REPORT_v1.md'), derivation=bind(OUT/'INDEPENDENT_DERIVATION_v1.md'), receipt=bind(OUT/'FINAL_RECEIPT_v1.json'), identity_failures=identity['unsatisfied'], evidence_count=len(records)),indent=2))
raise SystemExit(bool(identity['unsatisfied']))
