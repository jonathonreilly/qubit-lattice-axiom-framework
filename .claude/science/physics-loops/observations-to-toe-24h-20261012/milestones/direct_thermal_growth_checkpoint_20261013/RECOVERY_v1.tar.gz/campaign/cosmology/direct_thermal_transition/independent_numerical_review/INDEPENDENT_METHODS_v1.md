# Independent thermal numerical methods

This is a numerical check of the exact v1 action, matter assumptions and program frozen in `INPUT_FREEZE_v1.json`. The parent remains the scientific author. The parent program was not imported as an independent oracle or rerun unchanged. The existing handwritten review was read completely, including its source and 62 result records. The equations below independently connect the admitted action to the new numerical representation.

## Thermal sums and a different quadrature

Expand the supplied zero-chemical-potential Fermi occupation as a convergent alternating sum of Boltzmann factors. With r=1/T and c=2/pi^2, define explicitly

    S2=sum (-1)^(n+1) K2(nr)/n^2,
    S1=sum (-1)^(n+1) K1(nr)/n,
    S0=sum (-1)^(n+1) K0(nr).

The grand-pressure expansion and its derivatives give

    P_e/T^4=c r^2 S2,
    (rho_e-3P_e)/T^4=c r^3 S1,
    rho_e/T^4=3P_e/T^4+c r^3 S1,
    (d rho_e/dT)/T^3=c[12r^2 S2+5r^3 S1+r^4 S0].

The heat coefficient follows by differentiating at fixed electron mass and using K2'=-(K1+K3)/2, K3=K1+4K2/(nr), and K2=K0+2K1/(nr). Photons add pi^2/15 to density/T^4 and four times that value to heat/T^3. The sums use scaled Bessel functions times exp(-nr), with enough terms to exceed nr=55 at the upper thermal range. No parent Laguerre node or reference function is used here.

A second numerical route sets epsilon=(E-m_e)/T in the energy integral and factors out exp(-r). The remaining occupation factor is exp(-epsilon)/[1+exp(-(epsilon+r))]. Its square-root momentum factor is sqrt(epsilon(epsilon+2r)). Density, pressure, trace and heat integrands are respectively Ebar^2 pbar, pbar^3/3, r^2 pbar and Ebar^3 pbar/[1+exp(-Ebar)], times this factor. Adaptive infinite-range quadrature operates on quantities of ordinary size even when the physical Boltzmann tail is tiny. All twelve frozen temperatures were checked; the maximum relative Bessel/adaptive disagreement in electron quantities is 1.31e-15.

The separate finite-difference entropy check verifies d(s_pl/T^3)/dlnT=heat_bar-3 entropy_bar. The actual finite-temperature entropy at T_i=10 gives the pair-disappearance limit T_nu/T=0.7139301690449387. It is not the infinite-T_i value (4/11)^(1/3).

The independent ODE uses a 3001-point cubic representation of the Bessel values in L=ln(10/T). At 256 non-node points, the largest normalized interpolation discrepancy is 1.24e-12. Differentiating the interpolated entropy independently gives 1/c_T to 2.67e-10. This interpolation is reviewer-owned and independent of the parent's direct Gauss-Laguerre evaluation. It is not a modification to the parent calculation.

## Algebraic entropy clock

Let Sbar(T)=s_pl(T)/T^3. Conservation fixes the physical expansion coordinate and neutrino temperature algebraically:

    N_J=L-(1/3)ln[Sbar(T)/Sbar(T_i)],
    T_nu=T_i exp(-N_J),
    dN_J/dL=1/c_T(T).

This eliminates the parent's two integrated log-temperature variables and its passive N_J coordinate. It also avoids solving for temperature sample times after integration. The independent sample grid is directly the same 101 logarithmic temperatures.

The coordinate transformation g_J=B^2 ghat gives

    Nhat=N_J-ln(B/B_i)=N_J-(1/2)ln C_B,
    dL/dNhat=c_T[1+alpha_B du/dNhat].

The positive clock branch is checked during each independent RHS evaluation. This is an evolution in temperature, not a replay of the parent's seven-component Nhat system.

## Covariant scalar momenta

Use field coordinates chi=(u,l), where l=ln(y/sqrt(R_star)). The field metric in these coordinates is diagonal:

    g1=J/F^2,
    g2=(1+s)b y^2/(3FD),
    y^2=R_star exp(2l).

The rescaling removes a large constant from log y. Write v^i=dchi^i/dNhat and define the lowered momenta M_i=g_i v^i. The homogeneous Euler-Lagrange equation, divided by Hhat^2, is

    M_i'=-(3+h)M_i+(1/2)(partial_i g_j)(v^j)^2
          -[U_i+alpha_i(sigma-3pi_f)]/H2.

Here alpha_i=(partial_u ln B,0). This covector form includes all field-metric derivatives and differs from the parent's expanded acceleration formulas. Differentiate the metric and potential before evaluating them. The relevant derivatives are

    partial_u g1=2alpha z[(1-3a)/J-2/F]g1,
    partial_u g2=-2alpha z g2/F,
    partial_l g2=2g2/D.

For numerical stability separate the normalized potential into constant, nu u^2, y^2 and induced-vacuum pieces U0,Um,Uy,Uv. Then

    U_u=-4alpha z(U0+Um+Uy)/F
         +(1+s)nu u/F^2+4alpha Uv/F,
    U_l=2Uy.

The Friedmann and Raychaudhuri values are independently reconstructed as

    Q=sum_i M_i v^i,
    H2=2(sigma+U)/(3-Q),
    h=-(sigma+pi_f)/H2-Q,
    sigma=C_B^2 R_star rho, pi_f=C_B^2 R_star P.

These signs imply the Einstein-fluid exchange sigma'=-3(sigma+pi_f)+alpha_B p(sigma-3pi_f). It cancels the scalar trace work in total energy. At the supplied initial state the constraint gives H2=D and the remaining accelerations are

    p'_i=-sqrt(a)(1+s)R_star tau_i/(J_i D_i),
    w'_i=2R_star tau_i/(3D_i).

The initial finite trace is not discarded. Its sign and normalization were checked against all serialized initial accelerations using the independent Bessel EOS.

For integration divide both the coordinate and momentum Nhat derivatives by c_T(1+alpha_B p). Constant initial metric factors rescale the momenta to keep tolerances comparable across small k. DOP853 with rtol=2e-10, atol=2e-12 and maximum L step .02 is used, rather than Radau and a finite-difference Jacobian. Eight base histories and the two scale cases are integrated, plus two tighter own refinements. The refined own settings are rtol=2e-11, atol=2e-13 and maximum L step .01. All twelve completed. The eight massless controls are compared directly with the analytic solution, avoiding unnecessary integration of an exact invariant history.

## Readout and comparisons

From physical proper time dt_J=B dthat and scale a_J=B ahat,

    H_J=Hhat(1+alpha_B p)/B.

This gives the squared formula in the handwritten note. The independent readout reconstructs metric, potential, density, clock, kinetic margin and the Hubble ratio from each stored state and the separate EOS. It also checks the diagnostic G_N ratio, temperatures, entropy invariants, trace fraction and all stored extrema. Comparison to the independent evolution covers all seven stored state components and N, Hratio, GNratio, N_J', T_nu and T_nu/T at all 2020 original sample rows.

The comparator has the same physical temperature/density and fixed supplied reference G_N0. The inferred early-plasma Newton ratio remains conditional on a locally frozen, long-range, weak-body scalar bridge. Neither numerical agreement nor the background matter model establishes that bridge at arbitrary plasma scales.

All 13573 original check records were consumed; the 11440 records with explicit actual/expected values were recalculated. This is evidence-consistency checking, not 13573 additional independent physical tests. Every per-case file was compared with its corresponding full-result object. The four original variant comparisons were recomputed, and scale versus refined runs were also compared at the same node/solver settings to separate a change of supplied R_star from numerical refinement.

## Adversarial sensitivity and warning mechanism

Each mutant contains exact copies of all nine inputs and a fresh post-edit hash manifest. Only the intended source line changes. The physical Hubble-clock omission removes (1+alpha_B p)^2 from H_J^2 while leaving the evolution unchanged. It passes all original assertions; direct independent physical-clock reconstruction rejects 555 of its 808 thermal sample readouts at a normalized 2e-8 threshold. The entropy-cooling omission replaces dlnT/dNhat=-c_T N_J' by -N_J'. It is caught by 2496 genuine energy, fluid, entropy and temperature-ratio checks, with all source identity checks still passing.

The exact SciPy common.py implementation was preserved. A synthetic two-component system with one passive coordinate reproduces the same two overflow messages after repeated numerical-Jacobian requests: its adaptive step factor becomes infinite in the exactly zero column, while the returned Jacobian remains finite and exactly correct. The parent N_J state is likewise absent from every RHS dependency. This demonstrates a mechanism present in the code; the original run was not instrumented, so it does not identify every internal warning event. The unchanged original stderr and synthetic warning evidence remain preserved. Independent DOP853 evolution does not use this Jacobian machinery.

## Precision boundary

The parent's 2e-8 EOS criterion is normalized on T^-4-scaled energy/pressure/trace and the corresponding barred heat/entropy quantities. It is not a relative 2e-8 bound on an arbitrarily small trace. Six additional reviewer comparisons of unscaled trace failed at that stronger criterion. Those failures remain unmodified in the first EOS result; all comparisons using the actual parent's barred criterion pass. Independent evolution bounds the effect on the tested outputs directly, without changing either criterion after seeing the failure. This is a finite numerical cross-check, not a rigorous global error certificate or an empirical thermal-history test.
