# Focused thermal implementation review — original v1

The original computed values are independently reproduced within the declared comparison tolerance, but the original controls have a material physical-readout gap. Removing the velocity-dependent Jordan clock factor from the reported Hubble ratio passes all 13573 original assertions despite changing that ratio by up to 2.83e-4. This surviving mutation is preserved and was reported promptly to the parent. The actual unmutated formula and results agree with the independent calculation.

This report freezes the original review before examining the parent's separately versioned repair. It is a focused implementation/numerical check, not a formal audit, a new research route or an empirical acceptance claim.

## Source identity and coverage

The original runner is `check_thermal_transition_v1.py`, SHA-256 `fb92f069fc9e2bfea2ec401f795379651cf7a743aac12ea781412fe0c40f55d0`. The original full result is SHA-256 `587a6e96858db02f336cc7cae8dec83c9ee9bf6c2ec38defa5bf3f83a10801d9`; the handwritten note is SHA-256 `0bd3d91fdec1d11fd9200cce4f910c751baba08e2cf1188089e1f75d9fc5edd8`.

`INPUT_FREEZE_v1.json` copies and binds all nine executed inputs plus the execution evidence and existing independent handwritten-review recovery package: 50 original paths in total. Every frozen author input matched its declared hash before any check. The complete note, protocol, fixture, details, ledger, runner and mathematical review were read. The full node arrays and all result row classes were consumed programmatically. Exact prior curvature/weak-field handwritten premises were reused only at unchanged identities, without importing a global theorem or any parent numerical helper.

The later `RESULTS_AND_SCOPE_v1.md` was separately frozen and read under `SCOPE_INPUT_FREEZE_v1.json`. Its sampled-extremum, warning, refinement-coverage and empirical limits are consistent with the evidence. Its table values are the rounded values independently checked here. Primary-paper reading assertions in the ledger were not independently re-audited; the admitted statistical equations were checked directly. No paper's abundance or N_eff result is used as an oracle.

The full original positive parent program was not rerun. Two explicitly mutated copies were executed under freshly computed nine-input manifests. Writes are confined to this review directory. No parent source, Git state, PR, settings, other chat or formal audit state was changed.

## Independent numerical result

The recipe and derivation are in `INDEPENDENT_METHODS_v1.md`. The code is `independent_thermal_review_v1.py`, executed by the hash-recording `run_stage_v1.py`. The independent route uses Bessel-K thermal sums, a scaled adaptive quadrature comparison, algebraic entropy/neutrino conservation, temperature as the clock, and covariant scalar momenta with DOP853. No parent helper is imported.

All eight thermal histories, all eight analytic massless comparisons, both refined cases and both scale variants were checked at every one of the 101 declared temperature sites. This is 2020 stored sample rows. The independent run also performs its own two tighter refinements. The maximum normalized discrepancies over the full original sample census are:

| Quantity | Maximum discrepancy |
| --- | ---: |
| H_J/H_GR | 2.1245e-11 |
| G_N/G_N0 diagnostic | 3.331e-15 |
| u | 4.554e-11 |
| p=du/dNhat | 7.070e-9 |
| log-y velocity | 5.904e-11 |
| Einstein e-fold N | 4.249e-11 |
| T_nu/T | 1.118e-10 |

The largest scalar-velocity discrepancy occurs for k=1e-6 on the equal branch. All are below the predeclared 2e-6 comparison threshold. The independent EOS interpolation was checked away from its nodes; maximum normalized error is 1.24e-12. Its entropy derivative gives the cooling clock to 2.67e-10. Independent Bessel and scaled adaptive quadrature electron quantities agree relatively to 1.31e-15 at all twelve frozen temperatures.

All original initial accelerations agree with the independently computed finite-trace expressions. All sampled kinetic margins, physical clock branches and temperatures remain positive. The analytic massless solution reproduces the parent controls. Every stored row diagnostic and sampled extremum was recomputed, and all twenty per-case JSON objects are identical to their full-result entries. All 13573 original check records were consumed, including recalculation of the 11440 explicit numerical comparison records. Those consistency checks are not additional independent experiments.

At identical refined numerical settings, changing R_star from 1e30 to 1e20 changes Hratio by at most 1.68e-13 for k=.001 equal and 2.23e-16 for k=1e-5 split. This is a supplied high-density scale comparison, not a measurement or a general scale-independence theorem. The source refined only these two cases; the independent calculation supplies a distinct-method comparison for every frozen base case, not a rigorous error bound for every possible parameter.

## Original scientific rows and interpretation

The following are extrema over the 101 supplied sample sites, not certified continuous extrema:

| k | Branch | Minimum H_J/H_GR | Maximum H_J/H_GR | Final u |
| ---: | --- | ---: | ---: | ---: |
| .01 | b=a | 1.09687423037 | 1.11467484048 | .1393919364 |
| .01 | b=k | .999805330212 | 1.00017388230 | .00169503889 |
| .001 | b=a | 1.09867742661 | 1.11769852823 | .1467633379 |
| .001 | b=k | .999979379458 | 1.00001864885 | -.00285088703 |
| 1e-5 | b=a | 1.09886284146 | 1.11803063464 | .1476425204 |
| 1e-5 | b=k | .999999792467 | 1.00000018788 | -.00334618331 |
| 1e-6 | b=a | 1.09886451455 | 1.11803365334 | .1476505791 |
| 1e-6 | b=k | .999999979246 | 1.00000001879 | -.00335068213 |

The full u/p ranges, final p, minimum Newton diagnostic, minimum Jordan clock and endpoint temperatures are recorded in `SUMMARY_v1.json`. The shared entropy endpoint is consistent with the finite-initial-temperature value 0.7139301690449387. This differs from the infinite-temperature instantaneous limit because T_i=10 is supplied, not because the calculation predicts noninstantaneous neutrino transport.

The b=k branch was separately calibrated before this transition. Its proximity to the chosen reference does not predict b or fit a thermal observation. All species, equilibrium statistics, decoupling, electron-mass unit, initial scalar state, flat expanding background and R_star are supplied. Baryons, reaction networks, weak collisions, QED corrections, perturbations, abundances and late matching remain absent. The local Newton expression is only the stipulated frozen-background weak-body diagnostic. These data do not constitute a BBN/CMB likelihood or a selection theorem for the initial history.

## Material surviving mutation

In `mutations/omit_jordan_hubble_velocity/`, the sole source edit is

    HJ2=H2*njp*njp/CB  ->  HJ2=H2/CB.

All nine hashes were recomputed after that edit. The full mutant exits 0 with 13573 passing checks and no failed science or identity check. All thermal states are bitwise identical to the original; the erroneous clock conversion affects only readout. The maximum absolute Hratio change is 0.0002832749850272265 at k=.01 equal, T=0.20892961308540567. On k=.01 split it is 0.00016005405033370224. These exceed the declared 2e-6 comparison scale.

The cause is specific: massless controls have N_J' approximately one, and refinement compares the same readout function against itself. The program lacks an independent physical-clock check at nonzero velocity. Direct reconstruction from the independent geometry/clock calculation rejects 555 of 808 thermal mutant samples at normalized 2e-8. The source, fresh manifest, all raw/per-case output, failure finding and independent rejection rows are preserved. Hash mismatch is not used as detection.

The needed repair is a separate nonzero-velocity physical proper-time/scale-factor readout oracle, connected to the serialized values and their extrema. The parent has proposed a separate v2 correction; it is deliberately outside this immutable original report and requires its own affected-source check.

## Detected mutation and preserved stronger failures

In `mutations/omit_plasma_entropy_cooling/`, replacing the temperature RHS by -N_J' removes c_T while keeping the EOS unchanged. Every fresh input hash check passes, but the full program exits 1 with 2496 failed checks: 48 energy, 48 fluid, 1200 plasma-entropy and 1200 neutrino/photon-ratio comparisons. All thermal endpoints are still reached. Thus the existing thermodynamic controls do detect this substantive physical error rather than merely failing a provenance check.

The reviewer's first EOS phase also records six failures of an additional, stronger comparison applied to unscaled trace values. The original fixture's normalized 2e-8 test is on quantities divided by T^4, with denominator max(1,abs(reference)). It therefore does not promise relative 2e-8 accuracy on a small trace. All tests against that actual barred criterion pass. The stronger failures are preserved without changing the test or rerunning it:

| T | Nodes | Unscaled trace normalized discrepancy |
| ---: | ---: | ---: |
| 5 | 64 | 1.857e-6 |
| 10 | 64 | 1.152e-5 |
| 10 | 128 | 4.594e-7 |
| 20 | 64 | 1.656e-5 |
| 20 | 128 | 2.895e-6 |
| 20 | 256 | 1.148e-7 |

The actual trajectory starts at T=10 and uses 128 or 256 nodes. The independent evolution directly shows its outputs remain within the declared comparison tolerance. These six stronger failures establish a precision limit, not an undisclosed failure of the original barred-EOS gate.

## SciPy warning assessment

The original stderr, SHA-256 `8f3602474bd26b7f57b6113d6d1d8901b03af8e229b313afef66b0845b02bec0`, contains two overflow warnings in SciPy's finite-difference Jacobian step-factor multiplication. They were not hidden or suppressed. The parent system includes a passive N_J coordinate that affects no RHS component. In the preserved SciPy implementation, repeated exact-zero differences in such a column can increase its step factor without an upper bound.

A separate two-state passive-coordinate fixture reproduces both warnings: the passive factor becomes infinity while the returned Jacobian remains finite and correct. This is a mechanism reproduction consistent with the parent's structure; it is not a log of every original internal Jacobian or proof that any arbitrary overflow warning is harmless. Independent DOP853 trajectories, which use no finite-difference Jacobian, agree at all stored sites, providing direct evidence against a material output error from this warning at the tested tolerance. The computational stiffness and original warning remain part of the result.

## Preserved execution and disposition

Independent phase records bind the exact code and inputs at start and end. The EOS phase has 2546 passed and six stronger trace failures; history construction has nine identity checks and twelve completed integrations; full comparison has 82191 passed and zero failed records; warning assessment has twelve passed and zero failed records. The many record-level checks are explicitly distinguished from independent derivations and integrations. Both mutant runs and all their failures survive unchanged.

The numerical formula and stored original values are supported by the independent route within the declared domain and comparison tolerance. The original control suite's Hubble-readout sensitivity gap remains a finding of this v1 review until separately checked repair evidence addresses it. `FINAL_RECEIPT_v1.json` binds the full report, methods, sources, output rows, warning and mutations. The later v2 source is not used to rewrite this original disposition.
