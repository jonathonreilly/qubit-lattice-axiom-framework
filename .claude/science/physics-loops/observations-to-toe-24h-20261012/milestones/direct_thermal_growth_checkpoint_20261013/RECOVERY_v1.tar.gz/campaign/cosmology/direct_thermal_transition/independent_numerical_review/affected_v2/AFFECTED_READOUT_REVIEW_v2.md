# Thermal readout correction: focused affected-source review

The separately versioned v2 controls close the specific physical-clock gap found in the immutable v1 review. The same one-line omission, executed with twelve freshly computed input hashes, now exits 1 with 1216 scientific failures. Its source checks all pass. No physical function, trajectory, prediction, original tolerance or original check object was changed by the repair.

This is a narrow implementation and evidence check. It is not a formal audit, an empirical thermal-history test or a proof of general numerical accuracy. The original report and its actual failures remain unchanged.

## Exact scope and preserved originals

The v2 runner is `check_thermal_transition_v2.py`, SHA-256 `4ce62456ddf2e5521bab9c5985e4ba5d0cc6423c05da446238374d995258d17b`. Its executed result is SHA-256 `1b9c7df8354ce5b8b4a5b549eae8543f1863aa7011b8ad455a49090b93723159`. `INPUT_FREEZE_v2.json` binds and copies 38 source/evidence paths, including all twelve executed inputs. The original receipt is SHA-256 `3587bbcd2e8e240e6e477c116569a0015fdab5e5b62ca37f810190942bbe0489`; every one of its 163 listed artifacts and 51 original source/recovery pairs was checked unchanged.

The complete new runner, exact diff, correction record, fixture, execution record and output identity statement were read. All added output records were consumed, not sampled. The unchanged scientific arguments and independent numerical results are reused only after exact identity checks. No author helper was imported as positive evidence. Neither unchanged positive parent runner was reexecuted. The only full v2 execution here was the deliberately corrupted copy.

AST comparison confirms that all nine original non-main functions are identical. Removing only the two newly added functions and the one new main call makes the entire parsed v2 module identical to v1. The preserved textual patch is also exactly the recomputed unified diff. Thus the new input census grows from nine to twelve because the fixture, correction record and patch were added; no old physical input was replaced except the separately named runner version.

## Independent readout derivation

Write A=exp(sqrt(a)u), F=1+s A², B=A/sqrt(F), J=1+(1-3a)s A² and D=1+2(1+b)y²/3. The raw-action Weyl transformation gives

    K_u=(1-3a s A²)/F + (3/4)(F_u/F)² = J/F²,
    K_y=(1+s)b/(3FD),
    d ln B/du=sqrt(a)/F.

The first expression is the original kinetic term plus the Weyl derivative term; it is not a rescaling of an already computed output. With x=0, the dimensionless potential and matter energy are

    U=(1+s)[3/2 + (1+s)b y²/3 + nu u²/2 + (3/2)s A⁴]/F²,
    sigma=(1+s)² B⁴ Rstar rho.

For p=du/dNhat and w=d ln y/dNhat, the Friedmann constraint determines h=Hhat/Hhat_v through

    h²=2(sigma+U)/(3-K_u p²-K_y y² w²).

The physical scale factor and clock are a_J=B a_hat and dt_J=B dt_hat. Differentiating these directly yields

    H_J=(Hhat/B)[1+(d ln B/du)p],
    N_J'=1+(sqrt(a)/F)p.

The normalization Hhat_v=H_v/sqrt(1+s) therefore gives

    H_J/H_GR = h[1+(sqrt(a)/F)p]
                 /sqrt((1+s)B²[1+(2/3)(1+k0)Rstar rho]).

This is precisely the factor that the original survivor omitted. It retains its sign through the physical expanding-branch premise N_J'>0. The stored cases and sixteen new nonzero-velocity fixtures have this positive clock and positive kinetic/Friedmann margins. The check does not assert positivity at arbitrary field states.

The conditional local Newton diagnostic is

    G_N/G_N0=(1+s)B²[1+(d ln B/du)²/K_u]/(1+k0)
             =(1+s)B²(1+a/J)/(1+k0).

The parent oracle differentiates B and F with 60-digit arithmetic and computes these quantities from raw action terms. It does not call `quantities` or `rhs`. It does call the existing EOS function; this is explicitly disclosed and appropriate to this particular readout check. The EOS is separately checked in the original review, including its retained precision limits. V2 must not be represented as an independent thermodynamic oracle.

## Complete new-record comparison

The new records comprise 2020 sample rows times eight fields, 120 serialized-extremum checks, sixteen generic cases times eight fields, and two census checks: 16410 additions. Each actual sample value was matched exactly to its serialized row and to the original independently checked row. Every comparison's normalized error, threshold and pass Boolean were recalculated; expected-name sets and row counts were checked exactly. The 120 extrema are extrema over the supplied sites, not continuous extrema.

The new expected values were compared to the already preserved independent calculations. Maximum normalized discrepancy is 1.204e-12 for Hratio; the other seven fields differ by at most 5.17e-16. This reuses the reviewer's Bessel-EOS and closed-form geometry calculation without reintegrating unchanged histories. Its 2e-8 original serialization comparison scale is distinct from the parent's 3e-12 same-EOS readout comparison. The parent oracle's actual maximum normalized error is 6.063e-16.

The sixteen new fixtures use both branches, all four k values, Rstar=10 and two supplied nonzero velocities with differing temperatures. They were independently recomputed using the reviewer's previously pinned rational parameter construction, closed-form geometry, covariant energy and Bessel-K thermodynamics. The largest discrepancy against either serialized actual or expected field is 3.331e-16. This is a finite fixture test, not a general proof supplied by the pass count.

The five complete original scientific sections—scope, quadrature, histories, massless controls and variations—are exactly equal as parsed objects and have matching canonical hashes. All twenty individual result files match their full-result entries. All 13564 original non-source assertion objects, including numerical values and tolerances, are exactly unchanged. The independently reconstructed count is 29986 pass, zero fail for the parent v2 execution.

The reviewer's `independent_check_v2.py` produces 49593 passing record/identity/comparison checks and zero failed checks. These are mostly row-level bookkeeping and numerical comparisons; they must not be counted as 49593 independent scientific experiments. Execution took 2.60 seconds and all 38 source identities stayed unchanged at start and end.

## Repeated decisive source mutation

The sole mutation is exactly the original one:

    HJ2=H2*njp*njp/CB  ->  HJ2=H2/CB.

The mutant runner is SHA-256 `d9c26cf37d5f2fc795da017cdb0e954b9d3ce1b25b74f19887305e71a77e70f5`. All twelve copied input hashes were freshly computed after the edit. The complete mutated execution, source, inputs, all per-case output, stderr and timestamps are preserved in `same_clock_omission/`. No provenance mismatch is used as scientific rejection.

The mutant exits 1 after 86.98 seconds with 28770 passing and 1216 failing checks. Every failure is a new Hratio comparison: 1200 stored samples and all sixteen generic fixtures. All original non-source assertions still pass. All twenty state arrays are bitwise unchanged. The original maximum thermal readout change remains 0.0002832749850272265 on k=.01, b=a. Maximum new failed normalized error, including the deliberately nonzero-velocity generic fixtures, is 0.0009806286857756239.

The 1200 sample failures are the 100 noninitial sites in each of twelve massive-thermal histories, including refinements and scale variants. Massless histories remain insensitive at this threshold, as expected from their nearly unit physical clock. The generic failures demonstrate sensitivity independent of that exact-trajectory limitation. This is direct evidence that v2 catches the observed omission; it does not establish completeness against every possible correlated corruption of implementation and oracle.

## Unchanged limitations and final disposition

The same two SciPy finite-difference Jacobian overflow warnings remain byte-identical in v1, v2 and the mutant, SHA-256 `8f3602474bd26b7f57b6113d6d1d8901b03af8e229b313afef66b0845b02bec0`. The original review's passive-coordinate reproduction and distinct DOP853 comparison remain the evidence for their assessed scope. The six stronger unscaled-trace precision failures, the entropy-cooling mutation's 2496 failures, limited two-case parent refinement, supplied initial conditions and local-G_N bridge all remain in the immutable original report. None is removed by this repair.

There is no new empirical calibration, abundance prediction, likelihood, neutrino transport treatment, initial-history selection or global stability result. This correction adds a valid independent physical-clock/readout check to the already supplied finite calculations. No further correction is needed for the scoped v2 addition. `SOURCE_DISPOSITIONS_v2.json` gives every frozen source's identity, recovery and precise coverage; `FINAL_RECEIPT_v2.json` binds the full affected-source evidence without modifying the original receipt.
