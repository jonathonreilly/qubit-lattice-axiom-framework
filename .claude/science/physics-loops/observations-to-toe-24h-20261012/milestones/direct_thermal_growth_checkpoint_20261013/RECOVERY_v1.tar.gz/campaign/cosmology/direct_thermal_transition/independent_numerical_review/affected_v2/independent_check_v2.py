#!/usr/bin/env python3
"""Narrow v2 record/readout review. No parent helper import or positive run."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
import ast,copy,datetime,difflib,hashlib,importlib.util,itertools,json,math,sys
from collections import Counter
from pathlib import Path

A=Path(__file__).resolve().parent
P=A.parent
S=A/'source_snapshot'
CHECKS=[]
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def check(name,ok,**details):CHECKS.append(dict(name=name,passed=bool(ok),**details))
def close(name,got,wanted,tol):
    error=abs(got-wanted)/max(1.,abs(wanted))
    check(name,math.isfinite(error) and error<=tol,actual=float(got),expected=float(wanted),normalized_error=float(error),tolerance=tol)
def write(name,obj):
    with (A/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')
def allruns(r):
    return ([('histories',v) for v in r['histories']]+[('massless_controls',v) for v in r['massless_controls']]+[(v['kind'],v['run']) for v in r['variations']])

started=datetime.datetime.now(datetime.timezone.utc).isoformat()
freeze=load(A/'INPUT_FREEZE_v2.json')
before={r['source_path']:sha(r['source_path']) for r in freeze['sources']}
for i,r in enumerate(freeze['sources']):
    check(f'v2.source.{i}',before[r['source_path']]==r['sha256'])
    check(f'v2.snapshot.{i}',sha(r['snapshot_path'])==r['sha256'])
prior=load(P/'FINAL_RECEIPT_v1.json')
check('original.receipt_pin',sha(P/'FINAL_RECEIPT_v1.json')==freeze['original_review_receipt_sha256'])
for i,r in enumerate(prior['artifacts']):check(f'original.artifact.{i}',sha(r['path'])==r['sha256'])
for i,r in enumerate(load(P/'SOURCE_DISPOSITIONS_v1.json')['sources']):
    check(f'original.source.{i}',sha(r['original_path'])==r['original_sha256'])
    check(f'original.recovery.{i}',sha(r['recovery'])==r['recovery_sha256'])

r1=load(P/'source_snapshot/evidence_v1/RESULTS.json')
r2=load(S/'evidence_v2/RESULTS.json')
rm=load(A/'same_clock_omission/evidence/RESULTS.json')
science={}
for key in ['scope','quadrature','histories','massless_controls','variations']:
    science[key]=dict(v1_sha256=canon(r1[key]),v2_sha256=canon(r2[key]),exactly_equal=r1[key]==r2[key])
    check('science_identity.'+key,science[key]['exactly_equal'])
c1={v['name']:v for v in r1['checks'] if not v['name'].startswith('source.')}
c2={v['name']:v for v in r2['checks']}
cm={v['name']:v for v in rm['checks']}
check('old_non_source_census',len(c1)==13564)
check('old_non_source_objects_exact',all(c2.get(k)==v for k,v in c1.items()))
for label,r in [('original',r1),('v2',r2),('mutant',rm)]:
    check(label+'.counts',r['counts']==dict(passed=sum(v['passed'] for v in r['checks']),failed=sum(not v['passed'] for v in r['checks']),total=len(r['checks'])))
    check(label+'.unique_names',len({v['name'] for v in r['checks']})==len(r['checks']))
check('v2.positive_counts',r2['counts']==dict(passed=29986,failed=0,total=29986))
for i,(label,r) in enumerate(allruns(r2)):
    stem={'histories':'thermal','massless_controls':'massless'}.get(label,label)
    filename=f'{stem}.{r["parameters"]["k0"]}.{r["parameters"]["branch"]}.json'
    check(f'percase.{i}',load(S/'evidence_v2'/filename)==r)

old=(P/'source_snapshot/check_thermal_transition_v1.py').read_text()
new=(S/'check_thermal_transition_v2.py').read_text()
oldtree=ast.parse(old);newtree=ast.parse(new)
original_functions={n.name:ast.dump(n) for n in oldtree.body if isinstance(n,ast.FunctionDef)}
new_functions={n.name:ast.dump(n) for n in newtree.body if isinstance(n,ast.FunctionDef)}
for name,value in original_functions.items():
    if name!='main':check('ast.unchanged.'+name,new_functions.get(name)==value)
reduced=copy.deepcopy(newtree)
reduced.body=[n for n in reduced.body if not(isinstance(n,ast.FunctionDef) and n.name in ['independent_readout','additional_readout_controls'])]
main=next(n for n in reduced.body if isinstance(n,ast.FunctionDef) and n.name=='main')
def extra_call(n):
    return isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='additional_readout_controls'
check('ast.one_new_main_call',sum(extra_call(n) for n in main.body)==1)
main.body=[n for n in main.body if not extra_call(n)]
check('ast.entire_original_after_additions_removed',ast.dump(oldtree)==ast.dump(reduced))
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='v1',tofile='v2'))
check('exact_patch',diff==(S/'READOUT_CORRECTION_v2.diff').read_text())
mut=(A/'same_clock_omission/check_thermal_transition_v2.py').read_text()
check('same_single_mutation',new.count('HJ2=H2*njp*njp/CB')==1 and mut==new.replace('HJ2=H2*njp*njp/CB','HJ2=H2/CB'))

fix=load(S/'NUMERICAL_FIXTURES_v1.json');spec=load(S/'READOUT_FIXTURES_v2.json')
keys=['Hratio','GNratio','NJprime','Ku','F','J','T','Tnu']
added=[c for c in r2['checks'] if c['name'].startswith('readout.')]
expected_names=set();row_links=[];max_saved={k:0. for k in keys}
saved={c['name']:c for c in load(P/'INDEPENDENT_READOUT_v1.json')['checks']}
for i,(label,r) in enumerate(allruns(r2)):
    tag=f'{label}.{r["parameters"]["k0"]}.{r["parameters"]["branch"]}'
    for j,row in enumerate(r['samples']):
        for key in keys:
            name=f'readout.{i}.{j}.{key}';expected_names.add(name)
            c=c2[name];oldcheck=saved[f'{tag}.{j}.serialization.{key}']
            check('sample_binding.'+name,c['actual']==row[key] and c['actual']==oldcheck['got'])
            close('saved_independent_expected.'+name,c['expected'],oldcheck['wanted'],2e-8)
            max_saved[key]=max(max_saved[key],abs(c['expected']-oldcheck['wanted'])/max(1.,abs(oldcheck['wanted'])))
    for key in ['Hratio','GNratio','NJprime']:
        for which,fn in [('minimum',min),('maximum',max)]:
            name=f'readout.{i}.{which}.{key}';expected_names.add(name)
            c=c2[name]
            check('extremum_binding.'+name,c['actual']==r['sampled_extrema'][key][which] and c['expected']==fn(v[key] for v in r['samples']) and c['tolerance']==0.)
    row_links.append(dict(run=i,identity=tag,samples=len(r['samples'])))

# Reuse only reviewer-owned, hash-pinned, independently derived functions.
module_path=P/'independent_thermal_review_v1.py'
check('own_code_identity',sha(module_path)==next(v['sha256'] for v in prior['artifacts'] if v['relative_path']=='independent_thermal_review_v1.py'))
sp=importlib.util.spec_from_file_location('own_thermal_v1',module_path)
own=importlib.util.module_from_spec(sp);sp.loader.exec_module(own)
generic=[];i=0
for k,branch in itertools.product(fix['k_values'],fix['branches']):
    cfg=own.params(k,branch,spec['generic_R_star'])
    for v in spec['generic_cases']:
        state=[v['u'],v['ell'],v['p'],v['w'],math.log(v['T']),math.log(v['Tnu']),0.]
        wanted,margin=own.readout_from_stored(dict(state=state),cfg,False)
        check(f'generic_domain.{i}',margin>0 and wanted['NJprime']>0 and wanted['Ku']>0)
        for key in keys:
            name=f'readout.generic.{i}.{key}';expected_names.add(name)
            c=c2[name]
            close('independent_generic_actual.'+name,c['actual'],wanted[key],2e-8)
            close('independent_generic_expected.'+name,c['expected'],wanted[key],2e-8)
        generic.append(dict(case=i,parameters=cfg,state=state,independent={key:wanted[key] for key in keys},kinetic_margin=margin))
        i+=1
expected_names.update(['readout.sample_census','readout.generic_census'])
check('added_names_complete',expected_names=={c['name'] for c in added},expected_count=len(expected_names),actual_count=len(added))
check('sample_census',c2['readout.sample_census']['actual']==sum(len(r['samples']) for _,r in allruns(r2))==2020)
check('generic_census',i==16 and c2['readout.generic_census']['passed'])
for c in added:
    if 'actual' in c and 'expected' in c:
        er=abs(c['actual']-c['expected'])/max(1.,abs(c['expected']))
        check('comparison_record.'+c['name'],math.isfinite(er) and c['normalized_error']==er and c['passed']==(er<=c['tolerance']) and c['tolerance']==(0. if '.minimum.' in c['name'] or '.maximum.' in c['name'] else spec['stored_readout_tolerance']))

failed=[c for c in rm['checks'] if not c['passed']]
source_checks=[c for c in rm['checks'] if c['name'].startswith('source.')]
check('mutant.fresh_twelve_source_checks',len(source_checks)==12 and all(c['passed'] for c in source_checks))
for i,c in enumerate(load(A/'same_clock_omission/FROZEN_INPUTS.json')['inputs']):check(f'mutant.current_input.{i}',sha(c['path'])==c['sha256'])
check('mutant.scientific_rejection',len(failed)>0 and all(c['name'].startswith('readout.') and c['name'].endswith('.Hratio') for c in failed))
check('mutant.original_checks_pass',all(cm[k]['passed'] for k in c1))
check('mutant.exit_one',load(A/'same_clock_omission/EXECUTION.json')['exit_code']==1)
check('mutant.warning_preserved',sha(A/'same_clock_omission/evidence/stderr.txt')==sha(P/'source_snapshot/evidence_v1/stderr.txt'))
mutation_rows=[]
for i,((_,base),(_,mutant)) in enumerate(zip(allruns(r2),allruns(rm))):
    check(f'mutant.states_unchanged.{i}',[v['state'] for v in base['samples']]==[v['state'] for v in mutant['samples']])
    j=max(range(len(base['samples'])),key=lambda j:abs(base['samples'][j]['Hratio']-mutant['samples'][j]['Hratio']))
    mutation_rows.append(dict(run=i,k=base['parameters']['k0'],branch=base['parameters']['branch'],massless=base['massless'],worst_sample=j,absolute_change=abs(base['samples'][j]['Hratio']-mutant['samples'][j]['Hratio']),failed_sample_checks=sum(not cm[f'readout.{i}.{j}.Hratio']['passed'] for j in range(len(base['samples'])))))
mutation_detail=dict(counts=rm['counts'],failed_fields=dict(Counter(c['name'].split('.')[-1] for c in failed)),generic_failures=sum(c['name'].startswith('readout.generic.') for c in failed),sample_failures=sum(not c['name'].startswith('readout.generic.') for c in failed),rows=mutation_rows,maximum_failed_normalized_error=max(c['normalized_error'] for c in failed),failed_check_names=[c['name'] for c in failed])
execution=load(S/'evidence_v2/EXECUTION.json')
for name in ['stdout.txt','stderr.txt','RESULTS.json']:check('execution_binding.'+name,sha(S/'evidence_v2'/name)==execution[name]['sha256'])
check('execution_exit',execution['exit_code']==0 and execution['input_count']==12 and execution['inputs_unchanged'])
check('warning_unchanged',sha(S/'evidence_v2/stderr.txt')==sha(P/'source_snapshot/evidence_v1/stderr.txt'))
for i,r in enumerate(freeze['sources']):check(f'v2.input_unchanged_end.{i}',sha(r['source_path'])==before[r['source_path']])
counts=dict(passed=sum(c['passed'] for c in CHECKS),failed=sum(not c['passed'] for c in CHECKS),total=len(CHECKS))
result=dict(started_at=started,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_sha256=sha(__file__),freeze_sha256=sha(A/'INPUT_FREEZE_v2.json'),prior_receipt_sha256=sha(P/'FINAL_RECEIPT_v1.json'),parent_helpers_imported=False,parent_positive_reexecuted=False,science_sections=science,old_non_source_count=len(c1),new_readout_count=len(added),saved_independent_expected_maximum_errors=max_saved,record_links=row_links,generic_rows=generic,mutation=mutation_detail,checks=CHECKS,counts=counts)
write('INDEPENDENT_CHECKS_v2.json',result)
print(json.dumps({k:result[k] for k in ['counts','old_non_source_count','new_readout_count','saved_independent_expected_maximum_errors']},indent=2))
print(json.dumps({k:mutation_detail[k] for k in ['counts','generic_failures','sample_failures','maximum_failed_normalized_error']},indent=2))
raise SystemExit(int(counts['failed']!=0))
