#!/usr/bin/env python3
"""Preserve one execution of the independent affected-source checks."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
A=Path(__file__).resolve().parent
code=A/'independent_check_v2.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((A/'INPUT_FREEZE_v2.json').read_text())
before={r['source_path']:sha(r['source_path']) for r in freeze['sources']}
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
cmd=[sys.executable,'-B',str(code)]
record=dict(command=cmd,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),code_sha256=sha(code),wrapper_sha256=sha(__file__),input_hashes_before=before)
t=time.monotonic()
with (A/'independent_stdout_v2.txt').open('x') as out,(A/'independent_stderr_v2.txt').open('x') as err:
    result=subprocess.run(cmd,stdout=out,stderr=err,env=env,cwd=A)
record.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=result.returncode,input_hashes_after={p:sha(p) for p in before},code_hash_after=sha(code))
record['all_input_hashes_unchanged']=record['input_hashes_before']==record['input_hashes_after']
for name in ['INDEPENDENT_CHECKS_v2.json','independent_stdout_v2.txt','independent_stderr_v2.txt']:
    p=A/name
    if p.exists():record[name]=dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
with (A/'INDEPENDENT_EXECUTION_v2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print((A/'independent_stdout_v2.txt').read_text())
print((A/'independent_stderr_v2.txt').read_text())
print(json.dumps(dict(exit_code=result.returncode,all_input_hashes_unchanged=record['all_input_hashes_unchanged'],elapsed_seconds=record['elapsed_seconds'])))
raise SystemExit(result.returncode)
