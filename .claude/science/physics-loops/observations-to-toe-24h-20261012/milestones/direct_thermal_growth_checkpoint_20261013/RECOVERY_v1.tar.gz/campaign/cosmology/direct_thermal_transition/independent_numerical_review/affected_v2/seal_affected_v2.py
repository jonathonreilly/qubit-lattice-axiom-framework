#!/usr/bin/env python3
"""Finalize immutable affected-source review identities; no parent writes."""
from pathlib import Path
import datetime,hashlib,json
A=Path(__file__).resolve().parent
P=A.parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
    with (A/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
freeze=load(A/'INPUT_FREEZE_v2.json')
prior=load(P/'FINAL_RECEIPT_v1.json')
original_artifacts=[dict(path=r['path'],sha256=r['sha256'],unchanged=sha(r['path'])==r['sha256']) for r in prior['artifacts']]
assert all(r['unchanged'] for r in original_artifacts)
assert sha(P/'FINAL_RECEIPT_v1.json')==freeze['original_review_receipt_sha256']
inputs=load(A/'source_snapshot/evidence_v2/FROZEN_INPUTS.json')['inputs']
input_checks=[dict(path=r['path'],declared_sha256=r['sha256'],current_sha256=sha(r['path'])) for r in inputs]
assert len(inputs)==12 and all(r['declared_sha256']==r['current_sha256'] for r in input_checks)
frozen_by_path={r['source_path']:r for r in freeze['sources']}
assert all(frozen_by_path[r['path']]['sha256']==r['sha256'] for r in inputs)
original_sources=load(P/'SOURCE_DISPOSITIONS_v1.json')['sources']
assert all(sha(r['original_path'])==r['original_sha256']==sha(r['recovery']) for r in original_sources)
source_rows=[]
for r in freeze['sources']:
    assert sha(r['source_path'])==r['sha256']==sha(r['snapshot_path'])
    path=Path(r['source_path']);name=path.name
    if name=='check_thermal_transition_v2.py':
        coverage='Complete integrated source and exact diff read; all old AST retained; new raw-action/clock formulas independently derived; decisive full source mutation executed.'
    elif name in ['READOUT_FIXTURES_v2.json','READOUT_CORRECTION_v2.json','READOUT_CORRECTION_v2.diff','SCIENTIFIC_OUTPUT_IDENTITY_v2.json']:
        coverage='Complete new metadata read; fixture cases independently computed; stated source/prediction/check identities independently reconstructed.'
    elif name=='RESULTS.json' or name.startswith(('thermal.','massless.','refined.','scale.')):
        coverage='Complete JSON consumed; all old scientific sections match independently checked v1 exactly; every added numerical record and serialized row/extremum bound; per-case objects match.'
    elif 'evidence_v2' in path.parts:
        coverage='Complete execution/lineage record or output read; actual hashes, exit, census and unchanged warning independently checked.'
    else:
        coverage='Exactly unchanged prior numerical or handwritten premise; full prior review reused by hash, no new proof or authority inherited.'
    source_rows.append(dict(original_path=r['source_path'],original_sha256=r['sha256'],disposition='Unchanged; scoped v2 readout correction supported, with original failures and limits retained.',coverage=coverage,recovery=r['snapshot_path'],recovery_sha256=r['sha256'],final_path=r['source_path'],final_sha256=sha(r['source_path'])))
save('LINEAGE_CONFIRMATION_v2.json',dict(created_at=now,all_original_artifacts_unchanged=True,original_artifact_count=len(original_artifacts),original_artifacts=original_artifacts,original_source_count=len(original_sources),all_original_source_and_recovery_hashes_unchanged=True,v2_input_checks=input_checks,v2_input_count=len(inputs),all_v2_manifest_rows_match_review_freeze=True,source_count=len(source_rows),all_current_and_snapshot_hashes_match=True))
save('SOURCE_DISPOSITIONS_v2.json',dict(created_at=now,scope='Narrow separately versioned v2 affected-source review; supplements immutable original v1 map.',source_count=len(source_rows),author_input_count=len(inputs),original_dispositions_path=str(P/'SOURCE_DISPOSITIONS_v1.json'),original_dispositions_sha256=sha(P/'SOURCE_DISPOSITIONS_v1.json'),sources=source_rows))
result=load(A/'INDEPENDENT_CHECKS_v2.json');mut=load(A/'same_clock_omission/evidence/RESULTS.json')
receipt=dict(created_at=now,scope='Focused independent numerical/implementation affected-v2 check; not formal audit or empirical acceptance.',original_review_receipt_path=str(P/'FINAL_RECEIPT_v1.json'),original_review_receipt_sha256=sha(P/'FINAL_RECEIPT_v1.json'),report_path=str(A/'AFFECTED_READOUT_REVIEW_v2.md'),report_sha256=sha(A/'AFFECTED_READOUT_REVIEW_v2.md'),source_dispositions_path=str(A/'SOURCE_DISPOSITIONS_v2.json'),source_dispositions_sha256=sha(A/'SOURCE_DISPOSITIONS_v2.json'),source_runner_sha256=sha(A/'source_snapshot/check_thermal_transition_v2.py'),parent_result_sha256=sha(A/'source_snapshot/evidence_v2/RESULTS.json'),source_count=len(source_rows),executed_input_count=len(inputs),all_original_and_v2_identities_unchanged=True,science_sections_identical=result['science_sections'],original_non_source_checks_identical=13564,new_readout_checks=16410,sample_rows=2020,generic_cases=16,parent_counts=load(A/'source_snapshot/evidence_v2/RESULTS.json')['counts'],independent_counts=result['counts'],parent_positive_reexecuted=False,parent_helpers_imported=False,mutation=dict(kind='Same physical-clock velocity-factor omission as immutable v1 survivor',fresh_input_count=12,source_hash_checks_pass=True,exit_code=1,counts=mut['counts'],sample_failures=1200,generic_failures=16,runner_sha256=sha(A/'same_clock_omission/check_thermal_transition_v2.py'),result_sha256=sha(A/'same_clock_omission/evidence/RESULTS.json'),execution_sha256=sha(A/'same_clock_omission/EXECUTION.json')),finding='The observed v1 clock/readout control gap is closed in v2; scientific outputs unchanged. No further scoped correction needed.',limits_retained=['Original surviving mutation and entropy mutation failures remain immutable.','Six stronger unscaled-trace accuracy failures remain; no original barred-EOS gate was silently relaxed.','Identical SciPy Jacobian warnings remain; original independent assessment reused.','Finite synthetic rows and selected refinements only; no empirical abundance/likelihood or initial-history selection claim.','New raw-action readout oracle shares the separately checked EOS; it is not another independent EOS oracle.'])
artifacts=[]
for p in sorted(A.rglob('*')):
    if p.is_file() and p.name!='FINAL_RECEIPT_v2.json':
        artifacts.append(dict(path=str(p),relative_path=str(p.relative_to(A)),sha256=sha(p),bytes=p.stat().st_size))
receipt['artifact_count_excluding_this_receipt']=len(artifacts);receipt['artifacts']=artifacts
save('FINAL_RECEIPT_v2.json',receipt)
print(json.dumps(dict(report_sha256=receipt['report_sha256'],receipt_sha256=sha(A/'FINAL_RECEIPT_v2.json'),source_count=len(source_rows),artifacts=len(artifacts),all_original_and_v2_identities_unchanged=True),indent=2))
