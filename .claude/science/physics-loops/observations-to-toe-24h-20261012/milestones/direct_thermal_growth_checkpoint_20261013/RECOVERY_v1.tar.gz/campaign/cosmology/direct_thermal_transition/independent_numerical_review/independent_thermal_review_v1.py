#!/usr/bin/env python3
"""Independent Bessel thermodynamics and temperature-clock momentum evolution.

No parent implementation is imported. Frozen parent output is comparison data.
Each phase is executed once and preserves its own complete result.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
from fractions import Fraction
import argparse,datetime,hashlib,json,math,platform,warnings,inspect
import numpy as np
import scipy
from scipy.special import kve,expit
from scipy.integrate import quad,solve_ivp
from scipy.interpolate import CubicSpline

P=Path(__file__).resolve().parent
SRC=P/'source_snapshot'
FIX=json.loads((SRC/'NUMERICAL_FIXTURES_v1.json').read_text())
ORIG=json.loads((SRC/'evidence_v1/RESULTS.json').read_text())
CHECKS=[]
RG=math.pi**2/15
RN=7*math.pi**2/40
KEYS=['electron_density_bar','electron_pressure_bar','electron_trace_bar','heat_capacity_bar','entropy_bar','cT']
TABLE=None

def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def check(name,ok,**details):CHECKS.append(dict(name=name,passed=bool(ok),**details))
def close(name,got,wanted,tol):
    error=abs(float(got)-float(wanted))/max(1,abs(float(wanted)))
    check(name,math.isfinite(error) and error<=tol,got=float(got),wanted=float(wanted),normalized_error=error,tolerance=tol)
def save(name,obj):
    f=P/name
    f.parent.mkdir(parents=True,exist_ok=True)
    with f.open('x') as out:json.dump(obj,out,indent=2,allow_nan=False);out.write('\n')

def bessel(T):
    """Fermi fugacity expansion of grand pressure; analytic derivatives."""
    r=1/float(T)
    n=np.arange(1,max(16,int(math.ceil(55*T))+16)+1,dtype=float)
    arg=n*r
    signs=np.where(n.astype(int)%2,1.,-1.)
    decay=np.exp(-arg)
    k0=kve(0,arg)*decay;k1=kve(1,arg)*decay;k2=kve(2,arg)*decay
    s2=float(np.sum(signs*k2/n**2));s1=float(np.sum(signs*k1/n));s0=float(np.sum(signs*k0))
    pref=2/math.pi**2
    pe=pref*r*r*s2
    tr=pref*r**3*s1
    re=3*pe+tr
    heat=pref*(12*r*r*s2+5*r**3*s1+r**4*s0)+4*RG
    entropy=4*RG/3+re+pe
    return dict(zip(KEYS,[re,pe,tr,heat,entropy,3*entropy/heat]))

def shifted_energy_quad(T):
    """Scale out exp(-m/T) before adaptive kinetic-energy quadrature."""
    r=1/float(T);pref=2/math.pi**2*math.exp(-r)
    values=[]
    for kind in range(4):
        def integrand(e):
            E=e+r;p=math.sqrt(e*(e+2*r));d=1+math.exp(-E)
            occ=math.exp(-e)/d
            if kind==0:return E*E*p*occ
            if kind==1:return p**3*occ/3
            if kind==2:return r*r*p*occ
            return E**3*p*occ/d
        v,error=quad(integrand,0,np.inf,epsabs=1e-11,epsrel=3e-13,limit=250)
        values.append(pref*v)
    re,pe,tr,heat=values;heat+=4*RG;entropy=4*RG/3+re+pe
    return dict(zip(KEYS,[re,pe,tr,heat,entropy,3*entropy/heat]))

def load_table():
    global TABLE
    raw=json.loads((P/'EOS_TABLE_v1.json').read_text())
    TABLE={key:CubicSpline(raw['L'],[r[key] for r in raw['rows']]) for key in KEYS}

def thermal(T,Tnu,massless=False,use_table=True):
    if massless:
        re=7*math.pi**2/60;pe=re/3
        bars=dict(zip(KEYS,[re,pe,0.,4*(RG+re),4*(RG+re)/3,1.]))
    elif use_table and TABLE is not None and .01*(1-1e-13)<=T<=10*(1+1e-13):
        L=math.log(10/T);bars={k:float(v(L)) for k,v in TABLE.items()}
    else:bars=bessel(T)
    rpl=(RG+bars['electron_density_bar'])*T**4
    ppl=(RG/3+bars['electron_pressure_bar'])*T**4
    rn=RN*Tnu**4
    return dict(bars,rho=rpl+rn,pressure=ppl+rn/3,trace=bars['electron_trace_bar']*T**4,rho_pl=rpl,p_pl=ppl)

def phase_eos():
    rows=[]
    for T in FIX['quadrature_temperatures']:
        bs=bessel(T);ad=shifted_energy_quad(T)
        for key in KEYS:
            close(f'Bessel/adaptive.{T}.{key}',bs[key],ad[key],2e-11)
            if key.startswith('electron_'):
                rel=abs(bs[key]-ad[key])/abs(ad[key])
                check(f'positive-small-tail.{T}.{key}',bs[key]>0 and rel<2e-10,relative_error=rel)
        rows.append(dict(T=T,bessel=bs,adaptive=ad))
    for j,row in enumerate(ORIG['quadrature']):
        own=thermal(row['T'],row['T'],use_table=False)
        for key,value in row['computed'].items():close(f'parent_quadrature.{j}.{key}',value,own[key],2e-8)
        for key,value in row['reference'].items():close(f'parent_reference.{j}.{key}',float(value),own[key],2e-8)
    for T in [.05,.2,1.,10.]:
        h=1e-4
        def ent(delta):return bessel(T*math.exp(delta))['entropy_bar']
        deriv=(ent(-2*h)-8*ent(-h)+8*ent(h)-ent(2*h))/(12*h)
        bs=bessel(T)
        close(f'independent_entropy_derivative.{T}',deriv,bs['heat_capacity_bar']-3*bs['entropy_bar'],2e-9)
    # Use a distinct interpolated representation only in the independent ODE.
    grid=np.linspace(0,math.log(1000),3001)
    tab=[bessel(10*math.exp(-L)) for L in grid]
    save('EOS_TABLE_v1.json',{'method':'Analytic Bessel-K Fermi series; cubic interpolation in ln(10/T)','L':grid.tolist(),'rows':tab,'series_tail_exponent':55,'script_sha256':sha(__file__)})
    load_table()
    midpoints=[]
    for j in range(256):
        L=math.log(1000)*(j+.371)/256;T=10*math.exp(-L);direct=bessel(T)
        got={k:float(f(L)) for k,f in TABLE.items()}
        for key in KEYS:close(f'interpolation.{j}.{key}',got[key],direct[key],2e-9)
        # Algebraic entropy differentiation must agree with the cooling clock.
        invc=1-float(TABLE['entropy_bar'](L,1))/(3*got['entropy_bar'])
        close(f'interpolated_entropy_clock.{j}',invc,1/got['cT'],2e-8)
        midpoints.append({'L':L,'maximum_normalized_error':max(abs(got[k]-direct[k])/max(1,abs(direct[k])) for k in KEYS)})
    nodes=json.loads((SRC/'QUADRATURE_NODES_v1.json').read_text())['nodes']
    for key,row in nodes.items():
        x=np.array(row['x']);w=np.array(row['w'])
        check('nodes.dimension.'+key,len(x)==len(w)==int(key))
        check('nodes.order-and-nonnegative.'+key,bool(np.all(np.diff(x)>0) and np.all(w>=0)))
        for degree in range(7):close(f'nodes.moment.{key}.{degree}',float(np.dot(w,x**degree)),math.factorial(degree),2e-12)
    return dict(quadrature_rows=rows,interpolation_midpoints=midpoints,finite_initial_late_neutrino_ratio=(4*RG/3/bessel(10)['entropy_bar'])**(1/3))

def params(k,branch,Rstar):
    kk=Fraction(str(k));a=(1-kk)*(1+3*kk)/4;s=(1+kk)/(kk*(1-3*kk))
    return dict(k0=float(kk),a=float(a),s=float(s),b=float(a if branch=='equal' else kk),nu=FIX['nu'],Rstar=float(Rstar),branch=branch)

def geometry(u,l,cfg):
    a,b,s=cfg['a'],cfg['b'],cfg['s'];al=math.sqrt(a)
    E=math.exp(2*al*u);z=s*E;F=1+z;J=1+(1-3*a)*z
    y2=cfg['Rstar']*math.exp(2*l);D=1+2*(1+b)*y2/3
    ku=J/F**2;kl=(1+s)*b*y2/(3*F*D)
    du_ku=ku*2*al*z*((1-3*a)/J-2/F)
    du_kl=-2*al*z/F*kl;dl_kl=2*kl/D
    factor=(1+s)/F**2
    uconst=1.5*factor;urest=cfg['nu']*u*u/2*factor
    uy=b*(1+s)*y2/3*factor;uvac=1.5*s*E*E*factor
    potential=uconst+urest+uy+uvac
    gu=-4*al*z/F*(uconst+urest+uy)+cfg['nu']*u*factor+4*al/F*uvac
    gl=2*uy
    return dict(ku=ku,kl=kl,du_ku=du_ku,du_kl=du_kl,dl_kl=dl_kl,U=potential,gradient=np.array([gu,gl]),F=F,J=J,D=D,CB=(1+s)*E/F,ab=al/F,y2=y2)

def entropy_state(L,massless=False):
    T=10*math.exp(-L)
    bar=thermal(T,T,massless)['entropy_bar'];initial=thermal(10,10,massless)['entropy_bar']
    nj=L-math.log(bar/initial)/3
    tn=10*math.exp(-nj)
    return T,tn,nj,thermal(T,tn,massless)

def evaluate(L,state,cfg,kinit,massless=False):
    u,l,ru,rl=state;g=geometry(u,l,cfg)
    moment=np.array([ru,rl])*kinit
    velocity=moment/np.array([g['ku'],g['kl']])
    T,Tnu,nj,fluid=entropy_state(L,massless)
    density=g['CB']**2*cfg['Rstar']*fluid['rho'];pressure=g['CB']**2*cfg['Rstar']*fluid['pressure']
    trace=g['CB']**2*cfg['Rstar']*fluid['trace']
    kin=float(np.dot(moment,velocity));H2=2*(density+g['U'])/(3-kin)
    h=-(density+pressure)/H2-kin
    p,w=velocity;njprime=1+g['ab']*p
    if min(g['ku'],g['kl'],H2,3-kin,njprime)<=0:raise ValueError('Independent physical-domain failure')
    # Lowered Euler-Lagrange equation, not the author's expanded acceleration.
    metric_force=np.array([.5*(g['du_ku']*p*p+g['du_kl']*w*w),.5*g['dl_kl']*w*w])
    source=g['gradient']+np.array([g['ab']*trace,0.])
    dm=-(3+h)*moment+metric_force-source/H2
    rhs=np.r_[velocity,dm/kinit]/(fluid['cT']*njprime)
    Href=1+2*(1+cfg['k0'])*cfg['Rstar']*fluid['rho']/3
    obs=dict(N=nj-.5*math.log(g['CB']),state=[u,l+.5*math.log(cfg['Rstar']),p,w,math.log(T),math.log(Tnu),nj],T=T,Tnu=Tnu,Hratio=math.sqrt(H2/Href/g['CB'])*njprime,GNratio=g['CB']*(1+cfg['a']/g['J'])/(1+cfg['k0']),Ku=g['ku'],F=g['F'],J=g['J'],NJprime=njprime,fluid_trace_fraction=fluid['trace']/fluid['rho'],neutrino_temperature_ratio=Tnu/T,predicted_neutrino_temperature_ratio=Tnu/T,log_plasma_entropy_ratio=0.,log_neutrino_temperature_invariant=0.,kinetic_margin=3-kin)
    return rhs,obs,g,fluid,H2,h

def independent_history(cfg,rtol=2e-10,atol=2e-12,maxstep=.02):
    f=thermal(10,10);l0=.5*math.log(f['rho'])
    g=geometry(0,l0,cfg);kinit=np.array([g['ku'],g['kl']]);initial=np.array([0.,l0,0.,-2.])
    sol=solve_ivp(lambda L,state:evaluate(L,state,cfg,kinit)[0],(0,math.log(1000)),initial,method='DOP853',rtol=rtol,atol=atol,max_step=maxstep,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    rows=[evaluate(float(L),sol.sol(L),cfg,kinit)[1] for L in np.linspace(0,math.log(1000),101)]
    return dict(parameters=cfg,method='DOP853; temperature clock; scaled covariant momenta',success=sol.success,nfev=sol.nfev,samples=rows,rtol=rtol,atol=atol,max_step=maxstep)

def phase_histories():
    load_table();results=[]
    for k in FIX['k_values']:
        for branch in FIX['branches']:
            cfg=params(k,branch,FIX['R_star']);result=independent_history(cfg)
            save(f'own_histories/thermal.{k}.{branch}.json',result);results.append(result)
            print('Independent history',k,branch,result['nfev'],flush=True)
    variants=[]
    for case in FIX['refinement_cases']:
        cfg=params(case['k'],case['branch'],FIX['scale_variation_R_star']);r=independent_history(cfg)
        save(f'own_histories/scale.{case["k"]}.{case["branch"]}.json',r);variants.append(dict(kind='scale',run=r))
        cfg=params(case['k'],case['branch'],FIX['R_star']);r=independent_history(cfg,2e-11,2e-13,.01)
        save(f'own_histories/refined.{case["k"]}.{case["branch"]}.json',r);variants.append(dict(kind='refined',run=r))
        print('Independent refinements',case,flush=True)
    return dict(histories=results,variations=variants)

def readout_from_stored(row,cfg,massless):
    u,ell,p,w,lt,ltn,nj=row['state'];l=ell-.5*math.log(cfg['Rstar']);g=geometry(u,l,cfg)
    T=math.exp(lt);tn=math.exp(ltn);f=thermal(T,tn,massless,use_table=False)
    sig=g['CB']**2*cfg['Rstar']*f['rho'];norm=g['ku']*p*p+g['kl']*w*w
    H2=2*(sig+g['U'])/(3-norm);hgr=1+2*(1+cfg['k0'])*cfg['Rstar']*f['rho']/3
    clock=1+g['ab']*p;initial=thermal(10,10,massless,use_table=False)
    return dict(T=T,Tnu=tn,Hratio=math.sqrt(H2/hgr/g['CB'])*clock,GNratio=g['CB']*(1+cfg['a']/g['J'])/(1+cfg['k0']),Ku=g['ku'],F=g['F'],J=g['J'],NJprime=clock,fluid_trace_fraction=f['trace']/f['rho'],log_plasma_entropy_ratio=3*(lt-math.log(10))+math.log(f['entropy_bar']/initial['entropy_bar'])+3*nj,log_neutrino_temperature_invariant=ltn-math.log(10)+nj,neutrino_temperature_ratio=tn/T,predicted_neutrino_temperature_ratio=(f['entropy_bar']/initial['entropy_bar'])**(1/3)),3-norm

def phase_readout():
    load_table();runs=[]
    for label in ['histories','massless_controls']:
        for r in ORIG[label]:runs.append((label,r))
    for v in ORIG['variations']:runs.append((v['kind'],v['run']))
    coverage=[];maximums=[]
    for label,r in runs:
        cfg=r['parameters'];k=cfg['k0'];branch=cfg['branch'];tag=f'{label}.{k}.{branch}'
        check(tag+'.source_success',r['success'] and r['reached_endpoint'] and len(r['samples'])==101)
        percase={};allrows=[]
        if not r['massless']:
            filename=f'own_histories/{"scale" if label=="scale" else "thermal"}.{k}.{branch}.json'
            own=json.loads((P/filename).read_text())['samples']
        else:
            initial_density=thermal(10,10,True,use_table=False)['rho']
            own=[]
            for j in range(101):
                L=math.log(1000)*j/100;T=10*math.exp(-L);l=.5*math.log(cfg['Rstar']*initial_density)-2*L
                rr=dict(N=L,state=[0.,l,0.,-2.,math.log(T),math.log(T),L])
                obs,_=readout_from_stored(rr,cfg,True);own.append(dict(rr,**obs))
        for j,(row,expected) in enumerate(zip(r['samples'],own)):
            calculated,margin=readout_from_stored(row,cfg,r['massless'])
            for key,val in calculated.items():close(f'{tag}.{j}.serialization.{key}',row[key],val,2e-8)
            check(f'{tag}.{j}.kinetic_margin',margin>0,margin=margin)
            for key in ['N','Hratio','GNratio','NJprime','Tnu','neutrino_temperature_ratio']:
                close(f'{tag}.{j}.independent.{key}',row[key],expected[key],2e-6)
                percase[key]=max(percase.get(key,0.),abs(row[key]-expected[key])/max(1,abs(expected[key])))
            for i in range(7):
                close(f'{tag}.{j}.independent.state{i}',row['state'][i],expected['state'][i],2e-6)
                percase[f'state{i}']=max(percase.get(f'state{i}',0.),abs(row['state'][i]-expected['state'][i])/max(1,abs(expected['state'][i])))
            allrows.append({'sample':j,'independent_Hratio':expected['Hratio'],'parent_Hratio':row['Hratio'],'kinetic_margin':margin})
        for key,ext in r['sampled_extrema'].items():
            close(tag+'.minimum.'+key,ext['minimum'],min(x[key] for x in r['samples']),0.)
            close(tag+'.maximum.'+key,ext['maximum'],max(x[key] for x in r['samples']),0.)
        f=thermal(10,10,r['massless'],use_table=False);D=1+2*(1+cfg['b'])*cfg['Rstar']*f['rho']/3;J=1+(1-3*cfg['a'])*cfg['s']
        expectedp=-math.sqrt(cfg['a'])*(1+cfg['s'])*cfg['Rstar']*f['trace']/(J*D)
        expectedw=2*cfg['Rstar']*f['trace']/(3*D)
        close(tag+'.initial_pprime',r['initial_pprime'],expectedp,3e-9)
        close(tag+'.initial_wprime',r['initial_wprime'],expectedw,3e-9)
        coverage.append({'name':tag,'row_count':len(allrows),'rows':allrows,'maximum_independent_errors':percase})
        maximums.append({'name':tag,**percase})
    comparisons=[]
    for v in ORIG['variations']:
        r=v['run'];cfg=r['parameters'];base=next(t for t in ORIG['histories'] if t['parameters']['k0']==cfg['k0'] and t['parameters']['branch']==cfg['branch'])
        ownbase=json.loads((P/f'own_histories/thermal.{cfg["k0"]}.{cfg["branch"]}.json').read_text())
        ownv=json.loads((P/f'own_histories/{v["kind"]}.{cfg["k0"]}.{cfg["branch"]}.json').read_text())
        ownerr=max(abs(a['state'][i]-b['state'][i])/max(1,abs(b['state'][i])) for a,b in zip(ownv['samples'],ownbase['samples']) for i in [0,2,3])
        check('own_variation.'+v['kind']+str(cfg['k0']),ownerr<2e-6,maximum_error=ownerr)
        for j,(a,b) in enumerate(zip(r['samples'],base['samples'])):
            for key in ['Hratio','GNratio','neutrino_temperature_ratio']:close(f'recompute_{v["kind"]}.{cfg["k0"]}.{j}.{key}',a[key],b[key],2e-6)
            for i in [0,2,3]:close(f'recompute_{v["kind"]}.{cfg["k0"]}.{j}.state{i}',a['state'][i],b['state'][i],2e-6)
        comparisons.append({'kind':v['kind'],'k':cfg['k0'],'branch':cfg['branch'],'independent_variant_maximum_state_error':ownerr})
    # Consume every original check row; validate recorded numerical comparisons.
    numeric=0
    for j,c in enumerate(ORIG['checks']):
        check('original_flag.'+str(j),c['passed'])
        if 'actual' in c and 'expected' in c:
            numeric+=1;err=abs(c['actual']-c['expected'])/max(1,abs(c['expected']))
            check('original_comparison_record.'+str(j),err==c['normalized_error'] and c['passed']==(math.isfinite(err) and err<=c['tolerance']))
    check('complete_source_counts',ORIG['counts']=={'passed':13573,'failed':0,'total':len(ORIG['checks'])})
    for label,r in runs:
        prefix={'histories':'thermal','massless_controls':'massless'}.get(label,label)
        filename=f'{prefix}.{r["parameters"]["k0"]}.{r["parameters"]["branch"]}.json'
        check('case_file_identity.'+filename,json.loads((SRC/'evidence_v1'/filename).read_text())==r)
    return dict(coverage=coverage,maximum_independent_errors=maximums,variation_comparisons=comparisons,original_numerical_comparison_rows_consumed=numeric)

def phase_warning():
    import scipy.integrate._ivp.common as common
    source=Path(common.__file__);raw=source.read_bytes()
    (P/'scipy_common.py.snapshot').write_bytes(raw)
    y=np.array([1.,1.]);f=np.array([-1.,1.]);factor=None;records=[]
    def fun(t,yy):return np.array([-yy[0],np.ones_like(yy[0])])
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        for i in range(340):
            jac,factor=common.num_jac(fun,0,y,f,1e-11,factor)
            if i in [0,290,300,310,320,339]:records.append({'iteration':i,'jacobian':jac.tolist(),'factor':[float(x) if math.isfinite(x) else str(x) for x in factor]})
    msgs=[dict(category=x.category.__name__,message=str(x.message),filename=x.filename,lineno=x.lineno) for x in caught]
    check('passive_coordinate_warning_reproduced',any('overflow encountered' in x['message'] for x in msgs))
    check('passive_coordinate_jacobian_stays_finite',bool(np.all(np.isfinite(jac))))
    check('passive_coordinate_jacobian_correct',bool(np.allclose(jac,[[-1,0],[0,0]],atol=1e-8)))
    counts=[{'type':label,'k':r['parameters']['k0'],'branch':r['parameters']['branch'],'nfev':r['nfev'],'njev':r['njev']} for label in ['histories','massless_controls'] for r in ORIG[label]]
    return dict(scipy_common_path=str(source),scipy_common_sha256=hashlib.sha256(raw).hexdigest(),synthetic_records=records,warnings=msgs,parent_counts=counts,scope='Mechanism reproduction, not an instrumented attribution of every original warning. Parent NJ is a passive state coordinate absent from all RHS dependencies. Independent DOP853 uses no finite-difference Jacobian.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['eos','histories','readout','warning'],required=True);args=parser.parse_args()
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    expected=json.loads((P/'INPUT_FREEZE_v1.json').read_text())['sources']
    for x in expected:
        if x['author_frozen_input']:check('input_snapshot.'+Path(x['snapshot_path']).name,sha(x['snapshot_path'])==x['sha256'])
    detail=globals()['phase_'+args.phase]()
    result={'phase':args.phase,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(__file__),'input_freeze_sha256':sha(P/'INPUT_FREEZE_v1.json'),'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'author_helpers_imported':False,'checks':CHECKS,'counts':{'pass':sum(x['passed'] for x in CHECKS),'fail':sum(not x['passed'] for x in CHECKS)},'detail':detail}
    save('INDEPENDENT_'+args.phase.upper()+'_v1.json',result)
    print(json.dumps({'phase':args.phase,'counts':result['counts'],'failed':[x for x in CHECKS if not x['passed']][:15]},indent=2),flush=True)
    return int(result['counts']['fail']!=0)

if __name__=='__main__':raise SystemExit(main())
