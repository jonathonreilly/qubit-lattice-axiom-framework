#!/usr/bin/env python3
"""Record exact independent phase execution without replacing prior evidence."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent
phase=sys.argv[1]
dest=p/('RUN_'+phase+'_v1.json')
if dest.exists():raise FileExistsError(dest)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
freeze=json.loads((p/'INPUT_FREEZE_v1.json').read_text())
inputs=[dict(path=x['snapshot_path'],sha256=sha(x['snapshot_path'])) for x in freeze['sources']]
for f in [p/'independent_thermal_review_v1.py',p/'run_stage_v1.py',p/'INPUT_FREEZE_v1.json',p/'PRE_EXECUTION_PLAN_v1.json']:
    inputs.append(dict(path=str(f),sha256=sha(f)))
for f in [p/'EOS_TABLE_v1.json',*sorted((p/'own_histories').glob('*.json'))]:
    if f.is_file():inputs.append(dict(path=str(f),sha256=sha(f)))
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:env[key]='1'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.perf_counter()
cmd=[sys.executable,'-B',str(p/'independent_thermal_review_v1.py'),'--phase',phase]
with (p/('RUN_'+phase+'_v1.stdout.txt')).open('x') as out,(p/('RUN_'+phase+'_v1.stderr.txt')).open('x') as err:
    r=subprocess.run(cmd,cwd=p,env=env,stdout=out,stderr=err)
record={'command':cmd,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-tick,'exit_code':r.returncode,'inputs':inputs,'inputs_unchanged':all(sha(x['path'])==x['sha256'] for x in inputs),'stdout_sha256':sha(p/('RUN_'+phase+'_v1.stdout.txt')),'stderr_sha256':sha(p/('RUN_'+phase+'_v1.stderr.txt'))}
dest.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['command','elapsed_seconds','exit_code','inputs_unchanged']},indent=2))
raise SystemExit(r.returncode)
