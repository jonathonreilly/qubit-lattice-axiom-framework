# Frozen calculation and comparison scope

Parent implementation uses mpmath at 90 digits and SymPy for exact symbolic
identities. Fractions classify the supplied rational kinetic domains and
degenerate cases. Runtime input strings preserve fractions such as 1/3.
The primary calculation differentiates the original matter factor and kinetic
metric before introducing alpha, beta_D or the PPN response formulas.
Separate closed expressions and exact inverse substitutions supply controls.

The finite-coordinate test integrates the actual scalar line element to
find u(phi_0 +/- h), then differences ln G_N. Its three h values are fixed
in the protocol. The preliminary finite-grid checks demand normalized first-
and second-derivative errors <=100 h^2, and the second-derivative error must
decrease by at least a factor20 when h decreases by10, unless below1e-60.
These are explicit finite diagnostic thresholds, not proven global error
bounds. A failed threshold will remain visible and require diagnosis; it will
not change the handwritten exact identities by itself.

All excluded domain and inverse degeneracy rows are retained. Numeric output
uses80 significant digits, below the90-digit working precision but above the
1e-65 comparison accuracy. Record checks inspect the completed output
dictionaries before writing JSON, with independent review expected to inspect
the saved JSON and challenge the checks. No finite set of checks constitutes
a continuous parameter proof.

The PPN formulas are a stated primary-literature import. Both published
measurement summaries were already exposed; no data have been withheld.
They are used as separately labelled descriptive bands. No best fit,
combined probability, p-value or independent empirical validation is claimed.
The stationary-null family is intentionally designed from the response law.
Supplied compactness and H_v L/c values are dimensional applicability
diagnostics, not measured stellar bodies or instrument likelihoods.

First scientific execution will be capped at180 seconds. Preserve stdout,
stderr, source snapshots and the actual return code including failure.
