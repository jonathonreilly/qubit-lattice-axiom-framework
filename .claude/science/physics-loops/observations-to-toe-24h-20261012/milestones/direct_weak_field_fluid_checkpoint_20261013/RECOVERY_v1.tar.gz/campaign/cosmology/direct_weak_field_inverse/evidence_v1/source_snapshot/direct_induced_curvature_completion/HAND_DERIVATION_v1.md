# Direct induced-curvature completion — handwritten derivation v1

Parent /root, 2026-10-13. This is a new conditional candidate calculation,
not an observational fit, a measured coefficient, a radiative-stability
theorem, or a replacement for the checked analytic-fluid theorem.

## 1. Observation-led question and explicit extra premise

The earlier cosmological curve uses supplied matter/radiation densities and
a supplied positive H_v. The matter-vacuum block exposed the dependence on
the matter effective action. The auxiliary block compensates a constant
matter vacuum term under stated boundary conditions. Now test a further
allowed two-derivative matter-metric operator,
ζ/2 integral sqrt(-g_J) R_J. ζ is a supplied real coupling with mass dimension
two; no loop coefficient or phenomenological estimate is computed here.

Use the prior three-field K,V,A exactly, A=exp(sqrt(a)u), a,nu,H_v>0.
Keep the prior real, noncompact three-forms and finite boundary-sector
premises. q>0 and Lambda are integration constants after the form equations,
rho is a constant Jordan vacuum energy, and Ltilde=Lambda+rho.
ζ is independent of q,Lambda,rho. It is not varied by the q constraint.
Retain only the constant and Ricci terms of the matter effective action:
higher curvature/derivative operators and internal gravity/scalar loops
are outside this calculation. Boundary terms required by the metric
variational problem are stipulated, not proved to exist for arbitrary data.

Set alpha=sqrt(a), d=ζ A², F=q+d, C=Ltilde/(2q). Under g_J=A²g,
integration by parts gives

    (ζ/2) sqrt(-g_J) R_J
      = sqrt(-g)[ d R/2 + 3 a d (∂u)² ] + divergence.

The reduced bulk action, after dq=dLambda=0, is

    sqrt(-g)[ F R/2 - Z_AB ∂phi^A ∂phi^B
              - 2q V - Ltilde A⁴ ] + matter_ex,
    Z_AB = q K_AB - 3 a d delta_Au delta_Bu.

The sign of the added scalar derivative term alone is not the sign of the
propagating scalar energy: it mixes with the nonconstant Ricci coefficient.

## 2. Tensor and scalar kinetic domain

Require F>0. In a fixed q sector choose ghat=(F/q)g; this choice is made
after varying q and cannot be used to discard its original constraint.
The normalized action is q[Rhat/2-Khat_AB ∂phi^A∂phi^B-2 Vhat], where

    z=d/q=(ζ/q) exp(2alpha u), s=ζ/q,
    Khat_uu = [1+(1-3a)z]/(1+z)²,
    Khat_xx = K_xx/(1+z), Khat_yy = K_yy/(1+z),
    Vhat = [V+C A⁴]/(1+z)²,
    g_J = B² ghat, B=A/sqrt(1+z).

Indeed Khat=Z/F+(3/4) d(ln F) tensor d(ln F).
The full positive local two-derivative kinetic domain is

    1+z>0,    J:=1+(1-3a)z>0.

For z>=0 it holds for all z when 0<a<=1/3; for a>1/3 require
z<1/(3a-1). For negative z, F>0 (z>-1) already implies J>0.
Equality is a degenerate kinetic surface, not a positive-energy point.

At a constant background the scalar matter-coupling norm and tensor
coupling, relative to the prior q-normalized tensor coefficient, are

    alpha_eff² = (∂u ln B)²/Khat_uu = a/J,
    G_T,J / [1/(8pi q)] = B² = exp(2t)/(1+z), t=alpha u.

If the scalar is light on the measured length scale and ordinary weak
sources obey the universal matter premise, the usual local scalar
exchange additionally multiplies G_T,J by (1+alpha_eff²). No measured
Newton constant has been fitted here.

## 3. Form constraints and the trace

The form equations still give dLambda=0 and q dq=0. Their algebraic
equations remain

    F4=mu_aux⁴ A⁴ vol_g,
    Fhat4=-M_aux⁴ L0 vol_g/q,
    L0=R/2-K_AB ∂phi^A∂phi^B-2V.

The new Ricci term has no explicit q dependence in the original frame.
The constant compensation map rho->rho+delta, Lambda->Lambda-delta
therefore remains exact: all local fields and forms stay fixed and the
action changes by -delta integral(F4)/mu_aux⁴, a sector constant.
This is a finite fixed-sector classical statement. It is not a proof
about flux sums, quantization, path-integral measures, or infinite actions.

Let Q=K_AB ∂phi^A∂phi^B and Q_Z=Z_AB ∂phi^A∂phi^B.
After dq=0, tracing the metric equation gives

    F R = 2 Q_Z + 8q V + 4 Ltilde A⁴ - T_ex + 3 box F.

Thus the original auxiliary integrated-trace formula cannot simply be
reused when u varies. In particular,

    q L0 = -q d Q/F - 3q a d (∂u)²/F
           + 2q(q-d)V/F + 2q Ltilde A⁴/F
           - q T_ex/(2F) + 3q box F/(2F).

The finite flux ratio still fixes Bflux=integral(L0 vol_g)/
integral(A⁴ vol_g), with the same signed normalization as before.
The box-F term and field-dependent weights must be kept on a general
history. No extension of the old exact fluid orbit is asserted.

## 4. Constant vacua under the imposed future-ratio condition

Set x=y=0, constant u, no extra matter. Impose as an additional boundary
input b=Bflux/H_v², using a finite constant-vacuum region or the same
specified regulated ratio as before. Do not identify it with one finite
fixed-flux sector of an infinite history.

Write ell=nu/a, t=alpha u, v=3/2+ell t²/2, c=C/H_v²,
z=s exp(2t). The metric and scalar equations are

    R/H_v² = 8[v+c exp(4t)]/(1+z),
    ell t + 4c exp(4t) - z R/(2H_v²) = 0.

Eliminating c gives

    c exp(4t) = z v - ell t(1+z)/4,
    H_g²/H_v² = 1+ell(t²/3-t/6),
    b(t) = [3+ell(t²-t)] exp(-4t).

The last two expressions coincide with the earlier expressions as
functions of t, despite the changed action. This cancellation concerns
constant stationary vacua only. It is not a nonrenormalization theorem.

For imposed b=3, the possible t values are unchanged. At the origin,

    t=0, c=3s/2, Ltilde=3ζ H_v²,
    H_J=H_v, G_T,J/[1/(8pi q)]=1/(1+s).

The residual integration constant has shifted. It is not still zero.
If instead c is held at zero, the origin is not stationary for s≠0;
on the branch through s=0, t=(6/ell)s+O(s²).
These are different boundary/parameter questions.

At any stationary root, physical H_J=H_g exp(-t), while
Hhat=H_g/sqrt(1+z). The chosen positive expanding branch is used.

## 5. Local canonical Hessian and changed branch classification

Hold q,Lambda,rho,ζ fixed when taking local Hessians. These are local bulk
mass signs; they are not a stability theorem for a constrained finite
boundary-value problem. At a stationary point covariant Hessians equal
ordinary Hessians. With the canonical ghat normalization,

    mhat_u²/H_v² =
      { nu(1-4t) + z[nu(1-6t)+8a v] } / [(1+z)J],
    mhat_x²/H_v² =
      [9/4-9t/(2a)+9t²/a²]/(1+z),
    mhat_y²/H_v² = 2/(1+z).

To check the u expression directly, let w=v+c exp(4t) and
f=w/(1+z)². At stationarity,

    f_tt = {ell(1-4t)+z[ell(1-6t)+8v]}/(1+z)³,
    mhat_u²/H_v² = a f_tt / Khat_uu.

Physical constant-background mass squares are m_J²=mhat²/B².
At the origin,

    m_J,u²/H_v² = [nu(1+s)+12a s]/[1+(1-3a)s].

Even with positive kinetic energy, a sufficiently negative s can make this
negative: the extra local-Hessian requirement is s>-nu/(nu+12a).
For s>=0 it is positive at the origin throughout the kinetic domain.

For a nonzero b=3 root t>1, the old u-Hessian was negative. Now define
P=nu(1-6t)+8a v. If P>0 and z>nu(4t-1)/P within the kinetic domain,
the u-Hessian becomes positive. The x and y Hessians are already positive.
This gives a directly testable possible failure of the earlier unique
positive-Hessian branch statement once the extra operator is admitted.
That earlier statement had ζ=0 as a premise and is not contradicted.

The old global homogeneous convergence proof cannot be imported. For
s>0 and a<1/3, Vhat tends to C/s² as u->+infinity with x=y=0,
and the ghat scalar distance to that end is finite since
Khat_uu is asymptotic to (1-3a)/(s exp(2alpha u)).
The old coercive energy sublevels are therefore not supplied by this
modified potential. This observation is not a new global runaway theorem.

## 6. Neighboring flux response at fixed s

On the branch through t=0, b=3+epsilon, the implicit derivative is still

    t_epsilon = -1/(ell+12),
    c_epsilon = [ell(1+s)+12s]/[4(ell+12)],
    (H_J/H_v)_epsilon = 1/12,
    (G_T,J/[1/(8pi q)])_epsilon = -2/[(ell+12)(1+s)²].

The last expression is an absolute derivative about 1/(1+s).
The relative G derivative is -2/[(ell+12)(1+s)].
The expansion response does not by itself identify ζ or its gravity effect.

## 7. Scope and next checks

All scales, K,V,ideal matter interpretation and the future ratio are
supplied assumptions. No new empirical likelihood is used. Calibration
and previously exposed development data remain unchanged. These controls
will compare independent action differentiation, frame transformations,
root enumeration and physical observables on a frozen synthetic grid.
They cannot establish a TOE, solve the absolute scale problem, select an
observed branch, or establish quantum consistency.

Next: independent handwritten/action check; parent implement and freeze
symbolic/numerical controls, including degeneracies/ghost rejection,
a positive-kinetic negative-mass example, and a possible second
positive-Hessian vacuum. Preserve any algebra failure in a new version.

