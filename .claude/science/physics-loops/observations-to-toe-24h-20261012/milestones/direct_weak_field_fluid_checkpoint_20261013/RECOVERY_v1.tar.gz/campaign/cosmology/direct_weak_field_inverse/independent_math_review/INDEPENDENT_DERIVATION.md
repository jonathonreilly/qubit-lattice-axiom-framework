# Independent derivation of the local weak-field inverse

Scope: frozen handwritten weak-field inverse, its two scope corrections, the fixed-theory null-curvature addendum, and the finite canonical-distance addendum. All versions and protocols are separately snapshotted. The supplied action and mass formulas are reused only at the exact previously checked induced-curvature source SHA-256 `b37f6a0bf03a9a178c638266f4d6cffedce4150ed89c03ab6416a71c21ac225e`. No author numerical function is imported or executed. This check does not derive the complete post-Newtonian machinery or validate its empirical application outside the expressly assumed regime.

## Conditional physical reduction

Take q>0, a>0, t=sqrt(a)u, z=(zeta/q)exp(2t), F/q=1+z and J=1+(1-3a)z. Positive two-derivative tensor/scalar kinetic terms require 1+z>0 and J>0. The local Einstein-frame scalar metric and matter factor on x=y=0 are

    K_uu=J/(1+z)²,   B²=exp(2t)/(1+z).

The transverse restriction is consistent at the level needed here: partial_x K_uu=partial_y K_uu=0, so Gamma^x_uu=Gamma^y_uu=0; partial_x ln B=partial_y ln B=0; and the supplied potential has partial_x V=partial_y V=0 at x=y=0. Thus u motion and ordinary universal matter do not source a transverse field starting on this sector. This does not eliminate transverse fluctuations or nonlinear, environmental or compact-body phenomena from the full theory.

Define the dimensionless Damour-normalized coordinate by dphi/du=sqrt(J)/(1+z), choosing the positive orientation. The kinetic action is q/2 [Rhat-2(partial phi)²]. This matches the imported long-range tensor-scalar convention with G_*=1/(8 pi q). It is not the dimensionful coordinate sqrt(2q)phi; all derivatives below use the stated dimensionless convention.

The imported bridge requires universal metric matter, an almost constant local background, negligible apparatus-scale cosmological curvature and scalar mass, weak self-gravity, and a controlled PPN expansion. Holding the auxiliary constants fixed locally is also a premise; compatibility with a complete fixed-flux boundary problem is not established by this calculation. The bridge and its convention were checked against the primary introduction and equations (1.1), (1.3), (1.4) of [Damour and Esposito-Farese](https://arxiv.org/pdf/gr-qc/9602056v1). Their treatment also distinguishes weak-body responses from potentially nonperturbative compact-body behavior.

## Couplings and inverse identifiability

At fixed a,s=zeta/q,

    d ln B/du=sqrt(a)/(1+z),
    dz/du=2sqrt(a)z,
    d/dphi=[2sqrt(a)z(1+z)/sqrt(J)] d/dz.

Consequently

    alpha=d ln B/dphi=sqrt(a)/sqrt(J),
    k=alpha²=a/J,
    beta_D=dalpha/dphi=-a(1-3a)z(1+z)/J².

The derivative beta_D is neither a PPN beta deviation nor the action's Ricci coefficient zeta. A sign reversal of the scalar-coordinate orientation reverses alpha but leaves k and beta_D unchanged; the chosen orientation fixes the displayed alpha sign.

Solving k[1+(1-3a)z]=a gives

    a=k(1+z)/(1+3kz),   J=(1+z)/(1+3kz),
    beta_D=-k(1-3k)z.

Thus, for k>0 and k not equal to 1/3,

    z=-beta_D/[k(1-3k)].

Physical reconstructed points additionally require 1+z>0 and 1+3kz>0. For 0<k<1/3, these reduce to z>-1; for k>1/3, to z>-1/(3k), which is stronger than z>-1. Equality is excluded. This physical-domain check must precede interpretation of a rational inverse value.

An independent local-identifiability check is the forward Jacobian:

    det partial(k,beta_D)/partial(a,z)
      =-a(1-3a)(1+z)²/J⁴.

It is nonzero throughout the positive domain except a=1/3. At k=1/3,

    3a-J=(3a-1)(1+z)=0,

so a=1/3, J=1 and beta_D=0 for every z>-1. This is a real inverse degeneracy; if k=1/3 but beta_D is nonzero, there is no point of this model. At k=0 no finite a>0 and finite positive J point exists. Small k alone does not force every PPN response to be small if beta_D grows without bound. The source already warns against using small k as the only weak-source validity condition.

Even away from the degeneracies, k and beta_D identify only a and the local product z=s exp(2t). They do not separately identify the background field t and s. The origin specialization t=0 is an additional background choice, not information extracted from two response summaries. Other quantities in the potential and the cosmological/flux boundary history remain unmeasured by this inverse.

## PPN observables and the physical gamma domain

Under the imported bridge,

    delta_gamma=-2k/(1+k),
    delta_beta=beta_D k/[2(1+k)²],
    eta=4 delta_beta-delta_gamma
       =2k[(1+k)+beta_D]/(1+k)²,
    G_N=B²(1+k)/(8 pi q).

The relation eta=4beta-gamma-3 assumes the other potentially relevant PPN parameters vanish in this restricted metric scalar-tensor setting; it is not a universal identity for arbitrary gravitational models.

For finite k>0, delta_gamma lies strictly in (-2,0). In that interval,

    k=-delta_gamma/(2+delta_gamma),
    beta_D=2(1+k)² delta_beta/k,
    z=-2(1+k)² delta_beta/[k²(1-3k)].

If eta is supplied instead, delta_beta=(eta+delta_gamma)/4. The observable Jacobian det partial(delta_gamma,eta)/partial(k,beta_D)=-4k/(1+k)⁴ is nonzero at finite positive k. However, the inverse z sensitivity to delta_beta scales as k^-2 near the GR boundary, and also diverges near k=1/3. No numerical precision can remove these intrinsic identifiability limits.

The original handwritten wording said only 'for a negative delta_gamma'. That was too broad as a physical inverse claim: delta_gamma=-2 is singular and delta_gamma=-3 returns k=-3. The parent preserved v1 and corrected precisely this domain statement in v2. The algebra itself did not change.

At the tuned origin, the prior action requires C/H_v²=3s/2 to have H_J=H_v. If G_N is then used to normalize the weak-body gravitational strength,

    q=(1+k)/[8 pi G_N(1+s)],   zeta=sq.

This is a conditional normalization relation, not a derivation of a measured G_N or of the origin choice. For fixed k<1/3 and s->infinity, a->1/3 from below, q->0 and zeta tends to (1+k)/(8 pi G_N). Every finite model still requires q>0. Moreover the origin scalar mass grows with s, so a literal large-s limit at fixed nonzero H_v and apparatus length cannot silently inherit a light-scalar PPN approximation. The source's separate mass/range condition remains necessary.

## Exact eta-null family and fixed-theory differentiation

For 0<k<1/3 set

    z_null=(1+k)/[k(1-3k)],
    a_null=(1-k)(1+3k)/4.

Direct substitution gives beta_D=-(1+k), eta=0 and delta_gamma=-2k/(1+k) not equal to zero. The domain holds: z_null>0, a_null>0, and J=a_null/k>0. This is a response cancellation, not absence of scalar coupling. For k>1/3 the same formal eta-null z lies below -1/(3k), so it is outside the positive domain; k=1/3 has beta_D=0 and eta=1/2. These boundary observations follow directly from the same inverse inequalities.

At fixed a,s,q, differentiation of the actual local coefficient, rather than a reconstruction curve, gives

    ln G_N=2 ln B+ln(1+k)-ln(8 pi q),
    k'=2alpha beta_D,
    d ln G_N/dphi=2alpha[1+beta_D/(1+k)],
    eta=alpha/(1+k) d ln G_N/dphi.

A path artificially holding k fixed discards k' and produces 2alpha instead, missing the cancellation. That path generally changes the theory parameters. The null point does not require phi_dot=0; within this local formula it makes instantaneous G_N-dot vanish for any finite scalar velocity. No finite observation or time history is supplied by this derivative identity.

The parent null-curvature addendum is independently confirmed with a route through the original local z coordinate. Put c_a=1-3a and keep a fixed. Apart from constants,

    G_N(z) proportional to z(J+a)/[(1+z)J],
    d ln G_N/dz=1/[z(1+z)]-a c_a/[J(J+a)].

At a stationary point, the scalar-coordinate curvature is (dz/dphi)² times the second z derivative, since the term proportional to the first derivative vanishes. Differentiating before imposing the null relation gives

    d² ln G_N/dphi²=8(1-kz)=-32k/(1-3k)<0.

A separate two-variable chain-rule calculation using beta_D=-k(1-3k)z gives the signed intermediate identity

    beta_D'=-2sqrt(k)(1+k)(7+3k)/(1-3k)

at the null point, and reproduces the same curvature. Therefore it is a strict local maximum, with

    ln[G_N(phi0+delta_phi)/G_N(phi0)]
       =-16k/(1-3k) delta_phi²+O(delta_phi³).

This Taylor statement is local inside the scalar-coordinate domain. It is not a finite-time G-dot constraint or a cosmological trajectory.

## Origin mass and local range

The exact prior fixed-constant origin Hessian is

    m_J,u²/H_v²=[nu(1+s)+12as]/[1+(1-3a)s].

Using a/J=k and (1+s)/J=1+3ks gives

    m_J,u²/H_v²=nu+3ks(nu+4).

On the null origin family s=z_null>0, this is positive for nu>0. The transverse physical mass squares/H_v² remain 9/4 and 2. These are local fixed-integration-constant Hessians; they do not imply global attraction or stability in a constrained fixed-flux problem. Use of the long-range bridge separately requires sqrt(m_J,u²/H_v²)H_v L/c much smaller than one and the corresponding time-scale control. Merely finding a positive mass is not a successful range check.

## Finite scalar-coordinate endpoint

For z>0 and 0<a<1/3 let c_a=1-3a>0. The line element gives

    dphi/dz=sqrt(1+c_a z)/[2sqrt(a) z(1+z)].

The remaining distance to z=infinity is a positive convergent integral. With r=1/sqrt(z), reversing the limits gives

    Delta_phi=1/sqrt(a) integral from 0 to 1/sqrt(z)
                              sqrt(r²+c_a)/(1+r²) dr.

An independent substitution Y=sqrt(1+c_a z) instead gives the positive tail integral

    Delta_phi=(c_a/sqrt(a)) integral from Y to infinity
                     w²/[(w²-1)(w²-3a)] dw
             =1/sqrt(a) integral from Y to infinity
                     [1/(w²-1)-3a/(w²-3a)] dw.

Evaluation produces exactly

    Delta_phi=[atanh(1/Y)-sqrt(3a)atanh(sqrt(3a)/Y)]/sqrt(a).

Its derivative with respect to the lower Y limit is negative the positive line element, and it vanishes at infinity. Both atanh arguments lie in (0,1) on the stated domain. For fixed a and large z, Delta_phi~sqrt[(1-3a)/(az)].

At the null family, J=a/k and hence

    Delta_phi=atanh(sqrt(k/a))/sqrt(a)-sqrt(3)atanh(sqrt(3k)).

Expanding in h=sqrt(k), with a=(1-k)(1+3k)/4, gives

    Delta_phi=sqrt(k)[1-(17/3)k+(211/15)k²+O(k³)].

In particular the stated leading coefficient is exactly one. Independent quadratures give Delta_phi=0.000099999994333333474 at k=1e-8, and 0.000999994333347399964 at k=1e-6. A positive absolute scalar step .001 is unavailable at either point. The parent's reported first-run failure is therefore consistent with a real coordinate-domain limitation, not a reason to loosen root tolerances. I did not inspect or execute that parent run.

For these null points a<1/3,z>0 and the opposite z->0 end is at infinite negative scalar distance. A two-sided step h=f Delta_phi with 0<f<1 is therefore inside this sector's scalar-coordinate domain. The revised fractions .01,.001,.0001 are admissible. The proposed central first and second Taylor residuals h²f'''/6 and h²f''''/12 follow for a smooth f inside the domain; a relative residual check requires its selected leading coefficient to be nonzero. This handwritten check does not certify the parent's actual derivative implementation or convergence-test code.

## Exposed historical rectangles

The primary Cassini publisher abstract gives the frozen gamma-minus-one mean and uncertainty, 2.1e-5 and 2.3e-5. Direct page access failed in this review, while its indexed publisher abstract was retrievable. No raw Doppler likelihood was reviewed. [Primary publisher record](https://www.nature.com/articles/nature01997).

The primary lunar paper constructs eta=(4.4+/-4.5)e-4 from LLR, a laboratory composition comparison and self-energy modeling, then uses Cassini gamma to derive its beta estimate. That derived beta is not another independent input. The current block also reuses the campaign's earlier lunar information. The full scientific text through conclusions was checked for this lineage, without reprocessing ranges. [Primary lunar paper](https://arxiv.org/pdf/gr-qc/0411113v2).

For the frozen Cassini n=1,2,3 rectangles, write Delta=n sigma_gamma-mu_gamma. These inputs satisfy 0<Delta<2, so physical k obeys

    0<k<=Delta/(2-Delta).

The exact upper bounds are 1/999999, 1/79999 and 3/124997, respectively. The supplied k=1e-5 is outside the first, inside the second and third. The parent corrected that wording in v2. A generic formula for arbitrarily broad bands would need separate Delta>=2 cases; no such case occurs in this frozen n=1,2,3 scope.

For fixed k<1/3, put E=2k/(1+k) and D_k=2k²(1-3k)/(1+k)²>0. Since eta=E-D_k z, an eta interval [eta_lo,eta_hi] maps to

    (E-eta_hi)/D_k <= z <= (E-eta_lo)/D_k,

then must be intersected with the strict domain z>-1. For k=1e-5 all three raw lower bounds lie below -1. The corresponding physical upper bounds on a are approximately 0.2727312396, 0.3287674836 and 0.3309610425. These are conditional eta-band slices at a supplied k, not joint fitted estimates. In particular the first slice has no joint Cassini membership at this k.

The seven frozen diagnostic z values produce eta membership counts 5,6,6 for n=1,2,3; their joint rectangle counts are 0,6,6. All 21 rows, including the failures, are retained. The null designs have eta=0 by construction, which lies in the stated eta rectangles; their gamma condition still has to be checked separately. No Gaussian combination, independent-test count, posterior probability or global blind claim is justified by these rectangle calculations.

## Independent numerical route and its limits

The main independent calculation uses exact Fraction classification of all 80 forward and 64 inverse grid rows, exact symbolic identities and Jacobians, six exact null designs and three masses per design, and all 21 historical diagnostic membership rows. It also integrates the scalar line element between fixed u endpoints to compare finite log-G contrasts to the local fixed-theory derivative. These are u steps, not the parent's fixed absolute phi steps; the resulting scalar widths shrink with the geometry and remain in the domain. Thirty contrast rows show maximum errors 1.649e-7,1.649e-9,1.649e-11 for u steps .001,.0001,.00001 in these fixtures. Direct numerical differentiation and scalar-coordinate chain conversion also check all six null curvatures.

The distance check evaluates a positive rational Y-tail integral independently of the parent's regular-r integration, compares both to the elementary expression, and checks nine points including all six null fixtures. Maximum disagreement is below 9.90e-91 at 90-digit precision. Exact signed supplementary identities prevent a squared beta-prime magnitude check from hiding its sign.

Final successful stages contain 405,46 and 3 passing assertions, respectively, with no scientific assertion failure. Reviewer syntax and evidence-serialization failures, plus an early summary-read failure, remain preserved with their exact source versions and records. These finite controls strengthen the handwritten checks; they do not certify a parent numerical runner, a new likelihood, or the assumed physical bridge.
