# Focused independent weak-field inverse review

The handwritten algebra checks out within the stated positive-kinetic, universal weak-body, long-range PPN regime. Two wording issues in the original note were reported and corrected in the separately preserved v2: the physical gamma inverse requires -2<gamma-1<0, and the k=1e-5 illustration is outside the one-uncertainty Cassini band while inside the two- and three-uncertainty bands. No remaining equation correction is requested. The subsequently added null-curvature and finite-distance derivations also check out.

This is an independent handwritten/action/inverse check, not a formal audit, a retained status, a review of the parent's numerical implementation, or an empirical acceptance result. The parent remains the scientific author. `INDEPENDENT_DERIVATION.md` gives the complete derivation and the scope of every calculation.

## Exact source scope

The initial three inputs were frozen before checking at 2026-10-13T07:41Z: full `HAND_DERIVATION_v1.md` (SHA-256 `be32c0394625ed6a246a81cf2b87ed842e2edac49d0afe974dbe129af1df71c2`), `PROTOCOL_v1.json` and `OBSERVATION_INPUTS_v1.json`. All were fully read. The exact prior induced-curvature handwritten source and its completed review receipt were checked before reuse; no broader prior conclusion was inherited.

During the review the parent added, and I separately froze/read:

- `HAND_DERIVATION_v2.md`, SHA-256 `d7a2c1a8d8a955037d2324b77a94fbe7a974f646696765de6ae4ad190519b65b`, with the exact correction diff and record;
- `NULL_CURVATURE_ADDENDUM_v1.md`, SHA-256 `87e5a73fb04937b309905c9625f7655f881525ac6b30c56a065724c9a71dda79`;
- `CANONICAL_DISTANCE_ADDENDUM_v1.md`, SHA-256 `ecd4487e25f63128028c0d320c010f0a2010cf29b9e7920c3122f76d90d32309`, and `PROTOCOL_v2.json`.

There are ten file identities in the source disposition map, including the prior action and correction records. Original v1 files remain exact. V2 changes only the two identified wording passages; equations and observation input values are unchanged. The protocols were reviewed as plans, not as proof that a parent run fulfilled them. The parent runner, results, freeze and reported failure files were not read or executed in this assignment.

## Mathematical findings

1. The scalar normalization matters. Dividing d ln B/du by sqrt(K_uu) gives alpha=sqrt(a/J), and differentiating in that same coordinate gives beta_D=-a(1-3a)z(1+z)/J². The transverse x=y=0 reduction also uses the vanishing transverse potential gradients; these are present in the inherited potential. The conformal factor and K_uu alone would not suffice for an arbitrary different potential.
2. The inverse a=k(1+z)/(1+3kz), beta_D=-k(1-3k)z is correct. The reconstructed domain is z>-1 for 0<k<1/3, and z>-1/(3k) for k>1/3. The forward Jacobian is -a(1-3a)(1+z)²/J⁴. At k=1/3, a=1/3 and beta_D=0 for all z>-1, so z is unidentifiable; k=1/3 with nonzero beta_D is inadmissible. At k=0 there is no finite point with a>0. These are physical/inverse distinctions, not numerical failures to discard.
3. Finite positive k implies -2<delta_gamma<0. The original v1 phrase allowing any negative delta_gamma was too broad. Delta_gamma=-2 is singular and -3 maps to negative k. The v2 restriction correctly resolves this without changing the formula. The observable-to-parameter map remains ill-conditioned near k=0 and k=1/3 even with arbitrarily accurate arithmetic.
4. The eta=0 family is exact and has nonzero scalar response: z=(1+k)/[k(1-3k)], a=(1-k)(1+3k)/4, beta_D=-(1+k), for 0<k<1/3. It is a deliberately constructed response cancellation, not decoupling or a blind discovery. Only a and local z are identified by two exact nondegenerate response parameters; s and t remain combined without a further background assumption.
5. The derivative d ln G_N/dphi=2alpha[1+beta_D/(1+k)] is at fixed a,s,q. Keeping k fixed instead removes a genuine derivative term and yields the wrong response. On the null family, the complete second derivative is -32k/(1-3k)<0, confirming a strict local maximum. The signed beta_D-prime expression in the addendum also agrees. Instantaneous G-dot cancellation does not supply an evolving scalar trajectory or a finite-observation G-dot bound.
6. The tuned-origin mass rewrite m_J,u²/H_v²=nu+3ks(nu+4) follows from the exact prior fixed-constant Hessian. It is positive on the null family for nu>0, but positivity is separate from being light on the apparatus scale. The formal fixed-k, s->infinity normalization limit increases this mass and cannot automatically retain the long-range bridge. No global or fixed-absolute-flux stability inference is supported.
7. The remaining scalar distance is finite for z>0,0<a<1/3. Independent substitution gives the stated atanh form and the asymptotic Delta_phi/sqrt(k)->1 on the null family. At k=1e-8, Delta_phi is about 0.000099999994333333474; at k=1e-6 it is about 0.000999994333347399964. A positive .001 scalar step is unavailable in both cases. This confirms the mathematical explanation of the parent's reported first-run endpoint failure, without independently verifying the parent run itself. Fractions .01,.001,.0001 of the remaining distance are inside this domain. Their actual numerical implementation remains outside this review.

The supplied PPN bridge is not a derivation from the full constrained cosmological/boundary problem. Its stated local premises must hold before using this inverse on measurements. Small k alone does not establish a controlled expansion if coupling derivatives become large. Compactness products are diagnostics, not strong-body exclusions or a complete expansion proof. The new calculations do not reconstruct the old homogeneous fluid history for nonzero zeta, determine H_v, select a flux sector, or establish quantum consistency.

## Historical inputs and independent arithmetic

The imported normalization and PPN formulas were checked against the primary introduction and displayed equations of [Damour and Esposito-Farese](https://arxiv.org/pdf/gr-qc/9602056v1). This was a targeted bridge/source check, not a full 35-page review.

The frozen Cassini summary agrees with the primary publisher's indexed abstract. Direct publisher-page access failed with an authentication redirect, so I do not claim a current full-paper or raw-Doppler read. [Cassini primary record](https://www.nature.com/articles/nature01997).

The lunar scientific text through conclusions confirms that the eta summary combines lunar ranging, a composition test and self-energy modeling; the subsequent beta estimate incorporates Cassini. Reusing that beta as another independent datum would double count. The current block also reuses earlier campaign lunar information. [Lunar primary paper](https://arxiv.org/pdf/gr-qc/0411113v2). `PRIMARY_SOURCE_CHECK_v1.json` records these access and coverage limits.

For n=1,2,3 the exact positive-k Cassini upper bounds are respectively 1/999999, 1/79999 and 3/124997, approximately 1.000001e-6, 1.250015625e-5 and 2.400057601e-5. This establishes the corrected false/true/true membership of the supplied k=1e-5 illustration.

At that supplied k, each eta band was independently inverted with its decreasing slope and intersected with the strict kinetic condition z>-1. The resulting eta-only upper bounds on a are approximately 0.27273124, 0.32876748 and 0.33096104. The first is not a joint allowed slice because its k fails the corresponding Cassini band. Across the seven frozen z diagnostics, eta membership counts are 5,6,6 and joint rectangle counts are 0,6,6. Every failure remains in the 21-row evidence. These are exposed diagnostic rectangles, not confidence regions, likelihoods, best fits or independent blind tests.

## Independent method, controls and results

No parent helper or runner was imported. The reviewer scripts use exact rational algebra for domain/inverse classification, symbolic proper-scalar differentiation and Jacobians, direct numerical differentiation of G_N(u) with the scalar line element, and scalar-distance quadratures in a different integration variable.

- Main stage: 405 pass, 0 fail; all 80 forward rows (73 physical, 7 invalid), 64 inverse rows (61 physical, 3 invalid), four extra kinetic-boundary cases, six null designs with three masses each, 21 historical membership rows and 30 finite-coordinate contrast rows preserved.
- Distance stage: 46 pass, 0 fail; nine distance rows, including all six null designs and an additional asymptotic point, checked by positive rational Y-tail quadrature, the elementary expression and the regular-r integral. Maximum route discrepancy is below 9.90e-91 at 90-digit precision.
- Signed supplementary stage: 3 pass, 0 fail; checks the sign of beta_D-prime, the full fixed-theory second derivative before null substitution, and the negative-gamma counterexample.

Adverse formula controls detect dropping scalar normalization, confusing beta_D with the PPN beta deviation, and differentiating along fixed k. Historical rows contain real membership failures, preventing an all-true descriptive interpretation. These are independent mathematical controls, not mutations of or coverage claims for the parent's runner.

The finite-coordinate contrasts use fixed u increments and independently integrate dphi, so they do not repeat the parent's unavailable absolute-phi endpoints. Maximum derivative errors decrease from 1.649e-7 to 1.649e-9 to 1.649e-11 at u steps .001,.0001,.00001. This finite fixture result does not assert a uniform error bound across all model parameters. The revised parent's leading-Taylor-relative-error plan is mathematically sensible only where the chosen leading coefficient is nonzero; its code was not reviewed here.

## Preserved failures and evidence

Three reviewer technical failures remain recorded. The first main script failed to parse because an unused conditional branch contained an invalid decimal-literal method expression; no scientific check ran. A separate v2 removed that branch and passed. The first supplementary script completed its algebra but failed while counting/serializing a SymPy BooleanAtom; its separate v2 converts predicate values to Python bool and passes with unchanged expected identities. An early summary assembly attempted to read a supplementary result before successful production and raised FileNotFoundError; the primary-source ledger already written by that attempt was preserved, and a separate completed summary script records the final stages. No mathematical disagreement was hidden or rewritten into a pass.

Exact executed file versions, diffs, raw outputs and failure records are preserved. `SOURCE_DISPOSITIONS_v1.json` records all ten source identities and their roles. `FINAL_RECEIPT_v1.json` binds the complete report, derivation, sources, executions and result evidence. All writes are inside this review directory; no parent source, Git state, PR, settings, worker, prior review or empirical input was changed.
