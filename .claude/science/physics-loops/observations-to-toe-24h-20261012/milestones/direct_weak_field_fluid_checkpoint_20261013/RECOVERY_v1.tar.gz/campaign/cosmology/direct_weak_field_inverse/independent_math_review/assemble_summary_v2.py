#!/usr/bin/env python3
from pathlib import Path
from decimal import Decimal
import json,datetime
p=Path(__file__).resolve().parent
main=json.loads((p/'INDEPENDENT_RESULTS_v2.json').read_text())
dist=json.loads((p/'INDEPENDENT_DISTANCE_RESULTS_v1.json').read_text())
sup=json.loads((p/'SUPPLEMENTARY_EXACT_RESULTS_v2.json').read_text())
summary={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':[{'name':'inverse and response','pass':main['pass_count'],'fail':main['fail_count']},{'name':'finite canonical distance','pass':dist['pass_count'],'fail':dist['fail_count']},{'name':'signed supplementary identities','pass':sup['pass_count'],'fail':sup['fail_count']}],'row_counts':{'forward':len(main['forward_grid']),'forward_physical':sum(x['physical'] for x in main['forward_grid']),'forward_invalid':sum(not x['physical'] for x in main['forward_grid']),'inverse':len(main['inverse_grid']),'inverse_physical':sum(x['physical'] for x in main['inverse_grid']),'inverse_invalid':sum(not x['physical'] for x in main['inverse_grid']),'null_family':len(main['null_family']),'historical_membership':len(main['membership_rows']),'u_coordinate_contrasts':len(main['finite_coordinate_contrasts']),'distance':len(dist['rows'])},'historical_memberships':[{'n':n,'eta_pass':sum(x['eta_member'] for x in main['membership_rows'] if x['n']==n),'joint_pass':sum(x['joint_rectangle_member'] for x in main['membership_rows'] if x['n']==n)} for n in (1,2,3)],'finite_contrast_errors_by_u_step':{step:str(max(Decimal(x['absolute_error']) for x in main['finite_coordinate_contrasts'] if Decimal(x['u_step'])==Decimal(step))) for step in ('0.001','0.0001','0.00001')},'distance_route_max_error':str(max(Decimal(x['route_error']) for x in dist['rows'])),'all_parent_implementation_outside_scope':True}
(p/'INDEPENDENT_SUMMARY_v1.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
