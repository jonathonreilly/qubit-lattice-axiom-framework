#!/usr/bin/env python3
"""Independent remaining-distance integral and null-family geometry controls."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
import datetime,hashlib,json
import mpmath as mp
import sympy as sp
p=Path(__file__).resolve().parent
mp.mp.dps=90
checks=[]
def check(name,truth,detail=None):checks.append({'name':name,'pass':bool(truth),'detail':detail})
def exact(name,left,right):
    r=sp.factor(sp.together(left-right));check(name,r==0,str(r))
def dec(x):return mp.nstr(x,65)
a,Y,z=sp.symbols('a Y z',positive=True)
c=1-3*a
# Substitution Y=sqrt(1+c*z) applied directly to the scalar line element.
zY=(Y*Y-1)/c
line_z=sp.sqrt(1+c*z)/(2*sp.sqrt(a)*z*(1+z))
transformed=Y/(2*sp.sqrt(a)*zY*(1+zY))*sp.diff(zY,Y)
partial_fraction=(1/(Y*Y-1)-3*a/(Y*Y-3*a))/sp.sqrt(a)
exact('Y-coordinate partial fractions',transformed,partial_fraction)
remaining=(sp.atanh(1/Y)-sp.sqrt(3*a)*sp.atanh(sp.sqrt(3*a)/Y))/sp.sqrt(a)
exact('remaining distance derivative has negative line element',sp.diff(remaining,Y),-partial_fraction)
check('remaining distance vanishes at infinite Y',sp.limit(remaining,Y,sp.oo)==0)
# r=1/sqrt(z) Jacobian: reversed integration limits absorb the minus sign.
r=sp.symbols('r',positive=True)
exact('regular r-coordinate integrand',sp.sqrt(r*r+c)/(sp.sqrt(a)*(1+r*r)),(sp.sqrt(1+c/r**2)/(2*sp.sqrt(a)*(1/r**2)*(1+1/r**2)))*2/r**3)
# Along null family, use h=sqrt(k) to expand without a fractional-power ambiguity.
h=sp.symbols('h',real=True)
a_h=(1-h*h)*(1+3*h*h)/4
null_distance=sp.atanh(h/sp.sqrt(a_h))/sp.sqrt(a_h)-sp.sqrt(3)*sp.atanh(sp.sqrt(3)*h)
series=sp.series(null_distance,h,0,6).removeO()
exact('null distance leading and subleading series',series,h-sp.Rational(17,3)*h**3+sp.Rational(211,15)*h**5)

protocol=json.loads((p/'source_snapshot/PROTOCOL_v2.json').read_text())
rows=[]
fixtures=[(mp.mpf('0.1'),mp.mpf('2'),'generic'),(mp.mpf('0.3'),mp.mpf('1e6'),'generic')]
for value in protocol['null_k_grid']+['1e-12']:
    k=mp.mpf(value);av=(1-k)*(1+3*k)/4;zv=(1+k)/(k*(1-3*k))
    fixtures.append((av,zv,'null k='+value))
for av,zv,label in fixtures:
    cv=1-3*av;Y0=mp.sqrt(1+cv*zv)
    # Independent positive rational tail integral in Y, not the parent's regular r quadrature.
    integrand=lambda w:cv*w*w/(mp.sqrt(av)*(w*w-1)*(w*w-3*av))
    tail=mp.quad(integrand,[Y0,2*Y0,mp.inf])
    closed=(mp.atanh(1/Y0)-mp.sqrt(3*av)*mp.atanh(mp.sqrt(3*av)/Y0))/mp.sqrt(av)
    regular=mp.quad(lambda r:mp.sqrt(r*r+cv)/(mp.sqrt(av)*(1+r*r)),[0,1/mp.sqrt(zv)])
    err=max(abs(tail-closed),abs(tail-regular))
    check('three distance routes '+label,err<mp.mpf('1e-75') and tail>0,dec(err))
    scales=[]
    for hfrac in map(mp.mpf,protocol['finite_difference_steps']):
        step=hfrac*tail
        check('scaled endpoint is interior '+label+' '+str(hfrac),0<step<tail)
        scales.append({'fraction':dec(hfrac),'phi_step':dec(step),'remaining_distance_after_positive_step':dec(tail-step)})
    row={'label':label,'a':dec(av),'z':dec(zv),'distance_Y_tail':dec(tail),'distance_closed':dec(closed),'distance_r_integral':dec(regular),'route_error':dec(err),'scaled_steps':scales}
    if label.startswith('null'):
        k=mp.mpf(label.split('=')[1]);row['distance_over_sqrt_k']=dec(tail/mp.sqrt(k))
        if k==mp.mpf('1e-8'):
            check('original absolute .001 endpoint is unavailable at k1e-8',mp.mpf('.001')>tail)
            row['original_absolute_step_over_distance']=dec(mp.mpf('.001')/tail)
        if k<=mp.mpf('1e-5'):
            asym=mp.sqrt(k)*(1-mp.mpf(17)*k/3+mp.mpf(211)*k*k/15)
            check('null asymptotic numerical remainder '+str(k),abs(tail-asym)<100*mp.sqrt(k)*k**3,dec(tail-asym))
    rows.append(row)
result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Direct Y-substitution partial fractions, exact series in sqrt(k), independent positive rational Y-tail quadrature checked against elementary and regular-r forms.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'digits':mp.mp.dps,'pass_count':sum(x['pass'] for x in checks),'fail_count':sum(not x['pass'] for x in checks),'checks':checks,'rows':rows,'parent_runner_read_or_executed':False}
(p/'INDEPENDENT_DISTANCE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass_count'],'fail':result['fail_count'],'failed':[r for r in checks if not r['pass']],'rows':rows},indent=2))
raise SystemExit(bool(result['fail_count']))
