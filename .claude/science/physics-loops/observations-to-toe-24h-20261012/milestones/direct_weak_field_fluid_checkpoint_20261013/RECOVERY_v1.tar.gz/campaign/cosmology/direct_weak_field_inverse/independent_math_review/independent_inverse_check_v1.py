#!/usr/bin/env python3
"""Independent exact inverse algebra and local-coordinate controls.

No parent runner/helper is read, imported or executed. Fractions classify
boundaries exactly; mpmath integrates the scalar line element separately.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[name]='1'
from pathlib import Path
from fractions import Fraction as Q
import datetime,hashlib,json,platform
import sympy as sp
import mpmath as mp
p=Path(__file__).resolve().parent
mp.mp.dps=90
checks=[]
def check(name,truth,detail=None):
    checks.append({'name':name,'pass':bool(truth),'detail':detail})
def exact(name,left,right):
    residual=sp.factor(sp.together(left-right))
    check(name,residual==0,str(residual))
def dec(x):return mp.nstr(x,65)
def frac(x):return str(x)
def mfrac(x):return mp.mpf(x.numerator)/x.denominator

# Differential operator follows the proper scalar line element, not an inverse helper.
a,z,k,nu,t=sp.symbols('a z k nu t',real=True)
J=1+(1-3*a)*z
Ku=J/(1+z)**2
dphi_du=sp.sqrt(J)/(1+z)
lnB_u=sp.sqrt(a)/(1+z)
alpha=sp.cancel(lnB_u/dphi_du)
Dphi=lambda f:sp.factor(2*sp.sqrt(a)*z*(1+z)/sp.sqrt(J)*sp.diff(f,z))
beta=sp.factor(Dphi(alpha))
exact('normalized squared coupling',alpha**2,a/J)
exact('normalized coupling derivative',beta,-a*(1-3*a)*z*(1+z)/J**2)
inva=k*(1+z)/(1+3*k*z)
exact('inverse kinetic J',J.subs(a,inva),(1+z)/(1+3*k*z))
exact('inverse recovers k',(a/J).subs(a,inva),k)
exact('beta in inverse coordinates',beta.subs(a,inva),-k*(1-3*k)*z)
jac=sp.Matrix([a/J,beta]).jacobian([a,z]).det()
exact('forward inverse-identifiability determinant',jac,-a*(1-3*a)*(1+z)**2/J**4)
exact('k one third forces a one third',(a/J-sp.Rational(1,3))*3*J,(3*a-1)*(1+z))
exact('a one third gives beta zero',beta.subs(a,sp.Rational(1,3)),0)

b=sp.symbols('beta_D',real=True)
dg=-2*k/(1+k);db=b*k/(2*(1+k)**2);eta=4*db-dg
exact('PPN eta identity',eta,2*k*(1+k+b)/(1+k)**2)
exact('gamma inverse',-dg/(2+dg),k)
exact('beta inverse',2*(1+k)**2*db/k,b)
obsjac=sp.Matrix([dg,eta]).jacobian([k,b]).det()
exact('PPN observable-coordinate determinant',obsjac,-4*k/(1+k)**4)
nullz=(1+k)/(k*(1-3*k));nulla=(1-k)*(1+3*k)/4
exact('null family a from inverse',inva.subs(z,nullz),nulla)
exact('null family eta',eta.subs(b,-k*(1-3*k)*nullz),0)

# Work directly with G proportional to exp(2t)(1+a/J)/(1+z) at fixed a,s,q.
logG_rest=sp.log(1+a/J)-sp.log(1+z)
g_u=2*sp.sqrt(a)*(1+z*sp.diff(logG_rest,z))
g_phi=sp.factor(g_u/dphi_du)
exact('fixed theory Newton derivative',g_phi,2*alpha*(1+beta/(1+a/J)))
exact('eta derivative relation',eta.subs({k:a/J,b:beta}),alpha/(1+a/J)*g_phi)
mu_old=(nu*(1+z)+12*a*z)/J
exact('origin mass rewrite',mu_old.subs(a,inva),nu+3*k*z*(nu+4))
exact('large s fixed k a limit',sp.limit(inva,z,sp.oo),sp.Rational(1,3))
exact('fixed-k origin a side',(inva-sp.Rational(1,3)),(3*k-1)/(3*(1+3*k*z)))

# Independent curvature derivation: at a stationary point, g_phiphi=(z_phi)^2 g_zz.
c=1-3*a
logG_z=1/(z*(1+z))-a*c/(J*(J+a))
logG_zz=sp.diff(logG_z,z)
curv_z=sp.factor(4*(a/J)*z*z*(1+z)**2*logG_zz)
null_sub={a:nulla,z:nullz}
exact('null fixed theory first derivative squared',g_phi**2.subs(null_sub) if False else (g_phi**2).subs(null_sub),0)
exact('null curvature from z-coordinate Hessian',curv_z.subs(null_sub),-32*k/(1-3*k))
# Squaring removes branch simplification; the beta derivative has negative sign in 0<k<1/3.
beta_prime=Dphi(beta)
beta_prime_sq=sp.factor(beta_prime**2)
expected_bp_sq=4*k*(1+k)**2*(7+3*k)**2/(1-3*k)**2
exact('null beta derivative magnitude',beta_prime_sq.subs(null_sub),expected_bp_sq)

# Local x=y=0 consistency includes the transverse potential gradient.
x,y=sp.symbols('x y',real=True)
V=sp.Rational(3,2)+(a/2-t+2*t*t/a)*x*x+a*y*y/3+nu*t*t/(2*a)
exact('transverse x potential gradient',sp.diff(V,x).subs({x:0,y:0}),0)
exact('transverse y potential gradient',sp.diff(V,y).subs({x:0,y:0}),0)
exact('transverse kinetic connection numerator',sp.diff(Ku,x),0)

protocol=json.loads((p/'source_snapshot/PROTOCOL_v1.json').read_text())
obs=json.loads((p/'source_snapshot/OBSERVATION_INPUTS_v1.json').read_text())
forward=[]
for aa in map(Q,protocol['a_grid']):
    for zz in map(Q,protocol['z_grid']):
        JJ=1+(1-3*aa)*zz
        row={'a':frac(aa),'z':frac(zz),'F_over_q':frac(1+zz),'J':frac(JJ),'physical':1+zz>0 and JJ>0}
        if JJ:
            kk=aa/JJ;bb=-aa*(1-3*aa)*zz*(1+zz)/JJ**2
            row.update(k=frac(kk),beta_D=frac(bb))
            if row['physical']:
                check('forward physical k '+frac(aa)+' '+frac(zz),kk>0)
                if kk!=Q(1,3):
                    zr=-bb/(kk*(1-3*kk));ar=kk*(1+zr)/(1+3*kk*zr)
                    check('forward exact inverse '+frac(aa)+' '+frac(zz),(ar,zr)==(aa,zz))
                    row['inverse']={'a':frac(ar),'z':frac(zr)}
                else:
                    row['inverse']='z unidentified at k=1/3';check('degenerate forward '+frac(zz),aa==Q(1,3) and bb==0)
        forward.append(row)

inverse=[]
for kk in map(Q,protocol['inverse_k_grid']):
    for zz in map(Q,protocol['z_grid']):
        den=1+3*kk*zz;phys=kk>0 and 1+zz>0 and den>0
        row={'k':frac(kk),'z':frac(zz),'denominator':frac(den),'physical':phys,'z_identifiable':kk!=Q(1,3)}
        if den:
            aa=kk*(1+zz)/den;JJ=1+(1-3*aa)*zz
            row.update(a=frac(aa),J=frac(JJ),beta_D=frac(-kk*(1-3*kk)*zz))
            check('inverse domain '+frac(kk)+' '+frac(zz),phys==(aa>0 and 1+zz>0 and JJ>0))
            if phys:check('inverse forward recovery '+frac(kk)+' '+frac(zz),aa/JJ==kk)
        else:row['status']='singular inverse denominator'
        inverse.append(row)

# Boundary fixtures independent of the supplied finite grid.
boundaries=[]
for aa,zz in [(Q(1,2),Q(2)),(Q(1),Q(1,2)),(Q(1,3),Q(-1)),(Q(1,3),Q(-1,2))]:
    JJ=1+(1-3*aa)*zz
    boundaries.append({'a':frac(aa),'z':frac(zz),'F_over_q':frac(1+zz),'J':frac(JJ),'physical':1+zz>0 and JJ>0})
check('all kinetic equality cases rejected',all(not r['physical'] for r in boundaries[:3]))
check('k one third negative-z interior remains allowed',boundaries[3]['physical'])
for gg,expected_phys in [(Q(-3),False),(Q(-2),False),(Q(-1),True),(Q(0),False),(Q(21,1000000),False)]:
    if gg!=-2:
        kk=-gg/(2+gg)
        check('gamma inverse domain '+str(gg),(kk>0)==expected_phys)
    else:check('gamma negative two is singular',2+gg==0)

null_rows=[]
for kk in map(Q,protocol['null_k_grid']):
    zz=(1+kk)/(kk*(1-3*kk));aa=(1-kk)*(1+3*kk)/4;JJ=1+(1-3*aa)*zz
    bb=-aa*(1-3*aa)*zz*(1+zz)/JJ**2
    ee=2*kk*(1+kk+bb)/(1+kk)**2
    curvature=-32*kk/(1-3*kk)
    check('exact null family '+frac(kk),0<kk<Q(1,3) and zz>0 and aa>0 and JJ>0 and aa/JJ==kk and bb==-(1+kk) and ee==0 and curvature<0)
    masses=[]
    for nv in map(Q,protocol['nu_grid']):
        mm=(nv*(1+zz)+12*aa*zz)/JJ
        check('null physical mass '+frac(kk)+' '+frac(nv),mm==nv+3*kk*zz*(nv+4) and mm>0)
        masses.append({'nu':frac(nv),'mJu_squared_over_Hv2':frac(mm)})
    null_rows.append({'k':frac(kk),'a':frac(aa),'z':frac(zz),'beta_D':frac(bb),'eta':frac(ee),'delta_gamma':frac(-2*kk/(1+kk)),'log_GN_phi_curvature':frac(curvature),'masses':masses})

# Historical summaries are only exact arithmetic rectangle inputs here.
mu_g=Q(obs['Cassini']['mean']);sig_g=Q(obs['Cassini']['reported_uncertainty'])
mu_e=Q(obs['LLR']['mean']);sig_e=Q(obs['LLR']['reported_uncertainty'])
k0=Q(protocol['diagnostic_k']);E=2*k0/(1+k0);Dk=2*k0*k0*(1-3*k0)/(1+k0)**2
g0=-2*k0/(1+k0)
bands=[];members=[]
for n in protocol['observation_band_multiples']:
    gl,gh=mu_g-n*sig_g,mu_g+n*sig_g
    el,eh=mu_e-n*sig_e,mu_e+n*sig_e
    width=n*sig_g-mu_g
    assert 0<width<2
    kmax=width/(2-width)
    check('Cassini exact lower band edge '+str(n),-2*kmax/(1+kmax)==gl)
    zl=(E-eh)/Dk;zh=(E-el)/Dk
    alimit=lambda zz:k0*(1+zz)/(1+3*k0*zz)
    clipped_l=max(Q(-1),zl)
    bands.append({'n':n,'gamma_band':[frac(gl),frac(gh)],'eta_band':[frac(el),frac(eh)],'k_max':frac(kmax),'k_max_decimal':dec(mfrac(kmax)),'illustration_in_Cassini':gl<=g0<=gh,'raw_z_band':[frac(zl),frac(zh)],'physical_z_band':{'lower':frac(clipped_l),'lower_included':zl>Q(-1),'upper':frac(zh),'upper_included':True},'physical_a_upper':frac(alimit(zh)),'physical_a_upper_decimal':dec(mfrac(alimit(zh)))})
    check('eta exact band endpoints '+str(n),E-Dk*zl==eh and E-Dk*zh==el)
    for zz in map(Q,protocol['diagnostic_z_grid']):
        aa=alimit(zz);bb=-k0*(1-3*k0)*zz;ee=2*k0*(1+k0+bb)/(1+k0)**2
        direct_ee=4*(bb*k0/(2*(1+k0)**2))-g0
        check('rectangle direct eta '+str(n)+' '+frac(zz),ee==direct_ee)
        members.append({'n':n,'k':frac(k0),'z':frac(zz),'a':frac(aa),'beta_D':frac(bb),'eta':frac(ee),'eta_decimal':dec(mfrac(ee)),'gamma_member':gl<=g0<=gh,'eta_member':el<=ee<=eh,'joint_rectangle_member':gl<=g0<=gh and el<=ee<=eh,'physical':zz>-1})
check('illustration Cassini membership exactly false true true',[r['illustration_in_Cassini'] for r in bands]==[False,True,True])
check('rectangles retain real failures',any(not r['eta_member'] for r in members) and any(r['eta_member'] for r in members))

# Adverse formula controls are not parent-runner mutations.
adverse=[]
av=Q(1,5);zv=Q(1);jv=1+(1-3*av)*zv
naive_alpha_sq=av/(1+zv)**2;actual_alpha_sq=av/jv
adverse.append({'omission':'scalar coordinate normalization','naive_alpha_squared':frac(naive_alpha_sq),'actual_alpha_squared':frac(actual_alpha_sq)})
check('missing scalar normalization detected',naive_alpha_sq!=actual_alpha_sq)
kv=Q(1,10);zv=(1+kv)/(kv*(1-3*kv));bv=-(1+kv)
adverse.append({'omission':'confuse coupling beta with PPN beta deviation','beta_D':frac(bv),'delta_beta':frac(bv*kv/(2*(1+kv)**2))})
check('beta symbols cannot be conflated',bv!=bv*kv/(2*(1+kv)**2))
adverse.append({'omission':'hold k fixed in GN background derivative','at_null_true_dlogG_dphi':'0','fixed_k_dlogG_dphi_using_point_scalar_tangent':dec(2*mp.sqrt(mfrac(kv)))})
check('fixed-k derivative misses null cancellation',kv>0)

# Direct scalar-coordinate integration for finite contrasts at fixed a,s,q.
# This numerical oracle uses B(u), K(u), G(u), not the closed dlogG/dphi formula.
fixtures=[(Q(1,5),Q(-1,2),'generic'),(Q(1,10),Q(1),'generic'),(Q(1,3),Q(10),'constant coupling'),(Q(2,5),Q(1),'generic')]
fixtures += [(Q(r['a']),Q(r['z']),'null k='+r['k']) for r in null_rows]
finite=[]
for ar,sr,label in fixtures:
    av,sv=mfrac(ar),mfrac(sr)
    def zz(u):return sv*mp.exp(2*mp.sqrt(av)*u)
    def JJ(u):return 1+(1-3*av)*zz(u)
    def line(u):return mp.sqrt(JJ(u))/(1+zz(u))
    def GN(u):
        zval=zz(u);jval=JJ(u)
        return mp.exp(2*mp.sqrt(av)*u)*(1+av/jval)/(1+zval)
    kval=av/JJ(0);betaval=-av*(1-3*av)*sv*(1+sv)/JJ(0)**2
    prediction=2*mp.sqrt(kval)*(1+betaval/(1+kval))
    curv_prediction=(-32*kval/(1-3*kval)) if label.startswith('null') else None
    # Independent numerical differentiation wrt u plus scalar-coordinate chain rule.
    logG=lambda u:mp.log(GN(u))
    g1=mp.diff(logG,0)/line(0)
    g2=mp.diff(logG,0,2)/line(0)**2-mp.diff(logG,0)*mp.diff(line,0)/line(0)**3
    check('direct differentiated first derivative '+label+str(ar),abs(g1-prediction)<mp.mpf('1e-75'),dec(g1-prediction))
    if curv_prediction is not None:
        check('direct differentiated null curvature '+label,abs(g2-curv_prediction)<mp.mpf('1e-72'),dec(g2-curv_prediction))
    for step in map(mp.mpf,protocol['finite_difference_steps']):
        field_width=mp.quad(line,[-step,0,step])
        secant=(logG(step)-logG(-step))/field_width
        err=abs(secant-prediction)
        check('finite scalar-coordinate contrast '+label+' '+str(step),err<100*step**2*max(1,abs(prediction)),dec(err))
        finite.append({'label':label,'a':frac(ar),'s':frac(sr),'u_step':dec(step),'proper_scalar_width':dec(field_width),'predicted_first_derivative':dec(prediction),'contrast':dec(secant),'absolute_error':dec(err),'direct_second_derivative':dec(g2),'predicted_null_second_derivative':None if curv_prediction is None else dec(curv_prediction)})

result={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Proper-scalar differential operator, Jacobian and fixed-theory logG curvature; exact Fraction grids/bands; independently integrated scalar-coordinate contrasts. No author code imported.','python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__,'digits':mp.mp.dps,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'pass_count':sum(x['pass'] for x in checks),'fail_count':sum(not x['pass'] for x in checks),'checks':checks,'forward_grid':forward,'inverse_grid':inverse,'kinetic_boundaries':boundaries,'null_family':null_rows,'historical_bands':bands,'membership_rows':members,'adverse_formula_controls':adverse,'finite_coordinate_contrasts':finite}
(p/'INDEPENDENT_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass_count'],'fail':result['fail_count'],'failed_checks':[r for r in checks if not r['pass']],'forward_rows':len(forward),'inverse_rows':len(inverse),'null_rows':len(null_rows),'membership_rows':len(members),'finite_coordinate_rows':len(finite),'bands':bands},indent=2))
raise SystemExit(bool(result['fail_count']))
