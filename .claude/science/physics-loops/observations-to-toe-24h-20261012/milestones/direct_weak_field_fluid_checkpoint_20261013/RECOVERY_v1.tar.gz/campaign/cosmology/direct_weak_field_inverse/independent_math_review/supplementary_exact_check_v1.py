#!/usr/bin/env python3
"""Signed null-derivative and exact-domain counterexamples, separate from main run."""
from pathlib import Path
import datetime,hashlib,json
import sympy as sp
p=Path(__file__).resolve().parent
k,z=sp.symbols('k z',positive=True)
beta=-k*(1-3*k)*z
beta_prime=sp.diff(beta,k)*(2*sp.sqrt(k)*beta)+sp.diff(beta,z)*(2*sp.sqrt(k)*z*(1+z))
nullz=(1+k)/(k*(1-3*k))
expected=-2*sp.sqrt(k)*(1+k)*(7+3*k)/(1-3*k)
residual=sp.factor(beta_prime.subs(z,nullz)-expected)
# Check the full scalar-coordinate derivative before imposing the null constraint.
gprime=2*sp.sqrt(k)*(1+beta/(1+k))
gsecond=sp.diff(gprime,k)*(2*sp.sqrt(k)*beta)+sp.diff(gprime,z)*(2*sp.sqrt(k)*z*(1+z))
curv_residual=sp.factor(gsecond.subs(z,nullz)+32*k/(1-3*k))
checks=[{'name':'signed beta-prime null identity','pass':residual==0,'detail':str(residual)},{'name':'full two-variable fixed-theory second derivative','pass':curv_residual==0,'detail':str(curv_residual)},{'name':'negative gamma alone is insufficient','pass':-sp.Rational(-3)/(2-3)<0,'detail':'delta_gamma=-3 gives k=-3; delta_gamma=-2 has zero denominator.'}]
out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'pass_count':sum(x['pass'] for x in checks),'fail_count':sum(not x['pass'] for x in checks),'parent_code_imported_or_executed':False}
(p/'SUPPLEMENTARY_EXACT_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(bool(out['fail_count']))
