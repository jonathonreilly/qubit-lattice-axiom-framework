# Independent calculation details

The frozen action supplies, in t=sqrt(a)u coordinates,

    F=1+z0 exp(2t), J=1+(1-3a)z0 exp(2t),
    K_tt=J/(a F^2), ln B=t-(1/2)ln F.

On F,J>0 the normalized scalar derivative is
D_phi=sqrt(a)F/sqrt(J) D_t. Applying it to ln B and then again gives

    alpha=sqrt(a)/sqrt(J),
    beta_D=-a(1-3a)z(1+z)/J^2.

This is the source of the rational response oracle in the reviewer code.
The published PPN map is separately identified as an imported bridge.

The forward oracle keeps exact Fraction values for a,z,J,k,beta_D,
delta_gamma,delta_beta,eta and G_N/(1/(8 pi q)) at the chosen t=0 representative.
Only square roots for the normalized derivative require arbitrary precision.
The inverse solves a(1+3kz)=k(1+z) and explicitly checks the signs of both
the tensor factor and scalar eigenvalue. It handles k=1/3 separately.
All observation-band inequalities use exact Fraction arithmetic on the frozen
processed summaries. This avoids asking the producer membership helper to
validate itself.

For the positive-z null family, define r=1/sqrt(z) and h_a=1-3a.
Here 0<a<1/3 and h_a>0. At fixed a,s,q,

    dphi/dr=-sqrt(r^2+h_a)/[sqrt(a)(1+r^2)],
    D_phi=-sqrt(a)(1+r^2)/sqrt(r^2+h_a) D_r.

Apart from the fixed positive factor 1/s, the weak-body Newton coefficient is

    W(r)=[h_a+(1+a)r^2]/[(1+r^2)(h_a+r^2)].

The reviewer applies this r-space differential operator to ln W four times,
before inserting null a(k),r(k). This is independent of the author's z-space
operator and its u-space numerical derivatives. The first derivative vanishes,
and the second is -32k/(1-3k). Third and fourth derivatives set the finite
central-difference errors, not an arbitrary uniform threshold.

The remaining distance can be computed by a regular angular quadrature,

    Delta(r0)=1/sqrt(a) integral_0^atan(r0)
                          sqrt(tan(theta)^2+h_a) dtheta.

A separate expression, with Y=sqrt(1+h_a/r^2), is

    Delta(r)=[atanh(1/Y)-sqrt(3a)atanh(sqrt(3a)/Y)]/sqrt(a).

These two evaluations agree on every null input. For a chosen positive h
smaller than Delta(r0), monotonicity gives unique positive roots

    Delta(r_plus)=Delta(r0)-h, r_plus<r0,
    Delta(r_minus)=Delta(r0)+h, r_minus>r0.

The reviewer obtains them by signed bisection of the closed expression. The
original scalar coordinates are then u_plus/minus=ln(r0/r_plus/minus)/sqrt(a).
This does not call the author's local-u quadrature or findroot. Substituting
the endpoint r values directly into ln[W(r)/s] produces the independent
central differences. Every recorded up,um,h,remaining,first,second,error and
leading error term is compared with the original result.

The prior origin physical mass oracle is

    [nu(1+z)+12az]/[1+(1-3a)z].

It reproduces nu+3kz(nu+4) after the null inverse substitution. The reviewer
uses the former expression for the primary rational calculation and checks
the reduction separately. The length diagnostic is sqrt(mass_squared) H_v L/c;
it introduces no measured H_v, length or scalar mass.

The numerical comparison metric is
abs(actual-expected)/max(1,abs(expected)), with tolerance 1e-60.
The working precision is 110 decimal digits. Saved values use 100 significant
digits. These finite high-precision checks are not interval certificates.

No original physics helper or author module is imported. Parent result files
are read only for comparison after generating the independent reference.
The original v1 failure is checked by comparing its requested absolute h
with the independently calculated remaining range; no failed author run
is repeated or made to pass retrospectively.

