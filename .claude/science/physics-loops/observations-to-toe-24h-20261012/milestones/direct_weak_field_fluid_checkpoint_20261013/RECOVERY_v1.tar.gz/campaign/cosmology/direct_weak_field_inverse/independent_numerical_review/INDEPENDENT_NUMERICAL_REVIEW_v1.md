# Independent numerical review — weak-field inverse v2

**The unmodified scientific output is numerically supported on its frozen grid.
Two regression-coverage corrections are required.** All 6498 independent
checks pass. Forcing the shared membership helper to return true for both
experiments, or deleting all four singular-inverse records, each leaves the
author's 1938 assertions passing. The parent has accepted these gaps for a
separate future revision; that revision is outside this immutable report.

This is an implementation and numerical check of a parent-authored conditional
construction. It is not a formal audit, a publication gate, a new empirical
test, or a replacement scientific derivation by another author.

## Exact inputs and actual execution history

Reviewed runner:
check_weak_field_inverse_v2.py,
SHA256 6a155c3c849c9783a3cffb8c1bc0dcdd5d3044ba193ac372e09c12530b821fc6.

First successful v2 result:
evidence_v2/RESULTS.json,
SHA256 bd4f6c8877d5837512d2abd4ef245e1e59526e9c5615d4921382b0d565158320.
It reports 1938 passed and zero failed; the parent execution lasted 12.38 seconds.
All 12 frozen input identities match. The full current runner, protocol,
handwritten note, null-curvature and canonical-distance addenda, numerical
details, observation inputs, source ledger, corrections and execution evidence
were read. SOURCE_FREEZE_v1.json preserves 51 original/snapshot pairs, including
the complete failed v1 history.

The actual first v1 run exited 1 at its first positive canonical endpoint
search. Its unchanged source, freeze, stderr and empty stdout remain preserved.
There is no v1 RESULTS.json: it failed before producing one. This is a genuine
failed execution, not a successful result relabelled as v2.

The v1 handwritten scope correction was separately made before numerical
execution: it narrows the physical gamma inverse to -2<delta_gamma<0 and
states correctly that k=1e-5 lies outside the one-uncertainty Cassini band but
inside the two- and three-uncertainty bands. Those statements are confirmed.

Twelve non-main original functions are text- and AST-identical between v1 and
v2. The main changes implement the finite-distance control, relative steps
and appropriate Taylor-error tests. Precision remains 90 digits; algebra and
root tolerance were not relaxed. The old unsupported uniform 100 h^2
finite-difference threshold was replaced by declared derivative-based error
checks before that old threshold was reached.

## Independent recalculation

No author module or numerical helper was imported as positive evidence.
The reviewer derives the normalized coupling from the original matter factor
in t=sqrt(a)u coordinates. Rational arithmetic determines the complete forward
and inverse domains, response parameters, exact inverse degeneracies, masses,
band endpoints and membership booleans.

For the null family's finite-coordinate calculation the reviewer instead uses
r=1/sqrt(z). The remaining distance is integrated after r=tan(theta), which
gives a regular angular integral. The endpoints are found by signed bisection
of the elementary remaining-distance primitive in r, rather than the author's
u-space quadrature/findroot. Fixed-theory derivatives through fourth order are
taken from a rational r-space expression for G_N before any null substitution.

The first independent run completed in 2.635 seconds, with **6498/0**.
It includes three action identities, 114 inverse controls, four singular-case
controls, 42 null-family controls, six independent distance comparisons,
78 endpoint/Taylor/convergence controls, nine exact band-boundary controls,
2705 original-output and bookkeeping comparisons, 3486 stored-assertion checks,
and 51 snapshot checks. These are numerical and source checks, not independent
measurements. No positive calculation was rerun to obtain this outcome.

All seven scientific output sections and every leaf/shape were compared:

| Section | Rows | Domain handling |
|---|---:|---|
| Forward grid | 80 | 73 admitted; seven excluded retained |
| Inverse grid | 64 | 53 identified, eight degenerate, three excluded |
| Singular gamma cases | 4 | All retained with explicit status |
| Null family | 6 | All positive-domain cases checked |
| Canonical finite differences | 18 | Both endpoints checked in every row |
| Observation rectangles | 3 | Exact rational boundaries and closures |
| Additional diagnostic points | 7 | All memberships and applicability numbers checked |

The largest normalized numerical discrepancy was 4.11e-74, in a central
second derivative where subtraction loses precision. All comparisons use
abs(actual-expected)/max(1,abs(expected)) with tolerance 1e-60; ordinary response
fields agree to about 80 significant digits.

## Endpoint failure and corrected diagnostic

At the first null point k=1e-8, the remaining canonical distance is

    0.00009999999433333347399999642000009794...

The requested v1 absolute step 0.001 is larger than this total available
distance. There is no real endpoint on the specified positive branch. More
root iterations or a looser tolerance would not create one. The next supplied
point k=1e-6 also has remaining distance slightly below 0.001, although v1
stopped before reaching it.

The reviewer obtains the distance both from an independent angular integral
and the closed atanh primitive. All 18 v2 steps are the declared 0.01, 0.001,
0.0001 fractions of their available distances. Both endpoint inversions stay
strictly inside the required positive scalar domain.

The independent third and fourth derivatives reproduce the stated leading
central-difference errors h^2 f'''/6 and h^2 f''''/12. Every finite error ratio
passes the frozen one-percent check, and errors decrease by at least twentyfold
for each tenfold reduction of step. This validates the finite diagnostic on
the supplied grid; it is not a uniform all-parameter error theorem.

The finite canonical range is a property of the admitted classical kinetic
geometry. It does not by itself establish a quantum cutoff, pathology or
observed limitation of a scalar field.

## Conventions, inverse and fixed-theory interpretation

The dimensionless Damour scalar satisfies dphi/du=sqrt(Khat_uu).
This matches the R-2(dphi)^2 normalization and the alpha/beta0 definitions in
[Damour and Esposito-Farese, v1, Eqs. 1.1–1.4](https://arxiv.org/pdf/gr-qc/9602056v1).
Their long-range weak-body PPN response is an explicit imported bridge, not a
new derivation of apparatus physics. beta_D=dalpha/dphi and delta_beta are
different quantities; the factor k/[2(1+k)^2] is required.

The inverse returns local a,z away from k=0 and k=1/3. It does not separately
identify s and background t. The finite positive-a physical gamma range is
-2<delta_gamma<0. The positive Cassini central value is therefore not directly
a physical point estimate of k; the diagnostic uses uncertainty bands instead.

The numerical forward G_N ratios use the explicit u=t=0 representative with
s=z. General background B^2 additionally carries exp(2t). G_N can normalize
q at a chosen background; this does not derive q or infer t from k,z alone.

The null family has eta=0 but nonzero k and delta_gamma. Differentiating G_N
with a,s,q fixed gives a stationary point with second derivative
-32k/(1-3k)<0. The r-coordinate calculation confirms that it is a local
maximum, not a constant G_N over a finite field interval. Differentiating a
fixed-k reconstruction curve would be a different operation.

The origin mass and length diagnostics are consistent with the inherited local
action. They retain the supplied nu and H_v L/c premises. A positive mass alone
does not justify a long-range PPN approximation, and small k alone does not
control all nonlinear or strong-body effects.

## Observation inputs and interval boundaries

The exposed Cassini numbers match the official
[Bertotti–Iess–Tortora abstract](https://www.nature.com/articles/nature01997).
The exposed eta numbers and its PPN definition match the
[Williams–Turyshev–Boggs v2 abstract](https://arxiv.org/abs/gr-qc/0411113v2).
The Cassini-derived beta estimate is not counted as another independent input.
The earlier campaign's processed lunar analysis is also not counted again as
independent evidence.

For k=1e-5 the LLR-derived z intervals have the open lower edge -1 and closed
upper edges approximately 150006.5002, 2400119.0038 and 4650231.5074 for
one, two and three published-uncertainty multiples. Their mapped upper a
values are approximately .27273124, .32876748 and .33096104. The one-multiple
LLR interval exists, but this k independently fails the one-multiple Cassini
band. These are separate rectangular diagnostics, not a joint likelihood or
joint confidence region. The absence of a joint statistical acceptance
claim is appropriate.

The independent rational inequalities reproduce every original membership.
The seven extra diagnostic points and designed null family are exposed
development cases, not held-out observations. Source reading here checks the
declared response conventions and processed summaries; it does not reprocess
radio Doppler, lunar ranging, composition or geophysical data.

Direct Nature opens failed through the identity-provider redirect. The official
journal search result supplied the required abstract. Those failures and the
precise primary reading scope are recorded in PRIMARY_READING_RECORD_v1.json.
Raw remote bytes were not downloaded or represented as locally hash-verified.

## Actual mutation challenges and required repairs

Each mutation changes a real copied source expression and supplies a new freeze
for all 12 actual inputs. All 12 source identity checks pass in every trial.
No assertion or tolerance is removed or weakened. Complete changed source,
diff, freeze, execution, stdout/stderr and result are retained.

| Mutation | Author passed / failed | Disposition |
|---|---:|---|
| Omit scalar-coordinate normalization | 654 / 1284 | Detected |
| Replace delta_beta by beta_D in the producer | 1460 / 478 | Detected |
| Differentiate G_N holding k fixed | 1814 / 124 | Detected |
| Omit excluded forward rows | 1923 / 1 | Detected by complete census |
| Return true for all shared membership calls | 1938 / 0 | Survives |
| Remove all four singular-inverse records | 1938 / 0 | Survives |

**R1 — shared membership oracle.** Both producer and constructed-output checks
call membership. Replacing that helper with return True, True causes 21
incorrect false-to-true booleans while the entire suite passes. Ten concern
null-family Cassini flags, seven diagnostic Cassini flags and four diagnostic
LLR flags. Repair must independently reconstruct response observables and
compare exact input inequalities, rather than call the same altered producer
helper to confirm its output.

**R2 — singular-record coverage.** Replacing the singular list with an empty
list deletes all four explicit domain cases without any author failure.
Repair must check the complete case census and classify the physical inverse,
including the zero boundary, positive central value, denominator singularity,
and negative reconstructed k.

These are test-coverage failures. The original v2 memberships and all four
original singular records are correct under independent recomputation.
The six trials do not establish exhaustive mutation resistance. The additional
singular-record probe is a direct test of the declared retention requirement,
not an invented research route or quota.

The stored output comparator uses positional lists. For the excluded-forward
mutation, its 24 diagnostic differences include shifted alignment; they are
not 24 independent physical errors. The substantive author failure is the
census omission of seven excluded rows. For the empty singular list the
comparator records one list-length difference representing four missing cases.

## Evidence, scope and final disposition

INDEPENDENT_RESULTS_v1.json preserves the first successful 6498/0 independent
run. INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json stores the complete independent
scientific output. DISTANCE_AND_BAND_CONTROLS_v1.json adds explicit endpoint and
interval interpretations. V1_V2_HISTORY_CHECK_v1.json verifies unchanged helper
bodies and records the actual protocol changes. The executable recipes are
independent_recompute_v1.py and run_mutations_v1.py; they use exclusive outputs.
Replay only in a fresh copy with uncreated output names.

No author source, Git state or earlier review file was edited. The final receipt
binds every source/snapshot pair, reviewer source, actual failure and mutation
artifact. No new mathematical or empirical error was found in the unmodified
v2 grid. Source-assertion readiness remains pending R1/R2; the original evidence
and this report must remain immutable when the parent repairs them separately.

