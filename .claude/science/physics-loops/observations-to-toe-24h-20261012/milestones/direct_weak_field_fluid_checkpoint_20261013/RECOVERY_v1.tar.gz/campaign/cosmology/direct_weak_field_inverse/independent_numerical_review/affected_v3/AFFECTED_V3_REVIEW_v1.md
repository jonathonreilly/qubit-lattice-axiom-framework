# Affected independent numerical review — weak-field inverse v3

**The two demonstrated v2 output-coverage gaps are corrected in the frozen v3
source.** Both exact surviving mutations now fail mathematical output checks
while all 13 freshly frozen input hashes pass. The scientific output is
unchanged. This conclusion is limited to the affected source and frozen grid;
it is not a claim of universal corruption resistance, an empirical acceptance,
a formal audit or a publication/landing gate.

## Frozen identities and continuity

- Runner `check_weak_field_inverse_v3.py`:
  `0882f0cd194aec4ce1295118ea034907dcfe25e65267429db4faa5b213433b56`.
- First result `evidence_v3/RESULTS.json`:
  `45682309b8818f24a2d66fc7345578bc113b4ef039d9e6928248f275b8e02a65`.
- Original reviewed v2 runner:
  `6a155c3c849c9783a3cffb8c1bc0dcdd5d3044ba193ac372e09c12530b821fc6`.
- Original reviewed v2 result:
  `bd4f6c8877d5837512d2abd4ef245e1e59526e9c5615d4921382b0d565158320`.

The parent's first v3 execution ran from 10:51:32.061457 to
10:51:38.996376 UTC on October 13, 2026. It reports **2043 passed, zero failed**,
with all frozen inputs unchanged. Its source freeze, snapshots, launch,
execution record, complete result and raw stdout/stderr are preserved here.
The reviewer did not rerun the unmodified author implementation or the earlier
independent positive science.

All 12 non-main functions are text- and AST-identical to v2. Removing precisely
the newly added output-control block makes the entire v3 source byte-identical
to v2. The saved parent diff is the exact diff of those bytes. Protocol, input
values, physical calculations, tolerances and pre-existing assertions have not
changed. The only new frozen input is the output-control correction record.

The seven scientific sections—forward, inverse, singular, null family, finite
differences, observation bands and diagnostics—and the scope string are exact
matches to v2. Every scalar leaf, type, list length and dictionary structure was
compared. A canonical JSON serialization of each entire section is also byte
identical. This is section-content identity, not a claim that the complete
result file including its new checks is unchanged.

All **1926** original non-source assertion objects are identical and in their
original order. V3 adds **104** output assertions and one source-hash assertion,
explaining 1938 -> 2043. The immutable original review's **242 distinct bound
paths** were checked again and remain exact. That report's two findings and
original mutation outcomes are not rewritten by this affected review.

## Independent check of the added oracle

The new producer-independent oracle computes gamma minus one and the
Nordtvedt combination with exact rational arithmetic from the protocol's k,z.
It never calls `membership`. For the null family it obtains z and a from the
protocol's k, checks their serialized exact fractions, and binds the complete
list of band multiples. For additional diagnostic points it uses the protocol's
k,z and binds each band list. Earlier census checks fix the row order and labels.
The added checks require actual Boolean values rather than merely truthy values.

The reviewer did not copy the new compact response expression as the positive
oracle. Instead, `verify_affected_v3.py` reconstructs the original local action
parameters and coupling response:

    a = k(1+z)/(1+3kz),  J = 1+(1-3a)z,
    alpha^2 = a/J,
    beta_D = -a(1-3a)z(1+z)/J^2,
    delta_gamma = -2 alpha^2/(1+alpha^2),
    delta_beta = beta_D alpha^2/[2(1+alpha^2)^2],
    eta = 4 delta_beta - delta_gamma.

All quantities are `Fraction`s. Membership is tested by the absolute
standardized displacement from each exposed mean, using its positive reported
uncertainty. This independently agrees with the new oracle's inclusive lower
and upper rational inequalities for all 39 band pairs (78 Boolean outputs).
The equivalent compact eta expression is

    2k[1+k-k(1-3k)z]/(1+k)^2.

This equality follows from beta_D = -k(1-3k)z and the explicitly imported PPN
response. It introduces no new observational or scalar-normalization premise.

The four singular records are checked against the exact required sequence:
zero, the exposed positive Cassini central value, -2 and -3. The inverse
k = -delta_gamma/(2+delta_gamma) gives the zero boundary, the denominator
singularity, and negative k for both remaining cases. The stored status labels
agree. In particular, a positive central gamma offset is not silently treated
as a physically admitted positive-k point estimate.

The changed-source verification completed with **5076 passed, zero failed**.
That count includes source preservation, detailed scientific-section identity,
old assertion identity and the 104 newly evaluated controls; it is not 5076 new
physics experiments. Complete checks and rational outputs are in
`AFFECTED_CHECK_RESULTS_v1.json` and
`INDEPENDENT_RATIONAL_OUTPUT_CONTROLS_v1.json`.

## Two exact copied-source challenges

The driver reuses the exact textual mutations from the immutable original
mutation plan. It copies all 13 declared inputs into each isolated case, changes
only the targeted source expression, computes fresh hashes for the actual copied
bytes, and runs that copied source once. No assertion or tolerance is modified.
Both trials exit 1 after writing full results; both have empty stderr and no
timeout. All input files remain unchanged during execution.

| Exact mutation | Passed | Failed | Mathematical detection |
|---|---:|---:|---|
| Shared producer membership returns `True, True` | 2022 | 21 | Independent rational membership checks |
| Replace all four singular records by an empty list | 2036 | 1 | Exact required singular census |

All 13 source-identity checks pass in each trial. Thus neither failure is a
stale-hash or missing-file rejection.

The membership mutation again changes exactly 21 false flags to true: ten
null-family Cassini, seven diagnostic Cassini and four diagnostic LLR values.
The 21 newly independent comparisons now identify all 21 incorrect flags.
Every original non-source assertion still passes and is identical, showing why
the added independent oracle is needed.

Deleting the four singular records removes six per-row classification checks
(four status checks and two negative-k checks), so that mutant contains 2037
checks rather than 2043. Its census fails even though no row remains to visit.
The lower assertion total is explicitly retained; it is not reported as a
2043-check execution. All seven other scope/scientific sections are unchanged.
The output comparison has one list-length difference representing four missing
records, not one missing record.

`MUTATION_EVIDENCE_VERIFICATION_v1.json` independently inspects the completed
trial files, exact source substitutions, all fresh hashes, output differences,
old assertion identities and failure names. It performs no rerun. Full source,
diff, freeze, launch, result, execution and raw failure output are retained for
both trials.

## Disposition and limits

R1 (shared membership oracle) and R2 (missing singular census) from the immutable
v2 review are **closed for this v3 source and supplied grid**. No additional
material correction was found in the affected source. The original independent
6498/0 calculation continues to support the unchanged unmodified output and was
not rerun for this review.

The original author v1 endpoint-search failure remains in the original review's
verified evidence closure. It is not overwritten or relabelled. No reviewer
calculation or mutation execution encountered an unexpected failure in this
affected check; the two intentional source corruptions produced genuine
mathematical assertion failures as documented above.

These checks do not independently test the processed Cassini or LLR inputs,
derive a new PPN apparatus bridge, establish compact-body applicability, prove
global stability, or certify arbitrary future source mutations. The prior
review's finite-range, fixed-theory, long-range and weak-body qualifications
remain in force. No new primary-source claim is introduced here; the original
primary reading ledger is retained through its verified receipt.

The affected review wrote only its own directory and changed no author source,
earlier review artifact, Git state or campaign setting. The final receipt binds
all exact current/snapshot inputs and every review-owned source and evidence
file, without a self-referential hash.
