#!/usr/local/bin/python3
"""Bind this completed affected review; no science or mutation reruns."""
from pathlib import Path
import datetime as dt, hashlib, json, platform, subprocess
O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def item(p):return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
freeze=read(O/'SOURCE_FREEZE_v1.json')
prior=read(O/'snapshots/independent_numerical_review/FINAL_RECEIPT_v1.json')
affected=read(O/'AFFECTED_CHECK_RESULTS_v1.json')
mutations=read(O/'MUTATION_RESULTS_v1.json')
oldfiles={}
for r in prior['original_snapshot_pairs']:
    for kind in ['original','snapshot']:oldfiles[r[kind]['path']]=r[kind]['sha256']
for r in prior['review_artifacts']:oldfiles[r['path']]=r['sha256']
for p,h in oldfiles.items():assert sha(Path(p))==h
for r in freeze['sources']:assert sha(Path(r['path']))==r['sha256']==sha(Path(r['snapshot']))
save(O/'READING_LEDGER_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),entries=[
    dict(scope='Full current v3 runner, exact added block and raw diff',method='Read complete source; independently compare all original function text/AST and reconstruct entire unchanged source after removing only the inserted block.'),
    dict(scope='OUTPUT_CONTROL_CORRECTION_v3.json and SCIENTIFIC_OUTPUT_IDENTITY_v3.json',method='Read complete metadata and verify claims against pinned raw sources and parsed results.'),
    dict(scope='PROTOCOL_v2.json and OBSERVATION_INPUTS_v1.json',method='Read complete unchanged inputs; reconstruct affected rational observables and band inequalities without the producer or added compact oracle.'),
    dict(scope='Complete v2/v3 results and first-run evidence',method='Parse complete result trees, every original assertion, every new assertion, freeze, launch, execution and raw stdout/stderr; compare all scientific leaves and section bytes.'),
    dict(scope='Prior original independent report and 242 bound files',method='Read complete prior report and original mutation driver/plan; verify all receipt identities unchanged; reuse already completed independent positive 6498/0 science without rerun.'),
    dict(scope='Two new actual mutation sources and outputs',method='Exact original survivor substitutions; inspect full fresh input freezes, all result objects, failure output and recorded execution; independent output-difference verification without rerun.'),
    dict(scope='Unchanged handwritten action/PPN/calibration lineage',method='Current 13-input source closure and prior receipt bind exact previously reviewed bytes; no new handwritten or primary-source review claimed.'),
    dict(scope='External primary material',method='No fresh retrieval in this narrow changed-code check. Original reading record remains in prior verified receipt; no new empirical claim or apparatus review.'),
],python=platform.python_version(),author_source_edits=False,formal_audit=False,new_empirical_tests=0))
save(O/'REVIEW_EXECUTION_v1.json',dict(affected_check=dict(command=['/usr/local/bin/python3','verify_affected_v3.py'],exit_code=0,tool_chunk='6822f8',stdout=str(O/'affected_check_stdout_v1.txt'),stderr=str(O/'affected_check_stderr_v1.txt'),counts=affected['counts']),mutation_driver=dict(command=['/usr/local/bin/python3','run_two_mutations_v1.py'],exit_code=0,tool_completion_chunk='4eb7df',trials=2),mutation_evidence_check=dict(command=['/usr/local/bin/python3','verify_mutation_evidence_v1.py'],exit_code=0,tool_chunk='ad8292'),unexpected_reviewer_failures=[],positive_science_rerun=False,original_v1_failure='Preserved in original review and reverified through its complete immutable receipt.',intentional_failures='Both copied-source mutations exit 1 from added mathematical checks; raw failures preserved.'))
pids=[read(O/'MUTATION_PLAN_v1.json')['driver_pid']]
pids += [read(p)['pid'] for p in (O/'mutations').glob('*/LAUNCH.json')]
ps=subprocess.run(['ps','-p',','.join(map(str,pids)),'-o','pid=,ppid=,lstart=,command='],capture_output=True,text=True)
assert not ps.stdout.strip(),ps.stdout
save(O/'FINAL_PROCESS_CHECK_v1.json',dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),owned_pids=pids,ps_exit_code=ps.returncode,stdout=ps.stdout,stderr=ps.stderr,all_owned_pids_absent=True))
artifacts=[item(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='FINAL_RECEIPT_v1.json']
originals=[item(Path(p)) for p in sorted(oldfiles)]
bound={r['path']:r['sha256'] for r in originals+artifacts}
for r in freeze['sources']:
    bound[r['path']]=r['sha256'];bound[r['snapshot']]=r['sha256']
verified=all(sha(Path(p))==h for p,h in bound.items())
assert verified
receipt=dict(schema='independent-affected-source-receipt-v1',created_at=dt.datetime.now(dt.timezone.utc).isoformat(),scope='Weak-field inverse v3: two previously demonstrated output-coverage repairs only. No unmodified positive numerical rerun, formal audit, publication gate, or new empirical test.',disposition='R1 and R2 closed for frozen v3 source and supplied grid; original science unchanged.',author_source=item(Path(next(r['path'] for r in freeze['sources'] if Path(r['path']).name=='check_weak_field_inverse_v3.py' and 'evidence_v3' not in r['path']))),author_result=item(O/'snapshots/evidence_v3/RESULTS.json'),report=item(O/'AFFECTED_V3_REVIEW_v1.md'),prior_review_report=item(O.parent/'INDEPENDENT_NUMERICAL_REVIEW_v1.md'),prior_review_receipt=item(O.parent/'FINAL_RECEIPT_v1.json'),independent_counts=affected['counts'],continuity=dict(non_main_functions=12,original_non_source_assertions=1926,new_output_assertions=104,source_checks=13,unchanged_scope_science_sections=8,original_positive_calculation='6498/0 reused, not rerun'),mutations=[{k:r[k] for k in ['id','counts','exit_code','all_source_checks_pass','inputs_unchanged','source_sha256','result_sha256']} for r in mutations['mutations']],source_snapshot_pairs=freeze['sources'],original_review_bound_files=originals,review_artifacts=artifacts,verification=dict(unique_paths=len(bound),all_verified=verified,all_owned_pids_absent=True),limits=['Two targeted source challenges, not exhaustive mutation resistance.','Historical processed Cassini/LLR inputs remain exposed development data, not independent observation tests.','Prior finite-range, fixed-theory, long-range, weak-body and local-action qualifications remain.'],self_reference='This receipt excludes its own bytes; report and all other artifacts are bound.')
save(O/'FINAL_RECEIPT_v1.json',receipt)
print(json.dumps(dict(report=item(O/'AFFECTED_V3_REVIEW_v1.md'),receipt=item(O/'FINAL_RECEIPT_v1.json'),unique_bound_paths=len(bound),source_snapshot_pairs=len(freeze['sources']),review_artifacts=len(artifacts),all_verified=True),indent=2))
