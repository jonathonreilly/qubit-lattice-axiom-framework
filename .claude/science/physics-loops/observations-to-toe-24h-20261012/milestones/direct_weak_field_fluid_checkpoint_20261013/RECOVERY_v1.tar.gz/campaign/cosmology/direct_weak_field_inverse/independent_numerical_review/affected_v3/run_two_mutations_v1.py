#!/usr/local/bin/python3
"""Repeat only the two actual v2 survivors, against frozen v3 copies."""
from pathlib import Path
import datetime as dt, difflib, hashlib, json, os, subprocess, sys, time
O=Path(__file__).resolve().parent;S=O/'snapshots'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def read(p):return json.loads(p.read_text())
source=(S/'check_weak_field_inverse_v3.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='0882f0cd194aec4ce1295118ea034907dcfe25e65267429db4faa5b213433b56'
freeze=read(S/'evidence_v3/FREEZE.json')
snapshots={r['path']:Path(r['snapshot']) for r in read(O/'SOURCE_FREEZE_v1.json')['sources']}
old_plan=read(S/'independent_numerical_review/MUTATION_PLAN_v1.json')
mutations=[r for r in old_plan['mutations'] if r['id'] in ['m5_all_band_memberships_true','m6_omit_singular_records']]
assert len(mutations)==2
save(O/'MUTATION_PLAN_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),driver_pid=os.getpid(),source_sha256=hashlib.sha256(source.encode()).hexdigest(),mutations=mutations,scope='Exactly the two actual v2 survivors; no assertion or tolerance changes; fresh complete 13-input freezes.'))
results=[]
for mu in mutations:
    case=O/'mutations'/mu['id'];case.mkdir(parents=True)
    assert source.count(mu['old'])==1
    changed=source.replace(mu['old'],mu['new'],1)
    with (case/'MUTATION.diff').open('x') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen_v3',tofile=mu['id'])))
    inputs=[]
    for r in freeze['inputs']:
        original=Path(r['path']);snapshot=snapshots[str(original)]
        assert sha(snapshot)==r['sha256']
        dest=case/'sources'/original.parent.name/original.name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(changed.encode() if original.name=='check_weak_field_inverse_v3.py' else snapshot.read_bytes())
        inputs.append(dict(path=str(dest),sha256=sha(dest),original_path=str(original),original_sha256=r['sha256']))
        if original.name=='check_weak_field_inverse_v3.py':runner=dest
    save(case/'FREEZE.json',dict(inputs=inputs))
    start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
    with (case/'stdout.txt').open('x') as out,(case/'stderr.txt').open('x') as err:
        child=subprocess.Popen([sys.executable,str(runner),'--evidence',str(case)],stdout=out,stderr=err)
        save(case/'LAUNCH.json',dict(pid=child.pid,started_at=start,command=[sys.executable,str(runner),'--evidence',str(case)]))
        try:rc=child.wait(timeout=180);timeout=False
        except subprocess.TimeoutExpired:child.kill();rc=child.wait();timeout=True
    data=read(case/'RESULTS.json') if (case/'RESULTS.json').exists() else None
    sc=[r for r in data['checks'] if r['name'].startswith('source.')] if data else []
    record=dict(id=mu['id'],started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),seconds=time.monotonic()-tic,exit_code=rc,timeout=timeout,has_result=data is not None,counts=data['counts'] if data else None,source_checks_count=len(sc),all_source_checks_pass=len(sc)==13 and all(r['passed'] for r in sc),inputs_unchanged=all(sha(Path(r['path']))==r['sha256'] for r in inputs),failed_checks=[r for r in data['checks'] if not r['passed']] if data else [],source_sha256=sha(runner),result_sha256=sha(case/'RESULTS.json') if data else None)
    save(case/'EXECUTION.json',record);results.append(record)
    print(json.dumps({k:record[k] for k in ['id','exit_code','counts','all_source_checks_pass','inputs_unchanged']}),flush=True)
    save(case/'COMPLETE.json',dict(complete=True))
save(O/'MUTATION_RESULTS_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),mutations=results))
