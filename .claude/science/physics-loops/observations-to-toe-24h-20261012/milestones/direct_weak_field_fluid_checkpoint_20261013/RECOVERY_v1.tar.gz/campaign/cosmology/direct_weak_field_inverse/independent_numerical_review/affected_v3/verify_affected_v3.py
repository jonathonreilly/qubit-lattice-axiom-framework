#!/usr/local/bin/python3
"""Narrow source/output continuity and independent rational control review.

No author module is imported or executed by this check.  Original positive
numerical science is reused from the immutable v2 review, not recomputed.
"""
from pathlib import Path
from fractions import Fraction as F
import ast, datetime as dt, difflib, hashlib, json

O=Path(__file__).resolve().parent
S=O/'snapshots'
B=O.parent.parent
C=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def ck(name,passed,**detail):C.append(dict(name=name,passed=bool(passed),**detail))
def leaf_compare(a,b,path):
    if isinstance(a,dict):
        ck(path+'.keys',isinstance(b,dict) and list(a)==list(b))
        if isinstance(b,dict):
            for k in a:
                if k in b:leaf_compare(a[k],b[k],path+'.'+k)
    elif isinstance(a,list):
        ck(path+'.length',isinstance(b,list) and len(a)==len(b))
        if isinstance(b,list):
            for i,(x,y) in enumerate(zip(a,b)):leaf_compare(x,y,path+'.'+str(i))
    else:ck(path,a==b and type(a) is type(b))

freeze=read(O/'SOURCE_FREEZE_v1.json')
for r in freeze['sources']:
    ck('source.'+r['path'],sha(Path(r['path']))==r['sha256']==sha(Path(r['snapshot'])))
oldreceipt=read(S/'independent_numerical_review/FINAL_RECEIPT_v1.json')
oldfiles={}
for pair in oldreceipt['original_snapshot_pairs']:
    for kind in ['original','snapshot']:
        r=pair[kind];oldfiles[r['path']]=r['sha256']
for r in oldreceipt['review_artifacts']:oldfiles[r['path']]=r['sha256']
for p,h in oldfiles.items():ck('original_review_immutable.'+p,sha(Path(p))==h)

oldtext=(S/'check_weak_field_inverse_v2.py').read_text()
newtext=(S/'check_weak_field_inverse_v3.py').read_text()
trees=[ast.parse(x) for x in [oldtext,newtext]]
functions=[{n.name:n for n in t.body if isinstance(n,ast.FunctionDef)} for t in trees]
ck('source.function_names',list(functions[0])==list(functions[1]))
function_rows=[]
for name,node in functions[0].items():
    if name=='main':continue
    new=functions[1][name]
    exact=ast.get_source_segment(oldtext,node)==ast.get_source_segment(newtext,new)
    same=ast.dump(node,include_attributes=False)==ast.dump(new,include_attributes=False)
    ck('source.function_text.'+name,exact);ck('source.function_ast.'+name,same)
    function_rows.append(dict(name=name,text_identical=exact,ast_identical=same))
start=newtext.index('    # Independent exact response construction')
end=newtext.index('    passed=sum',start)
removed=newtext[:start]+newtext[end:]
ck('source.only_added_control_block',removed==oldtext)
actualdiff=''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile='check_weak_field_inverse_v2.py',tofile='check_weak_field_inverse_v3.py'))
ck('source.raw_diff_exact',actualdiff==(S/'OUTPUT_CONTROL_CORRECTION_v3.diff').read_text())

old=read(S/'evidence_v2/RESULTS.json');new=read(S/'evidence_v3/RESULTS.json')
science=[k for k in old if k not in ['counts','checks']]
identities=[]
for k in science:
    before=json.dumps(old[k],separators=(',',':')).encode()
    after=json.dumps(new[k],separators=(',',':')).encode()
    ck('science.serialized_exact.'+k,before==after)
    leaf_compare(old[k],new[k],'science.'+k)
    identities.append(dict(section=k,exact=before==after,sha256=hashlib.sha256(before).hexdigest(),bytes=len(before)))
oldcs=[r for r in old['checks'] if not r['name'].startswith('source.')]
newcs=[r for r in new['checks'] if not r['name'].startswith('source.')]
ck('checks.old_non_source_count',len(oldcs)==1926)
ck('checks.original_objects_unchanged',newcs[:len(oldcs)]==oldcs)
for i,(x,y) in enumerate(zip(oldcs,newcs)):
    ck('checks.original.'+str(i),x==y)
for label,d in [('v2',old),('v3',new)]:
    passed=sum(r['passed'] is True for r in d['checks'])
    ck('checks.'+label+'.count',d['counts']==dict(passed=passed,failed=len(d['checks'])-passed,total=len(d['checks'])))
    ck('checks.'+label+'.all_pass',all(r['passed'] is True for r in d['checks']))

af=read(S/'evidence_v3/FREEZE.json')
for r in af['inputs']:
    ck('author_freeze.'+r['path'],sha(Path(r['path']))==r['sha256']==sha(Path(r['snapshot'])))
sourcechecks=[r for r in new['checks'] if r['name'].startswith('source.')]
ck('author_freeze.check_census',{r['name'][7:] for r in sourcechecks}=={r['path'] for r in af['inputs']} and len(sourcechecks)==13)

p=read(S/'PROTOCOL_v2.json');obs=read(S/'OBSERVATION_INPUTS_v1.json')
expected=[]
def control(name,passed):expected.append(dict(name=name,passed=bool(passed)))
def separate_observables(k,z):
    # Reconstruct the original a,z action response first; do not use the new
    # compact k,z oracle or the producer membership implementation.
    a=k*(1+z)/(1+3*k*z)
    j=1+(1-3*a)*z
    alpha_squared=a/j
    beta=-a*(1-3*a)*z*(1+z)/(j*j)
    dg=-2*alpha_squared/(1+alpha_squared)
    db=beta*alpha_squared/(2*(1+alpha_squared)**2)
    return dg,4*db-dg
def bands(k,z,n):
    dg,eta=separate_observables(k,z)
    cm,ce=F(obs['Cassini']['mean']),F(obs['Cassini']['reported_uncertainty'])
    lm,le=F(obs['LLR']['mean']),F(obs['LLR']['reported_uncertainty'])
    return abs((dg-cm)/ce)<=n,abs((eta-lm)/le)<=n
membership_rows=[]
for i,row in enumerate(new['null_family']):
    k=F(p['null_k_grid'][i]);z=(1+k)/(k*(1-3*k))
    control('independent_output.null.band_census.'+str(k),[r['n'] for r in row['observation_bands']]==p['observation_band_multiples'])
    control('independent_output.null.parameters.'+str(k),F(row['z_exact'])==z and F(row['a_exact'])==(1-k)*(1+3*k)/4)
    for band in row['observation_bands']:
        c,l=bands(k,z,band['n'])
        membership_rows.append(dict(section='null_family',k=str(k),z=str(z),n=band['n'],expected_Cassini=c,expected_LLR=l,stored_Cassini=band['Cassini'],stored_LLR=band['LLR']))
        control('independent_output.null.Cassini.'+str(k)+'.'+str(band['n']),type(band['Cassini']) is bool and band['Cassini']==c)
        control('independent_output.null.LLR.'+str(k)+'.'+str(band['n']),type(band['LLR']) is bool and band['LLR']==l)
for i,row in enumerate(new['diagnostic']):
    k=F(p['diagnostic_k']);z=F(p['diagnostic_z_grid'][i])
    control('independent_output.diagnostic.band_census.'+str(z),[r['n'] for r in row['bands']]==p['observation_band_multiples'])
    for band in row['bands']:
        c,l=bands(k,z,band['n'])
        membership_rows.append(dict(section='diagnostic',k=str(k),z=str(z),n=band['n'],expected_Cassini=c,expected_LLR=l,stored_Cassini=band['Cassini'],stored_LLR=band['LLR']))
        control('independent_output.diagnostic.Cassini.'+str(z)+'.'+str(band['n']),type(band['Cassini']) is bool and band['Cassini']==c)
        control('independent_output.diagnostic.LLR.'+str(z)+'.'+str(band['n']),type(band['LLR']) is bool and band['LLR']==l)
required=[F(0),F(obs['Cassini']['mean']),F(-2),F(-3)]
control('independent_output.singular.census',[F(r['delta_gamma']) for r in new['singular']]==required and len(new['singular'])==4)
singular_rows=[]
for row in new['singular']:
    dg=F(row['delta_gamma'])
    if dg==0:status='GR_boundary_not_finite_positive_a';k=F(0)
    elif dg==-2:status='singular_inverse_denominator';k=None
    else:
        k=-dg/(2+dg)
        control('independent_output.singular.negative_k.'+str(dg),k<0)
        status='positive_central_value_outside_positive_k_model' if dg>0 else 'negative_reconstructed_k_outside_model'
    control('independent_output.singular.class.'+str(dg),row['status']==status)
    singular_rows.append(dict(delta_gamma=str(dg),inferred_k=None if k is None else str(k),expected_status=status,stored_status=row['status']))
added=newcs[len(oldcs):]
ck('added_control_census',len(expected)==104 and len(added)==104)
ck('added_control_objects',added==expected)
for row in expected:ck('independent.'+row['name'],row['passed'])
save(O/'INDEPENDENT_RATIONAL_OUTPUT_CONTROLS_v1.json',dict(memberships=membership_rows,singular=singular_rows,expected_controls=expected))
result=dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),scope='Narrow v3 source continuity and changed output controls; original positive 6498-check science not rerun.',source_sha256=sha(S/'check_weak_field_inverse_v3.py'),result_sha256=sha(S/'evidence_v3/RESULTS.json'),functions=function_rows,scientific_sections=identities,unchanged_original_non_source_assertions=len(oldcs),added_assertions=len(added),author_source_checks=len(sourcechecks),original_receipt_unique_paths=len(oldfiles),counts=dict(passed=sum(r['passed'] for r in C),failed=sum(not r['passed'] for r in C),total=len(C)),checks=C)
save(O/'AFFECTED_CHECK_RESULTS_v1.json',result)
print(json.dumps({k:result[k] for k in ['source_sha256','result_sha256','unchanged_original_non_source_assertions','added_assertions','author_source_checks','original_receipt_unique_paths','counts']},indent=2))
raise SystemExit(0 if all(r['passed'] for r in C) else 1)
