#!/usr/local/bin/python3
"""Inspect saved mutation executions only; never execute a runner."""
from pathlib import Path
import datetime as dt, hashlib, json
O=Path(__file__).resolve().parent;S=O/'snapshots'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def differences(a,b,path):
    found=[]
    if isinstance(a,dict):
        if not isinstance(b,dict) or set(a)!=set(b):return [dict(path=path,kind='keys')]
        for key in a:found+=differences(a[key],b[key],path+'.'+key)
    elif isinstance(a,list):
        if not isinstance(b,list) or len(a)!=len(b):return [dict(path=path,kind='list_length',expected=len(a),actual=len(b) if isinstance(b,list) else None)]
        for i,(x,y) in enumerate(zip(a,b)):found+=differences(x,y,path+'.'+str(i))
    elif a!=b or type(a) is not type(b):found.append(dict(path=path,kind='value',expected=a,actual=b))
    return found
base=read(S/'evidence_v3/RESULTS.json');source=(S/'check_weak_field_inverse_v3.py').read_text()
oldchecks=[r for r in base['checks'] if not r['name'].startswith(('source.','independent_output.'))]
plan=read(O/'MUTATION_PLAN_v1.json')
rows=[]
for mu in plan['mutations']:
    case=O/'mutations'/mu['id'];data=read(case/'RESULTS.json');freeze=read(case/'FREEZE.json');run=read(case/'EXECUTION.json')
    sc=[r for r in data['checks'] if r['name'].startswith('source.')]
    old=[r for r in data['checks'] if not r['name'].startswith(('source.','independent_output.'))]
    failed=[r for r in data['checks'] if not r['passed']]
    changes=[]
    for k in base:
        if k not in ['counts','checks']:changes+=differences(base[k],data[k],k)
    actual_source=case/'sources/direct_weak_field_inverse/check_weak_field_inverse_v3.py'
    assert actual_source.read_text()==source.replace(mu['old'],mu['new'],1)
    assert len(freeze['inputs'])==13==len(sc) and all(r['passed'] for r in sc)
    assert all(sha(Path(r['path']))==r['sha256'] for r in freeze['inputs'])
    assert old==oldchecks and len(old)==1926
    assert run['exit_code']==1 and run['has_result'] and not run['timeout']
    assert all(r['name'].startswith('independent_output.') for r in failed)
    assert (case/'stderr.txt').stat().st_size==0
    if mu['id']=='m5_all_band_memberships_true':
        assert len(changes)==21 and all(r['expected'] is False and r['actual'] is True for r in changes)
        assert len(failed)==21 and all('.Cassini.' in r['name'] or '.LLR.' in r['name'] for r in failed)
        assert len(data['checks'])==2043
    else:
        assert changes==[dict(path='singular',kind='list_length',expected=4,actual=0)]
        assert failed==[dict(name='independent_output.singular.census',passed=False)]
        assert len(data['checks'])==2037
    rows.append(dict(id=mu['id'],counts=data['counts'],fresh_source_checks=len(sc),source_hashes_pass=True,unchanged_original_non_source_assertions=len(old),mathematical_failure_names=[r['name'] for r in failed],scientific_output_changes=changes,stderr_empty=True,runner_sha256=sha(actual_source),result_sha256=sha(case/'RESULTS.json')))
save(O/'MUTATION_EVIDENCE_VERIFICATION_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),scope='Inspect completed copied-source trials only, no re-execution.',mutations=rows,all_verified=True))
print(json.dumps(dict(all_verified=True,mutation_counts=[dict(id=r['id'],counts=r['counts'],changes=len(r['scientific_output_changes'])) for r in rows]),indent=2))
