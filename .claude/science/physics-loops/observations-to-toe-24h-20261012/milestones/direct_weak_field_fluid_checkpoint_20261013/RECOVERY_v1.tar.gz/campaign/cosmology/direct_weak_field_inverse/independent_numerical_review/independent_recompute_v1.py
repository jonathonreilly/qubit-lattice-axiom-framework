#!/usr/local/bin/python3
"""Independent weak-field implementation review, without author imports."""
from pathlib import Path
from fractions import Fraction as Q
import datetime as dt, hashlib, json, platform, sys
import mpmath as mp
import sympy as sp
O=Path(__file__).resolve().parent
I=O/'snapshots/parent_files'
mp.mp.dps=110
checks=[]
def f(x):return mp.nstr(x,100)
def n(x):
    q=Q(str(x));return mp.mpf(q.numerator)/q.denominator
def check(label,ok,**details):checks.append(dict(name=label,passed=bool(ok),**details))
def close(label,actual,expected,tol='1e-60'):
    er=abs(actual-expected)/max(mp.mpf(1),abs(expected))
    check(label,er<=n(tol),actual=f(actual),expected=f(expected),error=f(er),tolerance=tol)
def exact(label,expression):
    v=sp.factor(sp.simplify(expression));check(label,v==0,remainder=str(v))
def save(path,x):
    with path.open('x') as h:json.dump(x,h,indent=2);h.write('\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
p=json.loads((I/'PROTOCOL_v2.json').read_text())
obs=json.loads((I/'OBSERVATION_INPUTS_v1.json').read_text())
author=json.loads((O/'snapshots/evidence_v2/RESULTS.json').read_text())

# Starting in t coordinates at fixed original a,z0:
# kinetic_tt=J/(a F^2), lnB=t-ln(F)/2; phi derivative
# is sqrt(a) F/sqrt(J) times the t derivative, with F,J positive.
aa=sp.symbols('a',positive=True);tt,zz=sp.symbols('t z',real=True)
F=1+zz*sp.exp(2*tt);J=1+(1-3*aa)*zz*sp.exp(2*tt)
D=lambda g:sp.sqrt(aa)*F/sp.sqrt(J)*sp.diff(g,tt)
alpha=sp.simplify(D(tt-sp.log(F)/2))
beta=sp.factor(D(alpha))
exact('action.alpha',alpha-sp.sqrt(aa)/sp.sqrt(J))
exact('action.beta',beta+aa*(1-3*aa)*zz*sp.exp(2*tt)*F/J**2)
GN=sp.exp(2*tt)*(1+alpha**2)/F
dGN=sp.simplify(D(sp.log(GN)))
exact('action.fixed_theory_G',dGN-2*alpha*(1+beta/(1+alpha**2)))

# Independent finite-coordinate route: r=1/sqrt(z), phi increases when r falls.
# ln G differs by a constant from the log of this rational expression.
rr=sp.symbols('r',positive=True)
ha=1-3*aa
logr=sp.log((ha+(1+aa)*rr**2)/((1+rr**2)*(ha+rr**2)))
op=-sp.sqrt(aa)*(1+rr**2)/sp.sqrt(rr**2+ha)
expr=logr;derivs=[]
for order in range(1,5):
    expr=sp.factor(op*sp.diff(expr,rr))
    derivs.append(expr)
df=sp.lambdify((aa,rr),derivs,'mpmath',cse=True)

def rational_response(a,z):
    j=1+(1-3*a)*z
    k=a/j
    beta=-a*(1-3*a)*z*(1+z)/(j*j)
    gamma=-2*k/(1+k)
    ppnb=beta*k/(2*(1+k)**2)
    return dict(k=k,beta_D=beta,delta_gamma=gamma,delta_beta=ppnb,
                eta=4*ppnb-gamma,G_N_ratio=(1+k)/(1+z))
def values(a,z):
    r=rational_response(a,z)
    out={k:f(n(v)) for k,v in r.items()}
    out['dlogG_dphi']=f(2*mp.sqrt(n(r['k']))*(1+n(r['beta_D'])/(1+n(r['k']))))
    return out
def admitted(a,z):
    # Exact eigenvalue signs, not floating thresholds.
    if a<=0 or 1+z<=0:return False
    return (1+(1-3*a)*z)/(1+z)**2>0
def band_flags(k,beta,ns):
    gamma=-2*k/(1+k);eta=2*k*(1+k+beta)/(1+k)**2
    gm,gs=Q(obs['Cassini']['mean']),Q(obs['Cassini']['reported_uncertainty'])
    em,es=Q(obs['LLR']['mean']),Q(obs['LLR']['reported_uncertainty'])
    return [dict(n=j,Cassini=bool(gm-j*gs<=gamma<=gm+j*gs),
                 LLR=bool(em-j*es<=eta<=em+j*es)) for j in ns]
forward=[]
for av in p['a_grid']:
 for zv in p['z_grid']:
    a,z=Q(av),Q(zv);ok=admitted(a,z)
    row=dict(a_label=av,z_label=zv,admitted=ok)
    if ok:
        row.update(values(a,z));row['inverse_degenerate']=a==Q(1,3)
    else:row['reason']='outside positive tensor/scalar kinetic domain'
    forward.append(row)
inverse=[]
for kv in p['inverse_k_grid']:
 for zv in p['z_grid']:
    k,z=Q(kv),Q(zv)
    row=dict(k_label=kv,z_label=zv)
    # Algebraic inversion a(1+3kz)=k(1+z), with both frame signs checked.
    if k<=0 or 1+z<=0 or 1+3*k*z<=0:
        row['status']='excluded_inverse_domain'
    else:
        a=k*(1+z)/(1+3*k*z)
        check('inverse.domain.'+kv+'.'+zv,admitted(a,z))
        if k==Q(1,3):
            row.update(status='degenerate_k_one_third',a_exact=str(a),
                       beta_D='0',delta_gamma='-0.5')
        else:
            r=rational_response(a,z)
            recovered_k=-r['delta_gamma']/(2+r['delta_gamma'])
            recovered_beta=2*(1+recovered_k)**2*r['delta_beta']/recovered_k
            recovered_z=-recovered_beta/(recovered_k*(1-3*recovered_k))
            recovered_a=recovered_k*(1+recovered_z)/(1+3*recovered_k*recovered_z)
            check('inverse.exact_response_roundtrip.'+kv+'.'+zv,
                  (recovered_k,recovered_z,recovered_a)==(k,z,a))
            row.update(status='identified_local_a_z',a_exact=str(a),a=f(n(a)),
                       recovered_a=f(n(recovered_a)),recovered_z=f(n(recovered_z)),**values(a,z))
    inverse.append(row)
singular=[
 dict(delta_gamma='0',status='GR_boundary_not_finite_positive_a'),
 dict(delta_gamma='2.1e-5',status='positive_central_value_outside_positive_k_model'),
 dict(delta_gamma='-2',status='singular_inverse_denominator'),
 dict(delta_gamma='-3',status='negative_reconstructed_k_outside_model')]
for row in singular:
 dg=Q(row['delta_gamma'])
 check('singular.response_domain.'+row['delta_gamma'],not(-2<dg<0))

def distance_closed(a,r):
    h=1-3*a
    Y=mp.sqrt(1+h/(r*r))
    return (mp.atanh(1/Y)-mp.sqrt(3*a)*mp.atanh(mp.sqrt(3*a)/Y))/mp.sqrt(a)
def bisect(fn,lo,hi):
    a,b=mp.mpf(lo),mp.mpf(hi);fa=fn(a);fb=fn(b)
    if fa*fb>=0:raise ValueError(('bracket',f(a),f(b),f(fa),f(fb)))
    for _ in range(420):
        mid=(a+b)/2;fm=fn(mid)
        if fm==0:return mid
        if fa*fm<0:b=mid
        else:a=mid;fa=fm
    return (a+b)/2

null=[];finite=[];distance_controls=[]
for kv in p['null_k_grid']:
 k=Q(kv);a=(1-k)*(1+3*k)/4;z=(1+k)/(k*(1-3*k))
 am,zm,km=n(a),n(z),n(k);r0=1/mp.sqrt(zm)
 resp=rational_response(a,z)
 check('null.exact_eta.'+kv,resp['eta']==0)
 check('null.exact_beta.'+kv,resp['beta_D']==-(1+k))
 row=dict(k_label=kv,a_exact=str(a),z_exact=str(z),a=f(am),z=f(zm),**values(a,z))
 # r-space chain-rule differentiation, before null substitution.
 first,second,third,fourth=df(am,r0)
 close('null.rspace_first.'+kv,first,0)
 close('null.rspace_second.'+kv,second,-32*km/(1-3*km))
 row['G_second']=f(second)
 masses=[]
 for nv in p['nu_grid']:
    nu=Q(nv)
    # Direct inherited physical origin Hessian, rather than null-family reduction.
    mass=(nu*(1+z)+12*a*z)/(1+(1-3*a)*z)
    check('null.mass_reduction.'+kv+'.'+nv,mass==nu+3*k*z*(nu+4) and mass>0)
    masses.append(dict(nu_label=nv,mass_squared=f(n(mass)),
      length_diagnostics=[dict(Hv_L_over_c=v,mL_over_c=f(mp.sqrt(n(mass))*n(v)))
                          for v in p['dimensionless_length_grid']]))
 row['masses']=masses
 row['observation_bands']=band_flags(k,resp['beta_D'],p['observation_band_multiples'])
 # Angular substitution r=tan(theta) yields an independent regular integral.
 remaining=mp.quad(lambda theta:mp.sqrt(mp.tan(theta)**2+1-3*am),
                   [0,mp.atan(r0)])/mp.sqrt(am)
 closed=distance_closed(am,r0)
 close('distance.angular_vs_closed.'+kv,remaining,closed)
 row['remaining_canonical_distance']=f(remaining)
 row['distance_over_sqrt_k']=f(remaining/mp.sqrt(km))
 null.append(row)
 distance_controls.append(dict(k=kv,remaining=f(remaining),closed=f(closed),
                               original_absolute_h='0.001',original_h_inside=bool(n('0.001')<remaining)))
 prior=None
 for hs in p['finite_difference_steps']:
    h=n(hs)*remaining
    # Solve remaining distance at two endpoints, rather than integrating u
    # from the origin and using the author's secant/findroot routine.
    targetp=remaining-h;targetm=remaining+h
    rp=bisect(lambda r:distance_closed(am,r)-targetp,r0/2,r0)
    rm=bisect(lambda r:distance_closed(am,r)-targetm,r0,2*r0)
    up=mp.log(r0/rp)/mp.sqrt(am);um=mp.log(r0/rm)/mp.sqrt(am)
    def lng(r):
        hh=1-3*am
        return mp.log((hh+(1+am)*r*r)/(zm*(1+r*r)*(hh+r*r)))
    numerical_first=(lng(rp)-lng(rm))/(2*h)
    numerical_second=(lng(rp)-2*lng(r0)+lng(rm))/(h*h)
    e1=abs(numerical_first);e2=abs(numerical_second-second)
    lead1=h*h*third/6;lead2=h*h*fourth/12
    close('fd.first_Taylor.'+kv+'.'+hs,numerical_first/lead1,mp.mpf(1),'0.01')
    close('fd.second_Taylor.'+kv+'.'+hs,(numerical_second-second)/lead2,mp.mpf(1),'0.01')
    if prior is not None:
        check('fd.first_convergence.'+kv+'.'+hs,e1<prior[0]/20 or e1<mp.mpf('1e-60'))
        check('fd.second_convergence.'+kv+'.'+hs,e2<prior[1]/20 or e2<mp.mpf('1e-60'))
    prior=(e1,e2)
    check('fd.domain.'+kv+'.'+hs,0<h<remaining and rp>0 and rm>0 and 0<am<mp.mpf(1)/3)
    finite.append(dict(k_label=kv,step_fraction=hs,h=f(h),remaining=f(remaining),
                       up=f(up),um=f(um),first=f(numerical_first),
                       second=f(numerical_second),second_error=f(e2),
                       first_leading=f(lead1),second_leading=f(lead2)))
bands=[];band_endpoint_controls=[]
gm,gs=Q(obs['Cassini']['mean']),Q(obs['Cassini']['reported_uncertainty'])
em,es=Q(obs['LLR']['mean']),Q(obs['LLR']['reported_uncertainty'])
for mult in p['observation_band_multiples']:
 lo,hi=gm-mult*gs,gm+mult*gs
 kmax=-lo/(2+lo)
 k=Q(p['diagnostic_k'])
 etalo,etahi=em-mult*es,em+mult*es
 base=2*k/(1+k); slope=-2*k*k*(1-3*k)/(1+k)**2
 zlower=(etahi-base)/slope;zupper=(etalo-base)/slope
 lower=max(zlower,Q(-1));upper_a=k*(1+zupper)/(1+3*k*zupper)
 row=dict(n=mult,gamma_low_exact=str(lo),gamma_high_exact=str(hi),
          k_max_exact=str(kmax),k_max=f(n(kmax)),diagnostic_k=str(k),
          eta_low_exact=str(etalo),eta_high_exact=str(etahi),
          z_lower_unrestricted_exact=str(zlower),z_lower_physical_exact=str(lower),
          z_lower_open=lower==Q(-1),z_upper_exact=str(zupper),a_upper_exact=str(upper_a))
 bands.append(row)
 check('band.gamma_endpoint.'+str(mult),-2*kmax/(1+kmax)==lo)
 check('band.eta_endpoints.'+str(mult),base+slope*zlower==etahi and base+slope*zupper==etalo)
 check('band.physical_open_lower.'+str(mult),lower==-1 and upper_a>0 and upper_a<Q(1,3))
 band_endpoint_controls.append(dict(n=mult,diagnostic_k_in_Cassini=bool(0<k<=kmax),
                                    eta_interval_nonempty=bool(lower<zupper),
                                    lower_open=True,upper_closed=True,
                                    z_upper=f(n(zupper)),a_upper=f(n(upper_a))))
diagnostic=[]
k=Q(p['diagnostic_k'])
for zv in p['diagnostic_z_grid']:
 z=Q(zv);a=k*(1+z)/(1+3*k*z);resp=rational_response(a,z)
 row=dict(k_label=str(k),z_label=zv,a_exact=str(a),**values(a,z))
 row['bands']=band_flags(k,resp['beta_D'],p['observation_band_multiples'])
 row['compactness_diagnostics']=[dict(U=v,beta_D_times_U=f(abs(n(resp['beta_D']))*n(v)))
                                for v in p['compactness_grid']]
 diagnostic.append(row)
reference=dict(forward=forward,inverse=inverse,singular=singular,null_family=null,
               null_finite_differences=finite,observation_bands=bands,diagnostic=diagnostic)
save(O/'INDEPENDENT_SCIENTIFIC_REFERENCE_v1.json',reference)
save(O/'DISTANCE_AND_BAND_CONTROLS_v1.json',dict(distance=distance_controls,bands=band_endpoint_controls))
def compare(got,want,path):
 if isinstance(want,dict):
    check(path+'.keys',isinstance(got,dict) and set(got)==set(want))
    if isinstance(got,dict):
        for k,v in want.items():
            if k in got:compare(got[k],v,path+'.'+k)
            else:check(path+'.missing.'+k,False)
 elif isinstance(want,list):
    check(path+'.length',isinstance(got,list) and len(got)==len(want),
          actual=len(got) if isinstance(got,list) else None,expected=len(want))
    if isinstance(got,list):
        for j,(x,y) in enumerate(zip(got,want)):compare(x,y,path+'.'+str(j))
 elif isinstance(want,bool) or want is None:
    check(path,got is want,actual=got,expected=want)
 else:
    try:a=n(got);b=n(want)
    except (ValueError,TypeError,ZeroDivisionError):check(path,got==want,actual=got,expected=want)
    else:close(path,a,b)
for k,v in reference.items():compare(author[k],v,'original.'+k)
check('original.check_count',author['counts']==dict(passed=1938,failed=0,total=1938))
check('original.check_names',len({q['name'] for q in author['checks']})==len(author['checks']))
for i,q in enumerate(author['checks']):
 check('assertion.original.'+str(i),q['passed'])
 if 'actual' in q and 'expected' in q and 'tolerance' in q:
    er=abs(n(q['actual'])-n(q['expected']))/max(mp.mpf(1),abs(n(q['expected'])))
    check('assertion.numeric.'+str(i),er<=n(q['tolerance']))
for q in json.loads((O/'SOURCE_FREEZE_v1.json').read_text())['files']:
 check('source.'+q['snapshot'],sha(Path(q['snapshot']))==q['sha256'])
out=dict(schema='independent_weak_field_inverse_review_v1',
 created_at=dt.datetime.now(dt.timezone.utc).isoformat(),source_sha256=sha(Path(__file__)),
 author_result_sha256=sha(O/'snapshots/evidence_v2/RESULTS.json'),
 counts=dict(passed=sum(q['passed'] for q in checks),failed=sum(not q['passed'] for q in checks),total=len(checks)),
 category_counts={x:sum(q['name'].startswith(x) for q in checks)
                  for x in ['action.','inverse.','singular.','null.','distance.','fd.','band.','original.','assertion.','source.']},
 checks=checks,versions=dict(python=platform.python_version(),mpmath=mp.__version__,sympy=sp.__version__))
save(O/'INDEPENDENT_RESULTS_v1.json',out)
# Compare saved mutants to the newly generated scientific oracle, not to
# their own formula/membership helpers. This does not rerun any mutant.
mut=[]
for path in sorted((O/'mutations').glob('*/RESULTS.json')):
 data=json.loads(path.read_text());start=len(checks)
 for k,v in reference.items():compare(data[k],v,path.parent.name+'.'+k)
 sub=checks[start:];del checks[start:]
 mut.append(dict(id=path.parent.name,counts=data['counts'],
    independently_detected_output_discrepancies=sum(not q['passed'] for q in sub),
    failures=[q for q in sub if not q['passed']]))
save(O/'MUTANT_OUTPUT_COMPARISON_v1.json',mut)
print(json.dumps(dict(counts=out['counts'],categories=out['category_counts'],
 mutation_output_counts=[dict(id=q['id'],differences=q['independently_detected_output_discrepancies']) for q in mut])))
sys.exit(int(out['counts']['failed']>0))

