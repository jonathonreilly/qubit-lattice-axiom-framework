#!/usr/local/bin/python3
"""Six targeted copied-source challenges, with complete fresh input freezes."""
from pathlib import Path
import json,hashlib,datetime as dt,difflib,subprocess,sys,time,os
O=Path(__file__).resolve().parent
S=O/'snapshots'
freeze=json.loads((S/'evidence_v2/FREEZE.json').read_text())
source=(S/'parent_files/check_weak_field_inverse_v2.py').read_text()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
mutations=[
dict(id='m1_omit_scalar_coordinate_normalization',
 old='return b, metric, log_b_prime/mp.sqrt(metric)',new='return b, metric, log_b_prime'),
dict(id='m2_confuse_betaD_with_delta_beta',
 old='    db = beta*k/(2*(1+k)**2)',new='    db = beta',expected_occurrences=2,replace_count=1),
dict(id='m3_fixed_k_G_derivative',
 old='    dlog = mp.diff(lambda w: mp.log(\n        coupling_at_u(w, a, z)[0]**2*(1+coupling_at_u(w, a, z)[2]**2)), u)/mp.sqrt(metric)',
 new='    dlog = 2*mp.sqrt(k)  # erroneous derivative with k held fixed'),
dict(id='m4_drop_excluded_forward_rows',old='            forward.append(row)',
 new='            if row["admitted"]:forward.append(row)'),
dict(id='m5_all_band_memberships_true',
 old='    return abs(dg-gm)<=n*gs, abs(eta-em)<=n*es',
 new='    return True, True'),
dict(id='m6_omit_singular_records',
 old='    singular=[\n        dict(delta_gamma="0",status="GR_boundary_not_finite_positive_a"),\n        dict(delta_gamma="2.1e-5",status="positive_central_value_outside_positive_k_model"),\n        dict(delta_gamma="-2",status="singular_inverse_denominator"),\n        dict(delta_gamma="-3",status="negative_reconstructed_k_outside_model")\n    ]',
 new='    singular=[]')
]
save(O/'MUTATION_PLAN_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
 driver_pid=os.getpid(),mutations=mutations,scope='Five requested error categories plus direct singular-record omission; no assertion or tolerance edits.'))
results=[]
for mu in mutations:
 case=O/'mutations'/mu['id'];case.mkdir(parents=True)
 assert source.count(mu['old'])==mu.get('expected_occurrences',1)
 changed=source.replace(mu['old'],mu['new'],mu.get('replace_count',1))
 with (case/'MUTATION.diff').open('x') as f:f.write(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='frozen_v2',tofile=mu['id'])))
 inp=[]
 for r in freeze['inputs']:
  old=Path(r['path'])
  src=S/'parent_files'/old.name if old.parent.name=='direct_weak_field_inverse' else S/'parent_inputs'/old.parent.name/old.name
  assert sha(src)==r['sha256']
  dest=case/'sources'/old.parent.name/old.name;dest.parent.mkdir(parents=True,exist_ok=True)
  raw=changed.encode() if old.name=='check_weak_field_inverse_v2.py' else src.read_bytes()
  with dest.open('xb') as f:f.write(raw)
  inp.append(dict(path=str(dest),sha256=sha(dest),original_path=str(old),original_sha256=r['sha256']))
  if old.name=='check_weak_field_inverse_v2.py':runner=dest
 save(case/'FREEZE.json',dict(inputs=inp))
 start=dt.datetime.now(dt.timezone.utc).isoformat();tic=time.monotonic()
 with (case/'stdout.txt').open('x') as out,(case/'stderr.txt').open('x') as err:
  child=subprocess.Popen([sys.executable,str(runner),'--evidence',str(case)],stdout=out,stderr=err)
  save(case/'LAUNCH.json',dict(pid=child.pid,started_at=start))
  try:rc=child.wait(timeout=180);timeout=False
  except subprocess.TimeoutExpired:child.kill();rc=child.wait();timeout=True
 data=json.loads((case/'RESULTS.json').read_text()) if (case/'RESULTS.json').exists() else None
 sc=[r for r in data['checks'] if r['name'].startswith('source.')] if data else []
 record=dict(id=mu['id'],started_at=start,ended_at=dt.datetime.now(dt.timezone.utc).isoformat(),
  seconds=time.monotonic()-tic,exit_code=rc,timeout=timeout,has_result=data is not None,
  counts=data['counts'] if data else None,source_checks_count=len(sc),
  all_source_checks_pass=len(sc)==12 and all(r['passed'] for r in sc),
  inputs_unchanged=all(sha(Path(r['path']))==r['sha256'] for r in inp),
  failed_checks=[r for r in data['checks'] if not r['passed']] if data else [],
  source_sha256=sha(runner),result_sha256=sha(case/'RESULTS.json') if data else None)
 save(case/'EXECUTION.json',record);results.append(record)
 print(json.dumps({k:record[k] for k in ['id','exit_code','has_result','counts','all_source_checks_pass']}),flush=True)
 save(case/'COMPLETE.json',dict(complete=True))
save(O/'MUTATION_RESULTS_v1.json',dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),mutations=results))

