# Stored-history first-correction diagnostic

Parent /root freezes this rule before evaluating the stored history. The new
canonical proof proposes C1=2(Vbar-sigma0)/(3 H_GR^2)+Tbar/3 with
Vbar=x^2/2+y^2/3, Tbar=[4 px^2/9+py^2/3]/D0 and
D0=1+2(x^2+y^2)/3. No coefficient is fitted here.

Evaluate C1 in80digit arithmetic on all241 rows of the already frozen
refined regular-limit solution and on each of the already completed split
k=1e-5 and1e-6 histories, reconstructing actual coordinate fields and
Einstein-e-fold velocities from the stored scales and physical entropy clock.
Use sigma0=3(H_GR^2-1)/2 from each stored background convention. Compare the
stored finite Hratio^2 with1+k C1 for both the limiting and finite-state
coefficient. Report maxima and all rows, with no finite-k pass threshold.

This is an exposed stored-array diagnostic, not a new ODE execution,
convergence certificate or data comparison. The arrays inherit floating-point
input precision even though subsequent arithmetic uses80digits. The symbolic
identity C1=2(Escalar-sigma0)/(3 H_GR^2),
Escalar=Vbar+H_GR^2 Tbar/2, is a separate arithmetic check. Standard fluid
conservation and the conditional transverse equations imply
Escalar'=-3 H_GR^2 Tbar and
(Escalar-sigma0)'=3[sigma0+R0 P_J-H_GR^2 Tbar].
At a matched ideal-speed initial state this derivative equals minus R0 times the
gas trace, -R0(rho_gas-3P_gas). This source identity does not prove a later trajectory bound.

Version2 clarifies the source normalization of the final trace identity only. The version1 computation and all frozen arrays are preserved unchanged.
