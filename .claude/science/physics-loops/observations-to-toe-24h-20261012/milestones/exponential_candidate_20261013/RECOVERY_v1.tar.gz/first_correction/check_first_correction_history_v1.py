#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json
import mpmath as mp

HERE=Path(__file__).resolve().parent
IC=HERE.parent/'direct_thermal_matter_bridge'
OUT=HERE/'first_correction_history_v1'

def coefficient(x,y,px,py,Hg):
    D=1+mp.mpf(2)/3*(x*x+y*y);sg=mp.mpf('1.5')*(Hg-1)
    V=x*x/2+y*y/3;T=(mp.mpf(4)/9*px*px+py*py/3)/D
    C=2*(V-sg)/(3*Hg)+T/3
    Cenergy=2*(V+Hg*T/2-sg)/(3*Hg)
    return C,abs(C-Cenergy),V+Hg*T/2-sg

def main():
    OUT.mkdir(exist_ok=False);mp.mp.dps=80
    files=[Path(__file__).resolve(),HERE/'FIRST_CORRECTION_PROTOCOL_v1.md',HERE/'evidence_v1/RESULTS.json',IC/'evidence_v3/histories/RESULTS.json']
    hashes=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    (OUT/'FREEZE.json').write_text(json.dumps(hashes,indent=2)+'\n')
    limit=json.loads(files[2].read_text());old=json.loads(files[3].read_text());ref=limit['histories'][1]['rows']
    f=lambda z:mp.mpf(str(z));fmt=lambda z:mp.nstr(z,45)
    limits=[];checks=[]
    for j,row in enumerate(ref):
        C,err,delta=coefficient(*[f(row[q]) for q in ['x','y','px','py','H2']])
        limits.append(dict(row=j,L=row['L'],C1=fmt(C),scalar_fluid_energy_difference=fmt(delta)))
        checks.append(dict(name='limit.energy_identity.'+str(j),passed=err<mp.mpf('1e-70'),error=fmt(err)))
    cases=[]
    for label in ['split_k1e-05','split_k1e-06']:
        history=next(x for x in old['histories'] if x['case']['id']==label);cfg=history['configuration'];k=f(cfg['k']);rows=[]
        for j,(a,b) in enumerate(zip(history['rows'],limits)):
            assert a['L']==b['L'];sx=f(cfg['xi'])*mp.exp(-mp.mpf('1.5')*f(a['NJ']));sy=f(cfg['yi'])*mp.exp(-2*f(a['NJ']))
            st=list(map(f,a['state']));C,err,delta=coefficient(sx*st[1],sy*st[2],sx*st[4],sy*st[5],f(a['HGR2']))
            obs=(f(a['Hratio'])**2-1)/k
            rows.append(dict(row=j,L=a['L'],C1_finite_state=fmt(C),C1_limit=b['C1'],observed_scaled_correction=fmt(obs),
                             residual_finite_coefficient=fmt(obs-C),residual_limit_coefficient=fmt(obs-f(b['C1']))))
            checks.append(dict(name=label+'.energy_identity.'+str(j),passed=err<mp.mpf('1e-70'),error=fmt(err)))
        cases.append(dict(case=label,rows=rows,max_abs_observed_scaled_correction=fmt(max(abs(f(z['observed_scaled_correction'])) for z in rows)),
                          max_abs_finite_state_residual=fmt(max(abs(f(z['residual_finite_coefficient'])) for z in rows)),
                          max_abs_limit_residual=fmt(max(abs(f(z['residual_limit_coefficient'])) for z in rows))))
    assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in hashes)
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Exposed stored-array diagnostic; no finite-k acceptance threshold, input precision remains that of original arrays.',inputs=hashes,limit=limits,cases=cases,checks=checks,counts=dict(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks)))
    (OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(counts=result['counts'],limit_max_abs_C1=fmt(max(abs(f(z['C1'])) for z in limits)),limit_final=limits[-1],cases=[{k:v for k,v in c.items() if k!='rows'} for c in cases]),indent=2))
    return bool(result['counts']['failed'])

if __name__=='__main__':raise SystemExit(main())
