# Focused stored-history first-correction review

The coefficient normalization, the energy derivative and the complete stored-array arithmetic agree with the supplied action and the frozen computation. One source-normalization ambiguity in the original protocol was corrected in a separately preserved v2. No numerical source or output change is needed within this scope. This is a focused independent check, not a formal audit or a finite-k convergence result.

## Source and execution scope

I read the complete FIRST_CORRECTION_PROTOCOL_v1.md, check_first_correction_history_v1.py, the parent freeze and all result rows/check objects. I froze the four declared inputs plus the freeze and result before independent calculations. The correction protocol v2 was separately frozen and read in full after the finding. The prior original-action derivation and affected weak-limit wording check are reused by exact identity. No canonical general-proof review, parent helper execution, ODE rerun, fit, external observation, network request or source edit was performed.

The parent's freeze matches the four input records in its result. All four current sources and their exact reviewer snapshots match those records. The result contains 241 limiting rows, two complete 241-row finite histories and 723 energy-rearrangement checks with the exact expected names and order. The refined limiting solution and both finite histories report successful completion; the k=1e-6 history explicitly retains its earlier v1 execution provenance. This review does not replace the separate original history reviews or certify their integration accuracy.

## Independent derivation and computation

Differentiating the complete Friedmann/Jordan readout at fixed physical calibration gives

    C1=[H_GR^2 Tbar+2Vbar-3(H_GR^2-1)]/(3H_GR^2).

This includes the negative fluid-normalization contribution from R(k)=R0/(1+k). The conformal readout and clock do not add a first-order term under u=k^2 v and p_u=O(k). The full derivation is in INDEPENDENT_DERIVATION_v1.md.

The independent implementation uses100-digit Decimal arithmetic, exact rational lowered-momentum controls, and fixed-state evaluations of the previously checked compact original action. It does not import the parent's runner. The first independent execution completed in 0.135s with 4,393 passing checks, no failing checks and empty stderr. This count includes source identities and complete arithmetic comparisons; it is not a count of independent physical tests. The maximum normalized discrepancy against the 45-digit serialized producer numbers is 4.3938e-45.

| Quantity | Independent value | Location |
|---|---:|---|
| Maximum absolute limiting C1 |0.04099150495628985|row36, L=3.570481971576531; C1 is negative|
| Maximum absolute observed scaled correction, k=1e-5 |0.04098840801987516|row36; negative|
| Maximum absolute observed scaled correction, k=1e-6 |0.04099097217993504|row36; negative|
| Maximum finite-state residual, k=1e-5 |1.614220817579879e-5|row3, L=0.2975401642980442; positive|
| Maximum finite-state residual, k=1e-6 |1.726401055416811e-6|row3; positive|
| Maximum limit-state residual, k=1e-5 |0.002003369892926913|row161, L=15.967988817328374; negative|
| Maximum limit-state residual, k=1e-6 |1.980080128337662e-5|row161; negative|

Residual means (Hratio^2-1)/k minus the indicated C1. Every row and all six reported case aggregates agree. The final limiting coefficient is-5.913464739045830e-8. The complete independent values, locations, coordinates and checks are saved in INDEPENDENT_RESULTS_v1.json.

The three generic exact rational energy controls give zero residual for both E'=-3H_GR^2 Tbar and Delta'=3(sigma0+R0 P_J-H_GR^2 Tbar). Eight direct full-action evaluations at four generic states and two small k values reproduce C1 with a maximum error/k of 0.644854. They are local coefficient controls, not history solves.

## Preserved finding and affected v2 confirmation

The original protocol said that the matched initial derivative equals minus the gas trace. With the thermodynamic trace used by the source, the precise identity is

    Delta'=-R0(rho_gas-3P_gas).

The factor R0 is necessary unless “trace” has already been defined to include source normalization. Exact rational controls with nonunit R0 expose this distinction. The parent preserved v1 and wrote FIRST_CORRECTION_PROTOCOL_v2.md. I read its complete text and checked the exact diff: only this clarification and a version footer were added. Its equation is correct, and it continues to deny a later-trajectory bound. The original runner, protocol v1, freeze, stored inputs and output remain unchanged. PROTOCOL_SOURCE_NORMALIZATION_CHANGE.diff preserves the change in this review directory.

There were no failed independent computations in this focused stage. The original wording finding, its nonunit-R0 witnesses and the correction are retained rather than erased. All upstream failed routes and earlier review evidence remain outside and unchanged by this task.

## Input precision and inference limits

The runner uses actual finite-history xi, yi and N_J to reconstruct fields, and the stored Einstein-e-fold velocities in the kinetic form. It pairs rows at the same stored L without pretending the finite and limiting entropy clocks or gas quadratures are identical. The parent used its recorded 80-digit arithmetic on binary64-derived input arrays; no new precision in the histories is obtained.

An exact-binary64 embedding instead of shortest-decimal embedding changes the observed scaled correction by at most 2.18363e-11 for k=1e-5 and 2.10404e-10 for k=1e-6. These are representation diagnostics, not error bars. The initially almost cancelling limiting energies leave a large absolute stored Delta but a coefficient of order1e-16; the exact matched-state identity should not be tested by treating that absolute rounding remainder as physical. Finite-state coefficients need not vanish initially because their initial fields contain R(k).

The 723 producer checks compare two algebraic forms of the same coefficient. They are appropriate arithmetic consistency checks; by themselves they do not establish the action expansion, its dynamical assumptions or finite-k error. Those distinctions are preserved in the protocol. The smaller residuals at smaller k are exposed descriptive values only. There is no predeclared finite-k acceptance threshold, new data comparison, empirical acceptance, convergence certificate, proof of initial-condition selection or replacement of unresolved stiff trajectories.

## Recovery and disposition

Every new parent file read for this task has an exact local snapshot and final identity in SOURCE_DISPOSITION_v1.json. Reused original-action evidence is separately pinned with its prior receipt and recovery paths in REUSED_SOURCE_IDENTITIES_v1.json. The independent plan, executed source, stdout/stderr, input freeze, full results and protocol diff are preserved. FINAL_RECEIPT_v1.json binds the report, derivation, dispositions and all review evidence. Writes were confined to independent_review/first_correction_v1.
