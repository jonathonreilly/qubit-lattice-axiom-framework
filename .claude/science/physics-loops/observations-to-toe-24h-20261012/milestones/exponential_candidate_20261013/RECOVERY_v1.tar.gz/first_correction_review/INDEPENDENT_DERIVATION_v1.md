# Independent first-correction calculation

This checks the stored-array application of the previously checked original curvature/fluid action. It does not repeat the separately assigned canonical general-proof review or solve any finite-k history.

## Normalization from the original action

Write B=H_GR^2=1+2 sigma0/3 and sigma0=R0 rho_J, with the physical calibration, R0 and H_v held fixed. The previously checked compact original-action identities give, on a fixed bounded coordinate set with u=k^2 v and p_u=k w,

    C_B=1+O(k^3),  N_J'=1+alpha_B p_u=1+O(k^2),
    sigma=C_B^2 sigma0/(1+k)=sigma0-k sigma0+O(k^2),
    U=3/2+k Vbar+O(k^2),  Q=K_i p_i^2=k Tbar+O(k^2),
    Vbar=x^2/2+y^2/3,
    Tbar=[4p_x^2/9+p_y^2/3]/[1+2(x^2+y^2)/3].

The full constraint and physical-clock readout are

    Hhat^2=2(sigma+U)/(3-Q),
    H_J^2/H_v^2=Hhat^2 (N_J')^2/C_B.

Thus

    (H_J^2/H_v^2)/B
      = [3B+2k(Vbar-sigma0)+O(k^2)]/[B(3-k Tbar+O(k^2))]
      = 1+k C1+O(k^2),
    C1=[B Tbar+2Vbar-3(B-1)]/(3B).

This is exactly 2(Vbar-sigma0)/(3B)+Tbar/3. The constant vacuum contribution 3/2 remains in B; it is not counted as a term proportional to k. The source normalization R(k)=R0/(1+k) produces the negative sigma0 term. The physical-clock factor first contributes beyond this order under the stated u,p_u bounds. The velocities entering the full kinetic form are Einstein-e-fold velocities; the limit identifies that clock with N_J. The finite-state diagnostic correctly reconstructs the stored Einstein velocities rather than replacing them by Jordan velocities.

The independent script evaluates the compact full action itself at four fixed generic states and k=1e-10,1e-14. It computes the quotient (H_J^2/(H_v^2 B)-1)/k before comparing with C1. The maximum error divided by k is 0.644854 across these eight evaluations. This checks the normalization at those states; it is neither a uniform remainder bound on the large-amplitude history nor a theorem about finite-k solutions.

## Energy derivative through lowered momenta

Let g_x=4/(9D), g_y=1/(3D), D=1+2(x^2+y^2)/3 and p_i=d phi_i/dN_J. The regular limit has lowered momenta pi_i=g_i p_i and equations

    pi_i'=-(3+h)pi_i+(1/2)sum_j(partial_i g_j)p_j^2-(partial_i Vbar)/B,
    B'=2hB=-2R0(rho_J+P_J).

Contracting with p_i and differentiating Tbar=sum_i g_i p_i^2 gives

    Tbar'=-2(3+h)Tbar-2 Vbar'/B.

Consequently, for E=Vbar+B Tbar/2,

    E'=Vbar'+B'Tbar/2+B Tbar'/2=-3B Tbar.

Conservation of the supplied Jordan fluid gives sigma0'=-3(sigma0+R0 P_J). Therefore

    Delta=E-sigma0,
    Delta'=3(sigma0+R0 P_J-B Tbar),
    C1=2Delta/(3B).

The independent rational controls construct the lowered-momentum equations and their metric derivatives at three generic states, including vanishing x or y. Both derivative residuals vanish as exact fractions. No parent acceleration helper is used.

## Matched initial state and its units

At an exactly matched limiting initial state,

    x^2=R0 rho_dust, y^2=R0 rho_gas,
    p_x=-3x/2, p_y=-2y, B=D,
    B Tbar=x^2+4y^2/3, E=sigma0.

With pressureless dust, the derivative is

    Delta'=3R0 P_gas-y^2=-R0(rho_gas-3P_gas).

It is the source-normalized gas trace. The raw thermodynamic gas trace lacks the factor R0. Two exact rational initial-state controls with R0=7/10 and 13/10 confirm this factor and explicitly differ from minus the raw trace. For example x=3/5, y=4/5, R0=13/10 and P_gas=1/10 give raw trace 5/26 and Delta'=-1/4.

This identity is about the exactly matched limiting state. The finite histories use R(k) in their initial fields, so their initial finite-state C1 is not required to vanish. Nor does the binary64 stored limiting state preserve exact equality of O(1e38) energies: its stored initial Delta is about 1.5222e22 while C1 is about 1.1667e-16. That arithmetic remainder must not be interpreted as a physical unmatched energy of that magnitude.

## Independent arithmetic and precision

All 241 limit rows and 482 finite rows are recomputed with Python Decimal at 100 digits. The coefficient is evaluated as the single quotient above, not by calling or importing the producer. For each finite row,

    sx=xi exp(-3 N_J/2), sy=yi exp(-2 N_J),
    (x,y,p_x,p_y)=(sx state[1],sy state[2],sx state[4],sy state[5]).

The stored actual scales and actual N_J are used. The pairing coordinate is the identical stored plasma log-temperature L. The256-node limiting gas convention and128-node finite convention are retained separately; neither is silently replaced by the other's normalization. Each row uses its own stored B. The observed scaled correction is (stored Hratio^2-1)/k. Every producer numerical field, all reported maxima and their locations are independently recomputed; the limit coefficient used for the producer's limit-residual field is its explicitly serialized 45-digit value.

The main comparison embeds inputs by their shortest decimal representations, matching the documented producer arithmetic. A separate calculation embeds each float's exact binary64 value. Their maximum differences in the observed scaled correction are 2.18363e-11 at k=1e-5 and 2.10404e-10 at k=1e-6. The corresponding finite-state C1 differences are at most 2.653e-15. These quantify representation sensitivity, not integration error, calibration uncertainty or a rigorous uncertainty interval. High precision arithmetic avoids adding appreciable rounding error to this calculation; it cannot recover precision absent from the stored input histories.
