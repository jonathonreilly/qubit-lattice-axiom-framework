#!/usr/bin/env python3
"""Reviewer-only stored-array arithmetic; no producer helper or integrator."""
from pathlib import Path
from decimal import Decimal, localcontext
from fractions import Fraction
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
SNAP = HERE / "source_snapshot"
D = Decimal


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dec(value, binary=False):
    return D.from_float(value) if binary and isinstance(value, float) else D(str(value))


def value(x, y, px, py, h2):
    metric_denominator = 1 + D(2) * (x*x + y*y) / 3
    kinetic = (D(4)*px*px/9 + py*py/3) / metric_denominator
    potential_twice = x*x + D(2)*y*y/3
    # The coefficient of k in the full numerator/denominator expansion.
    numerator = h2*kinetic + potential_twice - 3*(h2-1)
    return numerator/(3*h2), numerator/2


def finite_values(row, cfg, binary=False):
    n = dec(row["NJ"], binary)
    scales = [dec(cfg["xi"], binary)*(-D(3)*n/2).exp(),
              dec(cfg["yi"], binary)*(-2*n).exp()]
    st = [dec(z, binary) for z in row["state"]]
    vals = [scales[0]*st[1], scales[1]*st[2],
            scales[0]*st[4], scales[1]*st[5], dec(row["HGR2"], binary)]
    c, delta = value(*vals)
    observed = (dec(row["Hratio"], binary)**2-1)/dec(cfg["k"], binary)
    return c, delta, observed, vals


def rational_energy(x, y, px, py, r, rho, pressure):
    # Differentiate the lowered-momentum equations, not acceleration helpers.
    h2 = 1 + Fraction(2, 3)*r*rho
    h = -r*(rho+pressure)/h2
    den = 1 + Fraction(2, 3)*(x*x+y*y)
    den_dot = Fraction(4, 3)*(x*px+y*py)
    metric = [Fraction(4, 9)/den, Fraction(1, 3)/den]
    vel = [px, py]
    pos = [x, y]
    grad = [x, Fraction(2, 3)*y]
    kinetic = sum(g*p*p for g, p in zip(metric, vel))
    acceleration = []
    for z, g, p, force in zip(pos, metric, vel, grad):
        metric_dot = -g*den_dot/den
        lower_dot = -(3+h)*g*p - Fraction(2, 3)*z*kinetic/den - force/h2
        acceleration.append((lower_dot-metric_dot*p)/g)
    kinetic_dot = sum(2*g*p*acc-g*den_dot/den*p*p
                      for g, p, acc in zip(metric, vel, acceleration))
    h2_dot = -2*r*(rho+pressure)
    energy_dot = sum(g*p for g, p in zip(grad, vel)) + (h2_dot*kinetic+h2*kinetic_dot)/2
    sigma_dot = -3*r*(rho+pressure)
    return {"energy_residual": energy_dot+3*h2*kinetic,
            "difference_residual": energy_dot-sigma_dot-3*(r*rho+r*pressure-h2*kinetic),
            "difference_derivative": energy_dot-sigma_dot,
            "energy_difference": x*x/2+y*y/3+h2*kinetic/2-r*rho}


def raw_ratio(k, point):
    x, y, px, py, sigma0, v, w, nu = map(D, point)
    a = (1-k)*(1+3*k)/4
    alpha = a.sqrt()
    d = k*(1-3*k)
    u = k*k*v
    pu = k*w
    exponential = (2*alpha*u).exp()
    f = d+(1+k)*exponential
    den = 1+D(2)*(1+k)*(x*x+y*y)/3
    metric_u = d*(d+(1-3*a)*(1+k)*exponential)/(f*f)
    metric_x = 16*a*k/(9*f*den)
    metric_y = 4*a*k/(3*f*den)
    cb = 4*a*exponential/f
    ab = alpha*d/f
    s = (D(3)*(d+(1+k)*exponential**2)/2 + 2*a*k*x*x
         + 4*alpha*k*k*u*x*x + 8*a*a*u*u*x*x/k
         + D(4)*a*k*y*y/3 + nu*d*u*u/2)
    potential = 4*a*s/(f*f)
    sigma = cb*cb*sigma0/(1+k)
    q = metric_u*pu*pu+metric_x*px*px+metric_y*py*py
    hhat2 = 2*(sigma+potential)/(3-q)
    hgr2 = 1+D(2)*sigma0/3
    ratio = hhat2*(1+ab*pu)**2/(cb*hgr2)
    c, _ = value(x, y, px, py, hgr2)
    return (ratio-1)/k, c


def main():
    output = HERE / "INDEPENDENT_RESULTS_v1.json"
    assert not output.exists(), "Preserve an earlier execution rather than overwrite it"
    sources = []
    for name in ["INPUT_FREEZE_v1.json", "AFFECTED_INPUT_FREEZE_v2.json"]:
        sources.extend(json.loads((HERE/name).read_text())["sources"])
    frozen = [{"path": str(Path(r["snapshot_path"])), "sha256": digest(Path(r["snapshot_path"]))}
              for r in sources]
    frozen += [{"path": str(Path(__file__)), "sha256": digest(Path(__file__))},
               {"path": str(HERE/"INDEPENDENT_PLAN_v1.json"), "sha256": digest(HERE/"INDEPENDENT_PLAN_v1.json")}]
    (HERE/"EXECUTION_INPUTS_v1.json").write_text(json.dumps(frozen, indent=2)+"\n")
    assertions = []
    def check(name, passed, **detail):
        assertions.append(dict(name=name, passed=bool(passed), **detail))
    def near(name, actual, expected):
        error = abs(actual-expected)/max(D(1), abs(expected))
        check(name, error <= D("5e-44"), normalized_error=str(error))
        return error
    with localcontext() as ctx:
        ctx.prec = 100
        parent = json.loads((SNAP/"first_correction_history_v1/RESULTS.json").read_text())
        limit = json.loads((SNAP/"evidence_v1/RESULTS.json").read_text())
        finite = json.loads((SNAP/"external/histories/RESULTS.json").read_text())
        parent_freeze = json.loads((SNAP/"first_correction_history_v1/FREEZE.json").read_text())
        check("producer.result_matches_its_freeze", parent["inputs"] == parent_freeze)
        by_source = {x["source_path"]:x for x in sources}
        for row in parent_freeze:
            check("producer.input_identity."+row["path"], row["sha256"] == by_source[row["path"]]["sha256"])
        check("producer.check_census", len(parent["checks"]) == 723 and parent["counts"] == {"passed":723,"failed":0})
        for i, row in enumerate(parent["checks"]):
            check("producer.check_object."+str(i), row["passed"] is True and abs(D(row["error"])) < D("1e-70"))
        ref = limit["histories"][1]
        check("limit.refined_completed", ref["refined"] is True and ref["success"] is True)
        check("limit.census", len(ref["rows"]) == len(parent["limit"]) == 241)
        limit_rows = []
        max_row_error = D(0)
        limit_embedding = D(0)
        for i, (source, claimed) in enumerate(zip(ref["rows"], parent["limit"])):
            check("limit.site."+str(i), claimed["row"] == i and claimed["L"] == source["L"])
            args = [dec(source[q]) for q in ["x","y","px","py","H2"]]
            c, delta = value(*args)
            max_row_error = max(max_row_error, near("limit.C1."+str(i),D(claimed["C1"]),c),
                                near("limit.Delta."+str(i),D(claimed["scalar_fluid_energy_difference"]),delta))
            binary_c, _ = value(*[dec(source[q], True) for q in ["x","y","px","py","H2"]])
            limit_embedding = max(limit_embedding,abs(binary_c-c))
            limit_rows.append({"row":i,"L":source["L"],"C1":str(c),"Delta":str(delta)})
        cases = []
        check("cases.census", [x["case"] for x in parent["cases"]] == ["split_k1e-05","split_k1e-06"])
        for claimed_case in parent["cases"]:
            label = claimed_case["case"]
            history = next(h for h in finite["histories"] if h["case"]["id"] == label)
            cfg = history["configuration"]
            check(label+".completed", history["success"] is True)
            check(label+".census", len(history["rows"]) == len(claimed_case["rows"]) == 241)
            rows = []
            embedding = {q:D(0) for q in ["C1","observed","finite_residual"]}
            for i,(source,claimed,lim) in enumerate(zip(history["rows"],claimed_case["rows"],limit_rows)):
                check(label+".site."+str(i), claimed["row"] == i and source["L"] == lim["L"] == claimed["L"])
                c,delta,obs,coords = finite_values(source,cfg)
                lim_printed = D(parent["limit"][i]["C1"])
                vals = {"C1_finite_state":c,"C1_limit":lim_printed,"observed_scaled_correction":obs,
                        "residual_finite_coefficient":obs-c,"residual_limit_coefficient":obs-lim_printed}
                for key,v in vals.items():
                    max_row_error = max(max_row_error,near(label+"."+key+"."+str(i),D(claimed[key]),v))
                bc,_,bo,_ = finite_values(source,cfg,True)
                embedding["C1"] = max(embedding["C1"],abs(bc-c))
                embedding["observed"] = max(embedding["observed"],abs(bo-obs))
                embedding["finite_residual"] = max(embedding["finite_residual"],abs((bo-bc)-(obs-c)))
                rows.append(dict(row=i,L=source["L"],**{q:str(v) for q,v in vals.items()},
                                 source_coordinates=[str(z) for z in coords],Delta=str(delta)))
            mapping = {"max_abs_observed_scaled_correction":"observed_scaled_correction",
                       "max_abs_finite_state_residual":"residual_finite_coefficient",
                       "max_abs_limit_residual":"residual_limit_coefficient"}
            aggregates = {}
            for out_key,row_key in mapping.items():
                index = max(range(len(rows)),key=lambda j:abs(D(rows[j][row_key])))
                maximum = abs(D(rows[index][row_key]))
                max_row_error = max(max_row_error,near(label+"."+out_key,D(claimed_case[out_key]),maximum))
                aggregates[out_key] = str(maximum)
                aggregates[out_key+"_location"] = {"row":index,"L":rows[index]["L"],"signed_value":rows[index][row_key]}
            cases.append(dict(case=label,rows=rows,aggregates=aggregates,
                              binary64_embedding_max_difference={q:str(v) for q,v in embedding.items()}))
        rational_cases = [
            [".7","-.4",".2","-.9","1.3",".7",".1"],
            ["0",".3","-.2",".1",".4","2.1",".6"],
            ["1.1","0",".8","-.5","2",".05",".01"]]
        energy_controls = []
        for i,point in enumerate(rational_cases):
            result = rational_energy(*map(Fraction,point))
            for key in ["energy_residual","difference_residual"]:
                check("energy.exact."+str(i)+"."+key,result[key] == 0)
            energy_controls.append(dict(point=point,results={q:str(v) for q,v in result.items()}))
        initial_controls = []
        for i,(x,y,r,pressure) in enumerate([(Fraction(2),Fraction(3),Fraction(7,10),Fraction(1,5)),
                                              (Fraction(3,5),Fraction(4,5),Fraction(13,10),Fraction(1,10))]):
            rho = (x*x+y*y)/r
            result = rational_energy(x,y,-3*x/2,-2*y,r,rho,pressure)
            raw_gas_trace = y*y/r-3*pressure
            expected = -r*raw_gas_trace
            check("initial.energy_match."+str(i),result["energy_difference"] == 0)
            check("initial.source_normalized_trace."+str(i),result["difference_derivative"] == expected)
            check("initial.raw_trace_is_distinct."+str(i),result["difference_derivative"] != -raw_gas_trace)
            initial_controls.append({"x":str(x),"y":str(y),"R0":str(r),"raw_gas_trace":str(raw_gas_trace),
                                     "Delta_prime":str(result["difference_derivative"]),"expected":str(expected)})
        points = [[".7","-.4",".2","-.9",".91","1.1",".3","1"],
                  ["0",".3","-.2",".1",".84","-.5","-.4","2.25"],
                  ["1.1","0",".8","-.5",".1","2.3",".2","4"],
                  [".2",".9","-.3","-.6","1.7","0",".1",".7"]]
        full_action = []
        for i,point in enumerate(points):
            for ks in ["1e-10","1e-14"]:
                k = D(ks)
                observed,c = raw_ratio(k,point)
                error = abs(observed-c)/max(D(1),abs(c))
                check("full_action.first_derivative."+str(i)+"."+ks,error <= 1000*k,normalized_error=str(error))
                full_action.append(dict(point=point,k=ks,C1=str(c),full_constraint_difference_quotient=str(observed),
                                        normalized_error=str(error),normalized_error_over_k=str(error/k)))
        for pin in frozen:
            check("execution.input_unchanged."+pin["path"],digest(Path(pin["path"])) == pin["sha256"])
        for pin in sources:
            check("parent.input_unchanged."+pin["source_path"],digest(Path(pin["source_path"])) == pin["sha256"])
        largest = max(range(len(limit_rows)),key=lambda j:abs(D(limit_rows[j]["C1"])))
        result = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      scope="Independent Decimal/Fraction stored-array arithmetic and fixed-state original-action controls; no ODE or producer helper.",
                      inputs=frozen,precision_digits=100,maximum_normalized_row_discrepancy=str(max_row_error),
                      limit_max_abs_C1=str(abs(D(limit_rows[largest]["C1"]))),
                      limit_max_location={"row":largest,"L":limit_rows[largest]["L"],"signed_C1":limit_rows[largest]["C1"]},
                      limit_binary64_embedding_max_C1_difference=str(limit_embedding),limit=limit_rows,cases=cases,
                      exact_energy_controls=energy_controls,exact_initial_trace_controls=initial_controls,
                      full_action_first_derivative_controls=full_action,checks=assertions,
                      counts={"passed":sum(x["passed"] for x in assertions),"failed":sum(not x["passed"] for x in assertions)})
        output.write_text(json.dumps(result,indent=2)+"\n")
        print(json.dumps({k:v for k,v in result.items() if k not in ["inputs","limit","cases","checks"]},indent=2))
        print(json.dumps({"case_aggregates":[{"case":c["case"],"aggregates":c["aggregates"],
                          "binary64_embedding_max_difference":c["binary64_embedding_max_difference"]} for c in cases]},indent=2))
        return int(bool(result["counts"]["failed"]))


if __name__ == "__main__":
    raise SystemExit(main())
