The supplied three-scalar action can approach the GR expansion constraint while a scalar potential-curvature coefficient grows as the coupling decreases. This PR derives the uniform coefficient expansion on fixed compact scaled-state sets, the first physical Hubble correction, and the conditional transverse equations. It preserves the distinction between an instantaneous expansion and convergence of finite-coupling histories.

The action, universal matter coupling, dimensional normalization and bounded-state hypotheses are explicit candidate assumptions. The rapid coefficient is for fixed nonzero transverse field and is not a complete coupled eigenvalue. This establishes no finite-history error bound, quantum limit, empirical acceptance or TOE. No previously failed integration is repaired by this theorem.

- Claim type: `bounded_theorem`; actual surface: `conditional-support`.
- Trace: `frontier_discovery`; reachability to the observed TOE: `unknown_frontier`.
- The import exposed is the assumed small-field history scaling. This work derives its consequences; it does not derive that scaling from measured cosmology.
- Remaining work: finite-coupling solution bounds, fast-mode control, physical source/environment matching and independent empirical tests.

Validation: independent source derivation and 328 passing controls, with four actual defective source copies detected; actual canonical execution 510 passed/0 failed; independent final 23-path package check 2,001 passed/0 failed. Final independent source/gate mapping passed 125 controls; final UNIT preflight with cache passed. The pipeline, strict lint and changed-evidence checks all passed against main `583c699e859b64ff01c8bc92d1c04bdfe9994509`; the validation copy's final staged tree equals the submitted tree `eb8af86c1b245fc8b9b7cfb0c1191b11c3693e16`. Lint had no errors; its 33 warnings and 1,484 notices remain recorded.

The successful canonical execution was followed by a caller-side `AttributeError` while requesting cache status. The original failure and recovery from the actual existing successful cache are preserved; no replacement execution is claimed. These are source and mechanical checks, not a formal science audit. No merge or retained-status promotion is requested.

Artifacts:

- [Theorem and complete supplied action](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/docs/WEAK_SCALAR_LIMIT_BOUNDED_THEOREM_NOTE_2026-10-13.md)
- [Runner](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/scripts/weak_scalar_limit_2026_10_13.py)
- [Actual results](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/outputs/weak_scalar_limit_2026_10_13/RESULTS.json)
- [Assumptions and imports](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/outputs/weak_scalar_limit_2026_10_13/imports.json)
- [Handoff](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/.claude/science/physics-loops/weak-scalar-limit-20261013/HANDOFF.md)
- [Trace gate](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/.claude/science/physics-loops/weak-scalar-limit-20261013/TRACE_GATE.md)
- [Claim status](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/.claude/science/physics-loops/weak-scalar-limit-20261013/CLAIM_STATUS_CERTIFICATE.md)
- [Source review and exact recovery manifest](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/.claude/science/physics-loops/weak-scalar-limit-20261013/SOURCE_REVIEW_RECOVERY_v1.json)
- [Execution history and limits](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/40c809a34691c498faf38846da1f079e8fbb2e95/.claude/science/physics-loops/weak-scalar-limit-20261013/DELIVERY_RECORD_v1.md)

The final source, independent final-package/gate checks and actual validation logs are recoverable from the [campaign delivery manifest](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/42fb11a3dc0cbdec8037f44a2e59525b7cb0262b/.claude/science/physics-loops/observations-to-toe-24h-20261012/milestones/final_checked_reconstruction_20261013/RECOVERY_v1.json), under `weak_limit_package/`, `weak_limit_runtime/` and `weak_limit_final_source/`. Other exploratory physics in that archive is outside this PR's theorem and validation scope.
