#!/usr/bin/env python3
"""Bounded final identity check. No author execution, source edits, or Git mutations."""
from pathlib import Path
import ast, base64, datetime, difflib, hashlib, io, json, os, subprocess, tarfile
W = Path("/Users/jonBridger/.codex/worktrees/metric-clock-20261013/New Axioms Lets Go")
P = W / ".claude/science/physics-loops/metric-clock-reconstruction-20261013"
RT = Path("/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/metric_milestone")
O = RT / "final_identity_review_v3"
BASE = "516cb69d8487ff04f8a48e065d3dcbe71d7dd237"
HEAD = "2f451838e0d58df6b52024dd9db1062f60d8bf2b"
TREE = "c41c2cd4729ecdd57483ed62a782ec859cd47c52"
NOTE = "docs/METRIC_CLOCK_RECONSTRUCTION_BOUNDED_THEOREM_NOTE_2026-10-13.md"
RUNNER = "scripts/metric_clock_reconstruction_2026_10_13.py"
CACHE = "logs/runner-cache/metric_clock_reconstruction_2026_10_13.txt"
MANIFEST = "docs/audit/data/citation_graph_manifest.json"
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
def h(b): return hashlib.sha256(b).hexdigest()
def readj(f): return json.loads(Path(f).read_text())
def save(n,d):
    with (O/n).open("x") as f: json.dump(d,f,indent=2,sort_keys=True); f.write("\n")
def git(*a):
    return subprocess.check_output(["git", *a], cwd=W, env=ENV)
def paths(*a): return set(git(*a).decode().splitlines())
def archive(ref,names):
    b=git("archive","--format=tar",ref,"--",*sorted(names))
    with tarfile.open(fileobj=io.BytesIO(b),mode="r:") as t:
        return {m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
def assert_same(label,a,b):
    assert a==b, label
def asserts(b):
    return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(b)) if isinstance(n,ast.Assert)]
freeze=readj(RT/"FINAL_STAGING_v3.json")
final={x["path"]:x["sha256"] for x in freeze["paths"]}
initial_names=set(readj(RT/"INITIAL_STAGING_v1.json")["paths"])
previous=readj(P/"independent_port_review/PORT_REVIEW_RECEIPT_v1.json")
previous_disps=readj(P/"independent_port_review/REVIEWER_PORT_DISPOSITIONS_v1.json")
initial_pin={x["path"]:x["sha256"] for x in previous_disps["paths"]}
assert len(final)==328 and len(initial_names)==124
assert_same("HEAD",git("rev-parse","HEAD").decode().strip(),HEAD)
local_main=git("rev-parse","main").decode().strip()
origin_main=git("rev-parse","origin/main").decode().strip()
assert_same("origin/main",origin_main,BASE)
assert_same("initial commit parent",git("rev-parse","HEAD^").decode().strip(),BASE)
assert_same("freeze tree",freeze["index_tree"],TREE)
assert_same("index equals frozen tree",subprocess.run(["git","diff","--cached",TREE,"--quiet"],cwd=W,env=ENV).returncode,0)
assert_same("final path set",paths("diff","--cached","--name-only","--no-renames",BASE),set(final))
assert_same("initial path set",paths("diff","--name-only","--no-renames",BASE,HEAD),initial_names)
assert_same("initial review set",set(initial_pin),initial_names)
final_blobs=archive(TREE,final)
initial_blobs=archive(HEAD,initial_names)
assert_same("tree blob set",set(final_blobs),set(final))
for rel,sh in final.items():
    assert_same("tree:"+rel,h(final_blobs[rel]),sh)
    assert_same("working:"+rel,h((W/rel).read_bytes()),sh)
    assert_same("snapshot:"+rel,h((O/"final_snapshot"/rel).read_bytes()),sh)
for rel,b in initial_blobs.items(): assert_same("initial:"+rel,h(b),initial_pin[rel])
changed=[rel for rel in sorted(initial_names) if initial_blobs[rel]!=final_blobs[rel]]
added=sorted(set(final)-initial_names)
assert len(changed)==5 and len(added)==204
note_delta=readj(P/"evidence/FINAL_NOTE_METADATA_DELTA_v3.json")
old_note=initial_blobs[NOTE]; new_note=final_blobs[NOTE]
assert h(old_note)==note_delta["old_sha256"] and h(new_note)==note_delta["new_sha256"]
assert (P/note_delta["original_recovery"]).read_bytes()==old_note
actual_diff="".join(difflib.unified_diff(old_note.decode().splitlines(True),new_note.decode().splitlines(True),fromfile="reviewed_v2",tofile="metadata_v3"))
assert_same("note diff",actual_diff,note_delta["diff"])
removed=[s for s in actual_diff.splitlines() if s.startswith("-") and not s.startswith("---")]
assert removed==[], "No original note line is removed"
old_lines=old_note.decode().splitlines()
new_lines=new_note.decode().splitlines()
# Exact original order/content retained; additions are separately read as metadata/review record.
i=0
for line in new_lines:
    if i<len(old_lines) and line==old_lines[i]: i+=1
assert i==len(old_lines)
assert final_blobs[RUNNER]==initial_blobs[RUNNER]
assert final_blobs[MANIFEST]==initial_blobs[MANIFEST]
run=readj(P/"evidence/CANONICAL_FINAL_CACHE_RUN_v3.json")
record=run["result"][0]
cache=final_blobs[CACHE].decode()
header,streams=cache.split("----- stdout -----\n",1)
out,err=streams.split("----- stderr -----\n",1)
header_dict=dict(s.split(": ",1) for s in header.splitlines() if ": " in s)
fp=hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
nb=NOTE.encode()
fp.update(len(nb).to_bytes(8,"big"));fp.update(nb)
fp.update(len(new_note).to_bytes(8,"big"));fp.update(new_note)
assert header_dict["runner_sha256"]==h(final_blobs[RUNNER])
assert header_dict["input_fingerprint_sha256"]==fp.hexdigest()
assert header_dict["exit_code"]=="0" and header_dict["status"]=="ok"
assert record["exit_code"]==0 and record["status"]=="ok" and record["stderr"]==""
assert out.rstrip("\n")==record["stdout"].rstrip("\n") and err.strip()==""
assert "TOTAL: PASS=14 FAIL=0" in out
assert record["stdout"]==readj(P/"evidence/CANONICAL_CACHE_RUN_v1.json")["stdout"]
# Immutable review receipts/evidence including locally preserved archived originals.
for x in previous["reviewer_evidence_inventory"]:
    b=Path(x["path"]).read_bytes()
    assert h(b)==x["sha256"] and len(b)==x["bytes"], x["path"]
assert h((P/"independent_port_review/PORT_REVIEW.md").read_bytes())=="f2c4d5232603a3b0e3d2d627084c061be8b03c05b710524378971f0cb6245feb"
assert h((P/"independent_port_review/PORT_REVIEW_RECEIPT_v1.json").read_bytes())=="cd1007ee7626e53454975fe04b50696223da146409dad5ef88e67f8ee95f1d7c"
archive_file=P/"evidence/PORT_REVIEW_ARCHIVAL_BYTES_v1.json"
archive_review=readj(archive_file); archives=[]
for ix,e in enumerate(archive_review["files"]):
    decoded=base64.b64decode(e["data"],validate=True)
    assert h(decoded)==e["sha256"] and len(decoded)==e["bytes"]
    assert (W/e["original_path"]).read_bytes()==decoded
    assert e["original_path"] not in final
    assert e["original_path"] in freeze["excluded_exact_archived_originals"]
    display=(W/e["display_path"]).read_bytes()
    normalized=("\n".join(s.rstrip() for s in decoded.decode().splitlines()).rstrip()+"\n").encode()
    assert display==normalized
    assert e["display_is_original"] is False and e["original_stays_unmodified_locally"] is True
    assert e["display_path"].endswith(".DISPLAY.txt") and e["display_path"] in final
    dest=O/"decoded_archives"/e["original_path"]; dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open("xb") as f: f.write(decoded)
    archives.append({"original_path":e["original_path"],"original_sha256":e["sha256"],"bytes":len(decoded),
                     "archive_path":str(archive_file.relative_to(W)),"json_pointer":f"/files/{ix}/data",
                     "display_path":e["display_path"],"display_sha256":h(display),
                     "exact_decode_and_local_match":True,"display_whitespace_only":True,
                     "decoded_runtime_path":str(dest)})
assert len(archives)==3
older_archive=[]
for ix,e in enumerate(readj(P/"evidence/ARCHIVAL_BYTES_v1.json")["entries"]):
    b=base64.b64decode(e["base64"],validate=True)
    assert h(b)==e["sha256"] and len(b)==e["bytes"]
    older_archive.append({"original_relative_path":e["original_relative_path"],"sha256":h(b),"bytes":len(b),"json_pointer":f"/entries/{ix}/base64"})
mut_specs=readj(P/"evidence/mutations_v1/SPEC.json")["specs"]
mut_records=readj(P/"evidence/mutations_v1/RESULTS.json")
assert mut_records["complete"] and mut_records["all_detected"] and mut_records["original_runner_unchanged"]
assert len(mut_specs)==len(mut_records["rows"])==14
mutation_rows=[]
source=final_blobs[RUNNER]
for ix,(spec,row) in enumerate(zip(mut_specs,mut_records["rows"])):
    assert row["family"]==spec["family"] and source.decode().count(spec["old"])==1
    expected=source.decode().replace(spec["old"],spec["new"]).encode()
    live=Path(row["scratch_source"]).read_bytes()
    assert live==expected and h(live)==row["mutant_sha256"] and row["original_sha256"]==h(source)
    assert row["note_sha256"]==h(old_note)
    scratch_note=Path(row["scratch_source"]).parents[1]/NOTE
    assert scratch_note.read_bytes()==old_note
    exact="".join(difflib.unified_diff(source.decode().splitlines(True),live.decode().splitlines(True),fromfile="reviewed",tofile=row["family"]))
    assert exact==row["exact_diff"]
    assert asserts(source)==asserts(live), "Assertion changed: "+row["family"]
    stdout=(P/f"evidence/mutations_v1/{ix:02d}.stdout.txt").read_bytes()
    stderr=(P/f"evidence/mutations_v1/{ix:02d}.stderr.txt").read_bytes()
    assert h(stdout)==row["stdout_sha256"] and h(stderr)==row["stderr_sha256"]
    assert row["exit_code"]==1 and row["assertion_detected"] and stderr.decode().strip().endswith("AssertionError")
    assert str(row["scratch_source"]) in stderr.decode()
    dst=O/"mutation_source_snapshots"/f"{ix:02d}.py"; dst.parent.mkdir(exist_ok=True)
    with dst.open("xb") as f:f.write(live)
    mutation_rows.append({"family":row["family"],"mutant_sha256":h(live),"stdout_sha256":h(stdout),
                          "stderr_sha256":h(stderr),"exact_one_replacement":True,"all_assertions_unchanged":True,
                          "exit_code":1,"failure_kind":"AssertionError","source_snapshot":str(dst)})
# Parent-prepared evidence additions and all prior reviewed source are now tree-bound.
scope_by_changed={
    NOTE:"Retained all reviewed mathematical prose verbatim and in order; added only complete trace fields and factual review record with adopted six-refinement qualification.",
    CACHE:"Replaced initial source-bound successful cache with freshly executed successful cache bound to final note metadata; canonical runner and scientific stdout unchanged.",
    str((P/"HANDOFF.md").relative_to(W)):"Retained historical handoff and appended current source-review, mutation, metadata and pending-integration status; no science premise change.",
    str((P/"REVIEW_HISTORY.md").relative_to(W)):"Updated review and conformance record; retained historical facts and explicitly pending combined gate; no science premise change.",
    str((P/"CLAIM_STATUS_CERTIFICATE.md").relative_to(W)):"Updated scoped review disposition only; remains conditional-support with final metadata and combined gate pending at freeze."
}
assert set(changed)==set(scope_by_changed)
disps=[]
reviewer_initial_prefix=str((P/"independent_port_review/initial_snapshot").relative_to(W))
for rel in sorted(initial_names):
    original=h(initial_blobs[rel])
    recovery_rel=reviewer_initial_prefix+"/"+rel
    if recovery_rel in final:
        assert final_blobs[recovery_rel]==initial_blobs[rel]
        recovery={"kind":"exact_file","path":recovery_rel,"sha256":original}
        recovery_text=f"Exact initial bytes retained at {recovery_rel}, SHA256 {original}; also immutable commit {HEAD}:{rel}."
    else:
        ae=next(a for a in archives if a["original_path"]==recovery_rel)
        assert ae["original_sha256"]==original
        recovery={"kind":"base64_archive","path":ae["archive_path"],"sha256":h(archive_file.read_bytes()),
                  "json_pointer":ae["json_pointer"],"decoded_sha256":original,"decoded_bytes":ae["bytes"]}
        recovery_text=f"Exact initial bytes losslessly recoverable from {ae['archive_path']} at {ae['json_pointer']}, decoded SHA256 {original}; also immutable commit {HEAD}:{rel}. DISPLAY is not original."
    disps.append({"original_path":rel,"original_sha256":original,
                  "disposition":scope_by_changed.get(rel,"Retained byte-identically from independently reviewed initial constituent; its scoped source, preservation or supporting-evidence role remains unchanged."),
                  "recovery":recovery_text,"recovery_evidence":recovery,"final_path":rel,"final_sha256":final[rel]})
assert len(disps)==124
save("ORIGINAL_DISPOSITIONS_UNIT_V1.json",{
    "schema":"reviewer_owned_unit_receipt_original_dispositions/v1",
    "reviewer_session":"/root/direct_quantum_visibility_review",
    "original_constituent":{"head":HEAD,"delta_base":BASE,"tree":"3dde95713fafb4d48c72bcfc673d2d121018cdc5","original_path_count":124},
    "final_index_tree":TREE,"current_head":HEAD,
    "scope":"Same-session affected-source/metadata confirmation; supports UNIT_RECEIPT v1 /original_dispositions only; not a combined integration receipt.",
    "original_dispositions":disps})
results={
    "schema":"focused_final_identity_check/v1","at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "base":BASE,"head":HEAD,"index_tree":TREE,"local_main":local_main,"local_origin_main":origin_main,
    "final_bound_paths":328,"initial_constituent_paths":124,"added_paths":204,
    "changed_initial_paths":changed,"all_other_initial_paths_exact":119,
    "disk_snapshot_frozen_tree_and_index_match":True,
    "note_original_lines_retained_exact":len(old_lines),"note_additions":len(new_lines)-len(old_lines),
    "note_diff_record_exact":True,"runner_and_manifest_unchanged":True,
    "canonical":[{"path":rel,"sha256":final[rel],"bytes":len(final_blobs[rel])} for rel in [NOTE,RUNNER,CACHE,MANIFEST]],
    "cache":{"runner_sha256":h(source),"input_fingerprint_sha256":fp.hexdigest(),"status":"ok","exit_code":0,"families":14,
             "scientific_stdout_unchanged":True,"record_matches_cache":True,"author_run_replayed":False},
    "prior_reviewer_evidence_exact":len(previous["reviewer_evidence_inventory"]),
    "port_review_archives":archives,"earlier_original_archives":older_archive,
    "mutation_source_and_log_checks":mutation_rows,"mutation_executions_replayed":False,
    "assertions_and_tolerances_unchanged_in_mutants":True,"original_dispositions_count":len(disps),
    "scientific_rerun":False,"full_pipeline_run":False,"git_mutations":0,"source_edits":0}
save("FINAL_IDENTITY_RESULTS_v1.json",results)
print(json.dumps({k:results[k] for k in ["final_bound_paths","initial_constituent_paths","added_paths","changed_initial_paths","note_additions","prior_reviewer_evidence_exact","canonical"]},indent=2))
print("PASS: final tree, cache, archive, original dispositions and fourteen mutation-source/log checks.")

