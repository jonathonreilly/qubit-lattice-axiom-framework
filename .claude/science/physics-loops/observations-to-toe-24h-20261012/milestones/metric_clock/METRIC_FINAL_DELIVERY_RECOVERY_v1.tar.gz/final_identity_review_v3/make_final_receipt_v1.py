#!/usr/bin/env python3
"""Bind the finished same-session report without touching the worktree."""
from pathlib import Path
import hashlib,json,datetime,subprocess,os
W=Path("/Users/jonBridger/.codex/worktrees/metric-clock-20261013/New Axioms Lets Go")
P=W/".claude/science/physics-loops/metric-clock-reconstruction-20261013"
O=Path("/Users/jonBridger/.codex/campaigns/observations-to-toe-24h-20261012/metric_milestone/final_identity_review_v3")
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes()
 return {"path":str(p),"sha256":h(b),"bytes":len(b)}
def save(n,d):
 with(O/n).open("x") as f:json.dump(d,f,indent=2,sort_keys=True);f.write("\n")
results=json.loads((O/"FINAL_IDENTITY_RESULTS_v1.json").read_text())
freeze=json.loads((O/"FINAL_STAGING_v3.json").read_text())
prior=json.loads((P/"independent_port_review/PORT_REVIEW_RECEIPT_v1.json").read_text())
parent=json.loads((P/"evidence/PARENT_PORT_REVIEW_RECEIPT_v1.json").read_text())
disps=json.loads((O/"ORIGINAL_DISPOSITIONS_UNIT_V1.json").read_text())
initial=dict((r["original_path"],r["original_sha256"]) for r in disps["original_dispositions"])
final=dict((r["path"],r["sha256"]) for r in freeze["paths"])
expected_prior={r["path"]:r["sha256"] for r in prior["reviewer_evidence_inventory"]}
expected_prior.update({r["path"]:r["sha256"] for r in prior["canonical_identities"]})
assert len(expected_prior)==164
assert {r["path"]:r["sha256"] for r in parent["paths"]}==expected_prior
assert len(disps["original_dispositions"])==124 and len(initial)==124
for r in disps["original_dispositions"]:
 assert r["original_path"]==r["final_path"] and final[r["final_path"]]==r["final_sha256"]
 assert r["disposition"] and r["recovery"]
for rel,sha in final.items():assert h((W/rel).read_bytes())==sha
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
assert subprocess.run(["git","diff","--cached",results["index_tree"],"--quiet"],cwd=W,env=env).returncode==0
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=W,env=env,text=True).strip()==results["head"]
policy_paths=[
"docs/ai_methodology/skills/review-loop/references/UNIT_RECEIPT.md",
"docs/ai_methodology/REVIEW_LOOP_PR_CONFORMANCE_SPEC.md",
"docs/ai_methodology/skills/physics-loop/references/CLAIM_STATUS.md",
"docs/ai_methodology/skills/review-loop/references/AUDIT_COMPATIBILITY.md"]
policies=[]
for rel in policy_paths:
 b=(W/rel).read_bytes();dest=O/"reference_policy_snapshots"/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open("xb") as f:f.write(b)
 policies.append({"path":str(W/rel),"sha256":h(b),"bytes":len(b),"snapshot":str(dest),
 "reading_scope":"complete UNIT_RECEIPT reference" if rel.endswith("UNIT_RECEIPT.md") else "relevant status/conformance/authority passages; not a full policy audit"})
save("SUPPLEMENTAL_CONFIRMATION_v1.json",{
"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"parent_historical_receipt_exact_same_164_identities":True,
"final_328_disk_paths_still_match":True,"index_tree_still_matches":True,
"unit_original_disposition_rows_checked":124,
"reference_policy_pins":policies,
"base_qualification":"Frozen base and local origin/main are 516cb69d; local main is separately recorded, no remote fetch claimed.",
"source_ready":True,"combined_gate_run":False})
items=[pin(p) for p in sorted(O.rglob("*")) if p.is_file()]
receipt={
"schema":"same_session_final_affected_source_confirmation/v1",
"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"reviewer_session":"/root/direct_quantum_visibility_review",
"source_author":"parent /root",
"disposition":"PASS within stated conditional source/state/readout scope",
"source_ready":True,
"initial_constituent":disps["original_constituent"],
"final_index_tree":results["index_tree"],
"head_at_confirmation":results["head"],
"frozen_base":results["base"],
"local_refs_observed":{"main":results["local_main"],"origin/main":results["local_origin_main"]},
"remote_fetched_for_this_check":False,
"reference_qualification":"Local main differs from frozen base; downstream integration must bind its intended target exactly.",
"report":pin(O/"FINAL_AFFECTED_SOURCE_REPORT_v1.md"),
"initial_complete_report":pin(P/"independent_port_review/PORT_REVIEW.md"),
"initial_complete_receipt":pin(P/"independent_port_review/PORT_REVIEW_RECEIPT_v1.json"),
"final_freeze":pin(O/"FINAL_STAGING_v3.json"),
"independent_input_freeze":pin(O/"FINAL_INPUT_FREEZE_v1.json"),
"current_canonical_sources":results["canonical"],
"bound_source_paths":freeze["paths"],
"bound_source_path_count":328,
"original_dispositions":{"path":str(O/"ORIGINAL_DISPOSITIONS_UNIT_V1.json"),
"sha256":h((O/"ORIGINAL_DISPOSITIONS_UNIT_V1.json").read_bytes()),
"json_pointer":"/original_dispositions","count":124,
"format":"UNIT_RECEIPT v1-compatible reviewer-owned list; parent supplies overall unit receipt"},
"identity_check":pin(O/"FINAL_IDENTITY_RESULTS_v1.json"),
"executed_final_checker":pin(O/"check_final_identity_v3.py"),
"source_freeze_before_final_check":pin(O/"CHECK_SOURCE_FREEZE_v3.json"),
"execution":pin(O/"CHECK_EXECUTION_v3.json"),
"mutation_evidence_disposition":"All14 exact scratch-source hashes/diffs, raw logs and existing AssertionError outcomes verified; all assertions/tolerances unchanged; not re-executed.",
"archive_disposition":"Three exact original decodes/local matches; displays whitespace-only and not originals; prior two-file archive identity retained.",
"proof_and_code_disposition":"All original note lines preserved;25 metadata/review additions; entire runner and manifest unchanged.",
"old_review_evidence_unchanged":160,
"parent_historical_identity_mapping_confirmed":164,
"required_scientific_corrections":[],
"metadata_scope_corrections_required":[],
"historical_qualification_adopted":"Six author refinement rows inspected, not independently rerun by prior reviewer.",
"no_go_packet_triggered":False,
"no_go_reason":"Constructive conditional action/observable/clock relationship and bounded algebraic consequences; no failed-search or route-exhaustion claim.",
"governance":"Conditional source prose follows owning claim-status and audit-compatibility guidance; source classification does not confer audit ratification.",
"failure_history":pin(O/"OPERATIONAL_NOTES_v2.json"),
"reference_policy_pins":policies,
"reviewer_evidence_inventory_excludes_receipt_itself":True,
"reviewer_evidence_inventory":items,
"reviewer_evidence_file_count":len(items),
"full_pipeline_run":False,
"unit_preflight_run":False,
"combined_integration_gate_run":False,
"canonical_science_rerun":False,
"mutation_executions_rerun":False,
"formal_audit":False,
"landing_authorized":False,
"retained_status_conferred":False,
"new_framework_premise_adopted":False,
"author_source_edits":0,"git_mutations":0,"PR_mutations":0,"merges":0,
"workers_spawned":0,"model_or_settings_changes":0,
"fixed_deadline_utc":"2026-10-13T16:53:00Z",
"discovery_cutoff_utc":"2026-10-13T16:38:00Z",
"pending":["parent-owned unit preflight","combined gate on exact intended target","PR preparation if authorized checks pass"]
}
save("FINAL_AFFECTED_SOURCE_RECEIPT_v1.json",receipt)
for name in ["FINAL_AFFECTED_SOURCE_REPORT_v1.md","FINAL_AFFECTED_SOURCE_RECEIPT_v1.json","ORIGINAL_DISPOSITIONS_UNIT_V1.json","FINAL_IDENTITY_RESULTS_v1.json"]:
 print(name,h((O/name).read_bytes()))
print("Bound sources:",len(final),"Original dispositions:",len(initial),"Reviewer evidence files:",len(items))

