# Independent general kinetic background and harmonic-mode proof v1

Frozen before implementation and before any root GENERAL_KINETIC_PHOTON source exposure. The neutral input is the supplied action S=int sqrt(-g)[M^2 R/2+Q(zeta,Y)]+Sm[exp(2zeta)g], Y=-g^{ab}zeta_a zeta_b/2, and a pressureless material sector. Signature (-+++). This is a conditional source-equation construction, not an action inferred from observations. Proper Einstein time is t; a dot is d/dt. Set M=1 only when specializing. Power-law normalizations below use the supplied reference units t0=1.

1. Exact flat FLRW background.

Write v=zetadot, q=Q_Y, D=q+2Y Q_YY, Y=v^2/2, rho=rho_E. Einstein-frame dust mass is proportional to exp(zeta); its conserved bare-number density is n_b, with rho=exp(zeta)*constant*n_b. The equations are
  3 M^2 H^2 = rho + 2Yq-Q,
  -2 M^2 Hdot = rho+2Yq,
  rhodot+3Hrho = v rho,
  D vdot+3Hqv+2Y Q_Yzeta-Q_zeta = -rho.
The scalar sign follows from nabla_a(q nabla^a zeta)+Q_zeta-rho=0. The dust exchange sign follows independently from a particle action -int exp(zeta) ds_E.

For H=3/(2t), zeta=r log t with r=5/2, rho=1/(2t^2), Y=25/(8t^2), the Raychaudhuri equation forces q=2/5. For Q=K0 exp(c zeta)Y^n-V0 exp(-2zeta/r), equality of time powers requires c=2(n-1)/r=4(n-1)/5. If T=K0 exp(c zeta)Y^n, then q=nT/Y forces T=5/(4n t^2). Friedmann then gives
  K0=[5/(4n)](8/25)^n,
  V0=5(3n+1)/(4n).
Useful background derivatives are
  Q_Y=2/5; D=(2/5)(2n-1); Q_zeta=4/t^2;
  Q_Yzeta=8(n-1)/25;
  2Y Q_Yzeta-Q_zeta=2(n-3)/t^2;
  Q_zetazeta=4(n-5)/(5t^2).
These satisfy the scalar equation with -rho, not merely the two metric equations. For n>1/2, K0>0, Q_Y>0 and D=(2n-1)Q_Y>0 throughout the open domain Y>0, zeta finite. The principal scalar speed is c_s^2=1/(2n-1). Noninteger powers are smooth on Y>0, not necessarily through Y=0. The n=1/2 degeneracy is excluded; superluminality for 1/2<n<1 is not ruled out by the stipulated hyperbolicity conditions alone. No nonlinear global existence, UV or observational claim follows.

All n share the conformal background: a_J=exp(zeta)a_E=t^4, d tau=exp(zeta)dt=t^(5/2)dt, tau=2t^(7/2)/7 up to a constant, and rho_J=exp(-4zeta)rho_E=t^(-12)/2 proportional to a_J^(-3).

2. Full equal-Einstein-potential scalar/dust system.

Use ds_E^2=-(1+2U)dt^2+a^2(1-2U)dx^2, scalar perturbation x=delta zeta, bare-number contrast d=delta n_b/n_b, and covariant dust velocity u_i=partial_i V. Thus the explicitly defined coordinate velocity divergence is theta=a^(-2)Delta V. To linear order delta rho=rho(d+x), delta Y=v xdot-v^2 U. Define
  delta rho_Q=D delta Y+(2Y Q_Yzeta-Q_zeta)x,
  delta p_Q=q delta Y+Q_zeta x.
The linear equations (with spatially constant integration kernels separately excluded) are
  2M^2(Udot+H U)=qv x-rho V,                      [momentum]
  2M^2[a^(-2)Delta U-3H(Udot+H U)]=delta rho+delta rho_Q, [00]
  2M^2[Uddot+4H Udot+(2Hdot+3H^2)U]=delta p_Q,  [pressure trace]
  ddot=3Udot-a^(-2)Delta V,                       [bare-number continuity]
  Vdot+v V=-U-x.                                 [dust Euler]
Here ddot denotes the first time derivative of the contrast d, not its second derivative. The notation will be explicit in code. The unperturbed dust velocity is u^0=1, and u_i is a covariant spatial component; using a different velocity convention changes the Hubble factors.

An independent density-current variation gives a useful unexpanded scalar equation. Let delta q=Q_YY delta Y+Q_Yzeta x and Z=q xdot+v delta q. Then
  Zdot+3H Z-q a^(-2)Delta x-4qv Udot
  -2[(qv)dot+3Hqv]U-Q_Yzeta delta Y-Q_zetazeta x+delta rho=0.
Expanding gives
  D xddot+(Ddot+3HD)xdot-q a^(-2)Delta x
  +[(v Q_Yzeta)dot+3H v Q_Yzeta-Q_zetazeta]x
  -v(D+3q)Udot
  +[-(v(D+q))dot-3H v(D+q)+v^2 Q_Yzeta]U+delta rho=0.
This retains scalar, metric, source and dust terms. In the canonical q=D=constant limit it includes -4qv Udot and -2(Q_zeta-rho)U, as required by the sourced background equation. Hamiltonian or momentum elimination alone is not a normal-mode solution. The pressure, scalar, continuity and Euler equations remain obligations.

3. Nonconstant harmonic power modes of the entire supplied system.

Choose a fixed local nonconstant harmonic profile f(x), for example x1^2-x2^2, with Delta f=0 and nonzero traceless Hessian. This avoids treating the momentum equation as informative for a spatial constant. These functions are not nonzero global square-integrable Fourier k=0 waves; their amplitude must be small only on a declared finite spatial/time patch, with boundary completion unspecified.

Let U=U0 t^s f, x=x0 t^s f, d=d0 t^s f and V=V0mode t^(s+1)f. The background potential constant V0 is distinct from this mode amplitude. Put b=2n-1. The exact reduced amplitude rows are
  2(s+3/2)U0-x0+(1/2)V0mode=0,                       [momentum]
  (1/2)d0+[b s+2n-11/2]x0+[9s+16-5n]U0=0,          [00]
  2(s^2+5s+5)U0-(s+4)x0=0,                         [pressure]
  s(d0-3U0)=0,                                      [number]
  (s+7/2)V0mode+U0+x0=0,                            [Euler]
  [(2/5)b s(s+7/2)+2n+17/10]x0
      -[(2n+2)s+5n+2]U0+(1/2)d0=0.                 [scalar]

For s=0 there is a common mode with (U0,x0,d0,V0mode)=(1,5/2,-9/2,-1).
For s!=0 set U0=1, d0=3 and
  x0=2(s^2+5s+5)/(s+4), V0mode=2x0-4s-6.
The 00 residual is F(s)/(s+4), where
  F(s)=(s+5/2)[(2n-1)s(2s+7)+6].
Under these substitutions, pressure, momentum, Euler and number equations vanish, and the scalar residual is [(2s+5)/5] times the 00 residual. Hence all equations hold for
  s=-5/2, or s=(-7 +/- sqrt(49-48/(2n-1)))/4.
The shared s=-5/2 mode has x0=-5/3, d0=3, V0mode=2/3. s=-4 was divided out only after checking its original rows: pressure forces U0=0, continuity d0=0, momentum V0mode=2x0, and 00 forces x0=0 for n>1/2, so it supplies no nonzero solution.

For n=1 the two n-dependent powers are -3/2 and -2; their (x0,V0mode) are (-1/5,-2/5) and (-1,0). For n=3/2 the powers are -1/2 and -3, with (11/7,-6/7) and (-2,2). The common background therefore does not imply equal linear response. Nor does a shared common-mode sector identify n. The spatial Laplacian vanishes for these fixtures, so they are not scalar-speed measurements; the independent principal-symbol calculation supplies the speed.

For 1/2<n<97/98 the n-dependent powers are complex conjugates, giving real logarithmically oscillating combinations. Repeated powers occur at n=97/98 and n=11/10; the pure-power ansatz does not supply a complete basis there, and generalized log-time modes require separate treatment. No complete mode-basis or global-boundary assertion is made.

4. Independent implementation plan.

The proof above precedes code. Use direct symbolic action derivatives for the full background. Independently linearize the scalar current density and particle/number equations rather than relying only on the reduced amplitude rows. Check original metric/source/pressure/scalar/dust equations for the common modes and explicit n=1,3/2 fixtures; verify factorization for generic n and the excluded s=-4 branch. Preserve any algebraic or execution failure. All work is conditional mathematics, with no observation arrays, root imports, action-selection or formal-audit claim.
