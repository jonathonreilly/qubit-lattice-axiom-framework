# Real phase and sampled two-jet: focused integration comparison v1

This is a post-author-exposure integration check, not an independent discovery, formal audit, empirical test or action-selection result. Root retains authorship; the phase insight is attributed to the separate curvature checker. I read the complete new note, executable, 35-control result, pre-code freeze, execution receipt and empty stderr. I reread my frozen original proof/implementation and the previously checked general-kinetic action note. No new weak or KINETIC_CURVATURE source was opened. All 15 pre-author bindings remain unchanged, including the original 104/1 normalization failure and its narrow 105/0 repair.

## Findings and scope

No mathematical disagreement was found in the real-quadrature inversion or normalized jet chain rules. One physical-presentation ambiguity was reported and accepted by the author: a fixed **real** harmonic spatial pattern followed by taking the real part discards the imaginary temporal response. The two registered quadratures must actually be supplied, or the construction must use independently resolved real and imaginary spatial patterns. A concrete local choice is H=(x²-y²)+2i xy, so Re(P H)=t^-3(x²-y²)-2t^-1/2 xy. Both patterns are harmonic and linearly independent. The author's task response accepts this clarification for forthcoming canonical prose/controls; those future bytes are not certified by this v1 comparison. The already explicit absence of global boundary completion and a measured propagation speed is appropriate.

## Real inversion and original equations

For real U,U', write Xi=x+iy, Xi'=xp+iyp and V=vR+i vI. The coefficient matrix in columns (U',U) is [[x,xp],[y,yp]], with determinant Wc=x yp-y xp. Cramer's rule gives U=Im(conj(Xi)V)/Wc and U'=Im(conj(V)Xi')/Wc, with the displayed signs. For Xi=r exp(i theta), Wc=r² theta'. Both ratios are invariant under a common constant phase rotation. A time-dependent unregistered rotation contributes theta'|Xi|² to the determinant, so it cannot be silently used as observed phase information. The recovered derivative must still be compatible with the recovered function. No uniform conditioning follows from pointwise nonzero Wc.

On a connected interval without zeros of Xi, homogeneous solutions differ by C/Xi. If U must be real and Xi has two non-collinear phases, their common real-line condition forces C=0. For a real or fixed-phase Xi, the remaining constant is real up to that phase. The note's continuity/absolute-continuity qualification is sufficient for the separate internal-zero integral argument; it is not a noisy-data stability statement.

The constructed n=3/2 superposition uses exactly my pre-author full-action modes s=-3 and s=-1/2. A new bounded integration program substitutes the superposition in all six original equations: momentum, Hamiltonian, pressure, number continuity, Euler and the independently expanded scalar equation. Every residual vanishes. This last check uses my original expanded scalar operator, not the new author's flux expression. The same calculation gives

    Xi=(15/4)t^-10-(30/7)i t^-15/2,
    Wc=-(1125/28)t^-21.

Thus Xi never vanishes for positive normalized t and the realified local rank is nonzero. The author's directly source-bound 35/0 result records U=(4/5)t^7, derivative compatibility, density recovery and c_s²=1/2. I inspected that unchanged result and its receipt; I did not replay the author's aggregate. No global mode basis or actual observation is tested.

## Chain rules and dimensions

With physical-time prime, A'=Aq and Y=A²q²/2 imply Y'=A²q(q'+q²). From F=Q_Y/M² and E=Q_zeta/(M²A²), the ordinary two-variable chain rule gives

    F'/q=Q_Yzeta/M²+(A²Q_YY/M²)(q'+q²),
    (E'+2qE)/q=Q_zetazeta/(M²A²)+(Q_Yzeta/M²)(q'+q²).

These reproduce both displayed inverses. They require q nonzero, a sufficiently differentiable supplied/reconstructed background, and a genuine action whose mixed derivatives agree. I checked these identities separately without specifying one member of the power family. The three author direct-Q derivative fixtures and six vanishing cubic two-jet entries correspond to these formulas. For smooth lambda and y, lambda(zeta)[Y-y(zeta)]³ has vanishing full two-jet on the curve, while its third Y derivative is 6lambda. This proves sampled two-jet nonuniqueness, not global healthy completion for arbitrary lambda.

Taking zeta,A dimensionless and time measured in physical units, F and L=Q_Yzeta/M² are dimensionless; q has time^-1; E and Q_zetazeta/(M²A²) have time^-2; B=A²Q_YY/M² and U=S/R have time². Hence R U is dimensionless, as required by c_s²=F/(F+R U). The fixture's t powers use the previously supplied t0=1 reference units. Restoring x=t_E/t0 and A=A0 x^(5/2), the n=3/2 construction gives

    R=x^-7/(2 A0² t0²),
    U=(4/5) A0² t0² x^7,
    B=(8/125) A0² t0² x^7,
    L=4/25,
    Q_zetazeta/(M²A²)=-14 x^-7/(5 A0² t0²).

These restorations were checked exactly. The new formulas do not independently determine the absolute A0 or M scales, and do not restore a physical time calibration that has not been supplied. They identify normalized quantities along an admitted trajectory only; action values away from it, higher response, initial-state distributions and topology remain unrestricted. The note correctly says the separate weak metric-record test does not itself supply the required background derivatives.

## Executed evidence and limits

The new reviewer-owned post-exposure integration program has 17 exact checks, 17 passed and 0 failed, in a bounded bytecode-disabled run. Its source was frozen before this run. This count is separate from the author's 35 and the old independent 105; counts overlap and must not be summed as independent validation. The complete stdout, empty stderr, source freeze and execution receipt are preserved. There was no failed execution in this narrow check. The original normalization failure remains historical evidence.

Exact new-source hashes: note 8a55b4fdad79790428110067073c106e78652b3581f6b8d9ff88829a9e5e2b6c; author executable 13bc654cce52b42bd753a7897a9ac3d20b470170dceafe3ce73471af0574e04b; author controls ce03ec455701f43a1430fdc59e825598020e59757ac1df7442ca4a4717140a6e; receipt 950ac075e812bb0f531b29eac010dcfdd29b7e0ba9373d2bbdf23e05d10a3e59. The adjacent identity JSON binds every inspected source and this report. No source edits, Git operations, new observations, model changes, broad reruns or new author work occurred.
