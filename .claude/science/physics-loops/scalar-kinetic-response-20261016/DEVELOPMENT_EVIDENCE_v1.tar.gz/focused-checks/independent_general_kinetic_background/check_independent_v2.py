"""Independent full-action background and selected harmonic-mode controls."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json,hashlib,time
from pathlib import Path
start=time.monotonic();checks=[]
def norm(v):return s.factor(s.cancel(s.expand(v)))
def equal(name,a,b=0):
    v=s.simplify(a-b)
    checks.append({'name':name,'passed':v==0,'exact_residual':str(v)})
def truth(name,b,evidence):checks.append({'name':name,'passed':bool(b),'evidence':str(evidence)})
R=s.Rational
t=s.symbols('t',positive=True);n=s.symbols('n',positive=True)
zeta,Y=s.symbols('zeta Y',real=True,positive=True)
r=R(5,2);H=R(3,2)/t;a=t**R(3,2);v=r/t;rho=R(1,2)/t**2;Yb=v**2/2;zb=r*s.log(t)
c=R(4,5)*(n-1);K=R(5,4)/n*(R(8,25))**n;V0=R(5,4)*(3*n+1)/n
Q=K*s.exp(c*zeta)*Y**n-V0*s.exp(-R(4,5)*zeta)
def bg(vv):return s.simplify(s.powdenest(vv.subs({zeta:zb,Y:Yb},simultaneous=True),force=True))
qb=bg(s.diff(Q,Y));qY=bg(s.diff(Q,Y,2));qz=bg(s.diff(Q,Y,zeta));Qz=bg(s.diff(Q,zeta));Qzz=bg(s.diff(Q,zeta,2));Db=s.simplify(qb+2*Yb*qY)
equal('background_q',qb,R(2,5));equal('background_D',Db,R(2,5)*(2*n-1))
equal('background_Q_zeta',Qz,4/t**2);equal('background_Q_Yzeta',qz,R(8,25)*(n-1));equal('background_Q_zetazeta',Qzz,R(4,5)*(n-5)/t**2)
equal('full_background_Friedmann',3*H**2-rho-(2*Yb*qb-bg(Q)))
equal('full_background_Raychaudhuri',-2*s.diff(H,t)-rho-2*Yb*qb)
equal('full_background_dust_exchange',s.diff(rho,t)+3*H*rho-v*rho)
equal('full_background_scalar',Db*s.diff(v,t)+3*H*qb*v+2*Yb*qz-Qz+rho)
equal('sound_speed_squared',qb/Db,1/(2*n-1))
equal('principal_domain_factor',s.cancel((s.diff(Q,Y)+2*Y*s.diff(Q,Y,2))/s.diff(Q,Y)),2*n-1)
# Proper Jordan background dust conservation, independent clock conversion.
aJ=t**4;rhoJ=R(1,2)*t**(-12);At=t**R(5,2);HJ=(H+v)/At
equal('Jordan_scale_factor',At*a,aJ);equal('Jordan_dust_conservation',s.diff(rhoJ,t)/At+3*HJ*rhoJ)
equal('Jordan_elapsed_proper_time_derivative',s.diff(R(2,7)*t**R(7,2),t),At)
# Direct first-order metric Ricci calculation. Generic nonharmonic profile tests Laplacian terms.
xx,yy,zz=s.symbols('xx yy zz',real=True);coords=[t,xx,yy,zz]
f=xx**2+2*yy**2+3*zz**2+xx*yy
lap=lambda w:sum(s.diff(w,z,2) for z in coords[1:])
U=s.Function('U')(t);x=s.Function('x')(t);d=s.Function('d')(t);V=s.Function('V')(t)
g=s.diag(-1,a*a,a*a,a*a);gi=g.inv();h=s.diag(-2*U*f,-2*a*a*U*f,-2*a*a*U*f,-2*a*a*U*f);dgi=-gi*h*gi
G0={};G1={}
for A in range(4):
 for B in range(4):
  for C in range(4):
   G0[A,B,C]=s.simplify(sum(gi[A,L]*(s.diff(g[L,C],coords[B])+s.diff(g[L,B],coords[C])-s.diff(g[B,C],coords[L])) for L in range(4))/2)
   G1[A,B,C]=s.simplify(sum(dgi[A,L]*(s.diff(g[L,C],coords[B])+s.diff(g[L,B],coords[C])-s.diff(g[B,C],coords[L]))+gi[A,L]*(s.diff(h[L,C],coords[B])+s.diff(h[L,B],coords[C])-s.diff(h[B,C],coords[L])) for L in range(4))/2)
Ric0=s.zeros(4);Ric1=s.zeros(4)
for A in range(4):
 for B in range(4):
  Ric0[A,B]=s.simplify(sum(s.diff(G0[L,A,B],coords[L])-s.diff(G0[L,A,L],coords[B])+sum(G0[L,A,B]*G0[J,L,J]-G0[J,A,L]*G0[L,B,J] for J in range(4)) for L in range(4)))
  Ric1[A,B]=s.simplify(sum(s.diff(G1[L,A,B],coords[L])-s.diff(G1[L,A,L],coords[B])+sum(G1[L,A,B]*G0[J,L,J]+G0[L,A,B]*G1[J,L,J]-G1[J,A,L]*G0[L,B,J]-G0[J,A,L]*G1[L,B,J] for J in range(4)) for L in range(4)))
R0=s.simplify(s.trace(gi*Ric0));R1=s.simplify(s.trace(dgi*Ric0+gi*Ric1))
Ein0=Ric0-g*R0/2;Ein1=Ric1-h*R0/2-g*R1/2
mix1=s.simplify(dgi*Ein0+gi*Ein1)
equal('direct_metric_00_operator',mix1[0,0],6*H*(s.diff(U,t)+H*U)*f-2*U*lap(f)/a**2)
for i in range(1,4):
 equal(f'direct_metric_0{i}_operator',mix1[0,i],-2*(s.diff(U,t)+H*U)*s.diff(f,coords[i]))
 equal(f'direct_metric_spatial_{i}_pressure',mix1[i,i],2*(s.diff(U,t,2)+4*H*s.diff(U,t)+(2*s.diff(H,t)+3*H**2)*U)*f)
for i,j in [(1,2),(1,3),(2,3)]:equal(f'direct_metric_anisotropic_{i}{j}',mix1[i,j])
# Independent scalar density-current linearization, retaining nonzero spatial Laplacian.
e=s.symbols('e',real=True)
dY=(v*s.diff(x,t)-v*v*U)*f;dq=qY*dY+qz*x*f
sqrtg=a**3*(1-2*e*U*f);g00=-1+2*e*U*f
J0=s.expand(sqrtg*(qb+e*dq)*g00*(v+e*s.diff(x,t)*f))
J00=J0.coeff(e,0);J01=J0.coeff(e,1)
Ji1=[a*qb*x*s.diff(f,z) for z in coords[1:]]
Ecov1=s.simplify(s.diff(J01,t)/a**3+2*U*f*s.diff(J00,t)/a**3+sum(s.diff(Ji1[i],coords[i+1]) for i in range(3))/a**3+qz*dY+Qzz*x*f-rho*(d+x)*f)
scalar_expected=Db*s.diff(x,t,2)+3*H*Db*s.diff(x,t)+(2*n+R(6,5))*x/t**2-(2*n+2)*s.diff(U,t)/t-(5*n+2)*U/t**2+rho*(d+x)
equal('direct_current_full_scalar_operator',Ecov1,-scalar_expected*f+qb*x*lap(f)/a**2)
# Bare number continuity from the covariant number-current density.
nb=rho/s.exp(zb)
number0=s.expand(a**3*nb*(1-2*e*U*f)*(1+e*d*f)*(1-e*U*f)).coeff(e,1)
number_space=[a*nb*V*s.diff(f,z) for z in coords[1:]]
number_res=s.simplify((s.diff(number0,t)+sum(s.diff(number_space[i],coords[i+1]) for i in range(3)))/(a**3*nb))
equal('direct_number_current',number_res,(s.diff(d,t)-3*s.diff(U,t))*f+V*lap(f)/a**2)
# Independent particle-action variation identifies the covariant velocity convention.
w0,w1,w2=s.symbols('w0 w1 w2',real=True);ws=[w0,w1,w2];vis=s.symbols('v0 v1 v2',real=True)
particle=-s.exp(zb+e*x*f)*s.sqrt(1+2*e*U*f-a*a*(1-2*e*U*f)*sum(w*w for w in ws))
for i in range(3):
 mom=s.diff(particle,ws[i]).subs(dict(zip(ws,[e*q for q in vis])))
 equal(f'particle_covariant_momentum_{i}',s.diff(mom,e).subs(e,0),s.exp(zb)*a*a*vis[i])
 force=s.diff(particle,coords[i+1]).subs(dict(zip(ws,[e*q for q in vis])))
 equal(f'particle_force_{i}',s.diff(force,e).subs(e,0),-s.exp(zb)*(U+x)*s.diff(f,coords[i+1]))
equal('particle_covariant_velocity_friction',s.diff(s.exp(zb)*V,t)/s.exp(zb),s.diff(V,t)+v*V)
# Original full-action amplitude equations, assembled from Q derivatives above.
dy=v*s.diff(x,t)-v*v*U
rhoPert=rho*(d+x)+Db*dy+(2*Yb*qz-Qz)*x
pPert=qb*dy+Qz*x
rows={'momentum':2*(s.diff(U,t)+H*U)-qb*v*x+rho*V,
 '00':rhoPert+6*H*(s.diff(U,t)+H*U),
 'pressure':2*(s.diff(U,t,2)+4*H*s.diff(U,t)+(2*s.diff(H,t)+3*H**2)*U)-pPert,
 'number':s.diff(d,t)-3*s.diff(U,t),
 'Euler':s.diff(V,t)+v*V+U+x,
 'scalar':s.simplify(-(Ecov1-qb*x*lap(f)/a**2)/f)}
p=s.symbols('p',real=True);u0,x0,d0,wamp=s.symbols('u0 x0 d0 wamp',real=True)
subs={U:u0*t**p,x:x0*t**p,d:d0*t**p,V:wamp*t**(p+1)}
scale={'momentum':p-1,'00':p-2,'pressure':p-2,'number':p-1,'Euler':p,'scalar':p-2}
amplitude={name:s.simplify(expr.subs(subs).doit()/t**scale[name]) for name,expr in rows.items()}
b=2*n-1
expected={'momentum':2*(p+R(3,2))*u0-x0+wamp/2,
 '00':d0/2+(b*p+2*n-R(11,2))*x0+(9*p+16-5*n)*u0,
 'pressure':2*(p*p+5*p+5)*u0-(p+4)*x0,
 'number':p*(d0-3*u0),'Euler':(p+R(7,2))*wamp+u0+x0,
 'scalar':(R(2,5)*b*p*(p+R(7,2))+2*n+R(17,10))*x0-((2*n+2)*p+5*n+2)*u0+d0/2}
for name in rows:equal('derived_amplitude_'+name,amplitude[name],expected[name])
xratio=2*(p*p+5*p+5)/(p+4);wr=2*xratio-4*p-6
reduced={name:s.factor(expr.subs({u0:1,x0:xratio,d0:3,wamp:wr})) for name,expr in amplitude.items()}
F=(p+R(5,2))*(b*p*(2*p+7)+6)
equal('generic_00_polynomial_factorization',reduced['00'],F/(p+4))
equal('scalar_full_equation_redundancy_on_reduced_rows',reduced['scalar'],(2*p+5)*F/(5*(p+4)))
for name in ['momentum','pressure','number','Euler']:equal('generic_reduced_'+name,reduced[name])
# Selected powers checked against every original action-derived row, not only a root polynomial.
cases=[]
for nv,powers in [(s.Integer(1),[0,-R(5,2),-R(3,2),-2]),(R(3,2),[0,-R(5,2),-R(1,2),-3]),(R(3,4),[-R(7,4)+s.I*s.sqrt(47)/4])]:
 for pv in powers:
  if pv==0:xv=R(5,2);dv=-R(9,2);wv=-1
  else:xv=s.simplify(xratio.subs(p,pv));dv=3;wv=s.simplify(wr.subs(p,pv))
  values={n:nv,p:pv,u0:1,x0:xv,d0:dv,wamp:wv}
  for name,row in amplitude.items():equal(f'full_mode_n{nv}_p{pv}_{name}',row.subs(values))
  cases.append({'n':str(nv),'p':str(pv),'U':'1','x':str(xv),'d':str(dv),'V':str(wv),'cs_squared':str(1/(2*nv-1))})
# Same background does not make a canonical scalar-dependent mode a solution at n=3/2.
bad={n:R(3,2),p:-2,u0:1,x0:-1,d0:3,wamp:0}
equal('wrong_n_mode_00_failure_retained',amplitude['00'].subs(bad),-R(3,2))
equal('wrong_n_mode_scalar_failure_retained',amplitude['scalar'].subs(bad),-R(3,10))
# Singular algebra branch and collisions are not silently discarded.
equal('p_minus4_pressure_original',amplitude['pressure'].subs(p,-4),2*u0)
equal('p_minus4_00_after_other_rows',amplitude['00'].subs({p:-4,u0:0,d0:0,wamp:2*x0}),-(6*n+R(3,2))*x0)
equal('quadratic_repeated_threshold',49-48/(2*R(97,98)-1))
equal('adiabatic_collision_threshold',((2*n-1)*p*(2*p+7)+6).subs({n:R(11,10),p:-R(5,2)}))
result={'scope':'Independent symbolic full-action background and local harmonic-mode check; no author files or observations','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'controls':checks,'mode_fixtures':cases,'amplitude_rows':{k:str(v) for k,v in amplitude.items()},'constants':{'c':str(c),'K0':str(K),'V0':str(V0),'QY':str(qb),'D':str(Db),'sound_speed_squared':str(s.simplify(qb/Db))},'preserved_rejected_mode':{'n':'3/2','p':'-2','x':'-1','d':'3','V':'0','00_residual':'-3/2','scalar_residual':'-3/10','interpretation':'A canonical-mode assignment fails the noncanonical full equations; not empirical rejection'},'limitations':['No global harmonic boundary completion','No complete basis at repeated characteristic roots','Principal positivity only on Y>0; not nonlinear global well-posedness','Common background and two common modes do not imply equal full linear action','No direct sound-speed measurement from Delta=0 fixtures'],'elapsed_seconds':time.monotonic()-start}
print(json.dumps(result,indent=2));raise SystemExit(1 if result['failed'] else 0)
