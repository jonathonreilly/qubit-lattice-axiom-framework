"""Post-exposure narrow integration against independently frozen action equations."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import json,hashlib,time
from pathlib import Path
beg=time.monotonic(); rows=[]
def equal(name,a,b=0):
 r=s.factor(s.simplify(a-b));rows.append({'name':name,'pass':bool(r==0),'residual':str(r)})
R=s.Rational;t=s.symbols('t',positive=True)
H=R(3,2)/t;v=R(5,2)/t;rho=R(1,2)/t**2
P=t**-3+s.I*t**(-R(1,2));J=-2*t**-3+R(11,7)*s.I*t**(-R(1,2))
V=2*t**-2-R(6,7)*s.I*t**R(1,2);db=3*P
F=R(2,5);D=R(4,5);n=R(3,2)
dY=v*s.diff(J,t)-v*v*P
# These are the expanded original equations from PROOF_BEFORE_CODE_v1,
# not an import or replay of the author's new flux implementation.
equal('original_momentum',2*(s.diff(P,t)+H*P)-F*v*J+rho*V)
equal('original_00',D*dY+(2*n-6)*J/t**2+rho*(db+J)+6*H*(s.diff(P,t)+H*P))
equal('original_pressure',2*(s.diff(P,t,2)+4*H*s.diff(P,t)+(2*s.diff(H,t)+3*H*H)*P)-F*dY-4*J/t**2)
equal('original_number',s.diff(db,t)-3*s.diff(P,t))
equal('original_Euler',s.diff(V,t)+v*V+P+J)
equal('original_expanded_scalar',D*s.diff(J,t,2)+3*H*D*s.diff(J,t)+(2*n+R(6,5))*J/t**2-(2*n+2)*s.diff(P,t)/t-(5*n+2)*P/t**2+rho*(db+J))
A=t**R(5,2);prime=lambda z:s.diff(z,t)/A;q=v/A
Xi=s.factor(q*prime(J)-q*q*P-(prime(q)+q*q)*J)
equal('Xi_closed',Xi,R(15,4)*t**-10-R(30,7)*s.I*t**(-R(15,2)))
W=s.factor(s.im(s.conjugate(Xi)*prime(Xi)))
equal('W_closed',W,-R(1125,28)*t**-21)
# General chain rule with Y'=A² q(q'+q²), without substituting one Q.
aa,qq,qdot,bb,ll,ffdot,ee,eedot,zz=s.symbols('aa qq qdot bb ll ffdot ee eedot zz',nonzero=True)
ydot=aa**2*qq*(qdot+qq**2)
Fdot_actual=ll*qq+(bb/aa**2)*ydot
Edot_actual=zz*qq+ll*ydot/aa**2-2*qq*ee
equal('general_mixed_jet_chain',Fdot_actual/qq-bb*(qdot+qq**2),ll)
equal('general_second_zeta_chain',(Edot_actual+2*qq*ee)/qq-ll*(qdot+qq**2),zz)
# Unit restoration in the n=3/2 fixture; t is now dimensionless t_E/t0.
A0,t0=s.symbols('A0 t0',positive=True)
qs=R(5,2)/(A0*t0)*t**(-R(7,2));Rs=R(1,2)/(A0*t0)**2*t**-7
Us=R(4,5)*(A0*t0)**2*t**7
Bs=s.factor(Rs*Us/qs**2)
equal('dimensionful_B',Bs,R(8,125)*(A0*t0)**2*t**7)
equal('dimensionful_density_curvature',Rs*Us,R(2,5))
Es=4/(A0*t0)**2*t**-7
ps=lambda z:s.diff(z,t)/(A0*t0*t**R(5,2))
Ls=-Bs*(ps(qs)+qs*qs)
equal('dimensionful_mixed_jet',Ls,R(4,25))
equal('dimensionful_second_zeta_jet',(ps(Es)+2*qs*Es)/qs-Ls*(ps(qs)+qs*qs),-R(14,5)/(A0*t0)**2*t**-7)
# Realification: a real pattern loses the imaginary response, while two
# independent local harmonic spatial components preserve both coefficients.
x,y=s.symbols('x y',real=True);f=x*x-y*y;g=2*x*y
lap=lambda z:s.diff(z,x,2)+s.diff(z,y,2)
equal('two_harmonic_patterns',lap(f)+s.I*lap(g))
equal('complex_pattern_two_coefficients',s.re(P*(f+s.I*g)),t**-3*f-t**(-R(1,2))*g)
equal('single_real_pattern_discards_second_response',s.re(P*f),t**-3*f)
out={'scope':'Post-exposure integration controls, not independent discovery or author aggregate replay','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'passed':sum(r['pass'] for r in rows),'failed':sum(not r['pass'] for r in rows),'checks':rows,'elapsed_seconds':time.monotonic()-beg}
print(json.dumps(out,indent=2));raise SystemExit(bool(out['failed']))
