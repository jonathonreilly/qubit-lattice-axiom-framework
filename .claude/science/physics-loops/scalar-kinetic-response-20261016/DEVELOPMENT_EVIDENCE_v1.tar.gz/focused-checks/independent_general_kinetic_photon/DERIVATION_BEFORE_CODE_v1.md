# Independent general-kinetic photon mapping, before code

This derivation uses the neutral task and only the already-frozen PR9641 photon note/core. No new root GENERAL_KINETIC_PHOTON note, implementation or output has been read. Root retains authorship. The purpose is to identify what survives as a necessary inverse; it is not a proof of full observational nonidentifiability or an empirical test.

## 1. Action, coordinates and exact equations

Use signature (-,+,+,+) and

    S = integral sqrt(-gE)[M^2 RE/2+Q(zeta,Y)] + Sm[exp(2zeta)gE],
    Y=-(grad zeta)^2/2, A=exp(zeta), M>0.

Here Y always denotes the scalar kinetic argument. Write Y_gamma for corrected radial photon redshift to avoid confusing it with Y. Matter is the same universal pressureless dust as in the permitted note, with bare conserved rest density rho_b and Einstein density rE=A rho_b. The variational scalar stress, scalar equation and matter exchange are

    TQ_ab=Q_Y zeta_a zeta_b+Q gE_ab,
    divE(Q_Y gradE zeta)+Q_zeta+TE=0, TE=-rE,
    divE TE^a_b=TE partial_b zeta.

All partial Q derivatives hold its other argument fixed. For a homogeneous field v=dot(zeta), barY=v^2/2, the scalar density and pressure are

    epsilonQ=2barY Q_Y-Q, pQ=Q.

The complete homogeneous equations are

    3M^2 HE^2=2barY Q_Y-Q+rE,
    -2M^2 dot(HE)=2barY Q_Y+rE,
    (Q_Y+2barY Q_YY)dot(v)+3HE Q_Y v
        +2barY Q_zetaY-Q_zeta+rE=0,
    dot(rho_b)+3HE rho_b=0.

Equivalently the scalar equation is
(dot+3HE)(Q_Y v)-Q_zeta+rE=0. It follows from the actual scalar variation, not from choosing an effective mass.

Einstein proper time is t. Matter background proper time is tau, d tau=A dt. Define

    a=A aE, h=a'/a, q=zeta', ell=h-q, HE=A ell,
    R=rE/(M^2 A^2)>0, G=(Q_Y/M^2)q.

Primes act on coeval backgrounds in matter time. Rolling means q!=0. The metric sector has equal Einstein potentials P. For the photon comparison retain the permitted note's recovered full-sky l>=2 sector (or explicitly work modulo spatially constant velocity-potential integration terms). Equal potentials alone do not remove every local metric kernel or fix those potential zero modes.

## 2. Momentum and dust do not require a canonical scalar

Write J=delta zeta and Z=A U, where the dust momentum convention is delta TE^0_i=rE partial_i U. The scalar momentum is -Q_Y v partial_i J. The 0i Einstein equation therefore gives

    partial_i{2(P'+ell P)-GJ+RZ}=0.

In the stated angular sector its bracket is zero:

    P'+ell P=(GJ-RZ)/2.                         (M)

There is no Q_YY contribution: a perturbation of Q_Y multiplies a zero background spatial scalar gradient. Keeping the spatial gradient form is necessary if the angular/zero-mode restriction is dropped.

The particle force equation and conserved bare number current give

    Z'=-P-J,
    delta'=3P'-Delta Z/a^2,                    (D)

where delta=delta rho_b/rho_b. The background counterparts are

    R'=(2q-3h)R,
    -2(ell'+q ell)=qG+R.                       (B)

The physical rest density is rhoJ=A^-4 rE=M^2 R/A^2 and satisfies rhoJ'=-3h rhoJ. It must not be confused with rho_b or rE.

On a regular chart with Q_Y!=0 (hence G!=0) combine (M) with the dust Euler equation:

    Z'+CZ=-dP'-eP,
    C=R/G, d=2/G, e=1+d ell.                   (I)

The photon kinematic relation is unchanged:

    Y_gamma=-P-J+Z_r/a=LZ,
    L=partial_tau+a^-1 partial_r.

Thus the commutator, path identities, reception-gain algebra and weak adjoint identities of the permitted photon note remain necessary when the same registration, angular, observer and gain contracts are retained. With Kc=C'+hC, the ungained commutator is

    N=(partial_tau+h+C)Y_gamma+(L+h)(dP'+eP)=-Kc Z,

and on Kc!=0,

    (L-Kc'/Kc)N+Kc Y_gamma=0.

The common/separate-gain coefficient expansions are algebra on this pair of first-order equations, not consequences of a canonical scalar wave equation. Their rank conclusions remain conditional on actual rank and smooth histories. No generic rank for noncanonical solutions is inferred here; the supplied canonical subclass already lies within Q(zeta,Y), while a separate checker owns new noncanonical full-action fixtures.

Recovering coefficients gives the same combinations

    G=2/d, R=2C/d, q=h-(e-1)/d.

This requires d!=0 and, for the rolling reconstruction below, q!=0. Neither rolling nor positive dust density alone guarantees Q_Y!=0. At Q_Y=0 the exact momentum equation still holds but this divided inverse chart fails. Kc!=0 is needed for the displayed hidden-velocity reconstruction; the relevant full-rank design excludes its zero locus, not conversely. These algebraic statements do not assume Q_Y>0. A healthy hyperbolic scalar requires additional signs.

## 3. What the recovered histories determine

Choose one A normalization and integrate A'/A=q, zeta=log A. Then

    barY=A^2 q^2/2,
    barQ=M^2 A^2 [qG+R-3ell^2],
    overline(Q_Y)=M^2 G/q.                     (J1)

Thus C,d,e determine normalized on-trajectory value and kinetic derivative, not a two-variable action. The background scalar equation gives

    overline(Q_zeta)/(M^2 A^2)
       =G'+(3h-2q)G+R.                         (J2)

This also follows from the chain rule

    barQ'=q overline(Q_zeta)+barY' overline(Q_Y),

provided both background equations (B) hold. Conversely their agreement is an action-integrability check; values assigned independently to Q and its derivatives cannot bypass it. Scalar monotonicity makes the background curve a local graph Y=y(zeta).

The old canonical formula

    M^2 A^2 [3ell^2-qG/2-R]

is now exactly barY overline(Q_Y)-barQ. It is a genuine potential V only for Q=K(zeta)Y-V(zeta), or another separately stipulated decomposition. For general Q it must not be labeled the recovered fundamental potential.

Similarly qG=Q_Y q^2/M^2 is normalized scalar enthalpy, and q/G=M^2/Q_Y is the reciprocal kinetic slope. Writing them as x^2 and b^2 does not establish a globally canonical scalar coordinate or a universal canonical coupling. One can define a field coordinate along a positive-Q_Y trajectory, but that does not remove nonlinear dependence on Y away from that trajectory.

## 4. One Hessian function remains free from these histories

Let Q0(zeta)=barQ and Q1(zeta)=overline(Q_Y) expressed in the monotonic scalar coordinate, and y(zeta)=barY. Locally every smooth choice H(zeta) is compatible with the same value and first partial derivatives via

    Q_H(zeta,Y)
      =Q0(zeta)+Q1(zeta)[Y-y(zeta)]
         +H(zeta)[Y-y(zeta)]^2/2
         +terms vanishing to at least third order on the curve.

On the curve,

    Q_zeta=Q0_zeta-Q1 y_zeta,
    Q_YY=H,
    Q_zetaY=Q1_zeta-H y_zeta,
    Q_zetazeta=Q0_zetazeta-2Q1_zeta y_zeta-Q1 y_zetazeta
                 +H y_zeta^2.

Equivalently the inferred time histories constrain

    (Q_Y)'=q Q_zetaY+barY' Q_YY,
    (Q_zeta)'=q Q_zetazeta+barY' Q_zetaY,

which are two constraints on three symmetric Hessian entries. Even barY'=0 does not determine Q_YY. Changing Q by lambda(zeta)[Y-y(zeta)]^2/2 leaves its value and first gradient, the full background equations and C,d,e unchanged. In the background scalar equation the associated Hessian changes cancel because dot(v)=d barY/d zeta. This is an exact local functional freedom of the background and momentum map.

This does NOT show identical complete photon perturbation histories: Hamiltonian and scalar perturbation residuals generally change and may constrain H when additional information is used. No conclusion about the rank or uniqueness of that stronger inverse is made.

The scalar principal inverse metric is

    Q_Y gE^{ab}-Q_YY gradE^a zeta gradE^b zeta.

Its homogeneous time coefficient is BQ=Q_Y+2barY Q_YY, while the spatial coefficient is Q_Y. On a hyperbolic nondegenerate chart

    c_s^2=Q_Y/BQ.

The inverse momentum coefficient gives Q_Y/M^2=G/q, but not BQ or c_s. Q_Y>0 alone does not guarantee BQ>0. On a positive-Q_Y background choose different sufficiently small H changes that keep BQ>0; these preserve (J1)-(J2) and C,d,e while changing c_s. Conformal rescaling preserves the light cone, so this speed relative to the physical light cone is the same dimensionless ratio in either frame. No measured-pole interpretation follows.

## 5. The remaining full linear residuals change

The old canonical scalar/Hamiltonian formulas cannot simply be reused with x^2=qG. In Einstein Newtonian gauge set

    deltaY=v(dot J-vP)=A^2 q(J'-qP),
    BQ=Q_Y+2barY Q_YY,
    EQ=2barY Q_zetaY-Q_zeta.

The exact first-order stress perturbations are

    delta epsilonQ=BQ deltaY+EQ J,
    delta pQ=Q_Y deltaY+Q_zeta J,
    delta rE=rE(delta+J).

The general Hamiltonian residual is therefore

    R delta=2 Delta P/a^2-6ell(P'+ell P)
        -(BQ/M^2)q(J'-qP)
        -[EQ/(M^2 A^2)+R]J.                   (H)

The spatial Einstein pressure equation is

    2[P''+(q+4ell)P'
        +{2(ell'+qell)+3ell^2}P]
       =G(J'-qP)+[Q_zeta/(M^2 A^2)]J.        (P)

It uses only first action derivatives, but must still be tested.

For clarity a conservative exact scalar perturbation equation can be written without hiding time derivatives of its coefficients. Define

    uQ=(BQ/M^2)(J'-qP)+(q Q_zetaY/M^2)J,
    Fz=Q_zeta/(M^2 A^2).

Then the variation of div(Q_Y grad zeta)+Q_zeta-rE=0 is

    uQ'+(3h-2q)uQ
      -3G P'-(Fz-R)P
      -(Q_Y/M^2)Delta J/a^2
      -[Q_zetazeta/(M^2 A^2)]J
      -(q Q_zetaY/M^2)(J'-qP)
      +R(delta+J)=0.                          (S)

To derive (S), use the perturbed proper scalar current
delta j=BQ(dot J-vP)+v Q_zetaY J, j=Q_Y v, and
S0=dot j+3HE j=Q_zeta-rE. The first variation, multiplied by minus one, is

    (dot+3HE)delta j-3j dot P-S0 P
      -Q_Y Delta J/aE^2
      -Q_zetazeta J-Q_zetaY deltaY+rE(delta+J)=0.

The determinant perturbation is delta sqrt(-gE)/sqrt(-gE)=-2P; it supplies the stated metric terms. Dividing by M^2 A^2 gives (S). Expanding uQ' differentiates the action Hessian along the trajectory, so suitable higher action smoothness is required. There is no generally valid single canonical kappa=(V_phiphi+rho_b A_phiphi)/A^2 formula in the zeta theory. A response mass/pole would require its own definition and background/measurement analysis.

Complete existence still requires (M), both dust equations, (H), (P), (S), all background equations, a single smooth Q consistent with its derivatives, and every primitive photon/gain residual. The Hamiltonian may define delta only after its additional action coefficients are supplied; dust propagation remains a test. No transport integration constant is chosen to conceal a failed residual.

## 6. Surviving imports and predeclared checks

The action class Q plus Einstein gravity, universal exponential conformal dust coupling, species, flat background, perturbative metric sector, recovered angular sector, known matter clock/scale factor, radius/time and observer/source registration, primitive photon model, and reception-only gain assumptions remain supplied. No observation arrays are used.

A0 (equivalently the scalar origin zeta0 tied to A=e^zeta), M/units and clock/distance normalization remain imports. An independently calibrated physical dust density could fix A^2=M^2R/rhoJ; it is not supplied here. An arbitrary nonlinear field-coordinate change alters the stated coupling form, so it cannot silently be counted as an independently recovered canonical coordinate. Q away from the background curve, higher transverse derivatives and initial-state selection are also unresolved.

Dimensions are [zeta]=[A]=1, [Y]=mass^2, [Q]=mass^4, [Q_Y]=mass^2, [Q_YY]=1, [q]=[G]=[h]=mass, [R]=mass^2, [C]=mass, [d]=mass^-1 and [e]=1. The positivity conditions needed for a healthy scalar are Q_Y>0 and BQ>0, not merely R>0 and q!=0.

Before author exposure I will check: the exact stress/0i and dust transformations; the chain-rule/background inference of Q_zeta; the commutator and coefficient recovery; the graph-family value/gradient/Hessian identities and scalar-background cancellation; the principal-symbol ratio; the general linear Hamiltonian/pressure/scalar formulas and their canonical specialization. These are bounded exact algebra controls, not new noncanonical full-action fixtures. Every process is capped at 120 seconds with bytecode disabled; actual failures will be preserved.

