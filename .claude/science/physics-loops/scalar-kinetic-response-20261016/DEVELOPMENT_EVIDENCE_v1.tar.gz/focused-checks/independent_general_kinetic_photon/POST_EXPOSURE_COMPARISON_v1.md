# Post-exposure bounded comparison: general kinetic photon equations

No material equation or sign mismatch was found between the frozen author unit and the independent pre-author result. The author correctly limits the construction to necessary inverse relations and different supplied actions; it does not assert identical complete photon records. This comparison is static. No author replay, new fixture, new rank computation or formal audit was performed.

## Source identity and evidence boundary

The complete named note, implementation, controls and receipts were read. Exact unchanged copies are in post_exposure_author_snapshots_v1/, with absolute source root and byte counts in POST_EXPOSURE_SOURCE_BINDINGS_v1.json.

| File | SHA256 |
| --- | --- |
| GENERAL_KINETIC_PHOTON_DERIVATION_v1.md | cb0d42e2a504e411af58fb90d42129a78b0b8e983848f2b17d80069818c8fe8a |
| check_general_kinetic_photon_v1.py | 4246f13b83e1517bf6c5856945ea7a7087925efc7fb1c87e48046a9a86b34bee |
| GENERAL_KINETIC_PHOTON_CONTROLS_v1.json | be7d93cb0f0cbd353c80b9a630f514903504e1c46b7423b2f2899c3c8246c217 |
| GENERAL_KINETIC_PHOTON_EXECUTION_v1.json | 27f0fb2ae739e3c2225e6e8d8c49fbbf7b211c8435ba1d28150eab1a51d8a813 |
| GENERAL_KINETIC_PHOTON_DERIVATION_FREEZE_v1.json | afa81ee589240d1b1f8cc27b8402e2c05a04e1e72661a01251233e7d320047e3 |
| GENERAL_KINETIC_PHOTON_SOURCE_FREEZE_v1.json | 12dd42d7cc0a0c6aaf93fb0853edcdd3cb69ceb1a90012e61eb900be957d48eb |
| GENERAL_KINETIC_PHOTON_CONTROLS_v1.stderr.txt | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |

The author derivation/source freezes and execution receipt match those exact bytes. The saved result contains 82 passing control entries and zero failures; its receipt reports exit zero, no timeout and 0.7532 seconds under a 120-second limit. These are inspected author results, not newly reproduced independent results. The 19 pre-author files and their independent freeze remain unchanged. Their 57 exact controls remain a separate evidence stream.

No later canonical packet was read in this comparison. In particular, the historical v1 note retains a conditional reference to the prior fourteen-column theorem. Root's stated narrowing of later canonical prose is not represented here as a checked source delta.

## Equations and exact correspondence

The physical definitions G=Q_Y q/M^2, C=R/G, d=2/G and e=1+d(h-q), and all three momentum/dust equations, coincide with the independently derived formulas. The density variable delta_b=delta rhoE/rhoE-J is the bare number-density contrast. Consequently delta rhoE=rhoE(delta_b+J), which gives the author's Hamiltonian and scalar matter-source terms with the correct signs.

The author's Pi=qG+R-3ell^2, Raychaudhuri and normalized dust transport equations agree exactly. Its chain-rule expression for Q_zeta is equivalent to

    Q_zeta/(M^2 A^2)=G'+(3h-2q)G+R

when those background equations hold. This identity was independently established before exposure. The recovered data determine the action value and its first derivatives only along the visited curve, after normalizations are chosen. The old canonical potential expression would be YQ_Y-Q; v1 does not incorrectly identify that expression as a general fundamental potential.

The Einstein-time Hamiltonian and pressure equations use, respectively,

    D deltaY+(2Y Q_Yzeta-Q_zeta)J,
    Q_Y deltaY+Q_zeta J,

with D=Q_Y+2YQ_YY and deltaY=dot(zeta)dot(J)-dot(zeta)^2 P. These match the independent direct stress and metric variation.

The author's conservative scalar expression looks different but is identical. Put j=Q_Y v, v=dot(zeta), S0=dot j+3Hj and define the independently derived perturbed proper current

    delta j=D(dot J-vP)+v Q_Yzeta J.

The author's expression inside its aE^3 time derivative is exactly delta j-3jP. Expanding that derivative and its separate -2PS0 term gives

    -(dot+3H)delta j+3j dot P+S0 P
       +Q_Y Delta J/aE^2+Q_zetazeta J
       +Q_Yzeta deltaY-rhoE(delta_b+J).

This is minus the independently frozen scalar residual. There is no missing factor of two, lapse term or source-sign difference. The independent pre-author code already checked this conservative variation directly, so no additional disputed calculation was needed.

## Actual domain and limitations

The note's qG!=0 condition is essential: rolling and positive dust density alone do not ensure G!=0. The divided inverse needs G!=0, d!=0 and q!=0. The background algebra does not itself require healthy signs. Positive Q_Y and D are additional local hyperbolicity/kinetic conditions, and do not establish global stability or a complete ultraviolet theory.

The integrated 0i and Euler equations are potential equations after excluding spatial integration kernels. The note's nonzero-mode qualification must be retained. For the local harmonic fixtures, Delta H=0 means a nonconstant harmonic spatial amplitude can multiply each displayed time history; it must not be interpreted as a nonzero real Fourier wavenumber with zero Laplacian eigenvalue. No global decay or finite-energy spatial completion is proved by those local amplitudes.

Whenever the inherited photon commutator is divided by Kc=C'+hC, Kc!=0 remains necessary. V1 refers to inherited regularity rather than restating that denominator. This does not affect its directly displayed necessary C,d,e transport relation. It must not be lost in any later reconstruction or Kc'/Kc formula.

The power-action fixture uses t>0 and a local Y>0 kinetic patch. For noninteger n, this is the domain on which Y^n is smooth and real. The claimed healthy fixture has n>1/2, excluding the D=0 point n=1/2. The code's first-order generator divides by D dot(zeta), so that exclusion is substantive. Its forced power simplifications are consistent with t>0 and the positive background Y; they do not establish a continuation to negative Y. The code's intermediate harmonic coefficient formula also uses m+4 in a denominator; its tested roots do not hit that denominator. No claim of an exhaustive modal classification is needed or inferred.

The local nonzero-k state comparison distinguishes responses: it does not claim identical full data. The n-dependent D and sound speed leave background q,G,R unchanged, which is the same limitation exposed by the independent graph-family proof. The generic inverse itself does not measure D or sound speed. The tests' positive-cone condition is local; n between 1/2 and 1 also gives c_s^2>1, so no universal subluminality assertion should be inferred.

## What the implementation actually checks

The generator solves momentum and Hamiltonian for dot P and dot J, and uses both dust evolution equations for dot U and dot delta_b. It then checks the pressure and scalar equations along that full flow for symbolic n and nonnegative k^2. The modes are checked against all four flow equations for n=1,2,3/2, and the generic pressure/scalar identities supply their additional residual coverage. This is consistent with the full equations displayed in the note. I did not rerun or replace the separate checker's explicit noncanonical fixture work.

The wrong-source and wrong-canonical-D entries are algebraic negative controls, not executed whole-program mutations. The 82 controls do not constitute a new fourteen-column rank test, an empirical result or a proof of generic rank. The frozen v1's rank discussion is an inherited conditional argument; the narrow necessary-relation conclusion does not require importing that stronger theorem into this unit's executed result.

There is no mathematical source repair indicated by this bounded comparison. The explicit G/zero-mode/Kc/local-harmonic qualifications and the absence of identical-full-record claims remain necessary for any integration. All scale, clock/distance, frame/coupling, action-extension and calibration imports stated in the independent proof remain unresolved. The check is complete; subsequent work requires a separately scoped instruction.

