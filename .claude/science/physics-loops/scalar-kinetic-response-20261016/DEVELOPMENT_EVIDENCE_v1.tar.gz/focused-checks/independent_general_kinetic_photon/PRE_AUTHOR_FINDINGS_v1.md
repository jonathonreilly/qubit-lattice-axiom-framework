# Pre-author independent findings: general kinetic photon inverse

The necessary photon transport/gain algebra survives on its regular chart, with the replacement

    G=(Q_Y/M^2)q, q=zeta',
    C=R/G, d=2/G, e=1+d(h-q).

The physical-time momentum equation is P'+(h-q)P=(GJ-RZ)/2 with J=delta zeta; the dust equations remain Z'=-P-J and delta'=3P'-Delta Z/a^2. Their integrated potential form retains the permitted note's full-sky l>=2/zero-mode convention. The commutator and reception/path derivations therefore need no canonical wave equation. Rank must still be verified on the actual full-equation field.

For chosen A0 and M, smooth recovered histories determine on the rolling trajectory

    Y=A^2q^2/2,
    Q/(M^2A^2)=qG+R-3(h-q)^2,
    Q_Y/M^2=G/q,
    Q_zeta/(M^2A^2)=G'+(3h-2q)G+R.

The last expression agrees with the chain rule only when the background dust/Raychaudhuri constraints hold. The old canonical potential expression is YQ_Y-Q; it is not a general fundamental V. Writing qG and q/G as canonical velocity/coupling squares also imports a kinetic assumption.

One Hessian function remains free from these histories. On the monotonic background graph Y=y(zeta), adding lambda(zeta)[Y-y(zeta)]^2/2 preserves Q, both first partial derivatives, the complete background equations and C,d,e, but changes Q_YY and the perturbation energy/scalar residuals. Thus momentum alone cannot determine

    c_s^2=Q_Y/(Q_Y+2YQ_YY).

This is not a construction of identical complete photon perturbation records. Additional original-equation residuals can constrain the free function; that stronger inverse was not attempted.

The full proof explicitly derives the general Hamiltonian, pressure and conservative scalar perturbation equations, including deltaY=A^2q(J'-qP), delta rE=rE(delta+J), and the scalar matter-source sign. The old canonical scalar and Hamiltonian residuals cannot be retained unchanged. The background/momentum algebra only needs Q_Y!=0; rolling and R>0 do not guarantee this. Positive Q_Y and positive Q_Y+2YQ_YY are extra healthy-hyperbolic conditions. The divided commutator also needs Kc=C'+hC!=0. The corresponding exceptional charts are retained, not resolved by division.

All 57 exact pre-author controls passed: direct linearized Einstein/stress 11, direct scalar variation and canonical specialization 4, background/momentum/dust/commutator mapping 11, and graph/Hessian/principal-symbol identities 31. Complete stdout and empty stderr are preserved for four subprocesses; each took under 0.324 seconds under a 120-second cap with bytecode disabled. There were no failed or timed-out attempts, no retries and no omitted outputs. Counts overlap and are algebraic controls, not experiments.

The proof was frozen before executable code. No root GENERAL_KINETIC_PHOTON sources or results were read. The permitted PR9641 note/core were read in full and snapshotted, but not imported or executed. All scientific computations were newly written here; Python 3.12.8 and SymPy 1.14.0 are shared infrastructure. The checker reads no repository scientific inputs; the wrapper's literal input list binds only own proof, source snapshots and code before and after execution.

The action/coupling/species assumptions, matter clock and distance registration, angular sector, photon/observer/source and gain contracts, M/units, A0 and off-trajectory action extension remain inputs. Absolute physical dust density could supply additional A normalization, but it was not given. No empirical validation, generic noncanonical rank, nonlinear stability, initial-state selection or formal audit is claimed. A separate checker owns explicit noncanonical full-action fixtures.

Independent proof SHA256: 852f568b7f5c3d6ce623c38dc66d93584b99a8f454e707c7e0a2d632a5bfae78.
Pre-code freeze SHA256: 6cdd1b98cb9f267de95a36633d098a696e3f1066fd3c44ab568df6c7235d5e6f.

The next obligation is a bounded comparison with the still-unseen author unit. Root retains authorship.

