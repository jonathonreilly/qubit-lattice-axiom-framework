#!/usr/bin/env python3
"""Pre-author exact algebra for general-kinetic photon mapping; no author imports."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json
import platform
import sys
import time
import sympy as s

started=time.monotonic()
checks=[]; details={}
def zero(name,expr):
    value=s.factor(s.cancel(s.expand(expr)))
    checks.append({"name":name,"passed":value==0,"residual":str(value)})
def positive(name,expr):
    value=s.factor(expr)
    checks.append({"name":name,"passed":value.is_positive is True,
                   "expression":str(value),"is_positive":value.is_positive})

def setup():
    t,x,y,z=s.symbols("t x y z",real=True)
    ep=s.symbols("epsilon",real=True)
    a=s.Function("aE")(t); P=s.Function("P")(t,x)
    chi=s.Function("zeta")(t); J=s.Function("J")(t,x)
    coords=[t,x,y,z]
    lin=lambda expr:s.expand(expr).coeff(ep,0)+ep*s.expand(expr).coeff(ep,1)
    metric=s.diag(-(1+2*ep*P),*[a**2*(1-2*ep*P)]*3)
    inv=s.diag(-(1-2*ep*P),*[(1+2*ep*P)/a**2]*3)
    field=chi+ep*J; grad=s.Matrix([s.diff(field,c) for c in coords])
    Y=lin(-(grad.T*inv*grad)[0]/2)
    v=s.diff(chi,t)
    Q,Qy,Qz,Qyy,Qzy,Qzz=[s.Function(n)(t) for n in
        ["Qbar","QY","Qzeta","QYY","QzetaY","Qzetazeta"]]
    dy=s.expand(Y).coeff(ep,1)
    qlin=Q+ep*(Qz*J+Qy*dy)
    qylin=Qy+ep*(Qzy*J+Qyy*dy)
    return locals()

def geometry():
    data=setup()
    t,x,ep,a,P,J,coords,lin,metric,inv,grad=[data[k] for k in
         ["t","x","ep","a","P","J","coords","lin","metric","inv","grad"]]
    v,Qy,Qz,Qyy,Qzy,dy,qlin,qylin=[data[k] for k in
         ["v","Qy","Qz","Qyy","Qzy","dy","qlin","qylin"]]
    zero("kinetic_variation",dy-v*(s.diff(J,t)-v*P))
    gamma=[[[lin(sum(inv[k,l]*(s.diff(metric[l,b],coords[c])
                   +s.diff(metric[l,c],coords[b])-s.diff(metric[b,c],coords[l]))/2
                   for l in range(4))) for c in range(4)]
                   for b in range(4)] for k in range(4)]
    ric=s.Matrix(4,4,lambda b,c:lin(
        sum(s.diff(gamma[k][b][c],coords[k])-s.diff(gamma[k][b][k],coords[c])
            for k in range(4))
        +sum(gamma[k][k][l]*gamma[l][b][c]-gamma[k][c][l]*gamma[l][b][k]
             for k in range(4) for l in range(4))))
    curvature=lin(s.trace(inv*ric))
    Gcov=s.Matrix(4,4,lambda i,j:lin(ric[i,j]-metric[i,j]*curvature/2))
    Gmixed=s.Matrix(4,4,lambda i,j:lin(sum(inv[i,k]*Gcov[k,j] for k in range(4))))
    pert=lambda expr:s.expand(expr).coeff(ep,1)
    H=s.diff(a,t)/a
    zero("direct_linear_Einstein_0i",
         pert(Gmixed[0,1])+2*s.diff(s.diff(P,t)+H*P,x))
    zero("direct_linear_Einstein_00",
         pert(Gmixed[0,0])-6*H*(s.diff(P,t)+H*P)+2*s.diff(P,x,2)/a**2)
    pressure=2*(s.diff(P,t,2)+4*H*s.diff(P,t)
                 +(2*s.diff(H,t)+3*H**2)*P)
    for i in range(1,4):
        zero(f"direct_linear_Einstein_pressure_{i}",pert(Gmixed[i,i])-pressure)
    Tcov=s.Matrix(4,4,lambda i,j:lin(qylin*grad[i]*grad[j]+qlin*metric[i,j]))
    Tmixed=s.Matrix(4,4,lambda i,j:lin(sum(inv[i,k]*Tcov[k,j] for k in range(4))))
    B=Qy+v**2*Qyy; E=v**2*Qzy-Qz
    zero("direct_scalar_momentum",pert(Tmixed[0,1])+Qy*v*s.diff(J,x))
    zero("direct_scalar_energy_perturbation",-pert(Tmixed[0,0])-B*dy-E*J)
    for i in range(1,4):
        zero(f"direct_scalar_pressure_perturbation_{i}",pert(Tmixed[i,i])-Qy*dy-Qz*J)
    details["route"]="Full 4D Christoffel/Ricci linearization with arbitrary P(t,x), then scalar stress variation. One spatial direction represents an arbitrary component by isotropy."

def scalar():
    data=setup()
    t,x,ep,a,P,J,coords,lin,inv,grad=[data[k] for k in
        ["t","x","ep","a","P","J","coords","lin","inv","grad"]]
    v,Qy,Qz,Qyy,Qzy,Qzz,dy,qylin=[data[k] for k in
        ["v","Qy","Qz","Qyy","Qzy","Qzz","dy","qylin"]]
    H=s.diff(a,t)/a
    sqrtg=a**3*(1-2*ep*P)
    current=[lin(sqrtg*qylin*sum(inv[i,j]*grad[j] for j in range(4)))
             for i in range(4)]
    div=lin((1+2*ep*P)/a**3*sum(s.diff(current[i],coords[i]) for i in range(4)))
    rm=s.Function("rE")(t); delta=s.Function("delta")(t,x)
    EL=lin(div+Qz+ep*(Qzz*J+Qzy*dy)-rm*(1+ep*(delta+J)))
    j=Qy*v; S0=s.diff(j,t)+3*H*j
    dj=(Qy+v**2*Qyy)*(s.diff(J,t)-v*P)+v*Qzy*J
    desired=s.diff(dj,t)+3*H*dj-3*j*s.diff(P,t)-S0*P-Qy*s.diff(J,x,2)/a**2-Qzz*J-Qzy*dy+rm*(delta+J)
    zero("direct_scalar_background",EL.coeff(ep,0)+S0-Qz+rm)
    zero("direct_scalar_linear_conservative_form",s.expand(EL).coeff(ep,1)+desired)
    # Conversion to physical time with A'/A=q, and background source S0=Qz-rE.
    tau=s.symbols("tau",real=True)
    A=s.Function("A")(tau); q,h,G,Fz,R=s.symbols("q h G Fz R",real=True)
    M=s.symbols("M",positive=True)
    u=s.Function("uQ")(tau); pp=s.Function("P")(tau)
    jj=s.Function("J")(tau); dd=s.Function("delta")(tau)
    QY,QZY,QZZ,lap=s.symbols("QY QzetaY Qzetazeta lapJ",real=True)
    ell=h-q
    dot=lambda expr:A*s.diff(expr,tau)
    dj=A*M**2*u; j=A*M**2*G
    dy=A**2*q*(s.diff(jj,tau)-q*pp)
    converted=(dot(dj)+3*A*ell*dj-3*j*dot(pp)
               -M**2*A**2*(Fz-R)*pp
               -QY*A**2*lap-QZZ*jj-QZY*dy
               +M**2*A**2*R*(dd+jj))/(M**2*A**2)
    desired=s.diff(u,tau)+(3*h-2*q)*u-3*G*s.diff(pp,tau)-(Fz-R)*pp-QY*lap/M**2-QZZ*jj/(M**2*A**2)-q*QZY*(s.diff(jj,tau)-q*pp)/M**2+R*(dd+jj)
    zero("physical_time_scalar_conversion",(converted-desired).subs(s.diff(A,tau),q*A))
    # Canonical specialization zeta=phi/M, A=exp(zeta), Q=M^2Y-V(zeta).
    qf,hf,Rf=[s.Function(n)(tau) for n in ["q","h","R"]]
    Vzz_over=s.Function("Vzz_over_M2A2")(tau)
    Fbar=-s.diff(qf,tau)-(3*hf-2*qf)*qf
    Fz_bg=s.diff(qf,tau)+(3*hf-2*qf)*qf+Rf
    uq=s.diff(jj,tau)-qf*pp
    general=s.diff(uq,tau)+(3*hf-2*qf)*uq-3*qf*s.diff(pp,tau)-(Fz_bg-Rf)*pp-lap+Vzz_over*jj+Rf*(dd+jj)
    canonical=s.diff(jj,tau,2)+(3*hf-2*qf)*s.diff(jj,tau)-lap+(Vzz_over+Rf)*jj+Rf*dd-4*qf*s.diff(pp,tau)+2*Fbar*pp
    zero("canonical_scalar_specialization",general-canonical)
    details["scope"]="Exact first variation of scalar divergence with lapse, volume and spatial terms. This is not a noncanonical forward fixture."

def mapping():
    tau=s.symbols("tau",real=True)
    P,J,Z=[s.Function(n)(tau) for n in ["P","J","Z"]]
    h,q,G,R=[s.Function(n)(tau) for n in ["h","q","G","R"]]
    ell=h-q; C=R/G; d=2/G; e=1+d*ell
    momentum=2*(s.diff(P,tau)+ell*P)-G*J+R*Z
    euler=s.diff(Z,tau)+P+J
    transport=s.diff(Z,tau)+C*Z+d*s.diff(P,tau)+e*P
    zero("momentum_Euler_elimination",transport-euler-momentum/G)
    zero("recover_G",2/d-G)
    zero("recover_R",2*C/d-R)
    zero("recover_q",h-(e-1)/d-q)
    W=q*G+R-3*ell**2
    chain=(s.diff(W,tau)+2*q*W-G*(s.diff(q,tau)+q**2))/q
    scalar=s.diff(G,tau)+(3*h-2*q)*G+R
    rules={s.diff(R,tau):(2*q-3*h)*R,
           s.diff(h,tau):s.diff(q,tau)-q*ell-(q*G+R)/2}
    zero("first_action_gradient_from_chain_and_background",(chain-scalar).subs(rules))
    zero("old_potential_combination",q*G/2-W-(3*ell**2-q*G/2-R))
    A=s.Function("A")(tau); U=Z/A
    dot=lambda expr:A*s.diff(expr,tau)
    # Einstein particle-potential equation dot U+dot(zeta)U=-P-J.
    zero("dust_Euler_time_transformation",
         (dot(U)+A*q*U+P+J-euler).subs(s.diff(A,tau),q*A))
    rhoJ=s.Function("rhoJ")(tau)
    zero("physical_dust_density_transport",
         (s.diff(R/A**2,tau)+3*h*R/A**2).subs({
             s.diff(R,tau):(2*q-3*h)*R,s.diff(A,tau):q*A}))
    # Derive dust continuity from the linear number current.
    t,x=s.symbols("t x",real=True)
    a=s.Function("aE")(t); n=s.Function("rho_b")(t)
    pp=s.Function("P")(t,x); dd=s.Function("delta")(t,x); uu=s.Function("U")(t,x)
    H=s.diff(a,t)/a
    density=a**3*n*(dd-3*pp)
    flux=a*n*s.diff(uu,x)
    lhs=(s.diff(density,t)+s.diff(flux,x))/(a**3*n)
    zero("dust_linear_number_current",
         (lhs-s.diff(dd,t)+3*s.diff(pp,t)-s.diff(uu,x,2)/a**2).subs(s.diff(n,t),-3*H*n))
    # Direct commutator in conformal/coeval coordinates.
    eta,r=s.symbols("eta r",real=True)
    aa=s.Function("a")(eta); cc=s.Function("C")(eta)
    zz=s.Function("Z")(eta,r)
    dt=lambda expr:s.diff(expr,eta)/aa
    L=lambda expr:(s.diff(expr,eta)+s.diff(expr,r))/aa
    hh=dt(aa)/aa
    yy=L(zz); ff=-dt(zz)-cc*zz
    N=dt(yy)+(hh+cc)*yy+L(ff)+hh*ff
    K=dt(cc)+hh*cc
    zero("general_background_commutator",N+K*zz)
    zero("general_background_necessary_elimination",L(N)-dt(K)/K*N+K*yy)
    details["denominators"]="G != 0 for C,d,e; d != 0 and q != 0 for reconstruction; Kc != 0 only for the displayed divided commutator route."

def jets():
    z,Y=s.symbols("zeta Y",real=True)
    Q0,Q1,y,H=[s.Function(n)(z) for n in ["Q0","Q1","y","H"]]
    f=Y-y
    Q=Q0+Q1*f+H*f**2/2
    on=lambda expr:s.expand(expr).subs(Y,y)
    zero("graph_value",on(Q)-Q0)
    zero("graph_kinetic_slope",on(s.diff(Q,Y))-Q1)
    zero("graph_scalar_gradient",on(s.diff(Q,z))-s.diff(Q0,z)+Q1*s.diff(y,z))
    zero("graph_YY",on(s.diff(Q,Y,2))-H)
    zero("graph_zetaY",on(s.diff(Q,z,Y))-s.diff(Q1,z)+H*s.diff(y,z))
    zero("graph_zetazeta",on(s.diff(Q,z,2))-
         (s.diff(Q0,z,2)-2*s.diff(Q1,z)*s.diff(y,z)-Q1*s.diff(y,z,2)+H*s.diff(y,z)**2))
    zero("gradient_chain_along_graph",
         s.diff(on(s.diff(Q,Y)),z)-on(s.diff(Q,z,Y))-s.diff(y,z)*on(s.diff(Q,Y,2)))
    zero("scalar_gradient_chain_along_graph",
         s.diff(on(s.diff(Q,z)),z)-on(s.diff(Q,z,2))-s.diff(y,z)*on(s.diff(Q,z,Y)))
    lam=s.Function("lambda")(z)
    change=lam*f**2/2
    zero("Hessian_freedom_value",on(change))
    zero("Hessian_freedom_zeta_gradient",on(s.diff(change,z)))
    zero("Hessian_freedom_Y_gradient",on(s.diff(change,Y)))
    acceleration=s.symbols("vdot",real=True)
    deltaE=2*Y*on(s.diff(change,Y,2))*acceleration+2*Y*on(s.diff(change,z,Y))-on(s.diff(change,z))
    zero("full_background_scalar_Hessian_cancellation",deltaE.subs(acceleration,s.diff(y,z)))
    deltaY,J=s.symbols("deltaY J",real=True)
    densitychange=(2*Y*on(s.diff(change,Y,2)))*deltaY+(2*Y*on(s.diff(change,z,Y))-on(s.diff(change,z)))*J
    zero("Hessian_changes_energy_perturbation",
         densitychange-2*Y*lam*(deltaY-s.diff(y,z)*J))
    # Principal symbol from the kinetic Hessian in local inertial coordinates.
    velocities=s.Matrix(s.symbols("c0:4",real=True))
    mink=s.diag(-1,1,1,1)
    X=-(velocities.T*mink*velocities)[0]/2
    Qys,Qyys=s.symbols("QY QYY",real=True)
    # Use explicit local quadratic Taylor polynomial, whose gradient Hessian
    # has the same first and second Q partials at the arbitrary base point.
    Y0=s.symbols("Y0",real=True)
    taylor=Qys*(X-Y0)+Qyys*(X-Y0)**2/2
    gradH=s.hessian(taylor,list(velocities))
    # At X=Y0, only the tangent gradient coefficients remain.
    v=s.symbols("v",real=True)
    at={velocities[0]:v,velocities[1]:0,velocities[2]:0,velocities[3]:0,Y0:v**2/2}
    expected=s.diag(Qys+v**2*Qyys,-Qys,-Qys,-Qys)
    for i in range(4):
        for j in range(4):
            zero(f"principal_homogeneous_Hessian_{i}{j}",gradH[i,j].subs(at)-expected[i,j])
    slope,B,yp,lp=s.symbols("slope B Y lambda",positive=True)
    difference=slope/B-slope/(B+2*yp*lp)
    positive("same_momentum_distinct_positive_sound_speeds",difference)
    zero("exact_sound_speed_difference",difference-2*slope*yp*lp/(B*(B+2*yp*lp)))
    details["family"]="Changing H(zeta) preserves background and C,d,e but changes general perturbation residuals. It is not an identical-full-photon-data counterexample."

cases={"geometry":geometry,"scalar":scalar,"mapping":mapping,"jets":jets}
if len(sys.argv)!=2 or sys.argv[1] not in cases:
    raise SystemExit("Choose geometry, scalar, mapping, or jets")
cases[sys.argv[1]]()
failed=sum(not item["passed"] for item in checks)
print(json.dumps({"case":sys.argv[1],"stage":"Independent, before new author exposure",
    "python":platform.python_version(),"sympy":s.__version__,
    "elapsed_seconds":time.monotonic()-started,
    "passed":len(checks)-failed,"failed":failed,"checks":checks,"details":details},indent=2))
raise SystemExit(1 if failed else 0)

