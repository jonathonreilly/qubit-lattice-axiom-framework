# What the photon inverse constrains without a canonical kinetic action

Root derivation before execution. Status: conditional-support; no measured
record is newly exposed. Motivation: PR9641 reconstructs scalar/background
coefficient histories from ideal calibrated primitive photon records within
a supplied canonical class. Determine which of its necessary relations
actually require canonical kinetics, and what additional observations would
discriminate the remaining actions. General single-field kinetic theories
and their reconstruction degeneracies are established prior art; no novelty
claim is made for introducing Q or reconstructing one trajectory.

## Declared class and coordinate

On a local chart where d ln A/d phi is nonzero, choose the field coordinate
zeta=ln A and write

    S=int sqrt(-gE)[M^2 RE/2+Q(zeta,Y)]+Sm[exp(2zeta)gE],
    Y=-gE^{ab} zeta_a zeta_b/2.

This field relabeling is not a derivation of universal conformal coupling.
Assume spatially flat FLRW, one rolling scalar, pressureless universally
coupled matter, smooth Q, positive density, and the equal-Einstein-potential
sector at nonzero spatial mode. Neither Q_YY=0 nor a scalar sound speed is
assumed. Keep the healthy local domain Q_Y>0 and
D=Q_Y+2Y Q_YY>0 separate from the algebraic inverse.

Physical proper time is tau; dot denotes Einstein proper time tE, prime tau.
Let a=A aE, d tau=A dtE, A=exp(zeta),

    h=a'/a, q=zeta', ell=h-q, R=rhoE/(M^2 A^2),
    G=Q_Y q/M^2, C=R/G, d=2/G, e=1+d ell.

The inverse requires qG nonzero; this is not a global chart. In Newton gauge
the Einstein potentials are P. The physical potentials are Psi=P+J and
Phi=P-J with J=delta zeta. For matter velocity potential U in Einstein time,
put Z=A U and delta_b=delta rhoE/rhoE-J.

## Necessary momentum and matter equations

Scalar momentum density is Q_Y dot(zeta) J, so Einstein 0i and the dust
equations become

    P'+ell P=(G J-R Z)/2,
    Z'=-P-J,
    delta_b'=3P'-Delta Z/a^2.

Eliminating J gives exactly

    Z'+C Z=-d P'-e P.

This algebra never uses Q_YY, the scalar mass, or canonical normalization.
The photon geodesics depend only on the physical metric; therefore the
same geometric light-cone operator L and primitive lensing/redshift map in
the frozen PR9641 source give L Z=Yredshift. All reception-gain commutator
identities in that milestone follow from these same two equations.

In particular, the fourteen-column necessary coefficient inverse still
returns C,d,e and gain histories when its stated rank, regularity and
calibration conditions hold. The recovered coefficients imply

    G=2/d, R=C G, q=h-(e-1)/d, Q_Y/M^2=G/q.

This is a general-kinetic necessary inverse. It does not authorize reusing
the canonical scalar equation or canonical Hamiltonian residual to certify
a general-Q candidate. It does not show measured rank, fix the common
absolute gain or select an action. The canonical attainable-rank fixture
remains a member of this larger class, so it proves existence in that class,
but not rank for every noncanonical solution.

## Background action data and remaining ambiguity

Friedmann, Raychaudhuri and dust conservation imply

    Pi=Q/(M^2 A^2)=qG+R-3ell^2,
    -2(ell'+q ell)=qG+R,
    R'=(2q-3h)R.

Along the reconstructed history, Y=A^2 q^2/2. Differentiate Q=M^2 A^2 Pi:

    Q_zeta/(M^2 A^2)
      =[Pi'+2q Pi-G(q'+q^2)]/q.

These are values/derivatives on the visited trajectory, with the common
normalization A0 and M still conditional. The associated scalar background
equation must be checked; its redundancy requires the stated nonzero
velocity, Einstein equations and matter conservation. A scalar principal
speed measurement would additionally constrain

    2Y Q_YY/Q_Y=c_s^{-2}-1.

The photon coefficient inverse alone does not measure that derivative.
Even on a trajectory with luminal response, higher transverse derivatives
and behavior away from sampled states remain open, as the separately
checked finite-history construction shows. No assumed potential selector
or canonical coordinate is counted as a derived law.

## Original equations used for the next controls

The independent checks must start from this full action, not merely the
eliminated equation. In Einstein time, with D=Q_Y+2Y Q_YY:

    3M^2 H^2=2Y Q_Y-Q+rhoE,
    -2M^2 dot(H)=2Y Q_Y+rhoE,
    dot(rhoE)+3H rhoE=dot(zeta)rhoE,
    D ddot(zeta)+3H Q_Y dot(zeta)+2Y Q_Yzeta-Q_zeta=-rhoE.

For equal Einstein potentials and deltaY=dot(zeta)dot(J)-dot(zeta)^2 P:

    2M^2(dot(P)+H P)=Q_Y dot(zeta)J-rhoE U,
    2M^2 Delta P/aE^2-6M^2 H(dot(P)+H P)
       =D deltaY+(2Y Q_Yzeta-Q_zeta)J+rhoE(delta_b+J),
    2M^2[ddot(P)+4H dot(P)+(2dot(H)+3H^2)P]
       =Q_Y deltaY+Q_zeta J,
    dot(U)=-P-J-dot(zeta)U,
    dot(delta_b)=3dot(P)-Delta U/aE^2.

The scalar residual can be obtained directly by varying the divergence
equation div(Q_Y grad zeta)+Q_zeta-rhoE=0. With B=Q_Y dot(zeta),

    -aE^-3 d_t{aE^3[D dot(J)+Q_Yzeta dot(zeta)J
                          -(D+3Q_Y)dot(zeta)P]}
    -2P aE^-3 d_t(aE^3 B)+Q_Y Delta J/aE^2
    +Q_zetazeta J+Q_Yzeta deltaY-rhoE(delta_b+J)=0.

Signs and all coefficients will be tested against a full noncanonical
family and pressure/scalar constraints, not assumed from the reduced map.

## Exact noncanonical background family to challenge selection

Set M=1, Einstein t>0, p=3/2, r=5/2, rhoE=(1/2)t^-2,
aE=t^p, zeta=r ln t and A=t^r. For kinetic power n>1/2 choose

    Q=K0 exp(s zeta) Y^n - V0 exp(-2zeta/r),
    s=(2n-2)/r,
    Tkin=5/(4n), K0=Tkin/(r^2/2)^n,
    V0=15/4+5/(4n).

Along this history Q_Y=2/5, D=(2n-1)2/5 and c_s^2=1/(2n-1).
All n share the same q,G,R and physical background, while their principal
scalar responses differ. This is a family of different supplied actions,
not same-action nonuniqueness or equality of every perturbative photon
record. n=1 is the earlier canonical fixture in a rescaled field label;
n=2 is an explicit noncanonical positive-cone alternative.

For harmonic spatial amplitudes Delta=0 use P=t^s0, J=jP,
U=u tP, delta_b=bP. The original constraint/matter system predicts

    2(s0+3/2)=j-u/2,
    (s0+7/2)u+j+1=0,
    s0(b-3)=0,
    (2n-1)s0 j=5n-16-9s0-(2n-11/2)j-b/2.

These are proposed algebraic fixtures, to be checked against every original
linear equation including pressure and the scalar variation. No canonical
eigenvalue is assumed for n different from1. Controls will also include
nonzero-k local initial data to distinguish the n-dependent principal
response, and explicit wrong-source/normalization mutations. Failure of a
fixture is retained and repaired or rejected without changing observations.

All present histories and modes are synthetic development inputs. Existing
observational arrays remain unopened. Empirical acceptance needs a justified
mapping from actual records to the registered inputs and bounded errors.
