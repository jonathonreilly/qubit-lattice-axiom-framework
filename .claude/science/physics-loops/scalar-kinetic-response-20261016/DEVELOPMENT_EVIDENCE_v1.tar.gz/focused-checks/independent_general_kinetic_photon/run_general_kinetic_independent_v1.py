#!/usr/bin/env python3
"""Run independent algebra cases with exact source/stream preservation."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "DERIVATION_BEFORE_CODE_v1.md",
    "NEUTRAL_CONTRACT_v1.json",
    "PRE_CODE_FREEZE_v1.json",
    "permitted_prior_sources_v1/docs/SCALAR_PHOTON_CALIBRATION_NOTE_2026-10-16.md",
    "permitted_prior_sources_v1/scripts/scalar_photon_reception_core.py",
    "check_general_kinetic_independent_v1.py",
    "run_general_kinetic_independent_v1.py",
]
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

own=Path(__file__).resolve().parent
def bind(name):
    raw=(own/name).read_bytes()
    return {"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
before={n:bind(n) for n in AUDIT_INPUT_PATHS}
names=[f"ATTEMPT01_{c}.{ext}.txt" for c in ["geometry","scalar","mapping","jets"]
       for ext in ["stdout","stderr"]]+["INDEPENDENT_RUN_v1.json"]
assert not any((own/n).exists() for n in names),"Refusing to overwrite attempts"
env=os.environ.copy();env["PYTHONDONTWRITEBYTECODE"]="1"
record={"stage":"Independent calculation before new author exposure",
    "started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "timeout_per_process_seconds":120,"bytecode_disabled":True,"python":sys.executable,
    "source_bindings_before":before,"attempts":[]}
for case in ["geometry","scalar","mapping","jets"]:
    command=[sys.executable,"-B",str(own/"check_general_kinetic_independent_v1.py"),case]
    start=time.monotonic()
    try:
        result=subprocess.run(command,cwd=own,env=env,capture_output=True,timeout=120,check=False)
        stdout,stderr=result.stdout,result.stderr
        code=result.returncode;timeout=False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr=exc.stdout or b"",exc.stderr or b""
        code=None;timeout=True
    out=f"ATTEMPT01_{case}.stdout.txt";err=f"ATTEMPT01_{case}.stderr.txt"
    (own/out).write_bytes(stdout);(own/err).write_bytes(stderr)
    item={"case":case,"command":command,"elapsed_seconds":time.monotonic()-start,
          "exit_code":code,"timed_out":timeout,"stdout":out,"stderr":err,
          "stdout_binding":bind(out),"stderr_binding":bind(err)}
    try:
        parsed=json.loads(stdout)
        item.update({"passed":parsed["passed"],"failed":parsed["failed"]})
    except (json.JSONDecodeError,KeyError,TypeError):
        item["result_parse"]="No complete expected JSON"
    record["attempts"].append(item)
    print(json.dumps(item),flush=True)
record["source_bindings_after"]={n:bind(n) for n in AUDIT_INPUT_PATHS}
record["sources_unchanged"]=record["source_bindings_before"]==record["source_bindings_after"]
record["finished_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(own/"INDEPENDENT_RUN_v1.json").write_text(json.dumps(record,indent=2)+"\n")
print("run_sha256="+bind("INDEPENDENT_RUN_v1.json")["sha256"],flush=True)
raise SystemExit(0 if record["sources_unchanged"] and all(a["exit_code"]==0
    and not a["timed_out"] and a.get("failed")==0 for a in record["attempts"]) else 1)

