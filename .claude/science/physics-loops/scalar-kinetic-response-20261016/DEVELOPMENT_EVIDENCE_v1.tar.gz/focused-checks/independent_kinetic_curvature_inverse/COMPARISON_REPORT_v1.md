# Post-exposure kinetic-curvature and internal-zero comparison

The Hamiltonian rewrite, normalized kinetic inverse, compatibility/error conditions and regular-zero recovery agree with the independent derivation. One scope finding remains in the generic one-record ambiguity wording: a real coefficient inferred from complex records requires real/imaginary rank analysis. A varying-phase single complex record can determine it without an internal zero. This qualifies both the author's generic wording and my earlier generic rank-one discussion; neither frozen source is changed here.

Read the complete main inverse note/runner and zero-crossing note/runner, their outputs and execution/source receipts after the independent seven-file freeze. Exact copies and hashes are in author_comparison_v1 and COMPARISON_SOURCES_v1.json. No KINETIC_CURVATURE_WEAK source content was read. File names were incidentally visible in the directory listing only.

## Main inverse correspondence

Author Xi is independent W, author U=S/R is independentu, and author S=2YQ_YY/M² is independentBq². The density residual B_density is independentR d0. Thus the equations are exactly delta_b=B_density/R−U Xi and Xi U'+Xi' U=V. The dust contrast+J term, mixed-jet elimination and determinant signs agree. U' and U are distinct unknown coefficients pointwise; differentiating recoveredU remains an additional history-consistency check. Unused rows and original field equations remain necessary; no sufficient action reconstruction is claimed.

The observable normalized curvature is S=RU, or A²Q_YY/M²=S/q², not absoluteQ_YY without A,M normalization. Sound speed F/(F+RU) requires its regular positive kinetic denominator. q!=0,R>0, common background/state, registration and controlled smooth derivatives are explicit. Exact rank alone is not conditioning. The stated matrix perturbation estimate is valid for a subordinate fixed norm, with its required invertibility margin and column normalization. In the runner the nearby comment says Euclidean units, but the actual function norminf and computed bound use the induced infinity norm; this is a norm-label imprecision, not a false bound. There is no primitive-noise certificate.

## Regular zero and history consequence

For smooth compatible histories, (U Xi)'=V integrates to U Xi=C+integralV. A continuousU at an internal simple zero of Xi forces the product there to zero, fixesC, and gives U0=V0/Xi0'. Away from zeros division recoversU; finite limits and compatible vanishing integrals remain necessary at further zeros. An identically zero interval supplies noU information. The note correctly distinguishes pointwise rank deficiency from history regularity. Its integral formula uses the inherited smooth-record assumptions; as an abstract minimal-regularity theorem it should additionally require V and U Xi to satisfy the fundamental theorem of calculus (for example continuousV and an absolutely continuous product). No pathological nondifferentiable-record inference is endorsed here.

The n=3/2 superposition is a legitimate one-record linear combination in the stipulated local full-action sector, with Xi=(15/4)(t^-10−t^-15/2), Xi'(1)=−75/8, V(1)=−15/2 andU(1)=4/5. Its regular history is4t^7/5. The real application still must establish the zero and error bounds. The near-zero uncertaintyB|Xi0|/xi_min is correct under its explicitly supplied amplitude bound; it does not remove a noisy integration constant for free.

## Finding: real parameters and complex records

For a real action/background, U andU' are real. A single complex equation must therefore be stacked as

    [Re Xi  Re Xi'] [U'] = [Re V],
    [Im Xi  Im Xi'] [U ]   [Im V].

Its determinant is Im(conj(Xi)Xi'). It can be nonzero even with only one complex record and no zero ofXi. The explicit compatible algebraic example Xi=e^(i tau),V=i e^(i tau) gives U'+iU=i and uniquely U=1,U'=0 at every time. Xi never vanishes. A formal added C/Xi preserves the complexified differential equation, but its real-U restriction across a varying phase forcesC=0. This example is a coefficient-equation counterexample, not asserted to be a complete physical scalar solution.

Thus 'one history leaves an undetermined constant' is valid generically for a real or fixed-phase response away from zeros, or when the unknown coefficient is artificially complexified. It is not universal over the admitted complex-amplitude records with a real kinetic coefficient. The rank-two complex-record formula remains a sufficient inverse; it is not a necessary rank criterion. The simple-zero theorem is still sufficient and correct, but a regular zero is not the only way a single record can identify realU. The lower-rank statements in my frozen independent derivation have the same field-of-scalars limitation; this report explicitly corrects their interpretation without rewriting that record. Six exact controls record the counterexample and general real-stacked determinant.

## Independent correspondence computation

The author84/0 and18/0 outputs were reproduced in owned copies under120-second bytecode-disabled caps; complete check lists match the stored outputs, exit0 and empty stderr. No failure occurred. The main runner verifies density/conservation/inversion on imported mode formulas but does not itself test every original field equation for those modes.

To check that boundary independently, check_comparison_v1.py constructs its own explicit smooth action representative with the required two-jet:

    Q=(2/5)Y−5exp(−4zeta/5)
      +[4(2n−2)/125]exp(4zeta/5)[Y−(25/8)exp(−4zeta/5)]².

Along zeta=(5/2)logt it has the stated background and kinetic/mixed jets. It verifies the background equations and all six original linear momentum/Hamiltonian/pressure/Euler/number/scalar residuals for the four stated modes atn=1,3/2,2, plus a distinct regular-zero polynomial example:82/0. This is a post-exposure independent action-jet representative, not independent discovery of the exposed mode formula or proof of a uniquely selected global action. The inherited common linear jets suffice for these residuals; nonlinear/off-history behavior remains free.

Artifacts include COMPARISON_SOURCES_v1.json, COMPARISON_RECEIPTS_v1.json, both full author replays, check_comparison_v1.py with its output/receipt, and check_complex_rank_v1.py with its output/receipt. COMPARISON_FINAL_BINDINGS_v1.json binds all comparison evidence and confirms the seven original files remain unchanged. Root was notified of the complex-real rank finding. No author file, weak-source content, PR, workflow or audit state was altered. Awaiting any narrow correction instruction.
