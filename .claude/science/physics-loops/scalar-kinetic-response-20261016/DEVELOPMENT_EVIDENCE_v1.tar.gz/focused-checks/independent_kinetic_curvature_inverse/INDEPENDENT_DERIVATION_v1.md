# Independent kinetic-curvature identification from linear records

Pre-author derivation from the neutral assignment. No new root KINETIC_CURVATURE_INVERSE or GENERAL_KINETIC_PHOTON source has been read. Work within the supplied general-Q Einstein scalar/conformal bare-dust action, with zeta=ln A, A=e^zeta up to fixed normalization, Y=−(grad zeta)²/2. Primes denote physical tau derivatives, d tau=A dtE. The common background a,A,q=zeta',h=a'/a,ell=h−q,R=rhoE/(M²A²),F=Q_Y/M²,E=Q_zeta/(M²A²) is already reconstructed and must satisfy its original equations. Assume smoothness, R>0 and q!=0 on the regular connected interval when claiming a kinetic-curvature inverse. Input P,J=delta zeta,Z=AU and spatial Laplacian are calibrated registered Newtonian-gauge linear records, not newly derived observables.

## Hamiltonian constraint derived from the stress tensor

The scalar energy density is rhoQ=2YQ_Y−Q. In Einstein Newtonian gauge deltaY=A²q(J'−qP). The scalar density perturbation is

    delta rhoQ=(Q_Y+2YQ_YY)deltaY+(2YQ_Yzeta−Q_zeta)J.

Bare-dust contrast delta=delta rho_bare/rho_bare differs from Einstein dust contrast: delta rhoE=rhoE(delta+J). The linear Hamiltonian constraint, divided by M²A², is

    G=2Delta P/a²−6ell(P'+ell P)
     =(F+Bq²)q(J'−qP)+(q²Q_Yzeta/M²−E)J+R(delta+J),
    B=A²Q_YY/M².

The dust+J term is indispensable. Background Y=A²q²/2 gives Y'=A²q(q'+q²), and the along-trajectory identity

    F'=q Q_Yzeta/M²+Bq(q'+q²)

eliminates the mixed derivative without prescribing off-trajectory Q. Define solely from records and reconstructed background

    W=q(J'−qP)−(q'+q²)J,
    d0=[G−Fq(J'−qP)−(qF'−E+R)J]/R,
    u=Bq²/R.

Then the exact first-order Hamiltonian density is

    delta=d0−u W.                                      (1)

This identity can be checked independently by varying the original scalar and dust energy density before any inverse manipulation. The coefficient u is common to all records sharing the background; dust density initial constants need not be shared.

## Removing density constants by conservation, and rank

Bare-dust conservation in these variables is

    delta'=Ddust=3P'−Delta Z/a².

Differentiating(1), each record i therefore supplies

    W_i u'+W_i' u=V_i,
    V_i=d0_i'−3P_i'+Delta Z_i/a².                        (2)

No integral or dust initial condition has been chosen. For two records at a common background time, define Delta12=W1 W2'−W2 W1'. If nonzero,

    u=(W1 V2−W2 V1)/Delta12,
    u'=(V1 W2'−V2 W1')/Delta12.                         (3)

For more records require consistency of all rows of M=[W,W'] with vector(u',u). Rank two uniquely fixes this pair at that time. Across an interval, the recovered u must actually differentiate to the recovered u'; otherwise the records are incompatible. This integrability condition and all unused rows are necessary tests, not optional smoothing choices.

The exact lower-rank criterion for u alone is that every null vector of M has zero second component. Thus if every W_i=0 but some W_i'!=0, u is uniquely fixed at that event although u' is not. If M=0, the V rows must vanish and neither unknown is identified. When W is nonzero and rank one, u is generally not fixed by a single event. On a rank-one interval with W_i=c_i w(t) for constant record ratios, the compatible common equation is (u w)'=v(t); u has the surviving freedom c/w(t). Equation(1) then shifts each record's density by the corresponding constant−c c_i. This is precisely an undetermined density-initial-data direction rather than a derived zero constant. Zeros of w and regular continuation may constrain it globally; no universal persistence through singular points is asserted.

These distinctions do not require statistical independence of records. They require genuinely different response histories yielding the stated matrix rank. Repeating proportional responses gives no new rank. Registered records may have different preparations or spatial profiles, with each Delta known; the background and action derivatives must be common.

## What is identified and what is not

For nonzero q and positive R, the directly inferred normalized curvature is

    B=R u/q²=A²Q_YY/M²,
    Q_Y+2YQ_YY over M² = F+R u,
    c_s²=F/(F+R u).

Absolute Q_YY additionally depends on the chosen M and A normalization. Healthy-branch checks F>0,F+Ru>0 remain necessary. At q=0 the quadratic kinetic-curvature contribution loses sensitivity; at R=0 this density-normalized scheme is undefined. Other inverses in such regimes would require separate analysis. Small determinant/singular value, small q or unknown calibration makes the inverse poorly conditioned.

Given u and a monotonic regular zeta chart, the remaining second derivatives along the trajectory follow from the chain rule:

    Q_Yzeta/M²=F'/q−B(q'+q²)=Lmix,
    Q_zetazeta/(M²A²)=(E'+2qE)/q−Lmix(q'+q²).

The background value is Q/(M²A²)=Fq²+R−3ell² by Friedmann. These equations constrain the two-jet along the known trajectory, not an open state-space action. They must agree with the independently reconstructed background derivatives. The scalar equation, momentum, Euler, Einstein pressure and all observation maps still have to hold for existence; Hamiltonian plus bare conservation alone are not sufficient for a general record family.

A deformation lambda f(zeta,Y)[Y−Y0(zeta)]³ has zero two-jet on the monotonic trajectory and preserves these background/linear data while changing nonlinear/off-trajectory behavior. Coordinate, mass/normalization and off-trajectory freedoms are not retired. This use of nonlinear reconstruction ambiguity is a conditional example, not a novelty claim or universal impossibility theorem.

## Error bounds and weak alternative

For an exactly consistent full-rank finite design M beta=V with beta=(u',u), perturbed design M+E_M and right side V+e_V, least-squares recovery satisfies

    ||beta_hat−beta|| <= (||e_V||+||E_M||||beta||)
                         /(sigma_min(M)−||E_M||)

when the denominator is positive. Column scaling changes the coefficient coordinates and must be declared. This bounds errors in derivative-level features, not primitive instrument noise. Background errors affect M,V as well as the output normalization and need propagation; a claimed rank without a singular-value margin is not a finite-error certificate. With exact R,q, |delta B|<=|R/q²| |delta u|; density errors obey |delta delta|<=epsilon_d0+|u|epsilon_W+|W|epsilon_u+epsilon_u epsilon_W. Positivity and sound-speed ratios additionally require a nonzero denominator margin.

For compact dtau tests w, conservation can also be written without differentiating d0 or uW:

    integral w'(uW−d0)−w Ddust d tau=0.

This is a fixed-candidate necessary weak constraint, not the pointwise rank-two inverse, and still requires the derivatives already in W,d0,Ddust. It does not create a primitive-data availability result or eliminate finite-test null directions.

## Independent physical and algebraic controls planned before code

First vary a symbolic general Q stress tensor and verify(1) and the chain-rule elimination independently. For rank attainment use an explicit canonical member Q=Y−(3/2)e^(−2zeta), M=1,A=e^zeta, with Einstein t>0 background aE=t,zeta=ln t,rhoE=t^-2,rho_bare=t^-3. Then a=t²,q=ell=t^-2,h=2t^-2,R=t^-4,F=1,E=3t^-4; all background equations are checked directly. Nonzero spatial solid harmonics with Delta=0 are allowed since the task assumes known Delta, not a mandatory Fourier eigenvalue.

The exact canonical linear four-state system in ln t for(P,J,tJ_dotE,U/t) is

    t d/dt(P,J,jv,ve)=(-P+J/2−ve/2,
                       jv,
                       −P−4J−jv−5ve,
                       −P−J−2ve).

Derive/verify this from original scalar, Einstein momentum/Hamiltonian, dust continuity/Euler and pressure equations. Its scalar pair has exponents m=−1±i sqrt(14)/2. Use the corresponding eigenvectors, or their real/imaginary solution pair, and check W/W' rank and recovery u=0 directly. This gives a full-action rank witness in the canonical subclass, not assumed rank in all general-Q cases. Additional algebraic records with nonzero u verify inverse signs and rank-one density-constant ambiguity, explicitly without claiming they are full dynamical solutions. Preserve failures; bounded120second bytecode-disabled runs; no author exposure before output freeze.
