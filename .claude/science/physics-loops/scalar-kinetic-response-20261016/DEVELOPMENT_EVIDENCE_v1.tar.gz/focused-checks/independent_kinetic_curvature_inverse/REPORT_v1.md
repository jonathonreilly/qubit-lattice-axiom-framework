# Independent on-trajectory kinetic-curvature inverse

A conditional inverse exists without supplying bare-dust perturbation initial constants. It identifies a normalized kinetic curvature from sufficiently different registered linear histories, not an action on an open state space or a primitive observational pipeline. All new author sources remain unread.

The independent derivation was frozen before coding at2026-10-16T15:16:08.089086Z, SHA2568ee7fc948c28d8f452b27819b88bf9480f8fac39270822be295cb9545c4a3a05. Inputs were the neutral general-Q conformal-dust assignment and already specified reconstructed background/conditional fields. OUTPUT_FREEZE_v1.json binds the seven independent artifacts.

Write B=A²Q_YY/M² and u=Bq²/R. Direct stress variation gives delta rhoQ=(Q_Y+2YQ_YY)deltaY+(2YQ_Yzeta−Q_zeta)J with deltaY=A²q(J'−qP). Einstein dust contrast is delta+J, not bare delta alone. Eliminating Q_Yzeta with the along-trajectory F' identity yields

    delta=d0−uW,
    W=q(J'−qP)−(q'+q²)J,
    d0=[2DeltaP/a²−6ell(P'+ellP)−Fq(J'−qP)
        −(qF'−E+R)J]/R.

Bare conservation then gives W u'+W' u=d0'−3P'+DeltaZ/a² for every record. Two nonproportional rows determine(u',u) algebraically; consistency across unused records and time differentiation of recovered u remain necessary. No density constant was selected by integrating conservation.

The exact degeneracies matter. Proportional response histories generally leave u→u+c/w, equivalent to shifting each bare-density contrast by an independent proportional constant. A special rank-one event with allW=0 but someW'!=0 determinesu alone. q=0, R=0 and zero singular-value margins are outside the claimed regular inverse. Rank is a property of the actual records, not a consequence of counting them. All original scalar/Einstein/dust equations and measurement maps remain existence checks; the differentiated Hamiltonian alone is not sufficient.

The inferred combination is B=Ru/q²; absolute Q_YY additionally depends on M and A normalization. The principal kinetic coefficient is F+Ru and c_s²=F/(F+Ru), subject to positivity/nonzero-denominator checks. Along-trajectory identities then constrain the other second derivatives. Cubic deformations transverse to the background state curve remain invisible to its two-jet and linear histories. The class, normalization and off-trajectory action are not derived.

The independent checker performs stress variation before the inverse substitution and verifies the signs, dust+J term and chain rule. A full canonical-action rank witness uses Q=Y−(3/2)e^(−2zeta), A=e^zeta, M=1, aE=t,zeta=ln t,rhoE=t^-2. Original Friedmann/Raychaudhuri/scalar/bare-dust background equations and linear momentum/Hamiltonian/scalar/Euler/dust/pressure equations are checked. Two real preparations from the scalar pair m=−1±i sqrt(14)/2 give the exact design at t=1

    [−33/5,             186/5]
    [−3sqrt(14)/5, −3sqrt(14)/10],

with determinant243sqrt(14)/10 and recoveredu=0. The nonzero spatial solid-harmonic profiles have known Delta=0; they are local full-action linear solutions, not a generic survey or Fourier-rank claim. Separate nonzero-u algebraic records test the inverse and rank-one ambiguity but are explicitly not asserted to solve the full field system.

Thirty-one exact controls pass. The derivative-feature noise bound has a singular-value margin and is verified on a separate rational example. It is not a raw-record noise guarantee, and supplied-background errors require additional propagation. A compact-test conservation form is also checked; it retains finite-test ambiguity. Controls overlap and are not independent experiments. The bytecode-disabled120-second-bounded run completed normally in under one second, exit0, empty stderr. No failures occurred.

Files: INDEPENDENT_DERIVATION_v1.md, DERIVATION_FREEZE_v1.json, check_v1.py, stdout_v1.json, stderr_v1.txt, receipt_v1.json and OUTPUT_FREEZE_v1.json. No author-source comparison, formal audit, PR or empirical validation has been performed. Waiting for direction after this independent freeze.
