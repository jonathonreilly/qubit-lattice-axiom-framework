# Inferring the transverse kinetic derivative from multiple linear records

Root derivation before code, extending GENERAL_KINETIC_PHOTON_DERIVATION_v1.
All quantities are conditional reconstructed inputs; no empirical detection
or available experimental reconstruction is asserted. The purpose is to
replace a selected kinetic curvature by an explicit test of independent
perturbation histories on the same background.

Assume the preceding general-Q class, q nonzero, R positive, and registered
physical-time coefficients and fields (a,q,G,R,P,J,Z). Such fields may be
supplied by a successful photon inverse with all its rank/calibration/domain
requirements, or by a separately justified measurement map. Do not assume
that every tide or photon data set supplies them. Primes denote physical
proper time and Delta the registered comoving spatial Laplacian.

Define

    F=Q_Y/M^2=G/q,
    E=Q_zeta/(M^2 A^2),
    S=2Y Q_YY/M^2,
    Xi=q J'-q^2 P-(q'+q^2)J.

E is the background derivative from the preceding note. Xi is the scalar
kinetic displacement transverse to the sampled background trajectory:

    deltaY-(Y'/q)J=A^2 Xi.

Because F'=q Q_Yzeta/M^2+Y' Q_YY/M^2, the original scalar density variation
can be rewritten without choosing Q_Yzeta independently:

    delta rho_Q/(M^2 A^2)
      =F(q J'-q^2P)+(q F'-E)J+S Xi.

The full Hamiltonian constraint, including dust, therefore gives

    B=2Delta P/a^2-6ell(P'+ell P)
         -F(q J'-q^2P)-(q F'-E+R)J
      =S Xi+R delta_b.

Here B is a newly defined density residual, not the lensing primitive B of
PR9641. In any integrated implementation rename it B_density to avoid
mixing these two symbols. Neither B_density nor Xi contains a supplied
scalar potential, scalar mass or dust density perturbation.

Dust conservation removes the unobserved density perturbation derivative:

    V=(B_density/R)'-3P'+Delta Z/a^2
      =U' Xi+U Xi',       U=S/R.

At one physical time, two independently registered perturbation records
of the same background yield

    [Xi_1  Xi_1'] [U'] = [V_1],
    [Xi_2  Xi_2'] [U ]   [V_2].

If W=Xi_1 Xi_2'-Xi_2 Xi_1' is nonzero, then

    U'=(V_1 Xi_2'-V_2 Xi_1')/W,
    U =(Xi_1 V_2-Xi_2 V_1)/W.

For several records, use the corresponding common-coefficient linear
system and expose residuals. Differentiating the recovered U must agree
with the separately recovered U'; it is an independent compatibility
condition, not an identity for arbitrary input records. Then

    S=R U, c_s^2=F/(F+R U), D/M^2=F+R U.

Recovery of U fixes each candidate delta_b=(B_density-S Xi)/R.
The original Hamiltonian, pressure, scalar, dust and photon equations still
need checking. In particular arbitrary fields may satisfy this two-column
relation while violating other physical equations. The claim is necessary
coefficient identification on a nonzero-rank patch, not a sufficiency theorem
for a full action or a global uniqueness claim.

## Degenerate records are informative about the limit

If Xi vanishes identically, that perturbation travels tangent to the
background state curve and carries no information about S in this map.
One history alone supplies a differential equation for U Xi with an
undetermined constant; choosing that constant would reintroduce an initial
density assumption. Two proportional histories have zero W and do not
remove it. Distinct spatial harmonics are useful only when their temporal
responses give nonproportional Xi histories. Angular multiplicity alone is
not an extra independent kinetic probe.

The exact family in the preceding note provides tests. Its universal
harmonic modes m=0 and m=-5/2 are predicted to have Xi=0 even though their
metric fields are nonzero. The two n-dependent harmonic modes should give
nonzero W and return U=4(2n-2)t^7/5, since
S=(2/5)(2n-2) and R=(1/2)t^-7. This numerical factor is a prediction to
check, not an imported fit. For n=1 the recovered U should be zero; for
n=2 it should be 8t^7/5 and c_s^2=1/3.

## Domain and error contract

The inverse needs state correspondence: both records must probe the same
background Q derivatives, not unrelated environments whose coupling or
state is silently identified. Complex Fourier amplitudes are allowed with
consistent phase. A nonzero exact determinant does not guarantee a stable
experiment. For the two-column matrix M and vector V, if
||M^-1 deltaM||<1, then

    ||delta theta|| <= ||M^-1||/(1-||M^-1 deltaM||)
                         [||deltaV||+||deltaM|| ||theta||],
    theta=(U',U).

Use a fixed norm with a declared normalization of the two differently
dimensioned columns. No numerical error radius is inferred solely from
symbolic rank. The derivatives in Xi' and V require registered smooth
histories and controlled errors or a separately derived weak formulation.
This note does not assume noisy derivative estimates are bounded for free.
Absolute field/coupling scale, A0, M and the original metric/matter class
remain open. The recovered second derivative lies only on the sampled
history; finite-state data do not select a unique global action.

Controls: derive the density rewrite algebraically with arbitrary action
jets and time-trajectory jets; test complete original-action n=1 and n=2
modes and both non-informative modes; recover U and U' by an actual matrix
solve and compare to background Q_YY. Preserve a rank-zero same-temporal-
mode control and wrong-kinetic-derivative rejection. Synthetic data only.
