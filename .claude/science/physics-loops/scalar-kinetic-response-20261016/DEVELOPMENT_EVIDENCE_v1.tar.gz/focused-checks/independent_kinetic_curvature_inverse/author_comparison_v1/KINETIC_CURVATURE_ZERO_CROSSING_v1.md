# An internal zero can replace a density integration constant

Root derivation after a focused independent insight. network_history_check
reported before seeing root's kinetic-curvature source that a rank-one event
with Xi=0 and Xi' nonzero identifies U even when the two-column matrix lacks
full rank. Root rederived this point and the following history consequence.
This qualifies the generic one-record ambiguity wording in the frozen v1
note; it is not a change to the rank-two sufficient inverse.

For one record the equation is (U Xi)'=V. Assume a connected time interval,
continuous U, continuously differentiable Xi, and a known compatible V.
If Xi has a simple internal zero at tau0, then

    U(tau0)=V(tau0)/Xi'(tau0),
    U(tau)=[int_tau0^tau V(s)ds]/Xi(tau), where Xi(tau) is nonzero.

The integral's constant is fixed by continuity of U and Xi(tau0)=0; it is
not a supplied dust initial value. Two continuous solutions differ by
C/Xi away from zeros. Continuity at the internal zero forces C=0. Additional
zeros require compatible vanishing integrals and finite limits. A compatible
simple zero supplies its limit by the displayed first formula. This is a
local uniqueness statement on connected components linked through such
regular zeros, not a guarantee for arbitrary noisy records or arbitrary
multiple/interval zeros.

On an interval with Xi bounded away from zero, the generic C/Xi freedom
remains if no other information is supplied. If Xi=0 throughout an interval,
V must vanish there and that interval gives no U information. At one event
Xi=0,Xi' nonzero, U is fixed but U' is not determined by that one equation.
The distinction between a pointwise two-unknown inverse and a regular
history inverse is essential.

## Fixed original-action example before code

Use the n=3/2 full-action background already checked, with two of its
non-tangent harmonic modes sharing the same nonzero spatial harmonic. Take
their linear superposition with relative coefficient7/8:

    P=t^-3+(7/8)t^-1/2,
    J=-2t^-3+(11/8)t^-1/2,
    U_matter=2t^-2-(3/4)t^1/2,
    delta_b=3P, d tau=t^(5/2)dt.

This is one admissible record, not two assumed independent observations.
Linearity of the original system preserves its equations. Direct evaluation
should give

    Xi=(15/4)(t^-10-t^-15/2),
    Xi(1)=0, Xi'(1)=-75/8,
    V(1)=-15/2, U(1)=4/5,
    U(t)=4t^7/5.

The chosen coefficient only constructs the control; no observation has
been fitted to create its zero. A real application must establish a genuine
crossing and controlled errors from independent records.

## Bounded near-zero information

An exact observed zero is not assumed in noisy data. Suppose a supplied
physical bound |U|<=B is valid at a reference time tau0. Writing
C=U(tau0)Xi(tau0), one only obtains |C|<=B|Xi(tau0)|. Then wherever
|Xi|>=xi_min>0, the homogeneous uncertainty is at most
B|Xi(tau0)|/xi_min, plus propagated integral and Xi errors. The new bound B
is an explicit extra premise; do not call this an assumption-free recovery.
Without a justified amplitude bound and controlled crossing/error data,
use the two-record conditioned inverse or report unresolved U.

These statements infer a coefficient on a sampled history. They still do
not select off-history Q, a physical time/field normalization, or an initial
state of the universe.
