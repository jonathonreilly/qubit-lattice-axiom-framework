"""Post-exposure independent action-jet representative and complete mode residuals."""
AUDIT_TIMEOUT_SEC=120
import sympy as s,json
checks=[]
def ck(n,x):checks.append({'name':n,'pass':bool(s.simplify(s.expand(x))==0)})
t=s.symbols('t',positive=True);zz,yy=s.symbols('zz yy',real=True);n=s.symbols('n',real=True)
Y0=s.Rational(25,8)*s.exp(-s.Rational(4,5)*zz)
# Own explicit smooth representative with the same two-jet, not a copied author action.
Q=s.Rational(2,5)*yy-5*s.exp(-s.Rational(4,5)*zz)+s.Rational(4,125)*(2*n-2)*s.exp(s.Rational(4,5)*zz)*(yy-Y0)**2
on={zz:s.Rational(5,2)*s.log(t),yy:s.Rational(25,8)/t**2}
jet=lambda f:s.simplify(f.subs(on));F=jet(s.diff(Q,yy));Qz=jet(s.diff(Q,zz));Qyz=jet(s.diff(Q,yy,zz));Qzz=jet(s.diff(Q,zz,2));D=jet(s.diff(Q,yy)+2*yy*s.diff(Q,yy,2))
ck('F',F-s.Rational(2,5));ck('Qz',Qz-4/t**2);ck('kinetic_D',D-s.Rational(2,5)*(2*n-1));ck('mixed_jet',Qyz-s.Rational(4,25)*(2*n-2))
aE=t**s.Rational(3,2);Ac=t**s.Rational(5,2);H=s.Rational(3,2)/t;vb=s.Rational(5,2)/t;rho=s.Rational(1,2)/t**2;Y=vb**2/2
ck('background_Friedmann',3*H**2-(2*Y*F-jet(Q))-rho)
ck('background_Raychaudhuri',-2*s.diff(H,t)-2*Y*F-rho)
ck('background_scalar',s.diff(aE**3*F*vb,t)/aE**3-Qz+rho)
for nn in [1,s.Rational(3,2),2]:
 m=s.symbols('m');roots=s.solve((2*nn-1)*(2*m*m+7*m)+6,m)
 modes=[(s.Integer(0),s.Rational(5,2),s.Integer(-1),-s.Rational(9,2)),(-s.Rational(5,2),-s.Rational(5,3),s.Rational(2,3),s.Integer(3))]
 for mm in roots:
  jj=s.simplify((2*mm**2+10*mm+10)/(mm+4));uu=2*(jj-2*mm-3);modes.append((mm,jj,uu,s.Integer(3)))
 for i,(mm,jj,uu,dd) in enumerate(modes):
  P=t**mm;J=jj*P;Um=uu*t*P;db=dd*P;dy=vb*s.diff(J,t)-vb**2*P;Dn=D.subs(n,nn);Qyn=Qyz.subs(n,nn);Qzn=Qzz.subs(n,nn)
  vals={
   'momentum':2*(s.diff(P,t)+H*P)-F*vb*J+rho*Um,
   'Hamiltonian':-6*H*(s.diff(P,t)+H*P)-Dn*dy-(2*Y*Qyn-Qz)*J-rho*(db+J),
   'pressure':2*(s.diff(P,t,2)+4*H*s.diff(P,t)+(2*s.diff(H,t)+3*H**2)*P)-F*dy-Qz*J,
   'Euler':s.diff(Um,t)+P+J+vb*Um,
   'number':s.diff(db,t)-3*s.diff(P,t)}
  flux=aE**3*(Dn*s.diff(J,t)+Qyn*vb*J-(Dn+3*F)*vb*P)
  vals['scalar']=-s.diff(flux,t)/aE**3-2*P*s.diff(aE**3*F*vb,t)/aE**3+Qzn*J+Qyn*dy-rho*(db+J)
  for key,val in vals.items():ck(str(nn)+'_'+str(i)+'_'+key,val)
# Independent local regular-zero test, with a different polynomial record.
x=s.symbols('x',real=True);U=2+x+x*x;Xi=x*(1+x*x);V=s.diff(U*Xi,x);primitive=s.integrate(V,(x,0,x))
ck('regular_zero_integral_recovery',s.cancel(primitive/Xi)-U)
ck('regular_zero_value',V.subs(x,0)/s.diff(Xi,x).subs(x,0)-2)
C=s.symbols('C');ck('irregular_homogeneous_pole',s.limit(x*C/Xi,x,0)-C)
print(json.dumps({'scope':'Post-exposure independent full-equation action-jet correspondence and regular-zero controls; no weak-source read','checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'representative_action':str(Q),'jets':{'Q_Y':str(F),'Q_zeta':str(Qz),'Q_Yzeta':str(Qyz),'Q_zetazeta':str(Qzz),'D':str(D)}},indent=2));raise SystemExit(any(not c['pass'] for c in checks))
