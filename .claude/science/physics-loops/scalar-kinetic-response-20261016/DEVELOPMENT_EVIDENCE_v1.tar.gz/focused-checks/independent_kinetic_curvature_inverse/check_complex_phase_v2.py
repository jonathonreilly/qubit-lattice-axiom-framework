"""Narrow fixed-phase null companion to the varying-phase control."""
AUDIT_TIMEOUT_SEC=120
import sympy as s,json
x,theta,c=s.symbols('x theta c',real=True);w=1+x*x;Xi=w*s.exp(s.I*theta)
rankdet=s.simplify(s.im(s.conjugate(Xi)*s.diff(Xi,x)))
U=2+x;Uother=U+c/w
checks={'constant_phase_real_rank_deficient':rankdet==0,'real_homogeneous_shift_preserves_record':s.simplify(s.diff(Uother*Xi,x)-s.diff(U*Xi,x))==0,'shift_is_real':s.simplify(s.im(c/w))==0,'varying_phase_rank':s.simplify(s.im(s.exp(-s.I*x)*s.diff(s.exp(s.I*x),x)))==1}
print(json.dumps({'checks':checks,'passed':sum(checks.values()),'failed':sum(not v for v in checks.values())},indent=2));raise SystemExit(not all(checks.values()))
