"""Post-exposure correction of one-complex-record ambiguity wording."""
AUDIT_TIMEOUT_SEC=120
import sympy as s,json
x=s.symbols('x',real=True);Xi=s.exp(s.I*x);V=s.I*Xi
M=s.Matrix([[s.re(Xi),s.re(s.diff(Xi,x))],[s.im(Xi),s.im(s.diff(Xi,x))]])
y=s.Matrix([s.re(V),s.im(V)]);sol=s.simplify(M.inv()*y)
checks={'never_zero_record':s.simplify(s.conjugate(Xi)*Xi)==1,'real_stacked_rank_two':s.simplify(M.det())==1,'real_Uprime_zero':s.simplify(sol[0])==0,'real_U_one':s.simplify(sol[1])==1}
# General real-parameter rank criterion for a single complex equation.
a,b,c,d=s.symbols('a b c d',real=True);z=a+s.I*b;zp=c+s.I*d
checks['determinant_phase_criterion']=s.simplify(s.Matrix([[a,c],[b,d]]).det()-s.im(s.conjugate(z)*zp))==0
C1,C2=s.symbols('C1 C2',real=True);amb=(C1+s.I*C2)*s.exp(-s.I*x)
# Requiring its imaginary part vanish at0 andpi/2 already forces both constants0.
checks['real_U_eliminates_complex_constant']=s.solve([s.im(amb).subs(x,0),s.im(amb).subs(x,s.pi/2)],[C1,C2])=={C1:0,C2:0}
print(json.dumps({'scope':'Compatible coefficient-equation counterexample; not asserted a complete action solution','checks':checks,'passed':sum(checks.values()),'failed':sum(not z for z in checks.values()),'real_solution_Uprime_U':str(sol)},indent=2));raise SystemExit(not all(checks.values()))
