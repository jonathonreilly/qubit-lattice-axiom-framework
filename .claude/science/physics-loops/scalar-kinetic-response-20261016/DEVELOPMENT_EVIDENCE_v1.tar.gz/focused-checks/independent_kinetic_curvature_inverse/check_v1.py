"""Pre-author independent general-Q stress inverse and full-action rank witness."""
AUDIT_TIMEOUT_SEC=120
import sympy as s,json
checks=[]
def ck(n,b):checks.append({'name':n,'pass':bool(b)})
def zero(n,x):ck(n,s.simplify(s.expand_complex(x) if x.has(s.I) else x)==0)
# Independent first variation of rho=2Y Q_Y-Q, with dust A variation.
eps,y,y0,j,dY,zz,Q0,Qy,Qz,Qyy,Qyz,Qzz=s.symbols('eps y y0 j dY zz Q0 Qy Qz Qyy Qyz Qzz',real=True)
Q=Q0+Qy*(y-y0)+Qz*zz+Qyy*(y-y0)**2/2+Qyz*(y-y0)*zz+Qzz*zz**2/2
rho=2*y*s.diff(Q,y)-Q
pert=s.expand(rho.subs({y:y0+eps*dY,zz:eps*j})).coeff(eps,1)
zero('general_stress_first_variation',pert-(Qy+2*y0*Qyy)*dY-(2*y0*Qyz-Qz)*j)
A,M,q,qp,F,Fp,E,R,B,P,J,Jp,G,delta=s.symbols('A M q qp F Fp E R B P J Jp G delta',nonzero=True,real=True)
W=q*(Jp-q*P)-(qp+q*q)*J
d0=(G-F*q*(Jp-q*P)-(q*Fp-E+R)*J)/R
u=B*q*q/R
mix=Fp/q-B*(qp+q*q)
scalar=(F+B*q*q)*q*(Jp-q*P)+(q*q*mix-E)*J
zero('hamiltonian_density_chain_elimination',G-scalar-R*((d0-u*W)+J))
zero('along_trajectory_F_chain',q*mix+B*q*(qp+q*q)-Fp)
rhob,A0=s.symbols('rhob A0');direct=s.expand(A0*(1+eps*J)*rhob*(1+eps*delta)).coeff(eps,1)
zero('bare_to_Einstein_dust_J_term',direct-A0*rhob*(delta+J))
# Physical canonical member and all original background equations.
t=s.symbols('t',positive=True);aE=t;Ac=t;H=1/t;vel=1/t;rhoE=t**-2;bare=t**-3;V=s.Rational(3,2)*t**-2
force=-2/t**2;mass=7/t**2
zero('background_Friedmann',3*H*H-vel*vel/2-V-rhoE)
zero('background_Raychaudhuri',-2*s.diff(H,t)-vel*vel-rhoE)
zero('background_scalar',s.diff(vel,t)+3*H*vel+force)
zero('background_bare_dust',s.diff(bare,t)+3*H*bare)
# Construct original evolution before diagonalizing it, checking conservation/pressure.
p,j,jv,ve=s.symbols('p j jv ve',real=True);state=s.Matrix([p,j,jv,ve]);pd=-p+j/2-ve/2
density=-6*(pd+p)-jv+p+2*j
jvd=-2*jv-7*j-density+4*pd+4*p;ved=-p-j-2*ve
rhs=s.Matrix([pd,jv,jvd,ved]);mat=rhs.jacobian(state)
total=lambda f:s.diff(f,t)+sum(s.diff(f,x)*y/t for x,y in zip(state,rhs))
zero('original_dust_continuity',total(density)-3*pd/t)
zero('original_scalar',total(jv/t)+3*H*jv/t+mass*j+rhoE*density-4*vel*pd/t+2*force*p)
zero('original_Einstein_pressure',2*(total(pd/t)+4*H*pd/t+(2*s.diff(H,t)+3*H*H)*p)-vel*jv/t+vel*vel*p-3*j/t**2)
zero('original_Euler',2*ve+ved+p+j)
# Momentum and Hamiltonian define pd and density here, but verify direct identities.
zero('original_momentum',pd+p-(j-ve)/2)
zero('original_Hamiltonian',density-(-6*(pd+p)-jv+p+2*j))
expected=s.Matrix([[-1,s.Rational(1,2),0,-s.Rational(1,2)],[0,0,1,0],[-1,-4,-1,-5],[-1,-1,0,-2]])
ck('derived_state_matrix',mat==expected)
# Complex pair is a representation of two real independent scalar preparations.
ms=[-1+s.I*s.sqrt(14)/2,-1-s.I*s.sqrt(14)/2];rows=[];target=[];mode_report=[]
for n,m in enumerate(ms):
 jr=s.simplify((6*m+8)/(2-m));vr=s.simplify(jr-2*(m+1));vec=s.Matrix([1,jr,m*jr,vr])
 ck('physical_scalar_eigenmode_'+str(n),all(s.simplify(z)==0 for z in (mat-m*s.eye(4))*vec))
 # At t=1: q=1,q'=-2,R=1,F=1,F'=0,E=3,ell=1.
 Wi=s.simplify(jr*(m+1)-1);Wpi=s.simplify((m-4)*Wi)
 densitycoef=s.simplify(-6*(m+1)-(m*jr-1)+2*jr)
 zero('Hamiltonian_mode_density_'+str(n),densitycoef-3)
 Vi=s.simplify(m*densitycoef-3*m)
 rows.append([Wi,Wpi]);target.append(Vi);mode_report.append({'m':str(m),'Jratio':str(jr),'W':str(Wi),'Wprime':str(Wpi)})
cm=s.Matrix(rows);cv=s.Matrix(target);ck('complex_pair_rank_two',s.simplify(cm.det())!=0)
realmat=s.Matrix([[s.re(cm[0,0]),s.re(cm[0,1])],[s.im(cm[0,0]),s.im(cm[0,1])]]).applyfunc(s.simplify)
ck('two_real_preparations_rank_two',realmat.det()!=0)
sol=cm.inv()*cv;ck('physical_recovery_zero_kinetic_curvature',all(s.simplify(z)==0 for z in sol))
# Nonzero-u algebraic conservation records, no full action solution claim.
x=s.symbols('x',real=True);uf=1+x*x;Ws=[1+x,2+x*x]
Vs=[s.diff(uf*w,x) for w in Ws];design=s.Matrix([[w,s.diff(w,x)] for w in Ws]);sol=s.simplify(design.inv()*s.Matrix(Vs))
zero('nonzero_u_recovery',sol[1]-uf);zero('nonzero_uprime_recovery',sol[0]-s.diff(uf,x))
# Rank-one ambiguity is exactly a different density constant in each record.
c=s.symbols('c');w=1+x*x
zero('rank_one_homogeneous_ambiguity',s.diff((uf+c/w)*w,x)-s.diff(uf*w,x))
zero('density_constant_shift',-(uf+c/w)*w+uf*w+c)
corner=s.Matrix([[0,1],[0,3]]);ck('rank_one_value_only_corner',corner.rank()==1 and all(v[1]==0 for v in corner.nullspace()))
# Normalized curvature and sound-speed combination.
zero('normalized_curvature_recovery',R*u/q**2-B)
zero('principal_kinetic_recovery',F+R*u-(F+B*q*q))
# Weak integration by parts on separate polynomial conservation records.
wtest=x*x*(1-x)**2;d0f=x**3+2*x;Wf=1+x;df=d0f-uf*Wf;dd=s.diff(df,x)
zero('weak_conservation',s.integrate(s.diff(wtest,x)*(uf*Wf-d0f)-wtest*dd,(x,0,1)))
# Exact rational error bound example; independent of physical fixture.
MM=s.Matrix([[1,0],[0,2]]);bet=s.Matrix([2,3]);EM=s.diag(s.Rational(1,100),-s.Rational(1,100));ev=s.Matrix([s.Rational(1,100),-s.Rational(1,100)]);got=(MM+EM).inv()*(MM*bet+ev);actual=s.sqrt(sum(z*z for z in got-bet));bound=(s.sqrt(2)/100+s.sqrt(13)/100)/(1-s.Rational(1,100));ck('matrix_noise_bound',bool(actual<bound))
print(json.dumps({'scope':'Independent stress/rank identities and a full canonical-action local rank witness; algebraic nonzero-u records are not asserted full solutions','checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'mode_report':mode_report,'real_design':str(realmat),'real_determinant':str(s.factor(realmat.det())),'noise_actual':str(actual),'noise_bound':str(bound)},indent=2));raise SystemExit(any(not c['pass'] for c in checks))
