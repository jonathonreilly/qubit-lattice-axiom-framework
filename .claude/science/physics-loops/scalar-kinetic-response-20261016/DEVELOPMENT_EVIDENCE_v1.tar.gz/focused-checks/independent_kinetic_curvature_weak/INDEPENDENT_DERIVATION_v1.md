# Independent fixed-candidate weak kinetic-curvature test

Pre-author derivation. No root KINETIC_CURVATURE_WEAK source or runner has been read. Start from the already independently established Hamiltonian/conservation identity (U Xi)'=V, with prime=d/dtau, U=S/R, Xi=q(J'−qP)−(q'+q²)J, and delta_b=d0−U Xi. Background and physical-time/spatial registration are supplied and fixed. The task supplies the n=3/2 exact record and the test; neither candidate is fitted to that moment.

## Time adjoint and spatial qualification

Write

    d0=[2DeltaP/a²−6ell(P'+ellP)−Fq(J'−qP)
        −(qF'−E+R)J]/R,
    Ddust=3P'−DeltaZ/a².

The strong necessary residual is (U Xi)'−d0'+Ddust=0. For lambda=lambda'=0 at both time endpoints, its negative pairing is

    M_U=integral lambda'(U Xi−d0)−lambda Ddust d tau=0.

Choose this sign convention consistently; flipping the complete residual changes neither feasibility nor its absolute error bound. Define fixed-candidate coefficients

    bP=6ell/R,
    bJ=q(U+F/R),
    cP=−Uq²+(6ell²−Fq²)/R,
    cJ=−U(q'+q²)+(qF'−E+R)/R.

Then integration by parts yields the amplitude identity

    M_U=integral [HP P+HJ J−2lambda' DeltaP/(a²R)
                          +lambda DeltaZ/a²] d tau,
    HP=−(lambda'bP−3lambda)'+lambda'cP,
    HJ=−(lambda'bJ)'+lambda'cJ.

The endpoint conditions remove both integration stages: lambda=0 for the conservation derivative and lambda'=0 for the P',J' terms. U and background derivatives remain on the weights. No derivative of a recorded field is needed in the final form when the known spatial-profile contract is used.

For a registered Fourier/eigenmode with Delta=−k², set HP,total=HP+2k²lambda'/(a²R) and HZ=−k²lambda/a². For the supplied local harmonic profile Delta=0, these spatial terms vanish exactly. This does not mean arbitrary noisy spatial fields have zero Laplacian. The amplitude errors here refer to that registered harmonic sector. More generally pair over comoving spatial volume with a compact spatial test and use self-adjointness of Delta: the final primitive weights are HP−2Delta(lambda'/(a²R)), HJ, and Delta(lambda/a²), where lambda may include the spatial test. Spatial boundary traces must vanish or be supplied. This removes all spatial derivatives from the recorded P,J,Z too; time compactness alone is insufficient for that general spatial claim.

## Fixed-input error envelope

For fixed U, fixed registered background and the stated mode or compact spatial pairing, write M=integral(HP,total P+HJ J+HZ Z). Deterministic complex-modulus envelopes give

    |delta M|<=integral |HP,total|epsilon_P+|HJ|epsilon_J+|HZ|epsilon_Z.

No stochastic independence or noisy derivative estimate is used. These are errors of conditional reconstructed metric/scalar/velocity records, not raw photon/detector noise. A true candidate satisfying the original equations must obey |M_observed|<=its bound; finitely many such tests are only necessary conditions. Wrong candidates can lie in their null spaces. Real/imaginary treatment and real-U constraints remain as previously qualified; this fixed-test bound makes no general rank claim.

Background, coupling normalization, time/mode registration and calibration errors alter the weights, measure and input contract. They are not part of the displayed input-only bound. If weight errors are separately enclosed, their contributions can be bounded by products with field envelopes, with the mixed terms retained; uncertain time integration also needs a measure/registration enclosure. No useful such background budget is supplied here.

## Supplied physical record, exact expected moments

Use Einstein t in[1,2], d tau=t^(5/2)dt, a=t^4,
q=(5/2)t^(-7/2),ell=(3/2)t^(-7/2),R=(1/2)t^-7,F=2/5,E=4t^-7.
The specified local-harmonic fields are P=t^-3,J=−2t^-3,Z=2t^(1/2),delta_b=3t^-3. The fixed test is lambda=(t−1)^3(2−t)^3. Its value and first physical-time derivative vanish at both endpoints. Direct evaluation gives

    Xi=(15/4)t^-10, d0=6t^-3,
    Utrue=(4/5)t^7, Utrue Xi=3t^-3,
    V=−9t^(-13/2).

Compare the fixed candidates Utrue and Uwrong=0. With the above sign convention,

    M_true=0,
    M_wrong=−9 integral_1^2 lambda(t)t^-4 dt
           =393−567log2 <0.

No zero location or fitted parameter was chosen to make this test reject. The integral follows by expanding lambda/t^4=−t²+9t−33+63/t−66/t²+36/t³−8/t^4. The two candidates have different weight functions; each receives its own error bound.

For error integration in dt, write K=A H, A=t^(5/2). With dots below denoting ordinary t derivatives only,

    K_P,true=2 lambda_dot−18t lambda_ddot,
    K_J,true=−9 lambda_dot−4t lambda_ddot,
    K_P,wrong=7 lambda_dot−18t lambda_ddot,
    K_J,wrong=−9 lambda_dot−2t lambda_ddot.

Z has zero weight in this harmonic amplitude test. These expressions are an independently derived useful check on physical-time Jacobians and operator order.

## Conservative explicit uniform error budget

Set x=t−1 in[0,1], lambda=x³(1−x)³. Its derivative polynomials imply, by integrating absolute monomial bounds,

    integral|lambda_dot|dt<=8,
    integral|lambda_ddot|dt<=36,
    integral t|lambda_ddot|dt<=72.

Consequently for uniform amplitude errors epsilon_P=epsilon_J=epsilon,

    |delta M_true|<=1672epsilon,
    |delta M_wrong|<=1568epsilon.

These are deliberately conservative finite bounds, not claims about optimal dual norms. With epsilon=10^-6 the wrong exact residual exceeds twice its error radius: |393−567log2|>3136*10^-6. Therefore every perturbed pair within those uniform amplitude envelopes leaves the true candidate feasible and rejects U=0 by its own feasibility inequality. This is a deterministic separation for this fixed supplied record/test/background, not a general finite-test uniqueness result. A rigorous rational enclosure of log2 or direct positive-integrand bound must certify the numerical margin in code; floating-point agreement alone is not the certificate.

## Predeclared controls and freeze boundary

Before coding: independently substitute the stress-derived d0 and Xi; verify physical-time derivatives and both endpoint traces; compute strong-pair and primitive-weight moments independently; check the four dt weights against their above closed forms; verify exact residual393−567log2; certify the budget and rejection margin with a rational bound on log2; exercise bounded polynomial amplitude errors without ever differentiating the noisy records in the reported readout; include a deliberately incorrect physical-time Jacobian control. The same physical mode's original equations may be checked using the previously exposed n=3/2 jets, not read from any weak author source. Preserve failures. Each run bounded120seconds, bytecode disabled; no author weak exposure before output freeze.
