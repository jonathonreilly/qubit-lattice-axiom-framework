import sympy as s,json
AUDIT_TIMEOUT_SEC=120
x=s.symbols('x',nonnegative=True);t=x+1
l=x**3*(1-x)**3
p=s.Poly(s.expand(18*t*s.diff(l,x,2)-7*s.diff(l,x)),x)
j=s.Poly(s.expand(2*t*s.diff(l,x,2)+9*s.diff(l,x)),x)
b=lambda f:sum(abs(c)/s.Integer(k[0]+1) for k,c in f.terms())
kp,kj=b(p),b(j)
assert kp+kj==630
lo=2*sum(s.Rational(1,3)**(2*k+1)/s.Integer(2*k+1) for k in range(12))
assert 567*lo-393>1260*s.Rational(1,10**6)
# The independent opposite-sign dt weights agree coefficientwise.
assert s.expand(p.as_expr()+7*s.diff(l,x)-18*t*s.diff(l,x,2))==0
assert s.expand(j.as_expr()-9*s.diff(l,x)-2*t*s.diff(l,x,2))==0
assert s.integrate((p.as_expr()*t**-3-2*j.as_expr()*t**-3),(x,0,1))==567*s.log(2)-393
print(json.dumps({'passed':5,'failed':0,'P_polynomial':str(p.as_expr()),'J_polynomial':str(j.as_expr()),'P_bound':str(kp),'J_bound':str(kj),'combined_bound':str(kp+kj),'fixed_epsilon':'1/1000000','factor_two_rational_certificate':True},indent=2))
