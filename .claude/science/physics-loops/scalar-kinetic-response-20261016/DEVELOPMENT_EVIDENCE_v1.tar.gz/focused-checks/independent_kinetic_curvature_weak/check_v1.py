import sympy as s
import json
AUDIT_TIMEOUT_SEC = 120
t=s.symbols('t',positive=True); x=s.symbols('x',nonnegative=True)
A=t**s.Rational(5,2); D=lambda f:s.diff(f,t)/A
q=s.Rational(5,2)*t**s.Rational(-7,2); ell=s.Rational(3,2)*t**s.Rational(-7,2)
R=t**-7/2; F=s.Rational(2,5); E=4*t**-7
P=t**-3; J=-2*t**-3; Z=2*s.sqrt(t); db=3*t**-3
L=(t-1)**3*(2-t)**3
checks=[]
def check(name,ok):
    ok=bool(ok); checks.append({'name':name,'pass':ok})
    if not ok: raise AssertionError(name)
def eq(name,a,b=0):check(name,s.simplify(a-b)==0)
Xi=s.simplify(q*(D(J)-q*P)-(D(q)+q*q)*J)
d0=s.simplify((-6*ell*(D(P)+ell*P)-F*q*(D(J)-q*P)-(q*D(F)-E+R)*J)/R)
dust=3*D(P)
eq('Xi',Xi,s.Rational(15,4)*t**-10);eq('d0',d0,6*t**-3)
Ut=s.Rational(4,5)*t**7
eq('bare density',d0-Ut*Xi,db);eq('conservation',D(db),dust)
for e in [1,2]:
    eq('lambda endpoint '+str(e),L.subs(t,e));eq('lambda prime endpoint '+str(e),D(L).subs(t,e))
weights={}; moments={}
for name,U,cp,cj in [('true',Ut,2,4),('wrong',s.Integer(0),7,2)]:
    bP=6*ell/R; bJ=q*(U+F/R)
    cP=-U*q*q+(6*ell*ell-F*q*q)/R
    cJ=-U*(D(q)+q*q)+(q*D(F)-E+R)/R
    KP=s.simplify(A*(-D(D(L)*bP-3*L)+D(L)*cP))
    KJ=s.simplify(A*(-D(D(L)*bJ)+D(L)*cJ))
    eq(name+' P weight',KP,cp*s.diff(L,t)-18*t*s.diff(L,t,2))
    eq(name+' J weight',KJ,-9*s.diff(L,t)-cj*t*s.diff(L,t,2))
    weak=s.integrate(s.expand((KP*P+KJ*J)),(t,1,2))
    strong=-s.integrate(s.expand(A*L*(D(U*Xi)-D(d0)+dust)),(t,1,2))
    first=s.integrate(s.expand(A*(D(L)*(U*Xi-d0)-L*dust)),(t,1,2))
    eq(name+' adjoint agrees strong',weak,strong);eq(name+' first integration',weak,first)
    moments[name]=s.simplify(weak);weights[name]=(KP,KJ)
eq('true moment',moments['true']);eq('wrong moment',moments['wrong'],393-567*s.log(2))
poly=x**3*(1-x)**3
for n,b in [(1,8),(2,36)]:
    p=s.Poly(s.diff(poly,x,n),x)
    triangle=sum(abs(c)/s.Rational(k[0]+1) for k,c in p.terms())
    eq('polynomial triangle integral '+str(n),triangle,b)
check('true budget',2*8+18*72+9*8+4*72==1672)
check('wrong budget',7*8+18*72+9*8+2*72==1568)
N=12
lo=2*sum(s.Rational(1,3)**(2*j+1)/s.Integer(2*j+1) for j in range(N))
hi=lo+2*s.Rational(1,3)**(2*N+1)/(s.Integer(2*N+1)*(1-s.Rational(1,9)))
eps=s.Rational(1,10**6)
check('rational log lower proves robust separation',567*lo-393>3136*eps)
check('log enclosure width',hi-lo<s.Rational(1,10**12))
for name,budget in [('true',1672),('wrong',1568)]:
    KP,KJ=weights[name]
    for j,(dp,dj) in enumerate([(eps,-eps),(eps*(2*t-3),eps*(t-1)**2),(-eps*(2*t-3)**4,eps*(2*t-3)**3)]):
        change=s.integrate(s.expand(KP*dp+KJ*dj),(t,1,2))
        check(name+' bounded primitive perturbation '+str(j),abs(change)<=budget*eps)
# Wrong measure mutation: retain physical weights H, but integrate against dt.
KP,KJ=weights['true']
wrong_measure=s.integrate(s.expand((KP*P+KJ*J)/A),(t,1,2))
check('missing time Jacobian detected',s.simplify(wrong_measure)!=0)
print(json.dumps({'checks':checks,'passed':len(checks),'failed':0,'moments':{k:str(v) for k,v in moments.items()},'wrong_moment_decimal':str(s.N(moments['wrong'],18)),'uniform_epsilon':str(eps),'true_radius':'1672/1000000','wrong_radius':'1568/1000000','log2_lower':str(lo),'log2_upper':str(hi),'wrong_measure_mutation':str(s.simplify(wrong_measure))},indent=2))
