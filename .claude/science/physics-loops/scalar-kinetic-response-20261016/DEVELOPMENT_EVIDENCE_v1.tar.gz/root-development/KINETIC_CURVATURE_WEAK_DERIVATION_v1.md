# A finite-error test of a selected kinetic curvature

Root proof and fixed control plan before execution. Inputs are registered
metric/scalar histories P,J,Z after a justified observation map, not raw
photodetector counts. The test removes derivatives of these three inputs
from a necessary kinetic-curvature condition. Background coefficients and
candidate U=S/R still need controlled smoothness and calibration.

Use the symbols and density residual of KINETIC_CURVATURE_INVERSE_DERIVATION_v1.
For a registered comoving Fourier mode Delta=-k^2, define

    alpha=-6ell/R,
    beta=-q(F/R+U),
    gamma=2/(R a^2),
    delta=(-6ell^2+Fq^2)/R-3+Uq^2,
    epsilon=-(qF'-E+R)/R+U(q'+q^2).

Then B_density/R-3P-U Xi =
alpha P'+beta J'+(delta-k^2 gamma)P+epsilon J.
Bare-dust conservation implies, for a test lambda whose value and first
derivative vanish at both endpoints,

    int [lambda' (B_density/R-3P-U Xi)
                       +k^2 lambda Z/a^2] d tau=0.

Integrating the remaining P' and J' terms by parts gives

    int [wP P+wJ J+wZ Z] d tau=0,
    wP=-(alpha lambda')'+(delta-k^2 gamma)lambda',
    wJ=-(beta lambda')'+epsilon lambda',
    wZ=k^2 lambda/a^2.

For exact candidate weights and input error envelopes etaP,etaJ,etaZ,
the moment error is bounded by

    Etest=int [|wP|etaP+|wJ|etaJ+|wZ|etaZ] d tau.

Candidate/background/geometry errors are not part of this bound unless
explicitly propagated. A finite collection of such tests is necessary
compatibility only. It cannot select an arbitrary U function uniquely.

## Frozen constructed discrimination

Use the preceding full-action family at n=3/2 and its m=-3 harmonic mode:
P=t^-3, J=-2t^-3, U_matter=2t^-2, delta_b=3t^-3,
aE=t^(3/2), A=t^(5/2), a=t^4 and d tau=t^(5/2)dt.
The spatial harmonic may be any regular nonzero-degree solid harmonic in a
bounded patch, so Delta=0 does not mean a homogeneous metric gauge mode.
Normalize its registered amplitude to one at the sampled spatial channel.
Multiply all perturbations by a sufficiently small common amplitude for
the first-order interpretation; the error allowance scales by that amplitude.

The true kinetic history is U=4t^7/5. Test the distinct canonical candidate
U=0 on these same fixed fields and the same background. This candidate
passes the previously used background/momentum tests; the present test
challenges its kinetic curvature.

Fix t in[1,2] and lambda=(t-1)^3(2-t)^3, extended by zero. This supplies
the needed endpoint traces in physical time. For the wrong U=0 candidate,
the weights including d tau should reduce to the dt weights

    wP d tau=(18t lambda_tt-7lambda_t)dt,
    wJ d tau=(2t lambda_tt+9lambda_t)dt,
    wZ=0.

Their nominal moment should equal 9 int_1^2 lambda t^-4 dt, which is strictly
positive by the fixed integrand. The true candidate should yield zero.
Compute the strong density identity and the weak primitive moment through
separate expressions. Preserve any mismatch.

For a common pointwise amplitude error at most eta on P and J, bound
K=int_1^2(|18t lambda_tt-7lambda_t|+|2t lambda_tt+9lambda_t|)dt.
Use a predeclared conservative rational enclosure: expand each polynomial
in x=t-1 on[0,1], and bound its integral absolute value by the sum of
absolute monomial coefficients divided by exponent+1. Do not optimize the
window or bound after the outcome.

If the nominal wrong-candidate moment is Mbad>0, then every perturbed
record within eta of these true inputs rejects the wrong candidate at its
own eta K acceptance budget whenever eta<Mbad/(2K).
The factor two covers both the perturbation of the record and the candidate's
accepted uncertainty budget. Mbad/K is only the nominal zero-noise margin.
This is a deterministic constructed separation, not a confidence level,
an observational limit or uniqueness among all noncanonical histories.

The true action, its initial state, background scale and observation map
are supplied fixtures for this control. The calculation is useful only
as a demonstrated test that can in principle discriminate a kinetic
assumption; it does not count those fixture premises as derived physics.
