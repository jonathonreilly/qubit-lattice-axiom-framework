# Real kinetic coefficients, phase information, and the sampled two-jet

Root derivation before code, after the independent curvature checker found
the field-of-scalars qualification in the original one-record discussion.
The earlier files are preserved. This note corrects their interpretation;
it does not retrospectively count the correction as an independent author
prediction. All records below are constructed or conditionally registered,
not measured observations.

## One complex record contains two real equations

For a real action and background, U=S/R and U' are real. A registered
complex response satisfies Xi U'+Xi' U=V. Its real and imaginary parts give
a real two-column system. Define Wc=Im(conj(Xi) Xi'). If Wc is nonzero,

    U = Im(conj(Xi) V)/Wc,
    U'= Im(conj(V) Xi')/Wc.

This is algebraic identification from two real quadratures of one complex
response, not information obtained by calling a real channel complex.
Both quadratures and their common phase convention must be available.
A constant phase rotation changes neither result; a time-dependent
unregistered rotation changes Xi' and invalidates the interpretation.
Recovered U' must still equal the derivative of recovered U. When
Xi=r exp(i theta), Wc=r^2 theta'. A fixed-phase record has Wc=0.

On an interval where Xi does not vanish, two solutions differ by C/Xi.
Requiring both solutions to be real forces C/Xi real throughout. If Xi
takes two non-collinear complex phases, only C=0 is allowed. Thus the
undetermined integration constant in the original note applies to real
or fixed-phase records (or artificially complex U), not all complex data.
Internal zeros and continuity are another sufficient route. For that
route assume continuous V and absolutely continuous U Xi as well as the
stated smooth Xi and continuous U, so the integral identity is valid.

## Full-action constructed phase fixture

Use the n=3/2 member of the previously checked family, on t>0. The two
local harmonic modes m=-3 and m=-1/2 are independently valid solutions.
Combine them with coefficients 1 and i:

    P=t^-3+i t^-1/2,
    J=-2t^-3+(11/7)i t^-1/2,
    U_matter=2t^-2-(6/7)i t^1/2,
    delta_b=3P, Z=A U_matter.

The resulting complex coefficient multiplies a fixed nonconstant local
harmonic spatial pattern; taking its real part with the conjugate gives
real physical fields. Spatial/boundary completion is not supplied.
This is not a nonzero global Fourier mode or a measured propagation speed.
Its two real quadratures are two distinct temporal responses. The
prediction is that the realified inverse returns U=4t^7/5 and U' as its
physical-time derivative, without an internal zero of complex Xi.
Check all original linear field equations, not only the inverse relation.

## Closing the sampled action two-jet

Use the established physical-time background definitions
F=Q_Y/M^2, E=Q_zeta/(M^2 A^2), Y=A^2 q^2/2, and q=zeta' nonzero.
Write B=A^2 Q_YY/M^2=R U/q^2 and L=Q_Yzeta/M^2. Differentiating the
actual action derivatives along the sampled trajectory gives

    L=F'/q-B(q'+q^2),
    Q_zetazeta/(M^2 A^2)
      =(E'+2qE)/q-L(q'+q^2).

Thus identification of U and the already registered background gradients
fixes the normalized full second derivative of Q along that trajectory.
These are chain-rule constraints; they neither fix absolute A,M scales
nor select an extension of Q off the sampled curve. The formulas require
controlled derivatives of reconstructed backgrounds, which the weak
metric-record test does not provide by itself.

For a trajectory Y=y(zeta), additions lambda(zeta)[Y-y(zeta)]^3 preserve
Q and its full two-jet on that trajectory. Cubic and higher perturbations
or other states are therefore still needed to restrict the extension.
No unique action, potential, initial-state distribution or topology follows.

Controls will check general real linear algebra, phase rotations, the
full-action fixture, independent direct differentiation of the original
Q for n=1,3/2,2, and full two-jet vanishing of a cubic deformation.
