# Angular projection and the meaning of the error radius

The abstract primitive error inequality integrates absolute weights over time, radius and angle. The numerical fixture instead evaluates the amplitude of one normalized real Y20 harmonic, with integral Y20^2 dOmega=1. Its two-dimensional kernel norm therefore bounds errors in the recovered harmonic coefficients psi20 and z20. It is not a bound for identically sized arbitrary pointwise errors in the full sky without an angular projection factor. Root and the focused adjoint checker identified this distinction independently during source comparison.

Define psi20(tau,r)=integral Y20(n) psi(tau,r,n)dOmega, and likewise z20. The reported scalar moment is the pairing of the radial kernel coefficients with these projected records. If |delta psi20|<=epsilon_psi20 and |delta z20|<=epsilon_z20, the two-dimensional measure-weighted absolute norms apply directly. No angular derivatives of the errors are needed. A real instrument still needs a justified projection/error envelope and a mask/sampling treatment.

For an arbitrary pointwise full-sphere envelope |delta psi(n)|<=epsilon_sky, triangle inequality gives |delta psi20|<=A20 epsilon_sky, with
    A20=integral |Y20|dOmega=4 sqrt(15 pi)/9.
Derivation: Y20=sqrt(5/(16pi))(3mu^2-1), dOmega=2pi dmu. Splitting mu at +/-1/sqrt(3) gives integral_-1^1 |3mu^2-1|dmu=8/(3sqrt(3)). Thus the equal full-sky pointwise radius is at most the harmonic-coefficient radius divided by A20. Harmonic-shaped noise has different normalization: delta psi=epsilon Y20 is bounded by epsilon in coefficient space but its pixel supremum is epsilon sqrt(5/(4pi)).

The numerical coefficients and angularly projected moment are unchanged by this clarification. Old ambiguous labels primitive_uniform_radius refer only to harmonic-coefficient envelopes. No real pixel noise, harmonic extraction, survey coverage or instrument precision has been certified. The corrected full-ray support is governed by KINETIC_PRIMITIVE_RAY_DOMAIN_CORRECTION_v1.md; its new kernels and bounds are recomputed separately.

