# Rigorous refinement of the primitive error bound, before code

The first root primitive calculation passed 66 controls. It gives the nonzero wrong-candidate moment 29233/118066178630400, but expanding the input weights in unshifted eta,r monomials and integrating absolute coefficients yields a uniform radius approximately6.97e-34. This is a valid coarse bound, not the actual norm or an experimental precision claim. Preserve it unchanged.

Exact inspection shows both measure-weighted primitive coefficients a r^2 Hpsi and a r^2 Hz are polynomials: degrees(18,20) and(17,18). No singular rational denominator remains in this particular fixture. Their values at three rational interior points are finite and modest; those samples are diagnostics, not an enclosure. Tighten the bound by exact Bernstein coefficients, without altering the physical records, candidate, moment, test function or rejection rule.

Map x=eta+2 and y=r-1 onto [0,1]^2. For a polynomial p=sum a_pq x^p y^q of bidegree(n,m), its tensor Bernstein coefficients are
    b_ij=sum_{p<=i,q<=j} a_pq [binom(i,p)/binom(n,p)] [binom(j,q)/binom(m,q)].
This follows by the exact identity x^p=sum_i>=p binom(i,p)/binom(n,p) B_i^n(x), and likewise for y. The bases are nonnegative, sum to one, and each integrates to1/(n+1) or1/(m+1). Thus on a cell of area A,
    A |sum b_ij|/[(n+1)(m+1)] <= integral_cell |p|
      <= A sum |b_ij|/[(n+1)(m+1)].
The lower bound is just the absolute signed cell integral, not a pointwise lower hull.

Repeated exact de Casteljau averaging at1/2 subdivides each cell into four. Apply the same upper and lower inequalities on all leaves and sum. Rational arithmetic controls all transformations. The upper enclosure is nonincreasing by convexity under averaging, and the lower enclosure is nondecreasing by the triangle inequality. No statistical or quadrature approximation is used.

The combined upper enclosure K_upper for the two measure-weighted kernels replaces the previous conservative K in the same sufficient radius M_wrong/(2K_upper). The old coarse result remains a historical valid bound. This refinement supplies a certificate only for this constructed candidate/background/test rectangle; it does not supply instrumental errors, survey windows or temporal coverage.

Controls planned before implementation: constant polynomial; exact reconstruction at rational points; signed integral matching independently integrated power coefficients; positive quadratic after midpoint subdivision; (x-1/2)(y-1/2), whose exact L1 norm is1/16 after midpoint partition; nested enclosure and nonnegative gap; source mutation of conversion denominators, cell-area factor or deliberately underestimated bound; apply to the two frozen primitive kernels. Preserve failures and actual cost.

