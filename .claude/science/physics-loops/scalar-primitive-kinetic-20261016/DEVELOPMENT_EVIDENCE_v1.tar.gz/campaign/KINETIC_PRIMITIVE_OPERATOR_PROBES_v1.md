# Extending the primitive check beyond harmonic solutions

Root's complete-action witness is a local harmonic mode: Delta P=Delta Z=0. That is a legitimate original-action existence witness, but it cannot by itself challenge every sign in the spatial integration by parts. In particular a wrong sign on the wZ=-Delta(lambda)/a^2 contribution can have zero integrated effect against harmonic Z. A deliberate v1 source mutation is being preserved separately. Do not call such a survivor a physical failure or silently drop the spatial claim.

For arbitrary smooth probe fields P0,J0,Z0,Y0, form Ckin0 from the same displayed coefficients. Its strong residual need not vanish. Directly compare
    -integral lambda [Ckin0'+Delta Z0/a^2]
with the first weak field functional. This tests the full spatial/time adjoint, not a new full-action solution.

For the next elimination layer, let
    rE=J0+Z0'+P0,
    f0=dP0'+eP0,
    N0=Y0'+(C+h)Y0+(L+h)f0,
    rN=N0+KZ0.
With b=-v/K and the previously derived cP,cY,
    M_first-M_eliminated = integral[wJ rE-b rN].
This identity follows from one Euler substitution and the commutator residual without assuming the arbitrary probes are solutions. It checks the normalization and operator signs separately from the physical witness.

Finally use independent polynomial primitives psi0,z0 and their defined P0,Y0 map. Their eliminated-field and primitive-only functionals must agree even when their moment is nonzero. Nonzero controls prevent a zero-on-both-sides fixture from concealing the adjoint mechanism. These operator probes and full-action physical records have distinct roles.

No physical witness, action, candidate, data selection, envelope or tolerance is changed by this expansion of checks. The original66-control run and mutation outcome remain historical evidence. Freeze this extension before the new code.

