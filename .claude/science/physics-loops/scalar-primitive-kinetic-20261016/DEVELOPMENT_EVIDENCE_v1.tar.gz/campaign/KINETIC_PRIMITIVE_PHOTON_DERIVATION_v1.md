# Primitive photon records for the kinetic coefficient: root derivation before code

Direct author /root. Candidate calculation, frozen before implementation. It is not an empirical result, completed observation protocol, or independent audit.

## Problem and conditional inputs

The current response theorem takes intermediate P,J,Z as registered inputs. Derive a necessary kinetic test whose evaluated side uses only lensing and actual-event redshift primitives. Do not choose Q_YY, a potential, scalar initial state, density contrast or a transfer function to supply the answer.

Retain explicitly: the general Q(zeta,Y) action with universal conformal dust from the kinetic note, the admitted equal-Einstein-potential l>=2 linear sector, a smooth homogeneous flat background, geometric registration, the Born photon relation and consistently removed observer/additional source terms. q,G,R,F,E and derivatives remain conditional candidate histories; U=2Y Q_YY/(M^2 R) is the tested kinetic history. K=C'+hC must be nonzero on the compact test support. Smoothness and input-error envelopes remain premises. This block cannot infer a background by treating it as known.

Use matter time tau, comoving position x=r n, a(tau)>0, h=a'/a, prime=d/dtau at fixed x. Integrate in dmu=d tau r^2 dr dOmega. This measure is chosen for the weak equation, not a claim about the survey sampling measure. Spatial tests are compact in an annulus away from r=0 and in time, with the full angular sector treated explicitly. A single spherical harmonic l>=2 is an admissible sector; coefficients below preserve it.

The original kinetic reduction already derived from Hamiltonian plus conserved bare number is
    Ckin = alpha P' + beta J' + gamma Delta P + delta P + epsilon J,
    Ckin' + Delta Z/a^2 = 0,
    alpha=-6ell/R, beta=-q(F/R+U), gamma=2/(R a^2),
    delta=(-6ell^2+F q^2)/R-3+U q^2,
    epsilon=-(q F'-E+R)/R+U(q'+q^2).
Here ell=h-q; Ckin=B_density/R-3P-U Xi. For arbitrary data, this necessary equation is not sufficient for the original action equations.

Two U-independent relations, derived from momentum and Euler, are
    Z'+C Z=-f,  f=d P'+e P,
    J=-Z'-P,
    C=R/G, d=2/G, e=1+dell.
The corrected redshift is Y=LZ with L=partial_tau+a^-1 partial_r.

## First adjoint and elimination of J

For real compact test lambda, multiply the strong residual by -lambda and integrate. Spatial Delta is self-adjoint for d^3x. The necessary moment is
    M = integral [wP P+wJ J+wZ Z] dmu,
    wP=-(alpha lambda')'+delta lambda'+gamma Delta(lambda'),
    wJ=-(beta lambda')'+epsilon lambda',
    wZ=-Delta(lambda)/a^2.
Time boundary traces vanish. The sign of the spatial Z weight is fixed by the minus multiplier. With Delta=-k^2 this reduces to the existing positive k^2lambda/a^2 weight.

Substituting Euler J=-Z'-P and moving its derivative gives
    M=integral [(wP-wJ)P+v Z] dmu,
    v=wJ'+wZ.
This step needs the additional endpoint traces or compact support; the old lambda=lambda'=0 condition alone must not be reused without checking them.

## Velocity elimination by the commutator

Let T=partial_tau+C. Since [T,L]=-hL+h partial_tau-C',
    T(Y)+L(f)=-hY-hf-(C'+hC)Z.
Thus define
    K=C'+hC,
    N=Y'+(C+h)Y+(L+h)f=-K Z.

This is necessary for true records. It is not enough on arbitrary P,Y to assert an original Z solution. On K nonzero put b=-v/K. Then
    integral vZ = integral b[(partial_tau+C+h)Y+(L+h)(dP'+eP)].
For the declared measure,
    Ldagger b=-b'-a^-1(partial_r b+2b/r).
Put
    g=(Ldagger+h)b,
    cP=wP-wJ-(d g)'+e g,
    cY=-b'+(C+h)b.
Consequently
    M=integral(cP P+cY Y)dmu.
No measured J or Z appears. The 2/r term is a geometric divergence, not a fitted coefficient. K=0 is an excluded chart, not failure of the underlying theory.

## Pullback to photon primitives

Let eta be conformal time, d tau=a d eta, and u=eta+r reception conformal time. Define
    D=partial_r|tau-a partial_tau=partial_r|u.
On the admitted Born and observer convention,
    I0(u,r,n)=integral_0^r P(u-s,s n)ds,
    psi=2 integral_0^r (r-s)/(rs)P(u-s,s n)ds,
    I0=(r^2/2)D psi, P=(1/2)D(r^2 D psi),
    I1=partial_u I0,
    z=E_z-O_observer=Y-2I1.
At fixed r, partial_u=a partial_tau, so
    Y=z+a partial_tau(r^2 D psi).

Under dmu, the adjoint of D is
    Ddagger=-partial_r-2/r+a partial_tau+a'
            =-D-2/r+ah.
This follows by integrating its two vector components separately. It differs from the adjoint in flat du dr measure.

Move the derivatives from P and the path correction onto cP,cY. The resulting primitive test is
    M=integral[Hpsi psi+Hz z]dmu,
    Hz=cY,
    Hpsi=Ddagger{r^2[(1/2)Ddagger(cP)-partial_tau(a cY)]}.
Operator order and products matter. In particular Ddagger r^2 is not r^2 Ddagger, and the derivative of a cY cannot be replaced by a cY'.

For a fixed candidate reception gain g_obs(u)>0 on lensing and f_obs(u)>0 on corrected redshift, psi_obs=g_obs psi and z_obs=f_obs z. Then weights are Hpsi/g_obs and Hz/f_obs. This is only testing a supplied candidate gain pair; it does not derive those gains. Since this quotient is made after taking the adjoint, candidate gain derivatives do not enter this representation. A different source/observer convention or additive gain leakage needs a new map.

For a resolved full-sky l>=2 E-mode harmonic, gamma_lm=h_l psi_lm with h_l=sqrt[(l-1)l(l+1)(l+2)]/2. One can divide the known test weight by h_l. No l=0,1 reconstruction is required, but a mask or catalogue window is not inverted for free. Finite sampling and errors in harmonic extraction remain separate.

## Error and information statements

For fixed weights and deterministic continuum error envelopes,
    |delta M| <= integral [|Hpsi/g_obs| epsilon_psi_obs
                           +|Hz/f_obs| epsilon_z_obs] dmu.
This triangle inequality differentiates no record error. Candidate/background/geometry/gain uncertainty changes the weights and needs its own envelope; numerical quadrature needs a justified bound. Candidate-specific deterministic feasibility permits data-adaptive candidate selection only when the asserted envelopes actually hold uniformly; no confidence level is inferred.

Zero moments for finitely many tests are necessary constraints, not coefficient uniqueness or action sufficiency. The characteristic registration needs data over an open set of reception times, not merely depths on a single past light cone. Standard lensing depth tomography at one reception time is not a substitute for partial_u histories. That remaining empirical supplier must be reported and challenged, not counted as retired.

## Constructed noncanonical photon witness planned before code

Take the already full-action-checked n=3/2 member:
    Q=(5/6)(8/25)^(3/2) exp(2zeta/5)Y^(3/2)
       -(55/12)exp(-4zeta/5),
    aE=t^(3/2), A=t^(5/2), zeta=(5/2)ln t, rho=1/(2t^2), M=1.
On t>0 its local harmonic m=-3 mode is
    P=t^-3 r^2 Y20, J=-2P, Z=2t^(1/2)r^2 Y20, db=3P.
The real angular harmonic is normalized by integral Y20^2 dOmega=1. It is a local regular solid harmonic, with no global boundary or finite-energy completion asserted.

Using eta=-2/sqrt(t), t=4/eta^2 and eta<0:
    a=256/eta^8, h=-eta^7/32, q=-5eta^7/256,
    ell=-3eta^7/256, F=2/5, G=-eta^7/128,
    R=eta^14/32768, E=eta^14/4096,
    C=-eta^7/256, d=-256/eta^7, e=4, K=eta^14/65536,
    Utrue=65536/(5eta^14),
    P=eta^6 r^2 Y20/64, J=-2P, Z=-4r^2 Y20/eta.
Corrected Y=P+Z_r/a. Actual z=Y-2partial_u I0, with
    I0/Y20=sum_j=0^6 binom(6,j)u^(6-j)(-1)^j r^(j+3)/(64(j+3)),
    psi/Y20=sum_j=0^6 binom(6,j)u^(6-j)(-1)^j r^(j+2)
                    /[32(j+2)(j+3)].
Compute these primitives before applying inverse operators.

Use eta in[-2,-1], r in[1,2], and
    lambda=(eta+2)^8(-1-eta)^8(r-1)^8(2-r)^8 Y20.
Its zero extension has enough endpoint traces for the displayed finite-order operators (verify orders in the code); it is not a C-infinity bump. The abstract theorem uses smooth compact tests. All records share an arbitrarily small linear amplitude.

Planned controls: original background/full linear equations; measure and adjoint signs; direct integrals vs primitive integrals for true U and wrong U=0; nonzero wrong-candidate moment; exact rational or enclosed logarithmic error budgets; known gain pullback; actual-source mutations of radial divergence, commutator sign, path correction, adjoint order, measure, and underestimated error bound. The full-action witness is distinct from arbitrary operator probes.

Do not assert the final witness nonzero or an informative error radius until executed. If high-order weights make conditioning poor, preserve that outcome. This route removes explicit latent-field readout from the necessary test if valid; it does not close the real temporal coverage, background, calibration, physical action or state-origin assumptions.

## Context and novelty boundary

Taylor astro-ph/0111605v1 supplies established Born inverse context. Messenger/Bortz2007.02848v3 and Reinbold/Gurevich/Grigoriev1911.03365v1 establish weak derivative transfer and latent-field elimination as prior methods. Root re-opened their abstracts in this block; earlier campaign primary-source readings are separately recorded. The general method is not new. This proposed composition tests general kinetic curvature with explicit photon primitives and a full-action noncanonical witness. Earlier PR9641 tests the transport/background inverse; it does not supply this kinetic-curvature residual.

