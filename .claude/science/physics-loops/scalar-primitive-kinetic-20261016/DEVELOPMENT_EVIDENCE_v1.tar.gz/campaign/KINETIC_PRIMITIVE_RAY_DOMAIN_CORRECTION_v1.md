# Full-ray domain correction before revised calculation

Root preserves the original primitive proof, code v1/v2 and norm v1/v2/v3. Their algebraic moment and polynomial norm calculations are not being erased. The physical photon witness on the original rectangle was invalid: eta in[-2,-1], r in[1,2] allows u=eta+r>=0. At eta=-5/4,r=7/4, reception u=1/2 and the ray eta_s=u-s crosses eta_s=0 at s=1/2. The stipulated background a=256/eta^8 and expanding t=4/eta^2 chart require eta<0. Polynomial continuations of the perturbations are not a physical continuation of that background.

Root noticed the whole-ray mismatch while reading the independent witness proof. The focused inertial_response_check independently reported the same counterexample and domain requirement. This is a physical-domain failure, not an operational error or an empirical rejection of the action. The abstract adjoint identity remains conditional on a regular observation domain. The old numerical radius must not be reported as a valid full-ray physical witness.

Before any revised execution, fix eta in[-4,-3], r in[1,2]. Then -3<=u=eta+r<=-1 and every point 0<=s<=r of every ray has -4<=eta_s=u-s<=-1. The complete ray is bounded away from zero. A slightly larger open neighborhood remains inside eta<0. Source t ranges[1/4,4/9], and the ray union lies in t in[1/4,4]. This is an admissible finite local small-amplitude patch of the same stipulated background and the same original-action harmonic mode; a global completion is still absent.

Change only the temporal test support and corresponding integrations:
lambda=(eta+4)^8(-3-eta)^8(r-1)^8(2-r)^8 Y20.
Use x=eta+4,y=r-1 for unit-square polynomial bounds. All action, mode, observation, kinetic candidate and angular definitions are unchanged. The once-weak wrong-candidate moment still equals -(9/32) integral lambda eta^5 r^4 d eta dr and is strictly positive because eta<0 and lambda>0 in the interior. Its new exact value, primitive weights, conservative norm and Bernstein enclosure must be recomputed; no earlier numeric moment or bound is reused. The true candidate still has pointwise zero strong residual. Both statements are to be checked against the actual primitives, not inserted as outputs.

Add explicit coverage controls for the old counterexample and the complete new source/ray interval. Preserve the old spatial-sign mutation survivor; apply new mutations to the revised nonharmonic probe source. No threshold or candidate is selected from noisy measurements, and no empirical arrays are opened.

Historical proof identity clarification: the v2 execution receipt's ambiguous field proof_sha256=689289b78aa523162b9337d9395155f47616d37ddc4e7cfa25c6f8f04b62b5b9 binds KINETIC_PRIMITIVE_OPERATOR_PROBES_v1.md, the additional pre-code proof for the seven new arbitrary-probe controls. It does not bind or replace KINETIC_PRIMITIVE_PHOTON_DERIVATION_v1.md, whose hash is1979979683f09637d1fe66240af81a52bbfa99aa2815eec9d7f768a0b6361c68. Future receipts list paths and hashes for all proof dependencies explicitly.

