"""Scoped actual-source checks after two full mutant executions timed out."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import sympy as s

ROOT = Path("/Users/jonBridger/.codex/worktrees/scalar-primitive-kinetic-20261016/New Axioms Lets Go")
MUTANTS = Path("/Users/jonBridger/.codex/campaigns/observations-backward-derivation-24h-20261015/primitive-canonical-mutations-v1")
OUT = Path(__file__).resolve().parent


def function_tree(path):
    tree = ast.parse(path.read_text())
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run_checks')


def binding(path):
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


baseline = ROOT / 'scripts/scalar_primitive_kinetic_core.py'
rows = []
for label, path in [('baseline', baseline), ('mutant', MUTANTS/'D_time_jacobian/candidate.py')]:
    fn = next(n for n in function_tree(path).body if isinstance(n, ast.FunctionDef) and n.name == 'Ddag')
    eta, r = s.symbols('eta r', real=True, nonzero=True)
    a = 256/eta**8
    ns = {'s':s, 'eta':eta, 'r':r, 'a':a, 'canon':lambda x:s.cancel(s.expand(x))}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(path), 'exec'), ns)
    f = 1+eta+eta*r+r*r
    g = eta*eta+r+eta*r*r
    mu = a*r*r
    residual = s.cancel(s.expand(mu*(f*(s.diff(g,r)-s.diff(g,eta))-ns['Ddag'](f)*g)
                                 -s.diff(mu*f*g,r)+s.diff(mu*f*g,eta)))
    rows.append({'case':'D_time_jacobian', 'version':label, 'source':binding(path),
                 'executed_scope':'Exact Ddag function AST only; independent Green identity',
                 'residual':str(residual), 'pass':bool((residual==0) if label=='baseline' else (residual!=0))})

for label, path in [('baseline', baseline), ('mutant', MUTANTS/'path_product_rule/candidate.py')]:
    prefix = []
    for node in function_tree(path).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id=='ff' for t in node.targets):
            break
        prefix.append(node)
    ns = {'s':s}
    exec(compile(ast.Module(body=prefix, type_ignores=[]), str(path), 'exec'), ns)
    wp, wj, wz, cp, cy, hp, hz = ns['weights'](s.Integer(0))
    r, eta, a = ns['r'], ns['eta'], ns['a']
    T, Ddag = ns['T'], ns['Ddag']
    # Independent separated composition of the two primitive-map adjoints.
    expected = Ddag(r*r*Ddag(cp))/2-Ddag(r*r*T(a*cy))
    residual = s.cancel(s.expand(hp-expected))
    at_point = s.cancel(residual.subs({eta:s.Rational(-7,2),r:s.Rational(3,2)}))
    rows.append({'case':'path_product_rule','version':label,'source':binding(path),
                 'executed_scope':'Unchanged source prefix through weight/integration definitions, then exact weights(0); no aggregate replay',
                 'operator_difference_at_regular_point':str(at_point),
                 'operator_difference_identically_zero':bool(residual==0),
                 'pass':bool((residual==0) if label=='baseline' else (at_point!=0))})

result = {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope':'Targeted actual-source operator checks; original120-second full mutant timeouts remain preserved',
          'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'passed':sum(row['pass'] for row in rows),'failed':sum(not row['pass'] for row in rows),
          'checks':rows,'full_mutated_aggregate_completed':False}
print(json.dumps(result,indent=2))
raise SystemExit(int(result['failed']>0))
