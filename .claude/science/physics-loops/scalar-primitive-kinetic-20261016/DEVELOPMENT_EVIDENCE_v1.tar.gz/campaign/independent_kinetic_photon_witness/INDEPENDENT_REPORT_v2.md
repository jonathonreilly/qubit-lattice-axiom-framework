# Independent noncanonical photon witness: frozen report v1

The supplied n=3/2 action and mode admit the stated Born/actual-event photon records, and a separately chosen weak test rejects the fixed canonical kinetic coefficient U=0 on those exact records. This is a conditional first-order construction with a known background, not empirical validation or action selection. Root retains main authorship. This proof, executable and output were frozen before opening any new root KINETIC_PRIMITIVE_PHOTON proof, code or results.

## What was checked independently

The proof preceded executable implementation. The 59 exact controls check direct derivatives of the supplied Q, all four background equations, six original scalar/metric/dust linear equations, the normalized Y20 harmonic, the physical/conformal clock conversion, direct ray integration, lensing inversion, actual-event redshift and fixed-eta Doppler convention, a known-background commutator reconstruction, and the independent compact weak witness. The program imports no author program. It uses the separately frozen original scalar current equation rather than a new root primitive implementation.

All 59 passed on the first bounded run, with zero failed predicates, exit 0 and empty stderr. Outer runtime was 0.9902552501298487 seconds of 120. No failure or timeout occurred in this task. The output retains two explicit algebraic countercontrols: holding source time fixed inside the Born ray is wrong, and differentiating the Doppler field at fixed u instead of fixed eta is wrong. These are not an isolated source-mutation campaign or empirical exclusions.

## Exact photon result

Write eta=u-r<0, and suppress the common normalized Y20 factor. The original mode gives P=eta^6 r²/64 and Z=-4r²/eta. The exact ray integrals are

    I0=(1/64) sum_j=0..6 (-1)^j binom(6,j) u^(6-j)r^(j+3)/(j+3),
    psi=(1/32) sum_j=0..6 (-1)^j binom(6,j)u^(6-j)r^(j+2)/[(j+2)(j+3)].

Direct integration and these independently derived polynomial forms agree. The path identity I0=(r²/2)partial_r|u psi and endpoint inversion P=partial_r|u I0 hold exactly. Actual-event redshift is

    z_obs=eta^6 r²/64-eta^7 r/32-2partial_u I0.

The fixed-eta Doppler derivative supplies the negative eta^7 term. The observer perturbation terms vanish for the regular quadrupole at the origin. Source/observer calibration, the source species, background subtraction and the Born contract remain supplied premises.

LZ=Yred with Yred=z_obs+2partial_u I0 does not alone fix a transport boundary. With the additionally supplied known background, the necessary momentum/Euler equation is Z'+CZ=-F1, F1=dP'+eP=-2P. The commutator yields

    N=Yred'+(C+h)Yred+(L+h)F1=-KZ,
    K=C'+hC=(1/4)t^-7=(r-u)^14/65536.

Since K is nonzero here, -N/K reconstructs Z=4r²/(r-u), then J=-Z'-P=-r²(r-u)^6/32. Both first-order equations and momentum were separately checked after reconstruction. No arbitrary transport integration function was selected. This is an exact compatible witness, not a sufficiency theorem for arbitrary photon data or recovery of an unknown background.

## Separate weak witness

On the shell r0=1/2, angular projection against normalized Y20 divided by r0² recovers the time coefficients t^-3 and -2t^-3. The true coefficient is U=(4/5)t^7. For U=0, B_density/R-3P=3P and its strong residual is -9t^-13/2.

My distinct compact test is lambda=(t-1)²(2-t)² on [1,2], zero outside. It is C1 and piecewise smooth, with the two endpoint traces needed for this integration by parts zero; it is not claimed to be a globally smooth bump. Three exact calculations agree: the once-weak moment, the metric-weight pairing, and the positive integral

    Mwrong=9 integral_[1,2] lambda t^-4 dt
          =75/2-54ln2
          =0.07005224976295329146946544...,
    Mtrue=0.

Restricting the positive integral to [5/4,7/4] gives Mwrong>=81/8192>0. The pre-code proof stated the weaker 81/32768 bound; the implementation exposes the stronger arithmetic and checks the weaker claim without rewriting the proof. A separate rational upper enclosure of ln2 proves the logarithmic result is positive. Nonzero sufficiently small common physical amplitude rescales this moment; no nonlinear unit-amplitude accuracy is inferred.

## Remaining physical limits

A time-and-radius neighborhood is required. The source window t in [1,2] maps to eta in [-2,-sqrt(2)] and reception u in [-3/2,1/2-sqrt(2)] at r0=1/2. The actual ray samples intermediate eta=u-s all the way to the observer, including times later than the latest source event. A single reception-time cone does not give the u derivatives in the conditional inversion. The proof declares a regular open neighborhood and full ray coverage inside eta<0.

The field is a local solid harmonic, not a nonzero global square-integrable Fourier zero mode. The exact background is self-gravitating; its linear mode still needs a small-amplitude finite patch and unspecified boundary completion. No actual scalar propagation speed is measured by the harmonic mode. Full-sky harmonic recovery, known clock/radius registration and background, the coupled species and photon model, and the absence of unregistered gain changes remain assumptions. No instrument covariance, observation arrays, noise bound, controlled discrete quadrature, initial-state distribution or global kinetic-action completion was supplied. The root's separate primitive-adjoint calculation is outside this pre-exposure check.

## Source bindings

PROOF_BEFORE_CODE_v1.md: 00ff44243a4ab67dd1baa73f320dbb5b8abb126a982dabf3196633067c13157b.
check_witness_v1.py: f9217c8688a7f86a804120c1192eb9b7cdc00cc94e3ccadc77fb65d8fd86f20c.
RESULTS_v1.json and RUN_v1.stdout: b859cc8304d1fe8dc152b4da2a324279f6c9ebed1c6e42541a7707dafa2e5e35.

The initial evidence is bound in OUTPUT_FREEZE_v1.json; the report wording correction and all original files are additionally bound in OUTPUT_FREEZE_v2.json. No Git, PR, other source, model, data or ownership change was made. Ready for bounded root-source comparison after this immutable independent freeze.
