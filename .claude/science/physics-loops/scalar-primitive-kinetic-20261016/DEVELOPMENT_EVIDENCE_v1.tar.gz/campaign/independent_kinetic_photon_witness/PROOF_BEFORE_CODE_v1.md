# Independent noncanonical original-action photon witness v1

This proof is frozen before new executable work and before any new root KINETIC_PRIMITIVE_PHOTON proof, program or output is read. The action and Born/actual-event observation formulas are the supplied neutral contract. The previously checked original-action equations and canonical kinetic-response note are known inputs, with identities in SOURCE_INTAKE_v1.json. This is conditional mathematics, not observed data or an action inferred from photons.

## Action and full local mode

Take M=1, Q=(5/6)(8/25)^(3/2) exp(2zeta/5)Y^(3/2)-(55/12)exp(-4zeta/5), Y=-grad(zeta)^2/2, and universally conformally coupled dust with gJ=exp(2zeta)gE. On t>0 in the supplied reference units,

    aE=t^(3/2), A=t^(5/2), zeta=(5/2)ln t, rho=1/(2t²).

The background derivatives are Q=-15/(4t²), Q_Y=2/5, D=Q_Y+2YQ_YY=4/5, Q_zeta=4/t², Q_Yzeta=4/25, Q_zetazeta=-14/(5t²). They satisfy Friedmann, Raychaudhuri, dust exchange and the sourced scalar equation. On finite patches with Y>0, Q_Y,D are positive and c_s²=1/2. This is not a global stability or UV claim.

Define normalized real Y20=sqrt(5/(16pi))(3cos²theta-1), so integral Y20² dOmega=1. The solid harmonic f=r²Y20=sqrt(5/(16pi))(2z²-x²-y²) has Delta f=0. The supplied full-action solution is

    P=t^-3 f, J=-2t^-3 f, Um=2t^-2 f, db=3t^-3 f.

Use the original equations with deltaY=v dot(J)-v²P, v=5/(2t), H=3/(2t), not only a density inverse. Momentum, Hamiltonian, pressure, bare-number continuity, Euler and the scalar variation all vanish. An independent expanded scalar form for this member is

    (4/5)ddot(J)+3H(4/5)dot(J)+(21/5)J/t²
      -5dot(P)/t-(19/2)P/t²+rho(db+J)=0.

The full weak-field configuration is a sufficiently small common real amplitude times this mode on a compact spacetime patch. Neither global square-integrability, spatial boundary completion nor an actual measured scalar speed follows from the harmonic fixture.

## Primitive photon records without choosing a path approximation

Matter a=AaE=t^4, d tau=A dt and eta=-2/sqrt(t), hence t=4/eta² on eta<0 and d tau=a d eta. Reception conformal time is u=eta+r. Let the expressions below denote the coefficient of Y20, with eta=u-r. Then

    P=eta^6 r²/64, J=-2P,
    Z=AUm=-4r²/eta, a=256/eta^8.

In the Born integral the intermediate event is eta=u-s, not the source time eta=u-r held fixed. Exact integration gives

    I0(u,r)= (1/64) sum_{j=0}^6 (-1)^j binom(6,j)
                    u^(6-j) r^(j+3)/(j+3),
    psi(u,r)= (1/32) sum_{j=0}^6 (-1)^j binom(6,j)
                    u^(6-j) r^(j+2)/[(j+2)(j+3)].

Each has the common Y20 factor. The path and endpoint inversion identities are

    (r²/2) partial_r|u psi=I0,
    (1/2) partial_r|u(r² partial_r|u psi)=partial_r|u I0=P.

The derivative in Z_r/a for actual-event redshift is at fixed eta. It is -eta^7 r/32. Therefore the registered perturbative redshift coefficient is

    z_obs(u,r)=eta^6 r²/64-eta^7 r/32-2 partial_u I0(u,r).

The observer's metric and velocity terms vanish for this regular solid quadrupole at r=0. The background redshift and any other source terms remain supplied/subtracted according to the stipulated observation contract. No fit identifies physical source population, instrument or force channel.

Thus the path-corrected field Yred=z_obs+2partial_u I0 equals -P-J+Z_r/a. The actual photon data map does not amount to simply setting redshift drift equal to acceleration. In (u,r), physical-time differentiation at fixed comoving position is T=a^-1 partial_u and the outgoing radial operator is L=a^-1(2partial_u+partial_r). Directly, Z'=P and LZ=P-eta^7 r/32=Yred.

## Conditional reconstruction rather than a chosen transport boundary

The primitive formulas determine P and Yred from their registered neighborhood. The equation LZ=Yred alone leaves a transport boundary function; it must not be silently selected. Here the known background supplies the independently established necessary momentum/Euler relation

    Z'+CZ=-F1, F1=dP'+eP,
    C=R/G=(1/2)t^-7/2, d=2t^7/2, e=4.

For this mode F1=-2P. Since [T,L]=h(T-L), h=4t^-7/2, applying these two equations yields

    N=Yred'+(C+h)Yred+(L+h)F1=-K Z,
    K=C'+hC=(1/4)t^-7.

K is nonzero. The data-derived algebraic value -N/K must still satisfy both original first-order relations; it is not sufficient for arbitrary records. For this exact witness it returns Z=-4r²/eta, and J=-Z'-P=-2P. This removes a freely chosen transport boundary within this known-background consistent sector; it does not show a background can be identified from arbitrary primitive observations. Temporal/radial derivative control is essential. The root's separate primitive adjoint may later remove data derivatives from a test, but that derivation has not been read or assumed here.

## Independently chosen weak rejection

For a harmonic response the original density identity is B_density=s Xi+R db, with

    Xi=qJ'-q²P-(q'+q²)J=(15/4)t^-10 f,
    s=2/5, R=(1/2)t^-7, Utrue=s/R=(4/5)t^7.

Consequently B_density/R=6P and db=3P. The true candidate has C_U=B_density/R-3P-Utrue Xi=0. The fixed canonical kinetic candidate U=0 instead has C_0=3P and strong residual C_0'=-9t^-13/2 f. This is a residual of the same registered background/records, not a comparison only to a label n.

Choose my own test lambda=(t-1)²(2-t)² on [1,2], extended by zero. It and its first physical-time derivative vanish at both endpoints. This extension is C1 with piecewise smooth second derivative; that is sufficient for the two integrations by parts used here. It is not falsely called a C-infinity bump.

At a fixed shell r0=1/2, project each field against normalized Y20 and divide by r0². The test moment of the wrong candidate, in the orientation integral lambda' C_0 d tau, is

    Mwrong=9 integral_1^2 lambda(t)t^-4 dt
          =75/2-54ln2 >0,
    Mtrue=0.

Positivity follows directly from the positive integrand on (1,2), independently of a numerical difference of nearby terms. An explicit lower bound is 81/32768: restrict to t in [5/4,7/4], where lambda>=(3/16)²=9/256 and t^-4>=1/16. This bound is conservative and strictly positive. The exact logarithmic expression comes from lambda/t^4=1-6/t+13/t²-12/t³+4/t^4. Multiplying by any nonzero sufficiently small physical mode amplitude leaves a nonzero moment. No empirical error envelope, quadrature bound or noise significance is asserted here.

The known weak weights for U=0 and Delta=0, after converting d tau to dt, are wP=18t lambda_tt-7lambda_t and wJ=2t lambda_tt+9lambda_t. Their pairing with the reconstructed metric coefficients t^-3 and -2t^-3 equals the same moment by direct integration; it uses no fitted potential or initial scalar density. I will verify this with a separate exact implementation.

## Coverage and limits

The shell's t in [1,2] corresponds to source eta in [-2,-sqrt(2)] and reception u in [-3/2,1/2-sqrt(2)]. The Born integral also samples later intermediate conformal times up to u, so the source's t in [1,2] is not the full spacetime coverage. For example the open rectangle -8/5<u<-4/5, 1/4<r<3/4 covers the shell and derivative neighborhoods; rays need the regular field for 0<=s<=r, with eta=u-s<0. All lie in a compact subdomain of eta<0 after slightly restricting the rectangle. Data at one reception time alone does not supply the required u derivatives. Registered nearby radii, times and angular components, a known background clock/distance, full-sky quadrupole convention and the supplied Born/source model are premises. An arbitrary mask, unknown time-varying gain, discrete/noisy derivative estimate or different source species is not treated.

No actual observations are read, and no new root primitive-photon source is opened. The planned code checks the original action and all mode equations, direct ray integrals versus independently derived polynomials, path/inverse identities, actual-event signs and fixed-eta radial convention, the conditional no-boundary reconstruction, angular normalization, and the positive weak witness. Failures will be preserved, not replaced by new tolerances.
