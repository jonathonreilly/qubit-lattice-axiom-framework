"""Post-exposure correspondence only; does not import or execute author runner."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial, comb
import sympy as s
import json, hashlib
B=Path(__file__).resolve().parent.parent
D=Path(__file__).resolve().parent
checks=[]
def ck(name, truth, evidence):
    checks.append(dict(name=name,pass_=bool(truth),evidence=str(evidence)))
def zero(name,ex):
    val=s.cancel(s.expand(ex)); ck(name,val==0,val)
old=json.loads((B/'KINETIC_PRIMITIVE_PHOTON_CONTROLS_v2.json').read_text())
own=json.loads((D/'RESULTS_v1.json').read_text())
e,r,u=s.symbols('eta r u',real=True,nonzero=True)
loc={'eta':e,'r':r,'u':u}
for rootkey,ownkey in [('I0','I0'),('psi','psi'),('z','zobs')]:
    x=s.sympify(old['records'][rootkey],locals=loc)
    y=s.sympify(own['photon_coefficients'][ownkey],locals=loc).subs(u,e+r)
    zero('frozen_photon_polynomial_'+rootkey,x-y)
I0=s.sympify(own['photon_coefficients']['I0'],locals=loc)
zero('frozen_photon_I1',s.sympify(old['records']['I1'],locals=loc)-s.diff(I0,u).subs(u,e+r))
Z=s.sympify(own['photon_coefficients']['Z_reconstructed'],locals=loc)
a=256/(u-r)**8
Y=(2*s.diff(Z,u)+s.diff(Z,r))/a
zero('frozen_photon_Y',s.sympify(old['records']['Y'],locals=loc)-Y.subs(u,e+r))
# Separate exact beta-moment representation; no author Laurent integrator.
def beta_int(i,j):return F(factorial(i)*factorial(j),factorial(i+j+1))
radial=sum(F(comb(4,k))*beta_int(8+k,8) for k in range(5))
def wrong_moment(offset):
    temporal=sum(F(comb(5,k)*(-1)**k*offset**(5-k))*beta_int(8+k,8) for k in range(6))
    return F(9,32)*temporal*radial
oldmoment=wrong_moment(2)
ck('old_exact_wrong_moment',str(oldmoment)==old['moments']['wrong_canonical']['primitive_moment'],oldmoment)
ck('old_true_moment',all(v=='0' for v in old['moments']['true'].values()),old['moments']['true'])
# The error radius is conditional algebra; old physical support remains invalid.
psi_norm=F(old['moments']['wrong_canonical']['primitive_L1_bound_psi'])
z_norm=F(old['moments']['wrong_canonical']['primitive_L1_bound_z'])
rad=F(old['moments']['wrong_canonical']['primitive_uniform_radius'])
ck('old_radius_arithmetic',rad==oldmoment/(2*(psi_norm+z_norm)),rad)
eta0=F(-5,4);r0=F(7,4);u0=eta0+r0
ck('old_counterexample_inside_source_rectangle',-2<eta0<-1 and 1<r0<2,(eta0,r0,u0))
ck('old_counterexample_crosses_eta_zero',0<u0<r0,(u0,0,r0))
ck('new_reception_interval_negative',F(-4)+1==-3 and F(-3)+2==-1,[-3,-1])
ck('new_full_ray_interval_negative',F(-4)<F(-1)<0,[-4,-1])
ck('new_source_t_interval',F(4,16)==F(1,4) and F(4,9)==F(4,9),['1/4','4/9'])
newmoment=wrong_moment(4)
ck('new_positive_form_exact_oracle',newmoment>0,newmoment)
result=dict(scope='Post-exposure narrow algebra/byte correspondence; not an author replay or empirical check',passed=sum(c['pass_'] for c in checks),failed=sum(not c['pass_'] for c in checks),checks=checks,old_wrong_moment=str(oldmoment),corrected_domain_wrong_moment_beta_oracle=str(newmoment),old_physical_witness_valid=False,corrected_domain_source_read=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
print(json.dumps(result,indent=2))
raise SystemExit(int(result['failed']>0))
