"""Narrow v2-v3/source/product binding; no author runner imports or execution."""
from pathlib import Path
from fractions import Fraction as F
import sympy as s
import hashlib,json
B=Path(__file__).resolve().parent.parent
D=Path(__file__).resolve().parent
checks=[]
def ck(name,value,evidence):checks.append(dict(name=name,pass_=bool(value),evidence=evidence))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
x2=(B/'check_kinetic_primitive_photon_v2.py').read_text()
x3=(B/'check_kinetic_primitive_photon_v3.py').read_text()
expected=x2.replace('lam=(eta+2)**8*(-1-eta)**8','lam=(eta+4)**8*(-3-eta)**8').replace('(eta,[-2,-1])','(eta,[-4,-3])').replace('intpow(i,-2,-1)','intpow(i,-4,-3)').replace('abs(c)*intpow(i,1,2)','abs(c)*intpow(i,3,4)').replace('dx=eta+2;','dx=eta+4;')
block='# Full-ray coverage of the fixed negative-eta chart, not just source events.\ntruth("old_rectangle_crosses_singular_chart",s.Rational(-5,4)+s.Rational(7,4)>0)\ntruth("new_reception_interval_strictly_negative",s.Integer(-3)+s.Integer(2)<0)\ntruth("new_complete_ray_interval_negative",s.Integer(-4)<s.Integer(-1)<0)\ntruth("new_source_t_interval",s.Rational(4,16)==s.Rational(1,4) and s.Rational(4,9)<4)\n'
expected=expected.replace('result={"scope":',block+'result={"scope":')
ck('source_only_declared_domain_and_coverage_changes',expected==x3,sha(B/'check_kinetic_primitive_photon_v3.py'))
v2=json.loads((B/'KINETIC_PRIMITIVE_PHOTON_CONTROLS_v2.json').read_text())
v3=json.loads((B/'KINETIC_PRIMITIVE_PHOTON_CONTROLS_v3.json').read_text())
oracle=json.loads((D/'AUTHOR_CORRESPONDENCE_CONTROLS_v1.json').read_text())
ck('photon_record_coefficients_unchanged',v2['records']==v3['records'],list(v3['records']))
ck('actual_saved_checks_77_and_zero_failures',len(v3['checks'])==77 and all(c['pass'] for c in v3['checks']) and v3['passed']==77 and v3['failed']==0,{'count':len(v3['checks']),'passed':v3['passed'],'failed':v3['failed']})
ck('true_candidate_pointwise_and_moments_zero',all(v=='0' for v in v3['moments']['true'].values()) and any(c['name']=='true_strong_residual' and c.get('residual')=='0' for c in v3['checks']),v3['moments']['true'])
wr=v3['moments']['wrong_canonical'];mom=F(oracle['corrected_domain_wrong_moment_beta_oracle'])
ck('pre_v3_beta_oracle_matches_all_three_moments',all(F(wr[k])==mom for k in ['strong_moment','field_moment','primitive_moment']),str(mom))
norm=F(wr['primitive_L1_bound_psi'])+F(wr['primitive_L1_bound_z']);rad=F(wr['primitive_uniform_radius'])
ck('new_coefficient_radius_arithmetic',rad==mom/(2*norm),str(rad))
ck('new_bounded_shift_arithmetic',abs(F(wr['bounded_error_shift']))<=rad*norm/4,str(wr['bounded_error_shift']))
rec=json.loads((B/'KINETIC_PRIMITIVE_PHOTON_EXECUTION_v3.json').read_text())
fr=json.loads((B/'KINETIC_PRIMITIVE_PHOTON_SOURCE_FREEZE_v3.json').read_text())
for title,row in [('receipt',rec),('freeze',fr)]:
 ck(title+'_source_hash',sha(B/row['source'])==row['source_sha256'],row['source_sha256'])
 for name,h in row['proofs'].items():ck(title+'_proof_'+name,sha(B/name)==h,h)
ck('receipt_output',sha(B/'KINETIC_PRIMITIVE_PHOTON_CONTROLS_v3.json')==rec['output_sha256'],rec['output_sha256'])
ck('author_reported_exit_zero_under_120s',rec['exit_code']==0 and rec['elapsed_seconds']<120,rec['elapsed_seconds'])
ck('author_stderr_empty',(B/'KINETIC_PRIMITIVE_PHOTON_STDERR_v3.txt').read_bytes()==b'',sha(B/'KINETIC_PRIMITIVE_PHOTON_STDERR_v3.txt'))
x=s.symbols('x',real=True)
angular=2*s.pi*s.sqrt(s.Rational(5,16)/s.pi)*2*(s.integrate(1-3*x*x,(x,0,1/s.sqrt(3)))+s.integrate(3*x*x-1,(x,1/s.sqrt(3),1)))
ck('angular_projection_factor',s.simplify(angular-4*s.sqrt(15*s.pi)/9)==0,str(s.simplify(angular)))
result=dict(scope='Post-exposure affected-source/readout binding only; no author aggregate rerun',passed=sum(c['pass_'] for c in checks),failed=sum(not c['pass_'] for c in checks),checks=checks,source_sha256=sha(Path(__file__)))
print(json.dumps(result,indent=2));raise SystemExit(int(result['failed']>0))
