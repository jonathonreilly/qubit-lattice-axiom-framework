"""Independent original-Q photon witness, frozen before author primitive source."""
AUDIT_TIMEOUT_SEC=120
import sympy as s
import time,json,hashlib
from pathlib import Path
beg=time.monotonic();checks=[]
R=s.Rational
norm=lambda x:s.factor(s.cancel(s.expand(x)))
def zero(name,a,b=0):
 residual=s.factor(s.simplify(a-b));checks.append({'name':name,'pass':bool(residual==0),'residual':str(residual)})
def truth(name,test,evidence):checks.append({'name':name,'pass':bool(test),'evidence':str(evidence)})
t=s.symbols('t',positive=True);zeta,Y=s.symbols('zeta Y',real=True,positive=True)
Q=R(5,6)*R(8,25)**R(3,2)*s.exp(R(2,5)*zeta)*Y**R(3,2)-R(55,12)*s.exp(-R(4,5)*zeta)
v=R(5,2)/t;H=R(3,2)/t;aE=t**R(3,2);A=t**R(5,2);a=t**4;rho=R(1,2)/t**2
at=lambda f:s.simplify(f.subs({zeta:R(5,2)*s.log(t),Y:v*v/2}))
Qb=at(Q);Qy=at(s.diff(Q,Y));Qyy=at(s.diff(Q,Y,2));Qz=at(s.diff(Q,zeta));Qyz=at(s.diff(Q,Y,zeta));Qzz=at(s.diff(Q,zeta,2));D=s.factor(Qy+v*v*Qyy)
for name,a1,a2 in [('Q',Qb,-R(15,4)/t**2),('QY',Qy,R(2,5)),('D',D,R(4,5)),('Qz',Qz,4/t**2),('Qyz',Qyz,R(4,25)),('Qzz',Qzz,-R(14,5)/t**2)]:zero('action_derivative_'+name,a1,a2)
zero('background_Friedmann',3*H*H-rho-v*v*Qy+Qb)
zero('background_Raychaudhuri',-2*s.diff(H,t)-rho-v*v*Qy)
zero('background_exchange',s.diff(rho,t)+3*H*rho-v*rho)
zero('background_scalar',D*s.diff(v,t)+3*H*Qy*v+v*v*Qyz-Qz+rho)
zero('principal_speed',Qy/D,R(1,2))
P=t**-3;J=-2*P;Um=2*t**-2;db=3*P;dy=v*s.diff(J,t)-v*v*P
zero('linear_momentum',2*(s.diff(P,t)+H*P)-Qy*v*J+rho*Um)
zero('linear_Hamiltonian',6*H*(s.diff(P,t)+H*P)+D*dy+(v*v*Qyz-Qz)*J+rho*(db+J))
zero('linear_pressure',2*(s.diff(P,t,2)+4*H*s.diff(P,t)+(2*s.diff(H,t)+3*H*H)*P)-Qy*dy-Qz*J)
zero('linear_Euler',s.diff(Um,t)+v*Um+P+J)
zero('linear_number',s.diff(db,t)-3*s.diff(P,t))
# Independent current equation from old frozen proof, not root's new source.
dq=Qyy*dy+Qyz*J;current=Qy*s.diff(J,t)+v*dq;jbg=Qy*v
zero('linear_scalar_current',s.diff(current,t)+3*H*current-4*jbg*s.diff(P,t)-2*(s.diff(jbg,t)+3*H*jbg)*P-Qyz*dy-Qzz*J+rho*(db+J))
xx,yy,zz,mu=s.symbols('xx yy zz mu',real=True)
harmonic=s.sqrt(R(5,16)/s.pi)*(2*zz**2-xx**2-yy**2)
zero('solid_quadrupole_laplacian',sum(s.diff(harmonic,x,2) for x in [xx,yy,zz]))
zero('Y20_norm',2*s.pi*s.integrate(R(5,16)/s.pi*(3*mu**2-1)**2,(mu,-1,1)),1)
eta=-2/s.sqrt(t);zero('eta_conformal_clock',s.diff(eta,t),1/aE)
zero('matter_conformal_clock',A/(s.diff(eta,t)),a)
r=s.symbols('r',positive=True);u=s.symbols('u',real=True);ss=s.symbols('ss',real=True)
e=u-r;Pe=e**6*r*r/64;Ze=-4*r*r/e;ae=256/e**8
ray=(u-ss)**6*ss**2/64
I0_direct=s.integrate(s.expand(ray),(ss,0,r))
psi_direct=s.integrate(s.expand(2*(r-ss)*ray/(r*ss)),(ss,0,r))
I0_poly=sum((-1)**j*s.binomial(6,j)*u**(6-j)*r**(j+3)/R(64*(j+3)) for j in range(7))
psi_poly=sum((-1)**j*s.binomial(6,j)*u**(6-j)*r**(j+2)/R(32*(j+2)*(j+3)) for j in range(7))
zero('ray_integral_I0',I0_direct,I0_poly);zero('Born_integral_psi',psi_direct,psi_poly)
I0_from_psi=norm(r*r*s.diff(psi_direct,r)/2)
P_from_psi=norm(s.diff(r*r*s.diff(psi_direct,r),r)/2)
zero('path_identity',I0_from_psi,I0_direct)
zero('Born_endpoint_inverse',P_from_psi,Pe)
zero('integral_endpoint',s.diff(I0_direct,r),Pe)
T=lambda f:norm(s.diff(f,u)/ae)
L=lambda f:norm((2*s.diff(f,u)+s.diff(f,r))/ae)
Dr_eta=lambda f:norm(s.diff(f,r)+s.diff(f,u))
Doppler=norm(Dr_eta(Ze)/ae)
zero('fixed_eta_radial_Doppler',Doppler,-e**7*r/32)
zobs=norm(Pe+Doppler-2*s.diff(I0_direct,u))
Yred=norm(zobs+2*s.diff(I0_from_psi,u))
zero('actual_redshift_path_correction',Yred,Pe-e**7*r/32)
zero('original_physical_Euler',T(Ze),Pe)
zero('photon_transport',L(Ze),Yred)
# Known-background algebra eliminates the transport boundary only for compatible records.
q=-5*e**7/256;ell=-3*e**7/256;h=-e**7/32;Rb=e**14/32768;G=-e**7/128;C=norm(Rb/G);d=norm(2/G);ee=4
zero('coordinate_commutator_probe',T(L(u**2*r**3))-L(T(u**2*r**3)),h*(T(u**2*r**3)-L(u**2*r**3)))
F1=norm(d*T(P_from_psi)+ee*P_from_psi)
zero('mode_force_combination',F1,-2*Pe)
K=norm(T(C)+h*C);zero('K_nonzero_closed',K,e**14/65536)
N=norm(T(Yred)+(C+h)*Yred+L(F1)+h*F1)
Zrec=norm(-N/K);Jrec=norm(-T(Zrec)-P_from_psi)
zero('photon_Z_reconstruction',Zrec,Ze);zero('photon_J_reconstruction',Jrec,-2*Pe)
zero('reconstructed_momentum',T(P_from_psi)+ell*P_from_psi-(G*Jrec-Rb*Zrec)/2)
zero('reconstructed_reduced_equation',T(Zrec)+C*Zrec+F1)
zero('reconstructed_transport',L(Zrec),Yred)
truth('fixed_eta_not_fixed_u',Doppler-norm(s.diff(Ze,r)/ae)!=0,norm(Doppler-s.diff(Ze,r)/ae))
truth('wrong_source_time_Born_not_equal',norm((psi_direct-e**6*r*r/192).subs({u:-R(3,2),r:R(1,2)}))!=0,norm((psi_direct-e**6*r*r/192).subs({u:-R(3,2),r:R(1,2)})))
# Shell angular projection: norm(Y20)=1, divide the recovered coefficient by r0².
r0=R(1,2);shell_u=eta+r0
zero('shell_P_recovered',s.simplify(P_from_psi.subs({u:shell_u,r:r0})/r0**2),P)
zero('shell_J_recovered',s.simplify(Jrec.subs({u:shell_u,r:r0})/r0**2),J)
zero('shell_Z_recovered',s.simplify(Zrec.subs({u:shell_u,r:r0})/r0**2),A*Um)
prime=lambda f:s.diff(f,t)/A
qt=v/A;ellt=H/A;Rt=rho/A**2;Ft=Qy;Et=Qz/A**2
Xi=s.factor(qt*prime(J)-qt*qt*P-(prime(qt)+qt*qt)*J)
Bden=s.factor(-6*ellt*(prime(P)+ellt*P)-Ft*(qt*prime(J)-qt*qt*P)-(qt*prime(Ft)-Et+Rt)*J)
Utrue=R(4,5)*t**7
zero('Xi_formula',Xi,R(15,4)*t**-10)
zero('density_rewrite',Bden-Rt*Utrue*Xi-Rt*db)
zero('wrong_candidate_density_combination',Bden/Rt-3*P,3*P)
zero('true_candidate_density_combination',Bden/Rt-3*P-Utrue*Xi)
zero('wrong_candidate_strong_residual',prime(Bden/Rt-3*P),-9*t**(-R(13,2)))
lam=(t-1)**2*(2-t)**2
for edge in [1,2]:
 zero('lambda_value_'+str(edge),lam.subs(t,edge));zero('lambda_prime_'+str(edge),prime(lam).subs(t,edge))
Mweak=s.integrate(s.expand(A*prime(lam)*(Bden/Rt-3*P)),(t,1,2))
Mpositive=9*s.integrate(s.expand(lam/t**4),(t,1,2))
wp=18*t*s.diff(lam,t,2)-7*s.diff(lam,t);wj=2*t*s.diff(lam,t,2)+9*s.diff(lam,t)
Mweights=s.integrate(s.expand(wp*P+wj*J),(t,1,2))
zero('weak_positive_form',Mweak,Mpositive)
zero('weak_metric_weights',Mweights,Mpositive)
zero('weak_closed_form',Mpositive,R(75,2)-54*s.log(2))
zero('true_weak_moment',s.integrate(s.expand(A*prime(lam)*(Bden/Rt-3*P-Utrue*Xi)),(t,1,2)))
lower=9*R(1,2)*R(9,256)*R(1,16)
zero('middle_interval_lower_computation',lower,R(81,8192))
truth('proof_conservative_lower_bound',lower>=R(81,32768),lower)
# Exact rational log enclosure controls the stated log expression independently.
Llog=2*sum(R(1,3)**(2*j+1)/s.Integer(2*j+1) for j in range(10))
Ulog=Llog+2*R(1,3)**21/(21*(1-R(1,9)))
truth('exact_rational_positive_moment',R(75,2)-54*Ulog>R(81,32768),s.factor(R(75,2)-54*Ulog))
result={'scope':'Pre-author-source independent conditional original-action photon witness; no observations','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'checks':checks,'photon_coefficients':{'I0':str(s.factor(I0_direct)),'psi':str(s.factor(psi_direct)),'zobs':str(s.factor(zobs)),'P_from_psi':str(P_from_psi),'Z_reconstructed':str(Zrec),'J_reconstructed':str(Jrec),'K':str(K)},'weak':{'lambda':str(lam),'wrong_moment':str(s.simplify(Mpositive)),'wrong_moment_numeric':str(Mpositive.evalf(25)),'positive_integral':'9 integral_[1,2] (t-1)^2 (2-t)^2 t^-4 dt','proved_middle_interval_lower_bound':str(lower),'proof_uses_weaker_lower_bound':'81/32768','true_moment':'0'},'domain':['t>0 reference units','compact local small-amplitude harmonic profile','registered full-sky Y20 and repeated u,r neighborhood','Born/source and known background premise','no empirical error or global completion claim'],'elapsed_seconds':time.monotonic()-beg}
print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
