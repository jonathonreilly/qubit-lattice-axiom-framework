# Independent exact polynomial absolute-integral enclosure

Pre-coefficient, pre-code proof. No author KINETIC_PRIMITIVE_BOUND notes, code or results have been read. Target: supplied rational-coefficient polynomials on [0,1]^2. This checks their absolute integral only, not their physical derivation or observational error interpretation.

Let B_i^m(x)=binom(m,i)x^i(1-x)^(m-i), and similarly in y. For p=sum a_kl x^k y^l of separate degrees m,n,

    p=sum_(i=0..m,j=0..n) b_ij B_i^m(x) B_j^n(y),
    b_ij=sum_(k<=i,l<=j) a_kl binom(i,k)/binom(m,k)
                                      binom(j,l)/binom(n,l).

This follows by substituting x^k=sum_(i=k..m)binom(i,k)/binom(m,k) B_i^m(x), a consequence of the binomial theorem. Degree zero uses binom(0,0)=1. All arithmetic is rational when input is rational; decimal strings must be interpreted as exact decimals, not converted through binary floats.

Each tensor basis is nonnegative, their sum is1, and each integral is1/[(m+1)(n+1)]. On an axis-aligned rectangle C of area A, map to the unit square and let b^C be the coefficients of the mapped polynomial. Therefore

    I_C = integral_C p = A sum b^C /[(m+1)(n+1)],
    L_C = |I_C| <= integral_C |p|
        <= H_C = A sum |b^C| /[(m+1)(n+1)].

If all coefficients have one weak sign, L_C=H_C and the integral is exact. The proof of H_C is the triangle inequality applied pointwise before integrating. This is sharper than area*max|b^C| and remains a rigorous bound even when some coefficients have mixed signs but p itself does not. Summing L_C,H_C over a disjoint finite rectangular partition gives global rigorous bounds. A lower bound of0 is allowed but not required.

Subdivision is exact tensor de Casteljau. For one coefficient vector b_0..b_m and split theta in[0,1], set d_i^0=b_i, d_i^(r)=(1-theta)d_i^(r-1)+theta d_(i+1)^(r-1). The left coefficients are d_0^0,d_0^1,...,d_0^m; the right coefficients are d_0^m,d_1^(m-1),...,d_m^0. Apply independently along rows and columns for rectangles. At theta=1/2 every value and area remains rational. Subdivision must include area factors1/2 per split (1/4 per two-axis split). The mapped polynomial equality can be checked independently by monomial substitution.

Refining a cell cannot decrease the sum of its lower bounds (triangle inequality for integrals), or increase the sum of its upper bounds: each new coefficient is a convex combination of old coefficients and the integrated subdivision basis preserves their integral weights. Exact arithmetic permits these monotonicity checks without tolerances. Consequently any stopped subdivision level is already certified; a depth/time limit affects tightness, not validity.

Convergence: polynomial continuity and the shrinking-cell affine maps imply that all mapped Bernstein coefficients approach the polynomial value at a cell point uniformly as the mesh tends to zero. More explicitly the nonconstant mapped Taylor coefficients are bounded by derivative suprema times powers of cell side length; the finite monomial-to-Bernstein linear map then bounds coefficient deviations by O(mesh). Thus upper-minus-lower tends to0. No claim of a uniform rapid rate near zero contours is needed. Exact rational partition bounds need no root-location approximation and work for repeated or crossing zeros, identically zero polynomials and degenerate univariate cases.

Implementation contract: retain exact rational endpoints and coefficients; reconstruct the polynomial from Bernstein form and compare coefficientwise with input; independently verify signed integral by monomial integration. Report full rational bounds plus optional decimal displays with explicit noncertifying status. Report degrees, subdivision rule/depth/cell count, wall time and source hashes. Stop at a predeclared bounded depth or target gap rather than tuning physical conclusions. Each job<=120seconds, bytecode disabled. A conservative earlier bound may remain useful as a cross-check; no float approximation is allowed to shrink the certified interval.

Predeclared independent controls: constant/zero, x-1/2 (norm1/4), (x-1/2)(y-1/2) (norm1/16), nonnegative (x-y)^2 (norm1/6), x+y-1 (norm1/3), and a repeated-root polynomial. Check interval containment of known exact norms, signed-integral conservation, subdivision identity, enclosure monotonicity, and exact closure when dyadic zeros align with cell boundaries. Mutation tests must actually alter a load-bearing formula: omit subdivision area scaling, reverse one right-child coefficient ordering, and replace sum|b| with |sum b| in the upper bound. Controls must detect these mutated implementations, retaining their failing residuals or explicit rejected assertions.

The root coefficient file is not yet identified and has not been consumed. Once supplied, freeze its bytes and schema separately; input precision and normalization are part of that supplied contract. Nothing in this norm computation independently proves the kernels were obtained from a valid primitive photon map.
