import json,hashlib,sys
from pathlib import Path
from fractions import Fraction as Q
import sympy as s
AUDIT_TIMEOUT_SEC=120
p=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/scalar-primitive-kinetic-20261016/New Axioms Lets Go')
files=['scripts/scalar_primitive_kinetic_bound.py','scripts/scalar_primitive_kinetic_core.py','scripts/scalar_primitive_kinetic.py','docs/SCALAR_PRIMITIVE_KINETIC_NOTE_2026-10-16.md','outputs/scalar_primitive_kinetic/result.json']
hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
assert hashes[files[0]]=='e06cad4f61560603371dc99b4cc9e50e4d54859149435be35c8b9526f33ac32e'
assert hashes[files[1]]=='df030726044df695faacc96eefb5d899c5fbadb0f9138e3ca050de7617604ddb'
assert hashes[files[4]]=='f142d98b33c29cffb821c92c7e5ba4ac949fa3b0e0da269576fe15b06c7f9bc2'
data=json.loads((root/files[4]).read_text());bound=data['units']['exact_bounds'];frozen=json.loads((p/'KINETIC_PRIMITIVE_WEIGHT_POLYNOMIALS_v2.json').read_text());ind=json.loads((p/'RESULT_v2.json').read_text());checks=[]
def ck(n,c):checks.append({'name':n,'pass':bool(c)});assert c,n
for f in files[:4]:ck('source binding '+f,data['source_sha256'][f]==hashes[f])
for name in ['psi','z']:
 ck('canonical exact coefficient list '+name,bound['computed_weight_polynomials'][name]==frozen[name])
 for i in range(4):
  a=bound['norm_enclosures'][name]['levels'][i];b=ind['results'][name]['levels'][i]
  ck(name+' independent rational endpoints '+str(i),Q(a['lower'])==Q(b['lower']) and Q(a['upper'])==Q(b['upper']))
ck('exact moment',Q(bound['moment'])==Q(827093,50599790841600))
ck('radius',Q(bound['uniform_radius'])==Q(bound['moment'])/(2*Q(bound['combined_upper'])))
ck('note rational upper',Q(bound['combined_upper'])==Q(162677295731424740783879666051795129106258197,204455351051289521995092083836429520181657600))
# Targeted new bound interface replay using independently frozen polynomials;
# do not call the aggregate/core or write canonical outputs.
sys.path.insert(0,str(root/'scripts'));import scalar_primitive_kinetic_bound as cb
eta,r=s.symbols('eta r',real=True);context={'eta':eta,'r':r,'moment':bound['moment']}
for name in ['psi','z']:
 context['weighted_'+name]=sum(s.Rational(c['coefficient'])*(eta+4)**c['powers'][0]*(r-1)**c['powers'][1] for c in frozen[name]['coefficients'])
replay=cb.run_checks(context);ck('targeted canonical bound complete equality',replay==bound)
print(json.dumps({'passed':len(checks),'failed':0,'checks':checks,'canonical_bound_controls':{'passed':replay['passed'],'failed':replay['failed']},'source_sha256':hashes,'scope':'Targeted bound interface and source/output correspondence; no aggregate/core reexecution or full canonical mathematical review'},indent=2))
