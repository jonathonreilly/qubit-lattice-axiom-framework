import json,hashlib
from pathlib import Path
from fractions import Fraction as Q
import sympy as s
AUDIT_TIMEOUT_SEC=120
p=Path(__file__).resolve().parent;pack=p.parent
ours=json.loads((p/'RESULT_v1.json').read_text());author=json.loads((pack/'KINETIC_PRIMITIVE_BOUND_CONTROLS_v3.json').read_text());replay=json.loads((p/'author_stdout_v1.json').read_text())
checks=[]
def ck(n,c):checks.append({'name':n,'pass':bool(c)});assert c,n
for name in ['psi','z']:
 for level in range(4):
  a=author['norm_enclosures'][name]['levels'][level];b=ours['results'][name]['levels'][level]
  ck(name+' exact independent interval depth'+str(level),Q(a['lower'])==Q(b['lower']) and Q(a['upper'])==Q(b['upper']))
 ck(name+' depth5 nested',Q(ours['results'][name]['lower'])>=Q(a['lower']) and Q(ours['results'][name]['upper'])<=Q(a['upper']))
a=dict(author);b=dict(replay);a.pop('elapsed_seconds');b.pop('elapsed_seconds');ck('full author replay equality',a==b)
raw=(p/'author_replay_v1/KINETIC_PRIMITIVE_WEIGHT_POLYNOMIALS_v1.json').read_bytes();ck('regenerated supplied bytes',hashlib.sha256(raw).hexdigest()=='018cff840426fb9b133ace96dad8b293930aeb8e9cedca79d014d7cf42a1fdc6')
eta,r=s.symbols('eta r');lam=(eta+2)**8*(-1-eta)**8*(r-1)**8*(2-r)**8
moment=s.integrate(s.integrate(-s.Rational(9,32)*lam*eta**5*r**4,(eta,-2,-1)),(r,1,2))
ck('old formal moment integral',str(moment)==author['moment'])
M=Q(author['moment']);K=Q(author['combined_upper']);radius=Q(author['uniform_radius'])
ck('radius factor two',radius==M/(2*K));ck('radius quarter worst-case separation',M-K*radius/4>K*radius/4)
v2=json.loads((pack/'KINETIC_PRIMITIVE_BOUND_CONTROLS_v2.json').read_text());bad=[c['name'] for c in v2['checks'] if not c['pass']]
ck('preserved v2 domain failures',bad==['psi_polynomial','z_polynomial'])
ck('preserved v1 polynomial traceback','PolynomialError' in (pack/'KINETIC_PRIMITIVE_BOUND_STDERR_v1.txt').read_text())
for name,v in ours['results'].items():ck('positive certified '+name,Q(v['lower'])>0)
print(json.dumps({'passed':len(checks),'failed':0,'checks':checks,'old_combined_upper':str(K),'old_formal_radius':str(radius),'critical_domain_finding':'The old eta[-2,-1],r[1,2] support crosses the eta=0 background singularity on some source-to-observer rays. Polynomial norms remain correct; do not interpret old radius as a valid physical photon-record witness.','v2_preserved_failed_controls':bad},indent=2))
