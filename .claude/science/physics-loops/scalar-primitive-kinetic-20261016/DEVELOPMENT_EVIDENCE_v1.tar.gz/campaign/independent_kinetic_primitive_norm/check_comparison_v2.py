import json,hashlib
from pathlib import Path
from fractions import Fraction as Q
import sympy as s
AUDIT_TIMEOUT_SEC=120
p=Path(__file__).resolve().parent;pack=p.parent
ours=json.loads((p/'RESULT_v2.json').read_text());author=json.loads((pack/'KINETIC_PRIMITIVE_BOUND_CONTROLS_v4.json').read_text());checks=[]
def ck(n,c):checks.append({'name':n,'pass':bool(c)});assert c,n
for name in ['psi','z']:
 for i in range(4):
  a=author['norm_enclosures'][name]['levels'][i];b=ours['results'][name]['levels'][i]
  ck(name+' shared-depth exact equality '+str(i),Q(a['lower'])==Q(b['lower']) and Q(a['upper'])==Q(b['upper']))
 ck(name+' depth5 nested',Q(ours['results'][name]['lower'])>=Q(a['lower']) and Q(ours['results'][name]['upper'])<=Q(a['upper']))
e,r,mu=s.symbols('e r mu');lam=(e+4)**8*(-3-e)**8*(r-1)**8*(2-r)**8
M=s.integrate(s.integrate(-s.Rational(9,32)*lam*e**5*r**4,(e,-4,-3)),(r,1,2))
ck('independent changed formal moment',M==s.Rational(827093,50599790841600));ck('author moment',str(M)==author['moment'])
A=2*s.pi*s.sqrt(5/(16*s.pi))*(s.integrate(1-3*mu**2,(mu,-1/s.sqrt(3),1/s.sqrt(3)))+2*s.integrate(3*mu**2-1,(mu,1/s.sqrt(3),1)))
ck('angular factor',s.simplify(A-4*s.sqrt(15*s.pi)/9)==0)
# Parametrize every source and every point on its complete ray by unit variables.
x,y,v=s.symbols('x y v',nonnegative=True);eta=-4+x;rr=1+y;uu=eta+rr;ray=uu-v*rr
# Multi-affine extrema on cube occur at vertices; verify all eight.
verts=[s.expand(ray).subs({x:i,y:j,v:k}) for i in [0,1] for j in [0,1] for k in [0,1]]
ck('complete ray chart extrema',min(verts)==-4 and max(verts)==-1)
K=Q(ours['combined']['upper']);moment=Q(str(M));radius=moment/(2*K)
ck('own radius quarter robust rejection',moment-K*radius/4>K*radius/4)
ck('author factor two',Q(author['uniform_radius'])==moment/(2*Q(author['combined_upper'])))
base=(p/'check_v1.py').read_text();changed=(p/'check_v2.py').read_text();ck('algorithm unchanged',base.replace('KINETIC_PRIMITIVE_WEIGHT_POLYNOMIALS_v1.json','KINETIC_PRIMITIVE_WEIGHT_POLYNOMIALS_v2.json').replace('018cff840426fb9b133ace96dad8b293930aeb8e9cedca79d014d7cf42a1fdc6','e5b0b2607b8fa53761acdb6740d034ee9113dc7759f09a128d55981127283a2c')==changed)
print(json.dumps({'passed':len(checks),'failed':0,'checks':checks,'moment':str(M),'combined_upper':str(K),'coefficient_radius':str(radius),'coefficient_radius_display':float(radius),'full_sky_factor':str(s.simplify(A)),'full_sky_radius_display':float(radius)/float(A),'scope':'Norms certify supplied kernels; moment and ray checks do not replace full original-action review.'},indent=2))
