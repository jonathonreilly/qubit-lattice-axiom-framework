"""Exact rational tensor Bernstein norm enclosure; no root code imported."""
AUDIT_TIMEOUT_SEC=120
MAX_DEPTH=5
import json,hashlib,time,math
from fractions import Fraction as Q
from pathlib import Path
from math import comb
start=time.monotonic();checks=[];mutations=[]
def ck(name,ok):
 checks.append({'name':name,'pass':bool(ok)})
 assert ok,name
def bern(a,m,n):
 # separable monomial -> Bernstein conversion
 tmp=[[sum((a.get((k,l),Q(0))*Q(comb(i,k),comb(m,k)) for k in range(i+1)),Q(0)) for l in range(n+1)] for i in range(m+1)]
 b=[[sum((tmp[i][l]*Q(comb(j,l),comb(n,l)) for l in range(j+1)),Q(0)) for j in range(n+1)] for i in range(m+1)]
 den=math.lcm(*(v.denominator for row in b for v in row))
 return [[int(v*den) for v in row] for row in b],den
def inverse(b,den,m,n):
 tmp=[[sum(Q(b[i][j],den)*comb(m,i)*comb(m-i,k-i)*(-1)**(k-i) for i in range(k+1)) for j in range(n+1)] for k in range(m+1)]
 return {(k,l):sum(tmp[k][j]*comb(n,j)*comb(n-j,l-j)*(-1)**(l-j) for j in range(l+1)) for k in range(m+1) for l in range(n+1)}
def half(v,reverse_right=False):
 d=len(v)-1; rows=[v]
 for j in range(d): rows.append([rows[-1][i]+rows[-1][i+1] for i in range(len(rows[-1])-1)])
 left=[rows[j][0]*2**(d-j) for j in range(d+1)]
 right=[rows[d-i][i]*2**i for i in range(d+1)]
 if reverse_right:right=list(reversed(right))
 return left,right
# Output all children with common denominator old_den*2**(m+n).
def split(b):
 m=len(b)-1;n=len(b[0])-1
 lx=[[0]*(n+1) for _ in range(m+1)];rx=[[0]*(n+1) for _ in range(m+1)]
 for j in range(n+1):
  l,r=half([b[i][j] for i in range(m+1)])
  for i in range(m+1):lx[i][j]=l[i];rx[i][j]=r[i]
 ans=[]
 for bx in [lx,rx]:
  lo=[];hi=[]
  for row in bx:
   l,r=half(row);lo.append(l);hi.append(r)
  ans.extend([lo,hi])
 return ans
def cell_bounds(b,den,area,mutant=False):
 vals=[v for row in b for v in row];scale=area/Q(den*len(vals))
 return abs(sum(vals))*scale,(abs(sum(vals)) if mutant else sum(abs(v) for v in vals))*scale

def enclosure(a,m,n,depth):
 b,den=bern(a,m,n); back=inverse(b,den,m,n)
 ck('power reconstruction',all(back[k]==a.get(k,0) for k in back))
 signed=sum((v/Q((i+1)*(j+1)) for (i,j),v in a.items()),Q(0))
 ck('independent signed integral',Q(sum(map(sum,b)),den*(m+1)*(n+1))==signed)
 pending=[(b,den,Q(1))];doneL=Q(0);doneH=Q(0);rows=[];prevL=Q(0);prevH=None;terminal=0
 for level in range(depth+1):
  low=doneL;high=doneH;next_cells=[];signed_check=Q(0)
  for b,d,ar in pending:
   l,h=cell_bounds(b,d,ar);low+=l;high+=h
   if level<depth:
    if l==h:doneL+=l;doneH+=h;terminal+=1
    else:
     children=split(b);nd=d*2**(m+n)
     # exact local signed integral preservation
     before=Q(sum(map(sum,b)),d*(m+1)*(n+1))*ar
     after=sum((Q(sum(map(sum,c)),nd*(m+1)*(n+1))*ar/4 for c in children),Q(0))
     assert before==after
     next_cells.extend((c,nd,ar/4) for c in children)
  ck('monotone enclosure level'+str(level),low>=prevL and (prevH is None or high<=prevH) and low<=high)
  rows.append({'depth':level,'lower':str(low),'upper':str(high),'lower_display':float(low),'upper_display':float(high),'gap_display':float(high-low),'active_cells':len(pending),'resolved_cells':terminal})
  prevL,prevH=low,high;pending=next_cells
 return low,high,rows

known=[('zero',{},0,0,Q(0)),('constant',{(0,0):Q(3)},0,0,Q(3)),('linear',{(1,0):Q(1),(0,0):Q(-1,2)},1,0,Q(1,4)),('product',{(1,1):Q(1),(1,0):Q(-1,2),(0,1):Q(-1,2),(0,0):Q(1,4)},1,1,Q(1,16)),('square',{(2,0):Q(1),(1,1):Q(-2),(0,2):Q(1)},2,2,Q(1,6)),('diagonal',{(1,0):Q(1),(0,1):Q(1),(0,0):Q(-1)},1,1,Q(1,3)),('repeated root',{(2,0):Q(1),(1,0):Q(-1),(0,0):Q(1,4)},2,0,Q(1,12))]
known_results=[]
for name,a,m,n,exact in known:
 lo,hi,rows=enclosure(a,m,n,3);ck('known norm '+name,lo<=exact<=hi)
 if name in ['zero','constant','linear','product','repeated root']:ck('dyadic exact closure '+name,lo==hi==exact)
 known_results.append({'name':name,'exact':str(exact),'lower':str(lo),'upper':str(hi)})
# Independent pointwise de Casteljau check for nonsymmetric coefficients.
v=[2,-3,7];t=Q(2,7);poly=lambda vec,z:sum(Q(vv)*comb(len(vec)-1,i)*z**i*(1-z)**(len(vec)-1-i) for i,vv in enumerate(vec))
left,right=half(v)
ck('left child polynomial substitution',poly(left,t)/4==poly(v,t/2))
ck('right child polynomial substitution',poly(right,t)/4==poly(v,(1+t)/2))
# Actual mutated implementations are executed; detection via independently known facts.
b,d=bern({(0,0):Q(1)},0,0);bad=sum(cell_bounds(c,d,Q(1))[1] for c in split(b))
mutations.append({'mutation':'omit child area factor1/4','computed':str(bad),'expected':'1','detected':bad!=1})
_,badright=half(v,True);bad=poly(badright,t)/4;expected=poly(v,(1+t)/2)
mutations.append({'mutation':'reverse right-child coefficient order','computed':str(bad),'expected':str(expected),'detected':bad!=expected})
b,d=bern({(1,0):Q(1),(0,0):Q(-1,2)},1,0);bad=cell_bounds(b,d,Q(1),True)[1]
mutations.append({'mutation':'upper uses absolute signed coefficient sum','computed':str(bad),'known_norm':'1/4','detected':bad<Q(1,4)})
ck('all actual mutations detected',all(v['detected'] for v in mutations))
f=Path(__file__).parent/'KINETIC_PRIMITIVE_WEIGHT_POLYNOMIALS_v2.json';raw=f.read_bytes();sha=hashlib.sha256(raw).hexdigest()
ck('frozen supplied input',sha=='e5b0b2607b8fa53761acdb6740d034ee9113dc7759f09a128d55981127283a2c')
data=json.loads(raw);results={}
for name in ['psi','z']:
 item=data[name];m,n=item['degree'];a={}
 for term in item['coefficients']:
  ij=tuple(term['powers']);assert ij not in a;a[ij]=Q(term['coefficient'])
 ck(name+' supplied degree',max(i for i,j in a)==m and max(j for i,j in a)==n)
 lo,hi,rows=enclosure(a,m,n,MAX_DEPTH)
 results[name]={'degree':[m,n],'terms':len(a),'lower':str(lo),'upper':str(hi),'lower_display':float(lo),'upper_display':float(hi),'relative_gap_display':float((hi-lo)/hi),'levels':rows}
 print(json.dumps({'progress':name,'depth':MAX_DEPTH,'lower_display':float(lo),'upper_display':float(hi)}),flush=True)
combinedlo=sum(Q(results[k]['lower']) for k in results);combinedhi=sum(Q(results[k]['upper']) for k in results)
print(json.dumps({'passed':len(checks),'failed':0,'checks':checks,'known_controls':known_results,'mutations':mutations,'input_sha256':sha,'max_depth':MAX_DEPTH,'results':results,'combined':{'lower':str(combinedlo),'upper':str(combinedhi),'lower_display':float(combinedlo),'upper_display':float(combinedhi)},'elapsed_seconds':time.monotonic()-start,'decimal_displays':'informational only; rational endpoints certify bounds'},indent=2),flush=True)
