# Independent primitive kinetic weak test, frozen before code

Only the neutral contract is used. No root KINETIC_PRIMITIVE_PHOTON source, result or conclusion has been read. Root retains authorship. This is a necessary operator test, not a full-action construction.

## Domain and notation

Let T=partial_tau, Rr=partial_r at fixed tau, and let Delta be the flat spatial Laplacian

    Delta=Rr^2+(2/r)Rr+r^-2 Delta_Omega.

The pairing uses exactly dmu=d tau r^2 dr dOmega. Work on an open annulus r>0 with a(tau)>0, smooth prescribed time coefficients a,C,d,e,alpha,beta,gamma,delta,epsilon, and K=C'+hC!=0, h=a'/a. Tests are compactly supported inside this regular chart and smooth on the full sphere. At masked angular boundaries or r=0 further boundary conditions are required; they are not assumed silently. Coefficients and tests have enough derivatives for the operators below (at most seven test derivatives).

The supplied strong equations are

    Ckin=alpha TP+beta TJ+gamma Delta P+delta P+epsilon J,
    T Ckin+a^-2 Delta Z=0,
    J=-TZ-P,
    (T+C)Z=-(dT+e)P,
    LZ=Y, L=T+a^-1 Rr.

Y here is corrected photon redshift. All coefficients multiply the operator output immediately to their right.

## First-order elimination

Write F=(dT+e)P. Since [T,L]=h(T-L),

    N=(T+h+C)Y+(L+h)F=-KZ.

The sign follows directly by substituting Y=LZ and F=-(T+C)Z. Therefore on K!=0 define

    Zstar=-K^-1 N, Jstar=-TZstar-P.

Every original solution has Z=Zstar. For arbitrary P,Y this is a definition of reconstructed fields; it does not imply either original first-order equation. The residual tested below is

    Rkin=T{(alpha-beta)TP+gamma Delta P
              +(delta-epsilon)P-beta T^2 Zstar-epsilon T Zstar}
             +a^-2 Delta Zstar.                         (1)

A physical candidate must satisfy the first-order, primitive, background/action and all other required equations in addition to this test.

## Adjoint derivation in the declared measure

The divergences and formal adjoints are

    div_mu T=0,               Tdag=-T,
    div_mu L=2/(ar),          Ldag=-L-2/(ar),
    D=Rr-aT, div_mu D=2/r-a', Ddag=-D-2/r+a',
    Deltadag=Delta.

In particular the time divergence is not the +h term that appears with a different cone measure. The a' term in Ddag is required because the time component of D is -a. Delta is self-adjoint only after the radial r^2 measure and angular pairing are both included.

First eliminate J in the kinetic residual, then integrate by parts. For test lambda define

    W_P=T[(alpha-beta)Tlambda]
          -Delta(gamma Tlambda)-(delta-epsilon)Tlambda,
    W_Z=T^2(beta Tlambda)-T(epsilon Tlambda)
          +Delta(a^-2 lambda).                           (2)

These include derivatives of the time-dependent coefficient products. Direct integration gives

    <lambda,Rkin>=<W_P,P>+<W_Z,Zstar>.

Put w=-W_Z/K. The first-order elimination then gives

    H_Y=-Tw+(h+C)w,
    V=Ldag w+h w=-Lw+[h-2/(ar)]w,
    H_P=W_P-T(dV)+eV.                                    (3)

Thus

    <lambda,Rkin>=<H_P,P>+<H_Y,Y>.                        (4)

The order is essential: (dT+e)dag V=-T(dV)+eV, not -dTV+eV. Similarly multiplication by K^-1 occurs before the adjoint derivatives act.

## Primitive substitution

Let eta'=1/a, u=eta+r and D=partial_r|u=Rr-aT. The stipulated primitive map is

    P=(1/2)D(r^2 Dpsi),
    Y=z+aT(r^2 Dpsi).

Its adjoints are

    Pmapdag v=(1/2)Ddag(r^2 Ddag v),
    Pathdag v=-Ddag[r^2 T(av)].

The latter differentiates av, not merely v. Combining with (4),

    H_z=H_Y,
    H_psi=(1/2)Ddag(r^2 Ddag H_P)
                -Ddag[r^2 T(aH_z)],                     (5)

and the primitive-only identity is

    <lambda,Rkin>=integral(H_z z+H_psi psi)dmu.           (6)

No derivative of either datum appears on the right. Derivatives of the candidate coefficients, inverse K and test remain. Equation (6) is an identity for arbitrary sufficiently regular primitives and the reconstructed Zstar,Jstar. It becomes a necessary zero test only when the candidate satisfies the original equations.

Radial/time integration by parts has no endpoint terms because the test and the required derivatives vanish before reaching the integration boundary. Compact support strictly within r>0 avoids the displayed radial singularities. If a domain reaches the observer, regularity and all relevant flux traces must instead be demonstrated. The primitive identities themselves also assume a common calibrated observer/path convention. The radial null space of Pmap contains f0(u,n)+f1(u,n)/r; its endpoint behavior cannot be assigned freely when claiming a physical lensing primitive. These are distinct issues from the compact test's boundary terms.

## Gain division and deterministic input error

If the actual primitive records are psi_obs=g psi and z_obs=f z, for specified positive smooth candidate gains, the physical primitives must first be psi_obs/g and z_obs/f. For a fixed candidate the weak functional is therefore

    M=int[(H_psi/g)psi_obs+(H_z/f)z_obs]dmu.              (7)

This is an operator-order statement, not permission to commute division through T, D or the path correction. Even for a reception-only gain g(u), Dg=0 but Tg need not vanish. Dividing a nominally path-corrected redshift by g generally leaves an extra term. Gains must stay bounded away from zero on the compact support for finite useful error weights. The rule also requires that the gains multiply precisely the primitives stated here; a different channel definition needs its own map.

For pointwise bounds |delta psi_obs|<=epsilon_psi and |delta z_obs|<=epsilon_z,

    |delta M|<=int[|H_psi/g|epsilon_psi+|H_z/f|epsilon_z]dmu.  (8)

For equal constant epsilon, a conservative bound is

    |delta M|<=epsilon sqrt(2 Vol_mu [||H_psi/g||_2^2
                                        +||H_z/f||_2^2]).

The separate-channel L2 bound also follows. These are deterministic, candidate-conditional statements, with no independence, likelihood or confidence-level claim. Calibration/coefficient/coordinate errors are not included unless separately enclosed. Discrete use additionally requires a quadrature-error enclosure and a valid continuum error envelope. All finite selected tests are necessary constraints; zero moments do not establish uniqueness or a full solution.

## Predeclared independent controls and nonzero fixture

The exact operator fixture uses numerical coordinates on 0<tau<1, 1<r<2 and the full sphere, with angular factor H2=P2(cos theta). Let a=1+tau and

    C=a, d=a, e=a, h=1/a, K=2,
    alpha=2+tau, beta=1+tau/2, gamma=1,
    delta=3-tau, epsilon=1+tau,
    psi=[(1+tau+tau^3)r^2+(1+tau^2)r^3] H2,
    z=a[(1+tau^2)r^2+tau r^4] H2,
    lambda=a^8 r^8[tau(1-tau)(r-1)(2-r)]^8 H2.

The amplitude functions are constructed operator inputs, not fields claimed to satisfy an action. Compute P,Y,Zstar,Jstar and Rkin directly, and compare the exact strong moment to (6). Preserve a nonzero moment; do not retune a vanishing or failed test. The sphere factor is int H2^2 dOmega=4pi/5. Delta acting on any amplitude F times H2 gives [F_rr+2F_r/r-6F/r^2]H2.

The polynomial window extended by zero is C7, not globally C-infinity. Its boundary derivatives through order seven vanish, which suffices for this order-seven operator identity and exact integration-by-parts control. The general theorem above uses compact smooth tests; this finite-order control does not relabel its zero extension as a smooth bump. The r^8 and a^8 factors simplify rational denominators without changing the compact support or endpoint orders.

Check the formal divergences generically; check product and operator-order terms; compute the nonzero exact moment and both primitive kernel norms; verify sphere normalization and all needed boundary traces. For bounded errors use constants g=2,f=3 and errors (2tau-1)H2 and (2r-3)H2, whose absolute values are at most one on the box. Compare their exact functional shift to the conservative bound. Separately use the positive reception gain exp(u)=a exp(r) to expose the path-correction noncommutation. No fitted full-action fixture or rank claim is introduced.

Each scientific process is bounded by 120 seconds with bytecode disabled. Actual failures and timeouts, if any, will be preserved.

