# Bounded post-exposure correspondence and two witness qualifications

This supplement was written after reading the four author sources listed in `POST_EXPOSURE_SOURCE_BINDINGS_v1.json`. It does not replace the frozen pre-author proof or its 61 controls. No unchanged aggregate author replay is planned. The focused calculation below checks only disputed signs, angular noise normalization, the surviving spatial-sign mutation, and the announced ray-domain repair.

The author pairs the strong residual with **minus** lambda. The independent proof pairs it with plus lambda. Consequently every final author kernel equals minus the corresponding independent kernel. This is a convention, not a discrepancy. In particular `wP-wJ=-WP`, `v=-WZ`, author `b=-v/K` is minus the independent `w=-WZ/K`, and their `cP,cY` and primitive kernels are the negatives of the independent ones. The ordering of Ddagger, multiplication by r squared, and the derivative of a*cY agrees exactly.

For physical time and measure d tau r squared dr dOmega, the divergence identities are

    f Lg - (Ldagger f)g = partial_tau(fg) + (1/(a r^2))partial_r(r^2 fg),
    f Dg - (Ddagger f)g = (1/r^2)partial_r(r^2 fg) - partial_tau(a fg).

They fix Ldagger=-partial_tau-a^-1(partial_r+2/r) and Ddagger=-partial_r-2/r+a partial_tau+a'. With T_C=partial_tau+C, the commutator is [T_C,L]=-hL+h partial_tau-C'. For f=-(partial_tau+C)Z and Y=LZ, N=-KZ with K=C'+hC. No assertion of sufficiency follows from this necessary identity.

For arbitrary operator probes, rE=J+Z'+P and rN=N+KZ give

    M_first-M_eliminated = integral (wJ*rE-b*rN) dmu.

The latter is a residual-corrected algebraic identity; nonzero rE or rN does not make these probes physical solutions. The author's separation of physical and arbitrary probes is appropriate.

## Spatial-sign survivor

The physical radial harmonic Z=-4 r^2/eta has Delta_2 Z=0. Flipping the first weak spatial weight from -Delta(lambda)/a^2 to its negative changes its moment by 2 integral lambda Delta_2 Z/a^2 dmu=0. Thus this physical control cannot detect that mutation. For the separately declared operator probe Z0=eta^3 r^3, Delta_2 Z0=6 eta^3 r. The same difference on the old window is

    (3/64) integral_{-2}^{-1} integral_1^2 lambda0 eta^11 r^3 dr d eta,

where lambda0=(eta+2)^8(-1-eta)^8(r-1)^8(2-r)^8. This is strictly negative and can be evaluated exactly. It verifies why the new probe can detect the sign without turning it into a new action solution or repairing any domain error of the old ray witness. The actual historical mutation receipt is not in this comparison's supplied source set; its preservation is reported by root, while the mathematical reason for survival is independently checked here.

## Angular noise normalization

For standard real normalized Y20=sqrt(5/(4 pi))*P2(cos theta), integral Y20^2 dOmega=1, but

    integral |Y20| dOmega = 4 sqrt(15 pi)/9 > 1.

The author's two-dimensional radial/time L1 budgets therefore apply directly to deterministic errors in the recovered normalized harmonic coefficients psi20 and z20. A common full-field pointwise error envelope epsilon instead implies a coefficient envelope [4 sqrt(15 pi)/9]*epsilon. It cannot be called the same numerical full-field radius without that factor or another justified projection bound. A smooth example already exhibits the issue: delta psi(n)=epsilon P2(cos theta) has pointwise magnitude at most epsilon but its Y20 coefficient is epsilon sqrt(4 pi/5)>epsilon. The full-measure abstract triangle inequality is correct; this is a numerical-envelope interpretation issue. Root has independently acknowledged this qualification and will state coefficient envelopes explicitly.

## Full-ray domain failure and proposed repair

The old source window eta in [-2,-1], r in [1,2] contains eta=-3/2,r=7/4, for which u=eta+r=1/4. The ray eta_ray=u-s, 0<=s<=r, crosses eta_ray=0 at s=1/4. The stipulated action background and fields require eta<0 and have singular coefficients at zero. Polynomial expressions for P and its path integrals do not authorize this crossing. The old source-side operator integrals remain well defined, but the claimed complete physical observer-to-source ray witness fails on that window.

The proposed replacement eta in [-4,-3], r in [1,2] has u in [-3,-1]. Along every such ray, eta<=eta_ray<=u, hence -4<=eta_ray<=-1. It stays in the same smooth eta<0 branch. This geometric check does not itself verify forthcoming re-evaluated moments or error budgets; those require their own exact source binding. The pre-author independent operator fixture has no full-action or observer-to-source claim and is unaffected.

## Scope

The abstract test assumes a>0, r>0, K nonzero on the test support, regular prescribed coefficients, compact traces sufficient for all displayed integrations by parts, and nonvanishing supplied gains. The polynomial windows have C7 zero extensions, not C-infinity bump extensions; the author checks endpoint derivatives through order seven. A fixed candidate's primitive gain division occurs after the adjoint and does not remove the need to model any different gain/observer convention. Finite zero moments are neither full-action sufficiency, rank/uniqueness, nor empirical validation. Repeated-cone temporal coverage and calibrated geometry/background remain conditional inputs.
