# Corrected-window moment check before the focused calculation

This is a post-exposure correspondence check of the supplied v3 snapshot, not an independent pre-author discovery or an unchanged aggregate replay. The complete-ray repair and coefficient-envelope interpretation have been read. Earlier frozen evidence remains unchanged.

For the declared eta<0 coefficient history, T=(eta^8/256)partial_eta and P=eta^6 r^2/64, J=-2P, Z=-4r^2/eta. Direct substitution into the displayed kinetic combination gives Ckin(Utrue)=0 and Ckin(0)=3P. Therefore the wrong-candidate strong residual is 9 eta^13 r^2/8192, since Delta_2 Z=0. With the author's negative multiplier and measure a r^2 d eta dr, its moment density is -(9/32)lambda eta^5 r^4.

On the corrected support set x=eta+4, y=r-1. The exact moment is

    -(9/32) [integral_0^1 x^8(1-x)^8(x-4)^5 dx]
             [integral_0^1 y^8(1-y)^8(1+y)^4 dy].

Each bracket is evaluated by a finite binomial expansion and the factorial beta integral integral_0^1 x^(8+j)(1-x)^8 dx=(8+j)!8!/(17+j)!, instead of the author's Laurent-monomial integration routine. This independently checks the corrected strong moment. The supplied v3 primitive and field moments are then compared to this number as source-bound author results; their full high-order kernel integrals are not re-executed.

The reported L1 budgets are checked arithmetically for their radius relation m/[2(Npsi+Nz)]. Their many high-order terms are inspected through the source's exact monomial triangle bound, not independently recomputed here. The radius is a sufficient every-perturbed-record rejection radius for harmonic coefficient envelopes with a strict epsilon<radius inequality. For a common full-sky pointwise error envelope it is divided by integral|Y20|=4 sqrt(15 pi)/9. For common signal amplitude A, the nonzero moment and these sufficient radii scale by |A|, while the fixed candidate kernels do not. Unit-template numbers do not establish a usable small-amplitude instrument precision.

