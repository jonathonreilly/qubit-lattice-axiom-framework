# Pre-author findings: kinetic residual on primitive photons

The supplied equations admit a primitive-only necessary test under dmu=d tau r^2 dr dOmega. The correct formal adjoints are

    Tdag=-T,
    Ldag=-L-2/(ar),
    Ddag=-D-2/r+a',
    Deltadag=Delta.

These depend on the stated measure. In particular, the earlier flat-cone-measure adjoints cannot be reused.

The proof constructs weights by first integrating the kinetic residual, then eliminating Z=-N/K, and finally composing the primitive-map adjoints. Its final weight is

    H_psi=(1/2)Ddag(r^2 Ddag H_P)-Ddag[r^2 T(aH_z)],

with all intermediate coefficient products differentiated in their proper order. For arbitrary regular primitive inputs the exact identity is

    integral lambda Rkin dmu
        = integral(H_z z+H_psi psi)dmu.

It is a zero condition only for candidates satisfying the supplied original equations. The reconstruction from N/K alone does not certify their compatibility.

For the predeclared nonzero operator fixture, the full-sphere strong and primitive moments agree exactly:

    m=-1898512461891559291*pi/37752425453003939803125
      =-0.0001579859500802647... .

The fixture explicitly fails the original first-order equations and is not a full-action solution. It was not retuned after computation. Its angular factor is P2(cos theta), with integral P2^2 dOmega=4pi/5.

The compact polynomial window has a C7 zero extension, with all normal boundary derivatives through order seven checked to vanish. It is not called a C-infinity bump. These traces suffice for the finite-order identity through seven derivatives; the general proof applies to compact smooth tests. The support lies strictly on 1<r<2, so no observer-origin regularity is inferred. Physical primitive/path conventions and their possible radial integration kernels remain separate input conditions.

Four deliberate algebraic kernel errors each change this same fixed exact moment: omitting a' from Ddag, omitting the spherical radial divergence, replacing T(aH_z) by aT(H_z), and replacing T(dV) by dT(V). These are negative algebra controls, not failed scientific attempts or whole-program source mutations.

Gain division must apply to the stipulated primitives first. For psi_obs=g psi and z_obs=f z, the final weights are H_psi/g and H_z/f. A reception-only example g=exp(u)=(1+tau)exp(r) has Dg=0 but still produces an extra path term if one forms the nominal correction before dividing. This is not a gain-identification result.

The pointwise error inequality is

    |delta M|<=int[|H_psi/g|epsilon_psi+|H_z/f|epsilon_z]dmu.

A conservative equal-envelope bound is epsilon times
sqrt(2 Vol_mu [||H_psi/g||_2^2+||H_z/f||_2^2]).
The fixture uses g=2, f=3, Vol_mu=28pi/3, and bounded raw-channel errors
(2tau-1)P2 and (2r-3)P2. Their exact shift is
-300607408678529*pi/811880117268901931250, approximately -1.16321e-6;
the unit-envelope conservative bound is 336.90146. The bound is valid but very loose here. It is not evidence of useful instrument conditioning. Exact kernel norm fractions, the bound squared and their positive rational comparison are preserved in ATTEMPT01_bounds.stdout.txt. Candidate/coefficient/registration uncertainties and quadrature errors require their own enclosures.

There are 61 passing exact controls: adjoint/geometry algebra 10, fixed moment and endpoint/operator-order controls 46, and gain/error controls 5. Actual subprocess times were 0.338, 32.905 and 17.563 seconds; each had a 120-second cap and bytecode disabled. All full stdout/stderr streams are preserved. There were no failed or timed-out attempts and no retries.

The proof was frozen before code. No root primitive-photon source, implementation or output was read, and no earlier scientific note was needed for this unit. Python 3.12.8 and SymPy 1.14.0 are shared infrastructure. The code reads only its own earlier moment output for the norm-bound stage; that exact generated input is declared and hash-bound before consumption. The wrapper binds all its literal source inputs before and after execution.

The test is real and bilinear as written; complex implementations must keep the corresponding transpose/conjugation convention consistent. Finite zero tests do not establish a full solution, action selection, uniqueness, empirical acceptance or confidence level. Root retains authorship. The next obligation is a bounded comparison with the still-unseen author construction.

