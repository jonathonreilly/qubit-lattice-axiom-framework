"""Bounded canonical integration invariants; no author helper or aggregate executed."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = (
 "sources/docs/SCALAR_PRIMITIVE_KINETIC_NOTE_2026-10-16.md",
 "sources/scripts/scalar_primitive_kinetic.py",
 "sources/scripts/scalar_primitive_kinetic_core.py",
 "sources/scripts/scalar_primitive_kinetic_action.py",
 "sources/scripts/scalar_primitive_kinetic_bound.py",
 "sources/outputs/scalar_primitive_kinetic/result.json",
 "../post_author_sources_v3/check_kinetic_primitive_photon_v3.py",
 "../post_author_sources_v3/KINETIC_PRIMITIVE_PHOTON_CONTROLS_v3.json",
)
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import ast,hashlib,json,time
start=time.monotonic()
folder=Path(__file__).resolve().parent
raw={name:(folder/name).read_bytes() for name in AUDIT_INPUT_PATHS}
checks=[]
def test(name,condition):
 ok=bool(condition);checks.append({"name":name,"pass":ok})
 if not ok:raise AssertionError(name)
pins={
 "docs/SCALAR_PRIMITIVE_KINETIC_NOTE_2026-10-16.md":"1a2a389b64d4ad24f369876b637577459c1da568d2aaa6cb3a49c097446aff51",
 "scripts/scalar_primitive_kinetic.py":"978ab14363b55f759e867555dad5b15614056a7053caf4b33fb49abbec50475f",
 "scripts/scalar_primitive_kinetic_core.py":"df030726044df695faacc96eefb5d899c5fbadb0f9138e3ca050de7617604ddb",
 "scripts/scalar_primitive_kinetic_action.py":"9ec86c25fb331f2f41bbed742305ea1e072cf58759c6fe62ec36115b72af10de",
 "scripts/scalar_primitive_kinetic_bound.py":"e06cad4f61560603371dc99b4cc9e50e4d54859149435be35c8b9526f33ac32e",
 "outputs/scalar_primitive_kinetic/result.json":"f142d98b33c29cffb821c92c7e5ba4ac949fa3b0e0da269576fe15b06c7f9bc2"
}
for path,sha in pins.items():
 test("snapshot pin "+path,hashlib.sha256(raw["sources/"+path]).hexdigest()==sha)
result=json.loads(raw["sources/outputs/scalar_primitive_kinetic/result.json"])
expected_sources={p:h for p,h in pins.items() if p!="outputs/scalar_primitive_kinetic/result.json"}
test("result exact source closure",result["source_sha256"]==expected_sources)
primary=ast.parse(raw["sources/scripts/scalar_primitive_kinetic.py"])
inputs=next(ast.literal_eval(n.value) for n in primary.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="AUDIT_INPUT_PATHS" for t in n.targets))
test("declared integrity paths exact",list(inputs)==[
 "docs/SCALAR_PRIMITIVE_KINETIC_NOTE_2026-10-16.md",
 "scripts/scalar_primitive_kinetic_action.py",
 "scripts/scalar_primitive_kinetic_core.py",
 "scripts/scalar_primitive_kinetic_bound.py"])
test("explicit self integrity read",result["input_roles"]["integrity_reads"]==["scripts/scalar_primitive_kinetic.py",*inputs])
helpers={"scalar_primitive_kinetic_action","scalar_primitive_kinetic_core","scalar_primitive_kinetic_bound"}
imports={a.name for node in primary.body if isinstance(node,ast.Import) for a in node.names}
test("three imported canonical helpers",helpers<=imports)
calls=[node.func.value.id for node in ast.walk(primary) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=="run_checks" and isinstance(node.func.value,ast.Name)]
test("all helper calls present",set(calls)==helpers and len(calls)==3)
for name in sorted(helpers):
 tree=ast.parse(raw["sources/scripts/"+name+".py"])
 banned=[]
 for node in ast.walk(tree):
  if isinstance(node,ast.Call):
   if isinstance(node.func,ast.Name) and node.func.id in {"open","exec","eval","compile","__import__"}:banned.append(node.func.id)
   if isinstance(node.func,ast.Attribute) and node.func.attr in {"read_bytes","read_text","read","load","loads","parse","literal_eval","write_text","write_bytes"}:banned.append(node.func.attr)
 test(name+" has no file or dynamic scientific input calls",not banned)
main=next(n for n in primary.body if isinstance(n,ast.FunctionDef) and n.name=="main")
boundcall=next(n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=="scalar_primitive_kinetic_bound")
test("bound uses fresh core context",len(boundcall.args)==1 and isinstance(boundcall.args[0],ast.Name) and boundcall.args[0].id=="context")
for name,count in [("original_action",82),("primitive",78),("exact_bounds",42)]:
 unit=result["units"][name]
 test(name+" typed consistent controls",all(type(c.get("pass")) is bool for c in unit["checks"]) and len(unit["checks"])==count and unit["passed"]==count and unit["failed"]==0 and all(c["pass"] for c in unit["checks"]))
 test(name+" zero residual fields",all(c.get("residual","0")=="0" for c in unit["checks"]))
test("total failures consistent",result["failed"]==sum(u["failed"] for u in result["units"].values())==0)
old=json.loads(raw["../post_author_sources_v3/KINETIC_PRIMITIVE_PHOTON_CONTROLS_v3.json"])
new=result["units"]["primitive"]
test("core preserves all 77 old controls",new["checks"][:len(old["checks"])]==old["checks"])
test("core adds only angular control",len(new["checks"])==len(old["checks"])+1 and new["checks"][-1]["name"]=="fullsky_absolute_projection_factor")
test("core records unchanged",new["records"]==old["records"])
test("core moments unchanged",new["moments"]==old["moments"])
# Compare the actual mathematical statement prefix, not merely output labels.
oldtree=ast.parse(raw["../post_author_sources_v3/check_kinetic_primitive_photon_v3.py"])
newtree=ast.parse(raw["sources/scripts/scalar_primitive_kinetic_core.py"])
newbody=next(n.body for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=="run_checks")
def assigned(node,name):
 return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
oldstart=next(i for i,n in enumerate(oldtree.body) if assigned(n,"checks"))
oldend=next(i for i,n in enumerate(oldtree.body) if assigned(n,"result"))
newend=next(i for i,n in enumerate(newbody) if assigned(n,"xx"))
test("core mathematical AST prefix identical to corrected v3",ast.dump(ast.Module(body=oldtree.body[oldstart:oldend],type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=newbody[:newend],type_ignores=[]),include_attributes=False))
mode={"n":"3/2","exponent":"-3","J_over_P":"-2","U_over_tP":"2","db_over_P":"3"}
test("original-action output includes exact photon mode",mode in result["units"]["original_action"]["modes"])

# All serialized polynomial coefficients are consumed as exact rationals.
def add(a,b):
 c=a.copy()
 for ij,v in b.items():c[ij]=c.get(ij,Q(0))+v
 return {ij:v for ij,v in c.items() if v}
def scale(a,c):return {ij:v*c for ij,v in a.items() if v*c}
def mult(a,b):
 c={}
 for (i,j),v in a.items():
  for (k,l),w in b.items():c[i+k,j+l]=c.get((i+k,j+l),Q(0))+v*w
 return {ij:v for ij,v in c.items() if v}
def power(a,n):
 out={(0,0):Q(1)}
 for _ in range(n):out=mult(out,a)
 return out
def parse_poly(text):
 def ev(n):
  if isinstance(n,ast.Constant) and type(n.value) is int:return {(0,0):Q(n.value)}
  if isinstance(n,ast.Name) and n.id=="eta":return {(1,0):Q(1),(0,0):Q(-4)}
  if isinstance(n,ast.Name) and n.id=="r":return {(0,1):Q(1),(0,0):Q(1)}
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return scale(ev(n.operand),Q(-1))
  if isinstance(n,ast.BinOp):
   if isinstance(n.op,ast.Add):return add(ev(n.left),ev(n.right))
   if isinstance(n.op,ast.Sub):return add(ev(n.left),scale(ev(n.right),Q(-1)))
   if isinstance(n.op,ast.Mult):return mult(ev(n.left),ev(n.right))
   if isinstance(n.op,ast.Pow) and isinstance(n.right,ast.Constant) and type(n.right.value) is int and n.right.value>=0:return power(ev(n.left),n.right.value)
   if isinstance(n.op,ast.Div) and isinstance(n.right,ast.Constant) and type(n.right.value) is int:return scale(ev(n.left),Q(1,n.right.value))
  raise ValueError("Unexpected polynomial syntax "+ast.dump(n))
 return ev(ast.parse(text,mode="eval").body)
def integral(poly):return sum((c/Q((i+1)*(j+1)) for (i,j),c in poly.items()),Q(0))
bounds=result["units"]["exact_bounds"]
polys={}
for label in ["psi","z"]:
 encoded=bounds["computed_weight_polynomials"][label]
 terms=encoded["coefficients"]
 test(label+" unique polynomial powers",len({tuple(t["powers"]) for t in terms})==len(terms))
 poly={tuple(t["powers"]):Q(t["coefficient"]) for t in terms}
 test(label+" nonzero rational coefficients",all(v!=0 for v in poly.values()))
 test(label+" exact degree metadata",[max(i for i,j in poly),max(j for i,j in poly)]==encoded["degree"]==bounds["norm_enclosures"][label]["degrees"])
 levs=bounds["norm_enclosures"][label]["levels"]
 test(label+" degree-zero lower bound equals signed integral",Q(levs[0]["lower"])==abs(integral(poly)))
 test(label+" all enclosure levels nested",all(Q(v["lower"])<=Q(v["upper"]) for v in levs) and all(Q(a["lower"])<=Q(b["lower"])<=Q(b["upper"])<=Q(a["upper"]) for a,b in zip(levs,levs[1:])))
 polys[label]=poly
pairing=integral(mult(polys["psi"],parse_poly(new["records"]["psi"])))+integral(mult(polys["z"],parse_poly(new["records"]["z"])))
expected_m=Q(827093,50599790841600)
test("all encoded kernel coefficients reproduce fixed moment",pairing==expected_m)
test("primitive and bound moments agree",Q(bounds["moment"])==expected_m==Q(new["moments"]["wrong_canonical"]["primitive_moment"]))
upper=sum((Q(bounds["norm_enclosures"][k]["levels"][-1]["upper"]) for k in ["psi","z"]),Q(0))
test("combined exact upper closure",upper==Q(bounds["combined_upper"]))
test("strict-radius formula exact",Q(bounds["uniform_radius"])==expected_m/(2*upper))
test("note exact combined upper",str(upper.numerator) in raw[AUDIT_INPUT_PATHS[0]].decode() and str(upper.denominator) in raw[AUDIT_INPUT_PATHS[0]].decode())
# The isolated integrated channel uses endpoint differentiation only when it is separately supplied.
# For P(eta,s)=eta^2*s^2, explicit I=-2 integral_0^r P_eta(u-s,s)ds.
# I=-4u*r^3/3+r^4, so D_u I=-4u*r^2+4r^3=-2 P_eta(u-r,r).
test("isolated ISW endpoint identity at exact point",(-4*Q(-2)*Q(3,2)**2+4*Q(3,2)**3)==-4*(Q(-2)-Q(3,2))*Q(3,2)**2)
print(json.dumps({"scope":"Static source/output closure and exact encoded-kernel invariant; no aggregate replay",
 "passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks),"checks":checks,
 "elapsed_sec":time.monotonic()-start,"source_pins":pins,
 "values":{"encoded_psi_terms":len(polys["psi"]),"encoded_z_terms":len(polys["z"]),
 "primitive_pairing":str(pairing),"combined_upper":str(upper),"radius":bounds["uniform_radius"],
 "read_closure":"All helper science computed from imported code/context. Note and code files read only for integrity by canonical primary."}},
 indent=2))

