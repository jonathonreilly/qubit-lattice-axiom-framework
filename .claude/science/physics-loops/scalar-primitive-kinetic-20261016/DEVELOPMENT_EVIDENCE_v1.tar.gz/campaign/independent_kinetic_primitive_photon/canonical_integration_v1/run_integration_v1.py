"""Preserve a bounded integration checker attempt; no author computation replay."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = ("check_integration_v1.py",)
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
folder=Path(__file__).resolve().parent
script=folder/"check_integration_v1.py"
env=os.environ.copy();env["PYTHONDONTWRITEBYTECODE"]="1"
cmd=[sys.executable,"-B",str(script)]
start=time.monotonic()
meta={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":cmd,"cwd":str(folder),"timeout_sec":120,"script_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),"bytecode_disabled":True}
try:
 p=subprocess.run(cmd,cwd=folder,env=env,capture_output=True,timeout=120)
 out,err=p.stdout,p.stderr;meta["exit_code"]=p.returncode;meta["timeout"]=False
except subprocess.TimeoutExpired as ex:
 out,err=ex.stdout or b"",ex.stderr or b"";meta["exit_code"]=None;meta["timeout"]=True
meta["elapsed_sec"]=time.monotonic()-start
for name,data in [("ATTEMPT01.stdout.txt",out),("ATTEMPT01.stderr.txt",err)]:
 path=folder/name
 if path.exists():raise RuntimeError("Refusing to replace preserved "+name)
 path.write_bytes(data);meta[name]={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
if meta["exit_code"]==0:
 result=json.loads(out);meta["passed"]=result["passed"];meta["failed"]=result["failed"]
target=folder/"RUN_v1.json"
if target.exists():raise RuntimeError("Refusing to replace preserved run receipt")
target.write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta,indent=2))
sys.exit(0 if meta["exit_code"]==0 else 1)

