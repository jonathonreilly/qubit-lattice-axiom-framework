#!/usr/bin/env python3
"""Independent primitive weak identity and an exact non-solution operator fixture."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = ["ATTEMPT01_moment.stdout.txt"]
import json
from pathlib import Path
import platform
import sys
import time
import sympy as s

start=time.monotonic()
checks=[];details={}
t,r=s.symbols("tau r",real=True)
def clean(expr):
    return s.cancel(s.expand(expr))
def zero(name,expr):
    v=clean(expr)
    checks.append({"name":name,"passed":v==0,"residual":str(v)})
def nonzero(name,expr):
    v=clean(expr)
    checks.append({"name":name,"passed":v!=0,"value":str(v)})
def positive(name,expr):
    v=s.factor(expr)
    checks.append({"name":name,"passed":v.is_positive is True,"value":str(v)})
def integrate_poly(expr):
    poly=s.Poly(clean(expr),t,r,domain=s.QQ)
    radial={}
    for (i,j),coef in poly.terms():
        radial[i]=radial.get(i,s.S.Zero)+coef*s.Rational(2**(j+1)-1,j+1)
    return s.factor(sum(value/s.Integer(i+1) for i,value in radial.items()))
def pack_poly(expr):
    p=s.Poly(clean(expr),t,r,domain=s.QQ)
    return [[i,j,str(c)] for (i,j),c in p.terms()]
def unpack_poly(rows):
    return s.Poly.from_dict({(i,j):s.Rational(c) for i,j,c in rows},(t,r)).as_expr()

def adjoints():
    a=s.Function("a")(t)
    f=s.Function("f")(t,r);v=s.Function("v")(t,r)
    T=lambda x:s.diff(x,t)
    R=lambda x:s.diff(x,r)
    L=lambda x:T(x)+R(x)/a
    D=lambda x:R(x)-a*T(x)
    Tdag=lambda x:-T(x)
    Ldag=lambda x:-L(x)-2*x/(a*r)
    Ddag=lambda x:-D(x)-2*x/r+s.diff(a,t)*x
    zero("time_Green_identity",f*T(v)-Tdag(f)*v-T(f*v))
    zero("L_Green_identity",f*L(v)-Ldag(f)*v-T(f*v)-R(r**2*f*v/a)/r**2)
    zero("D_Green_identity",f*D(v)-Ddag(f)*v-T(-a*f*v)-R(r**2*f*v)/r**2)
    ell=s.symbols("ell",integer=True,nonnegative=True)
    lap=lambda x:R(R(x))+2*R(x)/r-ell*(ell+1)*x/r**2
    zero("spherical_Laplacian_Green_identity",
         f*lap(v)-lap(f)*v-R(r**2*(f*R(v)-R(f)*v))/r**2)
    h=s.diff(a,t)/a
    zero("time_lightcone_commutator",T(L(v))-L(T(v))-h*(T(v)-L(v)))
    C=s.Function("C")(t)
    Y=L(v);F=-T(v)-C*v
    N=T(Y)+(h+C)*Y+L(F)+h*F
    zero("hidden_velocity_sign",N+(T(C)+h*C)*v)
    x=s.symbols("cos_theta",real=True)
    H2=(3*x*x-1)/2
    zero("angular_eigenvalue",s.diff((1-x*x)*s.diff(H2,x),x)+6*H2)
    zero("sphere_normalization",2*s.pi*s.integrate(H2**2,(x,-1,1))-4*s.pi/5)
    # Product rules that would fail if coefficient multiplication were moved.
    d=s.Function("d")(t)
    zero("time_product_correction",T(d*f)-d*T(f)-T(d)*f)
    zero("path_time_product_correction",T(a*f)-a*T(f)-T(a)*f)
    details["measure"]="d tau r^2 dr dOmega; full sphere; compact annular support."

def fixture():
    a=1+t;h=1/a;C=a;d=a;e=a
    alpha=2+t;beta=1+t/2;gamma=s.Integer(1)
    delta=3-t;eps=1+t
    T=lambda x:s.diff(x,t)
    R=lambda x:s.diff(x,r)
    L=lambda x:T(x)+R(x)/a
    D=lambda x:R(x)-a*T(x)
    lap=lambda x:R(R(x))+2*R(x)/r-6*x/r**2
    Ldag=lambda x:-L(x)-2*x/(a*r)
    Ddag=lambda x:-D(x)-2*x/r+x
    psi=(1+t+t**3)*r**2+(1+t*t)*r**3
    z=a*((1+t*t)*r**2+t*r**4)
    lam=a**8*r**8*(t*(1-t)*(r-1)*(2-r))**8
    K=clean(T(C)+h*C)
    P=clean(D(r*r*D(psi))/2)
    Y=clean(z+a*T(r*r*D(psi)))
    F=clean(d*T(P)+e*P)
    N=clean(T(Y)+(h+C)*Y+L(F)+h*F)
    Z=clean(-N/K)
    J=clean(-T(Z)-P)
    Ckin=clean(alpha*T(P)+beta*T(J)+gamma*lap(P)+delta*P+eps*J)
    strong=clean(T(Ckin)+lap(Z)/a**2)
    WP=clean(T((alpha-beta)*T(lam))-lap(gamma*T(lam))-(delta-eps)*T(lam))
    WZ=clean(T(T(beta*T(lam)))-T(eps*T(lam))+lap(lam/a**2))
    w=clean(-WZ/K)
    Hz=clean(-T(w)+(h+C)*w)
    V=clean(Ldag(w)+h*w)
    HP=clean(WP-T(d*V)+e*V)
    Hpsi=clean(Ddag(r*r*Ddag(HP))/2-Ddag(r*r*T(a*Hz)))
    return locals()

def moment():
    data=fixture()
    a,h,C,d,e,psi,z,lam,K,P,Y,F,N,Z,J,strong,WP,WZ,w,Hz,V,HP,Hpsi,T,R,L,D,lap,Ddag=[data[n] for n in
      ["a","h","C","d","e","psi","z","lam","K","P","Y","F","N","Z","J","strong","WP","WZ","w","Hz","V","HP","Hpsi","T","R","L","D","lap","Ddag"]]
    zero("fixture_K",K-2)
    nonzero("fixture_original_first_order_not_assumed",T(Z)+C*Z+F)
    nonzero("fixture_photon_velocity_not_assumed",L(Z)-Y)
    m=integrate_poly(r*r*lam*strong)
    mstage1=integrate_poly(r*r*(WP*P+WZ*Z))
    mstage2=integrate_poly(r*r*(HP*P+Hz*Y))
    mprimitive=integrate_poly(r*r*(Hpsi*psi+Hz*z))
    zero("kinetic_adjoint_exact_moment",mstage1-m)
    zero("elimination_adjoint_exact_moment",mstage2-m)
    zero("primitive_adjoint_exact_moment",mprimitive-m)
    nonzero("nonzero_operator_moment",m)
    for variable,ends in [(t,[0,1]),(r,[1,2])]:
        for end in ends:
            for order in range(8):
                zero(f"boundary_{variable}_{end}_derivative_{order}",
                     s.diff(lam,variable,order).subs(variable,end))
    # Fixed-fixture algebraic mutations, not edits to a source program.
    badD=lambda x:-D(x)-2*x/r
    badH=clean(badD(r*r*badD(HP))/2-badD(r*r*T(a*Hz)))
    err_D=integrate_poly(r*r*((badH-Hpsi)*psi))
    nonzero("omitting_a_prime_detected_in_same_moment",err_D)
    badpath=clean(Ddag(r*r*Ddag(HP))/2-Ddag(r*r*a*T(Hz)))
    err_path=integrate_poly(r*r*(badpath-Hpsi)*psi)
    nonzero("wrong_path_product_order_detected_in_same_moment",err_path)
    badV=clean(-L(w)+h*w)
    badHP=clean(WP-T(d*badV)+e*badV)
    badradial=clean(Ddag(r*r*Ddag(badHP))/2-Ddag(r*r*T(a*Hz)))
    err_radial=integrate_poly(r*r*(badradial-Hpsi)*psi)
    nonzero("omitting_spherical_radial_divergence_detected",err_radial)
    badHP2=clean(WP-d*T(V)+e*V)
    baddprod=clean(Ddag(r*r*Ddag(badHP2))/2-Ddag(r*r*T(a*Hz)))
    err_dprod=integrate_poly(r*r*(baddprod-Hpsi)*psi)
    nonzero("wrong_d_product_order_detected_in_same_moment",err_dprod)
    # A positive reception-only multiplier has Dg=0 but aTg=g.
    gain=a*s.exp(r)
    B=r*r*D(psi)
    nominal=gain*z+a*T(r*r*D(gain*psi))
    zero("reception_gain_D_zero",D(gain))
    zero("reception_gain_path_extra_term",nominal/gain-Y-B)
    nonzero("nominal_path_then_divide_is_wrong",nominal/gain-Y)
    details.update({
      "angular_factor":"4*pi/5","moment_amplitude":str(m),
      "full_moment":str(4*s.pi*m/5),"full_moment_float":float(4*s.pi*m/5),
      "fixture_status":"Nonzero operator residual; original first-order equations not satisfied.",
      "window_status":"C7 zero extension, all normal boundary derivatives through seven vanish; theorem uses compact smooth tests.",
      "mutant_moment_amplitudes":{"omit_a_prime":str(err_D),"wrong_path_order":str(err_path),
          "omit_radial_divergence":str(err_radial),"wrong_d_product":str(err_dprod)},
      "polynomials":{"Hz":pack_poly(Hz),"Hpsi":pack_poly(Hpsi)},
      "strong_residual":str(strong),
      "data_psi":str(psi),"data_z":str(z)})
    
def bounds():
    path=Path(__file__).resolve().parent/"ATTEMPT01_moment.stdout.txt"
    raw=path.read_bytes()
    previous=json.loads(raw)
    assert previous["failed"]==0,"Moment case must complete before bound case"
    Hz=unpack_poly(previous["details"]["polynomials"]["Hz"])
    Hpsi=unpack_poly(previous["details"]["polynomials"]["Hpsi"])
    wz=Hz/3;wp=Hpsi/2  # raw-channel constant gains f=3, g=2
    nz=integrate_poly(r*r*wz*wz)
    np=integrate_poly(r*r*wp*wp)
    E=integrate_poly(r*r*(wz*(2*r-3)+wp*(2*t-1)))
    positive("z_kernel_norm_positive",nz)
    positive("psi_kernel_norm_positive",np)
    margin=s.Rational(70,3)*(nz+np)-E*E
    positive("pointwise_unit_errors_inside_conservative_bound",margin)
    # The gain-scaled raw records cancel pointwise before any data derivative.
    psi=(1+t+t**3)*r**2+(1+t*t)*r**3
    z=(1+t)*((1+t*t)*r**2+t*r**4)
    zero("constant_gain_division_before_pairing",wp*(2*psi)+wz*(3*z)-Hpsi*psi-Hz*z)
    strongm=s.Rational(previous["details"]["moment_amplitude"])
    measured=integrate_poly(r*r*(wp*(2*psi+(2*t-1))+wz*(3*z+(2*r-3))))
    zero("exact_perturbed_moment_shift",measured-strongm-E)
    Bsq=224*s.pi**2*(nz+np)/15
    details.update({
      "input_file":path.name,"input_sha256":__import__("hashlib").sha256(raw).hexdigest(),
      "angular_norm":"4*pi/5","support_volume":"28*pi/3",
      "g_lensing":"2","f_redshift":"3","epsilon":"1",
      "nz_amplitude":str(nz),"npsi_amplitude":str(np),
      "norm_sum_full":str(4*s.pi*(nz+np)/5),
      "actual_error_moment":str(4*s.pi*E/5),
      "error_bound_squared":str(Bsq),
      "error_bound_float":float(s.sqrt(Bsq)),
      "actual_error_float":float(4*s.pi*E/5),
      "pointwise_error_assumption":"|(2tau-1)P2|<=1 and |(2r-3)P2|<=1 on the stated box/sphere.",
      "interpretation":"Norms apply to divided weights Hz/f,Hpsi/g; fixed-candidate deterministic bound only."})

cases={"adjoints":adjoints,"moment":moment,"bounds":bounds}
if len(sys.argv)!=2 or sys.argv[1] not in cases:
    raise SystemExit("Choose adjoints, moment, or bounds")
cases[sys.argv[1]]()
failed=sum(not c["passed"] for c in checks)
print(json.dumps({"stage":"Independent pre-author operator check",
    "case":sys.argv[1],"python":platform.python_version(),"sympy":s.__version__,
    "elapsed_seconds":time.monotonic()-start,"passed":len(checks)-failed,"failed":failed,
    "checks":checks,"details":details},indent=2))
raise SystemExit(1 if failed else 0)

