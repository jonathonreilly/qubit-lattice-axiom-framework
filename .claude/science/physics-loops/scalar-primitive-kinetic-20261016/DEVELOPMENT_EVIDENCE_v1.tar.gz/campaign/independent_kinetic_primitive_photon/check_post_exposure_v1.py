"""Post-exposure focused algebra; no author aggregate imported or executed."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUTS = []
import json
import time
import sympy as s

started = time.monotonic()
checks = []
values = {}
def zero(name, expression):
    remainder = s.expand(expression)
    ok = remainder == 0
    if not ok:
        remainder = s.simplify(remainder)
        ok = remainder == 0
    checks.append({"name":name,"pass":bool(ok),"remainder":str(remainder)})
    if not ok:
        raise AssertionError(name + ": " + str(remainder))
def truth(name, value):
    ok = bool(value)
    checks.append({"name":name,"pass":ok})
    if not ok:
        raise AssertionError(name)

tau,r=s.symbols("tau r", real=True, positive=True)
a=s.Function("a")(tau)
C=s.Function("C")(tau)
d=s.Function("d")(tau)
e=s.Function("e")(tau)
al,be,ga,de,ep=[s.Function(n)(tau) for n in ["alpha","beta","gamma","delta","epsilon"]]
lam=s.Function("lambda")(tau,r)
T=lambda f:s.diff(f,tau)
L=lambda f:T(f)+s.diff(f,r)/a
D=lambda f:s.diff(f,r)-a*T(f)
Ld=lambda f:-T(f)-(s.diff(f,r)+2*f/r)/a
Dd=lambda f:-D(f)-2*f/r+T(a)*f
lap=lambda f:s.diff(f,r,2)+2*s.diff(f,r)/r-6*f/r**2
h=T(a)/a
K=T(C)+h*C
WP=T((al-be)*T(lam))-lap(ga*T(lam))-(de-ep)*T(lam)
WZ=T(T(be*T(lam)))-T(ep*T(lam))+lap(lam/a**2)
wP=-T(al*T(lam))+de*T(lam)+ga*lap(T(lam))
wJ=-T(be*T(lam))+ep*T(lam)
wZ=-lap(lam)/a**2
zero("first P weights differ only by declared multiplier sign",wP-wJ+WP)
zero("first Z weights differ only by declared multiplier sign",T(wJ)+wZ+WZ)
b=s.Function("b")(tau,r)
g=Ld(b)+h*b
root_cP=wP-wJ-T(d*g)+e*g
root_cY=-T(b)+(C+h)*b
own_w=-b
own_v=Ld(own_w)+h*own_w
own_HP=WP-T(d*own_v)+e*own_v
own_HY=-T(own_w)+(C+h)*own_w
zero("eliminated P kernels opposite",root_cP+own_HP)
zero("eliminated Y kernels opposite",root_cY+own_HY)
cp=s.Function("cp")(tau,r)
cy=s.Function("cy")(tau,r)
root_hp=Dd(r**2*(Dd(cp)/2-T(a*cy)))
same_hp=Dd(r**2*Dd(cp))/2-Dd(r**2*T(a*cy))
zero("primitive product ordering identical",root_hp-same_hp)
f=s.Function("f")(tau,r)
z=s.Function("Z")(tau,r)
zero("L adjoint pointwise divergence",f*L(z)-Ld(f)*z-T(f*z)-s.diff(r**2*f*z,r)/(a*r**2))
zero("D adjoint pointwise divergence",f*D(z)-Dd(f)*z-s.diff(r**2*f*z,r)/r**2+T(a*f*z))
Tc=lambda q:T(q)+C*q
zero("commutator generic coefficient history",Tc(L(z))-L(Tc(z))+h*L(z)-h*T(z)+T(C)*z)
F=-Tc(z); Y=L(z)
N=T(Y)+(h+C)*Y+L(F)+h*F
zero("N equals minus KZ on first order transport",N+K*z)
P=s.Function("P")(tau,r)
J=s.Function("J")(tau,r)
rE=J+T(z)+P
zero("Euler residual correction before integration",wP*P+wJ*J+wZ*z-((wP-wJ)*P+(T(wJ)+wZ)*z+wJ*rE)+T(wJ*z))
vv,nn,rr,kk=s.symbols("v N rN K", nonzero=True)
bb=-vv/kk
zero("commutator residual correction algebra",vv*(rr-nn)/kk-bb*nn+bb*rr)

eta=s.symbols("eta",real=True)
lapr=lambda q:s.diff(q,r,2)+2*s.diff(q,r)/r-6*q/r**2
zero("physical solid harmonic is insensitive to spatial sign",lapr(-4*r**2/eta))
zero("nonharmonic probe laplacian",lapr(eta**3*r**3)-6*eta**3*r)
lt=(eta+2)**8*(-1-eta)**8
lr=(r-1)**8*(2-r)**8
it=s.integrate(s.expand(lt*eta**11),(eta,-2,-1))
ir=s.integrate(s.expand(lr*r**3),(r,1,2))
delta=s.factor(s.Rational(3,64)*it*ir)
truth("spatial sign mutation detected by nonharmonic probe",delta<0)
values["spatial_mutation_moment_wrong_minus_right"]=str(delta)

x=s.symbols("x",real=True)
P2=(3*x**2-1)/2
Y20=s.sqrt(5/(4*s.pi))*P2
zero("normalized angular square",2*s.pi*s.integrate(Y20**2,(x,-1,1))-1)
cut=1/s.sqrt(3)
ang_l1=s.simplify(4*s.pi*(s.integrate(-Y20,(x,0,cut))+s.integrate(Y20,(x,cut,1))))
zero("angular L1 projection factor",ang_l1-4*s.sqrt(15*s.pi)/9)
truth("pointwise to harmonic factor exceeds one",ang_l1.evalf()>1)
smooth_coeff=s.simplify(2*s.pi*s.integrate(P2*Y20,(x,-1,1)))
zero("smooth pointwise envelope counterexample",smooth_coeff-s.sqrt(4*s.pi/5))
truth("smooth example coefficient exceeds pointwise envelope",smooth_coeff.evalf()>1)
values["angular_L1"]=str(ang_l1)
values["angular_L1_decimal"]=str(s.N(ang_l1,25))
values["smooth_pointwise_unit_error_coefficient"]=str(smooth_coeff)

old_eta=-s.Rational(3,2);old_r=s.Rational(7,4)
old_u=old_eta+old_r
truth("old source point inside old window",-2<old_eta<-1 and 1<old_r<2)
truth("old full ray crosses singular boundary",0<old_u<old_r)
zero("crossing conformal time",old_u-old_u)
# The ray time is eta+(1-v)r with 0<=v<=1; extrema are corners.
corners=[et+(1-v)*rr for et in [-4,-3] for rr in [1,2] for v in [0,1]]
truth("new ray interval lower endpoint",min(corners)==-4)
truth("new ray interval upper endpoint",max(corners)==-1)
truth("new full ray stays strictly negative",max(corners)<0)
values["old_example"]={"eta":str(old_eta),"r":str(old_r),"u":str(old_u),"crossing_s":str(old_u)}
values["new_full_ray_range"]=[min(corners),max(corners)]
new_lam=(eta+4)**8*(-3-eta)**8*(r-1)**8*(2-r)**8
for k in range(8):
    zero("new window eta left trace "+str(k),s.diff(new_lam,eta,k).subs(eta,-4))
    zero("new window eta right trace "+str(k),s.diff(new_lam,eta,k).subs(eta,-3))
    zero("new window r left trace "+str(k),s.diff(new_lam,r,k).subs(r,1))
    zero("new window r right trace "+str(k),s.diff(new_lam,r,k).subs(r,2))
print(json.dumps({"scope":"Post-exposure algebra and domain supplement; no action or author aggregate replay",
    "passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks),
    "elapsed_sec":time.monotonic()-started,"controls":checks,"values":values},indent=2))

