"""Focused corrected-window correspondence; no author aggregate execution."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUTS = ["post_author_sources_v3/KINETIC_PRIMITIVE_PHOTON_CONTROLS_v3.json"]
from pathlib import Path
import hashlib,json,time
import sympy as s
start=time.monotonic()
checks=[]
def zero(name,expr):
 value=s.factor(s.cancel(s.expand(expr)))
 ok=value==0
 checks.append({"name":name,"pass":bool(ok),"remainder":str(value)})
 if not ok:raise AssertionError(name+": "+str(value))
def truth(name,test):
 ok=bool(test);checks.append({"name":name,"pass":ok})
 if not ok:raise AssertionError(name)
eta,r=s.symbols("eta r",real=True,nonzero=True)
a=256/eta**8
T=lambda f:s.diff(f,eta)/a
lap=lambda f:s.diff(f,r,2)+2*s.diff(f,r)/r-6*f/r**2
P=eta**6*r**2/64;J=-2*P;Z=-4*r**2/eta
q=-5*eta**7/256;ell=-3*eta**7/256
F=s.Rational(2,5);R=eta**14/32768;E=eta**14/4096
Utrue=65536/(5*eta**14)
def ck(U):
 alpha=-6*ell/R
 beta=-q*(F/R+U)
 gamma=2/(R*a**2)
 delta=(-6*ell**2+F*q**2)/R-3+U*q**2
 epsilon=-(q*T(F)-E+R)/R+U*(T(q)+q**2)
 return alpha*T(P)+beta*T(J)+gamma*lap(P)+delta*P+epsilon*J
zero("true kinetic combination",ck(Utrue))
zero("wrong kinetic combination is 3P",ck(0)-3*P)
res=T(ck(0))+lap(Z)/a**2
zero("wrong strong residual",res-s.Rational(9,8192)*eta**13*r**2)
zero("strong moment density with physical time measure",-a*r**2*res+s.Rational(9,32)*eta**5*r**4)
def beta(j):
 return s.Rational(s.factorial(8+j)*s.factorial(8),s.factorial(17+j))
temporal=sum(s.binomial(5,j)*(-4)**(5-j)*beta(j) for j in range(6))
radial=sum(s.binomial(4,j)*beta(j) for j in range(5))
moment=s.factor(-s.Rational(9,32)*temporal*radial)
truth("moment positive on corrected support",moment>0)
zero("corrected exact beta moment",moment-s.Rational(827093,50599790841600))
folder=Path(__file__).resolve().parent
path=folder/AUDIT_INPUTS[0];raw=path.read_bytes()
truth("v3 result exact source pin",hashlib.sha256(raw).hexdigest()=="fc0ddaa78b802ab6753099f2c2cfcb8841153d6b24152033c340fe32560450c3")
result=json.loads(raw)
wrong=result["moments"]["wrong_canonical"]
for label in ["strong_moment","field_moment","primitive_moment"]:
 zero("author "+label+" matches independent beta moment",s.Rational(wrong[label])-moment)
normpsi=s.Rational(wrong["primitive_L1_bound_psi"])
normz=s.Rational(wrong["primitive_L1_bound_z"])
truth("author source budgets positive",normpsi>0 and normz>0)
radius=s.Rational(wrong["primitive_uniform_radius"])
zero("source radius formula",radius-moment/(2*(normpsi+normz)))
A20=4*s.sqrt(15*s.pi)/9
pixel_radius=s.simplify(radius/A20)
print(json.dumps({"scope":"Post-exposure corrected-window strong moment and source-result arithmetic; no aggregate replay",
 "passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks),
 "controls":checks,"elapsed_sec":time.monotonic()-start,
 "values":{"moment":str(moment),"moment_decimal":str(s.N(moment,25)),
 "author_mononomial_L1_sum":str(normpsi+normz),
 "coefficient_radius":str(radius),"coefficient_radius_decimal":str(s.N(radius,25)),
 "common_full_sky_pointwise_radius":str(pixel_radius),"common_full_sky_pointwise_radius_decimal":str(s.N(pixel_radius,25)),
 "amplitude_rule":"m and sufficient radii scale by absolute common signal amplitude; numerical radii are unit-template values"}},
 indent=2))

