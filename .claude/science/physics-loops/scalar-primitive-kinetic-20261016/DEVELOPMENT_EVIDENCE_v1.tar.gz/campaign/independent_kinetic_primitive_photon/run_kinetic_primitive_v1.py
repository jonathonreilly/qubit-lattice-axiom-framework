#!/usr/bin/env python3
"""Bounded staged execution with source identities and complete actual streams."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "DERIVATION_BEFORE_CODE_v1.md",
    "NEUTRAL_CONTRACT_v1.json",
    "PRE_CODE_FREEZE_v1.json",
    "check_kinetic_primitive_v1.py",
    "run_kinetic_primitive_v1.py",
]
AUDIT_GENERATED_INPUT_PATHS = ["ATTEMPT01_moment.stdout.txt"]
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

own=Path(__file__).resolve().parent
def binding(n):
    raw=(own/n).read_bytes()
    return {"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)}
before={n:binding(n) for n in AUDIT_INPUT_PATHS}
names=[f"ATTEMPT01_{c}.{e}.txt" for c in ["adjoints","moment","bounds"]
       for e in ["stdout","stderr"]]+["INDEPENDENT_RUN_v1.json"]
assert not any((own/n).exists() for n in names),"Refusing to overwrite attempts"
env=os.environ.copy();env["PYTHONDONTWRITEBYTECODE"]="1"
record={"stage":"Independent operator calculation before author exposure",
    "started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_bindings_before":before,"timeout_per_process_seconds":120,
    "bytecode_disabled":True,"python":sys.executable,"attempts":[]}
for case in ["adjoints","moment","bounds"]:
    command=[sys.executable,"-B",str(own/"check_kinetic_primitive_v1.py"),case]
    generated={n:binding(n) for n in AUDIT_GENERATED_INPUT_PATHS} if case=="bounds" else {}
    started=time.monotonic()
    try:
        result=subprocess.run(command,cwd=own,env=env,capture_output=True,timeout=120,check=False)
        stdout,stderr=result.stdout,result.stderr
        code=result.returncode;timeout=False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr=exc.stdout or b"",exc.stderr or b""
        code=None;timeout=True
    out=f"ATTEMPT01_{case}.stdout.txt";err=f"ATTEMPT01_{case}.stderr.txt"
    (own/out).write_bytes(stdout);(own/err).write_bytes(stderr)
    item={"case":case,"command":command,"elapsed_seconds":time.monotonic()-started,
          "exit_code":code,"timed_out":timeout,"stdout":out,"stderr":err,
          "stdout_binding":binding(out),"stderr_binding":binding(err),
          "generated_inputs":generated}
    try:
        data=json.loads(stdout)
        item.update({"passed":data["passed"],"failed":data["failed"]})
    except (json.JSONDecodeError,KeyError,TypeError):
        item["result_parse"]="No complete expected JSON"
    record["attempts"].append(item)
    print(json.dumps(item),flush=True)
record["source_bindings_after"]={n:binding(n) for n in AUDIT_INPUT_PATHS}
record["sources_unchanged"]=record["source_bindings_before"]==record["source_bindings_after"]
record["finished_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(own/"INDEPENDENT_RUN_v1.json").write_text(json.dumps(record,indent=2)+"\n")
print("run_sha256="+binding("INDEPENDENT_RUN_v1.json")["sha256"],flush=True)
raise SystemExit(0 if record["sources_unchanged"] and all(a["exit_code"]==0
    and a.get("failed")==0 and not a["timed_out"] for a in record["attempts"]) else 1)

