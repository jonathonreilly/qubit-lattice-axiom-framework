import sympy as s,json
AUDIT_TIMEOUT_SEC=120
eta,r,u,u0,c=s.symbols('eta r u u0 c',real=True)
checks=[]
def eq(n,a,b=0):
 ok=s.simplify(a-b)==0;checks.append({'name':n,'pass':bool(ok)});assert ok,n
F=eta**3*r**2+eta*r**4
hat=F.subs(eta,u-r)
eq('reception derivative',s.diff(hat,u),s.diff(F,eta).subs(eta,u-r))
eq('cone tangent',s.diff(hat,r),(s.diff(F,r)-s.diff(F,eta)).subs(eta,u-r))
eq('equal-time spatial derivative',s.diff(hat,r)+s.diff(hat,u),s.diff(F,r).subs(eta,u-r))
# l=2 radial coefficients; angular multiplier suppressed.
D=lambda z:s.diff(z,r)+s.diff(z,u)
lap=s.diff(F,r,2)+2/r*s.diff(F,r)-6/r**2*F
eq('equal-time Laplacian',D(D(hat))+2/r*D(hat)-6/r**2*hat,lap.subs(eta,u-r))
# Regular polynomial radial profile; local smoothness away from origin is sufficient.
f=r**2
for power in [1,2]:
 w=(eta+r-u0)**power*f; wh=w.subs(eta,u-r)
 lens=2*s.integrate((r-c)/(r*c)*wh.subs(r,c),(c,0,r))
 eq('Volterra inverse '+str(power),s.diff(r**2*s.diff(lens,r),r)/2,wh)
 eq('same single-cone lens '+str(power),lens.subs(u,u0))
 eq('same cone field '+str(power),wh.subs(u,u0))
 I=-2*s.integrate(s.diff(w,eta).subs({eta:u-c,r:c}),(c,0,r))
 eq('isolated ISW derivative '+str(power),s.diff(I,r),-2*s.diff(wh,u))
 if power==1:
  eq('lensing-only first jet',s.diff(wh,u).subs(u,u0),f)
  eq('kinematic endpoint cancellation',I+2*r**3/3)
 else:
  eq('joint first jet zero',s.diff(wh,u).subs(u,u0))
  eq('joint redshift unchanged',I.subs(u,u0))
  eq('second jet nonzero',s.diff(wh,u,2).subs(u,u0),2*f)
  eq('redshift drift sees second jet',s.diff(I,u).subs(u,u0),-4*r**3/3)
# Redshift drift in common-coordinate registered chart:
# endpoint function B(u,r) includes observer/source potentials and velocities.
B=u**2*r+u*r**2; p=u**3*r**2
I=-2*s.integrate(s.diff(p,u).subs(r,c),(c,0,r)); Dz=B+I
eq('drift endpoint obstruction',s.diff(Dz,u,r),s.diff(B,u,r)-2*s.diff(p,u,2))
# A higher power can be invisible even to first drift, absent dynamics.
w3=(u-u0)**3*r**2;I3=-2*s.integrate(s.diff(w3,u).subs(r,c),(c,0,r))
eq('cubic unchanged redshift',I3.subs(u,u0));eq('cubic unchanged drift',s.diff(I3,u).subs(u,u0))
eq('cubic third normal jet',s.diff(w3,u,3).subs(u,u0),6*r**2)
print(json.dumps({'scope':'Independent geometric identities, not full-action counterexamples','passed':len(checks),'failed':0,'checks':checks},indent=2))
