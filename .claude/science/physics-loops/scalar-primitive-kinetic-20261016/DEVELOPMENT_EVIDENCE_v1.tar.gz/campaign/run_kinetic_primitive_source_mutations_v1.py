"""Actual canonical-source mutations; each bounded and preserved independently."""
import concurrent.futures,datetime,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/Users/jonBridger/.codex/worktrees/scalar-primitive-kinetic-20261016/New Axioms Lets Go')
OUT=Path('/Users/jonBridger/.codex/campaigns/observations-backward-derivation-24h-20261015/primitive-canonical-mutations-v1')
PACK=Path('/Users/jonBridger/.codex/worktrees/observations-backward-derivation-24h-20261015/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-derivation-24h-20261015')
OUT.mkdir(parents=True,exist_ok=True)
core=(ROOT/'scripts/scalar_primitive_kinetic_core.py').read_text()
bound=(ROOT/'scripts/scalar_primitive_kinetic_bound.py').read_text()
mutations=[
('spatial_Z_sign','core','wz=canon(-Lap(lam)/a**2)','wz=canon(Lap(lam)/a**2)'),
('L_radial_divergence','core','s.diff(f,r)+2*f/r','s.diff(f,r)'),
('D_time_jacobian','core','(s.diff(a,eta)/a-2/r)*f','(-2/r)*f'),
('latent_sign','core','b=canon(-v/K)','b=canon(v/K)'),
('redshift_path_factor','core','z=canon(Y-2*I1)','z=canon(Y-I1)'),
('outer_radial_order','core','hp=canon(Ddag(r*r*(Ddag(cp)/2-T(a*cy))))','hp=canon(r*r*Ddag(Ddag(cp)/2-T(a*cy)))'),
('time_measure','core','mu=a*r*r','mu=r*r'),
('d_product_rule','core','cp=canon(wp-wj-T(d*g)+e*g)','cp=canon(wp-wj-d*T(g)+e*g)'),
('path_product_rule','core','Ddag(cp)/2-T(a*cy)','Ddag(cp)/2-a*T(cy)'),
('spherical_Laplacian','core','-6*f/r**2','-5*f/r**2'),
('Bernstein_conversion','bound','Q(comb(i,k),comb(n,k))','Q(comb(i,k),comb(n,k)+1)'),
('Bernstein_cell_area','bound','area/=4','area/=2'),
('Bernstein_false_upper','bound','sum((abs(z) for row in b for z in row),Q(0))','abs(sum((z for row in b for z in row),Q(0)))')]
prepared=[]
for name,target,old,new in mutations:
 s=core if target=='core' else bound
 assert s.count(old)==1,(name,s.count(old))
 d=OUT/name;d.mkdir(exist_ok=False)
 changed=s.replace(old,new)
 (d/'candidate.py').write_text(changed)
 if target=='bound':(d/'base_core.py').write_text(core)
 entry='import json,candidate\nunit,_=candidate.run_checks()\nprint(json.dumps(unit,sort_keys=True))\nraise SystemExit(int(unit["failed"]>0))\n' if target=='core' else 'import json,candidate,base_core\nbase,context=base_core.run_checks()\nassert base["failed"]==0\nunit=candidate.run_checks(context)\nprint(json.dumps(unit,sort_keys=True))\nraise SystemExit(int(unit["failed"]>0))\n'
 (d/'run.py').write_text(entry)
 prepared.append({'name':name,'target':target,'old':old,'new':new,'source':str(d/'candidate.py'),'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'entry_sha256':hashlib.sha256(entry.encode()).hexdigest()})
freeze={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonical_core':hashlib.sha256(core.encode()).hexdigest(),'canonical_bound':hashlib.sha256(bound.encode()).hexdigest(),'timeout_each':120,'parallelism':2,'cases':prepared,'unmodified_controls':'Canonical82/78/42 all zero failures, source-bound before mutations'}
(PACK/'KINETIC_PRIMITIVE_MUTATION_FREEZE_v1.json').write_text(json.dumps(freeze,indent=2)+'\n')
def run(item):
 d=Path(item['source']).parent;t=time.monotonic()
 try:
  r=subprocess.run(['/usr/local/bin/python3','-B','run.py'],cwd=d,capture_output=True,timeout=120,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  so,se,rc,timed=r.stdout,r.stderr,r.returncode,False
 except subprocess.TimeoutExpired as e:so,se,rc,timed=e.stdout or b'',e.stderr or b'',None,True
 (d/'stdout.json').write_bytes(so);(d/'stderr.txt').write_bytes(se)
 row={**item,'elapsed_seconds':time.monotonic()-t,'exit_code':rc,'timed_out':timed,'stdout_sha256':hashlib.sha256(so).hexdigest(),'stderr_sha256':hashlib.sha256(se).hexdigest()}
 try:
  z=json.loads(so);row.update(passed=z['passed'],failed=z['failed'],false_controls=[q['name'] for q in z['checks'] if not q['pass']],detected=z['failed']>0 and rc==1 and not se)
 except (ValueError,KeyError):row.update(detected=False,result_error='No complete check output; not counted as scientific rejection')
 (d/'receipt.json').write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps({k:row[k] for k in ['name','detected','exit_code','elapsed_seconds']}),flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,prepared))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual canonical-source mutations; no empirical tests','detected':sum(r['detected'] for r in results),'total':len(results),'cases':results}
(PACK/'KINETIC_PRIMITIVE_SOURCE_MUTATIONS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'detected':result['detected'],'total':len(results)}),flush=True)
