import json,candidate,base_core
base,context=base_core.run_checks()
assert base["failed"]==0
unit=candidate.run_checks(context)
print(json.dumps(unit,sort_keys=True))
raise SystemExit(int(unit["failed"]>0))
