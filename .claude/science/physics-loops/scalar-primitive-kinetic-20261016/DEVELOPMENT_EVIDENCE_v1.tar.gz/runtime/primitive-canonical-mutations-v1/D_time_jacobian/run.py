import json,candidate
unit,_=candidate.run_checks()
print(json.dumps(unit,sort_keys=True))
raise SystemExit(int(unit["failed"]>0))
