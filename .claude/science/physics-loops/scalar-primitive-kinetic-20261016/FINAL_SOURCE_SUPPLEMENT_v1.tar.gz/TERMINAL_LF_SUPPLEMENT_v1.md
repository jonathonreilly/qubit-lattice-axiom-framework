# Terminal-LF source correspondence supplement

The three announced changes are exactly one removed terminal LF each. Every changed file equals its frozen original.rstrip(b"\n")+b"\n". The note body is unchanged, and both changed Python ASTs are identical with location attributes excluded. The primary runner and action helper are byte-identical. No mathematical source change was found.

This supplement preserves the earlier canonical source snapshots, report and manifest. All 15 files bound by the earlier manifest remain unchanged. No aggregate was rerun, author code executed, or new mathematics checked. Current output/cache regeneration is outside this supplement; its new integrity closure still needs binding after regeneration.

| File | Current SHA256 |
|---|---|
| docs/SCALAR_PRIMITIVE_KINETIC_NOTE_2026-10-16.md | 4a24a549df6b53f23768e67ca174638ed360ec18137b874f85b9307cae03dfc3 |
| scripts/scalar_primitive_kinetic_core.py | b7fff4c8f1df13adfd4cab76e452722edda848fc814d68af5f6b332df047dee5 |
| scripts/scalar_primitive_kinetic_bound.py | f4e3fbbdddb22d23a8611f60bdb7b7cbad064892c918318abdf07b6e75756c82 |
| scripts/scalar_primitive_kinetic.py | 978ab14363b55f759e867555dad5b15614056a7053caf4b33fb49abbec50475f |
| scripts/scalar_primitive_kinetic_action.py | 9ec86c25fb331f2f41bbed742305ea1e072cf58759c6fe62ec36115b72af10de |

TERMINAL_LF_BINDINGS_v1.json records exact before/after byte counts, hashes and comparisons. TERMINAL_LF_MANIFEST_v1.json binds this supplement and receipt. The old and new source bytes are reconstructibly related by the verified terminal-LF transformation. No root source, Git state or shared register was changed.
