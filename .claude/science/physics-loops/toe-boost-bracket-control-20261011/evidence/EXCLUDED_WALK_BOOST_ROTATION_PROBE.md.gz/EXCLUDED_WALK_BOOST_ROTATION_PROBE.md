# Boost/boost bracket and prepared-state rotation control for the excluded Weyl pair

Date: 2026-10-11. External bounded derivation, not a repository publication.

**Status:** proposed conditional mathematical result; author completion and
cold read recorded in boost_rotation/receipt.json, independent review
pending. The supplied walk, continuous clock, antisymmetric pair sector,
site exclusion, spatial coordinates and canonical symmetric energy placement
remain premises. No physical continuous rotation group, full Poincare
algebra, collision clock or gravitational dynamics is inferred.

The estimate is at the specified prepared states. No persistence of their
derivative or support bounds under excluded evolution is asserted.

## 1. Result and source boundary

For the dipoles D_a defined below, the complete boost/boost bracket is

\[
 i[D_a,D_b]
   =P\mathcal M^{\rm lat}_{ab}P
     +i\left(Q_a\partial_{K_b}-Q_b\partial_{K_a}\right),
 \qquad Q_a=|h_a\rangle\langle h|+|h\rangle\langle h_a|.
                                                        \tag{BR1}
\]

The two second-K-derivative contact terms cancel. The remaining first
derivatives in BR1 must be retained. The free first-order expression
\(\mathcal M^{\rm lat}\) has the exact periodic orbital coefficients
\(\sin k_a\cos k_a\) and face-spin coefficients \(\cos k_a\cos k_b\).
Its one-body formula is matched prior art, identified in Section 10.
The contact formula and quantitative globally projected comparison are the
new derivation here.

On smooth origin-cone free preparations \(\phi_\lambda\) with
\(|K|\le\lambda/4,\ |q|\le3\lambda/4,\ \|\phi_\lambda\|=1\), put

\[
 B_j=\lambda\|\partial_{K_j}\phi_\lambda\|,\qquad
 V_j=\lambda\|\partial_{q_j}\phi_\lambda\|,\qquad
 \chi_\lambda=P\phi_\lambda/\|P\phi_\lambda\|.
                                                        \tag{BR2}
\]

All norms include both normalized measures. For the specified smooth
positive-positive family in Section 8, \(B_j<60,\ V_j<2^{18}\).
With \(0<\lambda\le1/16\), the proof gives for all a,b

\[
 \boxed{\ 
 \|(i[D_a,D_b]-\mathcal M^{\rm chart}_{ab})\chi_\lambda\|
       \le 2^{17}\lambda^{3/2}.
 \ }                                                    \tag{BR3}
\]

Here \(\mathcal M^{\rm chart}\) is the ordinary orbital-plus-spin expression
in the origin chart, not an asserted global physical rotation generator.
A smooth periodic auxiliary comparator agrees with it exactly on these
prepared states. Both the global contact tail and the chart-boundary issue
are treated explicitly below. BR3 is a statewise norm estimate on the
derivative-bounded class, not an unrestricted L2 operator-norm limit.

The frozen sources used are:

| Source | SHA-256 | Role |
|---|---|---|
| EXCLUDED_WALK_BOOST_CURRENT_PROBE.md | 903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923 | Complete B1–B32 source freshly read; model, domain, contact blocks, global normalization and specified smooth ++ preparation |
| EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md | 79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe | Complete 190-line source freshly read; actual local density and energy dipole, not just its current formula |
| Published low-energy energy-current parent | 9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401 | Lines 1–175, 370–478 and 805–844 freshly read; supplied fibers, all-corner distinction, canonical dipole and projection caveat |
| ROOT_EXCLUDED_WALK_BOOST_CURRENT_REVIEW.md | c019d73e57462fd5e71ff3dc0552cc49fdcf02f604184e6c779ffc7e5dacd300 | Complete independent review of the frozen B source; not independent review of this new derivation |

Paths and precise reading/search coverage are bound in boost_rotation/.
The evolving boost/current draft at
d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929
is an identity guard and scope context only. Its time bounds are not used
as a theorem for this new bracket. No new external literature theorem is
invoked. Existing elementary Pauli, integration-by-parts and Sobolev
calculations are supplied explicitly.

## 2. Supplied Hilbert space, placement and common domain

Fix \(U=\{K\in\mathbb R^3:|K|<1/8\}\) inside the origin total-momentum
chart and use the full relative torus \(\mathbb T^3\), with measures
\(dK/(2\pi)^3\) and \(dq/(2\pi)^3\). The stated K supports are compact
in this chart for the entire range \(0<\lambda\le1/16\).
The spin space is \(\mathbb C^2\otimes\mathbb C^2\), with swap \(\mathsf S\).
Antisymmetry means
\(\psi(K,-q)=-\mathsf S\psi(K,q)\). The normalized constant singlet is c.
Set

\[
 C=|c\rangle\langle c|,\quad P=I-C,\quad
 k_1=K/2+q,\quad k_2=K/2-q,
\]
\[
 h_i=\sigma_i\cdot\sin k_i,\quad H_0=h_1+h_2,\quad
 H_D=PH_0P,\quad h=H_0c,\quad h_a=\partial_{K_a}h .
                                                        \tag{BR4}
\]

P is one global contact projection in each full-torus fiber, not one
projection per cone. No exchange multiplicity or half-torus normalization
is inserted. The trigonometric symbols are periodic even where their
displayed lifted arguments cross a torus face.

The selected local density and energy first moment are

\[
 e_x^0=\tfrac12\sum_{i=1}^2\{\Pi_{i,x},h_i\},\qquad
 e_x=Pe_x^0P,\qquad
 D_a=PD_{0,a}P,\quad
 D_{0,a}=\tfrac12\sum_{i=1}^2\{X_{i,a},h_i\}.
                                                        \tag{BR5}
\]

These agree with the finite-spatial-support first moments. Our common
test domain consists of smooth antisymmetric sections, compactly
supported in U, smooth periodic in q, and lying in P. D_a preserves
this domain, so both products in [D_a,D_b] are defined. Ambient D0 acts
on the corresponding domain without the P restriction.

The individual derivatives are
\(X_{1,a}=i(\partial_{K_a}+\partial_{q_a}/2)\) and
\(X_{2,a}=i(\partial_{K_a}-\partial_{q_a}/2)\). Thus

\[
 D_{0,a}=iH_0\partial_{K_a}
       +\tfrac i2(h_1-h_2)\partial_{q_a}
       +i\partial_{K_a}H_0.                             \tag{BR6}
\]

All its coefficients are smooth periodic in q. Products of dipoles
map H2 to L2 continuously on compact K supports; after the cancellation
below their commutator expression extends continuously H1 to L2.
The latter is the extension of the common-core expression, not a claim
that each individual product is defined on every H1 section.
No essential self-adjointness or exponentiation of the dipoles is assumed.

## 3. Free bracket, signs and spin term

For one body let \(s_j=\sin k_j,\ c_j=\cos k_j\) in this section only, and
write \(d_a=i(h\partial_a+h_{,a}/2)\), with \(h=\sigma\cdot s\).
For a different pair of axes a,b, direct multiplication gives

\[
 [d_a,d_b]
  =-\tfrac12\{h,h_{,a}\}\partial_b
   +\tfrac12\{h,h_{,b}\}\partial_a
   -\tfrac14[h_{,a},h_{,b}].                            \tag{BR7}
\]

The h-squared second derivatives cancel. The constant second-symbol
derivatives cancel by equality of mixed derivatives. Pauli algebra gives
\(\{h,h_{,a}\}/2=s_ac_a I\) and
\([h_{,a},h_{,b}]=2i\epsilon_{abd}\sigma_dc_ac_b\).
Operators on the two individual particles commute. Consequently

\[
 i[D_{0,a},D_{0,b}]=\mathcal M^{\rm lat}_{ab}
 =-i\sum_{i=1}^2
   (j_{i,a}\partial_{k_{i,b}}-j_{i,b}\partial_{k_{i,a}})
  +\tfrac12\epsilon_{abd}
      \sum_{i=1}^2\sigma_{i,d}\cos k_{i,a}\cos k_{i,b},
\quad j_{i,a}=\sin k_{i,a}\cos k_{i,a}.                  \tag{BR8}
\]

Repeated d is summed; a,b are fixed. The a=b expressions are zero.
The sign is the convention \([D_a,D_b]=-i\mathcal M_{ab}\).
At the origin the spin term tends to
\(\epsilon_{abd}(\sigma_{1,d}+\sigma_{2,d})/2\).

In K,q coordinates define

\[
 g_a=\sin K_a\cos(2q_a),\qquad
 w_a=\tfrac12\cos K_a\sin(2q_a),\qquad
 S^{\rm lat}_{ab}=
 \tfrac12\epsilon_{abd}\sum_i\sigma_{i,d}\cos k_{i,a}\cos k_{i,b}.
\]

Then the fully periodic free expression is

\[
 \mathcal M^{\rm lat}_{ab}
 =-i(g_a\partial_{K_b}-g_b\partial_{K_a}
                   +w_a\partial_{q_b}-w_b\partial_{q_a})
      +S^{\rm lat}_{ab}.                               \tag{BR9}
\]

These orbital vector fields have zero divergence for a different from b.
Their periodicity, not an assumption of continuous lattice rotations,
justifies the q integration by parts on the full common core.

## 4. Exact compression defect

The singlet has zero expectation of H0. In BR6, the fiber adjoint of
\(i(h_1-h_2)\partial_{q_a}/2+i\partial_{K_a}H_0\) is
\(i(h_1-h_2)\partial_{q_a}/2\), which annihilates c.
Acting on c before taking the adjoint instead gives ih_a. Thus the
off-diagonal contact blocks are, including every K derivative,

\[
 CD_{0,a}P\psi=ic\langle h,\partial_{K_a}\psi\rangle,\qquad
 PD_{0,a}C(cf)=i\partial_{K_a}(hf).                      \tag{BR10}
\]

Expand the two compressed products:

\[
 [D_a,D_b]
  =P[D_{0,a},D_{0,b}]P-PD_{0,a}CD_{0,b}P
                                +PD_{0,b}CD_{0,a}P.
\]

On an allowed test section their last two terms are exactly

\[
 \partial_{K_a}\bigl(h\langle h,\partial_{K_b}\psi\rangle\bigr)
 -\partial_{K_b}\bigl(h\langle h,\partial_{K_a}\psi\rangle\bigr).
                                                        \tag{BR11}
\]

Expanding BR11 gives \(Q_a\partial_{K_b}\psi-
Q_b\partial_{K_a}\psi\); the two copies of
\(h\langle h,\partial_{K_aK_b}\psi\rangle\) cancel.
There is no constant contact term because the inner blocks in BR10
contain only a first derivative of the state. This proves BR1.
As a consistency check,
\(Q_a=\partial_{K_a}|h\rangle\langle h|\), so
\(\partial_{K_b}Q_a-\partial_{K_a}Q_b=0\); the displayed correction
in i[D_a,D_b] has the expected symmetry on the common domain.

The exact form factors are

\[
 h=2\sum_j\cos(K_j/2)\sin q_j\,\sigma_{1,j}c,\qquad
 h_a=-\sin(K_a/2)\sin q_a\,\sigma_{1,a}c.                \tag{BR12}
\]

They lie in P. In particular Q_a annihilates c. BR1 does not assert
that the compressed angular expression is conserved by H_D or closes
the other rotation/boost brackets.

## 5. Ordinary chart expression and the torus issue

On the fundamental cell \(q\in(-\pi,\pi)^3\), the ordinary origin-chart
orbital-plus-spin expression is

\[
 \mathcal M^{\rm chart}_{ab}
 =-i(K_a\partial_{K_b}-K_b\partial_{K_a}
                   +q_a\partial_{q_b}-q_b\partial_{q_a})
  +\Sigma_{ab},\qquad
 \Sigma_{ab}=\tfrac12\epsilon_{abd}(\sigma_{1,d}+\sigma_{2,d}).
                                                        \tag{BR13}
\]

The q coordinates in BR13 are bounded representatives, not smooth global
functions on the torus. This gives a well-defined H1-to-L2 expression
on that chosen cell. For a different from b it is symmetric on smooth
periodic sections with compact K support: a coefficient q_a is independent
of its differentiation variable q_b, whose two periodic face terms
cancel, and conversely. This observation does not make it a smooth
global rotation vector field or establish a group representation.

There is a concrete loss of the common smooth/H1 core. Choose a nonzero
smooth radial K envelope G, compact in U, and
\(\psi=G(K)c\cos q_a\). This is antisymmetric and lies in P.
For a different from b, its q contribution under BR13 is
\(-iG(K)c\,q_b\sin q_a\). Its two q_b face traces differ by
\(-2\pi iG(K)c\sin q_a\). Hence the image is not in H1 of the torus.
The expression cannot be silently treated as preserving the full
periodic dipole core. This witness concerns this chart expression and
this core; it is not an obstruction to every restricted domain or
approximate rotation construction.

For a smooth periodic auxiliary comparison, fix a smooth even cutoff
\(\rho(t)=1\) on \(|t|\le1\) and \(\rho(t)=0\) on \(|t|\ge2\) inside
\((-\pi,\pi)\), and put \(\tau(t)=t\rho(t)\), periodically extended.
For definiteness, with \(\theta(u)=e^{-1/u}\) for u>0 and zero otherwise,

\[
 \rho(t)={\theta(4-t^2)\over\theta(4-t^2)+\theta(t^2-1)}.
\]

Define the auxiliary operator

\[
 \mathcal M^{\rm aux}_{ab}
 =-i(K_a\partial_{K_b}-K_b\partial_{K_a}
                +\tau(q_a)\partial_{q_b}-\tau(q_b)\partial_{q_a})
       +\Sigma_{ab}.                                   \tag{BR14}
\]

It preserves the common smooth domain and antisymmetry. Its q orbital
field has zero divergence, and \(\Sigma_{ab}c=0\). Fiber integration
therefore gives
\(C\mathcal M^{\rm aux}\psi=\mathcal M^K C\psi\), where
\(\mathcal M^K=-i(K_a\partial_{K_b}-K_b\partial_{K_a})\).
Also \(\mathcal M^{\rm aux}(c\alpha)=c\mathcal M^K\alpha\).
Thus it commutes with P on this domain.

On a free packet supported in \(|q|<3\lambda/4<1\), BR14 and BR13
agree. They also agree on its global contact subtraction \(c\alpha(K)\),
since that subtraction has no q derivative and its spin term vanishes.
Consequently

\[
 \mathcal M^{\rm aux}_{ab}\chi_\lambda
       =\mathcal M^{\rm chart}_{ab}\chi_\lambda
 \quad\hbox{exactly}.                                  \tag{BR15}
\]

The image in BR15 is smooth periodic: its nonconstant q part is supported
away from the faces. No continuous rotation symmetry, global Lie-group
action or uniqueness of this auxiliary continuation is claimed.

## 6. Quantitative free and contact estimates

Let \(0<\lambda\le1/16\) and use the support in BR2. Define

\[
 \nu_1=\sqrt{9/(128\pi^2)},\qquad \eta=\nu_1\lambda^{3/2}.
                                                        \tag{BR16}
\]

The relative support's normalized volume is at most \(\eta^2\).
Write \(\alpha(K)=\langle c,\phi_\lambda(K)\rangle\) and
\(n=\|P\phi_\lambda\|\). Cauchy–Schwarz, also for a K derivative, gives

\[
 \|\alpha\|\le\eta,\quad
 \|\partial_{K_j}\alpha\|\le\eta B_j/\lambda,\quad
 n^2=1-\|\alpha\|^2\ge1-\eta^2,\qquad
 \chi_\lambda=(\phi_\lambda-c\alpha)/n.                  \tag{BR17}
\]

This is one global normalization over K and q. In particular n is
not differentiated in K. The contact subtraction occupies the full torus.

Put \(V_{ab}=\mathcal M^{\rm lat}_{ab}-\mathcal M^{\rm aux}_{ab}\);
the symbol V_ab is an operator here, distinct from the derivative norms
V_j in BR2. On the free support, elementary sine/cosine remainders give

\[
 |g_j-K_j|\le {109\over384}\lambda^3<\lambda^3/3,\qquad
 |w_j-q_j|\le {39\over128}\lambda^3<\lambda^3/3,
\]
\[
 \|S^{\rm lat}_{ab}-\Sigma_{ab}\|
       \le {49\over128}\lambda^2 .                     \tag{BR18}
\]

For the first bound use \(|K_j|^3/6+2|K_j|q_j^2\).
For the second use \(2|q_j|^3/3+K_j^2|q_j|/2\).
For the third use
\(|1-\cos k_{i,a}\cos k_{i,b}|
\le(k_{i,a}^2+k_{i,b}^2)/2\) and \(|k_i|\le7\lambda/8\).
The two spin terms each have the prefactor 1/2. Therefore, with

\[
 C_{ab}={49\over128}
             +{B_a+B_b+V_a+V_b\over3},
 \qquad \|V_{ab}\phi_\lambda\|\le C_{ab}\lambda^2.        \tag{BR19}
\]

This estimates the actual state derivatives, not merely the multiplier
symbols.

For the global tail set \(r_j=g_jc\), whose fiber mean is zero and
whose norm is at most \(\lambda/4\). Since the auxiliary spin term
annihilates c and the q derivatives of c alpha vanish,

\[
 PV_{ab}(c\alpha)
   =-i r_a\partial_{K_b}\alpha
      +i r_b\partial_{K_a}\alpha+s_{ab}\alpha,\qquad
 s_{ab}=S^{\rm lat}_{ab}c\in P.                         \tag{BR20}
\]

The constant K coefficients of the auxiliary expression disappear under
the outer P. If \(C_j=\cos(K_j/2)\), \(T_j=\sin(K_j/2)\), then

\[
 s_{ab}=-\epsilon_{abd}\sigma_{1,d}c
 (C_aT_b\cos q_a\sin q_b+T_aC_b\sin q_a\cos q_b).
\]

Thus \(\|s_{ab}\|\le|T_a|+|T_b|\le\lambda/4\), uniformly on the full
torus, and

\[
 \|PV_{ab}(c\alpha)\|
 \le\eta\left({B_a+B_b\over4}+{\lambda\over4}\right).    \tag{BR21}
\]

No corner-support assumption is applied to that output.

Finally, \(\|h\|\le3,\ \|h_j\|\le\lambda/8\) on the full torus,
whereas on the free input support
\(|h(q)|\le3\lambda/2,\ |h_j(q)|\le3\lambda^2/32\).
For any supported f these yield

\[
 \|Q_j f\|
  \le {15\over32}\lambda^2\eta\|f\|,\qquad
 \|(Q_a\partial_{K_b}-Q_b\partial_{K_a})\phi_\lambda\|
 \le {15\over32}\lambda\eta(B_a+B_b).                   \tag{BR22}
\]

The same uniform fiber estimates integrate over K. Since Q_j c=0,
they apply after global projection by dividing by n.

## 7. Prepared-state theorem with every parameter explicit

Combine BR1, commutation of P with BR14, and BR17–BR22. For every
normalized smooth origin-cone preparation in BR2, not necessarily a
positive band vector, the result is

\[
 \boxed{\ 
 \|(i[D_a,D_b]-\mathcal M^{\rm aux}_{ab})\chi_\lambda\|
 \le
 {C_{ab}\lambda^2+
 \nu_1\lambda^{3/2}
   \left((B_a+B_b)/4+\lambda/4+
                      (15/32)\lambda(B_a+B_b)\right)
  \over \sqrt{1-\nu_1^2\lambda^3}} .
 \ }                                                    \tag{BR23}
\]

BR15 identifies this with the chart-expression residual on the prepared
states. All norms and normalizations are global direct-integral ones.
For a=b the exact residual is zero; the uniform estimate is harmless.
For derivative norms bounded independently of lambda this is
O(lambda^(3/2)), in particular o(1) and o(lambda).
It also bounds every normalized test-vector matrix element by
Cauchy–Schwarz. It does not remove the derivative premises.

## 8. The specified smooth, normalizable ++ family

Use exactly the origin family B25–B29 from the frozen boost/current
source. Its K envelope F is the normalized convolution of the L2-normalized
product of \(p(8\sqrt3\,\kappa_j)\), where
\(p(t)=(1-t^2)^2\) on \(|t|<1\) and zero outside, with the normalized
smooth radial bump proportional to
\(\exp[-1/(1-512^2|y|^2)]\) on \(|y|<1/512\).
It obeys \(\|F\|=1,\ |\kappa|\le65/512<1/4\) on its support and
\(\|\partial_{\kappa_j}F\|\le192/7\).
The relative envelope is the positive L2 normalization of

\[
 f(x)\ \propto\
 \exp\!\left[-{1\over (|x|-5/8)(3/4-|x|)}\right],
 \qquad 5/8<|x|<3/4,                                  \tag{BR24}
\]

extended by zero. It is smooth, radial and even. Let

\[
 u_\lambda=(2\pi)^3\lambda^{-3}
      F(K/\lambda)f(q/\lambda)\Pi_{++}(K,q)c,\qquad
 Z_\lambda=\|u_\lambda\|,\quad \phi_\lambda=u_\lambda/Z_\lambda.
                                                        \tag{BR25}
\]

The prefactor compensates both normalized torus measures and both
three-dimensional rescalings. The packet is a normalizable antisymmetric
direct-integral state. Both individual momenta lie between lambda/2 and
7lambda/8 in length, their positive sine energies A,B are at least
3lambda/8, and their sum lies in [lambda,2lambda].
Its singlet ++ weight lies in [1/4,1/2], hence
\(Z_\lambda\in[1/2,1/\sqrt2]\). These are the same pointwise bounds and
global normalization proved in B26–B28, whose full argument was read.

For completeness the needed additional q derivative has an explicit
constant. Put \(r_0=11/16,\ u=16(r-r_0)\) and
\(g(u)=\exp[-256/(1-u^2)]\). On \(|u|\le1/32\),
\(g(u)^2\ge e^{-513}\), so
\(\int_{-1}^1g^2du\ge e^{-513}/16\). With
\(y=1/(1-u^2)\ge1\),
\[
 |g'(u)|^2=512^2u^2y^4e^{-512y}
       \le512^2e^{-512},
\]
because \(y^4e^{-512y}\) decreases for y>=1.
Consequently
\[
 {\int(g')^2\over\int g^2}\le32e\,512^2<96\,512^2.
\]
Radial symmetry, \(5/8\le r\le3/4\), and dr=du/16 now give

\[
 \|\partial_{x_j}f\|^2
  ={1\over3}{\int r^2|g_r'|^2dr\over\int r^2g^2dr}
  <{1\over3}{36\over25}\,16^2\,96\,512^2
   ={18\over25}2^{32}<2^{32}.                          \tag{BR26}
\]

The elementary inequality e<3 follows, for example, by bounding the
exponential series tail after 1+1 by a geometric series.
For a positive Pauli projector,
\(\|\partial_{q_j}\Pi_+\|\le1/(2A)\), and similarly with B.
The product derivative therefore obeys
\(\lambda\|\partial_{q_j}\Pi_{++}\|\le8/3\).
Using the one global Z_lambda gives

\[
 B_j\le384/7+8/3<60,\qquad
 V_j\le2\|\partial_{x_j}f\|+16/3<2^{18}.                \tag{BR27}
\]

All higher derivatives exist for each positive lambda, so the actual
projected state belongs to the commutator's common domain. Its energy
expectation remains in [lambda/2,3lambda] by B30; this does not assert
spectral support of the projected state.

In BR23 use \(B_a+B_b\le120,\ V_a+V_b\le2^{19}\),
\(\nu_1<1/4,\ n\ge1/2,\ \sqrt\lambda\le1/4\).
The resulting coefficient of lambda^(3/2) is at most

\[
 2\left[
 {1\over4}\left({49\over128}+{120+2^{19}\over3}\right)
 +{1\over4}\left(30+{1\over64}+{15\over32}{120\over16}\right)
 \right]<2^{17}.                                      \tag{BR28}
\]

This proves BR3 with conservative explicit constants and with the
original specified smooth packet, not a delta direction or fixed K fiber.

## 9. Corners, global tail and scope

The preparation before projection occupies only the origin cone.
The contact subtraction is constant in q and therefore occupies the
whole torus, including all seven other relative corners. BR20–BR22
use full-torus norms of its outputs; its q derivative is zero, rather
than being assumed confined to the origin.

For a genuinely populated different relative corner C in {0,pi}^3,
write q=C+x and \(\varepsilon_j=\cos C_j=\pm1\). The two individual
cone offsets are K/2+x and K/2-x. Their j=sin(k)cos(k) orbital
coefficients have the same leading offsets, but BR8's leading spin is
\[
 \tfrac12\epsilon_{abd}\varepsilon_a\varepsilon_b
                   (\sigma_{1,d}+\sigma_{2,d}).
                                                        \tag{BR29}
\]
It is the spin in that reflected cone frame; the origin spin cannot
be substituted uniformly at all corners. The ordinary q coordinate
in BR13 is likewise not the offset x at another corner. Distinct
total-momentum corners are outside the chosen K chart. Neither the
projection nor low total energy erases these distinctions.

One may construct additional smooth periodic patch comparators, but their
matching, corner spin and derivative hypotheses would have to be stated.
BR3 is only the origin preparation theorem. The failure of the unrestricted
chart expression to preserve H1 does not refute BR3 or an appropriately
specified other-domain construction.

The current and boost/current estimates from the parent do not by
themselves control this boost/boost residual at evolved states. The new
comparison uses q as well as K derivatives, and its global-tail estimate
uses the exact prepared-state decomposition. A norm-only approximation,
or a time interval justified for a different bracket, cannot replace
these premises. No fixed or growing time result is asserted here.

## 10. Prior art, controls and unresolved work

The pinned-main search at a13caa4885f547c8d206265b031ba7649e539fd9
is preserved in boost_rotation/prior_art_search.log. The complete
2026-09-25 note whose title begins “The walk carries an exact boost
charge” was read. Its T3 is matching prior art for BR7–BR9 for one
free walker, and hence for the additive free pair. Its T4 already records
the reflected corner spin. Its scope explicitly excludes excluded records;
its long-wave comparison is formal and does not supply this projected
statewise norm theorem or the torus-domain argument.

The complete 2026-05-30 free Dirac Poincare representation note was also
read. Its supplied continuum free-field/mass-shell algebra is context,
not a proof for this excluded lattice pair or its compressed placement.
The remaining displayed search hits concern coin-frame rotations, other
free carriers, scalar or source conventions, indexes and historical
methodology. Their complete source notes were not all read in this recovery.
The saved search and the two complete matching/context notes establish the
stated local scope comparison, not an exhaustive literature or open-PR
novelty search or independent recertification of those sources.

The distinct exact finite control in
`boost_rotation/exact_rotation_controls.py` forms differential-operator
compositions from a symbolic second Taylor jet of the one-body Pauli symbol.
It also uses a separate four-dimensional compression fixture with a complex,
nonconstant contact form factor. The latter is an abstract realization of
BR10, not a finite-site approximation of the excluded walk. The control
imports none of the earlier Fourier/jet boost-current helper.

Its first complete execution, recorded at 2026-10-11T21:59:16Z, exited zero
and emitted 63 distinct assertion records and `TOTAL: PASS=63 FAIL=0` in
`boost_rotation/first_run.log`. The categories are 12 Pauli-jet checks,
11 abstract-compression checks, 32 corner checks, seven exact constant or
volume checks, and one chart-face-jump check. In-process omission and sign
changes expose missing spin and contact terms. These are not separate
executions of mutated source files or a general tamper certificate.
`boost_rotation/execution.json` binds the command, timeout, source and log.
The unchanged successful calculation was not rerun during recovery.

These are the originating author's controls. They complement the analytic
domain and support estimates; they do not prove a continuum packet limit,
independent review, physical rotation representation or time extension.
Recovery checked the complete derivation, complete control source and full
saved output, and completed this evidence prose. This is author completion,
not an independent audit of the theorem. Exact source identities, reading
limits and the author check are recorded in `boost_rotation/receipt.json`
and `boost_rotation/AUTHOR_COMPLETION.md`.

The initial 589-line candidate and every pre-existing boost_rotation file
are preserved byte-for-byte in
`boost_rotation/recovery_initial_20261011T2202Z/`. Recovery followed reported
context-compaction failures of the originating author; the available first
complete control run succeeded. No failure transcript or compiler run is
inferred from that report.

A separate independent review of this complete new argument remains open.
The fixed supplied placement, band preparation, chart and explicit derivative
norms are part of the theorem, not hidden framework deductions. The precise
core counterexample in Section 5 is retained; neither it nor the scope
stress-test in the author record claims that every rotation construction is
impossible, or that a formal no-go submission packet has passed.
