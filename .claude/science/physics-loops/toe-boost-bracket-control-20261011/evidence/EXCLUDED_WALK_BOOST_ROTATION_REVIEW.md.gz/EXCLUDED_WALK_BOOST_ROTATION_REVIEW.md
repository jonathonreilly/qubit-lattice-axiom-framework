# Independent review of the excluded-pair boost–rotation argument

2026-10-11. **PASS for the frozen conditional mathematical source.** No
material algebraic, domain, normalization or constant error was found in
BR1–BR29. No source correction is requested. This is a bounded independent
review, not a retained-status audit or a review of a later integrated source.

The target is all 628 lines of `EXCLUDED_WALK_BOOST_ROTATION_PROBE.md`, SHA-256
`53f883ca7f01cdeb338e1c4d41367695fc6bdb32ee0ceb2905df50238a0c4760`.
The precise supported result is BR1 on the common core, BR23 on the stated
derivative-bounded origin preparations, and BR3 for the specified smooth
normalizable positive-positive packet. The supplied Hamiltonian, exclusion,
coordinates, clock, canonical placement and preparation remain hypotheses.

The full mathematical reconstruction is in
[PROOF_RECONSTRUCTION.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_rotation_review/PROOF_RECONSTRUCTION.md).
The source-bound receipt and exact reading limits are in
[receipt.json](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_rotation_review/receipt.json).

## Consequential checks and findings

- **Compression and signs, source lines 194–242:** the q-fiber adjoint removes
  the apparent constant overlap in `C D0,a P`; the reverse block is
  `i partial_Ka(h f)`. Inserting these blocks gives BR11 with its displayed
  signs. Both second K derivatives cancel, leaving
  `Qa partial_Kb-Qb partial_Ka`, with no constant contact term. Multiplication
  by i gives BR1. The coefficients obey the cross-derivative symmetry needed
  for the displayed formal symmetric expression.
- **Actual chart comparator, lines 244–316:** the ordinary chart expression
  is H1-to-L2 on the chosen cell, but the stated `G c cos(qa)` witness has
  the nonzero q_b face jump and fails to remain in periodic H1. The smooth
  auxiliary operator commutes with P and agrees exactly with the ordinary
  expression both on the supported packet and its constant-q contact tail.
  Therefore BR15 is a comparison with the actual chart expression on these
  states; it is not a substitution of a different global generator.
- **Global tail and norm estimate, lines 318–438:** the support-volume factor
  is `9 lambda^3/(128 pi^2)`. Both alpha and its K derivatives use that
  factor, and the one global normalization is not differentiated. BR20
  retains the periodic orbital tail multiplying derivatives of alpha and
  the full spin tail. BR22 uses full-torus output norms and only the free
  input support. Combining these contributions proves BR23 without assigning
  origin support or a free-band restriction to the projected state.
- **Normalizable specified family, lines 440–530:** the two normalized
  momentum measures and six rescaled variables are compensated by
  `(2 pi)^3 lambda^-3`. The mollified envelope, projector weight, global Z,
  band separation and derivative bounds check against B25–B30. The new
  radial derivative estimate includes the radius-squared measure and
  Cartesian factor 1/3. It gives `Bj<60`, `Vj<2^18`; the final exact budget
  is `67137247/768<2^17`. All higher derivatives exist for each lambda>0,
  and P preserves the needed smooth domain. The energy interval concerns
  the expectation, not spectral support after projection.
- **Novelty and scope, lines 532–628:** the September 25 free-walk bracket
  and corner-spin formula are matching prior art. The added contribution
  is the compressed contact formula and projected prepared-state comparison.
  BR29 correctly preserves reflected corner spin. The source does not
  infer a time theorem, other algebra brackets, physical rotations or an
  exponentiated representation. Those restrictions are necessary.

## Distinct decisive operator control

Before reading the author helper or its output, this reviewer wrote
[real_space_control.py](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_rotation_review/real_space_control.py).
It represents actual antisymmetric two-particle amplitudes on the infinite
integer lattice with exact Gaussian rational coefficients. Elementary shifts
implement the sine-Pauli Hamiltonian; multiplication by lattice coordinates
implements X; coincident sites implement C. There is no finite-box truncation,
periodic wrap, Taylor jet or abstract contact fixture.

The left side forms both compressed coordinate-dipole products directly. The
independently reconstructed right side is the free orbital/face-spin operator
plus the real-space form of the first-order contact term. With
`Ya=X1,a+X2,a` and `Va=sum_i sigma_i,a cos(ki,a)`, that term is

    [(Va C H0+H0 C Va)Yb-(Vb C H0+H0 C Vb)Ya]/4.

The first complete execution exited zero in 10.657677915878594 seconds under
a declared 120-second timeout. All 36 fixture/axis cases matched exactly:
24 off-diagonal ordered cases and 12 diagonal zero cases. Four adverse
expressions—omitted contact, reversed contact sign, halved contact, and
omitted face spin—each had a strictly positive residual in all 24
off-diagonal cases. For example, the first 0,1 case has omission residual
squared `389/900`, reversed-sign residual squared `389/225`, and omitted
spin residual squared `20909/900`.

These are 96 in-process wrong-object comparisons, not 96 independent
theorems or separately executed source mutants. The four finite fixtures
test the actual operator realization and detect those defects; the general
domain and packet bounds remain analytic. The full untruncated output is
[real_space_first_run.log](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_rotation_review/real_space_first_run.log),
with command, timeout and hashes in `real_space_execution.json`. No failed
scientific execution or counterexample was discarded.

## Author evidence and source integrity

After the proof and independent control were frozen, this reviewer read the
complete 186-line author helper, 39-line wrapper, 65-line first-run output,
completion report, receipt and recovery records. The author's 63 records
match the reported scope: Pauli jets, an abstract contact fixture, corner
signs, exact arithmetic budgets and the chart face jump. The source does not
pretend these finite checks prove the analytic norm or domain statements.
Its omissions and sign changes are correctly described as in-process checks.
The author helper was not rerun.

Deterministic verification checked all 41 path/hash records in the author's
receipt, all 11 initial snapshot files, preservation of the nine files not
authorized for recovery changes, all seven inherited source guards, the two
prior-art Git blobs, the exact recovery diff and its 37 unchanged displayed
equation blocks. The saved prior-art search reproduced byte-for-byte at
`a13caa4885f547c8d206265b031ba7649e539fd9`. All 83 bookkeeping checks
matched; they are provenance evidence, not mathematical proof. Full records
are in `boost_rotation_review/evidence_verification.log` and `.json`.

## Independence, reading limits and disposition

This reviewer did not author the target, canonical source, boost/current
source or author helpers. The full target and necessary premises were
reconstructed before opening author helpers/logs. The candidate itself
contains the proposed formulas and summaries of its controls, so the review
is not blind to their advertised results. A root message reporting agreement
arrived after the independent proof and control completed; it was not used
as mathematical evidence. The inherited selected model and effort were kept
without override; no different-model-family independence is asserted.

All 744 lines of the boost/current source and all 190 lines of the canonical
source were read. The necessary model/contact/packet portions were checked;
this report does not re-review every unrelated B or canonical-current claim.
The parent was read at lines 1–175, 370–478 and 805–844, not as a complete
scattering/Cook theorem. Both prior-art notes were read completely. The prior
root boost/current report was read only after the independent reconstruction
and does not certify this new bracket. The evolved boost/current draft and
two interspecies artifacts were identity guards only; no result from them
was used. No complete literature or current-open-PR novelty claim is made.

The chart-core counterexample and rejected shortcuts remain visible. In
particular, deleting the contact derivative, assigning cone support after
P, using origin spin at every corner, or borrowing a time interval from a
different bracket remains invalid. Any evolved-state extension must control
both differentiated profiles and its actual full-torus tail. A global
rotation generator, its domain, remaining Lie brackets and physical
identification require separate arguments.

No author source, repository source/index, editable prompt or audit data was
changed. Current instruction refs were fetched and read; repository source
files were not edited. One early aggregate tool display truncated and was
re-read in bounded complete pieces. A status command issued in external S
exited 128 because S is not a Git repository; the subsequent status check
used the actual walk worktree. Neither incident was a failed scientific
check. This source-bound PASS supports selective provisional reuse of the
stated conditional result. It grants no formal retained status.
