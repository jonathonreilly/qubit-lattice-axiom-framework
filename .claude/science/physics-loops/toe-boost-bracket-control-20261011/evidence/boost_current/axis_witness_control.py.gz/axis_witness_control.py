"""Separate exact Pauli/integral check of the nonzero differential coefficient.

This uses polynomial circle moments rather than the Laurent/K-jet engine.
It remains author evidence and does not independently review the theorem.
"""
from math import factorial
import sympy as s

C, S = s.symbols('C S', real=True)
ss = s.symbols('s0:3', real=True)
cc = s.symbols('c0:3', real=True)
variables = (*ss, *cc)
I = s.I
pauli = [s.Matrix([[0, 1], [1, 0]]), s.Matrix([[0, -I], [I, 0]]),
         s.Matrix([[1, 0], [0, -1]])]
eye = s.eye(2)
p1 = [s.kronecker_product(x, eye) for x in pauli]
p2 = [s.kronecker_product(eye, x) for x in pauli]
contact = s.Matrix([0, 1, -1, 0])/s.sqrt(2)


def avg(expr):
    poly = s.Poly(s.expand(expr), *variables)
    result = 0
    for power, coeff in poly.terms():
        factor = s.Integer(1)
        for j in range(3):
            m, n = power[j], power[j+3]
            if m % 2 or n % 2:
                factor = 0
                break
            m, n = m//2, n//2
            factor *= s.Rational(factorial(2*m)*factorial(2*n),
                                 4**(m+n)*factorial(m)*factorial(n)*factorial(m+n))
        result += coeff*factor
    return s.expand(result)


def inner(u, v):
    return avg((u.conjugate().T*v)[0])


def P(v):
    return s.expand(v-contact*inner(contact, v))


H = S*cc[0]*(p1[0]+p2[0]) + C*ss[0]*(p1[0]-p2[0])
H += sum((ss[j]*(p1[j]-p2[j]) for j in (1, 2)), s.zeros(4))
h = H*contact
hb = -S*ss[0]*p1[0]*contact
g = 2*S*C*(1-2*ss[0]**2)
r = g*contact


def Hd(v):
    return P(H*P(v))


def J(v):
    v = P(v)
    return P(g*v)-hb*inner(h, v)-h*inner(hb, v)


assert s.simplify(inner(h, h)-(2*C*C+4)) == 0
assert s.simplify(inner(hb, h)+C*S) == 0
assert all(s.simplify(x) == 0 for x in Hd(hb)-r/2)
assert inner(h, Hd(h)) == 0
actual = s.expand((contact.conjugate().T*(Hd(J(h))-J(Hd(h))))[0])
expected = 4*S*C*(ss[1]**2+ss[2]**2-2*ss[0]**2)
assert s.expand(actual-expected) == 0
assert s.expand(avg(actual*actual)-12*S*S*C*C) == 0
print('six exact identities from Pauli matrices and circle moments passed')
print('c* [H_D,J_b] h = 2 sin(K_b) (sin(q_j)^2+sin(q_k)^2-2 sin(q_b)^2)')
print('singlet-component squared norm = 3 sin(K_b)^2')
