"""Exact author controls for the compressed boost/current derivation.

Independent routes within this author calculation: the left side constructs
the dipole from its two symmetrized position/one-body-energy terms, then nests
commutators. The right side uses normal-ordered contact form factors. This is
finite algebra evidence, not independent review or a proof of analytic bounds.

Full three-dimensional relative Fourier polynomials; all four spin entries;
quadratic total-momentum jets. No sampled q quadrature or floating arithmetic.
Only constant jets are compared after at most two K derivatives.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import factorial
from sympy.polys.domains import QQ, QQ_I

Z = QQ_I.zero
ONE = QQ_I.one
I = QQ_I(0, 1)
HALF = QQ_I(QQ(1, 2))
ZERO = (0, 0, 0)
MAX = 2
checks = 0


def conj(z):
    return QQ_I(z.x, -z.y)


def plus(a, b):
    return tuple(x + y for x, y in zip(a, b))


def clean(d):
    return {k: v for k, v in d.items() if v}


def add(*fields):
    out = defaultdict(lambda: Z)
    for v in fields:
        for k, x in v.items():
            out[k] += x
    return clean(out)


def scale(v, z):
    return clean({k: z * x for k, x in v.items()})


def dk(v, a):
    out = {}
    for (p, q, s), x in v.items():
        if p[a]:
            pp = list(p)
            pp[a] -= 1
            out[(tuple(pp), q, s)] = x * p[a]
    return out


def dq(v, a):
    return clean({(p, q, s): x * I * q[a] for (p, q, s), x in v.items()})


def mul_scalar(f, v):
    out = defaultdict(lambda: Z)
    for (p, q, _), x in f.items():
        for (p2, q2, s), y in v.items():
            pp = plus(p, p2)
            if sum(pp) <= MAX:
                out[(pp, plus(q, q2), s)] += x * y
    return clean(out)


def inner(v, w):
    # Fiber inner product only: K remains a real formal Taylor variable.
    out = defaultdict(lambda: Z)
    by_qs = defaultdict(list)
    for (p, q, s), x in w.items():
        by_qs[(q, s)].append((p, x))
    for (p, q, s), x in v.items():
        for p2, y in by_qs[(q, s)]:
            pp = plus(p, p2)
            if sum(pp) <= MAX:
                out[(pp, ZERO, 0)] += conj(x) * y
    return clean(out)


def P(v):
    # c0=(0,1,-1,0); C=|c0><c0|/2, avoiding sqrt(2) arithmetic.
    means = defaultdict(lambda: Z)
    for (p, q, s), x in v.items():
        if q == ZERO and s in (1, 2):
            means[p] += (1 if s == 1 else -1) * x * HALF
    corr = {}
    for p, x in means.items():
        corr[(p, ZERO, 1)] = -x
        corr[(p, ZERO, 2)] = x
    return add(v, corr)


def outer(u, v, w):
    # Every form factor u,v here is computed with c0, hence divide by two.
    return scale(mul_scalar(inner(v, w), u), HALF)


def trigq(a, n, sine=False):
    q = [0, 0, 0]
    q[a] = n
    nq = tuple(-x for x in q)
    return {(ZERO, tuple(q), 0): -I * HALF if sine else HALF,
            (ZERO, nq, 0): I * HALF if sine else HALF}


def halfangle_jet(a, c, s, sine=False):
    vals = (s, c * HALF, -s / QQ_I(8)) if sine else (c, -s * HALF, -c / QQ_I(8))
    out = {}
    for n, x in enumerate(vals):
        p = [0, 0, 0]
        p[a] = n
        out[(tuple(p), ZERO, 0)] = x
    return clean(out)


def pauli(v, particle, axis):
    out = defaultdict(lambda: Z)
    for (p, q, s), x in v.items():
        bit = (s >> (1 - particle)) & 1
        if axis == 0:
            ss, factor = s ^ (1 << (1 - particle)), ONE
        elif axis == 1:
            ss, factor = s ^ (1 << (1 - particle)), I if bit == 0 else -I
        else:
            ss, factor = s, ONE if bit == 0 else -ONE
        out[(p, q, ss)] += factor * x
    return clean(out)


cs = [(QQ_I(QQ(63, 65)), QQ_I(QQ(16, 65))),
      (QQ_I(QQ(12, 13)), QQ_I(QQ(5, 13))),
      (QQ_I(QQ(4, 5)), QQ_I(QQ(3, 5)))]
C = [halfangle_jet(a, *cs[a]) for a in range(3)]
S = [halfangle_jet(a, *cs[a], sine=True) for a in range(3)]
sinK = [scale(mul_scalar(C[a], S[a]), QQ_I(2)) for a in range(3)]
cosK = [add(mul_scalar(C[a], C[a]), scale(mul_scalar(S[a], S[a]), -ONE)) for a in range(3)]
symbols = [[add(mul_scalar(S[a], trigq(a, 1)),
                scale(mul_scalar(C[a], trigq(a, 1, sine=True)), ONE if i == 0 else -ONE))
            for a in range(3)] for i in range(2)]


def hi(v, i):
    return add(*(mul_scalar(symbols[i][a], pauli(v, i, a)) for a in range(3)))


def H(v):
    return add(hi(v, 0), hi(v, 1))


def Hd(v):
    return P(H(P(v)))


def Hdiff(v):
    return add(hi(v, 0), scale(hi(v, 1), -ONE))


def Hprime(v, a):
    return add(*(mul_scalar(dk(symbols[i][j], a), pauli(v, i, j))
                 for i in range(2) for j in range(3)))


def X(v, i, a):
    return scale(add(dk(v, a), scale(dq(v, a), HALF if i == 0 else -HALF)), I)


def D0(v, a):
    return scale(add(*(add(X(hi(v, i), i, a), hi(X(v, i, a), i)) for i in range(2))), HALF)


def D(v, a):
    return P(D0(P(v), a))


c0 = {(ZERO, ZERO, 1): ONE, (ZERO, ZERO, 2): -ONE}
h = H(c0)
hb = [dk(h, a) for a in range(3)]
g = [mul_scalar(sinK[a], trigq(a, 2)) for a in range(3)]
r = [mul_scalar(g[a], c0) for a in range(3)]


def Fb(v, b):
    return scale(add(outer(hb[b], h, v), outer(h, hb[b], v)), -ONE)


def J(v, b):
    return add(P(mul_scalar(g[b], P(v))), Fb(v, b))


def Jraw(v, b):
    return scale(add(Hd(D(v, b)), scale(D(Hd(v), b), -ONE)), I)


def A(v, b):
    return add(scale(outer(h, r[b], v), -ONE), outer(r[b], h, v),
               scale(outer(Hd(hb[b]), h, v), -ONE),
               scale(outer(Hd(h), hb[b], v), -ONE),
               outer(hb[b], Hd(h), v), outer(h, Hd(hb[b]), v))


def L(v, a):
    return P(add(scale(Hdiff(dq(P(v), a)), HALF), Hprime(P(v), a)))


def Ladj(v, a):
    return scale(P(Hdiff(dq(P(v), a))), -HALF)


def B(v, a, b):
    hab = dk(hb[b], a)
    Fprime = scale(add(outer(hab, h, v), outer(hb[b], hb[a], v),
                      outer(hb[a], hb[b], v), outer(h, hab, v)), -ONE)
    return add(scale(outer(hb[a], r[b], v), -ONE),
               scale(outer(h, dk(r[b], a), v), -ONE), Hd(Fprime),
               scale(outer(L(hb[b], a), h, v), -ONE),
               scale(outer(L(h, a), hb[b], v), -ONE),
               outer(hb[b], Ladj(h, a), v), outer(h, Ladj(hb[b], a), v))


def ell(v, a):
    out = []
    for i in range(2):
        cos2ki = add(mul_scalar(cosK[a], trigq(a, 2)),
                     scale(mul_scalar(sinK[a], trigq(a, 2, sine=True)), -ONE if i == 0 else ONE))
        out.append(mul_scalar(cos2ki, hi(v, i)))
    return add(*out)


def constant(v):
    return {k: x for k, x in v.items() if k[0] == ZERO and x}


def assert_zero(v, label):
    global checks
    got = constant(v)
    assert not got, (label, list(got.items())[:3])
    checks += 1
    print(label, "exact zero", flush=True)


def phase(n):
    out = {}
    for p in product(range(MAX + 1), repeat=3):
        if sum(p) <= MAX:
            x = ONE
            for j in range(3):
                x *= (I * n[j]) ** p[j] / QQ_I(factorial(p[j]))
            if x:
                out[(p, ZERO, 0)] = x
    return out


base = add(mul_scalar(trigq(0, 1, sine=True), {(ZERO, ZERO, 0): ONE}),
           mul_scalar(trigq(1, 2), c0),
           mul_scalar(trigq(2, 1, sine=True), {(ZERO, ZERO, 1): ONE, (ZERO, ZERO, 2): ONE}),
           c0)
psi = P(mul_scalar(phase((2, -1, 3)), base))
psi0 = P(base)
print("Exact Gaussian-rational algebra; 3D q Fourier modes; K jets through degree 2.", flush=True)
print("Half-angle (cos,sin) fixtures:", cs, flush=True)
for b in range(3):
    assert_zero(add(Jraw(psi, b), scale(J(psi, b), -ONE)), f"canonical current b={b}")
    assert_zero(add(Hd(J(psi, b)), scale(J(Hd(psi), b), -ONE), scale(A(psi, b), -ONE)),
                f"Hamiltonian-current coefficient b={b}")
for a in range(3):
    for b in range(3):
        # Nested commutators start from the local-density dipole, not (J5).
        left = scale(add(D(Jraw(psi, b), a), scale(Jraw(D(psi, a), b), -ONE)), -I)
        right = add(P(ell(P(psi), a)) if a == b else {}, A(dk(psi, a), b), B(psi, a, b))
        assert_zero(add(left, scale(right, -ONE)), f"full bracket a={a}, b={b}")

# The differential term has a nonzero exact witness. This is not a band test.
av = constant(A(psi0, 0))
norm2 = sum((conj(z) * z for z in av.values()), Z)
assert norm2 and norm2.y == 0 and norm2.x > 0
checks += 1
print("nonzero [H_D,J_0] finite-polynomial witness norm^2 =", norm2, flush=True)

# Integer envelope constants used after the exact analytic support argument.
aconst = F(7, 4) + F(2) + F(3, 2) + F(11, 4) + F(21, 8)
bconst = F(17) + F(39, 8) + F(5, 32)
assert aconst == F(85, 8) and aconst < 12
assert bconst == F(705, 32) and bconst < 24
checks += 2
print("A support-kernel coefficient:", aconst, "< 12")
print("B support-kernel coefficient for lambda<=1:", bconst, "< 24")

# The fixed smooth preparation uses a mollified product polynomial.
i0 = sum(F((-1)**j * __import__('math').comb(4, j) * 2, 2*j + 1) for j in range(5))
i1 = 16 * (F(2, 3) - F(4, 5) + F(2, 7))
assert i0 == F(256, 315) and i1 == F(256, 105) and i1/i0 == 3
assert 24*24*3 < (512/F(8))**2  # convolution norm loss < 1/8
assert 2*F(192, 7) + F(8, 3) < 60
checks += 3
print("one-dimensional preparation integrals:", i0, i1, "; derivative ratio = 3")
print("mollified K-envelope gives scaled derivative B_a < 60")

# Mixed-band small-total-energy test: exact symbolic leading coefficients.
# At q=(pi/4,0,0), K=(t,0,0): E=sqrt(2)sin(t/2),
# ell_x=-sqrt(2)sin(t)cos(t/2); (ell_x-E)/E -> -3.
from sympy import symbols as syms, sin, cos, sqrt, limit, pi
t = syms('t', positive=True)
energy = sqrt(2)*sin(t/2)
residual = -sqrt(2)*sin(t)*cos(t/2) - energy
assert limit(residual/t, t, 0) == -3/sqrt(2)
assert limit(residual/energy, t, 0) == -3
checks += 2
print("mixed-channel small-total-energy residual/t = -3/sqrt(2); residual/E = -3")
print("completed", checks, "exact assertion families", flush=True)
