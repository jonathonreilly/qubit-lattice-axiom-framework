#!/usr/bin/env python3
"""Freeze author evidence identities. This script makes no scientific verdict."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
S = HERE.parent
REPO = S.parent / "boost_worktree"
PRIMARY = S / "BOOST_CURRENT_EXPECTATION_PROBE.md"
EXPECTED_PRIMARY = "a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68"
DEADLINE = "2026-10-12 16:00:52 UTC"


def binding(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data)}


def main():
    now = datetime.datetime.now(datetime.timezone.utc)
    assert now < datetime.datetime(2026, 10, 12, 16, 0, 52,
                                   tzinfo=datetime.timezone.utc)
    primary = binding(PRIMARY)
    assert primary["sha256"] == EXPECTED_PRIMARY, "Primary changed after freeze"
    inherited = json.loads((HERE / "initial_sources.json").read_text())
    old_checks = []
    for old in inherited["frozen_prior_packet_records_verified"]:
        current = binding(old["path"])
        ok = current["sha256"] == old["sha256"] and current["bytes"] == old["bytes"]
        old_checks.append({**current, "expected_sha256": old["sha256"], "match": ok})
    assert all(row["match"] for row in old_checks), "Frozen prior evidence changed"
    (HERE / "final_prior_preservation.json").write_text(
        json.dumps(old_checks, indent=2) + "\n")

    copied = json.loads((HERE / "source_copy_manifest.json").read_text())
    for row in copied:
        original = binding(row["original"])
        copy = binding(row["copy"])
        assert original["sha256"] == copy["sha256"] == row["sha256"]
        assert original["bytes"] == copy["bytes"] == row["bytes"]

    recovered = json.loads((HERE / "recovered_initial_bytes" / "preservation.json").read_text())
    for row in recovered["preserved"]:
        assert binding(row["recovery_copy"])["sha256"] == row["sha256"]
    assert binding(HERE / "initial_sources.json")["sha256"] == (
        "ae87a0144a71479f694bce13715e039c7da9c1312124ca746dc40fafe07d5b57")
    assert binding(HERE / "DRAFT_DIAGONAL_BEFORE_ALL_COMPONENTS.md")["sha256"] == (
        "e15765229f7cc512b041a2d5db3f1d1cb0b6ba676da1931a3dff932c59b9202e")

    refs = subprocess.check_output(
        ["git", "rev-parse", "HEAD", "origin/main", "origin/ai/execution"],
        cwd=REPO, text=True).splitlines()
    status = subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=REPO, text=True)
    (HERE / "repository_status_at_freeze.txt").write_text(status)

    checkpoint = f"""# Current checkpoint — completed author expectation derivation

Frozen author source: {PRIMARY}
SHA-256: {primary['sha256']}
Status: bounded-support conditional mathematical result; independent review pending.

Result: for the exact B25–B30 globally normalized preparation, every a,b in
{{1,2,3}} and every finite T>=0,
sup_|tau|<=T |<psi_lambda(tau/lambda),R_ab psi_lambda(tau/lambda)>|/lambda ->0.
No finite-lambda identity, new physical law, or residual-norm improvement is asserted.

Proof: exact contact-forcing formula; compact-family spectral cutoff and
integration by parts for the full bounded perturbation; differentiated error
equation gives H1_kappa convergence to a kernel-valued forced evolution.
Symmetry moves both cross terms onto the small free-comparison residual;
Q0,ab z=H_*L_b partial_a(kappa_b z) has zero pairing with z. A second
expectation check uses only strong L2 convergence and uniform H1 bounds.

Recovered initial checkpoint and initial manifest are preserved under
recovered_initial_bytes/. The complete diagonal draft is preserved as
DRAFT_DIAGONAL_BEFORE_ALL_COMPONENTS.md before root's all-component proposal.
The proposal was checked explicitly; no off-diagonal norm lower bound follows.
AUTHOR_CHECK.md contains the full author consistency calculations.

All five primary mathematical source copies and all 57 inherited receipt
bindings were checked unchanged. Bookkeeping is not scientific certification.
No new numerical science runner was needed or claimed to prove the gapless limit.
No repository or editable prompt changes, PR, merge, audit, physical adoption,
other-chat message, further delegation, model override, or deadline extension.

Next decision: source-bound independent review of the cutoff lemma, full
normalization, derivative equation, all-component symmetry, and expectation
decomposition. No mathematical residual is knowingly left in the authored
argument; independent validation remains pending. Physical model identification,
the full boost algebra, other states, growing tau, and rates remain outside scope.

Deadline: {DEADLINE}; never extended.
Freeze time: {now.isoformat()}
"""
    (HERE / "CHECKPOINT.md").write_text(checkpoint)

    excludes = {"receipt.json", "receipt_verification.stdout.log",
                "receipt_verification.stderr.log", "receipt_verification_run.json"}
    records = {}

    def add(path, category):
        rec = binding(path)
        if rec["path"] not in records:
            records[rec["path"]] = {**rec, "roles": []}
        if category not in records[rec["path"]]["roles"]:
            records[rec["path"]]["roles"].append(category)

    add(PRIMARY, "primary_author_proof_complete_read")
    for p in sorted(HERE.rglob("*")):
        if p.is_file() and p.name not in excludes:
            add(p, "assigned_evidence_artifact")
    for row in copied:
        add(row["original"], "frozen_mathematical_source_complete_read")
    for row in old_checks:
        add(row["path"], "inherited_binding_preservation_only_unless_other_role")
    instruction_source = json.loads((HERE / "instruction_sources.json").read_text())
    for row in instruction_source["records"]:
        add(row["path"], "applicable_instruction_or_registry_read")

    receipt = {
        "schema": "external_author_expectation_packet_v1",
        "created_utc": now.isoformat(),
        "deadline_utc": DEADLINE,
        "primary": primary,
        "scientific_scope": "All-nine fixed-finite-rescaled-time expectation limit; exact B25-B30 state, full physical projection, global normalization. Also forced H1 and residual-vector limits.",
        "status": "author conditional proof; independent scientific review pending; no audit status",
        "independence": "No independent reviewer or science runner was used by this worker. Analytic author checks are identified explicitly. Root supplied proposed mechanisms, then the all-index extension; current author checked them.",
        "runtime": {"python_executable": sys.executable, "python_version": sys.version,
                    "platform": platform.platform(), "model_effort": "Inherited parent-selected model and reasoning effort; no override. Exact runtime identity not inferred from historic skill model names."},
        "repository": {"path": str(REPO), "head": refs[0], "stored_origin_main": refs[1],
                       "stored_origin_ai_execution": refs[2], "porcelain_at_freeze": status,
                       "remote_freshness": "No fetch; root is sole repository writer."},
        "recovered_initial_bytes": recovered,
        "complete_scientific_read": [row["original"] for row in copied],
        "prior_binding_preservation_count": len(old_checks),
        "prior_binding_preservation_matching": sum(row["match"] for row in old_checks),
        "editable_prompt_files_changed": [],
        "prohibited_actions_performed": [],
        "artifacts_excluded_to_avoid_self_reference": sorted(excludes),
        "verification_limits": [
            "Hashes and complete logs verify provenance, not the theorem.",
            "No continuum numerical rate, onset, arbitrary-state bound, or growing-tau claim.",
            "No off-diagonal residual-norm lower bound.",
            "No independent verification of the new primary; source-bound independent review is next.",
            "No exhaustive literature, open-PR, or repository novelty claim."
        ],
        "bindings": sorted(records.values(), key=lambda row: row["path"])
    }
    (HERE / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"primary": primary, "receipt": binding(HERE / "receipt.json"),
                      "bound_paths": len(records), "prior_bindings_unchanged": len(old_checks),
                      "scientific_review": "pending"}, indent=2))


if __name__ == "__main__":
    main()
