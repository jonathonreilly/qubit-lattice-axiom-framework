# Current checkpoint — inverse-energy boost/current probe

Task: determine o(lambda) or a normalizable counterexample at t=tau/lambda
for the specified B25-B30 positive-positive origin-cone packets. External only.
Source identities and coverage: initial_sources.json. Earlier packets unchanged.

Candidate derived result (author composition, controls and final check pending):
For the K-rescaling isometry T_lambda psi = lambda^(3/2)/(2pi)^(3/2)
psi(lambda kappa,q), split psi=P exp(-itH0)phi/n + w using the exact
positive-sign contact Duhamel formula. Then lambda^(-1/2) T_lambda w tends
in H1_kappa(L2_q) to
z(tau,kappa)= i/((2pi)^(3/2)sqrt(I0)) integral_0^tau
 exp[-i(tau-s) A_kappa] zeta a(s,kappa) ds,
a=F/Z0 integral f(x) w0(kappa,x) exp[-is e0(kappa,x)] dx.
All Z_lambda,n_lambda remain global scalars; n_lambda ->1.

Forced limit proof: integrate the propagator applied to fixed h0. The kernel
part uses the checked gapless fixed-vector strong limit, uniformly on compact
kappa by Duhamel equicontinuity. The complement has a spectral-cutoff primitive
bounded by T||E_delta h0|| + lambda(2+T sup||B+R||)||h0||/delta.
Time integration by parts handles the scalar source. Uniform second kappa
derivatives of the rescaled propagator and scalar source, followed by finite
central/forward differences, give convergence of first kappa derivatives.
No q derivative of singular zeta is used.

Normal-order bracket limit on z in the fixed physical zero space:
G_ab=H_* L_b partial_{kappa_a}(kappa_b z), where
L_b=P cos(2q_b)P+|v_b><v|+|v><v_b|.
The supported free comparison contributes O(lambda^(3/2)), hence disappears
after division by sqrt(lambda). All bounded normal-form coefficients converge
in operator norm after A_b/lambda is used with partial_kappa.

Exact coupling:
H_* L_b zeta = (epsilon(q)^2/3-sin(q_b)^2)c/sqrt(I0),
whose squared norm is 1/(12 I0). This retains the canonical finite-rank terms.
For diagonal b, ||partial_b(kappa_b a(0))|| >= ||a(0)||/2 >0 by integration
by parts. Therefore dG_bb/dtau at zero is nonzero for the actual packet.
A conservative explicit remainder calculation gives, with N=(integral f)/Z0,
||G_bb(tau)-tau G_bb'(0)|| <=60 (2pi)^(-3/2) N tau^2/sqrt(I0),
||G_bb'(0)|| >=(2pi)^(-3/2) N/(8 sqrt(12) I0).
Using I0<=9/8, every fixed 0<tau<=1/4096 gives a positive limit lower bound.
Potential conclusion: ||R_bb psi(tau/lambda)|| is Theta(sqrt(lambda)),
although energy expectation remains in [lambda/2,3lambda].

Failed/inadequate routes preserved: E2's norm upper bound alone does not
prove an obstruction; isolating the initial zero projection loses cancellation
with the free complement; fixed-fiber computations do not make normalizable
packets; L2 forced convergence alone does not justify the K derivative;
no operator-norm gapless averaging over the full zero-space ball is asserted.

Next: write complete proof, independently exercise canonical coupling and
forced-limit derivative mechanics with scoped author controls, inspect all logs,
perform the narrow negative-scope checklist, and freeze note/receipt. No formal
review of this new authored result, repository edit, PR, or audit verdict.
