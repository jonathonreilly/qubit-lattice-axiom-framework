# Preserved longer route — not used by the final main proof

2026-10-11. Author analysis by spectral_edge_recovery, preserved after root
suggested the simpler mean-ergodic route. This is not an independently
reviewed theorem or an additional claim of the main probe. The main probe
uses only a fixed-tau liminf estimate on tau<=1/32768 and a shorter-time
exact asymptotic. It does not depend on the assertions explored below.

The initial target was the stronger fixed-tau H1 limit

    W_lambda(tau,kappa) -> z(tau,kappa)
      =i c0/sqrt(I0) integral_0^tau
         exp[-i(tau-s) A_kappa]zeta a(s,kappa) ds,
    A_kappa=Pi B_kappa Pi, B_kappa u=i d cross u,
    d_j=kappa_j cos q_j, ||B_kappa||<=|kappa|.

The source identities and packet conventions are those in the final probe's
T3–T12, and W_lambda is exactly its T11. The frozen degenerate dynamics
source D8–D11 supplies a fixed-vector strong limit from the physical zero
space, not a statement for arbitrary lambda-dependent packets.

The route works with the primitive

    S_lambda(t,kappa)=integral_0^t
        exp[-ir H(lambda kappa)/lambda]h(lambda kappa) dr.

Replace h(lambda kappa) by h0 in norm, since the difference is O(lambda^2)
on compact kappa sets. Decompose h0=Pi h0+Qh0. For the zero component,
D8 gives convergence to integral_0^t exp(-ir A_kappa)Pi h0 dr at each fixed
kappa, uniformly for bounded t. The propagators are equicontinuous in
kappa by bounded Duhamel differentiation; so are the effective ones.
A finite kappa net extends the convergence uniformly to compact kappa sets
for this one fixed vector. No zero-space unit-ball convergence is inferred.

For the complementary component set

    E_delta=1_(0<|H_*|<=delta), Q_delta=1_(|H_*|>delta),
    g_delta=H_*^(-1) Q_delta h0,
    ||g_delta||<=||h0||/delta,
    H(lambda kappa)/lambda=H_*/lambda+B_kappa+R_lambda,
    ||R_lambda||=O(lambda).

The primitive of the high component has the exact integration-by-parts
identity

    integral_0^t U_lambda(r)H_*g_delta dr
      =i lambda [U_lambda(t)-I]g_delta
         -lambda integral_0^t U_lambda(r)(B_kappa+R_lambda)g_delta dr.

Its norm is at most
`lambda[2+T sup||B+R||]||h0||/delta` for t<=T. The low nonzero component
is bounded by `T||E_delta h0||`, which tends to zero with delta by the
finite spectral measure of h0. First send lambda to zero at fixed delta,
then delta to zero. This would prove uniform convergence of the primitive
without a spectral gap or inverse on the whole complement.

For the scalar source, exact time integration by parts gives

    integral_0^tau U_lambda(tau-s)h_lambda a_lambda(s) ds
      =S_lambda(tau)a_lambda(0)
         +integral_0^tau S_lambda(tau-s) partial_s a_lambda(s) ds.

Its proposed limit is the z displayed above. This argument avoids a claim
that U_lambda itself converges on the nonzero component of h0.

The delicate additional step is momentum differentiation. The bounded
rescaled generator has

    ||partial_(kappa_j)[H(lambda kappa)/lambda]||<=1,
    ||partial_(kappa_j)^2[H(lambda kappa)/lambda]||<=lambda/2.

Duhamel differentiation therefore gives

    ||partial_(kappa_j) U_lambda(r)||<=|r|,
    ||partial_(kappa_j)^2 U_lambda(r)||<=r^2+|r|lambda/2.

The scalar source and h_lambda have uniform second kappa derivatives on a
fixed neighborhood of the packet support. Thus W_lambda has a uniform
second-derivative bound, and so does the candidate limit z. For their
difference, a finite-difference estimate of the form

    ||partial_j(W_lambda-z)|| <=2||W_lambda-z||_infinity/h+C h

would upgrade uniform strong convergence to uniform first-derivative
convergence by choosing h after lambda, and hence to H1 on the compact
support. No q derivative of zeta appears. The larger neighborhood must
keep both individual scaled momenta separated from zero; for example
|kappa|<1/2 still leaves a positive separation from the annular x support.

Combined with the exact normal-form coefficient limits, the proposed
stronger bracket limit would be

    lambda^(-1/2) T_lambda R_ab psi_lambda(tau/lambda)
       -> H_* L_b partial_(kappa_a)(kappa_b z(tau,kappa)).

On this candidate limit, z and its kappa derivatives lie in the fixed
physical zero space. Its derivative at tau=0 for diagonal b is exactly
Gamma_b in the main note. A Taylor estimate directly inside the bounded
zero-space dynamics suggests

    ||G_bb(tau)-tau Gamma_b||
       <=60 c0 N tau^2/sqrt(I0),

using ||H_*L_b||<12, the source bounds T21, and ||A_kappa||<=1/4.
This was the origin of an earlier candidate interval tau<=1/4096.
Neither the exact fixed-tau convergence nor that larger interval is asserted
in the final main theorem; its direct estimate uses full-space coefficient
bounds, sqrt(6) rather than 1/sqrt(I0), and tau<=1/32768.

The finite three-vector control exercises related forcing/derivative
mechanics, but its spectral gap supplies no proof of this continuum route.
If the stronger route is revived, its fixed-vector averaging premise,
compact-uniform extension, cutoff primitive, differentiation upgrade and
constants need explicit independent coverage. It was set aside to keep
the delivered theorem's proof elementary and its dependence surface smaller,
not because a contradictory calculation was found.
