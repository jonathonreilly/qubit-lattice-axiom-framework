#!/usr/bin/env python3
"""Author arithmetic control; analytic sine chord and radial proof are in note."""
import hashlib
import json
from pathlib import Path
import sympy as s
own=Path(__file__).resolve()
R=s.pi*s.sqrt(3)/2
coefficient=s.simplify(8/(4*(2*s.pi)**3) * s.pi**2/4)
bound=s.simplify(coefficient*4*s.pi*R)
assert coefficient==1/(16*s.pi)
assert bound==s.pi*s.sqrt(3)/8
# pi<4 and sqrt(3)<2 already give this bound<1<9/8.
assert 3<2**2
assert s.Rational(4*2,8)==1<s.Rational(9,8)
print(json.dumps({'script':str(own),'sha256':hashlib.sha256(own.read_bytes()).hexdigest(),'folded_integral_coefficient':str(coefficient),'ball_radius':str(R),'upper_bound':str(bound),'lower_bound':'1/12','retained_coarse_upper_bound':'9/8','role':'author exact arithmetic only; analytic inequalities and kernel completeness proved in note','status':'completed'}))
