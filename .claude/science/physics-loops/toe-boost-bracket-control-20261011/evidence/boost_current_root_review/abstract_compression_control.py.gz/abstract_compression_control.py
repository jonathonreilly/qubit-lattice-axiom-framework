"""Independent exact finite-matrix check of the compressed differential algebra.

This is an abstract two-parameter compression fixture, not another physical
Weyl/Fourier realization. It checks the contact-block identity and normal
ordering with nonzero derivative coefficients. Analytic packet/domain/support
statements are checked in the accompanying written review, not by this code.
The source author helpers were visible before this distinct fixture was made.
"""
import json
import time
import sympy as s

start = time.monotonic()
x, y = s.symbols('x y', real=True)
variables = [x, y]
c = s.ones(4, 1)/2
C = c*c.T
P = s.eye(4)-C
hd = [1+x+2*y+x*y, 2-x+y*y, -4+3*x-y, 1-3*x-y-x*y-y*y]
H0 = s.diag(*hd)
H = P*H0*P
h = H0*c
ha = [h.diff(k) for k in variables]
G = [s.diag(2-x+y, -1+2*x, 3+x*y, -4-x-y-x*y),
     s.diag(-3+y*y, 4-x*y, 2+2*x-y, -3+x*y-2*x+y-y*y)]
L0 = [H0.diff(k)/2+(ha[a]*c.T-c*ha[a].T)/2
      for a, k in enumerate(variables)]
L = [P*entry*P for entry in L0]
F = [-ha[b]*h.T-h*ha[b].T for b in range(2)]
J = [P*G[b]*P+F[b] for b in range(2)]
r = [G[b]*c for b in range(2)]
phi = P*s.Matrix([1+x+s.I*y*y, 2-y*y+s.I*x, s.Rational(1, 3)+x*y,
                  -2+s.I*x*x*y])
checks = []


def zero(v):
    return all(s.expand(z) == 0 for z in v)


def check(label, condition):
    assert condition, label
    checks.append(label)
    print(json.dumps({'check': label}), flush=True)


def D0(v, a):
    return s.I*(H0*v.diff(variables[a])+L0[a]*v)


def D(v, a):
    return P*D0(P*v, a)


check('normalized_contact_and_orthogonal_projection',
      c.dot(c) == 1 and zero(P*P-P) and zero(P*c))
check('pointwise_commuting_free_symbols_with_zero_contact_means',
      zero(c.T*H0*c) and all(zero(H0*g-g*H0) and zero(c.T*g*c) for g in G))
for a, k in enumerate(variables):
    check(f'ambient_contact_and_adjoint_blocks_{a}',
          zero(L0[a]*c-ha[a]) and zero(L0[a].T*c)
          and zero(L[a]+L[a].T-P*H0.diff(k)*P)
          and zero(C*D0(phi, a)-s.I*c*(h.T*phi.diff(k))[0]))
    scalar = 1+x*x+2*y+s.I*x*y
    check(f'right_contact_block_with_differentiated_amplitude_{a}',
          zero(P*D0(c*scalar, a)-s.I*(h*scalar).diff(k)))

for b in range(2):
    A = (-h*r[b].T+r[b]*h.T-(H*ha[b])*h.T-(H*h)*ha[b].T
         +ha[b]*(H*h).T+h*(H*ha[b]).T)
    check(f'finite_rank_hamiltonian_current_identity_{b}', zero(H*J[b]-J[b]*H-A))
    check(f'differential_coefficient_is_nonzero_{b}', not zero(A*phi))
    for a, k in enumerate(variables):
        ell = H0*G[b].diff(k)+L0[a]*G[b]-G[b]*L0[a]
        B = (-ha[a]*r[b].T-h*r[b].diff(k).T+H*F[b].diff(k)
             -(L[a]*ha[b])*h.T-(L[a]*h)*ha[b].T
             +ha[b]*(L[a].T*h).T+h*(L[a].T*ha[b]).T)
        left = -s.I*(D(J[b]*phi, a)-J[b]*D(phi, a))
        right = P*ell*P*phi+A*phi.diff(k)+B*phi
        check(f'complete_normal_ordered_bracket_{a}_{b}', zero(left-right))
        check(f'omitting_derivative_coefficient_is_detected_{a}_{b}',
              not zero(left-(right-A*phi.diff(k))))

print(json.dumps({'checks': len(checks), 'sympy': s.__version__,
                  'elapsed_seconds': time.monotonic()-start,
                  'scope': 'Abstract compression algebra only; no physical finite-grid approximation, packet estimate or continuum proof.'}))
