# Next scientific questions

The actual expectation and fixed-time forced dynamics are now established
conditionally for the same preparation. Next derive the explicit compressed
zero-space dynamics and its source-coupled spectrum. Rates and growing tau,
other justified energy placements and preparations, and full boost algebra
remain separate questions. The compact-patch scattering construction is
active elsewhere in the campaign, not a dependency of this milestone.
