# Author checks of the fixed-time expectation calculation

These are this derivation author's analytic checks. They are not independent
scientific review and do not convert source hashes into proof evidence.
The checked primary source is `../BOOST_CURRENT_EXPECTATION_PROBE.md`;
its final identity is bound by `receipt.json` after the complete read.

## Cutoff identity checked by an approximate solution

The main proof bounds the Duhamel integral of
`r=Q(Bz-g)` by integration by parts. An alternative arrangement checks its
signs and the retained full bounded perturbation. Put

    V_lambda=B+E_lambda,
    x_delta=H_*^-1 S_delta r,
    y_lambda=z-lambda x_delta,
    e_lambda=E_lambda z+g-g_lambda.

The exact residual of this approximate solution is

    i partial_t y_lambda-G_lambda y_lambda+g_lambda
      =-(I-S_delta)r-e_lambda
           -i lambda partial_t x_delta+lambda V_lambda x_delta.

This follows by substituting `i z'=G_lambda z-g_lambda-r-e_lambda`
and `lambda G_lambda x_delta=H_*x_delta+lambda V_lambda x_delta`.
The initial mismatch is `y_lambda(0)=-lambda x_delta(0)`; it must be
retained. Unitarity then bounds `W_lambda-y_lambda` by that mismatch
plus the integrated residual. Adding `lambda x_delta(t)` to compare
W_lambda with z gives exactly the endpoint and derivative scales in X17,
plus `T sup||e_lambda||`. This confirms that no commutation of B with
H_* or with S_delta was silently inserted, and that the cutoff's initial
corrector is accounted for.

The argument uses `delta>0` fixed before taking lambda to zero. Reversing
those limits or taking a uniform bound on the uncut inverse is not justified.

## A continuous-spectrum diagnostic for the strength of the cutoff claim

This diagnostic is a mathematical control, not a replacement for the supplied
lattice model. On `L2((0,1),dx)` take H_* to be multiplication by x,
Pi=0, V_lambda=0, and the constant forcing r(s,x)=1. Then

    I_lambda(t,x)=integral_0^t exp[-i(t-s)x/lambda] ds
                 =lambda(1-exp[-itx/lambda])/(i x).

For any fixed t>0 and `0<lambda<t`, its norm squared obeys

    (4/pi^2)lambda t <= ||I_lambda(t)||^2 <= 5lambda t.

For the lower bound use `|I_lambda|=2lambda sin(tx/(2lambda))/x`
on `0<x<lambda/t`, where `sin u>=2u/pi`. For the upper bound use
`|I_lambda|<=min(t,2lambda/x)` and split the integral at lambda/t.
Thus the cutoff lemma's convergence is compatible with an order
sqrt(lambda) norm in a genuinely gapless continuous spectrum. Treating
its integration by parts as an unqualified O(lambda) estimate would not
be supported even in this explicit control. No convergence rate is used
for the actual packet theorem.

## Form symmetry checked with both indices free

For `R=A_b partial_Ka+C_ab`, `A_b^*=-A_b`, compact support gives

    <u,Rv>-<Ru,v>
       =integral u^*(C_ab-C_ab^*-partial_Ka A_b)v.

The exact source R is a symmetric commutator form on its common core, so
the displayed coefficient difference vanishes and extends by density.
For the limiting form, the check is algebraic:

    C0=delta_ab H_*(L_b-I),
    A0=kappa_b[H_*,L_b],
    C0-C0^*=delta_ab[H_*,L_b]=partial_a A0.

For a unequal to b the two sides are both zero; the remaining derivative
coefficient is independent of kappa_a. For a equal to b both are
`[H_*,L_b]`. For every kernel-valued z with a kernel-valued derivative,

    Q0,ab z=H_*L_b(delta_ab z+kappa_b partial_a z).

The term `-delta_ab H_*z` vanishes. The term
`-kappa_b L_b H_*partial_a z` vanishes. These are separate uses of the
kernel property, and yield the main note's all-nine pairing identity.
This verifies root's index proposal rather than assuming it from its
analogy with the diagonal formula. It does not establish a nonzero
off-diagonal residual norm.

## Normalization, time scale, and small-time matching

The unscaled source alpha at physical time s/lambda is a_lambda(s,kappa)
without an additional lambda factor: the q Jacobian cancels the preparation
amplitude. In the forced correction, the rescaling factors are

    lambda^-1/2 * c0 lambda^3/2 * lambda^-1 = c0.

The remaining divisor is the initial global n_lambda. The residual's
derivative coefficient acquires exactly one lambda^-1 from
`T_lambda partial_Ka=lambda^-1 partial_a T_lambda`. These two identities
are the normalization and time-power checks for X9 and X27.

At small tau, the fixed-time limiting solution has

    z(tau)=i c0 tau a0 zeta/sqrt(I0)+O(tau^2) in H1_kappa.

Applying the diagonal Q0 and the exact previously checked identity
`H_*L_b zeta=(epsilon^2/3-sin(q_b)^2)c/sqrt(I0)` gives

    Q0,bb z(tau)/tau
      ->i c0 (epsilon^2/3-sin(q_b)^2)c
                     partial_b(kappa_b a0)/I0 = Gamma_b.

This matches T17's sign, both powers of sqrt(I0), the full-torus
normalization c0, and the derivative of the actual normalizable envelope.
The new fixed-time vector limit is therefore consistent with the
independently checked shorter-time and small-fixed-time statements. This
matching is a consistency check, not an independent proof of the new limit.

## Expectation checked with weaker topology

Write `d=W_lambda-z`. Without using convergence of d's derivative,

    <W_lambda,Q0 W_lambda>-<z,Q0 z>
       =<d,Q0 W_lambda>+<Q0 z,d>.

Uniform H1 bounds make Q0 W_lambda bounded, while strong L2 convergence
makes both pairings vanish. The coefficient error
`<W_lambda,(Q_lambda-Q0)W_lambda>` also vanishes because Q_lambda
converges in norm from H1 to L2 and W_lambda is uniformly H1 bounded.
Thus the all-component expectation proof has a route that uses only the
undifferentiated cutoff limit plus the explicit three-factor derivative
bound X13. The stronger derivative convergence X22 is established
separately and is needed for the asserted residual-vector limit X30.

The complete physical expectation also includes v and w_phys. Its v-v
term divided by lambda is O(sqrt(lambda)); both cross terms divided by
lambda are O(lambda) after exact form symmetry moves R onto v. No
orthogonality of v and w_phys is assumed. The correction self-pairing has
the exact isometric identity
`<w_phys,Rw_phys>/lambda=<W_lambda,Q_lambda W_lambda>`.

## Verification decision and limits

No new finite matrix or torus-grid runner was selected. Such a run would
not certify the fixed-vector compact-family spectral cutoff, the physical
continuum limit, or the common-domain passage. The explicit analytic
checks above target those steps without replacing the actual model by a
finite gapped surrogate. Deterministic scripts check source identity,
preservation, and packet completeness only; their output is not a science
verdict.

No external literature or exhaustive novelty search is claimed. The prior
norm counterexample remains valid. All new scientific conclusions are
author-proved conditional proposals pending an independent source-bound
check. No numerical onset, uniform rate in lambda, growing-tau result,
arbitrary-state bound, off-diagonal norm lower bound, or physical boost
identification is supplied.
