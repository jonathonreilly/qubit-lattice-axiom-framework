# A time threshold for the supplied excluded-walk boost/current residual

2026-10-11. Author research composition by `spectral_edge_recovery`, with the
shorter-time mean-ergodic route suggested by root. Conditional supplied-model
result; selective independent review pending. This document is neither an
independent review of itself nor a framework no-go or audit verdict.

The exact smooth, globally normalized positive-positive origin-cone packets
B25–B30 do give a counterexample to an `o(lambda)` bracket bound at inverse-energy
times. More precisely, write

    R_ab = -i[D_a,J_b] - delta_ab H,
    psi_lambda(t) = exp(-itH) chi_lambda,
    c0 = (2pi)^(-3/2).

For each diagonal component b there is an explicit fixed nonzero vector
Gamma_b in the rescaled direct integral, defined in (T17), such that

    T_lambda R_bb psi_lambda(t_lambda)/(lambda^(3/2) t_lambda)
        -> Gamma_b in L2,
    whenever t_lambda -> infinity and lambda t_lambda ->0.       (T1)

Here T_lambda is an isometry defined in (T7); it does not discard the contact
tail. In particular the residual norm divided by lambda tends to the
positive number `c_b=||Gamma_b||` at `t_lambda=lambda^(-1/2)`. For each fixed
`1/2<gamma<1`, the residual is asymptotic to
`c_b lambda^(3/2-gamma)` at `t_lambda=lambda^(-gamma)`. The prior E4 bound
for `gamma<1/2` is therefore sharp in its power threshold for these packets
and this norm of the diagonal bracket.

For every fixed `0<tau<=1/32768`, a separate direct estimate gives

    liminf_(lambda->0) ||R_bb psi_lambda(tau/lambda)||/sqrt(lambda)
        >= tau c_b/2
        >= c0 (integral f) tau/(18 sqrt(6)) >0,                 (T2)

and a finite upper bound on the corresponding limsup. Thus the norm is
`Theta(sqrt(lambda))` at those fixed small inverse-energy times. No existence
of its exact limit at fixed tau is needed or claimed here. The energy
**expectation** remains in `[lambda/2,3lambda]` by conservation. An evolving
spectral-window assertion is not intended. The conclusion concerns the norm
of this supplied bracket on this preparation, not a current-expectation rate,
a many-body law, or an adopted physical boost law.

## 1. Exact premises, source identities and authorship

All paths below are relative to this external research directory unless
otherwise stated. Sources are preserved byte for byte. The receipt records
complete paths, sizes, hashes, read coverage and the published-memory copy.

| Source | SHA-256 | Role |
|---|---|---|
| `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md` | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` | B5–B30: exact operators, common domain, normal form, specified packet and energy expectation |
| `ROOT_EXCLUDED_WALK_BOOST_CURRENT_REVIEW.md` | `c019d73e57462fd5e71ff3dc0552cc49fdcf02f604184e6c779ffc7e5dacd300` | Prior independent source review; not a review of the new result |
| `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md` | `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929` | Root's E1–E16: domain propagation, full contact Duhamel formula, supported free-comparison bound |
| `EXCLUDED_WALK_EVOLVED_BOOST_REVIEW.md` | `9cd540482c4cef79471530223dbbde93d36a6ba0aded1c99becf36a68ae263b9` | This author's prior independent E review; not independent evidence for T1–T24 |
| `boost_current_inverse_energy/sources/PUBLISHED_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md` | `3954606703f9a66665fb1ee9a27079f7f14e5183f28a8511a38743ef5d455aa1` | Prior published derivation of the physical kernel and I0; both are rederived here and are not logical premises |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | D12–D14 bounded current expansion; D8–D11 were examined for the preserved longer route, but are not needed by the main proof |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Prior review of the fixed-vector gapless limit; not a license to apply it to arbitrary lambda-dependent packets |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Fixed symmetric energy placement underlying B9; unchanged prior complete coverage reused |

The B source specifies the model and preparation. The memory source records
an earlier derivation of zero-space identities rederived below; its existing
review does not cover this proof. Root authored E and suggested the growing
time `lambda t->0` mean-ergodic route, and then the folded-cube bound on I0.
This author checked that bound, derived the full-torus coupling, rescaled
bracket and forcing, derivative estimates and fixed-tau lower bound, and
wrote the controls. Root's
initial suggestion that a zero-mode phase might matter was a question, not
evidence. No independent review of this composition has yet been performed.

The lattice, pair sector, generator clock, contact rule, total-momentum chart,
canonical local energy placement and preparation are supplied premises. No
registered native primitive is needed or adopted for this dimensionless
conditional calculation. Neither the cited notes' status nor this result is
promoted to formally retained status by the author controls.

## 2. Hilbert space, operators and domains

Take `0<lambda<=1/16`, with indices a,b,j in {1,2,3}. Use the full
relative torus with `dmu=dq/(2pi)^3` and total-momentum measure
`dK/(2pi)^3` in a fixed chart about zero. Spin is `C^2 tensor C^2`. The
normalized constant singlet is c; set `C=|c><c|`, `P=I-C`, and

    h_1=sigma_1.sin(K/2+q),  h_2=sigma_2.sin(K/2-q),
    H0(K,q)=h_1+h_2,  H(K)=P H0(K)P on ran P,
    h(K)=H0(K)c=2 sum_j cos(K_j/2) sin(q_j) T_j,
    h_b(K)=-sin(K_b/2) sin(q_b) T_b,  T_j=sigma_(1,j)c.

Even singlet and odd triplet coefficients implement antisymmetry. There is
no half-torus factor or additional exchange normalization. P is one fixed
full-torus contact projection in each fiber and is independent of K.

For the source's symmetric energy first moment, use the common smooth
antisymmetric domain, periodic in q, compactly supported in K and in ran P:

    D_a=i(H partial_Ka + Dcal_a),
    Dcal_a=P[(H_Delta/2) partial_qa + partial_Ka H0]P,
    H_Delta=h_1-h_2,
    J_b=P[sin K_b cos(2q_b)]P-|h_b><h|-|h><h_b|.              (T3)

`Dcal_a` here is the source B7 fiber differential operator. It is distinct
from the bounded operator `L_b` below. The exact source normal form is

    R_ab = C_ab(K)+A_b(K) partial_Ka,
    A_b=[H,J_b],
    C_ab=delta_ab P(ell_a-H0)P+B_ab,
    ell_a=h_1 cos(2k_(1,a))+h_2 cos(2k_(2,a)).                (T4)

For completeness, the bounded constant contact coefficient is

    r_b=sin K_b cos(2q_b)c,   r_(b,a)=partial_Ka r_b,
    F_b=-|h_b><h|-|h><h_b|,   F_(b,a)=partial_Ka F_b,
    B_ab=-|h_a><r_b|-|h><r_(b,a)|+H F_(b,a)
         -|Dcal_a h_b><h|-|Dcal_a h><h_b|
         +|h_b><Dcal_a^dagger h|+|h><Dcal_a^dagger h_b|,
    Dcal_a^dagger=-P(H_Delta/2) partial_qa P.

All form factors in this formula are smooth. The displayed q derivatives
act only on those form factors, not on the input. Consequently A_b,C_ab are
bounded operators with smooth K dependence, and (T4) extends continuously
from the common domain to sections in `H1_K(L2_q)`. For `|K|<=lambda/4`, the
source bounds, now applied globally in q, give

    ||A_b||<=12lambda,  ||C_ab||<=32,
    ||R_ab w||<=32||w||+12lambda||partial_Ka w||.              (T5)

The source's smaller support-volume estimates must not be applied to a
contact tail or to the actual evolved state. They will be used only for
the free comparison in (T10).

For every fixed lambda and finite physical t, the actual state is in the
common smooth domain: H0 is a smooth multiplier, P is fixed, and all
commutators with q derivatives and all K derivatives are bounded. Duhamel
iteration propagates every finite Sobolev order. Nothing in this proof
requires bounds on those orders uniform in t or lambda, nor exponentiation
or essential self-adjointness of the unbounded D_a.

## 3. The specified normalized packet and its exact contact amplitude

Retain exactly the B25–B30 functions. The nonnegative, smooth, real F has
Lebesgue L2 norm one, support `|kappa|<=65/512<1/4`, and
`||partial_(kappa_b)F||<=M=192/7`. It is obtained by convolving the normalized
product of `p(8sqrt(3) kappa_j)`, where `p(t)=(1-t^2)^2` on `|t|<1`
and is zero outside, with the normalized positive radial mollifier
`exp[-1/(1-512^2|y|^2)]` on `|y|<1/512`, zero outside. One global L2
normalization follows convolution. The source's translation bound gives M.

The real f is the positive Lebesgue L2 normalization of

    exp[-1/((|x|-5/8)(3/4-|x|))],   5/8<|x|<3/4,

and is zero elsewhere. It is even and smooth. Write `m_f=integral f>0`.
Let Pi_++ be the product of the two positive Pauli projectors, and set

    u_lambda=(2pi)^3 lambda^-3 F(K/lambda) f(q/lambda) Pi_++ c,
    Z_lambda=||u_lambda||,  phi_lambda=u_lambda/Z_lambda,
    n_lambda=||P phi_lambda||,  chi_lambda=P phi_lambda/n_lambda. (T6)

Both Z_lambda and n_lambda are global scalars over K and q. They have no K
derivative. These are normalizable smooth packets, with a fixed finite
spread in the rescaled K variable; no direction delta or fixed fiber is
substituted. The physical chi includes the contact subtraction on the
entire relative torus.

For `K=lambda kappa,q=lambda x`, define

    e_lambda=(|sin(lambda(x+kappa/2))|
                     +|sin(lambda(x-kappa/2))|)/lambda,
    w_lambda=||Pi_++(lambda kappa,lambda x)c||^2.

On the support, `1/4<=w_lambda<=1/2`, `1<=e_lambda<=2`, and

    Z_lambda^2=integral |F(kappa)|^2 |f(x)|^2 w_lambda dkappa dx
        in [1/4,1/2].

The six-dimensional Jacobian and `(2pi)^3 lambda^-3` in (T6) cancel exactly.
Define the isometry, extending sections by zero outside the K chart,

    (T_lambda u)(kappa,q)=lambda^(3/2)/(2pi)^(3/2) u(lambda kappa,q),
    T_lambda: L2(dK/(2pi)^3 dmu) -> L2(dkappa dmu).             (T7)

All states and comparisons considered here retain the fixed compact kappa
support of F. The full q torus is unchanged by T_lambda.

The exact free contact coefficient at physical time s/lambda is

    a_lambda(s,kappa)
      =<c,exp[-i(s/lambda)H0(lambda kappa)]phi_lambda(lambda kappa)>
      =F(kappa)/Z_lambda integral f(x) w_lambda(kappa,x)
                                      exp[-is e_lambda(kappa,x)] dx. (T8)

In this inner product the q measure is normalized. Its lambda^3 Jacobian
cancels the lambda^-3 preparation factor; the `(2pi)^3` cancels as well.
In particular a_lambda is order one in each rescaled fiber. Its L2_K norm
still has the factor `lambda^(3/2)/(2pi)^(3/2)`.

The two momenta `x+/-kappa/2` are separated from zero by 1/2. The scaled
sines extend smoothly to lambda=0 on these compact supports. Thus, on any
fixed finite s interval, a_lambda and its kappa derivatives through order
two, including their first s derivatives, converge uniformly to

    e=|x+kappa/2|+|x-kappa/2|,
    w=[1+(x+kappa/2).(x-kappa/2)/(|x+kappa/2||x-kappa/2|)]/4,
    Z0^2=integral |F|^2 |f|^2 w,
    a(s,kappa)=F(kappa)/Z0 integral f(x) w(kappa,x) exp[-is e] dx,
    a0(kappa)=a(0,kappa),   N=m_f/Z0.                          (T9)

Only one kappa derivative is needed below. Also, exactly,
`n_lambda^2=1-lambda^3 c0^2 ||a_lambda(0)||^2_L2(dkappa) ->1`.
The packet's conserved physical energy expectation lies in
`[lambda/2,3lambda]` by B30; projection does not preserve an exact free band.

## 4. Exact contact forcing and the free-comparison remainder

Let `f_free(t)=exp(-itH0)phi_lambda`, `v(t)=P f_free(t)/n_lambda`, and
`w_phys(t)=psi_lambda(t)-v(t)`. The name w_phys is unrelated to the
projector weight w in (T9). Keep the same initial n_lambda at all times.
The comparison v need not have norm one later. Direct differentiation gives

    i partial_t v=H v+h alpha(t)/n_lambda,
    alpha(t,K)=<c,f_free(t,K)>,
    w_phys(t)= i/n_lambda integral_0^t exp[-i(t-s)H]h alpha(s) ds.

The sign is positive: `i partial_t(psi-v)=H(psi-v)-h alpha/n_lambda`.
This identity retains both the initial full-torus tail and all its forcing.

The source's supported bounds apply to f_free and its K derivative, since
free evolution preserves the relative support. With
`eta<=lambda^(3/2)/4`, `B_a=lambda||partial_Ka phi_lambda||<60`, E13 gives

    ||R_ab v(t)||
       <=[4lambda^3+eta(32+12B_a+12lambda t)]/n_lambda.         (T10)

The `8eta` multiplier contribution inside this expression is the bound on
the full-torus contact subtraction. For `t->infinity,lambda t->0`, division
by `lambda^(3/2)t` makes (T10) vanish. At `t=tau/lambda` with fixed tau,
division by sqrt(lambda) makes it vanish. Thus a nonzero limit or lower
bound for the forced correction at those scales cannot be canceled by v.
This is a norm estimate on the full free comparison, not an orthogonality
assumption between its pieces.

Set `U_lambda(r,kappa)=exp[-ir H(lambda kappa)/lambda]`. Exactly,

    W_lambda(tau):=lambda^(-1/2) T_lambda w_phys(tau/lambda)
       = i c0/n_lambda integral_0^tau U_lambda(tau-s,kappa)
                              h(lambda kappa) a_lambda(s,kappa) ds. (T11)

## 5. The full physical zero space and elementary averaging

Put `s_j=sin q_j`, `epsilon=|s|`, `v0=sum_j s_j T_j`, `v_b=s_b T_b`,
`H_*=H(0)`, and

    I0=integral dmu/(4epsilon^2),
    zeta=v0/(2epsilon^2 sqrt(I0)),  ||zeta||=1,
    1/12<=I0<=9/8.

For completeness, fold the eight periodic copies into
`Q=[-pi/2,pi/2]^3`. Concavity of sine gives
`|sin q_j|>=2|q_j|/pi` on Q. Enclose Q in the radius
`R=pi sqrt(3)/2` ball and integrate its radial upper bound:

    I0 = 8/[4(2pi)^3] integral_Q 1/epsilon^2 dq
       <=1/(16pi) integral_(|q|<=R) |q|^(-2) dq
       =R/4=pi sqrt(3)/8<9/8.

This also proves finiteness at all cone points. The lower bound follows
pointwise from `epsilon^2<=3`. The following full physical kernel identities
agree with the published memory derivation, but the needed assertions and
the I0 bounds are rederived here directly from the supplied operator:

    Pi=F_transverse+|zeta><zeta|,
    H0(0) zeta=c/sqrt(I0),   H_*zeta=0,
    h0:=h(0)=2v0,   ||h0||=sqrt(6),
    Pi h0=zeta/sqrt(I0).                                    (T12)

Here F_transverse is the pointwise transverse-triplet projection, not the
packet envelope F. It kills v0. The last equality also follows from
`<zeta,2v0>=1/sqrt(I0)`. The auxiliary constant c is not a physical zero
mode. To check completeness, the singlet/triplet matrix of H0(0) is
`[[0,2s^T],[2s,0]]`. If a physical psi satisfies H_*psi=0, then
`H0(0)psi=beta c`; subtracting `beta sqrt(I0) zeta` leaves exactly a
free transverse zero vector. Conversely those vectors and zeta are killed
by H_*. This proves the full physical kernel assertion. Zeta is an L2
vector with integrable cone singularities; it need not belong to the
dipole's H1_q domain.

For the fixed vector h0 define

    M_t h0=(1/t) integral_0^t exp(-ir H_*)h0 dr.

The spectral multiplier is 1 at E=0 and
`(1-exp(-itE))/(itE)` elsewhere. Its modulus is at most one and it tends to
zero for each fixed nonzero E. Dominated convergence against the finite
spectral measure of h0 therefore proves

    M_t h0 -> Pi h0  in L2 as t->infinity.                    (T13)

This argument needs no gap, no inverse on the full complementary space,
no rate, and no assertion of operator-norm convergence.

The supplied Hamiltonian also has the global bounds, for all needed kappa,

    ||H(lambda kappa)-H_*||<=lambda |kappa|,
    ||partial_(kappa_a) H(lambda kappa)||<=lambda,
    h(lambda kappa)=h0+O(lambda^2) in C1_kappa(L2_q).

The first two follow directly by differentiating each Pauli symbol; each
one-body directional derivative has norm at most half the direction norm.
Consequently, with `U_*lambda(r)=exp(-ir H_*/lambda)`,

    ||U_lambda(r,kappa)-U_*lambda(r)||<=r |kappa|,
    ||partial_(kappa_a) U_lambda(r,kappa)||<=r.               (T14)

These are bounded-operator Duhamel estimates. Differentiating an integral
in (T11) differentiates its propagator, form factor and source. The source
already includes both the projector and phase derivatives. No derivative
of a global normalizing constant is introduced.

## 6. Rescaled bracket and a nonzero canonical coupling

Set the bounded operator

    L_b=P cos(2q_b)P+|v_b><v0|+|v0><v_b|,
    ||L_b||<=1+sqrt(3)<3.

Taylor expansion of the exact current (T3), or D13–D14, gives in operator
norm uniformly on compact kappa sets

    J_b(lambda kappa)/lambda -> kappa_b L_b,
    A_b(lambda kappa)/lambda -> kappa_b[H_*,L_b],
    C_ab(lambda kappa) -> delta_ab H_*(L_b-I).                 (T15)

For the last identity, on the smooth core the constant term of the
commutator is `H partial_Ka J_b+[Dcal_a,J_b]-delta_ab H`.
At K=0 the operator J_b is exactly zero, so its q derivative and the fiber
commutator are zero, while `partial_Ka J_b=delta_ab L_b`. This proves the
stated identity on the core. The bounded coefficient C_ab then extends it
to all physical L2 vectors. It does not apply D_a to zeta.

For diagonal b let

    Q_(lambda,b)=C_bb(lambda kappa)
                       +[A_b(lambda kappa)/lambda] partial_(kappa_b),
    Q_(0,b)=H_*(L_b-I)+kappa_b[H_*,L_b] partial_(kappa_b).

Thus `T_lambda R_bb u=Q_(lambda,b) T_lambda u`, and Q_lambda converges in
operator norm `H1_kappa(L2_q)->L2` on the fixed support to Q_0. On that
support `|kappa|<=1/4`, its two coefficient norms obey

    ||H_*(L_b-I)||<16,
    ||kappa_b[H_*,L_b]||<6.                                 (T16)

These bounds are global in q and apply to the complete contact correction.
For a field z valued in the fixed kernel of H_*, together with its kappa
derivative, `Q_(0,b)z=H_*L_b partial_(kappa_b)(kappa_b z)`.

The two canonical finite-rank terms are essential in the following exact
calculation. Cubic symmetry gives
`<v0,zeta>=1/(2sqrt(I0))`, `<v_b,zeta>=1/(6sqrt(I0))`. Therefore

    L_b zeta=cos(2q_b) zeta+v_b/(2sqrt(I0))+v0/(6sqrt(I0)),
    H0(0)L_b zeta=[1-s_b^2+epsilon^2/3]c/sqrt(I0),
    H_*L_b zeta=(epsilon^2/3-s_b^2)c/sqrt(I0).

The constant singlet mean in the middle line is exactly `1/sqrt(I0)` and
is removed by P. Write `p_b(q)=epsilon^2/3-s_b^2`. Separate circle moments
`integral sin^2=1/2`, `integral sin^4=3/8` give
`integral p_b=0` and `integral p_b^2=1/12`.
Thus define the explicit rescaled vector

    Gamma_b(kappa,q)
       = i c0 H_*L_b zeta partial_(kappa_b)(kappa_b a0)/sqrt(I0)
       = i c0 p_b(q)c partial_(kappa_b)(kappa_b a0)/I0,
    c_b:=||Gamma_b||
       =c0 ||partial_(kappa_b)(kappa_b a0)||/(sqrt(12) I0).    (T17)

Positivity of F,f and `1/4<=w<=1/2` yields `||a0||>=N/4>0`.
For any compactly supported C1 scalar a0, integration by parts gives

    Re<a0,partial_(kappa_b)(kappa_b a0)>=||a0||^2/2,
    ||partial_(kappa_b)(kappa_b a0)||>=||a0||/2.

There is no K-boundary term. In particular

    c_b>=c0 N/(8sqrt(12) I0)>0.                              (T18)

This rules out a cancellation by the K-envelope derivative on the actual
normalizable packet. It is not a claim about a single momentum fiber.

## 7. The shorter-time asymptotic and the power threshold

Let `t=t_lambda->infinity`, `sigma=lambda t->0`. Divide the exact physical
time Duhamel formula by `lambda^(3/2)t` after applying T_lambda:

    Y_lambda = T_lambda w_phys(t)/(lambda^(3/2)t)
       =i c0/(n_lambda t) integral_0^t exp[-i(t-s)H(lambda kappa)]
                          h(lambda kappa)a_lambda(lambda s,kappa) ds.

The propagator difference from `exp[-i(t-s)H_*]` has norm at most
`lambda(t-s)|kappa|`. Its kappa derivative has norm at most
`lambda(t-s)`; the reference propagator has zero kappa derivative.
Also `h(lambda kappa)-h0=O(lambda^2)` in C1 and

    sup_(0<=s<=t) ||a_lambda(lambda s)-a0||_(C1_kappa)
          =O(lambda t)+o(1).

The latter follows from (T9) and the uniform first time derivatives of the
source. Differentiating every factor under the time integral now gives

    Y_lambda - i c0 a0 M_t h0 ->0 in H1_kappa(L2_q).           (T19)

For example, each propagator error or differentiated propagator contributes
at most a constant times `lambda t`; the form-factor error contributes
`O(lambda^2)` and the source contributes its displayed C1 error. Factors
`1/n_lambda-1` tend to zero. All kappa support lies in one compact set,
so the uniform estimates imply the stated H1 convergence. Applying (T13),

    Y_lambda -> i c0 a0 zeta/sqrt(I0) in H1_kappa(L2_q).

Combining this with (T15), (T17), and the vanishing free-comparison term
(T10) proves the vector convergence (T1). Norm continuity proves all its
stated consequences, including

    ||R_bb psi_lambda(lambda^(-1/2))||/lambda ->c_b>0,
    ||R_bb psi_lambda(lambda^(-gamma))||/
                    lambda^(3/2-gamma) ->c_b,  0<gamma<1.    (T20)

For `gamma<1/2` this is consistent with the prior little-o bound. At and
above the threshold it gives an actual lower obstruction for the same
preparation. No rate of convergence in (T13) is needed to assert this
asymptotic; a numerical onset in lambda is not supplied.

## 8. Fixed small inverse-energy times

This step proves (T2) directly and does not extrapolate (T1) to constant
`lambda t`. Fix `tau>0`. The source limits and `n_lambda->1` permit replacing
`h(lambda kappa),a_lambda,n_lambda` by `h0,a,1` in (T11), with an error
vanishing in H1_kappa. In proving this, the differentiated propagator is
bounded by tau in (T14), independently of lambda.

Compare that integral to

    V_lambda(tau)=i c0 tau a0 M_(tau/lambda) h0.

By (T13), V_lambda converges in H1_kappa to
`V(tau)=i c0 tau a0 zeta/sqrt(I0)`, and `Q_(0,b)V=tau Gamma_b`.
The following explicit source bounds hold for every `s>=0`, with
`M=192/7`, `N=m_f/Z0` and `r=1/4`:

    ||a(s)||<=N/2,             ||a(s)-a0||<=Ns,
    ||partial_b a0||<=N(M/2+1),
    ||partial_b a(s)-partial_b a0||<=Ns(M+5/2).               (T21)

Here and below these scalar norms are in L2(dkappa), and partial_b means
`partial_(kappa_b)`. To verify them, `e<=2`, `|partial_b e|<=1`, and
`|partial_b w|<=1` on the support. The last bound follows by differentiating
the two unit vectors in w, whose denominators are at least 1/2. Use
`|exp(-is e)-1|<=s e`, `||F||=1` and `||partial_b F||<=M`.
The derivative of the phase contributes the final `s/2` in `s(M+5/2)`;
it is not omitted.

Let `E_lambda=W_lambda-V_lambda`. Write the undifferentiated integrand
error as `(U_lambda-U_*lambda)h0 a0+U_lambda h0(a(s)-a0)`.
For its derivative, use

    (partial_b U_lambda)h0 a(s)
      +(U_lambda-U_*lambda)h0 partial_b a0
      +U_lambda h0(partial_b a(s)-partial_b a0).

The reference propagator has no kappa dependence. Insert (T14), (T21) and
`||h0||=sqrt(6)`; integrate `tau-s` and s separately. This gives

    limsup ||E_lambda||
        <=c0 sqrt(6) N tau^2 (r/4+1/2)
         =c0 sqrt(6) N tau^2 (9/16),
    limsup ||partial_b E_lambda||
        <=c0 sqrt(6) N tau^2
             [1/4+r(M/2+1)/2+(M+5/2)/2]
         =c0 sqrt(6) N tau^2 (13/8+9M/16).                  (T22)

Every norm here is the full rescaled direct-integral norm. Terms from the
vanishing replacements in (T11) are already included as zero in the
limsup. No physical state is assumed to stay corner-supported.

The W_lambda are uniformly H1 on this finite time interval, so the
coefficient convergence (T15), bounds (T16), and (T10) yield

    limsup ||lambda^(-1/2) T_lambda R_bb psi_lambda(tau/lambda)
                                        -tau Gamma_b||
      <=c0 sqrt(6) N tau^2
          [16(9/16)+6(13/8+9M/16)]
       =c0 sqrt(6) N tau^2 (3117/28)
       <112 c0 sqrt(6) N tau^2.                             (T23)

This is an error about a specified vector, not an assertion that the left
hand vector has a limit. The leading vector lies in the physical zero
space before applying Q_0; the error generally does not. This is why the
full coefficient bounds 16 and 6 are used. Applying only the restriction
of Q_0 to zero-space errors would be unjustified.

For `tau<=1/32768` and `I0<=9/8`,

    112 sqrt(6) tau <= 1/(16sqrt(12) I0).

Indeed the worst-case product on the left after rearrangement is
`12096 sqrt(2)/32768<1`. With (T18), the error in (T23) is at most
`tau c_b/2`. Norm inequalities prove

    tau c_b/2 <= liminf ||R_bb psi_lambda(tau/lambda)||/sqrt(lambda)
       <= limsup ||R_bb psi_lambda(tau/lambda)||/sqrt(lambda)
       <=tau c_b+112c0 sqrt(6)N tau^2.                       (T24)

Finally `Z0<=1/sqrt(2)` implies `N>=sqrt(2)m_f`; (T18) and
`I0<=9/8` give the explicit second lower bound in (T2). This completes
both claimed time regimes. At these fixed tau the energy-scaled norm
`||R_bb psi||/<H>` diverges at least as a positive multiple of
`lambda^(-1/2)`. This ratio uses the conserved positive energy expectation;
it asserts nothing about the expectation of R_bb itself.

## 9. Controls, unsuccessful routes and verification limits

`boost_current_inverse_energy/inverse_energy_controls.py` is a single author
control with full stdout/stderr and a 120-second recorded timeout. Its
baseline completed with exit 0 on Python 3.13.5, NumPy 2.4.4, SciPy 1.17.1,
and SymPy 1.14.0. The receipt binds the source, executable, versions and logs.

The exact controls separately arrange the two algebraic expressions for
`H_*L_b zeta`, retain the full-torus mean subtraction, integrate the circle
moments, and check the dilation pairing and conservative time constant.
They exercise calculations already justified above; successful assertions
are not additional mathematical premises. A separate short exact control
checks the folded-cube normalization in the new self-contained I0 proof.
The pre-amendment note, map and wording scan are preserved; the main helper
and its existing logs are unchanged.

A separate noncommuting three-vector model uses `H_*=diag(0,1,-2)`, a linear
bounded matrix B(kappa), a kappa-dependent form factor, a normalized Gaussian
scalar envelope and a kappa-dependent forcing phase. The augmented matrix
exponential is compared with the actual vector obtained by integrating the
Hermitian spectral decomposition. Its kappa derivative uses the exponential
Frechet derivative and all source factors, and is compared with a five-point
derivative of that independently computed integral. The baseline vector
error was about `1.1e-15`, derivative error about `4.9e-12`. Shorter-time and
fixed-tau sequences resolve the corresponding kernel responses in this
finite model. This gapped fixture is not a torus discretization and supplies
no continuum convergence rate or theorem.

Three separate source files, each with exactly one literal replacement,
actually failed: omitting the current rank terms, reversing the Duhamel
source sign, and omitting the source-clock derivative. Their complete
sources, stdout, tracebacks, command metadata and exit codes are preserved.
These failures show that the selected controls distinguish these errors;
they are author consistency evidence, not selective independent review.

Routes that were insufficient or deliberately not used are preserved:

- Substituting `t=tau/lambda` into the prior E2 bound gives only an upper
  `O(sqrt(lambda))` estimate. It cannot prove a counterexample.
- Isolating the initial physical zero projection loses its cancellation
  with the free component at t=0. The exact forced comparison is necessary.
- A fixed K fiber or a direction delta does not meet the requested
  normalizability condition. Equations (T6)–(T9) use the actual packet.
- An L2 limit alone cannot pass through `A_b partial_Ka`. Equations
  (T19) and (T22) explicitly control the kappa derivative.
- An inverse on the whole gapless complement, or operator-norm averaging
  over its unit ball, is not available. The proof uses one fixed vector
  and its finite spectral measure instead.
- Zeta is singular. Applying D_a to it would exceed the demonstrated
  domain. Only bounded coefficients of the exact normal form act on it.
- A longer forced effective-dynamics route was worked out before root's
  mean-ergodic suggestion. Its analysis and proposed stronger fixed-tau
  convergence are preserved in
  `boost_current_inverse_energy/FIXED_TAU_ROUTE_NOT_USED.md`; no assertion
  from that file is needed or certified by this note. The simpler main
  proof uses the more conservative interval `tau<=1/32768`.

The prior `gamma<1/2` estimate has `lambda t->0`: it does not reach an
order-one rescaled energy-time. T20 locates a norm obstruction earlier,
while T24 reaches specified fixed positive rescaled energy-times. No claim
is made at arbitrary tau, for a different packet, for all low-energy
vectors, for boost/boost closure, or for a many-body or gravity algebra.
Other phases or contact-orthogonal preparations can have a different
forcing coefficient. The model clock and physical interpretation remain
supplied, and independent scientific review of T1–T24 remains open.

## 10. Scoped negative-claim discipline

This is a conditional counterexample inside a specified positive asymptotic
calculation. It does not close all routes to a boost law. The following
records the N1–N8 checks without claiming a formal negative-packet PASS or
retained authority for the newly authored proof.

**N1, actual cancellation/admissibility attacks.** Five mechanisms were
examined analytically: (i) spectral phase cancellation of the fixed contact
forcing, resolved at the asserted times by T13/T19/T22; (ii) vanishing
preparation contact amplitude, resolved for this positive F,f and Pi_++ by
T9/T18; (iii) cancellation by the canonical finite-rank current terms,
resolved by the full polynomial calculation preceding T17; (iv) cancellation
by K differentiation of the packet envelope, resolved by the compact
integration-by-parts identity; and (v) failure of global normalization or
admissible commutator domain, resolved for each finite lambda,t by T3–T11
and the bounded normal-form extension. Each was ATTEMPTED in this cycle.
These are concrete mechanisms, not an exhaustion claim. Their closure
here rests on a new author proof with cited source premises; it has not
received retained authority. A route count is not evidence of validity.

**N2, condition relationships.** No multiple independent-wall count is
asserted. The supplied Hamiltonian, contact rule, current/dipole placement,
packet and clock jointly specify one conditional theorem. They are not
presented as mutually independent obstacles to other research programs.

**N3, hidden hypotheses.** “Canonical” means exactly T3 from the specified
symmetric placement. “Physical” means ran P, excluding the auxiliary c.
Global normalization means T6/T8, not per-fiber normalization. Smoothness
and fixed support are explicit; the singular limit is used only through
bounded operators. The positive F,f choice and positive-positive band are
load-bearing for `a0` and are not silently generalized.

**N4, exact residual matching.** The source's mixed-band prepared-state
counterexample and the degenerate note's dressed-state current response
concern different preparations/observables. Neither is a negative witness
for T1 or T2. E1 matches the exact R_ab definition and is used as an identity;
its earlier upper bound is not a lower-bound witness. Only this note's new
norm calculation supplies the present obstruction.

**N5, resolution.** The assertions concern the normalized direct integral
for each diagonal component b and the explicit time regimes above. They
are not per-mode statements or operator-norm statements on a spectral
window. No negative assertion is made for untested current expectations,
other off-diagonal components or all packets.

**N6, alternatives.** Changing envelope phases, imposing contact
orthogonality, testing weaker observables, or changing the energy placement
changes the terminal question. Those are open alternatives; this result
neither requires a new axiom nor rules them out. No primitive absence is
used as a premise.

**N7, strongest challenge.** A small L2 contact correction could have a large
or canceling K derivative, and a fixed-fiber zero-mode argument could fail
after true global normalization. The terminal obligation is therefore a
full direct-integral H1 estimate followed by the complete R normal form,
not a zero-mode overlap heuristic. T7–T11, T19 and T22–T23 address those
specific mechanisms. For larger fixed tau, phase cancellation remains
unresolved and is outside the asserted interval.

**N8, prior echoes.** A bounded read-only search of the stored main and
working-tree refs for boost/inverse-energy/zero-space/current combinations
is recorded in `boost_current_inverse_energy/bounded_search.json`. It
found no matching doc line. This
is not a repository-wide or literature novelty claim. The nearby mixed-band
and dressed-current constructions were read and distinguished as in N4;
no old framework wall or its retirement is inherited by this counterexample.

The entire packet remains external research evidence, with no repository,
editable prompt, original source, prior review, audit status or physical
primitive changed. The next scientific gate is an independent check of
this authored theorem and its hypotheses.
