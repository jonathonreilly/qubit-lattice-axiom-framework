# Independent reconstruction of T1–T24

Target: all 658 lines of `BOOST_CURRENT_INVERSE_ENERGY_PROBE.md`, SHA-256
`76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990`.
Written before opening the new author's helpers, logs, completion evidence or
receipt. The note itself discloses proposed formulas and control outcomes;
this is independent mathematical checking, not blinded discovery.

## Source and hypothesis boundary

The exact B source (`903261f5...1923`) was read completely in the immediately
preceding review and its identity was rechecked. Here the necessary normal
form, global versus supported estimates, and B25–B30 packet construction were
reconstructed anew. The exact E source (`d8961198...fd929`) was read completely
in this task. The canonical source (`79bc9fb3...77fe`) was previously read at
unchanged bytes; its placement and contact calculation remain explicit.

The new argument supplies its own kernel, I0 and current-expansion proofs.
No prior memory/degenerate-dynamics theorem is required. The supplied model is
the bounded sine-Pauli Hamiltonian on the antisymmetric pair Hilbert space,
one full-torus contact projection P, fixed symmetric energy placement,
coordinates, clock and the specified positive envelopes/projector packet.
The conclusions concern the norm of R_bb on this actual normalized family.
They do not quantify over all low-energy states or assert a physical boost
law, current-expectation lower bound, many-body consequence or audit status.

## A. Complete bracket normal form and domain

With H=PH0P and D=i(H partial_Ka+Dcal_a), direct differentiation gives

    -i[D_a,J_b]-delta_ab H
      =H partial_Ka J_b+[Dcal_a,J_b]-delta_ab H
           +[H,J_b] partial_Ka.

For the canonical J_b=P g_b P+F_b, the free scalar-current bracket is
delta_ab ell_a. The two dipole contact blocks are

    C D0,a P psi=i c<h,partial_Ka psi>,
    P D0,a C(c f)=i partial_Ka(h f).

Inserting them into the compressed g bracket gives

    delta_ab P ell_a P
      -partial_Ka(h<r_b,psi>)+r_b<h,partial_Ka psi>.

Its derivative coefficient is -|h><r_b|+|r_b><h|; its constant part is
-|h_a><r_b|-|h><r_(b,a)|. Adding F_b gives
[H,F_b]partial_Ka+H F_(b,a)+[Dcal_a,F_b]. Expanding the latter rank terms
uses the q-fiber adjoint Dcal_a^dagger=-P(Hdelta/2)partial_qa P and produces
exactly the four final terms of B_ab in T4. Thus T4 contains the full first
K derivative and every bounded constant term; no input q derivative remains.

All these form factors lie in ran P, including those obtained using Dcal
or its fiber adjoint, so A_b and B_ab annihilate c. Their coefficients are
smooth in K in bounded-operator norm. Their finite-rank expressions therefore
extend the core formula to H1_K(L2_q). The source's full-torus term sums are
(85/8)lambda<12lambda for A_b and
17+(39/8)lambda+(5/32)lambda^2<24 for B_ab. Since ||ell_a-H0||<=8,
T5 follows with C_ab bounded by 32. The stronger supported-input versions
carry an additional support-volume factor; that factor is not available on
arbitrary evolved states or on the global contact tail.

H is bounded self-adjoint on the fixed physical space. P is K independent,
preserves every Sobolev space and commutes with q differentiation on periodic
sections. H0 and all its differentiated coefficients are smooth bounded
multipliers. Thus the propagator preserves each finite Sobolev order for each
finite lambda,t and preserves the compact K support. This proves the actual
states are in the claimed common smooth domain; no uniform high-order bound
or self-adjoint extension of D is needed.

## B. Normalization, scaling and the source amplitude

The B25 polynomial integrals are int p^2=256/315 and int(p')^2=256/105.
After scaling by 8 sqrt(3), each derivative norm of F0 is 24. Convolution
with the positive L1-normalized radius-1/512 mollifier changes its L2 norm
by at most 24 sqrt(3)/512<1/8. Normalization gives M=192/7 and support
radius 65/512<1/4. F is nonnegative, real and smooth. The annular f is
positive, even, smooth, has finite positive integral m_f and L2 norm one.

On the preparation support, |q +/- K/2| lies between lambda/2 and
7lambda/8. The two projectors are smooth there. Their ++ singlet weight
is between 1/4 and 1/2, because the dot product of sin(q+K/2) and
sin(q-K/2) is epsilon(q)^2-epsilon(K/2)^2>0. Their positive energy sum
lies between lambda and 2lambda. Both normalized momentum measures supply
lambda^6/(2pi)^6 after the two changes of variables; the square of the
prefactor (2pi)^3 lambda^-3 cancels it. Thus T6 is a genuine globally
normalized direct-integral family, and 1/2<=Z_lambda<=1/sqrt(2).

The even relative envelope and exchange covariance of Pi_++ supply
antisymmetry. P removes the one full-torus singlet average; it does not
preserve relative support. Both Z_lambda and n_lambda are global numbers,
so differentiating in K or kappa does not differentiate either.

T_lambda is an isometry since lambda^3 d kappa=dK and its squared
prefactor is lambda^3/(2pi)^3. Only K is rescaled; q remains the full
torus. Also T_lambda partial_Ka=lambda^-1 partial_kappaa T_lambda on
the compact-support Sobolev sections used below.

For the free ++ state, the normalized q integral at q=lambda x cancels
exactly the lambda^-3 and (2pi)^3 in the preparation. It gives T8 with
no remaining lambda or exchange factor. Consequently

    ||C phi_lambda||^2
       =lambda^3 c0^2 ||a_lambda(0)||^2_(L2 d kappa),
    n_lambda^2=1-lambda^3 c0^2||a_lambda(0)||^2 ->1.

The scaled vectors sin(lambda(x +/- kappa/2))/lambda extend smoothly to
lambda=0 and are bounded away from zero on the fixed support. Norms,
projectors, e_lambda and w_lambda therefore converge with all needed kappa
derivatives uniformly there. Integration against fixed smooth f and the
positive lower bound on Z_lambda prove the stated C1 convergence of
a_lambda, uniformly on each finite rescaled time interval. The first time
derivatives are also uniformly bounded. The source's C2 claim follows by
the same smooth compact-support argument, although the theorem uses C1.

## C. Exact forced comparison and removal of the free contribution

For v=P exp(-itH0)phi/n, differentiate without renormalizing in time:

    i v'=H v+h alpha/n,
    i(psi-v)'=H(psi-v)-h alpha/n,
    w_phys(t)=i/n integral_0^t exp[-i(t-s)H]h alpha(s) ds.

The plus i in the last equation is correct. Both initial vectors agree,
so there is no separate uncanceled homogeneous initial tail term. The full
contact tail and every subsequent forcing term are contained in this identity.

Free evolution preserves the small relative support. Its scaled K derivative
norm is bounded by B_a+lambda t because ||partial_Ka H0||<=1. Applying
the supported normal-form bounds to that free input and retaining the
global multiplier tail gives

    ||R_ab v(t)|| <= [4lambda^3+eta(32+12B_a+12lambda t)]/n.

This is T10/E13 with the same original n. In the intermediate regime,
division by lambda^(3/2)t gives terms bounded by a constant times
lambda^(3/2)/t, 1/t and lambda, all vanishing. At fixed tau and t=tau/lambda,
division by sqrt(lambda) gives terms of order lambda^(5/2) and lambda.
Thus the whole free-comparison contribution vanishes in both asserted
scalings. No orthogonality or cancellation hypothesis is used.

Multiplying the exact Duhamel expression by T_lambda and changing physical
time to s/lambda proves T11: lambda^-1/2 times the isometry factor
lambda^3/2 and the time Jacobian lambda^-1 cancel. Its forcing is
`i c0 U_lambda h(lambda kappa)a_lambda/n` on the full q torus.

The inherited E bound is compatible with this calculation. Its differentiated
forcing has three terms: differentiation of U, h and alpha. They give
eta[3t^2+3B_a t/lambda+lambda t/8]/n. The global R bound then yields E14
and E2; on t<=lambda^-gamma with gamma<1/2 this is o(lambda). That
upper estimate supplies no lower bound, but is the correct earlier threshold
comparison in the new claim.

## D. Full zero space and I0

At K=0 write the singlet/triplet decomposition of H0 as

    [[0,2s^T],[2s,0]],  s_j=sin q_j.

Its pointwise free kernel is the transverse triplet space, apart from the
measure-zero cone points. If a physical psi is killed by PH0P, then
H0 psi=beta c with a scalar constant in q. Its singlet component must vanish
almost everywhere, and its longitudinal triplet component is beta s/(2epsilon^2).
Subtracting beta sqrt(I0) zeta leaves precisely a transverse free zero vector.
Conversely both this zeta and transverse vectors are killed by PH0P. They
are orthogonal, and zeta lies in the physical antisymmetric sector. This
establishes the full physical kernel projection, not merely one zero vector.
The excluded auxiliary c is not counted as a physical kernel vector.

The norm of zeta equals one because
int epsilon^2/(4epsilon^4 I0) dmu=1. Folding the pi-periodic sine squares
into Q=[-pi/2,pi/2]^3 gives factor 8. Concavity gives
epsilon^2>=4|q|^2/pi^2, hence

    I0 <= [8/(4(2pi)^3)](pi^2/4)
             integral_(|q|<=pi sqrt(3)/2) |q|^-2 dq
       =pi sqrt(3)/8<9/8.

The radial integral is finite in dimension three and bounds every cone
singularity. The elementary lower bound is 1/12 from epsilon^2<=3.
Thus no unproved lattice Green-function constant is imported.

H0 zeta=c/sqrt(I0), h0=2v0 and ||h0||=sqrt(6). The transverse projection
kills v0, while <zeta,h0>=1/sqrt(I0), proving Pi h0=zeta/sqrt(I0).
The vector is L2; no H1_q regularity is used or assumed.

For this fixed h0, the mean propagator has spectral multiplier one at zero
and (1-exp(-itE))/(itE) elsewhere. Its modulus is <=1 and its nonzero-energy
part tends pointwise to zero. Dominated convergence against the finite
spectral measure of h0 proves T13. No gap, inverse on the complement,
convergence rate or operator-norm averaging assertion is required.

## E. Uniform bounded coefficients and the nonzero coupling

The Lipschitz bound for the sine-Pauli symbol gives
||H(lambda kappa)-H_*||<=lambda|kappa| and
||partial_kappaa H(lambda kappa)||<=lambda. Bounded-operator Duhamel gives
T14, including ||partial_kappaa U_lambda(r)||<=r. The contact vector has
h(lambda kappa)=h0+O(lambda^2) in C1 because its cosines are even.

Expanding the exact current at K=0 gives

    partial_Ka J_b(0)=delta_ab L_b,
    L_b=P cos(2q_b)P+|v_b><v0|+|v0><v_b|.

Indeed h_b=-(K_b/2)v_b+O(|K|^3) and h=2v0+O(|K|^2), so both rank
terms have the positive coefficient shown. Their norm sum is at most
2||v_b||||v0||=sqrt(3), hence ||L_b||<=1+sqrt(3)<3.

J_b(0)=0 as an operator, so [Dcal_a,J_b] vanishes there on the smooth core.
The bounded normal-form coefficient therefore has limit
delta_ab H_*(L_b-I). Also A_b(lambda kappa)/lambda tends in norm to
kappa_b[H_*,L_b]. This proves T15 without applying D to a singular vector.
Finite-rank smoothness makes the convergence uniform on the compact support.
It follows that Q_lambda->Q_0 in operator norm H1_kappa(L2_q)->L2.

The conservative coefficient bounds are ||H_*||||L_b-I||<4*4=16 and
|kappa_b|*2||H_*||||L_b||<(1/4)*2*4*3=6. For a kernel-valued field z
whose kappa derivative is kernel-valued, Q_0 z=H_*L_b partial_b(kappa_b z).

Cubic symmetry gives <v0,zeta>=1/(2sqrt(I0)) and
<v_b,zeta>=1/(6sqrt(I0)). Applying H0 to the complete L_b zeta gives

    [1-2s_b^2+s_b^2+epsilon^2/3]c/sqrt(I0).

The mean of this scalar is one. Removing it with P leaves
p_b c/sqrt(I0), p_b=epsilon^2/3-s_b^2. Independent circle means are
E(sin^2)=1/2 and Var(sin^2)=1/8, so E p_b=0 and
E p_b^2=(1^2+1^2+(-2)^2)/(9*8)=1/12. This checks the full canonical
rank correction and the global mean subtraction in T17.

Since a0>=N F/4 pointwise, ||a0||>=N/4>0. Compact integration by parts
gives Re<a0,partial_b(kappa_b a0)>=||a0||^2/2. Cauchy–Schwarz then gives
||partial_b(kappa_b a0)||>=||a0||/2. The packet derivative cannot cancel
the coupling. Thus Gamma_b and its norm are exactly T17, with
c_b>=c0 N/(8sqrt(12)I0)>0. Every factor acts in L2_q with one kappa
derivative only; no D_a zeta operation has entered the proof.

## F. Intermediate-time H1 convergence

Let t->infinity and sigma=lambda t->0. In Y_lambda of T19, replace the
actual propagator by exp[-i(t-s)H_*]. The operator error is bounded by
lambda(t-s)|kappa| and its kappa derivative by lambda(t-s). After averaging
over t, both errors are O(lambda t). Replace h by h0 at C1 cost O(lambda^2).
Uniform source convergence and its bounded time derivative give

    sup_(0<=s<=t)||a_lambda(lambda s)-a0||_C1
       <=o(1)+O(lambda t).

Differentiating the product includes the propagator, h and a factors.
Each error vanishes by these same bounds; n_lambda->1 introduces only a
scalar vanishing factor. Uniformity on one compact kappa support converts
these bounds to H1_kappa(L2_q). The remaining expression is
i c0 a0 M_t h0. Its H1 convergence follows from T13 because both a0 and
its derivative are fixed scalar functions. Hence

    Y_lambda -> i c0 a0 zeta/sqrt(I0) in H1_kappa(L2_q).

This supplies exactly the topology required by the unbounded first-order
bracket. Uniform boundedness/convergence of Q_lambda, its action on this
limit, and the vanishing entire free comparison prove the vector limit T1.
Norm continuity gives T20 for every 0<gamma<1. In particular gamma=1/2
has residual/lambda->c_b>0, and gamma>1/2 gives a growing residual/energy
scale. The proof does not substitute a fixed fiber or rely on a numerical
onset. It does not extend this limit to fixed nonzero lambda t.

## G. Separate fixed-small-tau lower bound

For fixed tau, ||partial_b U_lambda(r)||<=r<=tau and uniform source C1
convergence justify replacing h(lambda kappa),a_lambda,n_lambda by h0,a,1
in W_lambda with vanishing H1 error. The W_lambda are uniformly H1.
Set V_lambda=i c0 tau a0 M_(tau/lambda)h0. It converges in H1 to
V=i c0 tau a0 zeta/sqrt(I0), so Q_0 V=tau Gamma_b.

The continuum phase and weight have e<=2, |partial_b e|<=1 and
|partial_b w|<=1; the last follows by differentiating the two unit vectors
whose lengths are >=1/2 (in fact the crude bound 1/2 suffices). Differentiating
the source and its phase gives all four T21 estimates. In particular
the derivative of a(s)-a0 has three contributions bounded by
Ns M, 2Ns, and Ns/2, yielding Ns(M+5/2).

After the vanishing replacements, W_lambda-V_lambda has integrand
(U_lambda-U_*)h0 a0+U_lambda h0(a(s)-a0). Its derivative is exactly

    (partial_b U_lambda)h0 a(s)
       +(U_lambda-U_*)h0 partial_b a0
       +U_lambda h0(partial_b a(s)-partial_b a0).

Using r=1/4 for the kappa support and integrating tau-s and s gives the
undifferentiated coefficient r/4+1/2=9/16. The derivative coefficient is
1/4+r(M/2+1)/2+(M+5/2)/2=13/8+9M/16. These prove T22 with complete
direct-integral norms and full q tails, not just a kernel projection.

Apply the full Q_0 coefficient bounds 16 and 6 to that error. Since
(Q_lambda-Q_0)W_lambda->0, the free comparison vanishes and
Q_0 V_lambda->tau Gamma_b, the final error limsup is bounded by

    c0 sqrt(6)N tau^2 [16(9/16)+6(13/8+9M/16)]
       =c0 sqrt(6)N tau^2 (3117/28)
       <112 c0 sqrt(6)N tau^2.

The error need not lie in the kernel; the proof correctly does not use
the narrower kernel formula on it. The estimate does not assert existence
of a vector limit at fixed tau.

For tau<=1/32768 and I0<=9/8, the product testing
112sqrt(6)tau <=1/(16sqrt(12)I0) is at most
12096sqrt(2)/32768<1. Hence the T23 error is at most tau c_b/2. Triangle
inequalities give exactly T24: a positive liminf and finite limsup, which
establish Theta(sqrt(lambda)) for each specified fixed tau>0. Finally

    tau c_b/2 >= tau c0 N/(16sqrt(12)I0)
       >=tau c0 m_f/(18sqrt(6)),

using Z0<=1/sqrt(2) and I0<=9/8. This verifies every constant in T2.
The energy expectation remains between lambda/2 and 3lambda by unitary
conservation of H, so the stated norm-to-energy divergence follows. It says
nothing about the expectation of R_bb itself.

## Outcome before author-evidence reading

No material error or unresolved proof step was found in T1–T24. The
noncommutative coefficient convergence, actual global packet normalization,
H1 passage, singular-vector domain boundary, full tail and fixed-tau error
are all necessary and are supplied. No additional scientific computation
was selected: the load-bearing calculations above are elementary exact
identities and uniform analytic bounds, and a finite model would not test
the gapless continuum limit. This is an analytic independent review, not
an inference from passing controls.
