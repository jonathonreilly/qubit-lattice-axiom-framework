# Independent review of the sharp-time boost/current theorem

**Result: PASS for the conditional supplied-model theorem T1–T24 at the exact
source identity below.** No material mathematical defect, required correction,
or unresolved proof obligation was found within this scope. This is a selective
independent mathematical review, not an audit verdict or retained-status action.

The complete new 658-line argument was reconstructed before opening its author's
helpers, logs or receipt. The reconstruction includes the actual normalized
direct-integral packet, the whole relative-momentum torus, the required first
momentum derivative, the full physical zero space and the fixed-small-time
constants. Passing author controls were not used to establish the theorem.

## Exact target and necessary premises

All paths below are relative to this report's directory unless specified.

| Source | SHA-256 | Role and reading coverage |
|---|---|---|
| `BOOST_CURRENT_INVERSE_ENERGY_PROBE.md` | `76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990` | Complete 658-line T1–T24 argument read and reconstructed |
| `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md` | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` | Entire 744-line source previously read at these unchanged bytes; B5–B30 normal form, domains, global/supported estimates and preparation reconstructed for this review |
| `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md` | `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929` | Complete 185-line source read; domain propagation, exact forcing and free-comparison estimate rechecked |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Complete 190-line source previously read at these unchanged bytes; canonical placement and contact structure reused |
| `boost_current_inverse_energy/receipt.json` | `0c555b37791acd590c8a8b9686ebd2697873fcffd273eb67d6ed0d8e4b9ec715` | Complete receipt inspected only after the independent analytic reconstruction |

The physical kernel and the bound on I0 are fully derived in the new note and
were independently rederived here. No assertion from the published memory note
or the earlier degenerate-dynamics review is needed for this review's proof.
The current Taylor expansion follows directly from the fixed B9 current.

## What the checked result establishes

For the specified positive origin-cone ++ packet, fixed symmetric energy
placement, sine-Pauli Hamiltonian, contact projection, coordinates and clock:

* If `t_lambda -> infinity` and `lambda t_lambda -> 0`, the complete rescaled
  vector `T_lambda R_bb psi_lambda/(lambda^(3/2)t_lambda)` converges to the
  explicit nonzero vector Gamma_b in T17.
* At `t=lambda^(-1/2)`, the residual norm divided by lambda tends to
  `c_b=||Gamma_b||>0`. Together with the earlier uniform `o(lambda)` estimate
  for powers below 1/2, this supplies the claimed sharp power threshold for
  this family.
* For each fixed `0<tau<=1/32768`, the residual at `t=tau/lambda` is
  `Theta(sqrt(lambda))`. The checked lower bound is
  `liminf lambda^(-1/2)||R_bb psi_lambda|| >= c0 m_f tau/(18 sqrt(6))>0`,
  with `c0=(2pi)^(-3/2)`. The upper limsup is finite.

The fixed-tau conclusion is a liminf/limsup statement; it does not assert an
exact vector limit at fixed tau or a numerical onset in lambda. Conserved
energy expectation remains in `[lambda/2,3lambda]`. This is not propagated
spectral support or a lower bound for the expectation of the bracket itself.

## Load-bearing checks

The complete derivation is in
[PROOF_RECONSTRUCTION.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_inverse_energy_review/PROOF_RECONSTRUCTION.md).
Its pre-evidence SHA-256 is
`c0a06917dc1f24207d85656781e250104c81dd613a9a937a140088149bf2f131`.

1. **Normal form, support and domains.** Direct compression gives every
   derivative and finite-rank term in T4, with `A_b=[H,J_b]` and no remaining
   derivative of the input in q. The bounded coefficients extend the bracket
   from the smooth core to `H1_K(L2_q)`. The global coefficient bounds remain
   valid on the projected and evolved contact tail. The stronger
   support-volume bounds are used only on the supported free comparison.

2. **Actual packet and complete forcing.** The two normalized momentum
   measures cancel precisely the square of `(2pi)^3 lambda^(-3)`.
   `Z_lambda` and `n_lambda` are global constants. Rescaling changes K only
   and keeps every q mode. Differentiating the projected free state yields
   the positive-i Duhamel integral with zero initial difference. Its entire
   free-comparison bracket is negligible in both asserted scalings.

3. **Full zero space without a gap.** Solving `H0 psi=beta c` identifies the
   transverse free kernel and the orthogonal normalized longitudinal zeta.
   The excluded auxiliary c is not added to the physical kernel. Folding all
   eight sine-squared cells and integrating `|q|^(-2)` over the enclosing
   three-dimensional ball gives `1/12<=I0<=pi sqrt(3)/8<9/8`.
   Fixed-vector spectral dominated convergence proves the mean-ergodic limit;
   no spectral gap, inverse on the complement, rate or operator-norm
   averaging is assumed.

4. **One derivative and the singular vector.** The actual propagator error
   and its kappa derivative are `O(lambda t)` in the intermediate regime.
   Differentiation includes the propagator, form factor, envelope and source
   phase. These yield the required `H1_kappa(L2_q)` convergence. The rescaled
   coefficient map converges in norm from this space to `L2`. The proof acts
   on zeta only with bounded fiber coefficients; no boost is applied to zeta
   and no `H1_q` regularity is attributed to it.

5. **Nonzero current coupling.** The two canonical current rank terms give
   `H_* L_b zeta=(epsilon^2/3-sin^2 q_b)c/sqrt(I0)` after the full-torus mean
   is removed. Independent circle moments give squared polynomial norm
   `1/12`. Compact integration by parts proves
   `||partial_b(kappa_b a0)||>=||a0||/2>=N/8`, excluding envelope cancellation.

6. **Separate fixed-tau estimate.** The complete error, which need not be
   kernel-valued, is controlled using the full coefficient bounds 16 and 6.
   The state and derivative constants are `9/16` and `13/8+9M/16`, with
   `M=192/7`. They give `3117/28<112`. The stated tau interval makes that
   quadratic error at most half the linear nonzero term. The final
   normalization inequality gives exactly `c0 m_f tau/(18 sqrt(6))`.

## Independent checking and author evidence

No new scientific runner was selected or run. Every load-bearing uncertainty
was resolved by the explicit analytic reconstruction; an auxiliary finite
matrix calculation cannot establish this gapless continuum limit. This choice
follows the continuous-discovery/selective-check cadence rather than adding
duplicative PASS counts.

After that reconstruction was frozen, the author's complete 221-line primary
helper, 16-line I0 helper, successful stdout/stderr and metadata, and all three
actual failed-mutation logs were read. The primary helper checks exact
polynomial/moment identities and a noncommuting three-vector forced model.
Its saved vector error is about `1.03e-15`; its derivative comparison error is
about `4.92e-12`. The model is gapped auxiliary evidence and does not establish
the actual-lattice continuum theorem. The I0 helper checks elementary
arithmetic already derived analytically.

Each failed mutant is byte-for-byte the main helper with exactly its declared
single literal replaced. Omitting current rank terms fails the coupling
polynomial assertion; reversing the Duhamel source sign fails the actual-vector
assertion; omitting the source-clock derivative fails the derivative assertion.
All three saved executions exit 1, each under its declared 120-second timeout.
Both saved successful runs exit 0 with empty stderr under the same timeout.
These are author executions, inspected here without rerunning them.

The reviewer bookkeeping run verified all **57 author bindings, covering 56
distinct paths**, plus the independent pre-evidence freeze, instruction/source
identities, mutation differences and saved run metadata. All 123 bookkeeping
conditions matched; these counts have no mathematical evidentiary weight.
The run exited 0 in about 0.08 seconds with a declared 60-second timeout.
Full raw output, script, execution metadata, complete diffs and frozen author
evidence are in `boost_inverse_energy_review/`.

## Authorship, reading limits and preserved routes

The theorem and its helpers were composed by `spectral_edge_recovery`. Root
authored the E premise and suggested the intermediate-time mean-ergodic route
and elementary folded-cube I0 estimate. Root therefore is not the independent
checker for this composition. This reviewer authored the independent
reconstruction, review and provenance checking only. The target itself exposed
the proposed formulas and described control outcomes; this was independent
checking, not blinded discovery.

The archived stronger fixed-tau route was read as context and preserved; its
complete proof was not certified. Its proposed `1/4096` interval is not used.
The pre-I0 note was covered by a complete diff against the fully read current
note. The published memory source, D source/review, E review and unrelated
preservation guards were hashed but not newly read or independently certified.
Their review labels do not substitute for the reconstruction here. No
exhaustive literature or novelty claim is made.

All saved author failed runs, the unused route and pre-amendment documents
remain preserved. The reviewer had one operational read failure caused by a
mistyped working directory; the corrected read succeeded. That failure is
recorded in `operational_failures.json` and has no mathematical implication.

Current AGENTS, CLAUDE and SCIENCE_WORKFLOW instructions and the applicable
physics-claim-reviewer contract were read/reused at verified unchanged bytes.
Model and reasoning effort were inherited without override. No repository,
editable prompt, target note or author-evidence file was edited. No audit
verdict, physics adoption, framework no-go, global exponentiated representation,
other-chat message or campaign deadline extension was made. Source-bound recovery and
coverage details are in `boost_inverse_energy_review/receipt.json` and
`boost_inverse_energy_review/CHECKPOINT.md`.
