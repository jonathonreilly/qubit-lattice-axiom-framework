#!/usr/bin/env python3
"""Read-only input verification and reviewer-owned recovery copies; no science verdict."""
from pathlib import Path
import difflib
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
S = HERE.parent
AUTHOR = S / 'boost_current_expectation'
EXPECTED_RECEIPT = '4aa182928c9fa4a6bc44fbd69c6122a35aa9a8f99495a7170aa2f90e5aa1216f'
records = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(label, condition, detail=None):
    record = {'check': label, 'match': bool(condition)}
    if detail is not None:
        record['detail'] = detail
    records.append(record)
    print(json.dumps(record, sort_keys=True), flush=True)


def bind(path, expected_sha, expected_bytes=None, category='input'):
    path = Path(path)
    data = path.read_bytes()
    actual = digest(data)
    check(f'{category}: {path}', actual == expected_sha and
          (expected_bytes is None or len(data) == expected_bytes),
          {'sha256': actual, 'bytes': len(data)})
    destination = HERE / 'bound_bytes' / actual
    destination.parent.mkdir(exist_ok=True)
    if destination.exists():
        check(f'existing recovery bytes: {actual}', destination.read_bytes() == data)
    else:
        destination.write_bytes(data)
    return {'path': str(path), 'sha256': actual, 'bytes': len(data),
            'recovery': str(destination), 'category': category}


def main():
    inventory = []
    pre = json.loads((HERE / 'PRE_EVIDENCE_FREEZE.json').read_text())
    check('pre-evidence freeze states no author evidence opened',
          pre['author_evidence_opened'] is False)
    for row in pre['input_bindings']:
        inventory.append(bind(row['path'], row['sha256'], row['bytes'], 'pre-evidence input'))
        check(f'source snapshot: {row["snapshot"]}',
              Path(row['snapshot']).read_bytes() == Path(row['path']).read_bytes())
    for key in ['pre_evidence_reconstruction', 'preserved_prior_reconstruction']:
        row = pre[key]
        inventory.append(bind(row['path'], row['sha256'], row['bytes'], key))
    check('planning instruction snapshot',
          digest((HERE / 'instructions/planning_AGENTS.md').read_bytes()) ==
          pre['planning_instruction_sha256'])

    raw = (AUTHOR / 'receipt.json').read_bytes()
    receipt = json.loads(raw)
    inventory.append(bind(AUTHOR / 'receipt.json', EXPECTED_RECEIPT,
                          category='author receipt'))
    rows = receipt['bindings']
    check('author binding count', len(rows) == 97, len(rows))
    check('author binding paths distinct', len({row['path'] for row in rows}) == len(rows))
    for row in rows:
        inventory.append(bind(row['path'], row['sha256'], row['bytes'], 'author binding'))

    metadata = json.loads((AUTHOR / 'receipt_verification_run.json').read_text())
    check('saved author run succeeded within declared scope',
          metadata['exit_code'] == 0 and metadata['timeout_seconds'] == 60 and
          metadata['receipt_sha256'] == EXPECTED_RECEIPT)
    for suffix in ['stdout', 'stderr']:
        path = AUTHOR / f'receipt_verification.{suffix}.log'
        inventory.append(bind(path, metadata[f'{suffix}_sha256'], category='saved author log'))
    lines = [json.loads(line) for line in
             (AUTHOR / 'receipt_verification.stdout.log').read_text().splitlines()]
    check('complete saved log has all rows and final summary', len(lines) == len(rows) + 1)
    by_path = {row['path']: row for row in rows}
    check('complete saved log path coverage',
          {row['path'] for row in lines[:-1]} == set(by_path))
    for line in lines[:-1]:
        expected = by_path[line['path']]
        check(f'saved log row: {line["path"]}',
              line['match'] is True and line['expected_sha256'] == expected['sha256'] and
              line['actual_sha256'] == expected['sha256'] and line['bytes'] == expected['bytes'])
    summary = lines[-1]
    check('complete saved author summary matches raw log',
          summary['matched_paths'] == len(rows) and summary['mismatches'] == 0 and
          summary['receipt_sha256'] == EXPECTED_RECEIPT)
    metadata_data = (AUTHOR / 'receipt_verification_run.json').read_bytes()
    inventory.append(bind(AUTHOR / 'receipt_verification_run.json', digest(metadata_data),
                          category='saved author run metadata'))

    old = json.loads((AUTHOR / 'final_prior_preservation.json').read_text())
    initial = json.loads((AUTHOR / 'initial_sources.json').read_text())
    original_rows = initial['frozen_prior_packet_records_verified']
    check('inherited prior binding coverage is 57',
          len(old) == len(original_rows) == 57 and
          {row['path'] for row in old} == {row['path'] for row in original_rows})
    originals = {row['path']: row for row in original_rows}
    for row in old:
        expected = originals[row['path']]
        check(f'prior preservation record: {row["path"]}', row['match'] is True and
              row['sha256'] == row['expected_sha256'] == expected['sha256'] and
              row['bytes'] == expected['bytes'])

    copied = json.loads((AUTHOR / 'source_copy_manifest.json').read_text())
    check('five author mathematical source copies', len(copied) == 5)
    for row in copied:
        source = Path(row['original']).read_bytes()
        copy = Path(row['copy']).read_bytes()
        check(f'author source copy: {row["copy"]}', source == copy and
              digest(copy) == row['sha256'] and len(copy) == row['bytes'])

    recovered = json.loads((AUTHOR / 'recovered_initial_bytes/preservation.json').read_text())
    for row in recovered['preserved']:
        data = Path(row['recovery_copy']).read_bytes()
        check(f'recovered initial bytes: {row["recovery_copy"]}',
              digest(data) == row['sha256'] and len(data) == row['bytes'])

    diagonal = (AUTHOR / 'DRAFT_DIAGONAL_BEFORE_ALL_COMPONENTS.md').read_text()
    current = (S / 'BOOST_CURRENT_EXPECTATION_PROBE.md').read_text()
    diff = ''.join(difflib.unified_diff(diagonal.splitlines(True), current.splitlines(True),
                     fromfile='preserved_diagonal', tofile='frozen_all_components'))
    (HERE / 'complete_diagonal_to_final.diff').write_text(diff)
    replacements = json.loads((AUTHOR / 'all_component_replacements.json').read_text())
    replay = diagonal
    for index, row in enumerate(replacements):
        check(f'declared index replacement {index}',
              replay.count(row['old']) == row['occurrences'])
        replay = replay.replace(row['old'], row['new'])
    polishing_diff = ''.join(difflib.unified_diff(replay.splitlines(True), current.splitlines(True),
                             fromfile='replayed_index_changes', tofile='frozen_final'))
    (HERE / 'post_index_polishing.diff').write_text(polishing_diff)

    for path in sorted(AUTHOR.rglob('*')):
        if path.is_file():
            destination = HERE / 'author_packet' / path.relative_to(AUTHOR)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(path.read_bytes())

    (HERE / 'verified_input_inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
    failures = [row for row in records if not row['match']]
    result = {'meaning': 'Identity, preservation and complete saved-log checks only; no science verdict',
              'checks': len(records), 'failures': failures, 'author_bound_paths': len(rows),
              'prior_preserved_bindings': len(old), 'saved_author_log_rows': len(lines),
              'pre_evidence_reconstruction_sha256': pre['pre_evidence_reconstruction']['sha256'],
              'target_sha256': receipt['primary']['sha256'],
              'author_receipt_sha256': digest(raw)}
    (HERE / 'verification_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'summary': result}, sort_keys=True))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
