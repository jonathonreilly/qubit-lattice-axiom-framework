from pathlib import Path
import json, hashlib, sys, gzip, subprocess, re
S=Path(__file__).resolve().parent
W=S.parent/'boost_worktree'
D=S/'boost_whitespace_repair'
P=W/'.claude/science/physics-loops/toe-boost-bracket-control-20261011'
sys.path.insert(0,str(W/'scripts'))
import runner_cache
rp='scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
cache,_,_=runner_cache.load_cache(rp)
assert runner_cache.cache_status(rp)==runner_cache.cache_identity_status(rp)=='fresh'
raw=cache.read_text()
head=dict(re.findall(r'^([a-z_0-9]+): (.+)$',raw.split('----- stdout -----')[0],re.M))
assert head['status']=='ok' and head['exit_code']=='0'
stdout=raw.split('----- stdout -----\n',1)[1].split('----- stderr -----\n',1)[0].rstrip('\n')+'\n'
stderr=raw.split('----- stderr -----\n',1)[1].rstrip('\n')
old=json.loads((S/'boost_canonical_execution.json').read_text())
assert stdout==old['stdout'] and stderr==old['stderr']==''
record={'recovered_from_canonical_cache':str(cache),'header':head,'stdout':stdout,'stderr':stderr,
        'stdout_identical_to_prior_fully_read_run':True,'source_unchanged':True,'cache_and_input_fresh':True,
        'wrapper_failures':[
          'execute_and_write_cache returns (result, Path); JSON encoding failed after the canonical cache was successfully written.',
          'The lightweight parsed header omits elapsed_sec; reading the full canonical header repaired a KeyError before any publication edit.'
        ],'scientific_reruns_for_bookkeeping_repair':0}
(D/'canonical_execution_recovered.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['ROOT_COMPOSITION_REVIEW.md','DELIVERY_CHECKS.md']:
    p=P/name
    p.write_text(p.read_text()+f'\nThe refreshed canonical run exited 0 in {head["elapsed_sec"]} seconds.\n'
        'Its complete output is byte-identical to the earlier fully read output, and\n'
        'its updated note fingerprint is fresh. The post-execution JSON wrapper\n'
        'failed to serialize the returned Path; the already written canonical cache\n'
        'provided complete recovery without another scientific run. A lightweight\n'
        'header omitted elapsed time; its full header supplied that field. Both\n'
        'bookkeeping failures are recorded, separate from the successful execution.\n')
for mode in ['fix','report-only']:
    files=sorted(P.glob('*.md'))+[W/'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md',W/rp]
    target=D/('final_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(target.with_suffix('.json'))]+[str(p.relative_to(W)) for p in files],cwd=W,capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout+r.stderr)
    assert r.returncode==0
emap=json.loads((P/'EVIDENCE_MAP.json').read_text())
rows={r['preserved']:r for r in emap['files']}
for src in sorted(D.rglob('*'))+[Path(__file__).resolve()]:
    if not src.is_file():continue
    b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0))
    rel=str(dst.relative_to(P));rows[rel]={'original':str(src),'preserved':rel,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
for row in rows.values():
    b=gzip.decompress((P/row['preserved']).read_bytes())
    assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
emap['files']=[rows[k] for k in sorted(rows)]
(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md',W/rp,W/'docs/audit/data/citation_graph_manifest.json',cache]
files += [p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
    row={'path':str(p.relative_to(W)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    if p.suffix=='.gz':row['decompressed_sha256']=hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps({'base_revision':'b9b032ae790c66e762a6296a1306bfb64ae7cd70','scope':'Every publication file except this manifest itself.','files':ident},indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,cwd=W,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
for r in ident:
    assert hashlib.sha256(subprocess.check_output(['git','show',':'+r['path']],cwd=W)).hexdigest()==r['sha256']
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=W).decode().split('\0')
assert set(staged)-{''}==set(paths)
report={'staged_files':len(paths),'all_index_worktree_identities_match':True,'whitespace_clean':True,
        'note_sha256':hashlib.sha256((W/'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md').read_bytes()).hexdigest(),
        'cache_header':head,'stdout_matches_previous_complete_read':True}
(S/'boost_final_staged_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
