#!/usr/bin/env python3
"""Author consistency controls for the inverse-energy boost/current probe.

The exact moment calculation exercises the continuum proof's algebra. The
3-vector forcing calculation exercises Duhamel signs and all momentum
factors. It is a gapped auxiliary model, not a discretization or proof of the
excluded-walk continuum limit. No fitted constants or external data.
"""
import hashlib
import json
import math
import platform
import sys
from pathlib import Path

import numpy as np
import scipy
import scipy.linalg as la
import sympy as sp

CURRENT_RANK_WEIGHT = sp.Rational(1)
DUHAMEL_SOURCE_SIGN = 1.0
DIFFERENTIATE_SOURCE_CLOCK = True


def require(condition, message):
    if not bool(condition):
        raise AssertionError(message)


def exact_controls():
    x, y, z = sp.symbols('x y z', real=True)
    eps2 = x + y + z
    circle = {0: sp.Rational(1), 1: sp.Rational(1, 2),
              2: sp.Rational(3, 8), 3: sp.Rational(5, 16)}

    def mean(polynomial):
        return sp.expand(sum(coef * circle[p[0]] * circle[p[1]] * circle[p[2]]
                             for p, coef in sp.Poly(polynomial, x, y, z).terms()))

    # H0 applied to multiplication and both canonical rank terms, with the
    # common factor c/sqrt(I0) suppressed. P then removes the mean singlet.
    before_P = 1 - 2*x + CURRENT_RANK_WEIGHT * (x + eps2/3)
    after_P = sp.expand(before_P - mean(before_P))
    expected = eps2/3 - x
    require(sp.simplify(after_P - expected) == 0,
            'canonical full-torus coupling polynomial')
    # A_b/K_b from B12, independently arranged by its four surviving actions
    # on zeta; no q derivative of zeta occurs.
    rank_normal_form = 1 - 2*x + (2*x-1)/2 + (4*eps2-6)/12
    require(sp.simplify(rank_normal_form - expected) == 0,
            'B12 coefficient agrees with bounded-current calculation')
    require(mean(expected) == 0, 'physical projection removes mean')
    require(mean(expected**2) == sp.Rational(1, 12),
            'exact squared coupling is 1/(12 I0)')
    require(mean(before_P) == 1, 'full-torus contact subtraction is retained')
    print(json.dumps({'control': 'canonical_coupling',
                      'before_P': str(sp.expand(before_P)),
                      'after_P': str(after_P),
                      'squared_polynomial_mean': str(mean(expected**2))}))

    # An exact normalizable compact C2 scalar envelope tests the integration
    # by parts lower bound, independently of the B25 envelope's construction.
    k = sp.symbols('k', real=True)
    p = (1-k*k)**3
    dilated = sp.diff(k*p, k)
    norm2 = sp.integrate(p*p, (k, -1, 1))
    pairing = sp.integrate(p*dilated, (k, -1, 1))
    derivative_norm2 = sp.integrate(dilated*dilated, (k, -1, 1))
    require(pairing == norm2/2, 'compact dilation pairing')
    require(derivative_norm2 >= norm2/4, 'dilation norm lower bound')
    M = sp.Rational(192, 7)
    c_value = sp.Rational(9, 16)
    c_derivative = sp.Rational(13, 8) + 9*M/16
    c_bracket = 16*c_value + 6*c_derivative
    require(c_bracket < 112, 'direct comparison residual constant')
    # 112 sqrt(6) tau <= 1/(16 sqrt(12) I0) for tau<=1/32768,
    # I0<=9/8. Squaring is legitimate because all quantities are positive.
    require((sp.Integer(1792)**2)*72*sp.Rational(9, 8)**2 < 32768**2,
            'small fixed scaled-time lower bound')
    Kscale, Qscale, pi = sp.symbols('Kscale Qscale pi', positive=True)
    require(sp.simplify((2*pi)**6*Kscale**(-6)*Kscale**3*Qscale**3/
                        (2*pi)**6).subs(Qscale, Kscale) == 1,
            'six-dimensional packet normalization')
    require(sp.Rational(3, 2)-1 == sp.Rational(1, 2),
            'inverse-energy contact amplitude power')
    require(sp.Rational(3, 2)-sp.Rational(1, 2) == 1,
            'relative-error threshold power')
    print(json.dumps({'control': 'normalization_and_dilation',
                      'compact_envelope_norm2': str(norm2),
                      'dilation_pairing': str(pairing),
                      'dilation_norm2': str(derivative_norm2),
                      'state_error_coefficient': str(c_value),
                      'derivative_error_coefficient': str(c_derivative),
                      'bracket_error_coefficient': str(c_bracket),
                      'tau_max': '1/32768'}))


Hstar = np.diag([0.0, 1.0, -2.0])
Bparts = np.array([
    [[1,0,0],[0,0,.5],[0,.5,0]],
    [[0,.5,0],[.5,0,0],[0,0,0]],
    [[0,0,.5],[0,1,0],[.5,0,0]],
], dtype=float)
h0 = np.array([1.0, 2.0, -1.0])
e0vec = np.array([1.0, 0.0, 0.0], dtype=complex)


def factors(lam, k):
    G = Hstar/lam + np.einsum('j,jab->ab', k, Bparts)
    h = h0 + lam*lam*k
    e = 1.5+k[1]/4+k[0]*k[2]/8
    de = np.array([k[2]/8, .25, k[0]/8])
    F = (2/math.pi)**.75 * np.exp(-np.dot(k, k))
    dF = -2*k*F
    return G, h, e, de, F, dF


def augmented(lam, k, tau, component):
    G, h, e, de, F, dF = factors(lam, k)
    matrix = np.zeros((4,4), complex)
    matrix[:3,:3] = G
    matrix[:3,3] = DUHAMEL_SOURCE_SIGN*h
    matrix[3,3] = e
    dm = np.zeros_like(matrix)
    dm[:3,:3] = Bparts[component]
    dm[component,3] = DUHAMEL_SOURCE_SIGN*lam*lam
    dm[3,3] = de[component] if DIFFERENTIATE_SOURCE_CLOCK else 0
    ev, dev = la.expm_frechet(-1j*tau*matrix, -1j*tau*dm)
    initial = np.array([0,0,0,F], complex)
    di = np.array([0,0,0,dF[component]], complex)
    return (ev@initial)[:3], (dev@initial+ev@di)[:3]


def spectral_forcing(lam, k, tau):
    # Direct integral of +i exp(-i(tau-s)G) h F exp(-i e s), using
    # Hermitian G diagonalization; independent of the augmented generator.
    G, h, e, _, F, _ = factors(lam, k)
    evals, vectors = la.eigh(G)
    d = evals-e
    response = np.empty(3, complex)
    near = np.abs(d) < 1e-10
    response[near] = 1j*tau*np.exp(-1j*tau*e)
    response[~near] = -np.exp(-1j*tau*e)*np.expm1(-1j*tau*d[~near])/d[~near]
    return F*vectors@(response*(vectors.conj().T@h))


def fixed_tau_limit(k, tau, component):
    _, _, e, de, F, dF = factors(0.125, k)
    b = k[0]
    db = 1.0 if component == 0 else 0.0
    d = e-b
    numerator = np.exp(-1j*b*tau)-np.exp(-1j*e*tau)
    response = numerator/d
    dn = -1j*tau*db*np.exp(-1j*b*tau)+1j*tau*de[component]*np.exp(-1j*e*tau)
    derivative = (dn*d-numerator*(de[component]-db))/(d*d)
    return F*response*e0vec, (dF[component]*response+F*derivative)*e0vec


def vector_controls():
    k = np.array([.12, -.08, .09])
    lam, tau, component = 1/64, .37, 1
    value, derivative = augmented(lam, k, tau, component)
    direct = spectral_forcing(lam, k, tau)
    step = 1e-4
    unit = np.eye(3)[component]
    values = [spectral_forcing(lam, k+j*step*unit, tau) for j in [-2,-1,1,2]]
    finite_difference = (values[0]-8*values[1]+8*values[2]-values[3])/(12*step)
    value_error = la.norm(value-direct)
    derivative_error = la.norm(derivative-finite_difference)
    require(value_error < 2e-12, 'positive contact Duhamel sign: actual vectors')
    require(derivative_error < 2e-9, 'all momentum derivative factors: actual vectors')
    print(json.dumps({'control': 'actual_forced_vector', 'lambda': lam,
                      'tau': tau, 'kappa': k.tolist(), 'derivative_component': component,
                      'augmented_value': [[float(x.real), float(x.imag)] for x in value],
                      'spectral_integral_error': float(value_error),
                      'frechet_vs_five_point_derivative_error': float(derivative_error)}))

    shorter, fixed = [], []
    _, _, _, _, F, dF = factors(.125, k)
    target = 1j*F*e0vec
    dtarget = 1j*dF[component]*e0vec
    fixed_tau = .125
    fixed_target, fixed_dtarget = fixed_tau_limit(k, fixed_tau, component)
    for exponent in [6, 8, 10, 12, 14, 16, 18]:
        lam = 2.0**(-exponent)
        tau = math.sqrt(lam)
        value, derivative = augmented(lam, k, tau, component)
        shorter.append({'lambda': lam, 'physical_t': 1/math.sqrt(lam),
                        'scaled_tau': tau,
                        'value_error': float(la.norm(value/tau-target)),
                        'derivative_error': float(la.norm(derivative/tau-dtarget))})
        value, derivative = augmented(lam, k, fixed_tau, component)
        fixed.append({'lambda': lam, 'scaled_tau': fixed_tau,
                      'value_error': float(la.norm(value-fixed_target)),
                      'derivative_error': float(la.norm(derivative-fixed_dtarget))})
    for row in shorter:
        print(json.dumps({'control': 'shorter_time_finite_model', **row}))
    for row in fixed:
        print(json.dumps({'control': 'fixed_tau_finite_model', **row}))
    require(shorter[-1]['value_error'] < .08*shorter[0]['value_error'],
            'shorter-time finite model resolves the kernel forcing')
    require(shorter[-1]['derivative_error'] < .08*shorter[0]['derivative_error'],
            'shorter-time finite model resolves the derivative')
    require(fixed[-1]['value_error'] < .01*fixed[0]['value_error'],
            'fixed-tau finite model resolves the forced kernel limit')
    require(fixed[-1]['derivative_error'] < .01*fixed[0]['derivative_error'],
            'fixed-tau finite model resolves the derivative')
    print(json.dumps({'scope': 'gapped three-vector model only; no continuum rate or theorem is inferred',
                      'status': 'all author consistency controls completed'}))


if __name__ == '__main__':
    own = Path(__file__).resolve()
    print(json.dumps({'script': str(own), 'sha256': hashlib.sha256(own.read_bytes()).hexdigest(),
                      'python': sys.version, 'executable': sys.executable,
                      'platform': platform.platform(), 'numpy': np.__version__,
                      'scipy': scipy.__version__, 'sympy': sp.__version__,
                      'evidence_role': 'author consistency; independent scientific review pending'}))
    exact_controls()
    vector_controls()
