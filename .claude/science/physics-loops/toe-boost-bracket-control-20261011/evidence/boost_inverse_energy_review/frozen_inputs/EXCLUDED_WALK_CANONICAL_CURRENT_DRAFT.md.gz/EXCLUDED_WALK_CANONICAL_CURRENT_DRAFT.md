# Canonical local-energy current of the supplied excluded walk

Root derivation, 2026-10-11. Provisional: requires independent reconstruction
and exact controls. This is a selected supplied energy placement, not every
placement permitted by the repo. It may strengthen the separate walk probe's
finite-time bound from compressed free momentum to an actual local-energy
current. All walk, exclusion, spatial coordinate and clock premises remain
supplied. No dynamics is inferred from the minimal axioms.

## Canonical compressed density and its bounded current

For particle i=1,2 let h_i be the repo's one-body walk and X_(i,a) its
position operator. Use the additive symmetric local energy densities

    e_x^0=(1/2) sum_(i=1,2) {Pi_(i,x),h_i},
    e_x=P e_x^0 P,
    H_D=sum_x e_x=P H0 P, H0=h_1+h_2.

Here P removes coincident sites in the antisymmetric two-record space.
On finite-support states the energy first moment is

    D_a=P D0,a P,
    D0,a=(1/2)({X_(1,a),h_1}+{X_(2,a),h_2}).       (J1)

The free commutator is bounded:

    i[H0,D0,a]=g_a,
    g_a=sin(k_(1,a))cos(k_(1,a))
           +sin(k_(2,a))cos(k_(2,a))
        =sin K_a cos(2q_a).                        (J2)

This follows from (1/2){partial_a h_i,h_i}=sin k_(i,a)cos k_(i,a) I.
The cross-particle commutators vanish. We compute i[H_D,D_a] first on
the common finite-support core and then obtain its bounded extension.

Work in a local total-momentum chart K=k_1+k_2, q=(k_1-k_2)/2, with
smooth sections compactly supported in K. Torus q is periodic. Let c be
the constant normalized singlet, C=|c><c|, P=I-C in each fiber, and

    h=H0 c, h'_a=partial_(K_a) h,
    Hdiff=h_1-h_2, H0'=partial_(K_a)H0.

P is independent of K. Since X_(1,a)=i(partial_Ka+partial_qa/2) and
X_(2,a)=i(partial_Ka-partial_qa/2), direct symmetrization gives

    D0,a=i H0 partial_Ka+(i/2) Hdiff partial_qa+i H0'. (J3)

The equality partial_qa Hdiff=2H0' is essential to this expression.
Put Dq=(i/2)Hdiff partial_qa+iH0'. Integration by parts in q gives
Dq^*=(i/2)Hdiff partial_qa, so Dq^* c=0. Also Dq c=i h'_a.
Consequently the contact blocks are

    C D0,a P psi = i c <h,partial_Ka psi>,
    P D0,a C (c f) = i partial_Ka(h f).             (J4)

Here c is constant, <c,H0c>=0 and <c,h'_a>=0. These relations retain
the derivatives in K; discarding them would give the wrong current.

Expand the compressed commutator:

    i[PH0P,PD0,aP]
       =P g_a P-i P H0 C D0,a P+i P D0,a C H0 P.

Insert (J4). The terms h<h,partial_Ka psi> cancel. The remaining bounded
finite-rank correction is

    J_a=i[H_D,D_a]=P g_a P+F_a,
    F_a=-|h'_a><h|-|h><h'_a|.                     (J5)

Both h and h'_a lie in P. Thus (J5) is an operator identity for the bounded
extension of this canonical current, and not a postulated current choice.
It uses the specified compressed local densities in (J1).
The finite-support core calculation extends to the smooth compact-chart
sections used above by H1 approximation: D0,a maps H1 to L2 continuously,
and H0 and P preserve H1. These sections need not themselves have finite
spatial support. No self-adjointness claim for the unbounded dipole is
needed to identify its bounded commutator extension.

Pointwise singlet algebra gives

    h(q)=2 sum_j cos(K_j/2) sin q_j sigma_(1,j)c,
    h'_a(q)=-sin(K_a/2) sin q_a sigma_(1,a)c,
    ||h||^2=2 sum_j cos(K_j/2)^2<=6,
    ||h'_a||=|sin(K_a/2)|/sqrt(2),
    ||F_a||<=2sqrt(3)|sin(K_a/2)|.                 (J6)

In particular both g_a and F_a vanish at central total momentum K=0.
This is consistent with special zero-current sectors; no nonzero drift
for every state is asserted.

## Band estimates retaining the canonical correction

Use the independently checked domain and density conclusion only after
the pending walk-probe review: 0<lambda<=1/16, free spectral support
[lambda,2lambda], total-momentum support |K|<=lambda/4, and

    eta=sqrt(28/(3pi^2)) lambda^(3/2),
    ||C 1_[lambda,2lambda](H0)||<=eta.              (J7)

The source's positive-positive shell coverage also gives relative distance
r<=E<=2lambda from one of eight corners and contact spin weight at least
1/4 on every shell in this band. Let Pi_band be that spectral projection.
Since h=H0c,

    ||Pi_band h||<=2lambda eta.                    (J8)

The normalized torus measure of the band support is at most 4eta^2:
its contact spectral mass is at least one quarter of that volume. On this
support |sin q_a|<=2lambda. Equation (J6) therefore implies

    ||Pi_band h'_a||<=4lambda |sin(K_a/2)| eta.      (J9)

No inequality for a general spin form factor is inferred from contact
mass alone; the lower contact weight and pointwise bound are both used.

For a normalized free-band vector phi_t=exp(-itH0)phi and
t_a=ess sup_K |sin(K_a/2)|, equations (J6)-(J9) give uniformly in time

    ||F_a phi_t||<=(sqrt(2)+4sqrt(6)) t_a lambda eta,
    |<phi_t,F_a phi_t>|<=16 t_a lambda^2 eta^2.     (J10)

These also hold for normalized direct-integral packets by the uniform
fiber inequalities and Cauchy-Schwarz. Put

    s_a=ess sup_K |sin K_a|<=lambda/4,
    t_a<=lambda/8,
    O_a=g_a-sin K_a I+F_a,
    B_a=8s_a lambda^2+(sqrt(2)+4sqrt(6))t_a lambda eta,
    C_a=2s_a+2sqrt(3)t_a.

The shell range estimate in the walk probe yields ||O_a phi_t||<=B_a;
globally ||O_a||<=C_a. On P, O_a is J_a minus the conserved multiplier
sin K_a. The latter commutes with the full compressed generator, so
subtracting it does not change the current drift.

## Finite-time canonical energy-current theorem candidate

Prepare chi=P phi/||P phi|| and evolve chi_t=exp(-itH_D)chi. The walk
probe's direct Duhamel estimate is

    ||chi_t-phi_t||<=d_t,
    d_t=eta[sqrt(2)+(sqrt(6)+2lambda)|t|],
    d_0=sqrt(2)eta.                                (J11)

This includes the non-band-limited part introduced by projection. At each
endpoint, expand the quadratic expectation in chi_t-phi_t. The error is
at most 2B_a d_t+C_a d_t^2. The free expectation of g_a-sin K_a is
constant. Equation (J10) bounds the difference of its two F_a expectations.
Therefore the actual canonical current satisfies

    |<chi_t,J_a chi_t>-<chi,J_a chi>|
       <=2B_a(d_t+d_0)+C_a(d_t^2+d_0^2)
                                      +32t_a lambda^2 eta^2. (J12)

For a fixed supplied T, the right side is O_T(lambda^4), uniformly over
|t|<=T and every normalized packet with the specified free-band support,
after the displayed exclusion preparation. For |t|<=T0 lambda^(-1/2),
it is O_(T0)(lambda^3); the state error is O_(T0)(lambda). These are
upper bounds with explicit finite constants, not positive loss rates or
many-body relaxation estimates. No smooth spectral profile is required
for (J7)-(J12); the supplied band restriction suffices.

## Asymptotic interpretation and open checks

At fixed K, a finite-rank form factor has vanishing matrix elements along
every free absolutely continuous packet as |t| tends to infinity. Its
scalar complex spectral density is L1 by finite variation and absolute
continuity, so this follows from the Riemann-Lebesgue lemma. Thus the F_a
expectation vanishes in asymptotic free scattering packets. For normalizable
total-K packets, uniform boundedness of F_a and dominated convergence give
the same result by integrating the fiber statement. Wave-operator norm
convergence then gives the same canonical current asymptotes as the free
g_a scattering observable. This statement is qualitative; the separate
Cook bridge retains quantitative spectral-derivative constants.

Pending obligations:

1. Independently reconstruct the density placement, unbounded first-moment
   core calculation, K/q derivative factors and sign in (J5).
2. Independently check all contact-weight and band-volume hypotheses before
   accepting (J7)-(J12), using the final frozen walk threshold proof.
3. Execute exact operator controls of the derivative cancellation and
   finite-rank current, plus a finite-time compression discriminator.
4. Verify the fixed-K and direct-integral asymptotic statements without
   treating a global decomposable perturbation as trace class.

This draft strengthens one named canonical placement only. General
one-body placement changes or other interacting energy densities need
their own current operators and estimates. No source publication, audit
verdict, physical axiom adoption or universal-current claim has occurred.
