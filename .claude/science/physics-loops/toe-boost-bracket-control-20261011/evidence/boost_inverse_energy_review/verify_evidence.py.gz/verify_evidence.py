#!/usr/bin/env python3
"""Reviewer bookkeeping only: source bindings and saved run provenance, no physics run."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import shutil

BASE = Path(__file__).resolve().parent
S = BASE.parent
AUTHOR = S / "boost_current_inverse_energy"
EXPECTED_RECEIPT = "0c555b37791acd590c8a8b9686ebd2697873fcffd273eb67d6ed0d8e4b9ec715"
checks = []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def check(label, condition, **details):
    record = {"label": label, "matches": bool(condition), **details}
    checks.append(record)
    print(json.dumps(record, sort_keys=True))

receipt_path = AUTHOR / "receipt.json"
check("frozen author receipt", digest(receipt_path) == EXPECTED_RECEIPT,
      path=str(receipt_path), expected=EXPECTED_RECEIPT, actual=digest(receipt_path))
receipt = json.loads(receipt_path.read_text())
bindings = receipt["input_sources"] + [receipt["primary_note"]] + receipt["evidence"]
for record in bindings:
    path = Path(record["path"])
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    check("author binding", actual == record["sha256"] and len(raw) == record["bytes"],
          path=str(path), sha256=actual, bytes=len(raw))

manifest = json.loads((BASE / "source_manifest.json").read_text())
for record in manifest["sources"]:
    for kind in ("path", "frozen_path"):
        path = Path(record[kind])
        raw = path.read_bytes()
        check("reviewer core " + kind,
              digest(path) == record["sha256"] and len(raw) == record["bytes"]
              and len(raw.splitlines()) == record["lines"], path=str(path))
for record in manifest["instructions"]:
    check("review instruction unchanged", digest(record["path"]) == record["sha256"],
          path=record["path"])
stage = json.loads((BASE / "pre_author_evidence_stage.json").read_text())
check("independent reconstruction unchanged since pre-evidence freeze",
      digest(stage["proof_path"]) == stage["proof_sha256"],
      path=stage["proof_path"], sha256=digest(stage["proof_path"]))

initial = json.loads((AUTHOR / "initial_sources.json").read_text())["sources"]
preserved = json.loads((AUTHOR / "source_preservation.json").read_text())
check("all initial source identities remain current",
      all(digest(r["path"]) == r["sha256"] for r in initial), count=len(initial))
check("preservation record exactly covers initial sources",
      {(r["path"], r["sha256"]) for r in initial}
      == {(r["path"], r["expected"]) for r in preserved["checks"]}
      and all(r["matches"] and r["actual"] == r["expected"] for r in preserved["checks"]))

base_source = (AUTHOR / "inverse_energy_controls.py").read_text()
failures = json.loads((AUTHOR / "failure_runs.json").read_text())
check("receipt and saved negative runs agree", failures == receipt["runs"]["negative_controls"])
intended_errors = {
    "omit_current_rank_terms": "canonical full-torus coupling polynomial",
    "reverse_duhamel_sign": "positive contact Duhamel sign: actual vectors",
    "omit_source_clock_derivative": "all momentum derivative factors: actual vectors",
}
diff_text = []
for run in failures:
    path = S / run["mutated_source"]
    text = path.read_text()
    exact = (base_source.count(run["original_literal"]) == 1
             and text == base_source.replace(run["original_literal"], run["replacement_literal"]))
    check("exactly one declared mutant edit", exact, name=run["name"], path=str(path))
    check("mutant SHA and actual failure metadata",
          digest(path) == run["sha256"] and run["exit_code"] == 1
          and run["timeout_seconds"] == 120 and 0 < run["elapsed_seconds"] < 120,
          name=run["name"])
    stdout = (AUTHOR / run["stdout"]).read_text()
    stderr = (AUTHOR / run["stderr"]).read_text()
    check("mutant log identifies source and intended assertion",
          run["sha256"] in stdout.splitlines()[0]
          and "AssertionError" in stderr and intended_errors[run["name"]] in stderr,
          name=run["name"])
    diff_text.extend(difflib.unified_diff(base_source.splitlines(True), text.splitlines(True),
                     fromfile="inverse_energy_controls.py", tofile=path.name))
(BASE / "mutant_source_diffs.txt").write_text("".join(diff_text))

for name, metadata_name, script_name in (
        ("baseline", "baseline_run.json", "inverse_energy_controls.py"),
        ("kernel_bound", "kernel_bound_run.json", "kernel_bound_control.py")):
    run = json.loads((AUTHOR / metadata_name).read_text())
    stdout = (AUTHOR / run["stdout"]).read_text()
    stderr = (AUTHOR / run["stderr"]).read_bytes()
    check("saved successful run and source header",
          run == receipt["runs"][name] and run["exit_code"] == 0
          and run["timeout_seconds"] == 120 and 0 < run["elapsed_seconds"] < 120
          and len(stderr) == 0 and digest(AUTHOR / script_name) in stdout.splitlines()[0],
          name=name)

amendment = json.loads((AUTHOR / "I0_amendment.json").read_text())
before = Path(amendment["pre_amendment_note"])
after = Path(receipt["primary_note"]["path"])
check("I0 amendment endpoints",
      digest(before) == amendment["pre_amendment_sha256"]
      and digest(after) == amendment["final_note_sha256"])
(BASE / "I0_amendment.diff").write_text("".join(difflib.unified_diff(
    before.read_text().splitlines(True), after.read_text().splitlines(True),
    fromfile=before.name, tofile=after.name)))

frozen = []
for source in [receipt_path] + [Path(r["path"]) for r in receipt["evidence"]]:
    relative = source.relative_to(AUTHOR)
    destination = BASE / "frozen_author_evidence" / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    check("frozen author evidence identical", digest(source) == digest(destination),
          source=str(source), frozen_path=str(destination))
    frozen.append({"path": str(source), "frozen_path": str(destination),
                   "sha256": digest(source), "bytes": source.stat().st_size})
(BASE / "frozen_author_evidence_manifest.json").write_text(json.dumps(frozen, indent=2) + "\n")

result = {
    "checked_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "File identities and saved-run provenance only; no scientific execution or continuum validation",
    "author_receipt_sha256": digest(receipt_path),
    "author_binding_count": len(bindings),
    "author_distinct_bound_paths": len({r["path"] for r in bindings}),
    "checks_count": len(checks),
    "all_match": all(r["matches"] for r in checks),
    "scientific_reruns": 0,
    "checks": checks,
}
(BASE / "evidence_verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "checks"}, sort_keys=True))
raise SystemExit(0 if result["all_match"] else 1)
