"""Distinct exact finite controls for the authored boost/rotation probe.

SymPy differential-operator composition tests a universal local Pauli jet and
a separate four-dimensional abstract compression fixture. Neither is a
continuum packet simulation or independent scientific review. No author
boost/current helper is imported. Domain and support proofs remain analytic.
"""
import itertools
import json
import sympy as sp

I = sp.I
checks = 0


def check(name, condition, detail=None):
    global checks
    assert bool(condition), name
    checks += 1
    print(json.dumps({"check": name, "detail": detail}))


def mz(m):
    return all(sp.expand(x) == 0 for x in m)


def clean(op):
    return {key: value.applyfunc(sp.expand) for key, value in op.items()
            if not mz(value)}


def compose(a, b, variables):
    out = {}
    for alpha, left in a.items():
        for beta, right in b.items():
            for gamma in itertools.product(*(range(n+1) for n in alpha)):
                coeff = sp.prod(sp.binomial(n, k) for n, k in zip(alpha, gamma))
                derived = right
                for var, order in zip(variables, gamma):
                    derived = derived.diff(var, order)
                index = tuple(n-k+m for n, k, m in zip(alpha, gamma, beta))
                out[index] = out.get(index, sp.zeros(left.rows)) + coeff*left*derived
    return clean(out)


def difference(a, b):
    keys = set(a) | set(b)
    size = next(iter(a.values())).rows if a else next(iter(b.values())).rows
    return clean({key: a.get(key, sp.zeros(size))-b.get(key, sp.zeros(size))
                  for key in keys})


def comm(a, b, variables):
    return difference(compose(a, b, variables), compose(b, a, variables))


def compressed(op, p):
    return clean({key: p*value*p for key, value in op.items()})


def evaluated(op, substitutions):
    return clean({key: value.subs(substitutions) for key, value in op.items()})


sigma = [
    sp.Matrix([[0, 1], [1, 0]]),
    sp.Matrix([[0, -I], [I, 0]]),
    sp.diag(1, -1),
]
x = sp.symbols("x0:3", real=True)
s = sp.symbols("s0:3", real=True)
c = sp.symbols("c0:3", real=True)
eye = sp.eye(2)
zero = (0, 0, 0)
units = [tuple(int(a == j) for j in range(3)) for a in range(3)]

# This is the complete second Taylor jet of sin(k+x) at an arbitrary k.
# Mixed second derivatives vanish; sin and cos values may remain symbolic.
h = sum((sigma[j]*(s[j]+c[j]*x[j]-s[j]*x[j]**2/2)
         for j in range(3)), sp.zeros(2))
dipoles = [{zero: I*h.diff(x[a])/2, units[a]: I*h} for a in range(3)]
at_origin = dict.fromkeys(x, 0)
for a, b in itertools.combinations(range(3), 2):
    direct = evaluated(comm(dipoles[a], dipoles[b], x), at_origin)
    spin = sum((sp.LeviCivita(a, b, d)*sigma[d] for d in range(3)), sp.zeros(2))
    expected = {
        units[a]: s[b]*c[b]*eye,
        units[b]: -s[a]*c[a]*eye,
        zero: -I*c[a]*c[b]*spin/2,
    }
    check(f"Pauli_direct_dipole_commutator_{a}{b}",
          not difference(direct, expected))
    check(f"Pauli_second_derivatives_cancel_{a}{b}",
          all(sum(key) <= 1 for key in direct))
    check(f"Pauli_spin_omission_detected_{a}{b}",
          bool(difference(direct, {k: v for k, v in expected.items() if k != zero})))
    check(f"Pauli_spin_sign_flip_detected_{a}{b}",
          bool(difference(direct, {**expected, zero: -expected[zero]})))

# This fixture is abstract, not a four-site discretization of the Weyl walk.
# It realizes exactly the two contact blocks, with nonconstant complex h
# and a noncommuting Hermitian complementary block.
u, v = sp.symbols("u v", real=True)
variables = (u, v)
z2 = (0, 0)
e2 = [(1, 0), (0, 1)]
contact = sp.Matrix([1, 0, 0, 0])
p = sp.diag(0, 1, 1, 1)
hh = sp.Matrix([0, 1+u+v**2, I*(2+v+u**2), u*v-I*u])
bath = sp.Matrix([[u, 1+I*v, v],
                  [1-I*v, 2*v, u+v],
                  [v, u+v, -u]])
H = hh*contact.T+contact*hh.conjugate().T
H[1:4, 1:4] = bath
check("abstract_H_is_Hermitian", mz(H-H.conjugate().T))
ops = []
qops = []
for a, variable in enumerate(variables):
    ha = hh.diff(variable)
    L = sp.zeros(4)
    L[:, 0] = ha
    L[1:4, 1:4] = bath.diff(variable)/2
    check(f"abstract_dipole_symmetry_contract_{a}",
          mz(L+L.conjugate().T-H.diff(variable)))
    ops.append({e2[a]: I*H, z2: I*L})
    qops.append(ha*hh.conjugate().T+hh*ha.conjugate().T)

left = comm(compressed(ops[0], p), compressed(ops[1], p), variables)
free_compressed = compressed(comm(ops[0], ops[1], variables), p)
contact_difference = difference(left, free_compressed)
expected_contact = {e2[1]: qops[0], e2[0]: -qops[1]}
check("abstract_exact_full_compression_defect",
      not difference(contact_difference, expected_contact))
check("abstract_second_derivative_contact_terms_cancel",
      all(sum(key) <= 1 for key in contact_difference))
check("abstract_no_constant_contact_term", z2 not in contact_difference)
check("abstract_contact_derivative_is_nonzero", bool(contact_difference))
check("abstract_omitting_contact_derivative_detected",
      bool(difference(left, free_compressed)))
check("abstract_reversing_contact_sign_detected",
      bool(difference(contact_difference, {k: -m for k, m in expected_contact.items()})))
check("abstract_contact_coefficient_divergence_cancels",
      mz(qops[0].diff(v)-qops[1].diff(u)))
check("abstract_contact_annihilation",
      all(mz(q*contact) for q in qops))

# Every reflected cone changes the spin in the two-axis product indicated,
# while its sin*cos orbital coordinate has the ordinary offset sign.
for signs in itertools.product((-1, 1), repeat=3):
    for a, b in itertools.combinations(range(3), 2):
        direct_spin = I*((signs[a]*sigma[a])*(signs[b]*sigma[b]) -
                        (signs[b]*sigma[b])*(signs[a]*sigma[a]))*(-sp.Rational(1, 4))
        expected_spin = sum((sp.LeviCivita(a, b, d)*sigma[d]*signs[a]*signs[b]/2
                             for d in range(3)), sp.zeros(2))
        check(f"cone_spin_{signs}_{a}{b}", mz(direct_spin-expected_spin))
    check(f"cone_orbital_offset_sign_{signs}", all(sign**2 == 1 for sign in signs))

R = sp.Rational
check("free_K_coefficient_budget",
      R(1, 384)+R(9, 32) == R(109, 384) < R(1, 3))
check("free_q_coefficient_budget",
      R(2, 3)*R(3, 4)**3 + R(1, 2)*R(1, 4)**2*R(3, 4)
      == R(39, 128) < R(1, 3))
check("local_contact_Q_budget",
      R(1, 8)*R(3, 2)+3*R(3, 32) == R(15, 32))
check("original_radial_envelope_derivative_budget",
      R(1, 3)*R(36, 25)*16**2*96*512**2 == R(18, 25)*2**32 < 2**32)
check("positive_projector_q_derivative_budget",
      2*2**16+R(16, 3) < 2**18)
C = R(49, 128)+(120+2**19)/sp.Integer(3)
budget = 2*(C/4+(30+R(1, 64)+R(15, 32)*R(120, 16))/4)
check("explicit_rotation_norm_budget", budget < 2**17, str(budget))
pi = sp.pi
volume = 4*pi*(R(3, 4))**3/(3*(2*pi)**3)
check("normalized_origin_support_volume",
      sp.simplify(volume-R(9, 128)/pi**2) == 0)

# A periodic smooth singlet input cos(q_a) gives this nonperiodic chart output.
qa, qb = sp.symbols("qa qb", real=True)
chart_output = -I*(qa*sp.diff(sp.cos(qa), qb)-qb*sp.diff(sp.cos(qa), qa))
jump = sp.simplify(chart_output.subs(qb, pi)-chart_output.subs(qb, -pi))
check("ordinary_chart_face_trace_jump",
      sp.simplify(jump+2*pi*I*sp.sin(qa)) == 0 and jump != 0,
      str(jump))
print(f"TOTAL: PASS={checks} FAIL=0")
print("SCOPE: exact finite algebra and constant budgets; no analytic domain/packet proof, independent review, physical rotation representation or evolution theorem certified")
