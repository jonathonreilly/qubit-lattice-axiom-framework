# Independent reconstruction of the boost–rotation argument

Source: `EXCLUDED_WALK_BOOST_ROTATION_PROBE.md`, 628 lines, SHA-256
`53f883ca7f01cdeb338e1c4d41367695fc6bdb32ee0ceb2905df50238a0c4760`.
This reconstruction was written before opening the author's rotation helper,
first-run log, execution receipt or completion report. The candidate itself
discloses those controls and their claimed result, so this is independence of
the calculation path, not blindness to the proposed conclusions. Exact input
identities and frozen recovery copies are in `source_manifest.json`.

## Target, premises and dependency closure

The target is the identity BR1 on the stated smooth common core and the
prepared-state norm bound BR23, with BR3 for the specified family. The source
defines the supplied two-particle sine-Pauli Hamiltonian, full relative torus
with normalized measure, antisymmetric subspace, global rank-one contact
projection, fixed canonical symmetric energy density, spatial coordinates and
continuous clock. No framework derivation of those premises is attempted.
The bound is conditional on origin support and scaled K and q derivatives.

The complete B1–B32 source and complete canonical source were read. Only their
model, canonical first moment, contact-block derivation and B25–B30 packet
construction are necessary here. The parent note's lines 1–175, 370–478 and
805–844 confirm the model, measure, exclusion projection and selected
placement; its threshold scattering proof is not required for this result.
No evolved-state estimate or previous review verdict is used in this
reconstruction. The complete September 25 free-walk note and May 30 continuum
Dirac note were read for exact scope comparison; neither supplies an excluded
pair theorem or a physical group representation.

## 1. Coordinates, placement and domain

With K=k1+k2 and q=(k1-k2)/2, the chain rule gives
X1,a=i(partial_Ka+partial_qa/2),
X2,a=i(partial_Ka-partial_qa/2). Symmetrizing each Xi,a with hi produces

    D0,a = i H0 partial_Ka + (i/2) Hdelta partial_qa + i H0,a,
    partial_qa Hdelta = 2 H0,a.

This is the first moment of the supplied additive symmetric local density;
exclusion gives Da=P D0,a P. P integrates the constant singlet over the full
q torus. It is independent of K and bounded on every Sobolev space used here.
The Hamiltonian and dipole coefficients are smooth periodic in q and smooth
on the compact K supports. Exchange sends q to -q while swapping the two
spins, so D0 and P preserve the antisymmetric condition. Derivatives, smooth
multipliers and P preserve smoothness and K support. Therefore Da preserves
the indicated P-valued smooth core, and both commutator products are defined.
Each product maps H2 to L2 on a fixed compact K support. The later first-order
identity has an H1-to-L2 extension, which does not assert separately defined
products on all H1 inputs.

The compact chart |K|<1/8 contains all stated supports because
|K|<=lambda/4<=1/64. This avoids total-momentum gluing. The two coordinate
changes have Jacobian magnitude one in each axis; the full q torus and the
antisymmetric subspace use the declared measure with no extra exchange factor.

## 2. Free bracket reconstructed by coefficient expansion

Write da=i La, La=h partial_a+ha/2 for one particle. Direct composition gives

    La Lb = h^2 partial_ab
      + (h ha + ha h/2) partial_b + (h hb/2) partial_a
      + h hab/2 + ha hb/4.

Subtract the expression with a,b exchanged. The h-squared derivatives and
h hab terms cancel; [da,db]=-[La,Lb]. Hence

    [da,db] = -{h,ha}/2 partial_b
               +{h,hb}/2 partial_a - [ha,hb]/4.

For h=sigma dot sin(k), the Pauli anticommutator is
{h,ha}/2=sin(ka)cos(ka) I, and
[ha,hb]=2i epsilon_abd sigma_d cos(ka)cos(kb).
Thus multiplication by i gives the negative-i orbital term and positive
one-half spin term in BR8. Different particles commute. Transforming the
individual derivatives back to K,q gives coefficients

    j1,a+j2,a = sin(Ka) cos(2qa) = ga,
    (j1,a-j2,a)/2 = cos(Ka) sin(2qa)/2 = wa.

This proves BR7–BR9 with the convention [Da,Db]=-i Mab. For a=b both sides
vanish, so estimates derived for distinct axes need no diagonal spin formula.
The formula is prior art for a free walker and an additive free pair.

## 3. Contact blocks, signs and complete cancellation

Let T_a=(i/2)Hdelta partial_qa+i H0,a. Its q-fiber adjoint is

    T_a^*=(i/2)Hdelta partial_qa
           +(i/2)partial_qa Hdelta-i H0,a
         =(i/2)Hdelta partial_qa.

It annihilates c, whereas T_a c=i ha. Since <c,H0c>=0, h=H0c and
ha=partial_Ka h lie in P. For every core vector psi in P,

    C D0,a P psi = i c <h,partial_Ka psi>,
    P D0,a C(c f) = i (ha f+h partial_Ka f).

No zeroth-order scalar overlap is present in the first block. Now

    [Da,Db]=P[D0,a,D0,b]P
       -P D0,a C D0,b P+P D0,b C D0,a P.

The two factors i in each product are -1. Accounting also for the displayed
outer signs leaves

    partial_Ka (h <h,partial_Kb psi>)
      -partial_Kb (h <h,partial_Ka psi>).

Its full first expansion is

    ha <h,partial_Kb psi> + h <ha,partial_Kb psi>
      + h <h,partial_KaKb psi>
      -hb <h,partial_Ka psi> - h <hb,partial_Ka psi>
      - h <h,partial_KbKa psi>.

The last terms cancel by equality of mixed derivatives. The others are
(Qa partial_Kb-Qb partial_Ka)psi. There is no omitted constant term.
Multiplication by i gives exactly BR1. Also Qa=partial_Ka |h><h|, so
partial_Kb Qa=partial_Ka Qb; integration by parts verifies the symmetry of
i(Qa partial_Kb-Qb partial_Ka). The singlet relation sigma2,j c=-sigma1,j c
gives BR12 exactly and proves Qa c=0.

The real-space translation used for the independent control follows from
this reconstruction, rather than any author helper. Put
Ya=X1,a+X2,a and Va=sigma1,a cos(k1,a)+sigma2,a cos(k2,a). Then
i partial_Ka=Ya/2 and H0,a=Va/2. Consequently, on the full pair space,

    Qa=(Va C H0+H0 C Va)/2,
    i(Qa partial_Kb-Qb partial_Ka)
      =[(Va C H0+H0 C Va)Yb
           -(Vb C H0+H0 C Vb)Ya]/4.

The entire right side is finite range in real space. This provides a
different exact implementation path through lattice shifts and coordinates.

## 4. Ordinary chart expression and periodic continuation

On the chosen cell the ordinary q coordinates are bounded but jump at torus
faces. Each q_a partial_qb with a!=b maps H1 to L2. Its coefficient is
independent of the differentiation variable, so the two q_b face boundary
terms cancel on periodic inputs. The complete expression is symmetric on
the stated smooth periodic domain. This does not imply domain invariance.

For psi=G(K)c cos(qa), radial compact G makes the K orbital part zero and
Sigma c=0. Its q orbital output is -i G c q_b sin(qa). The q_b traces
differ by -2 pi i G c sin(qa), nonzero as a face function. Thus this image
does not lie in H1 of the torus. The source's counterexample is valid and
has the stated narrow quantifiers.

The specified rho is smooth and even: its denominator is positive throughout
the transition and at each endpoint; it is identically one for |t|<=1 and
zero for |t|>=2. Hence tau=t rho is smooth, odd and periodic after extension.
The auxiliary q field has zero divergence. Its integration against c
vanishes and its total spin term annihilates c. The K field acts on the
fiber average in exactly the same way as on c alpha. Therefore [P,Maux]=0.

For a smooth phi supported in |q|<=3 lambda/4<1, all q-dependent pieces and
their derivatives see tau(qj)=qj. For the projected tail c alpha(K), all q
derivatives vanish and Sigma c=0. The K pieces of both comparators coincide.
Thus Maux chi=Mchart chi exactly, including the global tail. The resulting
image is smooth periodic: its nonconstant q part vanishes near every face.
No iteration of the ordinary chart generator on arbitrary core vectors,
essential self-adjointness or exponentiated representation follows.

## 5. Projection normalization and support volume

The radius-3 lambda/4 ball has normalized volume

    (4 pi/3)(3 lambda/4)^3/(2 pi)^3
       =9 lambda^3/(128 pi^2)=eta^2.

Cauchy–Schwarz in each full q fiber gives |alpha(K)|<=eta ||phi(K)||.
A K derivative has the same uniform support, so after integrating K,
||alpha||<=eta and ||partial_Kj alpha||<=eta Bj/lambda. Orthogonality gives
n^2=||P phi||^2=1-||alpha||^2>=1-eta^2. This is one scalar global norm.
Neither n nor Z is differentiated in K; fiberwise renormalization is absent.

## 6. Free remainder and every full-torus tail term

On the free support, sine and cosine Taylor remainders give

    |gj-Kj| <= |Kj|^3/6+2|Kj|qj^2
       <= (1/384+108/384)lambda^3=109 lambda^3/384,
    |wj-qj| <= 2|qj|^3/3+Kj^2|qj|/2
       <= (36/128+3/128)lambda^3=39 lambda^3/128.

Both constants are below 1/3. For each spin contribution,
|1-cos(kia)cos(kib)|<=(kia^2+kib^2)/2<=49 lambda^2/128.
The two terms each have prefactor one-half, producing the same final bound
49 lambda^2/128. Multiplying these bounds by actual derivative norms gives
||Vab phi||<=[49/128+(Ba+Bb+Va+Vb)/3]lambda^2 as claimed.

On the global tail c alpha, the auxiliary K coefficients are constant in q
and vanish under the outer P. The q derivatives are exactly zero. Therefore
the entire projected tail is

    P Vab(c alpha)=-i ra partial_Kb alpha
                    +i rb partial_Ka alpha+sab alpha.

ra=ga c has mean zero and full-torus norm <=|sin(Ka)|<=lambda/4.
Using Ca=cos(Ka/2), Ta=sin(Ka/2), the difference of the two cosine products
in the spin term is -2(Ca Tb cos(qa)sin(qb)+Ta Cb sin(qa)cos(qb)).
This proves the exact sab in the source. It lies pointwise in the triplet
and hence in P, with norm <=|Ta|+|Tb|<=lambda/4. These give
eta[(Ba+Bb)/4+lambda/4] after K integration. No corner restriction is made
on the output, and no contact component is omitted.

For Qa applied to a supported f, use full-fiber output norms
||h||<=sqrt(6)<3, ||ha||<=lambda/8, and supported input bounds
|h(q)|<=2|q|<=3 lambda/2,
|ha(q)|<=|Ka||qa|/2<=3 lambda^2/32. The rank-one inequality gives

    ||Qa f|| <= [(lambda/8)(3 lambda/2)
                   +3(3 lambda^2/32)]eta ||f||
               =15 lambda^2 eta ||f||/32.

After a K derivative this is 15 lambda eta(Ba+Bb)/32. Qa c=0 removes
the derivative of the contact subtraction exactly. This establishes BR22
without assuming that the projected input remains supported or free-band.

Combining these three remainder estimates and dividing by n proves BR23.
The auxiliary/chart equality proves the same bound for Mchart on these
prepared states. With scaled derivative norms uniformly bounded, it is
O(lambda^(3/2)), hence o(lambda). It is a statewise result, not an L2
operator-norm limit without derivative control.

## 7. Explicit packet and constants

For p(t)=(1-t^2)^2 on (-1,1), direct polynomial integration gives
int p^2=256/315 and int (p')^2=256/105. The scaled product F0 therefore
has each derivative norm (8 sqrt(3))sqrt(3)=24 and support in radius 1/8.
The L1-normalized positive radial mollifier has radius 1/512. Translation
in H1 gives a difference norm <=24 sqrt(3)/512<1/8. Its convolution has
L2 norm >=7/8, so normalization yields derivative norm <=192/7 and support
radius 65/512. The mollifier convolution makes F smooth.

The relative f is smooth, radial and even on an annulus separated from
zero. Each projector is smooth on the resulting support because
lambda/2<=|q +/- K/2|<=7 lambda/8 and each sine energy is >=3 lambda/8.
The pointwise free positive sum is between lambda and 2 lambda: one can use
(7/8)(|q+K/2|+|q-K/2|)>=7|q|/4>35 lambda/32 for the lower bound.

The singlet ++ weight is (1+splus dot sminus/(AB))/4. The exact dot-product
identity is sum sin^2(qj)-sum sin^2(Kj/2), positive on this support; its
normalized ratio is at most one. Thus 1/4<=weight<=1/2 and
1/2<=Z<=1/sqrt(2). Under K=lambda kappa,q=lambda x, the two normalized
measures contribute lambda^6/(2 pi)^6. The squared prefactor in u cancels
this exactly. The even f and exchange covariance of the product projector
give antisymmetry. The packet is a normalizable six-variable direct-integral
state, not a fixed fiber or a distributional direction.

For the new q derivative constant, set u=16(r-11/16) and
g(u)=exp[-256/(1-u^2)]. On |u|<=1/32,
512/(1-u^2)<=512*1024/1023<513, so int g^2>=exp(-513)/16.
The derivative square is 512^2 u^2 y^4 exp(-512y), y=(1-u^2)^-1>=1.
Since d log(y^4 exp(-512y))/dy=4/y-512<0, this is bounded by
512^2 exp(-512); integrating and dividing gives at most 32 e 512^2,
strictly below 96*512^2. Radial symmetry and rmax/rmin=6/5 give

    ||partial_xj f||^2
       <(1/3)(36/25)*16^2*96*512^2
        =(18/25)2^32 <2^32.

The normalized Pauli vector derivative satisfies
||partial_qj Pi_plus||<=1/(2A). Two tensor factors yield
lambda ||partial_qj Pi_++||<=8/3. In K the single-particle derivative has
an extra factor 1/2, giving product bound 4/3. Dividing by global Z>=1/2,

    Bj<=384/7+8/3<60,
    Vj<=2||partial_xj f||+16/3<2^18.

Every higher derivative exists for a fixed positive lambda. The global
projection preserves this smooth domain. In the energy quadratic form,
<c,H0c>=0, ||C H0 phi||<=2 lambda eta and ||C phi||<=eta bound both cross
terms by 4 lambda eta^2 in total. Dividing by n^2 gives B30 and the asserted
[lambda/2,3 lambda] expectation range. This is not spectral support after P.

For the final coefficient, Ba+Bb<=120, Va+Vb<=2^19,
nu1<1/4, n>=1/2 and sqrt(lambda)<=1/4 yield exactly BR28. Its expression
is below 2^17. Thus all constants in BR3 follow from the specified smooth
family. They are very loose but finite and independent of lambda.

## 8. Corners and retained limitations

At q=C+x, Cj in {0,pi}, sin and cos each acquire epsilon_j=cos Cj.
Their product j_a=sin(ka)cos(ka) has unchanged leading offset, whereas the
spin face coefficient has epsilon_a epsilon_b. This proves BR29. The
ordinary q coordinate is not the shifted offset x. The theorem and its
auxiliary/chart agreement therefore remain origin-preparation statements.
The global constant tail may occupy all corners because its estimates used
full-torus norms; this does not identify populated other-cone packets with
the origin family.

Nothing above controls the K/q derivative norms of evolved projected
packets, proves a time interval, closes other Lie brackets, supplies a
physical continuous rotation, or proves exponentiation. The local chart
counterexample says only that this ordinary expression fails to preserve
the full periodic H1/smooth core. It is not a general no-go.

## Reconstruction outcome before author evidence

No material algebraic, normalization, domain or constant error was found in
BR1–BR29 on the frozen source. The genuinely new conditional contribution
is the compressed contact formula and prepared-state norm comparison;
the free-walk formula and reflected spin are prior art. This analytic
reconstruction is the principal mathematical evidence. The planned sparse
real-space control will independently challenge the actual excluded-pair
algebra; it cannot prove the all-packet analytic estimate by finite sampling.
