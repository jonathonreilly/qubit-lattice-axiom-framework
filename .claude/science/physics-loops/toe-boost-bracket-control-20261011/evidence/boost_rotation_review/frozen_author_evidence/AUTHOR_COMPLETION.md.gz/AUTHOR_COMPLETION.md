# Boost/rotation recovery author record

2026-10-11. This is recovery and completion of the originating author's
candidate, not an independent scientific review or retained-status audit.
The recovery agent inherited the selected model and effort without override.
The task permits external evidence only and ends before 2026-10-12 16:00:52 UTC.

The frozen candidate is `../EXCLUDED_WALK_BOOST_ROTATION_PROBE.md`; its final
identity and this record's identity are in `receipt.json`. The initial source
had 589 lines and SHA-256
`b27195f9db4d7b50d0a97599209b259eaaa99e0b2e6bd6093e5eb94a0e0f306a`.
Every initial boost_rotation file and that candidate were copied before
recovery edits into `recovery_initial_20261011T2202Z/`, with a byte manifest.

## Target and status

The target is the exact compression identity BR1 and the norm comparison
BR23, including its specified smooth positive-positive origin preparation
and explicit specialization BR3. The free single-walker identity is matching
prior art, not a new result. The compressed contact contribution, actual
chart-domain restriction, and quantitative projected-packet comparison are
the additional author argument under examination.

The walk symbol, antisymmetric two-record Hilbert space, full-torus contact
projection, continuous clock, positions and symmetric energy placement are
supplied mathematical hypotheses. This result does not adopt a physical axiom
or primitive. No approved primitive is reclassified as an unresolved import.
No dynamics, preparation selector or physical rotation group is derived from
the framework axioms here.

The status remains proposed conditional mathematical support with author
checks. Independent review of this full boost/rotation argument is pending.
There is no formal audit verdict, PR, commit or repository source edit from
this recovery. The next decision belongs to the supervisor: obtain a focused
independent check of this frozen source before substantial downstream reuse.

## Complete and partial source reading

The receipt gives hashes, byte counts and exact ranges. Recovery read the
following complete sources, not just their summaries:

- the initial 589-line candidate and, after edits, the complete final candidate;
- all 744 lines of the boost/current source, B1–B32;
- all 190 lines of the canonical-current draft;
- all 188 lines of the root boost/current review report;
- all 185 lines of the evolved boost/current draft, for the boundary of its
  different bracket only; none of its time estimates proves a new BR result;
- all 186 lines of the exact rotation control, all 39 lines of its execution
  wrapper, all 65 lines of the first-run output, and the complete execution,
  source-input and prior-art metadata;
- all 252 lines of the pinned free boost-charge note and all 196 lines of the
  free Dirac Poincare note;
- all 18 lines of the saved prior-art search output.

The 1280-line published energy-current parent was read only at lines 1–175,
370–478 and 805–844. These include the actual supplied fiber and contact
normalization, relevant channel/corner distinction, complete canonical
density/dipole/contact-block calculation, and explicit projection caveat.
Its remaining scattering, Cook and coherent-current proof is outside this
recovery's read coverage and is not a premise of BR1–BR29. The load-bearing
prepared-packet proof was read completely in the boost/current source.

The interspecies-rigidity note and its publication receipt appear in the
inherited source-input inventory. Their hashes were checked, but their text
was not read in this recovery and no result from them is used. Likewise,
reading the root review report is not a new execution or independent
recertification of the prior boost/current controls. No complete search of
external literature or current open PRs is claimed.

Applicable entry points, science workflow, skill freshness, physics-loop
entry and Discovery/Claim Status/Delivery references, workhorse entry,
no-go discipline, primitive-check instructions and the complete primitive
registry were read. They match local pinned main
`a13caa4885f547c8d206265b031ba7649e539fd9`; planning AGENTS was read at
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. Source identities are recorded
in `recovery_source_validation.json`. No fetch was performed during this
read-only repository task, so no fresh remote-state claim is made.

## Analytic author checks

1. **Differential and compression signs.** Expanding
   `d_a=i(h partial_a+h_a/2)` cancels the second state derivatives and mixed
   second symbol derivatives. Pauli anticommutators give the scalar orbital
   coefficients and Pauli commutators give the positive spin term in
   `i[d_a,d_b]`. Changing variables gives BR9 without a hidden factor of two.
   For the compressed pair, `partial_qa(h1-h2)=2 partial_Ka H0` supplies the
   fiber-adjoint cancellation. Inserting the two BR10 contact blocks into
   the exact compressed commutator produces BR11 with its displayed signs.
   The second K derivatives cancel, leaving both first derivatives with
   `Q_a=partial_Ka |h><h|`; no constant term is generated. The coefficient
   divergence vanishes by equality of mixed derivatives, consistent with
   formal symmetry. This does not establish essential self-adjointness.

2. **Domains and the actual comparator.** P is independent of K and maps
   each Sobolev space into itself. The smooth periodic core with compact K
   support is invariant under the dipoles; individual products are H2-to-L2
   while their normal-ordered commutator is H1-to-L2. The ordinary chart
   expression is H1-to-L2 on the selected cell and is symmetric there by
   transverse periodic integration by parts. For `G(K)c cos(q_a)`, a radial
   G makes the K orbital part vanish and the total spin annihilates c. The
   remaining `-iG c q_b sin(q_a)` has the nonzero face jump stated in the
   note, so it does not belong to periodic H1. The auxiliary cutoff is smooth,
   odd and periodic; its transverse orbital divergence is zero, and its
   total spin annihilates c. Its action commutes with P. It agrees with the
   actual linear chart expression on the compact relative support AND on
   the constant-q contact subtraction. BR15 is exact on the prepared state.

3. **Global normalization and tail.** The normalized relative volume is
   `9 lambda^3/(128 pi^2)`. Cauchy–Schwarz bounds alpha and each K derivative
   with this same volume factor. The normalization n is one global scalar,
   so it is not differentiated. On the tail, the auxiliary constant K
   coefficients disappear only after the outer P; the surviving periodic
   `g_a c` term still multiplies `partial_Kb alpha`. The spin difference on
   c is precisely the BR20 formula and has full-torus norm at most lambda/4.
   No relative support is assigned to this output.

4. **Constants and the contact estimate.** The free coefficient remainders
   are `109 lambda^3/384` and `39 lambda^3/128`; the spin norm is at most
   `49 lambda^2/128`. The full-torus h norm is at most sqrt(6)<3, and the
   h_j norm is at most lambda/8. On the input support their pointwise norms
   are at most `3 lambda/2` and `3 lambda^2/32`. The two rank-one terms in
   Q_j therefore sum to `(15/32) lambda^2 eta`. Q_j c=0 removes the contact
   subtraction from this term, not from the free multiplier difference.
   Adding these specific terms yields BR23 and the claimed statewise bound.

5. **Specified packet and its additional derivative.** The parent gives
   the explicit smoothed F, its support and derivative constant, the
   positive-positive projector weight in [1/4,1/2], and the single global
   Z. These were checked from its displayed construction, including the
   normalized K and q measures. The annular f becomes
   `g(u)=exp[-256/(1-u^2)]` after `u=16(r-11/16)`. On |u|<=1/32 its squared
   integral is at least exp(-513)/16; monotonicity of
   `y^4 exp(-512 y)` for y>=1 bounds the derivative integral. Including the
   radial Jacobian, its factor 1/3 for each Cartesian derivative, and the
   radius ratio 36/25 gives `(18/25)2^32<2^32`. The projector derivative
   contributes at most `8/(3 lambda)` before division by Z. Thus B_j<60
   and V_j<2^18 follow with no derivative of a fiberwise normalization.
   The BR28 rational budget is `67137247/768<2^17`. Every higher derivative
   exists for each positive lambda because the envelope support avoids the
   individual zero energies and vanishes smoothly at its boundary.

6. **Corner and time scope.** The orbital sine-cosine coefficient has the
   same leading offset at a reflected corner, but its spin has the product
   of corner signs in BR29. The global tail was estimated over every q;
   the prepared free packet itself occupies only the origin cone. A
   different corner's coordinate offset cannot replace the chosen cell's
   actual q. No argument in this packet propagates the q-derivative and
   exact prepared-tail hypotheses in time. The evolved boost/current result
   concerns a different normal form and is not transferred to this bracket.

## Finite evidence and independence limits

The first run at 2026-10-11T21:59:16.404794Z recorded exit 0 without timeout
in 0.4998505408875644 seconds. Its source SHA-256 is
`434b2cb6fb520f06d2a0de2c4287910880e0c0b0a31a335b8dedd9f1efea7959`
and its complete stdout SHA-256 is
`95ee24b704f07a711b61950c4b3cc0b7dbabd95f677880ca17bb43ac838e96cc`.
Recovery verified these identities and the 63 unique records plus summary.
It did not rerun the unchanged scientific script.

The local second-jet calculation uses enough symbol derivatives to calculate
the complete commutator of the first-order one-body dipoles. The abstract
four-dimensional fixture has complex nonconstant h and a Hermitian bath;
its off-diagonal blocks implement BR10 without importing the earlier
Fourier helper. The omissions/sign reversals are in-process adverse
expressions. They show limited detection ability, not a complete mutation
campaign or independent mathematical audit. Domain, normalization and
small-parameter norm estimates are supplied by the analytic proof.

The recorded interpreter is Python 3.13.5. Recovery separately inspected
SymPy 1.14.0 in that interpreter; the original execution metadata did not
record a SymPy version, so this is an environment observation at recovery,
not a retrospective attestation. No numerical continuum extrapolation,
Lean proof, compiler run or physical packet simulation is claimed.

## Narrow negative-scope assessment (N1–N8)

The negative finding is only that BR13 fails to preserve the specified
unrestricted smooth/H1 periodic core. Its explicit witness proves that
statement. This external author record makes no general rotation no-go and
does not claim a formal no-go packet PASS.

| Item | Actual assessment |
|---|---|
| N1 | The actual unrestricted chart route fails by the exhibited face trace. Two live repairs are restricting the domain to supported smooth packets and choosing a periodic continuation, both implemented in the positive theorem with their distinct scope. This does not supply five closed route families; the formal packet minimum is unmet. |
| N2 | No count of independent obstruction walls is asserted. The supplied model and packet assumptions are hypotheses, not proved mutually independent walls. No pairwise independence conclusion is used. |
| N3 | The exact phrase scan found only three canonical-placement/source-table occurrences. Each points to the explicitly supplied symmetric density. The derivative and origin-support conditions are stated in BR2/BR23, and the global tail is retained. |
| N4 | No prior no-go is used as evidence for the face-jump conclusion. The prior free-boost result matches BR7–BR9 and its reflected corner sign only; the continuum Dirac result is context. Neither certifies the interacting domain statement. |
| N5 | The witness is one smooth antisymmetric global torus section with a nonzero boundary trace. The separate symbolic control checks that trace, not every lattice-site resolution or every possible rotation domain. There is no claim of a universal physical obstruction and no added N5 cache certificate. |
| N6 | Domain restriction and a periodic auxiliary continuation are mathematical choices already used here; they require no adoption of a new physical axiom. No claim that a new axiom is required is made. |
| N7 | Strongest objection to a broad no-go: an invariant restricted domain or a different global generator may avoid the face jump. BR15 itself supplies a restricted positive comparison. This leaves any broader no-go unsupported while preserving the exact witness on its original core. |
| N8 | The saved pinned-main search and fully read free-boost note were checked. Their formal long-wave/domain qualifications are consistent with the narrow conclusion. No complete repository-wide historical-wall or open-PR scan was performed, so no exhaustive echo clearance is claimed. |

The domain finding is a partial narrowing for submission purposes: the exact
core counterexample is retained, while the larger family remains open. The
five-route and execution-certificate limitations are procedural limits of
this external packet, not evidence against the analytic counterexample.

## Recovery changes, interruptions and open work

Recovery changed only the candidate's evidence/status prose and made the
fixed K chart radius explicit, so the entire stated lambda range has compact
K support. All BR1–BR29 equations and bounds are unchanged. The prior-art
coverage sentence now distinguishes complete note reads from displayed
search hits. No editable prompt file, repository source, original control,
first-run output or upstream source was changed.

The dispatch reported repeated context-compaction failures of the originating
author. Their raw failure transcript is not in this assigned evidence set;
this record preserves that reporting limit instead of inventing causes,
counts or compiler errors. The stale initial checkpoint still described the
finite controls as pending even though their successful first-run evidence
was present. Its exact bytes remain in the initial snapshot. Several recovery
tool displays truncated broad instruction/search output; the necessary
instruction files were subsequently reread in bounded complete outputs.
The full argument, controls and relevant proof segments were not certified
from a truncated display. No failed scientific test was removed or retried.

Rejected shortcuts remain explicit: calling the prior free identity new;
dropping the first-derivative contact correction; treating global projection
as preserving a cone band; equating the global chart expression with a smooth
torus vector field; substituting origin spin at all corners; and borrowing a
time interval from the different boost/current bracket. These are scope
checks of this argument, not fabricated historical experiments.

The remaining scientific action is a separate independent check of BR1,
BR15 and BR23/BR27 on the final frozen source. Any actual-evolution theorem,
global generator/domain construction, additional commutator or physical
identification requires its own argument. The recovery does not declare
those routes impossible or the campaign complete.
