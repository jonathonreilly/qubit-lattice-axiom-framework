"""Preserve the first full exact-control execution without overwriting logs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
source = D / "exact_rotation_controls.py"
log = D / "first_run.log"
record = D / "execution.json"
assert not log.exists() and not record.exists()
command = [sys.executable, str(source)]
started = datetime.now(timezone.utc).isoformat()
t = time.monotonic()
timed_out = False
try:
    result = subprocess.run(command, cwd=D, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=90)
    code, output = result.returncode, result.stdout
except subprocess.TimeoutExpired as exc:
    code, output = 124, (exc.stdout or b"")+b"\nTIMEOUT after 90 seconds\n"
    timed_out = True
log.write_bytes(output)
record.write_text(json.dumps({
    "command": command, "cwd": str(D), "started_utc": started,
    "elapsed_seconds": time.monotonic()-t, "timeout_seconds": 90,
    "timed_out": timed_out, "exit_code": code,
    "python": sys.version, "platform": platform.platform(),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "log_sha256": hashlib.sha256(output).hexdigest(),
    "scope": "Same-author exact Pauli differential and abstract compression controls, not independent science review or a continuum proof."
}, indent=2)+"\n")
sys.stdout.buffer.write(output)
print("RECORDED_EXIT", code)
sys.exit(code)
