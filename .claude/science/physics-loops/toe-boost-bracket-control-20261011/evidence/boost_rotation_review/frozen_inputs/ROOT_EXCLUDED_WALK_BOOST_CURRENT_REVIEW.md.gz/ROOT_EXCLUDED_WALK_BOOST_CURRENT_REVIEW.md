# Independent root review of the prepared boost/current argument

2026-10-11. Scoped mathematical review, not a retained-status audit.

Target: all 744 lines of `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md`, SHA-256
`903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923`.
No consequential defect was found in B1-B32 under the stated supplied-model,
domain and preparation assumptions. No mathematical source repair is requested.
The positive conclusion concerns the specified prepared states, and the
restricted counterexamples do not assert a general gravity obstruction.

## Independence and exact reading boundary

Root did not author this target or its two finite helpers. Root reconstructed
the argument from the complete source, then read its complete 319-line
Fourier/jet helper, 74-line Pauli helper, both full outputs and the receipt.
Root also wrote the separate abstract finite-matrix control described below.
The author helpers were visible before that control was made: this is a
distinct algebraic representation and independent checking, not blind discovery.

Root authored the earlier canonical-current source used as a premise, SHA
`79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`.
That prior source and its separate independent review were already fully read
and checked in the campaign. Their unchanged identities are reused; this
report does not count root's review as another independent certification of
that root-authored premise. The full published parent at SHA
`9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401`
has likewise already received complete source and review inspection.

The frozen C3 report and both referees were read completely earlier at the
same hashes. They motivate the bracket choice, but their historical numerical,
literature and broad disposition claims are not premises of this proof and
are not independently recertified here. The newer candidate-law revision
`b568c14df54a5e64f904f54f0251b2173f9302c3` leaves those C3 sources unchanged.

Root separately authored `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md`
after checking this preparation theorem. That extension is outside this
review's independent coverage and is assigned to another reviewer. Nothing
in this report upgrades the frozen target's prepared-state-only scope.

## Domain and exact contact algebra

The K chart, full normalized q torus, singlet contact vector and antisymmetric
exchange condition match the supplied parent. P removes one contact vector
per fiber, not one per cone. Smooth periodic q sections with compact K support
form the common core used by the commutators. H0, P and the displayed J
preserve H1; the first-order dipole is continuous H1 to L2 on the chart.
The calculation does not require essential self-adjointness of the dipole.

In the coordinate change, X1=i(partial_K+partial_q/2) and
X2=i(partial_K-partial_q/2). Both differentiation terms from symmetrization
are needed. Since partial_q(H1-H2)=2partial_K H0, they sum to i partial_K H0.
Thus D=i(H partial_K+L), with the stated L. Integration by parts in q gives
L*=-P(H1-H2)partial_q P/2. Its sum with L is partial_K H, which also verifies
the full K-integrated symmetry of the dipole expression.

The off-diagonal contact blocks follow with the signs in B8. In CD0P, the
q integration-by-parts contribution cancels the explicit partial_K H0 term,
leaving i c<h,partial_K psi>. In PD0C, the input scalar is differentiated
as well, giving i partial_K(h f). Substituting these blocks into the
compressed Hamiltonian/dipole commutator cancels the input derivative and
leaves the two finite-rank current terms -|h_a><h|-|h><h_a|. This is the
actual current for the fixed energy placement, not a replacement by free g.

The free scalar g commutes with H0. Its dipole bracket differentiates only
g, giving the diagonal ell in B11. The compressed scalar-current bracket
has exactly -partial_K(h<r,psi>)+r<h,partial_K psi>. Its derivative
coefficient is -|h><r|+|r><h| and its constant terms are -|h_a><r|-|h><r_a|.
Adding the bracket of D with F gives [H,F]partial_K+H F_a+[L,F]. The right
action in [L,F] must use L*, and expanding it gives all four final terms of
B13. Thus both A in B12 and B in B13 have the displayed signs and factors.
No input q derivative remains. The input K derivative does remain.

The explicit axis witness in B17-B18 is consistent with the singlet identities.
H h_b before removing its mean is -sin(K_b) sin(q_b)^2 c, so H_D h_b=r_b/2.
The singlet expectation of H0 cubed vanishes, and the contact correction
leaves <h,H_D h>=0. Substitution gives the component
2 sin(K_b)(sin(q_j)^2+sin(q_k)^2-2sin(q_b)^2). Its norm squared is
3 sin(K_b)^2 from the independent circle variances 1/8. Therefore A is not
identically zero. A compactly supported smooth K section times exp(i M K_a)
proves the stated lack of an unrestricted L2 bound: the derivative term grows
linearly in M while all constant terms stay bounded. It is correctly limited
to that unrestricted relative-momentum class, not the prepared-band norm.

## Support estimates, global projection and normalization

Each retained corner ball has radius 3lambda/4. Dividing its Euclidean volume
by (2pi)^3 gives 9lambda^3/(128pi^2); the disjoint union yields B19. The
form-factor bounds use the full torus, including the output outside this
support. In particular H_D h and H_D h_b retain their subtracted contact
constants. The tabulated bounds 22 and 7lambda/8 are conservative and valid.
The L and L* bounds include the differentiation of the form factors and
the possible constant projection in their outputs.

For A, the six rank-one contributions sum to (85/8)lambda before multiplying
by nu_m lambda^(3/2). For B they sum to
17+(39/8)lambda+(5/32)lambda^2. Both are below the chosen constants 12lambda
and 24 on the stated range. These are analytic support-volume bounds, not
finite-grid or spectral-truncation estimates.

Global contact removal obeys ||C phi||<=eta and n^2>=1-eta^2. Both A and B
annihilate c; their right form factors, including the L* ones, lie in P.
The same is true for the K-derivative term. The single global normalization
n has no K derivative. In contrast the multiplier defect cannot ignore the
subtracted contact tail: its contribution is bounded by 8eta, as in B23.
On the original support, |ki-Cj|<=7lambda/8 gives the 4lambda^3 bound.
Adding these terms proves B24 for all nine components. The off-diagonal
components may omit the multiplier defect; the stated uniform bound is safe.

The treatment of eight corners is coherent: all amplitudes enter the same
contact scalar, and a bound using the union's measure already includes their
interference. It neither creates eight independent contacts nor identifies
other total-momentum corners with the selected K chart.

## Specified positive-band packet

The product-polynomial envelope has one-dimensional squared norms 256/315
and derivative squared norm 256/105. Scaling each coordinate by 8sqrt(3)
therefore gives derivative norm 24. Convolution changes the L2 norm by at
most 24sqrt(3)/512<1/8, while not increasing its derivative norm. Renormalizing
gives 192/7 and the support bound 65/512<1/4. The final envelope is smooth;
the intermediate C1 polynomial is used only to obtain its explicit H1 bound.

The joint prefactor (2pi)^3lambda^-3 compensates both normalized torus
measures and the six scaled variables. The even q envelope and singlet
exchange parity make the ++ packet antisymmetric. On its support the two
individual momenta are separated from zero. Their sine norms are at least
3lambda/8, and their positive sum is between 35lambda/32 and 7lambda/4.
The lower bound uses |q+K/2|+|q-K/2|>=2|q|, not a cancellation of bands.

The singlet projection weight lies between 1/4 and 1/2. Its positive numerator
is the exact identity epsilon(q)^2-epsilon(K/2)^2. Consequently the global
normalization Z is at least 1/2. Each one-body positive projector derivative
has norm at most 1/(4 epsilon), which gives the stated bound 4/(3lambda)
for the product. Combining this with the envelope and fixed global Z yields
B_a<60. All q derivatives remain finite for each lambda, as the projectors
are smooth away from the two individual zero energies.

The constants 384 and 6 follow from B24 using nu_m<=1/4 and n>=1/2.
The energy statement is about the expectation. In the contact correction,
||CH0 phi||<=2lambda eta and ||C phi||<=eta, while <c,H0c>=0. Both cross
terms are therefore bounded by 4lambda eta^2 in total. Dividing by n^2
gives B30 and the expectation interval [lambda/2,3lambda]. No projected
spectral-window preservation is asserted.

## Mixed-band counterexample and limits

At the stated axis point the (+,-) energy is sqrt(2)sin(t/2), whereas the
free multiplier defect is -sqrt(2)sin(t)cos(t/2)-sqrt(2)sin(t/2). The two
ratios in the source follow by first derivatives at zero. The normalized
two-patch construction is necessary: its disjoint exchanged supports make
the antisymmetrization norm exact, and its bands stay uniformly separated.
Uniform Taylor expansion on the fixed scaled supports yields B31. The
finite-rank and contact-tail errors are O(lambda^(3/2)), and the outer
contact projection of the multiplier is O(lambda^(5/2)). They vanish after
division by lambda, giving the positive norm limit B32. The energy expectation
correction is O(lambda^4), since the supported free total energy is O(lambda).

This is a valid restricted counterexample to replacing low individual
momenta by low total energy and momentum. It lies outside the ++ preparation
and central timelike shell. It proves no general impossibility for other
preparations, density placements, or interacting gravitational completions.

## Distinct finite check and evidence

`boost_current_root_review/abstract_compression_control.py` uses four-dimensional
exact matrices with two polynomial real parameters, a normalized constant
contact vector, commuting diagonal free H0/G symbols with zero contact means,
and independently constructed first-order dipoles satisfying the required
contact-block identities. It compares their direct compressed differential
bracket with the B12-B16 normal form on a nonconstant complex polynomial
section. It checks four index pairs and nonzero derivative coefficients, and
detects omission of the derivative term in each pair. It imports none of the
author helpers and uses neither their Fourier representation nor circle moments.

All 18 exact controls completed with exit 0 in 15.687 seconds under a
90-second timeout using Python 3.13.5 and SymPy 1.14.0. The complete output
was read. These test an abstract compression identity; the fixture is not
claimed to be a physical Weyl Hamiltonian/current realization. The packet,
domain, asymptotic and norm arguments above remain analytic. The deliberate
omission comparisons are in-process adverse expressions, not separately
executed primary source mutants. No extra author-helper execution is claimed.

The source-bound receipt records full input/output identities. No author
source, frozen failure, physical axiom, main branch or editable prompt was
changed. This review supports the bounded prepared-state theorem at its
exact hash. Actual-evolution control, other algebra brackets, and physical
law identification require their own arguments and checks.
