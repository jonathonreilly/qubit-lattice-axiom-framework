#!/usr/bin/env python3
"""Exact sparse infinite-lattice check of the ACTUAL excluded pair bracket.

Independent implementation: coordinate first moments + elementary site shifts.
No Fourier/Taylor jet, generic compression fixture or author code is imported.
The finite input supports are propagated without truncation or periodic wraps.
All coefficients are Gaussian rationals represented by two fractions.Fraction.
These finite fixtures supplement the universal analytic proof, not replace it.
"""
from fractions import Fraction as F
from itertools import product
import json

Z = (F(0), F(0))
ONE = (F(1), F(0))
I = (F(0), F(1))


def ga(a, b):
    return (a[0] + b[0], a[1] + b[1])


def gm(a, b):
    return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])


def put(v, key, value):
    value = ga(v.get(key, Z), value)
    if value == Z:
        v.pop(key, None)
    else:
        v[key] = value


def combine(*terms):
    out = {}
    for scalar, vec in terms:
        for key, value in vec.items():
            put(out, key, gm(scalar, value))
    return out


def scale(value, vec):
    return combine((value, vec))


def minus(a, b):
    return combine((ONE, a), ((F(-1), F(0)), b))


def norm2(vec):
    return sum((r*r + im*im for r, im in vec.values()), F(0))


def pauli(key, particle, axis):
    new = list(key)
    bit = key[6 + particle]
    if axis == 0:
        new[6 + particle] = 1 - bit
        factor = ONE
    elif axis == 1:
        new[6 + particle] = 1 - bit
        factor = (F(0), F(1 if bit == 0 else -1))
    else:
        factor = (F(1 if bit == 0 else -1), F(0))
    return tuple(new), factor


def position(vec, particle, axis):
    return {key: gm((F(key[3*particle + axis]), F(0)), value)
            for key, value in vec.items() if key[3*particle + axis] != 0}


def centre(vec, axis):
    return combine((ONE, position(vec, 0, axis)),
                   (ONE, position(vec, 1, axis)))


def hop(vec, particle, axis, displacement, scalar, spin_axis=None):
    out = {}
    for key, value in vec.items():
        if spin_axis is not None:
            key, factor = pauli(key, particle, spin_axis)
            value = gm(factor, value)
        new = list(key)
        new[3*particle + axis] += displacement
        put(out, tuple(new), gm(scalar, value))
    return out


def sine_term(vec, particle, axis):
    # Fourier convention psi(k)=sum_x exp(-i k.x) psi(x).
    # A displacement -1 has symbol exp(+i k), so sin(k)=(T_- -T_+)/(2i).
    return combine((ONE, hop(vec, particle, axis, -1, (F(0), F(-1, 2)), axis)),
                   (ONE, hop(vec, particle, axis, +1, (F(0), F(+1, 2)), axis)))


def hi(vec, particle):
    return combine(*[(ONE, sine_term(vec, particle, axis)) for axis in range(3)])


def H(vec):
    return combine((ONE, hi(vec, 0)), (ONE, hi(vec, 1)))


def velocity(vec, axis):
    return combine(*[(ONE, hop(vec, particle, axis, step, (F(1, 2), F(0)), axis))
                     for particle in range(2) for step in (-1, +1)])


def C(vec):
    return {key: value for key, value in vec.items() if key[:3] == key[3:6]}


def P(vec):
    return {key: value for key, value in vec.items() if key[:3] != key[3:6]}


def D0(vec, axis):
    terms = []
    for particle in range(2):
        terms.append(((F(1, 2), F(0)), position(hi(vec, particle), particle, axis)))
        terms.append(((F(1, 2), F(0)), hi(position(vec, particle, axis), particle)))
    return combine(*terms)


def D(vec, axis):
    return P(D0(P(vec), axis))


def momentum(vec, particle, axis):
    return combine((ONE, hop(vec, particle, axis, -2, (F(0), F(-1, 4)))),
                   (ONE, hop(vec, particle, axis, +2, (F(0), F(+1, 4)))))


def epsilon(a, b, d):
    if len({a, b, d}) < 3:
        return 0
    return 1 if (a, b, d) in [(0, 1, 2), (1, 2, 0), (2, 0, 1)] else -1


def free_rotation(vec, a, b, include_spin=True):
    terms = []
    for particle in range(2):
        terms += [(ONE, position(momentum(vec, particle, b), particle, a)),
                  ((F(-1), F(0)), position(momentum(vec, particle, a), particle, b))]
        if include_spin and a != b:
            d = 3 - a - b
            for sa, sb in product((-1, 1), repeat=2):
                first = hop(vec, particle, a, sa, (F(1), F(0)), d)
                second = hop(first, particle, b, sb, (F(epsilon(a, b, d), 8), F(0)))
                terms.append((ONE, second))
    return combine(*terms)


def rank_kernel(vec, axis):
    # 2 Q_axis = V_axis C H + H C V_axis.
    return combine((ONE, velocity(C(H(vec)), axis)),
                   (ONE, H(C(velocity(vec, axis)))))


def correction(vec, a, b):
    return scale((F(1, 4), F(0)), minus(rank_kernel(centre(vec, b), a),
                                      rank_kernel(centre(vec, a), b)))


def antisym_seed(x, y, spin, value):
    key = tuple(x) + tuple(y) + tuple(spin)
    exchanged = tuple(y) + tuple(x) + (spin[1], spin[0])
    return combine((ONE, {key: value}), ((F(-1), F(0)), {exchanged: value}))


def check_antisym(vec):
    exchanged = {key[3:6]+key[:3]+(key[7], key[6]): value for key, value in vec.items()}
    return not combine((ONE, vec), (ONE, exchanged))


fixtures = []
for n, centre_point in enumerate(((0, 0, 0), (2, -1, 3), (-3, 2, 1), (1, 4, -2))):
    terms = []
    displacements = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, -1, 0), (2, 0, -1))
    for j, displacement in enumerate(displacements):
        y = tuple(centre_point[k] + displacement[k] for k in range(3))
        for s1, s2 in product((0, 1), repeat=2):
            value = (F((j+1)*(n+2)+s1-2*s2, 3+n), F(j-n+2*s1+s2, 5+n))
            terms.append((ONE, antisym_seed(centre_point, y, (s1, s2), value)))
    fixtures.append(combine(*terms))

records = 0
mutants = {"drop_contact": 0, "reverse_contact_sign": 0,
           "halve_contact": 0, "drop_face_spin": 0}
for f_index, vec in enumerate(fixtures):
    assert vec and check_antisym(vec) and P(vec) == vec
    print(json.dumps({"fixture": f_index, "input_support_entries": len(vec),
                      "input_norm_squared": str(norm2(vec)), "antisymmetric": True,
                      "excluded": True}, sort_keys=True))
    for a, b in product(range(3), repeat=2):
        left = scale(I, minus(D(D(vec, b), a), D(D(vec, a), b)))
        free = P(free_rotation(P(vec), a, b))
        contact = correction(vec, a, b)
        right = combine((ONE, free), (ONE, contact))
        delta = minus(left, right)
        assert not delta, (f_index, a, b, norm2(delta))
        assert check_antisym(left) and P(left) == left
        assert check_antisym(contact) and P(contact) == contact
        records += 1
        row = {"fixture": f_index, "axes": [a, b], "exact_residual_norm_squared": "0",
               "left_support_entries": len(left), "contact_norm_squared": str(norm2(contact))}
        if a != b:
            wrong = {
                "drop_contact": free,
                "reverse_contact_sign": minus(free, contact),
                "halve_contact": combine((ONE, free), ((F(1, 2), F(0)), contact)),
                "drop_face_spin": combine((ONE, P(free_rotation(vec, a, b, False))), (ONE, contact)),
            }
            rejects = {name: norm2(minus(left, candidate)) for name, candidate in wrong.items()}
            for name, residual in rejects.items():
                assert residual > 0, ("non-discriminating fixture", f_index, a, b, name)
                mutants[name] += 1
            row["wrong_object_residual_norm_squared"] = {name: str(value) for name, value in rejects.items()}
        else:
            assert not left and not contact
        print(json.dumps(row, sort_keys=True))

print(json.dumps({"identity_cases": records, "wrong_object_rejections": mutants,
                  "arithmetic": "Gaussian rationals via Fraction",
                  "lattice": "infinite Z^3 x Z^3, exact sparse propagation, no truncation",
                  "scope": "finite exact operator fixtures; not an analytic packet-limit proof"}, sort_keys=True))
print("TOTAL: PASS=36 FAIL=0; WRONG_OBJECT_REJECTIONS=96")
