#!/usr/bin/env python3
"""Deterministic provenance checks only; no scientific verdict from hashes."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
S = HERE.parent
W = S.parent / "walk_worktree"
A = S / "boost_rotation"
rows = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(name, ok, **detail):
    row = dict(check=name, ok=bool(ok), **detail)
    rows.append(row)
    print(json.dumps(row, sort_keys=True))


receipt = json.loads((A / "receipt.json").read_text())
bindings = []


def walk(node, route="$" ):
    if isinstance(node, dict):
        if isinstance(node.get("path"), str) and isinstance(node.get("sha256"), str):
            path = Path(node["path"])
            content = path.read_bytes()
            matches = sha(content) == node["sha256"]
            if "bytes" in node:
                matches &= len(content) == node["bytes"]
            if "lines" in node:
                matches &= len(content.splitlines()) == node["lines"]
            bindings.append(route)
            record("author_receipt_binding", matches, route=route, path=str(path), sha256=sha(content))
        for key, value in node.items():
            walk(value, route + "." + str(key))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            walk(value, route + "[" + str(index) + "]")


walk(receipt)
for row in receipt["initial_preservation"]["files"]:
    frozen = Path(row["snapshot"]).read_bytes()
    record("author_initial_snapshot", sha(frozen) == row["sha256"], path=row["snapshot"], sha256=sha(frozen))
    if not row["original_current_change_authorized"]:
        original = Path(row["original"]).read_bytes()
        record("author_original_preserved", original == frozen, path=row["original"])

source_inputs = json.loads((A / "source_inputs.json").read_text())
for source in source_inputs["sources"]:
    data = Path(source["path"]).read_bytes()
    record("upstream_identity_guard", sha(data) == source["sha256"] and len(data) == source["bytes"],
           path=source["path"], sha256=sha(data))

for source in json.loads((A / "prior_art_sources.json").read_text()):
    data = Path(source["copy"]).read_bytes()
    original = subprocess.check_output(["git", "show", source["revision"] + ":" + source["repo_path"]], cwd=W, timeout=30)
    record("prior_art_git_blob", data == original and sha(data) == source["sha256"], path=source["copy"],
           revision=source["revision"], sha256=sha(data))

search = subprocess.run(source_inputs["search_command"], cwd=source_inputs["search_cwd"],
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
record("saved_prior_art_search_reproduces", search.returncode == source_inputs["search_exit"]
       and search.stdout == (A / "prior_art_search.log").read_bytes() and not search.stderr,
       exit_code=search.returncode, timeout_seconds=30, output_sha256=sha(search.stdout))

old = Path(receipt["initial_candidate"]["path"]).read_text()
new = Path(receipt["candidate"]["path"]).read_text()
old_blocks = re.findall(r"\\\[(.*?)\\\]", old, flags=re.S)
new_blocks = re.findall(r"\\\[(.*?)\\\]", new, flags=re.S)
record("recovery_equations_unchanged", old_blocks == new_blocks and len(new_blocks) == receipt["equation_block_count"],
       blocks=len(new_blocks))
expected_diff = "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                            fromfile="initial/EXCLUDED_WALK_BOOST_ROTATION_PROBE.md",
                                            tofile="frozen/EXCLUDED_WALK_BOOST_ROTATION_PROBE.md"))
record("recovery_diff_exact", expected_diff == (A / "recovery_diff.patch").read_text())

execution = json.loads((A / "execution.json").read_text())
record("author_executed_source_and_log", execution["source_sha256"] == sha((A / "exact_rotation_controls.py").read_bytes())
       and execution["log_sha256"] == sha((A / "first_run.log").read_bytes())
       and execution["exit_code"] == 0 and execution["timed_out"] is False,
       recorded_timeout_seconds=execution["timeout_seconds"], rerun=False)
log_lines = (A / "first_run.log").read_text().splitlines()
checks = [json.loads(line)["check"] for line in log_lines if line.startswith('{"check":')]
record("author_log_records", len(checks) == len(set(checks)) == 63 and "TOTAL: PASS=63 FAIL=0" in log_lines,
       records=len(checks), unique=len(set(checks)))

for row in json.loads((HERE / "source_manifest.json").read_text())["sources"]:
    current = Path(row["source_path"]).read_bytes()
    frozen = Path(row["frozen_path"]).read_bytes()
    record("review_input_still_frozen", current == frozen and sha(current) == row["sha256"],
           path=row["source_path"], sha256=sha(current))

evidence_names = ["AUTHOR_COMPLETION.md", "checkpoint.json", "exact_rotation_controls.py", "execution.json",
                  "first_run.log", "freeze_verification.json", "prior_art_search.log", "receipt.json",
                  "recovery_diff.patch", "recovery_source_validation.json", "run_controls.py", "scope_scan.json"]
copies = []
(HERE / "frozen_author_evidence").mkdir(exist_ok=True)
for name in evidence_names:
    data = (A / name).read_bytes()
    target = HERE / "frozen_author_evidence" / name
    if target.exists():
        assert target.read_bytes() == data, "refusing to replace changed frozen author evidence"
    else:
        target.write_bytes(data)
    copies.append(dict(path=str(A/name), frozen_path=str(target), sha256=sha(data), bytes=len(data)))

result = dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              role="deterministic source/evidence verification; not scientific proof",
              author_receipt_bindings=len(bindings), checks=len(rows), issues=[r for r in rows if not r["ok"]],
              results=rows, frozen_author_evidence=copies)
(HERE / "evidence_verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"binding_records": len(bindings), "checks": len(rows), "issues": result["issues"]}, sort_keys=True))
raise SystemExit(bool(result["issues"]))
