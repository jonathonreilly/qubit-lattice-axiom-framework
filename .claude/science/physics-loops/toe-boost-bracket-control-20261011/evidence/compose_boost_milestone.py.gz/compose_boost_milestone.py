"""Compose preserved boost arguments; publication verification follows separately."""
from pathlib import Path
import gzip
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent / 'boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-bracket-control-20261011'
P.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
note_rel = 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
primary_rel = 'scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
sources = [
    ('EXCLUDED_WALK_BOOST_CURRENT_PROBE.md', '903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923', [
        ('# Prepared-state boost/current control for the supplied excluded Weyl pair', '# Part I — Prepared-state boost/current control'),
        ('Date: 2026-10-11. External research derivation; no repository edits.', 'Source date: 2026-10-11. Original argument preserved with the publication edits recorded in the evidence packet.'),
        ('**Status:** proposed conditional mathematical result, with author finite-algebra\ncontrols. This is not an independently reviewed result or a retained-status\naudit.', '**Status:** conditional mathematical result. The source-bound review and its independence limits are recorded in the publication evidence. No retained-status audit is assigned here.'),
    ]),
    ('EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md', 'd89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929', [
        ('# Growing-time boost/current control for the prepared excluded walk', '# Part II — Growing-time boost/current control'),
        ('2026-10-11. Root-authored conditional extension, pending selective independent\nreview. No repository, physical axiom, or audit-status change.', 'Source date: 2026-10-11. Root-authored conditional extension, with a completed selective independent source review. No physical axiom or audit status is changed.'),
        ('the proposed extension is', 'the conditional extension is'),
        ('The actual energy stays in [lambda/2,3lambda] by conservation.', 'The actual energy expectation stays in [lambda/2,3lambda] by conservation. This is not a spectral-support statement.'),
        ('explicit proof below checks;', 'explicit proof below;'),
    ]),
    ('EXCLUDED_WALK_BOOST_ROTATION_PROBE.md', '53f883ca7f01cdeb338e1c4d41367695fc6bdb32ee0ceb2905df50238a0c4760', []),
    ('BOOST_CURRENT_INVERSE_ENERGY_PROBE.md', '76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990', [
        ('# A time threshold for the supplied excluded-walk boost/current residual', '# Part IV — A sharp time threshold for the boost/current norm'),
    ]),
]
front = '''---
claim_id: excluded_walk_boost_bracket_control_bounded_theorem_note_2026-10-11
claim_type: bounded_theorem
claim_scope: "For the supplied antisymmetric excluded Weyl pair and canonical additive energy placement, exact compressed boost/current and boost/boost formulas give explicit prepared-packet residual bounds. The boost/current norm is o(lambda) below the lambda^(-1/2) time threshold, has a positive energy-scaled limit at that threshold, and is Theta(sqrt(lambda)) at specified small inverse-energy times. Operator domains and all physical premises remain explicit."
upstream_dependencies:
  - excluded_walk_low_energy_energy_current_bounded_theorem_note_2026-10-11
runner: scripts/excluded_walk_boost_bracket_control_2026_10_11.py
---

# Boost-bracket control for the supplied excluded Weyl pair

**Date:** 2026-10-11. **Type:** bounded_theorem.

**Status:** conditional-support; provisional mathematics, without an applied
retained-status audit. The supplied walk, continuous clock, antisymmetric pair,
site exclusion, spatial coordinates and chosen energy placement are premises.

The four complete arguments below use one globally normalized positive-positive
origin-cone preparation. Part I gives the exact differential boost/current
bracket and an explicit norm bound. Part II controls its actual evolution for
times at most lambda^(-gamma), gamma<1/2. In this interval lambda*t tends to
zero, so it is shorter than the inverse-energy clock. Part III computes the
boost/boost contact correction and compares it to a rotation on the prepared
state, with the ordinary momentum chart and a periodic auxiliary operator
distinguished explicitly. Part III does not inherit Part II's time estimate.

Part IV locates the sharp power threshold for the norm in Part II using the
same packets. At time lambda^(-1/2), its norm divided by lambda tends to a
strictly positive constant. At time tau/lambda for fixed 0<tau<=1/32768,
the norm is Theta(sqrt(lambda)). These are diagonal-component norm results;
they do not give the corresponding expectation or exclude other preparations.
The complete zero-space and integrability arguments are rederived in Part IV,
with the earlier memory milestone credited as prior mathematical work.

The energy interval stated for the excluded state is an expectation bound.
It is not preserved individual-cone or spectral support. These estimates do
not construct an exponentiated boost, a physical rotation group, a full
Poincare algebra, or gravitational dynamics. Constants are conservative.

Each part retains its original equation and section numbering. A reference
to a section within a part refers to that part. Frozen research sources,
explicit publication edits and exact reconstruction are preserved in the
[milestone evidence](../.claude/science/physics-loops/toe-boost-bracket-control-20261011/).
The original sources' historical status prose is superseded only by the
source-bound publication review recorded there; no status is inferred from
a finite-control count.

**Parent:** [canonical current and excluded-walk premises](EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md),
complete branch revision b9b032ae790c66e762a6296a1306bfb64ae7cd70.
**Runner:** [finite algebra and constant controls](../scripts/excluded_walk_boost_bracket_control_2026_10_11.py).
**Negative-claim scope:** [N1–N8 assessment](../.claude/science/physics-loops/toe-boost-bracket-control-20261011/NO_GO_DISCIPLINE_CHECKLIST.md).

'''
parts = [front]
mapping = {'publication_path': note_rel, 'prefix': front, 'parts': []}
for name, digest, edits in sources:
    data = (S / name).read_bytes()
    assert sha(data) == digest, name
    text = data.decode()
    if name.endswith('BOOST_ROTATION_PROBE.md'):
        heading = text.splitlines()[0]
        edits = [(heading, '# Part III — Boost/boost contact correction and rotation domains')]
    for old, new in edits:
        assert text.count(old) == 1, (name, old, text.count(old))
        text = text.replace(old, new)
    frozen = P / 'evidence' / (name + '.gz')
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(gzip.compress(data, mtime=0))
    parts.append(text)
    parts.append('\n\n')
    mapping['parts'].append({'source_path': str(S / name), 'source_sha256': digest,
                             'preserved_source': str(frozen.relative_to(P)),
                             'edits': [{'before': a, 'after': b} for a, b in edits],
                             'separator': '\n\n'})
note = ''.join(parts)
(W / note_rel).write_text(note)
mapping['publication_sha256'] = sha(note.encode())
(P / 'PUBLICATION_EDITS.json').write_text(json.dumps(mapping, indent=2) + '\n')
(P / 'reconstruct.py').write_text('''"""Verify exact preservation and the explicit publication edits."""
from pathlib import Path
import gzip, hashlib, json
P=Path(__file__).resolve().parent
W=P.parents[3]
sha=lambda b:hashlib.sha256(b).hexdigest()
d=json.loads((P/'PUBLICATION_EDITS.json').read_text())
parts=[d['prefix']]
for row in d['parts']:
 b=gzip.decompress((P/row['preserved_source']).read_bytes())
 assert sha(b)==row['source_sha256']
 t=b.decode()
 for e in row['edits']:
  assert t.count(e['before'])==1
  t=t.replace(e['before'],e['after'])
 parts.extend([t,row['separator']])
b=''.join(parts).encode()
assert sha(b)==d['publication_sha256']
assert (W/d['publication_path']).read_bytes()==b
print('PASS: complete argument source preservation and explicit publication edits')
''')
print(json.dumps({'note': str(W / note_rel), 'sha256': mapping['publication_sha256'],
                  'lines': len(note.splitlines()), 'status': 'composition only; publication checks pending'}))
