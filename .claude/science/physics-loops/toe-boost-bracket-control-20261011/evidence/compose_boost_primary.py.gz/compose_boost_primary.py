"""Preserve the original finite helpers inside one self-contained primary."""
from pathlib import Path
import gzip, hashlib, json

S=Path(__file__).resolve().parent
W=S.parent/'boost_worktree'
P=W/'.claude/science/physics-loops/toe-boost-bracket-control-20261011'
sha=lambda b:hashlib.sha256(b).hexdigest()
rel='scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
sources=[
 ('boost_current/exact_controls.py','c6b2ec3789b768421d9b5cab9547edc27943c4f78403199c58975388f8e74af4','boost_current'),
 ('boost_current/axis_witness_control.py','2f09aefbd801fe28ba91ef514c759efb51c633005994d9a9658100326107c563','axis_witness'),
 ('boost_rotation/exact_rotation_controls.py','434b2cb6fb520f06d2a0de2c4287910880e0c0b0a31a335b8dedd9f1efea7959','boost_rotation'),
 ('boost_current_inverse_energy/inverse_energy_controls.py','6d78602b981cdc197be8531afbf905192e2651ddb26f24be4e25afccc752e02d','inverse_energy'),
 ('boost_current_inverse_energy/kernel_bound_control.py','6fe2a0b54e4cca013dacea54b70d83c46c4b9e77c31218973f24be7715e28dc9','kernel_bound'),
]
front='''#!/usr/bin/env python3
"""Finite algebra and constants for the conditional excluded-walk boost note.

The preserved helpers use exact rational/Pauli/Fourier or symbolic algebra,
plus a floating three-vector forcing fixture with explicit tolerances.
Their namespaces are separate. These are source-author controls;
publication replay does not constitute independent mathematical review.
The source note's analytic domain, packet and evolution proofs are separate.
No stochastic, network or external-data input is read. The last two helpers
hash this primary's own bytes for provenance. The note is declared
for repository evidence binding. Run with assertions enabled.
"""
AUDIT_TIMEOUT_SEC = 180
AUDIT_INPUT_PATHS = [
    "docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]
if not __debug__:
    raise RuntimeError("Run without -O: exact control assertions must be enabled")

'''
parts=[front]
rows=[]
for name,digest,label in sources:
 b=(S/name).read_bytes(); assert sha(b)==digest
 text=b.decode(); assert "'''" not in text
 block="_SOURCE_"+label.upper()+" = r'''"+text+"'''\n"
 block+="print("+repr('BEGIN '+label+' finite author evidence')+", flush=True)\n"
 block+="exec(compile(_SOURCE_"+label.upper()+", "+repr(label+'_preserved_helper')+", 'exec'), {'__name__': '__main__', '__file__': __file__})\n\n"
 parts.append(block)
 dst=P/'evidence'/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
 dst.write_bytes(gzip.compress(b,mtime=0))
 rows.append({'source_path':str(S/name),'source_sha256':digest,'preserved_source':str(dst.relative_to(P)),
              'label':label,'block':block})
tail='''print("per_element: exact Pauli, Fourier-coefficient and finite contact algebra checked; no continuum state-space exhaustion")
print("per_site: checked and not executed — these author helpers use Fourier and abstract compression, not infinite-site simulation")
print("per_mode: all eight reflected-corner sign patterns and finite Fourier modes checked; the continuum packet limits remain analytic")
print("per_block: full nine boost/current components and three boost/boost component pairs checked in the stated finite fixtures")
print("lattice_wide: checked and not executed — global analytic domain and prepared-packet bounds require the complete source proofs")
print("TOTAL: PASS=5 FAIL=0")
print("SCOPE: five preserved author-control modules, including 23 boost/current, 6 axis and 63 rotation checks plus forcing and integral controls; no count certifies the continuum proofs")
'''
parts.append(tail)
body=''.join(parts)
(W/rel).write_text(body)
(P/'PRIMARY_COMPOSITION.json').write_text(json.dumps({'publication_path':rel,'prefix':front,'sources':rows,'suffix':tail,'publication_sha256':sha(body.encode())},indent=2)+'\n')
print(json.dumps({'primary':str(W/rel),'sha256':sha(body.encode()),'lines':len(body.splitlines())}))
