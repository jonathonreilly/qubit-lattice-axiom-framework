# Evolved boost reconstruction before the distinct finite-vector control

Target: `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md`, SHA-256
`d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929`.
Complete 185-line target, complete 744-line prepared source at
`903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923`,
and complete 190-line canonical source at
`79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`
have been read. No author control code or log has been inspected in this
review. The target formulas and prepared-source evidence descriptions are
visible, so this is not a blind-discovery claim.

## Necessary prepared identities

For the fixed contact vector c and P=I-|c><c|, h=H0 c is in P because the
singlet expectation of H0 vanishes. Its K derivative is also in P. The
dipole formula D=i(H partial_K+L) gives the fiber adjoint
L^dagger=-P H_delta partial_q P/2, using partial_q H_delta=2 partial_K H0.
The compressed scalar-current part contributes
delta P ell P - partial_K(h<r,psi>) + r<h,partial_K psi>.
The rank-two current correction contributes
[H,F] partial_K+H partial_K F+[L,F]. Integrating the right q action gives
the displayed B13 signs and form factors. This yields E1 with no derivative
of the input in q. Every right form factor is in P, so A c=B c=0.

The source's full-torus estimates follow from bounded trigonometric
multipliers and the fixed projection. In particular, ||h||2<=3,
||h||infinity<=4, ||h_a||2,infinity<=lambda/8, ||h_ab||<=1/2,
||Hh||2<=12 and ||Hh||infinity<=22, with the latter including
the subtracted constant ||h||2^2<=6. Likewise ||Hh_b||2<=lambda/2,
||Hh_b||infinity<=7lambda/8. The two terms in L give ||Lh||2<=7,
||Lh_b||2<=3lambda/8. Applying P in the supremum norm costs at most
a factor two, giving ||L^dagger h||infinity<=8 and
||L^dagger h_b||infinity<=lambda/2.

With normalized torus measure, every right L2 norm is at most the listed
supremum norm. The six A terms sum to
(3/4+1+2+3/2+11/4+21/8)lambda=(85/8)lambda.
The B terms sum to 17+39lambda/8+5lambda^2/32. They are <12lambda and
<24 on 0<lambda<=1/16 without any relative-support premise. Together with
||M||<=8 this proves E5-E6 for allowed H1 sections. The volume factor is
used only for supported free inputs, not for w.

## Evolution and normalization

H(K)=PH0(K)P is bounded self-adjoint and decomposable in K. It preserves
the small K support and P. P is K independent and commutes with periodic
q differentiation on smooth sections. The trigonometric multipliers and
their derivatives are bounded. Thus H acts boundedly on each fixed finite
Sobolev space on a compact K chart; its exponential preserves smooth
sections for finite t. Compact K support, periodicity and antisymmetry
are preserved. This justifies applying E1 to psi, v and w, without any
claim about self-adjointness or exponentiation of the dipole.

||partial_K H||<=1 and the corresponding free bound imply the bounded
operator Duhamel derivative ||partial_K U(t)||<=t. This does not require
H to commute with its derivative. The same holds for U0.

The source packet has one global norm Z and one global projected norm n.
Both are constants with respect to the coordinate K. n is also kept fixed
in the entire time-dependent comparison; it is not ||P f(t)||. The free
packet f=U0(t)phi has norm one and the same fixed relative support. Its
K derivative has that support too and norm at most B_a/lambda+t.
Full-torus Cauchy-Schwarz on that support gives
||alpha||<=eta and ||partial_K alpha||<=eta(B_a/lambda+t).
The support is independent of K, and the contact functional is bounded,
so differentiating the contact integral is legitimate in H1.

For v=P f/n, i v_t=Hv+h alpha/n. Thus w=psi-v satisfies
i w_t=Hw-h alpha/n, w(0)=0, giving w=+i integral U h alpha/n.
This is E10's sign. Its derivative has three terms, from U(t-s), h and
alpha(s). Their integrated norm bounds are respectively
3eta t^2/(2n), lambda eta t/(8n), and
3eta(B_a t/lambda+t^2/2)/n. Their sum is exactly E12.
The undifferentiated bound is E11, 3eta t/n.

## Bracket and constants

E13 follows by applying the supported A and B bounds to f and its
derivative, while retaining the contact tail in P M P f. The derivative
constant is B_a+lambda t. The denominator is the original n. The terms
are 4lambda^3+8eta+12eta(B_a+lambda t)+24eta, as displayed.

For w, the global E6 bound gives
32||w||+12lambda||partial_K w|| <= eta/n times
[96t+36lambda t^2+36B_a t+(3/2)lambda^2 t].
Adding E13 yields E14, including the separate 12lambda t term.

Using eta/n<=lambda^(3/2)/2, B_a<=60, n>=1/2 and lambda<=1/16,
the constant term is <=(8+376)lambda^(3/2), the linear coefficient
inside braces is <=2256+3/4+3/512<2257, and the quadratic contribution
is <=18lambda^(5/2)t^2. This proves E2's conservative constants.
For t<=lambda^(-gamma), 0<=gamma<=1/2, lambda t<=1 and T>=1, so
384+1129t+18lambda t^2<=1531T<=1536T. Dividing E4 by lambda gives
lambda^(1/2-gamma), which vanishes only for strict gamma<1/2 in this
estimate. The endpoint is merely O(lambda), not a negative higher-time result.

For E15, A v=A f/n has norm <=12nu_m lambda^(5/2)/n, and A w is bounded
by 12lambda times E11. This gives E3. H and J are bounded self-adjoint,
psi is unit norm, and d<J>/dt=i<[H,J]>; integrating E3 gives exactly
lambda^(5/2)(6t+9t^2), E16.

The prepared energy expectation bound is inherited from B30 and is conserved
under U(t). The sentence “actual energy stays in [lambda/2,3lambda]” should
say “energy expectation”; a spectral-window assertion is not justified.
No numerical or physical selection premise is used to repair a proof step.

## Preliminary conclusion and independent control design

No mathematical extension defect found so far. No inherited defect found
in the necessary prepared identities or estimates just reconstructed.
The rest of the 744-line source is read but is not being given a separate
blanket review verdict here; root's source review remains distinct.

Construct a three-dimensional Hermitian matrix family H0(K) with
<c,H0(K)c>=0, K-dependent h=H0 c, and a compressed H whose derivative
does not commute with H. Use a smooth finite-vector section and one fixed
global normalization over several weighted K nodes. Compare direct
matrix-exponential evolution with the contact Duhamel integral, and use
matrix-exponential Frechet derivatives to check all three differentiated
terms. Deliberately omit each term, flip the contact sign, and substitute
fiber normalization to check that the fixture detects those mistakes.
This numerical finite-vector control will test the algebra and derivative
implementation, not prove the Hilbert-space bounds or physical premises.
