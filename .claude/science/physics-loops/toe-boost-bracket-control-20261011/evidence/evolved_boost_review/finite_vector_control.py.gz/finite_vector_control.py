"""Distinct actual-vector compression and differentiated-Duhamel controls.

This finite-dimensional family satisfies the structural contact hypotheses,
but is not the Weyl lattice, a continuum cutoff proof, or an E2 constant replay.
All matrix exponentials and derivatives act on actual complex three-vectors.
"""
import json
import platform
import time

import numpy as np
import scipy
from scipy.linalg import expm, expm_frechet

start = time.monotonic()
c = np.array([1, 0, 0], dtype=complex)
P = np.diag([0, 1, 1]).astype(complex)
K_nodes = np.array([-0.27, 0.11, 0.39])
K_weights = np.array([0.2, 0.3, 0.5])
times = [0.4, 1.3, 2.6]
quadrature_order = 96
gx, gw = np.polynomial.legendre.leggauss(quadrature_order)


def raw_phi(k):
    return np.array([0.17+0.03*k+0.05j*k,
                     (1+k/3)*np.exp(1j*k/5),
                     (0.4-k/7)*np.exp(-2j*k/3)], dtype=complex)


def raw_prime(k):
    return np.array([0.03+0.05j,
                     np.exp(1j*k/5)*(1/3+1j*(1+k/3)/5),
                     np.exp(-2j*k/3)*(-1/7-2j*(0.4-k/7)/3)], dtype=complex)


Z = np.sqrt(sum(w*np.vdot(raw_phi(k), raw_phi(k)).real
                for k, w in zip(K_nodes, K_weights)))
n = np.sqrt(sum(w*np.linalg.norm(P@raw_phi(k)/Z)**2
                for k, w in zip(K_nodes, K_weights)))


def symbols(k):
    h0 = np.array([[0, 1+k/3, 2/5-k/4],
                   [1+k/3, k, 1/2+k/7],
                   [2/5-k/4, 1/2+k/7, -2*k/3]], dtype=complex)
    dh0 = np.array([[0, 1/3, -1/4],
                    [1/3, 1, 1/7],
                    [-1/4, 1/7, -2/3]], dtype=complex)
    return h0, dh0, P@h0@P, P@dh0@P, h0@c, dh0@c


def propagator_and_prime(h, dh, t):
    return expm_frechet(-1j*t*h, -1j*t*dh, compute_expm=True)


def direct(k, t):
    h0, dh0, h, dh, contact, dcontact = symbols(k)
    phi, dphi = raw_phi(k)/Z, raw_prime(k)/Z
    u, du = propagator_and_prime(h, dh, t)
    u0, du0 = propagator_and_prime(h0, dh0, t)
    psi = u@P@phi/n
    dpsi = (du@P@phi+u@P@dphi)/n
    f = u0@phi
    df = du0@phi+u0@dphi
    v = P@f/n
    dv = P@df/n
    return psi, dpsi, f, df, v, dv, psi-v, dpsi-dv


def integral(k, t):
    h0, dh0, h, dh, contact, dcontact = symbols(k)
    phi, dphi = raw_phi(k)/Z, raw_prime(k)/Z
    value = np.zeros(3, dtype=complex)
    terms = [np.zeros(3, dtype=complex) for _ in range(3)]
    for node, weight in zip(gx, gw):
        s = t*(node+1)/2
        weight = weight*t/2
        u, du = propagator_and_prime(h, dh, t-s)
        u0, du0 = propagator_and_prime(h0, dh0, s)
        fs, dfs = u0@phi, du0@phi+u0@dphi
        alpha, dalpha = np.vdot(c, fs), np.vdot(c, dfs)
        value += weight*(u@contact)*alpha
        terms[0] += weight*(du@contact)*alpha
        terms[1] += weight*(u@dcontact)*alpha
        terms[2] += weight*(u@contact)*dalpha
    return 1j*value/n, [1j*x/n for x in terms]


norm = np.linalg.norm
rows = []
for k in K_nodes:
    h0, dh0, h, dh, contact, dcontact = symbols(k)
    assert norm(h0-h0.conj().T) == 0 and np.vdot(c, h0@c) == 0
    assert norm(P@contact-contact) == 0 and norm(h@dh-dh@h) > 0.1
    for t in times:
        psi, dpsi, f, df, v, dv, w, dw = direct(k, t)
        iw, differentiated = integral(k, t)
        idw = sum(differentiated)
        eps = 1e-5
        # The global Z and n stay fixed when evaluating the local K derivative.
        fdw = (direct(k+eps, t)[6]-direct(k-eps, t)[6])/(2*eps)
        u, du = propagator_and_prime(h, dh, t)
        naive = -1j*t*dh@u
        errors = {
            "duhamel": float(norm(w-iw)),
            "all_three_derivative_terms": float(norm(dw-idw)),
            "centered_K_difference": float(norm(dw-fdw)),
            "wrong_contact_sign": float(norm(w+iw)),
            "omit_propagator_derivative": float(norm(dw-(idw-differentiated[0]))),
            "omit_contact_vector_derivative": float(norm(dw-(idw-differentiated[1]))),
            "omit_contact_amplitude_derivative": float(norm(dw-(idw-differentiated[2]))),
            "commuting_exponential_shortcut": float(norm(du-naive)),
        }
        assert errors["duhamel"] < 2e-12
        assert errors["all_three_derivative_terms"] < 2e-12
        assert errors["centered_K_difference"] < 2e-8
        assert min(v for key, v in errors.items()
                   if key not in ["duhamel", "all_three_derivative_terms", "centered_K_difference"]) > 1e-5
        row = {"K": float(k), "t": t, "errors_or_wrong-route_discrepancies": errors}
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

normalization_rows = []
for k in K_nodes:
    phi, dphi = raw_phi(k)/Z, raw_prime(k)/Z
    local_n = norm(P@phi)
    local_n_prime = np.vdot(P@phi, P@dphi).real/local_n
    correct = P@dphi/n
    wrong_local = P@dphi/local_n - P@phi*local_n_prime/local_n**2
    discrepancy = float(norm(correct-wrong_local))
    assert discrepancy > 0.05
    normalization_rows.append({"K": float(k), "fiber_n": float(local_n),
                               "fiber_n_prime": float(local_n_prime),
                               "derivative_discrepancy_if_fiber_normalized": discrepancy})
print(json.dumps({"global_Z": float(Z), "global_n": float(n),
                  "normalization_controls": normalization_rows}, sort_keys=True))

J = np.array([[0, 0, 0], [0, 1, 0.3j], [0, -0.3j, -0.5]], dtype=complex)
initial_energy = sum(weight*np.vdot(direct(k, 0)[0], symbols(k)[2]@direct(k, 0)[0]).real
                     for k, weight in zip(K_nodes, K_weights))
global_rows = []
for t in times:
    psi_norm_sq = f_norm_sq = v_norm_sq = energy = derivative = commutator = 0.0
    for k, weight in zip(K_nodes, K_weights):
        psi, _, f, _, v, _, _, _ = direct(k, t)
        h = symbols(k)[2]
        psi_norm_sq += weight*norm(psi)**2
        f_norm_sq += weight*norm(f)**2
        v_norm_sq += weight*norm(v)**2
        energy += weight*np.vdot(psi, h@psi).real
        dpsi_dt = -1j*h@psi
        derivative += weight*(np.vdot(dpsi_dt, J@psi)+np.vdot(psi, J@dpsi_dt)).real
        commutator += weight*(1j*np.vdot(psi, (h@J-J@h)@psi)).real
    assert abs(psi_norm_sq-1) < 2e-13 and abs(f_norm_sq-1) < 2e-13
    assert abs(energy-initial_energy) < 2e-13
    assert abs(derivative-commutator) < 2e-13
    assert abs(v_norm_sq-1) > 0.01
    global_rows.append({"t": t, "psi_norm_squared": psi_norm_sq,
                        "free_norm_squared": f_norm_sq, "comparison_norm_squared": v_norm_sq,
                        "energy_expectation_error": abs(energy-initial_energy),
                        "current_derivative_identity_error": abs(derivative-commutator)})
print(json.dumps({"global_evolution_controls": global_rows}, sort_keys=True))
print(json.dumps({"status": "all specified finite-vector controls passed",
                  "cases": len(rows), "quadrature_order": quadrature_order,
                  "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
                  "elapsed_seconds": time.monotonic()-start,
                  "limits": "Floating-point finite-dimensional structural controls. No continuum norm bounds, actual lattice simulation, physical premises, or source-mutant executions are certified."}, sort_keys=True))
