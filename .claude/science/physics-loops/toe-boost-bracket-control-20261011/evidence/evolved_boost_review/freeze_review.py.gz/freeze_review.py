"""Freeze the review and its independent evidence without editing any source."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

D = Path(__file__).resolve().parent
S = D.parent
W = S.parent / "walk_worktree"
out = D / "receipt.json"
verification_path = D / "source_verification.json"
assert not out.exists() and not verification_path.exists(), "Preserve prior evidence"


def identity(path, role):
    path = Path(path)
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw), "logical_lines": len(raw.splitlines()), "role": role}


expected = [
    (S / "EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md", "d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929", "reviewed E1-E16 extension"),
    (S / "EXCLUDED_WALK_BOOST_CURRENT_PROBE.md", "903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923", "prepared-state source, complete reading and necessary-argument reconstruction"),
    (S / "EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md", "79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe", "canonical source, complete reading; only needed identities used"),
    (Path("/Users/jonreilly/.codex/skills/physics-claim-reviewer/SKILL.md"), "9d841edd05b9dc4c5145abcfd5352cd45460a1cc57c23c1eabd131590dbb1455", "reused applicable instruction"),
    (Path("/Users/jonreilly/.codex/skills/physics-loop/references/proof-search-governance.md"), "be4f955d9ff8a6f18c8f0f5fd6e872cac0ca95fcb752d86ec773961a4bb15258", "reused applicable instruction"),
    (W / "AGENTS.md", "f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f", "reused applicable instruction"),
    (W / "docs/ai_methodology/SCIENCE_WORKFLOW.md", "05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce", "reused applicable instruction"),
]
guards = [
    ("INTERSPECIES_CURRENT_RIGIDITY_REVIEW.md", "78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6"),
    ("interspecies_current_rigidity_review/receipt.json", "1c3c02926c6c35277fdde7a4b174b85d2471c3c3ec4da9d39681a3c9f2f68de7"),
    ("LEAN_RIGIDITY_STATEMENT_REVIEW.md", "14d5a11bf7476975b8067fd5d9c7f9e91381804a1b926fb324ff5b9bfd57b519"),
    ("interspecies_rigidity_lean_review/receipt.json", "974549d47ca67a1f82591d5cef2ab3fa3a2d5854b3b2404dfa58f265364c00a6"),
    ("FINAL_EXCLUDED_WALK_QUANTITATIVE_MEMORY_TRANSFER_NOTE.md", "284686962fe4cce3c59a93b89a9fc33776ffa2310dbc9c8e9c1e8bda809d049e"),
    ("excluded_walk_quantitative_memory_transfer_2026_10_11.py", "bf1a83f21e06818ba1182bfa186d13ccf971777afb52f70a09da0c69e0eaa85d"),
    ("quantitative_memory_transfer_composition/reconstruction_map.json", "c29df627eeedeaa21f1ce04abdec65f04aa58d5e3ce0b5266342497a5c9d586f"),
    ("quantitative_memory_transfer_composition/receipt.json", "c1e09e3b251469b7c27d02d79e8a1221c99598850454f02e42ba287f8592269e"),
]
expected += [(S / p, h, "prior-packet freeze guard, not a scientific premise") for p, h in guards]
sources, matches = [], []
for path, digest, role in expected:
    rec = identity(path, role)
    matches.append({"path": str(path), "expected_sha256": digest,
                    "actual_sha256": rec["sha256"], "matches": rec["sha256"] == digest})
    sources.append(rec)
assert all(x["matches"] for x in matches)
pre = json.loads((D / "pre_control_receipt.json").read_text())
assert identity(pre["reconstruction"]["path"], "check")["sha256"] == pre["reconstruction"]["sha256"]
for rec in pre["sources"]:
    assert identity(rec["path"], "check")["sha256"] == rec["sha256"]
execution = json.loads((D / "execution.json").read_text())
assert execution["exit"] == 0 and not execution["timed_out"]
assert identity(D / "finite_vector_control.py", "check")["sha256"] == execution["source_sha256"]
assert identity(D / "finite_vector_control.log", "check")["sha256"] == execution["log_sha256"]
rows = [json.loads(line) for line in (D / "finite_vector_control.log").read_text().splitlines()]
assert len(rows) == 12 and rows[-1]["cases"] == 9
assert rows[-1]["status"] == "all specified finite-vector controls passed"
stats = {"max_" + key: max(x["errors_or_wrong-route_discrepancies"][key] for x in rows[:9])
         for key in ["duhamel", "all_three_derivative_terms", "centered_K_difference"]}
stats["minimum_wrong_calculation_discrepancy"] = min(value for row in rows[:9]
        for key, value in row["errors_or_wrong-route_discrepancies"].items()
        if key not in ["duhamel", "all_three_derivative_terms", "centered_K_difference"])
verification = {"verified_utc": datetime.now(timezone.utc).isoformat(), "all_match": True,
                "source_records": matches, "source_count": len(matches),
                "pre_control_reconstruction_and_sources_unchanged": True,
                "execution_source_and_full_log_match": True, "execution": execution,
                "finite_control_summary": stats}
verification_path.write_text(json.dumps(verification, indent=2) + "\n")
report = identity(S / "EXCLUDED_WALK_EVOLVED_BOOST_REVIEW.md", "final independent E1-E16 review")
artifacts = [report] + [identity(p, "complete independent review evidence")
                       for p in sorted(D.iterdir()) if p.is_file() and p != out]
receipt = {
    "schema": "bounded-independent-evolved-boost-review-v1",
    "frozen_utc": datetime.now(timezone.utc).isoformat(),
    "target_sha256": expected[0][1], "prepared_source_sha256": expected[1][1],
    "disposition": "E1-E16 check under explicit supplied-model and preparation assumptions; no mathematical repair requested.",
    "publication_scope_clarifications": [
        "The conserved quantity in [lambda/2,3lambda] is the energy expectation, not a propagated spectral window.",
        "The growing supplied-clock interval remains below the inverse-energy time: lambda*t tends to zero; no order-one rescaled energy-time interval is controlled."
    ],
    "clarification_status": "Root acknowledged both; frozen author draft deliberately unchanged.",
    "independence": {"reviewer_authored_extension": False, "reviewer_authored_prepared_source": False,
                     "analytic_reconstruction_frozen_before_control_creation": True,
                     "author_helpers_or_logs_inspected_or_replayed": False,
                     "source_formulas_and_evidence_descriptions_visible": True,
                     "blind_discovery_claimed": False},
    "reading_coverage": {"extension": "Complete 185 lines, E1-E16.",
                         "prepared_source": "Complete 744 lines; necessary B5-B16 and B19-B30 arguments reconstructed. No blanket B1-B32 review verdict.",
                         "canonical_source": "Complete 190 lines; necessary canonical identities used, not all separate band/asymptotic claims recertified.",
                         "independent_evidence": "Complete pre-control reconstruction, helper, runner, full 12-line JSONL output, execution metadata, final report and checkpoint inspected.",
                         "instructions": "Complete earlier readings reused at unchanged verified identities."},
    "controls": {"kind": "Actual complex three-vector noncommuting contact-Duhamel and differentiated-evolution fixture.",
                 "formal_runs": 1, "failed_formal_runs": 0, "K_time_cases": 9,
                 "separate_source_mutant_processes": 0, "execution": execution,
                 "wrong_calculations": ["reversed contact sign", "omitted propagator derivative", "omitted contact-vector derivative", "omitted contact-amplitude derivative", "commuting-exponential shortcut", "fiber normalization"],
                 "summary": stats,
                 "limits": "Floating-point structural controls, not a Weyl lattice simulation, continuum certificate, or proof of the analytic constants."},
    "sources": sources, "artifacts": artifacts,
    "counts": {"sources": len(sources), "review_artifacts": len(artifacts)},
    "no_author_source_prior_packet_worktree_or_prompt_edits": True,
    "no_installation_or_dependency_changes": True,
    "no_audit_or_native_law_adoption": True,
    "open_scope": "Other boost/current and boost/boost brackets, order-one rescaled energy times, higher times, gravity algebras and many-body laws.",
    "receipt_self_hash": "Excluded to avoid self-reference; communicated separately."
}
out.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"review": report, "receipt": identity(out, "source-bound receipt"),
                  "source_verification": identity(verification_path, "source and execution identity check"),
                  "counts": receipt["counts"]}, indent=2))
