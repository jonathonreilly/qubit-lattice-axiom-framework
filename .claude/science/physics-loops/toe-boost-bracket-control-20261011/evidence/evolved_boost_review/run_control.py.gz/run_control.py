"""Preserve the first independent finite-vector execution and all output."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
source = D / "finite_vector_control.py"
log = D / "finite_vector_control.log"
meta = D / "execution.json"
assert not log.exists() and not meta.exists(), "Preserve every existing run"
command = [sys.executable, str(source)]
start = time.monotonic()
stamp = datetime.now(timezone.utc).isoformat()
try:
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    stdout, stderr, code, timeout = result.stdout, result.stderr, result.returncode, False
except subprocess.TimeoutExpired as ex:
    stdout = ex.stdout.decode() if isinstance(ex.stdout, bytes) else (ex.stdout or "")
    stderr = ex.stderr.decode() if isinstance(ex.stderr, bytes) else (ex.stderr or "")
    code, timeout = None, True
log.write_text(stdout+stderr)
record = {"started_utc": stamp, "command": command, "timeout_seconds": 90,
          "elapsed_seconds": time.monotonic()-start, "exit": code, "timed_out": timeout,
          "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
          "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
          "scope": "Distinct actual finite-vector Duhamel and K-derivative controls; not continuum proof."}
meta.write_text(json.dumps(record, indent=2)+"\n")
print(json.dumps(record, indent=2))
assert code == 0 and not timeout, "Failure preserved; never replace this execution"
