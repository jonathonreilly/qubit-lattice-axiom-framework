"""Preserve reviewed X and extend the existing boost milestone, without new science execution."""
from pathlib import Path
import gzip, hashlib, json, subprocess

S = Path(__file__).resolve().parent
W = S.parent / 'boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-bracket-control-20261011'
D = S / 'boost_expectation_publication'
OLD = '47cb1150396d0ed387f7ee6bd157dda156713f9e'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == OLD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W)
D.mkdir()
bindings = []
def verify(obj):
    if isinstance(obj, dict):
        if isinstance(obj.get('path'), str) and 'sha256' in obj:
            p = Path(obj['path'])
            if not p.is_absolute(): p = S / p
            b = p.read_bytes()
            assert sha(b) == obj['sha256'], p
            if isinstance(obj.get('bytes'), int): assert len(b) == obj['bytes'], p
            for key in ('snapshot', 'frozen_path'):
                if key in obj: assert Path(obj[key]).read_bytes() == b
            bindings.append({'path': str(p), 'sha256': sha(b)})
        for v in obj.values(): verify(v)
    elif isinstance(obj, list):
        for v in obj: verify(v)
for n in ('boost_expectation_review/receipt.json', 'boost_expectation_review/PRE_EVIDENCE_FREEZE.json'):
    verify(json.loads((S / n).read_text()))
expected = {
 'BOOST_CURRENT_EXPECTATION_PROBE.md': 'a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68',
 'BOOST_CURRENT_EXPECTATION_REVIEW.md': '0e17f9647141c200b1efcbe78f60ef6beedc1e249ce1b85544293dddbebe8690',
 'boost_expectation_review/receipt.json': '0ac3a2342ed0e27cb4dbbeaae08649fec925471a67a57d3be8677ef4f031eb37',
 'boost_expectation_review/PROOF_RECONSTRUCTION.md': '04adc0b81d3865f4819b8441e25279ef084bda755e9c0a3206be7d314ea04f9f',
}
for n, h in expected.items(): assert sha((S / n).read_bytes()) == h
(D / 'root_review_binding_check.json').write_text(json.dumps({
 'scope': 'Provenance only; complete source, author check, independent review and reconstruction separately read.',
 'binding_count': len(bindings), 'all_match': True, 'bindings': bindings}, indent=2) + '\n')

note = W / 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
primary = W / 'scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
cache = W / 'logs/runner-cache/excluded_walk_boost_bracket_control_2026_10_11.txt'
assert sha(primary.read_bytes()) == 'ad158ab067673f7ace2737b96475a45ce91cb3fc1718cf709e5c445f58f2a550'
for p in [note, cache] + sorted(P.glob('*')):
    if p.is_file():
        out = D / 'before_47cb115' / p.relative_to(W)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(p.read_bytes())

emap = json.loads((P / 'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}
def preserve(p):
    b = p.read_bytes()
    dst = P / 'evidence' / (str(p.relative_to(S)) + '.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(b, mtime=0)
    if dst.exists(): assert dst.read_bytes() == packed, dst
    else: dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = {'original': str(p), 'preserved': rel, 'sha256': sha(b), 'bytes': len(b)}

mapping = json.loads((P / 'PUBLICATION_EDITS.json').read_text())
prefix = mapping['prefix']
prefix = prefix.replace('Operator domains and all physical premises remain explicit.',
    'All nine actual residual expectations are o(lambda), uniformly on every fixed finite rescaled-time interval, by an explicit gapless forced-state limit and symmetric-form cancellation. Operator domains and all physical premises remain explicit.')
prefix = prefix.replace('The four complete arguments', 'The five complete arguments')
prefix = prefix.replace('they do not give the corresponding expectation or exclude other preparations.',
    'they do not imply an expectation estimate or exclude other preparations.')
needle = 'with the earlier memory milestone credited as prior mathematical work.\n'
assert prefix.count(needle) == 1
prefix = prefix.replace(needle, needle + '''
Part V proves the actual expectation result separately: all nine residual
expectations are o(lambda), uniformly for |tau|<=T at time tau/lambda for
each fixed finite T. The complete forced state converges in H1_kappa(L2_q)
to a compressed-kernel evolution. Symmetry controls both cross terms and
the limiting kernel self-pairing vanishes. Thus a small mean is compatible
with the larger diagonal residual norm. No convergence rate, growing-tau
interval or off-diagonal norm lower bound is asserted.
''')
mapping['prefix'] = prefix
mapping['parts'][-1]['separator'] = '\n---\n\n'
source = S / 'BOOST_CURRENT_EXPECTATION_PROBE.md'
text = source.read_text()
edits = [
 ('# Fixed inverse-energy-time expectation of the supplied boost/current residual',
  '# Part V — Actual boost/current expectations at inverse-energy time'),
 ('''2026-10-11. Author derivation by `boost_expectation_recovery`, continuing the
preserved checkpoint of an interrupted author. Conditional supplied-model
mathematical result; independent scientific review of this new argument is
pending. No physical premise, repository source, prior frozen note, or audit
status is changed.''',
  '''Source date: 2026-10-11. Conditional supplied-model mathematical result.
The complete source-bound independent review found no required repair within
X1–X35. Review identities, authorship and limits are recorded in the milestone
evidence. This publication applies no retained-status audit or physical premise.'''),
 ("Let `S` be this document's directory. These are the frozen mathematical",
  "Let `S` be the original research directory recorded in the milestone's\nEVIDENCE_MAP.json; its source bytes are preserved there. These are the frozen mathematical"),
 ('Author status fields are `target_claim_type: bounded_theorem`,\n`actual_current_surface_status: bounded-support`,',
  'Publication status fields are `target_claim_type: bounded_theorem`,\n`actual_current_surface_status: conditional-support`,'),
 ('''The present author has not carried out independent scientific review of its
own derivation. The appropriate next gate is a source-bound independent
check of the cutoff limit, the differentiated error equation, the exact
normalization, and the symmetric form pairings. A finite-dimensional model
or passing provenance check cannot certify this infinite-dimensional
gapless theorem. No scientific runner is claimed to do so.''',
  '''The separate source-bound independent review checked the cutoff limit,
the differentiated error equation, exact normalization and symmetric form
pairings, and reconstructed an alternative free-primitive/Volterra proof.
Root's mechanism suggestions are disclosed coauthorship. A finite-dimensional
model or passing provenance check cannot certify this infinite-dimensional
gapless theorem. No scientific runner is claimed to do so.'''),
 ('''Full source identities, recovery copies, author checks and limitations are
kept under `boost_current_expectation/`.''',
  '''Full source identities, recovery copies, author checks and limitations are
preserved losslessly under the milestone evidence's `boost_current_expectation/`
and `boost_expectation_review/` paths.'''),
]
for before, after in edits:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
preserve(source)
mapping['parts'].append({'source_path': str(source), 'source_sha256': sha(source.read_bytes()),
 'preserved_source': 'evidence/BOOST_CURRENT_EXPECTATION_PROBE.md.gz',
 'edits': [{'before': a, 'after': b} for a, b in edits], 'separator': ''})
parts = [prefix]
for row in mapping['parts']:
    raw = gzip.decompress((P / row['preserved_source']).read_bytes())
    assert sha(raw) == row['source_sha256']
    t = raw.decode()
    for e in row['edits']:
        assert t.count(e['before']) == 1
        t = t.replace(e['before'], e['after'])
    parts.extend([t, row['separator']])
note.write_text(''.join(parts))
mapping['publication_sha256'] = sha(note.read_bytes())
(P / 'PUBLICATION_EDITS.json').write_text(json.dumps(mapping, indent=2) + '\n')

updates = {
 'STATE.yaml': [('milestone: prepared_boost_brackets_and_sharp_current_time_threshold', 'milestone: boost_bracket_norm_threshold_and_actual_expectation'),
                ('pr_status: ready_for_regular_PR', 'pr_status: regular_PR_9484_open_expectation_extension_in_delivery'),
                ('next_action: open_regular_PR_after_explicit_staged_identity_checks', 'next_action: publish_reviewed_expectation_extension_to_regular_PR_9484')],
 'ROOT_COMPOSITION_REVIEW.md': [('All four original arguments', 'All five original arguments')],
 'PR_BACKLOG.md': [('while leaving\ncurrent expectations and alternative preparations open.', 'with a separate expectation derivation\nnow included in Part V; alternative preparations remain open.')],
 'NO_GO_DISCIPLINE_CHECKLIST.md': [
   ('weaker observables and other justified energy placements remain open.', 'other justified energy placements remain open. Part V positively resolves\nthe actual expectation for this same packet at every fixed finite tau interval.'),
   ('An actual expectation\nbound or a different preparation may answer a different physical question;\nthose routes are open.', 'Part V separately proves the actual expectation\nis o(lambda) at fixed rescaled time; the norm obstruction does not block it.\nDifferent preparations remain open.'),
   ('For expectations, cancellations unavailable to the norm\ncan occur; the present result does not close that route. Larger fixed tau\nalso remains open rather than being inferred from the small-tau estimate.',
    'Part V proves the required forced H1 limit and expectation cancellation\nfor each fixed finite tau interval. It preserves the norm lower bound and\ndoes not extend it to arbitrary fixed tau or unbounded rescaled time.')],
}
for name, pairs in updates.items():
    p = P / name; t = p.read_text()
    for before, after in pairs:
        assert t.count(before) == 1, (name, before)
        t = t.replace(before, after)
    p.write_text(t)
append = {
 'GOAL.md': 'Part V distinguishes the actual bracket expectation from the residual norm\nand constructs the fixed-rescaled-time forced limit for the same packets.\n',
 'ARTIFACT_PLAN.md': 'The fifth complete argument adds the fixed-time H1 forced-state limit and\nall nine expectation estimates. The existing primary is unchanged; its\nfinite calculations do not certify the new gapless analytic theorem.\n',
 'ASSUMPTIONS_AND_IMPORTS.md': 'Part V uses compact-family spectral convergence without a spectral gap,\na bounded inverse on the full complement, or an operator-norm limit. Every\nfirst kappa derivative is controlled by its exact differentiated equation.\nExpectations use common-core symmetry extended to H1 by the normal form.\n',
 'APPROACH_REGISTRY.md': 'The expectation extension proves the exact forced H1 limit by a spectral\ncutoff and differentiated error equation. A separate reviewer reconstructed\nit through a free spectral primitive, time approximation and a Volterra\nequation. Kernel compression cancels the limiting self-pairing; symmetry\nmoves both cross terms onto the small free-comparison residual.\n',
 'REVIEW_HISTORY.md': 'X: complete independent review\n0e17f9647141c200b1efcbe78f60ef6beedc1e249ce1b85544293dddbebe8690,\nwith pre-author-evidence reconstruction\n04adc0b81d3865f4819b8441e25279ef084bda755e9c0a3206be7d314ea04f9f.\nReceipt 0ac3a2342ed0e27cb4dbbeaae08649fec925471a67a57d3be8677ef4f031eb37\nbinds the complete X1–X35 source and review. No required repair was found.\nRoot read the complete source, author checks, reconstruction, final report\nand the reconstruction clarification; verified all bound source identities.\n',
 'ROOT_COMPOSITION_REVIEW.md': 'The expectation extension uses frozen X source\na7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68.\nRoot read all 587 lines, the complete author check, the separate complete\nreview and 426-line reconstruction. The latter was frozen before author\nevidence and adds a free-primitive/Volterra argument. Its preserved earlier\nwording needed only the clarification that a differentiated error tends\nuniformly to zero because the original error tends to zero in C1. Root\nsuggested the kernel cancellation and all-component extension and therefore\nis a coauthor, not the independent reviewer. No finite runner was added:\nthe new obligation was analytic. The old primary and twelve actual semantic\nmutants retain their source identities; they concern the earlier finite\ncalculations, not a new proof of X. Exact publication edits affect only\ntitles, status, source pointers and scope summaries; every X equation and\nproof step remains unchanged. Uniformity is on fixed compact tau intervals;\nno rate, growing tau, physical covariance or off-diagonal norm bound follows.\n',
 'ROUTE_PORTFOLIO.md': 'X has a separate pre-author-evidence reconstruction and alternate Volterra\nproof. It shares the exact source and supplied model, so independence means\na distinct checked derivation, not blinded discovery. Root contributed the\nmechanism and all-index suggestion and is not counted as independent.\n',
 'PR_BACKLOG.md': 'The regular PR9484 is open. Part V belongs in this same milestone because\nit answers the complementary mean-residual question for exactly the same\nmodel and preparation. It preserves the positive norm obstruction, avoiding\nan inference from norm size to expectation size. The full proof and its\ndistinct review replace the previously open expectation obligation.\n',
 'DELIVERY_CHECKS.md': 'The reviewed expectation extension changes the declared note input while\nleaving the primary source unchanged. A canonical cache refresh is required\nfor that input change; its result will be appended below. The original\ncomplete-primary mutation evidence remains bound to the unchanged primary.\nNo new finite runner is offered as verification of the X continuum theorem.\nThe prior worker disconnects and all old source versions remain preserved.\n',
}
for n, addition in append.items():
    p = P / n; p.write_text(p.read_text().rstrip() + '\n\n' + addition)
(P / 'OPPORTUNITY_QUEUE.md').write_text('''# Next scientific questions

The actual expectation and fixed-time forced dynamics are now established
conditionally for the same preparation. Next derive the explicit compressed
zero-space dynamics and its source-coupled spectrum. Rates and growing tau,
other justified energy placements and preparations, and full boost algebra
remain separate questions. The compact-patch scattering construction is
active elsewhere in the campaign, not a dependency of this milestone.
''')
for n in ('BOOST_CURRENT_EXPECTATION_REVIEW.md', 'boost_expectation_root_source_validation.json'):
    preserve(S / n)
for folder in ('boost_current_expectation', 'boost_expectation_review', 'boost_expectation_publication'):
    for p in sorted((S / folder).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts: preserve(p)
preserve(Path(__file__).resolve())
emap['files'] = [rows[k] for k in sorted(rows)]
(P / 'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2) + '\n')
subprocess.run(['python3', str(P / 'reconstruct.py')], cwd=W, check=True)
print(json.dumps({'note_sha256': sha(note.read_bytes()), 'review_bindings_matched': len(bindings),
                  'preserved_evidence_files': len(rows), 'primary_unchanged': True}))
