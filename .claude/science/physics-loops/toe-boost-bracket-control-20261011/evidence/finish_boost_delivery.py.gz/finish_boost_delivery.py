"""Freeze the boost milestone after actual source review and execution."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess
import sys
from urllib.parse import unquote

S = Path(__file__).resolve().parent
W = S.parent / 'boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-bracket-control-20261011'
BASE = 'b9b032ae790c66e762a6296a1306bfb64ae7cd70'
digest = lambda b: hashlib.sha256(b).hexdigest()
sha = lambda p: digest(p.read_bytes())
sys.path.insert(0, str(W / 'scripts'))
import runner_cache

# Independently recompute all path/hash records, without executing any theorem
# helper or modifying a frozen reviewer file.
bindings = []
def verify_bindings(obj):
    if isinstance(obj, dict):
        if isinstance(obj.get('path'), str) and 'sha256' in obj:
            path = Path(obj['path'])
            if not path.is_absolute():
                path = S / path
            data = path.read_bytes()
            assert digest(data) == obj['sha256'], path
            if isinstance(obj.get('bytes'), int):
                assert len(data) == obj['bytes'], path
            bindings.append({'path': str(path), 'sha256': digest(data)})
            if 'frozen_path' in obj:
                assert Path(obj['frozen_path']).read_bytes() == data
        for value in obj.values():
            verify_bindings(value)
    elif isinstance(obj, list):
        for value in obj:
            verify_bindings(value)

for name in ['boost_inverse_energy_review/receipt.json',
             'boost_inverse_energy_review/FINAL_FREEZE.json']:
    verify_bindings(json.loads((S / name).read_text()))
assert sha(S / 'BOOST_CURRENT_INVERSE_ENERGY_REVIEW.md') == 'd3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796'
assert sha(S / 'boost_inverse_energy_review/PROOF_RECONSTRUCTION.md') == 'c0a06917dc1f24207d85656781e250104c81dd613a9a937a140088149bf2f131'
(S / 'boost_inverse_energy_review_root_identity_check.json').write_text(json.dumps({
    'all_match': True, 'binding_count': len(bindings), 'bindings': bindings,
    'scope': 'Read-only provenance check; no scientific execution or audit verdict.'
}, indent=2) + '\n')

primary = W / 'scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
note = W / 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
body = primary.read_text()
mut = json.loads((S / 'boost_primary_mutations/manifest.json').read_text())
assert sha(primary) == mut['primary_sha256']
assert len(mut['runs']) == 12
for row in mut['runs']:
    d = S / 'boost_primary_mutations'
    assert body.count(row['before']) == 1
    actual = d / (row['name'] + '.py')
    assert actual.read_text() == body.replace(row['before'], row['after'])
    assert sha(actual) == row['mutant_sha256']
    for stream in ('stdout', 'stderr'):
        assert sha(d / (row['name'] + '.' + stream + '.log')) == row[stream + '_sha256']
    error = (d / (row['name'] + '.stderr.log')).read_text()
    assert 'AssertionError' in error and row['expected_failure_marker'] in error
    assert row['exit_code'] == 1 and not row['timed_out'] and row['intended_failure']
    assert row['elapsed_seconds'] < row['timeout_seconds'] == 180

old = json.loads(subprocess.check_output(['git', 'show', BASE + ':docs/audit/data/citation_graph_manifest.json'], cwd=W))
graph = W / 'docs/audit/data/citation_graph_manifest.json'
new = json.loads(graph.read_text())
assert (new['node_count'], new['edge_count']) == (old['node_count'] + 1, old['edge_count'] + 1)
assert all(new['nodes'][k] == v for k, v in old['nodes'].items())
assert set(new['nodes']) - set(old['nodes']) == {'excluded_walk_boost_bracket_control_bounded_theorem_note_2026-10-11'}
compat = json.loads((S / 'boost_focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []

(P / 'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete-source composition review

Root read the full B argument and distinct abstract compression evidence,
authored E, and read E's complete independent review, helper and output. Root
read all 628 BR lines, its author helper and outputs, its independent 149-line
report, 309-line reconstruction, 229-line actual real-space helper and full
42-line output. The latter checks exact sparse infinite-lattice coordinates
and shifts, with no wrap or finite-box truncation. Its 96 adverse expressions
are in-process controls, not complete-source mutants.

Root read the full 658-line T argument, its exact I0 amendment, both helpers,
all successful and failed outputs, and the complete new independent report
and reconstruction. T review d3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796
and reconstruction c0a06917dc1f24207d85656781e250104c81dd613a9a937a140088149bf2f131
find no material defect within T1–T24. The reviewer rebuilt the argument
before inspecting author evidence and selected no extra scientific runner:
finite fixtures cannot prove the gapless continuum limit. Root authored E
and suggested T's intermediate-time and I0 routes; this coauthorship is
disclosed and is not an independent review of T. The exact receipt is
9d32136c2f57a076dacec228ea4ecf1097782093f3f46830d48d3bed24aaaac0.

The checked mathematical boundaries include global packet normalization,
support used only for the free comparison, the entire excluded contact tail,
all first momentum-derivative factors, and bounded coefficients acting on
the singular zero vector. Energy bounds concern expectation. The original
rotation chart is distinguished from the periodic auxiliary operator.
The sharp-time norm theorem has no expectation conclusion. Every supplied
physical premise and all unpromoted fixed-time routes remain explicit.

All four original arguments are preserved through PUBLICATION_EDITS.json.
The small E wording changes distinguish energy expectation from spectral
support and state the already assumed time window. Publication frontmatter,
scope, parent links, source/status statements and the linked N1–N8 assessment
were read completely. Five exact original helper bodies remain in separate
namespaces; their publication replay is author evidence. The original helper
status statements remain historical. No finite PASS count changes status.

Full canonical output and all twelve complete-primary mutation stderr logs
were inspected. Byte reconstruction, single-replacement identities and all
saved output hashes were verified. Deterministic evidence binding is separate
from mathematical checking. No Lean claim, retained-status verdict, new
physical axiom or editable prompt change is made. The publication is a
regular milestone PR, with independent audit and landing decisions still open.
''')

(P / 'DELIVERY_CHECKS.md').write_text('''# Boost milestone delivery evidence

The complete conditional note contains the prepared current bracket, its
growing-time bound, the separate rotation bracket/domain argument and the
sharp norm time threshold. All source reviews and independence limits are
recorded in ROOT_COMPOSITION_REVIEW.md and the lossless evidence packet.

The self-contained canonical primary exited 0 in 18.975330114 seconds with
a declared 180-second timeout. The full 10,900-byte stdout was read; the
merged-error result is empty. Cache source and declared note input are fresh.
Runtime: Python 3.13.5, SymPy 1.14.0, NumPy 2.4.4, SciPy 1.17.1. Its final
five-module count is not a count of mathematical claims or independent proofs.

All twelve actual complete-primary semantic variants exited 1 at their
intended assertions, under the same timeout. Each differs by exactly one
declared replacement; complete source, stdout, stderr and execution metadata
are preserved. The variants test contact signs, the differential term,
second moments, rotation spin/contact/budget, current rank terms, forcing
sign, source-phase derivative, normalization and the folded-corner count.
They discriminate those finite calculations; they do not prove the analytic
theorem. No additional successful scientific execution was needed after the
primary source and note were frozen.

The citation build contains 6,871 nodes, 15,421 edges and 4,566 runners.
Its manifest adds one node and one edge; every old node is unchanged.
Focused changed-audit-evidence compatibility selected no applied audit rows
and reported no failures. The global combined audit pipeline and strict
audit lint were not run and remain independent landing gates.

Final note and primary reconstruction, syntax, ordinary local links, all
preserved evidence identities, vocabulary correction/report and cache input
freshness are checked mechanically. SOURCE_IDENTITIES.json binds every final
publication file except itself. Index/worktree byte identities and whitespace
are checked before commit. The parent is complete PR9479 at b9b032ae790c66e762a6296a1306bfb64ae7cd70.
The later memory PR is credited as prior work; its whole result is not a
logical dependency because the necessary kernel and integral bound are
proved here. No science merge, main push or audit application is performed.

Operational read commands that used a guessed filename or wrong external
working directory failed before scientific execution and were corrected.
One combined display was truncated; the missing argument was then read in
full separately. These are not scientific failures or completed verification.
The expectation worker's connection failure is separate ongoing research,
not an omitted result from this publication scope.
''')

replacements = {
 'STATE.yaml': [('pr_status: preparation', 'pr_status: ready_for_regular_PR'),
                ('next_action: complete_sharp_time_independent_review_and_delivery', 'next_action: open_regular_PR_after_explicit_staged_identity_checks')],
 'ROUTE_PORTFOLIO.md': [('T requires its own new\nreview: neither previous review certifies it.', 'T received its own complete analytic reconstruction before author-helper\ninspection; neither previous review was substituted for it.')],
 'REVIEW_HISTORY.md': [("match. T's separate source review is pending in this initial snapshot.\n\nFinal delivery records will bind its actual outcome and composition checks.",
                        'match. T received a complete separate analytic reconstruction and review,\nreport d3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796.\nRoot read both in full and verified the complete source-bound receipt and\nfreeze. No repair or unresolved scoped proof obligation was found.\nROOT_COMPOSITION_REVIEW.md and DELIVERY_CHECKS.md record final evidence.')],
 'PR_BACKLOG.md': [('Publication remains conditional on the separate sharp-time source review and\nthe source-bound delivery checks.', 'The separate sharp-time source review is complete without required repairs.\nSource-bound delivery checks are recorded in DELIVERY_CHECKS.md.')],
 'NO_GO_DISCIPLINE_CHECKLIST.md': [('T7–T24 address that obligation, with a separate source\nreview required.', 'T7–T24 address that obligation, and the separate complete source review is\nrecorded in REVIEW_HISTORY.md.')]
}
for name, edits in replacements.items():
    path = P / name
    data = path.read_text()
    for before, after in edits:
        assert data.count(before) == 1, (name, before)
        data = data.replace(before, after)
    path.write_text(data)

editable = sorted(P.glob('*.md')) + [note, primary]
for mode in ('fix', 'report-only'):
    target = S / ('boost_final_vocab_' + mode)
    result = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--' + mode,
                             '--report-path', str(target.with_suffix('.json'))] +
                            [str(p.relative_to(W)) for p in editable], cwd=W,
                            capture_output=True, text=True)
    target.with_suffix('.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr

result = subprocess.run([sys.executable, str(P / 'reconstruct.py')], cwd=W,
                        capture_output=True, text=True)
(S / 'boost_final_reconstruction.log').write_text(result.stdout + result.stderr)
assert result.returncode == 0, result.stdout + result.stderr
composition = json.loads((P / 'PRIMARY_COMPOSITION.json').read_text())
assembled = composition['prefix'] + ''.join(r['block'] for r in composition['sources']) + composition['suffix']
assert assembled == primary.read_text()
assert digest(assembled.encode()) == composition['publication_sha256']
tree = ast.parse(assembled)
literal_sources = {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
                   if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
                   and node.targets[0].id.startswith('_SOURCE_')}
for row in composition['sources']:
    raw = gzip.decompress((P / row['preserved_source']).read_bytes())
    assert digest(raw) == row['source_sha256']
    assert literal_sources['_SOURCE_' + row['label'].upper()] == raw.decode()
assert len(literal_sources) == 5
assert runner_cache.cache_status(str(primary.relative_to(W))) == 'fresh'
assert runner_cache.cache_identity_status(str(primary.relative_to(W))) == 'fresh'

links = []
for path in editable:
    if path.suffix != '.md':
        continue
    prose, fenced = [], False
    for line in path.read_text().splitlines():
        if line.lstrip().startswith('```'):
            fenced = not fenced
            continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for target in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        resolved = (path.parent / unquote(target.split('#', 1)[0])).resolve()
        assert resolved.exists(), (str(path), target)
        links.append({'source': str(path.relative_to(W)), 'target': target})

emap = json.loads((P / 'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}
def preserve(src):
    data = src.read_bytes()
    dst = P / 'evidence' / (str(src.relative_to(S)) + '.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    if dst.exists():
        assert dst.read_bytes() == packed, dst
    else:
        dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = {'original': str(src), 'preserved': rel, 'sha256': digest(data), 'bytes': len(data)}

for folder in ['boost_inverse_energy_review', 'boost_primary_mutations']:
    for path in sorted((S / folder).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            preserve(path)
for name in ['BOOST_CURRENT_INVERSE_ENERGY_REVIEW.md',
             'boost_inverse_energy_review_root_identity_check.json',
             'boost_inverse_energy_root_source_validation.json',
             'boost_canonical_execution.json', 'boost_citation_build.log',
             'boost_focused_audit_compat.json', 'run_boost_primary_mutants.py',
             'boost_primary_mutations_driver.log', 'compose_boost_milestone.py',
             'compose_boost_primary.py', 'prepare_boost_packet.py',
             'finish_boost_delivery.py', 'boost_final_reconstruction.log',
             'boost_final_vocab_fix.json', 'boost_final_vocab_fix.log',
             'boost_final_vocab_report-only.json', 'boost_final_vocab_report-only.log']:
    preserve(S / name)
for row in rows.values():
    data = gzip.decompress((P / row['preserved']).read_bytes())
    assert digest(data) == row['sha256'] and len(data) == row['bytes']

mechanical = {'review_bindings_matched': len(bindings), 'complete_primary_mutants': 12,
              'note_reconstructed': True, 'primary_modules_reconstructed': 5,
              'cache_and_declared_input_fresh': True, 'citation_delta': {'nodes': 1, 'edges': 1},
              'old_graph_nodes_unchanged': True, 'ordinary_links': links,
              'scope': 'Mechanical evidence identities; not an independent mathematical or audit verdict.'}
out = S / 'boost_delivery_mechanical.json'
out.write_text(json.dumps(mechanical, indent=2) + '\n')
preserve(out)
emap['files'] = [rows[k] for k in sorted(rows)]
(P / 'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2) + '\n')
files = [note, primary, graph, W / 'logs/runner-cache' / primary.with_suffix('.txt').name]
files += [p for p in P.rglob('*') if p.is_file() and p != P / 'SOURCE_IDENTITIES.json']
identities = []
for path in sorted(set(files)):
    row = {'path': str(path.relative_to(W)), 'sha256': sha(path)}
    if path.suffix == '.gz':
        row['decompressed_sha256'] = digest(gzip.decompress(path.read_bytes()))
    identities.append(row)
(P / 'SOURCE_IDENTITIES.json').write_text(json.dumps({
    'base_revision': BASE, 'scope': 'Every publication file except this manifest itself.',
    'files': identities
}, indent=2) + '\n')
print(json.dumps({'publication_files': len(identities) + 1, 'preserved_evidence_files': len(rows),
                  'review_bindings_matched': len(bindings), 'ordinary_links': len(links),
                  'complete_primary_mutants': 12, 'cache_and_inputs_fresh': True}))
