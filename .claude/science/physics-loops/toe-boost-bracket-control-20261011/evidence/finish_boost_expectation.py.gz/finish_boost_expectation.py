"""Bind the actual expectation extension's delivery evidence and stage exact owned files."""
from pathlib import Path
import ast, gzip, hashlib, json, re, subprocess, sys
from urllib.parse import unquote

S = Path(__file__).resolve().parent
W = S.parent / 'boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-bracket-control-20261011'
D = S / 'boost_expectation_publication'
OLD = '47cb1150396d0ed387f7ee6bd157dda156713f9e'
BASE = 'b9b032ae790c66e762a6296a1306bfb64ae7cd70'
sha = lambda b: hashlib.sha256(b).hexdigest()
rp = 'scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
primary = W / rp
note = W / 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
graph = W / 'docs/audit/data/citation_graph_manifest.json'
sys.path.insert(0, str(W / 'scripts'))
import runner_cache
assert sha(primary.read_bytes()) == 'ad158ab067673f7ace2737b96475a45ce91cb3fc1718cf709e5c445f58f2a550'
assert runner_cache.cache_status(rp) == runner_cache.cache_identity_status(rp) == 'fresh'
cache, _, _ = runner_cache.load_cache(rp)
header = dict(re.findall(r'^([a-z_0-9]+): (.+)$', cache.read_text().split('----- stdout -----')[0], re.M))
assert header['status'] == 'ok' and header['exit_code'] == '0'
execution = json.loads((D / 'canonical_execution.json').read_text())['result']
assert execution['stdout'] == json.loads((S / 'boost_canonical_execution.json').read_text())['stdout']
assert execution['stderr'] == ''
oldgraph = json.loads(subprocess.check_output(['git', 'show', OLD + ':docs/audit/data/citation_graph_manifest.json'], cwd=W))
newgraph = json.loads(graph.read_text())
assert (oldgraph['node_count'], oldgraph['edge_count']) == (newgraph['node_count'], newgraph['edge_count'])
assert oldgraph['nodes'] == newgraph['nodes']
compat = json.loads((D / 'focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []

p = P / 'DELIVERY_CHECKS.md'
p.write_text(p.read_text().rstrip() + f'''

The expectation-input cache refresh exited 0 in {header['elapsed_sec']} seconds
under the declared 180-second timeout. Full stdout is byte-identical to the
previously read 10,900-byte output, with empty stderr. Input fingerprint:
{header['input_fingerprint_sha256']}.
The primary remains unchanged; prior actual source mutants therefore remain
applicable to their finite algebra. The new theorem is checked by the complete
independent analytic reconstruction, including its alternate Volterra proof.

The refreshed citation graph keeps all 6,871 nodes and 15,421 edges unchanged;
no dependency changed. Focused compatibility again finds no affected applied
audit rows or failures. The global combined audit and strict lint remain
unrun landing gates. The full old 47cb115 publication note, cache, maps and
sidecars are preserved in the expectation-publication evidence; all new
author and reviewer bytes are also retained. Ordinary local links, exact
reconstruction, vocabulary correction/report, final cache/input freshness,
worktree/index identities and whitespace are checked before commit.
''')
p = P / 'STATE.yaml'
p.write_text(p.read_text().replace('pr_status: regular_PR_9484_open_expectation_extension_in_delivery',
                                 'pr_status: regular_PR_9484_open_reviewed_expectation_extension_ready'))
editable = sorted(P.glob('*.md')) + [P / 'STATE.yaml', note, primary]
for mode in ('fix', 'report-only'):
    out = D / ('final_vocab_' + mode)
    r = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--' + mode, '--report-path',
                        str(out.with_suffix('.json'))] + [str(p.relative_to(W)) for p in editable],
                       cwd=W, capture_output=True)
    out.with_suffix('.log').write_bytes(r.stdout + r.stderr)
    assert r.returncode == 0
r = subprocess.run([sys.executable, str(P / 'reconstruct.py')], cwd=W, capture_output=True)
(D / 'final_reconstruction.log').write_bytes(r.stdout + r.stderr)
assert r.returncode == 0
assert runner_cache.cache_status(rp) == runner_cache.cache_identity_status(rp) == 'fresh'
comp = json.loads((P / 'PRIMARY_COMPOSITION.json').read_text())
assembled = comp['prefix'] + ''.join(r['block'] for r in comp['sources']) + comp['suffix']
assert assembled == primary.read_text()
ast.parse(assembled)

links = []
for p in editable:
    if p.suffix != '.md': continue
    prose = []; fenced = False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'): fenced = not fenced; continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for link in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if link.startswith(('http:', 'https:', '#', 'mailto:')): continue
        target = (p.parent / unquote(link.split('#', 1)[0])).resolve()
        assert target.exists(), (p, link)
        links.append({'source': str(p.relative_to(W)), 'target': link})
mechanical = {'note_reconstructed': True, 'primary_unchanged': True,
 'all_five_arguments_preserved': True, 'cache_header': header,
 'stdout_matches_previous_complete_read': True, 'graph_unchanged': True,
 'focused_compatibility_failures': [], 'ordinary_links': links,
 'scope': 'Mechanical evidence bindings, not scientific or audit certification.'}
(D / 'delivery_mechanical.json').write_text(json.dumps(mechanical, indent=2) + '\n')

emap = json.loads((P / 'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}
for src in sorted(D.rglob('*')) + [Path(__file__).resolve()]:
    if not src.is_file(): continue
    b = src.read_bytes(); dst = P / 'evidence' / (str(src.relative_to(S)) + '.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(b, mtime=0)
    if dst.exists(): assert dst.read_bytes() == packed, dst
    else: dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = {'original': str(src), 'preserved': rel, 'sha256': sha(b), 'bytes': len(b)}
for row in rows.values():
    b = gzip.decompress((P / row['preserved']).read_bytes())
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
emap['files'] = [rows[k] for k in sorted(rows)]
(P / 'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2) + '\n')
files = [note, primary, graph, cache] + [p for p in P.rglob('*') if p.is_file() and p != P / 'SOURCE_IDENTITIES.json']
ident = []
for p in sorted(set(files)):
    row = {'path': str(p.relative_to(W)), 'sha256': sha(p.read_bytes())}
    if p.suffix == '.gz': row['decompressed_sha256'] = sha(gzip.decompress(p.read_bytes()))
    ident.append(row)
(P / 'SOURCE_IDENTITIES.json').write_text(json.dumps({'base_revision': BASE,
 'scope': 'Every publication file except this manifest itself.', 'files': ident}, indent=2) + '\n')
paths = [r['path'] for r in ident] + [str((P / 'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git', 'add', '--'] + paths, cwd=W, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=W, check=True)
for row in ident:
    assert sha(subprocess.check_output(['git', 'show', ':' + row['path']], cwd=W)) == row['sha256']
staged = set(filter(None, subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=W).decode().split('\0')))
assert staged <= set(paths)
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=W)
untracked = set(filter(None, subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=W).decode().split('\0')))
assert not untracked, untracked
report = {'changed_files_staged': len(staged), 'complete_publication_files_verified': len(paths),
          'preserved_evidence_files': len(rows), 'all_index_worktree_identities_match': True,
          'whitespace_clean': True, 'note_sha256': sha(note.read_bytes()), 'cache_header': header,
          'scope': 'Mechanical evidence; no independent scientific or audit verdict.'}
(S / 'boost_expectation_final_staged_verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
