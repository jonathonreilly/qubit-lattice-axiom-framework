"""Run actual whole-primary single-replacement variants; retain all outcomes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, time
S=Path(__file__).resolve().parent
W=S.parent/'boost_worktree'
primary=W/'scripts/excluded_walk_boost_bracket_control_2026_10_11.py'
data=primary.read_bytes();body=data.decode()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(data)=='ad158ab067673f7ace2737b96475a45ce91cb3fc1718cf709e5c445f58f2a550'
D=S/'boost_primary_mutations';D.mkdir(exist_ok=False)
cases=[
 ('canonical_contact_sign','return scale(add(outer(hb[b], h, v), outer(h, hb[b], v)), -ONE)',
  'return scale(add(outer(hb[b], h, v), outer(h, hb[b], v)), ONE)','canonical current b=0'),
 ('omit_current_differential','A(dk(psi, a), b), B(psi, a, b)',
  '{}, B(psi, a, b)','full bracket'),
 ('current_constant_contact_sign','return add(scale(outer(hb[a], r[b], v), -ONE),',
  'return add(scale(outer(hb[a], r[b], v), ONE),','full bracket'),
 ('axis_second_moment','avg(actual*actual)-12*S*S*C*C',
  'avg(actual*actual)-8*S*S*C*C','axis_witness_preserved_helper'),
 ('rotation_spin_weight','zero: -I*c[a]*c[b]*spin/2,',
  'zero: -I*c[a]*c[b]*spin/3,','Pauli_direct_dipole_commutator'),
 ('rotation_contact_sign','expected_contact = {e2[1]: qops[0], e2[0]: -qops[1]}',
  'expected_contact = {e2[1]: -qops[0], e2[0]: qops[1]}','abstract_exact_full_compression_defect'),
 ('rotation_constant_budget','"explicit_rotation_norm_budget", budget < 2**17',
  '"explicit_rotation_norm_budget", budget < 2**16','explicit_rotation_norm_budget'),
 ('inverse_current_rank','CURRENT_RANK_WEIGHT = sp.Rational(1)',
  'CURRENT_RANK_WEIGHT = sp.Rational(0)','canonical full-torus coupling polynomial'),
 ('inverse_duhamel_sign','DUHAMEL_SOURCE_SIGN = -1.0',
  'DUHAMEL_SOURCE_SIGN = 1.0','positive contact Duhamel sign: actual vectors'),
 ('inverse_phase_derivative','DIFFERENTIATE_SOURCE_CLOCK = True',
  'DIFFERENTIATE_SOURCE_CLOCK = False','all momentum derivative factors: actual vectors'),
 ('packet_jacobian','(2*pi)**6*Kscale**(-6)*Kscale**3*Qscale**3/',
  '(2*pi)**6*Kscale**(-6)*Kscale**2*Qscale**3/','six-dimensional packet normalization'),
 ('folded_corner_count','coefficient=s.simplify(8/(4*(2*s.pi)**3) * s.pi**2/4)',
  'coefficient=s.simplify(4/(4*(2*s.pi)**3) * s.pi**2/4)','kernel_bound_preserved_helper'),
]
rows=[]
for name,old,new,expected in cases:
 assert body.count(old)==1,(name,body.count(old))
 source=D/(name+'.py');changed=body.replace(old,new)
 source.write_text(changed)
 cmd=[sys.executable,str(source)]
 started=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 try:
  r=subprocess.run(cmd,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
  code,out,err,timeout=r.returncode,r.stdout,r.stderr,False
 except subprocess.TimeoutExpired as e:
  code,out,err,timeout=124,e.stdout or b'',e.stderr or b'',True
 (D/(name+'.stdout.log')).write_bytes(out)
 (D/(name+'.stderr.log')).write_bytes(err)
 intended=code==1 and not timeout and b'AssertionError' in err and expected.encode() in err
 row={'name':name,'before':old,'after':new,'expected_failure_marker':expected,
      'primary_sha256':sha(data),'mutant_sha256':sha(source.read_bytes()),
      'command':cmd,'cwd':str(W),'started_utc':started,'timeout_seconds':180,
      'elapsed_seconds':time.monotonic()-t,'exit_code':code,'timed_out':timeout,
      'stdout_sha256':sha(out),'stderr_sha256':sha(err),'intended_failure':intended}
 rows.append(row)
 (D/'manifest.json').write_text(json.dumps({'source':str(primary),'primary_sha256':sha(data),
    'scope':'Actual complete primary variants. These discriminate selected finite claims, not continuum theorem validity.',
    'runs':rows},indent=2)+'\n')
 print(json.dumps({'name':name,'exit_code':code,'intended_failure':intended,'seconds':row['elapsed_seconds']}),flush=True)
 assert intended,(name,code,err.decode(errors='replace'))
assert primary.read_bytes()==data
print('COMPLETE: twelve actual whole-primary semantic mutants rejected at intended assertions')
