# Independent review of gapped current and first-moment state invariance

**PASS for the exact conditional theorem G1–G6 ⇒ G7 at the frozen source.**
I found no material mathematical or evidence defect and require no author
source correction. The source-readiness recommendation is **PASS WITH BOUNDED
CLAIMS**. This review supplies no applied audit or retained status and does not
establish that an intended physical model satisfies the hypotheses.

The complete 774-line candidate is `GAPPED_BOOST_INVARIANCE_PROBE.md`, SHA-256
`94d1f879927135d378dcafb6e9b603465155906a71fed5ca301b4354566cea14`.
Its author receipt is
`6a384d384501cb5dfc7ef6ed4ae9b78628ea7710b525050efec4e7227b06596e`.
Root proposed the filtering mechanism and is a coauthor. This is a separate
reviewer context with the selected model and reasoning effort inherited;
no different-model-family or blinded verification is claimed.

The checked conclusion is
`omega(delta_p A)=omega(delta_b A)=0` for every local and rapid almost-local A,
where the actual current is `[delta_h,delta_b]`. Its leaves are the stated
finite-range density, the actual canonical energy dynamics and invariant
state, a positive canonical GNS Hamiltonian with a one-dimensional zero
space and positive gap, and exact operator conservation
`[delta_h,delta_p]A=0` on every local A. No self-adjoint P/B, global uniqueness
of algebraic ground states, current-state invariance or boost-state invariance
is imported.

| Complete candidate argument checked | Review conclusion |
|---|---|
| Finite current algebra and premises, lines 75–156 | The 3R center padding makes pair symmetrization finite. The sign, factor 1/2, radius 3R, density bound and R=0 case are correct. Exact conservation is a separate operator premise. |
| Rapid topology and weighted graphs, lines 158–275 | Nested expectations give the local approximation rates. The dyadic sum converges for q>n+d+kappa, yielding loss d+kappa+1 per derivation. Both the density series and the graph extension agree. The h-b words lose 2d+3, h-p words 2d+2; input n+2d+4 suffices for their common approximation. No norm-only domain shortcut occurs. |
| Finite ODE and light cone, lines 277–352 | Jacobi and the time-dependent unitary propagator give G20. The first support-chain step costs at most card(X) J, later steps sJ, and m links travel at most m ell. The factorial remainder tends to zero. G23 has no outside-support cardinality factor, so Haar averaging over the entire outside factor is valid. J=0, R=0 and both signs of time are handled. |
| Polynomial time control and differentiation, lines 354–425 | Splitting at 2(L+v abs(t)+1) converts the exponential spatial bound to a polynomial time bound. The dyadic sum gives G26 for q>n+d, and every word satisfies G30 with input loss L_D+d+1 and time degree n+L_D. Closedness of the actual generator and interpolation give rapid-topology differentiation before applying any unbounded functional. |
| Current-functional stationarity, lines 427–451 | Differentiation in the stronger topology and the extended exact conservation identity give d_t omega(delta_p alpha_t A)=0. Energy stationarity is applied to the rapid element delta_p alpha_t A. No current implementation is assumed. |
| Filtering and both vacuum columns, lines 453–526 | The real even Schwartz filter has Fourier support strictly inside the gap. GNS implementation gives g(H)=P_Omega on both A and A*. The adjoint column supplies omega(A_0 Q), and the ordinary column supplies omega(Q A_0). No separating vacuum or globally scalar A_0 is inferred. |
| Weighted integral exchange, lines 467–484 and 504–524 | Every derivation word is continuous with explicit seminorm loss, and its orbit grows only polynomially. These bounds dominate the Schwartz integral in every graph seminorm. Absolute norm convergence of the density sums then permits termwise expectation despite the unbounded coefficient x_b. |
| Boost-functional stationarity, lines 528–549 | After current invariance is proved, `[delta_h,delta_b]=delta_p` gives zero derivative for the first-moment functional. The same justified filter exchange then proves its vanishing. The order is acyclic. |
| Boundaries and scope, lines 551–774 | The density coboundary, degenerate kernel, two-column distinction, nonscalar filter and graph-approximation controls have their claimed precise scopes. Author evidence claims match the inspected execution artifacts. |

A distinct reconstruction was frozen before opening author helper/result
files. It uses unit shells rather than dyadic shells, with the deliberately
larger sufficient loss `d+kappa+2` per derivation. Its independent light-cone
argument uses a positive-kernel supersolution: for fixed arbitrary Y, set
`F_Y(X)=|X| exp(-dist(X,Y))`. The Volterra kernel satisfies
`K F_Y <= 2sJ exp(ell) F_Y`; finite positive-matrix comparison gives G23
without enumerating the author's chain fixtures. Combining this with the
cone split provides polynomial bounds for all graph words and directly
justifies the Schwartz exchange. The author's sharper dyadic exponents were
also checked, rather than replaced by these larger losses in the review.

The reconstruction and control plan were frozen at 05:31:51 UTC in
`gapped_boost_invariance_review/INDEPENDENT_RECONSTRUCTION_PRECHECK.md`, SHA-256
`060ffbac404c7f719ec4e65fe261d815d97ff12fe3ed74284b253466af407957`.
The complete candidate, including its reported results, had already been
read. That unavoidable source exposure is recorded. The independent control
source was frozen before execution and imports no author helper or output.

The fresh exact controls use sparse tensor matrix units and Gaussian-rational
Fraction pairs. For `q=3X-2Y+5Z`, the coboundary density has the same energy
action, current `3Y+2X`, conservation defect `-3X+2Y`, and first-moment
expectations -6 on Y and -4 on X. Thus the gap-preserving density change
fails the exact conservation hypothesis, as required. A qutrit control with
`Q=2(E01+E10)` has zero current and conservation but first-moment expectation
-4 and an additional zero-energy vector; it independently checks the simple
kernel boundary. The infinite-volume spectral statements were checked from
the explicit finite-modification product-GNS bases.

The fresh filter spectrum `(0,3,3,8)` retains a nontrivial excited 2x2 block,
including the entries `9-i` and `11+i`, while both vacuum columns are scalar
and every matrix-unit vacuum commutator vanishes. A one-sided column
example independently has commutator expectation -1. The Ising
example separately verifies that a simple gapped kernel in this GNS
representation coexists with more than one algebraic ground state.

The independent baseline completed 134 finite predicates without failure in
0.207204 seconds under a 60-second timeout. Five actual source mutations
reversed the current, removed its half-factor, replaced the computed filter
by a scalar, forced a rank-one zero projection, or ignored the adjoint column.
They exited 1 with respectively 24,24,4,2,1 failures under 30-second timeouts.
These are finite sensitivity checks, not a proof grade. Nondiscriminating
rows are retained: zero current does not detect its sign/scale, and scalar
vacuum columns do not detect a wrongly scalar full operator.

I read the complete 185-line final author helper, its 53-line logging helper,
all 105 final output rows and the complete correction diff. A byte-identical
copy reproduced the baseline and all five variants: each result JSON and
stdout stream matched its original exactly. The baseline exited 0 in
0.363151 seconds; the variants exited 1 with 5,5,1,1,1 failures and each
finished within 0.318 seconds. Every replay used a 60-second timeout with
empty stderr. Full commands, outputs, source hashes, timings and all failure
rows remain in the review evidence. No timeout or unintended execution
failure occurred. The author's earlier tautological filter comparison was
indeed repaired; its original source/results remain preserved. Some author
variants alter comparison claims rather than the computed routine, a limit
made explicit in `CONTROL_ANALYSIS.md` and addressed by the reviewer mutations.

The entire current source and prior review were read at
`bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a` and
`305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17`.
Only finite current algebra I6–I10 and finite-range construction I14–I22
are needed here; their supplied self-adjoint B/P theorem is not imported.
The entire joint-flow source and review were read at
`35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd` and
`9699043c35343901ef75ab6a29dd560ba4aa30f8a3b908643e959958e86447c9`.
Its complete one-site operator criterion is valid for checking G5, but does
not establish G5 for any intended model.

The weighted-flow source
`7ec1d7eecb4eba020548eba8b56dff66712f52b4eba634ba276dd67440d28de7`
was inspected only at lines 65–170 for its stated B1–B4 input boundary.
It is not a premise of this proof. G7 supplies B3 and energy invariance supplies
B4 for the same density/state if that separately reviewed theorem is later
composed. This review does not certify that weighted-flow theorem or its
literature input. No downstream Lorentz, cross-current, centre, scattering,
Fock or physical-realization conclusion is established.

There was one review iteration, zero material findings, zero fixes and zero
skipped material findings. The complete author receipt inventory has 95
entries; all bytes, sizes and line counts matched, with no unrecorded
non-generated file. Source/instruction identities and coverage are in
`SOURCE_COVERAGE.json`, `bootstrap.json` and the final receipt. The current
repository reporting reference, hash
`8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e`,
was used. The relevant instruction bytes match selected main
`a13caa4885f547c8d206265b031ba7649e539fd9`; planning authority remains
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. Read-only Git identity/source
queries were used; no ref, index or checkout mutation occurred.

Formal audit, Lean formalization and the broad repository integration pipeline
were not run. There is no assigned canonical claim ID in this external
research packet, no commit, PR, landing SHA, combined integration gate,
retry or fallback unit to report. Conditional source readiness is checked;
the repository's formal retained status remains ungranted. Intended-model
premises and separately reviewed downstream composition are the remaining
application obligations, not hidden gaps in G1–G6 ⇒ G7.

Only this review and `gapped_boost_invariance_review/` were written.
Frozen author and prior sources were unchanged. **Editable prompt files
changed: none.** No repository source, axiom, audit result or other chat was
modified, and no model/effort override or subdelegation occurred. The full
recovery checkpoint and final source-bound receipt are under the review
evidence directory. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.
