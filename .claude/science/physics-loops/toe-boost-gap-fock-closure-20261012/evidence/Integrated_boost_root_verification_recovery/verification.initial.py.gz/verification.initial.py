"""Verify the frozen fresh review without rerunning science."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
S=Path(__file__).resolve().parent;R=S/'integrated_boost_covariance_review';A=S/'integrated_boost_covariance'
js=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
bindings={}
def bind(p,h,size=None):
    p=Path(p).resolve();b=p.read_bytes();assert sha(b)==h,str(p)
    if size is not None:assert len(b)==size
    bindings[str(p)]=h
bind(R/'receipt.json','8a0988c3db50a91d937b8af78e3792df951392fd50866d65664f4889a7ab0ca6')
rec=js(R/'receipt.json')
for k in ['review','reconstruction','control_freeze','evidence_manifest','author_receipt','source_manifest']:
    r=rec[k];bind(r['path'],r['sha256'],r.get('bytes'))
for r in js(R/'evidence_manifest.json')['files']:bind(R/r['path'],r['sha256'],r['bytes'])
for r in js(R/'source_manifest.final.json')['sources']:
    bind(r['source'],r['sha256'],r['bytes']);bind(r['snapshot'],r['sha256'],r['bytes'])
freeze=js(R/'CONTROL_FREEZE.json')
for r in freeze['files']:bind(r['path'],r['sha256'],r['bytes'])
runs=[]
for r in rec['runs']:
    p=R/r['receipt'];bind(p,r['sha256']);x=js(p)
    assert x['exit_code']==r['exit_code'] and not x['timed_out'] and 0<x['elapsed_seconds']<x['timeout_seconds']
    assert x['elapsed_seconds']==r['elapsed_seconds']
    for f in x['sources']:bind(f['path'],f['sha256'],f['bytes'])
    for name,f in x['streams'].items():bind(p.parent/name,f['sha256'],f['bytes'])
    runs.append({'receipt':r['receipt'],'command':x['command'],'timeout':x['timeout_seconds'],'exit':x['exit_code'],'seconds':x['elapsed_seconds']})
source=(R/'independent_controls.py').read_text();baseline=js(R/'canonical.json')
assert baseline['pass']==38 and baseline['fail']==0 and len(baseline['rows'])==38
records=[]
for name in ['canonical']+list(freeze['mutations']):
    if name!='canonical':
        before,after=freeze['mutations'][name];assert source.count(before)==1
        assert (R/'mutants'/(name+'.py')).read_text()==source.replace(before,after,1)
    out=js(R/(name+'.json'));rows=out['rows']
    assert len(rows)==38 and sum(r['pass'] for r in rows)==out['pass'] and sum(not r['pass'] for r in rows)==out['fail']
    d=R/'logs'/('independent_'+name);e=js(d/'receipt.json')
    assert e['exit_code']==(0 if name=='canonical' else 1) and e['timeout_seconds']==60
    expected=''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows)+f"TOTAL: PASS={out['pass']} FAIL={out['fail']}\n"
    assert expected==(d/'stdout.txt').read_text() and not (d/'stderr.txt').read_bytes()
    if name=='canonical':records.append({'name':name,'rows':rows})
    else:
        changes=[];same=[]
        for a,b in zip(baseline['rows'],rows):
            assert a['name']==b['name']
            if a==b:same.append(b['name'])
            else:changes.append({'baseline':a,'mutant':b})
        records.append({'name':name,'changes':changes,'unchanged':same})
original=(A/'controls.py').read_text()
nodes=[]
for node in ast.walk(ast.parse(original)):
    if isinstance(node,ast.IfExp) and isinstance(node.test,ast.Compare):
        segment=ast.get_source_segment(original,node.test)
        if segment.startswith('args.mutation == '):nodes.append(node)
assert len(nodes)==6
for item in js(R/'author_replays/source_materialization.json'):
    name=item['name'];p=Path(item['source']);bind(p,item['sha256']);expect=original
    if name!='baseline':
        for node in nodes:
            test=ast.literal_eval(node.test.comparators[0])
            old=ast.get_source_segment(original,node)
            new=ast.get_source_segment(original,node.body if name==test else node.orelse)
            assert expect.count(old)==1;expect=expect.replace(old,new,1)
    assert p.read_text()==expect,(name,'materialization mismatch')
    assert (R/'author_replays'/(name+'.json')).read_bytes()==(A/('final_'+name+'.json')).read_bytes()
    for stream in ['stdout.txt','stderr.txt']:
        assert (R/'author_replays/logs'/name/stream).read_bytes()==(A/'logs'/('final_'+name)/stream).read_bytes()
with (S/'Integrated_boost_root_review_rows.compact.txt').open('w') as f:
    for r in records:
        f.write('RUN '+r['name']+'\n')
        for row in r.get('rows',r.get('changes',[])):f.write(json.dumps(row,separators=(',',':'))+'\n')
        if 'unchanged' in r:f.write('UNCHANGED '+json.dumps(r['unchanged'],separators=(',',':'))+'\n')
summary={'utc':datetime.now(timezone.utc).isoformat(),'bindings':bindings,'distinct_paths':len(bindings),'executions':runs,
 'independent_baseline_rows':38,'independent_whole_source_mutants':5,'byte_exact_author_materializations':6,'fresh_root_science_execution':False,
 'scope':'Provenance/full-output validation; complete proof and control source reads are recorded separately.'}
(S/'Integrated_boost_root_review_evidence_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['bindings','executions']}))

