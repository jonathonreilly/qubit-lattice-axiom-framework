# Independent review: nonisolated regular-packet Fock isometry

**Recommendation: PASS WITH BOUNDED CLAIMS.** The exact candidate supports its
conditional permanent Gram formula and Fock isometries over the defined closed
regular one-particle span. No required mathematical source correction was found.
This review neither grants retained status nor verifies a physical realization.

## Source and review boundary

| Source | SHA-256 |
|---|---|
| `NONISOLATED_FOCK_PROBE.md` — all 400 lines | `90471bd9b63f6a39356152a725e633a1d465272188ff1574bd198f71e97b85f5` |
| `nonisolated_fock/receipt.json` | `579ba4570a5459f6775811b5c6f236c2457a5427b576b4699547556b5b4d13ec` |
| `NONISOLATED_MASS_SCATTERING_PROBE.md` | `afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d` |
| Matching mass review | `09da880b4ebdf629cffcc72c490176e6706b0ae4b01790eb3a267b6d8b284143` |
| Exact N36 publication repair | `22d272711226acccb48f0c2e167bd47bc5296d4142c7e60ac537c0ae6f74a453` |

The complete mass, original SC/Fock notes and matching reviews, complete
publication mappings, Dybalski v4 TeX, and necessary BDN/NS passages were read.
Exact coverage and all additional identities are in
`nonisolated_fock_review/READING_COVERAGE.json` and
`source_evidence_verification.json`. The final refresh found all 110 distinct
bound source/evidence paths unchanged, including the target and its receipt.
Source identity establishes the scope of this review, not truth by provenance.

The distinct decisive route and algebraic tests were frozen at
2026-10-12T04:57:59.402028 UTC before inspecting the new author helper or raw
results. The full candidate, including its control descriptions and numbers,
was already visible. The reviewer used two Parseval norms in the contraction
estimate and independent exact matrices/clock weights. This is not a claim of
blind route discovery or different-model independence. The root lead was not
read as proof input; root is a coauthor, not an independent reviewer. The full
later reconstruction is not claimed to have been frozen before helper exposure.

## Mathematical disposition

The full derivation is saved in
`nonisolated_fock_review/INDEPENDENT_RECONSTRUCTION.md`.

| Obligation and candidate location | Checked result |
|---|---|
| NF9–NF14, lines 91–153: mixed energy bounds, massive packet decay and localization | Lowering-word induction supplies the uniform energy-window bounds; creator duality uses the output ceiling `R+L`. Only the common `alpha_(sigma T)` is removed. Each of four independent relative times remains. The LR localization error includes the input volume `O(U^d)` before exponential absorption. |
| NF15–NF25, lines 155–245: contraction and every tail | The two confined relative coordinates each cost `O(R^d)`. The middle near region and complete exponential far tail together cost `O(R^d)`, including the clustering support prefactor. Two Parseval norms and two stationary-phase sup bounds give `O(T^-d)`, hence `T^(-d+3d*kappa)`. Four localization errors cost `T^(2d-kappa*N)`; the union of all four independent time tails costs `T^(2d-delta*N)`, `delta=min(kappa-nu_j)>0`. No exponential kernel moment or hidden averaging-volume factor is used. |
| NF24–NF26, lines 231–250: mixed contraction | The connected four-point norm identity has the correct four independent clocks, projection and complex conjugations. The scalar vacuum overlap belongs initially to the actual averages; NF9 supplies its limiting target overlap. Small fixed widths with `max(nu_j)<kappa<1/3` suffice. |
| NF27–NF30, lines 252–277: double commutators | The third amplitude is partitioned by its own velocity map. The separated pair retains two clocks, LR controls the central sublinear time window, and Schwartz/spatial tails absorb every polynomial spectator norm. The Jacobi minus sign is correct. This estimate works for every fixed width below one. |
| NF31–NF33, lines 279–317: Gram recursion and width comparison | Every ordered double bracket and all `n-2` right plus `m-1` left spectators are accounted for. The slow contraction error is tested against a uniformly bounded finite-energy row containing all `m+n-2` remaining factors. Unequal-number base cases vanish exactly, giving cross-number orthogonality. The permanent has the stated creation-operator normalization. The previously checked creator comparison restores arbitrary fixed widths on each original chart; cross-chart well-definedness is not assumed circularly. |
| NF34–NF37, lines 319–358: regular closure and overlap | Smooth cutoffs preserve the actual regular seed and residual bound. Almost-local commutators yield an absolutely continuous geometric spectral measure for `B Omega`; domination and closure give absolute continuity on the defined regular subspace. This does not assert smooth density after projection. On a common lift, the difference of squared graph energies is affine; incompatible overlaps are null, while compatible graph velocities agree. Countable charts therefore do not duplicate states. |
| NF38 and lines 360–382: separated tensor density and isometry | Massive velocity maps are injective. Fubini eliminates equal-velocity diagonals, including across different species, in the actual product spectral spaces. Compact chart cutoffs and a finite partition of each compact overlap support produce genuinely separated packet supports. Symmetrization gives density in Fock space over the regular closure. The full Gram formula makes all finite linear combinations and chart/seed presentations well-defined; completion gives a closed-range isometry. |

## Controls and their limits

The original author runner was reproduced once with its recorded interpreter
and working directory: exit 0 in 0.25412 seconds under a 60-second limit,
byte-identical seven-record stdout and empty stderr.

The independent exact matrix calculation first timed out at its 60-second
limit after two complete partial records. Its original source and streams are
preserved. A frozen replacement of symbolic complex arithmetic by pairs of
rational matrices retained every matrix, dimension, case and gate. It exited
0 in 0.97748 seconds under the same limit. It checks the four-clock tensor and
256 clock orientations, complete ordered recursions through six creators,
nonzero omitted double brackets, creator padding and 40 mixed-row cases.
These are finite algebraic discriminators, not a lattice model or a proof of
asymptotic estimates.

Thirteen actual-source-copy mutations were executed with complete streams.
Nine rejected at the intended assertions: commutator sign, omitted double
brackets, omitted spectator, support distance, connected projection, complex
conjugation, a tied clock, Jacobi sign and unpadded creator bound. Four survived:

1. Replacing support-volume growth by a constant in both majorants.
2. Removing one confined relative-coordinate count.
3. Replacing the contraction decay exponent `d(1-3*kappa)` by `d(1-2*kappa)`.
4. Replacing the tail margin `kappa-small` by `kappa+small`.

These four control-coverage limits are preserved, not classified as successful
mutation detection. The finite tables share the supplied bookkeeping inputs
and do not independently derive these powers. The actual formulas are correct
under the analytic reconstruction above. The candidate already distinguishes
analytic proof from finite controls, so no source repair is required; stronger
future runner claims would require stronger gates. See
`nonisolated_fock_review/CONTROL_ASSESSMENT.md` and `author_mutations.json`.

## Imports, exclusions and reporting

The theorem imports a supplied finite-range lattice dynamics, unique gapped
vacuum, reducing massive graph sectors, almost-local creators and actual
geometric regularity with positive exponents. These are conditional inputs,
not consequences of the framework's registered primitives. N1–N31 supply the
already checked existence/comparison path. The old general-beta N36 expression
needs the documented `C_beta=H^2-beta*|K|^2` repair; this candidate bypasses it
by assuming geometric detuning regularity directly. Its beta=1 spectral
nonimplication remains intact. No relativistic or massless conclusion is
imported from Dybalski, and BDN's shell isolation and whole-shell density are
not silently transferred to this lattice argument.

The regular space may be zero. The proof does not supply regular-seed
existence, density in a whole physical sector, raw nonseparated packet
convergence, onto, detector, ND, EX, boost, equality of incoming/outgoing
ranges, an isometric S-matrix, a massless-vacuum theorem or a microscopic model.

One bounded review iteration was completed. Required mathematical findings:
0; source fixes: 0; skipped required fixes: 0. Four finite-control limitations
are reported above, with optional future hardening distinct from theorem
correction. No author source or editable prompt file changed. There were no
commits, integration retries, pipeline runs, landing units or fallback units.
This external probe is the sole reviewed unit; no train departure, combined
gate, landed main SHA or audit claim ID was created. Audit compatibility at a
future publication path was not tested. Any future retained claim for this
conditional Gram/isometry theorem requires the repository's independent audit
path and its then-current publication mapping. This review alone does not meet
or confer the repository's Nature-grade retention status.

Current worktree instructions and the current repository
`FIXES_AND_REPORTING.md` (`8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e`)
were applied; its differing installed copy was not assumed equivalent.
Parent-supplied main `a13caa4885f547c8d206265b031ba7649e539fd9`, planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`, and worktree HEAD
`dc7f415f73df3754653f4985382ca0fb96f07cda` are context labels, not Git states
independently refreshed by this reviewer. No Git, PR, audit, axiom, primitive,
other-chat or delegated action was performed. Model and reasoning settings
were unchanged.

Full source identities, read coverage, execution commands, limits, failures,
streams and recovery steps are retained in `nonisolated_fock_review/`.
The final receipt records review time and hashes. Formal audit, Lean and full
repository pipeline were not run because they are outside this bounded
source-only assignment. The fixed deadline was 2026-10-12 16:00:52 UTC.
