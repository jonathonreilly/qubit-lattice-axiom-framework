# Independent review of weighted current–boost closure

**PASS for the stated conditional mathematics at the frozen source.** I found
no material mathematical or evidence defect in W1–W22 or the fixed examples
W23–W28. No author correction is required. The source-readiness recommendation
is **PASS WITH BOUNDED CLAIMS**: this review neither supplies the physical model
hypotheses nor confers audit or retained status.

The complete 615-line source is
[WEIGHTED_CURRENT_CLOSURE_PROBE.md](WEIGHTED_CURRENT_CLOSURE_PROBE.md), SHA-256
`561cc0109580b74c42b19af27ab35801deea61a9c304dc2f43da772e042448f7`.
Its frozen author receipt is SHA-256
`a2640a66cf1e4d3d8a1f2f7d4957c9648a6c888f2f4f9da6a9ab48aea753c92e`.
Root contributed the proposed mechanism and is a coauthor; this reviewer
received a fresh, bounded review assignment.

The exact implication checked is: on the finite local tensor algebra of full
matrix sites over Z^d, for a specified finite-range Hermitian energy density,
exact conservation of its canonical energy-current derivation removes the
position weight from the ordered current/boost commutator. The unweighted
density has negative first translation moments as coefficients. Equality to
beta times the energy derivation is then equivalent to complete one-site
operator tests in a finite algebra. Under the additional actual-operator
actions W20, those tests are equivalent to W22 on the common local cyclic
domain.

| Complete argument reviewed | Result |
|---|---|
| W1–W8, lines 60–163 | Pair symmetrization supplies the current's factor 1/2 once. Ordered Jacobi gives `r=delta_p(h)`, `delta_r=[delta_p,delta_h]`, and `[delta_p,delta_b]=W_b(r)`. All contributing pairs lie in the finite 8R padding; no uncontrolled infinite sum or finite-boundary equality is used. |
| W9–W13, lines 165–243 | Nonidentity words have trivial translation stabilizers. The finite site commutant and zero partial trace force every orbit sum to vanish. A separate Laurent-module derivation yields the negative moment, with the weighted orbit-sum residue retained when conservation fails. |
| W14–W17, lines 245–311 | Coordinate-path telescoping constructs finite Hermitian primitives. Summation by parts gives the bth primitive with positive sign. Representative changes, scalar additions and primitive curls preserve the relevant derivation, while literal densities need not agree. The translation-defect sign is correct. |
| Support and norm bounds, W6/W16/W19 | r and the chosen moment density have radius at most 7R; the displayed coefficient norm bound follows from translation displacement at most 14R. The general primitive has radius at most 21R. The complete site test uses operators in B_(14R). These are sufficient bounds, not sharpness claims. |
| W18–W19, lines 313–369 | Complete site-basis tests imply all local identities by translation and Leibniz. Fixed representatives give a finite polynomial criterion. Beta uniqueness/scaling, scalar energy shifts, zero energy action, and R=0 are treated correctly. An energy-density divergence improvement is explicitly outside the claimed invariance. |
| W20–W22, lines 371–416 | Local-vector actions derive invariance and product domains before applying the commutator. The sign is `[P_j,B_b]=-i beta delta_jb H`. For the converse, applying the vector identity to AB, then cyclicity and local faithfulness, gives the algebra identity without a separating vacuum. The current clock divides by beta once. |
| W23–W28, lines 418–536 | The nonzero divergence and the nonconserving witness have the stated signs. The conserving XX density gives `t'=-8(f_0+ell_0)` and fails scalar-beta closure for every real beta at that fixed density. Its distinct four-site orbit cannot be cancelled by the nearest-neighbor energy orbit. |
| Evidence and scope, lines 538–615 | The original expected-sign failure is preserved and correctly explained. Source mutations reproduce with their stated limits. The finite matrix sign fixture is explicitly not a conserving physical lattice model. |

Both whole predecessor notes were read at the following identities; the
needed I1–I13 and J15–J20 algebra was independently reconstructed rather than
accepted because of the prior reviews.

| Frozen dependency | SHA-256 |
|---|---|
| `MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md` | `bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a` |
| `MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md` | `305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17` |
| `MICROSCOPIC_JOINT_FLOW_PROBE.md` | `35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd` |
| `MICROSCOPIC_JOINT_FLOW_REVIEW.md` | `9699043c35343901ef75ab6a29dd560ba4aa30f8a3b908643e959958e86447c9` |
| Joint-flow review receipt | `a31a20468660e38ff42bf215dd84832a1f722551c29ea770156dfc71781d4b06` |

The independent plan was frozen at 06:26:45 UTC and the reconstruction/control
source at 06:34:08 UTC, before either author helper or result was opened.
Prior knowledge is disclosed in
[PRECHECK_PLAN.md](weighted_current_closure_review/PRECHECK_PLAN.md): the full
candidate already exposed its equations, predicted coefficients and described
control outcomes. This was not blinded checking. The separate proof uses
Laurent augmentation/derivatives, the finite tensor commutant, and direct
domain algebra. Its frozen text is
[RECONSTRUCTION.before_author_helpers.md](weighted_current_closure_review/RECONSTRUCTION.before_author_helpers.md).

The new exact controls use CAR one-particle hopping kernels on an eleven-site
open interval, verified finite Jordan-Wigner maps, and direct qutrit matrix-unit
embeddings. They import no author helper. In the XX centre-number action,
one-particle coordinate entry (3,0) is -16i while the energy entry is zero;
entry (1,0) has weighted action -16i and energy action 2i. Thus beta=-8 is
forced by the second entry while the first rules out every beta. This is a
different witness from the author's centre-X entry. The qutrit controls test
two coordinate moments, altered representatives, origin shifts, scalars,
primitive curls, the nonconserved residue, and incomplete site tests. The
independent run completed 205 finite predicates with zero failures in
4.999261 seconds, exit 0, under a 60-second timeout. The count includes related
checks of the same identities and is not a proof grade.

I inspected all three author helpers and the complete final rows. An unchanged
copy of the original failed source reproduces 72 successful/1 failed
predicate: only the hand-written expected XX current was reversed. The
corrected source changes that expectation and its explanatory comment;
the current computation and r/t calculation are unchanged. Both final
baselines reproduce all 73 sparse and 33 matrix predicates. Their entire
stdout/stderr and every JSON field except the new timestamp match the
saved originals.

All five actual author source mutations were replayed from byte-identical
copies. Moment-sign reversal fails 26 predicates, deleting the current half
fails 2, insufficient padding fails 1, a Z-only basis fails 1, and disabling
the conservation guard fails 1. Their other predicates remain in the evidence.
In particular, current rescaling preserves XX conservation and shared
identities; representative comparisons can share the same wrong moment sign;
zero actions cannot detect that sign; and the guard mutation affects an API
rejection test, not the direct residue calculation. These limits are recorded
per mutation in
[CONTROL_ANALYSIS.md](weighted_current_closure_review/CONTROL_ANALYSIS.md)
and the full `author_mutation_analysis.json`.

The eight author replays—original failure, two final baselines, five
mutants—each used a 60-second timeout. Actual walls ranged from 0.087372 to
0.531921 seconds, with no timeout or unintended exception and empty stderr.
All output streams reproduced exactly. The original historical `started_utc`
field is mislabeled: it was recorded after execution. Its original receipt
and disclosed limitation are preserved; no missing start time was invented.
Full commands, hashes, timings, streams and exact residuals are under
`weighted_current_closure_review/`.

The mathematical conditional implication has no unresolved proof step
identified in this review. Its application still requires a specified energy
density satisfying conservation and every required closure identity with one
appropriate beta. W20 separately requires the actual self-adjoint operators
and their stated local-vector actions. Positivity, a gap, other momentum/boost
commutators, integrated Lorentz symmetry, particles and physical identification
are not supplied. The finite criterion is a genuine finite reduction; it is
not evidence that an intended physical density passes it.

The XX conclusion is the exact evaluation of one fixed density, with beta the
only quantified free scalar. Density improvements, other interactions and
continuum limits were not exhausted and are not ruled out. No broad no-go,
independent wall count, or N1–N8 packet PASS is assigned. The nonconserving
example attacks conservation, while the conserved XX example attacks the
different weighted closure identity; those residuals are not conflated.

There was one review iteration, zero material findings, zero source fixes,
and zero unresolved suspected findings. Supplied inputs are disclosed: the
full-matrix finite-range setting, specified density and normalization,
conservation, beta choice where prescribed, and optional W20 operator data.
There are no fitted or observational inputs and no primitive supplies the
model conditions. The current axiom memo/registry were checked without
classifying approved primitives as missing assumptions. No unrelated
predecessor analytic-flow, index or scattering theorem is certified here.

Instruction authority is the parent-specified main
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. Current repository workflow and
reviewer/review-loop/workhorse guidance were read, including reporting reference
SHA-256 `8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e`.
Local source-byte verification covers all 90 author receipt entries and all
reviewed instruction/dependency snapshots; all 110 distinct source paths
remain unchanged. The exact manifests and final verification are preserved.

Formal audit, Lean, full repository integration gates, publication, commits,
and Git operations were outside this dispatch and were not performed. No
retained/Nature-grade certification or new claim ID is assigned. Only this
review and `weighted_current_closure_review/` were written. No author source,
repository source, physical axiom, other chat, model setting or reasoning
effort was changed; no subdelegation occurred. **Editable prompt files changed:
none.** The campaign deadline remains 2026-10-12 16:00:52 UTC.
