# Actual preparation and later delivery record

Preparation maps complete frozen sources and checks Python syntax and exact
anchors without importing/executing a science helper or the publication script.
Its static checks and previews are preserved in the preparation evidence.
This packet initially contains no fresh canonical/mutation/independent-control
execution, current runner cache, vocabulary result, graph build, audit-system
check or new publication action. Root must record actual results before final
delivery; no unrun section is a passed section.

The original scientific stdout is an exact prefix of future canonical output;
only mapped finite scope and totals are appended. Keep complete raw cache API
returns before later identity/freshness checks can discard them. Reconstruct
both before and after any vocabulary action, and fail closed on unexplained
map drift. Preserve complete sources, stdout/stderr, timing and declared
timeouts for canonical and mutation runs, including expected Fock survivors.
The paired independent controls are preserved prior evidence; reusing them
does not mean they were executed again against the canonical surfaces.

Root's final focused checks and combined candidate validation/strict lint are
distinct obligations. Current source and source-map hashes, link validation
with inline/display mathematics stripped, and final payload membership must be
refreshed after actual verification adds or changes files. No editable prompt
source is changed by this package.
