# Root execution handoff

Actual explicit runtime base: `3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe`. The dependency/instruction bytes were
frozen after root reported `3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe`; preparation
performed no Git lookup. The script requires explicit --worktree and full --base, exact
HEAD equality, a clean worktree/index, unchanged frozen inputs and absent
targets. It creates only five notes, five primaries and this new packet.

Root reads the ten exact outputs and all administrative replacements before
using them. Run reconstruct.py first, then vocabulary --fix with checked JSON;
reconstruction must still pass and any byte change needs an explicit new map.
Run canonical primaries through runner_cache.execute_and_write_cache(path,60)
and preserve the complete raw execute_runner return externally before the
outer wrapper's identity checks, plus its outer returned result before cache
freshness calls. Keep errors, timeouts, partial streams and original evidence.
Replay each complete canonical source with precisely its original CLI variant
or original literal edit and replacement count; preserve all known survivors.
SPECIFICATIONS.json supplies original source/output/receipt hashes and observed
timeouts, elapsed times and failure gates. No fresh outcome is predeclared.

Root then owns graph build/manifest, exact-base focused audit compatibility,
metadata/source/link manifests, final reread and a new regular milestone PR
stacked on PR9486. Preparation creates or updates no PR and makes no commit,
push, index change, audit application or prompt change. It neither reruns
independent science nor publishes anything. The same-family/separate-context
pairing disclosure must remain in each note, receipt and later PR description.
The fixed deadline remains 2026-10-12 16:00:52 UTC. This is a frozen packet;
root owns the sole live campaign checkpoint and its current checkout pointer.
