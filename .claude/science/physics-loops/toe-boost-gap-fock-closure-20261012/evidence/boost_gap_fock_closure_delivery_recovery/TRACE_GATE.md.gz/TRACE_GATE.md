# Conditional trace and pending execution gates

Each canonical note names its own exact claim, supplied assumptions, direct
proof dependencies, finite primary and next scientific obligation. All five
are bounded_theorem surfaces with conditional-support status. The first four
have upstream_support/partially_closes trace. Integrated retains its original
direct_blocker_closure/closes trace for the conditional one-direction integration
obligation only, without physical input realization. The remaining physical inputs are
not relabeled axioms or discarded as administrative conditions. Combining
separately proved implications does not establish a common realized model.

Required publication gates remain root-owned: complete instantiated source
read, exact reconstruction, checked vocabulary JSON, full raw runner capture,
canonical cache construction, original mutation replay with survivors,
intended graph acknowledgment and focused audit-system compatibility. The
combined pipeline, strict lint and final changed-evidence/source/link manifests
remain separate final delivery gates. No unrun gate is marked passed here.
