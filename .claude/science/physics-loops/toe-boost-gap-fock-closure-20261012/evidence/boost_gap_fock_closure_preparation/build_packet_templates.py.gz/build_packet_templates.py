"""Write mechanical packet templates to scratch only; no science or worktree writes."""
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
specification = json.loads((Q / "SPECIFICATIONS.json").read_text())
specs = specification["specs"]
pairing = "Same selected model family, separate author/reviewer contexts, selected model/effort preserved. Candidate formulas and reported outcomes were visible; this was not blinded or cross-family checking. Root is a coauthor, not the independent reviewer. Preparation adds no new scientific review."
deps = "\n".join("- " + sp["key"] + ": " + "; ".join(d["note"] + " — " + d["role"] for d in sp["dependencies"]) for sp in specs)
status_rows = "\n".join("| `" + sp["claim"] + "` | conditional-support | bounded_theorem | " + sp["claim_reason"] + " |" for sp in specs)
review_rows = "\n".join("| " + sp["key"] + " | `" + sp["report"] + "` | `" + sp["report_sha"] + "` | `" + sp["root_coverage"] + "` |" for sp in specs)
primary_rows = "\n".join("| " + sp["key"] + " | `scripts/" + sp["runner"] + "` | `" + sp["folder"] + "/" + sp["helper"] + "` | " + str(sp["baseline_totals"]["passed"]) + " / " + str(sp["baseline_totals"]["failed"]) + " | " + sp["baseline_totals"]["semantics"] + " |" for sp in specs)
mutation_rows = "\n".join("| " + sp["key"] + " | " + str(len(sp["mutations"])) + " | " + (", ".join(sp["expected_mutation_survivors"]) or "None in the original complete-run gate") + " |" for sp in specs)

templates = {
    "STATE.yaml": '''loop: toe-boost-gap-fock-closure-20261012
mode: milestone_snapshot
delivery: milestone
base_revision: "@BASE@"
science_worktree: "@WORKTREE@"
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
conditional_surface_status: "Five separate implications under their explicit supplied hypotheses"
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: "Analytic implications do not construct their physical inputs or a joint microscopic realization"
trace_class: upstream_support
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
source_review: five_source_bound_reviews_no_required_mathematical_correction
author_checker_pairing: same_selected_model_family_separate_contexts_not_blinded
root_role: coauthor_supervisor_not_independent_reviewer
canonical_execution: not_run_by_preparation
pr_status: preparation_only_no_publication_action
next_exact_action: "Root reads all ten transformed files and runs the exact canonical and whole-source verification before final delivery"
strongest_open_obligation: "Actual finite-range density, exact conservation/closure, simple gapped invariant state and nonzero regular seed targets in the intended microscopic realization"
live_checkpoint: root_owned_campaign_checkpoint_with_current_science_checkout_pointer
deadline_utc: "2026-10-12 16:00:52 UTC"
stop_condition: "The campaign deadline is fixed and is not extended by packaging"
''',
    "GOAL.md": """# Exact conditional milestone contract

Preserve five complete independently source-checked arguments: weighted norm
flow and canonical GNS implementation from finite-range densities and supplied
state identities; those local identities from a simple gapped GNS vacuum and
exact conservation; Fock isometries over the actual regular nonisolated target
span; a finite weighted-current closure criterion under exact conservation;
and conditional one-direction integration with maximal generator domains.
Their quantified hypotheses remain separate. No joint physical realization,
complete physical particle sector or retained status follows by collecting them.
Integrated proves the conditional connected 1+1 representation only at its
stated hypotheses. No mathematical edit is made in publication.
The proofs are the central evidence; finite controls retain their stated limits.
""",
    "ASSUMPTIONS_AND_IMPORTS.md": "# Actual dependencies and supplied hypotheses\n\n" + deps + """

Boost supplies a finite-range density and same-state local infinitesimal
identities. TWW's matched growing-derivation theorem is an external mathematical
input; no positive-energy physical state or remaining Lie identities follows.
Gap supplies exact local current conservation, alpha invariance and a simple
positive-gap canonical GNS energy. Joint J17 is an optional conservation test,
not a premise of G1-G6 implies G7; the weighted-flow theorem is downstream.
Fock supplies the reviewed N1-N31 setting and actual regular seed targets.
The original SC note is context and transitive through N. N36 is unused.
Weighted supplies the specified density and exact conservation. Its optional
operator corollary additionally supplies actual self-adjoint operators and the
same local-vector actions. Newer boost/gap results are not proof dependencies.
Integrated supplies the two remaining local Lie identities and beta>0, with
positivity optional. Boost B1-B37 is direct; Joint J9-J10 is also direct for
the bounded spectral step. The separate mixed-history J1-J3 route is optional.
Readable links in canonical notes name these eight direct branch proof uses.
No additional axiom, primitive or retained dependency class is introduced.
""",
    "APPROACH_REGISTRY.md": """# Mechanisms and evidence roles

Boost matches the finite-spin spatially growing-flow theorem, explicit dyadic
graph estimates and C1 state/operator integration; it avoids assuming analytic
vectors for arbitrary local or rapid almost-local elements. Gap uses finite
ODE locality, cone-split polynomial-time seminorms and Schwartz gap filtering,
including both scalar vacuum columns and both derivation graph extensions.
Fock uses four independent clocks, capped connected clustering, three relative
lattice sums, complete finite-energy spectator bounds and Gram recursion;
separated-tensor density is proved in its defined regular target span only.
Weighted uses finite padded Jacobi and translation-orbit coefficient moments;
conservation removes the weighted residue, leaving a complete finite site test.
Integrated uses the rapid almost-local moving-vector product rule and existing
Banach-group uniqueness before canonical equality and maximal spectral sums.
Each mechanism is judged at its displayed hypotheses. Hashes and control-row
counts establish provenance and sensitivity, not the analytic conclusions.
""",
    "ROUTE_PORTFOLIO.md": "# Author/checker pairing and exposure\n\n" + pairing + """

The complete source reviews retain their exposure timelines, reconstructions,
distinct controls, actual source substitutions and scope limitations. The
Boost reviewer uses distinct algebra/spectral fixtures; Gap uses rational-pair
matrix units and source mutations; Fock retains the timeout and optimized
rational-pair run; Weighted uses the separate exact CAR/qutrit route; Integrated
uses planar Schwartz/Gaussian differentiation and full-domain diagnostics. Complete
own/repository evidence remains losslessly compressed. Root's completed source
reads and evidence binding are coauthor supervision, not an independent audit.
No new checker is invented and no finite row total substitutes for a proof.
""",
    "OPPORTUNITY_QUEUE.md": """# Separate unresolved application obligations

An intended finite-range density and a specified invariant physical state must
still satisfy the required conservation, simple GNS gap and local state
identities. Remaining exact Lie relations and domain/integration hypotheses
need separate verification. The weighted finite criterion can test supplied
densities, but its fixed-XX failure does not exclude other densities or models.
Fock's actual regular seed targets may be absent or zero. Their construction,
whole-sector density, detectors, onto/exhaustion and an S-matrix remain separate.
The integrated note is included only after completed source review. No pending
concrete-model note is included, and this packet launches
no new science. Root owns the sole live campaign checkpoint and its current checkout pointer.
""",
    "NO_GO_LEDGER.md": """# Original negative witnesses and control limits

Boost retains the rapid-almost-local zero-analytic-radius witness only at its
proved scope, insensitive norm/adjoint gates, loose dyadic bounds, initial
formal-C1 substitution and logging collision history. Gap retains nonconserved
current, degenerate-kernel, one-column and false-global-scalar witnesses, and
the original tautological author gate together with its correction. Fock keeps
all thirteen source mutations, including four surviving bookkeeping errors,
the initial timeout and partial output, and the optimized control without a
silent gate change. Weighted keeps the failed first expected-current sign,
nonconserved residue, open-boundary defect, insensitive mutation rows and the
all-beta failure at the fixed XX density only. That is not a universal no-go
over density improvements or interactions. No control failure is deleted.
Integrated preserves all five CLI variants and six whole-helper reviewer
materializations, its initial tautological partial-norm gate and correction,
phase/set-image/domain diagnostics and every insensitive row. Its representation
witnesses are not spin realizations or proof of arbitrary domains by samples.

| Original mutation family | Cases | Original survivors |
|---|---:|---|
""" + mutation_rows + """

All original scope/stress discussions remain in the evidence. Preparation
asserts no new universal impossibility claim or blanket stress-gate PASS.
""",
    "LITERATURE_BRIDGES.md": """# Frozen source versions and limited imports

Boost's matched analytic input is TWW arXiv:2511.02941v2, with the specified
NSY arXiv:1705.08553v3 commutator/Lieb-Robinson input. Fock reuses the identified
Dybalski hep-th/0412226v4 strategy, BDN arXiv:1412.2970v2 proof mechanisms and
NS arXiv:0712.3318v1 clustering result at their exact checked hypotheses and
recorded read scopes. Relativistic, massless, whole-shell density or exhaustive
Fock conclusions are not silently imported. Gap and Weighted's displayed
arguments retain their stated predecessor roles; no new external theorem is
inserted during packaging.
Integrated supplies its own Banach-group uniqueness proof. The Engel-Nagel
publisher PDF page is corroborating context; its exact hash and acquisition
identity are recorded, with no edition or full-paper read invented.

EXTERNAL_SOURCE_INVENTORY.json gives version, URL, original byte hash and
source-to-extraction/render relations. Every raw PDF, TeX, source response,
paper extraction and rendered page stays external and is not deleted. Complete
own reasoning, source receipts and instructions are compressed in EVIDENCE_MAP.
Preparation claims no new literature search, download or full paper read.
""",
    "ARTIFACT_PLAN.md": """# Complete notes and finite primaries

| Result | Canonical primary | Entire original helper | Original PASS / FAIL | Total semantics |
|---|---|---|---|---|
""" + primary_rows + """

SPECIFICATIONS.json derives these historical counts from frozen raw results.
Fock's seven JSON records are not a predicate count. Weighted's separate
33-predicate matrix helper and the prior 25-predicate version remain complete
supplemental author evidence; they are not folded into its canonical sparse
TOTAL or claimed freshly executed. Integrated's 71-predicate whole helper keeps
all active CLI branches, and every original reviewer materialization is bound.
All independent helpers and their complete
original output are likewise bound evidence, not second canonical primaries.

Publication preserves the entire source, calculation and failure gate for each
primary. Mapped additions are declarations/guard and scope/totals. Boost's and Integrated's
output arguments become optional. Boost/Gap/Weighted/Integrated suppress only the mapped
result-file side effects, preserving complete result calculations and any original self-hash calculation.
No output predicate or threshold is rewritten. Exact maps recover all sources.
""",
    "TRACE_GATE.md": """# Conditional trace and pending execution gates

Each canonical note names its own exact claim, supplied assumptions, direct
proof dependencies, finite primary and next scientific obligation. All five
are bounded_theorem surfaces with conditional-support status. The first four
have upstream_support/partially_closes trace. Integrated retains its original
direct_blocker_closure/closes trace for the conditional one-direction integration
obligation only, without physical input realization. The remaining physical inputs are
not relabeled axioms or discarded as administrative conditions. Combining
separately proved implications does not establish a common realized model.

Required publication gates remain root-owned: complete instantiated source
read, exact reconstruction, checked vocabulary JSON, full raw runner capture,
canonical cache construction, original mutation replay with survivors,
intended graph acknowledgment and focused audit-system compatibility. The
combined pipeline, strict lint and final changed-evidence/source/link manifests
remain separate final delivery gates. No unrun gate is marked passed here.
""",
    "CLAIM_STATUS_CERTIFICATE.md": """# Current surface claim certificate

| Proposed claim ID | Surface status | Claim type | Supplied boundary |
|---|---|---|---|
""" + status_rows + """

These are source-reviewed conditional implications. No applied audit verdict,
formal retained promotion, proof-assistant certificate, new physical axiom or
actual intended model is claimed. Independent audit status remains owned by
the separate audit path. Historical author statuses are retained as historical
records; the separately labeled note appendices give the completed review.
""",
    "REVIEW_HISTORY.md": "# Source-bound review history\n\n" + pairing + "\n\n" + """| Result | Complete source review | Review SHA-256 | Root coverage |
|---|---|---|---|
""" + review_rows + """

All five reviews require no mathematical correction. Root completed full
source/evidence closure before authorizing preparation. Original helper
weaknesses, failed executions, corrected author controls, mutation survivors
and finite limits remain available in full. The mechanical preparer reviewed
the notes/primary sources to design exact administrative maps, without issuing
a new mathematical verdict or executing science. Its syntax/anchor validation
does not add independent scientific evidence or reclassify the source reviews.
""",
    "HANDOFF.md": """# Root execution handoff

Actual explicit runtime base: `@BASE@`. The dependency/instruction bytes were
frozen after root reported `3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe`; preparation
performed no Git lookup. The script requires explicit --worktree and full --base, exact
HEAD equality, a clean worktree/index, unchanged frozen inputs and absent
targets. It creates only five notes, five primaries and this new packet.

Root reads the ten exact outputs and all administrative replacements before
using them. Run reconstruct.py first, then vocabulary --fix with checked JSON;
reconstruction must still pass and any byte change needs an explicit new map.
Run canonical primaries through runner_cache.execute_and_write_cache(path,60)
and preserve the complete raw execute_runner return externally before the
outer wrapper's identity checks, plus its outer returned result before cache
freshness calls. Keep errors, timeouts, partial streams and original evidence.
Replay each complete canonical source with precisely its original CLI variant
or original literal edit and replacement count; preserve all known survivors.
SPECIFICATIONS.json supplies original source/output/receipt hashes and observed
timeouts, elapsed times and failure gates. No fresh outcome is predeclared.

Root then owns graph build/manifest, exact-base focused audit compatibility,
metadata/source/link manifests, final reread and a new regular milestone PR
stacked on PR9486. Preparation creates or updates no PR and makes no commit,
push, index change, audit application or prompt change. It neither reruns
independent science nor publishes anything. The same-family/separate-context
pairing disclosure must remain in each note, receipt and later PR description.
The fixed deadline remains 2026-10-12 16:00:52 UTC. This is a frozen packet;
root owns the sole live campaign checkpoint and its current checkout pointer.
""",
    "PR_BACKLOG.md": "# Root-owned publication work\n\n" + pairing + """

No PR action is performed by preparation. Root's intended destination is a
new regular milestone PR stacked on PR9486 after the preceding three-note milestone. Final source
reads, canonical caches, exact mutation/stream comparisons, graph acknowledgment,
focused compatibility and complete metadata/link/source manifests remain root's
work. The final PR must describe the five separate conditional results and their
actual evidence/limits, including the same-family separate-context pairing.
Do not claim formal audit, physical model realization, fresh independent execution or
completed landing from this unexecuted preparation package.
""",
    "DELIVERY_CHECKS.md": """# Actual preparation and later delivery record

Preparation maps complete frozen sources and checks Python syntax and exact
anchors without importing/executing a science helper or the publication script.
Its static checks and previews are preserved in the preparation evidence.
This packet initially contains no fresh canonical/mutation/independent-control
execution, current runner cache, vocabulary result, graph build, audit-system
check or new publication action. Root must record actual results before final
delivery; no unrun section is a passed section.

The original scientific stdout is an exact prefix of future canonical output;
only mapped finite scope and totals are appended. Keep complete raw cache API
returns before later identity/freshness checks can discard them. Reconstruct
both before and after any vocabulary action, and fail closed on unexplained
map drift. Preserve complete sources, stdout/stderr, timing and declared
timeouts for canonical and mutation runs, including expected Fock survivors.
The paired independent controls are preserved prior evidence; reusing them
does not mean they were executed again against the canonical surfaces.

Root's final focused checks and combined candidate validation/strict lint are
distinct obligations. Current source and source-map hashes, link validation
with inline/display mathematics stripped, and final payload membership must be
refreshed after actual verification adds or changes files. No editable prompt
source is changed by this package.
""",
    "PREPARATION_LIMITATIONS.md": "# Mechanical preparation limits\n\n" + pairing + """

Preparation uses the current workflow/delivery/conformance source bytes,
unchanged from the preceding inspected revision, and the already reviewed
source evidence. Root's latest source/evidence completion and clean base report
are inputs; preparation itself performs no Git/ref read or mutation. The future
script checks exact HEAD and clean state before any writes. It never executes
science or changes existing source evidence. Unknown input or target mappings
fail closed instead of becoming invented results.

Own/repository evidence is preserved completely for the ten named bundles,
selected root records and explicitly consulted instructions/dependencies.
Transient bytecode and desktop metadata are explicitly excluded. Raw third-
party source/extraction/media bytes are inventoried and left untouched. Counts
derive from original results and mean only their recorded units. No mathematical
repair, silent finite-gate improvement or new science occurs during publication.

SOURCE_IDENTITIES.json initially covers the prepared payload except itself.
Root must regenerate or supplement the final manifest after verification or
metadata changes. PUBLICATION_EDITS.json remains the authority for exact note
and primary reconstruction; any later canonical change needs its own explicit
source map and hash. This snapshot is not a second live campaign checkpoint.
""",
}
(Q / "PACKET_TEMPLATES.json").write_text(json.dumps(templates, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"metadata_templates": len(templates), "worktree_files_written": 0, "science_or_preparation_executed": False}))
