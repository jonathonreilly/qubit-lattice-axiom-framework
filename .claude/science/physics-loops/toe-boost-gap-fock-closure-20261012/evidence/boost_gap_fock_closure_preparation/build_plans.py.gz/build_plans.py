"""Create exact administrative maps and review previews under this scratch directory.

Literal text transformations and compile-only checks; no imports of helpers,
science execution, preparation-script execution, Git operation or worktree write.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
CONFIG = json.loads((Q / "SPECIFICATIONS.json").read_text())
PACKET = CONFIG["packet"]
PAIRING = "Same selected model family in separate author/reviewer contexts; the selected model and reasoning effort were preserved. Candidate formulas and reported outcomes were visible before distinct controls, so this was neither blinded nor cross-family checking. Root proposed mechanisms and is a coauthor, not the independent reviewer. The mechanical preparer performed no new scientific review."


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Transform:
    def __init__(self, relative):
        self.relative = relative
        self.original = (S / relative).read_bytes()
        self.text = self.original.decode()
        self.edits = []

    def replace(self, before, after, category, reason):
        if self.text.count(before) != 1:
            raise RuntimeError("Ambiguous exact anchor: " + reason)
        self.text = self.text.replace(before, after, 1)
        self.edits.append({"before": before, "after": after, "category": category, "reason": reason, "occurrences": 1})

    def finish(self, kind, target, suffix=""):
        final = (self.text + suffix).encode()
        return final, {
            "kind": kind, "source_path": str(S / self.relative), "source_sha256": sha(self.original),
            "preserved_source": "evidence/" + self.relative + ".gz", "edits": self.edits,
            "appended_text": suffix, "appended_text_role": "Separate publication evidence appendix" if kind == "note" else "No suffix outside the original driver",
            "publication_path": target, "publication_sha256": sha(final), "publication_bytes": len(final),
            "mathematical_changes": [], "pairing": PAIRING,
        }


def header(sp):
    next_actions = {
        "Boost": "Supply a checked same-state finite-range realization and the remaining exact Lie relations; independently verify any integration argument.",
        "Gapped": "Supply the intended density, exact conservation and simple gapped GNS vacuum, then match the separate weighted-flow theorem before use.",
        "Nonisolated_fock": "Construct nonzero regular seed targets in an actual model and separately address density, detectors and onto/exhaustion.",
        "Weighted_current": "Test the full criterion on a specified intended density; separately construct actual self-adjoint operators and justify any global integration.",
        "Integrated_boost": "Supply a nontrivial intended density/state satisfying the two remaining exact local Lie identities, then separately check any positivity or broader covariance claim.",
    }
    fields = {
        "claim_id": sp["claim"], "claim_type": "bounded_theorem", "claim_scope": sp["scope"],
        "upstream_dependencies": sp["deps"], "runner": "scripts/" + sp["runner"],
        "actual_current_surface_status": "conditional-support", "target_claim_type": "bounded_theorem",
        "trace_class": sp.get("trace_class", "upstream_support"), "target_claim_id": None,
        "target_blocker_text": sp.get("target_blocker_text", next_actions[sp["key"]]), "source_of_blocker_text": "handoff",
        "reachability_to_target": sp.get("reachability_to_target", "partially_closes"), "artifact_role": "theorem",
        "next_trace_action": next_actions[sp["key"]], "conditional_surface_status": sp["conditional"],
        "hypothetical_axiom_status": None, "admitted_observation_status": None,
        "claim_type_reason": sp["claim_reason"], "audit_required_before_effective_retained": True,
        "bare_retained_allowed": False,
    }
    lines = ["---"]
    for key, value in fields.items():
        if isinstance(value, list):
            lines.append(key + (":" if value else ": []"))
            lines.extend("  - " + item for item in value)
        else:
            lines.append(key + ": " + json.dumps(value, ensure_ascii=False))
    return "\n".join(lines) + "\n---\n\n"


DETAILS = {
    "Boost": """The complete B1-B38 source review requires no mathematical correction.
It checks the finite-spin and Lieb-Robinson hypotheses of the supplied TWW
growing-derivation theorem, the dyadic graph losses, state integration, the C1
Schrodinger-curve identification of a supplied operator and the common-domain
current construction. The external theorem is a checked application; no new
general growing-flow theorem is claimed. The frozen TWW and NSY versions and
source hashes are in the external inventory, with raw paper bytes left external.

The final author helper has 49 recorded finite predicates. Its four original
CLI mutations fail 13, 12, 6 and 2 predicates. Norm preservation accepts the
wrong clock, while the full algebra adjoint accepts the left-only GNS action;
distinct cyclic/local-vector gates detect that omission. The dyadic upper-bound
fixture remains loose. The separate reviewer helper has 71 recorded predicates,
with distinct algebraic and spectral mutation checks. Its zero analytic-radius
example concerns a rapid almost-local vector, not a claim that local vectors
lack analytic radius. These finite checks do not establish infinite operator
domains, invariance of a physical state or the general external theorem.

The initial author's C1 gate substituted a formal commutator; the corrected
actual-orbit finite difference, both source versions and all surviving logs
remain preserved. The first logger's suffix collisions, unavailable overwritten
receipts, failed tar extraction of a single gzip TeX response and failed prose
patch contexts are recorded without inventing missing executions. Five author
replays were bound to their original scientific streams by the source reviewer.
Root subsequently verified their provenance and completed the source read; root
did not thereby become an independent reviewer. No positive-energy physical
state, remaining Lie identities or integrated Lorentz representation is supplied.
""",
    "Gapped": """The complete G1-G49 source review requires no mathematical correction.
The proof derives both local state identities from the supplied simple gapped
GNS vacuum and exact current conservation. It checks finite ODE/Lieb-Robinson
recursion without an outside-support volume, polynomial time bounds before
Schwartz filtering, both graph extensions and both scalar vacuum columns.
It never infers that the filtered observable is a globally scalar operator.
The Current note is the direct proof dependency. The Joint finite-site
criterion is an optional way to test the supplied conservation premise, and
the weighted-flow result is downstream; neither is used in G1-G6 implies G7.

The final author helper has 105 finite predicates. The five original CLI
variants fail 5, 5, 1, 1 and 1 predicates; some variants alter comparison claims
instead of the computed routine. The separate reviewer used exact rational-pair
controls with 134 predicates and five actual source substitutions, failing
24, 24, 4, 2 and 1. The complete fixtures and nondiscriminating rows remain
available. Counts indicate recorded sensitivity only, not the analytic proof.

The initial author filter comparison used its own computed matrix on both
sides. Its correction independently derives the diagonal comparison matrix;
the initial helper, all outputs, correction diff and final runs are preserved.
The saved analytic draft snapshot followed the first baseline execution;
neither a pre-execution hash freeze nor blinded author checking is claimed.
Six author result/stdout replays were bound exactly in the source review.
The degenerate vacuum, one-column shortcut, nonconserved current, density-gauge
and global-scalar counterexamples keep their original scopes. GNS vacuum
uniqueness is not uniqueness among all ground states. Actual density, state,
gap and conservation remain hypotheses; no intended physical model, Lorentz
closure, weighted-flow realization, scattering or Fock conclusion is supplied.
""",
    "Nonisolated_fock": """The complete NF1-NF38 source review requires no mathematical correction.
It checks the four independent averaging clocks, the capped clustering kernel
with three relative lattice sums, the squared contraction bound, every
finite-energy spectator, the full Gram recursion and the defined regular
one-particle space. The small-width sufficient bound is not asserted necessary.
Width comparison then transfers the result to every fixed sublinear power.
Compatible overlapping charts do not add species. The regular target space
may be zero; its separated-tensor density does not assert density in an entire
physical mass sector or density of the interacting scattering range.

The original author driver emits seven complete JSON records. Publication's
TOTAL counts one completed assertion-guarded driver, not seven predicates.
Thirteen full-source mutations preserve the original gates: nine are rejected,
while removal of the volume-growth factor, one relative count, the contraction
exponent and the tail margin survive. All changed numeric output and passing
rows remain. No calculation or gate is silently repaired to hide this limit.
The proof carries the general exponents; the finite arithmetic does not prove
them. The original independent matrix control timed out after two partial
records at 60 seconds. A rational-pair optimization retained its matrices,
cases and gates and completed six records. Both implementations, timeout,
partial output and completed run are preserved with their actual receipts.

The Nonisolated mass note supplies N1-N31 existence/comparison and energy
bounds. The prior compact-patch Fock mechanism is a second direct dependency,
reconstructed at the actual averaged, nonexact-vacuum hypotheses. Original SC
is context and transitive through N. N36's weighted-Casimir repair is preserved
as predecessor provenance; this proof imposes geometric regularity directly
and does not use N36. The exact Dybalski, BDN and NS paper versions and read
page scopes are recorded externally. No regular-seed existence, whole-sector
density, onto/exhaustion, detector, ND/EX, S-matrix, boost or microscopic model
is inferred. The positive-gap clustering premise is not a massless-vacuum result.
""",
    "Weighted_current": """The complete W1-W28 source review requires no mathematical correction.
It checks the negative first translation moment, the retained conservation
residue, the complete finite-site equivalence and the optional common-local-
domain operator corollary under its separately supplied actual actions. The
Current I1-I13 algebra and Joint J15-J20 orbit theorem are the direct proof
uses. Newer boost-flow or gap-filter theorems are not premises. A zero local
derivation is not a zero density, and primitive/representative ambiguity is
handled at the original stated scope.

The complete sparse author helper is the canonical primary: 73 finite
predicates and five copied-source mutations, with 26, 2, 1, 1 and 1 failures.
Passing mutant rows remain visible: current rescaling can conserve, shared
wrong moments can cancel, and zero-action probes may not detect a sign.
The separate author occupation-matrix helper and all 33 final predicates remain
bound evidence, including all eight added sign/beta diagnostics and the 25-row
earlier version. The H=2Z, B=Y, P=4X, beta=-4 fixture does not conserve energy
current and is not a physical lattice model. The guarded integer maximum
33,792 is below 2^60; seven open sites give finite padding, not an infinite
system, and the global boundary commutator remains nonzero.

The original sparse run failed its handwritten expected-current sign, with
72 passing predicates and one failed predicate. Its computed current/r/t
were unchanged by the expected-sign correction. All original source, output
and receipts remain. The first receipt mislabeled an after-execution clock
as started_utc; its separate correction note does not invent a missing start.
The separate reviewer reconstructed the proof and used an eleven-site exact
CAR route plus complete qutrit matrix units. Its 205 finite predicates,
different beta witness and eight byte-exact author replays are preserved.
Root's lossless read grouped 187 zero-residual rows by full labels and read
18 other records; that compression is a read aid, not new scientific evidence.

The fixed XX density fails weighted beta-energy closure for every real beta
at that density. This does not quantify over density improvements, other
interactions or all models. No integrated Lorentz group, physical self-adjoint
realization, current conservation in the intended model, particle theorem or
new physical axiom follows. All hypotheses retain their supplied status.
""",
    "Integrated_boost": """The complete C1-C28 source review requires no mathematical correction.
Actual rapid almost-local flows, finite seminorm losses and the moving-vector
product rule integrate the two remaining supplied local Lie identities. The
comparison group exists before classical-solution uniqueness is applied.
Canonical cyclic equality then gives complete Stone generators on maximal
joint-spectral sum domains, the inverse spectral-set image and the optional
positive-energy cone. No common core, analytic-vector or preexisting strong-
commutation premise is inserted. This closes the specified conditional
one-direction integration obligation, not physical realization of its inputs.

Boost B1-B37 is a direct dependency. Joint J9-J10 also directly supplies the
bounded Fourier/Gaussian spectral approximation used after commuting canonical
unitaries are established. The separate Joint J1-J3 mixed-history route is an
optional comparison and is not applied to the spatially weighted boost.
Gap-filter and weighted-closure results are not premises here. The uniqueness
argument is supplied in the note; its Engel-Nagel page is corroborating context
and remains externally inventoried without a new paper-reading claim.

The whole author helper has 71 recorded predicates. Its five original active
CLI branches fail 39, 13, 3, 3 and 50 predicates. The reviewer separately kept
the baseline byte-identical and materialized all six operative branch choices
for each mutant into complete helpers, preserving every comparator and gate.
All six review replays reproduce their original final stdout and result JSON
bytes. Both the original CLI representation and every reviewer source/diff,
stream, receipt and result are preserved. Reverse boosts still pass group-law
and mass-invariant checks; zero-rapidity energy is even; generator mixing does
not test the spatial divisor; selected projections may miss an energy phase.
Differential coefficient checks do not prove self-adjointness or full domains.

The author's initial domain helper assigned the expected partial norm directly.
Its corrected explicit sum, original helper and all six initial/final runs are
retained; the proof did not change. The separate reviewer froze its reconstruction
and planar Schwartz/Gaussian control before author helper/output exposure, while
the target's formulas and reported results were already visible. Its 38 exact
predicates and five whole-source mutants (2, 4, 1, 9 and 12 failed predicates)
test moving inputs, set images, intersection-domain restriction, beta and boost
direction. The cancellation-strip and distinct self-adjoint-extension witnesses
retain their exact scopes. Integrity controls reject altered or missing source;
that is provenance evidence, not a mathematical certificate. Root's earlier
text-spacing matcher failure and AST-only verifier repair remain preserved.

The theorem constructs conditional connected 1+1 translation/boost covariance
in the declared clocks. The intended density, invariant state, beta>0 and two
remaining local identities are supplied, with positive H optional. It supplies
no nontrivial common microscopic example, fixed mass, isolated shell, geometric
momentum identification, rotations, additional boosts, higher-dimensional
Poincare theorem, particles or scattering/exhaustion conclusion.
""",
}


def appendix(sp):
    return f"""

## Publication evidence and review record

The complete frozen author source is `{sp['source']}`, SHA-256
`{sp['source_sha']}`. Its separate review is `{sp['report']}`, SHA-256
`{sp['report_sha']}`, with receipt SHA-256 `{sp['review_receipt_sha']}`.
The [evidence map](../{PACKET}/EVIDENCE_MAP.json) preserves the complete own
author/reviewer sources, earlier versions, failures, stdout/stderr, execution
receipts, root source-coverage records and their byte identities. The
[exact transformation map](../{PACKET}/PUBLICATION_EDITS.json) and
[reconstruction program](../{PACKET}/reconstruct.py) recover every byte of
this complete note and its entire primary. No mathematical correction is made.
Historical review-pending and worker-scope statements above describe the author
freeze; this separate appendix records the completed source review.

**Author/checker pairing:** {PAIRING}

{DETAILS[sp['key']]}
The [canonical finite primary](../scripts/{sp['runner']}) retains every
original calculation and failure gate. Publication adds only mapped input and
timeout declarations, an assertion guard and finite-scope output. Original
adjacent-result writes are suppressed where present; the complete original
JSON outputs remain in the evidence map. Required output destinations in the
Boost and Integrated CLIs become optional for ordinary canonical execution.
Where present, self-hash calculations remain and refer to the source actually run.

Preparation ran no primary, mutant, independent control, runner-cache API,
vocabulary fixer, graph builder or audit compatibility check. Actual canonical
execution and complete original mutation replay are root's subsequent work,
recorded in [delivery checks](../{PACKET}/DELIVERY_CHECKS.md). Historical
source-bound results are not fresh canonical results. No retained promotion,
applied audit verdict, Lean certificate, helper-registry change or completed
publication is asserted here. Combined candidate validation and strict audit
lint remain separate landing gates.

This is a frozen milestone record. Root owns the sole live campaign checkpoint
and its current science-checkout pointer. Editable prompt files changed: none.
"""


def note(sp):
    tr = Transform(sp["source"])
    if sha(tr.original) != sp["source_sha"]:
        raise RuntimeError("Original note mismatch")
    if tr.text.startswith("---\n"):
        before = tr.text[:tr.text.index("\n---\n", 4) + len("\n---\n\n")]
        tr.replace(before, header(sp), "claim_metadata", "Complete bounded claim/status/dependency/trace metadata; no proof edit")
    else:
        first = tr.text.splitlines(keepends=True)[0]
        tr.replace(first, header(sp) + first, "claim_metadata", "Add bounded claim/status/dependency/trace metadata; no proof edit")
    provenance = f"S denotes the original research collection. The [frozen milestone handoff](../{PACKET}/HANDOFF.md) and [evidence map](../{PACKET}/EVIDENCE_MAP.json) preserve the original source bundles and complete own evidence. "
    deps = "The direct in-branch proof dependencies are " + "; ".join(f"[{key}]({dep['note']}): {dep['role']}" for key, dep in zip(sp["dependency_keys"], sp["dependencies"])) + " Other named sources are historical context or transitive dependencies unless their use is stated explicitly."
    if sp["key"] == "Boost":
        tr.replace("**Author proof, 2026-10-12; independent review pending.**", "**Conditional bounded theorem, 2026-10-12; separate complete source review requires no mathematical correction.**", "review_status", "Record completed source review without audit promotion")
        tr.replace("Let S be this note's directory. Exact source snapshots, acquisition evidence,\nproof freeze, controls and the current checkpoint are in\n`S/microscopic_boost_flow/`. There is no audit status attached to this note.", provenance + deps + " No audit status is attached to this note.", "portable_provenance", "Replace local recovery description with portable evidence and direct Current proof dependency")
        tr.replace("The remaining independent review must examine", "At the author freeze, the remaining independent review had to examine", "historical_status", "Distinguish the original pending handoff from the completed review appendix")
        tr.replace("No independent review, formal proof-assistant verification, repository", "Frozen author operational record: no independent review, formal proof-assistant verification, repository", "historical_status", "Label author-only execution and publication history")
        tr.replace("No editable prompt file, framework axiom, prior frozen source, repository", "Frozen author operational record: no editable prompt file, framework axiom, prior frozen source, repository", "historical_status", "Preserve original worker write-scope statement as history")
    elif sp["key"] == "Gapped":
        tr.replace("**Author theorem, 2026-10-12; independent review pending.**", "**Conditional bounded theorem, 2026-10-12; separate complete source review requires no mathematical correction.**", "review_status", "Record completed source review without audit promotion")
        tr.replace("Write S for this note's directory. Source snapshots, controls, logs and the\ncurrent recovery checkpoint are in `S/gapped_boost_invariance/`.", provenance + deps + " Joint J17 is an optional test of the supplied conservation premise; the weighted-flow theorem is downstream, not a premise of G1-G6 implies G7.", "portable_provenance", "Portable recovery links and direct Current proof use only; exclude optional/downstream graph edges")
        tr.replace("The next scientific handoff is a fresh independent review of this exact", "At the author freeze, the next scientific handoff was a fresh independent review of this exact", "historical_status", "Preserve the pending-review obligation as historical author context")
        tr.replace("Only this note and `gapped_boost_invariance/` were written.", "Frozen author operational record: only this note and `gapped_boost_invariance/` were written.", "historical_status", "Label original author write scope")
    elif sp["key"] == "Nonisolated_fock":
        tr.replace("**Author status:** conditional-support; this extension has not yet received independent review.", "**Actual current-surface status:** conditional-support; complete separate source review requires no mathematical correction.", "review_status", "Record completed review while retaining the bounded theorem tier")
        tr.replace("Let S be `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.", provenance + deps, "portable_provenance", "Remove machine-local path and name exact direct N/Fock proof dependencies; original SC remains context")
        tr.replace("`CHECKPOINT.md` is the single current recovery checkpoint.", "At the author freeze, `CHECKPOINT.md` was its recovery checkpoint; current campaign recovery and its science-checkout pointer remain root-owned.", "historical_status", "Separate frozen author recovery state from the current campaign checkpoint")
        tr.replace("The exact next scientific action is a fresh independent review of (NF14)–(NF38) and their stated N dependencies before extensive downstream reuse.", "At the author freeze, the exact next scientific action was a fresh independent review of (NF14)–(NF38) and their stated N dependencies before extensive downstream reuse; the completed review is recorded below.", "historical_status", "Preserve the original independent-review handoff and record its completion")
        tr.replace("Only this probe and `nonisolated_fock/` are author outputs.", "Frozen author operational record: only this probe and `nonisolated_fock/` are author outputs.", "historical_status", "Label original author-only output scope")
    elif sp["key"] == "Weighted_current":
        tr.replace("**Author derivation, 2026-10-12; independent review pending.**", "**Conditional bounded theorem, 2026-10-12; separate complete source review requires no mathematical correction.**", "review_status", "Record completed source review without changing the local-algebra result")
        tr.replace("Write S for this note's directory. The complete predecessor arguments were\nread, including their finite padded Jacobi proofs and tensor-word orbit\ntheorem. Frozen copies are under `weighted_current_closure/sources/`.", provenance + deps + " The complete original predecessor arguments were read, including their finite padded Jacobi proofs and tensor-word orbit theorem; source copies remain under the evidence-map entries for `weighted_current_closure/sources/`.", "portable_provenance", "Portable original snapshots and exact Current/Joint proof dependencies")
        for label, original in [("Current implementation", "MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md"), ("Joint-flow probe", "MICROSCOPIC_JOINT_FLOW_PROBE.md")]:
            tr.replace(f"[{label}]({original})", "Original `" + original + "`", "portable_provenance", "Keep original line count/hash attached to the original source; canonical proof link is separately declared")
        for label, original in [("Current review", "MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md"), ("Joint-flow review", "MICROSCOPIC_JOINT_FLOW_REVIEW.md")]:
            tr.replace(f"[{label}]({original})", f"[{label}, frozen original](../{PACKET}/evidence/weighted_current_closure/sources/{original}.gz)", "portable_provenance", "Point historical review provenance to its exact compressed original; no new claim graph dependency")
        tr.replace("The frozen receipt and current checkpoint bind the deliverable and evidence.", "Frozen author operational record: the receipt and author checkpoint bind the original deliverable and evidence.", "historical_status", "Label original worker handoff and write scope as history")
    else:
        tr.replace("**Author conditional theorem, 2026-10-12. Independent review pending.**", "**Conditional bounded theorem, 2026-10-12; complete separate source review requires no mathematical correction.**", "review_status", "Record completed conditional integration review without changing the supplied premise boundary")
        tr.replace("Write S for this note's directory. Source snapshots, checks and recovery\nevidence are in `S/integrated_boost_covariance/`.", provenance + deps, "portable_provenance", "Portable full evidence and exact Boost/J9-J10 proof dependencies; distinguish optional mixed-history comparison")
        tr.replace("The current recovery state is `CHECKPOINT.md`; final input/output bindings\nare in `receipt.json`.", "At the author freeze, its recovery state was `CHECKPOINT.md` and its final input/output bindings were in `receipt.json`; current campaign recovery remains root-owned.", "historical_status", "Preserve original author recovery state as historical metadata")
        tr.replace("A fresh independent source review must examine the complete final note,\nmatched upstream hypotheses, and controls before substantial downstream\nreuse.", "At the author freeze, a fresh independent source review was required for the complete final note, matched upstream hypotheses and controls before substantial downstream reuse; that review is now complete and recorded below.", "historical_status", "Record completion of the original source-review handoff, preserving the original proof")
        tr.replace("No Lean formalization, repository\npipeline, commit, PR, merge, push or audit action has been performed by this\nworker.", "Frozen author operational record: no Lean formalization, repository pipeline, commit, PR, merge, push or audit action was performed by this worker.", "historical_status", "Label the original worker execution/publication scope")
    return tr.finish("note", "docs/" + sp["note"], appendix(sp))


N5 = {
    "Boost": [
        "per_element: finite weighted commutator, current and orbit-derivative fixtures are checked; the analytic proof carries their generalization.",
        "per_site: finite support and current signs are checked; no intended microscopic density/state is supplied by the controls.",
        "per_mode: checked and not executed — no physical particle mode or positive-energy spectral realization is constructed.",
        "per_block: finite GNS column, adjoint and C1-orbit fixtures are checked; their nondiscriminating rows remain visible.",
        "lattice_wide: checked and not executed — infinite weighted-flow existence and domains use the conditional analytic argument and matched external theorem.",
    ],
    "Gapped": [
        "per_element: exact current, filter and vacuum-column finite fixtures are checked; the infinite argument is in the note.",
        "per_site: finite matrix-unit and support recursion fixtures are checked; intended-model conservation remains supplied.",
        "per_mode: finite gap/filter fixtures are checked; they do not construct an actual infinite GNS spectrum.",
        "per_block: simple and degenerate vacuum fixtures retain both passing and failing scalar-column controls.",
        "lattice_wide: checked and not executed — rapid almost-local graph bounds and state identities rely on the conditional analytic proof.",
    ],
    "Nonisolated_fock": [
        "per_element: exact free-word and finite covariance identities are checked; the analytic contraction proof remains separate.",
        "per_site: finite support geometry and exact rational lattice sums are checked; general exponent gates have documented survivors.",
        "per_mode: finite four-clock and energy-window fixtures are checked; no nonisolated infinite-lattice particle model is constructed.",
        "per_block: finite spectator and width bookkeeping is checked; one completed driver is not a predicate count or proof grade.",
        "lattice_wide: checked and not executed — Fock isometry and density in the defined regular space use the conditional analytic proof.",
    ],
    "Weighted_current": [
        "per_element: exact sparse coefficient moments, residuals and weighted Jacobi fixtures are checked against the original gates.",
        "per_site: complete finite Pauli site tests and padding controls are checked; no intended-model conservation is asserted.",
        "per_mode: checked and not executed — no physical particle spectrum, beta determination or continuum mode is inferred.",
        "per_block: finite XX and nonconserving fixtures retain all original defect and insensitive rows.",
        "lattice_wide: checked and not executed — local algebraic closure and the optional supplied-operator corollary require the analytic hypotheses.",
    ],
    "Integrated_boost": [
        "per_element: rational spectral mixing and actual multiplier/shift compositions are checked with the original sign and beta gates.",
        "per_site: checked and not executed — these abstract representation diagnostics do not construct a finite-range spin density or state.",
        "per_mode: finite abstract spectral fixtures and a written domain witness are checked; no physical particle or fixed mass is inferred.",
        "per_block: actual unitary, clock and projection fixtures retain every original insensitive row and active CLI variant.",
        "lattice_wide: checked and not executed — full integration and maximal domains use the conditional rapid almost-local analytic proof.",
    ],
}


def primary(sp):
    tr = Transform(sp["folder"] + "/" + sp["helper"])
    if sha(tr.original) != sp["helper_sha"]:
        raise RuntimeError("Original helper mismatch")
    tree = ast.parse(tr.text)
    body = list(tree.body)
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body.pop(0)
    while body and isinstance(body[0], ast.ImportFrom) and body[0].module == "__future__":
        body.pop(0)
    anchor = tr.text.splitlines(keepends=True)[body[0].lineno - 1]
    declaration = "AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = " + json.dumps(sp["audit_inputs"], indent=4) + '\nif not __debug__:\n    raise RuntimeError("Run without -O: finite control assertions must be enabled")\n\n'
    tr.replace(anchor, declaration + anchor, "runner_declarations", "Declare bound note/dependency/evidence-map inputs, timeout and assertion guard after the docstring and every future import")
    scope = "SCOPE: Original finite controls only; documented mutation survivors and insensitive rows remain. Counts do not prove the analytic theorem or a physical model."
    output = "\n".join("    print(" + repr(line) + ")" for line in N5[sp["key"]]) + "\n"
    if sp["key"] == "Boost":
        tr.replace('parser.add_argument("--output", required=True)', 'parser.add_argument("--output", default=None)', "canonical_cli", "Make the unused output destination optional so the canonical primary executes with no arguments")
        tr.replace('    Path(args.output).write_text(json.dumps(result, indent=2) + "\\n")', "    # Publication suppresses the adjacent-result write only; all calculations and original JSON evidence are preserved.", "suppress_output_side_effect", "Suppress the result-file write while retaining the complete result calculation and source self-hash")
        anchor = '    return 1 if result["failed"] else 0'
        output += '    print("TOTAL: PASS=" + str(result["passed"]) + " FAIL=" + str(result["failed"]))\n'
        output += "    print(" + repr(scope) + ")\n"
        tr.replace(anchor, output + anchor, "scoped_output", "Append finite-scope lines and existing-result totals after every original stdout byte; keep the exact failure return")
    elif sp["key"] == "Gapped":
        tr.replace("    args.output.parent.mkdir(parents=True,exist_ok=True)\n    args.output.write_text(json.dumps(result,indent=2)+'\\n')", "    # Publication suppresses output-directory creation and result writing only; the complete result remains computed.", "suppress_output_side_effect", "Suppress only output mkdir/write side effects; original predicates, result/self-hash and printed total remain")
        anchor = "    return 1 if result['failed'] else 0"
        output += "    print(" + repr(scope) + ")\n"
        tr.replace(anchor, output + anchor, "scoped_output", "Append finite-scope lines after the complete original stdout; keep the exact failure return")
    elif sp["key"] == "Nonisolated_fock":
        anchor = '    report("completion", status="complete", independent_review=False,\n           scope="Author finite algebra, support-counting and exponent controls only.")'
        output += '    print("TOTAL: PASS=1 FAIL=0")\n    print(' + repr(scope + " TOTAL counts one completed assertion-guarded driver.") + ")"
        tr.replace(anchor, anchor + "\n" + output, "scoped_output", "Append scope and a one-driver completion total inside the original main guard, after all seven original JSON records")
    elif sp["key"] == "Weighted_current":
        tr.replace("    Path(__file__).with_name('weighted_results.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\\n')", "    # Publication suppresses the adjacent-result write only; the complete result and source self-hash remain computed.", "suppress_output_side_effect", "Suppress only adjacent JSON output; preserve all sparse calculations, predicates, metadata calculations and stdout")
        anchor = "    return int(bool(output['summary']['failed']))"
        output += "    print(" + repr(scope) + ")\n"
        tr.replace(anchor, output + anchor, "scoped_output", "Append finite-scope output after the original total; keep the exact failure return")
    else:
        tr.replace("ap.add_argument('--output', required=True)", "ap.add_argument('--output', default=None)", "canonical_cli", "Make the unused output destination optional for canonical no-argument execution")
        tr.replace("    Path(args.output).write_text(json.dumps(result,indent=2)+'\\n')", "    # Publication suppresses the named-result write only; the complete result and all active mutation branches remain computed.", "suppress_output_side_effect", "Suppress only JSON output; preserve every original predicate, result, threshold and active CLI branch")
        anchor = "    return int(failed!=0)"
        output += "    print(" + repr(scope) + ")\n"
        tr.replace(anchor, output + anchor, "scoped_output", "Append finite-scope output after the original total and preserve the exact failure return")
    data, row = tr.finish("primary", "scripts/" + sp["runner"])
    compile(data, row["publication_path"], "exec")
    return data, row


outputs = []
for sp in CONFIG["specs"]:
    for data, row in [note(sp), primary(sp)]:
        path = Q / "previews" / row["publication_path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        source = Path(row["source_path"]).read_text().splitlines(keepends=True)
        diff = "".join(difflib.unified_diff(source, data.decode().splitlines(keepends=True), fromfile=row["source_path"], tofile=row["publication_path"]))
        (Q / "previews" / (Path(row["publication_path"]).name + ".diff")).write_text(diff)
        outputs.append(row)
by_target = {row["publication_path"]: row for row in outputs}
for sp in CONFIG["specs"]:
    for dep in sp["dependencies"]:
        if dep.get("publication_target"):
            dep["sha256"] = by_target["docs/" + dep["note"]]["publication_sha256"]
(Q / "SPECIFICATIONS.json").write_text(json.dumps(CONFIG, indent=2, ensure_ascii=False) + "\n")
mapping = {"packet": PACKET, "base_policy": CONFIG["base_policy"], "mathematical_changes": [],
           "pairing": PAIRING, "outputs": outputs,
           "execution_status": "Prepared by literal source mapping and compile-only syntax checks; no helper or preparation script executed"}
(Q / "TRANSFORM_PLANS.json").write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"outputs": len(outputs), "administrative_edits": sum(len(r["edits"]) for r in outputs),
                  "source_proof_edits": 0, "worktree_files_written": 0, "science_or_preparation_executed": False}, indent=2))
