"""Capture exact identities and existing control specifications to this scratch directory.

Bookkeeping only: never import a helper/preparation script, run science, invoke
Git, or write a worktree. Counts below are derived from preserved result data.
"""
import ast
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "scattering_worktree"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(relative):
    return json.loads((S / relative).read_text())


def bind(path):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError("Missing or nonregular input: " + str(path))
    data = path.read_bytes()
    return {"original": str(path), "bytes": len(data), "sha256": sha(data)}


def literal_assignment(path, name):
    matches = [n for n in ast.walk(ast.parse(path.read_text()))
               if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    if len(matches) != 1:
        raise RuntimeError("Ambiguous literal assignment: " + name)
    return ast.literal_eval(matches[0].value)


def cli_variants(path):
    matches = [n for n in ast.walk(ast.parse(path.read_text())) if isinstance(n, ast.Call)
               and isinstance(n.func, ast.Attribute) and n.func.attr == "add_argument"
               and n.args and isinstance(n.args[0], ast.Constant) and n.args[0].value == "--mutation"]
    if len(matches) != 1:
        raise RuntimeError("Ambiguous mutation CLI")
    choices = next(kw.value for kw in matches[0].keywords if kw.arg == "choices")
    return [x for x in ast.literal_eval(choices) if x != "none"]


config = json.loads((Q / "SPECIFICATIONS.json").read_text())
config["observed_dependency_revision_reported_by_root"] = "3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe"
config["base_policy"] = "Explicit --base is required at execution, HEAD must equal it, and every frozen dependency/instruction byte must still match. No Git lookup was performed by preparation."
for sp in config["specs"]:
    helper = S / sp["folder"] / sp["helper"]
    if bind(helper)["sha256"] != sp["helper_sha"]:
        raise RuntimeError("Primary identity changed")
    if sp["baseline_result"]:
        result = read(sp["baseline_result"])
        passed = result.get("passed", result.get("summary", {}).get("passed"))
        failed = result.get("failed", result.get("summary", {}).get("failed"))
        source_pin = result.get("source_sha256")
        if sp["key"] == "Integrated_boost":
            source_pin = next(r["sha256"] for r in read(sp["baseline_receipt"])["sources"] if r["path"] == str(helper))
        if passed + failed != len(result["rows"]) or failed != 0 or source_pin != sp["helper_sha"]:
            raise RuntimeError("Baseline source/row binding mismatch")
        sp["baseline_totals"] = {"passed": passed, "failed": failed, "semantics": "Original finite predicates"}
    else:
        records = [json.loads(line) for line in (S / sp["baseline_stdout"]).read_text().splitlines()]
        if records[-1].get("status") != "complete":
            raise RuntimeError("Fock completion record mismatch")
        sp["baseline_totals"] = {"passed": 1, "failed": 0, "semantics": "One completed assertion-guarded driver, not a predicate count", "original_json_records": len(records)}
    sp["baseline_scientific_stdout_policy"] = "Every original stdout byte is retained as an exact prefix; only the exact mapped N5/scope/completion suffix may follow. No original scientific row, threshold or failure gate changes."
    mutations = []
    if sp["key"] in {"Boost", "Gapped", "Integrated_boost"}:
        sp["mutation_kind"] = "original_cli_variant"
        sp["mutation_authority"] = str(helper.relative_to(S))
        for name in cli_variants(helper):
            if sp["key"] == "Boost":
                result_path = sp["folder"] + "/finite_controls.final." + name + ".json"
                stem = sp["folder"] + "/logs/final." + name
            elif sp["key"] == "Gapped":
                result_path = sp["folder"] + "/mutations/final_" + name + ".json"
                stem = sp["folder"] + "/logs/final_mutant_" + name
            else:
                result_path = sp["folder"] + "/final_" + name + ".json"
                stem = sp["folder"] + "/logs/final_" + name
            result = read(result_path)
            receipt_path = stem + ("/receipt.json" if sp["key"] == "Integrated_boost" else ".receipt.json")
            receipt = read(receipt_path)
            source_pin = result.get("source_sha256")
            if sp["key"] == "Integrated_boost":
                source_pin = next(r["sha256"] for r in receipt["sources"] if r["path"] == str(helper))
            if source_pin != sp["helper_sha"] or result["mutation"] != name:
                raise RuntimeError("Original CLI source mismatch")
            mutations.append({
                "name": name, "argv": ["--mutation", name], "original_result": result_path,
                "original_receipt": receipt_path, "original_stdout": stem + ("/stdout.txt" if sp["key"] == "Integrated_boost" else ".stdout"),
                "original_stderr": stem + ("/stderr.txt" if sp["key"] == "Integrated_boost" else ".stderr"), "expected_passed": result["passed"],
                "expected_failed": result["failed"], "expected_exit": receipt["exit_code"],
                "original_timeout_seconds": receipt.get("timeout_seconds", receipt.get("declared_timeout_seconds")),
                "original_elapsed_seconds": receipt["elapsed_seconds"], "original_timed_out": receipt["timed_out"],
                "survived": receipt["exit_code"] == 0,
            })
    elif sp["key"] == "Nonisolated_fock":
        sp["mutation_kind"] = "entire_source_copy_literal_edits"
        sp["mutation_authority"] = "nonisolated_fock_review/run_author_mutations.py"
        definitions = literal_assignment(S / sp["mutation_authority"], "cases")
        results = read("nonisolated_fock_review/author_mutations.json")
        if results["author_source_sha256"] != sp["helper_sha"] or len(results["cases"]) != len(definitions):
            raise RuntimeError("Fock mutation authority mismatch")
        for (name, before, after, count), row in zip(definitions, results["cases"]):
            if (name, before, after, count) != (row["name"], row["before"], row["after"], row["replacements"]):
                raise RuntimeError("Fock mutation definition drift")
            source = helper.read_text()
            if source.count(before) != count:
                raise RuntimeError("Fock mutation anchor mismatch")
            mutant = S / sp["review"] / "mutations" / (name + ".py")
            if source.replace(before, after).encode() != mutant.read_bytes() or sha(mutant.read_bytes()) != row["source_sha256"]:
                raise RuntimeError("Fock full mutated source mismatch")
            mutations.append({
                "name": name, "before": before, "after": after, "replacements": count,
                "original_source": str(mutant.relative_to(S)), "original_source_sha256": row["source_sha256"],
                "original_receipt": sp["review"] + "/mutations/" + name + ".execution.json",
                "original_stdout": str(Path(row["streams"]["stdout"]["path"]).relative_to(S)),
                "original_stderr": str(Path(row["streams"]["stderr"]["path"]).relative_to(S)),
                "expected_exit": row["returncode"], "survived": row["survived"],
                "original_timed_out": row["timed_out"], "original_timeout_seconds": row["timeout_seconds"],
                "original_elapsed_seconds": row["elapsed_seconds"],
            })
    else:
        sp["mutation_kind"] = "entire_source_copy_literal_edits"
        sp["mutation_authority"] = "weighted_current_closure/controls/run_controls.py"
        definitions = literal_assignment(S / sp["mutation_authority"], "mutations")
        results = read("weighted_current_closure/logs/final_execution_summary.json")
        if len(definitions) != len(results["mutations"]):
            raise RuntimeError("Weighted mutation authority mismatch")
        for (name, before, after), row in zip(definitions, results["mutations"]):
            source = helper.read_text()
            mutant = S / sp["folder"] / "mutations" / name / "weighted_controls.py"
            if row["mutation"] != name or source.count(before) != 1 or source.replace(before, after, 1).encode() != mutant.read_bytes():
                raise RuntimeError("Weighted full mutated source mismatch")
            mutations.append({
                "name": name, "before": before, "after": after, "replacements": 1,
                "original_source": str(mutant.relative_to(S)), "original_source_sha256": row["source_sha256"],
                "original_result": str(mutant.with_name("weighted_results.json").relative_to(S)),
                "original_receipt": str(mutant.with_name("execution.json").relative_to(S)),
                "original_stdout": str(mutant.with_name("stdout.jsonl").relative_to(S)),
                "original_stderr": str(mutant.with_name("stderr.txt").relative_to(S)),
                "expected_passed": row["summary"]["passed"], "expected_failed": row["summary"]["failed"],
                "expected_exit": row["exit_code"], "survived": row["exit_code"] == 0,
                "original_timed_out": row["timed_out"], "original_timeout_seconds": row["declared_timeout_seconds"],
                "original_elapsed_seconds": row["elapsed_seconds"],
            })
        sp["supplemental_author_helper"] = "weighted_current_closure/controls/matrix_controls.py"
        sp["supplemental_author_result"] = "weighted_current_closure/logs/final_matrix/matrix_results.json"
        matrix = read(sp["supplemental_author_result"])
        sp["supplemental_author_helper_sha256"] = bind(S / sp["supplemental_author_helper"])["sha256"]
        if matrix["source_sha256"] != sp["supplemental_author_helper_sha256"] or sum(matrix["summary"].values()) != len(matrix["rows"]):
            raise RuntimeError("Supplemental source/count mismatch")
        sp["supplemental_author_totals"] = matrix["summary"]
        sp["supplemental_author_policy"] = "Complete distinct occupation-matrix helper and original outputs remain frozen evidence; no second canonical primary, no fresh execution claim."
    if sp["key"] == "Integrated_boost":
        materialization = "integrated_boost_covariance_review/author_replays/source_materialization.json"
        sp["review_materialization_authority"] = materialization
        sp["review_materializations"] = []
        for saved in read(materialization):
            path = Path(saved["source"])
            raw = path.read_bytes()
            if sha(raw) != saved["sha256"]:
                raise RuntimeError("Integrated materialization identity mismatch")
            before = helper.read_text().splitlines(keepends=True)
            after = raw.decode().splitlines(keepends=True)
            if len(before) != len(after):
                raise RuntimeError("Unexpected materialization line change")
            edits = [{"before": a, "after": b, "occurrences": 1} for a, b in zip(before, after) if a != b]
            if len(edits) != (0 if saved["name"] == "baseline" else 6):
                raise RuntimeError("Unexpected active branch materialization")
            text = helper.read_text()
            for edit in edits:
                if text.count(edit["before"]) != 1:
                    raise RuntimeError("Ambiguous materialization edit")
                text = text.replace(edit["before"], edit["after"], 1)
            if text.encode() != raw:
                raise RuntimeError("Materialization does not reconstruct the entire helper")
            sp["review_materializations"].append({**saved, "source": str(path.relative_to(S)), "edits": edits,
                "original_result": str(path.with_suffix(".json").relative_to(S)),
                "original_stdout": sp["review"] + "/author_replays/logs/" + saved["name"] + "/stdout.txt",
                "original_stderr": sp["review"] + "/author_replays/logs/" + saved["name"] + "/stderr.txt",
                "original_receipt": sp["review"] + "/author_replays/logs/" + saved["name"] + "/receipt.json"})
        sp["review_materialization_policy"] = "Original author mutants are active CLI branches; reviewer preserves baseline bytes and materializes all six operative branch choices into complete helpers. Keep both representations and all full streams; neither changes the original gates."
    for mutation in mutations:
        for field in ["original_source", "original_result", "original_receipt", "original_stdout", "original_stderr"]:
            if field in mutation:
                mutation[field + "_sha256"] = bind(S / mutation[field])["sha256"]
    sp["mutations"] = mutations
    sp["mutation_count"] = len(mutations)
    sp["expected_mutation_survivors"] = [row["name"] for row in mutations if row["survived"]]
    sp["mutation_policy"] = "Preserve the entire original helper and all original edits/CLI choices, gates, survivors, full stdout/stderr and observed timeout/timing. Do not convert survivor output drift into a passing sensitivity claim. Traceback line relocation is administrative and must be explicitly mapped."
    independent_result = {
        "Boost": "microscopic_boost_flow_review/independent.canonical.json",
        "Gapped": "gapped_boost_invariance_review/independent_controls.result.json",
        "Nonisolated_fock": None,
        "Weighted_current": "weighted_current_closure_review/independent_run1/results.json",
        "Integrated_boost": "integrated_boost_covariance_review/canonical.json",
    }[sp["key"]]
    sp["independent_result"] = independent_result
    if independent_result:
        independent = read(independent_result)
        sp["independent_recorded_rows"] = len(independent["rows"])
        sp["independent_recorded_failed"] = independent.get("failed", independent.get("fail_count", independent.get("fail")))
        sp["independent_row_semantics"] = "Existing distinct finite control rows; not a proof or model-independence grade"
    else:
        records = [json.loads(line) for line in (S / sp["independent_stdout"]).read_text().splitlines()]
        sp["independent_recorded_rows"] = len(records)
        sp["independent_row_semantics"] = "Existing optimized-driver JSON records, not a predicate count; the initial timeout and partial records remain preserved"
    for field in ["source", "report", "baseline_stdout", "root_coverage", "root_evidence_verification", "independent_stdout", "independent_result"]:
        if sp.get(field):
            sp[field + "_sha256"] = bind(S / sp[field])["sha256"]

papers = {}
for key, identifier, local, expected in [
    ("TWW", "2511.02941v2", "microscopic_boost_flow/sources/TWW_main.tex", "bd67842f411193b3727a1d90aa7c47573c1db63e4b58a3a8d8bcf57ad5d4be0d"),
    ("NSY", "1705.08553v3", "microscopic_boost_flow/sources/NSY_1705.08553v3.tex", "291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722"),
    ("Dybalski", "hep-th/0412226v4", "nonisolated_fock/sources/09_Dybalski_hep-th_0412226v4.tex", "c425cfecc20136576180271a1e8e9c12df48ded2ae941655ad4e842363ee64a6"),
    ("BDN", "1412.2970v2", "nonisolated_fock/sources/10_BDN_1412.2970v2.pdf", "3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126"),
    ("NS", "0712.3318v1", "nonisolated_fock/sources/11_NS_0712.3318v1.pdf", "74829f87cc51d399613043a3abdc48ba3146c81292a09e4df1035b50eb464b5c"),
]:
    row = bind(S / local)
    if row["sha256"] != expected:
        raise RuntimeError("Primary-paper byte mismatch: " + key)
    papers[key] = {"source_id": key, "version": identifier,
                   "abstract_url": "https://arxiv.org/abs/" + identifier,
                   "pdf_url": "https://arxiv.org/pdf/" + identifier,
                   "source_url": "https://arxiv.org/src/" + identifier,
                   "bound_primary_local_file": row,
                   "scope": "Frozen source provenance only; preparation makes no new paper-read or network-retrieval claim"}
acquisition = read("integrated_boost_covariance/sources/Engel_Nagel_acquisition.json")
engel = bind(S / "integrated_boost_covariance/sources/Engel_Nagel_One_Parameter_Semigroups.pdf")
if engel["sha256"] != acquisition["sha256"]:
    raise RuntimeError("Engel-Nagel source binding mismatch")
papers["Engel_Nagel"] = {"source_id": "Engel_Nagel", "version": "Hash-bound publisher-hosted PDF acquired " + acquisition["acquired_utc"] + "; edition not independently inferred by preparation",
    "pdf_url": acquisition["url"], "source_url": acquisition["url"], "bound_primary_local_file": engel,
    "scope": acquisition["coverage"] + " Preparation did not read or download the paper."}


def classify(path):
    rel = path.relative_to(S)
    parts = rel.parts
    key = None
    if "BDN_pages" in parts or path.name in {"10_BDN_1412.2970v2.pdf", "BDN_page41.png"}:
        key = "BDN"
    elif "NS_pages" in parts or path.name in {"11_NS_0712.3318v1.pdf", "NS_page10.png"}:
        key = "NS"
    elif path.name in {"TWW_main.tex", "TWW_common.tex"}:
        key = "TWW"
    elif path.name in {"NSY_1705.08553v3.tex", "NSY_1705.08553v3.source", "NSY.tex"}:
        key = "NSY"
    elif path.name == "09_Dybalski_hep-th_0412226v4.tex":
        key = "Dybalski"
    elif path.name in {"Engel_Nagel_One_Parameter_Semigroups.pdf", "Engel_Nagel_page_145.txt"}:
        key = "Engel_Nagel"
    if key:
        paper = papers[key]
        return {"classification": "external_primary_content", "source_id": key,
                "version": paper["version"], "source_url": paper["source_url" if path.suffix in {".tex", ".source"} else "pdf_url"],
                "upstream_primary_sha256": paper["bound_primary_local_file"]["sha256"],
                "disposition": "Inventoried only; raw paper, extraction and rendered bytes stay external and are not deleted"}
    if path.suffix.lower() in {".pdf", ".tex", ".sty", ".bib", ".source", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".tar", ".gz", ".html"}:
        raise RuntimeError("Unclassified possible external content: " + str(path))
    if path.suffix == ".txt" and not any(token in path.name.lower() for token in ["stdout", "stderr"]) and not rel.parts[0].startswith("Integrated_boost_root_"):
        raise RuntimeError("Unclassified text extraction: " + str(path))
    return {"classification": "own_or_repository_evidence", "preserved": "evidence/" + str(rel) + ".gz"}


paths = set()
membership = {}
excluded = []
root_membership = {}
for sp in config["specs"]:
    for name in [sp["source"], sp["report"]]:
        paths.add(S / name)
    for folder in [sp["folder"], sp["review"]]:
        members = []
        for path in sorted((S / folder).rglob("*")):
            if path.is_symlink():
                raise RuntimeError("Symlink in source bundle: " + str(path))
            if not path.is_file():
                continue
            if "__pycache__" in path.parts or path.name == ".DS_Store":
                excluded.append({"original": str(path), "reason": "Transient bytecode or desktop metadata; complete own source files remain included"})
                continue
            members.append(str(path.relative_to(S)))
            paths.add(path)
        membership[folder] = members
    pattern = sp["key"] + "_root_*"
    selected_root_files = []
    for root_path in S.glob(pattern):
        candidates = [root_path] if root_path.is_file() else list(root_path.rglob("*"))
        for path in candidates:
            if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
                selected_root_files.append(str(path.relative_to(S)))
    root_membership[pattern] = sorted(selected_root_files)
    paths.update(S / name for name in root_membership[pattern])
    for dep in sp["dependencies"]:
        if dep.get("publication_target"):
            if bind(S / dep["original_source"])["sha256"] != dep["original_source_sha256"]:
                raise RuntimeError("New same-packet dependency original mismatch")
        elif bind(W / "docs" / dep["note"])["sha256"] != dep["sha256"]:
            raise RuntimeError("Dependency identity changed: " + dep["note"])
    for field, pin in [("source", "source_sha"), ("report", "report_sha")]:
        if bind(S / sp[field])["sha256"] != sp[pin]:
            raise RuntimeError("Frozen note/report mismatch")
paths.update(S / name for name in [
    "verify_boost_source_evidence.py", "verify_gapped_source_evidence.py",
    "verify_nonisolated_fock_evidence.py", "verify_weighted_current_review_evidence.py",
    "verify_integrated_boost_author_evidence.py", "verify_integrated_boost_review_evidence.py",
    "repo_sync_0740.json",
    "prepare_regularity_joint_publication.py",
])
rows = [{**bind(path), **classify(path)} for path in sorted(paths)]
worktree_paths = {
    "AGENTS.md", "docs/ai_methodology/SCIENCE_WORKFLOW.md",
    "docs/ai_methodology/REVIEW_LOOP_PR_CONFORMANCE_SPEC.md",
    "docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md",
    "docs/ai_methodology/skills/physics-loop/references/DELIVERY.md",
    "docs/ai_methodology/skills/physics-loop/references/CLAIM_STATUS.md",
    "docs/ai_methodology/skills/review-loop/references/FIXES_AND_REPORTING.md",
    "docs/ai_methodology/skills/workhorse/SKILL.md",
    ".claude/science/physics-loops/toe-regularity-joint-flow-20261012/reconstruct.py",
}
worktree_paths.update("docs/" + d["note"] for sp in config["specs"] for d in sp["dependencies"] if not d.get("publication_target"))
for rel in sorted(worktree_paths):
    rows.append({**bind(W / rel), "classification": "own_or_repository_evidence", "worktree_relative": rel, "preserved": "evidence/consulted_worktree/" + rel + ".gz"})
skill = Path("/Users/jonreilly/.codex/skills/ai-physics-lane-builder/SKILL.md")
rows.append({**bind(skill), "classification": "own_or_repository_evidence", "preserved": "evidence/consulted_skill/ai-physics-lane-builder/SKILL.md.gz"})
inventory = {
    "base_policy": config["base_policy"], "observed_dependency_revision_reported_by_root": config["observed_dependency_revision_reported_by_root"],
    "capture_scope": "Read-only identities for all ten named source bundles, five original probes/reviews, all selected root coverage/evidence files and named instruction/dependency/pattern inputs. No science execution, Git operation, new proof review or worktree write.",
    "files": rows, "source_directory_membership": membership,
    "root_evidence_glob_membership": root_membership,
    "external_reference_sources": list(papers.values()), "excluded_transient_files": excluded,
}
for name, data in [("SPECIFICATIONS.json", config), ("INPUT_INVENTORY.json", inventory)]:
    (Q / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"input_files": len(rows), "own": sum(r["classification"] == "own_or_repository_evidence" for r in rows),
                  "external": sum(r["classification"] == "external_primary_content" for r in rows),
                  "mutations": {sp["key"]: {"count": sp["mutation_count"], "survivors": sp["expected_mutation_survivors"]} for sp in config["specs"]},
                  "worktree_files_written": 0, "science_or_preparation_executed": False}, indent=2))
