"""Syntax, anchor, source-map and AST comparison only; no target code execution.

This reads the unexecuted preparation script and prepared helper previews as
text/AST. It never imports them, invokes Git or writes a worktree. Its only
output file is STATIC_CHECKS.json in this preparation directory.
"""
import ast
import hashlib
import json
import posixpath
import re
from pathlib import Path
from urllib.parse import unquote

Q = Path(__file__).resolve().parent
S = Q.parent
script = S / "prepare_boost_gap_fock_closure_publication.py"
specification = json.loads((Q / "SPECIFICATIONS.json").read_text())
inventory = json.loads((Q / "INPUT_INVENTORY.json").read_text())
mapping = json.loads((Q / "TRANSFORM_PLANS.json").read_text())
templates = json.loads((Q / "PACKET_TEMPLATES.json").read_text())
packet = specification["packet"]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class NormalizeAdministrativeAST(ast.NodeTransformer):
    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {"AUDIT_TIMEOUT_SEC", "AUDIT_INPUT_PATHS"}:
            return None
        return self.generic_visit(node)

    def visit_If(self, node):
        if ast.dump(node.test) == "UnaryOp(op=Not(), operand=Name(id='__debug__', ctx=Load()))":
            require(len(node.body) == 1 and isinstance(node.body[0], ast.Raise), "Unexpected assertion guard body")
            return None
        return self.generic_visit(node)

    def visit_Expr(self, node):
        call = node.value
        if isinstance(call, ast.Call):
            if isinstance(call.func, ast.Attribute) and call.func.attr in {"write_text", "mkdir"}:
                return None
            if isinstance(call.func, ast.Name) and call.func.id == "print":
                strings = [n.value for n in ast.walk(call) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
                if any(value.startswith(("per_element:", "per_site:", "per_mode:", "per_block:", "lattice_wide:", "SCOPE:", "TOTAL:")) for value in strings):
                    return None
        return self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr == "add_argument" and node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == "--output":
            node.keywords = [kw for kw in node.keywords if kw.arg not in {"required", "default"}]
        return self.generic_visit(node)


def scientific_ast(text):
    return ast.dump(NormalizeAdministrativeAST().visit(ast.parse(text)), include_attributes=False)


def math_blocks(text):
    pattern = r"\\\[.*?\\\]|\\\(.*?\\\)|(?<!\\)\$\$.*?(?<!\\)\$\$|(?<![\\$])\$(?!\$).*?(?<![\\$])\$(?!\$)"
    return re.findall(pattern, text, flags=re.S)


def links(text):
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    for block in math_blocks(text):
        text = text.replace(block, "")
    text = re.sub(r"`[^`\n]*`", "", text)
    return re.findall(r"(?<!!)\[[^\]\n]*\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)", text)


syntax = []
for path in [script, *sorted(Q.glob("*.py")), *sorted((Q / "previews/scripts").glob("*.py"))]:
    compile(path.read_bytes(), str(path), "exec")
    syntax.append(str(path.relative_to(S)))
available = {row["publication_path"] for row in mapping["outputs"]}
available.update(row["worktree_relative"] for row in inventory["files"] if "worktree_relative" in row)
available.update(packet + "/" + row["preserved"] for row in inventory["files"] if "preserved" in row)
available.update(packet + "/" + name for name in templates)
available.update(packet + "/" + name for name in ["EVIDENCE_MAP.json", "PUBLICATION_EDITS.json", "reconstruct.py", "SPECIFICATIONS.json", "INPUT_INVENTORY.json", "EXTERNAL_SOURCE_INVENTORY.json", "SOURCE_IDENTITIES.json", "PREPARATION_RECEIPT.json"])
records = []
for row in mapping["outputs"]:
    original = Path(row["source_path"]).read_bytes()
    require(sha(original) == row["source_sha256"], "Original source drift")
    text = original.decode()
    for edit in row["edits"]:
        require(edit["occurrences"] == 1 and text.count(edit["before"]) == 1, "Ambiguous original anchor")
        text = text.replace(edit["before"], edit["after"], 1)
    body = text
    text += row["appended_text"]
    preview = (Q / "previews" / row["publication_path"]).read_bytes()
    require(text.encode() == preview and sha(preview) == row["publication_sha256"] and len(preview) == row["publication_bytes"], "Complete forward reconstruction failed")
    reverse = body
    for edit in reversed(row["edits"]):
        require(reverse.count(edit["after"]) == 1, "Ambiguous reverse anchor")
        reverse = reverse.replace(edit["after"], edit["before"], 1)
    require(reverse.encode() == original, "Complete reverse recovery failed")
    result = {"path": row["publication_path"], "source_sha256": row["source_sha256"], "publication_sha256": row["publication_sha256"],
              "exact_forward_and_reverse_reconstruction": True, "administrative_edits": len(row["edits"])}
    if row["kind"] == "primary":
        require(scientific_ast(original.decode()) == scientific_ast(text), "Nonadministrative Python AST changed: " + row["publication_path"])
        result["complete_ast_equal_after_only_documented_declarations_cli_io_scope_normalization"] = True
        result["executed"] = False
    else:
        require(math_blocks(original.decode()) == math_blocks(body), "Original displayed/inline mathematics changed")
        require("**Author/checker pairing:** Same selected model family in separate author/reviewer contexts" in text, "Missing explicit same-family separate-context disclosure")
        dependency_links = set()
        for target in links(text):
            if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target) or target.startswith("#"):
                continue
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(row["publication_path"]), unquote(target.split("#", 1)[0])))
            require(resolved in available, "Dangling prepared local link: " + resolved)
            if resolved.startswith("docs/") and resolved.endswith(".md"):
                dependency_links.add(resolved.removeprefix("docs/"))
        sp = next(s for s in specification["specs"] if "docs/" + s["note"] == row["publication_path"])
        require(dependency_links == set(sp["prerequisites"]), "Readable proof links differ from explicit dependency scope")
        result["original_math_blocks_preserved"] = len(math_blocks(original.decode()))
        result["direct_proof_links"] = sorted(dependency_links)
        result["math_aware_local_links_resolve_against_proposed_payload"] = True
    records.append(result)

# Inspect the executable's interface and dangerous-operation boundary as AST;
# do not call main, an argument parser, a payload builder or a target helper.
tree = ast.parse(script.read_text())
parser_calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == "add_argument" and node.args]
arguments = {ast.literal_eval(call.args[0]): {kw.arg: ast.literal_eval(kw.value) for kw in call.keywords if kw.arg == "required"} for call in parser_calls}
require(arguments == {"--worktree": {"required": True}, "--base": {"required": True}}, "Required explicit interface changed")
require(not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in {"eval", "exec", "__import__"} for n in ast.walk(tree)), "Unexpected dynamic execution")
subprocess_calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == "subprocess"]
require(len(subprocess_calls) == 1 and subprocess_calls[0].func.attr == "run", "Unexpected subprocess surface")
require('[["rev-parse", "--show-toplevel"], ["rev-parse", "--verify", "HEAD"], ["status", "--porcelain=v1", "--untracked-files=all"]]' in script.read_text(), "Read-only Git whitelist changed")
require('with path.open("xb")' in script.read_text() and 'absent_targets(worktree, payload, specification)' in script.read_text(), "Create-only guard missing")

import yaml  # Parse metadata only; no helper or publication-script import.
state = yaml.safe_load(templates["STATE.yaml"].replace("@BASE@", "3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe").replace("@WORKTREE@", "/explicit/runtime/checkout"))
require(state["target_claim_type"] == "bounded_theorem" and state["actual_current_surface_status"] == "conditional-support", "Invalid state metadata")
for sp in specification["specs"]:
    text = (Q / "previews/docs" / sp["note"]).read_text()
    head = yaml.safe_load(text.split("---\n", 2)[1])
    require(head["upstream_dependencies"] == sp["deps"] and head["runner"] == "scripts/" + sp["runner"], "Canonical header mismatch")
    require(head["claim_type"] == "bounded_theorem" and head["actual_current_surface_status"] == "conditional-support", "Canonical status mismatch")
    for dep in sp["dependencies"]:
        if dep.get("publication_target"):
            require(sha((Q / "previews/docs" / dep["note"]).read_bytes()) == dep["sha256"], "Same-packet dependency drift")

report = {
    "scope": "Read-only source/AST/metadata validation and scratch report; no preparation-script/helper import or execution, Git command or worktree write",
    "pairing": mapping["pairing"], "syntax_checked_sources": syntax, "outputs": records,
    "source_proof_edits": 0, "direct_dependency_edges_proposed": sum(len(sp["deps"]) for sp in specification["specs"]),
    "original_mutation_cases_derived_from_sources": sum(len(sp["mutations"]) for sp in specification["specs"]),
    "known_survivors_preserved": {sp["key"]: sp["expected_mutation_survivors"] for sp in specification["specs"]},
    "source_files_bound": len(inventory["files"]), "external_files_not_bundled": sum(row["classification"] == "external_primary_content" for row in inventory["files"]),
    "required_worktree_and_base_arguments_checked_as_source": True, "runtime_preconditions_not_executed": True,
    "canonical_science_not_run": True, "preparation_script_not_executed": True, "worktree_files_written": 0,
    "remaining": "Root must read the complete instantiated changes, execute preparation/controls, preserve full raw API results, verify mutations/graph/compatibility and complete metadata/manifests/publication.",
}
(Q / "STATIC_CHECKS.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"syntax_sources": len(syntax), "outputs": len(records), "administrative_edits": sum(r["administrative_edits"] for r in records),
                  "direct_edges": report["direct_dependency_edges_proposed"], "mutations": report["original_mutation_cases_derived_from_sources"],
                  "science_or_preparation_executed": False, "worktree_files_written": 0}, indent=2))
