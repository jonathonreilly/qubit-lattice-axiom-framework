This is an unexecuted, source-frozen verification program for root review.

Run `verify_boost_gap_fock_closure_publication.py` with explicit `--worktree`
and `--base`. The reviewed target is
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/microscopic_boost_worktree`
at `3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe`. Use the Python environment
matching the original recorded versions; version fields are compared exactly.
The script refuses existing canonical caches and out-of-scope candidate paths.

Each invocation creates a unique `runs/` directory here. No earlier attempt,
original evidence, prompt, Git reference or index is overwritten. The requested
cache/graph tools have their ordinary repository outputs. Vocabulary `--fix`
is allowed only if its checked report and subsequent reconstruction establish
zero changes; a changed source fails closed before caching. `--report-only`
and another reconstruction follow. The existing vocabulary tool deliberately
skips `.claude/` paths; the packet is separately hash-bound and metadata/link
checked, rather than claimed to have received unsupported vocabulary coverage.

Five canonical cache runs and all 32 original whole-primary CLI/literal cases
are planned, exactly once. There is no new independent-control run. Fock has
four expected surviving mutations: drop_volume_growth, drop_one_relative_count,
incorrect_contraction_exponent and incorrect_tail_margin. Fock's appended
TOTAL counts one completed assertion driver, not the number of predicates.
All scientific stdout bytes are compared; only the exact source-mapped scope
suffix is appended. Original failure gates, full streams, observed original
timeouts/timings and full new timing/timeout records remain visible. Frozen
whole-source mutant specimens are included for root's pre-execution review.

The observation shim records the existing `result` or `output` dictionary at
the exact pinned `main` return. It uses `sys.setprofile`, does not alter frame
locals, branches, exceptions, streams or exit status, and catches recording
errors separately. A temporary in-memory Popen wrapper preserves the canonical
API's exact command/cwd/redirection and adds only the frozen shim path and four
target selectors to that subprocess's environment. Mutant commands are likewise
bound to their complete source specimens. The profiler adds execution overhead;
new timings are observations, not original timings or performance measurements.
Fock has no original result dictionary and needs no observer: its complete
seven-record baseline JSON stdout is the original calculation artifact.

Every suppressed result object is preserved as full JSON. Only its original
timestamp field and computed source self-hash may differ, with exact before/
after maps and time bounds. All other fields, versions, densities, residuals,
rows, thresholds, totals and gates are compared without numeric tolerances.
The canonical cache API merges stderr into stdout. Its entire INNER return is
saved immediately before outer identity checks, then its entire OUTER tuple is
saved immediately before inspection/cache checks. Raw pickle retains exact
Python container types; tagged JSON retains every readable field. The verifier
never loads pickle. Live logs and complete uncapped streams are also preserved.

Integrated's six existing whole-helper materializations are reconstructed and
copied with their full old results, streams and receipts. Their old outputs are
compared to the active original CLI variants. They are not freshly rerun and are
not counted as extra independence. All other original own evidence, including
failed and corrected attempts, remains hash-bound through the entire packet.
External literature stays in the existing source/version/hash/URL inventory.

The graph check compares every old node's topology against the exact-base
tracked manifest and requires precisely five added nodes and eight declared
direct edges. No old graph payload was present in this checkout, so it does not
claim a payload-level old-node comparison. Git scope checks protect unchanged
old source surfaces. Focused audit-system compatibility is exact-base and
reports the ledger rows it actually selects; it grants no new claim grade.
Global combined audit and strict audit lint remain separate landing gates.

Same selected model family in separate author/reviewer contexts; candidate
formulas and results were visible. This is neither blinded nor cross-family
checking. Root is a coauthor, not the independent reviewer. Mechanical
preservation is not a new proof review or retained status. Final publication
metadata, evidence integration and Git/publication remain root-owned.

Preparation performed only AST/syntax, source/anchor, metadata and hash checks.
It executed no verifier, shim, primary, mutation, independent helper, vocabulary
tool, graph builder, audit compatibility tool or Git command. Editable prompt
files changed: none. The initial exact-wording pairing-check failure and the
unexecuted initial verifier are preserved under `preparation_recovery/`.
