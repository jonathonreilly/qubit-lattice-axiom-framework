"""Deterministic source-only preparation; never import or execute the verifier.

Reads/AST-parses frozen sources, copies bookkeeping, and writes only the allowed
verification preparation folder plus the verifier's embedded freeze hash.
"""
import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import textwrap

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "microscopic_boost_worktree"
P = W / ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012"
VERIFIER = S / "verify_boost_gap_fock_closure_publication.py"
BASE = "3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def js(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def descriptor(root, path, folder):
    data = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(root=root, path=str(path.relative_to(folder)), bytes=len(data), sha256=sha(data))


specs = js(P / "SPECIFICATIONS.json")["specs"]
maps = js(P / "PUBLICATION_EDITS.json")["outputs"]
emap = {str(Path(r["original"]).relative_to(S)) if Path(r["original"]).is_relative_to(S) else r["original"]: r
        for r in js(P / "EVIDENCE_MAP.json")["files"]}


def original(rel):
    r = emap[rel]
    packed = (P / r["preserved"]).read_bytes()
    assert sha(packed) == r["compressed_sha256"]
    data = gzip.decompress(packed)
    assert sha(data) == r["sha256"] and len(data) == r["bytes"]
    return data


baselines = {
    "Boost": {"stderr": "microscopic_boost_flow/logs/final.none.stderr", "receipt": "microscopic_boost_flow/logs/final.none.receipt.json"},
    "Gapped": {"stderr": "gapped_boost_invariance/logs/final_baseline.stderr", "receipt": "gapped_boost_invariance/logs/final_baseline.receipt.json"},
    "Nonisolated_fock": {"stderr": "nonisolated_fock/logs/controls_run1.stderr.txt", "receipt": "nonisolated_fock/logs/controls_run1.execution.json"},
    "Weighted_current": {"stderr": "weighted_current_closure/logs/final_sparse/stderr.txt", "receipt": "weighted_current_closure/logs/final_sparse/execution.json"},
    "Integrated_boost": {"stderr": "integrated_boost_covariance/logs/final_baseline/stderr.txt", "receipt": "integrated_boost_covariance/logs/final_baseline/receipt.json"},
}
case_inventory, traceback_maps = [], []
for sp in specs:
    row = next(r for r in maps if r["publication_path"] == "scripts/" + sp["runner"])
    source = (W / row["publication_path"]).read_bytes()
    assert sha(source) == row["publication_sha256"]
    compile(ast.parse(source), row["publication_path"], "exec")
    note = (W / "docs" / sp["note"]).read_text()
    assert "**Author/checker pairing:** Same selected model family in separate author/reviewer contexts;" in note
    assert "neither blinded nor cross-family checking" in note and "is a coauthor, not the independent reviewer" in note
    assert original(baselines[sp["key"]]["stderr"]) == b""
    receipt = json.loads(original(baselines[sp["key"]]["receipt"]))
    assert receipt.get("exit_code", receipt.get("returncode")) == 0 and not receipt.get("timed_out", False)
    baselines[sp["key"]]["bindings"] = {kind: sha(original(path)) for kind, path in baselines[sp["key"]].items()}
    scoped = next(e for e in row["edits"] if e["category"] == "scoped_output")
    before, after = ast.parse(textwrap.dedent(scoped["before"])).body, ast.parse(textwrap.dedent(scoped["after"])).body
    if isinstance(before[0], ast.Return):
        assert len(before) == 1 and ast.dump(before[0]) == ast.dump(after[-1])
        printed = after[:-1]
    else:
        assert [ast.dump(n) for n in before] == [ast.dump(n) for n in after[:len(before)]]
        printed = after[len(before):]
    assert all(isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name)
               and n.value.func.id == "print" and len(n.value.args) == 1 and not n.value.keywords for n in printed)
    flag = {"Boost": "passed", "Gapped": "ok", "Weighted_current": "passed", "Integrated_boost": "pass"}.get(sp["key"])
    if flag:
        result = json.loads(original(sp["baseline_result"]))
        assert all(type(r[flag]) is bool for r in result["rows"])
        assert sum(r[flag] for r in result["rows"]) == sp["baseline_totals"]["passed"]
        assert sum(not r[flag] for r in result["rows"]) == sp["baseline_totals"]["failed"]
    else:
        assert len(original(sp["baseline_stdout"]).splitlines()) == sp["baseline_totals"]["original_json_records"] == 7
    primary_original = original(sp["folder"] + "/" + sp["helper"])
    assert sha(primary_original) == sp["helper_sha"]
    for case in sp["mutations"]:
        mutant, old = source.decode(), primary_original.decode()
        if "before" in case:
            assert mutant.count(case["before"]) == old.count(case["before"]) == case["replacements"]
            mutant = mutant.replace(case["before"], case["after"], case["replacements"])
            old = old.replace(case["before"], case["after"], case["replacements"])
            assert old.encode() == original(case["original_source"])
            assert sha(old.encode()) == case["original_source_sha256"]
        specimen = Q / "mutant_specimens" / sp["key"] / (case["name"] + ".py")
        assert specimen.read_bytes() == mutant.encode()
        compile(ast.parse(mutant), str(specimen), "exec")
        r = json.loads(original(case["original_receipt"]))
        assert r.get("exit_code", r.get("returncode")) == case["expected_exit"]
        assert r.get("timed_out", False) == case["original_timed_out"] is False
        assert r.get("timeout_seconds", r.get("declared_timeout_seconds")) == case["original_timeout_seconds"]
        assert r["elapsed_seconds"] == case["original_elapsed_seconds"]
        assert case["survived"] == (case["expected_exit"] == 0)
        if flag:
            result = json.loads(original(case["original_result"]))
            if "source_sha256" in result:
                assert result["source_sha256"] == sha(old.encode())
            assert sum(r[flag] for r in result["rows"]) == case["expected_passed"]
            assert sum(not r[flag] for r in result["rows"]) == case["expected_failed"]
            assert int(case["expected_failed"] != 0) == case["expected_exit"]
        for field in ("original_stdout", "original_stderr", "original_receipt", "original_result"):
            if field in case:
                assert sha(original(case[field])) == case[field + "_sha256"]
        old_lines, new_lines = old.splitlines(), mutant.splitlines()
        line_map = {}
        for block in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_matching_blocks():
            for offset in range(block.size):
                line_map[block.a + offset + 1] = block.b + offset + 1
        for path, line in re.findall(r'File "([^"]+)", line (\d+)', original(case["original_stderr"]).decode()):
            assert path == str(S / case.get("original_source", sp["folder"] + "/" + sp["helper"]))
            assert int(line) in line_map
            traceback_maps.append(dict(key=sp["key"], name=case["name"], original_path=path,
                original_line=int(line), prepared_line=line_map[int(line)], unchanged_line=old_lines[int(line)-1]))
        case_inventory.append(dict(key=sp["key"], name=case["name"], source_sha256=sha(mutant.encode()),
             original_exit=case["expected_exit"], survived=case["survived"], timeout=case["original_timeout_seconds"]))
    for m in sp.get("review_materializations", []):
        mapped = primary_original.decode()
        for edit in m["edits"]:
            assert mapped.count(edit["before"]) == edit["occurrences"]
            mapped = mapped.replace(edit["before"], edit["after"], edit["occurrences"])
        assert mapped.encode() == original(m["source"]) and sha(mapped.encode()) == m["sha256"]
        case = None if m["mode"] == "none" else next(c for c in sp["mutations"] if c["name"] == m["mode"])
        assert original(m["original_stdout"]) == original(sp["baseline_stdout"] if case is None else case["original_stdout"])
        assert json.loads(original(m["original_result"])) == json.loads(original(sp["baseline_result"] if case is None else case["original_result"]))
assert len(case_inventory) == 32 and sum(r["survived"] for r in case_inventory) == 4
write(Q / "VERIFICATION_CONTRACT.json", dict(base_revision=BASE, baselines=baselines,
    planned_canonical_count=len(specs), original_mutant_cases=case_inventory,
    planned_graph_delta=dict(nodes=len(specs), edges=sum(len(s["deps"]) for s in specs)),
    scientific_execution="not_run_by_preparation", pairing="same selected model family, separate contexts, not blinded; root coauthor"))
write(Q / "STATIC_TRACEBACK_MAPS.json", traceback_maps)
verifier_tree = ast.parse(VERIFIER.read_bytes())
compile(verifier_tree, str(VERIFIER), "exec")
canonical_node = next(n for n in verifier_tree.body if isinstance(n, ast.FunctionDef) and n.name == "canonical")
inner_node = next(n for n in canonical_node.body if isinstance(n, ast.FunctionDef) and n.name == "capture_inner")
assert ast.unparse(inner_node.body[0]) == "result = original_execute(*args, **kwargs)"
assert ast.unparse(inner_node.body[1]) == "preserved_return(folder, 'INNER_execute_runner', result)"
outer_node = next(n for n in ast.walk(canonical_node) if isinstance(n, ast.With))
assert ast.unparse(outer_node.body[0]) == "outer = runner_cache.execute_and_write_cache(path, 60)"
assert ast.unparse(outer_node.body[1]) == "preserved_return(folder, 'OUTER_execute_and_write_cache', outer)"
compile(ast.parse((Q / "observation_shim/sitecustomize.py").read_bytes()), str(Q / "observation_shim/sitecustomize.py"), "exec")
write(Q / "STATIC_PREPARATION_CHECKS.json", dict(status="source_only_checks_complete",
    verifier_imported_or_executed=False, shim_imported_or_executed=False, science_executed=False,
    worktree_writes=False, git_commands=False, frozen_mutant_specimens=32, known_original_survivors=4,
    checks=["AST and compile-without-exec", "full literal source mutations including two Fock occurrences",
            "all original receipts/streams/results hashes and derived counts", "unchanged original return gates",
            "all original traceback failing lines preserved", "six Integrated materializations exact",
            "actual note pairing wording", "exact canonical publication hashes",
            "raw INNER capture is the first statement after execute_runner return",
            "raw OUTER capture is the first statement after execute_and_write_cache return"],
    limits=["No runtime result is asserted", "Cache/graph/audit/vocabulary tools remain unexecuted by preparation"],
    editable_prompt_files_changed=[]))

source_paths = {p for p in P.rglob("*") if p.is_file()}
publication_paths = sorted(str(p.relative_to(W)) for p in source_paths | {W / r["publication_path"] for r in maps})
prepared_manifest = js(P / "SOURCE_IDENTITIES.json")
assert sorted([r["path"] for r in prepared_manifest["files"]] + [str((P / "SOURCE_IDENTITIES.json").relative_to(W))]) == publication_paths
for r in prepared_manifest["files"]:
    data = (W / r["path"]).read_bytes()
    assert len(data) == r["bytes"] and sha(data) == r["sha256"]
source_paths.update(W / r["publication_path"] for r in maps)
source_paths.update(W / "docs" / d["note"] for sp in specs for d in sp["dependencies"])
source_paths.update((W / "docs/audit/scripts").rglob("*.py"))
for path in ["AGENTS.md", "scripts/runner_cache.py", "scripts/vocab_lint.py", "docs/repo/controlled_vocabulary.yaml",
             "docs/ai_methodology/SCIENCE_WORKFLOW.md", "docs/ai_methodology/REVIEW_LOOP_PR_CONFORMANCE_SPEC.md",
             "docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md",
             "docs/ai_methodology/skills/physics-loop/references/DELIVERY.md",
             "docs/ai_methodology/skills/physics-loop/references/CLAIM_STATUS.md",
             "docs/ai_methodology/skills/review-loop/references/FIXES_AND_REPORTING.md",
             "docs/ai_methodology/skills/workhorse/SKILL.md", "docs/audit/data/citation_graph_manifest.json",
             "docs/audit/data/doc_authority_registry.json", "docs/audit/data/axiom_premise_nodes.json",
             "docs/audit/data/ledger_meta.json"]:
    assert (W / path).is_file(), path
    source_paths.add(W / path)
assert (Q / "base_graph_manifest.json").read_bytes() == (W / "docs/audit/data/citation_graph_manifest.json").read_bytes()
support_paths = [p for p in Q.rglob("*") if p.is_file() and p.name not in ("SOURCE_FREEZE.json", "FREEZE_RECEIPT.json") and "runs" not in p.relative_to(Q).parts]
research_paths = list((S / "boost_gap_fock_closure_root_preparation_execution").rglob("*"))
rows = [descriptor("worktree", p, W) for p in sorted(source_paths)]
rows += [descriptor("support", p, Q) for p in sorted(support_paths)]
rows += [descriptor("research", p, S) for p in sorted(research_paths) if p.is_file()]
template = re.sub(rb'FREEZE_SHA256 = "[^"]+"', b'FREEZE_SHA256 = "TO_BE_FROZEN"', VERIFIER.read_bytes(), count=1)
freeze = dict(base_revision=BASE, observed_worktree=str(W), source_review_scope="Mechanical preparation only; exact original science reviews and limits remain in the publication packet",
              verifier_template_sha256=sha(template), publication_paths=publication_paths,
              packet_membership=sorted(str(p.relative_to(W)) for p in P.rglob("*") if p.is_file()), files=rows,
              runtime_mutable_exception="Only the explicitly requested tracked graph manifest may change after graph generation; other frozen sources stay exact",
              execution_status="not_run_by_preparation", pairing="same selected model family in separate contexts; not blinded; root coauthor")
write(Q / "SOURCE_FREEZE.json", freeze)
freeze_sha = sha((Q / "SOURCE_FREEZE.json").read_bytes())
VERIFIER.write_bytes(template.replace(b'FREEZE_SHA256 = "TO_BE_FROZEN"', ('FREEZE_SHA256 = "' + freeze_sha + '"').encode(), 1))
compile(ast.parse(VERIFIER.read_bytes()), str(VERIFIER), "exec")
receipt = dict(verifier_sha256=sha(VERIFIER.read_bytes()), freeze_sha256=freeze_sha,
               source_bindings=len(rows), prepared_publication_paths=len(publication_paths),
               full_mutant_specimens=len(case_inventory), known_original_survivors=sum(r["survived"] for r in case_inventory),
               verifier_lines=len(VERIFIER.read_text().splitlines()), execution_status="unexecuted", editable_prompt_files_changed=[])
write(Q / "FREEZE_RECEIPT.json", receipt)
print(json.dumps(receipt))
