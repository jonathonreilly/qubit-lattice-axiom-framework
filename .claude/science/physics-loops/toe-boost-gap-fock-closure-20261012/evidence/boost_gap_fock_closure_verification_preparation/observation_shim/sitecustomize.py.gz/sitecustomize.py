"""Observation only: serialize the existing main-local result on its return.

Loaded only by the verifier's exact-command environment mapping. Never import
this module to prepare or inspect verification. Errors are recorded separately
and do not escape into the observed helper or alter its exit/streams.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback


def _install():
    folder = Path(os.environ["BGC_OBSERVE_FOLDER"])
    target = os.environ["BGC_OBSERVE_TARGET"]
    expected_sha = os.environ["BGC_OBSERVE_SHA256"]
    local_name = os.environ["BGC_OBSERVE_LOCAL"]

    def record(name, value):
        # Exclusive creation prevents overwriting an earlier observation.
        with (folder / name).open("x", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")

    def error(stage):
        try:
            record("observation.error.json", {"stage": stage, "traceback": traceback.format_exc()})
        except Exception:
            pass

    try:
        if sys.argv[0] != target or hashlib.sha256(Path(target).read_bytes()).hexdigest() != expected_sha:
            raise RuntimeError("Observation target/command/source identity mismatch")
        if local_name not in ("result", "output") or sys.getprofile() is not None:
            raise RuntimeError("Unexpected local name or pre-existing profiler")
        record("observation.start.json", {
            "target": target, "target_sha256": expected_sha, "local_name": local_name,
            "argv": sys.argv, "executable": sys.executable,
            "shim_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "environment": {k: os.environ.get(k) for k in (
                "PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "BGC_OBSERVE_FOLDER",
                "BGC_OBSERVE_TARGET", "BGC_OBSERVE_SHA256", "BGC_OBSERVE_LOCAL")},
            "scope": "Existing main-local object observed on return; no value or gate changes",
        })

        def observer(frame, event, argument):
            if event != "return" or frame.f_code.co_filename != target or frame.f_code.co_name != "main":
                return
            # Restore the previous (absent) observer before serializing once.
            sys.setprofile(None)
            try:
                value = frame.f_locals[local_name]
                if type(value) is not dict:
                    raise TypeError("The original result local is not a dictionary")
                record("calculation.raw.json", value)
                record("observation.return.json", {
                    "target": target, "local_name": local_name,
                    "function_first_line": frame.f_code.co_firstlineno,
                    "return_line": frame.f_lineno, "function_return": argument,
                    "calculation_sha256": hashlib.sha256((folder / "calculation.raw.json").read_bytes()).hexdigest(),
                })
            except Exception:
                error("main_return")

        sys.setprofile(observer)
    except Exception:
        error("install")


if "BGC_OBSERVE_FOLDER" in os.environ:
    _install()
