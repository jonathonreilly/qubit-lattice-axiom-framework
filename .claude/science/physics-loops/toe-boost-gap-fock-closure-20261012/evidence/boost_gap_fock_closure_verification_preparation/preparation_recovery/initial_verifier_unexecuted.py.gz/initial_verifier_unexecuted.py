#!/usr/bin/env python3
"""Root-executed, source-frozen five-primary verification; preparation is unexecuted.

No mathematical edits, independent-control reruns, audit verdicts, Git writes,
prompt edits or publication. Requested vocabulary/cache/graph tools write their
normal surfaces. All attempt evidence is created outside the worktree, and an
existing canonical cache is refused to avoid silently repeating execution.
"""
from __future__ import annotations

import argparse
import ast
from contextlib import contextmanager
from datetime import datetime, timezone
import difflib
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pickle
import re
import subprocess
import sys
import textwrap
import time
import traceback
from urllib.parse import unquote
import uuid

S = Path(__file__).resolve().parent
Q = S / "boost_gap_fock_closure_verification_preparation"
PACKET = ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012"
FREEZE_SHA256 = "TO_BE_FROZEN"
PAIRING = "Same selected model family in separate author/reviewer contexts; not blinded or cross-family. Root is a coauthor, not the independent reviewer. This verifier checks mechanical preservation."
GRAPH = "docs/audit/data/citation_graph.json"
GRAPH_MANIFEST = "docs/audit/data/citation_graph_manifest.json"
OBS_KEYS = ("BGC_OBSERVE_FOLDER", "BGC_OBSERVE_TARGET", "BGC_OBSERVE_SHA256", "BGC_OBSERVE_LOCAL")
sys.dont_write_bytecode = True


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def raw(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "Missing or nonregular source: " + str(path))
    return path.read_bytes()


def js(path):
    return json.loads(raw(path))


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def binding(path):
    data = raw(path)
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}


def source_path(row, worktree):
    return {"worktree": worktree, "support": Q, "research": S}[row["root"]] / row["path"]


def check_freeze(freeze, worktree, graph_written=False):
    need(sha(raw(Q / "SOURCE_FREEZE.json")) == FREEZE_SHA256, "Verification freeze drift")
    for row in freeze["files"]:
        if graph_written and row["root"] == "worktree" and row["path"] == GRAPH_MANIFEST:
            continue
        data = raw(source_path(row, worktree))
        need((len(data), sha(data)) == (row["bytes"], row["sha256"]), "Frozen source drift: " + str(row))
    members = sorted(str(p.relative_to(worktree)) for p in (worktree / PACKET).rglob("*") if p.is_file())
    need(members == freeze["packet_membership"], "Packet membership changed")


def preserved_return(folder, stem, value):
    """FIRST operation after each API return: lossless raw object serialization.

    Pickle retains the entire tuple/dict/Path structure; the accompanying tagged
    JSON is a fully readable representation, not an excerpt. Never load pickle.
    """
    (folder / (stem + ".raw.pickle")).write_bytes(pickle.dumps(value, protocol=5))

    def readable(obj):
        if isinstance(obj, Path):
            return {"__type__": type(obj).__name__, "value": str(obj)}
        if isinstance(obj, tuple):
            return {"__type__": "tuple", "items": [readable(x) for x in obj]}
        if isinstance(obj, dict):
            return {k: readable(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [readable(x) for x in obj]
        return obj
    write(folder / (stem + ".raw.json"), readable(value))


def log_run(folder, command, timeout, cwd, env=None):
    folder.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    timed_out, launch_error = False, None
    try:
        run = subprocess.run(command, cwd=cwd, stdin=subprocess.DEVNULL, capture_output=True,
                             timeout=timeout, env=env or {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "GIT_OPTIONAL_LOCKS": "0"})
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", None
        timed_out = True
    except OSError as exc:
        stdout, stderr, code = b"", str(exc).encode(), None
        launch_error = repr(exc)
    elapsed = time.monotonic() - timer
    (folder / "stdout").write_bytes(stdout)
    (folder / "stderr").write_bytes(stderr)
    receipt = {"command": command, "cwd": str(cwd), "started_utc": started,
               "finished_utc": datetime.now(timezone.utc).isoformat(), "timeout_seconds": timeout,
               "elapsed_seconds": elapsed, "exit_code": code, "timed_out": timed_out,
               "launch_error": launch_error, "stdout_bytes": len(stdout), "stderr_bytes": len(stderr),
               "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "pairing": PAIRING}
    write(folder / "execution.json", receipt)
    return receipt, stdout, stderr


def require_exit(receipt, expected=0):
    need(not receipt["timed_out"] and receipt["launch_error"] is None and receipt["exit_code"] == expected,
         "Unexpected result; full streams preserved: " + str(receipt))


def git_read(worktree, run, label, *args):
    receipt, stdout, _ = log_run(run / label, ["git", *args], 60, worktree)
    require_exit(receipt)
    return stdout


def check_scope(worktree, base, run, label, publication_paths, generated=()):
    folder = run / label
    folder.mkdir()
    head = git_read(worktree, folder, "head", "rev-parse", "--verify", "HEAD").decode().strip()
    need(head == base, "HEAD differs from exact supplied base")
    status = git_read(worktree, folder, "status", "status", "--porcelain=v1", "-z", "--untracked-files=all")
    rows = [x.decode() for x in status.split(b"\0") if x]
    need(all(x[:2] in ("??", " A", "A ", " M", "M ") for x in rows), "Unexpected deletion/rename/conflict or mixed index version")
    changed = {x[3:] for x in rows}
    need(changed <= set(publication_paths) | set(generated), "Out-of-scope changed paths: " + repr(sorted(changed - set(publication_paths) - set(generated))))
    need(set(publication_paths) <= changed, "A prepared publication path disappeared from the candidate change set")
    for entry in rows:
        if entry[:2] in ("A ", "M "):
            staged = git_read(worktree, folder, "index_" + sha(entry[3:].encode())[:16], "show", ":" + entry[3:])
            need(staged == raw(worktree / entry[3:]), "Index/worktree version mismatch")
    write(folder / "scope.json", {"base": base, "changed_paths": sorted(changed), "pairing": PAIRING})


class Evidence:
    def __init__(self, packet):
        self.packet = packet
        self.rows = {str(Path(r["original"]).relative_to(S)): r for r in js(packet / "EVIDENCE_MAP.json")["files"]}

    def read(self, relative):
        row = self.rows[relative]
        packed = raw(self.packet / row["preserved"])
        need(sha(packed) == row["compressed_sha256"], "Compressed evidence drift")
        data = gzip.decompress(packed)
        need(len(data) == row["bytes"] and sha(data) == row["sha256"], "Raw evidence drift: " + relative)
        return data

    def json(self, relative):
        return json.loads(self.read(relative))

    def save(self, relative, folder, name):
        data = self.read(relative)
        (folder / name).write_bytes(data)
        return {"original": str(S / relative), "preserved": self.rows[relative]["preserved"],
                "saved": name, "bytes": len(data), "sha256": sha(data)}


def assignment(source, name):
    matches = [n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    need(len(matches) == 1, "Ambiguous literal assignment: " + name)
    return ast.literal_eval(matches[0].value)


def edited(text, before, after, count, label):
    need(text.count(before) == count and count > 0, "Unexpected mutation anchor count: " + label)
    return text.replace(before, after, count)


def apply_publication(original, row):
    need(sha(original) == row["source_sha256"], "Publication source mismatch")
    result = original.decode()
    for edit in row["edits"]:
        result = edited(result, edit["before"], edit["after"], edit["occurrences"], edit["category"])
    result += row["appended_text"]
    need(sha(result.encode()) == row["publication_sha256"], "Publication transformation differs")
    return result.encode()


def totals(sp, result):
    flag = {"Boost": "passed", "Gapped": "ok", "Weighted_current": "passed", "Integrated_boost": "pass"}[sp["key"]]
    rows = result["rows"]
    need(all(type(r[flag]) is bool for r in rows), "Nonboolean original result predicate")
    derived = {"passed": sum(r[flag] for r in rows), "failed": sum(not r[flag] for r in rows)}
    recorded = result["summary"] if sp["key"] == "Weighted_current" else result
    need(all(recorded[k] == v for k, v in derived.items()), "Result summary disagrees with complete predicate rows")
    return derived


def render_expression(node, result):
    # Tiny interpreter restricted to the reviewed appended print expressions.
    if isinstance(node, ast.Constant) and type(node.value) in (str, int):
        return node.value
    if isinstance(node, ast.Name) and node.id == "result":
        return result
    if isinstance(node, ast.Subscript):
        return render_expression(node.value, result)[ast.literal_eval(node.slice)]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return render_expression(node.left, result) + render_expression(node.right, result)
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str" and len(node.args) == 1 and not node.keywords:
        return str(render_expression(node.args[0], result))
    raise RuntimeError("Unmapped administrative output expression: " + ast.dump(node))


def suffix(row, result, completed):
    if not completed:
        return b""
    mappings = [e for e in row["edits"] if e["category"] == "scoped_output"]
    need(len(mappings) == 1 and row["appended_text"] == "", "Ambiguous output source mapping")
    edit = mappings[0]
    before, after = ast.parse(textwrap.dedent(edit["before"])).body, ast.parse(textwrap.dedent(edit["after"])).body
    if len(before) == 1 and isinstance(before[0], ast.Return):
        need(ast.dump(before[0]) == ast.dump(after[-1]), "Failure gate changed")
        prints = after[:-1]
    else:
        need([ast.dump(x) for x in before] == [ast.dump(x) for x in after[:len(before)]], "Fock completion call changed")
        prints = after[len(before):]
    out = []
    for node in prints:
        need(isinstance(node, ast.Expr) and isinstance(node.value, ast.Call), "Output map contains a non-print statement")
        call = node.value
        need(isinstance(call.func, ast.Name) and call.func.id == "print" and len(call.args) == 1 and not call.keywords, "Unexpected mapped print")
        value = render_expression(call.args[0], result)
        need(type(value) is str, "Administrative print is not text")
        out.append(value + "\n")
    return "".join(out).encode()


def compare(folder, label, actual, expected):
    (folder / (label + ".expected")).write_bytes(expected)
    report = {"equal": actual == expected, "actual_bytes": len(actual), "expected_bytes": len(expected),
              "actual_sha256": sha(actual), "expected_sha256": sha(expected)}
    write(folder / (label + ".comparison.json"), report)
    if actual != expected:
        (folder / (label + ".diff")).write_text("".join(difflib.unified_diff(
            expected.decode(errors="replace").splitlines(True), actual.decode(errors="replace").splitlines(True),
            fromfile="frozen_expected", tofile="actual_complete_stream")))
    need(actual == expected, "Complete comparison failed: " + str(folder / label))


def compare_calculation(sp, folder, original, target, expected_exit, started, finished):
    need(not (folder / "observation.error.json").exists(), "Observation shim reported an error")
    start, end = js(folder / "observation.start.json"), js(folder / "observation.return.json")
    need(start["target"] == end["target"] == str(target) and start["target_sha256"] == sha(raw(target)), "Observed target drift")
    need(start["shim_sha256"] == sha(raw(Q / "observation_shim/sitecustomize.py")), "Observed shim drift")
    need(type(end["function_return"]) is int and end["function_return"] == expected_exit, "Unexpected original main return")
    actual = js(folder / "calculation.raw.json")
    need(end["calculation_sha256"] == sha(raw(folder / "calculation.raw.json")), "Observed result identity mismatch")
    need(totals(sp, actual) == totals(sp, original), "Predicate gates changed")
    mapped = json.loads(json.dumps(original))
    edits = []
    if "source_sha256" in original:
        replacement = sha(raw(target))
        need(actual.get("source_sha256") == replacement, "Computed self hash differs from executed source")
        edits.append({"json_pointer": "/source_sha256", "before": original["source_sha256"], "after": replacement,
                      "reason": "Exact whole-source publication/mutation bytes; the helper still computes its own hash"})
        mapped["source_sha256"] = replacement
    time_key = {"Boost": "utc", "Weighted_current": "created_utc"}.get(sp["key"])
    if time_key:
        observed = datetime.fromisoformat(actual[time_key])
        need(observed.tzinfo is not None and datetime.fromisoformat(started) <= observed <= datetime.fromisoformat(finished), "Result timestamp outside this execution")
        edits.append({"json_pointer": "/" + time_key, "before": original[time_key], "after": actual[time_key],
                      "reason": "Same original timestamp expression during this fresh execution"})
        mapped[time_key] = actual[time_key]
    write(folder / "calculation.administrative_map.json", edits)
    canonical_json = lambda x: (json.dumps(x, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n").encode()
    compare(folder, "calculation.full", canonical_json(actual), canonical_json(mapped))
    return totals(sp, actual)


def observation_environment(folder, target, local_name, original_env):
    need(not any(k in original_env for k in OBS_KEYS), "Pre-existing observation environment is forbidden")
    before_path = original_env.get("PYTHONPATH")
    environment = dict(original_env)
    if local_name is not None:
        environment.update({"BGC_OBSERVE_FOLDER": str(folder), "BGC_OBSERVE_TARGET": str(target),
                            "BGC_OBSERVE_SHA256": sha(raw(target)), "BGC_OBSERVE_LOCAL": local_name,
                            "PYTHONPATH": str(Q / "observation_shim") + (os.pathsep + before_path if before_path else "")})
    write(folder / "environment.map.json", {
        "target": binding(target), "shim": binding(Q / "observation_shim/sitecustomize.py"),
        "changed": {k: {"before": original_env.get(k), "after": environment.get(k)}
                    for k in (*OBS_KEYS, "PYTHONPATH") if original_env.get(k) != environment.get(k)},
        "PYTHONDONTWRITEBYTECODE": environment.get("PYTHONDONTWRITEBYTECODE"),
        "other_environment_keys": "Passed through unchanged; values are not copied into evidence",
        "command_policy": "Interpreter/arguments/cwd/streams/timeout remain unchanged; exact path and source hash required",
        "pairing": PAIRING,
    })
    return environment


@contextmanager
def observe_canonical_popen(runner_cache, folder, target, local_name):
    original = runner_cache.subprocess.Popen
    command = [sys.executable, "-u", str(target)]
    seen = []

    def observed(args, *positional, **kwargs):
        need(args == command and not positional and Path(kwargs["cwd"]).resolve() == target.parents[1], "Unexpected canonical Popen command or cwd")
        need(not seen, "Repeated canonical subprocess launch")
        seen.append(args)
        write(folder / "subprocess.command.json", {"actual": args, "expected_unmodified_api_command": command,
              "cwd": str(kwargs["cwd"]), "stderr": "STDOUT, as in the unmodified cache API", "pairing": PAIRING})
        kwargs["env"] = observation_environment(folder, target, local_name, kwargs["env"])
        return original(args, **kwargs)

    runner_cache.subprocess.Popen = observed
    try:
        yield seen
    finally:
        runner_cache.subprocess.Popen = original


def canonical(sp, row, evidence, worktree, run, runner_cache):
    folder = run / "canonical" / sp["key"]
    folder.mkdir(parents=True)
    path = "scripts/" + sp["runner"]
    target = worktree / path
    local_name = None if sp["key"] == "Nonisolated_fock" else "output" if sp["key"] == "Weighted_current" else "result"
    original = evidence.read(sp["baseline_stdout"])
    evidence.save(sp["baseline_stdout"], folder, "original.stdout")
    calculation = evidence.json(sp["baseline_result"]) if sp.get("baseline_result") else None
    if calculation is not None:
        evidence.save(sp["baseline_result"], folder, "original.result.json")
    original_execute = runner_cache.execute_runner
    inner_returns = []

    def capture_inner(*args, **kwargs):
        result = original_execute(*args, **kwargs)
        preserved_return(folder, "INNER_execute_runner", result)
        # No identity/cache calls have occurred since the raw inner return.
        (folder / "stdout").write_text(result.get("stdout") or "")
        (folder / "stderr").write_text(result.get("stderr") or "")
        if result.get("live_log") and Path(result["live_log"]).is_file():
            (folder / "live_log.complete.txt").write_bytes(raw(result["live_log"]))
        inner_returns.append(result)
        return result

    started = datetime.now(timezone.utc).isoformat()
    runner_cache.execute_runner = capture_inner
    try:
        with observe_canonical_popen(runner_cache, folder, target, local_name):
            outer = runner_cache.execute_and_write_cache(path, 60)
            preserved_return(folder, "OUTER_execute_and_write_cache", outer)
            # Only after FULL OUTER preservation may this tuple be inspected.
    except BaseException:
        (folder / "outer.exception.txt").write_text(traceback.format_exc())
        raise
    finally:
        runner_cache.execute_runner = original_execute
    finished = datetime.now(timezone.utc).isoformat()
    result, cache = outer
    write(folder / "execution_context.json", {"started_utc": started, "finished_utc": finished,
          "timeout_seconds": 60, "pairing": PAIRING, "raw_stream_convention": "Cache API merges stderr into complete stdout; stderr is its original empty field"})
    need(len(inner_returns) == 1 and result == inner_returns[0], "Cache API altered the execution return")
    need(result["status"] == "ok" and result["exit_code"] == 0 and result["timeout_sec"] == 60, "Canonical failure; raw return preserved")
    need(cache is not None, "Canonical cache missing")
    (folder / "cache.complete.txt").write_bytes(raw(cache))
    compare(folder, "stdout", result["stdout"].encode(), original + suffix(row, calculation, True))
    compare(folder, "stderr", result["stderr"].encode(), b"")
    if calculation is not None:
        measured = compare_calculation(sp, folder, calculation, target, 0, started, finished)
    else:
        records = [json.loads(x) for x in original.splitlines()]
        need(len(records) == sp["baseline_totals"]["original_json_records"] and records[-1]["check"] == "completion" and records[-1]["status"] == "complete", "Fock completion record mismatch")
        measured = {"passed": 1, "failed": 0, "semantics": "One completed original assertion driver, not seven predicates"}
    fresh = {"cache_status": runner_cache.cache_status(path), "identity_status": runner_cache.cache_identity_status(path),
             "runner_sha256": runner_cache.runner_sha256(path), "input_fingerprint_sha256": runner_cache.declared_input_fingerprint(path)}
    write(folder / "cache_freshness.json", fresh)
    need(fresh["cache_status"] == fresh["identity_status"] == "fresh", "Cache is not fresh/usable")
    return {"key": sp["key"], "totals": measured, "elapsed_sec": result["elapsed_sec"], "timeout_sec": 60,
            "cache": str(cache), "status": "full_streams_and_original_calculation_preserved", "pairing": PAIRING}


def mapped_stderr(original, original_source, new_source, original_path, new_path, folder):
    old_lines, new_lines = original_source.decode().splitlines(), new_source.decode().splitlines()
    line_map = {}
    for block in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_matching_blocks():
        for offset in range(block.size):
            line_map[block.a + offset + 1] = block.b + offset + 1
    edits = []

    def replace(match):
        path, line = match.group(1), int(match.group(2))
        need(path == str(original_path) and line in line_map, "Unmapped traceback source or changed failing line")
        edits.append({"original_path": path, "original_line": line, "new_path": str(new_path), "new_line": line_map[line],
                      "unchanged_source_line": old_lines[line - 1]})
        return 'File "' + str(new_path) + '", line ' + str(line_map[line])
    out = re.sub(r'File "([^"]+)", line (\d+)', replace, original.decode())
    write(folder / "stderr.traceback_map.json", edits)
    return out.encode()


def validate_mutation_authority(sp, evidence):
    original = evidence.read(sp["folder"] + "/" + sp["helper"])
    need(sha(original) == sp["helper_sha"], "Original complete primary hash changed")
    if sp["mutation_kind"] == "original_cli_variant":
        choices = []
        for node in ast.walk(ast.parse(original)):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "add_argument" and node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == "--mutation":
                choices.append(ast.literal_eval(next(x.value for x in node.keywords if x.arg == "choices")))
        need(len(choices) == 1 and [x for x in choices[0] if x != "none"] == [x["name"] for x in sp["mutations"]], "Original active CLI variants differ")
    else:
        definitions = assignment(evidence.read(sp["mutation_authority"]), "cases" if sp["key"] == "Nonisolated_fock" else "mutations")
        expected = [(x["name"], x["before"], x["after"], x["replacements"]) for x in sp["mutations"]]
        actual = [tuple(x) if len(x) == 4 else (*x, 1) for x in definitions]
        need(actual == expected, "Mutation definitions differ from the original driver")
    need(len(sp["mutations"]) == sp["mutation_count"] and len({x["name"] for x in sp["mutations"]}) == sp["mutation_count"], "Duplicate/incomplete mutation case set")
    return original


def mutant(sp, case, row, evidence, worktree, run):
    folder = run / "mutants" / sp["key"] / case["name"]
    folder.mkdir(parents=True)
    source = raw(worktree / "scripts" / sp["runner"])
    original_source = evidence.read(sp["folder"] + "/" + sp["helper"])
    if "before" in case:
        source = edited(source.decode(), case["before"], case["after"], case["replacements"], case["name"]).encode()
        original_source = edited(original_source.decode(), case["before"], case["after"], case["replacements"], case["name"]).encode()
        need(original_source == evidence.read(case["original_source"]) and sha(original_source) == case["original_source_sha256"], "Frozen whole-source mutant mismatch")
    specimen = Q / "mutant_specimens" / sp["key"] / (case["name"] + ".py")
    need(source == raw(specimen), "Prepared whole-primary specimen differs")
    target = folder / "source.py"
    target.write_bytes(source)
    (folder / "original.source.py").write_bytes(original_source)
    originals = []
    for field, name in (("original_stdout", "original.stdout"), ("original_stderr", "original.stderr"),
                        ("original_receipt", "original.receipt.json"), ("original_result", "original.result.json")):
        if field in case:
            originals.append(evidence.save(case[field], folder, name))
            need(sha(raw(folder / name)) == case[field + "_sha256"], "Frozen original stream/result/receipt hash mismatch")
    old_receipt = js(folder / "original.receipt.json")
    need(old_receipt.get("exit_code", old_receipt.get("returncode")) == case["expected_exit"] and old_receipt.get("timed_out", False) == case["original_timed_out"] is False, "Original mutation gate unresolved")
    calculation = evidence.json(case["original_result"]) if "original_result" in case else None
    if calculation is not None:
        derived = totals(sp, calculation)
        need(derived == {"passed": case["expected_passed"], "failed": case["expected_failed"]} and int(derived["failed"] != 0) == case["expected_exit"], "Frozen mutant totals/exit disagree")
    need(case["survived"] == (case["expected_exit"] == 0), "Mutation survivor label disagrees with actual gate")
    local_name = None if calculation is None else "output" if sp["key"] == "Weighted_current" else "result"
    command = [sys.executable, "-u", str(target), *case.get("argv", [])]
    environment = observation_environment(folder, target, local_name, {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(worktree / "scripts")})
    write(folder / "source_and_command_map.json", {"case": case, "originals": originals, "executed_source": binding(target),
        "specimen": binding(specimen), "command": command,
        "administrative_cli_difference": "Named/adjacent result output is suppressed by the exact publication mapping; the unchanged existing result object is observed. No --output argument is necessary.",
        "timeout_policy": "Original recorded per-case timeout retained", "pairing": PAIRING})
    receipt, stdout, stderr = log_run(folder / "execution", command, case["original_timeout_seconds"], worktree, environment)
    require_exit(receipt, case["expected_exit"])
    expected_stdout = raw(folder / "original.stdout") + suffix(row, calculation, calculation is not None or case["survived"])
    compare(folder, "stdout", stdout, expected_stdout)
    expected_stderr = mapped_stderr(raw(folder / "original.stderr"), original_source, source,
                                   S / case.get("original_source", sp["folder"] + "/" + sp["helper"]), target, folder)
    compare(folder, "stderr", stderr, expected_stderr)
    if calculation is not None:
        compare_calculation(sp, folder, calculation, target, case["expected_exit"], receipt["started_utc"], receipt["finished_utc"])
    return {"key": sp["key"], "name": case["name"], "survived_original_gate": case["survived"],
            "exit_code": receipt["exit_code"], "timeout_seconds": receipt["timeout_seconds"],
            "elapsed_seconds": receipt["elapsed_seconds"], "timed_out": receipt["timed_out"],
            "original_elapsed_seconds": case["original_elapsed_seconds"], "source_sha256": sha(source),
            "complete_streams_match": True, "pairing": PAIRING}


def materializations(sp, evidence, run):
    folder = run / "retained_integrated_materializations"
    folder.mkdir()
    original = evidence.read(sp["folder"] + "/" + sp["helper"])
    report = []
    for row in sp["review_materializations"]:
        destination = folder / row["name"]
        destination.mkdir()
        mapped = original.decode()
        for edit in row["edits"]:
            mapped = edited(mapped, edit["before"], edit["after"], edit["occurrences"], row["name"])
        need(mapped.encode() == evidence.read(row["source"]) and sha(mapped.encode()) == row["sha256"], "Integrated materialization source differs")
        records = [evidence.save(row["source"], destination, "source.py")]
        for field, name in (("original_stdout", "stdout"), ("original_stderr", "stderr"), ("original_result", "result.json"), ("original_receipt", "receipt.json")):
            records.append(evidence.save(row[field], destination, name))
        primary = None if row["mode"] == "none" else next(x for x in sp["mutations"] if x["name"] == row["mode"])
        need(raw(destination / "stdout") == evidence.read(sp["baseline_stdout"] if primary is None else primary["original_stdout"]), "Materialized replay stdout differs from original active CLI")
        need(js(destination / "result.json") == evidence.json(sp["baseline_result"] if primary is None else primary["original_result"]), "Materialized replay calculations differ")
        report.append({"source_map": row, "preserved": records, "fresh_execution": False,
                       "role": "Existing whole-helper replay, not an additional independent check", "pairing": PAIRING})
    write(folder / "retention.json", report)
    return report


def metadata_links(worktree, packet, specs, maps, evidence, run):
    import yaml
    records, links = [], []
    for sp in specs:
        note = worktree / "docs" / sp["note"]
        text = raw(note).decode()
        need(text.startswith("---\n"), "Missing note frontmatter")
        front = yaml.safe_load(text.split("---", 2)[1])
        expected = {"claim_id": sp["claim"], "claim_type": "bounded_theorem", "target_claim_type": "bounded_theorem",
                    "actual_current_surface_status": "conditional-support", "runner": "scripts/" + sp["runner"],
                    "upstream_dependencies": sp["deps"], "bare_retained_allowed": False,
                    "audit_required_before_effective_retained": True,
                    "trace_class": sp.get("trace_class", "upstream_support"),
                    "reachability_to_target": sp.get("reachability_to_target", "partially_closes")}
        need(all(front.get(k) == v for k, v in expected.items()), "Claim metadata differs from bounded source contract")
        need(sp["pairing"] in text, "Note lacks exact same-family/separate-context disclosure")
        source = raw(worktree / "scripts" / sp["runner"])
        need(assignment(source, "AUDIT_TIMEOUT_SEC") == 60 and list(assignment(source, "AUDIT_INPUT_PATHS")) == sp["audit_inputs"], "Runner declaration mismatch")
        compile(source, str(worktree / "scripts" / sp["runner"]), "exec")
        records.append({"note": binding(note), "frontmatter": front, "pairing": PAIRING})
        for kind, relative in (("note", "docs/" + sp["note"]), ("primary", "scripts/" + sp["runner"])):
            row = next(r for r in maps["outputs"] if r["publication_path"] == relative)
            original = evidence.read(str(Path(row["source_path"]).relative_to(S)))
            need(apply_publication(original, row) == raw(worktree / relative), "Full publication reconstruction mismatch")
            need(not row["mathematical_changes"], "Unexpected mathematical publication edit")
    state = yaml.safe_load(raw(packet / "STATE.yaml"))
    need(state["author_checker_pairing"] == "same_selected_model_family_separate_contexts_not_blinded" and state["root_role"] == "coauthor_supervisor_not_independent_reviewer", "Packet pairing/role drift")
    for path in sorted(packet.glob("*.md")) + [worktree / "docs" / s["note"] for s in specs]:
        prose, fenced = [], False
        for line in raw(path).decode().splitlines():
            if line.lstrip().startswith(("```", "~~~")):
                fenced = not fenced
                continue
            if not fenced and not line.startswith(("    ", "\t")):
                prose.append(re.sub(r"`[^`]*`", "", line))
        text = "\n".join(prose)
        for pattern in (r"\\\[.*?\\\]", r"\\\(.*?\\\)", r"\$\$.*?\$\$", r"(?<!\\)\$(?!\$).*?(?<!\\)\$"):
            text = re.sub(pattern, "", text, flags=re.S)
        for target in re.findall(r"\]\(([^)\s]+)\)", text):
            if target.startswith(("http:", "https:", "#", "mailto:")):
                continue
            destination = (path.parent / unquote(target.strip("<>").split("#", 1)[0])).resolve()
            need(destination.is_relative_to(worktree) and destination.exists(), "Broken/escaping publication link: " + str(path) + " -> " + target)
            links.append({"source": str(path.relative_to(worktree)), "target": target, "resolved": str(destination.relative_to(worktree))})
    write(run / "metadata_and_links.json", {"notes": records, "state": state, "ordinary_local_links": links,
          "math_exclusion": "Fenced/inline code, display and inline TeX, dollar math excluded before ordinary Markdown links", "pairing": PAIRING})


def graph_and_compatibility(worktree, base, specs, run):
    for label, script in (("graph_build", "run_citation_graph_build.py"), ("graph_manifest", "write_citation_graph_manifest.py")):
        receipt, _, _ = log_run(run / label, [sys.executable, "docs/audit/scripts/" + script], 180, worktree)
        require_exit(receipt)
    before = js(Q / "base_graph_manifest.json")
    after, graph = js(worktree / GRAPH_MANIFEST), js(worktree / GRAPH)
    (run / "citation_graph.complete.json").write_bytes(raw(worktree / GRAPH))
    (run / "citation_graph_manifest.complete.json").write_bytes(raw(worktree / GRAPH_MANIFEST))
    expected = {sp["claim"]: sorted(sp["deps"]) for sp in specs}
    need(set(after["nodes"]) - set(before["nodes"]) == set(expected) and set(before["nodes"]) <= set(after["nodes"]), "Unexpected graph node additions/removals")
    need(all(after["nodes"][k] == v for k, v in before["nodes"].items()), "An old node's topology changed")
    need(set(graph["nodes"]) == set(after["nodes"]), "Graph/manifest membership mismatch")
    for node, row in graph["nodes"].items():
        deps = sorted(row["deps"])
        need(len(deps) == len(set(deps)) and after["nodes"][node] == {"out_degree": len(deps), "deps_hash": sha("\n".join(deps).encode())[:12]}, "Graph/manifest topology mismatch")
    for sp in specs:
        node = graph["nodes"][sp["claim"]]
        need(sorted(node["deps"]) == expected[sp["claim"]] and node["runner_path"] == "scripts/" + sp["runner"] and node["note_hash"] == sha(raw(worktree / "docs" / sp["note"])), "New graph node/source/dependencies mismatch")
    delta = {"nodes": after["node_count"] - before["node_count"], "edges": after["edge_count"] - before["edge_count"]}
    need(delta == {"nodes": len(specs), "edges": sum(map(len, expected.values()))}, "Unexpected graph count delta")
    need(delta == {"nodes": 5, "edges": 8}, "Reviewed direct dependency plan changed")
    write(run / "graph.comparison.json", {"before_counts": {k: before[k] for k in ("node_count", "edge_count")},
          "after_counts": {k: after[k] for k in ("node_count", "edge_count")}, "delta": delta,
          "old_node_topology_unchanged": True, "new_direct_dependencies": expected,
          "limit": "Prior topology is compared to the exact-base tracked manifest; no pre-existing graph payload was present in this checkout", "pairing": PAIRING})
    receipt, stdout, _ = log_run(run / "focused_compatibility", [sys.executable, "docs/audit/scripts/check_changed_audit_evidence.py", "--base", base, "--include-worktree", "--json"], 120, worktree)
    require_exit(receipt)
    report = json.loads(stdout)
    need(report["base"] == base and report["diff_scope"] == "committed_and_worktree" and not report["failures"] and not report["control_failures"], "Focused compatibility failed")
    checked = {r["claim_id"] for r in report["checked"]}
    write(run / "focused_compatibility_scope.json", {"requested_new_claims": sorted(expected), "actually_checked_ledger_rows": sorted(checked),
          "new_claims_selected_in_existing_ledger": sorted(checked & set(expected)),
          "scope": "Compatibility only; no verdict, retained promotion, global combined audit or strict audit lint", "pairing": PAIRING})
    return delta, report


def output_manifest(run):
    rows = [binding(p) for p in sorted(run.rglob("*")) if p.is_file() and p != run / "EVIDENCE_MANIFEST.json"]
    write(run / "EVIDENCE_MANIFEST.json", {"scope": "All complete attempt files except this self-referential manifest", "files": rows, "pairing": PAIRING})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--base", required=True)
    args = parser.parse_args()
    need(__debug__ and not os.environ.get("PYTHONOPTIMIZE"), "Assertions must remain enabled")
    need(not any(k in os.environ for k in OBS_KEYS), "Unexpected inherited observation environment")
    worktree, base = args.worktree.resolve(), args.base
    freeze = js(Q / "SOURCE_FREEZE.json")
    need(base == freeze["base_revision"] and str(worktree) == freeze["observed_worktree"], "Explicit base/worktree do not match reviewed frozen inputs")
    run = Q / "runs" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:12])
    run.mkdir(parents=True, exist_ok=False)
    state = {"status": "running", "base": base, "worktree": str(worktree), "run": str(run), "pairing": PAIRING,
             "global_combined_audit": "not_run_separate_landing_gate", "strict_audit_lint": "not_run_separate_landing_gate",
             "audit_verdict": "not_applied", "independent_controls": "existing_source_bound_evidence_not_rerun"}
    write(run / "status.json", state)
    try:
        check_freeze(freeze, worktree)
        packet = worktree / PACKET
        specifications, maps = js(packet / "SPECIFICATIONS.json"), js(packet / "PUBLICATION_EDITS.json")
        specs = specifications["specs"]
        need(specifications["base_revision"] == maps["base_revision"] == base, "Packet base mismatch")
        publication_paths = freeze["publication_paths"]
        check_scope(worktree, base, run, "scope_before", publication_paths)
        base_manifest = git_read(worktree, run, "base_manifest", "show", base + ":" + GRAPH_MANIFEST)
        need(base_manifest == raw(Q / "base_graph_manifest.json") == raw(worktree / GRAPH_MANIFEST), "Graph manifest is not the exact-base frozen version")
        cache_paths = ["logs/runner-cache/" + Path(sp["runner"]).stem + ".txt" for sp in specs]
        need(all(not (worktree / x).exists() for x in cache_paths), "Existing canonical cache: refuse to repeat or overwrite a previous run")
        evidence = Evidence(packet)
        for label in ("before_vocabulary", "after_vocabulary_fix", "after_vocabulary_report"):
            if label != "before_vocabulary":
                mode = "fix" if label == "after_vocabulary_fix" else "report-only"
                targets = [r["publication_path"] for r in maps["outputs"]] + [str(p.relative_to(worktree)) for p in sorted(packet.glob("*.md"))] + [PACKET + "/reconstruct.py"]
                report_path = run / ("vocabulary_" + mode + ".json")
                receipt, _, _ = log_run(run / ("vocabulary_" + mode), [sys.executable, "scripts/vocab_lint.py", "--" + mode, "--report-path", str(report_path), *targets], 60, worktree)
                require_exit(receipt)
                report = js(report_path)
                need(report["summary"] == {"files_with_violations": 0, "total_auto_correctable": 0, "total_needs_human": 0} and report["files"] == [], "Vocabulary changed/found an unmapped surface; refuse caching")
            receipt, _, _ = log_run(run / ("reconstruction_" + label), [sys.executable, str(packet / "reconstruct.py")], 60, worktree)
            require_exit(receipt)
            check_freeze(freeze, worktree)
        metadata_links(worktree, packet, specs, maps, evidence, run)
        for sp in specs:
            validate_mutation_authority(sp, evidence)
            if sp.get("baseline_result"):
                recorded = totals(sp, evidence.json(sp["baseline_result"]))
                need(recorded == {k: sp["baseline_totals"][k] for k in ("passed", "failed")}, "Baseline summary mismatch")
        integrated = next(s for s in specs if s["key"] == "Integrated_boost")
        materializations(integrated, evidence, run)
        sys.path.insert(0, str(worktree / "scripts"))
        module_spec = importlib.util.spec_from_file_location("runner_cache", worktree / "scripts/runner_cache.py")
        runner_cache = importlib.util.module_from_spec(module_spec)
        sys.modules["runner_cache"] = runner_cache
        module_spec.loader.exec_module(runner_cache)
        original_dontwrite = os.environ.get("PYTHONDONTWRITEBYTECODE")
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        try:
            canonicals, mutations = [], []
            for sp in specs:
                row = next(r for r in maps["outputs"] if r["publication_path"] == "scripts/" + sp["runner"])
                canonicals.append(canonical(sp, row, evidence, worktree, run, runner_cache))
                for case in sp["mutations"]:
                    mutations.append(mutant(sp, case, row, evidence, worktree, run))
                check_freeze(freeze, worktree)
        finally:
            if original_dontwrite is None:
                os.environ.pop("PYTHONDONTWRITEBYTECODE", None)
            else:
                os.environ["PYTHONDONTWRITEBYTECODE"] = original_dontwrite
        survivors = {sp["key"]: [x["name"] for x in mutations if x["key"] == sp["key"] and x["survived_original_gate"]] for sp in specs}
        need(all(survivors[sp["key"]] == sp["expected_mutation_survivors"] for sp in specs), "Recorded nondiscrimination changed")
        need(len(mutations) == sum(sp["mutation_count"] for sp in specs) == 32 and sum(map(len, survivors.values())) == 4, "Reviewed mutation family membership changed")
        write(run / "canonical_summary.json", canonicals)
        write(run / "mutation_summary.json", {"cases": mutations, "survivors": survivors, "total": len(mutations),
              "scope": "Original finite gates, with four Fock survivors; no analytic proof or independence promotion", "pairing": PAIRING})
        delta, compatibility = graph_and_compatibility(worktree, base, specs, run)
        check_freeze(freeze, worktree, graph_written=True)
        check_scope(worktree, base, run, "scope_after", publication_paths, [GRAPH_MANIFEST, *cache_paths])
        receipt, _, _ = log_run(run / "reconstruction_final", [sys.executable, str(packet / "reconstruct.py")], 60, worktree)
        require_exit(receipt)
        freshness = {"scripts/" + sp["runner"]: runner_cache.cache_status("scripts/" + sp["runner"]) for sp in specs}
        write(run / "final_cache_status.json", freshness)
        need(set(freshness.values()) == {"fresh"}, "Final cache identity/usable status changed")
        final_paths = [worktree / x for x in publication_paths] + [worktree / GRAPH, worktree / GRAPH_MANIFEST] + [worktree / x for x in cache_paths]
        write(run / "publication_source_manifest.json", {"base": base, "files": [binding(p) for p in sorted(final_paths)],
              "scope": "Prepared source/evidence, graph and canonical cache bytes at this verification; final publication metadata remains root-owned", "pairing": PAIRING})
        state.update(status="completed", canonical_count=len(canonicals), actual_mutations=len(mutations),
                     known_survivors=survivors, graph_delta=delta, focused_compatibility_failures=len(compatibility["failures"]))
    except BaseException:
        state.update(status="failed", failure_traceback=traceback.format_exc())
        write(run / "status.json", state)
        output_manifest(run)
        raise
    write(run / "status.json", state)
    output_manifest(run)
    print(json.dumps({**state, "evidence_manifest": binding(run / "EVIDENCE_MANIFEST.json")}))


if __name__ == "__main__":
    main()
