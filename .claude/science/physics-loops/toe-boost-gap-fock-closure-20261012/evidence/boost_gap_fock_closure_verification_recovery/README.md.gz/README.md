The recovery finisher is prepared for root review and remains unexecuted.
It requires explicit `--worktree` and `--base` matching the original target at
`3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe`, and the same resolved Python binary
as the recorded first attempt. Root read all 728 original verifier lines and
its complete shim/contract before that execution. Root must read this separate
finisher and recovery mapping before executing it.

The first attempt is preserved at
`boost_gap_fock_closure_verification_preparation/runs/20261012T082449_7c155832925d`.
It successfully executed and cached Boost, Gapped and Fock, and completed the
nine Boost/Gapped CLI mutations. It then failed the Fock stdout comparison.
Only the first environment JSON line differed: numpy_version was 2.3.5 in the
original author stream and 2.4.4 in this interpreter. The complete remaining
expected/current stream bytes match, including every scientific number. Full
raw INNER and OUTER returns, streams, caches and the failed comparison survive.

Root explicitly approved a comparison-only mapping of that exact first JSON
line for the Fock baseline and 13 mutants. No future version, whitespace,
additional field or scientific value difference is accepted. Every file named
`original` retains the exact original bytes and original version. The finisher
does not replace Evidence.read or Evidence.save and does not edit any helper,
predicate, tolerance, gate, return value or original receipt. It writes a
separate complete unmapped expected stream and before/after mapping receipt,
then compares the entire current stream to the mapped expectation exactly.

The old verifier is imported inertly through its __main__ guard. Its exact
source, freeze, shim and all 32 whole-source specimens remain pinned. The
complete old attempt and three existing caches are additionally hash-bound.
Before any reuse, every old manifest member is checked, the entire attempt is
copied into a new attempt directory, and every copied byte is checked again.
Tagged JSON supplies the full inner/outer values; raw pickle is preserved only
as opaque hashed evidence and is never loaded. Each saved cache's complete
bytes and body are checked against the saved raw API streams before freshness
APIs run. Revalidation writes to new folders, leaving copied evidence intact.

Three saved canonical executions and nine saved mutations are revalidated with
their original source/command, full stdout/stderr, result dictionaries, original
and observed timing/timeout records and cache/input identities. The only new
science executions planned are 13 Fock mutations, Weighted and Integrated
canonical primaries, and their five mutations each: two new canonicals and
23 new mutants. Existing caches or unexpected prior-attempt membership fail
closed before continuation. Integrated materializations are reconstructed from
existing evidence without additional execution or independence claims.

The unmodified frozen canonical API/observer functions preserve full raw INNER
and OUTER returns in the required order for the two new canonical executions.
All original JSON calculations retain the original strict comparison policy.
The finisher uses the original reconstruction/vocabulary checks, metadata/math-
aware links, exact five-node/eight-edge graph check, focused exact-base audit
compatibility, source manifests and final scope/cache/reconstruction checks.
The three old caches, old attempt, verifier, freeze and originals must remain
unchanged through completion. All new attempt logs remain durable and unique.

Four Fock survivors remain expected finite-control limitations. Global combined
audit and strict audit lint remain separate independent landing gates. No audit
verdict, retained promotion or physical-model conclusion follows. Same selected
model family, separate author/reviewer contexts, formulas/results exposed;
neither blinded nor cross-family checking. Root is a coauthor. Final publication
metadata, evidence integration and Git actions remain root-owned.

Preparation performed source/AST/hash/byte-equality checks only. It executed no
finisher, frozen verifier, shim, primary, mutation, independent helper, Git,
cache, graph, audit or vocabulary operation. No worktree/cache/prompt file was
edited. The previous failed run is a preserved failure, not relabelled success.
