"""Source-only recovery preparation. Never import either verifier or run science."""
import ast
import hashlib
import json
from pathlib import Path
import re

R = Path(__file__).resolve().parent
S = R.parent
Q = S / "boost_gap_fock_closure_verification_preparation"
W = S.parent / "microscopic_boost_worktree"
OLD = Q / "runs/20261012T082449_7c155832925d"
FINISHER = S / "finish_boost_gap_fock_closure_verification.py"
VERIFIER = S / "verify_boost_gap_fock_closure_publication.py"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def js(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def binding(path):
    data = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


assert sha(VERIFIER.read_bytes()) == "96a59ee77749ce7d12a39ff2226561957ef4de7394a9a55b68d9995c86ba4578"
assert sha((Q / "SOURCE_FREEZE.json").read_bytes()) == "3efa2d27139c2f924fc495b3ad4017ef83f9e9173b56c6abf2aae73aee16b6be"
manifest = js(OLD / "EVIDENCE_MANIFEST.json")
assert sha((OLD / "EVIDENCE_MANIFEST.json").read_bytes()) == "4ae7dac62f65ff2236abfb2685f271b7336e2c763203e6bb9a566714e487de0b"
old_files = {Path(r["path"]) for r in manifest["files"]} | {OLD / "EVIDENCE_MANIFEST.json"}
assert old_files == {p for p in OLD.rglob("*") if p.is_file()}
for row in manifest["files"]:
    assert binding(Path(row["path"])) == row
old_line = b'{"check": "environment", "numpy_version": "2.3.5"}\n'
new_line = b'{"check": "environment", "numpy_version": "2.4.4"}\n'
expected = (OLD / "canonical/Nonisolated_fock/stdout.expected").read_bytes()
actual = (OLD / "canonical/Nonisolated_fock/stdout").read_bytes()
assert expected.startswith(old_line) and actual == new_line + expected[len(old_line):]
specs = js(W / ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012/SPECIFICATIONS.json")["specs"]
fock = next(s for s in specs if s["key"] == "Nonisolated_fock")
for case in fock["mutations"]:
    assert (S / case["original_stdout"]).read_bytes().startswith(old_line)
reused = ["Boost", "Gapped", "Nonisolated_fock"]
assert sorted(p.name for p in (OLD / "canonical").iterdir()) == sorted(reused)
assert sorted(p.name for p in (OLD / "mutants").iterdir()) == ["Boost", "Gapped"]
caches = []
for key in reused:
    sp = next(s for s in specs if s["key"] == key)
    cache = W / "logs/runner-cache" / (Path(sp["runner"]).stem + ".txt")
    assert cache.read_bytes() == (OLD / "canonical" / key / "cache.complete.txt").read_bytes()
    inner = js(OLD / "canonical" / key / "INNER_execute_runner.raw.json")
    outer = js(OLD / "canonical" / key / "OUTER_execute_and_write_cache.raw.json")
    assert outer["items"][0] == inner and inner["status"] == "ok" and inner["exit_code"] == 0
    _, body = cache.read_text().split("----- stdout -----\n", 1)
    out, err = body.rsplit("\n----- stderr -----\n", 1)
    assert out == inner["stdout"][-200000:] and err == inner["stderr"][-50000:] + "\n"
    caches.append(cache)
for key in ["Weighted_current", "Integrated_boost"]:
    sp = next(s for s in specs if s["key"] == key)
    assert not (W / "logs/runner-cache" / (Path(sp["runner"]).stem + ".txt")).exists()
tree = ast.parse(FINISHER.read_bytes())
compile(tree, str(FINISHER), "exec")
assert not any(isinstance(n, ast.Attribute) and n.attr in ("read", "save") and isinstance(n.ctx, ast.Store) for n in ast.walk(tree))
assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("load", "loads")
               and isinstance(n.func.value, ast.Name) and n.func.value.id == "pickle" for n in ast.walk(tree))
interpreter = Path(js(OLD / "canonical/Boost/subprocess.command.json")["actual"][0]).resolve()
write(R / "MAPPING_AND_EXECUTION_PLAN.json", dict(
    prior_status="failed_at_Fock_stdout_environment_line_only", approved_by="root explicit recovery task instruction",
    exact_mapping=dict(line=1, field="numpy_version", before_line=old_line.decode(), after_line=new_line.decode(),
        remaining_expected_bytes_sha256=sha(expected[len(old_line):]), remaining_actual_bytes_sha256=sha(actual[len(new_line):])),
    reused_canonicals=reused, reused_mutants={s["key"]:[c["name"] for c in s["mutations"]] for s in specs if s["key"] in ["Boost","Gapped"]},
    new_canonicals=["Weighted_current","Integrated_boost"],
    new_mutants={s["key"]:[c["name"] for c in s["mutations"]] for s in specs if s["key"] not in ["Boost","Gapped"]},
    totals=dict(reused_canonicals=3,reused_mutants=9,new_canonicals=2,new_mutants=23),
    root_source_exposure="Root read complete 728-line original verifier and full shim/contract; complete new finisher is supplied for root review before execution",
    original_artifacts_untouched=True, science_execution_by_preparation=False, verifier_imported=False,
    worktree_cache_git_actions_by_preparation=False, editable_prompt_files_changed=[],
    pairing="same selected model family, separate contexts, not blinded; root coauthor"))
write(R / "STATIC_CHECKS.json", dict(status="source_only_checks_complete", checks=[
    "all 329 prior attempt files including the manifest bound", "raw prior INNER/OUTER JSON equality and successful exit",
    "three current caches byte-identical to prior complete cache snapshots", "cache bodies equal raw returned streams",
    "only first Fock environment line differs; all remaining bytes equal", "all 13 original Fock mutant first lines match approved source version",
    "remaining two canonical caches absent", "finisher AST/compile without execution", "no pickle loads or Evidence read/save assignments"],
    limits="No recovery or science program was imported or executed; root owns runtime checking and final publication"))
inherited = js(Q / "SOURCE_FREEZE.json")
files = old_files | set(caches) | {VERIFIER, Q / "SOURCE_FREEZE.json", interpreter}
files.update(p for p in R.rglob("*") if p.is_file() and p.name not in ["SOURCE_FREEZE.json","FREEZE_RECEIPT.json"] and "runs" not in p.relative_to(R).parts)
template = re.sub(rb'FREEZE_SHA256 = "[^"]+"', b'FREEZE_SHA256 = "TO_BE_FROZEN"', FINISHER.read_bytes(), count=1)
freeze = dict(base_revision=inherited["base_revision"], worktree=str(W), prior_attempt=str(OLD),
    prior_attempt_manifest_sha256=sha((OLD / "EVIDENCE_MANIFEST.json").read_bytes()),
    finisher_template_sha256=sha(template), original_verifier_sha256=sha(VERIFIER.read_bytes()),
    original_freeze_sha256=sha((Q / "SOURCE_FREEZE.json").read_bytes()),
    inherited_full_source_and_specimen_bindings=inherited["files"],
    inherited_binding_policy="The inertly imported verifier checks every inherited binding before execution and again after; only its reviewed graph-manifest exception applies after graph generation",
    interpreter=binding(interpreter), files=[binding(p) for p in sorted(files)], status="unexecuted",
    original_attempt_and_three_caches_policy="Immutable through recovery; no repeated completed science")
write(R / "SOURCE_FREEZE.json", freeze)
freeze_sha = sha((R / "SOURCE_FREEZE.json").read_bytes())
FINISHER.write_bytes(template.replace(b'FREEZE_SHA256 = "TO_BE_FROZEN"', ('FREEZE_SHA256 = "'+freeze_sha+'"').encode(), 1))
compile(ast.parse(FINISHER.read_bytes()), str(FINISHER), "exec")
receipt = dict(finisher_sha256=sha(FINISHER.read_bytes()), freeze_sha256=freeze_sha,
    finisher_lines=len(FINISHER.read_text().splitlines()), direct_bindings=len(files), inherited_bindings=len(inherited["files"]),
    status="unexecuted", source_only_checks_passed=True, completed_science_repeated=0, editable_prompt_files_changed=[])
write(R / "FREEZE_RECEIPT.json", receipt)
print(json.dumps(receipt))
