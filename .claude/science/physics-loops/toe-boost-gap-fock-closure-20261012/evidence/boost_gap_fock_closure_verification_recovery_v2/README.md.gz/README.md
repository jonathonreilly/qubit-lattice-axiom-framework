This is a second unexecuted recovery finisher, supplied for root's complete read.
It requires the same explicit worktree/base, source pins and current Homebrew
Python 3.13.5 binary as the prior attempts. Preparation executed no verifier,
helper, science, cache, graph, vocabulary, audit or Git command and wrote only
the new finisher and this preparation folder. Editable prompt files: none.

Both operational failures remain immutable:

- `verification_preparation/runs/20261012T082449_7c155832925d` executed three
  canonicals and nine mutations, then failed Fock's environment-version line.
- `verification_recovery/runs/20261012T083953_62636d2de815` revalidated those
  executions and executed `bracket_sign` once. Its unchanged assertion rejected
  with the intended exit 1. Comparison then failed solely because the current
  Python traceback added `    ~~~~~~~~~~~~~~~~~^^` below `free_word_control()`.

Root approved two strictly administrative comparison maps. The Fock first
environment JSON line may map numpy_version 2.3.5 to 2.4.4. Separately, one
optional standalone caret/tilde diagnostic underline may be omitted from each
side of comparison immediately following an exact inventoried Fock frame and
displayed source line. Its characters must be spaces/tabs/carets/tildes, begin
with the four-space source indent, and fit inside the displayed source width.
No blanket traceback-line filtering is used. Missing, extra or reordered frames,
different paths/line numbers/functions/source/assertion/exception/value text,
changed exit gates, or any remaining byte difference fail closed. Four original
survivors have empty stderr and receive no diagnostic-format exemption.

All 13 original Fock stderr streams and complete source specimens are pinned.
The nine rejecting streams supply 18 exact frame contexts. Source-only preflight
binds their original/canonical line mapping and renders representative optional
underlines as text, without executing helpers. Those rendered examples are
explicitly synthetic formatting fixtures, not newly observed science. The one
actually observed added call-site underline is checked against the same context.
The runtime records complete original, unmapped current/expected and normalized
streams, every removed underline, both source contexts and all comparison hashes.
Evidence.read/save remain unchanged; files called `original` are never rewritten.

Provenance correction: root's earlier Python 3.11 label was an unverified
inference and has been withdrawn. Historical receipts identify the bundled
`.../dependencies/python/bin/python3` command but do not record its version.
That symlink currently resolves to `python3.12`; this is a current observation,
not historical version evidence. The mapping binds the actual historical command
path and exact traceback bytes to the pinned current interpreter and source
contexts, without inventing the old interpreter version.

The finisher revalidates the three saved canonicals, nine Boost/Gapped mutations
and saved Fock `bracket_sign` rejection. It plans only two new canonical runs and
22 new mutants (the remaining 12 Fock, five Weighted and five Integrated cases).
Both entire failed attempts, their manifests, their copied evidence, all old
source/freezes and the three existing caches are checked before reuse and after
completion. Existing copied failures retain their original failed status. Pickle
is opaque hash-bound evidence and is never loaded. No completed science reruns.

The original frozen verifier is imported inertly. Its canonical functions retain
full raw INNER-before-identity and OUTER-before-inspection capture and the strict
full-result comparison. Original JSON, all scientific stdout, mutation gates,
timeouts, durations, failures and four Fock survivors retain their existing
meaning. Integrated materializations are preserved without fresh independent
execution. Reconstruction before/after vocabulary, source/metadata/math-aware
links, the five-node/eight-edge graph, exact-base focused compatibility, source
manifests and final scope/cache checks remain required.

Global combined audit and strict audit lint remain separate landing gates; no
verdict or retained promotion is applied. Same selected model family, separate
author/reviewer contexts, formulas/results exposed; neither blinded nor
cross-family checking. Root is a coauthor, not the independent reviewer. Final
publication metadata, evidence integration and Git/publication remain root-owned.
