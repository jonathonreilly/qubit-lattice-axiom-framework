"""Source-only traceback inventory/freeze; imports no verifier or science helper."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

R = Path(__file__).resolve().parent
S = R.parent
Q = S / "boost_gap_fock_closure_verification_preparation"
R1 = S / "boost_gap_fock_closure_verification_recovery"
W = S.parent / "microscopic_boost_worktree"
P = W / ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012"
OLD = Q / "runs/20261012T082449_7c155832925d"
SECOND = R1 / "runs/20261012T083953_62636d2de815"
PROGRAM = S / "finish_boost_gap_fock_closure_verification_v2.py"
VERIFIER = S / "verify_boost_gap_fock_closure_publication.py"
PRIOR = S / "finish_boost_gap_fock_closure_verification.py"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def js(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def binding(path):
    data = path.read_bytes()
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


assert sha(VERIFIER.read_bytes()) == "96a59ee77749ce7d12a39ff2226561957ef4de7394a9a55b68d9995c86ba4578"
assert sha(PRIOR.read_bytes()) == "1f40293e3bac1d2634e3cff46f496d01ec73e0211ee3115dc3993df3abccb4e8"
assert sha((Q / "SOURCE_FREEZE.json").read_bytes()) == "3efa2d27139c2f924fc495b3ad4017ef83f9e9173b56c6abf2aae73aee16b6be"
assert sha((R1 / "SOURCE_FREEZE.json").read_bytes()) == "d9ca0ab4c8299286df5b301dd777b6911dcf6f268913f9e16ad7371b1fdeba09"
attempts = [(OLD, "4ae7dac62f65ff2236abfb2685f271b7336e2c763203e6bb9a566714e487de0b"),
            (SECOND, "8306eef2d122f74f54363feed567f85c99eb77fb7d2e756e93fe93f7d64c0174")]
files = set()
for folder, expected_sha in attempts:
    assert sha((folder / "EVIDENCE_MANIFEST.json").read_bytes()) == expected_sha
    manifest = js(folder / "EVIDENCE_MANIFEST.json")
    expected = {Path(r["path"]) for r in manifest["files"]} | {folder / "EVIDENCE_MANIFEST.json"}
    assert expected == {p for p in folder.rglob("*") if p.is_file()}
    for row in manifest["files"]:
        assert binding(Path(row["path"])) == row
    files.update(expected)
specs = js(P / "SPECIFICATIONS.json")["specs"]
fock = next(s for s in specs if s["key"] == "Nonisolated_fock")
current = Path(js(SECOND / "mutants/Nonisolated_fock/bracket_sign/execution/execution.json")["command"][0]).resolve()
contexts, preflight = {}, []
for case in fock["mutations"]:
    old_source = (S / case["original_source"]).read_bytes()
    specimen = Q / "mutant_specimens/Nonisolated_fock" / (case["name"] + ".py")
    new_source = specimen.read_bytes()
    original = (S / case["original_stderr"]).read_bytes()
    assert sha(original) == case["original_stderr_sha256"]
    assert sha(old_source) == case["original_source_sha256"]
    compile(ast.parse(new_source), str(specimen), "exec")
    old_lines, new_lines = old_source.decode().splitlines(), new_source.decode().splitlines()
    line_map = {}
    for block in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_matching_blocks():
        for offset in range(block.size):
            line_map[block.a + offset + 1] = block.b + offset + 1
    rows = original.decode().splitlines(keepends=True)
    frames, canonical_lines, representative, substantive = [], [], [], []
    index = 0
    while index < len(rows):
        match = re.fullmatch(r'  File "([^"]+)", line (\d+), in ([^\n]+)\n', rows[index])
        if not match:
            assert not re.fullmatch(r'[ \t]*[~^][~^ \t]*\n', rows[index]), "Marker outside inventoried frame"
            canonical_lines.append(rows[index]); representative.append(rows[index]); substantive.append(rows[index]); index += 1
            continue
        path, old_line, function = match.group(1), int(match.group(2)), match.group(3)
        assert path == str(S / case["original_source"]) and old_line in line_map
        source_line = rows[index + 1]
        assert source_line == "    " + old_lines[old_line - 1].strip() + "\n"
        assert old_lines[old_line - 1] == new_lines[line_map[old_line] - 1]
        canonical_header = '  File "TARGET_SOURCE.py", line ' + str(line_map[old_line]) + ', in ' + function + '\n'
        canonical_lines.extend([canonical_header, source_line]); representative.extend([canonical_header, source_line]); substantive.extend([canonical_header, source_line])
        frame = dict(original_path=path, original_line=old_line, canonical_line=line_map[old_line], function=function,
                     source_line=source_line, original_underlines=[])
        index += 2
        if index < len(rows) and re.fullmatch(r'[ \t]*[~^][~^ \t]*\n', rows[index]):
            assert len(rows[index].rstrip("\n")) <= len(source_line.rstrip("\n")) and rows[index].startswith("    ")
            frame["original_underlines"].append(rows[index]); canonical_lines.append(rows[index]); index += 1
        # A representative optional underline is text only, not an observed run.
        width = len(source_line.rstrip("\n")) - 4
        prototype = "    " + "~" * max(width - 2, 0) + "^" * min(width, 2) + "\n"
        representative.append(prototype)
        frames.append(frame)
    if case["expected_exit"] == 1:
        assert len(frames) == 2 and frames[0]["function"] == "<module>" and "assert " in frames[1]["source_line"]
        assert substantive[0] == "Traceback (most recent call last):\n" and substantive[-1] == "AssertionError\n"
    else:
        assert not original and not frames
    canonical = "".join(canonical_lines).encode(); simulated = "".join(representative).encode(); plain = "".join(substantive).encode()
    # Independent source-only rendering check: only inventoried markers differ.
    strip = lambda data: b"".join(line for line in data.splitlines(keepends=True) if not re.fullmatch(rb'[ \t]*[~^][~^ \t]*\n', line))
    assert strip(canonical) == strip(simulated) == plain
    destination = R / "traceback_preflight" / case["name"]
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "original.stderr").write_bytes(original)
    (destination / "canonical_path_template.stderr").write_bytes(canonical)
    (destination / "synthetic_optional_underlines.stderr").write_bytes(simulated)
    receipt = js(S / case["original_receipt"])
    contexts[case["name"]] = dict(original_stderr_sha256=sha(original), original_source_sha256=sha(old_source),
        canonical_specimen_sha256=sha(new_source), expected_exit=case["expected_exit"],
        original_command_interpreter=receipt["command"][0], historical_interpreter_version="not recorded; not inferred",
        current_bundled_symlink_resolution_observation=str(Path(receipt["command"][0]).resolve()), frames=frames)
    preflight.append(dict(case=case["name"], frames=len(frames), original_stderr_sha256=sha(original),
        canonical_path_template_sha256=sha(canonical), synthetic_optional_underlines_sha256=sha(simulated),
        same_substantive_bytes_sha256=sha(plain), scientific_execution=False, synthetic_fixture_is_not_an_observation=True))
assert sum(len(x["frames"]) for x in contexts.values()) == 18
actual = (SECOND / "mutants/Nonisolated_fock/bracket_sign/execution/stderr").read_bytes()
expected = (SECOND / "mutants/Nonisolated_fock/bracket_sign/stderr.expected").read_bytes()
known = b"    ~~~~~~~~~~~~~~~~~^^\n"
assert actual == expected.replace(b"    free_word_control()\n", b"    free_word_control()\n" + known, 1)
assert actual.count(known) == 1
write(R / "TRACEBACK_CONTEXTS.json", dict(current_interpreter=binding(current), cases=contexts,
    original_version_correction="Root's Python3.11 label was an unverified inference, withdrawn. Current bundled command resolves to python3.12; no historical version inferred.",
    policy="At most one optional standalone caret/tilde line immediately beneath each exact inventoried frame/source line; all other bytes exact"))
write(R / "STATIC_PREFLIGHT.json", dict(status="source_only_complete", cases=preflight,
    actual_second_failure=dict(manifest_sha256=attempts[1][1], stderr_sha256=sha(actual), expected_sha256=sha(expected), exact_added_line=known.decode()),
    verifier_or_science_executed=False, new_execution_plan=dict(canonical=2, mutants=22),
    reused_execution_plan=dict(canonical=3, mutants=10), original_failures_unchanged=True, editable_prompt_files_changed=[]))
tree = ast.parse(PROGRAM.read_bytes()); compile(tree, str(PROGRAM), "exec")
assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("load", "loads")
               and isinstance(n.func.value, ast.Name) and n.func.value.id == "pickle" for n in ast.walk(tree))
for sp in specs:
    cache = W / "logs/runner-cache" / (Path(sp["runner"]).stem + ".txt")
    if sp["key"] in ["Boost", "Gapped", "Nonisolated_fock"]:
        assert cache.read_bytes() == (OLD / "canonical" / sp["key"] / "cache.complete.txt").read_bytes(); files.add(cache)
    else:
        assert not cache.exists()
diff = "".join(difflib.unified_diff(PRIOR.read_text().splitlines(True), PROGRAM.read_text().splitlines(True), fromfile=PRIOR.name, tofile=PROGRAM.name))
(R / "finisher_source_changes.diff").write_text(diff)
inherited = js(Q / "SOURCE_FREEZE.json")
files.update([VERIFIER, PRIOR, Q / "SOURCE_FREEZE.json", R1 / "SOURCE_FREEZE.json", current])
files.update(p for p in R.rglob("*") if p.is_file() and p.name not in ["SOURCE_FREEZE.json", "FREEZE_RECEIPT.json"] and "runs" not in p.relative_to(R).parts)
template = re.sub(rb'FREEZE_SHA256 = "[^"]+"', b'FREEZE_SHA256 = "TO_BE_FROZEN"', PROGRAM.read_bytes(), count=1)
freeze = dict(base_revision=inherited["base_revision"], worktree=str(W),
    prior_attempt_manifest_sha256=attempts[0][1], second_attempt_manifest_sha256=attempts[1][1],
    finisher_template_sha256=sha(template), interpreter=binding(current), files=[binding(p) for p in sorted(files)],
    inherited_full_source_and_specimen_bindings=inherited["files"],
    inherited_binding_policy="Original verifier checks every source/specimen binding; only its reviewed post-graph manifest exception applies",
    both_old_attempts_and_existing_caches="immutable", status="unexecuted")
write(R / "SOURCE_FREEZE.json", freeze)
freeze_sha = sha((R / "SOURCE_FREEZE.json").read_bytes())
PROGRAM.write_bytes(template.replace(b'FREEZE_SHA256 = "TO_BE_FROZEN"', ('FREEZE_SHA256 = "' + freeze_sha + '"').encode(), 1))
compile(ast.parse(PROGRAM.read_bytes()), str(PROGRAM), "exec")
receipt = dict(finisher_sha256=sha(PROGRAM.read_bytes()), freeze_sha256=freeze_sha, finisher_lines=len(PROGRAM.read_text().splitlines()),
    direct_bindings=len(files), inherited_bindings=len(inherited["files"]), inventoried_failure_frames=18,
    new_science_executions_planned=24, previous_science_repeated=0, status="unexecuted")
write(R / "FREEZE_RECEIPT.json", receipt);print(json.dumps(receipt))
