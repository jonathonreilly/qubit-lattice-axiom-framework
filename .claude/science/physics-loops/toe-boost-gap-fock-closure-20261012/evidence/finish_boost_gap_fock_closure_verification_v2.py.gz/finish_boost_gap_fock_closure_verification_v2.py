#!/usr/bin/env python3
"""Root-executed recovery; prepare without executing this file or any science.

Reuse three canonical executions and ten mutants from two frozen failed attempts.
Fock permits only the approved first environment-version line and inventoried
standalone traceback underlines. All substantive bytes and failure gates stay exact.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import traceback
import uuid

S = Path(__file__).resolve().parent
Q = S / "boost_gap_fock_closure_verification_preparation"
R = S / "boost_gap_fock_closure_verification_recovery_v2"
OLD = Q / "runs/20261012T082449_7c155832925d"
SECOND = S / "boost_gap_fock_closure_verification_recovery/runs/20261012T083953_62636d2de815"
VERIFIER = S / "verify_boost_gap_fock_closure_publication.py"
FREEZE_SHA256 = "c62a0f484489d1b175b382f72f08b8b4ac1771f600036981e886021a5d716976"
OLD_LINE = b'{"check": "environment", "numpy_version": "2.3.5"}\n'
NEW_LINE = b'{"check": "environment", "numpy_version": "2.4.4"}\n'
sys.dont_write_bytecode = True


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def raw(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "Missing/nonregular input: " + str(path))
    return path.read_bytes()


def js(path):
    return json.loads(raw(path))


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def check_recovery_freeze(freeze):
    need(sha(raw(R / "SOURCE_FREEZE.json")) == FREEZE_SHA256, "Recovery freeze drift")
    normalized = re.sub(rb'FREEZE_SHA256 = "[^"]+"', b'FREEZE_SHA256 = "TO_BE_FROZEN"', raw(__file__), count=1)
    need(sha(normalized) == freeze["finisher_template_sha256"], "Recovery source drift")
    for row in freeze["files"]:
        data = raw(row["path"])
        need((len(data), sha(data)) == (row["bytes"], row["sha256"]), "Recovery input drift: " + row["path"])
    need(Path(sys.executable).resolve() == Path(freeze["interpreter"]["path"]), "Recovery must use the same recorded interpreter binary")


def validate_old_manifest(freeze, copied=None):
    manifest = js(OLD / "EVIDENCE_MANIFEST.json")
    need(sha(raw(OLD / "EVIDENCE_MANIFEST.json")) == freeze["prior_attempt_manifest_sha256"], "Prior attempt manifest changed")
    rows = manifest["files"]
    relative = []
    for row in rows:
        path = Path(row["path"])
        need(path.is_relative_to(OLD), "Prior manifest path escapes attempt")
        rel = path.relative_to(OLD)
        relative.append(str(rel))
        data = raw(path)
        need((len(data), sha(data)) == (row["bytes"], row["sha256"]), "Prior attempt file drift")
        if copied is not None:
            need(raw(copied / rel) == data, "Copied prior evidence differs")
    need(len(relative) == len(set(relative)), "Duplicate prior manifest paths")
    expected = sorted(relative + ["EVIDENCE_MANIFEST.json"])
    need(sorted(str(p.relative_to(OLD)) for p in OLD.rglob("*") if p.is_file()) == expected, "Prior attempt membership drift")
    if copied is not None:
        need(raw(copied / "EVIDENCE_MANIFEST.json") == raw(OLD / "EVIDENCE_MANIFEST.json"), "Copied prior manifest differs")
        need(sorted(str(p.relative_to(copied)) for p in copied.rglob("*") if p.is_file()) == expected, "Copied evidence membership differs")
    return rows


def validate_second_manifest(freeze, copied=None):
    path = SECOND / "EVIDENCE_MANIFEST.json"
    need(sha(raw(path)) == freeze["second_attempt_manifest_sha256"], "Second attempt manifest changed")
    rows = js(path)["files"]
    relative = []
    for row in rows:
        source = Path(row["path"])
        need(source.is_relative_to(SECOND), "Second manifest path escapes attempt")
        rel = source.relative_to(SECOND)
        relative.append(str(rel))
        data = raw(source)
        need((len(data), sha(data)) == (row["bytes"], row["sha256"]), "Second attempt file drift")
        if copied is not None:
            need(raw(copied / rel) == data, "Copied second evidence differs")
    need(len(relative) == len(set(relative)), "Duplicate second manifest paths")
    expected = sorted(relative + ["EVIDENCE_MANIFEST.json"])
    need(sorted(str(p.relative_to(SECOND)) for p in SECOND.rglob("*") if p.is_file()) == expected, "Second attempt membership drift")
    if copied is not None:
        need(raw(copied / "EVIDENCE_MANIFEST.json") == raw(path), "Copied second manifest differs")
        need(sorted(str(p.relative_to(copied)) for p in copied.rglob("*") if p.is_file()) == expected, "Copied second membership differs")
    return rows


def normalized_traceback(data, frames, target):
    """Remove only one optional standalone diagnostic underline per exact frame.

    Frame paths/line numbers/names and displayed source lines must match the
    frozen context inventory. Every other byte, including assertion messages,
    remains in the compared stream. This never changes an original artifact.
    """
    lines = data.decode().splitlines(keepends=True)
    kept, removed, seen = [], [], []
    index = 0
    while index < len(lines):
        line = lines[index]
        match = re.fullmatch(r'  File "([^"]+)", line (\d+), in ([^\n]+)\n', line)
        if match:
            frame_index = len(seen)
            need(frame_index < len(frames), "Unexpected traceback frame")
            frame = frames[frame_index]
            need(match.group(1) == str(target) and int(match.group(2)) == frame["canonical_line"]
                 and match.group(3) == frame["function"], "Traceback source/frame identity changed")
            need(index + 1 < len(lines) and lines[index + 1] == frame["source_line"], "Traceback displayed source/assertion changed")
            kept.extend(lines[index:index + 2])
            seen.append(frame)
            index += 2
            if index < len(lines) and re.fullmatch(r'[ \t]*[~^][~^ \t]*\n', lines[index]):
                underline = lines[index]
                need(len(underline.rstrip("\n")) <= len(frame["source_line"].rstrip("\n"))
                     and underline.startswith("    "), "Diagnostic underline escapes its displayed source width")
                removed.append({"frame": frame, "target": str(target), "line": underline,
                                "position_in_complete_stream": index + 1})
                index += 1
            continue
        # A standalone marker outside an inventoried frame is never ignored.
        kept.append(line)
        index += 1
    need(seen == frames, "Missing or reordered traceback frames")
    return "".join(kept).encode(), removed


def compare_fock_stderr(v, folder, actual, expected, case_name, target, original_compare):
    inventory = js(R / "TRACEBACK_CONTEXTS.json")
    case = inventory["cases"][case_name]
    need(Path(sys.executable).resolve() == Path(inventory["current_interpreter"]["path"]), "Unapproved current traceback renderer")
    # The original command/path and byte hash are pinned, with no invented old version.
    old_receipt = js(folder / "original.receipt.json")
    need(old_receipt["command"][0] == case["original_command_interpreter"]
         and sha(raw(folder / "original.stderr")) == case["original_stderr_sha256"], "Unapproved original traceback context")
    actual_normal, actual_markers = normalized_traceback(actual, case["frames"], target)
    expected_normal, expected_markers = normalized_traceback(expected, case["frames"], target)
    (folder / "stderr.unmapped.actual").write_bytes(actual)
    (folder / "stderr.unmapped.expected").write_bytes(expected)
    (folder / "stderr.normalized.actual").write_bytes(actual_normal)
    (folder / "stderr.normalized.expected").write_bytes(expected_normal)
    write(folder / "stderr.presentation_mapping.json", {
        "authority": "Root approved only standalone caret/tilde diagnostic underlines within exact inventoried Fock failure frames",
        "case": case_name, "original_command_interpreter": case["original_command_interpreter"],
        "historical_original_version": "not encoded in the historical receipt; not inferred",
        "current_interpreter": inventory["current_interpreter"],
        "removed_from_current_comparison": actual_markers, "removed_from_expected_comparison": expected_markers,
        "actual_sha256": sha(actual), "expected_sha256": sha(expected),
        "normalized_actual_sha256": sha(actual_normal), "normalized_expected_sha256": sha(expected_normal),
        "preserved": "Every frame/source/assertion/exception/value/exit gate and all original or unmapped bytes", "pairing": v.PAIRING})
    return original_compare(folder, "stderr", actual_normal, expected_normal)


def mapped_fock_expected(v, folder, expected):
    need(expected.startswith(OLD_LINE), "Fock original environment line differs from the sole approved mapping")
    mapped = NEW_LINE + expected[len(OLD_LINE):]
    (folder / "stdout.unmapped.expected").write_bytes(expected)
    write(folder / "stdout.environment_mapping.json", {
        "authority": "Root explicitly approved only first environment JSON line numpy_version 2.3.5 to 2.4.4 after reading the preserved failure diff",
        "source_of_decision": "Recovery task instruction; no scientific correction or tolerance change",
        "line_number": 1, "json_field": "numpy_version", "before_line": OLD_LINE.decode(), "after_line": NEW_LINE.decode(),
        "unmapped_expected_sha256": sha(expected), "mapped_expected_sha256": sha(mapped),
        "unchanged_remainder_sha256": sha(expected[len(OLD_LINE):]),
        "original_artifacts_modified": False, "pairing": v.PAIRING,
    })
    return mapped


@contextmanager
def fock_comparison_mapping(v, run, permitted_names):
    original_compare = v.compare
    permitted = {run / "mutants/Nonisolated_fock" / name for name in permitted_names}

    def compare(folder, label, actual, expected):
        if Path(folder) in permitted and label == "stdout":
            expected = mapped_fock_expected(v, folder, expected)
        if Path(folder) in permitted and label == "stderr":
            return compare_fock_stderr(v, folder, actual, expected, Path(folder).name, Path(folder) / "source.py", original_compare)
        return original_compare(folder, label, actual, expected)

    # Comparison only: Evidence.read/save, primary sources and execution remain unchanged.
    v.compare = compare
    try:
        yield
    finally:
        v.compare = original_compare


def preserve_originals(v, evidence, source, folder, pairs):
    for relative, filename in pairs:
        expected = evidence.read(relative)
        need(raw(source / filename) == expected, "Saved original differs from frozen publication evidence: " + relative)
        evidence.save(relative, folder, filename)


def copy_observation(v, source, folder):
    for name in ("observation.start.json", "observation.return.json", "calculation.raw.json"):
        shutil.copyfile(source / name, folder / name)
        need(raw(source / name) == raw(folder / name), "Observation copy drift")
    need(not (source / "observation.error.json").exists(), "Saved observation reported an error")


def revalidate_canonical(v, sp, row, baseline, evidence, worktree, run, copied, runner_cache):
    source = copied / "canonical" / sp["key"]
    folder = run / "revalidation/canonical" / sp["key"]
    folder.mkdir(parents=True)
    original_pairs = [(sp["baseline_stdout"], "original.stdout"), (baseline["stderr"], "original.stderr"), (baseline["receipt"], "original.receipt.json")]
    if sp.get("baseline_result"):
        original_pairs.append((sp["baseline_result"], "original.result.json"))
    preserve_originals(v, evidence, source, folder, original_pairs)
    # Read tagged JSON only. Pickles remain opaque, hash-bound raw evidence.
    inner = js(source / "INNER_execute_runner.raw.json")
    outer = js(source / "OUTER_execute_and_write_cache.raw.json")
    need(outer["__type__"] == "tuple" and len(outer["items"]) == 2 and outer["items"][0] == inner, "Saved INNER/OUTER return mismatch")
    path = "scripts/" + sp["runner"]
    target, cache = worktree / path, worktree / "logs/runner-cache" / (Path(sp["runner"]).stem + ".txt")
    need(inner["runner"] == path and inner["status"] == "ok" and inner["exit_code"] == 0 and inner["timeout_sec"] == 60, "Saved canonical was not successful")
    need(outer["items"][1] == {"__type__": "PosixPath", "value": str(cache)}, "Saved OUTER cache path mismatch")
    need(raw(source / "stdout") == inner["stdout"].encode() and raw(source / "stderr") == inner["stderr"].encode(), "Saved streams differ from raw API returns")
    need(raw(cache) == raw(source / "cache.complete.txt"), "Current canonical cache differs from the saved complete cache")
    _, cache_body = raw(cache).decode().split("----- stdout -----\n", 1)
    cache_stdout, cache_stderr = cache_body.rsplit("\n----- stderr -----\n", 1)
    need(cache_stdout == inner["stdout"][-200000:] and cache_stderr == inner["stderr"][-50000:] + "\n",
         "Saved cache body differs from its raw returned streams")
    command = js(source / "subprocess.command.json")
    need(command["actual"] == command["expected_unmodified_api_command"]
         and command["actual"][1:] == ["-u", str(target)] and Path(command["actual"][0]).resolve() == Path(sys.executable).resolve(), "Saved canonical command mismatch")
    calculation = evidence.json(sp["baseline_result"]) if sp.get("baseline_result") else None
    expected = raw(folder / "original.stdout") + v.suffix(row, calculation, True)
    if sp["key"] == "Nonisolated_fock":
        expected = mapped_fock_expected(v, folder, expected)
    v.compare(folder, "stdout", raw(source / "stdout"), expected)
    v.compare(folder, "stderr", raw(source / "stderr"), raw(folder / "original.stderr"))
    context = js(source / "execution_context.json")
    if calculation is not None:
        copy_observation(v, source, folder)
        measured = v.compare_calculation(sp, folder, calculation, target, 0, context["started_utc"], context["finished_utc"])
    else:
        records = [json.loads(line) for line in raw(folder / "original.stdout").splitlines()]
        need(len(records) == sp["baseline_totals"]["original_json_records"] == 7
             and records[-1]["check"] == "completion" and records[-1]["status"] == "complete", "Original Fock driver did not complete")
        measured = {"passed": 1, "failed": 0, "semantics": "One completed assertion driver; no predicate count promotion"}
    # The complete pinned raw returns/streams were checked before any freshness API call.
    freshness = {"cache_status": runner_cache.cache_status(path), "identity_status": runner_cache.cache_identity_status(path),
                 "runner_sha256": runner_cache.runner_sha256(path), "input_fingerprint_sha256": runner_cache.declared_input_fingerprint(path)}
    write(folder / "cache_freshness.json", freshness)
    need(freshness["cache_status"] == freshness["identity_status"] == "fresh", "Saved canonical cache is stale/unusable")
    result = {"key": sp["key"], "fresh_execution": False, "reused_execution": str(OLD / "canonical" / sp["key"]),
              "copied_evidence": str(source), "status": "revalidated_complete_original_execution", "totals": measured,
              "elapsed_sec": inner["elapsed_sec"], "timeout_sec": inner["timeout_sec"], "cache": str(cache), "pairing": v.PAIRING}
    write(folder / "reuse_receipt.json", result)
    return result


def revalidate_mutant(v, sp, case, row, evidence, worktree, run, copied):
    source = copied / "mutants" / sp["key"] / case["name"]
    folder = run / "revalidation/mutants" / sp["key"] / case["name"]
    folder.mkdir(parents=True)
    # All nine reused cases are the exact active CLI variants, never literal rewrites.
    need(sp["mutation_kind"] == "original_cli_variant" and "before" not in case, "Unexpected reused mutation kind")
    target = OLD / "mutants" / sp["key"] / case["name"] / "source.py"
    need(raw(target) == raw(source / "source.py") == raw(Q / "mutant_specimens" / sp["key"] / (case["name"] + ".py"))
         == raw(worktree / "scripts" / sp["runner"]), "Reused whole-primary source differs")
    pairs = [(case[field], filename) for field, filename in (("original_stdout", "original.stdout"),
             ("original_stderr", "original.stderr"), ("original_receipt", "original.receipt.json"), ("original_result", "original.result.json"))]
    preserve_originals(v, evidence, source, folder, pairs)
    receipt = js(source / "execution/execution.json")
    v.require_exit(receipt, case["expected_exit"])
    need(receipt["timeout_seconds"] == case["original_timeout_seconds"] and receipt["command"][1:] == ["-u", str(target), *case["argv"]]
         and Path(receipt["command"][0]).resolve() == Path(sys.executable).resolve(), "Reused mutant command/timeout mismatch")
    for stream in ("stdout", "stderr"):
        data = raw(source / "execution" / stream)
        need((len(data), sha(data)) == (receipt[stream + "_bytes"], receipt[stream + "_sha256"]), "Saved mutant stream/receipt mismatch")
    calculation = evidence.json(case["original_result"])
    measured = v.totals(sp, calculation)
    need(measured == {"passed": case["expected_passed"], "failed": case["expected_failed"]}
         and int(measured["failed"] != 0) == case["expected_exit"], "Frozen mutant gate mismatch")
    v.compare(folder, "stdout", raw(source / "execution/stdout"), raw(folder / "original.stdout") + v.suffix(row, calculation, True))
    original_source = evidence.read(sp["folder"] + "/" + sp["helper"])
    need(raw(source / "original.source.py") == original_source, "Saved original complete helper differs")
    expected_stderr = v.mapped_stderr(raw(folder / "original.stderr"), original_source, raw(target),
                                    S / sp["folder"] / sp["helper"], target, folder)
    v.compare(folder, "stderr", raw(source / "execution/stderr"), expected_stderr)
    copy_observation(v, source, folder)
    v.compare_calculation(sp, folder, calculation, target, case["expected_exit"], receipt["started_utc"], receipt["finished_utc"])
    result = {"key": sp["key"], "name": case["name"], "fresh_execution": False,
              "reused_execution": str(target.parent), "survived_original_gate": case["survived"],
              "exit_code": receipt["exit_code"], "elapsed_seconds": receipt["elapsed_seconds"],
              "timeout_seconds": receipt["timeout_seconds"], "timed_out": receipt["timed_out"],
              "complete_streams_match": True, "source_sha256": sha(raw(target)), "pairing": v.PAIRING}
    write(folder / "reuse_receipt.json", result)
    return result


def revalidate_bracket(v, sp, case, row, evidence, run, copied_second):
    source = copied_second / "mutants/Nonisolated_fock/bracket_sign"
    target = SECOND / "mutants/Nonisolated_fock/bracket_sign/source.py"
    folder = run / "revalidation/second_attempt/bracket_sign"
    folder.mkdir(parents=True)
    need(case["name"] == "bracket_sign" and case["expected_exit"] == 1 and not case["survived"], "Unexpected reused Fock case")
    specimen = Q / "mutant_specimens/Nonisolated_fock/bracket_sign.py"
    need(raw(target) == raw(source / "source.py") == raw(specimen), "Saved bracket whole-source mutant differs")
    original_source = evidence.read(sp["folder"] + "/" + sp["helper"]).decode()
    original_source = v.edited(original_source, case["before"], case["after"], case["replacements"], case["name"]).encode()
    need(raw(source / "original.source.py") == original_source == evidence.read(case["original_source"]), "Saved original bracket source differs")
    pairs = [(case[field], name) for field, name in (("original_stdout", "original.stdout"),
             ("original_stderr", "original.stderr"), ("original_receipt", "original.receipt.json"))]
    preserve_originals(v, evidence, source, folder, pairs)
    receipt = js(source / "execution/execution.json")
    v.require_exit(receipt, 1)
    need(receipt["command"][1:] == ["-u", str(target)] and Path(receipt["command"][0]).resolve() == Path(sys.executable).resolve()
         and receipt["timeout_seconds"] == case["original_timeout_seconds"], "Saved bracket command or timeout changed")
    for stream in ("stdout", "stderr"):
        data = raw(source / "execution" / stream)
        need((len(data), sha(data)) == (receipt[stream + "_bytes"], receipt[stream + "_sha256"]), "Saved bracket stream/receipt mismatch")
    expected_stdout = mapped_fock_expected(v, folder, raw(folder / "original.stdout"))
    v.compare(folder, "stdout", raw(source / "execution/stdout"), expected_stdout)
    expected_stderr = v.mapped_stderr(raw(folder / "original.stderr"), original_source, raw(target), S / case["original_source"], target, folder)
    compare_fock_stderr(v, folder, raw(source / "execution/stderr"), expected_stderr, "bracket_sign", target, v.compare)
    result = {"key": sp["key"], "name": "bracket_sign", "fresh_execution": False,
              "reused_execution": str(target.parent), "survived_original_gate": False,
              "exit_code": 1, "elapsed_seconds": receipt["elapsed_seconds"], "timeout_seconds": receipt["timeout_seconds"],
              "timed_out": False, "source_sha256": sha(raw(target)),
              "comparison_scope": "Full streams under the exact environment-line and inventoried diagnostic-underline maps",
              "original_failure_status_preserved": True, "pairing": v.PAIRING}
    write(folder / "reuse_receipt.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--base", required=True)
    args = parser.parse_args()
    need(__debug__ and not os.environ.get("PYTHONOPTIMIZE"), "Assertions must be enabled")
    freeze = js(R / "SOURCE_FREEZE.json")
    check_recovery_freeze(freeze)
    worktree, base = args.worktree.resolve(), args.base
    need(str(worktree) == freeze["worktree"] and base == freeze["base_revision"], "Explicit worktree/base mismatch")
    v = load_module("boost_gap_fock_frozen_verifier", VERIFIER)  # __main__ guard remains false.
    need(not any(k in os.environ for k in v.OBS_KEYS), "Unexpected observation environment")
    original_freeze = js(Q / "SOURCE_FREEZE.json")
    v.check_freeze(original_freeze, worktree)
    prior_rows = validate_old_manifest(freeze)
    second_rows = validate_second_manifest(freeze)
    run = R / "runs" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:12])
    run.mkdir(parents=True, exist_ok=False)
    state = {"status": "running", "base": base, "worktree": str(worktree), "run": str(run),
             "prior_attempt": str(OLD), "prior_attempt_manifest_sha256": freeze["prior_attempt_manifest_sha256"],
             "second_attempt": str(SECOND), "second_attempt_manifest_sha256": freeze["second_attempt_manifest_sha256"],
             "pairing": v.PAIRING, "global_combined_audit": "not_run_separate_landing_gate",
             "strict_audit_lint": "not_run_separate_landing_gate", "audit_verdict": "not_applied",
             "independent_controls": "existing_source_bound_evidence_not_rerun", "editable_prompt_files_changed": []}
    write(run / "status.json", state)
    try:
        copied = run / "reused_attempt"
        shutil.copytree(OLD, copied)
        validate_old_manifest(freeze, copied)
        copied_second = run / "reused_second_attempt"
        shutil.copytree(SECOND, copied_second)
        validate_second_manifest(freeze, copied_second)
        need(sorted(str(p.relative_to(SECOND / "mutants")) for p in (SECOND / "mutants").glob("*/*")) == ["Nonisolated_fock/bracket_sign"],
             "Unexpected additional second-attempt science")
        write(run / "second_copy_bindings.json", {"manifest_sha256": freeze["second_attempt_manifest_sha256"],
              "files": [{"original": x["path"], "copy": str(copied_second / Path(x["path"]).relative_to(SECOND)),
                         "bytes": x["bytes"], "sha256": x["sha256"]} for x in second_rows], "pairing": v.PAIRING})
        write(run / "prior_copy_bindings.json", {"manifest_sha256": freeze["prior_attempt_manifest_sha256"],
              "files": [{"original": x["path"], "copy": str(copied / Path(x["path"]).relative_to(OLD)),
                         "bytes": x["bytes"], "sha256": x["sha256"]} for x in prior_rows], "pairing": v.PAIRING})
        packet = worktree / v.PACKET
        specs = v.js(packet / "SPECIFICATIONS.json")["specs"]
        maps = v.js(packet / "PUBLICATION_EDITS.json")
        contract = js(Q / "VERIFICATION_CONTRACT.json")
        evidence = v.Evidence(packet)
        lookup = {sp["key"]: sp for sp in specs}
        reused_keys, new_keys = ["Boost", "Gapped", "Nonisolated_fock"], ["Weighted_current", "Integrated_boost"]
        need(sorted(x.name for x in (OLD / "canonical").iterdir()) == sorted(reused_keys), "Prior canonical membership differs")
        need(sorted(x.name for x in (OLD / "mutants").iterdir()) == ["Boost", "Gapped"], "Unexpected prior mutant family")
        for key in ["Boost", "Gapped"]:
            need(sorted(x.name for x in (OLD / "mutants" / key).iterdir()) == sorted(c["name"] for c in lookup[key]["mutations"]), "Prior mutant membership incomplete")
        caches = {sp["key"]: "logs/runner-cache/" + Path(sp["runner"]).stem + ".txt" for sp in specs}
        need(all(not (worktree / caches[key]).exists() for key in new_keys), "Pending canonical cache exists; refuse to repeat execution")
        v.check_scope(worktree, base, run, "scope_before", original_freeze["publication_paths"], [caches[k] for k in reused_keys])
        base_manifest = v.git_read(worktree, run, "base_manifest", "show", base + ":" + v.GRAPH_MANIFEST)
        need(base_manifest == raw(Q / "base_graph_manifest.json") == raw(worktree / v.GRAPH_MANIFEST), "Base graph manifest drift")
        for label in ["before_vocabulary", "after_vocabulary_fix", "after_vocabulary_report"]:
            if label != "before_vocabulary":
                mode = "fix" if label == "after_vocabulary_fix" else "report-only"
                report_path = run / ("vocabulary_" + mode + ".json")
                targets = [r["publication_path"] for r in maps["outputs"]] + [str(p.relative_to(worktree)) for p in sorted(packet.glob("*.md"))] + [v.PACKET + "/reconstruct.py"]
                receipt, _, _ = v.log_run(run / ("vocabulary_" + mode), [sys.executable, "scripts/vocab_lint.py", "--" + mode, "--report-path", str(report_path), *targets], 60, worktree)
                v.require_exit(receipt)
                report = js(report_path)
                need(report["summary"] == {"files_with_violations": 0, "total_auto_correctable": 0, "total_needs_human": 0} and report["files"] == [], "Vocabulary changed/found an unmapped surface")
            receipt, _, _ = v.log_run(run / ("reconstruction_" + label), [sys.executable, str(packet / "reconstruct.py")], 60, worktree)
            v.require_exit(receipt)
            v.check_freeze(original_freeze, worktree)
        v.metadata_links(worktree, packet, specs, maps, evidence, run)
        for sp in specs:
            v.validate_mutation_authority(sp, evidence)
        # Pure evidence reconstruction; no materialized helper executes.
        v.materializations(lookup["Integrated_boost"], evidence, run)
        sys.path.insert(0, str(worktree / "scripts"))
        runner_cache = load_module("runner_cache", worktree / "scripts/runner_cache.py")
        canonicals, mutations = [], []
        for key in reused_keys:
            sp = lookup[key]
            row = next(r for r in maps["outputs"] if r["publication_path"] == "scripts/" + sp["runner"])
            canonicals.append(revalidate_canonical(v, sp, row, contract["baselines"][key], evidence, worktree, run, copied, runner_cache))
            if key != "Nonisolated_fock":
                mutations.extend(revalidate_mutant(v, sp, c, row, evidence, worktree, run, copied) for c in sp["mutations"])
        fock = lookup["Nonisolated_fock"]
        fock_row = next(r for r in maps["outputs"] if r["publication_path"] == "scripts/" + fock["runner"])
        mutations.append(revalidate_bracket(v, fock, next(c for c in fock["mutations"] if c["name"] == "bracket_sign"), fock_row, evidence, run, copied_second))
        need(len(canonicals) == 3 and len(mutations) == 10, "Wrong reused execution totals")
        write(run / "reused_execution_summary.json", {"canonicals": canonicals, "mutations": mutations, "new_science_runs": 0, "pairing": v.PAIRING})
        old_dontwrite = os.environ.get("PYTHONDONTWRITEBYTECODE")
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        try:
            with fock_comparison_mapping(v, run, [c["name"] for c in lookup["Nonisolated_fock"]["mutations"]]):
                for key in ["Nonisolated_fock", *new_keys]:
                    sp = lookup[key]
                    row = next(r for r in maps["outputs"] if r["publication_path"] == "scripts/" + sp["runner"])
                    if key in new_keys:
                        value = v.canonical(sp, row, contract["baselines"][key], evidence, worktree, run, runner_cache)
                        canonicals.append({**value, "fresh_execution": True})
                    for case in sp["mutations"]:
                        if key == "Nonisolated_fock" and case["name"] == "bracket_sign":
                            continue  # Already executed once and revalidated above.
                        value = v.mutant(sp, case, row, evidence, worktree, run)
                        mutations.append({**value, "fresh_execution": True,
                            "comparison_scope": "Exact data under approved environment-line and inventoried diagnostic-underline maps" if key == "Nonisolated_fock" else "Exact original scientific streams plus mapped publication suffix"})
                    v.check_freeze(original_freeze, worktree)
        finally:
            if old_dontwrite is None:
                os.environ.pop("PYTHONDONTWRITEBYTECODE", None)
            else:
                os.environ["PYTHONDONTWRITEBYTECODE"] = old_dontwrite
        survivors = {sp["key"]: [x["name"] for x in mutations if x["key"] == sp["key"] and x["survived_original_gate"]] for sp in specs}
        need(all(survivors[sp["key"]] == sp["expected_mutation_survivors"] for sp in specs), "Known mutation survivors changed")
        need(len(canonicals) == 5 and len(mutations) == sum(sp["mutation_count"] for sp in specs) == 32
             and sum(x["fresh_execution"] for x in canonicals) == 2 and sum(x["fresh_execution"] for x in mutations) == 22
             and sum(map(len, survivors.values())) == 4, "Recovery execution membership differs")
        write(run / "canonical_summary.json", canonicals)
        write(run / "mutation_summary.json", {"cases": mutations, "survivors": survivors, "total": 32, "reused": 10, "new": 22, "pairing": v.PAIRING})
        delta, compatibility = v.graph_and_compatibility(worktree, base, specs, run)
        v.check_freeze(original_freeze, worktree, graph_written=True)
        v.check_scope(worktree, base, run, "scope_after", original_freeze["publication_paths"], [v.GRAPH_MANIFEST, *caches.values()])
        receipt, _, _ = v.log_run(run / "reconstruction_final", [sys.executable, str(packet / "reconstruct.py")], 60, worktree)
        v.require_exit(receipt)
        freshness = {"scripts/" + sp["runner"]: runner_cache.cache_status("scripts/" + sp["runner"]) for sp in specs}
        write(run / "final_cache_status.json", freshness)
        need(set(freshness.values()) == {"fresh"}, "Final cache identity/usable status differs")
        check_recovery_freeze(freeze)  # Original three caches and all old evidence remain unchanged.
        validate_old_manifest(freeze, copied)
        validate_second_manifest(freeze, copied_second)
        final_paths = [worktree / x for x in original_freeze["publication_paths"]] + [worktree / v.GRAPH, worktree / v.GRAPH_MANIFEST] + [worktree / x for x in caches.values()]
        write(run / "publication_source_manifest.json", {"base": base, "files": [v.binding(p) for p in sorted(final_paths)],
              "scope": "Verification state only; final publication metadata/evidence integration remains root-owned", "pairing": v.PAIRING})
        state.update(status="completed", canonical_count=5, reused_canonicals=3, new_canonicals=2,
                     actual_mutations=32, reused_mutations=10, new_mutations=22, known_survivors=survivors,
                     graph_delta=delta, focused_compatibility_failures=len(compatibility["failures"]))
    except BaseException:
        state.update(status="failed", failure_traceback=traceback.format_exc())
        write(run / "status.json", state)
        v.output_manifest(run)
        raise
    write(run / "status.json", state)
    v.output_manifest(run)
    print(json.dumps({**state, "evidence_manifest": v.binding(run / "EVIDENCE_MANIFEST.json")}))


if __name__ == "__main__":
    main()
