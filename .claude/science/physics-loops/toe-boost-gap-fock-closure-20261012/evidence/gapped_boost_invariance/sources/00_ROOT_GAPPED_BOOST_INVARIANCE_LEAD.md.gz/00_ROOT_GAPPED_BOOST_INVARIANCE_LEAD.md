# Unverified route: gap plus current conservation supplies boost invariance

Root research proposal, not an accepted proof. Fixed campaign deadline remains
2026-10-12 16:00:52 UTC. No physical axiom or intended-model conservation identity
is assumed to have been established by this proposal.

Take an actual finite-spin finite-range translation-covariant energy density
h_x, its actual norm dynamics alpha_t, and an invariant state omega whose GNS
Hamiltonian H is positive with ker(H)=C Omega and spectrum outside zero at least
Delta>0. This is uniqueness in the given GNS representation, not uniqueness of
all algebraic ground states. On local observables define delta_h, the linearly
weighted delta_b=i sum_x x_b[h_x, .], and the already derived finite-range
current derivation delta_p=[delta_h,delta_b]. Add the concrete exact local
conservation condition [delta_h,delta_p]=0. The joint-flow candidate provides a
finite one-site-basis criterion for that condition, not its truth in a model.

Possible conclusion: omega(delta_p A)=omega(delta_b A)=0 for every local A.
Combined only after exact premise matching with the newly frozen weighted-flow
candidate, this would construct actual canonical P and B without supplying
boost state invariance as an additional premise. The full Lorentz algebra,
spatial rotations, positivity/gap/model existence, spectrum and centre density
remain open. In particular current conservation is stronger than stationarity.

## Proposed gap-filter proof, to verify independently

1. Extend each finite-range uniform derivation and delta_b to the rapid
almost-local algebra by explicit conditional-expectation/dyadic bounds.
The weighted generator needs an extra spatial power. Prove actual alpha_t
preserves this algebra and is differentiable in sufficiently strong seminorms;
on a fixed local input its seminorms grow at most polynomially in |t|.
Exponential LR with a light-cone split should supply the polynomial estimate.
Do not use an exponential-in-time bound under a merely Schwartz integral.
Extend the exact local commutator identities to this algebra with the necessary
two-generator graph loss. No self-adjoint P or B is a premise of this step.

2. Let ell_p(A)=omega(delta_p A). Invariance gives omega(delta_h C)=0
on rapid almost-local C by graph approximation. Then

    d/dt ell_p(alpha_t A)
      = omega(delta_p delta_h alpha_t A)
      = omega(delta_h delta_p alpha_t A) = 0.

Every derivative/domain interchange in this display is a proof obligation.
It cannot be inferred just from a formal unbounded commutator on vectors.

3. Choose real even Schwartz f with integral one and Fourier transform smooth
and supported strictly inside (-Delta,Delta). Define the norm integral
A_0=integral f(t) alpha_t(A) dt. The gap and one-dimensional kernel imply BOTH
A_0 Omega=omega(A) Omega and A_0* Omega=omega(A*) Omega. Consequently for each
bounded local density q_x,

    omega([q_x,A_0])=0.

The rapid almost-local commutator sum is absolutely convergent, also after the
linear weight x_b. Hence ell_p(A_0)=ell_b(A_0)=0. This needs only vacuum-column
statements for this expectation calculation; it asserts no full-operator scalar
projection, small norm, or full Arveson energy filtering conclusion.

4. The polynomial graph bound and Schwartz f allow moving ell_p through the
integral. Since ell_p(alpha_t A)=ell_p(A), conclude ell_p(A)=0. This uses
only the unique gapped vacuum in this GNS representation. It does not rely on
global ground-state uniqueness or on an a priori invariant current state.

5. Next use [delta_h,delta_b]=delta_p and the just-derived ell_p=0:

    d/dt ell_b(alpha_t A)
      = omega(delta_h delta_b alpha_t A - delta_p alpha_t A)=0.

The same gap filter and polynomial weighted graph bound give ell_b(A)=0.
This is a finite hierarchy argument. Do not silently replace the exact current
conservation identity by current expectation zero or a vacuum commutator.

6. Match the conclusion to MICROSCOPIC_BOOST_FLOW_PROBE.md (frozen
7ec1d7eecb4eba020548eba8b56dff66712f52b4eba634ba276dd67440d28de7;
independent review pending). A standalone invariance theorem is sufficient if
the implementation composition is not yet reviewed. Preserve that provisional
dependency explicitly; do not call it retained or independently checked.

## Suggested stress tests

- Energy-density coboundaries change delta_b even when delta_h is unchanged.
  The new current-conservation premise must detect the harmful added term;
  inspect the weighted-flow author's telescoping-density example.
- With a degenerate zero eigenspace, A_0 can act nontrivially inside it. A
  qutrit onsite projector onto level 2 and a coboundary built from X_01 may
  give a counterexample retaining a positive excitation gap but failing the
  unique-kernel hypothesis. Check the actual signs and algebra, not this sketch.
- A one-sided scalar vacuum column does not make both commutator expectations
  vanish. Construct an exact matrix witness for omitting the adjoint condition.
- Finite controls cannot prove infinite-volume graph convergence or gap-filter
  interchange. Those analytic arguments need complete derivation and later
  independent review. Negative findings narrow this proposal, not all boost
  constructions or TOE research.

Root is a coauthor of this proposed mechanism. The assigned worker is an author;
a separate fresh source review remains necessary before publication.
