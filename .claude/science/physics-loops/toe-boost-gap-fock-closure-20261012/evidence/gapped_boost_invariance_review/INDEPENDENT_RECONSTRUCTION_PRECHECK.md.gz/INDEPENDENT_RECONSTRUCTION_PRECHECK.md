# Independent reconstruction and decisive-check freeze

Written after reading all 774 lines of candidate 94d1f879927135d378dcafb6e9b603465155906a71fed5ca301b4354566cea14, and before reading the author helper, receipt content, result JSON, logs, or mutations. The candidate itself disclosed its outcomes, including 105 passing author predicates and the listed mutation failures. This is therefore source-exposed independent review, not blinded prediction. No author numerical outcome will be used as the acceptance target. The same selected model/effort is inherited in a separate reviewer context; no model-family independence is claimed.

## Exact target and permitted leaves

For finite-range bounded Hermitian translated energy densities on a finite-spin Z^d tensor algebra, use the actual finite-range energy automorphism group. Supply its invariant state and its canonical positive GNS generator with simple zero eigenspace and positive gap. The only extra dynamical identity is [delta_h,delta_p]=0 on every local, where delta_p is the canonical current [delta_h,delta_b]. Target: omega(delta_p A)=omega(delta_b A)=0 first locally and then in the rapid almost-local topology. Neither an implemented boost/current nor globally unique algebraic ground state is permitted as a leaf. A result about the exact conditional implication is not proof that an intended physical model satisfies these leaves.

## Independently reconstructed graph estimates (unit shells)

Let p_n be the candidate's origin-centered rapid seminorms. Nested conditional expectations give p_q(E_L A)<=p_q(A) and p_n(A-E_L A)<=2(1+L)^(n-q)p_q(A) for q>n. For D_w of radius rho and weight degree kappa, a local C in B_L obeys

    supp D_w C subset B_(L+2rho),
    ||D_w C|| <= 2gW 3^d (1+rho)^(d+kappa) (1+L)^(d+kappa)||C||.

Hence p_n(D_w C)<=c_(n,w)(1+L)^(n+d+kappa)||C||.
Use unit shells a_0=E_0 A and a_m=E_m A-E_(m-1) A, m>=1, rather than the author's dyadic series. For m>=1, ||a_m||<=2 m^(-q)p_q(A), supp a_m subset B_m. Thus sum_m p_n(D_w a_m) converges whenever q>n+d+kappa+1. The concrete choice q=n+d+kappa+2 supplies a continuous extension. Its weighted density sum is absolutely norm convergent by annulus counting with q>d+kappa; uniform p_q(E_L A) identifies that sum with the shell extension. Density in the rapid topology makes this extension equal to the author's dyadic extension.

For a word D=D_1...D_k, the independently sufficient loss is L'_D=sum_j(d+kappa_j+2). Composition yields p_n(D A)<=C p_(n+L'_D)(A), and the nested-expectation error gives graph convergence using any q>n+L'_D. These deliberately larger losses prove the same rapid space claim. The author's sharper losses d+kappa+1 have also been checked directly against its geometric dyadic sum. They are sufficient; no endpoint equality is used. In particular, the author's h-b graph loss is 2d+3, and h-p graph loss is 2d+2.

## Independent light-cone comparison

For a fixed finite volume and bounded B supported in arbitrary finite Y, the exact Jacobi ODE gives the Volterra inequality

    C_B(X,t)<=C_B(X,0)+2 sum_(Z intersects X)||Phi(Z)|| integral_0^t C_B(Z,u)du.

The homogeneous generator in this ODE is the time-dependent bounded self-adjoint alpha_t K_X, so the propagator is isometric. This holds even when X is a large set; there is no B support cardinality in the forcing factor 2||A||.

A separate positive-matrix supersolution gives the decisive spatial estimate. Let F_Y(X)=|X|exp(-dist(X,Y)). For the positive kernel K(X,Z)=2||Phi(Z)||1_(Z intersects X), use |Z|<=s, diam Z<=ell, and sum_(Z intersects X)||Phi(Z)||<=|X|J. If Z meets X, dist(Z,Y)>=dist(X,Y)-ell. Therefore

    (K F_Y)(X)<=2sJ exp(ell) F_Y(X)=v F_Y(X).

The initial C_B(X,0)<=2||B||F_Y(X). In a finite volume the finite positive Volterra comparison, equivalently the matrix exponential power series, yields C_B(X,t)<=2||B||exp(v|t|)F_Y(X). This verifies the author's G23 by a comparison function, independently of its explicit support-chain totals. Its separate chain count is also checked: the first link costs |X|J, each next link at most sJ, and a chain of m sets travels at most m ell. No division by J or assumption ell>0 is needed; J=0 and R=0 are allowed.

Haar averaging over the entire outside finite tensor factor then bounds the conditional-expectation tail without an outside-volume factor. Norm thermodynamic convergence transfers it to the actual dynamics. Split r at 2(L+v|t|+1): below the split the norm bound costs (1+L+v|t|)^n; above it the exponential is bounded by exp(-r/2), with a harmless |B_L| factor. Thus p_n(alpha_t C)<=C_n(1+|t|)^n(1+L)^(n+d)||C|| for local C.

The unit-shell sum now gives p_n(alpha_t A)<=C'_n(1+|t|)^n p_(n+d+2)(A). Combining with the independent word loss gives

    p_n(D alpha_t A)<=C_(n,D)(1+|t|)^(n+L'_D) p_(n+L'_D+d+2)(A).

Every exponent and every loss is finite, which is the property required for the Schwartz integral. The author's smaller dyadic losses independently satisfy the same convergence test.

## Independent domain and state-functional reconstruction

Local E_L A converge both in norm and in the h graph. Closedness of the actual energy generator identifies it with delta_h on all rapid elements. Norm continuity of alpha_t and the elementary interpolation p_n(C)<=||C||+(2||C||)^(1-n/q)p_q(C)^(n/q), q>n, upgrade each orbit to rapid-topology continuity. The actual generator integral alpha_t A-A=integral alpha_u delta_h A then holds in the complete rapid topology. This gives differentiation through every continuous derivation word. Approximating the local commutator identities in two-derivation graph norms supplies them on all rapid elements without Hilbert-space unbounded products.

Energy-state stationarity extends to rapid elements. Therefore ell_p=omega delta_p has zero derivative along alpha, since delta_p delta_h=delta_h delta_p. A real Schwartz filter with Fourier support inside the gap and value one at zero gives A_0=integral f(t)alpha_t A. The polynomial graph bounds justify this integral and its exchange with every D_w or finite word. Applying the bounded map C -> pi(C)Omega to A_0 and to A_0* gives both scalar vacuum columns, because real f filters A* by the same function and g(H)=P_Omega. This uses simple kernel in this representation only.

For each bounded density Q, both columns imply omega([Q,A_0])=0. The absolutely norm convergent density sums, including the unbounded coefficient x_b, then give ell_p(A_0)=ell_b(A_0)=0. Functional stationarity and integral f=1 imply ell_p(A)=0. Next d_t ell_b(alpha_t A)=omega(delta_h delta_b alpha_t A)-ell_p(alpha_t A)=0, and the same filter argument gives ell_b(A)=0. Thus no provisional weighted-flow theorem is needed.

## Precommitted exact controls and discriminators

Implement independent sparse tensor matrix-unit arithmetic with exact Gaussian rational coefficients; import neither author code nor output. Freeze source before execution. Use finite padded density cutoffs only where local actions stabilize algebraically, not as evidence for the infinite theorem.

1. Recompute the qubit coboundary h_x=n_x+q_x-q_(x+1), first q=X and then the unreported q=3X-2Y+5Z. Derive H, B and their nested actions from the raw density sums. Independently compare all site-zero matrix-unit actions to onsite delta_n, boost delta_q (site zero), and current delta_(i[n,q]). For the new q, i[n,q]=3Y+2X; conservation failure is delta_(-3X+2Y). The one-site expectations include omega(delta_b Y)=-6 and omega(delta_b X)=-4. Reversing the current or deleting its half-factor must disagree for at least one one-site unit.
2. Use qutrit n=E22 and Q=2(E01+E10). Show commuting densities give exact current and conservation zero while omega(delta_b Y01)=-4. Exhibit the additional zero eigenvector E10 Omega directly; do not infer infinite kernel rank from a finite count.
3. Use the unreported filter spectrum (0,3,3,8), a non-Hermitian complex rational A, and a smooth Fourier filter supported in (-1,1). Its exact multiplier leaves the nontrivial excited 3-energy block, so A_0 need not even be diagonal. Check both vacuum columns and all matrix-unit commutator expectations. A globally scalar replacement must be rejected by full operator comparison, while the vacuum-column tests are explicitly nondiscriminating for that mutation.
4. Delete the adjoint-column requirement with C=E03 and Q=E03+E30. The scalar right column alone must coexist with omega([Q,C])=-1. A degenerate zero spectrum (0,0,3,8) must retain a nonscalar vacuum column for E10, rejecting a rank-one vacuum projection shortcut.
5. Check the Ising product-GNS premise distinction analytically: basis indexed by finite flipped sets, energy equals the finite domain-wall count, minimum nonzero energy two, unique empty-set zero vector despite the second algebraic product ground state.

These controls check algebra, signs, missing hypotheses and shortcut sensitivity. They do not test the infinite-dimensional proof by a count of passing cases. Analytic validation remains the decisive evidence.

## Recovery status

No material defect found in the reconstructed argument at this freeze. Remaining work: inspect exact prerequisite source statements, implement and run the frozen independent controls under declared timeouts, then read author helper/result evidence and check artifact provenance. Produce one review, its evidence receipt and source identities. No author/repository/prompt edits, Git mutations, audit application, subdelegation, or other-chat messages are authorized.
