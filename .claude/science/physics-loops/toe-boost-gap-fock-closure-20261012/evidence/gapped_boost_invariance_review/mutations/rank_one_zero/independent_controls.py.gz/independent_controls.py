#!/usr/bin/env python3
"""Exact sparse tensor controls, independent of all author code and output.

Coefficients are pairs of fractions; absent tensor factors are identities.
These fixtures test finite algebra and shortcut sensitivity, not the theorem.
"""
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import argparse
import hashlib
import json
import platform
import sys


@dataclass(frozen=True)
class G:
    re: Fraction = Fraction(0)
    im: Fraction = Fraction(0)

    def __add__(self, other):
        return G(self.re + other.re, self.im + other.im)

    def __neg__(self):
        return G(-self.re, -self.im)

    def __mul__(self, other):
        return G(self.re * other.re - self.im * other.im,
                 self.re * other.im + self.im * other.re)

    def conj(self):
        return G(self.re, -self.im)

    def __bool__(self):
        return bool(self.re or self.im)

    def text(self):
        return [str(self.re), str(self.im)]


ZERO, ONE, I = G(), G(Fraction(1)), G(Fraction(0), Fraction(1))
PAIR_SIGN = 1
PAIR_HALF = Fraction(1, 2)
GLOBAL_SCALAR_FILTER = False
RANK_ONE_ZERO = True
IGNORE_ADJOINT_COLUMN = False


def real(x):
    return G(Fraction(x))


def add(*operators):
    out = {}
    for op in operators:
        for word, coef in op.items():
            out[word] = out.get(word, ZERO) + coef
            if not out[word]:
                del out[word]
    return out


def scale(coef, op):
    return {word: coef * c for word, c in op.items() if coef * c}


def subtract(a, b):
    return add(a, scale(real(-1), b))


def multiply(a, b):
    out = {}
    for wa, ca in a.items():
        for wb, cb in b.items():
            factors = {site: (row, col) for site, row, col in wa}
            for site, row, col in wb:
                if site in factors:
                    row_a, col_a = factors[site]
                    if col_a != row:
                        break
                    factors[site] = (row_a, col)
                else:
                    factors[site] = (row, col)
            else:
                word = tuple((site, row, col)
                             for site, (row, col) in sorted(factors.items()))
                out[word] = out.get(word, ZERO) + ca * cb
                if not out[word]:
                    del out[word]
    return out


def adjoint(a):
    return {tuple((site, col, row) for site, row, col in word): c.conj()
            for word, c in a.items()}


def comm(a, b):
    return subtract(multiply(a, b), multiply(b, a))


def delta(a, b):
    return scale(I, comm(a, b))


def unit(site, row, col):
    return {((site, row, col),): ONE}


def shift(a, distance):
    return {tuple((site + distance, row, col) for site, row, col in word): c
            for word, c in a.items()}


def expectation(a):
    out = ZERO
    for word, c in a.items():
        if all(row == col == 0 for site, row, col in word):
            out = out + c
    return out


def serialized(a):
    return [{"word": word, "coefficient": c.text()}
            for word, c in sorted(a.items())]


def discrepancy(a, b):
    difference = subtract(a, b)
    return {"equal": not difference, "difference": serialized(difference)}


ROWS = []


def check(label, condition, **details):
    row = {"label": label, "pass": bool(condition), **details}
    ROWS.append(row)
    print(json.dumps(row, sort_keys=True))


def equal(label, a, b):
    d = discrepancy(a, b)
    check(label, d["equal"], **d)


def pair_current(densities):
    terms = []
    for x, hx in densities.items():
        for y, hy in densities.items():
            terms.append(scale(I * real(PAIR_SIGN * PAIR_HALF * (y - x)),
                               comm(hx, hy)))
    return add(*terms)


def coboundary_fixture(name, dim, n, q, expected_current, expected_conservation):
    # The density is an onsite sum, so all nested local actions stay onsite.
    densities = {x: add(shift(n, x), shift(q, x),
                        scale(real(-1), shift(q, x + 1)))
                 for x in range(-3, 4)}
    h = add(*densities.values())
    b = add(*(scale(real(x), hx) for x, hx in densities.items()))
    p = pair_current(densities)
    for row in range(dim):
        for col in range(dim):
            a = unit(0, row, col)
            label = f"{name}.E{row}{col}"
            equal(label + ".energy", delta(h, a), delta(n, a))
            equal(label + ".boost", delta(b, a), delta(q, a))
            equal(label + ".pair_current", delta(p, a), delta(expected_current, a))
            nested = subtract(delta(h, delta(b, a)), delta(b, delta(h, a)))
            equal(label + ".nested_current", nested, delta(expected_current, a))
            equal(label + ".pair_vs_nested", delta(p, a), nested)
            conserved = subtract(delta(h, delta(p, a)), delta(p, delta(h, a)))
            equal(label + ".conservation", conserved, delta(expected_conservation, a))
    return h, b, p


def column(a, dimension):
    return [a.get(((0, row, 0),), ZERO) for row in range(dimension)]


def scalar_column(a, dimension):
    col = column(a, dimension)
    return col[0] == expectation(a) and not any(col[1:])


def columns_certify_commutator(a, dimension):
    return scalar_column(a, dimension) and (
        IGNORE_ADJOINT_COLUMN or scalar_column(adjoint(a), dimension))


def spectral_filter(a, energies):
    result = {}
    for row, er in enumerate(energies):
        for col, ec in enumerate(energies):
            # Every nonzero difference in these fixtures has magnitude >= 3.
            # Any smooth g supported in (-1,1), g(0)=1, has this multiplier.
            if er == ec:
                result = add(result, multiply(multiply(unit(0, row, row), a),
                                               unit(0, col, col)))
    if GLOBAL_SCALAR_FILTER:
        result = scale(expectation(a), add(*(unit(0, k, k)
                                            for k in range(len(energies)))))
    return result


def vacuum_spectral_projection(vector, energies):
    return [z if (energy == 0 and (not RANK_ONE_ZERO or k == 0)) else ZERO
            for k, (z, energy) in enumerate(zip(vector, energies))]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    n = unit(0, 1, 1)
    x = add(unit(0, 0, 1), unit(0, 1, 0))
    y = add(scale(-I, unit(0, 0, 1)), scale(I, unit(0, 1, 0)))
    z = subtract(unit(0, 0, 0), unit(0, 1, 1))
    _, b, _ = coboundary_fixture("qubit_X", 2, n, x, y, scale(real(-1), x))
    check("qubit_X.boost_Y_expectation", expectation(delta(b, y)) == real(-2),
          actual=expectation(delta(b, y)).text())
    q = add(scale(real(3), x), scale(real(-2), y), scale(real(5), z))
    expected_p = add(scale(real(3), y), scale(real(2), x))
    expected_conservation = add(scale(real(-3), x), scale(real(2), y))
    _, b, _ = coboundary_fixture("qubit_fresh", 2, n, q, expected_p,
                                expected_conservation)
    check("qubit_fresh.boost_Y_expectation", expectation(delta(b, y)) == real(-6),
          actual=expectation(delta(b, y)).text())
    check("qubit_fresh.boost_X_expectation", expectation(delta(b, x)) == real(-4),
          actual=expectation(delta(b, x)).text())

    n3 = unit(0, 2, 2)
    q3 = scale(real(2), x)
    _, b3, _ = coboundary_fixture("qutrit_degenerate", 3, n3, q3, {}, {})
    check("qutrit_degenerate.boost_Y_expectation",
          expectation(delta(b3, y)) == real(-4),
          actual=expectation(delta(b3, y)).text())
    extra = [ZERO, ONE, ZERO]
    projected = vacuum_spectral_projection(extra, (0, 0, 1))
    check("qutrit_degenerate.extra_zero_vector", projected == extra,
          actual=[c.text() for c in projected])

    # Fresh non-Hermitian input with an excited degenerate spectral block.
    a = {((0, r, c),): G(Fraction(3 * (r + 1) + c + 1), Fraction(r - c))
         for r in range(4) for c in range(4)}
    a0 = spectral_filter(a, (0, 3, 3, 8))
    surviving = {(0, 0), (1, 1), (1, 2), (2, 1), (2, 2), (3, 3)}
    expected = {word: coef for word, coef in a.items()
                if (word[0][1], word[0][2]) in surviving}
    equal("filter.fresh_exact_block", a0, expected)
    check("filter.right_column", scalar_column(a0, 4))
    check("filter.adjoint_column", scalar_column(adjoint(a0), 4))
    check("filter.excited_offdiagonal_survives", bool(a0.get(((0, 1, 2),), ZERO)),
          actual=a0.get(((0, 1, 2),), ZERO).text())
    scalar = scale(expectation(a), add(*(unit(0, k, k) for k in range(4))))
    check("filter.not_globally_scalar", bool(subtract(a0, scalar)),
          difference=serialized(subtract(a0, scalar)))
    for r in range(4):
        for c in range(4):
            value = expectation(comm(unit(0, r, c), a0))
            check(f"filter.commutator_E{r}{c}", not value, actual=value.text())

    c = unit(0, 0, 3)
    q4 = add(c, adjoint(c))
    observed = expectation(comm(q4, c))
    check("one_column.right_column_holds", scalar_column(c, 4))
    check("one_column.adjoint_column_fails", not scalar_column(adjoint(c), 4))
    check("one_column.nonzero_commutator", observed == real(-1), actual=observed.text())
    certificate = columns_certify_commutator(c, 4)
    check("one_column.certificate_sound", not certificate or not observed,
          certificate=certificate, actual_commutator=observed.text())
    degenerate_vector = [ZERO, ONE, ZERO, ZERO]
    projected = vacuum_spectral_projection(degenerate_vector, (0, 0, 3, 8))
    check("filter.degenerate_projection_not_rank_one", projected == degenerate_vector,
          actual=[co.text() for co in projected])
    degenerate_a0 = spectral_filter(unit(0, 1, 0), (0, 0, 3, 8))
    check("filter.degenerate_vacuum_not_scalar", not scalar_column(degenerate_a0, 4),
          column=[co.text() for co in column(degenerate_a0, 4)])

    result = {"source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "python": platform.python_version(), "arithmetic": "exact Fraction pairs",
              "rows": ROWS, "passed": sum(r["pass"] for r in ROWS),
              "failed": sum(not r["pass"] for r in ROWS),
              "limits": "Finite controls do not prove infinite-volume or graph estimates."}
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: result[key] for key in ("passed", "failed")}, sort_keys=True))
    return bool(result["failed"])


if __name__ == "__main__":
    sys.exit(main())
