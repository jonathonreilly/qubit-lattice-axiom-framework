# Current checkpoint

Target: the exact G1–G6 ⇒ G7 local state-invariance theorem in
`../GAPPED_BOOST_INVARIANCE_PROBE.md`. Root and this worker are authors.

Source identities and recovery paths: `sources/manifest.json`; complete source
and instruction snapshots are in `sources/`. No Git operation has been used.
Only the assigned note and this evidence directory have been written.

Current result: the complete author theorem through G49 is on disk. It derives
a finite-volume light-cone inequality from the commutator ODE, converts that
bound to polynomial rapid-AL seminorm growth by a cone split, proves all finite
derivation graph extensions, extends both two-derivation identities, and makes
the gap-filter exchanges in those graphs. Both vacuum columns are used.

Author work completed: complete cold source read; exact coboundary,
degenerate-ground, one-sided-column and nonscalar-filter controls; complete
baseline output read; final row equality and all changed mutant rows checked;
helper source read; script compilation; synthetic log-collision preservation;
final 22-source byte check. The source-bound receipt freezes the final note
and evidence. No unresolved analytic step was identified by this author.
Independent review is not performed by this author and remains necessary.

Failed shortcuts preserved: global scalar filtering, one-sided vacuum-column
reasoning, arbitrary norm graph approximation, and exponential time bounds
under a merely Schwartz integral are not used. The simple-gapped onsite
coboundary is expected to violate exact conservation; the degenerate qutrit
version is expected to retain conservation and violate boost invariance.
The exact matrices confirmed both outcomes, including boost expectations −2.
The qubit conservation defect on Y_0 is 2Z_0; the qutrit p and conservation
defect are zero while its ground space is degenerate. The complete proof also
gives a ferromagnet example separating GNS kernel uniqueness from global
algebraic-ground-state uniqueness.

Control correction: the cold read found one initial baseline comparison reused
its computed matrix on both sides. The final control uses the independently
displayed G49 matrix, and all six executions were repeated for that changed
source. Initial sources/logs/results are preserved; `logs/control_correction.json`
records the issue. Final baseline: 105 predicates, zero failures. Five explicit
variants exit 1 with 5,5,1,1,1 failed predicates. Counts are execution facts,
not proof grades. No timeout or unintended execution failure occurred.

Precise proof boundary: the density, invariant state, positive simple gapped
GNS H, and local current conservation are supplied. No model realization,
Lorentz closure, centres, scattering or Fock result is claimed. The weighted
boost-flow source is optional downstream context, not a premise of this proof.

Next decision: root assigns a fresh independent review on the frozen source,
with particular attention to G20–G30, G18, G35 and G36–G41. Only after matching
reviewed downstream premises should G7 be composed with the weighted-flow
construction. The original source snapshots remain recoverable in `sources/`.
Deadline: 2026-10-12 16:00:52 UTC; never extend.
