#!/usr/bin/env python3
"""One subprocess with complete logs, timeout metadata and source bindings."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--name',required=True)
    p.add_argument('--timeout',type=float,required=True)
    p.add_argument('--source',action='append',default=[])
    p.add_argument('command',nargs=argparse.REMAINDER)
    a = p.parse_args()
    if a.command[:1] == ['--']:
        a.command = a.command[1:]
    base = Path(__file__).resolve().parent/'logs'/a.name
    base.parent.mkdir(parents=True,exist_ok=True)
    paths = {k:Path(str(base)+'.'+k) for k in ['stdout','stderr','receipt.json']}
    if any(x.exists() for x in paths.values()):
        raise FileExistsError('A unique run name is required; existing evidence is preserved.')
    sources = []
    for name in a.source:
        path = Path(name).resolve()
        raw = path.read_bytes()
        sources.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    start_utc = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    timed_out = False
    try:
        r = subprocess.run(a.command,capture_output=True,timeout=a.timeout)
        stdout,stderr,code = r.stdout,r.stderr,r.returncode
    except subprocess.TimeoutExpired as e:
        stdout,stderr,code = e.stdout or b'',e.stderr or b'',None
        timed_out = True
    elapsed = time.monotonic()-start
    paths['stdout'].write_bytes(stdout)
    paths['stderr'].write_bytes(stderr)
    receipt = {'start_utc':start_utc,'elapsed_seconds':elapsed,'declared_timeout_seconds':a.timeout,
               'timed_out':timed_out,'exit_code':code,'command':a.command,'cwd':str(Path.cwd()),
               'sources':sources,'stdout':str(paths['stdout']),'stderr':str(paths['stderr'])}
    paths['receipt.json'].write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    return 124 if timed_out else code


if __name__ == '__main__':
    raise SystemExit(main())
