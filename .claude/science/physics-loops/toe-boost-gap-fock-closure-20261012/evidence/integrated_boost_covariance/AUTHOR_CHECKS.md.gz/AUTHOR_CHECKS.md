# Author check design and independent mathematical route

This design is written after the 459-line proof freeze and before control
implementation/execution. It is an author check with full prior exposure to
the claimed formulas; it is not a fresh-context independent source review.
No author helper from the two input probes is imported or replayed.

## Explicit unbounded rapidity representation

Fix k>0, beta=k^2 and m>0. On L2(R_+, dr/r), take the self-adjoint real
multipliers

    H_m(r) = m(r+r^(-1))/2,
    P_m(r) = k m(r-r^(-1))/2,

on their maximal multiplication domains. The actual boost is

    (W_s f)(r) = f(r/exp(k s)).

Change of variables proves unitarity. Translation in log r proves strong
continuity, hence Stone supplies its self-adjoint generator. Differentiation
on compactly supported smooth functions gives B=i k r d/dr. Direct Leibniz
there gives i[H_m,B]=P_m and i[P_m,B]=beta H_m; the multipliers commute.
None of these statements requires an assumption about all smooth functions
being analytic. Adding a one-dimensional common fixed vector supplies an
abstract vacuum, without claiming it is cyclic for a spin observable algebra.

Direct composition, before solving any adjoint ODE, gives

    W_s exp(i t H_m) W_s* f(r)
      = exp(i t H_m(r/exp(k s))) f(r),

and similarly for P. Expanding r/exp(k s) and its reciprocal then derives
exactly the minus signs and beta factors in C9. This mechanism does not use
the weighted-lattice Fréchet extension or the paper's derivation conjugation.
It is an independent algebraic sign/normalization check within one author's
context, not an independent proof of the general lattice theorem.

Choosing exp(k s), k, m and r rational makes every multiplier comparison
exact in Fraction arithmetic, including the mass invariant and coordinate
clock transformation. Separate floating-point controls compose the actual
unitary function actions on f(r)=r^4/(1+r)^8, which lies in all domains needed
for these tested second-order expressions. They also finite-difference the
actual shifted multipliers, with a fourth-order centered stencil, h=1e-4
and absolute tolerance 1e-8. Group/phase residual tolerance is 1e-11.
The arithmetic controls do not certify unbounded domains.

## Full-domain diagnostic

On l2(N), let H e_n=n e_n and P e_n=(10/3)n e_n. For beta=4 and
exp(k s)=2, c_s=5/4 and d_s=3/8, so the joint-spectral G(c_s,-d_s) is zero
on all l2. The vector xi_n=1/n is square summable, but H xi is not. Thus
the intersection domain of the initial algebraic sum is strictly smaller
than the full spectral-sum domain. This example tests the general domain
convention, not all the boost theorem hypotheses; it supplies no boost
representation for this pair. The exact partial sums satisfy

    ||xi_(1..N)||^2 <= 2, ||H xi_(1..N)||^2=N,
    ||G xi_(1..N)||^2=0.

The written infinite-series argument, rather than testing finitely many N,
establishes the domain distinction. The theorem's joint-cutoff argument is
the actual proof of the full closure/domain statement for its generators.

## Spectral and positivity checks

In the rapidity representation the projection E(S) is multiplication by
the indicator of (H_m(r),P_m(r)) in S. Direct conjugation evaluates it at
r/exp(k s), which tests that C10 needs the preimage M_s^(-1) S, not
M_s S. Selected nonsymmetric halfspaces distinguish these alternatives.

For beta=4, the point (e,p)=(1,3) obeys the incorrect relaxed inequality
p^2<=beta^2 e^2 but becomes negative energy under exp(k s)=10. Its reflected
partner is detected at exp(k s)=1/10. Timelike and both null-ray controls
test C28 using exact fractions. A direct sum of the above representations
at masses 1 and 2 has mass-squared spectrum {1,4}; it satisfies covariance
and positive energy and therefore prevents reading C27 as fixed mass.
These are abstract representation diagnostics, not finite-range spin models.

## Predeclared mutations

1. `reverse_boost`: reverse the actual shift r/a to r*a. Group composition
   and mass preservation may still pass; Lie signs and covariance must fail.
2. `drop_beta`: omit beta from the candidate P-to-H mixing coefficient.
   First energy mixing can pass; current mixing must fail for beta!=1.
3. `double_spatial_beta`: use P/beta^2 in the actual spatial clock while
   retaining the proposed coordinate law. Generator mixing can pass;
   coordinate covariance must fail.
4. `forward_spectral_set`: replace the correct spectral set preimage by the
   forward image. Unitary covariance can pass; selected projections must fail.
5. `energy_phase`: add a nonzero scalar to the energy multiplier and its
   vacuum phase. This preserves the underlying adjoint automorphism but
   violates canonical vacuum fixation; exact unitary covariance must fail.

Each run will preserve every passing and failing row, stdout, stderr, command,
timeout, elapsed time and source hash. Canonical timeout is 60 seconds;
each mutation timeout is 30 seconds. No desired theorem conclusion is used
as a test implementation; comparisons are against explicit shift actions,
differential products, exact rational arithmetic and stated domain witnesses.

The remaining independent review must still check C14–C22 at full analytic
scope. No finite test or different implementation discharges those proofs.
