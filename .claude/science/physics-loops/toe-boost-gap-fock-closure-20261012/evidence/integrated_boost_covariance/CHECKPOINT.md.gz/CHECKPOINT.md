# Integrated boost covariance checkpoint

Final author source: `../INTEGRATED_BOOST_COVARIANCE_PROBE.md`, 550 lines,
SHA-256 `71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed`. Status: conditional-support author theorem; fresh independent
source review pending. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.

## Exact target and outcome

For one fixed direction, the reviewed actual weighted boost and finite-range
energy/current flows, plus exact local [delta_h,delta_p]=0 and
[delta_p,delta_b]=beta delta_h with beta>0, integrate to genuine all-time
1+1 covariance. The first local bracket [delta_h,delta_b]=delta_p is already
derived by the current construction. The two same-state infinitesimal
identities supply canonical GNS H/P/B; no separate analytic-vector, core,
strong-commutation or projective-phase premise is added.

The main formula is W(s) H W(s)* = G(cosh(s sqrt(beta)),
-sinh(s sqrt(beta))/sqrt(beta)), where G is the complete joint-spectral sum.
The analogous P formula, actual flow equality, exact spectral preimage law,
and connected semidirect-product representation are proved. Positive H
additionally gives |p|<=sqrt(beta)e and boost invariance of Dom H. No fixed
mass, physical momentum identification, multi-boost/Poincare closure or
nontrivial spin realization is claimed.

## Source identities and open obligations

The four assigned probe/review hashes and all 15 initially frozen source and
instruction paths are unchanged (see input_stability.json). Main/HEAD/planning
identities are root-reported; the worker made no Git query or mutation. Sources
are frozen under sources/, with exact read limits in READ_COVERAGE.json.
The gapped-invariance probe is not a dependency. No author-identified missing
mathematical step remains in the conditional integration implication.
Physical application still needs its explicit density, state, C3 and any
positivity premise. The next gate is a fresh source-bound independent review,
particularly C14-C22 and C8-C10, before extensive downstream reuse.

## Approach families and evidence

| Family | Mechanism | Scope / state |
|---|---|---|
| Actual flows on rapid AL | Finite-word graph losses, pointwise product rule, finite scalar ODE, Banach-group uniqueness | Target implication; author proof provisional pending independent review |
| Finite-range mixed histories | Reviewed J1-J14, matched only to H/P | Weaker independent route to strong H/P commutation; not a boost integrability assumption |
| Explicit rapidity multipliers | Actual shifts and direct function composition | Distinct normalization/domain scope check; not a spin realization or general proof |
| Analytic-vector/core shortcut | Would require justification beyond a dense local domain | Not used or declared impossible; graph/C1 route closes the assigned implication |

The 459-line proof was frozen before controls. Final canonical run: 71
predicates, 0 failed. Five explicit mutations: 39, 13, 3, 3 and 50 failed
predicates, each exit 1. Complete streams and source/timeout/exit receipts
exist for all six initial and six final runs. Final source reruns reproduce
all initial stdout and result JSON exactly. Full helper and result review
is recorded; finite controls do not certify the unbounded proof.

## Preserved failures and corrections

The first domain helper inserted its known partial H norm N, a tautological
comparison. It now computes the norm from the vector entries. Original source
and outputs are retained. No analytic argument changed. Optional PDF extraction
fell back from unavailable pdftotext to pypdf after a missing-file read; the
primary page agrees with the web view. The PDF font warning is recorded in
operational_history.json. No timeout or unexpected science execution failed.

## Handoff

Only the assigned note and this evidence directory were written. No repository,
Git, PR, audit, prompt, axiom, other-chat or subdelegation operation was performed.
The selected model and effort were inherited. Root should assign a neutral
fresh-context review of the exact final note and its matched inputs, with
particular attention to moving-vector differentiation, classical uniqueness,
canonical phase removal, full domains, spectral-set direction and clock scaling.
Root owns all later integration, scientific disposition and publication.
