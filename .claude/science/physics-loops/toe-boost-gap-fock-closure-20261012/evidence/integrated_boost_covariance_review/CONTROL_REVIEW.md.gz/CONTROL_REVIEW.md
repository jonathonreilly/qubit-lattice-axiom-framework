# Control and evidence review

The reconstruction and independent control were frozen in `CONTROL_FREEZE.json`
before any author-directory file was read. The candidate had already exposed
its formulas and reported outcomes. No blind or cross-model-family checking
is claimed. The proof is the general evidence; the controls exercise distinct
failure modes and do not prove the infinite-volume spin theorem.

## Independent reconstruction and diagnostics

The full spectral plane uses a complete divergence-free linear field, its
Cayley pullback and exact symbolic polynomial-Gaussian differentiation. The
claimed hyperbolic coefficients are compared against that pullback. This
shares the necessary Lie-sign convention with the target but imports no
author implementation, test fixture or result. The polynomial-Gaussian
product-rule check differentiates both the polynomial's explicit parameter
dependence and the transformed Gaussian. Its equality is symbolic for all
plane coordinates and nonsingular rational parameter, at k=2/3 and k=3/2.
It remains one diagnostic family, not a proof of the lattice Frechet rule.

The continuous-spectrum cancellation strip has squared Hilbert norm 3/10
and squared mixed-generator norm 1/10 in the chosen fixture. Both individual
generator squared norms diverge. The improper-integral proof in the frozen
reconstruction establishes the domain distinction; numerical cutoffs are
not used. The separate derivative-extension example has common dense
Cc-infinity action but time-one groups I and -I. Its discrepancy of 2
demonstrates the invalidity of the shortcut the candidate avoids.

All six independent source executions had 60-second limits. The canonical
run returned exit 0 in 2.577 seconds, with 38 passing exact predicates. Every
mutation returned exit 1, in 1.571–2.443 seconds. Full raw streams, input hashes
and receipts are in `logs/independent_*`; complete symbolic output is in the
adjacent named JSON files. No timeout, missing result or unexpected failure
occurred. The unmodified control source remains exactly as preregistered.

| Actual whole-source mutation | Failed / 38 | Meaning and survivor limit |
|---|---:|---|
| Delete the moving-input derivative term | 2 | Both Gaussian product-rule residuals become nonzero polynomials. Static generator and spectral tests do not inspect this term. |
| Replace inverse set image by forward image | 4 | Both exact spectral polynomials and two k=3/2 membership rows fail. The selected k=2/3 sample memberships all survive, showing why a few sign samples are incomplete. |
| Restrict the mixed-generator domain to the individual-domain intersection | 1 | The strip vector's selected squared norm changes from 1/10 to infinity. All algebraic mixing rows survive because they cannot establish a full domain. |
| Omit beta from the current mixing | 9 | Both current pullbacks, both claimed Jacobians, both spectral polynomials and three membership rows fail. The clock rows use the first mixing row and explicit beta, so they survive this particular implementation defect. |
| Reverse claimed boost direction | 12 | Energy/current pullbacks, spectral polynomials, clock rows and two sampled memberships fail. The Jacobian remains one. Local differential brackets and the moving-input check use the actual field, so they do not inspect the mutated claimed matrix. |

The Cayley ODE and actual-Jacobian rows check the chosen construction, not an
unknown physical model. Neither a correct determinant nor a mass invariant
selects the boost direction. The off-cone point transforms to energy -7/3;
the two null rays attain the exact graph-norm bounds 1/7 and 7. The universal
cone conclusion is supplied by the written spectral argument, not these
selected points.

## Author evidence and complete executions

The complete 167-line `controls.py`, 48-line logger, 89-line freeze helper and
102-line author-check note were read. All 95 manifest entries have matching
sizes and SHA-256 hashes, with no missing or undeclared non-bytecode files.
The manifest is bound to the dispatched receipt hash
`043ca7931ff183f7446831c50583a3d9189e950842c68c244b4c3d5d30f1ba8b`.
Those checks establish provenance only.

The author implements five mutations by command-line-selected branches in
one helper; it does not store five different source files. For an explicit
whole-source check, this review retained the baseline byte for byte and
materialized each mutation's six active branch choices into a complete
167-line helper. Every assertion, comparator, fixture and threshold remained
unchanged. All source diffs were inspected and are in `author_replays/`.
The mutation argument in those copies supplies result metadata only; all
scientifically operative branch choices have been fixed in source.

The complete canonical stdout and every changed mutation row were inspected.
The canonical execution and all five whole-source materializations reproduce
the author's final stdout and JSON **byte for byte**. All six used 60-second
review limits, ran in 0.030–0.041 seconds, and had empty stderr. Baseline exit
was 0; all mutants exited 1. Their failure counts are 39, 13, 3, 3 and 50 for
reverse boost, missing beta, doubled spatial beta, forward set image and
scalar energy phase, respectively. All passing rows are retained too.

The disclosed maximum function-composition residual is
5.838607383087711e-19, and the maximum fourth-order finite-difference residual
is 5.327738250571201e-12. The tolerances are respectively 1e-11 and 1e-8.
The direct shift and multiplier constructions do not compute their result
from the proposed mixing matrix. The differential Lie check cancels the
test-function derivative algebraically, so it is a coefficient check rather
than evidence of self-adjointness or general domain inclusion.

The mutation survivors are substantive limits, not grounds to inflate the
PASS count. Reverse boost preserves its group law and mass invariant, and
the energy comparison at r=1 is even under sign reversal. Missing beta
preserves energy mixing and the independently computed local Lie derivative.
Doubled spatial beta is detected only by coordinate covariance. A forward
set image still passes the selected r=3 projection. All four selected
projection predicates survive the energy phase in this fixture; canonical
vacuum fixation and exact generator/unitary covariance detect that phase.

The initial author helper differs in exactly one line: it assigned the
known H partial norm N instead of explicitly summing multiplication values.
The preserved corrected helper performs that sum. All six initial/final
stdout and result pairs agree byte for byte, with the corrected source
identities separately bound. This is an evidence-route repair, not a new
proof. The full diff and comparison records are retained. Earlier missing
`pdftotext`, missing-page read, PDF-font warning and missing `python` alias
are documented in the copied operational history; none is silently counted
as a successful science execution.

## Provenance teeth and limits

A separate pinned-target integrity check returned exit 0 on the exact frozen
note, and exit 1 on both a deliberately altered review copy and a missing
copy. Its 30-second bounded runs took about 0.025 seconds each. The expected
missing-file exception is captured as structured failure. This checks byte
binding and fail-closed IO only, not mathematical correctness.

No formalization, original TWW/NSY re-review, new lattice realization,
physical-model validation, repository pipeline, audit or broad novelty
search was performed. The local Engel–Nagel page excerpt was read and matches
the cited classical-solution statement; the new proof independently supplies
the necessary uniqueness argument and does not rely on that citation.
