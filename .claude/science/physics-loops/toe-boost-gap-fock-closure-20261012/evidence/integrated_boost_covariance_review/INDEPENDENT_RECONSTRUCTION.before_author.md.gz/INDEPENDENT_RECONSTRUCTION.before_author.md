# Reconstruction before author helpers

The target and antecedent notes/reviews were read first. This reconstruction
is independent of author-helper implementation, not of knowledge of the
candidate statement and proof. The antecedent results are reused at their
exact frozen source scope. No optional gapped-invariance premise is used.

## 1. Hypothesis closure

The finite-range energy density defines the local h and weighted b
derivations. The actual current C2 is a uniformly bounded finite-range
Hermitian density with radius at most 3R. The reviewed B1–B37 construction
provides their point-norm groups, a common rapid almost-local Frechet algebra
F, compact-time equicontinuity in each seminorm, continuous derivations F→F
with losses d+1,d+1,d+2, and C1 F-valued orbits. It constructs the same-state
canonical GNS groups from the two supplied local state identities. These
are precise imported provisional mathematics, not conclusions of the present
review about an uninspected literature theorem.

The local commutator `[delta_h,delta_b]=delta_p` has the displayed sign:
finite Jacobi gives `[i ad H,i ad B]=-ad[H,B]`, while the paired finite sum
gives `P=i[H,B]`. Thus `i ad P=-ad[H,B]`. The additional C3 identities are
explicit supplied conditions, not inferred from generic energy conservation.
No registered primitive supplies C3, the density, state identities or H>=0.

For a fixed word Q, compose its finitely many continuous-derivation estimates.
One obtains `p_nu(QA)<=C p_(nu+ell)(A)` with finite ell. Substitution of
`A-E_L A` into that estimate and B11 gives C14, with the factor 2 and exponent
`nu+ell-q`. Hence degree-two identities on locals extend to all F. This needs
neither a bound uniform in word length nor convergence of an exponential
series. Locality also makes every finite local cyclic product defined before
operator commutators are considered. No dense-domain equality is promoted
directly to self-adjoint equality.

## 2. Moving vectors in F

Let x(s) be C1 in F. At fixed s, write its difference quotient as in C15.
For each seminorm p, compact-time equicontinuity supplies a seminorm q and C
such that `p(T_(s+h)y)<=C q(y)`. Therefore

`T_(s+h)((x(s+h)-x(s))/h-x'(s)) → 0` in p.

Strong F-continuity on the fixed vector x'(s) yields
`T_(s+h)x'(s)→T_s x'(s)`. The other quotient is the known derivative of
the orbit of the *fixed* x(s). The derivative is consequently
`T_s x'(s)+T_s delta_T x(s)`. Applying the same equicontinuity estimate to
moving inputs proves continuity of the derivative. Finite seminorm loss is
sufficient; operator-norm differentiability is neither assumed nor needed.

Because delta_h and delta_p are continuous F→F, applying either to a C1
F-valued curve preserves C1 regularity and differentiates through it. This
discharges the moving derivation input in C16/C19. Iterating the product
rule a finite number of times is legitimate under the already proved losses.

## 3. Commuting translations without an integrability theorem

For A in F, differentiate `alpha_t delta_p alpha_-t A`. Own-generator
commutation and the preceding rule give
`alpha_t [delta_h,delta_p] alpha_-t A=0`. A zero-derivative curve in a
Hausdorff locally convex space is constant, by applying its separating
continuous linear functionals. Hence this conjugated derivation is delta_p.

For fixed t, `x(u)=alpha_t rho_u alpha_-t A` is norm-C1, remains in F,
and satisfies `x'=delta_p x`. F is contained in the norm-generator domain
of the actual rho group, where the generator equals delta_p. For any
strongly continuous bounded-operator group T with generator L, a norm-C1
curve with `x(t) in Dom L` and `x'=Lx` satisfies

`d/dt [T_-t x(t)] = T_-t x'(t)-T_-t Lx(t)=0`.

This follows from two difference-quotient terms; only local uniform boundedness
of T and the generator limit on the fixed vector x(t) are used. It does not
require x(t) to lie in a previously selected core. Thus x(u)=rho_u A.
Norm density of F and boundedness extend commutation to the entire algebra.

The canonical unitary groups commute on every cyclic vector and hence on H.
A bounded operator commuting with all `exp(itH)` commutes with its spectral
projections by bounded Fourier approximation and strong limits. Applying this
twice yields commuting spectral measures, hence a joint spectral measure E.
The source-bound J1–J14 theorem provides another valid route for this pair:
both interactions are bounded finite range and the supplied canonical actions
and local commutation match. It does not supply weighted-boost analyticity.

## 4. Derivation conjugation and whole flow equality

At fixed A in F, put X(s)=lambda_s delta_h lambda_-s A and
Y(s)=lambda_s delta_p lambda_-s A. Direct differentiation gives

`X'=-Y`, `Y'=-beta X`, with `X(0)=delta_h A`, `Y(0)=delta_p A`.

The minus signs follow from `[delta_b,delta_h]=-delta_p` and
`[delta_b,delta_p]=-beta delta_h`. This is a 2 by 2 scalar matrix system
with F-valued entries, not a general unbounded Frechet-space ODE. Multiply
the column by the inverse matrix exponential and differentiate; it is
constant. For k=sqrt(beta)>0 the unique solution is exactly C20.

For real a,b, commuting alpha and rho define the actual C0 group
`T_t=alpha_(at) rho_(bt)`. On F the product rule makes its norm generator
`a delta_h+b delta_p`. Every `lambda_s alpha_t lambda_-s A` remains in F
and, using C20, is a classical solution for `T_t` at `(a,b)=(c_s,-d_s)`.
The Banach-group uniqueness argument above therefore proves the first C7
identity. The second uses `(-beta d_s,c_s)`. Density gives all A and all real
times. Existence of the comparison group was established *before* uniqueness;
there is no unproved uniqueness assertion for a merely formal generator sum.

## 5. Full generator and domain identification

Canonical action, including vacuum fixation, turns C7 into equality of the
bounded unitary groups in C22 on dense cyclic vectors, thus on all H. No
commutant or scalar phase can remain in equality on every cyclic vector.

Joint spectral calculus defines
`G(a,b)=int (a e+b p) dE`, on exactly the square-integrability domain C8.
Its unitary group is `U(at)V(bt)`. The conjugated H group has generator
`W(s)H W(s)*` on `W(s)Dom H`. Equality of their unitary groups gives equality
of the complete self-adjoint operators by Stone uniqueness. The argument for
P is identical. A new local-core premise would add nothing to this proof.

The closure assertion at lines 355–360 is also valid. Restrict G to
Dom H intersect Dom P. For xi in Dom G, let xi_n=E([-n,n]^2)xi. Then xi_n
belongs to the intersection, converges to xi, and
`||G(xi_n-xi)||^2=int outside-box |a e+b p|^2 dmu_xi→0`.
The restriction is contained in the closed G and is graph dense, so its
closure equals G. This includes a=b=0. The original intersection need not
be the maximal domain; its enlargement is justified, not assumed.

## 6. Clocks, spectrum and positivity

The conjugated pair is M_s applied to the original joint spectral pair.
For any Borel set S its joint measure is `E(M_s^-1 S)`. Conjugating E by W
also gives that pair's joint measure, proving C10 by uniqueness. A neighborhood
has nonzero E projection exactly when its unitary-conjugate projection is
nonzero; the homeomorphism M_s therefore preserves the joint support.

Expanding the exponent of the negative spatial clock gives

`t(c_s H-d_s P)-(y/beta)(-beta d_s H+c_s P)`
`=(c_s t+d_s y)H-(beta d_s t+c_s y)P/beta`.

This proves C24 with exactly one beta division. The coordinate matrix preserves
beta t^2-y^2, and direct multiplication proves the semidirect law C25. The
rapidity reparametrization theta=ks replaces B by B/k. These statements do
not identify P/beta with geometric translations or add another boost.

If H>=0, every conjugate `G(c_s,-d_s)` is positive. A negative value of its
continuous multiplier at a support point produces a neighborhood with
nonzero projection on which the operator is negative. Thus
`e-(p/k)tanh(ks)>=0` at every support point for every s. Letting s tend to
both infinities gives `e>=|p|/k`. This argument uses the common support,
not uncountably many unrelated almost-everywhere representatives.

Integrating p^2<=beta e^2 proves Dom H subset Dom P and the stated norm
inequality, exactly the quadratic-form comparison. The invariant continuous
function e^2-p^2/beta defines the positive full-domain operator C27. Since
the function is invariant under M_s, its operator and domain are invariant
under W(s). On the cone, `exp(-|ks|)e<=c_s e-d_s p<=exp(|ks|)e`; the two
positive multipliers have equivalent square-integrability domains, proving
the optional invariance of Dom H. No fixed mass or isolated shell follows.

## 7. Distinct infinite-domain diagnostics

On L2(R2,de dp), let H and P multiply by e and p. The complete divergence-free
vector field `v=(-p,-beta e)` has flow M_s, determinant one. Pullback
`W(s)f(x)=f(M_s x)` is a strongly continuous unitary group, preserving
Schwartz space. Its generator on that space is
`B=i(p partial_e+beta e partial_p)`. Direct pullback shows
`W H W*=multiplication by c_s e-d_s p` and the analogous P identity.
Change of variables proves the full transformed domains. The example's full
plane spectrum is not positive; it is not a lattice or state realization.

For s>0 define q=c_s e-d_s p and r=p. The vector
`f(e,p)=1_(0<q<1) 1_(r>1)/(1+r)` is in L2 and in Dom G(c_s,-d_s), because
the Jacobian is 1/c_s and the two integrals are respectively 1/(2c_s)
and 1/(6c_s). It lies in neither Dom H nor Dom P: p=r and
e=(q+d_s r)/c_s grow linearly in r, while
`int_1^infty r^2/(1+r)^2 dr` diverges. This is an actual continuous-spectrum
domain diagnostic, different from the author's disclosed diagonal cancellation
fixture. It does not obey the note's optional positivity assumption.

Let D_theta=-i partial_x on L2(0,1), with H1 domain satisfying
`f(1)=exp(i theta)f(0)`. Integration by parts plus the explicit Fourier basis
`exp(i(2pi n+theta)x)` proves self-adjointness. D_0 and D_pi agree on dense
Cc-infinity(0,1), but `exp(i D_0)=I` and `exp(i D_pi)=-I`. Thus agreement
on a dense domain alone can miss an operator-norm discrepancy of 2. The
note avoids this failure through actual invariant F curves and whole-group
equality. This example is not a counterexample under its stronger hypotheses.

## 8. Preliminary disposition before author evidence

No missing core/analytic premise, sign error or counterexample to the
conditional implication was found in this reconstruction. The implication
is mathematically conditional on the frozen upstream flow regularity and
the supplied exact local identities and same-state conditions. Nontrivial
finite-range realization, physical state selection and positive energy remain
unsupplied. This is a provisional source analysis pending the registered
control execution and author evidence inspection, not an audit verdict.
