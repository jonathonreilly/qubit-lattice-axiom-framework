# Independent review registration

Registered before reading any file in the author's `integrated_boost_covariance/`
directory. The complete 550-line target, both complete antecedent notes and
both complete antecedent reviews were already read. Thus the target formulas,
proof route and its summaries of author tests are known. This is not blind
checking. Root contributed the route; root and the author controls are not
independent evidence. The reviewer is a separate context of the same model
family, with inherited model/effort, no override and no subdelegation.

Target: decide whether C1–C4 and the precisely reviewed rapid-AL conclusions
of B1–B37 imply C7–C10 on the full algebra and full self-adjoint domains,
without a new common-core, analytic-vector or strong-commutation premise;
then check C11/C23–C28 and the evidence claims. An honest counterexample or
unresolved proof step is an admissible outcome.

Primary target SHA-256:
`71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed`.
The five exact source hashes and source copies will be bound in this review
directory. Supplied checkout/main/planning identifiers are those in the
dispatch; no Git query or global-cleanliness claim is authorized here.

The mathematical reconstruction is written separately before author-helper
access. It checks the moving-vector product rule by seminorm estimates,
reduces the derivation conjugation to a two-dimensional scalar matrix ODE,
compares classical solutions of an already existing Banach-space group, and
uses bounded canonical unitary equality before Stone uniqueness. It also
proves the maximal-domain sum and positivity consequences by spectral cutoffs.

Distinct control, fixed before author-helper access:

* Use the full spectral plane L2(R2,de dp), multiplication by e,p and the
  volume-preserving boost vector field `-p d/de - beta e d/dp`. This differs
  from the author's disclosed positive-mass, one-dimensional multiplicative
  rapidity fixture. It has no spin realization or positive-energy claim.
* Construct its rationally parametrized pullback by a Cayley matrix from
  that vector field. Compare the claimed mixing to actual pullbacks of
  polynomial-Gaussian functions, using exact symbolic coefficients.
* Differentiate a genuinely moving polynomial-Gaussian input. Include the
  derivative of the input and the derivative of the pullback/Gaussian.
  Freeze a whole-source mutant deleting the moving-input term.
* Use a nonsymmetric spectral polynomial to check inverse-set orientation,
  and test the spatial clock at nonunit beta. Freeze whole-source mutants
  reversing boost direction, deleting beta and reversing the set image.
* Exhibit a full-plane cancellation-strip vector lying in the maximal
  mixed-generator domain but neither individual domain. Its integrability
  is proved by exact improper integrals, not a finite truncation. Freeze a
  whole-source mutant imposing the domain intersection.
* Preserve the self-adjoint derivative extensions on (0,1) with periodic
  versus antiperiodic boundary conditions. They agree on dense Cc-infinity,
  but their time-one unitaries differ by 2 in operator norm. This tests
  precisely why a dense-domain shortcut would fail; it is not a counterexample
  to the actual rapid-AL integration proof.
* Check off-cone rejection and the optional positive-cone domain equivalence.

Each run has a 60-second limit, saved complete stdout/stderr/results and
source hashes. Canonical and each declared whole-source mutation run once
unless a recorded concrete failure requires repair. Any repair preserves
old source and evidence. No target outcome or minimum PASS count is required.
After freezing these files, inspect and replay the complete author helper,
logger, actual mutations and outputs; report both detected defects and
surviving rows. Hash validation is provenance only.

No external literature acquisition is necessary for the new proof: its
classical-solution uniqueness argument is reconstructed directly. Existing
source-bound antecedent reviews may be reused only for their exact claims.
The original TWW/NSY proof is not freshly re-reviewed in this dispatch.
No optional gapped note, formal audit, repository pipeline or editable prompt
is part of this review.
