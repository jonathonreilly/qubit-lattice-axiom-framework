"""Bind the completed conditional proof to its reviewed inputs and author checks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


HERE = Path(__file__).resolve().parent
NOTE = HERE.parent / "INTEGRATED_BOOST_COVARIANCE_PROBE.md"
EXPECTED_NOTE = "71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


assert digest(NOTE) == EXPECTED_NOTE
assert len(NOTE.read_text().splitlines()) == 550
assert not (HERE / "receipt.json").exists(), "Final receipt already frozen"
assert not (HERE / "evidence_manifest.json").exists(), "Manifest already frozen"

source_manifest = json.loads((HERE / "sources/manifest.json").read_text())
source_checks = []
for source in source_manifest["sources"]:
    original = Path(source["source"])
    snapshot = Path(source["snapshot"])
    assert digest(original) == digest(snapshot) == source["sha256"]
    source_checks.append({"path": str(original), "sha256": digest(original)})

runs = json.loads((HERE / "final_control_verification.json").read_text())["final_source_checks"]
for run in runs:
    receipt = json.loads((HERE / "logs" / ("final_" + run["run"]) / "receipt.json").read_text())
    assert receipt["exit_code"] == run["exit"]
    assert not receipt["timed_out"]
    for source in receipt["sources"]:
        assert digest(Path(source["path"])) == source["sha256"]
    for stream in ("stdout", "stderr"):
        path = HERE / "logs" / ("final_" + run["run"]) / (stream + ".txt")
        assert digest(path) == receipt[stream + "_sha256"]
    assert (HERE / ("final_" + run["run"] + ".json")).read_bytes() == (HERE / (run["run"] + ".json")).read_bytes()

(HERE / "FINAL_SOURCE.md").write_bytes(NOTE.read_bytes())
assert digest(HERE / "FINAL_SOURCE.md") == EXPECTED_NOTE
now = datetime.now(timezone.utc).isoformat()
files = []
for path in sorted(HERE.rglob("*")):
    if not path.is_file() or "__pycache__" in path.relative_to(HERE).parts:
        continue
    if path == HERE / "receipt.json" or path == HERE / "evidence_manifest.json":
        continue
    files.append({"path": str(path.relative_to(HERE)), "bytes": path.stat().st_size, "sha256": digest(path)})
manifest = {
    "frozen_utc": now,
    "root": str(HERE),
    "final_note": {"path": str(NOTE), "bytes": NOTE.stat().st_size, "lines": 550, "sha256": EXPECTED_NOTE},
    "exclusions": ["evidence_manifest.json (self reference)", "receipt.json (binds this manifest)", "__pycache__/ (derived bytecode, not scientific evidence)"],
    "files": files,
    "file_count": len(files),
}
write_json(HERE / "evidence_manifest.json", manifest)
receipt = {
    "frozen_utc": now,
    "campaign_deadline_utc": "2026-10-12T16:00:52+00:00",
    "status": "conditional-support; author theorem, fresh independent source review pending",
    "claim_type": "bounded_theorem",
    "outcome": "The specified local 1+1 Lie identities, same-state invariance identities and reviewed actual flows imply full all-time Lorentz covariance of canonical GNS generators, with joint spectral domains. No analytic-vector, core or strong-commutation assumption is added.",
    "scope_limits": "One fixed boost direction only. Explicit density/state/local-Lie premises remain conditional. No nontrivial lattice realization, geometrical momentum identification, fixed mass, multiple boosts, rotations, full Poincare or physical-realization claim. The optional gapped-invariance result is not used.",
    "final_note": manifest["final_note"],
    "frozen_copy": {"path": str(HERE / "FINAL_SOURCE.md"), "sha256": EXPECTED_NOTE},
    "evidence_manifest": {"path": str(HERE / "evidence_manifest.json"), "sha256": digest(HERE / "evidence_manifest.json"), "file_count": len(files)},
    "source_recheck": {"all_match_initial_snapshots": True, "count": len(source_checks), "sources": source_checks},
    "author_control_source": {"path": str(HERE / "controls.py"), "sha256": digest(HERE / "controls.py")},
    "author_controls": runs,
    "verification_limits": "Finite explicit-representation controls corroborate signs, beta and clock normalization, spectral preimage direction, phase and domain distinctions; they do not certify the general unbounded proof and are not independent peer review.",
    "preserved_history": "Original helper and all six initial runs retained. Domain-norm diagnostic replaced a tautological assigned value with direct summation; all six final runs reproduce original outputs byte-for-byte. Nondiscriminating controls documented in final note. Optional extraction fallback and failed python alias recorded in operational_history.json.",
    "write_scope": {"note": str(NOTE), "evidence_directory": str(HERE)},
    "no_operations": ["repository edits", "Git", "commits", "PRs", "audit application", "prompt edits", "axiom edits", "other-chat messages", "subdelegation", "model or reasoning-effort override"],
    "next_gate": "Root-assigned fresh independent source-bound review of the frozen source and matched conditional inputs; root owns disposition and any publication.",
}
write_json(HERE / "receipt.json", receipt)
for entry in manifest["files"]:
    path = HERE / entry["path"]
    assert path.stat().st_size == entry["bytes"] and digest(path) == entry["sha256"]
assert digest(NOTE) == digest(HERE / "FINAL_SOURCE.md") == EXPECTED_NOTE
print(json.dumps({"frozen_utc": now, "note_sha256": EXPECTED_NOTE, "manifest_sha256": digest(HERE / "evidence_manifest.json"), "manifest_files": len(files), "receipt_sha256": digest(HERE / "receipt.json"), "all_source_and_evidence_checks_passed": True}, indent=2))
