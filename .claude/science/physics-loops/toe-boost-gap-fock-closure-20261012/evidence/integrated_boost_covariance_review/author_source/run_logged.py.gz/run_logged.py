#!/usr/bin/env python3
"""Capture one bounded diagnostic execution without overwriting evidence."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--name',required=True)
    ap.add_argument('--timeout',required=True,type=float)
    ap.add_argument('--source',action='append',default=[])
    ap.add_argument('command',nargs=argparse.REMAINDER)
    a=ap.parse_args()
    command=a.command[1:] if a.command and a.command[0]=='--' else a.command
    dest=Path('logs')/a.name
    dest.mkdir(parents=True,exist_ok=False)
    sources=[]
    for source in a.source:
        p=Path(source).resolve();d=p.read_bytes()
        sources.append({'path':str(p),'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)})
    receipt={'command':command,'cwd':str(Path.cwd()),'timeout_seconds':a.timeout,'sources':sources,
             'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    start=time.monotonic()
    try:
        p=subprocess.run(command,capture_output=True,timeout=a.timeout)
        stdout,stderr,code=p.stdout,p.stderr,p.returncode
        receipt['timed_out']=False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,code=exc.stdout or b'',exc.stderr or b'',124
        receipt['timed_out']=True
    receipt.update({'elapsed_seconds':time.monotonic()-start,'exit_code':code})
    (dest/'stdout.txt').write_bytes(stdout)
    (dest/'stderr.txt').write_bytes(stderr)
    receipt['stdout_sha256']=hashlib.sha256(stdout).hexdigest()
    receipt['stderr_sha256']=hashlib.sha256(stderr).hexdigest()
    (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'name':a.name,'exit_code':code,'timed_out':receipt['timed_out'],
                      'elapsed_seconds':receipt['elapsed_seconds'],'receipt':str(dest/'receipt.json')}))
    return code


if __name__=='__main__':
    raise SystemExit(main())
