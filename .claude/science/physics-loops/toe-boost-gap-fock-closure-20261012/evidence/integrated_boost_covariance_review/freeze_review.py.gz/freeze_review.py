#!/usr/bin/env python3
"""Freeze source-review evidence; does not confer an audit verdict."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
REPORT = HERE.parent / "INTEGRATED_BOOST_COVARIANCE_REVIEW.md"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name in ("receipt.json", "evidence_manifest.json"):
    assert not (HERE / name).exists(), "Refuse to replace frozen evidence"

source_manifest = json.loads((HERE / "source_manifest.final.json").read_text())
for source in source_manifest["sources"]:
    assert sha(Path(source["source"])) == sha(Path(source["snapshot"])) == source["sha256"]

frozen_controls = json.loads((HERE / "CONTROL_FREEZE.json").read_text())
for row in frozen_controls["files"]:
    assert sha(Path(row["path"])) == row["sha256"]

author = HERE.parent / "integrated_boost_covariance"
assert sha(author / "receipt.json") == "043ca7931ff183f7446831c50583a3d9189e950842c68c244b4c3d5d30f1ba8b"
author_receipt = json.loads((author / "receipt.json").read_text())
assert sha(author / "evidence_manifest.json") == author_receipt["evidence_manifest"]["sha256"]
for row in json.loads((author / "evidence_manifest.json").read_text())["files"]:
    assert sha(author / row["path"]) == row["sha256"]

run_records = []
for path in sorted(HERE.rglob("receipt.json")):
    if path.parent == HERE / "author_source":
        continue
    receipt = json.loads(path.read_text())
    for entry in receipt.get("sources", []):
        assert sha(Path(entry["path"])) == entry["sha256"]
    for name, stream in receipt.get("streams", {}).items():
        assert sha(path.parent / name) == stream["sha256"]
    run_records.append({"receipt": str(path.relative_to(HERE)),
                        "sha256": sha(path), "exit_code": receipt.get("exit_code"),
                        "timed_out": receipt.get("timed_out"),
                        "elapsed_seconds": receipt.get("elapsed_seconds")})

now = datetime.now(timezone.utc).isoformat()
entries = []
for path in sorted(HERE.rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        entries.append({"path": str(path.relative_to(HERE)), "sha256": sha(path),
                        "bytes": path.stat().st_size})
manifest = {"frozen_utc": now, "root": str(HERE), "files": entries,
            "file_count": len(entries),
            "exclusions": ["evidence_manifest.json: self reference", "receipt.json: binds manifest", "__pycache__: derived bytecode"]}
(HERE / "evidence_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

receipt = {
    "frozen_utc": now,
    "campaign_deadline_utc": "2026-10-12T16:00:52Z",
    "scope": "One frozen conditional source theorem; not repository landing or audit",
    "recommendation": "PASS WITH BOUNDED CLAIMS",
    "proof_disposition": "CONDITIONAL",
    "findings": [], "required_author_repairs": [],
    "primary_source": source_manifest["sources"][0],
    "review": {"path": str(REPORT), "sha256": sha(REPORT), "bytes": REPORT.stat().st_size,
               "lines": len(REPORT.read_text().splitlines())},
    "reconstruction": {"path": str(HERE / "INDEPENDENT_RECONSTRUCTION.before_author.md"),
                       "sha256": sha(HERE / "INDEPENDENT_RECONSTRUCTION.before_author.md")},
    "control_freeze": {"path": str(HERE / "CONTROL_FREEZE.json"), "sha256": sha(HERE / "CONTROL_FREEZE.json")},
    "evidence_manifest": {"path": str(HERE / "evidence_manifest.json"), "sha256": sha(HERE / "evidence_manifest.json"), "file_count": len(entries)},
    "author_receipt": {"path": str(author / "receipt.json"), "sha256": sha(author / "receipt.json")},
    "source_manifest": {"path": str(HERE / "source_manifest.final.json"), "sha256": sha(HERE / "source_manifest.final.json")},
    "independence": "Separate context of the same model family; target and outcome summaries known. Root contributed the route. Independent reconstruction/control frozen before author helpers and raw results. No cross-family or blinded independence claimed.",
    "selected_configuration": "Inherited selected model and reasoning effort unchanged; no override or subdelegation",
    "runs": run_records,
    "verification_limits": ["No new finite-range spin realization", "No freshly repeated TWW/NSY source review", "No formal proof assistant", "No repository pipeline or integration gates", "No applied audit or retained promotion", "No remote freshness assertion"],
    "writes": [str(REPORT), str(HERE)],
    "editable_prompt_files_changed": [],
    "git_operations": [], "repository_source_edits": [], "audit_operations": [],
}
(HERE / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
for row in entries:
    assert sha(HERE / row["path"]) == row["sha256"]
print(json.dumps({"report_sha256": sha(REPORT), "receipt_sha256": sha(HERE / "receipt.json"),
                  "manifest_sha256": sha(HERE / "evidence_manifest.json"),
                  "reconstruction_sha256": sha(HERE / "INDEPENDENT_RECONSTRUCTION.before_author.md"),
                  "frozen_utc": now, "file_count": len(entries), "logged_runs": len(run_records),
                  "recommendation": receipt["recommendation"]}, indent=2))
