#!/usr/bin/env python3
"""Exact plane/Schwartz diagnostics; no author imports or empirical inputs."""
import argparse
import json
import sys
import sympy as S

# Only these implementation sites are changed in the declared source mutants.
FLOW_SIGN = -1
CURRENT_FACTOR = "beta"
MOVING_TERM = 1
SET_INVERSE = True
MAXIMAL_DOMAIN = True

e, p, z, r, q = S.symbols("e p z r q", real=True)
I2 = S.eye(2)
rows = []


def canon(value):
    if isinstance(value, S.MatrixBase):
        return value.applyfunc(S.cancel)
    return S.cancel(S.expand(value))


def zero(value):
    value = canon(value)
    if isinstance(value, S.MatrixBase):
        return all(v == 0 for v in value)
    return value == 0


def record(name, ok, **values):
    row = {"name": name, "pass": bool(ok)}
    row.update({key: str(value) for key, value in values.items()})
    rows.append(row)
    print(json.dumps(row, sort_keys=True))


def actual_map(k):
    """Pullback from the Cayley map of the independently specified field."""
    field = S.Matrix([[0, -1], [-k*k, 0]])
    return canon((I2 + (z/k)*field) * (I2 - (z/k)*field).inv())


def claimed_map(k):
    # tanh(k s / 2)=z, so hyperbolic coefficients are rational in z.
    c = (1 + z*z)/(1 - z*z)
    d = 2*z/(k*(1 - z*z))
    lower_factor = k*k if CURRENT_FACTOR == "beta" else S.Integer(1)
    return S.Matrix([[c, -FLOW_SIGN*d], [-FLOW_SIGN*lower_factor*d, c]])


def sub_xy(poly, matrix):
    new = matrix * S.Matrix([e, p])
    return canon(poly.subs({e: new[0], p: new[1]}, simultaneous=True))


def polynomial_gaussian_field(poly, k):
    """D(poly exp(-|x|^2/2)) divided by that Gaussian; D=v dot grad."""
    ve, vp = -p, -k*k*e
    return canon(ve*S.diff(poly, e) + vp*S.diff(poly, p)
                 - (ve*e + vp*p)*poly)


def commutator(left, right, poly):
    return canon(left(right(poly)) - right(left(poly)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    x = S.Matrix([e, p])
    polynomial = 1 + e + 2*p + e*p*p
    moving = 1 + z*e + z*z*p*p
    spectral_poly = 2*e - 3*p - 1
    for k in (S.Rational(2, 3), S.Rational(3, 2)):
        ma = actual_map(k)
        mc = claimed_map(k)
        field = S.Matrix([[0, -1], [-k*k, 0]])
        ds_dz = 2/(k*(1-z*z))
        label = f"k={k}"
        record(label+":cayley_flow_ode", zero(ma.diff(z)-ds_dz*field*ma),
               residual=canon(ma.diff(z)-ds_dz*field*ma))
        record(label+":actual_jacobian", zero(ma.det()-1), determinant=ma.det())
        record(label+":claimed_jacobian", zero(mc.det()-1), determinant=canon(mc.det()))
        record(label+":energy_pullback", zero(sub_xy(e, ma)-sub_xy(e, mc)),
               residual=canon(sub_xy(e, ma)-sub_xy(e, mc)))
        record(label+":current_pullback", zero(sub_xy(p, ma)-sub_xy(p, mc)),
               residual=canon(sub_xy(p, ma)-sub_xy(p, mc)))
        D = lambda a: polynomial_gaussian_field(a, k)
        E = lambda a: e*a
        P = lambda a: p*a
        record(label+":local_bracket_hb", zero(commutator(E, D, polynomial)-P(polynomial)),
               residual=commutator(E, D, polynomial)-P(polynomial))
        record(label+":local_bracket_pb", zero(commutator(P, D, polynomial)-k*k*E(polynomial)),
               residual=commutator(P, D, polynomial)-k*k*E(polynomial))
        record(label+":local_bracket_hp", zero(commutator(E, P, polynomial)),
               residual=commutator(E, P, polynomial))

        # Independent direct derivative of P_z(M_z x) exp(-|M_z x|^2/2).
        # The common nonzero Gaussian is canceled only after differentiating it.
        transformed = ma*x
        moving_transformed = sub_xy(moving, ma)
        direct = canon(S.diff(moving_transformed, z)
                       - moving_transformed*(transformed.dot(ma.diff(z)*x)))
        rule = sub_xy(MOVING_TERM*S.diff(moving, z)
                      + ds_dz*polynomial_gaussian_field(moving, k), ma)
        residual = canon(direct-rule)
        record(label+":moving_input_product_rule", zero(residual), residual=residual)

        # Set membership of M^-1(S) is tested by evaluating S's predicate at Mx.
        candidate_membership_map = mc if SET_INVERSE else mc.inv()
        projection_difference = canon(sub_xy(spectral_poly, ma)
                                      - sub_xy(spectral_poly, candidate_membership_map))
        record(label+":spectral_set_polynomial", zero(projection_difference),
               residual=projection_difference)
        for zz in (S.Rational(1, 3), S.Rational(-2, 5)):
            actual_at = ma.subs(z, zz)
            candidate_at = candidate_membership_map.subs(z, zz)
            points = ((0, 0), (1, 2), (-2, 1), (3, -1), (4, 3))
            actual_bits, candidate_bits = [], []
            for ee, pp in points:
                actual_bits.append(bool(sub_xy(spectral_poly, actual_at).subs({e: ee, p: pp}) > 0))
                candidate_bits.append(bool(sub_xy(spectral_poly, candidate_at).subs({e: ee, p: pp}) > 0))
            record(label+f":projection_memberships:z={zz}", actual_bits == candidate_bits,
                   actual=actual_bits, candidate=candidate_bits)
            # Positive time and one negative spatial clock, tested as exponents.
            t, y = S.Rational(5, 7), S.Rational(-4, 5)
            phase = t*e-y*p/(k*k)
            direct_phase = sub_xy(phase, actual_at)
            c, d = mc[0, 0].subs(z, zz), -mc[0, 1].subs(z, zz)
            coordinate_phase = (c*t+d*y)*e-(k*k*d*t+c*y)*p/(k*k)
            record(label+f":negative_spatial_clock:z={zz}", zero(direct_phase-coordinate_phase),
                   residual=canon(direct_phase-coordinate_phase))

        # Explicit off-cone support point and finite boost, no asymptotic search.
        offcone = sub_xy(e, ma).subs({z: S.Rational(1, 2), e: 1, p: 3*k})
        record(label+":offcone_positive_energy_failure", offcone < 0, transformed_energy=offcone)
        for zz in (S.Rational(-3, 4), S.Rational(3, 4)):
            low = (1-abs(zz))/(1+abs(zz))
            high = 1/low
            energies = [canon(sub_xy(e, ma).subs({z: zz, e: 1, p: pp}))
                        for pp in (-k, S.Integer(0), k)]
            record(label+f":cone_graph_norm_bounds:z={zz}",
                   all(low <= energy <= high for energy in energies),
                   lower=low, upper=high, energies=energies)

    # Continuous-spectrum cancellation strip, c=5/3,d=8/9 (k=3/2,z=1/2).
    c = S.Rational(5, 3)
    d = S.Rational(8, 9)
    norm2 = S.integrate(1/(1+r)**2, (r, 1, S.oo))/c
    mixed2 = S.integrate(q*q, (q, 0, 1))*S.integrate(1/(1+r)**2, (r, 1, S.oo))/c
    p2 = S.integrate(r*r/(1+r)**2, (r, 1, S.oo))/c
    h2_lower = (d*d/(c*c))*p2
    selected_integral = mixed2 if MAXIMAL_DOMAIN else S.Max(p2, h2_lower)
    record("cancellation_strip:vector_in_hilbert_space", norm2.is_finite and norm2 > 0, integral=norm2)
    record("cancellation_strip:full_mixed_domain", selected_integral.is_finite,
           selected_integral=selected_integral, maximal_integral=mixed2)
    record("cancellation_strip:not_in_individual_domains", p2 == S.oo and h2_lower == S.oo,
           p_integral=p2, h_integral_lower=h2_lower)

    # Same dense differential action does not fix self-adjoint boundary conditions.
    phases = [S.exp(S.I*theta) for theta in (0, S.pi)]
    discrepancy = S.Abs(phases[0]-phases[1])
    record("dense_domain_shortcut:distinct_time_one_groups", discrepancy == 2,
           time_one_phases=phases, operator_norm_difference=discrepancy)

    result = {"schema": 1, "scope": "exact plane and polynomial-Gaussian diagnostics only",
              "rows": rows, "pass": sum(row["pass"] for row in rows),
              "fail": sum(not row["pass"] for row in rows),
              "versions": {"python": sys.version, "sympy": S.__version__}}
    with open(args.output, "w") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(f"TOTAL: PASS={result['pass']} FAIL={result['fail']}")
    return 0 if result["fail"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
