#!/usr/bin/env python3
"""Bounded review runner, complete logs and immutable attempt paths."""
import argparse
import hashlib
import json
import pathlib
import platform
import subprocess
import time
from datetime import datetime, timezone

parser = argparse.ArgumentParser()
parser.add_argument("--directory", required=True)
parser.add_argument("--timeout", type=float, required=True)
parser.add_argument("--source", action="append", default=[])
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ["--"] else args.command
out = pathlib.Path(args.directory).resolve()
out.mkdir(parents=True, exist_ok=False)
sources = []
for value in args.source:
    source = pathlib.Path(value).resolve()
    data = source.read_bytes()
    sources.append({"path": str(source), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
start = time.monotonic()
started = datetime.now(timezone.utc).isoformat()
try:
    run = subprocess.run(command, capture_output=True, timeout=args.timeout)
    stdout, stderr, exit_code, timeout = run.stdout, run.stderr, run.returncode, False
except subprocess.TimeoutExpired as exc:
    stdout, stderr, exit_code, timeout = exc.stdout or b"", exc.stderr or b"", None, True
elapsed = time.monotonic() - start
(out / "stdout.txt").write_bytes(stdout)
(out / "stderr.txt").write_bytes(stderr)
receipt = {"command": command, "cwd": str(pathlib.Path.cwd()), "timeout_seconds": args.timeout,
           "started_utc": started, "elapsed_seconds": elapsed, "exit_code": exit_code,
           "timed_out": timeout, "sources": sources, "python": platform.python_version(),
           "streams": {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                       for name, data in (("stdout.txt", stdout), ("stderr.txt", stderr))}}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps({"directory": str(out), "exit_code": exit_code, "timed_out": timeout,
                  "elapsed_seconds": elapsed, "stdout_bytes": len(stdout), "stderr_bytes": len(stderr)}))
