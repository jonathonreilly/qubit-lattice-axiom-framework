#!/usr/bin/env python3
"""Provenance control only; a matching hash grants no scientific status."""
import argparse
import hashlib
import json
from pathlib import Path

EXPECTED = "71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed"
parser = argparse.ArgumentParser()
parser.add_argument("path")
args = parser.parse_args()
try:
    digest = hashlib.sha256(Path(args.path).read_bytes()).hexdigest()
    result = {"path": args.path, "sha256": digest, "expected_sha256": EXPECTED,
              "match": digest == EXPECTED, "error": None}
except OSError as exc:
    result = {"path": args.path, "sha256": None, "expected_sha256": EXPECTED,
              "match": False, "error": str(exc)}
print(json.dumps(result, sort_keys=True))
raise SystemExit(0 if result["match"] else 1)
