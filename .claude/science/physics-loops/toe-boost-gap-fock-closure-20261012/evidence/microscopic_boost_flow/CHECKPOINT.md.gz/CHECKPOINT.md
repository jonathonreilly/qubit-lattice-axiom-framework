# Microscopic boost flow — final author checkpoint

Updated 2026-10-12T04:14:33.556268+00:00. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.

Frozen deliverable: `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/MICROSCOPIC_BOOST_FLOW_PROBE.md`
SHA-256 `7ec1d7eecb4eba020548eba8b56dff66712f52b4eba634ba276dd67440d28de7`; 758 lines, 37399 bytes.
The author run is complete. Independent proof review is pending; root alone
owns publication. No source has scientific audit status from this packet.

The complete proof was saved before controls in `PROOF_BEFORE_CONTROLS.md`
at SHA-256 `526aa21d8346b49602779c08dbaf95801af5f194cd7fdcc4c2ec578e18b0ddc7`.
The entire initial proof and complete later diff were cold-read. Final control
source `5a404e8ff79a64f004603d9ae6841675c294fd5d566818c05646974048cec76b` was read in full, every canonical row was inspected,
and all changes in mutation output were inspected. Source reading and scope
are specified in the note; `logs/source_refresh.json` rechecks the exact bytes.

Conditional result: B1 finite-range spin density gives the all-time spatially
weighted flow by checked TWW/NSY machinery. The dyadic estimate with
q>ν+d+1 gives a local graph approximation and a C1 rapid AL orbit. Supplied
ωδ_b=0 extends and integrates, giving an actual canonical self-adjoint B.
Graph approximation plus C1 Schrödinger uniqueness identifies any supplied
self-adjoint B with the same local action. With ωδ_h=0 too, finite Jacobi
gives ωδ_p=0, canonical P, and i[H,B]=P on the same invariant local D.
No centre/joint-flow candidate is a dependency.

Source identities: TWW `bd67842f411193b3727a1d90aa7c47573c1db63e4b58a3a8d8bcf57ad5d4be0d`;
NSY `291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722`;
current probe `bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`;
current review `305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17`.
Planning source and unchanged instruction inputs match their saved identities.
The root lead's dated reading-status addition is separately saved; it changes
no proof hypothesis. No Git command was authorized or used.

Verification: final canonical run 49 predicates, zero failures, exit 0,
60-second declared timeout. Mutations drop-position / reverse-clock /
drop-GNS-right / reverse-current produced 13 / 12 / 6 / 2 failures and exit 1
under 30-second timeouts. Complete results and execution receipts are bound
in `receipt.json`. These are author finite controls, not independent review
or proofs of infinite-volume convergence/domains. The right-action mutant
still passes adjoint implementation but fails cyclic-vector/local action;
the note names other nondiscriminating checks and limits.

Preserved failures: gzip-vs-tar source extraction; colliding initial log
names; first C1 control's formal-derivative weakness; failed prose patch
contexts. See `logs/operational_history.json` and its linked originals.
Failed shortcuts: arbitrary norm approximation is not graph approximation;
factorial-squared bounds do not prove boost analyticity; stationarity and
translation invariance do not supply ωδ_b=0. Exact counterexamples are in
the proof and checked finite fixtures.

Remaining obligations: fresh independent review of this exact note and
evidence, then root's disposition. The physical density/state identities,
positive energy/spectrum/vacuum structure, Lorentz/Lie and strong joint-flow
closure, scalar-representation identification, centre rate and regular-target
density remain separately supplied/open. The possible gapped-state route
for retiring boost invariance is outside this packet.

No editable prompt, axiom, prior frozen packet, repository file, Git ref,
PR, merge/push or audit verdict was changed. No model override, subdelegation
or other-chat message was used. Root can now dispatch a fresh reviewer with
the note, `receipt.json`, sources and full evidence.
