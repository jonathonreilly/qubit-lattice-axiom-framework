#!/usr/bin/env python3
"""Bind the completed author proof/evidence. This checks identity, not mathematics."""
import datetime as dt
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
NOTE = ROOT.parent / "MICROSCOPIC_BOOST_FLOW_PROBE.md"


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw),
            "lines": len(raw.splitlines()), "sha256": hashlib.sha256(raw).hexdigest()}


def write(path, content):
    path.write_text(json.dumps(content, indent=2) + "\n")


def main():
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    original = json.loads((ROOT / "sources/manifest.json").read_text())
    source_checks = []
    for row in original["rows"]:
        snapshot = identity(Path(row["snapshot"]))
        source = identity(Path(row["source"]))
        assert snapshot["sha256"] == row["sha256"], row["snapshot"]
        if Path(row["snapshot"]).name == "root_lead.md":
            updated = identity(ROOT / "sources/root_lead_after_reading_addendum.md")
            assert source["sha256"] == updated["sha256"], "root lead changed again"
            relation = "Original candidate context preserved; current source equals separately read dated addendum."
        else:
            assert source["sha256"] == snapshot["sha256"], row["source"]
            relation = "Current source matches read snapshot."
        source_checks.append({"source": source, "snapshot": snapshot, "relation": relation})
    extras = [identity(ROOT / "sources/NSY_1705.08553v3.source"),
              identity(ROOT / "sources/NSY_1705.08553v3.tex"),
              identity(ROOT / "sources/root_lead_after_reading_addendum.md")]
    assert extras[1]["sha256"] == "291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722"
    write(ROOT / "logs/source_refresh.json", {"utc": now, "checks": source_checks,
                                              "extra_sources": extras,
                                              "limits": "No Git fetch/head lookup authorized; identity is tied to exact available source bytes and root-supplied authority."})

    helper_sha = identity(ROOT / "finite_controls.py")["sha256"]
    logger_sha = identity(ROOT / "run_logged.py")["sha256"]
    final_runs = []
    outputs = {}
    for mutation in ["none", "drop_position", "reverse_clock", "drop_gns_right", "reverse_current"]:
        result_path = ROOT / f"finite_controls.final.{mutation}.json"
        result = json.loads(result_path.read_text())
        outputs[mutation] = result
        receipt_path = ROOT / "logs" / f"final.{mutation}.receipt.json"
        receipt = json.loads(receipt_path.read_text())
        assert result["source_sha256"] == helper_sha
        assert result["passed"] + result["failed"] == len(result["rows"]) == 49
        assert result["failed"] == sum(not row["passed"] for row in result["rows"])
        assert receipt["timed_out"] is False
        assert receipt["exit_code"] == (0 if mutation == "none" else 1)
        expected_failed = {"none": 0, "drop_position": 13, "reverse_clock": 12,
                           "drop_gns_right": 6, "reverse_current": 2}[mutation]
        assert result["failed"] == expected_failed
        assert receipt["timeout_seconds"] == (60 if mutation == "none" else 30)
        for item in receipt["sources"]:
            actual = identity(Path(item["path"]))
            assert actual["sha256"] == item["sha256"]
        for suffix in ["stdout", "stderr"]:
            actual = identity(Path(receipt[suffix]["path"]))
            assert actual["sha256"] == receipt[suffix]["sha256"]
        assert Path(receipt["stderr"]["path"]).read_bytes() == b""
        stdout = [json.loads(line) for line in Path(receipt["stdout"]["path"]).read_text().splitlines()]
        assert stdout[:-1] == result["rows"]
        assert stdout[-1]["total_failed"] == result["failed"]
        final_runs.append({"mutation": mutation, "result": identity(result_path),
                           "receipt": identity(receipt_path), "exit_code": receipt["exit_code"],
                           "timeout_seconds": receipt["timeout_seconds"],
                           "elapsed_seconds": receipt["elapsed_seconds"],
                           "passed": result["passed"], "failed": result["failed"]})
    base = {r["name"]: r for r in outputs["none"]["rows"]}
    mutation_comparison = []
    for m, result in outputs.items():
        if m == "none":
            continue
        changed = [row for row in result["rows"] if row != base[row["name"]]]
        mutation_comparison.append({"mutation": m, "source_sha256": helper_sha,
                                    "failed": result["failed"], "changed_rows": changed,
                                    "unchanged_row_count": len(result["rows"]) - len(changed)})
    write(ROOT / "logs/mutation_comparison.json", mutation_comparison)
    write(ROOT / "logs/final_evidence_validation.json", {"utc": now, "final_runs": final_runs,
                                                         "all_stdout_rows_equal_result_rows": True,
                                                         "all_source_and_output_hashes_match": True,
                                                         "scope": "Mechanical identity/receipt validation only; no scientific verdict."})
    history = {
        "utc": now,
        "events": [
            {"event": "Source display clipping", "disposition": "Affected instruction/source spans reread in smaller chunks; no clipped proof segment counted as a full read."},
            {"event": "NSY extraction failure", "evidence": "logs/NSY_fetch.json", "recovery": "logs/NSY_decompress_recovery.json", "disposition": "Download succeeded; tar format assumption failed. Original gzip-compressed TeX recovered without refetch or content changes."},
            {"event": "First execution log paths collided", "evidence": "logs/colliding_log_names_first_runs/incident.json", "disposition": "Distinct first-run result JSONs preserved. Surviving overwritten raw log/receipt preserved. Missing original logs are not reconstructed. Fixed logger appends extensions to complete names; later runs have unique complete receipts."},
            {"event": "C1 control did not differentiate mutated orbit", "evidence": "logs/before_C1_control_refinement/incident.json", "disposition": "Formal commutator comparison replaced by finite difference of actual orbit. Unchanged analytic proof; all final runs replayed with corrected helper."},
            {"event": "Two prose-patch context failures", "disposition": "No file changes on either failure. Verified note hash still equaled pre-control freeze. Applied source-ordered hunks, then evidence appendix separately."}
        ],
        "early_execution_limit": "Initial acquisition shell reads/copies did not each receive a dedicated subprocess timeout receipt. All final computational evidence and the replayed statement search have exact commands, declared timeouts, source/output hashes, full stdout/stderr and actual elapsed/exit metadata."
    }
    write(ROOT / "logs/operational_history.json", history)
    note_id = identity(NOTE)
    checkpoint = f"""# Microscopic boost flow — final author checkpoint

Updated {now}. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.

Frozen deliverable: `{NOTE}`
SHA-256 `{note_id['sha256']}`; {note_id['lines']} lines, {note_id['bytes']} bytes.
The author run is complete. Independent proof review is pending; root alone
owns publication. No source has scientific audit status from this packet.

The complete proof was saved before controls in `PROOF_BEFORE_CONTROLS.md`
at SHA-256 `526aa21d8346b49602779c08dbaf95801af5f194cd7fdcc4c2ec578e18b0ddc7`.
The entire initial proof and complete later diff were cold-read. Final control
source `{helper_sha}` was read in full, every canonical row was inspected,
and all changes in mutation output were inspected. Source reading and scope
are specified in the note; `logs/source_refresh.json` rechecks the exact bytes.

Conditional result: B1 finite-range spin density gives the all-time spatially
weighted flow by checked TWW/NSY machinery. The dyadic estimate with
q>ν+d+1 gives a local graph approximation and a C1 rapid AL orbit. Supplied
ωδ_b=0 extends and integrates, giving an actual canonical self-adjoint B.
Graph approximation plus C1 Schrödinger uniqueness identifies any supplied
self-adjoint B with the same local action. With ωδ_h=0 too, finite Jacobi
gives ωδ_p=0, canonical P, and i[H,B]=P on the same invariant local D.
No centre/joint-flow candidate is a dependency.

Source identities: TWW `bd67842f411193b3727a1d90aa7c47573c1db63e4b58a3a8d8bcf57ad5d4be0d`;
NSY `291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722`;
current probe `bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`;
current review `305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17`.
Planning source and unchanged instruction inputs match their saved identities.
The root lead's dated reading-status addition is separately saved; it changes
no proof hypothesis. No Git command was authorized or used.

Verification: final canonical run 49 predicates, zero failures, exit 0,
60-second declared timeout. Mutations drop-position / reverse-clock /
drop-GNS-right / reverse-current produced 13 / 12 / 6 / 2 failures and exit 1
under 30-second timeouts. Complete results and execution receipts are bound
in `receipt.json`. These are author finite controls, not independent review
or proofs of infinite-volume convergence/domains. The right-action mutant
still passes adjoint implementation but fails cyclic-vector/local action;
the note names other nondiscriminating checks and limits.

Preserved failures: gzip-vs-tar source extraction; colliding initial log
names; first C1 control's formal-derivative weakness; failed prose patch
contexts. See `logs/operational_history.json` and its linked originals.
Failed shortcuts: arbitrary norm approximation is not graph approximation;
factorial-squared bounds do not prove boost analyticity; stationarity and
translation invariance do not supply ωδ_b=0. Exact counterexamples are in
the proof and checked finite fixtures.

Remaining obligations: fresh independent review of this exact note and
evidence, then root's disposition. The physical density/state identities,
positive energy/spectrum/vacuum structure, Lorentz/Lie and strong joint-flow
closure, scalar-representation identification, centre rate and regular-target
density remain separately supplied/open. The possible gapped-state route
for retiring boost invariance is outside this packet.

No editable prompt, axiom, prior frozen packet, repository file, Git ref,
PR, merge/push or audit verdict was changed. No model override, subdelegation
or other-chat message was used. Root can now dispatch a fresh reviewer with
the note, `receipt.json`, sources and full evidence.
"""
    (ROOT / "CHECKPOINT.md").write_text(checkpoint)
    read_coverage = {
        "utc": now,
        "proof": {**note_id, "coverage": "All original 688 proof lines plus complete final change diff; load-bearing derivation manually checked."},
        "TWW": {"source": "sources/TWW_main.tex", "lines": [1, 959], "coverage": "Complete original source, including proofs and appendix; theorem-counter definitions inspected in common.tex."},
        "NSY": {"source": "sources/NSY_1705.08553v3.tex", "lines": [272, 623], "coverage": "Complete relevant Section 3: finite-volume dynamics, kernel conditions, Theorem 3.1, lemmas and commutator proof. Other sections are not a dependency and were not fully read."},
        "current": {"probe": "sources/current_probe.md", "review": "sources/current_review.md", "coverage": "Both complete. A clipped I22–I25 span was reread explicitly."},
        "controls": {"source": identity(ROOT / "finite_controls.py"), "coverage": "Complete final source, all canonical rows and all changed mutation rows; unchanged rows mechanically compared."},
        "limits": "Same author, inherited root proposal; no independent/blind review, Lean or audit. Original evidence is available; hashes do not certify mathematics."
    }
    write(ROOT / "logs/read_coverage.json", read_coverage)
    excluded = {"receipt.json"}
    evidence = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and path.name not in excluded and not path.name.startswith("packet_metadata."):
            evidence.append(identity(path))
    receipt = {"frozen_utc": now, "author_status": "conditional proof complete; independent review pending",
               "note": note_id, "critical_control_source": identity(ROOT / "finite_controls.py"),
               "proof_before_controls": identity(ROOT / "PROOF_BEFORE_CONTROLS.md"),
               "execution_summary": final_runs, "source_refresh": identity(ROOT / "logs/source_refresh.json"),
               "read_coverage": identity(ROOT / "logs/read_coverage.json"),
               "evidence_files": evidence,
               "manifest_scope": "All existing packet files except receipt.json and the finalizer's own packet_metadata execution outputs, which are produced after it returns. The sibling final note is separately bound. This is identity evidence, not a scientific verdict.",
               "authorization": {"git_commands": False, "repository_edits": False, "PR_actions": False,
                                  "audit_actions": False, "prompt_edits": False, "axiom_edits": False,
                                  "subdelegation": False, "model_override": False,
                                  "other_chat_messages": False},
               "deadline_utc": "2026-10-12 16:00:52 UTC"}
    write(ROOT / "receipt.json", receipt)
    print(json.dumps({"note": note_id, "receipt_sha256": identity(ROOT / "receipt.json")["sha256"],
                      "bound_evidence_files": len(evidence), "source_checks": len(source_checks),
                      "canonical_predicates": 49, "canonical_failures": 0,
                      "review": "pending"}, indent=2))


if __name__ == "__main__":
    main()
