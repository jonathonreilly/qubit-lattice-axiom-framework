#!/usr/bin/env python3
"""Run one bounded evidence command; preserve full output and its source hashes."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    p.add_argument("--timeout", type=float, required=True)
    p.add_argument("--cwd", default=str(Path(__file__).resolve().parent))
    p.add_argument("--source", action="append", default=[])
    p.add_argument("command", nargs=argparse.REMAINDER)
    args = p.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        p.error("no command")
    out = Path(__file__).resolve().parent / "logs"
    out.mkdir(exist_ok=True)
    base = out / args.name
    sources = []
    for name in args.source:
        source = Path(name).resolve()
        raw = source.read_bytes()
        sources.append({"path": str(source), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
    receipt = {"command": command, "cwd": str(Path(args.cwd).resolve()),
               "timeout_seconds": args.timeout, "sources": sources,
               "started_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
    started = time.monotonic()
    try:
        result = subprocess.run(command, cwd=args.cwd, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=args.timeout, check=False)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
        receipt["timed_out"] = False
    except subprocess.TimeoutExpired as e:
        stdout, stderr, code = e.stdout or b"", e.stderr or b"", 124
        receipt["timed_out"] = True
    except Exception as e:
        stdout, stderr, code = b"", repr(e).encode(), 125
        receipt["execution_error"] = repr(e)
    receipt.update(ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                   elapsed_seconds=time.monotonic() - started, exit_code=code)
    for suffix, data in (("stdout", stdout), ("stderr", stderr)):
        file = base.with_suffix("." + suffix)
        file.write_bytes(data)
        receipt[suffix] = {"path": str(file), "bytes": len(data),
                           "sha256": hashlib.sha256(data).hexdigest()}
    base.with_suffix(".receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"name": args.name, "exit_code": code,
                      "elapsed_seconds": receipt["elapsed_seconds"],
                      "timed_out": receipt.get("timed_out"),
                      "stdout_bytes": len(stdout), "stderr_bytes": len(stderr)}))
    return code


if __name__ == "__main__":
    sys.exit(main())
