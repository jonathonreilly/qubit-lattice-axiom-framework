# Control analysis and verification limits

The independent control was frozen at 04:57:25 UTC, and the mathematical
reconstruction at 05:01:28 UTC, before reading the author helper, output or
receipt contents. The complete candidate note had disclosed its formulas and
author-control outcomes, so this was not blind testing. The review used a
separate agent context and inherited the selected model/effort. No
cross-family independence is claimed, and the author's precise runtime model
configuration was not independently inspected. The phrase "same-family" in
the frozen reconstruction is not an independently established provenance fact.

The decisive domain control is the infinite trace-GNS construction proved in
`INDEPENDENT_RECONSTRUCTION.frozen.md`, not a numeric PASS count. For onsite
`h_x=Z_x`, the rapid-AL observable `A=sum exp(-sqrt(n)) X_n` has an actual C1
orbit and convergent local graph approximants, but
`r^k ||B^k A Omega||/k! >= (8 r exp(-2) k)^k` for every `r>0`.
This is a rigorous zero-analytic-radius example for a rapid-AL vector.
It does not establish nonanalyticity of local vectors. The distinction
validates the candidate's graph/C1 method and rejects a stronger shortcut.

The independent sparse-Pauli helper uses exact Gaussian rational arithmetic
and the density `h_x=2 X_x X_(x+1)+3 Y_x Z_(x+1)+5 Z_x`. Adaptive local
double derivations are compared with the independently assembled displacement
current on every Pauli word of the disconnected seed `{-1,0,2}`. The code
does not import, execute or share the author's Kronecker/expm implementation.
The common basic Pauli algebra and known claimed identity are shared inputs.
All 64 words agree exactly, including the identity word.

The independent canonical run had 71 passing predicates. Reversed current
sign, omitted pair displacement and insufficient finite-centre padding each
fail on all 63 nonidentity probes and exit 1. The identity probe remains
nondiscriminating, as it must. The onset of a spectral finite-difference
error is checked separately: the canonical error halves with ratios
1.999286, 1.999821, 1.999955. A reversed clock instead plateaus near
7.740005, and an omitted position weight plateaus near 3.227554. Those two
mutations each fail the convergence gate and exit 1. The algebra gates are
unchanged by mutations that affect only the spectral experiment. The
analytic-radius and graph-tail rows are illustrations of the separately
written inequalities; they do not prove their quantified limits by sampling.

The entire 268-line author helper and 63-line logger were read, along with
all 49 canonical output rows and the changed mutation outputs. The source
was copied without modification and replayed in this review directory. The
canonical and four mutation runs reproduced stdout byte for byte and every
JSON field except the fresh timestamp. Their results are respectively
49/0, 36/13, 37/12, 43/6 and 47/2 passing/failing predicates.

The author controls have the disclosed limitations:

- A finite trace state is invariant under every finite inner automorphism;
  this does not establish the infinite-state implication in B22.
- Norm preservation accepts either clock, so the trigonometric comparison
  and actual-orbit derivative are the discriminating checks.
- Dropping the GNS right action still implements the same adjoint algebra
  action because the omitted right action lies in the commutant. The
  cyclic-vector, local-action and group-column checks reject it.
- With omitted position weights, the GNS construction remains internally
  correct for the altered generator, so those GNS checks still pass. The
  independently anchored spatial-weight controls and current identity reject
  the alteration.
- The exact B16 bound is very loose on the finite dyadic fixture: its
  observed/bound ratios range from about 1.43e-4 down to 8.35e-16. It is not
  a discriminating proof of the optimal loss or endpoint, neither of which
  the note claims. The explicit geometric-series derivation establishes the
  stated strict loss.
- Finite matrices cannot establish all-time infinite-volume dynamics,
  generator-domain inclusions, operator uniqueness or the physical premises.
  These depend on the reconstructed proofs and checked literature hypotheses.

The archived earlier C1 source substituted `i[b,evolved]` for the derivative;
its changed-source diff confirms why that individual gate could not detect a
reversed clock. The final source uses an actual fourth-order difference
quotient, and its reversed-clock derivative residual is about 1.52069 at
both times, well above 2e-10. The original weak gate and overwritten initial
log incident remain preserved in the author packet; no original missing
stream has been reconstructed.

All eleven current science executions (six independent, five author replay)
have commands, declared 60-second canonical or 30-second mutation timeouts,
source hashes before/after, elapsed time, exit status, complete stdout/stderr
and result JSON. Full reproduction comparisons are in
`author_reproduction_comparison.json`; source identities are checked in
`author_receipt_verification.json`. Source inventory establishes provenance
only. It does not stand in for the mathematical reconstruction.
