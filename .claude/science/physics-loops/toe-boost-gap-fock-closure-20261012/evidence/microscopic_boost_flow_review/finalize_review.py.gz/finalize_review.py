#!/usr/bin/env python3
"""Verify identities/streams and bind the human-authored source review.

This script performs bookkeeping only and does not adjudicate mathematics.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

D = Path(__file__).resolve().parent
S = D.parent
A = S / "microscopic_boost_flow"
R = S.parent / "scattering_worktree"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def info(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw),
            "lines": len(raw.splitlines())}


def main():
    expected = {
        S / "MICROSCOPIC_BOOST_FLOW_PROBE.md": "7ec1d7eecb4eba020548eba8b56dff66712f52b4eba634ba276dd67440d28de7",
        A / "receipt.json": "556db66a03600f637ba47663e4faca9202d48baab65cbf81828e08015faa15c9",
        A / "finite_controls.py": "5a404e8ff79a64f004603d9ae6841675c294fd5d566818c05646974048cec76b",
        S / "MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md": "bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a",
        S / "MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md": "305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17",
        S / "growing_generator_literature/source_files/main.tex": "bd67842f411193b3727a1d90aa7c47573c1db63e4b58a3a8d8bcf57ad5d4be0d",
        S / "growing_generator_literature/source_files/common.tex": "743220af9c98e077199f2dfbdc72814434862bab0cd61ac80f8ae40d94f51fec",
        A / "sources/NSY_1705.08553v3.tex": "291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722",
        S / "centre_regularity_to_geometric/sources/planning_AGENTS.md": "3d409e93abb3b58796a9c10ca6d21ba93b7edc73b8fb24e7364da97c805580a9",
        R / "docs/ai_methodology/skills/review-loop/references/FIXES_AND_REPORTING.md": "8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e",
        D / "CONTROL_FREEZE.md": "151512ef7fe05374b29b25300e739cf073eabd53486f85c7e39fd1597d8708f6",
        D / "INDEPENDENT_RECONSTRUCTION.frozen.md": "8d3717a15e0e5b39ddb093deca35f4bb5aa5b8437397370323271b1858438dec",
        D / "independent_controls.py": "8e9bf5d4f77cdc45bdcfbc22b797535e37db73a2cfaca2d887e11cd1b85f3960",
    }
    failures = []
    source_rows = []
    for path, want in expected.items():
        row = {**info(path), "expected_sha256": want, "match": sha(path) == want}
        source_rows.append(row)
        if not row["match"]:
            failures.append("Source drift: " + str(path))

    instruction_paths = [
        "AGENTS.md", "CLAUDE.md", "docs/ai_methodology/SCIENCE_WORKFLOW.md",
        "docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md",
        "docs/ai_methodology/skills/physics-claim-reviewer/SKILL.md",
        "docs/ai_methodology/skills/workhorse/SKILL.md",
        "docs/ai_methodology/skills/review-loop/SKILL.md",
        "docs/ai_methodology/skills/review-loop/references/FIXES_AND_REPORTING.md",
        "docs/ai_methodology/skills/review-loop/references/SCIENCE_LENSES.md",
        "docs/ai_methodology/skills/review-loop/references/REVIEW_UNITS.md",
        "docs/ai_methodology/skills/review-loop/references/AUDIT_COMPATIBILITY.md",
        "docs/ai_methodology/skills/physics-loop/references/proof-search-governance.md",
        "docs/MINIMAL_AXIOMS_2026-06-29.md",
        "docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md",
        "docs/audit/data/axiom_premise_nodes.json",
        "docs/REALIZED_STATE_PRIMITIVE_NOTE_2026-06-11.md",
        "docs/SCALE_REFERENCE_PRIMITIVE_NOTE.md",
        "docs/KINETIC_ISOTROPY_PRIMITIVE_NOTE_2026-06-09.md",
    ]
    authority = "a13caa4885f547c8d206265b031ba7649e539fd9"
    authority_rows = []
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    for index, name in enumerate(instruction_paths):
        command = ["git", "show", authority + ":" + name]
        result = subprocess.run(command, cwd=R, env=env, stdin=subprocess.DEVNULL,
                                capture_output=True, timeout=10)
        stem = D / "logs" / ("authority." + str(index))
        Path(str(stem) + ".stdout").write_bytes(result.stdout)
        Path(str(stem) + ".stderr").write_bytes(result.stderr)
        same = result.returncode == 0 and result.stdout == (R / name).read_bytes()
        row = {"command": command, "cwd": str(R), "declared_timeout_seconds": 10,
               "exit_code": result.returncode, "source": info(R / name), "matches_pinned_main": same,
               "stdout": info(Path(str(stem) + ".stdout")), "stderr": info(Path(str(stem) + ".stderr"))}
        authority_rows.append(row)
        if not same:
            failures.append("Instruction/premise authority mismatch: " + name)
    planning_command = ["git", "show", "3a4b2c66a1ead7a1c48b4359627e968f681e3c39:AGENTS.md"]
    planning = subprocess.run(planning_command, cwd=R, env=env, stdin=subprocess.DEVNULL,
                              capture_output=True, timeout=10)
    (D / "logs/planning.stdout").write_bytes(planning.stdout)
    (D / "logs/planning.stderr").write_bytes(planning.stderr)
    planning_same = planning.returncode == 0 and planning.stdout == (S / "centre_regularity_to_geometric/sources/planning_AGENTS.md").read_bytes()
    if not planning_same:
        failures.append("Planning authority mismatch")

    author_checks = {}
    def inspect_refs(value):
        if isinstance(value, dict):
            if "path" in value and "sha256" in value:
                p = Path(value["path"])
                actual = sha(p)
                author_checks[str(p)] = {"expected": value["sha256"], "actual": actual, "match": actual == value["sha256"]}
                if actual != value["sha256"]:
                    failures.append("Author receipt mismatch: " + str(p))
            for nested in value.values():
                inspect_refs(nested)
        elif isinstance(value, list):
            for nested in value:
                inspect_refs(nested)
    inspect_refs(json.loads((A / "receipt.json").read_text()))

    run_rows = []
    for p in sorted((D / "logs").glob("*.receipt.json")):
        if not (p.name.startswith("independent.") or p.name.startswith("author.")):
            continue
        rec = json.loads(p.read_text())
        is_good = not rec["timed_out"] and rec["sources_before"] == rec["sources_after"]
        for source, want in rec["sources_after"].items():
            is_good = is_good and sha(Path(source)) == want
        for stream in rec["streams"].values():
            is_good = is_good and sha(Path(stream["path"])) == stream["sha256"]
        run_rows.append({"receipt": info(p), "verified": is_good, "elapsed_seconds": rec["elapsed_seconds"],
                         "exit_code": rec["exit_code"], "declared_timeout_seconds": rec["declared_timeout_seconds"]})
        if not is_good:
            failures.append("Run receipt drift: " + str(p))
    if len(run_rows) != 11:
        failures.append("Expected eleven science executions")

    manifest = {"utc": datetime.now(timezone.utc).isoformat(), "scope": "Exact proof/input and evidence provenance, not scientific adjudication",
                "bound_sources": source_rows, "authority": authority_rows,
                "planning": {"command": planning_command, "declared_timeout_seconds": 10,
                             "exit_code": planning.returncode, "matches_saved_planning": planning_same,
                             "stdout": info(D / "logs/planning.stdout"), "stderr": info(D / "logs/planning.stderr")},
                "author_receipt_file_checks": author_checks, "science_runs": run_rows, "failures": failures}
    (D / "source_manifest.final.json").write_text(json.dumps(manifest, indent=2) + "\n")
    receipt = {"utc": datetime.now(timezone.utc).isoformat(),
               "recommendation": "PASS for the stated conditional theorem" if not failures else "HOLD: provenance changed",
               "recommendation_authority": "Independent source reviewer; mathematical reasoning is in the named review/reconstruction, not computed by this script",
               "review": info(S / "MICROSCOPIC_BOOST_FLOW_REVIEW.md"),
               "source_manifest": info(D / "source_manifest.final.json"),
               "control_freeze": info(D / "CONTROL_FREEZE.md"),
               "reconstruction": info(D / "INDEPENDENT_RECONSTRUCTION.frozen.md"),
               "control_review": info(D / "CONTROL_REVIEW.md"),
               "iteration_count": 1, "material_findings": 0, "fixes": 0,
               "science_execution_count": len(run_rows),
               "science_execution_seconds": sum(row["elapsed_seconds"] for row in run_rows),
               "author_file_identity_count": len(author_checks),
               "full_pipeline_count": 0, "integration_retries": 0, "commits": [], "landing": None,
               "formal_audit_performed": False, "formalization_performed": False,
               "open_inputs": ["Finite-range density", "Supplied same-state local boost and energy identities", "Physical realization and downstream joint/centre identifications"],
               "failures": failures, "deadline_utc": "2026-10-12 16:00:52 UTC"}
    (D / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"review_sha256": receipt["review"]["sha256"], "manifest_sha256": receipt["source_manifest"]["sha256"],
                      "author_identity_count": len(author_checks), "authority_files": len(authority_rows),
                      "science_runs": len(run_rows), "science_seconds": receipt["science_execution_seconds"],
                      "failures": failures, "recommendation": receipt["recommendation"]}, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
