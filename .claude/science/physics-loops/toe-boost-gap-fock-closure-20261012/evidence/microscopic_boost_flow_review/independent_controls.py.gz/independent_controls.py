#!/usr/bin/env python3
"""Independent exact sparse-Pauli and spectral controls; no author import.

The infinite-series proof is INDEPENDENT_RECONSTRUCTION.frozen.md.
Finite computations here do not certify infinite volume or operator domains.
"""
import argparse
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys

ZERO = (F(0), F(0))
ONE = (F(1), F(0))
IMAG = (F(0), F(1))


def ga(a, b):
    return (a[0] + b[0], a[1] + b[1])


def gm(a, b):
    return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])


def phase(a, k):
    for _ in range(k % 4):
        a = (-a[1], a[0])
    return a


def add(*polys):
    out = {}
    for poly in polys:
        for word, coef in poly.items():
            out[word] = ga(out.get(word, ZERO), coef)
    return {word: coef for word, coef in out.items() if coef != ZERO}


def scale(poly, c):
    if isinstance(c, int) or isinstance(c, F):
        c = (F(c), F(0))
    return {word: gm(coef, c) for word, coef in poly.items() if gm(coef, c) != ZERO}


def word_product(a, b):
    out = dict(a)
    k = 0
    cyclic = {("X", "Y"): "Z", ("Y", "Z"): "X", ("Z", "X"): "Y"}
    for site, right in b:
        left = out.get(site)
        if left is None:
            out[site] = right
        elif left == right:
            del out[site]
        elif (left, right) in cyclic:
            out[site] = cyclic[left, right]
            k += 1
        else:
            out[site] = cyclic[right, left]
            k -= 1
    return tuple(sorted(out.items())), k % 4


def multiply(a, b):
    out = {}
    for wa, ca in a.items():
        for wb, cb in b.items():
            word, k = word_product(wa, wb)
            out[word] = ga(out.get(word, ZERO), phase(gm(ca, cb), k))
    return {word: coef for word, coef in out.items() if coef != ZERO}


def comm(a, b):
    return add(multiply(a, b), scale(multiply(b, a), -1))


def monomial(coef, *pairs):
    return {tuple(sorted(pairs)): (F(coef), F(0))}


def density(x):
    return add(monomial(2, (x, "X"), (x + 1, "X")),
               monomial(3, (x, "Y"), (x + 1, "Z")),
               monomial(5, (x, "Z")))


def support(a):
    return {site for word in a for site, _ in word}


def delta(a, weight, centres=None):
    sites = support(a)
    if centres is None:
        centres = sorted(sites | {x - 1 for x in sites})
    return scale(add(*(scale(comm(density(x), a), weight(x)) for x in centres)), IMAG)


def dh(a):
    return delta(a, lambda x: 1)


def db(a):
    return delta(a, lambda x: x)


def p_density(x, mutation):
    terms = []
    for r in range(-2, 3):
        displacement = 1 if mutation == "drop_displacement" else r
        terms.append(scale(comm(density(x), density(x + r)), displacement))
    result = scale(add(*terms), (F(0), F(1, 2)))
    return scale(result, -1 if mutation == "current_sign" else 1)


def dp(a, mutation):
    sites = support(a)
    if not sites:
        return {}
    centres = range(min(sites) - 3, max(sites) + 4)
    return scale(add(*(comm(p_density(x, mutation), a) for x in centres)), IMAG)


def l1(poly):
    return sum((abs(c[0]) + abs(c[1]) for c in poly.values()), F(0))


def serialize(poly):
    return [{"word": list(word), "real": str(c[0]), "imag": str(c[1])}
            for word, c in sorted(poly.items())]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mutation", default="none", choices=["none", "current_sign", "drop_displacement", "underpad", "clock", "drop_weight"])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []

    def check(name, ok, **evidence):
        row = {"name": name, "pass": bool(ok), **evidence}
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)

    # The multiplication table is separately anchored on two basic relations.
    X = monomial(1, (0, "X"))
    Y = monomial(1, (0, "Y"))
    Z = monomial(1, (0, "Z"))
    check("Pauli_XY_iZ", multiply(X, Y) == scale(Z, IMAG))
    check("Pauli_ZY_minus_iX", multiply(Z, Y) == scale(X, (F(0), F(-1))))
    check("disjoint_commute", comm(X, monomial(1, (3, "Y"))) == {})
    check("onsite_positive_clock_sign", scale(comm(Z, X), IMAG) == scale(Y, -2))

    # Full Pauli basis on a disconnected three-site seed; adaptive local sums
    # on the left are independent of the pair-current assembly on the right.
    for labels in itertools.product("IXYZ", repeat=3):
        sites = (-1, 0, 2)
        A = monomial(1, *((s, c) for s, c in zip(sites, labels) if c != "I"))
        direct = add(dh(db(A)), scale(db(dh(A)), -1))
        if args.mutation == "underpad":
            I = support(A)
            dhI = lambda C: delta(C, lambda x: 1, I)
            dbI = lambda C: delta(C, lambda x: x, I)
            candidate = add(dhI(dbI(A)), scale(dbI(dhI(A)), -1))
        else:
            candidate = dp(A, args.mutation)
        defect = add(direct, scale(candidate, -1))
        check("current_" + "".join(labels), not defect,
              direct_terms=len(direct), defect_l1=str(l1(defect)),
              first_defect=serialize(defect)[:1])

    # Spectral model: the two-dimensional frequency blocks +/-2n are derived
    # in the frozen proof. Arrays are scalar coefficient lists, no matrices.
    nmax = 4096
    deriv_sq = math.fsum((2 * n * math.exp(-math.sqrt(n))) ** 2 for n in range(1, nmax + 1))
    residuals = []
    for step in (0.002, 0.001, 0.0005, 0.00025):
        def contribution(n):
            weight = 1 if args.mutation == "drop_weight" else n
            clock = -1 if args.mutation == "clock" else 1
            a = math.exp(-math.sqrt(n))
            theta = clock * 2 * weight * step
            x = -2 * math.sin(theta / 2) ** 2 / step
            y = -math.sin(theta) / step + 2 * n
            return a * a * (x * x + y * y)
        residuals.append(math.sqrt(math.fsum(contribution(n) for n in range(1, nmax + 1))))
    ratios = [residuals[k] / residuals[k + 1] for k in range(3)]
    check("spectral_C1_first_order_convergence", all(1.8 < r < 2.2 for r in ratios),
          steps=[0.002, 0.001, 0.0005, 0.00025], residuals=residuals, ratios=ratios,
          truncated_n=nmax, derivative_norm=math.sqrt(deriv_sq),
          limitation="Finite truncation; the actual infinite C1/domain proof is in the frozen reconstruction.")

    # Exact analytic lower bound at n=4k^2: log of r^k||B^k xi||/k! >=
    # k(log(8r k)-2), using k! <= k^k. This is not a finite-cutoff claim.
    radius = F(1, 100)
    rows_lower = [{"k": k, "n": 4 * k * k,
                   "log_term_lower": k * (math.log(8 * float(radius) * k) - 2)}
                  for k in (128, 256, 512, 1024)]
    check("analytic_radius_lower_bound_growth", all(row["log_term_lower"] > 0 for row in rows_lower),
          radius=str(radius), sample_rows=rows_lower,
          theorem="For every r>0 the base 8*r*exp(-2)*k grows without bound. Samples illustrate, not prove, the quantified statement.")
    tails = []
    for N in (16, 64, 256, 1024, 4096):
        u = math.sqrt(N)
        tails.append({"N": N, "norm_tail_upper": 2 * (u + 1) * math.exp(-u),
                      "graph_tail_upper": 4 * math.exp(-u) * (u ** 3 + 3 * u ** 2 + 6 * u + 6)})
    check("spectral_graph_integral_bounds_decrease", all(tails[i+1]["graph_tail_upper"] < tails[i]["graph_tail_upper"] for i in range(4)),
          tails=tails, limitation="Integral majorants valid for N>=16; no arbitrary norm-approximation claim.")
    result = {"mutation": args.mutation, "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "python": sys.version, "rows": rows,
              "pass_count": sum(r["pass"] for r in rows), "fail_count": sum(not r["pass"] for r in rows)}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(f'TOTAL: PASS={result["pass_count"]} FAIL={result["fail_count"]}', flush=True)
    return int(result["fail_count"] != 0)


if __name__ == "__main__":
    raise SystemExit(main())
