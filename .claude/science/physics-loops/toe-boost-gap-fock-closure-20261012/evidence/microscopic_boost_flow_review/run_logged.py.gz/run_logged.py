#!/usr/bin/env python3
"""Capture each owned execution without overwriting evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    p.add_argument("--timeout", type=float, required=True)
    p.add_argument("--source", action="append", default=[])
    p.add_argument("command", nargs=argparse.REMAINDER)
    a = p.parse_args()
    command = a.command[1:] if a.command[:1] == ["--"] else a.command
    root = Path(__file__).resolve().parent
    prefix = root / "logs" / a.name
    prefix.parent.mkdir(exist_ok=True)
    paths = {kind: Path(str(prefix) + "." + kind) for kind in ("stdout", "stderr", "receipt.json")}
    if any(path.exists() for path in paths.values()):
        raise SystemExit("Evidence collision; choose a new name")
    sources = {str(Path(s).resolve()): hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in a.source}
    began = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    timed_out = False
    with paths["stdout"].open("xb") as out, paths["stderr"].open("xb") as err:
        try:
            run = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=a.timeout)
            code = run.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            code = None
    receipt = {"command": command, "cwd": str(root), "declared_timeout_seconds": a.timeout,
               "started_utc": began, "ended_utc": datetime.now(timezone.utc).isoformat(),
               "elapsed_seconds": time.monotonic() - started, "exit_code": code, "timed_out": timed_out,
               "sources_before": sources,
               "sources_after": {s: hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},
               "streams": {kind: {"path": str(paths[kind]), "sha256": hashlib.sha256(paths[kind].read_bytes()).hexdigest(),
                                    "bytes": paths[kind].stat().st_size} for kind in ("stdout", "stderr")}}
    paths["receipt.json"].write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return 124 if timed_out else code


if __name__ == "__main__":
    raise SystemExit(main())
