# Independent review of the microscopic current implementation lemma

**PASS for the stated conditional theorem at the frozen source.** I found no
mathematical defect in the complete I1–I31 argument and require no source
correction. This is an independent source review, not an audit verdict or a
construction of a physical boost/Poincaré model.

The reviewed note is `MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md`, all 399
lines, SHA-256 `bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`.
The author receipt is SHA-256
`1d298bbc206178f33be8851cc69481922682d0b78c8d68af7e09e5a5ecf31c37`.
Root supplied the mechanism and is a coauthor. This reviewer reconstructed
the proof and froze a separate control before opening the author's helper
or results. The source, its control descriptions and receipt metadata were
visible; root's preliminary no-defect message arrived after the written
reconstruction and before control-source freeze. This was not blind checking.

The precise conclusion checked is: the actual local-vector hypotheses
I1–I4 imply the current interaction I6/I8 and
`exp(it P_b) pi(A) exp(-it P_b) = pi(alpha_t^p(A))`
for every quasilocal A and real t. The negative current clock uses `-t`,
and replacing P by P/beta divides the time and interaction norm by beta once.

| Load-bearing step | Review result |
|---|---|
| Local-vector action and domains, lines 38–89 | The actual H/B action maps D into D, so HB/BH and every finite word are defined there. P-invariance and PΩ=0 then follow. No unspecified form domain or core is substituted. |
| Finite symmetrization and interaction, lines 90–159 | The 3R center padding makes Jacobi and pair exchange finite. The sign, both pair orientations and factor 1/2 agree. The assigned current radius is 3R, diameter 6R, and J is at most `v_(3R) h² c_(R,b)`. |
| Connected-history growth, lines 161–199 | The weighted history tree gives `norm(A) (2J)^n product_k(a+k(s-1))`. Its Taylor radius is independent of initial support size; disconnected supports, s=1, J=0, scalar A and R=0 are correctly handled. |
| Thermodynamic limit, lines 201–248 | Uniform Taylor remainders and coefficient stabilization give a small-time norm limit. Convergence of fixed compositions extends it to every real time and gives the automorphism group law. No uniform bound on the finite-volume Hamiltonian norm is used. |
| Self-adjoint P and GNS, lines 250–315 | The spectral Taylor remainder matches the algebra coefficients. State invariance then makes the canonical GNS action well-defined on null vectors. Equality on dense cyclic vectors gives the full adjoint implementation. Vacuum separation is never used. |
| Clocks and downstream scope, lines 317–352 | The negative current clock, single beta scaling and geometric covariance qualification agree with the contextual sources. Strong H/P or distinct-P commutation is not derived. |

The extra boost action and commutator relation on this exact D remain supplied,
as do existence/self-adjointness of the generators. The lemma removes
separate invariant-domain, product-domain, current-flow identification and
analytic-radius assumptions once those local actions are given. It does not
derive a boost realization, integrated Poincaré closure, strong joint
commutation, positive energy, particles, scattering completeness or physical
realization. No predecessor index/scattering theorem is certified by this review.

The independent control uses three open hopping sites, a pure nonseparating
vacuum, exact occupation-basis current matrices and the independently derived
polynomial exponential from `P³=P`. It checks the full 64 matrix-unit basis
and all 56 null-column basis elements. A deliberately incorrect right action
agrees on every vacuum column but has full-algebra norm defects 0.723230864
and 1.145734920 at the two tested times. It also detects the sign, half-factor,
clock and beta mutants. Three-site support histories include disconnected
seeds and give 15 histories at order two where omission of support growth
would permit only 9. All 34 finite predicates passed; the analytic proof,
rather than these finite examples, supports the infinite-volume conclusion.

I read the entire 334-line author helper and all 50 final output rows. An
unmodified copy reproduced all 50 rows and stdout exactly; only the result
JSON's timestamp changed. Five deliberate copied-source mutations exited 1:
current sign reversal, removal of the pair half-factor, inadequate current
center padding, omission of support growth, and a doubled Taylor derivative.
Their failed predicates and complete logs remain in the review directory.

Nondiscriminating cases are also preserved. Support/Hermiticity and the loose
norm bound accept the sign/half-factor mutants; the author's dense pair gate
uses a shared density input. The contiguous three-site history fixture still
accepts the omitted-growth bound through order seven, while the one-site and
disconnected two-site fixtures reject it from order two. The first Taylor
remainder accepts the doubled derivative's looser bound, while orders 2–6
reject it. None of these limited predicates is treated as proof of I1–I31.

There is one operational evidence limit: the original receipt records final
exit 0, but the examined author JSON logs contain no per-run declared timeout
or elapsed-time receipt. The new independent run and author replay each used
a declared 60-second timeout and completed with exit 0 in 0.250 and 0.679
seconds respectively. Each mutation used a declared 30-second timeout and
completed in under 0.5 seconds with its expected exit 1. These executions have
exact commands, source hashes, stdout, stderr, elapsed time and exit status.
No earlier metadata was invented. The two author platform disconnects and
recovered-draft discrepancy remain preserved in their original evidence.

The complete reconstruction, frozen control, source manifests, control analysis,
execution logs, operational record, checkpoint and final receipt are under
`microscopic_current_review/`. Key recovery files are
`INDEPENDENT_RECONSTRUCTION.frozen.md`, `independent_freeze.json`,
`CONTROL_REVIEW.md`, `source_manifest.final_verification.json`, and `receipt.json`.
All 40 author receipt/source checks matched after review. Authority remained
main `a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; the checkout's unrelated publication
movement to `f6f4348151734908dea3b32048ee1f36f694035b` changes no reviewed input.

Only this review and `microscopic_current_review/` were written. Frozen author
sources were unchanged. No editable prompt, axiom, audit result, Git ref or
repository source changed; no PR action, other-chat message, model override
or subdelegation occurred. Formalization was not run. Substantial reuse remains
conditional on the exact supplied premises; any changed proof/input needs
affected-source confirmation. Campaign deadline: 2026-10-12 16:00:52 UTC.
