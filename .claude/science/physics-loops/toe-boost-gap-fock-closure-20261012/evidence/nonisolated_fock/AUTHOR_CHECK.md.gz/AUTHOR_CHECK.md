# Author mathematical check and limits

This is the same author context, not an independent review. The source proof,
root lead and predecessor review descriptions were visible.

- Localization NF14: after removing alpha_(sigma T), all four remaining times
  have magnitude at most U=T^kappa. Conditional expectation norm is bounded;
  the input support has O(U^d) sites; padding R-r0-vU is at least 2U.
- Four-point geometry NF17-NF19: each nonzero local pair confines one relative
  coordinate to 2R. Pair supports lie within 3R of x2/x3, giving 6R subtraction.
  A norm cap treats the middle ball of radius 7R. Its outer tail has the displayed
  R^d support prefactor and R^(d-1) shell volume, with e^(-mu R) suppression.
- A deliberately weaker cross-check also works: use R^d times the exponential
  everywhere, including the near region. The three-relative sum is then
  O(R^(4d)), so a contraction still follows with kappa<1/4. This is a check of
  robustness to a looser estimate, not an independent proof or a change to NF25.
- Four independent clock measures have fixed L1 norms. Localization errors use
  four packet L1 factors, T^(2d); the union of the four tails has that same
  polynomial factor times arbitrary Schwartz decay. The central convolution
  uses one L1 and three supremum norms, T^(-d), not four supremum norms alone.
- The scalar contraction uses actual vacuum convergence. It is not replaced
  by exact graph support of an averaged vacuum vector.
- The double-commutator split belongs to the arbitrary third packet's own
  velocity map. Jacobi has a minus sign in NF29. No integration clocks coincide.
- NF31 keeps n-2 right spectators for each double bracket and m-1 left
  spectators. NF32 uses all m+n-2 remaining factors in a uniformly bounded
  mixed vacuum word, not unrestricted polynomial norms on the contraction error.
- Cutoff stability is a direct commuting-spectral inequality. Absolute
  continuity is inherited by domination from B Omega, not by treating E_s B
  as almost local. The closure in NF5 defines the only claimed one-particle
  space. Countable orthogonal actual projections avoid duplicate species copies.
- On common lifts, squared massive graphs differ by an affine polynomial.
  A nonidentical overlap can support only a Haar-null hyperplane, hence carries
  no regular vector. The local density proof partitions compact overlaps and
  drops only exactly zero targets. Velocity diagonal nullity follows from
  the explicit injective massive maps and Fubini, including mixed species.
- The Gram identity applies across any two individually separated finite
  presentations. It therefore makes the final linear map well-defined on
  their span before completion, including chart changes and particle number.

Failed shortcuts preserved: fixed-time almost-local constants at growing
relative times; collapse of averaging clocks; treating the support-volume
prefactor as free; dropping the connected projection or double brackets;
unpadded creator energy bounds; deriving full-sector regular-seed density from
cyclicity. The controls reject explicit finite versions of several shortcuts.
None is stated as a broad impossibility theorem.

No unresolved author proof obligation was found inside NF1-NF6's stated
conditional domain. Fresh independent review is pending. Existence/nonzero
regular targets, density in whole physical sectors, stable-sector derivation,
model realization, massless-vacuum clustering, detector/ND/EX/onto/boost results
are not conclusions of this packet.
