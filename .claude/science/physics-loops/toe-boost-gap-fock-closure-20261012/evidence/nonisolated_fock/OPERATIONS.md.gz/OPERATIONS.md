# Operations

- Initial `python` read failed because the unversioned executable was absent; reran with `python3`.
- A combined instruction output exceeded the display cap; the omitted instruction portions were reread explicitly. Truncation was not accepted as coverage.
- `pdftotext` was absent. Loaded the bundled dependency paths and used bundled Python/pypdf for complete page extraction.
- Created immutable source copies and original-to-publication diffs in this assigned evidence directory. No Git command was used.
- Complete Dybalski TeX was read in three disjoint ranges 1–245, 246–485, 486–673. Fresh BDN/NS extracts were read in complete page batches.
- The finite author control completed once under a 60-second timeout, exit 0, seven complete output records and empty stderr. All records and the complete helper were read. No numerical gate or case was changed after output inspection.
- The cold proof read found inline math delimiters lost by a JavaScript string escape and one backspace escape before `big`; these formatting defects were repaired. The frozen precontrol draft is preserved. A section reference N3 was clarified to N §3.
- A final statement search and source-byte refresh were run under the scoped read-only contract. Full results are retained.
