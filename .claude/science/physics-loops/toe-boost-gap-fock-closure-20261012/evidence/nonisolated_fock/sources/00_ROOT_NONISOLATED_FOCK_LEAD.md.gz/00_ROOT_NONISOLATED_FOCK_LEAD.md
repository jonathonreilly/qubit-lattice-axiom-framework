# Proposed Fock extension for time-averaged regular creators

Root research sketch, not an accepted proof or an independent check. The
359-line NONISOLATED_MASS_SCATTERING_PROBE.md at SHA
afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d
is frozen and under independent review. Any composition must keep that
provisional dependency explicit and respond to affected-source corrections.

Its comparison theorem permits arbitrarily small fixed averaging exponents
after existence is established at an integrable reference exponent. The
vacuum remains unique and gapped, so the earlier lattice Fock proof's
exponential clustering may close the missing contraction at small widths.
Do not import the continuum paper's massless estimate without a lattice proof.

For a finite pair of averaged creators choose 0<nu_i<kappa<1/3, perhaps
with a second exponent between the largest nu and kappa. Restrict all four
averaging times in the squared contraction to |t_i-sigma T|<=T^kappa;
the complementary Schwartz tails must absorb every polynomial packet norm.
Remove the common physical time sigma T. Then every remaining time is
O(T^kappa); actual finite-range LR and almost locality should approximate
each operator by a uniformly bounded observable supported in a ball of
radius R=C T^kappa, with rapid errors (choose C larger than LR speed times
the time-window constant). Check every LR volume factor and truncation order.

For those local observables the two commutators vanish unless
|x1-x2|, |x3-x4| <=2R. Exponential vacuum clustering between the two
commutator supports, capped by their uniform norm bound, should yield a
four-point covariance kernel whose sum over the three relative coordinates
is O(R^(3d)), possibly with explicit log or additional polynomial factors.
Do not assume that exponent: calculate it from the actual clustering
estimate in the complete existing Fock proof. If more powers occur, take
kappa correspondingly smaller; there remains room only after proving a
finite power and a uniform estimate.

For massive compact dispersions, uniform stationary phase gives
||f_t||_infty <= C T^(-d/2), ||f_t||_1 <= C T^(d/2) in the central time
windows. One l1 and three sup norms would then give a squared contraction
bound O(R^(3d) T^(-d)), plus rapid errors. Its square root tends to zero
for kappa<1/3. General smooth dispersions without a nondegenerate Hessian
need a separate statement and are not automatically included.

Because each full temporal transfer interval is strictly positive,
A_i(T)* Omega=0 exactly. The scalar contraction converges to
<psi_i,psi_j> by the established one-particle vacuum convergence. Thus the
candidate target is

    ||A_i(T)* A_j(T) Omega - <psi_i,psi_j> Omega|| ->0.

The averaged two-time double-commutator estimate needs its own proof via
the third packet's velocity partition and Jacobi, preserving all time
integrals. Combine it with the full finite-energy row/word bound in the
nonisolated source, not unrestricted polynomial norms, to derive the
permanent Gram recursion and cross-particle-number orthogonality. Transfer
the resulting inner products to all0<nu<1 only through the proved strong
limit comparison; do not pretend the contraction estimate itself is
uniform in nu or that raw unaveraged creators converge.

For an actual Fock space, keep a specified countable collection of orthogonal
stable graph sectors and a regular target space defined as the closure of
the admissible regular creator vectors. No density in an entire physical
mass sector follows just from cyclicity. Almost-local B with B*Omega=0
has summable geometric two-point coefficients. Its Q measure is absolutely
continuous; E1 commuting with Q makes the selected vector's measure
dominated by that one, even though E1B need not be almost local. This may
give absolute continuity on the closed regular target span. Check closure,
local cutoff invariance, multiplicity and chart overlaps carefully.

For massive charts the velocity map is injective with nonzero Jacobian, so
the equal-velocity diagonal is product-measure null. With density of regular
targets in the *defined* space and cutoff stability, separated finite tensors
may then be dense there. No duplicated chart species or arbitrary physical
one-particle density claim. Fock isometries would have closed selected ranges;
onto, ND, detector convergence, EX, boost covariance and model construction
remain distinct obligations. No existing theorem is yet extended by this sketch.
