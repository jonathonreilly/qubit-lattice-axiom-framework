# Independent review of nonisolated-mass scattering

**Verdict:** the conditional finite-product theorem N1–N31 and the beta=1
spectral counterexample N32–N35 are supported. One local definition repair is
required in the general-beta conversion paragraph, N36. No other required
mathematical correction was found. This is a source-bound review, not a retained
status decision, formal audit, Lean assertion or physical realization.

The frozen 359-line target is SHA256
`afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d`;
author receipt `2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6`.
Neither was edited. Root is a coauthor, not an independent reviewer.

**Required correction — lines 341–345.** Line 318 defines
\(\mathcal C=H^2-K^2\) in the beta=1 example. N36 then uses a general dispersion
\(\Sigma^2=M^2+\beta|K|^2\) without defining a corresponding weighted Casimir.
Under the general-beta reading, the literal sides differ by
\((\beta-1)|K|^2\): beta=2, M=K=1, H=2 gives left side 2 and right side 1.
Define \(\mathcal C_\beta:=H^2-\beta|K|^2\), use \(\mathcal C_\beta-M^2\)
in N36, and specify that variable in the regularity sentence. The exact reviewed
replacement is [N36_PUBLICATION_REPAIR.md](nonisolated_mass_review/N36_PUBLICATION_REPAIR.md),
with old/new byte bindings in the adjacent JSON. Its algebra and spectral
conversion were checked. This leaves the preceding theorem and beta=1 example
unchanged. Reading the old paragraph as restricted to beta=1 also avoids the
false identity, but does not state the intended general conversion.

| Claim group | Review finding |
|---|---|
| N1–N14: setting, regularity and filters | Premises are supplied explicitly. Closed zero-detuning regularity excludes unwanted graph-kernel atoms. Fourier signs give the stated vacuum multiplier; a separate convolution/transfer argument controls the full operator. The finite-range locality split and every norm time derivative are valid. |
| N15–N19: energy and spectators | The induction uses the common kernel of **all mixed lowering words**. The creator needs the output ceiling R+L. Uniform bounds on every finite-energy spectator word survive loss of exact vacuum graph support. |
| N20–N25: averages and derivatives | Vacuum convergence, both operator derivative formulas, both physical/packet-clock terms, and the width derivative are correct. Direct Cook integrability requires nu(1+a)>1. |
| N26–N31: locality and Cook | Independent averaging times, sublinear relative time, LR across linear spatial separation, both tails, and all n−2 commutator spectators are accounted for. All n−1 residual spectators use uniform energy bounds. Both time signs work. |
| Section 8: comparison | Actual amplitude refinement removes mixed-support conflicts while preserving regularity. Discarded/zero-target packets only tend to zero on the vacuum. Comparison with a regular reference width establishes every **fixed** 0<nu<1 without falsely asserting integrable derivatives for every width. |
| N32–N35: spectral nonimplication | Casimir detuning is comparable to 1/n; geometric detuning is exp(−n²). The infinite tail violates every positive power bound, and an on-mass centre selector retains it. This is a commuting spectral example, not a finite-range lattice countermodel. |
| N36: conversion | Supported after the explicit weighted-Casimir definition and consistent notation above. The whole-residual lift relation and matching kernel projection remain essential. |

The full [independent reconstruction](nonisolated_mass_review/INDEPENDENT_RECONSTRUCTION_PREAUTHOR.md)
was frozen at 03:29:17.490432 UTC before new author helper/output inspection.
Source text, receipt metadata and prior reviews were visible. All 673 original
Dybalski v4 TeX lines were read, with defining PDF equations checked visually;
the necessary BDN lattice arguments were read completely. Unchanged full
SC/Fock/centre readings were reused at exact identities, with all publication
diffs and F7–F9 checked. Relativistic locality, Fock and massless-vacuum conclusions
were not imported. The final N36 reread finding supersedes the frozen
reconstruction's preliminary assessment and is documented separately.

The distinct pre-author continuum control checked the derivative power and
slow-width convergence; a two-site control exposed equal-time replacement of
an unequal-time commutator. Its first run failed a quadrature gate. A separately
frozen refinement passed with unchanged cases/gates; both runs are retained.
The exact author helper reproduced byte-for-byte under a 60-second timeout.
Fourteen actual-source mutations rejected 11 defects. Two gates were
nondiscriminating: the energy-word check survived deleting both compensating
terms, and the finite Casimir check survived zero detuning. A benign weakened
padding inequality also survived. The analytic arguments supply what those
finite checks cannot; details and complete logs are in
[CONTROL_ASSESSMENT.md](nonisolated_mass_review/CONTROL_ASSESSMENT.md).

The note and all 103 author evidence bindings matched; source-specific checks
also verified the 27 reading records, 15 pinned instruction files and 39
preserved predecessor artifacts despite concurrent unrelated publication work.
The source inventory, exact correction, full logs, failed runs, mutation sources,
operational history, current checkpoint and final receipt are in
[nonisolated_mass_review](nonisolated_mass_review/).

The supported result does not supply regular-creator existence or density,
nonzero multiparticle norms, Fock/isometry, detector convergence, all-channel
coverage, a common q, ND, EX, boost covariance or a microscopic realization.
No author source, repository, Git reference, PR, audit, axiom or editable prompt
was changed. The completed centre review remains frozen.
