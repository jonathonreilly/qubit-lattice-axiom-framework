# Current checkpoint — nonisolated Fock independent review

Candidate SHA-256: 90471bd9b63f6a39356152a725e633a1d465272188ff1574bd198f71e97b85f5.
Author receipt SHA-256: 579ba4570a5459f6775811b5c6f236c2457a5427b576b4699547556b5b4d13ec.
Deadline: 2026-10-12 16:00:52 UTC, unchanged.

The complete candidate and necessary predecessor arguments have been read.
The independent pre-helper freeze, full reconstruction, exact matrix controls,
primary extracts and source-evidence verification are saved here. The proof
supports the conditional Fock isometry; no required source correction was found.
NONISOLATED_FOCK_REVIEW.md is complete with recommendation PASS WITH BOUNDED
CLAIMS. Read coverage and the final unchanged-source refresh are saved.

Failed routes/evidence limits: the initial exact symbolic matrix control hit
its 60-second limit after two complete records. Its source and partial output
remain intact. An exact rational-matrix backend completed the same cases/gates
in under one second. The original author runner reproduced byte for byte.
Thirteen actual-source mutations rejected nine algebraic/geometric defects;
four volume/exponent bookkeeping mutations survived. These controls do not
prove the analytic exponents. The independent Parseval/Cauchy–Schwarz argument
and complete tail/volume derivation supply that check.

Source state: all 72 author artifact bindings, all 25 original/snapshot source
bindings, 29 fresh primary page texts and both publication diff mappings match.
Current repository FIXES_AND_REPORTING.md differs from the installed copy;
the current repository version was read and applied. The parent-supplied main,
planning and worktree revision labels are recorded; no Git operation was run.

Open physical conditions: supplied finite-range dynamics, unique gapped vacuum,
massive reducing graphs and actual geometric regularity. No existence/density
of regular targets beyond their defined closure is proved. No detector, ND,
EX, onto, model, boost or massless-vacuum result is in scope.

Review work is complete. The receipt binds the final report, all review evidence
and the final source refresh. Root owns any publication and Git work; a change
to the target or necessary premises requires a scoped evidence refresh before
reusing this disposition. Only this evidence
directory and NONISOLATED_FOCK_REVIEW.md may be written. No editable prompt,
author source, repository science, Git/ref/index, PR, audit, axiom, primitive or
other chat was changed. No subdelegation or model/effort override.
