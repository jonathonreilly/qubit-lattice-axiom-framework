# Control assessment and preserved failures

The mathematical disposition rests on the complete source reconstruction.
Finite controls distinguish specific algebraic and bookkeeping defects; they
do not establish an infinite-volume scattering theorem or a microscopic model.

## Independent calculation and operational recovery

The pre-helper freeze selected a Parseval/Cauchy–Schwarz contraction route and
exact energy-graded matrix discriminators. The author's note-level test
descriptions and numbers were already visible. The reviewer used different
matrices, exact rational arithmetic, a 16-by-16 Gram tensor and distinct clock
weights; no author helper or result file was read before completion.

The analytic route gives a time-independent l2 norm for two of the four
packets, two `T^(-d/2)` sup bounds, and the independently counted
`O(R^(3d))` relative convolution volume. The full locality and four-tail
estimates are in `INDEPENDENT_RECONSTRUCTION.md`.

The first exact symbolic matrix implementation, SHA-256
`a3b9dde4f02dcaff5d79f00b343a5fdd2fde82f3db85f08555411dd0d5cab622`,
reached its declared 60-second timeout. Its two complete output records
verified the four-clock tensor identity and one dropped double-bracket
discriminator. This is a partial run, not a completed verification. Its
original source, stdout, empty stderr and execution metadata are preserved.

The recovery replaced symbolic complex expression trees by exact pairs of
rational matrices, preserving all matrices, dimension N=9, clock weights,
cases and gates. The pre-run recovery freeze records this sole implementation
change. The optimized source SHA-256 is
`dfb522d2017713aa210aabac4dee8c6e3b43b932c5ba3c633e6e2901babf20d2`.
It exited 0 in 0.97748 seconds under the same 60-second limit, with six
complete records and empty stderr. No parameter was fitted to an author
result and no case was removed after the timeout.

The four-clock quadratic form and direct norm squared are exactly
`20821909162831853/6015124728112500000`. The omitted-projection and tied-clock
calculations differ by nonzero exact rationals. All 256 ordered clock tuples
also match the commutator orientation individually. The full ordered recursion
holds as a matrix identity for n=1,...,6; each of the 35 double-bracket terms
over n=2,...,6 has a nonzero vacuum action in its corresponding test. Dropping
one fixed term at n=3 produces exact squared residual
`31785423651/25600000000`. The creator has vacuum norm squared
`14877/21560` while the unpadded vacuum lowering sum is zero. Forty mixed-row
cases check the stated factor counts and finite spectral inclusion. These
remain finite algebra/transfer tests, not asymptotic estimates.

## Exact author reproduction

The complete 319-line helper and seven-record stdout were read. Its source
SHA-256 is `367840a5726f4e7cecd16b35069fd06ca0643f660b7d254926293b2622053361`.
The exact recorded author command was run once with its original interpreter,
working directory and a 60-second timeout. It exited 0 in 0.25412 seconds;
stdout and empty stderr reproduced byte for byte. This is reproduction, not
an independent implementation.

The free-word expansion is a meaningful exact check of the ordered algebra.
The support enumeration tests the support-distance subtraction in its finite
one-dimensional domain. The exact shell sum includes its infinite residual
tail; it checks the chosen exponential-2 majorant. Both its primary and
comparison formulas take the support prefactor and pair count as inputs.
The matrix calculation meaningfully tests independent clocks, complex
conjugations, connected projection, Jacobi and energy padding. The width
table evaluates supplied rational formulas and checks sufficient positivity
or negativity inequalities. It does not derive those formulas from LR,
localization, or the Schwartz tail.

## Actual-source mutations

Each variant is an exact copy of the frozen author source with only the
recorded replacement. No author file was edited. Each had a declared
60-second limit; every command, source, full stdout, full stderr and execution
receipt is preserved under `mutations/`. No variant timed out or failed at
syntax/import setup. Nine failed at the intended mathematical assertions:

| Mutation | Result |
|---|---|
| Wrong commutator sign | Free-word identity assertion failed |
| All double brackets removed | Free-word identity assertion failed |
| A right spectator omitted | Free-word identity assertion failed |
| Support subtraction changed from 6R to 2R | Enumerated distance assertion failed |
| Connected projection omitted from four-point sum | Four-clock/direct-norm equality failed |
| A complex kernel conjugation omitted | Four-clock/direct-norm equality failed |
| One bra/ket clock tied | Four-clock/direct-norm equality failed |
| Wrong Jacobi sign | Triple/direct equality failed |
| Creator output ceiling unpadded | Finite-energy bound failed on the vacuum |

Four incorrect bookkeeping replacements survived all seven output records:

| Surviving mutation | What the gate does not independently test |
|---|---|
| `(R+1)^d` replaced by constant 2 in both majorant implementations | The support-cardinality prefactor is a shared supplied input |
| `(4R+1)^(2d)` replaced by `(4R+1)^d` | The number of the two confined relative coordinates is not separately enumerated in general d |
| `d(1-3 kappa)` replaced by `d(1-2 kappa)` | The table's positive decay test does not derive the contraction power |
| `kappa-small` replaced by `kappa+small` | Computing a tail order from the same erroneous margin preserves its self-consistency inequalities |

These survivors prevent treating the finite runner as validation of the
analytic volume/exponent derivation. They are not counterexamples to that
derivation. The actual source uses the correct prefactor, two relative
counts, exponent and tail margin; those were independently checked in the
written reconstruction. The candidate already separates its analytic proof
from finite bookkeeping. No mathematical source repair is required by these
control limits. A future runner claiming to certify those formulas would
need independent discriminating gates.

## Reading and identity limits

The candidate, necessary original upstream arguments, matching reviews and
both complete publication diffs were read. All 673 Dybalski TeX lines were
read. Fresh BDN pages 7–24 and 39–43 and NS pages 3–4 and 9–12 were read;
NS page 10 and BDN page 41 were also inspected as rendered images. Unread
primary pages and unrelated predecessor controls are not certified.

All 72 receipt artifact bindings and all 25 original/snapshot source pairs
matched. The freshly extracted 29 page texts match the author's after outer
whitespace normalization. Both saved publication mappings match independently
generated complete diffs. These checks establish provenance, not correctness
or that every historical author read actually occurred. The unused archival
precontrol proof and root lead were hash-checked but not read as proof inputs.

No formal audit, Lean check, full repository pipeline or landing operation was
run. Those operations were outside the bounded reviewer contract.
