# Source-bound independent reconstruction

Target: `NONISOLATED_FOCK_PROBE.md`, SHA-256
`90471bd9b63f6a39356152a725e633a1d465272188ff1574bd198f71e97b85f5`.
The pre-helper plan is `PRE_HELPER_FREEZE.md`, frozen at
2026-10-12T04:57:59.402028 UTC. The complete candidate, including its finite
control descriptions, was visible before that freeze. No author helper source
or raw results were inspected until the independent controls completed.
The root lead was not read. Root is a coauthor, not an independent checker.

## Exact target and inherited inputs

The statement is an implication from NF1–NF6 to the permanent Gram formula
and isometric embeddings of the bosonic Fock space over the *actual closed
span of regular targets*. It allows that space to be zero. A finite family is
internally separated in packet velocity, with no separation between its left
and right counterparts. Every width is fixed before the large-time limit.

The full 359-line N source at
`afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d`
and its matching review were read. N15–N19 depend on the common kernel of all
ordered lowering words. In the Q-squared identity, Cauchy–Schwarz bounds the
second sum by `b_(r-1) <Q>`, because each first lowering maps that common
kernel into the previous one. Positivity gives `<Q>² <= <Q²>`. The increasing
compressed sums therefore satisfy `Gamma_B(R) <= floor(R/epsilon) S_B`.
This does not require exact vacuum graph support. Duality for a creator needs
the output ceiling `R+L`; the unpadded bound already fails on the vacuum.

All fixed mixed words have bounded finite-energy norms by inserting an energy
ceiling at every step. The negative transfer of each adjoint never raises the
ceiling. Averaging multiplies the single-factor bound by `||h||_1` and does
not alter its temporal-transfer interval. No exponentially weighted integral
of a Schwartz kernel is used.

N20–N31 give vacuum convergence and an integrable reference product
derivative for `nu(1+a)>1`. N section 8 compares actual packet amplitudes with
refined amplitudes, commutes their zero-target difference to the vacuum and
uses the uniform finite-energy bound. Thus it establishes the same strong
product limit at any fixed `0<nu<1`, even when that width's derivative bound
is nonintegrable. The present use only changes widths on each packet's
original graph. Cross-chart well-definedness is derived later from Gram
preservation; it is not assumed in this comparison.

The supplied unique gapped vacuum, finite-range dynamics, reducing graph
projections and regularity are not supplied by the framework's three registered
primitives. No new primitive or physical realization is inferred. N36's old
general-beta Casimir notation has the previously documented repair, bound by
`22d272711226acccb48f0c2e167bd47bc5296d4142c7e60ac537c0ae6f74a453`.
Neither version of N36 is used here: NF4 directly imposes geometric detuning
regularity. The beta=1 spectral nonimplication remains intact.

## Four clocks, localization and an independent convolution route

Let the four physical times be `sigma T + u_j`. On their four separate central
windows, `|u_j| <= U = T^kappa`, vacuum invariance and commutation of the
vacuum projection with H remove just the common `alpha_(sigma T)`. The four
remaining observables are `alpha_(u_j)(B_j)`, and their locality constants
cannot be treated as fixed without a further estimate.

For `r0=ceil(U)` and `R=ceil((v_LR+4)U)`, one has
`R-r0-v_LR |u| >= 3U-1 >= 2U` when `U>=1`. Conditional expectation is
contractive. Applying the LR local approximation to the `r0` input ball
therefore gives

`||alpha_u(B)-E_R alpha_u(B)|| <= 2||B-E_r0 B|| + C V(r0)||B|| exp(-2 lambda U)`.

The volume `V(r0)=O(U^d)` is present, and is absorbed only by the exponential.
Almost-locality supplies an arbitrary inverse power of U. Max-norm balls are
legitimate: their complement is at least `R-r0` away in graph distance; a
graph-distance neighborhood lies inside the chosen max-norm ball. Any extra
conditional-expectation contraction factor is absorbed in the fixed C.

For localized radius-R observables, the two commutators vanish unless
`|a|,|c| <= 2R`. Their support unions lie in radius-3R balls about x2 and x3;
therefore their support distance is at least `|b|-6R`. Each union contains at
most `2 V(R)` sites. The connected expectation equals a covariance. The
rank-one vacuum ensures both centered-observable ground-projection conditions
in NS Theorem 4.1. At imaginary time zero it yields the stated support-volume
clustering bound. Taking its minimum with the elementary commutator norm cap
gives the near/far bound used in NF17.

Here is the dimension-independent relative sum without a numerical fit. The
max-norm shell at integer radius r has

`s_d(r) = (2r+1)^d - (2r-1)^d <= 2d (2r+1)^(d-1)`.

For integer R at least one, the near b ball has `(14R+1)^d` sites. The far sum
is bounded by

`C (1+R)^d exp(-mu R) sum_(ell>=1) (1+7R+ell)^(d-1) exp(-mu ell)`

`<= C_(d,mu) (1+R)^(2d-1) exp(-mu R) <= C'_(d,mu) (1+R)^d`.

The last inequality follows from boundedness of
`(1+R)^(d-1) exp(-mu R)` for R at least one. Each of a and c contributes
`(4R+1)^d`, so all three relative sums cost `O((1+R)^(3d))`. There is no lost
support factor or logarithmic divergence. The 7R split bounds the transition
region directly.

The frozen independent route uses **two exact Parseval norms**, rather than
the author's one-l1/three-sup argument. For each fixed a,b,c, Cauchy–Schwarz
and arbitrary independent times give

`sum_x |f1(x+a) f2(x) f3(x+b) f4(x+b+c)|`

`<= ||f1||_infinity ||f3||_infinity ||f2||_2 ||f4||_2`.

Parseval makes the last two norms independent of their times. Positive
massive Hessians on compact supports give the first two factors `O(T^(-d/2))`
each, at both time signs. Thus the convolution is `O(T^(-d))`, and the
localized connected four-point sum is `O(T^(-d+3d*kappa))`. This is an analytic
independent check of the disputed power; it uses no control-generated target.

The localization remainder cannot use this kernel sum, because it is not
localized. Its uniform `O(U^(-N))` norm error is multiplied by four packet l1
norms, giving `O(T^(2d-kappa N))`. Each central averaging measure has total
variation at most `||h_j||_1`, so no width-volume factor enters.

For the jth time tail, set `t=sigma T+T^nu_j z`. Since `T^nu_j<=T`,
`1+|t| <= 2T(1+|z|)`. A Schwartz polynomial-moment estimate yields
`G_j <= C T^(d/2)` and
`G_j^tail <= C_N T^(d/2-(kappa-nu_j)N)`. The complement of four central
windows is the union of the four individual tails. The original kernel has a
uniform norm cap even there; hence all tail combinations together are at most
`C_N T^(2d-delta N)`, where `delta=min_j(kappa-nu_j)>0`.

Before sums and integrals are interchanged, finite-T absolute integrability
follows from the product of the four G_j bounds. The exact norm-square
identity is NF24, with conjugation on the adjoint kernels. The sum of the
three estimates gives NF25. Choosing `max nu_j < kappa < 1/3` makes its first
power decay. The scalar part is initially the inner product of the two
*actual averaged vacuum vectors*, not the prescribed targets. NF9 converts
it to the target inner product with both residual rates. This proves NF26.

## Double commutators and the complete Gram recursion

Split the arbitrary third amplitude with a smooth function of its own
velocity map. One piece is separated from X, the other from Y. Compact
collars give positive separation, including for adjoints, whose absolute
spatial packet weights have the same velocity localization.

For each separated pair retain the two independent clocks, restrict them to
a window `T^mu` with `max nu < mu < 1`, and remove the common evolution.
Linear spatial separation dominates the sublinear relative time in the LR
bound. Spatial nonstationary-phase tails and both Schwartz time tails have
arbitrary power decay. The extra third factor costs only `T^(d/2)`, or the
triple-tail bound costs `T^(3d/2)` before arbitrary decay. The exact Jacobi
identity has the minus sign in NF29. This proves NF30 for all fixed widths
below one, independently of the small-width contraction choice.

For NF31, first use the ordered Leibniz expansion of a through A1...An.
Moving each resulting bracket to the right creates exactly one double
bracket for each pair `k<ell`, with the factors ordered as written. The
terminal `A1...An a Omega` vanishes. A double-bracket term has n-2 right
spectators; the scalar product contributes m-1 further left spectators.
Arbitrary rapid decay beats their total polynomial norm power
`d(m+n-3)/2` for each fixed pair of families.

The slow contraction remainder must instead be tested against the full row
vector `(product_(j!=k) A_j)^* tilde_A2...tilde_Am Omega`. It has all
`m+n-2` remaining factors. Spectral transfer bounds every intermediate energy
by the finite sum of the upper transfer endpoints. N19 therefore bounds the
norm of this representing vector uniformly. This is a bound on the row as a
functional on the entire Hilbert space; no missing spectral projection on
the contraction error is assumed.

The recursion follows with an o(1) error. If either family is empty and the
other is not, the scalar product is exactly zero by the first creator's
adjoint annihilating Omega. Empty–empty is one. Induction yields the full
permanent for equal lengths and zero for unequal lengths, with creation-
operator normalization and no extra factorial. The previously checked N
comparison restores every original fixed width at the level of strong
product limits, not by falsely extending the small-width error estimate.

## Regular-space closure, overlap consistency and density

A smooth torus multiplier q preserves the same creator, seed, original graph
and compact support, while multiplying both target and residual by q(Q).
Commutation of q(Q), E_s and D gives NF34. The closed regular span is invariant
under q(Q) and its adjoint. Uniform density in continuous torus functions,
followed by the bounded spectral calculus, makes it reducing for Q. Smooth
cutoffs increasing pointwise to an open-set indicator consequently give local
density *within this defined span*. Cyclicity is not used to supply arbitrary
regular seeds.

For the unprojected B Omega, the Q Fourier coefficients equal the vacuum
expectation of `[B*,tau_x B]`, since B* Omega is zero. Almost-locality makes
the coefficients rapidly decreasing, so Fourier uniqueness gives a smooth
Haar density. The spectral measure of the selected target is dominated by
that of B Omega times the bounded amplitude multiplier. Null projections
therefore kill every regular target and their closed span. Neither smoothness
of the selected density nor almost-locality of E_s B is claimed or needed.

Within a sector, two chart graph equalities imply that the common Q measure
is supported on equality of the two graph functions. In a common lift the
difference of their squares is affine. If it is not identically zero, its
zero set is empty or a hyperplane; the just-proved absolute continuity kills
that overlap on the regular subspace. Otherwise positive square roots and
their gradients agree. Countability of the charts and overlap components
makes the glued velocity spectral operator well-defined. Distinct species
are already orthogonal actual subspaces, not copies introduced by charts.

The positive massive velocity map has the stated explicit inverse and
nonzero Jacobian. In any pair of charts and for any fixed second momentum,
the first has at most one point with the same velocity. Fubini makes the
pair diagonal null. Product scalar spectral measures of elementary tensors
are absolutely continuous. By density, the corresponding diagonal projection
is zero on the entire tensor Hilbert space. Finite pair unions and countable
species/chart unions do not change this.

Every distinct-velocity tuple has a product of relatively compact chart
neighborhoods with disjoint closed velocity images. The corresponding product
spectral ranges span a dense subspace. In each factor range, approximate by
regular targets and then apply the supported smooth cutoffs. The resulting
compact supports lie in intersections of original and assigned charts. A
finite partition subordinate to their open overlap components exists by
compactness. On an incompatible component the target is exactly zero; on a
compatible one the original and assigned graph velocities agree. Thus actual
packet supports, not only vector labels, are separated. Algebraic tensor
density and continuous symmetrization prove the asserted dense Fock domain.

Finally the complete cross-family Gram formula preserves the squared norm of
every finite linear combination of admissible separated Fock vectors, even
with different chart/seed presentations and particle numbers. It defines a
well-defined linear isometry, extends uniquely from the dense domain, and has
closed range. It does not prove raw nonseparated packet convergence, regular
seed existence/density in a whole physical mass sector, onto, detector, ND,
EX, boost covariance, equality of incoming/outgoing ranges, an isometric
S-matrix, a massless-vacuum theorem or a microscopic model.

## Evidence limits

All relevant arguments were checked against the complete original Dybalski
v4 TeX and the exact BDN/NS passages recorded in `READING_COVERAGE.json`.
The relativistic massless contraction bound was not imported. The BDN
geometric shell-isolation condition and whole-shell density conclusion were
not imported. Their stronger S-matrix wording was not used.

The independently written exact matrix control tests a four-clock Gram tensor,
all ordered matrix recursion terms for n=1,...,6, a nonzero omitted double
bracket, energy padding and 40 finite row-support cases. Its first symbolic
implementation timed out; the exact paired-rational implementation completed
with the same matrices, cases and gates. It is finite algebraic evidence only.
The analytic estimates, spectral statements and Hilbert-space closure remain
the written proof checked above. No Lean verification or formal audit was run.
