# Review operations

- Started at 2026-10-12 04:56:23 UTC with the parent's fixed deadline of
  2026-10-12 16:00:52 UTC. No extension requested or used.
- Read current worktree AGENTS.md, CLAUDE.md, SCIENCE_WORKFLOW.md, freshness,
  reviewer/workhorse/review-loop instructions and the applicable proof,
  science-lens, reporting and premise references. The current repository
  FIXES_AND_REPORTING.md differs from the installed distribution; the current
  source was applied. Supplied Git revision labels were recorded; no Git or
  network-ref command was run under the explicit source-only contract.
- Two display truncations occurred: an aggregated predecessor-review read and
  a combined publication-diff read. Both affected complete files were reread
  in smaller complete calls. Truncated displays were not counted as coverage.
- `pdftotext` was absent from the ordinary PATH. Pypdf was available and made
  fresh page extracts. Bundled Poppler rendered the two formula pages under
  declared 45-second limits; both commands exited 0 with empty streams.
- The distinct review calculation was frozen before new author helper/raw
  result inspection. Note-level control descriptions were visible. Root's
  lead was not read. No claim of blind route discovery or different-model
  independence is made.
- The first exact matrix implementation timed out at 60 seconds with two
  complete partial records. Its source and streams are preserved. A frozen
  exact-arithmetic backend optimization retained the same cases and gates;
  the second run exited 0. Neither the timeout nor the completion establishes
  infinite-volume asymptotics.
- The exact author helper completed one reproduction run under a 60-second
  limit, with byte-identical stdout and empty stderr. Thirteen source-copy
  mutations preserved nine intended assertion failures and four survivors.
  The mutation orchestrator itself exited 0; no scientific failure was hidden.
- All edits are confined to NONISOLATED_FOCK_REVIEW.md and
  nonisolated_fock_review/. No author source, repository science, Git/ref/index,
  PR, audit, axiom, primitive, editable prompt or other chat was modified.
- No subagent was launched and no model/reasoning setting was overridden.
- During final reporting, one read used an incorrect short skill path and
  returned "No such file or directory"; the previously read current reference
  was located from its identity manifest and read successfully. A checkpoint
  patch initially missed its exact context and made no change; its corrected
  patch applied. Neither operational error affected a source or scientific run.
