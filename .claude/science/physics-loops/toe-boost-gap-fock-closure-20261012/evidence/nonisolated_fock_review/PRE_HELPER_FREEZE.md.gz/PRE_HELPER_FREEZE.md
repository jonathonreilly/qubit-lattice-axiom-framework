# Independent pre-helper reconstruction and decisive calculation freeze

UTC: 2026-10-12. Reviewer received a fresh bounded task; no author helper, receipt, source manifest, control source, or raw result file has been opened. The complete candidate note, including its control descriptions and displayed numeric results, has been read. This exposure is disclosed; it rules out calling those numbers held out. Root's lead and root-authored calculations have not been read. No model/effort substitution or subdelegation.

Source under review: NONISOLATED_FOCK_PROBE.md SHA-256 90471bd9b63f6a39356152a725e633a1d465272188ff1574bd198f71e97b85f5. Receipt metadata (size/hash only) was computed: 579ba4570a5459f6775811b5c6f236c2457a5427b576b4699547556b5b4d13ec. No receipt content yet inspected.

## Reconstructed obligation graph

1. Inherited N theorem gives actual strong product limits, comparison for fixed widths on the original graph, exact vacuum annihilation, and uniform creator/annihilator bounds on every finite energy interval. These dependencies are hypotheses to verify against the full source, not accepted by label.
2. Independently averaged A_i^* A_j vacuum contraction is the connected two-commutator four-point function. Four separate clocks are needed. Vacuum invariance removes one common center time while leaving four relative evolutions. Localize these to radius R proportional to T^kappa after restricting every clock to its own central window.
3. Two local commutators force relative offsets a and c to be O(R). Centered clustering controls the remaining relative offset b; the norm cap handles |b|=O(R). The triple relative sum is O(R^(3d)). Locality error costs four l1 packet norms and every clock tail must be retained.
4. Double commutators follow by velocity splitting plus Jacobi and full two-time rapid commutators; no simultaneous-clock shortcut.
5. Exact ordered Leibniz recursion has double-commutator errors, controlled against polynomial spectators. The contraction error is paired with a uniformly bounded entire-Hilbert-space row vector, using ALL remaining creator and annihilator factors and spectral transfer ceilings.
6. Gram identity, cross-number zero, amplitude cutoff closure, geometric spectral AC, overlap consistency and velocity-diagonal nullity yield an isometry on the defined regular closure. They do not yield whole-sector density, onto, detector, ND, EX, or a microscopic model.

## Distinct frozen decisive check

Use Parseval plus Cauchy-Schwarz for the packet convolution, instead of the author's one-l1/three-linfinity route. For arbitrary a,b,c and four independent times t_i with |t_i| comparable to T:

sum_x |f_1(x+a) f_2(x) f_3(x+b) f_4(x+b+c)|
 <= ||f_1||_infinity ||f_3||_infinity ||f_2||_2 ||f_4||_2
 <= C T^(-d).

The last two norms are EXACTLY time-independent by Parseval; no relation among t_i enters. Sum the independently derived capped clustering majorant over a,b,c to recover T^(-d) R^(3d). Derive the shell bound for arbitrary dimension, keeping the support-cardinality prefactor in the far tail. Separately test the contraction and full Gram spectator recursion using exact noncommuting nilpotent weighted-shift matrices built independently from an energy grading, with distinct complex quadrature weights per clock; use direct Kronecker/tensor contraction or polynomial coefficient extraction rather than the author's result or code. Predeclared discriminators: wrongly tying at least one clock; omitting P_perp; removing one specific double-commutator term; using finite-energy creator bound with unpadded R. Numeric values are not acceptance targets: equality or failure is computed from independently constructed objects.

The analytic part is decisive for the asymptotic volume/exponent claim. A finite matrix control is only an algebra/domain discriminator, not proof of scattering or a model satisfying the nonisolated massive graph premises. If an inherited estimate fails or a matrix check does not discriminate, preserve that failure and narrow the finding. Check the complete proof against upstream sources before any final disposition.
