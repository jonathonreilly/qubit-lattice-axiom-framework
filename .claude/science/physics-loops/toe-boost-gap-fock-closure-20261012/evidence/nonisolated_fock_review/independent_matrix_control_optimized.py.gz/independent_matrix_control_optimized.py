"""Independent exact matrix discriminators, frozen before author helper reads.

The matrices have a positive energy grading. They test finite algebra and
transfer bookkeeping, not the infinite lattice hypotheses or asymptotics.
"""
from itertools import product
import json
import sympy as s

I=s.I
class GM:
    _op_priority = 10000.0
    def __init__(self, real, imag=None):
        if imag is None:
            self.r = real.applyfunc(lambda z: s.expand_complex(z).as_real_imag()[0])
            self.i = real.applyfunc(lambda z: s.expand_complex(z).as_real_imag()[1])
        else:
            self.r, self.i = real, imag
    def __add__(self, other):
        if other == 0: return self
        return GM(self.r + other.r, self.i + other.i)
    __radd__ = __add__
    def __sub__(self, other):
        return GM(self.r - other.r, self.i - other.i)
    def __mul__(self, other):
        if isinstance(other, GM):
            return GM(self.r*other.r - self.i*other.i, self.r*other.i + self.i*other.r)
        a,b=s.expand_complex(other).as_real_imag()
        return GM(self.r*a - self.i*b, self.r*b + self.i*a)
    __rmul__ = __mul__
    def conjugate(self): return GM(self.r, -self.i)
    @property
    def T(self): return GM(self.r.T, self.i.T)
    def __getitem__(self, key):
        a,b=self.r[key],self.i[key]
        if isinstance(a,s.MatrixBase): return GM(a,b)
        return a+s.I*b
    def __setitem__(self, key, value):
        a,b=s.expand_complex(value).as_real_imag()
        self.r[key],self.i[key]=a,b
    def __eq__(self,other):
        return isinstance(other,GM) and self.r==other.r and self.i==other.i
    @staticmethod
    def hstack(*args):
        return GM(s.Matrix.hstack(*[x.r for x in args]),s.Matrix.hstack(*[x.i for x in args]))

def clean(x):
    return x if isinstance(x,GM) else s.simplify(x)

N=9
zero=GM(s.zeros(N))
eye=GM(s.eye(N))
vac=GM(s.eye(N)[:,0])
perp=eye-vac*vac.conjugate().T

def record(name, **fields):
    print(json.dumps({'name':name,**fields},sort_keys=True),flush=True)

def scalar(x):
    return clean(x[0] if isinstance(x,(s.MatrixBase,GM)) else x)

def norm2(v):
    return scalar(v.conjugate().T*v)

def creator(j):
    out=GM(s.zeros(N))
    for e in range(N):
        for jump in (1,2,3):
            if e+jump<N:
                out[e+jump,e]=s.Rational(((j+2)*(e+1)+jump*j)%7-3,4) + I*s.Rational((j+e+jump)%3-1,5)
    return out

def prod(items):
    result=GM(s.eye(N))
    for item in items:
        result=result*item
    return result

def comm(a,b):
    return a*b-b*a

def clock_packet(b,phase,dispersion):
    u=GM(s.diag(*[phase**e for e in range(N)]))
    return clean(phase**(-dispersion)*(u*b*u.conjugate().T))

phases=[s.Integer(1),I,s.Integer(-1),-I]
weights_a=[s.Rational(1,2)+I/7,s.Rational(1,4)-I/5,s.Rational(1,6)+I/11,s.Rational(1,12)-I/7+I/5-I/11]
weights_b=[s.Rational(1,3)-I/13,s.Rational(1,5)+I/7,s.Rational(1,7)-I/11,s.Rational(34,105)+I/13-I/7+I/11]
assert sum(weights_a)==1 and sum(weights_b)==1
aa=[clock_packet(creator(2),z,1) for z in phases]
bb=[clock_packet(creator(5),z,2) for z in phases]
abar=clean(sum((w*a for w,a in zip(weights_a,aa)),zero))
bbar=clean(sum((w*b for w,b in zip(weights_b,bb)),zero))
assert abar.conjugate().T*vac==GM(s.zeros(N,1))

# Independent double-index vectors and their 16-by-16 Gram matrix: its
# quadratic form is a four-clock tensor contraction, with all interference.
indices=list(product(range(4),repeat=2))
vectors=[perp*comm(aa[a].conjugate().T,bb[b])*vac for a,b in indices]
columns=GM.hstack(*vectors)
gram=columns.conjugate().T*columns
coeff=GM(s.Matrix([s.conjugate(weights_a[a])*weights_b[b] for a,b in indices]))
tensor_value=scalar(coeff.conjugate().T*gram*coeff)
direct_value=norm2(perp*abar.conjugate().T*bbar*vac)
assert clean(tensor_value-direct_value)==0

# Also check the kernel orientation directly at all 4^4 time tuples.
max_kernel_error=0
for i,j,k,l in product(range(4),repeat=4):
    direct=scalar(vac.conjugate().T*comm(bb[i].conjugate().T,aa[j])*perp*comm(aa[k].conjugate().T,bb[l])*vac)
    from_gram=gram[indices.index((j,i)),indices.index((k,l))]
    assert clean(direct-from_gram)==0

conditional=[sum((weights_b[b]*vectors[indices.index((a,b))] for b in range(4)),GM(s.zeros(N,1))) for a in range(4)]
tied_a=scalar(sum(s.conjugate(weights_a[a])*weights_a[a]*norm2(conditional[a]) for a in range(4)))
common_clock=norm2(sum((s.conjugate(weights_a[a])*weights_b[a]*vectors[indices.index((a,a))] for a in range(4)),GM(s.zeros(N,1))))
without_perp=norm2(abar.conjugate().T*bbar*vac)
assert tensor_value != tied_a and tensor_value != common_clock
assert without_perp != tensor_value
record('four_clocks_exact',tensor_value=str(tensor_value),direct_value=str(direct_value),clock_tie_residual=str(clean(tied_a-tensor_value)),common_clock_residual=str(clean(common_clock-tensor_value)),projection_omission_residual=str(clean(without_perp-tensor_value)),kernel_tuples=256,limits='Finite exact energy-graded matrix identity only.')

# Ordered recursion from its explicit product expansion; matrices do not
# commute. Test complete equality on all vectors and separately on vacuum.
a=creator(8).conjugate().T
right=[creator(j) for j in range(1,7)]
rows=[]
for n in range(1,7):
    xs=right[:n]
    terminal=prod(xs)*a
    main=sum((prod([xs[j] for j in range(n) if j!=k])*comm(a,xs[k]) for k in range(n)),zero)
    terms=[]
    for k in range(n):
        for ell in range(k+1,n):
            left=prod([xs[j] for j in range(ell) if j!=k])
            tail=prod(xs[ell+1:])
            terms.append((k,ell,left*comm(comm(a,xs[k]),xs[ell])*tail))
    doubles=sum((v for k,ell,v in terms),zero)
    residual=clean(a*prod(xs)-terminal-main-doubles)
    assert residual==zero
    assert terminal*vac==GM(s.zeros(N,1))
    teeth=[(k,ell,norm2(v*vac)) for k,ell,v in terms if v*vac!=GM(s.zeros(N,1))]
    rows.append({'n':n,'matrix_identity':True,'vacuum_identity':True,'number_of_double_terms':len(terms),'individually_detectable_on_vacuum':len(teeth)})
    if n==3:
        assert teeth
        k,ell,val=teeth[0]
        assert val>0
        record('dropped_specific_double_commutator',n=n,k=k,ell=ell,exact_vacuum_norm_squared=str(val),detected=True)
record('full_ordered_recursion',cases=rows,limits='Exact finite noncommutative identities; analytic spectator bounds proved separately.')

# Positive spectral transfer and the creator-padding failure at the vacuum.
p0=vac*vac.conjugate().T
energies=list(range(N))
nonzero_jumps=set()
for j in range(N):
    for k in range(N):
        if abar[j,k]!=0:
            nonzero_jumps.add(j-k)
assert nonzero_jumps.issubset({1,2,3})
assert abar.conjugate().T*p0==zero
vacuum_norm=norm2(abar*vac)
assert vacuum_norm>0
record('positive_transfer_padding',observed_energy_increases=sorted(nonzero_jumps),annihilator_on_vacuum_zero=True,creator_vacuum_norm_squared=str(vacuum_norm),unpadded_gamma_at_zero=0,unpadded_bound_rejected=True)

# Count ALL remaining factors in the row and verify spectral support by
# exact matrix projection. A selected finite case is only a discriminator.
xt=[creator(10+j) for j in range(4)]
ceiling_cases=[]
for m in range(1,5):
    for n in range(1,5):
        for deleted in range(n):
            factors=[right[j] for j in range(n) if j!=deleted]
            rowvec=prod(factors).conjugate().T*prod(xt[1:m])*vac
            ceiling=3*(m+n-2)
            p=GM(s.diag(*[int(e<=ceiling) for e in energies]))
            assert p*rowvec==rowvec
            ceiling_cases.append((m,n,deleted,m+n-2))
record('all_spectator_row',cases=len(ceiling_cases),all_factor_counts_checked=True,limits='Finite transfer inclusion only, no T-uniform asymptotic inference.')

record('completed',checks='all exact equalities and the predeclared clock/projection/bracket/padding discriminators satisfied')
