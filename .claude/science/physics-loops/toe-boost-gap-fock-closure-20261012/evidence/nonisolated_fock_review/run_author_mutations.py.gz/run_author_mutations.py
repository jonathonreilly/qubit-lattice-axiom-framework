"""Actual-source mutation checks of the finite author's gates.

All variants are copies in the reviewer directory; the author source stays frozen.
Preserve survivors as well as rejected defects. A survivor diagnoses that gate's
coverage, not the truth or falsity of the independently reviewed analytic proof.
"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

ROOT=Path(__file__).resolve().parent
AUTHOR=ROOT.parent/'nonisolated_fock/check_fock_extension.py'
EXE='/Users/jonreilly/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
original=AUTHOR.read_text()
assert hashlib.sha256(original.encode()).hexdigest()=='367840a5726f4e7cecd16b35069fd06ca0643f660b7d254926293b2622053361'
cases=[
 ('bracket_sign','return add(mul(a, b), scale(mul(b, a), -1))','return add(mul(a, b), scale(mul(b, a), +1))',1),
 ('omit_double_terms','rhs = add(terminal, *singles, *doubles)','rhs = add(terminal, *singles)',1),
 ('omit_right_spectator','*xs[ell + 1:]))','*xs[ell + 2:]))',1),
 ('wrong_support_distance','assert distance >= max(0, abs(b) - 6 * radius)','assert distance >= max(0, abs(b) - 2 * radius)',1),
 ('drop_volume_growth','amplitude = (radius + 1) ** d','amplitude = 2',2),
 ('drop_one_relative_count','pair_counts = (4 * radius + 1) ** (2 * d)','pair_counts = (4 * radius + 1) ** d',1),
 ('omit_connected_projection','left @ perpendicular @ right @ omega','left @ right @ omega',1),
 ('wrong_conjugate_weight','weights[1][j].conjugate() * weights[0][k].conjugate()','weights[1][j] * weights[0][k].conjugate()',1),
 ('tie_one_clock','right = comm(dagger(arrays[0][k]), arrays[1][ell])','right = comm(dagger(arrays[0][i]), arrays[1][ell])',1),
 ('wrong_jacobi_sign','jacobi = comm(dagger(a), comm(b, y)) - comm(b, comm(dagger(a), y))','jacobi = comm(dagger(a), comm(b, y)) + comm(b, comm(dagger(a), y))',1),
 ('creator_no_padding','np.sqrt(gamma(cutoff + upper))','np.sqrt(gamma(cutoff))',1),
 ('incorrect_contraction_exponent','target_decay = d * (1 - 3 * kappa)','target_decay = d * (1 - 2 * kappa)',1),
 ('incorrect_tail_margin','delta = kappa - small','delta = kappa + small',1),
]
directory=ROOT/'mutations'
directory.mkdir(exist_ok=True)
rows=[]
for name,before,after,count in cases:
    assert original.count(before)==count,(name,original.count(before))
    source=original.replace(before,after)
    target=directory/f'{name}.py'
    target.write_text(source)
    cmd=[EXE,str(target)]
    start=time.monotonic()
    try:
        run=subprocess.run(cmd,cwd=directory,capture_output=True,timeout=60)
        stdout,stderr=run.stdout,run.stderr
        code=run.returncode
        timed_out=False
    except subprocess.TimeoutExpired as e:
        stdout,stderr=e.stdout or b'',e.stderr or b''
        code=None
        timed_out=True
    elapsed=time.monotonic()-start
    streams={}
    for label,data in [('stdout',stdout),('stderr',stderr)]:
        path=directory/f'{name}.{label}.txt'
        path.write_bytes(data)
        streams[label]={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    record={'name':name,'command':cmd,'timeout_seconds':60,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'before':before,'after':after,'replacements':count,'returncode':code,'timed_out':timed_out,'elapsed_seconds':elapsed,'streams':streams,'survived':code==0}
    (directory/f'{name}.execution.json').write_text(json.dumps(record,indent=2)+'\n')
    rows.append(record)
    print(json.dumps({'name':name,'returncode':code,'survived':code==0,'last_error_line':stderr.decode().splitlines()[-1] if stderr else ''}),flush=True)
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_source_sha256':hashlib.sha256(original.encode()).hexdigest(),'cases':rows}
(ROOT/'author_mutations.json').write_text(json.dumps(summary,indent=2)+'\n')
