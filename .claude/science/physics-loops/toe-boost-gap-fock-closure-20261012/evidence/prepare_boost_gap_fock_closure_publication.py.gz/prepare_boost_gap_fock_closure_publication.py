#!/usr/bin/env python3
"""Prepare five complete reviewed conditional notes in an explicit clean checkout.

Root must read this script and the frozen preparation plans before executing it.
Both --worktree and --base are required. This script creates only new files; it
never executes a scientific helper, cache, graph, vocabulary or audit command,
and never commits, pushes, fetches, stages or changes an existing evidence file.
The preparer has not imported or executed this script. Preview/source-map and
compile-only validation artifacts live in boost_gap_fock_closure_preparation/.
"""
from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


S = Path(__file__).resolve().parent
Q = S / "boost_gap_fock_closure_preparation"
PACKET = ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012"
PREPARATION_FREEZE_SHA256 = "9e484758a5f0b2713bb7fe436961e4a13825f65206de1626a3d488a81a628d6b"
EXPECTED_KEYS = {"Boost", "Gapped", "Nonisolated_fock", "Weighted_current", "Integrated_boost"}
ALLOWED_EDIT_CATEGORIES = {
    "claim_metadata", "review_status", "portable_provenance", "historical_status",
    "runner_declarations", "canonical_cli", "suppress_output_side_effect", "scoped_output",
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def read_exact(path, expected=None, size=None):
    need(path.is_file() and not path.is_symlink(), "Missing or nonregular source: " + str(path))
    data = path.read_bytes()
    if expected is not None:
        need(sha(data) == expected, "Source identity mismatch: " + str(path))
    if size is not None:
        need(len(data) == size, "Source size mismatch: " + str(path))
    return data


def safe_relative(relative):
    path = Path(relative)
    need(not path.is_absolute() and ".." not in path.parts and relative not in {"", "."}, "Unsafe relative path: " + relative)
    return path


def source_members(folder):
    result = []
    need(folder.is_dir() and not folder.is_symlink(), "Absent or symlink source directory: " + str(folder))
    for path in sorted(folder.rglob("*")):
        need(not path.is_symlink(), "Symlink in frozen source directory: " + str(path))
        if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
            result.append(str(path.relative_to(S)))
    return result


def root_members(pattern):
    result = []
    for root in sorted(S.glob(pattern)):
        need(not root.is_symlink(), "Symlink in root evidence")
        candidates = [root] if root.is_file() else list(root.rglob("*"))
        for path in candidates:
            need(not path.is_symlink(), "Symlink in root evidence")
            if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
                result.append(str(path.relative_to(S)))
    return sorted(result)


def preparation_inputs():
    freeze_bytes = read_exact(Q / "PREPARATION_FREEZE.json", PREPARATION_FREEZE_SHA256)
    freeze = json.loads(freeze_bytes)
    files = {}
    for row in freeze["files"]:
        relative = row["path"]
        safe_relative(relative)
        need(relative not in files and relative != "PREPARATION_FREEZE.json", "Duplicate/self-referential preparation input")
        files[relative] = read_exact(Q / relative, row["sha256"], row["bytes"])
    actual = sorted(str(p.relative_to(Q)) for p in Q.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.name != ".DS_Store" and p.name != "PREPARATION_FREEZE.json")
    need(actual == sorted(files), "Preparation input membership changed")
    files["PREPARATION_FREEZE.json"] = freeze_bytes
    specification = json.loads(files["SPECIFICATIONS.json"])
    inventory = json.loads(files["INPUT_INVENTORY.json"])
    mapping = json.loads(files["TRANSFORM_PLANS.json"])
    templates = json.loads(files["PACKET_TEMPLATES.json"])
    need(specification["packet"] == mapping["packet"] == PACKET, "Packet mismatch")
    need({sp["key"] for sp in specification["specs"]} == EXPECTED_KEYS and len(specification["specs"]) == 5, "Unexpected scientific scope")
    need(mapping["mathematical_changes"] == [] and len(mapping["outputs"]) == 10, "Unexpected mathematical edit/output scope")
    return files, specification, inventory, mapping, templates


def frozen_sources(worktree, specification, inventory):
    frozen = {}
    seen_preserved = set()
    for row in inventory["files"]:
        original = row["original"]
        need(original not in frozen, "Duplicate original evidence path")
        path = worktree / safe_relative(row["worktree_relative"]) if "worktree_relative" in row else Path(original)
        frozen[original] = read_exact(path, row["sha256"], row["bytes"])
        if row["classification"] == "own_or_repository_evidence":
            safe_relative(row["preserved"])
            need(row["preserved"].startswith("evidence/") and row["preserved"] not in seen_preserved, "Duplicate or invalid evidence target")
            seen_preserved.add(row["preserved"])
        else:
            need(row["classification"] == "external_primary_content" and "preserved" not in row, "Unclassified or bundled external input")
    for folder, expected in inventory["source_directory_membership"].items():
        need(source_members(S / safe_relative(folder)) == expected, "Source bundle membership changed: " + folder)
    for pattern, expected in inventory["root_evidence_glob_membership"].items():
        need(root_members(pattern) == expected, "Root evidence membership changed: " + pattern)
    for sp in specification["specs"]:
        for relative, expected in [
            (sp["source"], sp["source_sha"]), (sp["report"], sp["report_sha"]),
            (sp["folder"] + "/" + sp["helper"], sp["helper_sha"]),
            (sp["folder"] + "/" + sp["author_receipt"], sp["author_receipt_sha"]),
            (sp["review"] + "/" + sp["review_receipt"], sp["review_receipt_sha"]),
        ]:
            need(sha(frozen[str(S / relative)]) == expected, "Frozen primary/source receipt mismatch: " + relative)
        coverage = json.loads(frozen[str(S / sp["root_coverage"])])
        if sp["key"] == "Boost":
            need(coverage.get("source_review_accepted") is True and coverage.get("required_mathematical_corrections") == [], "Boost source review is incomplete")
        elif sp["key"] in {"Gapped", "Nonisolated_fock"}:
            need(coverage.get("accepted_conditional_source") is True and coverage.get("required_mathematical_corrections") == [], "Conditional source review is incomplete")
        else:
            need(coverage.get("pending") == [] and coverage.get("findings") == [] and coverage.get("disposition", "").startswith("Accept conditional source mathematics with no required correction"), "Final source/evidence closure is incomplete")
        for dep in sp["dependencies"]:
            if not dep.get("publication_target"):
                read_exact(worktree / "docs" / dep["note"], dep["sha256"])
    return frozen


def clean_base(worktree, base):
    env = {key: value for key, value in os.environ.items() if key not in {"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE"}}
    env["GIT_OPTIONAL_LOCKS"] = "0"
    records = []
    for args in [["rev-parse", "--show-toplevel"], ["rev-parse", "--verify", "HEAD"], ["status", "--porcelain=v1", "--untracked-files=all"]]:
        result = subprocess.run(["git", *args], cwd=worktree, env=env, capture_output=True, text=True, timeout=30, check=False)
        records.append({"command": ["git", *args], "stdout": result.stdout, "stderr": result.stderr, "exit_code": result.returncode})
        need(result.returncode == 0, "Read-only Git identity/cleanliness check failed: " + result.stderr)
    need(Path(records[0]["stdout"].strip()).resolve() == worktree, "--worktree must name the actual checkout root")
    need(records[1]["stdout"].strip() == base, "HEAD differs from the explicit --base; refusing all writes")
    need(not records[2]["stdout"], "Checkout/index is dirty; refusing all writes")
    need(not (worktree / PACKET).exists() and not (worktree / PACKET).is_symlink(), "Packet target already exists")
    return records


def add(payload, relative, data):
    safe_relative(relative)
    need(relative not in payload, "Duplicate publication target: " + relative)
    payload[relative] = data


def prepare_payload(worktree, base, files, specification, inventory, mapping, templates, frozen, git_records):
    payload = {}
    expected_targets = {"docs/" + sp["note"] for sp in specification["specs"]} | {"scripts/" + sp["runner"] for sp in specification["specs"]}
    need({row["publication_path"] for row in mapping["outputs"]} == expected_targets, "Publication target scope mismatch")
    for row in mapping["outputs"]:
        original = frozen[row["source_path"]]
        need(sha(original) == row["source_sha256"] and row["mathematical_changes"] == [], "Source-map identity or proof-edit mismatch")
        text = original.decode()
        for edit in row["edits"]:
            need(edit["category"] in ALLOWED_EDIT_CATEGORIES and edit["occurrences"] == 1, "Unapproved transformation category/count")
            need(text.count(edit["before"]) == 1, "Ambiguous transformation anchor: " + edit["reason"])
            text = text.replace(edit["before"], edit["after"], 1)
        text += row["appended_text"]
        data = text.encode()
        need(sha(data) == row["publication_sha256"] and len(data) == row["publication_bytes"], "Mapped publication hash mismatch")
        need(data == files["previews/" + row["publication_path"]], "Frozen review preview mismatch")
        if row["kind"] == "primary":
            compile(data, row["publication_path"], "exec")  # Syntax only; never import/execute.
            tree = ast.parse(data)
            declarations = {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
                            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                            and node.targets[0].id in {"AUDIT_TIMEOUT_SEC", "AUDIT_INPUT_PATHS"}}
            sp = next(sp for sp in specification["specs"] if "scripts/" + sp["runner"] == row["publication_path"])
            need(declarations == {"AUDIT_TIMEOUT_SEC": 60, "AUDIT_INPUT_PATHS": sp["audit_inputs"]}, "Primary declarations do not match specifications")
        add(payload, row["publication_path"], data)
    for sp in specification["specs"]:
        for dep in sp["dependencies"]:
            if dep.get("publication_target"):
                need(sha(payload["docs/" + dep["note"]]) == dep["sha256"], "Same-packet dependency does not match its exact prospective bytes")
    for name, template in templates.items():
        need(len(Path(name).parts) == 1 and Path(name).suffix in {".md", ".yaml"}, "Invalid packet template target")
        text = template.replace("@BASE@", base).replace('"@WORKTREE@"', json.dumps(str(worktree)))
        need("@BASE@" not in text and "@WORKTREE@" not in text, "Unresolved runtime metadata")
        add(payload, PACKET + "/" + name, text.encode())
    mapping = {**mapping, "base_revision": base, "target_worktree": str(worktree)}
    specification = {**specification, "base_revision": base, "target_worktree": str(worktree)}
    add(payload, PACKET + "/PUBLICATION_EDITS.json", json_bytes(mapping))
    add(payload, PACKET + "/SPECIFICATIONS.json", json_bytes(specification))
    add(payload, PACKET + "/INPUT_INVENTORY.json", files["INPUT_INVENTORY.json"])
    compile(files["reconstruct.py"], "reconstruct.py", "exec")
    add(payload, PACKET + "/reconstruct.py", files["reconstruct.py"])
    own, external = [], []
    for row in inventory["files"]:
        if row["classification"] == "external_primary_content":
            external.append(row)
            continue
        data = frozen[row["original"]]
        compressed = gzip.compress(data, mtime=0)
        add(payload, PACKET + "/" + row["preserved"], compressed)
        own.append({"original": row["original"], "preserved": row["preserved"], "bytes": len(data),
                    "sha256": sha(data), "compressed_sha256": sha(compressed),
                    **({"verified_runtime_worktree_path": str(worktree / row["worktree_relative"])} if "worktree_relative" in row else {})})
    preparation = [(Path(__file__), read_exact(Path(__file__)))] + [(Q / relative, data) for relative, data in sorted(files.items())]
    for path, data in preparation:
        preserved = "evidence/" + str(path.relative_to(S)) + ".gz"
        compressed = gzip.compress(data, mtime=0)
        add(payload, PACKET + "/" + preserved, compressed)
        own.append({"original": str(path), "preserved": preserved, "bytes": len(data), "sha256": sha(data), "compressed_sha256": sha(compressed)})
    add(payload, PACKET + "/EVIDENCE_MAP.json", json_bytes({
        "base_revision": base, "pairing": mapping["pairing"], "scope": inventory["capture_scope"],
        "files": own, "external_reference_sources": inventory["external_reference_sources"], "external_files": external,
        "excluded_transient_files": inventory["excluded_transient_files"],
        "recovery": "Decompress each preserved file and check complete byte length/SHA-256. Original absolute paths are historical provenance; canonical runners need no original scratch path.",
    }))
    add(payload, PACKET + "/EXTERNAL_SOURCE_INVENTORY.json", json_bytes({
        "policy": "Raw third-party papers, TeX, source responses, extracts and media are inventoried and stay external; nothing is deleted.",
        "sources": inventory["external_reference_sources"], "files": external,
    }))
    receipt = {
        "status": "Prepared new files only; no canonical science, cache, graph, vocabulary, audit or publication execution",
        "base_revision": base, "target_worktree": str(worktree), "pairing": mapping["pairing"],
        "preparation_script_sha256": sha(preparation[0][1]), "preparation_freeze_sha256": PREPARATION_FREEZE_SHA256,
        "read_only_git_preconditions": git_records, "own_evidence_files": len(own), "external_files_inventoried_not_bundled": len(external),
        "outputs": [{key: row[key] for key in ["kind", "publication_path", "publication_sha256", "publication_bytes"]} for row in mapping["outputs"]],
        "syntax_and_exact_anchor_checks_only": True, "mathematical_changes": [], "science_controls_run": False,
        "git_state_mutated": False, "pr_created_or_updated": False, "editable_prompt_files_changed": [],
        "root_owns_remaining_work": "Actual canonical/mutation execution, cache raw capture, graph, metadata/link/source manifests, final review and new regular stacked milestone PR",
    }
    add(payload, PACKET + "/PREPARATION_RECEIPT.json", json_bytes(receipt))
    identities = {"base_revision": base, "scope": "Prepared payload only, excluding this self-referential manifest; root must refresh after later verification/metadata changes",
                  "files": [{"path": path, "bytes": len(data), "sha256": sha(data)} for path, data in sorted(payload.items())]}
    add(payload, PACKET + "/SOURCE_IDENTITIES.json", json_bytes(identities))
    for row in mapping["outputs"]:
        raw = gzip.decompress(payload[PACKET + "/" + row["preserved_source"]])
        need(sha(raw) == row["source_sha256"], "Complete frozen source recovery mismatch")
    return payload, receipt


def absent_targets(worktree, payload, specification):
    allowed = {"docs/" + sp["note"] for sp in specification["specs"]} | {"scripts/" + sp["runner"] for sp in specification["specs"]}
    for relative in payload:
        need(relative.startswith(PACKET + "/") or relative in allowed, "Forbidden target: " + relative)
        path = worktree / safe_relative(relative)
        need(not path.exists() and not path.is_symlink(), "Refusing existing target: " + str(path))
        parent = path.parent
        while parent != worktree:
            need(not parent.is_symlink(), "Symlink target parent: " + str(parent))
            need(not parent.exists() or parent.is_dir(), "Nondirectory target parent: " + str(parent))
            parent = parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", required=True, type=Path, help="Absolute target checkout root; no default")
    parser.add_argument("--base", required=True, help="Exact full 40-character lowercase HEAD identity; no default")
    args = parser.parse_args()
    need(args.worktree.is_absolute() and args.worktree.is_dir() and not args.worktree.is_symlink(), "--worktree must be an existing absolute nonsymlink directory")
    worktree = args.worktree.resolve()
    need(re.fullmatch(r"[0-9a-f]{40}", args.base) is not None, "--base must be an explicit full commit identity")
    before = clean_base(worktree, args.base)
    files, specification, inventory, mapping, templates = preparation_inputs()
    frozen = frozen_sources(worktree, specification, inventory)
    payload, receipt = prepare_payload(worktree, args.base, files, specification, inventory, mapping, templates, frozen, before)
    absent_targets(worktree, payload, specification)
    # Refresh all identities and membership after payload construction, before
    # the first exclusive creation. Existing originals are never overwritten.
    clean_base(worktree, args.base)
    refreshed = preparation_inputs()
    need(refreshed[0] == files, "Preparation input drift during build")
    need(frozen_sources(worktree, specification, inventory) == frozen, "Source drift during build")
    need(sha(read_exact(Path(__file__))) == receipt["preparation_script_sha256"], "Preparation script drift during build")
    absent_targets(worktree, payload, specification)
    for relative, data in sorted(payload.items()):
        path = worktree / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write(data)
    print(json.dumps({**receipt, "prepared_file_count": len(payload), "packet": str(worktree / PACKET)}, indent=2))


if __name__ == "__main__":
    main()
