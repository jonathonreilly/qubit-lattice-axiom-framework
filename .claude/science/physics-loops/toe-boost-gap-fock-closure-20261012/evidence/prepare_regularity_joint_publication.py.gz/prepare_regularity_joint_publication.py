#!/usr/bin/env python3
"""Prepare three complete reviewed conditional notes; never run science or publish.

Root must inspect this script and regularity_joint_preparation/INPUT_INVENTORY.json
before executing it. --check-only builds and validates the complete proposed
payload in memory. Normal execution creates only new note/primary/packet files.
No commit, push, fetch, index mutation, audit application, or cache execution is
implemented. Existing source evidence is never edited or removed.
"""
from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess


S = Path(__file__).resolve().parent
W = S.parent / "scattering_worktree"
Q = S / "regularity_joint_preparation"
BASE = "dc7f415f73df3754653f4985382ca0fb96f07cda"
PACKET = ".claude/science/physics-loops/toe-regularity-joint-flow-20261012"
P = W / PACKET
DEADLINE = "2026-10-12 16:00:52 UTC"
INPUT_INVENTORY_SHA256 = "0bbeb32329ecd9929f8bbc1d9d4bbd33d5bb40bb7beca235e282428982f51f15"
REPAIRED_MASS_SHA256 = "4fde0f00866d19decdbc3d9fc648bba510d14f78cacd31e5134c9e88f2854d7c"

# These are proof uses, not all sources mentioned by the frozen authors.
DEPENDENCIES = {
    "SC": {
        "note": "COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md",
        "sha256": "3adc57d0236fced52704aa76e4fa7d38abbe08204623162c8fd07404a2a44a05",
        "role": "Compact-patch signs, locality, packet and cutoff framework; the needed arguments are reconstructed, without importing isolated-shell scattering conclusions.",
    },
    "Fock": {
        "note": "COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md",
        "sha256": "494c283c163e88f959841462bbfbcfcc7c470072a0525d0dd6e2b44dd6f9b12b",
        "role": "F7-F9 mixed-lowering finite-energy proof mechanism, reproduced at the actual mass-note hypotheses; no Fock Gram, density or isometry conclusion is imported.",
    },
    "Centre": {
        "note": "ISOLATED_CENTRE_FILTERING_BOUNDED_THEOREM_NOTE_2026-10-12.md",
        "sha256": "1671b4cfa7a24e42875b3aa142444cdc034b1087a26325514d1dc0de8615051f",
        "role": "Supplied commuting-flow/mass premises, fixed almost-local filtering, exact isolated-mass selection and selected lift; no central isolation or downstream scattering/detector conclusion is imported.",
    },
    "Current": {
        "note": "MICROSCOPIC_CURRENT_IMPLEMENTATION_BOUNDED_THEOREM_NOTE_2026-10-12.md",
        "sha256": "e97ba0f26e1a21f3a4cd231c1abc9c97b8fbdc0b127bcfb6354aef37e4a54ccf",
        "role": "I14-I29 individual norm-flow construction and full canonical GNS implementation; I1-I13 additionally supplies the current-density application.",
    },
}

SPECS = [
    {
        "key": "Nonisolated_mass",
        "prefix": "NONISOLATED_MASS_SCATTERING",
        "slug": "nonisolated_mass_scattering",
        "source": "NONISOLATED_MASS_SCATTERING_PROBE.md",
        "source_sha": "afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d",
        "folder": "nonisolated_mass_scattering",
        "review": "nonisolated_mass_review",
        "helper": "check_nonisolated_controls.py",
        "report": "NONISOLATED_MASS_SCATTERING_REVIEW.md",
        "report_sha": "09da880b4ebdf629cffcc72c490176e6706b0ae4b01790eb3a267b6d8b284143",
        "author_receipt": "FINAL_RECEIPT.json",
        "review_receipt": "FINAL_RECEIPT.json",
        "dependency_keys": ["SC", "Fock"],
        "scope": "Under actual finite-range physical dynamics, a unique gapped vacuum, supplied stable graph sectors, positive full-operator transfer and geometric detuning regularity, fixed finite velocity-separated time-averaged products have incoming/outgoing limits independent of admissible creators and every fixed sublinear power width. No Fock, density, detector, exhaustion or microscopic-realization conclusion is supplied.",
        "conditional": "Finite-product scattering from an explicit geometric detuning bound on each residual packet",
        "claim_reason": "Actual dynamics, stable graph sectors, positive transfer and regular seed vectors remain supplied; the analytic implication is conditional.",
        "consumer": "A future independently checked nonexact-vacuum Fock and detector extension on actual regular creator classes.",
        "next_action": "Construct regular creators and establish their target density in an actual model; separately check Fock and detector extensions.",
        "baseline_stdout": "nonisolated_mass_scattering/author_controls.stdout",
        "comparison": "All original scientific JSON rows must match exactly. Only the historical independence wording in the final summary and appended scope/totals may differ.",
        "mutation_source": "nonisolated_mass_review/controls/run_author_mutations.py",
        "mutation_results": "nonisolated_mass_review/AUTHOR_MUTATION_RESULTS.json",
        "mutation_limits": "Preserve fourteen mutations: eleven rejected defects, two nondiscriminating defect gates and one benign weakened padding inequality. Do not silently repair these gates.",
        "supplemental_control": "nonisolated_mass_review/controls/check_general_beta_conversion.py",
    },
    {
        "key": "Centre_regularity",
        "prefix": "CENTRE_REGULARITY_TO_GEOMETRIC",
        "slug": "centre_regularity_to_geometric",
        "source": "CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md",
        "source_sha": "9ec8c3148442f981d6b3d4d38027ffde0d2a64adbd6e4664d6a24b5d3d06608a",
        "folder": "centre_regularity_to_geometric",
        "review": "centre_regularity_review",
        "helper": "analytic_control.py",
        "report": "CENTRE_REGULARITY_TO_GEOMETRIC_REVIEW.md",
        "report_sha": "bdeb88293de00f16e45a6747f46edda8c3391db5fdf3f1503c7a584b68ac3703",
        "author_receipt": "FREEZE_RECEIPT.json",
        "review_receipt": "FINAL_REVIEW_RECEIPT.json",
        "dependency_keys": ["Centre"],
        "scope": "On an exactly selected positive isolated mass and one fixed joint lift chart, a supplied product spectral carrier, residual momentum H1 regularity and a central spectral power bound imply the geometric norm exponent a/(2a+1) and the exact chartwise graph projection. A supplied scalar massive boost representation gives a separate domain-to-H1 implication. Actual regular almost-local seed existence, density and microscopic realization remain open.",
        "conditional": "Geometric spectral regularity from explicit joint-carrier, Sobolev and central-rate hypotheses",
        "claim_reason": "The fixed-mass representation, Sobolev trivialization and actual creator regularity remain supplied, and abstract vector density is not operator density.",
        "consumer": "A separately checked time-averaged scattering argument after matching the actual creator, transfer, graph and regularity hypotheses.",
        "next_action": "Identify a checked joint carrier and boost gauge for actual almost-local seed vectors, then prove their central rate and target density.",
        "baseline_stdout": "centre_regularity_to_geometric/logs/analytic_control_frozen_candidate.stdout",
        "comparison": "Canonical stdout must begin with every original stdout byte; only completion totals and an explicit finite-scope limitation may follow.",
        "mutation_source": "centre_regularity_review/mutation_study.py",
        "mutation_results": "centre_regularity_review/MUTATION_RESULTS.json",
        "mutation_limits": "Preserve the zero tent integral and omitted quadratic-term survivors of author upper-bound gates; independent exact Simpson rejects both. Do not modify calculations to hide the limitation.",
        "supplemental_control": "centre_regularity_review/tent_integral_control.py",
    },
    {
        "key": "Joint_flow",
        "prefix": "MICROSCOPIC_JOINT_FLOW",
        "slug": "microscopic_joint_flow",
        "source": "MICROSCOPIC_JOINT_FLOW_PROBE.md",
        "source_sha": "35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd",
        "folder": "microscopic_joint_flow",
        "review": "microscopic_joint_flow_review",
        "helper": "controls/joint_controls.py",
        "report": "MICROSCOPIC_JOINT_FLOW_REVIEW.md",
        "report_sha": "9699043c35343901ef75ab6a29dd560ba4aa30f8a3b908643e959958e86447c9",
        "author_receipt": "receipt.json",
        "review_receipt": "receipt.json",
        "dependency_keys": ["Current"],
        "scope": "A finite family of supplied self-adjoint generators with bounded finite-range spin actions on the actual local cyclic domain and exact pairwise commutation there has strongly commuting spectral measures and commuting microscopic norm flows. Translation-covariant finite densities admit a complete one-site criterion and scalar-plus-local-divergence classification. No generic current conservation, integrated Poincare model or physical realization is derived.",
        "conditional": "Strong joint commutation from exact local-vector commutation and finite-range actions",
        "claim_reason": "The finite-range actions and self-adjoint generators remain supplied; exact commutation on their actual local cyclic domain is sufficient.",
        "consumer": "The strong joint-commutation premise of compact-patch microscopic H/current scattering constructions, once the intended model supplies the exact local identities.",
        "next_action": "Verify the full one-site conservation and cross-current identities for the intended model with actual self-adjoint generators and local actions.",
        "baseline_stdout": "microscopic_joint_flow/logs/controls.run1.stdout.jsonl",
        "comparison": "All thirty-seven scientific JSON rows remain byte-identical; final source_sha256 is recomputed from canonical bytes. Only the adjacent result JSON write is suppressed, and scoped totals are added.",
        "mutation_source": "microscopic_joint_flow/run_mutations.py",
        "mutation_results": "microscopic_joint_flow/mutations/summary.json",
        "mutation_limits": "Retain all five failed whole-source mutants and every passing nondiscriminating row. Source hashes change through the explicit canonical packaging transformations.",
        "supplemental_control": "microscopic_joint_flow_review/independent_controls.py",
    },
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def need(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def source_bytes(path: Path, expected: str | None = None) -> bytes:
    need(path.is_file() and not path.is_symlink(), f"Missing or nonregular source: {path}")
    data = path.read_bytes()
    if expected is not None:
        need(sha(data) == expected, f"Source identity mismatch: {path}")
    return data


def base_is_clean() -> None:
    env = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}
    head = subprocess.check_output(["git", "rev-parse", "--verify", "HEAD"], cwd=W, env=env, text=True).strip()
    need(head == BASE, f"Expected base {BASE}, found {head}; refusing preparation")
    status = subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=W, env=env)
    need(not status, "Worktree/index is dirty; refusing preparation without changing anything")
    need(not P.exists(), f"Milestone packet already exists: {P}")


def inventory_and_sources():
    raw = source_bytes(Q / "INPUT_INVENTORY.json", INPUT_INVENTORY_SHA256)
    inventory = json.loads(raw)
    need(inventory["base_revision"] == BASE, "Inventory base mismatch")
    frozen = {}
    for row in inventory["files"]:
        path = Path(row["original"])
        data = source_bytes(path, row["sha256"])
        need(len(data) == row["bytes"], f"Size mismatch: {path}")
        frozen[str(path)] = data
    for folder, expected in inventory["source_directory_membership"].items():
        found = sorted(str(p.relative_to(S)) for p in (S / folder).rglob("*")
                       if p.is_file() and "__pycache__" not in p.parts and p.name != ".DS_Store")
        need(found == expected, f"Evidence membership changed in {folder}; refresh the reviewed inventory")
    for sp in SPECS:
        source_bytes(S / sp["source"], sp["source_sha"])
        source_bytes(S / sp["report"], sp["report_sha"])
        review = json.loads(frozen[str(S / (sp["key"] + "_root_review_coverage.json"))])
        need(review.get("passed") is True, f"Root review coverage is not complete for {sp['key']}")
        if sp["key"] == "Joint_flow":
            need(review.get("pending") == [], "Joint review coverage still has pending checks")
    for dep in DEPENDENCIES.values():
        source_bytes(W / "docs" / dep["note"], dep["sha256"])
    return inventory, frozen, raw


def enrich_specs(frozen):
    specs = json.loads(json.dumps(SPECS))
    for sp in specs:
        sp["note"] = sp["prefix"] + "_BOUNDED_THEOREM_NOTE_2026-10-12.md"
        sp["runner"] = sp["slug"] + "_2026_10_12.py"
        sp["claim"] = sp["slug"] + "_bounded_theorem_note_2026-10-12"
        sp["dependencies"] = [DEPENDENCIES[key] for key in sp["dependency_keys"]]
        sp["prerequisites"] = [d["note"] for d in sp["dependencies"]]
        sp["deps"] = [n.removesuffix(".md").lower() for n in sp["prerequisites"]]
        sp["timeout_sec"] = 60
        for field, rel in {
            "helper_sha": sp["folder"] + "/" + sp["helper"],
            "author_receipt_sha": sp["folder"] + "/" + sp["author_receipt"],
            "review_receipt_sha": sp["review"] + "/" + sp["review_receipt"],
        }.items():
            sp[field] = sha(frozen[str(S / rel)])
        for field in ["baseline_stdout", "mutation_source", "mutation_results", "supplemental_control"]:
            need(str(S / sp[field]) in frozen, f"Unbound verification input: {sp[field]}")
        sp["audit_inputs"] = ["docs/" + sp["note"]] + ["docs/" + n for n in sp["prerequisites"]]
        sp["canonical_execution_status"] = "not_run_by_preparation"
    return specs


class Transform:
    def __init__(self, data: bytes):
        self.original = data
        self.text = data.decode()
        self.edits = []

    def replace(self, before: str, after: str, reason: str) -> None:
        need(self.text.count(before) == 1, f"Ambiguous edit ({reason}): {before[:100]!r}")
        self.text = self.text.replace(before, after, 1)
        self.edits.append({"before": before, "after": after, "reason": reason})

    def record(self, kind, source, target, suffix=""):
        final = (self.text + suffix).encode()
        return final, {
            "kind": kind, "source_path": str(S / source),
            "source_sha256": sha(self.original), "preserved_source": "evidence/" + source + ".gz",
            "edits": self.edits, "appended_text": suffix,
            "publication_path": target, "publication_sha256": sha(final),
        }


def machine_header(sp):
    fields = {
        "claim_id": sp["claim"], "claim_type": "bounded_theorem", "claim_scope": sp["scope"],
        "upstream_dependencies": sp["deps"], "runner": "scripts/" + sp["runner"],
        "actual_current_surface_status": "conditional-support", "target_claim_type": "bounded_theorem",
        "trace_class": "upstream_support", "target_claim_id": None,
        "target_blocker_text": sp["consumer"], "source_of_blocker_text": "handoff",
        "reachability_to_target": "partially_closes", "artifact_role": "theorem",
        "next_trace_action": sp["next_action"], "conditional_surface_status": sp["conditional"],
        "hypothetical_axiom_status": None, "admitted_observation_status": None,
        "claim_type_reason": sp["claim_reason"], "audit_required_before_effective_retained": True,
        "bare_retained_allowed": False,
    }
    lines = ["---"]
    for key, value in fields.items():
        if isinstance(value, list):
            lines.append(key + (":" if value else ": []"))
            lines.extend("  - " + item for item in value)
        elif isinstance(value, str):
            lines.append(key + ": " + json.dumps(value, ensure_ascii=False))
        else:
            lines.append(key + ": " + json.dumps(value))
    return "\n".join(lines) + "\n---\n\n"


def publication_appendix(sp):
    common = f"""

## Publication evidence and review record

The frozen author source is `{sp['source']}`, SHA-256 `{sp['source_sha']}`.
The separate source review is `{sp['report']}`, SHA-256 `{sp['report_sha']}`,
with review receipt SHA-256 `{sp['review_receipt_sha']}`. The complete source,
review, controls, output streams, failures, source revisions and root coverage
records are indexed by the [evidence map](../{PACKET}/EVIDENCE_MAP.json).
The [exact transformation map](../{PACKET}/PUBLICATION_EDITS.json) and
[reconstruction program](../{PACKET}/reconstruct.py) recover the entire note
and primary from their frozen bytes. Historical write-scope and pending-review
statements above describe the author freeze; the following record describes
the completed source review. Root contributed the mechanisms and is a coauthor,
not the independent reviewer. No new review was performed by the packaging worker.

"""
    detail = {
        "Nonisolated_mass": r"""The review supports N1-N31 and the beta=1 spectral example N32-N35. Its
one required mathematical repair is explicit: the general-beta conversion
now defines the weighted Casimir and consistently uses that variable in N36
and its regularity sentence. The frozen original remains unchanged. The
repair-only note, before any publication metadata, has SHA-256
`4fde0f00866d19decdbc3d9fc648bba510d14f78cacd31e5134c9e88f2854d7c`.
The exact before/after fragment, beta=2 counterexample and separate algebraic
and spectral checks are preserved in `nonisolated_mass_review/N36_PUBLICATION_REPAIR.json`.
No other proof edit is made.

The reviewer saw source text, receipt metadata and prior reviews. Its initial
reconstruction and distinct continuum control froze before opening the new
author helper/output. A first quadrature run failed; the refinement retained
its cases and gates, and both source versions and logs remain. The later N36
finding supersedes the reconstruction's preliminary assessment. The original
author helper reproduced byte for byte. Of fourteen actual-source mutations,
eleven defects were rejected, two defect gates were nondiscriminating and a
benign weakened padding inequality survived. Specifically, deleting both
compensating energy-word terms or setting the finite Casimir detuning to zero
could survive the relevant author gates. These limitations are preserved;
finite arithmetic does not establish the analytic inequalities or convergence.

The source's infinite-tail witness concerns only the declared commuting
spectral data. It is not a finite-range lattice countermodel. The Cook power
condition is sufficient; comparison covers all fixed positive sublinear
widths. The reviewed `SCOPE_STRESS_TEST.md` remains part of the evidence.
No regular-creator existence/density, multiparticle nontriviality, Fock or
detector extension, all-channel coverage or microscopic model is supplied.
""",
        "Centre_regularity": r"""The review supports the complete G1-G32 conditional source without a required
mathematical correction. The source's earlier density overstatement is retained
as history with its complete correction diff: ambient H1 density does not give
H1 density in an arbitrary momentum-dependent physical range. The final source
already distinguishes that range, the full product carrier, the explicit scalar
carrier and actual almost-local operator columns.

The reconstruction and distinct controls froze before opening the current
author helper/output or the earlier density draft; the candidate proof and
its descriptions of controls and witnesses were visible. Root's preliminary
view and source freshness message are disclosed in the review. The independent
line proof uses Fourier Cauchy-Schwarz. Separate two-dimensional energy
bisection and the actual boost pullback test geometry and the invariant-measure
term. These are distinct finite checks, not blind checking or proof by counts.

The original helper's upper-bound gates allow two wrong tent integrals to
survive: zero mass and deletion of the quadratic term. A separate exact
rational Simpson integration of the actual squared tent matched the authentic
function and rejected both. The canonical helper keeps the original calculations
and their limitation; it does not silently add a new gate. All surviving and
rejected mutants and the post-evidence exact check are preserved. The analytic
source's tent formula is unchanged. The original helper reproduced all 7,225
stdout bytes; publication adds only declarations, an assertion guard and
completion/scope lines. The scalar domain implication does not construct
actual boost-regular almost-local seeds, a dense regular creator class or an
identified microscopic representation.
""",
        "Joint_flow": r"""The review supports J1-J24 without a required mathematical correction. It
read the actual current-implementation predecessor in full and matched the
local action, mixed-domain, individual-flow and full GNS implementation uses.
The joint conclusion remains conditional on the supplied self-adjoint operators
and the exact commutation identities on their actual local cyclic domain.

The reconstruction and distinct implementation froze before author helper,
output and mutant exposure. Candidate result summaries and upstream source and
receipt metadata were visible; this was not blinded checking. Exact Gaussian-
integer open-cutoff matrices, a complete qutrit basis and weighted two-dimensional
histories test different fixtures from the author helper. The baseline and all
five saved whole-source mutants reproduced their scientific output rows and
stdout exactly; replay result timestamps changed and were explicitly excluded
from metadata equality. The current-sign, half-factor, support-growth, Jacobi-
sign and divergence-term mutants fail their recorded gates. Passing mutant
rows, tracial-vacuum nondiscrimination, positive-pair sign/rescaling survival
and arithmetic-only binomial checks remain visible.

The canonical primary suppresses only the adjacent JSON-file write, declares
its inputs/timeout and assertion guard, and reports scoped execution totals.
Every calculation is preserved. Its printed self-hash correctly changes with
those recorded edits. Its only file read is its own source for that integrity
hash; declared note/dependency inputs bind the proof scope for the cache.
Neither the finite controls nor the classification builds an actual self-adjoint
realization or proves conservation for an intended physical model. The failed
instruction-freshness check and subsequent exact current-reference reread in
the review remain preserved; no prompt source was changed.
""",
    }[sp["key"]]
    end = f"""

The [canonical finite primary](../scripts/{sp['runner']}) is separate from the
analytic proof. For the mass and regularity primaries, `TOTAL` counts one
completed assertion-guarded driver; for the joint primary it counts its recorded
finite predicates. Neither total is a proof grade. Canonical execution, whole-
source mutation replays, current cache creation, graph acknowledgment and final
focused checks were **not run by preparation**. Their actual results must be
recorded in [delivery checks](../{PACKET}/DELIVERY_CHECKS.md) before publication.
No helper-registry policy change or formal audit is performed here.

The complete frozen argument retains its supplied conditions, scoped negative
witnesses and open application obligations. No Lean certificate, applied audit
verdict, retained promotion, new physical axiom or microscopic model is asserted.
The global combined pipeline and strict audit lint remain independent landing
gates. This is a frozen milestone packet; the sole live campaign checkpoint
remains in the transport worktree. Editable prompt files changed: none.
"""
    return common + detail + end


def transform_note(sp, frozen):
    tr = Transform(frozen[str(S / sp["source"])])
    if sp["key"] == "Nonisolated_mass":
        repair = json.loads(frozen[str(S / "nonisolated_mass_review/N36_PUBLICATION_REPAIR.json")])
        need(repair["frozen_note_sha256"] == sp["source_sha"], "N36 original identity mismatch")
        need(sha(repair["before"].encode()) == repair["before_sha256"], "N36 before fragment drift")
        need(sha(repair["after"].encode()) == repair["after_sha256"], "N36 after fragment drift")
        tr.replace(repair["before"], repair["after"], "Sole authorized mathematical repair: reviewed weighted general-beta Casimir in N36.")
        need(sha(tr.text.encode()) == REPAIRED_MASS_SHA256 == repair["prospective_note_sha256"], "Repair-only source differs from the reviewed prospective note")
    header = machine_header(sp)
    if tr.text.startswith("---\n"):
        old_header = tr.text[:tr.text.index("\n---\n", 4) + len("\n---\n\n")]
        tr.replace(old_header, header, "Complete claim/dependency/status/trace metadata; no proof change.")
    else:
        first = tr.text.splitlines(keepends=True)[0]
        tr.replace(first, header + first, "Add complete claim/dependency/status/trace metadata; no proof change.")

    provenance = (f"S denotes the original research collection. The [frozen milestone handoff](../{PACKET}/HANDOFF.md) "
                  f"and [evidence map](../{PACKET}/EVIDENCE_MAP.json) preserve the source files, full author/reviewer evidence and their identities. ")
    deptext = "The actual in-branch proof uses are " + "; ".join(
        f"[{key}]({DEPENDENCIES[key]['note']}): {DEPENDENCIES[key]['role']}"
        for key in sp["dependency_keys"]) + " Other historical references remain provenance only."
    if sp["key"] == "Nonisolated_mass":
        tr.replace("**Status:** conditional-support, author derivation; independent review pending.",
                   "**Actual current-surface status:** conditional-support. **Source review:** complete with the reviewed N36 definition repair below.",
                   "Record completed source review and its sole correction without claiming audit status.")
        old = next(line for line in tr.text.splitlines() if line.startswith("Write S for `/Users/"))
        tr.replace(old, provenance + "SW denotes the source-bound science checkout. " + deptext,
                   "Portable file-level recovery references and exact SC/finite-energy proof dependencies.")
        tr.replace("This is an author proof and proof-level adaptation, with fresh independent review still required.",
                   "At author freeze this proof-level adaptation awaited fresh independent review; that source review is now complete and recorded below.",
                   "Separate historical pending status from completed review.")
        old = next(line for line in tr.text.splitlines() if line.startswith("The fixed campaign deadline is"))
        tr.replace(old, "Frozen author operational record: " + old, "Identify historical author-only write-scope statement.")
    elif sp["key"] == "Centre_regularity":
        tr.replace("**Actual current-surface status:** conditional-support, author proof and controls; independent review pending.",
                   "**Actual current-surface status:** conditional-support. **Source review:** complete with no required mathematical correction.",
                   "Record completed source review without changing the argument.")
        old = next(line for line in tr.text.splitlines() if line.startswith("Let S be `/Users/"))
        tr.replace(old, provenance + deptext, "Portable recovery references and isolated-centre proof dependency only.")
        tr.replace("A fresh source review must check the general direct-integral slicing, graph projection, weights and domain matching before substantial downstream reuse.",
                   "At author freeze a fresh source review was required for the general direct-integral slicing, graph projection, weights and domain matching before substantial downstream reuse; the completed source review is recorded below.",
                   "Preserve the historical review obligation and record its completion.")
        tr.replace("**Handoff:** the elementary conditional bridge is ready for independent source review.",
                   "**Frozen author handoff:** the elementary conditional bridge was ready for independent source review. Publication update: that source review is complete.",
                   "Label the historical pending handoff.")
        old = next(line for line in tr.text.splitlines() if line.startswith("Only this note and"))
        tr.replace(old, "Frozen author operational record: " + old, "Identify historical author-only write-scope statement.")
    else:
        tr.replace("**Author derivation, 2026-10-12; independent review required.**",
                   "**Conditional bounded theorem, 2026-10-12; complete separate source review requires no mathematical correction.**",
                   "Record completed conditional source review only.")
        old = next(line for line in tr.text.splitlines() if line.startswith("Write S for this note's directory."))
        # Keep the exact 399-line/hash provenance attached to the original probe,
        # not to the longer published note that includes metadata and review.
        after = old.replace("Write S for this note's directory. ", provenance, 1)
        after = after.replace("[the current-implementation probe](MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md)",
                              "the original `MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md`", 1)
        tr.replace(old, after + " " + deptext, "Map the exact original current proof to its canonical publication without a dangling probe link.")
        tr.replace("No independent reviewer has checked this new candidate yet.",
                   "At author freeze no independent reviewer had checked this new candidate; the separate complete source review is now recorded below.",
                   "Separate historical pending review from the completed check.")
        old = next(line for line in tr.text.splitlines() if line.startswith("Only this note and"))
        tr.replace(old, "Frozen author operational record: " + old, "Identify historical author-only write-scope statement.")
    return tr.record("note", sp["source"], "docs/" + sp["note"], publication_appendix(sp))


N5_MASS = [
    "per_element: finite derivative, free-word and rational-margin identities are checked; the analytic convergence proof is in the note.",
    "per_site: finite hard-core creator padding is checked; no microscopic infinite-lattice realization is constructed.",
    "per_mode: finite zero-detuning and Casimir spectral examples are checked; infinite tail conclusions use the displayed analytic proof.",
    "per_block: fixed finite-product ordering and all-spectator exponent bookkeeping are checked; no Fock or detector extension is computed.",
    "lattice_wide: checked and not executed — these finite controls do not realize an infinite lattice model or establish channel exhaustion.",
]
N5_JOINT = [
    "per_element: exact finite Pauli currents, Jacobi densities and local divergence identities are checked against stated fixtures.",
    "per_site: a complete qubit one-site basis is exercised with finite support bookkeeping; no physical self-adjoint model is constructed.",
    "per_mode: checked and not executed — no particle spectral mode, mass shell or asymptotic particle sector is tested by these controls.",
    "per_block: finite mixed-color histories and six-site matrices are checked; finite predicates do not establish unbounded domains.",
    "lattice_wide: checked and not executed — the thermodynamic and strong-commutation statements require the analytic conditional proof.",
]


def transform_primary(sp, frozen):
    relative = sp["folder"] + "/" + sp["helper"]
    tr = Transform(frozen[str(S / relative)])
    tree = ast.parse(tr.text)
    ordinary = list(tree.body)
    if ordinary and isinstance(ordinary[0], ast.Expr) and isinstance(ordinary[0].value, ast.Constant) and isinstance(ordinary[0].value.value, str):
        ordinary.pop(0)
    while ordinary and isinstance(ordinary[0], ast.ImportFrom) and ordinary[0].module == "__future__":
        ordinary.pop(0)
    need(bool(ordinary), "Primary has no insertion boundary")
    anchor = tr.text.splitlines(keepends=True)[ordinary[0].lineno - 1]
    declarations = ("AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = " + json.dumps(sp["audit_inputs"], indent=4) +
                    '\nif not __debug__:\n    raise RuntimeError("Run without -O: finite control assertions must be enabled")\n\n')
    tr.replace(anchor, declarations + anchor, "Declare actual proof inputs, timeout and assertion guard after the docstring and all future imports.")
    suffix = ""
    if sp["key"] == "Nonisolated_mass":
        tr.replace('independence="author controls only; separate proof review remains pending"',
                   'independence="author controls only; completed separate source review is recorded in the note"',
                   "Update only the historical pending-review metadata in the emitted summary.")
        suffix = "\n" + "\n".join("print(" + repr(line) + ")" for line in N5_MASS)
        suffix += '\nprint("TOTAL: PASS=1 FAIL=0")\nprint("SCOPE: One completed assertion-guarded finite author driver; known mutation survivors are disclosed in the note, and no analytic or physical-model proof is numerical.")\n'
    elif sp["key"] == "Centre_regularity":
        suffix = '\nprint("TOTAL: PASS=1 FAIL=0")\nprint("SCOPE: One completed assertion-guarded finite author driver; the tent upper-bound gates remain nondiscriminating for two documented mutants, and no general proof is numerical.")\n'
    else:
        tr.replace("    Path(__file__).with_name('joint_controls_results.json').write_text(json.dumps(out,indent=2)+'\\n')",
                   "    # Canonical execution reports through stdout; the original adjacent JSON and all calculations are preserved in the packet.",
                   "Suppress only the adjacent JSON result-file side effect; preserve all calculations and the source integrity hash.")
        before = "    raise SystemExit(bool(out['failed']))"
        after = "\n".join("    print(" + repr(line) + ")" for line in N5_JOINT)
        after += '\n    print("TOTAL: PASS=" + str(out["total"] - out["failed"]) + " FAIL=" + str(out["failed"]))\n'
        after += '    print("SCOPE: Finite predicates only; no unbounded-domain, thermodynamic or physical-realization certificate.")\n' + before
        tr.replace(before, after, "Add finite execution scope and actual predicate totals without changing the failure gate.")
    result, row = tr.record("primary", relative, "scripts/" + sp["runner"], suffix)
    compile(result.decode(), row["publication_path"], "exec")  # syntax only; never execute
    return result, row


RECONSTRUCT = '''"""Verify every preserved byte and reconstruct all three notes and primaries."""
from pathlib import Path
import gzip
import hashlib
import json

P = Path(__file__).resolve().parent
W = P.parents[3]

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

evidence = json.loads((P / "EVIDENCE_MAP.json").read_text())
for row in evidence["files"]:
    packed = (P / row["preserved"]).read_bytes()
    require(sha(packed) == row["compressed_sha256"], row["preserved"])
    raw = gzip.decompress(packed)
    require(len(raw) == row["bytes"] and sha(raw) == row["sha256"], row["original"])
for row in json.loads((P / "PUBLICATION_EDITS.json").read_text())["outputs"]:
    raw = gzip.decompress((P / row["preserved_source"]).read_bytes())
    require(sha(raw) == row["source_sha256"], row["source_path"])
    text = raw.decode()
    for edit in row["edits"]:
        require(text.count(edit["before"]) == 1, "Ambiguous transformation: " + edit["reason"])
        text = text.replace(edit["before"], edit["after"], 1)
    text += row["appended_text"]
    final = (W / row["publication_path"]).read_bytes()
    require(final == text.encode() and sha(final) == row["publication_sha256"], row["publication_path"])
print("All preserved own/repository bytes, three complete notes and three entire finite primaries reconstruct exactly. External paper bytes are inventoried, not bundled or reread here.")
'''


def packet_texts(specs):
    dependency_lines = "\n".join(
        "- " + sp["key"] + ": " + "; ".join(d["note"] + " — " + d["role"] for d in sp["dependencies"])
        for sp in specs)
    return {
        "STATE.yaml": f'''loop: toe-regularity-joint-flow-20261012
mode: milestone_snapshot
delivery: milestone
base_revision: {BASE}
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
conditional_surface_status: "Three separate implications under their named supplied hypotheses"
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: "Proof implications do not construct their physical model or regular seed hypotheses"
trace_class: upstream_support
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
independent_check: three_source_bound_reviews_one_reviewed_N36_repair
canonical_execution: not_run_by_preparation
pr: null
pr_status: preparation_only
next_exact_action: "Root reviews the six transformed files, runs canonical verification and records actual delivery results"
strongest_open_obligation: "Actual self-adjoint microscopic realization, exact conservation and regular almost-local creator existence/density"
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
deadline_utc: "{DEADLINE}"
stop_condition: "The fixed campaign deadline is not extended by packaging"
''',
        "GOAL.md": """# Exact conditional milestone contract

Preserve three complete arguments: geometric regularity gives fixed finite
time-averaged scattering products; central/Sobolev regularity gives a fixed-mass
geometric detuning bound; exact local-vector commutation for supplied finite-
range self-adjoint generators gives strong joint microscopic flows. Each note
retains its separate quantified domain and physical hypotheses. The mass
conversion paragraph receives only the reviewed weighted-Casimir definition.
The main evidence is the displayed proofs and source-bound independent checks.
Finite outputs are discriminating controls with documented limits.
""",
        "ASSUMPTIONS_AND_IMPORTS.md": "# Actual proof dependencies and supplied inputs\n\n" + dependency_lines + """

Mass: actual finite-range physical dynamics, unique gapped vacuum, stable
reducing graph sectors, positive full-operator temporal transfer and geometric
regularity of each actual residual packet. SC/Fock proof mechanisms are reused
only at the displayed matched hypotheses; Fock/isometry conclusions are not.
Centre: exact isolated-mass restriction, a common fixed lift, a supplied joint
product carrier and Sobolev trivialization, central rate, and actual regular
seed conditions. Scalar boost representation/domain assumptions are separate.
Joint: finitely many actual self-adjoint generators with exact local actions,
finite-range interactions and pairwise vector commutation on the same local
cyclic domain. Model-specific conservation and boost realization remain supplied.
No registered primitive or physical axiom is added. The three notes are not
assumed to construct one jointly realized microscopic example.
""",
        "APPROACH_REGISTRY.md": """# Mathematical mechanisms

Mass uses time averages, mixed-lowering finite-energy estimates, unequal-time
LR localization, Cook estimates with every spectator and comparison of widths.
Centre uses Hilbert-valued line control plus massive Hessian transversality;
exact squared-energy slabs independently check the geometric step. A separate
full-line rapidity argument identifies the supplied scalar boost domain.
Joint uses mixed connected histories, self-adjoint Taylor remainders, absolute
multiple series and finite time subdivision, followed by finite padded Jacobi,
one-site basis tests and a local divergence classification.
These are mathematical mechanisms; hashes and predicate counts are bookkeeping.
""",
        "ROUTE_PORTFOLIO.md": """# Evidence roles and exposure

Each author note has a separate full source reconstruction and a distinct finite
control implementation. The reviews disclose prior source/metadata exposure;
their pre-author-helper freezes do not imply blind checking. Root proposed the
mechanisms and remains a coauthor. The mechanical preparer performs no new
scientific review. Full author/reviewer evidence and root coverage records are
preserved with source identities. The external paper inventory is provenance,
not a new paper-read or independent-check claim.
""",
        "OPPORTUNITY_QUEUE.md": """# Remaining application work

An actual self-adjoint microscopic realization and exact model-specific current
conservation would make the joint-flow criterion useful. Actual regular
almost-local creator vectors with a checked joint spectral carrier, central
rate and dense target components would make the regularity bridge useful.
The nonexact-vacuum setting still requires its own Fock/detector arguments and
channel-coverage analysis. These are separate tasks; no work is launched by
this frozen packet and the live campaign checkpoint stays in the transport tree.
""",
        "NO_GO_LEDGER.md": """# Preserved negative witnesses and failed controls

Mass retains the extra zero-detuning atom and infinite spectral tail example,
the failure of Casimir regularity to imply the required geometric rate from
those spectral facts alone, and the explicit repaired whole-residual conversion.
The failed first continuum quadrature run, refinement and actual-source mutation
survivors remain in the evidence. No lattice no-go is inferred.
Centre retains all six deleted-hypothesis spectral witnesses and the corrected
momentum-dependent-range density statement. Two wrong tent integrals survive
author upper-bound gates; independent exact Simpson integration rejects them.
Joint retains an exact nonconserving current, nonzero conserving divergences,
vacuum/selected-observable insufficiency and finite-boundary effects. Finite
controls do not establish a broad impossibility result or an infinite model.
The original centre N1-N8 discussion and mass SCOPE_STRESS_TEST are preserved.
Preparation asserts no universal five-route gate PASS; final scope/gate
conformance remains root's documented responsibility before publication.
""",
        "LITERATURE_BRIDGES.md": """# Sources and limited reuse

The mass note adapts the named Dybalski hep-th/0412226v4 mechanism and the
relevant BDN arXiv:1412.2970v2 lattice arguments at explicitly checked scope.
Relativistic locality, Poincare representation and massless/Fock conclusions
are not silently imported. EVIDENCE_MAP and EXTERNAL_SOURCE_INVENTORY bind the
official source URLs, versions, downloaded bytes and every extracted/rendered
external artifact; the originals remain external and are not deleted.
The centre scalar-domain proof is self-contained; earlier free-Dirac sources
provide historical context only. The joint proof invokes no new analytic-
vector integrability theorem. No new exhaustive novelty search or paper read
was performed in preparation.
""",
        "ARTIFACT_PLAN.md": """# Planned regular milestone

Create three full notes, three canonical finite primaries and this source-bound
packet. Root executes and checks the proposed bytes, then records actual caches,
mutations, graph effects, focused conformance and publication outcome. This
preparation creates no commit, PR, cache, graph acknowledgment or audit result.
No existing source, prompt, audit surface or campaign checkpoint is overwritten.
""",
        "TRACE_GATE.md": """# Conditional upstream support

trace_class: upstream_support
target_claim_id: null
target_blocker_text: "Microscopic scattering applications need actual commuting flows and a regular creator class with justified spectral hypotheses."
source_of_blocker_text: handoff
reachability_to_target: partially_closes
artifact_role: theorem
next_trace_action: "Construct and verify the intended model and actual regular creators; independently check downstream nonexact-vacuum extensions."

Mass supports a future Fock/detector extension under new matched arguments.
Centre supports a geometric regularity premise only after its actual vector
contract is supplied. Joint supports the strong-commutation premise only
after the intended model satisfies the exact local conservation tests.
No theorem is treated as supplying the other notes' physical premises.
""",
        "CLAIM_STATUS_CERTIFICATE.md": """# Claim status certificate

actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
conditional_surface_status: "Implications at each note's explicitly supplied premises"
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: "Physical realization and actual regular creator hypotheses remain supplied"
trace_class: upstream_support
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false

Three complete separate source reviews are preserved. One reviewed N36
definition correction is applied; centre and joint mathematics are unchanged.
Root is a coauthor. No applied audit result, retained promotion, Lean certificate
or newly adopted physical primitive is claimed. Canonical/mechanical validation
and final publication disposition remain unrun by preparation.
""",
        "REVIEW_HISTORY.md": """# Source-bound review and pending conformance

The full reports, receipts and root coverage records are preserved. Mass
requires only the exact N36 weighted-Casimir correction. Centre and joint need
no mathematical source repair. Source/helper exposure, initial failures,
superseded drafts and mutation nondiscrimination remain explicit in the notes
and evidence. Hash checks do not substitute for these source reviews.

No conformance PASS is asserted by this preparation. Root must finish the
current spec's sections on the exact resulting bytes:

| Section | Prepared evidence and remaining action |
|---|---|
| 1 Self-containment | Exact source/dependency pins and portable paths prepared; inspect final closure. |
| 2 Cache/execution | Timeouts and assertion guards declared; canonical envelope runs and current caches pending. |
| 3 Scope | Conditional status and control limits retained; inspect every final surface. |
| 4 Negative scope | Original witnesses/stress tests preserved; assess applicable N-gate scope without inventing routes or a PASS. |
| 5 Proof | Full frozen proofs retained, sole N36 repair mapped; root final-source inspection pending. |
| 6 Runner validity | Original calculations and distinct reviewer controls preserved; actual canonical mutations/comparison pending. |
| 7 Packet | Full own evidence mapped; assess restricted-packet helper reachability if any output becomes load-bearing. |
| 8 Links/graph | File-level links and exact proof uses prepared; current graph build, edge inspection and manifest pending. |
| 9 Structure | Full status/trace fields supplied; final note check pending. |
| 10 Propose/ratify | No audit fields or authority edits are produced; check exact final file set. |
| 11 Facts/counts | Facts attributed to pinned source reports; fresh canonical results not invented. |
| 12 Final gates | Focused vocabulary/diff/syntax/readiness checks pending; combined pipeline and strict lint are landing gates. |

Do not turn an unrun section into a passed section. If source bytes change,
refresh the affected reconstruction, review, runner/cache and input bindings.
""",
        "HANDOFF.md": f"""# Frozen milestone handoff

Expected clean publication base: `{BASE}`.
Fixed deadline: {DEADLINE}; it is not extended.

Root reviews the complete note/primary transformations and executes the actual
canonical controls, source mutants and mechanical gates before recording a
regular milestone publication. SPECIFICATIONS.json supplies exact primary,
baseline, mutation, supplemental-control and dependency paths. The preparation
script does not run them, change Git state, write caches or publish anything.
Source and evidence identities are frozen in INPUT_INVENTORY and EVIDENCE_MAP.
The original N36 defect is preserved and mapped to its exact reviewed repair.

All application hypotheses and finite-control limits remain explicit. No
current conservation, regular-seed density, Fock/detector extension or actual
microscopic model is inferred beyond each theorem's conditions. This packet
is not a live checkpoint; the sole live campaign checkpoint stays in the
transport worktree. Editable prompt files changed: none.
""",
        "PR_BACKLOG.md": """# Publication actions pending root

No PR is created, updated, merged or claimed by preparation. Root is responsible
for the complete final-source read, exact canonical execution and mutation
comparison, cache creation through runner_cache, intended citation-graph
acknowledgment, focused conformance and regular milestone publication. Preserve
all failed checks and recoverable source versions. Global combined pipeline,
strict audit lint and changed-evidence readiness remain separate landing gates.
""",
        "DELIVERY_CHECKS.md": """# Actual delivery checks

Preparation has not executed any scientific primary, mutation, supplemental
control, runner-cache envelope, vocabulary rewrite, graph builder, audit pipeline
or audit lint. It has not created a PR or run independent science review.
The prepared payload is guarded by exact source/base checks and compile-only
syntax checks; root must record the actual execution and final conformance
results here. Historical author/reviewer executions remain source-bound in the
evidence map and must not be relabelled as fresh canonical executions.
""",
        "PREPARATION_LIMITATIONS.md": """# Mechanical preparation limits

Preparation reads and maps the complete notes, primary code and source reports.
It does not independently recertify their proofs or rerun their computations.
Current workflow/delivery/conformance and the prior centre/current packaging
pattern were inspected. The mechanical task explicitly forbids Git/ref actions;
no planning-branch fetch or publication action is performed by the preparer.
The executing root owns current planning/source freshness and final delivery.

The SOURCE_IDENTITIES manifest initially covers the prepared files only and
excludes itself. Root must regenerate or supplement it after adding fresh
verification evidence/caches or changing any prepared file. Exact publication
reconstruction must continue to pass; any later note/primary change needs an
explicit transformation and new hash. No source evidence is deleted.
""",
    }


def prepare_payload(inventory, frozen, inventory_bytes):
    specs = enrich_specs(frozen)
    payload = {}
    outputs = []
    for sp in specs:
        for data, row in [transform_note(sp, frozen), transform_primary(sp, frozen)]:
            need(row["publication_path"] not in payload, "Duplicate publication target")
            payload[row["publication_path"]] = data
            outputs.append(row)
    for name, text in packet_texts(specs).items():
        payload[PACKET + "/" + name] = text.encode()
    mapping = {"base_revision": BASE, "sole_mathematical_change": "Reviewed N36 weighted-Casimir definition", "outputs": outputs}
    payload[PACKET + "/PUBLICATION_EDITS.json"] = json_bytes(mapping)
    payload[PACKET + "/SPECIFICATIONS.json"] = json_bytes({"base_revision": BASE, "packet": PACKET, "specs": specs})
    payload[PACKET + "/reconstruct.py"] = RECONSTRUCT.encode()
    compile(RECONSTRUCT, "reconstruct.py", "exec")
    own = []
    external = []
    for entry in inventory["files"]:
        data = frozen[entry["original"]]
        if entry["classification"] == "external_primary_content":
            external.append(entry)
            continue
        preserved = entry["preserved"]
        compressed = gzip.compress(data, mtime=0)
        target = PACKET + "/" + preserved
        need(target not in payload, f"Duplicate preserved target: {target}")
        payload[target] = compressed
        own.append({"original": entry["original"], "preserved": preserved,
                    "bytes": len(data), "sha256": sha(data), "compressed_sha256": sha(compressed)})
    extras = [(Path(__file__), Path(__file__).read_bytes())]
    extras.extend((path, source_bytes(path)) for path in sorted(Q.rglob("*"))
                  if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store")
    for path, data in extras:
        preserved = "evidence/" + str(path.relative_to(S)) + ".gz"
        compressed = gzip.compress(data, mtime=0)
        need(PACKET + "/" + preserved not in payload, "Duplicate preparation evidence")
        payload[PACKET + "/" + preserved] = compressed
        own.append({"original": str(path), "preserved": preserved, "bytes": len(data),
                    "sha256": sha(data), "compressed_sha256": sha(compressed)})
    evidence = {
        "scope": "Complete own/repository evidence in the six frozen source bundles and the explicitly named root/procedure inputs; external paper bytes inventoried separately and left untouched.",
        "base_revision": BASE, "files": own, "external_reference_sources": inventory["external_reference_sources"],
        "external_files": external, "excluded_transient_files": inventory["excluded_transient_files"],
        "recovery": "Decompress each preserved file and verify its bytes/sha256; original absolute paths are provenance and are not required for canonical runner execution.",
    }
    payload[PACKET + "/EVIDENCE_MAP.json"] = json_bytes(evidence)
    payload[PACKET + "/EXTERNAL_SOURCE_INVENTORY.json"] = json_bytes({
        "policy": "No raw third-party PDF, TeX, source archive, rendered page or extracted paper content is bundled or deleted.",
        "sources": inventory["external_reference_sources"], "files": external,
    })
    # A preparation-time manifest only: later root verification files must be
    # included by the final publication manifest rather than silently omitted.
    identities = {"base_revision": BASE, "scope": "Exact prepared payload except this self-referential manifest; no fresh execution results or caches yet", "files": [
        {"path": path, "bytes": len(data), "sha256": sha(data)} for path, data in sorted(payload.items())]}
    payload[PACKET + "/SOURCE_IDENTITIES.json"] = json_bytes(identities)
    # Verify reconstruction in memory without importing or executing any code.
    for row in outputs:
        data = gzip.decompress(payload[PACKET + "/" + row["preserved_source"]])
        need(sha(data) == row["source_sha256"], "Preserved source mapping mismatch")
        text = data.decode()
        for edit in row["edits"]:
            need(text.count(edit["before"]) == 1, "Reconstruction edit is ambiguous")
            text = text.replace(edit["before"], edit["after"], 1)
        text += row["appended_text"]
        need(text.encode() == payload[row["publication_path"]], "In-memory reconstruction mismatch")
        need(sha(text.encode()) == row["publication_sha256"], "Publication hash mismatch")
    return payload, outputs, len(own), len(external)


def validate_targets(payload):
    for relative in payload:
        path = W / relative
        allowed = relative.startswith(PACKET + "/") or relative in {
            "docs/" + sp["prefix"] + "_BOUNDED_THEOREM_NOTE_2026-10-12.md" for sp in SPECS
        } or relative in {"scripts/" + sp["slug"] + "_2026_10_12.py" for sp in SPECS}
        need(allowed and ".." not in Path(relative).parts, f"Forbidden output: {relative}")
        need(not path.exists() and not path.is_symlink(), f"Refusing to overwrite existing path: {path}")
        parent = path.parent
        while parent != W:
            need(not parent.is_symlink(), f"Refusing symlink output parent: {parent}")
            parent = parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true", help="Validate and build payload in memory; write no worktree files")
    args = parser.parse_args()
    base_is_clean()
    inventory, frozen, inventory_bytes = inventory_and_sources()
    payload, outputs, own_count, external_count = prepare_payload(inventory, frozen, inventory_bytes)
    validate_targets(payload)
    # Refresh both base/cleanliness and every frozen input after building the
    # payload so concurrent publication cannot silently change its premises.
    base_is_clean()
    inventory_and_sources()
    validate_targets(payload)
    if not args.check_only:
        for relative, data in sorted(payload.items()):
            path = W / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as handle:
                handle.write(data)
    print(json.dumps({
        "mode": "check_only_no_files_written" if args.check_only else "prepared_new_files_only",
        "base_revision": BASE, "packet": str(P), "files": len(payload),
        "own_evidence_files": own_count, "external_files_inventoried_not_bundled": external_count,
        "outputs": [{k: row[k] for k in ("kind", "publication_path", "publication_sha256")} for row in outputs],
        "science_controls_run": False, "caches_written": False, "git_state_mutated": False,
        "pr_created_or_updated": False, "editable_prompt_files_changed": [],
    }, indent=2))


if __name__ == "__main__":
    main()
