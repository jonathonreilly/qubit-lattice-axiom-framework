"""Verify existing source-bound evidence; this is not a fresh science run."""
from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
A = S / 'microscopic_boost_flow'
R = S / 'microscopic_boost_flow_review'
records = {}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def walk(x):
    if isinstance(x, dict):
        if isinstance(x.get('path'), str) and 'sha256' in x:
            p = Path(x['path'])
            if p.is_absolute():
                assert p.is_file(), str(p)
                assert sha(p) == x['sha256'], str(p)
                if 'bytes' in x:
                    assert p.stat().st_size == x['bytes'], str(p)
                records[str(p)] = x['sha256']
        for v in x.values():
            walk(v)
    elif isinstance(x, list):
        for v in x:
            walk(v)

author = json.loads((A / 'receipt.json').read_text())
review = json.loads((R / 'receipt.json').read_text())
manifest = json.loads((R / 'source_manifest.final.json').read_text())
for j in [author, review, manifest]:
    walk(j)
for p, row in manifest['author_receipt_file_checks'].items():
    assert sha(Path(p)) == row['expected'] == row['actual'] and row['match'], p
    records[p] = row['expected']

runs = []
for entry in manifest['science_runs']:
    p = Path(entry['receipt']['path'])
    j = json.loads(p.read_text())
    walk(j)
    assert not j['timed_out'], str(p)
    assert j['sources_before'] == j['sources_after'], str(p)
    for source, digest in j['sources_before'].items():
        assert sha(Path(source)) == digest, source
    err = Path(j['streams']['stderr']['path']).read_bytes()
    assert not err, str(p)
    runs.append({k: j[k] for k in ['command', 'declared_timeout_seconds', 'elapsed_seconds', 'exit_code']})

out = []
replays = []
for mutation in ['none', 'drop_position', 'reverse_clock', 'drop_gns_right', 'reverse_current']:
    tag = 'canonical' if mutation == 'none' else mutation
    a = json.loads((A / f'finite_controls.final.{mutation}.json').read_text())
    r = json.loads((R / f'author.{tag}.json').read_text())
    differences = [k for k in a if a[k] != r[k]]
    assert differences == ['utc'], differences
    assert (A / f'logs/final.{mutation}.stdout').read_bytes() == (R / f'logs/author.{tag}.stdout').read_bytes()
    replays.append({'mutation': mutation, 'passed': a['passed'], 'failed': a['failed'], 'stdout_exact': True, 'json_difference_keys': differences})
    if mutation == 'none':
        baseline = a['rows']
        out += [{'source': 'author', 'mutation': mutation, 'row': row} for row in a['rows']]
    else:
        out += [{'source': 'author', 'mutation': mutation, 'row': row} for row, base in zip(a['rows'], baseline) if row != base]

for mutation in ['none', 'current_sign', 'drop_displacement', 'underpad', 'clock', 'drop_weight']:
    tag = 'canonical' if mutation == 'none' else mutation
    j = json.loads((R / f'independent.{tag}.json').read_text())
    assert j['source_sha256'] == sha(R / 'independent_controls.py')
    if mutation == 'none':
        independent_base = j['rows']
        out += [{'source': 'independent', 'mutation': mutation, 'row': row} for row in j['rows']]
    else:
        out += [{'source': 'independent', 'mutation': mutation, 'row': row} for row, base in zip(j['rows'], independent_base) if row != base]

for source in ['author', 'independent']:
    for mode in ['baseline', 'mutations']:
        rows = [x for x in out if x['source'] == source and ((x['mutation'] == 'none') == (mode == 'baseline'))]
        (S / f'Boost_root_{source}_{mode}.jsonl').write_text(''.join(json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n' for x in rows))

old = A / 'finite_controls.before_C1_refinement.py'
if not old.exists():
    matches = list(A.rglob('*before*C1*.py'))
    if len(matches) == 1:
        old = matches[0]
if old.exists():
    diff = ''.join(difflib.unified_diff(old.read_text().splitlines(True), (A/'finite_controls.py').read_text().splitlines(True), fromfile=str(old), tofile=str(A/'finite_controls.py')))
    (S / 'Boost_root_C1_source_change.diff').write_text(diff)

result = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'passed': True,
          'scope': 'Existing evidence provenance, complete source/helper reading recorded separately; no new execution or audit verdict.',
          'verified_unique_paths': len(records), 'author_replays': replays,
          'review_runs': runs, 'raw_compact_rows': len(out), 'C1_old_source': str(old) if old.exists() else None,
          'proof_read': {'author_lines': 758, 'review_lines': 119, 'reconstruction_lines': 57,
                         'author_helper_lines': 268, 'independent_helper_lines': 221,
                         'author_logger_lines': 63, 'review_logger_lines': 50, 'control_analysis_lines': 84},
          'remaining': ['Root read generated complete output rows and original NSY required theorem/proof', 'Repository publication checks pending']}
(S / 'Boost_root_evidence_verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['passed', 'verified_unique_paths', 'author_replays', 'raw_compact_rows', 'C1_old_source']}))
