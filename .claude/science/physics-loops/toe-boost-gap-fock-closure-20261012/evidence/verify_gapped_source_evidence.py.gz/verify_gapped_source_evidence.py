"""Verify frozen evidence and expose control values; no new theorem run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import difflib

S = Path(__file__).resolve().parent
A = S / 'gapped_boost_invariance'
R = S / 'gapped_boost_invariance_review'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

verified = {}
for packet in [A, R]:
    receipt = read(packet/'receipt.json')
    for item in receipt['files']:
        p = Path(item['path'])
        raw = p.read_bytes()
        assert sha(p) == item['sha256'], str(p)
        assert len(raw) == item['bytes'], str(p)
        if 'lines' in item:
            assert len(raw.splitlines()) == item['lines'], str(p)
        verified[str(p)] = item['sha256']

replays = []
all_rows = []
for variant in ['none', 'current_sign', 'current_half', 'global_scalar', 'degenerate_rank_one', 'one_sided']:
    target = A/'finite_controls_results.json' if variant == 'none' else A/f'mutations/final_{variant}.json'
    original = read(target)
    replay_dir = R/'author_replays'/variant
    replay = read(replay_dir/'result.json')
    assert original == replay, variant
    logname = 'final_baseline' if variant == 'none' else f'final_mutant_{variant}'
    assert (A/f'logs/{logname}.stdout').read_bytes() == (replay_dir/'stdout').read_bytes()
    execution = read(replay_dir/'execution.json')
    assert execution['status'] == 'completed'
    assert execution['source_sha256'] == sha(R/'author_replays/finite_controls.py') == sha(A/'finite_controls.py')
    assert execution['exit_code'] == int(variant != 'none')
    assert not (replay_dir/'stderr').read_bytes()
    replays.append({'variant': variant, 'passed': original['passed'], 'failed': original['failed'], 'elapsed': execution['elapsed_seconds'], 'timeout': execution['timeout_seconds'], 'exact_result_and_stdout': True})
    if variant == 'none':
        baseline = original['rows']
        assert all(r['ok'] for r in baseline)
        all_rows += [{'source': 'author', 'variant': variant, 'row': r} for r in baseline]
    else:
        all_rows += [{'source': 'author', 'variant': variant, 'row': r} for r, b in zip(original['rows'], baseline) if r != b]

independent = read(R/'independent_controls.result.json')
assert independent['source_sha256'] == sha(R/'independent_controls.py')
assert all(r['pass'] for r in independent['rows'])
all_rows += [{'source': 'independent', 'variant': 'none', 'row': r} for r in independent['rows']]
mutations = []
for variant in ['current_sign', 'current_half', 'global_scalar', 'rank_one_zero', 'one_column']:
    directory = R/'mutations'/variant
    execution = read(directory/'execution.json')
    code = (directory/'independent_controls.py').read_text()
    original_code = (R/'independent_controls.py').read_text()
    replacement = execution['replacement']
    assert original_code.count(replacement['old']) == 1
    assert original_code.replace(replacement['old'], replacement['new'], 1) == code
    assert sha(directory/'independent_controls.py') == execution['source_sha256']
    result = read(directory/'result.json')
    assert result['source_sha256'] == execution['source_sha256']
    assert execution['status'] == 'completed' and execution['exit_code'] == 1
    assert not (directory/'stderr').read_bytes()
    changed = [r for r,b in zip(result['rows'], independent['rows']) if r != b]
    failed = [r for r in result['rows'] if not r['pass']]
    mutations.append({'variant': variant, 'replacement': replacement, 'changed': len(changed), 'failed': len(failed), 'elapsed': execution['elapsed_seconds'], 'timeout': execution['timeout_seconds'], 'failed_labels': [r['label'] for r in failed]})
    all_rows += [{'source': 'independent', 'variant': variant, 'row': r} for r in changed]

diff = ''.join(difflib.unified_diff((A/'logs/initial.finite_controls.py').read_text().splitlines(True), (A/'finite_controls.py').read_text().splitlines(True), fromfile='author_initial', tofile='author_final'))
(S/'Gapped_root_control_correction.diff').write_text(diff)
(S/'Gapped_root_all_control_rows.jsonl').write_text(''.join(json.dumps(r, separators=(',', ':'), sort_keys=True)+'\n' for r in all_rows))
# Retain every value and label, but collect repetitive exact-zero identities.
zero_labels = {}
other = []
for record in all_rows:
    row = record['row']; key = record['source']+'/'+record['variant']
    exact_zero = (set(row) == {'name','ok','residual'} and row['ok'] and row['residual'] == '0') or (set(row) == {'label','pass','equal','difference'} and row['pass'] and row['equal'] and row['difference'] == [])
    if exact_zero:
        zero_labels.setdefault(key, []).append(row.get('name',row.get('label')))
    else:
        other.append(record)
compact = {'exact_zero_identity_labels': zero_labels, 'all_other_rows': other}
(S/'Gapped_root_control_rows_compact.json').write_text(json.dumps(compact,indent=2)+'\n')
result = {'utc': datetime.now(timezone.utc).isoformat(), 'passed': True, 'verified_unique_paths': len(verified), 'replays': replays, 'mutations': mutations, 'total_rows_preserved':len(all_rows), 'exact_zero_rows_grouped':sum(map(len,zero_labels.values())), 'other_rows':len(other), 'limitations':'Existing source-bound executions only; root is coauthor and this is not independent review or applied audit.'}
(S/'Gapped_root_evidence_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,separators=(',',':')))
