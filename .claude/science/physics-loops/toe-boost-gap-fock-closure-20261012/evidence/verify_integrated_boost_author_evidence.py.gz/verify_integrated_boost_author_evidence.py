"""Read-only integrity checks; preserve lossless author-control presentation."""
from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json
S=Path(__file__).resolve().parent;R=S/'integrated_boost_covariance'
sha=lambda b:hashlib.sha256(b).hexdigest();js=lambda p:json.loads(p.read_text())
bindings={}
def bind(p,h,size=None):
    p=Path(p).resolve();b=p.read_bytes();assert sha(b)==h,str(p)
    if size is not None:assert len(b)==size
    bindings[str(p)]=h
bind(S/'INTEGRATED_BOOST_COVARIANCE_PROBE.md','71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed')
bind(R/'receipt.json','043ca7931ff183f7446831c50583a3d9189e950842c68c244b4c3d5d30f1ba8b')
rec=js(R/'receipt.json');bind(R/'evidence_manifest.json',rec['evidence_manifest']['sha256'])
for r in js(R/'evidence_manifest.json')['files']:bind(R/r['path'],r['sha256'],r['bytes'])
for r in rec['source_recheck']['sources']:bind(r['path'],r['sha256'])
for k in ['final_note','frozen_copy','author_control_source']:
    r=rec[k];bind(r['path'],r['sha256'])
assert (S/'INTEGRATED_BOOST_COVARIANCE_PROBE.md').read_bytes()==(R/'FINAL_SOURCE.md').read_bytes()
old=(R/'history/controls.initial.py').read_text();new=(R/'controls.py').read_text()
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original',tofile='final'))
(S/'Integrated_boost_root_control_correction.diff').write_text(diff)
base=js(R/'final_baseline.json')
allrows=[];runs=[]
for name in ['baseline','reverse_boost','drop_beta','double_spatial_beta','forward_spectral_set','energy_phase']:
    final=js(R/('final_'+name+'.json'));original=js(R/(name+'.json'));assert final==original
    rows=final['rows'];assert len(rows)==71 and final['passed']==sum(r['pass'] for r in rows) and final['failed']==sum(not r['pass'] for r in rows)
    d=R/'logs'/('final_'+name);e=js(d/'receipt.json');old_d=R/'logs'/name
    for r in e['sources']:bind(r['path'],r['sha256'],r['bytes'])
    assert not e['timed_out'] and 0<e['elapsed_seconds']<e['timeout_seconds']
    assert e['timeout_seconds']==(60 if name=='baseline' else 30)
    assert e['exit_code']==(0 if name=='baseline' else 1)
    for stream in ['stdout','stderr']:
        b=(d/(stream+'.txt')).read_bytes();bind(d/(stream+'.txt'),e[stream+'_sha256'])
        assert b==(old_d/(stream+'.txt')).read_bytes()
    want=''.join(('PASS ' if r['pass'] else 'FAIL ')+r['name']+' '+json.dumps(r['details'])+'\n' for r in rows)+f"TOTAL: PASS={final['passed']} FAIL={final['failed']}\n"
    assert want==(d/'stdout.txt').read_text()
    if name=='baseline':
        allrows.append({'run':name,'rows':rows})
    else:
        changes=[]
        for a,b in zip(base['rows'],rows):
            assert a['name']==b['name']
            if a!=b:changes.append({'baseline':a,'variant':b})
        allrows.append({'run':name,'changed_rows':changes,'unchanged_rows':[r['name'] for a,r in zip(base['rows'],rows) if a==r],
                        'failed':final['failed']})
    runs.append({'name':name,'execution':e,'results_and_full_streams_reproduce_initial':True})
(S/'Integrated_boost_root_author_rows.json').write_text(json.dumps(allrows,indent=2)+'\n')
with (S/'Integrated_boost_root_author_rows.compact.txt').open('w') as f:
    for r in allrows:
        f.write('RUN '+r['run']+'\n')
        for a in r.get('rows',r.get('changed_rows',[])):f.write(json.dumps(a,separators=(',',':'))+'\n')
        if 'unchanged_rows' in r:f.write('UNCHANGED '+json.dumps(r['unchanged_rows'],separators=(',',':'))+'\n')
summary={'utc':datetime.now(timezone.utc).isoformat(),'bindings':bindings,'distinct_paths':len(bindings),'runs':runs,
 'controls':'Author variants are declared active CLI code paths; not separately edited whole-source mutations. Fresh reviewer materializations are a separate check.',
 'fresh_root_science_execution':False,'scope':'Source integrity, full preserved execution outputs and correction history; not proof certification.'}
(S/'Integrated_boost_root_author_evidence_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'distinct_paths':len(bindings),'runs':len(runs),'status':'verified'}))

