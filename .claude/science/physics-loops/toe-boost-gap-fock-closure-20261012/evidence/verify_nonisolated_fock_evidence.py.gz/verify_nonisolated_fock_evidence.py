"""Provenance and mutation comparison for existing frozen source reviews."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

S = Path(__file__).resolve().parent
A = S/'nonisolated_fock'
R = S/'nonisolated_fock_review'
seen = {}

def read(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def walk(obj, root):
    if isinstance(obj, dict):
        if 'path' in obj and 'sha256' in obj:
            p = Path(obj['path'])
            if not p.is_absolute():
                p = root/p
            raw = p.read_bytes()
            assert sha(p) == obj['sha256'], str(p)
            if 'bytes' in obj:
                assert len(raw) == obj['bytes'], str(p)
            seen[str(p)] = obj['sha256']
        for v in obj.values():
            walk(v, root)
    elif isinstance(obj, list):
        for v in obj:
            walk(v, root)

for p, root in [(A/'receipt.json',A),(R/'receipt.json',R),(R/'source_evidence_verification.json',R),(R/'FINAL_SOURCE_REFRESH.json',R)]:
    walk(read(p), root)

assert (A/'logs/controls_run1.stdout.jsonl').read_bytes() == (R/'author_reproduction.stdout.txt').read_bytes()
assert not (R/'author_reproduction.stderr.txt').read_bytes()
baseline = [json.loads(s) for s in (R/'author_reproduction.stdout.txt').read_text().splitlines()]
assert len(baseline)==7
mutations = read(R/'author_mutations.json')
code = (A/'check_fock_extension.py').read_text()
all_changes = []
summary = []

def changed(before, after, path=''):
    if before == after:
        return []
    if isinstance(before, dict) and isinstance(after, dict) and before.keys()==after.keys():
        return sum([changed(before[k],after[k],path+'/'+str(k)) for k in before],[])
    if isinstance(before,list) and isinstance(after,list) and len(before)==len(after):
        return sum([changed(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(before,after))],[])
    return [{'path':path,'before':before,'after':after}]

for case in mutations['cases']:
    p=R/'mutations'/f"{case['name']}.py"
    assert code.count(case['before']) == case['replacements']
    assert code.replace(case['before'],case['after']) == p.read_text(), case['name']
    assert sha(p) == case['source_sha256']
    walk(case,R)
    assert not case['timed_out'] and case['returncode'] in (0,1)
    out=Path(case['streams']['stdout']['path']).read_text()
    err=Path(case['streams']['stderr']['path']).read_text()
    rows=[json.loads(s) for s in out.splitlines()]
    if case['survived']:
        assert len(rows)==7 and not err
    else:
        assert 'AssertionError' in err
    diffs=changed(baseline,rows)
    all_changes.append({'name':case['name'],'survived':case['survived'],'changes':diffs,'stderr':err})
    summary.append({k:case[k] for k in ['name','returncode','survived','elapsed_seconds','timeout_seconds']})

executions={}
for name in ['author_reproduction','independent_run1','independent_run2']:
    executions[name]=read(R/f'{name}.execution.json')
    walk(executions[name],R)
assert (R/'independent_run2.stdout.txt').read_text().startswith((R/'independent_run1.stdout.txt').read_text())
source_sha = sha(R/'independent_matrix_control_optimized.py')
freeze=read(R/'independent_optimization_freeze.json')
assert freeze['new_sha256']==source_sha
assert freeze['old_sha256']==sha(R/'independent_matrix_control_run1.py')

(S/'Nonisolated_fock_root_mutation_changes.json').write_text(json.dumps(all_changes,indent=2)+'\n')
result={'utc':datetime.now(timezone.utc).isoformat(),'passed':True,'verified_unique_paths':len(seen),
        'mutation_summary':summary,'executions':executions,'author_stdout_exact':True,
        'independent_timeout_partial_prefix_preserved':True,
        'scope':'Existing source-bound evidence verified; no new science execution, no independent root review or audit verdict.'}
(S/'Nonisolated_fock_root_evidence_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':True,'verified_unique_paths':len(seen),'mutants_rejected':sum(not r['survived'] for r in summary),'mutants_survived':sum(r['survived'] for r in summary),'author_stdout_exact':True,'independent_partial_prefix_exact':True}))
