"""Read-only evidence verification and lossless row presentation; no science rerun."""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

S = Path(__file__).resolve().parent
R = S / 'weighted_current_closure_review'
A = S / 'weighted_current_closure'
bindings = {}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

def bind(p, expected, size=None):
    p = p.resolve()
    assert p.is_file() and sha(p) == expected, str(p)
    if size is not None:
        assert p.stat().st_size == size, str(p)
    bindings[str(p)] = expected

bind(S / 'WEIGHTED_CURRENT_CLOSURE_PROBE.md', '561cc0109580b74c42b19af27ab35801deea61a9c304dc2f43da772e042448f7')
bind(S / 'WEIGHTED_CURRENT_CLOSURE_REVIEW.md', '5796e74e9ad160de9d240d50a67b00a83dab51af25596f0c3d1f1bfcc1b3cc95')
bind(R / 'receipt.json', '8afb751ac3fac724d43fa5078ce37a6818e864053966ebc63be409ba3cc6fbb4')
rec = read(R / 'receipt.json')
bind(A / 'receipt.json', rec['author_receipt_sha256'])
for row in rec['evidence_files']:
    bind(R / row['path'], row['sha256'], row['bytes'])
for row in read(R / 'final_source_verification.json')['checks']:
    bind(Path(row['path']), row['sha256'])
for row in read(R / 'author_snapshot_manifest.json')['files']:
    bind(Path(row['path']), row['sha256'], row['bytes'])
    bind(R / row['snapshot'], row['sha256'], row['bytes'])
for row in read(R / 'dependencies_manifest.json'):
    bind(Path(row['path']), row['sha256'], row['bytes'])
    bind(R / row['snapshot'], row['sha256'], row['bytes'])
for row in rec['pre_helper_freeze']['files']:
    bind(R / row['path'], row['sha256'], row['bytes'])

ex = read(R / 'independent_run1/execution.json')
assert ex == rec['independent_run']
bind(R / 'independent_run1/independent_controls.py', ex['source_sha256'])
bind(R / 'independent_run1/stdout.jsonl', ex['stdout_sha256'])
bind(R / 'independent_run1/stderr.txt', ex['stderr_sha256'])
assert ex['exit_code'] == 0 and not ex['timed_out'] and ex['timeout_seconds'] == 60
assert 0 < ex['wall_seconds'] < ex['timeout_seconds']
data = read(R / 'independent_run1/results.json')
rows = data['rows']
assert len(rows) == data['total'] == 205
assert sum(not x['ok'] for x in rows) == data['failed'] == 0
output = [json.loads(t) for t in (R / 'independent_run1/stdout.jsonl').read_text().splitlines()]
assert output[:-1] == [{'name': x['name'], 'ok': x['ok']} for x in rows]
assert output[-1] == {'total': len(rows), 'failed': data['failed']}
zero_groups, other = {}, []
for row in rows:
    residual = row.get('residual')
    if residual is not None:
        encoded = json.dumps(residual['entries'], separators=(',', ':')).encode()
        assert hashlib.sha256(encoded).hexdigest() == residual['sha256']
        assert residual['nnz'] == len(residual['entries'])
    if residual is not None and residual['nnz'] == 0:
        key = json.dumps({k: v for k, v in row.items() if k != 'name'}, sort_keys=True)
        zero_groups.setdefault(key, []).append(row['name'])
    else:
        other.append(row)
compact = {'zero_groups': [{'common': json.loads(k), 'names': v} for k, v in zero_groups.items()],
           'other_rows': other, 'total': len(rows), 'lossless': True}
assert sum(len(v) for v in zero_groups.values()) + len(other) == len(rows)
(S / 'Weighted_current_root_review_rows_compact.json').write_text(json.dumps(compact, indent=2) + '\n')

replays = []
for item in rec['author_replays']:
    name = item['case']
    d = R / 'author_replays' / name
    e = read(d / 'execution.json')
    assert e['exit_code'] == item['exit_code'] and e['wall_seconds'] == item['wall_seconds']
    assert not e['timed_out'] and e['declared_timeout_seconds'] == 60
    assert 0 < e['wall_seconds'] < 60
    if name == 'original_failed_expectation':
        old = A / 'logs/run1'
    elif name in ('final_sparse', 'final_matrix'):
        old = A / 'logs' / name
    else:
        old = A / 'mutations' / name
    helper = 'matrix_controls.py' if name == 'final_matrix' else 'weighted_controls.py'
    result = 'matrix_results.json' if name == 'final_matrix' else 'weighted_results.json'
    bind(d / helper, item['source_sha256'])
    assert (d / helper).read_bytes() == (old / helper).read_bytes()
    for stream in ['stdout.jsonl', 'stderr.txt']:
        assert (d / stream).read_bytes() == (old / stream).read_bytes()
        key = 'stdout' if stream.startswith('stdout') else 'stderr'
        bind(d / stream, item[key + '_sha256'])
    actual, previous = read(d / result), read(old / result)
    actual.pop('created_utc'); previous.pop('created_utc')
    assert actual == previous
    failures = [r['name'] for r in actual['rows'] if not r['passed']]
    assert failures == item['failed_names']
    assert len(failures) == item['summary']['failed']
    replays.append({'case': name, 'elapsed_seconds': item['wall_seconds'], 'failed_names': failures,
                    'source_and_full_streams_exact': True, 'result_exact_except_created_utc': True})

result = {'checked_utc': datetime.now(timezone.utc).isoformat(), 'bindings': bindings,
          'distinct_paths': len(bindings), 'independent_execution': ex,
          'author_replays': replays, 'fresh_root_science_execution': False,
          'scope': 'Source integrity and complete preserved output comparison; not a proof or audit grade.'}
(S / 'Weighted_current_root_review_evidence_verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'distinct_paths': len(bindings), 'independent_rows': len(rows),
                  'zero_grouped_rows': sum(len(v) for v in zero_groups.values()), 'other_rows': len(other),
                  'byte_exact_author_replays': len(replays), 'status': 'verified'}))
