# Author source and control inspection

This is an author check, not an independent review or audit verdict. Root
supplied the moment-reduction candidate and is a contributor. No checker agent
was launched. The complete predecessor current/joint-flow arguments and their
source-bound reviews were read at the manifest identities.

The new note's complete 615-line argument was read after the proof, controls
and failure disclosures were assembled. Three local wording/formatting fixes
followed that read: the full weighted commutator, rather than an ambiguously
named reduction, is what has W17's covariance equivalence; W19 uses explicit
spacing commands; and the finite sign fixture is described as a 2-by-2 matrix
fixture. These changes do not alter the computation. The affected lines were
read again before freezing.

| Proof obligation | Author check and limit |
|---|---|
| Finite ordered Jacobi | Both nested derivatives use centers inside Y+B_(8R); the maximal elementary support bound is 7R. Nonzero final nested terms require overlap and at least one support meeting Y. |
| Density and conservation signs | r=delta_p(h), delta_r=[delta_p,delta_h], and the weighted commutator is W_b(r). The sign is not borrowed from the reversed density delta_h(p). |
| Finite weighted relabeling | Fixed-word translations meeting the local input form a finite set. The coefficient becomes s_O z_b minus m_(O,b). Conservation kills only the first term. |
| Orbit theorem | The full site commutant plus vanishing partial trace of K_z forces orbit sums zero. Trivial translation stabilizers give unique coefficient counting. |
| Representatives and primitives | Literal densities can change; their derivations agree. Coordinate paths construct finite primitives; summation by parts gives the bth primitive with positive sign. |
| Support, norm and scalar terms | t can use representatives inside B_(7R); displacement bounds are 14R. The coefficient norm bound is explicit. All scalar commutators vanish before summation. |
| Complete local test | A full one-site basis, translations and Leibniz give all local algebra. Fixed representatives give a finite polynomial criterion. |
| Beta and actual operators | The derivation target corresponds to [P,B]=-i beta H on the common local cyclic domain. GNS faithfulness and multiplication by arbitrary B, not vacuum separation, give the converse. No global-domain or integration conclusion is made. |
| XX application | Manual four-triple calculation gives r=4(f_1-f_-1+ell_0-ell_-2). Orbit moments give -8(f+ell). The ell orbit, and a separate padded matrix entry, prevent any scalar beta from closing this fixed density. |

The XX conclusion is only an evaluation of one exactly specified density with
beta in R. It does not assess a Hamiltonian family, all energy improvements,
all lattices, or a physical realization. No broad no-go is asserted. The
conditional construction is positive support for the next interaction-selection
gate; conservation and closure of an intended model remain unverified.

The complete final baseline rows were inspected: 73 sparse exact rows and 33
Gaussian-integer matrix rows. The five mutants have 26, 2, 1, 1 and 1 failed
rows, respectively. Full rows remain in JSON and stdout, including the many
nondiscriminating rows. The first incorrect expected-current sign is preserved
with the mathematical reason for its correction. No code was fitted to make
the XX closure condition pass; the result is failure for that model.

The matrix source imports no sparse helper. It constructs hopping and weighted
energy directly by occupation-bit transitions, forms P=i[H,B], and checks the
center-site actions with Gaussian-integer matrix products. Arithmetic guards
prevent int64 overflow. Both routes were written by the same author with the
proof and predicted XX expression visible. They provide arithmetic diversity,
not context independence or independent scientific review.

The source-search logs contain 27 and 241 matching lines, respectively, at the
selected main. Most hits concern statistical first moments, record-hazard
currents, continuum covariance or other algebraic settings. A few density/current
first-moment titles concern separate compressed few-particle constructions;
only their search context was inspected in this bounded task. No complete
read of those unrelated arguments, comprehensive prior-art coverage, or
literature novelty is claimed. The contribution is the finite reduction of
the specific gap named in the dispatch. The parent owns open-PR routing.

Output discipline: baseline scripts write repeatable default result JSON beside
the executed copy. The create-only orchestration helper protects the original
one-time evidence directories and is explicitly labeled as such in the note.
No canonical runner cache is used. All declared bounded subprocesses completed;
one initial metadata field mislabels its post-execution timestamp as a start,
and a sidecar preserves that limitation without changing the original record.

Independent review, optional formalization if a concrete risk warrants it,
repository integration and physical application remain outside this author
dispatch. Editable prompt files changed: none.
