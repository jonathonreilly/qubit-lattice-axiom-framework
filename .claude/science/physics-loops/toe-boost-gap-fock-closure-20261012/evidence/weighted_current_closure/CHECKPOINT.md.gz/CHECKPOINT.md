# Weighted current closure checkpoint

Author work started 2026-10-12 05:59 UTC. Fixed campaign deadline:
2026-10-12 16:00:52 UTC. Parent/root owns integration and publication.

Target: a necessary and sufficient finite local test for
`[delta_pj, delta_b] = beta delta_jb delta_h`, conditional on exact
`[delta_h, delta_pj] = 0`, for a specified finite-range spin density and its
canonical current. No physical realization or generic conservation is assumed.

Selected instruction authority: main a13caa4885f547c8d206265b031ba7649e539fd9,
planning 3a4b2c66a1ead7a1c48b4359627e968f681e3c39. Frozen source identities are
in source_manifest.json. The full prior current and joint-flow proofs and
their source reviews were read. The supplied a31a… receipt is the joint-flow
review receipt, not its author receipt.

Completed mechanism: finite padded Jacobi gives W_b(r), r=delta_pj(h).
Finite tensor-word orbit relabeling splits W_b(r) into an unweighted first
coefficient moment and a residual weighted orbit-sum density. Conservation
kills the latter. Changing representatives preserves the resulting derivation,
not necessarily the literal density. A divergence primitive gives the same
derivation by finite summation by parts. Complete one-site matrix tests then
decide the target.

Author obligations completed: full finite padding and support proof, exact
sign/beta/domain accounting, distinct exact controls (nonzero divergence,
nonconserved density, XX chain), actual source mutations and execution metadata,
and a complete final-source read. Independent review of this new argument is
pending and is owned by the parent. No new boost-flow or gap-invariance premise
is used. No Git/ref/index/repo/PR/audit/axiom/prompt change, other-chat message,
model override or subdelegation occurred.

Approach registry: (1) finite tensor-word coefficient moments, author proof
complete; (2) coordinate-path divergence and summation by parts, author
cross-check complete, sharing the orbit theorem; (3) finite occupation-basis
matrix checks, complete as an author arithmetic cross-check only. A purely formal infinite first moment
and inference from conservation to Lorentz closure are excluded shortcuts.
The conditional finite reduction is weaker than construction of an actual
Poincare model. Checking the derived finite criterion on the intended density
remains exactly its local closure obligation, not a derived physical premise.

Frozen deliverable: ../WEIGHTED_CURRENT_CLOSURE_PROBE.md, 615 lines, SHA-256
561cc0109580b74c42b19af27ab35801deea61a9c304dc2f43da772e042448f7.
Its current support is conditional-support / bounded_theorem. The density t
has radius at most 7R; the complete-basis criterion lives in B_(14R).
On the supplied common local cyclic domain the target corresponds to
[P_j,B_b]=-i beta delta_jb H, with one beta division for K=P/beta.

Concrete conserving application: XX h=f gives
r=4(f_1-f_-1+ell_0-ell_-2) and t equivalent to -8(f_0+ell_0).
The length-four ell orbit has coefficient -8 after any scalar beta-energy
subtraction. Thus this one fixed density fails closure for every real beta.
Other interactions and energy-density improvements are untested.

Final evidence: 73 exact sparse predicates and 33 exact matrix predicates,
all completed successfully. Five source mutants exited 1 with 26, 2, 1, 1,
and 1 failed predicates. The initial expected-current-sign mistake and its
failed 72/1 run are preserved, with its timestamp-label limitation. All
subprocesses had 60-second declared limits and completed without timeouts.
All 19 frozen predecessor/instruction source entries reverified unchanged.
The complete logs and receipt are the recovery surface; no external state
needs restoration.

Next decision: the parent should obtain a fresh proof review of the source at
the hash above, concentrating on finite weighted relabeling, representative/
primitive equivalence, complete-basis sufficiency and the XX residual. No
substantial downstream physical conclusion should treat author checks as that
review. The intended density's conservation and closure tests remain open.
