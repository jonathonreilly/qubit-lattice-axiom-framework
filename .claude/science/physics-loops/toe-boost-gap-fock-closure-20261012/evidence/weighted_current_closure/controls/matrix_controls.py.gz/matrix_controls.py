#!/usr/bin/env python3
"""Disjoint exact occupation-basis matrices. No import of sparse Pauli code.

All arithmetic uses Gaussian integer matrices with guarded int64 operations.
These are same-author cross-checks, not an independent scientific review.
"""
from pathlib import Path
import datetime,hashlib,json,sys
import numpy as np

ROWS=[];BOUNDS=[]
def check(name,passed,**detail):
    row=dict(name=name,passed=bool(passed),**detail);ROWS.append(row);print(json.dumps(row,sort_keys=True))
def zeros(n):return np.zeros((n,n),dtype=np.int64),np.zeros((n,n),dtype=np.int64)
def add(a,b):
    bound=maxabs(a)+maxabs(b);guard(bound)
    return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def sub(a,b):return add(a,neg(b))
def timesi(a):return -a[1],a[0]
def scale(a,c):guard(abs(c)*maxabs(a));return c*a[0],c*a[1]
def maxabs(a):return max(int(np.max(np.abs(a[0]))),int(np.max(np.abs(a[1]))))
def guard(bound):
    BOUNDS.append(int(bound))
    if bound>=2**60:raise OverflowError('exact integer guard exceeded')
def mul(a,b):
    guard(2*a[0].shape[0]*maxabs(a)*maxabs(b))
    return a[0]@b[0]-a[1]@b[1],a[0]@b[1]+a[1]@b[0]
def comm(a,b):return sub(mul(a,b),mul(b,a))
def zero(a):return not np.any(a[0]) and not np.any(a[1])
def eq(name,a,b):
    defect=sub(a,b);check(name,zero(defect),largest_entry=maxabs(defect),nonzero_entries=int(np.count_nonzero(defect[0])+np.count_nonzero(defect[1])))

def spin_bit(state,x,sites):return (state>>(sites-1-x))&1
def flip(state,x,sites):return state^(1<<(sites-1-x))
def site_matrix(axis,x,sites):
    out=zeros(2**sites)
    for state in range(2**sites):
        s=spin_bit(state,x,sites)
        if axis=='Z':out[0][state,state]=1-2*s
        elif axis=='X':out[0][flip(state,x,sites),state]=1
        elif axis=='Y':out[1][flip(state,x,sites),state]=1-2*s
        else:raise ValueError(axis)
    return out

def energy(kind,sites,origin):
    H=zeros(2**sites);B=zeros(2**sites)
    for state in range(2**sites):
        for x in range(sites-1):
            if kind=='XX':
                if spin_bit(state,x,sites)!=spin_bit(state,x+1,sites):
                    dest=flip(flip(state,x,sites),x+1,sites)
                    H[0][dest,state]+=2;B[0][dest,state]+=2*(x+origin)
            else:
                val=(1-2*spin_bit(state,x,sites))*(1-2*spin_bit(state,x+1,sites))
                H[0][state,state]+=val;B[0][state,state]+=(x+origin)*val
        if kind=='ZZ_plus_X':
            for x in range(sites):
                dest=flip(state,x,sites)
                H[0][dest,state]+=1;B[0][dest,state]+=x+origin
    return H,B

def XX_bulk_t(sites):
    T=zeros(2**sites)
    # -8 times (nearest hopping + distance-three Jordan-Wigner string).
    # Direct action: f/ell exchanges unequal endpoint occupations with
    # amplitude 2 times the parity of occupied intermediate sites.
    for state in range(2**sites):
        for distance in (1,3):
            for x in range(sites-distance):
                y=x+distance
                if spin_bit(state,x,sites)!=spin_bit(state,y,sites):
                    parity=sum(spin_bit(state,z,sites) for z in range(x+1,y))%2
                    dest=flip(flip(state,x,sites),y,sites)
                    T[0][dest,state]+=-16*(-1 if parity else 1)
    return T

def pauli_word_matrix(letters,sites):
    # Used solely to verify the fixed nonconserving four-term witness.
    M=(np.eye(2**sites,dtype=np.int64),np.zeros((2**sites,2**sites),dtype=np.int64))
    for x,l in letters.items():M=mul(M,site_matrix(l,x,sites))
    return M

def main():
    # Finite sign/normalization diagnostic only: H=2Z, B=Y, P=4X,
    # beta=-4. It is not an energy-conserving lattice realization.
    Hs=scale(site_matrix('Z',0,1),2);Bs=site_matrix('Y',0,1);Ps=scale(site_matrix('X',0,1),4);beta=-4
    eq('finite_sign_fixture_current',Ps,timesi(comm(Hs,Bs)))
    eq('finite_sign_fixture_t_betaH',timesi(comm(Ps,Bs)),scale(Hs,beta))
    eq('finite_operator_closure_sign',comm(Ps,Bs),scale(timesi(Hs),-beta))
    Ks=neg(site_matrix('X',0,1))
    eq('finite_single_beta_division',comm(Bs,Ks),timesi(Hs))
    check('finite_double_beta_is_detected',not zero(sub(timesi(comm(Ps,Bs)),scale(Hs,beta**2))))
    for axis in ('X','Y','Z'):
        As=site_matrix(axis,0,1)
        eq('finite_derivation_closure_sign_'+axis,neg(comm(comm(Ps,Bs),As)),scale(timesi(comm(Hs,As)),beta))
    n=7;center=3;H,B=energy('XX',n,-3);P=timesi(comm(H,B));T=timesi(comm(P,B));bulk=XX_bulk_t(n)
    check('XX_open_H_P_commutator_is_nonzero_boundary',not zero(comm(H,P)))
    check('XX_open_T_differs_from_bulk_at_boundary',not zero(sub(T,bulk)))
    for axis in ('X','Y','Z'):
        A=site_matrix(axis,center,n)
        C=neg(comm(comm(P,B),A))
        eq('XX_padded_matrix_moment_'+axis,C,timesi(comm(bulk,A)))
        check('XX_open_H_P_has_zero_interior_'+axis,zero(comm(comm(H,P),A)))
        for beta in (1,-8):
            residual=sub(C,scale(timesi(comm(H,A)),beta))
            check('XX_matrix_beta_'+str(beta)+'_fails_'+axis,not zero(residual),largest_entry=maxabs(residual))
    # Changing first-moment origin adds a multiple of H. The bulk action
    # is unchanged on padded locals because current conservation holds there.
    _,Bshift=energy('XX',n,2)
    Pshift=timesi(comm(H,Bshift))
    eq('XX_origin_does_not_change_finite_current',Pshift,P)
    for axis in ('X','Y','Z'):
        A=site_matrix(axis,center,n)
        eq('XX_weighted_origin_local_'+axis,neg(comm(comm(Pshift,Bshift),A)),neg(comm(comm(P,B),A)))
    # Nonconserving witness from complete local calculation, not expectation values.
    Hn,Bn=energy('ZZ_plus_X',n,-3);Pn=timesi(comm(Hn,Bn));Z=site_matrix('Z',center,n)
    exact=add(add(scale(pauli_word_matrix({center:'Y'},n),-8),scale(pauli_word_matrix({center-1:'Y',center:'X'},n),8)),add(scale(pauli_word_matrix({center:'X',center+1:'Y'},n),8),scale(pauli_word_matrix({center-1:'Z',center:'Y',center+1:'Z'},n),-8)))
    # [delta_H,delta_P](Z)=-[[H,P],Z].
    eq('nonconserved_exact_matrix_witness',neg(comm(comm(Hn,Pn),Z)),exact)
    check('nonconserved_matrix_witness_nonzero',not zero(exact),largest_entry=maxabs(exact))
    _,Bnshift=energy('ZZ_plus_X',n,2)
    Cn=neg(comm(comm(Pn,Bn),Z));Cnshift=neg(comm(comm(Pn,Bnshift),Z))
    eq('nonconserved_origin_residue',sub(Cnshift,Cn),scale(neg(comm(comm(Pn,Hn),Z)),5))
    check('nonconserved_origin_residue_nonzero',not zero(sub(Cnshift,Cn)))
    # Finite scalar divergence weighted sum has a genuine interior action.
    z=[site_matrix('Z',x,n) for x in range(n)];Q=zeros(2**n)
    for x in range(n-1):Q=add(Q,scale(sub(z[x],z[x+1]),x-3))
    Ztotal=zeros(2**n)
    for zz in z:Ztotal=add(Ztotal,zz)
    A=site_matrix('X',center,n)
    eq('nonzero_divergence_matrix_weighted_action',timesi(comm(Q,A)),timesi(comm(Ztotal,A)))
    check('nonzero_divergence_matrix_action_not_zero',not zero(comm(Q,A)))
    # Exact finite beta coefficient: use two linearly independent matrix
    # columns of the interior X action. The first enforces beta=-8; the
    # second has zero energy entry and nonzero weighted-current entry.
    A=site_matrix('X',center,n);C=neg(comm(comm(P,B),A));D=timesi(comm(H,A))
    witness=None;beta_entry=None
    for part in (0,1):
        for i in range(2**n):
            for j in range(2**n):
                if D[part][i,j] and beta_entry is None:
                    beta_entry=dict(part=part,row=i,column=j,current=int(C[part][i,j]),energy=int(D[part][i,j]))
                if D[part][i,j]==0 and C[part][i,j]!=0 and witness is None:
                    witness=dict(part=part,row=i,column=j,current=int(C[part][i,j]),energy=0)
    check('XX_exact_beta_independent_matrix_entry',witness is not None,witness=witness,beta_entry=beta_entry)
    out=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),python=sys.version,numpy=np.__version__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),integer_guard=2**60,largest_operation_bound=max(BOUNDS),rows=ROWS,summary=dict(passed=sum(x['passed'] for x in ROWS),failed=sum(not x['passed'] for x in ROWS)))
    Path(__file__).with_name('matrix_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('TOTAL: PASS='+str(out['summary']['passed'])+' FAIL='+str(out['summary']['failed']))
    return int(bool(out['summary']['failed']))
if __name__=='__main__':sys.exit(main())
