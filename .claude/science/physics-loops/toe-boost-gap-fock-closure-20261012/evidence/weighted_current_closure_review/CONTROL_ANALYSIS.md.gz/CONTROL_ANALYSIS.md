# Source and control analysis

The independent plan, reconstruction and control source were frozen before
opening the author helpers. The target note already disclosed the predicted
coefficients and control descriptions; this was not blind checking. The new
control imports SymPy, not any author code. Its source hash is
`8c17e5756dd50e890106583b4c2e3223f5da71093fe55b2d70304c4736eef471`.

## Independent calculation

The fixed XX model is checked through number-conserving quadratic CAR kernels
on an eleven-site open interval, coordinates -5 through 5. H and B are
assembled on the one-particle space, and P=i[H,B], T=i[P,B] are computed
there. Separately, exact four-site Jordan-Wigner matrices verify the CAR,
quadratic commutator lift, and the factor-two/sign maps for the nearest and
distance-three spin strings. This differs from both author implementations:
there is no sparse Pauli-word multiplication, orbit reducer, or direct
many-spin occupation-bit assembly of the XX Hamiltonian.

Clarification of the frozen reconstruction's Jordan-Wigner notation: every
product over sites to the left is taken **within a finite open interval with
a fixed left endpoint**. It does not define an infinite spin string as a local
observable. The even hopping bilinears have the displayed finite spin support;
the padded calculations stabilize as the finite interval grows. The Laurent
description records those stabilized local coefficients, not an infinite
Hamiltonian operator. No frozen source was changed to add this clarification.

The independent beta witness uses the local occupation n_0. In one-particle
coordinate entry (3,0), its energy action is zero while its weighted-current
action is -16i. Entry (1,0) has energy action 2i and weighted action -16i,
requiring beta=-8 without removing the former defect. This is a different
witness from the author's centre-X entry. The open energy-current commutator
has four nonzero boundary entries; its commutator with n_0 is zero. T likewise
has a four-entry boundary discrepancy from the bulk density, which disappears
on the centre action. A three-site cutoff already fails the nearest-hop action
comparison; it cannot certify the range-three term.

The orbit and representation controls use explicit 3-by-3 matrix units,
embedded by Kronecker products on three qutrit sites. A two-coordinate density
with orbit polynomial `3-z_1-2z_2` gives moment actions 1 and 2 times its
reference-word derivation. Replacing the representative by its translate
(2,-1), shifting the origin, adding scalars, and adding a two-coordinate curl
of primitives preserve exactly the claimed actions. Adding one reference word
introduces a nonzero augmentation: six of the tested direction/basis pairs
detect the weighted residue. Sixteen detect a reversed moment sign. Zero
actions cannot detect those mutations. The test is not an exhaustive n,d,R
verification; the proof gives the general implication.

The qutrit density diag(1,1,-2) commutes with a five-element tested subalgebra
but not with E_02. It demonstrates why a qubit-sized subset is insufficient
for a full M_3 factor. The independent control also covers an on-site energy
with zero current and nonzero energy action.

The first and only independent baseline completed 205 named finite predicates,
zero failed, exit 0, in 4.999260833 seconds with a declared 60-second timeout.
The count includes many matrix-unit and CAR checks of the same identities; it
does not count independent proofs. Every residual is stored in full exact
sparse-entry form in `independent_run1/results.json`. The parameter competitors
are explicit wrong-value comparisons, not claimed copied-source mutants.

## Author code and history

I read all 219 sparse-helper lines, 151 matrix-helper lines and 57 orchestration
lines, plus the full original-to-final differences and every final result row.
The original sparse source differs only in the manually typed expected XX
current (and its explanatory comment). Its original 72 successful/1 failed
result reproduces exactly; the failed row has coefficient l1 defect 8 and four
terms. The corrected expected sign agrees with both the direct commutator
calculation and the independent CAR/Jordan-Wigner calculation. The canonical
current routine, r, moment reduction, and computed artifact were not edited.

The final sparse reducer genuinely groups finite translation orbits and sums
their coefficients/moments. The primitive builder telescopes signed coordinate
steps. Scalar support is removed before a local translation sum. The helper's
complete-basis test is a qubit test; the note separately proves general M_n
sufficiency, and the reviewer qutrit controls challenge that extension. Exact
support-derived centre sets include harmless commuting terms but omit no
overlapping local term in these fixtures.

The matrix helper imports no sparse source. It computes H and B by bit
transitions, then bounded Gaussian-integer commutators. Its int64 operations
are guarded by valid upper bounds on each real/imaginary result component;
the largest recorded bound is 33,792, below 2^60. The fixed small initial
literal/increment constructions cannot overflow. Its expected XX bulk term
is hand-specified from the candidate, so agreement is not blind evidence;
the direct P/B construction and reviewer CAR route are the discriminators.

The first matrix source has exactly the final source's last 25 checks. The
only later source change adds eight sign/beta diagnostics. Their 2-by-2
fixture violates energy-current conservation and cannot certify the theorem's
model hypotheses. The note discloses that scope correctly.

## Every author source mutation and its limits

All five mutations are unique one-line changes to the same frozen sparse
baseline. Their actual sources, full diffs and every changed/passing row are
in `author_mutation_analysis.json`; all were executed from byte-identical
copies. Each exited 1, without timeout or unintended exception.

| Mutated step | Detected defect | What the surviving checks do not establish |
|---|---|---|
| Moment sign, -1 to +1 | 26 failures, including divergence moment/action, primitive comparison, XX moment and origin comparisons | 47 checks still succeed. Representative independence compares two equally sign-flipped reductions and survives. Zero Z actions, raw Jacobi, conservation, and rejection of the two tested betas survive. In the nonconserving fixture the tested moment contribution is zero, so that residue comparison does not detect this sign mutation. |
| Current half, 1/2 to 1 | Only two failures: explicit XX current and explicit reduced density coefficients | 71 checks succeed. The current, r, t and direct weighted bracket all double together, so their mutual identities and the quadratic/cubic rescaling tests still hold. XX conservation survives rescaling; both beta examples still fail. It is the independent coefficient anchors, not the mutual identities, that detect normalization. |
| Padding radius, 8 to 1 | The sole finite-padded-Jacobi row fails, with five terms and l1 defect 80 | 72 checks use support-derived centres or other routines and do not exercise PAD_RADIUS. This detects inadequate padding for this fixture; it neither proves general 8R sufficiency nor proves 8R sharpness. |
| Complete basis, X/Y/Z to Z only | `full_basis_rejects_Z_density` fails | 72 checks succeed. Already-zero densities remain zero, and the actual XX/nonconserved fixture has nonzero Z action. Direct loops over X/Y/Z are outside the mutated selector. This does not make every other full-basis predicate discriminatory. |
| Conservation guard disabled | The sole deliberate exception/rejection predicate fails | 72 checks succeed. The nonconserved diagnostic deliberately asks for `require_conserved=False` to test the exact residue identity, so it is unaffected. The guard is an API protection, not a derivation of conservation. The independent six nonzero qutrit residues challenge the mathematical reason for the protection. |

The original failed expectation, both final baselines and all five mutants
were replayed, eight executions total. Every stdout/stderr byte and every
result field except the new timestamp reproduced exactly. Final sparse and
matrix exits were 0; original expectation and mutant exits were 1. Every
execution used 60 seconds as its timeout, actual walls ranged from 0.087372 to
0.531921 seconds, and all stderr streams were empty. The historical matrix
first run and corrected run2 were not rerun: their differences/equality to
the final source and their source-bound saved results were inspected instead.
The create-only orchestration helper was read, not reexecuted over evidence.

The author's initial `started_utc` was actually recorded after execution.
Its original receipt and explanatory sidecar remain unchanged. Monotonic
elapsed time and timeout are recorded; the original true wall-clock start
is unavailable. The fresh replay records its own start before execution and
does not reconstruct that missing historical datum.

## Additional direct check of the nonconserving witness

For h_x=Z_x Z_(x+1)+X_x the canonical current has the same unweighted action
as p'_x=-2 Z_x Y_(x+1). Applying i[sum_y h_y,p'_x] directly gives
`q'_x=-4X_(x+1)-4Y_xY_(x+1)-4Z_xX_(x+1)Z_(x+2)+4Z_xZ_(x+1)`.
The onsite X_x term gives the YY contribution, X_(x+1) gives ZZ, and the
two overlapping ZZ bonds give X and ZXZ. Acting on Z_0 leaves respectively
`-8Y_0`, `8Y_-1 X_0+8X_0 Y_1`, `-8Z_-1 Y_0 Z_1`, and zero.
This independently checks W24's sign and four distinct words. It agrees with
the author's directly assembled matrix replay. No absence-of-conservation
claim is made outside this fixed example.

No author file was changed. Source hashes establish provenance, not the
scientific theorem. The proof reconstruction, exact controls and scope
analysis together support the source-bound conclusion.
