# Independent reconstruction before author helper inspection

Source: `WEIGHTED_CURRENT_CLOSURE_PROBE.md`, SHA256
`561cc0109580b74c42b19af27ab35801deea61a9c304dc2f43da772e042448f7`.
The whole note and both whole predecessor notes have been read. Prior reviews
were read as context, not proof. No author helper/result has yet been opened.
The frozen precheck plan discloses that the candidate's equations and described
outcomes were already visible. The following is a separate derivation, not a
blind prediction and not a formal proof certificate.

## Exact implication and dependency boundary

The algebra is the algebraic union of finite tensor products of a fixed full
matrix algebra over Z^d. A specified Hermitian h has support in B_R. Its energy,
first-moment, and canonical-current derivations are the finite local sums W2.
Fix ordered indices j,b. Exact conservation `[delta_h,delta_pj]=0` is supplied.
The conclusion is the unweighted density representative W13, and equivalence
of the beta-energy identity with every operator test on a complete one-site
basis. The stated representation corollary additionally supplies actual
self-adjoint operators with the exact common-local-domain action W20.

The needed predecessor material is finite pair symmetrization I1-I13 and the
finite orbit kernel description J15-J20. They are reconstructed below. The
analytic joint-flow and implementation theorems, scattering statements, gap,
positivity, and physical identifications are not needed for this implication.

## Finite Jacobi and sign

For bounded finite sums, `[i ad P,i ad B]=-ad[P,B]=i ad(i[P,B])`.
With B=sum_x x_b h_x, the coefficient of x_b is
`r_j(x)=i sum_y[p_j(y),h_x]`. Thus `[delta_pj,delta_b]=W_b(r_j)` and the
unweighted version is `[delta_pj,delta_h]=delta_rj`, with the displayed order.
For the canonical current, interchange the two orientations in `[H,B]`:
its coefficient is `(y_b-x_b)/2`, so W2's i/2 is correct and occurs once.

All these manipulations can take place on one finite center set. If h_x and
p_y overlap, |x-y|<=R+3R=4R. If h_x meets Y, x is within R and y within 5R
of Y. If p_y meets Y, y is within 3R and x within 7R. If neither meets Y,
both commute with A and their nested commutator does also. The common center
set Y+B_(8R) therefore contains all potentially nonzero terms. This is padding
for local actions, not equality of finite Hamiltonians at the boundary.

p has support within B_(3R); its norm is at most
`h_*^2 sum_(|v|<=2R)|v_j|`. The terms in r have centers y in B_(4R) and each
p support lies in y+B_(3R), hence support B_(7R) and norm at most
`2 |B_(4R)| h_*^3 c_(R,j)`. Hermiticity follows because i times the
commutator of Hermitian matrices is Hermitian; its product trace is zero.

## Free translation module and augmentation

Fix a trace-orthonormal Hermitian basis with identity as its sole nontraceless
member. A nonidentity finite tensor word has trivial lattice stabilizer:
if a nonzero translation preserved its finite support, iterating it would
produce infinitely many support sites. Thus each orbit is a free copy of the
Laurent-polynomial module R[z_1^+-1,...,z_d^+-1]. Write its component as
`f_O(tau) w_O`, where `f_O(z)=sum_v c_(O,v) z^v` is finite.

The unweighted derivation depends only on augmentation `f_O(1)` because a
translated density has the same unweighted local action. This proves that all
augmentations zero is sufficient. For necessity, collect the finite operator
K_z made from translated words with a nonidentity factor at site z. Its
coefficient for any given word is exactly f_O(1), since its translation is
unique. A zero derivation makes K_z commute with the full site factor. Inside
its finite tensor algebra that commutant is identity at z tensored with the
other sites. Yet the partial trace at z is zero, so K_z=0. Independence of
the finite tensor basis and choosing z in every nonempty support prove all
augmentations vanish. No scalar infinite sum is ever formed.

Now put `D_b f=(z_b partial_(z_b) f)`. In the weighted action, shifting the
center by v replaces its weight x_b by z_b-v_b (the z here is a lattice
coordinate, not a Laurent variable). The resulting orbit contribution is
`f_O(1) W_b(w_O) - (D_b f_O)(1) delta_(w_O)`.
Therefore the exact correction is negative first moment, with no extra i,
half, or beta. Conservation sets each f_O(1)=0 and removes precisely the
weighted residue. It does not set r_j itself equal to zero.

If the representative is changed to tau_u w, its polynomial is z^-u f.
The product rule gives `D_b(z^-u f)(1)=D_b f(1)-u_b f(1)`. Under zero
augmentation the coefficient is unchanged, while the representative is
translated. The density changes but its derivation does not. Without zero
augmentation the altered weighted-residue and moment terms cancel; omitting
the former is invalid. A different Hermitian local basis also produces an
unweighted density with the same derivation by this identity; the proof does
not assert uniqueness of its literal coefficients.

## Primitive ambiguity and support

The augmentation ideal is generated by `(1-z_a)`: each monomial difference
`z^v-1` telescopes along a finite coordinate path. This supplies Hermitian
finite primitives when orbit sums vanish. Discrete summation by parts gives
`W_b((1-tau_ea) a)=delta_ab delta_a`. Therefore each bth primitive realizes
the same unweighted derivation as the moment density. Two primitive lists
with equal divergence have bth differences of zero derivation. Scalar and
finite curl changes are included; this is no unique stress-tensor claim.

Choose each representative among words supported in B_L, L=7R. The moment
density then stays in B_L. If both w and tau_v w occur in B_L, any fixed
support site s has s and s+v in B_L; hence |v|<=2L. Triangle inequality gives
`||t_b||<=2L sum_(O,v)|c_(O,v)| ||w_O||`. A coordinate-monotone path to v
has every intermediate |u|<=|v|, so the telescoped primitive lies in B_(3L).
No use of this larger primitive radius is required by the local test.
Assigning t_x to x+B_L gives diameter 2L, at most |B_L| sites and per-site
interaction norm <=|B_L| ||t||, including R=L=0.

## Complete local test and degenerate cases

For k=t-beta delta_jb h with support in B_L, only centers in B_L can act on
site zero; their supports are in B_(2L). Zero action on a complete matrix
basis is zero action on the whole site algebra. Translation invariance of
delta_k gives all sites, and the derivation product rule gives every finite
tensor product. This proves sufficiency; necessity is restriction. A partial
basis, expectation, or vacuum vector cannot replace the full operator test.

In a preselected finite tensor basis, p is quadratic and r/t cubic in h,
so the exact local conditions are polynomial in h and beta. If delta_h is
nonzero, any diagonal equality determines beta by one nonzero action
coefficient, and every remaining coefficient/direction must satisfy the same
value. Positivity is an additional inequality. Scaling h by nonzero lambda
and adding a scalar scales the three relevant actions by lambda, lambda^2,
lambda^3, hence beta by lambda^2. If delta_h=0, pair symmetrization gives
delta_p=0 and r=0. If R=0, p=t=0 even when the on-site energy acts; diagonal
closure then forces beta=0. Density improvements are not invariant because
their weighted action can survive although their unweighted action vanishes.

The translation law follows either from direct weighting or from Jacobi:
`tau_a C tau_-a=C-a_b delta_r=C+a_b[delta_h,delta_p]`.
Consequently this particular C is translation covariant iff the conservation
defect vanishes, since b is a genuine coordinate and a=e_b is available.

## Actual-operator corollary

Write V(A)=pi(A)Omega. W20 says G V(A)=-i V(delta_G A).
At A=1 every G annihilates Omega. Locality makes D invariant, so PB and BP
are both defined there. Thus `[P,B]V(A)=-V([delta_p,delta_b]A)`.
Closure gives `-beta V(delta_h A)=-i beta H V(A)`, agreeing with W22.
For the converse, W20/W22 make the derivation C annihilate every vacuum
column. Applying it to AB gives `pi(C(A))pi(B)Omega=0`; cyclicity forces this
bounded operator to be zero. A nonzero unital representation of a local full
matrix algebra is injective, so C(A)=0. No separating vector or full-domain
commutator identity is assumed. Dividing P by beta divides the negative clock
derivative by beta exactly once. The hypotheses do not construct the operators
or integrate the Lie algebra.

## Independent CAR check of the XX formula

Take `c_x=(product_(y<x) Z_y)(X_x+iY_x)/2`. Direct two-site multiplication
gives `f_x=2(c_x^*c_(x+1)+c_(x+1)^*c_x)` and similarly the four-site word
ell_x is twice the hopping of length three. Number-conserving quadratic
operators obey `[dGamma(A),dGamma(B)]=dGamma([A,B])`, by the CAR; their map
is injective because its restriction to the one-particle sector is A.

For one-particle matrices use H_(x,x+1)=2 and B_(x,x+1)=2x plus Hermitian
conjugates. In the interior, `P=i[H,B]` has P_(x,x+2)=4i and its conjugate
entry -4i. Hence H and P are commuting Laurent shift polynomials in the
infinite chain; an open cutoff retains only boundary defects. Evaluating
`i[P,h_0]` gives coefficients -8 on (-2,1) and (-1,0), and +8 on (1,2) and
(0,3), together with conjugates. This is exactly
`4(f_1-f_-1+ell_0-ell_-2)` under the verified factor-two map.

In `i[P,B]`, the interior hopping coefficients at distances one and three
are both -16. The latter calculation is
`i[(4i)2(x+2)-(2x)(4i)]=-16`; the distance-one difference gives the same
answer. Thus the spin density has action of `-8(f_0+ell_0)`. For any beta,
the distance-three coefficient of T-beta H stays -16, so it cannot have
zero derivation: its commutator with the local number n_0 already detects
that hopping. This is a different beta-independent witness from the author's
center-X matrix entry. It concerns this exact fixed density only.

The finite implementation to follow will check these CAR identities, boundary
behavior, direct elementary-matrix orbit actions, and deliberately wrong
sign/normalization/completeness/residue/padding variants. Finite execution
cannot establish the theorem or any physical realization by itself.
