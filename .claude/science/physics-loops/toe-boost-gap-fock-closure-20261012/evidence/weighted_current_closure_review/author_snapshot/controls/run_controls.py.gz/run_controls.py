#!/usr/bin/env python3
"""Source-bound bounded executions. All outputs, including failures, persist."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(source,destination,result_file,timeout=60):
    destination.mkdir(parents=True,exist_ok=False)
    target=destination/source.name
    target.write_bytes(source.read_bytes())
    return execute(target,destination,result_file,timeout)
def execute(target,destination,result_file,timeout=60):
    cmd=[sys.executable,str(target)];start=time.monotonic()
    meta=dict(command=cmd,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=sha(target),declared_timeout_seconds=timeout)
    try:
        process=subprocess.run(cmd,capture_output=True,timeout=timeout)
        stdout,stderr=process.stdout,process.stderr
        meta.update(exit_code=process.returncode,timed_out=False)
    except subprocess.TimeoutExpired as exc:
        stdout,stderr=exc.stdout or b'',exc.stderr or b''
        meta.update(exit_code=None,timed_out=True)
    meta['elapsed_seconds']=time.monotonic()-start
    (destination/'stdout.jsonl').write_bytes(stdout);(destination/'stderr.txt').write_bytes(stderr)
    result=destination/result_file
    if result.exists():
        data=json.loads(result.read_text());meta['summary']=data['summary']
        meta['failed_names']=[row['name'] for row in data['rows'] if not row['passed']]
        meta['result_sha256']=sha(result)
    meta['stdout_sha256']=hashlib.sha256(stdout).hexdigest();meta['stderr_sha256']=hashlib.sha256(stderr).hexdigest()
    (destination/'execution.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
    return meta

def main():
    source=ROOT/'controls/weighted_controls.py';matrix=ROOT/'controls/matrix_controls.py'
    baseline=run(source,ROOT/'logs/final_sparse','weighted_results.json')
    matrix_result=run(matrix,ROOT/'logs/final_matrix','matrix_results.json')
    mutations=[
        ('moment_sign','MOMENT_SIGN = -1','MOMENT_SIGN = 1'),
        ('current_half','CURRENT_FACTOR = F(1, 2)','CURRENT_FACTOR = F(1, 1)'),
        ('insufficient_padding','PAD_RADIUS = 8','PAD_RADIUS = 1'),
        ('incomplete_basis',"TEST_AXES = ('X', 'Y', 'Z')","TEST_AXES = ('Z',)"),
        ('ignore_conservation','IGNORE_ORBIT_SUM = False','IGNORE_ORBIT_SUM = True'),
    ]
    results=[]
    for name,old,new in mutations:
        directory=ROOT/'mutations'/name;directory.mkdir(exist_ok=False)
        text=source.read_text()
        if text.count(old)!=1:raise RuntimeError('mutation is not unique: '+name)
        target=directory/source.name;target.write_text(text.replace(old,new,1))
        (directory/'mutation.json').write_text(json.dumps(dict(name=name,old=old,new=new,baseline_sha256=sha(source),mutated_sha256=sha(target)),indent=2)+'\n')
        result=execute(target,directory,'weighted_results.json');result['mutation']=name;results.append(result)
    output=dict(baseline=baseline,matrix=matrix_result,mutations=results,driver_sha256=sha(Path(__file__)))
    (ROOT/'logs/final_execution_summary.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
    print(json.dumps(output,indent=2,sort_keys=True))
    return int(baseline.get('exit_code')!=0 or matrix_result.get('exit_code')!=0 or any(r.get('exit_code')!=1 for r in results))
if __name__=='__main__':sys.exit(main())
