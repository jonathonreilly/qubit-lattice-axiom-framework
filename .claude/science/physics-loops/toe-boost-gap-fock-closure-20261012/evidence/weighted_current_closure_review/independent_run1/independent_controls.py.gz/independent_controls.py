#!/usr/bin/env python3
"""Independent exact controls: CAR hopping kernels and qutrit matrix units.

No author helper, fixture, result, or Pauli-word arithmetic is imported.
All matrix operations are SymPy exact rational/Gaussian-rational operations.
The surrounding execution harness records wall time, timeout and stream hashes.
"""
from pathlib import Path
import hashlib
import json
import sys
import sympy as s

I = s.I
rows = []


def digest_matrix(a):
    a = s.SparseMatrix(a)
    entries = [[int(i), int(j), str(v)] for (i, j), v in sorted(a.todok().items()) if v != 0]
    return {"shape": list(a.shape), "nnz": len(entries), "entries": entries,
            "sha256": hashlib.sha256(json.dumps(entries, separators=(",", ":")).encode()).hexdigest()}


def check(name, condition, **evidence):
    row = {"name": name, "ok": bool(condition), **evidence}
    rows.append(row)
    print(json.dumps({"name": name, "ok": row["ok"]}), flush=True)


def eq(name, a, b):
    residual = s.SparseMatrix(a - b)
    check(name, residual == s.zeros(*residual.shape), residual=digest_matrix(residual))


def ne(name, a, b):
    residual = s.SparseMatrix(a - b)
    check(name, residual != s.zeros(*residual.shape), residual=digest_matrix(residual))


def comm(a, b):
    return a * b - b * a


def unit(n, a, b):
    return s.SparseMatrix(n, n, {(a, b): 1})


def tensor(mats):
    result = s.SparseMatrix([[1]])
    for mat in mats:
        result = s.SparseMatrix(s.kronecker_product(result, mat))
    return result


# CAR: a one-particle quadratic kernel determines the whole number-conserving
# quadratic observable, as its restriction to the one-particle sector is itself.
coords = list(range(-5, 6))
n = len(coords)
idx = {x: i for i, x in enumerate(coords)}


def edge(a, b):
    if a not in idx or b not in idx:
        return s.zeros(n)
    return 2 * (unit(n, idx[a], idx[b]) + unit(n, idx[b], idx[a]))


bonds = {x: edge(x, x + 1) for x in coords[:-1]}
H = sum(bonds.values(), s.zeros(n))
B = sum((x * q for x, q in bonds.items()), s.zeros(n))
P = I * comm(H, B)
P_oriented = sum((I * comm(bonds[x], bonds[x + 1]) for x in coords[:-2]), s.zeros(n))
P_double = sum((I * (y - x) * comm(hx, hy) / 2
                for x, hx in bonds.items() for y, hy in bonds.items()), s.zeros(n))
eq("CAR finite canonical pair half", P, P_double)
eq("CAR once-oriented adjacent pair current", P, P_oriented)
ne("CAR reversed-current mutation rejected", P, -P_double)
ne("CAR omitted-half mutation rejected", P, 2 * P_double)

P_expected = sum((4 * I * (unit(n, idx[x], idx[x + 2]) - unit(n, idx[x + 2], idx[x]))
                  for x in coords[:-2]), s.zeros(n))
eq("CAR derived second-neighbor kernel", P, P_expected)
r = I * comm(P, bonds[0])
r_formula = 4 * (edge(1, 2) - edge(-1, 0) + edge(0, 3) - edge(-2, 1))
eq("CAR XX r density from quadratic brackets", r, r_formula)
T = I * comm(P, B)
T_bulk = -8 * sum((edge(x, x + 1) for x in coords[:-1]), s.zeros(n))
T_bulk += -8 * sum((edge(x, x + 3) for x in coords[:-3]), s.zeros(n))
n0 = unit(n, idx[0], idx[0])
eq("CAR XX bulk weighted closure action", I * comm(T, n0), I * comm(T_bulk, n0))
ne("CAR open weighted operator has boundary discrepancy", T, T_bulk)
ne("CAR open energy-current commutator nonzero", comm(H, P), s.zeros(n))
eq("CAR open conservation defect annihilates center number action", comm(comm(H, P), n0), s.zeros(n))
eq("CAR direct nested derivation on center number", -comm(comm(P, B), n0), I * comm(T_bulk, n0))

energy_action = I * comm(H, n0)
boost_action = I * comm(T, n0)
row, col = idx[3], idx[0]
check("CAR beta-independent distance-three witness", energy_action[row, col] == 0 and boost_action[row, col] != 0,
      coordinate_entry=[3, 0], energy=str(energy_action[row, col]), weighted=str(boost_action[row, col]))
row, col = idx[1], idx[0]
check("CAR nearest-hop beta is minus eight", boost_action[row, col] / energy_action[row, col] == -8,
      coordinate_entry=[1, 0], energy=str(energy_action[row, col]), weighted=str(boost_action[row, col]))
for beta in [s.Integer(-8), s.Integer(0), s.Rational(3, 2)]:
    ne("CAR tested beta rejected " + str(beta), boost_action, beta * energy_action)

# Too-small open kernel cutoff removes the distance-three witness.
keep = [idx[x] for x in [-1, 0, 1]]
Hsmall = H.extract(keep, keep)
Bsmall = B.extract(keep, keep)
Tsmall = I * comm(I * comm(Hsmall, Bsmall), Bsmall)
bulk_nearest = T_bulk.extract(keep, keep)
ne("CAR inadequate-padding mutation detected already on nearest hop", I * comm(Tsmall, unit(3, 1, 1)),
   I * comm(bulk_nearest, unit(3, 1, 1)))

# Verify the CAR-to-spin map independently on four sites by elementary matrices.
e = s.eye(2)
X = s.Matrix([[0, 1], [1, 0]])
Y = s.Matrix([[0, -I], [I, 0]])
Z = s.diag(1, -1)
ann = s.Matrix([[0, 1], [0, 0]])
c = [tensor([Z if k < j else ann if k == j else e for k in range(4)]) for j in range(4)]
for j in range(4):
    for k in range(4):
        eq(f"CAR anticommutator annihilation {j} {k}", c[j] * c[k] + c[k] * c[j], s.zeros(16))
        eq(f"CAR anticommutator mixed {j} {k}", c[j] * c[k].H + c[k].H * c[j], s.eye(16) if j == k else s.zeros(16))
eq("Jordan-Wigner nearest word factor two", 2 * (c[0].H * c[1] + c[1].H * c[0]),
   tensor([X, X, e, e]) + tensor([Y, Y, e, e]))
eq("Jordan-Wigner distance-three word factor two", 2 * (c[0].H * c[3] + c[3].H * c[0]),
   tensor([X, Z, Z, X]) + tensor([Y, Z, Z, Y]))
eq("Jordan-Wigner oriented-current sign", 2 * I * (c[0].H * c[2] - c[2].H * c[0]),
   tensor([Y, Z, X, e]) - tensor([X, Z, Y, e]))

kernel_a = s.Matrix([[1, I, 0, 0], [-I, -1, 2, 0], [0, 2, 0, 1], [0, 0, 1, 0]])
kernel_b = s.Matrix([[0, 0, 1, 0], [0, 2, 0, I], [1, 0, -2, 0], [0, -I, 0, 1]])


def dgamma(a):
    return sum((a[j, k] * c[j].H * c[k] for j in range(4) for k in range(4) if a[j, k]), s.zeros(16))


eq("CAR quadratic commutator lift", comm(dgamma(kernel_a), dgamma(kernel_b)), dgamma(comm(kernel_a, kernel_b)))

# Independent qutrit local action: terms are explicit tensor products of 3x3
# matrices, embedded and multiplied as full matrices. No tensor-word reducer.
A = unit(3, 0, 1) + unit(3, 1, 0)
D = s.diag(1, -1, 0)
ambient = [(-1, 0), (0, 0), (1, 0)]
origin = (0, 0)
one = [(s.Integer(1), {origin: A})]
word = [(s.Integer(1), {origin: A, (1, 0): D})]


def shifted(terms, v):
    return [(a, {(p[0] + v[0], p[1] + v[1]): m for p, m in factors.items()}) for a, factors in terms]


def scaled(terms, q):
    return [(q * a, factors) for a, factors in terms]


def local_action(terms, probe, direction=None, at=origin):
    total = s.zeros(27)
    probe_matrix = tensor([probe if p == origin else s.eye(3) for p in ambient])
    for coeff, factors in terms:
        for support_site in factors:
            center = (at[0] - support_site[0], at[1] - support_site[1])
            placed = {(p[0] + center[0] - at[0], p[1] + center[1] - at[1]): m for p, m in factors.items()}
            if not set(placed).issubset(ambient):
                raise ValueError("independent fixture ambient does not cover support")
            term = tensor([placed.get(p, s.eye(3)) for p in ambient])
            weight = 1 if direction is None else center[direction]
            total += I * coeff * weight * comm(term, probe_matrix)
    return s.SparseMatrix(total)


translations = [((0, 0), 3), ((1, 0), -1), ((0, 1), -2)]
q = sum((scaled(shifted(word, v), a) for v, a in translations), [])
q_nonzero = q + word
vnew = (2, -1)
representative = shifted(word, vnew)
z1, z2 = s.symbols("z1 z2", nonzero=True)
f = 3 - z1 - 2 * z2
fnew = z1 ** -2 * z2 * f
check("Laurent augmentation and two moments", f.subs({z1: 1, z2: 1}) == 0 and
      s.diff(f, z1).subs({z1: 1, z2: 1}) == -1 and s.diff(f, z2).subs({z1: 1, z2: 1}) == -2,
      polynomial=str(f))
for b, z in enumerate([z1, z2]):
    old = (z * s.diff(f, z)).subs({z1: 1, z2: 1})
    new = (z * s.diff(fnew, z)).subs({z1: 1, z2: 1})
    check(f"Laurent representative transformation coordinate {b}", old == new, old=str(old), new=str(new))

wrong_moment_nonzero = 0
weighted_residue_nonzero = 0
for i in range(3):
    for j in range(3):
        E = unit(3, i, j)
        eq(f"M3 two-dimensional divergence on E{i}{j}", local_action(q, E), s.zeros(27))
        for b, m in enumerate([1, 2]):
            actual = local_action(q, E, b)
            expected = local_action(scaled(word, m), E)
            eq(f"M3 orbit moment coordinate {b} E{i}{j}", actual, expected)
            eq(f"M3 representative invariance coordinate {b} E{i}{j}", actual,
               local_action(scaled(representative, m), E))
            if actual != -expected:
                wrong_moment_nonzero += 1
            residual = local_action(q_nonzero, E, b) - expected
            eq(f"M3 exact nonconserved residue coordinate {b} E{i}{j}", residual, local_action(word, E, b))
            if residual != s.zeros(27):
                weighted_residue_nonzero += 1
            for displacement in [(2, -3), (-1, 1)]:
                eq(f"M3 origin translation coordinate {b} E{i}{j} at {displacement}",
                   local_action(q_nonzero, E, b, displacement),
                   local_action(q_nonzero, E, b) + displacement[b] * local_action(q_nonzero, E))
check("M3 wrong moment sign has discriminating probes", wrong_moment_nonzero > 0, detected=wrong_moment_nonzero)
check("M3 dropped residue has discriminating probes", weighted_residue_nonzero > 0, detected=weighted_residue_nonzero)

# A scalar density has empty support; the local commutator is zero before
# any translation sum. Primitive curl uses actual two-coordinate differences.
scalar = [(s.Integer(7), {})]
a1 = one + scaled(shifted(one, (0, 1)), -1)
a2 = shifted(one, (1, 0)) + scaled(one, -1)
curl_div = a1 + scaled(shifted(a1, (1, 0)), -1) + a2 + scaled(shifted(a2, (0, 1)), -1)
for i in range(3):
    for j in range(3):
        E = unit(3, i, j)
        eq(f"M3 scalar addition E{i}{j}", local_action(q + scalar, E, 0), local_action(q, E, 0))
        eq(f"M3 curl first primitive action E{i}{j}", local_action(a1, E), s.zeros(27))
        eq(f"M3 curl second primitive action E{i}{j}", local_action(a2, E), s.zeros(27))
        for b in range(2):
            eq(f"M3 curl weighted divergence coordinate {b} E{i}{j}", local_action(curl_div, E, b), s.zeros(27))

incomplete = [(s.Integer(1), {origin: s.diag(1, 1, -2)})]
restricted = [(0, 0), (0, 1), (1, 0), (1, 1), (2, 2)]
check("M3 incomplete subalgebra accepts false zero action", all(local_action(incomplete, unit(3, i, j)) == s.zeros(27)
      for i, j in restricted), selected_units=restricted)
ne("M3 complete basis rejects omitted third-level transition", local_action(incomplete, unit(3, 0, 2)), s.zeros(27))

# Degenerate on-site action: the current is zero despite nonzero energy action.
onsite = s.diag(2, -1, -1)
check("R zero current with nonzero energy action", comm(onsite, onsite) == s.zeros(3)
      and I * comm(onsite, unit(3, 0, 1)) != s.zeros(3))

payload = {"implementation": "exact SymPy CAR kernels and direct qutrit matrix-unit embeddings",
           "sympy_version": s.__version__, "rows": rows,
           "total": len(rows), "failed": sum(not row["ok"] for row in rows)}
output = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("independent_results.json")
output.write_text(json.dumps(payload, indent=2) + "\n")
print(json.dumps({"total": payload["total"], "failed": payload["failed"]}), flush=True)
raise SystemExit(bool(payload["failed"]))
