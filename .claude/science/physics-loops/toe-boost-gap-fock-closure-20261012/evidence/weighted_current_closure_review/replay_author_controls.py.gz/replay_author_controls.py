#!/usr/bin/env python3
"""Replay preserved author sources once, only inside reviewer evidence paths."""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SNAP = ROOT / 'author_snapshot'
LIVE = ROOT.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


receipt = json.loads((SNAP / 'receipt.json').read_text())
checks = []
for entry in receipt['source_files']:
    source = LIVE / entry['path']
    snap = (ROOT / 'sources' / entry['path']) if not entry['path'].startswith('weighted_current_closure/') else SNAP / Path(entry['path']).relative_to('weighted_current_closure')
    checks.append({'path': entry['path'], 'expected_sha256': entry['sha256'],
                   'live_sha256': sha(source), 'snapshot_sha256': sha(snap),
                   'bytes': source.stat().st_size,
                   'ok': sha(source) == sha(snap) == entry['sha256'] and source.stat().st_size == entry['bytes']})
write(ROOT / 'author_receipt_verification.json', checks)
if not all(c['ok'] for c in checks):
    raise RuntimeError('author receipt mismatch')

baseline = json.loads((SNAP / 'logs/final_sparse/weighted_results.json').read_text())
baseline_rows = {r['name']: r for r in baseline['rows']}
mutation_analysis = []
for directory in sorted((SNAP / 'mutations').iterdir()):
    metadata = json.loads((directory / 'mutation.json').read_text())
    source = directory / 'weighted_controls.py'
    original = (SNAP / 'controls/weighted_controls.py').read_text()
    expected = original.replace(metadata['old'], metadata['new'], 1)
    if original.count(metadata['old']) != 1 or expected != source.read_text():
        raise RuntimeError('mutation scope not reproduced: ' + directory.name)
    result = json.loads((directory / 'weighted_results.json').read_text())
    execution = json.loads((directory / 'execution.json').read_text())
    changed = [dict(baseline=baseline_rows[r['name']], mutated=r) for r in result['rows'] if r != baseline_rows[r['name']]]
    mutation_analysis.append({'name': directory.name, 'metadata': metadata,
                              'source_diff': ''.join(difflib.unified_diff(original.splitlines(True), source.read_text().splitlines(True))),
                              'execution': execution, 'changed_rows': changed,
                              'passed_rows': [r['name'] for r in result['rows'] if r['passed']],
                              'failed_rows': [r['name'] for r in result['rows'] if not r['passed']]})
write(ROOT / 'author_mutation_analysis.json', mutation_analysis)

cases = [('original_failed_expectation', 'logs/run1', 'weighted_controls.py', 'weighted_results.json'),
         ('final_sparse', 'logs/final_sparse', 'weighted_controls.py', 'weighted_results.json'),
         ('final_matrix', 'logs/final_matrix', 'matrix_controls.py', 'matrix_results.json')]
cases += [(d.name, 'mutations/' + d.name, 'weighted_controls.py', 'weighted_results.json')
          for d in sorted((SNAP / 'mutations').iterdir())]
run_results = []
for name, origin, script, output in cases:
    run = ROOT / 'author_replays' / name
    run.mkdir(parents=True, exist_ok=False)
    shutil.copy2(SNAP / origin / script, run / script)
    command = [sys.executable, str(run / script)]
    metadata = {'case': name, 'command': command, 'declared_timeout_seconds': 60,
                'started_utc': datetime.now(timezone.utc).isoformat(), 'source_sha256': sha(run / script)}
    write(run / 'execution.started.json', metadata)
    start = time.monotonic()
    try:
        result = subprocess.run(command, capture_output=True, timeout=60)
        stdout, stderr = result.stdout, result.stderr
        metadata.update(exit_code=result.returncode, timed_out=False)
    except subprocess.TimeoutExpired as exc:
        stdout, stderr = exc.stdout or b'', exc.stderr or b''
        metadata.update(exit_code=None, timed_out=True)
    metadata.update(wall_seconds=time.monotonic() - start, ended_utc=datetime.now(timezone.utc).isoformat())
    (run / 'stdout.jsonl').write_bytes(stdout)
    (run / 'stderr.txt').write_bytes(stderr)
    metadata['stdout_sha256'] = sha(run / 'stdout.jsonl')
    metadata['stderr_sha256'] = sha(run / 'stderr.txt')
    metadata['stdout_exactly_reproduced'] = stdout == (SNAP / origin / 'stdout.jsonl').read_bytes()
    metadata['stderr_exactly_reproduced'] = stderr == (SNAP / origin / 'stderr.txt').read_bytes()
    if (run / output).exists():
        actual = json.loads((run / output).read_text())
        old = json.loads((SNAP / origin / output).read_text())
        metadata['summary'] = actual['summary']
        metadata['failed_names'] = [r['name'] for r in actual['rows'] if not r['passed']]
        metadata['result_sha256'] = sha(run / output)
        old.pop('created_utc', None)
        actual.pop('created_utc', None)
        metadata['result_exact_except_timestamp'] = actual == old
    write(run / 'execution.json', metadata)
    run_results.append(metadata)
    print(json.dumps(metadata), flush=True)
write(ROOT / 'author_replays_summary.json', run_results)
print(json.dumps({'receipt_file_checks': len(checks), 'replays': len(run_results),
                  'all_stdout_equal': all(x['stdout_exactly_reproduced'] for x in run_results),
                  'all_results_equal_except_timestamp': all(x.get('result_exact_except_timestamp', False) for x in run_results)}))
