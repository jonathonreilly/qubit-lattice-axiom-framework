# Independent review of the microscopic joint-flow lemma

**PASS for the stated conditional theorem at the frozen source.** I found no
material mathematical or evidence defect in J1–J24 and require no author
source correction. This is a focused source review, with the supplied model
conditions preserved. It grants no applied audit or retained status.

The reviewed candidate is `MICROSCOPIC_JOINT_FLOW_PROBE.md`, all 279 lines,
SHA-256 `35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd`.
Its author receipt is SHA-256
`afdfaff1e0a1c4a6843cbfd0d49c449d37bed0d62052b967c92ac9c38582984c`.
The necessary current-implementation argument was read in full at its actual
399-line source, SHA-256
`bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`.
The prior review and both upstream receipts remain at their candidate-bound
identities. All 192 file entries across the three receipts match their hashes
and sizes; the author evidence inventory is complete.

The precise implication checked is: a finite family of supplied self-adjoint
operators with the stated bounded finite-range spin actions on the actual
local cyclic domain, commuting pairwise on that domain, has pairwise
commuting spectral measures and exact canonical GNS implementations of
commuting microscopic norm flows. For translation-covariant finite densities,
the complete one-site matrix criterion and scalar-plus-divergence
classification are valid as stated.

| Complete argument reviewed | Conclusion |
|---|---|
| Actual local action and domains, lines 30–53 | Locality derives invariance of D and all finite mixed product domains; G_jΩ=0 follows. No unspecified core or exponential invariance is substituted. |
| Mixed bound and analytic diamond, lines 54–89 | Each connected history adds at most s−1 sites. Its weighted branching estimate yields J4 for every color ordering. The multinomial bound is absolutely summable with a support-independent radius. Disconnected supports, scalar A, s=1 and J_j=0 are covered. |
| Actual unitary products and spectral passage, lines 90–122 | Self-adjoint Taylor remainders justify the sequential expansion. The mixed majorant permits rearrangement; D-invariance permits finite word swaps. Density, finite subdivision and spectral approximation give all-time strong commutation without an unproved domain interchange. |
| Individual norm flows and canonical implementation, lines 123–158; upstream I14–I29 | Finite-volume isometric remainders and coefficient stabilization construct each norm flow. Point-norm composition gives all real times and the group law. State invariance makes the canonical GNS map well-defined before promoting vacuum-column equality to adjoint implementation. |
| Vector/algebra equivalence and phases, lines 132–158 | Applying the zero vector derivation to AB, then using cyclic density and faithfulness, proves the algebra identity. Vacuum separation is not assumed. Canonical action on every cyclic vector removes commutant or scalar-phase ambiguity. |
| Finite density criterion, lines 160–186 | Finite padded Jacobi has the correct sign, ordered labels and no extra half. Radius 2L_j+L_k and the stated interaction bounds are valid. Translation plus Leibniz makes a complete one-site operator basis necessary and sufficient. |
| Finite-density classification, lines 188–209 | Nonidentity finite tensor words have trivial translation stabilizers. The finite K_z commutant and zero partial trace force each orbit sum to vanish. Coordinate-path telescoping produces finite Hermitian divergence primitives, and the converse is finite relabeling. No infinite scalar sum is used. |
| Examples and physical clock, lines 211–267 | J21 and J22 agree with independent exact matrices. The current does not conserve generically; nonzero divergence densities can conserve. The one beta division, negative current clocks and supplied geometric implementation are maintained. |

The full reconstruction and the independently designed control source were
frozen at 2026-10-12 03:43:59 UTC before author helper, control-output or mutant
access. Prior exposure is disclosed: the complete candidate includes author
result summaries, and the upstream note and receipt source metadata were
visible. This was not blinded checking. The new implementation imported no
author helper and used distinct arithmetic and fixtures. The frozen
reconstruction, including every load-bearing step and the predeclared control
design, is in
[RECONSTRUCTION.before_author_controls.md](microscopic_joint_flow_review/RECONSTRUCTION.before_author_controls.md).

The independent controls use exact Gaussian-integer Kronecker matrices with
open padded cutoffs, a full qutrit basis, and weighted two-dimensional support
histories. They reproduce the nonconserving current and J21 exactly, detect
the sign and half-factor competitors, and reproduce the nonzero XX divergence
J22 exactly. An open XX cutoff has nonzero [H,P] but zero action on every
padded interior one-site basis member. This explicitly checks why finite
open-boundary commutation is not required by the theorem. The qutrit cases
separate divergence cancellation from an altered orbit sum that selected
diagonal tests miss. Fourteen history cases reject omission of support
growth; the two color orders have different counts under the common bound.

That independent run completed 123 finite predicates with no failed predicate
in 1.160284 seconds under a 60-second timeout. Counts are execution facts,
not proof grades. The matrix arithmetic uses guarded integer operations; its
largest recorded operation bound is 210 against a 2^62 guard. No finite test
establishes a self-adjoint realization, an infinite-volume limit or physical
applicability; those distinctions remain explicit.

The complete author runner and both orchestration helpers were read. The
unmodified baseline and all five actual saved source mutants were reproduced
from byte-identical copies in the review directory. Every run reproduced all
37 rows and the entire stdout bytes exactly; every result field except its
new timestamp also matched. Baseline exit was 0. The five mutants exited 1
with respectively 3, 3, 10, 3 and 1 failed predicates for current sign,
current half, support growth, Jacobi sign and deleted divergence term.
All six author replays used 60-second timeouts and completed in under 0.41 seconds,
with empty stderr and no unintended failure.

Passing mutant predicates are preserved as well. XX conservation survives
current sign/rescaling, independent dense assembly does not inspect the
mutated sparse helper, binomial arithmetic does not validate the history
bound, and tracial-vacuum checks vanish even in the nonconserving fixture.
The detailed scope of every such control, the complete changed mutant rows,
all logs and source/output bindings are in
[CONTROL_ANALYSIS.md](microscopic_joint_flow_review/CONTROL_ANALYSIS.md) and
`microscopic_joint_flow_review/author_replays/`.

The conditional implication has no unresolved proof step identified by this
review. Application still requires the actual self-adjoint generators and
their exact local actions, the predecessor's boost closure on this same D,
and the intended model's conservation and cross-current identities. Under
J1/J2, J3 is equivalent to strong commutation on these supplied operators;
the note establishes the nontrivial sufficiency/domain argument and a finite
criterion, not the truth of that criterion for an intended physical model.
Positivity, gap, particles, centres, scattering, detector exhaustion,
completeness and physical identification remain separate. Generic energy
current conservation and an integrated Poincaré model are not derived.

There was one review iteration, with zero material findings and zero source
fixes. The source-readiness recommendation is **PASS WITH BOUNDED CLAIMS**;
the mathematical implication is checked conditionally. Formal audit,
retained status, Lean formalization, broad repository integration checks and
publication are outside this dispatch. No claim is made to certify unrelated
predecessor index or scattering arguments. No additional external theorem or
literature-novelty claim is used.

Instruction provenance is recorded from the supplied current checkout and
the parent-provided planning snapshot: main instruction authority
`a13caa4885f547c8d206265b031ba7649e539fd9`, planning authority
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. Local byte bindings, not global
worktree cleanliness, were checked. Final verification found one installed
reporting-reference mismatch. Its failed check and exact diff were preserved,
and the complete current checkout reference, SHA-256
`8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e`, was read
and applied. The added output-reproducibility guidance introduces no remaining
obligation here: output handling is unchanged, same-run stdout/JSON are saved,
and no runner cache is used. Neither instruction copy was edited.
The selected model and reasoning effort
were inherited without override or subdelegation. Only this review and
`microscopic_joint_flow_review/` were written. No Git command, repository
edit, PR, merge, push, audit application, axiom change or other-chat action
occurred. **Editable prompt files changed: none.** The fixed campaign deadline
remains 2026-10-12 16:00:52 UTC.
