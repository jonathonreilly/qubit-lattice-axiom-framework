# Independent analytic reconstruction before author evidence

This document was written before opening any file in
`boost_kernel_effective_dynamics/`, including its receipt, scripts, logs,
author checks and prior-art inventory. The frozen candidate itself was read
in full, including its stated conclusions and description of its controls.
That prior exposure is unavoidable and is not hidden. The mathematical
reconstruction below comes from the defining operators and original premise
notes, not from author finite controls or previous reviewer verdicts.

Target: K1–K19 of `BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md`, SHA-256
`1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9`.
The task is a selective independent source review, not formal audit or a new
review of the parent boost/current expectation claim. Supplied walk,
preparation, clock and Hilbert-space conventions remain hypotheses.

## 1. Fixed space, exact kernel, and domain

Use the complete torus with measure dq/(2pi)^3, singlet c of norm one,
and triplets T_j = sigma_(1,j)c. Pair antisymmetry means an even singlet
coefficient and odd triplet coefficients. The physical fiber is c-perp
inside that antisymmetric Hilbert space; P = I - |c><c| uses one global
torus integral. In particular, removing c does not remove arbitrary
q-dependent singlet fields.

At K = 0, the free symbol in this orthonormal frame is
H0(0) = [[0,2s^T],[2s,0]], where s_j = sin q_j. Away from the null cone
set, its free kernel is exactly the transverse triplet plane. If a physical
field u obeys P H0(0) P u = 0, then H0(0)u = gamma c with one constant
gamma. Hence its singlet coefficient is zero a.e.; its longitudinal
triplet part is gamma s/(2|s|^2). This proves completeness of the physical
kernel decomposition Z = F_tr orthogonal-sum C zeta.

The norm of s/(2|s|^2) is sqrt(I0). Folding the eight periodic sine-squared
cells into Q = [-pi/2,pi/2]^3 and using |sin q_j| >= 2|q_j|/pi gives

    1/12 <= I0 = integral 1/(4|s|^2) dmu
        <= (1/(16pi)) integral_(|q|<=pi sqrt(3)/2) |q|^-2 dq
        = pi sqrt(3)/8.

Thus zeta = s/(2|s|^2 sqrt(I0)) is a unit physical odd triplet field,
H0(0)zeta = c/sqrt(I0), and Pi h0 = zeta/sqrt(I0), h0 = 2s.
The cone singularity is square integrable in three dimensions but need not
be H1 in q. No claim in K1–K19 requires a q derivative of this vector.
All operators acting on it here are bounded fiber operators. Derivatives
in the new theorem are in kappa, whose zero-space projection is fixed.

## 2. First derivative, block, parity, and cyclic measure

Expand the sine symbol at K = lambda kappa. Its order-lambda triplet part
is (sigma_1 + sigma_2) dot d / 2, d_j = kappa_j cos q_j. Direct use of
Pauli multiplication and sigma_(2,j)c = -sigma_(1,j)c gives

    (sigma_(1,j)+sigma_(2,j))T_l = 2i epsilon_(jlm) T_m,

so B_kappa acts on triplets as i d cross and kills every singlet field.
It is bounded self-adjoint, norm at most |kappa|, and preserves physical
parity. Compression to Z cannot increase that norm.

For transverse u, project d cross u onto n-perp to obtain
(d dot n)n cross u. Since B zeta is transverse, its vector is exactly
g = i(d cross n)/(2epsilon sqrt(I0)), and its zeta expectation vanishes.
Therefore A = [[D,g],[<g|,0]], D = omega J, omega = d dot n and
J = i n cross on the tangent plane. This derives both off-diagonal
entries and their sign with the second-slot-linear convention.

Under q -> -q, d is even, n and omega are odd, J is odd, D is even,
and g is odd. J alone maps an odd triplet field to an even one; its
pointwise helicity projectors are not physical reducing projections by
themselves. Functional calculus for D uses the combined expressions
h(omega)(I+J)/2 + h(-omega)(I-J)/2 and does preserve odd parity.
The note respects precisely this distinction.

Pointwise J is Hermitian, J^2 = I on n-perp, and g is i times a real
vector. Antisymmetry of the real cross-product matrix gives g*Jg = 0.
Consequently the scalar spectral measure of D at g is

    beta(L) = (1/2) integral |g|^2
                 [1_L(omega) + 1_L(-omega)] dmu.

Its mass is ||g||^2, not 1. For any polynomial p,
||p(D)g||^2 = integral |p(E)|^2 dbeta(E). Polynomial density follows
from compact support of a finite Borel measure. The extension of this map
onto the D-cyclic subspace is therefore an isometry. Together with zeta it
reduces A. Conversely, A zeta = g and powers of A, after subtracting their
scalar zeta terms, successively generate D^n g. Thus this reducing subspace
is exactly the A-cyclic subspace of zeta, with the block action in K4.
At kappa = 0, g = D = A = 0; L2(beta) is the zero space and only zeta
is cyclic. There is no hidden bath dimension restriction.

Solving (z-A)(v,alpha) = (0,1) yields
v = alpha(z-D)^-1 g and alpha = [z - <g,(z-D)^-1g> ]^-1.
This derives K5. For Im z > 0, Im Sigma <= 0, so its denominator has
strictly positive imaginary part. These signs are consistent with the
resolvent convention (z-A)^-1, whose scalar imaginary part is negative.

## 3. Original proof needed for source absolute continuity

The block alone does not imply absolute continuity. I checked original
memory E13–E23, including the constants and endpoints, as follows.
For b = |kappa| > 0, let chi = delta/b in (0,1), r0 = sqrt(chi)/8 and
e_hat = kappa/b. On the shell q = r omega near zero set
X = sin(2r omega)/(2r), Y = sin(r omega)/r, h = |Y| and v = X/h.
Then omega_frequency/b = e_hat dot v. Taylor inequalities give
|X-omega| <= 2r^2/3, |Y-omega| <= r^2/6 and h >= 1-r^2/6.
For r <= 1/2 these imply |v-omega| <= r^2 and |n-omega| <= r^2/2.

For a tangent H, the diagonal cosine derivatives give
|dX[H]-H| <= 2r^2|H| and |dY[H]-H| <= r^2|H|/2.
Using omega dot H = 0 proves |dh[H]| <= 2r^2|H|/(3h).
Differentiating X/h then bounds |dv[H]-H| by
r^2[13/(6h) + 2/(3h^3)]|H|, strictly less than 4r^2|H|.
Also |d/b-e_hat| <= r^2/2, so
|(d/b) cross n - e_hat cross omega| <= r^2.

Use polar t = e_hat dot omega in [-1+chi/4,1-chi/4]. Its tangent
speed is (1-t^2)^-1/2 <= 2/sqrt(chi). On r in [r0/2,r0], the
frequency derivative in t lies between 7b/8 and 9b/8. Its range includes
[-b+delta/2,b-delta/2], and |d cross n| >= b sqrt(chi)/4.
Because epsilon <= r, |g|^2 >= b^2 chi/(64 I0 r^2).
Changing t to the frequency in just one helicity term gives the exact
lower bound

    beta(L) >= (1/2)(2pi)^-3 * b^2 chi/(64 I0)
                   * (1/(2b)) * (r0/2) * 2pi * |L|
            = b chi^(3/2)/(16384 pi^2 I0) * |L|

for Borel L in that interval. This calculation retains the single-helicity
half and the complete normalized torus measure.

For |x| <= b-delta and 0<y<=delta/2, the lower bound c_delta yields
-Im Sigma(x+iy) >= 2 c_delta arctan(delta/(2y)) >= pi c_delta/2.
Thus |M(x+iy)| <= 2/(pi c_delta) uniformly in this full strip.
The Poisson integrand is at least 1/(2y) on [x-y,x+y], so the dressing
measure satisfies mu([x-y,x+y]) <= 2y[-Im M(x+iy)] <= 2C_delta y.
Interval covers give local domination by Lebesgue measure on every
compact subinterval of (-b,b). This treats possible singular-continuous
measure as well as atoms; a mere a.e. boundary-value statement would not.

The only remaining possible singular measure is at +-b. Since
|d(q)|^2 = sum kappa_j^2 cos^2 q_j < b^2 a.e. for nonzero kappa,
every nonzero zero-space vector satisfies ||A u|| <= ||B u|| < b||u||.
An endpoint eigenvector, and hence any endpoint spectral atom, is impossible.
This strict vector inequality is not a uniform spectral gap. Accordingly
mu is an absolutely continuous probability measure supported in [-b,b].
No claim about all dark reducing subspaces is required.

## 4. Exact normalization and forcing from the original walk

The B25–B30 source uses F and f of Lebesgue L2 norm one, F smooth,
nonnegative, supported in |kappa| <= 65/512, and f the positive normalized
annular bump on 5/8 < |x| < 3/4. The factor (2pi)^3 lambda^-3 cancels
both normalized measures in its global norm. For the contact amplitude,
only the q measure is integrated, and its Jacobian alone cancels that
factor. Therefore a_lambda is exactly F/Z_lambda times the Lebesgue
integral of f w_lambda exp(-is e_lambda), without an extra c0.

The two one-body directions are y_+/|y_+| and -y_-/|y_-|.
The singlet contraction of their positive projectors is
w = [1 + y_+ dot y_-/(|y_+||y_-|)]/4. This has a plus sign because
the second direction is negative. Its global square norm is Z0^2 as in K6.
The full-torus exclusion normalization satisfies
n_lambda^2 = 1-c0^2 lambda^3 ||a_lambda(0)||^2 -> 1.
Neither global scalar has a kappa derivative.

For v_free = P exp(-itH0)phi_lambda/n_lambda, direct differentiation
gives i v_free' = H v_free + h<c,exp(-itH0)phi_lambda>/n_lambda.
Subtract from the actual homogeneous evolution to obtain
i w_phys' = H w_phys - h a_lambda/n_lambda, w_phys(0)=0.
Variation of constants has the positive-i sign.

Under the K-only isometry T_lambda = c0 lambda^(3/2) evaluation at
K=lambda kappa and the additional lambda^-1/2 factor, changing physical
time s to rescaled time lambda s supplies lambda^-1. The net prefactor
is c0, since lambda^(3/2) lambda^-1/2 lambda^-1 = 1. Projection of h0
onto the complete physical kernel supplies 1/sqrt(I0). Thus the effective
forcing is exactly the one in K8's preceding integral, with
C = c0 F/(Z0 sqrt(I0)). No initial homogeneous tail remains: the actual
and projected free comparison have the same initial state.

For completeness, the original X23 fixed-time theorem follows from its
cutoff proof, not operator-norm convergence. Write G_lambda = H_*/lambda
+ B + E_lambda, with E_lambda and its first kappa derivatives O(lambda).
For a compact continuous Q-valued residual family r(s,kappa), cut at
|H_*| >= delta. Strong convergence of that cutoff to Q is uniform on
the compact family. On the high piece use x_delta = H_*^-1 S_delta r;
integration by parts against the full perturbed unitary gives an error
bounded by T epsilon_delta plus lambda/delta times bounded endpoint,
time-derivative and perturbation terms. First lambda -> 0, then delta -> 0.
No commutation with B and no complementary gap are assumed.

Apply this to Q(Bz-g) in the exact error equation and then to its kappa
derivatives. The differentiated propagator term is controlled by
||partial_j G_lambda|| <= 1 and the already proved zeroth-order error.
This gives uniform H1 convergence on every fixed compact tau interval.
Its constants and cutoff argument provide no growing-time lambda rate.

## 5. Frequency separation and the forced resolvent identity

For r=|x| in [5/8,3/4] and b<=1/4, |y_+|,|y_-| >= r-b/2 >=1/2.
Their dot product is r^2-b^2/4 >0, so 1/4 <= w <=1/2. The triangle
inequality gives 2r <= e <=2r+b. Since sigma(A) is in [-b,b],

    1 <= e-E <= 3/2+2b <= 2.

The lower bound uses 5/4-b >=1. It concerns source frequency versus
the bounded effective spectrum only, and says nothing about H_* off Z.

For a single spectral value E, direct time integration gives

    i integral_0^tau exp[-i(tau-s)E] exp(-is e) ds
      = [exp(-i tau E)-exp(-i tau e)]/(e-E).

This remains true for negative tau and is zero at tau=0. Bounded spectral
calculus applies uniformly because e-E>=1; compact source support and
integrable f justify Bochner Fubini on every finite tau interval. This
derives K8, including its sign and all constants. Independently,
Y=(e-A)^-1[exp(-itA)-exp(-ite)]zeta satisfies Y(0)=0 and
iY'=AY-exp(-ite)zeta. The derivative at zero is +i zeta.

Set chi(E)=integral f w/(e-E) and v=C chi(A)zeta. Subtract the explicit
free-frequency integral r(tau) to obtain K9. At zero r(0)=v exactly.
Since f>=0 is not zero and 1/8<=w/(e-E)<=1/2,
m_f/8 <= chi <=m_f/2. Positive spectral calculus on the unit zeta and
||F||_2=1 yields K10, the nonzero lower bound for ||v||, and K17's bounds
on V=||v||^2. This argument has no reliance on absolute continuity.

## 6. Hilbert-valued integration by parts and global H1 constants

The radial phase derivative is
(r+kappa dot omega/2)/|r omega+kappa/2|
+(r-kappa dot omega/2)/|r omega-kappa/2|. Each numerator is positive;
replace it below by r-b/2 and its denominator above by r+b/2 to get
partial_r e >=2(r-b/2)/(r+b/2)>=4/3. All fixed mixed r,kappa
derivatives of e and w are bounded on this compact set. This does not
differentiate the torus variable q.

The family A is linear in kappa on the fixed Hilbert space Z, with
||partial_j A|| <=1. The resolvent R=(e-A)^-1 is smooth in operator norm:
partial R = -R partial(e-A) R, with ||R||<=1. Induction gives bounded
mixed derivatives of any fixed order. The denominator stays positive in
an open neighborhood of the compact parameter set, so boundary points
of the enclosing kappa ball cause no differentiability issue.

Let H0=r^2 f(r) w R zeta and L_e H = partial_r(H/partial_r e).
Every radial derivative of f vanishes at the annular endpoints, so the
same is true of H0 and every L_e iterate, also after kappa derivatives.
The exact identity is

    integral exp(-i tau e) H0 dr
       = (-i/tau)^n integral exp(-i tau e) L_e^n H0 dr.

It follows first for Hilbert-valued C1 functions by Bochner integration
by parts, then iteratively. There are no endpoint terms. Define the finite
numbers M_n(H)=sup_(|kappa|<=1/4) integral_(sphere,annulus)
||L_e^n H|| dr dOmega. Smoothness and compactness prove finiteness.
These give an explicit specification of constants, without requiring
a numerical quadrature to certify them.

For a kappa derivative of the integral the amplitudes are partial_j H0
and (-i tau)(partial_j e)H0. Use n integrations on the first and n+1
on the second. For |tau|>=1 the resulting bound is
|tau|^-n [M_n(partial_j H0)+M_(n+1)((partial_j e)H0)].
The undifferentiated bound is |tau|^-n M_n(H0).
Multiplication by C contributes the finite fixed factors
c0/(Z0 sqrt(I0)), ||F||_2 and ||partial_j F||_2. Since F is smooth
and supported strictly inside the enclosing ball, zero extension gives
a global H1 section with no boundary distribution. For |tau|<=1 use
the directly bounded integrals, including the at-most-unit tau factor.
Increasing constants by powers of two converts to (1+|tau|)^-n.
This proves the first half of K11 with uniform finite constants.

Duhamel differentiation of exp(i tau A) gives operator norm at most
|tau| ||partial_j A|| <=|tau|. Applying the first half with exponent
n+1 absorbs this derivative cost and proves the second half. The same
proof covers negative tau. At tau=0 the resolvent integral also proves
v is a compactly supported H1 section. No q-Sobolev norm of zeta enters.

The alternative outgoing-time formula is also consistent: rapid decay
of a and its kappa derivatives makes integral_0^infinity exp(isA)zeta
a(s) absolutely convergent in H1 despite the single s from differentiating
the unitary. With an Abel factor, i integral_0^infinity
exp[-(eta+i(e-E))s]ds = 1/(e-E-i eta), which tends to the positive
resolvent in K9. The gap dominates it uniformly. This is a consistency
derivation, not a need to exchange an uncontrolled improper integral.

## 7. Exactly where absolute continuity is used

For F(kappa)!=0, spectral calculus gives
mu_v(L)=|C|^2 integral_L chi(E)^2 dmu(E). The strictly positive bounds
on chi show equality of null sets and closed supports. For kappa!=0,
the prior absolute-continuity theorem therefore gives the displayed
nonzero density. At kappa=0 the spectral measure is delta_0 instead;
this isolated fiber is not incorrectly promoted to a decaying one.

The zeta coefficient of the leading term is
C integral exp(-i tau E) chi(E) rho(E) dE. Its density is L1 because
chi is bounded and rho has mass one. Approximation by finite interval
step functions proves its decay for either sign of time. The explicit
remainder vanishes pointwise by the preceding uniform amplitude estimates.
Thus the zeta coefficient tends to zero at each nonzero fiber. This is
the step that uses the prior continuum theorem. Unitarity and the rapid
remainder alone already give ||z(tau,kappa)||^2 -> ||v(kappa)||^2.

As z lies in the orthogonal sum F_tr plus C zeta, subtracting the squared
zeta coefficient yields the transverse norm limit. Its global version is
valid by dominated convergence using a fixed constant times |F|^2.
No uniform spectral Fourier rate near kappa=0 is needed. In fact the total
norm convergence is rapid by
abs(||z||^2-||v||^2)<=2||v||||r||+||r||^2, but this does not give the
same rate for the transverse norm because of the additional coefficient.

## 8. Ordered limits and preserved counterexamples

The isometry T_lambda changes only K and preserves the complete q fiber.
The comparison correction keeps the compact K support of its initial
packet since the Hamiltonians act fiberwise. Hence
||W_lambda||^2 = lambda^-1 ||w_phys,lambda||^2 exactly.
The fixed, bounded transverse projection commutes with T_lambda. For each
fixed tau, X23 therefore gives both inner norm limits in K18. Taking the
effective-time limit afterwards yields V>0. No step estimates a joint
regime tau(lambda) or justifies exchanging the limits. The error residual
Q(Bz-g) belongs to the nonzero H_* complement, whose low spectral mass
is not controlled by the source/effective-spectrum separation.

These correction norms are not probabilities for the unit total state;
the free comparison and its cross terms remain present in that state.
No conclusion about a limiting weighted current or complete boost algebra
is justified or claimed. The old small-positive-time residual-norm
obstruction and expectation cancellation are different observables.

The finite-bath counterexample is exact: with f=3/5,h=4/5 and the
memory E27 matrix, A^3=A and the dressing amplitude is
1+(cos t-1)h^2=(9+16 cos t)/25. It recurs to 1 at 2pi n, while K8
still holds for a separated source. Thus finite block/resolvent algebra
cannot prove K16. The cone-concentrating parent D31 example uses
lambda-dependent zero-space unit vectors, not the fixed compact residual
families of X14; it continues to preclude uniform state convergence.
The mixed-band small-total-energy example and the nonzero differential
bracket coefficient are unaffected by this forced-kernel statement.

## 9. Pre-evidence assessment

The stated analytic K1–K19 claims follow under the supplied model and
preparation, using precisely the imported fixed-time H1 and source-measure
theorems whose necessary proofs were checked above. I have not identified
a material analytic defect or a missing terminal lemma in this frozen
candidate. This assessment is prior to finite-control inspection and
does not grant retained status, new physical premises, or a growing-time
approximation. The finite author controls still need source and defect
discrimination checks; their outcome cannot replace any analytic step here.
