"""Independent finite controls, authored before opening the author evidence.

These discriminate finite algebra/sign/derivative errors. They do not prove
the continuum source-measure theorem or uniform Hilbert-valued IBP estimates.
"""
import json
import sys
import numpy as np
import scipy
import sympy as sp
from scipy.integrate import solve_ivp
from scipy.linalg import expm, expm_frechet

I = sp.I
pauli = [sp.Matrix([[0, 1], [1, 0]]),
         sp.Matrix([[0, -I], [I, 0]]),
         sp.Matrix([[1, 0], [0, -1]])]
singlet = sp.Matrix([0, 1, -1, 0]) / sp.sqrt(2)
s1 = [sp.kronecker_product(p, sp.eye(2)) for p in pauli]
s2 = [sp.kronecker_product(sp.eye(2), p) for p in pauli]
frame = sp.Matrix.hstack(singlet, *[p * singlet for p in s1])
assert frame.H * frame == sp.eye(4)
triplet_generators = []
for j in range(3):
    transformed = sp.simplify(frame.H * (s1[j] + s2[j]) * frame / 2)
    ej = sp.eye(3)[:, j]
    expected = I * sp.Matrix.hstack(*[ej.cross(sp.eye(3)[:, k]) for k in range(3)])
    assert transformed[0, :] == sp.zeros(1, 4)
    assert transformed[:, 0] == sp.zeros(4, 1)
    assert transformed[1:, 1:] == expected
    triplet_generators.append(np.array(expected, dtype=complex))
print('Exact Pauli frame: all three triplet generators are +i cross; singlet is killed.')

a = sp.Matrix([sp.Rational(3, 5), sp.Rational(4, 5), 0])
d = sp.Matrix([0, sp.Rational(5, 13), sp.Rational(12, 13)])
proj1 = (sp.eye(4) + sum((a[j] * s1[j] for j in range(3)), sp.zeros(4))) / 2
proj2 = (sp.eye(4) - sum((d[j] * s2[j] for j in range(3)), sp.zeros(4))) / 2
weight = sp.simplify((singlet.H * proj1 * proj2 * singlet)[0])
assert weight == (1 + a.dot(d)) / 4 == sp.Rational(17, 52)
assert weight != (1 - a.dot(d)) / 4
print('Exact positive-projector singlet weight:', weight, '(minus-dot competitor rejected).')

f0, h0 = sp.Rational(3, 5), sp.Rational(4, 5)
finite_bath = sp.Matrix([[0, -I*f0, I*h0], [I*f0, 0, 0], [-I*h0, 0, 0]])
assert finite_bath**3 == finite_bath
t = sp.symbols('t', real=True)
finite_evolution = sp.eye(3) - I*sp.sin(t)*finite_bath + (sp.cos(t)-1)*finite_bath**2
assert sp.simplify(finite_evolution[2, 2] - (9+16*sp.cos(t))/25) == 0
print('Finite-bath recurrence preserved exactly: amplitude (9+16 cos(t))/25.')

kappa = np.array([0.075, -0.052, 0.041])
x = np.array([0.69, 0.04, -0.01])
zeta = np.array([0, 0, 1], dtype=complex)
generators = np.array(triplet_generators)
A = np.einsum('j,jab->ab', kappa, generators)
yp, ym = x+kappa/2, x-kappa/2
rp, rm = np.linalg.norm(yp), np.linalg.norm(ym)
np_, nm = yp/rp, ym/rm
e = rp+rm
dot = np_.dot(nm)
w = (1+dot)/4
de = (np_-nm)/2
dw = ((nm-dot*np_)/rp-(np_-dot*nm)/rm)/8
assert 5/8 < np.linalg.norm(x) < 3/4
assert np.linalg.norm(kappa) < 1/4
assert e-np.linalg.eigvalsh(A)[-1] >= 1

def rhs(tau, y):
    blocks = y.reshape(4, 3)
    ans = np.empty_like(blocks)
    phase = np.exp(-1j*tau*e)
    ans[0] = -1j*A@blocks[0] + 1j*w*phase*zeta
    for j in range(3):
        ans[j+1] = (-1j*A@blocks[j+1] - 1j*generators[j]@blocks[0]
                    + 1j*(dw[j]-1j*tau*w*de[j])*phase*zeta)
    return ans.ravel()

def resolvent_formula(tau, omit_phase_derivative=False):
    R = np.linalg.inv(e*np.eye(3)-A)
    U = expm(-1j*tau*A)
    phase = np.exp(-1j*tau*e)
    T = U-phase*np.eye(3)
    ans = np.empty((4, 3), dtype=complex)
    ans[0] = w*R@T@zeta
    for j in range(3):
        dU = expm_frechet(-1j*tau*A, -1j*tau*generators[j], compute_expm=False)
        dT = dU if omit_phase_derivative else dU+1j*tau*de[j]*phase*np.eye(3)
        ans[j+1] = (dw[j]*R@T@zeta
                    - w*R@(de[j]*np.eye(3)-generators[j])@R@T@zeta
                    + w*R@dT@zeta)
    return ans

observations = []
for tau in [-7.0, -0.6, 0.4, 2.3, 8.0]:
    sol = solve_ivp(rhs, (0, tau), np.zeros(12, complex), method='DOP853',
                    rtol=2e-12, atol=2e-13)
    assert sol.success
    numerical = sol.y[:, -1].reshape(4, 3)
    closed = resolvent_formula(tau)
    errors = np.linalg.norm(numerical-closed, axis=1)
    assert max(errors) < 2e-10, errors
    observations.append({'tau': tau, 'state_error': float(errors[0]),
                         'kappa_derivative_errors': errors[1:].tolist(),
                         'ode_function_evaluations': sol.nfev})

tau = 2.3
correct = resolvent_formula(tau)
bad_phase = resolvent_formula(tau, omit_phase_derivative=True)
defect_distances = {
    'reverse_forcing_sign': float(np.linalg.norm(-correct[0]-correct[0])),
    'halve_forcing_normalization': float(np.linalg.norm(0.5*correct[0]-correct[0])),
    'omit_source_phase_derivative': float(np.linalg.norm(bad_phase[1:]-correct[1:])),
}
assert min(defect_distances.values()) > 1e-3, defect_distances
assert np.linalg.norm(resolvent_formula(0)) == 0

print(json.dumps({'runtime': sys.version, 'numpy': np.__version__,
                  'scipy': scipy.__version__, 'sympy': sp.__version__,
                  'finite_source': {'kappa': kappa.tolist(), 'x': x.tolist(),
                                    'e': float(e), 'w': float(w)},
                  'ode_against_resolvent': observations,
                  'wrong_candidate_distances': defect_distances}, indent=2))
print('Finite controls completed. No continuum or uniform-time conclusion is inferred.')
