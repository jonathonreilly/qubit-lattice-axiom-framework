"""Independent byte/provenance verification, not mathematical certification."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
base = out.parent
packet = base / 'boost_kernel_effective_dynamics'
repo = base.parent / 'boost_worktree'
expected_receipt = '8767499b08e7721cf1133930fcd9e0a5c703536b46aba5eacd98b81b688d7352'
def sha(blob):
    return hashlib.sha256(blob).hexdigest()

receipt_bytes = (packet/'receipt.json').read_bytes()
assert sha(receipt_bytes) == expected_receipt
receipt = json.loads(receipt_bytes)
rows = receipt['files']
assert len({r['path'] for r in rows}) == len(rows)
records = []
for r in rows:
    p = (packet/r['path']).resolve()
    assert p == base/'BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md' or packet in p.parents
    blob = p.read_bytes()
    assert sha(blob) == r['sha256'], str(p)
    assert len(blob) == r['bytes'], str(p)
    assert len(blob.splitlines()) == r['lines'], str(p)
    records.append({'path':r['path'], 'sha256':sha(blob), 'matched':True})

copies = []
for r in json.loads((packet/'source_manifest.json').read_text()):
    original, copied = Path(r['source']).read_bytes(), (packet/r['copy']).read_bytes()
    assert original == copied
    assert sha(original) == r['sha256']
    assert len(original) == r['bytes'] and len(original.splitlines()) == r['lines']
    copies.append({'source':r['source'], 'copy':r['copy'], 'sha256':sha(original)})

instructions = []
for r in json.loads((packet/'instruction_manifest.json').read_text())['items']:
    blob = subprocess.check_output(['git','show',r['ref']+':'+r['path']], cwd=repo)
    assert sha(blob) == r['sha256']
    instructions.append({'ref':r['ref'],'path':r['path'],'sha256':sha(blob)})

source = (packet/'forced_controls.py').read_text()
mutations = []
for r in json.loads((packet/'mutation_manifest.json').read_text()):
    assert sha(source.encode()) == r['baseline_sha256']
    assert source.count(r['before']) == 1
    mutant = (packet/r['paths']['source']).read_text()
    assert mutant == source.replace(r['before'],r['after'],1)
    assert sha(mutant.encode()) == r['mutant_sha256']
    execution = json.loads((packet/r['paths']['execution']).read_text())
    assert execution == r
    assert r['exit_code'] == 1 and r['caught_at_intended_check']
    stderr = (packet/r['paths']['stderr']).read_text()
    assert stderr.strip().endswith('AssertionError: '+r['expected_assertion'])
    mutations.append({'name':r['name'],'expected_assertion':r['expected_assertion'],
                      'difference':list(difflib.unified_diff(source.splitlines(True),mutant.splitlines(True))),
                      'recorded_exit_code':r['exit_code']})

baseline1 = json.loads((packet/'baseline.execution.json').read_text())
baseline2 = json.loads((packet/'baseline_attempt2.execution.json').read_text())
assert baseline1['exit_code'] == 'timeout'
assert baseline1['source_sha256'] == sha((packet/'forced_controls_attempt1.py').read_bytes())
assert baseline2['exit_code'] == 0 and baseline2['source_sha256'] == sha(source.encode())
assert (packet/'baseline.stderr.log').read_bytes() == b''
assert (packet/'baseline_attempt2.stderr.log').read_bytes() == b''
assert 'TOTAL author_controls=38;' in (packet/'baseline_attempt2.stdout.log').read_text()

postfreeze = []
for stem in ['receipt_freeze','receipt_verification']:
    r = json.loads((packet/(stem+'.execution.json')).read_text())
    assert r['exit_code'] == 0
    assert r['receipt_sha256'] == expected_receipt
    assert r['stdout_sha256'] == sha((packet/(stem+'.stdout.log')).read_bytes())
    assert r['stderr_sha256'] == sha((packet/(stem+'.stderr.log')).read_bytes())
    postfreeze.append(r)

# Verify the two historical PR source-byte mappings locally; this is not a
# remote-current PR-state check or full publication-note review.
publication_maps = []
for number in [9481,9482]:
    r = json.loads((packet/f'published_source_search_{number}.json').read_text())
    blob = subprocess.check_output(['git','show',r['head']+':'+r['path']],cwd=repo)
    assert sha(blob) == r['sha256'] and len(blob.splitlines()) == r['lines']
    publication_maps.append({'PR':number,'head':r['head'],'path':r['path'],'sha256':sha(blob)})

pre = json.loads((out/'PRE_AUTHOR_FREEZE.json').read_text())
for r in pre['sources']:
    assert sha((base/r['relative_path']).read_bytes()) == r['sha256']
for r in pre['pre_author_outputs']:
    assert sha((out/r['relative_path']).read_bytes()) == r['sha256']

result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'author_receipt_sha256':expected_receipt,'bound_files':records,
        'source_copies':copies,'instruction_bytes':instructions,'mutation_differences':mutations,
        'historical_publication_source_identities':publication_maps,'postfreeze_metadata':postfreeze,
        'prior_timeout_preserved':baseline1,'successful_author_baseline_metadata':baseline2,
        'pre_author_freeze_unchanged':True,
        'worktree_head_at_verification':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
        'worktree_status_at_verification':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),
        'verification_scope':'Identity/provenance only. Source reading and analytic reconstruction supply mathematical review.'}
(out/'author_packet_identity_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'bound_files':len(records),'source_copies':len(copies),'instruction_byte_identities':len(instructions),
                  'literal_mutations':len(mutations),'historical_publication_maps':len(publication_maps),
                  'pre_author_freeze_unchanged':True,'all_identities_matched':True},indent=2))
