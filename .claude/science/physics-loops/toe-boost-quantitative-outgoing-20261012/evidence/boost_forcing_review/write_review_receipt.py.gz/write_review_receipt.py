"""Freeze reviewer output after final source/evidence identity checks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
base = out.parent
repo = base.parent/'boost_worktree'
packet = base/'boost_kernel_effective_dynamics'
now = datetime.now(timezone.utc)
deadline = datetime.fromisoformat('2026-10-12T16:00:52+00:00')
assert now < deadline
assert not (out/'receipt.json').exists(), 'Do not overwrite a frozen review receipt'
sha = lambda b: hashlib.sha256(b).hexdigest()
pre = json.loads((out/'PRE_AUTHOR_FREEZE.json').read_text())
for r in pre['sources']:
    assert sha((base/r['relative_path']).read_bytes()) == r['sha256']
for r in pre['pre_author_outputs']:
    assert sha((out/r['relative_path']).read_bytes()) == r['sha256']
identity = json.loads((out/'author_packet_identity_check.json').read_text())
assert sha((packet/'receipt.json').read_bytes()) == identity['author_receipt_sha256']
for r in identity['bound_files']:
    assert sha((packet/r['path']).read_bytes()) == r['sha256']
for r in identity['source_copies']:
    assert sha(Path(r['source']).read_bytes()) == r['sha256']
    assert sha((packet/r['copy']).read_bytes()) == r['sha256']
replay = json.loads((out/'author_baseline_replay.execution.json').read_text())
assert replay['exit_code'] == 0
assert sha((out/'author_baseline_replay.stdout.log').read_bytes()) == replay['stdout_sha256']
assert sha((out/'author_baseline_replay.stderr.log').read_bytes()) == replay['stderr_sha256']
assert sha((packet/'forced_controls.py').read_bytes()) == replay['source_sha256']

coverage = {
    'BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md':[[1,441]],
    'BOOST_CURRENT_EXPECTATION_PROBE.md':[[1,440]],
    'BOOST_CURRENT_INVERSE_ENERGY_PROBE.md':[[1,44],[78,320],[434,520]],
    'EXCLUDED_WALK_BOOST_CURRENT_PROBE.md':[[84,184],[277,324],[488,691]],
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md':[[70,160],[401,485]],
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md':[[1,500]],
    'BOOST_CURRENT_EXPECTATION_REVIEW.md':[[1,186]],
    'boost_expectation_review/PROOF_RECONSTRUCTION.md':[[187,315]],
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md':[[1,140]],
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md':[[1,329]],
}
sources = []
for name, ranges in coverage.items():
    blob = (base/name).read_bytes()
    sources.append({'relative_path':name,'sha256':sha(blob),'lines':len(blob.splitlines()),
                    'read_ranges_counted_in_final_review':ranges})

instruction_main='a13caa4885f547c8d206265b031ba7649e539fd9'
instruction_planning='3a4b2c66a1ead7a1c48b4359627e968f681e3c39'
instruction_paths=['AGENTS.md','CLAUDE.md','docs/ai_methodology/SCIENCE_WORKFLOW.md',
                   'docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md',
                   'docs/ai_methodology/skills/physics-claim-reviewer/SKILL.md',
                   'docs/ai_methodology/skills/physics-loop/references/proof-search-governance.md',
                   'docs/ai_methodology/skills/review-loop/SKILL.md']
instructions=[]
for ref,path in [(instruction_main,p) for p in instruction_paths]+[(instruction_planning,'AGENTS.md')]:
    blob=subprocess.check_output(['git','show',ref+':'+path],cwd=repo)
    instructions.append({'ref':ref,'path':path,'sha256':sha(blob),
                         'coverage':'applicable source read; review-loop focused review/model boundary sections only' if path.endswith('review-loop/SKILL.md') else 'complete source read'})

final_state={'checked_utc':now.isoformat(),'all_target_premise_and_author_evidence_hashes_unchanged':True,
             'pre_author_reconstruction_and_controls_unchanged':True,
             'science_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
             'worktree_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),
             'before_deadline':True}
(out/'final_identity_check.json').write_text(json.dumps(final_state,indent=2)+'\n')
files=[]
paths=[base/'BOOST_KERNEL_EFFECTIVE_DYNAMICS_REVIEW.md']+sorted(p for p in out.iterdir() if p.is_file() and p.name not in {'receipt.json','receipt_freeze.log'})
for p in paths:
    blob=p.read_bytes()
    files.append({'path':str(p.relative_to(base)),'sha256':sha(blob),'bytes':len(blob),'lines':len(blob.splitlines())})
receipt={'schema':'boost-forcing-independent-review-v1','frozen_utc':now.isoformat(),
         'review_outcome':'PASS for exact conditional supplied-model K1-K19; no required source correction',
         'review_scope':'complete frozen 441-line argument and necessary exact original premises; selective independent review, not formal audit',
         'target_sha256':pre['candidate_sha256'],'author_receipt_sha256':identity['author_receipt_sha256'],
         'pre_author_freeze_sha256':sha((out/'PRE_AUTHOR_FREEZE.json').read_bytes()),
         'source_coverage':sources,'instructions':instructions,'reviewer_files':files,
         'final_source_check':final_state,'deadline_utc':deadline.isoformat(),
         'model_and_effort':'inherited user-selected configuration without override',
         'subdelegation':False,'required_corrections':[],'open_obligations_within_reviewed_K_scope':[],
         'outside_scope':['lambda convergence rate','growing-tau or exchanged-limit theorem','total-state probabilities','weighted-current asymptotics','full boost algebra','physical identification','separate quantitative-corrector work','formal retained status','global audit'],
         'changed_editable_prompts':[], 'repository_mutations':[],
         'independent_control_command':pre['independent_control_command'],
         'independent_control_exit_code':pre['independent_control_exit_code'],
         'author_identity_command':'python3 verify_author_packet.py > author_packet_verification.log 2>&1',
         'author_identity_exit_code':0,'author_baseline_replay':replay,
         'failed_or_incomplete_events':[{'event':'author baseline attempt one','outcome':'120-second timeout; original evidence unchanged'},
                                      {'event':'reviewer inventory wc on a directory','outcome':'exit 1; intended subsequent source read rerun separately'},
                                      {'event':'optimization diff command','outcome':'exit 1 denotes inspected differences, not test failure'}],
         'independence_limits':'Candidate itself read before reconstruction. Author evidence and prior reviewer outcomes first opened after PRE_AUTHOR_FREEZE. Finite controls and byte verification do not prove continuum theorems.',
         'reading_limits':'Parent complete expectation/bracket theorem and unrelated publication-note arguments not recertified; counted source ranges recorded explicitly.',
         'no_remote_freshness_claim':True,'no_lean_certification_claim':True,
         'output_binding':'Receipt does not include itself or its post-freeze stdout. All scientific outputs and final identity evidence above are bound without a circular self-hash.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
review_row=files[0]
print(json.dumps({'review_sha256':review_row['sha256'],
                  'receipt_sha256':sha((out/'receipt.json').read_bytes()),
                  'reconstruction_sha256':pre['pre_author_outputs'][0]['sha256'],
                  'candidate_sha256':pre['candidate_sha256'],
                  'final_state':final_state,'reviewer_file_count':len(files)},indent=2))
