#!/usr/bin/env python3
"""Author controls for the polynomial refinement; no continuum certification."""
import json
import numpy as np
import scipy
from scipy.integrate import quad_vec
from scipy.linalg import expm
import sympy as sp

names = []


def check(name, condition):
    assert bool(condition), name
    names.append(name)
    print('checked', name, flush=True)


def matrix_zero(name, value):
    check(name, all(sp.simplify(entry) == 0 for entry in value))


J = sp.Matrix([[0, -sp.I], [sp.I, 0]])
matrix_zero('tangent_generator_Hermitian', J.H-J)
matrix_zero('tangent_generator_square', J*J-sp.eye(2))
om, dom = sp.symbols('om dom', real=True)
matrix_zero('pointwise_parameter_commutator', (om*J)*(dom*J)-(dom*J)*(om*J))

pauli = [sp.Matrix([[0, 1], [1, 0]]), J, sp.diag(1, -1)]
p1 = [sp.kronecker_product(p, sp.eye(2)) for p in pauli]
p2 = [sp.kronecker_product(sp.eye(2), p) for p in pauli]
singlet = sp.Matrix([0, 1, -1, 0])/sp.sqrt(2)
triplets = sp.Matrix.hstack(*[p*singlet for p in p1])
k1, k2, k3 = sp.symbols('k1 k2 k3', real=True)
dd = sp.Matrix([k1, k2, sp.sqrt(3)*k3/2])
pauli_B = triplets.H*sum(((p1[j]+p2[j])*dd[j]/2 for j in range(3)), sp.zeros(4))*triplets
g_exact = sp.Matrix([sp.I*k2, -sp.I*k1])
block = (dd[2]*J).row_join(g_exact)
block = block.col_join(g_exact.H.row_join(sp.zeros(1)))
matrix_zero('direct_Pauli_transverse_block', pauli_B-block)

time_symbol = sp.symbols('time_symbol', nonnegative=True)
L = sp.Rational(192, 7)
mr = sp.Integer(406)


def nonnegative_polynomial(name, expression):
    poly = sp.Poly(sp.expand(expression), time_symbol)
    check(name, all(c >= 0 for c in poly.all_coeffs()))


nonnegative_polynomial('weighted_z_polynomial_constant',
                       mr*(1+time_symbol)-12*(1+time_symbol/4))
nonnegative_polynomial('weighted_zj_polynomial_constant',
                       2*mr*(1+time_symbol)**2
                       -12*(L+3+(2+(L+3)/4)*time_symbol+time_symbol**2/4))
nonnegative_polynomial('weighted_zt_polynomial_constant',
                       mr*(1+time_symbol)-(12+sp.Rational(3, 2)*time_symbol))
nonnegative_polynomial('weighted_zjt_polynomial_constant',
                       4*(1+time_symbol)**2-((1+time_symbol)**2+3*(1+time_symbol)))
nonnegative_polynomial('residual_polynomial_constant',
                       3*(1+time_symbol)-(sp.Rational(5, 2)+time_symbol/2))
nonnegative_polynomial('residual_jt_polynomial_constant',
                       6*(1+time_symbol)**2-(4*(1+time_symbol)+2*(1+time_symbol)**2))

# A single antipodal pair at q=(0,0,pi/6): finite I0=1, zeta=e3.
# Its three-dimensional block is only an algebra fixture; it has recurrence.
jn = np.array(J, complex)
kbase = np.array([1/8, -1/12, 1/16])
kslope = np.array([1/3, 1/5, 1/7])
zeta = np.array([0, 0, 1], complex)


def data(theta):
    kval = kbase+theta*kslope
    dvec = kval*np.array([1, 1, np.sqrt(3)/2])
    derivative = kslope*np.array([1, 1, np.sqrt(3)/2])
    dop = dvec[2]*jn
    dj = derivative[2]*jn
    coupling = np.array([1j*dvec[1], -1j*dvec[0]])
    gj = np.array([1j*derivative[1], -1j*derivative[0]])
    operator = np.zeros((3, 3), complex)
    operator[:2, :2] = dop
    operator[:2, 2] = coupling
    operator[2, :2] = coupling.conj()
    return operator, dop, dj, coupling, gj


def forced(time, theta=0.0):
    operator = data(theta)[0]
    frequency = 2+theta/7
    amplitude = (1+theta/5)*(3/10+theta/20)
    return amplitude*np.linalg.solve(frequency*np.eye(3)-operator,
                (expm(-1j*time*operator)-np.exp(-1j*time*frequency)*np.eye(3))@zeta)


def derivative(function):
    hh = 1e-4
    return (-function(2*hh)+8*function(hh)-8*function(-hh)+function(-2*hh))/(12*hh)


operator, dop, dj, g, gj = data(0.0)
state_errors, derivative_errors = [], []
for time in [-2.2, 0.4, 3.1]:
    def source_integrand(ss):
        return expm(-1j*(time-ss)*dop)@g*forced(ss)[2]

    u_integral = -1j*quad_vec(source_integrand, 0, time, epsabs=1e-12, epsrel=1e-12)[0]
    state_errors.append(float(np.linalg.norm(u_integral-forced(time)[:2])))
    check(f'transverse_block_integral_t_{time}', state_errors[-1] < 1e-10)

    def differentiated_integrand(ss):
        ud = expm(-1j*(time-ss)*dop)
        alpha = forced(ss)[2]
        alpha_j = derivative(lambda th: forced(ss, th))[2]
        propagator_term = (-1j*(time-ss)*dj)@ud@g*alpha
        coupling_term = ud@gj*alpha
        amplitude_term = ud@g*alpha_j
        return propagator_term+coupling_term+amplitude_term

    from_integral = -1j*quad_vec(differentiated_integrand, 0, time, epsabs=1e-11, epsrel=1e-11)[0]
    from_state = derivative(lambda th: forced(time, th))[:2]
    derivative_errors.append(float(np.linalg.norm(from_integral-from_state)))
    check(f'transverse_three_derivatives_t_{time}', derivative_errors[-1] < 1e-8)

print(json.dumps({'controls_completed':len(names), 'max_state_error':max(state_errors),
                  'max_derivative_error':max(derivative_errors), 'finite_I0':1,
                  'numpy':np.__version__, 'scipy':scipy.__version__, 'sympy':sp.__version__,
                  'scope':'author coefficient and finite-block controls; no continuum proof or independent review'}, indent=2))
