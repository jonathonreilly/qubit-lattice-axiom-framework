#!/usr/bin/env python3
"""Actually execute three one-term omissions in the transverse derivative."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

packet = Path(__file__).resolve().parent
source = (packet/'polynomial_controls.py').read_text()
specs = [
    ('transverse_propagator_derivative', 'propagator_term = (-1j*(time-ss)*dj)@ud@g*alpha',
     'propagator_term = np.zeros(2, complex)'),
    ('transverse_coupling_derivative', 'coupling_term = ud@gj*alpha',
     'coupling_term = np.zeros(2, complex)'),
    ('transverse_alpha_derivative', 'amplitude_term = ud@g*alpha_j',
     'amplitude_term = np.zeros(2, complex)'),
]
assert not (packet/'polynomial_mutation_manifest.json').exists()
rows = []
for name, before, after in specs:
    assert source.count(before) == 1
    changed = source.replace(before, after, 1)
    paths = {key:packet/f'mutant_{name}{ext}' for key,ext in
             [('source','.py'),('stdout','.stdout.log'),('stderr','.stderr.log'),('execution','.execution.json')]}
    assert not any(p.exists() for p in paths.values())
    paths['source'].write_text(changed)
    command=[sys.executable,str(paths['source'])]
    started=time.monotonic(); result=subprocess.run(command,capture_output=True,timeout=120)
    paths['stdout'].write_bytes(result.stdout); paths['stderr'].write_bytes(result.stderr)
    expected='transverse_three_derivatives_t_-2.2'
    row={'name':name,'before':before,'after':after,'command':command,'timeout_seconds':120,
         'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,
         'utc':datetime.now(timezone.utc).isoformat(),'expected_assertion':expected,
         'caught_at_intended_check':result.returncode==1 and f'AssertionError: {expected}' in result.stderr.decode(),
         'baseline_sha256':hashlib.sha256(source.encode()).hexdigest(),
         'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),
         'paths':{k:p.name for k,p in paths.items()}}
    paths['execution'].write_text(json.dumps(row,indent=2)+'\n'); rows.append(row)
(packet/'polynomial_mutation_manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows: print(row['name'],row['exit_code'],row['caught_at_intended_check'])
assert all(row['caught_at_intended_check'] for row in rows)
