# Proposed polynomial refinement of the H* corrector bound

Root research lead, 2026-10-12. This is a proposed derivation for the active
corrector author to check, not a published theorem or independent review.
Preserve the earlier exponential-bound route if this stronger estimate fails.
K1–K19 now has a completed separate source review; exact sources are in
BOOST_KERNEL_EFFECTIVE_DYNAMICS_REVIEW.md and boost_forcing_review/receipt.json.

The generic weighted Banach bound exp(T/2) may be avoidable for this actual
source. Use the exact block and the off-frequency solution, rather than a
Gronwall estimate on all weighted initial data.

Write the actual effective solution as z=u+alpha*zeta, u in F_tr. K gives
z=exp(-itau A)v-r with a uniformly bounded Hilbert norm, and its resolvent/IBP
proof appears to give the following pointwise-in-kappa bounds on the compact
support (these must be extracted and checked, not inferred from an integrated
H1 statement alone):

    ||z(tau,kappa)|| <= C |F(kappa)|,
    ||partial_j z(tau,kappa)||
      <= C (|F(kappa)|+|partial_j F(kappa)|)(1+|tau|).

Here v=C(kappa)chi_kappa(A)zeta is smooth in operator-norm parameters before
multiplication by F; derivatives of exp(-itau A) cost |tau|. The remainder
has bounded pointwise parameter derivatives by the uniform radial-IBP proof,
including |tau|<=1. Thus alpha=<zeta,z> and its derivatives obey those bounds.

The transverse equation has no direct source term:

    i u' = D_kappa u + g_kappa alpha,  u(0)=0,
    u(tau) = -i integral_0^tau exp[-i(tau-s)D] g alpha(s) ds.

D=omega J is pointwise Hermitian and its propagator preserves each pointwise
transverse norm. Also

    esssup_q epsilon|g| <= |kappa|/(2 sqrt(I0)),
    esssup_q epsilon|partial_j g| <= 1/(2 sqrt(I0)),
    epsilon|zeta| = 1/(2 sqrt(I0)).

D and partial_j D commute pointwise because both are scalar multiples of
the same tangent J; hence the kappa derivative of its propagator costs at
most |tau-s|. No separate parity-violating helicity subspace is needed.
The preceding integral therefore suggests

    ||z||_weighted <= C |F|(1+|tau|),
    ||partial_j z||_weighted
       <= C (|F|+|partial_j F|)(1+|tau|)^2,

where ||a||_weighted=esssup epsilon|a|. These statements follow from this
particular integral, so they need no global weighted-space generator theorem.
Differentiate the exact effective ODE to obtain the corresponding time and
mixed time/kappa bounds. The source and its first kappa/time derivatives
have at most the explicit low polynomial tau factors from the free phase.

Then r=Q(Bz-g_source) should have weighted size O((1+T)), its first kappa
derivative O((1+T)^2), and the same respective degrees for their time
derivatives. The truncated physical-singlet corrector with delta=lambda
could give

    sup_|tau|<=T ||W_lambda-z||_L2 <= C sqrt(lambda)(1+T)^2,
    sup_|tau|<=T ||W_lambda-z||_H1 <= C sqrt(lambda)(1+T)^3,

after retaining E_lambda z, g-g_lambda, both endpoints, the bounded
noncommuting perturbation and the (partial_j G_lambda)D term. The exact
lambda-source errors must be checked for arbitrary T with explicit powers:
|exp(-itau e_lambda)-exp(-itau e)|<=|tau||e_lambda-e|
remains valid without assuming lambda²T small, but derivatives add powers.
These displayed global T bounds are candidates, not yet accepted results.

If verified, the H1 convergence window would allow T=lambda^(-eta) for
0<eta<1/6, instead of only logarithmic T. The L2 estimate alone might allow
0<eta<1/4 for the simultaneous K correction-norm/transverse occupation limit.
Do not state either exponent before checking all omitted terms. Boost
expectations require their own decomposition; keep Hilbert and weighted
norms distinct and avoid an unnecessary product of two H1 norms. The old
operator-norm residual obstruction still survives.

The decisive new ingredient is the actual off-frequency source's bounded
effective Hilbert norm. This does not improve a theorem for arbitrary
weighted initial data, does not create a gap in H*, and does not justify
derivatives in q of zeta.
