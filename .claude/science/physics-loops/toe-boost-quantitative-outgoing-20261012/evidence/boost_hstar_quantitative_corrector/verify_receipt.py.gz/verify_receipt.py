#!/usr/bin/env python3
"""Verify the frozen Q bytes and execution provenance; no science verdict."""
import hashlib
import json
from pathlib import Path
import subprocess


def check_bytes(blob, expected, label):
    actual=hashlib.sha256(blob).hexdigest()
    if actual!=expected:
        raise ValueError(f'hash mismatch: {label}: {actual} != {expected}')


def main():
    packet=Path(__file__).resolve().parent
    receipt=json.loads((packet/'receipt.json').read_text())
    assert receipt['schema']=='boost-hstar-quantitative-corrector-receipt-v1'
    assert Path(receipt['packet_path']).resolve()==packet
    assert receipt['mathematical_status']=='conditional-author-result; independent-review-pending'
    bound=receipt['files']; names=[r['path'] for r in bound]
    assert len(names)==len(set(names)), 'duplicate binding'
    note=packet.parent/'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md'
    for row in bound:
        path=(packet/row['path']).resolve()
        assert path==note or packet in path.parents
        blob=path.read_bytes();check_bytes(blob,row['sha256'],row['path'])
        assert len(blob)==row['bytes'] and len(blob.splitlines())==row['lines']
    eligible={'../'+note.name}|{p.relative_to(packet).as_posix() for p in packet.rglob('*')
        if p.is_file() and p.relative_to(packet).as_posix() not in receipt['excluded_post_freeze_outputs']
        and '__pycache__' not in p.parts}
    assert eligible==set(names), 'unbound or missing pre-freeze file'
    print(f'Bound source/evidence files: {len(bound)} matched; inventory exact')

    sources=json.loads((packet/'source_manifest.json').read_text())
    for row in sources:
        original=Path(row['source']).read_bytes();copy=(packet/row['copy']).read_bytes()
        check_bytes(original,row['sha256'],row['source']);check_bytes(copy,row['sha256'],row['copy'])
        assert original==copy and len(original)==row['bytes'] and len(original.splitlines())==row['lines']
    print(f'Original sources and complete copies: {len(sources)} matched')

    instructions=json.loads((packet/'instruction_manifest.json').read_text())['items']
    for row in instructions:
        blob=subprocess.run(['git','show',f"{row['ref']}:{row['path']}"],
             cwd=receipt['read_only_worktree'],capture_output=True,check=True).stdout
        check_bytes(blob,row['sha256'],row['path'])
    print(f'Read-only exact-ref instructions: {len(instructions)} matched')

    baselines=[('corrector_controls.py','baseline',27),('polynomial_controls.py','polynomial_baseline',16),
               ('mean_controls.py','mean_baseline',8)]
    for script,stem,count in baselines:
        execution=json.loads((packet/(stem+'.execution.json')).read_text())
        assert execution['exit_code']==0
        check_bytes((packet/script).read_bytes(),execution['source_sha256'],script)
        assert execution['command'][1]==str(packet/script)
        assert (packet/(stem+'.stderr.log')).read_text()==''
        assert f'"controls_completed": {count}' in (packet/(stem+'.stdout.log')).read_text()
    print('Three successful baseline records: executed script identities and complete logs matched')

    nmutants=0
    for manifest,script in [('mutation_manifest.json','corrector_controls.py'),
                            ('polynomial_mutation_manifest.json','polynomial_controls.py')]:
        baseline=(packet/script).read_text()
        for row in json.loads((packet/manifest).read_text()):
            assert baseline.count(row['before'])==1, row['name']
            changed=(packet/row['paths']['source']).read_text()
            assert changed==baseline.replace(row['before'],row['after'],1),row['name']
            check_bytes(baseline.encode(),row['baseline_sha256'],script)
            check_bytes(changed.encode(),row['mutant_sha256'],row['name'])
            assert row['exit_code']==1 and row['caught_at_intended_check']
            assert json.loads((packet/row['paths']['execution']).read_text())==row
            assert f"AssertionError: {row['expected_assertion']}" in (packet/row['paths']['stderr']).read_text()
            nmutants+=1
    print(f'Literal defect sources and intended recorded failures: {nmutants} matched')

    saved=json.loads((packet/'EXPONENTIAL_BOUND_SNAPSHOT.json').read_text())
    check_bytes((packet/saved['path']).read_bytes(),saved['sha256'],'preserved exponential proof')
    assert saved['sha256']==receipt['preserved_exponential_proof_sha256']
    upstream=json.loads((packet/'upstream_K_review_identity.json').read_text())
    check_bytes((packet.parent/'boost_forcing_review/receipt.json').read_bytes(),
                upstream['review_receipt_sha256'],'selective K review receipt')
    for row in upstream['artifact_bindings']:
        blob=(packet.parent/row['path']).read_bytes()
        check_bytes(blob,row['sha256'],row['path']);assert len(blob)==row['bytes']
    print(f'Preserved exponential proof and {len(upstream["artifact_bindings"])} selective K review bindings matched')

    nr=next(r for r in bound if r['path']=='../'+note.name)
    tampered=bytearray(note.read_bytes());tampered[0]^=1
    try:check_bytes(bytes(tampered),nr['sha256'],'in-memory one-byte tamper')
    except ValueError:print('In-memory one-byte tamper rejected; original unchanged')
    else:raise AssertionError('tamper accepted')
    print('Receipt byte/provenance verification complete; no scientific or audit verdict')

if __name__=='__main__':main()
