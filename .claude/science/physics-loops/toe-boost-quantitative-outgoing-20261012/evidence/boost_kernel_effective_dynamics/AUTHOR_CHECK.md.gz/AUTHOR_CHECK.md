# Author checks and verification limits

This packet is authored research. The alternate derivations and controls
below check algebra by different arrangements; they do not constitute a
fresh-context independent scientific review. The user-selected model and
reasoning effort were inherited without override and no subagent was used.

## Load-bearing proof checks

1. **Sign and initial condition.** K8 was first obtained by integrating the
   bounded propagator against one forcing exponential. Separately, for
   `Y(t)=(e-A)^(-1)(exp(-itA)-exp(-ite))zeta`, direct differentiation gives
   `Y(0)=0` and `iY'=AY-exp(-ite)zeta`. Bounded ODE uniqueness then fixes
   the same vector. A mistaken source sign fails this independent algebraic
   arrangement. At t=0 the dressed vector and its transient cancel exactly.

2. **Actual preparation and denominator.** The source radial support is
   `[5/8,3/4]`, the actual F support lies inside `|kappa|<=65/512<1/4`, and
   `e=|x+kappa/2|+|x-kappa/2|`. Thus e>=5/4 while ||A||<=1/4. The real
   inverse is uniformly bounded by one. The upper bound e-E<=2 and positive
   w in [1/4,1/2] give m_f/8<=chi<=m_f/2. There is no factor of lambda,
   normalized-torus q measure or fiberwise normalization in this Lebesgue
   source integral. C(kappa)=c0 F/(Z0 sqrt(I0)) retains the exact X factors.

3. **Rapid remainder, independent arrangement.** The direct method is radial
   Hilbert-valued integration by parts, with e_r>=4/3 and amplitude flat at
   both endpoints. The recursive amplitude norms in K13 define finite
   constants for any specified power. For the first kappa derivative, the
   phase derivative costs one t, compensated by one extra radial integration
   by parts. Operator-resolvent derivatives are bounded because e-A>=1.
   A separate time-domain arrangement first proves rapid scalar-source decay,
   then integrates its tail in the interaction picture. It gives the same
   outgoing vector, via a bounded Abel resolvent limit, and the same H1
   conclusion. No inverse on the nonzero H_* complement enters either route.

4. **Spectral measure and limit order.** Positive bounded chi reweights the
   existing dressing measure by chi squared, so the actual dressed vector
   has the same spectral measure class where F!=0. The prior E23 continuum
   result, not a finite fixture, supplies absolute continuity for kappa!=0.
   The one exceptional zero fiber is retained and removed only by Lebesgue
   dominated convergence in the global packet. The original dynamics enter
   only through X23 at each fixed tau. No step permits a growing tau(lambda)
   schedule, actual-state probability interpretation of the correction norm,
   or a pointwise spectral decay rate for the surviving dressed amplitude.

5. **Parity and domain.** J=i n cross and its helicity projectors act
   pointwise; J alone changes the triplet parity. The combination omega J
   and its full functional calculus preserve odd parity. K4 uses the
   spectral theorem for the global self-adjoint D, not separate parity-
   violating helicity Hilbert spaces. Only bounded operators and kappa
   derivatives act on the singular L2 vector zeta.

The full final note was read after these checks, including its source
comparison, definitions, all formulas K1–K19, proof, scope and evidence prose.
No unresolved mathematical step is identified inside the stated conditional
theorem. This is an author assessment pending the supervisor's distinct check.

## Disjoint finite arithmetic and actual executions

`forced_controls.py` imports no previous campaign helper. Its finite model
has two weighted antipodal pairs, exact rational sine/cosine data and actual
4-by-4 Pauli matrices. An 8-dimensional antisymmetric representation is
compressed by the global contact projection, then by its complete physical
kernel. The fixture value I=17/36 is explicitly a finite weighted sum, not a
torus integral. The direct compression reconstructs both off-diagonal
couplings and is compared with the independent helicity scalar inverse.

For the new forced identity, exact Taylor derivatives from the source ODE
are compared with real-resolvent derivatives through order seven, using two
distinct positive frequencies. This tests the initial cancellation and
source sign without a numerical time integration. The conservative support,
radial derivative and spectral-weight constants also have exact scalar
controls.

A separate floating route uses a Hermitian eigendecomposition and integrates
the original time-dependent forcing. It is compared to the closed formula
built with dense matrix exponentials and linear solves at five positive,
zero and negative times. The largest discrepancy was
`7.079420107788696e-16`. Its five-point parameter derivative is compared
with the formula's Frechet exponential derivative, resolvent derivative,
source-amplitude derivative and source-clock derivative; the largest
discrepancy was `2.846874235784871e-12`.

The source spectral chi-squared weight is checked against the directly
computed dressed vector. A resonant scalar ODE supplies a separate
hypothesis diagnostic: when e equals A, the actual response
`i t exp(-ite)` has norm |t|. That finite example is outside the actual
forcing gap; it shows why the bounded real-resolvent formula cannot be used
at resonance. It is not a counterexample to the torus theorem.

The first complete invocation had a 120-second timeout. It completed all
checks through the exact fifth derivative, then timed out while redundantly
recomputing exact inverses and expanding higher derivatives. Its exact
source is `forced_controls_attempt1.py`, with full `baseline.stdout.log`,
empty `baseline.stderr.log`, and execution metadata. A timeout is an
incomplete run, not a mathematical failure or a passing result.

The repair caches the two exact inverses and recursively simplifies the
matrix/ODE powers. It changes no input, asserted derivative order, formula,
assertion, constant, or tolerance. The second run completed all 38 controls
with exit 0 in 23.803 seconds under the same 120-second limit. Its stdout,
empty stderr and metadata are in `baseline_attempt2.*`. The final source
hash is recorded in the receipt. Runtime versions were Python 3.13.5,
SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1.

Five literal source-copy defects actually exited 1 at their designated
assertions: reversing the Schur sign, reversing the forced real-resolvent
sign, reversing the Duhamel source sign, omitting the source phase
derivative, and replacing chi squared by chi in the spectral weight.
Every complete stdout/stderr log was read, and each altered source was
verified to differ by exactly the saved one-occurrence replacement. The
manifest records the commands, timeouts, source hashes and exit codes.
No failed run was overwritten. These failures establish only that the
specific controls distinguish those mistakes.

There is no torus grid, extrapolation or fitted constant in this helper.
Neither exact finite arithmetic nor floating ODE agreement proves the
continuum spectral or nonstationary-phase argument. Those remain the
analytic arguments and source-bound dependencies described above.

Reproduce the finite baseline with fresh output paths:

```text
/opt/homebrew/opt/python@3.13/bin/python3.13 /Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_kernel_effective_dynamics/forced_controls.py
```

`run_mutations.py` deliberately refuses to overwrite its original evidence.
The receipt verifier checks source identities separately from mathematics
and includes a non-mutating one-byte-tamper rejection control. It grants
no mathematical or audit status.
