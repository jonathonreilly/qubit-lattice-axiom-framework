# Current recovery checkpoint

Bounded author task completed, independent check pending. Fixed campaign
deadline: 2026-10-12 16:00:52 UTC. No extension was requested or performed.
This checkpoint supersedes the initial candidate-route checkpoint; the
original sources, unsuccessful compute attempt and defect copies remain
preserved in this packet.

The result is `../BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md`, K1–K19. Its
final bytes and all pre-freeze evidence are bound by `receipt.json`; verify
with `verify_receipt.py`. Later receipt-verification logs are bound by their
execution metadata, without a circular receipt self-hash. The ten fully read original source identities and
byte-for-byte copies are in `source_manifest.json`. The read-only exact
instruction refs are in `instruction_manifest.json`. The supplied worktree
was at 47cb1150396d0ed387f7ee6bd157dda156713f9e; no Git mutation occurred.

Prior-art correction: D6 already proved the multiplication block plus
rank-two coupling. The prior memory theorem in #9481 already supplied the
scalar bath/resolvent and source absolute continuity; #9482 supplied further
edge/mean-survival estimates. These are credited premises, not new claims.
`PRIOR_ART.md` records exact PR heads, source hashes and search limitations.

The genuinely additional bounded result retains the actual X preparation:
the positive source frequency e is at distance at least one above sigma(A)
on the enclosing kappa ball. Thus z(t)=exp(-itA)v-r(t), with
v=C chi(A)zeta, chi(E)=integral f w/(e-E), and m_f/8<=chi<=m_f/2.
Radial Hilbert-valued integration by parts proves that r, and the
interaction-picture error, decrease faster than every inverse power in
H1_kappa. The dressed measure is |C|^2 chi^2 times the already-established
source measure. It yields a nonzero global limiting correction norm and
lambda-first ordered limits. No lambda convergence rate, growing-tau
schedule, whole-state probability, weighted-current limit, or new physical
identification follows.

Checks: the note was cold-read completely; its final scope sentence was
then tightened to avoid suggesting absolute continuity is a necessary
condition for arbitrary decay. Direct one-frequency ODE differentiation
independently checks the convolution sign and zero initial condition.
The time-domain tail method checks the outgoing state. Disjoint finite
Pauli/ODE arithmetic completed 38 controls; five literal defect copies
actually failed at their intended checks. All full logs were read. The
first 120-second timeout and original code were preserved; the successful
repair only cached inverses and simplified recursive exact powers.
`AUTHOR_CHECK.md` gives errors, hypotheses, reproducibility and limits.
These are author checks, not distinct scientific review.

Open obligations: no unresolved proof step is identified by this author
inside the conditional K theorem. The supervisor's distinct scoped check
must still inspect K8 sign/normalization, actual support, H1 radial bounds,
prior-measure reuse and the order of limits. Any quantitative actual-lambda
theorem needs a separate H_* residual estimate. The supervisor's later
approximate-corrector proposal is deliberately excluded from this frozen
result and is not assessed here.

Preserved failures and scope limits: mixed-band obstruction, nonzero
differential-bracket coefficient, diagonal norm obstruction, cone-driven
unit-ball nonuniformity, finite-bath recurrence and resonant forced growth
outside the source-gap hypotheses. No false scalar dispersion or two-level
closure was introduced. No editable prompt, frozen source, worktree, PR,
audit status or physical axiom changed; no subagent or model override used.

Next action: deliver frozen note and receipt identities to the supervisor
for a distinct scoped review. New work requires a separate bounded dispatch.
