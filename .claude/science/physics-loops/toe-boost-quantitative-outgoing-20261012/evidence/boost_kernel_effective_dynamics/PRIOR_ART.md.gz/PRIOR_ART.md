# Source comparison and target selection

This is a bounded research dispatch, not a repository-wide novelty survey.
The worktree HEAD supplied by the supervisor is
`47cb1150396d0ed387f7ee6bd157dda156713f9e`. The read-only stored main ref
used for the initial search is `a13caa4885f547c8d206265b031ba7649e539fd9`;
the planning ref is `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. No git ref
was fetched or changed by this worker. Current open-PR metadata was queried
read-only through gh and saved as JSON.

The initial five exact sources supplied in the dispatch were read completely.
A distinctive-statement search then found the prior D6 block in the external
degenerate-dynamics note. The complete 549-line source, complete 375-line
review, and author receipt were read. Its directory has no checkpoint file;
the attempted checkpoint read reported that absence and no replacement was
created in the frozen directory. Its receipt is the recovery index.

The initial main search used the regular expression recorded in
`prior_statement_search.json`; all 116 result lines are in
`prior_statement_search.log`. Most matches refer to source-action premises,
other finite-spectrum carriers, or unrelated dressing terminology. They
do not supply a statement about this walk's Pi B Pi and the X source.
No absence claim rests on the initially truncated display: the full output
was saved and the separate existing campaign sources were searched directly.

The stored planning inventory was read. It describes the earlier original254
cutoff and does not inventory these October PRs. It was therefore not used as
a current open-work authority. Live searches for “excluded”, “zero space”,
“memory”, “Friedrichs”, and “source-cyclic” are saved. The latter two gave
no results, but the “memory” result exposed the decisive actual prior art.

The bodies, heads, primary path maps, and discussion counts for #9479,
#9480, #9481, #9482, and #9484 were inspected. There were zero comments and
zero review records in these saved responses. Git's complete primary path
delta was used for #9481/#9482 because gh's files response was capped at
100 paths. Their known source mapping is:

| PR and head | Relevant scope |
|---|---|
| #9479, `b9b032ae790c66e762a6296a1306bfb64ae7cd70` | Supplied walk and canonical current, scattering/preparation |
| #9480, `20ec94848ad264f3167db33028e98399c5c17dd9` | Scattering flux/form; no premise for this note |
| #9481, `d8480b5a6e04102ff076b3dd6f817a2d43f20252` | Prior degenerate block, memory measure and resolvent, outgoing transverse state, distinct preparation/current results |
| #9482, `ba74c93aab9185d62a9711695dc931446f67c8ba` | Prior edge inverse moment and quantitative mean survival; distinct prepared-packet transfer |
| #9484, `47cb1150396d0ed387f7ee6bd157dda156713f9e` | Boost brackets and sharp norm threshold; its body explicitly excludes the then-ongoing X expectation derivation |

The complete 500-line effective-memory source and complete 329-line review
were then read. They already supply the exact scalar resolvent, helicity
bath measure, cone lower bound, source-measure absolute continuity and
endpoint exclusion. Repeating those as a new theorem was rejected. The
review also records an independent analytic proof of bath absolute
continuity, so that additional route was not presented as new either.

Targeted phrase searches of the actual primary source at the exact #9481
and #9482 heads are in `published_source_search_9481.json` and
`published_source_search_9482.json`. The memory note at #9481 has hash
`3954606703f9a66665fb1ee9a27079f7f14e5183f28a8511a38743ef5d455aa1`;
the quantitative note at #9482 has hash
`69745b81cfbfb6676faa99e9e5491ddc94a8afdb97049802861a7b105bb711d9`.
The inspected source sections and searches distinguish their homogeneous
dressing/preparation problems from X's annular smooth inhomogeneous source.
These are scope comparisons, not complete reviews of those 1575- and
758-line publication notes or their entire transitive chains.

The supervisor approved this narrowing: derive the actual X forced vector
using its off-spectrum frequencies, keeping effective large-time and
original-walk lambda limits distinct. No global priority claim is made.

Approach disposition:

| Family | Mechanism and terminal obligation | Disposition |
|---|---|---|
| Zero-space block | Pauli cross product and tangent projection | Already supplied by D6; rederivation only |
| Source spectral measure | Schur resolvent, cone positivity, Poisson domination | Already supplied by memory E8–E23; reuse with exact sources |
| Actual X-source response | Positive annular frequencies separated from sigma(A); solve exact forced ODE and identify its outgoing state | New bounded target, developed in K6–K19 |
| Uniform lambda error | Quantify nonzero H_* spectral mass of Q(Bz-g) and derivatives | Not inferred from A's forcing gap; remains outside this packet |

The spectral block belongs to the classical bounded Friedrichs setting.
The primary publication metadata for K. O. Friedrichs, *On the perturbation
of continuous spectra*, Communications on Pure and Applied Mathematics 1
(1948), 361–406, DOI `10.1002/cpa.3160010404`, was checked at the publisher.
An attempted open of a modern primary Friedrichs–Lee paper at DOI
`10.1063/5.0013032` failed at the publisher redirect. No theorem from either
paper is imported. The mathematical tools actually used are bounded
spectral calculus, bounded ODE uniqueness, Hilbert-valued integration,
integration by parts, and dominated convergence, with hypotheses in the note.

The count of searches, sources, controls or prior reviews has no independent
scientific weight. Exact new proof coverage is still required.
