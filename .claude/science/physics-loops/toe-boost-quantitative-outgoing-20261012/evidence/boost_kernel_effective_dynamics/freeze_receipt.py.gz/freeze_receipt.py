#!/usr/bin/env python3
"""One-time exact byte freeze for the bounded K author result."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


packet = Path(__file__).resolve().parent
receipt_path = packet / "receipt.json"
assert not receipt_path.exists(), "refusing to overwrite a frozen receipt"
excluded = {
    "receipt.json", "receipt_freeze.stdout.log", "receipt_freeze.stderr.log",
    "receipt_freeze.execution.json", "receipt_verification.stdout.log",
    "receipt_verification.stderr.log", "receipt_verification.execution.json",
}
paths = [packet.parent / "BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md"]
paths += sorted(p for p in packet.rglob("*")
                if p.is_file() and p.name not in excluded and "__pycache__" not in p.parts)
files = []
for path in paths:
    blob = path.read_bytes()
    name = "../BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md" if path == paths[0] else str(path.relative_to(packet))
    files.append({"path": name, "sha256": hashlib.sha256(blob).hexdigest(),
                  "bytes": len(blob), "lines": len(blob.splitlines())})
receipt = {
    "schema": "boost-kernel-effective-dynamics-receipt-v1",
    "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
    "campaign_deadline_utc": "2026-10-12T16:00:52+00:00",
    "packet_path": str(packet),
    "read_only_worktree": "/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/boost_worktree",
    "supplied_worktree_head": "47cb1150396d0ed387f7ee6bd157dda156713f9e",
    "mathematical_status": "conditional-author-result; independent-review-pending",
    "new_claim_scope": "K8-K19 actual X off-spectrum forcing, resolvent dressing, rapid effective-time H1 remainder, positive reweighting and lambda-first ordered correction limits",
    "prior_results_not_new": ["D6 multiplication block and finite-rank coupling", "memory E8-E23 bath/resolvent and dressing measure absolute continuity"],
    "no_lambda_rate": True,
    "author_open_proof_obligations": [],
    "independent_check_pending": ["K8 sign and normalization", "actual source supports and gap", "H1 radial estimates", "prior-measure reuse", "K18 order of limits"],
    "changes": ["../BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md", "boost_kernel_effective_dynamics evidence packet only"],
    "changed_editable_prompts": [],
    "files": files,
    "excluded_post_freeze_outputs": sorted(excluded),
    "output_binding": "Post-freeze command logs are hashed by their execution metadata; the receipt itself is hashed in those metadata and in the supervisor delivery. No circular self-hash is asserted.",
    "verification_scope": "byte identity and recorded execution provenance only; not mathematical or audit certification",
}
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps({"receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
                  "note_sha256": files[0]["sha256"], "bound_files": len(files),
                  "frozen_at_utc": receipt["frozen_at_utc"]}, indent=2))
