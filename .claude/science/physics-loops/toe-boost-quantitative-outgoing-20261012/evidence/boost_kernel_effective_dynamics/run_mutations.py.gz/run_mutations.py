#!/usr/bin/env python3
"""Run literal, one-change defects without overwriting prior evidence."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

packet = Path(__file__).resolve().parent
baseline = packet / "forced_controls.py"
source = baseline.read_text()
changes = [
    ("Schur_sign", "schur = 1/(zvalue-sigma)", "schur = 1/(zvalue+sigma)",
     "Schur_against_actual_Pauli_inverse"),
    ("forced_resolvent_sign", "(frequency*sp.eye(8)-A).inv().applyfunc(sp.simplify)",
     "(frequency*sp.eye(8)+A).inv().applyfunc(sp.simplify)",
     "forced_resolvent_ODE_derivative_1"),
    ("Duhamel_source_sign", "-ii*A*ode_derivative+ii*source_derivative*zeta",
     "-ii*A*ode_derivative-ii*source_derivative*zeta",
     "forced_resolvent_ODE_derivative_1"),
    ("source_phase_derivative", "phase_prime = -1j*duration*fprime*phase",
     "phase_prime = 0.0", "all_parameter_factors_t_-3.1"),
    ("spectral_weight_power", "weighted_norm = np.sum(abs(source_coefficients)**2*chi**2)",
     "weighted_norm = np.sum(abs(source_coefficients)**2*chi)",
     "dressed_vector_spectral_chi_squared_weight"),
]


def run_one(item):
    name, before, after, expected = item
    if source.count(before) != 1:
        raise RuntimeError(f"Expected one literal mutation location: {name}")
    prefix = packet / f"mutant_{name}"
    paths = {key: Path(str(prefix)+suffix) for key, suffix in
             [("source", ".py"), ("stdout", ".stdout.log"),
              ("stderr", ".stderr.log"), ("execution", ".execution.json")]}
    if any(path.exists() for path in paths.values()):
        raise RuntimeError(f"Refusing to overwrite mutation evidence: {name}")
    altered = source.replace(before, after)
    paths["source"].write_text(altered)
    command = [sys.executable, str(paths["source"])]
    start = time.monotonic()
    result = subprocess.run(command, text=True, capture_output=True, timeout=120)
    paths["stdout"].write_text(result.stdout)
    paths["stderr"].write_text(result.stderr)
    caught = result.returncode != 0 and f"AssertionError: {expected}" in result.stderr
    row = {"name":name, "before":before, "after":after,
           "expected_assertion":expected, "caught_at_intended_check":caught,
           "command":command, "timeout_seconds":120,
           "exit_code":result.returncode, "elapsed_seconds":time.monotonic()-start,
           "utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "baseline_sha256":hashlib.sha256(source.encode()).hexdigest(),
           "mutant_sha256":hashlib.sha256(altered.encode()).hexdigest(),
           "paths":{key:str(path.relative_to(packet)) for key,path in paths.items()}}
    paths["execution"].write_text(json.dumps(row,indent=2)+"\n")
    return row


manifest = packet / "mutation_manifest.json"
if manifest.exists():
    raise SystemExit("Refusing to overwrite mutation manifest")
with ThreadPoolExecutor(max_workers=2) as pool:
    outcomes = list(pool.map(run_one, changes))
manifest.write_text(json.dumps(outcomes,indent=2)+"\n")
for item in outcomes:
    print(item["name"], "exit",item["exit_code"],
          "intended_assertion",item["caught_at_intended_check"], flush=True)
if not all(item["caught_at_intended_check"] for item in outcomes):
    raise SystemExit("At least one mutation did not fail at its designated check")
