# Independent review of the full-zero-space weak-momentum dynamics

2026-10-11. This is a source-bound research review, not an audit verdict or
a retained-status action. The reviewed source is
`EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md`, all 549 lines, SHA-256
`b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`.
Its frozen author receipt is
`excluded_walk_degenerate/receipt.json`, SHA-256
`369bebc245e0e7794608d6a1ef29a4ccd3d374a85f3f3bcc20f0f2dd81288dde`.

**Finding: no consequential defect found within the stated scope.** The full
physical zero space, bounded effective block, gapless fixed-vector strong
limit, actual bounded canonical-current limit, strict dressing-preparation
response, normalizable total-momentum packet, and explicit failure of an
operator-norm upgrade are supported by the arguments checked below. In
particular, the nonuniform state limit is not evidence of a current
counterexample. No claim for arbitrary lambda-dependent positive-band
preparations, growing rescaled times, or a quantitative finite-lambda onset
follows from this result. Those exclusions are present in the frozen source.

The independent reconstruction began from the frozen long-time and canonical
sources before this new draft was frozen. After the freeze, the complete
new argument was read and reconciled against that reconstruction. A different
finite fixture and a different cone control were then implemented without
importing author code. Author check counts and mutation failures were treated
as provenance and finite controls, not as independent proof.

## 1. Source identities, reuse, and actual coverage

Here `S` is
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and `W` is the sibling `worktree`. Every path below is relative to `S`
unless indicated otherwise.

| Source | SHA-256 | Coverage used here |
|---|---|---|
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | All 549 lines; every mathematical section D1–D31 reconstructed. |
| `excluded_walk_degenerate/receipt.json` | `369bebc245e0e7794608d6a1ef29a4ccd3d374a85f3f3bcc20f0f2dd81288dde` | All 250 lines; all 25 artifact and 8 source identities verified. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Prior complete 457-line independent review reused after identity check, especially full kernel, integrability, and canonical cancellations. |
| `excluded_walk_long_time/receipt.json` | `bdd9d7b0caedbf168f4e45dead01b7a816f321b5894ae5671c1dcdedb81d35dc` | Frozen provenance reused; unchanged. |
| `EXCLUDED_WALK_LONG_TIME_REVIEW.md` | `b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f` | Previous independent reconstruction; its original report and receipt remain frozen. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Prior complete 190-line reading reused after identity check; bounded canonical-current extension and specified energy placement. |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526` | Prior complete 322-line reading reused after identity check; model chart and normalization. |
| W's M6 note, `ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md` | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065` | Prior complete 226-line reading reused after identity check; supplied walk contract only. |

The unchanged canonical and Cook review identities in the author receipt
also match. This new proof does not depend on Cook preparation, stationary
scattering completeness, or the coherent positive-band packet theorem.
Their previous reviews are not counted as reviews of this new argument.

The current reviewer skill, repository AGENTS, and SCIENCE_WORKFLOW hashes
were checked against the previously read revisions:
`9d841edd05b9dc4c5145abcfd5352cd45460a1cc57c23c1eabd131590dbb1455`,
`f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f`,
and `05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce`.
No new novelty survey was needed for the mathematical review. The author's
historical comparison to local `main` at `e485eab6...` is expressly bounded
to that revision and is not treated here as a latest-main or global
priority claim.

## 2. Full physical kernel and first-order operator

Use normalized relative-torus measure, inner products linear in the second
slot, even singlet coefficients, and odd triplet coefficients. At K=0 the
free block is `[[0,2s^T],[2s,0]]`. Its kernel consists exactly of pointwise
transverse triplet fields. On the physical space `P=I-|c><c|`, an equation
`P H0 P psi=0` says `H0 psi=alpha c`. Subtracting
`alpha sqrt(I0) zeta` leaves a free-kernel vector. Conversely both the free
kernel and zeta are annihilated by the compressed operator. The two
summands are pointwise orthogonal, so

    Pi = F + |zeta><zeta|

is the complete physical zero projection. The auxiliary constant singlet
is absent. The prior cone bounds establish `I0<infinity` and the stated
`1/12<=I0<=9/8`; the new argument never needs a bounded inverse on the
nonzero spectrum or an H1 derivative of zeta.

Direct Pauli multiplication gives
`(sigma_1,l+sigma_2,l)T_j=2i epsilon_ljk T_k`. Consequently the exact
K-dependent block in D3 and the sign of `B_kappa u=i d cross u` are correct.
This was also reconstructed from actual Pauli matrices in the new control.
Since `|d(q)|<=|kappa|=b`, B is bounded self-adjoint with norm at most b;
it annihilates the singlet and preserves the physical space.

For the off-diagonal block, before division by lambda,

    ||2[(cos(lambda kappa/2)-1)*s]||
      <=lambda^2 sqrt(sum kappa_j^4)/4 <=lambda^2 b^2/4.

The triplet remainder is at most
`lambda^3 sqrt(sum |kappa_j|^6)/24 <=lambda^3 b^3/24`.
Thus both terms and factors in D5 survive compression with the advertised
bound. These elementary trigonometric estimates do not require a small
lambda restriction; the limit only uses lambda tending to zero.

For transverse u, tangent compression satisfies

    (I-nn^T)(d cross u)=(d dot n)n cross u.

Also `B_kappa zeta=i(d cross n)/(2 epsilon sqrt(I0))` is already
transverse, with zero zeta diagonal. These facts determine both
off-diagonal entries in D6, including their adjoints. The coefficient g
is square-integrable and the whole block has norm at most b because it
is a compression of B. A separate pointwise singular estimate on g is
not needed for boundedness. Its parity is correct. Omitting this coupling
would change the dynamics of the physical dressing vector.

## 3. Gapless strong convergence and its quantifiers

I independently obtained the same cutoff corrector. With `v=exp(-it A)z`,
`Q_sigma=1_{|H_*|>sigma}`, and
`E_sigma=1_{0<|H_*|<=sigma}`, take

    y=-H_*^{-1} Q_sigma B v,   w=v+lambda y.

Here the inverse is bounded by `1/sigma` only after its spectral cutoff.
The identities `H_*v=0` and `Pi Bv=Av` give exactly

    i w'-(H_*/lambda+B)w
      =-E_sigma Bv+lambda(i y'-By).

The sign is necessary. The independent signed-spectrum test has nonzero
low and high spectral forcing, and checks this identity for every vector
in its two-dimensional kernel. Reversing the corrector sign leaves a
nonzero leading high-spectrum residual.

The two endpoint correctors cost `2lambda b||z||/sigma`; the integrated
derivative and B terms each cost `Tlambda b^2||z||/sigma`. The low
spectral forcing costs `T M_z(sigma,T)`. Comparing the exact generators
with and without the bounded remainder costs `T r_lambda||z||` on the
initial vector z, so no extra corrector factor belongs in that term.
This gives all constants in D11, for positive and negative times.

The spectral sets defining E_sigma decrease to the empty set. Hence
E_sigma tends strongly to zero, although not in operator norm in this
gapless model. The norm-continuous orbit `B exp(-it A)z` on a compact time
interval is compact. A finite net, using `||E_sigma||<=1`, makes the low
spectral convergence uniform on that orbit. First letting lambda tend
to zero at fixed sigma and then sigma tend to zero proves D8. Equally,
the displayed estimate could be used with `sigma=sqrt(lambda)` for a
fixed z and fixed b,T; it still supplies no rate for its spectral-mass
term. The order and vector dependence in the source are sound.

The theorem applies to each fixed zero-space vector, uniformly on fixed
compact rescaled times. It does not apply uniformly over their unit ball,
to arbitrary lambda-dependent relative states, or to T increasing with
1/lambda. It says nothing about strongly convergent evolution of a
general initial vector in the nonzero spectral complement. No gap or
isolated-eigenvalue perturbation hypothesis is being smuggled into D8.

## 4. Bounded canonical current and the actual response

D12 is the previously checked bounded extension for the specified local
energy placement. Using it on L2 avoids the invalid step of inserting the
singular zeta into an unbounded energy-dipole commutator.

The multiplication term divided by lambda differs from
`kappa_a cos(2q_a)` by at most `lambda^2 |kappa_a|^3/6`.
The two finite-rank contributions use

    ||h||<=sqrt(6),   ||v_a||=1/sqrt(2),
    ||h-2v||<=lambda^2 b^2/(4sqrt(2)),
    ||h'_a/lambda+kappa_a v_a/2||
      <=lambda^2 |kappa_a|^3/(48sqrt(2)).

Twice the product of the last error with `||h||` gives
`lambda^2 sqrt(3)|kappa_a|^3/24`. Twice the product of
`|kappa_a| ||v_a||/2` with the h error gives
`lambda^2 |kappa_a| b^2/8`. These are precisely D14. The norm bound
`||L_a||<=1+sqrt(3)` follows from
`||v||=sqrt(3/2)`. If kappa_a=0 the entire a-th current vanishes
exactly, as the source states.

For the compression to Z, scalar multiplication by `cos(2q_a)` preserves
transverse and longitudinal triplet fields separately. The finite-rank
part has no transverse-transverse contribution because Fv=0. Its cross
term is `Fv_a/(2sqrt(I0))`, and the zeta diagonal equals one by the exact
free/placement cancellation. This independently reconstructs D15–D18,
including the cross-term conjugation convention. The current is not
obtained by differentiating A with respect to kappa.

For the full zero space, `sum r_a=0` and
`sum cos(2q_a)=3-2epsilon^2`, so

    sum_a <z,calJ_a z> = 3-2||epsilon u||^2

for unit `z=u+alpha zeta`. The longitudinal trace identity from the older
probe cannot replace this one after transverse amplitude is produced.
For diagonal kappa, cyclic coordinate permutation is a proper rotation.
It fixes zeta, commutes with A, and permutes the three current operators.
The expectations are therefore equal at every real time, giving D20
exactly, rather than merely as a Taylor expansion.

The positivity calculation in D21 is also correct. Coordinate reflections
kill mixed terms in `integral(d dot n)^2`. The common diagonal integral is

    L=integral cos^2(q_1)n_1^2=1/3-A0,
    A0=integral s_1^4/epsilon^2 >= (integral s_1^2)^2/
                                      integral epsilon^2 =1/6.

Since L is nonnegative, `0<=L<=1/6`, while
`integral |d|^2=b^2/2`. This gives
`b^2/(12I0)<=gamma_kappa^2<=b^2/(8I0)` and, using the previously
checked upper bound on I0, `gamma_kappa^2>=2b^2/27`. The mixed-term
reflection argument is essential; it is not a value inferred from the
author's finite fixture or torus quadrature.

The unitary Taylor remainder has norm at most `b^2 tau^2/2`. Multiplying
the transverse remainder by epsilon costs at most sqrt(3). Hence the
interval `0<|tau|<=sqrt(2)/(9b)` makes the remainder at most half
`|tau|gamma_kappa`, and D23 follows with coefficients `1/6` and `1/81`.
This interval is used only for nonzero b. The exact quadratic current
coefficient is `-(2/3)gamma_kappa^2`, and the first derivative vanishes.

Strong state convergence plus the operator-norm current expansion proves
D17 and D24. In particular, for `kappa=k(1,1,1)`, the scaled drift has
sign `-sgn(k)` on D23's interval and has the stated strictly positive
magnitude bound. The result is an actual canonical-current response of
the dressing preparation at time `tau/lambda`. It is not a response
theorem for arbitrary free positive-band preparation.

## 5. Normalized direct-integral packet and constants

The map `Psi(kappa,q)` to
`lambda^(-3/2) Psi(K/lambda,q)` preserves the norm with the displayed
normalized measures: the Jacobian `dK=lambda^3 dkappa` exactly cancels
the squared amplitude. Compact kappa support lies inside the fixed chart
for sufficiently small lambda. This is a normalizable momentum packet;
no fiber delta or contact renormalization is used.

For almost every kappa, the initial vector in the rescaled variable is
fixed and belongs to Z. D8 thus applies pointwise. The square of the
supremum of its state error is bounded by `4||Psi(kappa)||^2`, an
integrable bound. Measurability follows, for example, by taking the time
supremum over a countable dense set. Dominated convergence proves the
global compact-time strong limit. This does not contradict the later
nonuniformity family, whose relative q preparation changes with lambda.
Current convergence follows from the uniform-on-compact-kappa D14 bound
and the same normalization. The argument does not need convergence
uniform over all possible sections Psi.

At kappa0=(1,1,1), b=sqrt(3), and tau0=1/20 lies inside the stated
small-time interval. Its negative drift bound is exactly `-1/10800`.
Writing `q(kappa)=<exp(-i tau0 A_kappa)zeta,calJ_a exp(-i tau0 A_kappa)zeta>`,

    F_a(kappa)-F_a(kappa0)
      =(kappa_a-1)(q(kappa)-1)+(q(kappa)-q(kappa0)).

The first term is at most `(2+sqrt(3))|kappa-kappa0|`; the second is
at most `2(1+sqrt(3))tau0 |kappa-kappa0|`. In particular there is no
missing factor `|kappa_a|`: this decomposition uses kappa0,a=1 in the
second term. It proves the specified C0. Radius `1/(21600 C0)` leaves
`F_a<=-1/21600` throughout the envelope support. Integrating a normalized
`|f|^2` gives D25 for all three components. These constants were also
checked by exact arithmetic in the independent control.

The limit and strict sign are proved. A numerical finite-lambda onset
is not supplied, because no quantitative bound on the vector-dependent
low spectral mass has been supplied. The source states this limitation.

## 6. Constructive failure of operator-norm convergence

The author's paired balls have normalized volume
`lambda^3 eta^3/(3pi^2)`. They are disjoint for eta=1/100 and small
lambda. The projected e2 direction is nonzero there; using its pointwise
normalization and opposite signs at antipodes produces an exact odd,
unit, free-transverse field. Thus the example genuinely belongs to Z at
each lambda, with no auxiliary-singlet or point-state substitution.

On its support, `|d dot n|<=2eta` eventually. Moreover
`epsilon>=(2/pi)|q|>=(2/pi)lambda(1-eta)` gives

    ||1_Omega g||
      <=sqrt(lambda) eta^(3/2)/(sqrt(48I0)(1-eta)).

Comparing A with its transverse multiplication block by Duhamel along
the supported comparison orbit uses this restricted g norm, not the
global coupling norm. It proves D27. The finite-rank exclusion correction
along free evolution costs exactly the D28 bound: the contact amplitude
is at most `sqrt(mu(Omega))`, the global h norm is at most sqrt(6), and
its pointwise supported norm is at most `2lambda(1+eta)`. After division
by lambda this is O(sqrt(lambda)). The comparison may use the zero
extension on c; the actual compressed evolution stays physical.

The rescaled free symbol tends uniformly on the two fixed p balls to
D29. In the basis `(T2,T3,c)` at p=e3 its block is precisely D30's M0.
Its cubic polynomial is `M0^3=5M0`; at pi/sqrt(5), the cosine polynomial
`I-2M0^2/5` gives `(3/5)T2-(4i/5)c`. At the negative center the
singlet output has the required even parity. The norm of the difference
from the initial triplet is `2/sqrt(5)` on either ball.

The two direction replacements cost at most 8eta, the variation in the
rescaled symbol costs at most `2|tau*|eta`, and the effective motion from
the initial field costs at most another `2|tau*|eta`. The vanishing
compression and trigonometric errors do not affect the liminf. Thus
every coefficient in D31 is accounted for. Its last strict inequality
follows from `tau*<2`, `2/sqrt(5)>4/5`, and eta=1/100. This really
disproves operator-norm convergence on the zero-space unit ball at one
fixed rescaled time. It does not disprove any uniform current estimate.

As a separate decisive reconstruction, I used kappa=e3 and balls centered
at `+/-lambda e1/2` with physical radius `lambda^2`, again preparing the
normalized transverse projection of T2 with odd parity. Their volume
is `lambda^6/(3pi^2)`. The effective transverse multiplier is O(lambda),
and its supported coupling norm is O(lambda^2). The scaled exclusion
comparison is also O(lambda^2), since `sqrt(mu)/lambda=O(lambda^2)`.
The divided free symbol tends to a different cone matrix. In the basis
`(c,T1,T2)` it is

    [[0,1,0],[1,0,-i],[0,i,0]].

Its cube is twice itself, so time pi/sqrt(2) transfers T2 to i c exactly.
The negative patch has the same even singlet output. Pointwise direction
and symbol variations vanish with lambda, giving limiting state separation
sqrt(2) from the effective evolution. This alternative family, derived
independently and checked from Pauli matrices, supports the nonuniformity
mechanism. It is not needed to strengthen the source's stated bound and
does not produce a current conclusion.

## 7. Independent evidence and preserved limitations

New evidence lives only in `excluded_walk_degenerate_review/`:

- `independent_degenerate_controls.py` and its full `.log`;
- `independent_execution.json`;
- `evidence_identity_check.json`;
- `independent_review_receipt.json`, binding this report and all evidence.

The helper imports no author code and runs no torus quadrature. Its three
antipodal-pair fixture uses the cyclic orbit of
`sin q=(7/25,24/25,0)` and `cos q=(24/25,7/25,1)`. It has dimension 12,
physical zero dimension 7, fixture `I0=1/4`, and fixture coupling weight
`668354/390625`. These are finite-fixture values, not continuum integrals.
An exact cubic relation on the dressing cyclic subspace supplies an
independently evaluated finite-time exponential and current. The helper
checks both canonical cross terms, the trace identity, the zero first
derivative and nonzero second derivative, and the perfect-transfer cone.
An unrelated Hermitian signed-spectrum example checks the cutoff residual
with both nonempty low and high spectral parts. Floating matrix exponentials
provide supplementary controls, including negative times; their finite
bounds do not establish the gapless continuum theorem.

The independent process exited zero on its first run. Outer elapsed time
was 1.368658 seconds, with a 120-second timeout. Versions were Python
3.13.5, SymPy 1.14.0, NumPy 2.4.4, and SciPy 1.17.1. Its complete output
was read. No failed independent run or changed tolerance was suppressed.

The author helper was read in full (264 lines), as were its complete
baseline log (66 lines), mutation manifest (151 lines), and all eight
complete failure logs. Each mutant was verified to be exactly its stated
single replacement of the frozen author helper, and its intended assertion
appears in its failure log. All 25 recorded artifact hashes and 8 source
hashes match. No author process was replayed or counted as independent
evidence. The author's torus midpoint values remain unvalidated quadrature.

The supported theorem remains conditional on the supplied walk, pair
Hilbert space, exclusion rule, coordinate/clock convention, and canonical
energy placement. Fixed-vector strong convergence and the specified
normalizable dressing packet are proved by analysis, not by any finite
check. Quantitative low-spectral-mass estimates, arbitrary free-band
preparation, growing rescaled horizons, and associated current cross terms
remain open interfaces. No universal relaxation, scattering completeness,
physical-law derivation, or quantum-history claim has been established.

There is no Lean or other proof-assistant certification in this packet.
Formalization would need the physical-kernel characterization, bounded
spectral-cutoff/Duhamel lemma with compact-orbit uniformity, canonical-current
compression and integral symmetries, measurable direct-integral dominated
convergence, and the normalized concentrating-family estimates. The exact
finite algebra is not a substitute for these analytic obligations.

No repository, author source, previous report/receipt, audit state, commit,
PR, external message, or editable prompt file was changed. Only this new
report and its new evidence directory were written.
