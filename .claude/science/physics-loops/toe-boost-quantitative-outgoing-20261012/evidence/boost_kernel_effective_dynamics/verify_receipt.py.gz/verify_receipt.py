#!/usr/bin/env python3
"""Verify this frozen author's bytes; this grants no scientific status."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess


def check_bytes(blob: bytes, expected: str, label: str) -> None:
    actual = hashlib.sha256(blob).hexdigest()
    if actual != expected:
        raise ValueError(f"hash mismatch: {label}: {actual} != {expected}")


def main() -> None:
    packet = Path(__file__).resolve().parent
    receipt_path = packet / "receipt.json"
    receipt = json.loads(receipt_path.read_text())
    assert receipt["schema"] == "boost-kernel-effective-dynamics-receipt-v1"
    assert Path(receipt["packet_path"]).resolve() == packet
    assert receipt["mathematical_status"] == "conditional-author-result; independent-review-pending"
    bound = receipt["files"]
    names = [row["path"] for row in bound]
    assert len(names) == len(set(names)), "duplicate receipt file"
    for row in bound:
        path = (packet / row["path"]).resolve()
        assert path == packet.parent / "BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md" or packet in path.parents
        blob = path.read_bytes()
        check_bytes(blob, row["sha256"], row["path"])
        assert len(blob) == row["bytes"], row["path"]
    print(f"Bound artifact and evidence files: {len(bound)} matched")

    original_manifest = json.loads((packet / "source_manifest.json").read_text())
    for row in original_manifest:
        original = Path(row["source"]).read_bytes()
        copied = (packet / row["copy"]).read_bytes()
        check_bytes(original, row["sha256"], row["source"])
        check_bytes(copied, row["sha256"], row["copy"])
        assert original == copied
        assert len(original) == row["bytes"]
        assert len(original.splitlines()) == row["lines"]
    print(f"Original mathematical sources and identical copies: {len(original_manifest)} matched")

    instructions = json.loads((packet / "instruction_manifest.json").read_text())["items"]
    for row in instructions:
        blob = subprocess.run(
            ["git", "show", f'{row["ref"]}:{row["path"]}'],
            cwd=receipt["read_only_worktree"], capture_output=True, check=True,
        ).stdout
        check_bytes(blob, row["sha256"], f'{row["ref"]}:{row["path"]}')
    print(f"Read-only exact-ref instruction sources: {len(instructions)} matched")

    baseline = json.loads((packet / "baseline_attempt2.execution.json").read_text())
    assert baseline["exit_code"] == 0
    check_bytes((packet / "forced_controls.py").read_bytes(), baseline["source_sha256"], "executed baseline")
    baseline_text = (packet / "forced_controls.py").read_text()
    mutations = json.loads((packet / "mutation_manifest.json").read_text())
    for row in mutations:
        assert baseline_text.count(row["before"]) == 1, row["name"]
        changed = (packet / row["paths"]["source"]).read_text()
        assert changed == baseline_text.replace(row["before"], row["after"], 1), row["name"]
        assert row["exit_code"] == 1 and row["caught_at_intended_check"], row["name"]
        stderr = (packet / row["paths"]["stderr"]).read_text()
        assert f'AssertionError: {row["expected_assertion"]}' in stderr, row["name"]
    print(f"Literal defect-copy provenance and intended failures: {len(mutations)} matched")

    note_row = next(row for row in bound if row["path"] == "../BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md")
    note = bytearray((packet / note_row["path"]).read_bytes())
    note[0] ^= 1
    try:
        check_bytes(bytes(note), note_row["sha256"], "in-memory one-byte tamper")
    except ValueError:
        print("In-memory one-byte tamper: rejected; original file unchanged")
    else:
        raise AssertionError("one-byte tamper was accepted")
    print("Receipt byte/provenance verification complete; no mathematical or audit verdict")


if __name__ == "__main__":
    main()
