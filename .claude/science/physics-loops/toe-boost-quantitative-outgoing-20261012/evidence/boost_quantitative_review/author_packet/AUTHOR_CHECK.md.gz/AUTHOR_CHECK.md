# Author checks and exact limits of the evidence

Root supplied the approximate-range mechanism and subsequent polynomial
refinement lead and is a coauthor. The worker developed the complete source
bounds, pointwise K extraction, weighted derivative bounds, constants,
corrector estimate and growing-time consequences. Neither is an independent
reviewer of this result. The model and effort were inherited without an
override; no subagent was used.

Before freezing Q, the selective independent K review became available.
Its complete 230-line report and receipt were read, the frozen K target and
author-receipt hashes matched, and all fourteen review artifact bindings
were verified. This permits source-bound conditional reuse of K. The new
Q rate and growing-time argument are explicitly outside that review's scope.
This worker did not rereview all underlying K reviewer artifacts or rerun
their scientific controls; that is not claimed as new coverage.

## A second analytic arrangement of the central estimate

The note derives Q21 by integrating the fast generator. A separate direct
error-equation arrangement checks all its signs and endpoints. Let
r=H_*x_delta+eta_delta and put Y=D_lambda+lambda x_delta. Starting from
the exact X equation, without first invoking Q21, differentiation gives

    iY_t=G_lambda Y+eta_delta+e_lambda
                    +lambda(i(x_delta)_t-V_lambda x_delta),
    Y(0)=lambda x_delta(0).

Thus unitarity bounds D by the two corrector endpoints, the integrals of
lambda||(x_delta)_t||, lambda||V_lambda x_delta||, ||eta_delta|| and
||e_lambda||. Applying Q7 with delta=lambda reproduces Q22 and Q25.
The same construction for the differentiated equation uses x_delta[r_j]
and retains the additional forcing (partial_j G_lambda)D_lambda. It gives
Q26 with the same constants. This arrangement shows directly why assuming
the corrected variable has zero initial condition would drop a real term.
It also shows that no commutation or kernel restriction of the full error
was used.

## Analytic hypotheses checked

- Physical range: the Pauli singlet/triplet form gives H_*(alpha c)=2s alpha
  on even mean-zero alpha. Odd residual triplets have even beta; orthogonality
  to zeta is exactly the full-torus beta/(2epsilon) integral constraint.
  The cutoff and both projections are independent of time and kappa.
- Cone geometry: in each of the eight folded cells, concavity of sine gives
  sin(t)>=2t/pi on [0,pi/2], while |sin(t)|<=|t|. Normalization becomes
  pi^(-3). The low region lies in radius pi delta/2 and the high region
  lies outside radius delta. The radial integrals give precisely Q6.
  The mean bound is a low-cone L1 bound. The corrector bound is an L2
  bound improved by orthogonal projection; these two norms are not confused.
- Weighted evolution: the weighted field space embeds continuously in L2,
  Pi and Q are bounded on triplets, and A has a bounded Banach generator
  on its closed kernel subspace. The generic exponential proof remains
  valid in the preserved snapshot. The strengthened proof directly
  differentiates the exact K8 formula in each individual kappa fiber;
  it does not extract pointwise bounds from an integrated H1 assertion.
  Its Hilbert bounds control alpha and alpha_j in the exact transverse
  integral. Pointwise unitarity applies to D, and the three parameter
  derivatives act on its propagator, coupling and alpha. Their integrated
  majorants give Q11. The differentiated full equation then bounds z_t
  and z_jt. Weighted unitarity of A is never assumed.
- Source constants: the normalization derivative uses the global Z_lambda
  and n_lambda; neither has a kappa derivative. The elementary vector-sine
  remainder, normalized-vector derivative and reciprocal-radius estimates
  give the four Q15 constants. The derivative of the oscillatory source
  contains both projector and clock derivatives. Its difference bound is
  valid for every real time because |exp(iu)-exp(iv)|<=|u-v| without a
  small-phase restriction.
- Error space and derivative: r and r_j are the actual longitudinal
  residuals; their time derivatives obey the weighted estimates. In contrast
  e_lambda and D_lambda are treated on the full physical space. The exact
  derivative equation includes (partial_j G_lambda)D_lambda, whose norm is
  bounded by the already-proved undifferentiated error. No derivative of
  a limiting relation is taken.
- Time windows: the same all-T bounds yield H1 convergence for eta<1/6
  and L2 convergence for eta<1/4 by direct substitution T=lambda^(-eta).
  Constants are independent of both variables. K2/K8 enter the improved
  weighted estimate before this substitution; its further outgoing theorem
  is used only after growing-time convergence is established. The resulting
  correction norm limits retain their comparison-state interpretation.
  They are not occupations of the actual total state.
- All nine means: X's exact symmetric-form identity moves the derivative
  to the other entry, preserving the smaller L2 error in the pairing.
  Every free, cross and correction term is kept. The exact bounded B13
  form gives a 22lambda coefficient error, with all directional derivative
  constants displayed. q derivatives occur only on its known smooth form
  factors. The mean estimate is derived anew for all T before choosing
  eta<1/6; the wider L2 norm window is not transferred to this observable.

The main note was then read completely, from its source identities through
all equations Q1–Q34 and scope statements, after the polynomial refinement
and complete mean section were included. Final precision edits restrict
the trigonometric derivative bound to orders n>=1 and distinguish smooth
form-factor q derivatives from the prohibited input/zeta differentiation.
No unresolved proof step is identified by this author inside the stated conditional theorem. A distinct check
is still required; this author assessment is not an audit verdict.


## Additional arrangements for the strengthened result

The direct K8 pointwise estimate controls the scalar alpha before the
transverse integral is used. It bounds alpha uniformly and alpha_j by
|F_j|+(3+|t|)|F|. Independently differentiating the block ODE gives the
inhomogeneous equation for u_j. Its variation-of-constants solution has
exactly the propagator, coupling and alpha derivative terms retained in
the note. No two-level closure is used; this identity retains the complete
transverse multiplication space.

For the means, expand W=z+D in the quadratic form instead of using X35:

    <W,Q0 W>=2 Re<D,Q0 z>+<D,Q0 D>.

Symmetry and <z,Q0 z>=0 make this identical to the main arrangement.
It bounds the correction by 13||D||_2(2||z||_(1,Sigma)+||D||_(1,Sigma)),
which reproduces both time powers in Q33. The coefficient-difference
pairing uses ||W||_2||W||_(1,Sigma), with the uniform K8 Hilbert bound for
z. Expanding all terms gives only monomials dominated by
sqrt(lambda)(1+T)^3 or lambda(1+T)^5. In particular the full-error square
contributes the second power and cannot be silently omitted.

The second K derivative bound for A can also be obtained from B12's
six ranks, independent of the [H,J] arrangement used in the note. The two
scalar-current ranks contribute 13. The pair containing H h_b contributes
36 and the pair containing H h contributes 36, giving 85 again. The
script below verifies both product-rule arrangements exactly.

## Executed controls

`corrector_controls.py` imports no earlier campaign helper. Its direct
4-by-4 Pauli matrices represent two weighted antipodal momentum pairs in
an 8-dimensional ambient fiber, with the contact singlet removed by P.
The rational sine data differ from the
preceding K fixture. The finite integral I0=97/100 is explicitly not the
torus integral. Exact SymPy identities check the complete physical kernel,
Pi h0, the mean-zero singlet range, the residual's triplet type, the
corrector mean and full residual formula. The bounded perturbation does
not commute with H_*.

Exact scalar controls separately check folded cone coefficients and the
source/error constant arithmetic. A continuous radial diagnostic uses
normalized measure 3r^2 dr and beta=1/r-3r. It satisfies the global
orthogonality constraint while its uncut inverse is not L2. Its exact
corrector obeys delta||x_delta||^2->3/4 and
||r-H_*x_delta||^2/delta->3. This preserves the singular mechanism and
tests the cutoff powers in a model whose integrals are exact. It does
not establish optimality of the actual walk's lambda error.

The floating dynamics use the exact finite sine-Pauli G_lambda and its
first kappa derivative, at lambda=1/32, with time/parameter-dependent
two-frequency forcing. They compare direct time integration with the
four-term corrector identity at times -1.7, 0.6 and 2.3. A second check
compares a five-point derivative of the entire forced error with the
integral of its full differentiated equation. Its forcing contains the
generator derivative, source amplitude and phase derivatives, h derivative,
E derivative and effective-state derivative. This finite source is an
algebra fixture, not a replacement for the exact B25–B30 continuum source.

The first baseline completed all 27 controls with exit 0 in 1.912 seconds.
The largest corrector-identity discrepancy was
`3.210313764760098e-16`; the largest first-parameter-derivative discrepancy
was `6.845404783690867e-10`, below the specified 2e-8 tolerance. Full stdout,
empty stderr and command metadata are preserved. Runtime versions were
Python 3.13.5, SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1.

Eight literal one-replacement defect copies actually exited 1 at the
designated checks: omitted physical mean subtraction, omitted residual
mean term, omitted final endpoint, omitted initial endpoint, omitted time
corrector derivative, omitted noncommuting perturbation term, omitted
source phase derivative and omitted full-error generator derivative.
Their sources, complete logs, command metadata and replacement manifest
are preserved without overwriting. Each complete log was inspected and
each changed file was compared against the exact one-replacement rule.
These outcomes show sensitivity to those particular defects; they do not
certify the infinite-dimensional result.

Reproduce the baseline with fresh logging paths:

```text
/opt/homebrew/opt/python@3.13/bin/python3.13 /Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_hstar_quantitative_corrector/corrector_controls.py
```

`run_mutations.py` refuses to overwrite the original defect evidence. The
receipt verifier checks exact source/evidence identities, original/copy
equality, literal mutations and an in-memory one-byte tamper rejection.
It gives no mathematical certification. No finite fixture, fitted value,
torus grid, source-count total or provenance check replaces the analytic
proof or the pending independent review.

## Refinement and mean controls

`polynomial_controls.py` reconstructs the transverse generator and its
coupling directly from Pauli matrices in a separate finite block, with
finite I0=1 explicitly distinguished from the torus integral. Exact
controls check D's Hermiticity, D/D_j commutation, all weighted polynomial
majorants and the actual transverse block. Numerical integrals at times
-2.2, 0.4 and 3.1 compare the block integral with the full forced state;
the derivative comparison includes all three differentiated factors.
The 16 controls exited 0 in 1.260 seconds. Maximum state and derivative
discrepancies were 1.4092960140259168e-17 and
2.6684498818007686e-13, respectively.

Three further literal defect copies omit the propagator derivative,
coupling derivative or alpha derivative in that integral. Each actually
exited 1 at `transverse_three_derivatives_t_-2.2`. Every full stdout and
stderr was read; the eleven total mutant files were checked against their
unique literal replacement rules and bound baseline hashes.
`mutation_provenance_check.json` records that byte check, not a rerun or
an independent scientific verdict.

`mean_controls.py` uses scalar Taylor majorants to obtain the A second
parameter derivative bound in two product-rule arrangements and the full
B13 first-derivative bound. It checks the rounded operator constants and
the monomial dominance used in Q33. A generic Hermitian coefficient
fixture checks all nine symmetry identities and kernel pairings; it is
explicitly not a finite physical torus. Its eight checks exited 0 in
0.392 seconds. This is arithmetic and index bookkeeping supporting the
analytic proof, not an independent discovery of X29 or a continuum test.

The preserved exponential proof has SHA-256
`50ceee39e4a7364bb2b616ce09b741101492a9639e91ad0a2776c66c8b7a4ce9`.
It was copied before the later polynomial lead was read and is not edited
by the refinement. All three baseline command records bind their executed
script hashes and preserve complete stdout/stderr. Fresh-context review
of Q1–Q34 remains pending despite the selective checked K dependency.
