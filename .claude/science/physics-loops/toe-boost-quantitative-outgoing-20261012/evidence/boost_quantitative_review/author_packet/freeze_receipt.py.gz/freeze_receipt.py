#!/usr/bin/env python3
"""One-time byte freeze of the bounded Q author result; no science verdict."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

packet=Path(__file__).resolve().parent
receipt_path=packet/'receipt.json'
assert not receipt_path.exists(), 'refusing to overwrite a frozen receipt'
excluded={'receipt.json','receipt_freeze.stdout.log','receipt_freeze.stderr.log',
          'receipt_freeze.execution.json','receipt_verification.stdout.log',
          'receipt_verification.stderr.log','receipt_verification.execution.json'}
note=packet.parent/'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md'
paths=[note]+sorted(p for p in packet.rglob('*') if p.is_file()
    and p.relative_to(packet).as_posix() not in excluded and '__pycache__' not in p.parts)
files=[]
for path in paths:
    blob=path.read_bytes()
    name='../'+note.name if path==note else path.relative_to(packet).as_posix()
    files.append({'path':name,'sha256':hashlib.sha256(blob).hexdigest(),
                  'bytes':len(blob),'lines':len(blob.splitlines())})
receipt={
    'schema':'boost-hstar-quantitative-corrector-receipt-v1',
    'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
    'campaign_deadline_utc':'2026-10-12T16:00:52+00:00',
    'packet_path':str(packet),
    'read_only_worktree':'/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/boost_worktree',
    'observed_read_only_head':'773321aa8fdfccc05248682dfc96bf94215034a2',
    'mathematical_status':'conditional-author-result; independent-review-pending',
    'authors':'root proposed corrector and polynomial refinement mechanisms; boost_kernel_dynamics completed bounded derivation and author controls',
    'new_claim_scope':'Q1-Q34 actual X longitudinal corrector, full source and parameter/time bounds, all-T polynomial L2/H1 rates, distinct growing-time windows, simultaneous comparison-correction norms and all-nine actual expectation limits',
    'preserved_exponential_proof_sha256':'50ceee39e4a7364bb2b616ce09b741101492a9639e91ad0a2776c66c8b7a4ce9',
    'selective_checked_K_source_sha256':'1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9',
    'selective_K_review_sha256':'64cf08ea2c12f086d0efcc862d17ce0e394f53dfbcbfa5d48db73a10bb9652ca',
    'K_review_does_not_cover_Q':True,
    'author_open_proof_obligations':[],
    'independent_check_pending':['physical global mean and cone bounds','pointwise K8 extraction and complete transverse derivative','exact all-T source and error bounds','both corrector endpoints and noncommuting term','all-nine coefficient and expectation bounds','simultaneous limit windows and scope'],
    'preserved_failures':['actual residual is not generally in ran H_*','no full inverse or H_* gap','no complementary-unit-ball averaging rate','no inference from fixed-T convergence to growing times','no total-state occupation interpretation of comparison correction','no endpoint exponent or optimality assertion'],
    'changes':['../BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md','boost_hstar_quantitative_corrector evidence packet only'],
    'changed_editable_prompts':[],
    'git_mutations_by_worker':[],
    'files':files,
    'excluded_post_freeze_outputs':sorted(excluded),
    'output_binding':'Post-freeze logs are hashed by their execution metadata, which binds the receipt hash. No circular receipt self-hash is asserted.',
    'verification_scope':'byte identity and recorded execution provenance only; not a mathematical or audit verdict',
}
receipt_path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
                  'note_sha256':files[0]['sha256'],'bound_files':len(files),
                  'frozen_at_utc':receipt['frozen_at_utc']},indent=2))
