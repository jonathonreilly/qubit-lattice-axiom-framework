#!/usr/bin/env python3
"""Author arithmetic and generic coefficient checks, not a continuum proof.

The quadratic-form identity is inherited from exact X. This checks its
all-index bookkeeping and new majorant arithmetic without a torus grid.
"""
import json
import sympy as sp

checks=[]
def check(name, condition):
    assert bool(condition), name
    checks.append(name)
    print('checked', name, flush=True)

t=sp.symbols('t', real=True)
# Scalar exponential-generating majorants; differentiation performs the
# product rule independently of the termwise numbers in the manuscript.
H=4+t+t**2/4
h=4+t+t**2/4
hb=1+t/2+t**2/8
r=1+t+t**2/2
J=r+2*hb*h
A_comm=2*H*J
A_ranks=2*h*r+2*(H*hb*h+H*h*hb)
check('A_second_derivative_two_arrangements',
      sp.diff(A_comm,t,2).subs(t,0)==sp.diff(A_ranks,t,2).subs(t,0)==85)
ha=1+t/2
hab=sp.Rational(1,2)+t/4
Fba=2*hab*h+2*ha*hb
Hdelta=4+t
Ha=1+t/2
hq=2+t
hbq=1+t/2
Lh=Hdelta*hq/2+Ha*h
Lhb=Hdelta*hbq/2+Ha*hb
Ldagh=Hdelta*hq/2
Ldaghb=Hdelta*hbq/2
C=6*t+ha*r+h*r+H*Fba+Lhb*h+Lh*hb+hb*Ldagh+h*Ldaghb
check('C_first_derivative_full_product_rule',sp.diff(C,t).subs(t,0)==sp.Rational(149,2))
check('Taylor_operator_constant',sp.Rational(75,4)+sp.Rational(85,32)<22)
check('limiting_operator_constant',6+4*sp.sqrt(3)<13 and 3+sp.sqrt(3)<13)

# Generic Hermitian coefficient fixture; not a physical finite torus.
HH=sp.diag(0,0,2)
PP=sp.diag(1,1,0)
Ls=[sp.Matrix([[1,sp.I,2],[-sp.I,3,sp.I],[2,-sp.I,4]]),
    sp.Matrix([[2,1,sp.I],[1,4,3],[-sp.I,3,5]]),
    sp.Matrix([[3,sp.I,1],[-sp.I,5,2*sp.I],[1,-2*sp.I,6]])]
k=sp.symbols('k0:3', real=True)
z=sp.Matrix([1+k[0]+sp.I*k[1],k[2]+sp.I*k[0]*k[1],0])
all_form=True
all_kernel=True
for a in range(3):
    for b in range(3):
        delta=int(a==b)
        comm=HH*Ls[b]-Ls[b]*HH
        BB=k[b]*comm
        CC=delta*HH*(Ls[b]-sp.eye(3))
        all_form &= (BB.H==-BB and CC-CC.H==BB.diff(k[a]))
        qz=CC*z+BB*z.diff(k[a])
        target=HH*Ls[b]*(k[b]*z).diff(k[a])
        all_kernel &= all(sp.simplify(x)==0 for x in qz-target)
        all_kernel &= sp.simplify((z.H*qz)[0])==0
check('all_nine_symmetric_coefficient_identities',all_form)
check('all_nine_kernel_pairings',all_kernel)

# Each discarded factor is <=1 on 0<lambda<=1, s>=1. Map the actual
# monomials to the two retained powers; no fit to sampled lambda or time.
retained=[(sp.Rational(1,2),3),(1,5)]
actual=[(sp.Rational(1,2),1),(1,1),(sp.Rational(3,2),3),
        (sp.Rational(1,2),3),(1,5),(1,1),
        (sp.Rational(3,2),3),(sp.Rational(3,2),3),(2,5)]
check('mean_monomials_uniform_dominance',all(any(p>=a and q<=b for a,b in retained) for p,q in actual))
eta=sp.Rational(1,6)
check('open_window_endpoint_arithmetic',sp.Rational(1,2)-3*eta==0 and 1-5*eta>0)
print(json.dumps({'controls_completed':len(checks),'sympy':sp.__version__,
  'scope':'author exact product-rule arithmetic and generic all-index coefficient fixture; no independent review'},indent=2))
