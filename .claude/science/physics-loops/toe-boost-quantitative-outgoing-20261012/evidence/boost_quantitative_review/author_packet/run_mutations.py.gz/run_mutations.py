#!/usr/bin/env python3
"""Preserve and actually execute narrowly specified literal defects."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

packet = Path(__file__).resolve().parent
source = (packet/'corrector_controls.py').read_text()
base_sha = hashlib.sha256(source.encode()).hexdigest()
specs = [
    ('mean_subtraction', 'corrector_map = P*raw_map', 'corrector_map = raw_map',
     'corrector_physical_mean_zero'),
    ('mean_residual_term', '(eta_map-low_map-h0*mean_row)*Qt)', '(eta_map-low_map)*Qt)',
     'corrector_exact_residual_and_mean_term'),
    ('final_endpoint', 'endpoint = -1j*lam*(xt-U(time)@x0)', 'endpoint = 1j*lam*(U(time)@x0)',
     'noncommuting_corrector_Duhamel_t_-1.7'),
    ('initial_endpoint', 'endpoint = -1j*lam*(xt-U(time)@x0)', 'endpoint = -1j*lam*xt',
     'noncommuting_corrector_Duhamel_t_-1.7'),
    ('time_corrector_derivative', 'combined = endpoint+time_term+perturbation_term+error_term',
     'combined = endpoint+perturbation_term+error_term', 'noncommuting_corrector_Duhamel_t_-1.7'),
    ('noncommuting_perturbation', 'combined = endpoint+time_term+perturbation_term+error_term',
     'combined = endpoint+time_term+error_term', 'noncommuting_corrector_Duhamel_t_-1.7'),
    ('source_clock_derivative', 'phase_derivative = -1j*time*frequency_slopes*phase',
     'phase_derivative = np.zeros_like(phase)', 'full_differentiated_error_t_-1.7'),
    ('full_error_generator_derivative', 'generator_term = gj@dd',
     'generator_term = np.zeros_like(dd)', 'full_differentiated_error_t_-1.7'),
]
assert not (packet/'mutation_manifest.json').exists()


def run(spec):
    name, before, after, expected = spec
    assert source.count(before) == 1, name
    changed = source.replace(before, after, 1)
    paths = {key: packet/f'mutant_{name}{extension}'
             for key, extension in [('source','.py'),('stdout','.stdout.log'),
                                    ('stderr','.stderr.log'),('execution','.execution.json')]}
    assert not any(path.exists() for path in paths.values()), name
    paths['source'].write_text(changed)
    command = [sys.executable, str(paths['source'])]
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=120)
    paths['stdout'].write_bytes(result.stdout)
    paths['stderr'].write_bytes(result.stderr)
    row = {'name':name, 'before':before, 'after':after, 'expected_assertion':expected,
           'command':command, 'timeout_seconds':120, 'exit_code':result.returncode,
           'elapsed_seconds':time.monotonic()-start, 'utc':datetime.now(timezone.utc).isoformat(),
           'baseline_sha256':base_sha, 'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),
           'caught_at_intended_check':result.returncode == 1 and f'AssertionError: {expected}' in result.stderr.decode(),
           'paths':{key:path.name for key,path in paths.items()}}
    paths['execution'].write_text(json.dumps(row,indent=2)+'\n')
    return row


with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(run, specs))
(packet/'mutation_manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
    print(row['name'], row['exit_code'], row['caught_at_intended_check'])
assert all(row['caught_at_intended_check'] for row in rows)
