# Independent review of the fixed-time boost/current expectation

**PASS for the conditional supplied-model theorem X1–X35 at the frozen source
below. No required repair or unresolved mathematical proof obligation was found
within that scope.** This is a selective independent source review; it applies
no audit verdict and confers no retained status or physical identification.

The result covers all nine expectations for the exact globally normalized
B25–B30 packet and actual excluded evolution:

    sup_{|tau|<=T} |<psi_lambda(tau/lambda),R_ab psi_lambda(tau/lambda)>|/lambda ->0

for every fixed finite T>=0 and every a,b in {1,2,3}. The forced-state
H1_kappa(L2_q) limit X23 and residual-vector limit X30 also check. The earlier
diagonal norm of order sqrt(lambda) at sufficiently small fixed positive tau
remains valid. No off-diagonal norm lower bound follows from this review.

## Exact sources and complete reading coverage

All relative paths in this table are based at this report's directory.

| Source | SHA-256 | Coverage |
|---|---|---|
| `BOOST_CURRENT_EXPECTATION_PROBE.md` | `a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68` | All 587 lines read and reconstructed; target unchanged through final verification |
| `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md` | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` | All 744 lines read; complete normal form, domains, supported/global bounds and exact preparation reconstructed |
| `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md` | `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929` | All 185 lines read; exact forcing, derivative propagation and free-comparison estimate checked |
| `BOOST_CURRENT_INVERSE_ENERGY_PROBE.md` | `76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990` | All 658 lines read; necessary normalization, full kernel and rescaled coefficients reconstructed; norm/expectation distinction preserved |
| `BOOST_CURRENT_INVERSE_ENERGY_REVIEW.md` | `d3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796` | Complete 167-line prior review read; its label is not a premise for the new proof |
| `boost_inverse_energy_review/PROOF_RECONSTRUCTION.md` | `c0a06917dc1f24207d85656781e250104c81dd613a9a937a140088149bf2f131` | Complete 329-line prior reconstruction read and checked against necessary source arguments |

The supplied Hamiltonian, antisymmetric pair sector, exclusion projection,
coordinates, chart, clock, symmetric energy placement and exact preparation
remain explicit mathematical hypotheses. No framework axiom or primitive is
needed to establish the implication once those data are supplied. This does
not derive their physical identification or assess the framework registry's
separate authority.

## Decisive mathematical checks

The complete reconstruction was frozen before the current author's checks,
helpers, logs or receipt were opened. It is saved at
[PROOF_RECONSTRUCTION.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_expectation_review/PROOF_RECONSTRUCTION.md),
SHA-256 `04adc0b81d3865f4819b8441e25279ef084bda755e9c0a3206be7d314ea04f9f`.
The pre-evidence freeze and its narrowly clarified earlier version are both
preserved. The clarification concerns wording about uniform convergence of
the differentiated error source; it changes no target source or conclusion.

1. **Normalization and actual forcing (X2–X13).** Both three-dimensional
   Jacobians cancel the squared packet prefactor exactly. The contact
   amplitude has no extra lambda factor, while its L2_K norm has the
   lambda^(3/2)c0 factor. Both normalization constants are global numbers.
   Direct differentiation gives the positive-i forced comparison with zero
   initial difference. The source's projector and phase derivatives, all
   three differentiated Duhamel factors, and the entire relative torus are
   retained. The same source construction works for every first momentum
   derivative.

2. **Gapless fixed-time limit
   ([source line 247](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_CURRENT_EXPECTATION_PROBE.md:247)).**
   The cutoff inverse is used only on |H_*|>=delta. Its integration-by-parts
   signs and noncommuting perturbation term are correct. Strong spectral
   convergence is uniform on the compact family of residual vectors by a
   finite net; it is not operator-norm convergence on the complement.
   Taking lambda->0 before delta->0 proves the assertion without a rate.

   A separate reviewer derivation checks the same limit through the free
   primitive `F_lambda(t)=int_0^t exp(-iu H_*/lambda)Q du`. Its spectral
   multiplier is bounded by `min(T,2lambda/|E|)`, so it vanishes uniformly
   in bounded t on each fixed Q vector and then on compact families.
   Time-step approximation handles a continuous source. The exact Volterra
   equation for the bounded perturbation and a Gronwall bound transfer this
   convergence to the full perturbed propagator. This checks the decisive
   infinite-dimensional claim through a different perturbative arrangement.

3. **All first momentum derivatives
   ([source line 300](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_CURRENT_EXPECTATION_PROBE.md:300)).**
   Subtracting the exact forced and compressed-kernel equations gives
   `i D'=G_lambda D+Q(Bz-g)+E_lambda z+g-g_lambda`. For each j the
   differentiated equation retains `(partial_j G_lambda)D` and the fixed
   Q-valued source `Q(V_j z+B partial_j z-c0 h0 partial_j a)`.
   The first term tends to zero by the uniform derivative bound on G;
   the fixed residual is covered by the same gapless lemma; the remaining
   C1 error vanishes. Compact support gives the claimed uniform H1 limit.
   The full kernel contains both the transverse triplet subspace and zeta.
   The excluded auxiliary c is absent, and no H1_q regularity or dipole
   action on singular zeta is assumed.

4. **All-index form and common-domain symmetry
   ([source line 385](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_CURRENT_EXPECTATION_PROBE.md:385)).**
   Differentiating the exact current, including both rank terms, gives
   `partial_Ka J_b(0)=delta_ab L_b`. The bounded normal form then gives
   `Q0,ab=delta_ab H_*(L_b-I)+kappa_b[H_*,L_b]partial_a`.
   On the common smooth core the canonical commutator is symmetric;
   continuity and density extend its pairing to compact-support
   H1_K(L2_q). The limiting coefficient identity is
   `C0-C0*=partial_a(kappa_b[H_*,L_b])`. For every kernel-valued H1 field,
   `Q0,ab z=H_*L_b partial_a(kappa_b z)`, whose pairing with z is zero.
   For a!=b both constant terms vanish and the derivative is still the
   correct a derivative. The output need not itself be zero.

5. **Complete actual expectation
   ([source line 469](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_CURRENT_EXPECTATION_PROBE.md:469)).**
   The free comparison has residual O_T(lambda^(3/2)), while the correction
   has norm O_T(sqrt(lambda)). Common-domain symmetry moves both cross
   terms onto the free-comparison residual. After division by lambda,
   the free term is O_T(sqrt(lambda)), the cross terms are O_T(lambda),
   and the self-pairing converges to `<z,Q0,ab z>=0`. This proves X1;
   it does not assume orthogonality of the exact comparison and correction.
   The weaker-topology check X35 is also correct. Negative finite times
   and tau=0 are included. No conclusion is extrapolated to growing tau.

## Author evidence and provenance verification

After the reconstruction freeze, the complete 156-line `AUTHOR_CHECK.md`
was inspected. Its corrected-approximate-solution calculation retains the
initial corrector and has the correct signs. Its continuous-spectrum example
on L2(0,1), with H_*=x and constant forcing, has the stated bounds
`(4/pi^2)lambda t <= ||I_lambda(t)||^2 <=5lambda t`; it correctly shows why
the argument must not be advertised as an unqualified O(lambda) norm estimate.
The all-index symmetry, small-time Gamma_b match and weaker-topology check
agree with the reconstruction. These remain author checks.

There is no new finite scientific runner in this packet. None was added by
the reviewer: the remaining load-bearing questions were resolved analytically,
and a finite matrix or torus grid cannot establish this continuum averaging
theorem. The complete 164-line author freeze script and 32-line receipt
verifier were read as bookkeeping code. Their saved output is appropriately
limited to source identity rather than presented as scientific certification.

The author's frozen receipt has SHA-256
`4aa182928c9fa4a6bc44fbd69c6122a35aa9a8f99495a7170aa2f90e5aa1216f`.
An independent deterministic verification checked all 97 bound paths, the
57 inherited preservation records, five mathematical source copies, preserved
initial recovery files, all 98 rows of the saved author verification log,
and its run metadata. The author run has exit 0, a declared 60-second timeout
and empty stderr. The reviewer bookkeeping run also exited 0 with empty
stderr, about 0.08 seconds elapsed and a declared 60-second timeout. Its
352 identity/preservation conditions matched; this count has no mathematical
evidentiary weight. Full logs, script, metadata and recovery bytes are under
`boost_expectation_review/`.

The full diagonal-to-final diff was read. The all-component changes and
subsequent envelope/support/time-domain clarifications match the final source
reviewed here. The preserved diagonal draft is unchanged. The author records
one failed atomic patch before the successful index replacements; it is
preserved and has no mathematical implication. The inherited norm obstruction,
mixed-band counterexample, discarded shortcuts and unused historical route
remain intact.

## Independence, reading limits and final disposition

Root authored E and proposed the kernel-pairing mechanism and all-component
extension; those contributions are coauthorship, not independent evidence.
The current author developed the source and author checks. This reviewer
reconstructed the frozen argument and supplied the separate free-primitive
Volterra proof before opening the current author evidence. The target's own
text exposed its proposed formulas and described its controls, so this is
independent checking with shared source information, not blinded discovery.
The user-selected model and reasoning effort were inherited without override
or subdelegation.

All 587 target lines and all five mathematical context documents listed
above were read completely. Unused historical parent reports, the discarded
fixed-tau route, inherited numerical helpers and unrelated preservation-only
documents were hashed for recovery; their complete arguments are not newly
certified here. The current proof rederives its necessary kernel and coefficient
identities from the supplied B definitions. The author's bounded search logs
were inspected, but neither they nor this review establish exhaustive novelty.

The applicable AGENTS, CLAUDE, SCIENCE_WORKFLOW and reviewer skill were read;
instruction identities and the read-only local refs are recorded. The selected
worktree instruction files match stored origin/main
`a13caa4885f547c8d206265b031ba7649e539fd9`; no network freshness claim or
repository mutation was made. No source, author artifact, editable prompt,
physical axiom, PR, audit state or other chat was changed. The fixed campaign
deadline `2026-10-12 16:00:52 UTC` was not extended.

**Safe reuse:** a source-bound, independently checked conditional theorem for
the stated expectation and vector limits on this exact supplied model and
preparation. Physical covariance, complete boost algebra, gravity, other
preparations, a convergence rate and unbounded rescaled time remain outside
the theorem. No repair is required for the checked result. Recovery and final
identity details are in
[receipt.json](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_expectation_review/receipt.json)
and
[CHECKPOINT.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_expectation_review/CHECKPOINT.md).
