# Proposed quantitative corrector for the actual X error

2026-10-11. Root research proposal, not an independently checked theorem or
publication claim. This records a possible next derivation after the actual
X-source outgoing calculation. Keep all frozen X/K/other sources unchanged.
The fixed campaign deadline remains 2026-10-12 16:00:52 UTC.

The obstacle in X was a general gapless averaging rate. Its actual residual
has more structure than a general complement vector. The following route
may give a quantitative corrector without calculating a new spectral density.
It must be checked in full, including every derivative and time constant.

## Candidate algebra

Use the exact physical K=0 fiber of B/T/X, normalized torus measure dmu,
s=sin(q), epsilon=|s|, n=s/epsilon, singlet c, and
zeta=n/(2 epsilon sqrt(I0)). The physical kernel is the transverse triplet
space plus span{zeta}. On mean-zero even singlet functions alpha,

    H_* (alpha c) = 2 epsilon alpha n.

The exact X residual r=Q(B_kappa z-g) is triplet valued: z is in the
triplet kernel, B is total spin, and g=c0 h0 a is triplet. After Q removes
the transverse component and zeta, write r=beta(q)n, with

    integral beta/(2 epsilon) dmu = 0.

For any such beta with |beta(q)|<=C/epsilon(q), and 0<delta<=1, try

    m_delta = integral [beta/(2 epsilon)] 1_{epsilon>=delta} dmu,
    alpha_delta = [beta/(2 epsilon)]1_{epsilon>=delta}-m_delta,
    x_delta = alpha_delta c.

Then x_delta is physical (mean-zero singlet), and the proposed exact identity is

    r-H_*x_delta = beta n 1_{epsilon<delta} + 2 epsilon n m_delta.

The orthogonality condition rewrites m_delta as minus the small-cone integral.
The cutoff depends only on q, so kappa/time derivatives use the same formula.
No q derivative of the cutoff or zeta is needed for the X H1_kappa problem.

## Candidate cone estimates

Fold the eight zeros into [-pi/2,pi/2]^3; normalized integration becomes
pi^-3 times integration over that cube. There

    (2/pi)|q| <= epsilon(q) <= |q|.

Bounding the folded regions by Euclidean radial regions appears to give

    integral_{epsilon<delta} epsilon^-2 dmu <= (pi/2) delta,
    integral_{epsilon>=delta} epsilon^-4 dmu <= pi^2/(4 delta).

Consequently the candidate bounds are

    |m_delta| <= C pi delta/4,
    ||x_delta|| <= (C pi/4)(delta^-1/2+delta),
    ||r-H_*x_delta||
       <= C sqrt(pi delta/2) + (C pi sqrt(6)/4)delta.

The last term uses integral epsilon^2 dmu=3/2. Verify all constants,
fold multiplicities, parity and the global (not pointwise) orthogonality.

## Candidate dynamical use

For G_lambda=H_*/lambda+V_lambda with bounded V_lambda, the exact Duhamel
integration by parts on r=H_*x_delta+(r-H_*x_delta) should yield, uniformly
on a fixed finite time interval, a bound of the form

    ||integral_0^t U_lambda(t-s)r(s)ds||
       <= C_T [lambda delta^-1/2+delta^1/2].

Unlike the general spectral-cutoff route, this exploits explicit approximate
range vectors with norm O(delta^-1/2). Taking delta=lambda would give
O_T(sqrt(lambda)). Initial/final correctors and the noncommuting V term must
all be retained. The same estimate is needed for every first kappa derivative
of r and its time derivative; no differentiation of a convergence statement.

The needed weighted regularity might follow directly on the triplet space
with norm ||u||_w=ess sup_q epsilon(q)|u(q)|. The kernel projector appears
bounded with norm at most 2 in this space: the transverse projection has
norm 1 and the zeta rank-one contribution has norm at most 1, using
integral epsilon^-2=4I0. Multiplication B_kappa has norm <=|kappa|,
so A_kappa=Pi B_kappa on kernel fields has weighted norm <=2|kappa|.
For |kappa|<=1/4, fixed-time weighted source/evolution estimates could then
be bounded by a polynomial in T times exp(T/2). Check the actual h0 source,
all kappa derivatives, compact F support, and the distinction between weighted
norm and Hilbert-space unitarity. This is not a proof that A has a new gap.

X's exact differentiated error equation could then give

    ||W_lambda-z||_{H1_kappa(L2_q)} <= C_T sqrt(lambda),

since the normal-form generator remainder is O(lambda) in C1, while the
source's sine/projector/phase approximation has explicit polynomial-in-T
errors. If established, symmetry and Pi Q0 Pi=0 would plausibly improve the
actual expectation statement to O_T(lambda^(3/2)). These are targets to prove,
not conclusions accepted from this note.

Only after a complete explicit time dependence is proved should one examine
T=c log(1/lambda). An exp(T/2) bound with finite polynomial losses could permit
c<1, but neither that constant nor such a growing-time theorem is established
here. Check all lambda/T remainders rather than infer it from a fixed-T limit.

## Checks needed and scope

Prior K=0 finite algebra can cross-check H_*(alpha c) and the triplet residual
projection. A separate analytic reconstruction must check the range-corrector
argument and the cone integrals; finite grids cannot certify either.
The prior qualitative X theorem, norm obstruction, outgoing K construction,
all counterexamples and shared-premise limits remain unchanged. No total-state
occupation, full covariance, physical dynamics selection, or audit status is
implied. A failure of any proposed bound should be preserved with its exact
source and corrected narrow obligation.
