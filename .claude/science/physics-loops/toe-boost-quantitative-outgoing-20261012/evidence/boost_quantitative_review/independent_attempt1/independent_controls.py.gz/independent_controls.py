"""Independent finite algebra/ODE controls; not continuum proof or torus quadrature.
No Q author helper or log was read before this file was authored.
"""
import json
import sys
import numpy as np
import scipy
from scipy.linalg import block_diag, expm, eigh
from scipy.integrate import quad_vec, solve_ivp

I2=np.eye(2,dtype=complex)
sig=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
s1=[np.kron(a,I2) for a in sig]; s2=[np.kron(I2,a) for a in sig]
cspin=np.array([0,1,-1,0],complex)/np.sqrt(2)
spin_basis=np.column_stack([cspin]+[a@cspin for a in s1])
assert np.linalg.norm(spin_basis.conj().T@spin_basis-np.eye(4))<1e-14
q=np.array([[.018,.012,-.020],[.13,-.08,.04],[.31,.21,-.11],[.6,-.4,.2],[1.1,.5,-.7],[2.8,-.2,.9],[-2.9,2.7,-.14]])
weights=np.array([2,3,4,5,7,6,8],float); weights/=weights.sum()
# Each row represents q and -q, with even singlet/odd triplets and total pair weight.
N=len(q); dim=4*N; sw=np.sqrt(weights)
sine=np.sin(q); eps=np.linalg.norm(sine,axis=1); normal=sine/eps[:,None]
c=np.zeros((N,4),complex); c[:,0]=sw; c=c.ravel()
P=np.eye(dim)-np.outer(c,c.conj())
I0=np.sum(weights/(4*eps**2))
zeta=np.zeros((N,4),complex); zeta[:,1:]=sw[:,None]*normal/(2*eps[:,None]*np.sqrt(I0)); zeta=zeta.ravel()
Ftr=block_diag(*[block_diag(np.zeros((1,1)),np.eye(3)-np.outer(n,n)) for n in normal])
Pi=Ftr+np.outer(zeta,zeta.conj()); Q=P-Pi

def H0(k):
    return block_diag(*[spin_basis.conj().T@sum((s1[j]*np.sin(k[j]/2+qq[j])+s2[j]*np.sin(k[j]/2-qq[j]) for j in range(3)),start=np.zeros((4,4),complex))@spin_basis for qq in q])

def H0j(k,j):
    return block_diag(*[spin_basis.conj().T@(.5*s1[j]*np.cos(k[j]/2+qq[j])+.5*s2[j]*np.cos(k[j]/2-qq[j]))@spin_basis for qq in q])

Hstar=P@H0(np.zeros(3))@P
Bj=[P@H0j(np.zeros(3),j)@P for j in range(3)]
for label,value in [('Pi physical',np.linalg.norm(P@Pi-Pi)),('Pi projection',np.linalg.norm(Pi@Pi-Pi)),('kernel',np.linalg.norm(Hstar@Pi)),('zeta norm',abs(np.vdot(zeta,zeta)-1))]:
    assert value<2e-13,(label,value)
print('physical finite pair model',json.dumps({'pairs':N,'dimension':dim,'I0_finite_not_continuum':float(I0)}))

k=np.array([.12,-.09,.07]); lam=1/32; B=sum(k[j]*Bj[j] for j in range(3)); G=P@H0(lam*k)@P/lam; V=G-Hstar/lam
assert np.linalg.norm(Hstar@V-V@Hstar)>1e-3
rng=np.random.default_rng(27031)
u=np.zeros((N,4),complex);u[:,1:]=(rng.normal(size=(N,3))+1j*rng.normal(size=(N,3)))*sw[:,None]
h0=H0(np.zeros(3))@c
r1=-Q@h0;r2=Q@u.ravel()
delta=.35

def corrector(r):
    vals=r.reshape(N,4)[:,1:]/sw[:,None]
    beta=np.sum(normal*vals,axis=1)
    raw=beta/(2*eps)*(eps>=delta);mean=np.dot(weights,raw)
    x=np.zeros((N,4),complex);x[:,0]=sw*(raw-mean)
    eta=np.zeros((N,4),complex);eta[:,1:]=sw[:,None]*normal*(beta*(eps<delta)+2*eps*mean)[:,None]
    assert abs(np.dot(weights,beta/(2*eps)))<2e-12
    assert np.linalg.norm(r-Hstar@x.ravel()-eta.ravel())<2e-12
    assert abs(np.vdot(c,x.ravel()))<2e-12
    return x.ravel(),eta.ravel(),mean

x1,eta1,m1=corrector(r1);x2,eta2,m2=corrector(r2)
assert abs(m1)>1e-3 and abs(m2)>1e-3
print('uncentered singlet rejected',json.dumps({'r1_contact':float(abs(m1)),'r2_contact':float(abs(m2))}))

def source(t):return (1+.2*t)*r1+np.exp(-.7j*t)*r2
def xt(t):return (1+.2*t)*x1+np.exp(-.7j*t)*x2
def xprime(t):return .2*x1-.7j*np.exp(-.7j*t)*x2
def eta(t):return (1+.2*t)*eta1+np.exp(-.7j*t)*eta2

source_matrix=np.column_stack([r1,.2*r1,r2])
S=np.array([[0,0,0],[1,0,0],[0,0,-.7j]],complex)
aug=np.block([[-1j*G,source_matrix],[np.zeros((3,dim)),S]])
initial=np.r_[np.zeros(dim,complex),[1,0,1]]
energies,vectors=eigh(G)
def flow(t,v):return vectors@(np.exp(-1j*t*energies)*(vectors.conj().T@v))
corrector_rows=[]
for t in [.27,-.41,1.2]:
    direct=(expm(t*aug)@initial)[:dim]
    endpoints=-1j*lam*xt(t)+1j*lam*flow(t,xt(0))
    pieces=[]
    for fun in [lambda s:1j*lam*flow(t-s,xprime(s)),lambda s:-lam*flow(t-s,V@xt(s)),lambda s:flow(t-s,eta(s))]:
        val,err=quad_vec(fun,0,t,epsabs=1e-12,epsrel=1e-12);pieces.append(val)
    rhs=endpoints+sum(pieces)
    err=float(np.linalg.norm(direct-rhs));assert err<2e-10,err
    row={'time':t,'identity_error':err,'omit_initial':float(lam*np.linalg.norm(xt(0))),'omit_final':float(lam*np.linalg.norm(xt(t))),'omit_time_derivative':float(np.linalg.norm(pieces[0])),'omit_noncommuting_V':float(np.linalg.norm(pieces[1])),'omit_residual':float(np.linalg.norm(pieces[2]))}
    assert min(v for key,v in row.items() if key.startswith('omit_'))>1e-6,row
    corrector_rows.append(row)
print('noncommuting corrected-solution controls',json.dumps(corrector_rows))

# True source phases/projector weights on several annular x points. The finite
# envelope and global scalar normalizers are declared fixture inputs, not B25 F
# or a claimed quadrature approximation to the continuum normalization.
x=np.array([[.66,0,0],[.2,.5,-.42],[-.45,.24,.51]],float)
x=x/np.linalg.norm(x,axis=1)[:,None]*np.array([.66,.69,.73])[:,None]
xweight=np.array([.13,.21,.17]);Z=.63;c0=(2*np.pi)**(-1.5)
nglobal=np.sqrt(1-c0**2*lam**3*.23)

def Fenv(kk):
    base=np.exp(-np.dot(kk,kk));return base*(1+.2*kk[1]),base*(-2*kk*(1+.2*kk[1])+np.array([0,.2,0]))

def direct_frequency_weight(kk,ll):
    yp=x+kk/2;ym=x-kk/2
    up=yp if ll==0 else np.sin(ll*yp)/ll
    um=ym if ll==0 else np.sin(ll*ym)/ll
    rp=np.linalg.norm(up,axis=1);rm=np.linalg.norm(um,axis=1);np_=up/rp[:,None];nm=um/rm[:,None]
    ww=[]
    for aa,bb in zip(np_,nm):
        p1=(I2+sum(aa[j]*sig[j] for j in range(3)))/2
        p2=(I2-sum(bb[j]*sig[j] for j in range(3)))/2
        ww.append(float(np.real(np.vdot(cspin,np.kron(p1,p2)@cspin))))
    return rp+rm,np.array(ww)

def source_amplitudes(kk,ll):
    ee,ww=direct_frequency_weight(kk,ll);ff,_=Fenv(kk)
    hh=H0(ll*kk)@c
    norm=1 if ll==0 else nglobal
    return ee,np.column_stack([c0*hh*ff/Z/norm*xweight[a]*ww[a] for a in range(len(x))])

def direct_state(kk,t,ll,effective=False):
    ee,amps=source_amplitudes(kk,ll)
    generator=Pi@sum(kk[j]*Bj[j] for j in range(3))@Pi if effective else P@H0(ll*kk)@P/ll
    if effective:amps=Pi@amps
    full=np.block([[-1j*generator,1j*amps],[np.zeros((len(x),dim)),np.diag(-1j*ee)]])
    return (expm(t*full)@np.r_[np.zeros(dim,complex),np.ones(len(x))])[:dim]

def g_and_derivatives(kk,t,ll,omit_phase=False):
    yp=x+kk/2;ym=x-kk/2
    up=yp if ll==0 else np.sin(ll*yp)/ll;um=ym if ll==0 else np.sin(ll*ym)/ll
    cp=np.ones_like(up) if ll==0 else np.cos(ll*yp);cm=np.ones_like(um) if ll==0 else np.cos(ll*ym)
    rp=np.linalg.norm(up,axis=1);rm=np.linalg.norm(um,axis=1);nu=up/rp[:,None];nv=um/rm[:,None]
    ee=rp+rm;ww=(1+np.sum(nu*nv,axis=1))/4
    ff,fj=Fenv(kk);phase=np.exp(-1j*t*ee);aa=ff/Z*np.dot(xweight,ww*phase)
    hh=H0(ll*kk)@c;norm=1 if ll==0 else nglobal
    gg=c0/norm*hh*aa;der=[]
    for j in range(3):
        unit=np.eye(3)[j]
        du=.5*cp[:,j,None]*(unit-nu*nu[:,j,None])/rp[:,None]
        dv=-.5*cm[:,j,None]*(unit-nv*nv[:,j,None])/rm[:,None]
        ej=.5*(nu[:,j]*cp[:,j]-nv[:,j]*cm[:,j])
        wj=np.sum(du*nv+nu*dv,axis=1)/4
        aj=fj[j]/Z*np.dot(xweight,ww*phase)+ff/Z*np.dot(xweight,(wj if omit_phase else wj-1j*t*ww*ej)*phase)
        hj=np.zeros(dim,complex) if ll==0 else ll*H0j(ll*kk,j)@c
        der.append(c0/norm*(hj*aa+hh*aj))
    return gg,np.array(der)

A=Pi@B@Pi;Aj=[Pi@bj@Pi for bj in Bj]
Gj=[P@H0j(lam*k,j)@P for j in range(3)];E=G-Hstar/lam-B;Ej=[Gj[j]-Bj[j] for j in range(3)]

def error_ode(t,y,defect=None):
    yy=y.reshape(8,dim);z=yy[0];zj=yy[1:4];d=yy[4];dj=yy[5:8]
    gs,gsj=g_and_derivatives(k,t,0,defect=='omit_phase')
    gl,glj=g_and_derivatives(k,t,lam,defect=='omit_phase')
    r=Q@(B@z-gs);e=E@z+gs-gl
    out=np.zeros_like(yy);out[0]=-1j*A@z+1j*Pi@gs
    out[4]=-1j*(G@d+r+e)
    for j in range(3):
        out[1+j]=-1j*(A@zj[j]+Aj[j]@z-Pi@gsj[j])
        rj=Q@(Bj[j]@z+B@zj[j]-gsj[j])
        ej=(np.zeros(dim) if defect=='omit_Ej_z' else Ej[j]@z)+E@zj[j]+gsj[j]-glj[j]
        gd=np.zeros(dim) if defect=='omit_Gj_D' else Gj[j]@d
        out[5+j]=-1j*(G@dj[j]+gd+rj+ej)
    return out.ravel()

def run_error(t,defect=None):
    sol=solve_ivp(lambda tt,yy:error_ode(tt,yy,defect),(0,t),np.zeros(8*dim,complex),method='DOP853',rtol=2e-11,atol=2e-13)
    assert sol.success,sol.message
    return sol.y[:,-1].reshape(8,dim)

def fd(fun,kk,j):
    hh=1e-4;vec=np.eye(3)[j]*hh
    return (fun(kk-2*vec)-8*fun(kk-vec)+8*fun(kk+vec)-fun(kk+2*vec))/(12*hh)

state_rows=[]
for t in [.73,-.42]:
    y=run_error(t)
    zref=direct_state(k,t,0,True);dref=direct_state(k,t,lam)-zref
    zder=np.array([fd(lambda kk:direct_state(kk,t,0,True),k,j) for j in range(3)])
    dder=np.array([fd(lambda kk:direct_state(kk,t,lam)-direct_state(kk,t,0,True),k,j) for j in range(3)])
    row={'time':t,'state_error':float(np.linalg.norm(y[4]-dref)),'effective_error':float(np.linalg.norm(y[0]-zref)),'derivative_errors':[float(np.linalg.norm(y[5+j]-dder[j])) for j in range(3)],'effective_derivative_errors':[float(np.linalg.norm(y[1+j]-zder[j])) for j in range(3)]}
    assert row['state_error']<2e-9 and row['effective_error']<2e-9
    assert max(row['derivative_errors']+row['effective_derivative_errors'])<2e-8,row
    if t>0:
        defects={}
        for defect in ['omit_Gj_D','omit_Ej_z','omit_phase']:
            bad=run_error(t,defect)
            defects[defect]={'error_derivative_max':max(float(np.linalg.norm(bad[5+j]-dder[j])) for j in range(3)),'effective_derivative_max':max(float(np.linalg.norm(bad[1+j]-zder[j])) for j in range(3))}
            assert max(defects[defect].values())>1e-7,(defect,defects[defect])
        row['defects']=defects
    state_rows.append(row)
print('complete differentiated error controls',json.dumps(state_rows))
print('scope: finite Pauli algebra, global-contact admissibility, noncommuting identity, and finite ODE differentiation only')
print('versions',sys.version.split()[0],np.__version__,scipy.__version__)
