from pathlib import Path
import datetime,hashlib,json,subprocess,time
r=Path(__file__).resolve().parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();cmd=['/opt/homebrew/opt/python@3.13/bin/python3.13',str(r/'independent_controls.py')]
with (r/'independent.stdout.log').open('wb') as out,(r/'independent.stderr.log').open('wb') as err:
 try:
  completed=subprocess.run(cmd,cwd=r,stdout=out,stderr=err,timeout=120)
  code=completed.returncode;timed=False
 except subprocess.TimeoutExpired:
  code=None;timed=True
meta={'command':cmd,'start':start,'elapsed_seconds':time.monotonic()-t,'timeout_seconds':120,'timed_out':timed,'exit_code':code,'script_sha256':hashlib.sha256((r/'independent_controls.py').read_bytes()).hexdigest()}
(r/'independent.run.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
