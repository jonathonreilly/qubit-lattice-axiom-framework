# Independent reconstruction before Q author evidence

Frozen target: `BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md`, 729 lines,
SHA-256 `4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820`.
This document was written before opening any Q-author control source, log,
AUTHOR_CHECK, or receipt. The target itself disclosed its proof and described
its controls. The prior X and K reviews and the complete X reconstruction were
read as requested; this is a fresh reconstruction of Q with shared source
information, not blinded discovery or independent discovery of its mechanism.
Root proposed both the approximate-range and polynomial-growth mechanisms and
is a coauthor, not an independent checker. No model/effort override or delegation
was used in this review.

## Contract and source reading

The claim is conditional on the supplied sine-Pauli Hamiltonian, antisymmetric
pair space, one full-torus contact projection, momentum chart, continuous clock,
symmetric energy placement, and exactly the positive globally normalized B25–B30
packet. It is not a theorem uniformly over different preparations or the
complementary Hilbert unit ball, and does not identify these model data with a
physical covariance law.

The target asserts, for every finite T>=0 and 0<lambda<=1/16, a literal constant
C_* with ||W_lambda-z||_(1,Sigma) <= C_*sqrt(lambda)(1+T)^3 uniformly for
|tau|<=T, and a sharper L2 bound of degree two in 1+T. It deduces H1 convergence
on T=lambda^(-eta), eta<1/6, L2 convergence for eta<1/4, simultaneous K
comparison-correction norm limits in the latter window, and an actual total-state
quadratic expectation estimate for all nine canonical bracket components in the
former window. Neither endpoint exponent is included.

The source_manifest.json records full paths, copy paths, hashes, and line counts.
The following source reading is complete before this reconstruction freeze:

- Q target: all 729 lines, Q1–Q34 and the limitations/failure discussion.
- X source: all 587 lines, SHA a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68.
- X review: all 186 lines, SHA 0e17f9647141c200b1efcbe78f60ef6beedc1e249ce1b85544293dddbebe8690.
- X reconstruction: all 426 lines, SHA 04adc0b81d3865f4819b8441e25279ef084bda755e9c0a3206be7d314ea04f9f.
- K source: all 441 lines, SHA 1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9.
- K review: all 230 lines, SHA 64cf08ea2c12f086d0efcc862d17ce0e394f53dfbcbfa5d48db73a10bb9652ca.
- Original B source: all 744 lines, SHA 903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923.
- Original evolved-comparison E source: all 185 lines, SHA d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929.
- Original inverse-energy T source: all 658 lines, SHA 76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990.
- Its review: all 167 lines, SHA d3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796.
- Original degenerate-dynamics D source: lines 70–165 and 395–490, SHA b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876. These contain the physical kernel, Pauli block, and the surviving cone-localized nonuniformity witness. The unrelated D argument is not newly certified.
- Original effective-memory E source: all 500 lines, SHA b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c. In particular the complete E14–E23 proof needed only for Q28's transverse limit was checked.
- Both root lead documents: all 114 and 81 lines, at their target-listed identities. Their proposals are not premises.

The memory review is copied and hashed for recovery but has not been read or
used as a mathematical premise. Historical parent controls, receipts, upstream
publication sources, and unrelated arguments are not newly certified by this
reading. Necessary B definitions and bracket calculations are reproduced in B
itself and have been reconstructed here.

Instructions were read from the supplied main a13caa4885f547c8d206265b031ba7649e539fd9
and planning 3a4b2c66a1ead7a1c48b4359627e968f681e3c39 using read-only git show.
The source worktree is the supplied boost_worktree at named head 773321aa8fdfccc05248682dfc96bf94215034a2;
no mutation or network freshness assertion is made. Applicable AGENTS,
SCIENCE_WORKFLOW, freshness, physics-claim-reviewer, and proof-search-governance
were read. The relevant review-loop contract (lines 1–125) was read, without
invoking a landing or audit operation. Explicit task instructions preserve the
inherited model and effort. A truncated combined display was subsequently read
in complete smaller chunks; no truncated output was accepted as complete reading.

## A. The exact physical residual and cutoff range construction (Q3–Q7)

Use the orthonormal basis (c,T_1,T_2,T_3), T_j=sigma_(1,j)c. Pair antisymmetry
means an even singlet coefficient and odd triplet coefficients. At K=0,
H0=[[0,2s^T],[2s,0]], s=sin q. A physical singlet alpha c has integral alpha=0.
Its H_* image is exactly 2epsilon alpha n; the outer P changes nothing in
this triplet output. If H_*v=0, H0v must be a constant multiple of c. The
singlet coefficient vanishes almost everywhere, and the remaining triplet is
transverse plus that constant times s/(2epsilon^2). Consequently the physical
kernel is precisely F_tr plus span{zeta}, with no constant singlet.

Normalization is ||zeta||^2=(4I0)^(-1) integral epsilon^(-2)=1. Since
H0zeta=c/sqrt(I0), compression kills it. Also Pi h0=zeta/sqrt(I0). For an
odd triplet u, Q u=beta n with beta=n·u-<zeta,u>/(2epsilon sqrt(I0)). The
integral of beta/(2epsilon) is
sqrt(I0)<zeta,u>-sqrt(I0)<zeta,u>=0. The coefficient beta is even. This is a
global constraint, not vanishing of beta pointwise.

Let x_delta=[beta/(2epsilon) 1_(epsilon>=delta)-m_delta]c, where m_delta is
the full-torus mean of the cutoff term. For fixed delta>0 it is an L2 even
mean-zero singlet. Direct application of H_* gives exactly
r-H_*x_delta=beta n 1_(epsilon<delta)+2epsilon n m_delta. The global constraint
rewrites m_delta as minus the omitted cone integral. It is absolutely
convergent under |beta|<=C/epsilon.

For a function of epsilon fold all eight sine cells to [-pi/2,pi/2]^3;
the measure is pi^(-3)dq. There 2|q|/pi<=epsilon<=|q|. The low region lies
inside radius pi delta/2 and the high region lies outside radius delta.
Integrating the positive radial majorants gives, respectively,
(pi/2)delta and pi^2/(4delta). The same folding over a ball of radius
pi sqrt(3)/2 gives I0<=pi sqrt(3)/8; epsilon^2<=3 gives I0>=1/12.

Thus |m_delta|<=C pi delta/4. The uncentered singlet has norm at most
(C/2)[pi^2/(4delta)]^(1/2)=C pi/(4sqrt(delta)); orthogonal mean subtraction
can only lower it. The residual is at most
C sqrt(pi delta/2)+sqrt(6)|m_delta|, because integral epsilon^2=3/2.
For delta<=1 this is c_e C sqrt(delta), exactly Q7. No q differentiation
or assumed cancellation in the residual norm occurs. The construction is
bounded linear W->L2 for fixed delta and commutes with the time and kappa
derivatives under consideration.

The converse shortcut really fails: at time zero r=-c0 a(0)[2epsilon-
1/(2I0 epsilon)]n, so any singlet preimage must have coefficient
-c0 a(0)[1-1/(4I0 epsilon^2)]. This is not L2 at a three-dimensional cone
when a(0)!=0, since integral epsilon^(-4) diverges. A triplet input cannot
supply a triplet output under H_*. The residual is in ker(H_*)^perp but need
not be in the actual range. This supports only the stated failure of this
full-inverse shortcut; approximate range vectors remain available.

## B. Pointwise source and weighted polynomial estimates (Q8–Q13)

For ||u||_w=esssup epsilon|u|, the embedding to L2 has norm 2sqrt(I0).
The zeta rank projection has weighted norm <=1 by integral epsilon^(-2)=4I0.
The tangent and longitudinal pointwise projections have norm <=1. Therefore
Pi and Q on triplets have weighted norms <=2. Direct Pauli algebra yields
B u=i d cross u, d_j=kappa_j cos q_j, so ||B||_w<=|kappa|. On kernel
inputs A=Pi B, giving ||A||_w<=2|kappa| and ||A_j||_w<=2. Hilbert-space
compression separately gives ||A||<=|kappa| and ||A_j||<=1.

The annulus volume is 91pi/384, so 0<m<=sqrt(91pi/384)<1. From B25,
||F||_2=1, each ||F_j||_2<=L=192/7, and support lies inside radius 65/512.
The enclosing radius 1/4 keeps |y_+|,|y_-|>=1/2 and <=7/8. Thus e<=7/4,
|e_j|<=1, w<=1/2, and |w_j|<=1/2. The last follows by differentiating each
unit vector (norm derivative <=1 after its kappa factor 1/2), then dividing
the sum by 4. The product rule in a=F/Z0 integral f w exp(-ite) gives

||a||<=m, ||a_t||<=7m/4,
||a_j||<=m(L+1+T),
||a_jt||<=m(7L/4+11/4+7T/4).

The constant 7L/4+11/4 equals 203/4. This checks S0, including the source
phase derivative. Since epsilon|h0|=2epsilon^2<=6 and
||Pi h0||_w=1/(2I0)<=6, M=8c0S0 dominates all required source bounds.

K8 gives a pointwise-in-kappa estimate without invoking an integrated H1
bound. Here e-sigma(A)>=1, ||R||<=1, R=(e-A)^(-1), and
R_j=-R(e_j-A_j)R has norm <=2. The exponential difference has norm <=2,
and its j derivative norm <=2|t|. Differentiating the integrand bounds the
three contributions by m, 2m, and m|t|. Consequently

||z(t,kappa)||<=d0 m |F|,
||z_j(t,kappa)||<=d0 m[|F_j|+(3+|t|)|F|],

d0=c0/(Z0 sqrt(I0)). These inequalities also bound alpha=<zeta,z> and
alpha_j. They remain true at kappa=0; no absolute-continuity premise is
used in these estimates.

The transverse block satisfies i u_t=D u+g_bath alpha and u(0)=0, with
D=omega J and g_bath=i(d cross n)/(2epsilon sqrt(I0)). At each transverse
plane D is Hermitian. D_j is a scalar multiple of the same J and commutes
with D. Its propagator is pointwise unitary and its j derivative costs
|t-s|. The full D preserves odd parity although J alone need not. With
q0=1/(2sqrt(I0)), the weighted norms of g_bath,g_bath,j,zeta are <=q0/4,
q0,q0 respectively. Variation of constants and its three derivative terms
therefore give the explicit pointwise bound

||z_j||_w <=q0 d0 m{(1+T/4)|F_j|+[3+11T/4+T^2/4]|F|}.

The T^2/4 is the sum of T^2/8 from differentiating the transverse
propagator and T^2/8 from alpha_j under the integral. Taking L2_kappa
proves the sharper derivative polynomial in Q11. Since
q0 d0 m=c0m/(2Z0I0)<=12c0m=J0 and M=406c0m, all of its coefficient
comparisons to 2M(1+T)^2 hold. The corresponding zeroth estimate is
J0(1+T/4). The equation i z_t=A z-Pi g gives
||z_t||_W<=J0(1+T/8)<=M(1+T). Its derivative keeps A_j z and Pi g_j,
giving <=4M(1+T)^2. The pointwise representation supplies integrable
majorants and legitimate parameter differentiation; no q-Sobolev property
of zeta is used.

The source r=Q(Bz-g) and its time derivative have bounds at most
2[(M/4)(1+T)+M] <=3M(1+T). The j derivative has three terms
Q(V_jz+Bz_j-g_j), bounded by <=5M(1+T)^2. The mixed derivative is
Q(V_jz_t+Bz_jt-g_jt), bounded by <=6M(1+T)^2. This proves Q12's common
R0,R1. All are longitudinal and zeta-orthogonal because Q is fixed.
Finally Hilbert unitarity gives ||z||<=MT; integrating A_jz-Pi g_j with
its time-dependent estimates gives ||z_j||<=M(T+T^2), Q13.

## C. Every normalization and source approximation (Q14–Q20)

For u_lambda(y)=sin(lambda y)/lambda, |u-y|<=lambda^2/6 and
||Du-I||<=lambda^2/2 on the chosen ball. Its radius is at least |y|/2>=1/4.
The unit-vector difference is <=2|u-y|/|y|<=2lambda^2/3. Splitting
Dnu=(I-nu nu^T)Du/|u| from Dn=(I-nn^T)/|y| gives the three terms
16lambda^2/3, 2lambda^2, and 4lambda^2/3, totaling 26lambda^2/3.
These estimates check every denominator in Q14.

The two radial lengths give |e_lambda-e|<=lambda^2/3. Differentiating
them, each kappa factor is 1/2, and the bound is
(2/3+1/2)lambda^2=7lambda^2/6 after summing the two halves. The projector
weight difference is <=lambda^2/3. Its derivative difference is bounded
by [26/3+4/3]lambda^2/4=5lambda^2/2: two differentiated unit-vector terms
each carry 1/2, and the undifferentiated factor errors are retained.
The exact Q15 estimates e_lambda<=7/4, |e_lambda,j|<=1 and
|w_lambda,j|<=1 follow respectively from sine contraction, the norm of the
cosine Jacobian, and the radius lower bound. The bound 1/4<=w_lambda<=1/2
uses the same exact positive-positive preparation as B, including its dot
product sign, not a substituted band.

Both Z_lambda and Z0 are global scalars. Their squared difference is
<=lambda^2/3; dividing by Z_lambda+Z0>=1 proves their difference bound,
and Z_lambda Z0>=1/4 gives the inverse difference. The exact six-dimensional
normalization cancels both normalized momentum measures and the packet
prefactor. The contact amplitude has no additional lambda or c0 factor.
The K-only isometry separately supplies c0 lambda^(3/2), giving
n_lambda^2=1-c0^2 lambda^3||a_lambda(0)||^2. Since ||a_lambda(0)||<=m,
n_lambda>=1/2 and n_lambda^(-1)-1<=2c0^2m^2lambda^3. Neither normalizer
has any kappa derivative.

The phase inequality |exp(-it e_lambda)-exp(-it e)|<=|t|lambda^2/3
holds for every finite time, even when lambda^2 T is large. For the inner
integral I_lambda, the derivative difference is bounded by
m lambda^2[5/2+13|t|/12+t^2/6]. Its linear coefficient contains the weight
phase difference 1/6 and the differentiated-phase contributions 1/3+7/12.
Multiplication by F/Z and differentiation of F add the explicit constants
in Q17; 2mL+17m/3<=2m(L+3)=C_a. Thus every Q17 source power is justified
before choosing a lambda-dependent time interval.

From the singlet/triplet symbol, E_lambda has norm at most
lambda |kappa|^2/4+lambda^2 sum|kappa_j|^3/24<=lambda/32.
Its j derivative is <=lambda|kappa_j|/2+lambda^2 kappa_j^2/8<=lambda/4.
Here the difference-spin and total-spin blocks are both retained. Direct
original-symbol differentiation gives ||G_lambda,j||<=1. Hence
||V_lambda||<=1. The same sine/cosine bounds give
||h_lambda||<=sqrt(6), ||h_lambda-h0||<=lambda^2/64, and
||h_lambda,j||<=lambda^2/8.

Splitting h_lambda a_lambda/n_lambda-h0a and its derivative into the
h, a, and n factors yields exactly Q19's displayed coefficient bounds.
They are dominated by M and 2M using m<1, c0<1, C_a<=2S0. No normalizer,
projector, envelope, or source-phase derivative is missing. Duhamel's
propagator derivative has norm <=|t|, so integrating the differentiated
source and propagator terms gives ||W||<=MT and ||W_j||<=M(T+T^2), Q20.

## D. Noncommuting corrector and differentiated error (Q21–Q27)

The integration identity Q21 has all signs as written. An alternate
arrangement checks it: let J(t)=integral_0^t U_lambda(t-s)f(s)ds. It solves
i J_t=G_lambda J+i f with J(0)=0. Set
J_app=-i lambda x_delta(t)+i lambda U_lambda(t)x_delta(0).
Then J_app(0)=0 and

(i partial_t-G_lambda)J_app
 =i f+lambda x_delta,t+i lambda V_lambda x_delta-i eta_delta.

The equation for J-J_app therefore gives
+i lambda integral U x_delta,t -lambda integral U V_lambda x_delta
+integral U eta_delta, which is precisely Q21. This is a different
approximate-solution organization of the same identity and verifies both
endpoints and the order of V_lambda without any commutation.

For f and f_t of W norm <=R, Q7 bounds the integral by
R[c_x lambda delta^(-1/2)(2+2T)+c_e sqrt(delta)T]. Choosing delta=lambda
in its allowed range gives <=K_R R sqrt(lambda)(1+T),
K_R=2c_x+c_e. This is a bound in full physical L2 after Minkowski in kappa.

Subtract the exact equations iW_t=G_lambda W-g_lambda and
iz_t=A z-Pi g. Since H_*z=0, the result is exactly

iD_t=G_lambda D+Q(Bz-g)+E_lambda z+g-g_lambda.

Differentiating this exact equation retains (G_lambda,j)D, r_j, and
E_lambda,j z+E_lambda z_j+g_j-g_lambda,j. Q13/Q18/Q19 give the respective
derivative-error bounds Mlambda T/4, Mlambda T(1+T)/32, and
2Mlambda^2(1+T)^2, whose sum is <=Mlambda(1+T)^2 for lambda<=1/16.
The undifferentiated error is <=Mlambda(1+T). The error need not lie in
the kernel or triplet sector and is bounded in full physical L2.

Use Q22 on r with R0=3M(1+T), and integrate the ordinary error source.
This gives C_D0 sqrt(lambda)(1+T)^2, C_D0=M(3K_R+1). For a j derivative,
Q22 on r_j contributes 6MK_R sqrt(lambda)(1+T)^3; integrating G_jD adds
M(3K_R+1)sqrt(lambda)(1+T)^3; integrating e_j adds at most
Msqrt(lambda)(1+T)^3. Their sum is M(9K_R+2)sqrt(lambda)(1+T)^3.
Summing zeroth and three first derivatives gives exactly C_*=M(30K_R+7).
This proves the stronger sum norm claimed in Q1. Negative times use oriented
integrals and absolute lengths; zero time is included.

Substitute T=lambda^(-eta) only after these all-T estimates. The exponents
are 1/2-3eta in H1 and 1/2-2eta in L2. They are positive precisely in the
stated sufficient open windows eta<1/6 and eta<1/4. No endpoint claim,
optimality, or failure outside the windows follows.

## E. Imported outgoing result and simultaneous limits (Q28)

The required K premises were checked in their original proofs. Its exact
positive-frequency resolvent formula follows either by integrating the forced
ODE or differentiating the proposed solution with its zero initial condition.
Triangle inequalities give 1<=e-E<=2 on the actual source and sigma(A), so
m/8<=chi(E)<=m/2 and ||z||<=A0=d0m uniformly for all time. The rapid outgoing
remainder follows by radial integration by parts: e_r>=4/3, all amplitude
radial derivatives vanish at both annular endpoints, and the resolvent has
bounded parameter derivatives because e-A>=1. One additional integration
controls the time factor from a kappa phase derivative. This is a Hilbert-valued
statement, using no q derivative of zeta.

Only the transverse part of Q28 needs the original memory measure theorem.
Its cone-shell change of variables is sound: on radii sqrt(chi)/16 to
sqrt(chi)/8, the t=hat(kappa)·omega coordinate maps monotonically onto the
interior frequency interval, with derivative between 7b/8 and 9b/8 and
|d cross n|>=b sqrt(chi)/4. Keeping one helicity and normalized full-torus
measure gives beta(dE)>=b chi^(3/2)/(16384pi^2I0)dE there. The Schur
resolvent M=1/(z-Sigma) consequently obeys a uniform upper-half-plane
bound on each interior strip. Its Poisson interval inequality dominates
all interior spectral mass by a multiple of Lebesgue measure, excluding
singular continuous mass as well as atoms. At ±b, strict pointwise
|d(q)|<b almost everywhere excludes eigenvectors under compression. Thus
the zeta spectral measure is absolutely continuous for every b>0.

The Fourier transform of chi rho is then zero at infinity by interval-step
L1 approximation. With K's rapidly decreasing explicit forcing remainder,
the scalar zeta coefficient tends to zero. The total norm tends to V by
unitarity; subtracting the scalar coefficient squared gives the same V
for the transverse norm. Dominated convergence in kappa is legitimate
with |F|^2 majorants, and kappa=0 remains a null exceptional fiber. No
uniform near-zero spectral-decay rate is used. The finite-bath recurrence
is not a counterexample to this cone-density hypothesis.

For any |tau_lambda|<=lambda^(-eta), |tau_lambda|->infinity, eta<1/4,
Q27 gives ||W_lambda-z||->0. The squared-norm difference is bounded by
||W-z||(2||z||+||W-z||), and K gives uniform ||z||. The same holds after
F_tr. The exact K-only isometry gives ||W||^2=||w_phys||^2/lambda and
commutes with F_tr. This proves the simultaneous Q28, with K's positive
V bounds, without interchanging an uncontrolled ordered limit. These
are correction norms; they are not total-state probabilities.

## F. All-component coefficient and expectation constants (Q29–Q34)

The full B normal form is reconstructed by compressing the fixed energy
dipole and current, including both current ranks, then normal ordering the
q derivative onto its smooth form factors. It contains A_b=[H,J_b] as
the coefficient of partial_Ka, with all B13 constant ranks retained.
The common smooth domain is preserved for every fixed lambda,time, and
the normal form extends H1_K(L2_q)->L2. Symmetry follows on the core and
then by continuity/density; equivalently C-C*=partial_Ka A and A*=-A.
No self-adjoint extension of the dipole is required.

At zero, h=2v0, h_b=0, h_ab=-delta_ab v_b/2. Both current ranks contribute,
so J_b,j(0)=delta_jb L_b. Since J_b(0)=0 including its q dependence,
C_ab(0)=delta_ab H_*(L_b-I) and A_b'(0)[kappa]=kappa_b[H_*,L_b].
A kernel-valued z and each z_j are killed by H_*. Therefore
Q0,ab z=H_*L_b partial_a(kappa_b z), and its pairing with z is exactly
zero for all a,b, although the resulting vector need not vanish.
The off-diagonal derivative coefficient is also symmetric: both its
coefficient derivative and its constant skew part vanish when a!=b.

The two Q0 coefficient norms are <=6+4sqrt(3)<13 and
3+sqrt(3)<13, so ||Q0u||<=13||u||_(1,Sigma). For Q30's quantitative
coefficient error, derivatives of H0 of order n in unit K directions
are bounded by 2^(1-n), by the Pauli norm and coordinatewise product bound.
Compression preserves these estimates. Thus the (norm, first, second)
bounds on J_b are (9,7,6), and
||A_b''||<=2[(1/2)9+7+7+4·6]=85.

For C_ab', the diagonal multiplier contributes <=6: differentiating hi
contributes at most 2 in total, and differentiating the two cos(2kia)
factors contributes at most 2sqrt(3)<4. The two first contact ranks
contribute 3/2+5=13/2. The F_b,a norm is <=6 and its derivative <=5, so
(H F_b,a)' is bounded by 6+4·5=26. The fiber differential operator acts
only on the displayed smooth factors. Their (norm, derivative) bounds are
(3,5/2) for L_a h_b, (8,6) for L_a h, (4,3) for L_a^dagger h, and
(2,3/2) for L_a^dagger h_b. These follow from ||H_Delta||<=4,
||H_Delta'||<=1, and q-derivative bounds 2,1,1,1/2 for h,h_b,h',h_b'.
Differentiating their four ranks contributes respectively 13,10,5,8.
The sum is 6+13/2+26+36=149/2<75.

Taylor along K=lambda kappa gives the constant coefficient error
<=75lambda/4 and the derivative coefficient error <=85lambda/32.
Their sum is 685lambda/32<22lambda, valid for every a,b. This proves Q30;
no derivative of the input field or of zeta has been hidden in it.

K8's fiber estimates imply ||z||<=A0 and
||z||_(1,Sigma)<=A0(3L+10+3T)<=Z1(1+T), Z1=A0(3L+10).
Q25 and Q1 supply the two error norms in Q31. The exact X31 free
comparison with the initial global n gives
||Rv||<=8lambda^3+(376+6T)lambda^(3/2)
<=384lambda^(3/2)(1+T), and ||v||<=2. This includes the full contact tail.
With w_phys=sqrt(lambda)T_lambda^(-1)W, the free expectation divided by
lambda is <=768sqrt(lambda)(1+T); the two cross terms, after using actual
finite-lambda symmetry, are <=768lambda(1+T)||W||. The exact state remains
normalized and no orthogonality between comparison and correction is assumed.

For s=1+T, symmetry and <z,Q0z>=0 give
<W,Q0W>=<D,Q0W>+<Q0z,D>. This is bounded by
26 C_D0 Z1 sqrt(lambda)s^3+13 C_D0 C_*lambda s^5.
The coefficient error is bounded by
22lambda[A0+C_D0sqrt(lambda)s^2][Z1s+C_*sqrt(lambda)s^3].
Expand it: its terms have powers lambda s, lambda^(3/2)s^3 (twice),
and lambda^2s^5. Since lambda<=1 and s>=1, they fit the claimed two
majorants sqrt(lambda)s^3 and lambda s^5. The free and cross terms fit
the same majorants. Q31's C_mean is the sum of adequate positive
coefficients. This establishes Q33 with every total-state contribution
retained. Substitution gives exponents 1/2-3eta and 1-5eta, both positive
when eta<1/6. The all-component claim Q34 follows. It is not extended to
eta<1/4, is not a vector-norm cancellation, and is not full boost closure.

## Pre-author conclusion and planned independent evidence

No mathematical correction or unresolved proof step has emerged in the
reconstructed Q1–Q34 theorem with these exact premises. The most consequential
new bridge is the physical mean-zero singlet corrector and its weighted
regularity for the actual forcing. Its analytic cone proof, polynomial
pointwise estimates, noncommuting identity, and differentiated error all check.
The pre-evidence judgment remains subject to discriminating independent finite
checks and the subsequent author-evidence/provenance examination.

A separate finite control will use actual Pauli matrices on a parity-preserving
weighted set of q pairs, with a single global contact projection, and compare
an independently integrated forced solution to the corrected-solution identity.
It will challenge centering, both endpoints, time differentiation, and the
noncommuting V term. A separate state/parameter control will retain source
weight and phase derivatives and the full error equation. These finite checks
can detect algebraic implementation defects, but cannot establish the continuum
cone estimates, weighted Banach bounds, absolute continuity, or growing-time
theorem. No Lean or other formal proof verification is claimed.
