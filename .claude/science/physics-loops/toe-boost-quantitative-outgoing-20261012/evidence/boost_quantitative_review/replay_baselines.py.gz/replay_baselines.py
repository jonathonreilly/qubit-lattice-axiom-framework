from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,time,datetime
r=Path(__file__).resolve().parent
scripts=['corrector_controls.py','polynomial_controls.py','mean_controls.py']

def run(name):
 p=r/'author_packet'/name;stem=r/('replay_'+p.stem);cmd=['/opt/homebrew/opt/python@3.13/bin/python3.13',str(p)]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic()
 with stem.with_suffix('.stdout.log').open('xb') as out,stem.with_suffix('.stderr.log').open('xb') as err:
  try:
   result=subprocess.run(cmd,cwd=r,stdout=out,stderr=err,timeout=120);code=result.returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 meta={'command':cmd,'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'start':started,'timeout_seconds':120,'timed_out':timed,'exit_code':code,'elapsed_seconds':time.monotonic()-tic}
 for suffix in ['stdout','stderr']:meta[suffix+'_sha256']=hashlib.sha256(stem.with_suffix('.'+suffix+'.log').read_bytes()).hexdigest()
 stem.with_suffix('.execution.json').write_text(json.dumps(meta,indent=2)+'\n');return meta
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,scripts))
print(json.dumps(results,indent=2))
assert all(x['exit_code']==0 and not x['timed_out'] for x in results)
