from pathlib import Path
import datetime,hashlib,json,subprocess,time
r=Path(__file__).resolve().parent;cmd=['/opt/homebrew/opt/python@3.13/bin/python3.13',str(r/'verify_identity.py')]
tic=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'identity.stdout.log').open('xb') as out,(r/'identity.stderr.log').open('xb') as err:
 try:proc=subprocess.run(cmd,cwd=r,stdout=out,stderr=err,timeout=60);code=proc.returncode;timed=False
 except subprocess.TimeoutExpired:code=None;timed=True
meta={'command':cmd,'start':start,'timeout_seconds':60,'timed_out':timed,'exit_code':code,'elapsed_seconds':time.monotonic()-tic,'source_sha256':hashlib.sha256((r/'verify_identity.py').read_bytes()).hexdigest()}
(r/'identity.execution.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
