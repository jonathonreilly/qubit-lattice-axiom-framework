---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Gapless weak-momentum dynamics on the full physical zero space

2026-10-11. External author derivation for the supplied excluded Weyl walk.

The full physical zero space has a bounded, explicitly coupled effective
generator. For every fixed vector in that space, its evolution at
K=lambda kappa and physical time tau/lambda converges strongly to this
effective evolution, uniformly on compact tau intervals. No spectral gap
or isolated-eigenvalue perturbation theorem is used. The actual canonical
current has a corresponding limit. Starting from the threshold dressing
vector, equal components of kappa give a strict quadratic-in-tau change
of that limiting current coefficient. A normalizable total-momentum
packet realizes the same response.

These are statements about preparation in the K=0 zero space. They do
not settle the current of arbitrary projected positive-band packets,
whose initial vectors depend on lambda. An explicit cone-concentrating
family shows that even on the zero space the strong evolution limit
cannot be upgraded to operator-norm convergence. That state comparison
counterexample is not a canonical-current counterexample.

## 1. Sources, reading coverage, and the supplied premise boundary

S denotes `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`;
W denotes `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/worktree`.
Inner products are linear in their second argument. All relative-torus
integrals use dq/(2pi)^3. Coordinates, lattice units, clock units, two-spin
walk, antisymmetric pair Hilbert space, contact exclusion, and the named
canonical energy placement remain supplied premises. No physical law,
Record interpretation, or realized-state assertion is added.

| Source | SHA-256 and reading coverage |
|---|---|
| S/EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324`; all 457 lines; frozen |
| S/excluded_walk_long_time/receipt.json | `bdd9d7b0caedbf168f4e45dead01b7a816f321b5894ae5671c1dcdedb81d35dc`; frozen provenance reused after identity verification |
| S/EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`; all 190 lines |
| S/EXCLUDED_WALK_TRANSPORT_PROBE.md | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526`; prior complete 322-line reading reused after identity verification |
| W/docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`; prior complete 226-line reading reused after identity verification |

The checked canonical-current and Cook reviews remain unchanged and are
identified in the new receipt. Their checks are not a review of this new
proof. The present proof does not invoke the Cook bridge's incoming or
outgoing spectral regularity assumptions, scattering preparation, or a
threshold completeness claim. The M6 walk contract is reused only within
its named supplied model. Its finite-time band conclusion supplies no
uniform-in-time conclusion here.

The bounded local-main comparison used
`e485eab6b09b3957df5772104d3ea3980108d7fa`. The exact search and full output
are in `excluded_walk_degenerate/prior_statement_search.{json,log}`.
The matching lines concern other models or the already-read M6 contract;
none states this full-zero-space evolution result. This is a scoped
statement comparison, not a global novelty claim or remote-main survey.
Current instruction identities match the prior receipt. The selected
physics-loop procedure is continued under the narrower external-file
brief. No branch, publication, primitive, audit, prompt, or frozen packet
has been edited. No specialized averaging theorem is imported: the
gapless limit below is proved with a spectral cutoff and bounded-operator
Duhamel estimates.

## 2. Fixed physical space and the complete zero projection

In the source's fixed total-momentum chart, set

    H0(K,q)=sigma_1·sin(K/2+q)+sigma_2·sin(K/2-q),
    C=|c><c|, P=I-C, H_D(K)=P H0(K)P restricted to P.

Here c is the constant normalized singlet. The auxiliary vector c in the
zero extension PH0P is excluded from the physical Hilbert space throughout.
Let T_j=sigma_(1,j)c, s_j=sin q_j, epsilon=|s|, and n=s/epsilon almost
everywhere. In the singlet/Cartesian-triplet representation,

    H0(0,q)=[ 0    2s^T ],
             [ 2s   0   ]
    I0=integral 1/(4epsilon^2),
    zeta(q)=n(q)/(2epsilon(q)sqrt(I0)) in the triplet block.       (D1)

The source proves 1/12<=I0<=9/8, ||zeta||=1, and
H0(0)zeta=c/sqrt(I0). The singularity is square-integrable in three
dimensions. It is not generally permissible to differentiate zeta in
the unbounded energy dipole: its inverse-radius behavior fails H1 near
a cone. Only bounded operators act on zeta below.

Let F be the free-kernel projection. Its singlet block is zero and its
triplet block is pointwise I-nn^T. It acts on odd triplet fields, consistent
with pair antisymmetry. The singlet coefficient is even. Put

    H_*=H_D(0),
    Z=ker H_* = ran F direct-sum span{zeta},
    Pi=F+|zeta><zeta|.                                         (D2)

For completeness, H_*psi=0 with psi in P means H0(0)psi=alpha c.
Subtract alpha sqrt(I0) zeta to obtain a free-kernel vector. Conversely
both summands in D2 are physical zero vectors. Thus D2 is the entire
physical zero space, not just a selected finite-dimensional subspace.
There is no spectral gap about it: dispersive energies approach zero
alongside the free flat band. All operators below act on this fixed
physical Hilbert space, so their kernels and limits can be compared.

## 3. The bounded first derivative and its full effective block

Fix kappa in R^3, write b=|kappa|, and take lambda>0. The exact free
singlet/triplet block at K=lambda kappa is

    [ 0                         2(a_lambda*s)^T ]
    [ 2(a_lambda*s)              i b_lambda cross ],

    (a_lambda)_j=cos(lambda kappa_j/2),
    (b_lambda)_j=2sin(lambda kappa_j/2)cos q_j.                  (D3)

The sign follows directly from
(sigma_(1,l)+sigma_(2,l))T_j=2i epsilon_(ljk) T_k.
Consequently the bounded self-adjoint derivative B_kappa has zero
singlet block and triplet action

    B_kappa u=i d cross u,       d_j=kappa_j cos q_j,
    ||B_kappa||<=b.                                           (D4)

It annihilates c and preserves P. The inequalities
|cos x-1|<=x^2/2 and |sin x-x|<=|x|^3/6 give

    H_D(lambda kappa)/lambda=H_*/lambda+B_kappa+R_lambda,
    ||R_lambda||<=r_lambda:=lambda b^2/4+lambda^2 b^3/24.      (D5)

Indeed the singlet-triplet remainder before division by lambda has norm
at most lambda^2 b^2/4; the triplet remainder has norm at most
lambda^3 b^3/24. Compression cannot enlarge either norm.

Represent z in Z by (u,alpha), meaning u+alpha zeta with u transverse.
The correct effective generator is A_kappa=Pi B_kappa Pi, with

    A_kappa=[ D_kappa       g_kappa ],
             [ <g_kappa|     0      ],
    D_kappa u=i(d·n)n cross u,
    g_kappa(q)=i(d cross n)/(2epsilon sqrt(I0)).               (D6)

To verify the transverse block, for any transverse u,
(I-nn^T)(d cross u)=(d·n)n cross u. B_kappa zeta is already
transverse, and <zeta,B_kappa zeta>=0 pointwise. This proves both
off-diagonal entries and their signs. The parities are preserved.
The vector g_kappa is in L2 and ||A_kappa||<=b, because D6 is a
compression of the bounded D4. No inverse Hamiltonian or derivative
of zeta is being used. In particular the equations are defined on all Z:

    i partial_tau u=D_kappa u+alpha g_kappa,
    i partial_tau alpha=<g_kappa,u>.                          (D7)

Dropping g_kappa would discard the physical threshold dressing's coupling
to the free flat band. It is not a consistent reduction of this generator.

## 4. A gapless strong limit with an explicit vector-dependent remainder

For every fixed z in Z and T<infinity,

    sup_(|tau|<=T)
      ||exp[-i tau H_D(lambda kappa)/lambda]z
                         -exp[-i tau A_kappa]z|| ->0.         (D8)

Write U_lambda(tau)=exp[-i tau H_D(lambda kappa)/lambda].
Here is a direct proof. It works for any bounded self-adjoint H_* and
B on a fixed Hilbert space, with Pi the full kernel projection and a
self-adjoint remainder R_lambda with ||R_lambda||->0. On our physical
space Pi is exactly D2. For sigma>0, let

    Q_sigma=1_(|H_*|>sigma)(H_*),
    E_sigma=1_(0<|H_*|<=sigma)(H_*),
    v(tau)=exp(-i tau A)z,       A=Pi B Pi,
    y_sigma(tau)=-H_*^(-1)Q_sigma B v(tau).                   (D9)

The inverse in D9 is the bounded spectral-cutoff inverse, of norm at
most 1/sigma. It is not an inverse on the gapless complement. Let
w_lambda=v+lambda y_sigma. Exact differentiation gives

    (H_*/lambda+B)w_lambda=A v+E_sigma Bv+lambda B y_sigma,
    i partial_tau w_lambda=A v+i lambda partial_tau y_sigma.

The residual is therefore

    i partial_tau w_lambda-(H_*/lambda+B)w_lambda
      =-E_sigma Bv+lambda(i partial_tau y_sigma-B y_sigma).   (D10)

We have ||y_sigma||<=b||z||/sigma and
||partial_tau y_sigma||<=b^2||z||/sigma. Compare w_lambda with
the exact unitary evolution, accounting for the initial and final
correctors, then compare the evolutions with and without R_lambda.
Bounded-operator Duhamel gives the finite estimate

    sup_(|tau|<=T) ||U_lambda(tau)z-v(tau)||
      <= (2lambda b+2T lambda b^2)||z||/sigma
         +T M_z(sigma,T)+T r_lambda ||z||,

    M_z(sigma,T)=sup_(|tau|<=T)||E_sigma Bv(tau)||.            (D11)

For every fixed vector x, ||E_sigma x||->0 by its finite spectral
measure and the decreasing sets 0<|E|<=sigma. The set of vectors
Bv(tau), |tau|<=T, is compact, since v is norm-continuous on a compact
interval. A finite net and ||E_sigma||<=1 consequently give
M_z(sigma,T)->0. First take lambda->0 at fixed sigma, then take
sigma->0. This proves D8, including both signs of tau.

D11 states the exact missing quantitative input: a bound on the low
nonzero spectral mass of B exp(-i tau A)z. No such bound uniform over
the unit ball of Z follows from this proof. Section 8 gives an explicit
failure of operator-norm convergence, so that distinction is substantive.
There is also no estimate here uniform for T growing with 1/lambda.

## 5. The actual canonical current on the effective space

Use the source's bounded canonical current extension, derived from its
specified compressed local energy densities:

    J_a(K)=P[sin K_a cos(2q_a)]P
                         -|h'_a><h|-|h><h'_a|,
    h=2 sum_j cos(K_j/2) sin q_j T_j,
    h'_a=-sin(K_a/2)sin q_a T_a.                            (D12)

We use this bounded identity on all physical L2 vectors. We do not
apply the source's unbounded dipole or an H1 commutator to zeta.
Set v=s·T and v_a=s_a T_a; then

    J_a(lambda kappa)/lambda=kappa_a L_a+O(lambda^2),
    L_a=P cos(2q_a)P+|v_a><v|+|v><v_a|,
    ||L_a||<=1+sqrt(3).                                    (D13)

One explicit operator-norm remainder is

    ||J_a(lambda kappa)/lambda-kappa_a L_a||
      <=lambda^2[(1/6+sqrt(3)/24)|kappa_a|^3
                                    +|kappa_a|b^2/8].       (D14)

For D14, ||h||<=sqrt(6), ||v_a||=1/sqrt(2), and
||h-2v||<=lambda^2 b^2/(4sqrt(2)). Also
||h'_a/lambda+kappa_a v_a/2||
<=lambda^2|kappa_a|^3/(48sqrt(2)). Substitute into D12 and
use the cubic sine remainder for its multiplication term. If kappa_a=0,
J_a(lambda kappa) is exactly zero; no division by kappa_a is needed.

The compression of L_a to the entire zero space is

    calJ_a=Pi L_a Pi=[ m_a I_F       r_a ],
                      [ <r_a|        1   ],
    m_a(q)=cos(2q_a),
    r_a(q)=s_a(e_a-n_a n)/(2sqrt(I0)).                       (D15)

Here multiplication by m_a preserves transverse fields. Fv=0,
<v,zeta>=1/(2sqrt(I0)), and
<v_a,zeta>=1/(6sqrt(I0)). Thus the transverse cross term is
Fv_a/(2sqrt(I0)). The lower-right entry retains the exact canonical
cancellation proved in the frozen probe:

    <zeta,(cos(2q_a)-1)zeta>=-1/(6I0),
    <zeta,(|v_a><v|+|v><v_a|)zeta>=+1/(6I0).                (D16)

For normalized z in Z let z(tau)=exp(-i tau A_kappa)z.
D8 and D14 imply, uniformly on every compact tau interval,

    <U_lambda(tau)z,J_a(lambda kappa)U_lambda(tau)z>/lambda
      ->kappa_a <z(tau),calJ_a z(tau)>.                     (D17)

For example the error is bounded by the right side of D14 plus
2|kappa_a|(1+sqrt(3)) times the state error in D11. For
z(tau)=(u(tau),alpha(tau)), the right-hand quadratic form is explicitly

    integral m_a|u|^2+|alpha|^2
                  +2 Re[conjugate(alpha)<r_a,u>].          (D18)

The current is the supplied placement's current, not the derivative
of the effective generator with respect to kappa. D15 includes both
the dressing-transverse cross term and the diagonal cancellation.

## 6. An actual current response of the dressing preparation

The full-zero-space trace identity differs from the frozen probe's
singlet/longitudinal identity. Since sum_a r_a=0 and
sum_a m_a=3-2epsilon^2, D15 gives, for any normalized (u,alpha),

    sum_a <(u,alpha),calJ_a(u,alpha)>
                    =3-2 integral epsilon^2|u|^2.          (D19)

The frozen L24 identity was compressed to the singlet/longitudinal
subspace. It cannot be substituted for D19 after transverse amplitude
has been created. D16 remains exactly true.

Take kappa=k(1,1,1), k nonzero, and z=zeta. The even cyclic permutation
of the three coordinates is a proper rotation. In triplet coordinates
it acts as u(q)->R u(R^(-1)q), preserves zeta, commutes with A_kappa,
and cyclically permutes calJ_a. Cross products transform covariantly
under this rotation. No improper-rotation spin convention is needed.
The three expectations are therefore equal, so for all real tau

    <z(tau),calJ_a z(tau)>
             =1-(2/3)||epsilon u(tau)||^2,   a=1,2,3.       (D20)

This is an exact identity of the bounded effective dynamics, not merely
a second-order expansion. The coupling in D6 is nonzero. More precisely,

    gamma_kappa^2:=||epsilon g_kappa||^2
       =(1/(4I0)) integral[|d|^2-(d·n)^2],
    b^2/(12I0)<=gamma_kappa^2<=b^2/(8I0),
    gamma_kappa^2>=2b^2/27.                                (D21)

To verify the bounds, separate-coordinate reflections make all mixed
integrals in (d·n)^2 vanish. Cubic symmetry makes the remaining common
coefficient L=integral cos^2(q_1)n_1^2. Write
L=1/3-A0, where A0=integral s_1^4/epsilon^2. Cauchy-Schwarz gives

    A0 integral epsilon^2 >= (integral s_1^2)^2,
    A0>= (1/2)^2/(3/2)=1/6.

Hence 0<=L<=1/6, while integral |d|^2=b^2/2. This proves the
first two bounds in D21; I0<=9/8 proves the last. In particular g_kappa
is nonzero for every nonzero kappa, not just the chosen diagonal.

The bounded exponential Taylor remainder gives

    ||u(tau)+i tau g_kappa||<=b^2 tau^2/2,
    ||epsilon u(tau)||>=|tau|gamma_kappa
                                      -sqrt(3)b^2 tau^2/2. (D22)

For 0<|tau|<=sqrt(2)/(9b), the last expression is at least
|tau|gamma_kappa/2. Combining D20-D22 yields

    1-<z(tau),calJ_a z(tau)>
          >=tau^2 gamma_kappa^2/6 >=tau^2 b^2/81.           (D23)

Its exact quadratic coefficient is
-(2/3)gamma_kappa^2 tau^2+O(|tau|^3). The first derivative vanishes.
The corresponding actual canonical current satisfies

    lim_(lambda->0)
      [<U_lambda(tau)zeta,J_a(lambda kappa)U_lambda(tau)zeta>
                      -<zeta,J_a(lambda kappa)zeta>]/lambda
       =-(2k/3)||epsilon u(tau)||^2.                       (D24)

Thus a strict current response occurs on physical time tau/lambda for
this zero-space preparation. On D23's interval the drift has sign -sgn(k).
The magnitude is bounded below by |k|tau^2b^2/81 on D23's interval.
This does not contradict the earlier canonical cancellation: initially
u=0, and the new response is caused by the transverse population that
the full degenerate generator creates.

## 7. Normalizable total-momentum packets

The fiber statement can be made into an ordinary normalized packet.
Fix a compact kappa set and an L2 section Psi(kappa) in Z. In the
source's chart identify K=lambda kappa and set

    Psi_lambda(K,q)=lambda^(-3/2)Psi(K/lambda,q),

with measures dK/(2pi)^3 and dkappa/(2pi)^3. For small lambda its
support is in the chart and its norm is unchanged. Apply
D8 at almost every kappa. The supremum-in-tau squared error is bounded
by 4||Psi(kappa)||^2, so dominated convergence gives the global strong
limit uniformly on compact tau intervals. D14 is uniform on the
compact kappa set; D17 consequently integrates with the actual kappa
weights. No fiberwise preparation renormalization is inserted.

Here is a concrete nonzero response with full three-dimensional
total-momentum support. Put kappa0=(1,1,1), tau0=1/20, and

    C0=2+sqrt(3)+(1+sqrt(3))/10,
    rho=1/(21600 C0).

Let f be any normalized scalar L2 envelope supported in the ball of
radius rho about kappa0, and let Psi(kappa)=f(kappa)zeta. At kappa0,
D23 bounds the a-th scaled current drift by -1/10800. For each a define

    F_a(kappa)=kappa_a[<exp(-i tau0 A_kappa)zeta,
                  calJ_a exp(-i tau0 A_kappa)zeta>-1].

Since ||A_kappa-A_kappa0||<=|kappa-kappa0|, bounded Duhamel and
||calJ_a||<=1+sqrt(3) give

    |F_a(kappa)-F_a(kappa0)|<=C0|kappa-kappa0|.

Indeed the two contributions are at most
(2+sqrt(3))|kappa-kappa0| and
2(1+sqrt(3))|tau0||kappa-kappa0|. It follows that F_a<=-1/21600
on the envelope support. The normalized global packet therefore obeys

    lim_(lambda->0) (actual canonical current drift at tau0/lambda)/lambda
                       =integral |f(kappa)|^2 F_a(kappa)
                       <=-1/21600,   a=1,2,3.             (D25)

The limit is rigorous; the proof does not quantify its finite-lambda
onset. These states are prepared from zeta, have contact projection
already equal to themselves, and are not the arbitrary free positive
central-band packets of the original transport question. The lambda
here is the weak-total-momentum parameter. No energy-band condition
for these dressing packets has been asserted.

## 8. Why the strong limit is not uniform over the zero-space unit ball

This section supplies a constructive limitation of D8. Fix kappa=e_1,
p0=e_3, eta=1/100, and let Omega_lambda be the union of the q balls
of radius lambda eta about +/-lambda p0. Its normalized volume is

    mu(Omega_lambda)=lambda^3 eta^3/(3pi^2).

Define an odd, normalized transverse triplet u_lambda by taking the
normalized vector (I-nn^T)e_2 on the positive ball, its negative on
the negative ball, and the constant scalar amplitude mu(Omega)^(-1/2).
It is zero elsewhere. Thus u_lambda is an exact member of ran F in
the continuum fiber for each lambda, not a point-momentum delta vector.

First, effective evolution is close to this initial vector. D_kappa
preserves its q support and has norm at most 2eta there for sufficiently
small lambda. The off-diagonal coupling along this supported evolution
is bounded by ||1_Omega g_kappa||, and

    ||1_Omega g_kappa||
       <=sqrt(lambda) eta^(3/2)/[sqrt(48I0)(1-eta)].          (D26)

For D26 use epsilon(q)>=(2/pi)|q| when each |q_j|<=pi/2 and the
displayed exact volume. Duhamel for D6, compared with D_kappa direct-sum
0, gives

    limsup_(lambda->0)
      ||exp(-i tau A_kappa)u_lambda-u_lambda||<=2eta|tau|.   (D27)

Second, compression is a vanishing perturbation along the localized
free evolution at this rescaled time. On the full fiber the excluded
generator differs from the free one by

    V_K=-|h_K><c|-|c><h_K|.

Free evolution preserves Omega. There ||h_K(q)||<=2lambda(1+eta),
and globally ||h_K||<=sqrt(6). Consequently bounded Duhamel gives

    ||exp[-i tau H_D(lambda e_1)/lambda]u_lambda
                    -exp[-i tau H0(lambda e_1)/lambda]u_lambda||
      <=|tau|[sqrt(6)/lambda+2(1+eta)]sqrt(mu(Omega_lambda))
      =O(sqrt(lambda)).                                  (D28)

This comparison uses the zero extension on c only for the calculation;
the actual excluded evolution and initial vector remain physical.

Third, rescale q=lambda p. Uniformly on the two fixed p balls the free
divided symbol tends to

    M(p)=[ 0    2p^T ],
          [ 2p   i e_1 cross ].                           (D29)

At p=p0 its invariant (T_2,T_3,c) block is the actual matrix

    M0=[ 0  -i  0 ],
        [ i   0  2 ],
        [ 0   2  0 ].

It satisfies M0^3=5M0. At tau*=pi/sqrt(5),

    exp(-i tau* M0)T_2=(3/5)T_2-(4i/5)c,
    ||exp(-i tau* M0)T_2-T_2||=2/sqrt(5).                 (D30)

The negative ball gives the same norm. Its odd triplet initial field
produces the appropriate even singlet component. On each p ball,
||M(p)-M(+/-p0)||<=2eta. The normalized transverse initial direction
differs from +/-e_2 by at most 4eta in the lambda->0 limit. Thus the
initial/final direction changes cost at most 8eta, and the matrix
evolution comparison costs at most 2|tau*|eta. Combine this with D27
and D28 to obtain

    liminf_(lambda->0)
      ||exp[-i tau* H_D(lambda e_1)/lambda]u_lambda
                           -exp(-i tau* A_(e_1))u_lambda||
      >=2/sqrt(5)-(8+4tau*)eta >1/sqrt(5).                 (D31)

For the last strict inequality it is enough to use tau*<2,
2/sqrt(5)>4/5 and eta=1/100: 4/5-16/100>1/2>1/sqrt(5).
This proves a failure of operator-norm convergence on the zero-space
unit ball at one fixed rescaled time. It does not conflict with strong
convergence for each fixed vector. It neither disproves a uniform
current estimate nor treats free positive-band preparation. In
particular an O(1) state difference is not an O(1) current difference.

## 9. Controls, failed routes, and the remaining interface

The literal deterministic helper and complete logs are in
`excluded_walk_degenerate/`. Exact algebra is separated from floating
finite-dimensional evolution and unvalidated torus quadrature. The
helper reconstructs the spin derivative from Pauli matrices, the
transverse projection, the entire physical zero projection, both
off-diagonal effective couplings, and the actual canonical current
blocks. A six-antipodal-pair rational fixture has a 24-dimensional
reduced spin space, a 13-dimensional physical zero space,
I0=91675/154512, and gamma^2=60246/91675. These are fixture values,
not torus integral evaluations.

The cutoff-corrector residual is tested with a genuine nontrivial
spectral cutoff. Matrix exponentials check D5, D11, D14 and the cyclic
current response. The cone control computes M0 and its exponential;
the values in D30 are consequences of its matrix, not assigned constants.
Torus midpoint grids only illustrate the integrals and carry no rigorous
quadrature error certificate. Their changing I0 values must not be used
as exact continuum constants. The continuum claims rest on Sections
2-8, not on replay of a prior source runner or a numerical grid limit.

The receipt binds the final helper, all actual source-copy mutations,
baseline and full failure logs, source identities, runtime, timeout and
inputs. The 264-line helper completed 61 checks. Eight actual source-copy
mutants changed the derivative sign, transverse projection, full zero
space, dressing coupling, placement correction, cutoff-corrector sign,
actual current derivative sign, and cone streaming factor. Each process
exited 1 at its intended assertion, and every complete failure log was
read. The runtime was Python 3.13.5, NumPy 2.4.4, SciPy 1.17.1 and
SymPy 1.14.0, with a 120-second limit per process. These are author
controls, not an independent review or an audit verdict. The original
long-time probe and its entire evidence packet remain frozen.

The failed routes and limits are precise:

1. The zero mode is not isolated. An isolated-eigenvalue perturbation
   theorem does not justify its continuation. D8 concerns the full
   degenerate space and follows instead from D9-D11.
2. A formal inverse on the whole nonzero spectrum is unbounded. The
   cutoff inverse is used with its explicit norm and low-spectral-mass
   remainder; neither can be discarded before taking limits in order.
3. The effective dressing-to-transverse source cannot be omitted.
   Keeping only the transverse pointwise block or only the vector zeta
   misses D20-D24.
4. The free-current contribution alone gives a false initial dressing
   coefficient. The actual finite-rank placement correction preserves
   D16 and contributes the cross term in D15.
5. The longitudinal trace identity from the frozen probe is not an
   identity on the full degenerate space. D19 gives the correct scope.
6. Strong convergence does not allow an arbitrary lambda-dependent
   initial packet or an operator-norm upgrade; D31 is an explicit
   counterexample to that upgrade. Nor does the current response of
   zeta imply a response of arbitrary projected positive-band packets.

The next obligation is to control the actual lambda-dependent states
produced by free-band preparation at K=O(lambda), including their
near-threshold dispersive component, its interaction with the zero
space, and cross terms of the canonical current. Even a small zeta
overlap does not permit summing independent current contributions
without controlling those cross terms. A suitable vector-dependent
bound in D11, or a separate rescaled cone dynamics with matching to the
global dressing tail, could address that interface. No such matching,
universal relaxation law, scattering completeness, or eventual-time
current estimate is claimed here.
