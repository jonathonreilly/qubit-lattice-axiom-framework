"""Independent byte/provenance check; no mathematical verdict."""
from pathlib import Path
import hashlib,json,subprocess,difflib,datetime
R=Path(__file__).resolve().parent;S=R.parent;A=S/'boost_hstar_quantitative_corrector';W=S.parent/'boost_worktree'
def digest(data):return hashlib.sha256(data).hexdigest()
rows=[]
def bound(path,expected,label=None,byte_count=None,line_count=None):
 data=Path(path).read_bytes();actual=digest(data)
 assert actual==expected,(str(path),actual,expected)
 if byte_count is not None:assert len(data)==byte_count,str(path)
 if line_count is not None:assert len(data.splitlines())==line_count,str(path)
 rows.append({'path':str(path),'sha256':actual,'label':label,'bytes':len(data),'lines':len(data.splitlines())});return data
bound(A/'receipt.json','c447314e4a130e2fc2e047da6ddbe2abdf20209c5aa4718c2bab9b75783b5356')
receipt=json.loads((A/'receipt.json').read_text())
paths=set()
for item in receipt['files']:
 assert item['path'] not in paths;paths.add(item['path'])
 bound(A/item['path'],item['sha256'],'author binding',item['bytes'],item['lines'])
actual={'../BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md'}|{p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file() and p.relative_to(A).as_posix() not in receipt['excluded_post_freeze_outputs'] and '__pycache__' not in p.parts}
assert actual==paths,(actual-paths,paths-actual)
print('author bound inventory exact:',len(paths))
for p in sorted((R/'author_packet').rglob('*')):
 if p.is_file():assert p.read_bytes()==(A/p.relative_to(R/'author_packet')).read_bytes()
print('complete copied author packet matches original')
for item in json.loads((A/'source_manifest.json').read_text()):
 original=bound(item['source'],item['sha256'],'author original source',item['bytes'],item['lines'])
 assert original==(A/item['copy']).read_bytes()
print('all 11 author original/copy pairs match')
for item in json.loads((R/'source_manifest.json').read_text()):
 data=bound(item['copy'],item['sha256'],'review source copy',line_count=item['lines'])
 if 'ref' in item:
  original=subprocess.check_output(['git','show',item['ref']+':'+item['source']],cwd=W)
 else:original=Path(item['source']).read_bytes()
 assert data==original,item
print('all review mathematical sources and exact-ref instruction copies unchanged')
for item in json.loads((A/'instruction_manifest.json').read_text())['items']:
 blob=subprocess.check_output(['git','show',item['ref']+':'+item['path']],cwd=W)
 assert digest(blob)==item['sha256'],item
print('all 14 author instruction records match supplied exact local refs')
mutants=[];diffs=[]
for manifest,baseline in [('mutation_manifest.json','corrector_controls.py'),('polynomial_mutation_manifest.json','polynomial_controls.py')]:
 base=(A/baseline).read_text()
 for item in json.loads((A/manifest).read_text()):
  name=item['paths']['source'];changed=(A/name).read_text()
  assert base.count(item['before'])==1 and changed==base.replace(item['before'],item['after'],1)
  assert digest(base.encode())==item['baseline_sha256'] and digest(changed.encode())==item['mutant_sha256']
  assert item==json.loads((A/item['paths']['execution']).read_text())
  assert item['timeout_seconds']==120 and item['exit_code']==1 and 0<item['elapsed_seconds']<120
  stderr=(A/item['paths']['stderr']).read_text();stdout=(A/item['paths']['stdout']).read_text()
  assert stderr.rstrip().endswith('AssertionError: '+item['expected_assertion'])
  assert 'Traceback (most recent call last)' in stderr
  assert item['command'][1]==str(A/name)
  mutants.append({'name':item['name'],'assertion':item['expected_assertion'],'timeout':120,'exit_code':1})
  diffs.extend(difflib.unified_diff(base.splitlines(True),changed.splitlines(True),fromfile=baseline,tofile=name))
(R/'author_literal_mutations.diff').write_text(''.join(diffs))
print('eleven literal mutants and complete recorded failures match')
for script,stem,count in [('corrector_controls.py','baseline',27),('polynomial_controls.py','polynomial_baseline',16),('mean_controls.py','mean_baseline',8)]:
 meta=json.loads((A/(stem+'.execution.json')).read_text());out=(A/(stem+'.stdout.log')).read_text()
 assert meta['source_sha256']==digest((A/script).read_bytes()) and meta['exit_code']==0 and meta['timeout_seconds']==120
 assert not meta.get('timed_out',False) and 0<meta['elapsed_seconds']<120
 assert (A/(stem+'.stderr.log')).read_bytes()==b'' and meta['command'][1]==str(A/script)
 summary=json.loads(out[out.index('{'):]);assert summary['controls_completed']==count
print('three author baseline source/execution/log records consistent')
for stem,script in [('receipt_freeze','freeze_receipt.py'),('receipt_verification','verify_receipt.py')]:
 meta=json.loads((A/(stem+'.execution.json')).read_text())
 assert meta['receipt_sha256']==digest((A/'receipt.json').read_bytes())
 assert meta['script_sha256']==digest((A/script).read_bytes())
 assert meta['stdout_sha256']==digest((A/(stem+'.stdout.log')).read_bytes())
 assert meta['stderr_sha256']==digest((A/(stem+'.stderr.log')).read_bytes())
 assert meta['exit_code']==0 and meta['timeout_seconds']==120
print('post-freeze receipt and output bindings match')
up=json.loads((A/'upstream_K_review_identity.json').read_text())
bound(S/'boost_forcing_review/receipt.json',up['review_receipt_sha256'],'prior K review receipt')
for item in up['artifact_bindings']:bound(S/item['path'],item['sha256'],'prior K review artifact',item['bytes'])
print('all fourteen prior K review artifact bindings match; no new scientific certification by hashes')
for item in json.loads((R/'PRE_AUTHOR_CONTROL_FREEZE.json').read_text())['files']:bound(item['path'],item['sha256'],'pre-author reviewer freeze')
print('complete pre-author reconstruction/control/failure snapshots unchanged')
saved=json.loads((A/'EXPONENTIAL_BOUND_SNAPSHOT.json').read_text());bound(A/saved['path'],saved['sha256'],'preserved historical exponential proof',saved['bytes'],saved['lines'])
(R/'IDENTITY_VERIFICATION.json').write_text(json.dumps({'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'byte identity and reported execution consistency; no scientific certification','author_bindings':len(paths),'mutants':mutants,'records':rows},indent=2)+'\n')
print('identity and provenance verification complete')
