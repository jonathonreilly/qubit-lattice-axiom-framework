from pathlib import Path
import hashlib,json,datetime,subprocess
R=Path(__file__).resolve().parent;S=R.parent;A=S/'boost_hstar_quantitative_corrector';W=S.parent/'boost_worktree'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
q=S/'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md';report=S/'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_REVIEW.md'
assert sha(q)=='4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820'
assert sha(A/'receipt.json')=='c447314e4a130e2fc2e047da6ddbe2abdf20209c5aa4718c2bab9b75783b5356'
for row in json.loads((R/'source_manifest.json').read_text()):
 assert sha(row['copy'])==row['sha256']
 if 'ref' in row:
  data=subprocess.check_output(['git','show',row['ref']+':'+row['source']],cwd=W)
  assert hashlib.sha256(data).hexdigest()==row['sha256']
 else:assert sha(row['source'])==row['sha256']
for row in json.loads((R/'PRE_AUTHOR_CONTROL_FREEZE.json').read_text())['files']:assert sha(row['path'])==row['sha256']
for row in json.loads((A/'receipt.json').read_text())['files']:assert sha(A/row['path'])==row['sha256']
for p in (R/'author_packet').rglob('*'):
 if p.is_file():assert p.read_bytes()==(A/p.relative_to(R/'author_packet')).read_bytes()
for name,stem in [('corrector_controls','baseline'),('polynomial_controls','polynomial_baseline'),('mean_controls','mean_baseline')]:
 assert (R/('replay_'+name+'.stdout.log')).read_bytes()==(A/(stem+'.stdout.log')).read_bytes()
 assert (R/('replay_'+name+'.stderr.log')).read_bytes()==b''
final={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target_sha256':sha(q),'author_receipt_sha256':sha(A/'receipt.json'),'report_sha256':sha(report),'reconstruction_sha256':sha(R/'PROOF_RECONSTRUCTION_PRE_AUTHOR.md'),'sources_unchanged':True,'author_packet_unchanged':True,'pre_author_freeze_unchanged':True,'replay_outputs_identical':True,'scope':'identity only; analytic disposition is in report'}
(R/'final_identity_check.json').write_text(json.dumps(final,indent=2)+'\n')
files=[]
for p in [report]+sorted(p for p in R.rglob('*') if p.is_file() and p.name!='receipt.json' and '__pycache__' not in p.parts):
 data=p.read_bytes();files.append({'path':str(p.relative_to(S)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'lines':len(data.splitlines())})
# Explicitly include copied upstream/author receipts; only the new top-level
# review receipt is excluded from self-binding.
for p in sorted(R.rglob('receipt.json')):
 if p!=R/'receipt.json':
  data=p.read_bytes();files.append({'path':str(p.relative_to(S)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'lines':len(data.splitlines())})
assert len({x['path'] for x in files})==len(files)
receipt={'schema':'independent-quantitative-corrector-review-v1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadline_utc':'2026-10-12T16:00:52+00:00','disposition':'PASS for Q1-Q34 conditional supplied-model theorem at exact frozen source; no required mathematical correction','audit_verdict_applied':False,'retained_status_granted':False,'formal_proof_verification_performed':False,'target':{'path':str(q),'sha256':sha(q),'lines':729},'author_receipt':{'path':str(A/'receipt.json'),'sha256':sha(A/'receipt.json')},'report':{'path':str(report),'sha256':sha(report)},'pre_author_reconstruction':{'path':str(R/'PROOF_RECONSTRUCTION_PRE_AUTHOR.md'),'sha256':sha(R/'PROOF_RECONSTRUCTION_PRE_AUTHOR.md'),'frozen_at':'2026-10-12T00:34:22.738523+00:00'},'pre_author_control_freeze':{'path':str(R/'PRE_AUTHOR_CONTROL_FREEZE.json'),'sha256':sha(R/'PRE_AUTHOR_CONTROL_FREEZE.json'),'frozen_at':'2026-10-12T00:38:56.045865+00:00'},'independence':'fresh analytic reconstruction and separate finite Pauli/ODE implementation before Q author evidence; target formulas and control descriptions, prior X/K reviews, and root proposals visible; not blinded discovery','model_effort':'inherited user-selected settings; no override or subdelegation','source_reading_coverage':'complete explicit map in frozen reconstruction; hashes alone confer no reading coverage','unresolved_mathematical_obligations_within_scope':[],'limitations':['exact supplied model and B25-B30 preparation only','open exponent windows, no optimality','no Hstar gap or full inverse','no q derivative of zeta','Q28 is comparison-correction norm, not total-state probability','no physical covariance or full boost closure','finite controls and reproduction do not certify continuum theorem','two reviewer absolute defect-size thresholds refined; complete failed attempts preserved'],'instructions':{'main':'a13caa4885f547c8d206265b031ba7649e539fd9','planning':'3a4b2c66a1ead7a1c48b4359627e968f681e3c39','source_worktree_head_supplied':'773321aa8fdfccc05248682dfc96bf94215034a2','no_remote_freshness_claim':True},'changed_editable_prompts':[],'git_mutations':[],'scientific_sources_changed':[],'author_evidence_changed':[],'files':files}
assert not (R/'receipt.json').exists()
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'report':str(report),'report_sha256':sha(report),'receipt':str(R/'receipt.json'),'receipt_sha256':sha(R/'receipt.json'),'reconstruction_sha256':sha(R/'PROOF_RECONSTRUCTION_PRE_AUTHOR.md'),'artifact_bindings':len(files),'target_unchanged':True},indent=2))
