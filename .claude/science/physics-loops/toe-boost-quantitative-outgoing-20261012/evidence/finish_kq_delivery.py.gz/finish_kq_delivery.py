"""Verify, preserve and stage the exact reviewed K/Q publication."""
from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys

S = Path(__file__).resolve().parent
W = S.parent/'quantitative_boost_worktree'
P = W/'.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012'
BASE = '773321aa8fdfccc05248682dfc96bf94215034a2'
os.chdir(W)
sys.path.insert(0, str(W/'scripts'))
import runner_cache
sha = lambda b: hashlib.sha256(b).hexdigest()
notes = json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']
primaries = json.loads((P/'PRIMARY_COMPOSITION.json').read_text())['outputs']
mutants = json.loads((S/'kq_primary_mutations/manifest.json').read_text())['runs']
assert len(mutants) == 16
for r in mutants:
    body = (W/r['primary_path']).read_text()
    assert sha(body.encode()) == r['primary_sha256']
    d = S/'kq_primary_mutations'
    variant = (d/(r['name']+'.py')).read_text()
    assert body.count(r['before']) == 1 and variant == body.replace(r['before'], r['after'])
    assert sha(variant.encode()) == r['source_sha256']
    out, err = (d/(r['name']+'.stdout')).read_bytes(), (d/(r['name']+'.stderr')).read_bytes()
    assert sha(out) == r['stdout_sha256'] and sha(err) == r['stderr_sha256']
    assert r['exit_code'] == 1 and not r['timed_out'] and r['intended_failure'] and r['stdout_baseline_prefix']
    assert f"AssertionError: {r['expected_assertion']}" in err.decode()
    assert r['elapsed_seconds'] < r['timeout_seconds'] == 120

comparisons = []
executions = {}
for label, names in [('K', ['boost_kernel_effective_dynamics/baseline_attempt2.stdout.log']),
    ('Q', ['boost_hstar_quantitative_corrector/baseline.stdout.log',
           'boost_hstar_quantitative_corrector/polynomial_baseline.stdout.log',
           'boost_hstar_quantitative_corrector/mean_baseline.stdout.log'])]:
    e = json.loads((S/f'kq_{label}_canonical_execution.json').read_text())
    executions[label] = e
    assert e['status'] == 'ok' and e['exit_code'] == 0 and e['stderr'] == '' and e['timeout_sec'] == 120
    old = ''.join((S/name).read_text() for name in names).splitlines()
    new = e['stdout'].splitlines()
    changes = [dict(line=i+1, old=a, new=b) for i, (a,b) in enumerate(zip(old, new[:len(old)])) if a != b]
    assert len(new) == len(old)+7
    if label == 'Q':
        assert changes == []
    else:
        assert len(changes) == 1 and all(changes[0][k].startswith('elapsed_seconds=') for k in ['old', 'new'])
    comparisons.append(dict(label=label, original_scientific_output_identical=True,
        original_stdout_lines=len(old), changed_runtime_lines=changes, appended_lines=new[len(old):]))
(S/'KQ_canonical_output_comparison.json').write_text(json.dumps(dict(checks=comparisons,
    earlier_strict_prefix_failure='The K runner prints wall time; the first strict byte-prefix assertion rejected only that expected runtime change. Scientific output remains identical. The original comparison and first caches are preserved.'),indent=2)+'\n')

graph = W/'docs/audit/data/citation_graph_manifest.json'
old = json.loads(subprocess.check_output(['git', 'show', BASE+':'+str(graph.relative_to(W))]))
new = json.loads(graph.read_text())
assert (new['node_count'], new['edge_count']) == (old['node_count']+2, old['edge_count']+3)
assert all(new['nodes'].get(k) == v for k,v in old['nodes'].items())
assert {k:v['out_degree'] for k,v in new['nodes'].items() if k not in old['nodes']} == {
    'boost_forced_outgoing_bounded_theorem_note_2026-10-12':1,
    'boost_quantitative_corrector_bounded_theorem_note_2026-10-12':2}
compat = json.loads((S/'kq_focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []

(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Root composition check

Root read the complete441-line K and729-line Q sources, their necessary prior
arguments, every new control helper and complete scientific output. Root then
read the complete K/Q independent reports and pre-author reconstructions,
their independent control sources and full relevant outputs/failure records.
The Q reconstruction contains416lines. Its194-line control uses a separate
finite Pauli/augmented-ODE construction; it is not the original helper.

Every source edit in publication is explicit. The analytic equations and
arguments are unchanged. Metadata, portable source boundaries, actual review
history and recovery information are added. The K downstream reference to Q
is deliberately plain code because K does not mathematically depend on Q.
The current graph adds K-to-parent and Q-to-parent/K, with all old nodes intact.

The complete original K primary is preserved. Each Q helper is inserted as
one complete named-function body, without changing its calculations. Both
complete-primary reconstructions and all old scientific output match. Sixteen
actual whole-primary variants contain exactly one declared defect and exit at
their intended assertions. Root read all complete tracebacks and verified all
preceding output against the fully read original baseline. Counts and identity
checks do not replace the analytic proof.

The physical mean constraint, eight-cone bounds, full transverse derivative,
noncommuting identity, both endpoints, complete generator/source derivative,
both global normalizers, and all-nine expectation decomposition are retained.
K's continuum measure proof remains an explicit provisional cross-PR import.
The norm/expectation distinction and every earlier adverse witness survive.
Root is a coauthor, not the independent source reviewer. No retained status,
Lean certificate, physical-axiom or editable-prompt change is claimed.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped publication verification

Final canonical K execution exited0 in{executions['K']['elapsed_sec']:.9f}s;
Q exited0 in{executions['Q']['elapsed_sec']:.9f}s. Each used its declared120s
timeout and has empty stderr. K's38 original scientific records and Q's51
records are unchanged; only K's printed elapsed runtime differs. Both add
explicit resolution and scope lines. All note dependencies are declared inputs,
and source/cache identities are fresh. Full runtime versions remain in outputs
and cache headers. Both primaries reject optimized assertions.

Sixteen actual complete-primary defects fail at the intended checks: five K
Schur/source/resolvent/phase/spectral-weight edits, eight Q corrector/endpoint/
source/full-error edits, and three Q transverse-derivative omissions. Full
sources, commands, timeouts, stdout and stderr are preserved. Mean controls
are product-rule majorants and a generic Hermitian fixture, not a simulation
of the exact continuum bracket. Finite controls do not establish the analytic
cone estimates, continuum absolute continuity, time windows or physical axioms.

The first graph build included a spurious reverse edge from K's downstream
Markdown link to Q. Replacing that link by a plain-code reference changed no
proof. The first notes/maps/graph/executions are preserved in kq_pre_graph_repair.
Both caches were refreshed because Q declares K as an input. Final topology is
{new['node_count']}nodes and{new['edge_count']}edges: two added nodes and three
intended edges, every prior node unchanged. No old science was edited.

Focused changed-audit-evidence compatibility selected no applied rows and
reported no failures. Global combined audit pipeline and strict audit lint
were not run; they remain separate landing gates. No audit verdict was applied.
Exact reconstruction, Python syntax, ordinary local links, source/evidence
identities, fresh caches, vocabulary fix/report, whitespace and the exact
intended staged set are verified before commit. Only the permitted citation
manifest is included from audit data. No empirical fit or confidence interval
is applicable. No Lean verification is claimed for this milestone.
''')
history = P/'REVIEW_HISTORY.md'
history.write_text(history.read_text().split('\n## Publication conformance\n',1)[0]+'''
## Publication conformance

1. Self-containment: both complete arguments, prior source proofs, supplied
   hypotheses and exact recovery maps are included.
2. Execution: canonical declared-timeout runs completed at fresh identities;
   previous runtime/graph evidence remains recoverable.
3. Scope: bounded_theorem and conditional-support are separate; actual
   preparation, provisional imports and omitted conclusions are explicit.
4. Negative claims: only preserved counterexamples and rejected shortcuts;
   no new global no-go or retained negative verdict is proposed.
5. Proof obligations: every claimed K/Q step received a complete separate
   source reconstruction; physical selection/covariance/optimality stay open.
6. Controls: independent implementations, author controls, reproduction and
   source identity are distinguished. Actual primary defects are scoped.
7. Packet: goal, imports, approaches, status, trace, review and recovery are
   present; this snapshot does not compete with the single live checkpoint.
8. References: portable links and exact cross-PR imports are explicit. The
   graph acknowledges the intended two nodes and three dependency edges.
9. Notes: complete definitions, proof equations and limitations are preserved;
   every publication edit and primary composition reconstructs exactly.
10. Authority: no merge, main push, audit status, axiom or prompt change.
11. Counts: literal identities and complete outputs support the stated scope;
    no numeric fit is promoted to analytic evidence.
12. Gates: selective review and scoped delivery checks complete; global
    combined audit pipeline and strict audit lint remain unrun landing gates.
''')
editable = sorted(P.glob('*.md'))+[W/r['publication_path'] for r in notes+primaries]+[P/'reconstruct.py']
for mode in ['fix', 'report-only']:
    target = S/('kq_final_vocab_'+mode)
    r = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--'+mode, '--report-path',str(target.with_suffix('.json'))]+
                       [str(p.relative_to(W)) for p in editable], capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout+r.stderr)
    assert r.returncode == 0
r = subprocess.run([sys.executable, str(P/'reconstruct.py')], capture_output=True)
(S/'kq_final_reconstruction.log').write_bytes(r.stdout+r.stderr)
assert r.returncode == 0
for r in primaries:
    ast.parse((W/r['publication_path']).read_text())
    assert runner_cache.cache_status(r['publication_path']) == runner_cache.cache_identity_status(r['publication_path']) == 'fresh'
links = []
for p in editable:
    if p.suffix != '.md':
        continue
    prose, fenced = [], False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'):
            fenced = not fenced
            continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for target in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(), (p,target)
        links.append(dict(source=str(p.relative_to(W)), target=target))

emap = json.loads((P/'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']:r for r in emap['files']}
def preserve(src):
    b = src.read_bytes()
    dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True,exist_ok=True)
    packed = gzip.compress(b,mtime=0)
    if dst.exists() and dst.read_bytes() != packed:
        prior = rows.pop(str(dst.relative_to(P)))
        history = dst.with_name(dst.stem+'.previous_'+prior['sha256'][:12]+dst.suffix)
        assert not history.exists() or history.read_bytes() == dst.read_bytes()
        if history.exists():
            dst.unlink()
        else:
            dst.rename(history)
        prior['preserved'] = str(history.relative_to(P));prior['historical_source_version'] = True
        rows[prior['preserved']] = prior
    dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = dict(original=str(src),preserved=rel,bytes=len(b),sha256=sha(b))
for folder in ['kq_primary_mutations','kq_pre_graph_repair']:
    for src in sorted((S/folder).rglob('*')):
        if src.is_file():
            preserve(src)
for name in ['prepare_kq_primaries.py','prepare_kq_notes.py','prepare_kq_packet.py','run_kq_primary_mutants.py','finish_kq_delivery.py',
             'kq_K_canonical_execution.json','kq_Q_canonical_execution.json','KQ_canonical_output_comparison.json',
             'kq_initial_vocab_fix.json','kq_final_vocab_fix.json','kq_final_vocab_fix.log',
             'kq_final_vocab_report-only.json','kq_final_vocab_report-only.log','kq_final_reconstruction.log',
             'kq_citation_execution.json','kq_citation_build.stdout','kq_citation_build.stderr','kq_citation_manifest.stdout','kq_citation_manifest.stderr',
             'kq_focused_audit_compat.json','kq_focused_audit_compat.stderr','kq_focused_audit_compat.execution.json']:
    preserve(S/name)
for r in rows.values():
    b = gzip.decompress((P/r['preserved']).read_bytes())
    assert sha(b) == r['sha256'] and len(b) == r['bytes']
mechanical = dict(full_note_and_primary_reconstruction=True, actual_whole_primary_mutants=16,
    preserved_evidence_files=len(rows), cache_and_inputs_fresh=True, ordinary_links=links,
    citation_delta=dict(nodes=2,edges=3), every_old_graph_node_unchanged=True,
    scope='Mechanical verification plus separately identified complete source reviews; not an audit verdict')
out = S/'kq_delivery_mechanical.json';out.write_text(json.dumps(mechanical,indent=2)+'\n');preserve(out)
emap['files'] = [rows[k] for k in sorted(rows)]
(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files = [W/r['publication_path'] for r in notes+primaries]+[graph]+[
    runner_cache.cache_path_for(r['publication_path']) for r in primaries]+[
    p for p in P.rglob('*') if p.is_file() and p != P/'SOURCE_IDENTITIES.json']
ident = []
for path in sorted(set(files)):
    r = dict(path=str(path.relative_to(W)),sha256=sha(path.read_bytes()))
    if path.suffix == '.gz':
        r['decompressed_sha256'] = sha(gzip.decompress(path.read_bytes()))
    ident.append(r)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,
    scope='Exact intended publication files except this manifest itself.',files=ident),indent=2)+'\n')
paths = [r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
for r in ident:
    assert sha(subprocess.check_output(['git','show',':'+r['path']])) == r['sha256']
staged = set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}
assert staged == set(paths)
assert not subprocess.check_output(['git','diff','--name-only'])
result = dict(staged_files=len(paths),staged_hashes_match=True,whitespace_clean=True,**mechanical)
(S/'kq_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
