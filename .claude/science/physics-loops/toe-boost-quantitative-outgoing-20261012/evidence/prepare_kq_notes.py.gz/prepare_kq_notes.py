"""Map the complete frozen K/Q arguments into portable provisional notes."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent/'quantitative_boost_worktree'
P = W/'.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012'
sha = lambda b: hashlib.sha256(b).hexdigest()
outputs = []
common = '''---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: upstream_support
reachability_to_target: supports
audit_required_before_effective_retained: true
bare_retained_allowed: false
---'''
boost_id = 'excluded_walk_boost_bracket_control_bounded_theorem_note_2026-10-11'
packet_link = '[complete milestone packet](../.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012/)'

for label, filename, expected, target, claim, scope, upstream, primary in [
    ('K', 'BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md',
     '1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9',
     'docs/BOOST_FORCED_OUTGOING_BOUNDED_THEOREM_NOTE_2026-10-12.md',
     'boost_forced_outgoing_bounded_theorem_note_2026-10-12',
     'For the exact supplied excluded-walk preparation, the effective forced correction has an explicit resolvent-dressed outgoing vector and rapidly decreasing H1 transient. The prior continuum spectral measure gives positive ordered correction and transverse-norm limits; no actual-walk lambda rate is proved by this note alone.',
     [boost_id], 'scripts/boost_forced_outgoing_2026_10_12.py'),
    ('Q', 'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md',
     '4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820',
     'docs/BOOST_QUANTITATIVE_CORRECTOR_BOUNDED_THEOREM_NOTE_2026-10-12.md',
     'boost_quantitative_corrector_bounded_theorem_note_2026-10-12',
     'For the exact supplied globally normalized preparation, a physical approximate range corrector yields explicit L2 and H1 errors on growing effective-time windows. Combined with the conditional outgoing theorem, correction norms converge simultaneously for eta below 1/4; all nine normalized current residual means vanish for eta below 1/6. No exponent optimality, total-state occupation or physical covariance is asserted.',
     [boost_id, 'boost_forced_outgoing_bounded_theorem_note_2026-10-12'],
     'scripts/boost_quantitative_corrector_2026_10_12.py')]:
    source = S/filename
    raw = source.read_text()
    assert sha(raw.encode()) == expected
    edits = []

    def edit(before, after, reason):
        global raw
        assert raw.count(before) == 1, (label, before, raw.count(before))
        raw = raw.replace(before, after)
        edits.append(dict(before=before, after=after, reason=reason))

    meta = ('---\nclaim_id: '+claim+'\nclaim_type: bounded_theorem\nclaim_scope: '+json.dumps(scope)
            +'\nupstream_dependencies:\n'+''.join('  - '+x+'\n' for x in upstream)
            +'runner: '+primary+'\n'+common.split('\n', 1)[1])
    edit(common, meta, 'Register the exact conditional theorem, scoped primary and in-branch dependencies.')
    if label == 'K':
        edit('2026-10-11. External author derivation by `boost_kernel_dynamics`.\nIndependent review of this new composition is pending. No source, premise,\nrepository state, or audit status is changed.',
             'Author derivation dated 2026-10-11 by `boost_kernel_dynamics`; publication 2026-10-12.\nStatus: conditional-support. A separate complete source reconstruction found\nno required correction. This is provisional mathematics, without an applied\naudit verdict or retained status.',
             'Record the completed selective K review and distinguish publication from author history.')
        edit("Let S be this note's directory. All of the following mathematical source\narguments were read completely and their identities checked:",
             'S denotes the original research source collection, preserved losslessly in the\n'+packet_link+'. EVIDENCE_MAP.json maps every source below to its preserved\nbytes. All of these mathematical source arguments were read completely and\ntheir identities checked. The in-branch [boost theorem](EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md)\ncontains B, E and X; the memory proof from PR9481 remains an explicit\nprovisional cross-PR dependency, preserved completely in this packet:',
             'Make original source locations portable and disclose the non-ancestor memory dependency.')
        edit('There is no Lean certification in this author packet. A focused independent\ncheck should inspect K8\'s sign and normalization, K7\'s actual source support,\nthe uniform H1 integration-by-parts argument, the prior-measure reuse, and\nthe order of limits in K18.',
             'No Lean certification is claimed. The separate review checked K8\'s sign and\nnormalization, K7\'s actual source support, the uniform H1 integration-by-parts\nargument, the prior-measure reuse, and the order of limits in K18. The full\nreview and its reconstruction frozen before author controls are preserved.\nTheir identities and the distinct independent finite ODE calculation appear\nin REVIEW_HISTORY.md. Root is a contributor, not that independent reviewer.\nThe [quantitative extension](BOOST_QUANTITATIVE_CORRECTOR_BOUNDED_THEOREM_NOTE_2026-10-12.md)\nproves its own rates and simultaneous limits; those are separate from K alone.',
             'Record the completed K review and link the separate rate theorem without retroactive scope inflation.')
        edit('Only this note and `boost_kernel_effective_dynamics/` were written. No\neditable prompt files changed. No repository edit, commit, PR, merge,\naudit action, physical-axiom change, other-chat message, subdelegation,\nmodel override, or campaign-deadline extension was performed by this worker.',
             'The frozen author source and every publication edit are recoverable from\nPUBLICATION_EDITS.json. The [finite control](../scripts/boost_forced_outgoing_2026_10_12.py)\nchecks the stated finite algebra; the continuum theorem rests on the full\nproof and its checked dependencies. Publication execution is recorded in\nDELIVERY_CHECKS.md. No editable prompt, physical axiom, retained status or\napplied audit verdict is changed.',
             'Replace worker-local history with publication recovery and exact evidence scope.')
    else:
        edit('2026-10-11–12. Bounded author derivation by `boost_kernel_dynamics`, with root\nas coauthor of the proposed mechanism. This is a separate extension of the\nfrozen X and K sources. Independent review is pending. No frozen source,\nphysical premise, Git file, publication or audit status is changed.',
             'Derivation dated 2026-10-11–12 by `boost_kernel_dynamics`, with root as\ncoauthor of the proposed mechanism. Status: conditional-support. This is a\nseparate extension of the frozen X and K sources. Selective review and its\nexact evidence roles are recorded in the milestone packet; no audit verdict\nor retained status is applied.',
             'Separate the provisional publication and review record from frozen author history.')
        edit("Let S denote this note's directory. The exact source identities are:",
             'S denotes the original research source collection, preserved losslessly in the\n'+packet_link+'. EVIDENCE_MAP.json maps the exact source identities below\nto their preserved bytes. The [boost theorem](EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md)\nis the in-branch B/E/X dependency; [K](BOOST_FORCED_OUTGOING_BOUNDED_THEOREM_NOTE_2026-10-12.md)\nis published alongside this note and discloses its provisional memory import:',
             'Make the source boundary and cross-PR dependency portable and explicit.')
        edit('The appropriate independent check should inspect the global Q4 constraint,\ncone multiplicity, corrected range identity, weighted derivative estimates,\nall source approximations, both endpoints and noncommuting term in Q21,\nthe constants and limit order in Q25–Q28, and the all-index coefficient\nbounds and complete expectation decomposition in Q29–Q34. There is no\nLean certificate or audit verdict in this author packet. Only this note and its named\nevidence directory were written. No editable prompt files changed.',
             'The selective source check addresses the global Q4 constraint, cone multiplicity,\ncorrected range identity, weighted derivative estimates, all source approximations,\nboth endpoints and the noncommuting term in Q21, the constants and limit order\nin Q25–Q28, and the all-index coefficient bounds and complete expectation\ndecomposition in Q29–Q34. REVIEW_HISTORY.md records its final scope and verdict.\nThe [finite control](../scripts/boost_quantitative_corrector_2026_10_12.py)\ncontains all three complete original control sources in separate functions;\nPUBLICATION_EDITS.json and PRIMARY_COMPOSITION.json recover every byte.\nNo Lean certificate, physical-axiom change, editable-prompt change, retained\nstatus or applied audit verdict is claimed. Root is a coauthor, not the\nindependent reviewer. DELIVERY_CHECKS.md records publication verification.',
             'Link complete proof/review/recovery evidence and distinguish finite controls from the theorem.')
    # Record presentation-only repairs individually; preserve all argument text.
    lines = raw.splitlines(keepends=True)
    for old in list(dict.fromkeys(line for line in lines if line.rstrip('\r\n').endswith((' ', '\t')))):
        new = old.rstrip()+'\n'
        if raw.count(old) == 1:
            edit(old, new, 'Remove trailing presentation whitespace only.')
    if raw.endswith('\n\n'):
        old = raw[-160:]
        edit(old, old.rstrip()+'\n', 'Normalize end-of-file blank lines only.')
    assert not (W/target).exists()
    (W/target).write_text(raw)
    outputs.append(dict(kind='note', source_path=str(source), source_sha256=expected,
        preserved_source='evidence/'+filename+'.gz', edits=edits, appended_text='',
        publication_path=target, publication_sha256=sha(raw.encode())))
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=outputs), indent=2)+'\n')
print(json.dumps([dict(path=r['publication_path'], sha256=r['publication_sha256'], edits=len(r['edits'])) for r in outputs]))
