"""Preserve complete author/reviewer evidence and the coherent K/Q contract."""
from pathlib import Path
import gzip
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent/'quantitative_boost_worktree'
P = W/'.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha((S/'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_REVIEW.md').read_bytes()) == '6ccba5be389898bd97ce12e53bf767dd002a3e6f282afb3cb4e010f49d86ca2d'
assert sha((S/'boost_quantitative_review/receipt.json').read_bytes()) == 'c38f2a237e045a12870e380a7f9fc152c4a0e405238e8643050b4ec457e6dce2'
assert not (P/'STATE.yaml').exists()

texts = {
'STATE.yaml': '''loop: toe-boost-quantitative-outgoing-20261012
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-boost-quantitative-outgoing-20261012
base_revision: 773321aa8fdfccc05248682dfc96bf94215034a2
parent_pr: 9484
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: outgoing_forcing_and_quantitative_actual_correction
provisional_dependency: supplied_B25_B30_model_and_cross_PR9481_continuum_memory_measure
independent_check: separate_complete_K_and_Q_reconstructions_no_required_correction
strongest_unresolved_obligation: actual_covariance_or_general_preparations_do_not_follow
pr_status: ready_for_regular_milestone_after_delivery_checks
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
next_action: publish_regular_stacked_PR_then_continue_threshold_and_detector_derivations
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md': '''# Mathematical contract

For exactly the supplied excluded-walk model and globally normalized B25–B30
preparation, identify the effective forced solution reached by the actual
correction. Then quantify convergence to it in the original gapless dynamics,
including every first momentum derivative and all nine actual residual means.
Keep correction norms distinct from total-state occupations, and observable
means distinct from residual-vector norms or physical covariance.
''',
'ASSUMPTIONS_AND_IMPORTS.md': '''# Premises and exact dependencies

The Git parent is PR9484 at773321aa8fdfccc05248682dfc96bf94215034a2. Its
complete B/E/BR/T/X note supplies the sine-Pauli walk, antisymmetric pair,
single full-torus contact projection, continuous clock, fixed energy placement,
domains, full kernel, and exactly the globally normalized B25–B30 preparation.
These are supplied model data; the present work does not derive them from the
minimal physical axioms. No arbitrary-preparation theorem is claimed.

K explicitly uses a provisional cross-PR mathematical dependency: the complete
degenerate generator and continuum source-measure theorem published in PR9481
atd8480b5a6e04102ff076b3dd6f817a2d43f20252. This commit is not the Git parent.
The original D source b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876
and memory source b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c
are preserved completely, with their reviews, in evidence. EVIDENCE_MAP.json
resolves their exact original and recovery paths. Their conditional physical
premises are inherited; no review label substitutes for the actual proof.
Further PR9482 edge/occupation work is credited background, not a new premise.

Q depends on K's actual-source resolvent formula for its weighted estimates.
Only its transverse outgoing limit additionally needs the prior continuum
absolute continuity. The elementary approximate-range proof supplies the
lambda rate; K's forcing-frequency gap is not a gap of H_*. No inverse on the
full complement or q derivative of the singular kernel vector is used.
''',
'APPROACH_REGISTRY.md': '''# Completed approaches and remaining routes

1. The actual annular positive-frequency forcing is separated from the whole
   effective spectrum. Its resolvent gives a freely evolving dressed vector
   plus a rapidly decreasing transient. Positive spectral reweighting and the
   prior continuum theorem yield the ordered outgoing correction limits.
2. The actual residual is a longitudinal triplet satisfying one global mean
   constraint. A cutoff mean-zero singlet is an approximate range vector.
   Eight-cone radial bounds quantify its norm and approximation error.
3. Pointwise forcing resolvents and the full transverse integral give
   polynomial weighted growth. A noncommuting integration identity, both
   endpoints and the full differentiated error yield explicit all-time bounds.
4. Uniform Hilbert control of the effective solution converts those bounds
   into simultaneous correction-norm limits. Symmetric-form cancellation and
   every free/cross/correction term give all-nine actual expectation bounds.

The full-inverse shortcut fails for the actual initial residual. The earlier
valid exponential estimate is preserved; the polynomial derivation improves
it without changing its evidence. The separate H_* threshold probe may test
sharpness of a free primitive, but has no accepted outcome in this milestone.
''',
'ROUTE_PORTFOLIO.md': '''# Evidence roles and independence

The complete K and Q notes are the analytic theorem artifacts. Each received
a separate source reconstruction before its reviewer opened new author
controls. Reviewers had the theorem formulas and necessary prior reviews;
these are source-shared checks, not blinded discovery. Root proposed the
mechanisms and is a contributor, not their independent reviewer.

K's primary retains all38 original finite controls. Q's primary embeds all
three complete original helpers in separate named functions, without importing
an external sidecar or executing an opaque string:27 corrector,16 polynomial,
8 mean controls. They are finite algebra/ODE/majorant controls. Analytic cone
bounds, continuum measures and growing-time limits rest on the full proofs.
Separate reviewer controls use independent finite implementations. Author
replays establish reproduction. None is formal Lean verification.
''',
'OPPORTUNITY_QUEUE.md': '''# Next research decisions

The immediate next boost route is the actual H_* spectral threshold measure
and the sharp free-primitive scaling. It requires a real boundary-value proof,
zero-atom removal and all eight cones. A free-primitive law would not by itself
give a lower bound for the actual noncommuting error or optimal time windows.

The broader physical bridge remains constructive scattering completeness.
Continue the separate compact detector convergence and no-undetected-state
work under matched microscopic hypotheses. Neither this supplied two-body
model nor its prepared expectation result supplies that many-body bridge.
''',
'NO_GO_LEDGER.md': '''# Preserved adverse findings

The actual initial longitudinal residual need not be in ran H_*: its formal
mean-zero singlet inverse has an epsilon^(-2) coefficient, which is not L2
at a three-dimensional cone. This rejects that shortcut, not approximate
range methods. The full complement remains gapless.

Earlier mixed-band and differential-bracket witnesses, the small-positive-time
diagonal residual norm obstruction, cone-localized nonuniformity on the unit
ball, and finite-bath recurrence remain unchanged. No universal no-go,
stretch-attempt-negative or retained negative claim is proposed here.
The sufficient window endpoints and optimality are not established.
''',
'LITERATURE_BRIDGES.md': '''# Existing mathematics and prior work

The effective multiplication block and scalar memory resolvent are prior
repository work, explicitly credited to PR9481. K's prior-art assessment
records the relation to Friedrichs-type finite-rank models; that historical
comparison is not a theorem premise. Its full scalar spectral argument is
available in the preserved original repository source.

The new K/Q arguments use bounded-operator ODE uniqueness, resolvents,
Hilbert-space projections, elementary cone integration, nonstationary phase,
unitarity and integration by parts with checked hypotheses. No new niche
external theorem is silently imported. The continuum absolute-continuity
step was read in its original complete repository proof by both source checks.
No novelty claim is made for the imported block or memory machinery.
''',
'ARTIFACT_PLAN.md': '''# Coherent stacked milestone

Open one regular PR on the frozen PR9484 branch containing two full notes,
two honest finite controls, canonical caches, explicit source maps and this
milestone snapshot. No draft, merge, main push or applied audit action.
The independent PR9481 mathematical import is explicit and completely
recoverable, despite having a different Git parent. The original boost
argument and all its counterexamples remain unchanged.
''',
'TRACE_GATE.md': '''# Connection to the supplied-model boost obligation

```yaml
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Quantify canonical boost brackets on actual excluded-pair states and establish their time-scale limits."
source_of_blocker_text: canonical_current_and_prepared_boost_derivations
source_location: "PR9484 at773321aa8fdfccc05248682dfc96bf94215034a2, Part V and its TRACE_GATE.md"
next_trace_action: "Test threshold sharpness separately and continue the microscopic scattering-completeness bridge."
```

The fixed-effective-time result now has explicit quantitative errors and
sufficient growing-time windows. The actual forcing has an outgoing
description and simultaneous correction limits. This partially closes the
prepared-state time-scale obligation; it does not select a Hamiltonian or
prove full Poincare covariance, arbitrary-state closure or a TOE.
''',
'CLAIM_STATUS_CERTIFICATE.md': '''# Conditional mathematical status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
conditional_surface_status: "Exact supplied excluded-walk model and B25–B30 preparation, with explicit provisional memory import."
hypothetical_axiom_status: null
admitted_observation_status: null
independent_review_status: "Complete separate K and Q reconstructions; no required mathematical correction."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

Original mathematical derivations are authorized. Selective independent checks
support provisional composition; formal retained status still belongs to the
independent audit path. No formal verification certificate is claimed here.
''',
'REVIEW_HISTORY.md': '''# Complete focused source reviews

K author1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9;
review64cf08ea2c12f086d0efcc862d17ce0e394f53dfbcbfa5d48db73a10bb9652ca;
receipt6ecec5f7e9831fde22922d2ff6f5b7db4a31059ca82cf4b550a058a3a1aff7ce;
pre-author reconstructiond8069f6681f60eae1629e026fa877fac11eaa92d69e0a2df6510b40270a1fad2.
The full actual forcing, signs, uniform H1 transient, spectral reuse and
ordered limits were reconstructed. No required correction was found.

Q author4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820;
review6ccba5be389898bd97ce12e53bf767dd002a3e6f282afb3cb4e010f49d86ca2d;
receiptc38f2a237e045a12870e380a7f9fc152c4a0e405238e8643050b4ec457e6dce2;
416-line pre-author reconstructiondc370ac3cef04b514962d58862735c9080e1b91b0d078345da181a2d15e32ad9,
frozen2026-10-12 00:34:22 UTC. All Q1–Q34 and their necessary source premises
were reconstructed; no required correction was found. The independent control
freeze8f388f7d3dccd6059f4002ba52187098a2da9ee5b779dc75714d16f7c0399daa
preceded author evidence. The review checked original source arguments, not
only prior review labels.

Root read both complete sources, reviews/reconstructions, independent controls,
all relevant outputs and failure dispositions. K's64author and14review artifact
bindings plus10source identities match. Q's83author and164review bindings
match;11original/source copies and all16original K/Q literal defect variants
were checked. Counts establish identity only. Root is a contributor.

K's first120s timeout is preserved; caching exact inverse/simplification led
to a successful unchanged-assertion calculation. Q's separate reviewer twice
revised overly coarse finite defect-size gates, preserving both failed runs.
Their effects were resolved above actual baseline errors; no theorem, identity
or fixture was changed. All failures and exact changes remain recoverable.
Author reproduction and independent controls have distinct roles. No Lean,
retained status or applied audit verdict is claimed.
''',
'HANDOFF.md': '''# Quantitative boost milestone snapshot

This is one regular stacked milestone on PR9484 at773321aa8fdfccc05248682dfc96bf94215034a2.
The prior boost proof/counterexamples remain untouched. K additionally imports
the explicitly conditional memory theorem from PR9481 atd8480b5a6e04102ff076b3dd6f817a2d43f20252;
its complete original proof and review are preserved here. Q depends on K.

The new analytic conclusions are the effective outgoing forcing formula,
physical approximate range corrector, explicit L2/H1 errors, simultaneous
comparison-correction norm limits for eta<1/4, and all-nine actual normalized
residual mean limits for eta<1/6. They apply only to the stated preparation.
They do not supply physical covariance, total-state occupations or optimality.

The complete author and separate review evidence is losslessly preserved.
PUBLICATION_EDITS.json maps each full note; PRIMARY_COMPOSITION.json maps each
full control. reconstruct.py verifies every byte. SOURCE_IDENTITIES.json
binds the intended publication set. No original author proof is overwritten.

The live campaign checkpoint remains in the transport worktree's
toe-dynamics-bridge-20261009 directory. Fixed deadline2026-10-12 16:00:52 UTC.
Continue useful science afterwards within that deadline. No merge, main push,
applied audit, physical-axiom or editable-prompt change, other-chat message or
deadline extension. Global pipeline and strict audit lint remain unrun landing
gates; this packet does not claim they passed.
''',
'PR_BACKLOG.md': '''# Regular milestone

Publish one coherent regular PR after final canonical and source checks.
Both K and Q have complete focused reviews at the exact preserved sources.
No draft or duplicate of the memory/edge work is needed. The parent branch is
the boost PR; the separate memory dependency is explicitly named and complete.
Continue the threshold and detector lanes after publication.
'''
}
for name, text in texts.items():
    (P/name).write_text(text)

names = ['BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md', 'BOOST_KERNEL_EFFECTIVE_DYNAMICS_REVIEW.md',
         'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md', 'BOOST_HSTAR_QUANTITATIVE_CORRECTOR_REVIEW.md',
         'K_root_review_coverage.json', 'Q_author_root_identity_check.json', 'Q_root_review_coverage.json',
         'KQ_root_original_mutation_provenance.json']
paths = [S/name for name in names]
for folder in ['boost_kernel_effective_dynamics', 'boost_forcing_review',
               'boost_hstar_quantitative_corrector', 'boost_quantitative_review']:
    paths.extend(p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
rows = []
for src in sorted(set(paths)):
    b = src.read_bytes()
    dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    assert not dst.exists()
    dst.write_bytes(gzip.compress(b, mtime=0))
    rows.append(dict(original=str(src), preserved=str(dst.relative_to(P)), bytes=len(b), sha256=sha(b)))
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Complete frozen authored, repository and review evidence; no third-party paper is redistributed.',files=rows),indent=2)+'\n')
(P/'reconstruct.py').write_text('''from pathlib import Path
import gzip, hashlib, json, textwrap
P=Path(__file__).resolve().parent
W=P.parents[3]
sha=lambda b:hashlib.sha256(b).hexdigest()
for row in json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']:
    b=gzip.decompress((P/row['preserved_source']).read_bytes())
    assert sha(b)==row['source_sha256']
    t=b.decode()
    for edit in row['edits']:
        assert t.count(edit['before'])==1
        t=t.replace(edit['before'],edit['after'])
    t+=row['appended_text']
    assert t==(W/row['publication_path']).read_text()
    assert sha(t.encode())==row['publication_sha256']
for row in json.loads((P/'PRIMARY_COMPOSITION.json').read_text())['outputs']:
    parts=[]
    for src in row['sources']:
        b=gzip.decompress((P/src['preserved_source']).read_bytes())
        assert sha(b)==src['source_sha256']
        t=b.decode()
        parts.append(t if src['wrapper'] is None else 'def '+src['wrapper']+'():\\n'+textwrap.indent(t,'    ')+'\\n\\n')
    t=row['prefix']+''.join(parts)+row['suffix']
    assert t==(W/row['publication_path']).read_text()
    assert sha(t.encode())==row['publication_sha256']
print('Both full notes and both complete finite controls reconstruct exactly')
''')
print(json.dumps(dict(own_evidence_files=len(rows), snapshot_documents=len(texts))))
