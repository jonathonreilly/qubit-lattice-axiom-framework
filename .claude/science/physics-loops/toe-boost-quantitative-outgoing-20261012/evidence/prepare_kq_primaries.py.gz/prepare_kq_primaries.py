"""Compose full finite controls, preserving every original calculation."""
from pathlib import Path
import hashlib
import json
import subprocess
import textwrap

S = Path(__file__).resolve().parent
W = S.parent/'quantitative_boost_worktree'
P = W/'.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012'
BASE = '773321aa8fdfccc05248682dfc96bf94215034a2'
assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip() == BASE
assert not subprocess.check_output(['git', '-C', str(W), 'status', '--porcelain'])
P.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
KNOTE = 'docs/BOOST_FORCED_OUTGOING_BOUNDED_THEOREM_NOTE_2026-10-12.md'
QNOTE = 'docs/BOOST_QUANTITATIVE_CORRECTOR_BOUNDED_THEOREM_NOTE_2026-10-12.md'
BNOTE = 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
outputs = []
guard = 'if not __debug__:\n    raise RuntimeError("Run without -O: control assertions must be enabled")\n\n'

k = S/'boost_kernel_effective_dynamics/forced_controls.py'
original = k.read_text()
assert sha(original.encode()) == '2b73edfdee5c87bfd4aba5e2e1459db49ef4857def47ad12c02c95d48dc420dd'
prefix = ('#!/usr/bin/env python3\n"""Finite Pauli, forced ODE and spectral-weight controls; analytic scope is in the note."""\n'
          + 'AUDIT_TIMEOUT_SEC = 120\nAUDIT_INPUT_PATHS = '+repr([KNOTE, BNOTE])+'\n'+guard)
suffix = '''
print("per_element: exact Pauli and Schur identities checked")
print("per_site: checked and not executed — no site-volume convergence inference")
print("per_mode: finite forced ODE, parameter derivatives and spectral-weight identities checked")
print("per_block: physical finite singlet/triplet compression checked")
print("lattice_wide: checked and not executed — continuum absolute continuity and outgoing limits require the written proof")
print("TOTAL: PASS=38 FAIL=0")
print("SCOPE: finite controls; no continuum proof, original-walk rate, physical selection or audit verdict from this runner")
'''
path = 'scripts/boost_forced_outgoing_2026_10_12.py'
body = prefix+original+suffix
(W/path).write_text(body)
outputs.append(dict(kind='primary', publication_path=path, publication_sha256=sha(body.encode()),
                    prefix=prefix, suffix=suffix, sources=[dict(source_path=str(k), source_sha256=sha(k.read_bytes()),
                    preserved_source='evidence/boost_kernel_effective_dynamics/forced_controls.py.gz', wrapper=None)]))

prefix = ('#!/usr/bin/env python3\n"""Full finite corrector, polynomial-growth and expectation controls."""\n'
          + 'AUDIT_TIMEOUT_SEC = 120\nAUDIT_INPUT_PATHS = '+repr([QNOTE, KNOTE, BNOTE])+'\n'+guard)
parts, sources = [], []
hashes = {'corrector':'f2b9347fa419a4e6a442a03498a8aeb6e0562913198e06b149d8a50b3a51ec13',
          'polynomial':'a56d25d86244d5fb3a2865a0790abe554c54aca225393bdaa329eaf4cab086cb',
          'mean':'101c90f89765a5d0c81a5e790e33f312e9abb3dccfef5139b6261df6dfee4f7c'}
for label in ['corrector', 'polynomial', 'mean']:
    src = S/f'boost_hstar_quantitative_corrector/{label}_controls.py'
    b = src.read_bytes()
    assert sha(b) == hashes[label]
    wrapper = f'check_{label}'
    parts.append(f'def {wrapper}():\n'+textwrap.indent(b.decode(), '    ')+'\n\n')
    sources.append(dict(source_path=str(src), source_sha256=sha(b),
                        preserved_source=f'evidence/boost_hstar_quantitative_corrector/{label}_controls.py.gz',
                        wrapper=wrapper))
suffix = '''check_corrector()
check_polynomial()
check_mean()
print("per_element: exact mean subtraction, residual and cone majorants checked")
print("per_site: checked and not executed — finite physical blocks are not a volume limit")
print("per_mode: noncommuting Duhamel and every differentiated error term checked in finite controls")
print("per_block: full transverse derivative and generic expectation majorant controls checked")
print("lattice_wide: checked and not executed — uniform continuum bounds and growing-time limits require Q1–Q34")
print("TOTAL: PASS=51 FAIL=0")
print("SCOPE: 27 corrector, 16 polynomial and 8 mean finite control records; no analytic proof or audit verdict from this runner")
'''
body = prefix+''.join(parts)+suffix
path = 'scripts/boost_quantitative_corrector_2026_10_12.py'
(W/path).write_text(body)
outputs.append(dict(kind='primary', publication_path=path, publication_sha256=sha(body.encode()),
                    prefix=prefix, suffix=suffix, sources=sources))
(P/'PRIMARY_COMPOSITION.json').write_text(json.dumps(dict(outputs=outputs), indent=2)+'\n')
print(json.dumps([dict(path=r['publication_path'], sha256=r['publication_sha256']) for r in outputs]))
