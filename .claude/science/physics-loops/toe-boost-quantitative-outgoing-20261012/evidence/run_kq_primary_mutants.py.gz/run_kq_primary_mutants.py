"""Run actual full-publication-primary defects, with complete evidence."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
W = S.parent/'quantitative_boost_worktree'
D = S/'kq_primary_mutations'
D.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
cases = []
for label, path, folder, manifest in [
    ('K', 'scripts/boost_forced_outgoing_2026_10_12.py', 'boost_kernel_effective_dynamics', 'mutation_manifest.json'),
    ('Q', 'scripts/boost_quantitative_corrector_2026_10_12.py', 'boost_hstar_quantitative_corrector', 'mutation_manifest.json'),
    ('Q', 'scripts/boost_quantitative_corrector_2026_10_12.py', 'boost_hstar_quantitative_corrector', 'polynomial_mutation_manifest.json')]:
    for row in json.loads((S/folder/manifest).read_text()):
        cases.append((label, path, row))


def run(case):
    label, path, spec = case
    name = label+'_'+spec['name']
    body = (W/path).read_text()
    assert body.count(spec['before']) == 1
    changed = body.replace(spec['before'], spec['after'])
    src = D/(name+'.py')
    src.write_text(changed)
    command = [sys.executable, str(src)]
    started = time.monotonic()
    timed_out = False
    try:
        p = subprocess.run(command, capture_output=True, timeout=120)
        out, err, code = p.stdout, p.stderr, p.returncode
    except subprocess.TimeoutExpired as exc:
        out, err, code, timed_out = exc.stdout or b'', exc.stderr or b'', None, True
    elapsed = time.monotonic()-started
    (D/(name+'.stdout')).write_bytes(out)
    (D/(name+'.stderr')).write_bytes(err)
    if label == 'K':
        baseline = (S/'boost_kernel_effective_dynamics/baseline_attempt2.stdout.log').read_text()
    else:
        baseline = ''.join((S/'boost_hstar_quantitative_corrector'/f).read_text() for f in
                           ['baseline.stdout.log', 'polynomial_baseline.stdout.log', 'mean_baseline.stdout.log'])
    row = dict(name=name, primary_path=path, primary_sha256=sha(body.encode()),
        before=spec['before'], after=spec['after'], source_sha256=sha(changed.encode()),
        command=command, timeout_seconds=120, elapsed_seconds=elapsed, exit_code=code,
        timed_out=timed_out, utc=datetime.now(timezone.utc).isoformat(),
        expected_assertion=spec['expected_assertion'],
        intended_failure=code == 1 and f"AssertionError: {spec['expected_assertion']}" in err.decode(),
        stdout_sha256=sha(out), stderr_sha256=sha(err),
        stdout_baseline_prefix=out.decode().splitlines() == baseline.splitlines()[:len(out.decode().splitlines())])
    (D/(name+'.execution.json')).write_text(json.dumps(row, indent=2)+'\n')
    return row


with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(run, cases))
(D/'manifest.json').write_text(json.dumps(dict(runs=rows), indent=2)+'\n')
for row in rows:
    print(row['name'], row['exit_code'], row['intended_failure'], row['stdout_baseline_prefix'])
assert all(r['intended_failure'] and r['stdout_baseline_prefix'] and not r['timed_out'] for r in rows)
