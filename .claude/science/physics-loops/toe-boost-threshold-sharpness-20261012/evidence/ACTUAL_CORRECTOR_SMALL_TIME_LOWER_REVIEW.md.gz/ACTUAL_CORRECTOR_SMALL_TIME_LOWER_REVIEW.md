# Independent review of the actual boost-corrector lower bound

**PASS for the conditional supplied-model theorem L1–L20 at the frozen
source below. No required mathematical correction or unresolved proof
obligation was found within that scope.** This is an independent source
review; it applies no audit verdict and grants no retained status.

For the exact globally normalized B25–B30 preparation and the full physical
direct integral, the actual error D_lambda=W_lambda-z satisfies

    0<liminf_(lambda->0) ||D_lambda(t)||_2/sqrt(lambda)
      <=limsup_(lambda->0) ||D_lambda(t)||_2/sqrt(lambda)<infinity

for each fixed 0<t<=t0. The note's explicit t0, positive subinterval and
finite-lambda threshold are valid. In particular, for every 0<t<=t0 and
0<lambda<=lambda_*(t), with lambda_*(t)>0 as specified in L20,

    c_init sqrt(lambda t)/4 <= ||D_lambda(t)||_2
                              <=7c_init sqrt(lambda t)/4.

The bound concerns effective time t, with physical time t/lambda. The limit
holds with t fixed; the finite-lambda threshold depends on t. It proves
the square-root order for the actual error on that interval, without
determining its exact leading coefficient.

The S dependency has now received its separate matching source review.
The frozen target's statements that S review is pending describe its
earlier freeze state. Update that metadata in any publication copy while
preserving the original evidence. This is not a mathematical defect.

## Frozen identities and reading scope

The complete target is
[ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md](ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md),
406 lines, SHA-256
`972b66765f82346a9fb3a4171350b8136a4fb80671f99b4d35355d0388d09ef3`.
The author receipt has SHA-256
`6cd64fbba30a20a9582773a0fd944cb8db6922d679684a50c4b2ab0f2b281b1c`.
Both remain unchanged. Every target line was read and reconstructed.

| Source | Direct reading for this review |
|---|---|
| Q `4b1d5a83…` and review `6ccba5be…` | All 729 and 211 lines; physical corrector, residual class, exact source/generator remainders and stated constants. |
| S `6856c6ff…` and review `913a9c81…` | All 445 and 129 lines; physical block, local spectral measure, S19 coefficient and remainder, and initial-source identification. Review receipt `0e1cea8a…` and its bindings match. |
| X `a7161d79…` | Lines 1–355, including complete exact preparation, global normalization, forced equations and actual error through X23. |
| B `903261f5…` | Lines 1–181 and 488–605; physical definitions and complete B25–B30 preparation. |
| K `1c314fc0…` | Lines 1–230; full transverse block and exact forcing/resolvent representation needed by Q11. No long-time spectral conclusion is needed for L. |

The original source arguments, rather than only review labels, were checked
at their necessary complete proof scope. All source copies and full hashes
are in [source_manifest.json](actual_corrector_review/source_manifest.json).
Older source copies outside this mathematical closure were identity-checked,
not newly certified. No fresh re-review of the earlier Q/S author packets
or S's external spectral-theorem reference is claimed.

## Decisive findings

1. **The actual equation and physical residual class are correct**
   (target lines 126–198, L6–L10). Subtracting the exact W and z equations
   gives the positive ODE source Q(Bz-g)+E_lambda z+g-g_lambda and the
   Duhamel prefactor -i. The two original global normalizers remain in
   g_lambda. The full kernel is transverse triplets plus zeta; the excluded
   constant singlet is not a physical zero mode. Both r and r' are
   longitudinal and satisfy the one full-torus mean constraint.

2. **The weighted primitive estimate holds at every nonnegative length**
   (lines 200–251, L11–L13). Mean subtraction makes the cutoff corrector
   physical and supplies the second range-error term. Folding all eight
   sine cells proves the stated cone constants. The fixed-cutoff identity
   has both endpoints with the correct sign. Choosing delta=lambda/s
   afterwards gives the large-length estimate; the Hilbert embedding
   covers 0<=s<=lambda. No cutoff derivative, full inverse, operator gap
   or complementary-unit-ball bound is used.

3. **Noncommutation and time variation are retained correctly**
   (lines 253–317, L14–L17). The primitive difference equation fixes the
   exact order U_G V_lambda J_H. Only the input to J_H needs weighted
   regularity. The Hilbert C1 residual and bounded generators justify
   Bochner Fubini on the full finite time triangle. Applying the primitive
   estimate separately to r'(v) gives the coefficients 2/3 and 4/15.
   The full e_lambda, including possible singlet parts, contributes
   at most M lambda t(1+t). Its generator and source terms are not dropped.

4. **The initial continuum coefficient and every final constant check**
   (lines 84–124 and 319–370, L3–L5 and L18–L20). S19 factors through
   r(0)=-c0 a(0)Qh0 without a kappa-dependent spectral inference.
   Its coefficient is c_init=c0||a(0)||/(sqrt(2pi)I0), and the exact
   nonnegative preparation proves the stated positive lower bound.
   A_L+B_L=(38/5)K_R M gives
   t_bar=5/[15428 pi sqrt(3pi)K_R]>0, approximately 7.07734e-6.
   Both triangle inequalities give L19. The finite-lambda budgets are
   exactly 15/64 for the squared free error, 1/2 for perturbation plus
   variation, and 1/8 for forcing, yielding the 1/4 and 7/4 bounds.

An additional independent local check bounds ||r'(s)||_W by
`(3 exp(1/2)+21)c0m<26c0m<6M` on [0,1], directly from the source and
bounded-kernel Picard expansion. It confirms the generous L10 constants
without using K's long-time spectrum or weighted-space Bochner assumptions.
The complete argument is in
[PROOF_RECONSTRUCTION_PRE_AUTHOR.md](actual_corrector_review/PROOF_RECONSTRUCTION_PRE_AUTHOR.md).

## Independence, controls and reproduced evidence

The 287-line reconstruction and a distinct exact rational control were
frozen at **2026-10-12 01:23:44 UTC**, before opening any new L author
helper, receipt or log. The reconstruction SHA-256 is
`49a4255bf7744f088586ea1fa4a19cf43579ec9bf02efeda54c9e7da2d70b0a4`;
[PRE_AUTHOR_FREEZE.json](actual_corrector_review/PRE_AUTHOR_FREEZE.json)
has SHA-256
`3fdc0f578faa7b248f40795a2fe07a138474fc0c9a2fac6052b51c213eb0632e`.

The independent implementation uses rational longitudinal factorization
and formal coefficient recurrences through degree seven, rather than the
author's Pauli matrices and augmented exponentials. It checks the physical
centering, primitive identity, full error equation, noncommuting order,
varying-source identity and complete comparison. Eight deliberate wrong
expressions are distinguished exactly. The first scientific run completed
successfully in 2.52 seconds under its 120-second timeout; there was no
failed scientific baseline or tolerance adjustment.

After the freeze, the entire new author helper, AUTHOR_CHECK, bookkeeping
scripts, semantic receipt fields, original execution metadata and full logs
were inspected. Each complete mutant was verified as the fully read baseline
plus its unique literal change; all seven changes and complete tracebacks
were read. A fresh baseline and all seven mutants reproduced the recorded
exit codes and intended assertions. Standard output is byte-identical;
tracebacks agree after substituting only the copied script path. The
baseline took 0.89 seconds and each mutation 0.58–0.71 seconds, under
separate 120-second timeouts. These are reproductions, not independent
proofs. Full records are in [reproductions](actual_corrector_review/reproductions/manifest.json).

The finite fixture's noncommuting contribution, source variation and forcing
errors are resolved above its numerical discrepancy. Neither this fixture
nor the independent rational model establishes continuum sharpness. Their
fixed complementary gaps instead give a different lambda-first free law;
the analytic cone and spectral arguments supply the continuum result.

The independent identity check matched the 58 author receipt bindings,
all 64 original/copied packet files, twelve source pairs, fourteen exact-ref
instruction records, prior Q/S/K author bindings, Q/S review receipts, and
the pre-author reviewer freeze. Its first attempt used the wrong anchor
for relative paths in the older Q review receipt and stopped with
FileNotFoundError. The full failed verifier and logs are preserved in
[failed_identity_attempt1](actual_corrector_review/failed_identity_attempt1/DIAGNOSIS.md).
The corrected schema-specific path resolution passed. No scientific source
or expected value changed. Identity matching is bookkeeping, not proof.

## Acceptance boundary and recovery

This one review iteration supports conditional reuse of the exact L1–L20
source. The supplied model and selected packet remain disclosed conditions.
The non-L2 inverse, inadequate coarse propagator comparison, necessary source
variation, full forcing error, and distinct finite-mesh limit remain valid
scoped limitations. No actual leading coefficient, H1 sharpness, mean lower
bound, growing-time optimum, physical covariance or retained status follows.
No Lean proof-kernel verification was performed.

Root proposed the mechanism and remains a coauthor. This checker did not
author it; the target and prior source reviews were shared, so the check
is source-shared rather than blinded. The user-selected model and effort
were inherited without override or subdelegation. Instructions were bound
to main `a13caa4885f547c8d206265b031ba7649e539fd9` and execution
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`, without a remote freshness claim.

The read-only quantitative checkout remains at
`36d6069676f561d81ad693f286dd52f570fb37df`. Root's concurrent new publication
files are outside this frozen-source verdict. No combined integration gate,
publication approval, PR action, scientific audit or repository mutation was
performed here. A changed load-bearing source or new interaction needs
affected-source confirmation.

Only this report and `actual_corrector_review/` were written. **No editable
prompt file changed.** The fixed campaign deadline remains
2026-10-12 16:00:52 UTC. The source-bound [receipt.json](actual_corrector_review/receipt.json)
and [CHECKPOINT.md](actual_corrector_review/CHECKPOINT.md) preserve recovery,
full execution evidence, failure history and the exact acceptance boundary.
