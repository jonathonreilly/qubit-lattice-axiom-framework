# Independent review of the physical H-star threshold theorem

**PASS for the conditional supplied-model result S1–S20 at the frozen
source below. No required source correction or unresolved mathematical
obligation was found within that scope.** This is independent source review,
not a scientific audit or a grant of retained status.

For the exact full-torus, globally compressed sine-Pauli operator, the
source measure after removing its kernel projection has

    rho_Qh0(E)=1/(4pi^2 I0^2)+O(E^2),

and the free fast primitive satisfies

    ||J_lambda(t)||^2=|t|lambda/(2pi I0^2)+O(lambda^2).

The displayed remainder constant is valid uniformly as an absolute bound
in real t and lambda>0. The claimed square-root-lambda norm asymptotic
uses fixed t!=0. S20 correctly extends it to the actual initial residual
direction with its time frozen, under the free fast generator.

**Limit:** this does not establish the same lower bound for the full
noncommuting generator, the time-dependent actual residual, W_lambda-z,
a boost expectation or an optimal growing-time window. No result from the
concurrent quantitative Q theorem is used as a premise.

## Frozen source and read coverage

The target [HSTAR_THRESHOLD_SPECTRAL_PROBE.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md)
has 445 lines and SHA-256
`6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da`.
All lines and all necessary source premises were read completely before
opening the new author control, AUTHOR_CHECK, logs or receipt.

| Source | SHA-256 | Complete reading |
|---|---|---|
| EXCLUDED_WALK_BOOST_CURRENT_PROBE.md | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` | 744 lines; physical space, global contact rule, exact packet |
| BOOST_CURRENT_INVERSE_ENERGY_PROBE.md | `76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990` | 658 lines; physical kernel and normalization reconstructed directly |
| BOOST_CURRENT_EXPECTATION_PROBE.md | `a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68` | 587 lines; original forcing equation and initial direction |
| EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md | `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929` | 185 lines; exact free comparison and actual-evolution distinction |
| ROOT_HSTAR_SPECTRAL_LEAD.md | `5f46fe463706253f02ed8d8d42d0c89fac69a3b295999d4aac531bcd4300f4de` | 51 lines; proposal, not evidence of its desired conclusion |
| Prior X review and reconstruction | identities in source_manifest.json | 186 and 426 lines, read after this review's analytic freeze; no new-threshold authority inferred |

The older notes were read for this theorem's actual premises; this report
does not renew independent coverage of every unrelated older conclusion.
The supplied lattice, pair sector, contact rule and clock remain explicit
model data. No framework primitive or physical identification is derived.

The necessary original statements and proofs of Teschl 3.1, 3.7 and 3.21
were checked at the [author-hosted 2009 book](https://www.mat.univie.ac.at/~gerald/ftp/book-schroe/schroe.pdf).
They apply to bounded self-adjoint operators and finite scalar measures.
The opposite resolvent sign and inversion endpoint weights are handled
correctly. The author preserved a URL and fingerprint rather than a local
PDF; a fresh fetch matched SHA-256
`8dc8de0b58aa0a3fedfe594a345f9b5875322e5526ea581cb640a98d55b82818`.

## Decisive findings

| Source steps | Disposition and reason |
|---|---|
| S3–S5, [line 79](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:79) | Accept. Even mean-zero singlets and even longitudinal coefficients give the stated bounded off-diagonal operator. AA*=M_h²−\|h⟩⟨h\|, with the full global mean projection. The complete physical kernel and source atom at zero are correct. |
| S6–S7, [line 146](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:146) | Accept. Directly solving the resolvent equation gives G=1−1/(zF). Its negative imaginary convention and zero atom 1/I0 agree with the kernel overlap. |
| S8–S10, [line 178](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:178) | Accept. All eight cones, full-torus normalization and radial Jacobian give 1/(4pi²). A separate arcsine/Dirichlet calculation recovers it and the first correction. The explicit derivative bounds check. |
| S11–S15, [line 233](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:233) | Accept. Moving-point subtraction proves uniform upper boundary convergence on positive compact intervals. The real threshold error is O(s). Scalar inversion with endpoint atoms excluded identifies the entire local measure; no singular continuous component is discarded. |
| S16–S17 and S1, [line 314](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:314) | Accept. Chiral symmetry gives equal signed branches. Their factor one-half cancels ds/dE=2\|E\|. Removing the exact zero atom leaves local absolute continuity and the stated O(E²) remainder. |
| S18–S19 and S2, [line 347](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:347) | Accept. The exact spectral multiplier, both energy signs and three remainder bounds give the coefficient 1/(2pi I0²) and the displayed uniform absolute O(lambda²) bound. |
| S20, [line 383](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/HSTAR_THRESHOLD_SPECTRAL_PROBE.md:383) | Accept with the source's explicit limit. X20 gives r_X(0)=−c0 a(0)Qh0. Its global normalization and positive envelope make the coefficient nonzero. This is still frozen forcing with free propagation. |

The full argument, including the exclusion of hidden local singular mass,
is in [PROOF_RECONSTRUCTION.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/PROOF_RECONSTRUCTION.md).
It was frozen at 01:06:41 UTC before opening the new author evidence;
[PRE_AUTHOR_FREEZE.json](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/PRE_AUTHOR_FREEZE.json)
has SHA-256 `8a10c007642e3b4adb1c8561d74ccb2398eac52ec835d93111c6725650742f85`.

## Independent calculations and reproduction

The separately written [independent_checks.py](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/independent_checks.py)
uses literal Pauli matrices with different nonaxial momenta and nonuniform
weights, exact rational resolvents, a Dirichlet density calculation, and
time-autocorrelation versus spectral primitive integration. Its successful
run was frozen before author-code access. Two distinct actual-torus
quadratures give I0 approximately 0.252731009858663; this value is only a
numerical consistency check and does not enter the continuum proof.

The first reviewer cubature mistakenly counted 48 sectors where its
parametrization has 24. The separate Laplace integral exposed that factor
of two. The failed source, full traceback and correction are preserved in
[failed_initial_check](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/failed_initial_check/DIAGNOSIS.md).
This was a reviewer-check error, not a defect in the frozen theorem.

After the freeze, every new author evidence file was inspected. Each full
mutation source was verified against the fully read baseline plus its
unique change; all changes and all complete outputs were read. Fresh runs
reproduced the baseline exit 0 and all six intended assertion failures.
Outputs match the originals byte for byte, apart from the expected script
path in tracebacks. The original receipt verifier also exited 0. The
47-entry source/evidence inventory, seven source copies, fourteen pinned
instruction identities and post-freeze output bindings all match.

These are reproductions and provenance checks, distinct from the new
calculation and analytic review. The author's radial model, finite matrix
and the reviewer's quadrature do not establish continuum spectral type.
Details and full logs are in [AUTHOR_EVIDENCE_REVIEW.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/AUTHOR_EVIDENCE_REVIEW.md)
and its linked evidence directory. No formal Lean verification was performed.

## Safe reuse and recovery

The result may be reused as an independently checked conditional theorem
for this source direction and free generator at these exact bytes. The
non-L2 inverse failure, the unremoved zero atom's t²/I0 term, the different
finite-mesh limit and the inadequate O(t²) perturbation comparison are
correctly preserved as scoped limitations. None is a framework-wide no-go.

Root and the author remain coauthors; this reviewer is a separate checker
with shared target information, not a blinded discoverer. The selected
model and effort were inherited without override or subdelegation.
Applicable instructions were read from main `a13caa4885f547c8d206265b031ba7649e539fd9`
and execution `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The checkout had moved
from the brief's parent to `36d6069676f561d81ad693f286dd52f570fb37df`; no
claim here depends on its new Q/K content, and the frozen external inputs
remain identical. No remote freshness or global repository-integrity claim
is made.

Only this review file and `hstar_threshold_review/` were written. No frozen
source, editable prompt, Git state, PR, axiom, audit status or other chat was
changed. The fixed 2026-10-12 16:00:52 UTC deadline was not extended.
The source-bound [receipt.json](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/receipt.json)
and [CHECKPOINT.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_review/CHECKPOINT.md)
provide the recovery path. No correction is required for the reviewed scope.
