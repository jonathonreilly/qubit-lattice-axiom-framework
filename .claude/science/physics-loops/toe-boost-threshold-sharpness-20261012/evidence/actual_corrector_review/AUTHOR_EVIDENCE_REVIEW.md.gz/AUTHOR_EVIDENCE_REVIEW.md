# Author evidence inspected after the independent freeze

The complete author packet was copied only after PRE_AUTHOR_FREEZE.json was
written at 2026-10-12 01:23:44 UTC. The access/copy timestamp and every copied
file are recorded in author_inventory.json. Original author receipt:
6cd64fbba30a20a9582773a0fd944cb8db6922d679684a50c4b2ab0f2b281b1c.

The entire 203-line actual_lower_controls.py, 177-line AUTHOR_CHECK.md,
18-line freeze_receipt.py, 31-line run_mutations.py, 62-line verify_receipt.py,
61-line checkpoint and 103-line root lead were read. All source/instruction
manifests and receipt semantic fields were read; identity arrays were checked
deterministically against their actual bytes. The original 179-line baseline,
all seven complete mutation tracebacks, execution JSON, mutation-run output,
receipt-freeze output and verification output were inspected. Empty stderr
and stdout files were verified as empty, not inferred from a summary.

Each entire mutant equals the fully read baseline with exactly its one
declared literal replacement. All seven differences were inspected. Its
changed-source hash and saved assertion are bound. No baseline tolerance
was changed and no mathematical baseline failure was found in this packet.

The helper uses four weighted antipodal q pairs, the literal two-Pauli
Hamiltonian, parity isometry and one global singlet projection. It retains
nine physical zero modes in dimension fifteen. The one-x source is disclosed
as a finite diagnostic with exact sine/projector/normalizer structures, not
the actual continuum B25 envelope. It gives nonzero E_lambda z and source
approximation error. The operator comparison is genuinely noncommuting.

Its primitive is checked by spectral functions against a separate augmented
matrix exponential. The source derivative has a finite-difference comparator.
The ordered integral and varying-source Fubini identity use direct quadrature,
and the exact full W-z uses separate augmented forced solutions. The seven
literal mutations correctly discriminate the mean subtraction, initial
endpoint, comparison sign, noncommuting order, Bz' term, E_lambda z term,
and actual Duhamel sign. The independent pre-author rational-coefficient
control does not import this implementation and supplies a distinct algebra
path for the load-bearing identities.

One fresh execution of the baseline and each saved mutant was performed
from the unmodified copied source, with a separate 120-second timeout and
complete outputs in reproductions/. Baseline exit 0, all seven mutants exit
1 at their intended assertions. All standard outputs match byte for byte.
Every traceback matches after the sole original/copy path substitution.
The baseline elapsed 0.893744 seconds; mutation runs ranged from 0.578698
to 0.712974 seconds. These are reproductions, not independent continuum
evidence. The eight-case manifest records each source and output hash.

The finite complementary gap is explicitly distinguished from the continuum
threshold. A finite matrix can validate operator algebra but cannot establish
the square-root law by a lambda-first limit. The analytic proof, its physical
weighted hypotheses, and the separately checked S source provide that law.
The helper's status language and AUTHOR_CHECK preserve this limit.

identity_checks.py independently validates all 58 receipt bindings, 64 copied
packet files, twelve original/copy source pairs, fourteen exact-ref instruction
fingerprints, post-freeze log bindings, seven exact mutants, the prior Q/S/K
author receipts, the Q/S independent-review receipts, and this review's source
and pre-author snapshots. No scientific conclusion is inferred from counts.
The original author freeze script was not rerun because it writes the frozen
receipt. The original author verifier was not rerun because its fixed old
checkout path lies outside the assigned checkout; its complete read-only
logic and saved output were inspected, and the independent verifier uses the
permitted quantitative checkout for the same exact Git-object reads.

The first identity run used the wrong relative-path anchor for the Q review
receipt and stopped before comparing its first file. The failure was in
reviewer bookkeeping, not the target or author evidence. Its full source,
stderr, stdout and metadata are preserved in failed_identity_attempt1/.
After matching each receipt's actual path convention, the identity check
passed in 0.605937 seconds under a 60-second timeout with empty stderr.

No required scientific correction arises from the author-evidence inspection.
Pending-review metadata is historical at the author's freeze. S review is now
complete at the matching source and its original pending strings may be
updated in publication metadata without modifying the frozen originals.
