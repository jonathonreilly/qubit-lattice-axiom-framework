# Independent reconstruction before author-evidence access

Target: ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md, all 406 lines,
SHA-256 972b66765f82346a9fb3a4171350b8136a4fb80671f99b4d35355d0388d09ef3.
This is a source-shared check, not blinded discovery. The target and preceding
Q/S sources and reviews were visible. No actual_corrector_small_time_lower
helper, receipt, log, AUTHOR_CHECK or source manifest has been opened when
this reconstruction and its independent controls are frozen.

## Contract, sources, and proof graph

For precisely the globally normalized B25–B30 packet, the complete physical
direct integral, and 0<t<=t0 fixed before lambda decreases to zero, prove
strictly positive finite lower and upper bounds for ||W_lambda(t)-z(t)||/
sqrt(lambda). Also check every constant in the finite-lambda bounds L20.
The supplied sine-Pauli Hamiltonian, contact exclusion, antisymmetric pair
sector, clock, momentum coordinates and exact preparation are conditions.
No physical identification, axiom adoption, retained status or audit is made.

Complete new source: L1–L20. Supporting source reads before this freeze:
Q all 729 lines; Q review all 211 lines; S all 445 lines; S review all 129
lines; X lines 1–355 (complete actual source, rescaling, forcing and error
equations X2–X23); B lines 1–181 and 488–605 (definitions and complete exact
preparation); K lines 1–230 (block and exact resolvent forcing through K10).
The unchanged original identities and recovery copies are in source_manifest.
Unrelated older conclusions are not independently recertified by these reads.

The acyclic graph needed by L is:

1. B/X exact physical definitions and preparation -> actual W and z ODEs.
2. Physical Pauli block and global exclusion -> full kernel, longitudinal Q
   constraint and physical mean-subtracted range vectors.
3. Cone integration -> weighted range approximation -> all-length free
   primitive estimate.
4. Bounded noncommuting generator comparison plus Hilbert C1 source -> full
   actual-error comparison including variation and forcing approximation.
5. S's source-specific threshold measure -> positive initial free scale.
6. Two triangle inequalities and explicit constants -> L19 and L20.

The new comparison does not assume the desired actual lower bound in any
leaf. The independent S result covers only the frozen free direction, and
therefore is strictly weaker than the target to be checked here.

## 1. Physical generator, kernel and exact source

The one global relative projection is P=I-|c><c|. In singlet/triplet
coordinates the K=0 Pauli symbol is [[0,2s^T],[2s,0]]. An even singlet
alpha has full-torus mean zero; a triplet is odd. Set h=2epsilon. On the
singlet/longitudinal subspace the physical bounded operator is

    H_* = [[0,P0 M_h],[M_h,0]],

with the lower-left map restricted to the mean-zero scalar space and P0
the global scalar centering projection. Multiplication by h is injective
almost everywhere. Its adjoint kills exactly multiples of 1/h. Together
with the transverse triplets this yields exactly Pi=F_tr+|zeta><zeta|,
zeta=n/(2epsilon sqrt(I0)). This is the whole physical kernel, not the
extra excluded constant singlet of an ambient compression.

For a triplet u, Q u=beta n and

    beta=n.u-<zeta,u>/(2epsilon sqrt(I0)),
    integral beta/(2epsilon) dmu=0.

Odd u and odd n make beta even. If epsilon|beta|<=C(kappa), the integral
is absolutely convergent because integral epsilon^-2=4I0<infinity.

B=i d cross on triplets and kills singlets; ||B||<=|kappa|<=1/4. Therefore
the exact z and g are triplets, and r=Q(Bz-g), r'=Q(Bz'-g') are physical
longitudinal vectors satisfying the same full-torus mean constraint.

For the source, X's six-dimensional normalization cancels the packet's
(2pi)^3 lambda^-3 factor. The K-only isometry has c0 lambda^(3/2).
The contact coefficient a_lambda is a scalar amplitude, not a fiber norm.
The initial global scalars satisfy

    Z_lambda^2=integral |F|^2 |f|^2 w_lambda,
    n_lambda^2=1-c0^2 lambda^3 ||a_lambda(0)||^2.

The exact projected free comparison has fixed initial n_lambda. Direct
subtraction from the exact walk gives W'= -i G_lambda W+i g_lambda.
There is zero initial correction. The effective solution has
z'=-i A z+i Pi g and Pi z=z. Since H_*z=0,

    G_lambda z-Az=QBz+E_lambda z,
    iD'=G_lambda D+Q(Bz-g)+E_lambda z+g-g_lambda,
    D(0)=0.

Thus the actual Duhamel sign is -i. Both source normalizers, form factor
and exact fast source clock occur in g_lambda. No extra homogeneous tail
and no transverse-only projection of the error is permissible.

## 2. Complete forcing approximation and weighted source regularity

Q's elementary sine estimates on |kappa|<=1/4 give, for lambda<=1/16,
||E_lambda||<=lambda/32, ||V_lambda||<=1, ||g_lambda-g||<=M lambda^2(1+t).
The actual Hilbert forced ODE gives ||z(s)||<=Ms<=Mt. Therefore

    ||e_lambda(s)||<=M lambda[t/32+lambda(1+t)]
                       <=M lambda(1+t), 0<=s<=t<=1.

The first contribution may be singlet-valued. Only full physical-Hilbert
unitarity, not a longitudinal weighted estimate, is used for it.

The source integral differentiates in Hilbert norm because 0<=e<=7/4,
f is integrable and F is L2 with fixed support. A is a bounded self-adjoint
direct-integral operator; hence z and r are Hilbert C1 and r' is continuous.
This provides Bochner integrability for the later varying-source identity.

The weight is ||u||W^2=integral (esssup_q epsilon|u|)^2 dkappa. Joint
measurability makes the essential-supremum scalar measurable. Pointwise
integration yields ||u||2<=2sqrt(I0)||u||W. No strong measurability into
an L-infinity space is asserted or needed.

Q12 gives R_init=3M, R_dot=6M on [0,1]. A second shorter source-specific
bound verifies that these ample constants are safe without relying on K's
long-time spectral result. On triplets, ||Q||w<=2, ||Pi||w<=2 and
||A||w<=1/2 on its kernel. With J=6c0m, the source obeys
||Pi g||W<=J, ||g'||W<=7J/4, ||g(0)||W<=J. The successive-integral
expansion of the actual bounded ODE gives

    ||z(t)||W<=2J(exp(t/2)-1),
    ||z'(t)||W<=J exp(t/2),
    ||r(0)||W<=2J=12c0m<3M,
    ||r'(t)||W<=J[exp(1/2)/2+7/2]
                    =(3exp(1/2)+21)c0m<26c0m<6M.

These bounds follow by weighted estimates on finite Picard sums, then
Hilbert convergence and Fatou, so they require no weighted Bochner
integration. The target's stated R constants are therefore justified by
both its Q12 route and this independent, local-in-time estimate.

## 3. Physical approximate inverse and the all-length primitive bound

For a fixed longitudinal f=beta n with ||f||W=R and zero weighted global
mean, define a_delta=(beta/(2epsilon))1_{epsilon>=delta}, m_delta=<a_delta>,
x_delta=(a_delta-m_delta)c. This is even and mean zero, hence physical.
The exact residual is beta n 1_{epsilon<delta}+2epsilon n m_delta.
The latter term cannot be discarded. The cutoff map is a bounded Hilbert
operator with norm <=1/(2delta); it preserves measurable sections.

Fold the eight sine cells to the cube [-pi/2,pi/2]^3, with normalized
measure pi^-3 dq and (2/pi)|q|<=epsilon<=|q|. Radial enlargement gives

    integral_{epsilon<delta} epsilon^-2 <= pi delta/2,
    integral_{epsilon>=delta} epsilon^-4 <= pi^2/(4delta).

Centering is an orthogonal projection; its norm does not increase the
uncentered cutoff coefficient. Also integral epsilon^2=3/2. These facts
give ||x_delta||<=c_x R/sqrt(delta),
||f-H_*x_delta||<=c_e R sqrt(delta), with c_x=pi/4 and
c_e=sqrt(pi/2)+pi sqrt(6)/4. The last estimate uses delta<=sqrt(delta).

For each fixed delta and s, integrate H_* U_H directly:

    J_H(s)f=-i lambda (I-U_H(s))x_delta
                +J_H(s)(f-H_*x_delta).

Its derivative and zero initial value check both endpoint signs. If s>=
lambda, subsequently choose delta=lambda/s to get (2c_x+c_e)R sqrt(lambda s).
If s<=lambda, use the embedding and s<=sqrt(lambda s). The constant
2sqrt(I0)<=sqrt(pi sqrt(3)/2)<=pi sqrt(6)/4<K_R is sufficient. The middle
inequality is equivalent to 4sqrt(3)<=3pi and is strict. At s=0 both sides
vanish. Hence the bound holds for all lengths s>=0 and all lambda>0.

The selected cutoff is constant during each primitive calculation. Applying
the resulting norm inequality at varying lengths differentiates no cutoff.
This is a regularity-class estimate, not a complementary-Hilbert-unit-ball
bound. A full inverse of r(0) is non-L2 because of its epsilon^-2 singlet
coefficient and the local three-dimensional epsilon^-4 integral.

## 4. Noncommuting and time-varying comparisons

An independent derivation starts from the mild Volterra equation for the
primitive. Let Y=J_G f, X=J_H f. Then

    Y'= -iG Y+f, X'= -i(H_*/lambda)X+f.

Consequently Z=Y-X solves Z'=-iG Z-iV_lambda X, Z(0)=0, which gives

    J_G(s)f-J_H(s)f=-i integral_0^s U_G(s-u)V_lambda J_H(u)f du.

This derivation has no commuting hypothesis; the order V_lambda J_H is
fixed by the differential equation. The free primitive alone has a
weighted input. Its image after V_lambda need only be in the full Hilbert
space. Unitarity then gives

    ||(J_G-J_H)f||<=(2/3)K_R R sqrt(lambda)s^(3/2),
    ||J_G f||<=K_R R sqrt(lambda s)(1+2s/3).

Hilbert C1 gives r(s)-r0=integral_0^s r'(v)dv. The two-variable integrand
U_G(t-s)r'(v) is continuous on 0<=v<=s<=t, since G is bounded for fixed
lambda and r' is continuous. Its norm is integrably bounded. Bochner
Fubini, or ordinary Hilbert-norm Riemann sums, therefore gives exactly

    integral_0^t U_G(t-s)(r(s)-r0)ds
           =integral_0^t J_G(t-v)r'(v)dv.

Each individual r'(v) meets the weighted primitive hypotheses. Applying
the established norm estimate under this Hilbert integral gives
K_R R_dot sqrt(lambda)[(2/3)t^(3/2)+(4/15)t^(5/2)].
The 4/15 is (2/3)*(2/5). Together with the initial primitive comparison
and full e_lambda integral this gives

    ||D+iJ_H r0||<=sqrt(lambda)(A_L t^(3/2)+B_L t^(5/2))
                         +M lambda t(1+t),
    A_L=(2/3)K_R(R_init+R_dot)=6K_R M,
    B_L=(4/15)K_R R_dot=(8/5)K_R M.

## 5. Source coefficient and S dependency

S's full proof, rather than only its prior review label, was read. On the
even longitudinal space AA*=M_h^2-|h><h|; its source resolvent is
G=1-1/(zF_Y). The global zero atom has weight 1/I0 and is removed by Q.
The eight-cone pushforward gives rho_Y(s)=sqrt(s)a(s), a(0)=1/(4pi^2).
Its uniform local boundary values and denominator bounded away from zero
give the entire locally absolutely continuous source measure. The real
threshold remainder is O(s), and the squared modulus therefore differs
from I0^2 by O(s). Grading symmetry and the E^2 Jacobian give
rho_Qh0(E)=a(E^2)/|F_+(E^2)|^2=c_th+O(E^2), c_th=1/(4pi^2 I0^2).

The exact primitive multiplier is lambda(1-exp(-itE/lambda))/(iE).
The full-real-line squared sinc integral is 2pi; thus its constant-density
contribution is 2pi c_th |t|lambda. The local density remainder, constant
density tails and arbitrary remote spectral mass have the respective
absolute bounds 8C_rho e0 lambda^2, 8c_th lambda^2/e0,
4(6-1/I0)lambda^2/e0^2. These reproduce exactly S19 and the C_J copied
in L. Positivity 6I0>1 follows from strict Cauchy–Schwarz for h and 1/h.
No remote spectral classification is needed.

r0(kappa)=-c0 a(0,kappa)Qh0. Since H_* is independent of kappa, spectral
calculus factors the scalar amplitude, so

    | ||J_H(t)r0||^2-c_init^2 |t|lambda |<=C_init lambda^2,
    c_init=c0||a0||/(sqrt(2pi) I0), C_init=c0^2||a0||^2 C_J.

The exact nonnegative packet gives ||a0||>=m/(4Z0)>=m/(2sqrt(2)).
Together with I0<=pi sqrt(3)/8 this gives c_init>=
2c0m/(pi sqrt(3pi)), with no numeric I0 value or fiber normalization.
The newly completed S review is reusable at its stated unchanged identity;
L's frozen wording that it is pending is stale metadata only. This
reconstruction does not claim another fresh review of S's author evidence
or external spectral-theorem reference.

## 6. Lower and upper constants, finite lambda and quantifiers

For fixed positive t, division of the squared S19 estimate by lambda gives
||J_H r0||/sqrt(lambda)->c_init sqrt(t). The forcing-error term after
division by sqrt(lambda) tends to zero. Both triangle inequalities give
exactly L19. No actual-error limit is presupposed.

t0=min(1,c_init/[2(A_L+B_L)]) is strictly positive. For t<=t0,
A_L t+B_L t^2<=(A_L+B_L)t<=c_init/2. Its lower and upper liminf/limsup
bounds are therefore c_init sqrt(t)/2 and 3c_init sqrt(t)/2. Since
A_L+B_L=(38/5)K_R M and M=406c0m, the lower coefficient bound gives

    t0>=t_bar=5/[15428 pi sqrt(3pi)K_R]>0.

t_bar<1 follows immediately from the displayed positive constants.

At finite lambda, C_init lambda<=(15/64)c_init^2 t puts the free norm/
sqrt(lambda) in [7/8,sqrt(79)/8]c_init sqrt(t), contained in
[7/8,9/8]c_init sqrt(t). The third threshold in lambda_*(t) gives
M sqrt(lambda)t(1+t)<=c_init sqrt(t)/8. Add the perturbation/variation
budget c_init sqrt(t)/2 to get exactly [1/4,7/4]c_init sqrt(lambda t).
All three lambda_* entries are positive and finite for each fixed t>0.
C_init>0 follows from the explicit C_J and ||a0||>0.

The quantifiers are every 0<t<=t0, then every 0<lambda<=lambda_*(t), or
fixed t then lambda->0. The threshold shrinks near t=0; this is not a
uniform-in-t lower bound at one fixed lambda. Physical time is t/lambda.
The result determines order sqrt(lambda), not the actual coefficient,
H1 sharpness, a mean lower bound, a growing-time optimum, or covariance.

## Pre-author provisional assessment and independent control plan

No mathematical defect found in L1–L20. A separate exact rational-matrix
power-series control will test the noncommuting primitive identity, full
time-varying residual decomposition, exact actual-error ODE with e_lambda,
and physical centering. Unlike the author's stated direct-Pauli/augmented-
exponential arrangement, this uses rational longitudinal factorization and
formal coefficient recurrences. Finite controls check algebra only. The
continuum threshold and cone estimates remain analytic arguments.

Failures and corrections to reviewer controls will remain as full attempt
snapshots; author evidence will be opened only after the completed
reconstruction and successful control record are frozen and timestamped.
