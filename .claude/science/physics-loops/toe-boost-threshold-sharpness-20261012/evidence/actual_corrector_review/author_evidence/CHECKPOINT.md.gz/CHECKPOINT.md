# Actual small-time lower bound: current recovery checkpoint

Final source: ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md, 406 lines.
SHA-256: `972b66765f82346a9fb3a4171350b8136a4fb80671f99b4d35355d0388d09ef3`.
Author: boost_kernel_dynamics. Root proposed the mechanism and is a coauthor.
Deadline: 2026-10-12 16:00:52 UTC. No model/effort override or subdelegation.

## Completed result

L1-L20 are complete as a conditional author proof. The full actual X error
D_lambda=W_lambda-z has Theta(sqrt(lambda)) L2 norm at each fixed effective
time 0<t<=t0. Both limits and a finite-lambda sandwich are explicit:

    c_init sqrt(lambda t)/4 <= ||D_lambda(t)||
        <=7c_init sqrt(lambda t)/4,
    lambda<=lambda_*(t),  t<=t0.

The proof first establishes the free primitive bound for the physical
longitudinal weighted class, including s<=lambda, then compares primitives
with the ordered noncommuting V_lambda factor, uses the full source derivative
through a Hilbert-valued triangular integral, and retains e_lambda in the whole
physical space. The source-specific threshold input is precisely S19-S20.
The universal conservative interval t_bar is approximately 7.07734e-6;
its exact formula, all constants and the time-dependent lambda cutoff are in
the note. No actual fixed-time coefficient limit, H1 or mean lower bound,
or optimal growing-time exponent is claimed.

## Exact dependency/status boundary

source_manifest.json binds twelve original/copy source identities and read scope.
Q source: 4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820.
Q selective review: 6ccba5be389898bd97ce12e53bf767dd002a3e6f282afb3cb4e010f49d86ca2d.
S source: 6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da.
S remains provisional pending its separate independent review. This new
L1-L20 source also requires its own independent scientific check. There are
no remaining author proof obligations within that conditional statement.

## Evidence and preserved failures

AUTHOR_CHECK.md records distinct analytic arrangements, full cold reading,
physical domain/regularity checks and limitations. The actual_lower_controls.py
baseline passed 36 controls; seven unique one-replacement mutants each failed
at the intended assertion. Full sources, stdout/stderr and execution metadata
are preserved and were read. No failed baseline or changed tolerance is hidden.
The current baseline hash is
a9b5bd5986d3cd4752c1f8dabcb7157da240baa2f7424f11c75eae3d743b437b.

The coarse propagator O(t^2) comparison, invalid full inverse, uncentered
corrector, missing endpoint, wrong operator order, omitted Bz' and e_lambda,
and finite-mesh wrong continuum limit are preserved. No finite check proves
the continuum threshold or the actual asymptotic.

Prior Q/S/K receipt identities and all 194 bound artifacts match unchanged.
No prior source/evidence, Git, PR, audit, axiom or prompt file was changed.

## Next atomic step

Run freeze_receipt.py once, then verify_receipt.py with full post-freeze
logs/metadata. If receipt.json already exists and verification succeeds, this
packet is frozen and ready for root's separate independent review. Never
silently rewrite a frozen source or replace an execution log.
