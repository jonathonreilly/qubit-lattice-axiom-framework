# Prepared-state boost/current control for the supplied excluded Weyl pair

Date: 2026-10-11. External research derivation; no repository edits.

**Status:** proposed conditional mathematical result, with author finite-algebra
controls. This is not an independently reviewed result or a retained-status
audit. The supplied walk, continuous clock, antisymmetric pair sector, site
exclusion, spatial coordinates and canonical local-energy placement remain
premises. No new physical primitive, collision clock or gravity law is adopted.

The result is at the **prepared states** specified below. It does not assert
that their momentum or derivative bounds persist under the excluded evolution.

## 1. Result and exact source boundary

For the canonical energy dipole $D_a$, its actual bounded current $J_b$, and
the compressed Hamiltonian $H_D$, define on the common domain below

\[
 R_{ab}=-i[D_a,J_b]-\delta_{ab}H_D.
                                                        \tag{B1}
\]

The full bracket contains the first derivative

\[
 [H_D,J_b]\partial_{K_a}.
                                                        \tag{B2}
\]

It does not cancel. For globally normalized free packets with small individual
cone offsets, total momentum $|K|\le\lambda/4$, and

\[
 \lambda\|\partial_{K_a}\phi_\lambda\|\le B_a<\infty,
 \qquad \chi_\lambda={P\phi_\lambda\over\|P\phi_\lambda\|},
                                                        \tag{B3}
\]

the argument proves an explicit $O(\lambda^{3/2})=o(\lambda)$ **norm of the
residual applied to the state**. It is a uniform bound on this specified
preparation class with its scaled derivative norm, not an $L^2$-operator
bound obtained solely by imposing an energy window. An explicit smooth,
origin-cone, positive-positive free-band family below has $B_a<60$, and obeys

\[
 \|R_{ab}\chi_\lambda\|\le384\lambda^{3/2},\qquad
 \|[H_D,J_b]\chi_\lambda\|\le6\lambda^{5/2},\qquad
 {\lambda\over2}\le\langle\chi_\lambda,H_D\chi_\lambda\rangle
 \le3\lambda,
 \quad 0<\lambda\le1/16.                                \tag{B4}
\]

All nine $a,b$ components are covered. The constants are conservative.
The energy lower bound makes the comparison with $o(\lambda)$ nonvacuous.
A separate normalized mixed-band construction in Section 8 has small total
energy and total momentum, but has a nonzero order-$\lambda$ bracket residual.
It demonstrates why individual-momentum support is stated rather than inferred.

Load-bearing sources, all used at the following exact bytes:

| Source | SHA-256 | Use / reading coverage |
|---|---|---|
| `S/EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Complete 190-line source freshly read; canonical density, dipole, contact blocks and current, including their domain argument. |
| `WW/docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md` | `9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401` | Fresh reading of lines 1–175, 370–478 and 805–844: supplied symbol, normalized antisymmetric fibers, channel and corner distinctions, preparation caveat, complete canonical dipole derivation and corrected compression of the current. Earlier campaign reading is not counted as a fresh full-note review here. |
| `S/repo_sync_rc_2045/agents/RC_C3_report.md` | `c4ca747adf80fe0f4cb1e3218c3b47813c2923427fcf41df40b4474e471fe08d` | Complete 170-line report freshly reread; motivates the selected bracket, not a theorem for this interacting Weyl pair. |
| `S/repo_sync_rc_2045/agents/RC_C3_referee.md` | `06b603b76bf1ca0abba47f56a1e98a2993df7e8953e100d07232032461cd10e0` | Complete short referee freshly reread. |
| `S/repo_sync_rc_2045/agents/RC_C3_referee_full.md` | `7e7613191d08b98a5a2f21453da66c494d4a2afdc73a0f75acd49bc852db3354` | Complete 310-line referee freshly reread; regularity, single-scalar scope, improvements and multi-band limits retained. |

Here `S=/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and `WW=/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/walk_worktree`.
The RC copies are pinned to commit
`d009fb786d36a6cab4a7d410630b9382992faa08`; their containing manifest has SHA
`4bcc8fc339fafe9a42d2bc17ad67c23f3e55a21a35f13d740567ecaa41c44e57`.
They were byte-compared to that commit in the immediately preceding route
assessment. This derivation rehashes the copies and does not update that snapshot.

The published parent explicitly supplies the definitions used here; its
historical upstream walk source is `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`.
No result below relies on rereading all of that historical note in this task.
No new external literature theorem is invoked. The RC literature/numerical
claims are not independently reverified here or used to prove (B4).

## 2. Hilbert space, energy placement and common domain

Work in a small open total-momentum chart $U$ around zero. The relative torus
has measure $dq/(2\pi)^3$, total momentum has measure $dK/(2\pi)^3$, and the
spin space is $\mathbb C^2\otimes\mathbb C^2$. The antisymmetric fiber consists
of functions satisfying $\psi(K,-q)=-\mathsf S\psi(K,q)$, with spin swap
$\mathsf S$. The normalized constant singlet is $c$. Thus

\[
 C=|c\rangle\langle c|,\quad P=I-C,\quad
 H_0=h_1+h_2,\quad
 h_1=\sigma_1\cdot\sin(K/2+q),\quad
 h_2=\sigma_2\cdot\sin(K/2-q),\quad H_D=PH_0P.          \tag{B5}
\]

All fiber inner products below include normalized full-torus measure. $P$
is one global contact projection in each fiber, not eight corner projections.
On the full fiber $H_Dc=0$; its restriction to $P$ is the excluded walk.
The chart convention follows $k_1=K/2+q,k_2=K/2-q$. Compact $K$ support
avoids chart gluing; the full $q$ torus and the antisymmetric condition are
retained. No additional exchange normalization factor is used.

Here $\Pi_{i,x}$ projects particle $i$ onto site $x$, and $X_{i,a}$ is its
integer spatial coordinate. The local energy placement and first moment are
fixed as in the canonical source:

\[
 e_x^0={1\over2}\sum_{i=1}^2\{\Pi_{i,x},h_i\},\quad
 e_x=Pe_x^0P,\quad
 D_a=PD_{0,a}P,\quad
 D_{0,a}={1\over2}\bigl(\{X_{1,a},h_1\}+\{X_{2,a},h_2\}\bigr).
                                                        \tag{B6}
\]

These first moments agree with the spatial sums on finite-support states.
Take as the common invariant test domain the smooth antisymmetric sections,
compactly supported in $U$, smooth and periodic in $q$, and lying in $P$.
It is dense in the allowed direct integral over $U$. The compressed operators
$D_a,H_D,J_b$ preserve this test domain. The ambient operators $D_{0,a},H_0$
act on the corresponding smooth domain without the condition of lying in $P$;
they need not preserve $P$. Integration by parts has
no $K$ boundary term and no $q$ boundary term. The formulas extend to the
corresponding $H^1$ sections by approximation: $D_{0,a}:H^1\to L^2$ is
continuous, and $H_0,P,J_b$ preserve $H^1$. This also connects the chart
calculation to the finite-spatial-support definition. No essential
self-adjointness or exponentiation of the unbounded dipole is assumed.

Put $h=H_0c$, $h_a=\partial_{K_a}h$, and $H_\Delta=h_1-h_2$. Since

\[
 X_{1,a}=i(\partial_{K_a}+\tfrac12\partial_{q_a}),\qquad
 X_{2,a}=i(\partial_{K_a}-\tfrac12\partial_{q_a}),
\]

symmetrization, including $\partial_{q_a}H_\Delta=2\partial_{K_a}H_0$, gives

\[
 D_a=i(H_D\partial_{K_a}+L_a),\qquad
 L_a=P\left(\tfrac12 H_\Delta\partial_{q_a}
                         +\partial_{K_a}H_0\right)P,
 \quad
 L_a^\dagger=-P\tfrac12H_\Delta\partial_{q_a}P.          \tag{B7}
\]

The dagger in (B7) is the **fiber** adjoint in $q$, with $K$ held fixed.
In particular $L_a+L_a^\dagger=\partial_{K_a}H_D$, which also checks symmetry
of $i(H_D\partial_{K_a}+L_a)$ after integration in $K$.

For clarity, the parent contact calculation is reproduced. The $q$ part of

\[
 D_{0,a}=iH_0\partial_{K_a}
        +\tfrac i2H_\Delta\partial_{q_a}+i\partial_{K_a}H_0
\]

has fiber adjoint $\tfrac i2H_\Delta\partial_{q_a}$, which annihilates $c$.
Its value on $c$ is $ih_a$. Since $\langle c,H_0c\rangle=0$, the blocks are

\[
 CD_{0,a}P\psi=ic\langle h,\partial_{K_a}\psi\rangle,
 \qquad PD_{0,a}C(cf)=i\partial_{K_a}(hf).               \tag{B8}
\]

The free identity $i[H_0,D_{0,a}]=g_a$ uses

\[
 g_a=\sum_i\sin k_{i,a}\cos k_{i,a}
     =\sin K_a\cos(2q_a).
\]

The two derivative terms in the compressed Hamiltonian/dipole commutator
cancel, leaving the actual current

\[
 J_a=i[H_D,D_a]=Pg_aP+F_a,\qquad
 F_a=-|h_a\rangle\langle h|-|h\rangle\langle h_a|.       \tag{B9}
\]

Both form factors lie in $P$. $g_a+F_a$ itself need not preserve $P$;
the operator on the excluded space is its compression, as displayed in (B9).

## 3. Complete bracket, including the Hamiltonian/current defect

Define

\[
 r_b=g_bc,\quad r_{b,a}=\partial_{K_a}r_b,\quad
 h_{ab}=\partial_{K_a}h_b,\quad
 \ell_a=h_1\cos(2k_{1,a})+h_2\cos(2k_{2,a}).            \tag{B10}
\]

$r_b,r_{b,a},h,h_a,h_{ab}$ all lie in $P$. The free scalar multiplier
commutator is

\[
 -i[D_{0,a},g_b]=\delta_{ab}\ell_a.                    \tag{B11}
\]

Indeed only the derivatives of $g_b$ contribute; in individual momenta

\[
 \sum_{i=1}^2 h_i\partial_{k_{i,a}}
       \sum_j\sin k_{j,b}\cos k_{j,b}
 =\delta_{ab}\sum_i h_i\cos(2k_{i,a}).
\]

The exact bounded Hamiltonian/current defect, of finite rank in each relative
fiber, is

\[
\begin{split}
 A_b:=[H_D,J_b]={}&-|h\rangle\langle r_b|+|r_b\rangle\langle h|\\
 &-|H_Dh_b\rangle\langle h|-|H_Dh\rangle\langle h_b|\\
 &+|h_b\rangle\langle H_Dh|+|h\rangle\langle H_Dh_b|.
\end{split}                                                    \tag{B12}
\]

The first line is $[PH_0P,Pg_bP]$, since $H_0$ commutes with the scalar
$g_b$; the last two lines are $[H_D,F_b]$. In particular no conservation
of the canonical current has been inserted.

Write

\[
 F_{b,a}=-|h_{ab}\rangle\langle h|-|h_b\rangle\langle h_a|
         -|h_a\rangle\langle h_b|-|h\rangle\langle h_{ab}|,
\]

and define the following bounded operator of finite rank in each relative fiber:

\[
\begin{split}
 B_{ab}={}&-|h_a\rangle\langle r_b|-|h\rangle\langle r_{b,a}|
                +H_DF_{b,a}\\
 &-|L_ah_b\rangle\langle h|-|L_ah\rangle\langle h_b|\\
 &+|h_b\rangle\langle L_a^\dagger h|
                 +|h\rangle\langle L_a^\dagger h_b|.
\end{split}                                                    \tag{B13}
\]

Here $L_a$ and $L_a^\dagger$ act only on the explicitly given smooth
form factors. Thus (B13) contains no hidden differentiation of the input state.
The complete identity is

\[
 -i[D_a,J_b]\psi
   =\delta_{ab}P\ell_aP\psi+A_b\partial_{K_a}\psi+B_{ab}\psi.
                                                               \tag{B14}
\]

To check every contact term, first expand the compressed scalar-current part
using (B8):

\[
 -i[D_a,Pg_bP]\psi
 =\delta_{ab}P\ell_aP\psi
   -\partial_{K_a}\bigl(h\langle r_b,\psi\rangle\bigr)
   +r_b\langle h,\partial_{K_a}\psi\rangle.              \tag{B15}
\]

Its derivative coefficient is $-|h\rangle\langle r_b|+|r_b\rangle\langle h|$;
its constant contact terms are the first two terms of (B13). From (B7), the
remaining part is exactly

\[
 -i[D_a,F_b]=[H_D,F_b]\partial_{K_a}
                  +H_DF_{b,a}+[L_a,F_b].                \tag{B16}
\]

Inserting the rank-two $F_b$ into $[L_a,F_b]$, and integrating its right
action in $q$, gives the last four terms of (B13), with the fiber adjoint
and signs shown there. This proves (B14) without dropping differential terms.

## 4. The differential coefficient is nonzero

There is also an analytic witness, independent of any low-momentum
approximation. Let $K$ have only its $b$ component nonzero and let $j,k$
be the other two axes. Put $C_b=\cos(K_b/2)$, $S_b=\sin(K_b/2)$. Singlet
algebra gives

\[
 \|h\|^2=N=2(C_b^2+2),\quad
 \langle h_b,h\rangle=-\tfrac12\sin K_b,\quad
 H_Dh_b=\tfrac12 r_b,\quad \langle h,H_Dh\rangle=0.
                                                               \tag{B17}
\]

For the third identity, the total-spin term along $b$ annihilates
$\sigma_{1,b}c$, while the difference-spin term gives
$H_0h_b=-\sin K_b\sin^2q_b\,c$; removing its mean gives $r_b/2$.
For the last identity put $h_i^2=\epsilon_i^2 I$ and use
$H_0^3=(\epsilon_1^2+3\epsilon_2^2)h_1+(3\epsilon_1^2+\epsilon_2^2)h_2$, whose singlet expectation
vanishes pointwise. Since $h,r_b$ are pointwise triplet and singlet,
respectively, inserting (B17) into (B12) yields

\[
 A_bh=\tfrac N2r_b+\tfrac12\sin K_b\,H_Dh,
\]

and its pointwise singlet component is

\[
 c^*A_bh(q)=2\sin K_b
     \bigl(\sin^2q_j+\sin^2q_k-2\sin^2q_b\bigr).
                                                               \tag{B18}
\]

The normalized-torus squared norm of this component is $3\sin^2K_b$: the
three independent variables $\sin^2q_i$ have mean $1/2$ and variance $1/8$.
Thus $A_bh\ne0$ for nonzero sufficiently small $K_b$, as well as generically.

Consequently (B14) is not globally a bounded $L^2$ operator, even after a
small total-momentum cutoff alone. Localize a smooth section proportional to
$h(K,q)$ near a nonzero such fiber and multiply it by $e^{iM K_a}$.
Its norm and momentum support are unchanged, while the right side of (B14)
acquires $iM A_b\psi$. This is a statement about that unrestricted
relative-momentum class. This witness is not a positive-band preparation, and
does not establish an impossibility result for every restricted band norm.
It establishes that removing (B2) algebraically would be incorrect.

## 5. Uniform constants for localized free inputs

Assume $0<\lambda\le1/16$, $|K|\le\lambda/4$, and let a free input be
supported in a union of $m\le8$ relative corner balls

\[
 \Omega_\lambda=\bigcup_{C_j\in\mathcal C}
        \{q=C_j+x:\ |x|\le3\lambda/4\},\qquad
 \mathcal C\subset\{0,\pi\}^3.
\]

The balls are disjoint in the torus. Their normalized measure satisfies

\[
 \mu(\Omega_\lambda)\le\nu_m^2\lambda^3,
 \quad \nu_m=\sqrt{9m/(128\pi^2)},
 \quad \nu_m\le\nu:=3/(4\pi)<1/4.                    \tag{B19}
\]

The estimates below apply to any smooth input with this support; positivity
and a free energy window will be imposed in Section 7. A $K$ derivative of
a smooth supported section has the same support. The exact form factors are

\[
 h(q)=2\sum_j\cos(K_j/2)\sin q_j\,\sigma_{1,j}c,
 \quad h_b(q)=-\sin(K_b/2)\sin q_b\,\sigma_{1,b}c.
                                                               \tag{B20}
\]

The following bounds use the **full torus**, including the part outside
$\Omega_\lambda$. They hold uniformly on the stated $K$ support:

| Form factor / operator | Bound used |
|---|---|
| $H_0,H_\Delta,H_D$ | operator norm at most $4$ |
| $\partial_{K_a}H_0$ | operator norm at most $1$ |
| $h$ | $\|h\|_2\le3, \|h\|_\infty\le4, \|\partial_{q_a}h\|_2,\|\partial_{q_a}h\|_\infty\le2$ |
| $h_a,h_b$ | $L^2,L^\infty$ norms at most $\lambda/8$ |
| $\partial_{q_a}h_b$ | $L^2,L^\infty$ norms at most $\lambda/8$ (zero if $a\ne b$) |
| $h_{ab}$ | $L^2,L^\infty$ norms at most $1/2$ (zero if $a\ne b$) |
| $r_b,r_{b,a}$ | $\|r_b\|_2,\|r_b\|_\infty\le\lambda/4, \|r_{b,a}\|_\infty\le1$ |
| $H_Dh$ | $\|H_Dh\|_2\le12, \|H_Dh\|_\infty\le22$ |
| $H_Dh_b$ | $\|H_Dh_b\|_2\le\lambda/2, \|H_Dh_b\|_\infty\le7\lambda/8$ |
| $L_ah,L_ah_b$ | $L^2$ norms at most $7,3\lambda/8$ |
| $L_a^\dagger h,L_a^\dagger h_b$ | $L^\infty$ norms at most $8,\lambda/2$ |

For example, $H_Dh=H_0h-c\|h\|^2$ and
$H_Dh_b=H_0h_b-c\langle h,h_b\rangle$; these subtractions are included in
the $22$ and $7\lambda/8$ bounds. For $L_a^\dagger$, first bound
$H_\Delta\partial_{q_a}u/2$ and then its constant projection by the same
supremum bound. This accounts for the factor two in $8,\lambda/2$.

For a supported fiber input $f$, each rank-one term satisfies

\[
 \||u\rangle\langle v|f\|_2
 \le\|u\|_2\|v\|_\infty\nu_m\lambda^{3/2}\|f\|_2.
\]

Summing (B12), the coefficient of $\lambda$ is bounded by

\[
 (3/4+1)+(2+3/2+11/4+21/8)=85/8<12.
\]

In (B13), the corresponding coefficient is bounded by

\[
 3+\lambda^2/32+(14+\lambda^2/8)
       +(3/2+7/8+1+3/2)\lambda
 =17+39\lambda/8+5\lambda^2/32<24.
\]

Thus, also after integrating in $K$,

\[
 \|A_b f\|\le12\nu_m\lambda^{5/2}\|f\|,
 \qquad
 \|B_{ab}f\|\le24\nu_m\lambda^{3/2}\|f\|.             \tag{B21}
\]

Only the volume of the input support was used in (B21); its location in corner
balls is used next for the free multiplier. This distinction is useful for
the counterexample in Section 8.

## 6. Global contact projection and the prepared-state theorem

Let $\|\phi_\lambda\|=1$, with the support and regularity just specified. Put

\[
 \eta=\nu_m\lambda^{3/2},\quad
 \alpha(K)=\langle c,\phi_\lambda(K)\rangle,\quad
 n_\lambda=\|P\phi_\lambda\|.
\]

Cauchy–Schwarz in the full torus gives

\[
 \|C\phi_\lambda\|\le\eta,
 \quad n_\lambda^2=1-\|\alpha\|_{L^2_K}^2\ge1-\eta^2,
 \quad
 \chi_\lambda={\phi_\lambda-c\alpha\over n_\lambda}.
                                                               \tag{B22}
\]

This is a single global normalization over $K,q$. It is not fiberwise
renormalization and does not assume that the $K$ probability law is unchanged.
The subtracted $c\alpha$ has support on the **entire** relative torus.
The physical state is therefore not exactly free-band or corner supported.

All form factors in (B12)–(B13) lie in $P$. Hence

\[
 A_b\partial_{K_a}\chi_\lambda
     ={A_b\partial_{K_a}\phi_\lambda\over n_\lambda},
 \qquad B_{ab}\chi_\lambda={B_{ab}\phi_\lambda\over n_\lambda}.
\]

There is no derivative of $n_\lambda$ with respect to $K$: it is the one
global scalar in (B22). For the multiplier defect let $M_a=\ell_a-H_0$.
On every retained corner ball, each individual $k_i$ is within $7\lambda/8$
of the corresponding corner. Consequently

\[
 \|M_a\phi_\lambda\|\le4\lambda^3,
 \qquad\|M_a\|\le8,
 \qquad
 \|PM_aP\phi_\lambda\|\le4\lambda^3+8\eta.             \tag{B23}
\]

The first inequality uses $\|h_i\|\le\lambda$ on the support and
$|\cos(2k_{i,a})-1|\le2\lambda^2$; the global bound uses
$2\|h_1\|+2\|h_2\|\le4\sqrt3<8$. The last $8\eta$ explicitly bounds
the global contact tail instead of pretending that $P$ preserves the band.

Combining (B14), (B21) and (B23) proves, with
$B_a=\lambda\|\partial_{K_a}\phi_\lambda\|$,

\[
 \boxed{\quad
 \|R_{ab}\chi_\lambda\|
 \le {4\lambda^3+\nu_m(32+12B_a)\lambda^{3/2}
                  \over\sqrt{1-\nu_m^2\lambda^3}},\qquad
 \|[H_D,J_b]\chi_\lambda\|
 \le {12\nu_m\lambda^{5/2}\over\sqrt{1-\nu_m^2\lambda^3}}.
 \quad}                                                       \tag{B24}
\]

For $a\ne b$, the $4\lambda^3+8\eta$ multiplier contribution can be
omitted. The displayed uniform form is enough for all components. It also
bounds every normalized test-vector matrix element of the residual, by
Cauchy–Schwarz. It does not furnish an $L^2$-operator bound on states whose
scaled $K$ derivatives are unrestricted.

All eight corner signs are covered: writing $q=C_j+x$ replaces $\sin x$
by $\operatorname{diag}(\pm1)\sin x$ in the one-body symbols but leaves
their norms and $\cos(2k_{i,a})$ estimates unchanged. The contact amplitudes
from different corners add coherently in the **same** $\alpha(K)$.
Using the measure of their union in (B19) bounds that interference without
an incoherent-sum assumption. At the origin this is literal small individual
momentum; at the other seven corners it is small **offset** from a different
cone. Distinct-corner pairs with total momentum near another total corner
are outside the selected $K$ chart. They are not identified with $K=0$.

## 7. A specified smooth, normalizable low-individual-momentum preparation

Here only the origin corner is populated before projection. Let $F,f$ be
fixed smooth functions of Euclidean variables $\kappa,x$, normalized with
Lebesgue $L^2$ norms one, with

\[
 \operatorname{supp}F\subset\{|\kappa|<1/4\},\qquad
 \operatorname{supp}f\subset\{5/8<|x|<3/4\},\qquad f(-x)=f(x).
\]

For a specific $f$, take the positive normalization of
$\exp[-1/((|x|-5/8)(3/4-|x|))]$ on that annulus and zero outside.
For a specific $F$ with an explicit derivative bound, set
$p(t)=(1-t^2)^2$ for $|t|<1$, zero otherwise, and let $F_0$ be the
normalized product of $p(8\sqrt3\,\kappa_j)$. Direct integration gives

\[
 \int p^2=256/315,\quad \int(p')^2=256/105,\quad
 \|F_0\|_2=1,\quad\|\partial_{\kappa_a}F_0\|_2=24,
 \quad\operatorname{supp}F_0\subset\{|\kappa|\le1/8\}.
\]

Convolve $F_0$ with the positive, normalized $C^\infty$ radial mollifier
proportional to $\exp[-1/(1-512^2|y|^2)]$ on $|y|<1/512$, zero otherwise,
and normalize the result in $L^2$. Translation in $H^1$ and Minkowski give

\[
 \|\eta_{1/512}*F_0-F_0\|_2\le24\sqrt3/512<1/8,
 \quad\|\partial_{\kappa_a}F\|_2\le192/7,
 \quad\operatorname{supp}F\subset\{|\kappa|\le65/512<1/4\}.
                                                               \tag{B25}
\]

The temporary $\eta_{1/512}$ denotes this mollifier, not the contact bound
$\eta$ in (B22). This construction is smooth; the intermediate polynomial
is used only to supply its derivative constant.

Let $\Pi_{++}(K,q)$ be the product of the two positive one-body projectors,
and define

\[
 u_\lambda(K,q)=(2\pi)^3\lambda^{-3}
           F(K/\lambda)f(q/\lambda)\Pi_{++}(K,q)c,
 \quad Z_\lambda=\|u_\lambda\|,
 \quad\phi_\lambda=u_\lambda/Z_\lambda.                 \tag{B26}
\]

The factor $(2\pi)^3\lambda^{-3}$ compensates both normalized torus
measures and both three-dimensional changes of variables. This is a genuine
normalizable direct-integral packet, not a fixed $K$ fiber or a direction delta.
The even relative envelope and $\mathsf S c=-c$ give the required
antisymmetry. On its support

\[
 \lambda/2\le|q\pm K/2|\le7\lambda/8,
 \quad A=|\sin(q+K/2)|,\ B=|\sin(q-K/2)|\ge3\lambda/8.
\]

For these small arguments $\epsilon(y)\ge(7/8)|y|$. Thus

\[
 \lambda<35\lambda/32\le A+B\le7\lambda/4<2\lambda.
                                                               \tag{B27}
\]

There is no mixed-band cancellation in (B27): the free packet uses only the
positive-positive projector and both individual energies are small. Also

\[
 w_\lambda=\|\Pi_{++}c\|^2
 ={1+\sin(q+K/2)\cdot\sin(q-K/2)/(AB)\over4}
 \in[1/4,1/2].
\]

The positivity follows from the exact numerator identity
$\sin(q+K/2)\cdot\sin(q-K/2)=\epsilon(q)^2-\epsilon(K/2)^2>0$.
Consequently

\[
 Z_\lambda^2=\int |F(\kappa)|^2|f(x)|^2w_\lambda\,d\kappa\,dx
 \in[1/4,1/2].                                           \tag{B28}
\]

For one positive Pauli projector,
$\|\partial_{K_a}\Pi_+\|\le1/(4A)$, and similarly with $B$. Therefore

\[
 \lambda\|\partial_{K_a}\Pi_{++}\|\le4/3,
 \quad
 \lambda\|\partial_{K_a}\phi_\lambda\|
 \le2\|\partial_{\kappa_a}F\|_2+8/3
 \le384/7+8/3<60.                                       \tag{B29}
\]

All $q$ derivatives exist and are square integrable for each $\lambda>0$,
so the packet belongs to the common domain. No uniform $q$-derivative bound
is needed in (B24), because the exact normal ordering has removed derivatives
of the input in $q$. Both global normalization constants $Z_\lambda,n_\lambda$
are scalars depending on $\lambda$, not functions differentiated in $K$.

Using $\nu_m\le1/4$, $n_\lambda\ge1/2$, (B29), and
$\lambda^3\le\lambda^{3/2}$, (B24) gives the first two bounds of (B4).
For the energy bound, $\langle c,H_0c\rangle=0$, (B27), and support-volume
Cauchy–Schwarz give

\[
 \|CH_0\phi_\lambda\|\le2\lambda\eta,
 \quad
 {\lambda-4\lambda\eta^2\over n_\lambda^2}
 \le\langle\chi_\lambda,H_D\chi_\lambda\rangle
 \le{2\lambda+4\lambda\eta^2\over n_\lambda^2}.
                                                               \tag{B30}
\]

Since $\eta^2\le\lambda^3/16$, these lie inside $[\lambda/2,3\lambda]$
on the stated range. This completes the prepared-state construction.

## 8. A restricted failure: small total energy is not enough

At $q_0=(\pi/4,0,0)$, $K=(t,0,0)$, take the free $(+,-)$ band. Its
individual energies tend to $1/\sqrt2$, while its total energy and the
free $x,x$ multiplier defect are exactly

\[
 E(t)=\sqrt2\sin(t/2),\qquad
 (\ell_x-H_0)_{+,-}
 =-\sqrt2\sin t\cos(t/2)-\sqrt2\sin(t/2).
\]

Thus the defect divided by $t$ tends to $-3/\sqrt2$, and divided by the
small total energy tends to $-3$. A point in momentum space is not a
normalizable counterexample; the following packets give one.

Choose fixed smooth normalized envelopes $F_*(\kappa)$ in the ball of radius
$1/64$ about $(1/8,0,0)$, and $f_*(x)$ in a ball of radius $1/64$.
For example the positive normalized standard radial bumps used above, after
these translations and dilations, suffice. Let
$\tau=|+x\rangle\otimes|+x\rangle$. On the patch $q=q_0+\lambda x$, set

\[
 v_\lambda=Z_*^{-1}(2\pi)^3\lambda^{-3}
       F_*(K/\lambda)f_*((q-q_0)/\lambda)\Pi_{+,-}(K,q)\tau.
\]

Here $Z_*$ is the global norm of the numerator in this definition, so
$\|v_\lambda\|=1$. The individual bands are uniformly separated
from zero on this patch, $\Pi_{+,-}\tau\to\tau$ uniformly, and $Z_*\to1$.
The two patches near $q_0,-q_0$ are disjoint. Hence

\[
 \phi^*_\lambda(K,q)
 ={v_\lambda(K,q)-\mathsf S v_\lambda(K,-q)\over\sqrt2}
\]

is exactly normalized and antisymmetric. Exchange changes $(+,-)$ to $(-,+)$
on the second patch and preserves the same energy. Its $K$ support obeys
$|K|<\lambda/4$, its relative support has volume $O(\lambda^3)$, and
$\lambda\|\partial_K\phi^*_\lambda\|$ is bounded. Prepare the actual
allowed state $\chi^*_\lambda=P\phi^*_\lambda/\|P\phi^*_\lambda\|$.

Uniform Taylor expansion on these fixed scaled supports gives

\[
 E(K,q)/\lambda\to\kappa_x/\sqrt2,
 \qquad
 (\ell_x-H_0)_{+,-}(K,q)/\lambda\to-3\kappa_x/\sqrt2.
                                                               \tag{B31}
\]

For instance at general nearby $q$, the first-order coefficient is
\[
 (\cos2q_x-1)\kappa\cdot\nabla\epsilon(q)
 -2\kappa_x\sin2q_x\epsilon(q).
\]
It tends to the displayed value at $q_0$. The two-patch limit is the same
by exchange.

The finite-rank estimates in (B21) used only support volume and the same
small-$K$ bounds, so their contribution is still $O(\lambda^{3/2})$.
The global contact-tail multiplier contribution is also $O(\lambda^{3/2})$.
Removing the outer contact projection from $M_x\phi^*_\lambda$ costs only
$O(\lambda^{5/2})$, because $M_x\phi^*_\lambda=O(\lambda)$ with the same
small support. Thus this normalized, globally projected family satisfies

\[
 \lim_{\lambda\downarrow0}{\|R_{xx}\chi^*_\lambda\|\over\lambda}
 ={3\over\sqrt2}
     \left(\int\kappa_x^2|F_*(\kappa)|^2d\kappa\right)^{1/2}>0,
 \quad
 {\langle\chi^*_\lambda,H_D\chi^*_\lambda\rangle\over\lambda}
 \longrightarrow{1\over\sqrt2}\int\kappa_x|F_*|^2d\kappa>0.
                                                               \tag{B32}
\]

For the energy expectation, the same support argument bounds the projection
correction by $O(\lambda^4)$; the packet's free total energy is $O(\lambda)$.
This construction is outside the $(+,+)$, low-individual-momentum preparation
in Section 7 and outside the central timelike shell condition $E>|K|$.
It does not refute that theorem or supply a general obstruction for other
preparations. It refutes the replacement of its actual premises by “small
total energy and small total momentum.”

## 9. Finite evidence, provenance and remaining obligations

`boost_current/exact_controls.py` builds three-dimensional relative Fourier
polynomials with all four spin entries and quadratic $K$-Taylor jets, using
exact Gaussian rational arithmetic. Its left side forms $D_0$ directly from
the four terms $X_ih_i,h_iX_i$ in (B6), then takes the nested compressed
commutators. Its right side uses (B12)–(B14). All nine components agree exactly;
the three current identities and three $A_b$ identities also agree. A finite
polynomial has the exact nonzero $A_0$ norm squared
$8619295744/75418890625$. The remaining controls check the rational constants,
the envelope integrals and the mixed-channel leading symbol. The first full
execution exited zero with 23 assertion families; its complete output is
`boost_current/first_run.log`.

The separate `boost_current/axis_witness_control.py` uses $4\times4$ Pauli
matrices and exact circle moments, without that Fourier/jet implementation.
It checks the six identities supporting (B17)–(B18), including the exact
singlet-component squared norm $3\sin^2K_b$. Its first execution exited zero;
the complete output is `boost_current/axis_witness.log`. These distinct
calculational representations help detect normalization and sign errors.
Both are this derivation author's controls, not independent scientific review,
and neither proves the support estimates or the asymptotic packet claims by
numerics. Those arguments are given above. No numerical continuum extrapolation
is substituted for them.

A preliminary tool experiment found that the installed exact
`GaussianRational` type has no `.conjugate()` method; the helpers therefore
form conjugates from its real/imaginary rational fields. That setup error
preceded the saved helpers. No scientific failed run or counterexample was
discarded: the first full saved runs both succeeded, and the mixed-band and
unbounded differential-coefficient limitations are retained explicitly.

Exact note/helper/log/source identities and first-run outcomes are recorded
in `boost_current/receipt.json`; `boost_current/checkpoint.json` is the current
recovery pointer. The source files named in Section 1 remain unchanged.

The result addresses one necessary boost/current comparison, not the full
Poincaré or hypersurface-deformation algebra. RC C3's exact regular local
single-scalar obstruction is not being transplanted to this two-record,
spinful, interacting model, nor is its converse being inferred from (B24).
Interband terms, contact corrections and the derivative term have actually
been computed here. Rotational/dipole commutators, gravitational constraints,
density-improvement freedom and an exact closing algebra remain outside this
calculation.

In particular, the current estimate from the earlier walk sources does not
control the unbounded dipole. To extend (B24) to the actual states
$e^{-itH_D}\chi_\lambda$, one must control their differentiated $K$ profiles
and their form-factor overlaps, including any dressing outside the initial
free support. An undifferentiated small state-norm error does not provide
that information; $[H_D,J_b]\partial_{K_a}$ in (B14) can magnify a derivative
error. No fixed-time or growing-time stability of this preparation class,
boost drift bound, new native law, or exact GR conclusion follows from the
prepared-state theorem alone.
