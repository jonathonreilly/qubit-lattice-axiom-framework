# Growing-time boost/current control for the prepared excluded walk

2026-10-11. Root-authored conditional extension, pending selective independent
review. No repository, physical axiom, or audit-status change.

## Exact premise and claim

The premise is the complete 744-line
`EXCLUDED_WALK_BOOST_CURRENT_PROBE.md`, SHA-256
`903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923`.
Root read and reconstructed its whole argument, all 319 lines of the Fourier
control, the separate 74-line Pauli control, and both full logs. Its exact
normal form and preparation are used here; this is not a claim that its
author controls independently certify the premise. The canonical parent
source and original source revisions remain those pinned in that probe.

Use its common smooth domain, fixed contact projection P, H=PH0P,
A_b=[H,J_b], B_ab, and

    R_ab = -i[D_a,J_b] - delta_ab H
         = delta_ab P M_a P + A_b partial_Ka + B_ab,
    M_a = ell_a-H0.                                      (E1)

The section-7 free packet phi_lambda is globally normalized, supported at
|K|<=lambda/4 and in the origin relative cone, and has

    B_a := lambda ||partial_Ka phi_lambda|| < 60.

Set n=||P phi_lambda||, chi=P phi_lambda/n and
psi(t)=exp(-itH)chi. The norm n is one scalar over the entire direct integral.
For 0<lambda<=1/16, all t>=0 and every a,b, the proposed extension is

    ||R_ab psi(t)|| <= lambda^(3/2) (384+1129 t+18 lambda t^2),  (E2)
    ||[H,J_b]psi(t)|| <= lambda^(5/2) (6+18t).                  (E3)

In particular, for each fixed 0<=gamma<1/2,

    sup_{0<=t<=lambda^(-gamma)} ||R_ab psi(t)||
        <=1536 lambda^(3/2-gamma)=o(lambda).                    (E4)

The actual energy stays in [lambda/2,3lambda] by conservation. The comparison
with the energy scale remains nonvacuous during this growing physical-time
interval. This proves control on the evolved states themselves if the
explicit proof below checks; it does not claim that they remain corner
supported or have the same derivative norm as the initial free packet.

## Uniform operator and propagator estimates

All operations preserve the small K support. On that support the premise's
form-factor table also gives, without a relative-momentum support assumption,

    ||A_b|| <=12 lambda,  ||B_ab|| <=24,  ||M_a|| <=8.           (E5)

Indeed apply ||u><v||<=||u||_2||v||_2 and use ||v||_2<=||v||_infinity
for the normalized torus. The same term sums in B12/B13 are respectively
(85/8)lambda<12lambda and
17+(39/8)lambda+(5/32)lambda^2<24. The original supported-input estimates
are stronger by the support-volume factor; (E5) does not use that factor.
Consequently, for any allowed H1 section w on the K chart,

    ||R_ab w|| <=32||w||+12lambda||partial_Ka w||.              (E6)

The fixed P is K-independent. Thus ||partial_Ka H||<=1, since each of the
two free one-body derivatives has norm at most 1/2. For U(t,K)=exp(-itH(K)),
the bounded-operator Duhamel derivative gives

    partial_Ka U(t)=-i integral_0^t U(t-s)(partial_Ka H)U(s) ds,
    ||partial_Ka U(t)||<=t.                                  (E7)

The same estimate holds for U0(t)=exp(-itH0). It is valid fiberwise uniformly
in K, and then on the direct integral. Differentiating smooth sections gives
||partial_Ka(U0(t)phi)||<=||partial_Ka phi||+t||phi||.

There is no unproved dipole-domain propagation hidden here. Multiplication
by H0 and the fixed projection P preserve smooth sections compactly supported
in K and periodic in q. Their commutators with each q derivative, and their
K derivatives, are bounded on L2, with bounded higher derivatives. Duhamel
and iteration therefore preserve each finite Sobolev order for each finite
t. Equivalently one may first work on smooth sections and use the H1 bound
to extend (E1). No self-adjoint extension or exponentiation of D is used.

## A comparison retaining the contact forcing

Let eta=nu_m lambda^(3/2), with the source's nu_m<=1/4. Define

    f(t)=U0(t)phi_lambda,
    alpha(t,K)=<c,f(t,K)>,
    v(t)=P f(t)/n,
    w(t)=psi(t)-v(t).                                       (E8)

The free evolution preserves the relative support and the global norm of
phi. The projected comparison v need not have unit norm at later times;
we retain the same initial scalar n everywhere. Full-torus Cauchy-Schwarz
and (E7) give

    ||alpha(s)||_{L2_K}<=eta,
    ||partial_Ka alpha(s)||_{L2_K}<=eta(B_a/lambda+s).          (E9)

In the second bound partial_Ka f has the same support as f. The contact
coefficient is a bounded linear functional on each relative fiber, so the
derivative commutes with its integral. Smooth compact support justifies the
calculation; approximation then gives the corresponding H1 statement.

Since h=H0 c and PH0C f=h alpha, direct differentiation gives

    i partial_t v=H v+h alpha/n,
    w(0)=0,
    w(t)= i/n integral_0^t U(t-s)h alpha(s) ds.                (E10)

This sign can be checked from i partial_t(psi-v)=H(psi-v)-h alpha/n.
The norm estimates do not discard the forcing or suppose the projected
comparison solves the interacting equation.

Using ||h||<=3 and ||partial_Ka h||<=lambda/8,

    ||w(t)||<=3 eta t/n,                                    (E11)
    ||partial_Ka w(t)||
       <= eta/n (3t^2+3B_a t/lambda+lambda t/8).              (E12)

For (E12), differentiate all three factors U(t-s), h, alpha(s).
Their integrated bounds are respectively 3eta t^2/2,
lambda eta t/8, and 3eta(B_a t/lambda+t^2/2), divided by n.
This is explicit derivative control, not an inference from the small
undifferentiated error (E11).

## Applying the full bracket to the evolved state

For the free comparison f(t), the scaled derivative bound is
B_a+lambda t. Repeating B21-B24 of the premise without changing the
normalizing denominator to ||P f(t)|| yields

    ||R_ab v(t)||
       <=[4lambda^3+eta(32+12B_a+12lambda t)]/n.              (E13)

In detail A and B annihilate c, as do their relevant right form factors,
so their input can be f(t) or its K derivative. The multiplier term must
retain the global contact tail and is bounded by 4lambda^3+8eta.
No actual-evolution support restriction is imposed on w.

Combining (E6), (E11)-(E13) gives the more general explicit bound

    ||R_ab psi(t)|| <= 1/n [4lambda^3 + eta {
       32+12B_a+(96+36B_a+12lambda+(3/2)lambda^2)t
       +36lambda t^2 }].                                   (E14)

Use n>=1/2, eta<=lambda^(3/2)/4, B_a<=60, and lambda<=1/16.
The constant term is at most (8+376)lambda^(3/2); the linear coefficient
inside the braces is less than 2257, hence its contribution is at most
1129t lambda^(3/2). The quadratic contribution is 18lambda t^2 lambda^(3/2).
This proves (E2). For t<=lambda^(-gamma), gamma<=1/2, lambda t<=1,
so 18lambda t^2<=18t and 384+1147t<=1531lambda^(-gamma).
The relaxed integer 1536 gives (E4); strict gamma<1/2 makes it o(lambda).
At gamma=1/2 this argument gives only O(lambda), not the little-o conclusion.

For the bounded current commutator, the supported-input bound and (E5)
instead give

    ||A_b psi(t)|| <=12nu_m lambda^(5/2)/n
                     +12lambda(3eta t/n),                   (E15)

which proves (E3). A consequence for the same actual evolving state is

    |<J_b>_{psi(t)}-<J_b>_chi|
         <=lambda^(5/2)(6t+9t^2).                           (E16)

Here d<J_b>/dt=i<[H,J_b]> follows for bounded H and J_b, and integration
uses (E3) with the evolving unit vector. This is a bound on the canonical
current already identified by the source, not a new momentum definition.

## Limits and next check

The supplied excluded walk, its clock, physical projection, canonical energy
placement, smooth positive-positive origin-cone preparation, and scaled
derivative bound remain premises. The result controls one boost/current
bracket and its actual finite-time evolution; it does not supply boost/boost
closure, a gravity constraint algebra, a law for many particles, or a
uniform operator estimate on an unrestricted energy window. The mixed-band
counterexample and nonzero differential coefficient in the premise remain
unchanged. Higher time scales require a stronger estimate; none are excluded.

No finite computation proves the Hilbert-space estimates above. A selective
review must check the fixed global normalization, the contact-forcing sign,
propagator differentiation, all three differentiated factors, the global
versus supported form-factor bounds, and the time/error powers. This draft
does not silently upgrade the original source's prepared-state-only status.
