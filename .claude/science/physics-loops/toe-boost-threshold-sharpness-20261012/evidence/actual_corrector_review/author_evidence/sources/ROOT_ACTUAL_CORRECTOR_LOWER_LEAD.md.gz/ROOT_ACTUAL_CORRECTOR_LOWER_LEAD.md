# Proposed small-time actual-error lower bound

Root proposal, 2026-10-12. This is not a reviewed theorem. Its purpose is to
test whether the newly derived free threshold law can be combined with the
reviewed quantitative corrector machinery to establish sharpness for the
actual error on a sufficiently small fixed positive effective-time interval.

Frozen inputs:

- Q: BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md,
  4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820;
  separate completed review6ccba5be389898bd97ce12e53bf767dd002a3e6f282afb3cb4e010f49d86ca2d.
- S: HSTAR_THRESHOLD_SPECTRAL_PROBE.md,
  6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da.
  Its independent review is currently pending. This is a provisional dependency.
- X/B physical definitions remain at the identities given in Q and S.

Let D_lambda=W_lambda-z. Q gives the exact full physical equation

    i D' = G_lambda D + r(s) + e_lambda(s), D(0)=0,
    G_lambda=H_*/lambda+V_lambda, ||V_lambda||<=1,
    r(0)=-c0 a(0,kappa) Qh0,
    ||e_lambda(s)||_2<=M lambda(1+T), |s|<=T.

All forcing residuals r and r' are longitudinal, orthogonal to the complete
kernel, and satisfy the global mean constraint. On 0<=s<=1, Q12 gives the
coarse usable constants ||r(0)||_W<=R0=3M and ||r'(s)||_W<=R1=6M.
These constants and exact equations must be checked from the original proof.

1. A time-adapted free primitive bound seems available for ANY fixed physical
   residual f in this weighted class, not only Qh0. Write

       J_H(s)f = integral_0^s exp[-i(s-u)H_*/lambda] f du.

   For s>=lambda choose the Q7 corrector cutoff delta=lambda/s. The exact
   time-independent free integration identity gives

       ||J_H(s)f|| <= 2lambda c_x R/sqrt(delta)
                          +s c_e R sqrt(delta)
                    =K_R R sqrt(lambda s).

   For 0<=s<=lambda, use the direct Hilbert bound
   ||f||_2<=2sqrt(I0)R and s<=sqrt(lambda s). Check that K_R>=2sqrt(I0)
   at the proved I0 bounds. Thus the same bound should hold for every s>=0.
   No continuum density estimate for a general f is assumed.

2. The perturbation comparison should be performed on this already-small
   primitive. Its exact noncommuting identity is

       J_G(s)f-J_H(s)f
         =-i integral_0^s U_G(s-u)V_lambda J_H(u)f du.

   Therefore

       ||J_G(s)f-J_H(s)f||
          <=(2/3)K_R R sqrt(lambda) s^(3/2),
       ||J_G(s)f||<=K_R R sqrt(lambda s)(1+2s/3).

   This does not use a small operator-norm difference of the two propagators.
   It also does not assume that V commutes with H_* or preserves the weighted
   subspace: only the input free primitive uses the corrector estimate.

3. Retain the actual varying residual. By r(s)-r(0)=integral_0^s r'(v)dv
   and Fubini, its Duhamel contribution equals

       integral_0^t J_G(t-v) r'(v) dv.

   The last bound would give, for 0<t<=1,

       norm <=K_R R1 sqrt(lambda)
                  [(2/3)t^(3/2)+(4/15)t^(5/2)].

   Include also the exact e_lambda contribution <=M lambda t(1+t).
   Comparing D_lambda to -i J_H(t)r(0) then yields a candidate error bound

       ||D_lambda+i J_H(t)r(0)||
          <=sqrt(lambda)[A t^(3/2)+B t^(5/2)]
                         +M lambda t(1+t),
       A=(2/3)K_R(R0+R1), B=(4/15)K_R R1.

   Verify signs by differentiating the identities even though the final
   estimate is a norm statement. These are direct-integral Hilbert norms.

4. The provisional S20 threshold law gives

       ||J_H(t)r(0)||/sqrt(lambda) -> c_init sqrt(t),
       c_init=c0||a(0)||_2/sqrt(2pi I0^2)>0.

   If steps1–3 are valid, then

       liminf_(lambda->0) ||D_lambda(t)||/sqrt(lambda)
          >=sqrt(t)[c_init-A t-B t^2].

   Taking t0=min(1,c_init/[2(A+B)]) would make the right side at least
   c_init sqrt(t)/2 for every fixed 0<t<=t0. Q supplies a finite upper
   bound of the same lambda order. This would establish actual L2 error
   Theta(sqrt(lambda)) on a nonempty small fixed positive-time interval.

This is not an exact leading coefficient, a growing-time lower bound, an H1
lower asymptotic, a residual-mean lower bound, or a physical covariance claim.
S alone did not imply this result; the new steps explicitly control the full
noncommuting slow evolution and the changing forcing. Preserve any failed
inequality or missing regularity rather than treating this proposal as evidence.
