# Receipt path-resolution error in reviewer bookkeeping

The first identity verifier resolved every relative dependency-review path
against that review directory. The Q review receipt instead uses paths relative
to S for its report and evidence entries. The first Q entry therefore produced
FileNotFoundError before hash comparison. This is a reviewer verifier schema
error, not an author-source mismatch. The complete failed source, stdout,
stderr and execution metadata are preserved here. Resolve each receipt using
its explicit existing convention (S for Q; review directory for S), then rerun.
No scientific check, receipt, original source or tolerance changes.
