#!/usr/bin/env python3
"""Read-only byte/provenance checks. This script grants no science status."""
from pathlib import Path
import hashlib,json,subprocess

O=Path(__file__).resolve().parent
S=O.parent
A=S/'actual_corrector_small_time_lower'
C=O/'author_evidence'
R=S.parent/'quantitative_boost_worktree'

def sha(b): return hashlib.sha256(b).hexdigest()
def match(p,digest):
    b=p.read_bytes()
    assert sha(b)==digest,(str(p),sha(b),digest)
    return b

receipt=match(A/'receipt.json','6cd64fbba30a20a9582773a0fd944cb8db6922d679684a50c4b2ab0f2b281b1c')
ar=json.loads(receipt)
assert (C/'receipt.json').read_bytes()==receipt
names=[]
for row in ar['files']:
    p=(A/row['path']).resolve()
    assert p==S/'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md' or A in p.parents
    b=match(p,row['sha256']);assert len(b)==row['bytes'] and len(b.splitlines())==row['lines']
    names.append(row['path'])
assert len(set(names))==len(names)
expected={'../ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md'}|{str(p.relative_to(A)) for p in A.rglob('*') if p.is_file() and str(p.relative_to(A)) not in ar['excluded_post_freeze_outputs'] and '__pycache__' not in p.parts}
assert expected==set(names)
print('Author receipt and complete inventory',len(names),'bindings matched')

inv=json.loads((O/'author_inventory.json').read_text())
for row in inv['files']:
    b=match(A/row['relative'],row['sha256'])
    assert (C/row['relative']).read_bytes()==b
assert {str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()}=={x['relative'] for x in inv['files']}
print('Entire original/copied author packet',len(inv['files']),'files identical')

sm=json.loads((A/'source_manifest.json').read_text())
for row in sm:
    b=match(Path(row['source']),row['sha256'])
    assert (A/row['copy']).read_bytes()==b and len(b)==row['bytes'] and len(b.splitlines())==row['lines']
print('Original/copy scientific source pairs',len(sm),'matched')

im=json.loads((A/'instruction_manifest.json').read_text())['items']
for row in im:
    b=subprocess.check_output(['git','show',f"{row['ref']}:{row['path']}"],cwd=R)
    assert sha(b)==row['sha256']
print('Author exact-ref instruction fingerprints',len(im),'matched using allowed read-only checkout')

base=(A/'actual_lower_controls.py').read_text()
bm=json.loads((A/'baseline.execution.json').read_text())
assert bm['exit_code']==0 and sha(base.encode())==bm['source_sha256']
assert (A/'baseline.stderr.log').read_bytes()==b''
bo=json.loads((A/'baseline.stdout.log').read_text())
assert bo['controls_completed']==len(bo['records'])==36
mut=json.loads((A/'mutation_manifest.json').read_text())
for row in mut:
    assert base.count(row['before'])==1
    m=(A/row['paths']['source']).read_text()
    assert m==base.replace(row['before'],row['after'],1)
    assert sha(m.encode())==row['mutant_sha256'] and sha(base.encode())==row['baseline_sha256']
    assert json.loads((A/row['paths']['execution']).read_text())==row
    assert row['exit_code']==1 and row['caught_at_intended_check']
    assert (A/row['paths']['stdout']).read_bytes()==b''
    assert 'AssertionError: '+row['expected_assertion'] in (A/row['paths']['stderr']).read_text()
assert len(mut)==7
mm=json.loads((A/'mutations.execution.json').read_text())
assert mm['exit_code']==0
match(A/'run_mutations.py',mm['source_sha256'])
assert (A/'mutations.stderr.log').read_bytes()==b''
for prefix,script in [('receipt_freeze','freeze_receipt.py'),('receipt_verification','verify_receipt.py')]:
    row=json.loads((A/(prefix+'.execution.json')).read_text())
    assert row['exit_code']==0 and row['receipt_sha256']==sha(receipt)
    match(A/script,row['script_sha256'])
    match(A/(prefix+'.stdout.log'),row['stdout_sha256'])
    match(A/(prefix+'.stderr.log'),row['stderr_sha256'])
print('Baseline, seven exact mutations and post-freeze log bindings matched')

total=0
for row in json.loads((A/'prior_frozen_identity_check.json').read_text()):
    packet=Path(row['packet']);old=json.loads(match(packet/'receipt.json',row['receipt_sha256']))
    assert len(old['files'])==row['checked_bound_files']
    for item in old['files']:
        p=Path(item['path']);p=p if p.is_absolute() else packet/p
        match(p,item['sha256']);total+=1
print('Prior author Q/S/K evidence',total,'bindings matched; no scientific re-review inferred')

for row in json.loads((O/'source_manifest.json').read_text()):
    b=match(Path(row['path']),row['sha256']);assert Path(row['copy']).read_bytes()==b
pf=json.loads((O/'PRE_AUTHOR_FREEZE.json').read_text())
assert pf['author_new_evidence_accessed'] is False
for row in pf['bindings']:match(O/row['path'],row['sha256'])
for row in json.loads((O/'instruction_manifest.json').read_text()):
    b=match(O/'instructions'/row['path'],row['sha256'])
    assert b==subprocess.check_output(['git','show',f"{row['revision']}:{row['path']}"],cwd=R)
print('Reviewer source snapshots, instructions and pre-author freeze unchanged')

review_receipts=[('hstar_threshold_review','0e1cea8a04c122f4ae00af226ae3f2dd9d159701ae70d82671aa3eb42b57003c'),('boost_quantitative_review','c38f2a237e045a12870e380a7f9fc152c4a0e405238e8643050b4ec457e6dce2')]
dep=O/'dependency_receipts'
assert dep.exists()
for name,digest in review_receipts:
    b=match(S/name/'receipt.json',digest);assert (dep/(name+'.json')).read_bytes()==b
    jr=json.loads(b)
    for row in jr['files']:
        anchor=S if name=='boost_quantitative_review' else S/name
        p=Path(row['path']);p=p if p.is_absolute() else anchor/p
        match(p,row['sha256'])
print('Q/S independent-review receipts and their source/evidence bindings matched')

rep=json.loads((O/'reproductions/manifest.json').read_text())
for row in rep:
    assert row['expected_outcome'] and row['stdout_byte_equal'] and row['stderr_equal_after_path_normalization']
    assert not row['timed_out'] and row['exit_code']==row['expected_exit']
    match(Path(row['command'][1]),row['source_sha256'])
    d=O/'reproductions'/row['name']
    match(d/'stdout.log',row['stdout_sha256']);match(d/'stderr.log',row['stderr_sha256'])
    assert json.loads((d/'execution.json').read_text())==row
assert len(rep)==8
print('Fresh author baseline and seven intended failures reproduced with matching full logs')

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='36d6069676f561d81ad693f286dd52f570fb37df'
print('Read-only publication checkout HEAD',head)
print('Provenance verification complete; identity checks do not prove the theorem')
