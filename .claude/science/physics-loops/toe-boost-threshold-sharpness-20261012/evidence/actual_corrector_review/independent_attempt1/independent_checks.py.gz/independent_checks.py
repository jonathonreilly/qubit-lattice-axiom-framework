#!/usr/bin/env python3
"""Exact rational controls, written before accessing the new L author evidence.

This finite model checks identities, never continuum asymptotics. All expected
vectors come from a distinct recurrence or direct physical factorization.
"""
import json
import math
import sympy as s

I=s.I
N=7
lam=s.Rational(1,11)
e=s.ones(4,1)/2
T=s.Matrix([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/2
h=s.diag(1,2,3,5)
P0=s.eye(4)-e*e.T
Z3=s.zeros(3)
H=Z3.row_join(T.T*h).col_join((h*T).row_join(s.zeros(4)))
iv=h.inv()*e
zz=s.zeros(3,1).col_join(iv)
Pi=zz*zz.T/(zz.T*zz)[0]
Q=s.eye(7)-Pi
Btrip=s.Matrix([[0,2,-1,1],[2,1,3,0],[-1,3,-1,2],[1,0,2,2]])/23
B=s.diag(s.zeros(3),Btrip)
C=s.Matrix(7,7,lambda j,k:s.Rational((j+2)*(k+2)%7-3,211))
C=(C+C.T)/2
E=lam*C
V=B+E
G=H/lam+V
A=Pi*B*Pi
src=s.zeros(3,1).col_join(h*e)
q0=s.Matrix([s.Rational(j-2,37) for j in range(7)])
q1=s.Matrix([s.Rational((2*j+1)%5-2,41) for j in range(7)])
omega=s.Rational(8,5)
zero=s.zeros(7,1)

def clean(x):
    return x.applyfunc(s.cancel)

def assert_zero(x,label):
    x=clean(x)
    assert x==s.zeros(*x.shape), (label,str(x))
    print('EXACT',label)

def size(x):
    return float(s.sqrt(sum(abs(v)**2 for v in x)).evalf())

def reject(coeffs,label):
    nonzero=[(j,clean(v)) for j,v in enumerate(coeffs) if clean(v)!=zero]
    assert nonzero, label+' failed to distinguish the defect'
    j,v=nonzero[0]
    n=size(v)
    assert n>0
    print('DEFECT_REJECTED',label,'first_degree',j,'coefficient_norm',n)
    return {'name':label,'first_degree':j,'coefficient_norm':n}

def g_coeff(j):
    return src*(-I*omega)**j/s.factorial(j)

g=[g_coeff(j) for j in range(N+1)]
gl=[x.copy() for x in g]
gl[0]+=lam**2*q0
gl[1]+=lam**2*q1

def solve_coeff(M,forcing):
    # i y'=M y-forcing, exact coefficient recurrence with zero initial data.
    y=[zero.copy()]
    for j in range(N):
        y.append(clean((-I*M*y[-1]+I*forcing[j])/(j+1)))
    return y

def convolve_U(M,p):
    powers=[s.eye(7)]
    for j in range(N): powers.append(clean((-I*M)*powers[-1]))
    out=[zero.copy()]
    for k in range(1,N+1):
        out.append(clean(sum((powers[k-j-1]*p[j]*s.factorial(j)
                              for j in range(k)),zero.copy())/s.factorial(k)))
    return out

def primitive(M,f):
    return convolve_U(M,[f]+[zero.copy() for j in range(N)])

assert_zero(T.T*T-s.eye(3),'orthonormal physical singlet basis')
assert_zero(T*T.T-P0,'one global singlet projection')
assert_zero(H-H.T,'physical block self-adjoint')
assert_zero(H*Pi,'physical longitudinal kernel')
assert_zero(Pi*Pi-Pi,'kernel projection normalized')
assert H.rank()==6
assert V*H-H*V!=s.zeros(7)
print('EXACT physical kernel complete; perturbation noncommutes')

# A finite cutoff on h/2, with a complementary longitudinal residual.
beta=(s.eye(4)-iv*iv.T/(iv.T*iv)[0])*(h*e)
cut=s.diag(0,0,1,1)
a=cut*h.inv()*beta
mc=(e.T*a)[0]
x=T.T*a
f=s.zeros(3,1).col_join(beta)
xp=x.col_join(s.zeros(4,1))
eta=s.zeros(3,1).col_join((s.eye(4)-cut)*beta+h*e*mc)
assert_zero(f-H*xp-eta,'physical centered range identity')
assert_zero(e.T*P0*a,'centered singlet admissibility')
assert mc!=0
bad_eta=s.zeros(3,1).col_join((s.eye(4)-cut)*beta)
defects=[reject([f-H*xp-bad_eta],'omit mean correction in residual')]

jf=primitive(H/lam,f)
jeta=primitive(H/lam,eta)
up=[xp]
for j in range(1,N+1): up.append(clean((-I*H/lam)*up[-1]/j))
endpoint=[zero.copy()]+[I*lam*up[j] for j in range(1,N+1)]
for j in range(N+1): assert_zero(jf[j]-endpoint[j]-jeta[j],f'free primitive coefficient {j}')
defects.append(reject([jf[j]+endpoint[j]-jeta[j] for j in range(N+1)],'reverse primitive endpoint sign'))
defects.append(reject([I*lam*xp]+[zero.copy() for _ in range(N)],'omit initial corrector endpoint'))

W=solve_coeff(G,gl)
z=solve_coeff(A,[Pi*x for x in g])
D=[clean(W[j]-z[j]) for j in range(N+1)]
r=[clean(Q*(B*z[j]-g[j])) for j in range(N+1)]
err=[clean(E*z[j]+g[j]-gl[j]) for j in range(N+1)]
forcing=[r[j]+err[j] for j in range(N+1)]
actual=convolve_U(G,forcing)
for j in range(N+1): assert_zero(D[j]+I*actual[j],f'actual error equation coefficient {j}')
defects.append(reject([D[j]+I*convolve_U(G,r)[j] for j in range(N+1)],'omit entire forcing approximation'))
without_E=[r[j]+g[j]-gl[j] for j in range(N+1)]
test=convolve_U(G,without_E)
defects.append(reject([D[j]+I*test[j] for j in range(N+1)],'omit generator remainder on z'))

r0=r[0]
JG=primitive(G,r0)
JH=primitive(H/lam,r0)
ordered=convolve_U(G,[V*x for x in JH])
for j in range(N+1): assert_zero(JG[j]-JH[j]+I*ordered[j],f'ordered primitive identity coefficient {j}')
wrong_order=convolve_U(G,primitive(H/lam,V*r0))
defects.append(reject([JG[j]-JH[j]+I*wrong_order[j] for j in range(N+1)],'commute V through free primitive'))
defects.append(reject([JG[j]-JH[j]-I*ordered[j] for j in range(N+1)],'reverse ordered Duhamel sign'))

vary=[zero.copy()]+r[1:]
lhs=convolve_U(G,vary)
# Independently integrate J_G(t-v) r'(v) monomial by monomial.
rhs=[zero.copy() for _ in range(N+1)]
P=[s.eye(7)]
for j in range(N): P.append(clean((-I*G)*P[-1]))
for k in range(2,N+1):
    for j in range(1,k):
        n=k-j-1
        rhs[k]+=P[n]*r[j]*s.factorial(j)/s.factorial(k)
    rhs[k]=clean(rhs[k])
for j in range(N+1): assert_zero(lhs[j]-rhs[j],f'varying source Fubini coefficient {j}')
defects.append(reject(lhs,'freeze residual at initial value'))
int_err=convolve_U(G,err)
for j in range(N+1):
    assert_zero(D[j]+I*JH[j]+I*((JG[j]-JH[j])+rhs[j]+int_err[j]),
                f'complete comparison coefficient {j}')

# Constants derived independently from elementary integration and rational budgets.
v=s.symbols('v',nonnegative=True)
t=s.symbols('t',positive=True)
assert s.integrate(s.sqrt(v),(v,0,t))==s.Rational(2,3)*t**s.Rational(3,2)
assert s.integrate(s.Rational(2,3)*v**s.Rational(3,2),(v,0,t))==s.Rational(4,15)*t**s.Rational(5,2)
assert s.Rational(2,3)*(3+6)==6
assert s.Rational(4,15)*6==s.Rational(8,5)
assert (6+s.Rational(8,5))==s.Rational(38,5)
assert s.Rational(2,1)/(2*s.Rational(38,5)*406)==s.Rational(5,15428)
assert 1-s.Rational(15,64)==s.Rational(49,64)
assert 1+s.Rational(15,64)==s.Rational(79,64)<s.Rational(81,64)
assert s.Rational(7,8)-s.Rational(1,2)-s.Rational(1,8)==s.Rational(1,4)
assert s.Rational(9,8)+s.Rational(1,2)+s.Rational(1,8)==s.Rational(7,4)
KR=math.pi/2+math.sqrt(math.pi/2)+math.pi*math.sqrt(6)/4
tbar=5/(15428*math.pi*math.sqrt(3*math.pi)*KR)
assert 0<tbar<1
assert 4*math.sqrt(3)<3*math.pi
assert 3*math.exp(.5)+21<26<6*406
print('EXACT rational integration and all displayed finite-lambda budgets')
print('NUMERIC_DIAGNOSTIC K_R',KR,'t_bar',tbar)
print(json.dumps({'scope':'finite rational algebra only; no continuum sharpness inference',
                  'formal_degrees':N,'defect_controls':defects,'t_bar_diagnostic':tbar},indent=2))
