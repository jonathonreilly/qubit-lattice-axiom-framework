# Independent review of the quantitative boost-correction theorem

**PASS for the conditional supplied-model theorem Q1–Q34 at the frozen source
below. No required mathematical correction or unresolved proof step was found
within that exact scope.** This is a selective independent source review. It
applies no audit verdict, grants no retained status, and supplies no physical
covariance or new physical premise.

The supported estimates hold for the actual globally normalized B25–B30
preparation, every finite T>=0, and 0<lambda<=1/16:

    sup_(|tau|<=T) ||W_lambda-z||_(1,Sigma)
        <= M(30K_R+7) sqrt(lambda)(1+T)^3,
    sup_(|tau|<=T) ||W_lambda-z||_2
        <= M(3K_R+1) sqrt(lambda)(1+T)^2.

The literal constants are those defined in Q2. The stronger sum norm dominates
H1_kappa(L2_q). The resulting sufficient windows are 0<eta<1/6 for H1 and the
nine actual total-state expectations, and 0<eta<1/4 for L2 and simultaneous
comparison-correction norm limits. The endpoints and optimality are not claimed.

## Frozen source and reading coverage

The complete target is
[BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md),
729 lines, SHA-256
`4b1d5a8395d1d5c79d798ef17950f7c1ce4c1e0781e2f9ec610223bc1eb69820`.
Its author receipt has SHA-256
`c447314e4a130e2fc2e047da6ddbe2abdf20209c5aa4718c2bab9b75783b5356`.
Both remained unchanged through final verification.

All 729 target lines were read and reconstructed. Necessary original arguments
were read, rather than inferred from a review label. The complete source map,
hashes, instruction revisions, and explicit reading ranges are in
[the frozen reconstruction](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_quantitative_review/PROOF_RECONSTRUCTION_PRE_AUTHOR.md)
and `boost_quantitative_review/source_manifest.json`.

| Source | Direct reading and use |
|---|---|
| X source `a7161d79…` | All 587 lines: actual source, both global normalizers, exact error equation, complete bracket, common-domain symmetry, every expectation term. |
| X review `0e17f964…` and reconstruction `04adc0b8…` | All 186 and 426 lines; matching unchanged premises and prior verification limits. |
| K source `1c314fc0…` and review `64cf08ea…` | All 441 and 230 lines: pointwise resolvent formula, full transverse block, outgoing remainder, absolute-continuity dependency, and norm-limit scope. |
| B source `903261f5…` | All 744 lines: supplied operators, full B12–B13 normal form, support/global bounds, exact B25–B30 preparation, and adverse witnesses. |
| E evolved-comparison source `d8961198…` | All 185 lines: contact forcing, propagated domain, full free-comparison bound. |
| T inverse-energy source `76ed691c…` and review `d3c3d00b…` | All 658 and 167 lines: physical kernel, normalization, rescaled bracket and surviving norm obstruction. |
| D degenerate-dynamics source `b8f923be…` | Lines 70–165 and 395–490: full physical kernel, direct Pauli block, cone-localized nonuniformity witness. |
| Memory source `b667b092…` | All 500 lines, including the complete cone-density, Poisson-domination and endpoint proof used by Q28's transverse limit. |
| Both root leads | All 114 and 81 lines at the target's listed identities; proposals, not theorem premises. |

The memory review was copied and hashed but not used as a mathematical premise.
Unrelated historical sources and prior control implementations were not newly
certified. The preserved exponential proof was identity-checked; this report
reviews the current Q1–Q34 argument, not every historical formulation.

## Decisive mathematical findings

1. **The corrector is physical, and its cone constants are valid**
   ([target line 100](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:100)).
   The Pauli singlet/triplet matrix identifies the entire physical kernel as
   transverse triplets plus zeta, with the constant singlet excluded. For the
   actual triplet residual, orthogonality to zeta is exactly the full-torus
   constraint `integral beta/(2epsilon)=0`. The cutoff coefficient is explicitly
   centered, and direct application of H_* gives both the omitted-cone term
   and `2epsilon n m_delta`. Folding all eight sine cells gives precisely
   Q6. Mean subtraction is an orthogonal projection, so Q7's improved
   `pi C/(4sqrt(delta))` corrector norm is justified. No q derivative occurs.

2. **The polynomial weighted bounds follow from the actual source**
   ([target line 173](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:173)).
   K8's forcing gap bounds the resolvent by one and its kappa derivative by
   two at each individual fiber. Differentiating its weight, resolvent, and
   exponential factors yields the stated pointwise bounds on alpha and
   alpha_j. The complete transverse integral then gives Q11. Its two quadratic
   time contributions are each T^2/8, from the propagator and alpha derivative;
   the coupling derivative is also retained. Q10 supplies the time and mixed
   derivatives, so every actual residual required by Q7 satisfies Q12.
   Weighted-space boundedness and Hilbert unitarity are kept distinct.

3. **All approximation errors and differentiated terms are retained**
   ([target line 308](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:308)).
   Q14–Q19 preserve the normalized-vector denominators, positive-projector
   derivative, envelope derivative, source-clock derivative, and both global
   scalar normalizers. The inner-integral derivative difference has exactly
   the sufficient bound `m lambda^2[5/2+13|t|/12+t^2/6]`. No small-phase
   assumption on lambda^2 T is needed. The generator and form-factor
   remainders satisfy the stated uniform constants on the enclosing ball.

4. **The noncommuting integration identity gives the claimed all-T rates**
   ([target line 418](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:418)).
   Both endpoints in Q21 have the correct sign, including the nonzero initial
   corrector. An independently reconstructed approximate-solution equation
   confirms its time-derivative and ordered V_lambda x terms. With
   delta=lambda, Q7 gives Q22. The full differentiated error equation retains
   `(partial_j G_lambda)D_lambda`, `E_lambda,j z`, `E_lambda z_j`, and the
   complete source derivative. Its error is estimated in the whole physical
   Hilbert space. Summing the zeroth and three first-derivative estimates
   yields exactly `M(30K_R+7)`. Negative times and zero time are included.

5. **The simultaneous limits use the correct hypotheses and order**
   ([target line 490](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:490)).
   The all-T estimates precede the substitution T=lambda^(-eta). They give
   the positive exponents 1/2-3eta and 1/2-2eta on the stated open windows.
   K's uniform Hilbert bound then controls squared-norm differences along
   every admitted tau_lambda with |tau_lambda| tending to infinity. Only the
   transverse limit needs the original source-measure absolute continuity:
   its cone lower bound, local Poisson domination, and separate endpoint-atom
   exclusion all check. The kappa=0 exceptional fiber is removed by global
   dominated convergence, without a uniform near-zero decay rate. Q28 remains
   a comparison-correction norm statement, not a total-state occupation.

6. **The all-nine expectation estimate has no missing cross term or derivative**
   ([target line 542](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/BOOST_HSTAR_QUANTITATIVE_CORRECTOR_PROBE.md:542)).
   The complete B13 form gives directional constants 85 for A_b'' and
   149/2<75 for C_ab'. Taylor's formula gives
   `75/4+85/32=685/32<22`, proving Q30 on all components. q derivatives
   act only on known smooth form factors. Kernel orthogonality gives
   `<z,Q0,ab z>=0`; it does not make Q0,ab z vanish. Symmetry permits the
   smaller L2 error in the quadratic pairing. The actual free, cross and
   correction terms yield exactly the two majorants
   `sqrt(lambda)(1+T)^3` and `lambda(1+T)^5`. Their exponents are positive
   for 0<eta<1/6, proving Q33–Q34 with the stated C_mean.

## Independent finite checks and author reproduction

The 416-line analytic reconstruction was frozen at **2026-10-12 00:34:22 UTC**,
SHA-256 `dc370ac3cef04b514962d58862735c9080e1b91b0d078345da181a2d15e32ad9`.
Independent finite controls and their complete success/failure history were
also frozen before author evidence was opened, at **00:38:56 UTC**.
`PRE_AUTHOR_CONTROL_FREEZE.json` has SHA-256
`8f388f7d3dccd6059f4002ba52187098a2da9ee5b779dc75714d16f7c0399daa`.

The independent implementation uses actual Pauli matrices on seven weighted
antipodal q pairs, a single global contact projection, an augmented matrix
exponential, and a separately integrated full error ODE. Its global scalar
normalizers and local envelope are declared finite-fixture inputs, not an
approximation adopted for the exact B25–B30 packet. The corrector identity
agrees through approximately 3.00e-15 at positive and negative times. Direct
state/error comparison is within 8.96e-12, and all three parameter derivatives
are within 4.02e-12. Omitting the full-error generator derivative gives about
5.99e-4 discrepancy; omitting the source phase derivative gives about 1.58e-4;
omitting E_j z gives about 1.06e-8, well above the observed baseline error.
Omitted centering, both endpoints, the time-corrector derivative and the
noncommuting perturbation are also distinguished.

Two reviewer diagnostic gates initially failed: their absolute defect-size
thresholds (1e-6 and 1e-7) exceeded the small but resolved effects of V x and
E_j z in this fixture. Both full failed sources, logs and metadata are preserved
under `independent_attempt1/` and `independent_attempt2/`. The diagnostic gates
were revised to require explicit separation from the numerical comparison
error, with absolute floors; no fixture, predicted identity, source formula,
or theorem bound was changed. The successful final run took about 3.64 seconds
under its declared 120-second timeout, with empty stderr. These refinements are
disclosed so the final control is not presented as an unmodified preregistration.

After the freeze, the entire 224-line author-check document, all three scientific
helpers (251, 129 and 78 lines), bookkeeping/execution scripts, literal mutation
differences, and all complete baseline and failure logs were read. All eleven
saved defect copies are exactly their declared one-replacement mutations; each
recorded execution exits one at the intended assertion under a 120-second
limit. The continuous radial diagnostic correctly preserves a non-L2 full
inverse, with `delta||x_delta||^2->3/4` and residual squared norm divided by
delta tending to 3. It does not prove optimality for the actual walk.

The three author baselines were replayed once into fresh logs. They completed
in approximately 1.81, 0.92 and 0.53 seconds under separate 120-second timeouts,
with empty stderr; each complete stdout was byte-identical to its saved
baseline. This is reproduction, not another independent analytic proof. Finite
projection/annihilation identities alone do not prove kernel completeness,
cone bounds, absolute continuity or a continuum time window; the original
analytic arguments provide those conclusions. Generic coefficient fixtures
and scalar product-rule checks have correspondingly limited evidentiary scope.

The independent identity check matched all 83 author bindings, the complete
packet inventory/copy, eleven original/copy source pairs, fourteen exact-ref
instruction records, all eleven literal mutations, post-freeze log bindings,
and fourteen prior K review artifact bindings. All frozen mathematical inputs
and the pre-author reviewer artifacts remained unchanged. Its full output and
metadata are saved, including its 60-second timeout and exit zero. Identity
counts have no mathematical evidentiary weight.

## Safe reuse and preserved limitations

The initial actual residual's formal singlet inverse is not L2. The earlier
mixed-band counterexample, nonzero differential coefficient, small-positive-time
diagonal norm obstruction, cone-concentrating failure of uniform state
convergence, and finite-bath recurrence remain valid in their stated scopes.
This quantitative theorem supplies no H_* operator gap, inverse on the full
complement, q derivative of zeta, arbitrary-preparation uniformity, total-state
probability interpretation of Q28, full boost algebra, or physical covariance.
No new external theorem import or Lean certificate is used. Mathematical proof
checking, finite controls, reproduction, identity checking, and formal proof
verification remain distinct; only the first four were performed here.

Root is a coauthor of the mechanisms. This reviewer supplied a fresh analytic
reconstruction and separate finite implementation before opening Q author
evidence. The target's formulas/control descriptions and the prior X/K reviews
were visible, so independence is source-shared checking rather than blinding.
The user-selected model and effort were inherited without override or
subdelegation. Applicable instructions used main
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; local exact-ref reads do not assert
remote freshness. The campaign deadline remains 2026-10-12 16:00:52 UTC.

Only this report and `boost_quantitative_review/` were written. Frozen sources,
author evidence, Git state, PRs, audit state, physical premises and other chats
were not changed. **No editable prompt file changed.** This report supports
conditional reuse of the exact Q result. A changed load-bearing source or
hypothesis needs affected-source review. Full recovery is in
[CHECKPOINT.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_quantitative_review/CHECKPOINT.md)
and
[receipt.json](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/boost_quantitative_review/receipt.json).
