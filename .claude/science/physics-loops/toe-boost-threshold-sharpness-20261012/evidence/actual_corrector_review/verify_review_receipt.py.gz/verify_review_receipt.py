#!/usr/bin/env python3
"""Read-only recovery verification; never grants mathematical or audit status."""
from pathlib import Path
import hashlib,json

O=Path(__file__).resolve().parent
S=O.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((O/'receipt.json').read_text())
assert r['schema']=='actual-corrector-independent-review-v1'
assert Path(r['review_directory']).resolve()==O
names=[]
for row in r['files']:
 p=(O/row['path']).resolve();assert p==S/'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_REVIEW.md' or O in p.parents
 b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'] and len(b.splitlines())==row['lines'],row['path']
 names.append(row['path'])
actual={'../ACTUAL_CORRECTOR_SMALL_TIME_LOWER_REVIEW.md'}|{str(p.relative_to(O)) for p in O.rglob('*') if p.is_file() and str(p.relative_to(O)) not in r['excluded_post_freeze_outputs'] and '__pycache__' not in p.parts}
assert len(names)==len(set(names)) and actual==set(names)
assert sha(Path(r['target']['path']).read_bytes())==r['target']['sha256']
assert sha(Path(r['report']['path']).read_bytes())==r['report']['sha256']
assert sha((S/'actual_corrector_small_time_lower/receipt.json').read_bytes())==r['author_receipt_sha256']
assert sha((O/'PRE_AUTHOR_FREEZE.json').read_bytes())==r['pre_author_freeze_sha256']
for row in json.loads((O/'source_manifest.json').read_text()):
 assert sha(Path(row['path']).read_bytes())==row['sha256']
 assert Path(row['copy']).read_bytes()==Path(row['path']).read_bytes()
for row in json.loads((O/'author_inventory.json').read_text())['files']:
 assert sha(Path(row['path']).read_bytes())==row['sha256']
 assert sha((O/'author_evidence'/row['relative']).read_bytes())==row['sha256']
for row in json.loads((O/'PRE_AUTHOR_FREEZE.json').read_text())['bindings']:
 assert sha((O/row['path']).read_bytes())==row['sha256']
print('Review receipt inventory and all',len(names),'source/evidence bindings match')
print('Original target, original author packet, source snapshots and pre-author freeze remain unchanged')
print('Receipt verification is recovery bookkeeping; it does not apply an audit verdict or grant retained status')
