# Author checks for the actual small-time lower bound

These are author derivations and controls, not a fresh-context independent
review. Root proposed the mechanism and is a coauthor. The scope is exactly
L1–L20, with S19–S20 an explicit provisional dependency. No scientific review
status is inferred from the number of numerical checks or receipt bindings.

## Source boundary

The source manifest binds twelve original/copy pairs and records current or
inherited reading coverage. The Q source and its complete selective review
were read for this task. All necessary X2–X22 and B25–B30 equations were
rechecked at their frozen identities. The complete S source was authored and
cold-read in the preceding task; the threshold primitive and initial-source
arguments, and the explicit threshold constants, were reread here.

The full new note was cold-read after the successful baseline and mutation
executions. No failed mathematical baseline or changed numerical acceptance
threshold preceded the result. The lead's proposed route survives; its exact
limits and proof dependencies are retained. The minor final editorial edits
were reread before freezing. Existing Q/K/S sources and evidence are unchanged.
Applicable instructions were reused at the exact stored revisions in
instruction_manifest.json; no remote freshness or Git mutation is asserted.

## Distinct algebraic arrangements

The time-adapted estimate starts with the fixed-cutoff identity
`J_H(s)f=-i lambda[x-U_H(s)x]+J_H(s)(f-H_*x)`.
Differentiation checks both the sign and the two endpoints. Only after this
identity is established at each fixed final length is delta set to lambda/s.
The interval s<=lambda uses the Hilbert embedding, so delta never exceeds one.
Nothing differentiates a time-dependent cutoff.

For the perturbation identity there are two analytic reconstructions. The
primitive ODE has source i f. Subtraction therefore gives the difference ODE
with source V_lambda J_H f and the Duhamel prefactor -i. Alternatively,
insert the ordered propagator Duhamel formula into the primitive. The double
integral has integrand
`U_G(s-a-b) V_lambda U_H(b)f` on a,b>=0, a+b<=s.
Changing to u=a+b has unit Jacobian and gives
`U_G(s-u)V_lambda integral_0^u U_H(u-a)f da`.
This is the asserted U_G V_lambda J_H order; no factors commute.

A third local sign/order check is the bounded-operator Taylor expansion. With
Hf=H_*/lambda, the difference of the two primitives begins

    -i s^2 V_lambda/2
       -s^3(Hf V_lambda+V_lambda Hf+V_lambda^2)/6+O(s^4).

Expanding the ordered integral produces the same three cubic terms. The
commutator information occurs beyond the leading quadratic term, which is why
an actually noncommuting finite fixture is used as well as a sign check.

For the actual source, subtracting the two original equations gives
`r+e=Q(Bz-g)+E_lambda z+g-g_lambda` with exactly the positive ODE source.
The solution is therefore -i times its convolution. The time derivative is
`r'=Q(Bz'-g')`, retaining Bz'. The varying-source identity follows by regrouping
the continuous finite triangular integral, not by replacing r(s) with r(0).
Its lag primitive is J_G(t-v). Both 2/3 and 4/15 constants come from direct
integration, and the O(lambda) source error is estimated separately.

## Regularity and physical-domain check

The longitudinal corrector is an even singlet with one zero full-torus mean
per kappa fiber. The complementary constraint is exactly
`integral beta/(2epsilon)dmu=0`. The two terms of its range error survive.
For fixed delta, cutoff multiplication and orthogonal mean subtraction define
a Hilbert-bounded map of norm at most 1/(2delta). Thus there is no reliance on
strong measurability into a nonseparable weighted L-infinity space.

The exact source is continuously differentiable in the direct-integral Hilbert
space by the compact x support and bounded source energy. The bounded kernel
ODE gives a continuous z'. Consequently r is C1 in that Hilbert space. For
each lambda the full generator on the fixed kappa support is bounded and
self-adjoint; the integrands on finite time triangles are norm-continuous.
Their Bochner integrals and Fubini regrouping are therefore legitimate. All
norm estimates use full physical unitarity, even after V_lambda has taken a
vector out of the weighted longitudinal class. No q derivative or gap enters.

## Constants and order of limits

The two initial/time constants are Q12's first row at T=0 and T=1:
R_init=3M and R_dot=6M. They are not the separate kappa-derivative constants.
The small-s branch is covered because
`2sqrt(I0)<=sqrt(pi sqrt(3)/2)<=pi sqrt(6)/4<=K_R`.
The middle comparison is equivalent to 4sqrt(3)<=3pi and follows, for example,
from sqrt(3)<2 and pi>3. Sympy separately checks the time powers, substituted
constants, and the final rational budgets.

After division by sqrt(lambda), the new remainder is at most
`A_L t^(3/2)+B_L t^(5/2)+M sqrt(lambda)t(1+t)`.
S19 gives the time-frozen leading norm and its uniform absolute squared-norm
remainder. Both triangle inequalities apply before the limit. They yield the
positive liminf and finite limsup for every fixed 0<t<=t0. No limit of the
actual ratio is asserted. The finite-lambda threshold makes the free squared
error <=15/64 of c_init^2 t, and the forcing error <=1/8 of c_init sqrt(t).
This leaves the stated 1/4 and 7/4 two-sided constants after the perturbation
and source-variation budget of 1/2. The positive explicit subinterval is
`t_bar=5/[15428 pi sqrt(3pi)K_R]`, approximately 7.07734e-6; its exact formula,
not this rounded decimal, is used in the theorem. lambda_*(t) depends on t.

## Independently arranged finite implementation

actual_lower_controls.py imports no previous scientific helper. It builds the
original Pauli symbol on four antipodal q pairs, with full-pair weights
(0.1,0.2,0.3,0.4), constructs the singlet/triplet parity isometry, removes one
global mean, and independently forms the complete kernel projection. The
physical dimension is 15, with nine zero modes. These finite numbers and its
I0=0.4180247051450885 are fixture values, not continuum torus estimates.

The actual symbol at kappa=(0.14,-0.12,0.08), lambda=0.06 gives a perturbation
norm about 0.191821 and a commutator norm about 0.558661. The source uses the
exact sine, positive-projector weight, form-factor and global-scalar
normalization structures at one positive x fixture. This is not the B25
continuum envelope or a claimed continuum quadrature. It supplies nonzero
source-clock, normalization and generator errors for checking the equations.

W and z are obtained from separate augmented matrix exponentials. Their
subtracted ODE is compared with the full residual and e_lambda. Primitive
matrices are also computed from their spectral functions and compared with a
separate augmented exponential. Ordered perturbation integrals use 96-point
Gauss-Legendre quadrature, with a 48-point comparison. The time-varying source
is integrated directly and via its derivative/Fubini representation.

The baseline completed 36 checks with exit zero and empty stderr, in about
1.30 seconds under a 120-second limit. Its executed source SHA-256 is
`a9b5bd5986d3cd4752c1f8dabcb7157da240baa2f7424f11c75eae3d743b437b`.
Python 3.13.5, Numpy 2.4.4, Scipy 1.17.1 and Sympy 1.14.0 were used.
The complete baseline stdout and stderr were read.

Selected discrepancies were approximately:

- Full error ODE: 1.94e-16; full Duhamel solution: 4.61e-17.
- Ordered primitive identity: 1.68e-17; the quadrature comparison: 1.64e-19.
- Varying-source Fubini identity: 2.05e-17.
- Complete leading-term comparison: 3.58e-17.
- Finite-difference residual time derivative: 1.85e-12.

The resolved contributions are much larger: ||E_lambda z|| about 2.03e-6,
||g-g_lambda|| about 1.16e-5, perturbation primitive about 1.88e-6, varying
source about 1.74e-3, and cutoff mean about 8.78e-3. The fixture is not hiding
these terms by accidental zeroing.

## Actual defect executions and preserved failures

Seven unique one-replacement mutants were really executed; each exited one
at its intended assertion. Their exact source, complete stdout/stderr and
execution metadata are preserved. All seven full log pairs were read, and
all sources were checked against their unique declared literal replacements.
The baseline acceptance thresholds were not changed.

| Omission or defect | Intended distinguishing assertion |
|---|---|
| Global mean subtraction | physical_corrector_global_mean |
| Initial corrector endpoint | free_corrector_primitive_identity |
| Perturbation comparison sign | ordered_noncommuting_primitive_identity |
| V_lambda/J_H factor order | ordered_noncommuting_primitive_identity |
| Bz' in the residual derivative | residual_time_derivative |
| E_lambda z in the forcing error | exact_full_error_ODE |
| Actual Duhamel source sign | actual_full_forcing_solution |

The coarse operator-norm propagator comparison remains O(t^2) and cannot
transfer the threshold lower law. Full inversion still fails in L2. A fixed
finite fixture has complementary gap about 1.01183 and an O(lambda^2) squared
free-primitive bound; this is the wrong lambda-first law for the continuum.
That failure is explicitly recorded by the helper rather than hidden through
a mesh-dependent fitted exponent. No finite calculation proves S19 or L1.

## Remaining gate

The analytic proof is complete as a conditional author result. Its exact
S19–S20 dependency remains provisional pending the separate S review. L1–L20
need their own independent scientific check; the root and this worker are
coauthors. Receipt verification only establishes exact byte/execution
provenance. There is no audit verdict, retained status or Lean certificate.
All earlier counterexamples remain in their scopes. No new claim about H1,
means, a fixed-time exact coefficient or growing-time optimality is made.
