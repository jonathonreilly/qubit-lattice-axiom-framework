#!/usr/bin/env python3
"""Execute literal one-defect controls; all failed sources/logs are retained."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent
base=(p/'actual_lower_controls.py').read_text();basehash=hashlib.sha256(base.encode()).hexdigest()
mutations=[
 ('omitted_global_mean','alpha=beta/(2*eps)*(eps>=cutoff)-mean','alpha=beta/(2*eps)*(eps>=cutoff)','physical_corrector_global_mean'),
 ('omitted_initial_endpoint','range_primitive=-1j*lambda_value*(xc-sh.U(time_value)@xc)+sh.J(time_value)@eta','range_primitive=-1j*lambda_value*xc+sh.J(time_value)@eta','free_corrector_primitive_identity'),
 ('wrong_comparison_sign','comparison=-1j*quad(lambda u:sg.U(time_value-u)@V@sh.J(u)@rzero,time_value)','comparison=1j*quad(lambda u:sg.U(time_value-u)@V@sh.J(u)@rzero,time_value)','ordered_noncommuting_primitive_identity'),
 ('wrong_noncommuting_order','comparison=-1j*quad(lambda u:sg.U(time_value-u)@V@sh.J(u)@rzero,time_value)','comparison=-1j*quad(lambda u:sg.U(time_value-u)@sh.J(u)@V@rzero,time_value)','ordered_noncommuting_primitive_identity'),
 ('omitted_residual_Bz_derivative','def rp(tv):return Q@(B@zp(tv)+1j*omega*g(tv))','def rp(tv):return Q@(1j*omega*g(tv))','residual_time_derivative'),
 ('omitted_generator_forcing_error','def err(tv):return E@z(tv)+g(tv)-gl(tv)','def err(tv):return g(tv)-gl(tv)','exact_full_error_ODE'),
 ('wrong_actual_Duhamel_sign','full_duhamel=-1j*quad(lambda u:sg.U(time_value-u)@(r(u)+err(u)),time_value)','full_duhamel=1j*quad(lambda u:sg.U(time_value-u)@(r(u)+err(u)),time_value)','actual_full_forcing_solution')]
rows=[]
for name,before,after,assertion in mutations:
    assert base.count(before)==1,name
    d=p/'mutations'/name;d.mkdir(parents=True,exist_ok=True)
    source=d/'control.py';assert not source.exists(),'refuse to overwrite a mutation execution'
    changed=base.replace(before,after,1);source.write_text(changed)
    cmd=['/opt/homebrew/opt/python@3.13/bin/python3.13',str(source)]
    started=datetime.now(timezone.utc).isoformat();t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
    (d/'stdout.log').write_text(r.stdout);(d/'stderr.log').write_text(r.stderr)
    caught=r.returncode==1 and 'AssertionError: '+assertion in r.stderr
    row={'name':name,'before':before,'after':after,'baseline_sha256':basehash,'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),'command':cmd,'started_at_utc':started,'elapsed_seconds':time.monotonic()-t,'timeout_seconds':120,'exit_code':r.returncode,'expected_assertion':assertion,'caught_at_intended_check':caught,'paths':{'source':str(source.relative_to(p)),'stdout':str((d/'stdout.log').relative_to(p)),'stderr':str((d/'stderr.log').relative_to(p)),'execution':str((d/'execution.json').relative_to(p))}}
    (d/'execution.json').write_text(json.dumps(row,indent=2,sort_keys=True)+'\n');rows.append(row)
    (p/'mutation_manifest.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'name':name,'exit_code':r.returncode,'caught_at_intended_check':caught,'elapsed_seconds':row['elapsed_seconds']}),flush=True)
    if not caught:raise AssertionError('unexpected mutant result: '+name)
print('All seven literal intended failures executed; full sources and logs preserved.')
