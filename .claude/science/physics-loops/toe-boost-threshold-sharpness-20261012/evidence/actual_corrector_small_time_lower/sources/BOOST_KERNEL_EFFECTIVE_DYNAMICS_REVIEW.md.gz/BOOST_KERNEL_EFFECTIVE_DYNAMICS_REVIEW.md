# Independent review of the actual forced boost correction

**PASS for K1–K19 as a conditional supplied-model result on the frozen source
identified below. No required correction or unresolved analytic proof step was
found within that scope.** This is a selective independent source review, not
an audit verdict, retained-status grant, physical identification, or approval
of a different source revision.

The supported new result is the exact decomposition of the actual X correction
into a nonzero resolvent-dressed vector evolving under the compressed generator
and a remainder decreasing faster than every inverse power in H1_kappa.
Its spectral reweighting and lambda-first ordered correction-norm limits follow.
No new lambda rate, growing-time original-walk approximation, total-state
occupation theorem or weighted-current limit is established.

## Source and independence boundary

The complete 441-line target is `BOOST_KERNEL_EFFECTIVE_DYNAMICS_PROBE.md`,
SHA-256 `1c314fc05a26ca27e0828a70ca8132a2bad269b60c127ea37a53e11e95e087c9`.
The author receipt is `boost_kernel_effective_dynamics/receipt.json`, SHA-256
`8767499b08e7721cf1133930fcd9e0a5c703536b46aba5eacd98b81b688d7352`.
All paths in the following table are relative to this report's directory.

| Source | SHA-256 | Direct review coverage and use |
|---|---|---|
| `BOOST_CURRENT_EXPECTATION_PROBE.md` | `a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68` | Lines 1–440; in particular all of X2–X24, exact source and normalization, complete fixed-time H1 proof. X1's full expectation proof is not a new target of this review. |
| `BOOST_CURRENT_INVERSE_ENERGY_PROBE.md` | `76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990` | Lines 1–44, 78–320 and 434–520; preparation, global constants, full physical kernel and the stated surviving small-time norm obstruction. |
| `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md` | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` | Lines 84–184, 277–324 and 488–691; original operator/space conventions, exact B25–B30 source, differential witness and mixed-band scope. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Lines 70–160 and 401–485; full kernel, direct Pauli block D6, and cone-concentrating counterexample D31. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | All 500 lines; especially E8–E23 including the complete cone-density, Poisson-domination and endpoint proof, and E27–E28 recurrence. |
| `BOOST_CURRENT_EXPECTATION_REVIEW.md` | `0e17f9647141c200b1efcbe78f60ef6beedc1e249ce1b85544293dddbebe8690` | All 186 lines, read after the independent reconstruction freeze; prior provenance and scope comparison. |
| `boost_expectation_review/PROOF_RECONSTRUCTION.md` | `04adc0b81d3865f4819b8441e25279ef084bda755e9c0a3206be7d314ea04f9f` | Lines 187–315 fully refreshed after the freeze; prior alternative averaging proof, all first derivatives, and kernel premises. No complete new review of the 426-line parent reconstruction is claimed. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Lines 1–140, after the freeze; prior scope and source identities, kernel/block and fixed-vector limit. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | All 329 lines, after the freeze; comparison with the necessary original proof already reconstructed independently. |

The independent analytic reconstruction and independent finite-control source
and successful log were frozen at **2026-10-11 23:51:18 UTC**, before any
author-evidence file or prior reviewer conclusion was opened. The freeze is
`boost_forcing_review/PRE_AUTHOR_FREEZE.json`, SHA-256
`8cb07630fe71b46b99678f91b73316eb62cd0c20083cb5080ac753c8438d762a`.
The full reconstruction is
`boost_forcing_review/PROOF_RECONSTRUCTION_PRE_AUTHOR.md`, SHA-256
`d8069f6681f60eae1629e026fa877fac11eaa92d69e0a2df6510b40270a1fad2`.
It is preserved unchanged.

The target itself exposed its proposed conclusions, derivations and brief
descriptions of its controls. This is independent reconstruction with shared
source information, not blinded discovery. Root's proposed research direction
is not counted as independent checking. This reviewer inherited the user's
selected model and effort without override or subdelegation.

## Mathematical findings

1. **The physical zero space, block and source-cyclic representation are
   correct** (target lines 71–157). Direct singlet/triplet multiplication
   gives the sign `B v=i d cross v`. Solving `H0(0)u=gamma c` on the physical
   space gives precisely the transverse triplets plus zeta; the auxiliary
   constant singlet is excluded. The I0 cone integral is finite with the
   claimed bounds. Compression gives both coupling entries and norm <=b.
   Pointwise J alone changes odd parity; the combined D and its full
   functional calculus preserve it. The source-cyclic polynomial map has
   measure beta of mass ||g||^2, and adjoining zeta gives exactly K4.
   No two-dimensional bath or scalar dispersion is substituted.

2. **K8 has the exact forced sign, initial condition and normalization**
   (target lines 159–230). The original source's two normalized momentum
   measures and preparation factor cancel as stated. The contact amplitude
   uses the Lebesgue x integral with no extra c0; the K isometry and time
   rescaling then supply c0, and Pi h0 supplies 1/sqrt(I0). The remaining
   factor is the single global F/Z0. Both initial comparisons coincide, so
   the correction starts at zero. For each spectral E,

       i integral_0^tau exp[-i(tau-s)E] exp(-is e) ds
          = [exp(-i tau E)-exp(-i tau e)]/(e-E).

   This checks both signs of time. Differentiating the resolvent expression
   independently gives `iY'=AY-exp(-it e)zeta` and `Y'(0)=i zeta`.
   There is no additional homogeneous initial tail.

3. **The source separation and nonzero dressing bound hold uniformly.**
   On the actual annulus and enclosing kappa ball, the two momenta have
   norm at least 1/2, their dot product is positive, and `1/4<=w<=1/2`.
   Triangle inequalities give `5/4<=e<=3/2+b`; compression gives
   `sigma(A) subset [-b,b]`. Thus `1<=e-E<=2`. This proves a bounded
   real resolvent, `m_f/8<=chi<=m_f/2`, and the nonzero global V bounds
   using the positive spectral calculus and ||F||_2=1. Neither this
   positivity nor the total correction-norm limit needs source absolute
   continuity. No spectral gap for H_* or its nonzero complement follows.

4. **The uniform Hilbert-valued and kappa-derivative estimates are valid**
   (target lines 232–298). The radial derivative satisfies
   `e_r>=2(r-b/2)/(r+b/2)>=4/3`. The phase and weight are smooth on a
   compact set separated from both momentum singularities. Since A is
   linear in kappa and e-A>=1, repeated resolvent derivatives are bounded
   in operator norm. Every radial derivative of the amplitude vanishes at
   both endpoints because the fixed annular bump is flat there.

   Bochner integration by parts therefore gives K13 with the written
   `(-i/tau)^N` sign. The suprema of the integrated norms of the recursive
   amplitudes supply finite uniform constants. A kappa derivative has
   both an amplitude term and a phase term proportional to tau; one
   additional radial integration controls the latter. Multiplication by
   the fixed smooth F gives a global H1 section without a boundary
   distribution. Duhamel's bound on the derivative of exp(i tau A) costs
   at most |tau|, absorbed by another power. This proves K11/K19 for
   positive and negative time. No q derivative of singular zeta appears.
   The Abel-regularized outgoing integral has denominator e-E-i eta and
   confirms the same sign and limiting vector.

5. **Prior absolute continuity is used exactly where needed** (target
   lines 132–157 and 300–355). I reconstructed original E14–E23 rather
   than accepting a previous review label. The cone-shell change of
   variables yields the stated single-helicity constant
   `b(delta/b)^(3/2)/(16384 pi^2 I0)`. It gives a uniform local upper-half-
   plane bound on M. The Poisson interval inequality excludes all
   interior singular measure; the strict pointwise compression separately
   excludes both endpoint atoms. This is sufficient for every nonzero
   kappa, including axis directions. It does not classify dark subspaces.

   K14 correctly weights the source measure by **chi squared**, retaining
   exactly the same null sets and closed support where F!=0. The zeta
   coefficient of the leading term is the Fourier transform of
   `C chi rho`, an L1 density. That is the step using the prior continuum
   theorem. Subtracting its squared magnitude from the total norm proves
   the transverse limit. The kappa=0 exception is retained until global
   dominated convergence removes its null fiber. Rapid total-norm
   convergence does not supply rapid transverse-norm or dressing-amplitude
   decay; the note correctly keeps these apart.

6. **The limits in K18 have the stated order and interpretation** (target
   lines 357–390). The necessary X23 proof uses compact fixed families of
   Q-valued residuals and a cutoff inverse, first lambda->0 and then cutoff
   width->0. Its differentiated equation keeps the propagator, source
   phase and projector-weight derivatives. For each fixed tau, the K-only
   isometry gives `||W_lambda||^2=||w_phys,lambda||^2/lambda`, and F_tr
   commutes with it. Taking the effective-time limit afterwards gives V.
   The off-spectrum source bound on Z does not estimate the low nonzero
   H_* mass of Q(Bz-g); it cannot justify a joint limit or exchange of
   limits. These are comparison-correction norms, not total-state
   probabilities. The free comparison's cross terms remain relevant.

## Finite evidence, reproduction and preserved failures

After the pre-evidence freeze, the complete 130-line author-check document,
230-line final helper, bookkeeping scripts, baseline logs, all five literal
mutation differences and full failure logs were inspected. The earlier
227-line helper differs only by inverse caching and recursive simplification;
its 120-second timeout is preserved as an incomplete execution. No success
was inferred from its partial output. The final author run recorded 38
finite controls and exit zero. The five defect copies fail at the claimed
Schur-sign, real-resolvent-sign, forcing-sign, source-phase-derivative and
chi-squared-weight assertions. Their literal one-change provenance matches.

The author baseline was replayed once with fresh logs under this review
directory. It exited zero in approximately 24.963 seconds with empty stderr.
All 38 finite controls reproduced. Replay is reproducibility evidence, not
an additional independent analytic proof. The author fixture's I=17/36 is
a finite weighted sum, not an approximation adopted as the continuum I0.
Its projector/idempotency checks alone would not prove the full continuum
kernel or its spectral type; the explicit analytic kernel proof supplies
that conclusion.

The independently authored `boost_forcing_review/independent_controls.py`
was written and run before opening author evidence. It derives all three
spin generators from actual Pauli matrices, checks a separate exact
positive-projector singlet weight, and preserves the finite-bath recurrence.
An augmented ODE independently evolves a finite forced state and all three
kappa derivatives using the actual e(kappa,x), w(kappa,x) and their
derivatives. Its comparison uses matrix exponentials, Frechet derivatives
and the real resolvent. Across five positive/negative times, the largest
state discrepancy was approximately 2.935e-14 and the largest derivative
discrepancy was 1.780e-13. Reversing the source sign, halving its normalization
or omitting the source-phase derivative gives discrepancies about 1.443,
0.361 and 0.0424, respectively, at the fixed diagnostic time. These finite
controls discriminate the stated defects; they do not certify uniform
nonstationary phase, absolute continuity or infinite-time decay.

The independently written identity verifier matched all 64 author-receipt
file records, all ten original/copy source pairs, fourteen recorded
instruction-byte identities, the five literal defect copies and the two
historical publication-source hashes. The directly read receipt and all
pre-author review artifacts remain unchanged. Identity counts have no
mathematical evidentiary weight. The historical PR-source comparison is
bounded to the saved heads; neither current remote PR state nor exhaustive
novelty is certified here. No external theorem from the cited Friedrichs
paper is imported or needed.

The existing finite-bath matrix has `A^3=A` and dressing amplitude
`(9+16cos t)/25`, returning to one at `2pi n`. It satisfies the block
algebra but lacks the cone lower bound, so it remains a counterexample to
decay inferred from block structure alone. The author's resonant scalar
response `it exp(-ite)` also correctly grows linearly outside the actual
frequency-gap hypotheses. The previous mixed-band low-total-energy
counterexample, nonzero differential bracket coefficient, small-positive-
time diagonal residual-norm obstruction, and cone-concentrating failure
of uniform state convergence are preserved on their original scopes.
This review does not recertify every unrelated parent bracket calculation.

One reviewer inventory command included a directory in `wc -l` and exited
one; the subsequent author-check read in that shell command did not run.
The source reads were rerun separately and completed. A `diff -u` command
returned its normal exit one for the displayed optimization difference.
Neither event was a mathematical test failure. The independent controls,
identity verifier and final baseline replay each completed successfully.

## Safe reuse and recovery

Applicable repository entry points, SCIENCE_WORKFLOW and reviewer procedures
were read from main instruction revision
`a13caa4885f547c8d206265b031ba7649e539fd9`, with planning AGENTS at
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The assigned science worktree
was inspected at `773321aa8fdfccc05248682dfc96bf94215034a2`. The author's
receipt records its earlier supplied head `47cb1150396d0ed387f7ee6bd157dda156713f9e`;
the external mathematical inputs were checked by their exact hashes, not
assumed identical merely from branch ancestry. No remote freshness claim is
made.

This review supports downstream conditional use of the frozen K result with
the named source hypotheses and limit order. It does not confer formal
retained status, establish physical covariance or a complete boost algebra,
assess the separate quantitative-corrector research, or enlarge the axiom
stack. No Lean certification is claimed or required to interpret this
selective analytic check. Any changed load-bearing source or premise needs
affected-source review before reusing this result.

Only this review and `boost_forcing_review/` were written. Frozen sources,
author evidence, repository files, PRs and audit state were not changed.
**No editable prompt file changed.** The fixed campaign deadline remained
2026-10-12 16:00:52 UTC. Complete reconstruction, logs, actual commands,
identities, receipt and current checkpoint are in `boost_forcing_review/`.
