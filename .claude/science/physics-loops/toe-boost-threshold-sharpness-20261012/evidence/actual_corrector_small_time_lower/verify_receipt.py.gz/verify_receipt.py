#!/usr/bin/env python3
"""Check frozen bytes and recorded execution provenance; not theorem validity."""
from pathlib import Path
import hashlib,json,subprocess

def check(blob,expected,label):
    actual=hashlib.sha256(blob).hexdigest()
    if actual!=expected:raise ValueError(f'hash mismatch: {label}: {actual} != {expected}')

def main():
    p=Path(__file__).resolve().parent;r=json.loads((p/'receipt.json').read_text())
    assert r['schema']=='actual-corrector-small-time-lower-receipt-v1'
    assert Path(r['packet_path']).resolve()==p
    note=p.parent/'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md'
    rows=r['files'];names=[x['path'] for x in rows];assert len(set(names))==len(names)
    for row in rows:
        path=(p/row['path']).resolve();assert path==note or p in path.parents
        b=path.read_bytes();check(b,row['sha256'],row['path']);assert len(b)==row['bytes'] and len(b.splitlines())==row['lines']
    inventory={'../'+note.name}|{x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file() and x.relative_to(p).as_posix() not in r['excluded_post_freeze_outputs'] and '__pycache__' not in x.parts}
    assert inventory==set(names),'unbound or missing file'
    print(f'Exact source/evidence bindings and inventory: {len(rows)} matched')
    sources=json.loads((p/'source_manifest.json').read_text())
    for row in sources:
        original=Path(row['source']).read_bytes();copied=(p/row['copy']).read_bytes()
        check(original,row['sha256'],row['source']);check(copied,row['sha256'],row['copy']);assert original==copied and len(original)==row['bytes'] and len(original.splitlines())==row['lines']
    print(f'Original scientific sources and exact copies: {len(sources)} matched')
    instructions=json.loads((p/'instruction_manifest.json').read_text())['items']
    for row in instructions:
        b=subprocess.run(['git','show',f"{row['ref']}:{row['path']}"],cwd=r['read_only_worktree'],capture_output=True,check=True).stdout
        check(b,row['sha256'],row['path'])
    print(f'Read-only exact-ref instructions: {len(instructions)} matched')
    base=json.loads((p/'baseline.execution.json').read_text());assert base['exit_code']==0 and base['command'][1]==str(p/'actual_lower_controls.py')
    check((p/'actual_lower_controls.py').read_bytes(),base['source_sha256'],'executed baseline')
    assert (p/'baseline.stderr.log').read_text()==''
    output=json.loads((p/'baseline.stdout.log').read_text());assert output['controls_completed']==36 and len(output['records'])==36
    baseline=(p/'actual_lower_controls.py').read_text();mutants=json.loads((p/'mutation_manifest.json').read_text());assert len(mutants)==7
    for row in mutants:
        assert baseline.count(row['before'])==1
        changed=(p/row['paths']['source']).read_text();assert changed==baseline.replace(row['before'],row['after'],1)
        check(baseline.encode(),row['baseline_sha256'],'mutant baseline');check(changed.encode(),row['mutant_sha256'],row['name'])
        assert row['exit_code']==1 and row['caught_at_intended_check']
        assert json.loads((p/row['paths']['execution']).read_text())==row
        assert 'AssertionError: '+row['expected_assertion'] in (p/row['paths']['stderr']).read_text()
    mex=json.loads((p/'mutations.execution.json').read_text());assert mex['exit_code']==0
    check((p/'run_mutations.py').read_bytes(),mex['source_sha256'],'executed mutation runner')
    assert (p/'mutations.stderr.log').read_text()==''
    print(f'Executed 36-control baseline and {len(mutants)} intended literal failures matched')
    priors=json.loads((p/'prior_frozen_identity_check.json').read_text());total=0
    for row in priors:
        packet=Path(row['packet']);receipt=packet/'receipt.json';check(receipt.read_bytes(),row['receipt_sha256'],str(receipt));old=json.loads(receipt.read_text())
        assert len(old['files'])==row['checked_bound_files']
        for item in old['files']:
            path=Path(item['path']);path=path if path.is_absolute() else packet/path
            check(path.read_bytes(),item['sha256'],str(path));total+=1
    print(f'Prior frozen Q/S/K receipts and {total} source/evidence bindings unchanged; no scientific re-review')
    nr=next(x for x in rows if x['path']=='../'+note.name);changed=bytearray(note.read_bytes());changed[0]^=1
    try:check(bytes(changed),nr['sha256'],'one-byte in-memory tamper')
    except ValueError:print('One-byte in-memory tamper rejected; original unchanged')
    else:raise AssertionError('tamper accepted')
    print('Byte/execution provenance verification complete; S dependency and new scientific review remain pending')

if __name__=='__main__':main()
