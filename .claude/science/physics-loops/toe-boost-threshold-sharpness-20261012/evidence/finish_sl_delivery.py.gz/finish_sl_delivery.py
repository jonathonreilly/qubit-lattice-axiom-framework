"""Verify and stage the complete S/L publication after its scoped checks."""
from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys

S = Path(__file__).resolve().parent
W = S.parent / 'quantitative_boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-threshold-sharpness-20261012'
BASE = '36d6069676f561d81ad693f286dd52f570fb37df'
os.chdir(W)
sys.path.insert(0, str(W / 'scripts'))
import runner_cache
sha = lambda b: hashlib.sha256(b).hexdigest()
notes = json.loads((P / 'PUBLICATION_EDITS.json').read_text())['outputs']
primaries = json.loads((P / 'PRIMARY_COMPOSITION.json').read_text())['outputs']
mutants = json.loads((S / 'sl_primary_mutations/manifest.json').read_text())['runs']
assert len(mutants) == 13
for r in mutants:
    body = (W / r['primary_path']).read_text()
    assert sha(body.encode()) == r['primary_sha256']
    d = S / 'sl_primary_mutations'
    variant = (d / (r['name'] + '.py')).read_text()
    assert body.count(r['before']) == 1 and variant == body.replace(r['before'], r['after'], 1)
    assert sha(variant.encode()) == r['source_sha256']
    out, err = (d / (r['name'] + '.stdout')).read_bytes(), (d / (r['name'] + '.stderr')).read_bytes()
    assert sha(out) == r['stdout_sha256'] and sha(err) == r['stderr_sha256']
    assert r['exit_code'] == 1 and not r['timed_out'] and r['intended_failure'] and r['stdout_baseline_prefix']
    assert ('AssertionError: ' + r['expected_assertion']) in err.decode()
    assert r['elapsed_seconds'] < r['timeout_seconds'] == 120
executions, comparisons = {}, []
for label, folder in [('S', 'hstar_threshold_spectral'), ('L', 'actual_corrector_small_time_lower')]:
    e = json.loads((S / f'sl_{label}_canonical_execution.json').read_text())
    executions[label] = e
    assert e['status'] == 'ok' and e['exit_code'] == 0 and e['stderr'] == '' and e['timeout_sec'] == 120
    old = (S / folder / 'baseline.stdout.log').read_text()
    assert e['stdout'].startswith(old)
    extra = e['stdout'][len(old):].splitlines()
    assert len(extra) == 7
    comparisons.append(dict(label=label, complete_original_stdout_identical=True,
                            original_stdout_bytes=len(old.encode()), appended_lines=extra))
(S / 'SL_canonical_output_comparison.json').write_text(json.dumps(dict(checks=comparisons), indent=2) + '\n')
graph = W / 'docs/audit/data/citation_graph_manifest.json'
old = json.loads(subprocess.check_output(['git', 'show', BASE + ':' + str(graph.relative_to(W))]))
new = json.loads(graph.read_text())
assert (new['node_count'], new['edge_count']) == (old['node_count'] + 2, old['edge_count'] + 4)
assert all(new['nodes'].get(k) == v for k, v in old['nodes'].items())
assert {k: v['out_degree'] for k, v in new['nodes'].items() if k not in old['nodes']} == {
    'hstar_threshold_spectral_bounded_theorem_note_2026-10-12': 1,
    'actual_corrector_small_time_lower_bounded_theorem_note_2026-10-12': 3}
compat = json.loads((S / 'sl_focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []
(P / 'ROOT_COMPOSITION_REVIEW.md').write_text('''# Root composition check

Root read both complete arguments, every new author helper and complete
baseline, all13 literal defect changes and full tracebacks, then both finished
independent reports and their reconstructions/controls at the coverage stated
in the preserved root records. Root proposed both mechanisms and is a
contributor, not another independent reviewer.

The complete original notes remain recoverable. Publication edits add claim
metadata, portable dependencies and actual review/recovery status. No equation,
estimate, domain assumption or proof argument is altered. Both primaries retain
their whole original helper, with only explicit input/timeout/assertion/scope
metadata. Full original stdout is reproduced, and all13 complete-primary
defects fail at their intended checks.

The physical parity, global mean projection, eight cones, zero atom, full
local measure, signed Jacobian, noncommuting order, both primitive endpoints,
changing source, complete forcing error and ordered limits remain explicit.
All earlier K/Q science and adverse witnesses remain unchanged. Finite-mesh
controls are not continuum proofs. No axiom, editable prompt, Lean certificate,
physical realization, retained status or applied audit verdict is changed.
''')
(P / 'DELIVERY_CHECKS.md').write_text(f'''# Scoped publication verification

Final canonical S execution exited0 in{executions['S']['elapsed_sec']:.9f}s;
L exited0 in{executions['L']['elapsed_sec']:.9f}s. Each used its declared120s
timeout and has empty stderr. The complete original stdout is byte-identical;
each primary adds seven explicit resolution/scope lines. Both retain all36
original finite controls and reject optimized assertions. Cache and declared
input identities are fresh. Runtime versions remain in the full outputs.

Thirteen actual complete-primary defects fail at their intended assertions:
six physical spectral/projection/normalization defects and seven actual-error
mean/endpoint/sign/order/derivative/forcing defects. Every source, command,
timeout, stdout and stderr is preserved. All preceding outputs match the fully
read original baselines. The author and independent analytic arguments, not
these finite fixtures, establish the conditional continuum conclusions.

The citation graph has{new['node_count']}nodes and{new['edge_count']}edges:
two new theorem nodes and four declared dependency edges; every old node is
unchanged. Focused changed-audit-evidence compatibility selected no applied
rows and reported no failures. Global combined audit pipeline and strict
audit lint were not run and remain independent landing gates.

Exact source reconstruction, syntax, ordinary local links, evidence identities,
vocabulary fix/report, whitespace and the exact staged set are verified before
commit. Only the permitted citation manifest is included from audit data.
No empirical fit or confidence interval applies; no Lean certificate is claimed.
''')
history = P / 'REVIEW_HISTORY.md'
history.write_text(history.read_text().split('\n## Publication conformance\n', 1)[0] + '''
## Publication conformance

Both complete notes state the supplied physical setup, exact dependencies,
all definitions and proofs, quantifiers and limits. Their full sources,
selective independent reconstructions and separate evidence roles are retained.
Actual canonical runs and complete-primary defect executions are source-bound.
Failed routes and reviewer-control failures remain recoverable. Claim type,
conditional status, trace, goal, approaches, imports and recovery are explicit.
Publication maps recover every note and control byte. Portable references and
the two-node/four-edge citation change are checked. All numeric diagnostics
remain finite controls; no fit or count is treated as a continuum proof.
No draft, merge, main push, axiom or prompt edit, retained-status promotion or
applied audit is included. Global pipeline and strict lint are unrun gates.
''')
editable = sorted(P.glob('*.md')) + [W / r['publication_path'] for r in notes + primaries] + [P / 'reconstruct.py']
for mode in ['fix', 'report-only']:
    target = S / ('sl_final_vocab_' + mode)
    r = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--' + mode,
                        '--report-path', str(target.with_suffix('.json'))]
                       + [str(p.relative_to(W)) for p in editable], capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout + r.stderr)
    assert r.returncode == 0
r = subprocess.run([sys.executable, str(P / 'reconstruct.py')], capture_output=True)
(S / 'sl_final_reconstruction.log').write_bytes(r.stdout + r.stderr)
assert r.returncode == 0
for row in primaries:
    ast.parse((W / row['publication_path']).read_text())
    assert runner_cache.cache_status(row['publication_path']) == runner_cache.cache_identity_status(row['publication_path']) == 'fresh'
links = []
for path in editable:
    if path.suffix != '.md':
        continue
    prose, fenced = [], False
    for line in path.read_text().splitlines():
        if line.lstrip().startswith('```'):
            fenced = not fenced
            continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for target in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        assert (path.parent / unquote(target.split('#', 1)[0])).resolve().exists(), (path, target)
        links.append(dict(source=str(path.relative_to(W)), target=target))
emap = json.loads((P / 'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}

def preserve(src):
    b = src.read_bytes()
    dst = P / 'evidence' / (str(src.relative_to(S)) + '.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(b, mtime=0)
    if dst.exists() and dst.read_bytes() != packed:
        prior = rows.pop(str(dst.relative_to(P)))
        oldpath = dst.with_name(dst.stem + '.previous_' + prior['sha256'][:12] + dst.suffix)
        assert not oldpath.exists() or oldpath.read_bytes() == dst.read_bytes()
        if oldpath.exists():
            dst.unlink()
        else:
            dst.rename(oldpath)
        prior['preserved'] = str(oldpath.relative_to(P))
        prior['historical_source_version'] = True
        rows[prior['preserved']] = prior
    dst.write_bytes(packed)
    rows[str(dst.relative_to(P))] = dict(original=str(src), preserved=str(dst.relative_to(P)), bytes=len(b), sha256=sha(b))

for src in sorted((S / 'sl_primary_mutations').rglob('*')):
    if src.is_file():
        preserve(src)
for name in ['prepare_sl_primaries.py', 'prepare_sl_notes.py', 'prepare_sl_packet.py',
             'run_sl_primary_mutants.py', 'finish_sl_delivery.py',
             'sl_S_canonical_execution.json', 'sl_L_canonical_execution.json', 'SL_canonical_output_comparison.json',
             'sl_initial_vocab_fix.json', 'sl_final_vocab_fix.json', 'sl_final_vocab_fix.log',
             'sl_final_vocab_report-only.json', 'sl_final_vocab_report-only.log', 'sl_final_reconstruction.log',
             'sl_citation_execution.json', 'sl_citation_build.stdout', 'sl_citation_build.stderr',
             'sl_citation_manifest.stdout', 'sl_citation_manifest.stderr',
             'sl_focused_audit_compat.json', 'sl_focused_audit_compat.stderr', 'sl_focused_audit_compat.execution.json']:
    preserve(S / name)
for row in rows.values():
    b = gzip.decompress((P / row['preserved']).read_bytes())
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
mechanical = dict(full_note_and_primary_reconstruction=True, actual_whole_primary_mutants=13,
                  preserved_evidence_files=len(rows), cache_and_inputs_fresh=True, ordinary_links=links,
                  citation_delta=dict(nodes=2, edges=4), every_old_graph_node_unchanged=True,
                  scope='Mechanical verification with separately identified analytic source reviews; not an audit verdict')
out = S / 'sl_delivery_mechanical.json'
out.write_text(json.dumps(mechanical, indent=2) + '\n')
preserve(out)
emap['files'] = [rows[k] for k in sorted(rows)]
(P / 'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2) + '\n')
files = [W / r['publication_path'] for r in notes + primaries] + [graph] + [
    runner_cache.cache_path_for(r['publication_path']) for r in primaries] + [
    p for p in P.rglob('*') if p.is_file() and p != P / 'SOURCE_IDENTITIES.json']
ident = []
for path in sorted(set(files)):
    row = dict(path=str(path.relative_to(W)), sha256=sha(path.read_bytes()))
    if path.suffix == '.gz':
        row['decompressed_sha256'] = sha(gzip.decompress(path.read_bytes()))
    ident.append(row)
(P / 'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,
    scope='Exact intended publication files except this manifest itself.', files=ident), indent=2) + '\n')
paths = [r['path'] for r in ident] + [str((P / 'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git', 'add', '--'] + paths, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for row in ident:
    assert sha(subprocess.check_output(['git', 'show', ':' + row['path']])) == row['sha256']
staged = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().split('\0')) - {''}
assert staged == set(paths)
assert not subprocess.check_output(['git', 'diff', '--name-only'])
result = dict(staged_files=len(paths), staged_hashes_match=True, whitespace_clean=True, **mechanical)
(S / 'sl_final_staged_verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
