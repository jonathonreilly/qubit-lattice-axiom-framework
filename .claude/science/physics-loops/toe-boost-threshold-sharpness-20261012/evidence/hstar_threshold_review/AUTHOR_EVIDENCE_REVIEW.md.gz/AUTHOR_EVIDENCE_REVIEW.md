# Author evidence examined after the independent freeze

The independent reconstruction and finite checks were frozen at
2026-10-12T01:06:41.812751+00:00. `AUTHOR_ACCESS.json` records the later
opening of the new author evidence. The complete original author directory
was then preserved as `author_snapshot/`. No author artifact was changed.

## Complete reading and byte coverage

Read completely: the 145-line AUTHOR_CHECK, 182-line threshold control,
41-line mutation runner, 35-line freeze script, 62-line verifier, receipt,
both manifests, literature note, workspace provenance and checkpoint. The
baseline's full stdout/stderr and execution metadata were inspected, as
were all six mutation stdout/stderr/metadata sets and both post-freeze
receipt execution/output sets.

All six 182-line mutation sources were compared in their entirety with the
fully read baseline. Each file equals the baseline with exactly the one
declared literal replacement and no other changed byte; every changed
line and its context were inspected. This gives complete source coverage
without rereading 181 unchanged lines six times. The complete comparisons
and every old output are saved in
`author_reproduction/complete_mutation_comparison.log` and the snapshot.

The two target-listed older X review/reconstruction documents were also read
in full after this review's freeze. They do not supply independent evidence
for the new threshold theorem. Every mathematical source copy named in the
author manifest matches the original bytes and the review's recovery copy.

## Code-to-claim checks

The author's finite fixture starts from literal Pauli matrices at three
weighted antipodal pairs and one global contact projection. It tests the
physical action and longitudinal square before the scalar resolvent. Its
rank count correctly distinguishes the excluded auxiliary singlet from the
physical kernel. The finite I0 is computed from the fixture and is not
advertised as the torus integral. The chiral identity and signed resolvent
are tested against the actual physical matrix, including a negative-real-
part spectral parameter.

The leading cone-volume derivative and the separate arcsine convolution
are mathematically correct. The expected coefficient is derived rather
than inserted into the prediction. The first density correction and the
principal-value model expression have the stated exact limits. These
controls do not replace the analytic uniform-boundary or complete-measure
arguments.

The separate radial probability density (3/2)sqrt(y) on (0,1) has I0=3,
source mass 3/5 and zero atom 1/3. Direct integration after y=u^2 gives
F(z)=3[sqrt(z)atanh(1/sqrt(z))-1] with the upper-half-plane branch and
negative imaginary part. Its two-sided signed density has total
complementary mass 4/15. The direct Cauchy and mass checks discriminate
the sign and square-map Jacobian. The two primitive integrations use
different numerical arrangements with the correct full-line factor.

One numerical detail is approximate rather than symbolic: below 1e-4 the
radial remainder helper substitutes its limiting value
(2-pi^2/4)/6. This is consistent with a numerical diagnostic; it is not an
exact quadrature or proof of the torus error bound. The record already
labels all these computations as diagnostics, and no source correction is
needed. The continuum analytic proof is independent of that helper.

No hard-coded torus I0 value, fitted prefactor, proxy substituted for the
physical matrix, literal-True decisive gate or unused physical input was
found. The target's known constants are explicit comparison targets.
Mutation sensitivity establishes only sensitivity to those selected
defects, not completeness of the proof.

## Reproduction and source binding

`reproduce_author.py` independently verified the exact 47-entry author
receipt inventory, seven original/source-copy identities, fourteen pinned
instruction-file identities, and both excluded post-freeze output bindings.
The latter records hash the receipt, executable and complete stdout/stderr,
so no circular self-hash is inferred. The original receipt SHA is
`384a4a5f62310a3f77a138467690f14bbd51042ced9ede6aa3a51a861eddfc92`.

Fresh executions used the unchanged copied baseline and each unchanged
copied mutant, with logs written only under this review directory. The
baseline exited 0; each of the six mutants exited 1 at its intended
assertion. All stdout was byte-identical to the original records; all
stderr was identical after the expected snapshot path substitution. The
read-only original receipt verifier was also rerun and exited 0. These
are reproductions, not independent scientific calculations. Full logs and
individual source/output hashes are in `author_reproduction/`.

The reviewer reproduction harness exited 0 with empty stderr. It also
confirmed that the independent pre-author reconstruction, calculation code,
successful run and preserved initial failed run remain at their frozen
identities. The numerical results and asserted scopes in AUTHOR_CHECK
agree with the complete outputs. No additional source defect or required
correction emerged from this evidence phase.

## Limits

The author's source freeze and its verifier are bookkeeping. The author
and root remain coauthors. This reviewer shares the stated target and
physical premises, but froze new analysis and a separate implementation
before opening the new author evidence. No Lean or other proof-kernel
verification was performed. No audit status, physical identification,
full-slow lower bound or empirical conclusion is supplied by these files.
