# Independent reconstruction before author-control access

Target: the 445-line `HSTAR_THRESHOLD_SPECTRAL_PROBE.md`, SHA-256
`6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da`.
This reconstruction was written from the target and the complete frozen B,
T, X, E and root-lead source notes. The new author executable, author check,
logs, mutation sources and receipt have not been opened. Constants stated
in the target are already known to this reviewer; independence means a new
calculation and implementation, not blindness to the proposed statement.
Root proposed the mechanism and is a coauthor, not this review's checker.

The hypotheses below specify a supplied mathematical model. They are not
derived physical premises, a physical boost law or a retained audit result.
No result from the concurrent quantitative Q note is used.

## 1. Physical space and bounded operator: S3–S5

Let dmu=dq/(2pi)^3 on the complete three-torus. The normalized singlet c
has swap eigenvalue -1. Put T_j=sigma_(1,j)c. Direct Pauli multiplication
gives <T_i,T_j>=delta_ij and makes T_j a triplet basis. The antisymmetry
u(-q)=-S_swap u(q) therefore means an even scalar coefficient of c and
odd coefficients of T_j. The projection P removes the single constant
singlet functional on this full space: P=I-|c><c|. It is not a pointwise
removal of every singlet and does not introduce an exchange factor.

At K=0, the supplied Pauli symbol is

    H0=(sigma_1-sigma_2).sin(q).

Its singlet/triplet matrix is [[0,2s^T],[2s,0]], s=sin(q). This also follows
independently by evaluating the literal 4 by 4 spin matrices. Write h=2|s|
and n=s/|s| almost everywhere. The eight torus zero points are null sets.
An odd triplet vector u has v=n.u even and u_tr=u-vn odd and pointwise
orthogonal to n. Thus the singlet/longitudinal physical sector is isometric
to E0 direct-sum E, where E is scalar even L2(dmu), E0={f in E:<1,f>=0},
and U(f,v)=fc+v sum_j n_j T_j. Its orthogonal complement is the transverse
triplet sector. Every vector and norm keeps the full normalized torus.

For f in E0, define Af=hf in E. The adjoint is A*v=P0(hv), with
P0=I-|1><1| on E. Indeed <Af,v>=<f,hv>=<f,P0 hv>. Consequently

    U*H*U=[[0,A*],[A,0]],
    L=AA*=M_(h^2)-|h><h|,
    <v,Lv>=||P0 hv||^2=||hv||^2-|<h,v>|^2.

This fixes the rank-one sign by a factorization. Positivity alone would
not choose it. All maps are bounded on the indicated complete Hilbert
spaces. In particular the calculation never applies the unbounded dipole
or a q derivative to a singular zero mode.

Finiteness of I0=integral h^-2 dmu is elementary. The integrand is periodic
with period pi in each coordinate. On Q=[-pi/2,pi/2]^3, |sin q|>=2|q|/pi.
Therefore

    I0=(4pi^3)^-1 integral_Q |sin q|^-2 dq
       <=(16pi)^-1 integral_(|q|<=pi sqrt(3)/2)|q|^-2 dq
       =pi sqrt(3)/8.

The mean of h^2 is 6. Strict Cauchy–Schwarz applied to h and 1/h gives
1=<h,1/h>^2<6 I0 because h is nonconstant. Hence 6-1/I0 is positive.
Since h>0 almost everywhere, Af=0 forces f=0. The equation A*v=0 is
hv=constant and has precisely span{1/h} as its L2 solutions. Thus the
entire physical kernel consists of the transverse sector and the unit
longitudinal vector zeta_long=(h sqrt(I0))^-1. The excluded c is absent.

The source is h0=U(0,h). It has no transverse part; its norm squared is 6.
Its kernel projection and complement are exactly

    Pi h0=U(0,1/(I0 h)),
    Qh0=U(0,h-1/(I0 h)),
    ||Pi h0||^2=1/I0,  ||Qh0||^2=6-1/I0.

These statements reconstruct S3–S5 without importing the conclusion of
the earlier T12 kernel calculation.

## 2. Direct source resolvent and atom: S6–S7

Put Y=h^2 and F(z)=integral (z-Y)^-1 dmu. This is the transform of a
probability measure nu on [0,12], with strictly negative imaginary part
for Im z>0. Let v=(z-L)^-1 h and g=<h,v>. The pointwise equation is

    (z-Y)v+h g=h,  so v=(1-g)h/(z-Y).

Pairing with h yields g=(1-g)g0, where
g0=integral Y/(z-Y)dmu=zF(z)-1. Thus

    G(z)=<h,(z-L)^-1 h>=1-1/(zF(z)).

No conjugate of the right resolvent belongs in this equation. Since z and
F(z) are nonzero in the upper half-plane, its denominator cannot vanish.
The corresponding operator formula is R0-R0|h><h|R0/(1+g0), which can be
verified by multiplication; the direct scalar equation already suffices
for this source measure. The spectral theorem applies because L is bounded
self-adjoint and positive and h is L2. Its scalar measure is finite, total
mass 6.

For a>0, F(-a) tends to -I0 by dominated convergence with dominating
function 1/Y. Since the L spectrum is nonnegative, another dominated
convergence, now of a/(a+s), gives

    mu_h^L({0})=lim_(a->0)(-a)G(-a)=1/I0.

This agrees with the actual kernel overlap above. It is not a boundary
density proof: the real positive spectral axis still needs analysis.

## 3. Actual torus density and all cones: S8–S10

For a single uniform torus coordinate, y=4sin^2 q has four preimages in
(-pi,pi] except at endpoints. Their total change-of-variables density is

    p(y)=1/(pi sqrt(y(4-y))),  0<y<4.

The three independent coordinates give the distribution of their sum Y.
For 0<s<4, the convolution contains no upper-cutoff faces. Put y_j=s t_j,
with t_j>=0 and t_1+t_2+t_3=1. Its density is sqrt(s) a(s), where

    a(s)=(2pi)^-3 integral_simplex
           (t_1 t_2 t_3)^-1/2
           product_j(1-s t_j/4)^-1/2 dt_1 dt_2.

The simplex integral of the first factor is 2pi: substitute
t_1=u, t_2=(1-u)v, t_3=(1-u)(1-v); the Jacobian leaves the product
u^-1/2 [v(1-v)]^-1/2. Its integrals are 2 and pi. Thus
a(0)=a*=1/(4pi^2), and differentiation under this integrable simplex
weight gives a'(0)=a*/8 because sum t_j=1. This is an independent
coordinate derivation of the target's eight-cone coefficient.

For comparison, folding the torus into Q multiplies by eight, then
u_j=2sin q_j gives dq=1/8 product_j(1-u_j^2/4)^-1/2 du. Thus the full
prefactor is (8pi^3)^-1. Spherical r^2=s contributes sqrt(s)/2 and sphere
area 4pi, giving the identical a*. These factors cannot be divided by
two for parity: the Hilbert norms were never halved.

The integrand is analytic in s for |s|<4 under an integrable majorant on
each smaller complex disk. Its first logarithmic derivative on [0,1] is
at most 1/[8(1-s/4)] and its second at most 1/[32(1-s/4)^2]. Its second
ordinary derivative is therefore at most its value times
3/[64(1-s/4)^2]. With

    A0=a*(4/3)^(3/2), B0=A0/6, B1=A0/24,

this proves 0<a<=A0, |a'|<=B0, |a''|<=A0/12. Setting
b(s)=(a(s)-a*)/s=integral_0^1 a'(theta s)dtheta also proves
||b||<=B0 and ||b'||<=B1, including the removable value at s=0.

The independent code also checks the next relative coefficient, 11/640,
from the Dirichlet moments. That extra coefficient is a consistency check
and is not required by S1 or S2.

## 4. Boundary values at real positive energy: S11–S14

Fix a closed interval J strictly inside (0,1). On [1,12], the transform
of the finite measure is analytic in a neighborhood of J. On (0,1), write
rho(y)=sqrt(y)a(y) and subtract rho(x) at each x in J:

    integral_0^1 rho(y)/(x+i eta-y)dy
      =integral_0^1 [rho(y)-rho(x)]/(x+i eta-y)dy
        +rho(x)[log(x+i eta)-log(x-1+i eta)].

Use the upper-half-plane logarithms. Their limit is log[x/(1-x)]-i pi.
For y close to x, rho is uniformly Lipschitz on a larger compact interval;
the first integrand is bounded by a uniform constant. Its integral on a
neighborhood of radius r is at most 2Cr independently of eta. Away from
that neighborhood, the denominators stay uniformly nonzero and convergence
is uniform, with an integrable majorant even at y=0. First take eta down
to zero away from the neighborhood and then r down to zero. This proves
uniform convergence on J, continuity of the limit, and

    F_+(x)=PV integral dnu(y)/(x-y)-i pi sqrt(x)a(x).

This is an actual real-axis boundary limit. It did not interchange that
limit with the negative-axis endpoint limit.

For 0<s<=1/4, subtract -I0 and combine fractions. The real part becomes

    Re F_+(s)+I0
      =s PV integral_0^1 a(y)/(sqrt(y)(s-y))dy
        +s integral_[1,12] dnu(y)/(y(s-y)).

For the constant a* contribution, substitute y=u^2. An antiderivative of
2/(s-u^2) gives exactly

    a* sqrt(s) log[(1+sqrt(s))/(1-sqrt(s))].

It is positive and bounded by (8a*/3)s because
log[(1+x)/(1-x)]<=2x/(1-x^2) for 0<=x<=1/2. The remainder a(y)-a*=y b(y)
introduces g(y)=sqrt(y)b(y). For y,s in [0,1],
|g(y)-g(s)|<=(B0+B1)|y-s|^(1/2). Therefore

    PV integral_0^1 g(y)/(s-y)dy
      =integral_0^1 [g(y)-g(s)]/(s-y)dy
        +g(s)log[s/(1-s)].

The first term is bounded by 4(B0+B1). The second is bounded by 2B0
(in fact B0 is enough on this range). The remaining high-energy term
has magnitude at most 4s/3, using y>=1 and nu([1,12])<=1. Thus

    |Re F_+(s)+I0|<=C_F s,
    C_F=8a*/3+6B0+4B1+4/3,
    Im F_+(s)=-pi sqrt(s)a(s).

Every explicit constant in S13 is valid. For
delta=min(1/4,I0/(2C_F)), the real part has magnitude at least I0/2.
Writing Re F_+=-I0+R, |R|<=C_F s, gives

    ||F_+(s)|^2-I0^2|
      <=[2I0 C_F+C_F^2 delta+pi^2 A0^2]s=K_F s.

This proves S14, including the stronger O(s) error in the squared modulus.

## 5. Full local spectral measure, not merely its density: S15

For each compact J inside (0,delta), the preceding uniform boundary limit
and the lower bound on F_+ imply uniform convergence of
G(x+i eta)=1-1/[(x+i eta)F(x+i eta)] to a finite continuous function on J.
Writing F_+=u-i pi rho gives

    -(1/pi)Im G_+(s)=rho(s)/(s|F_+(s)|^2).

For any x in J, boundedness of G(x+i eta) implies no atom there: the
Poisson-kernel identity and dominated convergence give
mu_h^L({x})=lim_(eta->0)[-eta Im G(x+i eta)]=0. For any closed subinterval
[a,b] of J, Stieltjes inversion then has no endpoint half-masses. Uniform
convergence allows the limit through the finite interval integral, yielding

    mu_h^L([a,b])=integral_a^b rho(s)/(s|F_+(s)|^2)ds.

Equality on intervals determines the entire restricted finite measure.
A countable cover by compact intervals excludes singular continuous and
point mass throughout (0,delta). At zero the entire measure is the atom
already calculated, 1/I0. No theorem about spectral type on [delta,12] is
needed. This fully discharges the possible hidden-singular-mass objection.

The imported theorem is Teschl 3.21 for a finite Borel measure, with
Teschl's transform (A-z)^-1. Our (z-A)^-1 has the opposite imaginary sign.
The original statement and complete inversion proof were checked, including
the half-endpoint weights. Teschl 3.1 and 3.7 supply the functional calculus
for a self-adjoint operator. The original URL and fetched byte identity are
recorded separately; no global rank-one theorem is imported.

## 6. Signed H* measure and projection: S16–S17, S1

The longitudinal grading Gamma(f,v)=(-f,v) anticommutes with H* and fixes
h0=U(0,h). Functional calculus therefore makes its scalar H* spectral
measure symmetric under E->-E. The measure of H* squared in this vector
is the measure of L in h. For a Borel set B in (0,delta),

    mu_h^L(B)=mu_h0^H*(sqrt(B))+mu_h0^H*(-sqrt(B))
             =2 mu_h0^H*(sqrt(B)).

Consequently the branch factor 1/2 cancels ds/dE=2|E|:

    rho_h0^H*(E)=|E|rho_L(E^2)
               =a(E^2)/|F_+(E^2)|^2,
               0<|E|<sqrt(delta).

This transformation applies to the entire measure just identified, so it
does not discard a singular contribution. Its zero mass stays 1/I0. As
another sign check, the block resolvent gives <h0,(w-H*)^-1 h0>=wG(w^2).
For negative real w approached from above, w^2 approaches from below;
conjugation reproduces the same nonnegative signed density.

Q removes the full H* kernel. For this source its sole zero mass is 1/I0,
already identified by the actual kernel projection. After removal, the
measure is absolutely continuous on the entire open neighborhood of zero:
any remaining measure supported just at zero would be an atom, whose mass
is now zero. With c_th=a*/I0^2 and e0=sqrt(delta),

    |rho_Qh0(E)-c_th|
       <=(4B0/I0^2+4a*K_F/I0^4) E^2=C_rho E^2.

Indeed split a(s)/|F|^2-a*/I0^2 into the numerator difference and the
denominator difference and use |F|^2>=I0^2/4. This proves S17 and S1.
The positive constant is a source-specific density, not a scalar dispersion
or a classification of the whole physical spectrum.

## 7. Free primitive and uniform absolute remainder: S18–S19, S2

Take lambda>0 and real t. Bounded functional calculus gives the multiplier

    m_(lambda,t)(E)=lambda(1-exp(-itE/lambda))/(iE),
    m_(lambda,t)(0)=t.

The source Qh0 has no mass at zero, so its squared norm is exactly the
S18 spectral integral. Put M=6-1/I0. The portion |E|>=e0 is bounded by
4lambda^2 M/e0^2 with no assumption about its spectral type. The local
density error contributes at most 8C_rho e0 lambda^2. Replacing the local
constant density integral by its full-line integral costs at most
8c_th lambda^2/e0.

The full-line integral of 4sin^2(x/2)/x^2 is 2pi. To derive it without
another imported theorem, put D_epsilon(a)=integral_0^infinity
exp(-epsilon x)(1-cos(ax))/x^2 dx for epsilon>0. Twice differentiating in
a under exponential domination gives D_epsilon''(a)=epsilon/(epsilon^2+a^2).
Since D_epsilon(0)=D_epsilon'(0)=0, its first derivative is
arctan(a/epsilon); integrating in a and taking epsilon down to zero gives
D_0(a)=pi|a|/2 by monotone convergence. Evenness and
4sin^2(x/2)=2(1-cos x) supply the full-line factor 2pi. The independent
finite diagnostic also compares a continuum time autocorrelation integral
against direct spectral integration. Scaling x=tE/lambda now yields

    | ||J_lambda(t)||^2 -2pi c_th |t|lambda |
       <=[8C_rho e0+8c_th/e0+4M/e0^2]lambda^2.

The bracketed constant is finite and independent of lambda and t. It is
an absolute error statement even at t=0 or t depending on lambda; a
relative asymptotic requires an additional scale condition. The target
uses only fixed t!=0, for which division by lambda and taking a square
root prove S2 with coefficient 1/(2pi I0^2). Negative t gives the same
squared norm. At t=0 the exact norm is zero.

No continuum limiting assertion was inferred from a fixed finite matrix.
After its kernel is removed, a fixed finite matrix has finitely many
nonzero energies and gives an O(lambda) primitive, so the order of limits
would be wrong for the threshold question.

## 8. Actual initial direction and scope: S20

The original X20 error equation has r_X=Q(Bz-g), z(0)=0 and
g=c0 h0 a, c0=(2pi)^(-3/2). Therefore its actual initial direction is
r_X(0,kappa)=-c0 a(0,kappa)Qh0 with the sign displayed in the target.
The K-only rescaling uses Lebesgue dkappa and keeps dmu in q. The source
amplitude from X7 is

    a(0,kappa)=F(kappa)/Z0 integral f(x)w(kappa,x)dx.

The specified F and f are nonnegative, ||F||_2=1, m=integral f>0,
w>=1/4 on the support and Z0>0 is a single global normalizer. Hence
||a(0)||>=m/(4Z0)>0. The free H* operator is kappa-independent; integrating
the squared fiber result gives S20, including c0 squared and the same
|t|/(2pi I0^2) factor. This is a theorem about the time-frozen initial
forcing under the free fast generator.

It does not replace r_X(s,kappa) by r_X(0,kappa) in the actual evolution.
Nor does it replace H*/lambda+B+E_lambda by H*/lambda. In fact the direct
Duhamel comparison with an arbitrary bounded B has propagator difference
at most |u| ||B||, which bounds the primitive difference by a constant
times t^2, with no lambda factor. Such a bound cannot transfer a fixed-t
sqrt(lambda) lower bound. No full actual-error lower bound, boost
expectation rate, optimal growing-time window or physical identification
follows from this calculation.

## 9. Excluded shortcuts and consistency failures

If the zero atom is left in h0, its primitive contributes exactly t^2/I0
to the squared norm, orthogonally to the complementary primitive. The
source projection is essential.

To solve H*(f,v)=Qh0 in the longitudinal block, the second component
requires f=1-1/(I0 h^2). Its formal mean is zero, but its square is not
integrable at any three-dimensional cone: h is comparable to distance,
and the radial integral is proportional to integral_0^epsilon r^-2 dr.
Adding a longitudinal kernel vector or transverse triplet cannot change
this compulsory singlet coefficient. The local positive spectral density
also gives integral E^-2 dmu_Qh0=infinity. This excludes this inverse
construction, not all routes to the actual dynamical error.

The independent finite-check program initially overcounted the sectors in
its auxiliary cube integration of I0. It used 48 although q=(r,ru,rv)
orders only the largest coordinate and already includes both orders of
the other two; the correct factor is 8 times 3=24. The separate Laplace
integral exposed this reviewer error. Its source, execution metadata,
stdout, traceback and diagnosis are preserved under failed_initial_check/.
The corrected program changes only this reviewer cubature factor. It
does not change the frozen source or the analytic proof above.

## 10. Pre-author analytic disposition

No mathematical correction is required to S1–S20 on the frozen supplied
model. The proof obligations close conditionally on that model and the
standard finite-measure spectral calculus. The real boundary limit and
the complete local measure are established analytically; finite numerical
controls will only check algebra, factors and conventions. A final review
still requires inspection of the new author evidence and its exact source
bindings. No formal Lean verification has been performed, and no audit or
retained status is assigned.
