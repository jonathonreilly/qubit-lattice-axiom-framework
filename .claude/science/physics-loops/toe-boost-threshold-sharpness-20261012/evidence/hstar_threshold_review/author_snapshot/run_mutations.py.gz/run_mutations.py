#!/usr/bin/env python3
"""Execute actual literal defect copies without overwriting evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

p=Path(__file__).resolve().parent
src=p/'threshold_controls.py';baseline=src.read_text()
assert not (p/'mutation_manifest.json').exists(), 'refusing to overwrite defect evidence'
defects=[
 ('missing_mean_projection','A = mh*P0','A = mh','direct_physical_off_diagonal_map'),
 ('wrong_rank_one_sign','Llong = mh**2-hsrc*hsrc.H','Llong = mh**2+hsrc*hsrc.H','physical_longitudinal_square'),
 ('missing_eight_cones','cone_count = 8','cone_count = 1','eight_cone_coefficient_independent_convolution'),
 ('wrong_signed_density_Jacobian','density_factor = 1.0','density_factor = 2.0','signed_measure_half_and_square_root_Jacobian'),
 ('wrong_upper_boundary_sign','boundary_sign = -1.0','boundary_sign = 1.0','upper_boundary_sign_0.03'),
 ('unremoved_source_atom','rq = hsrc-zlong/sp.sqrt(Ifinite)','rq = hsrc','Q_source_zero_atom_removed'),
]
rows=[]
for name,before,after,expected in defects:
    assert baseline.count(before)==1, name
    changed=baseline.replace(before,after,1)
    mutant=p/('mutant_'+name+'.py');assert not mutant.exists();mutant.write_text(changed)
    argv=['/opt/homebrew/opt/python@3.13/bin/python3.13',str(mutant)]
    start=time.monotonic();cp=subprocess.run(argv,capture_output=True,text=True,timeout=120)
    paths={'source':mutant.name,'stdout':'mutant_'+name+'.stdout.log',
           'stderr':'mutant_'+name+'.stderr.log','execution':'mutant_'+name+'.execution.json'}
    (p/paths['stdout']).write_text(cp.stdout);(p/paths['stderr']).write_text(cp.stderr)
    row={'name':name,'before':before,'after':after,'expected_assertion':expected,
         'command':argv,'timeout_seconds':120,'exit_code':cp.returncode,
         'elapsed_seconds':time.monotonic()-start,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'baseline_sha256':hashlib.sha256(baseline.encode()).hexdigest(),
         'mutant_sha256':hashlib.sha256(changed.encode()).hexdigest(),
         'caught_at_intended_check':cp.returncode==1 and 'AssertionError: '+expected in cp.stderr,
         'paths':paths}
    (p/paths['execution']).write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
(p/'mutation_manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'defects_executed':len(rows),'caught_at_intended_check':[r['name'] for r in rows if r['caught_at_intended_check']]},indent=2))
assert all(r['caught_at_intended_check'] for r in rows)
