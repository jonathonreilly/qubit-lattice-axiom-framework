# Independent reconstruction of the fixed-time expectation theorem

Target: the complete 587-line `BOOST_CURRENT_EXPECTATION_PROBE.md`, SHA-256
`a7161d796001df4af243263acbd03e731d75d0eab2d93795f4b5960eff5acb68`.
This reconstruction is written and frozen before opening the current author's
`AUTHOR_CHECK.md`, control sources, logs, completion evidence or receipt.
The mathematical target itself supplies the proposed proof and describes
checks; this is independent checking, not blinded discovery.

## Source boundary and exact conclusion

The complete B source (744 lines, SHA `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923`),
E source (185 lines, SHA `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929`),
T source (658 lines, SHA `76ed691c581d4da282041b99fa53da48d1461b47ddccb765b736969a191b4990`),
T review (167 lines, SHA `d3c3d00b69b302beb88aef4a1b649f5e685ff7a08bc2c117755fcafde4d74796`),
and its separate reconstruction (329 lines, SHA `c0a06917dc1f24207d85656781e250104c81dd613a9a937a140088149bf2f131`)
have been read. Necessary arguments are reconstructed below; the earlier
review's result label is not a mathematical premise. The B source reproduces
the canonical energy placement and the complete compressed-current calculation,
so its historical upstream reports are not needed as additional premises here.

The supplied data are the sine-Pauli two-particle Hamiltonian, the antisymmetric
sector, the single full-torus contact projection, the chosen momentum chart,
integer coordinates, continuous clock, symmetric local energy placement, and
exact B25–B30 preparation. No framework primitive or physical identification is
derived by the theorem. The claim is, for each of the nine ordered pairs a,b
and each fixed finite T,

    sup_{|tau|<=T} |<psi_lambda(tau/lambda),R_ab psi_lambda(tau/lambda)>|/lambda -> 0.

The source also claims an H1_kappa(L2_q) limit of the exact forced correction
and the resulting residual-vector limit. It does not claim an off-diagonal
norm lower bound, vanishing residual norm at this scale, a growing rescaled
time interval, an unrestricted operator estimate, or full physical covariance.

## A. Operators, normal form and the common domain

The fiber is the antisymmetric part of L2(T^3,dq/(2pi)^3;C2 tensor C2), restricted
to ran P. With the constant unit singlet c, C=|c><c| and P=I-C, write

    H0=sigma_1.sin(K/2+q)+sigma_2.sin(K/2-q), H=PH0P,
    D_a=i(H partial_Ka+Dcal_a),
    Dcal_a=P[(Hdelta/2)partial_qa+partial_Ka H0]P.

The common core has smooth periodic q dependence, smooth compact K support,
antisymmetry and P membership. The fixed projection P preserves it. The fiber
adjoint is Dcal_a^dagger=-P(Hdelta/2)partial_qa P because
partial_qa Hdelta=2 partial_Ka H0. Therefore
Dcal_a+Dcal_a^dagger=partial_Ka H, and integration in K proves D_a is symmetric.
No exponentiation or self-adjoint extension of D_a is required.

For h=H0 c, h_b=partial_Kb h, and g_b=sin K_b cos(2q_b), the canonical
compressed current is the bounded self-adjoint operator

    J_b=P g_b P-|h_b><h|-|h><h_b|.

The dipole contact blocks are CD0,a P psi=i c<h,partial_Ka psi> and
PD0,a C(c f)=i partial_Ka(h f). Combining them with the free bracket gives

    -i[D_a,Pg_bP]psi
      =delta_ab P ell_a P psi-partial_Ka(h<r_b,psi>)
          +r_b<h,partial_Ka psi>, r_b=g_b c.

For F_b=-|h_b><h|-|h><h_b|, the remaining bracket is
[H,F_b]partial_Ka+H partial_Ka F_b+[Dcal_a,F_b]. Its right rank actions use
the displayed fiber adjoint. This gives exactly B12–B14/T4/X25, with

    R_ab=C_ab(K)+A_b(K)partial_Ka, A_b=[H,J_b],
    C_ab=delta_ab P(ell_a-H0)P+B_ab.

Every term of B_ab is a bounded finite-rank operator with q derivatives
applied only to its smooth form factors, not to the input. Its coefficients
and all K derivatives are smooth in bounded-operator norm. Consequently R
extends continuously H1_K(L2_q)->L2 on fixed compact K support.

The B full-torus term sums give ||A_b||<=12lambda and ||C_ab||<=32 on
|K|<=lambda/4. The stronger supported-input bounds carry the volume factor
eta<=lambda^(3/2)/4. They may be used for f_free and its K derivatives,
but not for the evolved correction or its full-torus contact tail.

For every fixed lambda>0 and finite physical time, the actual initial state
is in the common core: its projector is evaluated only away from the band
zeros and is multiplied by smooth compact supported envelopes. H0 and H have
bounded commutators with first derivatives and bounded higher coefficient
derivatives; P commutes with the periodic q derivatives. Duhamel iteration
propagates every finite Sobolev order, and multiplication in K preserves
the compact support. Thus psi, v and w at those finite times are legitimate
common-core vectors. Uniform high-order bounds in lambda are neither needed
nor claimed.

## B. Global normalization, support and the exact source

For p(t)=(1-t^2)^2 on (-1,1), direct integration gives int p^2=256/315 and
int(p')^2=256/105. After scaling by 8sqrt(3), the normalized product F0 has
each derivative norm 24. The radius-1/512 convolution changes its L2 norm by
at most 24sqrt(3)/512<1/8. Global renormalization gives the specified smooth
F with ||F||=1, derivative norms <=192/7, and support radius 65/512<1/4.
The radial annular f is smooth, nonnegative, even, L2-normalized and has
positive integral. These are the actual B envelopes, not replacements.

On their support y_+=x+kappa/2 and y_-=x-kappa/2 have norm at least 1/2.
The positive-positive singlet weight is

    w_lambda=(1+sin(lambda y_+).sin(lambda y_-)
                  /(|sin(lambda y_+)||sin(lambda y_-)|))/4.

The numerator dot product is positive there, by the exact sine-square
identity and the separation between q and K/2, so 1/4<=w_lambda<=1/2.
Both momenta are small and their positive energy sum lies between lambda
and 2lambda. The two normalized momentum measures yield lambda^6/(2pi)^6;
the square of the packet prefactor (2pi)^3 lambda^-3 cancels it. Hence

    Z_lambda^2=int |F|^2 |f|^2 w_lambda, 1/2<=Z_lambda<=1/sqrt(2).

The even envelope and exchange-covariant projector ensure antisymmetry.
Projecting with P removes one global q-singlet mean in each K fiber and
produces a tail over the whole torus. The two subsequent norms Z_lambda
and n_lambda are scalars over K and q, so neither has a K derivative.

For the exact free contact coefficient at t=s/lambda, the q substitution
q=lambda x cancels the packet prefactor and normalized q measure, giving

    a_lambda(s,kappa)=F(kappa)/Z_lambda
          int f(x) w_lambda(kappa,x) exp[-is e_lambda(kappa,x)]dx,
    e_lambda=(|sin(lambda y_+)|+|sin(lambda y_-)|)/lambda.

In particular a_lambda is a fiber amplitude, not a rescaled state norm.
The isometry T_lambda u=c0 lambda^(3/2)u(lambda kappa,q), with
c0=(2pi)^(-3/2), rescales K only. It gives exactly

    n_lambda^2=1-c0^2 lambda^3 ||a_lambda(0)||^2 ->1,
    T_lambda partial_Kj=lambda^-1 partial_kappaj T_lambda.

Because the scaled sine arguments stay separated from zero, the symbols
extend smoothly to lambda=0 on fixed supports. The first kappa derivatives
and their first time derivatives converge uniformly for bounded s, by
differentiating fixed-support integrals. Both projector-weight and phase
derivatives are included. The limiting source is the X7 expression a(s,kappa).

B30 follows by bounding the two contact cross terms in the energy by
4lambda eta^2 and using the positive free-band interval. It leaves the
energy expectation in [lambda/2,3lambda], which is conserved. It supplies
no exact interacting spectral support and is not used to prove the new
expectation cancellation.

## C. Actual forcing and smooth generator expansion

With f_free=exp(-itH0)phi, v=P f_free/n and w=psi-v, direct differentiation
gives i v'=H v+h<c,f_free>/n. Therefore i w'=H w-h<c,f_free>/n,
w(0)=0, and

    w(t)=i/n int_0^t exp[-i(t-s)H]h<c,f_free(s)>ds.

The sign is positive. No separate homogeneous initial tail may be added:
psi and v agree at time zero. This formula already includes the full contact
subtraction and its forcing. On setting W=lambda^-1/2 T_lambda w(tau/lambda),
the time Jacobian cancels the remaining scaling, and

    W(tau)=i int_0^tau U_lambda(tau-s)g_lambda(s)ds,
    i W'=G_lambda W-g_lambda, W(0)=0,
    G_lambda=H(lambda kappa)/lambda,
    g_lambda=c0 h(lambda kappa)a_lambda/n.

Splitting the sine symbol into difference-spin times sin q cos(K/2) and
total-spin times cos q sin(K/2) gives

    G_lambda=H_*/lambda+B(kappa)+E_lambda,
    B=sum_j kappa_j V_j, V_j=P[(sigma_1j+sigma_2j)cos q_j/2]P,
    ||E_lambda||+sum_j||partial_j E_lambda||=O(lambda),
    h(lambda kappa)=h0+O(lambda^2) in C1.

The cosine remainder divided by lambda is O(lambda), including its first
kappa derivative; the sine remainder is smaller. Each V_j is bounded
self-adjoint, and Pi below is independent of kappa. Direct differentiation
of the original sine-Pauli H also gives ||partial_j G_lambda||<=1.

The bounded-operator Duhamel derivative is

    partial_j U_lambda(r)=-i int_0^r U_lambda(r-u)
                                 (partial_j G_lambda)U_lambda(u)du,

so its norm is <=|r|. Differentiating W includes exactly the propagator,
form factor and source factors. Their bounds, compact support and
g_lambda->g=c0 h0 a in C1 give uniform H1_kappa(L2_q) bounds for W on
each fixed finite tau interval.

## D. Gapless forcing: direct sign check and a separate proof

Let Pi be the exact kernel projection of bounded self-adjoint H_* and Q=I-Pi.
The author's cutoff calculation uses S_delta=1_{|H_*|>=delta} and
x_delta=H_*^-1 S_delta r. Since H_*=lambda(G_lambda-V_lambda),
partial_s U_lambda(t-s)=i U_lambda(t-s)G_lambda and product integration gives

    int_0^t U_lambda(t-s)S_delta r(s)ds
     =-i lambda[U_lambda(t-s)x_delta(s)]_0^t
        +i lambda int_0^t U_lambda(t-s)x'_delta(s)ds
        -lambda int_0^t U_lambda(t-s)V_lambda x_delta(s)ds.

All three signs and the order of V_lambda are correct. No commutation is
used. The compact family of Q-valued r(s,kappa) is uniformly approximated
by S_delta r by a finite-net argument, giving precisely the bound X17.
First lambda->0 at fixed delta, then delta->0 proves the asserted uniform
limit. The inverse appears only behind the cutoff.

For an additional analytic check using a different perturbative organization,
define the *free* primitive

    F_lambda(t)=int_0^t exp(-iu H_*/lambda) Q du, 0<=t<=T.

For a fixed x in ran Q, its nonzero-energy multiplier is
lambda(1-exp(-itE/lambda))/(iE), with absolute value bounded uniformly in
t by min(T,2lambda/|E|). There is no zero-energy spectral mass for x.
Dominated convergence against its finite spectral measure proves

    sup_{0<=t<=T}||F_lambda(t)x|| ->0.

This is uniform on every compact family of x by a finite net and
||F_lambda(t)||<=T. It is not uniform over the Q unit ball.

For any continuous Q-valued r on the compact (s,kappa) domain, approximate
r uniformly by a finite time-step function whose values r(s_j,kappa) form
compact families. The error in its free forced integral is at most T times
the uniform approximation error. Each step integral is a difference of two
F_lambda primitives acting on one compact family, so its norm vanishes
uniformly in t,kappa. The number of time steps is fixed before lambda->0.
It follows that

    y0_lambda(t)=int_0^t exp[-i(t-s)H_*/lambda]r(s)ds ->0

uniformly on the compact domain. This proof only needs continuity of r;
the source's C1 time hypothesis is more than sufficient.

For the *perturbed* forced integral y_lambda=int U_lambda r, variation of
constants around the free generator gives the exact Volterra equation

    y_lambda(t)=y0_lambda(t)
       -i int_0^t exp[-i(t-s)H_*/lambda]V_lambda y_lambda(s)ds.

With ||V_lambda||<=M, its norm obeys
sup_{u<=t}||y_lambda(u)||<=sup_{u<=T}||y0_lambda(u)|| exp(Mt)
by the integral Gronwall estimate. Therefore the same uniform limit holds
for the perturbed integral. This independently checks the noncommuting,
gapless conclusion of X14 without differentiating the perturbed propagator
inside the cutoff proof or assuming any spectral gap or global inverse.
It applies equally to each of the finitely many derivative residual fields
below. Negative times follow by reversing time and generator signs.

## E. Effective forced state and all first derivatives

On ran Pi let A=Pi B Pi and

    z(tau)=i int_0^tau exp[-i(tau-s)A]Pi g(s)ds.

This is well-defined on the fixed kernel space, A is bounded self-adjoint,
and i z'=A z-Pi g. The parameter derivatives exist by bounded-operator
differentiation; z and all its first kappa and time derivatives are jointly
continuous and bounded on compact sets. They have the same compact kappa
support as F. Since Pi is fixed, Pi z=z and Pi partial_j z=partial_j z.

For D=W-z, subtraction of the two evolution equations gives exactly

    i D'=G_lambda D+r+e_lambda, D(0)=0,
    r=Q(Bz-g), e_lambda=E_lambda z+g-g_lambda.

The residual r is a fixed Q-valued field satisfying the gapless lemma.
The remaining error tends uniformly to zero with its first kappa derivatives.
Unitarity for e_lambda and either proof in D for r yield uniform D->0 in
fiber L2 for |tau|<=T and kappa on the fixed compact set.

For each j=1,2,3, differentiating this *exact error equation* gives

    i(partial_j D)'=G_lambda partial_j D
       +(partial_j G_lambda)D+partial_j r+partial_j e_lambda,
    partial_j r=Q(V_j z+B partial_j z-c0 h0 partial_j a).

The first source tends uniformly to zero by ||partial_j G_lambda||<=1 and
D->0. The final error source tends uniformly to zero because e_lambda->0
in C1. The middle fixed
Q-valued source again satisfies the gapless lemma, including its time
derivative. With zero initial derivative, all three differentiated Duhamel
integrals vanish. Compact support then proves

    sup_{|tau|<=T}||W_lambda-z||_{H1_kappa(L2_q)} ->0.

There is no inference of derivative convergence from L2 convergence alone.
In particular the propagator's parameter response is retained through
(partial_j G_lambda)D, and the phase derivative stays in partial_j a.

The explicit kernel description is also checked from the supplied operator.
At K=0 the singlet/triplet matrix of H0 is [[0,2s^T],[2s,0]], s_j=sin q_j.
For H_*u=0 in ran P, H0 u=beta c; its singlet component vanishes almost
everywhere and its longitudinal triplet part is beta s/(2|s|^2). The
remaining part is pointwise transverse. Defining

    I0=int dmu/(4|s|^2), zeta=sum_j s_j T_j/(2|s|^2 sqrt(I0)),

gives the orthogonal decomposition Pi=F_transverse+|zeta><zeta| and
Pi h0=zeta/sqrt(I0). Folding the eight sine-square cells and bounding
1/|sin q|^2 by pi^2/(4|q|^2) on [-pi/2,pi/2]^3 gives
1/12<=I0<=pi sqrt(3)/8. Thus zeta is an admissible L2 vector in dimension
three. The auxiliary c is excluded. The transverse space remains present
in Pi B Pi, so no unjustified scalar phase approximation is used. Neither
this kernel argument nor the expectation proof applies D_a to zeta.

## F. All nine limiting forms and symmetry

Write v_b=sin q_b T_b and v0=sum_j v_j. At K=0, h=2v0, h_b=0 and
partial_Ka h_b=-delta_ab v_b/2. Therefore both canonical rank terms give
the positive contribution

    partial_Ka J_b(0)=delta_ab L_b,
    L_b=P cos(2q_b)P+|v_b><v0|+|v0><v_b|.

J_b(0)=0 as an operator, including its q dependence. Consequently
[Dcal_a,J_b](0)=0 on the core. The constant coefficient of the exact
bracket there is H partial_Ka J_b+[Dcal_a,J_b]-delta_ab H, so

    C_ab(0)=delta_ab H_*(L_b-I),
    A_b(lambda kappa)/lambda -> kappa_b[H_*,L_b].

The bounded smooth normal form extends these identities to all fiber L2
vectors, including zeta. Hence, on the fixed support,

    Q_lambda,ab=C_ab(lambda kappa)
                    +[A_b(lambda kappa)/lambda]partial_a,
    Q_0,ab=delta_ab H_*(L_b-I)+kappa_b[H_*,L_b]partial_a,
    Q_lambda,ab->Q_0,ab in norm H1_kappa(L2_q)->L2.

On the common core, J_b is bounded self-adjoint and preserves the core,
while D_a is symmetric. It follows directly that -i[D_a,J_b]-delta_ab H
is symmetric. Smooth core vectors are dense in the compact-support
H1_K(L2_q) space (regularize, impose antisymmetry and apply P). Continuity
of the normal form therefore extends the pairing identity to this Sobolev
domain, without requiring any q derivative of the limit vectors.

The coefficient check reaches the same conclusion: A_b^*=-A_b and
C_ab-C_ab^*=partial_Ka A_b. Indeed the adjoint of A_b partial_Ka is
A_b partial_Ka+partial_Ka A_b after integration by parts. The limiting
identity is explicitly

    delta_ab[H_*,L_b]=partial_a(kappa_b[H_*,L_b]).

For a kernel-valued H1 field z, H_*z=H_*partial_a z=0. Thus for every
ordered pair a,b,

    Q_0,ab z=H_*L_b(delta_ab z+kappa_b partial_a z)
              =H_*L_b partial_a(kappa_b z),
    <z,Q_0,ab z>=0.

The last identity holds already in the fiber for almost every kappa:
the output lies in ran H_*, which is orthogonal to ker H_*. For a!=b,
partial_a kappa_b=0 and the constant term also vanishes. This is the full
index calculation; no diagonal-only premise is silently generalized.
The vector Q_0,ab z need not vanish. This is a quadratic-form cancellation,
not a zero residual vector or an off-diagonal lower bound.

## G. Every term of the actual expectation

For |tau|<=T, f_free(tau/lambda) retains its relative support and
lambda||partial_Ka f_free||<=B_a+T. The supported estimates, plus the
global multiplier tail already retained in E13, give

    ||R_ab v||<=[4lambda^3+eta(32+12B_a+12|tau|)]/n
                    =O_T(lambda^(3/2)).

Also ||v||=O(1) and ||w||=sqrt(lambda)||W||=O_T(sqrt(lambda)). All
finite-lambda vectors lie in the common core, so the exact pairing
<v,Rw>=<Rv,w> is legitimate. Using psi=v+w and the K isometry gives

    <psi,R_ab psi>/lambda
     =<v,R_ab v>/lambda+2Re<R_ab v,w>/lambda
          +<W,Q_lambda,ab W>.

The first term is O_T(sqrt(lambda)); the cross terms are O_T(lambda).
This is the place where symmetry is load-bearing: the crude separate
bound on ||R w|| would not suffice. No v-w orthogonality is assumed.

The H1 convergence from E and coefficient convergence from F imply
<W,Q_lambda W>-><z,Q_0 z> uniformly for bounded tau. Expanding into the
three source terms (W-z in the first slot, Q_lambda-Q_0 in the middle,
and W-z in the final slot) makes every norm estimate valid. The limit is
zero by the kernel action in F. This proves X1 for all nine components,
including tau=0 and negative bounded tau.

There is a correctly stated weaker-topology consistency check: because
Q_0 is symmetric,

    <W,Q_0 W>-<z,Q_0 z>
       =<W-z,Q_0 W>+<Q_0 z,W-z>.

Thus the expectation alone follows already from uniform strong L2
convergence and a uniform H1 bound. The stronger H1 convergence is needed
for the claimed residual-vector limit

    lambda^-1/2 T_lambda R_ab psi(tau/lambda)->Q_0,ab z(tau),

since the free-comparison term after this rescaling is O_T(lambda).
The proof provides that stronger convergence rather than relying only on
the weaker expectation argument.

## H. Compatibility, remaining scope and pre-evidence disposition

The previous T small-tau diagonal result is consistent: z'(0)=i Pi g(0),
so Q_0,bb z(tau)=tau Gamma_b+O(tau^2) in L2. The complete current rank
terms give H_*L_b zeta=(|sin q|^2/3-sin^2 q_b)c/sqrt(I0). Its mean is
zero and squared scalar norm is 1/12. The dilation pairing for compact
a0 gives ||partial_b(kappa_b a0)||>=||a0||/2>0. Thus the leading diagonal
residual can be nonzero and of order sqrt(lambda) even while its pairing
with the leading forced state vanishes. No off-diagonal norm lower bound
is inferred from this compatibility check.

The inherited mixed-band counterexample and nonzero differential coefficient
are preserved. They concern different quantified classes; X1 neither
contradicts them nor establishes a uniform low-energy operator identity.
The conclusion remains conditional on the supplied dynamics, clock,
placement and exact packet. Full boost closure, physical Lorentz covariance,
gravity, other preparations and unbounded rescaled time are outside scope.

No material mathematical defect or unresolved proof obligation was found
in X1–X35 on the frozen source. The new analytic mechanism has been checked
both through its actual cutoff proof and through the separate free-primitive
Volterra argument above. No new finite scientific runner was selected:
there is no residual uncertainty for which a finite matrix computation
would discriminate the actual infinite-dimensional assertion. The current
author's controls and provenance remain to be inspected; they will not be
used to replace this proof reconstruction or to grant audit status.
