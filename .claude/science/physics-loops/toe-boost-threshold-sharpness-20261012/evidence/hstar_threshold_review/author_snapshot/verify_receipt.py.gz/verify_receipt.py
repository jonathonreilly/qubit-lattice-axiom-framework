#!/usr/bin/env python3
"""Verify exact author bytes and recorded execution provenance only."""
from pathlib import Path
import hashlib,json,subprocess

def check(blob,expected,label):
    actual=hashlib.sha256(blob).hexdigest()
    if actual!=expected:raise ValueError(f'hash mismatch: {label}: {actual} != {expected}')

def main():
    p=Path(__file__).resolve().parent;r=json.loads((p/'receipt.json').read_text())
    assert r['schema']=='hstar-threshold-spectral-receipt-v1'
    assert Path(r['packet_path']).resolve()==p
    assert r['mathematical_status']=='conditional-author-result; independent-review-pending'
    note=p.parent/'HSTAR_THRESHOLD_SPECTRAL_PROBE.md'
    rows=r['files'];names=[x['path'] for x in rows];assert len(set(names))==len(names)
    for row in rows:
        path=(p/row['path']).resolve();assert path==note or p in path.parents
        b=path.read_bytes();check(b,row['sha256'],row['path'])
        assert len(b)==row['bytes'] and len(b.splitlines())==row['lines']
    inventory={'../'+note.name}|{x.relative_to(p).as_posix() for x in p.rglob('*')
      if x.is_file() and x.relative_to(p).as_posix() not in r['excluded_post_freeze_outputs'] and '__pycache__' not in x.parts}
    assert inventory==set(names),'unbound or missing file'
    print(f'Bound source/evidence files: {len(rows)} matched; inventory exact')
    sources=json.loads((p/'source_manifest.json').read_text())
    for row in sources:
        original=Path(row['source']).read_bytes();copied=(p/row['copy']).read_bytes()
        check(original,row['sha256'],row['source']);check(copied,row['sha256'],row['copy'])
        assert original==copied and len(original)==row['bytes'] and len(original.splitlines())==row['lines']
    print(f'Original scientific sources and copies: {len(sources)} matched')
    instructions=json.loads((p/'instruction_manifest.json').read_text())['items']
    for row in instructions:
        b=subprocess.run(['git','show',f"{row['ref']}:{row['path']}"],cwd=r['read_only_worktree'],capture_output=True,check=True).stdout
        check(b,row['sha256'],row['path'])
    print(f'Read-only exact-ref instructions: {len(instructions)} matched')
    base=json.loads((p/'baseline.execution.json').read_text())
    assert base['exit_code']==0 and base['command'][1]==str(p/'threshold_controls.py')
    check((p/'threshold_controls.py').read_bytes(),base['source_sha256'],'executed baseline')
    assert (p/'baseline.stderr.log').read_text()==''
    assert '"controls_completed": 36' in (p/'baseline.stdout.log').read_text()
    baseline=(p/'threshold_controls.py').read_text();mutants=json.loads((p/'mutation_manifest.json').read_text())
    for row in mutants:
        assert baseline.count(row['before'])==1
        changed=(p/row['paths']['source']).read_text()
        assert changed==baseline.replace(row['before'],row['after'],1)
        check(baseline.encode(),row['baseline_sha256'],'mutant baseline')
        check(changed.encode(),row['mutant_sha256'],row['name'])
        assert row['exit_code']==1 and row['caught_at_intended_check']
        assert json.loads((p/row['paths']['execution']).read_text())==row
        assert 'AssertionError: '+row['expected_assertion'] in (p/row['paths']['stderr']).read_text()
    print(f'Executed baseline and {len(mutants)} literal intended failures matched')
    primary=json.loads((p/'literature/teschl_source_identity.json').read_text())
    assert primary['sha256']=='8dc8de0b58aa0a3fedfe594a345f9b5875322e5526ea581cb640a98d55b82818'
    assert primary['copied_full_pdf_to_packet'] is False
    print('Primary theorem URL, recorded PDF fingerprint and read scope bound; no fresh network verification claimed')
    nr=next(x for x in rows if x['path']=='../'+note.name);changed=bytearray(note.read_bytes());changed[0]^=1
    try:check(bytes(changed),nr['sha256'],'in-memory one-byte tamper')
    except ValueError:print('In-memory one-byte tamper rejected; original unchanged')
    else:raise AssertionError('tamper accepted')
    print('Receipt byte/provenance verification complete; no mathematical or audit verdict')

if __name__=='__main__':main()
