#!/usr/bin/env python3
"""Freeze review outputs and exact input identities; no science verdict logic."""
from pathlib import Path
import datetime
import hashlib
import json

r=Path(__file__).resolve().parent
report=r.parent/'HSTAR_THRESHOLD_SPECTRAL_REVIEW.md'
excluded={'receipt.json','receipt_freeze.stdout.log','receipt_freeze.stderr.log',
          'receipt_freeze.execution.json','receipt_verification.stdout.log',
          'receipt_verification.stderr.log','receipt_verification.execution.json'}
assert not (r/'receipt.json').exists()
now=datetime.datetime.now(datetime.timezone.utc)
assert now < datetime.datetime(2026,10,12,16,0,52,tzinfo=datetime.timezone.utc)
files=[]
paths=[report]+sorted(p for p in r.rglob('*') if p.is_file()
                     and p.relative_to(r).as_posix() not in excluded
                     and '__pycache__' not in p.parts)
for p in paths:
    data=p.read_bytes()
    files.append(dict(path='../'+report.name if p==report else p.relative_to(r).as_posix(),
                      sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),lines=len(data.splitlines())))
receipt=dict(schema='hstar-threshold-independent-review-v1',frozen_at_utc=now.isoformat(),
             deadline_utc='2026-10-12T16:00:52Z',review_directory=str(r),
             review_disposition='PASS for S1-S20, conditional on the exact supplied model; no required repair',
             formal_retained_status_assigned=False,audit_operation=False,formal_verification_performed=False,
             target_sha256='6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da',
             target_lines=445,author_receipt_sha256='384a4a5f62310a3f77a138467690f14bbd51042ced9ede6aa3a51a861eddfc92',
             pre_author_freeze_sha256='8a10c007642e3b4adb1c8561d74ccb2398eac52ec835d93111c6725650742f85',
             independence='Reviewer did not coauthor the target. Target and exact premises shared; reconstruction and new finite checks frozen before new author evidence. Root and author remain coauthors.',
             evidence_classes=['independent analytic reconstruction','independent calculation before author access','author-code reproduction after freeze','read-only identity bookkeeping'],
             limitations=['Supplied physical model and packet, not derived physical identification',
                          'Free fast primitive and frozen initial residual only; no full noncommuting actual-error lower bound',
                          'No global spectral classification, boost expectation rate or optimal growing-time window',
                          'No Lean proof-kernel verification; numerical quadrature not continuum proof'],
             preserved_failures=['First reviewer cube cubature overcounted sectors by two; cross-check exposed it, complete failed evidence preserved',
                                 'Early source-inventory command used wrong cwd; second early git read used non-repository cwd',
                                 'pdftotext unavailable; primary passages read with web PDF text and fresh byte fingerprint matched'],
             changed_paths=['../HSTAR_THRESHOLD_SPECTRAL_REVIEW.md','hstar_threshold_review/ only'],
             changed_editable_prompt_files=[],git_mutations=[],other_chat_messages=[],subdelegation=False,
             model_and_effort='inherited without override',files=files,excluded_post_freeze_outputs=sorted(excluded),
             output_binding='Post-freeze execution metadata bind receipt, executable and full outputs; no circular self-hash.',
             verification_scope='The receipt verifies recovery/identity. It is not a mathematical proof or audit verdict.')
(r/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(receipt_sha256=hashlib.sha256((r/'receipt.json').read_bytes()).hexdigest(),
                      bound_files=len(files),frozen_at_utc=now.isoformat(),report_sha256=files[0]['sha256']),indent=2))
