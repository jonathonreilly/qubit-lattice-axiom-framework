#!/usr/bin/env python3
"""Independent finite consistency checks, written before author evidence access.

These do not prove continuum spectral type. The analytic proof is separately
recorded in PROOF_RECONSTRUCTION.md. No author helper is imported or executed.
"""
import json
import math
import platform
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.special import i0e, roots_jacobi
import sympy as sy


def emit(label, **data):
    print(json.dumps(dict(check=label, **data), sort_keys=True), flush=True)


emit("environment", python=platform.python_version(), numpy=np.__version__,
     scipy=scipy.__version__, sympy=sy.__version__)

# Start with the literal two-spin Pauli action, not the claimed reduced block.
I2 = sy.eye(2)
pauli = [sy.Matrix([[0, 1], [1, 0]]),
         sy.Matrix([[0, -sy.I], [sy.I, 0]]),
         sy.diag(1, -1)]
c = sy.Matrix([0, 1, -1, 0]) / sy.sqrt(2)
one = [sy.kronecker_product(p, I2) for p in pauli]
two = [sy.kronecker_product(I2, p) for p in pauli]
trip = [p * c for p in one]
V = sy.Matrix.hstack(c, *trip)
assert sy.simplify(V.conjugate().T * V - sy.eye(4)) == sy.zeros(4)
sx, syy, sz = sy.symbols("sx sy sz", real=True)
spin_h = sum((q * (a - b) for q, a, b in zip((sx, syy, sz), one, two)), sy.zeros(4))
block = sy.simplify(V.conjugate().T * spin_h * V)
expected = sy.Matrix([[0, 2*sx, 2*syy, 2*sz],
                      [2*sx, 0, 0, 0], [2*syy, 0, 0, 0], [2*sz, 0, 0, 0]])
assert block == expected
emit("exact_two_spin_action", block=str(block))

# A nonuniform three-orbit symmetric q quadrature. Each orbit represents q,-q
# with parity forced by the spin swap, so its total probability is p_j.
sr = sy.Matrix([[sy.Rational(3,10), sy.Rational(2,5), 0],
                [sy.Rational(2,5), -sy.Rational(1,5), sy.Rational(2,5)],
                [sy.Rational(27,35), sy.Rational(27,70), sy.Rational(9,35)]])
pr = [sy.Rational(1,5), sy.Rational(3,10), sy.Rational(1,2)]
hr = [2*sy.sqrt(sum(sr[j,k]**2 for k in range(3))) for j in range(3)]
assert hr == [1, sy.Rational(6,5), sy.Rational(9,5)]
vr = sy.Matrix([sy.sqrt(p)*h for p,h in zip(pr,hr)])
Lr = sy.diag(*[h*h for h in hr]) - vr*vr.T
zr = sy.Matrix([sy.sqrt(p)/h for p,h in zip(pr,hr)])
I0r = sy.simplify(sum(p/h**2 for p,h in zip(pr,hr)))
assert Lr*zr == sy.zeros(3,1)
z = sy.symbols("z")
F = sum(p/(z-h*h) for p,h in zip(pr,hr))
Gdirect = (vr.T * (z*sy.eye(3)-Lr).inv() * vr)[0]
Gclaim = 1-1/(z*F)
assert sy.factor(Gdirect-Gclaim) == 0
residue = sy.limit(z*Gdirect,z,0)
assert sy.simplify(residue-1/I0r) == 0
emit("exact_weighted_resolvent", h=[str(h) for h in hr],
     weights=[str(p) for p in pr], I0=str(I0r), residue=str(residue),
     G=sy.factor(Gdirect).__str__())

cn = np.array(c, dtype=complex).ravel()
pn = np.array(pr, dtype=float)
sn = np.array(sr, dtype=float)
hn = np.array(hr, dtype=float)
on = [np.array(a,dtype=complex) for a in one]
tn = [np.array(a,dtype=complex) for a in two]
H0 = np.zeros((12,12),dtype=complex)
long_embed = np.zeros((12,3),dtype=complex)
for j in range(3):
    H0[4*j:4*j+4,4*j:4*j+4] = sum(sn[j,k]*(on[k]-tn[k]) for k in range(3))
    long_embed[4*j:4*j+4,j] = sum((2*sn[j,k]/hn[j])*(on[k]@cn) for k in range(3))
cg = np.concatenate([math.sqrt(p)*cn for p in pn])
P = np.eye(12)-np.outer(cg,cg.conj())
H = P@H0@P
h0 = H0@cg
Ldirect = long_embed.conj().T@H@H@long_embed
Ln = np.array(Lr,dtype=complex)
square_error = np.linalg.norm(Ldirect-Ln)
assert square_error < 3e-14
evals,evecs = np.linalg.eigh(H)
zero = abs(evals)<1e-10
atom = float(np.sum(abs(evecs[:,zero].conj().T@h0)**2))
Qh = h0-evecs[:,zero]@(evecs[:,zero].conj().T@h0)
assert abs(atom-float(residue)) < 3e-14
assert abs(np.vdot(Qh,Qh).real-(np.vdot(h0,h0).real-float(residue))) < 3e-14
wn = np.sqrt(pn)*hn
Gerrors=[]
Herrors=[]
wrong_sign_errors=[]
for w in [0.31+0.47j,-0.82+0.29j,2.4+0.7j]:
    f = sum(p/(w-h*h) for p,h in zip(pn,hn))
    rhs = 1-1/(w*f)
    Gerrors.append(abs(np.vdot(wn,np.linalg.solve(w*np.eye(3)-Ldirect,wn))-rhs))
    f2 = sum(p/(w*w-h*h) for p,h in zip(pn,hn))
    hrhs = w*(1-1/(w*w*f2))
    Herrors.append(abs(np.vdot(h0,np.linalg.solve(w*np.eye(12)-H,h0))-hrhs))
    wrongL=np.diag(hn*hn)+np.outer(wn,wn)
    wrong_sign_errors.append(abs(np.vdot(wn,np.linalg.solve(w*np.eye(3)-wrongL,wn))-rhs))
assert max(Gerrors+Herrors)<3e-13
assert min(wrong_sign_errors)>0.01
missing_mean_error=np.linalg.norm(Ldirect-np.diag(hn*hn))
assert missing_mean_error>1
weights = abs(evecs.conj().T@h0)**2
symmetry_error=max(abs(evals+evals[::-1]))
nonzero_weights_error=max(abs(weights[~zero]-weights[~zero][::-1]))
assert max(symmetry_error,nonzero_weights_error)<3e-13
emit("literal_pauli_global_compression", square_error=float(square_error),
     ambient_zero_modes=int(zero.sum()), physical_zero_modes=int(zero.sum()-1),
     atom=atom, complementary_mass=float(np.vdot(Qh,Qh).real),
     max_resolvent_error=float(max(Gerrors+Herrors)),
     source_signed_measure_symmetry_error=float(nonzero_weights_error),
     wrong_plus_sign_min_resolvent_error=float(min(wrong_sign_errors)),
     missing_mean_projection_error=float(missing_mean_error))

# Two distinct actual-torus integrations of I0. The first splits the folded
# cube into 24 sectors q=(r,ru,rv) and removes its apparent radial singularity.
def cube_I0(n):
    x,w=np.polynomial.legendre.leggauss(n)
    rr=(x+1)*math.pi/4
    rw=w*math.pi/4
    u=(x+1)/2
    uw=w/2
    r=rr[:,None,None]
    denom=np.sin(r)**2+np.sin(r*u[None,:,None])**2+np.sin(r*u[None,None,:])**2
    weights=rw[:,None,None]*uw[None,:,None]*uw[None,None,:]
    return 6/math.pi**3*np.sum(weights*r*r/denom)

# E exp(-t Y) = exp(-6t) I_0(2t)^3 by the three independent cosine integrals.
# Change t=x^-2-1, so the infinite endpoint has a finite continuous limit.
def laplace_integrand(x):
    if x==0:
        return 2/(4*math.pi)**1.5
    t=1/(x*x)-1
    return 2*i0e(2*t)**3/x**3

I0lap,reported_error=quad(laplace_integrand,0,1,epsabs=2e-13,epsrel=2e-13)
I0cubes={str(n):float(cube_I0(n)) for n in [16,24,32,48]}
assert abs(I0cubes['48']-I0lap)<5e-12
assert 1/6<I0lap<math.pi*math.sqrt(3)/8
a0=1/(4*math.pi**2)
emit("actual_torus_I0_two_coordinates", cube_values=I0cubes,
     laplace_value=float(I0lap), quad_error_estimate=float(reported_error),
     difference=float(abs(I0cubes['48']-I0lap)),
     threshold_density=a0/I0lap**2, primitive_coefficient=1/(2*math.pi*I0lap**2),
     limitation="floating quadrature, not certified interval arithmetic")

# Compute the small-s coefficient from the three arcsine variables by a
# Dirichlet integral. This does not evaluate the sphere integral in the note.
exact_a0=sy.simplify(sy.gamma(sy.Rational(1,2))**3/sy.gamma(sy.Rational(3,2))/(2*sy.pi)**3)
assert exact_a0==1/(4*sy.pi**2)
u,wu=roots_jacobi(32,0,-.5);u=(u+1)/2;wu=wu/wu.sum()
v,wv=roots_jacobi(32,-.5,-.5);v=(v+1)/2;wv=wv/wv.sum()
x1=np.broadcast_to(u[:,None],(32,32))
x2=(1-u[:,None])*v[None,:]
x3=(1-u[:,None])*(1-v[None,:])
density_data=[]
for s in [.001,.005,.025,.1,.25,1.0]:
    ratio=float(np.sum(wu[:,None]*wv[None,:]/np.sqrt((1-s*x1/4)*(1-s*x2/4)*(1-s*x3/4))))
    density_data.append(dict(s=s,ratio=ratio,quadratic_residual=(ratio-1-s/8)/s**2))
assert abs(density_data[0]['quadratic_residual']-11/640)<4e-6
assert abs((a0/8)/a0-1)>.8
emit("dirichlet_convolution_density", exact_coefficient=str(exact_a0),
     exact_first_relative_coefficient="1/8", exact_second_relative_coefficient="11/640",
     data=density_data, missing_eight_cones_relative_error=7/8)

# For a continuum diagnostic use a held-out compact flat spectral density c.
# Integrate the time autocorrelation 2c sin(bu/lambda)/(u/lambda), rather than
# the claimed spectral multiplier; compare to the spectral integral separately.
ct=7/13; band=.83
primitive_data=[]
for t in [.7,-1.3,2.0]:
    T=abs(t)
    for lam in [.03,.01,.003]:
        k=T/lam
        points=np.arange(math.pi/k,band,math.pi/k).tolist()
        spectral=2*quad(lambda E: ct*(2*lam*math.sin(k*E/2)/E)**2 if E else ct*T*T,
                        0,band,points=points,epsabs=2e-12,limit=1000)[0]
        upoints=np.arange(math.pi*lam/band,T,math.pi*lam/band).tolist()
        timegram=2*quad(lambda u: (T-u)*2*ct*band*np.sinc(band*u/(math.pi*lam)),
                        0,T,points=upoints,epsabs=2e-12,limit=1000)[0]
        leading=2*math.pi*ct*T*lam
        err=abs(spectral-timegram)
        assert err<3e-11
        assert abs(spectral-leading)<=8*ct*lam*lam/band+1e-12
        assert abs(spectral-2*leading)>.5*leading
        primitive_data.append(dict(t=t,lambda_=lam,spectral=spectral,
                                   timegram=timegram,error=err,
                                   quotient=spectral/(T*lam),
                                   remainder_over_lambda2=(spectral-leading)/lam**2))
emit("continuum_flat_density_free_primitive", density=ct, band=band,
     leading_quotient=2*math.pi*ct, data=primitive_data,
     limitation="separate diagnostic; no substitution for the actual torus proof")
print("Independent finite and quadrature consistency checks completed.",flush=True)
