#!/usr/bin/env python3
"""Read-only verification and reproduction of the frozen author packet.

All generated outputs stay beside this script. No author file is written.
"""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess
import sys
import time

r=Path(__file__).resolve().parent
s=r.parent
a=s/'hstar_threshold_spectral'
snap=r/'author_snapshot'
out=r/'author_reproduction'
out.mkdir(exist_ok=False)

def digest(b):
    return hashlib.sha256(b).hexdigest()

receipt_bytes=(a/'receipt.json').read_bytes()
assert digest(receipt_bytes)=='384a4a5f62310a3f77a138467690f14bbd51042ced9ede6aa3a51a861eddfc92'
assert (snap/'receipt.json').read_bytes()==receipt_bytes
receipt=json.loads(receipt_bytes)
inventory={'../HSTAR_THRESHOLD_SPECTRAL_PROBE.md'}|{
    p.relative_to(a).as_posix() for p in a.rglob('*') if p.is_file()
    and p.relative_to(a).as_posix() not in receipt['excluded_post_freeze_outputs']
    and '__pycache__' not in p.parts}
assert inventory=={x['path'] for x in receipt['files']}
for row in receipt['files']:
    p=(a/row['path']).resolve()
    b=p.read_bytes()
    assert digest(b)==row['sha256']
    assert len(b)==row['bytes'] and len(b.splitlines())==row['lines']
    saved=r/'sources/HSTAR_THRESHOLD_SPECTRAL_PROBE.md' if row['path'].startswith('../') else snap/row['path']
    assert saved.read_bytes()==b
print(f'Original author receipt: all {len(receipt["files"])} bound files and inventory match snapshot.',flush=True)

sources=json.loads((a/'source_manifest.json').read_text())
for row in sources:
    b=Path(row['source']).read_bytes()
    assert digest(b)==row['sha256']
    assert b==(a/row['copy']).read_bytes()==(snap/row['copy']).read_bytes()
print(f'Original scientific sources and both preserved copies: {len(sources)} matched.',flush=True)

instructions=json.loads((a/'instruction_manifest.json').read_text())['items']
for row in instructions:
    b=subprocess.check_output(['git','show',row['ref']+':'+row['path']],cwd=receipt['read_only_worktree'])
    assert digest(b)==row['sha256']
print(f'Pinned author instruction identities: {len(instructions)} matched (not a fresh remote-ref claim).',flush=True)

for stem,script in [('receipt_freeze','freeze_receipt.py'),('receipt_verification','verify_receipt.py')]:
    meta=json.loads((a/(stem+'.execution.json')).read_text())
    assert meta['receipt_sha256']==digest(receipt_bytes)
    assert meta['script_sha256']==digest((a/script).read_bytes())
    assert meta['stdout_sha256']==digest((a/(stem+'.stdout.log')).read_bytes())
    assert meta['stderr_sha256']==digest((a/(stem+'.stderr.log')).read_bytes())
    assert meta['exit_code']==0
    for suffix in ['.execution.json','.stdout.log','.stderr.log']:
        assert (a/(stem+suffix)).read_bytes()==(snap/(stem+suffix)).read_bytes()
print('Both excluded post-freeze execution records bind receipt, script, full stdout and stderr.',flush=True)

base=(snap/'threshold_controls.py').read_text()
baseline_meta=json.loads((snap/'baseline.execution.json').read_text())
assert baseline_meta['source_sha256']==digest(base.encode()) and baseline_meta['exit_code']==0
rows=json.loads((snap/'mutation_manifest.json').read_text())
mutation_log=[]
for row in rows:
    p=snap/row['paths']['source'];b=p.read_text()
    assert base.count(row['before'])==1
    assert b==base.replace(row['before'],row['after'],1)
    assert digest(b.encode())==row['mutant_sha256']
    assert digest(base.encode())==row['baseline_sha256']
    assert json.loads((snap/row['paths']['execution']).read_text())==row
    assert row['exit_code']==1 and row['caught_at_intended_check']
    assert 'AssertionError: '+row['expected_assertion'] in (snap/row['paths']['stderr']).read_text()
    mutation_log.append(json.dumps(dict(source=p.name,complete_bytes_equal_to_unique_replacement=True,sha256=row['mutant_sha256'])))
    mutation_log.extend(difflib.unified_diff(base.splitlines(True),b.splitlines(True),fromfile='baseline',tofile=p.name))
    for role in ['stdout','stderr','execution']:
        name=row['paths'][role]
        mutation_log.extend([json.dumps(dict(file=name)),(snap/name).read_text()])
(out/'complete_mutation_comparison.log').write_text('\n'.join(mutation_log)+'\n')
print('All six complete mutation source files equal the baseline plus their unique stated change; full old outputs retained.',flush=True)

freeze=json.loads((r/'PRE_AUTHOR_FREEZE.json').read_text())
for row in freeze['files']:
    b=(r/row['path']).read_bytes();assert digest(b)==row['sha256']
print('Independent reconstruction and calculation freeze is unchanged after author evidence access.',flush=True)

jobs=[('baseline',snap/'threshold_controls.py',0,None)]
jobs += [(row['name'],snap/row['paths']['source'],1,row['expected_assertion']) for row in rows]
jobs += [('receipt_verifier',a/'verify_receipt.py',0,None)]
results=[]
for name,script,expected,assertion in jobs:
    command=[sys.executable,str(script)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic()
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    cp=subprocess.run(command,cwd=r,env=env,capture_output=True,text=True,timeout=120)
    stdout_path=out/(name+'.stdout.log');stderr_path=out/(name+'.stderr.log')
    stdout_path.write_text(cp.stdout);stderr_path.write_text(cp.stderr)
    matched=cp.returncode==expected and (assertion is None or 'AssertionError: '+assertion in cp.stderr)
    oldstem='baseline' if name=='baseline' else 'mutant_'+name
    output_comparison=None
    if name!='receipt_verifier':
        oldout=(snap/(oldstem+'.stdout.log')).read_text()
        olderr=(snap/(oldstem+'.stderr.log')).read_text().replace(str(a),str(snap))
        output_comparison=dict(stdout_byte_equal=cp.stdout==oldout,stderr_equal_after_snapshot_path_substitution=cp.stderr==olderr)
        matched=matched and all(output_comparison.values())
    meta=dict(command=command,cwd=str(r),start_utc=started,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              elapsed_seconds=time.monotonic()-tic,timeout_seconds=120,exit_code=cp.returncode,
              expected_exit=expected,expected_assertion=assertion,source_sha256=digest(script.read_bytes()),
              stdout_sha256=digest(stdout_path.read_bytes()),stderr_sha256=digest(stderr_path.read_bytes()),
              output_comparison=output_comparison,matched=matched,classification='reproduction, not independent derivation')
    (out/(name+'.execution.json')).write_text(json.dumps(meta,indent=2)+'\n')
    results.append(dict(name=name,exit_code=cp.returncode,matched=matched,output_comparison=output_comparison))
    print(json.dumps(results[-1],sort_keys=True),flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(row['matched'] for row in results)
print('All eight author reproduction/provenance runs match the expected outcomes. No mathematical status follows from this count.',flush=True)
