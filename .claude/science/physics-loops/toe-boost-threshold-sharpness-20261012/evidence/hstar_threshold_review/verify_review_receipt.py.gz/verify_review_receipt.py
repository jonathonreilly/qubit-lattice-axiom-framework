#!/usr/bin/env python3
"""Verify the frozen review and current original inputs, without modifying them."""
from pathlib import Path
import hashlib
import json

r=Path(__file__).resolve().parent
s=r.parent
data=json.loads((r/'receipt.json').read_text())
assert data['schema']=='hstar-threshold-independent-review-v1'
assert Path(data['review_directory'])==r
report=s/'HSTAR_THRESHOLD_SPECTRAL_REVIEW.md'
def sha(b): return hashlib.sha256(b).hexdigest()
expected={row['path'] for row in data['files']}
actual={'../'+report.name}|{p.relative_to(r).as_posix() for p in r.rglob('*')
       if p.is_file() and p.relative_to(r).as_posix() not in data['excluded_post_freeze_outputs']
       and '__pycache__' not in p.parts}
assert len(expected)==len(data['files']) and expected==actual
for row in data['files']:
    p=(r/row['path']).resolve();assert p==report or r in p.parents
    b=p.read_bytes();assert sha(b)==row['sha256']
    assert len(b)==row['bytes'] and len(b.splitlines())==row['lines']
print(f'Review inventory and full recovery bytes match: {len(expected)} files.')
sources=json.loads((r/'source_manifest.json').read_text())
for row in sources:
    b=Path(row['source']).read_bytes()
    assert sha(b)==row['sha256'] and b==(r/row['copy']).read_bytes()
assert sha((s/'HSTAR_THRESHOLD_SPECTRAL_PROBE.md').read_bytes())==data['target_sha256']
assert sha((s/'hstar_threshold_spectral/receipt.json').read_bytes())==data['author_receipt_sha256']
print('Target, eight original source identities and author receipt remain unchanged.')
assert sha((r/'PRE_AUTHOR_FREEZE.json').read_bytes())==data['pre_author_freeze_sha256']
pre=json.loads((r/'PRE_AUTHOR_FREEZE.json').read_text())
for row in pre['files']:
    assert sha((r/row['path']).read_bytes())==row['sha256']
access=json.loads((r/'AUTHOR_ACCESS.json').read_text())
assert pre['frozen_utc']<access['first_new_author_evidence_open_utc']
assert pre['new_author_evidence_opened'] is False
print('Pre-author analysis/calculation freeze unchanged and earlier than recorded new-author access.')
assert json.loads((r/'independent_checks.execution.json').read_text())['exit_code']==0
assert json.loads((r/'failed_initial_check/independent_checks.execution.json').read_text())['exit_code']==1
assert json.loads((r/'reproduce_author.execution.json').read_text())['exit_code']==0
for p in (r/'author_reproduction').glob('*.execution.json'):
    meta=json.loads(p.read_text());stem=p.name[:-len('.execution.json')]
    assert sha((p.parent/(stem+'.stdout.log')).read_bytes())==meta['stdout_sha256']
    assert sha((p.parent/(stem+'.stderr.log')).read_bytes())==meta['stderr_sha256']
    assert meta['matched']
print('Successful independent run, preserved reviewer failure and all reproduction output bindings match.')
assert not data['formal_retained_status_assigned'] and not data['audit_operation']
print('Verification complete. Identity bookkeeping supplies no additional mathematical or audit status.')
