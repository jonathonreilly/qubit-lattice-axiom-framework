# Author reconstruction and control coverage

Root proposed the threshold route and is a coauthor. The worker completed
S1–S20 and its checks with the inherited model and effort unchanged; no
subagent was used. This packet is author evidence, not an independent
scientific review or an audit. No Q conclusion or Q source is a mathematical
premise. The exact B/E/X sources, copies and coverage are in the manifest.

## Distinct analytic arrangements

The physical space is the orthogonal sum of a mean-zero even singlet,
an even scalar longitudinal coefficient times the odd n(q), and the odd
transverse triplets. Direct Pauli action yields A f=h f and A* v=P0(hv).
This is independently checked by the finite physical Pauli construction,
not merely an abstract assumed block. Multiplying A A* gives the negative
rank-one term. Solving A* v=0 then gives 1/h, and its normalization gives
I0. No contact singlet is counted as a physical zero mode.

The source resolvent is derived both by multiplying the rank-one inverse
and by solving the scalar equation (z-Y)v+h<h,v>=h. The zero residue is
checked against the actual kernel projection as well as the negative-axis
transform limit. The signed H* measure is derived both from chiral symmetry
and square pushforward, and from the source identity
<h0,(w-H*)^-1 h0>=w G(w^2). These different arrangements check the signs,
residue, negative-energy boundary choice and factor of two.

The cone coefficient is computed by folding the full torus and changing to
u=2sin q. Separately, the convolution of three single-coordinate arcsine
square densities gives the same coefficient and first correction. The
second calculation counts four preimages per one-coordinate square map;
the first counts eight three-dimensional sine zeros. Neither inserts an
exchange half factor. Both start from normalized full-torus probability.

The real-axis boundary proof is separate from the negative-axis limit.
On every compact positive interval, subtraction at the moving real part
bounds the Cauchy-integral remainder uniformly. This gives a continuous
boundary value on that compact interval. The near-zero real part is then
estimated by an exact principal-value integral for the leading square-root
density, a Hölder subtraction for its remainder, and a separated finite
measure tail. The upper-boundary imaginary part has the negative sign of
our (z-A)^-1 convention. The denominator stays uniformly away from zero
on a stated threshold interval. Scalar inversion identifies the entire
local measure after endpoint atoms are checked; no singular continuous
component is silently omitted. At zero the atom is computed and removed
exactly.

The final primitive estimate has three independent pieces: the actual
measure outside the threshold neighborhood, the O(E^2) local density error,
and the missing tail of the constant-density integral on the whole line.
All are bounded by explicit multiples of lambda^2. The full-line integral
is checked by an elementary Laplace regulator and arctangent calculation.
No large-time or small-frequency limit is taken inside the full slow
noncommuting dynamics.

## A corrected shortcut and other preserved failures

The cold read found an overstrong explanatory sentence in the draft:
positivity alone does not select the negative rank-one sign, because
M_Y+|h><h| is positive too. The final source explicitly records this failed
shortcut. The physical factorization and zero-vector identity select the
sign; the actual algebra and theorem were unchanged by this correction.

The same read clarified that the finite scalar endpoint integral -I0 is
not the value of a bounded operator resolvent at zero, and that the bounded
boundary values used for local inversion are scalar source resolvents.
The formal full inverse of Qh0 is not L2. The unprojected source has a
nonzero zero atom and a t^2/I0 primitive term. A fixed finite matrix has
a gap after removing its kernel and therefore cannot demonstrate the
continuum lambda-first threshold law. Finally an O(t^2) bounded-perturbation
comparison is not small enough to transfer the free lower asymptotic to
the full slow problem. These statements retain their precise scopes.

## Executed controls

`threshold_controls.py` imports no previous campaign helper. It constructs
4-by-4 Pauli matrices at three weighted antipodal momentum pairs, with
sine representatives (3/5,0,0), (0,5/13,0), (0,0,8/17) and equal weights.
The ambient fiber has dimension 12; the physical contact projection has
rank 11. Its finite I0=202369/172800 is explicitly not the torus integral.
Exact SymPy identities check the complete physical zero space, projected
source, off-diagonal map, longitudinal square, chiral symmetry, source
resolvent and its zero residue. Two nonreal signed-resolvent checks use the
direct physical Pauli matrix, not just the abstract block formula.

The scalar controls check the two cone coefficients, first density
correction and principal-value real-part order exactly. They do not sample
a torus or estimate its threshold coefficient by fitting.

A separate continuous radial model has probability density
(3/2)sqrt(y) on (0,1). Its I0 is 3, its unprojected source mass is 3/5 and
its zero atom is 1/3. Its exact transform is
3[sqrt(z) atanh(1/sqrt(z))-1] in the upper half-plane. Direct numerical
Cauchy integrals check that transform and the upper-boundary sign. The
signed density integrates to 4/15 after removing the atom, checking the
square-root Jacobian and equal branch weights. Two arrangements of the
free primitive are compared: direct sinc-kernel integration and a constant
term involving Si plus a cosine-weighted density remainder.

The baseline completed all 36 controls with exit 0 in 1.580 seconds.
Its full stdout, empty stderr and command metadata are preserved. The
largest direct Cauchy discrepancy was 1.3506446028928519e-15; the largest
primitive rearrangement discrepancy was 1.0918523030145622e-13. The radial
continuous mass was 0.2666666666666723 against 4/15. Its displayed small
lambda values are diagnostic results for this explicitly different model,
not evidence replacing the torus proof. The finite Pauli mesh has smallest
nonzero squared energy about 0.723824; its primitive has a direct
O(lambda^2) squared-norm upper bound after projection, preserving the
noncommutation of a finite-mesh limit and the continuum threshold limit.

Runtime versions were Python 3.13.5, SymPy 1.14.0, NumPy 2.4.4 and SciPy
1.17.1. Six literal defect copies actually exited 1 at their designated
assertions: omitted mean projection, wrong rank-one sign, omitted eight
cones, doubled signed density, wrong upper-boundary sign and unremoved
source atom. Every full stdout/stderr was inspected, and every changed
source was verified against its unique one-replacement rule. Their files,
command metadata and logs are preserved. Sensitivity to these defects does
not certify the continuum result or constitute an independent review.

Reproduce the author baseline with fresh logging destinations:

```text
/opt/homebrew/opt/python@3.13/bin/python3.13 /Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/hstar_threshold_spectral/threshold_controls.py
```

`run_mutations.py` refuses to overwrite the original defect evidence.
The receipt verifier checks exact bytes, source copies, instruction refs,
executed helper identities and literal failures, with an in-memory tamper
probe. Such verification is bookkeeping, not a mathematical verdict.

## Source reading and pending independent check

The complete final S1–S20 source was cold-read, including the full boundary
argument, explicit constants, all signed-energy factors and limitations.
The primary mathematical reference was checked at its author URL: the
bounded spectral calculus and scalar Stieltjes inversion apply because
the physical operators are bounded self-adjoint and the source measures
finite. The opposite resolvent convention was handled explicitly. No
rank-one regularity theorem, global spectral classification or numerical
I0 value was imported. The exact PDF identity and necessary read scope are
recorded without copying the full book into this packet.

No unresolved author proof obligation is identified within S1–S20.
A fresh independent check is still needed, particularly for the boundary
uniformity, complete local measure identification and free-only scope.
No Git, PR, editable prompt, axiom, publication or audit status changed.
