#!/usr/bin/env python3
"""Freeze exact S1-S20 author bytes once; not a scientific verdict."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
p=Path(__file__).resolve().parent
rp=p/'receipt.json';assert not rp.exists(),'refusing to overwrite a frozen receipt'
note=p.parent/'HSTAR_THRESHOLD_SPECTRAL_PROBE.md'
excluded={'receipt.json','receipt_freeze.stdout.log','receipt_freeze.stderr.log',
 'receipt_freeze.execution.json','receipt_verification.stdout.log',
 'receipt_verification.stderr.log','receipt_verification.execution.json'}
paths=[note]+sorted(x for x in p.rglob('*') if x.is_file() and x.relative_to(p).as_posix() not in excluded and '__pycache__' not in x.parts)
files=[]
for x in paths:
    b=x.read_bytes();files.append({'path':'../'+note.name if x==note else x.relative_to(p).as_posix(),
       'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'lines':len(b.splitlines())})
r={'schema':'hstar-threshold-spectral-receipt-v1','packet_path':str(p),
 'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'campaign_deadline_utc':'2026-10-12T16:00:52+00:00',
 'read_only_worktree':'/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/boost_worktree',
 'mathematical_status':'conditional-author-result; independent-review-pending',
 'authors':'root proposed spectral lead; boost_kernel_dynamics completed bounded derivation and author controls',
 'new_claim_scope':'S1-S20 physical longitudinal rank-one square, exact source resolvent and zero atom, eight-cone density, threshold boundary values and source-specific signed spectral density, sharp fixed-time free primitive with explicit O(lambda^2) squared-norm remainder',
 'Q_conclusions_are_not_premises':True,'frozen_Q_and_K_unchanged':True,
 'nonclaims':['full noncommuting slow-generator lower bound','actual W_lambda-z lower bound','boost expectation result','optimal growing-time window','global spectral classification','full physical boost law'],
 'preserved_failures':['positivity alone cannot select the rank-one sign','keeping the zero atom changes the leading scale','formal full inverse of Qh0 is not L2','negative-axis limit alone does not establish a threshold boundary density','fixed finite meshes have a different lambda-first law','bounded-perturbation O(t^2) comparison cannot transfer the free lower asymptotic'],
 'author_open_proof_obligations':[],
 'independent_check_pending':['physical parity and global mean-zero domain','rank-one sign and zero residue','eight cones and both Jacobians','uniform boundary and entire local measure identification','free primitive normalization, remainder and precise scope'],
 'changes':['../HSTAR_THRESHOLD_SPECTRAL_PROBE.md','hstar_threshold_spectral evidence packet only'],
 'changed_editable_prompts':[],'git_mutations_by_worker':[],
 'primary_reference_policy':'The author-hosted PDF was read and fingerprinted; its full content is not copied here. Local receipt verification binds the recorded fingerprint and read scope, not a fresh network retrieval.',
 'files':files,'excluded_post_freeze_outputs':sorted(excluded),
 'output_binding':'Post-freeze logs are hashed by their execution metadata, which binds the receipt hash; no circular self-hash is asserted.',
 'verification_scope':'byte and recorded execution provenance only; no mathematical or audit certification'}
rp.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps({'note_sha256':files[0]['sha256'],'receipt_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'bound_files':len(files),'frozen_at_utc':r['frozen_at_utc']},indent=2))
