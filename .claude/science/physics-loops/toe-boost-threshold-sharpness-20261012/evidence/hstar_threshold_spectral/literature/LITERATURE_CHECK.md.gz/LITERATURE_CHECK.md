# Primary source check

Gerald Teschl, *Mathematical Methods in Quantum Mechanics*, GSM 99,
version February 12, 2009, author URL:
https://www.mat.univie.ac.at/~gerald/ftp/book-schroe/schroe.pdf

Theorems 3.1 and 3.7 supply spectral calculus for a self-adjoint operator.
Theorem 3.21 supplies scalar Stieltjes inversion for a finite measure.
Their necessary statement/proof passages were read. The local operator
H* is bounded self-adjoint on its full physical Hilbert space; its source
measure has finite mass. The square AA* is likewise bounded, self-adjoint
and nonnegative. Thus those hypotheses hold. The note uses the opposite
resolvent sign and explicitly changes the inversion sign.

The source PDF was fetched for an exact byte fingerprint, recorded in
`teschl_source_identity.json`; no full book is retained in the packet.
No historical priority claim is made. The rank-one inverse, local density,
boundary regularity and primitive constant are derived in the probe.

The Simon bibliography was also searched to locate rank-one literature,
but no result from it is used as a theorem premise. A local pdftotext
availability check failed; the requested local source reads were reissued
successfully, and the primary theorem passages were read through the
browser PDF text. No unread theorem was substituted for that limitation.
