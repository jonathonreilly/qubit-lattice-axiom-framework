# Unproved lead: the actual H* threshold and a sharp free-primitive scale

Root proposal, 2026-10-12. This is an attack route, not a checked theorem.
Use the exact physical Hilbert space and normalized full-torus measure from
B/E/X. No Q growing-time assertion is needed as a premise. Root is a
contributor to this lead and cannot provide its independent source check.

Let h(q)=2 epsilon(q), Y=h^2, and P remove the constant even singlet.
On even singlet functions with zero mean and odd longitudinal triplets,
H* has off-diagonal map A f=h f. Thus the longitudinal square should be

    A A* = Y - |h><h|,
    zeta_long = 1/(h sqrt(I0)),   I0=integral 1/Y dmu.

Define F(z)=integral (z-Y)^(-1)dmu. A direct rank-one identity appears to give

    <h,(z-AA*)^(-1)h> = 1 - 1/(z F(z)).

Check the sign, parity, normalization, excluded constant and zero-mode residue
directly. The residue at zero should be 1/I0, consistent with the known zeta.
No full inverse on the complement is inferred from this formula.

A local coarea calculation near all eight sine zeros suggests the Y density
rho_Y(s)=sqrt(s)/(4 pi^2)+O(s^(3/2)) as s decreases to0. The singular part of
F near zero must be controlled in its actual boundary values, not merely
pointwise dominated convergence of off-axis resolvents. If F(s+i0) tends to
-I0, the longitudinal-square density for h away from its atom would be

    rho_h(s)=rho_Y(s)/(s |F(s+i0)|^2).

The symmetric H* spectral density of Q h0, with h0=h n, would then tend on
both sides of zero to c=1/(4 pi^2 I0^2). This needs proof of absolute
continuity in a punctured threshold neighbourhood and no remaining threshold
atom after projection. Global absence of other spectrum is unnecessary for
the proposed primitive asymptotic, since energy away from zero costs O(lambda^2).

For fixed t nonzero, consider only the free primitive

    J_lambda(t)=integral_0^t exp(-i(t-s)H*/lambda) Q h0 ds.

If the density statement holds, scaling the exact spectral integral suggests

    ||J_lambda(t)||^2 / lambda -> 2 pi c |t|
                                   = |t|/(2 pi I0^2).

This would make the square-root-lambda estimate sharp for this actual residual
direction under the free fast generator. It does NOT automatically prove a
lower bound for the full noncommuting H*/lambda+B+E_lambda evolution, the
time-dependent source, W_lambda-z, any boost mean or the optimal growing-time
window. Those extensions require separate matched estimates. Preserve that
distinction and any failed route or counterexample.
