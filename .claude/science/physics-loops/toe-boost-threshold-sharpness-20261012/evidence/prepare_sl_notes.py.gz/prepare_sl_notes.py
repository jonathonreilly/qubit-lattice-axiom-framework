"""Compose complete S/L notes only after root has read the finished L check."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent / 'quantitative_boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-threshold-sharpness-20261012'
sha = lambda b: hashlib.sha256(b).hexdigest()
approval = json.loads((S / 'L_root_review_coverage.json').read_text())
assert approval['review_accepted'] is True
assert sha((S / 'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_REVIEW.md').read_bytes()) == approval['report_sha256']
assert sha((S / 'HSTAR_THRESHOLD_SPECTRAL_REVIEW.md').read_bytes()) == '913a9c81f6361981041034059cb2fc12f1485e257c18e9576cd016ffd74eda05'
common = '''---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: upstream_support
reachability_to_target: supports
audit_required_before_effective_retained: true
bare_retained_allowed: false
---'''
boost_id = 'excluded_walk_boost_bracket_control_bounded_theorem_note_2026-10-11'
sid = 'hstar_threshold_spectral_bounded_theorem_note_2026-10-12'
qid = 'boost_quantitative_corrector_bounded_theorem_note_2026-10-12'
packet = '[complete milestone packet](../.claude/science/physics-loops/toe-boost-threshold-sharpness-20261012/)'
outputs = []
for label, filename, expected, target, claim, upstream, primary, scope in [
    ('S', 'HSTAR_THRESHOLD_SPECTRAL_PROBE.md',
     '6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da',
     'docs/HSTAR_THRESHOLD_SPECTRAL_BOUNDED_THEOREM_NOTE_2026-10-12.md', sid,
     [boost_id], 'scripts/hstar_threshold_spectral_2026_10_12.py',
     'For the supplied globally compressed sine-Pauli operator and the actual initial source direction, the kernel-complement scalar spectral measure has an explicit positive threshold density and the free fast primitive has a sharp square-root scaling with a uniform absolute squared-norm remainder. The full noncommuting actual-error comparison is a separate theorem.'),
    ('L', 'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md',
     '972b66765f82346a9fb3a4171350b8136a4fb80671f99b4d35355d0388d09ef3',
     'docs/ACTUAL_CORRECTOR_SMALL_TIME_LOWER_BOUNDED_THEOREM_NOTE_2026-10-12.md',
     'actual_corrector_small_time_lower_bounded_theorem_note_2026-10-12',
     [sid, qid, boost_id], 'scripts/actual_corrector_small_time_lower_2026_10_12.py',
     'For the exact supplied globally normalized preparation, the actual rescaled correction error is bounded above and below by explicit positive multiples of the square root of the product of lambda and effective time on a specified small positive time interval with an explicit time-dependent lambda threshold. No actual leading coefficient, optimal growing-time window or physical covariance is established.')]:
    src = S / filename
    raw = src.read_text()
    assert sha(raw.encode()) == expected
    edits = []

    def edit(before, after, reason):
        global raw
        assert raw.count(before) == 1, (label, before, raw.count(before))
        raw = raw.replace(before, after, 1)
        edits.append(dict(before=before, after=after, reason=reason))

    meta = ('---\nclaim_id: ' + claim + '\nclaim_type: bounded_theorem\nclaim_scope: ' + json.dumps(scope)
            + '\nupstream_dependencies:\n' + ''.join('  - ' + u + '\n' for u in upstream)
            + 'runner: ' + primary + '\n' + common.split('\n', 1)[1])
    edit(common, meta, 'Register the conditional theorem and its actual dependencies and finite primary.')
    if label == 'S':
        edit('2026-10-12. Bounded author derivation by `boost_kernel_dynamics`. Root\nproposed the spectral lead and is a coauthor. Independent scientific review\nis pending. This note uses the source-checked B/E/X physical setup and\nrederives the needed kernel identities. It uses no conclusion from the\nconcurrently reviewed quantitative Q note and changes neither Q nor K.',
             '2026-10-12. Bounded derivation by `boost_kernel_dynamics`; root proposed\nthe spectral lead and is a coauthor. Status: conditional-support. A separate\ncomplete scientific reconstruction found no required correction. This note\nuses the source-checked B/E/X physical setup and rederives the needed kernel\nidentities. No conclusion from the quantitative Q theorem is a premise here.',
             'Record the completed independent S check without changing mathematical premises or claiming an audit verdict.')
        edit("All paths in this table are relative to this note's directory S.",
             'S denotes the original research source collection, preserved losslessly in the\n' + packet + '. EVIDENCE_MAP.json maps the exact source identities below\nto their preserved bytes. The in-branch [boost theorem](EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md)\ncontains the complete B/E/BR/T/X arguments and their supplied-model boundaries.',
             'Make the original source boundary portable and identify the existing complete dependency.')
        edit("Independent review should check S3's even/mean-zero identification, the\nrank-one sign and zero residue, all eight cones and both Jacobians, the\nuniform boundary passage, exclusion of residual singular mass, and the\nfree-primitive normalization and scope. No global spectral classification,\nfull-slow lower bound, optimal growing-time exponent or physical boost law\nis claimed. No Git, PR, prompt, axiom, publication or audit file changed.",
             "The separate review checked S3's even/mean-zero identification, the rank-one\nsign and zero residue, all eight cones and both Jacobians, the uniform boundary\npassage, the entire local measure and free-primitive normalization. Its report\nis `913a9c81f6361981041034059cb2fc12f1485e257c18e9576cd016ffd74eda05`;\nthe 376-line reconstruction `0f66243e7a8322c1649990da27f56e509b1f18904ca2826d257e88ef05568377`\nwas frozen before new author evidence. The reviewer's corrected auxiliary\ncubature and its first failed source/logs are preserved. Root is a contributor,\nnot this independent reviewer. The [finite control](../scripts/hstar_threshold_spectral_2026_10_12.py)\npreserves the complete original helper; it does not prove continuum spectral\ntype. REVIEW_HISTORY.md and DELIVERY_CHECKS.md in the milestone packet record\neach evidence role and publication checks. The separate downstream note\n`ACTUAL_CORRECTOR_SMALL_TIME_LOWER_BOUNDED_THEOREM_NOTE_2026-10-12.md` proves\nits own full actual-error comparison. S alone supplies no such lower bound.\nNo global spectral classification, optimal growing-time exponent, physical\nboost law, Lean certificate, retained status or applied audit verdict is claimed.\nNo physical axiom or editable prompt changed.",
             'Replace the finished review obligation with exact evidence and retain the free-versus-actual boundary.')
    else:
        edit('The threshold source S is an explicit provisional dependency pending its\nseparate independent review. This note also needs its own independent check.',
             'The threshold source S and this full actual-error comparison have each\nreceived a separate complete scientific reconstruction with no required\ncorrection. Both remain conditional mathematical results; no audit verdict\nor retained status is assigned.',
             'Record the two completed selective reviews without changing the original frozen history.')
        edit('The source map and byte-identical copies are in\n`actual_corrector_small_time_lower/source_manifest.json`. The load-bearing\nidentities are:',
             'The ' + packet + ' preserves the complete original note, source map,\nbyte-identical dependencies, author controls and separate review. Its\nEVIDENCE_MAP.json provides recovery paths. The in-branch dependencies are\nthe [threshold theorem](HSTAR_THRESHOLD_SPECTRAL_BOUNDED_THEOREM_NOTE_2026-10-12.md),\n[quantitative corrector](BOOST_QUANTITATIVE_CORRECTOR_BOUNDED_THEOREM_NOTE_2026-10-12.md)\nand original [boost theorem](EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md).\nThe exact frozen source identities are:',
             'Make the complete mathematical source boundary and dependency graph portable.')
        edit('| Provisional S19–S20 free threshold law |',
             '| S19–S20 free threshold law; separate complete source review recorded in the milestone packet |',
             'Update the review-state description only; S19 remains a mathematical dependency.')
        edit('These\nare author checks, not an independent scientific review or a formal proof\ncertificate. Root is a coauthor, not the independent reviewer. The result\nremains a conditional supplied-model theorem with the exact dependencies\nlisted above. Only this note and its evidence directory were written.\nNo editable prompt, Git, axiom, publication or audit file changed.',
             'These\nauthor checks are distinct from the separate complete reconstruction. The\nreview report is `' + approval['report_sha256'] + '`;\nits reconstruction, independent controls, later reproduction and all preserved\nfailures are in the milestone packet. Root is a coauthor, not the independent\nreviewer. The [finite primary](../scripts/actual_corrector_small_time_lower_2026_10_12.py)\nretains every original control calculation. PUBLICATION_EDITS.json and\nPRIMARY_COMPOSITION.json reconstruct both full notes and both complete\nprimaries exactly; DELIVERY_CHECKS.md states the publication verification\nscope. The result remains a conditional supplied-model theorem. No Lean\ncertificate, retained status, applied audit verdict, editable-prompt change\nor physical-axiom change is claimed.',
             'Record actual complete review and publication evidence without changing the theorem or its limits.')
    for old in list(dict.fromkeys(x for x in raw.splitlines(keepends=True) if x.rstrip('\r\n').endswith((' ', '\t')))):
        edit(old, old.rstrip() + '\n', 'Remove presentation-only trailing whitespace.')
    if raw.endswith('\n\n'):
        old = raw[-160:]
        edit(old, old.rstrip() + '\n', 'Normalize final blank lines only.')
    assert not (W / target).exists()
    (W / target).write_text(raw)
    outputs.append(dict(label=label, kind='note', source_path=str(src), source_sha256=expected,
                        preserved_source='evidence/' + filename + '.gz', edits=edits, appended_text='',
                        publication_path=target, publication_sha256=sha(raw.encode())))
(P / 'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=outputs), indent=2) + '\n')
print(json.dumps([dict(path=r['publication_path'], sha256=r['publication_sha256']) for r in outputs]))
