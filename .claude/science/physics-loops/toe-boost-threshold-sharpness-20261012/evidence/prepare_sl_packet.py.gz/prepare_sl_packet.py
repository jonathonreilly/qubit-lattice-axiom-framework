"""Preserve the completed source checks and full threshold/sharpness milestone."""
from pathlib import Path
import gzip
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent / 'quantitative_boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-threshold-sharpness-20261012'
BASE = '36d6069676f561d81ad693f286dd52f570fb37df'
sha = lambda b: hashlib.sha256(b).hexdigest()
lr = json.loads((S / 'L_root_review_coverage.json').read_text())
assert lr['review_accepted'] is True
assert sha((S / 'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_REVIEW.md').read_bytes()) == lr['report_sha256']
assert not (P / 'STATE.yaml').exists()
texts = {
    'STATE.yaml': f'''loop: toe-boost-threshold-sharpness-20261012
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-boost-quantitative-outgoing-20261012
base_revision: {BASE}
pr: 9487
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: threshold_measure_and_actual_small_time_sharpness
provisional_dependency: supplied_B25_B30_model_and_reviewed_Q_S_mathematics
independent_check: separate_complete_S_and_L_reconstructions
pr_status: preparing_extension_to_regular_PR9487
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
next_action: canonical_controls_and_scoped_delivery_checks_then_publish_extension
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
    'GOAL.md': '''# Exact mathematical contract

Determine the actual source direction's threshold measure in the supplied
globally compressed sine-Pauli model, including its kernel atom and the entire
local measure. Then determine whether the quantitative square-root error rate
is sharp for the actual rescaled evolution on a nonempty small fixed-time
interval. Keep all noncommuting, changing-source and normalization terms.
''',
    'ASSUMPTIONS_AND_IMPORTS.md': f'''# Exact premises and dependencies

The pre-extension revision is {BASE}, regular PR9487, based on PR9484.
The original boost note supplies the antisymmetric pair sector, sine-Pauli
symbol, one global contact projection, continuous clock and exactly the
globally normalized B25–B30 preparation. These remain supplied model data.

S rederives the physical kernel and longitudinal square from those definitions.
It uses bounded self-adjoint functional calculus and finite scalar-measure
inversion, with Teschl's original statements and proofs checked at the exact
recorded edition. Its coarea, real-axis boundary and primitive estimates are
derived in full. S does not use Q's conclusion.

L uses S19–S20 and the complete Q approximate-range and exact-error estimates.
Q already appears in this PR and states its K and cross-PR9481 dependencies.
Those inherited supplied-model conditions remain explicit. The new L proof
uses bounded-operator ODEs and continuous Hilbert-valued integrals, not a new
unverified spectral import. Root and the author are contributors; the S and L
source checks are separate. Review status is evidence, not a mathematical premise.
''',
    'APPROACH_REGISTRY.md': '''# Completed argument families

1. Physical parity and the global mean projection give a longitudinal square
   with one rank-one subtraction. The source resolvent and zero atom are exact.
2. All eight torus cones give the low-energy pushforward density. Uniform
   boundary subtraction and scalar inversion identify the entire local measure,
   including the exclusion of hidden singular mass. Signed square-root branches
   and exact atom removal give the positive threshold density.
3. The free primitive spectral multiplier gives a sharp coefficient and a
   uniform absolute squared-norm remainder; finite meshes cannot supply it.
4. A time-adapted approximate-range vector bounds general weighted residual
   primitives. Noncommuting Duhamel acts on that already small primitive.
5. Hilbert-valued Fubini retains the full varying residual, while the exact
   forcing error remains separate. Both triangle inequalities give explicit
   actual two-sided bounds at small effective times and sufficiently small lambda.
''',
    'ROUTE_PORTFOLIO.md': '''# Evidence roles

The two complete analytic notes carry the mathematical claims. Separate
reviewers reconstructed their complete arguments before opening the new author
controls. Reviewers shared the proposed statements and source premises; this
is not blinded discovery. Root supplied the leads and is a contributor.

Both primaries preserve their entire original finite helper with only timeout,
input, assertion and scope metadata. Each has36 finite controls. Physical
Pauli fixtures, separate radial models, matrix exponentials and exact constant
checks test algebra. They do not prove the torus spectral type or continuum
asymptotic. Independent calculations and later author reproduction are distinct.
No formal Lean certificate or applied audit verdict is supplied.
''',
    'OPPORTUNITY_QUEUE.md': '''# Next scientific decisions

The square-root rate is now sharp for the actual preparation at each fixed
time in a specified small positive interval, conditional on the supplied model.
An exact actual leading coefficient, larger-time sharpness and optimal growing
windows remain open. Their proofs require new analysis beyond these bounds.

The parallel microscopic bridge continues through compact detector convergence,
construction of the selected scattering projection and no-undetected-state
estimates. Supplied two-body dynamics do not settle many-body GNS completeness.
''',
    'NO_GO_LEDGER.md': '''# Preserved failures and scope boundaries

Positivity alone does not choose the rank-one sign. A negative-axis resolvent
limit gives an atom, not the real-axis density. Omitting that atom's subtraction
changes the leading primitive scale. A full complementary inverse is not L2.
A fixed finite mesh has a different lambda-first limit.

A coarse operator-norm comparison of propagators loses the small-lambda scale.
The new proof compares primitives instead. Neither the noncommuting factor nor
the time-varying residual or exact forcing error can be dropped. No universal
no-go is proposed. Every earlier boost counterexample remains unchanged.
''',
    'LITERATURE_BRIDGES.md': '''# Checked mathematical imports

Gerald Teschl, Mathematical Methods in Quantum Mechanics, GSM99, version
February12,2009, author-hosted at
https://www.mat.univie.ac.at/~gerald/ftp/book-schroe/schroe.pdf.
The fetched1538372-byte PDF has SHA256
8dc8de0b58aa0a3fedfe594a345f9b5875322e5526ea581cb640a98d55b82818.
The necessary original statements and proofs of Theorems3.1,3.7 and3.21
were read, including the opposite resolvent sign and endpoint half-weights.
Exact read coverage and fresh retrieval identities remain in the evidence.
The full third-party book is not redistributed.

The rank-one equation, all-cone density, uniform boundary subtraction and
primitive coefficient are proved in the note rather than imported from a
global spectral classification. L adds bounded-operator ODE and finite
continuous Hilbert-integral manipulations with explicit hypotheses.
''',
    'ARTIFACT_PLAN.md': '''# Coherent regular PR extension

Extend regular PR9487 with two full notes, two finite primaries and canonical
caches, exact source/recovery maps, full source reviews and this snapshot.
Preserve the existing K/Q notes, controls and milestone packet unchanged.
No draft, merge, main push or applied audit action. This snapshot does not
replace the single live campaign checkpoint in the transport worktree.
''',
    'TRACE_GATE.md': '''# Connection to the prepared-state error problem

```yaml
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Determine whether the quantitative actual boost-corrector error rate can be improved for the stated preparation."
source_of_blocker_text: quantitative_boost_corrector_and_actual_error
source_location: "PR9487 at36d6069676f561d81ad693f286dd52f570fb37df, Q approximate-range theorem and its next threshold obligation."
next_trace_action: "Investigate exact coefficients or longer times separately; continue the microscopic scattering bridge."
```

The new proof establishes actual small-fixed-time square-root sharpness with
explicit constants. It does not select a Hamiltonian, derive physical boost
covariance, close all-state brackets or complete a TOE.
''',
    'CLAIM_STATUS_CERTIFICATE.md': '''# Conditional mathematical status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
conditional_surface_status: "Exact supplied excluded-walk model and globally normalized B25–B30 preparation; S and Q dependencies explicit."
hypothetical_axiom_status: null
admitted_observation_status: null
independent_review_status: "Complete separate S and L source reconstructions; see exact review history."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

Original mathematics is authorized. These source checks support provisional
composition; formal retained status belongs to the independent audit path.
No Lean proof-kernel verification is claimed for these analytic arguments.
''',
    'REVIEW_HISTORY.md': f'''# Complete selective source checks

S source6856c6ff02c50b2357fbda4f2c0dbc2833362965df7ef2efddb3e925b463f6da;
review913a9c81f6361981041034059cb2fc12f1485e257c18e9576cd016ffd74eda05;
receipt0e1cea8a04c122f4ae00af226ae3f2dd9d159701ae70d82671aa3eb42b57003c.
The376-line reconstruction0f66243e7a8322c1649990da27f56e509b1f18904ca2826d257e88ef05568377
and separate199-line control were frozen at01:06:41 UTC before new author
evidence. S1–S20 required no correction. The reviewer initially overcounted
cube sectors in an auxiliary numerical check; a separate Laplace integral
exposed that factor of two. Its failed source/logs and exact correction remain.

L source972b66765f82346a9fb3a4171350b8136a4fb80671f99b4d35355d0388d09ef3;
review{lr['report_sha256']}.
The complete report, pre-author reconstruction, independent controls and
all later reproduction evidence are preserved in actual_corrector_review/.
L_root_review_coverage.json records root's complete reading and byte checks.
The finished review found no required correction within the exact conditional
scope; S's review completed after the original L author freeze, so the frozen
author's pending-review language remains as historical evidence only.

Root fully read both complete source arguments, author helpers and outputs,
all literal defect changes and tracebacks, then the finished separate reviews
and their necessary evidence. Root's exact coverage records are preserved.
Root is a contributor and not another independent reviewer. No count of
bindings or finite controls is used as a substitute for an analytic proof.
''',
    'HANDOFF.md': f'''# Threshold and actual-sharpness milestone snapshot

Extend regular PR9487 from {BASE}. Existing K/Q science remains unchanged.
S proves the actual initial direction's complete local threshold measure and
sharp free primitive. L composes that result with Q's time-adapted corrector
to bound the full actual error above and below, including the noncommuting
perturbation, changing residual and complete forcing approximation.

The exact result is fixed-time Theta(sqrt(lambda)) on an explicit nonempty
small interval; finite-lambda bounds use their stated time-dependent threshold.
No exact actual coefficient, H1 asymptotic, mean lower bound, optimal growing
window, physical realization or retained status is inferred.

PUBLICATION_EDITS.json and PRIMARY_COMPOSITION.json recover every complete
note and control from lossless evidence. SOURCE_IDENTITIES.json binds the
intended publication set. Every failed numerical or operational check remains
recoverable. Canonical execution and scoped delivery checks are recorded
separately; global combined audit pipeline and strict audit lint remain unrun
independent landing gates, with no applied verdict.

The sole live campaign checkpoint is toe-dynamics-bridge-20261009 in sibling
transport worktree. Fixed deadline2026-10-12 16:00:52 UTC. Continue useful
science within it. No draft, merge, main push, applied audit, axiom or prompt
edit, other-chat message or deadline extension.
''',
    'PR_BACKLOG.md': '''# Regular milestone extension

Publish this coherent S/L extension in existing regular PR9487 after canonical
execution, exact source checks and scoped delivery conformance. Both complete
analytic sources received separate checks. Continue detector and projection
research after publication. No duplicate PR or draft is needed.
'''
}
for name, text in texts.items():
    (P / name).write_text(text)
names = ['HSTAR_THRESHOLD_SPECTRAL_PROBE.md', 'HSTAR_THRESHOLD_SPECTRAL_REVIEW.md',
         'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_PROBE.md', 'ACTUAL_CORRECTOR_SMALL_TIME_LOWER_REVIEW.md',
         'S_root_author_coverage.json', 'S_root_review_coverage.json', 'S_root_teschl_read_identity.json',
         'S_root_receipt_verify.stdout.log', 'S_root_receipt_verify.stderr.log',
         'L_root_author_coverage.json', 'L_root_review_coverage.json']
paths = [S / name for name in names]
for folder in ['hstar_threshold_spectral', 'hstar_threshold_review',
               'actual_corrector_small_time_lower', 'actual_corrector_review']:
    paths.extend(p for p in sorted((S / folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
rows = []
for src in sorted(set(paths)):
    assert src.suffix.lower() not in ['.pdf', '.png', '.jpg'], 'Keep third-party primary content external with exact reference metadata.'
    b = src.read_bytes()
    dst = P / 'evidence' / (str(src.relative_to(S)) + '.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    assert not dst.exists()
    dst.write_bytes(gzip.compress(b, mtime=0))
    rows.append(dict(original=str(src), preserved=str(dst.relative_to(P)), bytes=len(b), sha256=sha(b)))
(P / 'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Complete frozen authored and repository/review evidence; no third-party book redistributed.', files=rows), indent=2) + '\n')
reconstructor = W / '.claude/science/physics-loops/toe-boost-quantitative-outgoing-20261012/reconstruct.py'
(P / 'reconstruct.py').write_bytes(reconstructor.read_bytes())
print(json.dumps(dict(own_evidence_files=len(rows), snapshot_documents=len(texts))))
