"""Preserve both complete S/L controls beneath publication metadata."""
from pathlib import Path
import hashlib
import json
import subprocess

S = Path(__file__).resolve().parent
W = S.parent / 'quantitative_boost_worktree'
P = W / '.claude/science/physics-loops/toe-boost-threshold-sharpness-20261012'
BASE = '36d6069676f561d81ad693f286dd52f570fb37df'
assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip() == BASE
assert not subprocess.check_output(['git', '-C', str(W), 'status', '--porcelain'])
P.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
SNOTE = 'docs/HSTAR_THRESHOLD_SPECTRAL_BOUNDED_THEOREM_NOTE_2026-10-12.md'
LNOTE = 'docs/ACTUAL_CORRECTOR_SMALL_TIME_LOWER_BOUNDED_THEOREM_NOTE_2026-10-12.md'
QNOTE = 'docs/BOOST_QUANTITATIVE_CORRECTOR_BOUNDED_THEOREM_NOTE_2026-10-12.md'
BNOTE = 'docs/EXCLUDED_WALK_BOOST_BRACKET_CONTROL_BOUNDED_THEOREM_NOTE_2026-10-11.md'
outputs = []
for label, source, expected, primary, inputs, records, scope in [
    ('S', 'hstar_threshold_spectral/threshold_controls.py',
     'e4dc9cdc2c2d22476f7e15fcaffc326660aaa03c9b0fef6623830f32e8f09cc6',
     'scripts/hstar_threshold_spectral_2026_10_12.py', [SNOTE, BNOTE], 36,
     'Physical finite Pauli/resolvent and separate radial-model controls; continuum local measure and free threshold law require S1-S20.'),
    ('L', 'actual_corrector_small_time_lower/actual_lower_controls.py',
     'a9b5bd5986d3cd4752c1f8dabcb7157da240baa2f7424f11c75eae3d743b437b',
     'scripts/actual_corrector_small_time_lower_2026_10_12.py', [LNOTE, SNOTE, QNOTE, BNOTE], 36,
     'Physical finite Pauli and noncommuting ODE controls; actual continuum sharpness requires L1-L20 and the separate S threshold law.')]:
    src = S / source
    original = src.read_bytes()
    assert sha(original) == expected
    prefix = ('#!/usr/bin/env python3\n"""Complete original finite controls; scope is recorded below and in the note."""\n'
              + 'AUDIT_TIMEOUT_SEC = 120\nAUDIT_INPUT_PATHS = ' + repr(inputs) + '\n'
              + 'if not __debug__:\n    raise RuntimeError("Run without -O: control assertions must be enabled")\n\n')
    suffix = ('\nprint("per_element: complete original algebra and constant controls checked")\n'
              + 'print("per_site: checked and not executed — no volume-limit inference")\n'
              + 'print("per_mode: finite spectral or forced-evolution identities checked")\n'
              + 'print("per_block: physical finite parity and global mean projection checked")\n'
              + 'print("lattice_wide: checked and not executed — continuum conclusions rest on the written proof")\n'
              + f'print("TOTAL: PASS={records} FAIL=0")\n'
              + 'print(' + repr('SCOPE: ' + scope + ' No physical realization or audit verdict from this runner.') + ')\n')
    body = prefix + original.decode() + suffix
    assert not (W / primary).exists()
    (W / primary).write_text(body)
    outputs.append(dict(label=label, kind='primary', publication_path=primary,
                        publication_sha256=sha(body.encode()), prefix=prefix, suffix=suffix,
                        sources=[dict(source_path=str(src), source_sha256=expected,
                                      preserved_source='evidence/' + source + '.gz', wrapper=None)]))
(P / 'PRIMARY_COMPOSITION.json').write_text(json.dumps(dict(outputs=outputs), indent=2) + '\n')
print(json.dumps([dict(path=r['publication_path'], sha256=r['publication_sha256']) for r in outputs]))
