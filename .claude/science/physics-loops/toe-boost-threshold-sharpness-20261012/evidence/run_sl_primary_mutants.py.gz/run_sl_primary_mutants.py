"""Execute literal defects in complete S/L publication primaries."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
W = S.parent / 'quantitative_boost_worktree'
D = S / 'sl_primary_mutations'
D.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
rows = []
for label, folder, primary in [
    ('S', 'hstar_threshold_spectral', 'scripts/hstar_threshold_spectral_2026_10_12.py'),
    ('L', 'actual_corrector_small_time_lower', 'scripts/actual_corrector_small_time_lower_2026_10_12.py')]:
    original = (W / primary).read_text()
    baseline_output = (S / folder / 'baseline.stdout.log').read_bytes()
    for old in json.loads((S / folder / 'mutation_manifest.json').read_text()):
        name = label + '_' + old['name']
        assert original.count(old['before']) == 1
        body = original.replace(old['before'], old['after'], 1)
        path = D / (name + '.py')
        path.write_text(body)
        command = [sys.executable, str(path)]
        utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
        start = time.monotonic()
        try:
            done = subprocess.run(command, cwd=W, capture_output=True, timeout=120)
            out, err, code, timed_out = done.stdout, done.stderr, done.returncode, False
        except subprocess.TimeoutExpired as failure:
            out, err, code, timed_out = failure.stdout or b'', failure.stderr or b'', None, True
        elapsed = time.monotonic() - start
        (D / (name + '.stdout')).write_bytes(out)
        (D / (name + '.stderr')).write_bytes(err)
        row = dict(name=name, primary_path=primary, primary_sha256=sha(original.encode()),
                   before=old['before'], after=old['after'], expected_assertion=old['expected_assertion'],
                   command=command, cwd=str(W), started_utc=utc, timeout_seconds=120,
                   elapsed_seconds=elapsed, exit_code=code, timed_out=timed_out,
                   source_sha256=sha(body.encode()), stdout_sha256=sha(out), stderr_sha256=sha(err),
                   intended_failure=('AssertionError: ' + old['expected_assertion']) in err.decode(),
                   stdout_baseline_prefix=baseline_output.startswith(out))
        (D / (name + '.execution.json')).write_text(json.dumps(row, indent=2) + '\n')
        rows.append(row)
        (D / 'manifest.json').write_text(json.dumps(dict(runs=rows), indent=2) + '\n')
        assert code == 1 and not timed_out and row['intended_failure'] and row['stdout_baseline_prefix'], row
        print(json.dumps(dict(name=name, exit_code=code, intended_failure=True, elapsed_seconds=elapsed)), flush=True)
assert len(rows) == 13
