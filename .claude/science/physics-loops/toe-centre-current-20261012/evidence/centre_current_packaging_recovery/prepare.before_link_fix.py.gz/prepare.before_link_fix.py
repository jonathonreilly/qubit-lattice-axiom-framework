"""Package two reviewed conditional lemmas, retaining complete frozen proofs."""
from pathlib import Path
import gzip,hashlib,json,subprocess
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-centre-current-20261012'
BASE='f6f4348151734908dea3b32048ee1f36f694035b'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==BASE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
for key in ['Centre','Current']:assert json.loads((S/f'{key}_root_review_coverage.json').read_text())['review_accepted']
P.mkdir(exist_ok=False)
specs=[dict(key='Centre',prefix='ISOLATED_CENTRE_FILTERING',slug='isolated_centre_filtering',source='ISOLATED_CENTRE_FILTERING_PROBE.md',
    source_sha='1dcb9580d128d8fc41b76517ce0fe18842291e8e32681fa9c6b22f0feb1e13de',folder='isolated_centre_filtering',review='isolated_centre_review',helper='check_filter_algebra.py',
    report='ISOLATED_CENTRE_FILTERING_REVIEW.md',deps=['compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11','compact_patch_fock_isometry_bounded_theorem_note_2026-10-12','compact_detector_convergence_bounded_theorem_note_2026-10-12'],
    prerequisites=['COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md','COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md','COMPACT_DETECTOR_CONVERGENCE_BOUNDED_THEOREM_NOTE_2026-10-12.md'],
    scope='Actual implemented commuting finite-range flows, isolated positive mass and explicit mass-momentum restricted central spectral isolation give exact almost-local creators for arbitrary selected characters, with covered scattering, Fock and fixed-arrangement detector extensions under their separately stated hypotheses. No common finite order, microscopic realization or exhaustion follows.'),
 dict(key='Current',prefix='MICROSCOPIC_CURRENT_IMPLEMENTATION',slug='microscopic_current_implementation',source='MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md',
    source_sha='bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a',folder='microscopic_current_implementation',review='microscopic_current_review',helper='finite_controls.py',
    report='MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md',deps=[],prerequisites=[],
    scope='For bounded finite-range spin densities and supplied self-adjoint H, B, P with exact local cyclic H and first-moment B actions and P=i[H,B] on that domain, derive the finite-range current, common local analytic radius, norm thermodynamic dynamics and full canonical GNS adjoint implementation. Boost realization, strong joint commutation and a physical model remain supplied.')]
rows=[]
for sp in specs:
    note=sp['prefix']+'_BOUNDED_THEOREM_NOTE_2026-10-12.md';runner=sp['slug']+'_2026_10_12.py'
    sp.update(note=note,runner=runner,claim=sp['slug']+'_bounded_theorem_note_2026-10-12')
    src=S/sp['source'];raw=src.read_text();assert sha(src.read_bytes())==sp['source_sha'];edits=[]
    def edit(before,after,reason):
        global raw
        assert raw.count(before)==1,(sp['key'],before[:60],raw.count(before))
        raw=raw.replace(before,after,1);edits.append(dict(before=before,after=after,reason=reason))
    meta='---\nclaim_id: '+sp['claim']+'\nclaim_type: bounded_theorem\nclaim_scope: '+json.dumps(sp['scope'])+'\nupstream_dependencies:'+ ('\n'+''.join('  - '+d+'\n' for d in sp['deps']) if sp['deps'] else ' []\n')+'runner: scripts/'+runner+'\n'
    if sp['key']=='Centre':
        first=raw.splitlines()[0]
        extra='actual_current_surface_status: conditional-support\ntarget_claim_type: bounded_theorem\ntrace_class: upstream_support\nreachability_to_target: partially_closes\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\n---\n\n'
        edit(first,meta+extra+first,'Register scoped claim and actual predecessor proof dependencies.')
        edit('**Claim type:** conditional bounded theorem. **Status:** author derivation, independent review pending.','**Claim type:** conditional bounded theorem. **Status:** complete separate source review supports I1–I34; no applied audit verdict or retained status.','Record completed review without altering the theorem.')
        old=next(x for x in raw.splitlines() if x.startswith('Write S for /Users/'))
        edit(old,'S denotes the original research collection. The [complete milestone packet](../.claude/science/physics-loops/toe-centre-current-20261012/) preserves frozen sources, author evidence and independent review. The following sources are unchanged. Labels SC, F and C refer to their displayed equations or sections.','Provide portable recovery path.')
        old=next(x for x in raw.splitlines() if x.startswith('This author theorem requires a fresh focused check'))
        edit(old,'Frozen author operational record: '+old+' Publication update: the separate source check below is complete; the historical pending statement describes the author freeze.','Preserve historical operations and distinguish completed review.')
        reviewtext='''The separate review supports all I1–I34 with no required mathematical correction.
Report68ea0c2f00d0808ce5a6a63632b0bc84a05398260478510fb4f66256e885cbc9,
receipt8eeb364e11eb54d3cb4a6127596d6f9d422f6acd9d88b1275346922661c99abc.
The full reconstruction and distinct four-site spin/current-flow calculation
froze before author-helper exposure. The initial Fourier truncation failed
the declared1e-8 tolerance; resolution refinement at unchanged tolerance gave
error4.02e-14. The failure, both code versions and complete logs are preserved.
Author reproduction was byte-exact. Ten copied-source defects were rejected.
One survived: deleting the positive shift from the successful final-radius
inequality weakens that inequality. The source's separate overfilled-budget
counterexample does not test every support step. The analytic construction
explicitly includes the geometric displacement; arithmetic alone does not
prove locality. No uniform shrinking-collar bounds or microscopic irrational
sector are supplied. The accumulating-atom, nonatomic and unresolved-clock
examples retain their limited spectral scope.
'''
    else:
        edit('---\nactual_current_surface_status:',meta+'actual_current_surface_status:','Register self-contained conditional claim; contextual index/scattering sources are not proof dependencies.')
        edit('**Author derivation, 2026-10-12; independent review required.**','**Conditional bounded theorem, 2026-10-12; complete separate I1–I31 source review supports the implication.**','Record completed source review only.')
        old=next(x for x in raw.splitlines() if x.startswith("Write S for this note's directory."))
        edit(old,'S denotes the original research collection. The [complete milestone packet](../.claude/science/physics-loops/toe-centre-current-20261012/) preserves the frozen proposal, full control logs, independent review, recovery history and source identities. Prior science remains unchanged.','Provide portable recovery path.')
        edit('Independent proof review remains pending, and no retained or audit status is asserted.','Independent proof review was pending at author freeze; the completed review below confers no retained or audit status.','Distinguish historical author freeze from current review.')
        old=next(x for x in raw.splitlines() if x.startswith('Root supplied the candidate mechanism and is a coauthor. A fresh independent'))
        edit(old,'Frozen author operational record: '+old+' Publication update: the exact final argument has now received the separate source review below.','Preserve historical recovery without stale current review status.')
        reviewtext='''The separate review supports all I1–I31 with no required mathematical correction.
Report305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17,
receipt1e8f868b6722ce57d60c626d3899e08f28fe6183e7aef5533a2891f96bb803fc.
Its reconstruction and occupation-basis hopping control froze before author
helper exposure. A closed-form current exponential and nonseparating vacuum
test the full algebra, including a wrong right action with identical vacuum
columns but nonzero operator defects. All34independent predicates and all50
original rows passed. Five actual copied-source defects were rejected; known
nondiscriminating rows, including the contiguousa=3history fixture throughorder7,
are retained. Finite controls do not prove the domain or thermodynamic argument.
Original author logs lack per-run timeout/elapsed receipts; no metadata is
invented. Reviewer runs recorded60second limits and0.250/0.679second completion.
The two platform disconnects, late-draft discrepancy and all saved versions remain.
The published helper suppresses only its adjacent JSON-file side effect,
declares audit inputs and prints scoped execution totals. Every calculation is
unchanged; the printed helper hash changes with these explicit packaging edits.
'''
    for line in list(dict.fromkeys(x for x in raw.splitlines(keepends=True) if x.rstrip('\r\n').endswith((' ','\t')))):
        edit(line,line.rstrip()+'\n','Normalize presentation-only trailing whitespace.')
    append='\n\n## Publication verification and remaining obligations\n\n'+reviewtext+'''
Root proposed the mechanism and is a contributor, not the independent reviewer.
Shared source/metadata exposure is disclosed in the review; it is not blind
checking or an independence claim based on predicate counts. Complete proofs,
controls, review, failures and source hashes are preserved in the packet.
PUBLICATION_EDITS.json and reconstruct.py recover the note and entire primary
from frozen bytes and explicit metadata edits. No displayed mathematics changes.
The [finite primary](../scripts/'''+runner+''') is an executable finite check;
DELIVERY_CHECKS.md records its actual run and mechanical publication checks.
No Lean certificate, applied audit verdict, physical axiom change or retained
promotion is asserted. Global combined audit and strict audit lint remain
independent landing gates. The sole live campaign checkpoint remains in the
transport worktree; this packet is a frozen milestone.
'''
    (W/'docs'/note).write_text(raw+append)
    rows.append(dict(kind='note',source_path=str(src),source_sha256=sha(src.read_bytes()),preserved_source='evidence/'+src.name+'.gz',edits=edits,appended_text=append,publication_path='docs/'+note,publication_sha256=sha((raw+append).encode())))
    helper=S/sp['folder']/sp['helper'];body=helper.read_text();edits=[]
    inputs=['docs/'+note]+['docs/'+n for n in sp['prerequisites']]
    anchor='from fractions import Fraction as F\n'
    declarations='\nAUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = '+json.dumps(inputs,indent=4)+'\nif not __debug__:\n    raise RuntimeError("Run without -O: finite control assertions must be enabled")\n\n'
    addition=declarations+anchor
    assert body.count(anchor)==1
    body=body.replace(anchor,addition,1);edits.append(dict(before=anchor,after=addition,reason='Declare actual input paths, timeout and assertion guard.'))
    suffix=''
    if sp['key']=='Centre':
        suffix='\nprint("TOTAL: PASS=8 FAIL=0")\nprint("SCOPE: Eight finite algebra groups; no analytic convergence or microscopic realization certificate.")\n'
    else:
        before="    (path.parent/'finite_controls_results.json').write_text(json.dumps(result, indent=2)+'\\n')"
        after='    # Canonical runner reports through stdout; frozen original JSON is preserved in the milestone packet.'
        assert body.count(before)==1;body=body.replace(before,after,1);edits.append(dict(before=before,after=after,reason='Suppress only adjacent output-file write during canonical execution.'))
        before="    raise SystemExit(1 if result['failed_checks'] else 0)"
        after='    print("TOTAL: PASS="+str(result["total_checks"]-result["failed_checks"])+" FAIL="+str(result["failed_checks"]))\n    print("SCOPE: Finite controls only; no domain, thermodynamic or physical-realization certificate.")\n'+before
        assert body.count(before)==1;body=body.replace(before,after,1);edits.append(dict(before=before,after=after,reason='Report finite execution totals and scope without changing failure gates.'))
    primary=body+suffix;(W/'scripts'/runner).write_text(primary)
    rows.append(dict(kind='primary',source_path=str(helper),source_sha256=sha(helper.read_bytes()),preserved_source='evidence/'+str(helper.relative_to(S))+'.gz',edits=edits,appended_text=suffix,publication_path='scripts/'+runner,publication_sha256=sha(primary.encode())))
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=rows),indent=2)+'\n')
(S/'centre_current_specs.json').write_text(json.dumps(specs,indent=2)+'\n')
texts={
'STATE.yaml':'loop: toe-centre-current-20261012\nmode: milestone_snapshot\ndelivery: milestone\nactive_branch: physics-loop/toe-compact-patch-scattering-20261011\nbase_revision: '+BASE+'\ntarget_claim_type: bounded_theorem\nactual_current_surface_status: conditional-support\nindependent_check: two_separate_complete_source_reviews\npr: 9486\npr_status: preparing_regular_extension\nlive_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree\n',
'GOAL.md':'# Exact contract\n\nDerive arbitrary isolated-character creators from supplied actual commuting\nflows, and derive the full finite-range momentum implementation from exact\nlocal-vector boost hypotheses. Preserve each theorem\'s separate premises.\n',
'ASSUMPTIONS_AND_IMPORTS.md':'# Supplied inputs\n\nCentre: actual finite-range H/current flows, their strong commutation, isolated\npositive mass and explicit whole-patch character isolation. Unique vacuum/gap\nand detector energy remainder are additional downstream premises.\nCurrent: actual self-adjoint H/B/P and exact local cyclic actions and commutator\nclosure. No positivity or scattering proof is used. Contextual index sources\nare not a proof dependency. No physical axiom is added; no actual model is built.\n',
'APPROACH_REGISTRY.md':'# Derivations\n\nCentre: uniform flow truncation plus Schwartz Fourier tails, exact restricted\nspectral selection, then matched SC/Fock/PC direct hypotheses.\nCurrent: finite padded Jacobi, connected support histories, norm Taylor limits,\nthen state invariance and canonical GNS full-algebra implementation.\n',
'ROUTE_PORTFOLIO.md':'# Evidence roles\n\nEach complete source has a separate reconstruction and distinct finite control\nfrozen before author-helper inspection. Root is coauthor. Reproductions/hashes\nestablish provenance, not proof or physical realization.\n',
'OPPORTUNITY_QUEUE.md':'# Remaining work\n\nTime-averaged creators under geometric regularity, centre-to-shell spectral\ncontrol, exact local conservation to joint flows, then an actual microscopic\nrealization and justified channel coverage. These remain separate candidates.\n',
'NO_GO_LEDGER.md':'# Limited negative findings\n\nPreserve the accumulating-character continuous-selector obstruction, nonatomic\nzero atom, unresolved-clock counterexample, full-algebra vacuum-column gap,\ndomain/padding counterexamples and control nondiscrimination. Alternative\nmeasurable/time-averaged selectors and different microscopic models remain open.\nNo universal lattice or TOE no-go is asserted. Complete scope assessments retained.\n',
'LITERATURE_BRIDGES.md':'# Source reuse\n\nCentre reuses complete unchanged SC/Fock/PC proofs and their independently\nchecked analytic dependencies after matching actual hypotheses. Current is\nself-contained at the supplied self-adjoint/domain scope; no unchecked Nelson\ntheorem is imported. No novelty claim or new full primary-paper review.\n',
'ARTIFACT_PLAN.md':'# Regular milestone\n\nExtend regular PR9486 with two full notes/primaries/caches and complete frozen\nevidence. Earlier science remains unchanged. No draft, merge or main push.\n',
'TRACE_GATE.md':'# Trace\n\ntrace_class: upstream_support\nreachability_to_target: partially_closes\nartifact_role: theorem\ntarget_claim_id: null\ntarget_blocker_text: Exact creator selection and actual current implementation require stated mathematical bridges.\nsource_of_blocker_text: source_derivation\nnext_trace_action: Verify remaining commutation/spectral conditions and build an actual model.\n',
'CLAIM_STATUS_CERTIFICATE.md':'# Status\n\nactual_current_surface_status: conditional-support\ntarget_claim_type: bounded_theorem\nstatus: provisional\nindependent_review_status: two_complete_separate_source_checks_no_required_correction\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\n\nNo Lean, applied audit verdict or retained promotion.\n',
'REVIEW_HISTORY.md':'# Source-bound reviews\n\nComplete frozen source/report/receipt identities are in PUBLICATION_EDITS.json\nand the preserved Centre_root_review_coverage.json and Current counterpart.\nRoot read both complete proofs/reconstructions, all controls, failures and scope\nassessments. Centre154outputs/62sourcepairs; current81outputs/40authorbindings\nchecked. Initial Fourier-resolution failure and surviving weaker radius test\nremain explicit. Current original timing metadata is incomplete; new reviewer\nruns have exact receipts. No source correction was required.\n',
'HANDOFF.md':'# Frozen milestone\n\nRegular PR9486 extension from '+BASE+'.\nComplete proof and primary reconstruction mappings preserve original arguments.\nNo strong-commutation, model or completeness conclusion is supplied beyond\neach theorem\'s explicit premises. The live recovery checkpoint is in the\ntransport worktree. Fixed deadline2026-10-12 16:00:52UTC; never extend it.\n',
'PR_BACKLOG.md':'# Delivery\n\nRun original whole primaries with current inputs, actual complete-source\ndefects, source reconstruction, fresh caches, graph acknowledgment and focused\ncompatibility. Global audit pipeline and strict audit lint remain landing gates.\n'}
for n,t in texts.items():(P/n).write_text(t)
paths=[S/n for n in ['verify_centre_current_reviews.py','verify_centre_current_reviews.before_path_fix.py','centre_current_root_operational_failures.json']]
for sp in specs:
    paths.extend(S/n for n in [sp['source'],sp['report'],sp['key']+'_root_author_coverage.json',sp['key']+'_root_review_coverage.json'])
    for folder in [sp['folder'],sp['review']]:paths.extend(p for p in (S/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths.extend(p for p in (S/'centre_current_packaging_recovery').rglob('*') if p.is_file())
own=[]
for p in sorted(set(paths)):
    assert p.suffix.lower() not in ['.pdf','.png','.jpg']
    b=p.read_bytes();dest=P/'evidence'/(str(p.relative_to(S))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0))
    own.append(dict(original=str(p),preserved=str(dest.relative_to(P)),bytes=len(b),sha256=sha(b)))
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Complete own/repository evidence, no third-party primary media',files=own,external_reference_sources=[]),indent=2)+'\n')
recon=(W/'.claude/science/physics-loops/toe-detector-index-leakage-20261012/reconstruct.py').read_text().replace('Complete leakage note and entire finite primary','Both complete centre/current notes and entire finite primaries')
(P/'reconstruct.py').write_text(recon)
print(json.dumps(dict(outputs=[{k:r[k] for k in ['kind','publication_path','publication_sha256']} for r in rows],own_evidence=len(own),documents=len(texts))))
