"""Verify and stage the complete two-theorem conditional milestone."""
from pathlib import Path
from urllib.parse import unquote
import ast,gzip,hashlib,json,os,re,subprocess,sys
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree';P=W/'.claude/science/physics-loops/toe-centre-current-20261012'
BASE='f6f4348151734908dea3b32048ee1f36f694035b'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest();js=lambda p:json.loads(p.read_text())
rows=js(P/'PUBLICATION_EDITS.json')['outputs'];specs=js(S/'centre_current_specs.json');assert len(rows)==4
canonical={s['key']:js(S/f'{s["key"]}_canonical_execution.json') for s in specs}
for sp in specs:
    e=canonical[sp['key']];assert e['status']=='ok' and e['exit_code']==0 and e['timeout_sec']==60 and not e['stderr']
    body=(W/'scripts'/sp['runner']).read_text();ast.parse(body)
    if sp['key']=='Centre':
        old=(S/'isolated_centre_filtering/finite_controls.stdout').read_text();assert len(old.splitlines())==9
        assert e['stdout'].startswith(old) and len(e['stdout'][len(old):].splitlines())==2
    else:
        out=e['stdout'].splitlines();old=(S/'microscopic_current_implementation/logs/finite_controls.final.jsonl').read_text().splitlines()
        assert out[:50]==old[:50] and len(out)==53
        assert json.loads(out[50])==dict(total_checks=50,failed_checks=0,runner_sha256=sha(body.encode()))
runs=js(S/'centre_current_primary_mutations/manifest.json')['runs'];assert len(runs)==16
for r in runs:
    body=(W/r['primary_path']).read_text();assert sha(body.encode())==r['primary_sha256'] and body.count(r['before'])==1
    p=S/'centre_current_primary_mutations'/(r['key']+'_'+r['name']+'.py')
    assert p.read_text()==body.replace(r['before'],r['after'],1) and sha(p.read_bytes())==r['source_sha256']
    out=p.with_suffix('.stdout').read_bytes();err=p.with_suffix('.stderr').read_bytes()
    assert sha(out)==r['stdout_sha256'] and sha(err)==r['stderr_sha256']
    assert r['exit_code']==(0 if r['expected_survival'] else 1)
    if r['key']=='Centre':
        if r['expected_survival']:assert out==canonical['Centre']['stdout'].encode() and not err
        else:
            assert b'AssertionError' in err and canonical['Centre']['stdout'].encode().startswith(out)
            assert err.decode().splitlines()[-1]==(S/'isolated_centre_review/mutations'/f'{r["name"]}.stderr').read_text().splitlines()[-1]
    else:
        expected=js(S/'microscopic_current_review/mutations'/r['name']/'finite_controls_results.json')['results']
        assert [json.loads(x) for x in out.decode().splitlines()[:50]]==expected and not err
graph=W/'docs/audit/data/citation_graph_manifest.json'
before=json.loads(subprocess.check_output(['git','show',BASE+':'+str(graph.relative_to(W))]));after=js(graph)
assert after['node_count']==before['node_count']+2 and after['edge_count']==before['edge_count']+3
assert all(after['nodes'].get(k)==v for k,v in before['nodes'].items())
assert {k:v['out_degree'] for k,v in after['nodes'].items() if k not in before['nodes']}=={s['claim']:len(s['deps']) for s in specs}
compat=js(S/'centre_current_focused_audit_compat.json');assert compat['checked']==compat['failures']==compat['control_failures']==[]
(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete source composition

Root read both complete author arguments and every necessary premise, the
separate frozen reconstructions, all finite controls and their full outputs,
failure traces, assessments and source bindings. Root proposed the mechanisms
and is a contributor, not their independent reviewer. Both source reviews found
no required mathematical correction. Their supplied premises remain conditional.

Publication adds only claim/dependency/status/recovery metadata, labels author
history and records the completed reviews. No displayed mathematical argument
changes. The full primaries preserve every original calculation; current only
suppresses its adjacent result-file write and adds declared inputs/summary scope.
Its changed self-hash is explicitly accounted for. Exact reconstruction validates
both entire notes and both entire primaries from frozen bytes and declared edits.

The centre theorem uses the in-branch SC/Fock/PC arguments at matched direct
hypotheses, retaining its separate gap and detector conditions. The current
lemma is self-contained and imports no index/scattering proof; those files
are contextual records of the earlier obligation. No circular dependency is
introduced: the centre theorem still supplies its implementation assumptions.

No previous science source changes. No Lean, model, strong joint commutation,
full channel coverage, ND, EX, audit verdict or retained promotion is asserted.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped delivery evidence

The centre primary exited0 in{canonical['Centre']['elapsed_sec']:.9f}s/60s;
current exited0 in{canonical['Current']['elapsed_sec']:.9f}s/60s. Both stderr
streams are empty. Every original centre output record and all50current rows
reproduce exactly. Only declared summary/scope lines and the current source
hash differ. The canonical current execution writes no adjacent result file.

Sixteen actual complete-primary variants were executed with60second bounds.
Fifteen fail at their intended mathematical gates. One centre radius variant
passes because deleting a positive shift weakens the successful arithmetic
inequality; it is explicitly preserved as nondiscrimination. Current variants
give exactly the earlier full failed-row data, with their new primary hashes.
All complete source deltas, stdout/stderr, commands, elapsed times and exit
statuses are preserved. Finite arithmetic does not certify analytic convergence.

The citation graph has{after['node_count']}nodes/{after['edge_count']}edges,
adding2nodes and3centre dependency edges; all older nodes are unchanged.
Current has no imported theorem dependency. Focused changed-evidence compatibility
selects no applied row and reports no failures. Global combined audit and strict
audit lint were not run; these remain independent landing gates. No verdict applied.

Exact reconstruction, syntax, current cache/input identities, local links,
all evidence and staged hashes, vocabulary fix/report and whitespace are checked
before commit. All previous science and frozen milestone packets remain unchanged.
Original author timing metadata and reviewer nondiscrimination remain explicit.
''')
p=P/'REVIEW_HISTORY.md';p.write_text(p.read_text().split('\n## Publication conformance')[0]+'''
## Publication conformance

Both complete arguments and primaries reconstruct exactly. Actual primary
mutants preserve15rejections and1known surviving weakened inequality. Two fresh
canonical caches, citation acknowledgment and focused compatibility are checked.
Root packaging initially used an absent import anchor; exact partial files and
failed source are preserved, then recreated from the frozen sources with the
correct anchor. Initial citation verification then found missing graph edges:
the existing graph reads document links, while the centre frontmatter alone
had declared its three dependencies. Explicit links to those same proofs were
added, the affected cache refreshed and graph/compatibility rebuilt. No source
proof changed. Both failed records are preserved. Regular PR extension only.
''')
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in rows]+[P/'reconstruct.py']
for mode in ['fix','report-only']:
    prefix=S/('centre_current_final_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
    prefix.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
    report=js(prefix.with_suffix('.json'));assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'centre_current_final_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
for sp in specs:
    path='scripts/'+sp['runner'];assert runner_cache.cache_status(path)==runner_cache.cache_identity_status(path)=='fresh'
links=[]
for p in editable:
    if p.suffix!='.md':continue
    prose=[];fenced=False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
    prose_text='\n'.join(prose)
    prose_text=re.sub(r'\\\[.*?\\\]', '', prose_text, flags=re.S)
    prose_text=re.sub(r'\\\(.*?\\\)', '', prose_text, flags=re.S)
    for target in re.findall(r'\]\(([^)\s]+)\)',prose_text):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(p,target)
        links.append(dict(source=str(p.relative_to(W)),target=target))
emap=js(P/'EVIDENCE_MAP.json');evidence={r['preserved']:r for r in emap['files']}
def preserve(src):
    b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(b,mtime=0)
    if dst.exists():assert dst.read_bytes()==packed
    dst.write_bytes(packed);evidence[str(dst.relative_to(P))]=dict(original=str(src),preserved=str(dst.relative_to(P)),bytes=len(b),sha256=sha(b))
for p in sorted((S/'centre_current_primary_mutations').rglob('*')):
    if p.is_file():preserve(p)
for p in sorted((S/'centre_current_packaging_recovery').rglob('*')):
    if p.is_file():preserve(p)
for n in ['prepare_centre_current_publication.py','run_centre_current_verification.py','finish_centre_current_delivery.py','centre_current_specs.json',
    'repair_centre_citation_links.py','centre_link_vocab_fix.json','centre_link_vocab_fix.log',
    'Centre_canonical_execution.json','Current_canonical_execution.json','centre_current_initial_vocab_fix.json','centre_current_initial_vocab_fix.log','centre_current_initial_reconstruction.log',
    'centre_current_final_vocab_fix.json','centre_current_final_vocab_fix.log','centre_current_final_vocab_report-only.json','centre_current_final_vocab_report-only.log','centre_current_final_reconstruction.log',
    'centre_current_citation_execution.json','centre_current_citation_build.stdout','centre_current_citation_build.stderr','centre_current_citation_manifest.stdout','centre_current_citation_manifest.stderr',
    'centre_current_focused_audit_compat.json','centre_current_focused_audit_compat.stderr','centre_current_focused_audit_compat.execution.json']:
    preserve(S/n)
for r in evidence.values():
    b=gzip.decompress((P/r['preserved']).read_bytes());assert len(b)==r['bytes'] and sha(b)==r['sha256']
assert not emap['external_reference_sources']
mech=dict(full_source_reconstruction=True,canonical_elapsed_seconds={k:e['elapsed_sec'] for k,e in canonical.items()},actual_primary_mutants=16,intended_failures=15,nondiscriminating_passes=1,
 cache_and_input_identity_fresh=True,citation_delta=dict(nodes=2,edges=3),every_old_graph_node_unchanged=True,
 preserved_evidence_files_before_this_record=len(evidence),external_primary_bindings=0,ordinary_links=links,
 scope='Mechanical provenance/execution only; separate complete source reconstruction supplies mathematical review.')
(S/'centre_current_delivery_mechanical.json').write_text(json.dumps(mech,indent=2)+'\n');preserve(S/'centre_current_delivery_mechanical.json')
emap['files']=[evidence[k] for k in sorted(evidence)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in rows]+[graph]+[runner_cache.cache_path_for('scripts/'+s['runner']) for s in specs]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
    row=dict(path=str(p.relative_to(W)),sha256=sha(p.read_bytes()))
    if p.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(p.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,scope='Exact intended publication set except this self-referential manifest.',files=ident),indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True,timeout=60);subprocess.run(['git','diff','--cached','--check'],check=True,timeout=60)
for r in ident:assert sha(subprocess.check_output(['git','show',':'+r['path']]))==r['sha256']
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}==set(paths)
assert not subprocess.check_output(['git','diff','--name-only'])
assert all(x.startswith('A\t') or x=='M\tdocs/audit/data/citation_graph_manifest.json' for x in subprocess.check_output(['git','diff','--cached','--name-status'],text=True).splitlines())
result=dict(staged_files=len(paths),staged_hashes_match=True,whitespace_clean=True,preserved_evidence_files=len(evidence),**mech)
(S/'centre_current_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
