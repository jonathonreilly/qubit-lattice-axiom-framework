# Isolated central-character filtering — current checkpoint

This is the single current recovery surface for the new bounded author derivation. The adjacent ISOLATED_CENTRE_FILTERING_PROBE.md is complete at I1–I34; the freeze receipt, once present, is the authoritative exact identity. Independent review of this extension remains outstanding. Do not mutate this packet after freeze.

Fixed parent-campaign deadline: 2026-10-12 16:00:52 UTC, unchanged. Preserve the inherited model and effort. No subdelegation, repository/Git/PR/publication/audit/axiom/prompt mutation or other-chat messaging. Only this external note and isolated_centre_filtering/ have been written. Editable prompt files changed: none.

## Exact state and scientific result

Read-only source tree at launch: 296155eda2ca6a5ab6ae6307190362b9a84ea690; refreshed observation: 5cbc581504721a323f5fa2064694a67141a3ee98 after root's concurrent projection publication. The complete 203-path inventory and every bound repository input were checked: the relevant intersection is empty and those input Git blobs are byte-identical. Planning AGENTS revision: 3a4b2c66a1ead7a1c48b4359627e968f681e3c39. Applicable instruction bytes remain unchanged and were reused from complete earlier campaign reading. Full identities and reading limits are in SOURCE_LEDGER.json.

- Original SC source d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a.
- Fock source 9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404.
- PC source bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64; its completed separate review is bound in the ledger.
- Projection source 91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4 is unchanged and is not a premise. Its review was pending at launch; root later reported completion, without that outcome being imported here.

The exact replacement for finite-order centre averaging is
C_phi(B)=sum_j c_phi(j) Ad(V_j)(B), with c_phi(j)=integral exp(-ij theta) phi(theta) and V_j=e^(ijK) T_j. The vacuum column is phi(V)B Omega. The full operator instead has central transition-difference multiplier phi(theta_out-theta_in); no global left-projection or eigenoperator assertion is made.

The new uniform almost-locality proof uses B_{R/4}, accounts for the geometric displacement |j|_1, splits at |j|_1<=cR with c=1/[8d(1+v)], truncates d current flows with padding R/(2d) each, and sums the remaining Fourier tail by norm. The final local support is inside 7R/8, and the LR exponent margin is at least R/(4d) after rounding. All norm H derivatives commute through the bounded map and have the same locality proof.

The local sufficient spectral hypothesis is I5:
E_M 1_O(K) P^V(U_theta minus {theta})=0
on every declared open patch, with a countable covered union and no uniform collar requirement. Exact mass/current filtering then gives C_phi(B_g(A)) Omega=P^V({theta}) h(K)E_M A Omega. Global isolation of theta on the mass component is sufficient, but is not inferred from I5. Density is proved exactly on the declared covered spectral subspace. No claim of strict weakening after full integrated Poincare disintegration is made.

Geometric refiltering supplies the full operator momentum carrier while preserving the vacuum vector. The exact chart relation remains k=p+theta+2pi n. Compact Cook limits, creator-independence and fixed V covariance reuse direct-property proofs. With the original unique-vacuum/gap condition, the Fock Gram/isometry proof works for finitely many selected covered mass/character sectors. Fixed-arrangement PC and its positive detector limit work with the same direct geometric/energy/cutoff hypotheses and new creator seminorm constants. No common finite q, ND, EX, all-channel coverage, boost covariance or physical realization is inferred.

Finite arbitrary relevant central spectra also admit the multivariate polynomial I34. The four torsion characters {(±1,±1)} disprove the shortcut of finding one separating integer direction.

## Evidence, corrections and next decision

Eight finite controls ran once under 60 seconds: exit 0, elapsed 0.05947150010615587 seconds, nine stdout records, empty stderr. They reject the specified wrong Fourier/chart signs, outgoing-only multiplier, incorrect adjoint preservation, omitted mass restriction, single-direction separation, omitted geometric displacement, and unresolved packet clock. They do not certify analytic convergence. The first source check verified 25 inputs and all 63 PC plus 57 projection predecessor bindings. Final binding/freeze checks have separate retained log names.

The complete author source read caught and repaired two missing printed addition signs in I16/I17 from patch-marker formatting and removed a redundant math escape in I33. OPERATIONAL_HISTORY.md preserves these defects and the truncated aggregate displays. The final source check first stopped on the concurrent HEAD mismatch. A revision-inventory launch then failed because of a mistyped duplicate path component; the corrected launch succeeded and showed every bound repository input unchanged. Both failed logs remain. No scientific control failed or timed out. No frozen predecessor was changed.

Preserved limitations: a finite-q average without its finite-order premise is not exact; an uncontrolled finite subset cannot be selected by interpolation alone; an isolated atom must actually be nonzero; nonatomic point selection yields zero; nonisolated atomic shrinking bumps lack operator-norm convergence and no uniform locality bound is supplied; unresolved centre bands do not give the exact clock. These are proof limits/spectral examples, not full microscopic countermodels or universal no-go claims.

Next authorized step after freeze is to report exact note/receipt identities to root for a fresh focused independent check of I14–I20 and the downstream hypothesis substitution. This author does not self-assign independent status or start a further route.
