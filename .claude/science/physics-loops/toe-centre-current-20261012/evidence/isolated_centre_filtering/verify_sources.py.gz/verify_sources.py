#!/usr/bin/env python3
"""Bind exact inputs and verify frozen predecessors without writing to them."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
s = here.parent
repo = s.parent / "scattering_worktree"
planning = "3a4b2c66a1ead7a1c48b4359627e968f681e3c39"
initial_head = "296155eda2ca6a5ab6ae6307190362b9a84ea690"
expected_head = "5cbc581504721a323f5fa2064694a67141a3ee98"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bytes_for(record):
    if "path" in record:
        return Path(record["path"]).read_bytes()
    return subprocess.run(["git", "-C", str(repo), "show",
                           record["git_commit"]+":"+record["git_path"]],
                          check=True, capture_output=True, timeout=15).stdout


def checked(record):
    content = bytes_for(record)
    actual = digest(content)
    if actual != record["sha256"]:
        raise AssertionError(dict(record=record, actual=actual))
    return dict(record, bytes=len(content))


head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                      check=True, capture_output=True, timeout=15).stdout.decode().strip()
assert head == expected_head, (head, expected_head)
receipt_specs = [
    ("compact_detector_convergence", "de9a4acddf3c08b406c5dd74cae01d206e1e0a9ab2d804489ddc9ae42d0eca06"),
    ("detector_scattering_projection", "41e516aec74bd86d28702f5c079522f9ba8c91422eb660021190a241de176b72"),
]
predecessors = []
for directory, expected in receipt_specs:
    receipt_path = s / directory / "freeze_receipt.json"
    checked(dict(path=str(receipt_path), sha256=expected))
    receipt = json.loads(receipt_path.read_text())
    counts = {}
    for group in ("inputs", "outputs"):
        for entry in receipt[group]:
            checked(entry)
        counts[group] = len(receipt[group])
    predecessors.append(dict(directory=str(s/directory), receipt_sha256=expected,
                             verified_bindings=sum(counts.values()), groups=counts))

prior_path = s / "detector_scattering_projection" / "SOURCE_LEDGER.json"
prior_receipt = json.loads((s/"detector_scattering_projection"/"freeze_receipt.json").read_text())
prior_binding = next(x for x in prior_receipt["outputs"] if x.get("path") == str(prior_path))
checked(prior_binding)
prior = json.loads(prior_path.read_text())
inputs = []
for entry in prior["inputs"]:
    path = entry.get("path", "")
    if (path.startswith(str(repo)+"/") or
        path == "/Users/jonreilly/.codex/skills/physics-loop/SKILL.md" or
        entry.get("git_commit") == planning):
        fresh = checked(entry)
        fresh["coverage"] = ("Applicable instructions/registry read completely earlier in this coherent "
                             "campaign at this exact identity; current bytes reverified, not reread.")
        inputs.append(fresh)

sources = [
    ("COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md",
     "d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a",
     "Complete 404-line original reread in this task in two chunks. S1/S2, the actual finite flows, joint filter, LR bounds, direct creator/Cook and covariance arguments used; finite-q selector replaced."),
    ("COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md",
     "d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516",
     "Complete earlier reading reused at unchanged identity. Separate gap/unique-vacuum setting only."),
    ("COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md",
     "9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404",
     "Complete earlier reading reused; lines 35-326 reread completely here. Initial aggregated full display truncated and is not counted as a complete fresh read. Exact F1-F20 proof hypotheses inspected, finite-q inference omitted."),
    ("COMPACT_PATCH_FOCK_ISOMETRY_REVIEW.md",
     "bc88af1dda77065d8806da9d689546547f40847a340177086793dab5f3a277cf",
     "Full earlier report reading reused at unchanged identity. Independent predecessor review, not a review of this extension."),
    ("scattering_exhaustion_next/sources/COMPACT_PATCH_SCATTERING_COVARIANCE_REVIEW.md",
     "924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be",
     "Full earlier reading reused at unchanged identity. Predecessor direct-creator scope only."),
    ("scattering_exhaustion_next/sources/EX_REPAIR_REVIEW_ADDENDUM.md",
     "8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029",
     "Full earlier reading reused at unchanged identity. Exact repair scope only."),
    ("COMPACT_DETECTOR_CONVERGENCE_PROBE.md",
     "bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64",
     "Complete prior author source, all 339 lines reread in this task in chunks. Direct hypotheses, full-source filtering, C24a and C28 checked for dependence on centre order. No independent self-review claimed."),
    ("COMPACT_DETECTOR_CONVERGENCE_REVIEW.md",
     "2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0",
     "Full report read in preceding task and exact identity reused. Its underlying full independent packet was not freshly reconstructed here."),
    ("compact_detector_review/receipt.json",
     "e9fb01e5d88618f1905a7426d07991e0a96e88cdd32a8d996b4caa92bd39db5d",
     "Receipt identity bound; not a fresh check of every underlying independent-review file."),
    ("DETECTOR_SCATTERING_PROJECTION_PROBE.md",
     "91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4",
     "Frozen predecessor author source. Its review was pending at task launch; root later reported completion, but that report is not imported or freshly read here. Not a premise or conclusion of this filter proof; bound only for unchanged-source provenance."),
]
for relative, expected, coverage in sources:
    inputs.append(checked(dict(path=str(s/relative), sha256=expected, coverage=coverage)))
for directory, expected in receipt_specs:
    inputs.append(checked(dict(path=str(s/directory/"freeze_receipt.json"), sha256=expected,
                               coverage="Complete structured input/output bindings verified read-only; frozen predecessor unchanged.")))
inputs.append(checked(dict(prior_binding,
                           coverage="Prior structured source ledger parsed for exact instruction identities and reused reading provenance; not a new scientific premise.")))

ledger = dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
              repository_commit=head, initial_repository_commit=initial_head,
              instruction_commit=planning,
              revision_refresh="revision_refresh.json records all concurrent changed paths and unchanged bound repository inputs.",
              deadline="2026-10-12T16:00:52+00:00", inputs=inputs,
              predecessor_integrity=predecessors,
              new_external_theorems_imported=[],
              primary_reading_limits=[
                  "No new literature theorem or fresh primary-paper search is used in this bounded extension.",
                  "LR, clustering, stationary-phase, Cook, Fock and PC arguments are reused only through the exact source-bound proofs and checked direct hypotheses.",
                  "Prior primary reading recorded by the frozen predecessor packets is not relabeled a fresh full read here.",
                  "No projection-review outcome or EX/ND claim is a premise."
              ],
              limits="Author conditional proof; algebra controls cannot certify analytic limits, physical realization, independent review or all-channel coverage.")
(here/"SOURCE_LEDGER.json").write_text(json.dumps(ledger, indent=2)+"\n")
print(json.dumps(dict(status="pass", inputs=len(inputs), repository_commit=head,
                      predecessor_integrity=predecessors,
                      source_ledger_sha256=digest((here/"SOURCE_LEDGER.json").read_bytes())),
                 sort_keys=True))
