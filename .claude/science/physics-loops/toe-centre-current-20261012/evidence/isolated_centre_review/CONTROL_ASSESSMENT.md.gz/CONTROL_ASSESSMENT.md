# Control and reproduction assessment

The analytic conclusion rests on the frozen reconstruction and the complete source arguments, not on a count of passing checks. The candidate source and its control descriptions were visible; the author receipt also exposed control metadata before the independent freeze. The new author helper and numerical stdout/stderr were first inspected only after both independent control versions had frozen and executed.

## Independent finite spin/current-flow control

The pre-author reconstruction hash is 1a670bf6853f7bb5636e2ae1010735141df299537736055924e11ce814fdb030. The initial freeze was at 2026-10-12T02:43:20.932693+00:00, receipt 363e98dec58a422c405bb4bbff5d4d028e95f12418c5ece8734d4ae199d9e30b. It contains the original control at 4a6875f7261d184e88bf89e0473afa15e4303e77cb54af8a9ebbac2970ff8799.

The separately written control constructs a four-site, sixteen-dimensional periodic spin system with H=2N, K=sqrt(2)N plus a nearest-neighbor hopping interaction, and geometric cyclic shift T. It calculates V=exp(iK)T from the actual matrices. It integrates a smooth torus bump by FFT quadrature and applies the Fourier sum through repeated full matrix conjugation. Its separate prediction uses simultaneous spectral decomposition of H, K and T and transition differences. This is distinct from the author's diagonal five-character representation and finite Laurent polynomial. It is still a finite spectral/algebra test, not an infinite-lattice model satisfying all hypotheses or proof of analytic convergence.

The first run used a 60-second timeout and exited 1 in 0.183 seconds. The 256-term Fourier sum had error 4.6881470530034955e-8 against the predeclared 1e-8 tolerance. The complete initial source, stdout/stderr and execution record are retained. No author helper/output had yet been read. A second source version raised the truncations to 512/1024 and quadrature to 8192 while preserving the model, bump, comparisons, and tolerance. The wrong-sign control still uses 512 terms, which is sufficient for its large rejection gap. This was a response to a known resolution failure, not an unreported search over formulas or weaker tolerance.

Version 2 froze at 2026-10-12T02:43:46.150828+00:00, source 0bd50f362e758b8406fd8b257778178efb41e2aac7a3be7125425c9da5abba2c. It exited 0 in 0.164 seconds under 60 seconds, with all six output records read and empty stderr. Python was 3.13.5 and NumPy 2.4.4.

| Finite target | Result |
|---|---|
| H/K/T joint implementation | HK and KT commutators exactly zero in the constructed arrays; V unitarity residual 6.15e-15; simultaneous diagonalization residual at most 1.01e-13 |
| Full transition Fourier sum | 512-term error 8.82e-11; 1024-term error 4.02e-14; refinement difference 8.82e-11 |
| Opposite central sign / outgoing-only formula | Rejected with Frobenius differences 0.575 and 1.122 |
| Norm time derivative / correct adjoint sharp | Errors 2.23e-15 and 1.33e-15 |
| Real-but-asymmetric star shortcut / global idempotence | Rejected with differences 0.575 and 0.138 |
| Composition | Error 4.21e-14 against the squared multiplier |
| Joint mass and character vacuum selection | Two-dimensional mass range, rank-one chosen character, nonzero selected norm 0.5; exact-selection residual 3.94e-15 |
| Omitted mass restriction | Rejected with vector-norm difference 0.145 |
| Three-dimensional torsion cube | 64 exact rational interpolation values; omission of one coordinate gives eight off-target leaks; all eight direction parity classes have at most two values |

No tail certificate is inferred from these two Fourier truncations. The all-orders tail and locality bounds are proved in the reconstruction. No finite enumeration of q establishes irrationality.

## Complete author helper and output

All 190 helper lines, all nine original JSON records, empty stderr, execution metadata, self-check, checkpoint, operational history, source ledger, and all verification/freezing/refresh scripts were read. The entire directory was copied and hash-bound before reproduction. The exact helper was executed once under 60 seconds, exited 0 in 0.050 seconds, and reproduced stdout and stderr byte for byte. The exact read-only freeze verifier exited 0 in 0.075 seconds and reproduced its output byte for byte.

The Fourier-sign, transition, sharp-adjoint, convolution, interpolation and clock checks exercise their stated finite formulas. The exact spectral mask check deliberately supplies the mass/momentum/central masks; it tests their algebra, not whether an admissible microscopic joint spectrum or smooth exact selector exists. The radius cases check rational inequalities, not the LR estimate or Fourier tails. The final `status=pass` fields and literal flags are backed by the preceding assertions at these finite scopes; they are not independent proof predicates.

The source-check script writes a fresh SOURCE_LEDGER.json despite its description as a read-only input check. It was therefore not rerun in the frozen author directory. The freeze and revision-refresh writers were likewise not executed. Their complete preserved logs were inspected, and all their relevant assertions were reproduced by the review's read-only input verifier with outputs redirected to this review directory. This avoided mutating the author's evidence or restamping old executions.

## Copied-code mutations and the surviving case

Eleven separate copied-source mutations ran, each with an explicit 60-second subprocess timeout; their enclosing driver also had a 60-second timeout. Ten failed at the intended assertions: reversed Fourier recovery sign; incorrect right unitary action; omitted adjoint coefficient conjugation; doubled convolution coefficient; omitted mass mask; doubled torsion normalization denominator; wrong generic interpolation numerator; doubled locality radius budget; reversed chart sign; and falsely zero unresolved-clock derivative. Full copied code, stdout, stderr and execution records are in mutations/ and AUTHOR_MUTATIONS.json. All failures were assertion failures rather than syntax/import errors or timeouts.

One intentionally tested mutation survived and reproduced all author output exactly: deleting `+c` from the *successful* final-radius inequality at helper line 162 makes that inequality weaker. This is a nondiscriminating check for that omission. The author's separate counterexample at lines 164-166 instead uses an overfilled R/2 seed plus R/2 flow budget and detects its added positive shift. It does not directly mutate the actual R/4 construction, and should not be cited as verifying every occurrence of the geometric displacement.

This limitation does not invalidate I15-I17: the source explicitly includes the displacement, and the reconstruction verifies the support inclusion itself. A direct exact support witness explains the necessity of accounting for it: with d=1, v=0, R=8 and j=1, a Pauli observable at site 2 moves to site 3, outside the original radius-2 ball; the product-trace conditional expectation onto that original ball is zero. The radius-3 ball contains it. The final-radius inequality alone would not detect that support error. No source correction is required for the theorem; the reviewer does not promote the arithmetic helper into a proof of locality.

## Binding and execution limits

The author receipt binds 25 inputs and 31 outputs; all 56 matched hashes and lengths. The two predecessor receipts' 63 and 57 bindings also matched. Every author file and every prerequisite snapshot remained unchanged. These are identity checks, not recertification of the predecessor packets' entire mathematics. Their original independent primary-source coverage is reused only for the unchanged LR, clustering, stationary-phase, scattering, Fock and PC arguments after checking actual direct hypotheses in full.

The review's first final inventory check exited 1 because the shared checkout HEAD advanced concurrently from 5cbc581504721a323f5fa2064694a67141a3ee98 to f6f4348151734908dea3b32048ee1f36f694035b. The full 252-path inventory was parsed and every bound repository input was unchanged in both Git objects and on disk. The refreshed verifier then exited 0 in 0.551 seconds. The prior author's separate 203-path refresh was also reproduced exactly. Neither concurrent publication is imported into this proof. No scientific control was rerun merely for that metadata change.
