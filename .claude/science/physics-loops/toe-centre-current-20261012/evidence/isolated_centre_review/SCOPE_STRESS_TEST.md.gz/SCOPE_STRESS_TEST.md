# Negative-boundary and scope stress test

This is the N1-N8 scientific scope examination requested by the review skill. It is not a formal retained no-go packet or a claim that all alternative scattering routes fail. The current task authorizes no commit, audit or publication. The source's boundaries are exact limited spectral/algebraic statements and explicit statements of what its proof does not supply.

## N1: Distinct mechanisms and honest outcomes

| Mechanism | Actual check and conclusion |
|---|---|
| Continuous functional calculus on an accumulating atom | Reconstructed directly: continuity at zero forces phi(1/n) to approach phi(0), so no continuous multiplier is the exact isolated rank-one projector on the full stated example. This is the one elementary obstruction, not five distinct failed proofs of the same claim. |
| Discontinuous measurable spectral calculus | The singleton projection exists as a bounded Hilbert-space projection. No quasi-local observable implementation or uniform locality follows. This is an unclosed alternative outside the claimed continuous-multiplier obstruction. |
| Strong limiting averages or shrinking smooth bumps | Dominated convergence supplies the atom projector strongly; on a nonatomic component it is zero. At an accumulating atom the bumps stay norm distance one from the target. Almost-local seminorms of the observables are uncontrolled. |
| Mass/momentum or vector-specific support restriction | Can succeed even when global character isolation fails. I5 and I20 implement that restricted positive result. The note explicitly permits this escape from a wrongly global no-go. |
| Finite multivariate interpolation | Succeeds on the entire known finite relevant support, including irrational characters. It cannot select an arbitrary finite subset while ignoring unspecified spectral values. A single direction fails to separate the four two-dimensional torsion points, but several coordinates succeed. |
| Scattering with a full unresolved central parameter | The two-character clock example refutes reuse of one selected graph clock, not all possible direct-integral or operator-valued dispersion constructions. Such a construction remains unproved here, not foreclosed. |

These are real mechanisms, with successful and unresolved alternatives retained. They are not five failed attack families on a universal no-go. Accordingly this review does not claim the formal five-failed-route packet PASS required for a future canonical no-go submission. That procedural limitation does not contradict the directly proved elementary examples or the positive conditional filtering theorem.

## N2: Conditions and independence

No number of independent walls is claimed. Microscopic finite-range implementation, isolated mass, patchwise central isolation, unique gapped vacuum, convex cutoff geometry, and energy-only detector remainder are used at different stated steps. The current proof neither proves their pairwise independence nor counts them as independent obstructions. Global isolation implies I5; the reverse is not asserted. In a stronger integrated massive representation even their separation may disappear. No duplicated wall count is used.

## N3: Hidden premises

The complete source read found no hidden physical axiom or empirical comparator. S1-type microscopic implementation, the isolated mass-Casimir component, nonzero declared coverage, and I5 remain explicit conditions. I27 is added for Fock/clustering; geometric full-operator carriers and convex containment are added for PC; I32 remains separate for the detector product's vacuum factorization. None is inferred from the four framework axioms or an approved primitive. The registry and current axiom memo were read; this theorem does not invoke a specific registered primitive to supply dynamics or spectra.

## N4: Residual matching

The SC common-q boundary matches the finite-order centre assumption that this note replaces. The earlier EX scope repair addresses a different downstream completeness interpretation and is carried only at that scope. Fock and PC reviews are reused for unchanged analytic arguments, not as witnesses that the new filter works. No projection, detector leakage or index result is imported. The two-character spectral example only attacks the exact single-clock cancellation. The accumulating-atom example only attacks a continuous exact multiplier on that entire spectral support. These residuals are not enlarged.

## N5: Resolution and rhetoric

Per matrix element, the filter acts on outgoing-minus-incoming phase. On the vacuum column it acts on the outgoing phase because the incoming phase is zero. On the declared mass/patch subspace it becomes the exact character projector. On the full Hilbert space it need not. For finitely many separated packet factors the scattering and covariance proofs apply. For the covered Fock space the isometric extension applies. For every fixed admissible detector arrangement PC applies. The whole GNS space, uncovered momenta, infinite simultaneous families and a microscopic continuum-character realization remain outside those conclusions.

The finite radius and interpolation controls are finite algebra only. The written all-R estimate proves the locality statement under its stated LR hypotheses. No finite array or finite q search is promoted to an infinite-volume result. The two purely spectral counterexamples are explicitly not local-UHF models.

## N6: Partial closures and conventions

Changing a character representative only changes the lift label; it cannot turn an irrational phase into a root of unity. A sign convention must be changed consistently in V and Q, and does not supply a selector or a dynamics. Restricting the relevant spectral support, using the new smooth selector, or using finite interpolation are substantive positive partial closures already retained. No new axiom is claimed necessary. Approved scale, kinetic-form isotropy, and realized-state interfaces do not supply the stated mass/current/central spectrum, and the candidate does not purport to use them for that purpose.

## N7: Strong counterargument

The strongest challenge to a broad negative reading is to use the measurable singleton projection or a strong limit of group averages and then try to prove it is represented by an almost-local observable in the particular microscopic model. Alternatively, restrict mass and momentum before filtering, or build a scattering theory that retains the central parameter rather than collapsing it to one character. The note itself supplies the restricted-filter mechanism and leaves the other terminal obligations open. Therefore a universal claim that nonisolated centres admit no scattering or no exact local realization would be unjustified. The actual narrow continuity obstruction and missing common-q inference survive because those alternatives change their quantified domain or conclusion.

## N8: Prior-boundary comparison and search limit

The complete unchanged SC source at d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a explicitly says its finite-q filter needs its finite-order spectral condition. This new smooth/finite-interpolation construction is precisely an alternate positive route; the review does not turn the older route's missing hypothesis into a universal negative statement. Fock and PC proofs were re-examined for hidden finite-order use and only the final common-order conclusion depended on it.

A broad pinned-main text search was saved completely as logs/scope_search.stdout: 162 lines, 78,671 bytes. Its initially truncated display is not counted as review coverage. An exact central-spectrum phrase refinement returned zero matching lines; generic finite-character and selector hits include unrelated gauge and selector subjects, and are not mathematical authority here. This is a scoped retrieval check, not an exhaustive literature or repository novelty claim. No unseen historical theorem is being cited to close an alternative route.
