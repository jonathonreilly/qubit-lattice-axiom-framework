#!/usr/bin/env python3
import datetime, hashlib, json, pathlib, subprocess
R=pathlib.Path(__file__).resolve().parent;S=R.parent;repo=S.parent/'scattering_worktree'
def sha(data):return hashlib.sha256(data).hexdigest()
def binding(p):
    b=p.read_bytes();return dict(path=str(p),sha256=sha(b),bytes=len(b))
assert not (R/'receipt.json').exists(), 'Do not overwrite a final receipt'
now=datetime.datetime.now(datetime.timezone.utc)
assert now<datetime.datetime.fromisoformat('2026-10-12T16:00:52+00:00')
for frozen in ('pre_author_freeze.json','pre_author_control_v2_freeze.json'):
    packet=json.loads((R/frozen).read_text())
    entries=packet.get('files',[packet])
    for item in entries:
        data=pathlib.Path(item['path']).read_bytes();assert sha(data)==item['sha256'];assert len(data)==item['bytes']
manifest=json.loads((R/'FINAL_SOURCE_MANIFEST.json').read_text())
for e in manifest['sources']:
    copied=pathlib.Path(e['copy']).read_bytes();assert sha(copied)==e['sha256'];assert len(copied)==e['bytes']
    if 'path' in e:assert pathlib.Path(e['path']).read_bytes()==copied
    elif 'git_revision' in e:
        actual=subprocess.check_output(['git','-C',str(repo),'show',e['git_revision']+':'+e['git_path']],timeout=20)
        assert actual==copied
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],timeout=20).decode().strip()
refresh=json.loads((R/'REVIEW_CONCURRENT_REFRESH.json').read_text());assert head==refresh['new_head']
for e in refresh['relevant_repository_inputs']:
    data=subprocess.check_output(['git','-C',str(repo),'show',head+':'+e['path']],timeout=20)
    assert sha(data)==e['sha256']
runs={}
expected={'independent_spin_control':1,'independent_spin_control_v2':0,'author_finite_reproduction':0,'author_freeze_verification':0,'inventory_verification':1,'author_mutations':0,'scope_search':0,'inventory_verification_refreshed':0}
for name,code in expected.items():
    p=R/'logs'/(name+'.execution.json');record=json.loads(p.read_text());assert record['returncode']==code and not record['timed_out'];assert record['declared_timeout_seconds']==60
    for extension in ('stdout','stderr'):
        b=(R/'logs'/(name+'.'+extension)).read_bytes();assert sha(b)==record[extension+'_sha256'];assert len(b)==record[extension+'_bytes']
    runs[name]=record
mutations=json.loads((R/'AUTHOR_MUTATIONS.json').read_text());assert len(mutations)==11
assert sum(x['returncode']==0 for x in mutations)==1
excluded={'receipt.json','logs/finalize.stdout','logs/finalize.stderr','logs/finalize.execution.json','logs/receipt_verification.stdout','logs/receipt_verification.stderr','logs/receipt_verification.execution.json'}
outputs=[binding(S/'ISOLATED_CENTRE_FILTERING_REVIEW.md')]
outputs.extend(binding(p) for p in sorted(R.rglob('*')) if p.is_file() and str(p.relative_to(R)) not in excluded)
record=dict(frozen_at=now.isoformat(),deadline='2026-10-12T16:00:52+00:00',disposition='PASS for the frozen conditional I1-I34 theorem; no required mathematical source correction',formal_audit_status=None,reviewer_model_override=None,reviewer_reasoning_override=None,no_subdelegation=True,target=binding(S/'ISOLATED_CENTRE_FILTERING_PROBE.md'),author_receipt=binding(S/'isolated_centre_filtering/freeze_receipt.json'),main_authority='a13caa4885f547c8d206265b031ba7649e539fd9',planning_authority='3a4b2c66a1ead7a1c48b4359627e968f681e3c39',initial_checkout='5cbc581504721a323f5fa2064694a67141a3ee98',final_checkout=head,pre_author_freeze=binding(R/'pre_author_freeze.json'),pre_author_control_v2_freeze=binding(R/'pre_author_control_v2_freeze.json'),source_manifest=binding(R/'FINAL_SOURCE_MANIFEST.json'),executions=runs,mutation_summary=dict(total=11,intended_failures=10,surviving_cases=['radius_drop_shift_nondiscriminating']),outputs=outputs,excluded_paths=sorted(excluded),exclusion_reason='Receipt self-reference and finalization/verification wrapper logs are excluded; their hashes and outcomes are returned separately.',verification_limits=manifest['limits']+['Initial finite Fourier truncation failed, refined version passed at unchanged tolerance.','The radius inequality alone does not discriminate deletion of its positive shift term.','No formal universal no-go packet PASS, new microscopic realization, common q, ND or EX.'],editable_prompt_files_changed=[],git_ref_pr_publication_audit_axiom_mutations=[],allowed_output_root=str(R),allowed_report=str(S/'ISOLATED_CENTRE_FILTERING_REVIEW.md'))
(R/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status='frozen',frozen_at=record['frozen_at'],report_sha256=outputs[0]['sha256'],receipt_sha256=sha((R/'receipt.json').read_bytes()),output_bindings=len(outputs),source_manifest_entries=len(manifest['sources'])),sort_keys=True))
