#!/usr/bin/env python3
"""Copies-only finite mutation checks; preserve failures and survival."""
import datetime, hashlib, json, os, pathlib, subprocess, sys, time
R=pathlib.Path(__file__).resolve().parent
source=(R/'sources/author_packet/check_filter_algebra.py').read_text()
mutations=[
 ('fourier_sign','value(coeff, x)*cmath.exp(-1j*j*x)','value(coeff, x)*cmath.exp(1j*j*x)',False),
 ('operator_right_action','matmul(matmul(u, b), star(u))','matmul(matmul(u, b), u)',False),
 ('adjoint_reflection','{j: c.conjugate() for j, c in coeff.items()}','{j: c for j, c in coeff.items()}',False),
 ('composition_coefficient','product.get(j+k, 0) + c*d','product.get(j+k, 0) + 2*c*d',False),
 ('omit_mass','selected = [a*h*p for a, h, p in zip(mass, momentum, phi)]','selected = [h*p for a, h, p in zip(mass, momentum, phi)]',False),
 ('torsion_normalization','denom = za[coord]-zb[coord]','denom = 2*(za[coord]-zb[coord])',False),
 ('generic_interpolation','result *= (zc[coord]-zb[coord])/(za[coord]-zb[coord])','result *= (zc[coord]+zb[coord])/(za[coord]-zb[coord])',False),
 ('radius_budget','c = 1/(8*d*(1+v))','c = 1/(4*d*(1+v))',False),
 ('chart_sign','k = p+theta+2*math.pi*lift','k = p-theta+2*math.pi*lift',False),
 ('false_zero_clock','derivative_norm = gap/math.sqrt(2)','derivative_norm = 0',False),
 ('radius_drop_shift_nondiscriminating','assert F(1, 4)+c+F(1, 2) <= F(7, 8)','assert F(1, 4)+F(1, 2) <= F(7, 8)',True),
]
out=R/'mutations';out.mkdir(exist_ok=True);records=[]
for label,old,new,survive in mutations:
    assert source.count(old)==1,(label,source.count(old))
    text=source.replace(old,new);compile(text,label,'exec')
    path=out/(label+'.py');path.write_text(text)
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();before=time.monotonic();timed_out=False
    try:
        run=subprocess.run([sys.executable,str(path)],cwd=R,capture_output=True,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        code,stdout,stderr=run.returncode,run.stdout,run.stderr
    except subprocess.TimeoutExpired as e:
        code,stdout,stderr=None,e.stdout or b'',e.stderr or b'';timed_out=True
    (out/(label+'.stdout')).write_bytes(stdout);(out/(label+'.stderr')).write_bytes(stderr)
    record=dict(label=label,command=[sys.executable,str(path)],declared_timeout_seconds=60,started_at=started,elapsed_seconds=time.monotonic()-before,returncode=code,timed_out=timed_out,expected_survival=survive,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_records=len(stdout.splitlines()),last_stderr_lines=stderr.decode().splitlines()[-4:])
    (out/(label+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n');records.append(record)
    assert not timed_out,record
    assert (code==0) if survive else (code!=0 and b'AssertionError' in stderr),record
    print(json.dumps(record,sort_keys=True),flush=True)
(R/'AUTHOR_MUTATIONS.json').write_text(json.dumps(records,indent=2)+'\n')
