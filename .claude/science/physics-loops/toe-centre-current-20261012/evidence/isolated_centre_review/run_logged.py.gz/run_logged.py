#!/usr/bin/env python3
"""Capture a bounded command without writing outside the assigned review path."""
import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
label=sys.argv[1]; timeout=float(sys.argv[2]); command=sys.argv[3:]
assert label and '/' not in label
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
timed_out=False; error=None; returncode=None
try:
    result=subprocess.run(command,cwd=root,capture_output=True,timeout=timeout,check=False,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    stdout,stderr,returncode=result.stdout,result.stderr,result.returncode
except subprocess.TimeoutExpired as exc:
    stdout,stderr=exc.stdout or b'',exc.stderr or b'';timed_out=True
except Exception as exc:
    stdout,stderr=b'',b'';error=repr(exc)
finish=datetime.datetime.now(datetime.timezone.utc).isoformat()
for extension,data in [('stdout',stdout),('stderr',stderr)]:
    (root/'logs'/f'{label}.{extension}').write_bytes(data)
record=dict(command=command,cwd=str(root),declared_timeout_seconds=timeout,started_at=start,finished_at=finish,elapsed_seconds=time.monotonic()-clock,returncode=returncode,timed_out=timed_out,launch_error=error,stdout_bytes=len(stdout),stderr_bytes=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
(root/'logs'/f'{label}.execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,sort_keys=True))
sys.exit(124 if timed_out else (1 if error else returncode))
