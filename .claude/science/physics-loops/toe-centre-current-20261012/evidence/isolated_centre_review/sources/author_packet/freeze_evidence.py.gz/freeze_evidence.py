#!/usr/bin/env python3
"""Freeze this bounded author output; never write to a predecessor or repository."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import re
import subprocess

here = Path(__file__).resolve().parent
note = here.parent / "ISOLATED_CENTRE_FILTERING_PROBE.md"
repo = here.parent.parent / "scattering_worktree"
deadline = dt.datetime.fromisoformat("2026-10-12T16:00:52+00:00")
now = dt.datetime.now(dt.timezone.utc)
assert now < deadline
assert not (here/"freeze_receipt.json").exists(), "frozen packet must not be overwritten"
ledger = json.loads((here/"SOURCE_LEDGER.json").read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), sha256=sha(data), bytes=len(data))


def check(entry):
    if "path" in entry:
        data = Path(entry["path"]).read_bytes()
    else:
        data = subprocess.run(["git", "-C", str(repo), "show",
                               entry["git_commit"]+":"+entry["git_path"]],
                              capture_output=True, check=True, timeout=15).stdout
    assert sha(data) == entry["sha256"], entry


for entry in ledger["inputs"]:
    check(entry)
head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                      capture_output=True, check=True, timeout=15).stdout.decode().strip()
assert head == ledger["repository_commit"]
proof = note.read_text()
tags = re.findall(r"\\tag\{I([0-9]+)\}", proof)
assert tags == [str(i) for i in range(1, 35)], tags
assert proof.count(r"\[") == proof.count(r"\]")
assert r"\mathbin{+} C_d'" in proof
assert r"\mathbin{+}\|B\|\sum_{|j|_1>cR}" in proof
assert "old numerical constants are not transferred" in proof
executions = {}
for label, expected in [("finite_controls", 0), ("source_check", 0),
                        ("source_check_final", 1), ("revision_refresh", 2),
                        ("revision_refresh_retry", 0), ("source_check_refreshed", 0)]:
    run = json.loads((here/(label+".execution.json")).read_text())
    assert run["returncode"] == expected and not run["timed_out"], (label, run)
    assert run["declared_timeout_seconds"] == 60
    executions[label] = run
records = [json.loads(line) for line in (here/"finite_controls.stdout").read_text().splitlines()]
assert len(records) == 9 and all(x["status"] == "pass" for x in records)
assert records[-1]["analytic_convergence_certified"] is False
assert (here/"finite_controls.stderr").read_bytes() == b""
excluded = ["freeze_receipt.json", "freeze.stdout", "freeze.stderr", "freeze.execution.json",
            "freeze_verify.stdout", "freeze_verify.stderr", "freeze_verify.execution.json"]
outputs = [binding(note)]
outputs.extend(binding(p) for p in sorted(here.rglob("*"))
               if p.is_file() and p.name not in excluded)
receipt = dict(frozen_at=now.isoformat(), deadline=deadline.isoformat(),
               note_sha256=sha(note.read_bytes()), note_lines=len(proof.splitlines()),
               initial_repository_commit=ledger["initial_repository_commit"],
               repository_commit=head, instruction_commit=ledger["instruction_commit"],
               inputs=ledger["inputs"], outputs=outputs, output_exclusions=excluded,
               exclusion_reason="Receipt self-hash and finalization/verification logs are excluded to avoid circular hashes; their returned hashes and execution outcomes are reported separately.",
               theorem_status="Conditional author derivation I1-I34; fresh independent check outstanding.",
               source_scope="Smooth central transition filter, uniform almost locality, exact isolated mass/patch character selection, covered density and direct-hypothesis SC/Fock/PC extension. No projection theorem, ND, EX, microscopic existence or common-q conclusion imported.",
               controls=dict(records=9, controls=8, analytic_certification=False,
                             independent=False, executions=executions),
               predecessor_integrity=ledger["predecessor_integrity"],
               corrections=["Unfrozen I16/I17 missing printed addition signs repaired and reread.",
                            "Redundant I33 math escape removed.",
                            "Concurrent HEAD mismatch detected; all relevant inputs checked unchanged.",
                            "Mistyped inventory-launch path failed before script execution; corrected retry retained."],
               model_override=None, reasoning_override=None, no_subdelegation=True,
               no_repo_mutations=True, prompt_files_changed=[])
(here/"freeze_receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps(dict(status="frozen", note_sha256=receipt["note_sha256"],
                      receipt_sha256=sha((here/"freeze_receipt.json").read_bytes()),
                      note_lines=receipt["note_lines"], inputs=len(receipt["inputs"]),
                      outputs=len(receipt["outputs"]), frozen_at=now.isoformat()), sort_keys=True))
