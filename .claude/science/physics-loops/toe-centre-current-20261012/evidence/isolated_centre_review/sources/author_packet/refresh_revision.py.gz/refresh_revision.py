#!/usr/bin/env python3
"""Read-only audit of concurrent revision changes against the bound inputs."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
repo = here.parent.parent / "scattering_worktree"
old = "296155eda2ca6a5ab6ae6307190362b9a84ea690"
new = "5cbc581504721a323f5fa2064694a67141a3ee98"


def git(*args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True,
                          capture_output=True, timeout=20).stdout


assert git("rev-parse", "HEAD").decode().strip() == new
raw = git("diff", "--name-status", "-z", old, new)
(here/"revision_changed_paths.raw").write_bytes(raw)
fields = raw.decode().split("\0")
assert fields[-1] == ""
fields.pop()
changes = []
while fields:
    status = fields.pop(0)
    paths = [fields.pop(0)]
    if status.startswith(("R", "C")):
        paths.append(fields.pop(0))
    changes.append(dict(status=status, paths=paths))
changed_paths = {p for entry in changes for p in entry["paths"]}
ledger = json.loads((here/"SOURCE_LEDGER.json").read_text())
relevant = []
for entry in ledger["inputs"]:
    path = entry.get("path", "")
    if not path.startswith(str(repo)+"/"):
        continue
    relative = str(Path(path).relative_to(repo))
    old_bytes = git("show", old+":"+relative)
    new_bytes = git("show", new+":"+relative)
    old_hash = hashlib.sha256(old_bytes).hexdigest()
    new_hash = hashlib.sha256(new_bytes).hexdigest()
    assert old_hash == new_hash == entry["sha256"], (relative, old_hash, new_hash)
    assert relative not in changed_paths, relative
    relevant.append(dict(path=relative, sha256=new_hash))
record = dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
              initial_revision=old, observed_revision=new,
              commit_subject=git("log", "-1", "--format=%s", new).decode().strip(),
              changes=changes, changed_path_count=len(changed_paths),
              relevant_repository_inputs=relevant,
              relevant_changed_path_intersection=[],
              scope="Complete changed-path inventory parsed. Every repository proof/instruction input is byte-identical in both Git objects. Unrelated projection publication contents are not imported or claimed freshly read.")
(here/"revision_refresh.json").write_text(json.dumps(record, indent=2)+"\n")
print(json.dumps(dict(status="pass", initial_revision=old, observed_revision=new,
                      changed_paths=len(changed_paths), relevant_inputs_unchanged=len(relevant),
                      relevant_changed_path_intersection=[]), sort_keys=True))
