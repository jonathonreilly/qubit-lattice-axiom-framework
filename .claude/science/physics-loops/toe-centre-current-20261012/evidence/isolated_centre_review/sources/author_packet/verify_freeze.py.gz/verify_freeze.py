#!/usr/bin/env python3
"""Read-only final manifest check; output is held by the timeout runner."""
from pathlib import Path
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
repo = here.parent.parent/"scattering_worktree"
path = here/"freeze_receipt.json"
receipt = json.loads(path.read_text())
count = 0
for entry in receipt["inputs"]+receipt["outputs"]:
    if "path" in entry:
        data = Path(entry["path"]).read_bytes()
    else:
        data = subprocess.run(["git", "-C", str(repo), "show",
                               entry["git_commit"]+":"+entry["git_path"]],
                              capture_output=True, check=True, timeout=15).stdout
    assert hashlib.sha256(data).hexdigest() == entry["sha256"], entry
    assert len(data) == entry["bytes"], entry
    count += 1
bound = {x["path"] for x in receipt["outputs"]}
extras = [str(p) for p in here.rglob("*") if p.is_file()
          and str(p) not in bound and p.name not in receipt["output_exclusions"]]
assert extras == [], extras
freeze_run = json.loads((here/"freeze.execution.json").read_text())
assert freeze_run["returncode"] == 0 and not freeze_run["timed_out"]
print(json.dumps(dict(status="pass", verified_bindings=count, unlisted_files=extras,
                      note_sha256=receipt["note_sha256"],
                      receipt_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                      note_lines=receipt["note_lines"], outputs=len(receipt["outputs"]),
                      inputs=len(receipt["inputs"]),
                      excluded_finalization_logs=receipt["output_exclusions"]), sort_keys=True))
