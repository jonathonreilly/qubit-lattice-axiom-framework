#!/usr/bin/env python3
"""Predeclared finite control; no author helper is imported or read."""
import json
import math
from fractions import Fraction
import numpy as np

TOL = 1e-8
WRONG_MIN = 1e-4
N = 4
D = 2**N
eye = np.eye(D, dtype=complex)


def norm(x):
    return float(np.linalg.norm(x))


def emit(name, **kw):
    print(json.dumps({"control": name, **kw}, sort_keys=True), flush=True)


def close(name, x, y, tol=TOL):
    error = norm(x-y)
    assert error < tol, (name, error, tol)
    return error


def reject(name, x, y):
    difference = norm(x-y)
    assert difference > WRONG_MIN, (name, difference, WRONG_MIN)
    return difference


def create(site):
    a = np.zeros((D,D), dtype=complex)
    for state in range(D):
        if not (state >> site) & 1:
            a[state | (1 << site), state] = 1
    return a


plus = [create(i) for i in range(N)]
minus = [x.conj().T for x in plus]
number = sum(p @ m for p,m in zip(plus,minus))
translation = np.zeros((D,D), dtype=complex)
for state in range(D):
    target = ((state << 1) & (D-1)) | (state >> (N-1))
    translation[target,state] = 1
H = 2 * number
K = math.sqrt(2) * number
for i in range(N):
    hop = plus[i] @ minus[(i+1)%N]
    K = K + 0.23 * (hop + hop.conj().T)

# A generic Hermitian combination separates the simultaneous eigenspaces.
# Its eigenvectors are used only for a separate spectral prediction.
L = K + .113*H + .017*(translation+translation.conj().T) + .023j*(translation-translation.conj().T)
_, U = np.linalg.eigh(L)
energies = np.diag(U.conj().T @ H @ U).real
momenta = np.diag(U.conj().T @ K @ U).real
tdiag = np.diag(U.conj().T @ translation @ U)
joint_errors = [close("H diagonal", U.conj().T@H@U, np.diag(energies)),
                close("K diagonal", U.conj().T@K@U, np.diag(momenta)),
                close("T diagonal", U.conj().T@translation@U, np.diag(tdiag))]
kw, ku = np.linalg.eigh(K)
expK = (ku*np.exp(1j*kw)) @ ku.conj().T
V = expK @ translation
phases = np.angle(np.exp(1j*momenta)*tdiag)
Omega = np.zeros(D, dtype=complex); Omega[0] = 1
emit("actual_spin_representation", dimension=D, sites=N,
     joint_diagonalization_errors=joint_errors,
     H_K_commutator=close("HK", H@K,K@H),
     K_T_commutator=close("KT",K@translation,translation@K),
     V_unitarity=close("V unitary",V.conj().T@V,eye),
     vacuum_error=close("vacuum",V@Omega,Omega))

B = plus[0] + .29*plus[0]@plus[1] + (.19+.11j)*plus[1]@plus[2]@minus[0] + .07*plus[3]@plus[0]@minus[0]
theta = math.sqrt(2)-math.pi/2


def flat_bump(x, center, inner, outer, periodic=False):
    distance = np.abs(np.angle(np.exp(1j*(x-center)))) if periodic else np.abs(x-center)
    t = (distance-inner)/(outer-inner)
    result = np.ones_like(t, dtype=float)
    result[t >= 1] = 0
    middle = (t>0)&(t<1)
    v = t[middle]
    left = np.exp(-1/(1-v)); right = np.exp(-1/v)
    result[middle] = left/(left+right)
    return result


def phi(x):
    return flat_bump(np.asarray(x),theta,.18,.62,True)


def phi_sharp(x):
    return phi(-np.asarray(x))


def coeffs(function, grid=8192):
    values = function(2*math.pi*np.arange(grid)/grid)
    return np.fft.fft(values)/grid


def orbit_filter(matrix, coefficients, cutoff, reverse=False):
    # Iterates of actual full V conjugation, not an elementwise phase formula.
    output = coefficients[0]*matrix
    positive = matrix.copy(); negative = matrix.copy()
    for j in range(1,cutoff+1):
        positive = V@positive@V.conj().T
        negative = V.conj().T@negative@V
        if reverse:
            output = output+coefficients[-j]*positive+coefficients[j]*negative
        else:
            output = output+coefficients[j]*positive+coefficients[-j]*negative
    return output


def spectral_filter(matrix, function):
    entries = U.conj().T@matrix@U
    transitions = phases[:,None]-phases[None,:]
    return U@(entries*function(transitions))@U.conj().T


cf = coeffs(phi)
filtered512 = orbit_filter(B,cf,512)
filtered1024 = orbit_filter(B,cf,1024)
expected = spectral_filter(B,phi)
outgoing = U@np.diag(phi(phases))@U.conj().T@B
wrong_sign = orbit_filter(B,cf,512,True)
emit("smooth_full_transition_filter", error512=close("512 sum",filtered512,expected),
     error1024=close("1024 sum",filtered1024,expected),
     refinement=close("refinement",filtered512,filtered1024),
     wrong_sign_rejected=reject("Fourier sign",wrong_sign,expected),
     outgoing_only_rejected=reject("outgoing only",outgoing,expected),
     vacuum_multiplier_error=close("vacuum multiplier",filtered1024@Omega,(U@np.diag(phi(phases))@U.conj().T@B)@Omega))

adjoint_correct = orbit_filter(B.conj().T,coeffs(phi_sharp),1024)
adjoint_wrong = orbit_filter(B.conj().T,cf,1024)
twice = orbit_filter(filtered1024,cf,1024)
deltaB = 1j*(H@B-B@H)
emit("derivative_adjoint_composition",
     derivative_error=close("derivative",orbit_filter(deltaB,cf,1024),1j*(H@filtered1024-filtered1024@H)),
     sharp_error=close("sharp",filtered1024.conj().T,adjoint_correct),
     real_star_shortcut_rejected=reject("real star",filtered1024.conj().T,adjoint_wrong),
     product_error=close("product",twice,spectral_filter(B,lambda x:phi(x)**2)),
     global_idempotence_rejected=reject("global projection",twice,filtered1024))

# Joint energy/current operator transfer is filtered before central selection.
mass2 = 2.0
casimir = energies**2-momenta**2
nonzero_distances = np.abs(casimir-mass2)
gap = float(np.min(nonzero_distances[nonzero_distances>1e-7]))
deltaE=energies[:,None]-energies[None,:]
deltaK=momenta[:,None]-momenta[None,:]
G=flat_bump(deltaE,2,.05,.2)*flat_bump(deltaK,math.sqrt(2),.05,.20)*flat_bump(deltaE**2-deltaK**2,mass2,gap/8,gap/4)
Bg = U@((U.conj().T@B@U)*G)@U.conj().T
selected = orbit_filter(Bg,cf,1024)
mask=(np.abs(casimir-mass2)<1e-7)&(np.abs(np.angle(np.exp(1j*(phases-theta))))<1e-7)
Ptarget=(U*mask)@U.conj().T
Etarget=(U*(np.abs(casimir-mass2)<1e-7))@U.conj().T
emit("exact_mass_character_vacuum",
     mass_eigenspace_rank=int(round(np.trace(Etarget).real)),
     target_rank=int(sum(mask)), isolation_gap=gap,
     joint_vacuum_error=close("joint vacuum",Bg@Omega,Etarget@B@Omega),
     selected_vacuum_error=close("selected vacuum",selected@Omega,Ptarget@B@Omega),
     nonzero_selected_norm=norm(selected@Omega),
     annihilator_vacuum_error=close("annihilator vacuum",selected.conj().T@Omega,np.zeros(D)),
     omitted_mass_rejected=reject("omit mass",filtered1024@Omega,Ptarget@B@Omega))
assert sum(mask)==1
assert norm(selected@Omega)>WRONG_MIN

# Exact rational multivariate interpolation on all eight 3D torsion points.
from itertools import product
points=list(product((-1,1),repeat=3))
exact_values=[]; wrong_leakage=[]
for target in points:
    for point in points:
        factors=[Fraction(1+target[a]*point[a],2) for a in range(3)]
        value=math.prod(factors)
        assert value==int(point==target)
        exact_values.append(value)
        wrong=math.prod(factors[:2])
        if point!=target and wrong: wrong_leakage.append((target,point))
assert len(wrong_leakage)==8
for direction in product(range(2),repeat=3):
    assert len({math.prod(p[a]**direction[a] for a in range(3)) for p in points})<=2
emit("multivariate_exact_cube", interpolation_values=len(exact_values),
     omitted_coordinate_leaks=len(wrong_leakage), direction_parity_classes=8,
     limitation="Finite exact algebra; no microscopic existence or analytic convergence claim")
emit("complete", controls=5, analytical_certification=False, independent_of_author_helper=True)
