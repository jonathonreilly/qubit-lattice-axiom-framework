#!/usr/bin/env python3
"""Read-only verification of external inputs; writes only review evidence."""
import datetime, hashlib, json, pathlib, subprocess
R=pathlib.Path(__file__).resolve().parent
S=R.parent; repo=S.parent/'scattering_worktree'; A=S/'isolated_centre_filtering'

def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.run(['git','-C',str(repo),*args],capture_output=True,check=True,timeout=20).stdout
def read_binding(entry):
    if 'path' in entry: return pathlib.Path(entry['path']).read_bytes()
    return git('show',entry['git_commit']+':'+entry['git_path'])
def check(entry):
    data=read_binding(entry)
    assert sha(data)==entry['sha256'],entry
    if 'bytes' in entry: assert len(data)==entry['bytes'],entry
    return dict(identity=entry.get('path',entry.get('git_commit','')+':'+entry.get('git_path','')),sha256=sha(data),bytes=len(data))

receipt=json.loads((A/'freeze_receipt.json').read_text())
assert sha((A/'freeze_receipt.json').read_bytes())=='a76cd471016c6e280d44faa97e470cb13ec1e4dd480f0b16c30308eeb0093012'
checked=[check(e) for group in ('inputs','outputs') for e in receipt[group]]
predecessor=[]
for item in receipt['predecessor_integrity']:
    directory=pathlib.Path(item['directory']); p=directory/'freeze_receipt.json'
    assert sha(p.read_bytes())==item['receipt_sha256']
    prior=json.loads(p.read_text())
    bindings=[check(e) for group in ('inputs','outputs') for e in prior[group]]
    predecessor.append(dict(directory=str(directory),receipt_sha256=sha(p.read_bytes()),checked=bindings))
for e in json.loads((R/'AUTHOR_EVIDENCE_MANIFEST.json').read_text()):
    assert pathlib.Path(e['path']).read_bytes()==pathlib.Path(e['copy']).read_bytes(),e
for e in json.loads((R/'PREREQUISITE_SOURCES.json').read_text()):
    assert pathlib.Path(e['path']).read_bytes()==pathlib.Path(e['copy']).read_bytes(),e

# Independently parse the complete NUL-delimited inventory and compare it
# with Git, then check every relevant blob at both pinned commits.
refresh=json.loads((A/'revision_refresh.json').read_text())
raw=(A/'revision_changed_paths.raw').read_bytes()
assert raw==git('diff','--name-status','-z',refresh['initial_revision'],refresh['observed_revision'])
fields=raw.decode().split('\0');assert fields.pop()==''
changes=[]
while fields:
    status=fields.pop(0);paths=[fields.pop(0)]
    if status.startswith(('R','C')): paths.append(fields.pop(0))
    changes.append(dict(status=status,paths=paths))
assert changes==refresh['changes']
changed={p for item in changes for p in item['paths']}
assert len(changed)==refresh['changed_path_count']==203
for e in refresh['relevant_repository_inputs']:
    assert e['path'] not in changed
    assert sha(git('show',refresh['initial_revision']+':'+e['path']))==e['sha256']
    assert sha(git('show',refresh['observed_revision']+':'+e['path']))==e['sha256']
assert git('rev-parse','origin/main').decode().strip()=='a13caa4885f547c8d206265b031ba7649e539fd9'
review_refresh=json.loads((R/'REVIEW_CONCURRENT_REFRESH.json').read_text())
assert git('rev-parse','HEAD').decode().strip()==review_refresh['new_head']
for e in review_refresh['relevant_repository_inputs']:
    assert sha(git('show',review_refresh['new_head']+':'+e['path']))==e['sha256']

for extension in ('stdout','stderr'):
    assert (R/'logs'/('author_finite_reproduction.'+extension)).read_bytes()==(A/('finite_controls.'+extension)).read_bytes()
    assert (R/'logs'/('author_freeze_verification.'+extension)).read_bytes()==(A/('freeze_verify.'+extension)).read_bytes()

result=dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),author_bindings=checked,predecessors=predecessor,concurrent_inventory=dict(paths=len(changed),relevant_unchanged=len(refresh['relevant_repository_inputs']),intersection=[]),all_author_files_unchanged=True,all_prerequisite_snapshots_unchanged=True,author_reproductions_byte_identical=True,repository_head=git('rev-parse','HEAD').decode().strip(),origin_main=git('rev-parse','origin/main').decode().strip())
(R/'INVENTORY_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='verified',author_binding_count=len(checked),predecessor_binding_counts=[len(x['checked']) for x in predecessor],concurrent_paths=len(changed),relevant_repository_inputs=len(refresh['relevant_repository_inputs']),reproductions_byte_identical=True,report_sha256=sha((R/'INVENTORY_VERIFICATION.json').read_bytes())),sort_keys=True))
