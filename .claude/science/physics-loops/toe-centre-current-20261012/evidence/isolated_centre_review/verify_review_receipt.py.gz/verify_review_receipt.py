#!/usr/bin/env python3
import hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
receipt=json.loads((R/'receipt.json').read_text());count=0
for e in receipt['outputs']+[receipt['target'],receipt['author_receipt']]:
    data=pathlib.Path(e['path']).read_bytes();assert len(data)==e['bytes'];assert sha(data)==e['sha256'],e;count+=1
bound={x['path'] for x in receipt['outputs']}
extras=[str(p) for p in R.rglob('*') if p.is_file() and str(p) not in bound and str(p.relative_to(R)) not in receipt['excluded_paths']]
assert not extras,extras
execution=json.loads((R/'logs/finalize.execution.json').read_text());assert execution['returncode']==0 and not execution['timed_out']
print(json.dumps(dict(status='verified',checked_bindings=count,unlisted_outputs=extras,receipt_sha256=sha((R/'receipt.json').read_bytes()),report_sha256=receipt['outputs'][0]['sha256']),sort_keys=True))
