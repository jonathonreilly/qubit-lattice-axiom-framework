# Microscopic current implementation checkpoint

Status: source acquisition and analytic derivation in progress. The lead is a proposal, not authority.

Scope: derive or refute the local-current identification from exact local-vector action on D=A_loc Omega. No physical realization or local-domain premise is to be inferred from formal first moments. Root is coauthor and sole publication writer; separate independent review remains required.

Main authority a13caa4885f547c8d206265b031ba7649e539fd9; checkout 296155eda2ca6a5ab6ae6307190362b9a84ea690. Reuse applicable instructions at the unchanged hashes in the previous frozen leakage package. New writes are confined to MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md and this folder; the leakage package remains frozen.

Current route: derive H/B domain invariance from local action; pair-symmetrize only finite local commutators; prove connected-path factorial bound with support-independent radius; use finite-volume and self-adjoint-unitary Taylor remainders to identify vacuum columns, prove state invariance, and then obtain full canonical GNS implementation.

Open checks: signs and negative current clock; exact finite-volume boundary padding; J and s constants for density p; s=1/J=0 cases; identify precisely which S1 hypotheses remain external. No completed theorem is asserted by this checkpoint.
