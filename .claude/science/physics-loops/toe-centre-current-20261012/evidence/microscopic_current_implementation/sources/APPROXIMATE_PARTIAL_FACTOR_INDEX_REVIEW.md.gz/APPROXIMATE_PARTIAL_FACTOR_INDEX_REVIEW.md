# Independent review of the approximate partial-factor index theorem

**Source-review disposition: supported as written at the stated conditional mathematical scope. No material correction required.** This is an independent source review, not an audit verdict or a grant of retained status.

The reviewed source is `APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md`, SHA-256 `bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441`, with author receipt SHA-256 `ecf1f45eacdebea4702b1514d7f3295c9cfe7273e04e447c6bc517f63a6c6f67`. Repository base is `b9b032ae790c66e762a6296a1306bfb64ae7cd70`; checked current `origin/main` is `a13caa4885f547c8d206265b031ba7649e539fd9`. Instructions were read from that main revision and planning commit `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The inherited model and reasoning effort were kept unchanged; no subagent or model override was used.

## Result supported

For the uniform spin chain with site algebra `M_(dI) ⊗ M_(dB)`, the tail condition (P3), full interior-block map-norm condition (P4), threshold `CQ f(j) ≤ 1/3456`, and `η=ε+4CQ f(j)≤1` imply

\[
|\operatorname{ind}\gamma|\le 2j\log d_B+8j\delta\log(d_Id_B)+3g(\delta),\qquad
\delta=\eta/\sqrt2.
\]

The proof uses a finite QCA window and the exact RWW stability threshold. It does not rely on a dimension-free entropy-continuity estimate, an equality of ordinary and completely bounded norms for arbitrary maps, or rounding in a multi-prime logarithmic index group.

For the stated finite-range, uniformly bounded microscopic Hamiltonian interaction, the fixed-time tube estimates (P21) do follow with the explicit constants (P26), (P28). The choices (P22) therefore give the normalized bound (P24), of order `log² L/L`. With the separately supplied exact full-algebra identity `αt=τq`, the index is `q L^(d−1) log 2`; consequently a fixed nonzero q cannot satisfy all these Hamiltonian/shift hypotheses as L grows. This closes the named approximate-index step of the tube argument. It does not establish N1's prior reduction to that exact shift identity.

## Load-bearing checks

| Obligation | Source match and independent reconstruction |
|---|---|
| **Full algebra norm, Bell loss, amplification** — source lines 65–72, 131–185, 257–267 | The hypothesis controls every unitary in the full interior matrix algebra, including block-entangled unitaries. The normalized Weyl average has `m²` terms and coefficient `m^−2`. Trace preservation gives `1−p≤η²/2`; projection of a purification gives trace distance `≤η/√2`. The rank-one projection decouples the whole interior/reference pair from the finite remaining factors. No uncontrolled ancillary dimension enters. The separate Haar-intertwiner argument is also valid, with `\|\|U−1\|\|≤2η` and cb displacement `≤4η`, but the theorem does not require it or global gluing. |
| **Entropy dimensions and strict-QCA formula** — lines 187–235 | The common-mixture proof yields `\|Sρ−Sσ\|≤x log D+g(x)`. Three entropy terms give `2x(log DA+log DB)+3g(x)`. With `DA=DB=(dI dB)^r`, this is `4rδ log(dI dB)+3g(δ)` for either mutual information. After Bell projection each crossing mutual information lies in `[0,2r log dB]`; half their difference is bounded by `r log dB`. RWW Proposition 4.7, PDF pp.26–28, uses exactly r sites on each side and the same Choi convention. The sign agrees with `τq(A_n)=A_(n−q)`; the theorem itself takes absolute value. |
| **Explicit QCA constants** — lines 74–92 | RWW Theorem 2.6(i), Lemma 3.8(ii), Lemmas 5.1(i), 5.3(i), Proposition 5.4(i), Proposition 5.5, and Proposition 4.10/Remark 4.11 have the needed hypotheses. The eight corrections multiply nearest-neighbor errors by `25,97,385,97,385,97,385,97`; the displacement sum telescopes to `(A0−1)e`. Each intermediate error is below its required threshold under the stated conservative choice. Alignment costs at most `144A0e` in map norm, yielding single-site error `145A0e`. Lemma 2.7 yields the factor `2√2<3` when the sum is below one; otherwise the trivial bound two suffices. Thus `CQ=435A0`, `eQ=1/(2048A0)` are dimension-independent valid constants. The tracial GNS closures are hyperfinite and the automorphisms extend normally. |
| **Blocking and identification** — lines 94–129 | The radius-two construction is used in blocked units. The safe fine-site radius `3j` is valid, whereas a blind identification with exactly `2j` would not be justified by this blocking argument. On `[1,6(k+1)]` the cell counts are at most 12 and 6, giving `18CQf(k)≤1/192`. Both QCAs become nearest-neighbor after blocking by `3(k+1)`, so RWW Proposition 4.10 equates their indices. The comparison to an RWW defining sequence on `[1,6k]` has error tending to zero and identifies the stabilized value. The tail-dependent qualitative constant is used only for this limiting identification, not to select a uniform tube window. |
| **Assembly and tube scales** — lines 237–255, 269–311 | The four j-cells give error `ε+4CQf(j)`. Using strict radius two and dimensions `dI^j,dB^j` yields (P1). The logarithmic choices give `CQfL(j)≤L^−4/3456`, `ε≤L^−4/2`, and `η<L^−4`. The transverse count obeys `B/V≤2(d−1)R/L`. Division by `V log 2` then gives (P24). The restriction `R<L/2` holds eventually with all stated constants fixed. The cases `dI=1`, `dB=1`, or zero error introduce no singularity. |
| **Microscopic LR hypotheses** — lines 313–353 | NSY pp.17–20 define the pairwise F-norm used here; finite range and J imply `\|\|Φ\|\|F≤J/F(ell0)=NF`. The exponential times polynomial F-function is summable and reproducing on the microscopic ℓ¹ lattice. Its constants do not depend on L. Deleting terms cannot increase the interaction norm. NSY Theorem 3.1, equations (3.21)–(3.24), gives the stated disjoint-support coefficient; enlarging its boundary sums to support sums is legitimate. `CF≥1` and `Ct≥2` justify the chosen larger constant and the overlapping-support case. Theorem 3.5/Corollary 3.6 supply norm thermodynamic limits and point-norm continuous automorphisms. |
| **Microscopic sums and Duhamel** — lines 345–384 | The transverse kernel sums to at most `V S_(d−1)(a)`, not `V² S_(d−1)(a)`. The two longitudinal endpoint sums are independent of interval length; the shift costs `exp(a\|q\|)`. For small radii the zero approximant is sufficient. In Duhamel only boundary-crossing terms remain. Reversing the nonnegative sums uses `Σ_(Z∋w)\|\|hZ\|\|≤J` and leaves at most `nV` first-support sites. Every site in a crossing term is at least `R−ell0` from an interior support site; the exponential split gives exactly the bound in (P27). This is a full operator-norm estimate, uniform in outer truncation volume. |
| **Index of the tube flow** — lines 386–392 | For each fixed L, the slice Hilbert space is finite and the flow is a point-norm continuous path with one exponential tail function for all times between zero and t. This meets RWW Theorem 5.15(iii)(d), pp.48–49. Its index is zero. Additivity and the shift normalization produce (P29). No uniform Hilbert-space dimension across different L is needed for this step. |

## Evidence and independence

I read the complete 438-line target note and complete N1/B1/M1 reports before opening the author controls or receipt contents. I read RWW PDF pp.10–49 and 51, and NSY pp.17–28, including the LR proof on pp.22–24. Fresh `pypdf` extraction from the frozen PDFs matched the supplied text on all these pages. The RWW and NSY PDF hashes are respectively `03fc3e67ccd36c1f6ac7e5336bdf6977010cc12d615f90e095ded550268eda17` and `42fc3029fa582f14a01f858463f481d5cacf21ed785791d32c72dd9df97f66cd`.

The proof reconstruction was saved before control inspection in `partial_factor_review/precontrol_reconstruction.md`. A separate all-size geometric-series derivation is in `partial_factor_review/microscopic_kernel_proof.md`. In particular, for `ρ=e^−a` and `r≥|q|`, the exact longitudinal kernel is

\[
\frac{(\rho^{r-q+1}+\rho^{r+q+1})(1-\rho^n)}{(1-\rho)^2},
\]

and the one-coordinate transverse pair sum is

\[
L\frac{1+\rho}{1-\rho}-\frac{2\rho(1-\rho^L)}{(1-\rho)^2}.
\]

These formulas directly resolve the possible interval-length and extra-volume losses. The independent Fraction-based script checked 1,920 combined parameter cases and rejected removal of an endpoint, omission of a nonzero shift, and insertion of a spurious transverse-length factor. It completed with exit zero under the declared 30-second timeout; full stdout/stderr and execution identity are preserved. Its finite cases are implementation controls; the geometric-series argument supplies the all-size result.

The author's script also contains smaller geometric-sum controls, discovered afterward. My implementation was written before opening it and includes exact signed-shift closed forms. Both use the same exponential-kernel mechanism. This is an independently derived implementation check, not a second theorem proving the imported LR result or a wholly different mathematical route.

After reconstruction, I read the complete 298-line author control script, both baseline logs, the execution/mutation records, and the setup failure. The baseline records 33 finite controls. Every one of the 13 mutant sources matches its declared edit exactly; its saved traceback fails at the intended corresponding assertion. I rehashed all 231 artifacts listed in the author receipt with no mismatch. I did not rerun the author's controls. Their density matrices, Bell-edge counts, illustrative resource constants, and mutation failures are correctly separated from the infinite-algebra imports; they do not establish the general theorem by numerical agreement.

## Preserved limits and recovery

N1's H-int, H-cov, gap/unique-vacuum setting, exact continuous-momentum scattering completeness, common rational centres, and implementation of its momentum generator remain supplied or separately reviewed premises. This review does not certify N1's Step 1, its band-regularity claims, or all of B1/M1. The target correctly avoids importing a globally regular Bloch band from a local scattering shell. Its correction of N1 line 178 is right: use `Pb` for time `q/β`, or `Pb/β` for time q; do not divide by β twice.

No counterexample to the stated partial-factor theorem or its finite-range tube application was found. There is no claim about arbitrary long-range interactions, non-automorphic dynamics, nonlinear momentum actions, or a physical Record law. RWW Theorem 2.6 and Lemma 2.7 remain matched primary imports; their Appendix B proofs were not independently rebuilt. No Lean check or complete-paper certification is claimed. Prior referee labels and the assessment were frozen for recovery but were not used as proof. The later Y1/RZ changes are outside this review.

The review receipt, source inventory, complete evidence and current checkpoint are under `partial_factor_review/`. The original note and author receipt were rechecked unchanged at completion. No repository source, editable prompt, PR, main branch content, or audit data was edited by this review. The next scientific decision belongs to the coordinator: reuse this bounded mathematical lemma under its exact premises, while retaining the independent obligations preceding the full-algebra shift identity.
