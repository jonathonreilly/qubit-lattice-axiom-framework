# Control review and evidence limits

The proof reconstruction and independent control source were frozen at
2026-10-12 02:48:56 UTC before author-helper/output exposure. Their identities
are in `independent_freeze.json`. The separate control ran at 02:49:14 UTC;
the unchanged author helper replay began at 02:49:55 UTC. Source/result
metadata and descriptions were known, so this is not a blind comparison.

## Independent calculation

For occupation basis |b0 b1 b2>, h0 swaps unequal b0/b1 and h1 swaps unequal
b1/b2. They are the two open nearest-neighbor hopping bonds. With H=h0+h1
and B=h1, a raising/lowering derivation gives

    i[H,B] = i Z1 (c0 c2* - c0* c2).

This target is entered independently of the H/B multiplication: it maps
|001> to i|100>, |100> to -i|001>, with opposite signs when b1=1, and
annihilates the outer-equal subspace. Thus P has 2x2 ±Y blocks, P³=P and
exp(itP)=I+i sin(t)P+(cos(t)-1)P². The finite Hilbert vacuum |000> is cyclic
for M8 but is not separating. These facts supply the independent matrix,
functional-calculus and quotient controls, not a physical lattice model.

The Gaussian-integer gates use separate int64 real/imaginary matrices; the
small matrix entries remain exactly represented. The observed maximum entry
in the complete-basis Jacobi checks is 1. Exact algebra residuals are zero.
The wrong sign and dropped-half defects have coefficient l1 values 8 and 4.
The finite group and spectral remainder rows use floating sine/cosine and
operator norms, with explicit tolerances; they are not formal certificates.

The canonical finite GNS map is constructed from the alpha_t(E_i0)Ω columns.
All 64 basis elements satisfy its adjoint action; the 56 E_ij with j!=0
remain null on Ω. The right-action mutant U A U has exactly the same vacuum
columns for every tested basis element, but fails the full algebra identity
with defects 0.7232308639299241 and 1.1457349202009628. It therefore exposes
the particular gap that a vacuum-column-only implementation check would miss.

Clock defects are 0.33725543285370607 for a reversed clock and
0.10301691339501415 for double beta division. The tested spectral remainders
are below their derivative bounds for positive and negative time and orders
1,2,3,5,8. No test covers unbounded generators or infinite volume.

The support check aggregates exact history multiplicities by accumulated
unions for length-three intervals, including Y={0}, {0,7}, {0,13,26}. The
largest union reaches a+2n as predicted. At order two Y={0} gives 15 histories
versus the incorrect fixed-support bound 9, and the valid upper bound 27.
Singleton and empty-interaction cases are separate. After opening the author
helper, I found it uses the same accumulated-union recurrence for bonds.
Thus this part differs in fixture/cardinality, but is not a different general
counting mechanism. The occupation-basis/current/GNS calculation is the
distinct decisive control. Counts of predicates are never independence grades.

## Author helper coverage

The entire helper, lines 1–334, was read. The exact Pauli engine uses
Gaussian-rational coefficients and the correct cyclic product table. Local
derivation support ranges encompass all contributing centers. The direct
nested-derivation and explicit pair-density paths share this engine, so
agreement alone would not isolate a common multiplication bug. The separately
constructed dense matrices provide an arithmetic cross-check, while the
new occupation-basis calculation uses a different fixture and input assembly.

All final rows were read from `author_evidence/logs/finite_controls.final.jsonl`.
The saved JSON rows and stdout agree, and replay rows/metadata agree except for
the recorded timestamp. The exact helper copy has the original SHA-256
`e38b4cf704febec830a45c2521524be21646ce6bd512d6bf318dba581b31a908`.
Its result-file side effect is confined by copying it into `author_replay/`;
the original helper/output remain unchanged.

| Author controls | Checked scope |
|---|---|
| Five exact pair identities and first-moment translations | Actual nonzero Pauli probes detect sign/half and translation-sign errors; current covariance also enters the predicates. |
| Padded pair reduction, density support/Hermiticity | The 3R center cutoff agrees and R fails with l1 defect 93/4. Structural predicates alone cannot select current normalization. |
| Taylor coefficient stabilization, orders 1–5 | A separate nearest-neighbor interaction agrees with n-diameter padding; deleting the last layer gives defects 2,4,8,16,32. |
| Histories, orders 1–7 for three seeds | Exact enumerated counts satisfy the derived upper bound and cardinality bound; the omitted-growth mutation is discriminating for selected seeds/orders. |
| Singleton/zero cases | Actual history recurrence rather than the earlier redundant arithmetic equality. Zero's support predicate is vacuous, as it should be; count zero is the content. |
| Dense finite pair identity, clocks, remainders | Correct finite identity with a shared density input; clocks detect actual nonzero alternatives, and remainders are finite numeric checks. |
| Density norm | Numeric actual norms are observations. The independent analytic upper bound uses 7/4 for h, 147/8 for p, and 1029/8 for J. It is loose and does not select the current. |

## Actual source mutations and nondiscrimination

Each copied-source mutant retains its exact source, JSON result, stdout,
stderr and execution receipt under `mutations/`. Every execution completed
within its declared 30-second timeout and exited 1. Their complete failed
predicate lists are in `logs/author_mutation_summary.json`.

| Mutation | Rejection | Preserved nondiscriminating cases |
|---|---|---|
| Reverse `F(r,2)` sign | Five exact pair rows fail | Hermiticity/support/norm still pass; dense clock fixture computes its own current and is unaffected. |
| Replace `F(r,2)` by `F(r)` | Five exact pair rows fail | Loose norm upper bound and structural rows pass despite doubled current. |
| Reduce current center radius 3 to 1 | Five exact pair rows fail | Relative-center translation covariance alone still passes. |
| Delete k in `a+k` | Twelve rows fail: a=1 and a=2 at orders 2–7 | All order-one rows and the contiguous a=3 fixture through order seven pass. This does not validate the mutant bound. |
| Double Taylor derivative | Orders 2–6 fail | Order one passes its inflated remainder bound. |

The reader should not interpret any predicate outside its declared target.
In particular, the dense pair residual is a universal finite commutator
identity for its chosen matrices; it does not independently identify the
specified microscopic density or prove an infinite-volume realization.
The source itself makes those limits explicit, so no source correction is
required on this point.

## Historical and operational limits

Both earlier author scripts/results/stdout are copied unchanged. Their source
diffs to final and metadata checks are in `logs/author_history_inspection.json`.
Run 1 has 49 true predicates and run 2 has 50. Final changes turn reported
mutation/support facts into executable gates, replace a redundant arithmetic
edge check with enumeration, rename a radius field, and use an analytic
triangle upper bound. The displayed prior source/result history does not
contain a suppressed failed mathematical predicate. It does not establish
that every possible earlier platform event was captured.

The original receipt records final exit 0. A structured metadata scan of its
JSON logs found no declared per-run timeout or elapsed-time receipt; this
limit is preserved in `logs/author_execution_metadata_scan.json`. The two
platform disconnect identifiers and recovered-draft discrepancy are preserved
in copied operational logs. There is no inferred diagnosis of those events.

Review executions use Python 3.13.5, NumPy 2.4.4; the author replay additionally
uses SciPy 1.17.1. Independent and replay runs declare 60-second timeouts and
complete in 0.250119625 and 0.679413583 seconds respectively, both exit 0.
Complete stdout and empty stderr files are on disk. No timed-out scientific
execution occurred in this review.
