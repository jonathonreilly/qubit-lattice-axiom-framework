# Independent reconstruction before author-helper exposure

Source: `MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md`, all 399 lines, SHA-256
`bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`.
This reconstruction and the companion control script are to be frozen together
before opening the author's current helper or output. The source, its declared
control descriptions, and receipt metadata were visible; this is not a blind
check. Root proposed the mechanism and is a coauthor, not this reviewer.

## Target and supplied inputs

For every bounded finite-range translation-covariant self-adjoint spin density
on Z^d, and every cyclic GNS representation with the actual self-adjoint H, B,
P and exact local-vector equalities I1–I4, prove the represented full-algebra
identity I29 for every real time. No physical realization, spectral gap,
positivity, scattering or independent audit conclusion is a success criterion.
Changing any domain or local-vector equality changes the theorem.

Necessary contextual premises were read directly: the complete root lead and
next-obligation assessment; N1 H-loc/H-int/H-cov and Step 1/HR qualification;
the compact-patch S1–S4 and clock conventions; partial-factor P11/P12. None of
the predecessor conclusions is used in the implementation proof itself. The
axiom memo and primitive registry provide no hidden boost or dynamics grant.

## Reconstruction of I1–I13

For local A supported in Y, only density centers in Y^R appear in its first
commutator. Its derivative is supported in Y^(2R), so any center in a second
commutator lies in Y^(3R). Thus both delta_h and delta_b really map local
observables to local observables; the unbounded center coordinate creates no
infinite sum at this stage. D is linear and dense by cyclicity and local norm
density. The actual equalities H AΩ=-i delta_h(A)Ω and B AΩ=-i delta_b(A)Ω
give H D and B D contained in D, then every finite operator word, including
HB and BH, is defined on D. No conclusion about the full domains or unitary
invariance of D is needed. PΩ=0 follows by applying the supplied commutator
identity to Ω. In fact the displayed H/B vector equalities at A=1 already
imply the H/B vacuum equations; retaining them explicitly is harmless.

For a finite center set I containing Y^(3R), expand bounded commutators only:

    [delta_h,delta_b] A = -[[H_I,B_I],A],
    [H_I,B_I] = sum_(x,y in I) y_b [h_x,h_y]
              = (1/2) sum_(x,y in I) (y_b-x_b)[h_x,h_y].

The second equality follows by exchanging the dummy indices in a finite sum.
Any term that can survive its final commutator with A has overlapping h
supports and at least one such support meeting Y. Thus both centers are
already in I; removing I after that final local commutator adds only zeros.
Writing r=y-x gives p_b(x)=(i/2) sum_r r_b[h_x,h_(x+r)] and hence
delta_p=i sum_x[p_b(x),.] = [delta_h,delta_b]. Both pair orientations are
counted, so the half-factor is compulsory. Multiplication by i, including
the two i factors in the derivation commutator, gives the stated sign.

For nonzero density commutators |r|_1<=2R; the union of the two supports is
contained in x+B_(3R). The density is Hermitian because i times an
anti-Hermitian commutator is Hermitian and its weight is real. The triangle
bound is (1/2) sum |r_b| 2 h^2 = h^2 c_(R,b). Assigning the whole density to
x+B_(3R) is a legitimate interaction, even when its actual support is smaller.
Exactly |B_(3R)| such assigned sets contain a fixed site. Thus s<=v_(3R),
diameter<=6R and J<=v_(3R) h^2 c_(R,b). R=0 gives zero current.

H B AΩ=-delta_h delta_b(A)Ω and B H AΩ=-delta_b delta_h(A)Ω now imply
P AΩ=-i delta_p(A)Ω. The result is again a local cyclic vector, deriving
P-invariance of D and the iterated identity P^n AΩ=(-i)^n delta_p^n(A)Ω.
Translations replace the first-moment weight x_b by x_b-j_b under the
specified positive geometric convention. The current weight y_b-x_b is
unchanged. Thus I13 has the stated negative first-moment shift; it does not
prove equality of full unbounded boost domains.

## Reconstruction of I14–I22

Expand delta_Psi^n(A) as ordered nested commutators. For a nonzero history,
X_k must meet the preceding union Z_(k-1). Each step adds at most s-1 sites,
even when Y is disconnected or much larger than one interaction support.
The union size is at most a+(k-1)(s-1). For any such union,

    sum_(X intersects Z) ||Psi(X)|| <= sum_(z in Z) sum_(X contains z)
                                      ||Psi(X)|| <= J |Z|.

Induction on the weighted history tree and a norm factor two per commutator
proves I15. The tree has finitely many branches at each level: on Z^d there
are finitely many subsets of each fixed finite-range neighborhood. Deleting
interaction terms cannot enlarge any bound. This proves the finite-volume
version at the same time.

For r=s-1>0, divide by n! and write the product as r^n(a/r)_n. At z=2Jr|t|,
the ratio of consecutive majorants is z(n+a/r)/(n+1), converging to z.
Hence all remainder terms and series tails vanish for z<1, with a positive
radius independent of a and volume. There is no uniform bound in a and no
boundary claim at z=1. For s=1, the product is a^n and the exponential series
is entire. For J=0 all terms vanish. Scalars have zero positive derivatives.

G_Lambda is a bounded self-adjoint local operator. Repeated fundamental
theorem of calculus along real t gives I19 (the same formula with t^N works
for negative t after the interval substitution). Isometry of alpha_(ut)^L
gives the remainder |t|^N ||delta_L^N(A)||/N!, without controlling ||G_L||.
Every connected length-k history is within distance k ell of Y: choose an
intersection point at each new set and use its diameter. Consequently each
of its sets is wholly included in any volume containing Y^(k ell), proving
coefficient stabilization I20. At |t|<rho, choose N for the common remainder,
then Lambda for the finitely many coefficients. This proves a net limit in
norm, independent of exhaustion, uniformly on smaller time intervals.

The small-time maps extend by isometry/density to the quasilocal algebra,
preserving products and adjoints. For point-norm convergent isometries F_L,
G_L, the displayed two-term inequality proves convergence of F_L G_L at
every fixed A. For arbitrary t, choose m with |t/m|<rho and apply it m times
to alpha_t^L=(alpha_(t/m)^L)^m. The limit is unique because this is the same
finite-volume net for every m. Use that composition inequality again with
arbitrary s,t to pass the finite-volume group law, giving inverses as well.
Continuity at zero on locals follows from the convergent series, then by
density on all observables, then by the group law at every time. Therefore
this is a point-norm continuous automorphism group, with the claimed local
generator. The uniqueness sentence uses iterated generator domains supplied
by the fact that the local derivation maps locals into locals and the same
isometric Taylor remainders; no core assumption is smuggled in.

The boundary warning is correct: the interaction-cutoff Hamiltonian need
not be the commutator of two independently cut off first moments. The local
finite-center proof and the current interaction proof use their own sufficient
padding. A 4R spatial neighborhood contains the supports of the h centers
in the 3R center neighborhood; 6Rn suffices for assigned-current coefficient n.

## Reconstruction of I23–I31

Actual self-adjoint P supplies the spectral theorem and its unitary group.
For xi in Dom P^N, integrate N strong derivatives or apply the scalar
spectral Taylor remainder. The vector integral has norm at most
|t|^N ||P^N xi||/N!, proving I25. Every local cyclic vector belongs to
Dom P^N by the derived invariant D. Representation contractivity and I15
control its remainder with the same radius. The coefficients match the
microscopic series since i^n(-i)^n=1. Thus I26 is proved on local vacuum
columns for small t.

Taking its vacuum expectation and using e^(-itP)Ω=Ω proves state invariance
for small times. This extends to all algebra elements by norm density and to
all real times by the already established flow group law. For the canonical
map AΩ -> alpha_t(A)Ω, the squared norm is omega(alpha_t(A* A))=omega(A* A).
This equality also treats differences A-B, so it proves well-definedness on
the GNS null-vector quotient, not just preservation of individual norms.
Inverse time makes it unitary; point-norm continuity gives strong continuity.
On dense local columns its small-time action agrees with e^(itP), hence the
bounded operators agree; their group laws extend that equality globally.

For arbitrary quasilocal A,B, W_t pi(A) W_t* pi(B)Ω equals
pi(alpha_t(A)) pi(B)Ω by applying W_t to A alpha_(-t)(B). Equality on this
dense vector set proves the represented operator identity I29. No step uses
XΩ=0 => X=0. The additional faithfulness observation is valid because every
unital local matrix-factor representation is isometric and locals are norm
dense. Faithfulness is unnecessary for the represented implementation itself.
Uniqueness follows from equality of groups and the self-adjoint generator.

The positive current clock is Ad e^(itP). The chosen physical spatial clock
Ad e^(-isP) is its value at -s. Replacing P by P/beta therefore changes the
time to -y/beta, once, and divides J by beta for beta>0. The physical H clock
retains +itH. Translating finite-volume current interactions and passing the
norm limit proves algebra flow covariance; invariant geometric GNS
implementers then commute with the current group on the dense cyclic set.

## Distinct decisive control, fixed before execution

Use a three-site open hopping fixture, different from the author's disclosed
Pauli density. Let c=|1><0|, Z=diag(1,-1),
h0=c0 c1*+c0* c1, h1=c1 c2*+c1* c2; H=h0+h1 and B=h1. The vacuum is |000>.
An independent raising/lowering calculation gives

    P_expected = i Z1 (c0 c2* - c0* c2),
    P_expected^3 = P_expected,
    exp(itP_expected) = I + i sin(t) P_expected
                         + (cos(t)-1) P_expected^2.

Construct H/B from occupation-basis swaps and expected P directly from the
last formula's occupation-basis transitions, not from a computed commutator.
Use integer real/imaginary matrices for exact checks; the fixture contains
only Gaussian-integer entries. Compare all 64 matrix units for Jacobi and
local-vector action. The reference polynomial exponential supplies an
analytic test target independently of matrix exponential software.

Check canonical action and null-vector preservation for the pure vacuum,
which is cyclic and nonseparating for M8. Check conjugation on all matrix
units. Mutate current sign, half-factor, clock and beta scaling. Include a
right-action mutant U A U that agrees on every vacuum column but fails the
full-algebra gate. This directly tests the semantic gap I26 -> I29.

Independently enumerate weighted connected-support histories by dynamic
programming on accumulated unions for three-site interval interactions, with
connected and disconnected initial supports. This differs from pair/bond
history fixtures and tests the s-1 growth. Removing support growth should
fail: from Y={0}, there are 3 choices at step one and 5 per choice at step
two, giving 15 histories, exceeding (Ja)^2=9 for J=3. The correct product
bound gives 27. Handle singleton and zero cases separately. Check scalar
spectral Taylor remainder inequalities at the exact eigenvalues {-1,0,1},
for both time signs. None of these finite tests proves infinite-volume or
unbounded-domain facts; those rely on the reconstruction above.

## Preliminary disposition and remaining obligations

No mathematical defect found in I1–I31 during this reconstruction. This is a
pre-control conclusion, subject to change after actual checks. The supplied
existence and exact local action of B, supplied self-adjoint P and commutator
closure on D, strong H/P and distinct-current commutation, positive energy
and all spectral/scattering/physical hypotheses remain separate. The theorem
does discharge local invariance/products, PΩ=0, finite-range current identity
and uniform constants, norm flow construction and full GNS implementation.
There is no physical model construction or predecessor theorem certification.

The no-local-action shortcut in §8 has a valid 3-dimensional diagnostic:
H=diag(0,1,2), B=E12+E21 (indices 0,1,2) fix e0 but i[H,B] is nonzero.
A designated coordinate-zero density has zero first-moment action, so it
cannot identify this B. Adding a translation-invariant C also preserves the
formal covariance equation without fixing the commutator with H. These are
scoped failures of weakened premises, not no-go claims about lattice physics.

No Lean proof, audit verdict, external theorem certification, Git operation,
prompt edit, model override or subdelegation is undertaken. Deadline remains
2026-10-12 16:00:52 UTC.
