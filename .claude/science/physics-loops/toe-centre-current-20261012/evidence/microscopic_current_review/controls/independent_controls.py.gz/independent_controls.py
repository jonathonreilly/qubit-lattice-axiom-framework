"""Finite diagnostics, not a proof of the infinite-volume theorem.

Independent of the author's helper. Exact gates use pairs of int64 matrices.
No exponentiation package supplies the expected group: P^3=P gives it directly.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import platform
from collections import defaultdict

import numpy as np

ROWS = []


def record(name, condition, **data):
    row = dict(name=name, passed=bool(condition), **data)
    ROWS.append(row)
    print(json.dumps(row, sort_keys=True))


def zero(n=8):
    return np.zeros((n, n), dtype=np.int64), np.zeros((n, n), dtype=np.int64)


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def scale(k, a):
    return k*a[0], k*a[1]


def mul(a, b):
    return a[0]@b[0] - a[1]@b[1], a[0]@b[1] + a[1]@b[0]


def ii(a):
    return -a[1], a[0]


def comm(a, b):
    return add(mul(a, b), scale(-1, mul(b, a)))


def delta(a, b):
    return ii(comm(a, b))


def defect(a, b):
    return int(np.abs(a[0]-b[0]).sum() + np.abs(a[1]-b[1]).sum())


def complex_matrix(a):
    return a[0].astype(float) + 1j*a[1]


def unit(a, b):
    z = zero()
    z[0][a, b] = 1
    return z


def hopping(left):
    # Site 0 is the high bit, site 2 the low bit.
    a = zero()
    p, q = 1 << (2-left), 1 << (1-left)
    for basis in range(8):
        if bool(basis & p) != bool(basis & q):
            a[0][basis ^ p ^ q, basis] = 1
    return a


def current_from_occupation():
    # Derived directly: i Z_1 (c_0 c_2* - c_0* c_2).
    p = zero()
    for basis in range(8):
        first, middle, last = (basis >> 2) & 1, (basis >> 1) & 1, basis & 1
        if first != last:
            z = 1-2*middle
            p[1][basis ^ 5, basis] = z * (1 if last else -1)
    return p


def support_histories(seed, depth, term_size):
    """Exact recurrence in accumulated supports, not raw history enumeration.

    Every interval of length term_size has weight one. Candidate left ends
    are generated from the current union, so there is no volume truncation.
    """
    states = {frozenset(seed): 1}
    counts, max_sizes, state_counts = [], [], []
    for n in range(1, depth+1):
        nxt = defaultdict(int)
        for support, weight in states.items():
            starts = {x-k for x in support for k in range(term_size)}
            for left in starts:
                nxt[support | frozenset(range(left, left+term_size))] += weight
        states = nxt
        counts.append(sum(states.values()))
        max_sizes.append(max(map(len, states), default=0))
        state_counts.append(len(states))
    return counts, max_sizes, state_counts


def main():
    h0, h1 = hopping(0), hopping(1)
    h, b = add(h0, h1), h1
    p = current_from_occupation()
    pc = ii(comm(h, b))
    record('current_from_occupation_vs_commutator', defect(p, pc) == 0,
           gaussian_integer_l1=defect(p, pc))
    # Both ordered pairs: i/2 (1 [h0,h1] -1 [h1,h0]).
    pair_twice = ii(add(comm(h0, h1), scale(-1, comm(h1, h0))))
    even = all(np.all(x % 2 == 0) for x in pair_twice)
    pair = tuple(x // 2 for x in pair_twice)
    record('ordered_pair_half_factor', even and defect(pair, p) == 0,
           numerator_even=bool(even), gaussian_integer_l1=defect(pair, p))
    record('wrong_sign_detected', defect(scale(-1, pair), p) > 0,
           gaussian_integer_l1=defect(scale(-1, pair), p))
    record('missing_half_detected', defect(pair_twice, p) > 0,
           gaussian_integer_l1=defect(pair_twice, p))
    record('cubic_current_polynomial', defect(mul(mul(p,p),p), p) == 0,
           gaussian_integer_l1=defect(mul(mul(p,p),p),p))
    record('current_self_adjoint', np.array_equal(p[0].T, p[0]) and
           np.array_equal(-p[1].T, p[1]))
    record('all_generators_fix_vacuum', all(np.all(a[0][:,0] == 0) and
           np.all(a[1][:,0] == 0) for a in [h,b,p]))
    jacobi, local_action, max_entry = 0, 0, 0
    for i in range(8):
        for j in range(8):
            a = unit(i,j)
            lhs = add(delta(h,delta(b,a)), scale(-1,delta(b,delta(h,a))))
            rhs = delta(p,a)
            jacobi = max(jacobi, defect(lhs,rhs))
            expected = scale(-1,ii(rhs))
            pa = mul(p,a)
            local_action = max(local_action, int(np.abs(pa[0][:,0]-expected[0][:,0]).sum()+
                                                np.abs(pa[1][:,0]-expected[1][:,0]).sum()))
            for arr in lhs+rhs:
                max_entry = max(max_entry,int(np.abs(arr).max()))
    record('jacobi_on_complete_matrix_basis', jacobi == 0,
           matrix_units=64, maximum_gaussian_integer_l1=jacobi,
           maximum_integer_entry=max_entry)
    record('local_vector_action_on_complete_matrix_basis', local_action == 0,
           matrix_units=64, maximum_gaussian_integer_l1=local_action)
    pf = complex_matrix(p)
    ident = np.eye(8)
    omega = ident[:,0]
    def u(t):
        return ident + 1j*math.sin(t)*pf + (math.cos(t)-1)*(pf@pf)
    def norm(a):
        return float(np.linalg.norm(a,2))
    for t in [0.37,-0.61]:
        ut = u(t)
        gram = norm(ut.conj().T@ut-ident)
        record(f'closed_exponential_unitarity_{t}', gram < 2e-14, residual=gram)
        columns=[]
        for k in range(8):
            a=complex_matrix(unit(k,0))
            columns.append((ut@a@ut.conj().T)@omega)
        w = np.column_stack(columns)
        max_full=max_null=max_invariance=0.0
        wrong_full=wrong_columns=0.0
        for i in range(8):
            for j in range(8):
                a=complex_matrix(unit(i,j))
                actual=ut@a@ut.conj().T
                max_full=max(max_full,norm(w@a@w.conj().T-actual))
                max_invariance=max(max_invariance,float(abs(actual[0,0]-a[0,0])))
                if j != 0:
                    max_null=max(max_null,float(np.linalg.norm(actual@omega)))
                wrong=ut@a@ut
                wrong_full=max(wrong_full,norm(wrong-actual))
                wrong_columns=max(wrong_columns,float(np.linalg.norm((wrong-actual)@omega)))
        record(f'nonseparating_gns_full_action_{t}',max_full<2e-14 and max_null<2e-14
               and max_invariance<2e-14,matrix_units=64,null_matrix_units=56,
               max_full_residual=max_full,max_null_residual=max_null,
               max_state_invariance_residual=max_invariance)
        record(f'vacuum_column_mutant_discriminator_{t}',wrong_columns<2e-14 and wrong_full>0.1,
               same_column_residual=wrong_columns,full_algebra_defect=wrong_full)
    t=0.43; beta=2.5; a=complex_matrix(unit(4,1))
    physical=u(-t/beta)@a@u(-t/beta).conj().T
    wrong_clock=u(t/beta)@a@u(t/beta).conj().T
    wrong_beta=u(-t/beta**2)@a@u(-t/beta**2).conj().T
    kpf=pf/beta
    uk=ident+1j*math.sin(-t/beta)*beta*kpf+(math.cos(-t/beta)-1)*beta**2*(kpf@kpf)
    proper=uk@a@uk.conj().T
    record('negative_clock_single_beta',norm(physical-proper)<2e-14,
           residual=norm(physical-proper),beta=beta,time=t)
    record('positive_clock_mutant_detected',norm(physical-wrong_clock)>0.1,
           defect=norm(physical-wrong_clock))
    record('double_beta_mutant_detected',norm(physical-wrong_beta)>0.05,
           defect=norm(physical-wrong_beta))
    # Scalar spectral theorem remainder: exact spectrum is {-1,0,1}.
    for t in [0.4,-1.2]:
        for n in [1,2,3,5,8]:
            err=0.0
            for lam in [-1,0,1]:
                poly=sum((1j*t*lam)**k/math.factorial(k) for k in range(n))
                exact=complex(math.cos(t*lam),math.sin(t*lam))
                err=max(err,abs(exact-poly))
            bound=abs(t)**n/math.factorial(n)
            record(f'spectral_remainder_{t}_{n}',err<=bound*(1+1e-9)+1e-15,
                   error=err,bound=bound,ratio=err/bound)
    for seed in [{0},{0,7},{0,13,26}]:
        depth=7;s=3;j=3;a=len(seed)
        counts,sizes,states=support_histories(seed,depth,s)
        bounds=[j**n*math.prod(a+k*(s-1) for k in range(n)) for n in range(1,depth+1)]
        record('triple_support_history_'+str(sorted(seed)),
               all(c<=b for c,b in zip(counts,bounds)) and
               all(v<=a+n*(s-1) for n,v in enumerate(sizes,start=1)),
               seed=sorted(seed),counts=counts,bounds=bounds,max_union_sizes=sizes,
               dynamic_state_counts=states)
        if a==1:
            record('fixed_support_growth_mutant_detected',counts[1]>(j*a)**2,
                   order=2,actual_histories=counts[1],mutant_bound=(j*a)**2)
    counts,sizes,states=support_histories({0,11},7,1)
    record('singleton_entire_case',counts==[2**n for n in range(1,8)] and all(v==2 for v in sizes),
           counts=counts,max_union_sizes=sizes)
    # Empty available interaction set has no extension at any positive order.
    states={frozenset({0}):1}; zero_counts=[]
    for _ in range(7):
        nxt=defaultdict(int)
        for support,weight in states.items():
            for interaction in []:
                nxt[support|interaction]+=weight
        states=nxt;zero_counts.append(sum(states.values()))
    record('zero_interaction_case',zero_counts==[0]*7,counts=zero_counts)
    out=dict(python=platform.python_version(),numpy=np.__version__,
             source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             rows=ROWS,total=len(ROWS),failed=sum(not r['passed'] for r in ROWS),
             scope='Finite controls only; no physical or unbounded-domain realization')
    Path(__file__).with_name('independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ['python','numpy','source_sha256','total','failed']},sort_keys=True))
    raise SystemExit(bool(out['failed']))


if __name__=='__main__':
    main()
