# Next obligation before the full-algebra shift identity

**Assessment date:** 2026-10-11. **Status:** source assessment and proposed derivation, not a physical premise adoption, an N1 certification, or an audit verdict.

The most useful next obligation, within N1's common-rational-centre class, is **a scattering construction from microscopic observables that is complete on the entire vacuum GNS Hilbert space**. In particular, the exact continuous-momentum particles must admit scattering states whose symmetry action is inherited from their local creators. N1's last algebraic implication is already conditional on this construction, completeness, and HR covariance. There is no further index gap to invent after those premises are supplied. The checked index lemma makes it consequential to resolve their microscopic validity.

The strongest unresolved statement is surjectivity of this scattering map. Its first discriminating derivation should test the local scattering construction for one compact patch of an isolated exact mass shell. Passing that test would establish only an ingredient of completeness. It would not establish completeness, N1, or an obstruction for every qubit theory.

## Exact sources and limits

Repository: `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/boost_worktree`. Working base: `b9b032ae790c66e762a6296a1306bfb64ae7cd70`. Main authority: `a13caa4885f547c8d206265b031ba7649e539fd9`. Current checked `origin/pr-9476-latest`: `407f99203a553b336f98e832213045ed49f7fc13` (checked 2026-10-11 22:56:36 UTC). The three reports below were also checked against the requested earlier PR head `dec0b37467be8cd7b47449833a734e1c799dc1c0`; their bytes agree at both commits and with the frozen copies fully read during the independent index review.

The Git path prefix is `.claude/science/exercises/gravity-current-state-20261009/agents/`. Recovery copies are in `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/partial_factor_review/frozen/sources/`.

| Source | SHA-256 | Relevant locations |
|---|---|---|
| `C4_N1_report.md` | `c284a41bfee8a1238643330ddd46f3a7c4f6f1a865509a9aaec5ab6f4238ad13` | Hypotheses, lines 39–45; commutant/tower, 72–95; Step 1, 156–168; exclusions, 204–207 and 239–245; explicit HR-covariance qualification, 271 |
| `C4_B1_report.md` | `95044a142cf94ad397c5f7b2bdf806905d2f40bb166fb8d5920fb5daf54a7a0e` | Bounded-sector Theorem U, 67–71; first-moment discussion, 73–81 |
| `C4_M1_report.md` | `fb2d6b5f54fcff8680219dce5f903d6620e5f987d4f093462502dc3e600b1b2b` | T3 assumptions and argument, 226–256; especially the unproved scattering convergence at 234 |

The checked mathematical input is `APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md`, SHA-256 `bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441`, with author receipt `partial_factor_index/receipt.json`, SHA-256 `ecf1f45eacdebea4702b1514d7f3295c9cfe7273e04e447c6bc517f63a6c6f67`. Its frozen independent review is `APPROXIMATE_PARTIAL_FACTOR_INDEX_REVIEW.md`, SHA-256 `9118707fdcc85cdfd0a1160598872fb8544a9de757b3a1efe8e93292719c533c`, and receipt `partial_factor_review/receipt.json`, SHA-256 `03b9c5236179f02220f16f4770f7386eb4673aa78d8881be9b8076c6afe267bf`. These paths are relative to this report's directory.

The review checked the dimension-aware partial-factor estimate, explicit RWW correction/identification hypotheses, and microscopic uniform LR bounds needed for its logarithmic-window tube application. It did not certify N1's scattering or physical premises. This assessment reuses that bounded result; it does not extend the frozen review. No Y1/RZ or changed science outside the three identified reports was assessed. No author control was rerun for this assessment.

## Minimal premise and implication graph

Let \(\mathcal A\) be the quasilocal qubit algebra and \((\pi,\mathcal H_\Omega,\Omega)\) its nonzero vacuum GNS representation. Fix one lattice direction \(b\). Use N1's conventions

\[
U(j)=e^{-ij\cdot P/\beta},\qquad V_j=U(j)^*T_j,\qquad \beta>0.
\]

The microscopic implementation premise means that \(P_b\) generates on \(\mathcal A\) the finite-range bounded-current dynamics used in H-loc, and that its implementation in \(\pi\) is the integrated generator in H-int. A formal sum or a formal Lie bracket alone is insufficient for this identification. The reports use this identification; it remains explicit here rather than being derived anew from their domain assumptions.

```text
H-int + integrated H-cov + invariant vacuum
    └─> V_j commutes with the Poincaré representation and fixes Ω

H-loc + microscopic implementation
    └─> Ad(V_j) acts on almost-local creators; P_b has a finite-time LR flow

Constructive scattering limits + dependence only on one-particle data
    └─> V_j W = W Γ(v_j), where v_j = V_j restricted to the particle space

Full-GNS completeness (Ran W = H_Ω) + common q with v_j^q = 1
    └─> V_j^q = 1 on H_Ω
    └─> T_{q e_b} = exp(-i q P_b/β)

Faithfulness of π + microscopic implementation
    └─> τ_{q e_b} = α^{P_b}_{q/β} on every A in the quasilocal algebra

Checked partial-factor/tube theorem + fixed microscopic finite-range constants
    └─> contradiction for nonzero q
```

Here \(W\) can be an incoming or outgoing wave operator; one surjective choice suffices. \(\Gamma(v_j)\) is the product action on the specified asymptotic Fock space, including all species and multiplicity spaces. The rational-centre premise must imply the **operator identity** \(v_j^q=1\) with one common positive integer \(q\). Checking a finite selection of scalar particle phases would not suffice.

The last index implication is the checked conditional mathematical result: the composed tube automorphism has index \(qV\log 2\), while the partial-factor bound divided by \(V\log 2\) tends to zero as the transverse volume grows. It requires a full-algebra equality and microscopic constants fixed independently of tube size. Agreement on particles, low-energy states, single-site expectations, or a finite window does not supply that equality.

## Why the conditional bridge is already closed

N1 line 271 expressly includes HR covariance in Step 1's conditions. M1 line 234 expressly assumes the relevant scattering convergence and does not prove it. Taken with their intended constructive meaning, these conditions are enough for the following elementary argument.

Suppose scattering states are limits of products of almost-local creators,

\[
W(\psi_1\otimes_s\cdots\otimes_s\psi_n)
=\lim_{t\to-\infty} B_{1,t}\cdots B_{n,t}\Omega,
\]

with the appropriate particle statistics, and the limit depends only on the one-particle data \(\psi_i\). The automorphism induced by \(V_j\) commutes with the time and translation smearings. Applying the fixed bounded unitary \(V_j\) through the limit replaces each creator by its transformed creator, which creates \(v_j\psi_i\). Consequently \(V_jW=W\Gamma(v_j)\). This is a consequence of a valid symmetry-covariant local scattering construction; it does not require an additional index argument.

If \(W\) is onto and \(v_j^q=1\), then

\[
V_j^q=W\Gamma(v_j^q)W^*=1.
\]

The commuting factors \(U(j)\) and \(V_j\) give \(T_j^q=U(j)^q\). The UHF qubit algebra is simple, so its nonzero GNS representation is faithful; purity is not needed for this step. Equality of the implemented automorphisms therefore implies equality on all of \(\mathcal A\).

With \(\alpha_s^{P_b}=\operatorname{Ad}e^{-isP_b}\), the time is \(s=q/\beta\). Equivalently use generator \(P_b/\beta\) and time \(q\). N1 line 178 divides by \(\beta\) in both generator and time; the checked tube application already corrected that normalization.

If \(W\) is only isometric, this argument yields \(V_j^q=1\) only on its scattering range. Faithfulness of \(\pi\) cannot turn equality on a proper Hilbert subspace into equality of operators. This is why full completeness is the decisive supplied premise.

An abstract identification with a Poincaré Fock representation is also insufficient to replace the constructive covariance premise. An exact algebraic diagnostic is available. On bosonic Fock space over a massive scalar one-particle representation, let \(U_F=\Gamma(U_1)\), let \(N\) be particle number, and set

\[
V=\exp\!\left(i\vartheta N(N-1)/2\right),\qquad
T_b=U_F(e_b)V,
\quad \vartheta/(2\pi)\notin\mathbb Q.
\]

Use \(T_c=U_F(e_c)\) in the other directions. These translations commute, \(V\) commutes with the full Poincaré representation, and the integrated covariance relation for \(T_b\) holds. The vacuum is unique and gapped. \(V\) is the identity on the vacuum and one-particle space, but equals \(e^{i\vartheta}\) on the two-particle space. The identity map gives a complete abstract Fock identification, yet it does not intertwine \(V\) with \(\Gamma(V|_{\mathcal H_1})=1\). This tests the logical weakening of H-AC; it is **not** a finite-dimensional local-lattice model, a counterexample to N1's full intended premises, or a physical route around the index theorem. Its required local-observable compatibility is absent.

## Strongest unresolved obligation and a discriminating first derivation

Keep the integrated representation, microscopic implementation, gap/vacuum conditions, and common rational centres as explicit hypotheses. Let \(\mathcal H_1\) include every particle species and multiplicity channel claimed by H-AC, and let \(\mathcal H_{\rm sc}\) be the closed span of the vacuum and all constructed multiparticle limits. The target is

\[
W_\pm:\mathcal F_{\rm as}(\mathcal H_1)\longrightarrow\mathcal H_\Omega
\quad\text{is a surjective isometry, with}\quad
V_jW_\pm=W_\pm\Gamma(v_j).
\tag{SC}
\]

For a constructed time-covariant scattering range with projection \(P_{\rm sc}\), its completeness can be written as the concrete exhaustion condition

\[
\left\|(1-P_{\rm sc})\,\mathbf 1_{[m,E]}(H)\,\pi(A)\Omega\right\|=0
\quad\text{for every finite }E\text{ and every local }A.
\tag{EX}
\]

Together with the vacuum, these vectors are dense. Thus (EX) is an equivalent formulation of completeness, not a weaker result that would already settle it. H-gap alone neither supplies isolated particle mass shells nor proves this exhaustion. No derivation of (SC) or (EX) from the remaining microscopic assumptions is present in the identified reports.

**Proposed first calculation: a compact mass-shell patch with geometric separation.** This is a derivation to attempt, not a cited scattering theorem or a completed proof.

1. Choose an isolated exact mass eigenvalue \(M\) and a compact patch of the continuous joint \((H,P)\) spectrum on which the projection to lattice momentum is one-to-one. Set \(k=P/\beta\); the shell energy is \(E_M(k)=\sqrt{M^2+\beta|k|^2}\). The projection includes the stated centre phase and reduction modulo \(2\pi\). Work on this patch only; do not assume a globally smooth isolated Bloch band.
2. For a local observable \(A\), attempt a joint spectral filter
   \[
   B=\int_{\mathbb R\times\mathbb R^d}g(s,y)\,
       \alpha_s^H\rho_y(A)\,ds\,dy,
   \qquad \rho_y=\operatorname{Ad}e^{-iy\cdot P/\beta},
   \]
   where \(g\) is Schwartz and its Fourier transfer support isolates that shell patch. Prove, using the actual microscopic implementations and LR estimates, that \(B\) is almost local and \(B\Omega\) lies in the desired one-particle subspace. Joint \((H,P)\) isolation must be checked; lattice momentum alone does not remove the folded-tower continuum overlap. Failure to isolate the patch is a real failure of this route and should be retained.
3. Form creation packets using **geometric lattice shifts** \(\tau_x\) of \(B\), time evolution by \(H\), and the lifted patch dispersion, with Fourier signs fixed so the packet's one-particle vector is independent of time. Choose two compact, disjoint group-velocity supports. Derive an integrable Cook bound, first for two packets and then, if justified, for finite products:
   \[
   \left\|\frac{d}{dt}B_{1,t}(f_1)\cdots B_{n,t}(f_n)\Omega\right\|
       \le C(1+|t|)^{-1-\epsilon},\qquad \epsilon>0.
   \]
   Preserve the actual commutator/localization estimates, dependence on the compact supports, and the proof that the limit depends only on the one-particle vectors. Fixed-parameter almost locality and oscillatory separation must justify the bound; a presumed continuous spatial geometry is not a substitute.
4. Apply \(\operatorname{Ad}V_j\) to these same creators and limits. Its commutation with \(H\), the lattice translations, and the joint filters, together with almost locality at fixed \(j\), should give the covariance used above if the construction succeeds. Check this explicitly before asserting product phases.

The choice of geometric shifts in step 3 is deliberate. A finite-time flow generated by the local current \(P\) preserves quasi-locality, but that fact does not make \(\rho_y(A)\) localized near the geometric point \(y\). It can merely spread around the original support as \(|y|\) grows. M1's proposed use of the quasi-local translations \(e^{-iaP/\beta}\) therefore needs an actual separation argument. The joint filter followed by geometric packets is a concrete way to test whether the folded tower can be treated without assuming that unproved spatial property.

Success would supply scattering existence and covariance on the channels actually constructed; isometry would additionally need its clustering/inner-product argument. None of these proves (EX). The remaining decisive step would be a propagation or asymptotic-detector exhaustion proof for every finite-energy vector created by a local observable. A genuine counterexample to (SC) would require a nonzero vector orthogonal to all such scattering states in a model meeting the other stated microscopic premises. An abstract extra sector, failure of one Cook estimate, or an unproved absence of particles would not meet that standard.

## Choice of target and recovery decision

B1-U and M1's bounded-sector theorem do not supply the missing step: their boundedness hypothesis fails on a complete nontrivial boost-invariant mass hyperboloid, as N1 lines 151–154 observe. The compact-patch proposal above uses local spectral information and does not promote it to a bounded boost-invariant sector. The folded tower also prevents assuming the global isolated-band hypothesis merely to reuse a Bloch-band obstruction.

Rational centres with a common denominator remain an independent supplied restriction. This report holds that restriction fixed; it does not claim the microscopic axioms force it or settle irrational centres. Integrated exact closure and the current's microscopic implementation also remain supplied. They are not established physical laws by virtue of the index contradiction.

The next research decision is therefore to attempt the compact-patch construction with explicit localization estimates, while retaining **full-GNS exhaustion (EX)** as the unresolved terminal obligation. If a valid constructive complete scattering theory is independently supplied, the conditional bridge already reaches the checked index contradiction. If only particle-sector scattering is available, the full-algebra identity remains unavailable.

Only this new Markdown assessment was written. No repository file, editable prompt, author packet, accepted review artifact, or receipt was changed. No numerical run, PR action, audit action, other-chat message, model override, or subdelegation was used. Campaign deadline retained: 2026-10-12 16:00:52 UTC.
