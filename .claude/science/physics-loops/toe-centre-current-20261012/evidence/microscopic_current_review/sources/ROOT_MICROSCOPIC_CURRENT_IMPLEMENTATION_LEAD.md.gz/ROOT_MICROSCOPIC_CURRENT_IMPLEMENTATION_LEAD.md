# Proposed microscopic current identification route

Root proposal, 2026-10-12. This is an unverified proof sketch, not a theorem,
an independent review or a new physical axiom. A worker may refute it. The
purpose is to replace a vaguely stated implementation premise by precise
local-domain hypotheses and a proved consequence, if possible.

The existing INDEX_TO_PHYSICS_NEXT_OBLIGATION.md deliberately leaves the
identification of integrated P_b with the finite-range energy current supplied.
N1 H-loc displays a formal current density; formal sums alone do not establish
unitary implementation. Check whether the following closes that identification
once the exact local action of the first-moment boost is supplied. Do not claim
that H-cov alone implies that local action or its domains.

## Candidate hypotheses

Use a finite-dimensional spin algebra on Z^d, h_x=tau_x(h_0)=h_x*,
supp h_x contained in x+B_R and ||h_x||<=h. The finite-range H dynamics is
implemented in an invariant cyclic GNS representation by self-adjoint H.
Let D=pi(A_loc)Omega. Suppose a self-adjoint first-moment boost B_b and the
self-adjoint integrated momentum P_b satisfy H Omega=B_b Omega=P_b Omega=0,
D is in their necessary domains, and on D

    i[H,A]Omega = delta_H(A)Omega,
    i[B_b,A]Omega = delta_B(A)Omega,
    P_b psi = i(H B_b - B_b H)psi,

where delta_H(A)=i sum_x[h_x,A] and
delta_B(A)=i sum_x x_b[h_x,A]. Each local commutator sum is finite.
Show exactly which domain inclusion/invariance follows from these local-action
formulas. State any extra assumptions rather than deriving them from notation.
No vacuum separation is available. H>=0, a gap or scattering should not be
needed for the implementation lemma once the invariant cyclic vector is given.

## Candidate finite-range reduction

The Jacobi identity suggests [delta_H,delta_B]=delta_p on local A, with

    p_b(x) = (i/2) sum_r r_b [h_x,h_(x+r)],
    delta_p(A) = i sum_x [p_b(x),A].

Only |r|<=2R contributes (choose and fix a metric). Thus p_b(x) is a
self-adjoint translation-covariant density of radius at most3R, with
||p_b(x)|| <= h^2 sum_(|r|<=2R)|r_b|.
Check signs against P=i[H,B], the +itH physical clock and the repo's
negative-time current clock Ad exp(-isP). All pair symmetrizations must be
justified after local commutation; do not rearrange divergent global sums.
An additional finite-range improvement is allowed only if its matching local
action is separately supplied and the interaction norm is updated.

## Candidate uniqueness/implementation argument

For a finite-range interaction Psi with each term supported on at most s sites,
J=sup_z sum_(X contains z)||Psi(X)||, connected nested commutators suggest

    ||delta_Psi^n(A)|| <= ||A||(2J)^n
        product_(k=0..n-1)(|supp A|+k(s-1)).

The proof must count each nested support union, not the whole radius-n ball.
This should give a positive convergence radius independent of the local
support size; handle s=1 and J=0 explicitly. If P A Omega=-i delta_p(A)Omega
and D is invariant, the same bound controls P^n A Omega.

There may be no need to import Nelson's theorem: because P is already
self-adjoint, Taylor's integral remainder bounds the vector exponential by
|t|^n||P^n A Omega||/n!, while the finite-volume microscopic flows have the
same local Taylor coefficients and a uniform bound. Obtain, for small |t|,

    exp(itP) A Omega = alpha_t^p(A)Omega.

This should establish state invariance for that microscopic flow, first for
small t and then all t. Its canonical GNS unitary then agrees on the dense
local cyclic set with exp(itP), hence agrees as an operator, and the group
law extends the equality to every t. Finally obtain the full-algebra
implementation by acting on dense cyclic vectors, not just the vacuum column.
Check the finite-volume-to-infinite-flow step and every uniform radius claim.
An alternative proof using analytic vectors is welcome only with its exact
primary theorem and all hypotheses checked.

## Acceptance and limits

A useful result is a complete conditional implementation lemma, or an exact
counterexample/domain obstruction. Distinguish the formal Jacobi identity,
the local-vector relation, and the full automorphism statement. Identify
which S1/index premises it supplies and which remain independent. It does
not construct a Poincare representation, a boost, particles, physical
dynamics, a vacuum or completeness from the repo's axioms. No change to
those axioms or silent reinterpretation of the existing N1 report is allowed.

Finite controls, if helpful, should test actual noncommuting current signs,
translation of the first moment, adequate boundary padding and support-count
arithmetic; they cannot prove analytic domains or a thermodynamic limit.
Root supplied this mechanism and is a coauthor. A fresh independent proof
check will be needed before publication or extensive downstream use.
