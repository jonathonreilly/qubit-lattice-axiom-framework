"""Expose declared proof dependencies to the existing link-based citation graph."""
from pathlib import Path
import gzip,hashlib,json,subprocess,sys,os,time
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree';P=W/'.claude/science/physics-loops/toe-centre-current-20261012'
R=S/'centre_current_packaging_recovery';sha=lambda b:hashlib.sha256(b).hexdigest()
mapping=json.loads((P/'PUBLICATION_EDITS.json').read_text());row=mapping['outputs'][0]
note=W/row['publication_path'];assert sha(note.read_bytes())==row['publication_sha256']
for p in [P/'PUBLICATION_EDITS.json',note,S/'Centre_canonical_execution.json',S/'centre_current_citation_execution.json',S/'centre_current_focused_audit_compat.json',W/'docs/audit/data/citation_graph_manifest.json']:
    (R/(p.name+'.before_link_fix.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
old='The following sources are unchanged. Labels SC, F and C refer to their displayed equations or sections.'
new='The in-branch proof dependencies are [compact creators](COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md), [Fock isometry](COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md) and [detector convergence](COMPACT_DETECTOR_CONVERGENCE_BOUNDED_THEOREM_NOTE_2026-10-12.md). The following frozen sources are unchanged. Labels SC, F and C refer to their displayed equations or sections.'
edit=next(x for x in row['edits'] if x['reason']=='Provide portable recovery path.');assert edit['after'].count(old)==1
edit['after']=edit['after'].replace(old,new);edit['reason']='Provide portable recovery path and explicit links for the already declared proof dependencies.'
raw=gzip.decompress((P/row['preserved_source']).read_bytes()).decode()
for e in row['edits']:assert raw.count(e['before'])==1;raw=raw.replace(e['before'],e['after'],1)
raw+=row['appended_text'];note.write_text(raw);row['publication_sha256']=sha(raw.encode())
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(mapping,indent=2)+'\n')
prepare=S/'prepare_centre_current_publication.py';before=prepare.read_text();(R/'prepare.before_link_fix.py').write_text(before)
needle="The following sources are unchanged. Labels SC, F and C refer to their displayed equations or sections.','Provide portable recovery path.')"
assert before.count(needle)==1
prepare.write_text(before.replace(needle,new+"','Provide portable recovery path and explicit links for the already declared proof dependencies.')"))
(R/'citation_failure.json').write_text(json.dumps(dict(tool_chunk='4bd0b5',exit=1,reason='Centre frontmatter declared three dependencies, but the existing citation graph recognized document links; initial graph had two nodes and zero new edges. Add portable links for those exact already declared proofs; no mathematical change.',old_note_sha256='0cfc72a0faf7f9371e82fe922d3d2c5017435323343215d4501340c80f687ff6',new_note_sha256=row['publication_sha256']),indent=2)+'\n')
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
cmd=[sys.executable,'scripts/vocab_lint.py','--fix','--report-path',str(S/'centre_link_vocab_fix.json'),str(note.relative_to(W))]
r=subprocess.run(cmd,capture_output=True,timeout=60);(S/'centre_link_vocab_fix.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
assert sha(note.read_bytes())==row['publication_sha256']
assert subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60).returncode==0
e,cache=runner_cache.execute_and_write_cache('scripts/isolated_centre_filtering_2026_10_12.py',60)
old_e=json.loads(gzip.decompress((R/'Centre_canonical_execution.json.before_link_fix.gz').read_bytes()))
assert e['stdout']==old_e['stdout'] and e['status']=='ok' and e['exit_code']==0 and not e['stderr']
(S/'Centre_canonical_execution.json').write_text(json.dumps(e,indent=2)+'\n')
records={}
for name,cmd in [('build',[sys.executable,'docs/audit/scripts/run_citation_graph_build.py']),('manifest',[sys.executable,'docs/audit/scripts/write_citation_graph_manifest.py'])]:
    for ext in ['stdout','stderr']:
        p=S/f'centre_current_citation_{name}.{ext}';(R/(p.name+'.before_link_fix.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=180)
    (S/f'centre_current_citation_{name}.stdout').write_bytes(r.stdout);(S/f'centre_current_citation_{name}.stderr').write_bytes(r.stderr)
    records[name]=dict(command=cmd,timeout_seconds=180,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
    (S/'centre_current_citation_execution.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
cmd=[sys.executable,'docs/audit/scripts/check_changed_audit_evidence.py','--base','f6f4348151734908dea3b32048ee1f36f694035b','--include-worktree','--json']
start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=120)
(S/'centre_current_focused_audit_compat.json').write_bytes(r.stdout);(S/'centre_current_focused_audit_compat.stderr').write_bytes(r.stderr)
(S/'centre_current_focused_audit_compat.execution.json').write_text(json.dumps(dict(command=cmd,timeout_seconds=120,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode),indent=2)+'\n');assert r.returncode==0
print(json.dumps(dict(note_sha256=row['publication_sha256'],canonical_seconds=e['elapsed_sec'],citation=records)))
