"""Run the actual two publication primaries and bounded source defects once."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,os,subprocess,sys,time
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree';P=W/'.claude/science/physics-loops/toe-centre-current-20261012'
BASE='f6f4348151734908dea3b32048ee1f36f694035b'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest();js=lambda p:json.loads(p.read_text())
rows=js(P/'PUBLICATION_EDITS.json')['outputs'];specs=js(S/'centre_current_specs.json')
editable=[W/r['publication_path'] for r in rows]+list(P.glob('*.md'))+[P/'reconstruct.py']
prefix=S/'centre_current_initial_vocab_fix'
r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--fix','--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
prefix.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
report=js(prefix.with_suffix('.json'));assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'centre_current_initial_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
M=S/'centre_current_primary_mutations';M.mkdir(exist_ok=False);runs=[];canonical={}
for sp in specs:
 path='scripts/'+sp['runner'];body=(W/path).read_text();compile(body,path,'exec')
 result,cache=runner_cache.execute_and_write_cache(path,60)
 (S/f'{sp["key"]}_canonical_execution.json').write_text(json.dumps(result,indent=2)+'\n')
 assert result['status']=='ok' and result['exit_code']==0 and not result['stderr']
 canonical[sp['key']]=result
 if sp['key']=='Centre':
  old=(S/'isolated_centre_filtering/finite_controls.stdout').read_text()
  assert result['stdout'].startswith(old) and len(result['stdout'][len(old):].splitlines())==2
  tree=ast.parse((S/'isolated_centre_review/run_author_mutations.py').read_text())
  defs=next(ast.literal_eval(x.value) for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutations' for t in x.targets))
 else:
  out=result['stdout'].splitlines();old=(S/'microscopic_current_implementation/logs/finite_controls.final.jsonl').read_text().splitlines()
  assert out[:50]==old[:50] and len(out)==53
  summary=json.loads(out[50]);assert summary==dict(total_checks=50,failed_checks=0,runner_sha256=sha(body.encode()))
  assert not (W/'scripts/finite_controls_results.json').exists()
  defs=[(x['name'],x['replacement']['old'],x['replacement']['new'],False) for x in js(S/'microscopic_current_review/logs/author_mutation_summary.json')]
 for name,before,after,survives in defs:
  assert body.count(before)==1
  changed=body.replace(before,after,1);p=M/(sp['key']+'_'+name+'.py');p.write_text(changed)
  cmd=[sys.executable,str(p)];start=time.monotonic();utc=datetime.now(timezone.utc).isoformat()
  r=subprocess.run(cmd,capture_output=True,timeout=60)
  p.with_suffix('.stdout').write_bytes(r.stdout);p.with_suffix('.stderr').write_bytes(r.stderr)
  rec=dict(key=sp['key'],name=name,command=cmd,started_utc=utc,timeout_seconds=60,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode,before=before,after=after,primary_path=path,primary_sha256=sha(body.encode()),source_sha256=sha(changed.encode()),stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr),expected_survival=survives)
  p.with_suffix('.execution.json').write_text(json.dumps(rec,indent=2)+'\n');runs.append(rec)
  (M/'manifest.json').write_text(json.dumps(dict(runs=runs),indent=2)+'\n')
  assert r.returncode==(0 if survives else 1)
  if sp['key']=='Centre':
   if survives:assert r.stdout==result['stdout'].encode() and not r.stderr
   else:
    assert b'AssertionError' in r.stderr and result['stdout'].encode().startswith(r.stdout)
    assert r.stderr.decode().splitlines()[-1]==(S/'isolated_centre_review/mutations'/f'{name}.stderr').read_text().splitlines()[-1]
  else:
   assert not r.stderr
   output=r.stdout.decode().splitlines();expected=js(S/'microscopic_current_review/mutations'/name/'finite_controls_results.json')['results']
   assert [json.loads(x) for x in output[:50]]==expected
   summary=json.loads(output[50]);assert summary['runner_sha256']==sha(changed.encode()) and summary['failed_checks']==sum(not x['passed'] for x in expected)
assert len(runs)==16 and sum(x['expected_survival'] for x in runs)==1
records={}
for name,cmd in [('build',[sys.executable,'docs/audit/scripts/run_citation_graph_build.py']),('manifest',[sys.executable,'docs/audit/scripts/write_citation_graph_manifest.py'])]:
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=180)
 (S/f'centre_current_citation_{name}.stdout').write_bytes(r.stdout);(S/f'centre_current_citation_{name}.stderr').write_bytes(r.stderr)
 records[name]=dict(command=cmd,timeout_seconds=180,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
 (S/'centre_current_citation_execution.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
cmd=[sys.executable,'docs/audit/scripts/check_changed_audit_evidence.py','--base',BASE,'--include-worktree','--json']
start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=120)
(S/'centre_current_focused_audit_compat.json').write_bytes(r.stdout);(S/'centre_current_focused_audit_compat.stderr').write_bytes(r.stderr)
(S/'centre_current_focused_audit_compat.execution.json').write_text(json.dumps(dict(command=cmd,timeout_seconds=120,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode),indent=2)+'\n');assert r.returncode==0
print(json.dumps(dict(canonical_seconds={k:v['elapsed_sec'] for k,v in canonical.items()},primary_mutants=16,intended_failures=15,nondiscriminating_passes=1,citation=records)))
