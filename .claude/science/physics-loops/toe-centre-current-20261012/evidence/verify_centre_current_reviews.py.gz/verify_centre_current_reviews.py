"""Read-only provenance checks after complete root proof/control inspection."""
from pathlib import Path
from datetime import datetime, timezone
import ast, difflib, hashlib, json, subprocess

S=Path(__file__).resolve().parent; W=S.parent/'scattering_worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda p:json.loads(p.read_text())
def check(row,base=S):
    p=Path(row['path']);p=p if p.is_absolute() else base/p
    b=p.read_bytes();assert sha(b)==row.get('sha256',row.get('expected_sha256')),(p,'hash')
    n=row.get('bytes',row.get('expected_bytes'))
    if n is not None:assert len(b)==n,(p,'bytes')
    return str(p)

C=S/'isolated_centre_review';M=S/'microscopic_current_review'
c=js(C/'receipt.json');m=js(M/'receipt.json')
for row in c['outputs']:check(row)
for k in ['target','author_receipt','pre_author_freeze','pre_author_control_v2_freeze','source_manifest']:check(c[k])
for row in js(C/'FINAL_SOURCE_MANIFEST.json')['sources']:
    check({**row,'path':row['copy']})
    if 'path' in row:check(row)
    else:
        b=subprocess.check_output(['git','show',row['git_revision']+':'+row['git_path']],cwd=W)
        assert sha(b)==row['sha256']
for row in js(C/'pre_author_freeze.json')['files']:check(row)
check(js(C/'pre_author_control_v2_freeze.json'))
for row in m['files']:check(row)
for row in js(M/'source_manifest.initial.json')['items']:
    check({**row,'path':row['copy']})
    src=row['source']
    b=Path(src).read_bytes() if src.startswith('/') else subprocess.check_output(['git','show',src],cwd=W)
    assert sha(b)==row['sha256']
for row in js(M/'source_manifest.final_verification.json')['checks']:check(row)
for row in js(M/'independent_freeze.json')['items']:check(row,M)

# The prior complete author reads remain valid at unchanged source identities.
assert sha((S/'ISOLATED_CENTRE_FILTERING_PROBE.md').read_bytes())=='1dcb9580d128d8fc41b76517ce0fe18842291e8e32681fa9c6b22f0feb1e13de'
assert sha((S/'MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md').read_bytes())=='bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a'
assert (C/'logs/author_finite_reproduction.stdout').read_bytes()==(S/'isolated_centre_filtering/finite_controls.stdout').read_bytes()
assert not (C/'logs/author_finite_reproduction.stderr').read_bytes()
assert (M/'logs/author_replay.stdout.jsonl').read_bytes()==(S/'microscopic_current_implementation/logs/finite_controls.final.jsonl').read_bytes()
assert not (M/'logs/author_replay.stderr.txt').read_bytes()

tree=ast.parse((C/'run_author_mutations.py').read_text())
defs=next(ast.literal_eval(x.value) for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutations' for t in x.targets))
base=(S/'isolated_centre_filtering/check_filter_algebra.py').read_text()
cm=[]
for label,old,new,survive in defs:
    assert base.count(old)==1
    p=C/'mutations'/f'{label}.py';assert p.read_text()==base.replace(old,new)
    r=js(C/'mutations'/f'{label}.execution.json')
    assert sha(p.read_bytes())==r['source_sha256']
    for ext in ['stdout','stderr']:
        b=(C/'mutations'/f'{label}.{ext}').read_bytes();assert sha(b)==r[ext+'_sha256']
    assert r['returncode']==(0 if survive else 1) and not r['timed_out']
    original=(S/'isolated_centre_filtering/finite_controls.stdout').read_bytes()
    assert original.startswith((C/'mutations'/f'{label}.stdout').read_bytes())
    cm.append(dict(label=label,before=old,after=new,exit=r['returncode'],survives=survive))
base=(S/'microscopic_current_implementation/finite_controls.py').read_text();mm=[]
for r in js(M/'logs/author_mutation_summary.json'):
    old,new=r['replacement']['old'],r['replacement']['new'];assert base.count(old)==1
    d=M/'mutations'/r['name'];assert (d/'finite_controls.py').read_text()==base.replace(old,new)
    assert sha((d/'finite_controls.py').read_bytes())==r['source_sha256']
    q=js(d/'finite_controls_results.json');failed=[x['name'] for x in q['results'] if not x['passed']]
    assert failed==r['failed_predicates'] and r['exit_code']==1
    mm.append(dict(name=r['name'],before=old,after=new,failed_predicates=failed))

now=datetime.now(timezone.utc).isoformat()
common=dict(utc=now,review_accepted=True,root_role='Contributor, not independent reviewer',
    full_reads=['Complete frozen author proof and helper in prior author coverage','Complete final independent review and reconstruction','Complete separate control, all numerical output rows, control assessment and operational history','Literal mutation changes, full failure evidence and known nondiscriminating cases'],
    limits=['Finite controls do not prove analytic limits or physical realization','No Lean certificate, applied audit verdict, global audit pipeline or strict audit lint'])
co={**common,'receipt_sha256':sha((C/'receipt.json').read_bytes()),'review_sha256':sha((S/'ISOLATED_CENTRE_FILTERING_REVIEW.md').read_bytes()),
    'review_outputs':len(c['outputs']),'additional_receipt_bindings':5,'source_pairs':62,'prefreeze_bindings':6,'mutation_checks':cm,
    'specific_limits':['Initial finite Fourier truncation failed; refinement preserved tolerance','Dropped-positive-shift radius inequality survives; proof includes actual shift','Broad search is not a novelty proof']}
mo={**common,'receipt_sha256':sha((M/'receipt.json').read_bytes()),'review_sha256':sha((S/'MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md').read_bytes()),
    'review_outputs':len(m['files']),'initial_source_pairs':9,'author_freshness_bindings':len(js(M/'source_manifest.final_verification.json')['checks']),'prefreeze_bindings':2,'mutation_checks':mm,
    'specific_limits':['Author historical executions lack per-run elapsed/timeout metadata; reviewer executions record both','Contiguous a=3 history fixture does not reject omitted growth','Vacuum column mutant is independently rejected on full algebra']}
for label,out in [('Centre',co),('Current',mo)]:
    (S/f'{label}_root_review_coverage.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['full_reads','mutation_checks','limits','specific_limits']}))
