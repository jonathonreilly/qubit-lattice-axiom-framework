# Chain binding source v3: final-wrapper LF repair

This is a source-only repair for root review. The proposed builder and primary helper have not been run, imported or compiled by this worker. Root's actual first v2 builder run failed, and its complete source, receipt and streams are preserved here. V1, v2, accepted mathematical sources, actual binding inputs and the science checkout remain unchanged.

Read the short `V2_TO_V3.diff`, then the complete affected functions `build()` in `build_bound_source.py` and `verify()` in `identity_runner.template.py`. Their whole current source and exact old/current function intervals are supplied by `SOURCE_MAP.json`. The rest of the operational contract is unchanged from the complete v2 guide preserved at `repair_evidence/v2_source/READ_GUIDE.md`.

## Actual failure and precise scope

The failed root run began at 2026-10-14T22:31:24.144164+00:00 and ended at 22:31:24.467086+00:00, exit 1. Its executed builder is exactly v2 `bc2e31e868d75b2faa4256cd286faecdec7347690cbbeb437f095aaec4bcbf2f`. Stdout is empty. The complete stderr contains a nonfatal invalid-escape `SyntaxWarning` followed by `ValueError: Final wrapper must end in LF` at builder line 148. No successful output is claimed. The v2 `outputs/bound_source_01` path was also observed absent during this repair's evidence capture.

The accepted original SUFFIX has one trailing LF. Its final paragraph is selected by splitting on two LFs, so that selected string includes the final LF. Replacing the entire paragraph with new prose removes it. The v2 assumption that the resulting wrapper already had at least one LF was therefore false. This was a packaging defect, not a scientific failure. The v2 source acceptance authorized an actual-binding run; it did not establish successful execution.

For the new SUFFIX string `s`, let `n = len(s) - len(s.rstrip('\n'))`. V3 records an EOF change whenever `n != 1`, including `n = 0`, and constructs `s.rstrip('\n') + '\n'`. It never uses `s[:-0]`. The helper independently obtains the actual maximal LF tail by `s[len(s.rstrip('\n')):]`, requires the recorded tail to equal it exactly, requires a SUFFIX-only change to one LF, and uses the same explicit normalization. For zero LFs the tail is the empty string, so all original characters survive and one LF is appended. One LF needs no recorded edit. Two or more LFs are replaced by one. No raw mathematical interval is normalized.

The only additional program change is the archival role description from “current v2 source” to “current source and immutable repair evidence.” The nonfatal regular-expression warning is preserved without an unrelated repair. Receipt guards, literal paths, 60-second timeout, five identity-only scope lines, de7/79d extraction, sole theorem-parent role, gzip format, all proof hashes and the sealed-v1 archive contract are unchanged.

## Immutable repair evidence

`REPAIR_EVIDENCE_MAP.json` supplies the original path, stored path, size and SHA-256 for every exact copy:

- All eight files of sealed v2, including freeze `f4140abb3d7161259dddc790bdcb534db408ac4b1c5bb55e1e6d9b0d360c3a50` and its complete v1-to-v2 diff.
- All four files of the actual failed run: executed source, `EXECUTION.json`, complete stdout and complete stderr.
- The exact recorder source matching the failed receipt.
- Root's actual `BINDING_SOURCE_ROOT_ACCEPTANCE.json`, which predates the failed run.

Every member is included in this v3 freeze. When root later runs the proposed builder, its unchanged current-source archival loop wraps this entire source tree, including repair evidence, in the existing explicit `.gz` representation. The primary helper reconstructs the complete current freeze as before. Original evidence bytes are not cleaned, shortened or silently regenerated. No historical input-at-launch hashes are invented: the failed receipt's actual recorded fields retain their original limits.

## Root-owned next execution

Root can use the existing real binding and parent inputs after complete v3 source review. The required command arguments remain:

```text
python3 build_bound_source.py
  --binding /absolute/path/to/actual_binding.json
  --parent /absolute/path/to/actual_parent_note.md
  --source-freeze-sha ACTUAL_V3_FINAL_FREEZE_SHA256
  --output-name bound_source_01
```

Output is confined to a fresh `outputs/<name>/` under this v3 directory. A previous result is never overwritten. The null binding template remains deliberately unusable. Root owns actual execution recording, canonical integration, whitespace checks, cache/graph checks, staging and publication. This source handoff supplies no runtime-success, theorem, native-realization or audit verdict.

The worker performed only source/evidence reads, exact copying, hashes, text edits, inventories and diff bookkeeping. No proposed program was run, imported or compiled, and no science program or fixture was run. No Git, checkout, graph, cache, PR, checkpoint, physical axiom or editable prompt was changed.
