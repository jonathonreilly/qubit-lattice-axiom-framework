#!/usr/bin/env python3
"""Source identities only: no archived program, theorem, operator or mathematical test is executed."""
from pathlib import Path, PurePosixPath
import difflib, gzip, hashlib, json, posixpath, re, sys

AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = __AUDIT_INPUT_PATHS__
MANIFEST_SHA = __MANIFEST_SHA__
NOTE='docs/CHAIN_PREPARATION_MOMENT_SCALING_BOUNDED_THEOREM_NOTE_2026-10-14.md'
PARENT='docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md'
PACKET='.claude/science/physics-loops/toe-chain-preparation-scaling-20261014'
CLAIM='chain_preparation_moment_scaling_bounded_theorem_note_2026-10-14'
SOURCE_SHA='659b6e517f8fff8939447a25b7539f97f6cefbeb8d7b41acfcbff5e4c941776f'
ACCEPTANCE_SHA='a2d2310ca5ff409cbbaf7ea01df2e73e8957d0c2e4347879dcb538df24e24aaa'
PRIOR_SHA='3b739e10f598dc4d9dbb837f827291a886e9a3edd09ed8227c36b80c9fe57a41'
CORES=('de7e79161faf1c35941285c9670e9cc421f798c51204da139575c36870ab9976','79d2388a7f6e2ce36d8b1055bd2ad80149a9e5375ff7f23248391d72bf5692ff')

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def pointer(value,path):
    need(path.startswith('/'),'Invalid receipt pointer')
    for key in path[1:].split('/'):
        key=key.replace('~1','/').replace('~0','~');value=value[int(key)] if isinstance(value,list) else value[key]
    return value
def verify(root):
    root=root.resolve();reads={}
    def read(name):
        p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'Unsafe declared path')
        f=root.joinpath(*p.parts)
        need(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(root),'Missing or unsafe input: '+name)
        if name not in reads:reads[name]=f.read_bytes()
        return reads[name]
    def packet(name):return read(PACKET+'/'+name)
    manifest_raw=packet('IDENTITY_MANIFEST.json');need(sha(manifest_raw)==MANIFEST_SHA,'Identity manifest changed')
    manifest=json.loads(manifest_raw);members=manifest['members']
    need(len(AUDIT_INPUT_PATHS)==len(set(AUDIT_INPUT_PATHS)) and set(AUDIT_INPUT_PATHS)==set(members)|{PACKET+'/IDENTITY_MANIFEST.json'},'Literal declared input closure changed')
    for name,p in members.items():
        b=read(name);need(len(b)==p['bytes'] and sha(b)==p['sha256'],'Declared byte identity changed: '+name)
    archive_map=json.loads(packet('ARCHIVE_MAP.json'));archives=archive_map['members'];decoded={}
    def original(name):
        entry=archives[name];need(entry['encoding']=='gzip' and entry['stored_path']==PACKET+'/'+name+'.gz','Archive mapping changed')
        stored=read(entry['stored_path'])
        need(len(stored)==entry['stored_bytes'] and sha(stored)==entry['stored_sha256'],'Compressed representation changed')
        if name not in decoded:decoded[name]=gzip.decompress(stored)
        b=decoded[name];need(len(b)==entry['decoded_bytes'] and sha(b)==entry['decoded_sha256'],'Decoded original changed')
        return b
    for name in archives:original(name)
    def source(name):return original('source/'+name)
    def archived_group(prefix,expected_sha,expected_count):
        freeze=original(prefix+'/FINAL_FREEZE.json');need(sha(freeze)==expected_sha,'Archived source freeze changed')
        old=json.loads(freeze);old_names={r['path'] for r in old['members']}|{'FINAL_FREEZE.json'}
        mapped={n[len(prefix)+1:] for n in archives if n.startswith(prefix+'/')}
        actual={str(p.relative_to(root/PACKET/prefix)) for p in (root/PACKET/prefix).rglob('*') if p.is_file()}
        need(mapped==old_names and actual=={n+'.gz' for n in old_names} and len(mapped)==expected_count,'Complete archived group membership changed')
        need(archive_map['groups'][prefix]=={'final_freeze_sha256':expected_sha,'complete_files':expected_count},'Archive group metadata changed')
        for r in old['members']:
            b=original(prefix+'/'+r['path']);need(len(b)==r['bytes'] and sha(b)==r['sha256'],'Decoded frozen member changed')
    archived_group('source',SOURCE_SHA,452)
    archived_group('prior_binding_source',PRIOR_SHA,7)
    need(sha(original('COMPONENT_ROOT_ACCEPTANCE.json'))==ACCEPTANCE_SHA,'Component acceptance changed')
    binding=json.loads(packet('ACTUAL_BINDING.json'));facts=binding['facts']
    need(binding['prior_binding_source_freeze_sha256']==PRIOR_SHA,'Sealed v1 source binding changed')
    own=json.loads(original('binding_source/FINAL_FREEZE.json'))
    archived_group('binding_source',binding['source_binding_builder_freeze_sha256'],len(own['members'])+1)
    need(facts==json.loads(original('ACTUAL_BINDING_INPUT.json'))['facts'],'Actual binding input differs')
    need(binding['component_freeze_sha256']==SOURCE_SHA and binding['component_acceptance_sha256']==ACCEPTANCE_SHA,'Binding source status changed')
    parent=read(PARENT);need(parent==original('observed_parent.md') and sha(parent)==facts['parent']['canonical_sha256']==binding['parent_sha256'],'Actual canonical parent differs from dated bytes')
    need(facts['parent']['canonical_path']==PARENT and facts['parent']['state']=='OPEN' and facts['parent']['is_draft'] is False,'Dated regular-parent observation changed')
    need(facts['child']['clean'] is True and facts['child']['head_sha']==facts['child']['base_head_sha']==facts['parent']['head_sha'],'Dated clean-child observation changed')
    covered=set()
    for e in binding['evidence']:
        b=original(e['path']);need(len(b)==e['bytes'] and sha(b)==e['sha256'],'Receipt source changed')
        obj=json.loads(b)
        for target,origin in e['matches'].items():
            actual=pointer(obj,origin);wanted=pointer(facts,target)
            need(type(actual) is type(wanted) and actual==wanted,'Receipt facts differ');covered.add(target)
    required={'/parent/'+k for k in ['number','url','state','is_draft','head_ref','head_sha','observed_utc']}|{'/child/'+k for k in ['branch','head_sha','base_head_sha','tree_sha','clean','observed_utc']}
    need(required<=covered,'Incomplete parent/child receipt coverage')
    need([r['sha256'] for r in binding['parent_maps']]==list(CORES),'Actual theorem-clause roles changed')
    for r in binding['parent_maps']:
        core=original(r['source']);need(sha(core)==r['sha256'] and len(core)==r['bytes'],'Relied parent source changed')
        need(parent[r['byte_start_0']:r['byte_end_exclusive']]==core and parent.count(core)==1 and r['body_edits']==[],'Complete parent theorem extraction changed')
    body=json.loads(packet('BODY_MAP.json'));old_map=json.loads(source('payload/BODY_MAP.json'))
    rendering=json.loads(packet('PUBLICATION_RENDERING.json'));edits={r['label']:r for r in rendering['framing_edits']}
    need(len(body['parts'])==len(old_map['parts']) and body['mathematical_body_edits']==rendering['proof_edits']==[],'Publication scope changed')
    result=[body['frontmatter'].encode()];before_storage=[result[0]];cursor=len(result[0]);note=read(NOTE)
    for source_part,r in zip(old_map['parts'],body['parts']):
        need(all(r[k]==v for k,v in source_part.items()),'Original interval map was changed')
        complete=source(r['origin']);need(sha(complete)==r['source_sha256'],'Relied complete source differs')
        raw=complete[r['source_byte_start_0']:r['source_byte_end_exclusive']]
        need(sha(raw)==r['body_sha256'],'Relied source interval differs')
        b=raw
        if r['kind']=='new_framing':
            s=raw.decode();edit=edits[r['label']];need(sha(raw)==edit['original_sha256'],'Original framing differs')
            for e in edit['changes']:
                if 'before' in e:
                    need(s.count(e['before'])==1,'Ambiguous framing replacement');s=s.replace(e['before'],e['after'],1)
                else:
                    a=']('+e['before_target']+')';c=']('+e['after_target']+')'
                    need(s.count(a)==e['occurrences'],'Link relocation count changed');s=s.replace(a,c)
            need(sha(s.encode())==edit['pre_storage_sha256'],'Pre-storage framing differs');before_storage.append(s.encode())
            for e in edit['storage_changes']:
                if 'ending_before' in e:
                    tail=e['ending_before'];actual_tail=s[len(s.rstrip('\n')):]
                    need(r['label']=='SUFFIX.md' and isinstance(tail,str) and set(tail)<={'\n'} and len(tail)!=1 and tail==actual_tail and e['ending_after']=='\n','Invalid final-wrapper-only LF repair')
                    s=s.rstrip('\n')+'\n'
                else:
                    a=']('+e['before_target']+')';c=']('+e['after_target']+')'
                    logical=posixpath.normpath(posixpath.join('docs',e['before_target']))
                    need(logical.startswith(PACKET+'/') and logical[len(PACKET)+1:] in archives and e['after_target']==e['before_target']+'.gz','Invalid gzip-only link repair')
                    need(s.count(a)==e['occurrences'],'Gzip link count changed');s=s.replace(a,c)
            b=s.encode();need(b==original('rendered_framing/'+r['label']) and sha(b)==edit['rendered_sha256'],'New framing does not reconstruct')
        else:
            need(note.count(raw)==1,'Raw mathematical body changed or repeated');before_storage.append(raw)
        need(sha(b)==r['rendered_sha256'] and len(b)==r['rendered_bytes'],'Rendered interval differs')
        need(r['published_byte_start_0']==cursor and note[cursor:r['published_byte_end_exclusive']]==b,'Published interval differs')
        cursor=r['published_byte_end_exclusive'];result.append(b)
    need(b''.join(result)==note and cursor==len(note) and sha(note)==body['note_sha256'],'Complete note reconstruction differs')
    need(note.endswith(b'\n') and not note.endswith(b'\n\n'),'Final wrapper LF changed')
    prior_note=b''.join(before_storage)
    need(prior_note==original('PRE_STORAGE_NOTE.md') and sha(prior_note)==rendering['pre_storage_note_sha256'],'Complete pre-repair rendering differs')
    storage_delta=b''.join(difflib.diff_bytes(difflib.unified_diff,prior_note.splitlines(True),note.splitlines(True),fromfile=b'v1_rule_rendering',tofile=b'gzip_links_and_final_wrapper_LF'))
    need(storage_delta==original('STORAGE_RENDERING.diff'),'Full narrow storage/framing diff differs')
    old_note=source('payload/CANDIDATE_NOTE.md')
    delta=b''.join(difflib.diff_bytes(difflib.unified_diff,old_note.splitlines(True),note.splitlines(True),fromfile=b'accepted_unbound_note',tofile=b'bound_publication_rendering'))
    need(delta==original('PUBLICATION.diff'),'Complete publication diff differs')
    deps=json.loads(packet('DEPENDENCIES.json'));parent_role=deps['sole_direct_parent']
    need(parent_role['path']==PARENT and parent_role['sha256']==sha(parent) and parent_role['required_complete_raw_clauses']==list(CORES) and deps['expected_direct_edges']==1,'Sole direct theorem role changed')
    need(parent_role['claim_id']==facts['parent']['claim_id'] and note.decode().count(parent_role['markdown'])==1,'Actual parent citation changed')
    need(('upstream_dependencies: '+json.dumps([parent_role['claim_id']])+'\n').encode() in result[0],'Machine dependency field changed')
    links=[{'target':t,'resolved':posixpath.normpath(posixpath.join('docs',t.split('#',1)[0]))} for t in re.findall(r'\[[^\]]+\]\(([^)]+)\)',note.decode())]
    need(links==json.loads(packet('LINK_MAP.json'))['links'] and sum(r['resolved']==PARENT for r in links)==1,'Complete note link map differs')
    need(all(r['resolved'] in members for r in links),'Unpinned current note link')
    need(set(reads)==set(AUDIT_INPUT_PATHS),'Declared runtime read closure differs')
    return {'result':'source_identities_and_reconstruction_match','claim_id':CLAIM,'meaning':'Byte integrity and lossless archive decoding only; no mathematical theorem or audit was executed.','mathematical_predicates_executed':0,'scientific_programs_executed':0,'decoded_archival_originals':len(decoded),'original_component_files':452,'observations_are_dated':True,'actual_parent_live_state_queried':False}

def main():
    print(json.dumps(verify(Path(__file__).resolve().parents[1]),sort_keys=True))
    print('per_element: checked and not executed — source identities only; no operator algebra was evaluated.')
    print('per_site: checked and not executed — source identities only; no support or local-load calculation was evaluated.')
    print('per_mode: checked and not executed — source identities only; no physical-mode identification was evaluated.')
    print('per_block: checked and not executed — source identities only; no marginal or variance inequality was evaluated.')
    print('lattice_wide: checked and not executed — source identities only; no all-length or native theorem was verified.')
if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'result':'identity_verification_incomplete','error':str(error),'mathematical_predicates_executed':0,'scientific_programs_executed':0}),file=sys.stderr)
        raise SystemExit(1)
