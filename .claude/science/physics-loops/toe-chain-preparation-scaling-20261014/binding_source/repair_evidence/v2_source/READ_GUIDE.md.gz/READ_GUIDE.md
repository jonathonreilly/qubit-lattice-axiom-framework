# Chain binding source v2: complete reading and argument guide

This package contains proposed source programs only. Neither the builder nor the primary runner template has been executed, imported or compiled by this worker. No unbound/imaginary-parent fixture was created. Root owns every later program execution, integration check and publication action after reading the complete source. The source package itself is a compact immutable handoff, not an actual-parent binding.

Read `V1_TO_V2.diff`, then the whole changed `build()` and `verify()` functions in `build_bound_source.py` and `identity_runner.template.py`, this guide and the input template. Both complete programs are included; the unchanged functions remain readable in place. `SOURCE_MAP.json` supplies compact whole-file hashes and function locations; there is no large per-statement certificate to substitute for reading the programs. The output paths and all argument requirements are literal in the builder.

## Accepted inputs and required real observations

The builder reads the complete accepted 452-file component package at the sibling `chain_scaling_publication_components`, with freeze `659b6e517f8fff8939447a25b7539f97f6cefbeb8d7b41acfcbff5e4c941776f`. It verifies every file and refuses extra/missing files. It also verifies root component acceptance at `publication_integration/chain/COMPONENT_ROOT_ACCEPTANCE.json`, SHA `a2d2310ca5ff409cbbaf7ea01df2e73e8957d0c2e4347879dcb538df24e24aaa`. Those inputs are read only. This binding-source directory has its own final freeze; root passes that exact hash to prevent accidental use of a changed builder/template. V2 also reads and verifies all seven sealed v1 source files at sibling `chain_binding_source`, freeze `3b739e10f598dc4d9dbb837f827291a886e9a3edd09ed8227c36b80c9fe57a41`. The accepted components and sealed v1 are not changed.

Supply an actual binding JSON following `BINDING_INPUT.template.json` and a separate actual parent-note file. The null template is deliberately unusable. The parent canonical path is fixed by the task; PR number, URL, regular OPEN state, branch/head, claim identifier, full-note hash and observation time must be actual facts. The child must be a distinct clean branch observed at the same parent head/base, with an actual tree hash and observation time. No branch is created or queried by this builder.

Every dynamic parent/child fact must match a field in exact supplied receipt bytes. An `evidence` entry has `file` (a local receipt path), `bytes`, `sha256`, and `matches`. Each `matches` key is a JSON pointer into the binding's `facts`, and its value is a JSON pointer into that actual receipt. For example, when a real receipt uses a `pr.number` field, `/parent/number` can be matched to `/pr/number`; the builder does not assume any particular receipt schema. Cover every parent field except canonical path/hash/claim ID, and every child field. The excluded three are checked against the task-fixed path and the supplied parent bytes themselves. Boolean and numeric types must match exactly. Observation times must explicitly use UTC and cannot be in the future. Empty evidence, missing fields and null facts are refused before any output directory is created.

Receipt matching verifies consistency of supplied local evidence, not the truth of a remote state. Root remains responsible for actual repository/API observations and their combined head/tree/base guard. Both builder and helper label PR and clean-child facts as dated observations and make no live-state query. No claim is made that a formerly OPEN PR stays open indefinitely.

The parent note must contain each complete raw source exactly once: de7 `de7e79161faf1c35941285c9670e9cc421f798c51204da139575c36870ab9976` and 79d `79d2388a7f6e2ce36d8b1055bd2ad80149a9e5375ff7f23248391d72bf5692ff`. The extracted bytes are compared with the accepted archived originals. A wrapper hash alone is insufficient. An actual parent containing different body bytes is rejected; this program is not authority to repair the parent or relax its theorem identity.

## Exact proposed command and output boundary

After root source review and receipt preparation, the command shape is:

```sh
python3 build_bound_source.py \
  --binding /absolute/path/to/actual_binding.json \
  --parent /absolute/path/to/actual_parent_note.md \
  --source-freeze-sha ACTUAL_HASH_OF_THIS_PACKAGE_FINAL_FREEZE \
  --output-name bound_source_01
```

All output is confined to a fresh `outputs/<name>/` descendant of this assigned directory. The builder refuses an existing result and never deletes a partial failure. Root must preserve actual command/source/stdout/stderr/exit evidence when it executes the program. No source output exists in this package yet.

The future payload contains only the new canonical note, new primary helper and their packet subtree. The complete original 452-file package is represented exactly once under `.claude/science/physics-loops/toe-chain-preparation-scaling-20261014/source/`, with one deterministic lossless gzip layer and an explicit `.gz` suffix appended to every original path. It is not duplicated into another history tree. This includes already compressed originals: removing the new outer layer recovers their exact original compressed bytes, without interpreting them. Actual receipts, the observed parent note, the accepted component disposition, current v2 source and sealed seven-file v1 source are likewise stored as mapped `.gz` archives. The parent canonical note itself is an external read dependency, not installed or rewritten by the builder.

The proposed paths are:

- `docs/CHAIN_PREPARATION_MOMENT_SCALING_BOUNDED_THEOREM_NOTE_2026-10-14.md`
- `scripts/chain_preparation_moment_scaling_identity_2026_10_14.py`
- `.claude/science/physics-loops/toe-chain-preparation-scaling-20261014/`

## Rendering argument and source preservation

The source note's complete byte partition controls reconstruction. Only parts classified as new framing are changed. The complete e943 root argument, complete e734 independent argument and exact accepted comparison constant section retain their original bytes and occur once in the new note. Historical pending-review text inside those raw bodies remains unchanged and explicitly historical.

Two required refinements are literal, unique replacements: `full norm/scalar bound as M^7` becomes `full-space norm bound as M^7`; and the full old/reference marginal is described as a supplied certificate distinct from the separate epsilon_R cost. Current framing also states total defect `eta<=4M nu`, the P-Q/Q-Q distinction and the retained M^7 epsilon_R record allowance. None alters the accepted mathematical bodies or presents placement as new science.

The intended but unbound-parent paragraph becomes exactly one actual canonical preparation-note citation, with its de7/79d clause roles and dated parent/child observations. Be8 remains transitive. Existing source/metadata links are relocated only inside framing, and every rendered note link must resolve to a declared payload file or the actual parent. Complete before/after tuples, the full note diff, all source/published byte intervals and the new framing bytes are emitted. The original full note and all evidence remain in the frozen source subtree. V2 changes only the new wrapper further: archival link targets gain their explicit `.gz` suffixes, and the final SUFFIX wrapper ends with one LF. Every accepted raw mathematical interval stays exact. The full v1-rule rendering at the same actual binding facts and creation time is preserved as `PRE_STORAGE_NOTE.md.gz`; `STORAGE_RENDERING.diff.gz` records the complete narrow repair. `PUBLICATION.diff.gz` records the complete original-to-current rendering diff. Both diffs and all standalone framing evidence are compressed without whitespace normalization.

Machine fields state `bounded_theorem`, current `conditional-support`, `status: proposed_retained`, required audit before effective retained, and `bare_retained_allowed: false`. The one actual parent claim is the sole upstream dependency. Source acceptance is recorded separately from retained status and from root's integration/publication actions; current voice does not pretend the source is still awaiting its already completed review. This builder creates no graph node, edge, cache, HANDOFF or TRACE_GATE. Root supplies publication-only governance surfaces in its later reviewed integration.

## Primary identity runner and its limits

The template is rendered to a standalone runner with literal complete `AUDIT_INPUT_PATHS` and literal `AUDIT_TIMEOUT_SEC = 60`. The manifest hash is literal. Every file the runner reads is enumerated, including the actual canonical parent and all preserved source/evidence files. The helper's own source identity is handled by the root cache/tooling; it does not read itself or create a circular self-pin. Extra root publication metadata is not silently declared as an input: any later read-relevant addition needs an explicit reviewed manifest/input-list derivative.

The helper independently decompresses and verifies every mapped original before reconstructing the rendered note from frozen source intervals plus recorded framing changes. It checks complete parent extractions; exact original 452-file membership; physical `.gz` membership; sealed v1/current source groups; full pre-repair rendering and both full diffs; source acceptance and dated receipt selections; and its actual physical read set against the literal declaration. It executes zero mathematics and no archived code. Success prints an identity summary followed by the five explicit per-element/site/mode/block/lattice scope lines. These say what was not calculated; they do not award a theorem PASS, independent review, N-gate or audit status.

The output report and manifest are source handoff data, not an install/publish driver. Root alone owns actual cache/graph, mutations, staging, commit/push/PR work and combined integration validation. The original finite resource, baseline/scalar/reserve, same-K, arbitrary-reference and separately supplied preparation hypotheses remain as accepted. There is no new optimality, native supply or physical-energy identification claim.

## Gzip map and exact reconstruction contract

`ARCHIVE_MAP.json` is ordinary readable JSON. Its `members` dictionary keys are original logical paths relative to the packet. Each entry supplies the explicit stored path ending `.gz`, gzip encoding, compressed size/SHA-256, decoded original size/SHA-256 and role. Every compressed representation is also a literal manifest/audit input. The primary helper reads only declared physical files, uses Python's standard-library gzip decoder on bytes, and never imports or executes decoded code. A `.md.gz` link is an archival download, not an unlabelled Markdown file containing binary data.

For the accepted source group, the decoded original freeze gives the full original member set including its freeze: exactly 452 paths. The helper requires that set to equal the map's source keys, and that the actual physical subtree equal those same paths with `.gz` appended. It then checks every decoded size/hash against the unchanged original freeze. The same rule verifies seven v1 source files and the complete current source group. Extra, missing, renamed, truncated or altered representations do not satisfy these identities. No extraction to disk is needed.

The builder's new nested `archive()` handles compression and exact round-trip identity. Its existing actual-fact guards, accepted proof extraction, source partition and publication scope remain unchanged. The primary helper's new `original()` and `archived_group()` handle decoding and exact membership; `verify()` reconstructs both the pre-storage rendering and the authorized link/EOF-only wrapper derivative. Function-level and whole-file maps identify these changes. Root must read these complete functions before execution.

This worker has not run either proposed program, compiled/imported it, or built any parent fixture. The whitespace problem was reported from root's preparation-note staging; no chain staging check or successful runtime is claimed here. Root owns later actual execution and `git diff --check`. V2 addresses archive representation and the specifically authorized final wrapper LF; it does not normalize accepted source bytes or provide a general whitespace-cleanliness theorem.
