#!/usr/bin/env python3
"""Source identities only: no archived program, theorem, operator or mathematical test is executed."""
from pathlib import Path, PurePosixPath
import difflib, hashlib, json, posixpath, re, sys

AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = __AUDIT_INPUT_PATHS__
MANIFEST_SHA = __MANIFEST_SHA__
NOTE='docs/CHAIN_PREPARATION_MOMENT_SCALING_BOUNDED_THEOREM_NOTE_2026-10-14.md'
PARENT='docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md'
PACKET='.claude/science/physics-loops/toe-chain-preparation-scaling-20261014'
CLAIM='chain_preparation_moment_scaling_bounded_theorem_note_2026-10-14'
SOURCE_SHA='659b6e517f8fff8939447a25b7539f97f6cefbeb8d7b41acfcbff5e4c941776f'
ACCEPTANCE_SHA='a2d2310ca5ff409cbbaf7ea01df2e73e8957d0c2e4347879dcb538df24e24aaa'
CORES=('de7e79161faf1c35941285c9670e9cc421f798c51204da139575c36870ab9976','79d2388a7f6e2ce36d8b1055bd2ad80149a9e5375ff7f23248391d72bf5692ff')

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def pointer(value,path):
    need(path.startswith('/'),'Invalid receipt pointer')
    for key in path[1:].split('/'):
        key=key.replace('~1','/').replace('~0','~');value=value[int(key)] if isinstance(value,list) else value[key]
    return value
def verify(root):
    root=root.resolve();reads={}
    def read(name):
        p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'Unsafe declared path')
        f=root.joinpath(*p.parts)
        need(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(root),'Missing or unsafe input: '+name)
        if name not in reads:reads[name]=f.read_bytes()
        return reads[name]
    def packet(name):return read(PACKET+'/'+name)
    def source(name):return packet('source/'+name)
    manifest_raw=packet('IDENTITY_MANIFEST.json');need(sha(manifest_raw)==MANIFEST_SHA,'Identity manifest changed')
    manifest=json.loads(manifest_raw);members=manifest['members']
    need(len(AUDIT_INPUT_PATHS)==len(set(AUDIT_INPUT_PATHS)) and set(AUDIT_INPUT_PATHS)==set(members)|{PACKET+'/IDENTITY_MANIFEST.json'},'Literal declared input closure changed')
    for name,p in members.items():
        b=read(name);need(len(b)==p['bytes'] and sha(b)==p['sha256'],'Declared byte identity changed: '+name)
    freeze=source('FINAL_FREEZE.json');need(sha(freeze)==SOURCE_SHA,'Accepted source freeze changed')
    old=json.loads(freeze);old_names={r['path'] for r in old['members']}|{'FINAL_FREEZE.json'}
    actual={str(p.relative_to(root/PACKET/'source')) for p in (root/PACKET/'source').rglob('*') if p.is_file()}
    need(actual==old_names and len(actual)==452,'Complete frozen source archive changed')
    for r in old['members']:
        b=source(r['path']);need(len(b)==r['bytes'] and sha(b)==r['sha256'],'Frozen member changed')
    need(sha(packet('COMPONENT_ROOT_ACCEPTANCE.json'))==ACCEPTANCE_SHA,'Component acceptance changed')
    binding=json.loads(packet('ACTUAL_BINDING.json'));facts=binding['facts']
    need(facts==json.loads(packet('ACTUAL_BINDING_INPUT.json'))['facts'],'Actual binding input differs')
    need(binding['component_freeze_sha256']==SOURCE_SHA and binding['component_acceptance_sha256']==ACCEPTANCE_SHA,'Binding source status changed')
    parent=read(PARENT);need(parent==packet('observed_parent.md') and sha(parent)==facts['parent']['canonical_sha256']==binding['parent_sha256'],'Actual canonical parent differs from dated bytes')
    need(facts['parent']['canonical_path']==PARENT and facts['parent']['state']=='OPEN' and facts['parent']['is_draft'] is False,'Dated regular-parent observation changed')
    need(facts['child']['clean'] is True and facts['child']['head_sha']==facts['child']['base_head_sha']==facts['parent']['head_sha'],'Dated clean-child observation changed')
    covered=set()
    for e in binding['evidence']:
        b=packet(e['path']);need(len(b)==e['bytes'] and sha(b)==e['sha256'],'Receipt source changed')
        obj=json.loads(b)
        for target,origin in e['matches'].items():
            actual=pointer(obj,origin);wanted=pointer(facts,target)
            need(type(actual) is type(wanted) and actual==wanted,'Receipt facts differ');covered.add(target)
    required={'/parent/'+k for k in ['number','url','state','is_draft','head_ref','head_sha','observed_utc']}|{'/child/'+k for k in ['branch','head_sha','base_head_sha','tree_sha','clean','observed_utc']}
    need(required<=covered,'Incomplete parent/child receipt coverage')
    need([r['sha256'] for r in binding['parent_maps']]==list(CORES),'Actual theorem-clause roles changed')
    for r in binding['parent_maps']:
        core=packet(r['source']);need(sha(core)==r['sha256'] and len(core)==r['bytes'],'Relied parent source changed')
        need(parent[r['byte_start_0']:r['byte_end_exclusive']]==core and parent.count(core)==1 and r['body_edits']==[],'Complete parent theorem extraction changed')
    body=json.loads(packet('BODY_MAP.json'));old_map=json.loads(source('payload/BODY_MAP.json'))
    rendering=json.loads(packet('PUBLICATION_RENDERING.json'));edits={r['label']:r for r in rendering['framing_edits']}
    need(len(body['parts'])==len(old_map['parts']) and body['mathematical_body_edits']==rendering['proof_edits']==[],'Publication scope changed')
    result=[body['frontmatter'].encode()];cursor=len(result[0]);note=read(NOTE)
    for original,r in zip(old_map['parts'],body['parts']):
        need(all(r[k]==v for k,v in original.items()),'Original interval map was changed')
        complete=source(r['origin']);need(sha(complete)==r['source_sha256'],'Relied complete source differs')
        raw=complete[r['source_byte_start_0']:r['source_byte_end_exclusive']]
        need(sha(raw)==r['body_sha256'],'Relied source interval differs')
        b=raw
        if r['kind']=='new_framing':
            s=raw.decode();edit=edits[r['label']];need(sha(raw)==edit['original_sha256'],'Original framing differs')
            for e in edit['changes']:
                if 'before' in e:
                    need(s.count(e['before'])==1,'Ambiguous framing replacement');s=s.replace(e['before'],e['after'],1)
                else:
                    a=']('+e['before_target']+')';c=']('+e['after_target']+')'
                    need(s.count(a)==e['occurrences'],'Link relocation count changed');s=s.replace(a,c)
            b=s.encode();need(b==packet('rendered_framing/'+r['label']) and sha(b)==edit['rendered_sha256'],'New framing does not reconstruct')
        else:need(note.count(raw)==1,'Raw mathematical body changed or repeated')
        need(sha(b)==r['rendered_sha256'] and len(b)==r['rendered_bytes'],'Rendered interval differs')
        need(r['published_byte_start_0']==cursor and note[cursor:r['published_byte_end_exclusive']]==b,'Published interval differs')
        cursor=r['published_byte_end_exclusive'];result.append(b)
    need(b''.join(result)==note and cursor==len(note) and sha(note)==body['note_sha256'],'Complete note reconstruction differs')
    old_note=source('payload/CANDIDATE_NOTE.md')
    delta=b''.join(difflib.diff_bytes(difflib.unified_diff,old_note.splitlines(True),note.splitlines(True),fromfile=b'accepted_unbound_note',tofile=b'bound_publication_rendering'))
    need(delta==packet('PUBLICATION.diff'),'Complete publication diff differs')
    deps=json.loads(packet('DEPENDENCIES.json'));parent_role=deps['sole_direct_parent']
    need(parent_role['path']==PARENT and parent_role['sha256']==sha(parent) and parent_role['required_complete_raw_clauses']==list(CORES) and deps['expected_direct_edges']==1,'Sole direct theorem role changed')
    need(parent_role['claim_id']==facts['parent']['claim_id'] and note.decode().count(parent_role['markdown'])==1,'Actual parent citation changed')
    need(('upstream_dependencies: '+json.dumps([parent_role['claim_id']])+'\n').encode() in result[0],'Machine dependency field changed')
    links=[{'target':t,'resolved':posixpath.normpath(posixpath.join('docs',t.split('#',1)[0]))} for t in re.findall(r'\[[^\]]+\]\(([^)]+)\)',note.decode())]
    need(links==json.loads(packet('LINK_MAP.json'))['links'] and sum(r['resolved']==PARENT for r in links)==1,'Complete note link map differs')
    need(all(r['resolved'] in members for r in links),'Unpinned current note link')
    need(set(reads)==set(AUDIT_INPUT_PATHS),'Declared runtime read closure differs')
    return {'result':'source_identities_and_reconstruction_match','claim_id':CLAIM,'meaning':'Byte integrity only; no mathematical theorem or audit was executed.','mathematical_predicates_executed':0,'scientific_programs_executed':0,'observations_are_dated':True,'actual_parent_live_state_queried':False}

def main():
    print(json.dumps(verify(Path(__file__).resolve().parents[1]),sort_keys=True))
    print('per_element: checked and not executed — source identities only; no operator algebra was evaluated.')
    print('per_site: checked and not executed — source identities only; no support or local-load calculation was evaluated.')
    print('per_mode: checked and not executed — source identities only; no physical-mode identification was evaluated.')
    print('per_block: checked and not executed — source identities only; no marginal or variance inequality was evaluated.')
    print('lattice_wide: checked and not executed — source identities only; no all-length or native theorem was verified.')
if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'result':'identity_verification_incomplete','error':str(error),'mathematical_predicates_executed':0,'scientific_programs_executed':0}),file=sys.stderr)
        raise SystemExit(1)
