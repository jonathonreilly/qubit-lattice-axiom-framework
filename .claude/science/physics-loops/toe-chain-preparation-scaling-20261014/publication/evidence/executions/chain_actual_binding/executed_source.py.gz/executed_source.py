import json,shutil
from pathlib import Path
from common import N,W,pin,check_pin,read_json,write_json,run,now,require_campaign_active,require_clean_branch,git_read
D=N/'publication_integration/chain';p=read_json(N/'publication_integration/preparation/PUBLICATION.json');head=p['pr']['headRefOid'];branch='physics-loop/toe-chain-preparation-scaling-20261014'
require_campaign_active();require_clean_branch(p['pr']['headRefName'],head)
parent=json.loads(run(D,'actual_parent_pr',['gh','pr','view',str(p['pr']['number']),'--json','number,url,state,isDraft,headRefName,headRefOid']))
assert parent['state']=='OPEN' and parent['isDraft'] is False and parent['headRefOid']==head
observed=now().isoformat();check_pin(W/'docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md',p['note'])
run(D,'create_child',['git','switch','-c',branch,head]);require_clean_branch(branch,head)
child={'branch':branch,'head_sha':git_read('rev-parse','HEAD').decode().strip(),'base_head_sha':head,'tree_sha':git_read('rev-parse','HEAD^{tree}').decode().strip(),'clean':True,'observed_utc':now().isoformat()}
facts={'parent':{'canonical_path':'docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md','canonical_sha256':p['note']['sha256'],'claim_id':'multi_port_preparation_energy_moments_bounded_theorem_note_2026-10-14','number':parent['number'],'url':parent['url'],'state':parent['state'],'is_draft':parent['isDraft'],'head_ref':parent['headRefName'],'head_sha':head,'observed_utc':observed},'child':child}
receipt={'facts':facts,'actual_pr_command':pin(D/'actual_parent_pr/EXECUTION.json'),'actual_child_command':pin(D/'create_child/EXECUTION.json'),'prior_publication':pin(N/'publication_integration/preparation/PUBLICATION.json'),'note':pin(W/facts['parent']['canonical_path']),'scope':'Actual GitHub response and clean local child observations at the recorded times; no future remote state claim.'}
write_json(D/'ACTUAL_BINDING_RECEIPT.json',receipt)
fields=['/parent/'+k for k in facts['parent'] if k not in ['canonical_path','canonical_sha256','claim_id']]+['/child/'+k for k in child]
file=D/'ACTUAL_BINDING_RECEIPT.json';record=pin(file)
binding={'schema':1,'facts':facts,'evidence':[{'file':str(file),'bytes':record['bytes'],'sha256':record['sha256'],'matches':{field:'/facts'+field for field in fields}}]}
write_json(D/'ACTUAL_BINDING.json',binding);shutil.copyfile(W/facts['parent']['canonical_path'],D/'actual_parent_note.md')
# Before-graph is the exact previously verified after-graph: the child starts at that committed tree.
P=N/'publication_integration/preparation'
assert (W/'docs/audit/data/citation_graph.json').read_bytes()==(P/'after_graph.json').read_bytes()
assert git_read('show','HEAD:docs/audit/data/citation_graph_manifest.json')==(P/'after_graph_manifest.json').read_bytes()
for name,source in [('base_graph.json','after_graph.json'),('base_graph_manifest.json','after_graph_manifest.json')]:shutil.copyfile(P/source,D/name)
write_json(D/'BASE_GRAPH_BINDING.json',{'utc':now().isoformat(),'child':child,'graph':pin(D/'base_graph.json'),'manifest':pin(D/'base_graph_manifest.json'),'reviewed_prior_graph_verification':pin(P/'GRAPH_VERIFICATION.json'),'reuse':'Exact committed preparation tree, unchanged complete graph and topology bytes; no extraction input changed.'})
print({'binding':pin(D/'ACTUAL_BINDING.json'),'actual_parent':facts['parent'],'child':child})
