from chain_common import *
import ast, gzip

require_campaign_active()
source = N / 'chain_binding_source_v3/outputs/bound_source_01'
payload = source / 'payload'
packet = payload / PACKET
report = read_json(source / 'BUILD_REPORT.json')
assert report['note']['sha256'] == '883e0c0ad7d31fc039de0d895fb586818c2562150acef528fb4c79c784f9441b'
manifest = read_json(source / 'OUTPUT_MANIFEST.json')
for row in manifest['members']:
    check_pin(source / row['path'], row)
assert {str(p.relative_to(source)) for p in payload.rglob('*') if p.is_file()} == {row['path'] for row in manifest['members']}
archives = read_json(packet / 'ARCHIVE_MAP.json')['members']
decoded = {}
for logical, row in archives.items():
    stored = (payload / row['stored_path']).read_bytes()
    raw = gzip.decompress(stored)
    assert len(stored) == row['stored_bytes'] and hashlib.sha256(stored).hexdigest() == row['stored_sha256']
    assert len(raw) == row['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == row['decoded_sha256']
    decoded[logical] = raw
    if logical.startswith('source/'):
        assert raw == (N / 'chain_scaling_publication_components' / logical[len('source/'):]).read_bytes()
note = (payload / NOTE).read_bytes()
body = read_json(packet / 'BODY_MAP.json')
cursor = len(body['frontmatter'].encode())
assert note[:cursor] == body['frontmatter'].encode()
proofs = []
for row in body['parts']:
    section = note[row['published_byte_start_0']:row['published_byte_end_exclusive']]
    assert row['published_byte_start_0'] == cursor
    assert hashlib.sha256(section).hexdigest() == row['rendered_sha256']
    original = decoded['source/' + row['origin']][row['source_byte_start_0']:row['source_byte_end_exclusive']]
    if row['kind'] != 'new_framing':
        assert section == original and note.count(original) == 1
        proofs.append({'label': row['label'], 'sha256': hashlib.sha256(section).hexdigest(), 'bytes': len(section), 'body_edits': []})
    cursor = row['published_byte_end_exclusive']
assert cursor == len(note) and note.endswith(b'\n') and not note.endswith(b'\n\n')
binding = read_json(packet / 'ACTUAL_BINDING.json')
assert binding['facts'] == read_json(D / 'ACTUAL_BINDING.json')['facts']
parent = (W / PARENT).read_bytes()
assert parent == (D / 'actual_parent_note.md').read_bytes() == decoded['observed_parent.md']
for row in binding['parent_maps']:
    raw = decoded[row['source']]
    assert parent[row['byte_start_0']:row['byte_end_exclusive']] == raw and parent.count(raw) == 1
helper = (payload / HELPER).read_text()
values = {n.targets[0].id: ast.literal_eval(n.value) for n in ast.parse(helper).body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['AUDIT_INPUT_PATHS', 'MANIFEST_SHA']}
template = (N / 'chain_binding_source_v3/identity_runner.template.py').read_text()
assert helper == template.replace('__AUDIT_INPUT_PATHS__', repr(values['AUDIT_INPUT_PATHS'])).replace('__MANIFEST_SHA__', repr(values['MANIFEST_SHA']))
drivers = ['common.py', 'chain_common.py', 'install_chain.py', 'check_chain_mutations.py', 'execute_chain_cache.py', 'check_chain_graph.py', 'package_chain.py', 'verify_stage_chain.py', 'publish_chain.py', 'run_identity_fixture.py']
write_json(D / 'BOUND_SOURCE_REVIEW.json', {'utc': now().isoformat(), 'output_directory': str(source), 'build_report': pin(source / 'BUILD_REPORT.json'), 'output_manifest': pin(source / 'OUTPUT_MANIFEST.json'), 'complete_current_framing_and_sidecars_read': True, 'generated_helper_exact_reviewed_template': True, 'decoded_originals': len(decoded), 'complete_source_components': sum(key.startswith('source/') for key in decoded), 'unchanged_math_intervals': proofs, 'actual_parent_clauses': binding['parent_maps'], 'root_authored_or_fully_reviewed_drivers': [pin(Path(__file__).parent / name) for name in drivers], 'approved_for_installation': True, 'independent_wrapper_review': 'separate pending source-exposed check; required before publication', 'new_mathematical_predicates': 0, 'editable_prompts_changed': []})
print(json.dumps({'note': pin(payload / NOTE), 'archives': len(decoded), 'proofs': proofs, 'approved_for_installation': True}))
