#!/usr/bin/env python3
"""Build fresh bound publication source only. No Git, install, cache, graph or math execution."""
from pathlib import Path, PurePosixPath
import argparse, datetime, difflib, gzip, hashlib, json, posixpath, re

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'chain_scaling_publication_components'
PRIOR=HERE.parent/'chain_binding_source'
PRIOR_SHA='3b739e10f598dc4d9dbb837f827291a886e9a3edd09ed8227c36b80c9fe57a41'
ACCEPTANCE=HERE.parent/'publication_integration/chain/COMPONENT_ROOT_ACCEPTANCE.json'
SOURCE_SHA='659b6e517f8fff8939447a25b7539f97f6cefbeb8d7b41acfcbff5e4c941776f'
ACCEPTANCE_SHA='a2d2310ca5ff409cbbaf7ea01df2e73e8957d0c2e4347879dcb538df24e24aaa'
PARENT='docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md'
NOTE='docs/CHAIN_PREPARATION_MOMENT_SCALING_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='scripts/chain_preparation_moment_scaling_identity_2026_10_14.py'
PACKET='.claude/science/physics-loops/toe-chain-preparation-scaling-20261014'
CLAIM='chain_preparation_moment_scaling_bounded_theorem_note_2026-10-14'
CORES=('de7e79161faf1c35941285c9670e9cc421f798c51204da139575c36870ab9976','79d2388a7f6e2ce36d8b1055bd2ad80149a9e5375ff7f23248391d72bf5692ff')

def need(ok,message):
    if not ok: raise ValueError(message)
def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(v): return (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
def read(p):
    p=Path(p);need(p.is_file() and not p.is_symlink(),'Missing file or symlink: '+str(p));return p.read_bytes()
def relative(name):
    p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and str(p)==name,'Unsafe relative path');return name
def pointer(value,path):
    need(path.startswith('/'),'JSON pointer must start with /')
    for key in path[1:].split('/'):
        key=key.replace('~1','/').replace('~0','~');value=value[int(key)] if isinstance(value,list) else value[key]
    return value
def freeze_members(base,expected,ignore_outputs=False):
    seal=read(base/'FINAL_FREEZE.json');need(sha(seal)==expected,'Frozen source identity changed')
    members=json.loads(seal)['members'];names={relative(r['path']) for r in members}|{'FINAL_FREEZE.json'}
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and not(ignore_outputs and p.relative_to(base).parts[0]=='outputs')}
    need(actual==names,'Frozen source membership changed')
    for r in members:
        b=read(base/r['path']);need(len(b)==r['bytes'] and sha(b)==r['sha256'],'Frozen member changed: '+r['path'])
    return sorted(names)
def date(value):
    need(isinstance(value,str) and value,'Missing observation time')
    d=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
    need(d.tzinfo is not None and d.utcoffset()==datetime.timedelta(0),'Observation must explicitly use UTC')
    need(d<=datetime.datetime.now(datetime.timezone.utc),'Future observation is not an actual observation')
def binding_inputs(binding_path,parent_path):
    raw=read(binding_path);binding=json.loads(raw);need(binding.get('schema')==1,'Binding schema must be 1')
    facts=binding['facts'];parent=facts['parent'];child=facts['child']
    required_parent={'canonical_path','canonical_sha256','claim_id','number','url','state','is_draft','head_ref','head_sha','observed_utc'}
    required_child={'branch','head_sha','base_head_sha','tree_sha','clean','observed_utc'}
    need(set(parent)==required_parent and set(child)==required_child,'Binding fields incomplete or unknown')
    need(all(v is not None and v!='' for v in list(parent.values())+list(child.values())),'Null/empty binding refused')
    need(parent['canonical_path']==PARENT and parent['state']=='OPEN' and parent['is_draft'] is False,'Actual regular OPEN preparation parent required')
    need(type(parent['number']) is int and parent['number']>0,'Invalid actual PR number')
    need(parent['url']=='https://github.com/jonathonreilly/qubit-lattice-axiom-framework/pull/'+str(parent['number']),'PR URL/number mismatch')
    for x in [parent['head_sha'],child['head_sha'],child['base_head_sha'],child['tree_sha']]:need(bool(re.fullmatch('[0-9a-f]{40}',x)),'Invalid commit/tree SHA')
    for x in [parent['head_ref'],child['branch']]:need(bool(re.fullmatch('[A-Za-z0-9._/-]+',x)),'Invalid branch text')
    need(child['head_sha']==child['base_head_sha']==parent['head_sha'] and child['clean'] is True,'Clean child must begin at actual parent head')
    need(child['branch']!=parent['head_ref'],'Parent and child branches must differ')
    date(parent['observed_utc']);date(child['observed_utc'])
    note=read(parent_path);need(sha(note)==parent['canonical_sha256'],'Actual parent bytes/hash mismatch')
    ids=re.findall(rb'^claim_id: ([a-z0-9_\-]+)\s*$',note,re.M)
    need(len(ids)==1 and ids[0].decode()==parent['claim_id'],'Parent claim_id differs from actual note')
    need(bool(re.fullmatch('[a-z0-9_\-]+',parent['claim_id'])),'Invalid parent claim identifier')
    evidence=[];covered=set()
    for i,item in enumerate(binding['evidence']):
        b=read(item['file']);need(len(b)==item['bytes'] and sha(b)==item['sha256'],'Actual evidence bytes/hash mismatch')
        obj=json.loads(b);matches=item['matches'];need(isinstance(matches,dict) and matches,'Empty evidence selector map')
        for fact_path,evidence_path in matches.items():
            actual=pointer(obj,evidence_path);wanted=pointer(facts,fact_path)
            need(type(actual) is type(wanted) and actual==wanted,'Evidence does not match fact '+fact_path);covered.add(fact_path)
        evidence.append({'path':'binding_evidence/'+str(i).zfill(2)+'.json','bytes':len(b),'sha256':sha(b),'original':item['file'],'matches':matches,'raw':b})
    required={'/parent/'+k for k in required_parent-{'canonical_path','canonical_sha256','claim_id'}}|{'/child/'+k for k in required_child}
    need(required<=covered,'Every dynamic parent/child fact needs an exact receipt selector')
    return raw,facts,note,evidence
def unified(a,b,left,right):
    return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=left.encode(),tofile=right.encode()))

def build(args):
    names=freeze_members(SOURCE,SOURCE_SHA);need(len(names)==452,'Accepted component file count changed')
    prior_names=freeze_members(PRIOR,PRIOR_SHA,True);need(len(prior_names)==7,'Sealed v1 membership changed')
    own_names=freeze_members(HERE,args.source_freeze_sha,True)
    acceptance=read(ACCEPTANCE);need(sha(acceptance)==ACCEPTANCE_SHA,'Actual component acceptance changed')
    raw_binding,facts,parent,evidence=binding_inputs(args.binding,args.parent)
    need(bool(re.fullmatch('[a-z0-9][a-z0-9_-]*',args.output_name)),'Output name must be a simple fresh directory name')
    out=HERE/'outputs'/args.output_name;need(out.resolve().is_relative_to(HERE.resolve()),'Output escapes assigned source directory');need(not out.exists(),'Fresh output required; previous partial results are never overwritten')
    parent_maps=[]
    for h in CORES:
        core=read(SOURCE/'archive/objects'/h);need(sha(core)==h and parent.count(core)==1,'Complete exact de7/79d parent extraction required')
        start=parent.index(core);parent_maps.append({'sha256':h,'source':'source/archive/objects/'+h,'byte_start_0':start,'byte_end_exclusive':start+len(core),'bytes':len(core),'body_edits':[]})
    source_note=read(SOURCE/'payload/CANDIDATE_NOTE.md');source_map=json.loads(read(SOURCE/'payload/BODY_MAP.json'))
    need(sha(source_note)==source_map['note_sha256'],'Source note map changed')
    staged={};archives={};edits=[];parts=[];pre_storage_parts=[];published_parts=[]
    def emit(name,b):
        relative(name);need(name not in staged,'Duplicate output path');staged[name]=b
    def packet(name,b):emit(PACKET+'/'+name,b)
    def archive(name,b,role):
        relative(name);need(name not in archives,'Duplicate logical archive path')
        stored=gzip.compress(b,compresslevel=9,mtime=0)
        need(gzip.decompress(stored)==b,'Lossless archive round trip failed')
        packet(name+'.gz',stored)
        archives[name]={'stored_path':PACKET+'/'+name+'.gz','encoding':'gzip','decoded_bytes':len(b),'decoded_sha256':sha(b),'stored_bytes':len(stored),'stored_sha256':sha(stored),'role':role}
    # One mapped gzip representation of every exact original, including existing gzip files.
    for name in names:archive('source/'+name,read(SOURCE/name),'accepted component original')
    for name in prior_names:archive('prior_binding_source/'+name,read(PRIOR/name),'sealed v1 source')
    for name in own_names:archive('binding_source/'+name,read(HERE/name),'current source and immutable repair evidence')
    archive('COMPONENT_ROOT_ACCEPTANCE.json',acceptance,'exact acceptance receipt')
    archive('ACTUAL_BINDING_INPUT.json',raw_binding,'actual binding input')
    archive('observed_parent.md',parent,'exact observed canonical parent')
    for e in evidence:archive(e['path'],e['raw'],'actual binding evidence')
    current_date=datetime.datetime.now(datetime.timezone.utc).isoformat()
    citation='[preparation-moment theorem and restricted-chain prerequisite]('+PurePosixPath(PARENT).name+')'
    parent_paragraph=('The sole imported canonical theorem source is the '+citation+'. Its complete de7 and 79d clauses match the frozen premises exactly. The be8 simultaneous operator result is transitive; no additional theorem edge follows from branch ancestry. Parent PR '+str(facts['parent']['number'])+' was observed regular OPEN at '+facts['parent']['observed_utc']+' at head `'+facts['parent']['head_sha']+'`. The clean child `'+facts['child']['branch']+'` was observed at that head at '+facts['child']['observed_utc']+'. These are dated observations, not claims about future PR state. The [binding record](../'+PACKET+'/ACTUAL_BINDING.json) preserves the exact receipts and complete parent-body extractions.')
    for item in source_map['parts']:
        original=read(SOURCE/item['origin'])[item['source_byte_start_0']:item['source_byte_end_exclusive']]
        need(sha(original)==item['body_sha256'],'Frozen part changed')
        rendered=original
        if item['kind']=='new_framing':
            s=original.decode();changes=[]
            def replace(old,new):
                nonlocal s
                need(s.count(old)==1,'Framing replacement is not unique: '+old[:60]);s=s.replace(old,new,1);changes.append({'before':old,'after':new})
            if item['label']=='PREFIX.md':
                replace('**Accepted conditional analytic sources; publication components awaiting source review and actual parent binding.**','**Conditional support; the mathematical sources and source components have separate recorded acceptances.**')
                replace('Its reference marginal is the complete old-system/reference marginal, and its auxiliary data are actual local excitation probabilities.','It requires a supplied certificate for the complete old-system/reference marginal, and its auxiliary data are actual local excitation probabilities. This full marginal error epsilon is distinct from the additional epsilon_R cost for reference-valued records.')
                replace('It does not assume independent cell errors.','It does not assume independent cell errors. In the root corollary, nu bounds one auxiliary excitation probability and eta<=4M nu bounds their sum. The separately supplied [sigma,P]=0 condition removes P-Q cross terms while retaining Q-Q coherences. The centered second reference-valued record still pays Delta*kappa*epsilon_R, with the chain upper bound D*k*M^7*epsilon_R; scalar moment tolerances do not remove that term.')
                replace('full norm/scalar bound as M^7','full-space norm bound as M^7')
                old=next(p for p in s.split('\n\n') if p.startswith('The sharper [de7 moment theorem]'))
                replace(old,parent_paragraph)
            if item['label']=='SUFFIX.md':
                replace('SOURCE_MAP.json at the component root','The preserved [source map](../'+PACKET+'/source/SOURCE_MAP.json)')
                old=next(p for p in s.split('\n\n') if p.startswith('Before canonical use, root must review'))
                replace(old,'The mathematical sources were accepted under 3787850c and the complete unbound source components under a2d2310c at 2026-10-14T22:02:40.263776+00:00. This publication rendering was constructed at '+current_date+' from the dated parent/child evidence above. The original unbound note and all historical pending status text remain preserved byte for byte. Canonical integration, cache/graph checks, staging and publication have separate root-owned records. This note and its identity runner confer no retained audit status or apparatus supply.')
            for target in sorted(set(re.findall(r'\[[^\]]+\]\(([^)]+)\)',s))):
                if target.startswith('../archive/objects/'):
                    new='../'+PACKET+'/source/archive/objects/'+target.rsplit('/',1)[1]
                elif target in ['BODY_MAP.json','DEPENDENCIES.json']:
                    new='../'+PACKET+'/'+target
                else:continue
                count=s.count(']('+target+')');s=s.replace(']('+target+')',']('+new+')');changes.append({'before_target':target,'after_target':new,'occurrences':count})
            pre_storage=s.encode();storage_changes=[]
            for target in sorted(set(re.findall(r'\[[^\]]+\]\(([^)]+)\)',s))):
                resolved=posixpath.normpath(posixpath.join('docs',target))
                if resolved.startswith(PACKET+'/') and resolved[len(PACKET)+1:] in archives:
                    count=s.count(']('+target+')');s=s.replace(']('+target+')',']('+target+'.gz)')
                    storage_changes.append({'before_target':target,'after_target':target+'.gz','occurrences':count})
            if item['label']=='SUFFIX.md':
                n=len(s)-len(s.rstrip('\n'))
                if n!=1:
                    storage_changes.append({'ending_before':'\n'*n,'ending_after':'\n'});s=s.rstrip('\n')+'\n'
            rendered=s.encode();archive('rendered_framing/'+item['label'],rendered,'exact rendered framing evidence')
            edits.append({'label':item['label'],'original_sha256':sha(original),'pre_storage_sha256':sha(pre_storage),'rendered_sha256':sha(rendered),'changes':changes,'storage_changes':storage_changes})
        else:pre_storage=rendered
        pre_storage_parts.append(pre_storage);parts.append(rendered);published_parts.append({**item,'rendered_sha256':sha(rendered),'rendered_bytes':len(rendered)})
    front=('---\ntitle: Sufficient preparation-moment budgets for a restricted noncommuting chain\nclaim_id: '+CLAIM+'\nclaim_type: bounded_theorem\ntarget_claim_type: bounded_theorem\nactual_current_surface_status: conditional-support\nartifact_role: theorem\ntrace_class: upstream_support\ntarget_claim_id: null\ntarget_blocker_text: null\nsource_of_blocker_text: frontier_question\nreachability_to_target: supports\nconditional_surface_status: same-K scalar moment sensitivity with supplied full old/reference marginal and local auxiliary bounds; block diagonality separately supplied\nhypothetical_axiom_status: null\nadmitted_observation_status: null\nstatus: proposed_retained\ncanonical_parent_binding_complete: true\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\nupstream_dependencies: '+json.dumps([facts['parent']['claim_id']])+'\nrunner: '+RUNNER+'\nclaim_type_reason: accepted conditional source composition; sufficient costs only, no native preparation or physical-energy identification\nnext_trace_action: root-owned integration verification and any later independent audit\n---\n\nClaim type: bounded_theorem\n\n').encode()
    pre_storage_note=front+b''.join(pre_storage_parts)
    note=front+b''.join(parts);cursor=len(front)
    need(note.endswith(b'\n') and not note.endswith(b'\n\n'),'New canonical wrapper must end with exactly one LF')
    for r,b in zip(published_parts,parts):
        r['published_byte_start_0']=cursor;r['published_byte_end_exclusive']=cursor+len(b);cursor+=len(b)
        if r['kind']!='new_framing':need(sha(b)==r['body_sha256'] and note.count(b)==1,'Mathematical interval changed or repeated')
    emit(NOTE,note)
    packet('BODY_MAP.json',encoded({'note':NOTE,'note_sha256':sha(note),'frontmatter':front.decode(),'parts':published_parts,'mathematical_body_edits':[]}))
    packet('PUBLICATION_RENDERING.json',encoded({'created_utc':current_date,'source_note_sha256':sha(source_note),'pre_storage_note_sha256':sha(pre_storage_note),'published_note_sha256':sha(note),'framing_edits':edits,'proof_edits':[],'storage_wrapper_delta':'gzip link targets and final wrapper LF only','actual_source_acceptance_sha256':ACCEPTANCE_SHA}))
    archive('PRE_STORAGE_NOTE.md',pre_storage_note,'complete v1-rule rendering before storage links and EOF repair')
    archive('STORAGE_RENDERING.diff',unified(pre_storage_note,note,'v1_rule_rendering','gzip_links_and_final_wrapper_LF'),'complete narrow wrapper repair diff')
    archive('PUBLICATION.diff',unified(source_note,note,'accepted_unbound_note','bound_publication_rendering'),'complete publication diff')
    bound={'facts':facts,'parent_path':PARENT,'parent_sha256':sha(parent),'parent_maps':parent_maps,'evidence':[{k:v for k,v in e.items() if k!='raw'} for e in evidence],'component_freeze_sha256':SOURCE_SHA,'component_acceptance_sha256':ACCEPTANCE_SHA,'prior_binding_source_freeze_sha256':PRIOR_SHA,'source_binding_builder_freeze_sha256':args.source_freeze_sha,'observations_are_dated':True,'external_state_independently_queried_by_builder':False}
    packet('ACTUAL_BINDING.json',encoded(bound))
    packet('DEPENDENCIES.json',encoded({'claim_id':CLAIM,'sole_direct_parent':{'path':PARENT,'claim_id':facts['parent']['claim_id'],'sha256':sha(parent),'required_complete_raw_clauses':list(CORES),'markdown':citation},'transitive_be8_is_not_an_added_direct_edge':True,'branch_ancestry_is_not_a_theorem_import':True,'expected_direct_edges':1,'graph_execution':False}))
    packet('SOURCE_REVIEW_STATUS.json',encoded({'mathematical_sources_accepted':True,'unbound_components_accepted':True,'component_acceptance_sha256':ACCEPTANCE_SHA,'derivative_created_utc':current_date,'new_independent_mathematical_review':False,'retained_audit_status':False,'mathematical_body_edits':[],'canonical_install_or_publication_performed_by_builder':False}))
    packet('ARCHIVE_MAP.json',encoded({'schema':1,'representation':'one lossless gzip layer with explicit .gz suffix','members':archives,'groups':{'source':{'final_freeze_sha256':SOURCE_SHA,'complete_files':len(names)},'prior_binding_source':{'final_freeze_sha256':PRIOR_SHA,'complete_files':len(prior_names)},'binding_source':{'final_freeze_sha256':args.source_freeze_sha,'complete_files':len(own_names)}}}))
    links=[]
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',note.decode()):
        need(not re.match(r'^[a-z]+:',target),'Unexpected URL in note framing')
        resolved=posixpath.normpath(posixpath.join('docs',target.split('#',1)[0]))
        need(resolved in staged or resolved==PARENT,'Unresolved rendered note link: '+target);links.append({'target':target,'resolved':resolved})
    need(sum(x['resolved']==PARENT for x in links)==1,'Sole actual preparation citation required')
    packet('LINK_MAP.json',encoded({'links':links,'framing_only_relocation':True,'raw_math_links_edited':False}))
    manifest_path=PACKET+'/IDENTITY_MANIFEST.json'
    expected={name:{'bytes':len(b),'sha256':sha(b)} for name,b in staged.items()}
    expected[PARENT]={'bytes':len(parent),'sha256':sha(parent)}
    manifest=encoded({'schema':1,'members':expected,'source_freeze_sha256':SOURCE_SHA,'source_acceptance_sha256':ACCEPTANCE_SHA,'mathematical_predicates':0})
    packet('IDENTITY_MANIFEST.json',manifest)
    inputs=sorted(expected)+[manifest_path];inputs=sorted(inputs)
    template=read(HERE/'identity_runner.template.py').decode()
    for marker,value in [('__AUDIT_INPUT_PATHS__',repr(inputs)),('__MANIFEST_SHA__',repr(sha(manifest)))]:
        need(template.count(marker)==1,'Runner marker not unique');template=template.replace(marker,value)
    emit(RUNNER,template.encode())
    # Only now create the fresh output; partial failures are retained, never erased.
    out.mkdir(parents=True)
    for name,b in sorted(staged.items()):
        f=out/'payload'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
    report={'created_utc':current_date,'source_only':True,'payload_files':len(staged),'literal_audit_input_count':len(inputs),'note':{'path':NOTE,'sha256':sha(note),'bytes':len(note)},'runner':{'path':RUNNER,'sha256':sha(template.encode())},'all_frozen_component_files_preserved_once':452,'archive_representations':len(archives),'archive_encoding':'lossless gzip with explicit .gz suffix','parent':facts['parent'],'child':facts['child'],'canonical_execution':False,'mathematics_executed':False,'driver_supplied':False}
    (out/'BUILD_REPORT.json').write_bytes(encoded(report))
    (out/'OUTPUT_MANIFEST.json').write_bytes(encoded({'members':[{'path':'payload/'+name,'bytes':len(b),'sha256':sha(b)} for name,b in sorted(staged.items())]}))
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binding',required=True);p.add_argument('--parent',required=True)
    p.add_argument('--source-freeze-sha',required=True);p.add_argument('--output-name',required=True)
    print(json.dumps(build(p.parse_args()),sort_keys=True))
