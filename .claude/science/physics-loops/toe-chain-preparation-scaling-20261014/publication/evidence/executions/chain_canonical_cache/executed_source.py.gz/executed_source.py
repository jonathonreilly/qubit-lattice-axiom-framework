from chain_common import *
import sys

require_campaign_active()
prepared = check_installed()
sys.path.insert(0, str(W / 'scripts'))
import runner_cache
result, cache = runner_cache.execute_and_write_cache(HELPER, timeout_sec=60)
write_json(D / 'CANONICAL_RESULT.json', result)
assert result['exit_code'] == 0 and result['status'] == 'ok' and cache
assert runner_cache.cache_status(HELPER) == 'fresh'
data, end = json.JSONDecoder().raw_decode(result['stdout'].lstrip())
assert data['result'] == 'source_identities_and_reconstruction_match'
assert data['mathematical_predicates_executed'] == data['scientific_programs_executed'] == 0
lines = result['stdout'].lstrip()[end:].strip().splitlines()
assert len(lines) == 5 and [s.split(':', 1)[0] for s in lines] == ['per_element', 'per_site', 'per_mode', 'per_block', 'lattice_wide']
check_installed()
write_json(D / 'CANONICAL_EXECUTION.json', {'utc': now().isoformat(), 'result': pin(D / 'CANONICAL_RESULT.json'), 'cache': pin(cache), 'helper': pin(W / HELPER), 'cache_status': 'fresh', 'identity_result': data, 'scope_lines': lines, 'inputs': len(prepared['canonical_inputs']), 'canonical_child_streams': 'runner_cache merges child stderr into stdout; result.stderr is not separate child stderr evidence', 'mathematical_predicates_executed': 0})
print(json.dumps({'cache': pin(cache), 'source_identity': data}))
