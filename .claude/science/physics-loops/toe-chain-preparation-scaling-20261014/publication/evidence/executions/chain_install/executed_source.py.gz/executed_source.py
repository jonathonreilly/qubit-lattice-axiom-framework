from chain_common import *
import ast, shutil

require_campaign_active()
review = read_json(D / 'BOUND_SOURCE_REVIEW.json')
assert review['approved_for_installation'] is True
source = Path(review['output_directory'])
for key in ['build_report', 'output_manifest']:
    check_pin(review[key]['path'], review[key])
members = read_json(source / 'OUTPUT_MANIFEST.json')['members']
assert {str(p.relative_to(source)) for p in (source / 'payload').rglob('*') if p.is_file()} == {row['path'] for row in members}
for row in members:
    check_pin(source / row['path'], row)
require_clean_branch(BRANCH, BASE_HEAD)
snapshot = read_json(N / 'bootstrap/SOURCE_SNAPSHOT.json')
for ref, expected in [('origin/main', snapshot['main']), ('origin/ai/execution', snapshot['instructions'])]:
    assert git_read('rev-parse', ref).decode().strip() == expected, 'Source revision changed: ' + ref
parent = json.loads(run(D, 'parent_before_install', ['gh', 'pr', 'view', '9575', '--json', 'number,url,state,isDraft,headRefOid,headRefName']))
assert parent['state'] == 'OPEN' and parent['isDraft'] is False and parent['headRefOid'] == BASE_HEAD and parent['headRefName'] == BASE_BRANCH
assert pin(W / PARENT)['sha256'] == '9cfc7b475f26975e61de5c52d5c616098e0d5e34f86507a95cccffc9f47df21f'
report = read_json(source / 'BUILD_REPORT.json')
assert report['note']['path'] == NOTE and report['runner']['path'] == HELPER
assert report['child']['branch'] == BRANCH and report['child']['head_sha'] == BASE_HEAD
helper_text = (source / 'payload' / HELPER).read_text()
tree = ast.parse(helper_text)
values = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['AUDIT_INPUT_PATHS', 'MANIFEST_SHA']}
manifest_path = PACKET + '/IDENTITY_MANIFEST.json'
assert values['MANIFEST_SHA'] == pin(source / 'payload' / manifest_path)['sha256']
assert set(values['AUDIT_INPUT_PATHS']) == set(read_json(source / 'payload' / manifest_path)['members']) | {manifest_path}
paths = sorted(row['path'][len('payload/'):] for row in members)
assert all(row['path'].startswith('payload/') for row in members)
assert all(name in [NOTE, HELPER] or name.startswith(PACKET + '/') for name in paths)
for name in paths:
    assert not (W / name).exists(), name
require_clean_branch(BRANCH, BASE_HEAD)
require_campaign_active()
for name in paths:
    target = W / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / 'payload' / name, target)
    target.chmod(0o644)
write_json(D / 'PREPARED_SOURCE.json', {'utc': now().isoformat(), 'base_head': BASE_HEAD, 'branch': BRANCH, 'bound_source_review': pin(D / 'BOUND_SOURCE_REVIEW.json'), 'output_directory': str(source), 'installed_paths': paths, 'installed_pins': {name: pin(W / name) for name in paths}, 'canonical_inputs': values['AUDIT_INPUT_PATHS'], 'fresh_parent_observation': parent, 'mathematical_body_edits': [], 'editable_prompts_changed': []})
print(json.dumps({'installed_files': len(paths), 'note': pin(W / NOTE), 'helper': pin(W / HELPER)}))
