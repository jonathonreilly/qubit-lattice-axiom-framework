from common import *
import ast, difflib

require_campaign_active()
D = N / 'chain_binding_source_v2'
V1 = N / 'chain_binding_source'
freeze = read_json(D / 'FINAL_FREEZE.json')
assert pin(D / 'FINAL_FREEZE.json')['sha256'] == 'f4140abb3d7161259dddc790bdcb534db408ac4b1c5bb55e1e6d9b0d360c3a50'
assert {x.name for x in D.iterdir()} == {'FINAL_FREEZE.json'} | {x['path'] for x in freeze['members']}
for row in freeze['members']:
    check_pin(D / row['path'], row)
mapping = read_json(D / 'SOURCE_MAP.json')
checked_functions = []
for row in mapping['files']:
    old, new = (V1 / row['path']).read_bytes(), (D / row['path']).read_bytes()
    assert hashlib.sha256(old).hexdigest() == row['old_sha256']
    assert hashlib.sha256(new).hexdigest() == row['new_sha256']
    for function in row.get('top_level_function_map', []):
        for raw, key in [(old, 'old'), (new, 'current')]:
            part = function[key]
            body = raw[part['byte_start_0']:part['byte_end_exclusive']]
            assert hashlib.sha256(body).hexdigest() == part['sha256']
        if function['status'] == 'exact reuse':
            assert function['old']['sha256'] == function['current']['sha256']
        checked_functions.append([row['path'], function['name'], function['status']])
    if row['path'].endswith('.py'):
        ast.parse(new)
check_pin(D / 'V1_TO_V2.diff', mapping['complete_diff'])
out = N / 'publication_integration/chain/BINDING_SOURCE_ROOT_ACCEPTANCE.json'
write_json(out, {'utc': now().isoformat(), 'source_freeze': pin(D / 'FINAL_FREEZE.json'), 'complete_current_programs_read': ['build_bound_source.py', 'identity_runner.template.py'], 'complete_current_prose_read': ['READ_GUIDE.md', 'EXPOSURE_AND_LIMITS.md'], 'input_template_read': True, 'top_level_function_map_verified': checked_functions, 'historical_diff': pin(D / 'V1_TO_V2.diff'), 'historical_diff_read_claim': 'No separate full diff read claimed; complete current programs and changed prose read, exact reuse function intervals verified.', 'disposition': 'Accepted for an actual-binding source reconstruction run; no mathematical execution or native physical-realization finding.', 'mathematical_executions': 0, 'editable_prompts_changed': []})
print(json.dumps(pin(out)))
