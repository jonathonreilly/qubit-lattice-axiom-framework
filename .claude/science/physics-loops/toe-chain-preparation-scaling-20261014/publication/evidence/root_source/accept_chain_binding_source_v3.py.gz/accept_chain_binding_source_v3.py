from chain_common import *
import ast

require_campaign_active()
source = N / 'chain_binding_source_v3'
prior = N / 'chain_binding_source_v2'
freeze = read_json(source / 'FINAL_FREEZE.json')
assert pin(source / 'FINAL_FREEZE.json')['sha256'] == 'e5db26b252bfc634a50c9d34caf233ae1e210baaec78f32141bd5153a6497680'
assert {str(path.relative_to(source)) for path in source.rglob('*') if path.is_file()} == {row['path'] for row in freeze['members']} | {'FINAL_FREEZE.json'}
for row in freeze['members']:
    check_pin(source / row['path'], row)
mapping = read_json(source / 'SOURCE_MAP.json')
functions = []
for row in mapping['programs']:
    old = (prior / row['path']).read_bytes()
    new = (source / row['path']).read_bytes()
    assert hashlib.sha256(old).hexdigest() == row['old_sha256']
    assert hashlib.sha256(new).hexdigest() == row['current_sha256']
    for function in row.get('functions', []):
        for raw, key in [(old, 'old'), (new, 'current')]:
            section = function[key]
            assert hashlib.sha256(raw[section['byte_start_0']:section['byte_end_exclusive']]).hexdigest() == section['sha256']
        if function['status'] == 'exact reuse':
            assert function['old']['sha256'] == function['current']['sha256']
        functions.append([row['path'], function['name'], function['status']])
    if row['path'].endswith('.py'):
        ast.parse(new)
evidence = read_json(source / 'REPAIR_EVIDENCE_MAP.json')
for row in evidence['entries']:
    check_pin(row['origin'], row)
    check_pin(source / row['stored_path'], row)
check_pin(source / 'V2_TO_V3.diff', mapping['diff'])
write_json(D / 'BINDING_SOURCE_V3_ROOT_ACCEPTANCE.json', {'utc': now().isoformat(), 'freeze': pin(source / 'FINAL_FREEZE.json'), 'full_current_programs_and_changed_functions_read': True, 'complete_diff_and_guide_read': True, 'changed_logic': 'Normalize only the new SUFFIX wrapper to exactly one LF, including the actual zero-LF case; validate its exact maximal LF tail. Preserve the original failed source and streams.', 'raw_mathematical_changes': [], 'function_maps_verified': functions, 'exact_repair_evidence_copies': len(evidence['entries']), 'nonfatal_existing_regex_warning': 'Preserved, no unrelated code repair.', 'approved_for_actual_binding_run': True, 'mathematical_predicates_executed': 0, 'editable_prompts_changed': []})
print(json.dumps(pin(D / 'BINDING_SOURCE_V3_ROOT_ACCEPTANCE.json')))
