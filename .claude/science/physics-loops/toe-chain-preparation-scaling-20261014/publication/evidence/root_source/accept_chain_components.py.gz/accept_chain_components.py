from pathlib import Path
import ast,hashlib
from common import N,pin,check_pin,read_json,write_json,now
P=N/'chain_scaling_publication_components';D=N/'publication_integration/chain';D.mkdir(exist_ok=True)
freeze=pin(P/'FINAL_FREEZE.json');assert freeze['sha256']=='659b6e517f8fff8939447a25b7539f97f6cefbeb8d7b41acfcbff5e4c941776f'
m=read_json(P/'FINAL_FREEZE.json');names={r['path'] for r in m['members']}
assert {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}==names|{'FINAL_FREEZE.json'}
assert not any(f.is_symlink() for f in P.rglob('*'))
for r in m['members']:check_pin(P/r['path'],r)
program_map=read_json(P/'PROGRAM_MAP.json');assert pin(P/'PROGRAM_MAP.json')['sha256']=='ecde2969f4959456069a16723902a2e6687cc48c03a5f0cf1159341349bee92f'
for r in program_map['programs']:
 check_pin(P/r['path'],r);text=(P/r['path']).read_text();lines=text.splitlines(True)
 parts=[]
 for s in r['top_level_partition']:
  b=''.join(lines[s['start_line']-1:s['end_line']]).encode();assert len(b)==s['bytes'] and hashlib.sha256(b).hexdigest()==s['sha256'];parts.append(b)
 assert b''.join(parts)==text.encode()
 tree=ast.parse(text);assert len(tree.body)==len(r['all_top_level_statements'])
 for node,part in zip(tree.body,r['all_top_level_statements']):
  assert hashlib.sha256(ast.get_source_segment(text,node).encode()).hexdigest()==part['syntax_sha256']
for r in read_json(P/'FRAMING_MAP.json')['new_prose']:check_pin(P/r['path'],r)
actual=read_json(P/'ACTUAL_EXECUTION_INDEX.json');assert len(actual['complete_recorded_runs'])==11
for r in actual['complete_recorded_runs']:
 d=P/r['path'];rec=read_json(d/'RECEIPT.json')
 assert pin(d/'executed_source.py')['sha256']==rec['source_sha256_before']==rec['source_sha256_after']
 for stream in ['stdout','stderr']:check_pin(d/(stream+'.txt'),rec[stream])
 assert rec['exit_code']==r['exit_code']
check=read_json(N/'runs/chain_components_source_check/EXECUTION.json');assert check['exit_code']==0
read_json(N/'runs/chain_components_source_check/stdout')
r={'utc':now().isoformat(),'disposition':'Accept exact unbound source components for root publication derivative; actual canonical binding and integration remain pending.','freeze':freeze,'complete_files':len(names)+1,'complete_current_programs_read':[{'path':p['path'],'bytes':p['bytes'],'sha256':p['sha256']} for p in program_map['programs']],'complete_new_framing_read':read_json(P/'FRAMING_MAP.json')['new_prose'],'complete_actual_source_processes_and_streams_reviewed':11,'identity_rejections':2,'mapping_failure_and_complete_repair_preserved':True,'root_source_check':pin(N/'runs/chain_components_source_check/EXECUTION.json'),'reused_math_review':{'acceptance':'3787850cc78f5653bf5ed918e2ab7072b0cfaa4a8ff044d3e4cf09152ba91259','root_argument':'e94339ebe1787aac242d0340fddd6c2616f3e8d22bc837bdb8f0746def664e3f','separate_argument':'e734f3f4d1ef21b77dea5db767355f8abdd5caa44b54118b7ab053caa03c9c55','comparison':'2ace6b191f80514c24dec8a46b2e113beddf9db1036f47e70163c1dad240c68c','scope':'unchanged complete arguments, prior checked premises and source-exposed reviews; no new blind/model-diverse validation'},'required_derivative_changes':['Use full-space norm bound M^7 without implying the actual scalar has the same leading power.','Say supplied full old/reference marginal certificate rather than ambiguously calling it the reference marginal.','Replace null parent/status fields using only actual first-publication bytes, proof intervals and observed PR/child facts.','Relocate and verify all source/metadata links and declared canonical inputs.'],'source_program_scope':'Capture, byte reconstruction, maps and rejection controls only; no canonical driver or mathematics.','coverage_limitation':'One initial aggregate metadata display was truncated; it was not counted as complete. All seven program sources, eight new prose files, actual streams and repair diffs were then read completely, and complete maps are deterministically bound here.','new_mathematical_executions':0,'retained_audit':False,'editable_prompt_files_changed':[]}
write_json(D/'COMPONENT_ROOT_ACCEPTANCE.json',r);print({'acceptance':pin(D/'COMPONENT_ROOT_ACCEPTANCE.json'),'files':len(names)+1,'programs':len(program_map['programs']),'actual_source_processes':11,'publication':'pending'})
