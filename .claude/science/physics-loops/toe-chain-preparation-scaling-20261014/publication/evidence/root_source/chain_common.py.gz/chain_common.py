from common import *

D = N / 'publication_integration/chain'
NOTE = 'docs/CHAIN_PREPARATION_MOMENT_SCALING_BOUNDED_THEOREM_NOTE_2026-10-14.md'
HELPER = 'scripts/chain_preparation_moment_scaling_identity_2026_10_14.py'
PACKET = '.claude/science/physics-loops/toe-chain-preparation-scaling-20261014'
PARENT = 'docs/MULTI_PORT_PREPARATION_ENERGY_MOMENTS_BOUNDED_THEOREM_NOTE_2026-10-14.md'
CLAIM = 'chain_preparation_moment_scaling_bounded_theorem_note_2026-10-14'
PARENT_CLAIM = 'multi_port_preparation_energy_moments_bounded_theorem_note_2026-10-14'
BRANCH = 'physics-loop/toe-chain-preparation-scaling-20261014'
BASE_BRANCH = 'physics-loop/toe-preparation-moments-20261014'
BASE_HEAD = '84d28d386cf8d8dbbdd4506387ad18296161fe53'

def check_installed():
    prepared = read_json(D / 'PREPARED_SOURCE.json')
    assert git_read('rev-parse', 'HEAD').decode().strip() == BASE_HEAD
    for name, row in prepared['installed_pins'].items():
        check_pin(W / name, row)
    return prepared
