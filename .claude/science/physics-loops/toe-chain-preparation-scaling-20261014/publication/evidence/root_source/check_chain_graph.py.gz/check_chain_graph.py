from chain_common import *
import shutil

require_campaign_active()
check_installed()
g = read_json(W / 'docs/audit/data/citation_graph.json')
old = read_json(D / 'base_graph.json')
assert set(g['nodes']) == set(old['nodes']) | {CLAIM}
assert all(g['nodes'][key] == value for key, value in old['nodes'].items())
node = g['nodes'][CLAIM]
assert node['deps'] == [PARENT_CLAIM] and node['path'] == NOTE and node['runner_path'] == HELPER
key = lambda value: json.dumps(value, sort_keys=True)
edge = {'from': CLAIM, 'to': PARENT_CLAIM}
assert sorted(map(key, g['edges'])) == sorted(list(map(key, old['edges'])) + [key(edge)])
assert g['roots'] == old['roots']
run(D, 'write_graph_manifest', ['python3', 'docs/audit/scripts/write_citation_graph_manifest.py'])
m = read_json(W / 'docs/audit/data/citation_graph_manifest.json')
prior = read_json(D / 'base_graph_manifest.json')
assert all(m['nodes'][k] == v for k, v in prior['nodes'].items())
assert m['node_count'] == len(g['nodes']) and m['edge_count'] == len(g['edges'])
for filename in ['citation_graph.json', 'citation_graph_manifest.json']:
    shutil.copyfile(W / 'docs/audit/data' / filename, D / ('after_' + filename))
record = {'utc': now().isoformat(), 'complete_old_nodes_preserved': len(old['nodes']), 'complete_old_edges_preserved': len(old['edges']), 'roots_unchanged': True, 'new_node': node, 'new_edge': edge, 'graph': pin(D / 'after_citation_graph.json'), 'manifest': pin(D / 'after_citation_graph_manifest.json'), 'scope': 'Full old graph objects unchanged; one new direct theorem edge. No audit status change.'}
write_json(D / 'GRAPH_VERIFICATION.json', record)
print(json.dumps(record))
