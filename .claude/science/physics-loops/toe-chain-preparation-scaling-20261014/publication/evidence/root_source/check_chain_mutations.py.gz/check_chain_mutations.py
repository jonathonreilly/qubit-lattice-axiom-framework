from chain_common import *
import ast, gzip, shutil

require_campaign_active()
prepared = check_installed()
source = Path(prepared['output_directory']) / 'payload'
manifest_path = PACKET + '/IDENTITY_MANIFEST.json'

def reassign(path, name, value):
    text = path.read_text()
    lines = text.splitlines(True)
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    lines[node.lineno - 1:node.end_lineno] = [name + ' = ' + repr(value) + '\n']
    path.write_text(''.join(lines))

def refresh_outer(root, changed):
    manifest = read_json(root / manifest_path)
    for name in changed:
        manifest['members'][name] = {key: pin(root / name)[key] for key in ['bytes', 'sha256']}
    write_json(root / manifest_path, manifest)
    reassign(root / HELPER, 'MANIFEST_SHA', pin(root / manifest_path)['sha256'])

cases = ['manifest_anchor', 'note_byte', 'decoded_original', 'archive_mapping', 'group_membership', 'receipt_fact', 'parent_clause', 'canonical_parent', 'body_interval', 'framing_lf', 'declared_read']
results = []
for case in cases:
    root = D / 'integrity_fixtures' / case
    assert not root.exists()
    shutil.copytree(source, root)
    (root / PARENT).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(W / PARENT, root / PARENT)
    changed = []
    if case == 'manifest_anchor':
        path = root / manifest_path
        path.write_bytes(path.read_bytes() + b' ')
        expected = 'Identity manifest changed'
    elif case == 'note_byte':
        path = root / NOTE
        raw = path.read_bytes()
        path.write_bytes(b'!' + raw[1:])
        expected = 'Declared byte identity changed: ' + NOTE
    elif case in ['decoded_original', 'archive_mapping', 'group_membership']:
        name = PACKET + '/ARCHIVE_MAP.json'
        value = read_json(root / name)
        logical = next(key for key in value['members'] if key.startswith('source/archive/objects/'))
        item = value['members'][logical]
        if case == 'decoded_original':
            physical = item['stored_path']
            path = root / physical
            path.write_bytes(gzip.compress(gzip.decompress(path.read_bytes()) + b'!', mtime=0))
            item['stored_bytes'] = pin(path)['bytes']
            item['stored_sha256'] = pin(path)['sha256']
            changed.append(physical)
            expected = 'Decoded original changed'
        elif case == 'archive_mapping':
            item['encoding'] = 'unlabelled'
            expected = 'Archive mapping changed'
        else:
            del value['members'][logical]
            expected = 'Complete archived group membership changed'
        write_json(root / name, value)
        changed.append(name)
    elif case in ['receipt_fact', 'parent_clause']:
        name = PACKET + '/ACTUAL_BINDING.json'
        value = read_json(root / name)
        if case == 'receipt_fact':
            value['evidence'][0]['matches']['/parent/head_sha'] = '/facts/parent/head_ref'
            expected = 'Receipt facts differ'
        else:
            value['parent_maps'][0]['byte_end_exclusive'] += 1
            expected = 'Complete parent theorem extraction changed'
        write_json(root / name, value)
        changed.append(name)
    elif case == 'canonical_parent':
        path = root / PARENT
        raw = path.read_bytes()
        offset = read_json(root / PACKET / 'ACTUAL_BINDING.json')['parent_maps'][0]['byte_start_0']
        path.write_bytes(raw[:offset] + b'!' + raw[offset + 1:])
        changed.append(PARENT)
        expected = 'Actual canonical parent differs from dated bytes'
    elif case == 'body_interval':
        name = PACKET + '/BODY_MAP.json'
        value = read_json(root / name)
        part = next(row for row in value['parts'] if row['kind'] != 'new_framing')
        part['source_byte_end_exclusive'] += 1
        write_json(root / name, value)
        changed.append(name)
        expected = 'Original interval map was changed'
    elif case == 'framing_lf':
        name = PACKET + '/PUBLICATION_RENDERING.json'
        value = read_json(root / name)
        suffix = next(row for row in value['framing_edits'] if row['label'] == 'SUFFIX.md')
        repair = next(row for row in suffix['storage_changes'] if 'ending_before' in row)
        repair['ending_after'] = '\n\n'
        write_json(root / name, value)
        changed.append(name)
        expected = 'Invalid final-wrapper-only LF repair'
    else:
        reassign(root / HELPER, 'AUDIT_INPUT_PATHS', [name for name in prepared['canonical_inputs'] if name != manifest_path])
        expected = 'Literal declared input closure changed'
    if changed:
        refresh_outer(root, changed)
    output = json.loads(run(D / 'integrity_runs', case, ['python3', str(Path(__file__).with_name('run_identity_fixture.py')), '--runner', str(root / HELPER), '--repo', str(root)], expected=(1,)))
    assert output['type'] == 'ValueError' and output['reason'] == expected, (case, output, expected)
    results.append({'case': case, 'expected_reason': expected, 'actual': output, 'execution': pin(D / 'integrity_runs' / case / 'EXECUTION.json')})
check_installed()
write_json(D / 'INTEGRITY_CONTROLS.json', {'utc': now().isoformat(), 'scope': 'Scratch source-integrity mutations only; no mathematical or physical controls.', 'results': results, 'canonical_source_unchanged': True, 'mathematical_predicates_executed': 0})
print(json.dumps({'actual_rejections': len(results), 'record': pin(D / 'INTEGRITY_CONTROLS.json')}))
