from chain_common import *
import gzip

require_campaign_active()
prepared = check_installed()
wrapper = read_json(D / 'WRAPPER_REVIEW_ACCEPTANCE.json')
assert wrapper['material_defect'] is False
for row in wrapper['sources']:
    check_pin(row['path'], row)
out = W / PACKET / 'publication'
assert not out.exists()
out.mkdir()
archive = []

def preserve(source, logical):
    source = Path(source)
    target = out / 'evidence' / (logical + '.gz')
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    original = source.read_bytes()
    target.write_bytes(gzip.compress(original, mtime=0))
    assert gzip.decompress(target.read_bytes()) == original
    archive.append({'logical_path': logical, 'original': pin(source), 'stored_path': str(target.relative_to(W)), 'stored': pin(target), 'codec': 'gzip'})

for name in ['COMPONENT_ROOT_ACCEPTANCE.json', 'BINDING_SOURCE_ROOT_ACCEPTANCE.json', 'BINDING_SOURCE_V3_ROOT_ACCEPTANCE.json', 'ACTUAL_BINDING.json', 'ACTUAL_BINDING_RECEIPT.json', 'BOUND_SOURCE_REVIEW.json', 'PREPARED_SOURCE.json', 'INTEGRITY_CONTROLS.json', 'CANONICAL_RESULT.json', 'CANONICAL_EXECUTION.json', 'BASE_GRAPH_BINDING.json', 'GRAPH_VERIFICATION.json', 'WRAPPER_REVIEW_ACCEPTANCE.json']:
    preserve(D / name, 'root_records/' + name)
for name in ['common.py', 'chain_common.py', 'accept_chain_components.py', 'accept_chain_binding_source_v2.py', 'accept_chain_binding_source_v3.py', 'review_chain_bound_source.py', 'install_chain.py', 'check_chain_mutations.py', 'run_identity_fixture.py', 'execute_chain_cache.py', 'check_chain_graph.py', 'package_chain.py', 'verify_stage_chain.py', 'publish_chain.py']:
    preserve(Path(__file__).parent / name, 'root_source/' + name)
preserve(N / 'run.py', 'root_source/campaign_recorder.py')
preserve(N / 'bootstrap/SOURCE_SNAPSHOT.json', 'root_records/instruction_source_snapshot.json')
for label in ['chain_actual_binding', 'chain_binding_source_v2_accept', 'chain_bound_source_v2_build', 'chain_fresh_fetch', 'chain_binding_source_v3_accept', 'chain_bound_source_v3_build', 'chain_bound_source_review', 'chain_install', 'chain_integrity_controls', 'chain_canonical_cache', 'chain_graph_after', 'chain_graph_verification']:
    directory = N / 'runs' / label
    assert directory.is_dir(), label
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            preserve(path, 'executions/' + label + '/' + str(path.relative_to(directory)))
for group in ['parent_before_install', 'integrity_runs', 'write_graph_manifest']:
    for path in sorted((D / group).rglob('*')):
        if path.is_file():
            preserve(path, 'executions/' + group + '/' + str(path.relative_to(D / group)))
for path in sorted((N / 'chain_wrapper_check').rglob('*')):
    if path.is_file():
        preserve(path, 'wrapper_check/' + str(path.relative_to(N / 'chain_wrapper_check')))
source = Path(prepared['output_directory'])
for name in ['BUILD_REPORT.json', 'OUTPUT_MANIFEST.json']:
    preserve(source / name, 'bound_output/' + name)
write_json(out / 'EVIDENCE_MAP.json', {'scope': 'Exact original source and execution evidence; explicit lossless gzip storage.', 'records': archive})
base = {name: pin(W / name) for name in prepared['installed_paths'] + [PARENT]}
mutations = []
for case in read_json(D / 'INTEGRITY_CONTROLS.json')['results']:
    root = D / 'integrity_fixtures' / case['case']
    changes = []
    for name, original in base.items():
        actual = pin(root / name)
        if actual['sha256'] == original['sha256']:
            continue
        target = out / 'mutation_objects' / (actual['sha256'] + '.gz')
        if not target.exists():
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(gzip.compress((root / name).read_bytes(), mtime=0))
        changes.append({'path': name, 'before': original, 'after': actual, 'stored_path': str(target.relative_to(W)), 'stored': pin(target), 'codec': 'gzip'})
    mutations.append({'case': case['case'], 'expected_reason': case['expected_reason'], 'changed_files': changes})
write_json(out / 'MUTATION_RECONSTRUCTION.json', {'base': base, 'cases': mutations, 'scope': 'Every scratch case reconstructs from the pinned canonical input tree plus exact replacement bytes. Zero mathematical tests.'})
check_installed()
write_json(D / 'PUBLICATION_EVIDENCE_PACKAGE.json', {'utc': now().isoformat(), 'records': len(archive), 'files': {str(path.relative_to(W)): pin(path) for path in out.rglob('*') if path.is_file()}, 'canonical_proof_or_input_changes': []})
print(json.dumps({'archived_records': len(archive), 'mutation_cases': len(mutations), 'package': pin(D / 'PUBLICATION_EVIDENCE_PACKAGE.json')}))
