from chain_common import *
import sys

require_campaign_active()
v = read_json(D / 'STAGED_VERIFICATION.json')
assert git_read('branch', '--show-current').decode().strip() == BRANCH
assert git_read('rev-parse', 'HEAD').decode().strip() == v['base'] == BASE_HEAD
assert not git_read('diff', '--name-only', '-z')
assert set(git_read('diff', '--cached', '--name-only', '-z').decode().rstrip('\0').split('\0')) == set(v['staged_pins'])
for name, row in v['staged_pins'].items():
    check_pin(W / name, row)
    assert hashlib.sha256(git_read('show', ':' + name)).hexdigest() == row['sha256']
sys.path.insert(0, str(W / 'scripts'))
import runner_cache
assert runner_cache.cache_status(HELPER) == 'fresh'
parent = json.loads(run(D, 'parent_before_publish', ['gh', 'pr', 'view', '9575', '--json', 'number,url,state,isDraft,headRefName,headRefOid']))
assert parent['state'] == 'OPEN' and parent['isDraft'] is False and parent['headRefOid'] == BASE_HEAD and parent['headRefName'] == BASE_BRANCH
existing = json.loads(run(D, 'existing_child_pr', ['gh', 'pr', 'list', '--state', 'open', '--head', BRANCH, '--json', 'number,url,isDraft,headRefOid']))
assert existing == [], 'Existing PR must be reused; no duplicate creation'
run(D, 'commit', ['git', 'commit', '-m', 'Add checked chain preparation-moment scaling bounds'])
head = git_read('rev-parse', 'HEAD').decode().strip()
assert git_read('show', '-s', '--format=%P', 'HEAD').decode().strip() == BASE_HEAD
assert not git_read('status', '--porcelain', '-z')
for name, row in v['staged_pins'].items():
    assert hashlib.sha256(git_read('show', 'HEAD:' + name)).hexdigest() == row['sha256']
changed = git_read('diff', '--name-only', '-z', BASE_HEAD + '..HEAD').decode().rstrip('\0').split('\0')
numstat = git_read('diff', '--numstat', '-z', BASE_HEAD + '..HEAD').decode().rstrip('\0').split('\0')
assert set(changed) == set(v['staged_pins']) and len(changed) == len(numstat) == v['paths']
run(D, 'committed_diff_check', ['git', 'diff', '--check', BASE_HEAD + '..HEAD'])
write_json(D / 'COMMIT.json', {'utc': now().isoformat(), 'head': head, 'tree': git_read('rev-parse', 'HEAD^{tree}').decode().strip(), 'parent': BASE_HEAD, 'delta_paths': changed, 'independent_numstat_count': len(numstat), 'verification': pin(D / 'STAGED_VERIFICATION.json'), 'clean': True})
run(D, 'push', ['git', 'push', '-u', 'origin', BRANCH])
urlbase = 'https://github.com/jonathonreilly/qubit-lattice-axiom-framework/blob/' + head + '/'
links = {label: urlbase + path for label, path in [('Theorem', NOTE), ('Source checker', HELPER), ('Canonical output', 'logs/runner-cache/' + Path(HELPER).stem + '.txt'), ('Handoff', PACKET + '/HANDOFF.md'), ('Physical trace', PACKET + '/TRACE_GATE.md'), ('Review and verification', PACKET + '/REVIEW_HISTORY.md'), ('Complete source map', PACKET + '/ARCHIVE_MAP.json')]}
body = '''Local preparation errors become more costly as the restricted noncommuting chain grows. This note publishes the checked sufficient scalar mean/variance budgets under Delta=D M^6: full old/reference marginal error epsilon=O(M^-2) and per-auxiliary excitation nu=O(M^-20), or nu=O(M^-14) with the separately supplied [sigma,P]=0 condition. Complete constants, mean-only cases and counterexamples remain in the unchanged accepted arguments.

The sole direct mathematical parent is the preparation-moment theorem in #9575, including its complete de7 and 79d clauses. This regular PR is stacked on `physics-loop/toe-preparation-moments-20261014`. Q-Q coherences remain; reference-valued centered second records still pay Delta*kappa*epsilon_R. Rates are sufficient, not optimal. Native preparation, full reference certification, physical energy identification, available strength caps and reader/reset supply remain open or supplied.

'''
body += 'Validation: complete changed-source and premise review; all 452 frozen component originals preserved; eleven corrupted-source controls rejected; fresh canonical identity envelope; one added graph node/edge with all ' + str(v['graph_delta']['old_complete_nodes_preserved']) + ' old nodes and ' + str(v['graph_delta']['old_complete_edges_preserved']) + ' edges unchanged; vocabulary, Python compilation and exact ' + str(v['paths']) + '-file staged/committed delta checks. The primary executes zero mathematical predicates. Focused existing-ledger compatibility returned checked=[], failures=[] and control_failures=[]; that empty selection audits no scientific claim. The independently prepared analytic argument and subsequent source-exposed checks retain their actual exposure limits.\n\n'
body += 'The first binding builder failed before output creation on a final-newline assumption. The exact failed source and streams are preserved; the narrow wrapper repair and final checks do not alter any mathematical body. Combined current-main landing validation and independent retained audit remain pending. No science merge, main push, applied audit verdict, physical axiom or editable-prompt change.\n\n'
body += ' · '.join('[' + label + '](' + url + ')' for label, url in links.items()) + '\n'
(D / 'PR_BODY.md').write_text(body)
require_campaign_active()
created = run(D, 'create_regular_pr', ['gh', 'pr', 'create', '--base', BASE_BRANCH, '--head', BRANCH, '--title', '[physics-loop] toe-chain-preparation-scaling: bounded_theorem / conditional-support', '--body-file', str(D / 'PR_BODY.md')]).decode().strip()
pr = json.loads(run(D, 'verify_created_pr', ['gh', 'pr', 'view', created, '--json', 'number,url,state,isDraft,headRefOid,headRefName,baseRefName,mergeStateStatus']))
assert pr['state'] == 'OPEN' and pr['isDraft'] is False and pr['headRefOid'] == head and pr['baseRefName'] == BASE_BRANCH
write_json(D / 'PUBLICATION.json', {'utc': now().isoformat(), 'pr': pr, 'commit': pin(D / 'COMMIT.json'), 'body': pin(D / 'PR_BODY.md'), 'verification': pin(D / 'STAGED_VERIFICATION.json'), 'note': pin(W / NOTE), 'runner': pin(W / HELPER), 'science_merged': False, 'editable_prompts_changed': []})
print(json.dumps(pr))
