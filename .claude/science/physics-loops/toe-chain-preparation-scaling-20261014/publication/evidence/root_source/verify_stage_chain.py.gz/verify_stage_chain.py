from chain_common import *
import sys

require_campaign_active()
prepared = check_installed()
graph = read_json(D / 'GRAPH_VERIFICATION.json')
controls = read_json(D / 'INTEGRITY_CONTROLS.json')
assert len(controls['results']) == 11
assert read_json(D / 'WRAPPER_REVIEW_ACCEPTANCE.json')['material_defect'] is False
packet = W / PACKET
handoff = '''# Chain preparation-scaling publication handoff

This is a static publication snapshot. The sole current campaign checkpoint remains toe-dynamics-bridge-20261009/STATE.yaml and HANDOFF.md in the checkpoint worktree. The fixed campaign deadline is 2026-10-15T21:43:09Z. No science merge is authorized.

The checked result gives sufficient local auxiliary-preparation budgets for the same installed Hamiltonian on the restricted reserved-strip chain. For M>=1, Delta=D M^6 and bounded target coefficients, the simultaneous scalar mean/variance conditions use full old/reference marginal error epsilon=O(M^-2) and per-auxiliary excitation nu=O(M^-20). With the separately supplied [sigma,P]=0 condition, nu=O(M^-14) suffices. Constants and all endpoint conventions remain in the complete accepted arguments. Mean-only conditions differ. These are sufficient upper bounds, not optimal rates.

The sole imported canonical theorem is the preparation-moment note in regular parent PR #9575, head 84d28d386cf8d8dbbdd4506387ad18296161fe53. Its complete de7 moment and 79d restricted-chain clauses are identified in ACTUAL_BINDING.json. The be8 operator result is transitive. Git ancestry creates no additional theorem edge. This child is intentionally based on physics-loop/toe-preparation-moments-20261014.

The original candidate e94339eb, independently prepared e734f3f4 argument and accepted comparison 2ace6b19 retain their exact mathematical intervals. ARCHIVE_MAP.json preserves all 452 frozen publication-component originals, the prior binding sources and the actual binding evidence in explicitly named gzip files. The publication directory preserves root integration evidence and reconstructable integrity mutations. Historical pending text and failures remain historical. The independent argument was sealed before candidate exposure; later comparison and wrapper checks were source-exposed and use the same selected model. No model diversity or new blind numerical check is claimed.

The first v2 builder failed before creating output because replacement of the closing framing paragraph removed its final newline. The v3 repair handles zero or multiple trailing newlines and validates that exact wrapper-only operation. Original v2 source and actual failed streams are preserved. Complete mathematical bodies are unchanged. Eleven final scratch integrity controls and the canonical source-identity envelope succeeded in their stated roles: zero mathematical predicates were executed. Canonical child stderr is merged with stdout by runner_cache; no separate-child-stderr conclusion follows from an empty result.stderr.

Full old/reference certification, actual local defect bounds, native preparation/control, Hamiltonian/energy identification, reader/reset supply and available strength caps remain open or supplied. Block diagonality removes P-Q terms but preserves Q-Q coherences. Reference-valued centered second records still pay Delta*kappa*epsilon_R, bounded by D*k*M^7*epsilon_R. Scalar error budgets do not remove that cost. All-excited and coherent counterexamples retain their precise witness scope.

REVIEW_HISTORY.md records focused verification. Combined current-main landing validation and independent retained audit remain separate and pending. No editable prompt, physical axiom, audit verdict or authority surface changed; no science merge or main push is part of this publication.
'''
trace = '''# Physical-realization trace

Trace class: upstream_support. The conditional bridge is from a supplied full old/reference preparation certificate and actual local auxiliary excitation bounds to scalar mean and variance control for the same specified installed K. The eta<=4M nu conversion, Delta=D M^6 and literal restricted-chain prerequisites are explicit. The theorem quantifies preparation precision costs while retaining growing strengths and full-space norm costs.

The parent preparation-moment note supplies complete de7 and 79d clauses; no later result is imported. The new claim does not provide the preparation device or certificate. A local data marginal alone does not certify a full old/reference marginal. Correlations, Q-Q coherences, scalar shifts, baseline coupling variance, reference-valued correction terms and normalization costs cannot be silently removed.

Reachability is conditional finite error budgeting. Native realization, a common strength cap, arbitrary occupied-site packing, interacting continuum/photon identification and permanent-record supply remain unresolved. The next research decision is a concrete preparation/certification or native-control construction with independently checkable hypotheses. Counterexamples exclude only their stated optimistic rates under their stated witness families; they are not universal physical no-go results.
'''
review = '''# Chain preparation-scaling publication review

Complete current framing and its necessary parent clauses were reviewed. Accepted mathematical sources were reused at exact hashes, with complete interval reconstruction rather than numerical replay. Complete new builder/helper logic and changed functions were read. Exact inventories and unchanged-function maps were deterministically verified; truncated displays were not treated as complete review. The separate wrapper review and its exact source pins are archived. It is a source-exposed composition check, not an independent retained audit.

1. Self-containment: complete accepted candidate and independent arguments plus the comparison constants are preserved; complete de7 and 79d prerequisites are present in the actual parent note.
2. Cache/execution: literal declared inputs, a 60-second timeout and five explicit scope lines; fresh canonical envelope and eleven scratch integrity rejections. Actual failed first build and subsequent streams are preserved.
3. Claim scope: bounded_theorem / conditional-support / upstream_support. Same installed K, supplied full reference marginal and local defect bounds, restricted geometry and sufficient rates remain explicit.
4. Negative-claim gate: no universal no-go, stretch-negative or wall-exhaustion claim. Quantified counterexamples retain their witness scope. N1-N8 is not represented as run.
5. Proof obligations: candidate scaling, independent derivation and comparison acceptance retain their actual evidence; the factor 4M, coherent square-root term, Q-Q terms, constant minima and epsilon_R charge remain explicit. No new mathematical program was executed.
6. Runner validity: the primary checks byte identity, complete archive membership, dated binding evidence and exact reconstruction. Its successes are not proofs of inequalities. Mutations exercise the new source-integrity families, including the actual final-newline repair.
7. Packet completeness: all 452 component originals, previous/current binding sources and complete failed execution evidence are mapped losslessly. No extra live scientific helper output is claimed; no helper-registry change is proposed.
8. Links/graph: exactly one direct theorem citation to the actual preparation-moment parent. Full old graph nodes/edges and roots are preserved. The graph manifest is the sole audit-data exception.
9. Note structure: machine status, question/domain, complete arguments, constants, counterexamples, physical premises and review scope are present. Historical pending statements are dated source history.
10. Propose/ratify: proposed_retained is an author proposal; actual status is conditional-support. No applied audit, ledger, matrix, physical axiom or editable prompt change.
11. Facts/counts: identities, input counts and graph changes derive from actual records. Parent PR/head observations are dated. Same-model and exposure limitations remain explicit. Sufficient powers are not claimed optimal.
12. Focused pre-review: source review, canonical integrity execution, mutations, graph preservation, vocabulary, Python compilation and exact staged/committed delta checks are scoped to this publication. Full cumulative landing checks and independent retained audit remain pending; an empty existing-ledger selection audits no scientific claim.

No editable prompt files changed.
'''
for name, content in [('HANDOFF.md', handoff), ('TRACE_GATE.md', trace), ('REVIEW_HISTORY.md', review)]:
    assert not (packet / name).exists()
    (packet / name).write_text(content)
paths = sorted(set(prepared['installed_paths']) | {str(p.relative_to(W)) for p in (packet / 'publication').rglob('*') if p.is_file()} | {PACKET + '/' + name for name in ['HANDOFF.md', 'TRACE_GATE.md', 'REVIEW_HISTORY.md']} | {'docs/audit/data/citation_graph_manifest.json', 'logs/runner-cache/' + Path(HELPER).stem + '.txt'})
before = {name: pin(W / name) for name in paths}
for flag, label in [('--fix', 'vocabulary_fix'), ('--report-only', 'vocabulary_report')]:
    run(D, label, ['python3', 'scripts/vocab_lint.py', flag, *paths])
for name, row in before.items():
    check_pin(W / name, row)
python_files = [name for name in paths if name.endswith('.py')]
run(D, 'python_compile', ['python3', '-m', 'py_compile', *python_files])
sys.path.insert(0, str(W / 'scripts'))
import runner_cache
assert runner_cache.cache_status(HELPER) == 'fresh'
check_pin(W / 'docs/audit/data/citation_graph_manifest.json', graph['manifest'])
assert graph['new_node']['note_hash'] == pin(W / NOTE)['sha256']
stage_exact(paths)
status = git_read('status', '--porcelain', '-z', '--untracked-files=all')
assert {row[3:].decode() for row in status.split(b'\0') if row} == set(paths)
compat = json.loads(run(D, 'focused_compatibility', ['python3', 'docs/audit/scripts/check_changed_audit_evidence.py', '--base', 'HEAD', '--include-worktree', '--json']))
assert compat['failures'] == compat['control_failures'] == [] and compat['changed_path_count'] == len(paths)
summary = {'utc': now().isoformat(), 'base': BASE_HEAD, 'paths': len(paths), 'python_files': len(python_files), 'vocabulary_fix_and_report_exit': 0, 'vocabulary_source_drift': False, 'python_compile_exit': 0, 'canonical_cache_status': 'fresh', 'integrity_cases_rejected': len(controls['results']), 'graph_delta': {'nodes': 1, 'edges': 1, 'old_complete_nodes_preserved': graph['complete_old_nodes_preserved'], 'old_complete_edges_preserved': graph['complete_old_edges_preserved']}, 'focused_existing_ledger_compatibility': compat, 'mathematical_predicates_executed': 0, 'combined_current_main_validation': 'pending separate landing review', 'independent_retained_audit': 'not performed', 'editable_prompts_changed': []}
review_file = packet / 'REVIEW_HISTORY.md'
with review_file.open('a') as stream:
    stream.write('\nActual focused repository check:\n\n```json\n' + json.dumps(summary, indent=2) + '\n```\n\nAn empty checked list audits no existing scientific claim. This result append changes only this review record; canonical inputs remain unchanged.\n')
for flag, label in [('--fix', 'vocabulary_final_review'), ('--report-only', 'vocabulary_final_review_report')]:
    run(D, label, ['python3', 'scripts/vocab_lint.py', flag, PACKET + '/REVIEW_HISTORY.md'])
for name, row in before.items():
    if name != PACKET + '/REVIEW_HISTORY.md':
        check_pin(W / name, row)
staged = stage_exact(paths)
for name, row in staged.items():
    assert hashlib.sha256(git_read('show', ':' + name)).hexdigest() == row['sha256']
assert runner_cache.cache_status(HELPER) == 'fresh'
write_json(D / 'STAGED_VERIFICATION.json', dict(summary, staged_pins=staged, review_record=pin(review_file)))
print(json.dumps(summary))
