

## Evidence, reproduction and remaining publication obligations

The [body map](../.claude/science/physics-loops/toe-chain-preparation-scaling-20261014/BODY_MAP.json) gives exact source intervals and their positions in this note. The preserved [source map](../.claude/science/physics-loops/toe-chain-preparation-scaling-20261014/source/SOURCE_MAP.json.gz) retains every original alias and maps identical byte strings to one archive object. The complete accepted 252-file sharper-moment assembly and 158-file restricted-chain assembly are preserved, along with the 11-file independent scaling argument, 14-file comparison, dispositions and actual outer source records. Historical failed attempts retain their actual streams or their explicitly recorded limits; no retrospective launch pin is invented.

No mathematical program was executed for the scaling composition or this packaging. The general result and failure families rest on the displayed arguments and their source-exposed reviews. The archived parent controls retain their original selected scopes. The new identity-only runner checks preservation, byte reconstruction and declared source closure; its success is not a theorem proof or audit verdict.

The mathematical sources were accepted under 3787850c and the complete unbound source components under a2d2310c at 2026-10-14T22:02:40.263776+00:00. This publication rendering was constructed at 2026-10-14T22:36:42.573511+00:00 from the dated parent/child evidence above. The original unbound note and all historical pending status text remain preserved byte for byte. Canonical integration, cache/graph checks, staging and publication have separate root-owned records. This note and its identity runner confer no retained audit status or apparatus supply.
