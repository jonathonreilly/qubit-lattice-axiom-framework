# Root reproduction and handoff

These commands run source-identity and reconstruction checks only. No archived mathematical program is imported or executed. Run from this component directory; Python 3.9+ with only its standard library is sufficient. Complete source/runtime versions and raw streams are recorded under `runs/`.

```sh
python3 check_identity.py --originals
python3 build_components.py --output root_reconstruction
python3 check_identity.py --payload root_reconstruction --compare payload
```

Choose a fresh descendant output name: the helper refuses to overwrite any prior result or write outside this component root. For an immutable delivered copy, first copy the complete directory into a new authorized review destination and execute there. Omit `--originals` when the old archive root is unavailable; that mode verifies the self-contained captured bytes and makes no live-original claim. No Git or network is required.

The current actual reconstruction under `reconstruction_payload/` was produced and compared byte for byte. `SOURCE_MAP.json` maps every old logical filename to `archive/objects/<sha256>`, with its original path and any exact prior embedded-byte extraction. The two parent groups preserve all 252 and 158 accepted assembly files, including their prior source/stream/repair evidence. The current archive deduplicates only identical complete bytes. It does not rewrite historical records or upgrade their independence.

`check_identity.py` is the proposed identity-only runner component, not a scientific test. It checks every captured object, each payload file, the complete note partition, exact proof intervals and occurrences, and the intentionally unbound publication fields. Its two selected corruption fixtures demonstrate rejection of a changed note byte and an invented canonical parent, including the latter with a refreshed payload hash. Their exit-one receipts are expected integrity failures, not scientific refutations. The complete sources and raw streams are preserved.

The proposed canonical science import is one actual preparation-moment note supplying both the exact de7 and 79d clauses. No actual publication identity exists in this package. The raw be8 operator theorem remains transitive. Generic be126 is not imported into the sharper scaling argument just because it may share the future parent's note. Existing multi-port PR9574 is context, not the child's base or an extra graph edge.

Root must first review the current program/module maps, new framing and all source-only streams. A future binding derivative must preserve this complete unbound packet; obtain actual canonical parent bytes/path/hash/head/PR and actual clean child/base facts; verify the parent contains the complete de7 and 79d bodies; and expose exact source/framing/metadata differences. Current pending prose is confined to separate framing files and generated status sidecars, identified in FRAMING_BINDING_MAP.json. Rebuild the note after editing those wrappers and prove the raw mathematical intervals remain unchanged. Historical pending text inside raw proofs must stay byte-identical and explicitly historical.

No canonical install/prepare/verify driver, cache materialization, staging helper, dependency-graph writer, PR command or audit executor is supplied or executed here. Root owns any later reviewed canonical integration.
