#!/usr/bin/env python3
"""Identity-only source runner. It neither imports nor executes mathematical source code."""
from pathlib import Path
import argparse, hashlib, json, sys

P=Path(__file__).resolve().parent
class IdentityError(Exception):pass
def fail(reason):raise IdentityError(reason)
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def read_relative(root,relative):
    p=(root/relative).resolve()
    if not p.is_relative_to(root.resolve()):fail('path_escape:'+relative)
    if not p.is_file() or p.is_symlink():fail('missing_or_symlink:'+relative)
    return p.read_bytes()
def check(payload,originals=False,compare=None):
    payload=payload.resolve()
    if not payload.is_relative_to(P):fail('payload_outside_component_root')
    source_map=load(P/'SOURCE_MAP.json');rows=source_map['rows']
    if len({r['alias'] for r in rows})!=len(rows):fail('duplicate_source_alias')
    for r in rows:
        b=read_relative(P,r['stored_file'])
        if len(b)!=r['bytes'] or sha(b)!=r['sha256']:fail('source_object_identity:'+r['alias'])
        if originals:
            original=Path(r['original'])
            if not original.is_file() or sha(original.read_bytes())!=r['sha256']:fail('original_source_identity:'+r['alias'])
    objects={r['stored_file'] for r in rows}
    actual_objects={str(f.relative_to(P)) for f in (P/'archive/objects').iterdir() if f.is_file()}
    if objects!=actual_objects:fail('archive_object_membership')
    manifest=load(payload/'PAYLOAD_MANIFEST.json')
    declared={r['path'] for r in manifest['members']}|{'PAYLOAD_MANIFEST.json'}
    actual={str(f.relative_to(payload)) for f in payload.rglob('*') if f.is_file()}
    if actual!=declared:fail('payload_membership')
    for r in manifest['members']:
        b=read_relative(payload,r['path'])
        if len(b)!=r['bytes'] or sha(b)!=r['sha256']:fail('payload_identity:'+r['path'])
    note=read_relative(payload,'CANDIDATE_NOTE.md');mapping=load(payload/'BODY_MAP.json')
    if sha(note)!=mapping['note_sha256'] or len(note)!=mapping['note_bytes']:fail('note_identity')
    cursor=0;reconstructed=[]
    for part in mapping['parts']:
        source=read_relative(P,part['origin'])
        if sha(source)!=part['source_sha256']:fail('mapped_source_identity:'+part['label'])
        b=source[part['source_byte_start_0']:part['source_byte_end_exclusive']]
        if len(b)!=part['bytes'] or sha(b)!=part['body_sha256']:fail('source_interval_identity:'+part['label'])
        if part['note_byte_start_0']!=cursor:fail('noncontiguous_note_map')
        end=part['note_byte_end_exclusive']
        if note[cursor:end]!=b:fail('note_body_difference:'+part['label'])
        if part['kind']=='complete_proof' and note.count(b)!=1:fail('proof_occurrence_count:'+part['label'])
        reconstructed.append(b);cursor=end
    if cursor!=len(note) or b''.join(reconstructed)!=note:fail('complete_note_reconstruction')
    bindings=load(payload/'PUBLICATION_BINDINGS.json')
    for key in ['canonical_path','claim_id','packet_name','child_branch','base_kind','base_head','base_tree','parent_pr','child_pr']:
        if bindings[key] is not None:fail('unbound_publication_field:'+key)
    for key in ['canonical_prepare_executed','canonical_verify_executed','cache_or_graph_mutated','source_review_accepted']:
        if bindings[key] is not False:fail('unbound_execution_or_acceptance:'+key)
    deps=load(payload/'DEPENDENCIES.json');parent=deps['direct_parent']
    for key in ['canonical_path','canonical_sha256','pr','head']:
        if parent[key] is not None:fail('unbound_parent_field:'+key)
    expected=load(P/'INPUT_PLAN.json')['critical_sources']
    if {r['raw_sha256'] for r in parent['required_complete_clauses']}!={expected['moment_premise'],expected['chain_premise']}:fail('direct_source_role_identity')
    if parent['actual_publication_confirmed'] is not False or deps['expected_direct_canonical_parent_count_after_binding']!=1:fail('pending_parent_contract')
    if compare is not None:
        compare=compare.resolve()
        if not compare.is_relative_to(P):fail('comparison_outside_component_root')
        names={str(f.relative_to(compare)) for f in compare.rglob('*') if f.is_file()}
        if names!=actual:fail('reconstruction_membership')
        for n in sorted(actual):
            if read_relative(compare,n)!=read_relative(payload,n):fail('reconstruction_bytes:'+n)
    return {'identity_scope':'source bytes and mechanical reconstruction only','aliases_verified':len(rows),'unique_objects_verified':len(objects),'payload_files':len(actual),'complete_proof_bodies':2,'exact_comparison_section':1,'all_originals_checked':originals,'reconstruction_compared':compare is not None,'parent_binding':'pending','mathematical_predicates':0,'scientific_programs_executed':0,'canonical_execution':False}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--payload',default='payload');ap.add_argument('--originals',action='store_true');ap.add_argument('--compare');a=ap.parse_args()
    try:result=check(P/a.payload,a.originals,P/a.compare if a.compare else None)
    except (IdentityError,OSError,KeyError,ValueError) as e:
        print(json.dumps({'identity_result':'rejected','reason':str(e),'mathematical_predicates':0},sort_keys=True));sys.exit(1)
    print(json.dumps({'identity_result':'verified',**result},sort_keys=True))
