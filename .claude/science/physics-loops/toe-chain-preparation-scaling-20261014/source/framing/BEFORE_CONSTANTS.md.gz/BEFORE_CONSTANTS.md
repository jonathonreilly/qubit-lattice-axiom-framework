

## Explicit constants from the accepted comparison

The following exact section is extracted from the [complete source-exposed comparison](../archive/objects/2ace6b191f80514c24dec8a46b2e113beddf9db1036f47e70163c1dad240c68c). Its variables refer to the root corollary above. The full comparison also verifies the mean-only exponents and clarifies that the coherent counterexample has population `eta g_u^2/kappa` generally and exactly `eta/(4M)` under its explicitly equal couplings. Neither frozen proof required a repair.

