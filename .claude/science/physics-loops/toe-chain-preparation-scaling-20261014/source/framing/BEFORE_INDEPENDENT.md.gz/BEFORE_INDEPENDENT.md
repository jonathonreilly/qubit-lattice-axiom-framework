

## Complete separately composed derivation and failure families

This body was sealed before exposure to the root scaling candidate. The authors share earlier source/model context; this is not blind or model-diverse evidence. The exact correlated and coherent counterexamples, all constant choices and the historical pre-seal units clarification are retained in the archive.

