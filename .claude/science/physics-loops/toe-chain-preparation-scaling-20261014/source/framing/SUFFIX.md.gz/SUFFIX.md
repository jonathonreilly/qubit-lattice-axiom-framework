

## Evidence, reproduction and remaining publication obligations

The [body map](BODY_MAP.json) gives exact source intervals and their positions in this note. SOURCE_MAP.json at the component root retains every original alias and maps identical byte strings to one archive object. The complete accepted 252-file sharper-moment assembly and 158-file restricted-chain assembly are preserved, along with the 11-file independent scaling argument, 14-file comparison, dispositions and actual outer source records. Historical failed attempts retain their actual streams or their explicitly recorded limits; no retrospective launch pin is invented.

No mathematical program was executed for the scaling composition or this packaging. The general result and failure families rest on the displayed arguments and their source-exposed reviews. The archived parent controls retain their original selected scopes. The new identity-only runner checks preservation, byte reconstruction and declared source closure; its success is not a theorem proof or audit verdict.

Before canonical use, root must review this complete current package, supply and check the actual preparation-parent canonical bytes containing the exact de7 and 79d clauses, and bind the actual child/base/branch facts. A later publication derivative must preserve this unbound source freeze and expose every link, metadata or code change. No canonical installation, runner-cache regeneration, dependency-graph mutation, staging, commit, push, PR or merge is performed by these components.
