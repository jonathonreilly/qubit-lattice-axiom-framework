#!/usr/bin/env python3
"""Close current source receipts and freeze the complete source-only directory."""
from pathlib import Path
import argparse,datetime,hashlib,json
P=Path(__file__).resolve().parent
def pin(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,value):
    p=P/name;assert not p.exists(),str(p)
    p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def verify_runs():
    result=[]
    for d in sorted((P/'runs').iterdir()):
        receipt=d/'RECEIPT.json'
        if not receipt.exists():continue
        r=json.loads(receipt.read_text());src=d/'executed_source.py'
        assert pin(src)['sha256']==r['source_sha256_before']==r['source_sha256_after']
        for key in ['stdout','stderr']:
            assert pin(d/(key+'.txt'))=={k:r[key][k] for k in ['bytes','sha256']}
        expected=1 if d.name in ['05_corrupt_note','06_invent_parent'] else 0
        assert r['exit_code']==expected,(d.name,r['exit_code'])
        result.append({'path':str(d.relative_to(P)),'receipt':pin(receipt),'source':pin(src),'stdout':pin(d/'stdout.txt'),'stderr':pin(d/'stderr.txt'),'exit_code':r['exit_code'],'expected_integrity_rejection':expected==1,'scientific':False})
    return result
def inspect():
    runs=verify_runs();assert len(runs)==9
    mapping=json.loads((P/'PROGRAM_MAP.json').read_text())
    for p in mapping['programs']:assert pin(P/p['path'])=={k:p[k] for k in ['bytes','sha256']}
    for p in json.loads((P/'FRAMING_MAP.json').read_text())['new_prose']:
        assert pin(P/p['path'])=={k:p[k] for k in ['bytes','sha256']}
    put('PRE_FREEZE_CHECK.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete_recorded_runs_checked':runs,'current_program_and_framing_maps_match':True,'mathematical_predicates':0,'pending_canonical_parent':True,'old_sources_written':False})
    return {'source_closure_inspection':'verified','prior_recorded_runs':len(runs),'expected_integrity_rejections':2,'mathematical_predicates':0}
def close():
    runs=verify_runs();assert len(runs)==10
    put('ACTUAL_EXECUTION_INDEX.json',{'complete_recorded_runs':runs,'mathematical_runs':0,'expected_integrity_rejections':2,'unexpected_failures':0,'final_manifest_write':'This final metadata-only closure is performed after the ten fully recorded source processes; its command/source are identified in FINAL_FREEZE.json, without fabricating another child launch receipt.'})
    target=P/'FINAL_FREEZE.json'
    rows=[{'path':str(f.relative_to(P)),**pin(f)} for f in sorted(P.rglob('*')) if f.is_file() and f!=target]
    assert not any(f.is_symlink() for f in P.rglob('*'))
    put('FINAL_FREEZE.json',{'schema':1,'sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':rows,'member_count_excluding_this_seal':len(rows),'complete_files_including_this_seal':len(rows)+1,'total_member_bytes':sum(r['bytes'] for r in rows),'note':pin(P/'payload/CANDIDATE_NOTE.md'),'archive_objects':len(list((P/'archive/objects').iterdir())),'source_aliases':len(json.loads((P/'SOURCE_MAP.json').read_text())['rows']),'scientific_runs':0,'mathematical_predicates':0,'canonical_execution':False,'retained_audit':False,'pending_actual_preparation_parent':True,'status':'unbound source/publication components; root source review and canonical binding pending','final_metadata_writer':{'path':'finalize_components.py',**pin(P/'finalize_components.py'),'argument':'--close','execution_capture':'Actual tool result; all ten preceding source processes have separate exact-source outer receipts.'},'editable_prompt_files_changed':[]})
    for r in rows:assert pin(P/r['path'])=={k:r[k] for k in ['bytes','sha256']}
    assert {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}=={r['path'] for r in rows}|{'FINAL_FREEZE.json'}
    for f in P.rglob('*'):
        if f.is_file():f.chmod(0o444)
    return {'source_packet':'frozen','complete_files':len(rows)+1,'note':pin(P/'payload/CANDIDATE_NOTE.md'),'freeze':pin(target),'actual_recorded_source_processes':len(runs),'scientific_runs':0,'canonical_parent_binding':None}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--close',action='store_true');args=a.parse_args()
    print(json.dumps(close() if args.close else inspect(),sort_keys=True))
