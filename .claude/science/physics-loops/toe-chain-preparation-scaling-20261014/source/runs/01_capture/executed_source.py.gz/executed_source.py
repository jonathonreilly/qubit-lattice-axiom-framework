#!/usr/bin/env python3
"""Read pinned immutable sources into a deduplicated archive; execute no imported code."""
from pathlib import Path
import datetime, hashlib, json

P=Path(__file__).resolve().parent
Z=P.parent.parent/'renewal_20261013_213733'
def digest(b): return hashlib.sha256(b).hexdigest()
def write_json(path,value):
    assert not path.exists(),str(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def exact(path,expected=None):
    assert path.is_file() and not path.is_symlink(),str(path)
    b=path.read_bytes()
    if expected is not None: assert digest(b)==expected,(str(path),digest(b),expected)
    return b
rows=[];groups=[]
def archive(alias,path,expected=None,body=None,extra=None):
    assert not any(r['alias']==alias for r in rows),alias
    b=exact(path,expected) if body is None else body
    h=digest(b)
    if expected is not None: assert h==expected,(alias,h)
    stored='archive/objects/'+h
    out=P/stored
    if out.exists(): assert out.read_bytes()==b
    else:
        out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
    row={'alias':alias,'original':str(path),'bytes':len(b),'sha256':h,'stored_file':stored,'transformation':'none; complete exact bytes'}
    if extra:row.update(extra)
    rows.append(row)
    return row
def frozen_group(alias,relative,seal_name,seal_hash,expected_count):
    base=Z/relative
    seal=exact(base/seal_name,seal_hash)
    data=json.loads(seal)
    expected={r['path'] for r in data['members']}|{seal_name}
    actual={str(f.relative_to(base)) for f in base.rglob('*') if f.is_file()}
    assert actual==expected and len(actual)==expected_count,(relative,len(actual),expected_count,actual^expected)
    for r in data['members']:
        b=exact(base/r['path'],r['sha256']);assert len(b)==r['bytes']
    for name in sorted(actual):archive(alias+'/'+name,base/name)
    groups.append({'alias':alias,'original':str(base),'complete_files':len(actual),'seal_file':seal_name,'seal_sha256':seal_hash,'complete_declared_and_actual_members_equal':True})
    return base

moment=frozen_group('moment_assembly','joint_sharper_preparation_moment_source_assembly','FINAL_FREEZE.json','7b79c1d0db70b7f4c4e85966e1fad1d0124dab3653489ffb5901f0184b997349',252)
chain=frozen_group('chain_assembly','joint_multi_port_chain_placement_source_assembly','FINAL_FREEZE.json','35d97011ad15d410bc8ee607c685ea338c1c7d0f6cea158a552790c2ec6bfc1b',158)
frozen_group('scaling_independent','joint_preparation_moment_chain_scaling_independent','FINAL_FREEZE.json','268de71fa073bab40b6420bc85292cc4e74f7401256cc643b62effbaf91a29fa',11)
frozen_group('scaling_comparison','joint_preparation_moment_chain_scaling_comparison','FINAL_FREEZE.json','63a2887733f64b65b3af46c9717e80faf583b4797bfcefac1f26a2ddd13a2e29',14)

# Resolve complete original aliases through their exact archived body slices.
# An assembly's embedded proof is a byte interval, not a filesystem alias.
for namespace,base in [('moment.source',moment),('chain.source',chain)]:
    mapping=json.loads(exact(base/'SOURCE_MAP.json'))
    for r in mapping['rows']:
        full=exact(base/r['stored_file'])
        b=full[r['stored_byte_start_0']:r['stored_byte_end_exclusive']]
        assert len(b)==r['source_bytes'] and digest(b)==r['sha256'],r['alias']
        archive(namespace+'/'+r['alias'],Path(r['original']),r['sha256'],body=b,
                extra={'origin_source_map':str(base/'SOURCE_MAP.json'),'origin_stored_file':r['stored_file'],'origin_byte_start_0':r['stored_byte_start_0'],'origin_byte_end_exclusive':r['stored_byte_end_exclusive'],'original_path_preserved_as_provenance':True})

fixed=[
('scaling_root/DERIVATION.md','joint_preparation_moment_chain_scaling_candidate/DERIVATION.md','e94339ebe1787aac242d0340fddd6c2616f3e8d22bc837bdb8f0746def664e3f'),
('scaling_root/PRE_REVIEW_SEAL.json','joint_preparation_moment_chain_scaling_candidate/PRE_REVIEW_SEAL.json','a36b46b911a272783fd0c0e21eda332abc9e6b90befdea3c9955703f09f0e3fb'),
('dispositions/SCALING_ACCEPTANCE.json','PREPARATION_MOMENT_CHAIN_SCALING_ROOT_ACCEPTANCE.json','3787850cc78f5653bf5ed918e2ab7072b0cfaa4a8ff044d3e4cf09152ba91259'),
('dispositions/SCALING_REVIEW.md','PREPARATION_MOMENT_CHAIN_SCALING_ROOT_REVIEW.md','8682e1b71d250dfb7b0d41e99f4bbfdf5d7d93610e31fa33fd0732f9a7fdfa87'),
('dispositions/MOMENT_ACCEPTANCE.json','SHARPER_PREPARATION_MOMENT_ROOT_ACCEPTANCE.json','d7fa3588ccac72db8317984adab6c4e70e69c583fe404705e3659d70931c9daa'),
('dispositions/MOMENT_REVIEW.md','SHARPER_PREPARATION_MOMENT_ROOT_REVIEW.md','c93de734fa4de99742f601521b879da59bffcf49496249893bf8d832a09cba1f'),
('dispositions/MOMENT_ASSEMBLY_ACCEPTANCE.json','SHARPER_PREPARATION_MOMENT_ASSEMBLY_ROOT_ACCEPTANCE.json','825da3a22167a7f0a90639311135cfb3795f8e203d3d687d0a00bb1e73f4118e'),
('dispositions/MOMENT_ASSEMBLY_REVIEW.md','SHARPER_PREPARATION_MOMENT_ASSEMBLY_ROOT_REVIEW.md','3de73f254ff80fc554e7e07cfd4971ebd27ae0904ce8ac469355cee3bc74bef0'),
('dispositions/CHAIN_ACCEPTANCE.json','CHAIN_PLACEMENT_ROOT_ACCEPTANCE.json','8d3de83e97874aeab1ada0fc53af5b3a7c371c6080d8c411917ec1c59744fdbb'),
('dispositions/CHAIN_REVIEW.md','CHAIN_PLACEMENT_ROOT_REVIEW.md','ec1cd0da487d318548754ffe85c7a3e76c249f695ca0284d225d0a6fc0a3662b'),
('dispositions/CHAIN_ASSEMBLY_ACCEPTANCE.json','CHAIN_PLACEMENT_ASSEMBLY_ROOT_ACCEPTANCE.json','b104daaf89ec4a0fd4bc7e59a483bfb35e2e934f1d90cb39a26818173152f3ea'),
('dispositions/CHAIN_ASSEMBLY_REVIEW.md','CHAIN_PLACEMENT_ASSEMBLY_ROOT_REVIEW.md','2fac0c0ab4d5e664b969aeefdc0c5134b7c9f9095fea237ff06a4cf8f2b92f98')]
for alias,rel,h in fixed:archive(alias,Z/rel,h)

for alias,rel in [
 ('independent_seal_outer','joint_preparation_moment_chain_scaling_seal_outer'),
 ('comparison_seal_outer','joint_preparation_moment_chain_scaling_comparison_seal_outer'),
 ('moment_assembly_root_check','continuation_20261014_023239/binary_admission_publication_root_review/sharper_moment_assembly_root_2120'),
 ('chain_assembly_root_evidence','continuation_20261014_023239/chain_assembly_root_review')]:
    base=Z/rel
    files=sorted(f for f in base.rglob('*') if f.is_file())
    assert files,rel
    for f in files:archive(alias+'/'+str(f.relative_to(base)),f)
    groups.append({'alias':alias,'original':str(base),'complete_files':len(files),'scope':'complete exact necessary source/outer evidence group; no retrospective launch source pin inferred'})

critical={
 'root_corollary':'e94339ebe1787aac242d0340fddd6c2616f3e8d22bc837bdb8f0746def664e3f',
 'independent_derivation':'e734f3f4d1ef21b77dea5db767355f8abdd5caa44b54118b7ab053caa03c9c55',
 'comparison':'2ace6b191f80514c24dec8a46b2e113beddf9db1036f47e70163c1dad240c68c',
 'moment_premise':'de7e79161faf1c35941285c9670e9cc421f798c51204da139575c36870ab9976',
 'chain_premise':'79d2388a7f6e2ce36d8b1055bd2ad80149a9e5375ff7f23248391d72bf5692ff',
 'transitive_multi_port':'be8f8d49362f5d9e363bd1df8b70b6e46b475beaa52e9ee5e18e0bece4293ddc'}
for h in critical.values():assert (P/'archive/objects'/h).is_file(),h
write_json(P/'INPUT_PLAN.json',{'schema':1,'origin_root':str(Z),'groups':groups,'fixed_inputs':[{'alias':a,'relative':r,'sha256':h} for a,r,h in fixed],'critical_sources':critical,'all_old_sources_read_only':True,'scientific_execution':False})
write_json(P/'SOURCE_MAP.json',{'schema':1,'rows':rows,'alias_count':len(rows),'unique_object_count':len({r['sha256'] for r in rows}),'deduplication':'identical complete byte strings only; original logical aliases and embedded extraction provenance retained'})
write_json(P/'CAPTURE_RECEIPT.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'complete_groups':groups,'aliases':len(rows),'unique_objects':len({r['sha256'] for r in rows}),'old_files_written':0,'old_programs_executed':0,'mathematical_predicates':0,'canonical_or_git_execution':False})
print(json.dumps({'source_capture':'complete','groups':len(groups),'aliases':len(rows),'objects':len({r['sha256'] for r in rows}),'new_mathematical_runs':0,'old_files_written':0},sort_keys=True))
