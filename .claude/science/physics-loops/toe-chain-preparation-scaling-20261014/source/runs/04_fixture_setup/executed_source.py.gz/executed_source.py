#!/usr/bin/env python3
"""Create two byte/metadata integrity mutations; never alter the current payload."""
from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent
base=P/'fixtures';assert not base.exists();base.mkdir()
for name in ['note_byte_corruption','invented_parent_binding']:
    shutil.copytree(P/'payload',base/name)
note=base/'note_byte_corruption/CANDIDATE_NOTE.md'
b=note.read_bytes();assert b[:1]==b'#';note.write_bytes(b'!'+b[1:])
f=base/'invented_parent_binding/DEPENDENCIES.json'
d=json.loads(f.read_text());assert d['direct_parent']['canonical_path'] is None
d['direct_parent']['canonical_path']='docs/NOT_AN_ACTUAL_PARENT.md'
f.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
m=base/'invented_parent_binding/PAYLOAD_MANIFEST.json';manifest=json.loads(m.read_text())
for r in manifest['members']:
    if r['path']=='DEPENDENCIES.json':
        raw=f.read_bytes();r['bytes']=len(raw);r['sha256']=hashlib.sha256(raw).hexdigest()
m.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
expected={'note_byte_corruption':{'exit_code':1,'reason':'payload_identity:CANDIDATE_NOTE.md'},'invented_parent_binding':{'exit_code':1,'reason':'unbound_parent_field:canonical_path'}}
(base/'EXPECTED_REJECTIONS.json').write_text(json.dumps(expected,indent=2,sort_keys=True)+'\n')
print(json.dumps({'integrity_fixtures_created':2,'current_payload_modified':False,'mathematical_predicates':0,'expected':expected},sort_keys=True))
