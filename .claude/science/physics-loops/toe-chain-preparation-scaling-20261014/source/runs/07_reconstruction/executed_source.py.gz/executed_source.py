#!/usr/bin/env python3
"""Deterministically reconstruct publication source bytes from the archived inputs."""
from pathlib import Path
import argparse, hashlib, json

P=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(value): return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def object_bytes(h):
    b=(P/'archive/objects'/h).read_bytes()
    assert sha(b)==h,h
    return b
def put(out,name,b):
    f=out/name
    assert not f.exists(),str(f)
    f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
def build(out):
    out=out.resolve()
    assert out.is_relative_to(P) and out!=P,'Output must be a new descendant of this component directory'
    assert not out.exists(),'Refusing to overwrite any previous result'
    out.mkdir(parents=True)
    sources=json.loads((P/'INPUT_PLAN.json').read_text())['critical_sources']
    parts=[];maps=[];cursor=0
    def add(kind,label,b,origin,start=0,source_hash=None):
        nonlocal cursor
        row={'kind':kind,'label':label,'origin':origin,'source_sha256':source_hash or sha(b),'source_byte_start_0':start,'source_byte_end_exclusive':start+len(b),'body_sha256':sha(b),'bytes':len(b),'note_byte_start_0':cursor,'note_byte_end_exclusive':cursor+len(b),'transformation':'none; exact bytes'}
        parts.append(b);maps.append(row);cursor+=len(b)
    def frame(name):
        f=P/'framing'/name
        add('new_framing',name,f.read_bytes(),'framing/'+name)
    frame('PREFIX.md')
    root=object_bytes(sources['root_corollary'])
    add('complete_proof','accepted_root_corollary',root,'archive/objects/'+sources['root_corollary'])
    frame('BEFORE_INDEPENDENT.md')
    independent=object_bytes(sources['independent_derivation'])
    add('complete_proof','accepted_independent_derivation',independent,'archive/objects/'+sources['independent_derivation'])
    frame('BEFORE_CONSTANTS.md')
    comparison=object_bytes(sources['comparison'])
    start_marker=b'## Explicit choices of the constants\n'
    end_marker=b'## The questioned equal-defect counterexample is valid as written\n'
    assert comparison.count(start_marker)==comparison.count(end_marker)==1
    start=comparison.index(start_marker);end=comparison.index(end_marker)
    assert start<end
    add('exact_review_section','accepted_explicit_constants',comparison[start:end],'archive/objects/'+sources['comparison'],start,sources['comparison'])
    frame('SUFFIX.md')
    note=b''.join(parts)
    assert note.count(root)==1 and note.count(independent)==1
    put(out,'CANDIDATE_NOTE.md',note)
    put(out,'BODY_MAP.json',encoded({'note_sha256':sha(note),'note_bytes':len(note),'parts':maps,'complete_proof_occurrences':{'root':1,'independent':1},'chain_proof_republished_in_note':False,'source_body_edits':0}))
    dependencies={
        'schema':1,'status':'unbound source roles; no canonical graph mutation',
        'expected_direct_canonical_parent_count_after_binding':1,
        'direct_parent':{'role':'preparation-moment theorem and included restricted-chain application','canonical_path':None,'canonical_sha256':None,'pr':None,'head':None,'actual_publication_confirmed':False,
            'required_complete_clauses':[{'role':'sharper_same_K_preparation_moments','raw_sha256':sources['moment_premise'],'object':'../archive/objects/'+sources['moment_premise']},{'role':'restricted_chain_geometry_and_cost_contract','raw_sha256':sources['chain_premise'],'object':'../archive/objects/'+sources['chain_premise']}],
            'binding_requirement':'Actual parent publication receipt and exact current canonical bytes must contain both complete raw clauses; record their full byte extractions and all wrapper changes before canonical use'},
        'transitive_sources':[{'role':'simultaneous_multi_port_operator_theorem','raw_sha256':sources['transitive_multi_port'],'direct_graph_edge_requested':False,'reason':'Already imported by the required parent clauses; source review exposure does not create another theorem dependency'}],
        'included_current_scientific_bodies':[sources['root_corollary'],sources['independent_derivation']],
        'review_section_source':sources['comparison'],'procedural_templates_are_scientific_dependencies':False,
        'branch_ancestry_is_scientific_dependency':False}
    put(out,'DEPENDENCIES.json',encoded(dependencies))
    put(out,'PUBLICATION_BINDINGS.json',encoded({'canonical_path':None,'claim_id':None,'packet_name':None,'child_branch':None,'base_kind':None,'base_head':None,'base_tree':None,'parent_pr':None,'child_pr':None,'canonical_prepare_executed':False,'canonical_verify_executed':False,'cache_or_graph_mutated':False,'source_review_accepted':False}))
    put(out,'CLAIM_STATUS.json',encoded({'scientific_source_status':'accepted conditional analytic sources','source_assembly_status':'prepared; separate root review pending','retained_audit':False,'canonical_publication':False,'required_conditions':['same installed finite K and actual scalar/reserve','normalized actual and intended preparations','complete old/reference marginal certificate','actual auxiliary excitation bounds','separately supplied joint vacuum-block diagonality for improved block budgets','fixed sufficient D and growing chain resources','separate epsilon_R record costs'],'new_mathematical_runs':0,'theorem_checker_supplied':False,'identity_only_runner_supplied':True}))
    put(out,'CONFORMANCE.json',encoded({'complete_root_and_independent_bodies_unchanged':True,'accepted_constants_section_exact':True,'full_chain_argument_in_archive':True,'placement_not_claimed_new':True,'old_reference_and_baseline_reserved':True,'reference_valued_record_terms_retained':True,'counterexamples_retained_in_full_independent_body':True,'historical_pending_text_labeled':True,'no_optimality_or_native_or_physical_energy_identification':True,'no_unreviewed_896_binder_used':True,'new_proof_obligations':[],'remaining_publication_obligations':['Root full source/component review','Actual preparation parent canonical/source/receipt binding','Actual child/base binding','Reviewed publication derivative and root-owned canonical verification']}))
    files=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(out.rglob('*')) if f.is_file()]
    put(out,'PAYLOAD_MANIFEST.json',encoded({'schema':1,'members':files,'member_count':len(files),'scope':'deterministic source payload only; no runner cache or graph execution'}))
    return {'payload':str(out.relative_to(P)),'files':len(files)+1,'note_bytes':len(note),'note_sha256':sha(note),'mathematical_predicates':0,'canonical_execution':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',default='payload');a=p.parse_args()
    print(json.dumps(build(P/a.output),sort_keys=True))
