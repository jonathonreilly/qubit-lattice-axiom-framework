#!/usr/bin/env python3
"""Generate complete source/framing maps and verify actual identity-only run records."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json
P=Path(__file__).resolve().parent
def pin(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,value):
    p=P/name;assert not p.exists(),str(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
def diff_new(path):
    return ''.join(difflib.unified_diff([],path.read_text().splitlines(True),fromfile='/dev/null',tofile=path.name)).encode()

programs=[]
for p in sorted(P.glob('*.py')):
    text=p.read_text();lines=text.splitlines(True);tree=ast.parse(text)
    spans=[];statements=[];cursor=1
    for n in tree.body:
        start=n.lineno;end=n.end_lineno
        statement={'kind':'function' if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) else 'class' if isinstance(n,ast.ClassDef) else 'module_statement','name':getattr(n,'name',type(n).__name__),'start_line':start,'end_line':end,'start_column_0':n.col_offset,'end_column_0':n.end_col_offset,'syntax_sha256':hashlib.sha256(ast.get_source_segment(text,n).encode()).hexdigest()}
        statements.append(statement)
        if spans and start<=spans[-1]['end_line']:
            spans[-1]['end_line']=max(spans[-1]['end_line'],end)
            spans[-1]['statement_indices'].append(len(statements)-1)
        else:
            if cursor<start:spans.append({'kind':'module_comments_or_spacing','start_line':cursor,'end_line':start-1})
            spans.append({'kind':'complete_statement_line_group','start_line':start,'end_line':end,'statement_indices':[len(statements)-1]})
        cursor=max(cursor,end+1)
    if cursor<=len(lines):spans.append({'kind':'module_comments_or_spacing','start_line':cursor,'end_line':len(lines)})
    for s in spans:
        b=''.join(lines[s['start_line']-1:s['end_line']]).encode();s.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    assert ''.join(''.join(lines[s['start_line']-1:s['end_line']]) for s in spans)==text
    functions=[{'name':n.name,'start_line':n.lineno,'end_line':n.end_lineno,'sha256':hashlib.sha256(''.join(lines[n.lineno-1:n.end_lineno]).encode()).hexdigest()} for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    reused=p.name=='record_run.py'
    if reused:
        prior=P.parent.parent/'renewal_20261013_213733/joint_preparation_moment_block_review/record_run.py'
        assert p.read_bytes()==prior.read_bytes()
        delta=b'';prior_info={'path':str(prior),**pin(prior),'exact_complete_reuse':True}
    else:delta=diff_new(p);prior_info=None
    diff_path='readable_diffs/'+p.name+'.diff';put(diff_path,delta)
    programs.append({'path':p.name,**pin(p),'classification':'exact recorded procedural reuse' if reused else 'new identity/source-only program','prior':prior_info,'complete_diff':diff_path,'top_level_partition':spans,'all_top_level_statements':statements,'all_function_definitions_including_nested':functions,'mathematical_predicates':0})
put('PROGRAM_MAP.json',{'scope':'complete current program functions, module statements and comment/spacing partition; no science imported','programs':programs,'full_source_delta_for_every_program':True,'896_binder_imported_or_executed':False})
repairs=[]
for name in ['map_and_verify.py','finalize_components.py']:
    old=P/'history/map_attempt01'/name;new=P/name
    delta=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='failed_map_attempt/'+name,tofile='current/'+name)).encode()
    relative='readable_diffs/'+name+'.repair.diff';put(relative,delta)
    repairs.append({'before':{'path':str(old.relative_to(P)),**pin(old)},'after':{'path':name,**pin(new)},'full_diff':relative})
put('SOURCE_REPAIRS.json',{'actual_failed_run':'runs/09_maps','repair':'Group physical source lines without losing distinct AST statement/column identities; retain the actual failed process in subsequent receipt closure','mathematical_or_payload_body_change':False,'program_changes':repairs})

framing=[]
for p in sorted((P/'framing').glob('*.md')):
    rel=str(p.relative_to(P));d='readable_diffs/'+p.name+'.diff';put(d,diff_new(p))
    framing.append({'path':rel,**pin(p),'classification':'new framing only','complete_diff':d})
for name in ['TASK_CONTRACT.md','ROOT_REPRODUCTION.md','SOURCE_EXPOSURE.md','ASSEMBLY_REPORT.md']:
    p=P/name;d='readable_diffs/'+name+'.diff';put(d,diff_new(p));framing.append({'path':name,**pin(p),'classification':'new source handoff prose','complete_diff':d})
put('FRAMING_MAP.json',{'new_prose':framing,'mathematical_body_changes':0,'body_partition':'payload/BODY_MAP.json'})
pending=[]
for rel in ['framing/PREFIX.md','framing/SUFFIX.md']:
    for number,line in enumerate((P/rel).read_text().splitlines(),1):
        if any(word in line.lower() for word in ['pending','awaiting','not yet','unbound','before canonical']):
            pending.append({'path':rel,'line':number,'exact_text':line,'future_change_requires':'Actual source/acceptance/publication facts; preserve this original and full delta, then reconstruct/check exact proof intervals'})
put('FRAMING_BINDING_MAP.json',{'replaceable_current_voice':pending,'generated_pending_fields':['payload/PUBLICATION_BINDINGS.json','payload/DEPENDENCIES.json/direct_parent','payload/CLAIM_STATUS.json/source_assembly_status'],'generator':'build_components.py','raw_historical_proof_status_must_not_change':True,'later_binding_requires_reviewed_derivative':True})

body=json.loads((P/'payload/BODY_MAP.json').read_text());note=(P/'payload/CANDIDATE_NOTE.md').read_bytes()
for r in body['parts']:
    if r['kind']=='complete_proof':
        raw=(P/r['origin']).read_bytes();embedded=note[r['note_byte_start_0']:r['note_byte_end_exclusive']]
        d=b''.join(difflib.diff_bytes(difflib.unified_diff,raw.splitlines(True),embedded.splitlines(True),fromfile=b'raw_source',tofile=b'embedded_note'))
        assert not d;put('readable_diffs/'+r['label']+'.body.diff',d)

actual=[]
for folder in sorted((P/'runs').iterdir()):
    receipt=folder/'RECEIPT.json'
    if not receipt.exists():continue
    r=json.loads(receipt.read_text());source=folder/'executed_source.py'
    assert pin(source)['sha256']==r['source_sha256_before']==r['source_sha256_after']
    for stream in ['stdout','stderr']:
        p=folder/(stream+'.txt');assert pin(p)=={k:r[stream][k] for k in ['bytes','sha256']}
    output=(folder/'stdout.txt').read_text()
    result=json.loads(output) if output else None
    expected_failure=folder.name in ['05_corrupt_note','06_invent_parent']
    historical_map_failure=folder.name=='09_maps'
    expected_reason={'05_corrupt_note':'payload_identity:CANDIDATE_NOTE.md','06_invent_parent':'unbound_parent_field:canonical_path'}.get(folder.name)
    if expected_failure:assert r['exit_code']==1 and result['reason']==expected_reason
    elif historical_map_failure:
        assert r['exit_code']==1 and not output
        assert pin(folder/'stderr.txt')['sha256']=='1934db03eadc1123afd212816c5d7fd0db07c7c6f9e16a09002d8ed5e785705e'
    else:assert r['exit_code']==0
    if not historical_map_failure:assert (folder/'stderr.txt').read_bytes()==b''
    actual.append({'run':str(folder.relative_to(P)),'receipt':pin(receipt),'source':pin(source),'stdout':pin(folder/'stdout.txt'),'stderr':pin(folder/'stderr.txt'),'exit_code':r['exit_code'],'expected_integrity_rejection':expected_failure,'expected_reason':expected_reason,'historical_mapping_failure_preserved':historical_map_failure,'scientific':False,'complete_source_and_streams_read':True})
assert len(actual)==9
put('ACTUAL_EXECUTION_INDEX.before_map.json',{'runs':actual,'mathematical_runs':0,'unexpected_failures_preserved':1,'expected_identity_rejections':2,'current_mapping_run_recorded_separately':True})

rows=json.loads((P/'SOURCE_MAP.json').read_text())['rows'];by_alias={r['alias']:r for r in rows}
roles={}
for key,alias in [('moment_parent_history','moment_assembly/HISTORICAL_RUNS.json'),('chain_parent_history','chain_assembly/HISTORICAL_RUNS.json'),('scaling_acceptance','dispositions/SCALING_ACCEPTANCE.json'),('scaling_root_review','dispositions/SCALING_REVIEW.md')]:
    r=by_alias[alias];roles[key]={'alias':alias,'object':r['stored_file'],'sha256':r['sha256']}
put('EVIDENCE_ROLES.json',{'roles':roles,'historical_parent_attempts_replayed':False,'source_aliases':len(rows),'deduplicated_objects':len({r['sha256'] for r in rows}),'counterexamples':'Complete independent body; no numeric replacement','historical_failures':'Complete inherited source assemblies and their historical run/repair maps preserved','no_historical_child_launch_pin_invented':True})

root=P.parent.parent/'correlation_worktree'
instructions={}
for rel in ['AGENTS.md','docs/ai_methodology/SCIENCE_WORKFLOW.md','docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md','docs/WRITING_VOICE_GUIDE_2026-04-25.md']:
    instructions[rel]=pin(root/rel)
installed=Path('/Users/jonreilly/.codex/skills')
for name,expected in [('ai-physics-lane-builder','ca2f2325ba990d868adef13bf2cea72d96b1a4b99bd07e84c32fa057a2c922f9'),('workhorse','9801055aea637b0e6f765f1558113a9998fe6b4d5a213b0d03d096fe96cb4cdb')]:
    p=installed/name/'SKILL.md';instructions[str(p)]=pin(p);assert pin(p)['sha256']==expected
put('INSTRUCTION_PINS.json',{'read_only_observed_origin_main':'92574ffe95192cc0724a27e1acad28e42d325115','read_only_observed_origin_ai_execution':'3a4b2c66a1ead7a1c48b4359627e968f681e3c39','fetch_performed':False,'files':instructions,'explicit_selected_model_effort_preserved':True,'editable_prompt_changes':[]})
print(json.dumps({'complete_program_maps':len(programs),'new_framing_documents':len(framing),'previous_actual_runs_verified':len(actual),'expected_rejections_verified':2,'proof_body_differences':0,'mathematical_predicates':0,'publication_bindings':'null'},sort_keys=True))
