#!/usr/bin/env python3
"""Source adaptation only. Never execute the proposed publication programs."""
from pathlib import Path
import hashlib, json
Q = Path(__file__).resolve().parent
T = Q / 'procedural_template'
CHANGES = []
def replace(text, old, new, count=1):
    actual = text.count(old)
    if count < 1 or actual != count:
        raise ValueError(f'Exact adaptation context count {actual}, expected {count}: {old!r}')
    CHANGES.append({'old':old, 'new':new, 'occurrences':count})
    return text.replace(old,new)
def between(text, start, end, body):
    a=text.index(start); z=text.index(end,a)
    return replace(text,text[a:z],body)
def main():
    text=(T/'prepare_verify_initial_state_kinetic_energy.py').read_text()
    for old,new in [
      ('toe-initial-state-kinetic-energy-20261013','toe-chirped-kinetic-energy-20261013'),
      ('finite_initial_energy_kinetic_publication_execution','chirped_kinetic_energy_publication_execution'),
      ('finite_initial_energy_kinetic_source_assembly','chirped_kinetic_law_source_assembly'),
      ('8ce9cbb235c6696f760e867192942bb2d0e85867bb333bb75671d890fa59a819','fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38'),
      ('FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json','CHIRPED_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json'),
      ('FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md','CHIRPED_SOURCE_ASSEMBLY_ROOT_REVIEW.md'),
      ('963bb68b3456a0b746f6c227156417c41c837ff7723523b84a1e2ff1e2b0d80d','fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e'),
      ('002d3585f3ca5b17ab0eaad81e03f10d97337cace053a4a2393eb6ffe539117c','3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134'),
      ('initial-state-kinetic-integrity-','chirped-kinetic-integrity-'),
      ("old['files']","old['members']"),
      ("== 52, 'Accepted source count differs'","== 161, 'Accepted source count differs'"),
      ('pure_mixed_scope_and_precision_reviewed','one_time_scope_and_BV_integrated_phase_reviewed'),
      ('negative_partial_narrowing_FAIL_and_bounded_N8_reviewed','root_independent_strength_and_phase_precision_reviewed'),
      ("'source_assembly_root_acceptance_sha256','disposition','N1','N5','N8','no_go_packet_pass'", "'source_assembly_root_acceptance_sha256','disposition','root_core_sha256',\n        'independent_core_sha256','no_go_packet_pass'"),
      ('Accepted source or negative scope differs','Accepted source or conditional scope differs'),
      ('FINITE_INITIAL_ENERGY_BRANCH_START.json','CHIRPED_BRANCH_PLAN.json'),
      ("branch['parent_pr'].endswith('/pull/9517'), 'Branch receipt differs'", "branch['parent_pr'].endswith('/pull/9517')\n         and branch['branch_created_by_source_preparer'] is False, 'Branch plan differs'"),
      (",'N8_HISTORICAL_SCAN.md'",""),
      ("'no_go_packet_pass': False, 'N1': 'FAIL: five-family minimum unmet', 'N5': 'identity-only nonexecution',", "'no_go_packet_pass': False, 'one_time_conditional_scope': True,\n        'N5': 'identity-only nonexecution',"),
      ("'Every unclassified finding fails. N1 fails the route minimum; N5 reports identity-only nonexecution; bounded N8 coverage is explicit. '", "'Every unclassified finding fails. N5 reports identity-only nonexecution; no no-go packet PASS is supplied. '")
    ]:
        text=replace(text,old,new,text.count(old))
    (Q/'prepare_verify_chirped_kinetic_energy.py').write_text(text)
    text=(T/'run_combined_validation.py').read_text()
    text=replace(text,'finite_initial_energy_kinetic_combined_validation_execution','chirped_kinetic_energy_combined_validation_execution')
    (Q/'run_combined_validation.py').write_text(text)
    text=(T/'IDENTITY_TOOL.template.py').read_text()
    for old,new in [
      ('Initial-state kinetic source identity','Chirped kinetic source identity'),
      ('toe-initial-state-kinetic-energy-20261013','toe-chirped-kinetic-energy-20261013'),
      ('8ce9cbb235c6696f760e867192942bb2d0e85867bb333bb75671d890fa59a819','fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38'),
      ('963bb68b3456a0b746f6c227156417c41c837ff7723523b84a1e2ff1e2b0d80d','fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e'),
      ('002d3585f3ca5b17ab0eaad81e03f10d97337cace053a4a2393eb6ffe539117c','3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134'),
      ("seal['files'] == members and len(members) == 52 and contract['all_files'] == 53", "seal['members'] == members and len(members) == 161 and contract['all_files'] == 162"),
      ('FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json','CHIRPED_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json'),
      ('FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md','CHIRPED_SOURCE_ASSEMBLY_ROOT_REVIEW.md'),
      ("scope['status'] == 'accepted_for_publication_preparation' and scope['publication_execution_approved_by_this_receipt']", "scope['status'] == 'accepted_for_source_only_publication_preparation' and scope['publication_execution_authorized_by_this_receipt']"),
      ("status['chirp_dependency'] is False and status['N1'].startswith('FAIL:')", "status['initial_state_dependency'] is False and status['one_time_marginals_only'] is True"),
      ('the one-pair two-particle construction was not simulated','the chirped BV secular construction was not simulated')
    ]:
        text=replace(text,old,new,text.count(old))
    text=between(text,'    closure_counts = []\n',"    edits = pinned('PUBLICATION_EDITS.json'",'''    closures = json.loads(source('IMMEDIATE_CLOSURES.json'))['closures']
    need(closures == evidence['source_provenance_closure'], 'Immediate closure selection differs')
    need([len(c['members']) for c in closures] == [26,24,32], 'Immediate closure extents differ')
    for c in closures:
        need(c['recursive'] is False and c['complete_immediate_members'] is True, 'Closure scope differs')
        archived(c['seal'])
        for name in c['members']: archived(name)
    selection = json.loads(source('SOURCE_SELECTION.json'))['sources']
    need(len(selection) == 106, 'Original source selection differs')
    for row in selection:
        b = archived(row['source'])
        need(b == source(row['archive']) and sha(b) == row['sha256'] and len(b) == row['bytes'] and len(b.splitlines()) == row['lines'], 'Original source alias differs')
    mapping = json.loads(source('SOURCE_MAP.json')); accepted = source(mapping['note']); cores = []
    need(sha(accepted) == mapping['sha256'], 'Accepted complete note differs')
    for part in mapping['pieces']:
        original = source(part['path']); a,z = part['byte_range']; l,k = part['line_range']
        need(sha(original) == part['sha256'] and len(original) == part['bytes'] and accepted[a:z] == original, 'Accepted piece differs')
        need(accepted[:a].count(b'\\n')+1 == l and accepted[:z].count(b'\\n') == k, 'Accepted piece line map differs')
        if part['kind'] != 'wrapper': cores.append(original)
    need([sha(c) for c in cores] == ['87011c662344ed684a7251f5067bb8193d156837a50a23e71fa29ccff38e92f6','279a96bc07b495a59b829cac70586ae8e115f0ddefca0d405bb15f0a7de6e95c'], 'Core order or extent differs')
''')
    (Q/'IDENTITY_TOOL.template.py').write_text(text)
    (Q/'PROGRAM_ADAPTATION.json').write_text(json.dumps({'scope':'Deterministic source text changes only; no adapted program executed','changes':CHANGES,'scientific_predicates':0},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'programs_written':3,'exact_replacement_records':len(CHANGES),'scientific_predicates':0}))
if __name__=='__main__': main()
