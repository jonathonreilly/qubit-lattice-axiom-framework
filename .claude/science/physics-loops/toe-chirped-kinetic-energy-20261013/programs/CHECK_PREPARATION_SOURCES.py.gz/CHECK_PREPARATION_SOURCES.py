#!/usr/bin/env python3
"""Read-only source reconstruction; never import or execute proposed runtime programs."""
from pathlib import Path
from urllib.parse import unquote
import argparse, ast, difflib, gzip, hashlib, json, pprint, re
Q=Path(__file__).resolve().parent;CW=Q.parent.parent/'correlation_worktree'
def raw(p):return Path(p).read_bytes()
def js(p):return json.loads(raw(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(b):return {'sha256':sha(b),'bytes':len(b),'lines':len(b.splitlines())}
def need(x,s):
    if not x:raise ValueError(s)
def diff(a,b,x,y):return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=x.encode(),tofile=y.encode(),n=3))
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--require-freeze',action='store_true');ap.add_argument('--archive-only',action='store_true',help='Reconstruct from package bytes without reading external source aliases or canonical checkout files.');args=ap.parse_args()
    spec=js(Q/'SPECIFICATIONS.json');P=Q/'payload'/spec['packet'];n=spec['notes'][0]
    need(not any(p.is_symlink() for p in Q.rglob('*')),'Source symlink')
    evidence=js(P/'EVIDENCE_MAP.json');origins={};contents={}
    for obj in evidence['objects']:
        z=raw(P/obj['path']);b=gzip.decompress(z)
        need(sha(z)==obj['stored_sha256'] and len(z)==obj['stored_bytes'] and pin(b)=={k:obj[k] for k in ['sha256','bytes','lines']},'Archive identity')
        need(obj['sha256'] not in contents,'Duplicate archive object');contents[obj['sha256']]=b
        for origin in obj['origins']:
            name=origin['path'];need(name not in origins,'Duplicate origin alias');origins[name]=b
            if not args.archive_only:need(raw(name)==b,'Live source changed: '+name)
    def historical(path):return origins[str(path)] if args.archive_only else raw(path)
    def historical_json(path):return json.loads(historical(path))
    contract=evidence['accepted_source_package'];A=Path(contract['path']);prefix=str(A)+'/'
    freeze=origins[prefix+'FINAL_FREEZE.json'];need(sha(freeze)==contract['freeze_sha256']=='fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38','Accepted seal')
    old=json.loads(freeze);need(old['members']==contract['members'] and len(old['members'])==161 and contract['all_files']==162,'Accepted extent')
    expected={r['path'] for r in old['members']}|{'FINAL_FREEZE.json'}
    if not args.archive_only:need({str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()}==expected,'Live accepted membership')
    need({p[len(prefix):] for p in origins if p.startswith(prefix)}==expected,'Archived accepted membership')
    for row in old['members']:need(pin(origins[prefix+row['path']])=={k:row[k] for k in ['sha256','bytes','lines']},'Accepted member')
    closures=historical_json(A/'IMMEDIATE_CLOSURES.json')['closures'];need(closures==evidence['source_provenance_closure'] and [len(c['members']) for c in closures]==[26,24,32],'Immediate closure extent')
    for c in closures:
        need(c['recursive'] is False and c['complete_immediate_members'] is True and c['seal'] in origins and all(p in origins for p in c['members']),'Immediate closure membership')
    selection=historical_json(A/'SOURCE_SELECTION.json')['sources'];need(len(selection)==106,'Original consumed source count')
    for row in selection:need(origins[row['source']]==historical(A/row['archive']) and pin(origins[row['source']])=={k:row[k] for k in ['sha256','bytes','lines']},'Original source selection')
    mapping=historical_json(A/'SOURCE_MAP.json');accepted=historical(A/mapping['note']);need(sha(accepted)==mapping['sha256'],'Accepted complete note')
    cores=[]
    for part in mapping['pieces']:
        b=historical(A/part['path']);a,z=part['byte_range'];l,k=part['line_range']
        need(pin(b)=={k:part[k] for k in ['sha256','bytes','lines']} and accepted[a:z]==b and accepted[:a].count(b'\n')+1==l and accepted[:z].count(b'\n')==k,'Accepted complete piece map')
        if part['kind']!='wrapper':cores.append(b)
    edits=js(P/'PUBLICATION_EDITS.json');row=edits['notes'][0];joined=b'';copied=[];wrappers={}
    need(edits['source_freeze_sha256']==contract['freeze_sha256'] and edits['additional_mathematical_body_edits']==[] and len(edits['notes'])==1,'Publication transformation scope')
    need(origins[row['accepted_candidate_path']]==accepted and sha(accepted)==row['accepted_candidate_sha256'],'Accepted note source alias')
    for part in row['pieces']:
        if part['kind']=='accepted_core_slice':
            full=origins[part['source_path']];need(sha(full)==part['source_sha256'],'Complete core input')
            b=b''.join(full.splitlines(True)[part['source_line_start']-1:part['source_line_end']]);copied.append(b)
            need(sha(b)==part['expected_slice_sha256'] and part['additional_mathematical_body_edits']==[],'Unchanged core contract')
        else:
            need(part['kind']=='publication_wrapper','Publication piece kind');b=part['text'].encode();need(raw(Q/part['wrapper_path'])==b,'Wrapper text');wrappers[part['wrapper_path']]=b
        need(pin(b)=={k:part[k] for k in ['sha256','bytes','lines']} and part['byte_offset']==len(joined) and part['first_line']==joined.count(b'\n')+1 and part['last_line']==(joined+b).count(b'\n'),'Publication complete piece map');joined+=b
    need(copied==cores and joined==raw(Q/'payload'/n['path']) and sha(joined)==row['published_sha256'] and len(joined)==row['published_bytes'] and len(joined.splitlines())==row['published_lines'],'Published note/core reconstruction')
    def checkdiff(r,before,after,readable):
        z=raw(P/r['diff']);d=gzip.decompress(z)
        need(sha(z)==r['diff_stored_sha256'] and len(z)==r['stored_bytes'] and sha(d)==r['diff_sha256'] and len(d)==r['diff_bytes'] and r['context_lines']==3,'Raw diff pins')
        need(d==diff(before,after,r['fromfile'],r['tofile']) and raw(Q/readable)==d,'Complete exact n=3 diff')
    checkdiff(row,accepted,joined,'readable_diffs/'+Path(row['diff']).name.removesuffix('.gz'))
    for r in edits['wrapper_changes']:
        a,z=r['source_line_range'];before=b''.join(accepted.splitlines(True)[a-1:z]);after=wrappers[r['publication']]
        need(sha(before)==r['source_sha256'] and sha(after)==r['publication_sha256'],'Wrapper diff inputs');checkdiff(r,before,after,'readable_diffs/'+Path(r['diff']).name.removesuffix('.gz'))
    need(js(P/'RAW_DIFF_INTEGRITY.json')['diffs']==[{k:r[k] for k in ['diff','diff_sha256','diff_bytes','diff_lines','diff_stored_sha256','stored_bytes','context_lines','fromfile','tofile']} for r in [row,*edits['wrapper_changes']]],'Raw source diff inventory')
    for r in js(P/'CORE_EXTRACTION_DIFFS.json')['diffs']:
        checkdiff(r,origins[r['source_path']],joined[r['byte_offset']:r['byte_offset']+r['bytes']],'readable_diffs/'+Path(r['diff']).name.removesuffix('.gz'));need(r['diff_bytes']==0,'Nonempty core extraction diff')
    parents=js(P/'PARENT_BINDINGS.json');need(len(parents['parents'])==4 and len(parents['canonical_core_maps'])==5,'Parent/map count')
    for r in parents['parents']:
        b=origins[r['archive_alias']] if args.archive_only else raw(CW/r['path']);need(sha(b)==r['published_sha256'] and len(b)==r['bytes'] and origins[r['archive_alias']]==b and r['base_commit']==spec['base'],'Canonical parent identity')
    for r in parents['canonical_core_maps']:
        owner=next(p for p in parents['parents'] if p['path']==r['canonical_path']);b=origins[owner['archive_alias']] if args.archive_only else raw(CW/r['canonical_path']);c=origins[r['archive_alias']];a,z=r['byte_start_inclusive'],r['byte_end_exclusive']
        need(sha(b)==r['canonical_sha256'] and sha(c)==r['core_sha256'] and b.count(c)==1 and b[a:z]==c and len(c)==r['bytes'] and len(c.splitlines())==r['lines'],'Canonical byte core map')
        need(b[:a].count(b'\n')+1==r['line_start_inclusive'] and b[:z].count(b'\n')==r['line_end_inclusive'],'Canonical line core map')
    need(parents['archived_provisional_relations']==parents['same_packet_parents']==parents['history_only_relations']==parents['standalone_hypotheses']['edges_created']==[] and parents['initial_state_dependency'] is False,'Import boundary')
    graph=js(P/'CLAIM_REGISTRY_ADDITIONS.json');need(len(graph['nodes'])==1 and graph['nodes'][0]['claim_id']==n['claim_id'] and graph['nodes'][0]['deps']==n['deps'] and graph['direct_edges']==[{'from':n['claim_id'],'to':d} for d in n['deps']] and graph['expected_delta']=={'nodes':1,'edges':4},'Proposed graph delta')
    for r in js(Q/'PROGRAM_DIFFS.json')['diffs']:checkdiff(r,raw(Q/r['template']),raw(Q/r['program']),r['readable_diff'])
    need(js(Q/'PROGRAM_DIFFS.json')==js(P/'PROGRAM_DIFFS.json'),'Program diff map copy')
    for r in js(P/'PROGRAM_ARCHIVE_INTEGRITY.json')['programs']:
        z=raw(P/r['archive']);b=gzip.decompress(z);need(pin(b)=={k:r[k] for k in ['sha256','bytes','lines']} and sha(z)==r['stored_sha256'] and len(z)==r['stored_bytes'] and b==raw(Q/r['source']),'Complete program archive')
    for r in js(Q/'TEMPLATE_SELECTION.json')['selected_files']:
        b=raw(Q/'procedural_template'/r['path']);need(pin(b)=={k:r[k] for k in ['sha256','bytes','lines']},'Selected procedural template')
    render=js(Q/'RUNNER_SOURCE_RENDERING.json');template=(Q/'IDENTITY_TOOL.template.py').read_text()
    for token,name in {'MAP_SHA':'EVIDENCE_MAP.json','EDITS_SHA':'PUBLICATION_EDITS.json','PARENTS_SHA':'PARENT_BINDINGS.json','STATUS_SHA':'SOURCE_REVIEW_STATUS.json','GRAPH_SHA':'CLAIM_REGISTRY_ADDITIONS.json'}.items():template=template.replace('__'+token+'__',sha(raw(P/name)))
    template=template.replace('__DECLARED_INPUTS__',pprint.pformat(render['inputs'],width=100)).replace('__EXTRA_PINS__',pprint.pformat(render['extra_pins'],width=100)).replace('__CLAIM__',n['claim_id'])
    rb=raw(Q/'payload'/n['runner']);need(rb==template.encode() and sha(rb)==render['runner_sha256'] and sha(raw(Q/'IDENTITY_TOOL.template.py'))==render['template_sha256'],'Literal unexecuted runner rendering')
    values={t.targets[0].id:ast.literal_eval(t.value) for t in ast.parse(rb).body if isinstance(t,ast.Assign) and isinstance(t.targets[0],ast.Name) and t.targets[0].id in ['AUDIT_TIMEOUT_SEC','AUDIT_INPUT_PATHS','EXTRA_PINS','CLAIM']}
    packets=sorted(str(p.relative_to(Q/'payload')) for p in P.rglob('*') if p.is_file());inputs=sorted(set(packets+[n['path']]+[p['path'] for p in parents['parents']]))
    need(values['AUDIT_TIMEOUT_SEC']==60 and values['CLAIM']==n['claim_id'] and values['AUDIT_INPUT_PATHS']==render['inputs']==inputs and values['EXTRA_PINS']==render['extra_pins'],'Literal declared read closure')
    need(set(render['extra_pins'])==set(packets),'Extra packet pins closure')
    for name,p in render['extra_pins'].items():need({k:pin(raw(Q/'payload'/name))[k] for k in ['sha256','bytes']}==p,'Extra packet pin')
    for p in Q.rglob('*.py'):ast.parse(raw(p),filename=str(p))
    for r in js(Q/'PROCEDURE_REUSE.json')['files']:
        b=origins[str(Path(spec['worktree'])/r['path'])] if args.archive_only else raw(CW/r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Procedure pin')
    payload=js(Q/'PAYLOAD_MANIFEST.json')['files'];need({r['path'] for r in payload}=={str(p.relative_to(Q/'payload')) for p in (Q/'payload').rglob('*') if p.is_file()},'Exact payload membership')
    binary={r['path']:r for r in js(Q/'BINARY_PAYLOAD_PINS.json')['files']};need(set(binary)=={r['path'] for r in payload if r['path'].endswith('.gz')},'Exact binary membership')
    exceptions=spec['preserved_source_whitespace'];observed=[]
    need(js(P/'SOURCE_WHITESPACE_CLASSIFICATION.json')['preserved_source_whitespace']==exceptions,'Whitespace classification supplied for runtime')
    for r in payload:
        b=raw(Q/'payload'/r['path']);need(pin(b)=={k:r[k] for k in ['sha256','bytes','lines']},'Payload pin')
        if r['path'] in binary:
            z=b;b=gzip.decompress(z);p=binary[r['path']];need(sha(z)==p['sha256']==p['stored_sha256'] and len(z)==p['bytes']==p['stored_bytes'] and sha(b)==p['raw_sha256'] and len(b)==p['raw_bytes'] and len(b.splitlines())==p['raw_lines'],'Exact binary stored/raw pins');continue
        b.decode();need(b.endswith(b'\n') and not b.endswith(b'\n\n'),'Terminal newline: '+r['path'])
        for i,line in enumerate(b.splitlines(),1):
            if line.rstrip(b' \t')!=line:observed.append({'path':r['path'],'line':i,'line_sha256':sha(line),'source_sha256':sha(b)})
    need(observed==exceptions,'Exact literal whitespace differences: '+repr(observed))
    links=[];excluded=[]
    need(js(P/'MARKDOWN_NOTATION_CLASSIFICATION.json')['exclusions']==spec['notation_exclusions'],'Exact notation classification')
    for relative in [n['path']]+[str(p.relative_to(Q/'payload')) for p in P.glob('*.md')]:
        s=raw(Q/'payload'/relative).decode()
        for row in [r for r in spec['notation_exclusions'] if r['note']==relative]:
            need(s.splitlines(True)[row['canonical_line']-1]==row['exact_line'] and s.count(row['context'])==1 and row['context'].count(row['raw_match'])==1 and row['exact_line'].count(row['raw_match'])==1,'Exact notation context changed')
            s=s.replace(row['context'],row['context'].replace(row['raw_match'],']EXACT_LATEX_NOTATION',1),1);excluded.append(row)
        s=re.sub(r'(?m)^(?: {4}|\t).*(?:\n|$)','',s);s=re.sub(r'```.*?```|~~~.*?~~~|`[^`]*`','',s,flags=re.S)
        for target in re.findall(r'\]\(([^)\s]+)\)',s):
            if target.startswith(('https://','http://','#','mailto:')):continue
            name=unquote(target.split('#',1)[0]);need(not Path(name).is_absolute(),'Absolute Markdown link')
            dest=(CW/relative).parent/name;dest=dest.resolve();need(dest.is_relative_to(CW),'Escaped Markdown link')
            rel=str(dest.relative_to(CW));external_exists=rel in {p['path'] for p in parents['parents']} if args.archive_only else dest.is_file();need((Q/'payload'/rel).is_file() or external_exists,'Broken Markdown link: '+target);links.append({'source':relative,'target':target})
    need(excluded==spec['notation_exclusions'],'Notation exclusions accounted exactly')
    stage=set(js(Q/'EXPECTED_INSTALL_AND_STAGE_PATHS.json')['paths']);want={r['path'] for r in payload}|{'logs/runner-cache/'+Path(n['runner']).stem+'.txt','docs/audit/data/citation_graph_manifest.json',spec['packet']+'/PUBLICATION_ROOT_ACCEPTANCE.json',spec['packet']+'/PUBLICATION_ASSEMBLY_REVIEW.txt'};need(stage==want,'Exact planned stage paths')
    acceptance=js(Q/'ROOT_ACCEPTANCE.template.json');need(acceptance['root_authorizes_execution'] is False and acceptance['root_execution_acceptance'] is False and acceptance['publication_source_freeze_sha256'] is None,'False acceptance placeholder')
    need(js(P/'CHIRPED_BRANCH_PLAN.json')['source_generation_current_branch_requirement'] is False and js(P/'CHIRPED_BRANCH_PLAN.json')['base']==spec['base'],'Branch source plan')
    if args.require_freeze:
        f=js(Q/'SOURCE_FREEZE.json');members={r['path'] for r in f['files']};need(len(members)==f['file_count'] and {str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file() and p!=Q/'SOURCE_FREEZE.json'}==members,'Final freeze membership')
        for r in f['files']:need(pin(raw(Q/r['path']))=={k:r[k] for k in ['sha256','bytes','lines']},'Final frozen member')
    print(json.dumps({'result':'source_reconstruction_and_identity_match','archive_objects':len(contents),'archive_aliases':len(origins),'accepted_source_files':162,'original_source_selection':106,'unchanged_cores':len(cores),'canonical_parents':4,'canonical_core_maps':5,'payload_files':len(payload),'planned_stage_files':len(stage),'declared_runner_inputs':len(inputs),'binary_payloads':len(binary),'resolved_links':len(links),'proposed_runner_and_drivers_executed':False,'mathematical_predicates':0,'require_freeze':args.require_freeze,'archive_only':args.archive_only,'external_live_sources_read':not args.archive_only},sort_keys=True))
if __name__=='__main__':main()
