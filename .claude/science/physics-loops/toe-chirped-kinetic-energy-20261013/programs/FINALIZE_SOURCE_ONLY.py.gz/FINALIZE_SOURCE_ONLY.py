#!/usr/bin/env python3
"""Render source records and proposed runner text without executing that text."""
from pathlib import Path
import ast, difflib, gzip, hashlib, json, pprint
Q=Path(__file__).resolve().parent
def raw(p):return Path(p).read_bytes()
def js(p):return json.loads(raw(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(b):return {'sha256':sha(b),'bytes':len(b),'lines':len(b.splitlines())}
def put(p,b):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def dump(p,d):put(p,json.dumps(d,indent=2,sort_keys=True)+'\n')
def text(p,s):put(p,s.strip()+'\n')
def diff(a,b,x,y):return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=x.encode(),tofile=y.encode(),n=3))
def main():
    spec=js(Q/'SPECIFICATIONS.json');packet=spec['packet'];P=Q/'payload'/packet;n=spec['notes'][0]
    # Later root-owned branch action is a procedural receipt, never an author runtime outcome.
    branch_path=Q.parent/'CHIRPED_BRANCH_CREATED.json';branch_bytes=raw(branch_path)
    if sha(branch_bytes)!='34c318ded50947ee4d654001eb38637060c9ce6da4c07c3a201c757a52a4bd4a':raise ValueError('Root branch receipt changed')
    branch=json.loads(branch_bytes)
    if branch['base']!=spec['base'] or branch['branch']!=spec['branch'] or branch['exit_code']!=0:raise ValueError('Root branch receipt scope differs')
    put(P/'CHIRPED_BRANCH_CREATED.json',branch_bytes)
    evidence=js(P/'EVIDENCE_MAP.json');alias=str(branch_path);existing=[o for o in evidence['objects'] if any(x['path']==alias for x in o['origins'])]
    if not existing:
        z=gzip.compress(branch_bytes,mtime=0);path='objects/'+sha(branch_bytes)+'.gz';put(P/path,z)
        evidence['objects'].append({**pin(branch_bytes),'path':path,'stored_sha256':sha(z),'stored_bytes':len(z),'compression':'gzip mtime=0; raw bytes unchanged','origins':[{'path':alias,'roles':['later_root_owned_branch_creation_procedural_receipt']}]})
    elif len(existing)!=1 or existing[0]['sha256']!=sha(branch_bytes):raise ValueError('Branch archive alias conflict')
    evidence['later_root_branch_receipt']={'path':alias,**pin(branch_bytes),'meaning':'Root-owned action at 14:09:08; source generation required no current-branch selection and performed no Git mutation.'}
    dump(P/'EVIDENCE_MAP.json',evidence)
    plan=js(P/'CHIRPED_BRANCH_PLAN.json');plan['later_root_creation_receipt']='CHIRPED_BRANCH_CREATED.json';plan['later_root_creation_receipt_sha256']=sha(branch_bytes);plan['historical_source_acceptance_branch_false_preserved']=True;dump(P/'CHIRPED_BRANCH_PLAN.json',plan)
    records={
      'TRACE_GATE.md':'''# Trace gate

Trace class: upstream_support. Claim type: bounded_theorem. Current surface:
conditional-support. Target physical consumer and blocker are not yet known.
The owner asked for a conditional one-time vacuum energy law for BV chirped
drives. The accepted proofs supply that bounded target under exposed premises,
with independent850's stronger profile-uniform conclusions separately assessed
by root. No physical selector, model realization or named physical blocker
is closed. `target_claim_id` and `target_blocker_text` remain null; the metadata
reachability value describes partial upstream support, not a physical closure.
Next action is root review of the exact publication source and runtime contract.
Effective retained review remains separate. See [HANDOFF](HANDOFF.md).''',
      'CLAIM_STATUS_CERTIFICATE.md':'''# Claim status certificate

Claim: chirped_kinetic_energy_bounded_theorem_note_2026-10-13.
Claim type: bounded_theorem. Artifact role: theorem.
Actual current surface: conditional-support. Bare retained is disallowed.
Independent audit is required before effective retained status.
No newly assumed physical axiom, empirical prediction, physical parameter
selector, multi-time process, W1 rate or initial-state extension is promoted.
The supplied-model/BV/frequency-gap and actual-cell hypotheses are explicit.
This certificate describes source status and is not an applied audit verdict.''',
      'ASSUMPTIONS.md':'''# Premises, exact parents and import boundary

The supplied massive free CAR model and vacuum, positive fixed m and v, fixed
general real compact smooth slots, fixed finite slow-time interval, real BV
amplitude and frequency with bounded resources and a strict gap above 2m are
premises. The phase is the integral of frequency; no reset occurs at a jump.
The pair density may vanish. Constant, jump and zero cases remain in both cores.

The exact direct canonical mathematical owners are modulated-drive,
general-compact-control, corrected-two-zero and correlation-limit notes.
`PARENT_BINDINGS.json` pins each complete canonical note and its exact parent
Git tree, plus modulated464, general470, corrected859 and correlation335.
Historical mean301 is also contained in the general note, with no fifth edge.
Corrected859 retains its special-control hypotheses where that faster route is
used; general controls use the general-control estimates. Canonical publication
does not erase the parents' original conditional premises.

Actual-cell transfer additionally assumes the exact real energy embedding,
unital band Fock identification, exterior vacuum, common H0, fixed resources
and finite-order control/commutator-form errors. The stated mean/W1 scale
epsilon=o(h^2) is sufficient, not optimal or necessary. No calibration or
embedding construction is supplied by this package. Initial-state mathematics
and concurrent branch history are not imports. See both complete cores and
[HANDOFF](HANDOFF.md) for exact attributed conclusions and limits.''',
      'NO_GO_DISCIPLINE_CHECKLIST.md':'''# No-go applicability record

Current claim is a positive conditional bounded theorem. It does not assert
a no-go, negative stretch-attempt result, or bounded-with-named-walls result.
The failed fixed-accuracy frequency-approximation shortcut is retained as a
failure of that shortcut, not a claim that every alternative route fails.

N1-N4 and N6-N8: no negative packet is asserted or passed here. No five-family
exclusion, wall-independence verdict, hidden-wall closure, residual matching,
universal steelman or historical echo scan is supplied by this preparation.
N5: the identity runner prints all five resolution labels with explicit
scientific nonexecution. It checks bytes only. Its author has not executed it.
No no-go packet PASS follows from those labels or from source reconstruction.
If a later author adds a triggering negative claim, applicability and all
required N1-N8 work must be separately addressed before that claim ships.''',
      'NO_GO_LEDGER.md':'''# Scoped failed routes and nonclaims

The accepted cores preserve the fixed-accuracy frequency approximation failure:
a phase error can accumulate at order delta/h^2, so that shortcut alone does
not prove the BV secular limit. The successful arguments have their own BV
localization/control hypotheses. A fixed-partition normalization check is
not silently substituted for the complete BV argument.

This ledger makes no theorem of route impossibility, universal obstruction,
necessity/optimality of the sufficient cell scale, or extension failure outside
the fixed resources. No new no-go claim or N1-N8 packet PASS is introduced.
Original847's picture defect, root miss and subsequent repair remain archived
historical facts; their presence is not a new audit verdict.''',
      'GOAL.md':'''# Current goal

Prepare reviewable publication source for the accepted one-time chirped vacuum
energy law and separate mean/W1 result, preserving both unchanged cores and
their distinct scope. Root owns runtime integration and regular PR creation.
This source task is complete only at an exact immutable source freeze with
actual source-only logs and explicit remaining publication obligations.''',
      'STATE.md':'''# Source preparation state

Accepted source assembly is immutable. Canonical publication source, identity
runner text, dependency/cache/manifest proposals and full prepare/verify contract
are prepared for root review. Branch creation/selection, canonical execution,
staging, runtime verification, PR creation/attachment, current-main combined
validation and effective retained audit are not source-preparer outcomes.
No editable prompt files changed. No extra agents or model changes occurred.''',
      'ROUTE_PORTFOLIO.md':'''# Accepted routes and scope

Root V2: fixed BV profiles, qualitative secular localization, weighted full-input
comparison and one-time law/mean/W1. Independent850: resource-uniform secular
bound and corresponding fixed-characteristic/mean errors, qualitative profile-W1.
Root's later assessment of that strengthening is separate. Fixed-partition
normalization and cross-block estimates are supporting checks. Fixed-accuracy
frequency approximation alone is a preserved failed shortcut. This source
package proposes no new frontier route and runs none of these calculations.''',
      'APPROACH_REGISTRY.md':'''# Approach register

The complete root V2 and independent850 proofs remain separate unchanged cores.
Their old source plans, exclusions, checks and comparison344 remain in the
complete accepted archive. Packaging applies byte reconstruction and procedural
source review only. It is not another independent derivation or a model-diverse
check. No new route is ranked or excluded by this publication task.''',
      'OPPORTUNITY_QUEUE.md':'''# Remaining work

Root must review the full exact source/program package, confirm the clean
planned child directly from PR9517, provide external execution acceptance,
prepare, stage exactly, verify and create/attach a regular PR. Cumulative
parent review, current-main combined landing checks and independent retained
audit remain distinct later obligations. Any new mathematical extension needs
its own scoped derivation; none is started by this packet.''',
      'LITERATURE_BRIDGES.md':'''# Source boundary

This publication-only task consumes accepted local proof sources and current
repository procedures. It performs no new literature search and adopts no
new scientific source. Existing mathematical machinery and its hypotheses
remain in the exact canonical parents and unchanged cores. Identity inventory
does not establish a new literature or upstream proof review.''',
      'ARTIFACT_PLAN.md':'''# Artifact plan

Install the dated canonical note, one identity-only primary runner and this
scoped packet. Generate one canonical runner cache and the citation manifest
through the reviewed runtime contract. Preserve complete compressed evidence,
full program/template sources and complete raw diffs. Root records exact new
acceptance and final review copies. All stage paths are explicit; unexpected
paths or old-node/edge changes fail. No broad raw-diff whitespace skip is used.''',
      'PR_BACKLOG.md':'''# Publication obligations

Proposed regular milestone: chirped_kinetic_energy_bounded_theorem_note_2026-10-13,
bounded_theorem, conditional-support. Planned branch is the direct PR9517 child
recorded in CHIRPED_BRANCH_PLAN.json. No chirp PR number or head is invented.
Root must supply the actual runtime receipts, exact staged commit and regular
PR attachment. The prior source acceptance and current preparation alone do
not satisfy those obligations or an independent retained audit.'''
    }
    for name,value in records.items():text(P/name,value)
    dump(P/'SOURCE_WHITESPACE_CLASSIFICATION.json',{'preserved_source_whitespace':spec['preserved_source_whitespace'],'raw_diff_policy':'Exact compressed/raw pins, no broad whitespace bypass; literal raw diff context spaces stay inside lossless archives.','mathematical_source_edits':0})
    # Preserve complete source programs and exact template diffs, never normalized diff markers.
    pairs=[('prepare_verify_initial_state_kinetic_energy.py','prepare_verify_chirped_kinetic_energy.py'),('IDENTITY_TOOL.template.py','IDENTITY_TOOL.template.py'),('run_combined_validation.py','run_combined_validation.py'),('CHECK_PREPARATION_SOURCES.py','CHECK_PREPARATION_SOURCES.py')]
    program_diffs=[]
    for old,new in pairs:
        a=raw(Q/'procedural_template'/old);b=raw(Q/new);name=new.replace('.py','')+'.diff';d=diff(a,b,'reviewed_template/'+old,'chirped_publication/'+new);z=gzip.compress(d,mtime=0)
        put(P/'program_diffs'/(name+'.gz'),z);put(Q/'program_diffs'/name,d)
        program_diffs.append({'template':'procedural_template/'+old,'program':new,'template_sha256':sha(a),'program_sha256':sha(b),'diff':'program_diffs/'+name+'.gz','readable_diff':'program_diffs/'+name,'diff_sha256':sha(d),'diff_bytes':len(d),'diff_lines':d.count(b'\n'),'diff_stored_sha256':sha(z),'stored_bytes':len(z),'context_lines':3,'fromfile':'reviewed_template/'+old,'tofile':'chirped_publication/'+new})
    dump(Q/'PROGRAM_DIFFS.json',{'convention':'LF-preserving difflib.diff_bytes(unified_diff),n=3,literal labels,no timestamps,lossless gzip','diffs':program_diffs,'mathematical_body_template_adoption':False})
    dump(P/'PROGRAM_DIFFS.json',js(Q/'PROGRAM_DIFFS.json'))
    programs=['prepare_verify_chirped_kinetic_energy.py','IDENTITY_TOOL.template.py','run_combined_validation.py','CHECK_PREPARATION_SOURCES.py','BUILD_SOURCE_ONLY.py','ADAPT_PROGRAMS.py','FINALIZE_SOURCE_ONLY.py','RUN_SOURCE_ONLY.py']
    archives=[]
    for name in programs:
        b=raw(Q/name);ast.parse(b,filename=name);z=gzip.compress(b,mtime=0);path='programs/'+name+'.gz';put(P/path,z)
        archives.append({'source':name,'archive':path,**pin(b),'stored_sha256':sha(z),'stored_bytes':len(z),'execution_scope':'Source archive only; canonical identity never imports or executes it.'})
    dump(P/'PROGRAM_ARCHIVE_INTEGRITY.json',{'programs':archives,'scientific_predicates':0})
    dump(Q/'PROGRAM_SOURCE_INVENTORY.json',{'programs':archives,'complete_program_diff_count':len(program_diffs),'selected_template_files':js(Q/'TEMPLATE_SELECTION.json')['selected_files']})
    # Core extraction diffs are complete empty diffs because every byte agrees.
    edits=js(P/'PUBLICATION_EDITS.json');nb=raw(Q/'payload'/n['path']);core_diffs=[]
    for i,piece in enumerate(x for x in edits['notes'][0]['pieces'] if x['kind']=='accepted_core_slice'):
        before=raw(piece['source_path']);after=nb[piece['byte_offset']:piece['byte_offset']+piece['bytes']];name='core_'+str(i+1)+'_extraction.diff';x='accepted/core_'+str(i+1);y='publication/core_'+str(i+1);d=diff(before,after,x,y);z=gzip.compress(d,mtime=0);put(P/'diffs'/(name+'.gz'),z);put(Q/'readable_diffs'/name,d)
        if d:raise ValueError('Mathematical core changed')
        core_diffs.append({'source_path':piece['source_path'],'byte_offset':piece['byte_offset'],'bytes':piece['bytes'],'diff':'diffs/'+name+'.gz','diff_sha256':sha(d),'diff_bytes':len(d),'diff_lines':d.count(b'\n'),'diff_stored_sha256':sha(z),'stored_bytes':len(z),'context_lines':3,'fromfile':x,'tofile':y})
    dump(P/'CORE_EXTRACTION_DIFFS.json',{'diffs':core_diffs,'mathematical_core_edits':0})
    # Root acceptance remains a separately reviewed future root record, not an author approval.
    status=js(P/'SOURCE_REVIEW_STATUS.json');tree=ast.parse(raw(Q/'prepare_verify_chirped_kinetic_energy.py'));guard=next(t for t in tree.body if isinstance(t,ast.FunctionDef) and t.name=='source_guards');flags=next(ast.literal_eval(t.value) for t in guard.body if isinstance(t,ast.Assign) and t.targets[0].id=='required')
    anchors=['base','branch','prepared_source_freeze_sha256','source_assembly_root_review_sha256','source_assembly_root_acceptance_sha256','disposition','root_core_sha256','independent_core_sha256','no_go_packet_pass']
    acceptance={k:status[k] for k in anchors};acceptance.update({k:False for k in flags});acceptance.update({'publication_source_freeze_sha256':None,'publication_program_sha256':sha(raw(Q/'prepare_verify_chirped_kinetic_energy.py')),'final_assembly_review_path':None,'final_assembly_review_sha256':None,'final_assembly_review_disposition':None,'placeholder_only':True,'scientific_predicates':0})
    dump(Q/'ROOT_ACCEPTANCE.template.json',acceptance)
    combined=js(Q/'procedural_template/COMBINED_ROOT_ACCEPTANCE.template.json');combined['program_sha256']=sha(raw(Q/'run_combined_validation.py'));combined['package_source_freeze_sha256']=None
    for key in ['root_authorizes_execution','cumulative_unit_reviewed','source_footprint_reviewed','generation_scope_reviewed','recovery_owned_by_root']:combined[key]=False
    dump(Q/'COMBINED_ROOT_ACCEPTANCE.template.json',combined)
    combined_plan=raw(Q/'procedural_template/COMBINED_VALIDATION_PLAN.json').decode().replace('finite_initial_energy_kinetic','chirped_kinetic_energy')
    put(Q/'COMBINED_VALIDATION_PLAN.json',combined_plan)
    # Render the primary runner from an AST-valid template and exact data literals.
    packets=sorted(str(p.relative_to(Q/'payload')) for p in P.rglob('*') if p.is_file())
    inputs=sorted(set(packets+[n['path']]+[p['path'] for p in js(P/'PARENT_BINDINGS.json')['parents']]))
    extra={name:{k:pin(raw(Q/'payload'/name))[k] for k in ['sha256','bytes']} for name in packets}
    template=(Q/'IDENTITY_TOOL.template.py').read_text()
    for token,name in {'MAP_SHA':'EVIDENCE_MAP.json','EDITS_SHA':'PUBLICATION_EDITS.json','PARENTS_SHA':'PARENT_BINDINGS.json','STATUS_SHA':'SOURCE_REVIEW_STATUS.json','GRAPH_SHA':'CLAIM_REGISTRY_ADDITIONS.json'}.items():template=template.replace('__'+token+'__',sha(raw(P/name)))
    template=template.replace('__DECLARED_INPUTS__',pprint.pformat(inputs,width=100)).replace('__EXTRA_PINS__',pprint.pformat(extra,width=100)).replace('__CLAIM__',n['claim_id'])
    ast.parse(template,filename=n['runner']);put(Q/'payload'/n['runner'],template)
    dump(Q/'RUNNER_SOURCE_RENDERING.json',{'inputs':inputs,'extra_pins':extra,'template_sha256':sha(raw(Q/'IDENTITY_TOOL.template.py')),'runner_sha256':sha(template.encode()),'template_executed':False,'runner_executed':False})
    payload=[]
    for p in sorted((Q/'payload').rglob('*')):
        if p.is_file():payload.append({'path':str(p.relative_to(Q/'payload')),**pin(raw(p))})
    dump(Q/'PAYLOAD_MANIFEST.json',{'files':payload,'file_count':len(payload),'scientific_predicates':0})
    binary=[]
    for row in payload:
        if row['path'].endswith('.gz'):
            z=raw(Q/'payload'/row['path']);b=gzip.decompress(z);binary.append({'path':row['path'],'sha256':sha(z),'bytes':len(z),'stored_sha256':sha(z),'stored_bytes':len(z),'raw_sha256':sha(b),'raw_bytes':len(b),'raw_lines':len(b.splitlines()),'reason':'Lossless exact source/program/diff archive; no byte normalization'})
    dump(Q/'BINARY_PAYLOAD_PINS.json',{'files':binary,'policy':'Only exact listed stored-byte pins use binary treatment; no broad extension/path whitespace skipping.'})
    paths=sorted([r['path'] for r in payload]+['logs/runner-cache/'+Path(n['runner']).stem+'.txt','docs/audit/data/citation_graph_manifest.json',packet+'/PUBLICATION_ROOT_ACCEPTANCE.json',packet+'/PUBLICATION_ASSEMBLY_REVIEW.txt'])
    dump(Q/'EXPECTED_INSTALL_AND_STAGE_PATHS.json',{'paths':paths,'payload_count':len(payload),'total':len(paths),'additional_runtime_paths':4,'plan_only':True})
    dump(Q/'STAGE_PINS.proposed.json',{'payload':payload,'runtime_pins':'Root computes the one canonical cache, generated manifest and exact two accepted root records after prepare; no fabricated pins.','paths':paths})
    dump(Q/'SOURCE_ONLY_EXECUTION_POLICY.json',{'allowed':'Enumerated source generators and read-only reconstruction checker; FREEZE_PACKAGE.py for final local bookkeeping and seal only; exact read-only Git source inventory; AST parsing only.','prohibited':['proposed identity runner','prepare/verify driver','combined validation','canonical cache','graph/pipeline execution','Git mutation','PR/audit/prompt mutation'],'programs_executed_by_preparer_are_not_runtime_outcomes':True,'scientific_predicates':0,'formal_builds':0,'editable_prompt_files_changed':[]})
    dump(Q/'SOURCE_CHECK_PROTOCOL.json',{'program':'CHECK_PREPARATION_SOURCES.py','scope':'Read-only byte identity, exact declared-source reconstruction, AST/rendering, paths and program diff checks. No import/execution of proposed programs and no mathematical predicates.','logs':'evidence/source_check_* complete stdout/stderr/receipt','freeze':'SOURCE_FREEZE.json pins every preparation file except itself; final readonly verification creates no new file.'})
    print(json.dumps({'payload_files':len(payload),'planned_stage_files':len(paths),'declared_runner_inputs':len(inputs),'binary_payloads':len(binary),'program_archives':len(archives),'scientific_predicates':0},sort_keys=True))
if __name__=='__main__':main()
