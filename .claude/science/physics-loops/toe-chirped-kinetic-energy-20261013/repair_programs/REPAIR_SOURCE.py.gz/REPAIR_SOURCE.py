#!/usr/bin/env python3
"""Apply the one-line body metadata repair in V2 source only; no runtime executes."""
from pathlib import Path
from datetime import datetime, timezone
import difflib, gzip, hashlib, json
Q=Path(__file__).resolve().parent;R=Q.parent;V1=R/'chirped_kinetic_energy_publication_preparation'
def raw(p):return Path(p).read_bytes()
def js(p):return json.loads(raw(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(b):return {'sha256':sha(b),'bytes':len(b),'lines':len(b.splitlines())}
def put(p,b):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def dump(p,d):put(p,json.dumps(d,indent=2,sort_keys=True)+'\n')
def diff(a,b,x,y):return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=x.encode(),tofile=y.encode(),n=3))
def update_diff(P,row,before,after):
    d=diff(before,after,row['fromfile'],row['tofile']);z=gzip.compress(d,mtime=0)
    put(P/row['diff'],z);put(Q/'readable_diffs'/Path(row['diff']).name.removesuffix('.gz'),d)
    row.update({'diff_sha256':sha(d),'diff_bytes':len(d),'diff_lines':d.count(b'\n'),'diff_stored_sha256':sha(z),'stored_bytes':len(z)})
def main():
    if Q.name!='chirped_kinetic_energy_publication_preparation_v2' or (Q/'SOURCE_FREEZE.json').exists():raise ValueError('Wrong or frozen repair target')
    assert sha(raw(V1/'SOURCE_FREEZE.json'))=='410cdda05fd70ebbbb0a767b28f9632fd8e1e196e4b49c5fc34b8ea959f64a7b'
    spec=js(Q/'SPECIFICATIONS.json');P=Q/'payload'/spec['packet'];edits=js(P/'PUBLICATION_EDITS.json');note=edits['notes'][0]
    title='# Chirped one-time vacuum energy laws\n';old=raw(Q/'payload'/note['note'])
    assert old.count(title.encode())==1 and b'\nClaim type: bounded_theorem\n' not in old
    first=note['pieces'][0];assert first['kind']=='publication_wrapper' and title in first['text']
    first['text']=first['text'].replace(title,title+'\nClaim type: bounded_theorem\n',1);put(Q/first['wrapper_path'],first['text'])
    joined=b''
    for piece in note['pieces']:
        if piece['kind']=='publication_wrapper':b=piece['text'].encode()
        else:
            full=raw(piece['source_path']);b=b''.join(full.splitlines(True)[piece['source_line_start']-1:piece['source_line_end']])
            assert sha(b)==piece['expected_slice_sha256']
        piece.update({**pin(b),'byte_offset':len(joined),'first_line':joined.count(b'\n')+1,'last_line':(joined+b).count(b'\n')});joined+=b
    assert joined==old.replace(title.encode(),(title+'\nClaim type: bounded_theorem\n').encode(),1)
    put(Q/'payload'/note['note'],joined);note.update({'published_sha256':sha(joined),'published_bytes':len(joined),'published_lines':len(joined.splitlines())})
    accepted=raw(note['accepted_candidate_path']);update_diff(P,note,accepted,joined)
    for row in edits['wrapper_changes']:
        lo,hi=row['source_line_range'];before=b''.join(accepted.splitlines(True)[lo-1:hi]);after=raw(Q/row['publication'])
        row['publication_sha256']=sha(after);update_diff(P,row,before,after)
    dump(P/'PUBLICATION_EDITS.json',edits)
    keys=['diff','diff_sha256','diff_bytes','diff_lines','diff_stored_sha256','stored_bytes','context_lines','fromfile','tofile'];record=js(P/'RAW_DIFF_INTEGRITY.json');record['diffs']=[{k:r[k] for k in keys} for r in [note,*edits['wrapper_changes']]];dump(P/'RAW_DIFF_INTEGRITY.json',record)
    for row in spec['notation_exclusions']:
        row['canonical_line']=joined.decode().splitlines(True).index(row['exact_line'])+1;row['note_sha256']=sha(joined)
    dump(Q/'SPECIFICATIONS.json',spec);notation=js(P/'MARKDOWN_NOTATION_CLASSIFICATION.json');notation['exclusions']=spec['notation_exclusions'];dump(P/'MARKDOWN_NOTATION_CLASSIFICATION.json',notation)
    evidence=js(P/'EVIDENCE_MAP.json')
    paths=[R/'chirped_kinetic_energy_publication_execution/20261013T144604_prepare_2c732f85ed2b/FAILURE.json']+[R/'chirped_kinetic_root_execution/prepare'/name for name in ['START.json','RESULT.json','outer_program.py','stdout','stderr']]
    receipts=[]
    for path in paths:
        b=raw(path);h=sha(b);obj=next((o for o in evidence['objects'] if o['sha256']==h),None)
        if obj is None:
            z=gzip.compress(b,mtime=0);name='objects/'+h+'.gz';put(P/name,z);obj={**pin(b),'path':name,'stored_sha256':sha(z),'stored_bytes':len(z),'compression':'gzip mtime=0; raw bytes unchanged','origins':[]};evidence['objects'].append(obj)
        assert not any(o['path']==str(path) for o in obj['origins']);obj['origins'].append({'path':str(path),'roles':['later_root_owned_failed_prepare_selected_receipt_or_stream']});receipts.append({'path':str(path),**pin(b)})
    evidence['later_root_failed_prepare']={'selected_immediate_records':receipts,'scope':'Selected exact FAILURE and complete outer execution records/streams only; no recursive closure of the entire inner runtime folder.','author_execution':False};dump(P/'EVIDENCE_MAP.json',evidence)
    result=js(R/'chirped_kinetic_root_execution/prepare/RESULT.json');assert result['exit_code']==1
    history='''# Publication metadata repair V2

Root's V1 prepare failed its unchanged exact graph claim-type guard. The
graph builder reads a standalone body Claim type line; the YAML field alone
did not supply its author hint. V2 adds Claim type: bounded_theorem immediately
beneath the note title. Both complete 515/850 mathematical cores are unchanged.
The complete prepare/verify, identity algorithm, combined program and source
checker remain byte-identical to V1. The graph gate is not weakened.

The root-owned failed prepare lasted '''+str(result['elapsed_seconds'])+''' seconds and
exited 1. Exact selected FAILURE, outer program, START/RESULT and complete
stdout/stderr are archived with original paths in EVIDENCE_MAP.json. The full
inner runtime directory remains at the recorded external path; its recursive
contents are not claimed archived here. Root owns installed-state recovery.

This source author only repaired metadata and dependent maps/diffs/digests,
rerendered literal integrity data, and ran source-only checks. No graph parser,
identity runtime, cache, prepare/verify, pipeline or Git mutation was executed.
The actual root rerun must establish the graph and publication outcomes.
V1 remains frozen at 410cdda05fd70ebbbb0a767b28f9632fd8e1e196e4b49c5fc34b8ea959f64a7b.
V1-to-V2 byte reconstruction and complete program comparisons are separate
records in the external source package. Historical V1 read/check logs retain
their dates and paths; they are not mislabeled as V2 checks or execution.
'''
    put(P/'PUBLICATION_REPAIR_V2.md',history)
    rows=[]
    for name in ['REPAIR_SOURCE.py','CHECK_V2_REPAIR.py']:
        b=raw(Q/name);z=gzip.compress(b,mtime=0);path='repair_programs/'+name+'.gz';put(P/path,z);rows.append({'source':name,'archive':path,**pin(b),'stored_sha256':sha(z),'stored_bytes':len(z)})
    dump(P/'REPAIR_PROGRAMS.json',{'programs':rows,'scientific_predicates':0,'scope':'Source bookkeeping only, never imported by primary identity runner.'})
    d=diff(old,joined,'V1/'+note['note'],'V2/'+note['note']);put(Q/'V1_TO_V2_NOTE.diff',d)
    dump(Q/'REPAIR_APPLIED.json',{'utc':datetime.now(timezone.utc).isoformat(),'old_note':pin(old),'new_note':pin(joined),'entire_cores_unchanged':True,'mathematical_body_edits':0,'runtime_driver_sha256':sha(raw(Q/'prepare_verify_chirped_kinetic_energy.py')),'root_failure_records':receipts,'source_predicates_only':True})
    print(json.dumps({'old_note':pin(old),'new_note':pin(joined),'source_repair_only':True,'scientific_predicates':0}))
if __name__=='__main__':main()
