# Independent review of the conditional scattering-exhaustion reduction

No material mathematical error was found in E1–E18 of the frozen
`SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md`. The supported result is the stated
conditional reduction: direct compact creators and the energy-remainder
restriction give bounded detector compression and scalar off-collision
dynamics; PC gives positive detector limits with scattering range; ND on
every specified energy interval gives EX. The proof does not establish PC,
ND, or completeness for N1. Those realization obligations remain
`science-needed`. No source correction or new retained status is recommended
by this focused review.

The reviewed target is exactly 262 lines with SHA-256
`c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2`.
The corresponding author receipt is
`8fac2fc46322fc8a58e2a86eda22128a7e9c7a831f329c53f0775d2ea60aca3a`.
All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

The review applied the current physics-claim-reviewer skill and relevant
repository instructions at the supplied main and instruction revisions,
`a13caa4885f547c8d206265b031ba7649e539fd9` and
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The read-only scattering
publication source was `c3f84746b1991e0a15c6da79d049b89d9469f727`.
N1/B1/M1 copies were checked against their actual source commit
`0cc560e3935fa1ad7623592bf9974680c922d52d`; they are not attributed to the
separate scattering publication commit. Exact source identities and reading
coverage are in `scattering_exhaustion_review/source_match.json` and
`reading_coverage_precontrols.json` in that directory.

The complete independent reconstruction was frozen before opening the author
helper, logs, execution metadata or receipt. Its SHA-256 is
`a4a084179531369c12c2b5cb894d776ed11fa325a4cbb20aaf3b67a4906b35f6`,
with freeze time 2026-10-12T00:45:02.797103+00:00. The candidate's descriptions
of its own controls and the earlier review labels were already visible and
are declared shared context. The prior review reports and Fock proof were
not used to reconstruct the argument. The full proof record is
`scattering_exhaustion_review/INDEPENDENT_RECONSTRUCTION_PRECONTROLS.md`;
the freeze and exact coverage have separate immutable hash records.

The following source-bound conclusions support the disposition.

| Target lines | Checked conclusion and indispensable restriction |
|---|---|
| 23–37 | E1 must mean a unique zero-energy vacuum and a gap on its entire orthogonal complement. N1 H-gap includes that stronger spectral clause. Local cyclicity and strong spectral cutoffs prove EX iff the constructed closed scattering span is the whole space. H-AC is excluded. Actual microscopic flows, selected mass/centre components and direct creator properties remain explicit inputs. |
| 68–100 | The current/geometric momentum relation and E2 signs agree with the compact source. E3 filters the full operator geometric transfer, preserving temporal transfer and almost locality. Negative temporal transfer, positive energy and almost locality suffice for E4. Repeated energy lowering justifies E5. No global geometric shell or Fock norm identity enters. |
| 104–144 | E6 is the exact energy-remainder restriction needed for E7. A gap alone does not give vacuum factorization or covering tuples. Pairwise spatial support separation gives the operator-norm remainder E8 by O(t^(nd)) counting. The creator energy upper bound makes J_t bounded on all ell^2. E10 is exactly positive after compression and has the stated uniform bound. |
| 148–183 | F_t is differentiable in ell^2 on a bounded energy window. The Fourier support uses the creator's geometric momentum sign. Moving the zero-vacuum-row defects D_i to the left gives every term and the sign in E12, including the dispersion derivative. The global ell^2 source bound comes from E11, while E14 follows from compact off-collision support and t^(nd/2) counting. No cluster-direction decay is inferred. |
| 187–207 | The full operator momentum filters give S_t=S_t g(D). Compact Cook limits on a dense product class and uniform boundedness give a strong limit S on all ell^2. Time covariance makes the scattering span reducing for H. PC then gives strong convergence of Q(t), positivity and scattering range. E16 has the correct left multiplication and O(t^-2) remainder. Its leading O(t^-1) bound is insufficient for PC. |
| 211–234 | The weighted positive series converges in norm with tail at most 2^-m and has precisely the common kernel. ND implies density of its range inside the closed scattering space, hence exhaustion on J. E18 is equivalent to ND only with the displayed ordered limits: first t, then m, then eta. Projected local vacuum vectors form the required dense set. Applying this on the countable energy partition gives EX. |

For the load-bearing finite-energy import, I also supplied a direct proof.
For a finite spatial set, let Q be the sum of A_x^* A_x and D the maximum
row sum of the norms of [A_x,A_y^*]. On the common kernel of all ordered
length-n annihilator words, a commutator expansion, Cauchy–Schwarz and the
Schur bound give
`||Q psi||^2 <= (n-1) D <psi,Q psi>`, hence
`<psi,Q psi> <= (n-1) D ||psi||^2`. Energy lowering puts the entire
energy-[0,R] subspace in this kernel once n epsilon>R. Almost locality bounds
D uniformly in the spatial set; monotone finite sums give E4. This argument
does not assume that Q preserves the energy window. The full induction and
all later strong-limit and density arguments are in the frozen reconstruction.

For a chosen detector family, ND is a sufficient coverage condition; EX does
not by itself ensure that this particular family has trivial common kernel.
The candidate's actual equivalences, ND with E18 and EX with P_sc=1, are
correct. The narrow partition width does not produce admissible tuples or
establish coverage. EC is a valid stronger sufficient condition only with
the stated positive-form domain and zero-form property on common undetected
vectors. Constructing that form or comparing it with microscopic local energy
density remains open. These distinctions prevent the terminal estimate from
being presented as near-closure of the physical problem.

The primary-source assessment used the arguments that enter the proof.
BDN arXiv:1412.2970v2 Proposition 3.6, Lemma 3.9 and Theorems 3.10–3.11
were checked in their original statement/proof context. The finite-energy
theorem does not require the isolated geometric shell appearing later in
that paper. The direct Cook construction and all 404 lines of its frozen
predecessor were read, together with the complete 28-line EX scope repair.
The publication diff was checked in full and introduces no unexamined core
argument. The separately reviewed Fock extension is not a dependency of
E1–E18; its source identity was checked, but its proof was not reused here.

Dybalski arXiv:1608.08750v1 was read in full. Its actual detector theorem
additionally requires the isolated geometric shell, admissible small transfer
sets, disjoint geometric momentum transfers and the appropriate convex
velocity supports. The direct reduction permits mixed dispersions and needs
velocity separation rather than species labels. It therefore does not acquire
PC by a literal application of that theorem. The impossible empty-set clause
on source page 4 is visible in the original page; the candidate correctly
records it without importing the literal clause. Dybalski–Gérard's scalar
reduction and propagation/range arguments were checked in their continuum
hypothesis context; only the scalar mechanism is reconstructed here. Their
detected-range result does not supply full-GNS exhaustion. Kruse's stated
absolute-continuity and one-particle-remainder hypotheses, and the unproved
energy-density bridge, were checked. Graf–Schenker's scanned theorem
statements concern a fixed two-particle coordinate problem with bound-pair
channels. Neither provides a missing N1 premise. Exact page coverage and
unread/nonimported portions are disclosed in the coverage record; this is
not a claim to recertify every comparator's full proof.

After freezing the analytic work, I ran a distinct finite control suite once
with a declared 60-second timeout. It separately tested full operator
filtering, mixed-dispersion scalar dynamics, and the convolution calculation
in E16. The 1197 finite source equations had maximum array residual
5.07e-15. Relevant incorrect formulas were rejected: the wrong free sign,
omitted dispersion commutators, omitted nonadjacent commutators, vacuum-only
filtering, reversed velocity sign and omitted moving-cutoff derivative.
The n-dependent cases where an omitted term is vacuous are explicitly
excluded from the claimed rejection counts. These constructed finite
examples test algebra and signs; they are not microscopic N1 models.

I then read the complete author helper and reproduced it once under its
declared 60-second timeout. It exited 0 in 0.890 seconds; all five stdout
records matched byte for byte and stderr was empty. All 230 author receipt
artifact hashes and byte lengths matched. The free-word and XY controls
exercise the source identity, while the on-site lowering and positive-matrix
examples correctly disprove weakened remainder and unordered-limit claims.
They establish neither PC nor ND. The proof, rather than the finite scalar
checks, establishes the operator resolvent estimate. Full logs, execution
metadata, the independent implementation, negative controls and a precise
fabrication-pattern/discriminating-gate assessment are retained in
`scattering_exhaustion_review/CONTROL_ASSESSMENT.md` and adjacent files.

The safe scope is the conditional E1–E18 reduction at the exact frozen source.
No Fock isometry has been promoted to completeness, no abstract spectator
space has been treated as a local-UHF counterexample, and no broad no-go or
physical N1 conclusion follows. No frozen source, physical axiom, Git state,
PR, audit record or editable prompt was changed. Review outputs alone were
written. The final source refresh, evidence inventory, open obligations and
verification limits are recorded in `scattering_exhaustion_review/receipt.json`.
