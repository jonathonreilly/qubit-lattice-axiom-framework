# Compact detector convergence checkpoint

Updated: 2026-10-12T01:12:14.341865+00:00. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.

Target: the precise PC norm limit for each fixed admissible compact detector arrangement. Status: candidate-complete conditional author proof; independent review pending. Claim type: bounded_theorem. Trace: direct_blocker_closure of PC at the supplied fixed-arrangement scope, with no ND or EX assertion.

Current note: COMPACT_DETECTOR_CONVERGENCE_PROBE.md, SHA-256 bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64. Read-only source tree: c3f84746b1991e0a15c6da79d049b89d9469f727. Instruction source: 3a4b2c66a1ead7a1c48b4359627e968f681e3c39. All frozen predecessor hashes match; SOURCE_LEDGER.json records exact source and reading coverage. The E1-E18 review was reported complete by the parent during this pass; its outcome was not used as a premise of the new proof.

Strongest result: u_t = exp(it omega) g(D) h(X/t) F_t converges in l2 to h(v(D)) S* psi for every finite-energy psi. The argument retains only weak adjoint convergence, applies a finite-rank cutoff at fixed t, reverses the exact scalar Duhamel integral, and proves both Schur sums for the two-time kernel uniformly for s>=t>=1. With the energy-only vacuum remainder, Q_J(t) converges strongly to P_J S h(v(D)) S* P_J, a positive bounded operator with scattering range.

Load-bearing checks: full source filter follows from the closed Fourier support of F and its strong derivative; both time and packet derivatives are in the commutator source; all remaining factors are bounded; the stationary sign is y=x+(s-t)v; convex containment keeps the source cutoff off every collision; the kernel estimate covers s=t; periodicity/compact chart support removes momentum boundary terms. The free limit is proved by Fourier shifts. The entire final proof was read, then all narrow notation/power-count edits were checked.

Open obligations: focused independent reconstruction of C18 and C24a; physical realization of supplied microscopic/direct-creator hypotheses; ND/no-common-kernel, energy capture, all needed particle channels, EX, and full-algebra shift. No uniformity in growing n, vanishing separation, infinite chart families or unbounded energy is established. Fock isometry is not a premise and cannot provide surjectivity.

Failed routes preserved: strong S_t does not imply strong S_t*; moving compact cutoffs cannot use a weak limit uniformly; forward Cook gives only 1/t; deleting q after a spatial cutoff loses velocity control; mere support separation without convex containment does not establish this propagation geometry. Dybalski v1's empty-set shell clause is not imported. The printed B.17 difference is visually verified and fails direct third differentiation; this proof avoids that formula.

Evidence: six finite controls, seven full output records, empty stderr, declared 60-second timeout, exit 0; one hash-bound p.12 rendering under the same timeout, exit 0. These are finite algebra/sign checks, not analytic or physical certificates. Repository search had one documented launch-path failure and a successful resolved-path search; its two finite-time dynamics hits were inspected and classified as nonmatching. Complete logs are on disk.

Next action: parent arranges a focused independent check of this frozen note and its exact necessary inputs. Do not silently edit frozen predecessor files or promote this author result to retained status. This worker has completed its bounded deliverable; the parent campaign continues within its existing fixed deadline.

Only this note and compact_detector_convergence/ were written. Editable prompt files changed: none. No Git/repo/PR/audit/axiom/model/other-chat mutation or subdelegation. Model and reasoning remained inherited. No deadline extension.
