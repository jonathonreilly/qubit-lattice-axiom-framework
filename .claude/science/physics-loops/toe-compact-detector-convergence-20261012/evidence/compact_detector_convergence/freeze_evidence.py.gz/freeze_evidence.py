#!/usr/bin/env python3
"""Bind fixed sources, one checkpoint, and completed author evidence without repo writes."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
s = out.parent
repo = s.parent / 'scattering_worktree'
commit = 'c3f84746b1991e0a15c6da79d049b89d9469f727'
instruction_commit = '3a4b2c66a1ead7a1c48b4359627e968f681e3c39'
deadline = dt.datetime(2026, 10, 12, 16, 0, 52, tzinfo=dt.timezone.utc)
now = dt.datetime.now(dt.timezone.utc)
assert now < deadline, 'fixed campaign deadline has passed'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path, coverage, expected=None):
    data = path.read_bytes()
    digest = sha(data)
    if expected is not None:
        assert digest == expected, f'Changed frozen input: {path}'
    return dict(path=str(path), sha256=digest, bytes=len(data), coverage=coverage)


inputs = []
specs = [
 ('SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md', 'c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2', 'Complete 262 lines; every used reduction rebuilt. No reliance on its later review outcome.'),
 ('COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md', 'd1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a', 'Complete 404 lines; supplied direct creator class and full Cook proof reused.'),
 ('COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md', 'd4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516', 'Complete 28 lines; separate vacuum/gap scope.'),
 ('COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md', '9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404', 'Complete 326 lines; finite-energy proof reconstructed; Fock theorem not needed as premise.'),
 ('COMPACT_PATCH_FOCK_ISOMETRY_REVIEW.md', 'bc88af1dda77065d8806da9d689546547f40847a340177086793dab5f3a277cf', 'Complete 138 lines; source-bound predecessor scope only.'),
 ('scattering_exhaustion_next/sources/COMPACT_PATCH_SCATTERING_COVARIANCE_REVIEW.md', '924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be', 'Complete review; no detector convergence conclusion reused.'),
 ('scattering_exhaustion_next/sources/EX_REPAIR_REVIEW_ADDENDUM.md', '8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029', 'Complete addendum; EX wording repair only.'),
 ('scattering_exhaustion_next/sources/Dybalski_1608.08750v1.pdf', '9d574c50f960920daa39a13fb2a07de09b57d717d715f4507731a43f03e6f1c4', 'All 13 pages through supplied page text; page 12 freshly rendered and visually checked. No general theorem imported with global-shell hypotheses.'),
 ('scattering_exhaustion_next/sources/BDN_1412.2970v2.pdf', '3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126', 'Complete pages 9-13,39-40 through supplied page text; other pages not read in this pass.'),
]
for rel, expected, coverage in specs:
    inputs.append(bind(s / rel, coverage, expected))
for p in range(1, 14):
    inputs.append(bind(s / f'scattering_exhaustion_next/sources/Dybalski_1608.08750v1_pages/{p:02}.txt', 'Complete supplied page text read; not a fresh independent extraction.'))
for p in [9, 10, 11, 12, 13, 39, 40]:
    inputs.append(bind(s / f'scattering_exhaustion_next/sources/BDN_pages/{p:02}.txt', 'Complete supplied page text read; not a fresh independent extraction.'))

observed_head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=repo, check=True,
                               capture_output=True, text=True, timeout=10).stdout.strip()
assert observed_head == commit, f'Read-only source HEAD changed: {observed_head}'
governance = [
 'AGENTS.md', 'docs/ai_methodology/SCIENCE_WORKFLOW.md',
 'docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md',
 'docs/ai_methodology/skills/physics-loop/SKILL.md',
 'docs/ai_methodology/skills/physics-loop/references/DISCOVERY.md',
 'docs/ai_methodology/skills/physics-loop/references/CLAIM_STATUS.md',
 'docs/ai_methodology/skills/physics-loop/references/DELIVERY.md',
 'docs/ai_methodology/skills/physics-loop/references/proof-search-governance.md',
 'docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md',
 'docs/audit/data/axiom_premise_nodes.json',
]
for rel in governance:
    expected = subprocess.run(['git', 'show', f'{commit}:{rel}'], cwd=repo, check=True,
                              capture_output=True, timeout=10).stdout
    inputs.append(bind(repo / rel, 'Applicable instructions read. Fixed-revision equality verified.', sha(expected)))
planning = subprocess.run(['git', 'show', f'{instruction_commit}:AGENTS.md'], cwd=repo,
                          check=True, capture_output=True, timeout=10).stdout
(out / 'AGENTS.planning.read.txt').write_bytes(planning)
inputs.append(dict(git_commit=instruction_commit, git_path='AGENTS.md', sha256=sha(planning),
                   bytes=len(planning), coverage='Complete planning AGENTS read from this exact commit.'))
inputs.append(bind(Path('/Users/jonreilly/.codex/plugins/cache/openai-primary-runtime/pdf/26.1007.11041/skills/pdf/SKILL.md'), 'Complete; read-only PDF visual inspection only.'))

for rel, coverage in [
 ('docs/ORIGINAL_RECORD_THERMODYNAMIC_DYNAMICS_AND_ENERGY_DENSITY_BOUNDED_THEOREM_NOTE_2026-09-30.md', 'Search-context-only: lines 1-32,241-260; finite-time thermodynamic scope, not a matching detector theorem.'),
 ('docs/LOCAL_VOLUME_DYNAMICS_WITH_COMMUTING_ELECTRIC_TERMS_BOUNDED_THEOREM_NOTE_2026-09-24.md', 'Search-context-only: lines 1-28,190-220; finite-time thermodynamic scope, not a matching detector theorem.'),
]:
    inputs.append(bind(repo / rel, coverage))

ledger = dict(created_at=now.isoformat(), repository_commit=commit,
              instruction_commit=instruction_commit, inputs=inputs,
              literature_urls=['https://arxiv.org/abs/1608.08750v1', 'https://arxiv.org/abs/1412.2970v2'],
              web_scope='Official version metadata checked. Proof reads used hash-bound local primary PDFs/page texts.',
              not_read_or_imported=['DG 1308.5187v1 in this pass', 'Kruse 2024 in this pass', 'Graf-Schenker 1997 in this pass',
                                    'Unrelated N1/B1/M1 arguments and published-note variants in this pass'],
              limits='No exhaustive literature survey, retained-status certification, physical realization, or new independent review.')
(out / 'SOURCE_LEDGER.json').write_text(json.dumps(ledger, indent=2) + '\n')

note = s / 'COMPACT_DETECTOR_CONVERGENCE_PROBE.md'
note_hash = sha(note.read_bytes())
checkpoint = f'''# Compact detector convergence checkpoint

Updated: {now.isoformat()}. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.

Target: the precise PC norm limit for each fixed admissible compact detector arrangement. Status: candidate-complete conditional author proof; independent review pending. Claim type: bounded_theorem. Trace: direct_blocker_closure of PC at the supplied fixed-arrangement scope, with no ND or EX assertion.

Current note: COMPACT_DETECTOR_CONVERGENCE_PROBE.md, SHA-256 {note_hash}. Read-only source tree: {commit}. Instruction source: {instruction_commit}. All frozen predecessor hashes match; SOURCE_LEDGER.json records exact source and reading coverage. The E1-E18 review was reported complete by the parent during this pass; its outcome was not used as a premise of the new proof.

Strongest result: u_t = exp(it omega) g(D) h(X/t) F_t converges in l2 to h(v(D)) S* psi for every finite-energy psi. The argument retains only weak adjoint convergence, applies a finite-rank cutoff at fixed t, reverses the exact scalar Duhamel integral, and proves both Schur sums for the two-time kernel uniformly for s>=t>=1. With the energy-only vacuum remainder, Q_J(t) converges strongly to P_J S h(v(D)) S* P_J, a positive bounded operator with scattering range.

Load-bearing checks: full source filter follows from the closed Fourier support of F and its strong derivative; both time and packet derivatives are in the commutator source; all remaining factors are bounded; the stationary sign is y=x+(s-t)v; convex containment keeps the source cutoff off every collision; the kernel estimate covers s=t; periodicity/compact chart support removes momentum boundary terms. The free limit is proved by Fourier shifts. The entire final proof was read, then all narrow notation/power-count edits were checked.

Open obligations: focused independent reconstruction of C18 and C24a; physical realization of supplied microscopic/direct-creator hypotheses; ND/no-common-kernel, energy capture, all needed particle channels, EX, and full-algebra shift. No uniformity in growing n, vanishing separation, infinite chart families or unbounded energy is established. Fock isometry is not a premise and cannot provide surjectivity.

Failed routes preserved: strong S_t does not imply strong S_t*; moving compact cutoffs cannot use a weak limit uniformly; forward Cook gives only 1/t; deleting q after a spatial cutoff loses velocity control; mere support separation without convex containment does not establish this propagation geometry. Dybalski v1's empty-set shell clause is not imported. The printed B.17 difference is visually verified and fails direct third differentiation; this proof avoids that formula.

Evidence: six finite controls, seven full output records, empty stderr, declared 60-second timeout, exit 0; one hash-bound p.12 rendering under the same timeout, exit 0. These are finite algebra/sign checks, not analytic or physical certificates. Repository search had one documented launch-path failure and a successful resolved-path search; its two finite-time dynamics hits were inspected and classified as nonmatching. Complete logs are on disk.

Next action: parent arranges a focused independent check of this frozen note and its exact necessary inputs. Do not silently edit frozen predecessor files or promote this author result to retained status. This worker has completed its bounded deliverable; the parent campaign continues within its existing fixed deadline.

Only this note and compact_detector_convergence/ were written. Editable prompt files changed: none. No Git/repo/PR/audit/axiom/model/other-chat mutation or subdelegation. Model and reasoning remained inherited. No deadline extension.
'''
(out / 'CHECKPOINT.md').write_text(checkpoint)

excluded = {'freeze_receipt.json', 'freeze.stdout', 'freeze.stderr', 'freeze.execution.json'}
outputs = [bind(note, 'Complete conditional proof; author-read final source; independent review pending.')]
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name not in excluded:
        outputs.append(bind(path, 'Frozen author evidence; see individual scope statements.'))
receipt = dict(frozen_at=dt.datetime.now(dt.timezone.utc).isoformat(), deadline=deadline.isoformat(),
               note_sha256=note_hash, inputs=inputs, outputs=outputs,
               output_exclusions=sorted(excluded),
               exclusion_reason='Receipt self-reference and wrapper logs written after this freeze call returns.',
               author_checks='Complete written proof plus six finite algebra/sign controls. No analytic theorem is certified by finite controls.',
               independent_review='pending', no_repo_mutations=True, no_subdelegation=True,
               model_override=None, reasoning_override=None, prompt_files_changed=[])
(out / 'freeze_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(note_sha256=note_hash, note_lines=len(note.read_text().splitlines()),
                     receipt_sha256=sha((out / 'freeze_receipt.json').read_bytes()),
                     inputs=len(inputs), outputs=len(outputs), frozen_at=receipt['frozen_at']), sort_keys=True))
