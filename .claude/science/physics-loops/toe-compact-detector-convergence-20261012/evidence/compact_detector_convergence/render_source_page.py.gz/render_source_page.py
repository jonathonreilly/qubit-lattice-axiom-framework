#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import pypdfium2 as pdfium

out = Path(__file__).resolve().parent
source = out.parent / 'scattering_exhaustion_next/sources/Dybalski_1608.08750v1.pdf'
expected = '9d574c50f960920daa39a13fb2a07de09b57d717d715f4507731a43f03e6f1c4'
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
doc = pdfium.PdfDocument(str(source))
page = doc[11]
image = page.render(scale=2).to_pil()
target = out / 'Dybalski_v1_page12.png'
image.save(target)
print(json.dumps({'source_sha256': expected, 'page': 12, 'output': str(target),
                  'width': image.width, 'height': image.height}))
