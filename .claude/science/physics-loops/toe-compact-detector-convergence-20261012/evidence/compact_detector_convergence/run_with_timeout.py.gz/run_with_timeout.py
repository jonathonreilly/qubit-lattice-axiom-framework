#!/usr/bin/env python3
"""Preserve complete outputs and the actual declared-timeout execution receipt."""
from pathlib import Path
import datetime as dt
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, limit_text, *command = sys.argv[1:]
if not label.replace('_', '').isalnum() or not command:
    raise SystemExit('invalid label or missing command')
limit = float(limit_text)
if not 0 < limit <= 60:
    raise SystemExit('timeout must be in (0,60] seconds')
start = dt.datetime.now(dt.timezone.utc)
before = time.monotonic()
try:
    done = subprocess.run(command, cwd=root, capture_output=True, timeout=limit)
    stdout, stderr, code, timed_out = done.stdout, done.stderr, done.returncode, False
except subprocess.TimeoutExpired as e:
    stdout, stderr, code, timed_out = e.stdout or b'', e.stderr or b'', None, True
end = dt.datetime.now(dt.timezone.utc)
(root / f'{label}.stdout').write_bytes(stdout)
(root / f'{label}.stderr').write_bytes(stderr)
data = dict(command=command, cwd=str(root), declared_timeout_seconds=limit,
            started_at=start.isoformat(), finished_at=end.isoformat(),
            elapsed_seconds=time.monotonic() - before, returncode=code,
            timed_out=timed_out, stdout_bytes=len(stdout), stderr_bytes=len(stderr))
(root / f'{label}.execution.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data, sort_keys=True))
raise SystemExit(124 if timed_out else code)
