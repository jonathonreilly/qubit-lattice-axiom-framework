# Control and artifact assessment

The analytic result is supported by the complete frozen reconstruction, not
by any finite control below. The new author evidence was opened only after
`precontrol_freeze.json` was written. The target's own control descriptions
and the predecessor review were already visible and disclosed.

## Independent Fourier-kernel control

`kernel_control.py` was written and hash-frozen before author-helper inspection.
The input is q(p)=exp(-1/(1-p²)) for |p|<1, zero otherwise, on the torus.
Two smooth periodic dispersion extensions may agree with c+p and c-p near
this support. Thus the kernel at integer propagation time mu is exactly
k_0(z+mu v). This identity follows by combining exponents in the defining
Fourier integral, independently of the implementation of the phased FFT.
The two velocities are separated although their geometric momentum supports
coincide; this exercises the mixed-dispersion scope of C18.

The code compares phased FFT coefficients at mu=0,1,16,128,896 for both
velocities against translated base coefficients at 5001 integer z values.
The fixed tolerance was 2e-11. Maximum error was 1.2658263715938763e-14.
The finite Schur calculation exploits factorization and an inclusion/exclusion
identity for the product cutoff. For the small t=4,s=8 case it is checked
against an explicitly materialized two-coordinate absolute kernel; maximum
error is 1.3877787807814457e-17. The full 16 time pairs include s=t,
s=t+1, s=2t and s=8t for t=16,32,64,128. Two grid resolutions, 32768 and
65536, differ by at most 1.3877787807814457e-16 in the finite sums.

The cutoff values in this finite control are indicators of fixed intervals;
only the geometric kernel part of the argument is tested. The proof itself
uses the required smooth h and chi. The column set is finite and no numerical
tail estimate is supplied. The finite values are therefore not bounds for
the complete infinite operator and no observed rate establishes rapid decay.

At t=128,s=256, x=(t,-t), y=(0,0), the correct kernel has coefficient
arguments (2t,-2t), while the reversed sign has (0,0). The actual moduli are
4.2750213491402566e-19 and 0.00499337412079394 respectively, rejecting the
wrong sign against the frozen threshold 1e-4. No threshold was tuned after
examining this result. The one run took 0.14783975016325712 seconds and had
exit code 0 under a declared 60-second timeout. Complete output and command
metadata are in `independent_control.*`.

## Author helper and mutation failures

The complete helper `check_detector_algebra.py` computes finite Fourier
matrices directly with Python complex arithmetic. The expected shift formula
comes from the Fourier convention and is separately derived in the written
proof. The two-time identity retains g before h. The affine-in-time w example
tests the reversed integral sign directly, although it is only a finite-time
identity and does not itself have the weak limit used in the theorem. The
source filter example tests qR=R followed by noncommuting position
multiplication. Exact rational convex combinations test stationary geometry,
and cubic arithmetic plus a periodic sine example detect the primary typo.

No measured target, fitted prefactor, physical proxy or synthetic PASS flag
is substituted for a calculation. Some expected values are of course known
identities; the relevant defect tests show the formulas are discriminating
at that finite scope. In particular, the final summary's six-check count is
not scientific evidence in its own right.

The reviewer ran the original helper without using its write-wrapper, to
avoid changing the author's frozen output directory. The reproduction command
and all bytes are in `author_reproduction.*`. It exited 0 in
0.02564449980854988 seconds; stdout is exactly the saved 1481 bytes and stderr
is empty. The largest reported correct finite-matrix error is
3.66205343881779e-15. The incorrect formulas have errors 1.81747 (free phase),
0.0288191 (cutoff order), 14.6492 (Duhamel sign), and 0.109420 (filter deletion).

Post-freeze `mutate_author_controls.py` writes copies only in `mutations/`.
It corrupts one correct formula per copy. All six runs terminate at the
intended assertion; complete stderr and partial stdout survive for each.
These are actual, expected failures, not fabricated counterfactual log lines.
The mutation suite is an assessment of the author helper, not independent
pre-exposure evidence. The originals remain byte-identical.

## Source precision, inventory and operational failures

Both PDF hashes match the declared primary versions. Complete original
Dybalski pages 4 and 12 were rendered with the bundled pdftoppm at 130 dpi
under separate declared 60-second timeouts (exit 0; empty stdout/stderr) and
visually inspected. The empty-set clause and the B.17 minus sign are visible.
The render logs and images are retained here. This was read-only source
inspection under the PDF skill, not authoring a new scientific PDF.

The exact directional identity is

  f'''(lambda) = (D³Sigma(xi+lambda z/2)[z,z,z]
                 +D³Sigma(xi-lambda z/2)[z,z,z])/8.

The frozen reconstruction's phrase about '(z.grad)^3/8 times the sum of the
two third derivatives' is imprecise wording: the directional derivative acts
on Sigma, not on an already differentiated function. The displayed formula
here is the intended identity. It does not alter the main analytic proof,
which does not use B.17. In a multi-index expansion the usual multinomial
coefficients must also be retained; the one-dimensional finite test makes
no claim to check that further source typography.

All 63 author receipt entries were checked programmatically against actual
bytes (or the pinned planning Git object). The source ledger's input list is
exactly the receipt's. All evidence files are covered after the stated four
receipt/wrapper exclusions. `author_receipt_verification.json` retains every
expected and actual hash, not just an aggregate count. Hash agreement checks
identity, not the truth of self-reported reading or science status.

Observed operational failures/limits were preserved rather than hidden:

- The review initially attempted to read SCIENCE_WORKFLOW.md on the planning
  branch; Git correctly reported that path absent there. Planning AGENTS
  points to science main, so the actual workflow was read at the frozen
  locally available main revision. No repository change was made.
- An initial filesystem AGENTS inventory was unnecessarily broad and returned
  a partial listing. No listed unrelated source content was used. Some early
  batched read outputs were truncated; the omitted mathematical sections
  were subsequently read in bounded chunks before the reconstruction freeze.
  The receipt itself was verified through every parsed entry, rather than
  treating its truncated display as a complete check.
- The author's preserved repository-search launch failure was an absent
  guessed rg executable path, followed by a successful resolved-path run.
  Its full failure, search output and wrapper metadata were inspected.
  No search result is being used as an absence or novelty theorem here.
- No Lean proof, full microscopic model construction, physical realization,
  independent source extraction for all page text, or audit certification
  was performed. The model and reasoning setting remained inherited.

No author source correction was necessary. The live recovery surface is
`CHECKPOINT.md`; immutable pre-control evidence is never rewritten.
