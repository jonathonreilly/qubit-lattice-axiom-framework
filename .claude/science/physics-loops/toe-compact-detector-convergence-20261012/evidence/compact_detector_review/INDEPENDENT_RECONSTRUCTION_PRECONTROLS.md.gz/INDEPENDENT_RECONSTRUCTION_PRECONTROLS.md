# Independent reconstruction before author controls

This record covers all of `COMPACT_DETECTOR_CONVERGENCE_PROBE.md`, 339 lines,
SHA-256 `bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64`.
It was written before opening `compact_detector_convergence/` (including its
helper, output, receipts and images). The candidate itself describes its controls;
that description is shared context. The complete EX review was also read, so its
preliminary conclusions are shared context, not a source of independent authority.
The mathematics below was reconstructed directly. No Fock theorem was used.

## Contract and sources

The claim is a conditional theorem for one fixed finite creator arrangement,
on each finite energy subspace. The direct assumptions are commuting positive
time evolution and geometric lattice translations fixing the vacuum; almost
local creators and norm time derivatives; strictly positive compact temporal
transfer; compact full operator geometric filters; exact vacuum graph vectors;
and pairwise disjoint compact convex detector velocity regions containing the
filtered creator velocities. The positive detector product additionally needs
the vacuum remainder C25 and a unique zero-energy vacuum. Realization of this
setting, full-GNS exhaustion, detector coverage, ND and retained status are
outside the theorem.

Read complete: target; 404-line compact scattering source
`d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`;
28-line EX repair `d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`;
262-line EX obligation `c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2`;
131-line EX review `8c9f7bb60724982ce7580a8b5688d8b61572ea008d92305f057d3f9b7a4e735d`.
Primary Dybalski v1 pages 1–13 were read, including the whole Theorem 4.2 proof
and Appendices A–B. BDN v2 pages 9–19 and 39–43 were read, covering transfer,
almost locality and its proof, finite-energy bound, packet estimates and Cook
construction. The original PDFs in `scattering_exhaustion_next/sources/` match
the candidate's hashes. The primary arXiv version pages were opened as well.
No DG, Kruse or Graf–Schenker comparison theorem enters the PC proof.

Instructions: planning `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; science workflow,
physics-claim-reviewer, relevant review-loop scientific lenses and proof-search
governance from locally available main `a13caa4885f547c8d206265b031ba7649e539fd9`.
The source checkout remains read-only at `c3f84746b1991e0a15c6da79d049b89d9469f727`.
No fetch was run because this dispatch forbids Git changes; local ref freshness
is the limit of that operational check. The explicit dispatch preserves the
inherited model and forbids subdelegation, overriding older procedural defaults.

## 1. Filtering, positive-energy bounds and scattering map

With Fourier convention fhat(p)=sum_x exp(-ipx) f(x), convolution of spatial
smears multiplies their Fourier multipliers. Thus C2 restricts full operator
transfer, not merely the vacuum vector. Taking adjoints changes coefficients
to their conjugates; replacing x by x+z in a scalar amplitude multiplies its
Fourier transform by exp(+ipz). The resulting factor is conjugate(phi(p)).
For finite-energy input the unfiltered amplitude is square summable by the
annihilation bound below. Independent coordinate smears therefore give exactly
F_t=P_Lambda F_t and J_t=J_t P_Lambda as bounded-map identities. Noncommutation
of the operator factors does not obstruct coordinate convolution. The sum over
z converges in norm; almost locality follows by using radius r/2 approximants
for |z|<=r/2 and estimating the remaining Schwartz tail by operator norms.
The same argument applies to time derivatives. Temporal transfers, graph and
centre sector are preserved because their implementations commute with shifts.

Here is an independent check of the finite-energy constant. For a finite site
set let Q=sum_x A_x^* A_x. Let E_r be the common kernel of every ordered word
of length r, and b_r the supremum of <u,Qu> on its unit sphere. A_x E_r is a
subspace of E_(r-1), and b_1=0. Expanding Q^2 once gives exactly

  ||Q u||^2 = sum_xy <A_x u,[A_x,A_y^*]A_y u>
               + sum_xy <A_y A_x u,A_x A_y u>.

The matrix of commutator norms has both row and column sums at most S_B.
Its quadratic form is at most S_B sum_x||A_x u||^2. Cauchy–Schwarz in (x,y)
bounds the absolute value of the second sum by sum_xy||A_y A_x u||^2, and the
last expression is <=b_(r-1)<u,Qu>. Thus <Q>^2<=||Qu||^2<=
(S_B+b_(r-1))<Q>, including the zero case. Taking the supremum proves
b_r<=(r-1)S_B. No invariance of E_r or P_R under Q was assumed. Every ordered
r-fold annihilator word kills P_R if r epsilon>R, by spectral transfer and
positive energy. Choose r=floor(R/epsilon)+1, then pass through increasing
finite spatial sums of the compressed positive operators. This proves C4,
including R<epsilon and the threshold case R/epsilon integral. Iteration on
lowered energy subspaces proves C5 uniformly in common time.

The vectors defining J_t have energy <=L=sum_i L_i. Pairing only against P_L
and using C5 bounds J_t by M_L on finite-support functions; hence it extends
to all ell^2. Vacuum invariance gives J_t=e^(itH) J_0. Duality gives exactly
the reverse creator order in C6. The C7 support identity therefore holds on
the whole domain, not only a selected packet subspace.

For S_t=J_t e^(-it omega), insert q into any tensor product of smooth Fourier
amplitudes, since S_t=S_t q. Its factors then have separated velocity supports.
The one-particle clocks cancel on the vacuum graph. Differentiation gives
the time derivative creator AND the packet multiplier -i Sigma_i. Commuting
the derivative packet toward the vacuum leaves every pair commutator and all
n-2 spectators. Each packet is O((1+t)^d), each derivative commutator is
O((1+t)^(2d-N)); hence each full term is O((1+t)^(nd-N)). Taking N=nd+2
gives an integrable bound. For n=1 the derivative is identically zero.
Convergence holds on the linear span of smooth tensor products, which is dense,
and uniform boundedness ||S_t||<=M_L extends it to all ell^2. Strictly, it is
this linear span that is dense; the candidate's 'product functions are dense'
is conventional shorthand and causes no gap because convergence is linear.

For fixed a, e^(iaH)S_t=S_(t+a)e^(ia omega). Taking strong limits proves C10.
Every chosen range is invariant in both time directions, so its closed span
with the vacuum is reducing for H. No isometry or surjectivity was used.

## 2. Source equation and regularity

For Psi in P_R H, F_t=J_0^*e^(-itH)Psi is C^1 in ell^2, with derivative
-iJ_0^*H e^(-itH)Psi. The C5 bound applies to H Psi as well as Psi, yielding
the two C11 bounds. Pointwise differentiation of the norm-smooth products
agrees with this ell^2 derivative because coordinate evaluation is continuous.

Let kappa be the inverse Fourier coefficients of real smooth periodic Sigma.
Sigma(D)f(x)=sum_z kappa(z)f(x-z), so the sign tau_(-z) in A^Sigma is correct.
Its scalar row equals the row of A followed by H on the vacuum graph. The
vacuum graph is in compact energy, so the row identity initially established
on Dom H extends to every vector. Since the inner product is antilinear in
its first argument, the derivative row is -i times this H row. Consequently
<Omega,(delta A+i A^Sigma)(t,x)Phi>=0. A^Sigma is almost local by its Schwartz
kernel; norm differentiation and spectral smearing preserve the negative
temporal transfer needed for the source terms.

In the product derivative replace delta A_i by D_i-i A_i^Sigma. The latter
terms sum to -i omega(D)F_t. Moving D_i to the left gives
sum_(j<i) A_1...A_(j-1)[A_j,D_i]A_(j+1)...A_(i-1)A_(i+1)...A_n,
with a PLUS sign, and the final leftmost D_i term vanishes on the vacuum row.
This is all of C14; it includes nonadjacent commutators and the dispersion
part of D_i. Its common time factors out by the automorphism alpha_t, leaving
uniform almost-local commutator bounds. Fixed spectator norms then prove the
pointwise part of C15. That pointwise bound cannot be summed over arbitrary
spectator coordinates. The global ell^2 source bound instead follows from
R_t=F'_t+i omega F_t. The source is continuous in ell^2.

The subspace P_Lambda ell^2 is closed. Since F_t lies in it at every time,
its strong derivative does too; omega preserves it. Thus the COMPLETE source
satisfies R_t=q R_t. There is no inference from the support of individual
vacuum factors or individual commutator terms. For a compact chi supported
away from all collision planes, every separation in its support is >=c s,
and the number of lattice points in s supp chi is O(s^m), m=nd. Taking the
square root after summation gives C17, with exponent m/2-N. For n=1 R=0.

## 3. Independent parameter-uniform kernel argument

Use lambda=t/s in [0,1], a=(x-y)/s and the normalized phase
theta(p)=a.p+(1-lambda)omega(p). On the nonzero spatial support,
x/t and v(p) lie in the fixed convex product K, while y/s is at distance
at least delta from K. Thus

  grad theta = (t/s)(x/t)+(1-t/s)v(p)-y/s,
  |grad theta|>=delta.

Let V=sup|v| and r=s+|x-y|. If |x-y|>=2s max(1,V), the triangle inequality
gives |grad Phi|>=|x-y|/2. Otherwise the displayed delta s bound controls r.
Hence |grad Phi|>=c r for a fixed positive c in BOTH regimes. Its zeroth
derivative is O(r), and each higher derivative is O(s)<=O(r). Therefore
grad Phi/r and all its derivatives are bounded independently of x,y,s,t,
and its norm is uniformly separated from zero on supp q. A smooth cutoff
vanishing near zero makes b=(grad Phi)/(i|grad Phi|^2) globally smooth and
periodic while leaving it unchanged near supp q. Every fixed derivative of
b is O(r^-1). The neighborhood can be chosen uniformly because the normalized
gradient has uniformly bounded derivatives and a uniform lower bound.

For L=b.grad_p, L exp(iPhi)=exp(iPhi) near supp q. After N integrations by
parts the amplitude is (-div(b .))^N q. Each summand contains N factors of
b or its derivatives and fixed derivatives of q, hence is bounded by C_N r^-N.
The fixed torus volume gives C22. Periodicity of exp(i(x-y).p), q and omega
removes boundary terms. All this remains valid at lambda=1 (s=t), where the
phase is linear and the spatial separation itself supplies the lower bound;
there is no singular 1/(s-t) factor. It also remains valid as lambda tends
to zero, so there is no hidden bound on s/t.

For N>m, split the lattice into |z|<s and shells 2^j s<=|z|<2^(j+1)s.
The first part is O(s^(m-N)); shell j contributes at most
C s^(m-N)2^(j(m-N)). The geometric series is finite. For fixed x, y maps
bijectively to z=x-y; for fixed y, x does also. Therefore BOTH absolute
Schur sums are at most C_N s^(m-N), without relying on a finite number of
rows or interchanging the two suprema. The operator norm has the same bound.
Taking N>m+A proves C18. The constants depend on fixed cutoff seminorms,
dispersion derivatives, convex separation, n and d. No family-uniform claim
is justified as those data vary.

Convex regions exist even if a velocity is on the hull boundary: take a
sufficiently small fixed enlargement of each original hull, then a sufficiently
small momentum neighborhood. Compactness and positive distance between hulls
keep the enlarged sets disjoint. Extensions of Sigma outside the chart are
smooth real periodic functions; only their values near q enter the kernel
stationary argument. No relation between momentum supports of different
species is required. Zero h gives the zero target directly.

## 4. Reversed integral, free limit and detector limit

Let w_t=S_t^*Psi. Strong convergence of S_t implies ONLY weak convergence
w_T to S^*Psi. K_t=e^(it omega)g h_t e^(-it omega) is finite rank for each
fixed t because h_t has finitely many nonzero lattice entries. Thus at fixed
t, K_t w_T converges in norm. The finite-interval fundamental theorem gives

  K_t w_t = K_t w_T - integral_t^T K_t e^(is omega)R_s ds.

This fixes the minus sign without a scattering-sector argument. Insert q on
R_s and split AFTER q: q chi_s R_s+q(1-chi_s)R_s. The localized part is
bounded by C17 and fixed operator norms; the other part by C18 and the global
C15 bound. For every A, the integrand has norm <=C_(A,R)s^-A||Psi|| uniformly
for s>=t>=1. Continuity supplies Bochner measurability. Choose A>N+1; absolute
integration gives a C_(N,R)t^-N tail. The T->infinity limit is now in norm
at fixed t. Only after this equality is obtained is t taken to infinity.
This proves C24a; a moving-t compactness inference is absent.

For fixed eta, conjugating exp(i eta.X/t) acts on Fourier functions by
exp(it[omega(p)-omega(p-eta/t)]) fhat(p-eta/t). The periodic smooth dispersion
gives uniform convergence of the phase to exp(i eta.v(p)); torus translation
is strongly continuous on L^2. All these operators have norm one. Integrate
against the L^1 Fourier transform of the Schwartz function h using vector
dominated convergence. Thus K_t strongly tends to g h(v). Since
S^*=P_Lambda S^* and g=1 on Lambda, the exact limit is h(v)S^*Psi. This proves
PC and C24 for all finite-energy vectors. It is a strong limit, not an
operator-norm free limit. On H_sc perpendicular, S^*Psi=0, and C24a gives
the stated rapid uniform estimate on each finite-energy unit ball.

C25 plus temporal transfer and unique zero-energy vacuum makes every
A_1...A_n P_J have vacuum range. The product C_1...C_n has finitely many
spatial tuples at fixed t. Reorder it into (A_1...A_n)^*(A_1...A_n), with
weights, swapping only distinct labels. Their positions have separation
>=c t; all other factors are fixed bounded operators. Each commutator is
O(t^-N), the number of tuples is O(t^(nd)), and the number of swaps is fixed.
This proves C27 after vacuum factorization. The compressed Q_J(t) is positive
and bounded by M_L^2||h|| P_J.

The identity J_t g=J_t gives Q_J(t)Psi=P_J S_t u_t(Psi) for Psi in P_J H,
without moving g across h_t. Uniformly bounded S_t and norm-convergent u_t
give the displayed strong limit P_J S h(v) S^* P_J. Its positivity follows
from h>=0, and its range from the reducing scattering space. Intertwining
implies e^(iaH)S h(v)S^*e^(-iaH)=S h(v)S^*, since h(v) commutes with omega.
Therefore the uncompressed limit S h(v)S^*P_J already lies in P_J H and
equals the compressed value. This proves C28 and the subsequent uncompressed
claim. The weighted countable positive sum is valid arrangement by arrangement;
it grants no trivial-kernel or completeness statement.

## 5. Failure tests, source precision and prospective control

The rank-one strong/adjoint and moving-projection counterexamples in the
candidate are correct. The direct forward derivative leaves an unintegrable
1/t estimate; the reversed argument avoids needing it. Dropping the operator
filter or convex containment removes the proved nonstationary lower bound,
but this is not a general no-go. In Dybalski p.4 a nonempty h contains pairs
whose difference is zero, so the printed empty-set condition contradicts a
vacuum in Sp U. On p.12 the third derivative of
Sigma(xi+lambda z/2)-Sigma(xi-lambda z/2) is (z.grad)^3/8 times the SUM
of the two third derivatives. In one dimension, Sigma=sin and xi=0 gives
2 sin(lambda z/2), whose third derivative is nonzero generically; the printed
difference vanishes. The cubic estimate needed there survives the correction.
Neither formula is imported into the target's new kernel proof. The textual
source misprint is established; visual PDF confirmation will be recorded
separately if performed. No BDN Fock or global isolated geometric shell
theorem is being invoked without its hypotheses.

Current analytic disposition: no material error in C1–C28 at the stated
conditional fixed-arrangement scope. The proof is complete under its direct
premises. 'Linear span of smooth products' is the precise density wording.
No scientific source correction is currently required. Full physical
realization, ND, EX and formal retained status remain open/outside this review.

Before inspecting author controls I will freeze and run one distinct finite
control: a smooth compact momentum bump with two different linear dispersions
on its support, velocities +1 and -1. Its infinite-lattice Fourier kernel is
exactly a translated fixed coefficient sequence at integer time differences.
The implementation will compare direct phase quadrature/FFT with this shift,
compute both finite absolute Schur sums by a factorized route, check that route
against an explicit two-coordinate kernel, include s=t and s/t close to one,
and reject the opposite propagation sign using the collision source y=(0,0)
at s=2t, x=(t,-t). Two quadrature resolutions will check numerical stability.
The identities and wrong-sign threshold are preregistered in the script; no
finite trend will be called a proof of C18 or of infinite-volume convergence.
