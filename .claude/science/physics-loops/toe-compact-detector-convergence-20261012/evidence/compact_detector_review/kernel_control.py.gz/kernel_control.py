"""Independent finite Fourier-kernel controls; not an asymptotic theorem."""
import json
import math
import numpy as np

TOL = 2e-11
WRONG_SIGN_MIN = 1e-4
RESOLUTIONS = (32768, 65536)
TIME_PAIRS = tuple((t, s) for t in (16, 32, 64, 128)
                   for s in (t, t + 1, 2 * t, 8 * t))


def coefficients(size, mu, velocity):
    p = 2 * math.pi * np.arange(size) / size
    chart_p = (p + math.pi) % (2 * math.pi) - math.pi
    q = np.zeros(size)
    mask = np.abs(chart_p) < 1
    q[mask] = np.exp(-1 / (1 - chart_p[mask] ** 2))
    # On supp q the smooth periodic dispersion extension is constant + v*p.
    # The irrelevant constant is omitted, contributing only a unit phase.
    return np.fft.ifft(q * np.exp(1j * mu * velocity * chart_p))


def finite_schur(c0, t, s, padding=384, explicit=False):
    size = len(c0)
    mu = s - t
    xs1 = np.arange(math.ceil(.8 * t), math.floor(1.2 * t) + 1)
    xs2 = -xs1[::-1]
    ys = np.arange(-math.ceil(2 * s) - padding,
                   math.ceil(2 * s) + padding + 1)
    inside1 = (ys >= .7 * s) & (ys <= 1.3 * s)
    inside2 = (ys >= -1.3 * s) & (ys <= -.7 * s)
    b1 = np.abs(c0[(xs1[:, None] - ys[None, :] + mu) % size])
    b2 = np.abs(c0[(xs2[:, None] - ys[None, :] - mu) % size])
    a1, a2 = b1.sum(axis=1), b2.sum(axis=1)
    i1, i2 = b1[:, inside1].sum(axis=1), b2[:, inside2].sum(axis=1)
    row = float(np.max(a1[:, None] * a2[None, :] - i1[:, None] * i2[None, :]))
    c1, c2 = b1.sum(axis=0), b2.sum(axis=0)
    col = float(max(np.max(c1[~inside1]) * np.max(c2),
                    np.max(c1) * np.max(c2[~inside2])))
    if explicit:
        matrix = np.einsum('ay,bz->abyz', b1, b2)
        matrix *= 1 - inside1[None, None, :, None] * inside2[None, None, None, :]
        direct_row = float(matrix.sum(axis=(2, 3)).max())
        direct_col = float(matrix.sum(axis=(0, 1)).max())
        error = max(abs(row - direct_row), abs(col - direct_col))
        if error >= TOL:
            raise AssertionError(('Schur factorization', error))
        return {'row': row, 'column': col, 'direct_error': error}
    return {'t': t, 's': s, 'row': row, 'column': col,
            'finite_schur_bound': math.sqrt(max(0, row * col)),
            'x_count': len(xs1) * len(xs2), 'y_coordinate_count': len(ys)}


def main():
    base = {n: coefficients(n, 0, 1) for n in RESOLUTIONS}
    shift_error = 0.
    for n in RESOLUTIONS:
        z = np.arange(-2500, 2501)
        for mu in (0, 1, 16, 128, 896):
            for velocity in (-1, 1):
                direct = coefficients(n, mu, velocity)
                err = float(np.max(np.abs(direct[z % n] - base[n][(z + mu * velocity) % n])))
                shift_error = max(shift_error, err)
    if shift_error >= TOL:
        raise AssertionError(('Fourier kernel translation identity', shift_error))
    print(json.dumps({'test': 'direct_phase_vs_translated_coefficients',
                      'max_error': shift_error, 'tolerance': TOL}))
    explicit = finite_schur(base[RESOLUTIONS[-1]], 4, 8, padding=16, explicit=True)
    print(json.dumps({'test': 'both_schur_sums_direct_2d_crosscheck', **explicit}))
    records = [finite_schur(base[RESOLUTIONS[-1]], t, s) for t, s in TIME_PAIRS]
    other = [finite_schur(base[RESOLUTIONS[0]], t, s) for t, s in TIME_PAIRS]
    stability = max(abs(a[key] - b[key]) for a, b in zip(records, other)
                    for key in ('row', 'column'))
    if stability >= TOL:
        raise AssertionError(('quadrature refinement', stability))
    print(json.dumps({'test': 'two_resolution_finite_schur_values',
                      'max_difference': stability, 'cases': records,
                      'scope': 'finite columns only; no tail certificate or theorem inferred'}))
    n = RESOLUTIONS[-1]
    c = base[n]
    t = 128
    # x=(t,-t), y=(0,0), s=2t. Correct arguments are (2t,-2t),
    # while opposite propagation gives (0,0), stationary on the collision set.
    correct = float(abs(c[(2 * t) % n] * c[(-2 * t) % n]))
    wrong = float(abs(c[0] ** 2))
    if wrong <= WRONG_SIGN_MIN or correct >= wrong * 1e-5:
        raise AssertionError(('opposite-sign collision discriminator', correct, wrong))
    print(json.dumps({'test': 'opposite_sign_collision_discriminator',
                      'correct_kernel_modulus': correct,
                      'wrong_kernel_modulus': wrong,
                      'required_wrong_minimum': WRONG_SIGN_MIN}))
    print(json.dumps({'status': 'complete', 'controls': 4,
                      'not_proved': ['all_scale_C18', 'PC', 'ND', 'EX', 'physical_realization']}))


if __name__ == '__main__':
    main()
