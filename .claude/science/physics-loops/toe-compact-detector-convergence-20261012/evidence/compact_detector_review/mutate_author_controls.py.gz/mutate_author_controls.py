"""Post-freeze mutation tests of copied author controls; never alter originals."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
source_path = here.parent / 'compact_detector_convergence/check_detector_algebra.py'
source = source_path.read_text()
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == 'e056da90bf5526e2af387df869a2b86f6dda2300408ea0054ee3bd481954bffb'
mutations = [
    ('free_phase', 'expected = [[cmath.exp(1j * t * (omega[k] - omega[j]))',
     'expected = [[cmath.exp(-1j * t * (omega[k] - omega[j]))',
     'assert good_error < 1e-11 and wrong_error > 0.1'),
    ('cutoff_order', 'right = mul(mul(mul(u(t), g), h), u(s - t))',
     'right = mul(mul(mul(u(t), h), g), u(s - t))',
     'assert delta(left, right) < 1e-11 and delta(left, wrong_order) > 1e-3'),
    ('reversed_integral_sign', 'recovered = add(mul(kt, ws), scale(-1, integral))',
     'recovered = add(mul(kt, ws), integral)',
     'assert delta(actual, recovered) < 1e-11 and max(phase_errors) < 1e-11'),
    ('filter_deletion', 'filtered_after = mul(q, mul(chi, v))',
     'filtered_after = mul(chi, v)',
     'assert delta(mul(q, v), v) == 0 and delta(filtered_after, unfiltered_after) > 0.1'),
    ('stationary_sign', 'y = lam * av + (1 - lam) * vel',
     'y = lam * av - (1 - lam) * vel', 'assert lo <= y <= hi'),
    ('third_derivative_difference', 'correct_cubic_remainder = z ** 3 * F(1, 16) * (F(6) + F(6)) * F(1, 3)',
     'correct_cubic_remainder = z ** 3 * F(1, 16) * (F(6) - F(6)) * F(1, 3)',
     'assert actual_cubic_remainder == correct_cubic_remainder'),
]
out = here / 'mutations'
out.mkdir(exist_ok=True)
results = []
for name, old, new, expected_assertion in mutations:
    assert source.count(old) == 1, name
    path = out / (name + '.py')
    path.write_text(source.replace(old, new))
    command = [sys.executable, str(path)]
    start = time.monotonic()
    run = subprocess.run(command, capture_output=True, timeout=60, cwd=here)
    (out / (name + '.stdout')).write_bytes(run.stdout)
    (out / (name + '.stderr')).write_bytes(run.stderr)
    result = dict(name=name, command=command, declared_timeout_seconds=60,
                  elapsed_seconds=time.monotonic()-start, exit_code=run.returncode,
                  expected_assertion=expected_assertion,
                  rejected_at_expected_assertion=run.returncode != 0 and
                  expected_assertion in run.stderr.decode() and b'AssertionError' in run.stderr)
    results.append(result)
    print(json.dumps(result))
(here / 'mutation_results.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(r['rejected_at_expected_assertion'] for r in results)
