"""Validate and stage the complete reviewed E/PC milestone; no audit verdict."""
from pathlib import Path
from urllib.parse import unquote
import ast, gzip, hashlib, json, os, re, subprocess, sys

S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-compact-detector-convergence-20261012'
BASE='c3f84746b1991e0a15c6da79d049b89d9469f727'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']
notes=[r for r in rows if r['kind']=='note'];prim=[r for r in rows if r['kind']=='primary']
assert len(notes)==len(prim)==2
mut=json.loads((S/'epc_primary_mutations/manifest.json').read_text())['runs'];assert len(mut)==11
for r in mut:
    body=(W/r['primary_path']).read_text();assert sha(body.encode())==r['primary_sha256']
    variant=(S/'epc_primary_mutations'/(r['name']+'.py')).read_text()
    assert body.count(r['before'])==1 and variant==body.replace(r['before'],r['after'],1)
    assert sha(variant.encode())==r['source_sha256']
    out=(S/'epc_primary_mutations'/(r['name']+'.stdout')).read_bytes()
    err=(S/'epc_primary_mutations'/(r['name']+'.stderr')).read_bytes()
    assert sha(out)==r['stdout_sha256'] and sha(err)==r['stderr_sha256']
    assert r['exit_code']==1 and r['intended_failure'] and not r['timed_out'] and r['stdout_baseline_prefix']
    assert r['expected_assertion'] in err.decode() and 'AssertionError' in err.decode()
    assert r['elapsed_seconds']<r['timeout_seconds']==60
executions={};comparisons=[]
for label,baseline in [('E','scattering_exhaustion_next/reduction_algebra.stdout.jsonl'),('PC','compact_detector_convergence/detector_algebra.stdout')]:
    e=json.loads((S/('epc_'+label+'_canonical_execution.json')).read_text());executions[label]=e
    assert e['status']=='ok' and e['exit_code']==0 and e['timeout_sec']==60 and e['stderr']==''
    old=(S/baseline).read_text();assert e['stdout'].startswith(old)
    extra=e['stdout'][len(old):].splitlines();assert len(extra)==7
    comparisons.append(dict(label=label,complete_original_stdout_identical=True,original_stdout_bytes=len(old.encode()),appended_lines=extra))
(S/'EPC_canonical_output_comparison.json').write_text(json.dumps(dict(checks=comparisons),indent=2)+'\n')
graph=W/'docs/audit/data/citation_graph_manifest.json'
old=json.loads(subprocess.check_output(['git','show',BASE+':'+str(graph.relative_to(W))]));new=json.loads(graph.read_text())
assert (new['node_count'],new['edge_count'])==(old['node_count']+2,old['edge_count']+2)
assert all(new['nodes'].get(k)==v for k,v in old['nodes'].items())
assert {k:v['out_degree'] for k,v in new['nodes'].items() if k not in old['nodes']}=={
 'compact_detector_exhaustion_reduction_bounded_theorem_note_2026-10-12':1,
 'compact_detector_convergence_bounded_theorem_note_2026-10-12':1}
compat=json.loads((S/'epc_focused_audit_compat.json').read_text())
assert compat['checked']==compat['failures']==compat['control_failures']==[]
(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete source composition

Root read both full source proofs and their necessary premises, complete
separate reviews/reconstructions and the controls at the exact scopes in the
preserved root coverage records. Root supplied mechanisms and is a contributor,
not a second independent reviewer. All new primary helpers, baseline output,
eleven literal primary defects and their complete tracebacks were read.

Publication adds claim/review/recovery metadata and makes linear-span density
explicit. Every complete frozen original is preserved; no equation, estimate,
domain or physical premise changes. Full original helper bodies are retained
with timeout, input, assertion and finite-scope metadata only. Canonical output
matches every original calculated record. Exact maps reconstruct all four
complete artifacts. Older SC/Fock publication science remains unchanged.

Both proofs retain full operator filtering, mixed lowering words, all source
commutators, global versus localized norm distinctions, all spectator factors,
both Schur sums, convex separation, fixed-time compactness and ordered limits.
No finite-grid rate, source-review label or evidence count is used as a proof.
ND, EX, physical realization and retained status remain outside this result.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped publication verification

Canonical E execution exited0 in{executions['E']['elapsed_sec']:.9f}s; PC exited0
in{executions['PC']['elapsed_sec']:.9f}s. Each used its declared60s timeout and
has empty stderr. All five original E records and seven original PC records
are byte-identical, followed by seven explicit scope lines for each primary.
PC's seventh original record is a scope summary, not a seventh computation.
Both runners reject optimized assertions and bind their complete input notes.

Eleven actual whole-primary defects failed at their intended assertions: five
ordered-source/time/dispersion/resolvent defects and six Fourier/order/filter/
geometry/derivative defects. Every changed source, command, timeout, stdout
and full stderr is preserved. Partial stdout matches the original baselines.
These are finite discriminating controls, not proofs of analytic convergence.

The citation graph has{new['node_count']}nodes and{new['edge_count']}edges:
two new nodes, two explicit creator-dependency edges, every older node unchanged.
Focused changed-audit-evidence compatibility selected no applied rows and
reported no failures. Global combined audit pipeline and strict audit lint
were not run; they remain independent landing gates, with no applied verdict.

Exact full-source reconstruction, syntax, cache/input freshness, ordinary local
links, all own/external evidence identities, vocabulary fix/report, whitespace
and the exact staged file set are checked before commit. Third-party primary
papers/images/texts remain external with official URLs and hashes. No fit,
confidence interval, Lean certificate or physical-model certification is claimed.
''')
rh=P/'REVIEW_HISTORY.md'
rh.write_text(rh.read_text().split('\n## Publication conformance\n',1)[0]+'''
## Publication conformance

The two full notes state their physical conditions, exact imports, complete
arguments and downstream limits. Separate reconstructions, independent finite
controls, author reproductions and all relevant failures remain distinct and
source-bound. Trace, goal, claim type, provisional status and recovery are
explicit. Full source maps, actual primary defect runs, canonical execution,
ordinary references and the citation change are checked at final identities.
No draft, merge, main push, axiom/prompt edit, audit verdict or retained-status
promotion is included. The global pipeline and strict audit lint remain unrun.
''')
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in rows]+[P/'reconstruct.py']
for mode in ['fix','report-only']:
    path=S/('epc_final_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(path.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
    path.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'epc_final_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
for row in prim:
    ast.parse((W/row['publication_path']).read_text())
    assert runner_cache.cache_status(row['publication_path'])==runner_cache.cache_identity_status(row['publication_path'])=='fresh'
links=[]
for p in editable:
    if p.suffix!='.md':continue
    prose=[];fenced=False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
    for target in re.findall(r'\]\(([^)\s]+)\)','\n'.join(prose)):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(p,target)
        links.append(dict(source=str(p.relative_to(W)),target=target))
emap=json.loads((P/'EVIDENCE_MAP.json').read_text());evidence={r['preserved']:r for r in emap['files']}
def preserve(src):
    b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(b,mtime=0)
    if dst.exists() and dst.read_bytes()!=packed:
        prior=evidence.pop(str(dst.relative_to(P)));oldpath=dst.with_name(dst.stem+'.previous_'+prior['sha256'][:12]+dst.suffix)
        assert not oldpath.exists();dst.rename(oldpath);prior['preserved']=str(oldpath.relative_to(P));prior['historical_source_version']=True;evidence[prior['preserved']]=prior
    dst.write_bytes(packed);evidence[str(dst.relative_to(P))]=dict(original=str(src),preserved=str(dst.relative_to(P)),bytes=len(b),sha256=sha(b))
for src in sorted((S/'epc_primary_mutations').rglob('*')):
    if src.is_file():preserve(src)
for name in ['prepare_epc_notes.py','prepare_epc_packet.py','run_epc_primary_mutants.py','finish_epc_delivery.py',
 'epc_E_canonical_execution.json','epc_PC_canonical_execution.json','EPC_canonical_output_comparison.json',
 'epc_initial_vocab_fix.json','epc_initial_vocab_fix.log','epc_final_vocab_fix.json','epc_final_vocab_fix.log',
 'epc_final_vocab_report-only.json','epc_final_vocab_report-only.log','epc_final_reconstruction.log',
 'epc_citation_execution.json','epc_citation_build.stdout','epc_citation_build.stderr','epc_citation_manifest.stdout','epc_citation_manifest.stderr',
 'epc_focused_audit_compat.json','epc_focused_audit_compat.stderr','epc_focused_audit_compat.execution.json']:
    preserve(S/name)
for row in evidence.values():
    b=gzip.decompress((P/row['preserved']).read_bytes());assert sha(b)==row['sha256'] and len(b)==row['bytes']
for row in emap['external_reference_sources']:
    b=Path(row['original']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
mech=dict(full_notes_and_primaries_reconstruct=True,actual_complete_primary_defects=11,
          preserved_evidence_files=len(evidence),external_primary_bindings=len(emap['external_reference_sources']),
          cache_and_inputs_fresh=True,ordinary_links=links,citation_delta=dict(nodes=2,edges=2),every_old_graph_node_unchanged=True,
          scope='Mechanical verification; separate analytic reviews carry the mathematical check; no audit verdict.')
out=S/'epc_delivery_mechanical.json';out.write_text(json.dumps(mech,indent=2)+'\n');preserve(out)
emap['files']=[evidence[k] for k in sorted(evidence)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in rows]+[graph]+[runner_cache.cache_path_for(r['publication_path']) for r in prim]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
    row=dict(path=str(p.relative_to(W)),sha256=sha(p.read_bytes()))
    if p.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(p.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,scope='Exact intended publication set except this self-referential manifest.',files=ident),indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True,timeout=60);subprocess.run(['git','diff','--cached','--check'],check=True,timeout=60)
for row in ident:assert sha(subprocess.check_output(['git','show',':'+row['path']]))==row['sha256']
staged=set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}
assert staged==set(paths) and not subprocess.check_output(['git','diff','--name-only'])
assert all(x.startswith('A\t') or x=='M\tdocs/audit/data/citation_graph_manifest.json' for x in subprocess.check_output(['git','diff','--cached','--name-status'],text=True).splitlines())
result=dict(staged_files=len(paths),staged_hashes_match=True,whitespace_clean=True,**mech)
(S/'epc_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
