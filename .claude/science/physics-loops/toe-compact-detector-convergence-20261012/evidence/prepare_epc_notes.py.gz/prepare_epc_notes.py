"""Compose the complete reviewed detector reduction/convergence milestone."""
from pathlib import Path
import hashlib, json, subprocess

S=Path(__file__).resolve().parent
W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-compact-detector-convergence-20261012'
BASE='c3f84746b1991e0a15c6da79d049b89d9469f727'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()==BASE
assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain'])
assert json.loads((S/'PC_root_review_coverage.json').read_text())['review_accepted']
P.mkdir(exist_ok=False)
sc='COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md'
eid='compact_detector_exhaustion_reduction_bounded_theorem_note_2026-10-12'
cid='compact_detector_convergence_bounded_theorem_note_2026-10-12'
enames=['COMPACT_DETECTOR_EXHAUSTION_REDUCTION_BOUNDED_THEOREM_NOTE_2026-10-12.md','COMPACT_DETECTOR_CONVERGENCE_BOUNDED_THEOREM_NOTE_2026-10-12.md']
packet='[complete detector milestone packet](../.claude/science/physics-loops/toe-compact-detector-convergence-20261012/)'
outputs=[]
for label,source_name,target,claim,scope,runner in [
 ('E','SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md',enames[0],eid,
  'Under the supplied direct compact-creator conditions and a unique gapped vacuum, full operator filtering gives the scalar detector source reduction; propagation convergence and a no-common-kernel condition imply full-GNS exhaustion. This theorem does not prove the no-common-kernel condition or physical realization.',
  'compact_detector_exhaustion_reduction_2026_10_12.py'),
 ('PC','COMPACT_DETECTOR_CONVERGENCE_PROBE.md',enames[1],cid,
  'For each fixed admissible arrangement of supplied direct compact creators with separated convex velocity regions, the scalar detector amplitude converges in norm on every finite-energy vector. With the exact vacuum remainder and unique vacuum, positive detector operators converge strongly with range in the constructed scattering space. No common-kernel triviality, exhaustion or physical realization follows.',
  'compact_detector_convergence_2026_10_12.py')]:
    src=S/source_name;raw=src.read_text();original=raw
    expected={'E':'c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2','PC':'bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64'}[label]
    assert sha(raw.encode())==expected
    edits=[]
    def edit(a,b,reason):
        global raw
        assert raw.count(a)==1,(label,a,raw.count(a))
        raw=raw.replace(a,b,1);edits.append(dict(before=a,after=b,reason=reason))
    first=raw.splitlines()[0]
    meta='---\nclaim_id: '+claim+'\nclaim_type: bounded_theorem\nclaim_scope: '+json.dumps(scope)+'\nupstream_dependencies:\n  - compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11\nrunner: scripts/'+runner+'\nactual_current_surface_status: conditional-support\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\n---\n\n'
    edit(first,meta+first,'Register the exact conditional theorem, finite control and actual upstream creator premise.')
    if label=='E':
        edit('Status: bounded author derivation and primary-source route assessment, 2026-10-12. No asymptotic-completeness premise is added. The new results are the detector/source reduction in §4 and the conditional exhaustion criterion in §5. The two estimates named there remain unproved. This is neither an audit verdict nor a local-UHF no-go theorem.',
             'Status: conditional-support, bounded theorem and primary-source route assessment, 2026-10-12. A separate complete E1–E18 reconstruction found no required correction. The results are the detector/source reduction in §4 and the conditional exhaustion criterion in §5. This proof treats PC and ND as explicit additional conditions. The sibling theorem `'+enames[1]+'` now supplies PC for its stated admissible arrangements; ND remains open. No asymptotic-completeness premise or audit verdict is added, and no local-UHF no-go theorem is asserted.',
             'Record the completed E review and current PC status without changing the conditional implication or creating a reverse proof dependency.')
        edit('All files below are unchanged external sources under `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011` (abbreviated S). Copies, primary PDFs and page texts are in `scattering_exhaustion_next/sources/`.',
             'S denotes the original external research collection. The '+packet+' preserves the complete frozen note, repository sources, author and separate review evidence. EVIDENCE_MAP.json records recovery paths and external primary URLs/hashes; full third-party papers and page extractions remain external. The in-branch [compact-creator theorem]('+sc+') contains the complete upstream proof and its reviewed unique-vacuum/gap clarification.',
             'Make source recovery and the actual creator dependency portable.')
        edit('PROVISIONAL author extension; its fresh independent review was pending at this task\'s start',
             'Separate Fock review completed; the historical author freeze predates it. Its isometry conclusion is not an input here',
             'Refresh Fock review metadata while retaining the absence of that proof dependency.')
        for a,b in [
            ('not its provisional isometry conclusion','not its isometry conclusion'),
            ('adding the unproved (PC)','adding the explicit (PC) condition'),
            ('The provisional Fock theorem identifies','The separately checked Fock theorem identifies'),
            ('independently of the provisional Fock extension','without using the Fock extension'),
            ("the provisional Fock note's quantitative kernel induction","the Fock note's quantitative kernel induction"),
            ('independent of the still-provisional Fock-isometry identification','independent of the Fock-isometry identification')]:
            edit(a,b,'Refresh source-state wording only; no equation or proof condition changes.')
        edit('Such products are dense in the tensor product of the',
             'The linear span of such products is dense in the tensor product of the',
             'Make the conventional linear-span density statement explicit.')
        tail='The result is therefore a source-bound conditional route with one completed preliminary lemma and an exact terminal estimate. Full-GNS exhaustion remains a separate unproved obligation here.'
        edit(tail,tail+'\n\nThe separate review report has SHA256 `8c9f7bb60724982ce7580a8b5688d8b61572ea008d92305f057d3f9b7a4e735d`; its complete 337-line reconstruction was frozen before new author controls. Full evidence roles, original reading limits, operational failures and exact source bindings are preserved in the milestone packet. The [finite reduction control](../scripts/'+runner+') retains the complete original helper. Its five records and distinct independent finite controls are not continuum proofs. Root is a contributor, not the separate reviewer. PUBLICATION_EDITS.json and reconstruct.py recover the whole source and control. DELIVERY_CHECKS.md states the scoped publication verification; no Lean certificate or retained status is claimed.',
             'Record the finished complete source check and portable finite evidence.')
    else:
        edit('**Author status:** conditional support; independent review pending. **Trace:** proposed closure',
             '**Status:** conditional-support; complete separate C1–C28 reconstruction found no required correction. **Trace:** closure',
             'Record the completed focused source review.')
        edit('Write S for `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`. All predecessor files remain unchanged.',
             'S denotes the original research collection, preserved through the '+packet+'. EVIDENCE_MAP.json binds the complete original proof, source ledgers, author evidence and separate review. The in-branch [compact-creator theorem]('+sc+') supplies the direct creator construction. This note rederives the preliminary reductions it needs; the sibling exhaustion-reduction note states the downstream conditional criterion. Full third-party papers and page extractions remain external at their recorded identities.',
             'Make source paths portable and state the exact proof dependency.')
        edit('Smooth product functions on the torus are dense.',
             'The linear span of smooth product functions on the torus is dense.',
             'Use the precise linear-span density wording identified in the separate review.')
        edit('extends convergence from that dense product domain',
             'extends convergence from that dense linear span',
             'Keep the same precise density wording in the extension step.')
        edit('This author result needs a focused independent reconstruction before substantial downstream reuse.',
             'The complete proof has now received that separate reconstruction. The report `2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0` and its pre-author-evidence reconstruction/control freeze `4d75d0893cc6fdddb207dd31ddd137359874183b2f8b8b8878382c21adaa8702` are preserved in the milestone packet. The reviewer checked the full analytic argument, used a distinct two-time Fourier-kernel control, then reproduced the author output and rejected six actual copied-code defects. Finite Schur sums have no uncomputed-tail certificate; the written all-scale estimate establishes convergence. Root supplied the mechanism and is a contributor, not an independent reviewer.',
             'Replace the completed review obligation with exact evidence and its scope.')
        edit('Only this note and `compact_detector_convergence/` were written. The single current recovery surface is `compact_detector_convergence/CHECKPOINT.md`; exact input/output hashes are in its freeze receipt. Editable prompt files changed: none. No repository, Git, PR, audit, axiom, model or other-chat mutation or subdelegation was performed. The inherited model/reasoning setting and fixed deadline, 2026-10-12 16:00:52 UTC, were preserved.',
             'The [finite detector control](../scripts/'+runner+') retains the entire original helper. The milestone packet preserves its complete source, frozen recovery record, separate proof reconstruction, all controls and failures. PUBLICATION_EDITS.json and reconstruct.py recover every note and primary byte; DELIVERY_CHECKS.md states the publication checks and remaining audit gates. No Lean certificate, physical realization, retained status, applied audit verdict, editable-prompt change or physical-axiom change is claimed. The live campaign checkpoint remains in `toe-dynamics-bridge-20261009`, with fixed deadline 2026-10-12 16:00:52 UTC.',
             'Provide publication recovery and honest verification boundaries; preserve original operational history as frozen evidence.')
    for line in list(dict.fromkeys(x for x in raw.splitlines(keepends=True) if x.rstrip('\r\n').endswith((' ','\t')))):
        edit(line,line.rstrip()+'\n','Remove presentation-only trailing whitespace.')
    if raw.endswith('\n\n'):
        tail=raw[-180:];edit(tail,tail.rstrip()+'\n','Normalize final blank lines only.')
    (W/'docs'/target).write_text(raw)
    outputs.append(dict(kind='note',label=label,source_path=str(src),source_sha256=expected,
                        preserved_source='evidence/'+source_name+'.gz',edits=edits,appended_text='',
                        publication_path='docs/'+target,publication_sha256=sha(raw.encode())))

for label,helper,runner,target,total,scope,anchor in [
 ('E','scattering_exhaustion_next/check_reduction_algebra.py','compact_detector_exhaustion_reduction_2026_10_12.py',enames[0],5,
  'Finite ordered-word, periodic spin-chain, residual-window and resolvent algebra only; PC, ND and physical completeness require separate analytic arguments.', 'from collections import Counter\n'),
 ('PC','compact_detector_convergence/check_detector_algebra.py','compact_detector_convergence_2026_10_12.py',enames[1],6,
  'Finite Fourier, ordering, convex-geometry and source-typo controls only; infinite-lattice kernel decay and detector convergence rest on C1-C28.', 'from fractions import Fraction as F\n')]:
    src=S/helper;body=src.read_text()
    addition='AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = [\n    "docs/'+target+'",\n    "docs/'+sc+'",\n]\nif not __debug__:\n    raise RuntimeError("Run without -O: exact control assertions must be enabled")\n\n'+anchor
    assert body.count(anchor)==1
    suffix='\nprint("per_element: complete original finite algebra controls checked")\nprint("per_site: finite lattice fixtures only; no infinite-volume inference")\nprint("per_mode: Fourier and source signs checked at the stated finite scope")\nprint("per_block: ordered products and finite projections checked")\nprint("lattice_wide: checked and not executed — convergence and exhaustion require the written proofs")\nprint("TOTAL: PASS='+str(total)+' FAIL=0")\nprint('+json.dumps('SCOPE: '+scope)+')\n'
    text=body.replace(anchor,addition,1)+suffix
    (W/'scripts'/runner).write_text(text)
    outputs.append(dict(kind='primary',label=label,source_path=str(src),source_sha256=sha(body.encode()),
                        preserved_source='evidence/'+helper+'.gz',edits=[dict(before=anchor,after=addition,reason='Declare exact inputs/timeout and reject optimized assertions; all original calculations unchanged.')],
                        appended_text=suffix,publication_path='scripts/'+runner,publication_sha256=sha(text.encode())))
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=outputs),indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['kind','publication_path','publication_sha256']} for r in outputs],indent=2))
