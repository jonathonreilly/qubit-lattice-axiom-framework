"""Preserve reviewed E/PC proof evidence and exact external primary identities."""
from pathlib import Path
import gzip, hashlib, json

S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-compact-detector-convergence-20261012'
assert not (P/'STATE.yaml').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
texts={
'STATE.yaml':'''loop: toe-compact-detector-convergence-20261012
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-compact-patch-scattering-20261011
base_revision: c3f84746b1991e0a15c6da79d049b89d9469f727
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: direct_detector_convergence_and_conditional_exhaustion_reduction
provisional_dependencies: supplied_direct_compact_creators_and_stated_vacuum_remainder
independent_check: separate_complete_E1_E18_and_C1_C28_reconstructions
pr: 9486
pr_status: preparing_regular_PR_extension
next_action: canonical_controls_and_scoped_delivery_checks_then_publish
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md':'''# Exact mathematical contract

Construct the full scalar detector source reduction from the supplied direct
compact creators. Prove norm convergence for each admissible fixed arrangement,
then positive detector limits with scattering range under the exact vacuum
remainder. State the additional no-common-kernel condition needed for full-GNS
exhaustion. Do not assume it in the convergence proof.
''',
'ASSUMPTIONS_AND_IMPORTS.md':'''# Premises and complete source boundary

The same PR already contains the complete compact-creator theorem, its reviewed
unique-vacuum/gap clarification and the separate Fock theorem. E and PC use
the direct creator construction, with microscopic H/current implementations,
isolated selected mass components and finite centre selectors supplied.
Neither new proof uses the Fock isometry conclusion.

Every creator has strictly positive compact temporal operator transfer, full
geometric operator filtering, an exact compact vacuum graph, almost locality
and the required norm time derivatives. PC fixes finitely many creators and
nonnegative compact cutoffs with disjoint convex velocity hulls. Its positive
detector conclusion additionally uses the exact energy-only vacuum remainder
and a unique vacuum. No global isolated geometric Bloch shell is substituted
for these hypotheses. E1 supplies the gap for its exhaustion equivalence.

E retains PC and ND as conditions of its implication. PC now has a separate
direct proof for its admissible arrangements. No common kernel is proved
trivial; an arbitrary detector family need not cover even the chosen channels.
''',
'APPROACH_REGISTRY.md':'''# Complete argument families

1. Schwartz operator filters restrict full transfer; lowering-word kernels
   give finite-energy bounds. The exact remainder gives vacuum factorization.
2. Scalar source differentiation retains every dispersion commutator and
   spectator factor. Strong Hilbert differentiation gives its global norm;
   off-collision localization gives its rapid local decay.
3. The entire source inherits a closed Fourier support. Creation maps converge
   strongly by Cook on the linear span of smooth products; adjoints converge
   only weakly at this step.
4. Convex separation and a normalized two-time phase control every integration
   by parts coefficient. Both lattice Schur sums are uniform for s>=t>=1,
   including s=t and unbounded s/t.
5. Reverse the finite-interval scalar integral. Compactness is used at fixed t
   before sending its upper time to infinity; the source filter order is kept.
   Fourier dominated convergence then identifies the final strong limit.
6. Positivity and energy intertwining give the compressed/uncompressed detector
   limits. A positive weighted sum and ordered singular resolvent limits state
   the further exact exhaustion criterion, without proving its kernel vanishes.
''',
'ROUTE_PORTFOLIO.md':'''# Evidence roles

Both full analytic notes are preserved with separate complete source reviews.
The E reviewer supplied a distinct finite mixed-dispersion spin calculation;
the PC reviewer supplied a distinct translated Fourier-kernel calculation.
Each reconstruction/control freeze preceded new author-evidence access.
The targets and upstream source statements were shared; this is not blinded
discovery. Root supplied mechanisms and is a contributor.

The two complete author helpers remain the finite primaries. E emits five
calculated records; PC emits six controls and a seventh scope summary. No
finite matrix or finite Schur sum establishes analytic infinite-volume limits.
Author reproduction, independent calculation and proof inspection are distinct.
''',
'OPPORTUNITY_QUEUE.md':'''# Next science decisions

Complete and independently check the proposed rich detector-family resolution
of the selected scattering projection. Determine the compatibility of ND with
the exact microscopic current/index and common-centre assumptions before
trying to prove ND generically. Physical realization and all needed channels
remain separate. The current theorem closes fixed-arrangement PC only.
''',
'NO_GO_LEDGER.md':'''# Failed steps retained at their actual scope

Vacuum-vector momentum support does not imply full operator support. A gap
does not alone give the vacuum remainder for a chosen annihilator tuple.
Pointwise pair separation cannot be summed over unrestricted spectator
coordinates. Creation convergence does not imply strong adjoint convergence.
Moving-time compactness and a bare forward 1/t estimate do not prove PC.
Deleting the source Fourier filter or convex containment loses the demonstrated
kernel estimate. An arbitrary joint time/resolvent limit can be wrong.

These are scoped proof failures or algebraic counterexamples. The product
qubit example tests a missing vacuum-remainder hypothesis, not the full N1
microscopic setting. No general completeness impossibility is asserted here.
''',
'LITERATURE_BRIDGES.md':'''# Primary theorem and comparator scope

BDN arXiv:1412.2970v2 supplies the transfer, almost-locality, finite-energy
and compact-packet machinery under explicitly matched hypotheses. Dybalski
arXiv:1608.08750v1 supplies the fixed-time compactness/reversed-integral
mechanism. The new direct two-time kernel proof rederives the required bound.
The original Dybalski p4 empty-set condition and p12 third-derivative difference
are disclosed; neither erroneous clause is imported. The latter derivative
requires a sum. The cubic and periodic sine controls distinguish the typo.

Exact primary PDFs, page reads and URLs are bound in EVIDENCE_MAP.json and
the preserved reading ledgers. Root read all13 Dybalski extracted pages and
viewed originalp12; root's earlier necessary BDN proof reads are reused.
Separate review coverage is recorded at its actual scope. DG1308.5187v1,
Kruse CMP405:236 and Graf-Schenker1997 are route comparators, with their
different hypotheses and explicit reading limits. Root does not newly certify
their complete proofs. No unread1986 ideal-detector result supplies a premise.

Full third-party PDFs, images and page extractions remain external. Own
arguments, computational evidence, source identity ledgers and review reports
are preserved losslessly in this publication packet.
''',
'ARTIFACT_PLAN.md':'''# Regular PR extension

Extend regular PR9486 with the full E reduction and PC convergence notes,
their finite primaries and canonical caches, exact source maps and this
milestone snapshot. Keep the existing compact-scattering and Fock notes,
controls and packets unchanged. No draft, duplicate PR, merge, main push,
audit verdict, axiom change or editable-prompt change.
''',
'TRACE_GATE.md':'''# Direct detector-convergence obligation

```yaml
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Prove the norm-Cauchy condition (PC) for the direct compact-chart creator class."
source_of_blocker_text: source_derivation
source_location: "SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md, c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2, section3."
next_trace_action: "Resolve selected detector-family coverage and the separate ND/physical-model obligations."
```

E states the conditional terminal criterion; PC proves the preceding
convergence obligation for its stated arrangements. Neither establishes
surjectivity of the wave operator or the full-algebra shift identity.
''',
'CLAIM_STATUS_CERTIFICATE.md':'''# Conditional source-checked status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
conditional_surface_status: "Supplied direct compact-creator class and explicitly stated detector/vacuum conditions."
independent_review_status: "Complete separate E1-E18 and C1-C28 source reconstructions, no required mathematical correction."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

Original derivations are authorized; their premises and proof limits remain
explicit. Source checks do not apply an audit verdict or grant formal retained
status. No Lean proof-kernel verification or physical realization is claimed.
''',
'REVIEW_HISTORY.md':'''# Separate complete source reconstructions

E sourcec4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2;
review8c9f7bb60724982ce7580a8b5688d8b61572ea008d92305f057d3f9b7a4e735d;
receipt7567a560ce881d0a429c70d7479d3b92a0d89dfd0e641d9397163c5c12fdaa52.
The337-line pre-control reconstruction was frozen00:45:02UTC. No required
correction E1-E18. Root read the complete source, reconstruction, both helpers,
all output and operational failures;230author95review bindings matched.

PC sourcebed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64;
review2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0;
receipte9fb01e5d88618f1905a7426d07991e0a96e88cdd32a8d996b4caa92bd39db5d.
Its reconstruction/control freeze4d75d0893cc6fdddb207dd31ddd137359874183b2f8b8b8878382c21adaa8702
is01:21:51UTC, before author evidence. No required correction C1-C28.
Root read the complete source/reconstruction, independent helper and all five
outputs, complete author reproduction and every six mutation traceback.
All63author90review38freeze bindings matched. Full root coverage records
are preserved. Source identity counts are bookkeeping, not proof quality.

Publication changes metadata, recovery links and review-state wording, and
makes the linear span of smooth products explicit in both density passages.
No equation, estimate or scientific premise changes. Root is a contributor,
not another independent reviewer. Each original frozen source remains intact.
''',
'HANDOFF.md':'''# Detector milestone recovery snapshot

Extend regular PR9486 fromc3f84746b1991e0a15c6da79d049b89d9469f727.
The new complete notes establish E's conditional source/exhaustion reduction
and PC's direct fixed-arrangement detector convergence. Positive detector
limits have scattering range. Their common kernel is not proved trivial.
No full-GNS exhaustion, all channels, physical realization, boost covariance,
full-algebra shift identity or retained status follows.

PUBLICATION_EDITS.json and reconstruct.py recover all four complete artifacts.
EVIDENCE_MAP.json separates lossless own evidence from externally retained
third-party papers/images/texts. Every failed acquisition, control and recovery
step remains in the source packet at its recorded scope. DELIVERY_CHECKS.md
records publication execution and remaining independent audit gates.

The sole live campaign checkpoint is toe-dynamics-bridge-20261009 in the
transport worktree. Fixed deadline2026-10-12 16:00:52 UTC. No new research
after that time; checkpoint/report/disable heartbeat. Continue useful work
before it. No science merge, main push, audit verdict, axiom/prompt edit,
other-chat message or deadline extension.
''',
'PR_BACKLOG.md':'''# Coherent milestone in regular PR9486

Publish E and PC together after canonical controls, actual primary defects,
source reconstruction, citation acknowledgment and scoped compatibility.
Keep the existing SC/Fock evidence unchanged. The projection and index-leakage
derivations are separate new work and require their own source checks.
'''
}
for name,text in texts.items():(P/name).write_text(text)
paths=[S/n for n in ['SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md','SCATTERING_EXHAUSTION_REVIEW.md',
 'COMPACT_DETECTOR_CONVERGENCE_PROBE.md','COMPACT_DETECTOR_CONVERGENCE_REVIEW.md',
 'EX_root_author_coverage.json','EX_root_review_coverage.json','PC_root_author_coverage.json','PC_root_review_coverage.json',
 'root_verify_L_PC_reviews.py']]
for folder in ['scattering_exhaustion_next','scattering_exhaustion_review','compact_detector_convergence','compact_detector_review','root_L_PC_identity_failure_1']:
    paths.extend(p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
rows=[];refs=[]
for src in sorted(set(paths)):
    b=src.read_bytes();rel=str(src.relative_to(S));row=dict(original=str(src),bytes=len(b),sha256=sha(b))
    is_primary=src.suffix.lower() in ['.pdf','.png','.jpg'] or any(x.endswith(('_pages','_images')) for x in src.parts) or src.name.endswith(('_fulltext.txt','_reextracted.txt'))
    if is_primary:
        lower=rel.lower()
        if 'gerard' in lower:url='https://arxiv.org/abs/1308.5187v1'
        elif 'dybalski' in lower:url='https://arxiv.org/abs/1608.08750v1'
        elif 'bdn' in lower:url='https://arxiv.org/abs/1412.2970v2'
        elif 'kruse' in lower:url='https://doi.org/10.1007/s00220-024-05091-7'
        elif 'graf' in lower:url='https://www.numdam.org/item/AIHPA_1997__67_1_91_0.pdf'
        else:raise AssertionError(('Unidentified external primary',rel))
        refs.append(dict(**row,primary_url=url,recovery='Exact third-party source remains external; not redistributed.'))
    else:
        dst=P/'evidence'/(rel+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
        assert not dst.exists();dst.write_bytes(gzip.compress(b,mtime=0));rows.append(dict(**row,preserved=str(dst.relative_to(P))))
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Lossless own/repository evidence and exact external primary identities.',files=rows,external_reference_sources=refs),indent=2)+'\n')
recon=(W/'.claude/science/physics-loops/toe-compact-patch-fock-20261012/reconstruct.py').read_text()
recon=recon.replace('Complete Fock note and primary reconstruct exactly from frozen sources and explicit edits','Both complete E/PC notes and both entire primaries reconstruct exactly from frozen sources and explicit edits')
(P/'reconstruct.py').write_text(recon)
print(json.dumps(dict(snapshot_documents=len(texts),preserved_evidence_files=len(rows),external_primary_bindings=len(refs))))
