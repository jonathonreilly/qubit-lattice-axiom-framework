"""Root evidence binding after full argument/control reading; not a proof gate."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()

L = S / 'actual_corrector_review'
lr = json.loads((L / 'receipt.json').read_text())
assert sha((L / 'receipt.json').read_bytes()) == '61845782fd71dd0bda01abaa6eab7fb83ea96044b62949a79931a4afc90b294e'
start = time.monotonic()
p = subprocess.run([sys.executable, str(L / 'verify_review_receipt.py')], capture_output=True, timeout=60)
(S / 'L_root_receipt_verify.stdout').write_bytes(p.stdout)
(S / 'L_root_receipt_verify.stderr').write_bytes(p.stderr)
assert p.returncode == 0 and p.stderr == b''
for row in json.loads((L / 'reproductions/manifest.json').read_text()):
    name = row['name']
    old = S / 'actual_corrector_small_time_lower'
    old = old if name == 'baseline' else old / 'mutations' / name
    stem = 'baseline.' if name == 'baseline' else ''
    observed = L / 'reproductions' / name
    assert (observed / 'stdout.log').read_bytes() == (old / (stem + 'stdout.log')).read_bytes()
    err = (observed / 'stderr.log').read_text()
    original = (old / (stem + 'stderr.log')).read_text()
    assert err.replace(str(L / 'author_evidence'), str(S / 'actual_corrector_small_time_lower')) == original
coverage = dict(utc=datetime.now(timezone.utc).isoformat(), review_accepted=True,
    target_sha256=lr['target']['sha256'], report_sha256=lr['report']['sha256'],
    receipt_sha256=sha((L / 'receipt.json').read_bytes()), review_bindings=len(lr['files']),
    source_pairs=len(json.loads((L / 'source_manifest.json').read_text())),
    pre_author_bindings=len(json.loads((L / 'PRE_AUTHOR_FREEZE.json').read_text())['bindings']),
    reproduction_cases=8, receipt_execution_seconds=time.monotonic()-start,
    read_scope=['Complete 406-line author argument and author coverage already recorded in L_root_author_coverage.json',
                'Complete final review, 287-line reconstruction, independent exact rational code and all output',
                'Author evidence assessment, exact verifier logic and full first failed identity diagnosis/traceback',
                'All eight reproduced outputs bound byte-for-byte to the previously fully read originals, traceback path only normalized'],
    limits=['Root is coauthor, not independent reviewer', 'No Lean, continuum numerical inference, physical realization or retained verdict'])
(S / 'L_root_review_coverage.json').write_text(json.dumps(coverage, indent=2) + '\n')

P = S / 'compact_detector_review'
pr = json.loads((P / 'receipt.json').read_text())
count = 0
for kind in ['inputs', 'outputs']:
    for row in pr[kind]:
        b = (S / row['path']).read_bytes()
        h = sha(b)
        assert len(b) == row['bytes']
        if kind == 'inputs':
            assert h == row['frozen_sha256'] == row['current_sha256'] and row['match']
        else:
            assert h == row['sha256']
        count += 1
freeze = json.loads((P / 'precontrol_freeze.json').read_text())
for row in freeze['records']:
    b = (S / row['path']).read_bytes()
    assert len(b) == row['bytes'] and sha(b) == row['sha256']
base = (S / 'compact_detector_convergence/check_detector_algebra.py').read_text()
module = ast.parse((P / 'mutate_author_controls.py').read_text())
spec = next(ast.literal_eval(n.value) for n in module.body if isinstance(n, ast.Assign) and any(isinstance(x, ast.Name) and x.id == 'mutations' for x in n.targets))
baseline = (P / 'author_reproduction.stdout').read_bytes()
assert (P / 'author_reproduction.stderr').read_bytes() == b''
for name, before, after, assertion in spec:
    assert base.count(before) == 1
    assert (P / 'mutations' / (name + '.py')).read_text() == base.replace(before, after, 1)
    out = (P / 'mutations' / (name + '.stdout')).read_bytes()
    assert baseline.startswith(out)
    err = (P / 'mutations' / (name + '.stderr')).read_text()
    assert assertion in err and 'AssertionError' in err
for prefix in ['independent_control', 'author_reproduction', 'primary_page4', 'primary_page12']:
    assert (P / (prefix + '.stderr')).read_bytes() == b''
pc = dict(utc=datetime.now(timezone.utc).isoformat(), review_accepted=True,
    target_sha256=pr['target_sha256'], report_sha256=pr['review_sha256'],
    receipt_sha256=sha((P / 'receipt.json').read_bytes()), review_bindings=count,
    pre_author_bindings=len(freeze['records']), actual_mutations=len(spec),
    read_scope=['Complete C1-C28 author argument and author coverage previously recorded',
                'Complete final review, independent reconstruction, control assessment, Fourier helper and all five output records',
                'Complete author reproduction, all six literal mutation changes and all six full tracebacks',
                'Root primary reads as previously recorded: Dybalski all13 extracted pages and original page12 image; BDN necessary proof scope'],
    publication_clarification='Use linear span of smooth products for density; no new premise or conclusion.',
    limits=['Root is coauthor, not independent reviewer', 'Finite Schur sums have no tail certificate',
            'No ND, EX, physical realization, Lean or retained verdict', 'Root did not independently render the reviewer page4 image'])
(S / 'PC_root_review_coverage.json').write_text(json.dumps(pc, indent=2) + '\n')
print(json.dumps({'L':coverage, 'PC':pc}, indent=2))
