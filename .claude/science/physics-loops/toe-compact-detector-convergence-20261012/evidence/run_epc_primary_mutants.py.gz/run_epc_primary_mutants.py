"""Actual complete-primary defects, with original finite outputs kept in full."""
from pathlib import Path
import ast, hashlib, json, subprocess, sys, time

S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
O=S/'epc_primary_mutations';O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
ep='scripts/compact_detector_exhaustion_reduction_2026_10_12.py'
cp='scripts/compact_detector_convergence_2026_10_12.py'
spec=[
 (ep,'E_word_commutator_sign','addword(rhs, a[:j] + [f"L{i}", a[j]] + tail, -1)','addword(rhs, a[:j] + [f"L{i}", a[j]] + tail, 1)','assert +lhs == +rhs and -lhs == -rhs'),
 (ep,'E_dispersion_sign','L = [s.I * comm(H, ops[j]) + s.I * sigma_op(j) for j in range(N)]','L = [s.I * comm(H, ops[j]) - s.I * sigma_op(j) for j in range(N)]','assert all(vac.H * a == s.zeros(1, dim) for a in L)'),
 (ep,'E_time_derivative_sign','df = -s.I * f * H','df = s.I * f * H','assert df + s.I * sigma_f == r'),
 (ep,'E_missing_collision_source','for j in range(i):\n            out += (','for j in range(max(0, i - 1)):\n            out += (','assert df + s.I * sigma_f == r'),
 (ep,'E_resolvent_regularizer','value = eta * (Kt + eta*s.eye(2)).inv() * v','value = eta * Kt.inv() * v','assert value == s.Matrix([0, s.Rational(1, 2)])')]
module=ast.parse((S/'compact_detector_review/mutate_author_controls.py').read_text())
pc=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='mutations' for x in n.targets))
spec.extend((cp,'PC_'+name,a,b,assertion) for name,a,b,assertion in pc)
runs=[]
for primary,name,before,after,expected in spec:
    source=(W/primary).read_text();assert source.count(before)==1,(name,source.count(before))
    variant=source.replace(before,after,1);path=O/(name+'.py');path.write_text(variant)
    command=[sys.executable,str(path)];start=time.monotonic()
    r=subprocess.run(command,capture_output=True,timeout=60,cwd=W)
    (O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
    baseline=(S/('scattering_exhaustion_next/reduction_algebra.stdout.jsonl' if primary==ep else 'compact_detector_convergence/detector_algebra.stdout')).read_bytes()
    row=dict(name=name,primary_path=primary,primary_sha256=sha(source.encode()),before=before,after=after,
             source_sha256=sha(variant.encode()),command=command,timeout_seconds=60,elapsed_seconds=time.monotonic()-start,
             exit_code=r.returncode,timed_out=False,expected_assertion=expected,
             intended_failure=r.returncode==1 and expected in r.stderr.decode() and 'AssertionError' in r.stderr.decode(),
             stdout_baseline_prefix=baseline.startswith(r.stdout),stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr))
    runs.append(row);(O/'manifest.json').write_text(json.dumps(dict(runs=runs),indent=2)+'\n')
    print(json.dumps({k:row[k] for k in ['name','exit_code','intended_failure','stdout_baseline_prefix','elapsed_seconds']}),flush=True)
    assert row['intended_failure'] and row['stdout_baseline_prefix']
assert len(runs)==11
