# Source acquisition and reading limits

The first acquisition command downloaded Dybalski, Dybalski–Gerard and Graf–Schenker PDFs successfully, then failed with `FileNotFoundError: [Errno 2] No such file or directory: 'pdftotext'`. PDF bytes were preserved. Extraction was completed with installed pypdf 6.11.0. Graf–Schenker's scanned equations are poorly represented in extracted text, so the load-bearing theorem/hypothesis pages were rendered and inspected.

A first local rendering attempt via Swift/PDFKit returned exit 69 because the machine's Xcode license had not been accepted. Full commands, stdout and stderr are preserved in render_selected_output.json. No license was accepted. The installed bundled pypdfium2 runtime rendered the required pages successfully; render_pdfium_output.json records those outputs. Generated but unread extra images do not count as reading coverage.

Kruse's published PDF was obtained from the German National Library. Layout extraction contains oversized whitespace and font glyph names such as /Delta1; raw output is preserved. Separate whitespace-normalized page copies were read. Exact statements/symbols were also checked against the publisher's primary HTML, especially Theorems 1.1/3.4 and Corollary 1.2. No claim is based on a truncated tool result: the overlong Kruse read was repeated in full using the normalized pages.

Dybalski v1 p.4's empty-set pseudo-relativistic condition is genuinely printed in the PDF, as shown by the preserved image. BDN Definition 4.1(3) gives the usual vacuum-only condition. The note imports neither an impossible premise nor a silently corrected full detector theorem.

The 1986 Buchholz ideal-detector chapter was discovered through Kruse and searched, but no original readable copy was obtained. It is excluded from the proof/import set. Kruse's full Mourre proof and Graf–Schenker's full completeness proof were not independently reverified; their hypotheses and scope serve as route comparisons. Complete PDFs remain available for a later bounded attack.
