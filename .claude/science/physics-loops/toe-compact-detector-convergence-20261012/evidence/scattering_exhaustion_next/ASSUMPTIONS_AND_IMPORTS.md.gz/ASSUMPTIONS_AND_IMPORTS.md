# Assumptions and imports

No physical premise, axiom or registered primitive is adopted. This is a bounded conditional mathematical probe within the ongoing physics-loop campaign. The applicable current workflow/instructions are reused by their checked source identities; the parent's external scope excludes repository, PR, audit, unrelated lane and subdelegation work.

| Item | Class | Role/status |
|---|---|---|
| N1 H-loc/H-int/H-cov | Supplied physical conditions | Actual microscopic H and current flows, integrated closure and geometric covariance. The report does not derive their existence from Lie brackets. |
| Isolated positive Casimir components and selected finite-order centres | Supplied compact-construction conditions | Gives exact one-particle vacuum graphs in local geometric charts. Does not supply global geometric shell isolation. |
| ker H = C Omega, spec H outside vacuum >= gamma > 0 | Supplied N1 H-gap, additional relative to compact S1–S4 | Used in the vacuum remainder and EX. State-level translation invariance uniqueness alone is insufficient. |
| Geometric translation sign and K_current=P/beta | Admitted convention | Matches frozen compact note; distinguished from N1's boost K. |
| BDN 3.6, 3.9, 3.10, 3.11 | Literature theorem | Transfer, almost locality under Schwartz smearing, equal-time commutators and finite-energy annihilation norm bound. Exact hypotheses checked; no geometric shell assumption for 3.11. |
| Compact-packet Cook construction | Independently checked conditional dependency | Frozen source d1d8...02a4a and its scope repair; existence and H covariance only. |
| Fock isometry | Provisional dependency, not used by new reduction | Frozen author source 9bc3...69404; fresh review was pending at task start. No review verdict inferred here. |
| Energy-window source reduction and PC => detector convergence/range | New bounded author derivation | Main note E3–E16; requires independent reconstruction before substantial reuse. |
| PC, norm-Cauchy lattice amplitude | Open estimate | The leading 1/t detector derivative is not controlled by ordinary Cook estimates. |
| ND / ordered resolvent criterion | Open coverage estimate | Positivity proves the exact equivalence ND <=> E18 and implication to EX under PC, not the vanishing of E18. |
| EC, microscopic energy capture | Proposed stronger sufficient condition | Neither supplied nor proved by N1's bounded local density. Infinite channels may preclude a uniform finite detector comparison. |
| Dybalski 2016/2018 and DG 2013/2014 detector mechanisms | Literature theorem / route comparator | Reconstructed preliminary mechanism; complete theorems not imported into N1's folded setting. |
| Kruse 2024 single-detector/Mourre criterion | Literature theorem / background context | Precise spectral and remainder conditions not established here. Energy-density bridge is explicitly a proposal in the source. |
| Graf–Schenker 1997 two-magnon completeness | Literature theorem / non-derivation analogy | Fixed two-particle channel result, not a full-GNS theorem. |
| Buchholz 1986 ideal detector | Unread discovery lead | No theorem or assumption imported; cited by Kruse but original not obtained. |

Neither absence of proof nor abstract Hilbert-space spectator constructions is presented as a no-go for local UHF models. The actual on-site UHF counterexample only rejects omission of the narrow residual-energy condition.
