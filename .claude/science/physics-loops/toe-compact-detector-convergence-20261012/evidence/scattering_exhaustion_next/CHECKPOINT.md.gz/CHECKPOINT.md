# Scattering exhaustion next-obligation checkpoint

Completed author probe at 2026-10-12T00:29:28.801411+00:00; fixed campaign deadline 2026-10-12 16:00:52 UTC. Deliverable: ../SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md. Source hashes and final artifact bindings are in SOURCE_IDENTITIES.json and receipt.json.

N1/B1/M1 match their frozen hashes at exact candidate 0cc560e3935fa1ad7623592bf9974680c922d52d. The shared checkout was last observed at 773321aa8fdfccc05248682dfc96bf94215034a2 with clean working tree. All 173 compact/Fock predecessor receipt bindings and eight source hashes matched. No frozen source or Git changes were made.

Completed conditional author derivation: full geometric operator-momentum trimming; a narrow residual-energy condition plus the unique gap gives the vacuum remainder; detector products reduce to bounded positive scalar-amplitude compressions. The amplitude satisfies an inhomogeneous lattice many-particle equation whose commutator source decreases faster than any inverse power off collision planes. Under the explicit norm-Cauchy estimate PC, these compressions have scattering-range strong limits. Positivity then makes no-common-kernel ND equivalent to the ordered resolvent test E18; PC plus ND on a countable energy partition implies EX.

Unresolved: PC, ND and the proposed stronger energy-capture comparison EC. The leading detector transport term is only O(1/t), so ordinary compact-packet Cook bounds do not prove PC. Bounded microscopic energy density has not been compared with particle-detector forms. No full-GNS exhaustion, N1 realizability, general no-go or audit verdict is claimed. The provisional Fock isometry conclusion is not used.

Literature: BDN supplies the finite-energy annihilation bound. Dybalski supplies the closest lattice compactness mechanism; its full global geometric-shell theorem is not silently imported. DG supplies a propagation alternative. Kruse 2024 sharpens the low-energy/joint-absolute-continuity route and explicitly leaves the energy-density bridge proposed. Graf–Schenker supplies restricted two-magnon completeness, with no fixed-particle representation assumed for N1. Exact reading and acquisition limits are preserved.

One distinct author control ran once, timeout 60 s, exit 0: free-word identity n1–8; 84 exact finite XY source equations, 40 nonzero sources and 80 rejected wrong-sign cases; a true local UHF counterexample only to dropping the residual-energy condition; ordered-resolvent and truncation checks. No author control was rerun and none is independent review.

Next decision for the parent: commission independent reconstruction of this bounded source reduction before substantial reuse; if accepted, attack PC on one mixed-chart arrangement using Dybalski's compactness proof, then the separate detector coverage/energy-capture estimate. Keep all-source exhaustion separate from scattering existence and Fock isometry.

Authority unchanged: no repository, prompt, PR, audit, merge, axiom, other-chat or subdelegation action; inherited model and reasoning unchanged. This checkpoint is final for the bounded probe; no new research has begun after completion.
