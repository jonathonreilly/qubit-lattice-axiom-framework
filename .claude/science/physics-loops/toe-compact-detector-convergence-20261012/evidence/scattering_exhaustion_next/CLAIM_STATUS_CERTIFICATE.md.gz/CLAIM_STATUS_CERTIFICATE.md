# Claim-status certificate

1. **Conditional author theorem, newly proved:** from direct compact creators, a unique gapped vacuum and geometric lattice translations, geometric operator-momentum trimming and an energy-window detector tuple give a vacuum remainder, positive bounded detector compression, and a scalar n-body equation with a rapidly decreasing source away from collision planes (E3–E14).
2. **Conditional author reduction, newly proved:** the explicit norm-Cauchy estimate PC implies strong detector limits with scattering range; their common-kernel condition ND is equivalent to the ordered resolvent test E18. PC plus ND on a countable energy partition implies EX.
3. **Open, not adopted:** PC; ND; EC; all-channel coverage; microscopic realizability of the supplied N1 setting. No numerical check establishes them.
4. **Reused independent check:** frozen compact core S1–S4 and the exact EX scope repair. Fock isometry is not a load-bearing input to this note; its source remains provisional in this assessment regardless of its separately active review.
5. **Preserved failed inference:** a rapid off-collision source is insufficient for the detector Cook argument because the transport derivative has a 1/t leading term. A bounded local energy density has not been identified with canonical particle detectors.
6. **Preserved counterexample scope:** a product-vacuum on-site UHF model rejects omission of E6; it does not satisfy exact N1 Poincare closure and is not an N1 countermodel.
7. **Author control only:** one new 60-second-timeout script, exit 0, complete stdout/stderr retained; no compact/Fock control rerun. This is not independent review or a retained-science/audit verdict.
8. **Authority:** no repository, frozen source, editable prompt, PR, audit, merge or axiom changes; no other-chat message or subdelegation; inherited model/effort unchanged. Hard deadline remains 2026-10-12 16:00:52 UTC.
