# Literature bridges

| Primary source | Exact item | Role | Import class | Affected claim | Closure |
|---|---|---|---|---|---|
| BDN, arXiv:1412.2970v2 | Proposition 3.6, Lemma 3.9, Theorems 3.10–3.11; Definition 4.1(3) | Mathematical transfer/localization/bounded-energy machinery | literature theorem | E3–E5, E8 and source estimates; source typo comparison | Supplies these implications under checked hypotheses, no EX |
| Dybalski, arXiv:1608.08750v1 | Theorem 4.2, Definition 4.1, Appendices A–B | Closest lattice compactness route | literature theorem | PC strategy and detector ranges | No full-GNS closure; theorem's global geometric shell conditions not silently imported |
| Dybalski–Gérard, arXiv:1308.5187v1 | Theorems 2.8–2.9, 4.1, 5.4; Lemma 4.2; Proposition 5.3 | Scalar source equation and propagation alternative | literature theorem | E11–E16 adapted directly; PC route | No automatic transfer of continuum geometric hypotheses |
| Kruse, CMP 405:236 (2024), DOI 10.1007/s00220-024-05091-7 | Theorems 1.1/3.4, Corollary 1.2; sections 2.1–2.2, 5.1/5.3/5.4 | Updated single-detector and energy-capture assessment | literature theorem / background context | Route 2, EC proposal | No EX; joint absolute continuity and canonical-detector approximation remain obligations |
| Graf–Schenker, Ann. IHP 67 (1997), 91–107 | Theorems 1.1/2.1, assumptions (i)–(iii), pp.93–95 | Fixed-particle comparison | literature theorem / non-derivation analogy | Route 4 | No N1 coordinate representation or full-GNS coverage supplied |

BDN is used as an established mathematical bound; it does not provide derivation closure for full-GNS exhaustion.

Dybalski is used as a lattice detector proof mechanism; it does not provide derivation closure for N1 or EX.

Dybalski–Gérard is used as the primary source of the inhomogeneous scattering mechanism; it does not provide derivation closure for the current-flow lattice setting.

Kruse is used to identify a concrete newer coverage route and its stated limits; it does not provide derivation closure from local energy density to EX.

Graf–Schenker is used as a genuine restricted lattice completeness comparison; it does not provide derivation closure for the number-nonconserving GNS problem.

All source PDF hashes are recorded in the download receipts and final artifact receipt. No observational input or fitted physical value is used.
