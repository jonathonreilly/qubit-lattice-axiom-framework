# Bounded primary-literature search record

Searches in this task covered lattice scattering/asymptotic completeness, Dybalski particle detectors and almost locality, fixed-particle lattice/magnon completeness, and newer 2024–2026 detector/completeness leads. This is a topic record, not a verbatim query transcript or exhaustive survey.

Selected primary sources are fixed by PDF hashes in SOURCE_IDENTITIES.json. The closest lattice theorem is Dybalski 1608.08750v1. Its scalar propagation alternative was traced to Dybalski–Gérard 1308.5187v1. The fixed-particle contrast is Graf–Schenker 1997. The newer relevant lead is Kruse, CMP 405:236 (2024), DOI 10.1007/s00220-024-05091-7, published PDF obtained from the German National Library and cross-checked against the publisher HTML. ArXiv metadata identifies 2311.18680v3 (16 September 2024); the 36-page published PDF, not an unexamined arXiv version, is the bound source.

Kruse's energy-density paragraph is a proposed bridge and is kept at that status. Its cited Buchholz 1986 ideal-detector chapter was searched but not obtained/read; no result from that original is imported. Generated PDF pages that were not viewed are explicitly excluded from reading coverage.

Every literature bridge is mathematical machinery or a route comparison. No observational value, phenomenological fit, physical premise adoption or claim of a general no-go results from these searches.
