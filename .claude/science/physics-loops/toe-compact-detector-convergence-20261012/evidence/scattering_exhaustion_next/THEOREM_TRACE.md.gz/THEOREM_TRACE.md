# Theorem trace and failed routes

| Main item | Required input | Argument/evidence | Limit |
|---|---|---|---|
| EX <=> P_sc=1 | E1 and cyclicity; closed scattering span contains vacuum | Strong energy cutoffs and density | Does not prove EX |
| E3 full geometric transfer cut | Direct almost-local creators; commuting lattice translations | Schwartz coefficient sum, BDN 3.6/3.10 | Vacuum graph alone was not used as operator support |
| E4–E5 finite-energy bounds | Compact negative temporal transfer; positive H; AL | BDN 3.11, iterated lowering | No Fock induction assumed |
| E6–E7 vacuum remainder | Full gap and interval difference | Transfer addition and unique zero eigenspace | On-site UHF negative control if interval condition removed |
| E8–E10 positive compression | Separated compact detector positions; AL | O(t^(nd)) tuples times arbitrary inverse-power commutator decay | Finite n/charts; no uniform small-patch claim |
| E11–E14 scalar evolution | Exact vacuum graph, smooth bounded dispersion extension, AL time derivative | Defect D_i=delta A_i+i A_i^Sigma has zero vacuum row; commute to left | 84 exact XY-source identities and free-word checks corroborate algebra only |
| E15–E16 failed direct Cook route | Previous equation and compact position cutoff | Kernel Taylor expansion gives nonintegrable 1/t term | Does not establish PC |
| PC => detector range | Uniform creation map; compact Cook limits; full operator chart cutoff | Density in tensor products of L2 chart spaces, S_t strong convergence | No Fock isometry required |
| ND <=> E18 | PC and positive bounded detector limits | Weighted norm sum, resolvent identity, spectral theorem | Time, truncation and eta limits ordered |
| ND on each J => EX | Ranges inside scattering subspace | Closure of range K = orthogonal complement of kernel K | No detector completeness assumed beforehand |
| EC => ND | Proposed positive detector-form energy domination | Gap excludes zero-energy nonvacuum vectors | EC remains unproved and may be unnecessarily strong |

The literature match is constructive but incomplete: the current-flow momentum is not geometric position; global Bloch isolation is not available; the full mass spectral measure can include unselected/singular components. Neither an AQFT generalized-free-field example nor an abstract spectator direct sum is asserted to be a local UHF model satisfying N1.
