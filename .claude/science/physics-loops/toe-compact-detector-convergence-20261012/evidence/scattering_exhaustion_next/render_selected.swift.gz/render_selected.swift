import Foundation
import AppKit
import PDFKit
let args = CommandLine.arguments
let doc = PDFDocument(url: URL(fileURLWithPath: args[1]))!
let out = args[2]
for value in args.dropFirst(3) {
    let n = Int(value)!
    let page = doc.page(at: n - 1)!
    let img = page.thumbnail(of: CGSize(width: 1400, height: 1800), for: .mediaBox)
    let bitmap = NSBitmapImageRep(data: img.tiffRepresentation!)!
    let png = bitmap.representation(using: .png, properties: [:])!
    try png.write(to: URL(fileURLWithPath: out + "/" + String(format: "%02d", n) + ".png"))
    print("Rendered page \(n)")
}
