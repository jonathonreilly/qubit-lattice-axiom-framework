# Control assessment after the independent freeze

The complete analytic reconstruction and source-reading coverage were frozen
at 2026-10-12T00:45:02.797103+00:00, before opening the author's helper, logs,
execution metadata or receipt. The candidate's descriptions of its controls
were already visible; this shared context is explicitly recorded in the freeze.
The reviewer then wrote and ran a distinct implementation before inspecting
the author's implementation. Neither control suite proves an infinite-volume
scattering statement.

The reviewer's `independent_checks.py` ran once with a declared 60-second
timeout, exit 0, elapsed 0.1932797078 seconds, and empty stderr. It uses NumPy
2.4.4 with Python 3.13.5 and fixed seed 621847. There was no search over seeds,
parameter fitting, or selection among successful runs. Its three mathematical
checks have the following scope.

1. A finite spectral calculation checks the full operator geometric filter,
   independently comparing spatial averaging with matrix transfer selection.
   The residual is 2.6734699439e-16. Filtering only the vacuum column leaves
   forbidden transfer of norm 1.4349290181. This discriminates full transfer
   filtering from the weaker vacuum-vector statement; it is not a proof of
   infinite-lattice almost locality.
2. A 10-dimensional, seven-site cyclic algebra with distinct smooth
   dispersions checks the scalar source equation using the direct derivative
   of the entire ordered product, a separate discrete Fourier free term, and
   the proposed commutator source. All position tuples for n=1,2,3 at times
   0, 0.37, 1.15 give 1197 component equations. The largest correct residual
   norm among the nine arrays is 5.0661068848e-15. The wrong free sign fails
   in all nine arrays with residual at least 3.7227362724. Omitting the
   dispersion commutator fails in all six arrays with n>=2, at least
   5.8093221436. Omitting nonadjacent pairs fails in all three n=3 arrays,
   at least 4.6721723132. Those omissions are vacuous for the smaller n
   cases and are not counted as detected defects there. The constructed
   vacuum-row defect is exactly zero in the calculation; this is a controlled
   input, not an independently discovered physical property. The finite
   construction does not satisfy or test the full microscopic N1 premises.
3. Direct convolution kernels check the sign, operator ordering, and moving
   cutoff in E16. For two finite-band dispersions and t=16,32,64,128,256,
   the computed Schur row sums multiplied by t^2 stay below 1.492. A reversed
   velocity sign leaves t-scaled residuals between 0.8716 and 0.9741;
   omitting the moving-cutoff derivative leaves a t-scaled residual near
   0.618. These are finite kernel checks; the analytic Taylor remainder and
   Schur argument in the frozen reconstruction establish the general bound.

The author's script was then read completely before execution. It implements
free-word expansion for n=1,...,8, an exact four-site periodic XY source
identity for 84 position tuples, a residual-energy counterexample when E6 is
removed, a noncommuting order-of-limits example for E18, and 72 scalar
resolvent-tail inequalities. The free-word calculation establishes the
commutator expansion, not its physical applicability. The exact XY derivative
uses the actual finite Hamiltonian and the specified scalar dispersion; it
has 40 nonzero source cases and rejects the wrong free sign in 80 cases.
The eight zero/degenerate cases are not advertised as sign discriminators.
The separate reviewer implementation supplies additional omitted-term and
filter discriminators. Neither suite uses a fitted prefactor or a target
number inserted as the computed physical result.

The on-site lowering example correctly establishes that a gap without E6 does
not give vacuum collapse: removing energy two from a three-excitation state
leaves energy one. It does not satisfy N1's exact Poincare closure. The positive
matrix example correctly gives a residual 1/2 when eta=1/t, although the
ordered limit gives the kernel projection. The scalar tail inequalities check
the stated near-zero scaling only; the operator resolvent identity remains
the proof. These examples are deliberately elementary counterexamples to
weakened intermediate claims, not countermodels to the physical setting.

Reproduction used the exact copied author script, SHA-256
`674259f169591f92feba1bb2dceb94e8e90ec070336c856cad018ebd802e75b7`, once,
under a declared 60-second timeout. It exited 0 in 0.8899987917 seconds. All
five stdout records matched the supplied output byte for byte, and stderr
was empty. The reproduction is corroboration of the author's implementation,
not an independent derivation. Full commands, times, stdout and stderr are
in the adjacent execution records and logs.

The supplied author receipt has the expected SHA-256
`8fac2fc46322fc8a58e2a86eda22128a7e9c7a831f329c53f0775d2ea60aca3a`.
All 230 listed artifact hashes and byte lengths were checked mechanically
without mismatch. The complete metadata outside its artifact list was read;
the artifact list was parsed and validated in full rather than claimed as
manual scientific reading. Its inventory does not certify the truth or
reading coverage of every inventoried artifact. The author helper, all five
stdout records, empty stderr, execution record, assumptions, theorem trace,
claim certificate, literature bridges and reading coverage were read after
the freeze. The earlier compact review and EX repair addendum were also read
only after the independent reconstruction and checks; their verdicts are not
premises of this review.

No result from these controls proves PC, ND, EC, all-channel coverage,
microscopic N1 realization, or a no-go theorem. They support the local algebra
and expose specific incorrect shortcuts within the bounded reduction.
