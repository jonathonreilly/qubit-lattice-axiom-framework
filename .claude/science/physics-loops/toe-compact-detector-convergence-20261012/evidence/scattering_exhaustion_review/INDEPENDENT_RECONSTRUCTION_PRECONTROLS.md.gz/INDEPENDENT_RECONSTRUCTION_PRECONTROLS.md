# Independent reconstruction before author controls

Frozen review target: `SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md`, 262 lines,
SHA-256 `c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2`.
This record is completed before opening the exhaustion author's helper,
stdout, stderr, execution metadata, or receipt. Its freeze time and hash are
recorded in `precontrols_freeze.json`. It will not be rewritten after controls.

The reviewer has seen the candidate's descriptions of its free-word, four-site
XY, on-site lowering, and resolvent controls, and the descriptions of earlier
compact-creator controls in the predecessor note. The parent brief and candidate
also disclose that the predecessor received review and that Fock isometry was
under separate review. Those descriptions and labels are shared context, not
independent proof evidence. No previous review report or Fock argument has been
used to establish the claims below. The exact source reading coverage is in
`reading_coverage_precontrols.json`.

## Target, premises, and actual dependency graph

The claim under examination is a conditional implication, not existence of a
physical model satisfying it. Work in the supplied positive-energy lattice GNS
representation with geometric translations fixing the vacuum, commuting with
time translations. Assume a unique zero-energy vacuum and a gap gamma on its
orthogonal complement. For each fixed finite detector arrangement assume
bounded creators with compact strictly positive temporal transfer, almost
locality of the creators and their norm time derivatives, and exact vacuum
vectors on the specified smooth geometric-momentum graphs. Their mass/current
construction additionally requires the actual microscopic commuting flows,
isolated positive mass-Casimir components, finite-order centre selectors, and
compact charts stated in precursor S1--S4. N1's formal closure language alone
does not replace those assumptions.

The original N1 H-gap has the additional clause that the spectrum on
Omega-perp is at least m>0. That clause, with H Omega=0, really does exclude
all additional zero modes. Merely unique *translation-invariant* ground state
language would not do so. H-AC is not an input here. B1's bounded-sector
argument and M1's completeness-dependent index argument are context, not
premises for the detector reduction. The Fock proof is also not a dependency.

The directed implication is:

1. Direct creator properties and positive energy give spectral filtering,
   finite-energy annihilation bounds, and bounded scalar creation maps.
2. The gap plus the arrangement's **energy remainder restriction** give the
   vacuum factorization. Almost locality and spatial separation give norm
   detector factorization and the off-collision source estimate.
3. The compact Cook limits, uniform boundedness, and the separately assumed
   norm-Cauchy condition PC give positive detector limits with scattering range.
4. The separately assumed zero-common-kernel condition ND on every energy
   partition interval gives full exhaustion EX, equivalently P_sc=1.

No arrow from a gap, local cyclicity, isometry, or individual particle limits
to PC or ND is available from this graph. For an arbitrarily chosen detector
family, ND is a sufficient coverage condition; EX alone need not imply ND.
The equivalence actually proved in the candidate is ND iff the ordered
resolvent test E18 (assuming PC), and EX iff P_sc=1 under E1 and cyclicity.

## Reconstruction of E2--E5: signs, filtering, and a direct bound

Use T_x=exp(-i x Q) and current translations R_y=exp(-i y K), where
K=P/beta. Then V_j=R_j^* T_j=exp(i j(K-Q)). A centre character
exp(i theta j) gives Q=K-theta modulo 2 pi. On a fixed lift,
k=p+theta+2 pi n, and H on the selected vacuum graph is
Sigma(p)=sqrt(M^2+beta|p+theta+2 pi n|^2). The velocity of the spatial packets
is the derivative with respect to geometric p, not a derivative with respect
to a continuous current position. There is no extra factor beta in the time.

For c(z)=integral exp(i p z) phi(p) dp/(2 pi)^d,
sum_z c(z) tau_z(B) Omega=phi(Q) B Omega. With the same spatial Fourier
sign, the *full operator* geometric transfer is multiplied by phi.
Its support is therefore compactly inside the chart. Temporal transfer is
unchanged because the actions commute. A Schwartz-weighted sum of translates
of an almost-local operator is almost local: in a radius-r approximant keep
|z|<=r/2, approximate the original operator at r/2, and bound the discarded
sum by arbitrary powers of r. The same argument applies to each norm time
derivative. It neither asserts nor needs isolation in joint (H,Q) spectrum.

For A=B^*, temporal transfer is in [-L,-epsilon], epsilon>0. The compact
spectral region needed by BDN 3.11 can be chosen as
Sp(H,Q) intersect ([0,R] times the momentum torus); the torus is compact.
The BDN theorem's hypotheses at this step are precisely positive energy,
compact negative transfer, and almost locality, not its later shell hypotheses.

Here is a separate proof of the bound, avoiding a theorem-name-only import.
For a finite set Lambda put A_x=tau_x(A), Q_Lambda=sum A_x^* A_x, and
D_Lambda=max_x sum_y ||[A_x,A_y^*]||. Let V_n be the common kernel of all
ordered length-n products of the A_x. It is enough to prove

    <psi,Q_Lambda psi> <= (n-1) D_Lambda ||psi||^2, psi in V_n.

For n=1 the assertion is immediate. Each A_y maps V_n into V_(n-1).
Moving A_x through A_y^* once gives the exact quadratic identity

    ||Q_Lambda psi||^2
      = sum_(x,y) <A_y A_x psi, A_x A_y psi>
        + sum_(x,y) <A_x psi, [A_x,A_y^*] A_y psi>.

By Cauchy--Schwarz and exchanging x,y in one half, the first sum is at most
sum_(x,y)||A_x A_y psi||^2. Induction bounds this by
(n-2)D_Lambda <psi,Q_Lambda psi>. The operator-valued commutator matrix is
self-adjoint, and its row/column norm sums are at most D_Lambda; the Schur
bound makes its quadratic form at most D_Lambda <psi,Q_Lambda psi>.
Consequently ||Q_Lambda psi||^2 <= (n-1)D_Lambda <psi,Q_Lambda psi>.
A final Cauchy--Schwarz inequality proves the desired quadratic bound.

Choose n epsilon>R. Transfer addition and H>=0 imply P_[0,R]H is contained
in V_n. Almost locality gives
D_Lambda <= sum_z ||[A,tau_z(A^*)]|| < infinity, uniformly in Lambda.
The monotone finite spatial sums therefore give E4. This argument does not
assume that Q_Lambda preserves an energy window or that distinct A_x commute.

For E5 sum x_1 first and apply E4 to A_2(x_2)...A_n(x_n)P_[0,R]psi.
This vector still lies in P_[0,R]H because each factor lowers energy.
Iterate. The result is the stated product of the individual square-root bounds.
Time translation is a common unitary conjugation, so the same constants apply.

## Reconstruction of E6--E10: remainder, ordering, and compression

Every ordered product A_1(t,x_1)...A_n(t,x_n)P_J has output energy in
J-I_1-...-I_n, by repeated spectral transfer. E6 and the one-dimensional
zero-energy eigenspace put this output in C Omega. Negative elements of that
Minkowski difference do no harm because H has no negative spectrum. The
sufficient bound placing the entire difference in (-gamma,gamma) is correct;
it is not asserted to ensure the existence or sufficiency of any detector tuple.

For compact spatial cutoffs h_i(x_i/t), there are O(t^(nd)) position tuples.
Reorder A_1^*A_1 ... A_n^*A_n into A_n^*...A_1^* A_1...A_n. Each required
swap involves two different labels. On the relevant supports their positions
are at distance at least delta t, including swaps of two adjoints. Their
equal-time commutator is the time evolution of the commutator at time zero;
its norm is O(t^-N) for every N. All other factors have fixed norm. This
proves the operator-norm estimate E8, with t^(nd-N), on P_J and indeed for
the finite spatial sums before compression. Taking N larger yields E9's
arbitrary rapid remainder. Convex-hull separation is not needed for E8.

For finitely supported f,

    J_t f = sum_x f(x) B_n(t,x_n)...B_1(t,x_1) Omega.

Its range has energy at most L=sum_i L_i (by *full operator* temporal
transfer). Pairing with an arbitrary vector may therefore insert P_[0,L].
E5 at L then gives ||J_t||<=M_L and a bounded extension to all ell^2.
The scalar row map F_t equals J_t^* on the relevant energy-restricted vector.
Thus vacuum factorization gives E9, and E10 is exactly

    Q(t)=P_J J_t h_t J_t^* P_J.

This is bounded, self-adjoint and positive because h_t>=0. Its norm is at
most M_L^2 product_i ||h_i||_infinity. Only the compressed product of the
original detectors is claimed to have this exact positivity; the unsymmetrized
finite-time product need not be positive. Finite spatial support also prevents
an unaddressed domain issue in the intermediate a_t^* h_t a_t expression.

## Reconstruction of E11--E16: scalar equation and the missing estimate

The common time evolution pulls through the entire ordered product, and its
left action fixes Omega. Hence F_t=L_a exp(-itH)psi, where
L_a=(<Omega| tensor 1)a P_[0,R] is bounded. Bounded H on this spectral
subspace makes t -> F_t continuously differentiable in ell^2, with norm of
its derivative at most R M_R ||psi||. No unbounded-generator differentiation
on an unspecified domain is needed.

The partial Fourier support of F_t in x_i is the *creator's* geometric
transfer support, not its negative. Indeed A_i=B_i^* has phase exp(+ipx_i),
and the scalar Fourier transform uses exp(-ipx_i). Thus g_i=1 on that
support is the correct multiplier.

For the convention (Sigma(D)f)(x)=sum_z kappa(z) f(x-z), the operator
A_i^Sigma=sum_z kappa_i(z)tau_(-z)(A_i) gives exactly the same scalar
convolution. The vacuum row identity is

    <Omega,delta A_i(t,x) Phi>
      = -i Sigma_i(D_x)<Omega,A_i(t,x) Phi>.

It follows from the exact graph for B_i Omega and the spectral theorem, with
the centre shift included in Sigma_i. Thus D_i=delta A_i+i A_i^Sigma has
zero vacuum row. Smoothness of the torus extension makes kappa_i Schwartz;
A_i^Sigma, delta A_i, and D_i are almost local and have the same negative
temporal-transfer bound.

Differentiate the ordered product, substitute delta A_i=D_i-i A_i^Sigma,
and commute each D_i to the far left. Its final vacuum row vanishes. The
terms left are precisely

    sum_(i>j) <Omega,A_1...A_(j-1) [A_j,D_i]
                    A_(j+1)...A_(i-1) A_(i+1)...A_n psi>.

This proves the sign and order in E11--E12. It includes both the operator
time derivative and the dispersion convolution. In particular one cannot
discard the commutator part of the dispersion contribution.

Equal-time almost locality bounds each source term by an arbitrary inverse
power of |x_i-x_j|, independently of time. The global ell^2 bound on the
*sum* R_t follows from R_t=partial_t F_t+i tildeSigma(D)F_t. There is no
need to infer it from the nonintegrable pointwise pairwise bound alone.
For compact chi(X/t) separated from every collision plane, its O(t^(nd))
support sites have |x_i-x_j|>=delta t. Taking the square root of the count
gives E14: t^(nd/2-N). It supplies no decay along a cluster collision plane.

The Heisenberg derivative in E15 follows from the product rule, since g(D)
commutes with tildeSigma(D). For a scalar convolution term,

    i[Sigma(D),h(X/t)]f(x)
      = i sum_z kappa(z)[h((x-z)/t)-h(x/t)]f(x-z).

Taylor's formula gives the leading multiplier
t^-1 (nabla h)(X/t) dot v(D), because v has convolution coefficients
-i z kappa(z). The derivative of h(X/t) contributes
-t^-1 (nabla h)(X/t) dot X/t. The second-order remainder is bounded in
operator norm by a constant times t^-2 sum_z |z|^2|kappa(z)|, by the
Schur test. This proves E16 with multiplication on the stated left side.
For a sum of dispersions apply the argument coordinatewise. Uniform
boundedness of F_t yields only the nonintegrable O(t^-1) term. The note
correctly does not infer PC from E14 or the compact-packet Cook estimate.

## Reconstruction of PC -> strong detector limits with scattering range

The full operator momentum filters imply J_t=J_t g(D). Therefore
S_t=J_t exp(-it tildeSigma(D)) is uniformly bounded and S_t=S_t g(D).
For a product of smooth Fourier functions compactly supported in the chosen
velocity-separated charts, S_t is a reversed-order compact-creator packet
product. The predecessor's direct Cook proof applies: each differentiated
packet kills Omega; commuting it through the other factors gives arbitrary
inverse powers of the separation time, absorbing the finite polynomial packet
norms. This gives strong limits on a dense product class. Outside the tensor
chart subspace S_t is zero; uniform boundedness extends convergence to all
ell^2. No Fock norm identity is used. If a chart is originally too large,
the argument is applied to the slightly enlarged support neighbourhoods with
separated velocity closures stipulated in the candidate, not arbitrary
unseparated supports elsewhere in an original chart.

The scattering span reduces H. Explicitly, applying exp(isH) to a packet
product at time t gives the product at time t+s with Fourier amplitude
exp(is Sigma_i) fhat_i. Its support is unchanged. Passing to the limit works
for every real s, giving both invariance directions and commutation of P_sc
with every spectral projection P_J.

Assuming PC, u_t converges to u_+ and
Q(t)psi=P_J S_t u_t(psi) -> P_J S u_+(psi). Uniform boundedness of S_t
justifies the product limit even though both factors vary with t. Its range
lies in the closed intersection P_J H_sc. On P_J-perp the approximants
vanish, so this is strong convergence on the whole Hilbert space. Positivity
and the operator bound pass to the limit. A dense-core formulation of PC is
adequate because the maps u_t have a common operator bound.

## Reconstruction of E17--E18 and EX

Set w_alpha=2^-alpha/(1+B_alpha). The series sum w_alpha Q_alpha is
norm-convergent, positive, bounded by the identity on P_J H, and has norm
tail at most 2^-m. For a positive series,

    <psi,K_J psi>=sum_alpha w_alpha ||Q_alpha^(1/2)psi||^2.

All weights are strictly positive; hence its kernel is exactly the common
kernel. A bounded self-adjoint operator with range inside P_J H_sc annihilates
that space's orthogonal complement. The entire norm series has range in this
closed subspace. Therefore ND gives

    P_J H = closure Ran K_J subset P_J H_sc,

using closure Ran K=(ker K)^perp for bounded self-adjoint K.

For fixed m and eta>0, bounded strong convergence of K_(J,m)(t) implies
strong resolvent convergence. This also follows directly from the resolvent
identity: the inverse norms are at most 1/eta and the middle strong difference
acts on a fixed vector. At fixed eta, the next approximation in m satisfies

    ||eta[(K_J+eta)^-1-(K_(J,m)+eta)^-1]psi||
       <= 2^-m ||psi||/eta.

Finally the spectral theorem sends eta(K_J+eta)^-1 strongly to the kernel
projection as eta decreases to zero. The operators are contractions, so
vanishing on the dense set P_J pi(A)Omega for local A is equivalent to
vanishing on the entire spectral subspace. This proves precisely the ordered
limit in E18 and its equivalence to ND, not an interchangeable joint limit.

A countable disjoint partition of [gamma,infinity) by bounded half-open
intervals of width less than gamma/4 yields strong sum of its projections
equal to 1-|Omega><Omega|. If the conclusion holds on each interval, the
closed scattering space contains their entire sum and Omega. Equivalently,
EX on all local vectors and finite cutoffs gives P_sc=1 by strong spectral
convergence and local cyclicity. The interval width does not prove that
appropriate arrangements exist or that ND holds.

The sufficient energy comparison EC is correct if its positive form has the
stated domain on P_J H and every common undetected vector has zero form.
Then gamma||psi||^2<=<psi,Hpsi><=C_J D_J[psi]=0. The note correctly leaves
the construction, sums, domain, and comparison open. Positivity of H does
not make each vacuum-subtracted microscopic density positive.

## Primary source compatibility and limits of this reconstruction

BDN Proposition 3.6 and Lemma 3.9 match spectral transfer and almost locality;
Theorem 3.11 is applicable independently of its later shell assumptions.
Its finite-energy proof was reconstructed above. The precursor's direct Cook
proof uses only the elementary packet bounds of Proposition 4.3, not Fock
isometry. The source explicitly distinguishes the stronger Definition 4.4
operator-shell condition from exact vacuum-vector support.

Dybalski 1608.08750v1 is a route comparator. Its Theorem 4.2 additionally
specifies an isolated geometric shell, admissible transfer tuples, disjoint
geometric momentum transfers, and appropriate convex velocity support hulls.
Its proof uses compactness, re-expansion into scattering packets, both
derivative terms, and off-collision control after pseudodifferential transport.
The candidate has not claimed this theorem applies literally with mixed
dispersions or overlapping geometric supports. The printed empty-set clause
on page 4 is indeed impossible for nonempty h and a vacuum; BDN Definition
4.1(3) has {0}. The candidate discloses rather than imports that literal clause.

Dybalski--Gerard's framework is a continuum covariant local net with an
isolated hyperboloid and a higher threshold. Its Theorem 4.1/Lemma 4.2 match
the scalar reduction mechanism, but the candidate reconstructs that mechanism
from the lattice hypotheses. Prop. 5.3 and Theorem 5.4 require a phase-space
propagation estimate and a corrected symbol, beyond E14. Theorem 2.9 identifies
the span of detected ranges with the scattering space, not the full GNS space.
This review does not import that theorem or all its transitive proof lemmas.

Kruse's Theorem 3.4 explicitly imposes joint spectral absolute continuity and
the uniform one-particle spectral-remainder condition. The spin extension
requires an isolated regular pseudo-relativistic geometric shell. Sections
5.1 and 5.3 leave the canonical-detector/energy-density bridge open. The
candidate faithfully states these limitations. Kruse's full Mourre proof and
the cited 1986 ideal-detector paper are not proof inputs to this review.

Graf--Schenker's theorem is for a fixed two-magnon/two-particle coordinate
problem; its scattering part is complemented by bound-pair channels. The
displayed interaction is bounded, self-adjoint, invariant along a sublattice,
and supported on finitely many transverse classes. Those hypotheses are not
provided by N1 for the whole GNS representation. The original scanned theorem
statements and hypotheses were inspected from images extracted directly from
the stored PDF. No whole-model completeness theorem is imported.

Provisional pre-control conclusion: the full displayed conditional reduction
reconstructs without a material mathematical defect. PC and ND remain genuine
open obligations; there is no N1 completeness result or microscopic
counterexample. The reviewer's independent finite checks and then the author
control inspection may still reveal errors and will be recorded separately.
