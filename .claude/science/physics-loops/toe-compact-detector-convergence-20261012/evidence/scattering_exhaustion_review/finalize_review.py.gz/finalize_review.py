"""Deterministic source refresh and evidence inventory; no scientific checks."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

E = Path(__file__).resolve().parent
S = E.parent
A = S / 'scattering_exhaustion_next'
W = S.parent / 'scattering_worktree'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (E / name).write_text(json.dumps(value, indent=2) + '\n')


def check(path, expected):
    actual = sha(path)
    result = {'path': str(path), 'expected_sha256': expected,
              'actual_sha256': actual, 'matches': actual == expected}
    assert result['matches'], result
    return result


now = datetime.datetime.now(datetime.timezone.utc).isoformat()
target = S / 'SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md'
target_expected = 'c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2'
author_receipt_expected = '8fac2fc46322fc8a58e2a86eda22128a7e9c7a831f329c53f0775d2ea60aca3a'
freeze = json.loads((E / 'precontrols_freeze.json').read_text())
coverage = json.loads((E / 'reading_coverage_precontrols.json').read_text())
checks = [check(target, target_expected),
          check(A / 'receipt.json', author_receipt_expected),
          check(E / 'precontrols_freeze.json',
                'f30fb81f12a766b7a2ae59a8ba6817a28ae8eaf8e6ae0996eb39ba864a70792f')]
for name, expected in freeze['frozen_files'].items():
    checks.append(check(E / name, expected))
for source in coverage['sources']:
    checks.append(check(Path(source['path']), source['sha256']))
for source in json.loads((E / 'primary_verification/pdf_identity.json').read_text()):
    checks.append(check(Path(source['path']), source['sha256']))
for source in json.loads((E / 'source_match.json').read_text()):
    choices = [S / source['name'], A / 'sources' / source['name']]
    path = next(p for p in choices if p.is_file())
    checks.append(check(path, source['sha256']))

author_receipt = json.loads((A / 'receipt.json').read_text())
artifact_checks = []
for artifact in author_receipt['artifacts']:
    path = (A / artifact['path']).resolve()
    assert path.is_relative_to(A.resolve())
    result = check(path, artifact['sha256'])
    result.update({'bytes': path.stat().st_size,
                   'bytes_match': path.stat().st_size == artifact['bytes']})
    assert result['bytes_match'], result
    artifact_checks.append(result)

expected_refs = {
    'HEAD': 'c3f84746b1991e0a15c6da79d049b89d9469f727',
    'origin/main': 'a13caa4885f547c8d206265b031ba7649e539fd9',
    'origin/ai/execution': '3a4b2c66a1ead7a1c48b4359627e968f681e3c39',
}
refs = []
for ref, expected in expected_refs.items():
    actual = subprocess.check_output(['git', 'rev-parse', ref], cwd=W,
                                     text=True).strip()
    refs.append({'ref': ref, 'expected': expected, 'observed': actual,
                 'unchanged': actual == expected})
save('source_refresh.json', {
    'checked_utc': now, 'target_lines': len(target.read_text().splitlines()),
    'checks': checks, 'author_artifacts': artifact_checks,
    'all_source_hashes_match': True, 'all_author_artifacts_match': True,
    'author_artifact_count': len(artifact_checks), 'observed_refs': refs,
    'remote_fetch_performed': False,
    'authority': 'Exact supplied commit identities, not a claim of fetched remote freshness.'
})

post_paths = [
    E / 'author_evidence/check_reduction_algebra.py',
    E / 'author_evidence/reduction_algebra.execution.json',
    E / 'author_evidence/reduction_algebra.stdout.jsonl',
    E / 'author_evidence/reduction_algebra.stderr.txt',
    E / 'author_evidence/ASSUMPTIONS_AND_IMPORTS.md',
    E / 'author_evidence/THEOREM_TRACE.md',
    E / 'author_evidence/CLAIM_STATUS_CERTIFICATE.md',
    E / 'author_evidence/LITERATURE_BRIDGES.md',
    E / 'author_evidence/READING_COVERAGE.json',
    A / 'sources/COMPACT_PATCH_SCATTERING_COVARIANCE_REVIEW.md',
    A / 'sources/EX_REPAIR_REVIEW_ADDENDUM.md',
    E / 'author_reproduction.stdout.jsonl',
    E / 'author_reproduction.stderr.txt',
    E / 'author_reproduction.execution.json',
    E / 'independent_checks.stdout',
    E / 'independent_checks.stderr',
    E / 'independent_checks.execution.json',
]
save('reading_coverage_postcontrols.json', {
    'recorded_utc': now, 'read_after_independent_freeze': [
        {'path': str(p), 'sha256': sha(p), 'coverage': 'complete'}
        for p in post_paths
    ],
    'author_receipt': {
        'path': str(A / 'receipt.json'), 'sha256': author_receipt_expected,
        'coverage': 'Complete metadata outside artifact list read; all 230 artifact hashes and byte counts mechanically validated. Inventory is not proof reading.'
    },
    'later_target_reread': 'All 262 numbered lines read after author reproduction; unchanged hash.',
    'reread_display_limits': 'One combined redisplay of already-frozen coverage and reconstruction exceeded output limits. No new source-reading claim depends on it; the beginning of reconstruction was separately reread and its complete prior coverage is frozen.',
    'excluded': 'Fock proof and any proof of PC/ND; no status claim adopted from previous review verdicts.'
})

failures_path = E / 'operational_failures.json'
failures = json.loads(failures_path.read_text())
failure = {
    'stage': 'final bookkeeping schema inspection',
    'error': "AttributeError: 'list' object has no attribute 'items'",
    'cause': 'Inspector assumed source_match.json was a dictionary; it is a list.',
    'resolution': 'Type-aware read completed; full refresh validates every source entry.',
    'science_effect': 'none; no check or source mutation occurred in the failed read'
}
if failure not in failures:
    failures.append(failure)
save('operational_failures.json', failures)

report = S / 'SCATTERING_EXHAUSTION_REVIEW.md'
report_hash = sha(report)
(E / 'CHECKPOINT.md').write_text(f'''# Scattering exhaustion review checkpoint

Review complete for the exact 262-line frozen target, SHA-256 {target_expected}.
Report: {report.name}, SHA-256 {report_hash}.

Disposition: supported conditional E1-E18 reduction; no material correction
required within that scope. PC and ND remain open science obligations. No
physical N1 completeness, new retained status, or broad no-go is established.

The independent analytic reconstruction and exact coverage were frozen at
{freeze['frozen_utc']} before author controls. The distinct reviewer checks
then ran once under 60 seconds; the author helper was subsequently read and
reproduced once under 60 seconds, with five byte-identical stdout records.
All 230 author artifact identities and all frozen review dependencies were
refreshed. Full logs, coverage, source identities and control limitations are
in this directory; receipt.json binds the final inventory.

Read-only authority: main a13caa4885f547c8d206265b031ba7649e539fd9,
instructions 3a4b2c66a1ead7a1c48b4359627e968f681e3c39, scattering source
c3f84746b1991e0a15c6da79d049b89d9469f727. Original N1/B1/M1 identities
are from 0cc560e3935fa1ad7623592bf9974680c922d52d. No remote fetch or
Git, PR, audit, axiom or prompt mutation was made.

Parent's proposed later PC compactness adaptation is outside this review.
No author work on that route has started here. Next decision belongs to the
parent after receiving the present source-bound verdict. Three repaired
bookkeeping/path assumptions are preserved in operational_failures.json;
none affected a mathematical inference or altered frozen sources.
''')

save('finalization_result.json', {
    'finished_utc': now, 'report_sha256': report_hash,
    'source_checks': len(checks), 'source_checks_all_match': True,
    'author_artifacts_checked': len(artifact_checks),
    'author_artifacts_all_match': True,
    'observed_refs': refs,
    'remaining_required_review_work': []
})

inventory = []
for path in sorted(E.rglob('*')):
    if path.is_file() and path.name != 'receipt.json':
        inventory.append({'path': str(path.relative_to(E)),
                          'bytes': path.stat().st_size, 'sha256': sha(path)})
# The author receipt is an input and is included explicitly despite its basename.
author_copy = E / 'author_evidence/receipt.json'
inventory.append({'path': str(author_copy.relative_to(E)),
                  'bytes': author_copy.stat().st_size, 'sha256': sha(author_copy)})
save('receipt.json', {
    'kind': 'focused_independent_conditional_scattering_exhaustion_review',
    'completed_utc': now,
    'campaign_deadline_utc': '2026-10-12 16:00:52 UTC',
    'target': {'path': str(target), 'lines': 262, 'sha256': target_expected},
    'report': {'path': str(report), 'sha256': report_hash},
    'author_receipt_sha256': author_receipt_expected,
    'review_disposition': 'supported conditional reduction E1-E18; no material mathematical correction required',
    'open_science_obligations': ['PC for each admissible arrangement',
                                 'ND/E18 for each energy partition interval',
                                 'realization of all required direct creator and microscopic premises'],
    'not_established': ['PC', 'ND', 'EC', 'physical N1 exhaustion',
                        'Fock surjectivity', 'new retained status',
                        'local-UHF counterexample or broad no-go'],
    'fock_isometry_used': False,
    'independence': {
        'precontrol_freeze_utc': freeze['frozen_utc'],
        'precontrol_freeze_sha256': sha(E / 'precontrols_freeze.json'),
        'reconstruction_sha256': sha(E / 'INDEPENDENT_RECONSTRUCTION_PRECONTROLS.md'),
        'shared_context': freeze['shared_context'],
        'distinct_reviewer_control_before_author_helper': True,
        'model_or_effort_override': False, 'subdelegation': False
    },
    'control_executions': {
        'independent': json.loads((E / 'independent_checks.execution.json').read_text()),
        'author_reproduction': json.loads((E / 'author_reproduction.execution.json').read_text())
    },
    'refresh': {'source_checks': len(checks), 'all_match': True,
                'author_artifact_count': len(artifact_checks),
                'author_artifacts_all_match': True, 'observed_refs': refs},
    'writes': ['SCATTERING_EXHAUSTION_REVIEW.md', 'scattering_exhaustion_review/'],
    'editable_prompt_files_changed': [],
    'frozen_sources_changed': [],
    'git_pr_audit_or_axiom_mutations': [],
    'self_hash_policy': 'This receipt excludes itself; its SHA-256 is returned to the parent.',
    'artifacts': inventory
})
print(json.dumps({'report_sha256': report_hash,
                  'receipt_sha256': sha(E / 'receipt.json'),
                  'review_artifact_count': len(inventory),
                  'source_checks': len(checks),
                  'author_artifacts': len(artifact_checks),
                  'observed_refs': refs}, indent=2))
