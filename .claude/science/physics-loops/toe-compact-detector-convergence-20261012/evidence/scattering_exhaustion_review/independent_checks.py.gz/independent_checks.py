#!/usr/bin/env python3
"""Finite convention controls only; no PC/ND/infinite-volume conclusion.

Written before reading the exhaustion author's helper/logs/receipt.
Distinct construction: spectral lowering matrices with a cyclic translation
representation, mixed smooth dispersions, and a direct convolution remainder.
The candidate's descriptions of its own control classes were already visible.
"""
import itertools
import json
import platform

import numpy as np


def emit(name, **values):
    print(json.dumps({"check": name, **values}, sort_keys=True), flush=True)


rng = np.random.default_rng(621847)
L, dim = 7, 10
p = 2 * np.pi * np.arange(L) / L
qidx = np.array([0, 1, 2, 3, 4, 5, 6, 2, 4, 1])
q = p[qidx]
sigma = [
    mass + 0.23 * (1 - np.cos(p + theta)) + 0.17 * (1 - np.cos(2 * p - theta))
    for mass, theta in [(1.5, 0.17), (2.3, -0.29), (3.1, 0.41)]
]
energies = np.array([0.0, sigma[0][1], sigma[1][2], sigma[2][3], 7.2, 8.5,
                     10.1, 12.3, 14.8, 17.1])
energy_diff = energies[:, None] - energies[None, :]
momentum_diff = q[:, None] - q[None, :]
transfer_idx = (qidx[None, :] - qidx[:, None]) % L
annihilators = []
for i in range(3):
    A = np.zeros((dim, dim), complex)
    A[0, i + 1] = 1 + 0.11j * (i + 1)
    for row in range(1, dim):
        for col in range(row + 1, dim):
            A[row, col] = 0.2 * (rng.normal() + 1j * rng.normal())
    annihilators.append(A)

psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
psi /= np.linalg.norm(psi)
delta = [1j * energy_diff * A for A in annihilators]
Ds = [delta[i] + 1j * sigma[i][transfer_idx] * annihilators[i] for i in range(3)]
vacuum_row_defect = max(float(np.linalg.norm(D[0])) for D in Ds)
assert vacuum_row_defect < 1e-12

# The Fourier filter acts on every matrix entry, not only B Omega.
B = annihilators[0].conj().T
phi = np.array([0, 1, 0.7, 0, 0, 0, 0.0])
c = np.fft.ifft(phi)
filtered = sum(c[z] * np.exp(-1j * z * momentum_diff) * B for z in range(L))
creator_transfer = (qidx[:, None] - qidx[None, :]) % L
expected = phi[creator_transfer] * B
filter_error = float(np.linalg.norm(filtered - expected))
vacuum_only_mutant = B.copy()
vacuum_only_mutant[:, 0] *= phi[qidx]
forbidden = (phi[creator_transfer] == 0)
vacuum_only_leak = float(np.linalg.norm(vacuum_only_mutant * forbidden))
assert filter_error < 1e-12 and vacuum_only_leak > 0.1
emit("full_operator_geometric_filter", error=filter_error,
     vacuum_only_mutant_forbidden_transfer_norm=vacuum_only_leak)


def product(matrices):
    ans = np.eye(dim, dtype=complex)
    for matrix in matrices:
        ans = ans @ matrix
    return ans


def source(matrices, derivatives, n, adjacent_only=False):
    total = 0j
    for i in range(1, n):
        for j in range(i):
            if adjacent_only and j != i - 1:
                continue
            comm = matrices[j] @ derivatives[i] - derivatives[i] @ matrices[j]
            seq = (matrices[:j] + [comm] + matrices[j + 1:i] + matrices[i + 1:])
            total += (product(seq) @ psi)[0]
    return total


records = []
for n in (1, 2, 3):
    sigsum = sum(sigma[i].reshape([L if k == i else 1 for k in range(n)])
                 for i in range(n))
    for time in (0.0, 0.37, 1.15):
        operators, source_operators, derivative_operators = [], [], []
        for i in range(n):
            phase = np.exp(1j * time * energy_diff)[None, :, :] * np.exp(
                -1j * np.arange(L)[:, None, None] * momentum_diff[None, :, :])
            operators.append(phase * annihilators[i][None, :, :])
            source_operators.append(phase * Ds[i][None, :, :])
            derivative_operators.append(phase * delta[i][None, :, :])
        F = np.empty([L] * n, complex)
        dF = np.empty_like(F)
        R = np.empty_like(F)
        R_missing_dispersion = np.empty_like(F)
        R_adjacent_only = np.empty_like(F)
        for positions in itertools.product(range(L), repeat=n):
            As = [operators[i][positions[i]] for i in range(n)]
            Di = [source_operators[i][positions[i]] for i in range(n)]
            dAs = [derivative_operators[i][positions[i]] for i in range(n)]
            ordered = product(As)
            F[positions] = (ordered @ psi)[0]
            # Independent derivative path from the common microscopic unitary.
            dF[positions] = -1j * (ordered @ (energies * psi))[0]
            R[positions] = source(As, Di, n)
            R_missing_dispersion[positions] = source(As, dAs, n)
            R_adjacent_only[positions] = source(As, Di, n, adjacent_only=True)
        free = np.fft.ifftn(sigsum * np.fft.fftn(F))
        residual = float(np.linalg.norm(dF + 1j * free - R))
        wrong_sign = float(np.linalg.norm(dF - 1j * free - R))
        missing_dispersion = float(np.linalg.norm(dF + 1j * free - R_missing_dispersion))
        missing_pair = float(np.linalg.norm(dF + 1j * free - R_adjacent_only))
        record = dict(n=n, time=time, configurations=L**n, correct_residual=residual,
                      source_norm=float(np.linalg.norm(R)), wrong_free_sign=wrong_sign,
                      omitted_dispersion_commutator=missing_dispersion,
                      omitted_nonadjacent_pairs=missing_pair)
        records.append(record)
        assert residual < 2e-10
        assert wrong_sign > 0.1
        if n >= 2:
            assert record["source_norm"] > 0.1 and missing_dispersion > 0.1
        if n == 3:
            assert missing_pair > 0.1
emit("mixed_dispersion_scalar_equation", dimension=dim, cyclic_sites=L,
     vacuum_row_defect=vacuum_row_defect, records=records,
     limitation="Finite cyclic algebra control, not a microscopic N1 or scattering model")


def bump(u):
    u = np.asarray(u)
    ans = np.zeros_like(u, dtype=float)
    good = np.abs(u) < 2
    ans[good] = np.exp(-1 / (1 - u[good] ** 2 / 4))
    return ans


def bump_derivative(u):
    u = np.asarray(u)
    ans = np.zeros_like(u, dtype=float)
    good = np.abs(u) < 2
    z = u[good]
    ans[good] = -bump(z) * z / (2 * (1 - z*z / 4) ** 2)
    return ans


convolution_records = []
for theta, a, b in [(0.31, 0.7, 0.2), (-0.47, 0.9, -0.16)]:
    kappa = {-1: a/2*np.exp(1j*theta), 1: a/2*np.exp(-1j*theta),
             -2: b/(2j)*np.exp(-1j*theta), 2: -b/(2j)*np.exp(1j*theta)}
    rows = []
    for time in (16, 32, 64, 128, 256):
        x = np.arange(-4*time, 4*time + 1)
        h = bump(x/time)
        hp = bump_derivative(x/time)
        remainder = np.zeros_like(x, dtype=float)
        wrong_sign = np.zeros_like(x, dtype=float)
        for z, coefficient in kappa.items():
            diff = bump((x-z)/time) - h
            remainder += np.abs(1j*coefficient*(diff + z/time*hp))
            wrong_sign += np.abs(1j*coefficient*(diff - z/time*hp))
        # All omitted rows vanish: support is inside |x|<=2t+2.
        rows.append(dict(time=time,
                         correct_row_sum=float(np.max(remainder)),
                         t_squared_correct=float(time*time*np.max(remainder)),
                         t_wrong_velocity=float(time*np.max(wrong_sign)),
                         t_omitted_moving_cutoff=float(np.max(np.abs(x/time*hp)))))
    scaled = [r["t_squared_correct"] for r in rows]
    assert max(scaled)/min(scaled) < 1.2
    assert min(r["t_wrong_velocity"] for r in rows) > 0.1
    assert min(r["t_omitted_moving_cutoff"] for r in rows) > 0.1
    convolution_records.append(dict(theta=theta, records=rows))
emit("direct_E16_convolution_remainder", records=convolution_records,
     limitation="Schur row-sum control of finite-band convolution kernels; analytic proof remains load-bearing")
emit("environment", python=platform.python_version(), numpy=np.__version__,
     seed=621847, status="all_assertions_satisfied")
