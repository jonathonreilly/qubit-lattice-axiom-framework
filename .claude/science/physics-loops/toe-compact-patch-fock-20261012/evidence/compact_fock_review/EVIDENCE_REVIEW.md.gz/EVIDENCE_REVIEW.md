# Author evidence and independent controls

The analytic reconstruction was frozen before reading the author-control
source, logs, execution metadata or receipt. Its SHA-256 is
`85f4d93458c6f00ede645e6d2ac272084dc0cd053b66801b25db8574586df484`,
with freeze time 2026-10-12T00:00:56.486997+00:00. Candidate descriptions of
the controls were visible; this exposure is recorded in the freeze receipt.

The author's receipt matches the assigned SHA-256
`48b2a3fb2aeef107685ade2404e4029741fd9076e22f2d1fd6a3803588026c6d`.
All 92 artifact length/hash bindings and the 326-line note binding matched.
The complete receipt-bound evidence has been copied unchanged to author_evidence/.
Hash checks bind those bytes; actual mathematical coverage comes from the
source and original primary proof reads, not the artifact count.

## Independent implementation

`independent_controls.py` was written and run before viewing author code.
It uses concrete matrix multiplication and occupation polynomials, whereas
the author's central algebra test uses free noncommutative words. Both target
the same visible mathematical identities; these are not independent premises.
The run used a declared 60-second timeout, exited 0 in 2.088 seconds, and
preserved seven complete JSONL records and empty stderr. Its source SHA-256 is
`23ecbf20deeb4dd83de577bc6f0913b47b93bc8c0e2abd5bf2f47eb3a8c2e873`.

- Eighteen exact integer-matrix cases tested Q^2's identity. Omitting its
  commutator term produced a maximum entry residual of 7787.
- Fourteen exact integer-matrix cases tested the full annihilator recursion
  on a vacuum annihilated by A, without assuming the creator factors commute.
  Omitting double brackets produced a maximum entry residual of 6118.
- The integer matrix dimensions and word lengths are small enough that the
  crude bound from entry size <=2 and dimension <=7 is far below int64
  overflow; these identity checks are exact arithmetic, not floating norms.
- 165 finite cyclic spin cases tested energy compressions with actual
  translation covariance of H, creator energy transfers {1,2}, and
  noncommuting translated lowerers. The computed maximum bound ratio was
  1.0000000000000002, within the declared floating tolerance of 1e-9.
  The minimum nonzero creator norm squared on the vacuum was 2.0847463991690827,
  while the incorrectly unpadded bound is zero. This is a finite float64
  control; it does not prove the infinite-lattice estimate.
- An exact two-site hard-core example has A_0^2=0 but A_0 A_1!=0,
  so a single nilpotence kernel cannot replace the mixed-product kernels.
- Twenty-one exact occupation-polynomial cases agreed with the permanent
  of the single-particle Gram matrix. An extra factorial is detected.
- A two-dimensional Hilbert-space example has individually isometric W_out
  and W_in but W_out*W_in=0. This controls the conclusion boundary only;
  it is not a counterexample to any lattice scattering premise.

The analytic proof remains RECONSTRUCTION.md. None of these finite controls
establishes clustering, stationary phase, density or a physical realization.

## Author source scrutiny and reproduction

The full 7643-byte author-control source, complete nine-record stdout, empty
stderr and execution metadata were read. The exact author command was rerun
with a declared 60-second timeout. It exited 0 in 0.716 seconds and reproduced
both outputs byte-for-byte. Full logs and the exact command are in
logs/author_rerun.*. This rerun is reproduction, not an independent implementation.

The free-word recursion and Q^2 checks compare actual polynomial expansions
and do not assume translated lowerers commute. The Hessian is differentiated
by SymPy and its determinant compared with the proved formula. The inverse
velocity calculation checks the dispersion relation and the positive root
under its declared velocity-ball domain. The concrete different-mass example
correctly has beta=1 and equal velocity 4/5, so species alone do not separate
packets.

The finite hard-core energy checks construct lowering matrices, form Q and
creator matrices, and test all principal minors of the claimed compressed
positive-semidefinite differences. Their S_B=1 and Gamma(R)=R values are
justified by the generated matrices. The creator-padding negative control is
meaningful. The author's separate two-by-two translated-nilpotence example
only illustrates the logical distinction between kernels; its translation
is not asserted to commute with a positive Hamiltonian. The review's two-site
example checks that distinction even with translation-covariant number energy.

The normalization function explicitly branches on m=n, so its reported 49
rectangular cases do not independently verify particle-number orthogonality.
It enumerates factorial counts; the note already restricts its claimed role
to bookkeeping and disclaims an analytic Gram proof from it. That portion is
not used as evidence for orthogonality in this review. The independent full
recursion proves unequal-number vanishing, and the occupation-polynomial
control checks the actual bosonic normalization. Likewise, the exponent table
checks arithmetic after the energy-word bound is supplied; it does not test
that bound dynamically. No required source correction follows from these
honestly stated limitations.

No proxy physical model, fitted prefactor, copied empirical target, rounded
anchor or fabricated completeness gate was found in a load-bearing claimed
control. None of the nine records replaces the written analytic proof.

## Primary extraction and source coverage

The two PDF hashes match the designated versioned primary sources. The review
used a fresh layout-mode pypdf extraction from those PDFs for its original
reading. Whole-PDF extraction warned about rotated text; the relevant theorem
pages were read completely, and their proof context was preserved. As a later
cross-check, default-mode extraction of all 29 read pages was compared with
the author's page texts. All content agreed after stripping outer whitespace;
BDN differences were trailing newline only. The full diff and per-page records
are retained. No byte-for-byte equality claim is made for those page files.

BDN pages read: 7-24, 39-43. NS pages read: 3-4, 9-12. These cover the actual
imported LR/interaction assumptions, clustering theorem and proof, Arveson
transfer and its Appendix B proof, almost-local invariance and localization,
packet stationary phase, creator and shell definitions, regular mixed-packet
contraction, Gram recursion and Fock-density extension. The remaining pages
are saved as recovery material but are not certified as read.

The note, predecessor, predecessor review, exact EX repair and addendum were
read completely. N1 lines 1-195 were read for the hypotheses and relevant
reduction setting; this review certifies only the use of the displayed H-gap
clause, not other N1 claims. The author assumption/status/trace/literature,
checkpoint, source/reading/runtime/instruction metadata were read in full.
The old predecessor artifact inventory in FROZEN_INPUT_RECHECK.json is a
binding record, not a fresh review of its author controls.

## Operational failures and recovery

An initial overbroad path inventory and combined display were truncated; they
were used only to locate paths. Necessary sources were subsequently read in
bounded complete chunks and saved in sources/. System pdftotext was absent;
the configured runtime's pypdf performed extraction. One parallel read of two
snapshots raced their creation and returned file-not-found; it was repeated
sequentially after snapshot creation and read fully. An initial apply_patch
for the reconstruction had a malformed add-file line, failed validation and
wrote no file; the subsequent complete file write succeeded. No failed step
is counted as scientific verification. The primary-extraction equality check
initially failed exact-byte comparison, then was resolved to outer newlines
with the complete retained diff.
