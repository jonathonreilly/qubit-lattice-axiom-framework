# Pre-author-evidence reconstruction of the compact-patch Fock argument

This file is to be frozen before opening the Fock author's control source,
outputs, execution metadata, or receipt. The candidate itself, including its
control descriptions, was read completely. The parent's brief named the
regular-shell route and questions to check; root is a contributor. This is an
independent examination of a visible proof, not blind discovery. Inherited
model/reasoning settings are unchanged, and there was no subdelegation.

## Fixed source and target

- Candidate: 326 lines, SHA-256
  `9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404`.
- Predecessor: 404 lines, SHA-256
  `d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`.
- Predecessor review:
  `924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be`.
- EX repair `d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`;
  addendum `8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029`.
- BDN arXiv:1412.2970v2 PDF:
  `3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126`.
- NS arXiv:0712.3318v1 PDF:
  `74829f87cc51d399613043a3abdc48ba3146c81292a09e4df1035b50eb464b5c`.
- N1: `c284a41bfee8a1238643330ddd46f3a7c4f6f1a865509a9aaec5ab6f4238ad13`;
  only its explicit H-gap setting is reused, not its no-go conclusions.

The target is an implication for d>=1, beta>0, positive masses, finitely many
actual mass/centre subspaces, and fixed finite internally velocity-separated
packet families. It asserts their permanent Gram formula and unique incoming
and outgoing isometric extensions on symmetric Fock space. It does not assert
physical realization, GNS exhaustion, boost covariance, or isometry of the
composition of the two wave operators.

Instructions were read at main `a13caa4885f547c8d206265b031ba7649e539fd9`
and planning `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. Read-only remote
ref verification agreed. The parent's separate staged scattering publication
was not edited. This review does not run landing or audit procedures.

## Predecessor and actual imported properties

The complete predecessor was read. Its supplied assumptions are actual bounded
finite-range microscopic H and K flows, strongly commuting implementing
unitaries, an isolated positive Casimir mass value, finite-order centre action
on that mass space, and compact chart data separated in velocity within each
product. They are conditions, not derived framework premises.

The joint Schwartz filter has vacuum value

    B_g(A) Omega = G(H,K) A Omega = h(K) E_M A Omega.

The signs follow from alpha_t=Ad exp(+itH), rho_y=Ad exp(-iy.K),
T_x=exp(-ix.Q), and inverse transform exp(-iEs+ik.y). The finite centre
average with weight exp(-i theta.z) is a character projector on E_M H only.
It gives B Omega=Pi_theta^M h(K) E_M A Omega and Q=k-theta modulo 2pi.
On a lift k=p+theta+2pi n this vector lies on E=Sigma(p).

Almost locality follows by truncating continuous flow parameters at a small
multiple of the localization radius. Local approximation error is polynomial
in the radius times exp(-c r); the outer integral is a Schwartz tail. No
exponentially growing LR bound is integrated over the unrestricted tail.
Derivatives differentiate the L1 filter kernel and are norm-defined, with all
derivatives almost local. Fixed finite microscopic flows preserve this class.

The packet sum has C_i(t)Omega=psi_i exactly. Its full derivative includes
both alpha_t(B_i)'s derivative and the packet phase derivative and annihilates
Omega. Equal-time commutator norms lose the common alpha_t exactly. Velocity
collars give rapid commutators; a fixed remaining finite word costs polynomial
norms. Moving differentiated factors to the right produces every i<k bracket
and n-2 other factors. Taking arbitrarily high almost-locality order yields
Cook convergence and permutation symmetry in both time directions.

The predecessor's EX paragraph needed the separate unique-vacuum/gap setting;
the exact read repair supplies it without changing the construction. Here F1
supplies both hypotheses explicitly. The predecessor review is not Fock evidence.

## Positive transfer gives uniform finite-energy bounds

The time-frequency projection of supp G is a compact subset of (0,infinity).
Convolving in time with a Schwartz multiplier equal to one there leaves B
unchanged; tests outside that projection vanish. Thus Sp_alpha(B) is contained
in [epsilon,L], epsilon>0. Commuting centre averages, geometric translations,
alpha_t, and the packet sum preserve this interval. The joint geometric
transfer is therefore contained in [epsilon,L] x T^d even without geometric
shell isolation.

BDN Proposition 3.6 (3.11)-(3.15) and Appendix B prove transfer by convolving
an operator and an input spectral cutoff, adding their Fourier supports,
separating compact output support and removing the smoothing with an approximate
identity. The sets needed here are compact, so no closure or measurability
issue with a sum of arbitrary Borel sets enters. In particular every translate
of B* lowers P_R=1_[0,R](H) by at least epsilon. Every mixed r-fold word in
such translates vanishes on P_R when r epsilon>R.

For finite Lambda put A_x=tau_x(B*), Q=sum A_x* A_x. Let P_r project onto
the common kernel of all r-fold words in all A_x, not just a power of one
operator. Then A_x Ran P_r is contained in Ran P_(r-1), and
b_r=||P_r Q P_r|| satisfies b_1=0. For unit Phi in Ran P_r, q=<Phi,Q Phi>,

    <Phi,Q^2 Phi>
      =sum_xy <A_x Phi,[A_x,A_y*]A_y Phi>
        +sum_xy <A_y A_x Phi,A_x A_y Phi>.

This follows directly from moving A_x across A_y* in Q^2. The absolute
row/column sums of the commutator matrix are bounded by
S=sum_z ||[B*,tau_z B]||<infinity. The inequality 2ab<=a^2+b^2 bounds
the first sum by S q. Cauchy-Schwarz and interchange of x,y bound the second
sum by sum_xy ||A_y A_x Phi||^2<=b_(r-1)q. Thus q^2<=<Q^2><=(S+b_(r-1))q,
including q=0, and b_r<=(r-1)S. Taking r=floor(R/epsilon)+1 proves

    ||P_R sum_x tau_x(BB*) P_R|| <= floor(R/epsilon)S =: upper Gamma_B(R).

The infinite sum means the positive increasing strong limit after compression.
It need not be bounded without compression. The bound vanishes for R<epsilon;
at R=epsilon it allows one lowering. This reconstructs the required Buchholz
estimate behind BDN Theorem 3.11 without assuming lowering operators commute.

Vector-valued Cauchy-Schwarz and Parseval now give

    ||C(t)*P_R|| <= ||f_t||_2 sqrt(Gamma_B(R)).

Because C(t)P_R=P_(R+L)C(t)P_R, duality gives

    ||C(t)P_R|| <= ||C(t)*P_(R+L)||
                 <= ||f_t||_2 sqrt(Gamma_B(R+L)).

The l2 norm is time independent, and alpha_t commutes with P_R. The R+L
padding is essential even when creating from Omega. These are the exact
bounds needed from BDN Lemma 4.5(c), with its shell-isolation assumption
replaced by the directly established compact positive transfer.

For any fixed finite mixed word W(t), choose R_* as the sum of its upper
positive transfer bounds. Every intermediate vector in W(t)Omega has energy
in [0,R_*]. Inserting P_(R_*) and the preceding bounds makes its norm O(1).
Taking the adjoint word also proves ||<Omega|W(t)||=O(1). This controls the
entire later Gram row, not only a two-packet product.

## Regularity and mixed-packet contraction

Direct differentiation gives Hess Sigma=(beta/E)I-(beta^2/E^3)kk^T.
Its transverse eigenvalues are beta/E, its longitudinal eigenvalue beta M^2/E^3;
at k=0 all equal beta/M. Therefore det Hess Sigma=beta^d M^2/E^(d+2)>0.
These eigenvalues have positive uniform lower bounds on each compact chart.
Uniform stationary phase gives ||f_t||_infty=O(T^(-d/2)); rapid off-velocity
integration-by-parts tails plus O(T^d) sites in the collar give
||f_t||_1=O(T^(d/2)). This matches BDN Proposition 4.3. Every packet may
use its own dispersion; constants need not be uniform over the chart cover.

F1 explicitly says ker H=C Omega and gives a positive lower bound on H on
all Omega-perp. N1's actual H-gap clause includes that spectral statement, so
its implication of F1 is correct even though invariant-state uniqueness alone
would be insufficient. Finite-range microscopic H has the finite exponentially
weighted interaction norm required by NS Theorem 4.1.

That theorem requires P_0 B Omega=P_0 B* Omega=0. Apply it to
B_0=B-omega(B)1: rank-one P_0 supplies both, ||B_0||<=2||B||, and B_0
belongs to the same local algebra. In the proof, the positive spectral gap
bounds the two Gaussian spectral remainders and LR bounds the short real-time
commutator. The choices alpha=gamma/(2s) and
s=lambda R/(2 N_H C_lambda+gamma/2) yield
mu=lambda gamma/(4 N_H C_lambda+gamma). For distance R>=1, NS (46)'s
square-root factor is bounded by mu^(-1/2). Interaction-boundary cardinalities
are bounded by support cardinalities; min(|X|,|Y|)>=1 absorbs the remaining
constant terms. Hence the candidate's
C_cl=2(1+mu^(-1/2)+2||F||/(pi C_lambda)) is safe in F12. No K-gap is used.

For four fixed almost-local observables define

    F=<Omega,[tau_x1 A_1,tau_x2 A_2] P_perp
                     [tau_x3 A_3,tau_x4 A_4]Omega>.

Almost locality gives arbitrary-order decay separately in x_1-x_2 and x_3-x_4.
For R=|x_2-x_3|, use norm-bounded local approximants of radius r=(1+R)/16.
If either pair's balls are disjoint its commutator is zero. Otherwise each
pair's centres have distance <=2r and the pair supports have distance >=R-6r.
Clustering bounds the connected correlation by
C(1+r)^d exp(-mu(R-6r)); replacement errors are O(r^(-L)) for arbitrary L,
uniformly in all positions. This proves arbitrary middle-distance decay.
Apply the three separate bounds at order 3N and take their geometric mean.
This proves the product of three summable relative-coordinate weights in F13.

Since C_i(t)*Omega=0,

    P_perp C_i(t)*C_k(t)Omega=P_perp[C_i(t)*,C_k(t)]Omega.

Its squared norm is a four-packet sum. Remove common physical time evolution,
which fixes Omega and commutes with P_perp. For each three relative coordinates,
sum one scalar factor in l1 and bound the other three in l-infinity; the total
power is T^(d/2)T^(-3d/2)=T^(-d). Taking N>d makes the three relative sums
converge. Thus

    C_i(t)*C_k(t)Omega=<psi_i,psi_k>Omega+O(T^(-d/2)).

This proof requires neither common dispersion, geometric shell isolation nor
cross-family velocity separation. Different mass/centre sectors merely make
the scalar contraction zero by their actual Hilbert-space orthogonality. The
original BDN Lemma 4.7(b) proof supplies this mechanism, not an unverified
application of all its standing shell hypotheses.

## Full recursion, including the error after other factors

If X and Y have separated compact velocity supports and A is any third packet,
choose a smooth velocity cutoff equal to one near V_X and zero near V_Y.
Pull it back by A's own velocity map to split its Fourier amplitude. The
second piece is separated from X and has a rapid inner commutator. The first
is separated from Y, and Jacobi expresses its double commutator using rapid
commutators with Y and between X,Y. Polynomial remaining norms are absorbed
by arbitrary decay order. This proves F15 for different charts and adjoints.

Commute A=tilde C_1* through C_1...C_n. Its terminal action vanishes.
Move each resulting [A,C_k] through every later C_l. The exact identity
contains all k<l terms [[A,C_k],C_l], with the other factors in order, plus
the terms whose bracket acts on Omega. The double commutators are rapid
because the right family is internally separated, and their finite polynomial
prefactors do not prevent convergence.

On Omega, [A,C_k] acts as A C_k. Insert the contraction. Its remainder
is paired with the row

    <Omega|tilde C_m*...tilde C_2* C_1...omit C_k...C_n.

The adjoint of this row is a finite mixed word on Omega, and has norm O(1)
by the energy argument. The complete error is therefore O(T^(-d/2)), even
with all other factors present. Full polynomial operator-norm bounds alone
would not establish this. This proves F16 without cross-family separation.

For m=0<n or n=0<m the matrix element is zero already at finite time because
an outer creator's adjoint annihilates Omega; m=n=0 gives one. Recursion
therefore enumerates every permutation exactly once and proves F5 including
unequal particle numbers. Both signs of time use T=1+|t|. In d=1 the
T^(-1/2) contraction error tends to zero; its integrability is unnecessary.

## Spectral absolute continuity and Fock density

For each bounded open K chart O, the vectors
Pi_theta^M h(K)E_M A Omega with smooth compact h in O and local A span a
dense subspace of Pi_theta^M E_M 1_O(K)H. Approximate the identity on O by
bounded smooth cutoffs strongly, and use local cyclicity. A packet amplitude
one on supp h realizes each such vector. Countably many relatively compact
charts cover each selected mass/centre summand.

For every such creator,

    <B Omega,T_x B Omega>=<Omega,[B*,tau_x B]Omega>.

B*Omega=0 kills the other commutator term. The coefficients decrease rapidly
by almost locality, so their Fourier series is a smooth density for the scalar
Q-spectral measure, by Fourier uniqueness on the torus. A Haar-null Q set
therefore kills every dense creator vector and hence all H_1. This proves
absolute continuity on H_1; it does not require smooth densities for all
vectors after Hilbert-space completion.

On each centre/lift chart Q=k-theta modulo 2pi is injective and locally
measure-preserving. Its chart projection commutes with Q. A K-null set in
that chart maps into a Q-null set, so its K spectral projection vanishes.
A countable cover proves K-spectral absolute continuity on each selected
summand. Folded lifts remain coordinate charts, not extra species copies.

The velocity map v_M(k)=beta k/sqrt(M^2+beta|k|^2) is a diffeomorphism onto
|v|<sqrt(beta), with inverse k_M(v)=Mv/(sqrt(beta)sqrt(beta-|v|^2)).
For fixed second momentum and any two positive masses, there is at most one
first momentum with equal velocity. Fubini makes the pairwise equal-velocity
set Lebesgue-null. Finite unions over pairs/species and countable unions over
charts remain null. Distinct masses alone do not imply velocity separation.

Scalar product spectral measures of elementary tensors are products of
absolutely continuous measures. The equal-velocity tensor projection kills
all such tensors and therefore their dense span. Cover its complement by
countably many products of relatively compact chart neighbourhoods with
pairwise disjoint closed velocity images. Their spectral ranges span a dense
tensor subspace: annihilation by each box projection implies annihilation by
the projection of their union. Use local creator density in each factor of
each box, then symmetrize. This proves density of the admissible separated
bosonic products in every Fock sector.

This reconstructs BDN Lemmas 4.15-4.19 for the actual joint K/centre setting.
It does not import BDN's geometric transfer-isolation assumption for density.
The explicit velocity diffeomorphism also avoids the literal pointwise set
inclusion printed in BDN (4.58), which for general smooth maps would require
an almost-everywhere qualification.

## Well-defined extension and covariance

With a*(psi_1)...a*(psi_n)Omega_F normalization, the bosonic Gram formula is
the permanent without an extra factorial. F5 equates norms for every finite
linear combination and its proposed image. A zero Fock vector therefore has
zero image, including when different creator/chart realizations are used.
The map extends uniquely isometrically on each sector. F5 makes distinct
sector images orthogonal, so their Hilbert direct sum gives W^+ and W^-.

Every fixed e^(isH)T_x, exp(-iy.K) and V_j fixes Omega, commutes with the
common packet evolution, preserves H/K/centre spectral subspaces and compact
energy transfer, and preserves almost locality under the supplied finite-time
microscopic flows. Conjugating creators gives the packets of transformed
one-particle vectors with the same velocity support. Passing the fixed
unitary through the known strong limit proves covariance on the dense domain;
continuity extends it. The common q makes V_j^q=1 on each wave-operator range.

An isometry's range is closed but need not equal H. Two isometries can have
different ranges; W_out*W_in is not automatically an isometry. BDN's wording
about S is not imported as that inference. No boosts enter this proof.

## Pre-evidence conclusion and reading limits

No required correction or mathematical counterexample was found in the frozen
candidate. F1 together with the predecessor's explicit supplied hypotheses
supports F5-F6 and the stated translation/V covariance. The physical premises,
coverage of all species, full-GNS exhaustion, boost covariance and full N1
certification remain outside this result. This is not an audit verdict.

Original primary reading: complete BDN PDF pages 7-24 and 39-43; complete NS
pages 3-4 and 9-12. Fresh pypdf extraction was made from the frozen PDFs.
Whole-document extraction issued rotated-text warnings; no inspected theorem
text is truncated. Exact equations were read in their proof context. No claim
to have read all other pages is made. NS's auxiliary Gaussian contour identity
is standard Fourier/Gaussian calculus; its role, gap hypotheses and parameter
choices were checked in the displayed proof rather than by theorem name.

Next: freeze this reconstruction and its timestamp/hash record, perform
independent finite matrix checks of algebraic failure modes, and only then
inspect and reproduce the author's actual controls and bind their evidence.
