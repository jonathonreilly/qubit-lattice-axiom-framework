#!/usr/bin/env python3
"""Independent finite matrix controls, written before viewing author code.
These do not model infinite-lattice scattering and do not prove analytic estimates.
"""
import itertools, json, math
from collections import defaultdict
import numpy as np
rng=np.random.default_rng(20261012)

def emit(name, **kw):
    print(json.dumps({'check':name, **kw},sort_keys=True),flush=True)

def prod(ms, dim):
    out=np.eye(dim,dtype=np.int64)
    for m in ms: out=out@m
    return out

def comm(a,b): return a@b-b@a

def op(a): return float(np.linalg.norm(a,2))

# Exact integer matrices: Q^2 and the complete vacuum commutation recursion.
qcases=0; largest=0; qmut=[]
for dim in [3,5,7]:
  for count in range(1,7):
    aa=[rng.integers(-2,3,size=(dim,dim),dtype=np.int64) for _ in range(count)]
    qq=sum((a.T@a for a in aa),np.zeros((dim,dim),dtype=np.int64))
    term1=sum((a.T@comm(a,b.T)@b for a in aa for b in aa),np.zeros_like(qq))
    term2=sum((a.T@b.T@a@b for a in aa for b in aa),np.zeros_like(qq))
    assert np.array_equal(qq@qq,term1+term2)
    qmut.append(int(np.max(np.abs(qq@qq-term2))))
    largest=max(largest,int(np.max(np.abs(qq@qq))),int(np.max(np.abs(term1))),int(np.max(np.abs(term2))))
    qcases+=1
assert max(qmut)>0
emit('Q_squared_integer_matrix_identity',cases=qcases,exact=True,omitted_commutator_max_residual=max(qmut),largest_integer=largest)

recases=0; rmut=[]; largest=0
for dim in [3,5]:
  omega=np.zeros(dim,dtype=np.int64);omega[0]=1
  for count in range(1,8):
    a=rng.integers(-2,3,size=(dim,dim),dtype=np.int64);a[:,0]=0
    cc=[rng.integers(-2,3,size=(dim,dim),dtype=np.int64) for _ in range(count)]
    lhs=a@prod(cc,dim)@omega
    contracted=np.zeros(dim,dtype=np.int64); double=np.zeros(dim,dtype=np.int64)
    for k in range(count):
      contracted+=prod(cc[:k]+cc[k+1:],dim)@a@cc[k]@omega
      for ell in range(k+1,count):
        double+=prod(cc[:k]+cc[k+1:ell],dim)@comm(comm(a,cc[k]),cc[ell])@prod(cc[ell+1:],dim)@omega
    assert np.array_equal(lhs,contracted+double)
    rmut.append(int(np.max(np.abs(lhs-contracted))))
    largest=max(largest,int(np.max(np.abs(lhs))),int(np.max(np.abs(contracted))),int(np.max(np.abs(double))))
    recases+=1
assert max(rmut)>0
emit('annihilator_recursion_integer_matrices',cases=recases,exact=True,omitted_double_brackets_max_residual=max(rmut),largest_integer=largest)

# Cyclic spin models with translation commuting with H and a noncommuting
# family of energy-lowering translates; B has temporal transfer in {1,2}.
energy_cases=0; ratios=[]; noncomm=[]; wrongpad=[]
for sites in [3,4,5]:
  dim=2**sites; ident=np.eye(dim); energies=np.array([i.bit_count() for i in range(dim)])
  raise_ops=[]
  for s in range(sites):
    r=np.zeros((dim,dim))
    for b in range(dim):
      if not ((b>>s)&1):r[b|(1<<s),b]=1
    raise_ops.append(r)
  rr=raise_ops; ns=[r@r.T for r in rr]
  b=rr[0]@(ident+0.5*ns[1])+0.25*rr[0]@rr[1]+0.75*ns[0]@rr[1]
  nz=np.nonzero(b)
  assert set((energies[nz[0]]-energies[nz[1]]).tolist())=={1,2}
  tt=np.zeros((dim,dim))
  for word in range(dim):
    shifted=((word<<1)&(dim-1))|(word>>(sites-1));tt[shifted,word]=1
  assert np.array_equal(tt@np.diag(energies),np.diag(energies)@tt)
  bb=[];tx=ident.copy()
  for x in range(sites):bb.append(tx@b@tx.T);tx=tx@tt
  sb=sum(op(comm(b.T,bx)) for bx in bb)
  qq=sum((bx@bx.T for bx in bb),np.zeros_like(b))
  noncomm.append(op(comm(bb[0].T,bb[1].T)))
  def project(cut):return np.diag((energies<=cut).astype(float))
  def gamma(cut):
    pp=project(cut);return op(pp@qq@pp)
  for cut in np.arange(0,sites+1.5,0.5):
    assert gamma(cut)<=math.floor(cut)*sb+1e-10
    for t in [-13.0,-1.0,0.0,0.7,15.0]:
      ff=(rng.normal(size=sites)+1j*rng.normal(size=sites))*np.exp(-1j*t*np.arange(sites)**2)
      cc=sum((f*bx for f,bx in zip(ff,bb)),np.zeros_like(b,dtype=complex))
      pp=project(cut);norm2=float(np.vdot(ff,ff).real)
      cr=op(cc@pp)**2;an=op(cc.conj().T@pp)**2
      cb=norm2*gamma(cut+2);ab=norm2*gamma(cut)
      assert cr<=cb+1e-9 and an<=ab+1e-9
      if cb:ratios.append(cr/cb)
      if ab:ratios.append(an/ab)
      if cut==0:wrongpad.append(cr)
      energy_cases+=1
assert min(noncomm)>0 and min(wrongpad)>0
emit('energy_compressions_noncommuting_cyclic_spins',cases=energy_cases,max_bound_ratio=max(ratios),lowering_translate_commutator_norms=noncomm,unpadded_creator_bound_is_zero_on_vacuum=True,min_actual_vacuum_creator_norm_squared=min(wrongpad),precision='float64 eigen/singular-value comparisons, tolerance 1e-9')

# Exact local hard-core lowerings distinguish mixed kernels from repeated powers.
a=np.array([[0,1],[0,0]],dtype=np.int64)
a0=np.kron(a,np.eye(2,dtype=np.int64));a1=np.kron(np.eye(2,dtype=np.int64),a)
assert np.count_nonzero(a0@a0)==0 and np.count_nonzero(a0@a1)==1
emit('mixed_kernel_boundary',single_square_zero=True,mixed_product_nonzero_entries=int(np.count_nonzero(a0@a1)),exact=True)

# Independent occupation-polynomial representation of bosonic products.
def polynomial(vectors,modes):
  result={(0,)*modes:1}
  for vec in vectors:
    nxt=defaultdict(int)
    for occ,coeff in result.items():
      for j,weight in enumerate(vec):
        oo=list(occ);oo[j]+=1;nxt[tuple(oo)]+=coeff*int(weight)
    result=dict(nxt)
  return result
fcases=0; norm_mut=[]
for n in range(0,7):
  for mode in [2,3,4]:
    vv=rng.integers(-2,3,size=(n,mode));ww=rng.integers(-2,3,size=(n,mode))
    vp=polynomial(vv,mode);wp=polynomial(ww,mode)
    actual=sum(coeff*wp.get(occ,0)*math.prod(math.factorial(k) for k in occ) for occ,coeff in vp.items())
    gram=vv@ww.T
    permanent=sum(math.prod(int(gram[i,p[i]]) for i in range(n)) for p in itertools.permutations(range(n)))
    assert actual==permanent
    if n>=2:norm_mut.append(abs(actual-math.factorial(n)*permanent))
    fcases+=1
assert max(norm_mut)>0
emit('Fock_occupation_polynomial_vs_permanent',cases=fcases,exact=True,extra_factorial_max_residual=max(norm_mut))

# Scope safeguard: isometric W+ and W- do not imply isometric W+*W-.
wout=np.array([[1.],[0.]]);win=np.array([[0.],[1.]])
assert np.array_equal(wout.T@wout,np.eye(1)) and np.array_equal(win.T@win,np.eye(1))
assert np.array_equal(wout.T@win,np.zeros((1,1)))
emit('two_isometries_scope',individual_isometries=True,composition_norm=op(wout.T@win),exact=True,limit='This is a Hilbert-space scope counterexample, not a lattice scattering model.')
emit('limits',analytic_scattering_proved_by_controls=False,exhaustive_over_theorem_domain=False,independent_analytic_evidence='RECONSTRUCTION.md')
