# Independent review of compact-patch scattering and covariance

**Disposition:** the finite-packet conditional theorem is mathematically supported under its stated S1–S4. One narrow downstream wording repair is required before the note is reused as a self-contained source: make the additional unique-vacuum and positive-gap setting explicit around (EX). This is not an audit verdict, retained status, Fock-isometry result, completeness result, or N1 certification.

**Frozen source:** `COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md`, 404 lines, SHA-256 `d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`. The source was not edited. Full reconstruction, source copies, exact reading coverage, controls, and receipts are in `compact_scattering_review/`.

## Required narrow repair

At **lines 384–392**, the note calls (EX) the assessment's exhaustion condition but uses m without defining it in S1–S4. These hypotheses do not require either a unique vacuum vector or a positive gap above it. The assessment supplies that additional setting; it must be explicit where its criterion is reused.

A sufficient replacement introduction is:

> In the assessment's additional unique-vacuum and positive-gap setting, let m>0 satisfy E_H({0})=|Omega><Omega| and spec(H) subset {0} union [m,infinity). For the full constructed scattering span, including the vacuum and all required channels, the open downstream target is (EX).

After (EX), state that only in this additional setting does it express full-GNS completeness, and that S1–S4 alone neither supply the gap edge nor establish that interpretation. Preserve all existing exclusions and the fact that EX remains unproved. This is a wording/scope fix to the downstream target, not a missing premise in the compact scattering proof.

The separate exact spectral check in `EX_BOUNDARY_CHECK.md` shows the issue: (EX) can miss either positive-energy vectors below its cutoff or additional zero-energy vectors. It also proves the claimed equivalence after the missing spectral conditions are supplied. The examples are not lattice models or counterexamples to S1–S4.

## Load-bearing mathematical findings

- **Joint-filter locality, §§3–4:** the successive conditional expectations and parameter truncation give the stated polynomial prefactor times an exponentially small local error plus a Schwartz tail. No exponential moment of the kernel is used. Time differentiation translates an L1 kernel and is a norm derivative; every derivative remains almost local. Fixed microscopic flows preserve this class by a separate local-approximation/LR estimate.
- **Selection and signs, §§2,4–5:** joint H/K calculus gives exactly h(K)E_M A Omega; it does not confuse geometric momentum with continuous momentum. The finite character average is a projector only on the stipulated finite-order mass component. Its negative character weight is consistent with T_x=exp(-ix.Q), V_j phase exp(+i theta.j), and Q=k-theta. The +itH clock cancels the packet's -it Sigma clock, with both derivative terms required.
- **Commutators and Cook estimate, §6:** the common equal-time dynamics cancel exactly in commutator norms. The near-collar term is O(T^(2d-N)); both packet tails and both derivative pieces are included in (25). The exact derivative contains all i<k pairs and n-2 further factors in their original relative order. Their norms change the power to dn-N. N=dn+2 gives the stated integrable bound for each fixed finite n. The n=0, n=1 and negative-time cases are covered. The explicit loose constant (22) is sufficient.
- **Creator independence, §7:** the cutoff refinement is valid on the fixed dispersion charts. The discarded packet has velocity support contained in the original packet's velocity support, kills the vacuum exactly, and has rapidly decaying commutators with the other original/refined factors. No unsupported small-norm assertion is used. This justifies original-to-refined comparison before using refined-to-alternative cross-compatibility. Zero one-particle data give a zero product limit.
- **Covariance, §8:** the transformed local seed need not be local. The note correctly uses the invariant direct-property class of creators, rather than asserting closure of the local-seed subclass. The transformed creators retain almost locality, time smoothness, and exact graph support. Finite-time conjugation and bounded-unitary passage through the established limits prove (29); creator independence and scaling give the centre product phase and V_j^q=1 on the constructed closed span.

There is no invocation of BDN Theorem 4.8 with an unverified Definition 4.4 hypothesis. The note reconstructs the portion of its proof needing the directly established creator properties. BDN's stronger geometric transfer-isolation condition may fail here without invalidating this Cook argument.

## Primary-source and control verification

The complete argument was reconstructed before inspecting the author-control source, outputs, or receipt. `RECONSTRUCTION.md` was frozen at 2026-10-11 23:34:26 UTC, SHA-256 `6bf05b705a3bfda8f2469aa86fff6bd13d3e0827495ce8ea2408f61c91ee4fcc`. The target's own §9 control descriptions were visible during that initial read and were not accepted as evidence.

The exact BDN v2 PDF was checked at SHA-256 `3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126`. Complete pages 7–23 and 40–43 were read, covering the relevant statements, hypotheses, and proofs: LR and local approximants; almost locality; mass-shell/creator definitions; both packet derivatives; commutator and full Cook proofs; and the additional hypotheses and mechanisms used for Fock inner products and extension. A fresh pypdf extraction matched every inspected page text. No coverage of the remaining pages is claimed.

The author receipt `23a9f9aa165a1b88183b07ab7f5234c5b3294bbfdbd526a3fd475f5752bf3059` and all 81 bound artifact hashes/lengths matched. The complete algebra-control source, execution metadata, nine-record stdout and empty stderr, assumption/trace/status documents, literature/coverage documents, source identities, covariance-class diff, and search logs were inspected. The old index-evidence inventory is context-only; this review does not recertify its 521 unrelated bindings.

The exact author control was rerun after the reconstruction freeze, with a 60-second timeout. It exited 0 in about 0.64 seconds and reproduced stdout/stderr byte-for-byte. Its character tests, free noncommutative word reduction and negative mutations are meaningful for their finite algebraic targets. The packet energy table deliberately encodes the chosen graph: its clock check verifies convention consistency, not mass-shell existence. The power-count test is arithmetic. None tests analytic localization, full scattering, or physical realization. Reproduction of the author's code is not an independent implementation.

## Exact safe scope and unresolved obligations

The supported result is a dense one-particle creator construction on each supplied nonzero mass/centre/open patch and strong incoming/outgoing limits for admissible finite families of velocity-separated packets. Those limits are symmetric and depend only on their one-particle vectors within the fixed charts; V acts by the corresponding product action. A common q therefore gives V_j^q=1 on the closed span of the constructed states and vacuum.

This does **not** prove that multiparticle limits are nonzero; give their inner products; define an isometric or continuous Fock wave operator; extend to arbitrary nonseparated data or inequivalent charts; exhaust all required species or channels; establish (EX); prove a full-algebra shift identity; or derive the supplied microscopic implementations, isolated masses, rational centres, or physical framework. The separately proposed Fock extension was not inspected or used as a premise of this review.

The assessment at `cb512af29397a3a6e8c58161bbe1dd6c15e61944b5f8bdd9ae0c1a0cc53c2536` was read completely. N1 was read completely; the necessary B1-U and M1-T3 contexts were read directly at the supplied hashes recorded in `initial_sources.json`. Their unrelated arguments and status labels were not certified. No additional original scientific input from those reports is needed once S1–S4 are stated explicitly.

## Provenance and recovery

The review used the inherited model/reasoning configuration without overrides or subdelegation. The parent supplied a bounded brief, load-bearing questions, and prior suggestions concerning parameter truncation, equal-time cancellation, cutoff comparison, and the transformed-seed class; these shared contributions are not represented as independent discoveries. Applicable instructions were read from main `a13caa4885f547c8d206265b031ba7649e539fd9` and planning `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; the parent had rechecked those remote identities at 23:29 UTC. The review independently checked the corresponding local refs and exact source bytes, not another remote fetch.

Only this review and `compact_scattering_review/` were written. The repository, frozen author note, author evidence, earlier assessment/reviews, editable prompts, and platform instructions were not modified. No PR, publication, audit, axiom, other-chat, or unrelated-science action occurred. Fixed campaign deadline: 2026-10-12 16:00:52 UTC. A later narrow correction needs affected-source confirmation; this review does not pre-approve unseen edits.
