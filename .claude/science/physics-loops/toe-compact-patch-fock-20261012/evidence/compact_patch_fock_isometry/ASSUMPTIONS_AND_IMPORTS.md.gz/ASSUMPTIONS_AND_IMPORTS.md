# Assumptions and imports

This is a conditional Fock-isometry theorem for selected particles. No physical axiom or framework primitive is adopted.

| Premise or mechanism | Source/class | Role and current status |
|---|---|---|
| Microscopic H and P/beta implementations, strong commutation, geometric translations and invariant vacuum | Supplied CP S1; N1 H-loc/H-int setting | Needed by the provisional creator construction. Formal current sums or Lie brackets alone do not supply the microscopic implementation. |
| Nonzero isolated positive mass-Casimir components | Supplied CP S2; selected N1 section 1.3 setting | Needed for exact joint filters. Vacuum gap does not prove their existence or isolation. |
| Common finite-order centre action on selected components | Supplied CP S3; rational-centre condition in N1 section 2.2 | Needed for exact finite centre selection. No global V^q identity is assumed. |
| Compact charts, smooth packet data and internal velocity separation | CP S4, mathematical domain restriction | Initial dense packet domain. The Fock extension is obtained by the new density and Gram arguments. |
| Unique vacuum vector and positive gap on all Omega-perpendicular states | Added relative to CP; already explicit in N1 H-gap | Supplies NS/BDN exponential clustering. Translation-invariant-state uniqueness alone is insufficient. |
| Compact positive temporal transfer | Derived from CP joint filter and centre average | Enables the energy-kernel estimate and uniform bounds for creators, adjoints and finite words on bounded energy. |
| Regular Hessian | Derived from the exact massive dispersion | Supplies stationary-phase bounds on each compact chart. |
| Momentum absolute continuity and distinct-velocity tensor density | Derived in the new note section 6 | Not silently imported from BDN's globally isolated geometric-shell setting. |
| BDN regular-shell proof and NS clustering theorem | Primary mathematical imports with checked hypotheses | Proof mechanisms are reused/adapted, not claimed as novel or as physical derivations. |
| Fock-isometry result | New bounded author implication; independent review pending | The preceding compact-patch review did not cover it. Root proposed the route and is a contributor. |
| Full-GNS exhaustion, all-channel coverage and boost covariance | Separate unresolved obligations | Not asserted by this theorem or imported as premises. |

The primitive registry and relevant instruction bodies were already read at the unchanged checked main revision and are bound in INSTRUCTION_REUSE.json. None of the units, kinetic-isotropy or realized-state primitives supplies these dynamical/spectral conditions. There is no new primitive or axiom action.
