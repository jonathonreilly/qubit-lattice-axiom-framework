# Primary literature bridge

BDN: Bachmann–Dybalski–Naaijkens, arXiv:1412.2970v2. NS: Nachtergaele–Sims, arXiv:0712.3318v1. Exact PDFs, extracted pages, source identities and reading coverage are preserved here.

| Source | Exact use | Hypothesis check |
|---|---|---|
| BDN Proposition 3.6 and Theorem 3.11; Lemma 4.5(c) | Compact energy transfer and energy-restricted packet bounds | The filter has temporal transfer in [epsilon,L], epsilon>0; torus momentum is compact. Almost-local commutators are summable. A complete finite-sum kernel induction is written in the new note, including mixed translated products and energy padding. No geometric shell isolation enters. |
| NS Theorem 4.1 and full proof; BDN Theorem 2.4 | Exponential clustering with explicit sufficient constants | Finite-range bounded H interaction has finite NS norm. Unique ground vector and positive gap are stated explicitly. Centering B gives both ground-projection annihilation conditions. |
| BDN Proposition 4.3 | Regular stationary phase and packet l1/sup estimates | Exact massive dispersion has positive Hessian determinant on every compact lift. |
| BDN Lemmas 4.6(b),4.7(b) | Double commutators and scalar contraction of creator-adjoint pairs | Velocity partition is performed through each third packet's own dispersion. Four-point clustering proof permits different mass/centre charts. |
| BDN Theorem 4.9, regular case | Permanent Gram recursion and particle-number orthogonality | Uniform energy-restricted finite-word bounds control the O(t^(-d/2)) error; polynomial operator bounds alone would not. |
| BDN Theorem 4.13, wave-operator part; Lemmas 4.15–4.19 | Isometric extension and dense distinct-velocity tensor domain | Local one-particle density is supplied by the joint H/K filter, not by global geometric isolation. Momentum absolute continuity is reconstructed from vacuum annihilation and almost locality. The exact mixed-mass velocity maps are injective, so the coincidence sets are null. |

The original Buchholz 1990 article was not obtained or represented as fully read. BDN is the primary lattice theorem; the needed finite-sum argument is explicitly reconstructed. A failed Project Euclid access attempt did not become evidence. No theorem about an isometric or unitary S-matrix is imported from wave-operator isometry alone.
