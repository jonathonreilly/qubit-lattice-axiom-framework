# Trace and next independent check

trace_class: upstream_support
source_target: The compact-patch report explicitly leaves Fock inner products and an isometric extension separate.
reachability_to_target: partially_closes
artifact_role: theorem
next_trace_action: Independently reconstruct the finite-energy kernel estimate, regular mixed-chart contraction, double-commutator recursion, absolute-continuity argument and Fock-density extension before substantial reuse.

The new theorem conditionally supplies Fock wave-operator isometries over the selected isolated mass/centre components. It does not supply full-GNS exhaustion, coverage of every channel, the full Poincare/boost representation on scattering states, or the full-algebra shift identity. Its trace to the N1 reduction therefore remains partial.
