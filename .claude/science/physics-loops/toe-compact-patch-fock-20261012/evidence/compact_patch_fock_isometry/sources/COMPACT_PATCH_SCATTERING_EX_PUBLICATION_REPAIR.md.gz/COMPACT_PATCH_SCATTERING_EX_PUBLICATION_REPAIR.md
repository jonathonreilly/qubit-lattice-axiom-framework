# Proposed exact downstream-scope repair

This changes only the EX discussion in the frozen compact-patch source
d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a.
S1–S4 and the construction/covariance theorem remain unchanged.

Replace the sentence immediately before EX with:

In the assessment's separate vacuum setting, assume additionally
\(E_H(\{0\})=|\Omega\rangle\langle\Omega|\) and
\(\operatorname{spec}(H)\subset\{0\}\cup[m,\infty)\), with \(m>0\).
Let \(P_{\rm sc}\) project onto the closed span of all relevant constructed
scattering states over all needed patches, including \(\Omega\). The
downstream exhaustion condition in that setting is

Keep the displayed EX formula unchanged.

Replace the paragraph immediately following EX with:

With those additional spectral assumptions, (EX) expresses full-GNS
completeness: the spectral cutoffs \(\mathbf1_{[m,E]}(H)\) tend strongly
to \(1-|\Omega\rangle\langle\Omega|\) as \(E\to\infty\), and the local
vectors \(A\Omega\) are dense. This equivalence is not asserted from
S1–S4 alone. Neither (27), one-particle density, nor (29) proves (EX).
The present theorem also does not prove that all finite-energy excitations
belong to isolated mass components, that the common rational denominator
exists, or that the supplied continuous generators are microscopic
implementations.
