"""Verify and stage the complete Fock extension at its frozen source identities."""
from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys

S = Path(__file__).resolve().parent
W = S.parent/'scattering_worktree'
P = W/'.claude/science/physics-loops/toe-compact-patch-fock-20261012'
BASE = '7f4c1a23d1acb7bec85a6aabc78addd2fc70cb00'
os.chdir(W)
sys.path.insert(0, str(W/'scripts'))
import runner_cache
sha = lambda b: hashlib.sha256(b).hexdigest()
m = json.loads((P/'PUBLICATION_EDITS.json').read_text())
primary = W/m['outputs'][1]['publication_path']
body = primary.read_text()
mutants = json.loads((S/'fock_primary_mutations/manifest.json').read_text())
assert mutants['primary_sha256'] == sha(primary.read_bytes())
assert len(mutants['runs']) == 8
baseline = (S/'compact_fock_review/logs/author_rerun.stdout.jsonl').read_text().splitlines()
for r in mutants['runs']:
    d = S/'fock_primary_mutations'
    v = (d/(r['name']+'.py')).read_text()
    assert body.count(r['before']) == 1 and v == body.replace(r['before'], r['after'])
    assert sha(v.encode()) == r['source_sha256']
    out, err = (d/(r['name']+'.stdout')).read_bytes(), (d/(r['name']+'.stderr')).read_bytes()
    assert sha(out) == r['stdout_sha256'] and sha(err) == r['stderr_sha256']
    assert out.decode().splitlines() == baseline[:len(out.decode().splitlines())]
    assert r['exit_code'] == 1 and not r['timed_out'] and r['intended_failure']
    assert r['expected_assertion'] in err.decode() and err.decode().splitlines()[-1].startswith('AssertionError')
    assert r['elapsed_seconds'] < r['timeout_seconds'] == 60
execution = json.loads((S/'fock_canonical_execution.json').read_text())
assert execution['status'] == 'ok' and execution['exit_code'] == 0 and execution['stderr'] == ''
assert execution['stdout'].startswith((S/'compact_fock_review/logs/author_rerun.stdout.jsonl').read_text())
graph = W/'docs/audit/data/citation_graph_manifest.json'
old = json.loads(subprocess.check_output(['git', 'show', BASE+':'+str(graph.relative_to(W))]))
new = json.loads(graph.read_text())
assert (new['node_count'], new['edge_count']) == (old['node_count']+1, old['edge_count']+1)
assert all(new['nodes'][k] == v for k, v in old['nodes'].items())
assert set(new['nodes'])-set(old['nodes']) == {'compact_patch_fock_isometry_bounded_theorem_note_2026-10-12'}
assert new['nodes']['compact_patch_fock_isometry_bounded_theorem_note_2026-10-12']['out_degree'] == 1
compat = json.loads((S/'fock_focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []

(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Root source and composition check

The full326-line author proof, source helper and all nine output records were
read. Root then read the complete separate review,320-line reconstruction,
evidence assessment, independent control source and all seven output records.
The complete original BDN/NS pages needed by root are listed in the literature
ledger; original-source reading and dependency hypotheses were also checked
by the separate reviewer. All92 author and195 reviewer artifact bindings
match. The complete changed publication prose is represented by explicit
source edits; no analytic equation or proof step is changed.

The core proof points are uniform energy-restricted creation/annihilation
bounds, the common kernel of all mixed lowering products, the massive Hessian,
clustering of connected commutator pairs, the complete Gram recursion and
spectral absolute continuity followed by separated-tensor density. Every
remaining factor in a contraction error is controlled by the uniform vacuum
word bound. No cross-family separation, global geometric shell isolation,
onto property or boost covariance is inserted.

Eight complete publication-primary copies contain the declared single defects
and fail at the intended assertions. Every traceback was read and preceding
stdout is an exact prefix of the fully read baseline. Their count is not an
analytic proof. The independent matrix controls have their stated finite
scope; the author normalization enumeration is bookkeeping, while the written
Gram recursion proves unequal-number orthogonality. Root contributed the
regular-shell route and is not its independent reviewer.

The earlier scattering note, primary, cache and milestone packet remain
byte-identical to7f4c1a23. This new packet records the extension; its checkpoint
is a milestone snapshot, not a competing live campaign state. No editable
prompt, physical axiom, audit verdict, retained status or main branch changes.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped delivery verification

The canonical primary exited0 in{execution['elapsed_sec']:.9f}s under its
declared60s timeout; stderr is empty. All nine original output records are
byte-identical to the fully read author baseline. Explicit resolution/scope
lines follow them. The note and upstream scattering note are declared inputs;
cache/source identities are fresh and runtime versions are in the cache header.

Eight actual complete-primary defects are detected: omitted double brackets,
energy-commutator sign, radial Hessian sign, Hessian determinant power,
velocity inverse beta factor, creator output-energy padding, collapsed mixed
kernel, and a missing sup factor in the arithmetic contraction count. Complete
sources, commands, timeout records, stdout and stderr are preserved. They do
not certify analytic estimates, continuum dynamics or physical hypotheses.
No Lean check is claimed. The initial cache API call used an unsupported
keyword and raised TypeError before executing the primary; the corrected
positional call above is the one completed canonical execution.
An initial link scan parsed a bare spectral interval as a Markdown link;
inline-code formatting repaired only that snapshot-queue presentation.
The first staged whitespace check exposed trailing padding and blank lines
inherited from the frozen author note. Two explicit presentation-only edits
repair them. The canonical cache was refreshed for the changed note identity;
the control source and its finite results are unchanged.

Citation topology adds one Fock node and its one intended dependency on the
compact scattering node: {new['node_count']} nodes,{new['edge_count']} edges.
Every older manifest node is unchanged. Focused changed-audit-evidence
compatibility selected no applied rows and reported no failures. The global
combined audit pipeline and strict audit lint were not run. They remain
independent landing gates, with no fabricated pass or applied audit change.

Vocabulary fix/report, exact complete-note/primary reconstruction, Python
syntax, ordinary local links, source/evidence identities, cache freshness and
the exact intended staged set are checked before commit. Only the permitted
citation manifest is included from audit data. Third-party reference bytes
stay external; the packet binds their official URLs and exact identities.
''')
(P/'REVIEW_HISTORY.md').write_text((P/'REVIEW_HISTORY.md').read_text().split('\n## Publication conformance by section\n', 1)[0]+'''
## Publication conformance by section

1. Self-containment: full proof, supplied hypotheses, upstream note, evidence
   roles and exact source maps are present in the same PR.
2. Cache/execution: declared60s canonical execution completed with fresh inputs.
3. Claim scope: bounded_theorem and conditional-support are separate fields;
   selected components, supplied premises and absent conclusions are explicit.
4. Negative claims: no no-go/retained negative claim is proposed. Invalid
   shortcuts are proof controls, so a no-go packet PASS is inapplicable.
5. Proof obligations: energy, contraction, recursion and density received a
   complete source check. Full-GNS exhaustion/boost covariance remain open.
6. Runner validity: finite symbolic/matrix evidence and actual primary defects
   are scoped honestly; no finite controls are promoted to analytic proof.
7. Packet: complete goals, imports, approaches, status, trace, review, evidence
   and recovery are supplied; one live campaign checkpoint remains elsewhere.
8. Links/graph: ordinary local links checked; one intended node/edge acknowledged.
9. Note: definitions, hypotheses, primary-source matches, proof and limits
   are complete; all publication edits are explicit and reconstructible.
10. Authority: no audit verdict, retained status, main push, merge or global weave.
11. Sourcing/counts: exact source/control bindings support the stated counts.
    No empirical fit, observed target or confidence interval applies.
12. Pre-review gates: selective reconstruction, canonical execution, mutations,
    vocabulary, cache/source identity, graph and focused compatibility are
    complete. Global pipeline and strict audit lint remain unrun landing gates.
''')
state = P/'STATE.yaml'
state.write_text(state.read_text().replace('pr_status: preparing_extension_to_regular_PR9486', 'pr_status: reviewed_extension_for_regular_PR9486').replace(
    'next_action: canonical_controls_and_delivery_checks_then_update_PR9486', 'next_action: publish_extension_then_continue_constructive_exhaustion'))
editable = sorted(P.glob('*.md'))+[W/r['publication_path'] for r in m['outputs']]+[P/'reconstruct.py']
for mode in ['fix', 'report-only']:
    target = S/('fock_final_vocab_'+mode)
    r = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--'+mode, '--report-path', str(target.with_suffix('.json'))]+
                       [str(p.relative_to(W)) for p in editable], capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout+r.stderr)
    assert r.returncode == 0
r = subprocess.run([sys.executable, str(P/'reconstruct.py')], capture_output=True)
(S/'fock_final_reconstruction.log').write_bytes(r.stdout+r.stderr)
assert r.returncode == 0
ast.parse(primary.read_text())
assert runner_cache.cache_status(str(primary.relative_to(W))) == runner_cache.cache_identity_status(str(primary.relative_to(W))) == 'fresh'
links = []
for path in editable:
    if path.suffix != '.md':
        continue
    prose, fenced = [], False
    for line in path.read_text().splitlines():
        if line.lstrip().startswith('```'):
            fenced = not fenced
            continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for target in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        assert (path.parent/unquote(target.split('#', 1)[0])).resolve().exists(), (path, target)
        links.append(dict(source=str(path.relative_to(W)), target=target))
emap = json.loads((P/'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}


def preserve(src):
    b = src.read_bytes()
    dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(b, mtime=0)
    if dst.exists() and dst.read_bytes() != packed:
        previous = rows.pop(str(dst.relative_to(P)))
        prior = dst.with_name(dst.stem+'.previous_'+previous['sha256'][:12]+dst.suffix)
        assert not prior.exists() or prior.read_bytes() == dst.read_bytes()
        if prior.exists():
            dst.unlink()
        else:
            dst.rename(prior)
        previous['preserved'] = str(prior.relative_to(P))
        previous['historical_source_version'] = True
        rows[previous['preserved']] = previous
    dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = dict(original=str(src), preserved=rel, sha256=sha(b), bytes=len(b))


for src in sorted((S/'fock_primary_mutations').iterdir()):
    preserve(src)
for name in ['prepare_fock_publication.py', 'run_fock_primary_mutants.py', 'finish_fock_delivery.py',
             'fock_canonical_execution.json', 'fock_focused_audit_compat.json', 'fock_focused_audit_compat.stderr',
             'fock_citation_execution.json', 'fock_citation_build.stdout', 'fock_citation_build.stderr',
             'fock_citation_manifest.stdout', 'fock_citation_manifest.stderr',
             'fock_initial_vocab_fix.json', 'fock_initial_vocab_fix.log', 'fock_initial_reconstruction.log',
             'fock_final_vocab_fix.json', 'fock_final_vocab_fix.log', 'fock_final_vocab_report-only.json',
             'fock_final_vocab_report-only.log', 'fock_final_reconstruction.log']:
    preserve(S/name)
for r in rows.values():
    b = gzip.decompress((P/r['preserved']).read_bytes())
    assert sha(b) == r['sha256'] and len(b) == r['bytes']
for r in emap['external_reference_sources']:
    b = Path(r['original']).read_bytes()
    assert sha(b) == r['sha256'] and len(b) == r['bytes']
mechanical = dict(note_and_primary_reconstructed=True, whole_primary_mutants=8,
    preserved_evidence_files=len(rows), external_reference_identities=len(emap['external_reference_sources']),
    citation_delta=dict(nodes=1, edges=1), old_graph_nodes_unchanged=True,
    cache_and_inputs_fresh=True, ordinary_links=links,
    scope='Mechanical checks plus the source reviews identified separately; no audit verdict.')
out = S/'fock_delivery_mechanical.json'
out.write_text(json.dumps(mechanical, indent=2)+'\n')
preserve(out)
emap['files'] = [rows[k] for k in sorted(rows)]
(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2)+'\n')
files = [W/r['publication_path'] for r in m['outputs']]+[graph, runner_cache.cache_path_for(str(primary.relative_to(W)))]+[
    p for p in P.rglob('*') if p.is_file() and p != P/'SOURCE_IDENTITIES.json']
ident = []
for path in sorted(set(files)):
    row = dict(path=str(path.relative_to(W)), sha256=sha(path.read_bytes()))
    if path.suffix == '.gz':
        row['decompressed_sha256'] = sha(gzip.decompress(path.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,
    scope='Every intended extension file except this manifest itself.', files=ident), indent=2)+'\n')
paths = [r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git', 'add', '--']+paths, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for row in ident:
    assert sha(subprocess.check_output(['git', 'show', ':'+row['path']])) == row['sha256']
staged = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().split('\0'))-{''}
assert staged == set(paths)
assert not subprocess.check_output(['git', 'diff', '--name-only'])
final = dict(staged_files=len(paths), staged_hashes_match=True, whitespace_clean=True, **mechanical)
(S/'fock_final_staged_verification.json').write_text(json.dumps(final, indent=2)+'\n')
print(json.dumps(final))
