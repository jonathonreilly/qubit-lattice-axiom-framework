"""Compose the reviewed Fock extension without altering the frozen SC milestone."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

S = Path(__file__).resolve().parent
W = S.parent / 'scattering_worktree'
P = W / '.claude/science/physics-loops/toe-compact-patch-fock-20261012'
BASE = '7f4c1a23d1acb7bec85a6aabc78addd2fc70cb00'
assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip() == BASE
assert not subprocess.check_output(['git', '-C', str(W), 'status', '--porcelain'])
P.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
note_path = 'docs/COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md'
primary_path = 'scripts/compact_patch_fock_isometry_2026_10_12.py'
source = S / 'COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md'
raw = source.read_text()
assert sha(raw.encode()) == '9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404'
edits = []


def edit(before, after, reason):
    global raw
    assert raw.count(before) == 1, (before, raw.count(before))
    edits.append(dict(before=before, after=after, reason=reason))
    raw = raw.replace(before, after)


edit('# Compact-patch Fock inner products and isometric wave operators', '''---
claim_id: compact_patch_fock_isometry_bounded_theorem_note_2026-10-12
claim_type: bounded_theorem
claim_scope: "Under the compact-patch construction's supplied conditions and a unique gapped vacuum, selected mass/centre components have permanent scattering Gram matrices and covariant isometric Fock embeddings. Full-GNS exhaustion and boost covariance remain open."
upstream_dependencies:
  - compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11
runner: scripts/compact_patch_fock_isometry_2026_10_12.py
actual_current_surface_status: conditional-support
---

# Compact-patch Fock inner products and isometric wave operators''',
     'Add explicit conditional claim metadata and the actual scientific dependency.')
edit('**Author status:** conditional support, independent review pending.',
     '**Status:** conditional-support; complete source review found no required correction.',
     'Record the completed selective source review, without audit or retained status.')
edit('[COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md)',
     '[compact-patch construction](COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md), whose complete frozen author source is preserved in its publication packet',
     'Make the full upstream theorem available in the same PR; preserve the original source identity below.')
edit('Its own claim labels are not proof inputs. No Y1/RZ or other changed science is certified.',
     'Its bytes were also verified unchanged at PR9476 revision `0cc560e3935fa1ad7623592bf9974680c922d52d`. Its own claim labels are not proof inputs. No Y1/RZ, RV4 or other changed science is certified.',
     'Record the latest completed identity-only refresh without adopting concurrent science.')
edit('- The present Fock proof needs its own independent reconstruction, particularly the energy restriction, mixed-chart contraction, recursion and density steps.',
     '- The complete Fock proof received a separate reconstruction of the energy restriction, mixed-chart contraction, full recursion and density steps. The review found no required correction; this is a source check, not an applied audit verdict or retained status.',
     'Replace the now-completed review obligation with its actual scope and result.')
edit('The source ledger, complete primary texts, declared-timeout author checks, full outputs and freeze receipt are in compact_patch_fock_isometry/. The checks concern algebra and finite-dimensional controls; they do not turn this author derivation into independent review or supply any physical premise.',
     'The [Fock milestone packet](../.claude/science/physics-loops/toe-compact-patch-fock-20261012/) preserves the complete original note, source ledger, author checks, full outputs, separate review and pre-author-control reconstruction. PUBLICATION_EDITS.json and reconstruct.py recover this publication from those frozen sources. Complete third-party papers and page extractions remain in the external research directory, with exact hashes and official URLs in EVIDENCE_MAP.json. The finite controls concern algebra; they do not supply a physical premise or replace the analytic proof.',
     'Provide self-contained original research evidence while keeping primary papers external.')
edit('A single execution of check_fock_algebra.py used a declared 60-second timeout',
     'The original author execution of the [finite Fock control](../scripts/compact_patch_fock_isometry_2026_10_12.py) used a declared 60-second timeout',
     'Link the actual preserved control and distinguish its author execution from publication replay.')
edit('No earlier compact-patch control was rerun or treated as a proof of these new claims. These are author controls, not independent reconstruction. Stationary phase, clustering, spectral density and the Hilbert-space extension require the written proofs and checked primary hypotheses.',
     'No earlier compact-patch control was treated as a proof of these new claims. These author controls are distinct from the independent reconstruction. The separate review is `bc88af1dda77065d8806da9d689546547f40847a340177086793dab5f3a277cf`; its pre-author-control reconstruction is `85f4d93458c6f00ede645e6d2ac272084dc0cd053b66801b25db8574586df484`, frozen before the reviewer opened the author source, logs or receipt. The reviewer reconstructed the complete analytic argument and checked the original BDN and NS hypotheses/proofs. Separately written finite matrix and occupation-polynomial controls checked the algebra. The later exact author rerun reproduced its output; that rerun is reproduction, not an independent implementation. Root proposed the regular-shell route and is a contributor. Stationary phase, clustering, spectral density and the Hilbert-space extension rest on the written proofs and checked primary hypotheses. No Lean verification, full-GNS completeness, physical realization or retained status is claimed. Publication execution and its exact limits are in DELIVERY_CHECKS.md in the milestone packet.',
     'Record the completed independent analytic check and distinguish each evidence role.')
edit('\\boxed{\\ \n', '\\boxed{\n', 'Remove trailing presentation-only TeX padding; formulas and proof are unchanged.')
tail = raw[-180:]
edit(tail, tail.rstrip()+'\n', 'Normalize only end-of-file blank lines.')
(W / note_path).write_text(raw)
outputs = [dict(kind='note', source_path=str(source), source_sha256=sha(source.read_bytes()),
                preserved_source='evidence/COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md.gz', edits=edits,
                appended_text='', publication_path=note_path, publication_sha256=sha(raw.encode()))]

src = S / 'compact_patch_fock_isometry/check_fock_algebra.py'
original = src.read_text()
assert sha(original.encode()) == 'c46a7d3ebef131324caf477a12ea25e9e57a47a0b86c408e7234ebc644822fdc'
before = 'from collections import Counter\n'
after = '''AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = [
    "docs/COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md",
    "docs/COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]
if not __debug__:
    raise RuntimeError("Run without -O: exact control assertions must be enabled")

from collections import Counter
'''
assert original.count(before) == 1
suffix = '''
print("per_element: exact noncommutative word and symbolic Hessian identities checked")
print("per_site: exact finite cyclic hard-core energy bounds for one to three sites checked")
print("per_mode: exact velocity inverse formulas and mixed-mass overlap fixture checked")
print("per_block: complete finite-word recursion checked; normalization enumeration is bookkeeping only")
print("lattice_wide: checked and not executed — clustering, spectral density and Fock extension are analytic proof obligations")
print("TOTAL: PASS=9 FAIL=0")
print("SCOPE: nine finite control records; no analytic Fock proof, physical realization, full-GNS exhaustion or audit verdict from this runner")
'''
body = original.replace(before, after) + suffix
(W / primary_path).write_text(body)
outputs.append(dict(kind='primary', source_path=str(src), source_sha256=sha(src.read_bytes()),
                    preserved_source='evidence/compact_patch_fock_isometry/check_fock_algebra.py.gz',
                    edits=[dict(before=before, after=after, reason='Declare timeout and source inputs; reject optimized assertions; control body unchanged.')],
                    appended_text=suffix, publication_path=primary_path, publication_sha256=sha(body.encode())))
(P / 'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=outputs), indent=2) + '\n')

texts = {
'STATE.yaml': '''loop: toe-compact-patch-fock-20261012
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-compact-patch-scattering-20261011
base_revision: 7f4c1a23d1acb7bec85a6aabc78addd2fc70cb00
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: selected_component_Fock_isometry
provisional_dependency: supplied_compact_scattering_S1_through_S4_and_F1_unique_gapped_vacuum
independent_check: complete_separate_reconstruction_no_required_correction
strongest_unresolved_obligation: constructive_full_GNS_exhaustion
pr_status: preparing_extension_to_regular_PR9486
next_action: canonical_controls_and_delivery_checks_then_update_PR9486
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md': '''# Exact extension contract

Given the same PR's conditional compact-packet construction and a unique
gapped vacuum, prove the permanent Gram formula for finite internally
velocity-separated families, including different masses, centres and charts.
Prove density and the well-defined isometric Fock extensions with translation
and centre covariance. Full-GNS completeness and boost covariance are separate.
''',
'ASSUMPTIONS_AND_IMPORTS.md': '''# Premises and dependency map

The upstream compact scattering note supplies S1–S4: microscopic commuting
H and K flows, isolated positive Casimir mass components, finite-order centre
action on those components, and separated compact charts. Its complete proof
and reviewed EX repair are in the same PR at pre-extension revision7f4c1a23.
Its conditional status and every supplied physical premise are inherited.

F1 adds kerH=C Omega and a positive gap on all Omega-perp. N1's actual H-gap
clause supplies this in its proposed setting; the Fock theorem does not derive
that physical setting. BDN's transfer, energy-bound and regular-shell proof
machinery and NS's clustering proof are checked with their exact hypotheses.
Geometric shell isolation is replaced by proved direct creator properties.
Momentum absolute continuity, velocity-diagonal nullity and Fock density are
derived. Selected components need not include every physical channel.
''',
'APPROACH_REGISTRY.md': '''# Mathematical approach families

1. Temporal transfer and common mixed lowering kernels give a uniform energy
   bound; no commutativity of lowering translates is assumed.
2. Massive Hessian regularity and clustering give mixed-chart contraction.
3. Uniform finite-energy vacuum-word bounds preserve contraction decay after
   all remaining factors. Double commutators give the complete Gram recursion.
4. Rapid commutators imply spectral absolute continuity. The explicit massive
   velocity diffeomorphism makes pairwise equal-velocity diagonals null.
5. Dense separated tensor boxes and the Gram identity give the unique Fock
   isometries and covariance. No onto inference is made.

The pseudo-relativistic shell route is unused. Full-GNS exhaustion requires
additional constructive propagation/channel control and remains open.
''',
'ROUTE_PORTFOLIO.md': '''# Evidence roles

The full analytic note is the theorem artifact. The author runner checks
finite word identities, differentiated formulas and finite energy matrices.
Its rectangular normalization branch encodes unequal-number vanishing and
is only bookkeeping. The independent reviewer froze its complete analytic
reconstruction before opening author code, then wrote matrix/occupation
controls. Its later author rerun is reproduction, not independent code.
Root proposed the regular-shell route and is a contributor. The selected
model and reasoning effort were preserved. No formal Lean claim is made.
''',
'OPPORTUNITY_QUEUE.md': '''# Next scientific decision

The isometric Fock construction now has a complete focused source check.
The high-leverage remaining condition is full-GNS exhaustion by all needed
scattering channels: for every local A and finite E, the complementary
projection of `1_[m,E](H)A Omega` must vanish. Evaluate a constructive detector
or propagation estimate against the actual microscopic hypotheses. An
isometry or abstract spectator Hilbert space does not settle that condition.
''',
'NO_GO_LEDGER.md': '''# Preserved invalid shortcuts

All mixed-product kernels cannot be replaced by powers of one lowering
operator. The creator's output-energy padding cannot be omitted. Different
masses do not guarantee distinct velocities. Full operator-norm estimates
for remaining factors lose the decay needed by the Gram recursion. Two
isometries alone do not make their scattering-matrix composition isometric.
These are proof-boundary controls, not lattice no-go theorems or N-gate claims.
''',
'LITERATURE_BRIDGES.md': '''# Checked primary imports

[BDN1412.2970v2](https://arxiv.org/abs/1412.2970v2), PDF
3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126:
the reviewer read complete pages7–24 and39–43 for transfer, energy bounds,
regular contraction, full Gram recursion and Fock density. Root's necessary
primary reads cover pages7,8,14–24 and39–43; the complete new proof and
independent reconstruction were read by root.

[Nachtergaele–Sims0712.3318v1](https://arxiv.org/abs/0712.3318v1), PDF
74829f87cc51d399613043a3abdc48ba3146c81292a09e4df1035b50eb464b5c:
pages3–4 and9–12 were read for interaction assumptions and the complete
clustering argument. No novelty claim is made for imported machinery.
Primary PDF/text bytes remain external with official URLs and exact hashes.
Unread primary pages and unrelated N1 science are not certified.
''',
'ARTIFACT_PLAN.md': '''# Coherent PR extension

Add one complete Fock theorem and its finite control to the existing regular
compact-scattering PR9486. Keep the original scattering note, cache, source
maps and milestone snapshot unchanged. Preserve both original author and
review evidence and an exact publication map. This closes the Fock extension
obligation within the supplied setting; it does not close completeness.
''',
'TRACE_GATE.md': '''# Reachability to the constructive scattering premise

```yaml
trace_class: upstream_support
target_claim_id: null
target_blocker_text: "That convergence step is assumed, not proved"
source_of_blocker_text: user_goal
source_location: "C4_M1_report.md line234, fb2d6b5f54fcff8680219dce5f903d6620e5f987d4f093462502dc3e600b1b2b"
reachability_to_target: partially_closes
artifact_role: theorem
next_trace_action: "Prove finite-energy exhaustion for all required channels under checked microscopic hypotheses."
```

The direct consumer is N1's constructive scattering/covariance premise.
The predecessor constructs finite packet limits; this extension establishes
their permanent inner products and well-defined selected-component Fock
isometries. It does not retire the entire premise, prove boosts or establish
the full-algebra shift identity. All physical premises remain supplied.
''',
'CLAIM_STATUS_CERTIFICATE.md': '''# Conditional mathematical status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: upstream_support
reachability_to_target: partially_closes
conditional_surface_status: "Fock isometries for selected mass/centre components under SC S1–S4 and F1."
hypothetical_axiom_status: null
admitted_observation_status: null
independent_review_status: "Complete separate source reconstruction; no required correction."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

No physical axiom, global status, applied audit verdict or retained status is
changed. No Lean verification is claimed. Independent audit remains distinct
from this selective mathematical source check.
''',
'REVIEW_HISTORY.md': '''# Completed focused source review

Frozen author note9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404.
Reviewbc88af1dda77065d8806da9d689546547f40847a340177086793dab5f3a277cf;
receiptd5549ee3c35f54a90aaa40aaa5e3aa608d6f1d32ede8844adf58808ad657b3f0.
Pre-author-control reconstruction85f4d93458c6f00ede645e6d2ac272084dc0cd053b66801b25db8574586df484
was frozen2026-10-12 00:00:56 UTC. The reviewer found no required correction.
Root read the full proof, complete review/reconstruction/evidence assessment,
independent control source and complete outputs. All92 author and195 review
artifact bindings match; those counts establish identity, not proof quality.

The exact proof remains unchanged in publication. Edits add claim metadata,
portable upstream links, the latest checked N1 identity, completed review and
recovery descriptions. Publication conformance is recorded after its checks.
''',
'HANDOFF.md': '''# Fock milestone snapshot

This is an extension of regular PR9486 on the same coherent scattering branch.
The prior snapshot at7f4c1a23d1acb7bec85a6aabc78addd2fc70cb00 remains intact.
The live campaign checkpoint stays in the transport worktree at
toe-dynamics-bridge-20261009. Fixed deadline2026-10-12 16:00:52 UTC.

The source-bound separate review supports the selected-component permanent
Gram formula, Fock isometries and translation/centre covariance. It does not
prove full-GNS exhaustion, all channels, boosts, microscopic realization,
full N1 obstruction or an isometric/unitary S-matrix. Global audit pipeline
and strict audit lint are unrun independent landing gates, not passed checks.
No science merge, main push, applied audit or physical-axiom edit is made.

EVIDENCE_MAP.json recovers authored source and review bytes. Third-party
papers remain external with URL/hash bindings. PUBLICATION_EDITS.json and
reconstruct.py verify the whole note and control. No editable prompt or
platform instruction changed. Continue the exhaustion probe after delivery.
''',
'PR_BACKLOG.md': '''# Extend regular PR9486

The complete focused review supports this coherent Fock extension of the
compact-packet construction already in PR9486. Add it to that regular PR
after canonical execution, actual control mutations, citation acknowledgment
and source-bound publication conformance. No duplicate or draft PR is needed.
Full-GNS completeness and boost covariance remain explicit open obligations.
'''
}
for name, text in texts.items():
    (P / name).write_text(text)

paths = [source, S/'COMPACT_PATCH_FOCK_ISOMETRY_REVIEW.md',
         S/'Fock_author_root_identity_check.json', S/'Fock_review_root_identity_check.json']
for folder in ['compact_patch_fock_isometry', 'compact_fock_review']:
    paths.extend(p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
rows, refs = [], []
for src in sorted(set(paths)):
    b = src.read_bytes()
    row = dict(original=str(src), bytes=len(b), sha256=sha(b))
    is_paper = src.suffix == '.pdf' or any(part in ['BDN_pages', 'NS_pages', 'BDN_1412.2970v2_pages', 'NS_0712.3318v1_pages'] for part in src.parts) or src.name in ['BDN_fulltext.txt', 'NS_fulltext.txt', 'BDN_1412.2970v2_extracted.txt', 'NS_0712.3318v1_extracted.txt']
    if is_paper:
        row.update(primary_url='https://arxiv.org/pdf/0712.3318v1' if any('NS' in part for part in src.parts) else 'https://arxiv.org/pdf/1412.2970v2',
                   recovery='Exact primary reference remains external; not redistributed in this PR.')
        refs.append(row)
    else:
        dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(gzip.compress(b, mtime=0))
        row['preserved'] = str(dst.relative_to(P))
        rows.append(row)
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Lossless authored/repository evidence and external primary reference identities.',
    files=rows, external_reference_sources=refs), indent=2)+'\n')
(P/'reconstruct.py').write_text('''from pathlib import Path
import gzip, hashlib, json
P = Path(__file__).resolve().parent
W = P.parents[3]
for row in json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']:
    b = gzip.decompress((P/row['preserved_source']).read_bytes())
    assert hashlib.sha256(b).hexdigest() == row['source_sha256']
    t = b.decode()
    for edit in row['edits']:
        assert t.count(edit['before']) == 1
        t = t.replace(edit['before'], edit['after'])
    t += row['appended_text']
    assert (W/row['publication_path']).read_text() == t
    assert hashlib.sha256(t.encode()).hexdigest() == row['publication_sha256']
print('Complete Fock note and primary reconstruct exactly from frozen sources and explicit edits')
''')
print(json.dumps(dict(note_sha256=sha((W/note_path).read_bytes()), primary_sha256=sha((W/primary_path).read_bytes()),
                     own_evidence_files=len(rows), external_reference_bindings=len(refs))))
