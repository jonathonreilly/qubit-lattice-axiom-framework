"""Actual complete-primary perturbations of load-bearing finite controls."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
W = S.parent/'scattering_worktree'
P = W/'scripts/compact_patch_fock_isometry_2026_10_12.py'
D = S/'fock_primary_mutations'
D.mkdir(exist_ok=False)
body = P.read_text()
sha = lambda b: hashlib.sha256(b).hexdigest()
baseline = (S/'compact_fock_review/logs/author_rerun.stdout.jsonl').read_text().splitlines()
cases = [
    ('dropped_double_brackets', 'rhs=add(rhs,term); double_terms=add(double_terms,term)',
     'rhs=add(rhs,scale(0,term)); double_terms=add(double_terms,term)', 'assert lhs==rhs,(n,lhs,rhs)'),
    ('energy_commutator_sign', 'comm(a[i],ad[j])', 'scale(-1,comm(a[i],ad[j]))', 'assert mul(q,q)==add(first,second)'),
    ('hessian_radial_sign', 'expected=(beta/E)*s.eye(d)-(beta**2/E**3)*s.Matrix(k)*s.Matrix(k).T',
     'expected=(beta/E)*s.eye(d)+(beta**2/E**3)*s.Matrix(k)*s.Matrix(k).T', 'assert all(s.simplify(x)==0 for x in H-expected)'),
    ('hessian_determinant_power', 'det=s.factor(H.det())', 'det=s.factor(E*H.det())',
     'assert s.simplify(det-beta**d*M*M/E**(d+2))==0'),
    ('velocity_inverse_beta', 'denom=s.sqrt(beta)*s.sqrt(beta-r2)', 'denom=s.sqrt(beta-r2)',
     'assert s.simplify(Epos**2-(M*M+beta*sum(x*x for x in k)))==0'),
    ('creator_energy_padding', 'creator=(R+1)*f2*s.eye(len(ids))-(C.T*C).extract(ids,ids)',
     'creator=R*f2*s.eye(len(ids))-(C.T*C).extract(ids,ids)', 'assert all_principal_minors_nonnegative(creator)'),
    ('collapsed_mixed_kernel', 'a1=T*a*T', 'a1=a', 'assert a*a==s.zeros(2) and a*a1!=s.zeros(2)'),
    ('contraction_missing_sup_factor', 'squared=s.Rational(d,2)-3*s.Rational(d,2)',
     'squared=s.Rational(d,2)-2*s.Rational(d,2)', 'assert squared==-d'),
]


def run(case):
    name, before, after, expected = case
    assert body.count(before) == 1
    source = body.replace(before, after)
    path = D/(name+'.py')
    path.write_text(source)
    start = time.monotonic()
    command = [sys.executable, str(path)]
    timed_out = False
    try:
        r = subprocess.run(command, cwd=W, capture_output=True, timeout=60)
        out, err, rc = r.stdout, r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out, err, rc = e.stdout or b'', e.stderr or b'', None
        timed_out = True
    (D/(name+'.stdout')).write_bytes(out)
    (D/(name+'.stderr')).write_bytes(err)
    lines = out.decode().splitlines()
    row = dict(name=name, before=before, after=after, expected_assertion=expected,
               source_sha256=sha(source.encode()), command=command,
               utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               elapsed_seconds=time.monotonic()-start, timeout_seconds=60,
               exit_code=rc, timed_out=timed_out, stdout_sha256=sha(out),
               stderr_sha256=sha(err), stdout_is_baseline_prefix=lines==baseline[:len(lines)],
               intended_failure=rc==1 and expected in err.decode() and err.decode().splitlines()[-1].startswith('AssertionError'))
    (D/(name+'.execution.json')).write_text(json.dumps(row, indent=2)+'\n')
    return row


with ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(run, cases))
(D/'manifest.json').write_text(json.dumps(dict(primary=str(P), primary_sha256=sha(P.read_bytes()), runs=rows), indent=2)+'\n')
assert all(r['intended_failure'] and r['stdout_is_baseline_prefix'] and not r['timed_out'] for r in rows)
print(json.dumps(dict(complete_primary_mutants=len(rows), intended_failures=len(rows), source_sha256=sha(P.read_bytes()))))
