# Literature bridge

Primary: [Bachmann–Dybalski–Naaijkens, arXiv:1412.2970v2](https://arxiv.org/abs/1412.2970v2); downloaded PDF SHA-256 `3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126`.

| Exact source item | Role | Import class | Effect |
|---|---|---|---|
| Theorem 2.1; Corollary 2.2; Appendix C, especially (C.7) | Microscopic LR dynamics and local approximants | Literature theorem | Supplies the bound used in the multi-flow cutoff derivation. |
| Definition 3.8, Lemma 3.9, Theorem 3.10 | Almost locality | Literature theorem/proof mechanism | Establishes the correct topology and the fixed-flow/commutator machinery. |
| Definition 4.1; Definition 4.4 | Hypothesis comparison | Background and scope check | Geometric shell isolation and geometric Arveson-transfer isolation are not established by the new joint filter and are not assumed silently. |
| Proposition 4.3 | Packet l1 bounds and tails | Literature theorem with proof reconstruction | Smooth compact supports on charts satisfy the needed hypotheses. |
| Lemmas 4.5(a,b,d), 4.6(a), Theorem 4.8 | Finite-product existence and comparison | Literature proof mechanism | Reconstructed from directly checked creator properties, with explicit constants and both derivative terms. |
| Theorems 4.9 and 4.13 | Fock/isometry scope | Background only | Stronger conclusions are deliberately not adopted from the finite-product proof. |

The source is used as a mathematical scattering and locality bridge; it does not provide derivation closure for the microscopic physical premises or for full-GNS completeness. Its proof is not redescribed as novel. The new packet realizes the needed creator properties by a joint current/energy filter and a finite centre average.

Complete reading coverage: PDF pages 7–23 and 40–43. Those include the standing assumptions, definitions and complete Cook proof. Page texts were extracted with pypdf 6.11.0; all 46 are preserved for recovery, but unread pages are not certified.
