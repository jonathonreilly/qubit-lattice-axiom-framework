# Separate analytic check of the exhaustion boundary

This check addresses the one remaining logical uncertainty: whether the displayed condition (EX), with an unspecified positive m, characterizes full Hilbert-space exhaustion under the compact theorem's S1–S4 alone. It is independent of the author's centre/clock/product-control code. It is a spectral implication test, not a proposed lattice model or a counterexample satisfying S1–S4.

Take a three-dimensional Hilbert space with basis e_0,e_1,e_2, Omega=e_0, m=1, and P=diag(1,0,1).

1. If H=diag(0,1/2,2), then for every finite E, `(1-P)1_[1,E](H)=0`, but `(1-P)e_1=e_1`. A unique vacuum does not help when the named lower cutoff omits positive spectrum.
2. If H=diag(0,0,2), the same equality holds for every finite E, and the vacuum is included in Ran P, but e_1 is an omitted zero-energy vector. A positive gap above the ground eigenspace does not help when that eigenspace is larger than the chosen vacuum line.

For either example the operator equality implies EX for every A and every cyclic collection A Omega. Hence cyclicity alone cannot fix either omission. These are exact diagonal matrix calculations; no numeric tolerance or simulation is needed.

Conversely, suppose `E_H({0})=|Omega><Omega|`, `spec(H) subset {0} union [m,infinity)` for some m>0, and P is an orthogonal projection fixing Omega. For any local A, spectral convergence as E tends to infinity gives

`1_[m,E](H) A Omega -> A Omega - Omega <Omega,A Omega>`.

If EX holds, continuity of 1-P and P Omega=Omega give `(1-P)A Omega=0`. Cyclicity of local observables implies P=1. The converse is immediate. No commutation of P with H is needed for this density argument.

Thus the precise repair is to declare this additional spectral/vacuum setting when interpreting EX as completeness. It must not be added retroactively as a premise of the compact Cook theorem, which does not use it. The original frozen source's affected lines are 384–392. The provisional line reference in RECONSTRUCTION.md is superseded by this verified range; the frozen reconstruction is otherwise unchanged.
