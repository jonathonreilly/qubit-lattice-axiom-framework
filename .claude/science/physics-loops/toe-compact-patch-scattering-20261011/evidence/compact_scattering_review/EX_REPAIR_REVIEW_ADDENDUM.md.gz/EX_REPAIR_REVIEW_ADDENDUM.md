# Focused confirmation of the EX wording repair

**Disposition: the exact proposed replacement resolves the sole finding in the frozen review. No remaining issue was found in this edit.**

Reviewed in full: `COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md`, SHA-256 `d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`. It replaces only the sentence before and paragraph after (EX), retaining the displayed formula. This confirmation is bound to the original 404-line probe at `d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a` and review at `924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be`.

The added unique-vacuum identity and spectrum containment with m>0 imply that `1_[m,E](H)` converges strongly to `1-|Omega><Omega|`. The explicitly included vacuum gives `P_sc Omega=Omega`. Thus (EX) implies `(1-P_sc)A Omega=0` for every local A, and local cyclicity gives `P_sc=1`; the converse is immediate. Commutation of P_sc with H is not needed. This verifies the stated completeness equivalence with exactly the additional assumptions the edit supplies.

The edit correctly treats these as separate downstream assumptions, leaves S1–S4 and the compact construction/covariance theorem unchanged, and preserves the exclusions concerning EX, isolated mass components, rational centres, and microscopic implementations. It does not assert that EX holds, establish nonzero multiparticle limits or a Fock isometry, or upgrade any physical or audit status.

This addendum closes the wording finding for the reviewed replacement and supersedes the pending-repair entry in the original review checkpoint only to that extent. The proposed repair, original theorem, frozen review, and original review receipt remain unchanged. The reviewer did not apply the publication edit or make Git changes. No unchanged analytic check, author control, or unrelated Fock extension was rerun or assessed. Confirmation covers this exact replacement; other publication changes are outside its scope.

Only this addendum, a recovery copy of the proposed replacement, and `ex_repair_review_receipt.json` were written. Model/reasoning remained inherited; no subdelegation, prompt edits, PR, audit, or external publication action occurred. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.
