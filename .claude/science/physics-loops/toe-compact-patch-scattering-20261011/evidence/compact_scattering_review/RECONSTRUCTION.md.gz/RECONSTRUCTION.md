# Reconstruction frozen before author-control inspection

This reconstruction concerns only `COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md`, SHA-256 `d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`. The complete target, complete assessment, all of N1, necessary B1-U context (lines 1–107), M1-T3 context (lines 210–265), and BDN PDF pages 7–23 and 40–43 have been read. The paper page texts were independently extracted from the hash-bound PDF with pypdf and matched. No author-control source, output, execution receipt, or package receipt has been inspected at this freeze. The target itself describes its controls in §9; that description was necessarily visible but is not evidence here.

The parent supplied the intended pressure points and suggested parameter truncation, equal-time cancellation, and the transformed-seed class issue. Those are shared contributions, not independent findings. I reconstructed the mathematical implications below directly from the frozen sources. No subdelegation, model override, publication, or audit occurred.

## Exact conditional target and obligation graph

For each finite family of ordinary almost-local observable creators whose compact Fourier packet supports lie on specified smooth dispersion charts and have pairwise disjoint velocity images, prove norm convergence of their products on the vacuum as time tends to either infinity, permutation symmetry, dependence only on the represented one-particle vectors within those fixed charts, and covariance under each fixed commutant unitary V_j. Construct at least a dense class of single-particle creators on a nonzero selected mass/centre/patch component from local seeds.

The supplied conditions are actual bounded finite-range microscopic flows for H and K=P/beta; their commuting, vacuum-preserving implementations; H nonnegative; an isolated nonzero positive mass-squared eigenvalue of H²-beta|K|²; finite-order V on each selected mass component with a common q; and separated compact packet supports on single lifts. S1–S4 are conditional mathematical hypotheses, not derived framework axioms. Poincaré integration, uniqueness of the ground vector, a global positive H-gap, and full scattering completeness are not used in this compact theorem.

The acyclic chain is:

1. Microscopic LR estimates -> joint-filter almost locality and norm time derivatives.
2. Joint spectral calculus + isolated mass -> exact vacuum vector on the mass graph.
3. Finite-order V on that mass component -> exact centre selection there.
4. Geometric Fourier packets + selected graph -> constant one-particle vectors.
5. Almost locality + geometric packet velocity separation -> rapid equal-time commutators.
6. Leibniz rule + each differentiated creator kills the vacuum -> integrable full n-product derivative.
7. Telescoping differences + admissible cutoffs -> fixed-chart creator independence.
8. Fixed-time microscopic action of V -> closure of the direct-property creator class -> covariance and product character.

No step requires geometric energy–momentum transfer isolation of the BDN Definition 4.4 type. No step gives multiparticle nonzero norms, Fock inner products, Fock-space continuity, or full-GNS density.

## 1. Multi-flow localization

BDN Theorem 2.1 and Appendix C give, for any finite support X, an error at radius r bounded by (4||F||/C_lambda)|X|||A|| exp[-lambda(r-v|u|)]. The constants in target (7)–(8) agree with BDN (2.12)–(2.14), (C.5)–(C.7); replacing each finite-range interaction norm by J/F_lambda(range) is a valid upper bound. Choose one common maximum speed and minimum localization exponent for the finitely many supplied flows.

For m=d+1 flows, apply each flow to the preceding local approximant and conditionally expect onto X^(ell r/m). Each support gains r/m. Within |z|_1 <= r/[2m(1+v)], every flow time obeys v|z_ell| <= r/(2m), so the difference of available radius and LR spread is at least r/(2m). Contractivity prevents previous errors from being amplified. The support-cardinality upper bound |X|(2r+3)^d is adequate. Summing m errors gives (10).

The integral of those approximants lies in the finite-dimensional algebra of X^r. Outside the truncated parameter region use ||alpha_s rho_y(A)||=||A||, not an LR estimate with growing time prefactor. Thus

`error <= constant * r^d exp[-lambda r/(2m)] ||g||_1 + ||A|| integral_{|z|_1>ar}|g(z)| dz`.

For every desired N the second term is bounded by `(1+ar)^(-N) integral (1+|z|_1)^N |g(z)| dz`; it is finite for every Schwartz g. This establishes all polynomial orders without an exponential moment. Translating the kernel in its s variable gives the norm derivative with kernel -partial_s g, and every derivative is again Schwartz.

To verify the transformed creator class separately: approximate an almost-local A in a ball of radius r/2, evolve for a fixed u, and approximate the evolved approximant in a ball of radius r. The error is bounded by an arbitrary polynomial tail plus `O(r^d exp[-lambda(r/2-v|u|)])`. Fixed translations only change the required ball radius by a constant. Applying finitely many such maps proves fixed nu_j preserves almost locality, without requiring its transformed seed to be local. Commutation with alpha_t preserves each norm time derivative.

## 2. Spectral selection and signs

On a vacuum vector, alpha_s rho_y(A) acts as `exp(iHs-iK.y)A Omega`. The inverse transform chosen in (13) therefore gives G(H,K)A Omega with no extra sign or beta. Isolation gives eta(C)=E_M, and H>=0 with M>0 makes H equal to the positive square root on this component. Since chi is one on the energies over supp h, (14) follows exactly. Adjoint conjugation replaces G(E,k) by conjugate G(-E,-k), whose energy support is strictly negative; hence B_g(A)^* Omega=0. Compact positive temporal transfer follows from temporal Fourier convolution of the smearing and does not require geometric transfer isolation.

The identity `V_j=exp(i j.K)T_j` with `T_j=exp(-i j.Q)` gives `V_j=exp(i j.(K-Q))`; the character exp(i theta.j) therefore implies Q=k-theta modulo 2pi. This checks the lift and clock conventions independently of N1's opposite label convention.

Only on the mass component does V factor through (Z/qZ)^d. There its q^d character sum with negative weight is an orthogonal joint character projection. On B_g(A)Omega that is sufficient; no global operator-average idempotency is used. The finite sum preserves almost locality and vacuum annihilation of adjoints. Cyclicity and bounded smooth spectral cutoffs supply density on the selected nonzero open patch, not density of multiparticle states.

## 3. Packet and derivative bounds

Fourier inversion gives

`C_t(B,f)Omega = exp(itH) exp[-it Sigma(Q)] fhat(Q)B Omega`.

The vector has support on H=Sigma(Q), so it equals psi at every t. On compact time intervals all spatial Fourier coefficients and their time derivatives decay to arbitrary order; the norm-convergent sums can be differentiated. The derivative is the sum of the operator derivative delta_H B and the differentiated amplitude -i Sigma fhat. Each term separately has nonzero vacuum action in general; their sum kills Omega. The proof differentiates the uncut packet, so no moving spatial-cutoff derivative is missing.

The BDN Proposition 4.3 proof of its weaker bounds (4.4) uses only smooth compact momentum amplitudes. Away from the velocity collar, |x-t grad Sigma| is bounded below by a constant times |x|+|t|. Integration by parts to arbitrarily high order, followed by a lattice sum, gives every negative power for the tail. The compact collar has O((1+|t|)^d) points. These estimates apply equally to the differentiated amplitude and to t<0. The stronger stationary-phase bound and Hessian nondegeneracy are not used.

## 4. Equal-time commutators and full Cook estimate

For almost-local A,B, conditional-expectation approximants in radius |z|/3 commute when shifted by z. At |z|>=3 the approximation errors give a constant no larger than `2*3^N*(epsilon_N(A)||B||+||A||epsilon_N(B))` times (1+|z|)^(-N). At |z|<3 the trivial 2||A||||B|| bound is absorbed by 2*7^N||A||||B||. Thus the deliberately loose constant (22) is safe.

The exact isometric automorphism identity is

`[alpha_t tau_x(A),alpha_t tau_y(B)] = alpha_t tau_x([A,tau_(y-x)(B)])`.

Physical time consequently contributes no LR exponential. Separate each packet into collar and tail. Collar positions have |x-y|>=delta|t|>=delta(1+|t|)/2, giving the `kappa_N K L_i L_k T^(2d-N)` contribution. Use one full packet against the other's tail and one collar packet against the remaining tail; this covers the tail-tail pair without a missing term. Their bounds are `2 b_i b_k (R_i L_k + L_i R_k)T^(d-N)`, no greater than the target's T^(2d-N) envelope. Summing the two derivative pieces yields exactly (25).

The unreduced derivative has n Leibniz terms. Its exact vacuum reduction is

`sum_(i<k) C_1 ... C_(i-1) C_(i+1) ... C_(k-1) [D_i,C_k] C_(k+1) ... C_n Omega`.

All n-2 other factors retain their relative order. Their norm bound is T^(d(n-2)), so the total power is 2d-N+d(n-2)=dn-N. N=dn+2 makes it integrable, with integral from t_1 to infinity equal to 1/(1+t_1). There is no restriction on any fixed finite n, nor a claimed uniform n-bound. n=1 is constant and n=0 is the vacuum. Adjacent swaps follow from the same estimate without a derivative. This reconstruction is the analytic proof; a finite algebraic control could check ordering and signs but could not prove its localization premises.

## 5. Creator independence and cutoff removal

For cross-compatible original/alternative supports, telescope the product difference. Each difference kills Omega, and commuting it right leaves only rapidly decaying pair commutators times polynomially bounded factors. Their limits agree.

For two separately separated families on fixed charts, let S_i be the compact spectral support of their common psi_i. It lies in both Fourier supports. Since each family is separately separated and the chart/dispersion for label i is unchanged, grad Sigma_i(S_i) is separated from every other label's original and alternative velocity support. Compactness supplies positive separation and a smooth h_i equal to one around S_i with sufficiently narrow velocity image.

The discarded packet has amplitude `(1-h_i)fhat_i`, and hence velocity support inside the original support for label i. It kills Omega exactly. It need not have small norm. Every other original/refined first-family factor remains supported in its own original velocity set, so commuting the discarded packet right in the telescoped difference is legitimate and leaves errors that vanish after the same polynomial power count. Thus refinement preserves the original limit. Refined versus alternative families are cross-compatible, completing the comparison. If psi_i=0, commute the whole factor right; the limit is zero. This proof does not identify arbitrary nonseparated tensors or inequivalent dispersion assignments.

## 6. Covariance and stopping point

The direct-property creator class consists of almost-local operators with the needed almost-local norm time derivatives and exact vacuum-vector graph support. S1–S3 ensure nu_j preserves this class, all graph subspaces and the vacuum, and commutes with the smearing flows. The local-seed subclass need not be invariant; no argument requires it to be. At each finite t conjugation gives (28) exactly. The fixed bounded V_j passes through the already proved strong limit. Fixed-chart creator independence identifies the resulting vector with the notation on the right side of (29).

Scaling a creator by its centre character scales its one-particle vector and its product limit. Apply creator independence to compare this scaling with nu_j(B). Hence (30) follows without a global Fock operator. V_j^q fixes the vacuum and all constructed limits and therefore their closed linear span. This does not establish that any multiparticle limit with n>=2 is nonzero, even when all one-particle vectors are nonzero.

BDN Theorem 4.9 has an extra vacuum-factorization step, Lemma 4.7, and uses either small geometric transfer/pseudo-relativistic support or regular dispersion plus clustering and a bounded-energy operator estimate. BDN Theorem 4.13 further uses (4.33), spectral absolute continuity, and density of separated configurations. These conclusions are not supplied by the compact Cook proof and have not been imported here.

## Finding before control inspection

The compact theorem is supported by the reconstructed proof. A narrow downstream wording repair is needed around target lines 373–382: (EX) uses m without S1–S4 defining a unique vacuum or a positive H-gap. To call it a full-GNS exhaustion criterion, explicitly restore the assessment's additional hypothesis `ker H=C Omega` and `spec(H)|_(Omega perp) subset [m,infinity)` with m>0. The full scattering span must include Omega and all required channels. Under that extra condition, finite-energy local vectors plus Omega are dense and EX forces P_sc=1. Without it, EX could omit low-energy or additional zero-energy vectors. This does not affect the compact theorem or justify adding the gap assumption to its proof.

No counterexample to the compact theorem under its stated assumptions was found. No assertion of model realization, formal retained status, full N1 certification, global shift/current-flow equality, Fock isometry, or exhaustion follows.
