# Assumptions and imports

Claim: conditional finite-packet scattering construction and V_j covariance in `../COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md`. This is not a derivation from the framework's minimal axioms or an adoption of any physical premise.

| Item | Class | Exact role and current status |
|---|---|---|
| S1 microscopic H and P/beta flows, their strong commutation, invariant vacuum | Supplied physical/mathematical setting | N1 H-loc/H-int implementation is made explicit. Formal generators are insufficient; this identification is not proved here. |
| S2 isolated positive mass-Casimir eigenspace | Supplied spectral condition | Enables exact compact joint H/K filtering. Vacuum gap alone does not imply this condition. |
| S3 commutant V and common finite order on selected mass components | Supplied condition | Implements finite centre selection without assuming V^q=1 globally. Rational centres remain unproved as a physical necessity. |
| S4 compact charts and disjoint packet velocities | Admitted mathematical data | Restricts the finite products covered by the theorem. No uniform limit as separation vanishes is taken. |
| BDN LR bound and local approximants, almost-local commutators, packet estimates, Cook argument | Literature theorem/proof mechanism | Exact items and primary-page coverage appear in LITERATURE_BRIDGES.md and the probe. Finite-range hypotheses are checked; the stronger geometric isolation premise is not imported. |
| Fourier, time and centre signs | Explicit conventions | H evolution uses +itH, current flow -iy.P/beta, geometric T=exp(-ix.Q), V phase exp(+i theta.j), hence Q=k-theta. |
| Full-GNS exhaustion EX | Open downstream obligation, not a premise of this theorem | Neither finite-product existence nor covariance proves it. It is equivalent to the remaining completeness target in the named gapped setting. |
| Fock isometry/extension to all tensor data | Separate unproved result | No inference from polynomial packet norms or Cook convergence is made. |

The primitive registry at main a13caa4885f547c8d206265b031ba7649e539fd9 was read. None of the scale-reference, kinetic-isotropy or realized-state primitives supplies or enters the conditions above. No primitive is added, reclassified as an import, or used to close a dynamical premise.

Counterfactual checks: without mass isolation the displayed smooth filter need not be an exact shell selector; without an exact centre selector the geometric packet can contain several dispersions; without microscopic flow implementation the LR localization proof is unavailable; without velocity separation the stated Cook estimate does not follow. These are limits of this construction, not no-go results for alternative scattering theories. The failed exponential-moment estimate is preserved in the probe and replaced by a parameter cutoff plus a Schwartz-tail estimate.
