"""Check the exact scattering publication and stage only its intended paths."""
from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys

S = Path(__file__).resolve().parent
W = S.parent/'scattering_worktree'
P = W/'.claude/science/physics-loops/toe-compact-patch-scattering-20261011'
BASE = 'a13caa4885f547c8d206265b031ba7649e539fd9'
os.chdir(W)
sys.path.insert(0, str(W/'scripts'))
import runner_cache
sha = lambda b: hashlib.sha256(b).hexdigest()
m = json.loads((P/'PUBLICATION_EDITS.json').read_text())
primary = W/m['outputs'][1]['publication_path']
body = primary.read_text()
mutants = json.loads((S/'scattering_primary_mutations/manifest.json').read_text())
assert mutants['primary_sha256'] == sha(primary.read_bytes())
assert len(mutants['runs']) == 8
baseline = (S/'compact_patch_scattering/clock_and_product.stdout.jsonl').read_text().splitlines()
for r in mutants['runs']:
    d = S/'scattering_primary_mutations'
    v = (d/(r['name']+'.py')).read_text()
    assert body.count(r['before']) == 1 and v == body.replace(r['before'], r['after'])
    assert sha(v.encode()) == r['source_sha256']
    out, err = (d/(r['name']+'.stdout')).read_bytes(), (d/(r['name']+'.stderr')).read_bytes()
    assert sha(out) == r['stdout_sha256'] and sha(err) == r['stderr_sha256']
    assert out.decode().splitlines() == baseline[:len(out.decode().splitlines())]
    assert r['exit_code'] == 1 and not r['timed_out'] and r['intended_failure']
    assert r['expected_assertion'] in err.decode() and err.decode().splitlines()[-1] == 'AssertionError'
    assert r['elapsed_seconds'] < r['timeout_seconds'] == 60

execution = json.loads((S/'scattering_canonical_execution.json').read_text())
assert execution['status'] == 'ok' and execution['exit_code'] == 0 and execution['stderr'] == ''
assert execution['stdout'].startswith((S/'compact_patch_scattering/clock_and_product.stdout.jsonl').read_text())
graph = W/'docs/audit/data/citation_graph_manifest.json'
old = json.loads(subprocess.check_output(['git', 'show', BASE+':'+str(graph.relative_to(W))]))
new = json.loads(graph.read_text())
assert (new['node_count'], new['edge_count']) == (old['node_count']+1, old['edge_count'])
assert all(new['nodes'][k] == v for k, v in old['nodes'].items())
assert set(new['nodes'])-set(old['nodes']) == {'compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11'}
compat = json.loads((S/'scattering_focused_audit_compat.json').read_text())
assert compat['checked'] == compat['failures'] == compat['control_failures'] == []
ex = json.loads((S/'compact_scattering_review/ex_repair_review_receipt.json').read_text())
for r in ex['inputs']+[ex['addendum'], ex['recovery_copy']]:
    b = Path(r['path']).read_bytes()
    assert sha(b) == r['sha256'] and len(b) == r['bytes']

(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Full source and publication review

Root read the complete402-line candidate and the complete two-line admissible-
class amendment, then the final404-line source's changed text. The analytic
scope includes joint-flow localization, mass and centre selection, signs,
every product derivative, fixed-chart creator independence and V covariance.
Root read the necessary primary BDN pages7,8,14–21,41,42 and later the full
independent review, pre-control reconstruction, EX boundary check and exact
EX replacement/addendum. Original source, review and repair identities are
listed in REVIEW_HISTORY.md and preserved without later alteration.

The author helper and all nine output records were read in full. The separate
reviewer's rerun matched those records; it is reproduction, not a second
implementation. Root checked all81 author and76 review artifact bindings,
plus all six exact EX-repair bindings. The full publication primary's eight
source-copy variants each differ in the single declared place and fail at
the intended assertion. All traceback text was read; every prior stdout is
an exact prefix of the fully read baseline. These are finite algebra controls,
not proofs of almost locality, strong scattering limits or physical premises.

The publication map changes metadata, reviewed status, source recovery and
the exact downstream EX correction. S1–S4 and the analytic construction proof
are otherwise unchanged. The corrected EX discussion supplies a unique vacuum
and positive gap only for its completeness equivalence; it does not prove EX.
Source-to-publication reconstruction is exact for both note and runner.

All new publication prose was reviewed. The snapshot records the source
check and its limits without adopting a Fock extension, full-GNS exhaustion,
N1 obstruction, physical axiom, applied audit or retained status. Root
contributed to creator-comparison and covariance clarifications and is not
the independent reviewer. No editable prompt files were changed. Full third-
party paper/text bytes remain outside the PR, with official URL and hashes.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped delivery verification

The canonical publication primary exited0 in {execution['elapsed_sec']:.9f}s
under its declared60s timeout, with empty stderr. All nine original JSON
records are byte-identical to the fully read author baseline, followed by
explicit resolution and scope statements. The note is a declared input and
its cache/source identities are fresh. Python and dependency versions remain
recorded in the canonical cache header.

Eight actual complete-primary mutations failed at the intended assertions:
character weight, the spectrum in the non-global projection witness, omitted
Cook pair, commutator sign, geometric centre sign, packet clock sign, double
beta division and the final Cook power. Full source copies, commands, timeouts,
outputs and hashes are preserved. No analytic or audit conclusion follows
from their count. No Lean verification was run.

The citation manifest contains {new['node_count']} nodes and {new['edge_count']}
edges: one intended new theorem node, no new edges and no changed older nodes.
Focused changed-audit-evidence compatibility selected no applied rows and
reported no failures. The global combined audit pipeline and strict audit
lint were not run; they remain separate landing gates. No result is fabricated
for them and no applied audit surface is changed.

Final vocabulary fix/report, full note/primary reconstruction, syntax, local
links, evidence identities and canonical-cache freshness are checked. The
SOURCE_IDENTITIES manifest binds every intended publication file except itself;
the complete staged set and every staged/worktree hash are compared before
commit. Only the allowed citation manifest is included from audit data.
''')
(P/'REVIEW_HISTORY.md').write_text((P/'REVIEW_HISTORY.md').read_text()+'''
## Publication conformance by section

1. Self-containment: complete hypotheses, proof, finite control and source map
   are included; no local path supplies an unstated premise.
2. Cache/execution: declared60s canonical run completed; note input is fresh.
3. Claim scope: bounded_theorem and conditional-support are separate fields;
   supplied premises and all absent conclusions remain explicit.
4. Negative claims: no no-go theorem or retained negative is proposed. The
   adverse examples test proof shortcuts, so a negative-packet PASS is inapplicable.
5. Proof obligations: the complete analytic chain and selective reconstruction
   are present; Fock isometry and EX remain open.
6. Runner validity: exact finite algebra controls plus actual whole-primary
   defects, with no continuum claim by enumeration.
7. Packet: goal, assumptions, approaches, evidence, status, trace, history and
   recovery are complete; this snapshot is not a second live campaign state.
8. Links/graph: ordinary local links checked and one intended node acknowledged.
9. Note: definitions, source match, proof, counterexamples, scope and recovery
   are explicit; publication reconstructs from the entire frozen argument.
10. Authority: no audit verdict, retained status, global weave, main push or merge.
11. Sourcing/counts: all stated numbers are bound to full source/control logs.
   No empirical observations, confidence intervals or fitted constants apply.
12. Pre-review gates: selective source review, canonical execution, mutants,
   vocabulary, source/cache identity, citation and focused audit compatibility
   completed. Global combined pipeline and strict audit lint were not run and
   are not recorded as passed; independent landing gates remain.
''')
state = P/'STATE.yaml'
state.write_text(state.read_text().replace('pr_status: preparation', 'pr_status: ready_for_regular_PR').replace(
    'next_action: canonical_controls_and_source_bound_conformance_then_regular_PR',
    'next_action: open_regular_PR_after_final_staged_checks'))
backlog = P/'PR_BACKLOG.md'
backlog.write_text(backlog.read_text().replace('Canonical runner evidence,\nsource-mutant controls and source-bound publication conformance are completed\nbefore opening.',
    'Canonical runner evidence,\nsource-mutant controls and source-bound publication conformance are now\nrecorded in DELIVERY_CHECKS.md.'))

editable = sorted(P.glob('*.md'))+[W/r['publication_path'] for r in m['outputs']]+[P/'reconstruct.py']
for mode in ['fix', 'report-only']:
    target = S/('scattering_final_vocab_'+mode)
    r = subprocess.run([sys.executable, 'scripts/vocab_lint.py', '--'+mode,
                        '--report-path', str(target.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable], capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout+r.stderr)
    assert r.returncode == 0
r = subprocess.run([sys.executable, str(P/'reconstruct.py')], capture_output=True)
(S/'scattering_final_reconstruction.log').write_bytes(r.stdout+r.stderr)
assert r.returncode == 0
ast.parse(primary.read_text())
assert runner_cache.cache_status(str(primary.relative_to(W))) == runner_cache.cache_identity_status(str(primary.relative_to(W))) == 'fresh'
links = []
for path in editable:
    if path.suffix != '.md':
        continue
    prose, fenced = [], False
    for line in path.read_text().splitlines():
        if line.lstrip().startswith('```'):
            fenced = not fenced
            continue
        if not fenced and not line.startswith(('    ', '\t')):
            prose.append(re.sub(r'`[^`]*`', '', line))
    for target in re.findall(r'\]\(([^)\s]+)\)', '\n'.join(prose)):
        if target.startswith(('http:', 'https:', '#', 'mailto:')):
            continue
        assert (path.parent/unquote(target.split('#', 1)[0])).resolve().exists(), (path, target)
        links.append(dict(source=str(path.relative_to(W)), target=target))

emap = json.loads((P/'EVIDENCE_MAP.json').read_text())
rows = {r['preserved']: r for r in emap['files']}


def preserve(src):
    b = src.read_bytes()
    dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(b, mtime=0)
    if dst.exists():
        assert dst.read_bytes() == packed, dst
    else:
        dst.write_bytes(packed)
    rel = str(dst.relative_to(P))
    rows[rel] = dict(original=str(src), preserved=rel, sha256=sha(b), bytes=len(b))


for src in sorted((S/'scattering_primary_mutations').iterdir()):
    preserve(src)
for name in ['prepare_scattering_publication.py', 'run_scattering_primary_mutants.py',
             'finish_scattering_delivery.py', 'scattering_canonical_execution.json',
             'scattering_focused_audit_compat.json', 'scattering_focused_audit_compat.stderr',
             'scattering_citation_execution.json', 'scattering_initial_vocab_fix.json',
             'scattering_initial_vocab_fix.log', 'scattering_initial_reconstruction.log',
             'scattering_final_vocab_fix.json', 'scattering_final_vocab_fix.log',
             'scattering_final_vocab_report-only.json', 'scattering_final_vocab_report-only.log',
             'scattering_final_reconstruction.log']:
    preserve(S/name)
for r in rows.values():
    b = gzip.decompress((P/r['preserved']).read_bytes())
    assert sha(b) == r['sha256'] and len(b) == r['bytes']
for r in emap['external_reference_sources']:
    b = Path(r['original']).read_bytes()
    assert sha(b) == r['sha256'] and len(b) == r['bytes']
mechanical = dict(note_and_primary_reconstructed=True, whole_primary_mutants=8,
                  preserved_evidence_files=len(rows), external_reference_identities=len(emap['external_reference_sources']),
                  exact_EX_repair_bindings=6, citation_delta=dict(nodes=1, edges=0),
                  old_graph_nodes_unchanged=True, cache_and_inputs_fresh=True,
                  ordinary_links=links, scope='Mechanical identity checks, not a scientific or audit verdict.')
out = S/'scattering_delivery_mechanical.json'
out.write_text(json.dumps(mechanical, indent=2)+'\n')
preserve(out)
emap['files'] = [rows[k] for k in sorted(rows)]
(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap, indent=2)+'\n')
files = [W/r['publication_path'] for r in m['outputs']]+[graph, runner_cache.cache_path_for(str(primary.relative_to(W)))]+[
    p for p in P.rglob('*') if p.is_file() and p != P/'SOURCE_IDENTITIES.json']
ident = []
for path in sorted(set(files)):
    row = dict(path=str(path.relative_to(W)), sha256=sha(path.read_bytes()))
    if path.suffix == '.gz':
        row['decompressed_sha256'] = sha(gzip.decompress(path.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,
    scope='Every intended publication file except this manifest itself.', files=ident), indent=2)+'\n')
paths = [r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git', 'add', '--']+paths, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
for row in ident:
    assert sha(subprocess.check_output(['git', 'show', ':'+row['path']])) == row['sha256']
staged = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z']).decode().split('\0'))-{''}
assert staged == set(paths)
assert not subprocess.check_output(['git', 'diff', '--name-only'])
final = dict(staged_files=len(paths), staged_hashes_match=True, whitespace_clean=True, **mechanical)
(S/'scattering_final_staged_verification.json').write_text(json.dumps(final, indent=2)+'\n')
print(json.dumps(final))
