"""Compose the reviewed compact-patch theorem with an exact source map."""
from pathlib import Path
import gzip
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent / 'scattering_worktree'
P = W / '.claude/science/physics-loops/toe-compact-patch-scattering-20261011'
P.mkdir(parents=True, exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
note_path = 'docs/COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md'
primary_path = 'scripts/compact_patch_scattering_covariance_2026_10_11.py'
source = S / 'COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md'
raw = source.read_text()
assert sha(raw.encode()) == 'd1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a'
edits = []


def edit(before, after, reason):
    global raw
    assert raw.count(before) == 1, (before, raw.count(before))
    edits.append(dict(before=before, after=after, reason=reason))
    raw = raw.replace(before, after)


edit('# Compact-patch scattering and commutant covariance', '''---
claim_id: compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11
claim_type: bounded_theorem
claim_scope: "Supplied microscopic commuting flows, isolated mass components, finite centre spectrum and separated compact packets imply almost-local creators, finite-product scattering limits and commutant covariance. No Fock isometry or full-GNS completeness is asserted."
upstream_dependencies: []
runner: scripts/compact_patch_scattering_covariance_2026_10_11.py
actual_current_surface_status: conditional-support
---

# Compact-patch scattering and commutant covariance''',
     'Publication metadata; explicit supplied hypotheses are not framework authority.')
edit('**Author status:** conditional support; independent proof review pending.',
     '**Status:** conditional-support; the complete argument received a separate source review.',
     'Record completed scoped review without applying an audit verdict.')
edit('was downloaded on 2026-10-11 and is preserved as `compact_patch_scattering/sources/BDN_1412.2970v2.pdf`,',
     'was downloaded on 2026-10-11 and is preserved in the external research directory at `resume_20261011/compact_patch_scattering/sources/BDN_1412.2970v2.pdf`,',
     'Distinguish the local reference recovery path from redistributed publication evidence.')
edit('Complete page texts 7–23 and 40–43 were read; all page texts are preserved, without claiming all were read.',
     'Complete page texts 7–23 and 40–43 were read by the author and independent reviewer; all page texts remain in external recovery, without claiming all were read. The [milestone evidence map](../.claude/science/physics-loops/toe-compact-patch-scattering-20261011/EVIDENCE_MAP.json) records reference hashes and the official URL; complete third-party papers are not redistributed.',
     'Make exact literature coverage and recovery explicit.')
edit('Main `a13caa4885f547c8d206265b031ba7649e539fd9` was checked against the remote main ref.',
     'All three report identities were also rechecked unchanged at `0cc560e3935fa1ad7623592bf9974680c922d52d`. Main `a13caa4885f547c8d206265b031ba7649e539fd9` was checked against the remote main ref on 2026-10-11 at 23:44 UTC.',
     'Record the refreshed source identity; new RV4 science is not adopted.')

repair = (S / 'COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md').read_text()
assert sha(repair.encode()) == 'd4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516'
intro = repair.split('Replace the sentence immediately before EX with:\n\n', 1)[1].split('\n\nKeep the displayed EX formula unchanged.', 1)[0]
outro = repair.split('Replace the paragraph immediately following EX with:\n\n', 1)[1].rstrip()
edit("The independent remaining target is exactly the assessment's exhaustion condition", intro,
     'Exact independently confirmed repair: define the additional unique-vacuum and positive-gap setting only for EX.')
edit('with the vacuum included in the scattering span. Here \\(P_{\\rm sc}\\) projects onto the relevant full constructed scattering space, not just one compact patch. Neither (27), one-particle density, nor (29) proves (EX). The present theorem also does not prove that all finite-energy excitations belong to isolated mass components, that the common rational denominator exists, or that the supplied continuous generators are microscopic implementations.',
     outro, 'Exact independently confirmed downstream completeness equivalence; S1–S4 are unchanged.')
edit('The exact author control `compact_patch_scattering/check_clock_and_product.py` checked',
     'The [finite convention and product control](../scripts/compact_patch_scattering_covariance_2026_10_11.py) preserves the exact author control and checks',
     'Point to the self-contained publication runner.')
edit('The proof is provisional until independently checked.',
     'A separate reviewer reconstructed the complete argument before inspecting the author-control evidence. The report is `924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be`; its sole downstream EX wording finding was resolved by the exact replacement confirmed in addendum `8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029`. This selective source review does not apply an audit verdict or retained status.',
     'Describe the actual completed review and scope repair.')
edit('Evidence and exact source bindings are in `compact_patch_scattering/receipt.json`; the current checkpoint is `compact_patch_scattering/CHECKPOINT.md`. Only this new probe and its evidence directory were written. All earlier assessment/review/source files remain unchanged. No repository, prompt, PR, audit, axiom, model, or other-chat action was taken. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.',
     'The [milestone packet](../.claude/science/physics-loops/toe-compact-patch-scattering-20261011/) preserves the complete original note, author evidence, independent reconstruction, exact EX repair and both review receipts. PUBLICATION_EDITS.json and reconstruct.py reproduce this note and its runner from those frozen sources. Earlier assessments and candidate-law reports are unchanged; no editable prompt, physical axiom, main branch, audit verdict or retained status is changed. The live campaign checkpoint remains in the transport worktree at `toe-dynamics-bridge-20261009/STATE.yaml` and `HANDOFF.md`. Fixed campaign deadline: 2026-10-12 16:00:52 UTC.',
     'Replace historical author-only delivery prose with the actual publication and recovery paths.')
(W / note_path).write_text(raw)
outputs = [dict(kind='note', source_path=str(source), source_sha256=sha(source.read_bytes()),
                preserved_source='evidence/COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md.gz',
                edits=edits, appended_text='', publication_path=note_path,
                publication_sha256=sha(raw.encode()))]

src = S / 'compact_patch_scattering/check_clock_and_product.py'
original = src.read_text()
assert sha(original.encode()) == '57855b43dbaf43e7bdcb6ef60bcf6e1c56b05b23ff0368c61bbab37a834135f4'
before = 'from collections import defaultdict\n'
after = '''AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = [
    "docs/COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]
if not __debug__:
    raise RuntimeError("Run without -O: exact control assertions must be enabled")

from collections import defaultdict
'''
assert original.count(before) == 1
suffix = '''
    print("per_element: exact finite character, Fourier, clock and product-word identities checked")
    print("per_site: checked and not executed — the supplied local interactions enter the analytic LR hypotheses")
    print("per_mode: exact finite Fourier convention fixtures; no continuum spectral sampling claim")
    print("per_block: finite noncommutative products n=1,...,9 checked modulo D_i Omega=0")
    print("lattice_wide: checked and not executed — analytic Cook convergence and covariance are proved in the note")
    print("TOTAL: PASS=9 FAIL=0")
    print("SCOPE: nine finite control records; no analytic scattering proof, Fock isometry or audit verdict from this runner")
'''
body = original.replace(before, after) + suffix
(W / primary_path).write_text(body)
outputs.append(dict(kind='primary', source_path=str(src), source_sha256=sha(src.read_bytes()),
                    preserved_source='evidence/compact_patch_scattering/check_clock_and_product.py.gz',
                    edits=[dict(before=before, after=after, reason='Declare timeout/input and reject optimized execution; control body unchanged.')],
                    appended_text=suffix, publication_path=primary_path, publication_sha256=sha(body.encode())))
(P / 'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=outputs), indent=2) + '\n')

texts = {
'STATE.yaml': '''loop: toe-compact-patch-scattering-20261011
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-compact-patch-scattering-20261011
base_revision: a13caa4885f547c8d206265b031ba7649e539fd9
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: compact_packet_scattering_construction_and_commutant_covariance
independent_check: complete_source_reconstruction_plus_EX_scope_repair_confirmation
strongest_unresolved_obligation: Fock_isometry_then_full_GNS_exhaustion
provisional_dependency: supplied_S1_through_S4_not_derived_physical_axioms
pr_status: preparation
next_action: canonical_controls_and_source_bound_conformance_then_regular_PR
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md': '''# Exact construction contract

Given the explicitly supplied S1–S4, construct a dense class of one-particle
creators on each selected compact mass/centre patch. Prove strong incoming and
outgoing products for every fixed finite family of separated packet velocities,
fixed-chart creator independence, permutation symmetry and the V action.
No uniform limit as separation vanishes is part of this contract. Nonzero
multiparticle norms, Fock extension and full-GNS exhaustion are later obligations.
''',
'ASSUMPTIONS_AND_IMPORTS.md': '''# Premises and dependencies

S1 supplies actual commuting, vacuum-preserving finite-range microscopic H and
K=P/beta flows. S2 supplies isolated positive mass-Casimir eigenspaces. S3
supplies a common finite-order centre action on those components only. S4
supplies compact single-lift charts and separated packet velocities. None is
derived from the framework's minimal physical axioms or changed by this PR.

BDN's LR bound, finite-region approximation and smooth packet estimates are
matched primary imports. The finite-product Cook argument is reconstructed
from directly proved creator properties. BDN's stronger geometric isolation
condition need not hold, and its Fock-isometry conclusion is not imported.

The EX discussion separately assumes a unique vacuum and positive H-gap. Those
additional assumptions make EX equivalent to full-GNS completeness; EX itself
is unproved. They are not silently added to the compact scattering theorem.
N1/B1/M1 provide the motivating exact source contract, not retained authority.
Their unchanged byte identities were checked through PR9476 head0cc560e.
''',
'APPROACH_REGISTRY.md': '''# Mathematical approach families

1. Joint energy/current filtering: exploit the supplied continuous momenta
   before using geometric translations. Split flow parameters into a bounded
   region and a Schwartz tail; do not require an exponential moment.
2. Centre decomposition: finite characters project only on the stipulated
   finite-order mass component. A global projection is unnecessary and false
   without that spectrum.
3. Direct creator properties: exact vacuum graphs and almost locality permit
   Cook convergence without unproved geometric transfer isolation.
4. Fixed-chart comparison: discard a packet only through its zero vacuum
   action and separated commutators; no small operator-norm claim is used.
5. Covariance: the direct-property creator class is preserved by fixed
   microscopic flows even when a transformed local seed is not local.

The Fock inner-product factorization and full-space density families remain
underexplored in this milestone and are explicit next obligations.
''',
'ROUTE_PORTFOLIO.md': '''# Evidence and checking roles

The full analytic proof is the theorem artifact. The runner is an exact finite
algebra control for signs, product order and powers only. The independent
review reconstructs the proof before author-control inspection and gives a
separate spectral check of the EX boundary. Its later rerun of the same helper
is reproduction, not an independent implementation. Root suggested comparison
and covariance-class clarifications and is a contributor, not the independent
reviewer. All workers retained the user-selected model and effort.
''',
'OPPORTUNITY_QUEUE.md': '''# Next decisions

First derive and selectively check the Fock inner-product/isometry extension
with its extra vacuum gap and regular-dispersion hypotheses. The decisive
checks are bounded-energy creator norms and the clustering factorization
needed to control the full product without a hidden polynomial loss.

Then determine the exact density/exhaustion obligation for all needed channels.
An isometry onto a proper subspace cannot establish a full-algebra shift. A
faithful GNS representation alone does not repair that missing implication.
Avoid duplicating the active candidate-law gravity or chiral PR lanes.
''',
'NO_GO_LEDGER.md': '''# Preserved adverse findings and limits

A Schwartz kernel need not have an exponential moment; that proposed estimate
fails. Parameter truncation repairs the localization proof. A centre average
on the full Hilbert space need not be idempotent without the finite-order
spectrum. Both examples remain in the original proof/control evidence.

EX with an unspecified lower cutoff can omit positive-energy vectors below
that cutoff or additional zero-energy vectors. The review's exact finite
spectral examples expose this scope issue; the reviewed additional vacuum/gap
conditions repair the completeness equivalence. These are not lattice-model
counterexamples to S1–S4 or a no-go theorem. No N-gate PASS is requested.
''',
'LITERATURE_BRIDGES.md': '''# Primary mathematical source

[Bachmann–Dybalski–Naaijkens, arXiv1412.2970v2](https://arxiv.org/abs/1412.2970v2)
supplies the matched LR, almost-locality, packet and Cook machinery. Exact
statement/hypothesis matches are in the theorem's table. PDF SHA-256:
3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126.
The author and reviewer read complete PDF pages7–23 and40–43. Root read the
complete new argument and the necessary primary pages7,8,14–21,41,42.
Full papers and raw extracted pages remain external with hashes and official
URLs; the original proof, reconstruction and source coverage are preserved.
No global literature novelty or physical realization is claimed.
''',
'ARTIFACT_PLAN.md': '''# Reviewable milestone

One complete conditional theorem, one finite convention/product control,
source-to-publication edit maps, preserved author and independent review
evidence, canonical execution and explicit scope. The joint-filter construction
and finite-product covariance form one coherent main-based result. Later Fock
work is not treated as evidence for this milestone.
''',
'TRACE_GATE.md': '''# Named downstream connection

```yaml
trace_class: upstream_support
target_claim_id: null
target_blocker_text: "That convergence step is assumed, not proved"
source_of_blocker_text: user_goal
source_location: "C4_M1_report.md line234, fb2d6b5f54fcff8680219dce5f903d6620e5f987d4f093462502dc3e600b1b2b"
reachability_to_target: partially_closes
artifact_role: theorem
next_trace_action: "Derive the Fock inner-product extension, then address full-GNS exhaustion without promoting a proper scattering range."
```

The consumer is N1's constructive-scattering/HR-covariance premise. This
theorem covers specified isolated mass components and separated compact
packets; it does not retire the complete scattering assumption or derive
the microscopic implementation, all species, rational centres or global shift.
''',
'CLAIM_STATUS_CERTIFICATE.md': '''# Mathematical claim status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: upstream_support
reachability_to_target: partially_closes
conditional_surface_status: "Finite-packet construction and covariance under explicit S1–S4."
hypothetical_axiom_status: null
admitted_observation_status: null
independent_review_status: "Complete source reconstruction; sole EX scope finding repaired and confirmed."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

No physical axiom, audit verdict or retained status is changed. No Lean check
is claimed; the load-bearing work is analytic and received a distinct scoped
review. Finite controls do not substitute for that argument or future audit.
''',
'REVIEW_HISTORY.md': '''# Source review and affected-source repair

Source d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a.
Review924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be;
receipt4664463d5fd978e9d3026660b563f25c5628e46f43a10340169306d474d809aa.
Pre-author-control reconstruction6bf05b705a3bfda8f2469aa86fff6bd13d3e0827495ce8ea2408f61c91ee4fcc.
The source proof was supported. The sole finding required explicit additional
unique-vacuum and positive-gap assumptions around EX. Exact repair
d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516 was
confirmed by addendum8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029.
Original theorem/review/receipts remain unchanged. Root read the complete
source, amendment, review, reconstruction, EX check and repair confirmation.
Root verified all81 author and76 review artifact bindings; their scientific
coverage is the argument, not the count. Final publication conformance and
execution are recorded separately after completion.
''',
'HANDOFF.md': '''# Fixed scattering milestone snapshot

This main-based branch packages compact-patch scattering and commutant
covariance under explicitly supplied assumptions. It is not a second live
campaign checkpoint. Current campaign STATE.yaml/HANDOFF.md remain in the
transport worktree at toe-dynamics-bridge-20261009. Fixed deadline:
2026-10-12 16:00:52 UTC. No science merge, main push, applied audit, physical
axiom change or other-chat message is authorized by this milestone.

Original note and source reviews are recoverable through EVIDENCE_MAP.json;
PUBLICATION_EDITS.json includes the exact reviewed EX scope correction.
reconstruct.py checks the full publication note and primary. The cited paper
and page extraction bytes remain external and can be recovered from their
official URL/hash. No inaccessible local file supplies an unstated premise.

The Fock extension is ongoing external research and is not asserted here.
Independent audit/landing authority remains separate. No editable prompt or
platform instruction was changed. No later candidate-law RV4 proof is adopted.
''',
'PR_BACKLOG.md': '''# Milestone decision: OPEN

The joint-filter creator construction, finite-product limits and commutant
covariance form an independently reviewable mathematical milestone. Existing
candidate-law work assumes a constructive scattering step. A direct appeal to
a geometric lattice-shell theorem would leave an unmatched isolation premise:
different continuous momenta can fold onto the same geometric momentum. This
result makes the extra commuting momentum an explicit part of the filter,
then proves the exact creator properties needed for spatial packet separation.

The proof also exposes two tempting but invalid shortcuts. Integrating an LR
exponential against an arbitrary Schwartz kernel is not justified, so the
localization estimate cuts off flow parameters and controls the remaining
tail separately. A finite character average is not a global projector unless
the whole spectrum has the required finite order; the construction uses that
projection only on the already selected mass component. These distinctions
are part of the theorem's self-contained hypotheses and proof.

The final Cook estimate includes both differentiated packet terms and every
remaining operator factor. Creator independence uses zero vacuum vectors and
rapid commutators rather than asserting that a discarded packet has small norm.
The fixed microscopic symmetry preserves the admissible creator properties,
even though it need not send a strictly local seed to another local seed.
Those points make the covariance statement inspectable without an assumed
global Fock wave operator or completeness conclusion.

The separate reviewer reconstructed the full analytic chain before seeing
the author-control evidence. Its one finding concerned the downstream EX
wording, not the compact construction. The exact extra vacuum/gap setting and
the resulting density argument were checked in a separate addendum. The
frozen source and review remain recoverable alongside the publication map.

The milestone therefore supports the named scattering premise but does not
settle it in full. Nonzero multiparticle norms, the Fock extension, all required
channels and full-GNS exhaustion remain open here. A regular PR records this
coherent boundary while discovery proceeds. Canonical runner evidence,
source-mutant controls and source-bound publication conformance are completed
before opening. No science merge or retained-status assignment follows.
'''
}
for n, t in texts.items():
    (P / n).write_text(t)

paths = [source, S/'COMPACT_PATCH_SCATTERING_COVARIANCE_REVIEW.md',
         S/'COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md',
         S/'INDEX_TO_PHYSICS_NEXT_OBLIGATION.md', S/'compact_patch_scattering_root_check.json',
         S/'SC_review_root_final_identity_check.json', S/'scattering_source_0cc560e_recheck.json']
for folder in ['compact_patch_scattering', 'compact_scattering_review']:
    paths.extend(p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
rows, refs = [], []
for src in paths:
    b = src.read_bytes()
    row = dict(original=str(src), bytes=len(b), sha256=sha(b))
    if src.suffix == '.pdf' or 'BDN_pages' in src.parts or src.name == 'BDN_fulltext.txt':
        row.update(primary_url='https://arxiv.org/pdf/1412.2970v2',
                   recovery='Exact reference bytes remain at external research path; not redistributed in this PR.')
        refs.append(row)
    else:
        dst = P/'evidence'/(str(src.relative_to(S))+'.gz')
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(gzip.compress(b, mtime=0))
        row['preserved'] = str(dst.relative_to(P))
        rows.append(row)
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(
    scope='Lossless authored/repository evidence; external primary reference identities and official URL.',
    files=rows, external_reference_sources=refs), indent=2)+'\n')
(P/'reconstruct.py').write_text('''from pathlib import Path
import gzip, hashlib, json
P = Path(__file__).resolve().parent
W = P.parents[3]
for row in json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']:
    b = gzip.decompress((P/row['preserved_source']).read_bytes())
    assert hashlib.sha256(b).hexdigest() == row['source_sha256']
    t = b.decode()
    for edit in row['edits']:
        assert t.count(edit['before']) == 1
        t = t.replace(edit['before'], edit['after'])
    t += row['appended_text']
    assert (W/row['publication_path']).read_text() == t
    assert hashlib.sha256(t.encode()).hexdigest() == row['publication_sha256']
print('Complete note and primary reconstruct exactly from frozen sources and explicit edits')
''')
print(json.dumps(dict(note_sha256=sha((W/note_path).read_bytes()),
                     primary_sha256=sha((W/primary_path).read_bytes()),
                     own_evidence_files=len(rows), reference_bindings=len(refs))))
