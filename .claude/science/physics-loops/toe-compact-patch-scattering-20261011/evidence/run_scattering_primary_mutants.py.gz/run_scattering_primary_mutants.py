from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
W = S.parent/'scattering_worktree'
P = W/'scripts/compact_patch_scattering_covariance_2026_10_11.py'
D = S/'scattering_primary_mutations'
D.mkdir(exist_ok=False)
body = P.read_text()
sha = lambda b: hashlib.sha256(b).hexdigest()
baseline = (S/'compact_patch_scattering/clock_and_product.stdout.jsonl').read_text().splitlines()
cases = [
    ('character_weight', 'variable, wrong_sign=False):', 'variable, wrong_sign=True):',
     'assert value == int(selected == actual)'),
    ('global_projection_spectrum', 'reduce_roots(global_average**2 - global_average, 3, x)',
     'reduce_roots(global_average**2 - global_average, 2, x)', 'assert residual != 0'),
    ('cook_missing_pair', 'n, drop_pair=None, reverse_sign=False):',
     'n, drop_pair=(0, 1), reverse_sign=False):', 'assert product_derivative(n) == commuted_derivative(n)'),
    ('cook_commutator_sign', 'n, drop_pair=None, reverse_sign=False):',
     'n, drop_pair=None, reverse_sign=True):', 'assert product_derivative(n) == commuted_derivative(n)'),
    ('geometric_centre_sign', 'geometric_q = (momentum - centre) % ring',
     'geometric_q = (momentum + centre) % ring', 'assert energies[momentum] - sigma[fourier_q] == 0'),
    ('packet_clock_sign', 'assert energies[momentum] - sigma[fourier_q] == 0',
     'assert energies[momentum] + sigma[fourier_q] == 0', 'assert energies[momentum] + sigma[fourier_q] == 0'),
    ('double_beta_clock', 'assert Fraction(q, 1) / beta * beta == q',
     'assert Fraction(q, 1) / beta / beta * beta == q', 'assert Fraction(q, 1) / beta / beta * beta == q'),
    ('cook_power_loss', 'power = d*(n-2) + 2*d - (d*n+2)',
     'power = d*(n-2) + 2*d - (d*n+1)', 'assert power == -2'),
]


def run(case):
    name, before, after, expected = case
    assert body.count(before) == 1
    source = body.replace(before, after)
    path = D/(name+'.py')
    path.write_text(source)
    start = time.monotonic()
    command = [sys.executable, str(path)]
    timed_out = False
    try:
        r = subprocess.run(command, cwd=W, capture_output=True, timeout=60)
        out, err, rc = r.stdout, r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out, err, rc = e.stdout or b'', e.stderr or b'', None
        timed_out = True
    (D/(name+'.stdout')).write_bytes(out)
    (D/(name+'.stderr')).write_bytes(err)
    lines = out.decode().splitlines()
    row = dict(name=name, before=before, after=after, expected_assertion=expected,
               source_sha256=sha(source.encode()), command=command,
               utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               elapsed_seconds=time.monotonic()-start, timeout_seconds=60,
               exit_code=rc, timed_out=timed_out, stdout_sha256=sha(out),
               stderr_sha256=sha(err), stdout_is_baseline_prefix=lines==baseline[:len(lines)],
               intended_failure=rc==1 and expected in err.decode() and err.decode().splitlines()[-1]=='AssertionError')
    (D/(name+'.execution.json')).write_text(json.dumps(row, indent=2)+'\n')
    return row


with ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(run, cases))
(D/'manifest.json').write_text(json.dumps(dict(primary=str(P), primary_sha256=sha(P.read_bytes()), runs=rows), indent=2)+'\n')
assert all(r['intended_failure'] and r['stdout_is_baseline_prefix'] and not r['timed_out'] for r in rows)
print(json.dumps(dict(complete_primary_mutants=len(rows), intended_failures=len(rows), source_sha256=sha(P.read_bytes()))))
