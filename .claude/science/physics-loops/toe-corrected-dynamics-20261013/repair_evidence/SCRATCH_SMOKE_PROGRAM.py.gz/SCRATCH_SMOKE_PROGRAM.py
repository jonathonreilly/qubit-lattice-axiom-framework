#!/usr/bin/env python3
"""Scratch-only byte-integrity regression; no canonical API or scientific predicate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time

Q = Path(__file__).resolve().parent
CW = Q.parent.parent / 'correlation_worktree'
PACKET = '.claude/science/physics-loops/toe-corrected-dynamics-20261013'
DEADLINE = datetime(2026, 10, 13, 16, 42, 30, tzinfo=timezone.utc)
sys.dont_write_bytecode = True


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(path):
    return json.loads(path.read_bytes())


def write(path, raw):
    assert path.resolve().is_relative_to(Q)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw if isinstance(raw, bytes) else
                     (json.dumps(raw, indent=2, sort_keys=True) + '\n').encode())


def run(folder, root, runner, expected):
    assert datetime.now(timezone.utc) < DEADLINE
    argv = [sys.executable, '-B', str(root / runner)]
    start, tick = datetime.now(timezone.utc).isoformat(), time.monotonic()
    timeout = min(60, (DEADLINE - datetime.now(timezone.utc)).total_seconds())
    out, err, code, timed_out, launch_error = b'', b'', None, False, None
    try:
        process = subprocess.Popen(argv, cwd=root, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        try:
            out, err = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            out, err = process.communicate()
        code = process.returncode
    except OSError as exc:
        launch_error, err = repr(exc), repr(exc).encode()
    write(folder / 'stdout', out)
    write(folder / 'stderr', err)
    record = {'argv': argv, 'cwd': str(root), 'interpreter': sys.executable,
        'python': sys.version, 'started_utc': start, 'ended_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - tick, 'timeout_seconds': timeout,
        'timed_out': timed_out, 'exit_code': code, 'expected_exit_code': expected,
        'launch_error': launch_error, 'runner_sha256': sha((root / runner).read_bytes()),
        'stdout_sha256': sha(out), 'stderr_sha256': sha(err), 'stdout_bytes': len(out), 'stderr_bytes': len(err),
        'canonical_cache_api_used': False, 'mathematical_predicates_executed': 0}
    write(folder / 'execution.json', record)
    assert not timed_out and launch_error is None and code == expected, record
    return out, err, record


def main():
    assert Q.name == 'corrected_dynamics_publication_preparation_v2'
    assert datetime.now(timezone.utc) < DEADLINE
    evidence = Q / 'repair_history/scratch_smoke'
    assert not evidence.exists()
    spec = js(Q / 'SPECIFICATIONS.json')
    rendering = js(Q / 'RUNNER_SOURCE_RENDERING.json')
    parents = {p['path']: p for p in js(Q / 'payload' / PACKET / 'PARENT_BINDINGS.json')['parents']}
    inputs = rendering['inputs']
    assert len(inputs) == len(set(inputs)) == 232
    values, origins = {}, []
    for name in inputs + [r['runner'] for r in spec['notes']]:
        source = CW / name if name in parents else Q / 'payload' / name
        raw = source.read_bytes()
        if name in parents:
            assert sha(raw) == parents[name]['published_sha256'] and len(raw) == parents[name]['bytes']
        values[name] = raw
        origins.append({'path': name, 'source': str(source), 'sha256': sha(raw), 'bytes': len(raw)})
    write(evidence / 'SCRATCH_INPUTS.json', {'files': origins, 'file_count': len(origins),
        'scope': 'Exact scratch copies only; inputs remain available in the frozen V2 payload and pinned parent sources.'})
    write(evidence / 'program.py', Path(__file__).read_bytes())
    with tempfile.TemporaryDirectory(prefix='scratch-identity-', dir=Q / 'repair_history') as directory:
        root = Path(directory)
        for name, raw in values.items():
            write(root / name, raw)
        first = spec['notes'][0]
        old = Q / 'repair_history/v1_sources' / Path(first['runner']).name
        assert sha(old.read_bytes()) == 'd8ba6bc53a8fd2b1dfc7247302e11ec56b2689f35468037bcf00a086b016b277'
        (root / first['runner']).write_bytes(old.read_bytes())
        out, err, old_record = run(evidence / 'v1_regression', root, first['runner'], 1)
        assert out == b'' and json.loads(err) == {'result': 'identity_verification_incomplete',
            'error': 'Complete accepted assembly diff differs', 'mathematical_operations_executed': False,
            'mathematical_predicates_executed': 0, 'scientific_mutations_executed': 0}
        (root / first['runner']).write_bytes(values[first['runner']])
        successes = []
        for note in spec['notes']:
            out, err, record = run(evidence / ('v2_' + note['key']), root, note['runner'], 0)
            lines = out.decode().splitlines()
            assert err == b'' and len(lines) == 6
            result = json.loads(lines[0])
            assert result['result'] == 'source_identities_and_reconstruction_match'
            assert result['claim_id'] == note['claim_id'] and result['mathematical_operations_executed'] is False
            assert result['mathematical_predicates_executed'] == result['scientific_mutations_executed'] == 0
            assert result['independent_review_supplied_by_tool'] is result['no_go_packet_pass_supplied_by_tool'] is False
            assert set(result['external_scientific_input_reads']) == set(parents)
            assert sorted(result['external_scientific_input_reads'] + result['package_local_integrity_reads']) == inputs
            for prefix, line in zip(['per_element:', 'per_site:', 'per_mode:', 'per_block:', 'lattice_wide:'], lines[1:]):
                assert line.startswith(prefix + ' checked and not executed — source integrity only;')
            successes.append({'key': note['key'], 'runner': note['runner'], 'runner_sha256': record['runner_sha256'],
                'exit_code': record['exit_code'], 'stdout_sha256': record['stdout_sha256'], 'stderr_sha256': record['stderr_sha256']})
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(values)
        assert all((root / name).read_bytes() == raw for name, raw in values.items())
    result = {'utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Scratch source-integrity smoke only; no canonical prepare, verify, cache, graph or Git execution.',
        'v1_regression_exit_code': old_record['exit_code'], 'v1_regression_error': 'Complete accepted assembly diff differs',
        'v2_successes': successes, 'scratch_identity_processes_executed': 4,
        'successful_v2_identity_processes': 3, 'scratch_inputs_unchanged': True,
        'canonical_identity_processes_executed': 0, 'prepare_verify_executed': False,
        'scientific_programs_executed': 0, 'mathematical_predicates_executed': 0,
        'canonical_writes': 0, 'cache_api_calls': 0, 'git_commands': 0,
        'root_source_review': 'pending', 'root_canonical_runtime': 'pending', 'audit_verdict': False}
    write(evidence / 'RESULT.json', result)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
