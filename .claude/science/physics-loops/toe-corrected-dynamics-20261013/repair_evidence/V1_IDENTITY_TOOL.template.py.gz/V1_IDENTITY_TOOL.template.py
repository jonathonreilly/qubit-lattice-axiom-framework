#!/usr/bin/env python3
"""Exact selected source recovery and publication bytes; zero mathematical predicates."""
from pathlib import Path, PurePosixPath
import difflib
import gzip
import hashlib
import json
import sys

AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = __DECLARED_INPUTS__
PACKET = '.claude/science/physics-loops/toe-corrected-dynamics-20261013'
CLAIM = '__CLAIM__'
MAP_SHA = '__MAP_SHA__'
EDITS_SHA = '__EDITS_SHA__'
PARENTS_SHA = '__PARENTS_SHA__'
STATUS_SHA = '__STATUS_SHA__'
GRAPH_SHA = '__GRAPH_SHA__'
SOURCE_FREEZE_SHA = '1397b1c6397ce7db4c84716cde94a529aa51422f19942ffec3ec43db7eb46c48'
ROOT_ACCEPTANCE_SHA = '8df5f60b85d5e9b22b7d6281bc9941c300ce408caba135f988a125393d212bb2'
ROOT_REVIEW_SHA = '03a051715e85c11d38ad9a9875f8227dda579b1869a9ef7d58d1d858aac47008'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def complete_diff(a, b, name_a, name_b):
    return ''.join(difflib.unified_diff(a.decode().splitlines(True), b.decode().splitlines(True),
        name_a, name_b, n=max(len(a.splitlines()), len(b.splitlines())))).encode()


def verify(root):
    reads = []
    def read(name):
        relative = PurePosixPath(name)
        need(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe declared input')
        path = root.joinpath(*relative.parts)
        need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root),
             'Declared input missing or outside repository')
        reads.append(name)
        return path.read_bytes()
    raw_map = read(PACKET + '/EVIDENCE_MAP.json')
    need(sha(raw_map) == MAP_SHA, 'Archive map changed')
    evidence = json.loads(raw_map)
    objects = evidence['objects']
    need(len({o['sha256'] for o in objects}) == len(objects) and
         len({o['path'] for o in objects}) == len(objects), 'Duplicate archive object')
    contents, origins = {}, {}
    for obj in objects:
        stored = read(PACKET + '/' + obj['path'])
        need(sha(stored) == obj['stored_sha256'] and len(stored) == obj['stored_bytes'], 'Compressed archive changed')
        value = gzip.decompress(stored)
        need(sha(value) == obj['sha256'] and len(value) == obj['bytes'], 'Archived source changed')
        contents[obj['sha256']] = value
        for origin in obj['origins']:
            need(origin['path'] not in origins, 'Duplicate original alias')
            origins[origin['path']] = obj['sha256']
    contract = evidence['accepted_source_package']
    prefix = contract['path'] + '/'
    need(contract['freeze_sha256'] == SOURCE_FREEZE_SHA and
         origins[prefix + 'SOURCE_FREEZE.json'] == SOURCE_FREEZE_SHA, 'Accepted source freeze differs')
    original_freeze = json.loads(contents[SOURCE_FREEZE_SHA])
    need(original_freeze['files'] == contract['members'] and
         original_freeze['file_count_excluding_self'] == 236 and
         len({r['path'] for r in contract['members']}) == len(contract['members']) == 236,
         'Original membership differs')
    expected_aliases = {prefix + r['path'] for r in contract['members']} | {prefix + 'SOURCE_FREEZE.json'}
    need({p for p in origins if p.startswith(prefix)} == expected_aliases, 'Source package aliases differ')
    for item in contract['members']:
        need(origins[prefix + item['path']] == item['sha256'] and
             len(contents[item['sha256']]) == item['bytes'], 'Source member identity differs')
    def archived(path):
        return contents[origins[path]]
    def source(name):
        return archived(prefix + name)
    identities = json.loads(source('SOURCE_IDENTITIES.json'))
    need(len(identities['files']) == identities['source_alias_count'] == 198 and
         len(set(identities['archive_relative_paths'])) == 154, 'Original source-alias count differs')
    for item in identities['files']:
        value = source(item['archive'])
        need(sha(value) == item['sha256'] and len(value) == item['bytes'], 'Exact original archive differs')
    manifest = json.loads(source('SCIENTIFIC_INPUT_MANIFEST.json'))
    need(len(manifest['sources']) == 17, 'Scientific original membership differs')
    need(json.loads(source('EVIDENCE_ARCHIVE_MANIFEST.json')) == evidence['source_archive_manifest'],
         'Original archive closure limits changed')
    bodies = json.loads(source('BODY_COPY_MANIFEST.json'))['bodies']
    complete = {}
    need(len(bodies) == 3 and sum(b['original_lines'] for b in bodies) == 2380, 'Core membership differs')
    for body in bodies:
        original = source(body['source_archive'])
        need(body['all_original_bytes_preserved'] is True and body['edit_ids'] == [] and
             sha(original) == body['original_sha256'] == body['transformed_sha256'] and
             len(original) == body['original_bytes'] == body['transformed_bytes'] and
             original == source(body['body_copy']) and source(body['diff']) == b'', 'Complete accepted core differs')
        complete[prefix + body['body_copy']] = original
    source_map = json.loads(source('LINE_PIECE_MAP.json'))
    need(len(source_map['notes']) == 3, 'Accepted candidate membership differs')
    for note in source_map['notes']:
        assembled = b''
        kinds = []
        for piece in note['pieces']:
            part = source(piece['source'])
            kinds.append(piece['kind'])
            first = assembled.count(b'\n') + 1
            end = (assembled + part).count(b'\n')
            need(piece['output_byte_range'] == [len(assembled), len(assembled) + len(part)] and
                 piece['output_line_range'] == [first, end] and sha(part) == piece['sha256'] and
                 len(part) == piece['bytes'], 'Accepted piece boundary differs')
            assembled += part
        need(kinds == ['new scope/chronology wrapper', 'byte-identical complete original core',
                       'new scope/chronology wrapper'], 'Accepted piece order differs')
        need(assembled == source(note['candidate_path']) and sha(assembled) == note['sha256'] and
             len(assembled) == note['bytes'], 'Accepted source-note reconstruction differs')
        baseline = b''.join(source('body_copies/' + n) for n in note['source_body_order'])
        need(baseline == source(note['original_body_concatenation']) and source(note['complete_diff']) ==
             complete_diff(baseline, assembled, note['original_body_concatenation'], note['candidate_path']),
             'Complete accepted assembly diff differs')
    raw_edits = read(PACKET + '/PUBLICATION_EDITS.json')
    need(sha(raw_edits) == EDITS_SHA, 'Publication transformation changed')
    edits = json.loads(raw_edits)
    need(edits['source_freeze_sha256'] == SOURCE_FREEZE_SHA and
         edits['additional_mathematical_body_edits'] == [] and len(edits['notes']) == 3,
         'Publication scope differs')
    wrappers, published_notes = {}, {}
    for note in edits['notes']:
        need(origins[note['accepted_candidate_path']] == note['accepted_candidate_sha256'] and
             note['additional_mathematical_body_edits'] == [], 'Accepted note or no-edit contract differs')
        assembled, body_names = b'', []
        for piece in note['pieces']:
            if piece['kind'] == 'accepted_complete_core':
                need(piece['additional_mathematical_body_edits'] == [] and
                     piece['historical_status_and_exposure_bytes_preserved'] is True and
                     origins[piece['source_path']] == piece['source_sha256'], 'Core preservation differs')
                part = complete[piece['source_path']]
                body_names.append(Path(piece['source_path']).name)
            else:
                need(piece['kind'] == 'publication_wrapper', 'Unknown publication piece')
                part = piece['text'].encode()
                need(piece['wrapper_path'] not in wrappers, 'Duplicate wrapper')
                wrappers[piece['wrapper_path']] = part
            need(len(assembled) == piece['byte_offset'] and len(part) == piece['bytes'] and sha(part) == piece['sha256'] and
                 assembled.count(b'\n') + 1 == piece['first_line'] and (assembled + part).count(b'\n') == piece['last_line'],
                 'Publication boundary differs')
            assembled += part
        accepted_note = next(n for n in source_map['notes'] if n['canonical_path'] == note['note'])
        need(body_names == accepted_note['source_body_order'], 'Complete core order differs')
        published = read(note['note'])
        need(published == assembled and len(published) == note['published_bytes'] and sha(published) == note['published_sha256'],
             'Published source does not reconstruct')
        published_notes[note['note']] = published
        stored = read(PACKET + '/' + note['diff'])
        need(sha(stored) == note['diff_stored_sha256'], 'Compressed publication diff changed')
        delta = gzip.decompress(stored)
        need(sha(delta) == note['diff_sha256'] and delta == complete_diff(archived(note['accepted_candidate_path']),
             published, accepted_note['candidate_path'], note['note']), 'Complete publication diff differs')
    for wrapper in edits['wrapper_changes']:
        old, new = archived(wrapper['source']), wrappers[wrapper['publication']]
        need(sha(old) == wrapper['source_sha256'] and sha(new) == wrapper['publication_sha256'], 'Wrapper identity differs')
        stored = read(PACKET + '/' + wrapper['diff'])
        need(sha(stored) == wrapper['diff_stored_sha256'], 'Compressed wrapper diff changed')
        delta = gzip.decompress(stored)
        need(sha(delta) == wrapper['diff_sha256'] and delta == complete_diff(old, new,
             'accepted/' + wrapper['publication'], 'publication/' + wrapper['publication']), 'Complete wrapper diff differs')
    raw_parents = read(PACKET + '/PARENT_BINDINGS.json')
    need(sha(raw_parents) == PARENTS_SHA, 'Parent bindings changed')
    bindings = json.loads(raw_parents)
    parents = bindings['parents']
    need(len(parents) == len({p['path'] for p in parents}) == 3, 'Parent membership differs')
    for item in parents:
        value = read(item['path'])
        need(sha(value) == item['published_sha256'] and len(value) == item['bytes'], 'Canonical parent bytes changed')
    same = bindings['same_packet_parent']
    need(same['parent'] == 'corrected_dispersion_bounded_theorem_note_2026-10-13' and
         same['dependent'] == 'moment_sensitive_corrected_dynamics_bounded_theorem_note_2026-10-13' and
         sha(published_notes[same['path']]) == same['published_sha256'] and
         same['core_sha256'] == '402cbc03585ac1cf0fc32facfc18b889de09a2fc9b3bb1449dfda47beb813c0d',
         'Same-packet kinetic parent differs')
    dependencies = json.loads(source('DEPENDENCY_MAP.json'))
    need(bindings['archived_provisional_relations'] == dependencies['external_provisional_support_relations'] and
         len(bindings['archived_provisional_relations']) == 4 and
         bindings['publication_lineage_only'] == dependencies['publication_lineage'], 'Provisional or lineage scope changed')
    raw_graph = read(PACKET + '/CLAIM_REGISTRY_ADDITIONS.json')
    need(sha(raw_graph) == GRAPH_SHA, 'Graph proposal changed')
    graph = json.loads(raw_graph)
    edges = {(r['from'], r['to']) for r in graph['direct_edges']}
    need(len(graph['nodes']) == 3 and len(edges) == len(graph['direct_edges']) == 6 and
         edges == {(r['from'], r['to']) for r in dependencies['edges']} and
         CLAIM in {n['claim_id'] for n in graph['nodes']}, 'Exact direct graph proposal differs')
    raw_status = read(PACKET + '/SOURCE_REVIEW_STATUS.json')
    need(sha(raw_status) == STATUS_SHA, 'Review scope changed')
    status = json.loads(raw_status)
    root_acceptance = read(PACKET + '/CORRECTED_DYNAMICS_SOURCE_ROOT_ACCEPTANCE.json')
    need(sha(root_acceptance) == ROOT_ACCEPTANCE_SHA, 'Root source acceptance changed')
    scope = json.loads(root_acceptance)
    root_review = read(PACKET + '/CORRECTED_DYNAMICS_SOURCE_ROOT_REVIEW.md')
    need(sha(root_review) == ROOT_REVIEW_SHA, 'Root source review changed')
    need(scope == status['source_review_coverage_verbatim'] and
         scope['source_freeze_sha256'] == SOURCE_FREEZE_SHA and scope['required_repairs'] == [] and
         scope['fresh_full_final_candidate_manual_read'] is False and
         scope['full_raw_newfile_diff_manual_reread'] is False and
         scope['reconstruction_and_full_diff_verification'] is True and
         scope['new_independent_mathematical_review'] is False and scope['new_scientific_execution'] is False and
         scope['model_diverse_or_formal_analytic_check'] is False and scope['audit_verdict'] is False and
         status['no_go_packet_pass'] is False and status['N1'] == status['N5'] == 'pending' and
         status['dynamics_source_freeze_sha256'] == SOURCE_FREEZE_SHA, 'Source coverage or pending status changed')
    need(set(reads) == set(AUDIT_INPUT_PATHS) and len(reads) == len(set(reads)), 'Declared read closure differs')
    return {'result': 'source_identities_and_reconstruction_match', 'claim_id': CLAIM,
        'meaning': 'Integrity only; no mathematical calculation, proof or audit was executed.',
        'mathematical_operations_executed': False, 'mathematical_predicates_executed': 0,
        'scientific_mutations_executed': 0, 'independent_review_supplied_by_tool': False,
        'no_go_packet_pass_supplied_by_tool': False,
        'external_scientific_input_reads': [p['path'] for p in parents],
        'package_local_integrity_reads': sorted(set(reads) - {p['path'] for p in parents})}


def main():
    print(json.dumps(verify(Path(__file__).resolve().parents[1]), sort_keys=True))
    print('per_element: checked and not executed — source integrity only; no scalar coefficient or positivity theorem was proved.')
    print('per_site: checked and not executed — source integrity only; no CAR grading or locality estimate was computed.')
    print('per_mode: checked and not executed — source integrity only; no dispersion or physical-band estimate was computed.')
    print('per_block: checked and not executed — source integrity only; no graph domain, commutator or compression theorem was tested.')
    print('lattice_wide: checked and not executed — source integrity only; no time-window, moment, physical-selection or no-go result was verified.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps({'result': 'identity_verification_incomplete', 'error': str(error),
                          'mathematical_operations_executed': False,
                          'mathematical_predicates_executed': 0,
                          'scientific_mutations_executed': 0}), file=sys.stderr)
        raise SystemExit(1)
