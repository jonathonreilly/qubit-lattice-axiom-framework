# Current checkpoint and recovery

This is the current author checkpoint for CURRENT_PRESERVING_REFINEMENT_PROBE.md.
Fixed hard stop: 2026-10-12T16:00:52Z. Root alone owns packaging and any later
repository/PR work. This task owns only that note and this evidence directory.
The completed ENERGY review is immutable and separate.

The bounded mathematical question has a conditional construction: two full
current branches, exact all-scale composition/state/current, four complex
coefficient current fibers and two positive-polarization fibers, explicit actual
time defect, low ordinary-cell sector, persistent local alternating-cell sector,
and a doubled equal-time local section quotient via paired cells. The high
sector has diverging energy; no second light particle or full actual-time
continuum is asserted. Full all-spacing and dyadic time quantifiers differ.

Plan/source freeze: PLAN_FREEZE.json, 15:19:58 UTC. Analytic freeze:
CORE_FREEZE.json, 15:34:14 UTC, original core SHA
b5a80216d91bb1d525a605ba825c3c46a5130fd47ca4ed7f3444242ca778d637.
The original 498 lines are preserved under frozen/. Root coauthor reconstruction
was first read only afterward; ROOT_EXPOSURE.json records exact identity.
Root's actual post-freeze wording finding is corrected transparently in the
final note and FINAL_CORE_ERRATUM.diff. No formulas changed. No optional norm
optimization was pursued. Source and instruction identities are in their JSON
inventories, including the newer-main byte-identity comparison.

No scientific executable was created or run. Deterministic Python and shell
actions only copied, searched, diffed, hashed and inventoried artifacts. There
are no scientific PASS counts, floating checks or pseudo-independent reruns.
The proof depends on the parent actual spin/state conventions and elementary
Hilbert/spectral/real-CAR arguments. No proof-assistant verification or fresh
full transitive parent audit was performed. Root's parallel reconstruction
and subsequent full read are coauthor input, not independent evidence.

Failed shortcuts retained in source section 8: low-branch truncation as a map
of the full source; missing Jacobian; signed negative measure; incorrect real
generator convention; exhaustion inferred from fixed low-cell convergence;
state preservation mistaken for time compatibility; divergent scalar energy
phase treated as invisible on even observables. Scope escapes are restricted
carriers, relaxed currents or modified dynamics; no universal no-go claimed.

Next action: root and the separately assigned fresh reviewer reconcile the
exact final source, specifically the even time witness, spectral module lemma
and paired-cell local quotient. Their outcome belongs to their own artifacts.
If a genuine proof defect is found, retain the frozen source and add a sourced
erratum or narrowed statement with a new final manifest. Do not overwrite
the original freeze, import a new physical axiom, or manufacture a runner.

Final mechanical seal: final_manifest.json plus FINAL_RECEIPT.json. These
assert source identity and file accounting, not mathematical correctness or
audit status. No editable prompt, Git/worktree/PR, axiom, or audit file changed.
