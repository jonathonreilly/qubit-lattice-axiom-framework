"""Deterministic artifact accounting only. No scientific theorem is executed."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json

E = Path(__file__).resolve().parent
S = E.parent
N = S / "CURRENT_PRESERVING_REFINEMENT_PROBE.md"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


frozen = E / "frozen" / N.name
original = frozen.read_text()
assert sha(frozen) == "b5a80216d91bb1d525a605ba825c3c46a5130fd47ca4ed7f3444242ca778d637"
old = "all-spacing c->0 point-norm time limit exists on C13. Norms of the two\nsubsequential limits differ by 2 on B. The real and imaginary parts of B"
new = "all-spacing c->0 point-norm time limit exists on C13. The two subsequential\nlimits have norm distance 2 on B. The real and imaginary parts of B"
assert original.count(old) == 1
corrected = original.replace(old, new)
final = N.read_text()
assert final.startswith(corrected + "\n## 9. Post-freeze chronology and exact erratum\n")
(E / "FINAL_CORE_ERRATUM.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(True), corrected.splitlines(True),
    fromfile="frozen/core", tofile="corrected/core")))
(E / "FINAL_APPENDIX.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(True), final.splitlines(True),
    fromfile="frozen/core", tofile="final/source")))

checks = []
for row in json.loads((E / "source_inventory.json").read_text())["parents"]:
    checks.append({"path": row["path"], "expected": row["sha256"],
                   "actual": sha(Path(row["path"])),
                   "snapshot_actual": sha(Path(row["snapshot"]))})
for filename, expected in {
    "SHARP_CURRENT_REFINEMENT_PROBE.md": "2a6948ab1d98584ac77b3486f8ec1927d88fbb55cd0276123b6c24750f9d6a42",
    "CURRENT_PRESERVING_ROOT_RECONSTRUCTION.md": "8182f9251de4c084edf4da8f4c073a8fa17a03d206720bdf0559fd50fe40b338",
}.items():
    checks.append({"path": str(S / filename), "expected": expected,
                   "actual": sha(S / filename),
                   "snapshot_actual": sha(E / "sources" / filename)})
for filename, expected in {
    "ENERGY_ADAPTED_REFINEMENT_REVIEW.md": "2e6fb1da31b3a12e2ce998123ce3f09d9766f3fb375766f99927b840212dc9f0",
    "energy_adapted_refinement_review/final_manifest.json": "2658ca8d78d15b0a92b377abf913a8f7bb209b7d57571bfecf8e4bb587896e3f",
}.items():
    checks.append({"path": str(S / filename), "expected": expected,
                   "actual": sha(S / filename), "scope": "prior completed review unchanged"})
for row in json.loads((E / "instruction_inventory.json").read_text())["files"]:
    checks.append({"path": row["snapshot"], "expected": row["sha256"],
                   "actual": sha(Path(row["snapshot"])),
                   "newer_identity_recorded": row["identical_at_newer_revision"]})
ok = all(r["actual"] == r["expected"] and
         r.get("snapshot_actual", r["expected"]) == r["expected"] for r in checks)
verification = {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "purpose": "Source accounting, no scientific validation",
    "core_lines": len(original.splitlines()),
    "core_sha256": sha(frozen), "final_source_sha256": sha(N),
    "core_change": "One literal norm-distance erratum; complete appendix is separate",
    "identity_checks": checks, "identities_match": ok,
    "scientific_runs": 0, "formal_proof_assistant": False,
    "independent_review": "Separate artifact; this seal makes no verdict",
}
dump(E / "FINAL_IDENTITY_CHECK.json", verification)
if not ok:
    raise SystemExit("Source identity mismatch; refusal to seal is recorded")

excluded = {"final_manifest.json", "FINAL_RECEIPT.json"}
files = [N] + sorted(p for p in E.rglob("*") if p.is_file() and p.name not in excluded)
manifest = {
    "kind": "Full author artifact manifest, no scientific verdict",
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_sha256": sha(N), "frozen_core_sha256": sha(frozen),
    "files": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p)} for p in files],
    "excluded_self_and_receipt": [str(E / n) for n in sorted(excluded)],
}
dump(E / "final_manifest.json", manifest)
receipt = {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": str(N), "source_sha256": sha(N),
    "manifest": str(E / "final_manifest.json"),
    "manifest_sha256": sha(E / "final_manifest.json"),
    "manifest_files": len(files),
    "source_identity_checks": len(checks),
    "result": "File accounting sealed; no independent or audit verdict",
}
dump(E / "FINAL_RECEIPT.json", receipt)
print(json.dumps(receipt, indent=2))
