#!/usr/bin/env python3
"""Root-only installation of reviewed sources and identity-only verification.

Unexecuted by the author. No Git mutation, science predicates, PR or audit.
Read-only Git guards bind the clean child and final footprint. Failures stop and
preserve every completed stream; there is no retry or vocabulary auto-fix.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ast
import gzip
import hashlib
import importlib.util
import json
import os
import pickle
import re
import signal
import subprocess
import sys
import time
import traceback
import uuid

S = Path(__file__).resolve().parents[1]
Q = S / 'current_preserving_publication_preparation'
WORKTREE = S.parent / 'current_preserving_worktree'
STAGE = Q / 'payload'
BASE = '7c0570a4a20a768349f3d88960303f8637e7fe33'
BRANCH = 'physics-loop/toe-current-preserving-20261012'
FREEZE_SHA = None  # Root supplies the externally anchored final source seal.
ACCEPTANCE_SHA = None  # Root supplies actual final execution acceptance.
PACKET = '.claude/science/physics-loops/toe-current-preserving-20261012'
NOTE = 'docs/CURRENT_PRESERVING_REFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-12.md'
RUNNER = 'scripts/current_preserving_refinement_identity_2026_10_12.py'
CLAIM = 'current_preserving_refinement_bounded_theorem_note_2026-10-12'
DEPS = ['concrete_gapped_chain_bounded_theorem_note_2026-10-12',
        'local_even_continuum_bounded_theorem_note_2026-10-12']
GRAPH = 'docs/audit/data/citation_graph.json'
MANIFEST = 'docs/audit/data/citation_graph_manifest.json'
sys.dont_write_bytecode = True


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return Path(path).read_bytes()


def js(path):
    return json.loads(read(path))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if isinstance(value, bytes) else
                     (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def pin(path):
    data = read(path)
    return {'sha256': sha(data), 'bytes': len(data)}


def preserve_return(folder, stem, value):
    # First operation after the API returns: serialize its complete raw object.
    (folder / (stem + '.raw.pickle')).write_bytes(pickle.dumps(value, protocol=5))
    write(folder / (stem + '.raw.json'), value if isinstance(value, dict) else
          [value[0], str(value[1]) if value[1] is not None else None])


def run_command(run, label, argv, timeout, cwd=WORKTREE):
    folder = run / label
    folder.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    out, err, code, timed_out, launch_error = b'', b'', None, False, None
    try:
        process = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0'})
        try:
            out, err = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            out, err = process.communicate()
        code = process.returncode
    except OSError as exc:
        launch_error = repr(exc)
        err += repr(exc).encode()
    write(folder / 'stdout', out)
    write(folder / 'stderr', err)
    receipt = {'argv': argv, 'cwd': str(cwd), 'started_utc': started,
        'finished_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - start, 'timeout_seconds': timeout,
        'timed_out': timed_out, 'exit_code': code, 'launch_error': launch_error,
        'stdout_sha256': sha(out), 'stderr_sha256': sha(err),
        'stdout_bytes': len(out), 'stderr_bytes': len(err)}
    write(folder / 'execution.json', receipt)
    need(not timed_out and launch_error is None and code == 0,
         'Command failed; complete streams retained: ' + label)
    return out


def git_read(run, label, *args):
    return run_command(run, label, ['git', *args], 60)


def syntax_metadata_links(run, inputs):
    import yaml
    source = read(WORKTREE / RUNNER)
    tree = ast.parse(source, filename=RUNNER)
    values = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body
        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
        and n.targets[0].id in ['AUDIT_TIMEOUT_SEC', 'AUDIT_INPUT_PATHS']}
    need(values['AUDIT_TIMEOUT_SEC'] == 60 and values['AUDIT_INPUT_PATHS'] == inputs,
         'Primary declarations differ')
    text = read(WORKTREE / NOTE).decode()
    front = yaml.safe_load(text.split('---', 2)[1])
    expected = {'claim_id': CLAIM, 'claim_type': 'bounded_theorem',
        'target_claim_type': 'bounded_theorem', 'actual_current_surface_status': 'conditional-support',
        'upstream_dependencies': DEPS, 'runner': RUNNER, 'artifact_role': 'theorem',
        'bare_retained_allowed': False, 'audit_required_before_effective_retained': True}
    need(all(front.get(k) == v for k, v in expected.items()), 'Metadata mismatch')
    need(all(k in front for k in ['trace_class', 'target_claim_id', 'target_blocker_text',
        'source_of_blocker_text', 'reachability_to_target', 'conditional_surface_status',
        'hypothetical_axiom_status', 'admitted_observation_status', 'claim_type_reason',
        'next_trace_action']), 'Required trace metadata absent')
    links = []
    for path in [WORKTREE / NOTE, *sorted((WORKTREE / PACKET).glob('*.md'))]:
        text = re.sub(r'(?m)^(?: {4}|\t).*(?:\n|$)', '', path.read_text())
        text = re.sub(r'```[\s\S]*?```|~~~[\s\S]*?~~~|`[^`]*`', '', text)
        for target in re.findall(r'\]\(([^)\s]+)\)', text):
            if target.startswith(('http:', 'https:', '#', 'mailto:')):
                continue
            dest = (path.parent / target.split('#', 1)[0].strip('<>')).resolve()
            need(dest.is_relative_to(WORKTREE) and dest.is_file(), 'Broken local link: ' + target)
            links.append({'source': str(path.relative_to(WORKTREE)), 'target': target})
    write(run / 'metadata_syntax_links.json', {'frontmatter': front, 'links': links,
        'primary_python_syntax_parsed': True, 'scientific_predicates_executed': 0})
    report = run / 'vocabulary.json'
    run_command(run, 'vocabulary', [sys.executable, 'scripts/vocab_lint.py', '--report-only',
        '--report-path', str(report), NOTE, RUNNER, PACKET], 120)
    result = js(report)
    need(result['summary']['total_auto_correctable'] == 0 and
         result['summary']['total_needs_human'] == 0, 'Vocabulary requires root review; no auto-fix')


def canonical_identity(cache, run):
    folder = run / 'canonical_identity'
    folder.mkdir()
    original = cache.execute_runner
    inner = []
    def capture(*args, **kwargs):
        value = original(*args, **kwargs)
        preserve_return(folder, 'INNER', value)
        live = value.get('live_log')
        if live and Path(live).exists():
            write(folder / 'INNER.complete_merged_live_log', read(live))
        inner.append(value)
        return value
    cache.execute_runner = capture
    try:
        outer = cache.execute_and_write_cache(RUNNER, 60)
        preserve_return(folder, 'OUTER', outer)
    except BaseException:
        write(folder / 'OUTER.exception.txt', traceback.format_exc().encode())
        raise
    finally:
        cache.execute_runner = original
    need(len(inner) == 1 and outer[0] == inner[0], 'INNER/OUTER result differs')
    result, path = outer
    write(folder / 'canonical.stdout', result['stdout'].encode())
    write(folder / 'canonical.stderr', result['stderr'].encode())
    need(result['status'] == 'ok' and result['exit_code'] == 0 and
         result['timeout_sec'] == 60 and result['stderr'] == '', 'Canonical identity execution failed')
    need(path == cache.cache_path_for(RUNNER), 'Canonical cache destination differs')
    write(folder / 'canonical.cache', read(path))
    lines = result['stdout'].splitlines()
    need(len(lines) == 6, 'Unexpected identity output; do not infer mathematical predicates')
    report = json.loads(lines[0])
    need(report['result'] == 'source_identities_and_reconstruction_match' and
         report['mathematical_operations_executed'] is False and
         report['no_go_packet_pass_supplied_by_tool'] is False, 'Identity-only meaning changed')
    for prefix, line in zip(['per_element:', 'per_site:', 'per_mode:', 'per_block:', 'lattice_wide:'], lines[1:]):
        need(line.startswith(prefix + ' checked and not executed — source integrity only;'),
             'Resolution statement no longer explicitly excludes scientific execution')
    write(folder / 'interpretation.json', {'identity_result': report,
        'canonical_api_stderr_merged_into_complete_stdout': True,
        'separate_child_stderr_not_available_from_this_API': True,
        'scientific_predicates_executed': 0, 'scientific_mutations_executed': 0,
        'mathematical_proof_verified_by_program': False, 'no_go_packet_pass': False})
    return path


def graph_compare(run, old, before):
    run_command(run, 'graph_after', [sys.executable, 'docs/audit/scripts/run_citation_graph_build.py'], 180)
    run_command(run, 'graph_manifest', [sys.executable, 'docs/audit/scripts/write_citation_graph_manifest.py'], 180)
    graph, after = js(WORKTREE / GRAPH), js(WORKTREE / MANIFEST)
    write(run / 'citation_graph.complete.json', read(WORKTREE / GRAPH))
    write(run / 'citation_graph_manifest.complete.json', read(WORKTREE / MANIFEST))
    need(graph['schema_version'] == old['schema_version'] and
         after['schema_version'] == before['schema_version'], 'Graph schema changed')
    need(set(graph['nodes']) == set(old['nodes']) | {CLAIM} and CLAIM not in old['nodes'], 'Node delta differs')
    need(set(after['nodes']) == set(before['nodes']) | {CLAIM}, 'Manifest node delta differs')
    need(all(graph['nodes'][k] == v for k, v in old['nodes'].items()) and
         all(after['nodes'][k] == v for k, v in before['nodes'].items()), 'Old complete graph node changed')
    old_edges = [(e['from'], e['to']) for e in old['edges']]
    edges = [(e['from'], e['to']) for e in graph['edges']]
    wanted = {(CLAIM, d) for d in DEPS}
    need(all(set(e) == {'from', 'to'} for e in old['edges'] + graph['edges']), 'Edge schema changed')
    need(len(edges) == len(set(edges)) and len(old_edges) == len(set(old_edges)) and
         set(edges) == set(old_edges) | wanted and not wanted & set(old_edges), 'Exact old edges plus two differ')
    for key, row in graph['nodes'].items():
        deps = sorted(row['deps'])
        need(len(deps) == len(set(deps)) and set(deps) == {b for a, b in edges if a == key}, 'Dependency mismatch')
        need(all(d in graph['nodes'] for d in deps), 'Unresolved edge')
        need(after['nodes'][key] == {'out_degree': len(deps), 'deps_hash': sha('\n'.join(deps).encode())[:12]}, 'Topology manifest mismatch')
    node = graph['nodes'][CLAIM]
    need(node['path'] == NOTE and node['runner_path'] == RUNNER and
         node['helper_runner_paths'] == [] and node['note_hash'] == sha(read(WORKTREE / NOTE)) and
         sorted(node['deps']) == sorted(DEPS), 'New graph source differs')
    need(graph['roots'] == sorted(k for k, v in graph['nodes'].items() if not v['deps']), 'Graph roots differ')
    need(after['node_count'] == graph['stats']['node_count'] == len(graph['nodes']) and
         after['edge_count'] == graph['stats']['edge_count'] == len(edges), 'Graph count mismatch')
    delta = {'nodes': after['node_count'] - before['node_count'], 'edges': after['edge_count'] - before['edge_count']}
    need(delta == {'nodes': 1, 'edges': 2}, 'Exact graph delta differs')
    write(run / 'graph.comparison.json', {'delta': delta, 'old_complete_nodes_and_edges_unchanged': True})
    output = run_command(run, 'focused_compatibility', [sys.executable,
        'docs/audit/scripts/check_changed_audit_evidence.py', '--base', BASE, '--include-worktree', '--json'], 120)
    report = json.loads(output)
    need(report['base'] == BASE and report['diff_scope'] == 'committed_and_worktree' and
         not report['failures'] and not report['control_failures'], 'Focused compatibility failed')
    write(run / 'focused_scope.json', {'actually_checked_claims': [r['claim_id'] for r in report['checked']],
        'scope': 'Existing selected ledger compatibility only; no new claim audit or retained verdict.'})
    return delta


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--program-sha256', required=True)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--acceptance', type=Path, required=True)
    parser.add_argument('--acceptance-sha256', required=True)
    args = parser.parse_args()
    need(sha(read(__file__)) == args.program_sha256, 'Root program anchor differs')
    need(WORKTREE == WORKTREE.resolve() and STAGE == STAGE.resolve(), 'Expected resolved paths differ')
    run = S / 'current_preserving_integration_runs' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '_' + uuid.uuid4().hex[:12])
    run.mkdir(parents=True, exist_ok=False)
    phase = 'source_and_clean_child_guards'
    try:
        write(run / 'program.py', read(__file__))
        write(run / 'invocation.json', {'argv': sys.argv, 'interpreter': sys.executable,
            'python': sys.version, 'worktree': str(WORKTREE), 'stage': str(STAGE), 'base': BASE})
        need(sha(read(Q / 'SOURCE_FREEZE.json')) == args.source_freeze_sha256, 'Frozen source package changed')
        acceptance = args.acceptance
        need(sha(read(acceptance)) == args.acceptance_sha256, 'Root execution acceptance changed')
        write(run / 'SOURCE_FREEZE.json', read(Q / 'SOURCE_FREEZE.json'))
        write(run / 'ROOT_ACCEPTANCE.json', read(acceptance))
        accepted = js(acceptance)
        need(accepted['root_authorizes_execution'] is True and all(accepted[k] is True for k in ['source_read', 'program_read', 'packet_read']) and accepted['base'] == BASE and accepted['no_go_packet_pass'] is False, 'Root source acceptance remains incomplete')
        bound_status = js(Q / 'payload' / PACKET / 'SOURCE_REVIEW_STATUS.json')
        need(all(accepted[k] == bound_status[k] for k in ['source_sha256', 'review_sha256', 'gate_sha256', 'parent_receipt_sha256']), 'Root accepted source/review/parent anchors differ')
        freeze = js(Q / 'SOURCE_FREEZE.json')
        for row in freeze['files']:
            path = Q / row['path']
            need(path.resolve().is_relative_to(Q) and pin(path) == {'sha256': row['sha256'], 'bytes': row['bytes']}, 'Frozen support source changed: ' + row['path'])
        payload = {r['path'][8:]: r for r in freeze['files'] if r['path'].startswith('payload/')}
        actual = {str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()}
        need(actual == set(payload), 'Staged payload membership differs')
        for name, row in payload.items():
            p = STAGE / name
            need(not p.is_symlink() and p.resolve().is_relative_to(STAGE) and
                 pin(p) == {'sha256': row['sha256'], 'bytes': row['bytes']}, 'Staged source differs: ' + name)
            need(not (WORKTREE / name).exists(), 'Refuse duplicate or partial install: ' + name)
        need(git_read(run, 'initial_head', 'rev-parse', 'HEAD').decode().strip() == BASE, 'Wrong base')
        need(git_read(run, 'initial_branch', 'branch', '--show-current').decode().strip() == BRANCH, 'Wrong branch')
        need(not git_read(run, 'initial_status', 'status', '--porcelain=v1', '-z', '--untracked-files=all'), 'Child is not clean')
        before = js(WORKTREE / MANIFEST)
        write(run / 'base_graph_manifest.json', read(WORKTREE / MANIFEST))
        need(git_read(run, 'base_manifest', 'show', BASE + ':' + MANIFEST) == read(WORKTREE / MANIFEST), 'Base manifest differs')
        old_bytes = gzip.decompress(read(Q / 'base_graph.json.gz'))
        old = json.loads(old_bytes)
        write(run / 'base_graph.json', old_bytes)
        need(set(old['nodes']) == set(before['nodes']), 'Base graph/manifest membership differs')
        phase = 'install_reviewed_sources'
        for name in sorted(payload):
            target = WORKTREE / name
            target.parent.mkdir(parents=True, exist_ok=True)
            need(target.parent.resolve().is_relative_to(WORKTREE), 'Install parent escaped worktree')
            with target.open('xb') as handle:
                handle.write(read(STAGE / name))
        tree = ast.parse(read(WORKTREE / RUNNER))
        inputs = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'AUDIT_INPUT_PATHS')
        immutable = {name: pin(WORKTREE / name) for name in set(inputs) | {RUNNER}}
        write(run / 'declared_input_identities.json', immutable)
        syntax_metadata_links(run, inputs)
        phase = 'canonical_identity_only'
        sys.path.insert(0, str(WORKTREE / 'scripts'))
        spec = importlib.util.spec_from_file_location('runner_cache', WORKTREE / 'scripts/runner_cache.py')
        cache = importlib.util.module_from_spec(spec)
        sys.modules['runner_cache'] = cache
        spec.loader.exec_module(cache)
        need(cache.REPO_ROOT.resolve() == WORKTREE, 'Wrong cache repository')
        cache_path = canonical_identity(cache, run)
        phase = 'graph_and_focused_compatibility'
        delta = graph_compare(run, old, before)
        previous = ['concrete_gapped_chain', 'local_even_continuum', 'continuum_local_boost',
            'microscopic_local_boost_limit', 'mixed_local_poincare_correlations',
            'dyadic_even_refinement', 'state_adapted_refinement', 'energy_adapted_refinement',
            'sharp_current_refinement_identity']
        paths = [RUNNER] + ['scripts/' + n + '_2026_10_12.py' for n in previous]
        statuses = {p: cache.cache_status(p) for p in paths}
        write(run / 'cache_freshness.json', statuses)
        need(set(statuses.values()) == {'fresh'}, 'Current or inherited milestone cache is not fresh')
        need({n: pin(WORKTREE / n) for n in immutable} == immutable, 'Declared identity input changed')
        result = {'status': 'actual_source_integration_and_identity_checks_completed', 'base': BASE,
            'graph_delta': delta, 'cache_statuses': statuses, 'scientific_predicates_executed': 0,
            'scientific_mutations_executed': 0, 'mathematical_proof_verified_by_program': False,
            'no_go_packet_pass': False, 'N1': 'pending', 'N5': 'pending',
            'canonical_stderr_merged_into_complete_stdout': True,
            'audit_verdict_applied': False, 'retained_promotion': False, 'git_mutation': False,
            'later_landing_obligations': ['combined current-main validation', 'strict audit lint', 'formal retained audit']}
        write(run / 'VERIFICATION_RESULT.json', result)
        packet = WORKTREE / PACKET
        rows = []
        for p in sorted(run.rglob('*')):
            if p.is_file():
                data = read(p)
                relative = 'integration_evidence/' + str(p.relative_to(run)) + '.gz'
                packed = gzip.compress(data, mtime=0)
                write(packet / relative, packed)
                rows.append({'source': str(p), 'path': relative, 'sha256': sha(data),
                             'stored_sha256': sha(packed), 'bytes': len(data)})
        write(packet / 'INTEGRATION_EVIDENCE_MAP.json', {'files': rows, 'scientific_predicates_executed': 0})
        write(packet / 'INTEGRATION_RESULT.json', result)
        expected = set(payload) | {str(p.relative_to(WORKTREE)) for p in packet.rglob('*') if p.is_file()} | {str(cache_path.relative_to(WORKTREE))}
        need(git_read(run, 'final_head', 'rev-parse', 'HEAD').decode().strip() == BASE, 'HEAD changed')
        records = [x.decode() for x in git_read(run, 'final_status', 'status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0') if x]
        need({x[3:] for x in records} == expected | {MANIFEST}, 'Final publication footprint differs')
        need(all(x[:2] == (' M' if x[3:] == MANIFEST else '??') for x in records), 'Tracked source/index changed')
        need({n: pin(WORKTREE / n) for n in immutable} == immutable, 'Late archive changed an identity input')
        need(all(cache.cache_status(p) == 'fresh' for p in paths), 'Late archive changed cache freshness')
        # Generate PR prose only after actual checks; no scientific TOTAL/PASS.
        actual_text = ('Root execution verified source identities and exact publication reconstruction, '
            'parsed primary syntax, checked metadata/local links and vocabulary, generated the exact '
            'one-node/two-edge graph delta with all prior nodes/edges unchanged, completed focused '
            'existing-ledger compatibility and checked ten cache identities. The canonical tool '
            'executed zero scientific predicates and zero mutations; merged stdout/stderr and complete '
            'INNER/OUTER records are preserved. N1/N5 remain pending, with no no-go packet PASS. '
            'Combined current-main landing validation, strict audit lint and formal retained audit '
            'remain later obligations. No audit verdict or retained promotion was applied.')
        proposed = (Q / 'PR_BODY.proposed.md').read_text()
        first = proposed.index('Validation at scaffold creation:')
        last = proposed.index('\n\nIndependent proof review', first)
        proposed = proposed[:first] + actual_text + proposed[last:]
        marker = '\nSource-freeze update:'
        if marker in proposed:
            proposed = proposed.split(marker, 1)[0].rstrip() + '\n'
        write(run / 'PR_BODY.ready.md', proposed.encode())
        write(run / 'FINAL.json', {'status': 'completed', 'exact_added_paths': sorted(expected),
            'only_tracked_change': MANIFEST, 'graph_delta': delta, 'scientific_predicates_executed': 0,
            'root_publication_required': True, 'all_declared_inputs_unchanged': True})
        phase = 'completed'
        print(json.dumps({'status': 'completed', 'run': str(run), 'graph_delta': delta,
            'scientific_predicates_executed': 0, 'root_publication_required': True}))
    except BaseException as exc:
        write(run / 'FAILURE.json', {'phase': phase, 'exception': repr(exc),
            'traceback': traceback.format_exc(), 'automatic_retry': False,
            'partial_installed_files_and_prior_streams_preserved': True})
        raise
    finally:
        write(run / 'EVIDENCE_MANIFEST.json', {'phase': phase, 'self_excluded': True,
            'files': [{'path': str(p.relative_to(run)), **pin(p)} for p in sorted(run.rglob('*'))
                      if p.is_file() and p.name != 'EVIDENCE_MANIFEST.json']})


if __name__ == '__main__':
    main()
