# Current-preserving refinement: independent mathematical review

## Current disposition

The supplied massive free chain admits coherent real coefficient isometries that preserve the actual normalized current `K_c(q)=sin(cq)/c` and its chosen quasifree state exactly. The complete construction retains both momentum branches at each current value. Its full Hilbert/current and even-CAR limits contain an additional spectral channel beyond the continuum selected by fixed ordinary physical-cell inputs.

**Final focused disposition: supported at the stated supplied-model scope, with no unresolved material mathematical finding.** The complete final author source is SHA-256 `1104de3922002720beecb7eb2bd106b64025aea0afb1e11b8f86750dfb59e30d`. The source-bound review includes the doubled equal-time local quotient, both the all-spacing and dyadic time witnesses, and the finite-scale spatial-shift distinction. It confers no formal retained status.

One literal error was corrected: the two time-limit witnesses B and -B each have norm one; their **norm distance** is two. The original 498-line core remains preserved at SHA-256 `b5a80216d91bb1d525a605ba825c3c46a5130fd47ca4ed7f3444242ca778d637`. The correction and final chronology appendix are the complete source delta; no equation or quantified scientific conclusion changed.

The complete proof is in [INDEPENDENT_FINDINGS.md](current_preserving_refinement_review/INDEPENDENT_FINDINGS.md), SHA-256 `ffcd67002584dfa4d8b55e5d1225c77b8cc375ee076943980cae0769270757cb`. The [seal](current_preserving_refinement_review/independent_seal.json) was written at **2026-10-12 15:30:13.072695 UTC**, before the new author note or helper was opened.

## Findings established in the independent derivation

1. Split the Brillouin circle into the inner and outer inverse branches of `sin(cq)/c`, and use the absolute inverse-Jacobian half-density `r_c(k)^(-1/2)`, where `r_c(k)=sqrt(1-c^2k^2)`. Flatten the chosen polarization with the actual coefficient frame separately on each branch. This is a real unitary to `L^2((-1/c,1/c);C^4)` with current k and polarization `P0 direct_sum P0`. Zero extension gives nested ranges and coherent state/current isometries.
2. The actual energy transported by this map has two positive values `E_c,L/H(k)^2=m^2+(2v^2/c^2)(1 minus/plus r_c(k))`. The refinement defect is their literal difference between spacings, with the coefficient sign matrix C0. Low-channel energy converges to `sqrt(m^2+v^2k^2)` on fixed current compacts. High-channel energy equals `2v/c+O(c)` there and has a divergent dyadic refinement defect. A fixed-time dyadic packet witness prevents a full actual time-flow limit for this construction.
3. Every full current-intertwining coefficient isometry has an almost-everywhere unitary 4-by-4 fibre map on the common current interval. State preservation restricts that map to commute with the flattened polarization. Consequently the full current inductive limit has coefficient spectral multiplicity four, or two after positive polarization. Abstract CAR isomorphism alone does not identify it with the single marked physical continuum carrier.
4. Fixed ordinary cell averages converge to the low channel. Fixed **staggered** cell averages `(-1)^j(C_c f)_j` converge to the high channel. For compactly supported f these remain finite-support coefficient vectors and yield actual local even spin words. Thus high channels are not negligible in the C*-norm limit merely because their energies diverge.
5. The current Cauchy-section algebra strictly contains the Haar Cauchy-section algebra. The latter is exactly the subalgebra of current-Cauchy sequences whose current limit lies in the low even-CAR subalgebra. An explicit even-bilinear trace witness proves strictness. The equality of complete section spaces from the earlier energy-adapted construction cannot be transferred to this one.

## Complete final-source comparison

The entire 498-line frozen author core was read after root authorized exposure, beginning at 15:35:28 UTC. The source agrees with the sealed independent construction after the fixed target coordinate change `(L^-1 direct_sum L^-1) diag(F*,1)`. This changes neither the finite-scale refinement maps nor their exact current/state properties. The final 541-line source was covered by that complete core read plus the complete independently generated final diff, including the full 43-line chronology appendix. The final source was copied and its hash verified at 15:40:50 UTC.

| Author argument | Review result and exact coverage |
| --- | --- |
| C1–C13, sections 2–4 | Actual signs and real involution, both current branches, absolute Jacobian, endpoint null sets, nested ranges, state/current coherence, CAR limit and full current multiplicity agree with the independent proof. The single-copy rank statement is correctly restricted to the marked coefficient/current system. |
| C14–C18, section 5 | Exact energy and group defects checked. The high expansion is uniform on fixed current compacts. The even pair-creation witness has norm one. Both positive all-spacing sequences and the specified dyadic cube-root phases give the claimed nonconvergence. The norm-distance correction is confirmed. No claim of failure at every dyadic time is made. |
| C19–C25, section 6 | Ordinary and alternating physical-cell phases, outer reflection and target high polarization checked. Contraction/density extends each fixed-input result to every L2 vector. Uniform bounded-time convergence on ordinary cells follows despite the small high component's rapid phase. |
| C26–C29, section 7 | Exact paired-cell adjoint normalization checked by integrating each pair. Real unitary extension gives equivalence for all varying norm-convergent even sections. The trace conditional expectation proves the required outer continuity; compact two-envelope words and diagonal approximation prove surjectivity of the whole doubled local quotient. |
| C30 and section 7 tail statement | Grid-shift phase, high-cell parity and the nonconstant low-branch phase witness checked. The fine spectral cutoff proves infinite coefficient support, while ell2 truncation gives quasilocal even-CAR images. No uniform physical-tail claim is made. |
| Sections 1, 8–9 | Conditional premises, comparison-only sources, coauthor exposure and remaining physical-selection scope are explicit. The final appendix changes provenance/status description only. Formal review/audit promotion is not supplied by the author note. |

The additional detailed proofs are in [SECTION_COMPARISON_ADDENDUM.md](current_preserving_refinement_review/SECTION_COMPARISON_ADDENDUM.md), SHA-256 `fbb63e0299de54528b48c20d7006a42bb1d29c71e97fa9bb4e95fd5e029e6c96`. This addendum was written after author exposure and is labeled accordingly. Its first two sections fully spell out the all-bounded-even-sequence characterization and an explicit compact-support staggered local-spin pair already present in the independent seal. Its paired-cell local quotient verification is a check of the newly exposed author argument.

The final author manifest is SHA-256 `0b532e0f7ca31108f1fca7d8a6d2685f3dba45aaac80cf38a648e52f8635f520`. At 15:42:03 UTC all 33 manifest identities, all 14 files in the independent seal, and all three original parent identities matched. The [identity refresh](current_preserving_refinement_review/FINAL_IDENTITY_REFRESH.json) is bookkeeping, not mathematical evidence. The immutable independent seal itself still has SHA-256 `bf11ae489d90b50dda3e2cb05bedb1485294f5348428d48bcfe2bf376d7efa78`.

## Source identities and review limits

The three inputs were verified against the assigned hashes and copied before reading their mathematical contents:

| Input | SHA-256 | Use |
| --- | --- | --- |
| CONCRETE_GAPPED_CHAIN_PROBE.md | `0aebc2ded245d9bc9ecae364db0d1a042f9642771ed788794dafd73fb7f621bd` | Actual coefficient matrix, even JW, selected state and current normalization |
| LOCAL_EVEN_CONTINUUM_PROBE.md | `7be1a72e2b59c5c61b68ead6d663e8d4e179b21e2497243a2859a4082ea7813b` | Scaling, signs, covariance, physical cell maps and specified continuum |
| ENERGY_ADAPTED_REFINEMENT_PROBE.md | `65d49c82eb14b88e4880983eb8b41ecb5141cb0ff00f4e5e4760bbb12a151b9d` | Earlier refinement and exact contrast of the current/energy coordinates |

The [source manifest](current_preserving_refinement_review/source_manifest.json) records paths, sizes and the read-only Git identities. The worktree HEAD at initial read was `f85656c1766536299c8bafdb91db6dd1dfbd5e2d`; the locally available origin/main instruction revision was `34ab62523138756eded9bdcc8a35fd2ff61f926f`, and planning instructions were `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. No fetch or Git mutation was performed because this worker's scope forbids Git writes. No clean-tree or whole-repository claim is made; root publication work is concurrent.

The neutral plan bears the initial clock timestamp 15:16:52 UTC and was written before opening mathematical inputs. Source snapshots were verified at 15:17:58 UTC. The first combined instruction output was truncated; it was not treated as completed reading, and the required instruction and proof-source passages were subsequently read with complete output. Relevant complete parent passages and inherited theorem boundaries are itemized in the independent proof. The parents' full transitive external theorem chains were not re-audited.

This is a pure proof check. No numerical executable, numerical PASS, Lean result, empirical prediction, or new physical axiom was invented. The inherited selected model/reasoning profile was kept; no delegation occurred. The root is a disclosed coauthor. Separate context and pre-exposure sealing do not make this a different-family check or remove shared-parent dependence.

The no-go scope record in the independent proof distinguishes explicit rank/packet counterexamples from a universal impossibility claim. No five-family mechanical no-go packet PASS is claimed. The complete doubled **equal-time** local quotient is now verified by the source comparison. A time-covariant doubled continuum net for this unmodified energy is excluded by the explicit time witness; limiting boosts and arbitrary mixed-flow claims were not examined. The chosen dynamics, state, m,v and current normalization remain supplied model data, and the additional spectral channel is not identified as a new light particle.

Only this review file and its supporting directory are editable outputs. No prompt file, platform instruction, audit verdict, Git/worktree state or publication surface was changed by this worker.
