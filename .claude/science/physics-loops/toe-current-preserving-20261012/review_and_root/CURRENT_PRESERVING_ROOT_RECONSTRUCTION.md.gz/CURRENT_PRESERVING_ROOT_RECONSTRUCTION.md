# Root reconstruction before author or independent-checker findings

This is a separate root calculation for the question dispatched on October 12,
2026. It has not yet been compared with either worker's answer. Root chose the
question and is a coauthor; no blinded or independent-family claim. Source
premises are the exact Concrete, Local-even-continuum and Energy-adapted
sources named in the dispatch. This is provisional analytic work, with no
scientific executable, retained verdict or publication decision.

## Exact current coordinates require both folds

Use the supplied coefficient space L2(B_c;C2), B_c=(-pi/c,pi/c), actual
K_c(q)=sin(cq)/c and D_c(q). The actual frame F_c gives
F_c D_c F_c*=E_c C0 and F_c P_c F_c*=P0, with the exact parent conventions.
Set I_c=(-1/c,1/c), z_c(k)=sqrt(1-c^2 k^2). There are two inverse branches:

    q_c,0(k)=arcsin(ck)/c,
    q_c,1(k)=sgn(k)pi/c-arcsin(ck)/c.

The value at k=0 on the second branch and the endpoints are irrelevant null
sets; the second branch consists of the two outer quarter-circle intervals.
Both absolute Jacobians equal 1/z_c(k). Thus

    (T_c h)_sigma(k)=z_c(k)^(-1/2) F_c(q_c,sigma(k)) h(q_c,sigma(k))

is onto L2(I_c;C2_branch tensor C2_component). Norm equality follows by
integrating separately on the two monotone branches; the inverse uses the
square-root Jacobian. These statements extend from a dense compact core in
both directions. The singular endpoint factor is not a bounded multiplier on
one fixed measure, and need not be. Fourier transform is understood before
T_c when h is a lattice coefficient sequence.

q_sigma(-k)=-q_sigma(k) almost everywhere and F_c(-q)=conj(F_c(q)). Therefore
the transported real involution is componentwise conjugation and reflection
in k, without exchanging branch labels. K becomes k times the identity;
the chosen covariance becomes I_branch tensor P0.

For 0<b<a, extension by zero i_ba on both branch channels is a real isometry.
G_ba=T_b* i_ba T_a preserves chosen state and current exactly. The inclusions
compose, so G_cb G_ba=G_ca. There is no frame or arbitrary multiplicity choice
between adjacent steps. The real maps induce isometric CAR embeddings and
their restrictions to the even algebra.

## Actual energy distinguishes the branches

In these coordinates the two positive energy magnitudes satisfy

    E_c,0(k)^2=m^2+(2v^2/c^2)(1-z_c(k)),
    E_c,1(k)^2=m^2+(2v^2/c^2)(1+z_c(k)).

The full generator is diag(E_c,0 C0,E_c,1 C0). Consequently its refinement
defect is exactly multiplication by E_b,sigma-E_a,sigma followed by inclusion
and C0. This is an actual-energy statement, not a dispersion chosen afterward.
For nonzero k, E_a,0>E_b,0, while E_b,1>E_a,1 everywhere. The central equality
at k=0 is a null-set exception, not an exact time-intertwining subspace.

At fixed compact k sets as c tends to zero,

    E_c,0(k)=sqrt(m^2+v^2k^2)+O(c^2),
    E_c,1(k)=2v/c+c(m^2-v^2k^2)/(4v)+O(c^3),

uniformly on each such compact, for fixed m,v>0. The second follows by a
Taylor expansion of z_c and then the positive square root. The first follows
from E_c,0^2=m^2+2v^2k^2/(1+z_c). On fixed central windows the energy mismatch
is O(a^2) for b=ra. On the other branch it diverges as 2v(1/r-1)/a.

One optional exact norm calculation remains to check against the worker:
both E_a,0-E_b,0 and E_b,1-E_a,1 increase with |k| on the coarse band. Their
derivatives are controlled by E_c,sigma z_c; as functions of z, both products
increase. For the outer branch use E_c,1^2=m^2+2v^2k^2/(1-z_c).
The outer difference dominates the central one because E_c,0+E_c,1 increases
with 1/c: its square equals

    2m^2+4v^2/c^2+2sqrt(m^4+4v^2(m^2+v^2k^2)/c^2).

Thus on a current band |k|<=P the full defect norm should be
E_b,1(P)-E_a,1(P), and the central restricted norm E_a,0(P)-E_b,0(P).
The multiplier identity above is sufficient without using this optimization.

## Inductive limit and physical inputs are different objects

For spacings tending to zero, the coefficient inductive limit is
H_inf=L2(R;C2_branch tensor C2_component), because the current intervals
exhaust R on each branch. The chosen covariance and current are respectively
I_branch tensor P0 and multiplication by k. The even CAR inductive limit is
the even CAR algebra of this doubled real coefficient space, by density and
continuity. No algebraic nonisomorphism of abstract separable CAR algebras is
being asserted: the branch and specified-action identifications matter.

Let C_c be physical cell averaging of f in L2(R_x;C2). In these coordinates
the proposed strong limit is

    T_c C_c f -> (F_0(k) Fourier(f)(k), 0).

To prove it, first use compact Fourier support. The exact alias formula of
the pinned local parent leaves only a fixed bounded q interval for small c,
which lies entirely on the central branch. Its inverse current coordinate
and Jacobian converge uniformly on a fixed compact; the frame and cell
factor converge too. Density and the uniform contraction bound finish the
all-L2 statement. This gives only the central sector of H_inf. A fixed
nonzero outer-branch vector supported in I_a retains its norm under every
later inclusion and is orthogonal to all these limiting physical cell inputs.
It cannot be discarded merely because smooth fixed physical inputs miss it.

## A precise time-limit counterexample to check

Along c_n=a0/2^n choose t=pi*a0/(3v). For a compactly supported outer-branch
vector in the C0=+1 eigenspace,

    exp(i t E_c_n,1(k))=exp(i (2pi/3)2^n)+o(1)

uniformly on its compact support. The scalar phase alternates between the
two cube roots of unity. These vectors therefore give no strong limit of
the actual coefficient time groups on all H_inf at this fixed time. This
is a counterexample for this concrete dyadic family, not a theorem about all
other constructions or all subsequences/times.

The failure can also be witnessed inside the even algebra. Choose orthogonal
compactly supported outer vectors f,g in the +1 eigenspace of C0. Their
conjugates lie in the opposite eigenspace, so the normalized complex CAR
fields have the usual two-mode relations. Their nonzero pair product has
norm one. Under actual time evolution its leading phase is
exp(i (4pi/3)2^n); the two subsequential limits again differ. The small uniform
phase errors tend to zero on each field and hence on the pair by telescoping.
Unlike a number projection, this even pair detects the common rapid phase.
Check creation/annihilation sign against the parent's convention; either sign
has the same nonconvergence. No full-algebra norm estimate is required.

A fixed positive-energy cutoff removes the outer one-particle branch for all
sufficiently small c, since inf E_c,1=sqrt(m^2+2v^2/c^2). Extending that
observation to physical observable or many-body selection requires its own
stated representation/domain argument; it is not a new physical axiom here.

The spectral multiplicity of the coarse actual current is four (two folds
times two components), whereas the specified single-continuum current k on
L2(R;C2) has multiplicity two. Exact all-time current intertwining into that
single target would force an isometric fiber map C4 to C2 on a finite band,
which cannot exist. This last generalization should remain a separate scoped
proof obligation until its spectral-intertwining hypotheses are checked; it
is not necessary to establish the explicit doubled construction above.

## Open checks before reuse

Confirm exact parent frame/polarization and Fourier normalizations, compare
the fresh author/checker constructions after their seals, verify the physical
cell strong-limit proof and even pair witness, and keep doubled Hilbert limit,
selected physical sector and any low-energy restriction distinct. No full
single-species dynamical inductive limit, framework-level selection or extra
physical degree of freedom has been established by this preliminary note.
