# Independent current-preserving refinement derivation

This text was derived without opening `CURRENT_PRESERVING_REFINEMENT_PROBE.md`, its helpers, or a root candidate construction. The assignment supplied the target current and the three exact parent notes. The neutral plan was frozen first. This is an ordinary mathematical proof check, not an executable certificate, a formal audit, or a new physical premise. The supplied chain and chosen state remain premises.

## 1. Exact conventions and dependency boundary

Fix `m,v,a0>0` and `a_n=a0*2^(-n)`. For a spacing `c`, put

```
H_c = l^2(Z; C^2),     B_c=(-pi/c,pi/c),
(L_c z)(q)=sqrt(c/(2pi)) sum_j z_j exp(-icqj),
Gamma_c z=bar(z),      (L_c Gamma_c z)(q)=bar((L_c z)(-q)).
sigma_c=sqrt(m^2/4+v^2/c^2),
g_c=sigma_c/2+m/4,    J_c^hop=sigma_c/2-m/4,
D_c(q)=-2J_c^hop sin(cq) sigma_x-2(g_c-J_c^hop cos(cq)) sigma_y,
E_c(q)^2=m^2+(4v^2/c^2) sin^2(cq/2),
theta_c(q)=arg(g_c-J_c^hop exp(-icq)),
F_c(q)=exp(-i theta_c(q) sigma_z/2),
C0=-sigma_y,          P0=(1+C0)/2,
F_c D_c F_c*=E_c C0,  P_c=F_c* P0 F_c.
```

`Re(g_c-J_c^hop exp(-icq))>0`, so the argument is the continuous periodic branch with theta odd and theta(0)=0. In particular `F_c(-q)=bar(F_c(q))`. The actual selected state has real-field covariance `2<z,P_c w>`; the inner product is conjugate-linear in its first argument. The actual coefficient time group is `exp(+it D_c)`.

The actual current in Concrete C28 is `4J_c^hop g_c sin(cq)`. Thus its stipulated normalization `(c/v^2)P_actual` acts on coefficients as

```
K_c(q)=sin(cq)/c times I_2.
```

Its reality relation is `Gamma_c K_c Gamma_c=-K_c`; it is its exponential `exp(+it K_c)` that preserves real coefficient vectors. The current is not `q`, and is not the energy-adapted parent's monotone coordinate `2sin(cq/2)/c`.

Exact parent identities and relevant complete passages read: Concrete sections 1–2 and 5–7 (C1–C6 and C13–C29); Local Even Continuum sections 1–6 through L25 (chosen scaling, coefficient signs, covariance, cell maps, continuum Dirac operator and even JW); Energy Adapted Refinement E1–E22 and its sign/quantifier clarification, used as an explicitly supplied earlier construction. This does not re-audit the parents' external spin-flow existence theorems, full transitive claim chain, or numerical records.

## 2. The two current branches and exact real change of measure

Let `I_c=(-1/c,1/c)` and `r_c(k)=sqrt(1-c^2 k^2)`. Away from the null set `k=0`, define

```
q_c,L(k)=arcsin(ck)/c,
q_c,H(k)=(sgn(k)*pi-arcsin(ck))/c.
```

The first branch covers `|q|<pi/(2c)`. The second covers the two outer arcs `pi/(2c)<|q|<pi/c`. The apparent jump of the second branch at zero is the Brillouin-circle seam. Both obey `q_c,s(-k)=-q_c,s(k)` away from that seam, and both have `|dq_c,s/dk|=1/r_c(k)`. At each `k` in the open interval except null sets there are exactly two preimages. The two ramification endpoints have zero measure and need no assigned L2 values.

Define the unitary

```
V_c:H_c -> L^2(I_c,dk; C^2_L direct_sum C^2_H),
(V_c z)_s(k)=r_c(k)^(-1/2) F_c(q_c,s(k)) (L_c z)(q_c,s(k)).
```

Change of variables on each open arc gives

```
sum_s integral_Ic |(V_c z)_s(k)|^2 dk
 = integral_Bc |(L_c z)(q)|^2 dq = ||z||^2.
```

Conversely multiply the chosen branch component by `r_c(k)^(1/2)F_c(q)*` and use `k=sin(cq)/c` on that arc. This gives an L2 inverse, proving onto-ness. No extra factor `1/sqrt(2)` is allowed: the two branch contributions are a direct sum, not two copies added into one component. The inverse-Jacobian factor diverges at the folds like distance^(-1/4), but its square is integrable and the unitary calculation is exact.

In this representation

```
Gamma Psi(k)=bar(Psi(-k)),
V_c K_c V_c*=M_k I_4,
V_c P_c V_c*=Pflat := P0 direct_sum P0,
V_c D_c V_c*=diag(E_c,L(k) C0, E_c,H(k) C0),
E_c,L(k)^2=m^2+(2v^2/c^2)(1-r_c(k)),
E_c,H(k)^2=m^2+(2v^2/c^2)(1+r_c(k)).
```

`Gamma Pflat Gamma=1-Pflat`, as required for the Majorana quasifree covariance. Current multiplicity is four on the complex coefficient space, and two after restricting to the positive polarization. Each energy branch has one positive and one negative coefficient eigenline. The branch energies coincide only at the current-fold endpoints; those endpoints have zero measure. At current zero the low energy is m and the high energy is `sqrt(m^2+4v^2/c^2)`.

## 3. Constructive answer: coherent real current-and-state refinements exist

Take

```
Hinf=L^2(R,dk; C^2_L direct_sum C^2_H),
J_c=i_c V_c,       Q_c=M_(1_Ic) I_4,
G_(b,a)=V_b* i_(b,a) V_a=J_b* J_a    (0<b<a),
```

where each `i` is extension by zero. All maps preserve the displayed real structures. Their ranges are exactly `L^2(I_c;C^4)`, so they are nested and exhaust Hinf along `a_n -> 0`. Consequently

```
G_(b,a)*G_(b,a)=1,
G_(d,b)G_(b,a)=G_(d,a),
K_b G_(b,a)=G_(b,a) K_a,
G_(b,a)* P_b G_(b,a)=P_a.
```

The last equation also follows from the stronger projection intertwining. On either branch, the explicit fine Fourier coefficient is

```
(L_b G_(b,a)z)(q_b,s(k))
 = sqrt(r_b(k)/r_a(k))
   F_b(q_b,s(k))* F_a(q_a,s(k)) (L_a z)(q_a,s(k)),   |k|<1/a,
```

and is zero on the rest of the fine Brillouin zone. This checks the isometry, branch labeling and cocycle directly. The two branch matrices and weights cancel separately under composition.

Real isometries induce injective isometric unital maps of CAR algebras, first on finite Clifford algebras and then by norm completion. Their even restrictions, transported by the compatible even JW maps of the parents, give actual even-spin algebra embeddings. Quasifree two-point preservation gives preservation of all even moments and hence of the state by norm density. Current group intertwining is exact on real fields and therefore on the complete even algebras. The full inductive limit is

```
CAR(Hinf_R)^even,
omega_inf(c(Psi)c(Phi))=2<Psi,Pflat Phi>,
Kinf=M_k,  Dom Kinf={Psi : k Psi in L^2}.
```

Every finite-scale image lies in `Dom Kinf`, since k is bounded on I_c. Polynomial density and density of the increasing real one-body ranges identify the full C*-inductive limit, not just a selected collection of observables. No actual limiting energy or boost is defined by these statements.

## 4. Exact energy defect and a high-channel time witness

For this branch-preserving construction the transported coefficient defect is exactly

```
V_b(D_b G_(b,a)-G_(b,a)D_a)V_a*
 = i_(b,a) diag((E_b,L-E_a,L) C0, (E_b,H-E_a,H) C0).
```

For `b<a` and `0<|k|<1/a`, the low difference is negative and the high difference positive. For the low branch, rationalization gives

```
E_c,L(k)^2 = m^2 + 2v^2 k^2/(1+r_c(k)),
E_c,L(k)-E0(k)
 = v^2 c^2 k^4 / [(1+r_c(k))^2 (E_c,L(k)+E0(k))],
E0(k)=sqrt(m^2+v^2 k^2).
```

Thus low-channel energy converges uniformly on every fixed compact current interval, with an O(c^2) bound. For example `0<=E_c,L-E0<=v^2 c^2 M^4/(2m)` for `|k|<=M<1/c`. This statement excludes the cutoff moving with 1/c.

For the high branch,

```
E_c,H(k)-2v/c
 = [m^2-2v^2 k^2/(1+r_c(k))]/[E_c,H(k)+2v/c] = O(c)
```

uniformly on each fixed compact current interval. In particular, with `b=a/2`, the high-channel energy defect is `2v/a+O(a)`, not a vanishing error. The underlying vectors have unchanged norm under all refinements. Their high energy supplies no CAR norm suppression.

Energy-flow failure occurs on even observables too. On a low positive-polarization packet supported where `E_b,L-E_a,L` varies, the two time evolutions give different rank-one packet number projections for some t. The difference is nonconstant because it is analytic, zero at k=0 and strictly negative away from zero; equality of every packet number projection would require a constant relative phase on its support. This is a witness against the specified map, not a universal result about arbitrary renormalizations.

There is an explicit failure of a full strong time limit in this common embedding. Let

```
T_n(t)=J_(a_n) exp(itD_(a_n)) J_(a_n)* + 1-Q_(a_n),
t0=pi*a0/(3v).
```

On a fixed nonzero high-channel packet of compact k support and positive polarization,
`T_n(t0)Psi = [exp(i*2*pi*2^n/3)+o(1)]Psi` in norm. Even and odd n approach distinct phases. Their norm difference approaches `sqrt(3)||Psi||`. Real packets follow by adding their Gamma-related negative-polarization parts. Multiplying a real high field by a nonzero orthogonal real low field yields an even CAR witness; the low time evolution converges while the high rotation has these two distinct limits. No full actual energy flow is therefore obtained for this chosen current refinement merely from its state/current coherence.

## 5. Current multiplicity is intrinsic to the full coefficient refinement

For completeness this is not only an artifact of the branch-preserving gauge. Every bounded complex-linear current intertwiner from `L^2(I_a;C^4)` to `L^2(I_b;C^4)` is, on I_a, a measurable matrix multiplier W(k), and vanishes off I_a. One can see this without an unproved multiplicity slogan: current intertwining implies intertwining of spectral projections, then of bounded scalar multipliers; apply the map to each constant coordinate vector on the finite interval I_a, and then to its products with simple functions. Isometry on every measurable subset forces `W(k)*W(k)=I_4` almost everywhere. Hence W is a unitary 4-by-4 matrix almost everywhere.

State preservation is exactly `W*Pflat W=Pflat`, equivalently commutation with Pflat. Realness is `W(-k)=bar(W(k))`. A coherent family is a unitary cocycle on the growing intervals. It can be trivialized along the countable scale chain by choosing a gauge on each newly added shell and recursively cancelling the previous cocycle on the old interval. These gauges retain the real and polarization constraints. Thus all such full coherent coefficient systems have current multiplicity four (positive-polarization multiplicity two) in the direct limit.

In particular there is no isometric current intertwiner of a whole finite-scale H_a into the **specified** single continuum coefficient carrier `L^2(R;C^2)` with current multiplier k: the same simple-function argument would require a 2-by-4 matrix W with `W*W=I_4` almost everywhere on I_a. This is a precise rank statement for these marked currents and full coefficient spaces. Abstract separable Hilbert spaces, or abstract CAR algebras without their marked current/state/embeddings, do not have this obstruction. A branch restriction or a different target current changes the question.

## 6. Fixed physical-cell inputs occupy only the low channel

Retain the actual cell maps

```
(C_c f)_j=c^(-1/2) integral_[cj,c(j+1)] f(x) dx,
j_c=C_c*,   Q_c^cell=j_c C_c ->1 strongly.
```

For smooth compact Fourier support in [-M,M], the parent's alias formula, also obtained directly by integrating the inverse Fourier transform over each cell, reduces for small c to

```
(L_c C_c f)(q)=exp(icq/2) sinc(cq/2) fhat(q).
```

Take `cM<pi/2`. The high branch of `J_c C_c f` is then identically zero. On the low branch it is

```
r_c(k)^(-1/2) F_c(q_c,L(k))
  exp(ic q_c,L(k)/2) sinc(c q_c,L(k)/2) fhat(q_c,L(k)).
```

On its fixed compact support, `q_c,L(k)->k`, `r_c(k)->1`, and
`F_c(q_c,L(k))->F(k)=exp(-i arctan(vk/m) sigma_z/2)` uniformly. The last limit follows by dividing `g_c-J_c^hop exp(-icq)` into its real and imaginary parts, which tend to m/2 and vk/2. Extending fhat by zero and applying dominated convergence gives

```
J_c C_c f -> Wlow f := (F(k) fhat(k), 0).
```

The maps on the left are contractions. Density extends this to every fixed L2 input, including rough real cell indicators. No regularity rate is needed. `Wlow` is a real isometry onto the whole low channel, and

```
Wlow* Pflat Wlow = P,
P(k)=F(k)*P0F(k),
Wlow* Kinf Wlow = physical continuum momentum.
```

The limiting low-channel energy is the supplied massive Dirac energy. Thus the earlier fixed-input continuum remains valid as an embedded subtheory. It does not exhaust the complete current-preserving inductive limit.

## 7. Fixed staggered inputs reveal a further local channel

The extra channel is also visible through finite-support even spin observables, rather than only through abstract high-energy vectors. Let `(S_c z)_j=(-1)^j z_j`. This real lattice unitary leaves the set of occupied cells unchanged. For a smooth compact Fourier-supported f and small c, Fourier translation by pi/c gives

```
(L_c S_c C_c f)(q_c,H(k))
 = exp(-ic q_c,L(k)/2) sinc(c q_c,L(k)/2) fhat(-q_c,L(k)),
```

and the low component is zero. On a fixed current compact set `F_c(q_c,H(k))->I_2`, since its real argument component is of order 1/c while its imaginary component is bounded. The same change-of-measure and density argument yields, for every fixed L2 f,

```
J_c S_c C_c f -> Whigh f := (0, fhat(-k)).
```

This is another real isometry, onto the entire high channel. For compactly supported real f, each lattice coefficient vector remains finitely supported in the same physical cell neighborhood. Even products of two or more such fields are actual local even spin observables. Their current-refinement limits can be nonzero high-channel even elements. This statement does not assign them a finite limiting physical energy: section 4 explicitly prevents that identification.

Here `Gamma_Haar` and `Gamma_current` mean bounded even-spin sequences whose images under `CAR(j_(a_n))` and `CAR(J_(a_n))`, respectively (with the same even JW identification), converge in the corresponding common C*-algebra. The dyadic cell spaces and the current ranges are nested, so these are also their intrinsic inductive-system Cauchy sections.

The full norm-Cauchy section algebra is therefore larger than the Haar section algebra. To make this rigorous, choose any real orthonormal high-channel pair u,v with compact current support and put `z_n=J_(a_n)*u`, `w_n=J_(a_n)*v` for sufficiently large n. Their current images are constant. For every fixed physical f,

```
<j_(a_n) z_n,f>=<u,J_(a_n) C_(a_n)f> ->0,
<j_(a_n) w_n,f> ->0.
```

Thus the original Haar coefficient images `u_n=j_(a_n)z_n` and `v_n=j_(a_n)w_n` are weakly zero unit vectors. Their even bilinears `B_n=i c(u_n)c(v_n)` cannot be norm Cauchy. In the CAR tracial state, `tau(B_n^2)=1` and

```
tau(B_m B_n)
 = <u_m,u_n><v_m,v_n>-<u_m,v_n><v_m,u_n> ->0
```

for fixed m and n->infinity. Hence the squared tracial L2 distance tends to 2, a lower bound on squared C*-norm distance. The same argument can be made with compactly supported staggered f,g, followed by asymptotically harmless Gram–Schmidt normalization; it then gives local even spin sequences. The sequence index m in this argument denotes a scale index, not the mass parameter.

Conversely every Haar-convergent sequence is current-convergent with limit its `CAR(Wlow)` image. Approximate its Haar limit by a fixed finite field polynomial and use the approximants built from `C_c f`; these converge under both embeddings, and isometry transfers the small residual norm. The reverse implication holds whenever the current limit lies in the low-channel even algebra, by the same approximation. Therefore

```
Gamma_Haar = {x in Gamma_current : ev_current(x) in CAR(Wlow K_R)^even}.
```

The equality of complete Cauchy section spaces from the earlier **energy-adapted** construction cannot be copied to this current construction. No full characterization of the new geometric local net, boost action, or all mixed current/energy scaling words is asserted here. The high local sequences are enough to reject a claim that the fixed ordinary cell inputs exhaust this limit.

## 8. Scope controls and open work

The constructive question has a positive answer under the supplied m,v, chain and chosen-state premises. The proof explicitly retains the two current branches, exact real structure, polarization, folding endpoints, cocycle and CAR norm completion. The extra channel is a spectral channel, not an independently identified relativistic particle species. Only the low channel has the specified finite massive energy limit in this construction.

No formalization or numerical calculation was used. Load-bearing scalar identities were derived algebraically; current multiplicity was checked by the simple-function matrix-rank argument, not by a sampled dispersion plot. Parent spin-flow existence and the parent chosen-state realization are inherited assumptions for this bounded check. There is no new framework axiom, empirical prediction, formal retained result, or whole-repository review.

No-Go Discipline scope record: N1, the actual routes considered are full two-branch spectral transport, alternative current-preserving unitary cocycles, and fixed versus staggered cell sampling. They are not claimed to be five independent search families, and no mechanical no-go packet PASS is claimed. N2, there is no asserted count of independent walls. N3, all model, state, full-space, current, realness and countable-scale hypotheses are explicit. N4, no older failed refinement is used to rule out the present one. N5, the energy and section failures have explicit packet/bilinear witnesses; the finite-scale current-target rank statement is quantified separately. N6, no missing physical axiom is claimed; restricting a branch or changing the target observable is a different marked system. N7, the strongest escape is to select a low-energy/low-current branch or choose another geometric comparison: that can recover the earlier fixed-input continuum, and is explicitly allowed, but is not a full current-preserving isometry into the single marked carrier. N8, the earlier energy-adapted success is preserved as a different construction; it does not eliminate the full current multiplicity in this one. This is a proof-level boundary record, not a submission-ready universal no-go packet.

The proof dependency graph is: supplied coefficient/state/current conventions -> two-branch Jacobian unitary -> nested inclusions and covariance -> coherent CAR/state/current limit. The energy conclusions use only the branch energies in that same unitary. Fixed-input and staggered-input comparisons use the cell Fourier identity and contraction/density, independently of any limiting energy claim. The section-space distinction uses those comparisons plus an explicit CAR trace identity. No branch of this graph imports its desired conclusion.

The inherited selected model/reasoning profile was kept, with no override or subdelegation. Root is a disclosed coauthor of the campaign. Separate context and pre-exposure sealing do not establish a different-model-family check or statistical independence from the three shared parent sources.

Remaining review work is comparison with the final new author source only after this document is sealed and the root authorizes exposure. Additional dynamics or local-net claims in that source require their actual arguments to be checked; none is preaccepted by this seal.
