# Frozen neutral independent plan

Frozen at 2026-10-12 15:16:52 UTC, before opening the three mathematical input notes or the new author target/helpers. The assignment and instruction/skill inventory are the only context seen at this point. The first batched instruction read was truncated and is not counted as fully read.

1. Freeze and verify the exact supplied source identities. Read the three notes completely where they supply the chain, coefficient real structure, quasi-free covariance, normalized current and existing continuum/refinement conventions; do not re-audit their transitive parents.
2. Derive the full Brillouin-zone spectral representation of the normalized current, retaining multiplicity and endpoint null sets. Express the real conjugation and covariance in that representation.
3. Test existence of isometric coherent scale maps by spectral-fibre maps. Do not assume either existence or obstruction. Check exact current intertwining, real structure, state pullback, domains, composition, and possible degeneracy choices.
4. Compute the actual energy transport/defect of any candidate map. Separate fixed bounded-current asymptotics from uniform full-zone claims.
5. Identify the Hilbert and CAR inductive limits of the specified candidate family, and compare their embeddings with physical-cell continuum sampling on a common domain. Retain any extra full-zone channels unless a proved selection mechanism removes them.
6. Independently write and seal findings, with proof obligations and limitations. Only after reporting the seal to the root and receiving comparison authorization, open the author's new source, refresh its identity, and compare complete load-bearing arguments.

Allowed deliverables: CURRENT_PRESERVING_REFINEMENT_REVIEW.md and this current_preserving_refinement_review/ directory. No Git, worktree, publication, audit, other-chat messaging, or delegation actions. This is a pure mathematical check; no numerical check or PASS line is to be invented. The root is a disclosed coauthor and the author is a separate derivation, not automatically a different-family validation.
