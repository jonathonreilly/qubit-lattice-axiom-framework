# Post-seal verification of sections, locality and time

Written after the immutable 15:30:13 UTC independent seal and after authorized first exposure to the complete author core at 15:35:28 UTC. The exposed author hash is `b5a80216d91bb1d525a605ba825c3c46a5130fd47ca4ed7f3444242ca778d637`. The all-sequence low-channel characterization and staggered witnesses were already in the sealed independent proof. The paired-cell full local quotient is an additional author argument checked here after exposure; it is not relabeled as a blind reconstruction. The final review will bind the corrected source identity separately.

## 1. Every bounded even sequence, not only sampled field words

Use the author's physical target gauge `J_c` (ordinary fixed cells tend to `(f,0)`). Let `A_c` be the actual even-spin algebra, `A=CAR(K_R)^even`, `A_*=CAR((K direct_sum K)_R)^even`, and put

```
Phi_c=CAR(j_c) jw_c^(-1): A_c -> A,
Psi_c=CAR(J_c) jw_c^(-1): A_c -> A_*,
iota=CAR(f -> (f,0))|even: A -> A_*.
```

All three maps are isometric. Define Gamma_H and Gamma_C as the bounded sequences whose respective images converge in norm. For a fixed even polynomial p in finitely many real fields `c(f_j)`, let `p_c` be exactly the same even polynomial in lattice fields `c_c(C_c f_j)`, transported to A_c by JW. Its two image limits are

```
Phi_c p_c -> p,
Psi_c p_c -> iota(p).
```

The first follows from `j_c C_c ->1` strongly; the second from author C21. Field norm continuity and finite-product telescoping give norm convergence. Real inputs ensure the CAR relations are those of the actual real coefficient space. Every monomial has even degree, so no odd spin element is invoked.

Suppose `Phi_c x_c -> A`. Given epsilon>0, choose a fixed even polynomial p within epsilon of A. For all sufficiently small c, `||Phi_c x_c-A||<epsilon`, `||Phi_c p_c-p||<epsilon` and `||Psi_c p_c-iota(p)||<epsilon`. Isometry gives `||x_c-p_c||<3epsilon`, hence

```
||Psi_c x_c-iota(A)||<5epsilon.
```

Conversely, if `Psi_c x_c -> iota(A)`, use the same p and p_c, measure `||x_c-p_c||` through Psi_c, and obtain `||Phi_c x_c-A||<5epsilon`. Thus, for all bounded sequences, with no regularity condition on their changing entries,

```
Gamma_H = {x in Gamma_C : ev_C(x) belongs to iota(A)},
ev_C(x)=iota(ev_H(x)) for x in Gamma_H.
```

This uses point-norm approximation on fixed p, not a false uniform approximation over the microscopic local unit ball. Along a dyadic scale chain the ranges of both embedding systems are nested, so image convergence is exactly their intrinsic inductive-system Cauchy condition. On all positive spacings the same proof applies to nets; the single-copy Haar family is then understood as the specified comparison images rather than a nested non-dyadic inductive system.

## 2. A fully explicit local even-spin strictness witness

Fix a bounded open physical interval I. Choose a real nonzero smooth h with compact support strictly inside I, normalize `||h||_2=1`, and set `f=h e_1`, `g=h e_2`. For sufficiently small c, every occupied cell of C_c h is wholly inside I. Write

```
nu_c=||C_c h|| ->1,
z_c=M_c C_c f/nu_c,
w_c=M_c C_c g/nu_c,
X_c=jw_c(i c_c(z_c)c_c(w_c)).
```

The component directions make z_c,w_c exactly orthogonal at every c. The common normalization makes each a real unit vector. Multiplication by M_c does not change the occupied cells. Therefore X_c is an actual finite-support even spin observable supported in I, with norm one and square one. Its current-refinement image tends to

```
X_high=i c((0,Rf))c((0,Rg)),
```

also of norm one. In the reflected physical two-envelope coordinates, remove both R's.

Its Haar coefficient images `u_c=j_c z_c`, `v_c=j_c w_c` are weakly zero. For example, for any fixed physical h0,

```
<u_c,h0>=<J_c z_c,J_c C_c h0> -> <(0,Rf),(h0,0)>=0.
```

For a dyadic sequence let `B_n=Phi_(a_n) X_(a_n)=i c(u_n)c(v_n)`. The CAR tracial state has

```
tau(B_n^2)=1,
tau(B_m B_n)=<u_m,u_n><v_m,v_n>-<u_m,v_n><v_m,u_n>.
```

The second identity is the explicit four-field tracial Wick formula, with the displayed signs. For each fixed m its right side tends to zero as n tends to infinity. Consequently

```
||B_n-B_m||^2 >= tau((B_n-B_m)^2) ->2.
```

If the sequence were norm Cauchy, pick m beyond its Cauchy threshold and then let n grow: this contradicts the displayed bound. Thus Gamma_H is a proper subalgebra of Gamma_C, even among the indicated physically local even-spin sequences. This witness supplies an algebraic channel and no finite-energy particle identification.

## 3. Independent check of the author's paired-cell extension

The author's C26 map pairs the vectors at sites 2j and 2j+1 into their normalized sum u_j and difference v_j, then applies step-cell embeddings of width 2c to each. Direct insertion of cell integrals gives

```
B_c*(f,g)=C_c Q_(2c) f + M_c C_c Q_(2c) g.
```

For example the even coefficient is `(2 sqrt(c))^(-1) integral_pair(f+g)` and the odd coefficient is `(2 sqrt(c))^(-1) integral_pair(f-g)` on both sides. This fixes the normalization and alternating sign without appealing to the desired limit. B_c is a real isometry with range the two-copy step space; its range projection is `Q_(2c) direct_sum Q_(2c)` and tends strongly to 1.

Writing `Jtilde_c=(1 direct_sum R)J_c`, C21 and C24 together with the exact adjoint identity give `Jtilde_c B_c* ->1` strongly. The complements of the two-copy step range and two-copy band range are both infinite-dimensional separable real Hilbert spaces. A real unitary between them exists by real orthonormal bases. For any such choice,

```
V_c=Jtilde_c B_c*+W_c(1-B_c B_c*)
```

is an onto real unitary with `Jtilde_c=V_c B_c`, and

```
||(V_c-1)F||
 <=||Jtilde_c B_c* F-F||+||(1-B_c B_c*)F|| ->0.
```

Since V_c is unitary, `||(V_c*-1)F||=||(1-V_c)F||`, so the adjoints converge strongly too. The induced even-CAR automorphisms and their inverses converge point-norm to the identity. For arbitrary varying images Y_c, if Y_c->Y then

```
||CAR(V_c)(Y_c)-Y||
 <=||Y_c-Y||+||CAR(V_c)(Y)-Y|| ->0.
```

Using the inverse proves the converse. This establishes the same-section equivalence for all bounded norm-convergent even sequences between the paired two-copy Haar comparison and the current comparison. It is fully compatible with section 1: the paired comparison has two continuum envelopes, while the ordinary comparison has one.

## 4. Outer continuity and the complete local quotient

If the original even-spin element is supported on cells wholly in I, B_c can enlarge its physical coefficient support by at most a pair width. Its image lies in `CAR(L2(I_(2c);R^4))^even`. Any norm limit therefore lies in every enlarged local algebra.

The intersection is exactly `CAR(L2(I;R^4))^even`. Here is a justification of the conditional-expectation step in the author core. For a closed real subspace V with orthogonal projection Q, there is a trace-preserving conditional expectation E_Q from real CAR to CAR(V): split each input vector into Qf and (1-Q)f, move the complement fields to one side using their anticommutation, and take their canonical tracial expectation. On a finite field word the resulting formula is a finite sum of products of fields `c(Qf)` and inner-product contractions of the complement vectors. The map is unital positive and contractive by the finite Clifford conditional expectation, and consistent finite-dimensional completion defines it on the full CAR algebra. Here both V and its complement are infinite-dimensional, so the finitely many decomposed vectors can always be padded within each side to even-dimensional finite Clifford matrix algebras. Removing contracted complement fields in pairs makes E_Q parity preserving.

If Q_epsilon->Q strongly, the finite-word formula converges in norm: every projected vector and complement contraction converges, and the field norm equals its real Hilbert norm. Contractivity and polynomial density imply point-norm convergence of E_(Q_epsilon) to E_Q on all CAR elements. For `V_epsilon=L2(I_epsilon;R^4)`, these projections decrease strongly to `L2(I;R^4)`; the boundary points have zero measure. An element in all the enlarged local algebras is fixed by every E_(Q_epsilon), hence by E_Q, proving the required outer continuity, including on the even part.

Conversely a dense set in the doubled local even algebra consists of even words in real compactly supported two-envelope inputs lying strictly inside I. C21/C24 give microscopic local sections approximating every such word; small c keeps their cells wholly inside I. Approximate an arbitrary local element by a sequence of these fixed words and choose successively smaller c thresholds for their norm errors and supports. Diagonal selection supplies a uniformly bounded local section converging to that element. Isometry makes the kernel precisely sections whose microscopic norms tend to zero.

This checks author C29 as a complete **equal-time local C*-quotient**, not merely convergence for a fixed list of sample words. The conditional expectation uses the CAR trace as a mathematical projection; the selected physical covariance remains `P direct_sum P0`. No time-covariant doubled net follows.

## 5. All-scale and dyadic actual-time witness

For fixed outer compact-current positive-polarization packets u,v, the expansion

```
e_c,1(p)=2v/c+c(m^2-v^2p^2)/(4v)+O(c^3)
```

is uniform on their supports. The O(c^3) order follows by expanding `sqrt(1-c^2p^2)` and then the outer square root; fixed m,v and bounded p are essential. Their even creation product B has norm one and obeys

```
alpha_c^time(t)(B)=exp(i4vt/c) B+O(c)
```

in norm for fixed t. For every t!=0 the two positive spacing sequences in the author core produce phases +1 and -1. Their limiting elements are B and -B, of norm distance 2, with each individual norm equal to 1. This is the one wording error identified independently by reviewer and root; the original frozen core is retained, and the corrected final source is bound in the final review.

On dyadic `c_n=c0*2^(-n)`, the author's `t=pi*c0/(6v)` gives phase `exp(i*(2pi/3)*2^n)`, alternating between two distinct cube roots of unity. Their difference has modulus sqrt(3), and the O(c_n) correction vanishes. Thus the dyadic witness is correct. At `t=pi*c0/(2v)` the leading phase is one for every n, so the note correctly avoids asserting failure at every dyadic time. These are actual even-CAR witnesses with the chosen state; they are not just unobservable odd-field phases.

No substantive mathematical defect was found in the complete frozen author core. The one norm-versus-distance wording correction is necessary. No numerical run or new physical assumption is used in these additional checks.
