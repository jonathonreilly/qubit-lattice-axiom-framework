from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
s=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=s/'CURRENT_PRESERVING_REFINEMENT_PROBE.md';assert sha(source)=='1104de3922002720beecb7eb2bd106b64025aea0afb1e11b8f86750dfb59e30d'
manifest=s/'current_preserving_refinement/final_manifest.json';assert sha(manifest)=='0b532e0f7ca31108f1fca7d8a6d2685f3dba45aaac80cf38a648e52f8635f520'
review=s/'CURRENT_PRESERVING_REFINEMENT_REVIEW.md';assert sha(review)=='da47384bb8658c6abbca2e9cec5e75e2a40b55a4c0ef9b75e311ef5eceb23040'
seal=s/'current_preserving_refinement_review/independent_seal.json';assert sha(seal)=='bf11ae489d90b50dda3e2cb05bedb1485294f5348428d48bcfe2bf376d7efa78'
receipt=s/'current_preserving_refinement_review/FINAL_REVIEW_RECEIPT.json';f=json.loads(receipt.read_text());assert f['final_author_source']['sha256']==sha(source)
counts={}
for name,p in [('author',manifest),('independent_seal',seal),('final_review',receipt)]:
 rows=json.loads(p.read_text())['files'];counts[name]=len(rows)
 for r in rows:
  b=Path(r['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
  if 'bytes' in r:assert len(b)==r['bytes']
core=(s/'current_preserving_refinement/frozen/CURRENT_PRESERVING_REFINEMENT_PROBE.md').read_text();assert hashlib.sha256(core.encode()).hexdigest()=='b5a80216d91bb1d525a605ba825c3c46a5130fd47ca4ed7f3444242ca778d637'
a='all-spacing c->0 point-norm time limit exists on C13. Norms of the two\nsubsequential limits differ by 2 on B.';b='all-spacing c->0 point-norm time limit exists on C13. The two subsequential\nlimits have norm distance 2 on B.';assert core.count(a)==1 and source.read_text().startswith(core.replace(a,b))
add=s/'current_preserving_refinement_review/SECTION_COMPARISON_ADDENDUM.md';assert sha(add)=='fbb63e0299de54528b48c20d7006a42bb1d29c71e97fa9bb4e95fd5e029e6c96'
rows=[]
for p in [source,manifest,review,seal,receipt,add,s/'Current_preserving_refinement_root_analytic_read.json',s/'CURRENT_PRESERVING_ROOT_RECONSTRUCTION.md']:
 rows.append({'path':str(p),'sha256':sha(p)})
coverage={'utc':datetime.now(timezone.utc).isoformat(),'files':rows,'mechanical_identity_counts':counts,'source_coverage':'Full498lineoriginal plus complete one-line erratum and43line appendix; final541lines covered. Full independent findings, section comparison addendum and final report read.','load_bearing_checks':['Full-zone2branch realunitary and state/current cocycle','Actualenergy signs and all-scale/dyadic evencreation timewitness','Ordinary/alternatingcell phase/reflection with contractiondensity','Pairedcell B* exactidentity and realunitarysectionequivalence','TracialCARconditionalexpectation outercontinuity and doubledlocalquotientsurjectivity','Currentintertwiner scalar-module multiplicity and markedcarrierboundary','Physicalgridshiftparity and specifiedmap infinitesupport'],'correction':'OriginalB/-Bindividualnormwording corrected to normdistance2; immutable originalpreserved. No formula or quantified conclusion changed.','root_is_coauthor':True,'independent_check':'Separate same-family/same-effort context; neutral plan before target and independent proof sealed before source exposure; extra pairedlocalquotient checked after source exposure.','scientific_runner_executed':False,'lean_formalized':False,'formal_audit':False,'no_go_packet_pass':False,'publication_disposition':'partial_narrowing_proposal','proof_gate':'open_for_regular_review_proposal','publication_execution_pending':True}
(s/'Current_preserving_refinement_root_review_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
(s/'CURRENT_PRESERVING_REFINEMENT_MILESTONE_GATE.md').write_text('''# Current-preserving refinement source gate

Root accepts the exact final author source 1104de3922002720beecb7eb2bd106b64025aea0afb1e11b8f86750dfb59e30d for a regular partial-narrowing review proposal. The separately source-bound final review da47384bb8658c6abbca2e9cec5e75e2a40b55a4c0ef9b75e311ef5eceb23040 leaves no unresolved material mathematical finding. Complete root source, independent derivation, post-exposure section proof and final-report coverage is recorded in Current_preserving_refinement_root_review_coverage.json. Exact source and receipt identities were refreshed mechanically.

The conditional theorem constructs real coherent state/current isometries on the full supplied-chain coefficient space. It proves two-branch multiplicity, the doubled equal-time even-CAR local quotient, ordinary and alternating-cell sectors, and explicit failure of a full actual-time limit for this construction. The low ordinary-cell sector retains the supplied massive time limit. The high branch has diverging energy; no new light particle is identified. The all-spacing and dyadic quantifiers remain distinct. Current-class multiplicity is not a classification of abstract CAR isomorphisms.

The single wording defect about norms versus norm distance is corrected transparently; the original frozen core and exact diff remain. Root is a coauthor. The fresh reviewer used the same selected model and effort in a separate context with a neutral plan and independent derivation sealed before author exposure. The extra paired-cell local quotient was then checked from the complete exposed source. This is neither a blind nor a model-diverse review.

This is ordinary mathematical proof review, without a scientific executable or Lean certificate for this unit. Identity support proves no mathematics. The scoped counterexamples remain in a partial-narrowing proposal; formal N1/N5 no-go packet obligations are pending, no packet PASS is claimed, and remaining restricted-carrier/relaxed-current/changed-dynamics routes are not counted as tested families. No formal retained audit, physical axiom, empirical prediction or framework model/state-selection conclusion follows.

Packaging/execution and regular PR remain distinct next steps. Combined current-main landing validation, strict audit lint and independent retained audit remain later obligations. Two direct mathematical parents are Concrete and Local Even; Energy and Sharp are comparison/stack context, since required alias and spectral formulas are rederived here. Editable prompt files changed: none.
''')
print(json.dumps({'coverage_sha256':sha(s/'Current_preserving_refinement_root_review_coverage.json'),'gate_sha256':sha(s/'CURRENT_PRESERVING_REFINEMENT_MILESTONE_GATE.md'),'review_receipt_sha256':sha(receipt),'counts':counts}))
