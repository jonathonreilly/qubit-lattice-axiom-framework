# Independent review of finite-energy complement weight

**Disposition: PASS at the frozen note's stated conditional mathematical
scope. No required source correction or counterexample was found.** The
defect-to-complement inequality, local energy cutoff, two-term
operator-to-state conversion, optional finite-tube bound, and detector
zero-atom lower bound are supported. This is source review, not an audit
verdict, retained status, physical realization or universal lattice no-go.

The complete reviewed target is `DETECTOR_INDEX_LEAKAGE_PROBE.md`, 405 lines,
SHA-256 `4d1e9b888c6e84881e8d356c42e8da521794c68191ebcebab1c145ced5189747`.
Its author receipt is
`47bf0db5e653961b622953a77d26f345515e8f87fe583c6ce66c8951c0f6a498`.
All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The frozen source and author evidence were not edited.

| Target lines | Mathematical finding and scope |
|---|---|
| 54–111, L2–L7 | With the declared flow `alpha_s^P=Ad exp(-isP_b)`, gamma is implemented by `U=exp(+i q P_b/beta)T_q`. The time is q/beta for generator P_b. The full-algebra identity gamma=id is precisely the identity excluded by the matched finite-range tube theorem. The nonzero UHF representation is faithful; cyclicity then supplies some local C with `(U-1)C Omega!=0`. No separating-vacuum inference is used. |
| 113–126, L8 | UP=P and unitarity give `(U-1)*(U-1)<=4(1-P)`. The coefficient 1/4 is sharp under these abstract hypotheses. A fixed vector may still lie in the complement, so no converse is implied. |
| 128–182, L9–L12 | The interaction sum is bounded by `J_H|X|`; the commutator contributes the factor two. Norm Duhamel and vacuum invariance establish the local H-domain, not just a formal commutator. Reduction by P, the rank-one vacuum, gap, and spectral tail then prove L1. For the existential witness, every finite `E>2h_C/d_C` gives strictly positive complement weight; this threshold is automatically at least m. The narrow-window partition handles spectral atoms and endpoints. |
| 184–221, L13–L17 | The exact identity is `(U-1)A+UA(U*-1)=UAU*-A`. Both terms are necessary. Cyclicity approximates a norm-witness vector for the algebra defect by a normalized local B Omega; it supplies no bound on B's operator norm, support or energy. The two-state squared estimate, normalized denominator `16a^2`, and cutoff subtraction `2(h_AB+a h_B)/E` are correct. Zero AB or window vectors are omitted as stated. |
| 223–274, L18–L21 | The P11 tail and zero-index path arguments do not use an exact global shift identity. Only its interior-error step changes: the triangle inequality gives `epsilon<=Delta_L+e_L`. Thus P8 applies if `Delta_L+e_L+a_L<=kappa<=1`. The stated tail threshold, integer windows, `1<=R<L/2`, strict L20 inequality and `kappa>e_L+a_L` are all needed and retained. Monotonicity of g yields the strict lower bound. The proposed kappa gives admissible sufficiently large finite L with fixed microscopic constants. |
| 276–327, L22–L26 | Actual positive C28 limits have range in the same selected scattering projection. Self-adjointness converts that range inclusion to annihilation of the complement. Positive summability gives the common kernel and its zero spectral atom, proving L24 without coverage. The ordered limits are time, countable truncation, then eta; the intermediate norm error is `2^-N/eta`. No simultaneous-limit or convergence-rate claim follows. |
| 329–337, L27 | The separate projection theorem now has a completed source-bound review. Its hypotheses match the F2 selection and the constructed windows, so its specifically chosen family identifies the zero atom exactly with `Pi_J(1-P_sc)`. This optional equality does not apply to an arbitrary family or follow from abstract L5 alone. It remains unnecessary for L1/L24. |
| 339–405 | The failed shortcuts and scope exclusions are accurate. The conditional proper-subspace conclusion is the existing N1 contrapositive. The additional content is quantitative vector/energy/operator conversion and the finite-block extension; it does not construct a microscopic model, a numerical local witness, all channels, or a physical readout probability. |

The strict positive sign in L25 uses the witness and cutoff satisfying L11,
as in the note's existence construction. L12 for an arbitrary cutoff gives
only a nonnegative lower bound. No different cutoff quantifier is licensed.

## Independent reconstruction and finite evidence

The proof and a separately written exact control were frozen at
2026-10-12 02:16:57 UTC, before opening the new author helper or its control
outputs. The freeze record is
`detector_index_leakage_review/precontrol_freeze.json`, SHA-256
`944536d3166e9378d2e97e4ac437c1b7e0ee0b87c4116be71f2729e30724ec66`.
The full reconstruction is
`detector_index_leakage_review/INDEPENDENT_RECONSTRUCTION_PRECONTROLS.md`,
SHA-256 `c07b6a3e03999d33b6e55d651edb9c69fa805472e21a610f5702e0a675afc50a`.
The note's own control descriptions and earlier source reviews were visible.
Root proposed the mechanism and is a coauthor; this checker did not author
the target. No blind-discovery, different-model or formal-proof claim is made.

The independent script uses rational 7-dimensional matrices and every
principal minor to check operator inequalities for all fixture vectors,
including a genuine rotation and a dense orthogonal change of basis.
It also checks noncommuting positive detector sums, incomplete-family
kernels, exact resolvents and missing-premise counterexamples. It exited
zero in 0.106 seconds under a 60-second timeout. A false 1/3 coefficient
produced the negative minor -43/540; removing the high-energy subtraction
failed at four tested cutoffs. Each omitted identity term failed for all
six tested norm-one A operators. The code has five JSON records covering
six subjects; these are finite algebra controls, not a physical lattice
model or proof of an infinite-dimensional claim.

Afterward, the complete author helper, execution wrapper and freeze script
were read. The baseline reproduced all output byte-for-byte under a
60-second timeout, exiting zero in 0.032 seconds. All six exact source
mutants were rerun and exited one at their intended assertions, reproducing
their full stdout/stderr. The author receipt matched all 69 bound files,
with no unlisted evidence files. All traces, commands and hashes are retained
under `detector_index_leakage_review/logs/`.

The author's tube arithmetic uses illustrative constants, not measured
microscopic current constants; it does not compute the block operator norm.
The independent all-vector check differs from the author's diagonal-vector
enumeration, but both use the same underlying operator identities.
Neither execution substitutes for the analytic proof. L17, infinite-volume
index, local domains and asymptotic detector convergence are not certified
by counting finite cases. Detailed coverage is in
`detector_index_leakage_review/POSTCONTROL_ASSESSMENT.md`.

## Exact premise reading and reuse

I read the complete new note and all necessary repository premise proofs:
the 146-line assessment; the full 438-line partial-factor proof and 61-line
review; the complete 301-line N1 report; the 404-line compact-creator proof,
51-line review and 28-line EX repair; the 326-line Fock proof and 138-line
review; and the complete 339-line detector proof C1–C28 and 124-line review.
B1 lines 1–100 were read for Theorem U/first-moment context; M1 lines 210–275
were read for T3 and its exclusions. Their unrelated remaining arguments
are not certified. Exact paths, hashes, counts and reading coverage are in
`detector_index_leakage_review/source_manifest.initial.json` and
`detector_index_leakage_review/reading_coverage.json`.

The exact prior reviews' RWW, NSY, BDN, NS and Dybalski checks are reused
within their recorded scope. I checked the complete necessary repository
arguments and hypothesis matching, without freshly rebuilding every primary
theorem, repeating prior helpers, or claiming complete-paper certification.
The new steps do not change those imported hypotheses.

During this review the separate projection check completed. I then read its
full 126-line review and full 330-line frozen source and checked applicability:

- Projection source: `91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4`.
- Projection review: `d9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2`.
- Projection review receipt: `1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b`.

That is reuse of a completed independent review, not another certification
of its control packet. The pre-control reconstruction's “pending” description
is preserved as accurate at its freeze time.

## Conditional boundary and recovery

The N1–N8 assessment is recorded in `POSTCONTROL_ASSESSMENT.md`. It supports
the note's limited consequence: the fixed common-q selected scattering space
is proper under the supplied microscopic hypotheses. Extra channels with
no common denominator, other locality classes, or failure of the proposed
microscopic identification remain outside that consequence. Positivity gives
kernel inclusion for any admissible selected-sector family; the new projection
theorem gives equality only for its chosen covering family. Neither statement
proves framework ND, EX, universal detector blindness, or a Born/Record bridge.

Two broad pinned-main searches terminated with signal 9 before completion;
the cause is unavailable. Their partial output is preserved and supplies no
absence or novelty evidence. N1's earlier open index step and its subsequent
closure were checked directly. Initial overlarge tool displays were also
reread in bounded chunks before being counted as source coverage. No Lean
verification or exhaustive physical-model search was performed.

Instruction authority was main `a13caa4885f547c8d206265b031ba7649e539fd9` and
planning `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; the stale local main
name was not used as authority. The source checkout began at
`296155eda2ca6a5ab6ae6307190362b9a84ea690` and advanced through the parent's
concurrent publication to `5cbc581504721a323f5fa2064694a67141a3ee98`.
The final original-source refresh matched all 28 checked bindings, including
the unchanged target and optional projection sources. The checkout was clean.

Only this report and `detector_index_leakage_review/` were written. Live
editable prompt files changed: none; instruction copies are frozen evidence.
No Git/ref, PR, audit, axiom, model/effort, or other-chat mutation was made,
and no subdelegation occurred. The current recovery record is
`detector_index_leakage_review/CHECKPOINT.md`; the final receipt binds the
report and evidence. There are no unresolved source corrections in this
review. Unseen publication edits require affected-source confirmation.
