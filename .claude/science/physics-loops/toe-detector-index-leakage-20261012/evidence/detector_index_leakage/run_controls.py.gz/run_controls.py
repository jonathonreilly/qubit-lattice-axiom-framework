#!/usr/bin/env python3
"""Preserve one declared-timeout author run and actual source-mutant failures."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
source=here/"check_leakage_controls.py"
out=here/"logs";out.mkdir(exist_ok=True)
mutations=[
 ("bad_defect_coefficient","DEFECT_DENOMINATOR = 4","DEFECT_DENOMINATOR = 3"),
 ("omit_first_identity_term","FIRST_IDENTITY_TERM = 1","FIRST_IDENTITY_TERM = 0"),
 ("omit_second_identity_term","SECOND_IDENTITY_TERM = 1","SECOND_IDENTITY_TERM = 0"),
 ("halve_energy_bound","ENERGY_FACTOR = 2","ENERGY_FACTOR = 1"),
 ("omit_high_energy_tail","TAIL_COEFFICIENT = 1","TAIL_COEFFICIENT = 0"),
 ("reverse_zero_resolvent_sign","RESOLVENT_SIGN = 1","RESOLVENT_SIGN = -1"),
]
runs=[]
def execute(label,path):
    stdout=out/(label+".stdout.txt");stderr=out/(label+".stderr.txt")
    assert not stdout.exists() and not stderr.exists(), "do not overwrite previous execution"
    command=[sys.executable,str(path)]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
    try:
        p=subprocess.run(command,text=True,capture_output=True,timeout=60,cwd=here)
        stdout.write_text(p.stdout);stderr.write_text(p.stderr)
        code=p.returncode;timed_out=False
    except subprocess.TimeoutExpired as e:
        stdout.write_bytes(e.stdout or b"");stderr.write_bytes(e.stderr or b"")
        code=None;timed_out=True
    row={"label":label,"command":command,"declared_timeout_seconds":60,"started_utc":start,
         "elapsed_seconds":time.monotonic()-tick,"exit_code":code,"timeout":timed_out,
         "source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
         "stdout":str(stdout.relative_to(here)),"stderr":str(stderr.relative_to(here))}
    runs.append(row)
    return code
baseline=execute("baseline",source)
assert baseline==0, "baseline failed; preserve output before any correction"
mutantdir=here/"mutants";mutantdir.mkdir(exist_ok=True)
source_text=source.read_text()
for label,old,new in mutations:
    assert source_text.count(old)==1
    path=mutantdir/(label+".py")
    assert not path.exists()
    path.write_text(source_text.replace(old,new))
    code=execute(label,path)
    assert code not in (None,0), "mutant was not rejected"
    runs[-1]["mutation"]={"old":old,"new":new}
(out/"execution_records.json").write_text(json.dumps(runs,indent=2)+"\n")
print(json.dumps({"baseline_exit":baseline,"mutants_rejected":len(mutations),
                  "records":str(out/"execution_records.json")},sort_keys=True))
