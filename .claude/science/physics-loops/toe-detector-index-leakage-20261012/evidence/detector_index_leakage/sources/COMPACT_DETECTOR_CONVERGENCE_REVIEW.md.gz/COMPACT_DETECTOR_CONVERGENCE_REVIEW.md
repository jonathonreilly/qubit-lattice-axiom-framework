# Independent review of compact-chart detector convergence

**Disposition: PASS for the stated conditional C1–C28 theorem at the frozen
source below.** No material mathematical error was found. The proof establishes
the PC norm limit for each fixed admissible arrangement and every finite-energy
vector. With C25 and the unique vacuum, it also establishes the positive
compressed and uncompressed detector limits and their scattering range.
No source correction is required by this review. ND, full-GNS exhaustion,
physical realization and formal retained status do not follow.

The reviewed source is `COMPACT_DETECTOR_CONVERGENCE_PROBE.md`, all 339 lines,
SHA-256 `bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64`.
Its author freeze receipt has SHA-256
`de9a4acddf3c08b406c5dd74cae01d206e1e0a9ab2d804489ddc9ae42d0eca06`.
All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

The complete proof reconstruction and distinct kernel-control source were
frozen before opening the new author helper, logs, metadata, receipt or images.
The freeze time was 2026-10-12T01:21:51.918850+00:00; its record is
`compact_detector_review/precontrol_freeze.json`, SHA-256
`4d75d0893cc6fdddb207dd31ddd137359874183b2f8b8b8878382c21adaa8702`.
The complete derivation is
`compact_detector_review/INDEPENDENT_RECONSTRUCTION_PRECONTROLS.md`.
The target's own descriptions of controls and the completed predecessor EX
review were already visible; they are disclosed shared context. The reviewer
was not a contributor to this proof. The independent evidence is the direct
reconstruction and separately written control, not the existence of another
review label or a different implementation of the author's expected answer.

The exact source-bound conclusions are as follows.

| Target lines | Conclusion and required scope |
|---|---|
| 25–49, C1–C2 | The spatial filter has full operator momentum support in Lambda, with the stated Fourier sign. Schwartz coefficient summation preserves almost locality, temporal transfer and the exact vacuum graph. Microscopic flows, selected mass/centre components and direct creator properties remain supplied conditions. |
| 51–108, C3–C9 | The common-word-kernel induction proves the finite-energy annihilation bound without assuming Q preserves the energy subspace. Both commutator Schur sums enter that induction. Iterated lowering bounds a_t; the output energy bound makes J_t bounded on all ell². Coordinate filtering proves J_t=J_t P_Lambda. The full two-term packet derivative, commutator count and spectator factors give an integrable Cook bound. Convergence extends from the linear span of smooth tensor products to all ell². |
| 110–162, C10–C17 | Time intertwining makes the constructed closed scattering span reducing for H. F_t is strongly differentiable in ell² on P_R H. The vacuum row defect is zero with the displayed sign and spatial convolution convention. C14 retains every ordered commutator and both derivative contributions. The global source norm follows from strong differentiation, while the localized estimate uses off-collision lattice counting. The entire source inherits the exact closed Fourier support from F_t and F'_t. |
| 164–217, C18–C22 | The stationary source position is y=x+(s-t)v. Convex containment gives a lower bound delta s. Combining it with the large-distance bound gives c(s+abs(x-y)); all differentiated integration-by-parts coefficients are O((s+abs(x-y))^-1). Periodicity or compact chart support eliminates boundary terms. Both absolute Schur sums are O(s^(nd-N)). Constants are uniform for s≥t≥1, including s=t, s/t near one and unbounded s/t. |
| 219–249, C23–C24a | Strong S_T gives weak S_T* only. At fixed t, K_t has finite rank, so K_t w_T converges in norm. The finite-interval fundamental theorem gives the minus sign in the reversed integral. The split occurs after q, leaving q chi_s and q(1-chi_s) in the required order. C17 and C18 give absolute Bochner integrability with constants independent of s≥t. T tends to infinity at fixed t before t is increased. |
| 251–272, C24 | Fourier shifts on the torus prove the free strong limit by dominated convergence against the integrable Fourier transform of h. The result is exactly h(v(D)) S* Psi; g is removed only in the limit using the Fourier support of S*. The rapid estimate on the finite-energy unit ball in H_sc perpendicular follows from C24a. Strong convergence of unlocalized adjoints and a free operator-norm limit are never assumed. |
| 276–318, C25–C28 | The energy-only remainder condition and unique vacuum give exact vacuum factorization. Reordering swaps distinct labels separated by a multiple of t, with O(t^(nd)) spatial tuples, yielding the rapid operator-norm remainder. Uniformly bounded S_t times convergent u_t gives Q_J=P_J S h(v) S* P_J. Positivity, boundedness and scattering range follow. Intertwining makes S h(v)S* commute with H, so the uncompressed product on P_J H has the same limit. |
| 320–339 | A countable weighted positive sum is allowed after each fixed arrangement is established. No uniform family estimate, common-kernel result, channel coverage or exhaustion is inferred. The finite controls are described at their actual scope. |

The new load-bearing lemma was reconstructed using the normalized phase
`Phi/s = ((x-y)/s)·p + (1-t/s) omega(p)`. Its gradient is uniformly separated
from zero on the relevant support; after splitting the cases of large and
bounded `abs(x-y)/s`, normalization by `s+abs(x-y)` controls every derivative.
A dyadic lattice-shell estimate then proves both Schur sums. This supplies
the all-scale analytic bound. Neither a finite spatial truncation nor a
numerical rate fit supplies that conclusion.

The scattering-map density wording at line 108 is understood precisely as
the **linear span** of smooth product functions. A single rank-one tensor
class is not itself dense when n>1. This is harmless shorthand here because
the maps are linear, convergence is proved on each product, and uniform
boundedness extends their finite span. It does not require a new premise or
a change in the conclusion.

The exact predecessor inputs were checked: the complete compact-creator
source `d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`, its
complete EX scope repair `d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`,
and the complete E1–E18 reduction `c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2`.
The complete EX review `8c9f7bb60724982ce7580a8b5688d8b61572ea008d92305f057d3f9b7a4e735d`
and the repair-confirmation addendum were read. The Fock conclusion was not
used; its file identities were checked only as author-receipt entries.

Primary-source proof coverage is explicit in the frozen reconstruction:
[Dybalski v1](https://arxiv.org/abs/1608.08750v1), all 13 pages, and
[BDN v2](https://arxiv.org/abs/1412.2970v2), pages 9–19 and 39–43.
The exact PDFs match the candidate's hashes. This checks the transfer and
almost-locality mechanisms, finite-energy estimate, packet Cook construction,
and the original fixed-time compactness argument in their hypothesis context.
The target rebuilds these mechanisms from its direct properties; it does not
apply a global isolated geometric-shell theorem with missing hypotheses.
The supplied page texts are shared extraction evidence. The reviewer also
rendered and inspected original Dybalski pages 4 and 12 independently: the
empty-set condition and the third-derivative difference are printed there.
The correct derivative uses the sum of the two third derivatives; the new
proof does not use that Taylor formula. No full recertification of unrelated
Fock or literature-comparator results is claimed.

The independent control `compact_detector_review/kernel_control.py` ran once
under a declared 60-second timeout, exited 0 in 0.148 seconds, and retained
all five stdout records and empty stderr. It uses a compact smooth momentum
bump with different linear dispersions on its support, for which the Fourier
kernel is a translated coefficient sequence at integer time differences.
Direct phase quadrature agreed with that separate shift calculation to
1.27e-14. The factorized row and column sums agreed with an explicit
two-coordinate kernel to 1.39e-17. Two quadrature resolutions differed by at
most 1.39e-16 in the finite sums. At the registered collision configuration,
the correct kernel modulus was 4.28e-19; the wrong sign gave 0.00499.
These are finite sign and algebra controls. The finite-column sums carry no
uncomputed-tail certificate and establish no infinite-volume convergence.

The entire author helper and supporting execution/freezing scripts were read.
The author helper was reproduced once under its declared 60-second timeout:
exit 0 in 0.026 seconds, all seven output records identical byte for byte,
stderr empty. Six copied-code mutations separately corrupted the free phase,
cutoff order, reversed-integral sign, retained source filter, stationary sign
and third-derivative sum. Every mutation failed at its intended assertion.
The six original controls are discriminating at their claimed finite scope;
none supplies the analytic theorem or microscopic realization. All 43 author
input records and 20 output records matched their hashes and byte lengths,
including the pinned Git object; no unlisted author evidence file was found
after accounting for the declared self-reference/wrapper exclusions. Full
results are in `compact_detector_review/CONTROL_ASSESSMENT.md` and adjacent logs.

The failed proof shortcuts remain failures: creation convergence alone does
not give strong adjoint convergence; compactness cannot be used with a moving
time parameter; the forward derivative's 1/t estimate is insufficient; and
omitting q or convex containment loses the demonstrated propagation bound.
These facts do not constitute a general detector or local-UHF no-go. No source
repair was made. A minor wording clarification in the reviewer's own frozen
directional-derivative discussion is recorded separately, without changing its
pre-control evidence.

This review used the instructed planning revision
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39` and current locally available
science-workflow/reviewer instructions at
`a13caa4885f547c8d206265b031ba7649e539fd9`. The read-only source checkout stayed
at `c3f84746b1991e0a15c6da79d049b89d9469f727`. No model override, subdelegation,
Git mutation, publication, audit verdict, axiom change or other-chat message
was performed. Editable prompt files changed: none. The final receipt records
source refresh, evidence identities, complete coverage and verification limits.
