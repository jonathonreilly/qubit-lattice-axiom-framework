# Independent review of compact-patch Fock isometry

**Disposition: PASS for the frozen conditional theorem. No required source
correction or counterexample was found.** The permanent Gram formula,
chart-independent isometric Fock extension and stated translation/centre
covariance are supported under the predecessor's explicit supplied conditions
and the additional unique gapped vacuum (F1). This is a source review, not an
audit verdict, retained status, physical realization or full N1 certification.

Frozen source: `COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md`, 326 lines, SHA-256
`9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404`.
The original note and all author evidence remain unchanged. The complete
pre-author-evidence reconstruction, independent controls, primary sources,
coverage records and reproduction logs are in `compact_fock_review/`.

## Load-bearing findings

- **Energy restriction, lines 94-149:** compact positive temporal transfer is
  inherited from the actual joint filter, and does not require isolation in
  geometric energy-momentum. The common kernel of all mixed translated
  lowering words gives the stated Q^2 induction and
  Gamma_B(R)<=floor(R/epsilon)S_B. Its compressed infinite sum is a bounded
  positive strong limit. The creator needs the R+L output-energy padding;
  the annihilator needs R. These estimates uniformly bound every fixed finite
  mixed vacuum word and its row functional.
- **Regular contraction, lines 151-212:** the massive Hessian is positive on
  every compact lift, including k=0, and gives the stated stationary-phase
  l1/sup powers. F1 supplies precisely the rank-one vacuum and positive gap
  required by NS clustering. The displayed clustering constant is sufficient.
  The four-observable connected commutator kernel is rapidly decreasing in
  all three relative coordinates. One l1 packet bound and three sup bounds
  give the squared norm O(T^(-d)), hence the contraction error O(T^(-d/2)).
  This proof works for different masses, centres and lifts; geometric shell
  isolation and cross-family separation are not used.
- **Full Gram recursion, lines 214-249:** the third packet can be partitioned
  through its own velocity map, so mixed-chart double commutators are rapid.
  The exact recursion contains all double brackets. The finite-energy row
  bound, rather than polynomial full-operator norms, controls the contraction
  remainder after every other factor. The base cases and recursion prove the
  permanent and particle-number orthogonality for both signs of time. There
  is no extra factorial with the stated creation-operator normalization.
- **Absolute continuity and density, lines 251-285:** exact local-filter
  creators are dense in each selected open K patch. Their two-point Fourier
  coefficients equal almost-local commutators because B*Omega=0. Rapid decay
  gives a smooth Q-density for those vectors, and closure gives absolute
  continuity on the whole selected one-particle space. Injective local
  K-to-Q charts transfer it to K. The explicit massive velocity maps make
  every mixed-species pairwise velocity diagonal null; Fubini and tensor
  spectral projections give a full-measure separated domain. Countably many
  separated compact boxes and local creator density prove Fock-sector density.
- **Extension and covariance, lines 287-307:** the Gram identity preserves
  norms of arbitrary finite linear combinations, so it removes dependence
  on creator, chart and partition realization. Sector orthogonality permits
  the Hilbert direct sum. Fixed geometric/current translations and V_j
  preserve the direct creator class and packet velocities; finite-time
  conjugation, the existing strong limits and continuity give intertwining.
  V_j^q=1 follows on each wave-operator range, with no global completeness claim.

## Original imports and dependency scope

The full predecessor at
`d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`
and its necessary creator/Cook arguments were read. Its independent review
`924b2fa9d6175bcbc213d164da6322d3fde0d769f06a5608d4aadc1644f974be`
is reused only for that exact conditional construction. Its sole EX-scope
finding is resolved by the read repair
`d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`
and confirmation
`8135fdaf9481c492738eee35d7b360c0e4f864b9213fd9751218bd3ee64f3029`.
None supplies a Fock conclusion. The new F1 explicitly states the vacuum
hypotheses needed here; N1's actual H-gap clause on all Omega-perp implies them.

The exact [BDN v2](https://arxiv.org/abs/1412.2970v2) PDF hash is
`3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126`.
Complete pages 7-24 and 39-43 were read, including the actual transfer lemma,
energy-bound mechanism, regular-shell contraction, full Gram proof and density
construction. The exact [NS v1](https://arxiv.org/abs/0712.3318v1) PDF hash is
`74829f87cc51d399613043a3abdc48ba3146c81292a09e4df1035b50eb464b5c`;
complete pages 3-4 and 9-12 were read for the interaction hypotheses and
clustering theorem/proof. This is proof-level reuse with the missing geometric
isolation replaced by directly verified creator properties. BDN's general
S-matrix wording is not imported as a conclusion. The exact velocity inverse
also avoids any need for BDN (4.58)'s general smooth-map pointwise inclusion.

## Independent and author evidence

`RECONSTRUCTION.md` was frozen at 2026-10-12 00:00:56 UTC, before reading the
Fock author's code, logs or receipt, at SHA-256
`85f4d93458c6f00ede645e6d2ac272084dc0cd053b66801b25db8574586df484`.
The candidate's own control descriptions were visible during this phase.
Root suggested the regular-shell route and is a contributor; no claim of blind
route discovery, different-model independence or formal proof verification is made.

Separately written concrete integer matrices checked the noncommutative Q^2
and complete annihilator identities; omitted brackets failed. Finite cyclic
spin controls with noncommuting lowering translates checked the energy bounds
and rejected missing energy padding. Exact occupation-polynomial checks tested
the permanent normalization. These controls were written before opening author
code, used a 60-second timeout, exited 0 and preserved full outputs. The finite
floating energy tests use tolerance 1e-9 and are not infinite-volume proof.

The author receipt
`48b2a3fb2aeef107685ade2404e4029741fd9076e22f2d1fd6a3803588026c6d`
matched all 92 bound artifact lengths/hashes and the note. The entire control
source and nine-record output were inspected. The exact author command rerun
under a 60-second timeout exited 0 in 0.716 seconds and reproduced stdout and
empty stderr byte-for-byte. Its free-word, Hessian and finite positive-matrix
checks are meaningful for their stated finite targets. Its rectangular
normalization branch encodes unequal-number vanishing, and its exponent table
is arithmetic; neither is used as evidence for the analytic Gram conclusion.
The note already labels these limits honestly. Reproduction is not independent
implementation, and passing controls do not replace the reconstructed proof.

Fresh extraction of the frozen original PDFs was used for the proof reads.
The later 29-page comparison with author page text agreed after stripping outer
whitespace; BDN differences were trailing newlines. Full diffs and coverage
are retained. Unread primary pages and unrelated source arguments are not certified.

## Exact stopping point and provenance

The supported isometries act on Fock space over finitely many selected isolated
mass/centre components, allowing all their momenta through compact chart covers.
They initially agree with strong packet limits for separated data. The extension
does not prove convergence of raw unseparated products. Their closed ranges
need not exhaust the GNS space or include all channels. No boost/Poincare
intertwining, isometric/unitary S-matrix, full-algebra shift identity or full N1
obstruction follows from this result alone. Microscopic implementations,
isolated mass components, finite-order centres and F1 remain supplied conditions.

The inherited user-selected model and reasoning effort were preserved, without
subdelegation. Instruction identities were main
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`, verified against remote refs at
review start. Only this report and `compact_fock_review/` were written.
Editable prompt files changed: none. No platform instruction, frozen source,
Git, PR, audit, axiom or other-chat changes were made. This review is bound to
the exact source above; unseen publication changes require affected confirmation.
Fixed campaign deadline: 2026-10-12 16:00:52 UTC.
