# Independent reconstruction before author-control inspection

Target: `DETECTOR_INDEX_LEAKAGE_PROBE.md`, 405 lines, SHA-256
`4d1e9b888c6e84881e8d356c42e8da521794c68191ebcebab1c145ced5189747`.
Author freeze receipt SHA-256
`47bf0db5e653961b622953a77d26f345515e8f87fe583c6ce66c8951c0f6a498`.
This reconstruction is frozen before opening the author's new helper or its
control-output files. The target note's descriptions of its controls and
the earlier source-bound reviews were visible. The parent proposed the
mechanism and is a coauthor; this checker did not contribute to the target.
There is no claim of blind discovery, different-model checking, or formal
verification. The independently written argument below is the verification,
not the existence of a second agent or a passing label.

## Exact conditional target and dependency graph

The core question is a mathematical implication for the full qubit UHF
algebra on Z^d, d=2 or 3, a cyclic nonzero vacuum representation, actual
microscopic H and current implementations, and a fixed selected scattering
projection P. The supplied ground-state assumptions are H>=0,
ker H=C Omega and spec H subset {0} union [m,infinity), m>0. The microscopic
H interaction has finite range and J_H=sup_x sum_(Z contains x)||Phi_H(Z)||.
The current has its own fixed finite-range uniformly bounded interaction.
Neither interaction is derived from the framework axioms here.

The constructively covariant common-q scattering range supplies UP=P and
P reducing H, where U=exp(i q P_b/beta) T_(q e_b). U fixes Omega and strongly
commutes with H. The checked partial-factor index theorem rules out the
full-algebra finite-time shift identity, giving gamma!=id. Faithfulness
then gives U!=1; cyclicity, and not separation of Omega, gives a local
vector on which U-1 is nonzero. Elementary unitary and spectral estimates
give L1. Positive detector range inclusion gives L24. Neither EX nor a
detector coverage theorem occurs in this dependency chain. L27 alone is
conditional on a separately reviewed projection theorem.

## Sign and microscopic implementation check

The declared current flow is alpha_s^P=Ad exp(-isP_b). Its inverse at
s=q/beta is Ad exp(+i q P_b/beta). Thus gamma=(alpha_s^P)^-1 tau_q is
implemented by exp(+i q P_b/beta)T_q, exactly U, without needing to reverse
the geometric translation convention. If gamma=id, apply alpha_s^P to
the equality to obtain tau_q=alpha_s^P. The equivalent generator/time
choices are P_b at q/beta or P_b/beta at q. Dividing both gives the wrong
flow. This agrees with the signs in the compact-creator S1/S3 conventions
K=P/beta, rho_y=Ad exp(-iyK), V_j=exp(ijK)T_j and the Fock source F20.

The finite-range current implementation is an explicit leaf. A formal
first-moment sum or formal Lie algebra does not prove it. The older N1
Step 1 and M1-T3 become usable only with the constructive covariance
premise, including all multiplicity spaces. N1's incorrect double-beta
line is not reused. B1-U assumes a bounded boost-invariant sector and
is not a premise of this argument.

## Algebra nontriviality, cyclicity and the reducing projection

A nonzero representation of a simple unital UHF algebra is injective and
isometric. If U=1, the implementer identity makes gamma=id, contradicting
the matched index theorem. Therefore U!=1. If (U-1)C Omega=0 for every
local C, continuity makes U-1 vanish on the closure of those vectors,
which is the GNS space. Hence some local C has d_C>0. Density is obtained
from the norm-dense local algebra and cyclicity; a finite linear
combination of local operators has finite union support.

UP=P means U is the identity on Ran P. For a unitary this also gives
U*P=P, PU=P and PU*=P. Consequently P commutes with U and
(U-1)=(U-1)Q=Q(U-1), Q=1-P. The local defect vector lies in Ran Q.
Invariance of a closed scattering range under e^(isH) for every real s
makes it reducing, so P commutes with every H spectral projection.
These facts do not make Omega separating. Faithfulness preserves an
operator norm; it never changes ||D||>0 into ||D Omega||>0.

The compact-creator proof's finite-time conjugation of packets and its
fixed-chart creator independence give the product centre action. The
Fock proof's Gram identity and separated-data density extend this action
to the whole selected Fock range. Isometry makes that range closed; time
intertwining gives the reduction just used. No surjectivity is present.

## Unit-vector and energy estimates

For any psi, ||(U-1)psi||=||(U-1)Qpsi||<=2||Qpsi||. Equivalently,
(U-1)*(U-1)<=4Q in operator order, which proves L8 simultaneously for
all vectors. U=-1 on one complementary line saturates the coefficient.
A fixed line in Q shows that the reverse inference fails.

For local C supported on finite X, only finitely many interaction sets
meet X within the finite range. The double counting bound is
sum_(Z meets X)||Phi_H(Z)|| <= sum_(x in X)sum_(Z contains x)||Phi_H(Z)||
<= |X|J_H. Thus ||delta_H(C)||<=2J_H|X|||C||. Finite-volume Duhamel,
followed by the norm thermodynamic limit uniformly on compact times,
gives the point-norm derivative of alpha_t(C). Vacuum invariance changes
that derivative to d/dt e^(itH) C Omega at zero. The strong generator
definition therefore proves C Omega in Dom H and
iHC Omega=delta_H(C)Omega. There is no unproved domain commutation in L10.

Let F=1_[m,E](H), G=1_(E,infinity)(H), E>=m. Since P includes Omega,
QP0=0; uniqueness and the gap give I=P0+F+G. Orthogonality and [Q,H]=0
give ||QFC Omega||^2=||QC Omega||^2-||QGC Omega||^2. The second term is
at most ||GC Omega||^2<=h_C^2/E^2. Combining with L8 and nonnegativity
proves L1, including its positive-part notation. This first derivation
does not require [U,H]=0 beyond the hypotheses used elsewhere.

The strict positivity threshold is E>2h_C/d_C. It automatically lies
above m, because h_C>=m||QC Omega||>=m d_C/2. The cruder threshold
4J_H|X|||C||/d_C follows from the derived domain estimate. Neither
threshold is numerical without a witness C and its actual defect.

Under strong [U,H]=0, the defect itself has Dom H and
||H(U-1)C Omega||<=2h_C. Its finite-window projections exhaust it.
Some finite F_E Q space is nonzero. Normalizing a nonzero vector there
gives pure complement weight one. Cyclic local approximants to that
fixed vector, followed by F_E, have normalized complement weight tending
to one. This proves the stronger existential preparation assertion, with
no bound on the approximating operator's norm, support or energy.

For a disjoint finite Borel partition of [m,E], [Q,H]=0 gives an
orthogonal decomposition of QF_E C Omega. At least one of N pieces
has >=1/N of its squared norm. Half-open intervals with the final endpoint
assigned once handle spectral atoms. Diameter <=m/8 is stronger than
the optional projection theorem's <m/4 requirement. L25's strict >0
uses a witness and cutoff satisfying L11, as intended by the preceding
existence construction; L12 for an arbitrary cutoff has only >=0.

## Operator-to-vector conversion, including both terms

Expand the operator identity, without applying it to the vacuum:
(U-1)A + UA(U*-1)=UA-A+UAU*-UA=UAU*-A.
Applied to B Omega, this is L13. For the first summand use
||(U-1)AB Omega||<=2||QAB Omega||. For the second use
||UA(U*-1)B Omega||<=2a||QB Omega||. Cauchy-Schwarz for two real
nonnegative numbers gives c^2<=8(||QAB Omega||^2+a^2||QB Omega||^2).

If Delta=||D_A||>r, choose a unit vector xi with ||D_A xi||>r.
Approximate xi by C_n Omega and normalize; continuity preserves the
strict inequality eventually. Scaling C_n is allowed and yields a local
B with ||B Omega||=1. It does not control ||B|| or support. a>0 follows
from Delta>0. Since ||AB Omega||<=a, L14 is bounded above by
4a sqrt(max(W(B),W(AB))). If AB Omega=0, omit that undefined weight;
the surviving term actually gives a stronger estimate. This proves L16.

For the cutoff form, each defect has no vacuum component. Decompose its
input using F+G; use [U,H]=0, reduction of Q, and
||QGC Omega||<=h_C/E. Then
c <= 2(x_E+a y_E)+2(h_AB+a h_B)/E.
If the left residual is positive, one of the two window vectors is
nonzero. Their denominators are at most a and 1, respectively, because
F is a contraction. This proves L17 with the stated 16a^2 denominator.
There is no direct estimate on D_A Omega and no bound using AB alone.

## Optional finite-tube extension

P8 requires a genuine automorphism with RWW interval-uniform tails,
C_Q f(j)<=1/3456, and a map norm on the entire 4j-slice interior algebra,
with eta=epsilon+4C_Q f(j)<=1. In P11 the tail calculation and zero-index
flow path use only the finite-range interaction and fixed time. The
extensive shift index likewise needs no full-algebra equality. The exact
identity is used solely to replace the interior error by a flow-comparison
error. That is the step the new triangle inequality replaces.

For A in the interior algebra, isometry of alpha_t^W gives
||gamma_L(A)-A||=||tau_q(A)-alpha_t^W(A)||. Insert alpha_t(A).
The first difference has norm ||gamma(A)-A|| and the second is bounded
by the same microscopic Duhamel estimate used in P27. Thus epsilon is
bounded by Delta_L+e_L. The tail correction is <=a_L, so eta is bounded
by Delta_L+e_L+a_L. All these are full map norms; vacuum expectations
and one-site tests cannot replace them.

The logarithmic choices give C_Q f_L(j)<=L^-4/3456,
e_L<=L^-4/2 and a_L<=L^-4/864. The required restrictions include
integer L>=2, j>=1, 1<=R<L/2, fixed positive mu,nu and fixed A,E>=1.
If Delta_L<=kappa-e_L-a_L and 0<kappa<=1, then eta<=kappa.
Monotonicity of g(x), g'(x)=log(1+1/x)>0, bounds P8 after division by
V log 2 by the L20 expression. Its strict inequality contradicts the
known |q| index. This proves the strict lower bound in L21.

For kappa=min(1/2,|q|/(16 sqrt(2)j)), the middle term is <=|q|/4.
The first term tends to zero because B/V=O(R/L), j,R=O(log L).
The entropy term tends to zero, and e+a=O(L^-4) is eventually smaller
than kappa~1/log L. Hence admissible finite L exist for fixed nonzero q.
Compactness of a finite-dimensional unit ball proves norm attainment for
the restricted map even though its codomain is infinite-dimensional.
It does not supply a physical witness or a vacuum defect without B.

## Positive detector limits, common kernels and ordered resolvents

The complete C1-C28 source proves bounded positive Q_(J,l) with range
in Ran(Pi_J P), provided that arrangement has full operator transfer,
the stated convex velocity containment/separation, and the energy-only
vacuum remainder C25. The declared selected charts must belong to the
same P selection. Its proof uses weak adjoint convergence only and takes
its fixed-time compactness limit in the specified order. No coverage
claim is part of this reused theorem.

Set R=Pi_J P, itself an orthogonal projection. Range inclusion gives
R D=D for a detector D. Self-adjointness gives D R=D. Therefore D kills
Pi_J Q. The weighted sum K is norm convergent: each summand has norm
<=2^-l b_l/(1+b_l)<=2^-l. Positivity shows
<xi,Kxi>=0 iff every ||D_l^(1/2)xi||=0, since all weights are positive.
Thus ker K is exactly the common kernel. Its spectral-zero projection
on Pi_J is >=Pi_J Q. This proves L24 and, with the narrow window
construction, L25. The family may be empty; its zero-atom bound remains
true but supplies no detector coverage evidence.

For fixed eta>0, positive bounded operators have resolvents bounded by
1/eta. Strong convergence and the resolvent identity give strong
convergence of eta(K_N(t)+eta I)^-1. Taking N to infinity then costs
at most ||K_N-K||/eta <=2^-N/eta in norm. Lastly the scalar functions
eta/(lambda+eta) tend pointwise to 1_{lambda=0}, bounded by one, so the
spectral theorem gives the strong zero projection. Pi_J removes the
automatic kernel outside the energy window. Interchanging eta with the
time limit would generally be invalid; finite positive eigenvalues may
approach zero as time grows. No uniform convergence rate is established.

L27 is a separate conditional implication if the separately reviewed
projection theorem identifies the selected family support with Pi_J P.
It is unnecessary through L26. This review does not certify that new
projection proof. Selected-sector complement may consist of omitted
ordinary channels; it is not universal observational invisibility.

## Distinct finite control selected before author-code exposure

The independent executable uses exact rational 7-dimensional matrices
and all-principal-minor certificates for operator order, after a dense
rational orthogonal basis change. It checks L8/L1/L15 for every vector
of each fixture rather than only nominated sample states. Noncommuting
positive rank-one detectors distinguish support equality from inclusion;
exact inverses test the resolvent inequalities. Sharp reflection and
high-energy fixtures reject wrong coefficients and an omitted tail.
These are finite algebra/inference controls, never a local-UHF model,
an infinite-lattice index proof, or analytic detector convergence.

## Reading coverage and retained boundaries at this freeze

Fully read: the 405-line target; the 146-line assessment; the 438-line
partial-factor proof (P1-P29 equations and all P1-P15 sections) and its
61-line review; the 301-line N1 report; the complete 404-line compact
creator proof and its 51-line review; the 28-line EX repair; the complete
326-line Fock proof and its 138-line review; the complete 339-line detector
proof C1-C28 and its 124-line review. Directly read B1 lines 1-100 for
Theorem U/first-moment context and M1 lines 210-275 for T3 and its exclusions.
The unrelated remaining B1/M1 material is not needed and is not certified.
The optional 330-line new projection source is hash-bound but its proof
is outside this review; its conditional support-equality implication alone
is discussed above.

The earlier exact source-bound reviews' checks of RWW, NSY, BDN, NS and
Dybalski are reused within their stated scope. I read the complete necessary
repository premise proofs above; I have not freshly reconstructed every
imported primary theorem or re-executed their earlier helpers. Their
identities and reading limits are preserved in the frozen review copies.
The new mathematical steps do not alter their hypotheses. No all-literature
novelty search, physical realization, exhaustive model search, or Lean
verification is claimed. The proper-subspace conclusion is N1's familiar
contrapositive; the quantitative vector/cutoff/operator-conversion results
are the added content.
