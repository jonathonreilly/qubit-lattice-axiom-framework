# Source/control assessment after reconstruction freeze

The pre-control reconstruction and script remain unchanged. Their freeze is
`precontrol_freeze.json`, SHA-256
`944536d3166e9378d2e97e4ac437c1b7e0ee0b87c4116be71f2729e30724ec66`,
at 2026-10-12 02:16:57 UTC. No new author helper/control output was opened
before that freeze. The target note itself described its controls, and its
receipt's artifact names/hashes were visible; neither was treated as proof.

## Independent control outcome and limitations

The exact rational script exited zero in 0.106 seconds under the declared
60-second timeout, with empty stderr. Its five JSON records cover six
subjects: defect order and sharpness; energy-window order; the ordered
operator identity and L15; positive detector support and resolvents;
nonselfadjoint range; and limit-order failure. The last two subjects share
one record. The final printed phrase `6 finite exact control groups` counts
those six subjects, not six JSON records; no claim of six separate runs is made.

All-principal-minor rational tests certify positive semidefiniteness of
the displayed fixture matrices, hence the finite L8, L1 and L15 instances
for every fixture vector. A dense rational orthogonal change of basis
avoids restricting the calculations to a common visible diagonal basis.
The fixture nevertheless deliberately supplies commuting H, U, P, exactly
as the theorem requires. This construction is not evidence that the
microscopic hypotheses can be realized on the infinite qubit lattice.

The stronger defect coefficient 1/3 gives the explicit negative principal
minor -43/540. Deleting the energy subtraction gives negative minors at
E=2,6,7,10. Both ordered identity terms are nonzero for all six tested
norm-one A operators. Noncommuting positive rank-one detectors give a
strictly positive selected 2x2 block of determinant 1/144; an incomplete
family leaves an extra selected zero vector. A nonselfadjoint range
operator fails complement annihilation. Exact resolvents satisfy the
finite operator inequality; the scalar vanishing-eigenvalue examples
demonstrate that eta and time cannot be interchanged without justification.

The author's code, inspected afterward, also uses rational matrix arithmetic,
nonorthogonal rank-one detector examples and a resolvent-order diagnostic.
Those shared objects were already motivated by the note, so this is not a
wholly different theorem mechanism. The independent control's distinct
contribution is the all-vector operator-order certification with a rotation
and a dense basis change; the author instead enumerates diagonal vector
fixtures and two ordered M3 examples. Neither independently proves the
analytic index, domain, scattering or detector-convergence inputs.

## Author evidence checked and reproduced

The complete author helper, its execution wrapper and freezing script were
read. The helper is SHA-256
`f2ddc3a783ca7f112a19e83b61e412697bd7ceb34df6414789b9c2ef8976cebd`.
Its baseline rerun exited zero in 0.032 seconds under a 60-second timeout
and reproduced all stdout and empty stderr byte-for-byte. Its mathematical
control scopes are exactly those declared in the note: 2,187 diagonal
projection/vector cases, two M3 identity examples, 567 finite spectral
cases, a saturated one-site interaction normalization, positive rank-one
kernels, noncommuting resolvent algebra, and illustrative tube arithmetic.

The six saved mutant source files match the wrapper's declared one-line
changes exactly. Each was rerun separately under a 60-second timeout and
exited one at its intended assertion, reproducing stdout/stderr exactly:
wrong defect coefficient, omission of either identity term, halved local
energy factor, omitted high-energy subtraction, and reversed resolvent sign.
The full failure traces remain in `logs/reproduced_*.stderr.txt`; these
expected rejections are not suppressed or represented as successful runs.

All 69 files bound by the author freeze receipt matched hash, byte length
and line count; there were no unlisted author evidence files after its
declared receipt self-exclusion. `logs/author_receipt_check.json` records
every checked item. Hash agreement is provenance evidence, not proof.

The tube helper uses an explicitly illustrative choice A_tail=E_bd=1,
mu=1, nu=1/2 and the actual algebraic C_Q formula. It finds j=137, R=180
at L=10^6 in d=3. These do not purport to be constants of a physical
microscopic current. The helper checks neither the block operator norm
Delta_L nor its maximizing local observable. L18-L21 are justified by the
written index/tube reconstruction, not by that arithmetic example.

L17's normalized two-state cutoff inequality and the asymptotic existence
of finite admissible tube choices are established analytically in the
reconstruction. They are not directly exercised by every author finite
fixture. No generic runner-completeness claim is made.

## Optional projection dependency update

After the reconstruction freeze, the parent reported completion of the
separate projection review. I checked the received identities and read
the complete 126-line review and complete 330-line original source:

- Source: `91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4`.
- Review: `d9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2`.
- Review receipt: `1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b`.

The matching hypotheses are the same finite F2 mass/centre selection,
its outgoing constructed product/Fock range, the same microscopic
implementations and unique gapped vacuum, and a bounded Borel window
J with diameter less than m/4. The leakage construction produces windows
of diameter at most m/8, so it meets the strict requirement. The projection
source refilters the full operators and constructs the required admissible
family; its P24/P30 identify the zero atom with Pi_J(1-P_sc). Its positive
weights may use any finite actual bound large enough for each arrangement,
so the leakage note's normalization convention is compatible.

Consequently the separately reviewed theorem applies to optional L27 for
that selected range and family. L27 is still not an arbitrary-family result.
If the core leakage theorem is used with only an abstract projection P
satisfying L5, one must additionally supply the projection theorem's
constructed-product and coverage hypotheses to invoke this equality.
The note already says “under its actual hypotheses,” so no correction is
required. The newly available result does not enter the L1/L24 proof.

This is exact-scope reuse of the completed separate review and a direct
applicability check, not a second certification of its primary sources or
control packet. The pre-control reconstruction correctly records that the
projection review was pending at the time it was frozen.

## No-go discipline at the actual conditional scope

| Item | Independent assessment |
|---|---|
| N1: alternatives | The note's five mechanisms are materially different: full-block shift comparison, cyclic state preparation, finite-energy escape, detector positivity/kernel, and centre/selection changes. The mathematical objections are addressed by the displayed proofs or retained as explicit out-of-domain alternatives. They are not five exhausted physical theories. |
| N2: dependencies | Current implementation implies index nontriviality; constructed covariance implies UP=P; H implementation gives the local domain; positive scattering range gives kernel inclusion. These are implication chains, not an asserted independent-wall count. No independence theorem is manufactured for microscopic realization versus channel selection. |
| N3: hidden inputs | Finite-range microscopic flows, the common operator identity including multiplicity, unique gapped vacuum, full block norm, and actual detector admissibility remain explicit. No separating vacuum, Born/Record readout or EX is inserted. |
| N4: residual matching | The P8/P11 shift obstruction matches gamma=id on the whole algebra. Creator/Fock covariance matches UP=P only on the selected range. C28 supplies positive range only. B1-U and M1 bounded-sector arguments do not match and are not used. |
| N5: resolution | New finite controls address matrix/vector and operator-order implications. The full finite interior algebra is addressed analytically through the imported map-norm theorem. Infinite-lattice index, domain and detector limits are written conditional mathematics; no finite-ring or per-mode physical inference is made. |
| N6: partial closure | The primitive registry and axiom memo were read. This consequence is conditional mathematics and requests no new primitive. No convention or existing approved primitive supplies the additional current/scattering/observable identifications by relabeling them. |
| N7: strongest escape | Add genuinely constructed channels without a common finite denominator and prove their covariance/detector range in the same microscopic model; the enlarged P may then evade UP=P. Alternatively the proposed current may fail the exact microscopic implementation. These are live changes to the stated premises, not counterexamples inside them. |
| N8: history | The exact N1 open approximate-index obligation and its later P1-P29 proof/review were read directly, as were the constructive covariance and Fock extensions. The proper-subspace conclusion repeats N1's conditional contrapositive. No priority or broad absence claim is inferred. |

No overbroad physical no-go is supported or recommended. No formal committed
N-packet or audit PASS is requested for this external source review.

## Operational failures and search limits

The first two aggregate text displays exceeded their output budgets. The
complete target and necessary arguments were subsequently read in smaller,
untruncated chunks. The truncated displays were not counted as verification.

Two broad read-only `git grep` searches at pinned main, each with a declared
60-second timeout, terminated with exit -9 (signal 9). The caller did not
request termination, and the cause is unavailable. They retained 29 and 27
partial lines respectively, with empty stderr. Full partial outputs and
exact search commands are preserved in `logs/search_*`; there is no complete
search or absence conclusion. The returned fragments are unrelated matches
and are not scientific evidence. Directly inspected N1/index/scattering
history suffices for the scoped N8 comparison above.
