# Source and evidence ledger

This is an author derivation package. It is not an independent review, audit verdict, retained claim, or claim that the supplied microscopic model exists. The supervisor proposed the mechanism and is a coauthor. The selected model and reasoning effort were preserved; there was no subdelegation.

## Authority and source identity

The instruction/science authority is pinned main `a13caa4885f547c8d206265b031ba7649e539fd9`; planning is `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The checkout was acquired at `c3f84746b1991e0a15c6da79d049b89d9469f727`. The supervisor's known concurrent publication advanced it to `296155eda2ca6a5ab6ae6307190362b9a84ea690`. Local branch `main` is `e485eab6b09b3957df5772104d3ea3980108d7fa`, which was not used as the authority. The worker made no fetch, ref mutation, source checkout edit, or publication action.

`source_manifest.initial.json` and `source_manifest.additional.json` record exact source paths, copies, line counts and SHA-256 values. The final refresh adds the supplied optional projection proof and receipt, checks all frozen bytes against their identified originals, and records checkout identities in `logs/final_identity_check.json`. It does not replace the pinned authority with local main or a later HEAD. `freeze_receipt.json` binds the final note, this ledger, the checkpoint, every frozen instruction/source, helpers, mutation sources and full logs.

## Actual reading scope

Applicable workflow, physics-loop, workhorse and no-go instructions were read once at the pinned unchanged revision, together with planning AGENTS, skill freshness, primitive registry check, the physics-loop Discovery/Claim Status/Delivery/proof-search references, the primitive registry and the minimal-axiom note. Installed entries matched the pinned skill copies. No prompt files were edited. The instruction bytes are included so that a checker can recover the exact scope.

| Source | Reading and use |
|---|---|
| INDEX_TO_PHYSICS_NEXT_OBLIGATION | Complete assessment, including the microscopic-generator identification and constructive covariance/exhaustion distinction |
| APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE and REVIEW | Complete arguments and complete source-bound review; reuse P8/P10/P11 as the previously checked conditional theorem. The new approximate-defect application in note §7 is this author's derivation |
| COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE, REVIEW and EX_PUBLICATION_REPAIR | Complete arguments and reviews; common-q covariance and the explicit unique-vacuum/positive-gap correction |
| COMPACT_PATCH_FOCK_ISOMETRY_PROBE and REVIEW | Complete arguments and review; selected closed range, time covariance and pointwise common-q action, without surjectivity |
| COMPACT_DETECTOR_CONVERGENCE_PROBE and REVIEW | Complete arguments and review at the required hashes; positive compressed fixed-arrangement limits and scattering range, without ND or coverage |
| C4_N1_report | Complete 301-line report; only setting, conditional Step 1 and stated exclusions used |
| C4_B1_report | Lines 1–115, containing the complete Theorem U/first-moment argument and context needed here. Its separate bounded-sector sections are not a premise |
| C4_M1_report | Lines 214–278, containing complete T3 and nearby scope. Its assumed scattering convergence is not imported |
| DETECTOR_SCATTERING_PROJECTION_PROBE | Complete frozen 330-line proof, including P14 separately after one truncated display; used only as an explicitly conditional optional source in note §9. A separate checker was pending when the source was supplied |

Some batched displays initially truncated. Missing relevant portions were subsequently read explicitly; truncated output was not counted as completed verification. The entire new note and all source-control code were read, with targeted rereads of changed arguments, the tube comparison and detector range statements. This is internal author checking, not independent reconstruction. The RWW/NSY primary papers and earlier source helpers were not re-reviewed or rerun: the new work reuses the exact supplied source-bound theorem at its checked scope.

## Analytic content and finite controls

The full proof is in `../DETECTOR_INDEX_LEAKAGE_PROBE.md`. Its core needs the matched index theorem, cyclicity/faithfulness, microscopic H/current implementations, common-q selected covariance, and the gap/unique-vacuum assumptions. EX is absent. Reviewed detector range inclusion is sufficient to turn complement weight into a lower bound on the detector zero atom. Optional new family coverage supplies equality only if separately accepted.

`check_leakage_controls.py` checks six finite mechanisms: sharp abstract defect coefficient; ordered noncommutative A/B identity with both terms necessary; cutoff and local-energy arithmetic; positive detector kernels and failure of nonselfadjoint range reasoning; exact noncommuting resolvent identity plus a failed joint-limit example; and numerical arithmetic for the finite-block tube inequality. These do not prove the infinite-dimensional statements or the physical model. The tube numerical constants are illustrative inputs, not derived microscopic couplings; no exponentially large supersite matrix was built.

`run_controls.py` was run once. `logs/execution_records.json` records the full interpreter commands, 60-second declared timeouts, UTC starts, elapsed times, exit codes, source hashes and output paths. Baseline exit was 0. All six copied-source mutants exited 1 at their intended assertion; the actual tracebacks were inspected and are preserved. The mutations change the denominator 4 to 3, remove either ordered identity term, halve the local commutator factor, remove the high-energy subtraction, and reverse the resolvent sign. The mutations and output files are retained rather than overwritten. No baseline failure or counterexample to the displayed conditional theorem was found by these limited controls.

`finalize_freeze.py` performs only identity/bookkeeping checks. It verifies exact mutant deltas, execution source hashes and intended assertion messages; it does not rerun the science controls or turn their count into proof. Its receipt explicitly excludes itself as a checksum target only in the sense that the receipt cannot hash its own bytes; the script itself is included in the inventory. The receipt's final SHA is reported separately to the supervisor.

## Searches and novelty limit

Full search commands, exit codes, result counts, stdout and stderr are preserved in `logs/searches.json` and `logs/search_*.txt`. Searches used pinned `git grep` because the target is a historical commit, not mutable working-tree text. They scanned main markdown and no-go ledgers for defect/complement, cyclic/detector, index/leakage, shift/index/Hamiltonian, and prior negative rhetoric. There were respectively 7, 1, 0, 62 and 47 matches. Result snippets and filename inventories were inspected to select relevant history; unrelated full papers were not read or asserted as support.

The proper-subspace conclusion is the existing N1 contrapositive. No broad literature novelty or universal impossibility is inferred from absent matches. Added content is the explicit defect-to-weight and local finite-energy bounds, honest state conversion, the optional finite-block quantitative obstruction, and detector-kernel translation using range alone. The N1–N8 gate and live escape routes are in the note.

## Remaining independent work

The new L1–L27 derivation still requires a separate source-bound reviewer. Priority checks are the sign and beta convention in L3/L6; the exact local interaction norm, domain and commuting projections in §5; the extension of the reviewed tube theorem in §7; and positivity/range versus coverage in §8. A physical realization and justified enlarged channel selection remain open. No audit result, AXIOM change, detector ND proof, completeness result or universal preparation-energy lower bound is claimed.
