#!/usr/bin/env python3
"""One-shot source identity, execution-evidence validation and receipt creation.

No science control is rerun here. No Git state is changed. A receipt cannot
hash itself; report its SHA-256 separately after this process exits.
"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
S = HERE.parent
CHECKOUT = S.parent / "scattering_worktree"
NOTE = S / "DETECTOR_INDEX_LEAKAGE_PROBE.md"
RECEIPT = HERE / "freeze_receipt.json"
IDENTITY = HERE / "logs/final_identity_check.json"
assert not RECEIPT.exists() and not IDENTITY.exists(), "preserve earlier freeze evidence"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=CHECKOUT)

sources = []
for name in ("source_manifest.initial.json", "source_manifest.additional.json"):
    sources.extend(json.loads((HERE / name).read_text()))
for origin, copy, expected in (
    (S / "DETECTOR_SCATTERING_PROJECTION_PROBE.md",
     "sources/DETECTOR_SCATTERING_PROJECTION_PROBE.md",
     "91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4"),
    (S / "detector_scattering_projection/freeze_receipt.json",
     "sources/projection_freeze_receipt.json",
     "41e516aec74bd86d28702f5c079522f9ba8c91422eb660021190a241de176b72"),
):
    sources.append({"source": str(origin), "copy": copy, "sha256": expected})

identity_rows = []
for item in sources:
    copied = (HERE / item["copy"]).read_bytes()
    origin = item["source"]
    original = Path(origin).read_bytes() if origin.startswith("/") else git("show", origin)
    expected = item["sha256"]
    assert sha(copied) == expected, ("frozen copy drift", item["copy"])
    assert sha(original) == expected, ("identified source drift", origin)
    assert copied == original
    if "lines" in item:
        assert len(copied.splitlines()) == item["lines"], ("line count drift", origin)
    identity_rows.append({**item, "current_source_sha256": sha(original),
                          "copy_equal_to_source": True})

base = (HERE / "check_leakage_controls.py").read_text()
executions = json.loads((HERE / "logs/execution_records.json").read_text())
messages = {
    "bad_defect_coefficient": "AssertionError: defect coefficient invalid",
    "omit_first_identity_term": "AssertionError: ordered A,B identity requires first term",
    "omit_second_identity_term": "AssertionError: ordered A,B identity requires second term",
    "halve_energy_bound": "AssertionError: local generator bound needs factor two",
    "omit_high_energy_tail": "AssertionError: cutoff inequality needs high-energy subtraction",
    "reverse_zero_resolvent_sign": "AssertionError: zero-resolvent identity has wrong sign or order",
}
assert len(executions) == 7
for row in executions:
    path = Path(row["command"][-1])
    assert path.is_relative_to(HERE)
    assert sha(path.read_bytes()) == row["source_sha256"]
    assert row["declared_timeout_seconds"] == 60 and not row["timeout"]
    stdout = HERE / row["stdout"]
    stderr = HERE / row["stderr"]
    assert stdout.exists() and stderr.exists()
    if row["label"] == "baseline":
        assert row["exit_code"] == 0 and stderr.read_bytes() == b""
        assert '"outcome": "all finite controls satisfied"' in stdout.read_text()
    else:
        mutation = row["mutation"]
        assert base.count(mutation["old"]) == 1
        assert path.read_text() == base.replace(mutation["old"], mutation["new"])
        assert row["exit_code"] == 1
        assert messages[row["label"]] in stderr.read_text()

identities = {
    name: git("rev-parse", name).decode().strip()
    for name in ("HEAD", "main", "origin/main")
}
assert identities == {
    "HEAD": "296155eda2ca6a5ab6ae6307190362b9a84ea690",
    "main": "e485eab6b09b3957df5772104d3ea3980108d7fa",
    "origin/main": "a13caa4885f547c8d206265b031ba7649e539fd9",
}, identities
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
IDENTITY.write_text(json.dumps({
    "checked_utc": stamp,
    "source_rows": identity_rows,
    "checkout": str(CHECKOUT),
    "git_identities": identities,
    "git_status_porcelain": git("status", "--porcelain=v1").decode(),
    "identity_scope": "Byte identity and actual recorded control/mutation outputs; not science validation",
    "baseline_executions_verified": 1,
    "specific_source_mutations_verified": list(messages),
    "science_controls_rerun": False,
}, indent=2) + "\n")

def file_row(path):
    data = path.read_bytes()
    return {"path": str(path), "relative_to_S": str(path.relative_to(S)),
            "sha256": sha(data), "bytes": len(data), "lines": len(data.splitlines())}

files = [NOTE] + sorted(p for p in HERE.rglob("*") if p.is_file() and p != RECEIPT)
receipt = {
    "frozen_utc": stamp,
    "role": "author derivation; independent source-bound review required",
    "science_authority": "a13caa4885f547c8d206265b031ba7649e539fd9",
    "planning_authority": "3a4b2c66a1ead7a1c48b4359627e968f681e3c39",
    "checkout_at_acquisition": "c3f84746b1991e0a15c6da79d049b89d9469f727",
    "checkout_at_freeze": identities["HEAD"],
    "concurrent_change": "Supervisor's reviewed E/PC publication; all bound source bytes unchanged",
    "parent_is_coauthor": True,
    "EX_assumed": False,
    "new_projection_coverage_core_dependency": False,
    "prompt_files_changed": [],
    "worker_git_mutation": False,
    "model_or_effort_override": False,
    "subdelegation": False,
    "note": file_row(NOTE),
    "files": [file_row(p) for p in files],
    "excluded": [str(RECEIPT)],
    "self_hash_policy": "Receipt is excluded from its own inventory; its SHA is reported separately",
}
RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"receipt": str(RECEIPT), "receipt_sha256": sha(RECEIPT.read_bytes()),
                  "note": receipt["note"], "frozen_files": len(files),
                  "unchanged_bound_sources": len(identity_rows)}, indent=2))
