# Independent review of the selected scattering projection

**Disposition: PASS for the frozen conditional P1–P33 theorem. No required
source correction or counterexample was found.** The theorem supports an
existential countable detector resolution of the already selected outgoing
scattering projection, its displayed ordered strong limits, and the conditional
finite-time lower witness. It does not prove no-common-kernel ND, full-GNS
exhaustion EX, all-channel coverage, physical realization or formal retention.

The reviewed source is the complete 330-line
`DETECTOR_SCATTERING_PROJECTION_PROBE.md`, SHA-256
`91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4`.
Its author receipt is
`41e516aec74bd86d28702f5c079522f9ba8c91422eb660021190a241de176b72`.
All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The complete reconstruction and evidence are in `detector_projection_review/`.
The frozen note and author packet remain unchanged.

The independent reconstruction and separately written rational control were
frozen before opening the new author's helper, logs, receipt or controls, at
2026-10-12T01:55:53.921827+00:00. The freeze record is
`detector_projection_review/precontrol_freeze.json`, SHA-256
`76c3d7adfc4cfa8d5c77f427aa35f8aaf1615b08e537103b9f6677eb985f895a`.
The statement and its own control descriptions were visible. The supplied
Fock/PC source reviews were read; their labels were not substituted for proofs.
Root proposed key mechanisms and is a coauthor. This reviewer claims neither
blind route discovery, a different model family, nor formal proof verification.

| Frozen source lines | Reconstructed conclusion and scope |
|---|---|
| 1–70, P1–P5 | The target is exactly the existing selected F2 outgoing range, with the supplied microscopic conditions and unique gapped vacuum. Its closed, reducing status follows from Fock isometry and covariance. PC is used only for a fixed direct filtered arrangement. Borel compression follows from the interval result without an energy-boundary approximation. |
| 72–129, P6–P11 | Finite smooth packet partitions admit narrow positive temporal intervals and full operator geometric carriers. Both filters act on arbitrary operator transitions, with the stated Fourier signs. They preserve each packet's exact one-particle vector. Temporal filtering of an almost-local seed uses LR only on a bounded time region and a norm-controlled Schwartz tail; kernel derivatives and spatial smearing preserve the direct creator class. |
| 131–144, P12–P13 | The F5 Gram identity gives creator-independence after refiltering; finite multilinearity then preserves the entire scattering product exactly. Small carrier balls, detector supports and enlarged convex balls retain positive cross-factor separation. This resolves disconnected original velocity supports and includes n=1. Each refined term is a range vector of an admissible bounded PC creation map. |
| 146–180, P14–P17 | Covariance intertwines the whole sum-energy spectral measure for arbitrary Borel J. A term is discarded only when its compact sum support misses J. A retained sum energy gives the strict bound `diam(J)+2 sum(r_i)<gamma/2` for the closed hull and all closed transfer intervals. This handles open/half-open endpoints and singleton hulls without boundary-null assumptions. Projected generators are dense only in the already selected `P_J H_sc`. |
| 182–205, P18–P20 | Carrier weight one gives `Q_alpha=A_alpha A_alpha*`. The vacuum remainder gives the exact finite positive coincidence expression, containing no scattering projection. Positivity is not inferred from a noncommuting product of separate detectors. PC's common-word lowering and duality estimate supplies the actual finite arrangement bound. |
| 207–246, P21–P25 | Cyclicity of the separable local algebra makes the target separable. Countably many finite approximations select a range-dense detector family, including empty/finite cases. Positive weights normalized by actual bounds give norm summability. Its quadratic form vanishes exactly on the orthogonal complement of the chosen range span; hence support is exactly `P_J P_sc`. No arbitrary-family claim or lower frame bound enters. |
| 248–276, P26–P28 | The ordered resolvent identity is valid for noncommuting positive operators. It proves strong continuity at fixed eta, then the norm truncation bound `2^(-m)/eta`. Spectral dominated convergence gives the final strong eta limit. The asserted order is detector time, then countable truncation, then eta. No uncontrolled joint rate or uniform unit-ball convergence is inferred. |
| 278–292, P29–P30 | Disjoint half-open energy windows exhaust the positive spectral subspace; their orthogonality and the vacuum recover the full selected projection. Inner limits are taken for each fixed finite collection first. The complementary resolvent limit is exactly `P_J(1-P_sc)`; its vanishing on a countable cyclic set is equivalent to ND/energy capture, and remains unproved. |
| 294–313, P31–P33 | The finite-energy complement projection E is annihilated by every `S_alpha*`. PC C24a, including its uniform finite-energy remainder, gives operator-norm decay of `Q_alpha(t)E`. Positivity gives the square-root loss, and the triangle inequality yields the stated lower witness for B_alpha>0. Existence of constants does not provide numerical values; zero response gives no converse. |
| 315–330 | The stated failed shortcuts and counterexamples are valid at their explicit algebraic/Hilbert-space scope. They are not microscopic no-go results. The note correctly preserves the distinction between a failed uncontrolled joint limit and other potentially valid iterated orders. |

The crucial coverage proof was reconstructed directly: refilter the full
operators while preserving packet vectors, use the Fock Gram identity for the
new realizations, retain whole-product energy compression, and use a retained
sum energy to place the entire remainder interval strictly inside the vacuum
gap. This avoids any assumption that transfer intervals must fit inside J.
Countable selection then supplies the dense range span needed by the positive
common-kernel argument. Its use of a dense set in the selected target is an
existence proof, not an algorithm for discovering that target or enumerating
physical detector channels.

The complete creator source
`d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`,
EX scope repair
`d4aac1e14a20e82be994bd4b8de966f0063affcbaa22a40a173b126f77fa3516`,
Fock source
`9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404`
and Fock review
`bc88af1dda77065d8806da9d689546547f40847a340177086793dab5f3a277cf`
were read, with their actual creator-independence, covariance and density
arguments. The full PC source
`bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64`
and its separate review
`2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0`
were also read. The reconstruction checks the common-word energy bound,
complete scalar source, full momentum filtering, two-time kernel sign and
both Schur sums, fixed-time compactness and the order of the reversed integral,
including C24a. It does not infer strong convergence of unlocalized adjoints.
Upstream physical hypotheses and previously reviewed primary-source imports
remain conditional inputs; unrelated N1 conclusions are outside this verdict.

The primary [DG v1 comparator](https://arxiv.org/abs/1308.5187v1) was checked
against its actual hypotheses and complete Section 7 in freshly extracted
pages 4–9 and 20–22 of the hash-bound PDF. Its relativistic spacetime/global-shell
setting and joint energy–momentum admissibility are not imported. Lemma 7.5
refers its proof elsewhere; that external proof was neither read nor used.
The frozen note's limited analogy is accurate. Full reading limits and the
exact PDF/page identities are in `detector_projection_review/PRIMARY_COMPARISON.md`
and `detector_projection_review/primary_extraction.json`; no novelty or full literature-certification claim
is made.

The separately written control uses a nonorthogonal chain of detector
vectors, exact row-reduction of its common kernel, noncommuting resolvents,
and a rationally rotating family showing uncontrolled joint-limit failure.
It ran under a 60-second timeout, exited 0 in about 0.027 seconds, and retained
all four records and empty stderr. Those are finite algebra checks. The
infinite-dimensional support and convergence statements are supported by the
analytic reconstruction, not the number of samples.

The author receipt matched all 34 input and 23 output bindings; the 63 saved
predecessor bindings also matched deterministically. The complete helper and
logs were inspected. Its recorded command reproduced all seven stdout records
and empty stderr byte for byte under a 60-second timeout, exiting 0 in about
0.038 seconds. Copied-code perturbations detected wrong transfer filtering,
omitted partition terms, signed weights and invalid resolvent order, among
other finite defects. All failure traces are retained.

One nonblocking control limitation is explicit: replacing the square-root
error by a linear error still passes the author's 588-case witness sweep,
because that toy family admits the stronger bound. The separate scalar
negative example and the analytic P32 proof establish the universal need for
the square root. The reviewer made the scalar operator case explicit:
`Q=(1/16)E` gives a false lower witness 3/4 for a zero selected component if
the error is incorrectly made linear. The theorem uses the correct formula.
No correction is required, but the sweep alone must not be credited with
general positive-operator coverage. `detector_projection_review/AUTHOR_EVIDENCE_ASSESSMENT.md` records
the full distinction and the author's corrected unfrozen limit-order claim.

The scope stops at the chosen scattering sector. The family may be existential;
no effective enumeration, lower frame bound, numerical witness constants,
uniform eta rate, all-channel detection, ND or EX is established. No physical
axiom, empirical prediction, retained status or independent audit verdict is
supplied by this review. The inherited model/effort was preserved without
subdelegation. Editable prompt files changed: none.

Instruction sources were the pinned science revision
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning revision
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The checkout initially had HEAD
`c3f84746b1991e0a15c6da79d049b89d9469f727`; root then reported its own concurrent
E/PC publication at `296155eda2ca6a5ab6ae6307190362b9a84ea690`. The frozen
external inputs remained byte-identical. This reviewer made no Git change,
and the new publication files are not covered here. Only this report and
`detector_projection_review/` were written. The final receipt refreshes source
identities and binds all review evidence. Unseen publication changes require
affected source confirmation. Fixed deadline: 2026-10-12 16:00:52 UTC.
