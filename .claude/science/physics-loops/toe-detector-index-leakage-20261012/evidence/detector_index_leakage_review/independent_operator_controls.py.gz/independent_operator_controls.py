"""Exact finite operator-order controls; no physical-model assertion.

Written before opening the new author's helper. All principal minors are
computed by rational elimination, so PSD checks certify all fixture vectors.
The fixtures and target formulas were chosen from the written argument.
"""
from fractions import Fraction as F
from itertools import combinations
import json


def mat(rows):
    return [[F(x) for x in row] for row in rows]


def eye(n):
    return mat([[int(i == j) for j in range(n)] for i in range(n)])


def diag(xs):
    return mat([[x if i == j else 0 for j in range(len(xs))] for i, x in enumerate(xs)])


def tr(a):
    return [list(x) for x in zip(*a)]


def add(a, b, scale=F(1)):
    return [[x + scale*y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def mul(a, b):
    return [[sum(x*y for x, y in zip(ar, bc)) for bc in zip(*b)] for ar in a]


def scale(a, c):
    return [[c*x for x in row] for row in a]


def zero(a):
    return all(x == 0 for row in a for x in row)


def det(a):
    a = [r[:] for r in a]
    value = F(1)
    for k in range(len(a)):
        p = next((p for p in range(k, len(a)) if a[p][k]), None)
        if p is None:
            return F(0)
        if p != k:
            a[p], a[k] = a[k], a[p]
            value *= -1
        pivot = a[k][k]
        value *= pivot
        for i in range(k+1, len(a)):
            factor = a[i][k]/pivot
            for j in range(k+1, len(a)):
                a[i][j] -= factor*a[k][j]
    return value


def psd(a):
    assert a == tr(a), "PSD requires real symmetry"
    n = len(a)
    for size in range(1, n+1):
        for indices in combinations(range(n), size):
            minor = det([[a[i][j] for j in indices] for i in indices])
            if minor < 0:
                return False, list(indices), str(minor)
    return True, None, None


def inv(a):
    n = len(a)
    b = [r[:] + er for r, er in zip(a, eye(n))]
    for k in range(n):
        p = next(p for p in range(k, n) if b[p][k])
        b[p], b[k] = b[k], b[p]
        pivot = b[k][k]
        b[k] = [x/pivot for x in b[k]]
        for i in range(n):
            if i == k:
                continue
            factor = b[i][k]
            b[i] = [x-factor*y for x, y in zip(b[i], b[k])]
    return [r[n:] for r in b]


def outer(v):
    return mat([[x*y for y in v] for x in v])


def reflect(v):
    return add(eye(len(v)), outer(v), -F(2, sum(x*x for x in v)))


def normsq(v):
    return sum(x*x for x in v)


def apply(a, v):
    return [sum(x*y for x, y in zip(r, v)) for r in a]


def emit(name, **kwargs):
    print(json.dumps({"check": name, **kwargs}, sort_keys=True))


n = 7
I = eye(n)
P0 = diag([1, 0, 0, 0, 0, 0, 0])
Pd = diag([1, 1, 1, 0, 0, 0, 0])
Hd = diag([0, 2, 2, 7, 7, 13, 17])
Ud = eye(n)
Ud[3][3] = Ud[4][4] = F(3, 5)
Ud[3][4], Ud[4][3] = -F(4, 5), F(4, 5)
Ud[5][5] = -1
S = reflect([0, 1, 2, 1, -1, 1, 2])


def basis(a):
    return mul(mul(S, a), tr(S))


P, H, U = basis(Pd), basis(Hd), basis(Ud)
Q = add(I, P, -1)
Pi = add(I, P0, -1)
D = add(U, I, -1)
assert mul(tr(U), U) == I
assert mul(U, P) == P
assert mul(H, U) == mul(U, H)
assert mul(H, P) == mul(P, H)
assert mul(P, P) == P
assert psd(add(scale(Q, 4), mul(tr(D), D), -1))[0]
wrong_defect = psd(add(Q, scale(mul(tr(D), D), F(1, 3)), -1))
assert not wrong_defect[0]
fixed_complement = apply(S, [0, 0, 0, 0, 0, 0, 1])
assert apply(Q, fixed_complement) == fixed_complement
assert normsq(apply(D, fixed_complement)) == 0
emit("all-vector sharp defect order", wrong_one_third_negative_minor=wrong_defect[1:],
     complementary_fixed_line=True, fixture_dimension=n)

cutoffs = [F(2), F(6), F(7), F(10), F(13), F(16), F(17), F(20)]
tail_failures = []
for E in cutoffs:
    FE = basis(diag([int(2 <= e <= E) for e in [0, 2, 2, 7, 7, 13, 17]]))
    # psi* (Q FE + H^2/E^2 - D*D/4) psi >= 0 is L1 for every psi.
    order = add(add(mul(Q, FE), scale(mul(H, H), 1/(E*E))),
                scale(mul(tr(D), D), F(1, 4)), -1)
    assert psd(order)[0], (E, psd(order))
    omitted = add(mul(Q, FE), scale(mul(tr(D), D), F(1, 4)), -1)
    bad = psd(omitted)
    if not bad[0]:
        tail_failures.append({"E": str(E), "minor": bad[1:],})
assert tail_failures
emit("all-vector energy-window order", exact_cutoffs=[str(E) for E in cutoffs],
     missing_tail_rejections=tail_failures)

# Six norm-one Householder A operators; each is checked as a full identity
# and by an all-vector quadratic estimate, with no selected vacuum input.
identity_omissions = [0, 0]
for j in range(1, n):
    v = [int(k == 0) + 2*int(k == j) for k in range(n)]
    A = reflect(v)
    DA = add(mul(mul(U, A), tr(U)), A, -1)
    first = mul(D, A)
    second = mul(mul(U, A), add(tr(U), I, -1))
    assert add(first, second) == DA
    identity_omissions[0] += not zero(add(DA, first, -1))
    identity_omissions[1] += not zero(add(DA, second, -1))
    L15 = add(add(mul(mul(tr(A), Q), A), Q),
              scale(mul(tr(DA), DA), F(1, 8)), -1)
    assert psd(L15)[0]
assert min(identity_omissions) > 0
emit("ordered identity and all-vector L15", norm_one_A_count=6,
     omitted_term_failures=identity_omissions)

v, w = [0, 1, 2, 0, 0, 0, 0], [0, 1, 1, 0, 0, 0, 0]
Q1, Q2 = basis(outer(v)), basis(outer(w))
assert not zero(add(mul(Q1, Q2), mul(Q2, Q1), -1))
assert psd(Q1)[0] and psd(Q2)[0]
assert zero(mul(Q1, Q)) and zero(mul(Q2, Q))
K = scale(add(Q1, Q2), F(1, 12))
assert psd(add(Pi, K, -1))[0]
# In the original basis K's selected 2x2 block has determinant 1/144.
selected = [[basis(K)[i][j] for j in [1, 2]] for i in [1, 2]]
assert det(selected) == F(1, 144)
# One detector leaves a selected scattering line in the zero atom.
Zsingle = add(Pi, scale(Q1, F(1, 5)), -1)
assert mul(Zsingle, Zsingle) == Zsingle
assert psd(add(Zsingle, Q, -1))[0]
assert not zero(add(Zsingle, Q, -1))
traces = []
for eta in [F(1), F(1, 2), F(1, 4), F(1, 16), F(1, 256)]:
    Reta = mul(scale(inv(add(K, scale(I, eta))), eta), Pi)
    difference = add(Reta, Q, -1)
    assert psd(difference)[0]
    traces.append(sum(difference[i][i] for i in range(n)))
assert all(a > b for a, b in zip(traces, traces[1:]))
emit("noncommuting positive detector sum and exact resolvents",
     selected_block_determinant="1/144", incomplete_family_has_extra_zero=True,
     positive_trace_above_complement=[str(x) for x in traces])

# A range-only non-self-adjoint control fails the annihilation inference.
R = mat([[int(i == 1 and j == 3) for j in range(n)] for i in range(n)])
R = basis(R)
assert mul(P, R) == R
assert not zero(mul(R, Q))
# In a vanishing eigenvalue 1/T, eta/(eta+1/T) demonstrates nonuniformity.
eta_first = [F(1, k)/(F(1, k)+1) for k in [1, 10, 1000]]
time_first = [1/(1+F(1, k)) for k in [1, 10, 1000]]
assert eta_first[-1] < F(1, 100) and time_first[-1] > F(99, 100)
emit("missing-premise controls", nonselfadjoint_range_does_not_kill_Q=True,
     eta_first_at_fixed_T=[str(x) for x in eta_first],
     T_first_at_fixed_eta=[str(x) for x in time_first])

print("TOTAL: 6 finite exact control groups completed; no infinite-lattice or physical-model claim")
