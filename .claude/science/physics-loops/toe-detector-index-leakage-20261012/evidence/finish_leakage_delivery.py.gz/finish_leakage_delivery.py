"""Validate and stage the full conditional leakage milestone."""
from pathlib import Path
from urllib.parse import unquote
import ast,gzip,hashlib,json,os,re,subprocess,sys
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-detector-index-leakage-20261012'
BASE='5cbc581504721a323f5fa2064694a67141a3ee98'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest()
js=lambda p:json.loads(p.read_text())
rows=js(P/'PUBLICATION_EDITS.json')['outputs'];assert len(rows)==2
primary=next(r for r in rows if r['kind']=='primary');body=(W/primary['publication_path']).read_text()
e=js(S/'leakage_canonical_execution.json')
assert e['status']=='ok' and e['exit_code']==0 and e['timeout_sec']==60 and not e['stderr']
old=(S/'detector_index_leakage/logs/baseline.stdout.txt').read_text()
assert e['stdout'].startswith(old) and len(old.splitlines())==12
assert len(e['stdout'][len(old):].splitlines())==2
runs=js(S/'leakage_primary_mutations/manifest.json')['runs'];assert len(runs)==6
for r in runs:
 assert r['primary_sha256']==sha(body.encode()) and body.count(r['before'])==1
 p=S/'leakage_primary_mutations'/(r['name']+'.py')
 assert p.read_text()==body.replace(r['before'],r['after'],1) and sha(p.read_bytes())==r['source_sha256']
 out=p.with_suffix('.stdout').read_bytes();err=p.with_suffix('.stderr').read_bytes()
 assert sha(out)==r['stdout_sha256'] and sha(err)==r['stderr_sha256']
 assert r['exit_code']==1 and b'AssertionError' in err and e['stdout'].encode().startswith(out)
 original=(S/'detector_index_leakage/logs'/f"{r['name']}.stderr.txt").read_text().splitlines()[-1]
 assert err.decode().splitlines()[-1]==original
graph=W/'docs/audit/data/citation_graph_manifest.json'
before=json.loads(subprocess.check_output(['git','show',BASE+':'+str(graph.relative_to(W))]));after=js(graph)
assert after['node_count']==before['node_count']+1 and after['edge_count']==before['edge_count']+4
assert all(after['nodes'].get(k)==v for k,v in before['nodes'].items())
assert {k:v['out_degree'] for k,v in after['nodes'].items() if k not in before['nodes']}=={'detector_index_leakage_bounded_theorem_note_2026-10-12':4}
compat=js(S/'leakage_focused_audit_compat.json');assert compat['checked']==compat['failures']==compat['control_failures']==[]
(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete source composition

Root read the full author proof, separate reconstruction, finite controls,
assessment and relevant premise arguments at their frozen identities. Root
proposed the mechanism and is coauthor. The independent checker found no
required correction; this does not make supplied physical premises independent.

Publication edits only identify claim/dependency/status/recovery metadata and
label historical author operations. The full L1-L27 argument and N1-N8 scope
stress tests are unchanged. Optional projection applicability is now checked
for its chosen family; its conditional theorem statement remains unchanged.
The entire finite helper is preserved with declared inputs, timeout and an
assertion guard. Exact source reconstruction checks both full outputs.

PR9485 at b8402c17d337f371c0c73696ef170727de9ab5bd is an explicit required
unmerged index dependency. The complete proof and review are frozen here,
and the primary input identity includes that proof. It is not silently present
on main. Four in-branch dependencies are graphed; projection is optionalL27.

No previous science source changes. No microscopic model, effective local
preparer, measurement probability, all-channel no-go, Lean or retained claim.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped delivery evidence

The canonical primary exited0 in{e['elapsed_sec']:.9f}s under its declared60s
timeout, with empty stderr. All12original output records reproduce byte-exact,
followed by2publication scope/summary lines. Six actual whole-primary defects
fail at their intended assertions: stronger defect coefficient, either omitted
ordered identity term, halved local-energy factor, omitted spectral tail, and
reversed resolvent sign. Every altered full source, command, timeout, complete
stdout and stderr is preserved. Source deltas and output prefixes are checked
against the actual publication primary; finite controls are not analytic proof.

Citation acknowledgment gives{after['node_count']}nodes and{after['edge_count']}edges,
adding1node and4in-branch dependencies with every older node unchanged. The
required unmerged index dependency is separately explicit in metadata, prose
and frozen source evidence, not represented as a node already on this branch.
Focused changed-evidence compatibility selects no applied rows and has no
failures. The global combined audit pipeline and strict audit lint were not run;
those remain independent landing gates and no audit verdict is applied.

Exact reconstruction, syntax, declared-input/cache identity, local links,
all evidence and staged hashes, vocabulary fix/report and whitespace are
checked before commit. All old SC/Fock/E/PC/projection science is unchanged.
No effective physical witness, full channel coverage or retained promotion.
''')
p=P/'REVIEW_HISTORY.md';p.write_text(p.read_text()+'''
## Publication conformance

Goal, trace, actual dependencies and conditional claim are explicit. Whole
source proof and evidence remain distinguishable from toy controls and their
execution. Full primary mutations, canonical output, exact reconstruction,
scoped citation/audit compatibility and source identities are checked. Regular
PR extension only; no draft, merge, main push, prompt/axiom edit or verdict.
''')
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in rows]+[P/'reconstruct.py']
for mode in ['fix','report-only']:
 prefix=S/('leakage_final_vocab_'+mode)
 r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
 prefix.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
 report=js(prefix.with_suffix('.json'));assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'leakage_final_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
ast.parse(body)
assert runner_cache.cache_status(primary['publication_path'])==runner_cache.cache_identity_status(primary['publication_path'])=='fresh'
links=[]
for p in editable:
 if p.suffix!='.md':continue
 prose=[];fenced=False
 for line in p.read_text().splitlines():
  if line.lstrip().startswith('```'):fenced=not fenced;continue
  if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
 for target in re.findall(r'\]\(([^)\s]+)\)','\n'.join(prose)):
  if target.startswith(('http:','https:','#','mailto:')):continue
  assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(p,target)
  links.append(dict(source=str(p.relative_to(W)),target=target))
emap=js(P/'EVIDENCE_MAP.json');evidence={r['preserved']:r for r in emap['files']}
def preserve(src):
 b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(b,mtime=0)
 if dst.exists():assert dst.read_bytes()==packed
 dst.write_bytes(packed);evidence[str(dst.relative_to(P))]=dict(original=str(src),preserved=str(dst.relative_to(P)),bytes=len(b),sha256=sha(b))
for p in sorted((S/'leakage_primary_mutations').rglob('*')):
 if p.is_file():preserve(p)
for n in ['prepare_leakage_publication.py','run_leakage_verification.py','finish_leakage_delivery.py',
 'leakage_canonical_execution.json','leakage_initial_vocab_fix.json','leakage_initial_vocab_fix.log','leakage_initial_reconstruction.log',
 'leakage_final_vocab_fix.json','leakage_final_vocab_fix.log','leakage_final_vocab_report-only.json','leakage_final_vocab_report-only.log','leakage_final_reconstruction.log',
 'leakage_citation_execution.json','leakage_citation_build.stdout','leakage_citation_build.stderr','leakage_citation_manifest.stdout','leakage_citation_manifest.stderr',
 'leakage_focused_audit_compat.json','leakage_focused_audit_compat.stderr','leakage_focused_audit_compat.execution.json']:
 preserve(S/n)
for r in evidence.values():
 b=gzip.decompress((P/r['preserved']).read_bytes());assert len(b)==r['bytes'] and sha(b)==r['sha256']
assert not emap['external_reference_sources']
mech=dict(full_source_reconstruction=True,canonical_elapsed_seconds=e['elapsed_sec'],actual_primary_assertion_failures=6,
 cache_and_input_identity_fresh=True,citation_delta=dict(nodes=1,edges=4),every_old_graph_node_unchanged=True,
 preserved_evidence_files_before_this_record=len(evidence),external_primary_bindings=0,ordinary_links=links,
 required_cross_pr=dict(number=9485,head='b8402c17d337f371c0c73696ef170727de9ab5bd',status='unmerged_provisional',complete_source_preserved=True),
 scope='Mechanical provenance/execution only; complete separate source reconstruction supplies the mathematical check.')
(S/'leakage_delivery_mechanical.json').write_text(json.dumps(mech,indent=2)+'\n');preserve(S/'leakage_delivery_mechanical.json')
emap['files']=[evidence[k] for k in sorted(evidence)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in rows]+[graph,runner_cache.cache_path_for(primary['publication_path'])]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
 row=dict(path=str(p.relative_to(W)),sha256=sha(p.read_bytes()))
 if p.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(p.read_bytes()))
 ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,scope='Exact intended publication set except this self-referential manifest.',files=ident),indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True,timeout=60);subprocess.run(['git','diff','--cached','--check'],check=True,timeout=60)
for r in ident:assert sha(subprocess.check_output(['git','show',':'+r['path']]))==r['sha256']
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}==set(paths)
assert not subprocess.check_output(['git','diff','--name-only'])
assert all(x.startswith('A\t') or x=='M\tdocs/audit/data/citation_graph_manifest.json' for x in subprocess.check_output(['git','diff','--cached','--name-status'],text=True).splitlines())
result=dict(staged_files=len(paths),staged_hashes_match=True,whitespace_clean=True,preserved_evidence_files=len(evidence),**mech)
(S/'leakage_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
