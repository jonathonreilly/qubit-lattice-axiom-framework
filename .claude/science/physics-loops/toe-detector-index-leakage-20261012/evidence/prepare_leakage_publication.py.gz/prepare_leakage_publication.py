"""Package the complete reviewed leakage theorem without changing its proof."""
from pathlib import Path
import gzip, hashlib, json, subprocess

S=Path(__file__).resolve().parent; W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-detector-index-leakage-20261012'
BASE='5cbc581504721a323f5fa2064694a67141a3ee98'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==BASE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert json.loads((S/'Leakage_root_review_coverage.json').read_text())['review_accepted']
P.mkdir(exist_ok=False)
note='DETECTOR_INDEX_LEAKAGE_BOUNDED_THEOREM_NOTE_2026-10-12.md'
runner='detector_index_leakage_2026_10_12.py'
claim='detector_index_leakage_bounded_theorem_note_2026-10-12'
deps=['compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11',
      'compact_patch_fock_isometry_bounded_theorem_note_2026-10-12',
      'compact_detector_convergence_bounded_theorem_note_2026-10-12',
      'detector_scattering_projection_bounded_theorem_note_2026-10-12']
precursors=['COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md',
 'COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md',
 'COMPACT_DETECTOR_CONVERGENCE_BOUNDED_THEOREM_NOTE_2026-10-12.md',
 'DETECTOR_SCATTERING_PROJECTION_BOUNDED_THEOREM_NOTE_2026-10-12.md']
src=S/'DETECTOR_INDEX_LEAKAGE_PROBE.md'; raw=src.read_text()
assert sha(raw.encode())=='4d1e9b888c6e84881e8d356c42e8da521794c68191ebcebab1c145ced5189747'
edits=[]
def edit(before,after,reason):
 global raw
 assert raw.count(before)==1,(before,raw.count(before))
 raw=raw.replace(before,after,1);edits.append(dict(before=before,after=after,reason=reason))
scope='For supplied microscopic finite-range H/current implementations and a fixed common-q selected scattering range, the index defect gives explicit positive finite-energy complement weight, two-state operator-to-vector bounds, an optional finite-block defect bound and selected-detector zero-atom bounds. No model, numerical local witness, all-channel no-go or physical readout probability is constructed.'
meta='---\nclaim_id: '+claim+'\nclaim_type: bounded_theorem\nclaim_scope: '+json.dumps(scope)+'\nupstream_dependencies:\n'+''.join('  - '+d+'\n' for d in deps)+'runner: scripts/'+runner+'\ncross_pr_dependencies:\n  - pr: 9485\n    revision: b8402c17d337f371c0c73696ef170727de9ab5bd\n    role: required_partial_factor_index_proof\n    status: provisional_unmerged\n    source_sha256: bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441\n'
edit('---\nactual_current_surface_status:',meta+'actual_current_surface_status:','Register actual in-branch and explicit unmerged cross-PR proof dependencies.')
line=next(x for x in raw.splitlines() if x.startswith('**Author derivation,'))
edit(line,'**Conditional bounded theorem, 2026-10-12.** A separate complete source reconstruction supports L1–L26 and optional L27 at their stated hypotheses, with no required correction. The supervisor proposed the mechanism and is a coauthor, not its independent reviewer. No applied audit verdict or retained status is conferred. Physical implementations and the selected common-q scattering setting remain supplied conditions.','Record completed independent source review only.')
line=next(x for x in raw.splitlines() if x.startswith("Write S for this note's directory."))
edit(line,'S denotes the original research collection. The [complete milestone packet](../.claude/science/physics-loops/toe-detector-index-leakage-20261012/) preserves the full frozen proof, sources, separate review, controls and failures; EVIDENCE_MAP.json gives exact recovery. The required partial-factor index proof is a provisional cross-PR dependency in [PR #9485](https://github.com/jonathonreilly/qubit-lattice-axiom-framework/pull/9485), head b8402c17d337f371c0c73696ef170727de9ab5bd. Its complete original source and review are preserved here; it is not assumed present on main. In-branch inputs are [compact creators]('+precursors[0]+'), [Fock isometry]('+precursors[1]+') and [detector convergence]('+precursors[2]+'). The [selected projection]('+precursors[3]+') is used only for optional L27. Science authority remains a13caa4885f547c8d206265b031ba7649e539fd9 and planning3a4b2c66a1ead7a1c48b4359627e968f681e3c39. Author acquisition and concurrent publication records remain frozen in the packet.','Replace workspace-only navigation with portable evidence and explicit cross-PR dependency.')
line=next(x for x in raw.splitlines() if x.startswith('The optional §9 input is '))
edit(line,line+' Publication update: its separate review is complete, SHA d9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2, receipt1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b. The leakage checker separately verified the chosen-family applicability; the conditional statement in §9 remains unchanged.','Label the historical pending state and add current exact applicability evidence.')
line=next(x for x in raw.splitlines() if x.startswith('The priority independent checks are '))
edit(line,'Frozen author review priorities: '+line+' Publication update: those checks are now complete in the separate report preserved below; no Lean verification is asserted.','Preserve historical priorities and identify their completed source review.')
line=next(x for x in raw.splitlines() if x.startswith('Only this new note and its assigned evidence directory were written.'))
edit(line,'Frozen author operational record: '+line,'Distinguish author-only operations from current publication.')
for line in list(dict.fromkeys(x for x in raw.splitlines(keepends=True) if x.rstrip('\r\n').endswith((' ','\t')))):
 edit(line,line.rstrip()+'\n','Presentation-only whitespace normalization.')
if raw.endswith('\n\n'):
 tail=raw[-180:];edit(tail,tail.rstrip()+'\n','Normalize final blank lines.')
append='''

## Publication verification and unresolved physical inputs

The separate report has SHA fbd6bbbfe6d725b531da2d3c53e650fbcbb07c8195d7af151043d5eab14df39f,
receipt0e96c15785d6e5f74d160a5753bdd33b47f91ac5f425de809e5749ecffaa9254.
The complete reconstruction and distinct rational operator-order control froze
at02:16:57UTC, before new author control inspection. The seven-dimensional
rotating fixture checks all principal minors, including a sharp reflection,
high-energy tails, both ordered identity terms and noncommuting positive sums.
Its five JSON records cover six finite subjects; they are not six independent
proofs. The complete author baseline and all six intended mutation failures
were reproduced exactly. Two reviewer searches exited with signal9; their
partial logs support no absence or novelty assertion.

The [finite control](../scripts/'''+runner+''') preserves every original calculation.
PUBLICATION_EDITS.json and reconstruct.py recover the full proof and primary
from frozen bytes and declared metadata additions. No displayed mathematical
argument is changed. DELIVERY_CHECKS.md records execution and mechanical checks.
Global combined audit and strict audit lint remain independent landing gates.

The result quantifies the complement of a fixed selected common-q channel set.
It does not establish that the supplied microscopic hypotheses are realizable,
construct an effective local preparer or detector measurement probability, or
exclude an enlarged scattering theory without a common finite denominator.
No Lean certificate, applied audit verdict, physical axiom change or retained
promotion is asserted. The sole live campaign checkpoint remains in the
transport worktree; this packet is a frozen milestone.
'''
(W/'docs'/note).write_text(raw+append)
rows=[dict(kind='note',source_path=str(src),source_sha256=sha(src.read_bytes()),preserved_source='evidence/'+src.name+'.gz',edits=edits,appended_text=append,publication_path='docs/'+note,publication_sha256=sha((raw+append).encode()))]
helper=S/'detector_index_leakage/check_leakage_controls.py';body=helper.read_text()
anchor='from fractions import Fraction as F\n';assert body.count(anchor)==1
inputs=['docs/'+note]+['docs/'+n for n in precursors]+[str(P.relative_to(W))+'/evidence/detector_index_leakage/sources/APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md.gz']
addition='AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = '+json.dumps(inputs,indent=4)+'\nif not __debug__:\n    raise RuntimeError("Run without -O: exact control assertions must be enabled")\n\n'+anchor
suffix='\nprint("TOTAL: PASS=6 FAIL=0")\nprint("SCOPE: Six original finite control groups; no physical realization, effective preparer or all-channel completeness.")\n'
primary=body.replace(anchor,addition,1)+suffix
(W/'scripts'/runner).write_text(primary)
rows.append(dict(kind='primary',source_path=str(helper),source_sha256=sha(helper.read_bytes()),preserved_source='evidence/detector_index_leakage/check_leakage_controls.py.gz',edits=[dict(before=anchor,after=addition,reason='Declare actual inputs, timeout and assertion guard; preserve every finite calculation.')],appended_text=suffix,publication_path='scripts/'+runner,publication_sha256=sha(primary.encode())))
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=rows),indent=2)+'\n')
texts={
 'STATE.yaml': 'loop: toe-detector-index-leakage-20261012\nmode: milestone_snapshot\ndelivery: milestone\nactive_branch: physics-loop/toe-compact-patch-scattering-20261011\nbase_revision: '+BASE+'\ntarget_claim_type: bounded_theorem\nactual_current_surface_status: conditional-support\nindependent_check: complete_separate_L1_L27_source_review\npr: 9486\npr_status: preparing_regular_extension\nprovisional_dependencies: unmerged_PR9485_index_and_supplied_microscopic_common_q_setting\nlive_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree\nstop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z\n',
 'GOAL.md':'# Exact contract\n\nQuantify finite-energy weight outside the fixed common-q selected scattering\nrange and relate it to actual positive detector zero atoms. Construct no model\nor universal no-go; state all implementation and preparation costs.\n',
 'ASSUMPTIONS_AND_IMPORTS.md':'# Actual dependencies\n\nFull qubit UHF algebra, faithful cyclic vacuum representation, actual fixed\nfinite-range H/current interactions, unique positive-gap vacuum, and the\nconstructed common-q selected range are supplied. PR9485 at b8402c17 supplies\nthe required index proof; its complete frozen original and review are preserved.\nIt is unmerged and is not silently available on main. SC/Fock/PC are in branch.\nThe projection dependency is optional for L27 only. No EX is assumed.\n',
 'APPROACH_REGISTRY.md':'# Derivation\n\nThe matched shift obstruction gives a nontrivial unitary. Faithfulness plus\ncyclicity supplies a local defect vector. Unitary operator order gives the\nsharp factor1/4; the local H domain and spectral tail yield finite-energy\nweight. Both terms of the exact operator identity are retained for preparer\nconversion. The full-block index estimate gives an optional quantitative\noperator defect. Actual positive detector range gives kernel inclusion, with\nchosen-family equality only under the separately checked projection theorem.\n',
 'ROUTE_PORTFOLIO.md':'# Evidence roles\n\nThe analytic L1-L27 proof is primary. A fresh checker reconstructed it and\nwrote separate exact operator-order controls before author evidence access.\nRoot proposed the mechanism and is coauthor. Reproductions and hashes establish\nexecution/provenance, not independence or microscopic realizability.\n',
 'OPPORTUNITY_QUEUE.md':'# Remaining work\n\nDerive actual microscopic current implementation from sufficient local-domain\nconditions; construct justified channels without a common finite denominator.\nFind an actual model and effective local preparation before numerical physics\nclaims. Do not seek generic ND for the obstructed fixed common-q selection.\n',
 'NO_GO_LEDGER.md':'# Scope stress tests\n\nFull N1-N8 alternative-route, dependency, hidden-premise, residual-match,\nresolution, primitive, steelman and history analyses are preserved in the\ncomplete source and separate assessment. Properness is the earlier N1\ncontrapositive; new content is quantitative. Faithfulness is not separation,\na local operator defect need not act on vacuum, positivity matters, and a\ncommon-q theorem cannot classify irrational or unbounded-denominator channels.\nNo universal lattice or TOE no-go is asserted.\n',
 'LITERATURE_BRIDGES.md':'# Checked source reuse\n\nThe exact reviewed partial-factor proof supplies its RWW/NSY bridge at the\npreviously checked scope. Creator/Fock/PC arguments and their exact source\nreviews are reused with matched hypotheses. No new primary theorem is imported;\nno full literature novelty, whole-paper recertification or model search is claimed.\n',
 'ARTIFACT_PLAN.md':'# Regular milestone\n\nExtend PR9486 with the complete note, primary, cache and evidence packet.\nExplicitly name provisional PR9485 dependency. Preserve every older science\nsource. No duplicate or draft PR, merge, main push, audit verdict or axiom edit.\n',
 'TRACE_GATE.md':'# Precise trace\n\ntrace_class: upstream_support\nreachability_to_target: partially_closes\nartifact_role: theorem\ntarget_claim_id: null\ntarget_blocker_text: Quantify the fixed selected-sector complement from the reviewed shift obstruction.\nsource_of_blocker_text: source_derivation\nnext_trace_action: Construct actual microscopic implementations and justified additional channels.\n',
 'CLAIM_STATUS_CERTIFICATE.md':'# Conditional theorem\n\nactual_current_surface_status: conditional-support\ntarget_claim_type: bounded_theorem\nstatus: provisional\nindependent_review_status: Complete separate L1-L27 source reconstruction; no required correction.\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\n\nNo applied audit verdict, Lean certificate or retained promotion.\n',
 'REVIEW_HISTORY.md':'# Exact independent review\n\nSource4d1e9b888c6e84881e8d356c42e8da521794c68191ebcebab1c145ced5189747;\nreportfbd6bbbfe6d725b531da2d3c53e650fbcbb07c8195d7af151043d5eab14df39f;\nreceipt0e96c15785d6e5f74d160a5753bdd33b47f91ac5f425de809e5749ecffaa9254.\nThe complete reconstruction and exact rational control froze before author\nevidence. L1-L26 and optionalL27 applicability are supported. Root read the\ncomplete proof, reconstruction, independent control, assessment and outputs.\n69author and107review bindings,28source pairs and2prefreeze files match.\nAuthor baseline and six intended failures reproduce byte-exact. Two signal9\nsearches are incomplete and support no absence claim. No theorem correction.\n',
 'HANDOFF.md':'# Frozen milestone\n\nExtend regular PR9486 from '+BASE+'.\nComplete source, controls, review and failures are preserved by exact mappings.\nThe index dependency is PR9485 at b8402c17d337f371c0c73696ef170727de9ab5bd.\nMicroscopic realization, effective preparer and correct all-channel selection\nremain unproved. Single live campaign checkpoint stays in the transport\nworktree. Fixed deadline2026-10-12 16:00:52UTC; do not extend it.\n',
 'PR_BACKLOG.md':'# Delivery\n\nPackage this accepted conditional result with exact reconstruction, original\nfinite controls, actual whole-primary mutation failures, canonical cache,\ncitation acknowledgment and scoped compatibility. Global audit pipeline and\nstrict audit lint remain independent landing gates. No applied verdict.\n'}
for n,t in texts.items():(P/n).write_text(t)
paths=[S/n for n in ['DETECTOR_INDEX_LEAKAGE_PROBE.md','DETECTOR_INDEX_LEAKAGE_REVIEW.md','Leakage_root_author_coverage.json','Leakage_root_review_coverage.json','root_verify_projection_and_leakage.py','update_campaign_checkpoint_0235.py']]
for folder in ['detector_index_leakage','detector_index_leakage_review']:
 paths += [p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
own=[]
for p in sorted(set(paths)):
 assert p.suffix.lower() not in ['.pdf','.png','.jpg']
 b=p.read_bytes(); rel=str(p.relative_to(S));dst=P/'evidence'/(rel+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0))
 own.append(dict(original=str(p),preserved=str(dst.relative_to(P)),bytes=len(b),sha256=sha(b)))
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Complete own/repository source and evidence, including unmerged cross-PR proof.',files=own,external_reference_sources=[]),indent=2)+'\n')
assert (W/inputs[-1]).is_file(),inputs[-1]
recon=(W/'.claude/science/physics-loops/toe-detector-scattering-projection-20261012/reconstruct.py').read_text()
recon=recon.replace('Complete projection note and entire finite primary','Complete leakage note and entire finite primary')
(P/'reconstruct.py').write_text(recon)
print(json.dumps(dict(outputs=[{k:r[k] for k in ['kind','publication_path','publication_sha256']} for r in rows],own_evidence=len(own),documents=len(texts))))
