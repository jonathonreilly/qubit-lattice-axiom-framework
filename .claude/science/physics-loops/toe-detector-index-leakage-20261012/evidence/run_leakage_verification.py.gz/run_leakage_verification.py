"""Execute the actual publication primary, targeted defects and scoped graph checks."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-detector-index-leakage-20261012'
BASE='5cbc581504721a323f5fa2064694a67141a3ee98'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']
editable=[W/r['publication_path'] for r in rows]+list(P.glob('*.md'))+[P/'reconstruct.py']
prefix=S/'leakage_initial_vocab_fix'
r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--fix','--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
prefix.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
report=json.loads(prefix.with_suffix('.json').read_text());assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'leakage_initial_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
primary=next(r for r in rows if r['kind']=='primary');path=primary['publication_path']
body=(W/path).read_text()
result,cache=runner_cache.execute_and_write_cache(path,60)
(S/'leakage_canonical_execution.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['status']=='ok' and result['exit_code']==0 and result['stderr']==''
old=(S/'detector_index_leakage/logs/baseline.stdout.txt').read_text()
assert result['stdout'].startswith(old) and len(result['stdout'][len(old):].splitlines())==2
M=S/'leakage_primary_mutations';M.mkdir(exist_ok=False)
runs=[]
for rec in json.loads((S/'detector_index_leakage/logs/execution_records.json').read_text()):
 if 'mutation' not in rec:continue
 before,after=rec['mutation']['old'],rec['mutation']['new']
 name=Path(rec['command'][-1]).stem
 assert body.count(before)==1
 changed=body.replace(before,after,1);p=M/(name+'.py');p.write_text(changed)
 started=time.monotonic();cmd=[sys.executable,str(p)]
 r=subprocess.run(cmd,capture_output=True,timeout=60)
 for ext,data in [('stdout',r.stdout),('stderr',r.stderr)]: (M/(name+'.'+ext)).write_bytes(data)
 e=dict(name=name,command=cmd,timeout_seconds=60,elapsed_seconds=time.monotonic()-started,exit_code=r.returncode,before=before,after=after,primary_sha256=sha(body.encode()),source_sha256=sha(changed.encode()),stdout_sha256=sha(r.stdout),stderr_sha256=sha(r.stderr),expected_failure=True)
 (M/(name+'.execution.json')).write_text(json.dumps(e,indent=2)+'\n');runs.append(e)
 (M/'manifest.json').write_text(json.dumps(dict(runs=runs),indent=2)+'\n')
 assert r.returncode==1 and b'AssertionError' in r.stderr
 assert r.stderr.decode().splitlines()[-1]==(S/'detector_index_leakage/logs'/f'{name}.stderr.txt').read_text().splitlines()[-1]
 assert result['stdout'].encode().startswith(r.stdout)
assert len(runs)==6
records={}
for name,cmd in [('build',[sys.executable,'docs/audit/scripts/run_citation_graph_build.py']),('manifest',[sys.executable,'docs/audit/scripts/write_citation_graph_manifest.py'])]:
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=180)
 (S/f'leakage_citation_{name}.stdout').write_bytes(r.stdout);(S/f'leakage_citation_{name}.stderr').write_bytes(r.stderr)
 records[name]=dict(command=cmd,timeout_seconds=180,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
 (S/'leakage_citation_execution.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0
cmd=[sys.executable,'docs/audit/scripts/check_changed_audit_evidence.py','--base',BASE,'--include-worktree','--json']
start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=120)
(S/'leakage_focused_audit_compat.json').write_bytes(r.stdout);(S/'leakage_focused_audit_compat.stderr').write_bytes(r.stderr)
e=dict(command=cmd,timeout_seconds=120,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
(S/'leakage_focused_audit_compat.execution.json').write_text(json.dumps(e,indent=2)+'\n');assert r.returncode==0
print(json.dumps(dict(canonical_seconds=result['elapsed_sec'],actual_primary_failures=len(runs),citation=records,compatibility=e)))
