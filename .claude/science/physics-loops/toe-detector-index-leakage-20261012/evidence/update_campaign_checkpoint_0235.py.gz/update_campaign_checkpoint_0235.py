"""Verify frozen leakage review and refresh the sole recovery checkpoint."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, yaml

S = Path(__file__).resolve().parent
T = S.parent
W = T/'worktree'
P = W/'.claude/science/physics-loops/toe-dynamics-bridge-20261009'
R = S/'detector_index_leakage_review'
sha = lambda b: hashlib.sha256(b).hexdigest()
js = lambda p: json.loads(p.read_text())
now = datetime.now(timezone.utc)
r = js(R/'receipt.json')
assert sha((R/'receipt.json').read_bytes()) == '0e96c15785d6e5f74d160a5753bdd33b47f91ac5f425de809e5749ecffaa9254'
for row in r['files']:
    b = Path(row['path']).read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
    assert len(b.splitlines()) == row['lines']
f = js(R/'precontrol_freeze.json')
for row in f['files']:
    b = (R/row['path']).read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
sources = js(R/'source_manifest.initial.json')['files'] + js(R/'source_manifest.additional.json')
for row in sources:
    ref = row['source']
    b = Path(ref).read_bytes() if ref.startswith('/') else subprocess.check_output(['git','show',ref],cwd=W)
    assert sha(b) == row['sha256']
    assert Path(row.get('path',row.get('copy'))).read_bytes() == b
author = S/'detector_index_leakage'
assert (R/'logs/author_reproduction.stdout.txt').read_bytes() == (author/'logs/baseline.stdout.txt').read_bytes()
assert (R/'logs/author_reproduction.stderr.txt').read_bytes() == b''
for rec in js(R/'logs/mutation_reproduction.json'):
    src = Path(rec['source'])
    assert sha(src.read_bytes()) == rec['source_sha256']
    assert rec['exit_code'] == 1 and rec['stdout_identical'] and rec['stderr_identical']
    for ext in ['stdout','stderr']:
        assert (R/f'logs/reproduced_{src.stem}.{ext}.txt').read_bytes() == (author/f'logs/{src.stem}.{ext}.txt').read_bytes()
coverage = dict(utc=now.isoformat(),review_accepted=True,
    target_sha256=r['target_sha256'],report_sha256=r['report_sha256'],
    receipt_sha256=sha((R/'receipt.json').read_bytes()),review_bindings=len(r['files']),
    original_source_pairs=len(sources),precontrol_bindings=len(f['files']),
    full_author_reproduction_exact=True,author_mutations_reproduced_exactly=6,
    read_scope=['Full 405-line author proof and helper previously read and bound in Leakage_root_author_coverage.json',
      'Full 138-line review, 254-line precontrol reconstruction, independent rational script and all five JSON records',
      'Full 146-line assessment including N1-N8, optional projection applicability and operational failures',
      'All receipt/source/precontrol identities checked; repeated author stderr/stdout verified byte-identical to previously fully read originals'],
    limits=['Root is coauthor, not independent reviewer','Two reviewer git-grep searches exited -9, no absence inference',
      'Finite fixtures do not prove infinite-lattice index, microscopic realization or physical readout',
      'No Lean, retained verdict, full audit pipeline or strict audit lint'])
(S/'Leakage_root_review_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')

old = '259b8d7b14dfa1f6ed3b5291b3564ea3057276b2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip() == old
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
stamp = now.strftime('%Y%m%dT%H%M%SZ')
names = ['STATE.yaml','HANDOFF.md','OPPORTUNITY_QUEUE.md']
for name in names:
    (P/'history'/f'{stamp}_{name}.gz').write_bytes(gzip.compress((P/name).read_bytes(),mtime=0))
sync = js(S/'repo_sync_0230.json')
assert sync['refs']['origin/main'] == 'a13caa4885f547c8d206265b031ba7649e539fd9'
state = yaml.safe_load((P/'STATE.yaml').read_text())
state.update(active_route='publish_reviewed_index_leakage; isolated_centre_filtering; microscopic_current_implementation',
    milestone='ten_regular_PRs_published; detector_projection_extension_published',
    scattering_published_science_revision='5cbc581504721a323f5fa2064694a67141a3ee98',
    latest_chiral_revision='bc81b65a4d3e2fa081b759832dfc2f1e976c8b26',
    lock_refresh_before_utc='2026-10-12T03:15:00Z',
    next_action='package_accepted_index_leakage; independently_check_frozen_centre_filter; complete_current_implementation_derivation')
state['independent_checks'] += '; detector projection P1-P33 and leakage L1-L27 complete at frozen scope'
(P/'STATE.yaml').write_text(yaml.safe_dump(state,sort_keys=False,width=110))
h=(P/'HANDOFF.md').read_text()
h=h.replace('Clean head: 296155eda2ca6a5ab6ae6307190362b9a84ea690','Clean head: 5cbc581504721a323f5fa2064694a67141a3ee98')
h=h.replace('633c25ab024c30a181dbdf2a893a2755595afea9 is losslessly archived at history/20261012T020419Z_*.gz.',f'{old} is losslessly archived at history/{stamp}_*.gz.')
h=h.replace('At02:00:09 UTC','At02:29:45 UTC')
h=h.replace('|9486|Scattering, Fock, exhaustion reduction and detector convergence|296155eda2ca6a5ab6ae6307190362b9a84ea690; maina13caa48|','|9486|Scattering, Fock, detector convergence and selected projection|5cbc581504721a323f5fa2064694a67141a3ee98; maina13caa48|')
start=h.index('## Active focused projection review')
end=h.index('## New positive route: isolated arbitrary centre characters')
h=h[:start]+'''## Detector projection published in PR9486

S/projection_pr_verified.json verifies exact title/body/head/base, regular/open,
MERGEABLE and attached. Head5cbc581504721a323f5fa2064694a67141a3ee98 is clean.
Packet: scattering_worktree/.claude/science/physics-loops/toe-detector-scattering-projection-20261012.
Source330lines91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4;
reviewd9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2;
receipt1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b.
All P1-P33 supported at conditional scope. Root read full arguments, separate
exact-rational controls, operational history and complete mutation failures.
Projection_root_author/review_coverage.json record56authorfile+1Git and
122reviewoutput+7source+7instruction+10prefreeze bindings. Root is coauthor.

For narrow J, diameterJ<gap/4, exact full-operator creator refiltering and finite
partitions give a countable admissible detector family with closureRanK_J=PJHsc.
The energy-only vacuum remainder uses diameterJ+2sumr<gap. Positive sum support
is exactly PJ Psc. Ordered t, family m, eta limits recover that projection,
with tail2^-m/eta. Finite response gives a one-sided selected-scattering weight
witness with square-root complement error. No finite-time zero-response converse,
ND, EX, actual microscopic realization, effective enumeration or family-uniform
rate is proved. Countable selection is existential. The m/eta iterated support
limits do agree; the genuine t/eta joint-limit counterexample is preserved.

Canonical primary0.048258066s/60s, exit0,stderr0. Every original stdout record
reproduced, plus scoped publication records. Eight actual whole-primary variants
give7intended assertion failures and1deliberate nondiscriminating pass. The original
rank-one witness sweep does not reject replacing sqrt(error) by error; that limit
is explicit. The added exact scalar Q=(1/16)E does reject the universal false
formula. Independent rational noncommuting-resolvent and rotating-limit controls
are separate from the analytic proof. No Lean certificate is claimed.

All203staged hashes,179final own evidence files,30external-primary bindings,
source maps, fresh cache inputs, links, vocab and whitespace checked. Graph
6874nodes15424edges adds1node/3SC-Fock-PC edges with all old nodes unchanged.
Focused audit compatibility finds no applied row/failure. Global combined audit
pipeline and strict lint not run. Old SC/Fock/E/PC sources unchanged. Publication
scripts prepare_projection_publication/run_projection_primary_mutants/
run_projection_citation_compat/finish_projection_delivery already ran; do not
rerun blindly. Exact note/runner hashes are in packet/PUBLICATION_EDITS.json.

## Index-to-complement result independently checked; publication next

DETECTOR_INDEX_LEAKAGE_PROBE.md,405lines,
4d1e9b888c6e84881e8d356c42e8da521794c68191ebcebab1c145ced5189747;
author receipt47bf0db5e653961b622953a77d26f345515e8f87fe583c6ce66c8951c0f6a498.
Reviewfbd6bbbfe6d725b531da2d3c53e650fbcbb07c8195d7af151043d5eab14df39f;
receipt0e96c15785d6e5f74d160a5753bdd33b47f91ac5f425de809e5749ecffaa9254.
L1-L26 and optionalL27 supported with no required correction. Independent proof
and exact rational matrix control froze before author control access. The all-vector
operator-order check uses a rotating7D fixture and every principal minor; it rejects
the stronger1/3coefficient and omitted spectral tail. Author baseline reproduced
byte-exact; all6actual mutants reproduced full intended failures. Root full reads
and69author,107review,28original-source,2prefreeze bindings are recorded in
Leakage_root_author/review_coverage.json. Search signal-9 failures preserved;
no absence/novelty conclusion. This is source review, not applied audit/retention.

For actual microscopic H/current implementations and a fixed common-q selected
scattering range, U=exp(iqP_b/beta)T_q fixes that range. Checked shift index excludes
AdU=id; faithful cyclic GNS then supplies local C with d_C=||(U-1)COmega||>0.
The bound is ||(1-Psc)1_[m,E](H)COmega||² >=[d_C²/4-||HCOmega||²/E²]_+,
with ||HCOmega||<=2J_H|suppC|||C||. E>2h_C/d_C gives positivity. Positive detector
range gives a lower bound on the common zero atom. Optional chosen-family
projection equality matches the separately reviewed projection theorem; arbitrary
families have inclusion only. Full two-term operator-to-state conversion and
finite-tube defect extension are proved. Cyclic preparer support/norm/energy are
uncontrolled. The core proper-subspace conclusion is N1's existing conditional
contrapositive, not a universal lattice no-go. New content is quantitative.

The frozen source's description of optional projection review as pending was
accurate when written; publication may label that operational history and add
the exact now-completed review record without changing mathematics. Publishing
in9486 requires explicit cross-PR9485 index dependency and frozen proof sources.
Do not silently treat that unmerged source as present on main. Full N1-N8 scope
assessment is preserved. Other channels, irrational characters, unbounded finite
denominators and failed microscopic identification remain real alternatives.

'''+h[end:]
h=h.replace('The new projection result is optional until its review is complete. A separate','Projection review is now complete, but this extension does not use it. A separate')
start=h.index('## Freshness, lock and next decisions')
h=h[:start]+'''## Microscopic current implementation derivation and recovery

S/ROOT_MICROSCOPIC_CURRENT_IMPLEMENTATION_LEAD.md is a root unverified sketch.
Fresh author agent microscopic_current_implementation continues only
MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md and microscopic_current_implementation/.
The prior worker had two stream disconnects, requests d8b30d99-0af8-4663-ade1-1950f8b68e30
and30f8456c-bfa0-4295-8850-c2939a9cb712. Root recovery inventory originally saw
source copies/checkpoint only; the fresh worker subsequently found a27197-byte
note timestamp02:21:13UTC. It preserves that recovered predecessor before finishing
controls and provenance. No proof is accepted yet. Both failures remain recorded.

Target: under explicit local-vector H/boost domain actions and supplied self-adjoint
integrated P=i[H,B], derive finite-range current density
p_b(x)=(i/2)sum_r r_b[h_x,h_(x+r)] and its implementation on the full GNS algebra.
Use connected-support nested-commutator analytic bounds, supplied self-adjoint
Taylor remainder and finite-volume norm convergence; prove invariance before
canonical GNS identification. Do not infer boost local action from a formal first
moment, equality on one vacuum column, or an unproved analytic-core theorem.
This could reduce an implementation premise; no model/Poincare integration or
physical axioms are constructed. Independent source review remains necessary.

## Freshness, lock and next decisions

S/repo_sync_0230.json records02:29:45UTC. Main/planning/instructions unchanged.
Candidate9476 remains100a6fc7bf476d011bb47e18045e60bb810b2b5d with the separate
field-dependent Ward plan. Chiral9477 advanced tobc81b65a4d3e2fa081b759832dfc2f1e976c8b26:
two143-line partner-rank notes and full changed HANDOFF/queue were read for overlap.
They treat specific thrice-cap/swapped-dot combinations by rank/minor pencils,
not current implementation or scattering. Their large runners are not re-certified
or imported. Avoid duplicating that active lane. Full changed-path inventory was
inspected. Local main e485 remains stale; fetched origin/maina13 is authority.

Lock refreshed02:29:15.577118UTC; expires03:29:15.577118UTC. Refresh by03:15UTC
from worktree using ownercodex-toe-native-20261011 and the same holder.
Package reviewed leakage, check the centre source when frozen, finish the current
implementation candidate, and then choose the next constructive route. A possible
next lead is time-averaged scattering for stable nonisolated mass shells; only
Dybalski hep-th/0412226v4 abstract/early pages have been inspected, no theorem
import or adaptation is yet established. Read original source before use.

Preserve failures and source limits. No deadline extension. All earlier full
proof summaries and operations are recoverable from archives and source packets.
'''
(P/'HANDOFF.md').write_text(h)
(P/'OPPORTUNITY_QUEUE.md').write_text('''# Current ranked opportunity queue

1. Publish the accepted index-to-selected-complement inequalities with explicit
   cross-PR index dependency, finite controls and limited physical interpretation.
2. Independently check exact almost-local filters for arbitrary isolated centre
   characters, including irrational phases; do not assume a common integer period.
3. Complete and independently check the finite-range momentum-current implementation
   proof under explicit local-vector domain assumptions. This targets a live premise.
4. Investigate stable nonisolated mass shells through time averaging and matched
   spectral regularity, if the primary proof and lattice estimates support it.
5. Actual microscopic realization and justified enlarged channel selection remain
   the decisive targets. Existing conditional completeness reductions do not build
   a model. Do not seek generic ND for the obstructed fixed common-q sector.
6. More exact boost coefficients/longer-time sharpness are secondary to these gaps.

Ten regular PRs9478–9487 are open, unmerged. Projection5cbc581 and S/L433f641
are published. Main/instructions unchanged02:29UTC;9476 owns the gravity Ward
search and9477 owns chiral partner-rank pencils. Avoid duplicate work.

Preserve failed routes and counterexamples. No applied audit verdict, main push,
science merge, axiom edit, other-chat message or extension beyond12October16:00:52UTC.
One live checkpoint remains here; individual packets are frozen milestones.
''')
record=dict(utc=now.isoformat(),previous_checkpoint=old,archive_stamp=stamp,
            files={n:sha((P/n).read_bytes()) for n in names},leakage_review=coverage)
(S/'checkpoint_0235_update.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
