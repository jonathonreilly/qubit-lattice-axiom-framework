# Proposed detector resolution of the constructed scattering sector

Root research proposal, 2026-10-12. This is not a theorem or independent
review. It depends provisionally on the new compact detector PC argument,
which has not yet been independently checked. No ND or full-GNS exhaustion
is supplied as a premise.

Sources (exact identities remain in their frozen packets):
- SC: COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md and its reviewed EX repair.
- F: COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md, with complete separate review;
  published in regular PR9486 at c3f84746b1991e0a15c6da79d049b89d9469f727.
- EX: SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md,
  c4af4f5e9823e2cd1cfb79a0f17498fb2ffe117cb24c90bc572b888e31ae08c2,
  separate review 8c9f7bb60724982ce7580a8b5688d8b61572ea008d92305f057d3f9b7a4e735d.
- PC: COMPACT_DETECTOR_CONVERGENCE_PROBE.md, currently being finalized;
  do not bind a changing version or treat its conclusion as verified.

Question: can the positive detector operators construct the projection onto
the already constructed scattering space, without assuming that this space
is all of the physical GNS space?

If PC yields, for each admissible fixed tuple alpha on a bounded energy
window J,

    Q_alpha = P_J S_alpha h_alpha(v(D)) S_alpha^* P_J,

where S_alpha is the limit of the bounded compact-creator map and h_alpha
is the product of the nonnegative velocity cutoffs, then its range is in
P_J H_sc. The missing converse is a genuinely chosen family: arbitrary
families of detectors need not see all of H_sc.

Candidate construction and checks:

1. Fix a countable narrow-window partition of [gamma,infinity), with window
   width less than gamma/4. For each J, approximate every P_J finite outgoing
   scattering packet by packets with each creator's temporal transfer and
   momentum support narrowly localized. Keep positive energy, compact direct
   vacuum graphs and separated velocity supports. The temporal intervals I_i
   must satisfy (J-sum I_i) intersect spec H subset {0}; check this for all
   approximating terms that survive P_J. Do not assume that energy projection
   factors over the one-particle tensor factors. A partition of packet energy
   supports followed by P_J may suffice. Boundary energy values and Borel J
   need an honest strong-approximation argument.

2. Given an internally separated product packet, shrink the operator momentum
   supports and choose h_i>=0 identically one on their velocity images, with
   disjoint convex support hulls. Determine whether these choices can always
   be made after a finite or countable partition; convexity is stronger than
   pairwise disjoint velocity supports. Then find f in the auxiliary tensor
   space with h_alpha(v(D)) f = f and with P_J S_alpha f equal to, or dense in,
   the corresponding outgoing packet subspace.

3. Separability of the local-qubit GNS Hilbert space could select a countable
   list of such tuples and test vectors whose P_J S_alpha f span is dense in
   P_J H_sc. No frame lower bound or uniformity over shrinking patches is
   needed if all detector bounds B_alpha are retained in positive weights.
   Prove this countable choice from actual dense local/packet data. If a
   component family itself is not supplied countably, use separability to
   extract the needed generators without silently enlarging the channels.

4. For that specifically complete detector family, let

    K_J = sum_alpha 2^(-alpha)/(1+B_alpha) Q_alpha.

   Positivity gives ker K_J = intersection ker Q_alpha. If a vector is killed
   by all Q_alpha, then h_alpha(v)^(1/2) S_alpha^* P_J psi=0 and hence it is
   orthogonal to every P_J S_alpha f from step2. Conversely H_sc-perp is killed
   since every range lies in H_sc. Thus the hoped-for exact conclusion is

    closure Ran K_J = P_J H_sc,
    ker(K_J restricted to P_J H) = P_J H_sc-perp.

5. Spectral calculus would then give an explicit bounded reconstruction

    strong-lim_(eta downarrow 0) K_J(K_J+eta)^(-1) P_J = P_J P_sc.

   Finite detector sums and finite times are accessible through the already
   proved estimates: at fixed eta, the truncation error is <=2^(-m)/eta;
   first take t->infinity, then m->infinity, then eta->0. Record any changed
   expression needed to keep the finite-time sum positive. Do not assert an
   uncontrolled joint limit or quantitative eta rate without a spectral gap.

This would make the selected scattering projection a limit of explicit
almost-local detector constructions and turn ND into an exact local cyclic
vector test for that chosen complete family. It would not prove that the
complement vanishes. The central unresolved physics would remain detection
of every finite-energy state, including every necessary channel. A generic
spectator-space example is not an N1/local-UHF counterexample.

Potential failure points to preserve: no admissible transfer partition for
fixed J; hidden use of the completeness being sought; non-factorizing energy
projection; inability to choose convexly separated refinements; unsupported
countability or detector lower-frame bound; order-of-limits interchange.
