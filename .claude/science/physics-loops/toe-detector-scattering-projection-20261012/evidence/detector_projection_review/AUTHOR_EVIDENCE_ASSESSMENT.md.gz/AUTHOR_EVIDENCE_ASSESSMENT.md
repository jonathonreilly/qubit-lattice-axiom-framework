# Author evidence assessment

The pre-author-evidence reconstruction and separate rational control were
frozen at 2026-10-12T01:55:53.921827+00:00. The freeze receipt has SHA-256
`76c3d7adfc4cfa8d5c77f427aa35f8aaf1615b08e537103b9f6677eb985f895a`.
The new author's receipt, helper and logs were first opened afterward.

The complete author control source, timeout wrapper, freeze helper, both
source-ledger helper revisions, author self-check, operational record and
checkpoint were read. All ordinary execution metadata/stdout/stderr were read,
including the full DG search output; that search is retrieval evidence only.
The full structured source ledger was parsed, and its input array equals the
receipt's input array. The receipt's 34 input records and 23 output records
were checked against their full bytes, including the nonpath Git source. The
63 predecessor records were also checked against both their original receipt
and the author's saved verification array. All hashes and byte lengths match.
No unlisted file remains in the author directory after the declared receipt
self-reference / post-freeze wrapper exclusions. Those excluded wrapper logs
were also read and copied into this review's evidence. The reviewer did not
run the author bookkeeping helpers, which write files and assert the former
checkout HEAD; this was not necessary to verify their outputs.

The exact author control command and cwd from the recorded execution were
reproduced under a 60-second timeout. Exit status was 0, elapsed time about
0.038 seconds, and all seven stdout records and empty stderr match byte for
byte. This is reproduction of author code, not independent implementation.
The first five control groups use exact integer/rational arithmetic. The
last uses elementary floating scalar formulas for its stated rank-one toy
matrix family, with tolerance 1e-12. Its 588 cases are not general positive
operator coverage, and its fixed finite count has no force for P31's analytic
remainder estimate or any microscopic hypothesis.

The finite targets are real algebraic checks, rather than fitted physical
comparisons. The energy mask is rank two and all independent binary
factorizations are rejected. Interval arithmetic is exact and covers
zero-width, endpoint and interior choices. Filtering acts on all toy matrix
transitions and changes nonvacuum entries while preserving the vacuum column.
Finite overlapping partitions are reassembled before a whole-product energy
mask. The positive-sum example has two nonorthogonal, noncommuting generators,
an explicit null direction and a positive principal determinant. The
noncommuting resolvent identity is checked without moving its middle factor.
The final witness uses constants justified for that particular toy family.
There is no fitted prefactor, rounded empirical target, hidden physical
baseline, or numerical output being promoted to an analytic theorem.

Copied-code perturbations were run only under this review directory. A
factorable replacement energy mask, wrong temporal transfer, omitted partition
piece, signed detector weight, invalid resolvent order, and complete omission
of the witness error each failed at the relevant assertion. All intermediate
stdout and complete assertion tracebacks were retained and read. These are
post-author-evidence probes; they are not claimed as blind controls.

A limit of the witness sweep is deliberately preserved. Replacing its
`sqrt(2*eps)` error by `2*eps` still passes all toy cases. In that particular
family `Q=|(1,0,eps)><(1,0,eps)|`, the norm of `sqrt(Q)E` is eps, whereas the
supplied bound on `||QE||` is 2 eps. The linear replacement is therefore still
a valid bound for those toy cases, although it is invalid as a universal
deduction from P31. The author's separate scalar assertion `1/4>1/16` is the
actual discriminator for that universal error. To make the operator meaning
explicit, take `Q=(1/16)E`, `psi` a unit vector in Ran E, and zero selected
component: the correct square-root witness is zero, while using the linear
error gives the false lower bound 3/4. The post-author script verifies this
exactly. P32 and P33 themselves contain the correct square root and were
proved independently before this evidence was opened. No source repair is
required; the sweep must not be described as a stand-alone general check of
the square-root step.

The self-check and operational record disclose an initially unfrozen wrong
claim that interchanging m and eta necessarily fails. The author corrected it:
after time limits, positive partial sums have increasing support projections.
The final note instead gives a valid uncontrolled joint time/eta
counterexample and explicitly avoids ruling out every other iterated order.
The other preserved failures are operational: a stream disconnect without
available platform details, missing source-directory lookup, truncated tool
displays, JavaScript parse errors and a rejected duplicate-path patch. The
records distinguish them from mathematical failures. No fabricated platform
error details or unrecorded successful scientific test were found.

The new control packet does not prove almost locality, PC, spectral density,
the separable range selection, physical realization, ND or EX. Those are
analytic or physical questions with the explicit source boundaries in the
reconstruction and report. The receipt is bookkeeping evidence, not a proof
certificate or audit verdict.
