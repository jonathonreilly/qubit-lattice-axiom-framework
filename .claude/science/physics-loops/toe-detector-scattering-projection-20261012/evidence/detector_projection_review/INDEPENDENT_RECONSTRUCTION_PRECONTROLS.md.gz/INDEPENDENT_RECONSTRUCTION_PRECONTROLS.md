# Independent reconstruction before opening the new author evidence

This document records the reviewer's reconstruction of the full 330-line
`DETECTOR_SCATTERING_PROJECTION_PROBE.md` at SHA-256
`91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4`.
The new author's helper, receipt, logs and control source have not been opened
when this document and the adjacent exact-rational control are frozen. The
source statement and its control descriptions were visible. The full frozen
creator, Fock and PC source notes, the EX repair, and the Fock/PC review reports
were read. Those source review labels are not mathematical premises.

The parent coordinator proposed mechanisms and is a coauthor. This reviewer
does not claim blind discovery of the route, a different model family, a
formal proof check, or independence of shared source assumptions. The present
independence consists of reconstructing the analytic implication, checking its
hypotheses, and writing a separate finite control before reading author code.
The inherited model and reasoning effort are unchanged. No delegation occurs.

## Target and exact premise graph

The target is an existential resolution of the projection onto one specified
outgoing scattering space, after a sufficiently narrow total-energy
compression. It is not a theorem that detectors exhaust the full GNS space.
Let H be positive, with unique vacuum Omega and spectral gap gamma>0. The
quasilocal algebra has finite-dimensional sites on a countable lattice and
Omega is cyclic. The selected one-particle components are exactly the finite
mass/centre set in F2. Their Fock isometry gives a closed outgoing range T,
containing Omega, reducing H, and generated densely by finite products of
internally separated compact packets. The creator source supplies finite-range
microscopic dynamics, the joint mass/centre filters and direct creator class.
These are conditional scientific inputs, not deductions from a physical axiom.

The bounded maps furnished by PC for one admissible arrangement obey
S = s-lim J_t exp(-it omega), S=S P_Lambda, exp(iaH)S=S exp(ia omega),
and Ran S subset T. For compact positive temporal intervals I_i and separated
convex detector regions containing full operator carrier velocities, the
energy remainder condition gives the strong positive coincidence limit
P_J J_t h_t J_t* P_J -> P_J S h(v) S* P_J. The stronger PC C24a is uniform
over bounded-energy unit balls, with fixed-arrangement constants; it is needed
only for the finite-time lower witness. No strong unlocalized adjoint limit
is a premise.

Every downstream conclusion is conditional on these exact inputs and their
supplied physical setting. The review reads the complete upstream arguments
and checks their use here. It is not a new audit of unrelated N1/B1/M1 results,
an all-channel claim, a physical realization, or formal retention.

## Upstream mechanisms checked at their actual scope

The full creator source §§2–8 uses commuting, microscopically implemented
finite-range flows and a joint smooth compact multiplier in (H,K). The
parameter integral is split at a radius proportional to the localization
radius. Lieb–Robinson estimates control the bounded parameter region; the
Schwartz tail is controlled by the automorphism norm, never by an exponential
LR prefactor. Kernel differentiation supplies norm derivatives. Finite centre
averaging acts as a projection only on the selected finite-order mass
components. The filtered vacuum vector has exactly one selected graph, even
when the full geometric spectrum overlaps it. Geometric packet clocks cancel
the physical vacuum clock. Both packet-derivative terms enter the Cook
commutators; n-2 remaining factors change the power to nd-N. Choosing N=nd+2
gives integrability for each finite n. Permutation invariance follows by the
same separated-packet commutators. The EX repair adds the unique vacuum and
gap explicitly; no density conclusion follows from creator existence.

The full Fock source adds that unique gapped vacuum. Its common-kernel
induction concerns every mixed word of translated annihilators, not powers of
one operator. Expanding Q^2 and using commutator row/column sums bounds the
compressed annihilation square function by floor(R/epsilon) S_B. The creator
bound requires output energy R+L. These bounds give uniform finite mixed-word
vacuum norms. The massive Hessian is positive on each compact lift, and the
regular stationary-phase l1/sup powers combine with exponential clustering to
give the mixed-creator contraction remainder O(t^(-d/2)). The full double
commutator recursion uses separation only within each family, with finite
energy row bounds controlling that remainder. The permanent formula therefore
identifies all admissible realizations of a one-particle tensor.

For its density step, almost-local vacuum two-point functions are rapid
commutator coefficients because B*Omega=0. Their Fourier measures have smooth
densities. Local creator density extends absolute continuity to H1. The
massive velocity map is invertible on each mass component, so pairwise
equal-velocity sets are product-measure null, including different masses.
Separated compact product boxes and symmetrization are dense in each Fock
sector. This proves density in the asymptotic Fock space, then in its isometric
range T, not in the full interacting Hilbert space. Fixed translations give
covariance and show that T reduces H. F5 is therefore the correct mechanism
for replacing creators after a new filter. No cross-family separation between
the two realizations is needed in that Gram argument.

The complete PC proof was read. Its C3 common-word identity and C4 bound are
the same finite-energy mechanism. Repeated lowering bounds the annihilation
map; the total output energy ceiling and duality bound J_t on all ell2. Full
operator filtering in each coordinate gives J_t=J_t P_Lambda. Strong Cook
convergence first holds on the linear span of smooth tensors, then extends
by the uniform J_t bound. A single class of rank-one tensors is not itself
dense; the linear span is used. The full scalar source R_t = F'_t+i omega F_t
inherits the closed carrier subspace from F_t and its strong derivative. Its
pointwise off-collision estimate has all commutators and spectator factors;
the global ell2 estimate instead uses the differentiated finite-energy bound.

For s>=t>=1 the PC propagator kernel has phase
(x-y)·p+(s-t)omega(p). The stationary source point is y=x+(s-t)v(p).
Convex containment places [x+(s-t)v]/s in the allowed product of separated
convex velocity regions. The forbidden y/s support is a fixed positive
distance from that product. Thus the phase gradient is >=delta s; combined
with the large |x-y| estimate it is >=c(s+|x-y|). Dividing by that latter
scale bounds all normalized derivatives uniformly, including s=t. Repeated
torus integration by parts yields (s+|x-y|)^(-N). Both Schur sums are bounded
by the same dyadic lattice-shell series O(s^(nd-N)). This establishes the
operator kernel estimate at all scales, without a finite numerical tail.

Strong S_T gives weak S_T* only. At fixed t the spatial cutoff is finite rank,
so it converts that weak limit to norm convergence. Integrating the scalar
equation from t to T gives u_t=K_t w_T minus the source integral. The source
is split after q(D), retaining q(D)chi(X/s) and q(D)(1-chi(X/s)) in that order.
The localized source and kernel estimates make the integral absolutely
Bochner integrable uniformly for s>=t. T first tends to infinity with t fixed,
giving C24a and its uniform t^(-N) remainder on finite-energy vectors. A
Fourier-shift proof gives the remaining free strong limit. It does not claim
free operator-norm convergence. The vacuum remainder then produces positive
coincidence detectors and the limit by uniformly bounded S_t times convergent
u_t. The different-label reordering errors have arbitrary spatial decay,
overcoming the O(t^(nd)) number of tuples. No full-shell isolation is imported.

## Reconstruction of P1–P18: coverage by admissible ranges

Fix a bounded nonempty Borel J subset [gamma,infinity) with diameter d<gamma/4.
Its closed interval hull has the same diameter, whether endpoints belong to J
or not. P_J commutes with P_T since T reduces H. Hence P_J T is closed. The
empty-window case is zero throughout and needs no detectors.

Start with any generating separated product. Its compact packet supports K_i
have pairwise disjoint compact velocity images. For n>=2, their minimum
distance delta is strictly positive. Cover each K_i by finitely many open
sets inside the original chart on which (a) velocity stays within delta/10
of the centre velocity and (b) energy varies by less than r_i/3. Choose
positive r_i with sum r_i<=gamma/8 and r_i less than one quarter of the
minimum original chart energy on K_i. The latter minimum is positive. A
finite smooth partition equal to one near K_i splits the packet amplitude
exactly; it introduces neither approximation nor an independent factorwise
energy projection. Pieces with zero amplitude may be omitted.

For each piece, let e_i be the dispersion at its cover centre and put
I_i=[e_i-r_i,e_i+r_i]. Choose a smooth time multiplier zeta equal to one near
the piece's graph energies, supported inside I_i, and a geometric momentum
multiplier phi equal to one near the piece support, with compact support
Lambda_i inside its cover neighborhood. Apply both multipliers to the
operator, not just to its vacuum vector. The temporal inverse transform uses
exp(-iEs), while the spatial coefficients use exp(+ipz); with alpha_s=Ad
exp(isH) and T_z=exp(-izQ), the vacuum action is phi(Q)zeta(H)B^0 Omega.
On the packet support the two multipliers equal one on the exact graph, so
the resulting one-particle vector is exactly unchanged.

Fourier convolution also restricts the full operator transfers, by applying
a second filter and multiplying its transfer multiplier. This controls
matrix elements between arbitrary energy/momentum states, rather than only
transitions from Omega. Temporal transfer is in the strictly positive I_i;
geometric transfer is in Lambda_i. Commuting symmetries preserve the mass,
centre and lift of the vacuum vector. The old direct creator may already be
almost local: approximate it on radius R/4, evolve for |s|<=cR, and use LR to
localize in radius R. The polynomial support prefactor times exp(-c'R) is
rapid. Integrate the remaining time tail against the norm bound. Norm time
derivatives replace the kernel by a derivative; the same proof applies.
Spatial Schwartz smearing preserves all these properties after a radius/tail
split. Thus the new operators remain in the class needed by F5 and PC.

The original separated product is a finite multilinear sum of the split
products. F5 compares each realization made with the old and new creators:
the one-particle tensor is unchanged, so their difference has zero squared
norm. This establishes exact P12. The supports from different factors remain
separated. Centres chosen from the original K_i remain at distance >=delta.
Choose h_i=1 near v_i(Lambda_i), with support inside the ball of radius 2r,
r=delta/10. Its convex hull and a small enlargement of the carrier velocities
fit in the ball of radius 3r. Distinct such balls are disjoint because 6r<delta.
The auxiliary smooth carrier cutoff q_i can also remain in the chosen chart.
This cures the genuine problem that disjoint original velocity sets can have
overlapping convex hulls. For n=1 there is no separation constraint and any
positive local ball size works.

The auxiliary product f has Fourier amplitude equal to the product of split
amplitudes. By PC's definition of S and permutation invariance, S f is exactly
the split scattering product. All auxiliary carrier velocities have detector
weight one. Time covariance of S implies P_J S=S 1_J(omega(D)) for arbitrary
Borel J. One proof is first to intertwine resolvents of the selfadjoint
generators, then their spectral measures by uniqueness. Here omega is the
sum of all one-particle dispersions. No projection onto J is factored through
the individual tensor factors.

The f just constructed has omega support in the compact Minkowski sum of
E_i=Sigma_i(K_i,piece). If that sum has empty intersection with J, its projected
vector is zero. Otherwise choose any e_* in the intersection, with e_* a sum
of e_i' in E_i. For x in the closed hull of J and y_i in I_i,
abs(x-sum y_i)<=d+sum abs(e_i'-y_i)<=d+2 sum r_i<gamma/2.
Thus the entire closed interval difference is inside (-gamma/2,gamma/2),
and its intersection with spec H is contained in {0}. This is a strict
margin even if sum r_i=gamma/8. It remains true under sufficiently small
enlargement of a singleton hull. Discarding by the stated criterion cannot
discard any nonzero projected vector, although it may retain zero vectors.
There is no assumption that the sum of transfer intervals is inside J.

P_J applied to the dense generating span of T is dense in P_J T. The exact
finite decompositions above express every such projected generator as a sum
of ranges P_J S_alpha of admissible arrangements with the vacuum remainder.
Conversely every such range lies in P_J T. This proves P17, including all
Borel endpoints and singletons without boundary-null assumptions. Density
has been used only within the already chosen closed scattering space.

For those arrangements S=S P_Lambda and h(v)=1 on Lambda. Hence
Q=P_J S h(v) S* P_J=P_J S S* P_J=A A*, A=P_J S. The equality is a carrier
multiplier identity, not a claim that momentum filters commute with h(X/t).
For every bounded A, ker A A*=ker A*, and closure Ran A A*=closure Ran A;
this follows from the orthogonal complements of those kernels. Individual
detectors need not be projections and no lower frame bound follows.

## P19–P25: positivity, countable selection, support

Each ordered product D=A_1(t,x_1)...A_n(t,x_n) lowers temporal energy by
sum I_i. The strict remainder condition puts D P_J in the unique vacuum
space. Therefore its vacuum amplitude square equals its full D*D form after
compression. The finite spatial sum with nonnegative weights is exactly
P_J J_t h_t J_t* P_J, a bounded positive operator. This formula is valid at
finite time and contains no P_T. The ordered product of individual positive
detectors need not be positive; the source correctly uses the coincidence
expression instead. The PC annihilation/duality bound gives ||J_t||<=M_L,
so with h<=1, Q(t)<=B P_J for B=M_L^2. All constants may depend on this
particular arrangement. The formula with floors is valid also at exact
energy edges: choose lowering word length floor(R/epsilon)+1, giving strict
r epsilon>R. It requires a common kernel of all such words.

The countable local finite matrix algebra has a countable norm-dense set of
rational matrix combinations; cyclicity makes H separable. For each element
u_k of a countable dense set in P_J T and each precision 2^(-l), choose one
finite range combination approximating it. The union of arrangements used by
these countably many choices is countable and still has dense range span.
This uses only existence, not an effective enumeration or rational parameter
approximation of all possible creators. If P_J T=0 the family can be empty;
finite families and zero terms also present no difficulty.

Label this selected family by a subset of positive integers. Set
w_a=2^(-a)/(1+B_a). Because 0<=w_a Q_a(t)<=2^(-a)P_J, the infinite limiting
series is norm convergent and positive, bounded by P_J; its m-tail is <=2^-m.
At fixed m the strong detector limits give K_m(t)->K_m. The same tail estimate
would define an infinite finite-time series, but it is not required.

For every psi, <psi,K psi>=sum w_a ||A_a*psi||^2 by norm convergence.
Strictly positive weights make this vanish exactly on the common kernel of
the A_a*, which is the orthogonal complement of their dense range span P_J T.
For a positive bounded operator zero quadratic form is equivalent to being
in its kernel. Selfadjointness then gives closure Ran K=(ker K)^perp=P_J T,
and spectral support 1_(0,infinity)(K)=P_J P_T. This proof does not promote
an arbitrary detector family to a complete one. The result is an equality
for the existentially selected family. Since S intertwines time evolutions,
S S* and the compressed sums commute with H. No positive spectral minimum
on P_J T is implied.

## P26–P30: ordered limits and energy assembly

Write F_eta(A)=1-eta(A+eta)^(-1) for bounded positive A. The resolvent
identity gives exactly
F_eta(A)-F_eta(B)=eta(A+eta)^(-1)(A-B)(B+eta)^(-1).
It is valid without A and B commuting. Its norm is <=||A-B||/eta. If A_t->A
strongly and the operators are positive, apply A_t-A to the fixed vector
(A+eta)^(-1)psi; the other resolvent is bounded by 1/eta. This proves strong
continuity for fixed eta. The detector-time limit must be taken with m and
eta fixed. Then the m-limit is a norm limit with error <=2^-m/eta.

Finally lambda/(lambda+eta) converges pointwise to 1_(0,infinity)(lambda)
and is bounded by one. The spectral theorem gives the last strong eta->0
limit. At lambda=0 it remains zero. These facts prove the order t, then m,
then eta displayed in P28, including an empty target. There is no uniform
unit-ball convergence or effective diagonal rate. The supplied diagonal
example proves such uniformity false in general. A finite-time tiny response
can be magnified by a still tinier eta, so no uncontrolled joint limit follows.
After the time limit, other iterated orders may also work by increasing
positive supports; the source does not falsely rule them all out.

The half-open energy windows J_j of width gamma/8 are disjoint and exhaust
[gamma,infinity). Their spectral projections are orthogonal. Since T reduces
H and contains Omega, the sum of P_Jj P_T tends strongly to P_T-P_0. For each
finite collection one may substitute the separately proved ordered limits;
only afterward is the energy cutoff removed. There is no assertion of a
uniform arrangement choice or rate over infinitely many windows.

The complementary scalar function eta/(lambda+eta) tends to 1_{0}(lambda).
Multiplication by P_J removes the outside-window kernel, giving
P_J(1-P_T). Thus vanishing on P_J A_r Omega for a countable cyclic local set
is equivalent by density and boundedness to P_J<=P_T. The identity is proved;
its vanishing is not. This is exactly the unresolved no-common-kernel /
energy-capture issue. The selected particle content may itself be incomplete.

## P31–P33: finite-time lower witness

E=P_J(1-P_T) is an orthogonal projection reducing H and has a finite energy
ceiling R. Since Ran S subset T, S*E=0. C24a applied to E psi gives
||u_t(E psi)||<=c_(N,R)t^-N||E psi|| uniformly over psi. The exact identity
Q(t)E=P_J S_t u_t E and ||S_t||<=M_L imply ||Q(t)E||<=C_N t^-N. It is the
stronger remainder estimate that yields this operator-norm conclusion;
strong convergence by itself would not suffice.

Positivity gives ||Q(t)^(1/2)E||^2=||E Q(t)E||<=||Q(t)E||. For psi in the
energy window, apply Q(t)^(1/2) to psi=P_T psi+E psi and take the triangle
inequality. Since ||Q(t)^(1/2)||<=sqrt(B),
sqrt(<psi,Q(t)psi>)<=sqrt(B)||P_T psi||+sqrt(C_N)t^(-N/2)||E psi||.
Replace ||E psi|| by ||psi||, subtract the error and truncate at zero. Division
by sqrt(B) gives P33 when B>0. If B=0 the detector is zero and the division is
not made. Existence of the constants does not give numerical values, and a
zero response cannot prove absence of a scattering component. The bound is
a conditional witness once its constants are independently controlled.

## Discriminators and initial conclusion

The six source shortcuts are failures at their stated scope: the crossed
total-energy mask is not rank one; packet vacuum support does not constrain
all operator transfers; disjoint sets need not have disjoint convex hulls;
arbitrary detector families can miss selected directions; positive support
does not imply a spectral gap; and finite-time/resolvent limits cannot be
coupled arbitrarily. None is a microscopic countermodel or universal no-go.

The separate exact-rational control uses a four-dimensional degenerate
energy block, adjacent nonorthogonal detector vectors, and an independently
identified alternating dark direction. Row reduction checks the common
kernel; matrix inversion checks the noncommuting resolvent order. A rotating
rational positive matrix family makes the uncontrolled joint-limit failure
noncommutative, unlike the source's diagonal example. The source's finite
control descriptions were visible, but its new code and outputs were not.
These computations can challenge finite algebra only. The analytic proof
above carries the infinite-dimensional and all-scale conclusions.

No material mathematical defect has been found in P1–P33 in this reconstruction.
This is provisional until source identity refresh and author-evidence inspection
are complete. No source correction is proposed at this stage. The comparator
DG 1308.5187v1 has not yet been opened in this review and supplies no step of
the reconstruction; its comparison claims and exact reading limits will be
checked separately after this freeze.
