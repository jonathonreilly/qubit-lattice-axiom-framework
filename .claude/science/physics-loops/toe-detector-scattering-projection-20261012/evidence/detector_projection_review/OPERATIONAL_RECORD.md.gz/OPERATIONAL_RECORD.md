# Review operation and recovery record

Scope: one independent reconstruction and source review of frozen P1–P33.
Only the assigned report and `detector_projection_review/` are writable.
No new model/effort setting, subagent, Git mutation, publication, audit verdict,
physical axiom or editable prompt action was taken by this reviewer.

The first read used the installed physics-claim-reviewer entry point, then
the source at the explicitly pinned science revision. The exact pinned
science workflow, freshness guidance, reviewer skill, proof governance and
review-loop depth guidance were read and copied. The planning AGENTS source
was read at its supplied revision. The broad landing/backlog operations are
not invoked by this external frozen-source review. No fetch was performed.

An initial guessed filename included `SCATTERING_COVARIANCE_EX_PUBLICATION`;
it was absent. The target names the actual
`COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md`, which was recovered and
read completely. One large batched display was truncated. Affected target
and instruction content was reread in bounded calls. The full target was
covered, and its second half was refreshed after the reconstruction freeze.
No truncated display alone is counted as a completed read.

`command -v pdftotext` returned exit 1 with no output. The bundled Python
runtime was located through the workspace-dependencies tool. Its pypdf
reader successfully extracted all pages of the unchanged frozen primary PDF.
Complete read coverage is recorded separately in PRIMARY_COMPARISON.md.

Before the new author helper, receipt and logs were opened, the complete
analytic reconstruction, separate exact-rational control and source snapshot
were frozen at 2026-10-12T01:55:53.921827+00:00. The independent control ran
under a 60-second timeout, exit 0, with four complete records and empty stderr.
The source's own control descriptions and the supplied premise review reports
were visible before the freeze. No stronger claim of blind independence is made.

The author original control was run once under its recorded command and cwd,
with a 60-second timeout. It reproduced stdout/stderr exactly. Author
bookkeeping scripts were inspected, not executed. Post-author copied-code
mutations produced six expected assertion failures and one deliberate passing
case exposing a limited test family. All full outputs and exact commands are
retained, and the limitation is explained in AUTHOR_EVIDENCE_ASSESSMENT.md.
No mathematical failure or unexpected result is suppressed.

The source checkout initially resolved to
`c3f84746b1991e0a15c6da79d049b89d9469f727`. During this review root reported
publishing the previously reviewed E/PC extension and moving HEAD to
`296155eda2ca6a5ab6ae6307190362b9a84ea690`. This was a concurrent root action,
not an edit by this reviewer. The verdict remains bound to the external
projection note and explicit predecessor hashes. The original external files
and author receipt bindings were reverified after the root change. The new
publication files and metadata changes are outside this review's coverage.

No user/platform instruction file was modified. Fixed deadline remains
2026-10-12 16:00:52 UTC. No operational time limit was treated as proof that a
scientific claim is true or false.
