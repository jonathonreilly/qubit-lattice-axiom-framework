# Primary comparator and reading limits

The official [DG v1 abstract](https://arxiv.org/abs/1308.5187v1) and
[versioned PDF](https://arxiv.org/pdf/1308.5187v1) were opened. The frozen local
PDF SHA-256 is
`64ab1ee60602583c8491fb012f064102e9cda45dcd319288184d1f42349f2793`.
Fresh pypdf extraction was read for complete pages 4–9 and 20–22.

DG Theorem 2.9 identifies a detector-range span with a scattering sector.
Its framework is a Haag–Kastler net with continuous spacetime translations,
unique cyclic vacuum, and a global isolated mass-shell spectrum. Detector
admissibility uses joint energy–momentum transfers and open bounded windows;
theorem-specific symbol conditions also apply. These hypotheses are not
identified with the lattice setting here. Section 7 uses one-particle detector
spanning, Lemma 7.5, whose proof is delegated to another paper. Neither that
lemma nor its external proof supplies a premise of P1–P33. The comparison in
the frozen note is accurate at this restricted level. It does not establish
novelty, physical realization or full completeness.

All 29 pages were extracted for durable recovery; extraction is not reading.
Pages 1–3, 10–19 and 23–29 were not read completely. Search-hit context from
other pages was seen. No full independent certification of DG or its cited
external proofs is claimed. The other primary-paper audits in the upstream
reviews are reused at their stated scope, not claimed as new full reads here.
