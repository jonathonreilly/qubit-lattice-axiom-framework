"""Post-author-evidence discrimination probes; these are not blind controls.

Run altered COPIES only. Preserve all stdout/stderr, including expected
failures and a known nondiscrimination in the witness sweep.
"""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
source_path = root.parent / 'detector_scattering_projection/check_projection_algebra.py'
source = source_path.read_text()
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == '6152016d6bf85e8691f69eb15bf082239d1ecb50c742257265079be4887a972f'
mutations = [
    ('factorable_energy_mask', 'mask = [[int(x+y == 3)', 'mask = [[int(x+y == 2)', True),
    ('wrong_temporal_transfer', 'x if h[i]-h[j] == 1 else F(0)', 'x if h[i]-h[j] != 1 else F(0)', True),
    ('omit_partition_piece', 'for a in vectors for c in vectors)', 'for a in vectors for c in vectors[:1])', True),
    ('signed_detector_weight', 'scale(F(1,8), q2)', 'scale(F(-1,8), q2)', True),
    ('wrong_resolvent_order', 'scale(eta, mul(mul(ra, delta), rb))', 'scale(eta, mul(mul(ra, rb), delta))', True),
    ('witness_omits_error', 'response_root-math.sqrt(2*eps)*math.sqrt(aa*aa+bb*bb)', 'response_root', True),
    ('witness_linear_error', 'response_root-math.sqrt(2*eps)*math.sqrt(aa*aa+bb*bb)', 'response_root-(2*eps)*math.sqrt(aa*aa+bb*bb)', False),
]
outdir = root / 'post_author_mutations'
outdir.mkdir(exist_ok=True)
records = []
for name, old, new, expected_failure in mutations:
    assert source.count(old) == 1, (name, source.count(old))
    altered = source.replace(old, new)
    path = outdir / (name + '.py')
    path.write_text(altered)
    command = [sys.executable, str(path)]
    before = time.monotonic()
    result = subprocess.run(command, cwd=root, capture_output=True, timeout=60)
    (outdir / (name + '.stdout')).write_bytes(result.stdout)
    (outdir / (name + '.stderr')).write_bytes(result.stderr)
    rec = {'name': name, 'command': command, 'cwd': str(root),
           'timeout_seconds': 60, 'returncode': result.returncode,
           'elapsed_seconds': time.monotonic() - before,
           'expected_failure': expected_failure,
           'observed_failure': result.returncode != 0,
           'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    (outdir / (name + '.execution.json')).write_text(json.dumps(rec, indent=2) + '\n')
    records.append(rec)
    assert rec['observed_failure'] == expected_failure

# The universal square-root step is checked independently of the author's
# rank-one family with norm >=1. Let Q=lambda E, psi in Ran E, selected
# projection zero on psi. Then ||QE||=lambda, ||sqrt(Q)E||=sqrt(lambda).
lam, root_lam = F(1, 16), F(1, 4)
assert root_lam * root_lam == lam
correct_witness = max(F(0), root_lam - root_lam) / root_lam
wrong_witness = max(F(0), root_lam - lam) / root_lam
assert correct_witness == 0 and wrong_witness == F(3, 4)
assessment = {'time_utc': datetime.now(timezone.utc).isoformat(),
              'author_source_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
              'mutations': records,
              'scalar_witness': {'Q': 'lambda E', 'lambda': str(lam),
                                 'selected_component_norm': '0',
                                 'correct_witness': str(correct_witness),
                                 'wrong_linear_error_witness': str(wrong_witness)},
              'limit': 'Deleting the square root in the sweep formula still passes that toy family; its separate scalar inequality and the analytic P32 proof, not the 588 cases, establish why the universal square-root step is necessary. No theorem counterexample or source repair follows.'}
(root / 'post_author_control_assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
print(json.dumps({'mutation_outcomes': [{k: r[k] for k in ['name', 'expected_failure', 'returncode']} for r in records],
                  'scalar_witness': assessment['scalar_witness'], 'limit': assessment['limit']}, sort_keys=True))
