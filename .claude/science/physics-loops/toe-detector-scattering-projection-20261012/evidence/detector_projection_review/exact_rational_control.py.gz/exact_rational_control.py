"""Separate finite algebra controls; no author helper imported or executed.

Python standard library only. Exact rational identities are the assertions;
floating values below are display-only. No infinite-dimensional theorem is
claimed from these finite cases.
"""
from fractions import Fraction as F
import json


def mat(rows):
    return [[F(x) for x in row] for row in rows]


def eye(n):
    return mat([[int(i == j) for j in range(n)] for i in range(n)])


def zeros(n):
    return mat([[0] * n for _ in range(n)])


def add(a, b):
    return [[x + y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def scale(c, a):
    return [[c * x for x in row] for row in a]


def sub(a, b):
    return add(a, scale(-1, b))


def trans(a):
    return [list(x) for x in zip(*a)]


def mul(a, b):
    bt = trans(b)
    return [[sum(x * y for x, y in zip(ar, bc)) for bc in bt] for ar in a]


def rref(a):
    a = [row[:] for row in a]
    pivots = []
    row = 0
    for col in range(len(a[0])):
        nz = next((j for j in range(row, len(a)) if a[j][col]), None)
        if nz is None:
            continue
        a[row], a[nz] = a[nz], a[row]
        v = a[row][col]
        a[row] = [x / v for x in a[row]]
        for j in range(len(a)):
            if j != row:
                v = a[j][col]
                a[j] = [x - v * y for x, y in zip(a[j], a[row])]
        pivots.append(col)
        row += 1
        if row == len(a):
            break
    return a, pivots


def inv(a):
    n = len(a)
    joined = [ar + ir for ar, ir in zip(a, eye(n))]
    reduced, pivots = rref(joined)
    assert pivots[:n] == list(range(n))
    assert [r[:n] for r in reduced] == eye(n)
    return [r[n:] for r in reduced]


def null_basis(a):
    reduced, pivots = rref(a)
    free = [j for j in range(len(a[0])) if j not in pivots]
    basis = []
    for j in free:
        v = [F(0)] * len(a[0])
        v[j] = F(1)
        for i, k in enumerate(pivots):
            v[k] = -reduced[i][j]
        basis.append(v)
    return basis


def outer(v):
    return [[x * y for y in v] for x in v]


def frob2(a):
    return sum(x * x for row in a for x in row)


def resolvent_function(a, eta):
    return sub(eye(len(a)), scale(eta, inv(add(a, scale(eta, eye(len(a)))))))


def record(name, **kwargs):
    print(json.dumps({'control': name, **kwargs}, sort_keys=True))


def main():
    # The four coordinates are one degenerate positive-energy block. Vacuum
    # and an outside energy block would be zero summands under P_J.
    vectors = [mat([[int(j == i or j == i + 1) for j in range(4)]])[0]
               for i in range(3)]
    qs = [outer(v) for v in vectors]
    weights = [F(1, 3 * 2 ** (i + 1)) for i in range(3)]  # actual B_i=2
    partials = []
    k = zeros(4)
    for w, q in zip(weights, qs):
        k = add(k, scale(w, q))
        partials.append(k)
    assert [len(rref(a)[1]) for a in partials] == [1, 2, 3]
    assert null_basis(k) == [[F(-1), F(1), F(-1), F(1)]]
    z = [F(1), F(-1), F(1), F(-1)]
    dark = scale(F(1, 4), outer(z))
    target = sub(eye(4), dark)
    assert mul(target, target) == target
    assert mul(k, dark) == zeros(4)
    assert mul(k, inv(add(k, dark))) == target
    assert mul(qs[0], qs[1]) != mul(qs[1], qs[0])
    # Wrong family and wrong dark direction must not reproduce the target.
    assert len(null_basis(partials[1])) == 2
    wrong_dark = scale(F(1, 4), outer([F(1)] * 4))
    assert mul(k, wrong_dark) != zeros(4)
    # Kernel-from-zero-quadratic-form needs positivity: this signed example
    # has zero form but nonzero action on (1,1).
    signed = mat([[1, 0], [0, -1]])
    v = mat([[1], [1]])
    assert mul(trans(v), mul(signed, v)) == mat([[0]])
    assert mul(signed, v) != mat([[0], [0]])
    record('nonorthogonal_chain_support', dimension=4, target_rank=3,
           exact_kernel=[str(x) for x in null_basis(k)[0]],
           omitted_generator_rank=2, signed_zero_form_is_not_kernel=True)

    a, b, eta = partials[0], partials[2], F(1, 7)
    ra = inv(add(a, scale(eta, eye(4))))
    rb = inv(add(b, scale(eta, eye(4))))
    difference = sub(resolvent_function(a, eta), resolvent_function(b, eta))
    rhs = scale(eta, mul(ra, mul(sub(a, b), rb)))
    wrong = scale(eta, mul(sub(a, b), mul(ra, rb)))
    assert difference == rhs
    assert difference != wrong
    record('noncommuting_resolvent_order', eta=str(eta),
           exact_correct_residual='0',
           exact_wrong_residual_squared=str(frob2(sub(difference, wrong))))

    rows = []
    p = mat([[1, 0], [0, 0]])
    fixed_eta = F(1, 9)
    for n in [2, 3, 5, 9, 17, 33]:
        # Rational orthogonal rotations approach the identity. These K_n do
        # not commute with their limit, or with each other in general.
        c, s = F(n * n - 1, n * n + 1), F(2 * n, n * n + 1)
        rot = mat([[c, -s], [s, c]])
        assert mul(rot, trans(rot)) == eye(2)
        a = mul(rot, mul(mat([[1, 0], [0, F(1, n ** 4)]]), trans(rot)))
        assert mul(a, p) != mul(p, a)
        coupled = resolvent_function(a, F(1, n ** 8))
        expected_coupled = mul(rot, mul(mat([[F(n ** 8, n ** 8 + 1), 0],
                                            [0, F(n ** 4, n ** 4 + 1)]]),
                                        trans(rot)))
        assert coupled == expected_coupled
        fixed = resolvent_function(a, fixed_eta)
        rows.append({'n': n, 'K_to_P_frob2': float(frob2(sub(a, p))),
                     'joint_to_identity_frob2': float(frob2(sub(coupled, eye(2)))),
                     'joint_to_P_frob2': float(frob2(sub(coupled, p))),
                     'fixed_eta_to_F_P_frob2': float(frob2(sub(fixed, resolvent_function(p, fixed_eta))))})
    assert rows[-1]['joint_to_identity_frob2'] < rows[0]['joint_to_identity_frob2']
    assert rows[-1]['K_to_P_frob2'] < rows[0]['K_to_P_frob2']
    assert rows[-1]['fixed_eta_to_F_P_frob2'] < rows[0]['fixed_eta_to_F_P_frob2']
    assert rows[-1]['joint_to_P_frob2'] > 0.99
    record('rotating_joint_limit_counterexample', samples=rows,
           scope='Exact finite identities; asymptotic conclusion follows from the displayed eigenvalues and rotation, not these samples.')
    record('completion', scope='Finite algebra only; no analytic convergence, microscopic realization, ND, EX or independent status from a count.')


if __name__ == '__main__':
    main()
