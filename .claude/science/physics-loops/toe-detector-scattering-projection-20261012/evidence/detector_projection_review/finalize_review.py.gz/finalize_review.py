"""Refresh exact read-only inputs and bind the completed external review.

No repository or author-packet mutation. The receipt binds evidence and
declared scope; it does not calculate or confer a scientific audit verdict.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
s = root.parent
repo = s.parent / 'scattering_worktree'
report = s / 'DETECTOR_SCATTERING_PROJECTION_REVIEW.md'
deadline = datetime(2026, 10, 12, 16, 0, 52, tzinfo=timezone.utc)
now = datetime.now(timezone.utc)
assert now < deadline
assert not (root / 'receipt.json').exists(), 'Do not silently replace the completed receipt.'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data)}


source = json.loads((root / 'source_initial.json').read_text())
refresh = []
for entry in source['target_sources']:
    actual = bind(Path(entry['path']))
    assert actual['sha256'] == entry['sha256'] and actual['bytes'] == entry['bytes']
    refresh.append({**actual, 'complete_read': True,
                    'lines': entry['lines'], 'unchanged': True})
instructions = []
for entry in source['instructions']:
    data = subprocess.check_output(['git', 'show', entry['git_source']], cwd=repo)
    assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
    instructions.append({**entry, 'unchanged': True})
pre_path = root / 'precontrol_freeze.json'
assert sha(pre_path.read_bytes()) == '76c3d7adfc4cfa8d5c77f427aa35f8aaf1615b08e537103b9f6677eb985f895a'
pre = json.loads(pre_path.read_text())
for entry in pre['files']:
    actual = bind(Path(entry['path']))
    assert actual['sha256'] == entry['sha256'] and actual['bytes'] == entry['bytes']
author_path = s / 'detector_scattering_projection/freeze_receipt.json'
assert sha(author_path.read_bytes()) == '41e516aec74bd86d28702f5c079522f9ba8c91422eb660021190a241de176b72'
author = json.loads(author_path.read_text())
author_rows = []
for kind in ['inputs', 'outputs']:
    for index, entry in enumerate(author[kind]):
        if 'path' in entry:
            data = Path(entry['path']).read_bytes()
            identity = entry['path']
        else:
            identity = entry['git_commit'] + ':' + entry['git_path']
            data = subprocess.check_output(['git', 'show', identity], cwd=repo)
        assert sha(data) == entry['sha256'] and len(data) == entry['bytes']
        author_rows.append({'kind': kind, 'index': index, 'identity': identity,
                            'sha256': sha(data), 'bytes': len(data), 'unchanged': True})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
refresh_record = {'time_utc': now.isoformat(), 'target_sources': refresh,
                  'instructions': instructions, 'author_bindings': author_rows,
                  'initial_checkout_head': source['initial_checkout_head'],
                  'current_checkout_head': head,
                  'known_concurrent_root_action': source['concurrent_root_action'],
                  'reviewer_git_mutations': False}
(root / 'final_source_refresh.json').write_text(json.dumps(refresh_record, indent=2) + '\n')

outputs = [bind(report)] + [bind(path) for path in sorted(root.rglob('*'))
                           if path.is_file() and path != root / 'receipt.json']
receipt = {
    'frozen_at': now.isoformat(), 'deadline': deadline.isoformat(),
    'disposition': 'PASS for the exact conditional P1-P33 source; no required correction.',
    'target': refresh[0], 'author_receipt': bind(author_path),
    'report': bind(report), 'precontrol_freeze': bind(pre_path),
    'source_refresh': bind(root / 'final_source_refresh.json'),
    'source_read_coverage': refresh,
    'instruction_sources': instructions,
    'primary_comparator': {
        'versioned_url': 'https://arxiv.org/pdf/1308.5187v1',
        'pdf_sha256': '64ab1ee60602583c8491fb012f064102e9cda45dcd319288184d1f42349f2793',
        'fully_read_freshly_extracted_pages': [4, 5, 6, 7, 8, 9, 20, 21, 22],
        'extracted_pages_total': 29,
        'external_lemma_7_5_proof_read': False,
        'imported_as_mathematical_premise': False,
        'official_abstract_and_pdf_opened': True},
    'complete_target_claim_coverage': [f'P{i}' for i in range(1, 34)],
    'independence': {
        'new_author_code_logs_receipt_opened_after_precontrol_freeze': True,
        'shared_inputs': 'Complete source statement/control descriptions, exact precursor notes and Fock/PC reviews; coordinator is a coauthor.',
        'independent_work': 'Analytic reconstruction and separate exact-rational control frozen before author evidence.',
        'not_claimed': ['blind route discovery', 'different model-family independence',
                        'formal proof verification', 'independence of supplied physical premises']},
    'verification': {
        'author_inputs_and_outputs_refreshed': len(author_rows),
        'predecessor_identity_array_checked': 63,
        'original_author_reproduction': json.loads((root / 'logs/author_reproduction.execution.json').read_text()),
        'pre_author_independent_control': json.loads((root / 'logs/independent_control.execution.json').read_text()),
        'post_author_mutation_assessment': bind(root / 'post_author_control_assessment.json'),
        'full_failure_logs_preserved': True,
        'control_limitation': 'The rank-one witness sweep passes a linear-error substitution; its separate scalar negative example and the analytic P32 proof carry the universal square-root requirement.'},
    'scope': 'Selected F2 outgoing scattering sector; existential countable family, exact support and ordered limits, conditional finite-time lower witness.',
    'unproved': ['ND/no-common-kernel vanishing', 'full-GNS EX', 'all-channel coverage',
                 'physical realization', 'effective detector enumeration', 'numerical witness constants',
                 'lower frame bound', 'uniform resolvent rate'],
    'limits': ['No formal retained status or audit verdict.',
               'No complete new audit of external primary proofs used by the already-reviewed precursor results.',
               'New E/PC publication files and any subsequent projection publication edits are outside this frozen-source verdict.',
               'Identity arrays and finite checks do not replace the analytic proof.'],
    'current_checkout_head': head,
    'initial_checkout_head': source['initial_checkout_head'],
    'concurrent_root_action': source['concurrent_root_action'],
    'reviewer_git_mutations': False,
    'editable_prompt_files_changed': [],
    'model_override': None, 'reasoning_override': None,
    'subdelegation': False, 'publication_action': False,
    'audit_verdict_applied': False, 'physical_axiom_change': False,
    'other_chat_message': False,
    'write_scope': [str(report), str(root)],
    'outputs': outputs,
    'output_exclusions': [str(root / 'receipt.json')],
    'exclusion_reason': 'Receipt self-reference only. Execution summary is returned by the tool, not written after freezing.'}
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'report': bind(report), 'receipt': bind(root / 'receipt.json'),
                  'disposition': receipt['disposition'], 'frozen_at': receipt['frozen_at'],
                  'output_count': len(outputs), 'current_checkout_head': head}, sort_keys=True))
