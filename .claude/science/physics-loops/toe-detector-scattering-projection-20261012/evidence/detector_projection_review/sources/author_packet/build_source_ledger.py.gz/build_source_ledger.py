#!/usr/bin/env python3
"""Bind actual source identities without modifying any predecessor or repository."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
s = root.parent
repo = s.parent / 'scattering_worktree'
old = s / 'compact_detector_convergence'
sha = lambda data: hashlib.sha256(data).hexdigest()
expected_head = 'c3f84746b1991e0a15c6da79d049b89d9469f727'
instruction_head = '3a4b2c66a1ead7a1c48b4359627e968f681e3c39'
head = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'], text=True).strip()
assert head == expected_head, (head, expected_head)
old_receipt = json.loads((old/'freeze_receipt.json').read_text())
assert sha((old/'freeze_receipt.json').read_bytes()) == 'de9a4acddf3c08b406c5dd74cae01d206e1e0a9ab2d804489ddc9ae42d0eca06'

checks = []
for item in old_receipt['inputs']+old_receipt['outputs']:
    if 'path' in item:
        data = Path(item['path']).read_bytes()
        identity = item['path']
    else:
        data = subprocess.check_output(['git','-C',str(repo),'show',
                                        item['git_commit']+':'+item['git_path']])
        identity = item['git_commit']+':'+item['git_path']
    actual = sha(data)
    checks.append(dict(identity=identity, expected_sha256=item['sha256'],
                       actual_sha256=actual, matches=(actual == item['sha256'])))
assert all(c['matches'] for c in checks)
(root/'predecessor_binding_check.json').write_text(json.dumps(dict(
    checked_at=dt.datetime.now(dt.timezone.utc).isoformat(),
    receipt_sha256=sha((old/'freeze_receipt.json').read_bytes()),
    bindings=checks), indent=2)+'\n')

prior = json.loads((old/'SOURCE_LEDGER.json').read_text())
inputs = []
coverage = {
    'SCATTERING_EXHAUSTION_NEXT_OBLIGATION.md':
        'Read fully in predecessor task at unchanged identity. Motivation only; P21-P30 rebuilt here. Later EX review outcome not imported.',
    'COMPACT_PATCH_SCATTERING_COVARIANCE_PROBE.md':
        'Read fully in predecessor task. Complete lines 1-280 reread here; exact filter/direct creator and creator-density passages used.',
    'COMPACT_PATCH_SCATTERING_EX_PUBLICATION_REPAIR.md':
        'Read fully in predecessor task, unchanged. Separate vacuum/gap setting.',
    'COMPACT_PATCH_FOCK_ISOMETRY_PROBE.md':
        'Read fully in predecessor task. Complete lines 1-200 and 240-326 reread here. F5-F6 creator-independence, selected range and separated-product density are premises.',
    'COMPACT_PATCH_FOCK_ISOMETRY_REVIEW.md':
        'Read fully in predecessor task, unchanged. Independent predecessor scope only; this note remains unreviewed.',
    'COMPACT_PATCH_SCATTERING_COVARIANCE_REVIEW.md':
        'Read fully in predecessor task, unchanged. Core direct-creator review only.',
    'EX_REPAIR_REVIEW_ADDENDUM.md':
        'Read fully in predecessor task, unchanged. Exact EX wording repair confirmation only.'
}
for item in prior['inputs']:
    if 'path' in item:
        path = Path(item['path'])
        if path.name in coverage:
            entry = dict(item)
            entry['coverage'] = coverage[path.name]
            inputs.append(entry)
        elif str(path).startswith(str(repo)) and (
                '/docs/ai_methodology/' in str(path) or path.name in ('AGENTS.md','axiom_premise_nodes.json')):
            entry = dict(item)
            entry['coverage'] = 'Applicable instruction/registry read fully in predecessor task; same coherent campaign and exact source. Hash reverified here, not reread.'
            inputs.append(entry)
    else:
        entry = dict(item)
        entry['coverage'] = 'Complete planning AGENTS read in predecessor task at this exact revision; identity reverified read-only here.'
        inputs.append(entry)


def bind(path, role, expected=None):
    path = Path(path)
    data = path.read_bytes()
    actual = sha(data)
    if expected:
        assert actual == expected, (str(path), actual, expected)
    inputs.append(dict(path=str(path), sha256=actual, bytes=len(data), coverage=role))


bind(s/'COMPACT_DETECTOR_CONVERGENCE_PROBE.md',
     'Complete 339-line source authored/read in predecessor task. Provisional when this task began; separate review completed during this derivation at the unchanged identity. Exact direct properties, creation maps, C24a, and positive-detector formula reread here. No independent review by this author of its own PC proof claimed.',
     'bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64')
bind(s/'COMPACT_DETECTOR_CONVERGENCE_REVIEW.md',
     'Full report read after completion, including C24a/C28 and scope limits. The underlying independent reconstruction/control packet was not rechecked by this author; root reports completing its own full coverage.',
     '2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0')
bind(s/'compact_detector_review/receipt.json',
     'Exact receipt hash and structured target/report identities checked. No claim here to reread or independently reconstruct all listed review evidence.',
     'e9fb01e5d88618f1905a7426d07991e0a96e88cdd32a8d996b4caa92bd39db5d')
review_receipt = json.loads((s/'compact_detector_review/receipt.json').read_text())
assert review_receipt['target_sha256'] == 'bed0584922876c64de1658f3135390420b703dd661edf5076e02a0a36af34d64'
assert review_receipt['review_sha256'] == '2f9ebfed745c217d97750ddc5f7a5edeaffaede72895ad0da1af0974ef2c51f0'
bind(s/'ROOT_DETECTOR_SUPPORT_PROJECTION_LEAD.md',
     'Complete 93 lines read. Conjectural lead from contributor, not evidence.',
     '8ae35c637fd77aee6a68e7a120c36d7d5c4aba4c9fef6df8b594316369c5138f')
bind(old/'freeze_receipt.json',
     'Structured receipt parsed completely; all 63 input/output identities checked, including one nonpath Git binding. No predecessor changed.',
     'de9a4acddf3c08b406c5dd74cae01d206e1e0a9ab2d804489ddc9ae42d0eca06')
bind(old/'SOURCE_LEDGER.json',
     'Structured ledger parsed for exact prior reading provenance. Initial combined display with receipt truncated; no complete fresh prose read of that display claimed.',
     '8e8a85eebb04735f5bbf9ca88f8a9e1daaded9b3ae59f2cae335976263d03330')
bind(Path('/Users/jonreilly/.codex/skills/physics-loop/SKILL.md'),
     'Installed physics-loop skill previously read; current hash matches the frozen repository copy.',
     '7d924a4c8b3ae428523616f801cf05ee10d372eced7b6939030f1eb5d5897aa4')
sources = s/'scattering_exhaustion_next/sources'
bind(sources/'Dybalski_Gerard_1308.5187v1.pdf',
     'Primary comparison only. Complete supplied text pages 6-9 and 20-22 read here, including full section 7. Theorem 2.9 and standing assumptions compared; no theorem invoked under unchecked relativistic hypotheses. Lemma7.5 refers its proof elsewhere, not imported.',
     '64ab1ee60602583c8491fb012f064102e9cda45dcd319288184d1f42349f2793')
for page in (6,7,8,9,20,21,22):
    bind(sources/'Dybalski_Gerard_1308.5187v1_pages'/('%02d.txt'%page),
         'Complete supplied primary page text read in this task; not a fresh extraction or visual-render verification.')
bind(sources/'download_receipt.json',
     'Parsed source metadata only to verify the DG PDF identity and official versioned URL. Other sources not used in this task.')
ledger = dict(
    created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
    repository_commit=head, instruction_commit=instruction_head,
    deadline='2026-10-12T16:00:52+00:00', inputs=inputs,
    literature_urls=['https://arxiv.org/abs/1308.5187v1'],
    web_scope='Official v1 metadata opened in this task; proof comparison uses the hash-bound local primary PDF/page texts.',
    no_fresh_read_claims=[
        'DG pages 1-5,10-19,23-29 not read here except search-hit context.',
        'DG12 and the external proof behind DG Lemma7.5 not read or imported.',
        'No new full BDN/Dybalski1608 reading in this task; precursor proofs are explicit source-bound dependencies.',
        'The PC review report was read completely and its receipt bound; its underlying complete reconstruction/controls were not independently rechecked here. The separate E1-E18 review was not read or used here.',
        'Published-note variants and unrelated science sources are not new proof inputs.'
    ],
    limits='Conditional author proof. No exhaustive literature search, analytic certification by finite tests, effective detector enumeration, ND/EX, physical realization, or independent review.')
(root/'SOURCE_LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n')
print(json.dumps(dict(input_bindings=len(inputs), verified_predecessor_bindings=len(checks),
                      verified_predecessor_path_bindings=sum('path' in x for x in old_receipt['inputs']+old_receipt['outputs']),
                      repository_commit=head, all_predecessor_bindings_match=True),sort_keys=True))
