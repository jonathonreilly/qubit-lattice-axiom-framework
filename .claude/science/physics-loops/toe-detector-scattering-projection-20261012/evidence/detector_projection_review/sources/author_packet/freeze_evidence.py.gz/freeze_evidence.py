#!/usr/bin/env python3
"""Freeze only this external author packet and verify its exact inputs."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parent
s = root.parent
repo = s.parent/'scattering_worktree'
note = s/'DETECTOR_SCATTERING_PROJECTION_PROBE.md'
deadline = dt.datetime(2026,10,12,16,0,52,tzinfo=dt.timezone.utc)
now = dt.datetime.now(dt.timezone.utc)
assert now < deadline, 'fixed campaign deadline has passed'
assert not (root/'freeze_receipt.json').exists(), 'never overwrite a frozen receipt'
sha = lambda b: hashlib.sha256(b).hexdigest()
ledger = json.loads((root/'SOURCE_LEDGER.json').read_text())
for entry in ledger['inputs']:
    if 'path' in entry:
        data = Path(entry['path']).read_bytes()
    else:
        data = subprocess.check_output(['git','-C',str(repo),'show',
                                       entry['git_commit']+':'+entry['git_path']])
    assert sha(data) == entry['sha256'], entry
    assert len(data) == entry['bytes'], entry
head = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
assert head == ledger['repository_commit']
text = note.read_text()
assert re.findall(r'\\tag\{P(\d+)\}',text) == [str(x) for x in range(1,34)]
assert text.count(r'\[') == text.count(r'\]')
assert text.count(r'\(') == text.count(r'\)')
assert not any(ord(c)<32 and c not in '\n\t\r' for c in text)
assert '+operatorname' not in text
checks = [json.loads(x) for x in (root/'projection_algebra.stdout').read_text().splitlines()]
assert len(checks) == 7 and all(x['passed'] for x in checks)
execution = json.loads((root/'projection_algebra.execution.json').read_text())
assert execution['returncode'] == 0 and not execution['timed_out']
assert execution['declared_timeout_seconds'] == 60
assert (root/'projection_algebra.stderr').read_bytes() == b''
exclusions = {'freeze_receipt.json','freeze.stdout','freeze.stderr','freeze.execution.json'}
paths = [note]+sorted(p for p in root.rglob('*') if p.is_file() and p.name not in exclusions)
outputs = []
for path in paths:
    data = path.read_bytes()
    outputs.append(dict(path=str(path),sha256=sha(data),bytes=len(data)))
receipt = dict(
    frozen_at=now.isoformat(), deadline=deadline.isoformat(),
    note_sha256=sha(note.read_bytes()), note_lines=len(text.splitlines()),
    repository_commit=head, instruction_commit=ledger['instruction_commit'],
    inputs=ledger['inputs'], outputs=outputs,
    output_exclusions=sorted(exclusions),
    exclusion_reason='Receipt self-reference and timeout-wrapper logs written after freezing returns.',
    theorem_status='Complete conditional author proof P1-P33; independent reconstruction pending.',
    pc_status='Unchanged source separately reviewed; report and receipt bound, full report read here.',
    controls='Six finite author algebra controls; no analytic convergence or physical realization certified.',
    prompt_files_changed=[], no_repo_mutations=True, no_subdelegation=True,
    model_override=None, reasoning_override=None)
(root/'freeze_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(frozen_at=receipt['frozen_at'],note_sha256=receipt['note_sha256'],
                      note_lines=receipt['note_lines'],input_bindings=len(receipt['inputs']),
                      output_bindings=len(outputs),
                      receipt_sha256=sha((root/'freeze_receipt.json').read_bytes())),sort_keys=True))
