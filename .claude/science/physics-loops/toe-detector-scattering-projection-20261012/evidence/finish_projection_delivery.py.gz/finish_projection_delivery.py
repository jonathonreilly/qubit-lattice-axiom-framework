"""Validate and stage the complete source-reviewed projection milestone."""
from pathlib import Path
from urllib.parse import unquote
import ast,gzip,hashlib,json,os,re,subprocess,sys
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-detector-scattering-projection-20261012'
BASE='296155eda2ca6a5ab6ae6307190362b9a84ea690'
os.chdir(W);sys.path.insert(0,str(W/'scripts'));import runner_cache
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs'];assert len(rows)==2
primary=next(r for r in rows if r['kind']=='primary');body=(W/primary['publication_path']).read_text()
execution=json.loads((S/'projection_canonical_execution.json').read_text())
assert execution['status']=='ok' and execution['exit_code']==0 and execution['timeout_sec']==60 and execution['stderr']==''
old=(S/'detector_scattering_projection/projection_algebra.stdout').read_text()
assert execution['stdout'].startswith(old)
extra=execution['stdout'][len(old):].splitlines();assert len(extra)==8
assert json.loads(extra[0])['wrong_linear_witness']=='3/4'
mutations=json.loads((S/'projection_primary_mutations/manifest.json').read_text())['runs']
assert len(mutations)==8 and sum(r['expected_failure'] for r in mutations)==7
for r in mutations:
    assert r['primary_sha256']==sha(body.encode()) and body.count(r['before'])==1
    d=S/'projection_primary_mutations';p=d/(r['name']+'.py')
    assert p.read_text()==body.replace(r['before'],r['after'],1) and sha(p.read_bytes())==r['source_sha256']
    out=(d/(r['name']+'.stdout')).read_bytes();err=(d/(r['name']+'.stderr')).read_bytes()
    assert sha(out)==r['stdout_sha256'] and sha(err)==r['stderr_sha256']
    assert execution['stdout'].encode().startswith(out)
    if r['expected_failure']:assert r['exit_code']==1 and b'AssertionError' in err
    else:assert r['name']=='witness_linear_error' and r['exit_code']==0 and not err and out==execution['stdout'].encode()
graph=W/'docs/audit/data/citation_graph_manifest.json'
before=json.loads(subprocess.check_output(['git','show',BASE+':'+str(graph.relative_to(W))]));after=json.loads(graph.read_text())
assert after['node_count']==before['node_count']+1 and after['edge_count']==before['edge_count']+3
assert all(after['nodes'].get(k)==v for k,v in before['nodes'].items())
assert {k:v['out_degree'] for k,v in after['nodes'].items() if k not in before['nodes']}=={'detector_scattering_projection_bounded_theorem_note_2026-10-12':3}
compat=json.loads((S/'projection_focused_audit_compat.json').read_text());assert compat['checked']==compat['failures']==compat['control_failures']==[]
(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete source composition

The complete P1-P33 source, necessary premises, separate reconstruction and
all finite evidence were read at their frozen identities. Root proposed
mechanisms and is a coauthor, not an independent reviewer. The historical
author operational paragraph is explicitly labeled; original bytes remain
preserved. Publication changes only claim/review/recovery metadata and adds
the reviewed scalar control/evidence discussion. No equation, hypothesis,
domain or analytic conclusion is changed. Full source maps recover both
the entire note and original helper plus the explicit scalar addition.

The primary's new scalar case is exactly the reviewed Q=(1/16)E example:
response and correct error are1/4, with B=1/16. The correct witness is0;
the incorrect linear error1/16 gives3/4 for a zero selected component.
Its exact finite assertion is separate from the unchanged rank-one sweep,
whose known nondiscrimination remains preserved. Seven intended actual
whole-primary defects fail; the disclosed eighth alteration passes that
limited sweep. These finite controls do not prove the analytic theorem.

All older SC/Fock/E/PC science and evidence remain unchanged. The selected
support equality does not supply ND, EX, effective enumeration, numerical
witness constants or a microscopic realization.
''')
(P/'DELIVERY_CHECKS.md').write_text(f'''# Scoped publication verification

The canonical primary exited0 in{execution['elapsed_sec']:.9f}s under its
declared60s timeout, with empty stderr. Every original seven-line output
record reproduced byte-for-byte, followed by the exact scalar discriminator
and seven explicit scope lines. The original seventh line is a scope summary;
the total consists of six original finite control groups plus one scalar case.

Seven actual complete-primary defects failed at their intended assertions:
factorable total-energy mask, wrong temporal transfer, omitted partition,
signed weight, invalid resolvent order, omitted witness error, and the scalar
linear-error substitution. The eighth alteration, a linear error in only the
rank-one sweep, deliberately passes and records that toy family's limitation.
All altered sources, commands, declared timeouts, full outputs and traces
are preserved. Source changes and stdout prefixes were checked against the
actual complete primary, not a separately recreated helper.

Citation acknowledgment gives{after['node_count']}nodes and{after['edge_count']}edges:
one new projection node and three intended creator/Fock/PC dependencies.
Every older node is unchanged. Focused changed-evidence compatibility selected
no applied rows and no failures. The global combined audit pipeline and strict
audit lint were not run; independent landing gates remain, with no audit verdict.

Exact note/primary reconstruction, syntax, cache/input identity, ordinary
local links, own/external source bindings, vocabulary fix/report, whitespace
and all staged identities are checked before commit. No primary paper is
redistributed. No Lean, physical realization, ND, EX or retained claim follows.
''')
rhp=P/'REVIEW_HISTORY.md';rhp.write_text(rhp.read_text()+'''
## Publication conformance

Goal, trace, exact conditional claim and source dependencies are explicit.
Complete arguments, reconstructions, independent controls, reproductions,
known nondiscriminating cases and failures remain distinguishable. Source
maps, actual primary defects, canonical output, citation acknowledgment and
scoped compatibility were checked. No draft, science merge, main push,
axiom/prompt edit, applied audit verdict or retained promotion is included.
''')
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in rows]+[P/'reconstruct.py']
for mode in ['fix','report-only']:
    prefix=S/('projection_final_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
    prefix.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
    report=json.loads(prefix.with_suffix('.json').read_text());assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
r=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'projection_final_reconstruction.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
ast.parse(body)
assert runner_cache.cache_status(primary['publication_path'])==runner_cache.cache_identity_status(primary['publication_path'])=='fresh'
links=[]
for p in editable:
    if p.suffix!='.md':continue
    prose=[];fenced=False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
    for target in re.findall(r'\]\(([^)\s]+)\)','\n'.join(prose)):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(p,target)
        links.append(dict(source=str(p.relative_to(W)),target=target))
emap=json.loads((P/'EVIDENCE_MAP.json').read_text());evidence={r['preserved']:r for r in emap['files']}
def preserve(src):
    b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(b,mtime=0)
    if dst.exists():assert dst.read_bytes()==packed,src
    dst.write_bytes(packed);evidence[str(dst.relative_to(P))]=dict(original=str(src),preserved=str(dst.relative_to(P)),bytes=len(b),sha256=sha(b))
for p in sorted((S/'projection_primary_mutations').rglob('*')):
    if p.is_file():preserve(p)
for n in ['prepare_projection_publication.py','run_projection_primary_mutants.py','run_projection_citation_compat.py','finish_projection_delivery.py',
          'projection_canonical_execution.json','projection_initial_vocab_fix.json','projection_initial_vocab_fix.log','projection_initial_reconstruction.log',
          'projection_final_vocab_fix.json','projection_final_vocab_fix.log','projection_final_vocab_report-only.json','projection_final_vocab_report-only.log',
          'projection_final_reconstruction.log','projection_citation_execution.json','projection_citation_build.stdout','projection_citation_build.stderr',
          'projection_citation_manifest.stdout','projection_citation_manifest.stderr','projection_focused_audit_compat.json',
          'projection_focused_audit_compat.stderr','projection_focused_audit_compat.execution.json']:
    preserve(S/n)
for r in evidence.values():
    b=gzip.decompress((P/r['preserved']).read_bytes());assert len(b)==r['bytes'] and sha(b)==r['sha256']
for r in emap['external_reference_sources']:
    b=Path(r['original']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
mech=dict(full_source_reconstruction=True,canonical_elapsed_seconds=execution['elapsed_sec'],
          actual_primary_assertion_failures=7,disclosed_toy_nondiscrimination=1,cache_and_input_identity_fresh=True,
          citation_delta=dict(nodes=1,edges=3),every_old_graph_node_unchanged=True,
          preserved_evidence_files=len(evidence),external_primary_bindings=len(emap['external_reference_sources']),ordinary_links=links,
          scope='Mechanical provenance and execution checks; complete separate analytic reconstruction carries the mathematical check.')
(S/'projection_delivery_mechanical.json').write_text(json.dumps(mech,indent=2)+'\n');preserve(S/'projection_delivery_mechanical.json')
emap['files']=[evidence[k] for k in sorted(evidence)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in rows]+[graph,runner_cache.cache_path_for(primary['publication_path'])]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
    row=dict(path=str(p.relative_to(W)),sha256=sha(p.read_bytes()))
    if p.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(p.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps(dict(base_revision=BASE,scope='Exact intended publication set except this self-referential manifest.',files=ident),indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True,timeout=60);subprocess.run(['git','diff','--cached','--check'],check=True,timeout=60)
for r in ident:assert sha(subprocess.check_output(['git','show',':'+r['path']]))==r['sha256']
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}==set(paths)
assert not subprocess.check_output(['git','diff','--name-only'])
assert all(x.startswith('A\t') or x=='M\tdocs/audit/data/citation_graph_manifest.json' for x in subprocess.check_output(['git','diff','--cached','--name-status'],text=True).splitlines())
result=dict(staged_files=len(paths),staged_hashes_match=True,whitespace_clean=True,**mech)
(S/'projection_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
