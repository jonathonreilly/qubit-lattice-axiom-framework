"""Preserve the full reviewed projection theorem in the existing regular PR."""
from pathlib import Path
import gzip,hashlib,json,subprocess

S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-detector-scattering-projection-20261012'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()=='296155eda2ca6a5ab6ae6307190362b9a84ea690'
assert not subprocess.check_output(['git','-C',str(W),'status','--porcelain'])
assert json.loads((S/'Projection_root_review_coverage.json').read_text())['review_accepted']
P.mkdir(exist_ok=False)
note='DETECTOR_SCATTERING_PROJECTION_BOUNDED_THEOREM_NOTE_2026-10-12.md'
runner='detector_scattering_projection_2026_10_12.py'
claim='detector_scattering_projection_bounded_theorem_note_2026-10-12'
precursors=['COMPACT_PATCH_SCATTERING_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-11.md',
            'COMPACT_PATCH_FOCK_ISOMETRY_BOUNDED_THEOREM_NOTE_2026-10-12.md',
            'COMPACT_DETECTOR_CONVERGENCE_BOUNDED_THEOREM_NOTE_2026-10-12.md']
deps=['compact_patch_scattering_covariance_bounded_theorem_note_2026-10-11',
      'compact_patch_fock_isometry_bounded_theorem_note_2026-10-12',
      'compact_detector_convergence_bounded_theorem_note_2026-10-12']
src=S/'DETECTOR_SCATTERING_PROJECTION_PROBE.md';raw=src.read_text()
assert sha(raw.encode())=='91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4'
edits=[]
def edit(before,after,reason):
    global raw
    assert raw.count(before)==1,(before,raw.count(before))
    raw=raw.replace(before,after,1);edits.append(dict(before=before,after=after,reason=reason))
first=raw.splitlines()[0]
meta='---\nclaim_id: '+claim+'\nclaim_type: bounded_theorem\nclaim_scope: '+json.dumps('For the stated selected outgoing scattering sector and narrow bounded Borel energy windows, a countable family of admissible positive detectors has support exactly the selected scattering projection. Ordered detector-time, family and resolvent limits recover it; a conditional finite-time response gives a one-sided lower witness. No full-GNS exhaustion, physical realization, effective enumeration or numerical witness constants are proved.')+'\nupstream_dependencies:\n'+''.join('  - '+x+'\n' for x in deps)+'runner: scripts/'+runner+'\nactual_current_surface_status: conditional-support\naudit_required_before_effective_retained: true\nbare_retained_allowed: false\n---\n\n'
edit(first,meta+first,'Register the exact conditional scope and actual proof dependencies.')
edit('**Claim type:** conditional bounded theorem. **Author status:** proof proposed; independent reconstruction required. The compact detector convergence dependency PC received a separate source-bound independent review during this derivation; its original source is unchanged. The new projection theorem has not been independently checked. Root proposed the route and is a contributor, not an independent reviewer. No physical realization, retained audit status, no-common-kernel condition ND, or full-GNS exhaustion EX is asserted.',
     '**Claim type:** bounded theorem. **Status:** conditional-support. A separate complete P1–P33 reconstruction found no required mathematical correction. The compact detector convergence dependency PC also has a separate source-bound review. Root proposed the route and is a contributor, not an independent reviewer. No physical realization, retained audit status, no-common-kernel condition ND, or full-GNS exhaustion EX is asserted.',
     'Record the completed focused proof review; no theorem or premise changes.')
edit('Write S for `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`. The read-only repository source is `c3f84746b1991e0a15c6da79d049b89d9469f727`; planning instructions are `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. All predecessor files remain unchanged.',
     'S denotes the original external research collection. The [complete projection milestone packet](../.claude/science/physics-loops/toe-detector-scattering-projection-20261012/) preserves the frozen argument, author evidence, separate review and exact reconstruction maps. Its EVIDENCE_MAP.json records external primary-source recovery without redistributing complete papers. The actual in-branch premises are the [compact-creator construction]('+precursors[0]+'), [selected Fock isometry]('+precursors[1]+') and [detector convergence]('+precursors[2]+'). Original source identities below remain unchanged. The author acquired sourcec3f84746b1991e0a15c6da79d049b89d9469f727; the reviewed E/PC publication advanced the branch to296155eda2ca6a5ab6ae6307190362b9a84ea690. Planning remains3a4b2c66a1ead7a1c48b4359627e968f681e3c39.',
     'Provide portable recovery and all three actual proof dependencies.')
edit('The new theorem still needs its own independent review.',
     'The new theorem has now received its own complete independent reconstruction; the exact report and limits are appended below.',
     'Refresh the completed review obligation only.')
append='''

## Publication evidence and remaining scope

The complete separate report has SHA256
`d9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2`,
with receipt`1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b`.
The full reconstruction and distinct exact-rational control were frozen before
new author evidence, at01:55:53UTC, record
`76c3d7adfc4cfa8d5c77f427aa35f8aaf1615b08e537103b9f6677eb985f895a`.
No required proof correction was found. Root read the complete source,
reconstruction and control evidence and is a coauthor, not a second independent
reviewer. Neither same-family context separation nor source hashes establish
independence of shared physical premises.

The [finite projection control](../scripts/'''+runner+''') preserves the entire
original helper. Its rank-one witness sweep does not distinguish every invalid
universal error formula: a linear-error substitution passes that toy family.
This limitation and its complete passing output are preserved. The separately
checked scalar case Q=(1/16)E gives zero true selected component and a false
lower witness3/4 under the linear-error formula. The primary includes that
explicit exact scalar discriminator. P32 supplies the actual universal
square-root proof; neither toy family establishes analytic propagation.

PUBLICATION_EDITS.json and reconstruct.py recover the complete note and primary
from frozen bytes and explicit metadata/evidence additions. DELIVERY_CHECKS.md
records canonical execution, actual whole-primary defects and the outstanding
independent audit gates. No Lean certificate, physical realization, effective
enumeration, numerical witness constants, ND, EX or retained status is claimed.
The live campaign checkpoint remains toe-dynamics-bridge-20261009 in the
transport worktree; this packet is a frozen milestone snapshot.
'''
for line in list(dict.fromkeys(x for x in raw.splitlines(keepends=True) if x.rstrip('\r\n').endswith((' ','\t')))):
    edit(line,line.rstrip()+'\n','Remove presentation-only trailing whitespace.')
if raw.endswith('\n\n'):
    tail=raw[-180:];edit(tail,tail.rstrip()+'\n','Normalize final blank lines only.')
(W/'docs'/note).write_text(raw+append)
rows=[dict(kind='note',source_path=str(src),source_sha256=sha(src.read_bytes()),preserved_source='evidence/'+src.name+'.gz',
           edits=edits,appended_text=append,publication_path='docs/'+note,publication_sha256=sha((raw+append).encode()))]
helper=S/'detector_scattering_projection/check_projection_algebra.py';body=helper.read_text()
anchor='from fractions import Fraction as F\n'
assert body.count(anchor)==1
addition='AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = '+json.dumps(['docs/'+note]+['docs/'+x for x in precursors],indent=4)+'\nif not __debug__:\n    raise RuntimeError("Run without -O: exact control assertions must be enabled")\n\n'+anchor
suffix='''
# The reviewed scalar positive-operator case discriminates a universal error
# formula that the original rank-one sweep does not distinguish.
_scalar_lambda = F(1, 16)
_scalar_response = F(1, 4)
_scalar_error = F(1, 4)
assert _scalar_response * _scalar_response == _scalar_lambda
_correct_witness = max(F(0), _scalar_response - _scalar_error) / _scalar_response
_wrong_linear_witness = max(F(0), _scalar_response - _scalar_lambda) / _scalar_response
assert _correct_witness == 0, "scalar positive operator needs the square-root error"
assert _wrong_linear_witness == F(3, 4)
print(json.dumps({"control": "reviewed_scalar_witness", "Q": "(1/16)E",
                  "actual_selected_norm": "0", "correct_witness": str(_correct_witness),
                  "wrong_linear_witness": str(_wrong_linear_witness)}, sort_keys=True))
print("per_element: finite exact filtering, support and noncommuting resolvent identities checked")
print("per_site: finite matrix fixtures only; no microscopic physical model constructed")
print("per_mode: finite tensor masks checked; continuum coverage uses the written proof")
print("per_block: narrow-window arithmetic and positive finite sums checked")
print("lattice_wide: checked and not executed — analytic scattering projection and ordered limits are proved in P1-P33")
print("TOTAL: PASS=7 FAIL=0")
print("SCOPE: Six original finite control groups plus the exact scalar discriminator; no ND, EX or physical realization.")
'''
primary=body.replace(anchor,addition,1)+suffix
(W/'scripts'/runner).write_text(primary)
rows.append(dict(kind='primary',source_path=str(helper),source_sha256=sha(helper.read_bytes()),
                 preserved_source='evidence/detector_scattering_projection/check_projection_algebra.py.gz',
                 edits=[dict(before=anchor,after=addition,reason='Declare exact input paths and timeout; preserve all original finite calculations.')],
                 appended_text=suffix,publication_path='scripts/'+runner,publication_sha256=sha(primary.encode())))
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(dict(outputs=rows),indent=2)+'\n')
texts={
'STATE.yaml':'''loop: toe-detector-scattering-projection-20261012
mode: milestone_snapshot
delivery: milestone
active_branch: physics-loop/toe-compact-patch-scattering-20261011
base_revision: 296155eda2ca6a5ab6ae6307190362b9a84ea690
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
milestone: selected_scattering_projection_from_admissible_detectors
provisional_dependencies: supplied_microscopic_creators_Fock_and_PC_conditions
independent_check: complete_separate_P1_P33_reconstruction
pr: 9486
pr_status: preparing_regular_PR_extension
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md':'''# Exact contract

Construct a countable admissible positive-detector family whose support equals
the existing selected scattering projection in every narrow energy window.
Prove its ordered-limit formula and a conditional finite-time lower witness.
Do not assume or assert exhaustion of the full physical Hilbert space.
''',
'ASSUMPTIONS_AND_IMPORTS.md':'''# Actual proof inputs

The complete compact-creator, Fock and PC notes in this same PR are the three
inputs. Microscopic H/current implementations, isolated selected mass/centre
components, unique gapped vacuum and the stated direct creator hypotheses
remain supplied. The fixed F2 outgoing range is closed and H-reducing.
PC is used with exact full operator carriers, convex velocity separation,
positive temporal transfer and the energy-only vacuum remainder.
The detector family is chosen existentially within this fixed sector.
''',
'APPROACH_REGISTRY.md':'''# Complete derivation

Finite smooth amplitude partitions and temporal/geometric operator filters
preserve each one-particle vector exactly. Fock Gram identities preserve
the entire scattering product. Whole-product energy compression, a retained
sum energy and the narrow-window gap yield admissible vacuum remainders.
The resulting ranges span exactly the selected energy-window scattering space.
Separability selects countably many ranges. Positive norm-summable weights
identify their common kernel and spectral support. Resolvent identities and
spectral dominated convergence give the ordered time/family/eta limits.
PC's uniform complement remainder plus positivity gives the square-root
finite-time error and the one-sided lower witness.
''',
'ROUTE_PORTFOLIO.md':'''# Evidence roles

The complete analytic proof is P1-P33. A fresh same-family context reconstructed
it and wrote an exact rational support/resolvent control before opening new
author evidence. The original helper was subsequently reproduced exactly.
Root supplied mechanisms and is a coauthor. Source identity is provenance,
not a proof. Finite fixtures do not establish infinite-dimensional convergence.
''',
'OPPORTUNITY_QUEUE.md':'''# Remaining research

Check the index-to-selected-complement estimates and construct admissible
channels beyond a common rational centre selection. Derive precise conditions
identifying the integrated current with the microscopic flow. No ND, physical
realization or full-GNS exhaustion follows from selected support equality.
''',
'NO_GO_LEDGER.md':'''# Scoped failed shortcuts

Whole-product energy compression does not factor into single-particle masks.
Vacuum support does not give full operator support. Disjoint velocity sets may
have overlapping convex hulls. Arbitrary detector menus may miss selected
directions. Positive support need not have a lower frame bound. Uncontrolled
joint time/resolvent limits fail. After time convergence, positive partial
supports can make some other iterated orders valid; the author's earlier
unfrozen blanket objection was corrected and preserved in its operation record.
These are algebraic/proof-boundary examples, not physical no-go models.
''',
'LITERATURE_BRIDGES.md':'''# Comparator and exact reading limits

Dybalski-Gerard arXiv:1308.5187v1, Theorem2.9 and Section7, is a comparator
for detector-range spanning. Its relativistic/global-shell assumptions and
joint energy-momentum admissibility are not imported. Lemma7.5 refers its
proof elsewhere; that proof was not read or used. The reviewer read fresh
extractions of full PDFpages4-9 and20-22; the author read6-9 and20-22.
Root read the complete new proof and review but did not newly certify all
of DG Section7. The source supplies no mathematical lemma needed here.
Exact PDF64ab1ee60602583c8491fb012f064102e9cda45dcd319288184d1f42349f2793
and page identities remain in EVIDENCE_MAP.json. Complete third-party texts
stay external. Upstream primary proofs are reused at their checked scope.
''',
'ARTIFACT_PLAN.md':'''# Coherent regular PR extension

Extend regular PR9486 with the complete projection note, finite primary,
canonical cache and source-bound evidence packet. Preserve all older SC,
Fock, E and PC sources and evidence. No draft, duplicate PR, merge, main push,
applied audit verdict, physical axiom edit or editable-prompt change.
''',
'TRACE_GATE.md':'''# Selected projection obligation

```yaml
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Construct a rich countable admissible detector family resolving the selected scattering projection."
source_of_blocker_text: source_derivation
source_location: "ROOT_DETECTOR_SUPPORT_PROJECTION_LEAD.md and the complete P1-P33 source."
next_trace_action: "Determine justified enlarged channels and microscopic implementations; do not infer ND."
```
''',
'CLAIM_STATUS_CERTIFICATE.md':'''# Conditional source-checked theorem

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
independent_review_status: "Complete separate P1-P33 reconstruction; no required mathematical correction."
audit_required_before_effective_retained: true
bare_retained_allowed: false
```

No formal retained status, applied audit verdict, Lean certificate or physical
realization is conferred by the focused source check.
''',
'REVIEW_HISTORY.md':'''# Separate complete source review

Target91c561d9d24d27bd4c5be26f0f688553d3d690df51766c9f6de5ec70f3ed38b4;
reviewd9ab71d88615c78cb49eda7cc85ff263d65c12be6cc6e019314cd96eb42a20a2;
receipt1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b.
Reconstruction7d5461a55498e9958e267aea18d2af21157108c9670dc303b5ae6db80dbd3146
and distinct exact-rational control were frozen01:55:53UTC, before author
evidence. Every P1-P33 argument and necessary predecessor proof was read.
Root independently read the complete author proof and separate reconstruction,
all code, outputs and failed variants; root is a coauthor.122review outputs,
7source pairs,7instruction pairs and10prefreeze bindings matched. Earlier
56file+1Git author coverage is preserved. Counts do not establish correctness.

No required theorem correction was found. The witness sweep's nondiscrimination
of a linear-error substitution remains explicit. The separately checked scalar
Q=(1/16)E discriminates that universal wrong formula and is included in the
publication primary. Original helper calculations and all failures remain
unchanged; publication edits are only metadata, recovery and review evidence.
''',
'HANDOFF.md':'''# Projection milestone snapshot

Regular PR9486 extension from296155eda2ca6a5ab6ae6307190362b9a84ea690.
The theorem identifies the selected scattering projection with the support
of an existentially chosen countable positive-detector family. It gives ordered
strong limits and a conditional finite-time lower witness. ND, EX, numerical
constants, effective enumeration and physical realization remain unproved.
PUBLICATION_EDITS.json plus reconstruct.py preserve the complete source.
The sole live campaign checkpoint remains in the transport worktree.
Fixed deadline2026-10-12 16:00:52UTC. No new research afterward; preserve work,
report limits and disable heartbeat. No main push, science merge or audit verdict.
''',
'PR_BACKLOG.md':'''# Regular milestone delivery

Publish this source-reviewed projection result with canonical control, actual
whole-primary defects, exact maps, citation acknowledgment and scoped audit
compatibility. The separate index-leakage, arbitrary-centre and implementation
derivations are not silently added as accepted premises.
'''
}
for n,t in texts.items():(P/n).write_text(t)
paths=[S/n for n in ['DETECTOR_SCATTERING_PROJECTION_PROBE.md','DETECTOR_SCATTERING_PROJECTION_REVIEW.md',
       'Projection_root_author_coverage.json','Projection_root_review_coverage.json','root_verify_projection_and_leakage.py',
       'ROOT_DETECTOR_SUPPORT_PROJECTION_LEAD.md']]
for folder in ['detector_scattering_projection','detector_projection_review']:
    paths += [p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
own=[];external=[]
for p in sorted(set(paths)):
    b=p.read_bytes();rel=str(p.relative_to(S));r=dict(original=str(p),bytes=len(b),sha256=sha(b))
    if p.suffix.lower() in ['.pdf','.png','.jpg'] or any(x.endswith(('_pages','_images')) for x in p.parts):
        external.append(dict(**r,primary_url='https://arxiv.org/abs/1308.5187v1',recovery='Exact primary source remains external; not redistributed.'))
    else:
        dst=P/'evidence'/(rel+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(gzip.compress(b,mtime=0));own.append(dict(**r,preserved=str(dst.relative_to(P))))
(P/'EVIDENCE_MAP.json').write_text(json.dumps(dict(scope='Full own/repository evidence; third-party primary texts remain external.',files=own,external_reference_sources=external),indent=2)+'\n')
recon=(W/'.claude/science/physics-loops/toe-compact-patch-fock-20261012/reconstruct.py').read_text()
recon=recon.replace('Complete Fock note and primary reconstruct exactly from frozen sources and explicit edits','Complete projection note and entire finite primary reconstruct exactly from frozen sources and explicit edits')
(P/'reconstruct.py').write_text(recon)
print(json.dumps(dict(artifacts=[{k:r[k] for k in ['kind','publication_path','publication_sha256']} for r in rows],documents=len(texts),own_files=len(own),external_primary_bindings=len(external)),indent=2))
