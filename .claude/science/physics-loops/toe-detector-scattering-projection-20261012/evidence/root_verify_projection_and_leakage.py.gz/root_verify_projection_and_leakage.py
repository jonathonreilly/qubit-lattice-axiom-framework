"""Root provenance and finite-evidence verification after complete proof reads."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, subprocess

S=Path(__file__).resolve().parent
W=S.parent/'scattering_worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(row):
    p=Path(row['path'])
    b=p.read_bytes()
    assert sha(b)==row['sha256'],p
    if 'bytes' in row: assert len(b)==row['bytes'],p
def js(path):return json.loads(path.read_text())

R=S/'detector_projection_review'
r=js(R/'receipt.json')
assert sha((R/'receipt.json').read_bytes())=='1fed9654096e0c67535640f60c1f1c318ac313c1436d84a21c4544b744f6ce3b'
for row in r['outputs']+r['source_read_coverage']: check(row)
for row in r['instruction_sources']:
    b=subprocess.check_output(['git','show',row['git_source']],cwd=W)
    assert sha(b)==row['sha256'] and len(b)==row['bytes']
    assert Path(row['snapshot']).read_bytes()==b
f=js(R/'precontrol_freeze.json')
for row in f['files']+f['source_identities']:check(row)
source=(S/'detector_scattering_projection/check_projection_algebra.py').read_text()
base=(S/'detector_scattering_projection/projection_algebra.stdout').read_bytes()
assert (R/'logs/author_reproduction.stdout').read_bytes()==base
assert (R/'logs/author_reproduction.stderr').read_bytes()==b''
spec=next(ast.literal_eval(n.value) for n in ast.parse((R/'assess_author_controls.py').read_text()).body
          if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutations' for t in n.targets))
for name,before,after,fail in spec:
    p=R/'post_author_mutations'/name
    assert source.count(before)==1 and p.with_suffix('.py').read_text()==source.replace(before,after)
    out=p.with_suffix('.stdout').read_bytes();err=p.with_suffix('.stderr').read_text()
    e=js(p.with_suffix('.execution.json'))
    assert sha(p.with_suffix('.py').read_bytes())==e['source_sha256']
    assert sha(out)==e['stdout_sha256'] and sha(err.encode())==e['stderr_sha256']
    assert base.startswith(out)
    if fail: assert e['returncode']==1 and 'AssertionError' in err
    else: assert e['returncode']==0 and out==base and err==''
coverage=dict(utc=datetime.now(timezone.utc).isoformat(),review_accepted=True,
    target_sha256=r['target']['sha256'],report_sha256=r['report']['sha256'],
    receipt_sha256=sha((R/'receipt.json').read_bytes()),review_output_bindings=len(r['outputs']),
    source_pairs=len(r['source_read_coverage']),instruction_pairs=len(r['instruction_sources']),
    pre_author_bindings=len(f['files'])+len(f['source_identities']),
    full_author_reproduction_exact=True,post_author_defect_failures=6,
    deliberate_nondiscriminating_mutation='witness_linear_error passes the limited rank-one sweep; exact scalar Q=(1/16)E rejects the universal wrong formula',
    read_scope=['Complete 330-line frozen author proof and code previously recorded in Projection_root_author_coverage.json',
                'Complete review, pre-author reconstruction, exact rational independent control and all four records',
                'Complete author-evidence assessment, post-author mutation script, all full failure traces, unchanged stdout prefixes',
                'Operational record, primary comparator scope and all literal mutations; original full helper remains unchanged'],
    limits=['Root is coauthor, not the independent reviewer','Root has not newly read all DG Section7; reviewer reading limits are explicit and DG supplies no lemma',
            'No Lean, ND, EX, physical realization, effective enumeration, controlled numerical constants or retained verdict'])
(S/'Projection_root_review_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')

L=S/'detector_index_leakage'
l=js(L/'freeze_receipt.json')
assert sha((L/'freeze_receipt.json').read_bytes())=='47bf0db5e653961b622953a77d26f345515e8f87fe583c6ce66c8951c0f6a498'
for row in l['files']:check(row)
sources=js(L/'logs/final_identity_check.json')['source_rows']
for row in sources:
    ref=row['source']
    b=Path(ref).read_bytes() if ref.startswith('/') else subprocess.check_output(['git','show',ref],cwd=W)
    assert sha(b)==row['sha256']==row['current_source_sha256']
    assert (L/row['copy']).read_bytes()==b
records=js(L/'logs/execution_records.json')
source=(L/'check_leakage_controls.py').read_text()
base=(L/'logs/baseline.stdout.txt').read_bytes()
for rec in records:
    p=Path(rec['command'][-1])
    assert sha(p.read_bytes())==rec['source_sha256']
    out=(L/rec['stdout']).read_bytes();err=(L/rec['stderr']).read_text()
    if 'mutation' in rec:
        m=rec['mutation'];assert source.count(m['old'])==1
        assert p.read_text()==source.replace(m['old'],m['new'])
        assert rec['exit_code']==1 and 'AssertionError' in err and base.startswith(out)
    else:assert rec['exit_code']==0 and not err and out==base
lc=dict(utc=datetime.now(timezone.utc).isoformat(),author_bindings=len(l['files']),source_pairs=len(sources),
    note_sha256=l['note']['sha256'],receipt_sha256=sha((L/'freeze_receipt.json').read_bytes()),
    read_scope=['Complete 405-line frozen argument, all L1-L27 equations and N1-N8 scope checks',
                'Complete 211-line helper, all 12 baseline records, full six assertion tracebacks and exact mutation changes',
                'Source ledger, checkpoint and structured execution/source identity evidence'],
    controls_reexecuted_by_root=False,source_reviews_complete=False,
    limits=['Root proposed mechanism and is coauthor; fresh independent review active',
            'Finite controls do not prove the infinite-algebra theorem or construct the hypothesized physical model',
            'Large raw metadata display truncated; all relevant execution fields were subsequently read in compact form and every binding verified'])
(S/'Leakage_root_author_coverage.json').write_text(json.dumps(lc,indent=2)+'\n')
print(json.dumps({'projection':coverage,'leakage':lc},indent=2))
