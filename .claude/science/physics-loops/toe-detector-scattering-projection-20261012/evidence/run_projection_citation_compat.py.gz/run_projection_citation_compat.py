"""Acknowledge actual citation additions and inspect scoped audit compatibility."""
from pathlib import Path
import json,subprocess,sys,time
S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
records={}
for name,cmd in [('build',[sys.executable,'docs/audit/scripts/run_citation_graph_build.py']),
                 ('manifest',[sys.executable,'docs/audit/scripts/write_citation_graph_manifest.py'])]:
    start=time.monotonic();r=subprocess.run(cmd,cwd=W,capture_output=True,timeout=180)
    (S/('projection_citation_'+name+'.stdout')).write_bytes(r.stdout)
    (S/('projection_citation_'+name+'.stderr')).write_bytes(r.stderr)
    records[name]=dict(command=cmd,timeout_seconds=180,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
    assert r.returncode==0,(name,r.stderr.decode())
(S/'projection_citation_execution.json').write_text(json.dumps(records,indent=2)+'\n')
cmd=[sys.executable,'docs/audit/scripts/check_changed_audit_evidence.py','--base','296155eda2ca6a5ab6ae6307190362b9a84ea690','--include-worktree','--json']
start=time.monotonic();r=subprocess.run(cmd,cwd=W,capture_output=True,timeout=120)
(S/'projection_focused_audit_compat.json').write_bytes(r.stdout)
(S/'projection_focused_audit_compat.stderr').write_bytes(r.stderr)
rec=dict(command=cmd,timeout_seconds=120,elapsed_seconds=time.monotonic()-start,exit_code=r.returncode)
(S/'projection_focused_audit_compat.execution.json').write_text(json.dumps(rec,indent=2)+'\n');assert r.returncode==0,r.stderr.decode()
print(json.dumps(dict(citation=records,compatibility=rec)))
