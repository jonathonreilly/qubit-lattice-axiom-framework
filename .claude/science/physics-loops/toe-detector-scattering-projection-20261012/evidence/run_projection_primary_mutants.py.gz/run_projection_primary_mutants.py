"""Actual complete-primary defects; preserve the known passing toy limitation."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,subprocess,sys,time

S=Path(__file__).resolve().parent;W=S.parent/'scattering_worktree'
primary=W/'scripts/detector_scattering_projection_2026_10_12.py'
base=primary.read_text();sha=lambda b:hashlib.sha256(b).hexdigest()
source=ast.parse((S/'detector_projection_review/assess_author_controls.py').read_text())
spec=next(ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutations' for t in n.targets))
spec.append(('scalar_linear_error','_scalar_error = F(1, 4)','_scalar_error = F(1, 16)',True))
D=S/'projection_primary_mutations';D.mkdir(exist_ok=False)
baseline=json.loads((S/'projection_canonical_execution.json').read_text())['stdout'].encode()
runs=[]
for name,before,after,fail in spec:
    assert base.count(before)==1
    p=D/(name+'.py');p.write_text(base.replace(before,after,1))
    start=time.monotonic();utc=datetime.now(timezone.utc).isoformat()
    result=subprocess.run([sys.executable,str(p)],cwd=W,capture_output=True,timeout=60)
    (D/(name+'.stdout')).write_bytes(result.stdout);(D/(name+'.stderr')).write_bytes(result.stderr)
    assert (result.returncode!=0)==fail
    assert baseline.startswith(result.stdout)
    if fail:assert result.returncode==1 and b'AssertionError' in result.stderr
    else:assert result.returncode==0 and not result.stderr and result.stdout==baseline
    r=dict(name=name,primary_path=str(primary.relative_to(W)),primary_sha256=sha(base.encode()),
           before=before,after=after,source_sha256=sha(p.read_bytes()),command=[sys.executable,str(p)],cwd=str(W),
           started_utc=utc,timeout_seconds=60,elapsed_seconds=time.monotonic()-start,exit_code=result.returncode,
           expected_failure=fail,stdout_baseline_prefix=True,stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr))
    (D/(name+'.execution.json')).write_text(json.dumps(r,indent=2)+'\n');runs.append(r)
(D/'manifest.json').write_text(json.dumps(dict(scope='Actual full-primary controls; seven intended assertion failures and one known passing rank-one-family limitation.',runs=runs),indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['name','exit_code','expected_failure','elapsed_seconds']} for r in runs],indent=2))
