# Current opportunity queue

1. Finish exact response/pulse assembly review, prepare the two-note source package with already checked BV averaged-readout transfer, and publish a regular PR on PR9502.
2. Complete near-ground correlation comparison and independent all-BV pulse-work proof/check.
3. Independently check the new native whole-even-algebra route at fixed physical interval lengths; it may close the expression-resource limitation of native spatial bounds.
4. Independently check preparation-error propagation through a finite pulse and the weak-source/preparation joint limit.
5. Assemble a coherent spatial milestone from checked native/continuum clustering, local-ground stability, and near-ground limits, including the whole-algebra extension only if checked.
6. Then consolidate the generalized finite-energy/BV/pulse-preparation results. Use corrected cells where their rate improves a downstream quantity.

Regular PR9499,9500,9502 remain open and attached. No child response PR yet. Main516cb69d and distinct PR9501 unchanged at21:17:52. Every candidate retains its exact unreviewed status until checked; total-norm bounded interactions, prescribed states/sources and representation remain physical inputs. Extensive interactions, channel selection and intended3D realization stay open.
