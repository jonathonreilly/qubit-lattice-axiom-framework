# Independent review of the local-qubit nonlinear composition

**Date:** 2026-10-11. **Disposition:** no consequential defect found in the positive conditional claims of the frozen publication source below. This is a source-bound research review, not a formal audit verdict or retained-status decision.

The earlier global-capacity composition remains valid. The stopped-capacity refinement supports the smaller sufficient ceilings \(m^3S^3=O(\delta^{-123/2})\) and \(\nu=O(\delta^{-429/2}[1+\log(1/\delta)])\). The refinement is an error-event transfer; it does not provide a global favorable-state total-variation bound for arbitrary target paths. The finite ideal quantum count-measurement law is correctly distinguished from the associated classical full-path law.

I authored the inherited nonlinear particle theorem. I do **not** count my use of that theorem as an independent review of its PDE/particle proof. The separate particle review is inherited evidence. Independence here consists of reconstructing the different authors' geometry, mixing, averaging, capacity composition and quantum-instrument arguments, and performing separately implemented controls.

## 1. Frozen sources and reading coverage

Paths are relative to this report's directory.

| Source | SHA-256 | Coverage |
|---|---|---|
| [NATIVE_REALIZATION_PROBE.md](NATIVE_REALIZATION_PROBE.md) | aa85c3269178565c98daed6716dbf0b0c5bce7aab72658b46165e64183ee992a | All 758 lines. Positive construction, geometry and path proofs reconstructed. Broader negative probes excluded from this disposition. |
| [EXCLUSION_MIXING_PROBE.md](EXCLUSION_MIXING_PROBE.md) | 9b42ba8f2e5f222d6d5ae5db15e58bec70c1cd20f3987bd6da5943bbed469804 | All 393 lines; variance, routing, integrated product distance and BFS refinement reconstructed. |
| [LOCAL_QUBIT_NONLINEAR_COMPOSITION_DRAFT.md](LOCAL_QUBIT_NONLINEAR_COMPOSITION_DRAFT.md) | 41746837456a3ec325bdce904b802afa966a71af538b080ae7c8b95d2eaa7e4e | All 119 lines; original global-capacity composition and resource exponents. |
| [LOCAL_QUBIT_STOPPED_CAPACITY_REFINEMENT.md](LOCAL_QUBIT_STOPPED_CAPACITY_REFINEMENT.md) | f28c729a079799286d626a6d8b427d4869ee6639e262fbda0264ca896cd5859c | All 114 lines; stopping, both directional deficits and sharper constants. |
| [FINAL_QUBIT_PORT_NOTE.md](FINAL_QUBIT_PORT_NOTE.md) | 5d7fbfe0d0603e52c80de047f3ea91bff46b01d3a24b40ba2f796d49c0c3d3ad | All 889 lines. Exact inverse replacement of the sole final wording change “including inert qubit factors” recovers the fully read mathematical version d203b096d57a2331d6f14db21d9541230bf9970aa88523579c5f981b6c63687d. |
| [root_qubit_port_primary.py](root_qubit_port_primary.py) | 0a655a71047cae8fde331eba758ad91da08cc7f5cbaddac4b2335196a9f38f2a | All 548 lines read; final bytes replayed successfully. |
| [FINAL_NONLINEAR_PARTICLE_NOTE.md](FINAL_NONLINEAR_PARTICLE_NOTE.md) | ab42c1e6377e360739d01ac9f37f56f98b087997649ebec45be59ea07e23fc90 | Complete inherited theorem previously read/written; preparation, stopping and simultaneous scale contract matched. Worktree publication copy has identical bytes. |
| [NONLINEAR_PARTICLE_REVIEW.md](NONLINEAR_PARTICLE_REVIEW.md) | 4aec121de3df2c52d8d913e253a0aa35c04b26a44d630264752dae6945eb400a | Complete separate review previously read; not a second proof by this reviewer. |
| [native_probe/publication_composition_review.md](native_probe/publication_composition_review.md) | f0d4b25cfac7ccc4d422b4c57da187bd641a9ee07b9216efcd5a327f24ebd183 | Complete author packaging/composition report read; not used as proof authority. |
| [native_probe/publication_receipt.json](native_probe/publication_receipt.json) | 505b507f6a8c7008d32f1cb1566324fe52bb06c6e20a5c6bada67cfdc4c9da5b | Source identity fields checked; no claim to new full reading of every historical source listed there. |
| [native_probe/publication_mutation_results.json](native_probe/publication_mutation_results.json) | 9f4f3d4714a2b825d230d1cecbadfe323e75860cc95b23e1d244617561f1a483 | All 24 actual source differences inspected; hashes and complete stored execution/failure logs checked programmatically. Mutants not redundantly rerun. |

The intended final destinations are docs/LOCAL_QUBIT_PORT_REALIZATION_WITH_POLYNOMIAL_MIXING_BOUNDED_THEOREM_NOTE_2026-10-11.md and scripts/local_qubit_port_realization_polynomial_mixing_2026_10_11.py.

The spatial quantum parent retains hash f02fe7fae147bf5aedac035334ab8a34ac89deb3220c9381918e58e30711fff2. Its labelled-register realization is background; the new note proves the port and partial-permutation identities actually used. Searches at frozen main a13caa4885f547c8d206265b031ba7649e539fd9 are historical campaign evidence, not an exhaustive literature novelty search by this reviewer.

At final refresh, worktree HEAD was 3fbaa00e9d97a19459d197fd0de2d62d45327e90 and local main was e485eab6b09b3957df5772104d3ea3980108d7fa. Current AGENTS.md and docs/ai_methodology/SCIENCE_WORKFLOW.md retained their read hashes f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f and 05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce. The physics-claim-reviewer skill and proof-search-governance reference were read and matched the selected-main copies. No audit-loop process was invoked.

## 2. Geometry and quantum-generator reconstruction

Independent enumeration through four-element subsets, rather than the author's equal-invariant pair fibers, gives 288 reactions and nine axial exchanges. A shared input/output cancels by momentum and leaves a trivial exchange. A repeated input has strictly larger output energy unless the exchange is trivial. Thus every retained exchange uses four distinct species.

The last plaquette has largest x-coordinate 1151 and fits at S=1152. The height planes, y=0/5 backbones, x=0 stem, y=2/3 columns and y>=6 padding have the claimed disjointness. At a column coordinate only its assigned species has a horizontal connector. Thus extending one such column to full height creates no crossing with another compartment. Every padding prefix connects to its row and the stem.

Counting gives
\[
 K_v^0=(3S-2)+d_v(h_v+2)+(S-h_v-1)
      =4S+d_v(v+3)-v-4.
\]
The independently obtained offsets range from 104 to 1259. The geometry interval (G3) is correct. For \(K=\lfloor S^2/2\rfloor\), its lower inequality follows from \((S^2-1)/2\ge4S+1259\) at and above 1152; its upper inequality follows from \(S^2/2\le S^2-3S+110\). These estimates include odd S.

Signed translation of each lower/upper face port by \(\operatorname{sign}(v_d)S e_d\) gives one microscopic edge, including across the periodic seam. The collision arity is four and Manhattan diameter two. The proof does not silently make a four-site collision into a two-site operation.

Actual routes give stem/backbone/connector length <=S+6, column addition <=S-2, and padding route x+y<=2S-2. The BFS radius <=2S+5 and diameter <=4S+10 are therefore safe. No global mixing edge replaces spatial motion.

The physical carrier has \((mS)^3\) full qubit factors. Only active compartments enter \(\mathsf N,\mathsf P,\mathsf E\). The final support condition
\[
 (\Pi_N^{\rm active}\otimes I_{\rm inert})\rho
 (\Pi_N^{\rm active}\otimes I_{\rm inert})=\rho
\]
is correct; inert factors can have arbitrary occupations and correlations.

Each jump is an injective partial permutation of the occupation basis. Its adjoint maps diagonal observables to
\[
 \mathcal D[J]^*D_f(\eta)
 =1_{\eta\in\operatorname{dom}\sigma}
    [f(\sigma\eta)-f(\eta)].
\]
Here \(J^\dagger J\) is diagonal, and injectivity eliminates diagonal gain from off-diagonal inputs. Hence arbitrary-coherence population closure holds for the **summed GKSL generator**. This is not a full-channel dephasing or classical-channel assertion.

Fast exclusion on each connected tree is symmetric and irreducible within a count fiber. Conditioning on the complete count vector gives a product of uniform compartment laws, even with fixed global number. Named-port occupancies yield exactly (R), with K and \(K^2\) compensating one and two occupied-port probabilities. A reversible partial-swap collision is one mark with at most one enabled direction at a bit state, so
\[
 B_K=\frac{54Kb}{w\ell}+\frac{cK^2K_\Sigma}{Nw^2}.
\]
There is no extra factor two. Finite-\(\nu\) projected counts are generally non-Markov, as the note states.

## 3. Mixing and full-path averaging

The complete-graph induction is consistent with rate-one unordered edges. Conditional variance gives internal coefficient \(2/(K-1)\). If \(p=n/K\), the cross-edge form is \(p(K-n)\mathbb E[(f_{\rm out}-f_{\rm in})^2]\), and Jensen supplies \(Kp(1-p)(\mu_1-\mu_0)^2\). Averaging over coordinates gives
\[
 \frac{2(K-2)}{K(K-1)}+\frac{2}{K^2}
 =\frac2K\left(1-\frac1{K(K-1)}\right)\le\frac2K.
\]
The K=2 base case and singleton fibers satisfy the same conventions.

The forward-and-return tree word restores every interior label and implements the endpoint transposition. Cauchy-Schwarz uses length \(2d-1\); each partial word preserves uniform fiber measure. Edge congestion is at most \(2(2K-3)a_e(K-a_e)\), giving
\[
 \operatorname{Var}_\pi f
 \le\frac{4(2K-3)\lfloor K^2/4\rfloor}{K}\mathcal E_T(f,f)
 \le K(2K-3)\mathcal E_T(f,f).
\]
The actual diameter supplies \(c_{K,S}=\min\{K(2K-3),K(8S+19)\}\). No optimal interchange-process gap is imported.

The initial L2 density norm is \(\sqrt{\binom Kn-1}\). This proves the TV prefactor 1/2 in (M8). Product TV is at most the sum of component distances, capped at one. Integrating \(\min(1,H e^{-t/c})\) gives \(cg(H)\), including H<=1; this is an integral of worst-case distances, not a norm taken after integration.

For K>=max(N,2), N>=1, the quantities \(D_N=\min(D,N)\) and \(n_*=\min(N,\lfloor K/2\rfloor)\) are >=1. They correctly bound the number of nontrivial factors and their binomial sizes. Thus
\[
 \tau\le c_{K,S}
 \left[1+\log D_N+\frac{n_*}{2}\log(eK/n_*)\right]
\]
has the asserted domain. Empty/full fibers are singletons. Conditioning on initial configurations handles arbitrary starting laws.

The common proposal-clock construction preserves both marginals: conditional on the joint past and proposal gap, maximal coupling pairs the correct real fast endpoint with a uniform reference fiber draw. On success a common \(P_B\) transition preserves count agreement. Fast moves do not alter counts, so success gives full-path agreement between proposals as well.

An independent derivation of the renewal kernel conditions on \(N_T=n\) Poisson proposals. Each of the first n spacings has density \(n(1-u/T)^{n-1}/T\). Summing their n contributions against \(e^{-BT}(BT)^n/n!\) yields
\[
 B e^{-Bu}[1+B(T-u)].
\]
This includes the first unequilibrated gap and proves \(\tau B_K(1+TB_K)/\nu\). The independent exact coefficient control below fails if the first-gap term is omitted. Initial fiber equilibration is not assumed.

## 4. Capacity, initialization and stopping

For m>=3 a directed cycle does not duplicate an unordered edge. Thus \(\sum_xn_{x,v}n_{x+s e_d,v}\le N_v^2/2\), giving the global hop deficit \(3bN^2/(2\ell K)\). For one reaction,
\[
 ab(c+d)+cd(a+b)
 \le (a+b)(c+d)(a+b+c+d)/4\le N_x^3/16.
\]
Both directional deficits therefore give the uniform C_cap in (F), with exactly \(\Omega=Nw\).

The finite resource choice works for all \(\epsilon>0\), N>=1, m>=3 and finite T>=0. In particular,
\[
 S\ge\sqrt{2(K_{\rm req}+1)}
 \ \Longrightarrow\ \lfloor S^2/2\rfloor\ge K_{\rm req}+1\ge K_{\rm req}.
\]
The maxima with 1152 and 2 enforce the geometry and logarithm domains. T=0 and epsilon>1 require no hidden exception. Both new error allocations are <=epsilon/2; a probability bound can be capped at one.

The nonlinear composition uses the parent's same N, m, \(\ell=2\pi/m\), normalized w, b, c, tuned reaction coefficients and horizon L. Its initial multinomial probabilities are exactly
\[
 p_{zv}=wM_v[1+\delta(S_mP_mU(0))_{zv}].
\]
The parent's positivity and zero-mode conditions give nonnegativity and exact normalization. No additional conditioning on momentum or energy is performed. K>=N realizes every count outcome, and arbitrary within-fiber populations/coherences require no unmentioned mixing preparation.

For the parent's stopping time \(\tau_*\), including initial exit and stopping-jump overshoot, \(n_{zv}\le2NwM_v\) strictly before exit. The independent product-weight calculation gives
\[
 \sum_{v,d}|v_d|M_v^2=1/24.
\]
There is one inverse w from summing cells, so the stopped hop deficit is \(bN^2w/(6\ell K)\).

For each reaction in one cell, both directions give
\[
 \frac{c\kappa_r}{NwK}
 [n_i n_j(n_k+n_l)+n_k n_l(n_i+n_j)]
 \le\frac{8c\kappa_rN^2w^2}{K}
 p_r(M_i+M_j+M_k+M_l).
\]
Summing cells yields
\[
 C_{\rm local}=N^2w[b/(6\ell)+8cT_4],\qquad
 T_4=\frac{4417}{69984}+\frac{11}{2187}\alpha_*.
\]
The exact T4 coefficients were independently regenerated. The separate nonuniform envelope-state control rejects an erroneous extra factor w.

Until the first capacity discrepancy and \(\tau_*\), G and \(G_K\) agree. The stopped compensator intensity is bounded by \(C_{\rm local}/K\). For the norm-error event \(\mathcal B\),
\[
 \Pr_{G_K}(\mathcal B)
 \le\Pr_G(\tau_*\le L)+LC_{\rm local}/K.
\]
Exit is charged once. A discrepancy at an exiting target jump is covered; the intensity estimate uses the predictable pre-jump state. If \(\tau_*=0\), the target-exit term already applies.

The **global** fast-averaging comparison is then added:
\[
 \Pr_{\rm actual}(\mathcal B)
 \le C_{\rm prob}\delta^2+LC_{\rm local}/K
       +\tau B_K(1+LB_K)/\nu.
\]
It does not assume the microscopic process stays in the favorable region. The selected capacity and fast rate allocate <=delta squared/2 to each new term. Hence the final norm error is \(C_{\rm path}\delta\) with failure <=\(\min(1,(C_{\rm prob}+1)\delta^2)\). Substituting the favorable-state deficit into the global arbitrary-path TV theorem would be invalid; the final note avoids that substitution.

The event is measurable on finite-state cadlag count paths: continuity of the fluid comparison lets the supremum be taken over a dense countable time set plus the endpoint. Every fixed finite set of readout times is controlled by this same event.

## 5. Resource arithmetic

“Pole p” below denotes a delta-independent constant times \(\delta^{-p}\), with logarithms shown separately.

| Quantity | Original global-capacity route | Stopped-capacity route |
|---|---:|---:|
| Defect numerator C | 46; hop 41, collision 46 | 35; hop 35, collision 34 |
| Required K | 48 | 37 |
| S | 24 | 37/2 |
| Total physical sites | 78 | 123/2 |
| Active sites and fast-mark count | 54 | 43 |
| Hop part of B | 57 | 46 |
| Collision part of B | 91 | 69 |
| BFS Poincare constant | 72 | 111/2 |
| Integrated mixing, one logarithm | 91 | 149/2 |
| Fast rate, one logarithm | 275 | 429/2 |
| Individual streaming rate | 51 | 40 |
| Individual collision rate | 85 | 63 |
| Log coefficient in explicit ceiling | 54 | 43 |

For the improved route, \(N\le2\delta^{-19}\), \(w\le(2\pi)^{-3}\delta^6\), and \(\ell>c_\ell\delta^2\) give the two C_local poles 35 and 34. The max/ceiling bounds give \(K_{\rm req}\le C_{\rm req}\delta^{-37}\) and \(S\le C_S\delta^{-37/2}\). Since the collision contribution to B contains 1/N, its bound correctly uses the **lower** bound \(N\ge\delta^{-19}\), yielding pole 69.

For entropy,
\[
 1+\log D_N+\frac{n_*}{2}\log(eK/n_*)
 \le\delta^{-19}[2+\log D_0+\log C_K+43\log(1/\delta)].
\]
Indeed \(\log(eK/n_*)\le1+\log C_K+37\log(1/\delta)\); enlarging the remaining nonnegative term by delta to the minus 19 adds the other six logarithmic powers. Combining poles 111/2, 19, twice 69, and 2 gives 429/2. Constants (H12)–(H15) work on all \(0<\delta\le1\), subject to the parent's separate smallness conditions. The original construction similarly gives 78 sites and 275 fast-rate poles and remains a valid fallback.

These are sufficient constructive ceilings, not optimality claims. No bounded-strength limit or fixed physical microscopic spacing at fixed torus volume is established.

## 6. Finite repeated quantum count measurements

For the active diagonal after tracing inert factors,
\[
 \operatorname{Diag}_{\rm act}(e^{t\mathcal L}\rho)
 =e^{tQ}\operatorname{Diag}_{\rm act}\rho,\qquad
 \operatorname{Diag}_{\rm act}(\Pi_n\rho\Pi_n)
 =1_{\mathrm{count}=n}\operatorname{Diag}_{\rm act}\rho.
\]
Q is the forward bit-population generator. Both identities are linear for unnormalized states; the projector acts as identity on inert factors. Induction therefore proves the exact joint law for any fixed finite ordered sequence of supplied ideal count instruments, including coherent input and correlated inert factors. Degenerate count projection retains possible within-fiber coherence. It never causes a uniform redraw.

The independent exact control uses the one-excitation sector of a three-site path with two symmetric partial swaps, distinct from the author's floating four-active-qubit example. With \(q=e^{-t/2}\), \(v_1=(1,0,-1)\), \(v_3=(1,-2,1)\),
\[
 P(q)=\mathbf1\mathbf1^T/3+q^2v_1v_1^T/2+q^6v_3v_3^T/6.
\]
Adjacent coherences evolve with coefficients \((q+q^5)/2\), \((q-q^5)/2\); endpoint coherence is multiplied by \(q^2\). Exact generator and semigroup identities were verified on nine matrix units, which span the complex algebra by complex linearity. For \(aa^T/14\), \(a=(1,2,3)\), and degenerate partition \(\{0,1\},\{2\}\), all eight three-time quantum histories match exact classical filtering probabilities and sum to one.

A noninjective control jump \(J=|0\rangle\langle1|+|0\rangle\langle2|\) feeds \(E_{12}\) into diagonal \((1,-1/2,-1/2)\). This demonstrates the injectivity premise matters. It does not refute the stated positive theorem.

The conclusion is a finite ideal readout law with failure bound independent of the finite number of readings. It is not diamond-norm channel equality, an autonomous apparatus, a continuous physical record, or a permanent-Record theorem.

## 7. Executed evidence and limits

Two independent standard-library exact controls ran without author/repository imports. Complete sources and outputs are embedded below:

- A different four-subset reaction census; held-out S=1153, K=5871; last eligible full-height column instead of the author's first choice; all 158517 active coordinates, connectivity/BFS and periodic ports; exact nonuniform envelope-state deficits; 54 ceil/floor cases including N=1, T=0 and epsilon>1.
- A distinct exact semigroup and degenerate instruments; noninjective counterexample; 32 exact renewal coefficient checks from the conditional-Poisson derivation, including first-gap omission discriminators.

The envelope state satisfies F<=2M and exact total number but is not asserted to be an actual near-equilibrium pre-stop trajectory from the parent. It tests the deterministic inequality on a broader envelope state. A rational axial rate is used for that finite control; the exact symbolic T4 split covers the supplied tuned rate. Finite checks do not replace the general proof.

The frozen author primary replay used /opt/homebrew/opt/python@3.13/bin/python3.13, Python 3.13.5, NumPy 2.4.4, SciPy 1.17.1 and SymPy 1.14.0. It exited zero in 1.990 seconds internally, with 2.586 seconds tool wall time, below its declared 180-second timeout. Complete stdout follows. It has no runtime data inputs, repository imports or output writes; its only file read prints its own source hash. Provenance input declarations are appropriate.

I inspected every actual author-mutant diff and verified its source hash and complete stored failure log. All 24 exit at intended mathematical AssertionErrors, not syntax/import failures. These remain author discrimination controls, not independent proof. They were not re-executed because the independent calculations and final replay identified no concern requiring duplication. The printed PASS total is not used as evidence of independence.

No consequential defect remains in the checked positive claim. Tensor carrier, basis, role pattern, local GKSL law, rates, clock, preparation and ideal instrument remain supplied. Four-site collisions remain four-site operations. The smooth fluid lifetime and every particle-parent smallness/positivity condition remain necessary. No broad no-go, exhaustive novelty, native physical law, physical apparatus energy accounting or global smooth fluid existence claim is approved.

No Lean or other proof-assistant verification was performed. Kernel checking would still require coordinate disjointness/connectivity, finite-fiber Poincare comparison, product distance, coupling/renewal, stopped compensator/event transfer and quantum-instrument induction, besides the separate nonlinear particle dependency.

Only this review report was written by this reviewer during this task. No repository, author source, editable prompt, skill, instruction, commit or PR changed; no external communication occurred.

## Appendix A. Independent geometry/capacity source and full output

Executed through python3 -c with no file writes.

```python
from fractions import Fraction as F
from itertools import product, combinations
from collections import deque
from math import isqrt
from time import perf_counter
import json
start=perf_counter()
V=list(product((-1,0,1),repeat=3))
def key(pair):
    i,j=pair
    return tuple(V[i][d]+V[j][d] for d in range(3))+(sum(a*a for a in V[i]+V[j]),)
rr=[]
for a,b,c,d in combinations(range(27),4):
    for i,j,k,l in ((a,b,c,d),(a,c,b,d),(a,d,b,c)):
        if key((i,j))==key((k,l)): rr.append((i,j,k,l))
assert len(rr)==288
weights=[F(2,3)**(3-sum(a*a for a in v))*F(1,6)**sum(a*a for a in v) for v in V]
parts=[F(0),F(0)]; axial=[]
for r,(i,j,k,l) in enumerate(rr):
    a=[abs(V[i][d]-V[j][d]) for d in range(3)]
    b=[abs(V[k][d]-V[l][d]) for d in range(3)]
    special=(sorted(a)==[0,0,2] and sorted(b)==[0,0,2] and a.index(2)!=b.index(2))
    if special: axial.append(r)
    assert weights[i]*weights[j]==weights[k]*weights[l]
    parts[int(special)]+=weights[i]*weights[j]*sum(weights[q] for q in (i,j,k,l))
assert len(axial)==9
hop_weight=sum(abs(v[d])*weights[i]**2 for i,v in enumerate(V) for d in range(3))
assert hop_weight==F(1,24)
S=1153
ports=[[] for _ in V]
for r,species in enumerate(rr):
    p=((4*r+2,2),(4*r+3,2),(4*r+3,3),(4*r+2,3))
    for v,xy in zip(species,p): ports[v].append(xy)
d=[len(p) for p in ports]
offsets=[d[v]*(v+3)-v-4 for v in range(27)]
assert min(offsets)==104 and max(offsets)==1259
K=4*S+max(offsets)
used=set(); radii=[]; selected=[]; sets=[]
for v in range(27):
    h=v+1
    vertices={(x,y,h) for x in range(S) for y in (0,5)}
    vertices.update((0,y,h) for y in range(S))
    for x,y in ports[v]:
        vertices.update((x,y,z) for z in range(h+1))
        ys=(0,1,2) if y==2 else (3,4,5)
        vertices.update((x,yy,h) for yy in ys)
    x,y=ports[v][-1]
    selected.append((x,y))
    vertices.update((x,y,z) for z in range(S))
    assert len(vertices)==4*S+offsets[v]
    deficit=K-len(vertices)
    vertices.update((1+j%(S-1),6+j//(S-1),h) for j in range(deficit))
    assert len(vertices)==K and not used.intersection(vertices)
    used.update(vertices); sets.append(vertices)
    root=(0,0,h); dist={root:0}; todo=deque([root])
    while todo:
        p=todo.popleft()
        for axis in range(3):
            for sign in (-1,1):
                q=list(p);q[axis]+=sign;q=tuple(q)
                if q in vertices and q not in dist:
                    dist[q]=dist[p]+1;todo.append(q)
    assert len(dist)==K and max(dist.values())<=2*S+5
    radii.append(max(dist.values()))
m=3; edge_count=0
for v,vel in enumerate(V):
    h=v+1;x,y=selected[v]
    pairs=[((0,0,h),(S-1,0,h)),((0,0,h),(0,S-1,h)),((x,y,0),(x,y,S-1))]
    for axis in range(3):
        sign=vel[axis]
        if not sign: continue
        lo,hi=pairs[axis]
        src,dst=(hi,lo) if sign>0 else (lo,hi)
        assert src in sets[v] and dst in sets[v]
        for cellcoord in (0,m-1):
            a=list(src);b=list(dst)
            a[axis]+=S*cellcoord
            b[axis]+=S*((cellcoord+sign)%m)
            diff=[min(abs(a[k]-b[k]),m*S-abs(a[k]-b[k])) for k in range(3)]
            assert sum(diff)==1
        edge_count+=1
assert edge_count==54
# A valid nonuniform total-N state entirely in the population envelope F<=2M.
Z=list(product(range(3),repeat=3)); w=F(1,27);N=216*27;cap=2*N
multipliers=[2]*13+[1]+[0]*13
counts={(z,i):int(216*weights[i])*multipliers[j] for j,z in enumerate(Z) for i in range(27)}
assert sum(counts.values())==N
assert all(F(counts[z,i],N*w)<=2*weights[i] for z in Z for i in range(27))
alpha=F(5,3); c=F(7,4); hop_ratio=F(2,3)
T4=parts[0]+alpha*parts[1]
hop_defect=F(0);col_defect=F(0)
for z in Z:
    for i,v in enumerate(V):
        for d0 in range(3):
            if v[d0]:
                zz=list(z);zz[d0]=(zz[d0]+v[d0])%3
                hop_defect+=hop_ratio*counts[z,i]*counts[tuple(zz),i]/cap
    for r,(i,j,k,l) in enumerate(rr):
        aa,bb,cc,dd=[F(counts[z,q]) for q in (i,j,k,l)]
        kappa=alpha if r in axial else F(1)
        col_defect+=c*kappa/(N*w)*(aa*bb*(1-(1-cc/cap)*(1-dd/cap))+cc*dd*(1-(1-aa/cap)*(1-bb/cap)))
hop_bound=N*N*w*hop_ratio/(6*cap)
col_bound=8*c*N*N*w*T4/cap
assert hop_defect<=hop_bound and col_defect<=col_bound
assert hop_defect+col_defect>w*(hop_bound+col_bound)
def ceilq(q):return (q.numerator+q.denominator-1)//q.denominator
def ceilsqrt(n):
    x=isqrt(n)
    return x if x*x==n else x+1
rounding_cases=0
for N0,m0,T,eps in product((1,2,17),(3,4),(F(0),F(1,7),F(4)),(F(1,10),F(1),F(5))):
    w0=F(1,m0**3)
    Ccap=F(3*N0*N0,2)+F(288*N0*N0,16*w0)
    req=max(N0,2,ceilq(2*T*Ccap/eps))
    side=max(1152,ceilsqrt(2*(req+1)));capacity=side*side//2
    assert capacity>=req and 4*side+1259<=capacity<=4*side+104+(side-6)*(side-1)
    assert T*Ccap/capacity<=eps/2
    nstar=min(N0,capacity//2)
    assert nstar>=1 and min(27*m0**3,N0)>=1
    rounding_cases+=1
print(json.dumps({
 'reaction_count':len(rr),'axial_count':len(axial),'T4_constant_alpha_coefficients':list(map(str,parts)),
 'hop_weight_sum':str(hop_weight),'held_out_geometry':{'S':S,'K':K,'active_sites':len(used),'maximum_BFS_radius':max(radii),'streaming_ports_including_periodic_seams':edge_count},
 'exact_envelope_state':{'N':N,'K':cap,'hop_deficit':str(hop_defect),'hop_bound':str(hop_bound),'collision_deficit':str(col_defect),'collision_bound':str(col_bound),'extra_w_optimistic_bound_rejected':True},
 'rounding_cases_including_N1_T0_epsilon_gt1':rounding_cases,
 'runtime_seconds':perf_counter()-start},indent=2))

```

```text
{
  "reaction_count": 288,
  "axial_count": 9,
  "T4_constant_alpha_coefficients": [
    "4417/69984",
    "11/2187"
  ],
  "hop_weight_sum": "1/24",
  "held_out_geometry": {
    "S": 1153,
    "K": 5871,
    "active_sites": 158517,
    "maximum_BFS_radius": 2286,
    "streaming_ports_including_periodic_seams": 54
  },
  "exact_envelope_state": {
    "N": 5832,
    "K": 11664,
    "hop_deficit": "110/27",
    "hop_bound": "12",
    "collision_deficit": "257198135929/4897760256",
    "collision_bound": "105077/972",
    "extra_w_optimistic_bound_rejected": true
  },
  "rounding_cases_including_N1_T0_epsilon_gt1": 54,
  "runtime_seconds": 0.5328610832802951
}

```

## Appendix B. Independent quantum/renewal source and full output

Executed through python3 -c with no file writes.

```python
from fractions import Fraction as F
from itertools import product
from math import factorial
from time import perf_counter
import json
started=perf_counter()
Z=lambda: [[F(0) for j in range(3)] for i in range(3)]
def add(a,b): return [[a[i][j]+b[i][j] for j in range(3)] for i in range(3)]
def scale(a,c): return [[c*a[i][j] for j in range(3)] for i in range(3)]
def mul(a,b): return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def tr(a): return sum(a[i][i] for i in range(3))
def diag(a): return [a[i][i] for i in range(3)]
def unit(i,j):
 a=Z();a[i][j]=F(1);return a
def transpose(a):return list(map(list,zip(*a)))
def lindblad(j,r):
 j2=mul(transpose(j),j)
 return add(mul(mul(j,r),transpose(j)),scale(add(mul(j2,r),mul(r,j2)),F(-1,2)))
j01=add(unit(0,1),unit(1,0))
j12=add(unit(1,2),unit(2,1))
def generator(r):return add(lindblad(j01,r),lindblad(j12,r))
v1=[1,0,-1];v3=[1,-2,1]
def classical(q):
 return [[F(1,3)+q**2*F(v1[i]*v1[j],2)+q**6*F(v3[i]*v3[j],6) for j in range(3)] for i in range(3)]
def evolve(r,q):
 a=Z();p=classical(q)
 for i in range(3):a[i][i]=sum(p[i][j]*r[j][j] for j in range(3))
 for i,j in [(0,1),(1,2)]:
  a[i][j]=(q+q**5)*r[i][j]/2+(q-q**5)*r[j][i]/2
  a[j][i]=(q+q**5)*r[j][i]/2+(q-q**5)*r[i][j]/2
 a[0][2]=q**2*r[0][2];a[2][0]=q**2*r[2][0]
 return a
def derivative_at_zero(r):
 a=Z()
 for i in range(3):
  a[i][i]=sum((-F(v1[i]*v1[j],2)-F(v3[i]*v3[j],2))*r[j][j] for j in range(3))
 for i,j in [(0,1),(1,2)]:
  a[i][j]=-F(3,2)*r[i][j]+r[j][i]
  a[j][i]=-F(3,2)*r[j][i]+r[i][j]
 a[0][2]=-r[0][2];a[2][0]=-r[2][0]
 return a
matrix_units=0
for i,j in product(range(3),repeat=2):
 r=unit(i,j)
 assert evolve(r,F(1))==r
 assert derivative_at_zero(r)==generator(r)
 assert evolve(evolve(r,F(1,2)),F(2,3))==evolve(r,F(1,3))
 expected=[sum(classical(F(3,5))[i][j]*diag(r)[j] for j in range(3)) for i in range(3)]
 assert diag(evolve(r,F(3,5)))==expected
 matrix_units+=1
def select(r,o):
 keep=[0,1] if o==0 else [2]
 return [[r[i][j] if i in keep and j in keep else F(0) for j in range(3)] for i in range(3)]
amplitude=[1,2,3]
rho=[[F(amplitude[i]*amplitude[j],14) for j in range(3)] for i in range(3)]
qs=[F(1,2),F(2,3),F(3,5)]
histories={}
for os in product([0,1],repeat=3):
 quantum=rho
 cp=diag(rho)
 for q,o in zip(qs,os):
  quantum=select(evolve(quantum,q),o)
  keep=[0,1] if o==0 else [2]
  p=classical(q)
  cp=[sum(p[i][j]*cp[j] for j in range(3)) if i in keep else F(0) for i in range(3)]
 assert tr(quantum)==sum(cp)
 histories["".join(map(str,os))]=tr(quantum)
assert sum(histories.values())==1
assert select(rho,0)[0][1]!=0
bad_j=add(unit(0,1),unit(0,2))
bad_diag=diag(lindblad(bad_j,unit(1,2)))
assert bad_diag==[F(1),F(-1,2),F(-1,2)]
renewal_checked=[]
for p in range(4):
 for k in range(1,9):
  lhs=sum(F((-1)**r,factorial(r))*F(n*factorial(p),factorial(n+p)) for n in range(1,k+1) for r in [k-n])
  r=k-1
  first=F((-1)**r,factorial(r)*(r+p+1))
  second=F(0)
  if k>=2:
   r=k-2
   second=F((-1)**r,factorial(r))*(F(1,r+p+1)-F(1,r+p+2))
  assert lhs==first+second
  if k==1:
   assert lhs==F(1,p+1) and second==0
  renewal_checked.append((p,k))
print(json.dumps({"exact_complex_linear_matrix_units":matrix_units,"coherent_initial_density":"a a^T/14, a=(1,2,3)","measurement_partition":[[0,1],[2]],"gap_parameters_e_minus_t_over_2":[str(q) for q in qs],"exact_history_probabilities":{k:str(v) for k,v in histories.items()},"total_history_mass":"1","noninjective_jump_offdiagonal_diagonal_feed":[str(x) for x in bad_diag],"renewal_coefficient_checks":len(renewal_checked),"first_gap_omission_rejected_for_p":list(range(4)),"runtime_seconds":perf_counter()-started},indent=2))

```

```text
{
  "exact_complex_linear_matrix_units": 9,
  "coherent_initial_density": "a a^T/14, a=(1,2,3)",
  "measurement_partition": [
    [
      0,
      1
    ],
    [
      2
    ]
  ],
  "gap_parameters_e_minus_t_over_2": [
    "1/2",
    "2/3",
    "3/5"
  ],
  "exact_history_probabilities": {
    "000": "8120138641/22963500000",
    "001": "615109871/5740875000",
    "010": "73740277/1148175000",
    "011": "1283858693/18370800000",
    "100": "194083153/1530900000",
    "101": "18123743/382725000",
    "110": "211694461/1913625000",
    "111": "3685716749/30618000000"
  },
  "total_history_mass": "1",
  "noninjective_jump_offdiagonal_diagonal_feed": [
    "1",
    "-1/2",
    "-1/2"
  ],
  "renewal_coefficient_checks": 32,
  "first_gap_omission_rejected_for_p": [
    0,
    1,
    2,
    3
  ],
  "runtime_seconds": 0.010141292121261358
}

```

## Appendix C. Frozen primary replay: full stdout

Command: python3 root_qubit_port_primary.py, working directory this report's directory. Exit code 0.

```text
Exact partial-permutation channel controls: 288 complete matrix units, arbitrary off-diagonal inputs included.
Exact collision port average: 256 microstates, 81 count fibers; both directions and all vacancy sectors.
Exact hop port average: 16 microstates, 9 fibers; rate q*K produces q*n_source*(1-n_target/K).
Exact micro/count generator: 56 microstates, 16 count states; uniform fast fibers; averaged capacity rates; finite-rate non-lumping.
Two-time averaging: {"T": 1.0, "nu": 16, "path_bound_using_integrated_mixing_le_1": 0.6111111111111112, "worst_two_time_TV": 0.043487227298979546}
Two-time averaging: {"T": 1.0, "nu": 64, "path_bound_using_integrated_mixing_le_1": 0.1527777777777778, "worst_two_time_TV": 0.011124060118958931}
Two-time averaging: {"T": 1.0, "nu": 256, "path_bound_using_integrated_mixing_le_1": 0.03819444444444445, "worst_two_time_TV": 0.0027939491863657843}
Uniform collision-rate deficit bound checked on every four-count composition through N=9.
Literal cubic tile: 288 plaquettes; 54 streaming ports; 27 disjoint compartments; K= 5867 active sites= 158409 all physical sites= 1528823808
Native BFS geometry: maximum radius 1345 maximum diameter 2505 ; large-family size inequalities checked without allocating large cubes.
Exact complete-graph Poincare controls: 21 fibers, K=2..7, all zero-mean functions.
Exact route/congestion controls: 1441 labelled trees; endpoint routes: 20796
Finite spectral controls: all fixed-occupation fibers in those trees; minimum gap*K*(2K-3) = 4.0
Additional path/star/binary controls: 63 fibers, K=7..9; direct TV checked at six times.
Exact integrated product control: one component 1/4, two components 5/16.
Retained connectedness counterexample: two disjoint bonds, one particle, two zero modes; global-uniform mixing fails.
Exact epsilon allocation: three finite parameter sets, including growing-cube capacity; both error terms <= epsilon/2.
Exact stopped capacity controls: all 288 reaction boxes, 81 points each; T4 = 4417/69984 + alpha_* * 11/2187 ; hopping weight = 1/24
Floating quantum instrument control: 27 three-time outcomes, 6 active states plus a correlated inert qubit; maximum joint probability error = 6.938893903907228e-17
Exact stopped nonlinear resource poles: {"K": "37", "S": "37/2", "active_sites": "43", "collision_exit": "69", "comparison": "111/2", "fast_rate": "429/2", "hop_exit": "46", "individual_collision": "63", "individual_hop": "40", "local_collision": "34", "local_hop": "35", "log_coefficient": "43", "mix_time": "149/2", "volume": "123/2"}
Exact stopped-capacity choices: delta=1,1/2,1/4; certified odd grid, full multinomial support, geometric interval, and capacity error <= delta^2/2.
Coverage: local matrix units; all small port fibers; exact finite generator; two-time floating count law; full periodic-port tile; rational variance forms; tree routes; spectral/TV examples; epsilon choices; stopped capacity; quantum count instruments; nonlinear resource substitutions.
Boundary: supplied local GKSL, tensor carrier, role pattern, clock and preparation; four-site collision support; nonlinear corollary conditional on the supplied particle theorem; no native Record law asserted.
TOTAL: PASS=221912 FAIL=0
Elapsed seconds: 1.990
Runner SHA256: 0a655a71047cae8fde331eba758ad91da08cc7f5cbaddac4b2335196a9f38f2a

```

