# External qubit-port publication checkpoint and composition check

2026-10-11. This is an author packaging record and a separate source-bound
check of the root-authored composition drafts. It is not a formal audit
verdict or independently retained status. No shared-repository files,
instruction files or editable prompts were changed by this worker.

## Frozen publication bytes

- [Final theorem note](../FINAL_QUBIT_PORT_NOTE.md), 889 lines,
  SHA-256 `5d7fbfe0d0603e52c80de047f3ea91bff46b01d3a24b40ba2f796d49c0c3d3ad`.
- [Final primary](../root_qubit_port_primary.py), 548 lines,
  SHA-256 `0a655a71047cae8fde331eba758ad91da08cc7f5cbaddac4b2335196a9f38f2a`.
- Intended destinations: `docs/LOCAL_QUBIT_PORT_REALIZATION_WITH_POLYNOMIAL_MIXING_BOUNDED_THEOREM_NOTE_2026-10-11.md`
  and `scripts/local_qubit_port_realization_polynomial_mixing_2026_10_11.py`.
- Status remains `bounded_theorem`, `proposed_retained`, actual
  `conditional-support`. Parent copying, independent review and formal
  audit are separate actions.

The final note and primary were read completely. The final narrow wording
clarifications define active-number support with arbitrary correlated inert
factors, signed tile translation, the forward generator convention, and the
supplied ideal selective count instrument. They do not change the proved
rates or comparison estimates. The primary's final cleanup replaces an
obsolete Poisson-corrector comment and removes an unused array; its complete
source mutation suite was rerun on the final bytes.

## Composition sources and complete reading coverage

- Root's complete 119-line [first composition draft](../LOCAL_QUBIT_NONLINEAR_COMPOSITION_DRAFT.md):
  `41746837456a3ec325bdce904b802afa966a71af538b080ae7c8b95d2eaa7e4e`.
- Root's complete 114-line [stopped-capacity refinement](../LOCAL_QUBIT_STOPPED_CAPACITY_REFINEMENT.md):
  `f28c729a079799286d626a6d8b427d4869ee6639e262fbda0264ca896cd5859c`.
- Complete 813-line [final nonlinear particle parent](../FINAL_NONLINEAR_PARTICLE_NOTE.md):
  `ab42c1e6377e360739d01ac9f37f56f98b087997649ebec45be59ea07e23fc90`. The current worktree
  publication copy has identical bytes. Exact model, principal-cutoff
  preparation, stop definition, exit/overshoot bound and simultaneous
  schedule were matched directly to this source.
- The old 286-line root particle draft was read as development context;
  it is not the corollary's preparation contract. A partial read of the
  separate nonlinear particle review was used only to locate sources;
  it is not claimed as completed verification or proof authority.
- The nonlinear-fluid note `c81c0029fb70d1cea0ecf41ee893caf357747bcda138af5d1bef5ed5848a114a`
  was used for publication style and parent context. This worker did not
  independently redo its complete nonlinear PDE theorem. The corollary
  explicitly retains the complete conditional particle-parent contract.

The original full port and exclusion-mixing derivations were read and
developed earlier in this campaign; their complete arguments, scripts,
source inventory, exact reading coverage and negative findings remain in
the unchanged [native probe](../NATIVE_REALIZATION_PROBE.md),
[mixing probe](../EXCLUSION_MIXING_PROBE.md), [original receipt](receipt.json)
and [mixing receipt](exclusion_mixing_receipt.json). All 15 original packet
files and all 11 mixing packet files were rehashed unchanged. All 19
worktree source identities from that original read were rehashed unchanged.
Their original distinction between complete and selected source readings
is preserved; this refresh is not an assertion of additional full reading.

The original search covered top-level documents at frozen main
`a13caa4885f547c8d206265b031ba7649e539fd9`. It was not an exhaustive archival
or literature novelty search. At this freeze, observed worktree HEAD is
`3fbaa00e9d97a19459d197fd0de2d62d45327e90`, local main is `e485eab6b09b3957df5772104d3ea3980108d7fa`,
and branch is `physics-loop/toe-nonlinear-transport-20261011`. Root's concurrent branch
changes are not authored by this worker. These changed revisions do not
invalidate the source comparison because the necessary source bytes were
refreshed directly. No network search or physical primitive adoption occurred.

## Independent reconstruction of the root's corollary

No consequential defect was found in either complete composition draft
under its stated conditional source theorem. The earlier global-capacity
construction remains a valid fallback but is not the resource ceiling
selected for publication. Both original drafts are unchanged.

1. For the target's pre-stop `F<=2M`, direct substitution into the hopping
   deficit gives `4 b N^2 w/(ell K)` times
   `sum_(v,d)|v_d| M_v^2=1/24`, hence `bN^2w/(6ell K)`.
   Both collision directions give at most
   `8 c kappa N^2 w^2 p_r sum_(four species)M/K` in each cell.
   Summing `1/w` cells yields
   `C_local=N^2 w[b/(6ell)+8c T4]`, with no hidden torus-volume factor.
   The exact finite census independently gives
   `T4=4417/69984+(11/2187)alpha_*`.
2. The capacity chains are equal until a discrepancy, so the target's
   pre-stop bound controls the common state's excess-event intensity.
   The stopped compensator gives `L C_local/K`. Target exit, including
   initial exit and an overshooting jump, is charged once through
   `C_prob delta^2`. This is a bad-event bound; it does not replace the
   global G-versus-G_K path TV bound by a favorable-state bound.
3. The fast-averaging comparison still uses the global `B_K` and uniform
   integrated mixing estimate. Gluing its path coupling adds
   `tau B_K(1+LB_K)/nu`. The chosen capacity and fast rate allocate at
   most `delta^2/2` to each new term, yielding the parent path error
   `C_path delta` with failure at most `(C_prob+1)delta^2`.
4. With `N~delta^-19`, `m~delta^-2`, the two C_local powers are -35 and
   -34. Thus K has sufficient power -37, S has -37/2, and total volume
   has -6-3(37/2)=-123/2. The slow-exit powers are -46 and -69; the BFS
   comparison contributes -111/2, and the fixed-N entropy contributes
   -19 and a logarithm. Therefore tau has power -149/2 and nu has
   `-149/2-69-69-2=-429/2`. The log coefficient is `6+37=43`.
   Ceiling constants and the inequalities involving `c_m,c_ell,C_S,C_K`
   were checked as inequalities for every `0<delta<=1`, subject to the
   parent's independent smallness requirements.
5. Count-fiber projection sends the active diagonal to its fiber
   indicator times that diagonal. Active GKSL evolution closes on the
   diagonal after tracing out inert factors. Induction on unnormalized
   selective states proves all finite ordered count-readout joint laws
   equal their classical counterparts. There is no unjustified uniform
   redraw after an actual measurement. This uses a supplied ideal
   count instrument and does not establish a permanent-Record apparatus
   or a physical continuously observed trajectory.

The exact count preparation uses the nine tuned axial rates, the principal
Fourier cutoff sampled at cell centers, and active-number support. Arbitrary
within-fiber populations, coherences, and correlated inert qubits are allowed.
The norm event is a measurable event of finite-state cadlag count paths;
the sampled-time consequence follows for any fixed finite number of ideal
readings, with the same probability bound.

## Final executable evidence and limits

The final [baseline log](publication_baseline.log) is exit 0,
`PASS=221912 FAIL=0`, approximately two seconds on this host. The primary
declares a 180-second timeout and provenance input paths; it reads no input
data files, imports no repository modules, writes no output artifacts, and
does not allocate the full many-body Hilbert space or a huge coordinate file.
Python/NumPy/SciPy/SymPy versions and exact execution commands are in the
receipt and [mutation record](publication_mutation_results.json).

The complete primary covers local matrix units, all small port fibers,
the actual 56-state microscopic generator, floating two-time count laws,
all 288 plaquettes and 54 streaming ports, disjoint equal-capacity cubic
compartments, actual BFS radii, rational Poincare forms, all 1,441 labelled
trees through K=6, larger floating spectral/TV examples, and exact product
mixing integrals from matrices. The final new controls include 288 exact
pre-stop reaction boxes with 81 points each; rational grid/capacity choices;
exact resource substitutions; and an actual 12-dimensional quantum model
with a correlated inactive qubit. All 27 three-time instrument outcomes
match the associated classical law to floating error below `7e-17`.

All 24 actual source-copy mutants exited 1 at their intended mathematical
assertions. They cover population leakage, rate powers/vacancies, biased
fibers, wrong quotient, missing fast rate, first-gap omission, uniform
capacity constant, reaction energy, plaquette range, streaming translation,
non-BFS trees, complete-graph variance factor, endpoint route, product mixing,
both generic epsilon allocations, both stopped-deficit families, actual
selective instruments, inactive-factor readout, nonlinear exponent and
stopped-capacity allocation. Complete tracebacks and mutant sources are
retained; none of the intended failures is a syntax error. The
[aggregate execution log](publication_mutations.log) links every full log.
These are author discrimination controls, not independent proof or audit
verdicts. Finite floating computations do not prove the all-size theorem.

The intermediate composition baseline is explicitly retained with its
source `publication_intermediate_f42eceb.py`; it is not the final source.
A first naive Markdown regex interpreted code `D[J](rho)` as a link;
the final scanner removes code spans and checks all actual publication
links. This was a packaging false positive, not a mathematical failure.
The first freeze script also required the expected assertion text to begin
immediately after `AssertionError:`; one valid failure includes a jump-name
prefix. The corrected check retains both the assertion-type and expected
message requirements. Its failed bookkeeping log is preserved separately.

## Recovery and open obligations

Root is the sole worktree writer. This packet is ready for root's complete
read and the separately assigned reviewer. Copying may rebase relative
artifact links only with an explicit packaging record. The original broad
negative research probes remain separate; only finite hypothesis controls
occur in the positive publication unit. Supplied tensor structure, basis,
role pattern, local GKSL law, bath/clock implementation, large rates,
preparation and ideal count instrument remain physical interfaces. The
operators retain four-site collision support, not strict two-site support.
No native physical law, permanent-Record realization, fixed-volume limit,
fixed-strength limit, or globally smooth fluid existence theorem is claimed.
