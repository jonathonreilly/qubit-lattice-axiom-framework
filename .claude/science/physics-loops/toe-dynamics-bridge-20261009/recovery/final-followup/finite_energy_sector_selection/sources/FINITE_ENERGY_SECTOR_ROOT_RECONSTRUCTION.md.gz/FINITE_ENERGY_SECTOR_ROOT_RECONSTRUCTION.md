# Conditional finite-energy concentration: root reconstruction

Root coauthor derivation, independently written before reading the newly assigned worker's result. This is a follow-up proposal, not an addition to the frozen CURRENT theorem, a retained audit, or a new physical axiom. Exact premises are CURRENT final source 1104de3922002720beecb7eb2bd106b64025aea0afb1e11b8f86750dfb59e30d and the supplied Concrete full-spin chosen-state GNS with positive Fock Hamiltonian. No scientific executable or Lean certificate is used.

For the specified current embeddings, the positive-polarization one-particle space is K_L direct_sum K_H. Work in the common vacuum Fock space over it. Finite-scale states are supported on the embedded finite-scale Fock range; the one-particle occupied current interval is I_c. The actual physical Hamiltonian there is dGamma(e_c,0 direct_sum e_c,1), with the two positive energies of CURRENT C14. The larger common Fock space is a comparison representation, not an assertion of a limiting actual energy operator.

Let N_H count particles in the high channel and let P be the projection onto its vacuum, with arbitrary low-channel occupation. Set Q=1-P and

    M_c = sqrt(m^2+2v^2/c^2).

Since w_c(p)>=0, e_c,1(p)>=M_c throughout the high current band, while every low energy is nonnegative. On the embedded finite-scale Fock space,

    H_c >= M_c N_H >= M_c Q

as positive quadratic forms. This follows sector by sector by summing the nonnegative one-particle energies and then closing the forms. It does not require a bound on the number of low excitations. Normal density matrices rho_c with Tr(rho_c H_c)<=E_* therefore satisfy

    delta_c := Tr(rho_c Q) <= E_*/M_c,
    Tr(rho_c N_H) <= E_*/M_c.

For positive trace-class rho, the inequalities follow by spectral truncation of the forms and monotone convergence. Thus uniform actual energy controls high-occupation probability at order c. More generally the sufficient condition is E_c/M_c->0, not necessarily a fixed E_*.

If delta_c<1, define the normalized low-sector state

    sigma_c = P rho_c P / (1-delta_c).

A quantitative estimate is

    ||rho_c-sigma_c||_1 <= 2 sqrt(delta_c) <= 2 sqrt(E_*/M_c).

Proof: purify rho as a unit vector Psi in a larger Hilbert space. Normalize (P tensor1)Psi to Phi; their overlap has modulus sqrt(1-delta). The difference of their rank-one density matrices has two nonzero eigenvalues +sqrt(delta), -sqrt(delta), as follows by writing Phi in the span of Psi and an orthogonal unit vector. Its trace norm is 2sqrt(delta). Partial trace is contractive on self-adjoint trace-class operators: use its dual action A->A tensor1 and the variational trace-norm formula. The partial traces are rho and sigma. This proves the bound without assuming purity of rho or a product state.

For a normalized pure vector psi_c with energy at most E_*, its unnormalized distance to the no-high sector is ||Q psi_c||<=sqrt(E_*/M_c). For phi_c=P psi_c/||P psi_c||, the squared distance is 2-2sqrt(1-delta_c)<=2delta_c. Phase is chosen by the displayed projection.

The exact vacuum-Fock tensor decomposition identifies sigma_c with a low density matrix tensor the high vacuum. For every bounded operator A,

    |Tr((rho_c-sigma_c)A)| <= 2||A|| sqrt(E_*/M_c).

This is state distinguishability control, uniform over the unit ball of bounded operators for each pair of states. It is NOT convergence of the operators themselves in C*-norm and does not identify the complete doubled observable algebra with a single copy. A high packet number operator n_h=a*(h)a(h), for a normalized compact-current high packet, remains an even CAR element of norm one, although its expectation in sigma_c is zero and its expectation in rho_c is at most delta_c whenever its packet lies in the finite-scale band.

Nor does the energy assumption imply that sigma_c converges as a state in the low sector: translated low packets can escape spatially, and low normal states can vary with c. No compactness, unique state selection, physical model selection, interacting extension, or uniform convergence of all actual-flow observables is concluded. Actual finite-scale time evolution preserves the high projection and the energy bound, but that fact alone does not solve these low-sector convergence questions.

The bound explains one conditional way the extra high channel becomes operationally negligible for finite-energy states. It uses an explicitly imposed bound on actual excitation energy above the chosen vacuum. The framework's axioms have not been shown to require this class of states. The earlier all-algebra time counterexample and doubled equal-time local quotient remain valid.
