# Root addendum A, still before new author/checker exposure

This adds a direct domain proof and a concrete local observable family to the
frozen reconstruction dc3a429afc045d6bf39564f1ada2c1dddfab056ce3c2ba5ad34f1f13a095d75a.
It does not modify that freeze. All hypotheses remain conditional on the
supplied chain. The energy unit in G=H+1 is fixed mathematical normalization;
equivalently use G=1+H/mu for any fixed reference mu>0.

## 1. Bounded commutator implies the needed form control, without interpolation

Suppose A is bounded, maps D(H) into D(H), and C=[H,A] extends boundedly.
Set G=H+1>=1. The resolvent commutator identity and the positive square-root
integral give on D(G), hence by closure on D(G^1/2),

    [G^1/2,A] = (1/pi) integral_0^infinity
       s^1/2 (G+s)^-1 C (G+s)^-1 ds.                (A1)

The integral converges in operator norm because its norm is bounded by
||C|| s^1/2/(1+s)^2. The integral of that scalar function is pi/2 (substitute
s=u^2, then u=tan theta). Thus

    ||[G^1/2,A]||<=||C||/2,
    ||G^1/2 A G^-1/2||<=||A||+||C||/2.             (A2)

For the domain extension, approximate a vector in D(G^1/2) by its spectral
cutoffs in D(G). The right side A G^1/2 psi +[G^1/2,A]psi converges, as does
A psi; closedness of G^1/2 gives the stated preservation and identity. To
justify A1 first on D(G), truncate the square-root integral and use
G(G+s)^-1=1-s(G+s)^-1; the commutator is exactly the norm-integrable right
side. A* is treated separately; norm differentiability of its evolution
supplies its domain statement and the same commutator norm.

Norm differentiability of alpha_t(A) at zero is sufficient for these domain
statements: for psi in D(H),
U(t)A psi=alpha_t(A)U(t)psi has a strong derivative at zero. Hence A psi
belongs to D(H), and the derivative identifies the bounded commutator.
This avoids treating a formal commutator as a domain proof. The integral is
standard operator calculus, supplied here with its hypotheses; no novelty
claim is attached to it.

## 2. Ordinary compact smooth physical cells give a nonempty local class

Take finitely many fixed real two-component f_j in C_c^infinity(R), and
the parent's actual cell coefficient C_c f_j. For c<=c0 the checked Local
Even estimate supplies

    ||D_c C_c f_j|| <= ||D f_j||
       +(c0/2)(m||f_j'||+v||f_j''||) =:d_j,
    ||C_c f_j||<=||f_j||=:l_j.                     (A3)

Refresh the exact parent inequality before publication; no stronger rate for
J_c C_c f is claimed here. The coefficient dynamics of each represented CAR
field is norm differentiable, with derivative norm <=d_j. Consequently an
even word in these fields has operator norm <= product l_j and derivative
norm <=sum_j d_j product_(i!=j) l_i. Products and adjoints obey the same
norm-domain argument. A2 gives a uniform two-sided actual-energy form bound.

At every c these even words are actual local even spin observables: compact
physical supports contain finitely many cells, and the even-JW strings stay
inside their finite hull. The number of cells may grow as c decreases.
Nothing here asserts that arbitrary single-site or staggered-cell families
have the same uniform energy control.

The checked Current C21 gives J_c C_c f ->(f,0) in the common coefficient
space for each fixed f. CAR polynomial norm continuity gives a norm limit
of the common full-Fock represented even words to the low-only target words.
Compression to the high vacuum is contractive, so their unital common-low
extensions b_c converge in norm to the continuum word b0. They commute with
the outside-band particle projection Pi_c. The physical finite-c compressed
word is the restriction to Pi_c, and a_c=Pi_c b_c Pi_c is its zero extension.

For b0 satisfying the H0 graph bound K, the cutoff term is harmless in the
two-sided weighted norm:

    ||G0^-1/2 b0(1-Pi_c)G0^-1/2||
       <=K/(1+sqrt(m^2+v^2/c^2)).                  (A4)

Use ||G0^-1/2 b0 G0^1/2||<=K (the adjoint graph bound) and that any outside-
band particle has H0>=sqrt(m^2+v^2/c^2). Since b_c commutes with Pi_c,
a_c-b0=(b_c-b0)Pi_c-b0(1-Pi_c), so the weighted observable error in R6 is
at most ||b_c-b0|| plus A4. This tends to zero. The H0 graph bounds of a_c
follow from the actual Hc bounds on its band, H0<=Hc<=sqrt(2)H0, and
commutation of Pi_c with H0; one conversion factor at most 2^(1/4) suffices.

The continuum b0 also has a bounded energy commutator, since fixed smooth
packets are in the domain of the continuum coefficient generator. Thus this
family meets the proposed correlation theorem's hypotheses without imposing
an unproved transfer property on arbitrary observables. The family is a
chosen test class; it does not select all physical measurements or a unique
limiting state. Initial low trace-norm convergence remains separately supplied.

## 3. Outstanding checks

Confirm the precise CAR norm convention and A3 from full relevant parent
passages; check the telescoping constants in R7 and the Fock-factor/zero-
extension interpretation; independently challenge R1 and the fractional
power phase estimate R4. No claim of optimal rate, retained audit, Lean
verification or general interacting/thermodynamic result is made.
