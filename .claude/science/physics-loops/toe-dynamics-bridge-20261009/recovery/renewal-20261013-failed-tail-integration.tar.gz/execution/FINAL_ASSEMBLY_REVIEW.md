# Root review of the energy-tail publication

Disposition: accepted_for_source_integration. This is source/publication review
of already checked conditional mathematics, not a new retained audit.

The final packet is freeze dfef53f78d531e88ef431843a2a9683d37442666785241486d6e1c34e9b342c9
(361 members). The962-line note has SHA a387258882122bd06b0840a0498ad5aa368dc2e86f454039975d5c9cf5a149e8.
The758-line root driver has SHA4ee0f3efbf893e1a4c86e90ed8471e5ad6ea8ec8429a9c43ef47c708f15802f9.
The actual clean branch is physics-loop/toe-energy-tail-20261013 on
PR9521 head e8d5b7b99c9faab65f71eb5ff353b60e2b609608. Remote main and this
parent head were unchanged at the22:13:49UTC refresh; the parent remains open
and regular. No sibling initial-state ancestry is claimed.

## Mathematical statement and source reuse

Root read the entire new wrapper, every inter-core wrapper, complete changed
sidecar arguments and dependency/parent maps. All306/390/84 source bodies are
unchanged. Earlier full source coverage and ordinary analytic acceptance are
reused at their exact frozen identities, including comparison239/evidence412,
prepared340/512 and compact-preparation qualifications. Root also reread the
complete306-line root proof to compare the wrapper's cutoff bound directly
with U11-U12. The abstract common-H graph/UI theorem is separate from its
additional supplied normal-state weak-law premise. Vacuum multitime parentage
does not certify that normal-state law.

The wrapper retains finite first energy only, fixed finite chains, genuine
uniform fixed-state tails, weighted compact-family qualification, and the
lim_R limsup_joint statement for convergent varying states. The normal-state
corollary preserves regular fixed boundaries, the shared initial energy and
positive limiting event probability for normalized means/W1. The actual-cell
statement retains common H/instruments, domain/commutator hypotheses and the
accepted epsilon=o(h^2) scale. Later epsilon=o(h) sharpening is excluded here.

The mandatory precision J=Gamma C linear/unitary is explicit before the
unchanged independent proof; Gamma alone remains antiunitary. Original failed
wording and no-correction acceptance remain archived with the superseding
precision. The high-rank counterexample is outside fixed slots; the single-pair
control retains UI. No universal negative or no-go packet PASS is claimed.

The archived finite-Fock controls remain finite algebra evidence. Prior Lean
source bbcb658c and its actual20.399216-second successful compiler/axiom receipt
are reused only for the scalar common-modulus cutoff implication. No CAR,
domain, trace, calibration or kinetic-law proof is asserted formalized.

## Tools, metadata and actual check

Root read the complete758-line driver, pure148-line identity core,142-line
source checker,34-line extractor, all executable canonical-runner code and
the declared configuration/map structure. Large literal identity arrays were
fully checked deterministically, not claimed individually reread by eye.
The full source transformations reconstruct all280 declared inputs,326accepted
members,294original aliases,3unchanged complete cores and5parent core slices.
All current local links and the exact two mathematical-notation exclusions
were checked. Raw diffs remain exact compressed bytes with no text normalization.

Root caught invalid trace/status enum use in the draft. The preserved correction
now gives upstream_support/supports, user_goal and null downstream target/blocker
across the note and structured sidecars. The final driver/checker enforce this,
and the PR title has distinct lane, claim-type and status fields. No scientific
body changed. Root read all twelve handoff sections, review history, conformance,
negative checklist/ledger, scalar scope and publication body/title.

The root source-only check at22:16:30UTC exited0 in0.396892seconds with empty
stderr, verified the full361-member freeze and rejected all four in-memory
byte corruptions for their exact expected causes. stdout SHA is
18ba4f5b49204c3873d25f9f0fad3648d91d4d81ef2459adcf3825e73a99b56d.
It executed zero mathematical predicates and no proposed canonical runtime.
Root now authorizes the explicitly reviewed prepare/stage/verify sequence.
Its actual runtime outcomes, Git publication and attached regular PR remain
future actions at this review's timestamp. Exact old graph objects must remain
unchanged with the declared one-node/two-edge addition.

## Limits

No new independent science review, model diversity, empirical prediction,
physical realization, retained promotion or audit verdict is supplied here.
Combined current-main landing validation and independent retained audit remain
separate obligations. The fixed renewed campaign ends2026-10-14T21:37:33Z.
No editable prompt or physical-axiom file changed.
