# Publication conformance

One canonical note, full unchanged 306/390/84 cores, complete accepted source closure, explicit provisional supplied dependency table, two real canonical parent edges and twelve-section HANDOFF form the review unit. Root accepted the one-note structure for preparation, not publication execution.

Root runtime requires a separate exact acceptance/review outside the frozen preparation; all acceptance-template flags begin false. Driver rejects changed package, source, parent, procedure, branch, base, stage or index. Prepare installs the frozen payload and creates a root staging list; root stages; verify checks staged blobs before include-worktree checks. Runtime reports preserve raw failures and do not turn identity checks into scientific PASS.

Raw unified diffs are gzip archives with exact pins. Text normalization is not authorized. No canonical source, cache, graph, PR, audit, prompt or axiom was mutated during preparation. No extra agent or model/effort change. Full new wrapper/helper/program-diff reads and complete extraction-map checks are required before source freeze.
