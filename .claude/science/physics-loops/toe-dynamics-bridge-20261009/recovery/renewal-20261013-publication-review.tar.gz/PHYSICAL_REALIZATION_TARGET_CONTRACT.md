# Next physical-realization target — pre-derivation contract

Status: research target only. The two requested publications remain first.
No theorem, simulation, physical realization or audit is established by this plan.

## Exact interface to improve

The checked kinetic results use a common nonnegative selfadjoint energy H and
specified finite coarse spectral Lüders instruments. For bin B_z the branch
map is rho -> P_z rho P_z, P_z=1_(B_z)(H). The full classical-label/system map,
including an arbitrary passive reference, is the comparison object. Merely
matching the energy-bin probabilities does not identify this instrument.
Between a fixed number of interventions the original supplied evolution remains
in place. The final unnormalized energy measure, first moment and, when success
probability has positive limit, conditional W1 law are the downstream objects.

The intended gain is an explicitly constructed finite apparatus with a spatial
implementation and quantitative error/resources for this same instrument. A
spectral gate or energy phase oracle alone is an intermediate mathematical
module; it does not discharge the spatial implementation obligation.

## Quantifiers and imports that must remain visible

- State exactly whether H is the unbounded supplied CAR energy, a finite-volume
  Hamiltonian, or a bounded local-qubit Hamiltonian. Give the energy zero and
  every embedding if more than one is used. A bounded finite-dimensional
  compiler alone proves no continuum or thermodynamic identification.
- Work on fixed finite-first-energy inputs, or a stated weighted compact family.
  If states or resources vary jointly, state the limiting order and tail modulus.
  A bound on mean energy alone is not uniform integrability.
- Specify regular bin boundaries or account for their spectral weight explicitly.
  Do not obtain an operator-norm approximation of a discontinuous projector
  across an unqualified boundary by naming phase estimation.
- Fixed finite history length is the initial target. Growing measurement counts,
  moving boundaries, feedback and rare normalized postselection need separate
  estimates; do not introduce them silently.
- Price finite registers, prepared blank states, phase references, forward and
  inverse controls, coefficient precision, query/intervention duration, geometry,
  interaction support and control/clock resources. State which are supplied.
- State the allowed physical lattice model. Additional qubit blocks, routing
  corridors, accuracy-dependent range/arity and a selected macro origin are
  constructions with explicit costs, not an unchanged native law.
- A classical pointer register is a supplied instrument output. Permanent
  Record occurrence, Born selection and a physical axiom change are not implied.

## First decisive comparisons

Freeze a finite common-H fixture with two distinct energy vectors in one bin
and a vector in another bin. Use a superposition inside the first bin and a
system/reference entangled input. Compare complete branch maps, not histograms.
Preserve a fine-energy archive followed by classical binning as a control: it
must be distinguished from the coarse Lüders target. Also test the boundary,
energy-period alias and finite-precision cases appropriate to the chosen route.
This discriminator is prior art (Cycle279), not a new result of this campaign.

Analytic acceptance requires the apparatus map to be identified explicitly, a
proved input/reference error bound, and an honest composition with finite
histories and first-energy tails. Finite matrix controls can expose sign,
coherence and normalization mistakes; they cannot certify unbounded domains,
uniformity, continuum limits or spatial realization on their own.

## Approach comparison before selection

Consider spectral-filter/phase-register constructions, direct finite-window
functional calculus and local bounded-Hamiltonian synthesis. Keep the actual
strength of any assumed controlled evolution explicit. Compare the candidate
against existing generic pointer/uncompute, battery lifts and autonomous rotor
suppliers. Select a route only if its output instrument or physical-resource
bounds improve the stated interface. No universal no-go claim is proposed.

A useful first milestone may be a quantitative apparatus module with a fully
stated local-H implementation and an explicit remaining continuum embedding.
It must be described as that conditional advance, not as complete TOE closure.
A failure of one construction triggers a different route or a narrower
correct result, preserving the failure; it is not a reason to change axioms.

## Source pins and novelty limits

- Current main: 583c699e859b64ff01c8bc92d1c04bdfe9994509.
- Multi-time parent PR9521: e8d5b7b99c9faab65f71eb5ff353b60e2b609608;
  canonical note SHA b782e4814730e330c1a3d0452382dc488caa2e920b7e544e43cba84ef12279af.
  Root read exact instrument/qualifier sections; full proof reuse is prior evidence.
- Source survey REPORT.md SHA ba5e76deb71bad9701d2e81a69096c392d800cd6ef0d3044354c643d2e837a2b.
  It is reconnaissance, informed by root messages, not independent verification.
- Root full-read scope is in ROOT_INSTRUMENT_TARGET_SOURCE_READS.json.
  The native edge instrument, historical Cycle279 and local-reference note are
  additionally pinned in root_physical_sources/SOURCES*.json.
- Energy-tail and graph-calibration actual publication heads will be bound after
  their regular PRs exist. Their checked conditional mathematical sources remain
  those in the sole current checkpoint; this contract adds no source authority.
- Standard energy phase estimation is primary literature, including
  https://arxiv.org/abs/1310.3047. Selected QPE pages were read; its universal
  controllization construction has not been adopted or independently checked.
- A bounded repository search is saved at
  root_prior_art_search/energy_instrument_terms.txt. It is not an exhaustive
  novelty proof. Generic uncompute, phase estimation and finite local compilation
  must not be advertised as new mathematics.

Second-ranked route: joint physical fermion/photon site composition. Existing
3D even-algebra architectures remain prior art. G0c primary recovery is underway;
its summary cannot substitute for absent source dependencies. Do not import the
candidate branch's altered axiom test setting into the current framework.
