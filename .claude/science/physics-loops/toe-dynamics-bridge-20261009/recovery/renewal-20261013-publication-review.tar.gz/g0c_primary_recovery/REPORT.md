# G0c bounded source-recovery report

**Outcome: the missing primary dependencies and original outputs were not recovered from the authorized local sources.** The existing referee verdict and checker are preserved with exact hashes. Their dependency/output packet remains incomplete; this is a recovery result, not a scientific verdict on G0c.

The previous reconnaissance report is unchanged: SHA256 `ba5e76deb71bad9701d2e81a69096c392d800cd6ef0d3044354c643d2e837a2b`. This follow-up wrote only inside `renewal_20261013_213733/g0c_primary_recovery`.

## Search completed

| Authorized source | Read-only search | Outcome |
|---|---|---|
| Exact temporary path recorded by the referee | Existence check before any traversal | Directory absent |
| `/Users/jonreilly/Documents/Codex` | Hidden/ignored-aware filename search for `ckcore.py`, `turns.py`, G0c directories, and eight exact cited test/output filenames | No missing primary/test/output files found; only previously preserved G0c artifacts/references |
| Workspace manifests and recovery records | 7,140 manifest-like text files searched for G0c, `ckcore.py`, and `turns.py` | Matches only in our already preserved reconnaissance files |
| Workspace archives | 77 archive paths, 55 distinct byte sequences; 42,333 member names plus 142 members in one nested archive | No G0c, `ckcore.py` or `turns.py` member |
| Known repository worktree/history metadata | Worktree inventory and completed `git log --all` path search for the dependency names/G0c paths | Sole relevant commit introduces the two existing referee files |

The exact absent temporary directory is:

```text
/private/tmp/claude-502/-Users-jonBridger-Projects-Physics-baremetal-probes--claude-worktrees-toe-leverage-analysis-e8a790/af5789b9-888d-43b1-90de-58a07e0f2129/scratchpad/referee_G0c
```

The history query used the known repository through `correlation_worktree`; its shared Git directory is `/Users/jonreilly/Projects/Physics/.git`. No other home directories or external worktree contents were searched. The single path-history result was `f5adbd3a7cd90be537c54d62f12da3115c9e185f` (2026-10-08). Its complete commit summary is preserved in `G0C_INTRODUCING_COMMIT.txt`; it adds the referee pair and changes other candidate bookkeeping, without adding the missing dependency files.

## Exact surviving sources

Both sources are byte-identical at their introducing revision `f5adbd3a7cd90be537c54d62f12da3115c9e185f` and the frozen candidate head `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`.

| Original repository path | SHA256 |
|---|---|
| `.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/REFEREE_VERDICT.md` | `487587f7dd10c72dc680319d1dbcea151583136fe0e25825635d4f3af89efc8d` |
| `.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/referee_checks.py` | `0aeab81ffc4419ba74a0cbbf1b402fec6d496d52bca742193e2b3012b25f7d0d` |

Exact copies are in `preserved_existing_referee/`, with origin/revision/size/hash records in `PRESERVED_EXISTING_REFEREE_MANIFEST.json`. These are not newly recovered primary dependencies. The checker still imports unavailable `ckcore` and `turns`; its referenced original check outputs were not recovered. No incomplete program was run, and no replacements were reconstructed.

## Completeness and limits

The local archive scan used exact archive SHA256 hashes to avoid reading duplicate byte sequences. Python's tar reader initially lacked zstd support for one Lean distribution; a successful `tar -tf` retry indexed all 18,527 members with no target match. The original error and successful retry remain recorded. One nested recovery archive was inspected in memory without extraction. The additional split-file search found only 146 `.partial.npz` files and 45 JSON manifests beyond the indexed archives; these were not mistaken for split archives.

This establishes absence only from the specified temporary location, searched workspace files/archive members, and matching named paths in reachable repository history. It does not establish loss everywhere: remote machines, other user directories, other chats, renamed/unrecognized archives, unreachable or pruned Git objects, and unrecorded external storage remain outside this search. Symlinked directory targets outside the workspace were not followed. No network fetch, chat access, Git mutation, scientific execution, derivation, audit action or prompt edit occurred.

The search stops here under the bounded brief. Reuse of G0c as a new execution dependency still needs its original `ckcore.py`, `turns.py`, complete primary construction and cited outputs recovered from the original campaign storage, or a separately authorized reconstruction with its own provenance and review. The prior source survey's finite, corrected referee scope remains unchanged.

Full search outputs, archive hashes/member results, the temporary-path check, source-preservation check and final artifact hashes are in this directory. `DELIVERY_MANIFEST.json` binds the delivered files.
