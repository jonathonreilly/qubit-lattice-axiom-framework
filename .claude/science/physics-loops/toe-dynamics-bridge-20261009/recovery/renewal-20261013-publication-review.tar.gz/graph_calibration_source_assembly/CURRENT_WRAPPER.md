# Conditional calibration stability for finite energy measurements

This source candidate packages a checked conditional perturbation theorem.
Uniform ideal energy-graph bounds improve the sufficient calibration scale
from the earlier \(\epsilon=o(h^2)\) to \(\epsilon=o(h)\) on a kinetic
window with integrated drive budget \(b_h=O(h^{-1})\). The more precise
condition is \(\epsilon b_h\to0\). The earlier sufficient bound remains
valid. Necessity for the fixed-slot continuum model is not established.

The mathematical result received ordinary conditional source acceptance on
2026-10-13. This assembly adds no independent mathematical review, retained
audit status, physical realization or empirical prediction. The complete
unchanged proofs and analytic checks follow this wrapper. Their historical
status sentences and notation remain visible; the current scope is fixed
by this wrapper and the archived final acceptance/review.

<!-- CURRENT-SCOPE: uniform_C_G_for_full_theorem -->
<!-- CURRENT-SCOPE: calibration_order_p_plus_one_separate_from_2n_plus_one -->
<!-- CURRENT-SCOPE: assumed_common_H_not_retained_status -->
<!-- CURRENT-SCOPE: ideal_regular_law_is_an_application_assumption -->
<!-- CURRENT-SCOPE: growing_C_G_single_propagator_only -->
<!-- CURRENT-SCOPE: abstract_controls_do_not_prove_continuum_necessity -->

## Conditional theorem

Let \(H\ge0\) be the exact common self-adjoint free energy on the identified
Hilbert space, \(G=1+H\), and \(S=G^{1/2}\). Let \(h>0\),
\(\epsilon\ge0\), and all error constants be nonnegative. The ideal and
actual interactions differ by the real drive \(f_h(t)\Delta V\), where
\(\Delta V\) is bounded self-adjoint and

\[
 b_h=\int_0^{T_h}|f_h(t)|\,dt<\infty,\qquad
 \|\Delta V\|\le d_0\epsilon,\qquad
 \|[H,\Delta V]\|\le d_1\epsilon.
\]

The ideal Hilbert-space interaction-picture unitary starts at identity.
Assume the ideal and perturbed Hilbert evolutions satisfy the bounded
interaction integral equations used in Appendix A. Actual graph-domain
invariance is proved by the construction, rather than included here as an
assumption.

The last commutator is a genuine bounded graph-domain extension. The
perturbation preserves \(D(H)\); equivalently, the bounded commutator-form
criterion supplies that invariance. The free observable, embedding and
spectral instrument are common by assumption. Their physical realization
and the two error bounds are not derived in this packet.

For every prefix time, assume genuine ideal forward and inverse graph maps
with one constant \(C_G\ge1\), uniform over the parameter family:

\[
 \|G Y_h(t)G^{-1}\|,\quad
 \|G Y_h(t)^*G^{-1}\|\le C_G.
\]

Assume the stated strong graph evolution regularity. In the bounded-control
source setting, strong graph continuity follows at each fixed parameter
from its bounded first commutator. A uniform time modulus or operator-norm
Bochner measurability is not required. Mere norm inequalities are not used
as a replacement for an existing graph-space evolution.

Put \(d_G=d_0+d_1\) and \(x_h=C_G^2d_G\epsilon b_h\). Then the actual
evolution and its inverse preserve the graph domain and satisfy

\[
 \|G Y_{{\rm act},h}^{(*)}(t)G^{-1}\|\le C_G e^{x_h},
 \qquad
 \delta_G\le C_G(e^{x_h}-1),
\]

where \(\delta_G\) bounds both forward and adjoint full-graph differences
uniformly in prefix time. With \(D\) either propagator difference,

\[
 \|D\|\le d_0\epsilon b_h,\qquad
 \delta_S:=\sup\|SDS^{-1}\|
 \le\sqrt{d_0\epsilon b_h\,C_G(e^{x_h}-1)}.
\]

These are consequences of a graph-space Dyson construction in the ideal
interaction frame. A separate inverse construction gives the adjoint graph
bound; it is not inferred by equating oppositely weighted adjoint norms.
Vectorwise integrals have an integrable norm majorant, and their ordered
series converges in graph-operator norm.

Thus \(\epsilon b_h\to0\) gives uniform full and half graph differences
of order \(\epsilon b_h\). If \(\epsilon b_h\) is merely bounded, actual
graph norms remain uniformly bounded, but ideal-law convergence does not
follow from that fact alone. The case of zero perturbation or zero drive
has exactly zero difference.

For fixed kinetic resources \(b_h\le C/h\), the sufficient requirement is
\(\epsilon=o(h)\). Write the calibration order as \(p\ge0\), fixed, with
\(\epsilon=O(a^{p+1})\). Then

\[
                         a=o\!\left(h^{1/(p+1)}\right)
\]

is sufficient. The symbol \(p\) denotes calibration order only. It is
distinct from the number \(2n+1\) of unitary factors in an \(n\)-record
measurement chain. No optimality is claimed for this physical calibration
scale.

## Fixed finite measurement chains and first energies

For fixed times and common Borel bins, put
\(P_j=Y_h(t_j)^*1_{B_j}(H)Y_h(t_j)\) and
\(Q_h=Y_h(t_f)P_n\cdots P_1\); use the same construction for the actual
evolution. Common spectral projections contract both graph spaces. If
\(L_A\ge1\) bounds every ideal and actual unitary factor on the graph of
\(A=G\) or \(S\), finite telescoping gives

\[
 \|A(Q_{{\rm act},h}-Q_h)A^{-1}\|
 \le(2n+1)L_A^{2n}\delta_A.
\]

The comparison allows arbitrary common Borel bins because these exact
projections are unchanged between the models. It does not remove boundary
regularity assumptions from an ideal weak-limit theorem. The number of
records and the resource constants remain fixed.

For a fixed normalized state with finite first energy,
\(M=\operatorname{Tr}(G\rho)<\infty\), let \(L_{\rm act},L_{\rm id}\)
bound the two history half-graph norms, and let \(d\) bound their difference.
The unnormalized final-energy means obey

\[
 |m_{{\rm act},h}-m_h|
 \le (L_{\rm act}+L_{\rm id})dM.
\]

This follows from the bounded factorization of
\(H^{1/2}Q_h\rho^{1/2}\). It requires neither a second initial energy
moment nor quasifreeness. For moving normalized states with
\(d_E=\|S(\rho_{\rm act}-\rho)S\|_1\to0\), the extra mean error is at
most \(L_{\rm act}^2d_E\). Bounded history comparisons require only ordinary
trace convergence; any fixed normal initial state is allowed for them.

Uniform full and half graph bounds also give uniform first-energy tails
for each fixed finite-energy state. For moving states, the precise assertion
is \(\lim_{R\to\infty}\limsup_{\rm joint}\) of the tail equal to zero.
A convergent sequence or a weighted-trace-compact family has a genuine
uniform tail modulus. Convergence at a missing limit point alone does not
give uniformity over every arbitrary punctured continuum neighborhood.

For a limiting-law application, assume the ideal finite-history weak law
at its regular bins or separately justified common zero-gap convention.
Together with the graph tail argument, the comparison transfers branch
masses and unnormalized first means. For a selected history whose limiting
probability is positive, conditional weak convergence and first-moment
convergence yield conditional \(W_1\) convergence on nonnegative energies.
Zero-probability normalization is not covered. Finite unions of recorded
histories sum positive branch measures, rather than chain amplitudes.

## Scope of the analytic controls

The two-level resonant calculation shows failure of a generic ideal-law
convergence guarantee at \(\epsilon=kh\) within the abstract assumptions.
It does not prove necessity for the nonzero fixed-slot continuum model.
The bounded-commutator measurability example shows why vectorwise graph
integrals are used; it is not a physical obstruction. The escaping-energy
rotation shows why the growing-\(C_G\) comment cannot replace uniform
graph bounds in the full protocol and tail theorem.

In particular, formulas involving growing \(C_G\) diagnose the
single-propagator difference only. Finite products carry additional graph
powers, and uniform tails need separately justified bounds. No theorem for
growing resources, growing record count, arbitrary energy-ball families,
unspecified instruments, massless or zero-frequency limits, or physical
continuum realization is exported here.

## Exact dependencies and publication boundary

| Claim or application | Premise and current status |
|---|---|
| Abstract graph stability | Exact common \(H\), graph regularity, uniform two-way ideal graph bounds and the two error bounds are explicit assumptions; the unchanged root V2 proves the implication. |
| Fixed finite deterministic instrument comparison | Requires the same spectral instrument and fixed record count; proved in the included argument. |
| Weak-law, mean and conditional \(W_1\) application | Assumes an established regular ideal finite-history weak law and finite first initial energy for unbounded conclusions; graph tails and transfer are supplied here. |
| Supplied model's ideal graph theorem | Historical postmeasurement sources are archived as premise provenance with their \(J=\Gamma C\) precision. This candidate does not silently promote them to a new canonical retained dependency. |
| Future canonical energy-tail publication | Not supplied at this freeze. Root will provide it after its regular PR publication; no dependency edge, source path, PR identity or base head is invented. |
| Physical realization and calibration | Remain assumptions; no realization family, detector model or empirical validation is supplied. |

The abstract implication is complete without a newly published tail parent.
Connecting this application to that canonical publication is a later
source-integration step, not a missing proof inside the abstract theorem.
This packet creates no driver, branch, PR or audit verdict.

## Preserved proofs, correction and exposure history

Appendices A--D contain exact immutable bodies: root V2/192 lines,
independent derivation/289, independent evidence/192, and separate analytic
review evidence/206. Extraction records bind every body to its original
hash. Full comparison/194 and separate review/108, plans, seals, read
receipts and final acceptance/review are archived with their source closures.

Root V1 incorrectly asserted that the \(TR\) derivative directly vanishes.
V2 uses its commutator equation and uniqueness. The exact V1, V2 and diff
remain archived. V1 was sealed before the independent preliminary route
message; V2 followed that message and preceded the complete independent
proof. The separate exposed reviewer did not read the independent target.
All used the same selected model family and shared graph premises.

Historical pending/status sentences in the appended sources are preserved
as history. The final review requires uniform \(C_G\), the calibration
notation used above, and reading historical “retained common-H” as assumed
common-H, not audit retention. These are wrapper precisions, not silent
changes to frozen bodies.

The root's read-only wrong-filename attempt and subsequent complete recovery
are preserved in its independent-read receipt. Source checks execute zero
mathematical predicates. They validate bytes, extraction boundaries and
declared archive identities, not the correctness of the theorem. The read
coverage record distinguishes full new wrapper/review reads from reused
unchanged proof coverage and metadata-only archive checks.

No editable prompt, physical axiom, audit status or original scientific
source was changed in this assembly. Ordinary source acceptance applies to
the reviewed mathematics; this current wrapper still awaits root source
acceptance and publication integration.
