# Source assembly plan: graph calibration sufficient scale

Renewal window: 2026-10-13 21:37:33 UTC through 2026-10-14 21:37:33 UTC.
This source-only assignment targets a checkpoint at22:00 and a complete
freeze at22:15 if the work is ready. The absolute renewal end is fixed.

## Exposure and authority

I authored the frozen independent graph perturbation derivation289 and
analytic evidence192, then the exposed comparison194 of root V2. Those
complete readings and the shared ideal graph/protocol premises are prior
source exposure. This assignment assembles already reviewed mathematics;
it is neither a new independent derivation nor an independent review of my
own proof. No new scientific conclusion is assumed from a publication goal.

The root has supplied exact target identities and ordinary final acceptance.
The separate review108/evidence206 and final acceptance/review will be read
fully before their findings are used. The root-provided procedure reuse
check was read: all18 listed instruction/procedure identities are reported
unchanged. Existing verified instruction coverage is reused, not a claim
that every listed procedure has been executed in this assignment.

## Authorized output and exclusions

Write only under this graph_calibration_source_assembly directory. R, CW
and Git remain read-only. Do not inspect unfinished energy-tail preparation,
invent its future canonical source or dependency edge, assume a pending
base head, create a driver or PR, execute proposed science, change audit
status/prompts/axioms, subdelegate, or message other chats. Root owns source
acceptance and publication. Preserve the selected model and reasoning effort.

Produce one readable current candidate with explicit abstract hypotheses,
the full unchanged accepted root V2, independent derivation and analytic
evidence, and a bounded archive of exact review/repair/provenance sources.
All historical bodies remain byte-identical. Current wrapper precisions
must be explicit rather than silently rewriting an archived proof.

## Mandatory export precisions

1. Uniform forward/inverse ideal C_G bounds and ideal graph regularity are
   assumptions of the full theorem. Growing-C_G formulas diagnose only a
   single propagator difference and do not imply a growing-resource protocol.
2. Denote the calibration order by p, separately from the measurement-chain
   count 2n+1. The sufficient scale is epsilon b->0, hence epsilon=o(h)
   when b=O(1/h), or a=o(h^(1/p)) if epsilon=O(a^p), p>0 fixed.
3. The exact common H, common instrument and bounded error/commutator are
   assumed; the source packet does not prove a physical realization or
   confer retained/audited status.
4. Application assumes an established ideal regular finite-history law and
   the appropriate first-energy theorem. The future canonical energy-tail
   parent is not yet supplied; do not add a fabricated citation edge.
5. Preserve V1, the exact V2 repair, seal chronology and source exposures.
   The two-level resonance, measurability and escaping-energy controls keep
   their stated abstract scope. No necessity for fixed continuum slots is
   inferred.

## Work and verification sequence

Read and bind all newly authorized review/status sources. Inventory the
unchanged relied proof bodies and required recovery artifacts. Resolve
their claims against actual contents, keeping partial/incomplete historical
checks distinct from final acceptance. Draft the wrapper with a dependency
table and exact scope. Assemble full proof/evidence bodies with extraction
markers and byte/hash identities, then read every changed wrapper and all
extraction boundaries; reuse complete unchanged body coverage only at exact
verified hashes.

Create a deterministic source-check helper that checks identities, extraction
equality, declared scope markers and archive closure. It must report zero
mathematical predicates and no scientific certification. Run only this
bookkeeping helper; preserve its report and any recovery failures. Record
full changed-read coverage and source identities, then freeze the packet.

Missing publication inputs must remain explicit rather than blocking the
standalone conditional theorem or being filled with guessed future sources.
