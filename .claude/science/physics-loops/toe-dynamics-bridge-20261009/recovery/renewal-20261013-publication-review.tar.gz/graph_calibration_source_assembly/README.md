# Graph-calibration source assembly

Start with [CURRENT_CANDIDATE.md](CURRENT_CANDIDATE.md). Its current wrapper
states the conditional theorem and mandatory export precisions, followed by
four complete unchanged proof/evidence bodies. [CURRENT_WRAPPER.md](CURRENT_WRAPPER.md)
is the same front matter without the appended historical sources.

The result is the sufficient condition epsilon b_h->0, hence epsilon=o(h)
for b_h=O(1/h), under uniform ideal forward/inverse energy-graph bounds and
the stated common-H calibration. Fixed finite histories, finite-first-energy
means and positive-probability conditional W1 follow at the explicit scope.
This packet asserts no necessity for the fixed-slot continuum model.

The source-only assembly is ready for root review after its final freeze.
Publication integration still needs the exact canonical energy-tail parent
that root will supply after that regular PR is published. No dependency edge,
pending base head, branch, driver or PR is created here. The abstract theorem
remains explicitly conditional on ideal graph bounds and the regular ideal
law needed for application.

The archive preserves root V1/V2 and their exact correction, the independent
packet, both exposed checks, final acceptance/review, predecessor premise
snapshots, plans, seals and the recorded read-recovery failure. See
[PROVENANCE.md](PROVENANCE.md), [RECOVERY_RECORD.md](RECOVERY_RECORD.md),
[DEPENDENCIES.json](DEPENDENCIES.json) and [READ_COVERAGE.json](READ_COVERAGE.json).

Run the local source check with:

```sh
python3 source_check.py
```

Adding `--verify-originals` also compares the archived bytes with the recorded
local originals when they are available. Both commands are read-only by
default. SOURCE_CHECK_REPORT.json preserves the assembly's original check;
if saving a later report, choose a new filename rather than overwriting a
frozen record. The helper executes zero mathematical
predicates and no scientific runtime. Its report checks hashes, extraction
equality, exact diff and declared archive closure only. It is not a science
driver, proof certificate, audit verdict or substitute for mathematical review.

[FINAL_FREEZE.json](FINAL_FREEZE.json) binds the completed candidate, archive,
helper, report and coverage records. Historical source bodies and their old
pending-status sentences remain unchanged; the current accepted mathematical
scope is stated in the wrapper and final root review.
