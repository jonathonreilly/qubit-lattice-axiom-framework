# Preserved failures and recovery

1. Root V1 asserted that both inverse products had directly zero derivative.
   The TR derivative is actually a commutator. The exact V2 repair uses
   uniqueness for that commutator equation; all estimates and conclusions
   survive. V1, V2, the exact diff and both seals are preserved byte for byte.

2. The root's independent-read receipt records read-only attempt9d41ca:
   a guessed DECISIVE_ANALYTIC_EVIDENCE filename was absent. The actual
   ANALYTIC_EVIDENCE file was then completely read in outputf67d75. The
   immutable receipt is archived as
   ENERGY_GRAPH_PERTURBATION_ROOT_INDEPENDENT_READ.json. This packet preserves
   that exact receipt and does not invent a missing raw terminal transcript.

3. The assembly plan used p as a total calibration exponent. The fully read
   final root review requires p>=0 as the order in a^(p+1). The current
   wrapper follows the latter convention, while the original sealed plan
   remains unchanged. This is a notation alignment, not new science.

4. The first wrapper read found a literal accidental plus sign joining two
   scope sentences. It was removed before candidate extraction and final
   freeze; the affected context is included in final changed-read coverage.
   No frozen historical proof or mathematical estimate was changed.

There was no source-check failure, scientific runtime or proposed-science
execution during this assembly as of this record. If the deterministic
check fails before freeze, its report must be preserved and this statement
updated rather than replacing the failed attempt silently.
