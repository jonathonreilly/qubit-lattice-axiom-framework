# Root final review of conditional energy-graph calibration sharpening

Accept rootV2/0906b061 under fixed uniform ideal forward/inverse G=1+H graph
bounds, exact common H and spectral instrument, bounded self-adjoint control
error and bounded first commutator error O(epsilon), and the stated strong
graph evolution regularity. The small quantity is epsilon b, where b is the
integrated absolute drive. Thus b=O(1/h) permits epsilon=o(h), improving the
previous sufficient epsilon=o(h²) scale without falsifying that older bound.

Full rootV2 read b013fe, independent289 read5b6e2e/0d2181 and evidence192
readf67d75; independent14members/8sourcepairs verified58c902. Full exposed
comparison194 read6ff709;17members/12pairs verified2d0fd7. Separate source-
exposed review108 readbc9020 and evidence206 read3f5da6, with final unchanged
identities verified here:31members/23pairs. Separate reviewer did not read
the independent derivation or comparison. All use the same selected model
family and shared graph premises; no model diversity or retained audit claimed.

Load-bearing checks are graph/Hilbert compatibility of vectorwise Dyson
integrals, reverse evolution and correct inverse products, interpolation of
bounded weighted operators, exact2n+1 history factor count, finite-first-energy
Hilbert-Schmidt/trace-form pairing and moving-state lim_R limsup_joint tails.
The non-norm-Bochner-measurable graph-generator example confirms why vector
integrals matter. The resonant two-level bounded-primitive calculation confirms
that epsilon=O(h) alone is insufficient in the abstract class; it establishes
no optimality for the fixed-slot continuum family. No numerical execution is
needed or claimed for these explicit analytic calculations.

V1's directly vanishing derivative assertion for TR was false as written.
The preserved V2 diff33c2e05a repairs it by the commutator equation and
uniqueness; both independent comparisons confirm the correction. RootV1 was
sealed before the target worker's preliminary route message; V2 followed
that message but preceded the independent complete proof. The chronology is
explicit, not inflated to independent discovery of all shared premises.

Mandatory export precisions: G6(iii) concerns single-propagator differences
only when C_G grows. It does not replace uniform graph bounds in the finite-
chain/tail theorem; the separately checked escaping-energy rotation is a
countercontrol to that broader reading. Write calibration order as p>=0,
epsilon=a^(p+1), distinct from chain count N=2n+1. The resulting sufficient
scale is a=o(h^(1/(p+1))). Read G6's 'retained common-H' as assumed common-H
premises, not retained audit status. Take h>0, epsilon>=0 and nonnegative
error constants. These precisions change no fixed-resource bound or conclusion.
Original frozen sources remain unchanged; this review governs accepted scope.

For any fixed finite regular ideal history with positive limiting success,
actual weak laws, first moments and conditional W1 transfer. Only finite initial
first energy is needed. Moving densities converge in weighted trace norm;
arbitrary first-energy balls, growing record counts, unspecified instruments,
physical embeddings and continuum-model necessity are not proved. Common
Borel bins are allowed in deterministic comparison, not in an unqualified
ideal limiting-law statement. No massless/zero-frequency/3D realization is
inferred. No formal domain proof or retained verdict was applied.

This is accepted conditional mathematics preserved for later source assembly
and a regular PR. No PR exists yet for this sharpening, threshold-protocol
composition or the newly assembled postmeasurement tail package. The relevant
earlier pair, kinetic and drive results already have regular PRs. Editable
prompt files changed:none. All scientific checks completed before the fixed
2026-10-13T16:42:30Z deadline; subsequent work must be closeout only.
