# Root plan: sharper actual-cell energy transfer

Target: re-examine the sufficient epsilon=o(h^2) calibration scale now that
uniform forward/inverse ideal D(H) graph bounds are available. Keep every
common-energy, bounded-control and bounded-commutator-error premise unchanged.
No actual physical embedding is constructed. Determine a valid scale, not a
predetermined answer; preserve a failure if the weighted evolution argument fails.

Pre-plan reasoning disclosed: root has already reasoned that interpolation of
the old unweighted and full-graph Duhamel differences would give a half-graph
O(epsilon/h^(3/2)) bound. More promising, the interaction picture relative to
the ideal evolution has generator Y* DeltaV_I Y. The accepted ideal uniform
forward/inverse full graph bounds and ||DeltaV||+||[H,DeltaV]||=O(epsilon)
may bound that generator in the graph space by O(epsilon), yielding a weighted
Dyson bound exponential in epsilon integral|lambda c|, rather than an absolute
commutator bound proportional to epsilon b^2. This suggests epsilon=o(h), but
requires explicit domain, strong measurability, inverse-evolution, identification
and projection-chain checks. No other agent has supplied this target finding.

Read exact root306, independent390 with current J precision, their comparison
and full412-line evidence. Derive the abstract weighted perturbation lemma from
norm-convergent graph-space Dyson series, prove consistency with the Hilbert
unitary evolution, then apply both graph weights and actual instrument chains.
Separate finite-state or weighted-compact initial tails from the correct joint
limit for varying states. Establish direct unnormalized moment bounds and
positive-probability conditional/W1 implications only if justified. Any numerical
or Lean check would have separately bounded scope; no runtime is planned here.

Freeze a complete root proof with exact sources before receiving a separate
checker finding. Deadline2026-10-13T16:42:30Z applies to this work too. Unfinished
or unreviewed results must be preserved as such, never rushed into acceptance.
