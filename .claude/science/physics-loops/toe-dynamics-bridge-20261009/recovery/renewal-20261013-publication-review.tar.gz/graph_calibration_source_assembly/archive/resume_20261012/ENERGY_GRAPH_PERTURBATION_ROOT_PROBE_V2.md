# Conditional sharpening of actual energy transfer by graph interaction picture

Root original derivation. Status at seal: proposed conditional theorem, not yet
independently checked. Plan sealed16:16:39UTC after disclosed pre-plan reasoning.
No independent target findings have been received. No new physical axiom,
embedding, instrument, channel selection or actual continuum construction.

## G1. Precise abstract premises

Let H>=0 be self-adjoint on Hilbert space, G=1+H and S=G^(1/2).
Fix a finite kinetic horizon. The ideal interaction-picture unitary Y(t)
starts at identity and its inverse obeys, uniformly for every prefix time,

  ||G Y(t) G^-1||, ||G Y(t)* G^-1|| <= C_G.                 (1)

Here these are genuine bounded extensions on the graph space D(H), and Y(t)
and its inverse preserve that domain. Strong continuity on this graph space
holds for each fixed parameter, not necessarily with a uniform time modulus.
The accepted postmeasurement q2 argument supplies uniform constants (1) for
its ideal drive families; the separately checked threshold version supplies
it on that extension. This note is an abstract implication from (1).

Ideal and actual Hamiltonians have exactly common free H and differ by
lambda c(t) DeltaV, where c is real measurable, b=integral|lambda c(t)| finite,
DeltaV is bounded self-adjoint and maps D(H) into itself, and its commutator
has a bounded extension satisfying

  ||DeltaV||<=d0 epsilon, ||[H,DeltaV]||<=d1 epsilon.       (2)

The common H and domain/error hypotheses are assumptions. Set dG=d0+d1.
For x in D(H), G DeltaV x=DeltaV Gx+[H,DeltaV]x, hence
||G DeltaV G^-1||<=dG epsilon. Free conjugation preserves this bound.
The original bounded-control/commutator premises ensure graph strong
measurability: on D(H), G V_I(t)G^-1=V_I(t)+[H,V]_I(t)G^-1 is strongly
continuous before multiplication by measurable c. Each fixed-parameter graph
Dyson series for the ideal evolution is consequently well-defined. Thus the
strong graph continuity premise above is satisfied in the source setting.

## G2. Relative propagator and graph construction

Let Y_a be the actual Hilbert-space interaction-picture evolution and define
T=Y*Y_a. Differentiation in the bounded interaction-picture integral equations
(or their absolutely continuous strong derivatives a.e.) gives

  T'=-i lambda c(t) B(t) T,  B(t)=Y(t)* DeltaV_I(t) Y(t).  (3)

Every factor in B preserves D(H). Equation(1) yields

  ||G B(t) G^-1|| <= C_G^2 dG epsilon =: k_G.             (4)

B is strongly measurable on the graph space; its norm majorant multiplied
by |lambda c| is integrable. On the Banach/Hilbert graph space with norm
||Gx||, construct the ordered Dyson series. The nth term has norm at most
(k_G b)^n/n!. Hence it converges in operator norm after conjugating by G,
with strong Bochner integrals understood vectorwise (operator-norm
measurability is unnecessary). Its sum T_G satisfies the graph-space
integral equation and

  ||G T G^-1|| <= exp(k_G b),
  ||G(T-I)G^-1|| <= exp(k_G b)-1.                        (5)

To justify the notation T rather than assuming graph invariance: embed the
graph-space integral equation continuously into the original Hilbert space.
For each initial vector in D(H) its solution satisfies the Hilbert integral
equation, which has uniqueness for an integrable bounded generator. It equals
Y*Y_a on D(H). This identifies the bounded graph solution and proves actual
forward invariance. Solve the right equation R'=i lambda c R B, R(0)=I,
by the reverse ordered series. It has the same absolute bounds. The product
rule a.e. on each graph vector gives (RT)'=0. For K=TR it instead gives
K'=-i lambda c B K+i lambda c K B, K(0)=I. Uniqueness of this bounded
operator integral equation (the difference is bounded by an integrable
coefficient times its norm) implies K=I as well. Thus both products equal
identity, R=T^-1=T*, and R has the same graph bounds. This proves actual
inverse invariance, without assuming Y_a already has uniform graph bounds.

## G3. Uniform actual bounds and differences

Since Y_a=YT and Y_a*=T*Y*, (1) and (5) imply, with x=C_G^2 dG epsilon b,

  ||G Y_a^(*) G^-1|| <= C_G exp(x),
  ||G(Y_a^(*)-Y^(*))G^-1|| <= C_G (exp(x)-1).            (6)

Both signs are separate products, not an illicit equality of weighted
adjoint norms. Hilbert unitarity gives the usual Duhamel bound
||Y_a^(*)-Y^(*)||<=d0 epsilon b (or the trivial cap2).
Complex interpolation of the Hilbert scale D(G^theta), or its three-lines
proof for <u,G^z D G^-z v>, yields

  ||S D S^-1|| <= sqrt(||D|| ||G D G^-1||).              (7)

Use finite spectral cutoffs/dense analytic vectors for the three-lines proof
then bounded extension and closure. G>=1 makes inverse powers bounded;
this is an interpolation of linear operator norms, not operator monotonicity
applied to an ordered square. Applying (7) to each difference gives

  delta_S <= sqrt(d0 epsilon b C_G (exp(x)-1)).           (8)

Also actual and ideal half-graph norms are bounded by the square roots of
their full-graph norms, since their Hilbert norms are1. Thus epsilon b->0
suffices for convergence on both graph spaces. For b<=C/h this is epsilon=o(h),
strictly weaker than the earlier sufficient epsilon=o(h^2) estimate. If b=0
or d0=0, the exact difference is zero. Nothing here asserts this scaling is
necessary or optimal; cancellations may permit still weaker hypotheses.

The earlier unweighted commutator estimate epsilon(b+b^2) remains a valid
coarser bound. The relative graph difference G D G^-1 does not imply a
small unweighted [H,D]. There is no contradiction: uniform ideal graph
bounds use energy structure absent from that earlier coarse estimate.

## G4. Fixed measurement protocols

Let Pi_j=1_{B_j}(H) and P_j=Y(t_j)* Pi_j Y(t_j); actual P_a,j uses Y_a.
Each Pi_j commutes with G,S and is a contraction on both graph spaces.
For a fixed number n of bins, the history amplitude with final drive is
Q=Y(t_f)P_n...P_1, and Q_a is the identical construction using Y_a.
It is a product of N=2n+1 unitary factors and n projections. A telescoping
product bounds each graph difference by

  ||A(Q_a-Q)A^-1|| <= N L_A^(N-1) delta_A,               (9)

for A=G,S, where L_A>=1 bounds every ideal/actual unitary factor and delta_A
bounds their differences. Projections contribute factor1 and are common.
The bound is uniform over Borel bins and protocol times on the fixed horizon,
for this actual/ideal comparison only; n and the resource constants are fixed.
The ordinary norm analogue also holds, and all history amplitudes contract
on the original Hilbert space. No dense-monitoring limit is asserted.

## G5. Energy moments, tails and limiting laws

For a positive normalized finite-energy density rho define M=Tr(G rho).
Let L bound ideal and actual half-graph history amplitudes, and d the
half-graph difference in (9). Their unnormalized final energy moments are
m_Q=||H^(1/2)Q rho^(1/2)||_HS^2. H^(1/2) S^-1 is a contraction, so

  |m_Qa-m_Q| <= (L_a+L_i) d M.                          (10)

Indeed each Hilbert-Schmidt norm is at most L_(a/i) sqrt(M), and their
difference norm at most d sqrt(M); apply the difference of squared norms.
This argument needs only initial first energy, not a second moment.

For varying rho_a with d_E=||S(rho_a-rho)S||_1->0, an additional moment
error is at most L_a^2 d_E: the conjugated positive form
S^-1 Q_a* H Q_a S^-1 is bounded by L_a^2 in norm and pairs with the signed
weighted trace-class difference. Branch probabilities differ by the ordinary
product norm and ||rho_a-rho||_1. No unjustified continuity of square roots
in the weighted trace norm is used here.

For fixed rho, uniform full and half graph bounds reproduce the accepted
cutoff tail argument for all Q_a whenever epsilon b remains bounded. The
constants are uniform and the initial tail modulus is common; hence actual
branch final energies are uniformly integrable. For varying rho_a converging
in d_E, compare the positive tail form
S^-1 Q_a* H 1_{H>R} Q_a S^-1, whose norm is at most L_a^2. Thus the actual
initial-state replacement changes each tail by at most L_a^2 d_E uniformly
in R. This gives lim_R limsup_joint tail=0; it does not assert uniform tails
on every arbitrary punctured continuum parameter neighborhood. Weighted
compact initial families or a convergent sequence do give uniform tails.

Combine (10) and ordinary actual/ideal norm convergence with an already
proved ideal weak finite-history law. The actual branch mass and first
moment converge. For any selected history of limiting probability p>0,
normalization is valid eventually and its conditional final-energy law
converges weakly and in first moment, hence in W1 on [0,infinity). Zero-mass
histories retain only unnormalized conclusions. Uniform conditional claims
require a common positive probability floor and the relevant compact-family
initial controls. The ideal weak-limit regular-boundary premises remain
required; arbitrary bins in (9) do not erase them.

## G6. Source application, limits and decisive checks

Under the accepted fixed-resource ideal q2 hypotheses, every retained common-H
actual-cell error pair of order epsilon can use this abstract sharpening.
If epsilon=a^(N+1), the sufficient joint scale becomes
 a=o(h^(1/(N+1))) instead of the earlier a=o(h^(2/(N+1))).
This is conditional on both error norms (2) and the ideal graph theorem;
it neither builds a physical embedding nor applies to arbitrary energy-ball
initial families. The old published sufficient estimates are not false and
are not silently edited. The threshold protocol application remains dependent
on its complete accepted composition, not merely on the marginal law.

Checks: (i) finite-dimensional H=0 reduces(3)-(8) to standard bounded-generator
stability and gives zero energy moments; (ii) DeltaV commuting with H gives
d1=0, and the graph-generator estimate uses only ideal graph constants;
(iii) if ideal graph constants grow with h, the correct condition is
C_G^2 epsilon b->0 and C_G expm1(C_G^2 dG epsilon b)->0, not automatically
epsilon=o(h); (iv) an energy-ball family without common initial tails is
still excluded by the archived escaping-energy countercontrol; (v) (6)
requires the inverse ideal graph bound, so bounded forward action alone is
not substituted. These are analytic checks, no numerical/Lean executions.

Open at this seal: independent reconstruction and complete source-exposed
comparison; no regular PR, retained verdict or formal domain verification.
