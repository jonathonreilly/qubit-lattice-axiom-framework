# Precision addendum to the postmeasurement acceptance

This supersedes only the no-correction wording in root acceptance59f1556c and
reviewaac66b22. The finite-first-energy theorem and actual-cell graph transfer
remain accepted conditionally, with the operator convention stated correctly
below. This is a real notation/type correction, missed by the original author,
exposed comparison and root read. No frozen original is overwritten.

Fresh threshold-protocol derivation702/2c29d973 and evidence223/bd2f45c3 identified
independent390/9597693a lines79--80: the scalar Born-kernel identification calls
J antiunitary. The exact parent convention is J=Gamma C, where Gamma and the
scalar conjugation C are both antiunitary. Therefore J is linear, unitary and
energy intertwining. Corrected859/c9e8f391 lines452--454 and threshold788/0406c0e3
lines442--445 explicitly fix this convention. Root reread these source locations
and all occurrences of J in390/evidence170/comparison239/evidence412. Only390
lines79--80 contain J; later graph/inverse/CAR calculations use Gamma directly.

The corrected reading of line80 is:

    lambda Delta(p,q) I_h,T(E(p)+E(q)), with J=Gamma C the linear unitary energy isometry.

This makes the ordinary linear integral-kernel statement type-correct. Since
J is onto and energy intertwining, ||E beta1||_HS=||E beta1 J||_HS; its kernel
then gives the same bound by2 h^2 integral e^2 r(e)|I_h,T(e)|^2de. Temporal
Plancherel and all subsequent estimates, constants, domains and quantified
conclusions are unchanged. This argument does not replace Gamma by J in the
self-dual covariance or in the inverse/right-weight proof. Gamma remains
antiunitary there, as required by CAR conventions.

A source assembly may preserve the historical390 byte for byte, provided the
current wrapper clearly supplies this correction immediately before its use
and identifies the earlier no-correction wording as superseded. Alternatively
a new version must preserve the original and record this exact single-line
delta. Neither option silently edits an original freeze or treats an ordinary
analytic correction as a formal audit verdict.

The root's separate analytic scope check is complete. The original author and
fresh protocol comparator are checking this same correction in source-exposed
contexts; their later records will be additional evidence, not backdated here.
No new numerical, Lean or other scientific runtime was executed. No physical
axiom, editable prompt, main branch or retained audit changed.
