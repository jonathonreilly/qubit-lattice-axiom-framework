# Energy tails after fixed finite measurement protocols

Status: provisional conditional root derivation, following the sealed plan.
No independent solution to this new target has been opened. This proof uses
already checked strict-gap chirp estimates and addresses Q25 of prepared512.
It changes no frozen parent and makes no retained, numerical or Lean claim.
Section5 explicitly depends on the prepared-multitime probability theorem;
its newly frozen exposed comparison still awaits root reading. The tail bound
U3 itself does not depend on those limiting-probability assertions.

## 1. Exact setting and target

Use the supplied massive free CAR model and notation of initial-state407
and strict-gap chirp515V2/850. On K let D be the real signed generator,
E=|D|>=m>0, P its positive spectral projection and P_-=I-P. The conjugation
Gamma exchanges P and P_- and commutes with E. On fermionic Fock over PK,
H=dGamma(E), N=dGamma(I), A=I+H and S=A^(1/2). Thus N<=H/m.
The controls are the fixed real compact smooth slots; BV amplitude/frequency,
positive strict gap above2m and finite kinetic horizon retain all parent
hypotheses. No threshold-crossing extension is used here.

For each small h and prefix tau, the Fock interaction implementer is Y and
the real unitary one-particle map is Z. Use the convention
Y*b(k)Y=b(Z*k). Put u=PZP, beta=PZP_-, gamma=P_-ZP and d=P_-ZP_-.
The parents supply, uniformly over the fixed resources and prefixes,

  ||Z-I||<=C eta_h, ||E(Z-I)||<=C eta_h,
  ||E(Z-I-K1)||_HS<=C eta_h,
  eta_h=sqrt(h log(2+h^(-2))).                         (U1)

Weighted products in U1 are their already justified bounded extensions.
We will also justify from the parent spectral kernel

  ||E beta||_HS<=C.                                   (U2)

The target is a uniform integrability assertion for finitely many fixed
Lueders projections P_j=Y_j* 1_(B_j)(H) Y_j and C_h=P_n...P_1. Bins
are arbitrary Borel sets for the tail bound; regularity is required only
when invoking the checked limiting probability theorem. For a final prefix
tau_f and any fixed normal rho with Tr(rho H)<infinity, prove

 lim_(R->infinity) sup_(h small, allowed drives)
 Tr[H 1_(R,infinity)(H) Y_f C_h rho C_h* Y_f*]=0.       (U3)

This is Q25, since A_h(tau_f)=Y_f* H Y_f. The number n is fixed. These
are coarse projective instruments, not a claim about a continuous-spectrum
fine measurement channel, infinitely many observations, or arbitrary Kraus
operators. The constants may grow with n.

## 2. Second one-particle weight and inverse implementer

The exact pair amplitude in chirp H21 gives the output-weight bound

 ||E beta1||_HS^2
   <=2h^2 integral e^2 r(e)|I_(h,T)(e)|^2 de.           (U4)

Indeed the output particle energy squared is bounded by the total pair
energy squared in the nonnegative kernel integral. No exact factor for
this second moment is being inferred from the first-moment identity.
For b(e)=e^2 r(e), extended by zero, the general-control parent threshold
analysis gives an integrable correlation kernel C_b(t)=integral b(e)e^(ite)de.
Multiplication by the fixed polynomial preserves the smooth rapidly decaying
interior and the linear threshold vanishing that produced O((1+|t|)^(-2))
in the parent argument. In particular ||C_b||_1<infinity. Exact finite-time
Fubini, followed by the absolute kernel bound, yields

 integral b(e)|I_(h,T)(e)|^2de <= A_star^2 T ||C_b||_1.

Together with T<=tau_star/h^2 and the q=2 remainder U1 this proves U2.
This uses no independence of emissions and no already assumed Fock H^2
moment. It is a weighted one-particle Hilbert--Schmidt estimate.

For Z*=Z^(-1),

 E(Z*-I)=-E(Z-I)Z*,

so the full left weighted operator bound is also O(eta_h). For sufficiently
small h, d is invertible with ||d^-1||<=2. Unitarity gives
  u* beta+gamma* d=0.
Equivalently, gamma*=-u* beta d^-1. Hence the off-diagonal block of Z* obeys

 ||E gamma*||_HS
 <=2(||E beta||_HS+||E(u*-I)|| ||beta||_HS)<=C.          (U5)

The second term is legitimate because beta is HS, ||beta||_HS<=||E beta||_HS/m,
and E(u*-I) is bounded by the full inverse operator bound. This step avoids
incorrectly identifying left- and right-weighted Hilbert--Schmidt norms.
The weighted operator and off-diagonal HS hypotheses needed below therefore
hold for the inverse implementer Y*. No inverse Born remainder is asserted.
They hold also for full-picture propagators after a free factor, since all
powers of A commute with that free unitary.

## 3. Uniform D(H) graph bound

We prove a Fock graph estimate that is stronger than the previously used
form estimate Y*HY<=C(H+I):

 ||A Y A^-1||<=C_G, ||A Y* A^-1||<=C_G.               (U6)

First, for each fixed h and finite T, Y and Y* preserve D(H). The fixed
bounded quadratic V preserves D(H) and has bounded [H,V]. On a domain
core, Duhamel gives ||[H,W(t,s)]||<=k integral_s^t |lambda c(v)|dv;
closure then proves domain preservation. This bound is finite for each h,
although its O(h^-1) size is not used as the uniform bound U6.

Choose an orthonormal basis (e_i) of PK lying in D(E), and use Gamma e_i
on P_-K. Finite-particle vectors formed from D(E) are a graph core of H.
Normal ordering the exact transformed energy, or polarizing initial407 I14,
gives on this core

 Y* H Y = H+dGamma(C_0)+Pi_B+Pi_B*+c_0 I,             (U7)

 c_0=Tr(E beta beta*),
 C_0=u* E u-E-Gamma(beta* E beta)Gamma,
 B=beta* E u=(E beta)* u,
 Pi_B=-sum_(i,j) B_(j,i) a(e_i)a(e_j),
 B_(j,i)=<Gamma e_j,B e_i>.

The antiunitary conjugations in C_0 map the negative band to the positive
band. Pi_B uses the matrix of B between the stated bases. Its skew part
alone contributes. With inner products linear in the second slot, the
anomalous block has kappa_(i,j)=Tr(rho a(e_i)a(e_j)); thus Pi_B+Pi_B* has
expectation -2 Re Tr(B kappa), exactly the two anomalous terms in I16.
The normal term and c_0 likewise reproduce I14/I16 with their signs.

Here C_0 is bounded, despite the individual unbounded E terms. Set L=u-I.
On D(E),

 u* E u-E=L*E+EL+L*EL,

where EL is bounded O(eta_h) and L*E=(EL)*. The hole term beta*E beta
is bounded by ||beta|| ||E beta||, using the small weighted operator bound
for E beta as well. Consequently ||C_0||<=C, uniformly (in fact it vanishes).
Also ||B||_HS<=||E beta||_HS and c_0<=||E beta||_HS||beta||_HS are bounded.
All displayed products are thereby defined before their estimates are used.

For clarity, the pair estimate needed for U7 does not assume a finite rank.
For a finite skew coefficient array, group i<j. Its two-particle coefficient
norm is at most sqrt(2)||B||_HS. Exterior multiplication and its adjoint on
the n-particle sector have norms at most sqrt(binomial(n+2,2)) and
sqrt(binomial(n,2)) times that coefficient norm. This follows directly by
antisymmetrizing a tensor product: the antisymmetric projection is a
contraction and the Fock normalization supplies the binomial factor.
Approximate an arbitrary HS array in HS norm, first on each finite sector;
the same inequalities then give a limit on D(N) and

 ||Pi_B psi||<=||B||_HS ||N psi||,
 ||Pi_B* psi||<=||B||_HS ||(N+2)psi||.                 (U8)

Likewise ||dGamma(C_0)psi||<=||C_0|| ||N psi||. These are operator-norm
bounds on vectors, not merely expectation bounds. Since N<=H/m, U7/U8
imply ||Y* H Y psi||<=C||(H+I)psi|| on the graph core.

One can justify U7 without presupposing a uniform domain theorem: for each
fixed h the finite-time domain statement above permits Y*HY on that core.
The exact finite-energy covariance identity I14, its convergent normal and
HS anomalous traces, and polarization identify its matrix elements with U7.
The HS limit in U8 defines the right side on the core. Equality against
every core vector identifies the two vectors. Finally approximate any
psi in D(H) by core vectors in the H graph norm; the uniform right-side
bound makes H Y psi_k Cauchy. Closedness of H proves U6 for Y. Apply the
same reasoning using U5 to Y*. This is not an appeal to an unproved
many-body moment bound or to vacuum Gaussianity of the initial state.

Interpolation supplies the corresponding half-graph bound

 ||S Y S^-1||, ||S Y* S^-1|| <= C_G^(1/2).            (U9)

For example, apply the three-lines theorem to matrix elements of
A^z Y A^(-z) on spectral cutoff vectors for 0<=Re z<=1; unitaries A^(it)
give boundary norms1 and C_G. Let cutoffs increase using the bounds.
The same result follows from the Hilbert scale interpolation inequality.
No interpolation of the target tail conclusion is used.

## 4. Projector chains and energy tails

For every Borel B, spectral P_B=1_B(H) commutes with A and is a contraction
on each of the H and half-H graph spaces. Therefore

 ||A (Y*P_B Y) A^-1||<=C_G^2,
 ||S (Y*P_B Y) S^-1||<=C_G.                          (U10)

For L_h=Y_f P_n...P_1, both graph bounds are uniform with constants depending
on the fixed n. These estimates hold without a bin-boundary hypothesis and
without asserting convergence of the moving postmeasurement states.

Here is the abstract tail lemma actually needed. Suppose a family L has
bounded ordinary norm, ||S L S^-1||<=C_1 and ||A L A^-1||<=C_2. For any
positive finite-energy trace-class rho, define

 G_(L,R)=L* H 1_(R,infinity)(H) L.

It is a nonnegative form and 0<=G_(L,R)<=C_1^2 A. Thus S^-1 G_(L,R) S^-1
is a bounded operator, uniformly in L and R. Take Q_K=1_[0,K](H) and
rho_K=Q_K rho Q_K, without renormalization. Since Q_K commutes with S,

 d_E(rho,rho_K):=||S(rho-rho_K)S||_1 ->0.             (U11)

This follows from strong Q_K->I acting on the trace-class operator S rho S;
Q_K need not have finite rank. Weighted trace duality gives

 |Tr G_(L,R)(rho-rho_K)|<=C_1^2 d_E(rho,rho_K).

On the other hand H 1_(R,infinity)(H)<=H^2/R, so

 Tr G_(L,R)rho_K <=C_2^2 Tr(A^2 rho_K)/R.             (U12)

The right side is finite for each K, since
Tr(A^2 rho_K)<=(1+K) Tr(A rho). Choose K first and then R. Equations U11/U12
prove uniform integrability of every such family L, and in particular U3.
No second moment of rho is assumed. Replacing rho by another finite-energy
state changes every tail integral by at most C_1^2 d_E; hence a finite-net
argument makes U3 uniform over every d_E-compact family of finite-energy
density matrices. An energy cap alone does not supply that compactness.

## 5. Consequences for the already checked finite protocols

The prepared multi-time theorem supplies weak convergence of the finite
positive measure of the final energy with a preceding regular coarse-bin
history held fixed. This is a bounded spectral-test assertion; it does not
supply U3 on its own. U3 is the additional tail argument now proved.
Together they imply convergence of the unnormalized first moment for every
such history, including histories whose limiting mass is zero.

In the auxiliary limit the final energy is E_0 plus the marked compound-
Poisson increments, with the earlier coarse-bin events imposed on the same
shared E_0 and partial sums. Therefore the limiting unnormalized mean is
exactly the expectation of that final energy times the history indicator.
E_0 has the initial spectral law; its first moment is finite here. Bounded
jump sizes and uniformly bounded jump intensity give integrable added energy.
If the history has positive limiting probability, normalize the finite
measures. Their masses and first moments converge, so the conditional final
energy laws converge in Wasserstein-one. Uniform conditional conclusions
require a common positive lower bound on success probability.

Regular boundaries and fixed protocols have exactly the meaning in the
prepared theorem; U3 does not repair an atomic-boundary failure. For a fixed
profile and protocol, d_E-compact finite-energy initial families inherit
uniform unnormalized means and uniform conditional W1 wherever all histories
are regular and the success probabilities have a common positive bound.
Uniformity over moving bin families or protocols requires additional boundary
control. No rate for conditional W1 is inferred. No conditional quantum-state
trace norm convergence or infinitely frequent observation follows.

## 6. Sufficient actual common-energy transfer

Retain common H, common measured spectral projections, common Fock/vacuum
identification and the parent bounded-control calibration hypotheses

 ||V_a-V||<=d0 epsilon, ||[H,V_a-V]||<=d1 epsilon,
 ||[H,V_a]||,||[H,V]||<=k.

For each fixed h define b(T)=integral_0^T |lambda c(t)|dt<=C/h. Duhamel and
the bounded commutator identity give, with deltaW=W_a-W,

 ||deltaW||<=d0 epsilon b,
 ||[H,deltaW]||<=epsilon(d1 b+d0 k b^2).              (U13)

To check the second bound, commute H through the three factors of
-integral i W_a(T,s) lambda c(s)(V_a-V) W(s,0) ds.
The middle factor contributes d1 epsilon b. The two outside factors
contribute d0 epsilon k integral |lambda c(s)|(b(T)-b(s)+b(s))ds
=d0 epsilon k b(T)^2. Approximation by bounded energy resolvents or the
common invariant domain justifies the identity before the norm estimate.
No derivative of the scalar drive or instantaneous kick is inserted.

Free conjugation leaves these norms unchanged. Since
A deltaY A^-1=deltaY+[H,deltaY]A^-1, U13 yields

 ||A(Y_a-Y)A^-1||,
 ||A(Y_a*-Y*)A^-1|| <=C epsilon(b+b^2).              (U14)

For the adjoint, commutator norms are equal and the same identity applies.
Thus epsilon=o(h^2) supplies uniform full graph bounds for actual Y_a and
Y_a*, using the ideal U6. This is a stronger graph comparison derived here
from the stated bounded commutators, not an assertion that an unweighted
operator error can simply be multiplied by H.

Actual projector chains consequently satisfy the same U3 tail bound. If
initial rho_a converges to a fixed finite-energy rho in d_E, weighted trace
duality makes their tails differ uniformly by o(1). The previously checked
bounded-protocol probability comparison uses trace convergence and
epsilon=o(h), which are implied by these stronger assumptions. Combining
that weak comparison with the new tail control transfers unnormalized
means and positive-probability conditional W1 as above. Paired approximation
to a d_E-compact reference family gives its uniform version. The compact
preparation theorem is one sufficient source of such families and weighted
approximation; it does not construct a physical instrument or embedding.

## 7. Failure checks, premises and scope

A uniform first-energy cap on the output would not prove U3. The proof
instead derives D(H) bounds on dense energy-cutoff inputs, then uses the
uniform half-graph bound to extend tails to each finite-energy rho. The
cutoff Q_K is not presumed finite rank. Left-weighted HS bounds cannot be
transposed without U5. A moving arbitrary HS test is not used in a weak
pairing argument. No Wick identity is imposed on rho.

The gap m>0 is used in N<=H/m. Weighted q=2 one-particle estimates and fixed
smooth spatial resources are used in U2/U6; an unweighted kinetic law alone
is insufficient. Bounded commutator error is used in actual U13/U14. The
number of observations remains fixed; graph constants are not uniform as
it diverges. Rare-event normalized means are not inferred from small absolute
errors. Regular boundary exclusions of the preceding theorem remain intact.
The old Q25 statement is preserved as the earlier open obligation; it is not
rewritten to pretend that its author had already established this result.
