# Exposed comparison of the sharpened energy graph perturbation theorem

## 1. Disposition and source scope

Root V2 is supported under its stated abstract premises. Its sufficient
epsilon b->0 condition, hence epsilon=o(h) for b=O(1/h), agrees with my
independently frozen derivation. I find no further mathematical correction
needed in the fixed-resource implication. The earlier o(h^2) condition
remains sufficient; the new graph argument proves a weaker sufficient
calibration requirement without asserting continuum optimality.

The V1 inverse proof did contain a specific incorrect intermediate claim:
the derivative of TR is a commutator, not immediately zero. The exact V2
diff repairs that step with uniqueness of the commutator evolution. The
repair changes no bound, domain conclusion or final hypothesis. V1 remains
an immutable historical source; V2 is the checked target.

This is an exposed review of root and a self-check of my own independent
packet, not an independent review of my own work. The root and independent
derivations share previously read ideal graph/protocol premises. No separate
exposed-reviewer packet was read before this comparison froze.

Exact targets:

- Root V2, 192 lines:
  0906b06197d7664b5b7ee9c7bfe6b453e2949135225ee647feaeb6f93b1eb5dd.
- Root V1, 190 lines:
  9dc7b9ee2b5b97ed8029feaf605252628f55b62adfa0aaf4b683589a0d03be35.
- V2 diff:
  33c2e05a1ef7399788aa39c62a6f0e1a8ebee9025e95968d7511740149937257.
- Independent289:
  c2f208d2b05d43167f6beb18b2f30cedc01e3ff6b430ed8f39ed24ff57a2c5b3.
- Independent evidence192:
  5c59ba4d4f587d547283c21cbd5afb6466d98732df86b76ba7eb50630a89cf5b.

The comparison plan was frozen before target reading at
0cef2d198030f1bc03c6c2e68bcbe347afc32e349b9fa0d02f056b0e75e1acb5.
Root V1 was sealed16:25:57 UTC before the independent preliminary route
message; V2 was sealed16:27:05 after that route message but before the full
independent proof. Its seal discloses the timing and local self-correction.
My independent packet froze16:32:13 before root target exposure. These
records establish the stated exposure chronology, not model diversity or
independent derivation of shared source premises.

## 2. Graph premise, generator and domain construction

Both proofs require the exact common H, bounded self-adjoint control
difference, bounded O(epsilon) first commutator, and uniformly bounded
ideal forward and inverse full graph maps. Root assumes strong ideal graph
continuity explicitly and verifies it from the supplied bounded-control
source setting. Independent289 does the same. Neither substitutes a family
of norm inequalities for the existence of a graph-continuous evolution.

For G=1+H, both use

    ||G DeltaV G^-1|| <= (d0+d1)epsilon,
    B(t)=Y(t)* DeltaV_I(t) Y(t),
    ||G B(t) G^-1|| <= C_G^2(d0+d1)epsilon.                 (A)

This multiplication is legitimate on D(H), then extended boundedly.
Both ideal directions are essential. The field is strongly measurable on
the graph space and has an integrable scalar norm majorant. Vectorwise
strong integrals suffice; operator-norm measurability is not presumed.

The chronological Dyson series has nth term norm at most (k_G b)^n/n!.
It therefore converges in bounded graph-operator norm. Root first defines
the Hilbert relative propagator and then identifies the graph solution by
Hilbert uniqueness. Independent289 constructs the graph relative solution
and then multiplies by Y to identify the actual evolution. These are
equivalent noncircular constructions: actual graph invariance is a result,
not an input to the perturbative estimate.

## 3. The inverse repair is exact and sufficient

In root notation T'=-if BT and R'=if RB. The right-ordered R series has
the same graph majorant. Direct differentiation gives

    (RT)'=if RBT-if RBT=0,
    (TR)'=-if B(TR)+if(TR)B.                               (B)

Thus the V1 statement that both derivatives vanish directly is incorrect.
For K=TR, the second equation has the identity as a solution. On each
finite interval the difference from identity satisfies a bounded operator
integral equation with norm majorant 2|f| ||B||. Iteration, or Gronwall,
gives uniqueness and K=I. Hence R=T^-1; Hilbert unitarity identifies it
with T*. The graph inverse is established without incorrectly taking an
adjoint of a weighted norm. Root V2 states exactly this repair.

Independent289 instead uses RT=I followed by Hilbert uniqueness and
unitarity to identify R=T*, yielding TR=I as well. That proof is equally
valid. Its own final cold-read precision made this order explicit before
the independent freeze and before root V2 exposure.

## 4. Constants, half graphs and finite chains

Root's full graph difference is

    delta_G <= C_G [exp(C_G^2(d0+d1)epsilon b)-1].           (C)

The inverse has the same bound from its separate product order. The
unweighted difference is at most d0 epsilon b, with cap2 available.
Root interpolates those two difference bounds to obtain

    delta_S <= sqrt(d0 epsilon b delta_G).                  (D)

Independent289 alternatively interpolates DeltaV first and runs the
relative Dyson proof directly on D(G^(1/2)). Both yield O(epsilon b)
half-graph differences as epsilon b tends to zero. Root's route needs
only the full ideal graph theorem, since half-graph ideal bounds follow
from unitarity and interpolation. There is no unsupported operator-square
inequality in either route.

For a fixed n-record history, the amplitude has N=2n+1 unitary factors and
n common H-spectral projections. Each projection contracts both graph
norms. Telescoping the unitary differences gives root's exact bound
N L_A^(N-1) delta_A for A=G,S. This agrees with independent289's finite
product estimate; all projections are common, so no projection difference
or regular-boundary limit is hidden in this comparison.

The comparison bound is uniform over Borel bins. The ideal limiting law
still requires its regular boundary or common zero-gap premise. Fixed n
and uniform ideal graph constants remain part of the theorem. Root's G6
comment about growing C_G diagnoses the propagator bound (C) only; it
should not be read as an additional growing-resource protocol theorem.
Such a protocol would also require the growing chain factors in (9) to
be controlled. No such extension is claimed in the checked fixed-resource
statement.

## 5. First energies, moving states and W1

Root's Hilbert--Schmidt proof and independent289's trace-form proof are
the same estimate in two representations. For S=G^(1/2), a chain Q with
bounded S Q S^-1 has

    ||H^(1/2)Q rho^(1/2)||_HS <= L sqrt(Tr G rho).

The half-graph chain difference gives the corresponding difference norm.
The difference of squared norms is therefore at most
(L_a+L_i) delta_chain Tr G rho. Only finite first initial energy is used.
No continuity of weighted density square roots is assumed.

For moving states, the additional mean error is bounded by
L_a^2 ||S(rho_a-rho)S||_1, since the conjugated energy form is bounded by
L_a^2. The same statement holds for each truncated positive tail form,
uniformly in its tail cutoff. Root's lim_R limsup_joint tail quantifier is
correct. A convergent sequence or weighted-trace-compact family gives true
family uniformity; an arbitrary punctured continuum neighborhood does not.

Together with an established ideal weak finite-history law, these estimates
give actual branch masses and unnormalized first means. Positive limiting
branch mass permits normalization, weak convergence and first-moment
convergence, hence W1 on nonnegative energies. Zero-mass branches permit
only the unnormalized conclusions. Finite unions sum positive branches.

## 6. Calibration scale and countercontrol scope

The common sufficient condition is epsilon b->0. If b<=C/h, epsilon=o(h)
suffices. If epsilon=a^(N+1), with fixed N+1>0 and both calibration errors
obeying that bound, this gives a=o(h^(1/(N+1))). No ideal graph or actual
control hypothesis is dropped in this conversion.

Bounded epsilon b still gives uniform actual graph constants and finite-
energy tail control, but it does not force the actual limit to equal the
ideal one. Independent evidence E4 explicitly solves a two-level resonant
control at epsilon=k h by a bounded-primitive averaging estimate, producing
a nontrivial limiting rotation and positive energy mean. The example
supports only failure of a generic implication at that scale in the
abstract class. It is not necessity for the fixed-slot continuum theorem.
Root V2 makes no necessity or optimality claim, so there is no disagreement.

The old epsilon(b+b^2) absolute commutator bound remains valid. The improved
graph comparison does not imply a correspondingly small unweighted
[H,Y_a-Y]. This distinction removes any apparent conflict with the earlier
accepted sufficient scale.

## 7. Coverage and conclusion

Root V2 and V1 were read completely in outputs fdba8d and 9553ba. The
complete diff and both proof seals were read in 4af88e. The root plan and
plan seal were read in 6e47e8. Own289/evidence192 were fully read before
their freeze and remain unchanged. Exact source hashes, snapshots and
metadata coverage are recorded in SOURCE_INVENTORY.json.

The decisive checks above verify the corrected inverse equation, compatible
graph/Hilbert construction, half-graph interpolation, exact finite-chain
factor count and weighted first-energy pairing. No separate reviewer
packet, numerical runtime or proof assistant was used. No original source,
CW/Git state, audit, prompt, axiom or publication was changed.

Root V2 is mathematically supported as a conditional sharpening; no residual
obligation is identified within its fixed-resource implication. Shared
premises and physical calibration remain hypotheses. Parent owns ordinary
acceptance and any later retention. The complete compared files and this
report are bound by FINAL_FREEZE.json.
