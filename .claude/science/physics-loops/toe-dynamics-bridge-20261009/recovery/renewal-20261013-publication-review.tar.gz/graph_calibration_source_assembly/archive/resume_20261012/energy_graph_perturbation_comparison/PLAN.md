# Neutral exposed comparison plan

Prepared after independent packet freeze16:32:13 UTC and before reading
the root energy graph perturbation proof. Hard stop16:42:30 UTC; target
finish16:39 if the bounded comparison is complete.

Own derivation289/c2f208d2 and evidence192/5c59ba4d are frozen at
63d08b56c307655ca7efa7bdbaa1ce939cb9f276cdad9db9244959833e99e11f.
They prove an epsilon b graph-Dyson bound and sufficient epsilon=o(h),
with separate inverse construction and finite-first-energy chain transfer.
That result is exposed prior knowledge. This is review of root and
self-check of own work, not a new independent review of my own packet.

The parent disclosed root V1 seal16:25:57 and V2 seal16:27:05, with V2
correcting an explicit TR inverse proof via commutator-equation uniqueness.
No root formula or full proof was read before this plan. No outcome is
assumed from the correction report or the coinciding proposed technique.

Read complete root V2 at SHA256
0906b06197d7664b5b7ee9c7bfe6b453e2949135225ee647feaeb6f93b1eb5dd,
then the exact V1, their seals and complete diff. Compare graph hypotheses,
domain construction, inverse ordering/uniqueness, budget/constants,
measurement chains and first-energy/W1 consequences. Determine any required
correction or open obligation without assuming agreement. Preserve the
two-level control's abstract scope and do not assert continuum optimality.

Do not read any separate exposed-reviewer packet before this comparison
freezes. Do not modify original sources, assemble protocol sources, run
scientific code, mutate CW/Git, audit, prompts or axioms, or subdelegate.
Writes stay in this comparison directory. Deterministic hashes/copies are
allowed. Deliver a short complete comparison with decisive checks and an
exact freeze; stop new science before the absolute deadline.
