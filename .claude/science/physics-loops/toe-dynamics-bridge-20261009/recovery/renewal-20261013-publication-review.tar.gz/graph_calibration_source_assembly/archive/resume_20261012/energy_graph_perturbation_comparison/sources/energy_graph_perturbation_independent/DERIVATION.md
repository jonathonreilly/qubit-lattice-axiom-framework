# Perturbation in a uniformly bounded ideal energy graph

## 1. Conditional result and exact scope

The supplied uniform forward and inverse ideal energy graph bounds improve
the sufficient calibration scale to epsilon=o(h). More precisely, the
small parameter is epsilon b_h, where b_h is the integrated absolute drive
budget. The proof below gives uniform full and half graph differences of
order epsilon b_h when epsilon b_h tends to zero. Merely bounded epsilon b_h
gives uniform actual graph bounds, but does not by itself give convergence
to the ideal histories.

This is an improvement of the weighted propagator comparison needed for
energy observations. It does not assert that the unweighted operator norm
of [H,Y_a-Y] improves from the earlier coarse commutator estimate.
The exact common H, common spectral instrument and the stated calibration
remain hypotheses; no physical cell construction or new empirical claim
is supplied.

For kinetic time T<=tau_star/h^2 and bounded amplitude, b_h<=C/h. Hence
epsilon=o(h) suffices for graph convergence, bounded finite history transfer,
and finite-energy branch means. Together with the established ideal weak
history and first-mean limits, it gives conditional final mean and W1 at
positive limiting success probability. No second initial energy moment is
required. Fixed arbitrary normal states still have bounded-history transfer.

A finite-dimensional resonant example in the evidence shows that
epsilon=O(h) does not guarantee ideal convergence under the abstract graph
and commutator assumptions. This tests the general perturbation theorem.
It is not a claimed sharpness theorem for the particular nonzero continuum
CAR control with fixed slots; that narrower optimality question is not
needed for the sufficient result proved here.

## 2. Premises and graph domains

Let H>=0 be the exact common self-adjoint free energy and G=1+H.
Write S=G^(1/2). Consider the ideal interaction-picture propagator Y_h(t,s)
and its endpoint Y_h(t)=Y_h(t,0), with real integrable drive f_h(t).
In the supplied application f_h(t)=lambda c_h(t), |lambda|=h, and

    b_h(t)=integral_0^t |f_h(u)|du <= A tau_star/h.              (1)

The ideal interaction is V_I(t)=exp(itH)V exp(-itH). The actual interaction
is V_I(t)+Delta V_I(t), with bounded self-adjoint Delta V and

    ||Delta V||<=d0 epsilon,
    ||[H,Delta V]||<=d1 epsilon.                               (2)

The commutator is a bounded graph-domain commutator; equivalently its form
on D(H) has a bounded extension. The latter condition implies
Delta V D(H) is contained in D(H) by the adjoint-domain criterion. Since
free rotations commute with G and S, (2) holds equally in interaction
picture for every t.

The established ideal input is, for q=1/2 and q=1,

    sup_(h,t) ||G^q Y_h(t) G^-q|| <= M_q,
    sup_(h,t) ||G^q Y_h(t)* G^-q|| <= M_q.                      (3)

These are actual domain-preserving bounded extensions. The supplied ideal
propagator is strongly continuous on the graph spaces. In this model that
property follows at every fixed h from the bounded interaction with bounded
first commutator, before using any uniform kinetic estimate. It can also be
included explicitly as the evolution regularity premise of the abstract
statement. Uniform graph bounds alone are not used as a substitute for
existence of a graph-space evolution.

The endpoint bounds imply the interval bound

    ||G^q Y_h(t,s) G^-q|| <= M_q^2,
    Y_h(t,s)=Y_h(t)Y_h(s)*.                                  (4)

Thus the proof does not assume an independent uniform interval theorem.
It uses both directions of (3); forward bounds alone would not control
the generator in the ideal interaction frame.

## 3. The small perturbation is bounded on the graph

On D(H), using ||G^-1||<=1,

    G Delta V G^-1 = Delta V+[H,Delta V]G^-1,
    ||G Delta V G^-1|| <= (d0+d1)epsilon.                     (5)

Set D_1=d0+d1 and D_(1/2)=sqrt(d0(d0+d1)). Interpolation between
the Hilbert norm and the full graph norm gives

    ||S Delta V S^-1|| <= D_(1/2) epsilon.                    (6)

One may replace D_(1/2) by the weaker D_1 without changing any rate. The
interpolation follows by applying the three-lines bound to G^z Delta V G^-z
on spectral-compact vectors, then taking graph cutoffs. Imaginary powers
of G are unitary. If d0=0 then Delta V=0 and (6) is exact with zero.

For q in {1/2,1}, define the ideal-frame perturbation

    B_h(t)=Y_h(t)* Delta V_I(t) Y_h(t).

It is bounded self-adjoint on the Hilbert space. By (2), (3), (5)--(6),

    ||G^q B_h(t) G^-q|| <= M_q^2 D_q epsilon
                         = kappa_q epsilon.                 (7)

Its graph action is strongly measurable and bounded. In particular, the
integrated graph generator has norm budget at most kappa_q epsilon b_h.
No factor b_h from a separately estimated ideal commutator is introduced.

## 4. Construct actual domain preservation rather than assuming it

Solve on the graph space X_q=D(G^q), with norm ||G^q psi||,

    R_h'(t)=-i f_h(t) B_h(t) R_h(t),   R_h(0)=I.              (8)

The generator is integrable in the strong graph sense and uniformly bounded
by (7). Its chronological Dyson series converges as bounded operators on
X_q, with nth term norm at most (kappa_q epsilon b_h(t))^n/n!.
Consequently

    ||G^q R_h(t) G^-q|| <= exp(kappa_q epsilon b_h(t)),
    ||G^q (R_h(t)-I) G^-q||
       <= exp(kappa_q epsilon b_h(t))-1.                      (9)

The same series on the Hilbert space has a unique solution. Since B_h(t)
is self-adjoint and f_h real, that solution is unitary. Compatibility on
the dense graph domain identifies the graph-space and Hilbert solutions.

Define Y_a,h(t)=Y_h(t)R_h(t). The product differentiation in Hilbert space
gives the actual bounded-interaction equation with generator
f_h(t)(V_I(t)+Delta V_I(t)). Uniqueness identifies it with the actual
propagator. Thus Y_a,h preserves X_q by construction; actual graph-domain
preservation was not assumed to justify its own estimate.

The inverse requires a separate argument. The backward, right-ordered
Dyson equation

    Q_h'(t)=i f_h(t) Q_h(t) B_h(t),   Q_h(0)=I

has the same graph series bounds. The product rule gives Q_h R_h=I.
Hilbert-space uniqueness and unitarity identify Q_h=R_h*, hence also
R_h Q_h=I; both identities restrict to the graph space. Therefore

    ||G^q (R_h(t)*-I) G^-q||
       <= exp(kappa_q epsilon b_h(t))-1.                      (10)

This is not obtained by taking the Hilbert adjoint of G^q R_h G^-q,
whose adjoint has the reversed weights. Right-ordered inverse construction
is what proves the needed domain and estimate.

## 5. Improved endpoint and interval comparisons

Since Y_a,h-Y_h=Y_h(R_h-I), and
Y_a,h*-Y_h*=(R_h*-I)Y_h*, (3), (9) and (10) give

    ||G^q (Y_a,h(t)-Y_h(t))G^-q||
      <= M_q [exp(kappa_q epsilon b_h(t))-1],
    ||G^q (Y_a,h(t)*-Y_h(t)*)G^-q||
      <= M_q [exp(kappa_q epsilon b_h(t))-1].                 (11)

Likewise the actual forward and inverse graph norms are at most
M_q exp(kappa_q epsilon b_h(t)). An interval [s,t] has the same relative
Dyson construction with budget b_h(t)-b_h(s) and outside ideal factors
Y_h(t),Y_h(s)*, giving the analogous difference with M_q^2 in place of M_q.

Thus epsilon b_h(tau_star/h^2)->0 gives uniform forward/inverse full and
half graph convergence. For the specified kinetic budget, epsilon=o(h)
is sufficient, with graph error O(epsilon/h). Bounded epsilon/h supplies
uniform actual graph norms through the exponential, even when the graph
difference need not vanish.

Unweighted Duhamel also gives

    sup_t ||Y_a,h(t)-Y_h(t)|| <= d0 epsilon b_h.               (12)

The same bound holds for adjoints. The earlier epsilon(b_h+b_h^2)
commutator estimate is consistent but weaker for this purpose. It estimates
ideal commutators separately in the unweighted operator norm; (7) instead
uses the already available ideal graph maps as a whole.

## 6. Fixed finite spectral histories

Let Q_j=1_(B_j)(H) be any fixed Borel spectral projections of the common H.
They contract both X_q. Let

    P_j=Y_h(t_j)* Q_j Y_h(t_j),
    P_a,j=Y_a,h(t_j)* Q_j Y_a,h(t_j).

Under epsilon b_h->0, (3) and (11) imply uniformly bounded graph norms of
these projections and vanishing graph norm differences, of order
epsilon b_h. For example, insert and subtract Y_h* Q_j Y_a,h and use
the two differences in (11). No commutativity of different P_j is needed.

For a fixed chain and final observation time define

    T_h=Y_h(t_f)P_n ... P_1,
    T_a,h=Y_a,h(t_f)P_a,n ... P_a,1.

Finite telescoping in the Banach algebra of bounded graph maps gives

    ||G^q (T_a,h-T_h)G^-q|| ->0,
    sup_h [||G^q T_a,h G^-q||+||G^q T_h G^-q||] <infinity.    (13)

The constants depend on the fixed n and ideal graph constants. The
unweighted versions follow from (12). Consequently all bounded history
probabilities and bounded final-energy tests transfer to the ideal ones
for any fixed normal initial density. Ordinary trace convergence of moving
initial densities is enough for that bounded comparison.

This actual-versus-ideal comparison works for any fixed common Borel bins.
Identifying a limiting classical history law still requires the regular
boundary or common zero-gap hypotheses of the established ideal theorem.
The comparison does not remove those hypotheses or prove new ideal limits.

## 7. Finite first energies transfer directly

For a fixed finite-energy rho, put A=S rho S, a positive trace-class
operator with Tr A=1+Tr H rho. For either history chain put

    F_h=H^(1/2) T_h S^-1,
    F_a,h=H^(1/2) T_a,h S^-1.

Since ||H^(1/2)S^-1||<=1, the q=1/2 part of (13) gives bounded F_h,F_a,h
and ||F_a,h-F_h||->0. Quadratic forms on D(S), followed by density, give

    Tr rho T_h* H T_h = Tr A F_h* F_h.                       (14)

Hence actual minus ideal unnormalized history-weighted final mean tends
to zero, bounded in absolute value by

    Tr A (||F_a,h||+||F_h||)||F_a,h-F_h||.                    (15)

This direct energy-form comparison needs only the first initial moment.
It does not infer an unbounded mean from the norm estimate (12).

For normalized moving rho_a with

    d_E(rho_a,rho)=||S(rho_a-rho)S||_1 ->0,                  (16)

the additional mean error is at most d_E(rho_a,rho)||F_a,h||^2. Thus (15)
still gives convergence to the ideal mean along the stated joint limit.
Together with bounded-law convergence and the ideal first-mean theorem,
this proves the same unnormalized actual means. At a history event of
positive limiting probability, division by its converging mass gives
conditional weak convergence and convergence of first moments, hence W1
on the nonnegative energy line. No zero-probability normalization follows.

One can alternatively obtain the required tails from the actual full and
half graph bounds and the established two-cutoff estimate. For moving
states, (16) gives precisely

    lim_(L->infinity) limsup_(joint limit) Tr rho_a G1_(H>L)=0.

A convergent sequence or weighted-trace-compact family has genuine uniform
tails. A blanket supremum over every point in a fixed punctured continuum
neighborhood is not implied. The direct form comparison above avoids any
need to strengthen this quantifier.

Finite unions of measured records sum their positive branch measures;
coherently summing chain operators would describe another instrument.
Measurement count and bins are fixed; no increasing-record or moving-bin
extension is inferred.

## 8. Source boundary, novelty of this check and disposition

The pre-target neutral plan was sealed at SHA256
5123f69db72250d6f31802c9cf5726ca5626e92d6575109d394a3241d01693ab.
Its disclosure includes prior exposure to root211's coarse commutator
estimate and my own earlier proof/comparison. New root perturbation plan,
probe and findings remained unread throughout this derivation and freeze.

Eight exact source bodies in SOURCE_INVENTORY.json were already fully read
and were reused only after unchanged hashes were verified. Root306 and
independent390, with the mandatory linear/unitary J precision, supply the
ideal graph premise; fresh702 supplies the threshold protocol interface.
The present proof begins from the explicit graph bounds (3), not an unstated
ancestor theorem. No new reading or certification of corrected859 or other
unread ancestors is claimed.

The new load-bearing calculation is (7)--(11), with actual domains and
inverse graphs constructed before use. Equations (13)--(16) supply the
measurement-chain consequence directly. The evidence file independently
checks the frame equation, factorial bound, inverse order, endpoint/interval
distinction, resonant critical scale, and finite-energy form comparison.

Within these explicit hypotheses, no residual step is left in the sufficient
epsilon=o(h) implication. Optimality for the specified nonzero continuum
CAR slot control remains unclaimed. Parent comparison and ordinary
acceptance are pending. This is not retained science or a formal audit.
No scientific runtime, CW/Git mutation, prompt/axiom change, subdelegation,
other-chat contact, source assembly or publication occurred. Original
frozen sources remain unchanged.
