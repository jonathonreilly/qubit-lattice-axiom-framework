# Analytic checks for ideal-frame energy graph perturbation

These checks are analytic, source-exposed to the inherited graph theorem,
and unexposed to the new root perturbation argument. No scientific runtime
is used. They test the new relative-frame construction and its consequences.

## E1. Frame equation and graph generator

The ideal equation is Y'=-i f V_I Y. For a proposed actual equation
Y_a'=-i f(V_I+Delta V_I)Y_a, put R=Y*Y_a. Differentiation yields

    R'=i f Y*V_I Y_a-i f Y*(V_I+Delta V_I)Y_a
      =-i f(Y* Delta V_I Y)R.

The ideal terms cancel exactly, before taking any norm. With G=1+H,

    G(Y* Delta V_I Y)G^-1
    =(GY*G^-1)(G Delta V_I G^-1)(GYG^-1).

Each product is legitimate on D(H) and has a bounded extension. Both
ideal directions are needed. Its norm is bounded by M_1^2(d0+d1)epsilon.
Estimating [H,Y] separately would unnecessarily restore a factor b.

For construction, the logic is reversed: define the graph-space solution
R first and then Y_a=YR. The Hilbert equation and uniqueness identify
Y_a as the actual propagator. This avoids assuming actual graph regularity
before proving it.

## E2. Time simplex and domain compatibility

The nth graph Dyson term is an integral over
0<t_n<...<t_1<t of n generator factors. Bounding each graph generator by
kappa epsilon |f(t_j)| gives

    (kappa epsilon)^n integral_simplex product_j |f(t_j)|dt_j
    = (kappa epsilon b(t))^n/n!.

The scalar product integrand is symmetric; the simplex occupies one of
n! orderings up to measure-zero equal-time sets. Summing n>=0 gives the
exponential bound and summing n>=1 gives the difference from I.
This estimate remains valid for sign-changing or merely integrable f.

Strong graph continuity of the ideal maps and bounded graph action of
Delta V make the relative generator strongly measurable on D(G^q).
Strong integrals and the norm bound suffice; operator-norm continuity is
not required. The series converges on both the graph space and Hilbert
space to compatible operators. The latter solution is unitary because
the Hilbert generator is self-adjoint times a real scalar.

The proof imports the supplied graph regularity of the ideal evolution,
which also follows here from bounded [H,V] at each fixed h. It does not
deduce graph continuity merely from a uniform collection of norm bounds.

## E3. Inverse order and intervals

The inverse is constructed by Q'=i f Q B, with multiplication on the
right. Its series has the reversed chronological order and the same
factorial norm estimate. Differentiating QR gives zero, so QR=I.
In Hilbert space, uniqueness and unitarity give Q=R*, hence also RQ=I.
This proves that the Hilbert adjoint preserves the graph domain.

Taking the adjoint of GRG^-1 would instead give G^-1 R* G. That is the
wrong graph weight and is not used. The actual adjoint difference is

    Y_a*-Y*=(R*-I)Y*,

so its bound has the same ideal prefactor as the forward difference.

For an interval [s,t], the relative propagator is R(t,s)=R(t)R(s)* and

    Y_a(t,s)=Y(t)R(t,s)Y(s)*,
    Y(t,s)=Y(t)Y(s)*.

Its Dyson generator is the same B(u), now integrated from s to t. Thus
only b(t)-b(s) enters the exponential; outside ideal factors contribute
M_q^2. Bounding R(t)-I and R(s)*-I separately would give a valid but
weaker estimate depending on the full endpoint budgets.

## E4. Calibration regimes and a resonant critical-scale test

The estimate is M_q[exp(kappa_q epsilon b)-1]. Therefore:

- epsilon b tends to zero: graph differences vanish, with order epsilon b.
- epsilon b stays bounded: actual graph norms stay bounded.
- epsilon b grows without bound: this estimate gives no uniform conclusion.

The third statement is a limitation of the estimate, not a proof of
divergence. If b=0, the difference is exactly zero. A smaller actual drive
budget permits a weaker calibration requirement than replacing b by C/h.

For a direct critical-scale control, take a two-level Hilbert space with
H=diag(0,omega), omega>0, ideal V=0 and Delta V=epsilon sigma_x.
The ideal graph maps are the identity. Also

    ||Delta V||=epsilon,
    ||[H,Delta V]||=omega epsilon.

Take the fixed drive f_h(t)=h cos(omega t) and T=tau/h^2. Write
sigma_+=|1><0|, sigma_-=|0><1| and g=h epsilon. The actual interaction
equation has generator g[A+B(t)], where

    A=sigma_x/2,
    B(t)=[exp(2i omega t)sigma_++exp(-2i omega t)sigma_-]/2.

The primitive F(t)=integral_0^t B(s)ds is uniformly bounded by a constant
depending only on omega. Let Z(t)=exp(-igAt). Variation of constants gives

    Y_a(t)-Z(t)=-ig integral_0^t Z(t-s)B(s)Y_a(s)ds.

Integrate B=F' by parts. The endpoint term is bounded by ||F||_infinity;
the derivative terms are bounded by
g t ||F||_infinity (||A||+sup||A+B||). Thus

    ||Y_a(t)-Z(t)|| <= C_omega(g+g^2 t).                     (E1)

If epsilon=k h with fixed k>0, then g=k h^2. At T=tau/h^2 the right side
of (E1) tends to zero, while

    Y_a(T) -> exp(-i k tau sigma_x/2).

For k tau not a multiple of 2pi this differs from ideal I. Starting in
the zero-energy state, the final mean tends to
omega sin^2(k tau/2), while the ideal mean is zero. Choosing k tau not a
multiple of 2pi makes this strictly positive.

This example obeys the abstract common-energy, bounded commutator and
uniform ideal graph hypotheses, with a fixed positive-frequency cosine
drive and bounded resources. It shows that epsilon=O(h) cannot guarantee
ideal graph or energy convergence for that abstract class. It does not
establish optimality for the specific continuum CAR slot control: that
model has additional structure not represented by this two-level example.

## E5. A commuting phase and the meaning of convergence

If Delta V=v I, then the relative perturbation is v I and
R(t)=exp(-i v integral_0^t f(s)ds)I. Its exact graph error equals the
scalar phase error. The absolute-budget bound remains valid, though drive
cancellations may make it very loose. Energy histories are identical even
when the scalar phase does not converge to one.

Thus graph convergence is a sufficient route to energy convergence, not
a necessary condition for every special perturbation. The claimed scaling
is sufficient for the entire stated class and does not prohibit stronger
conclusions under additional structure or cancellations.

## E6. Measurement chains and the first-energy form

For q=1/2 or 1, let ||A||_q=||G^q A G^-q|| on bounded graph maps.
It is submultiplicative. Every common spectral projection Q_j has
||Q_j||_q<=1. Subtracting
P_a,j=Y_a,j*Q_jY_a,j and P_j=Y_j*Q_jY_j yields two terms, each with one
propagator difference. Their graph norm is O(epsilon b) with bounded
constants. A length-n product then differs by a sum of n terms, each
containing exactly one difference and finitely many uniformly bounded
graph factors. Fixed n is used here.

Let A=S rho S and F=H^(1/2)TS^-1. For a vector psi in D(S),

    ||H^(1/2)T psi||^2=||F S psi||^2.

Summing a density decomposition, using nonnegative forms and monotone
finite partial sums, gives Tr rho T*H T=Tr A F*F. This establishes the
trace identity without assuming Tr rho H^2 is finite.

For actual and ideal chains,

    ||F_a*F_a-F*F|| <= (||F_a||+||F||)||F_a-F||.

The half-graph chain difference bounds ||F_a-F||, because
H^(1/2)S^-1 is a contraction. Multiplication by Tr A therefore controls
the entire mean error using the first initial energy only. For moving
states an additional weighted trace-norm error multiplies ||F_a||^2.

This direct comparison is stronger than trying to apply the unweighted
propagator estimate to the unbounded H. Full graph bounds remain useful
for the independent tail route and are also proved by the same Dyson
construction. Positive limiting event probability is still required to
normalize branch measures; finite unions sum positive branches.

## E7. What is and is not independently established here

The inherited ideal graph theorem and ideal protocol law are exposed exact
premises. The independent new work is the relative graph generator bound,
the graph-compatible construction of actual evolution and its inverse,
the epsilon b estimate and the direct finite-energy chain comparison.
The resonant calculation tests the scale in the abstract class analytically.

No new root perturbation source was read. No numerical or symbolic runtime,
scientific test program, CW/Git mutation, audit, prompt/axiom change,
subdelegation or source assembly was performed. Sharpness for the nonzero
continuum slot control remains outside the proved claim. Parent comparison
and ordinary acceptance are pending.
