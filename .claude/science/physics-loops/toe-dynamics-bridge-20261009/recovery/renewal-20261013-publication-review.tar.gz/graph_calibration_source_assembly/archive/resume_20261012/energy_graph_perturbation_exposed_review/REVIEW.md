# Focused source-exposed review: relative-graph energy perturbation

Verdict: the fixed-resource conditional theorem in rootV2 is valid at its
explicit uniform forward/inverse graph hypotheses. The relative graph Dyson
argument sharpens the sufficient epsilon=o(h^2) scale to
epsilon=o(h), for b=O(h^-1). The finite-chain, first-energy, varying-state
and positive-probability conditional W1 steps follow at the stated scope.
No formula or domain repair is required within that scope. One scope
qualification is necessary before exporting G6(iii)'s growing-C_G comment;
it is not a replacement for uniform graph constants in the tail theorem.

Target: ENERGY_GRAPH_PERTURBATION_ROOT_PROBE_V2.md,192 lines,
SHA0906b06197d7664b5b7ee9c7bfe6b453e2949135225ee647feaeb6f93b1eb5dd.
V1,190 lines, is9dc7b9ee2b5b97ed8029feaf605252628f55b62adfa0aaf4b683589a0d03be35.
V2 seal isee6c954a70896a42331922e5c09e61ee2bfe4e93ad7e79082425f44ad928ee1e;
its exact diff is33c2e05a1ef7399788aa39c62a6f0e1a8ebee9025e95968d7511740149937257.
Both full bodies are archived; the entire V2 and changed V1 inverse argument
were read, and the exact unified diff was reconstructed without normalization.
The earlier accepted graph premises remain immutable and are archived with
23 exact source/snapshot identities, including all nine root-seal source pairs.

## Consequential checks

1. G1–G2: D(H) with norm||(1+H)x|| is complete. The bounded commutator
identity gives an actual bounded graph operator for DeltaV. Free conjugation,
ideal evolution and its inverse are strongly continuous on that space under
the stated premises. The generator is vectorwise strongly measurable with an
integrable norm majorant. Dyson terms exist as vector Bochner integrals and
the series converges in operator norm. No operator-norm Bochner measurability
is needed. Evidence E1 gives a bounded-commutator example where that stronger
measurability actually fails, so this distinction is load bearing.

2. G2: Hilbert-space uniqueness identifies the graph solution with Y*Y_a.
A separate reverse/two-parameter evolution proves both inverse products.
V1 incorrectly stated that the TR derivative directly vanishes. V2 correctly
uses its commutator equation and uniqueness. Evidence E2 reconstructs the
inverse through two-parameter composition, avoiding an unsupported claim of
operator-norm differentiability or a common exceptional set for all vectors.

3. G3: Forward and adjoint differences use different correctly ordered
products; weighted adjoint norms are not equated. The exponential constant
is C_G^2(d0+d1)epsilon b. Spectral cutoff plus three-lines gives the stated
half-graph interpolation inequality. The adjoint and domain extensions, zero
control cases and commuting-error case are checked explicitly in E3.

4. G4: There are2n+1 unitary factors and n common spectral projections.
Telescoping gives exactly N L_A^(N-1)delta_A. Arbitrary Borel bins are allowed
for this deterministic comparison, not automatically for an inherited weak
limit. The fixed count, common H/instrument and uniform resource hypotheses
cannot be removed by this estimate.

5. G5: Weighted Hilbert–Schmidt factorization proves the moment difference
without a second moment or quasifree assumption. The signed weighted trace
argument for varying rho avoids a square-root continuity assumption. Evidence
E5 gives an explicit cutoff bound using a possibly infinite-rank initial
spectral projection. Fixed rho has genuine uniform tails when epsilon b is
bounded. Varying d_E-convergent rho_a has lim_R limsup_joint tails; compact
families or convergent sequences have the corresponding uniform modulus.
No arbitrary punctured-continuum-neighborhood supremum follows merely from
convergence at its missing limit point.

6. Scalar conclusions: inherited regular-protocol weak convergence plus these
tails gives unnormalized first moments. At branch probability p>0 the
conditional mean is the limiting unnormalized mean divided by p, and weak
plus first-moment convergence gives W1. At p=0 only unnormalized conclusions
remain. Uniform conditioning needs a success floor and uniform initial/ideal
limit controls. For calibration order r>=0, epsilon=a^(r+1) gives the
sufficient a=o(h^(1/(r+1))). It is not a necessity or optimality statement.

## Required scope qualification and presentation precisions

G6(iii) is sound as a diagnostic of the single-propagator difference (6).
Its two C_G-dependent conditions alone do not imply all G4–G5 conclusions
if C_G grows. A fixed-state, fixed-H example with DeltaV=0 satisfies both
perturbation conditions exactly, yet its ideal/actual output energy law has
weak limit delta0 and mean tending to one, with escaping energy. E6 supplies
the full two-level rotation calculation. This is outside the main uniform-C_G
theorem and does not refute it. Any wrapper should explicitly say that the
G6(iii) conditions control single-propagator differences; product powers and
uniform tails require their own bounds. No varying-C_G generalization of the
full theorem is certified here.

Use a different symbol for calibration order than N=2n+1 in G4, and read
“retained common-H” in G6 as “assumed common-H,” not retained audit status.
Root separately flagged these two presentation points at16:37; they are not
presented as independent discoveries or as changes to a theorem formula.

## Review exposure and limits

Plan07de4ab3 was sealed at16:29:53 before opening the new target body. This is
same-family source-exposed checking, using the previously read exact accepted
postmeasurement graph sources and their current J-type precision. It is not a
new blind reconstruction, model-diverse check, retained audit or formal proof.
The separately deriving target worker and its folder were neither read nor
contacted. The source's threshold references are assessed only as conditional
uses of an abstract graph premise; no threshold body or composition was
adopted or verified. The root plan's disclosed pre-plan reasoning and V2 seal's
preliminary-route exposure remain preserved as history, without inflation of
independence.

The full explicit calculations are in evidence/ANALYTIC_EVIDENCE.md. No
scientific/Lean runtime, Git/CW, audit, prompt or source mutation, literature
search or subdelegation occurred. Deterministic byte/diff bookkeeping executes
zero mathematical predicates. There is no unfinished fixed-scope domain or
measurability check in this review. Physical calibration/embedding and any
independently supplied ideal graph theorem remain hypotheses. A broader
nonuniform-graph theorem would require additional work; it is not accepted
by this review. All original sources and earlier sufficient bounds survive.
