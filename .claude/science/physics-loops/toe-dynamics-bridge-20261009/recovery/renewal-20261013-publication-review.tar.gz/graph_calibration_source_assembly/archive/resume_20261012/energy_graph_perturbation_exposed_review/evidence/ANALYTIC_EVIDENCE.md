# Decisive analytic reconstruction of the relative-graph perturbation argument

This is a source-exposed calculation from exact rootV2/0906b061. It does not
use the separately deriving independent target. H>=0 is self-adjoint,
G=1+H, S=G^(1/2), g=lambda c is real and integrable, b=integral|g|.
All graph constants below are uniform over the parameter family unless
explicitly labeled otherwise. No proposed-science runtime was executed.

## E1. Closed-domain graph conjugation and measurability

Equip X=D(G) with norm ||x||_X=||Gx||. This is a complete Hilbert space,
and G:X->H is an isometric isomorphism with bounded inverse G^-1.
A domain-preserving bounded DeltaV with bounded commutator satisfies, on X,

 G DeltaV G^-1 = DeltaV + [H,DeltaV]G^-1,
 ||G DeltaV G^-1|| <= (d0+d1)epsilon.

Thus this is an actual bounded operator identity, not a formal commutator.
Let U0(t)=exp(-itH), C=G DeltaV G^-1. Free conjugation of the graph
operator is U0(t)* C U0(t), up to the harmless chosen free-picture sign.
It is strongly continuous, because U0 is strongly continuous and C bounded.
It need not be norm continuous or operator-norm Bochner measurable.

Write Y_G=G Y G^-1 and Y_inv,G=G Y* G^-1. These are genuine inverses
by the assumed two-way domain invariance. Strong graph continuity and the
uniform inverse bound give strong continuity of both; alternatively use
Y_G(t)^-1-Y_G(s)^-1=Y_G(t)^-1(Y_G(s)-Y_G(t))Y_G(s)^-1.
Consequently B_G=Y_inv,G C_I Y_G is strongly continuous, with
||B_G||<=C_G^2(d0+d1)epsilon=k_G. Multiplication by the measurable scalar
g gives strongly measurable vector functions with integrable norm majorant.
In particular, all required integrals exist as Bochner integrals of vectors
in X or H. This uses no separability or measurability in the operator norm.

Here is an independent discriminator for that distinction. On a fixed Hilbert
space with orthonormal pairs e_n,f_n, let H e_n=0 and H f_n=n f_n. Define
DeltaV e_n=f_n/n and DeltaV f_n=e_n/n. It is bounded self-adjoint,
[H,DeltaV] e_n=f_n, [H,DeltaV] f_n=-e_n, and it preserves D(H).
However C_I(t)e_n=((n+1)/n) exp(i n t)f_n, up to the sign convention.
For distinct t,s in (0,2pi),

 ||C_I(t)-C_I(s)|| >= sup_n |exp(i n(t-s))-1| >= sqrt(3).

For irrational (t-s)/(2pi) the supremum is2; for a rational angle of order
q>=2, the largest chord among its roots is at least sqrt(3). The range is
therefore an uncountable uniformly separated set in operator norm. Any
norm-separable subset intersects it in only countably many points, so the
map is not essentially norm-separably valued on a time interval and is not
an operator-norm Bochner measurable map. It remains strongly continuous.
This meets the bounded-commutator hypotheses and confirms that rootV2's
vectorwise integral qualification is necessary and sufficient for its method.
This example is a scoped measurability diagnostic, not a physical no-go.

## E2. Dyson construction and both inverse orders

On X, recursively integrate the strongly measurable bounded generator
-i g(t) B(t). The ordered n-simplex term defines a bounded operator with
norm at most (k_G b)^n/n!, by the vector norm inequality and scalar simplex
integration. The resulting series converges in operator norm, although
its individual integrals were only constructed vectorwise. Its sum T_X is
strongly absolutely continuous on each vector and solves the integral
equation. The estimates are

 ||T_X||<=exp(k_G b), ||T_X-I||<=exp(k_G b)-1.

The embedding X->H is continuous. For x in X, the same vector equation
holds in H, with bounded integrable generator -i g B. Hilbert-space
uniqueness identifies T_X x with T x=Y*Y_a x. This proves forward graph
invariance without assuming it for Y_a.

For inverse invariance, construct the two-parameter graph propagator U(t,s)
using oriented integrals. Uniqueness gives U(t,s)U(s,r)=U(t,r) on each
vector. Hence U(0,t)U(t,0)=U(t,0)U(0,t)=I. The reverse series for
R(t)=U(0,t) obeys R'=i g R B, and has the same exponential norm and
R-I bounds. This proves both inverse orders without any unproved
operator-norm derivative. The Hilbert identification then gives R=T*=T^-1
on X and proves inverse graph invariance.

RootV2's displayed repair is also correct: RT has zero derivative, whereas
K=TR solves K'=-i g B K+i g K B. The identity solves this equation. The
difference of any two bounded solutions satisfies a norm integral inequality
with coefficient2|g|k_G, so Gronwall yields uniqueness. The evolutions are
operator-norm continuous by their integrable norm bounds. In the present
setting B_G is strongly continuous before multiplication by g, so strong
product differentiation can be justified at scalar Lebesgue points of g.
The two-parameter construction above additionally avoids reliance on choosing
common null sets for arbitrary operator-valued differentiability assertions.
V1's statement that (TR)' directly vanishes was wrong; V2 repairs it.

## E3. Forward, adjoint and half-graph difference estimates

Y_a=YT and Y_a*=T*Y*. Set x=C_G^2(d0+d1)epsilon b. Independently for
the two products,

 ||G Y_a G^-1||, ||G Y_a* G^-1|| <= C_G exp(x),
 ||G(Y_a-Y)G^-1|| <= C_G(exp(x)-1),
 ||G(Y_a*-Y*)G^-1|| <= C_G(exp(x)-1).

The adjoint estimate uses the graph inverse T*, not an equality between
weighted adjoint norms. Hilbert Duhamel gives ||D||<=d0 epsilon b for
each difference D, optionally capped by2.

For interpolation, let P_L=1_[1,L](G). D_L=P_L D P_L has operator norm
at most M0=||D|| and full-graph norm at most M1=||G D G^-1||. On the
spectral subspace P_L H, log G is bounded. Three-lines applied to scalar
matrix elements of G^z D_L G^-z gives
||G^(1/2) D_L G^(-1/2)||<=sqrt(M0 M1). Let L increase to infinity;
density and closure yield the same bounded extension for D. No finite-rank
assumption on P_L and no operator-order squaring rule is needed.
This proves (7) and

 delta_S <= sqrt(d0 epsilon b C_G(exp(x)-1)).

Applying the same interpolation to the individual unitaries gives half-graph
norms <=sqrt(C_G exp(x)), and <=sqrt(C_G) for ideal factors. With fixed
C_G,d0,d1, both graph differences are O(epsilon b) as epsilon b->0.
The cases b=0 or DeltaV=0 are exactly zero differences. If d0=0, DeltaV=0
by (2), irrespective of a loose d1 bound. If [H,DeltaV]=0, d1=0 suffices,
but B=Y*DeltaV_I Y need not commute with H; retaining C_G^2 is correct.

## E4. Finite history products and positive first-energy forms

There are N=2n+1 unitary factors and n identical H-spectral projectors in
Q=Y_f(Y_n*Pi_n Y_n)...(Y_1*Pi_1 Y_1). On either graph space, each
projector has norm<=1. Replace the N unitary factors one at a time. The
sum of N differences has norm <=N L_A^(N-1)delta_A. This establishes
(9), its adjoint-factor ordering and uniformity over arbitrary Borel bins
for this comparison. It is not a weak-limit regular-boundary theorem.
Both Q and Q_a contract on H.

For fixed finite-energy rho, X=S rho^(1/2) is Hilbert–Schmidt with
||X||_HS^2=M=Tr(G rho). The bounded factorization
H^(1/2)Q rho^(1/2)=(H^(1/2)S^-1)(SQS^-1)X
justifies its domain and norm, including noncommuting, nonquasifree rho.
The corresponding difference has norm <=d sqrt(M). Difference of squared
Hilbert–Schmidt norms therefore gives (L_a+L_i)d M exactly as in (10).

For varying rho_a, define the bounded positive operator associated with
S^-1 Q_a* H Q_a S^-1; it equals F_a*F_a for
F_a=H^(1/2)Q_a S^-1 and has norm<=L_a^2. Pairing it with the signed
trace-class S(rho_a-rho)S gives error <=L_a^2 d_E. This is an equality
of forms extended by bounded operators; it requires no unjustified square
root continuity. The identical argument applies to H1_(H>R), uniformly in R.
Ordinary probabilities differ by at most2||Q_a-Q||+||rho_a-rho||_1, and
||rho_a-rho||_1<=d_E, since G^-1/2 is a contraction.

## E5. Explicit cutoff tail and conditional scalar limits

Suppose the history norms obey ||GQ_aG^-1||<=C and ||SQ_aS^-1||<=L,
uniformly. Put P_K=1_[0,K](H). Splitting rho^(1/2) at this initial
projection gives the quantitative bound

 ||H^(1/2)1_(H>R)Q_a rho^(1/2)||_HS
 <= C sqrt((1+K)M/R)
    +L sqrt(Tr(G1_(H>K)rho)).

Indeed on H>R, H<=H^2/R, while
||G P_K rho^(1/2)||_HS^2<= (1+K)Tr(G rho). The other term uses the
half-graph bound. Fix K, send R to infinity, then K to infinity. The last
trace vanishes because the initial first energy is finite. This proves the
genuine fixed-state uniform tail assertion without a second moment or
finite-rank cutoff. If epsilon b is merely bounded, (6) provides the uniform
actual graph constants needed here; convergence is not necessary for UI.

For d_E(rho_a,rho)->0, tail replacement is bounded by L^2 d_E uniformly
in R. Therefore the correct assertion is lim_R limsup_joint tail=0.
A d_E-compact family has finite nets and bounded first energy, yielding a
common tail modulus. A convergent sequence plus its limit is compact, so
it also has uniform tails under uniform history constants. An arbitrary
fixed punctured continuum parameter neighborhood is not made compact by
convergence at its missing limit point; no such uniformity is inferred.

If the ideal regular-protocol weak law is given, the bounded-observable
comparison above transfers it. Ideal and actual tail control gives convergence
of unnormalized first moments; (10) also transfers an existing ideal mean
limit directly. For branch masses tending to p>0, normalize eventually:
weak convergence and convergence of first moments on [0,infinity) imply
W1 convergence. The conditional mean is the limiting unnormalized mean
integral x dmu divided by p. At p=0 only the unnormalized conclusions are
retained. A uniform normalized statement requires a success-probability floor
and the stated initial-tail/ideal-limit controls. No regular-boundary premise
is lost by the stronger arbitrary-bin comparison bound.

With b<=C/h and fixed resource constants, epsilon=o(h) is sufficient. For
fixed calibration order p>=0 and epsilon=a^(p+1), this is a=o(h^(1/(p+1))).
For example, a=h^(3/(2(p+1))) satisfies the new condition and need not satisfy
the older a=o(h^(2/(p+1))). The older bound remains valid; neither is claimed optimal.

## E6. Scope precision for nonuniform ideal graph constants

Root G6(iii)'s C_G-dependent conditions control the single-propagator
full-graph difference C_G expm1(C_G^2 dG epsilon b). They must not be read
as a replacement for uniform C_G in all finite-chain, tail and mean results.
The product estimate contains additional L_A powers, and uniform tails need
uniform graph constants or separately checked substitutes.

A decisive example uses fixed H e_0=0, H e_n=n e_n on l2, fixed rho equal
to the e_0 pure state, and Y_n rotating span(e_0,e_n) by theta_n=1/sqrt(n).
Choose a strongly continuous prefix rotation and Y_a,n=Y_n, DeltaV=0.
Then ||G Y_n^(*)G^-1|| grows like sqrt(n), while both proposed perturbation
conditions in G6(iii) are zero. Nevertheless the final energy law is
cos^2(theta_n)delta_0+sin^2(theta_n)delta_n. It converges weakly to delta_0,
its mean n sin^2(theta_n)->1, and its first-energy tails are not uniformly
integrable. This is outside G1's uniform-C_G assumption and is not a
counterexample to the fixed-resource theorem. It proves that the phrase
“correct condition” in G6(iii) is only a single-propagator convergence
qualification; exporting it to G4–G5 requires additional hypotheses.
