# Energy tails after finitely many Lüders measurements

Status: new target-root-excluded conditional analytic derivation, pending a
separate mathematical check. The accepted strict-gap chirped free CAR model
is supplied. No new physical axiom, apparatus calibration, numerical result,
formal proof or retained audit is claimed. This targets Q25 of prepared512;
the earlier comparison correctly left that obligation open.

The conclusion of the argument below is affirmative for every fixed normal
initial density of finite first free energy and a fixed finite measurement
count. The additional step is a uniform D(H) bound for both directions of
the Bogoliubov implementer, derived from the accepted q=2 weighted inputs.
It is not obtained by squaring a first-energy form inequality. The initial
state itself needs no second moment.

## 1. Sources, setting and precise assertion

Use prepared_multitime_energy_independent/DERIVATION.md512 at SHA
48f329cf8795f7f222b091c5152899809199566898b32f2aa310b338dbc9e4d8,
initial407 at SHA20c9f7cba4ea75cfad431e067f676aae54b15e031005a04dd9b4c63d37423086,
strict-gap chirp V2/515 at SHA87011c662344ed684a7251f5067bb8193d156837a50a23e71fa29ccff38e92f6,
and chirp independent850 at SHA279a96bc07b495a59b829cac70586ae8e115f0ddefca0d405bb15f0a7de6e95c.
Their chirp acceptance is9918f46bbf900e35241aae0ad51f92ba6164df21081ec6f75f97ff8576cc895c.
Exact full snapshots and the direct source manifest accompany this note.
The previously checked bounded prepared-protocol result is used at its
explicit chirped-input scope; it is not inferred from a one-time law.

Let E>=m>0 be the supplied one-particle energy, P the positive polarization,
Gamma the real conjugation, and H=dGamma(E|PK) on fermionic Fock space.
Gamma exchanges P and P_- and commutes with E. The real unitary Z commutes
with Gamma. Its implementer obeys

 Y*b(k)Y=b(Z*k), b(k)=a*(Pk)+a(P Gamma k).             (T1)

All profiles and the massive smooth-slot model are as in accepted chirp
H1--H2: bounded BV amplitude and frequency, with a fixed positive distance
between the carrier frequencies and2m. Write h=|lambda|,
Y_h(tau)=Y(tau/h^2), A_h(tau)=Y_h(tau)*HY_h(tau),
G=I+H and S=G^(1/2). Fix a finite slow-time horizon. Tail constants
are uniform over the stated drive resource bounds. All limiting-law and
conditional-moment assertions below instead keep the profiles a,varpi
and the finite observation protocol fixed, as in the supplied parents.

For any n preceding observations in the ordered slow-time list
0<=tau_1<...<tau_n<=tau<=tau_star, set

 P_(h,j)=Y_h(tau_j)*1_(B_j)(H)Y_h(tau_j),
 C_h=P_(h,n)...P_(h,1),
 T_h=Y_h(tau) C_h.                                  (T2)

For the energy-tail assertion, the B_j may be arbitrary Borel sets; its
bound does not depend on their endpoints. For the limiting probability
and conditional-mean conclusions, observations and bins are fixed and
satisfy the exact regular-bin hypotheses of prepared512: finite interval
partitions, unbounded end intervals allowed, finite boundaries satisfying
Q14--Q15 or the separately justified common zero-gap condition.

For every fixed normalized normal rho with M_rho=Tr(Hrho)<infinity,
with no quasifree, parity or energy-diagonality assumption,

 lim_(R->infinity) sup_(0<h<h0)
  || H^(1/2)1_(H>R) T_h rho^(1/2) ||_HS^2 =0.        (T3)

Here h0 is a sufficiently small resource-dependent constant. The supremum
can also cover all times in the fixed horizon and all choices of B_j with
the same bound on n. By unitary spectral calculus, the squared norm in T3
is exactly Q25. Thus T3 is stronger than its required limsup as h->0.
It supplies no uniformity over the unrestricted first-energy ball.

## 2. The one-particle second-energy inputs and inverse blocks

Write Z=[[alpha,beta],[gamma,delta]]. Accepted V2 H6 gives, for q=1,2,

 ||E^(q/2)(Z-I)||<=C_q eta_h,
 ||E^(q/2)(Z-I-K1)||_HS<=C_q eta_h,
 eta_h=sqrt(h log(2+h^-2)).                           (T4)

These are bounded extensions with the stated graph-domain meaning.
Let beta1=PK1P_-. In the accepted scalar band frame beta1 J has kernel
lambda Delta(p,q) I_h,T(E(p)+E(q)), with J an antiunitary energy isometry.
The pair density r satisfies sup_e e^2 r(e)<infinity by its checked smooth
threshold behavior and rapid decay. Since E(p)<=E(p)+E(q),

 ||E beta1||_HS^2
  <=2h^2 integral e^2 r(e)|I_h,T(e)|^2de
  <=4pi A_*^2 tau_* ||e^2 r(e)||_infinity.            (T5)

The last inequality is temporal Plancherel, using
integral|I_h,T|^2=2pi integral_0^T|c_h(t)|^2dt and h^2T<=tau_*.
No second-moment secular limit is needed. The q=2 remainder in T4 yields

 ||E beta||_HS<=B_2,  ||E^(1/2)beta||_HS<=B_1,        (T6)

uniformly for small h and the fixed resources. The mass gap also bounds
||beta||_HS by B_2/m. This is an actual second-energy Hilbert-Schmidt
bound; a first-energy estimate alone would not establish it.

Unitarity gives the exact bounded-extension identity

 E^(q/2)(Z*-I)=-E^(q/2)(Z-I)Z*.                      (T7)

Indeed Z*-I=-(Z-I)Z*, so its range is in the same graph domain before
applying the closed energy multiplier. Thus T4's weighted operator bound
also holds for Z*. In particular alpha* preserves D(E).

For h0 small, delta is invertible with ||delta^-1||<=2. The off-diagonal
unitarity equation and the real structure give

 gamma*=-alpha* beta delta^-1,
 gamma*=Gamma beta* Gamma.                           (T8)

Consequently, using E alpha* beta=E beta+E(alpha*-I)beta,

 ||E gamma*||_HS
 <=2[||E beta||_HS+||E(alpha*-I)|| ||beta||_HS] <=B'_2. (T9)

This multiplication is legitimate: beta maps into D(E), and alpha*
preserves that domain. T9 controls the weighted off-diagonal block of
the inverse implementer Y*. It also bounds ||E beta*||_HS by real
conjugation, hence ||beta E||_HS by adjunction. No skew-symmetry of the
bare beta is assumed; its exact alpha/delta factors are retained.

Finally put Q=E^(1/2). Spectral calculus on the Hilbert-Schmidt class gives

 ||Q beta* Q||_HS^2
 <=(1/2)(||E beta*||_HS^2+||beta* E||_HS^2)<=B_x^2.   (T10)

One can verify this with bounded spectral cutoffs and the scalar inequality
xy<=(x^2+y^2)/2 for the commuting left/right energy variables, then pass
monotonically. The same statements hold for the inverse blocks: its beta
is gamma*, already controlled by T9, while its weighted full operator
bound follows from T7. All constants below may take the maximum for Y
and Y*. Only the q=1,2 instances and the supplied mass gap are needed.

## 3. A Fock energy graph lemma with all CAR terms

This section proves uniform constants c1,c2 such that, for U=Y or Y*,

 ||S U psi||<=c1||S psi||, psi in D(H^(1/2)),
 ||G U psi||<=c2||G psi||, psi in D(H).                (T11)

The domain conclusions are part of these estimates. They are not
assumed in order to take an unbounded energy trace.

For the forward direction, T1 gives for xi in the positive one-particle
space

 Y*a(xi)Y=a(alpha*xi)+a*(Gamma beta*xi).              (T12)

The star and the side of beta in this formula are important. For Y*
apply the same proof with the inverse block map.

Let E_L=min(E,L), and let (e_i) be any orthonormal basis. The CAR imply
the positive-form identities

 <z,dGamma(E_L)z>=sum_i ||a(E_L^(1/2)e_i)z||^2,

 ||dGamma(E_L)z||^2
  =sum_i ||a(E_L e_i)z||^2
    +sum_(i,j)||a(E_L^(1/2)e_j)a(E_L^(1/2)e_i)z||^2. (T13)

The second term is the ordered distinct-particle contribution; on each
particle sector the identity is
(sum E_i)^2=sum E_i^2+sum_(i!=j)E_i E_j.
Positive sums, finite particle truncations and then monotone limits make
T13 an extended positive-form identity for every Fock vector. No
finite-rank projection commuting with the continuous-spectrum E is used.

Set k_q=||E^(q/2)(alpha-I)|| and
a_q=(1+k_q/m^(q/2))^2, q=1,2. On the relevant graph domains,

 alpha* E^q alpha<=a_q E^q.                          (T14)

This follows by the triangle inequality for E^(q/2)alpha, not by
squaring the q=1 operator inequality. For u_i=E_L^(1/2)e_i write
f_i=alpha*u_i and g_i=Gamma beta*u_i. Then

 sum_i |f_i><f_i|=alpha*E_L alpha<=a_1 E,
 sum_i||g_i||^2<=B_1^2,
 sum_i||E^(1/2)g_i||^2<=B_x^2.                       (T15)

The last estimate uses T10 and Gamma E=E Gamma. The maps involving
Gamma may be antilinear; their squared column norms have the same
Hilbert-Schmidt interpretation. The bounded extension in T10 ensures
that the g_i appearing here have the needed form domain.

Applying T12 to the first identity in T13 and bounding the two column
vectors by the sum-of-squares inequality gives

 <Ypsi,H Ypsi><=2a_1<psi,Hpsi>+2B_1^2||psi||^2.      (T16)

First do this with E_L, then let L increase. This proves the first
domain assertion in T11 by monotone convergence.

For the first sum in the second identity T13, T14 with q=2 and T6 give

 sum_i||Y*a(E_L e_i)Y psi||^2
          <=2a_2||Hpsi||^2+2B_2^2||psi||^2.           (T17)

For the double sum expand
(a(f_j)+a*(g_j))(a(f_i)+a*(g_i)) into its four terms. Their squared
column norms obey the following bounds for psi in D(H):

 AA <=a_1^2||Hpsi||^2,
 CA <=a_1 B_1^2 <psi,Hpsi>,
 AC <=2a_1 B_x^2||psi||^2+2a_1 B_1^2<psi,Hpsi>,
 CC <=B_1^4||psi||^2.                                (T18)

For AA, the ordered two-particle operator is bounded by a_1^2 times
sum_(r!=s)E_r E_s, using T15 on each distinct tensor factor. It is
therefore bounded by a_1^2 H^2. This argument does not incorrectly
square noncommuting one-particle form inequalities.
For CA and CC use ||a*(g)||<=||g|| and sum the column norms.
For AC use the CAR
a(f_j)a*(g_i)=<f_j,g_i>-a*(g_i)a(f_j). Parseval and T14 give

 sum_(i,j)|<f_j,g_i>|^2
   =sum_i ||E_L^(1/2)alpha g_i||^2
   <=a_1 sum_i||E^(1/2)g_i||^2<=a_1 B_x^2.

These estimates include the scalar contraction term; dropping it would
leave the graph proof incomplete. Every bound is uniform in L and in
the number of basis columns retained.

Using ||v1+v2+v3+v4||^2<=4sum||v_i||^2 in T18, and then T17,

 ||H Ypsi||^2
 <=(2a_2+4a_1^2)||Hpsi||^2
    +12a_1 B_1^2<psi,Hpsi>
    +(2B_2^2+8a_1 B_x^2+4B_1^4)||psi||^2.           (T19)

To justify the left side, bound T13 on Ypsi first, where it is permitted
to be infinite. The transformed finite products in T12 are bounded CAR
operators, so the estimates apply without a prior domain assumption on
Ypsi. Pass through the positive basis sums and E_L cutoffs. Sectorwise
dGamma(E_L)^2 increases to H^2. Monotone convergence proves finiteness
and Ypsi in D(H), as well as T19. Since
<psi,Hpsi><=||psi||||Hpsi||, T19 and unitarity imply the second estimate
in T11. T7--T10 give the identical proof for Y*. All c1,c2 are uniform
on the accepted kinetic window and fixed drive resources.

## 4. Projection chains and the fixed-state tail estimate

Every spectral projection Pi=1_B(H) is a contraction in both the S and
G graph norms because it commutes with H. T11 therefore gives, for
each Heisenberg projection P_h=Y_h*Pi Y_h,

 ||S P_h S^-1||<=c1^2,  ||G P_h G^-1||<=c2^2.         (T20)

For n preceding projections in T2,

 ||S T_h S^-1||<=L1=c1^(2n+1),
 ||G T_h G^-1||<=L2=c2^(2n+1).                       (T21)

The bounds concern the graph-space extensions of these expressions.
They are independent of the bins and require a fixed finite n.

Let F_L=1_[0,L](H). For fixed finite-energy rho,
S rho^(1/2) is Hilbert-Schmidt and

 t_rho(L):=||S(I-F_L)rho^(1/2)||_HS^2
          =Tr[rho(I+H)1_(H>L)] ->0.                 (T22)

Apply T21 first to the high-energy part of the initial square-root density.
For its complementary part, H1_(H>R)<=R^-1 H^2 gives

 ||H^(1/2)1_(H>R) T_h rho^(1/2)||_HS^2
 <=2L1^2 t_rho(L)
       +(2L2^2/R)||G F_L rho^(1/2)||_HS^2
 <=2L1^2 t_rho(L)
       +(2L2^2/R)(1+L)(1+M_rho).                   (T23)

These are inequalities between Hilbert-Schmidt norms of graph-bounded
maps; no unbounded trace is cycled. They can also be checked column by
column and then summed positively. Taking L=sqrt(R) for R>=1 proves T3.
The proof uses the initial first-energy tail, not an initial second moment.

By functional calculus,

 ||A_h(tau)^(1/2)1_(A_h(tau)>R) C_h rho^(1/2)||_HS
       =||H^(1/2)1_(H>R) T_h rho^(1/2)||_HS.          (T24)

Thus Q25 follows with its correct Heisenberg ordering. In particular all
the unnormalized history states have finite final first energy. A bounded
first moment by itself would not imply this uniform-integrability result;
the uniform D(H) bound was used only on the truncated initial part.

## 5. Limiting postselected means and final-energy laws

Let E_tau=X0+S_tau be the already checked classical comparison variables:
X0 has initial law mu_rho, and S has the marked compound-Poisson increment
law of the accepted strict-gap chirp measure M, independent of X0. The
same X0 is used at every observation. Let F be a fixed preceding regular
coarse-bin history and define the positive subprobability measure

 nu_h^F(B)=Tr[C_h rho C_h* 1_B(A_h(tau))].            (T25)

The prepared512 bounded-test/projection passage gives

 nu_h^F => nu^F,  nu^F(B)=E[1_F 1_(E_tau in B)].     (T26)

T3 gives uniform integrability of its energy. Hence bounded truncation
followed by R->infinity proves

 integral x nu_h^F(dx) -> E[E_tau 1_F].              (T27)

The target is finite because E[E_tau]=M_rho+integral e dM_(u<=tau).
This does not apply the fixed-initial-state mean theorem to a moving
collapsed state. It uses the new tail estimate on that state.

A regular final bin, including an unbounded one, may also be imposed.
The bounded-protocol theorem gives its restricted weak limit and success
probability; its energy tails are bounded by those in T3. Therefore, for
any such fixed full history F with limiting success probability p_F>0,

 conditional final mean -> E[E_tau 1_F]/p_F,
 conditional final-energy law -> Law(E_tau | F) in W1. (T28)

This is the physical final free-energy mean of the postmeasurement state:
the final spectral projection commutes with A_h(tau), and the full final
propagator transports the Heisenberg history to the actual Lüders chain.
Its extra free rotation commutes with H, so using Y or the full propagator
gives the same energy. Division is justified only after success
probabilities converge to a positive value. Weak convergence and the
separately proved finite means give the stated one-dimensional W1 limit.

Finite unions of recorded histories are covered by summing their positive
subprobability measures. The number of recorded histories is fixed and
finite, so the tail bound survives that sum. In particular, summing a
complete finite partition gives the nonselective final mean limit
M_rho+integral e dM_(u<=tau). No limiting conditional quantum-state trace
norm or instrument-independent continuous-energy path law is asserted.
Vanishing-success-probability histories remain outside T28.

## 6. Optional compact-family uniformity and exact boundaries

If C_E is compact in weighted trace norm within normalized finite-energy
densities, its initial tails T22 vanish uniformly. Indeed the positive
operators Q_rho=S rho S form a trace-norm compact family, and the bounded
spectral projections 1_(H>L) converge strongly to zero. Their traces tend
uniformly to zero on that compact family by finite-rank approximation and
a finite trace-norm net. Also sup_(rho in C_E)(1+M_rho)<infinity.
Thus T23 proves Q25 uniformly over C_E.

For fixed regular bins satisfying prepared512's condition for every member,
its bounded history convergence is uniform over C_E. Truncating the energy
and using the uniform tails proves uniform unnormalized mean convergence.
If the relevant limiting success probabilities are bounded below by a
positive common number, division gives uniform conditional means.
Uniform conditional W1 follows by the same compact-subsequence argument:
along rho_h->rho_* in weighted trace, target bounded tests converge by
trace duality and target means converge because their positive energy
kernel is bounded above by H+constant. The exact laws have the same weak
limit and mean, so W1 follows. No boundary-density rate is required.

The mass gap, fixed higher weighted drive resources and bounded observation
count enter the constants. The initial-tail modulus enters T23. This is
not a bound uniform over an unrestricted first-energy ball, and it does
not contradict the previously preserved moving-state counterexamples.
The proof gives no growing-observation, shrinking-bin, feedback, massless,
threshold-crossing or arbitrary actual-Hamiltonian result. Actual-cell
transfer of these new tails would need corresponding uniform forward and
inverse graph bounds and the exact common energy instrument; it is not
claimed from a norm-close propagator or a first-commutator estimate alone.

## 7. Failed shortcuts, independent checks and exposure

The direct first-energy-form route was insufficient: a uniform bound on
the means of moving history states does not prove their uniform tails.
Likewise, squaring a form inequality would be invalid for noncommuting
one-particle energies. The proof instead uses the q=2 input and the exact
single- and double-annihilation decomposition T13. Assuming beta itself
skew would also give an unjustified inverse-weight shortcut; T8 retains
the actual block factors.

Separate analytic evidence checks the particle-count factors, the scalar
CAR contraction in AC, a high-energy pair family that separates first
weighted bounds from the required second-energy graph input, and the
cutoff tail estimate. No proposed-science numerical command is run.

Earlier complete prepared512/root340 and their source-exposed comparison,
initial407, compact-preparation and vacuum multi-time work are conceptual
exposures. The accepted chirp weighted statements were already exposed and
are used as premises. This new target's root plans/proofs/findings,
POSTMEASUREMENT_ENERGY_UI_ROOT files and future root folder, all threshold
sources, root checkpoints and opportunity notes were not opened. The
neutral plan records the pre-plan dense-core idea. No model diversity or
absence of prior relevant ideas is claimed. Selected model and effort are
unchanged; no extra agent, other chat, Git/CW mutation, prompt edit, audit
action, scientific runtime or Lean certificate supports this derivation.
