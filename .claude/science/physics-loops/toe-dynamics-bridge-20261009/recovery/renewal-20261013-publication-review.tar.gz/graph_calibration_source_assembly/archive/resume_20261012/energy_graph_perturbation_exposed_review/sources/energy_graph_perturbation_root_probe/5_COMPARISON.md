# Comparison of the frozen postmeasurement energy-tail derivations

The ideal Q25 conclusion is supported by both frozen proofs at their stated
conditional scope. I found no required formula or domain correction. Root's
additional actual-cell conclusion is also justified under its exact common-H,
bounded-control and small bounded-commutator-error hypotheses: those hypotheses
produce the additional uniform graph bounds left conditional in independent390.
The root high-rank control correctly disproves a weaker inference, while lying
outside the fixed-slot theorem. Full analytic reconstruction is in
evidence/DECISIVE_ANALYTIC_EVIDENCE.md, not delegated to a numerical check.

This is an exposed mathematical review of root306 and rootcontrol84 by the
author of independent390. Rechecking the latter is author self-check. The two
derivations were frozen before their target findings were shared, but they use
the same exposed parents and model family. No new model diversity, retained
audit, formal certificate or empirical validation is claimed.

## 1. Exact compared sources and chronology

The source manifest binds complete originals, seals and declared source
closures. The consequential pins are:

| Source | Lines | SHA256 |
| --- | ---: | --- |
| POSTMEASUREMENT_ENERGY_UI_ROOT_PROBE.md | 306 | 1dfe0c91716ade6e0cfc81ac4e185fa8e0783098963e2fea2460077ba768f639 |
| POSTMEASUREMENT_ENERGY_UI_ROOT_SEAL.json | 103 | 82e977c015f101e6f0e597707805aa89125b187ea9be0ef56c887245b525b87d |
| postmeasurement_energy_ui_independent/DERIVATION.md | 390 | 9597693aa9fc6aebb93de7419d4e4dbb74a6156531179fef27e6107e75cf7c96 |
| independent evidence/ANALYTIC_EVIDENCE.md | 170 | d392d3ffae7fdb718a7219ca118f01dac91e35a82851296826ea0e8b7be2d0c7 |
| independent FINAL_FREEZE.json | 139 | 96865ed38c3344481ccfe26843fe6718fe3eb094e98933c563366377cf6bc0b2 |
| POSTMEASUREMENT_ENERGY_UI_ROOT_COUNTERCONTROL.md | 84 | 1bea9837de02088791faa010c86d7c0baf9364662849ab23e15dd8176a56db2a |
| countercontrol seal | 8 | b45885069ff978acf9983fb548e094ed708506390daecc086da3695bd61a5923 |

Root306 was sealed at14:58:19 UTC. Rootcontrol84 was sealed at15:25:00.
Independent390 and its full evidence were frozen at15:25:11; the root bodies
and finite-Fock diagnostic remained excluded through that freeze. This new
comparison's neutral plan was sealed before reading those new bodies. Root's
earlier pending wording and the prepared512 Q25 open-obligation wording remain
unchanged historical records. Their scope is not retroactively rewritten.

The 59 direct source/snapshot pairs preserve the full 19-member independent
freeze, all13 source pairs in the root seal, both target proofs and control,
and the finite diagnostic with its review and logs. This is the declared
closure, not a claim to recursively audit every ancestor named in those files.
No threshold source or unrelated active mathematical finding was opened.

## 2. The common result and the two different graph arguments

The supplied setting is massive free fermionic Fock space over the positive
band, H=dGamma(E), E>=m>0, with fixed smooth real slots, bounded BV amplitude
and strict-gap frequency resources, and a fixed kinetic horizon. Write A=I+H.
For finitely many Heisenberg projections P_j=Y_j*1_(B_j)(H)Y_j and
L_h=Y_f P_n...P_1, both proofs establish

 lim_(R->infinity) sup_(h small, drives within the fixed bounds)
  ||H^(1/2)1_(H>R)L_h rho^(1/2)||_HS^2=0            (C1)

for each fixed finite-first-energy normal density rho. No Gaussian, parity,
purity or energy-diagonality restriction is imposed. The tail bound is uniform
over arbitrary Borel bins and times in the fixed horizon with bounded finite
observation count. The probability and conditional-law limits still keep the
profiles and regular measurement protocol fixed. C1 is stronger than Q25's
limsup in h; it is not uniform over an unrestricted first-energy ball.

The load-bearing correspondence is:

| Step | Root route | Independent route | Assessment |
| --- | --- | --- | --- |
| Second weighted pair HS bound | U4, integrable correlation kernel for e^2r | T5, bounded e^2r and temporal Plancherel | Both valid finite-time estimates |
| Inverse block | U5, u*beta+gamma*d=0 | T7--T10, same inverse plus right half-weights | Correct products and domains; no skew-beta shortcut |
| Full Fock graph | U7--U8, normal-ordered energy and N-relative pair operator | T13--T19, single/double annihilation positive sums | Distinct valid proofs |
| Half graph | Interpolation U9 | Direct first-energy estimate T16 | Both uniform for Y and Y* |
| Fixed-state extension | Weighted trace cutoff U11--U12 | Initial square-root cutoff T22--T23 | No initial second moment needed |
| Actual-cell transfer | Small graph difference U13--U14 | Left as an extra graph condition | Root supplies that condition under its stated assumptions |

The common accepted q=2 input is a weighted one-particle estimate, not an
assumed Fock second moment. General470's full radial argument shows
r(2m+s)=s rho(s) with smooth rho and rapid decay. It also justifies root's
polynomial extension to e^2r: two integrations by parts retain the finite
threshold derivative boundary term and give an L1 time correlation. A separate
Plancherel bound checks the same estimate with fewer regularity requirements.

The inverse identity E(Z*-I)=-E(Z-I)Z* is a bounded extension with a genuine
range/domain argument. In gamma*=-u*beta d^-1, beta maps into D(E), u*
preserves D(E), and d^-1 is applied before beta. The resulting HS estimate
does not transpose a left weight without proof. Independent390's additional
two-sided half-weight estimate follows from reality and the two one-sided
weights, so it does not add an unproved assumption.

I reconstructed root U7 directly from the transformed annihilator
Y*a(xi)Y=a(u*xi)+a*(Gamma beta*xi). Normal ordering gives the positive vacuum
scalar, negative hole term and pair coefficient B=beta*Eu=(E beta)*u with
exactly the displayed order and sign. Grouping the pair coefficients gives
norm at most sqrt(2)||B||_HS; exterior-product normalization proves U8 on
D(N). The proof uses operator bounds on vectors, not only state expectations.
Energy cutoffs, bounded strong limits of the normal remainder, HS convergence
of pair coefficients, and closedness justify the infinite-dimensional identity.

Independent390's positive-sum method retains the scalar AC contraction and
uses distinct tensor factors for the AA estimate. Its coefficients in T19
are correct. Monotone cutoff sums establish Ypsi in D(H) at the end; no
unproved squared form inequality or prior output H^2 moment is inserted.
For root, the finite-time bounded-commutator domain argument is legitimate
and is not confused with the uniform graph estimate derived afterwards.

## 3. Projection order, state quantifiers and moments

Both forward and inverse graph bounds are needed for
Y_j*1_(B_j)(H)Y_j. Spectral projections contract the two H graph spaces,
including for unbounded bins. Products then have graph constants depending
on n but not on their endpoints. The final transformation is exactly

 A_f^(1/2)1_(A_f>R)C_h
   =Y_f*H^(1/2)1_(H>R)Y_f C_h,  A_f=Y_f*HY_f.

This proves that C1 is Q25, without commuting projections at different times
or replacing the moving history state by a new fixed initial state.

Root's rho_K=1_(H<=K)rho1_(H<=K) is unnormalized and converges in weighted
trace norm. The cutoff can have infinite rank. The tail form is uniformly
bounded by a constant times I+H; its error on rho-rho_K is therefore controlled
by weighted trace duality. Its value on rho_K is bounded by
C(1+K)(1+Tr(Hrho))/R. Independent390 splits rho^(1/2) instead and obtains
its explicit two-term estimate T23. These are compatible extensions from
energy-truncated data, including fixed states whose second energy is infinite.

Combining C1 with the supplied prepared bounded-protocol theorem gives
unnormalized final first-moment convergence. In the limit the final energy is
the shared initial variable X0 plus the marked compound-Poisson increments;
earlier regular coarse-bin events condition their partial sums. A regular
unbounded final bin is permitted. Histories of limiting mass0 have vanishing
unnormalized first moment, but neither source claims a normalized limit there.
For positive limiting mass the conditional final mean and one-dimensional
final-energy W1 converge. Finitely many recorded histories can be summed.

Weighted-trace-compact families must consist of finite-energy densities.
Their initial tails are uniform, as are the graph bounds. Fixed regular-bin
probability limits are uniform over those compact families by the supplied
finite-net result. Truncation then gives uniform unnormalized means; normalized
means/W1 require a common positive success lower bound. The proofs do not
establish quantum-state trace convergence, unrestricted-state uniformity,
moving-boundary law convergence, feedback, or diverging measurement count.

## 4. The actual-cell scope difference is resolved positively

Root assumes the exact same H and spectral projectors in the common embedded
representation, bounded self-adjoint controls V_a,V, and

 ||V_a-V||<=d0 epsilon, ||[H,V_a-V]||<=d1 epsilon,
 ||[H,V_a]||,||[H,V]||<=k.

These commutators have their bounded graph-domain meaning. Let
b(T)=integral_0^T|lambda c(s)|ds<=A_star tau_star/h. Commuting H through
the three-factor Duhamel difference gives exactly

 ||W_a-W||<=d0 epsilon b,
 ||[H,W_a-W]||<=epsilon(d1 b+d0 k b^2).

The two outside propagator contributions add to b(T)-b(s)+b(s)=b(T).
No derivative of a BV profile is needed. Free conjugation preserves the
norms, and the adjoint commutator has the same norm. Therefore

 ||A(Y_a-Y)A^-1||, ||A(Y_a*-Y*)A^-1||
  <=epsilon[(d0+d1)b+d0 k b^2].                    (C2)

Under epsilon=o(h^2), C2 tends to zero uniformly over the fixed resources.
Adding it to the ideal graph estimates proves the needed actual forward and
inverse full graph bounds; unitarity and interpolation give half-graph bounds.
This independently verifies root U13--U14 at its exact sufficient scale.
No assertion of scale optimality is made.

Actual chains with the same measured H consequently satisfy the tail lemma.
If d_E(rho_a,rho)->0, their tail errors from changing initial state are bounded
uniformly in R by C d_E(rho_a,rho). The existing weak comparison follows from
trace convergence and ||Y_a-Y||<=d0 epsilon b->0. The new tails therefore
transfer unnormalized means and positive-probability conditional W1. The
compact-family version requires uniform paired weighted approximation and
the same uniform control resources. No physical embedding or calibration is
constructed by this conditional argument.

Independent390 did not reject this inference; it reserved actual transfer
until the additional graph hypotheses were proved. Root's stronger argument
now proves them from its precise assumptions. A publication wrapper should
state that resolution explicitly. It must not turn the independent note's
reservation into a claim that a small bounded commutator of the propagator
difference cannot control graph norms. An unweighted error alone, or an
absolute first-commutator work bound growing like h^-1, would still be
insufficient for this argument. No frozen source edit is required.

## 5. Root control and finite diagnostic

Rootcontrol84's high-rank family is valid. With R^2 independent pair rotations,
p_R=R^-3 and wave packets in [R/2,R/2+1], its vacuum output has nonvacuum
probability at most1/R but mean in [1,1+2/R]. All that mean lies above any
fixed cutoff for large R. Thus its energy law tends weakly to delta0 while
UI fails. The continuum shell supports arbitrarily many orthonormal smooth
packets; no exact energy eigenvectors or invariant finite span are assumed.

The same example has ||E(Z_R-I)||=O(R^-1/2), uniformly bounded forward/inverse
first-energy forms, and ||E beta_R||_HS^2>=R/2. Its full Fock graph bound
fails already on vacuum. It therefore correctly isolates the missing
second weighted pair HS/domain step. The varying rank and slots violate the
positive theorem's fixed-resource hypotheses. This is a scoped invalid-
inference control, not a universal no-go or proof that the chosen graph
criterion is necessary. Independent evidence170's single-pair control remains
correct at its explicitly weaker graph-only scope.

The archived finite program and its snapshot both have SHA
9bfd0ddeb159583e6e137859b72b49a41f5423664969f5673b9ad8257694798d.
The complete code, pre-run seal, RESULT, stdout/stderr and root diagnostic
review were inspected. The recorded three cases compare full finite Fock
operators with separately exponentiated Nambu dynamics and discriminate four
prescribed wrong formulas. The recorded exit is0, elapsed0.8381239157170057s,
maximum correct-form residual2.760140320569077e-14, and minimum mutant residual
0.007850628238697938. Those facts are preserved as finite floating algebra
evidence only. They neither prove domains/UI nor supply model independence;
the program was not rerun in this comparison.

## 6. Disposition and remaining obligations

The two ideal tail arguments and root's exact actual-cell extension are
mathematically compatible. The source-exposed reconstruction found no required
correction; the actual-cell scope difference should be explained as above.
The complete positive theorem remains conditional on the accepted strict-gap
free model, its q=2 weighted estimates, and the supplied prepared-protocol
weak limits for the conditional-law consequences. Rootcontrol retains only
its stated invalid-inference scope.

Independent390 has been self-checked here; the parent's separate full analytic
read remains a distinct review action. This comparison is not a retained
audit of either source. Actual physics still requires the exact common-H
instrument, calibration and weighted-state hypotheses. Rare normalized
events, arbitrary energy-bounded moving initial families, growing protocols,
threshold dynamics and absent embeddings are not resolved by this package.

Only this new comparison directory was written. No original proof, frozen
source, CW/Git state, cache/pipeline, audit, physical axiom or editable prompt
was changed. No new scientific numerical or Lean execution was performed.
The read-only identity helper verifies declared bytes and source closure;
its mathematical predicate count is zero.
