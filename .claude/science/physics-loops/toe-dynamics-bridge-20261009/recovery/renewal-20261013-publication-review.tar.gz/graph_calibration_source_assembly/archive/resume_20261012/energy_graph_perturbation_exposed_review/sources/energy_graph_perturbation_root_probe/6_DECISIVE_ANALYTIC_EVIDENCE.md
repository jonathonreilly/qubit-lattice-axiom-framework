# Analytic comparison of the two energy-tail proofs

This is a source-exposed check of root306 and rootcontrol84. The same agent
authored independent390/evidence170, so examination of those files is author
self-check, not a new independent review. No numerical program is executed.
U labels refer to root306; T labels refer to independent390. The exact source
manifest and frozen complete source payloads accompany this file.

## E1. Weighted Born bound and inverse domains

The source pair kernel gives, without taking a kinetic limit,

 ||E beta1||_HS^2
  <=2h^2 integral e^2 r(e)|I_(h,T)(e)|^2de.

The factor2 is the unweighted exterior-pair normalization. Only the
inequality E(p)^2<=(E(p)+E(q))^2 is used; the first-moment symmetrization
formula is not reused as an exact second-moment formula.

For b(e)=e^2 r(e), the complete general470 radial argument supplies
r(2m+s)=s rho(s), one-sided smoothness and rapid decay of every derivative.
Multiplication by e^2 preserves these properties. Thus b(2m)=0, b'(2m)
is finite, and b,b',b'' are integrable on the positive half-line. Extending
b by zero, two integrations by parts give for t!=0

 |C_b(t)|<= (|b'(2m)|+||b''||_1)/t^2,
 |C_b(t)|<=||b||_1,
 C_b(t)=integral_(2m)^infinity b(e)exp(ite)de.

The boundary derivative term is retained. Therefore C_b is in L1(R).
Fubini at finite T, using |c|<=A_star, gives

 integral b(e)|I_(h,T)(e)|^2de
  <=A_star^2 integral_0^T integral_0^T |C_b(t-s)|dsdt
  <=A_star^2 T ||C_b||_1.

This verifies U4. A distinct check is temporal Plancherel:

 integral b|I|^2<=||b||_infinity integral|I|^2
                <=2pi ||b||_infinity A_star^2 T.

It verifies T5 using only bounded b. The constants need not agree: these
are two upper bounds. Combining either with h^2T<=tau_star and the accepted
q=2 remainder proves uniform ||E beta||_HS without assuming a Fock H^2
moment, a secular second-moment limit, or an emission interpretation.

Let Z=[[u,beta],[gamma,d]]. The bounded-extension identity

 E(Z*-I)=-E(Z-I)Z*

has a domain justification before it has a norm bound: Z*-I=-(Z-I)Z*,
and the range of Z-I lies in D(E). Consequently u* preserves D(E).
For h small, d is invertible with ||d^-1||<=2, and

 gamma*=-u* beta d^-1,
 E gamma*=-(E beta+E(u*-I)beta)d^-1.

Here beta has range in D(E), its HS norm is bounded by ||E beta||_HS/m,
and E(u*-I) is bounded. No input graph property of d^-1 is needed: beta
acts after d^-1. The first product is weighted HS and the second is bounded
times HS. This proves U5 and T9 with the correct block order.

For the independent annihilation proof one also needs right weights.
Reality gives gamma*=Gamma beta* Gamma, with Gamma E=E Gamma. It follows
that E beta* is HS, while beta*E is the adjoint of E beta. Hence, with
commuting left and right energy variables on the HS class,

 ||E^(1/2)beta*E^(1/2)||_HS^2
  <=[||E beta*||_HS^2+||beta*E||_HS^2]/2.

Bounded spectral cutoffs followed by monotone convergence justify this
inequality. For the inverse block gamma*, the corresponding two one-sided
norms follow from E gamma* above and E gamma=Gamma(E beta)Gamma. Thus the
extra half-weight step in independent390 uses no extra scientific premise.
Neither proof treats the bare beta as skew or the identity as HS.

## E2. Direct CAR reconstruction of the normal-ordered root operator

This reconstructs U7 by energy cutoffs, rather than taking agreement with
the stored finite diagnostic or the earlier covariance formula as proof.
Annihilation is antilinear and inner products are linear in the second
argument. Since b(Gamma xi)=a(xi) for xi in PK and Z commutes with Gamma,

 Y*a(xi)Y=a(u*xi)+a*(Gamma beta*xi).                  (E1)

Take a bounded positive one-particle operator D_0 and an orthonormal basis
(e_i) of PK. Put f_i=u*D_0^(1/2)e_i and
g_i=Gamma beta*D_0^(1/2)e_i. The transformed number-energy expression is

 sum_i [a*(f_i)+a(g_i)][a(f_i)+a*(g_i)].

The four terms give respectively

 dGamma(u*D_0 u),
 sum_i a*(f_i)a*(g_i),
 sum_i a(g_i)a(f_i),
 Tr(D_0 beta beta*) I-dGamma(Gamma beta*D_0 beta Gamma).

The negative hole sign is the CAR exclusion sign. To check the pair order,
let B_0=beta*D_0 u and B_(j,i)=<Gamma e_j,B_0 e_i>. Expanding the third
term with the antilinear annihilator convention gives

 sum_(i,j) B_(j,i) a(e_j)a(e_i)
       =-sum_(i,j) B_(j,i) a(e_i)a(e_j).

This is precisely Pi_B in U7, without an additional factor1/2. Its adjoint
is the other cross term. The formulas concern the positive Fock space PK;
Gamma transports the negative-band hole operator back to that space.

The following cutoff argument handles convergence. Fix h and finite T.
The fixed bounded smooth-slot control has bounded [H,V], so it preserves
D(H). Dyson/Duhamel evolution on that graph space and closure prove that
Y and Y* preserve D(H) for this finite time. The finite-time graph bound
may grow with h^-1; it is used only to make the following identities
well-defined, not as the desired uniform estimate.

First take D_0=E_L=min(E,L). Finite basis sums may be implemented with
E_L^(1/2)Q_j E_L^(1/2), where Q_j increases strongly to I; these cutoffs
need not commute with E. At fixed L, their normal operators converge
strongly with a common norm bound, their pair coefficients converge in HS
norm, and their scalar traces converge against beta beta*. The finite-rank
CAR identity is bounded and exact. Its left side converges on Ypsi in
D(H) subset D(N), and the right side converges on psi in D(H) subset D(N),
using the common N-graph bounds. There is no finite-rank energy-eigenprojection
assumption in continuous spectrum.

Write L_0=u-I. Then

 u*E_Lu-E_L=L_0*E_L+E_LL_0+L_0*E_LL_0.

E_LL_0=(E_LE^-1)(EL_0) and L_0*E_L=(EL_0)*(E^-1E_L)
converge strongly, with uniform bounds, to EL_0 and (EL_0)*. Also
E_L beta->E beta in HS norm. Therefore the bounded one-particle
remainders C_(0,L) converge strongly, uniformly bounded, to

 C_0=u*Eu-E-Gamma(beta*E beta)Gamma,

while B_L=beta*E_Lu->B=(E beta)*u in HS norm and
c_(0,L)->c_0=||E^(1/2)beta||_HS^2. For psi in D(N), a strongly convergent
uniformly bounded sequence C_(0,L) yields
dGamma(C_(0,L))psi->dGamma(C_0)psi: use finite particle sectors first,
then dominate the sector tail by a constant times ||Npsi||.

The pair limits are justified by E3 below. Since psi and Ypsi are in
D(H) for the fixed finite time, dGamma(E_L)psi->Hpsi and
dGamma(E_L)Ypsi->HYpsi. Taking L->infinity consequently proves

 Y*HY=H+dGamma(C_0)+Pi_B+Pi_B*+c_0 I                 (E2)

on the H graph core, with exactly U7's signs and transposes. This also
checks the operator identity beyond its expectations on quasifree states.
In particular, no Wick assumption is used for an arbitrary initial rho.

## E3. Pair HS control, closure and the other graph proof

For a finite coefficient array B, grouping i<j in Pi_B gives coefficient
c_(i,j)=B_(i,j)-B_(j,i). Thus

 sum_(i<j)|c_(i,j)|^2<=2||B||_HS^2.

The two-particle coefficient vector has norm at most sqrt(2)||B||_HS.
Antisymmetrization is a contraction; the normalization of exterior powers
gives creation bound sqrt(binomial(n+2,2)) times that vector norm on the
n-particle sector. The adjoint bound is sqrt(binomial(n,2)). Hence

 ||Pi_B psi_n||<=sqrt(n(n-1))||B||_HS||psi_n||,
 ||Pi_B*psi_n||<=sqrt((n+1)(n+2))||B||_HS||psi_n||.

The images of distinct input sectors are orthogonal for each of these
operators. Summing their squared norms proves U8 on D(N). Approximating
an arbitrary HS array by finite arrays gives convergence in the indicated
N-graph operator norms; this is not an unsupported bounded-Fock-operator
claim for a general pair creation operator.

The remaining root terms are controlled as follows:
EL_0 is bounded, L_0*E=(EL_0)*, and
u*Eu-E=(EL_0)*+EL_0+L_0*EL_0. The hole term beta*E beta is bounded,
B=(E beta)*u is HS, and
c_0<=||E beta||_HS||beta||_HS. All constants are uniform by E1.
Since N<=H/m and ||dGamma(C_0)psi||<=||C_0||||Npsi||, E2 gives

 ||HYpsi||=||Y*HYpsi||<=C||(I+H)psi||.

Closure from the graph core proves root U6 on every D(H) vector. The
inverse uses its own off-diagonal block gamma*, already controlled in E1.
This route is logically independent of squaring the first-energy form.
Interpolation between the ordinary unitary norm and the full graph norm
then gives the half-graph bound U9. Spectral-cutoff vectors justify the
three-lines proof for (I+H)^zY(I+H)^(-z); cutoff limits preserve the bound.

Independent390 instead uses the exact positive identity

 ||dGamma(E_L)z||^2
  =sum_i||a(E_L e_i)z||^2
   +sum_(i,j)||a(E_L^(1/2)e_j)a(E_L^(1/2)e_i)z||^2.

On each particle sector this is sum E_i^2 plus the ordered distinct-factor
sum E_iE_j. The AA bound uses a positive operator inequality on each of
two distinct tensor factors, not a square of a noncommuting inequality.
The AC term includes the scalar contraction; its squared sum is bounded
by a_1||E^(1/2)beta*E^(1/2)||_HS^2. CA and CC are bounded by creation
norms. Applying four-term Cauchy--Schwarz gives exactly T19's coefficients
2a_2+4a_1^2, 12a_1B_1^2, and 2B_2^2+8a_1B_x^2+4B_1^4.
All positive sums are bounded before sending E_L upward. Since E_L is a
function of E, dGamma(E_L)^2 increases sectorwise to H^2; this proves
Ypsi in D(H) rather than assuming that domain at this stage.

The authored evidence170's two-mode pair-rotation calculation correctly
counts the ordered factor2 and isolates the AC contraction at order theta^2.
Its single high-energy-pair example has vanishing first mean and divergent
second mean, as stated. It is not mislabeled as a failure of UI itself.

## E4. Truncation and exact history order

Write A=I+H and S=A^(1/2). Every Pi_B=1_B(H) contracts both graph spaces,
even when B is unbounded or has irregular boundaries. Forward and inverse
graph estimates therefore apply to L_h=Y_f P_n...P_1 in its actual order.
No commuting assertion about different P_j is needed.

For rho>=0 of finite first energy, Q=S rho S is trace class. With
F_K=1_[0,K](H), strong F_K->I implies

 ||Q-F_K Q F_K||_1->0.

This is root U11 and permits infinite-rank energy cutoffs and unnormalized
rho_K=F_K rho F_K. For a quantitative comparison with T22, define
t_rho(K)=Tr[Q(I-F_K)]. Factoring Q through its HS square root gives

 ||Q-F_KQF_K||_1<=2 sqrt(Tr Q) sqrt(t_rho(K)).

The positive tail form L*H1_(H>R)L, sandwiched by S^-1, has norm at most
the squared half-graph constant. Weighted trace duality bounds the error
from rho-rho_K. On rho_K, the full graph bound and H1_(H>R)<=H^2/R give

 Tr[L*H1_(H>R)L rho_K]
  <=C_2^2(1+K)Tr(A rho)/R.

Choosing K first then R proves root U3. Independent T23 instead splits
rho^(1/2) and controls its high-energy columns directly; its factor2 and
choice K=sqrt(R) are valid and require the same initial first moment.
Neither uses Tr(H^2rho)<infinity or cycles an unbounded trace informally.

Finally, if A_f=Y_f*HY_f, spectral calculus gives

 A_f^(1/2)1_(A_f>R)C_h rho^(1/2)
  =Y_f*H^(1/2)1_(H>R)Y_f C_h rho^(1/2).

Left unitary multiplication does not change the HS norm. This verifies
Q25 and the precise final-Y ordering. A final bin projection commutes with
A_f, so imposing that bin can only decrease its positive energy tail.

## E5. Actual-cell transfer under the exact commutator hypotheses

This is a fresh analytic check of root U13--U14, not an inference from the
independent note's conservative omission. Let H be the exact common measured
Hamiltonian, V,V_a bounded self-adjoint controls, and DeltaV=V_a-V. Assume
their bounded commutators have the graph-domain meaning and satisfy

 ||DeltaV||<=d0 epsilon, ||[H,DeltaV]||<=d1 epsilon,
 ||[H,V]||,||[H,V_a]||<=k.

If the commutators are initially specified as bounded forms on D(H), the
adjoint-domain criterion implies V D(H),V_a D(H) subset D(H): the bounded
form identity makes psi-><Hpsi,Vphi> continuous in the ordinary norm for
each phi in D(H). Thus this domain interpretation is justified rather
than a formal multiplication by H.

Put f(t)=lambda c(t), b(t)=integral_0^t|f(s)|ds. Finite-time evolution
preserves D(H); the exact commutator identities yield

 ||[H,W_a(t,s)]||<=k(b(t)-b(s)),
 ||[H,W(s,0)]||<=k b(s).

Duhamel is

 D(t):=W_a(t,0)-W(t,0)
      =-i integral_0^t W_a(t,s) f(s)DeltaV W(s,0)ds.

Commuting H through its three factors on D(H), then taking norms, gives

 ||D(t)||<=d0 epsilon b(t),
 ||[H,D(t)]||
  <=epsilon integral_0^t |f(s)|[d1+d0k(b(t)-b(s))+d0k b(s)]ds
  =epsilon[d1 b(t)+d0k b(t)^2].                    (E3)

The outside contributions add to b(t), not to two independent worst-case
copies of b(t). No derivative of c or impulsive term is present; its real
bounded measurable/BV profile is compatible with these integral identities.
Finite-time graph-space approximation and closure justify the integral
commutator as a bounded extension. This proves U13 with its stated factor.

The interaction-picture difference is DeltaY=e^(itH)D(t), so both norms
in E3 are unchanged. Also [H,DeltaY*]=-[H,DeltaY]*. On D(H),

 A DeltaY A^-1=DeltaY+[H,DeltaY]A^-1,

and the corresponding formula holds for DeltaY*. Consequently

 ||A DeltaY A^-1||, ||A DeltaY* A^-1||
  <=epsilon[(d0+d1)b+d0k b^2].                     (E4)

For T<=tau_star/h^2, b<=A_star tau_star/h. Thus epsilon=o(h^2) makes
both graph differences tend to zero. Adding them to the ideal uniform
graph bounds proves uniform actual forward/inverse D(H) bounds. Actual
unitarity and interpolation give the half-graph bounds as well. Root's
stated sufficient scale is valid; no necessity or optimality is claimed.

The actual chains built with the same 1_B(H) now meet the abstract tail
lemma. For weighted initial approximation d_E(rho_a,rho)->0 their positive
tail forms are uniformly bounded by a constant times A, so

 |tail_(a,h,R)(rho_a)-tail_(a,h,R)(rho)|
                        <=C d_E(rho_a,rho),

uniformly in R and the fixed protocol. The tails for fixed rho vanish
uniformly by the graph lemma. Hence the actual varying-state sequence is
uniformly integrable in the limiting sense required for moment transfer.
Weighted convergence also gives ordinary trace convergence, while
||DeltaY||<=d0 epsilon b=o(1). The supplied fixed regular-protocol weak
comparison therefore combines with these tails to give unnormalized means
and positive-probability conditional W1. Uniform paired d_E approximation
to a d_E-compact finite-energy family gives the same uniform conclusion.

This proves the missing actual graph hypotheses from the precise root
assumptions. It does not follow from an unweighted propagator error alone,
or from a uniform bound on [H,V_a] alone: that latter route would only give
an O(h^-1) propagator commutator. The small commutator of the control
difference, the Duhamel comparison, and the ideal q=2 graph bound all
matter. Independent390's reservation is a narrower scope, not a theorem
that these exact stronger assumptions cannot suffice.

## E6. Root high-rank control: a valid invalid-inference example

For integer R>2m, choose 2R^2 orthonormal positive-band wave packets in
the shell [R/2,R/2+1]. That continuum shell has infinite rank. Smooth
compact momentum support places the packets in every energy domain.
Set N_R=R^2, p_R=R^-3 and sin(theta_R)=sqrt(p_R). Distinct orthogonal
even pair rotations commute and their vacuum output is the displayed
product. Pair count is Binomial(N_R,p_R); nonvacuum probability is at
most N_Rp_R=1/R. The pure-state trace distance from vacuum is therefore
at most 2/sqrt(R), implying weak energy-law convergence to delta0.

Although the selected finite span need not be E-invariant, the entire
shell is spectral and E-invariant. Every nonvacuum output sector has
energy at least R. The occupation is p_R Q_R, so

 M_R=p_R Tr(E Q_R),  1<=M_R<=1+2/R,
 <Y_R Omega,H1_(H>L)Y_R Omega>=M_R  when R>L.

The mean therefore fails to converge to the weak limit's mean; UI fails.
No continuous-spectrum eigenvector fiction or cancellation of positive
energy has entered this calculation.

The pair block has 2N_R singular values sqrt(p_R). Its range and the range
of Z_R-I lie in the corresponding signed energy shell. Thus

 ||E^(1/2)beta_R||_HS^2=M_R,
 ||E beta_R||_HS^2>=2N_Rp_R(R/2)^2=R/2,
 ||E(Z_R-I)||<=(R/2+1)2sqrt(p_R)=O(R^-1/2).

The last inequality needs only shell support of the range, not invariance
of the finite selected span. Reversing theta gives the same inverse bounds.
Moreover u_R-I=(cos(theta_R)-1)Q_R, so its half-weighted operator norm is
uniformly bounded (in fact O(R^-5/2)). The single-annihilator form estimate
from the displayed covariance and independent T16 now gives
Y_R*HY_R<=C(H+I) and the inverse version, uniformly.
Nevertheless H^2>=R H on the nonvacuum output support, yielding

 ||(H+I)Y_R Omega||^2>=R M_R>=R.

Thus no uniform full H graph bound holds. This verifies every advertised
invalid-inference claim in rootcontrol84. Its rank, wave packets and energies
move with R; it violates the fixed-slot and uniform q=2 pair-HS hypotheses
of both positive theorems. It is neither a physical no-go nor proof that
the H graph criterion is necessary for every possible UI theorem.

This control is stronger for the UI question than independent evidence E3:
the latter single-pair example still has UI and only disproves a weaker
graph inference. Both original scopes are correctly stated and preserved.

## E7. Finite diagnostic and limiting consequences

The stored 52-line program constructs CAR annihilators, a vacuum-subtracted
quadratic V and its Nambu B with the source normalization. It exponentiates
the Fock and one-particle propagators separately, then compares the full
operator Y*HY to U7. All three parameter tuples and seeds are fixed in code.
The four mutants test omission of c_0, reversed exclusion, halved anomalous
term and reversed pair sign. These target real coefficient/order hazards.

The preserved RESULT reports exit0 in 0.8381239157170057 seconds; stdout
contains three cases, maximal operator discrepancy 2.760140320569077e-14
and minimum wrong-formula discrepancy 0.007850628238697938. Program and
snapshot hashes agree with the pre-run seal; output hashes match RESULT.
No rerun occurred here. These are recorded floating finite-algebra results,
not continuum estimates, domain proofs, formal checks or independent author
verification. Their mathematical scope remains exactly U7's finite algebra.

For either proof's final-energy subprobability measure, bounded-protocol
weak convergence plus the new tails implies convergence of the first moment
by continuous bounded energy truncation. This includes a history of limiting
mass0, whose unnormalized first moment tends to0. A positive limiting mass
permits normalization and final-energy W1. The shared initial energy and
the marked compound-Poisson increments are inherited from the supplied
prepared-protocol theorem; a one-time law alone would not establish this.

The same tails apply after a regular unbounded final bin, and finitely many
recorded histories may be summed. Compact finite-energy families are handled
in weighted trace topology; a common positive success bound is needed for
uniform normalized statements. Tail bounds allow arbitrary Borel bins and
resource-uniform drives, while limiting laws retain fixed profiles and fixed
regular protocols. No moving-boundary law, unrestricted-state uniformity,
vanishing-probability ratio, feedback, or growing observation count is proved.
