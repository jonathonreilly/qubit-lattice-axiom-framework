# Neutral plan: perturbing uniformly bounded ideal energy graphs

Prepared before reading any new root perturbation plan, probe or finding.
The absolute campaign deadline is 2026-10-13 16:42:30 UTC. Aim to finish
the bounded mathematical check by 16:34 if genuinely complete; otherwise
freeze precise remaining obligations before 16:40. No proof obligation is
shortened to fit the clock.

## Exposure before this plan

I authored fresh702/223 and the exposed threshold comparison356/evidence309.
I have fully read the named root306 and independent390 postmeasurement
proofs, their comparison239/evidence412, and the pinned J type precision.
I previously read threshold composition root211, including its coarse
epsilon(b+b^2) Duhamel commutator estimate with b=O(1/h). This is prior
source exposure, not independent rediscovery of that estimate.

The new perturbation question is supplied with the proposed use of already
established uniform ideal forward/inverse full and half graph bounds.
Before writing this plan I recognized graph-space Duhamel/Dyson estimates
as a possible technique, but did not derive a bound, assume a scaling,
construct a counterexample or read any new target-source argument.

Exclude ENERGY_GRAPH_PERTURBATION_ROOT_PLAN.md, all new root perturbation
probes and any root findings until this packet is frozen. The previously
authorized exact root306 remains an allowed premise. No subdelegation,
scientific runtime, CW/Git mutation, audit, prompt or axiom change, source
assembly or other-chat contact is authorized. Writes are restricted to
this directory. Deterministic source hashes/copies are allowed.

## Neutral question and method

Given common H>=0, uniform ideal forward/inverse full and half energy graph
bounds on the kinetic window, and a bounded self-adjoint control difference
Delta V with ||Delta V||<=d0 epsilon and bounded first commutator
||[H,Delta V]||<=d1 epsilon, determine a sufficient calibration scale for
actual graph convergence and fixed finite measurement-chain energies.
An improvement, a precise obstruction, or an unresolved obligation are
equally acceptable outcomes. Do not infer optimality from one proof route.

1. Bind the exact inherited sources at their known hashes; reuse complete
   readings only while identities and premises remain unchanged.
2. Formulate the graph-space evolution problem, explicitly distinguishing
   a propagator from an endpoint interaction-picture map and identifying
   both domain and inverse hypotheses.
3. Derive a perturbative graph bound or locate the exact obstruction.
   Check time composition, generator conjugation, integrability and the
   possible growth in the total drive budget b.
4. Determine separately what the bound implies for graph differences,
   uniform actual graph bounds, bounded history laws, initial/final energy
   tails and conditional first mean/W1. Keep the moving-state joint-limit
   quantifier and positive-success condition explicit.
5. Test the rate and constants using analytically computable controls and
   domain/inverse edge cases. Distinguish a failure of a bound from an
   actual counterexample. State any sharpness only for the stated class.
6. Freeze one complete derivation with separate decisive checks and exact
   source/coverage inventory. Parent owns comparison and acceptance.

Current state: new target sources unread; no mathematical answer assumed.
