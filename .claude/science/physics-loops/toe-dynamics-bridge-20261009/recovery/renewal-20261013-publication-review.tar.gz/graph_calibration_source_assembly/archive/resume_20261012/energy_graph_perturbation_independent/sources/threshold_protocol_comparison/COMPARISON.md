# Source-exposed comparison of threshold-crossing observation protocols

## 1. Outcome and epistemic status

The sealed root211 proof is a valid conditional composition within its
specified fixed-resource massive CAR model, subject to the required linear
unitary reading of J in the inherited postmeasurement source. I find no
additional substantive formula, rate, domain or conclusion correction in
the compared argument. The one-time marginal law alone would not establish
this result: the full signed-input weighted estimates and secular theorem
of threshold788 are the sufficient input actually used.

There are two assembly precisions: the mandatory J type correction, and an
explicit joint-limit quantifier for varying actual-state energy tails. A
literal uniform tail assertion over an arbitrary fixed punctured continuum
neighborhood is not implied. The intended mean/W1 limits remain valid.

Root211 additionally proves an actual-cell sufficient condition that my
unchanged fresh702 deliberately did not prove. Its bounded commutator
comparison gives uniform forward and inverse energy graph bounds when
epsilon=o(h^2), under the exact common-energy and calibration hypotheses
stated there. This is a genuine scope addition, not a contradiction and not
a result retroactively attributed to fresh702. Section 6 below derives it.

This is an exposed review of root211 and a self-check of fresh702/223. I
authored fresh702/223 before seeing root211, froze those outputs, and then
read root211 after the comparison plan was frozen. It is not a new
independent review of my own output. Shared threshold, vacuum, prepared and
postmeasurement sources also preclude claiming independent derivation of
those inputs. Parent acceptance, later retention and publication remain
outside this worker's authority.

The exact compared targets are:

- root211: 7a3ecb8b8b9c059e602e57d6a6d8859cdafe6f100f0d073b7372c56e84f99771;
  sealed at 2026-10-13 15:32:19.019231 UTC, before my fresh derivation.
- fresh702: 2c29d9731c8f43c2441dc52f158042a321ccc0dabd85136fd3855449e157032f.
- fresh evidence223: bd2f45c3e7d1098e704d9de776bd9a2d5eafd8194f7da49befcf5154868ace4d.
- This comparison's pre-target PLAN.md:
  88d26d1001c4dda2e32c6b5132946320f41d13fae685a473418f551bf6dceb36.

## 2. Full scope and strict-gap substitution map

The common premises include m>0, E>=m, fixed real compact smooth slots,
the same alternating quadratic control and real structure, and real BV
profiles on a fixed slow-time interval. Bounds on amplitude, both BV norms,
and 0<omega0<=Omega<=W remain fixed. Observation number, times and bins
remain fixed in the law limit. Crossing, touching or lying below 2m is
allowed. No massless limit, zero-frequency limit or growing-resource result
is obtained by this comparison.

The mark measure is

    dM(u,e)=(pi/2)a(u)^2 r(Omega(u))du delta_Omega(u)(de),

where r vanishes on e<=2m. The distinction between the carrier frequency
floor omega0 and the pair production threshold 2m is essential. The first
survives the theorem; strict separation above the second does not.

The following is the complete mechanism map for the sources actually read,
not a statement about every unread ancestor of this research lane.

| Inherited location | Role of strict separation and checked replacement |
|---|---|
| root398 section 1, independent667 section 1, prepared512 Q2, postmeasurement390 section 1 | Old drive domain assumed separation. Root211 changes the domain and separately supplies each needed estimate; replacing the domain sentence alone would be insufficient. |
| root398 T3/T13, independent667 (9)--(10) and gauge estimate (24), prepared512 Q3, postmeasurement390 T4 | These import small full-input operator norm and weighted Hilbert--Schmidt Born remainders. Threshold788 supplies both, for every fixed q, with eta_h=sqrt(h log(2+h^-2)). |
| Underlying causal-square estimate | Threshold788 uses the real-slot alternating identity A_s M0 A_-s=0 before norm bounds. Remaining carrier denominators use omega0. An old inverse distance from 2m cannot simply be set to infinity or zero. |
| Underlying full-input forcing estimate | Threshold788 cancels opposite-band threshold rows and controls their energy densities. Its same-band near-threshold separation uses omega0/4. Both input signs are needed; a beta-only bound would not give normal-state scalarization. |
| Underlying Born operator-norm estimate | Threshold788 cancels the constant opposite-band near-near term and bounds the remaining threshold-vanishing synthesis. The fact r(2m)=0 alone would not prove this operator bound. |
| root398 T10--T12, independent667 (13)--(14) | Diagonal secular limits use the threshold Fourier lemma after cutting the envelope. Difference-phase continuity holds at 2m; sum-phase nonstationarity uses 2omega0>0. Cross-interval terms use integrable pair-energy Fourier decay, with no carrier denominator. |
| root398 T4--T8, T14--T17, independent667 sections 4--6 | Graph products, inverse graphs, overlaps, number bounds and gauge scalarization are finite implementer algebra once the full norm and Hilbert--Schmidt hypotheses hold. No additional strict-gap estimate occurs. |
| prepared512 Q8--Q12 | CAR commutant scalarization uses q=0 full norm and fixed trace-class states. It needs neither carrier separation, finite energy nor initial quasifreeness. |
| root398 section 6, independent667 section 8, prepared512 Q14--Q17 | Projection convergence needs all ordered word Gram limits and regular boundary projections. Constant-carrier lattice exclusions must be replaced by the actual point spectrum of X+K. This is a spectral boundary condition. |
| prepared512 common zero-energy gap | This is the positive mass gap of H. Marks charged by M have e>2m, so the same common gap (0,m) remains. No positive distance of Omega above 2m is used. |
| postmeasurement390 T5--T10 | Weighted Born control uses bounded e^2 r, temporal Plancherel and q=2 remainders. Threshold vanishing and slot decay imply the required bound. Inverse/right weights use exact block unitarity and reality, not a new stationary-phase estimate. |
| postmeasurement390 T11--T24 | Positive CAR sums, graph domains, spectral graph contractions and initial-energy cutoffs need those weighted bounds and m>0. Their constants contain no carrier-threshold separation. |
| postmeasurement390 T25--T28 | First moments require weak final-energy measures plus uniform tails. Conditional normalization requires a positive limiting success probability. Neither operation adds a carrier gap. |

Fresh702 section 8 supplied this map before root exposure. Root211
sections 2--4 implement the same replacements. I find no inherited
strict-carrier-gap input left unprovided in this scope.

## 3. Interval products, secular terms and arbitrary words

Cutting a fixed envelope to an observation interval adds at most
2||a||_infinity to its variation. The phase and Omega must remain unchanged;
resetting the phase independently would describe a different protocol.
Empty intervals are retained as zero vectors, including repeated times.
Threshold788 therefore applies to each interval with bounded resources.

For pair inner product (1/2)Tr(L*Q), the interval Gram entry is

    h^2 integral r(e) exp(i(t-s)e) conj(I_k,h(e)) I_l,h(e) de.

Its diagonal limit is integral over I_k of exp(i(t-s)e)dM. The secular
test r exp(ise) is the sum of the two explicitly available tests r and
r(exp(ise)-1). For distinct intervals, transforming first to the scalar
energy kernel and using its O((1+|x|)^-2) decay gives root C5. Adjacent
intervals still give O(h^2 log(2+h^-2)), not an order-one contact term.
The independent integral calculation is recorded in evidence E1.

The finite-product lemma requires more than those diagonal Gram limits.
The full one-particle norm controls multiplication and gauge errors; bounded
pair Hilbert--Schmidt norms control overlaps; exact block inversion gives
the negative inverse graph to vanishing Hilbert--Schmidt error. The paired
Y and Y* scalar phases cancel in each energy-unitary construction. Root211
uses exactly these hypotheses from C3 and interval Gram convergence.

The resulting displacement list

    v_(2j-1)=-1_(u<=tau_j) exp(i S_(j-1)e),
    v_(2j)= 1_(u<=tau_j) exp(i S_j e)

has vacuum word expectation

    exp[-(1/2)sum ||v_a||^2 - sum_(a<b)<v_a,v_b>].

The complex ordered cross terms matter. Neither root211 nor fresh702
replaces general ordered words by a commuting classical characteristic
function. Chronological finite measurement records nevertheless admit
the compound-Poisson representation through the separate projection and
interval-factorization argument.

## 4. Fixed normal states and the Gram-to-projector passage

After extracting exp(i(sum s_j)H), the residual bounded word asymptotically
commutes in operator norm with every fixed CAR polynomial. Irreducibility
and the vacuum expectation determine each weak cluster point to be a scalar.
Equivalently, finite-CAR vectors give a dense cyclic set and fix every matrix
element. Fixed trace-class approximation then gives, for every normal rho,
the factor chi_rho(sum s_j) multiplying the vacuum word limit. This does not
require energy integrability, a diagonal state or quasifreeness.

The auxiliary representation is L2(mu_rho) tensor bosonic Fock over L2(M),
with initial-energy multiplication X and K=dGamma(e). The same random X0
appears at every observation; it is not resampled after each measurement.

For a finite boundary b, the sufficient global condition is

    mu_rho({b-e})=0 for every e in sigma_pp(K).

It is equivalent to 1_{b}(X+K)=0. The continuum positive Fock energy has no
positive eigenvalues; the only possible atom of mu_rho is its vacuum mass
at zero. Thus no vacuum mass implies every finite boundary is regular.
When vacuum mass is present, positive atoms of K still matter. A chirped
mark law need not have the same point spectrum as a constant carrier.

Smooth Fourier tests approximate each bin indicator in the relevant
limiting vector's spectral L2 norm. The full word Gram convergence supplies
the needed norm limits on all previous word vectors. A finite contraction
induction preserves the Heisenberg projector order. A chronological scalar
characteristic product alone would not justify this induction. In the mixed
state setting sqrt(rho) in Hilbert--Schmidt space supplies the vectors.

The common zero-gap convention is separate: a smooth function supported
inside the mass gap realizes the zero spectral projection exactly on both
models. It does not follow by pretending zero is a regular boundary.
Future interval factors remain vacuum during each finite history, yielding
the chronological law X0+S_tau. A final unused interval through tau_star can
be kept in the factorization. Finite records converge in total variation
because their outcome set is finite. No path-space or arbitrary-Borel-set
convergence follows.

## 5. Weighted graphs, domains and first-energy tails

The root's positive-column graph route and the separately exposed root306
normal-ordering route agree on their sufficient inputs. For this threshold
composition the direct positive-column route in fresh702 is also fully
written out and does not require any unread ancestor theorem.

With the corrected J convention of section 7, Plancherel gives

    ||E beta1||_HS^2 <= 2h^2 integral e^2 r(e)|I_h,T(e)|^2 de
                     <= 4 pi A^2 tau_star ||e^2 r||_infinity.

The q=2 remainder controls E beta. Right and inverse weights are not
interchangeable without proof: for blocks alpha,beta,gamma,delta, one uses
gamma*=-alpha* beta delta^-1, bounded delta^-1, and the full q=2 bound on
E(alpha*-I). Reality then converts E gamma* to the required beta* weight.
The mixed weight Q beta* Q, Q=E^(1/2), follows from the arithmetic-geometric
bound on its two spectral energy variables. The inverse full-input estimate
is the actual domain identity E^(q/2)(Z*-I)=-E^(q/2)(Z-I)Z*.

For finite energy cutoffs E_L, the positive single- and double-annihilation
identity avoids cancellations between unbounded Fock operators. The AC
term contains its scalar CAR contraction and must not be treated as CA.
The detailed independent estimate is in fresh702 (25)--(31); its positive
sums and cutoff limit establish the output domain rather than presupposing
it. The estimates for alpha at q=1 and q=2 are separate form estimates;
squaring a noncommuting operator inequality would not justify q=2.

This yields uniform forward/inverse G=1+H graph bounds, then S=G^(1/2)
bounds by interpolation. Spectral projections of H contract both graphs.
For a fixed history chain T=Y_final P_n...P_1, the corresponding constants
are L_j=C_j^(2n+1). Initial truncation gives exactly root C7:

    Tr rho T* H1_(H>R)T
    <= 2L_1^2 Tr rho G1_(H>L)
       + (2L_2^2/R)(1+L)(1+Tr H rho).

Taking L=sqrt(R) proves uniform integrability for every fixed finite-energy
rho, including states with infinite second moment. The postmeasurement
state may vary with h and need not be Gaussian. Weak subprobability limits
plus these tails give unnormalized history-weighted final means. A regular
final bin only restricts a positive measure. Positive limiting success
probability permits normalization and hence conditional first mean and W1
convergence. A zero limiting probability permits no such division.

Uniform tail bounds in fixed resources and arbitrary Borel bins are stronger
than the law statement, which keeps bins fixed and regular. Weighted-trace
compact initial families have uniform initial tails; finite uniform law
arguments then require the stated boundary hypotheses, and conditional
uniformity additionally requires a positive probability floor. An unrestricted
first-energy ball lacks uniform tails. No W1 rate is obtained.

## 6. Additional actual-cell graph bridge

Write f_h(t)=lambda c_h(t), b(t)=integral_0^t |f_h(s)|ds. On the kinetic
window b(t)<=C/h. Require an exact common self-adjoint H and common spectral
instrument, bounded self-adjoint V_a,V, and bounded graph-domain commutators

    ||Delta V||<=d0 epsilon,
    ||[H,Delta V]||<=d1 epsilon,
    ||[H,V_a]||,||[H,V]||<=k,

uniformly in the comparison. These are substantive calibration hypotheses.
They do not follow from norm closeness of V_a,V alone.

In interaction picture, bounded commutators imply that each V_I(t) acts
boundedly on D(H) with its graph norm. For every fixed h and finite time,
the L1 Dyson equation on that Banach space gives domain preservation and
the corresponding inverse evolution. Its preliminary large exponential
bound is used only to justify domains, not as a uniform kinetic estimate.
Differentiation on D(H), or the convergent graph-norm Dyson series, then
gives for either evolution

    ||[H,Y(t,s)]|| <= k (b(t)-b(s)).

Apply [H,.] to every factor in

    D(t)=Y_a(t,0)-Y(t,0)
        =-i integral_0^t Y_a(t,s) f_h(s) Delta V_I(s) Y(s,0) ds.

The middle factor contributes d1 epsilon b(t). The two outside factors
contribute d0 epsilon k times

    integral_0^t |f_h(s)|[(b(t)-b(s))+b(s)]ds=b(t)^2.

Consequently

    ||D(t)||<=d0 epsilon b(t),
    ||[H,D(t)]||<=epsilon[d1 b(t)+d0 k b(t)^2].

This is root C8 with its actual coefficient. Taking adjoints yields the
same two bounds for Y_a*-Y*. Since ||G^-1||<=1,

    ||G D G^-1|| <= epsilon[(d0+d1)b+d0 k b^2] = o(1)

when epsilon=o(h^2). The ideal uniform G bounds therefore transfer to actual
forward and inverse evolutions. Interpolation with unitarity gives uniform
S bounds as well. No second commutator is needed. One must not replace this
argument by an assertion that unweighted norm convergence controls energy.
No claim that little-o(h^2) is optimal is made.

Define weighted trace convergence by

    ||S(rho_a-rho)S||_1 -> 0,   S=(1+H)^(1/2),

with normalized finite-energy densities in the identified representation.
It implies ordinary trace convergence and uniform initial energy tails
in the limiting sense: the difference of the tail traces is bounded by this
norm, since G1_(H>L) becomes a projection after multiplication by S^-1.
Precisely, lim_(L->infinity) limsup_(joint limit) Tr rho_a G1_(H>L)=0.
For a convergent sequence, or an explicitly weighted-trace-compact family,
one also obtains a genuine uniform tail modulus over that family. Convergence
alone does not give a vanishing supremum over every point of an arbitrary
fixed punctured continuum neighborhood. Root211's phrase "uniformly small"
should receive this quantifier in an assembly wrapper; it is a precision
of the sufficient limiting argument, not a failure of mean/W1 convergence.
Uniform actual graph constants therefore give the same two-cutoff bound.
Common PVMs and unweighted Duhamel convergence transfer each bounded
history law by finite telescoping; no convergence of discontinuous moving
projectors is invoked. Weak limits plus actual tails then give the same
unnormalized means and, at positive limiting success, conditional W1.

Fresh702's final discussion leaves these actual graph bounds as additional
hypotheses. Root211 supplies them under the stronger commutator calibration
and error scale. The physical embedding, common observable and realizable
error scale remain assumed. Neither proof constructs a cell or detector.

## 7. Exact extent of the J correction and updated dependency status

Postmeasurement390 lines 79--80 called J antiunitary while describing the
ordinary integral kernel of the linear operator beta1 J. That adjective is
mathematically inconsistent. Gamma and scalar conjugation C are individually
antiunitary; their composition J=Gamma C is linear, unitary and energy
intertwining. This is already explicit in the fully read threshold788.

Right composition by this onto unitary preserves ||E beta1||_HS. Its kernel
therefore gives precisely the same integral bound used above, with unchanged
Plancherel constants and domains. Later inverse/right-weight and self-dual
CAR formulas use antiunitary Gamma, not J; they must not be changed to use
linear J. No other substantive correction is implied by this type repair.

The old postmeasurement acceptance59f1556c and comparison239 stated that no
source correction was required. Their literal statement is superseded by
the pinned precision addendum aff1db27 and acceptance08cfed6c. The correction
must accompany any assembled use of the original390. Old freezes remain
historical and unchanged; a correct wrapper or an explicit new version is
required rather than a silent reinterpretation.

I fully read the addendum and the later author precision snapshot9f7cc514
with receipt0683ce8d. The author's check corroborates the same narrow type,
domain and norm analysis; it is an author self-check, not a new blind review.
The addendum's pending-confirmation sentence was historically true when
written. This comparison supplies my later source-exposed corroboration.
I did not independently read corrected859 in this task; threshold788 already
provides the sufficient convention, and no hidden859 premise is adopted.

Root211's references to a pending postmeasurement comparison were also true
at its seal time. The subsequently frozen comparison239/evidence412 and
acceptance59f1556c, now with the mandatory precision, resolve that dependency
for ordinary conditional assembly. They do not themselves confer retained
status or certify this new composition without its own review.

## 8. Verification limits, remaining obligations and disposition

Separate evidence/DECISIVE_ANALYTIC_EVIDENCE.md gives hand calculations for
the interval contact bound, state and projector distinctions, inverse/domain
checks, actual commutator budget, weighted transfer and sharp scope controls.
No numerical, symbolic, finite-volume, proof-assistant or other scientific
runtime was executed. Hashes, line counts and copies are bookkeeping only.

SOURCE_INVENTORY.json distinguishes complete new semantic reads, reused
complete readings at unchanged hashes, and metadata-only checks. The initial
directory inventory hashed some unrelated comparison artifacts; a hash is
not a semantic read. Numerical countercontrol reports mentioned by the
postmeasurement comparison were not independently rerun or adopted as new
runtime evidence here. No unread initial407, chirp515/850, compact-preparation
or corrected859 theorem is imported through a source title.

The remaining scientific obligations are the explicitly conditional model
and calibration premises, later independent retention procedures if sought,
and any extension outside the stated finite fixed protocol. Within the
stated implication I find no residual mathematical gap. The required source
assembly precision is J linear/unitary; it changes no estimate or conclusion.
The actual varying-state tail wording should additionally specify the
joint-limit quantifier, with genuine family uniformity reserved for a
convergent sequence or weighted-trace-compact family.

This worker changed only files under threshold_protocol_comparison. The
original fresh proof/evidence, root proof, all predecessor sources and their
freezes remain unchanged. No editable prompt, physical axiom, CW/Git state,
audit status, PR or publication was changed. No subdelegation or other-chat
contact occurred. The exact final freeze and completed cold-read coverage
are recorded separately; parent owns acceptance and any assembled source.
