# Decisive analytic checks for the exposed threshold composition comparison

These are hand derivations directed at the composition interfaces and the
actual-cell addition. They are source-exposed checks, not numerical tests,
formal verification, or a new independent review of my own fresh702 proof.
The exact target and source identities are in the accompanying inventory.

## E1. Adjacent interval contact terms vanish at the claimed scale

Put a0=1+d, where d>=0 is the physical-time separation between two disjoint
intervals. Their lengths L,K are at most tau_star/h^2. Direct integration
gives

    integral_0^L integral_0^K (a0+x+y)^(-2) dy dx
    = log[(a0+L)(a0+K)/(a0(a0+L+K))].

The ratio is 1+LK/[a0(a0+L+K)] and is at most
1+min(L,K)/a0. Therefore multiplying by h^2 gives at most
h^2 log(1+tau_star/h^2), which tends to zero even when d=0.
An empty interval gives zero exactly. The boundary shared by adjacent
intervals has zero Lebesgue measure and adds no delta term to this kernel.

The estimate is applied after forming the scalar pair-energy Fourier kernel.
The fixed time shift t-s from free rotations changes the kernel constant,
not its integrable decay or the h scaling. It is not an estimate obtained by
taking an absolute value of each original oscillatory one-particle term.
No denominator involving Omega-2m appears in this calculation.

Diagonal interval Grams cannot be inferred from this vanishing cross term.
They separately use the threshold secular result. Cutting the envelope
retains the original integrated phase; the added BV variation is bounded
by two endpoint jumps. These two checks account for all interval Grams.

## E2. Pair normalization and ordered phases are retained

Use ||B||_pair^2=(1/2)||B||_HS^2. The accepted Born kernel therefore makes
the interval diagonal Gram exactly h^2 integral r(e)|I_h(e)|^2 de, with
the limiting intensity (pi/2)a^2 r(Omega), not twice that intensity.

For a single observation, the displacement list is v1=-b and
v2=exp(ise)b. Its ordered overlap exponent is

    -(1/2)(||b||^2+||b||^2)-<-b,exp(ise)b>
    = integral (exp(ise)-1)|b|^2 dM.

This recovers the one-time Poisson characteristic function, including its
imaginary part. Dropping the ordered imaginary cross term would instead
recover only the modulus and would fail this check.

For chronological times, disjoint interval factors give

    chi_rho(sum_j s_j)
    exp(sum_k integral_(I_k) [exp(ie sum_(j>=k)s_j)-1]dM).

The initial characteristic function occurs once. Replacing it by a product
of chi_rho(s_j) would falsely resample the initial energy after each time.
At M=0 the formula is chi_rho(sum s_j), as required for repeated observation
of an unchanged initial free energy. Arbitrary reordered words retain the
general Weyl overlap and need not have this commuting form.

## E3. Boundary regularity is distinct from threshold regularity

On L2(mu_rho) tensor bosonic Fock, the spectral mass at b of X+K is
the direct-integral operator 1_{b-x}(K). It vanishes exactly when
mu_rho({b-e})=0 for every eigenvalue e of K. A self-adjoint operator on this
separable space has at most countably many eigenvalues, so the condition
is sufficient as well as necessary.

The microscopic massive continuum H has no positive eigenvalues. On each
positive particle sector, fixing every momentum except one leaves a level
set of the strictly nonconstant continuous dispersion with Lebesgue measure
zero. Fubini gives a null level set for the full sector; the direct sum has
only the vacuum eigenvalue zero. Thus the only atom in a normal state's
free-energy law can be p0 delta_0.

The common zero projection is exceptional but controlled: choose a smooth
function equal to one at zero and supported below m. It agrees exactly
with the vacuum spectral projection for H and X+K. Nonzero marks have
energy greater than 2m even on threshold-crossing protocols. This uses
mass positivity and positivity of initial energy, not a carrier margin.

For a constant allowed above-threshold carrier and p0>0, K has positive
lattice atoms while the microscopic H has no positive eigenvalue. Therefore
arbitrary singleton convergence at those atoms fails. This allowed subcase
survives enlargement of the drive class and prevents any claim that
threshold crossing removes the boundary qualification. It does not decide
either half-open interval convention at an atomic endpoint.

## E4. Inverse weights and positive CAR domains

Let Z be unitary with blocks alpha,beta,gamma,delta and ||Z-I|| small.
The off-diagonal block of ZZ*=I gives alpha gamma*+beta delta*=0;
the block of Z*Z=I gives alpha* beta+gamma* delta=0. The latter yields

    gamma*=-alpha* beta delta^-1.

Using only gamma*=-beta would miss both factors. The energy bound follows
by writing alpha*=I+(alpha*-I), using bounded E(alpha*-I), bounded beta in
Hilbert--Schmidt norm, bounded E beta, and bounded delta^-1. Reality converts
this to the opposite weight on beta* with antiunitary Gamma.

The inverse full-input estimate is an exact identity on the energy domain:

    E^(q/2)(Z*-I)=-E^(q/2)(Z-I)Z*.

The right side is a bounded extension; it also identifies the range of
Z*-I in the required domain. It is not a formal reassociation of unbounded
operators without range control.

For Q=E^(1/2), in a joint spectral representation of a Hilbert--Schmidt
kernel B, the inequality xy<=(x^2+y^2)/2 gives

    ||Q B Q||_HS^2 <= (||E B||_HS^2+||B E||_HS^2)/2.

The positive annihilator identities use E_L=min(E,L) before taking limits.
On each particle sector they give

    ||dGamma(E_L)z||^2
    = sum_i ||a(E_L e_i)z||^2
      + sum_ij ||a(E_L^(1/2)e_j)a(E_L^(1/2)e_i)z||^2.

The diagonal one-particle terms and distinct-particle cross terms account
for the square exactly. After Bogoliubov substitution, the AC term satisfies
a(f)a*(g)=<f,g>-a*(g)a(f); its scalar contraction contributes the mixed
weighted beta bound. The CA term has no such scalar contraction. Retaining
both is essential to the graph estimate in fresh702.

All estimates hold for spectral cutoffs before the output is assumed to
have a second energy moment. Monotone positive sums and closedness then
put the output in D(H). This avoids using the desired domain assertion as
an input. Estimates at q=1 and q=2 are proved individually; no invalid
squaring of a noncommuting form inequality is needed.

## E5. The initial cutoff requires only first energy

Let S=G^(1/2), G=1+H, and suppose ||S T S^-1||<=L1 and
||G T G^-1||<=L2 for every history chain under consideration. For a vector
psi split at H<=L. The high part obeys the half-graph bound, while
H1_(H>R)<=H^2/R and the full graph bound control the low part. Applying
||x+y||^2<=2||x||^2+2||y||^2 and integrating a density decomposition gives

    Tr rho T* H1_(H>R)T
    <=2L1^2 Tr rho G1_(H>L)
      +(2L2^2/R)(1+L)Tr rho G.

Choose L=sqrt(R). The first term tends to zero for each fixed finite-energy
rho; the second is O(R^-1/2) times its first energy. No initial H^2 term
remains. A fixed density with probabilities proportional to n^-3 on
disjoint packets of energy near n has finite first moment and infinite
second moment, and is covered by this estimate.

A bound on Tr H rho alone is not a uniform tail modulus over all states.
For a packet of energy in [R,R+1], mix weight 1/R of that packet with the
vacuum. Mean energy stays bounded but the high-energy tail contribution
stays close to one. Hence neither proof supplies uniform first-mean or W1
convergence on an unrestricted first-energy ball.

## E6. Three-factor Duhamel commutator and its coefficient

Suppose V_a,V are bounded self-adjoint, preserve D(H), and have bounded
commutators as stated in the comparison. Bounded commutator forms on D(H)
also suffice: the adjoint-domain criterion shows V D(H) is contained in
D(H), after which the same bounded graph action follows.

For fixed h, the interaction-picture generator is L1 in time as a bounded
map on D(H) with graph norm. Its Dyson construction establishes domain
preservation and the propagator composition law there. Taking a commutator
in that graph equation and then passing to bounded extensions gives

    [H,Y(t,s)]=-i integral_s^t Y(t,u) f_h(u)
                         [H,V_I(u)] Y(u,s)du,

and hence ||[H,Y(t,s)]||<=k[b(t)-b(s)]. The estimate is linear in b despite
the preliminary graph-domain existence bound being potentially exponential.

For the comparison D=Y_a-Y, expand the commutator of the exact Duhamel
integrand into left, middle and right factors. Their norm bounds are

    epsilon d0 k |f_h(s)|[b(t)-b(s)],
    epsilon d1 |f_h(s)|,
    epsilon d0 k |f_h(s)|b(s).

Their integral is epsilon[d1 b(t)+d0 k b(t)^2]. More explicitly,
integral |f_h(s)|b(s)ds=b(t)^2/2 and the complementary outside term also
integrates to b(t)^2/2, since b is absolutely continuous. Thus the outside
coefficient is one, not an omitted term or an additional factor of two.
Sign changes or zeros in f_h cause no problem because b uses |f_h|.

Adjunction gives [H,D*]=-[H,D]*, with the same bounded norm. The same bounds
therefore hold for forward and inverse differences. Common H ensures that
free interaction-picture rotations do not change these norms. A mismatch
in the measured free energy would invalidate this specific derivation.

## E7. Rate, graph transfer and scope control

Since b<=C/h,

    ||G D G^-1||
    <=epsilon[(d0+d1)C/h+d0 k C^2/h^2].

Under epsilon=o(h^2) this tends to zero. Adding the ideal uniform graph
bound gives a uniform actual graph bound, and the adjoint version supplies
the inverse bound. The half graph follows by interpolation with unitarity.
The conclusion requires no bound on [H,[H,V_a]]. This is only a sufficient
rate statement; no optimality or failure at a slower scale has been proved.

Unweighted norm convergence alone would be insufficient. In the span of
vacuum and a packet near energy E, rotate through theta=E^-1/2. Then
||U_theta-I|| tends to zero, but the vacuum output energy is
approximately E sin(theta)^2, which tends to one, and the full graph
off-diagonal entry is approximately (1+E)sin(theta), which diverges.
This abstract control violates the bounded small commutator conclusion;
it is not asserted to arise from the allowed fixed-drive calibration class
and does not refute root C8.

At zero drive, b=0 and the two propagators agree exactly, so both Duhamel
bounds vanish regardless of the unused interaction mismatch. For a scalar
Delta V commuting with H, the actual difference can be a scalar phase:
its commutator vanishes and energy observations agree. C8 remains an upper
bound and need not be saturated. These limits test its interpretation.

## E8. Moving initial states: exact tail quantifier

Put Q_a=S rho_a S and Q=S rho S. Weighted trace convergence means
||Q_a-Q||_1 tends to zero. With F_L=1_(H>L),

    |Tr rho_a G F_L-Tr rho G F_L|
    =|Tr (Q_a-Q)F_L|<=||Q_a-Q||_1.

Thus

    lim_(L->infinity) limsup_(joint limit) Tr rho_a G F_L=0.

The total first energies are eventually bounded. Applying the actual
history tail estimate first with fixed L, then taking the joint limit,
then R to infinity, and finally L to infinity proves the required final
energy uniform integrability in the limiting sense. Equivalently, along
any convergent sequence the Q_a form a trace-norm compact set and possess
a genuine uniform tail modulus.

One cannot replace this by the supremum over all parameter points in an
arbitrary fixed punctured continuum neighborhood without extra regularity
or compactness. For example, in each parameter annulus near 2^-k choose a
sequence of parameter points accumulating away from zero, and at its jth
point mix a packet of energy E_(k,j)->infinity with vacuum, with weight
2^-k/E_(k,j). Elsewhere use the vacuum. Then ||Q_a-Q||_1=O(a) near zero,
but every fixed neighborhood contains an annulus whose positive tail mass
2^-k survives the supremum over its j. The joint limiting tail statement
still holds. This diagnostic concerns a quantifier, not the limiting theorem.

Root211's wording should be made explicit in an assembly wrapper. The
postmeasurement comparison's limiting formulation and conditional mean/W1
conclusion are consistent with the precise quantifier above.

## E9. Bounded history transfer followed by tails

Let delta_h=sup_t ||Y_a(t)-Y(t)||. Common PVMs give for each Heisenberg bin
projection a norm difference at most 2delta_h. A length-n chain differs by
at most 2n delta_h, because every factor is a contraction. Its probability
difference, including initial states, is at most

    ||rho_a-rho||_1+4n delta_h.

The same finite telescoping handles a bounded final energy test. Duhamel
gives delta_h<=d0 epsilon C/h=o(1). Thus each actual bounded history law
has the ideal limit. This estimate uses neither energy moments nor tails;
those are supplied independently by E5--E8 for the unbounded observable.

For a history event with limiting mass p>0, its actual mass is eventually
at least p/2. Weak subprobability convergence and uniform first tails give
convergent unnormalized means; dividing by the converging positive masses
gives conditional weak and mean convergence. On [0,infinity), compact
Lipschitz approximation and tail truncation then give W1 convergence.

At p=0 this reasoning has no denominator bound. For example, subprobability
measures n^-2 delta_n tend weakly to zero and their unnormalized means tend
to zero, but their normalized means diverge. Such an abstract control
justifies the positive-probability hypothesis without claiming a physical
counterexample to every possible rare-event limit.

Finite unions of recorded histories sum positive branch measures. Summing
chain operators coherently would introduce interference and describe a
different instrument. The stated finite-outcome record theorem uses the
former operation.

## E10. J is linear; Gamma remains antiunitary

For z complex, Gamma C(z f)=Gamma(conj(z)C f)=z Gamma C f. Both factors
are onto antiunitary isometries, so J=Gamma C is linear and unitary. Since
C commutes with the real scalar energy multiplier and Gamma intertwines
the two band energies, E_- J=J E_+ on D(E_+), and the same holds for
fractional powers. The domains map onto each other.

For an orthonormal basis e_j of the positive band, J e_j is an orthonormal
basis of the negative band. Hence

    sum_j ||E_+ beta1 J e_j||^2=||E_+ beta1||_HS^2.

The ordinary scalar kernel of beta1 J gives the stated weighted density
bound without any changed coefficient. Calling J antiunitary would make
beta1 J antilinear and that ordinary kernel statement type-inconsistent.
The correction is mathematically required even though the resulting norm
bound survives unchanged.

This calculation does not replace Gamma by J in the self-dual covariance,
the relation between gamma* and beta*, or the CAR scalar contraction.
Those use antiunitary Gamma correctly. The precision addendum and later
author check preserve this distinction. No other formula or domain repair
was identified in the fully compared source scope.
