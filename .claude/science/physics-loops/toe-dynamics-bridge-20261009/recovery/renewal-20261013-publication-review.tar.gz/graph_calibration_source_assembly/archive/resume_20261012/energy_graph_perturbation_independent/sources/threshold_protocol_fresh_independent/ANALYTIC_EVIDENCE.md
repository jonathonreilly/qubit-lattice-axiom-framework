# Separate analytic checks of the threshold protocol composition

These are hand calculations by the deriving agent after the neutral plan.
They are not numerical execution, an external audit, or model-diverse evidence.
The parent composition proof remains excluded. D references are to
DERIVATION.md in this directory.

## E1. Cross-interval Gram entries with an actual threshold crossing

When the fixed resource range permits it, choose a three-block slow
schedule: omega_- in (omega0,2m), then
omega_=2m, then omega_+>2m, with an allowed finite upper bound. Take a
constant real amplitude a0 and preserve the continuously integrated phase.
This has bounded variation with two jumps; the theorem permits such a
crossing without a transverse derivative assumption.

The target measure on the first two blocks is zero. On the third it is

    (pi/2)a0^2 r(omega_+) du delta_omega_+.

The diagonal Born norms on the zero-rate blocks tend to zero by the
threshold secular formula evaluated at those frequencies. Cauchy--Schwarz
alone then kills their cross terms with a bounded-norm block. For two
positive-rate adjacent blocks, that shortcut is unavailable, but direct
integration gives, for a=1+d,

    integral_0^L integral_0^K (a+x+y)^-2 dy dx
      =log[(a+L)(a+K)/(a(a+L+K))].

Multiplication by h^2 makes it vanish on the kinetic window. This separately
checks both zero-rate crossing blocks and the genuine cross-covariance
obligation when both intervals have positive intensity. The bound includes
adjacent intervals; no artificial macroscopic time gap is used.

If the drive is entirely at Omega=2m, M=0. The threshold source's direct
dwell calculation bounds the Born energy by O(h^2 log(2+h^-2)); the full
q=1 remainder tends to zero. D13 predicts unchanged initial energy for
every fixed normal state, and D34 proves the finite-energy W1 version.
There is no positive threshold rate hidden in the product construction.

## E2. The finite-product phase and exterior factor

For two small implementers, the recursion used in D10 has leading logarithm

    -||L1||_HS^2/4-||L2||_HS^2/4-(1/2)Tr(L1*L2),

apart from the separately retained vacuum scalar phases. Expressed with
the pair norm, this is

    -(1/2)||L1+L2||_p^2-i Im<L1,L2>_p.

Its real part is nonpositive. Taking L2=-L1 makes the overlap correction
zero, as required for adjacent inverse implementers; taking L2=iL1 gives
the nonzero ordered imaginary term. Using only real norm polarization
would miss that phase.

For a one-letter energy word the two limiting vectors are -b and exp(ise)b.
Its exponent is

    -||b||^2+integral exp(ise)|b(u,e)|^2 dM
      =integral_(u<=tau)(exp(ise)-1)dM.

Thus the fixed-word normalization reduces to the accepted one-time
compound-Poisson characteristic exponent, with no additional factor two.
For adjacent equal observation times, exact operator cancellation combines
their s parameters. The displacement list in D12 has an adjacent pair
exp(iS_j e)b and -exp(iS_j e)b, which cancels as well.

The elementary free-rotation check for two factors is

    [Y1*R(s1)Y1R(-s1)]
    [R(s1)Y2*R(-s1) R(s1+s2)Y2R(-s1-s2)] R(s1+s2)
      =Y1*R(s1)Y1 Y2*R(s2)Y2.

The residual rotation is on the right; moving it to the wrong side would
not justify the initial-state factor in D13.

## E3. Initial energy and the spectral-boundary change

At M=0 the auxiliary energy is X at every time. Hence a two-bin history
has probability mu_rho(B1 intersect B2), not mu_rho(B1)mu_rho(B2).
This detects accidental resampling of initial energy. It also tests coherent
initial states: the result uses their H spectral law, obtained from trace
pairing, without projecting rho onto energy sectors at the start.

For a chirp, the correct boundary object is X+K. Direct integration gives

    [1_b(X+K)f](x)=1_(b-x)(K)f(x).

A boundary with zero original marginal mass is insufficient if x+e=b on
an initial atom and an auxiliary eigenvalue that a history vector can reach.
D16 avoids precisely this problem. In the supplied continuum representation
the only possible initial atom is 0; this is why vacuum-free normal states
admit every finite interval boundary.

Threshold crossing changes neither the free mass gap nor the zero-atom
argument. Even if the drive approaches 2m from above at arbitrarily many
times, M has no mass at or below 2m. Its one-particle multiplication operator
has lower bound 2m, sufficient for the common gap (0,m). A strict margin
Omega>=2m+delta never enters this step.

As a positive-boundary control, the threshold source's real bump pair has
r(2m+x)=c x+O(x^2), c>0. Choose a sufficiently small fixed x>0 and constant
omega=2m+x. Then the permitted class contains a positive-rate example.
With initial vacuum, the exact projection onto the singleton {omega} is
zero, while the target atom is exp(-mu)mu>0. This refutes arbitrary Borel
event convergence within the actual allowed class; it does not refute the
regular-bin theorem or select a convention at the positive atomic boundary.

## E4. A different finite-block check of the energy graph input

Take two fermionic modes with positive energies e1,e2 and total e=e1+e2.
Let U_theta rotate the even vacuum/pair subspace by [[c,-s],[s,c]], where
c=cos(theta), s=sin(theta); it fixes the singly occupied states. On that
two-dimensional even subspace, G=1+H has diagonal entries 1 and 1+e, so

    G U_theta G^-1
      =[[c,-s/(1+e)],[(1+e)s,c]].

The potentially large graph entry is (1+e)s. The one-particle off-diagonal
block has weighted HS norm |s|sqrt(e1^2+e2^2), and

    e|s| <=sqrt(2)||E beta||_HS.

Thus the exact graph growth is controlled by the same q=2 quantity used
in D20--D32. The inverse has s replaced by -s and the same graph bound.
This directly checks why energy weighting of both directions is relevant
and why a small unweighted angle alone is insufficient. It does not use
an energy eigenbasis for the continuum proof.

The H^2 sum identity also has an immediate particle-sector check. On the
occupied pair, its first term is e1^2+e2^2 and the ordered double term is
2e1e2. The total is e^2. A missing order or factor two would fail even
this exact finite algebra. This corroborates D27 but does not substitute
for its positive-form/domain argument.

## E5. An interpolation check of the first graph norm

There is an independent functional-analytic route from the uniform second
graph estimate to the first one. If T is a contraction and GTG^-1 is
bounded with norm at most L, then

    ||G^(1/2) T G^-1/2||<=sqrt(L).

For spectral-compact u,v, consider <u,G^z T G^-z v> on 0<=Re z<=1.
G>=1; T preserves D(G) by the graph premise. The scalar function is
analytic in the open strip and continuous on its boundaries. It is bounded
on the strip: move G^z onto the spectral-compact u in the pairing, while
G^-z v is uniformly bounded. On Re z=0,
unitary imaginary powers give the norm bound 1; on Re z=1 they give L.
The three-lines theorem and dense spectral-compact approximation give
the displayed inequality. This checks the existence of a uniform first
graph bound for the contraction T_h once D32--D33 give its second graph
bound. It uses no initial second moment and is consistent with the direct
CAR first-form calculation in D30.

Both routes would fail if one merely squared a noncommuting first-form
inequality. Here the second graph premise was obtained separately from
the q=2 one-particle estimate and the full AA/CA/AC/CC expansion.

## E6. Initial first energy without initial second energy

Choose orthogonal one-particle wave packets psi_j supported in disjoint
energy bands [m 2^j,m 2^j+m]. Put p_j=c 2^(-j)/j^2, with c normalizing
their sum, and rho=sum_j p_j |psi_j><psi_j|. This is a fixed normal state.
Its first energy is finite because sum 1/j^2 converges, while its second
energy diverges because sum 2^j/j^2 diverges.

The low-energy part F_L rho^(1/2) has finite HS G norm, bounded by
sqrt((1+L)Tr rho G). The discarded part has squared S norm
Tr[rho G 1_(H>L)], which tends to zero. Therefore D34 applies to this
state. A proof applying D(H) propagation directly to the entire initial
state would be invalid; truncation first is essential.

The lack of uniformity on the whole first-energy ball can also be checked
inside the actual continuum Hilbert space. Let psi_R be a one-particle
packet in [R,R+1] and

    rho_R=(1-1/R)|Omega_F><Omega_F|+(1/R)|psi_R><psi_R|,

for R>=1. Its first energy is bounded, but its energy tail above R/2 is
at least 1. At zero drive and with no preceding observations, those are
the actual final states. Thus no uniform first-energy-tail theorem on
that unrestricted state ball is possible. This exact countercontrol does
not concern fixed rho or compact families with a common tail modulus.

## E7. Conditioning and record unions

The quantity before normalization is a positive measure. Restricting its
last energy to any final bin cannot increase its energy tail. If its
mass tends to p>0, normalization multiplies the tail by at most 2/p for
small h, so the tail proof survives and gives D38.

If p=0, the same argument supplies no such bound. As a test of the logical
inference, the subprobabilities nu_n=n^-2 delta_n have vanishing mass and
vanishing first moment, but their normalized laws delta_n diverge. This
abstract example tests division, not the existence of that rare event in
the supplied CAR dynamics. It supports only the stated exclusion from
the inference, not a physical rare-history no-go theorem.

A union of recorded outcomes is a classical forgetting of records. Its
state is the positive sum of branch states. In contrast, replacing that
sum by a coherent sum of chain operators introduces cross terms and can
describe a different instrument. D37--D38 use only the positive sum, as
required by the original finite-outcome Lüders protocol.

## E8. Postmeasurement proof convention and exposure check

Threshold788 defines C as scalar conjugation and J=Gamma C. Both factors
are antiunitary, so J is linear. The provisional postmeasurement390 setup
calls J antiunitary while using the same scalar Born kernel. D20 derives
the needed inequality directly from the threshold convention, making the
operator type unambiguous. HS norms are preserved by either an antiunitary
isometry or a unitary one, but a claimed ordinary linear integral kernel
must have the matching convention. This is a notation repair, not a new
loss in the energy estimate.

This checker read all allowed target bodies, including provisional390,
before completing its derivation. The graph-tail strategy is accordingly
source exposed. Its independent contribution relative to the sealed parent
composition is the explicit threshold interface audit, complete conditional
derivation, and the checks above. Neither shared model family nor agreement
with a supplied proof establishes external independence or formal retention.
