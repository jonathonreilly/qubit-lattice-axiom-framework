# Threshold-crossing drives in fixed finite energy protocols

Status: conditional-support; a fresh composition derivation with the parent
composition source excluded. This is an ordinary analytic argument in the
supplied massive free CAR model. It grants no retained audit status, physical
model selection, apparatus realization, or empirical prediction. The frozen
postmeasurement390 input was read as provisional mathematics and is checked
below, not treated as an accepted authority.

    target_claim_type: bounded_theorem
    actual_current_surface_status: conditional-support
    trace_class: upstream_support
    reachability_to_target: supports
    conditional_surface_status: supplied massive free CAR dynamics and energy instrument
    hypothetical_axiom_status: null
    admitted_observation_status: null
    audit_required_before_effective_retained: true
    bare_retained_allowed: false

The answer is affirmative at the stated fixed-protocol scope. The usable
input is the threshold theorem's full weighted operator and Born estimates,
not its marginal probability conclusion alone. In particular its q=2 bound
supplies the extra energy graph control needed after measurement. The proof
below isolates these interfaces and retains the regular-boundary and positive
postselection-probability conditions.

## 1. Exact setting and conclusion

Use threshold788, SHA256
0406c0e397b82a95159a77e47d093771e19f316c46f80c996ec2969ca082cea4,
as the accepted ordinary analytic source. On K=L2(R,dp;C^2), let

    D(p)=-vp sigma_x-m sigma_y, E(p)=sqrt(m^2+v^2p^2),
    P=(I+D/E)/2, P_-=I-P, Gamma k(p)=overline(k(-p)), m,v>0.

On the supplied Fock representation over PK put H=dGamma(E|PK), with
vacuum Omega_F. Fixed real f,g in C_c^infinity(R;R^2) give F=(f,g),
M0=2i[[0,1],[-1,0]], B=F M0 F*, and the same centered quadratic V as
threshold788. Their component integrals may be nonzero. No alternative
control, real structure, observable identification, or state-selection
principle is inserted.

Fix finite tau_*, A, V_a, V_Omega, W, and omega0>0. The real profiles obey

    ||a||_infinity<=A, Var(a)<=V_a,
    omega0<=Omega(u)<=W a.e., Var(Omega)<=V_Omega.       (1)

Profiles are fixed for each limiting-law assertion here. Let h=|lambda|,

    phi_h(t)=phi0+h^-2 integral_0^(h^2t) Omega(u)du,
    c_h(t)=a(h^2t)cos(phi_h(t)).

The interaction propagators Y_h(t), Z_h(t) and their pictures are those of
threshold788. Write Y_tau=Y_h(tau/h^2), Z_tau=Z_h(tau/h^2), and

    A_h(tau)=Y_tau* H Y_tau,
    U_h(tau,s)=Y_tau* exp(isH)Y_tau.                   (2)

The full-picture Heisenberg energy is identical. A_h is self-adjoint by
unitary conjugation; bounded functions and projections require no assumption
that the initial state is in its operator domain.

Let r be threshold788's exact exterior-pair density, extended by zero below
2m. Define a finite measure on time and energy by

    dM(u,e)=(pi/2)a(u)^2 r(Omega(u))du delta_Omega(u)(de). (3)

It vanishes on e<=2m, including a plateau at Omega=2m. Let S_tau be the
marked compound-Poisson comparison process of intensity M: draw a Poisson
number of marks from M and sum the energies of marks with time <=tau.
Zero total intensity gives S_tau=0. This construction is a mathematical
comparison, not an assumed process for the microscopic dynamics.

For any fixed normal density matrix rho on the original Fock space, define

    mu_rho(B)=Tr(rho 1_B(H)), phi_rho(s)=Tr(rho exp(isH)).

The claims proved below are:

1. Every fixed ordered word of (2), with repetitions and arbitrary ordering,
   has the limit (13). No first energy moment of rho is needed.
2. Every specified fixed finite Lüders protocol with the boundary conditions
   of section 5 has limiting history probabilities given by the one shared
   initial energy X0~mu_rho plus S_tau, independently of X0.
3. If Tr(Hrho)<infinity, its final free-energy subprobability measures have
   uniformly integrable first moments. Every regular recorded history of
   positive limiting probability has convergent conditional final mean and
   final-energy law in W1. An unbounded final bin is allowed.

Observation times, Fourier parameters, word length, partition count and
measurement count are fixed. Crossings need not be transverse, monotone or
finite in number. No claim here takes omega0 to zero, m to zero, resources
to infinity, or the protocol to continuous monitoring.

## 2. Threshold inputs and interval covariance

For every fixed q>=0, threshold788(6), with its graph-domain meaning, gives

    ||E^(q/2)(Z_tau-I)||<=C_q eta_h,
    ||E^(q/2)(Z_tau-I-K1_tau)||_HS<=C_q eta_h,
    eta_h=sqrt(h log(2+h^-2)),
    K1_tau=-i lambda integral_0^(tau/h^2)c_h(t)F_t M0 F_t*dt,
    F_t=exp(itD)F.                                    (4)

These estimates are for full input, not just its vacuum excitation block.
Threshold788 also proves r(2m+x)=x rho0(x), x>=0, with smooth one-sided
rho0 and rapid decay of the needed derivatives. Consequently

    sup_(e>=0) e^2 r(e)<infinity,
    |C_b(t)|<=C_b/(1+t^2),
    C_b(t)=integral b(e)exp(iet)de,                    (5)

for b=r exp(ise), any fixed real s. The latter is the sum of the two cases
r and r(exp(ise)-1) explicitly proved there. No finite first absolute
correlation-time moment is assumed.

Sort the distinct observation times, including a later final-energy time
when one is used, and insert 0, obtaining intervals J_k in slow time and
I_k=J_k/h^2 in physical time. The remaining interval up to tau_* is an
additional future factor when nonempty; it never enters a prefix before
its left endpoint. Put

    I_k(e)=integral_(I_k)c_h(t)exp(iet)dt,
    B_k(p,q)=lambda Delta(p,q)I_k(E(p)+E(q)),
    <L,Q>_p=(1/2)Tr(L*Q), R_s L=exp(isE)L exp(isE^T).

B_k is a skew pair kernel, unrelated to the generator B except through
its definition. Delta and the scalar band frame are exactly those of
threshold788(4). The kernel normalization gives

    <R_s B_k,R_t B_l>_p
      =h^2 integral r(e)exp(i(t-s)e)conj(I_k(e))I_l(e)de. (6)

For k=l use threshold788(24) with the envelope a 1_(J_k), extended by
zero. It is an allowed real BV envelope; its variation increases by at
most 2A. The original continuously integrated phase is kept, with no
phase reset. The secular lemma applied to b=r exp(i(t-s)e) yields

    <R_s B_k,R_t B_k>_p
      =integral_(J_k)exp(i(t-s)e)dM(u,e)+O(h).         (7)

Its b(-Omega) term vanishes because Omega>=omega0>0 and b is supported
on [2m,infinity). Fourier inversion is valid also at Omega=2m because
b is continuous there and b(2m)=0. A positive distance above 2m is unused.

For k!=l, (5), bounded c_h, and Fubini give an absolute bound C h^2 times

    integral_0^L integral_0^K (1+d+x+y)^-2 dxdy
      =log[(1+d+L)(1+d+K)/((1+d)(1+d+L+K))]
      <=log(1+min(L,K)/(1+d)),                       (8)

where d>=0 is the gap between facing endpoints. The harmless comparison
between 1+t^2 and (1+|t|)^2 has been absorbed into C. Since all lengths are
at most tau_*/h^2, the cross Gram error is O(h^2 log(2+h^-2)), even for
adjacent intervals. This proof uses no carrier separation or random phase.

The exact graph L_tau of Y_tau Omega_F obeys, by threshold788(30),

    ||L_tau||=O(eta_h), ||L_tau||_HS<=C,
    L_tau=sum_(J_k subset [0,tau])B_k+O_HS(eta_h).     (9)

Individual B_k have bounded HS norm and small operator norm. These facts
also follow by taking differences of the prefix Born blocks in (4), so
no extra claim about independently restarted interval dynamics is needed.
Equations (6)--(9) supply the actual cross-time information missing from
a theorem stated only in terms of one-time marginal laws.

## 3. Fixed products and the vacuum word formula

For clarity the implementer step is repeated. Suppose a fixed list of even
implementers V_i has real one-particle maps Z_i with ||Z_i-I||<=d->0 and
bounded off-diagonal HS norms. Their small skew graphs L_i have bounded
HS norms. Exact block multiplication gives

    beta_(UV)=alpha_U beta_V+beta_U delta_V
             =beta_U+beta_V+O_HS(d).

The graph differs from beta J by O_HS(d), where J=Gamma C is linear,
unitary, and energy intertwining; C is scalar conjugation in the positive
band frame. The product of the two antiunitaries Gamma and C is linear.
For inverses, the upper-right block of Z_U Z_U*=I gives

    beta_(U^-1)=-alpha_U^-1 beta_U delta_U*,
    L_(U^-1)=-L_U+O_HS(d).

Thus for each prefix Q=V_1...V_(j-1), its inverse graph is
-sum_(i<j)L_i+O_HS(d). Products remain close to I in one-particle norm
and retain bounded off-diagonal HS norm because the number of factors is
fixed. No HS norm is assigned to an identity operator.

Write V_i Omega_F=g_i F_(L_i), with vacuum coefficient g_i and the
unnormalized pair vector F_L of threshold788 section 9. Its exact mixed
overlap gives the recursion

    <Omega_F,Q V_j Omega_F>
      =g_Q g_j exp[(1/2)Tr log(I+L_(Q^-1)*L_j)] .

The scalar is g_Q, rather than its conjugate: Q*Omega_F has coefficient
conj(g_Q), whose bra contributes g_Q. The trace-log series is convergent;
the operator norm of its argument minus I is O(d^2), its trace norm is
bounded, and all terms after the first are O(d^2). HS pairing controls
the graph replacements. Also |g_i|=exp[-||L_i||_HS^2/4+O(d^2)]. Hence

    <Omega_F,V_1...V_q Omega_F>
      =(product_i g_i/|g_i|)
       exp[-(1/4)sum_i||L_i||_HS^2
           -(1/2)sum_(i<j)Tr(L_i*L_j)+O(d)].         (10)

This keeps the full implementer phase and operator order. It is an overlap
argument, not a supposition that the Fock implementers are norm-close to I.
The exact graph/overlap identity was fully read in threshold788; no hidden
parent overlap formula is imported.

For an ordered list (t_j,s_j), j=1,...,N, put S_j=sum_(l<=j)s_l, S_0=0.
Move all free rotations in product_j U_h(t_j,s_j) to the right. Its 2N
remaining implementers, in order, are

    R(S_(j-1))Y_(t_j)*R(-S_(j-1)),
    R(S_j)Y_(t_j)R(-S_j), R(s)=exp(isH).              (11)

The rightmost R(S_N) fixes the vacuum. Free conjugation rotates pair
graphs exactly, preserves their norms, and fixes their vacuum scalars.
The scalar phases in (10) cancel in conjugate Y/Y* pairs.
Using (6)--(9), set in H_b=L2(M)

    v_(2j-1)(u,e)=-1_(u<=t_j)exp(iS_(j-1)e),
    v_(2j)(u,e)=1_(u<=t_j)exp(iS_j e),
    F_M(t,s)=exp[-(1/2)sum_a||v_a||^2
                       -sum_(a<b)<v_a,v_b>].        (12)

Equation (10) gives the vacuum word limit F_M with error O_word(eta_h).
The exterior factor 1/2 in (6) converts the coefficients in (10) exactly
to those in (12). Inner products are linear in the second slot.

## 4. Arbitrary fixed normal initial states

Let W_h=product_j U_h(t_j,s_j) and C_h=W_h R(-S_N). Formula (11) expresses
C_h as a fixed product of near-identity one-particle implementers. For the
complex-linear self-dual field b(k)=a*(Pk)+a(P Gamma k), CAR gives
||b(k)||<=||k|| and exact covariance Y* b(k)Y=b(Z*k). Thus

    ||[C_h,b(k)]||<=2N C eta_h||k||, ||C_h||=1,
    <Omega_F,C_h Omega_F> -> F_M.

Every weak-operator cluster point commutes with all CAR fields. Its
commutant in this Fock representation is scalar: commuting with all
annihilators sends the vacuum into their common one-dimensional kernel;
commuting with all creators fixes the operator on their dense vacuum
orbit. Separable Fock space and the uniform norm bound give weak-operator
subsequences along any h sequence. Their vacuum entries determine the
same scalar, so C_h converges weakly to F_M I.

Bounded weak-operator convergence pairs with every trace-class operator:
first approximate it in trace norm by finite rank, and bound the residual
pairing by the common operator-norm bound. Taking the trace-class operator
R(S_N)rho proves

    Tr(rho product_j U_h(t_j,s_j))
       -> phi_rho(S_N) F_M(t,s).                    (13)

This needs neither finite energy, parity, quasifreeness, energy diagonality,
nor purity of rho. It is for each fixed normal state. No uniform rate over
all such states follows from the finite-rank approximation.

A positive representation of (13) is useful. On

    L2(mu_rho) tensor Gamma_s(L2(M))

let X multiply by the initial energy x, K=dGamma(e) on the bosonic factor,
b_t=1_(u<=t), xi=1 tensor Omega_b, and

    mathcal K=X+K,
    mathcal A(t)=(I tensor D(-b_t)) mathcal K
                                     (I tensor D(b_t)).              (14)

These are self-adjoint by joint spectral calculus and unitary conjugation.
The initial vector need not lie in their unbounded operator domains.
Weyl displacements have vacuum overlap (12), so bounded words in (14)
give exactly (13). This auxiliary bosonic representation is a construction
of limiting moments, not a change in physical particle statistics.

For increasing times t_1<=...<=t_N, put t_0=0 and retain empty intervals
when a time repeats. The interval tensor factors give

    phi_rho(sum_j s_j)
     exp{sum_(k=1)^N integral_(t_(k-1),t_k]
          [exp(ie sum_(j=k)^N s_j)-1]dM}.            (15)

This is the characteristic function of Z_tau=X0+S_tau, with one shared
X0~mu_rho independent of S. It does not erase the other-order dependence
in (12)--(13).

## 5. Boundaries and the actual finite Lüders history

For each observation fix a finite partition into intervals, with fixed
endpoint membership and unbounded end intervals allowed. A sufficient
condition for a finite boundary b is

    1_{b}(mathcal K)=0,
    equivalently mu_rho({b-e})=0 for every e in sigma_point(K).        (16)

To verify equivalence, view (14) as a direct integral over x. Its boundary
projection is 1_(b-x)(K). K has at most countably many eigenvalues on its
separable Hilbert space; away from x=b-e this projection is zero. An atom
of mu_rho at b-e and a nonzero e-eigenvector produce the converse witness.
The condition removes boundary mass on every history word vector, not only
on the original state's one-time marginal.

The continuum H has only the vacuum eigenvalue 0. On an n>=1 particle
sector it multiplies by sum_i E(p_i); fixing the other momenta leaves at
most two p_1 solutions to a prescribed level equation. Fubini gives a
measure-zero level set, also at a threshold, and the countable Fock sum
preserves this conclusion. Hence mu_rho=p0 delta_0 plus a nonatomic part.
If p0=0 every finite boundary satisfies (16). If p0>0, boundaries outside
sigma_point(K) suffice.

The boundary 0 has a separate permitted extension even when it is atomic.
Both H and mathcal K have no spectrum in (0,m). Indeed M has no mass at
or below 2m, so every nonvacuum bosonic energy is >=2m in spectral support;
no uniform gap above 2m is needed. A smooth compactly supported function
equal to 1 at 0 and zero on [m,infinity) is exactly their zero projector.
It handles either endpoint convention without a continuity argument at
the zero atom. Positive atomic boundaries retain condition (16).

Put P_(h,j)=1_(B_j)(A_h(tau_j)) and L_h=P_(h,n)...P_(h,1). The actual
specified Lüders history probability is

    p_(h,rho)(B_1,...,B_n)=Tr(L_h rho L_h*).           (17)

Multiplying by the final full propagator recovers the Schrödinger-picture
chain of the intervening exact propagators and free-energy bin projections.
Thus (17) specifies an instrument; no continuous-spectrum dephasing map
is presumed.

For completeness, purify rho into Hilbert-Schmidt space with vector
rho^(1/2) and left multiplication. Gram entries of finite linear
combinations of unitary word vectors are expectations in (13). Inserting
one more energy unitary gives the characteristic functions of positive
finite spectral measures. Their masses converge and the target functions
are continuous at zero in (14), so the measures converge weakly.

For a bin B satisfying (16), approximate 1_B in the limiting vector's
spectral L2 norm by a smooth compactly supported f. Tightness treats an
unbounded bin. The bounded function |1_B-f|^2 is continuous except at
the zero-mass boundaries, so its exact-h integrals converge. For a zero
boundary use the exact common-gap function instead. Fourier inversion for
smooth f has an integrable Fourier transform; (13) and dominated convergence
give all mixed inner-product limits after applying f(A_h). Finite Fourier
sums approximate the resulting limiting vector in norm, and their exact-h
limsup errors agree by those same Gram limits. Thus fixed word vectors
can approximate the postprojection vector as closely as required.

Repeat this construction after each of the finitely many projections.
Existing errors cannot grow under the next projection, a contraction.
This proves convergence of (17) to the analogous auxiliary projected norm.
It also proves bounded-continuous final-energy tests after a preceding
history, rather than only its total probability.

Evaluate that norm by splitting L2(M) into the intervals
(tau_(k-1),tau_k], tau_0=0, retaining empty factors for repeated measurement
times, and the remaining future interval up to tau_*. If Q_k is the
displaced energy on interval factor k and K_k its undisplaced energy,

    mathcal A(tau_j)=X+sum_(k<=j)Q_k+sum_(k>j)K_k.    (18)

Before its first observation every future factor is still vacuum, and
its K_k term acts as zero on the history vector. Projection onto a bin
therefore applies to X+sum_(k<=j)Q_k and leaves the future vacua intact.
The Q_k on distinct factors commute, and their vacuum laws are independent
compound-Poisson increments. Induction gives

    p_(h,rho)(B_1,...,B_n)
      -> E[product_j 1_(B_j)(X0+S_(tau_j))].         (19)

Within-bin coherence has been kept throughout. The same initial X0 appears
at every observation. Finite outcome sets give total-variation convergence
of their recorded history distributions.

## 6. Uniform energy graph control from the threshold theorem

Here is the additional unbounded-observable argument. It checks the core of
the still provisional postmeasurement390 at the new threshold input, and
does not invoke that note's conclusion as a black box.

Write Z=[[alpha,beta],[gamma,delta]], Q=E^(1/2), beta1=P K1_tau P_-,
T=tau/h^2, and I_h,T(e)=integral_0^T c_h(t)exp(iet)dt. The accepted
Born kernel and (5), followed by temporal Plancherel, give

    ||E beta1||_HS^2
       <=2h^2 integral e^2 r(e)|I_h,T(e)|^2de
       <=4pi A^2 tau_* ||e^2 r||_infinity.           (20)

The inequality E(p)^2<=(E(p)+E(q))^2 explains the factor 2 relative to
the exterior density. This needs a uniform upper bound, not a secular
second-moment theorem. The q=2 remainder in (4) gives uniform constants

    ||E beta||_HS<=B2, ||Q beta||_HS<=B1, ||beta||_HS<=B0. (21)

The mass m>0 also supplies B1 and B0 from B2. For q=1,2 unitarity gives
the bounded-extension identity

    E^(q/2)(Z*-I)=-E^(q/2)(Z-I)Z*.                  (22)

Its domain is justified before multiplying by E^(q/2): the range of
Z*-I=-(Z-I)Z* is in the same graph domain as Z-I. In particular alpha*
preserves D(E). For small h the block delta is invertible with inverse
norm at most 2, because ||Z-I|| tends to zero. The upper-right block of
Z*Z=I and the real structure give

    gamma*=-alpha* beta delta^-1,
    gamma*=Gamma beta* Gamma,
    ||E gamma*||_HS
      <=2[||E beta||_HS+||E(alpha*-I)|| ||beta||_HS].  (23)

This proves the weighted inverse off-diagonal bound and, through Gamma,
the right-weighted bound for beta. It never assumes that bare beta is skew.
Only the exact graph, containing inverse diagonal factors, is skew.

In the Hilbert-Schmidt spectral representation the left and right energy
variables commute. Applying xy<=(x^2+y^2)/2, with bounded cutoffs first,
gives the finite uniform mixed bound

    ||Q beta* Q||_HS^2
       <=(1/2)(||E beta*||_HS^2+||beta* E||_HS^2)<=Bx^2. (24)

The same statements apply to Z*; its off-diagonal block is gamma*, and
(22) supplies its full weighted bound. Take all constants below to cover
both directions.

We now prove that each U=Y_tau or Y_tau* is uniformly bounded in both
energy graph spaces. Put G=1+H and S=G^(1/2). The claim is

    ||S U psi||<=c1||S psi||, psi in D(H^(1/2)),
    ||G U psi||<=c2||G psi||, psi in D(H).            (25)

Exact CAR covariance gives, for a positive-band vector xi,

    Y* a(xi)Y=a(alpha*xi)+a*(Gamma beta*xi).          (26)

This follows by applying the complex self-dual covariance to Gamma xi.
Let E_L=min(E,L), and let (e_i) be any positive-band orthonormal basis.
The positive CAR sum identities, valid also as extended positive forms, are

    <z,dGamma(E_L)z>=sum_i||a(E_L^(1/2)e_i)z||^2,
    ||dGamma(E_L)z||^2
       =sum_i||a(E_L e_i)z||^2
        +sum_(i,j)||a(E_L^(1/2)e_j)a(E_L^(1/2)e_i)z||^2. (27)

On each particle sector this is (sum E_i)^2=sum E_i^2+sum_(i!=j)E_iE_j.
Parseval, finite particle truncation, and positive increasing basis sums
give (27), without requiring a finite-rank projection commuting with E.

For q=1,2 let k_q=||E^(q/2)(alpha-I)|| and
a_q=(1+k_q/m^(q/2))^2. The triangle inequality on the energy graph gives

    alpha*E^q alpha<=a_q E^q.                        (28)

The q=2 inequality is proved separately, not by squaring the q=1 form
inequality. If f_i=alpha*E_L^(1/2)e_i and
g_i=Gamma beta*E_L^(1/2)e_i, then

    sum_i |f_i><f_i|<=a1 E,
    sum_i||g_i||^2<=B1^2,
    sum_i||E^(1/2)g_i||^2<=Bx^2.                    (29)

Applying (26) to the first line of (27) gives

    <Ypsi,H Ypsi><=2a1<psi,Hpsi>+2B1^2||psi||^2.     (30)

The estimate is first for E_L and then by monotone convergence; it proves
the form-domain inclusion as well as the bound.

For the single-annihilation term of the second line of (27), use q=2:
it is at most 2a2||Hpsi||^2+2B2^2||psi||^2. For the double term expand
(a(f_j)+a*(g_j))(a(f_i)+a*(g_i)). Its four squared column sums satisfy

    AA <=a1^2||Hpsi||^2,
    CA <=a1 B1^2<psi,Hpsi>,
    AC <=2a1 Bx^2||psi||^2+2a1 B1^2<psi,Hpsi>,
    CC <=B1^4||psi||^2.                              (31)

For AA, (29) is applied on distinct particle tensor factors: the sum is
bounded by a1^2 sum_(r!=s)E_r E_s<=a1^2 H^2. No noncommuting one-particle
form inequality is squared. CA and CC use ||a*(g)||<=||g||. In AC the
scalar contraction is essential. CAR and Parseval give

    a(f_j)a*(g_i)=<f_j,g_i>-a*(g_i)a(f_j),
    sum_(i,j)|<f_j,g_i>|^2
      =sum_i||E_L^(1/2)alpha g_i||^2<=a1 Bx^2.

The two-term squared-norm bound then proves the AC line. Summing (31)
with the four-term bound and adding the single sum yields

    ||H Ypsi||^2
      <=(2a2+4a1^2)||Hpsi||^2+12a1 B1^2<psi,Hpsi>
          +(2B2^2+8a1 Bx^2+4B1^4)||psi||^2.          (32)

Initially the left side is the possibly infinite positive expression
(27) on Ypsi. Its transformed finite CAR products are bounded, so no
domain for Ypsi is presupposed. Increasing the positive basis sums and
letting L grow, sectorwise monotone convergence of dGamma(E_L)^2 proves
Ypsi is in D(H) and establishes (32). Since <H><=||psi||||Hpsi||,
(30)--(32) prove (25). Equations (22)--(24) prove exactly the same claims
for Y*. This is uniform in times and profiles within (1), for small h.

Only the supplied mass gap, q=1,2 instances of (4), and the finite (20)
enter this proof. There is no hidden use of Omega-2m in a denominator.

## 7. Postmeasurement tails, means and W1

Let C_h=P_(h,n)...P_(h,1) be a preceding history and let its final energy
be observed at tau>=tau_n. Write T_h=Y_tau C_h. An arbitrary spectral
projection Pi=1_B(H) contracts the S and G graph norms. Thus (25) gives

    ||S T_h S^-1||<=L1=c1^(2n+1),
    ||G T_h G^-1||<=L2=c2^(2n+1).                  (33)

These are bounded graph-space extensions, uniform for all Borel sets B_j
with a fixed upper bound on n. Boundary regularity is needed for limiting
laws, but not for this tail estimate.

Suppose M_rho=Tr(Hrho)<infinity and F_L=1_[0,L](H). Then

    t_rho(L)=||S(I-F_L)rho^(1/2)||_HS^2
            =Tr[rho(1+H)1_(H>L)] ->0.

Split the initial square-root density with F_L. On its high-energy part
apply the S bound in (33). On its low-energy part use
H1_(H>R)<=R^-1 H^2 and the G bound. The squared-norm triangle inequality
gives the explicit estimate

    ||H^(1/2)1_(H>R) T_h rho^(1/2)||_HS^2
      <=2L1^2 t_rho(L)
        +(2L2^2/R)(1+L)(1+M_rho).                   (34)

Indeed ||G F_L rho^(1/2)||_HS^2<= (1+L)Tr[rho G]. The traces are positive
spectral integrals; none is obtained by cycling an unbounded operator.
Taking L=sqrt(R) proves uniform integrability in first energy, uniformly
over small h, the fixed time horizon, and all bins with bounded count.
Only the initial first energy, not its second energy, was assumed.

Unitary spectral calculus identifies the desired Heisenberg tail exactly:

    ||A_h(tau)^(1/2)1_(A_h(tau)>R) C_h rho^(1/2)||_HS
       =||H^(1/2)1_(H>R)Y_tau C_h rho^(1/2)||_HS.     (35)

Consequently (34) discharges the threshold-crossing version of Q25 in
prepared512. It is not an application of a fixed-initial-state mean theorem
to a moving collapsed state.

For a fixed preceding regular recorded history F, set

    nu_h^F(B)=Tr[C_h rho C_h* 1_B(A_h(tau))].

Section 5 gives weak convergence to

    nu^F(B)=E[1_F 1_(X0+S_tau in B)].                (36)

Equation (34) gives its uniformly integrable energy tail. Truncating the
energy by a bounded continuous function, using (36), and then removing
the truncation proves

    integral x nu_h^F(dx) -> E[(X0+S_tau)1_F].        (37)

The target is finite because its unrestricted first moment is
M_rho+integral_(u<=tau)e dM. A regular final bin, even an unbounded one,
may be imposed: the bounded protocol result gives its restricted weak
limit, and restriction cannot increase its positive energy tail.

If the full recorded event has limiting probability p_F>0, divide by its
converging success probabilities. Then

    final conditional mean -> E[(X0+S_tau)1_F]/p_F,
    final conditional energy law -> Law(X0+S_tau | F) in W1.           (38)

Weak convergence plus the separate converging first moments on [0,infinity)
gives the W1 assertion: tail truncation controls Lipschitz tests outside a
compact interval, and a finite net of normalized Lipschitz functions on that
interval reduces its supremum to finitely many weak-convergence tests.
No convergence rate is asserted.

The final spectral projection commutes with A_h(tau), so this is precisely
the physical free energy of the postmeasurement state after transportation
by the final full propagator. Finite unions of recorded histories mean the
sum of their positive branch measures, not a coherent sum of their chain
operators. Those sums preserve (34)--(38). Summing a full finite record
partition gives the nonselective mean limit M_rho+integral e dM. For n=0
the same proof supplies the unmeasured mean and W1 result for finite-energy
normal rho without importing an unseen earlier mean theorem.

## 8. Exhaustive strict-carrier-gap audit of the read sources

The following table covers the proof mechanisms in the complete read
root398, independent667, prepared512 and postmeasurement390. Their exact
hashes and full-read coverage are in SOURCE_INVENTORY.json. Formula labels
belong to the original files in this table.

| Location or mechanism | Original use and threshold replacement |
|---|---|
| root398 section 1; independent667 section 1; prepared512 Q2; postmeasurement390 section 1 | Strict separation was part of the imported drive domain. Replace it by (1), retaining fixed real slots and positive mass. A scope sentence alone supplies no proof. |
| root398 T3/T13; independent667 (9)--(10), gauge smallness in (24); prepared512 Q3; postmeasurement390 T4 | All inherit full-input kinetic estimates. Threshold788 proves them with the same eta_h at every fixed q; (4) records the exact replacement. |
| Underlying causal-square estimate | Threshold788 section 4 removes opposite-band stationary products by A_s M0 A_-s=0 before taking norms. Surviving denominators use omega0, not Omega-2m. This is imported fully proved input, not a new scalar-gap argument. |
| Underlying full-input forcing estimate | Threshold788 (15)--(17) handles both input signs. Opposite-band threshold rows vanish and have bounded energy density; same-band near-threshold terms are separated by omega0/4. Controlling only beta would not supply normal-state scalarization or the energy graph bounds. |
| Underlying Born small-operator estimate | Threshold788 (19)--(20) cancels the constant opposite-band near-near term and uses threshold-vanishing synthesis for the remainder. Substituting zero into an old inverse gap constant would be invalid. |
| root398 T10--T12; independent667 (13)--(14) | Diagonal interval Gram limits need the secular lemma, now threshold788(24) with cutoff envelopes. Difference-phase inversion uses continuity at 2m. Sum-phase nonstationarity needs only 2omega0>0. Off-diagonal interval Grams use (5)/(8) and no carrier gap at all. |
| root398 T4--T8 and T14--T17; independent667 sections 4--6 | Graph, overlap, number-moment, gauge and finite-product arguments use small full norm, bounded HS norm and interval Gram entries. They contain no extra carrier denominator. Section 3 verifies this interface directly. |
| prepared512 Q8--Q12 | Residual-word scalarization uses the full q=0 operator estimate, irreducibility and trace-class approximation. It does not use carrier separation, an energy moment, or initial quasifreeness. |
| root398 section 6; independent667 section 8; prepared512 Q14--Q17 | The spectral passage uses bounded words and regular boundary projections. Constant-carrier lattice boundaries must be replaced by the actual sigma_point(X+K) condition when the drive is chirped. This is a spectral regularity condition, not a carrier gap. |
| prepared512's common zero-energy gap | This is the mass gap m of H. Threshold M still charges only e>2m, giving the same auxiliary gap (0,m). A distance of the carrier above 2m is unnecessary. |
| postmeasurement390 T5--T10 | q=2 weighted Born/remainder bounds and inverse/right-weight control are required. The e^2 r bound is valid at the threshold by its linear vanishing and rapid decay. Temporal Plancherel uses no separation. Equations (20)--(24) check the inverse domain and order. |
| postmeasurement390 T11--T24 | The Fock graph proof, CAR AC contraction, graph contraction of spectral projections, and two-cutoff tail estimate depend only on those weighted bounds and m>0. Equations (25)--(35) verify every such step. |
| postmeasurement390 T25--T28 | Weak final-energy measures come from the prepared protocol proof; tails are separate. Positive limiting success probability remains needed before normalization. No extra carrier gap occurs. |
| Original ordering and positive-boundary controls | Constant above-threshold schedules remain a subclass of (1), so their concrete countercontrols remain valid. Threshold crossing does not make all orderings commute or all atomic boundaries regular. |

The source audit finds no remaining mathematical use of strict separation
from 2m after these replacements. It does not claim that a different
unread proof has no such use. The three original kinetic gap uses are
specifically replaced by the three distinct threshold cancellations already
proved in threshold788; a statement about r(2m) alone would not replace them.

## 9. What the conclusion does and does not supply

When M=0, including a drive entirely at or below threshold, (13) reduces
to phi_rho(sum s_j), and (19) observes the same initial energy repeatedly.
For finite-energy rho the unmeasured law converges to mu_rho in W1, and
(38) gives the corresponding static-energy conditional law for positive
regular events. There is no spurious positive threshold-plateau jump rate.

For M with positive production, arbitrary quantum word orderings generally
remain noncommutative. In an allowed constant-carrier subcase with rate mu>0,
the four-word commutator at s=t=pi/omega has limit exp(-8mu), whereas a
commuting process gives 1. The initial-state factor is phi_rho(0)=1.
This is a direct inherited countercontrol, not a universal negative theorem.

Positive atomic boundaries cannot all be included: with vacuum weight p0>0
and constant-carrier production mu>0, the target has atom p0 exp(-mu)mu at
omega, while the exact continuum free energy has no positive eigenvalue.
Thus arbitrary singleton/Borel convergence fails in that allowed subclass.
This does not decide either interval convention at a positive atom.

Infinite-energy normal states retain (13) and (19), and bounded-final-bin
moment conclusions at positive success probability. General unbounded
first means/W1 need the finite-energy premise. Vanishing limiting success
probability gives no normalized conclusion here. The tail bound depends
on the initial energy-tail modulus, so it is not uniform over an arbitrary
first-energy ball. No conditional quantum-state trace-norm limit, feedback,
shrinking-bin, increasing-observation or path-space theorem has been proved.

Unweighted actual-cell word/probability transfer can separately use an exact
common measured H and uniformly norm-close propagators, by fixed-product
telescoping. This packet does not transfer postmeasurement tails from that
norm closeness alone. Uniform forward and inverse energy graph bounds in
the actual common-energy representation would be additional hypotheses.
No such calibration or actual-cell construction is supplied here.

## 10. Source dependence, independence and final disposition

PLAN.md was frozen before scientific-source reading; its SHA256 is
10217ea142aff72fbf4f8eb4ec42d796b418896b7434286db4ca472492c9c157.
It discloses the only pre-plan reasoning: the general distinction between
marginals, multitime words and unbounded moments. The parent composition
proof and all excluded postmeasurement comparison/root sources were not read.

All ten allowed source bodies in SOURCE_INVENTORY.json were read fully and
copied at their supplied hashes under sources/. The threshold acceptance
record confirms ordinary conditional source-assembly acceptance only.
Prepared512's acceptance covers its bounded protocol result, with Q25 still
open there. Postmeasurement390 and evidence170 were exposed provisional
sources; their underlying tail approach is therefore not an independent
invention here. This packet independently checks its mathematical interface
against threshold788, including the complete graph-domain calculation.

One notation correction is made explicitly in this derivation: the J used
for the scalar Born kernel is Gamma C, a linear energy intertwiner as in
threshold788 section 8. Postmeasurement390 calls J antiunitary in its T5
setup. Its HS inequality is recovered directly by (20); the contradictory
adjective should be corrected before combining the sources. This causes no
change to the bound or to the stated conditional conclusion.

No unstated theorem from initial407, chirp515/850, the compact-preparation
proof, or another named ancestor is adopted. Those ancestor bodies were not
read in this task. The sufficient model, graph identities, density, weighted
bounds and secular input are all explicitly available in the fully read
threshold788. The finite product, prepared-state and tail arguments used
here are written out above. The source-bound derived implication remains
subject to the parent's separate comparison and any later independent audit.

ANALYTIC_EVIDENCE.md gives separate hand-checks directed at the newly
composed steps. No scientific numerical, symbolic, finite-volume or Lean
runtime was executed. Source copying, hashes, line counts and Git instruction
reads are deterministic bookkeeping only. There was no CW/Git mutation,
subdelegation, contact with another chat, physical axiom or prompt change,
audit action, commit, PR or publication action by this worker. Broad current
repository premise certification and publication belong to the parent; no
unseen framework derivation or broad novelty search is claimed.

The mathematical deliverable is the conditional implication (1)--(4) to
(13), (19) and, for finite-energy rho, (34)--(38). No residual proof step is
left inside that quantified implication. Threshold788 is an accepted ordinary
analytic input; this composition itself awaits the parent's source-exposed
comparison. The exact final freeze and cold-read coverage are recorded in
FINAL_FREEZE.json and CHECKPOINT.md.
