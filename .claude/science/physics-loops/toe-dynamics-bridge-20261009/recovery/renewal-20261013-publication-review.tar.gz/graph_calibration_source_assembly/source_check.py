#!/usr/bin/env python3
"""Check source identities and extraction bytes; execute zero math predicates."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def local_path(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError(f"Path leaves source packet: {relative}")
    return path


def read_json(relative: str):
    return json.loads(local_path(relative).read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-originals", action="store_true")
    parser.add_argument("--report", help="Write JSON report inside this packet")
    args = parser.parse_args()
    failures: list[dict[str, str]] = []
    counts: dict[str, int] = {}

    def check(stage: str, label: str, condition: bool) -> None:
        counts[stage] = counts.get(stage, 0) + 1
        if not condition:
            failures.append({"stage": stage, "identity": label})

    try:
        archive = read_json("ARCHIVE_MANIFEST.json")
        extraction = read_json("EXTRACTION_MANIFEST.json")
        dependencies = read_json("DEPENDENCIES.json")
        plan_seal = read_json("PLAN_SEAL.json")
        check("plan", "sealed plan hash", digest(local_path("PLAN.md").read_bytes())
              == plan_seal["plan_sha256"])

        for item in archive["sources"]:
            data = local_path(item["archive"]).read_bytes()
            check("archive", item["archive"],
                  digest(data) == item["sha256"]
                  and len(data) == item["bytes"]
                  and len(data.splitlines()) == item["lines"])
            if args.verify_originals:
                original = Path(item["source"]).read_bytes()
                check("originals", item["source"], original == data)

        for declared in archive["authoritative_freezes"]:
            path = local_path(declared["archive"])
            data = path.read_bytes()
            freeze = json.loads(data)
            check("freezes", declared["archive"],
                  digest(data) == declared["sha256"]
                  and len(freeze["members"]) == declared["member_count"])
            for member in freeze["members"]:
                target = (path.parent / member["path"]).resolve()
                if not target.is_relative_to(ROOT):
                    raise ValueError("Frozen member leaves packet")
                check("frozen_members", str(target.relative_to(ROOT)),
                      digest(target.read_bytes()) == member["sha256"])

        for pair in archive["source_pairs"]:
            original = local_path(pair["original"]).read_bytes()
            snapshot = local_path(pair["snapshot"]).read_bytes()
            check("source_pairs", pair["owner"] + ":" + pair["snapshot"],
                  original == snapshot and digest(original) == pair["sha256"])

        candidate = local_path(extraction["candidate"]).read_bytes()
        wrapper = local_path(extraction["wrapper"]).read_bytes()
        check("wrapper", "exact candidate prefix", candidate.startswith(wrapper)
              and digest(wrapper) == extraction["wrapper_sha256"]
              and len(wrapper) == extraction["wrapper_bytes"]
              and len(wrapper.splitlines()) == extraction["wrapper_lines"])
        for item in extraction["extractions"]:
            begin = item["begin_marker"].encode("utf-8")
            end = item["end_marker"].encode("utf-8")
            check("markers", item["label"],
                  candidate.count(begin) == 1 and candidate.count(end) == 1)
            start = candidate.index(begin) + len(begin)
            stop = candidate.index(end, start)
            body = candidate[start:stop]
            expected = local_path(item["archive"]).read_bytes()
            check("extractions", item["label"],
                  body == expected and digest(body) == item["sha256"]
                  and len(body) == item["bytes"]
                  and len(body.splitlines()) == item["lines"]
                  and start == item["body_start_byte"]
                  and stop == item["body_end_byte"]
                  and candidate[:start].count(b"\n") + 1 == item["body_start_line"]
                  and candidate[:stop].count(b"\n") == item["body_end_line"])

        base = "archive/resume_20261012/"
        v1 = local_path(base + "ENERGY_GRAPH_PERTURBATION_ROOT_PROBE.md").read_bytes()
        v2 = local_path(base + "ENERGY_GRAPH_PERTURBATION_ROOT_PROBE_V2.md").read_bytes()
        expected_diff = local_path(base + "ENERGY_GRAPH_PERTURBATION_ROOT_V2.diff").read_bytes()
        reconstructed = b"".join(difflib.diff_bytes(
            difflib.unified_diff, v1.splitlines(keepends=True),
            v2.splitlines(keepends=True), fromfile=b"frozen_root190", tofile=b"rootV2"))
        check("diff", "exact immutable V1 to V2 diff", reconstructed == expected_diff)
        v2_seal = read_json(base + "ENERGY_GRAPH_PERTURBATION_ROOT_V2_SEAL.json")
        check("seals", "V2 and previous identities",
              v2_seal["sha256"] == digest(v2)
              and v2_seal["previous_sha256"] == digest(v1)
              and v2_seal["diff_sha256"] == digest(expected_diff))

        required_markers = [
            "uniform_C_G_for_full_theorem",
            "calibration_order_p_plus_one_separate_from_2n_plus_one",
            "assumed_common_H_not_retained_status",
            "ideal_regular_law_is_an_application_assumption",
            "growing_C_G_single_propagator_only",
            "abstract_controls_do_not_prove_continuum_necessity",
        ]
        for marker in required_markers:
            literal = ("<!-- CURRENT-SCOPE: " + marker + " -->").encode()
            check("literal_scope_markers", marker, wrapper.count(literal) == 1)
        check("dependency_record", "no invented publication dependency",
              dependencies["canonical_tail_parent"] is None
              and dependencies["repository_dependency_edges_added"] == []
              and dependencies["base_head_for_publication"] is None
              and dependencies["driver_created"] is False
              and dependencies["pull_request_created"] is False)

    except (OSError, ValueError, KeyError, TypeError) as error:
        failures.append({"stage": "execution", "identity": str(error)})

    report = {
        "role": "Deterministic source identity bookkeeping only",
        "source_checks_complete": not failures,
        "originals_requested": args.verify_originals,
        "check_counts": counts,
        "failures": failures,
        "mathematical_predicates_executed": 0,
        "scientific_runtime_executed": False,
        "scope_marker_meaning": "Literal presence only; not validation of mathematical scope",
        "proof_certification": False,
        "retained_audit_status": False,
        "canonical_parent_resolved": False,
    }
    if args.report:
        local_path(args.report).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
