# G0c exact evidence and recovery boundary

Pinned source: candidate-law `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`.

The full branch tree was searched for G0c, CK/bosonization, `ckcore`, `turns.py`, and related rotation paths. The durable G0c packet contains these two files, both fully read and preserved:

| Repository path | SHA256 |
|---|---|
| `.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/REFEREE_VERDICT.md` | `487587f7dd10c72dc680319d1dbcea151583136fe0e25825635d4f3af89efc8d` |
| `.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/referee_checks.py` | `0aeab81ffc4419ba74a0cbbf1b402fec6d496d52bca742193e2b3012b25f7d0d` |

The worker/supervisor summary at `.claude/science/candidates/candidate-law-20261008/TEST_LOG.md` lines263–325 has SHA256 `0ee3112d7eb69a7914c87898ef344774414d882e731fce1a973c6644acb48aec`. It is not a substitute for the primary construction. The original worker's broader Eq.30, frame/size and depth wording is corrected by the referee; use the referee's exact final statement.

The referee code imports `ckcore` and `turns`. Those dependency files, the worker's complete derivation/implementation and the cited output files were not found in the pinned branch tree. I did not run the incomplete program or infer hashes for absent sources.

The referee points to the following original location:

```text
/private/tmp/claude-502/-Users-jonBridger-Projects-Physics-baremetal-probes--claude-worktrees-toe-leverage-analysis-e8a790/af5789b9-888d-43b1-90de-58a07e0f2129/scratchpad/referee_G0c/
```

Referenced members include `ckcore.py`, `turns.py`, `t1b_gauss_vs_CK30.py`, `t3_turns.py`, `t6_framing_scan.py`, `paper/ck.txt`, `out_referee_checks.txt`, `out_t1b.txt`, `out_t3_A10.txt`, `out_t4_A10.txt`, and `out_depth_A10.txt`. These temporary paths were not accessed and may need recovery from the original campaign archive. Their existence elsewhere is unresolved, not denied.

The strongest statement actually recorded by the referee is:

> For the genuine Chen–Kapustin A10 cubic framing, on periodic \(L=3,4\) lattices every one of the 24 proper cubic turns about either a cube centre or a vertex is implemented by a geometric face permutation followed by a cube-local diagonal Clifford dressing; it preserves the Gauss-law code, maps all parity and hopping generators correctly, retains the fermionic exchange sign, and realizes the cubic group with an exact nonprojective composition law. This establishes turn covariance of the constrained even algebra of a one-component spinless lattice fermion, not a spin-\(\tfrac12\) double-group action, and explicitly tests PPP rather than AAA.

The quotation is copied from the pinned referee source. Its final sentence restricts this to the one-component spinless even algebra and PPP implementation. It does not establish spin 1/2, AAA, all system sizes, rotations about each occupied physical role, or a nearest-neighbor circuit for the macroscopic spatial permutation.

The separately pinned main predecessor is:

```text
archive/notes/docs/work_history/repo/review_feedback/EXACT_3D_HIGHER_FORM_BOSONIZATION_CYCLE235_NOTE_2026-07-17.md
main 583c699e859b64ff01c8bc92d1c04bdfe9994509
SHA256 295edee5608d3141fc3e3212bc51753265d953dadd68a8b44a66ed1e0e16e0d2
```

That complete 481-line note was read. It contains an explicit physical six-mode/15-face-qubit architecture and its distinct historical full-Fock boundary. Its exact runner exists at `scripts/exact_3d_higher_form_bosonization_cycle235_2026_07_17.py`, but was not read or run in this survey. It is useful prior art, not a recovery of G0c's missing code.

Recovery acceptance should first bind the actual CK A10 framing, correction history, primary code, imported dependencies and original outputs to byte hashes. Only then can a new source review or scientific execution substantiate reuse; this reconnaissance confers no such verdict.
