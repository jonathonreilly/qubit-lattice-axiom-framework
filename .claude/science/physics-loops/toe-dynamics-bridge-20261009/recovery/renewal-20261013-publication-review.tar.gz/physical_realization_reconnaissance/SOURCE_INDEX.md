# Pinned source index

Source copies are exact `git show REV:PATH` bytes. Reading coverage is separate from theorem verification. No scientific runner was executed. Full SHA256 values follow.

## ai: AGENTS.md

Revision: `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`  
SHA256: `3d409e93abb3b58796a9c10ca6d21ba93b7edc73b8fb24e7364da97c805580a9`  
Size: 11558 bytes; 183 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/ai/AGENTS.md)

## ai: TOE_SCORECARD.md

Revision: `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`  
SHA256: `b235f314801c5c1b6407ef4493804bbae009963dded8ab2648736580bd21e93d`  
Size: 19201 bytes; 171 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/ai/TOE_SCORECARD.md)

## ai: CAMPAIGN_STATUS.md

Revision: `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`  
SHA256: `f8543c159bdb2bb8e98d2c42f429fe0b7a0e0f4a62246257fcf0222ea8c1ae2b`  
Size: 5055 bytes; 64 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/ai/CAMPAIGN_STATUS.md)

## ai: BACKLOG_STATUS.md

Revision: `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`  
SHA256: `88713c9331b92f3c9d5fff2db898deaf8b04ea8d74dfe0c2525267a6d5b3ab34`  
Size: 37170 bytes; 420 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/ai/BACKLOG_STATUS.md)

## ai: OPEN_PR_INVENTORY.json

Revision: `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`  
SHA256: `ed6d7c0e78019d521380b4aa1330296452f908579c8402356bb6eaf01649d1c3`  
Size: 3203 bytes; 109 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/ai/OPEN_PR_INVENTORY.json)

## main: docs/ai_methodology/SCIENCE_WORKFLOW.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce`  
Size: 15435 bytes; 245 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/ai_methodology/SCIENCE_WORKFLOW.md)

## main: docs/MINIMAL_AXIOMS_2026-06-29.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `93af34cf6fcfcfcc85c2cd39e8be7bbcf25253030f83a4cbc905a4a0cd68b753`  
Size: 11333 bytes; 233 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/MINIMAL_AXIOMS_2026-06-29.md)

## main: docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `f268ad7caad2db36a3274c7304c8ba97ce24d33afb49d4e9ad47b45a2848ec69`  
Size: 6427 bytes; 130 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md)

## main: docs/audit/data/axiom_premise_nodes.json

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `615f13aaa70e82d50cdf1a8aa479eb40d6ce70a3bb7b152ac63fd88bee341f37`  
Size: 6416 bytes; 52 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/audit/data/axiom_premise_nodes.json)

## main: docs/MICROSCOPIC_CURRENT_IMPLEMENTATION_BOUNDED_THEOREM_NOTE_2026-10-12.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `3b59c6aebd78eca1ad72c69b9b73cfede0abd1a7a315389cf0c6c7eebeb20485`  
Size: 38590 bytes; 440 lines.  
Coverage: selected_complete_sections_only. Header/claim and opening source boundary only (lines1–33); not used as a proved premise.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/MICROSCOPIC_CURRENT_IMPLEMENTATION_BOUNDED_THEOREM_NOTE_2026-10-12.md)

## main: docs/LOCAL_REFERENCE_FERMION_ENCODING_OBSTRUCTIONS_AND_CONSTRUCTIVE_GRAPH_ISOMETRIES_BOUNDED_THEOREM_NOTE_2026-09-14.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `240f0f508a02c343b4c239a43d2d6b005b65ac25d17b1f2991f8caf341fceb64`  
Size: 41090 bytes; 685 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/LOCAL_REFERENCE_FERMION_ENCODING_OBSTRUCTIONS_AND_CONSTRUCTIVE_GRAPH_ISOMETRIES_BOUNDED_THEOREM_NOTE_2026-09-14.md)

## main: docs/DYNAMICS_CLAUSE_RECORDS_CARVE_EXACTLY_SOLVABLE_THREE_DIMENSIONAL_KITAEV_NETWORKS_GAPPED_MAJORANA_FERMIONS_IN_A_STATIC_Z2_GAUGE_FIELD_BOUNDED_THEOREM_NOTE_2026-09-24.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `36a45000490e3620e2a8c399b90713d5932a9f6c8d90e64a03f8708fda464f88`  
Size: 11153 bytes; 116 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/DYNAMICS_CLAUSE_RECORDS_CARVE_EXACTLY_SOLVABLE_THREE_DIMENSIONAL_KITAEV_NETWORKS_GAPPED_MAJORANA_FERMIONS_IN_A_STATIC_Z2_GAUGE_FIELD_BOUNDED_THEOREM_NOTE_2026-09-24.md)

## main: docs/THE_HYPERHONEYCOMB_EMBEDS_IN_THE_DOUBLED_CUBIC_LATTICE_A_THREE_DIMENSIONAL_COMPOSITE_SITE_NETWORK_WITH_AN_EXACT_CHARGE_BOUNDED_THEOREM_NOTE_2026-09-24.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `72bec69c09dd89e4bf2b61e61d0343c335cead637f38988a3c9ce97e0ad9cde7`  
Size: 8452 bytes; 140 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/THE_HYPERHONEYCOMB_EMBEDS_IN_THE_DOUBLED_CUBIC_LATTICE_A_THREE_DIMENSIONAL_COMPOSITE_SITE_NETWORK_WITH_AN_EXACT_CHARGE_BOUNDED_THEOREM_NOTE_2026-09-24.md)

## main: docs/ORIGINAL_RECORD_CALIBRATION_AND_PREPARED_MATTER_PROBE_BOUNDED_THEOREM_NOTE_2026-09-24.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `41c545882c910d6d351a8537e93d52f23794155e9b531310c88a556bde82c8e4`  
Size: 37258 bytes; 686 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/ORIGINAL_RECORD_CALIBRATION_AND_PREPARED_MATTER_PROBE_BOUNDED_THEOREM_NOTE_2026-09-24.md)

## main: docs/NATIVE_SAME_HAMILTONIAN_RAMP_NOTE_2026-09-08.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `0885155f848eebe50e45b9cec4805265c4f6ac5edc330b214dec1c40d66d0223`  
Size: 18697 bytes; 184 lines.  
Coverage: selected_complete_sections_only. Header/claim and opening source boundary only (lines1–33); not used as a proved premise.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/NATIVE_SAME_HAMILTONIAN_RAMP_NOTE_2026-09-08.md)

## main: docs/DIRECTED_BOND_QUADRATIC_ACTION_CHANNELS_BOUNDED_THEOREM_NOTE_2026-10-09.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `746af0f3ab84c1bff3b397939d443424c999f4eef291a8664f33ba5a0e8c3892`  
Size: 15634 bytes; 344 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/DIRECTED_BOND_QUADRATIC_ACTION_CHANNELS_BOUNDED_THEOREM_NOTE_2026-10-09.md)

## main: docs/LOCAL_EVEN_CONTINUUM_BOUNDED_THEOREM_NOTE_2026-10-12.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `b5a8394a9d8c17bb9559597a68b061ad3872201ebf9793bd5c9f10b15ac2c6aa`  
Size: 36376 bytes; 731 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/LOCAL_EVEN_CONTINUUM_BOUNDED_THEOREM_NOTE_2026-10-12.md)

## main: docs/SCALE_REFERENCE_PRIMITIVE_NOTE.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `e7e75a36bd16094cbb547f6b215680ac45adc565c4cc93f05b0af17992eb9292`  
Size: 2581 bytes; 57 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/SCALE_REFERENCE_PRIMITIVE_NOTE.md)

## main: docs/KINETIC_ISOTROPY_PRIMITIVE_NOTE_2026-06-09.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `5516fb0bb8f50286b3c34d3f2668b1a2e347b9f7e257a8b5745f84f1093dd96b`  
Size: 4770 bytes; 99 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/KINETIC_ISOTROPY_PRIMITIVE_NOTE_2026-06-09.md)

## main: docs/REALIZED_STATE_PRIMITIVE_NOTE_2026-06-11.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `755cfd44924439468708124a8aaafce1b2bcaf6260d3bc08263dc6e7a4327563`  
Size: 5313 bytes; 110 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/REALIZED_STATE_PRIMITIVE_NOTE_2026-06-11.md)

## candidate_law: .claude/science/candidates/candidate-law-20261008/CANDIDATE_1.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `faa293b72cfff41f2d910d27cf5da9a0935b515f79af44a54d03874583dfe226`  
Size: 6579 bytes; 96 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/candidates/candidate-law-20261008/CANDIDATE_1.md)

## candidate_law: .claude/science/candidates/candidate-law-20261008/DECISION_MATRIX.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `a5bd4006e487ee732eacb309f413696be807e33916aad8a39ce3d18a62e36d76`  
Size: 7850 bytes; 161 lines.  
Coverage: snapshot_only. Preserved for recovery; contents not used to support conclusions.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/candidates/candidate-law-20261008/DECISION_MATRIX.md)

## candidate_law: .claude/science/candidates/candidate-law-20261008/TEST_LOG.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `0ee3112d7eb69a7914c87898ef344774414d882e731fce1a973c6644acb48aec`  
Size: 50766 bytes; 649 lines.  
Coverage: selected_complete_sections_only. Lines1–325: G0/G0b/G0c and adjacent comparison entries. Later entries not relied upon.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/candidates/candidate-law-20261008/TEST_LOG.md)

## observations: .claude/science/physics-loops/observations-to-toe-24h-20261012/FINAL_REPORT.md

Revision: `873795e3cd34b1e26d3fa1937169588c50ad5609`  
SHA256: `5e6e43059bb83eacb232233a403a2e58632a71f55ff0537c2e2fa47cc57ed24f`  
Size: 23554 bytes; 104 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/observations/.claude/science/physics-loops/observations-to-toe-24h-20261012/FINAL_REPORT.md)

## observations: .claude/science/physics-loops/observations-to-toe-24h-20261012/INTEGRATION_MAP.md

Revision: `873795e3cd34b1e26d3fa1937169588c50ad5609`  
SHA256: `be3f143e3eea3b566f71eec0fc0bcab9928914c5f85334acbf214f5e177df113`  
Size: 6415 bytes; 46 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/observations/.claude/science/physics-loops/observations-to-toe-24h-20261012/INTEGRATION_MAP.md)

## observations: .claude/science/physics-loops/observations-to-toe-24h-20261012/ASSUMPTIONS_AND_IMPORTS.md

Revision: `873795e3cd34b1e26d3fa1937169588c50ad5609`  
SHA256: `72fdbb9d4161da761157f3f3dc127fc9ab20c541d06509b62a72fed947cff0a1`  
Size: 14156 bytes; 159 lines.  
Coverage: snapshot_only. Preserved for recovery; contents not used to support conclusions.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/observations/.claude/science/physics-loops/observations-to-toe-24h-20261012/ASSUMPTIONS_AND_IMPORTS.md)

## candidate_law: .claude/science/candidates/candidate-law-20261008/checks/referee_G0c/REFEREE_VERDICT.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `487587f7dd10c72dc680319d1dbcea151583136fe0e25825635d4f3af89efc8d`  
Size: 9066 bytes; 27 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/REFEREE_VERDICT.md)

## candidate_law: .claude/science/candidates/candidate-law-20261008/checks/referee_G0c/referee_checks.py

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `0aeab81ffc4419ba74a0cbbf1b402fec6d496d52bca742193e2b3012b25f7d0d`  
Size: 15237 bytes; 418 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/candidates/candidate-law-20261008/checks/referee_G0c/referee_checks.py)

## main: docs/FINITE_WINDOW_MICROSCOPIC_ENERGY_LAWS_BOUNDED_THEOREM_NOTE_2026-09-25.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `bc3bbcefdc844659396fb100da6de3922d418d98c218eb66071340e28c14d0c6`  
Size: 24713 bytes; 367 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/FINITE_WINDOW_MICROSCOPIC_ENERGY_LAWS_BOUNDED_THEOREM_NOTE_2026-09-25.md)

## main: docs/NATIVE_FEEDBACK_FINITE_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-13.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `b5ee292289cd2c133fee8ceaf68452366ea0dc04e3570326cd643ed4b5674503`  
Size: 16250 bytes; 319 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/NATIVE_FEEDBACK_FINITE_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-13.md)

## main: docs/AUTONOMOUS_LOCAL_SUPPLIER_OF_ORIGINAL_ROTOR_RECORDS_BOUNDED_THEOREM_NOTE_2026-09-30.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `29602b548895fe0fd7dcfb256aadaee35dbbaf8f226147d9d4c847b2a068c4b3`  
Size: 47653 bytes; 866 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/AUTONOMOUS_LOCAL_SUPPLIER_OF_ORIGINAL_ROTOR_RECORDS_BOUNDED_THEOREM_NOTE_2026-09-30.md)

## main: docs/NATIVE_DENSITY_SPECTRUM_AND_READOUT_ENERGY_BOUNDED_THEOREM_NOTE_2026-09-30.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `7cc68d5ec8e8db3123409555c15582c8238e5c2eb60ec5f20c6f392081261d62`  
Size: 47713 bytes; 747 lines.  
Coverage: selected_complete_sections_only. Header/claim lines1–33, heading/search matches and identified supplied occupation-Luders scope only; no full proof read.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/NATIVE_DENSITY_SPECTRUM_AND_READOUT_ENERGY_BOUNDED_THEOREM_NOTE_2026-09-30.md)

## main: docs/NATIVE_EDGE_RECORD_FINITE_COLLISION_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-07.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `06c624b2bd77da00f404c7e31a125f5ce1db21a3483e7bc662cea0ae8afa3885`  
Size: 11757 bytes; 128 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/NATIVE_EDGE_RECORD_FINITE_COLLISION_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-07.md)

## main: docs/REPEATED_RECORD_MATTER_AND_ENERGY_CONSERVING_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-05.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `9f572fe7baa96e6c2fe2f9432a5dac96959d7c2ba635fc7c2365059939f8b056`  
Size: 36721 bytes; 835 lines.  
Coverage: selected_complete_sections_only. Claim/opening boundary, full apparatus argument lines268–491, full stationary-input comparison lines684–744; other bulk matter laws not rechecked.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/REPEATED_RECORD_MATTER_AND_ENERGY_CONSERVING_APPARATUS_BOUNDED_THEOREM_NOTE_2026-09-05.md)

## main: docs/CONNECTED_CHAIN_LOCAL_ENERGY_BOUNDARY_COMMUTANT_BOUNDED_THEOREM_NOTE_2026-09-07.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `2731290317cbefbec8cc9f3be37aa554d705c25cdfa9b8de014b10018c2f9403`  
Size: 8308 bytes; 71 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/docs/CONNECTED_CHAIN_LOCAL_ENERGY_BOUNDARY_COMMUTANT_BOUNDED_THEOREM_NOTE_2026-09-07.md)

## main: archive/notes/docs/work_history/repo/review_feedback/LOCAL_INSTRUMENT_TO_RECORD_CLOSE_TOURNAMENT_CYCLE279_NOTE_2026-07-17.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `de39729d0f845994e04dd0b417ac7d05f90be14790c47d2183d7cb6ae24cd1c1`  
Size: 29265 bytes; 575 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/archive/notes/docs/work_history/repo/review_feedback/LOCAL_INSTRUMENT_TO_RECORD_CLOSE_TOURNAMENT_CYCLE279_NOTE_2026-07-17.md)

## candidate_law: .claude/science/exercises/gravity-current-state-20261009/agents/C5_F5_report.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `5996a5789d1489f88a3054087945244b6bd746ce46697af9d0ee6823618b79e6`  
Size: 41959 bytes; 256 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/exercises/gravity-current-state-20261009/agents/C5_F5_report.md)

## candidate_law: .claude/science/exercises/gravity-current-state-20261009/agents/panel_F/SYNTHESIS.md

Revision: `56a60d09abe4aa99cc41a517c2881f5e64da7e6f`  
SHA256: `4b8318b1faf7439c2998a86d071fd0df464bc5d228743fcb7b66bd173d0f5b01`  
Size: 10194 bytes; 124 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/candidate_law/.claude/science/exercises/gravity-current-state-20261009/agents/panel_F/SYNTHESIS.md)

## main: archive/notes/docs/work_history/repo/review_feedback/EXACT_3D_HIGHER_FORM_BOSONIZATION_CYCLE235_NOTE_2026-07-17.md

Revision: `583c699e859b64ff01c8bc92d1c04bdfe9994509`  
SHA256: `295edee5608d3141fc3e3212bc51753265d953dadd68a8b44a66ed1e0e16e0d2`  
Size: 21919 bytes; 481 lines.  
Coverage: complete_text_read. Complete pinned source read as reconnaissance; no fresh independent verification or scientific execution.

[Exact snapshot](/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/renewal_20261013_213733/physical_realization_reconnaissance/sources/main/archive/notes/docs/work_history/repo/review_feedback/EXACT_3D_HIGHER_FORM_BOSONIZATION_CYCLE235_NOTE_2026-07-17.md)

