# TOE campaign — 2026-09-07

Owner update 2026-09-10: review, correct and land all 18 remaining original PRs. The prior owner reservations on #6379/#6858/#6859 are released for this task, including dependent original scopes. Source acceptance still requires focused independent review and combined validation. All twelve formerly pending transferred scopes now have corrected landing dispositions; eight partial Maxwell scopes retain their scientific obligations. New arrivals remain excluded and formal audit stays deferred. See [release and frozen heads](backlog_evidence/released18-20260910/RELEASED_TARGETS.json). Counts below remain the last completed landing snapshot.

The fixed original 254 PR backlog now has complete review and closure dispositions. New arrivals are
excluded by the owner cutoff in BACKLOG_CUTOFF.json. Read
[BACKLOG_STATUS.md](BACKLOG_STATUS.md) for current main, queue counts and assignments,
[NEXT_REVIEW_UNITS.json](NEXT_REVIEW_UNITS.json) for exact units, and
[TOE_SCORECARD.md](TOE_SCORECARD.md) for physical obligations. Formal audit is
deferred until a solid TOE. Shared planning remains on the separate ai/execution
branch; source landings go to main.

The original three-block science campaign is a checkpoint on
physics-loop/toe-campaign-20260907, based on f6f861e8f0c7870b3a9a200a020ec5ca0b14be38.
Its whole packet remains unlanded. The selected field-source correction is now
independently reviewed and on main; that does not land the whole campaign packet.

## What the campaign changed

The source/evidence checkpoint is `e3d28020b5fbe5f8c7c00bd030aba991abb364d3`
on `physics-loop/toe-campaign-20260907`.
Its common packet is `.claude/science/physics-loops/toe-campaign-20260907/`;
`RESULTS.md` indexes the notes and `REVIEW_HISTORY.md` binds the independent
checks to their exact source hashes. The three blocks share the frozen main
premises; they do not assume one another or close a physical TOE by assembly.
The explicitly authorized review/landing backlog, including all original drafts, is complete; see [BACKLOG_STATUS.md](BACKLOG_STATUS.md).

- Formation: for the supplied six-content local rule and iid priorities,
  permanent formation exists on Z3 with factorial ancestry/error tails.
  On the supplied ferromagnetic subfamily, a content-only statistic separates
  it from every free-boundary static limit. Which formation mechanism physics
  supplies remains open. The independent checker additionally optimized the
  finite adaptive scheduler exactly; its scoped gap survives.
- Matter: a supplied global spectral-battery operation admits finite-patch
  approximation with vanishing channel and full mean-energy error at fixed
  event count/duration. The proof prices the patch, coherence and positive
  reachable cap. The common battery's communication, preparation and autonomy
  remain unsolved. The finite narrow-packet energy loss is preserved.
- Field: #7946's occupation-sign source is checkerboard in the electric
  convention used by its parents; the uniform source needs root parity.
  Preserve the computed matrix responses and unrelated data. Correct the
  uniform-K identification and dependent UK interpretations. A full background
  flux endpoint is separately unitarily equivalent to zero source, so a
  physical flux-sector claim still needs its sector/branch and limit proof.

A suggested Born proof target was screened out because main already contains
a more general characterization on matching menus. The complete original review of #7990 found an indexed-effects versus Record-content mismatch
and unsupplied joint-law assumptions. Its reviewed corrections are now on main:
conditional indexed-menu mathematics is preserved, while physical probability and
joint-law selection remain open.

## Next scientific decisions

1. The requested 18 PRs and fixed 254 PR backlog are complete. 238 reviewed original science scopes landed: 139 direct science and 99 consolidated science. The 144 direct closures also include one partial Maxwell, one meta, two process scopes and one historical archive recovery. Eight original Maxwell scopes retain broader scientific obligations. No transferred scope remains pending on an open successor; historical and unproved scientific obligations remain recorded. Resume discovery from these corrected boundaries; formal audit remains deferred.
2. For field response, choose the actual physical source/sector and estimator
   target before another large computation. Finite fits do not resolve population,
   component, thermodynamic or physical-identification questions.
3. Choose a missing physical supplier: formation law, spatial apparatus and
   preparation, or sourced field/action. The checked conditional theorems constrain
   these interfaces but do not supply them by being assembled together.

Discovery continues with selective decisive checks and coherent review milestones.
Workers preserve their evidence and report to the coordinator, who owns shared
planning and GitHub changes. Complete historical campaign context is archived.
