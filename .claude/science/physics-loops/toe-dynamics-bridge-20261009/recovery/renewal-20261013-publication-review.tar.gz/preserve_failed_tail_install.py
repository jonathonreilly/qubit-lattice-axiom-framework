from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import tarfile

T = Path('/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009')
Z = T / 'renewal_20261013_213733'
CW = T / 'correlation_worktree'
P = T / 'worktree/.claude/science/physics-loops/toe-dynamics-bridge-20261009'
RUN = Z / 'energy_tail_publication_execution/20261013T221757_prepare_72458b48a14c'
BASE = 'e8d5b7b99c9faab65f71eb5ff353b60e2b609608'
MANIFEST = 'docs/audit/data/citation_graph_manifest.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=CW)
assert git('rev-parse', 'HEAD').decode().strip() == BASE
assert git('branch', '--show-current').decode().strip() == 'physics-loop/toe-energy-tail-20261013'
assert not git('diff', '--cached', '--name-only')
freeze = json.loads((RUN / 'SOURCE_FREEZE.json').read_text())
payload = {r['path'][8:]: r for r in freeze['files'] if r['path'].startswith('payload/')}
extra = {
    'logs/runner-cache/energy_tail_identity_2026_10_13.txt',
    '.claude/science/physics-loops/toe-energy-tail-20261013/PUBLICATION_ASSEMBLY_REVIEW.txt',
    '.claude/science/physics-loops/toe-energy-tail-20261013/PUBLICATION_ROOT_ACCEPTANCE.json',
}
status = git('status', '--porcelain=v1', '-z', '--untracked-files=all')
rows = [x.decode() for x in status.split(b'\0') if x]
actual = {r[3:]: r[:2] for r in rows}
assert set(actual) == set(payload) | extra | {MANIFEST}, (len(actual), len(payload), set(actual) - set(payload) - extra - {MANIFEST})
assert actual[MANIFEST] == ' M'
assert all(v == '??' for k, v in actual.items() if k != MANIFEST)
for name, row in payload.items():
    assert sha((CW / name).read_bytes()) == row['sha256'], name
assert (CW / MANIFEST).read_bytes() == (RUN / 'citation_graph_manifest.complete.json').read_bytes()
assert git('show', BASE + ':' + MANIFEST) == (RUN / 'base_graph_manifest.json').read_bytes()
bundle = P / 'recovery/renewal-20261013-failed-tail-integration.tar.gz'
assert not bundle.exists()
members = {}
for name in sorted(actual):
    members['partial_install/' + name] = (CW / name).read_bytes()
for f in sorted(RUN.rglob('*')):
    if f.is_file():
        members['execution/' + str(f.relative_to(RUN))] = f.read_bytes()
import io
with tarfile.open(bundle, 'w:gz') as tar:
    for name, data in members.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(bundle, 'r:gz') as tar:
    assert tar.getnames() == list(members)
    for name, data in members.items():
        assert tar.extractfile(name).read() == data, name
receipt = {
    'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reason': 'Root prepare found no citation edges because canonical Markdown parent citations were missing; mathematical bodies unchanged.',
    'failed_run': str(RUN), 'archive': str(bundle), 'archive_sha256': sha(bundle.read_bytes()),
    'base': BASE, 'initial_git_status': rows,
    'members': [{'path': n, 'sha256': sha(b), 'bytes': len(b)} for n, b in members.items()],
    'preservation_roundtrip_verified': True,
}
# Only root-owned files from this failed install are removed after exact recovery.
for name in sorted(set(actual) - {MANIFEST}):
    f = CW / name
    assert f.read_bytes() == members['partial_install/' + name]
    f.unlink()
(CW / MANIFEST).write_bytes((RUN / 'base_graph_manifest.json').read_bytes())
receipt['final_git_status'] = git('status', '--porcelain=v1', '-z', '--untracked-files=all').decode()
assert not receipt['final_git_status']
out = Z / 'ENERGY_TAIL_FAILED_INSTALL_RECOVERY.json'
out.write_text(json.dumps(receipt, indent=2) + '\n')
(P / 'recovery/renewal-20261013-failed-tail-integration.MANIFEST.json').write_bytes(out.read_bytes())
print(json.dumps({'archive': str(bundle), 'archive_sha256': receipt['archive_sha256'], 'preserved_members': len(members), 'restored_clean_head': BASE, 'receipt': str(out)}, indent=2))
