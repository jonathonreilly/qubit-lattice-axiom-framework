from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import tarfile
import yaml

T = Path('/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009')
Z = T / 'renewal_20261013_213733'
W = T / 'worktree'
CW = T / 'correlation_worktree'
P = W / '.claude/science/physics-loops/toe-dynamics-bridge-20261009'
R = T / 'resume_20261012'
sha = lambda b: hashlib.sha256(b).hexdigest()
now = dt.datetime.now(dt.timezone.utc).isoformat()
def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
assert git(W, 'rev-parse', 'HEAD') == 'c03620656c4b745351e388d8dad1e12d1a0eb324'
assert git(W, 'status', '--porcelain') == ''
assert git(CW, 'branch', '--show-current') == 'physics-loop/toe-energy-tail-20261013'
assert git(CW, 'rev-parse', 'HEAD') == 'e8d5b7b99c9faab65f71eb5ff353b60e2b609608'
old = yaml.safe_load((P / 'STATE.yaml').read_text())
hist = P / 'history/renewal-1-complete-before-20261013T213733Z'
hist.mkdir(exist_ok=False)
for name in ['STATE.yaml', 'HANDOFF.md', 'GOAL.md', 'OPPORTUNITY_QUEUE.md', 'TRACE_GATE.md', 'CLAIM_STATUS_CERTIFICATE.md']:
    (hist / name).write_bytes((P / name).read_bytes())
lock = json.loads((Z / 'LOCK_ACQUIRED.json').read_text())['payload']
state = {
    'loop': 'toe-dynamics-bridge-20261009', 'mode': 'campaign', 'delivery': 'milestone',
    'runtime': '24h', 'renewal_number': 2,
    'started_utc': '2026-10-13T21:37:33+00:00',
    'deadline_utc': '2026-10-14T21:37:33+00:00',
    'checkpoint_interval': '30m', 'checkpoint_utc': now,
    'campaign_status': 'active', 'automation_status': 'ACTIVE',
    'automation_id': 'toe-physical-realization-renewed-24-hour-campaign',
    'authorization': 'Explicit user renewal: another 24 hours; latest repo sync; regular energy-tail and epsilon=o(h) PRs; then highest-leverage physical-realization gaps.',
    'active_branch': git(CW, 'branch', '--show-current'),
    'worktree': str(CW), 'active_head': git(CW, 'rev-parse', 'HEAD'),
    'base_revision': 'e8d5b7b99c9faab65f71eb5ff353b60e2b609608',
    'active_parent_pr_url': 'https://github.com/jonathonreilly/qubit-lattice-axiom-framework/pull/9521',
    'active_pr_status': 'Publication preparation; no new PR yet', 'active_pr_url': None,
    'checkpoint_directory': str(P), 'checkpoint_branch': git(W, 'branch', '--show-current'),
    'previous_checkpoint_commit': git(W, 'rev-parse', 'HEAD'),
    'source_root': str(Z), 'prior_source_root': str(R),
    'latest_main_revision': '583c699e859b64ff01c8bc92d1c04bdfe9994509',
    'instruction_revision': '3a4b2c66a1ead7a1c48b4359627e968f681e3c39',
    'latest_candidate_law_revision': '56a60d09abe4aa99cc41a517c2881f5e64da7e6f',
    'latest_observations_revision': '873795e3cd34b1e26d3fa1937169588c50ad5609',
    'startup_status': 'Fetch, source refs, open-PR inventory and current instruction identity refresh complete; physical-route primary-source reconnaissance in progress.',
    'source_refresh_evidence': str(Z / 'STARTUP_REPO_SYNC.json'),
    'procedure_evidence': str(Z / 'PROCEDURE_SNAPSHOT.json'),
    'grounding_evidence': str(Z / 'GROUNDING_SOURCES.json'),
    'pr_inventory_limit': 'gh pr view files returned at most 100 paths for larger unchanged parents; complete prior local source maps are reused, not replaced by this truncated field.',
    'external_pr_scope': '9524 and 9525 bodies and complete five-path inventories read: supplied revised-scalar action, homogeneous confinement and local scalar response. Science not adopted. External candidate-law/observations changes under reconnaissance.',
    'cycle': 1, 'active_route': 'Publish accepted finite-first-energy tails, then graph calibration sharpening; source survey ranks physical-realization target.',
    'target_claim_type': 'bounded_theorem', 'actual_current_surface_status': 'conditional-support',
    'campaign_prs_created': 0, 'campaign_prs_currently_open': 0,
    'prior_campaign': {'archive': str(hist), 'started_utc': old['started_utc'], 'deadline_utc': old['deadline_utc'], 'status': old['campaign_status'], 'regular_prs': [9499,9500,9502,9504,9506,9508,9510,9511,9512,9513,9515,9516,9517,9518,9520,9521,9522], 'checkpoint_head': git(W,'rev-parse','HEAD'), 'recovery_bundle': old['recovery_bundle']},
    'energy_tail': {'status': 'Accepted source assembly; publication preparation active', 'assembly': str(R / 'postmeasurement_energy_ui_source_assembly'), 'freeze_sha256': '8a19d7e566f1ed77a2effe2234ad4fc0e4398f28a562c151b3245e5abbcfc7cf', 'root_review_sha256': '54072cf09669f21b4581abb79da64bcf9ce37fbd3de2e49f86ed8aa7a5fdac90', 'publication_folder': str(Z / 'energy_tail_publication_preparation'), 'scope': 'Fixed first-energy normal state and uniformly graph-bounded finite protocol imply final-energy uniform integrability. Varying states require joint limsup quantifier. J=Gamma C is linear/unitary. Weak prepared-state law remains explicitly supplied/provisional in its corollary.'},
    'graph_calibration': {'status': 'Checked epsilon=o(h) theorem; source assembly active; tail canonical parent not yet supplied', 'acceptance': str(R / 'ENERGY_GRAPH_PERTURBATION_FINAL_ROOT_ACCEPTANCE.json'), 'acceptance_sha256': '6766afd47d73f3de5ab1a1a3437dac43f6a31ef734566ec51cf88876557660ad', 'source_folder': str(Z / 'graph_calibration_source_assembly'), 'scope': 'Uniform ideal G graph norms and common-H bounded perturbation/commutator errors give epsilon*b -> 0 graph transfer; b=O(1/h) yields epsilon=o(h). Calibration order p differs from chain length. Growing-C_G diagnostic applies only to propagator differences, not the full protocol theorem.'},
    'scoped_lean_status': 'CutoffUniformTail.lean bbcb658c compiled in 20.399216 seconds, exit0, standard propext/Classical.choice/Quot.sound. Only the scalar uniform-cutoff implication is formalized; CAR, domains, traces, kinetic limits and physical calibration are not.',
    'independent_checks': 'Previous exact frozen analytic derivations plus independent finite controls and source-exposed reviews reused at unchanged identities. Same-family corroboration, not a model-diverse or retained audit.',
    'independent_audit': 'not_requested; no verdicts applied',
    'provisional_dependencies': 'Supplied one-dimensional gapped CAR/spin chain, graph bounds, common Hamiltonian and exact instruments. Prepared and compact-normal-family results remain checked provisional dependencies where invoked.',
    'strongest_unresolved_obligations': ['Actual three-dimensional local-qubit realization', 'Physical common-H observable/instrument and calibrated embedding', 'Interacting-channel and central-rate selection'],
    'failed_routes_and_corrections': ['Original energy-tail J antiunitary wording corrected by immutable precision addendum; later Gamma remains antiunitary.', 'Root graph-transfer V1 inverse derivative argument repaired in V2; all originals retained.', 'Weak energy convergence alone does not control means; nonuniform graph bounds and unrestricted first-energy balls retain counterexamples.', 'Reconnaissance agent disconnected twice; reassigned to a fresh bounded source survey without scientific acceptance.', 'Stale usable-derived-index path resolved to archive; no source authority inferred from a failed lookup.', 'Oversized startup metadata display truncated; exact live pointers and relevant argument ranges recovered separately.'],
    'active_workers': {'kinetic_correlation_review': 'energy-tail publication preparation only', 'threshold_protocol_fresh': 'graph-calibration source assembly only', 'physical_source_survey': 'read-only primary-source reconnaissance only'},
    'next_action': 'Review the full changed energy-tail wrapper, dependency declarations, runner and publication driver; run exact source/runtime checks, publish a regular stacked PR, then bind calibration publication to the actual tail head. Independently finish current-source physical reconnaissance before selecting new derivations.',
    'lock_owner': lock['owner'], 'lock_status': 'held', 'lock_expires_utc': lock['expires_at'], 'lock_refresh_before_utc': '2026-10-13T23:30:00+00:00',
    'lock_path': str(T / 'current_preserving_worktree/logs/physics_worker_lock.json'),
    'lock_meta_path': str(T / 'current_preserving_worktree/logs/.physics_worker_lock.guard'),
    'stop_condition': 'Fixed deadline or documented global quality/tooling exhaustion; local blockers trigger another useful route.',
    'boundaries': ['No science merges or main pushes', 'No audit verdicts', 'No physical-axiom or editable-prompt changes', 'No messages to other chats'],
    'editable_prompt_files_changed': [], 'automatic_continuation_disabled': False,
}
(P / 'STATE.yaml').write_text(yaml.safe_dump(state, sort_keys=False, width=110))
(P / 'HANDOFF.md').write_text(f'''# Current recovery checkpoint — renewed campaign active

User explicitly renewed work for another 24 hours. Start 2026-10-13T21:37:33Z;
fixed deadline 2026-10-14T21:37:33Z (5:37:33 p.m. America/New_York).
New heartbeat: toe-physical-realization-renewed-24-hour-campaign. Never extend it.
Prior campaign is archived at {hist}; its old heartbeat remains deleted.

Active worktree {CW}, branch physics-loop/toe-energy-tail-20261013,
HEAD/base e8d5b7b99c9faab65f71eb5ff353b60e2b609608, regular parent PR9521.
Checkpoint worktree {W}, branch physics-loop/toe-nonlinear-transport-20261011.
No new PR yet. Prior17 regular PRs remain open/non-draft at startup inventory.
Current main583c699e859b64ff01c8bc92d1c04bdfe9994509 and ai/execution3a4b2c66
are unchanged. Candidate-law56a60d09 and observations873795e3 advanced; source
reconnaissance is active. Scalar PR9524/9525 bodies and five-path inventories
show separate supplied-action scopes; their science is not adopted.

Current evidence root {Z}. Startup sync, procedure reuse and grounding identities
are saved there. GH's files field capped large parents at100; complete prior
local maps, not that truncated field, remain their source evidence.

First publication: accepted energy-tail assembly326members/freeze8a19d7e5,
review54072cf0. Worker kinetic_correlation_review prepares one canonical note
with explicit graph premises. Prepared normal-state weak-law corollary retains
its own supplied/provisional premise and full reviewed sources; the vacuum
multitime parent does not certify it. J=Gamma C must be linear/unitary; varying
states use lim_R limsup_joint. Failed originals and precision addenda remain.
Lean bbcb658c proves only the scalar cutoff implication, compiled20.399216s with
standard axioms; operator, CAR, trace and physical claims remain analytic.

Second publication: checked graph-Dyson epsilon=o(h), final acceptance6766afd4,
review8c604896. Worker threshold_protocol_fresh prepares the source assembly.
Uniform C_G, common H, bounded errors and exact instruments remain assumptions.
Calibration order p differs from chain length. Growing-C_G diagnostic is not
the full tail/protocol theorem. Root V1 inverse error and V2 repair remain.
Bind the publication to the actual energy-tail head only after it exists.

Physical_source_survey reads bounded primary sources and changed branches to
rank actual three-dimensional qubit realization, physical instrument/calibration,
and interacting-channel selection. No new physical derivation selected yet.
Prior reconnaissance agent disconnected twice; this is a tooling interruption,
not scientific evidence. Existing stronger results and precise no-go escapes
must be checked before choosing the target.

Root next: full changed wrapper/code review, exact checks and regular energy-tail
PR; then calibration PR and source-grounded physical derivation. No audit, main
push, axiom or editable-prompt change, or messages to other chats. Same-family
checks are not model-diverse verification. Continue useful science past local
blockers. At deadline start no research, checkpoint, release owned lock and
delete the new heartbeat. Lock expires {lock['expires_at']}; refresh by23:30UTC.

Checkpoint written {now}; original completed-campaign recovery bundle remains
{old['recovery_bundle']}. Exact prior scientific scopes and failures are preserved
in the archived STATE.yaml. This current STATE/HANDOFF pair is authoritative.
''')
(P / 'GOAL.md').write_text('''# Renewed TOE derivation campaign

From 2026-10-13T21:37:33Z through the fixed deadline2026-10-14T21:37:33Z,
publish the independently checked energy-tail and epsilon=o(h) calibration
results as regular PRs, then attack the highest-leverage physical-realization
gaps supported by current source reconnaissance. Original derivations are
authorized; use scoped Lean verification where it improves the audit evidence.

Continue discovery with selective independent checks and coherent milestone PRs.
Keep supplied models, conditional theorems, proof obligations and physical claims
distinct. Preserve counterexamples. Do not merge science, push main, apply audit
verdicts, alter physical axioms or editable prompts, or message other chats.
STATE.yaml and HANDOFF.md are the sole current operational checkpoint.
''')
(P / 'OPPORTUNITY_QUEUE.md').write_text('''# Current ranked queue

1. Publish accepted finite-first-energy tail theorem, explicit prepared-law
   dependency and scalar Lean scope. Exact parent9521; preparation active.
2. Publish checked graph-transfer sharpening epsilon=o(h), with uniform graph
   resources and common-H/instrument premises. Parent binding waits for actual1.
3. Rank and attack physical-realization gaps from current primary sources:
   three-dimensional qubit/even-algebra realization, actual instruments and
   calibration, interacting-channel selection. Ranking within3 is pending the
   neutral source survey; no new route is accepted from a headline.
4. Revisit threshold finite-protocol composition only if it resolves an actual
   physical-route need; its accepted unpublished source remains recoverable.

Local publication or tooling blockers do not exhaust the science queue.
Deadline2026-10-14T21:37:33Z; no automatic extension.
''')
(P / 'TRACE_GATE.md').write_text('''# Current trace gate

Conditional-support publication, not retained promotion. Energy-tail conclusion
follows from explicit uniform graph premises and finite first energy; prepared
weak-law composition retains its separate premise. Calibration sharpens the
sufficient scale under common-H bounded-error and uniform graph assumptions.
Neither supplies the physical qubit embedding, instrument, clock or dynamics.
Physical-route ranking remains under primary-source inspection. Failed weak-law
mean and nonuniform-family routes remain preserved. No audit verdict is applied.
''')
(P / 'CLAIM_STATUS_CERTIFICATE.md').write_text('''# Author scope certificate

Target bounded_theorem; actual conditional-support. Source checks and prior
focused analytic reviews are evidence, not retained audit status. No new physical
realization is asserted. Scoped Lean proves the scalar cutoff implication only.
See STATE.yaml for exact source identities and provisional dependencies.
''')
with (P / 'REVIEW_HISTORY.md').open('a') as f:
    f.write(f'\nRenewal2 started2026-10-13T21:37:33Z; checkpoint{now}. Prior campaign archived unchanged. Main/instructions unchanged; own publication heads unchanged. New regular tail/calibration preparation and read-only physical source survey active. No new scientific acceptance or audit verdict.\n')
startup = json.loads((Z / 'START.json').read_text())
startup['startup_status'] = state['startup_status']
(Z / 'START.json').write_text(json.dumps(startup, indent=2)+'\n')
evidence = [p for p in Z.iterdir() if p.is_file()]
evidence += [p for sub in ['startup_sync','procedures','grounding'] for p in (Z/sub).rglob('*') if p.is_file()]
bundle = P / 'recovery/renewal-20261013-startup.tar.gz'
manifest = [{'path':str(p.relative_to(Z)), 'sha256':sha(p.read_bytes()), 'bytes':p.stat().st_size} for p in sorted(set(evidence))]
with tarfile.open(bundle, 'w:gz') as tar:
    for row in manifest:
        tar.add(Z/row['path'], arcname=row['path'], recursive=False)
(P / 'recovery/renewal-20261013-startup.MANIFEST.json').write_text(json.dumps({'source_root':str(Z),'members':manifest,'archive_sha256':sha(bundle.read_bytes())},indent=2)+'\n')
print(json.dumps({'checkpoint_utc':now,'branch':state['active_branch'],'head':state['active_head'],'startup_archive':str(bundle),'members':len(manifest),'new_state_keys':len(state),'archived_prior':str(hist)},indent=2))
