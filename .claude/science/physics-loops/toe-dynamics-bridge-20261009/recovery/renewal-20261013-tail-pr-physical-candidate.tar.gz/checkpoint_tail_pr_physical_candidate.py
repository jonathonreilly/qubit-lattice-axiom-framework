from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import tarfile
import yaml

T = Path('/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009')
Z = T / 'renewal_20261013_213733'
W = T / 'worktree'
CW = T / 'correlation_worktree'
P = W / '.claude/science/physics-loops/toe-dynamics-bridge-20261009'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
now = dt.datetime.now(dt.timezone.utc).isoformat()
assert git(W, 'rev-parse', 'HEAD') == '16183b28ebcf88a7805387fb450e546026537ab1'
assert git(W, 'status', '--porcelain') == ''
assert git(CW, 'rev-parse', 'HEAD') == 'ccbeddd0c04b70ee2b6c5f1cffeeeefa23df2989'
assert git(CW, 'status', '--porcelain') == ''
created = json.loads((Z / 'ENERGY_TAIL_PR_CREATED.json').read_text())
assert created['pr']['state'] == 'OPEN' and not created['pr']['isDraft']
assert sha(CW / 'docs/POSTMEASUREMENT_ENERGY_TAIL_BOUNDED_THEOREM_NOTE_2026-10-13.md') == created['canonical_note_sha256']

reads = json.loads((Z / 'ROOT_INSTRUMENT_TARGET_SOURCE_READS.json').read_text())
additions = [
    ('LOCAL_EVEN_CONTINUUM_BOUNDED_THEOREM_NOTE_2026-10-12.md', [[1,731]], 'Full source read during this renewal; Haar local-even map alone does not provide the stronger energy-adapted Fock identification.'),
    ('ENERGY_ADAPTED_REFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-12.md', [[1,568]], 'Full source read during this renewal; supplied infinite-chain energy-adapted exact map and nonlocality restrictions. This is a premise/applicability read, not independent reverification of every earlier proof.'),
    ('CALIBRATED_ENERGY_TRANSFER_BOUNDED_THEOREM_NOTE_2026-10-13.md', [[1,126],[348,390],[752,813],[863,979],[1262,1300]], 'Necessary Fock/energy-PVM, calibrated-control, supplied-vacuum and scope passages freshly read; unchanged previously reviewed core reused, not a fresh full 1421-line read.')
]
for name, ranges, scope in additions:
    path = CW / 'docs' / name
    reads['sources'] = [r for r in reads['sources'] if r['path'] != str(path)]
    reads['sources'].append({'path': str(path), 'sha256': sha(path), 'lines': len(path.read_text().splitlines()), 'read_ranges': ranges, 'read_scope': scope})
reads['updated_utc'] = now
(Z / 'ROOT_INSTRUMENT_TARGET_SOURCE_READS.json').write_text(json.dumps(reads, indent=2)+'\n')

state = yaml.safe_load((P / 'STATE.yaml').read_text())
state.update(checkpoint_utc=now, previous_checkpoint_commit=git(W,'rev-parse','HEAD'), active_head=created['head'], active_pr_url=created['pr']['url'], active_pr_status='Regular PR9526 OPEN; clean published science head. Calibration actual-parent binding and physical instrument checks active.', campaign_prs_created=1, campaign_prs_currently_open=1)
state['energy_tail'].update(status='Published regular PR9526; conditional-support analytic theorem, unchanged mathematical cores.', publication_folder=str(Z/'energy_tail_publication_preparation_v2'), publication_acceptance=str(Z/'ENERGY_TAIL_PUBLICATION_V2_ROOT_ACCEPTANCE.json'), publication_freeze_sha256='c92f7441e466d4ac8ed5f71d0cb79a4f04afe9c3f31b5450e69e009a51a3d8b2', canonical_note_sha256=created['canonical_note_sha256'], pr_receipt=str(Z/'ENERGY_TAIL_PR_CREATED.json'), head=created['head'], prepare=str(Z/'energy_tail_publication_execution/20261013T223622_prepare_04336d40a60d'), verify=str(Z/'energy_tail_publication_execution/20261013T224113_verify_2df4239a9599'), verification_scope='All source, graph and exact staging checks passed; graph +1 node/+2 edges. Canonical identity and four corruption controls are zero-math checks. Focused ledger checked=[]; no retained verification inferred.')
state['graph_calibration']['status']='Source accepted and unbound package corrected; actual PR9526/head supplied to preparation worker. Resume final binding when a concurrency slot frees; no final freeze or runtime yet.'
state['physical_realization'].update(status='Root full coarse energy instrument candidate sealed; finite matrix controls pass; independent derivation and exposed local-compiler review active. No scientific acceptance or physical realization claimed.', root_candidate=str(Z/'coarse_energy_instrument_root/DERIVATION.md'), root_candidate_sha256='aa8349482e636744d001946cf2531d83f12d79847e3d025c35d657f4d6d093a8', root_candidate_sealed_utc='2026-10-13T22:34:51.077825+00:00', root_finite_controls=str(Z/'coarse_energy_instrument_root/finite_controls_run01/RECEIPT.json'), root_finite_scope='Reference-entangled full CQ instruments, fine-archive coherence counterexample, phase tails/boundary/alias controls, finite local product formula and coherent bus reset. Floating finite controls, not infinite-dimensional proof.', existing_bridge='Exact infinite-chain energy-adapted J_a, positive one-particle Fock lift I_a, vacuum and energy-PVM intertwining already exist for the supplied model. Do not duplicate or claim absent. The finite-volume/apparatus and quantitative locality/resource interface remains open.', source_reconciliation=str(Z/'ROOT_INSTRUMENT_TARGET_SOURCE_READS.json'), first_target='Full coarse common-H energy Lüders instrument preserving within-bin coherence and references, graph error transfer and priced finite local compiler. Connect finite apparatus to the existing exact infinite-chain energy bridge; do not rebuild that bridge.')
state['strongest_unresolved_obligations']=['Finite local apparatus and finite-volume interface to the existing supplied infinite-chain energy/Fock embedding', 'Native preparation, controls, energy accounting and actual three-dimensional local-qubit realization', 'Interacting-channel and central-rate selection']
state['active_workers']={'coarse_energy_instrument_derivation':'Independent full-instrument analytic target, root candidate hidden', 'local_instrument_compiler_review':'Source-exposed local compiler and finite full-instrument checks', 'physical_source_survey':'Exact existing energy/Fock bridge applicability report', 'threshold_protocol_fresh':'Idle pending concurrency slot; actual PR9526/head sent, final parent binding needed'}
state['next_action']='Resume calibration parent binding after a slot frees; review final changed sources, root prepare/stage/verify, regular PR and attachment. Complete physical instrument independent checks and reconcile existing energy-adapted bridge before the next finite-apparatus derivation.'
state['failed_routes_and_corrections'] += ['Tail v2 prepare accidentally invoked with PLACEHOLDER acceptance hash; rejected before mutation, preserved, then correct pinned invocation succeeded.', 'Read-only source command ran git in evidence directory and short-circuited intended reads; immediately reran reads in the correct directories.', 'Earlier physical-target checkpoint understated existing common-energy identification: source reconciliation found exact energy-adapted infinite-chain/Fock/PVM bridge. Finite-apparatus interface remains distinct.']

stable = [p for p in Z.iterdir() if p.is_file()]
stable += [p for p in (Z/'coarse_energy_instrument_root').rglob('*') if p.is_file()]
stable += [p for p in (Z/'energy_tail_git_publication').rglob('*') if p.is_file()]
for sub in ['20261013T223613_prepare_e9a7b75969a1','20261013T223622_prepare_04336d40a60d','20261013T224113_verify_2df4239a9599']:
    stable += [p for p in (Z/'energy_tail_publication_execution'/sub).rglob('*') if p.is_file()]
stable = sorted(set(stable))
manifest = [{'path': str(p.relative_to(Z)), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in stable]
bundle = P/'recovery/renewal-20261013-tail-pr-physical-candidate.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'w:gz') as tar:
    for row in manifest:
        tar.add(Z/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert tar.getnames() == [r['path'] for r in manifest]
    for row in manifest:
        assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest() == row['sha256']
bundle_receipt={'source_root':str(Z),'archive_sha256':sha(bundle),'members':manifest,'roundtrip_verified':True,'utc':now}
(P/'recovery/renewal-20261013-tail-pr-physical-candidate.MANIFEST.json').write_text(json.dumps(bundle_receipt,indent=2)+'\n')
state['recovery_bundle']=str(bundle)
(P/'STATE.yaml').write_text(yaml.safe_dump(state,sort_keys=False,width=110))
(P/'HANDOFF.md').write_text(f'''# Current recovery checkpoint — renewed campaign active

Fixed window 2026-10-13T21:37:33Z to 2026-10-14T21:37:33Z; never extend.
Checkpoint {now}. STATE.yaml and this file are the sole operational checkpoint.
Heartbeat toe-physical-realization-renewed-24-hour-campaign remains active.

Active science worktree {CW}; branch physics-loop/toe-energy-tail-20261013,
clean HEAD ccbeddd0c04b70ee2b6c5f1cffeeeefa23df2989, regular OPEN PR9526,
base branch physics-loop/toe-multitime-kinetic-energy-20261013 / PR9521 at e8d5b7b9.
Checkpoint worktree {W}, branch physics-loop/toe-nonlinear-transport-20261011.
Main583c699e and parent e8d5b7b9 were unchanged at the22:43 remote refresh.
Prior17 regular PRs remain as recorded. No merge/main push/audit verdict.

Evidence root {Z}. Tail publication v2 freeze c92f7441, canonical note dc651056,
root review f5e81785 and acceptance3e0a3670. Runtime prepare223622 and verify224113
passed exact source/staging checks, graph +1 node/+2 edges. Identity655inputs and
four exact corruption controls are zero-math checks; focused ledger checked=[].
Mathematical cores and prior scoped analytic checks are unchanged. PR9526 created
22:43 and attached. Full receipt ENERGY_TAIL_PR_CREATED.json. Prior missing-citation
failure and root PLACEHOLDER invocation are preserved; neither is a math failure.

Calibration source assembly281a36b1 and root review4e143d35 remain accepted.
Publication folder graph_calibration_publication_preparation has corrected title
and citation guard but no final freeze. Worker threshold_protocol_fresh received
actual tail PR9526/head and note hash; resume its actual-parent binding once a slot
frees. Root owns final source review, branch, canonical prepare/stage/verify and PR.
Common H, uniform graph resources and finite protocol assumptions remain explicit.
Lean bbcb658c proves only the scalar cutoff implication; no full operator Lean proof.

Physical root candidate coarse_energy_instrument_root/DERIVATION.md aa834948,
sealed22:34:51 before independent target findings. Compute/copy/uncompute preserves
within-bin coherence and reference correlations; proposed weighted instrument bound
uses phase-error, boundary mass and first-energy tail. Conditional local compiler
prices product-formula and coherent-bus resources. Auxiliary routing, native controls,
preparation, autonomous energy accounting and finite-volume interface remain open.
Finite floating controls12192909 ran1.440s, exit0, including fine-archive error1,
alias and boundary controls. Independent derivation and exposed compiler review are
active; do not label this candidate accepted or physically realized yet.

SOURCE RECONCILIATION: the supplied infinite chain ALREADY has exact energy-adapted
J_a and positive Fock lift I_a, H I_a=I_a H_a, energy-PVM intertwining and common
supplied vacuum. ENERGY_ADAPTED_REFINEMENT note e8b34ef4 read fully; necessary
CALIBRATED_ENERGY_TRANSFER note1f71af03 passages read. The earlier checkpoint's broad
missing-common-H language was too weakly informed. Its nonlocal finite-a map leaves
quantitative locality and finite-apparatus/volume obligations. Do not duplicate the
existing bridge. Survey worker completes precise source applicability report.

Next: calibration publication while physical checks complete; read complete new
arguments and actual evidence, preserve failures, then attack finite apparatus gaps.
Lock owner codex-toe-native-20261013 expires23:41:58UTC; refresh by23:30UTC.
No drafts, axiom/prompt edits, science merges, audit verdicts or other-chat messages.
At fixed deadline start no research; checkpoint, release owned lock and delete heartbeat.
Fresh recovery bundle {bundle}, roundtrip verified; published tail branch is remote.
''')
(P/'OPPORTUNITY_QUEUE.md').write_text('''# Current ranked queue

1. Finish regular epsilon=o(h) calibration PR, bound to published tail PR9526.
2. Check the full coarse common-H energy instrument and conditional finite local
   compiler against independent derivation and exposed decisive controls.
3. Connect finite apparatus/volume to the existing exact supplied infinite-chain
   energy-adapted Fock embedding. Quantify locality, preparation and resources.
4. Native three-dimensional realization, interacting channels and rate selection;
   reopen only a concrete source-grounded target, preserving supplied assumptions.
5. Threshold finite-protocol source remains accepted and unpublished if needed.

Tail regular PR9526 is complete. Existing infinite-chain energy/PVM intertwining
is prior art, not a new gap. Local blockers do not exhaust the queue.
Fixed deadline2026-10-14T21:37:33Z; no automatic extension.
''')
with (P/'REVIEW_HISTORY.md').open('a') as f:
    f.write(f'\n{now}: Regular tail PR9526 published and attached; exact runtime source/graph checks, no new retained status. Calibration binding pending slot. Root full-instrument candidate sealed with finite controls; independent checks active. Existing exact infinite-chain energy/Fock bridge source reconciliation narrows the next gap to finite apparatus/locality.\n')
print(json.dumps({'checkpoint_utc':now,'science_head':state['active_head'],'pr':9526,'archive_members':len(manifest),'archive_sha256':sha(bundle),'archive_bytes':bundle.stat().st_size},indent=2))
