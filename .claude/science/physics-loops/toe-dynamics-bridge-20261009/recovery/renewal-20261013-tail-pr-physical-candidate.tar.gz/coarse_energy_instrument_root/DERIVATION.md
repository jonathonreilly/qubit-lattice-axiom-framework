# Coarse energy instruments from finite coherent phase registers

Root proposed conditional derivation. No independent target findings have been
received. This is an intermediate apparatus module and a finite local-spin
compiler, not a derivation of a native physical model or an audit verdict.
Standard phase estimation, pointer dilation, coherent uncomputation and product
formulas are prior machinery. The claim being checked is their quantitative
composition with this repository's finite-first-energy protocol requirements.

## 1. Supplied model and the full instrument

Let H>=0 be self-adjoint on a separable Hilbert space, G=1+H and S=G^(1/2).
Fix finitely many internal boundaries 0<b_1<...<b_(q-1)<infinity and the
half-open interval partition I_0=[0,b_1), ..., I_(q-1)=[b_(q-1),infinity).
Write z(E) for the bin containing E and P_z=1_(I_z)(H). The ideal instrument is

    L(rho) = sum_z P_z rho P_z tensor |z><z|.

Its coherent dilation W is W psi=sum_z P_z psi tensor |0>_F tensor |z>_Z.
The fine register F in this expression is blank. A passive reference is allowed
throughout; all operators on the reference are identities. Initial rho is
positive trace class, possibly subnormalized, with M_rho=Tr(G rho)<infinity.
Energy here is the supplied H, not an unidentified physical observable.

## 2. A finite unitary construction

Take M=2^m, a period Lambda>0 and tau=2*pi/Lambda. The fine register has M
basis states. Its Fourier transform has entries exp(2*pi*i*y*n/M)/sqrt(M).
Let B be the tensor product of m Hadamards. Define

    D = sum_(n=0)^(M-1) exp(i*n*tau*H) tensor |n><n|,
    Q = (1 tensor F_M^*) D (1 tensor B).

These are bounded unitaries even for unbounded H, by spectral calculus. For a
spectral energy E, Q_E|0> has amplitudes

    a_y(E) = M^(-1) sum_(n=0)^(M-1)
                 exp(2*pi*i*n*(E/Lambda-y/M)).                    (2.1)

Choose the signed representative s_y in [-Lambda/2,Lambda/2) of Lambda*y/M,
and set e_y=max(0,s_y). Let C XOR the r=ceil(log_2 q)-bit representation of
z(e_y) into the coarse register, controlled by y. Empty extra coarse codes
are unused. For q=1 one may omit the coarse register and the entire readout.
The implemented isometry, including its residual fine workspace, is

    V psi = Q^* C Q (psi tensor |0>_F tensor |0>_Z).             (2.2)

The implemented instrument A traces F and dephases Z. It does not measure or
archive y before uncomputation. In general F is not exactly blank afterwards;
it must be kept or discarded and a fresh blank F supplied at the next readout.

Every factor commutes with spectral projections of H on the system. Thus V
and W intertwine every bounded spectral function and G or S on its domain:

    (S tensor 1)V=VS,  (S tensor 1)W=WS.                       (2.3)

In particular both dilations preserve the system energy distribution when
the readout is nonselective. This is a statement about system energy in the
supplied model, not total apparatus energy conservation.

## 3. Exact error identity and phase resolution

For each E, apply the unitary Q_E to both terms of V_E-W_E. The difference
becomes C(Q_E|0> tensor |0>)-Q_E|0> tensor |z(E)>. Fine labels y are orthogonal;
for a wrong coarse label the two coarse basis vectors have squared distance2.
Consequently

    ||V_E-W_E||^2 = 2 p(E),
    p(E)=sum_{y:z(e_y)!=z(E)} |a_y(E)|^2.                      (3.1)

There is no factor equal to the number of energies or coarse bins. In
particular fine energies within one coarse bin can retain their coherence.

For circular phase distance d_y in [0,1/2] from E/Lambda to y/M, the geometric
sum gives |a_y(E)|<=1/(M |sin(pi*d_y)|)<=1/(2*M*d_y) when d_y>0.
Fix delta>0, K>=0, Lambda>2(K+delta), and a=M*delta/Lambda>1. For 0<=E<=K
at distance greater than delta from every internal boundary, any circular
estimate within delta in energy has a signed representative within delta
of E. Clamping a negative estimate to zero cannot increase its distance from
E. Such an estimate has the correct bin. Hence wrong labels require
d_y>=delta/Lambda.

The scaled signed distances x=M*d_y lie on the two rays of a unit-spaced
shifted integer lattice, with absolute value at least a. On each ray their
inverse-square sum is at most 1/a^2+integral_a^infinity x^(-2)dx, which is at
most 1/(a-1). The finite circular set is a subset of these two rays; a tie at
the antipode can only reduce its cardinality. Therefore

    p(E) <= eta := min(1, 1/[2(a-1)])                         (3.2)

on the good energy set. The exact-grid case follows directly from (2.1).
For all other E use p(E)<=1. This loose bound is sufficient; no optimal
phase-estimation constant is claimed.

## 4. Trace norm, reference systems and energy weights

Let mu_rho(B)=Tr(rho 1_B(H)), including the identity on any passive reference.
Let mu_G,rho(B)=Tr(G rho 1_B(H)) and B_delta be the delta-neighborhood of the
finite internal boundary set, intersected with [0,infinity). Define

    t_K = mu_G,rho((K,infinity)),
    b_delta = mu_G,rho(B_delta),
    R = eta M_rho + b_delta + t_K.

Equation(3.1), spectral calculus and Hilbert-Schmidt integration give

    ||(S tensor 1)(V-W)rho^(1/2)||_2^2
       = 2 integral (1+E)p(E) dmu_rho(E) <= 2R.               (4.1)

For any two Hilbert-Schmidt operators X,Y,
||XX^*-YY^*||_1 <= (||X||_2+||Y||_2)||X-Y||_2, by expanding the
difference into (X-Y)X^*+Y(X^*-Y^*). Set X=(S tensor 1)V rho^(1/2)
and Y=(S tensor 1)W rho^(1/2). Equation(2.3) gives both norms sqrt(M_rho).
Taking the partial trace of F and dephasing Z are trace-norm contractions on
Hermitian trace-class operators and commute with the system weighting. Thus

    ||(S tensor 1)(A-L)(rho)(S tensor 1)||_1
       <= 2 sqrt(2 M_rho R).                                (4.2)

All identities are justified first by bounded energy cutoffs, or equivalently
by the trace-class input S rho S and the bounded intertwining maps V and W;
then monotone/Hilbert-Schmidt convergence removes the cutoff. No second
moment, density of spectral eigenvectors or finite-rank energy cutoff is used.
The same proof is unchanged with an arbitrary passive reference and with
previous classical history registers retained. This is an energy-constrained
reference-stable bound, not an unconstrained diamond-norm assertion.

Dropping S gives the analogous unweighted estimate with Tr(rho), ordinary
boundary mass and ordinary cutoff mass. The weighted bound also bounds the
trace-norm error, each branch probability error and each branch first-energy
error, since ||S^(-1)||<=1 and ||H G^(-1)||<=1. For a fixed state, t_K->0 as
K->infinity. If mu_rho has no atom at each internal boundary, b_delta->0 as
delta decreases to zero: these boundaries are finite energies, so the weight
is locally bounded. Hence choosing K->infinity, delta->0,
Lambda>2(K+delta), and M*delta/Lambda->infinity proves convergence in(4.2).
No explicit rate for the state's tail or boundary mass has been assumed.

## 5. Families and finite histories

For a parameter family rho_alpha the sufficient uniform/joint conditions are

    sup_alpha M_rho_alpha < infinity,
    lim_(K->infinity) limsup_(alpha->limit) t_(alpha,K)=0,
    lim_(delta->0) limsup_(alpha->limit) b_(alpha,delta)=0.     (5.1)

Any K_alpha->infinity and delta_alpha->0 then make those terms vanish,
by monotonicity and comparison to fixed K and delta. Take the phase
resolution eta_alpha->0 as well. Uniform conclusions on a whole resource
set replace limsup_alpha by its supremum. Bounded first moments alone do
not imply the tail condition. Boundary regularity of a weak limiting energy
law implies the last condition at the finitely many finite boundaries, with
the weight bounded on their neighborhoods.

For a fixed n readouts, place supplied unitary drives U_j between them.
Assume ||S U_j S^(-1)||<=L_j with the stated common energy. The weighted
conjugate of a drive is X -> B_j X B_j^*, of trace-norm norm at most L_j^2.
Both ideal and phase-register readouts have weighted conjugates that are
trace-preserving CP maps, by(2.3); their norm on Hermitian inputs is at most1.

Telescoping the channel products with an ideal prefix and actual suffix
therefore bounds the weighted error of the entire classical-history/system
output by the sum, over j, of the single-readout bound(4.2) evaluated at the
ideal pre-readout state sigma_j, multiplied by the product of L_k^2 for all
subsequent drives. Prior classical records are passive references at that
step. There is no demand to reset correlated fine registers: allocate a fresh
one at every readout. The graph and tail hypotheses are those of the ideal
pre-readout family, whose conditional branches are summed as positive
subnormalized states; finite n and finitely many bins keep that sum finite.

The repository's accepted energy-tail theorem can supply the joint tail
condition for those states only when its actual two-sided G graph bounds and
fixed finite protocol premises hold. Its finite-history weak-law premise
can supply boundary regularity only at boundaries regular for the relevant
pre-readout limiting marginal. These are explicit applications, not facts
obtained from the register construction. Conditional branch conclusions
require a limiting branch probability bounded away from zero. The present
proof compares instruments; combining it with an ideal weak-law/first-moment
limit transfers that limit, and hence W1 when the respective probability
measures have the required weak convergence and moment convergence.

## 6. Decisive controls and limits of the claim

Fine archive: take distinct exact phase-grid energies E_0,E_1 in the same
bin, an energy E_2 outside, and (|E_0>+|E_1>)/sqrt(2). The correct ideal
coarse branch leaves this pure superposition unchanged. Measuring/retaining
a fine energy label and forgetting it dephases that superposition, with
trace-norm error1. The Bell-correlated version with a passive reference has
the same error. Equation(2.2) restores the blank fine register for those
exact-grid inputs and preserves this coherence. A coarse pointer alone is
therefore insufficient evidence of the full intended instrument.

Boundary atom: choose a boundary b=1, period Lambda=3, and the exact energy
E=1, assigned to the upper bin. For dyadic M, M/3 has fractional part r=1/3
or2/3. The closest lower grid point has wrong label, and its probability is
sin^2(pi*r)/(M^2 sin^2(pi*r/M)) >= 27/(16*pi^2). Thus this construction need
not converge on boundary atoms. This is a counterexample to a regularity-free
claim, not necessity of regularity for every possible apparatus or sequence.

Phase alias: energies0 and Lambda have identical Q_E. If their desired bins
differ, a fixed period cannot distinguish them, for any M. The growing
cutoff/period hypothesis removes this obstruction on the controlled family.

Weak-only control: states(1-1/N)|0><0|+(1/N)|N><N| converge in trace norm to
vacuum, yet their first energies stay1. This violates uniform first-energy
tails, so an unweighted instrument estimate cannot replace(4.2).

## 7. Explicit ideal-oracle resource accounting

Binary control implements D with m controlled evolutions exp(i*t_j*H),
t_j=tau*2^j. Q^* requires their inverses in the reversed circuit. Total
absolute oracle evolution time is2*tau*(M-1); the longest query is
tau*M/2. Both signs and controlled access to the actual H are supplied
resources. There are two Fourier transforms and2m Hadamards in V.

A finite exact lookup is available without assuming a black-box bin gate.
For each y, temporarily flip fine bits whose target pattern is zero,
compute their AND into m-1 clean scratch bits by an explicit Toffoli chain,
CNOT that AND into each coarse bit of z(e_y), uncompute the chain, and undo
the pattern flips. This costs at most M[2(m-1) Toffolis+r CNOTs+2m X gates]
for m>=2, with m-1 scratch bits. Scratch returns exactly blank. This bound
is intentionally coarse. The assumed condition M*delta/Lambda>1 together
with Lambda>2*delta ensures M>=4. Boundaries determine a finite lookup table;
their mathematical specification and exact gate-angle access are inputs.

Each readout uses m fine bits plus r output bits and the reusable lookup
scratch. A finite history reserves n fresh fine registers and n coarse
records, or supplies a priced reset mechanism. This derivation supplies
no free erasure, finite-temperature preparation theorem, autonomous clock,
permanent macroscopic record or resource bound uniform as accuracy grows.

## 8. Conditional local compiler for a bounded finite spin Hamiltonian

This section changes to a FINITE supplied system. Let

    H_N=c*1+sum_(l=1)^L h_l >=0,
    B_N=|c|+sum_l ||h_l||,
    C_N=sum_(l<k)||[h_l,h_k]||.

Each h_l has a specified bounded-arity, bounded-range support in a finite
connected geometry. Assume individually switchable signed local term gates,
local controlled versions of them with one nearby auxiliary bit, and a
connected auxiliary bus with a bit near every term. Also assume local
auxiliary one-, two- and three-bit gates. These are explicit control and
geometry hypotheses. H_N is not identified with the preceding unbounded H.

For two bounded self-adjoint terms A,B, Duhamel comparison of
exp(i*t*(A+B)) and exp(i*t*A)exp(i*t*B) bounds their difference by
t^2||[A,B]||/2: differentiate the product in the joint interaction picture,
write the conjugation difference of B as the integral of the conjugated
commutator, and use unitary invariance of norm. Induction over the terms
and telescoping r substeps then gives

    ||exp(i*t*sum_l h_l) - (prod_l exp(i*t*h_l/r))^r||
        <= t^2 C_N/(2r).                                    (8.1)

The scalar c phase is implemented exactly on the controlling bit. A
controlled operator has the same error as its active block. If the j-th
query uses r_j substeps, the error of the Q circuit is at most
sum_j t_j^2 C_N/(2r_j). Choose the inverse approximate Q circuit exactly as
the inverse gate list; then the full V circuit error is at most twice this
sum. No cancellation of its noncommuting term errors is assumed.

Writing S_N=sqrt(1+H_N), ||S_N|| ||S_N^(-1)||<=sqrt(1+B_N).
An unweighted isometry error u therefore gives graph-half error

    d = ||(S_N tensor 1)(V_tilde-V) S_N^(-1)||
      <= sqrt(1+B_N)*u.                                     (8.2)

The ideal V graph-half norm is1. The actual graph-half norm is at most1+d,
so the weighted output error on rho is at most(2+d)d M_rho, by the same
Hilbert-Schmidt factorization as in section4. Its weighted CP-map norm is
at most(1+d)^2, available in the finite-history telescope. The compiled
apparatus can change system energy; exact energy preservation is asserted
only for the ideal oracle circuit. For a desired d<=zeta>0 it suffices to use

    r_j=max(1,ceil(m*C_N*t_j^2*sqrt(1+B_N)/zeta)).             (8.3)

If C_N=0 the local product is exact. Otherwise each query contributes at
most zeta/[2m sqrt(1+B_N)] to the Q error. The term-gate count for Q and its
inverse is2L sum_j r_j, with

    sum_j r_j <= m + m*C_N*sqrt(1+B_N)*tau^2*(M^2-1)/(3zeta).

To implement a controlled product locally, fan out the computational basis
of its fine control bit along a spanning tree of the bus using CNOTs, apply
each local term controlled by its nearby bus bit, and reverse the fanout.
This is a coherent GHZ control encoding, not cloning an arbitrary state.
The term gates never change bus bits. In both control branches the inverse
fanout restores the bus exactly, even when the fine control was entangled
with the system. With V_bus bus vertices including the controlling root,
each query uses2(V_bus-1) fanout/unfanout CNOTs. Q and its inverse use
4m(V_bus-1) such gates. Depth depends on the spanning-tree height and the
specified term schedule; no finite-speed independent-of-size claim is made.

The auxiliary QFT and lookup gates also require routing if their operands
are not adjacent. They can be routed by explicit swaps on a connected
finite auxiliary graph, applying the gate on an adjacent patch and undoing
the permutation. Such a compilation has finite size-dependent overhead;
an exact routed count requires the chosen graph and is an open implementation
deliverable. The quoted logical gate counts exclude this routing overhead.
No global gate is declared local merely by writing it in a circuit.

This compiler requires additional spatial sites, blank pure auxiliaries,
signed switching, gate precision and an externally supplied timing schedule.
It prices oracle replacement and logical controls, but does not furnish a
closed autonomous energy ledger. A native single-qubit-per-site theory must
supply a compatible enlarged geometry and all those physical resources.
As N and continuum resolution change, B_N,C_N, bus size and required gate
precision can diverge. Equations(8.1)-(8.3) expose that cost rather than
asserting uniformity. A calibrated identification of finite H_N, its prepared
state and these instruments with the common continuum H remains unproved;
the existing even-algebra embedding alone is insufficient for it.

## 9. Proposed scope

Sections1–5 propose a finite-first-energy approximation of the full coarse
instrument, stable with a passive reference and composable on fixed finite
histories under explicit tail, boundary and graph assumptions. Section8
proposes a conditional local finite-system implementation with stated
size/accuracy costs. Neither establishes the actual continuum physical
energy instrument, autonomous apparatus, native symmetries, interacting
channel selection or empirical validity. These remain named constructive
obligations. Independent derivation, decisive controls and review are pending.
