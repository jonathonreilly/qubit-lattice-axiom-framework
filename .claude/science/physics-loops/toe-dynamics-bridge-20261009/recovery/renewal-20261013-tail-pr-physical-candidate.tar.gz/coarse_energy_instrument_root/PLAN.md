# Root plan: finite coarse energy instrument

Status: pre-derivation plan after disclosed orientation reasoning, not a proof acceptance. Root reasoned informally about compute/coarse-copy/uncompute, pointwise phase-estimation error, spectral energy weights and a finite local controlled-product compiler before sealing this plan. These formulas have not been shown to the independently assigned worker. Same selected model family; no model-diverse independence claim.

Target: H>=0 self-adjoint on a supplied common system Hilbert space. Fixed finite Borel interval partition of [0,infinity), internal boundaries regular for the relevant energy measures. Compare full quantum-to-classical branch maps to P_z rho P_z, preserving within-bin coherence and a passive reference. Initial Tr((1+H)rho) finite. No physical axiom, native model selection, Record occurrence or Born derivation.

Plan:
1. Specify finite phase register M=2^m, period Lambda, signed energy estimator with negative estimates clamped to zero, coarse output register and reversible bin lookup. Prove the spectral-fiber isometry formula for compute/copy/uncompute. Check exact maps in a finite three-level fixture with two distinct energies inside one bin, with reference entanglement. Preserve comparison to the fine-label archive.
2. Derive a finite-grid Dirichlet-tail bound with all constants and phase-wrap margins checked. Split errors into phase resolution, cutoff tails and boundary mass, including the weighted measure (1+E)Tr(rho dP_E). Determine exact graph intertwining, trace-norm and weighted trace-norm claims from the constructed isometry. No operator-norm convergence claim at discontinuous bin boundaries.
3. Extend to a fixed finite history using CP-map telescoping and stated graph bounds for intervening drives. State required joint limit/uniform boundary and tail hypotheses explicitly; do not infer uniformity from finite first energy balls.
4. Price forward and inverse oracle evolution times, blank registers, finite lookup and QFT operations. Treat the supplied global energy oracle only as an intermediate module.
5. If the first four steps survive, give a conditional finite local-spin implementation using a connected auxiliary control bus, local term gates and controlled product formulas. Price size/time/accuracy dependence. Keep finite H_N versus unbounded common H and vacuum-representation bridges separate; do not assume the local-even algebra embedding identifies energies or states.

Verification: exact finite matrix/isometry comparisons plus an independently authored derivation; targeted countercontrols for fine readout, boundary atoms, phase alias and weak-only energy control. Standard phase estimation, pointer dilation, coherent uncompute and product formulas are prior machinery, not claimed inventions. Scope novelty, if any, is the checked composition needed by this repo's conditional finite-energy protocol.

Source identities: target contract636c4f620a9bf590bf47ea2e60586c7a9c2b419720c620aee18779f7da55f63f; multitime note b782e4814730e330c1a3d0452382dc488caa2e920b7e544e43cba84ef12279af; local-even note b5a8394a9d8c17bb9559597a68b061ad3872201ebf9793bd5c9f10b15ac2c6aa. Prior literature Nakayama/Soeda/Murao arXiv1310.3047v2 phase estimation pages5–7 read; universal controllization not adopted. Root source-reading ledger has further exact scopes.

No scripts or analytic claims are accepted merely by this plan. Fixed campaign deadline2026-10-14T21:37:33Z.
