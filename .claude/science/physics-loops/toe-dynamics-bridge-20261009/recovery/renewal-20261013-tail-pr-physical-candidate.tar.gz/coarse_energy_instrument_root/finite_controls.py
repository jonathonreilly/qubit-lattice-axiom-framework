"""Finite matrix controls for the proposed instrument; not an infinite proof."""
import json
import math
import numpy as np
from scipy.linalg import expm, hadamard

TOL = 2e-10
def op(a):
    return float(np.linalg.norm(a, 2))
def tn(a):
    return float(np.linalg.svd(a, compute_uv=False).sum())
def fourier(M):
    j = np.arange(M)
    return np.exp(2j*np.pi*np.outer(j,j)/M)/np.sqrt(M)
def labels(M, period, boundary):
    e = np.arange(M)*period/M
    e = np.where(e >= period/2, e-period, e)
    return (np.maximum(0,e) >= boundary).astype(int)
def copy_gate(lab):
    M = len(lab)
    C = np.zeros((2*M,2*M),complex)
    for y,z in enumerate(lab):
        for k in range(2): C[2*y+(k^int(z)),2*y+k] = 1
    return C
def fiber(E,M,period,boundary,uncompute=True):
    F = fourier(M)
    B = hadamard(M)/np.sqrt(M)
    Q = F.conj().T @ (np.exp(2j*np.pi*E*np.arange(M)/period)[:,None]*B)
    v = np.zeros(2*M,complex); v[0] = 1
    qbig = np.kron(Q,np.eye(2))
    v = copy_gate(labels(M,period,boundary)) @ qbig @ v
    if uncompute: v = qbig.conj().T @ v
    w = np.zeros_like(v); w[int(E>=boundary)] = 1
    prob = np.abs(Q[:,0])**2
    wrong = float(prob[labels(M,period,boundary)!=int(E>=boundary)].sum())
    return v.reshape(M,2),w.reshape(M,2),wrong
def cq_outputs(fibers,coeff):
    # coeff[i,r] is a pure system/reference input, no spectral error formula used.
    d,M,q = fibers.shape; r = coeff.shape[1]
    outputs=[]
    for z in range(q):
        amps = (fibers[:,:,z][:,None,:]*coeff[:,:,None]).reshape(d*r,M)
        outputs.append(amps @ amps.conj().T)
    return outputs
def weighted_cq_error(a,b,energies,r):
    S=np.diag(np.repeat(np.sqrt(1+np.asarray(energies)),r))
    return sum(tn(S@(x-y)@S) for x,y in zip(a,b))

result={'scope':'Finite floating-point controls only; no infinite-dimensional, continuum or native-physical proof.',
        'tolerance':TOL,'instrument_cases':[]}
coeff=np.zeros((3,3),complex);coeff[0,0]=1/np.sqrt(2);coeff[1,1]=1/np.sqrt(2)
energies=[0.,1.,3.]
v,w,fine=[],[],[]
for E in energies:
    vi,wi,p=fiber(E,8,8.,2.);v.append(vi);w.append(wi)
    fi,_,_=fiber(E,8,8.,2.,False);fine.append(fi)
ideal=cq_outputs(np.array(w),coeff)
exact=cq_outputs(np.array(v),coeff);archive=cq_outputs(np.array(fine),coeff)
exact_error=sum(tn(a-b) for a,b in zip(exact,ideal))
archive_error=sum(tn(a-b) for a,b in zip(archive,ideal))
assert exact_error<TOL and abs(archive_error-1)<TOL
result['exact_grid_reference']={'coherent_instrument_trace_error':exact_error,
    'fine_archive_trace_error':archive_error,'system_energies':energies,'boundary':2.}

energies=np.array([.37,1.11,3.23]);period=10.;boundary=2.;delta=.4;K=3.5
coeff=np.array([[.4,.2j,0],[.1,.7,0],[.2j,.1,.3]],complex);coeff/=np.linalg.norm(coeff)
weights=np.sum(abs(coeff)**2,axis=1);mass=float(np.dot(1+energies,weights))
for M in (32,64,128):
    vs=[];ws=[];ps=[]
    for E in energies:
        v,w,p=fiber(E,M,period,boundary);vs.append(v);ws.append(w);ps.append(p)
        assert abs(np.vdot(v-w,v-w).real-2*p)<TOL
    vs=np.array(vs);ws=np.array(ws);ps=np.array(ps)
    assert period>2*(K+delta) and M*delta/period>1
    eta=min(1.,1/(2*(M*delta/period-1)))
    assert np.max(ps)<=eta+TOL
    measured=weighted_cq_error(cq_outputs(vs,coeff),cq_outputs(ws,coeff),energies,3)
    exact_rhs=2*np.sqrt(2*mass*np.dot((1+energies)*weights,ps))
    coarse_rhs=2*np.sqrt(2*mass*eta*mass)
    assert measured<=exact_rhs+TOL and exact_rhs<=coarse_rhs+TOL
    result['instrument_cases'].append({'M':M,'wrong_probabilities':ps.tolist(),
        'weighted_cq_error':measured,'fiber_bound':float(exact_rhs),'resolution_bound':float(coarse_rhs)})

# Direct Fourier amplitudes over a dense grid, distinct from the error formula.
tail_rows=[]
for M,delta in [(64,.4),(128,.2),(256,.1)]:
    eta=1/(2*(M*delta/period-1));worst=0.;count=0
    for E in np.linspace(0,3.5,701):
        if abs(E-boundary)<=delta: continue
        amplitude=np.fft.fft(np.exp(2j*np.pi*np.arange(M)*E/period))/M
        p=float((abs(amplitude)**2)[labels(M,period,boundary)!=int(E>=boundary)].sum())
        assert p<=eta+TOL
        worst=max(worst,p);count+=1
    tail_rows.append({'M':M,'delta':delta,'good_energies_checked':count,'worst_wrong_probability':worst,'bound':eta})
result['resolution_controls']=tail_rows
boundary_rows=[]
for M in [4,8,16,32,64,128,256,512,1024]:
    amp=np.fft.fft(np.exp(2j*np.pi*np.arange(M)/3))/M
    y=M//3;p=float(abs(amp[y])**2)
    assert labels(M,3.,1.)[y]==0 and p>=27/(16*np.pi**2)-TOL
    boundary_rows.append({'M':M,'lower_point_probability':p})
result['boundary_atom_counterexample']=boundary_rows
amp0=np.fft.fft(np.ones(32))/32
amp_alias=np.fft.fft(np.exp(2j*np.pi*np.arange(32)))/32
assert np.linalg.norm(amp0-amp_alias)<TOL
result['phase_alias_amplitude_error']=float(np.linalg.norm(amp0-amp_alias))
result['weak_only_energy_control']=[{'N':N,'trace_distance_to_vacuum':2/N,'first_energy':1.} for N in [10,100,1000]]

# Finite noncommuting local spin replacement, using full operator matrices.
I=np.eye(2);X=np.array([[0,1],[1,0]],complex);Z=np.diag([1,-1])
terms=[.7*np.kron(X,I),.6*np.kron(Z,Z),.5*np.kron(I,X)]
H=4*np.eye(4)+sum(terms);ev,R=np.linalg.eigh(H)
S=(R*np.sqrt(1+ev))@R.conj().T;Sinv=(R/np.sqrt(1+ev))@R.conj().T
BN=4+sum(op(t) for t in terms)
CN=sum(op(a@b-b@a) for i,a in enumerate(terms) for b in terms[i+1:])
M=8;m=3;period=18.;tau=2*np.pi/period;zeta=.4
D=np.eye(4*M,dtype=complex);Da=D.copy();rows=[]
for j in range(m):
    t=tau*2**j;n=max(1,math.ceil(m*CN*t*t*np.sqrt(1+BN)/zeta))
    step=np.eye(4,dtype=complex)
    for h in terms:step=expm(1j*t*h/n)@step
    U=np.exp(4j*t)*np.linalg.matrix_power(step,n);exactU=expm(1j*t*H)
    err=op(U-exactU);bound=t*t*CN/(2*n);assert err<=bound+TOL
    on=np.diag([int((y>>j)&1) for y in range(M)]);off=np.eye(M)-on
    Da=(np.kron(U,on)+np.kron(np.eye(4),off))@Da
    D=(np.kron(exactU,on)+np.kron(np.eye(4),off))@D
    rows.append({'query':j,'time':t,'substeps':n,'operator_error':err,'product_bound':bound})
F=fourier(M);B=hadamard(M)/np.sqrt(M)
Q=np.kron(np.eye(4),F.conj().T)@D@np.kron(np.eye(4),B)
Qa=np.kron(np.eye(4),F.conj().T)@Da@np.kron(np.eye(4),B)
C=np.kron(np.eye(4),copy_gate(labels(M,period,4.)))
big=np.kron(Q,np.eye(2));biga=np.kron(Qa,np.eye(2))
cols=np.arange(4)*M*2
V=(big.conj().T@C@big)[:,cols];Va=(biga.conj().T@C@biga)[:,cols]
u=op(Va-V);d=op(np.kron(S,np.eye(2*M))@(Va-V)@Sinv)
assert u<=2*sum(r['product_bound'] for r in rows)+TOL
assert d<=np.sqrt(1+BN)*u+TOL and d<=zeta+TOL
assert op(np.kron(S,np.eye(2*M))@Va@Sinv)<=1+d+TOL
result['local_product_compiler']={'BN':BN,'CN':CN,'query_controls':rows,
    'full_isometry_operator_error':u,'half_graph_error':d,'requested_half_graph_bound':zeta}

# Coherent bus: root control0, bus1/2, system3/4. All input columns checked.
def ctrl_on_system(control,U):
    out=np.zeros((32,32),complex)
    for col in range(32):
        if not ((col>>(4-control))&1):out[col,col]=1;continue
        sy=col&3;base=col&~3
        for target in range(4):out[base+target,col]=U[target,sy]
    return out
def cnot(control,target):
    a=np.zeros((32,32),complex)
    for x in range(32):
        y=x^(1<<(4-target)) if ((x>>(4-control))&1) else x
        a[y,x]=1
    return a
fan=cnot(1,2)@cnot(0,1)
U1=expm(.31j*terms[0]);U2=expm(.27j*terms[1])
physical=fan.conj().T@ctrl_on_system(2,U2)@ctrl_on_system(1,U1)@fan
ideal=ctrl_on_system(0,U2@U1)
inputs=np.array([16*c+s for c in range(2) for s in range(4)])
bus_error=op(physical[:,inputs]-ideal[:,inputs])
outside=np.array([x for x in range(32) if ((x>>2)&3)!=0])
bus_residual=op(physical[np.ix_(outside,inputs)])
assert bus_error<TOL and bus_residual<TOL
result['coherent_bus']={'complete_input_isometry_error':bus_error,'nonblank_bus_amplitude':bus_residual,'input_columns':len(inputs)}
print(json.dumps(result,indent=2))
