# Preserved static failures

`build_package_attempt_01` failed before executing any builder statement. Python
reported an unclosed outer dictionary at builder line 173. The missing closing
brace in the finite input-map construction was corrected. The exact attempted
source, serialized prelaunch bindings, empty stdout, complete traceback and
receipt remain in that attempt directory. All bound bytes and generation fields
were unchanged. This was a packaging syntax failure, not scientific evidence.

The second builder completed. During source review, ordinary indentation of
the historical module docstring was found to add spaces inside its multiline
string value. That changes a documentation AST constant even though it changes
no science. The builder now uses the exact string value's Python representation
when wrapping it. The second build's complete overlay, build result and text
diff are archived with its attempt before constructing the final third build.
This is a disclosed static adaptation correction, not a scientific run/failure.

