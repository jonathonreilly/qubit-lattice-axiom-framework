---
claim_type: bounded_theorem
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
trace_class: upstream_support
target_claim_id: product_seed_emitter_bounded_theorem_note_2026-10-17
target_blocker_text: "The supplied product-seed emitter has a sufficient onset of 10^36 and 5*10^37 clock sites in the published fixed-coupling weighted estimate. A larger coupling requires renewed complete normalization and output bounds."
source_of_blocker_text: user_goal
reachability_to_target: supports
artifact_role: theorem
next_trace_action: "Complete the separate family analytical review and root qualification, review the portable adaptation, then execute the frozen canonical runner and focused milestone checks. Shared integrated-main landing gates remain later obligations."
conditional_surface_status: "Supplied exact positive two-body ladder and square-loop emitter; 10^-12 <= kappa <= 10^-8, fixed sigma=10^-6 and L=12, clean source/clock vacuum, one excited emitter, static complex phase, arbitrary old/reference input. Fixed accuracy and actual profile for each apparatus."
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: "The unchanged author body proposes a complete-output parameter-family theorem with renewed spectral-mass, inverse, normalization, phase, localization and finite-horizon bounds. Its analytical review and qualification are pending."
source_science_acceptance_complete: false
wrapper_root_approval: pending_separate_transport_review
canonical_execution: pending_not_executed
publication: local_reviewable_draft_only
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# A coupling family for a supplied autonomous emitter

**Claim type:** proposed `bounded_theorem`. **Current status:** frozen author
candidate with separate analytical review and root qualification pending. This
local publication packet has not executed its canonical scientific runner.
It makes no independent, retained, merged or hardware-realization claim.

For the [product-seed emitter theorem](PRODUCT_SEED_EMITTER_BOUNDED_THEOREM_NOTE_2026-10-17.md),
the proposed family permits

\[
10^{-12}\le\kappa\le10^{-8},\qquad \sigma=10^{-6},\qquad L=12,
\]

with every other exact ladder coefficient, emitter energy and static loop phase
fixed. The full author argument is preserved byte for byte below. Its new
spectral-mass lower bound replaces a variance shortcut whose discarded-mass
upper bound becomes 1.28 at the larger coupling. That failed shortcut, the
wrong-sign arctan defect and the changed point-spectrum variance bound remain
in the source and evidence. They are not concealed by the improved estimate.

For each actual apparatus the statement uses its own normalized common envelope
\(f_\kappa\) and unit phase \(\rho_\kappa\). They are common to all four old
input columns at their respective total energies \(1+E(k)\) and \(3+E(k)\),
not a single waveform shared by different apparatuses. The literal operators are

\[
K=2I+Z_1Z_2,\qquad
W=\frac{(9+12i)I+(-16+12i)X_1X_2}{25}.
\]

Writing \(\iota x=x\otimes|00\rangle_{AB}\), the supplied initial isometry
is one excited emitter in product with the blank clock, source vacuum and
arbitrary old/reference input. The complete ideal output is

\[
\mathcal U_{{\rm id},\kappa}(t)x
=\zeta e^{-it(\nu+2\kappa)}
 \beta_{\kappa,t}\otimes\iota e^{-itK}Wx,
\qquad \zeta=-e^{-4ik_0}\alpha,
\]

with the emitter empty; \(\alpha\), \(\beta_{\kappa,t}\), and the positive-real
normalization convention are defined in the frozen body. Thus the old system
ages for the whole elapsed time, and the scalar from the positive vacancy
blocks is retained. The theorem does not assume that \(K\) commutes with the
interacting Hamiltonian. Every emitter, source and clock output, prompt and
returned component, closed tail and possible seed bound-state component is
included in the operator norm.

The proposed uniform conclusion is complete isometry error below 0.004 for
every \(t\ge T(\kappa)=10^6/\kappa^2\) on the infinite clock. A finite clock
with \(M=\lceil50T(\kappa)\rceil\) sites gives embedded error below 0.005 on
\([T,2T]\) only. These imply complete unhalved trace-norm errors below 0.008
and 0.01 respectively, including arbitrary passive references.

At \(\kappa=10^{-8}\), the sufficient onset is \(10^{22}\), with
\(5\times10^{23}\) clock sites and five additional qubits. These costs remain
enormous. Times are in the declared Hamiltonian units; physical seconds and
minimum resource costs are not identified. The positive residual allowance
\(1.76\times10^{-13}\) remains in the target comparison. No arbitrary-accuracy,
exact-calibration, capture/reset/reuse or finite-device all-future claim follows.

The added old-site incident norms are 1.993757127633340 and 1.198638631120596,
below two. The source loads are 20.332662089993454 and 17.078839343776311;
the two boundary loads are 8.015120691541701 and 6.730044773026091. The existing
old edge has norm three in addition. Each emitter attachment adds exactly
\(3\kappa\), and the emitter load is \(E_0+2\kappa\). The global incident cap
two is therefore not established. All preparation, vacuum, phase, coefficient
and positive-block supply assumptions remain explicit conditional resources.

## Source credit and scope

The exact parent is published proposal PR9664 at
`0f1022e03dbbed8085035f2a378be8ae1aca02e8`; it is not described as merged or
retained. Its weighted estimate at \(\kappa=10^{-12}\) has onset \(10^{36}\).
The separately qualified fixed-coupling position-moment refinement has onset
\(10^{30}\). Sections 7–8 of the present body re-establish the weighted and
actual-profile moment premises over the new coupling family. At the larger
coupling the eight-order improvement is relative to the same moment method;
the other six orders relative to PR9664 are credited to that earlier refinement.
No separate constant-only publication is proposed here.

The [fixed-coupling moment argument](../outputs/emitter_coupling_family_2026_10_17_inputs/frozen_family/inputs/moment.md.txt),
its [separate review](../outputs/emitter_coupling_family_2026_10_17_inputs/frozen_family/inputs/moment_review.md.txt),
[qualification](../outputs/emitter_coupling_family_2026_10_17_inputs/frozen_family/inputs/moment_qualification.md.txt)
and [acceptance](../outputs/emitter_coupling_family_2026_10_17_inputs/frozen_family/inputs/moment_acceptance.json)
are preserved as inherited evidence. Some of those historical files also
discuss a separately qualified joint coefficient box. That historical scope
does not extend this exact-ladder family. Calibration and joint static-box
conclusions are excluded from this publication's claimed scope.

The author previously developed the stationary ladder, reviewed generic and
installed arguments, and adapted the product-seed publication. The present
author calculation and packaging share that source exposure and model. Neither
the replay nor byte/AST equivalence establishes independence. The ongoing
separate family review, its eventual root decision, wrapper portability approval,
canonical execution and retained audit are distinct records; none is inferred
from the inherited fixed-parameter qualifications.

## Portable reproduction boundary

The proposed primary is
[scripts/emitter_coupling_family_2026_10_17.py](../scripts/emitter_coupling_family_2026_10_17.py).
It calls only the adapted family scalar-checking function. It neither imports
nor executes parent scientific programs. The copied `FrozenInputs` class comes
from the exact parent primary and accepts only the finite, hash-bound local
[input map](../outputs/emitter_coupling_family_2026_10_17_inputs/INPUT_MAP.json).
It has no historical absolute-path fallback.

The [source map](../outputs/emitter_coupling_family_2026_10_17_inputs/SOURCE_MAP.json)
accounts for every file of the frozen 45-file source packet. Eighteen exact
tracked parent files are reused at their existing paths; 27 remaining files,
including all failed-route and actual-run evidence, are preserved as bytes in
the new bundle. Historical receipts retain their original external path labels
and timestamps. Those labels are provenance, never canonical file lookups.
The full old source tree can be reconstructed from the finite map without
rewriting any historical manifest or receipt.

The [transport ledger](../outputs/emitter_coupling_family_2026_10_17_inputs/TRANSPORT_EDIT_LEDGER.json)
identifies every removal, read adaptation, metadata adjustment and returned
report. The scientific statement ASTs are preserved except for the explicitly
identified transport/actual-cap metadata nodes; no mathematical constant,
comparison, formula or assertion changes. The
[body map](../outputs/emitter_coupling_family_2026_10_17_inputs/PROOF_BODY_MAP.json)
pins the unchanged theorem bytes and their exact range in this note.

The proposed shared canonical caps are 20 CPU seconds and 30 external wall
seconds, one scalar function, no matrices, grid, quadrature, optimization or
dynamics. Historical author output remains historical evidence. No canonical
result or cache is supplied by this draft. The
[status record](../outputs/emitter_coupling_family_2026_10_17_inputs/PUBLICATION_STATUS.json)
and [reproduction plan](../outputs/emitter_coupling_family_2026_10_17_inputs/REPRODUCTION_PLAN.json)
separate the pending decisions and execution. Focused milestone checks precede
publication; conformance section 12 leaves the full shared integrated-main
landing gates for the later exact landing candidate.

## Unchanged author theorem body

The following 835-line source is embedded without edits. Its relative historical
path strings resolve through the source map above; its original pending labels
describe the author's freeze, not a subsequently invented acceptance. Wrapper
status and eventual review records must remain separate from these source bytes.

