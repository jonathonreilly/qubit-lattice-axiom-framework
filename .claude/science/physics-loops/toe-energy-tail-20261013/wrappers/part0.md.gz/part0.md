---
claim_id: postmeasurement_energy_tail_bounded_theorem_note_2026-10-13
claim_type: bounded_theorem
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
artifact_role: theorem
upstream_dependencies:
  - chirped_kinetic_energy_bounded_theorem_note_2026-10-13
  - multitime_kinetic_energy_bounded_theorem_note_2026-10-13
runner: scripts/energy_tail_identity_2026_10_13.py
bare_retained_allowed: false
audit_required_before_effective_retained: true
trace_class: upstream_support
target_claim_id: null
target_blocker_text: null
source_of_blocker_text: user_goal
reachability_to_target: supports
conditional_surface_status: Explicit supplied model and provisional normal-state weak-law dependency.
hypothetical_axiom_status: No physical axiom added.
admitted_observation_status: No empirical observation imported.
claim_type_reason: Analytic bounded theorem with unchanged checked cores and declared conditional dependencies.
next_trace_action: Root publication review and regular PR; independent audit remains separate.
---

# Finite-first-energy tails after bounded energy protocols

Claim type: bounded_theorem

This note separates a uniform energy-tail theorem from a limiting-law corollary.
The tail theorem assumes the explicit common-energy graph bounds below. The
normal-state law, means and Wasserstein corollary additionally assume the
reviewed prepared-state weak-law theorem archived in this packet. That theorem
is a supplied provisional scientific dependency; the canonical vacuum
multi-time parent does not establish it. Identity tools check bytes only.

This is upstream support for possible physical-realization work. No named
downstream physical consumer is yet established, so target claim and blocker
fields are null. The user requested this energy-tail publication milestone;
physical realization and independently retained status remain outside the
supplied-model theorem.

The mathematical cores below are the complete unchanged root306, independent390
and scoped countercontrol84. Their earlier acceptance is preserved with the
subsequent required J-type precision. There is no new independent derivation,
retained audit, physical realization or operator-domain formal certificate.

## Main theorem and exact quantifiers

Let H be a nonnegative self-adjoint free energy on the common Hilbert space and
A=1+H. Let Y and its inverse range over the permitted unitary segments, with
uniform bounds on A Y A^{-1} and A Y^{-1} A^{-1}. These are bounded extensions
of maps preserving D(H), with common constants over the stated parameter
resources. The corresponding half-graph bounds follow by interpolation.
Let P_j be spectral projections of this same H and let Q be any correctly
ordered finite product of these segments and projections, with a fixed upper
bound on the number of factors. Thus Q is a contraction, and A Q A^{-1} and
A^{1/2} Q A^{-1/2} have common bounds C_2 and C_1.

For every fixed normal density rho with Tr(H rho)<infinity, put
rho_K=P_K rho P_K with P_K=1_{[0,K]}(H), and

d_E(rho,sigma)=||A^{1/2}(rho-sigma)A^{1/2}||_1.

The cutoff argument in the complete cores proves, for R>0 and K>=0,

    Tr[H 1_(R,infinity)(H) Q rho Q*]
      <= C_1^2 d_E(rho,rho_K)
         + C_2^2 (1+K) Tr[A rho]/R.

Since d_E(rho,rho_K)->0, the left side tends to zero uniformly over the allowed
Q as R tends to infinity. Only finite initial first energy is required: no
second moment, Gaussianity, parity, purity or energy-diagonal assumption.
The uniform tail assertion itself permits arbitrary spectral bins under the
common graph bounds. Regular fixed boundaries enter the weak-law corollary.

For weighted-trace-compact families of initial states, the common initial-tail
modulus yields a uniform version. For varying rho_a with d_E(rho_a,rho)->0,
the conclusion is the limiting statement

    lim_(R->infinity) limsup_(joint (a,h)->0)
      Tr[H 1_(R,infinity)(H) Q_(a,h) rho_a Q_(a,h)*] = 0.

This does not assert a supremum over every point of an arbitrary fixed
punctured continuum neighborhood. Such a supremum requires compactness or a
uniform initial-tail modulus. Fixed rho ideal and actual families satisfying
the common graph bounds do have a genuine uniform tail bound.

## Conditional normal-state law, means and W1

For the supplied massive CAR model H=dGamma(E), E>=m>0, the accepted strict-gap
chirp estimates provide the weighted one-particle inputs used in root U1-U9 and
independent T1-T19 to obtain the required graph bounds. The fixed smooth slots,
real bounded-variation envelope resources, strict carrier gap, finite horizon
and small h are those of the archived accepted premises; none is broadened.

Assume additionally the normal-state finite-protocol weak-law theorem in the
full prepared root340 and independent512, with its state-specific boundary
criterion, common H, exact Lüders ordering and finite fixed protocol. Then the
UI theorem upgrades its unnormalized output energy laws to convergence of
first moments and, after normalization on an event with limiting probability
p>0, to W1 convergence and convergence of conditional means. Uniform conditional
statements need a uniform positive lower bound on event probabilities. The
limiting representation retains the shared initial energy variable X_0 and the
accepted marked compound-Poisson increments with the stated measurement
conditioning; independent fresh initial variables cannot be substituted.

This implication does not infer weak convergence from graph bounds. It does
not add a path-space law, growing protocol length, moving-boundary limit,
feedback control or a conclusion on vanishing-probability postselection.
The complete prepared arguments, comparison, acceptance and historical open-Q25
wording remain archived. The current theorem closes their tail obligation
separately, under the hypotheses stated here. Optional compact-preparation
composition remains conditional on its accepted weighted compactness premises.

## Actual-cell transfer retained at its accepted scale

Use the exact same H and Lüders instruments through the stated embedding. The
accepted comparison supplies the graph Duhamel argument under bounded
self-adjoint controls, bounded errors ||Delta V||<=d_0 epsilon, bounded
commutator errors ||[H,Delta V]||<=d_1 epsilon, and common commutator bounds
||[H,V]||, ||[H,V_a]||<=k, with the domain/measurability hypotheses in the cores.
For b<=A_0 tau/h it gives graph error bounded by

    epsilon [(d_0+d_1)b + d_0 k b^2].

Thus epsilon=o(h^2) supplies this packet's actual-cell transfer. The independent
proof's original extra-graph reservation is resolved by the compared root
argument at precisely these hypotheses. Calibration, embedding, common H and
instruments remain assumptions. No later relative-graph sharpening or threshold
composition is imported into this publication.

## Required precision and preserved controls

Independent390 lines79-80 call J antiunitary. Read J=Gamma C as linear, unitary
and energy intertwining: Gamma and C are separately antilinear, so their
composition is linear. The original sentence remains unchanged below. The
T5 Hilbert-Schmidt inequalities use its energy-isometry property and retain
the same formulas and bounds. The subsequent inverse, domain and positive-column
arguments use Gamma directly and do not change. The accepted precision addendum,
author check and root corroboration supersede only the earlier no-correction
wording. See [precision](../.claude/science/physics-loops/toe-energy-tail-20261013/J_PRECISION.md).

The high-rank countercontrol preserves a failure of inference from weak energy
convergence and one-particle operator smallness alone to uniform first tails.
It lies outside the fixed-slot family. The single-pair control separates graph
norm requirements and itself has UI. Neither is a universal impossibility
claim. The N1-N8 packet remains FAIL / partial-narrowing; no five route families,
wall independence or negative certificate is invented.

## Evidence and publication boundaries

The canonical direct parents are the
[strict-gap chirped kinetic-energy theorem](CHIRPED_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE_2026-10-13.md)
and the [vacuum finite-multi-time energy theorem](MULTITIME_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE_2026-10-13.md),
at the existing regular PR9521 base. Initial-state PR9518 remains sibling
provenance. No combined ancestry or canonical edge to the unpublished prepared
sources is asserted. [Dependency bindings](../.claude/science/physics-loops/toe-energy-tail-20261013/IMPORTS.json)
and the complete archive identify every supplied source and scope.

The finite-Fock diagnostic is archived only as finite algebra evidence, with
its actual recorded execution; it cannot certify continuum domains or limits.
A separate Lean run compiled only the final scalar common-modulus cutoff
implication. Its actual axiom receipt lists propext, Classical.choice and
Quot.sound. It formalizes no CAR, unbounded-operator domain, trace inequality,
physical embedding or law/W1 passage. Historical pre-compilation source prose
is preserved alongside the later compiler receipt. See
[scalar evidence](../.claude/science/physics-loops/toe-energy-tail-20261013/LEAN_SCOPE.md).

All source archives, exact extraction maps and raw diffs are available through
[the archive guide](../.claude/science/physics-loops/toe-energy-tail-20261013/ARCHIVE_GUIDE.md).
Raw unified diffs are compressed without rewriting their literal context
markers. The proposed runner evaluates zero mathematical predicates and supplies
no independent scientific review. Root execution and publication remain pending.

## Unchanged root proof (306 lines)

