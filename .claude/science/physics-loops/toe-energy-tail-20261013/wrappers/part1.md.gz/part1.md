
## Unchanged independent proof (390 lines)

Required current reading: the historical J adjective at original line80 is corrected by the publication wrapper and J_PRECISION.md. All original formulas and domain arguments below are unchanged.

