
## Unchanged scoped countercontrol (84 lines)

