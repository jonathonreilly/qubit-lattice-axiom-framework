# Selective independent check of canonical current and companion Cook bridge

2026-10-11. This is a source-bound research check, not a formal audit or landing verdict. No repository source was edited. The separate threshold probe is my author derivation, so this report does **not** constitute independent review of that dependency.

## Exact coverage

- `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md`: all original 185 lines, SHA-256 `114c92ccf992bce2aededc2c4de25d02392edf29413746c56592e5dbee34f2af`; then the complete five-line H1/core clarification after J5 and its surrounding context were read. Current source is 190 lines, SHA-256 `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`. No formula changed in this update.
- `EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md`: the complete original 253-line source at `b70b43fc6a518988b59c9a1c4955db6d294030200c1c1fd6e2ef3291c94ff027`; affected updates at `1286d276e87e2e2607184b14a5ce3d87fc4bc2a3d75b55f0af644b7fddbab38e`; then all 262 lines of current source at `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7`.
- Unchanged threshold dependency: all 322 lines of `EXCLUDED_WALK_TRANSPORT_PROBE.md`, SHA-256 `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526`. Its derivation, rather than this review, supplies the pending central-shell estimates.
- M3/M6/M9 at frozen main `a13caa4885f547c8d206265b031ba7649e539fd9`: complete source reading and exact hashes are recorded in the threshold probe and `excluded_walk_probe/identity_manifest.json`. Those premises were reused unchanged.
- The five-page Kato 1957 primary paper was read in full. The fiberwise bounded self-adjoint rank-two perturbation meets its Theorem-1 trace-class hypotheses. The theorem concerns absolutely continuous subspaces, not absence of bound states. [Primary paper](https://www.jstage.jst.go.jp/article/pjab1945/33/5/33_5_260/_pdf).

## Canonical current reconstruction

No consequential defect was found in J1–J12 under the specified placement and pending threshold input. I reconstructed the first moment directly from the two original position operators, before introducing the local K,q chart. The factors `∂k1=∂K+∂q/2` and `∂k2=∂K−∂q/2` give J3. The coefficient of `∂q` is the **full** difference `h1−h2`, including all spatial axes.

For the contact row, integration by parts in q replaces `(i/2)(h1−h2)∂q` by `−i∂K H0` acting on c, which cancels the explicit `iH0'` term. Thus `C D0 P=i|c><h|∂K`. The contact column is `P D0(c f)=i∂K(h f)`. In the compressed commutator the two `h<h,∂Kψ>` terms cancel, while differentiating h and its contact bra leaves

`F_a=−|h'_a><h|−|h><h'_a|`.

The sign therefore follows from the actual placement commutator, not an assigned observable. The free term is `sin K_a cos 2q_a`; the original one-particle anticommutators give its factor exactly.

The common finite-support calculation is a valid dense algebraic domain and gives a bounded current extension. A precision improvement was sent to the author and is now present in the five-line paragraph after J5, checked at the current source hash: smooth sections compactly supported in a momentum chart are not themselves finite-support position states. The calculation extends to them because `D0:H1→L2`, while `H0` and P preserve H1; Fourier polynomials approximate in H1. Thus the chart calculation and bounded commutator agree on their common Sobolev domain. No assertion that the dipole itself is bounded, or an unproved self-adjointness theorem for a compressed dipole, is needed. The current identity alone does not bound an arbitrary unbounded position observable.

The band estimates use two separate facts correctly. First, `Pi_band h=H0 Pi_band c` gives `||Pi_band h||≤2λ eta`. Second, the lower contact weight `w++≥1/4` gives normalized band volume at most `4 eta²`; this converts the pointwise estimate `|h'_a(q)|≤2λ|sin(K_a/2)|` into J9. Contact mass alone would not bound a general spin form factor without this lower weight. The source retains both hypotheses.

Consequently

`||F_a φ_t||≤(sqrt(2)+4sqrt(6)) |sin(K_a/2)| λ eta`,
`|<φ_t,F_a φ_t>|≤16 |sin(K_a/2)| λ² eta²`.

I checked the endpoint expansion `2 B_a d+C_a d²` and the two free correction expectations. They yield J12 with the displayed 32 coefficient. The leading fixed-time term is `C_a d²=O_T(λ⁴)`; for `T=T0 λ^{-1/2}` it is `O(λ³)`. Projection may leave the free band, but the proof uses the global operator bound for the quadratic error and does not retain a false band assumption for the compressed state. The direct-integral statements follow from the uniform fiber bounds and a single global normalization.

The asymptotic finite-rank correction also checks: a free absolutely continuous packet gives L1 scalar spectral densities against each fixed form factor, so each coefficient tends to zero; the finite-rank expectation follows. The K-integral is dominated by a bounded fiber norm times the integrable packet norm squared. This does not assert that a decomposable interaction is globally trace class or that all globally dispersing bound-fiber states lie in the scattering range.

## Exact finite controls and their limits

`excluded_walk_probe/canonical_current_checks.py`, SHA-256 `3f59faae468e70b8aa16f7550773570d3c9e9f0c15ffb9bb7ee350dc41d4fdcd`, uses exact Gaussian-rational Laurent convolution with arbitrary first K-derivative jets. All 48 antisymmetric-field/axis cases give the original-position free current and the compressed finite-rank correction, with complete derivative-jet cancellation. Parseval gives the source's two form-factor norms exactly. An omitted-correction discriminator has squared output norm `23116208/404015625`.

The final seven-line `excluded_walk_probe/canonical_current_checks.log` was read completely after exit 0; SHA-256 `35a0666a65053cac3c111537d9ff5ac83218e09cdd814277096286fd428c7754`. The arithmetic utility code was copied from my own earlier exact checker; there are no root-runner or repository-science imports. No finite Fourier truncation or alias convention enters. These are independent finite controls of J2–J6, not a proof of the band/threshold estimates or a replay of an author primary runner. No separate numerical time-propagation control was run here; the finite-time inequality was checked analytically.

A first checker version mistakenly used only the differentiated-axis summand of `h1−h2`. It failed the free-current identity before testing the proposed correction. The checker was corrected to the full coefficient; the root draft already had the full coefficient. The failed source/log are preserved as `excluded_walk_probe/canonical_current_checks_initial_failure.py` (`f3cf1921255dbeaec867b51e0bc24d98978ac2ca0f2138fed20d70fb222c2ecb`) and `excluded_walk_probe/canonical_current_checks_initial_failure.log` (`dac4bcabacf222fe5135e86feba8df0730ca4222e40900bd6223df783553fe40`). This was a reviewer implementation error, not a scientific counterexample.

## Cook reconstruction and a disclosed missed prose defect

The Fourier convention gives `<h,e^{-itH0}ψ>=i a'_ψ(t)`, so C4 contains both terms of the actual perturbation. Integrating `|t|^{-r}` gives exactly `[(r−1)T^{r−1}]^{-1}`. I independently checked the incoming/outgoing signs, the normalized exclusion cost, the two endpoint observable comparisons in C8, and the additional finite-rank expectations in C9. The contact density transforms as `b_out=s b_in`, not its conjugate. The stationary phase and rank-one variance identities were reconstructed separately in the threshold probe, including a primary stationary theorem with its actual hypotheses.

My first pass did **not** catch the original prose claiming no resulting change of total-momentum weights. Another reviewer caught it, and the author repaired it. I checked the repair: with removed mass p, the prepared K density is `(||ψ_K||²−|a_K|²)/(1−p)`. The original law is the mixture of the normalized surviving and removed laws with weights 1−p and p, so its total-variation distance from the prepared law is at most p. This is already included in the state-norm preparation error. The updated seminorm wording is also accurate. The present report therefore does not represent the original version as fully clean.

The Cook constants remain explicit packet-dependent seminorms. A contact-aligned scaled family can give `A_r,D_r=O(λ^{3/2−r})` using the threshold density's fixed-order smooth scaled bounds, but its asymptotic g-current change is identically zero because S acts only by a phase on that channel. It is an existence/control family, not a nonzero current-change example. General coherent angular profiles need their own uniform contact-profile bounds before the same powers can be asserted. None of C7–C12 alone supplies a collision rate or a many-body relaxation law.

No formal audit verdict is issued. The material remaining verification is independent review of the author's threshold proof and any final combined-source/primary-runner packaging; neither is silently supplied by the finite controls in this report.
