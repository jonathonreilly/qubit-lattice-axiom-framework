# A coherent low-energy packet with nonzero canonical-current change

External author derivation, 2026-10-11. This is a proposed theorem composed
with the three frozen analytic inputs below, not an independent review of
those inputs or an audit verdict. It concerns the supplied three-dimensional
antisymmetric hard-core Weyl walk and one specified local-energy placement.
The dynamics, lattice, clock and placement remain supplied model premises.

The construction gives normalized smooth incoming packets whose asymptotic
canonical energy-current change is

    Delta J_asym = -epsilon C lambda^4 + O(lambda^5), C>0,

and actual excluded initial states at time -T, T=lambda^(-3/2), whose current
change by +T is

    Delta J_finite = -epsilon C lambda^4 + O(lambda^(9/2)).       (P1)

Here epsilon=+1 or -1 is an explicitly chosen relative coherent phase.
Changing it reverses the leading sign. This is a signed two-body coherent
current change, not dissipation, a many-body relaxation rate, or a statement
that every incoming packet changes current.

## 1. Frozen sources and exact dependency scope

All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Source | SHA-256 | Input used here |
| --- | --- | --- |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526` | Complete central-channel geometry, contact density and principal-value estimates, scaled derivatives in Section 4, stationary convention and rank-one formula in Section 5. |
| `EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md` | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7` | C1-C9 and the complete direct-integral extension, including global projection normalization and its changed K law. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Specified density, H1/core justification and bounded current J1-J6; qualitative asymptotic interpretation. Its J7-J12 fixed-time estimates are not used to prove (P1). |

These full sources were read in the preceding derivation/review and their
hashes were refreshed for this construction. The first is this author's own
threshold derivation; its reuse is not independent evidence. The canonical
identity was independently reconstructed in `EXCLUDED_WALK_CANONICAL_REVIEW.md`
at SHA `ced416dce3a7de31b503d73460e2fa449f6ed4e7175400d8376179cbeead0f9c`.
That report also preserves its initial helper failure and the later correction
to an earlier missed Cook-prose claim about K reweighting.

The repository source map remains frozen at main
`a13caa4885f547c8d206265b031ba7649e539fd9`; exact original M3/M6/M9 paths,
hashes and reading coverage are in `excluded_walk_probe/identity_manifest.json`.
No new repository source or external theorem is imported here. The threshold
source already checks the stationary Yafaev hypotheses; the Cook source checks
the fiberwise Kato trace-class hypotheses. Their conclusions, not a putative
global trace-class perturbation, are used below.

In particular, the finite-time claim requires the threshold source's uniform
scaled-parameter derivative conclusion through order seven. Keeping that
dependency explicit matters: pointwise smallness of a scattering phase alone
does not bound the outgoing Cook seminorms. A separate source-bound check of
that threshold argument and of this packet construction remains required.

## 2. Model, regular region and analytic inputs

Use normalized relative-momentum measure dq/(2pi)^3 and normalized total-
momentum measure dK/(2pi)^3 in a local K chart. In each antisymmetric fiber,

    H0(K,q)=sigma_1 dot sin(K/2+q)+sigma_2 dot sin(K/2-q).

Let c be the normalized constant singlet, C0=|c><c| and P=I-C0. The full-fiber
extension H=PH0P is zero on c; its restriction to P is the excluded walk. Put

    h=H0c, h'_a=partial_(K_a)h,
    H-H0=-|h><c|-|c><h|,
    ||h||<=sqrt(6),
    h'_a(q)=-sin(K_a/2) sin q_a sigma_(1,a)c.                (P2)

The canonical placement is e_x=P[(1/2)sum_i{Pi_(i,x),h_i}]P. Its energy
dipole has the bounded commutator extension

    J_a=P g_a P+F_a,   g_a(K,q)=sin K_a cos(2q_a),
    F_a=-|h'_a><h|-|h><h'_a|,
    ||F_a||<=2sqrt(3)|sin(K_a/2)|.                         (P3)

This is the specified canonical current, not a claim for all local-energy
placements. With J_ext=g_a+F_a, its operator on the excluded space is
P J_ext P. Thus their expectations agree on vectors in P; J_ext itself
need not preserve that subspace.

The central region 0<E<=1/8, |K|<=E/4 contains only the positive-positive
free channel. Its eight relative-momentum corner shells are q=C_j+r n,
C_j in {0,pi}^3, n in S^2. There is one radial root, with

    E/4<=r<=E,   1/2<=partial_r E_(++)<=2,
    1/4<=w_(++)=<c,Pi_(++)c><=1/2.                       (P4)

Let G(K,E+i0)=<c,(H0-E-i0)^(-1)c> and rho=Im(G)/pi. On each compact
scaled region with E=lambda e, K=lambda kappa, e>0, |kappa|<e/4, the frozen
threshold input gives

    rho(lambda kappa,lambda e)=lambda^2 r_lambda(kappa,e),
    r_lambda=r_0+O(lambda^2), r_0=(e^2-|kappa|^2)/(4pi^2),
    G(lambda kappa,lambda e+i0)/lambda=A(kappa,e)+O(lambda), (P5)

with the displayed remainder bounds after any fixed finite number of
derivatives in the scaled parameters. In particular they hold through order
seven on the compact set selected below. Here

    A=e integral [(e^2-|kappa odot cos q|^2)
          / (4 eps(q)^2 (e^2-(kappa dot v(q))^2))] dq/(2pi)^3,
    eps(q)=|sin q|, v_j(q)=sin q_j cos q_j/eps(q),
    I0=integral dq/[(2pi)^3 4 eps(q)^2],
    e(1-|kappa|^2/e^2) I0<=A<=e I0.                    (P6)

The measure-zero cone points do not affect these integrals; I0 is finite in
three dimensions. The threshold input supplies an E_*>0 for which
Re G>=5E/128 on 0<E<=E_*, |K|<=E/4. E_* has not been numerically certified.

For the convention S=Omega_+^*Omega_- and resolvent (H0-z)^(-1), the regular
shell scattering operator is

    S_(K,E)=I+(s-1)|v><v|,
    v=Z_(K,E)c/sqrt(rho), s=conj(G)/G.                  (P7)

Z is the coarea spectral restriction described below. The representative
(P7) is smooth on a regular interval; equality almost everywhere in energy
suffices for the packet. The contact zero eigenstate of H is not included
in the incoming free absolutely continuous space.

## 3. A compact domain and smooth normalized shell vectors

Take a=1; permutation gives either other component. Fix

    kappa_0=(1/8,0,0), R=1/32,
    U={kappa: |kappa-kappa_0|<R}, I=(5/4,7/4).

On the closures,

    3/32<=kappa_1<=5/32, |kappa|<=5/32,
    D=e^2-|kappa|^2>=D_min=1575/1024,
    beta=D+kappa_1^2>=D_min.                            (P8)

Thus the domain lies strictly inside |kappa|<e/4. For lambda<=1/16 it also
satisfies |K|<=lambda/4 and lambda<E<2lambda. Decrease a positive lambda_0
as needed so E<=E_* and the variance bound below holds. Every statement
from now on is for 0<lambda<=lambda_0.

For clarity use a fixed shell Hilbert space: the eight copies of
L2(S^2,C^4,dOmega/(2pi)^3), restricted to the positive band and the exchange-
antisymmetric subspace. Write r=lambda R_lambda(kappa,e,n). The physical
coarea restriction in these coordinates is

    (Z_(K,E)F)(j,n)=[r/sqrt(partial_r E_(++))]
                                  Pi_(++)(K,C_j+r n)F(C_j+r n). (P9)

It is an isometry after integration over dE. The exchange constraint is
inherited from the original full-q-torus antisymmetric space; no additional
factor of two or half-torus convention is introduced.

The implicit root R_lambda and the projectors are smooth in lambda^2,
kappa,e,n on this domain. At the limiting shell both one-particle momenta
have norm at least (e-|kappa|)/2>0; (P4) gives a uniform radial derivative.
The implicit-function theorem therefore applies uniformly. It follows that

    Zc=lambda z_(c,lambda),
    v_lambda=z_(c,lambda)/sqrt(r_lambda)                  (P10)

has uniformly bounded derivatives of each fixed order in the scaled
parameters. Positive contact weight avoids a spinor gauge choice: Pi_(++)c
is a globally defined nonzero section on each shell. Also v_lambda is a
unit vector in the antisymmetric shell space.

Remove the shell-constant part of g_1 and define a stable scaled multiplier

    gamma_lambda=(g_1-sin(lambda kappa_1))/lambda^3
       =-2 [sin(lambda kappa_1)/lambda]
                    [sin(lambda R_lambda n_1)/lambda]^2,
    m_lambda=<v_lambda,gamma_lambda v_lambda>,
    d_lambda^2=<(gamma_lambda-m_lambda)^2>_(v_lambda).      (P11)

These expressions extend smoothly to lambda=0 as functions of lambda^2.
Once d_lambda>0, set

    u_lambda=(gamma_lambda-m_lambda)v_lambda/d_lambda,
    chi_(lambda,epsilon)=(v_lambda+i epsilon u_lambda)/sqrt(2),
    chi_out=(s v_lambda+i epsilon u_lambda)/sqrt(2).        (P12)

Here epsilon is either +1 or -1. Both shell vectors have unit norm;
<v_lambda,u_lambda>=0. Multiplication by g_1 preserves exchange antisymmetry.
Equation (P7) gives exactly S chi=chi_out. The strictly positive variance
and the uniform smoothness of u are proved next, not assumed.

## 4. Exact limiting contact measure and angular variance

On one limiting continuum cone put p=kappa/2+y, so the second momentum is
kappa-p. The limiting shell and contact weight are

    |p|+|kappa-p|=e,
    w_0=D/[8|p||kappa-p|].                              (P13)

Let k=|kappa|>0. In prolate coordinates
u=(|p|+|kappa-p|)/k, v_p=(|p|-|kappa-p|)/k and azimuth phi, the volume
Jacobian is k^3(u^2-v_p^2)/8 and the product of the two radii is
k^2(u^2-v_p^2)/4. Multiplying by w_0 and delta(e-ku) leaves
D dv_p dphi/16. Consequently the normalized contact angular measure is
dv_p dphi/(4pi), with weight 1/8 at each of the eight cones. This also
rederives r_0=D/(4pi^2), including the torus normalization.

Under this probability measure,

    y=T n, n uniform on S^2,
    T^2=[D I+kappa kappa^T]/4.                           (P14)

Indeed y_parallel=e v_p/2 and
|y_perpendicular|=sqrt(D)sqrt(1-v_p^2)/2. Since the squared length of
row 1 of T is beta/4, the uniform-sphere moments give

    <y_1^2>=beta/12, <y_1^4>=beta^2/80,
    Var(y_1^2)=beta^2/180.                               (P15)

For example these follow from <n_1^2>=1/3, <n_1^4>=1/5 and rotational
invariance, or directly from the displayed v_p,phi measure. Since
gamma_0=-2 kappa_1 y_1^2, (P11) yields

    d_0=kappa_1 beta/(3sqrt(5))
        >=d_min:=D_min/(32sqrt(5))>0,
    d_lambda=d_0+O(lambda^2).                            (P16)

All finite-order scaled derivatives have the same smoothness just used in
(P9)-(P11). An explicit way to choose the remaining variance restriction
is to let C_V be the supremum of
|partial_(lambda^2) Var_(v_lambda)(gamma_lambda)| over the compact domain
0<=lambda<=1/16, closure(U) times closure(I). This constant is finite before
taking a variance square root. Choose additionally
lambda_0<=d_min/sqrt(2C_V), interpreting that restriction as absent if C_V=0.
Then d_lambda>=d_min/sqrt(2). Thus u_lambda and chi have uniform scaled
derivative bounds, including through order seven. This proves that the
normalization in (P12) is legitimate everywhere on the packet support.

## 5. Exact coherent sign and leading shell change

Write sigma_lambda=sqrt(Var_v(g_1))=lambda^3 d_lambda. The exact rank-one
calculation in the v,u basis gives

    S^*g_1 S-g_1
       =sigma_lambda[(s-1)|u><v|+(conj(s)-1)|v><u|],
    <chi_(lambda,epsilon),(S^*g_1 S-g_1)chi_(lambda,epsilon)>
       =epsilon sigma_lambda Im(s).                     (P17)

For this sign convention,

    Im(s)=-2 Re(G) Im(G)/|G|^2<0,
    Im(s)=-2pi lambda r_0/A+O(lambda^2).                  (P18)

Using (P5) and (P16), uniformly on the selected domain,

    epsilon sigma_lambda Im(s)
       =-epsilon lambda^4 c_*(kappa,e)+O(lambda^5),
    c_*(kappa,e)=kappa_1 beta D/[6pi sqrt(5) A(kappa,e)]>0. (P19)

This fixes both the sign and the normalization; using the opposite convention
for the resolvent or S without changing the sign here would be an error.

There is a simple explicit lower bound for the coefficient. Fold the q torus
to eight copies of [-pi/2,pi/2]^3 and use |sin x|>=2|x|/pi on that cube.
The cube lies in the ball of radius sqrt(3)pi/2, so

    I0 <= (1/pi^3)(pi^2/16) integral_(|x|<=sqrt(3)pi/2) |x|^-2 dx
       =sqrt(3)pi/8.

Equations (P6) and (P8) then imply

    c_*(kappa,e)>=c_min:=D_min^2/[14pi^2 sqrt(15)]>0.       (P20)

The pure contact vector v is an exact zero-change control: S only multiplies
it by a phase. Its nonzero scattering phase alone cannot produce the claimed
current expectation change. The interference with u in (P12) is essential.

## 6. One actual normalizable incoming packet

Choose the following real smooth bump envelopes, extended by zero:

    alpha(kappa)=N_K exp[-1/(1-|kappa-kappa_0|^2/R^2)] in U,
    f(e)=N_E exp[-1/(1-16(e-3/2)^2)] in I.

The positive normalizers are defined by

    integral |alpha|^2 d^3kappa/(2pi)^3=1,
    integral |f|^2 de=1.                                 (P21)

In the shell spectral representation with measure dK/(2pi)^3 dE, set

    Psi_(lambda,epsilon)(K,E)
       =lambda^-2 alpha(K/lambda) f(E/lambda)
                             chi_(lambda,epsilon)(K/lambda,E/lambda).
                                                               (P22)

The norm is exactly one: the squared amplitude contributes lambda^-4,
the K measure contributes lambda^3 and the E measure contributes lambda.
There is no normalization of individual K fibers; they have norm
lambda^(-3/2)|alpha(K/lambda)|. Formula (P9), inverted on its positive-band
range, constructs the corresponding free two-record vector. It is in the
free fiberwise absolutely continuous space, supported inside the eight
regular shell neighborhoods and in the selected K chart.

For each lambda>0 the incoming vector is smooth in momentum. The chart
Jacobian is nonsingular on its support, the projectors and u are smooth,
and the bump envelopes vanish with every derivative at their support
boundaries. Thus this is a smooth normalizable packet, not a delta function
in K or energy. Define Phi=S Psi by replacing chi with chi_out in (P22).

Finite-rank F_1 has vanishing free asymptotic expectation on these packets:
its scalar spectral densities are L1, and the Riemann-Lebesgue lemma applies
fiberwise. Dominated convergence integrates the statement over K; wave-
operator norm convergence transfers it to the actual scattering states.
Therefore the canonical current has the same asymptotic change as g_1.
Equations (P17)-(P22) give

    Delta J_asym=-epsilon lambda^4 C+O(lambda^5),
    C=integral |alpha(kappa)|^2 |f(e)|^2 c_*(kappa,e)
                                      d^3kappa/(2pi)^3 de >=c_min. (P23)

The coefficient is independent of lambda and epsilon. No assumption about
incoherent angular averaging has been made; the constructed state is coherent.

## 7. Scaled Cook and canonical form-factor seminorms

This section verifies the regularity needed for a finite-time witness,
including both canonical form factors. It does not infer their bounds merely
from the contact density. All inner products below are in the fixed shell
space of (P9), linear in the second argument.

Put r_lambda=rho/lambda^2 as above and define, for b=in,out,

    B_0^in=f sqrt(r_lambda)/sqrt(2),
    B_0^out=s B_0^in,
    B_1^b=e B_0^b.                                      (P24)

The contact scalar densities of the full packet at K=lambda kappa,E=lambda e
are exactly

    b_(c,b)=lambda^-1 alpha(kappa) B_0^b,
    b_(h,b)=alpha(kappa) B_1^b.                          (P25)

For example the first identity is the product of Zc=lambda sqrt(r_lambda)v
with the lambda^-2 packet amplitude and <v,chi>=1/sqrt(2). For the outgoing
packet this last inner product is s/sqrt(2). The second identity uses
Z h=E Z c, rather than an independent approximation.

For h'_1 the pointwise formula (P2) on q=C_j+lambda R_lambda n has two
small sine factors. Combining it with the coarea factor in (P9) proves

    Z h'_1=lambda^3 zeta'_lambda,
    zeta'_lambda uniformly smooth in the scaled parameters,
    B_2^in=f <zeta'_lambda,chi>,
    B_2^out=f <zeta'_lambda,chi_out>,
    b_(h'_1,b)=lambda alpha(kappa) B_2^b.                 (P26)

Here zeta' is notation for this scaled form factor, not another derivative.
The formula also retains the corner signs and projectors; a bound on |sin q_1|
alone would not prove the required derivative regularity.

For each integer 0<=r<=7 define explicit finite mixed-norm constants

    C_(j,r)^b(lambda)
       = [integral_U |alpha(kappa)|^2
             (integral_R |partial_e^r B_j^b(lambda,kappa,e)| de)^2
                                      d^3kappa/(2pi)^3]^(1/2),
    bar C_(j,r)^b=sup_(0<lambda<=lambda_0,epsilon=+/-1) C_(j,r)^b(lambda).
                                                               (P27)

All B_j are extended by zero in e. Their compact smooth envelope gives the
vanishing endpoint traces. Equations (P9)-(P16), (P24)-(P26) and the order-seven
part of (P5) prove finiteness. More explicitly, G/lambda has a uniform positive
real-part lower bound, and

    s=1-2pi i lambda r_lambda/(G/lambda),                 (P28)

so product/quotient differentiation bounds each of its first seven scaled
e derivatives. Uniform smallness of s-1 without these derivative estimates
would not suffice.

The constants in (P27) are specified functionals, not numerically evaluated
uniform bounds. If numerical upper bounds are desired, the following direct
product-rule bounds reduce them to finitely many compact suprema. Let

    M_j^in=sup |partial_e^j sqrt(r_lambda)|,
    M_j^out=sup |partial_e^j(s sqrt(r_lambda))|,
    Z_j=sup ||partial_e^j zeta'_lambda||,
    X_j^b=sup ||partial_e^j chi_b||,
    H_j^b=sum_(l=0)^j binom(j,l) Z_l X_(j-l)^b,

where each supremum is over the same compact domain and chi_in=chi. Then

    bar C_(0,r)^b <= (1/sqrt(2)) sum_(j=0)^r binom(r,j)
                                          ||f^(r-j)||_1 M_j^b,
    bar C_(1,r)^b <= (7/4) bar C_(0,r)^b+r bar C_(0,r-1)^b,
    bar C_(2,r)^b <= sum_(j=0)^r binom(r,j)||f^(r-j)||_1 H_j^b. (P29)

The middle formula is for r>=1, with the evident r=0 bound. These constants
are independent of lambda and epsilon. No uniform bound in derivative order
is asserted.

Let A_r(K,b)=||partial_E^r b_(c,b)||_(L1_E) and
D_r(K,b)=||h(K)|| A_r(K,b)+||partial_E^r b_(h,b)||_(L1_E), as in the Cook
source. A change of variables E=lambda e, K=lambda kappa proves

    ||A_r(.,b)||_(L2_K)=lambda^(3/2-r) C_(0,r)^b(lambda),
    ||D_r(.,b)||_(L2_K)
       <=lambda^(3/2-r)[sqrt(6) C_(0,r)^b(lambda)
                                      +lambda C_(1,r)^b(lambda)]. (P30)

For the canonical finite-rank correction choose columns (h,h'_1) and
M=[[0,-1],[-1,0]], so ||M||=1. Its integrated C9 seminorm is exactly

    F_r(b)=integral [||partial_E^r b_(h,b)||_1^2
                          +||partial_E^r b_(h'_1,b)||_1^2] dK/(2pi)^3
       =lambda^(5-2r) [C_(1,r)^b(lambda)]^2
                         +lambda^(7-2r) [C_(2,r)^b(lambda)]^2.  (P31)

The extra lambda^3 in this integral is the total-momentum volume factor.
Using normalized individual fibers without restoring that factor would
give incorrect global seminorm powers.

## 8. An actual finite-time nonzero canonical-current witness

Set r=7 and T=lambda^(-3/2). Define finite constants

    D_bar=sqrt(6)(bar C_(0,7)^in+bar C_(0,7)^out)
                        +lambda_0(bar C_(1,7)^in+bar C_(1,7)^out),
    J_0=(1+sqrt(3)) 5/32.

Prepare and evolve the actual excluded state by one global normalization:

    Eta_-=P exp(iT H0)Psi / ||P exp(iT H0)Psi||,
    Eta_+=exp(-2iT H)Eta_-.                              (P32)

Its removed probability obeys

    p=||C0 exp(iT H0)Psi||^2
       <=[bar C_(0,7)^in]^2 lambda^10.                   (P33)

Take lambda small enough that this is less than one. In particular, the
preparation changes total-momentum weights: the normalized new density is
(||Psi_K||^2-|<c,exp(iT H0(K))Psi_K>|^2)/(1-p). Its total-variation distance
from the original K density is at most p. Neither unchanged K weights nor
fiberwise renormalization is assumed in (P32).

The integrated incoming-plus-outgoing Cook tail is at most
(D_bar/6)lambda^(7/2), and the projection norm cost is at most
sqrt(2) bar C_(0,7)^in lambda^5. On this K support, (P3) gives

    ||J_ext|| <= J_0 lambda.                             (P34)

This norm bound is global in q, so it covers components outside the original
free energy band introduced by P. Applying the Cook C8-C9 endpoint comparison
with (P30)-(P34) yields the explicit estimate

    | <Eta_+,J_1 Eta_+>-<Eta_-,J_1 Eta_->-Delta J_asym |
       <= (J_0 D_bar/3) lambda^(9/2)
          +4sqrt(2) J_0 bar C_(0,7)^in lambda^6
          +([bar C_(1,7)^in]^2+[bar C_(1,7)^out]^2) lambda^12
          +([bar C_(2,7)^in]^2+[bar C_(2,7)^out]^2) lambda^14. (P35)

The last two terms explicitly control the canonical h,h'_1 correction at
the free endpoints. Its qualitative asymptotic disappearance alone would
not justify a finite-time leading coefficient.

Combining (P23) and (P35) proves (P1). More quantitatively, choose C_asym
so the uniform integrated remainder in (P23) is at most C_asym lambda^5.
Let C_tot be C_asym plus the four coefficients on the right of (P35).
For lambda<=1 they bound the combined error by C_tot lambda^(9/2).
It is enough to impose, in addition to the prior restrictions,

    [bar C_(0,7)^in]^2 lambda^10 <=1/2,
    sqrt(lambda) C_tot <= c_min/2.                       (P36)

Such a positive range exists because all constants are finite and c_min>0.
It gives the genuinely nonzero finite-time statement

    -epsilon [<Eta_+,J_1 Eta_+>-<Eta_-,J_1 Eta_->]
                      >= (c_min/2)lambda^4>0.            (P37)

For epsilon=+1 the current decreases; for epsilon=-1 it increases. The
experiment has duration 2lambda^(-3/2) in the supplied clock and concerns
this prepared two-record family. It establishes no irreversible trend.

## 9. Controls, failed routes and remaining obligations

`excluded_walk_probe/coherent_packet_checks.py` was read in full and run to
exit 0. Its complete 15-line log is
`excluded_walk_probe/coherent_packet_checks.log`. Source SHA-256:
`21ae25081286984d725daa7e3820886d6d411d233acb615819eb77aee4a13ad0`;
log SHA-256: `105bbe68af4547800077514b4cc2047ae62a99f58b62448e9fdc2616f255eb0c`.

Its exact Gaussian-rational two-by-two controls derive the sign in (P17)
from an actual coherent vector and preserve the exact pure-contact zero.
Exact sphere monomial moments separately test (P15), and exact rational
exponent arithmetic tests r=6 versus r=7. A direct lattice-shell calculation
finds radial roots in 3,072 deterministic angular directions at two kappa
values and four scales, uses the actual contact/coarea weight, and compares
sigma/lambda^3 and the angular moments with (P15)-(P16). These are author
controls, reusing this author's exact-arithmetic utilities; they are not an
independent review of the theorem. The angular quadrature is not interval
certified and does not prove any uniform estimate or principal value.

Two unsuccessful shortcuts are retained. A packet in v alone has exactly
zero asymptotic current change even when its scattering phase is nonzero.
Also r=6 at T=lambda^(-3/2) makes the Cook state error O(lambda^3) and its
current error O(lambda^4), the same order as the desired coefficient. That
estimate alone cannot prove a finite-time leading coefficient. Using r=7
and verifying both canonical form-factor profiles resolves that issue here.

Remaining dependencies and limits are explicit. The source's uniform
threshold/PV derivative proof through order seven and the stationary
representation need their independent selective check; this draft does not
replace it. This new packet construction, moment coefficient, scaled
normalization and finite-time composition also need independent review.
E_*, C_V, the derivative suprema and a maximal numerical lambda range have
not been interval certified; the theorem gives a positive sufficiently
small range through finite analytic constants. No other total-momentum
corner, mixed-channel regime, two-dimensional threshold, arbitrary placement,
many-body transport or physical rate is covered. The opposite coherence
sign is a counterexample to any universal-current-loss interpretation.

Only this external draft, its named helper/log and new identity-manifest
entries were written. Frozen analytic sources, prior failure records,
repository files, claim status and audit metadata were not changed.
