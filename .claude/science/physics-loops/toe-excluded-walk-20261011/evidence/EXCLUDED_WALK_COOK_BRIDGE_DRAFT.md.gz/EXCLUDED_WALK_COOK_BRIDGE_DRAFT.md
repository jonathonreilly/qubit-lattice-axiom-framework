# Quantitative finite-time bridge for the supplied excluded walk

Root derivation, 2026-10-11. Provisional analytic draft; requires a separate
source-bound check before publication. It concerns the supplied antisymmetric
two-record walk, not a derivation of that dynamics from minimal axioms. The
threshold/scattering-matrix work in EXCLUDED_WALK_TRANSPORT_PROBE.md is a
separate dependency only where explicitly invoked below.

## Exact finite-rank extension

Fix total momentum K in three dimensions. On the antisymmetric fiber use
normalized torus measure and

    H0(q)=sigma_1 dot sin(K/2+q)+sigma_2 dot sin(K/2-q).

Let c be the normalized constant singlet, C=|c><c|, P=I-C, and h=H0 c.
The singlet has zero one-spin expectation, so <c,H0c>=0. Set H=PH0P on
the full fiber. Its restriction to P is the physical excluded walk and its
restriction to C is a decoupled zero eigenstate. Direct expansion gives

    V=H-H0=-|h><c|-|c><h|,                          (C1)
    <c,h>=0,  ||h||^2=2 sum_a cos(K_a/2)^2 <=6.      (C2)

Indeed H0 c=[sigma_1 dot (a-b)]c, where a=sin(K/2+q),
b=sin(K/2-q). The Pauli identity gives norm squared |a-b|^2 pointwise,
and a-b=2 cos(K/2) sin q. Each normalized torus integral of sin^2 q_a
is 1/2. Thus H and H0 are bounded self-adjoint and V is self-adjoint
of rank at most two. The special all-pi fiber has h=0 and no perturbation.

Let P_ac(H0) be the absolutely continuous spectral projection. Kato's
trace-class theorem implies that

    Omega_+/-=s-lim_(t->+/-infinity) exp(itH) exp(-itH0) P_ac(H0)

exist and map the absolutely continuous space of H0 isometrically onto
that of H. Consequently S=Omega_+^* Omega_- is unitary on that initial
space and Omega_- = Omega_+ S there. The auxiliary zero eigenstate is
orthogonal to both wave-operator ranges. No absence-of-bound-states
assumption is needed.

The exact primary import is Theorem 1, p.260, of Tosio Kato, Perturbation
of Continuous Spectra by Trace Class Operators, Proceedings of the Japan
Academy 33 (1957), 260-264:
https://www.jstage.jst.go.jp/article/pjab1945/33/5/33_5_260/_pdf
Its self-adjoint and trace-class hypotheses hold by (C1); its limits use
the same sign convention. The theorem and its five-page source were read.
The bounds below are direct calculations and are not attributed to that
paper's statement. This application is fiberwise: it does not claim that
the full translation-invariant two-body perturbation is trace class.

## Quantitative Cook tails from contact spectral regularity

Let psi be a normalized vector in P_ac(H0). Define the complex scalar
spectral density b_psi by

    <c, dP_H0(E) psi> = b_psi(E) dE.

For an integer r>=2 assume b_psi and E b_psi belong to W^(r,1)(R).
Functions are extended over the whole real line; these hypotheses include
the vanishing boundary traces needed for integration by parts. A compactly
supported smooth density inside a regular energy interval suffices. Set

    A_r(psi)=|| d_E^r b_psi ||_1,
    D_r(psi)=||h|| A_r(psi)+|| d_E^r(E b_psi) ||_1.

Write a_psi(t)=<c,exp(-itH0)psi>. Fourier integration by parts yields

    |a_psi(t)| <= A_r(psi) |t|^-r,
    |a_psi'(t)| <= ||d_E^r(E b_psi)||_1 |t|^-r.      (C3)

The sign relation <h,exp(-itH0)psi>=i a_psi'(t) and (C1) give

    ||V exp(-itH0)psi||
       <= ||h|| |a_psi(t)|+|a_psi'(t)|
       <= D_r(psi) |t|^-r.                         (C4)

The derivative of exp(itH)exp(-itH0)psi is
i exp(itH)V exp(-itH0)psi. Integrating this identity from T to infinity,
or from minus infinity to -T, proves for T>0

    ||(Omega_+ - exp(iTH)exp(-iTH0))psi||
       <= D_r(psi)/[(r-1) T^(r-1)],
    ||(Omega_- - exp(-iTH)exp(iTH0))psi||
       <= D_r(psi)/[(r-1) T^(r-1)].                 (C5)

These tails use the full V, including both contact matrix elements. A
bound on contact occupation alone without its time derivative would not
establish (C4).

## Prepared finite-time scattering experiment

Let phi=S psi and also require the same W^(r,1) hypotheses for b_phi.
At time -T start the excluded walk in

    eta_- = P exp(iTH0)psi / ||P exp(iTH0)psi||,

assuming |a_psi(-T)|<1. Its state at +T is eta_+=exp(-2iTH)eta_-.
For any normalized chi with contact amplitude a, direct calculation gives

    ||P chi/||P chi|| - chi||^2
       =2(1-sqrt(1-|a|^2)) <=2|a|^2.              (C6)

Apply (C5) first to psi at -T, use Omega_-psi=Omega_+phi, and then apply
(C5) to phi at +T. Unitary propagation and (C6) prove

    ||eta_+ - exp(-iTH0)phi|| <= R_T,
    R_T=[D_r(psi)+D_r(phi)]/[(r-1) T^(r-1)]
                              +sqrt(2) A_r(psi)/T^r. (C7)

This is a finite-time norm estimate for the actual compressed unitary.
It is conditional on explicit packet regularity, not on a collision
count, relaxation ansatz, presumed Fermi-golden-rule rate or initial
scattering-state preparation. The excluded preparation is displayed.

## Current and bounded-observable consequences

Let g be a bounded self-adjoint operator commuting with H0. For the
specific observable J=P g P on the excluded space, free time evolution
keeps the expectation of g fixed. The inequality between expectations
of a bounded observable in two unit vectors is at most twice its norm
times their norm distance. Applying it at both endpoints yields

    |<eta_+,J eta_+>-<eta_-,J eta_->
                 -<psi,(S^* g S-g)psi>|
       <=2||g|| { [D_r(psi)+D_r(phi)]/[(r-1)T^(r-1)]
                                    +2sqrt(2)A_r(psi)/T^r }. (C8)

For the repo's free two-step current, g_a(q)=sin K_a cos(2q_a).
Equation (C8) applies to its explicit compression. Identifying it with
a chosen interacting placement current requires checking that placement;
a finite contact correction is not silently set to zero.

A version retaining such a correction is also elementary. Suppose a
bounded self-adjoint extension of the desired physical current is
J_ext=g+A M A^*, with columns f_j of A and a Hermitian finite matrix M.
For chi=psi or phi let

    <f_j,dP_H0(E)chi>=b_(j,chi)(E)dE,
    F_r(chi)=sum_j ||d_E^r b_(j,chi)||_1^2,

and require these scalar densities to be W^(r,1)(R). At time +/-T,
the free expectation of A M A^* is bounded in absolute value by
||M|| F_r(chi)/T^(2r). Repeating the endpoint comparison proves (C8)
with ||g|| on its right replaced by ||J_ext|| and the extra term

    ||M|| [F_r(psi)+F_r(phi)]/T^(2r).               (C9)

Here the left-hand side uses the restriction of J_ext to the excluded
space. Finite support by itself does not assert these packet regularity
hypotheses or numerical constants; the form factors must be checked.

## Conditional rank-one scattering specialization

On a regular positive-energy interval, suppose the separately justified
stationary representation has contact density rho(E)>0, normalized
contact vector v_E, and

    S_E=I+(s(E)-1)|v_E><v_E|,
    s(E)=conj(G(E+i0))/G(E+i0), Im G=pi rho.        (C10)

For a real bounded shell multiplier g_E put
w_E=(g_E-<v_E,g_E v_E>)v_E, so <v_E,w_E>=0. Direct multiplication gives

    S_E^*g_E S_E-g_E
       =(s-1)|w_E><v_E|+(conj(s)-1)|v_E><w_E|,
    ||S_E^*g_E S_E-g_E||
       = |s-1| ||w_E|| = (2pi rho/|G|) sqrt(Var_(v_E)(g_E)). (C11)

The equality also holds when w_E=0. It concerns an operator difference,
and does not assert nonzero loss for every state or a sign of current
change. Direct integration bounds the packet expectation by the
essential supremum of (C11) on its energy support.

The contact density of the outgoing packet is b_phi(E)=s(E)b_psi(E).
Thus b_psi compactly supported in this interval and s of class C^r
there provide the needed outgoing contact regularity; its constants
come from the product rule and must be bounded before using a claimed
uniform low-energy scaling. The current-contact form factors in (C9)
have their own regularity obligations.

If the pending threshold work proves rho<=C_rho E^2 and |G|>=c_G E,
and the entire central positive shell has distance at most E from the
relative-momentum corners in {0,pi}^3,
then g_a=sin K_a cos(2q_a) has shell range at most 2|sin K_a|E^2.
The variance of a real variable in an interval of length L is at most
L^2/4. Hence (C11) is at most

    (2pi C_rho/c_G) |sin K_a| E^3.                (C12)

For |K|=O(E) this is an O(E^4) asymptotic packet-current bound. It is
conditional on the stated uniform threshold bounds and their channel
domain, not yet a completed conclusion of this draft. Equations (C7)
and (C8) state exactly the extra finite-time errors that must be kept.

## Normalizable center-of-mass packets

The finite-time statements extend to a normalizable direct-integral packet
without claiming global trace-class scattering. Let the total-momentum
fibers vary measurably over a coordinate patch, with the packet zero outside
that patch. Use normalized total-momentum measure dK. Take a measurable
field psi_K in P_ac(H0(K)) with integral ||psi_K||^2 dK=1. Individual
psi_K need not be normalized. Define the linear density b_(K,psi) and the
homogeneous seminorms A_r(K,psi), D_r(K,psi) as above, and assume A_r and D_r
are in L2(dK). Require the analogous
D_r(K,phi) bound for phi_K=S_K psi_K.

The fiberwise wave operators form measurable fields: they are pointwise
strong limits of measurable bounded operator fields along integer times.
Fiberwise strong convergence and the bound 2||psi_K|| give convergence in
the direct-integral Hilbert space by dominated convergence. The resulting
Omega operators are isometries between the direct integrals of the fiber
absolutely continuous spaces, and satisfy Omega_-=Omega_+ S on that domain.
This does not identify their ranges with the full absolutely continuous
space of the global H: dispersing fiber-bound states need not belong to
that range.

Let P now denote the direct integral of the contact complements, and prepare

    Eta_- = P exp(iTH0)Psi / ||P exp(iTH0)Psi||

using one global normalization. The removed-contact norm is at most
||A_r(.,psi)||_(L2_K)/T^r. Integrate the squared pointwise Cook bound and
then take a square root. Equations (C7) and (C8) hold verbatim with

    A_r(psi) -> ||A_r(.,psi)||_(L2_K),
    D_r(psi) -> ||D_r(.,psi)||_(L2_K),
    D_r(phi) -> ||D_r(.,phi)||_(L2_K),

and the essential supremum of the fiber observable norms. The preparation
requires the actual removed-contact norm to be less than one; the displayed
upper bound gives a sufficient condition. There is no fiber-by-fiber
renormalization. The global projection does reweight total momentum: if
p=integral |a_(K,psi)(-T)|^2 dK, its new density is
(||psi_K||^2-|a_(K,psi)(-T)|^2)/(1-p). Its total-variation distance from
the original K density is at most p, since the original is the mixture
of the normalized surviving and removed-contact densities with weights
1-p and p. Here p<=||A_r(.,psi)||_(L2_K)^2/T^(2r). This preparation effect
is already included in (C6)-(C8); unchanged total-momentum weights are not
assumed.

For (C9), take measurable finite-rank form factors and replace F_r(chi) by
integral F_r(K,chi) dK and ||M|| by ess sup_K ||M_K||. Its proof is the
same integrated quadratic bound. Likewise the asymptotic packet-current
estimate is the essential supremum of (C11) over (K,E) on the actual packet
support. All corner/channel and regularity restrictions remain in force.

## Recovery and open checks

1. Independent analytic check of (C1)-(C9), including signs, normalization,
   physical excluded subspace and the required regularity of both packets.
2. Exact finite matrix controls of the rank-two identity and (C11), plus
   Fourier-density controls of the Cook-tail normalization and powers.
3. Bind (C10) to the verified stationary theorem and its actual hypotheses;
   Kato completeness alone does not supply the stationary formula.
4. Complete the separate central-channel threshold proof before using
   (C12). Other total corners are not covered by that central estimate.
5. Derive uniform scaled packet constants, or preserve them as explicit
   packet-dependent quantities. Independently check the direct-integral
   argument and its distinction from global asymptotic completeness.

No repository science source, claim registry, audit verdict or axiom was
changed by this external draft. The new derivation is provisional.
