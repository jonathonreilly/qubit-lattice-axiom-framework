# Source-bound independent check of the excluded-walk Cook bridge

2026-10-11. Bounded analytic and computational review by the spatial quantum
worker. This memo supplies independent checks, not a formal audit verdict or
retained-status decision. It makes no repository edits and adopts no physical
primitive. The selected model and reasoning effort were preserved.

The final draft's C1–C9 and direct-integral extension withstand the independent
reconstruction below under their stated packet and observable hypotheses. Two
direct-integral wording defects were corrected during review: the regularity
quantities are homogeneous seminorms, and global contact projection generally
reweights total momentum. The final C12 now names the required relative corners
in `{0,pi}^3`. C10–C12 remain conditional interfaces. This review does not
establish their stationary representation or the pending threshold estimates.

## 1. Exact sources, reading coverage, and revisions

Let S be `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and W be `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/worktree`.
SHA-256 identities are:

| Source | Identity and coverage |
|---|---|
| S/EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md, final | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7`; all 262 lines read, including all C1–C12 and the direct-integral argument |
| Original Cook draft | `b70b43fc6a518988b59c9a1c4955db6d294030200c1c1fd6e2ef3291c94ff027`; all 253 lines read; original bytes recovered by reversing the exact two subsequent edits and checking this original hash |
| Intermediate Cook draft | `1286d276e87e2e2607184b14a5ce3d87fc4bc2a3d75b55f0af644b7fddbab38e`; complete changed argument read; only the central-corner wording changed from this version to final |
| W/docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`; all 226 lines read |
| Kato primary PDF, archived under excluded_walk_review/kato_1957_primary.pdf | `12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`; all five pages' extracted text read, especially Theorem 1 p.260 and its proof pp.263–264; no claim of visual page inspection |

The supplied walk note fixes the free symbol, antisymmetric contact projection,
and free two-step current used here. Reading it does not independently validate
every threshold or physical claim in that parent note. The separate transport
probe, its stationary proof, and any new threshold argument are outside this
check. No author runner was used as independent evidence.

The worktree was on `physics-loop/toe-nonlinear-transport-20261011`, HEAD
`3fbaa00e9d97a19459d197fd0de2d62d45327e90`, with local main
`e485eab6b09b3957df5772104d3ea3980108d7fa` at the final source check. File hashes,
not a claim that this concurrently used worktree was globally frozen, bind the
review. Exact Cook snapshots, helper sources, logs, and a receipt reside in
S/excluded_walk_review. All earlier qubit files remain untouched.

The applicable physics-claim-reviewer skill and current freshness instructions
were read; the proof-search governance was read completely. The current main
review-loop's model/tool and focused-review instructions were checked without
starting a review-loop operation. No audit workflow or skill synchronization
was run. The owner's bounded scope and preserved-model instruction controlled.

## 2. Compression and the primary scattering theorem: C1–C2

Use the physicists' inner product, linear in the second slot, and normalized
torus measure. The constant singlet c has norm one and belongs to the
antisymmetric fiber: its spin exchange sign matches the reversal of relative
momentum. The free symbol preserves that fiber. For a=sin(K/2+q) and
b=sin(K/2-q), the singlet identity gives

    H0 c = [sigma_1 dot (a-b)] c = h,
    <c,h> = 0,
    ||h||^2 = integral |a-b|^2 dq = 2 sum_j cos(K_j/2)^2.

The last coefficient uses each normalized average of sin(q_j)^2 equal to 1/2.
It is not an unnormalized Brillouin-zone volume. Expanding P=I-|c><c| yields

    PH0P-H0 = -|h><c|-|c><h|.

The omitted quadratic term is zero precisely because <c,H0c>=0. If h is
nonzero, this operator has eigenvalues +||h|| and -||h|| on span{c,h}; hence
its operator norm is ||h|| and its trace norm is 2||h||. If all K components
are pi modulo 2pi, h=0 and the perturbation vanishes. Hc=0, and P reduces H,
so the full-space extension agrees with the physical compressed operator on P.

The applicable primary result is [Kato, Theorem 1, p.260 (1957)](https://www.jstage.jst.go.jp/article/pjab1945/33/5/33_5_260/_pdf).
It assumes self-adjoint H0 and a bounded self-adjoint trace-class perturbation
V. It gives the two strong limits with signs exp(itH)exp(-itH0), their reverse
adjoint limits, and completeness between the two absolutely continuous
subspaces. C1 verifies these hypotheses separately for each K. Thus S is
unitary on the free absolutely continuous subspace and Omega_- = Omega_+ S.
The zero eigenvector c is orthogonal to the final absolutely continuous
subspace. Additional bound states are allowed; no absence-of-bound-states
premise is needed. The theorem does not supply C10's stationary formula, nor
does fiberwise trace class imply trace class for the global direct integral.

## 3. Contact regularity, signs, and preparation: C3–C7

For psi in the free absolutely continuous subspace the complex contact
spectral measure has an integrable density b. In the draft's convention,

    a(t) = integral exp(-itE) b(E) dE,
    a'(t) = -i <h,exp(-itH0)psi>.

There is no additional 2pi in this spectral-measure Fourier transform. Whole
line W^(r,1) regularity permits r integrations by parts and gives the two C3
bounds. For the bounded H0, compact spectral support means the whole-line
regularity of Eb follows from that of b by a smooth cutoff/product argument;
the explicit derivative norm of Eb is nevertheless needed in D_r. Retaining
both hypotheses is harmless and makes the load-bearing derivative visible.
Interior smoothness alone is insufficient: the density 1_[-1,1] has zero
ordinary interior derivatives but Fourier transform 2 sin(t)/t, with boundary
jumps preventing the asserted whole-line W^(r,1) decay.

Orthogonality of c and h in fact gives the stronger identity

    ||V exp(-itH0)psi||^2 = ||h||^2 |a(t)|^2 + |a'(t)|^2.

The triangle bound in C4 follows. Controlling |a| alone would miss the second
term. Differentiating the actual comparison operator gives

    d/dt [exp(itH)exp(-itH0)] = i exp(itH)V exp(-itH0).

Both tails therefore have the draft's signs. Integrating |t|^-r on either
half-line produces 1/[(r-1)T^(r-1)], including the denominator in C5.

For normalized chi and p=|<c,chi>|^2<1, <Pchi,chi>=1-p and
||Pchi||=sqrt(1-p). Expanding the square gives exactly

    ||Pchi/||Pchi|| - chi||^2 = 2(1-sqrt(1-p)) <= 2p.

Let e_T=sqrt(2) A_r(psi)/T^r and B_T(chi)=D_r(chi)/[(r-1)T^(r-1)].
The negative tail compares exp(iTH0)psi with exp(iTH)Omega_-psi.
Propagate the normalized projected preparation by exp(-2iTH), substitute
Omega_-psi=Omega_+phi, and apply the positive tail to phi. The three errors
are e_T, B_T(psi), and B_T(phi), yielding exactly C7. Kato completeness
makes phi=Spsi normalized. It does not make phi's contact density smooth:
the outgoing W^(r,1) premise must remain. Possible bound-state components
introduced by finite-time projection are covered by this norm estimate.

## 4. Current and a finite-rank placement correction: C8–C9

For unit vectors x,y and bounded self-adjoint B,
|<x,Bx>-<y,By>| <= 2||B|| ||x-y||. Because eta_+ and eta_- lie in P,
their expectations of PgP equal those of g. Comparing both endpoints to
the free incoming and outgoing packets costs

    2||g|| [B_T(psi)+B_T(phi)+2e_T],

which is C8. Commutation with H0 removes the free time dependence. The
supplied scalar multiplier g_a(q)=sin(K_a)cos(2q_a) has that commutation
property; an unspecified interacting placement current does not follow.

For the optional correction, put z_j(t)=<f_j,exp(-itH0)chi>. Then

    |<exp(-itH0)chi, A M A* exp(-itH0)chi>|
       <= ||M|| sum_j |z_j(t)|^2
       <= ||M|| F_r(chi)/|t|^(2r).

Endpoint comparison uses ||J_ext||, while the two free correction
expectations add the stated C9 term. This requires W^(r,1) regularity of
each form-factor density; energy-weighted derivatives are not needed for
this particular expectation bound. Finite support alone proves none of
these regularity assertions or uniform constants.

The physical observable in this argument is P J_ext P acting on P. The
draft's word “restriction” is literal if the stated extension of the
physical current preserves P; otherwise its quadratic-form compression is
the meaning needed here. The formula g+A M A* by itself does not establish
either a chosen physical placement or preservation of P. This is a scope
clarification under the supplied-extension premise, not a failure of C9.

## 5. Conditional stationary algebra: C10–C12

Assume C10, including its positive contact density, spectral normalization,
and resolvent sign. Let mu=<v,gv>, w=(g-mu)v, and s=conj(G)/G. Since
|s|=1 and <v,w>=0, direct multiplication cancels the |v><v| coefficient
and gives the two off-diagonal terms in C11. On span{v,w} the nonzero
eigenvalues are +/-|s-1| ||w||. Finally

    |s-1| = 2 Im(G)/|G| = 2pi rho/|G|,
    ||w||^2 = <v,g^2v>-<v,gv>^2.

The same norm identity holds when w=0. This checks C11's coefficient,
adjoints, and variance. It gives an operator bound, not a sign or a
nonzero current change for every incident state.

In the stationary representation c_E=sqrt(rho)v_E; therefore
b_phi(E)=s(E)b_psi(E). Compact support inside the regular interval and
s in C^r yield the claimed outgoing regularity by the product rule.
Uniform low-energy conclusions still require uniform derivative bounds
for this product, and C9's separate form factors remain separate data.

For C12's final explicit corners, each q lies within E of some
q0 in {0,pi}^3, so every cos(2q_a)=1-2sin(q_a-q0_a)^2 lies in
[1-2E^2,1]. This common baseline is why specifying these corners matters.
The shell range of g_a is at most 2|sin K_a|E^2; the variance of a real
variable in an interval of length L is at most L^2/4. With the two stated
uniform threshold inequalities, C11 is bounded by

    (2pi C_rho/c_G) |sin K_a| E^3.

The resulting O(E^4) bound when |K|=O(E) is valid conditional algebra.
This memo has not proved rho<=C_rho E^2, |G|>=c_G E, their uniform
channel domain, coverage of the entire central shell, or C10. Nor has
it shown uniform packet constants needed to suppress C7–C9 errors on
a joint low-energy/large-time sequence. Kato's theorem alone closes
none of those obligations.

## 6. Direct integral, projection law, and completeness

For a measurable supplied field psi_K in the free fiber absolutely
continuous spaces, finite-time comparison fields are measurable. Their
pointwise limits on that field remain measurable. The reverse wave
limits on the target fiber absolutely continuous spaces similarly
justify measurability of phi_K and the inverse map. Norm differences
are bounded by 2||psi_K||, so dominated convergence gives the stated
strong direct-integral limit. Fiber completeness and these inverse
maps give completeness between the integrals of the fiber absolutely
continuous spaces.

This is weaker than global absolutely continuous completeness. For
example, H(K)=K on one-dimensional fibers over K in (0,1) has no
fiber absolutely continuous states, whereas the global multiplication
operator on L2(0,1) is purely absolutely continuous. Thus dispersing
fiber eigenstates cannot silently be added to the proved range.

b_(K,psi) is linear in psi; A_r and D_r are homogeneous seminorms
on their regularity domain. No normalization of individual psi_K is
needed. Squaring and integrating the pointwise Cook bound gives the
L2 norm of D_r divided by (r-1)T^(r-1). Minkowski then gives the sum
of the two L2 norms without an extra volume or fiber-count factor.
The global removed contact weight satisfies

    p = integral |a_(K,psi)(-T)|^2 dK
      <= ||A_r(.,psi)||_(L2_K)^2/T^(2r).

The exact projection identity applies to the global orthogonal
projection even though its contact complement has infinite rank.
One normalization and p<1 suffice. The final draft correctly states
the new total-momentum density

    f_new(K) = [||psi_K||^2-|a_(K,psi)(-T)|^2]/(1-p).

For p>0 define f_removed(K)=|a_(K,psi)(-T)|^2/p. Then
f_old=(1-p)f_new+p f_removed, proving TV(f_old,f_new)<=p. For p=0
the densities agree. The bound is sharp: an exact two-fiber example
has old weights (1/2,1/2), complete removal of the first fiber,
and new weights (0,1). The final revised text accounts for this
effect in C6–C8 instead of claiming unchanged K weights.

For C9, integrate F_r(K,chi) and use essentially bounded M_K and
J_ext,K for a finite useful bound. The stationary packet estimate
uses the essential supremum over its actual (K,E) support. These
operations do not erase any packet, channel, or regularity premise.

## 7. Independent computational controls and their limits

The independent helper imports no repository code and does not replay
an author runner. It uses an actual 3x3 compression, actual Pauli and
singlet matrices, exact symbolic projection and scattering matrices,
and an explicitly absolutely continuous scalar spectral model. Its
68 checks passed; all eight actual modified source copies exited 1
at the intended scientific assertion. Each process had a 90-second
timeout. The full outputs and tracebacks were read.

| Control | Decisive result |
|---|---|
| H0=diag(-1,0,1), c=(1,1,1)/sqrt(3) | Exact rank-two identity, eigenvalues +/-sqrt(2/3), and decoupled zero state |
| Symbolic Pauli matrices and normalized torus integral | Contact norm coefficient 2, upper bound 6, correct all-pi degeneracy |
| Exact normalized projections | C6 identity at contact weights 0, 1/4, 3/4, and 99/100 |
| Centered differences of actual comparison exponentials | Floating derivative errors 2.400274260444071e-7 and 6.000680405166434e-8 when the step halves; correct sign and second-order behavior |
| H0=E on L2([-1,1],dE), c=1/sqrt(2), psi=sqrt(315)(1-E^2)^2/16 | Whole-line W^(2,1) endpoint traces; exact A2=sqrt(210)/3 and energy-weighted derivative norm 39sqrt(70)/80 |
| Exact Fourier transform versus 65-digit quadrature | Largest discrepancy about 3.08e-62 over six times; contact derivative sign and both integrand bounds checked |
| Symbolic tail integrals at r=2,3,5 | Exact (r-1) denominator and T exponent |
| v=(1,i,2)/sqrt(6), g=diag(-2,1,5), G=2+3i | Exact variance 269/36, current-change norm squared 269/13, phase and adjoint identities |
| Actual two-fiber projection | Changed K law with TV=p=1/2 |

The actual mutants omit a rank-one term, double the torus measure,
omit normalization, reverse the Cook derivative sign, insert an
extraneous Fourier 2pi, remove the tail denominator, interchange
the scattering adjoints, and assert unchanged K weights. These
checks detect those specific errors; their number is not evidence
of exhaustive coverage. In particular, finite matrices cannot test
infinite-volume wave-operator existence or absolute continuity.
Quadrature and finite differences are floating examples, not proofs
of the universal bounds. The analytic derivation supplies those bounds.

An initial helper comparison used structural equality of differently
factored but equal symbolic characteristic polynomials. That helper
assertion failed and was corrected to test their simplified difference.
The initial source and traceback are preserved. This was a checker
representation error, not a changed scientific target or a hidden pass.

Key evidence identities are:

| Artifact under S/excluded_walk_review | SHA-256 |
|---|---|
| cook_independent_check.py | `b773b5d413a8649b138893a5985d9792bee1a60dc1839b8a03e6971e8f2c83a6` |
| run_independent_controls.py | `50aa75ad9726f7d3d38814bd42e6f4082b2967c0fd6e511aa0107e66a7a8a0f0` |
| control_manifest.json | `a3b06aeb4c767d213a6e5cf98b10989be22a8034a159bb30e30c63678a89c545` |
| control_run.log | `0b49184f86efea1471643b930a0c8f596d88947a6995562fc39fde56ceddb41d` |
| baseline.log | `21fbf8d9550d2c442d71387b164338d999f376bef4655a2faf0c0884ab64c3d7` |
| first_structural_equality_source.py | `179bfd078609b7f5ddaae2993075803523606a1ed057b6d845e2e172c1503a03` |

The manifest records exact mutant edits, sources, commands, exits,
durations, intended assertions, and log names. The receipt records
all helper/log/source identities and the final memo's identity.
The execution environment was Python 3.13.5, NumPy 2.4.4,
SciPy 1.17.1, SymPy 1.14.0, and mpmath 1.3.0. The command was
`/opt/homebrew/opt/python@3.13/bin/python3.13 run_independent_controls.py`
from the evidence directory, with each child source path recorded
absolutely in the manifest. Inputs are literal fixtures in the helper;
there is no unstated coordinate data or random seed.

## 8. Remaining obligations and disposition of this review

No consequential defect was found in the final C1–C9 or direct-integral
estimates under their explicit assumptions. The direct-integral
corrections are incorporated in the source identity reviewed here.
The following remain outside the established conclusion:

1. A primary-source or independent proof of C10 with this contact
   normalization and resolvent convention.
2. The uniform threshold estimates and entire-shell geometry needed
   for C12, restricted to their actual central channel.
3. Uniform incoming/outgoing packet derivative bounds if a scaled
   low-energy finite-time statement is desired.
4. A specified interacting placement current, its finite-rank
   extension/compression, and its form-factor regularity for C9.
5. Any identification of the fiber-scattering range with the full
   global absolutely continuous subspace, or derivation of the
   supplied walk and exclusion law from physical axioms.

The packet is ready as a source-bound independent check of the stated
conditional finite-time bridge. It supplies no retained-status change,
threshold certification, new physical law, or claim of universal
relaxation. Only this external memo and its evidence directory were
created or edited for the review; no editable prompt, repository
science source, earlier qubit packet, or platform instruction changed.
