# Source-bound independent review of the excluded-walk publication candidate

2026-10-11. This is a bounded research review, not a formal claim-audit verdict,
retained-status decision, or Lean certificate. It preserves the selected model
and reasoning effort. The frozen particle, qubit, and original walk sources were
not edited. No repository, worktree, PR, or audit mutation was performed.

No consequential defect remains in the reviewed combined theorem under its
explicit supplied walk, exclusion, clock, and canonical energy-placement
premises. The coherent packet has the claimed nonzero fourth-order coefficient,
and its verified global regularity bounds make the finite-time error smaller
than that signal. An operator-scope wording defect was found in the packet
draft and corrected by its author before the final freeze: the physical current
is the compression of `g+F`, not generally its literal restriction to P.

This conclusion is bound to the exact candidate and runner below. It does not
adopt these model premises as native framework laws, establish a relaxation
rate, or supply a universal direction of current change.

## 1. Source identities and actual reading coverage

Let S be
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and W be its sibling `worktree`. All short paths in this report are relative
to S unless explicitly prefixed W.

| Source | SHA-256 and coverage |
| --- | --- |
| `FINAL_EXCLUDED_WALK_NOTE.md` | `dbcd5c3685898054fa6b6e38b9aa695985a08157948fa3e4e81f7eddca66667c`; all 1,278 lines covered: the complete 793-line base was read, an exact byte comparison confirmed it is the full unchanged prefix, and every added line through the final scope footer was read. |
| `FINAL_EXCLUDED_WALK_NOTE_BASE.md` | `c73b325fc0146d61089c923bd7473ff82f8a494f4b6ec4b5bffd4b5c361f99c2`; all 793 lines read, including the new differentiated threshold argument and C9 compression wording. |
| `EXCLUDED_WALK_COHERENT_PACKET_DRAFT.md` | `b4ae921cc065fb2f38c1caee5aca3a1cf69bac317a6f6f0f537becd393b6cd38`; all mathematical and scope content read. The complete preceding source at `3b459bcd6b63f89fc3cd5b8f90ec03259401c38ba90c96fafb8eed14a488d925` was read, and the final P3 change was checked with its surrounding argument. The frozen file has 522 lines. |
| `root_walk_primary.py` | `c3fa78eed004b57bb8deb704d38c307566c7d707be33d06983cbef26f31ea70d`; complete 420-line source read and replayed once. This composite author primary is not counted as an independent derivation. |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526`; all 322 lines and necessary exact premises were read in my preceding threshold review, reused unchanged here. |
| `EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md` | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7`; all 262 lines read here, including both time directions, outgoing regularity, and global normalization. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`; all 190 lines read here, including the H1/core paragraph and J1–J12. |
| `EXCLUDED_WALK_THRESHOLD_REVIEW.md` | `9168b32dac2634152aa54431dc47dbb91e019818afdc9d84c40c717d51c3f952`; my prior complete reconstruction and independent controls, reused as the unchanged threshold evidence. |
| `EXCLUDED_WALK_COOK_REVIEW.md` | `a145780abbc767a71dd72b5a9fe3fa4ea6c59015ad57818623fcc81d3c62c75c`; complete 326-line separate review read for provenance and its earlier corrections, not treated as a substitute for checking the supplied argument. |
| `EXCLUDED_WALK_CANONICAL_REVIEW.md` | `ced416dce3a7de31b503d73460e2fa449f6ed4e7175400d8376179cbeead0f9c`; all 52 lines read, including the disclosed initial checker failure and missed Cook wording defect. |
| `excluded_walk_review/kato_1957_primary.pdf` | `12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`; the complete five-page extracted text was read here, especially Theorem 1, p.260, and its proof pp.263–264. No new visual inspection of this PDF is claimed. |

The prior threshold report records complete readings of M3/M6/M9 and the
binding source at main `a13caa4885f547c8d206265b031ba7649e539fd9`, with
their exact filenames, hashes, and limited premise use. It also records the
Yafaev source PDF, Theorems 2.3/2.4, and inspected pages 368–371. Those verified
unchanged premises are inherited here. No unreviewed generic-K impossibility
result is being used as a central threshold estimate.

The scientific-review skill and current repository workflow were reused at
their previously checked identities; this did not start an audit operation.
No editable prompt or platform instruction was changed. Source hashes bind
this review despite concurrent unrelated work in W.

## 2. Base composition and external theorem interfaces

The base note correctly states the derivative result needed by the new packet:
for every fixed multi-index alpha on a compact timelike scaled domain,

    partial_(kappa,e)^alpha [G(delta kappa,delta e+i0)-delta A]
                                                     =O_alpha(delta^2).

My earlier reconstruction bounds the outer differentiated integrand by
`C_alpha delta^2/r^4` for `G/delta-A`, and treats the inner ball using a fixed
scaled spectral cutoff and a subtracted Cauchy integral. It does not
differentiate an unsubtracted pole. The base's new (12a) agrees with that
argument, including use of the full matrix inverse near individual cone
points. Each unscaled K or E derivative costs a factor delta inverse. There
is no uniform unscaled C^7 statement at zero, and none is needed below.

The differentiated density remainder follows from smoothness in delta squared
of the positive-shell coarea integrand. Thus `rho/delta^2` has uniform fixed-
order scaled derivatives, while `G/delta` has the requisite bounded scaled
derivatives and a positive real lower bound. These are genuinely the two
inputs used to control outgoing, as well as incoming, packet profiles.

I rechecked the canonical current from the original position factors
`partial_k1=partial_K+partial_q/2` and
`partial_k2=partial_K-partial_q/2`. Symmetrization gives

    D0=i H0 partial_K+(i/2)(h1-h2) partial_q+i partial_K H0.

The integration-by-parts term in the contact row cancels the explicit
`i partial_K H0` term. In the compressed commutator the two derivatives of
the test field cancel, leaving exactly

    J=P g P-|h'><h|-|h><h'|.

The full difference h1-h2 is needed here, not its differentiated-axis summand.
The H1 approximation paragraph suffices to pass from the common finite-support
core to compact-chart smooth sections. The bounded current extension does not
assert boundedness or self-adjointness of the unbounded energy dipole.

I also checked the band consequences J7–J12. In particular, `Pi_band h=H0
Pi_band c` gives `2 lambda eta`, while the separate lower contact weight 1/4
bounds band volume by `4 eta^2`. Combining that volume with the pointwise
h-prime bound gives `4 lambda |sin(K_a/2)| eta`; it is not inferred from
contact mass alone. The endpoint quadratic error uses the global observable
norm, so projection outside the original energy band is covered. The fixed-
time orders and the additional `32 t_a lambda^2 eta^2` term are consistent.

For each K the perturbation is bounded self-adjoint of rank at most two.
Kato's Theorem 1 has the hypotheses needed for the two complete wave maps
between the fiber absolutely continuous spaces. This provides the identity
`Omega_-=Omega_+ S`, including in the presence of other bound states. The
stationary rank-one formula comes from the separately checked Yafaev interface,
not from Kato completeness alone. The base distinguishes this fiberwise use
from a false assertion of trace class or complete scattering range for the
whole K direct integral.

For the quantitative comparison, both terms of the actual perturbation matter:
if `a(t)=<c,exp(-itH0)psi>`, then

    <h,exp(-itH0)psi>=i a'(t),
    ||V exp(-itH0)psi||<=||h|| |a(t)|+|a'(t)|.

Whole-line W^(r,1) regularity, including the endpoint traces, yields the stated
tail denominator `(r-1)T^(r-1)`. The incoming and outgoing time signs in C5–C7
are correct. The normalized projection costs at most `sqrt(2)||C psi||`;
the two endpoint expectation comparisons give C8. In C9 each form-factor
coefficient decays as T inverse to the r power, so its quadratic expectation
decays as T inverse to the 2r power. The final base explicitly says compression
of J_ext; this is the operator needed for that argument.

## 3. The smooth angular section and the exact nonzero coefficient

The chosen compact domain has kappa_1 at least 3/32 and
`e^2-|kappa|^2>=1575/1024`. It stays strictly within the central timelike
region. All individual momenta on the scaled positive shell stay separated
from their cone points. The radial slope is bounded below uniformly, so the
implicit root and spectral projectors are smooth in lambda squared and in
the scaled parameters. They may be treated in the fixed ambient space of
eight C^4-valued sphere sections. The positive-band ranges form its smooth
subbundle; no choice of eigen-spinor phase is required.

Indeed `Pi_++ c` never vanishes because its squared norm is at least 1/4.
The coarea factor is `r/sqrt(S_r)`, hence `Zc=lambda z_c`. Normalizing by
the positive `rho/lambda^2` gives a smooth unit v. Exchange sends q to minus
q and swaps the two spins; the singlet transforms with the required minus
sign. The even multiplier g therefore preserves this antisymmetric section.
The use of all eight relative corners and the full torus introduces no
additional exchange factor. The final P9 interval qualification correctly
limits its isometry claim to the positive spectral interval in use.

Here is an independent derivation of the limiting variance. Let
`k=|kappa|`, `D=e^2-k^2`, and write the two focal distances as r1,r2.
Prolate coordinates have

    Jacobian=k^3(u^2-vp^2)/8,
    r1 r2=k^2(u^2-vp^2)/4,
    contact weight=D/(8 r1 r2).

Multiplying these factors and the energy delta function at e=ku leaves
`D dvp dphi/16`. Eight corners with normalized torus measure therefore give
`rho0=D/(4 pi^2)`. Conditional on energy and contact, vp is uniform on
[-1,1], phi is uniform on [0,2pi), and each corner has weight 1/8.

Let t=kappa_1/k. Rotate only the transverse coordinate basis, so

    y1=(e t/2) vp + (sqrt(D) sqrt(1-t^2)/2)
                                      sqrt(1-vp^2) cos(phi).

Integrating phi first and then vp gives, with
`beta=D+kappa_1^2`,

    <y1^2>=beta/12,
    <y1^4>=beta^2/80,
    Var(y1^2)=beta^2/180.

This direct prolate integration was separately implemented symbolically; it
does not import the author's sphere-monomial routine. Since
`gamma0=-2 kappa_1 y1^2`,

    d0=kappa_1 beta/(3 sqrt(5))>=D_min/(32 sqrt(5))>0.

The variance itself is smooth in lambda squared before taking its square
root. Its compact derivative supremum C_V is finite, and the restriction
`lambda_0<=d_min/sqrt(2 C_V)` gives `d_lambda>=d_min/sqrt(2)`; when C_V is
zero that extra restriction is unnecessary. Thus the angular normalization
defining u has no hidden zero or singularity, and u has uniform derivatives
through order seven (indeed each fixed order).

For unit v,u with `<v,u>=0`, put `chi=(v+i epsilon u)/sqrt(2)`. Direct
two-by-two multiplication gives

    <chi,(S* g S-g)chi>=epsilon sigma Im(s),
    sigma=lambda^3 d_lambda,
    Im(s)=-2 Re(G) Im(G)/|G|^2.

This sign is compatible with the fixed resolvent and wave-operator convention.
The threshold expansion then yields

    <chi,(S* g S-g)chi>
       =-epsilon lambda^4 kappa_1 beta D/(6 pi sqrt(5) A)
                                                        +O(lambda^5).

I checked the positive uniform lower bound independently. Folding the torus
to eight cubes, using `|sin x|>=2|x|/pi`, and enlarging the cube to its
circumscribed ball gives `I0<=sqrt(3)pi/8`. Combining kappa_1>=3/32,
e<=7/4, beta,D>=D_min and A<=e I0 gives exactly

    c_*>=D_min^2/(14 pi^2 sqrt(15))=c_min>0.

The opposite coherent sign reverses the leading current change. A packet
exactly aligned with v has zero asymptotic expectation change. These are
actual controls against a universal-loss interpretation, not failed versions
of the proved signed witness.

## 4. Global packet normalization and both outgoing form factors

The normalizers in P21 use `d^3 kappa/(2pi)^3` and ordinary de. With those
measures, the amplitude lambda inverse squared in P22 gives

    ||Psi||^2=lambda^-4 lambda^3 lambda
                 integral |alpha|^2 d^3kappa/(2pi)^3 integral |f|^2 de=1.

Individual K fibers have norm `lambda^(-3/2)|alpha(K/lambda)|` and are not
renormalized. The inverse coarea representation gives a genuine free packet:
the angular section is in the positive-band range, its envelopes have all
boundary derivatives zero, and the coordinate changes are nonsingular on
the support for every positive lambda. Smoothness need not be uniform in
unscaled physical momentum to establish this assertion.

The three scalar densities at K=lambda kappa, E=lambda e are exactly of
amplitudes lambda inverse, one, and lambda respectively:

    b_c=lambda^-1 alpha B0,
    b_h=alpha e B0,
    b_hprime=lambda alpha B2.

For the outgoing packet B0 is multiplied by s, not its conjugate. The h
identity is exact because `Zh=E Zc`. For h-prime, its pointwise two small
sine factors contribute lambda squared and the coarea factor contributes
one further lambda. Thus `Z hprime=lambda^3 zeta_prime`, with a uniformly
smooth scaled section retaining the projectors and corner signs. This is
stronger than a bound on its pointwise magnitude: it controls its energy
derivatives as required.

The quotient `s=1-2pi i lambda r_lambda/(G/lambda)` has uniform first seven
scaled energy derivatives, since the denominator has a uniform positive
real part and the differentiated threshold estimates apply. The outgoing
chi and its h-prime profile therefore satisfy the same finite-order bounds.
This explicitly checks the outgoing interface instead of assuming small
phase implies smoothness. The smooth compact envelopes supply whole-line
W^(7,1) profiles and all integration-by-parts boundary traces.

At fixed K, each physical energy derivative costs lambda inverse, the L1
energy norm contributes lambda, and taking L2 over K contributes lambda to
the 3/2 power. Consequently the exact exponents of the three global norms
are `3/2-r`, `5/2-r`, and `7/2-r`. This gives P30 and P31 including their
normalized total-momentum measure. The product-rule constants in P29 also
check: differentiating e B0 gives `e B0^(r)+r B0^(r-1)`; the two-form-factor
inner product uses the full binomial product rule. The constants are finite
specified functionals, not evaluated numerical certificates.

The asymptotic finite-rank expectations vanish by the Riemann-Lebesgue lemma
for their absolutely continuous scalar spectral measures. Their total
variation is finite by Cauchy-Schwarz, so their densities are L1. The bounded
K-dependent form-factor norms and the integrable fiber packet norm squared
justify dominated convergence. The packet expectation is therefore the
weighted integral of the shell result with coefficient C>=c_min; it is not
a delta-normalized fixed-K assertion.

## 5. Finite-time constants, preparation, and the positive range

For r=7 the contact global seminorm is O(lambda^(-11/2)). At
`T=lambda^(-3/2)`, the incoming-plus-outgoing Cook error is at most

    (D_bar/6)lambda^(7/2),

and the normalized projection cost is at most
`sqrt(2) bar C_(0,7)^in lambda^5`. The removed probability is bounded by
`[bar C_(0,7)^in]^2 lambda^10`. These powers include the total-momentum
volume; using independently normalized fibers would give incorrect powers.

Global projection generally changes the K distribution. If p is its removed
mass, the original distribution is the mixture of the normalized survivor
law and removed law with weights 1-p,p, so their total-variation distance
is at most p. The proof uses one global normalization and propagates that
prepared state for duration 2T. Potential components outside the free band,
including bound-state components, are covered by the norm comparison.

On the K support, `|sin K1|<=5lambda/32` and
`||F1||<=sqrt(3)5lambda/32`; thus
`||J_ext||<=(1+sqrt(3))5lambda/32=J0 lambda`. This is a global q norm and
applies to the prepared state's non-band components. The endpoint comparison
therefore gives the following four terms, with exactly the source constants:

    (J0 D_bar/3)lambda^(9/2),
    4 sqrt(2) J0 bar C_(0,7)^in lambda^6,
    ([bar C_(1,7)^in]^2+[bar C_(1,7)^out]^2)lambda^12,
    ([bar C_(2,7)^in]^2+[bar C_(2,7)^out]^2)lambda^14.

The last two follow from `lambda^(5-14) T^-14=lambda^12` and
`lambda^(7-14) T^-14=lambda^14`. Their control uses both h and h-prime;
qualitative disappearance of F would not give this finite-time conclusion.
For lambda<=1 all four errors and the O(lambda^5) asymptotic remainder are
bounded by C_tot lambda^(9/2). The restrictions in P36 make the preparation
defined and make this error at most `(c_min/2)lambda^4`. A positive range
exists because the finitely many constants are finite and c_min is positive.
No maximal numerical range or certified numerical preparation horizon is
claimed.

As a useful failure discriminator, r=6 would only give a Cook state error
O(lambda^3) and current error O(lambda^4) at this T. It cannot separate the
leading fourth-order coefficient by this estimate. The r=7 calculation
does separate it and yields P37 for both coherent signs.

## 6. Correction found and final-source scope

At packet source `3b459bcd...`, P3 said that J on P equals the restriction of
`J_ext=g+F`. In general `C g P` is nonzero, while C F P=0, so J_ext need
not preserve P. I sent this concrete scope correction to the author via
root. Frozen source `b4ae921c...` and combined source `dbcd5c36...` state
`J=P J_ext P` and equality of expectations on P explicitly. No equation or
estimate required alteration, since all endpoint arguments already used
that compression. C9 in the base has the same correct qualification.

The final claim scope is supported as written: a supplied central
three-dimensional two-record scattering theorem, explicit finite-time band
bounds for the canonical placement, and a smooth, normalizable, signed
coherent witness with the stated controlled preparation. The claims do not
extend to other total corners, open mixed channels, two-dimensional
thresholds, arbitrary energy placements, many-body dynamics, native-law
selection, irreversible dissipation, or a physical transport rate.

The full proof depends on the checked analytical threshold and scattering
interfaces, not on finite quadrature output. The same applies to the
uniform derivative constants and the existence of the sufficiently small
positive lambda range. The scope footer makes these limits explicit.

## 7. New independent finite controls and author replay

New evidence is under `excluded_walk_publication_review/`:

| Artifact | SHA-256 |
| --- | --- |
| `independent_packet_controls.py` | `9d95f7d4ad95036af15dc4c475761f16f0cbcffd4a934e9173e1b74fff9460e4` |
| `independent_packet_controls.log` | `887757a1d5c34cd7ac51e0334760474f95b1d354ff07cc461c0314e0ef496b48` |
| `author_primary_replay.log` | `ab87a1ea0b6ebe4bfc46fb55381006685fa91a5712459582f7cafc359ebafe06` |
| `independent_packet_controls_initial_tolerance.py` | `9b0680c6ed866a28c0ace713653c9bd3086f756912d8a1f4440a78436c3e1c52` |
| `independent_packet_controls_initial_tolerance.log` | `0aabc13e181fbf560b04b863a8436a2dc907018f2700cfdbd87541dc52f06f0b` |
| `tolerance_diagnostic.log` | `0213ddc01f711bb0d2f33435fbce94fff6f03a95b264f7b7da42db95aefda4b8` |

The independent helper imports no author or repository code. It derives
the prolate contact measure and second/fourth moments symbolically, derives
the complex coherent expectation using a generic Cayley phase, and performs
exact physical-variable norm integrals for compact polynomial K/E envelope
fixtures with the required seven vanishing endpoint traces. These fixtures
check normalization and derivative powers; they are not the source's
particular C-infinity bump envelopes.

A separate numerical part forms the actual 4x4 Pauli positive projectors
in all eight lattice corners, solves the physical radial shell, and performs
Gauss-Legendre/azimuth coarea quadrature. It never inserts the asserted
singlet contact weight as input. It checks the normalized v,u sections,
`Zh=E Zc`, the actual h-prime form factor, and the continuum variance for
both axial and off-axis kappa at lambda=1/16,1/32,1/64,1/128. At
`kappa=(1/8,0,0), e=3/2, lambda=1/128`, for example,

    rho/lambda^2=0.056598358311952,
    limiting rho0=0.056597379925212,
    d_lambda=0.041926279345509,
    limiting d0=0.041926274578121.

Halving lambda contracts both errors by approximately one quarter. The
printed coherent current in this numerical part uses a synthetic positive
real boundary value `Re G=lambda` with the computed contact density. It
is explicitly an algebraic phase fixture, not a numerical computation of
the walk's principal-value resolvent or its actual scattering phase.
No claim of PV quadrature, infinite-time propagation, or interval-certified
uniform estimate is made.

The first helper run failed a reviewer-chosen density tolerance
`error<0.01 lambda^2`: at e=3/2 its second-order density coefficient is about
0.016, so that tolerance was too tight. The failed source and traceback
are preserved. A diagnostic run with Python's assertions disabled printed
the values and is not counted as validation. The finite-fixture threshold
was changed to 0.02; the separate successive-scale contraction and all exact
symbolic and projector assertions remained in force. The final ordinary
Python run exited 0 in 0.620 seconds. This was a reviewer tolerance error,
not a defect in the theorem or a changed scientific target.

The final independent execution used Python 3.13.5, SymPy 1.14.0, NumPy
2.4.4 and SciPy 1.17.1. The command was
`python3 independent_packet_controls.py`, working in the evidence directory;
the runtime executable resolves to `/opt/homebrew/opt/python@3.13/bin/python3.13`.
All inputs are literal deterministic fixtures. The complete log was read.

The unchanged primary `root_walk_primary.py` was replayed by
`python3 root_walk_primary.py` from S, exiting 0 in 5.934 seconds. Its
35-line output was read completely. This is a source/output consistency
check only, not a second independent derivation of its incorporated earlier
helpers. I also read the author mutation driver, manifest, and all twelve
complete mutant tracebacks. Exact source-copy substitutions and source
hashes were checked. They support the footer's narrow statement about
actual altered sources failing at their intended assertions; those author
mutation executions were not rerun or counted as independent evidence.

## 8. Remaining limits and possible formalization obligations

No further mathematical repair was identified in this bounded review. Its
analytic conclusions and new finite controls support the frozen candidate's
stated scope. They do not amount to machine-checked proof or an applied
retained-status audit.

Potential separate formalization obligations are: the Pauli and compression
identities with the normalized antisymmetric space; the coarea isometry and
exchange constraint; parameter-uniform subtracted Cauchy integrals; the
precise imported scattering theorems and measurable direct integral; the
energy-dipole common-core argument; smooth variance normalization; global
packet/profile scaling; and the two-sided Cook/preparation/current comparison.
No Lean process was executed here.

The independent helper and this report are the only new review sources;
their raw logs and identity receipt are in the named evidence directory.
Earlier particle/qubit files, author drafts, repository sources, worktrees,
and editable prompt files remain untouched by this review.
