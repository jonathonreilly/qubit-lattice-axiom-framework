# Independent review: excluded-walk threshold and packet estimates

**Date:** 2026-10-11. **Disposition:** no consequential defect found in the stated positive claims of the frozen probe below. This is a source-bound mathematical research review, not a formal audit or retained-status decision.

The all-channel contact resolvent, explicit central regular domain, uniform scaled threshold expansion, stationary rank-one scattering formula, and separate finite-time estimates (21)–(23) are supported under the supplied model. The differentiated expansion is justified for each fixed finite derivative order in the **scaled parameters** \((\kappa,e)\); it must not be read as a uniform bound on unscaled energy/momentum derivatives at zero. The reconstruction below supplies the detailed domination and subtraction argument behind that point.

The separate Cook bridge and canonical-current drafts are not premises of this review and were not used. No generic-K conclusion from the older no-go notes is used to establish the central threshold estimates.

## 1. Source identities and actual coverage

All relative links below are relative to this report's directory.

| Source | SHA-256 | Review coverage |
|---|---|---|
| [EXCLUDED_WALK_TRANSPORT_PROBE.md](EXCLUDED_WALK_TRANSPORT_PROBE.md) | 8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526 | Complete 322-line frozen probe. |
| [Author helper](excluded_walk_probe/exact_and_shell_checks.py) | d2bc72a63fd588a9068884b7091ebbfd7a9eddf25be48cc0321a4458317ba9b1 | Complete 215-line source; finite coverage and limitations checked. |
| [Author log](excluded_walk_probe/exact_and_shell_checks.log) | a0b6f6729d95dbfb15b9690203f784b99da1b96fad9be8122e5bdc3a438ef8f7 | Complete 19-line output; not counted as independent verification. |
| [Author identity manifest](excluded_walk_probe/identity_manifest.json) | e88f2ec2a92dbeee3c5ce9225e9d29599e90907ee7df4b176aaf369f139a375c | Complete manifest read; source identities checked. Its Cook entry is explicitly excluded as a premise. |
| [Yafaev primary PDF](excluded_walk_probe/yafaev_1992_scattering.pdf) | 6852364a4b5fccc6a8db834b5ef11e9cabcc8c5dae4c1c98ae171c0322ffe4c6 | Section 2 setup through Theorem 2.4 and (2.9), journal pp.368–371. All load-bearing formulas inspected visually. Later constant-sign applications not imported. |
| [Independent helper](excluded_walk_threshold_review/independent_controls.py) | 73801d139ab5aeebd904d374f0ad5ab8fd9a125a167098e54fa8540e9ba0065a | New exact symbolic and separately labeled finite unitary controls; no repository/author-runner imports. |
| [Independent full log](excluded_walk_threshold_review/independent_controls.log) | 427a70da78041a3c4f76143cbecc8abe2e5cedc9616da04ea5f17d6b30632355 | Exit 0, complete output read. |

The four repository premises were read completely, at bytes verified identical to frozen main a13caa4885f547c8d206265b031ba7649e539fd9:

| ID | Exact path relative to W | SHA-256 |
|---|---|---|
| M3 | docs/ADMISSIBILITY_RULE_NO_FINITE_RANGE_INTERACTION_KEEPS_TWO_EXCLUDED_RECORDS_TOTAL_ENERGY_CURRENT_ON_THE_PLANE_OR_IN_SPACE_BOUNDED_THEOREM_NOTE_2026-09-26.md | 996dbbc8cebb88bd94f00336fcfebcab97f01209c9a1f717117567f5a2394cb5 |
| M6 | docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md | e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065 |
| M9 | docs/ADMISSIBILITY_RULE_EXACT_BOOKS_NEED_RECORDS_THAT_NEVER_SCATTER_OR_BIND_NOTHING_LOCAL_KEEPS_THEM_UNDER_ONE_RECORD_PER_SITE_BOUNDED_THEOREM_NOTE_2026-09-25.md | 06c78db9394c0a7ffc39f08385d3cf2bb6aaa528639c2b4e34994ed00ed6d88a |
| B | docs/ADMISSIBILITY_RULE_A_REST_ENERGY_FROM_BINDING_TWO_WALKERS_IS_EXACT_WITH_THE_WALKERS_OWN_SPEED_IN_ONE_DIMENSION_INVISIBLE_UNDER_ONE_RECORD_PER_SITE_AND_ANISOTROPIC_IN_THREE_BOUNDED_THEOREM_NOTE_2026-09-24.md | 50c708e3742f9a5daa59f6f1fb48b44fe388d71b9fc2454ede1a9595185d332d |

W is /Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/worktree. These reads covered 283, 226, 230 and 106 lines respectively. The needed inputs are the supplied Weyl symbol, antisymmetric contact vector, exact exclusion/compression, additive free current, and dispersion inequality. M3's generic-K spectral-density proof and M9's conditional determinant bridge are not substitutes for the present threshold proof. B uses the opposite resolvent convention and proves an off-spectrum contact identity; that is not imported as a positive-energy boundary theorem.

Yafaev's formulas were inspected in the supplied rendered pp.369–371. A fresh lossless page-image extraction of journal p.368 is retained at [yafaev_journal_368.png](excluded_walk_threshold_review/yafaev_journal_368.png), confirming the wave-operator convention and \(S=W_+^*W_-\). The paper is *On the scattering matrix for perturbations of constant sign*, Ann. Inst. H. Poincaré 57 (1992), 361–384. Only its sign-independent abstract Section 2 is used.

The author search logs were identity-checked; the unrelated historical hit corpus was not rereviewed as an additional source of premises or novelty evidence. The complete earlier particle and qubit work remains frozen and is not used here.

## 2. All-channel contact resolvent and exceptional fibers

An independent derivation avoids diagonalizing each numerical pair matrix. Set
\[
 H=a\cdot\sigma\otimes I+I\otimes b\cdot\sigma,\quad
 A^2=|a|^2,\ B^2=|b|^2.
\]
The commuting two tensor terms imply
\[
 H^4-2(A^2+B^2)H^2+(A^2-B^2)^2I=0.
\]
Consequently
\[
 (H-z)^{-1}
 =\frac{(H+z)[2(A^2+B^2)-z^2-H^2]}
 {(A^2+B^2-z^2)^2-4A^2B^2}.
\]
For the normalized singlet,
\[
 \langle H\rangle=\langle H^3\rangle=0,\qquad
 \langle H^2\rangle=|a-b|^2.
\]
Its expectation is therefore precisely
\[
 \frac{z(|a+b|^2-z^2)}
 {[(A+B)^2-z^2][(A-B)^2-z^2]}.
\]
The independent helper verifies this polynomial identity for arbitrary six real vector components, not merely selected inverse matrices. It also verifies the sum of the four projector-weight fractions and the large-z limit \(-1/z\), fixing the \((H-z)^{-1}\) sign. Individual cone points are treated by the matrix identity, without an eigenvector gauge.

Normalized full-torus measure and the constant unit singlet give contact mass one in the antisymmetric Hilbert space. There is no extra exchange factor two. The dispersion inequality
\[
 |\epsilon(q+K/2)-\epsilon(q-K/2)|\le\epsilon(K)
\]
follows directly from subadditivity of \(|\sin k|\). Thus \(|K|\le E/4\) closes the mixed channels at positive E, while preserving their virtual contribution to G.

The low-energy mixed-channel counterexample outside this gap is valid: at \(K=(\pi/2,0,0)\), \(q=(\arcsin(E/\sqrt2),0,0)\), \(A-B=E\), both individual energies approach \(1/\sqrt2\), and the positive mixed weight is 1/2. Low pair energy alone does not justify deleting this channel. This does not contradict M6's statement for an incoming ++ pair, whose energy must be at least \(\epsilon(K)\).

At a total corner with r components equal to pi, \(A=B=\epsilon_C\) and the combined zero-energy weight is
\[
 f_C=\frac{\sum_{j:C_j=\pi}\cos^2q_j}{\epsilon_C^2}.
\]
Coordinate shifts and permutation symmetry give the weighted radial average r/3, proving (2), including the atom \(-r/(3z)\). For r=3, \(H_0c=0\); the contact subspace is already reducing and its removal changes no complementary dynamics. A uniform strictly positive scattering effect over all total corners is false. The probe preserves this counterexample and confines its positive threshold conclusions to the central corner. At K=0 the displayed current is identically zero even though scattering need not be trivial.

## 3. Explicit central shell and principal-value control

I reconstructed (3)–(9), including their constants.

For \(E\le1/8\), \(|K|\le E/4\), put \(k=K/2\) and \(h=|k|\le E/8\). On a ++ shell, both individual dispersions are <=E. Their coordinatewise nearest pi-corners must agree because their separation is too small to cross the distance \(\pi-2\arcsin E\). In each of eight disjoint charts \(q=C+x\), \(r=|x|\),
\[
 \sqrt{1-E^2}(|x+k|+|x-k|)
 \le E\le |x+k|+|x-k|\le2r+2h.
\]
This gives \(3E/8\le r\le E/[2\sqrt{1-E^2}]<9E/16\), with complete shell coverage.

The elementary gradient estimate
\[
 \left|\nabla\epsilon(y)-y/|y|\right|\le5|y|^2/6
\]
comes from cosine error \(|y|^2/2\) plus normalized-vector error \(|y|^2/3\). On \(r\in[E/4,E]\), the Euclidean radial derivative is >=1/3 and the error is <5/96. Hence each summand has radial derivative >1/4 and their sum lies in [1/2,2]. The endpoint energies bracket the full interval used in the proof, so each ray has exactly one root.

The contact weight is positive because
\[
 \sin(rn+k)\cdot\sin(rn-k)=\epsilon(rn)^2-\epsilon(k)^2>0.
\]
Thus \(1/4\le w\le1/2\). Integrating the eight identical coarea charts with the stated normalized measure gives exactly the lower and upper constants in (7). No angular incoherence or half-torus convention enters.

For the neighboring energy interval \([7E/8,9E/8]\), the common ray interval remains valid. Individual norms satisfy \(\epsilon(rn\pm k)\ge3E/32\). Differentiating normalized sine vectors yields
\[
 |w_r|\le16/(3E)<6/E.
\]
The norm-composition Hessian satisfies
\(\|\nabla^2\epsilon\|\le1/\epsilon+\epsilon\le2/\epsilon\), whence
\[
 |S_{rr}|\le128/(3E)<44/E.
\]
With \(F=wr^2/S_r\),
\[
 |F_u|\le(6E+E)\,4+(E^2/2)(44/E)\,8=204E.
\]
The angular normalization is \(4/\pi^2\), giving the bound \(816E/\pi^2\) in (8).

Subtracting the central density in the Cauchy integral over the symmetric interval gives real PV contribution <=\(204E^2/\pi^2\). The constant part has zero real PV. The remaining positive, negative and mixed spectral contributions lie at distance >=E/8 and have total mass <=1. Their contribution is therefore <=8/E. The sign of the boundary value is
\(\operatorname{Im}G=+\pi\rho\). These facts prove (9) and its inverse bound without importing a generic-K limiting-absorption theorem.

The same local coordinates are smooth on compact positive-energy subdomains. Individual projector singularities occur only off the positive shell; there the full matrix resolvent is smooth and bounded. This supports the stated local \(C^\infty\) regularity.

## 4. Uniform threshold expansion, including derivatives

The claimed (12) is supported. The following spells out the required uniform argument, including the terse differentiated sentence in the source.

Fix \(0<e_-<e_+<\infty\) and
\[
 \mathcal D=\{(\kappa,e): e_-\le e\le e_+,\ |\kappa|\le e/4\}.
\]
For differentiation at its boundary, work in a slightly larger compact timelike neighborhood, for example with ratio strictly below 1/3 and a slightly enlarged positive energy interval. Constants below may depend on that neighborhood and the fixed derivative multi-index, but not delta.

At real energy in the mixed-channel gap,
\[
 \frac{G(\delta\kappa,\delta e+i0)}{\delta}
 =e\int\frac{W_\delta(q)}
 {S_\delta(q)^2-\delta^2e^2-i0}\,dq,
\quad
 W_\delta=\frac{e^2-|a+b|^2/\delta^2}
 {e^2-(D_\delta/\delta)^2}.
\]
The gap gives uniform positive denominator and \(1-|\kappa|^2/e^2\le W_\delta\le1\). The limiting weight is
\[
 W_0=\frac{e^2-|\kappa\odot\cos q|^2}
 {e^2-(\kappa\cdot v(q))^2}.
\]
This is the coefficient in (10); omitting virtual mixed channels would incorrectly replace it by one. An exact rational limiting example in the independent helper gives \(W_0=75/77\).

### Outer region

Choose disjoint cone balls of fixed radius \(r_0<1\), and a fixed R large compared with the compact upper energy/momentum bounds. For \(R\delta\le r\le r_0\), all shifted points stay at distance comparable to r from a cone. Norm-composition differentiation gives
\[
 |\nabla^j\epsilon|\le C_j r^{1-j}.
\]
Symmetric Taylor formulas with integral remainders consequently give, together with every fixed \((\kappa,e)\)-derivative,
\[
 S_\delta-2\epsilon=O(\delta^2/r),\quad
 D_\delta/\delta-\kappa\cdot v=O(\delta^2/r^2),\quad
 |a+b|^2/\delta^2-|\kappa\odot\cos q|^2=O(\delta^2).
\]
Higher parameter derivatives of these remainders do not introduce an uncontrolled singularity: each extra spatial derivative is accompanied by a delta factor, and \(\delta/r\le1/R\). Factors polynomial in bounded kappa are harmless.

It follows that
\[
 S_\delta^2-\delta^2e^2\ge c r^2,\qquad
 S_\delta^2-\delta^2e^2-4\epsilon^2=O(\delta^2),
\]
with corresponding derivative bounds. The mixed denominator remains uniformly separated from zero. The product/quotient rule therefore gives, for each fixed multi-index alpha,
\[
 \left|
 \partial_{\kappa,e}^\alpha
 \left[
 \frac{eW_\delta}{S_\delta^2-\delta^2e^2}
 -\frac{eW_0}{4\epsilon^2}
 \right]\right|
 \le C_\alpha\frac{\delta^2}{r^4}.
\]
Integrating \(r^2dr\) over this annulus is \(O_\alpha(\delta)\), for the integrand of G/delta. Away from all cone balls, the error is \(O_\alpha(\delta^2)\).

### Inner region and the pole

Put \(q=C+\delta p\), \(|p|\le R\). The scaled matrix
\[
 A_\delta(p,\kappa)=\delta^{-1}H_0(\delta\kappa,C+\delta p)
\]
extends smoothly to delta=0. The contact resolvent contributes delta to the minus one and the volume delta cubed, so the inner G contribution is delta squared times a scaled boundary integral.

Uniformly on the compact parameter region, the ++ shell lies strictly inside this ball and stays separated from both individual cone points. Its radial slope is positive. Mixed and negative channels stay separated from e. Choose an even smooth energy cutoff equal to one near e, supported in a fixed interval whose width is small relative to \(e_-\). The associated scaled ++ density \(J(u;\kappa,\delta)\), obtained by coarea, has uniformly bounded derivatives of every fixed finite order on this interval: the implicit radial root and contact projector are smooth, with uniform gap and slope.

Its singular integral can be written with \(t=u-e\) as
\[
 \int\chi(t)\frac{J(e+t;\kappa,\delta)-J(e;\kappa,\delta)}{t}\,dt
   +i\pi J(e;\kappa,\delta).
\]
The omitted constant PV term is zero because chi is even. Every fixed parameter derivative of the numerator difference is \(O_\alpha(|t|)\), by one additional bounded energy derivative of J. This supplies uniform domination after differentiation and avoids differentiating an unsubtracted pole.

Outside this cutoff the matrix inverse is uniformly separated from its poles. Near individual cone points the full matrix inverse, rather than singular eigenprojectors, is smooth. Equivalently a smooth scalar cutoff removes the resolvent singularity before finite-dimensional functional calculus. This part and every fixed parameter derivative are uniformly bounded as well.

Thus the inner contribution is \(O_\alpha(\delta^2)\). The limiting integrand \(eW_0/(4\epsilon^2)\) has all these parameter derivatives bounded by \(C_\alpha/r^2\), so its inner integral is \(O_\alpha(\delta)\), and multiplication by delta gives \(O_\alpha(\delta^2)\).

Together the regions prove the precise supported statement:
\[
 \sup_{\mathcal D}
 \left|\partial_{\kappa,e}^\alpha
 [G(\delta\kappa,\delta e+i0)-\delta\mathcal A(\kappa,e)]\right|
 \le C_\alpha\delta^2
\]
for each fixed alpha and sufficiently small positive delta.

No derivative in delta, bound uniform in derivative order, or uniform unscaled \(K,E\) derivative estimate is established by this statement. Applying an unscaled derivative of total order j costs \(\delta^{-j}\), so the corresponding remainder estimate is only \(O(\delta^{2-j})\) by this argument.

The leading integral is finite because its cone singularities are \(r^{-2}\) in three dimensions. Cauchy-Schwarz gives
\((\kappa\cdot v)^2\le|\kappa\odot\cos q|^2\), yielding (11); \(I_0\ge1/12\) follows from \(\epsilon^2\le3\). With e=1 the positive leading coefficient and the uniform remainder imply a common \(E_*>0\) and the lower real-part bound (13). The proof supplies existence of this threshold, not a certified numerical value.

## 5. Leading density and its normalization

The density remainder (14) is also supported. On the scaled ++ shell, both individual momenta are bounded away from zero. Since \(\sin(\delta p)/\delta\) is smooth in delta squared, the shell root, weight and coarea factor are smooth in that variable. The slope bound is uniform. Thus the density is delta squared times a smooth function of delta squared, giving an \(O(\delta^4)\) remainder uniformly on the compact timelike set.

I independently derived the coefficient using centered radial coordinates rather than the author's prolate coordinates. Put \(k=|\kappa|\), \(\mu=n\cdot\kappa/k\). The limiting shell has radius
\[
 r=\frac{e\sqrt{e^2-k^2}}{2\sqrt{e^2-k^2\mu^2}}.
\]
Writing A,B for the two limiting individual energies,
\[
 AB=e^2/4-r^2k^2\mu^2/e^2,\quad
 w=(e^2-k^2)/(8AB),\quad
 S_r=r(e^2-k^2\mu^2)/(eAB).
\]
Hence
\[
 \frac{wr^2}{S_r}
 =\frac{e^2(e^2-k^2)^{3/2}}
 {16(e^2-k^2\mu^2)^{3/2}}.
\]
The antiderivative of the last denominator power is
\(\mu/[e^2\sqrt{e^2-k^2\mu^2}]\). Angular integration, eight cones and normalized torus measure give exactly \((e^2-k^2)/(4\pi^2)\). The direct k=0 limit agrees. These identities are verified symbolically by the independent helper.

At K=0 the global substitution \(u=\sin q\) has eight preimages with normalized Jacobian \(\pi^{-3}\prod(1-u_j^2)^{-1/2}\). The ++ weight is 1/2 and the radial slope is two. This gives (15) and both its stated bounds for \(0<E<2\). No principal-value quadrature is needed for these normalization checks.

## 6. Stationary theorem hypotheses and current identity

The extension \(H_{\rm ext}=PH_0P\), zero on c, satisfies
\[
 V=-|b\rangle\langle c|-|c\rangle\langle b|,\qquad b=H_0c,
 \quad \langle c,b\rangle=0,\quad
 \|b\|^2=2\sum_j\cos^2(K_j/2)\le6.
\]
Both H0 and Hext are bounded self-adjoint in each fixed fiber.

The exact hypotheses of Yafaev's abstract theorem are met by the specified augmentation. On this separable fiber choose any injective Hilbert–Schmidt Q, for example a positive diagonal operator with summable squared eigenvalues in a fixed orthonormal basis. Then
\[
 Lf=(\langle c,f\rangle,\langle b,f\rangle,Qf),\qquad
 J=\begin{pmatrix}0&-1\\-1&0\end{pmatrix}\oplus0
\]
has \(V=L^*JL\), bounded self-adjoint J, injective L and Hilbert–Schmidt L. Therefore \(LE_0(X)\) is Hilbert–Schmidt for bounded X, and \(L(|H_0|+I)^{-1/2}\) is Hilbert–Schmidt. These are Theorem 2.4's conditions with p=1. The sandwiched resolvent is trace class, hence compact, as required by (2.3). The kernel condition in Assumption 2.2 is explicitly satisfied. The Section 2 theorem does not require J to have constant sign despite the paper's title.

Yafaev consequently supplies complete absolutely-continuous wave operators and the stationary formula almost everywhere in energy. The auxiliary rows make the theorem applicable but do not alter the answer: \(I+B_0J\) is block lower triangular with identity in the auxiliary diagonal block, and multiplication by J kills its auxiliary output.

The active 2-by-2 reduction in (17) is correct:
\[
 \det(I+B_0J)=-zG,\quad
 J(I+B_0J)^{-1}=
 \begin{pmatrix}G^{-1}+z&-1\\-1&z^{-1}\end{pmatrix}.
\]
On shell \(\Gamma_Eb=E\Gamma_Ec\), and its contraction is precisely \(1/G\). Equivalently the extra \(-C/z\) term in the full extended resolvent is necessary and its associated T contribution vanishes on shell. No infinite-coupling scattering limit is assumed.

Since \(\operatorname{Im}G=\pi\rho\), the convention checked from the primary paper gives
\(s=1-2\pi i\rho/G=\overline G/G\). Formula (18) and its unitary modulus follow. The nonzero contact density and denominator permit a smooth local shell representative; the scattering operator itself remains defined up to energy-null sets. Fiberwise construction followed by dominated convergence gives the direct-integral packet statement; it does not require the global decomposable perturbation to be trace class.

For \(w=(g-\mu)v_E\), orthogonality eliminates the diagonal rank-one term in \(S^*gS-g\). The remaining two-dimensional block has eigenvalues \(\pm|s-1|\|w\|\), proving (19), including zero variance. The shell range of \(g_a\) has length <=\(2|\sin K_a|E^2\). Combining its variance bound with (7), (13) gives the constant \(1024/(5\pi)\) in (20), and then \(256/(5\pi)\) after \(|K|\le E/4\). This is a coherent scattering observable estimate, not a collision-event probability or kinetic relaxation rate.

## 7. Finite-time estimates (21)–(23)

These estimates are independent of the stationary theorem and threshold PV expansion.

For \(\lambda\le1/16\), the entire free band \([\lambda,2\lambda]\) and K support lie in the regular domain. Rank-one projection and the spectral theorem give
\[
 \|C1_{[\lambda,2\lambda]}(H_0)\|^2
 =\langle c,1_{[\lambda,2\lambda]}(H_0)c\rangle
 \le\int_\lambda^{2\lambda}4E^2/\pi^2\,dE
 =28\lambda^3/(3\pi^2).
\]
For the decomposable projection, take the uniform fiber supremum. This proves (21) with the correct square root.

The two terms of V yield
\[
 \|Ve^{-itH_0}\phi\|
 \le\sqrt6\,\eta_\lambda+
 \|CH_0e^{-itH_0}\phi\|
 \le(\sqrt6+2\lambda)\eta_\lambda.
\]
Duhamel applies to bounded self-adjoint generators for either time sign. For \(\beta=\|C\phi\|\),
\[
 \|\chi-\phi\|^2
 =2(1-\sqrt{1-\beta^2})\le2\beta^2.
\]
Since \(\eta_\lambda<1\), normalization is well defined, proving (22). The projection may introduce energy outside the original band; the proof never requires otherwise.

The multiplier \(\sin K_a\) commutes with both generators and P, so it cancels in the actual drift even if the global normalization changes the K distribution relative to phi. With \(O_a=g_a-\sin K_a\),
\[
 \|O_a\|\le2s_a,\qquad
 \|O_ae^{-itH_0}\phi\|\le8s_a\lambda^2.
\]
For \(\varepsilon_t=\chi_t-\phi_t\),
\[
 |\langle\chi_t,O_a\chi_t\rangle-
   \langle\phi_t,O_a\phi_t\rangle|
 \le16s_a\lambda^2d_t+2s_ad_t^2.
\]
Subtracting the same comparison at time zero and using free conservation proves exactly (23). The quadratic term cannot generally be dropped: an exact independent two-state control has \(O\phi=0\) but nonzero expectation difference.

For fixed T, \(s_a\le\lambda/4\) and \(d_t=O((1+T)\lambda^{3/2})\) yield the stated \(O((1+T)^2\lambda^4)\) drift. At \(|t|\le T_0\lambda^{-1/2}\), state error is \(O_{T_0}(\lambda)\) and current drift is \(O_{T_0}(\lambda^3)\). No packet smoothness or angular incoherence is needed for this bounded-observable argument.

A separate six-dimensional finite compression with exact low-band contact control was constructed in the independent helper. High-precision unitary evolutions at positive, negative, zero and scaled times satisfy the preparation, Duhamel and current inequalities with nonzero drift. This is a finite control of their abstract algebra, not an approximation of the infinite walk or proof of the density bound.

## 8. Gaps, counterexamples and supported scope

No consequential proof gap or counterexample to the frozen bounded statements was found. The following restrictions remain load-bearing:

- Virtual mixed channels enter the leading central coefficient even when no mixed channel is open on shell. Deleting them gives an incorrect coefficient; the independent exact weight 75/77 is a concrete discriminator.
- Noncentral total corners have zero-energy atoms; the all-pi corner has no contact-induced scattering at all. The central expansion is not a uniform theorem over all corners.
- The differentiated remainder is in scaled parameters. It supplies no uniform physical-energy derivative constants at zero and no all-orders estimate.
- The stationary formula is an almost-everywhere absolutely-continuous scattering result with a regular local representative. The isolated contact zero mode is not an incoming scattering state.
- The finite-time preparation is the normalized projected free packet. It is not an arbitrary hard-core state already confined to the same free energy band.
- The observable is the compressed additive free two-step current. A placement-dependent interacting current or unbounded position observable requires additional estimates.
- The model, continuous clock, exchange sector and exclusion are supplied. No physical collision frequency, kinetic closure, many-body theorem, native-law selection or axiom consequence follows.

The quantified derivative statement in Section 4 of this review would be useful to retain explicitly in any publication, to prevent a later bridge from treating it as an unscaled uniform \(C^r\) assertion. This is a clarification of the already stated derivative scope, not a discovered change to the theorem.

No Lean or other kernel-checked formal proof was executed. Formal obligations remain for shell coverage/coarea, the parameter-dependent subtracted Cauchy integral, the compact-region uniformity argument, and the imported stationary theorem interface. Finite controls do not replace these arguments.

## 9. Raw evidence and provenance

The independent helper and its complete log are linked in Section 1 and inventoried in [review identity manifest](excluded_walk_threshold_review/identity_manifest.json). It uses SymPy exact polynomial/rational algebra and mpmath at 70 decimal digits for separately labeled finite matrix exponentials. Runtime was 0.469 seconds internally; the wrapper exited zero. No author helper was imported or replay counted as independence. No numerical principal-value extrapolation was used as evidence.

The original author helper/log was read in full, including its 48 finite inverse checks and 2048-direction shell quadrature. Its limitations are stated honestly. This reviewer did not redundantly replay it: the new symbolic identities, independently derived radial coefficient, full analytic reconstruction and finite-time controls are the added evidence.

No W file, earlier particle/qubit file, author probe/helper/log, Cook draft, canonical-current draft, editable prompt, skill, commit or PR was changed. Only this report and its new excluded_walk_threshold_review evidence directory were written. No network access, audit verdict or other-chat message was used.

