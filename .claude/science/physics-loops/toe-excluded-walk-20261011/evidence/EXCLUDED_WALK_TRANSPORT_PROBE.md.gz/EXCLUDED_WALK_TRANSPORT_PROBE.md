# Excluded-walk transport probe — central regular domain and packet control

Date: 2026-10-11. Status: external author derivation, with finite controls; no independent audit or retained-status claim. The result is conditional on the supplied three-dimensional Weyl walk, continuous clock, antisymmetric pair sector, exact exclusion and stated observable. It does not derive a physical collision frequency, kinetic closure, native law selection or an axiom consequence.

The positive results below are: an explicit regular contact-resolvent domain; a uniform central threshold expansion; the exact coherent scattering/current identity on that domain; and a separate explicit finite-time comparison for the actual compressed unitary. The final particle review remains separate in `NONLINEAR_PARTICLE_REVIEW.md` at SHA-256 `4aec121de3df2c52d8d913e253a0aa35c04b26a44d630264752dae6945eb400a`.

## 1. Frozen premises and prior-art scope

All walk science is read at repository revision `a13caa4885f547c8d206265b031ba7649e539fd9`, W=`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/worktree`. The earlier source map is `DYNAMICS_OPPORTUNITIES.md`, SHA-256 `fcae61bf9c4f01cea4f755539f72bf46ffe9784acc68eca015b60eb393d64a4b`; its exact path/reading inventory is `dynamics_read_coverage.json`, SHA-256 `a0bdb98658cb4ebdce58e56219d45c82f8c33f7d0b2ba75a0e11beacc7f6f9a9`.

| ID | Exact path relative to W | SHA-256 | Refreshed scope |
|---|---|---|---|
| M3 | `docs/ADMISSIBILITY_RULE_NO_FINITE_RANGE_INTERACTION_KEEPS_TWO_EXCLUDED_RECORDS_TOTAL_ENERGY_CURRENT_ON_THE_PLANE_OR_IN_SPACE_BOUNDED_THEOREM_NOTE_2026-09-26.md` | `996dbbc8cebb88bd94f00336fcfebcab97f01209c9a1f717117567f5a2394cb5` | All 283 lines; generic-total-momentum nonconservation and placement-current distinction |
| M6 | `docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md` | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065` | All 226 lines; exact compression, kinematics, conditional regular-shell scattering and cubic defect |
| M9 | `docs/ADMISSIBILITY_RULE_EXACT_BOOKS_NEED_RECORDS_THAT_NEVER_SCATTER_OR_BIND_NOTHING_LOCAL_KEEPS_THEM_UNDER_ONE_RECORD_PER_SITE_BOUNDED_THEOREM_NOTE_2026-09-25.md` | `06c78db9394c0a7ffc39f08385d3cf2bb6aaa528639c2b4e34994ed00ed6d88a` | All 230 lines; contact overlap and supplied free/current framework |
| B | `docs/ADMISSIBILITY_RULE_A_REST_ENERGY_FROM_BINDING_TWO_WALKERS_IS_EXACT_WITH_THE_WALKERS_OWN_SPEED_IN_ONE_DIMENSION_INVISIBLE_UNDER_ONE_RECORD_PER_SITE_AND_ANISOTROPIC_IN_THREE_BOUNDED_THEOREM_NOTE_2026-09-24.md` | `50c708e3742f9a5daa59f6f1fb48b44fe388d71b9fc2454ede1a9595185d332d` | All 106 lines; matching K=0 singlet algebra, but an attractive-contact off-spectrum binding theorem |

M3's initially truncated lines were subsequently read. B uses the opposite `(z-H)^{-1}` convention, and its three-dimensional off-spectrum expansion does not establish the present low-positive-energy boundary value. M6 leaves that regularity conditional. M3/M9's generic-K arguments do not prove a uniform central threshold estimate. Their arguments also distinguish the free additive two-step current from a placement-dependent interacting energy current. That distinction is retained here.

Frozen-main statement searches produced 27 hits in 12 files (`excluded_walk_probe/matched_statement_search.log`) and six further finite-time/packet hits (`finite_time_statement_search.log`), both fully read. Complete scope/hit-context excerpts for the first search are in `search_scope_excerpts.log`; all 473 log lines were read, with the result-up-front sections of historical Cycles 578/583 additionally read. The matching mathematical premises are M6 and B. The other hits concern a static clock Green function, Villain response, a Wilson stress contact, Spin(10) atomic propagators, a cubic-ice sampling matrix, raw Sommerfeld prompts, a different massive six-mode discrete-time CAR dimer, or a static source ansatz. The dimer result has a 15-dimensional contact space and an open contact-cyclic pole obligation, not this massless two-coin hard core. The six finite-time search hit statements did not match this model; their full unrelated notes were not read. This is a bounded statement search, not a global novelty claim or a rereview of unrelated claims.

Applicable main workflow/axiom/registry reading from the unchanged earlier source map is reused. The installed physics-loop skill and frozen canonical skill matched at SHA-256 `7d924a4c8b3ae428523616f801cf05ee10d372eced7b6939030f1eb5d5897aa4`; its required references were read. The parent's narrower frozen-source, external-output brief controls this probe. No W bytes, model/reasoning setting, commit, PR or audit surface was changed.

## 2. All four channels and exceptional fibers

Use normalized measure `dq/(2π)^3` on the full relative torus, the normalized constant singlet `c`, `C=|c><c|`, and `P=I-C`. The fiber free generator is

`H0(K,q)=h(K/2+q)⊗I+I⊗h(K/2−q)`, `h(k)=sin(k)·σ`.

It preserves the antisymmetric pair space. The contact vector and its norm are taken in that space using the full-torus representation; there is no additional factor of two. Define

`a=sin(K/2+q)`, `b=sin(K/2−q)`, `A=|a|`, `B=|b|`,
`S=A+B`, `D=A−B`, `t=a·b/(AB)`.

Away from individual cone points, the energies `S,−S,D,−D` have contact weights `(1−t)/4,(1−t)/4,(1+t)/4,(1+t)/4`. This follows by expanding the two one-particle projectors and using the singlet identity `<σ_i⊗σ_j>=−δ_ij`. Summing all four fractions, with `R0(z)=(H0−z)^{-1}`, gives

\[
G(K,z)=\langle c,R_0(z)c\rangle
=\int\left\{\frac{z(1-t)}{2(S^2-z^2)}+
\frac{z(1+t)}{2(D^2-z^2)}\right\}dq
=\int\frac{z(|a+b|^2-z^2)}{(S^2-z^2)(D^2-z^2)}dq.                 \tag{1}
\]

The final denominator also equals `(A²+B²−z²)²−4A²B²`. Formula (1) is interpreted at cone points through the original matrix resolvent. The singlet projector gauge is not a premise there.

M6's dispersion inequality gives `|D|≤ε(K)`, where `ε(k)=|sin k|`. At any total corner `C0∈{0,π}³`, the condition

`K=C0+δκ`, `E=δe>0`, `|κ|≤θe`, `θ<1`

therefore closes all mixed and negative-negative channels at energy E. It does not remove the mixed channels' virtual contribution to G. Conversely, low total energy alone does not close them: at `K=(π/2,0,0)`, put `q=(asin(E/√2),0,0)` with small positive E. Then `A−B=E`, both A and B tend to `1/√2`, and the positive mixed contact weight is exactly `1/2`.

At an exact total corner let r be its number of π components and let `ε_C(q)` use cos in those r coordinates and sin in the other coordinates. Then `A=B=ε_C`, and the combined zero-energy mixed weight is

`f_C(q)=Σ_{j:C_j=π} cos²(q_j)/ε_C(q)²`.

Coordinate shifts and permutation symmetry imply `∫f_C=r/3` and `∫f_C F(ε_C²)=(r/3)∫F(ε²)`. Consequently the exact full expression is

\[
G(C_0,z)=-\frac{r}{3z}
 +\left(1-\frac r3\right)z\int\frac{dq}{4\epsilon(q)^2-z^2}.   \tag{2}
\]

Thus the contact spectral measure has a zero-energy atom of mass r/3. At `C0=(π,π,π)`, `H0c=0`, `G=−1/z`, and c is already a reducing zero eigenspace. Its removal leaves the complementary unitary unchanged. Positive-energy contact weights vanish at that exact fiber. A uniform strictly positive scattering loss over all total corners is therefore false. At K=0 there is no contact atom, but the pair two-step current itself vanishes identically, so a current claim restricted only to K=0 would be trivial.

## 3. Explicit central regular domain

For the remainder of the proof take

\[
0<E\le\tfrac18,\qquad |K|\le E/4.                              \tag{3}
\]

Put `k=K/2`, `h=|k|≤E/8`. Every positive-positive shell point has `ε(q+k),ε(q−k)≤E`. Each coordinate of q±k therefore lies within `asin E` of a π-multiple. Since their separation is `2k` and `|2k|≤E/4<π−2 asin E`, both use the same coordinatewise corner. Write `q=C0+x`, `r=|x|`, in that chart. For `u=x+k`, `v=x−k`,

`ε(u)≥√(1−E²)|u|`, `ε(v)≥√(1−E²)|v|`.

Indeed each coordinate has absolute value at most asin E and `sin y/y≥cos(asin E)`. Hence

`3E/8≤r≤E/[2√(1−E²)]<9E/16`.                       (4)

The lower bound follows from `E≤|u|+|v|≤2r+2h`. This proves full shell coverage in eight disjoint small corner charts and excludes other shell components.

For `n∈S²`, let `S_K(r,n)=ε(rn+k)+ε(rn−k)`. On `r∈[E/4,E]`, `R=|rn±k|≤9E/8<1/4`, and

\[
\left|\nabla\epsilon(y)-\frac y{|y|}\right|\le\frac56|y|^2.
                                                                    \tag{5}
\]

To prove (5), write `∇ε(y)=diag(cos y) sin(y)/|sin y|`. The cosine error is at most `|y|²/2`; normalization changes a nonzero vector by at most twice its relative error, and `|sin y−y|≤|y|³/6`. The second error is at most `|y|²/3`. Also

`n·(rn±k)/|rn±k|≥(r−h)/(r+h)≥1/3`.

Each radial derivative is therefore greater than `1/3−5/96>1/4`. Since `|∇ε|≤1`,

\[
\tfrac12\le\partial_r S_K\le2.                                  \tag{6}
\]

At r=E/4 the energy is at most 3E/4; at r=E it is at least `(3/4)(|En+k|+|En−k|)≥3E/2`. Thus every ray has exactly one root, and (4) shows that it is the full shell.

Let `s_±=sin(rn±k)`. The actual vectors in (1) are `a=s_+`, `b=−s_−`, up to the same corner signs. The contact weight is

`w=(1+s_+·s_−/(|s_+||s_−|))/4`.

The identity `s_+·s_−=ε(rn)²−ε(k)²`, together with `ε(rn)≥3r/4` and `h≤r/2`, gives positive dot product. Thus `1/4≤w≤1/2`. Coarea now has no hidden shell multiplicity:

\[
\rho(K,E)=\frac8{(2\pi)^3}\int_{S^2}
 \frac{w(rn)r^2}{\partial_rS_K(r,n)}d\Omega,
\qquad
\frac{E^2}{32\pi^2}\le\rho(K,E)\le\frac{4E^2}{\pi^2}.          \tag{7}
\]

The lower estimate uses only r≥E/4, w≥1/4 and the slope upper bound; the upper uses r≤E, w≤1/2 and the slope lower bound.

The real boundary value needs an estimate, not just (7). Keep K and E fixed and consider energy `u∈I=[7E/8,9E/8]`. The same ray interval `[E/4,E]` contains every root for every such u. Full coverage follows from the same coordinate argument with `u≤9E/8`. On this common interval `|rn±k|≥E/8`, so `ε(rn±k)≥3E/32`. Therefore

`|∂_r w|≤6/E`, `|∂_r²S_K|≤44/E`.

For the latter, `||Hess ε(y)||≤2/ε(y)` when `ε(y)≤1`; the two terms in the Hessian of a Euclidean norm composed with sin give this bound. If `F(u,n)=w r²/S'_K`, implicit differentiation gives

`F_u=(w_r r²+2rw)/(S'_K)²−w r² S''_K/(S'_K)³`,

hence `|F_u|≤28E+176E=204E`. Integrating the angular factor gives

\[
\sup_{u\in I}|\partial_u\rho(K,u)|\le816E/\pi^2.              \tag{8}
\]

The positive-band Cauchy integral over I has a finite boundary value: subtract `ρ(K,E)` and use (8). The constant part has zero real principal value because I is symmetric about E. Its real contribution is at most `204E²/π²`; its imaginary part is `πρ(K,E)≤4E²/π`. Every remaining spectral contribution is at least E/8 from E, and the entire contact measure has mass one, so its absolute value is at most 8/E. Thus

\[
\operatorname{Im}G(K,E+i0)=\pi\rho(K,E),\qquad
\frac{E^2}{32\pi}\le |G(K,E+i0)|\le\frac9E,
\quad |G(K,E+i0)^{-1}|\le\frac{32\pi}{E^2}.                   \tag{9}
\]

Here `8/E+(204/π²+4/π)E²≤9/E` on (3). This proves an explicit nonzero regular denominator without assuming a limiting-absorption theorem. Smooth local coarea density and repeated subtraction also give `G,ρ∈C^∞` on every compact subdomain with strict energy separation. The bound in (9) is deliberately coarse near zero.

## 4. Sharper uniform central threshold expansion

Let e belong to a fixed compact positive interval and `|κ|≤e/4`, with `K=δκ`, `E=δe`. Define

\[
I_0=\int\frac{dq}{4\epsilon(q)^2},\qquad
v_j(q)=\frac{\sin q_j\cos q_j}{\epsilon(q)},
\]

\[
\mathcal A(\kappa,e)=e\int
\frac{e^2-|\kappa\mathbin{\odot}\cos q|^2}
 {4\epsilon(q)^2[e^2-(\kappa\cdot v(q))^2]}dq.                \tag{10}
\]

The singularity of I0 at each of the eight cones is integrable in dimension three. In particular `I0≥1/12`. Since `|κ·v|²≤|κ⊙cos q|²≤|κ|²`,

\[
e(1-|\kappa|^2/e^2)I_0\le\mathcal A(\kappa,e)\le eI_0.     \tag{11}
\]

The claimed uniform expansion, including virtual mixed channels, is

\[
G(\delta\kappa,\delta e+i0)=\delta\mathcal A(\kappa,e)+O(\delta^2).
                                                                    \tag{12}
\]

Here is a direct control of the principal value in (12). At real energy inside the gap rewrite (1) as

`G/E = ∫ Wδ(q)/(S²−E²−i0) dq`,
`Wδ=(E²−|a+b|²)/(E²−D²)`.

The shorthand `−i0` has the same positive-energy pole convention as `(S²−(E+i0)²)^{-1}`. The mixed denominator is separated from zero. Moreover `D²≤|a+b|²≤|K|²`, so `1−|K|²/E²≤Wδ≤1`.

Choose disjoint fixed balls of radius r0 around the eight cones, and an inner radius Rδ with fixed R sufficiently large for the compact e,κ domain. Every on-shell root lies inside these inner balls by (4). On a cone annulus `Rδ≤r≤r0`, the elementary norm-composition derivative estimates are `|∂^j ε|≤C_j r^{1−j}`: differentiate the norm of sin, use `|sin q|≥c r`, and bounded derivatives of sin. Taylor expansion symmetrically about q then yields

`S=2ε+O(δ²/r)`, `D/δ=κ·v+O(δ²/r²)`,
`|a+b|²/δ²=|κ⊙cos q|²+O(δ²)`.

Consequently `S²−δ²e²≥c r²` for a sufficiently large fixed R, and the difference between the integrand of `G/δ` and the integrand in (10) is bounded by `C δ²/r⁴`. Integrating `r² dr` from Rδ to r0 gives O(δ). Away from all cone balls the bound is O(δ²).

It remains to justify the inner part, where expanding through the pole would be invalid. Set `q=C0+δp` in each inner ball. The matrix resolvent integrand is δ^{-1} times the resolvent of the smooth scaled matrix `δ^{-1}H0(δκ,C0+δp)` at e, and the volume contributes δ³. The ++ pole is simple, in an annulus bounded away from the individual cone points, with uniformly positive radial slope by (6). Coarea followed by symmetric density subtraction, exactly as in (8), bounds its principal-value integral uniformly in the scaled variables. Away from this shell the scaled matrix inverse is uniformly bounded; in particular the individual projector cone points have no resolvent singularity because their total energy is separated from e. A smooth energy cutoff equal to one near e makes the subtraction interval fixed and leaves bounded integrals outside it. Thus each inner contribution to G is O(δ²). The integral of the limiting integrand in (10) over the same inner balls is O(δ), hence its contribution after multiplication by δ is also O(δ²). These bounds prove (12).

This proof supplies a finite uniform remainder constant, not a numerically evaluated maximal threshold. With e=1, (11) and (12) imply that there exists E*>0, E*≤1/8, such that uniformly for `|K|≤E/4`, `0<E≤E*`,

\[
\operatorname{Re}G(K,E+i0)\ge\frac{15I_0}{32}E\ge\frac5{128}E.
                                                                    \tag{13}
\]

The estimates can be differentiated a fixed finite number of times in the scaled parameters `(κ,e)`: on the annuli the Taylor remainders obey the same `C_j δ²/r⁴` majorant; in the inner balls the smooth moving shell is handled by the fixed cutoff and coarea subtraction. This gives corresponding finite constants for each fixed derivative order. No uniform bound in the derivative order, or explicit numerical E*, is asserted. For the Cook bridge, the weaker `C^r` regularity on each compact positive-energy interval already follows from Section 3.

For completeness the leading spectral density is

\[
\rho(\delta\kappa,\delta e)
 =\frac{\delta^2(e^2-|\kappa|^2)}{4\pi^2}+O(\delta^4).         \tag{14}
\]

To see the coefficient without relying on angular sampling, use one cone's physical momentum p for particle 1 and κ−p for particle 2. On the limiting shell `|p|+|κ−p|=e`,

`w0=(e²−|κ|²)/(8|p||κ−p|)`.

The integral of `δ(e−|p|−|κ−p|)/(|p||κ−p|)` over R³ equals 2π. For κ≠0, use prolate coordinates `u=(r1+r2)/|κ|`, `v=(r1−r2)/|κ|`, azimuth φ: the Jacobian is `|κ|³(u²−v²)/8`, and `r1 r2=|κ|²(u²−v²)/4`. The delta factor removes |κ|; the remaining v and φ integrals give 2π. The κ=0 case is its direct spherical limit. Multiplying by eight cones and `(2π)^{-3}` proves the coefficient. On the compact timelike domain, individual momenta stay bounded away from zero on the scaled shell; `sin(δp)/δ` is smooth in δ², and the implicit radial root has a uniform slope. Thus the scaled coarea integral differs from its δ=0 value by O(δ²), proving the remainder in (14).

At K=0 an exact independent normalization formula is available for `0<E<2`:

\[
\rho(0,E)=\frac{E^2}{16\pi^3}\int_{S^2}
 \prod_{j=1}^3(1-E^2 n_j^2/4)^{-1/2}d\Omega.
                                                                    \tag{15}
\]

It follows from `u=sin q` in the eight cone charts. In particular it lies between `E²/(4π²)` and `E²/[4π²(1−E²/4)^{3/2}]`.

## 5. Actual stationary scattering and coherent current change

The compressed generator is realized on the original fiber by `Hext=P H0 P`, with zero on c. Put `b=H0c`. Since `<c,H0c>=0`,

\[
V=H_{\rm ext}-H_0=-|b\rangle\langle c|-|c\rangle\langle b|,
\qquad \|b\|^2=2\sum_j\cos^2(K_j/2)\le6.                     \tag{16}
\]

This is bounded self-adjoint of rank at most two. Its contact zero mode is not an incoming scattering state.

The external stationary theorem used here is Yafaev's Theorems 2.3/2.4, Eq. (2.8), pp.369–371. They give the stationary formula for `V=L* J L` under the stated compactness and trace-ideal hypotheses for the sandwiched resolvent; J need not have constant sign. Choose `Lf=(<c,f>,<b,f>,Qf)`, where Q is injective Hilbert–Schmidt, and `J=[[0,−1],[−1,0]]⊕0`. Then L is injective and Hilbert–Schmidt. Since H0 is bounded, both trace-ideal hypotheses of Theorem 2.4 hold with p=1. Its conclusion supplies Assumption 2.2 and Eq. (2.8). This checks the otherwise easily missed kernel condition. The resulting formula holds almost everywhere in energy. [Yafaev, *On the scattering matrix for perturbations of constant sign* (1992)](https://www.numdam.org/item/AIHPA_1992__57_4_361_0.pdf).

The active two-dimensional part can be evaluated independently of that theorem's proof. Set G=G(K,z). The free sandwiched resolvent, in the rows c,b, is

\[
B_0(z)=\begin{pmatrix}G&1+zG\\1+zG&z+z^2G\end{pmatrix},
\qquad \det(I+B_0J)=-zG,
\]

\[
J(I+B_0J)^{-1}
=\begin{pmatrix}G^{-1}+z&-1\\-1&z^{-1}\end{pmatrix}.          \tag{17}
\]

The auxiliary Q rows do not enter because J is zero there. At shell energy E>0, the spectral restrictions satisfy `Γ_E b=E Γ_E c`. Thus (17) restricts exactly to `|Γ_Ec><Γ_Ec|/G`. Equivalently the full resolvent is

`Rext=R0−R0 C R0/G−C/z`;

the extra T term is `(H0−z)C(H0−z)/z` and vanishes on shell. No convergence of scattering operators under an infinite-coupling limit has been assumed.

On the regular region (3), `||Γ_Ec||²=ρ(K,E)>0`. Let `v_E=Γ_Ec/√ρ`. The stationary scattering matrix therefore has the representative

\[
S_E=I+(s_E-1)|v_E\rangle\langle v_E|,
\qquad s_E=1-\frac{2\pi i\rho}{G}=\frac{\overline G}{G},
\qquad |s_E-1|=\frac{2\pi\rho}{|G|}.                         \tag{18}
\]

It acts as the identity on the orthogonal channel complement. The sign in (18) is tied to `(H0−z)^{-1}` and `S=W_+^*W_-`. Formula (9) prevents a denominator zero; smooth local density and G give a continuous representative in the regular energy interval. The physical scattering operator itself is defined up to energy-null sets, which suffices for every packet statement. The theorem is applied fiberwise; no assertion that the direct integral over K is trace class is made.

For any bounded real multiplication observable g on the shell, set `μ=<v_E,g v_E>` and `w=(g−μ)v_E`. Since w is orthogonal to v_E, expansion of (18) gives exactly

\[
S_E^*gS_E-g=(s_E-1)|w\rangle\langle v_E|
 +(\overline{s_E}-1)|v_E\rangle\langle w|,
\qquad
\|S_E^*gS_E-g\|=|s_E-1|\sqrt{\operatorname{Var}_{v_E}(g)}.    \tag{19}
\]

The diagonal term cancels by `|s_E|=1`; the nonzero two-dimensional block has eigenvalues `±|s_E−1|||w||`. This remains true when w=0.

For the supplied additive pair two-step current, `g_a(K,q)=sin K_a cos 2q_a`. On (3) the relative offset r is at most E, so its shell range has length at most `2|sin K_a|E²`. The elementary interval variance bound is `Var≤(range)²/4`; it follows from `(g−m)(M−g)≥0` and maximizing `(μ−m)(M−μ)`. From (7), (13), (18), (19), for `0<E≤E*`,

\[
\|S_E^*g_aS_E-g_a\|
 \le\frac{1024}{5\pi}|\sin K_a|E^3
 \le\frac{256}{5\pi}E^4.                                  \tag{20}
\]

Direct integration gives the corresponding expectation bound for arbitrary normalized coherent incoming packets supported in that region, without an angular incoherence or event-count assumption. This is an asymptotic incoming/outgoing observable bound for actual hard-core scattering. It differs from a conditional change per selected collision, and it does not provide a kinetic relaxation time. The constant and E* are conservative; E* is supplied by the proved remainder existence, not numerically certified here.

## 6. A separate explicit finite-time unitary result

This result uses the density upper estimate (7) and needs neither stationary scattering nor a principal-value estimate. Let `0<λ≤1/16`, let φ be a normalized free pair packet with spectral support `λ≤H0≤2λ`, and restrict its total-momentum support to `|K|≤λ/4`. Equivalently one may work at one fixed K. These energies have only ++ channels. By (7),

\[
\|C\mathbf1_{[\lambda,2\lambda]}(H_0)\|\le
\eta_\lambda:=\sqrt{\frac{28}{3\pi^2}}\lambda^{3/2}<1.        \tag{21}
\]

For a direct integral, C and P in this section mean the decomposable contact projections, and the same bound follows from the uniform fiber estimate. The contact mass is `∫_λ^{2λ}ρ(K,E)dE≤28λ³/(3π²)`. The spectral theorem and (16) then give, for every t,

`||V exp(−itH0)φ||≤(√6+2λ)ηλ`.

The second term is `||C H0 exp(−itH0)φ||≤2λ ηλ`. Duhamel and normalization of the actual allowed initial state `χ=Pφ/||Pφ||` therefore yield

\[
\|e^{-itH_{\rm ext}}\chi-e^{-itH_0}\phi\|
 \le d_t:=\eta_\lambda[\sqrt2+(\sqrt6+2\lambda)|t|].          \tag{22}
\]

Indeed if `β=||Cφ||`, then `||χ−φ||²=2(1−√(1−β²))≤2β²`. The compressed state stays in P. Its projection initially introduces components outside the original energy band; (22) already includes them and does not assume that the hard-core state remains spectrally band-limited.

A useful current bound follows by subtracting the K-dependent constant `sin K_a`. That multiplier commutes with both generators, so it contributes no drift. Write `O_a=g_a−sin K_a I` and `s_a=ess sup_{K in packet}|sin K_a|≤λ/4`. Globally `||O_a||≤2s_a`, whereas on the free band `||O_a exp(−itH0)φ||≤8s_a λ²` by the shell coverage. Expanding the expectation in the state difference gives

\[
\left|\langle\chi_t,g_a\chi_t\rangle-
             \langle\chi,g_a\chi\rangle\right|
\le16s_a\lambda^2(d_t+d_0)+2s_a(d_t^2+d_0^2),
\quad d_0=\sqrt2\eta_\lambda.                               \tag{23}
\]

On the allowed space these expectations are those of `P g_a P` under the actual compressed unitary. Formula (23) is O((1+T)² λ⁴) for fixed `|t|≤T`, with all displayed constants explicit. For `|t|≤T0 λ^{-1/2}`, it is O_{T0}(λ³) and the state error in (22) is O_{T0}(λ). This is a positive finite-time result for arbitrary packets in the stated free spectral band, after the explicit allowed-state preparation. It neither assumes that a collision took place nor estimates a macroscopic relaxation time.

The observable here is the compressed free two-step current. M3 permits placement-dependent finite-rank corrections to an interacting energy current. Those require their own matrix elements and are not silently included in (20) or (23). Nor is an unbounded position observable controlled by these norm estimates. The parent's separate Cook bridge addresses remote-time scattering preparation and such corrections; it is not used to prove (21)–(23).

## 7. Controls, provenance and remaining limits

`excluded_walk_probe/exact_and_shell_checks.py` is a new external, standard-library helper with no repository or author-runner imports. Its Gaussian-rational calculations independently invert 48 four-by-four pair matrices, check all four total-corner atom weights on a coordinate-symmetric rational measure, check the finite compressed resolvent including `−C/z`, reduce the two-by-two stationary matrix, and verify a nonzero rank-one observable identity (`||Δg||²=2304/3125`). Its floating calculations find actual radial shell roots in 2,048 fixed directions, at three κ values and four scales, and compare the coarea density with (14). They also preserve the open-mixed-channel counterexample. The full 19-line log was read after exit 0. The angular quadrature is not interval validated and proves no analytic uniform estimate or principal value. No numerical principal-value extrapolation is used as evidence for (12).

The external primary stationary source was read through its full Section-2 setup, Assumptions 2.1/2.2, Theorems 2.3/2.4 and formulas (2.3)–(2.9); the formulas on journal pp.369–371 were checked from local rendered PDF pages because web OCR omitted them. Its remaining constant-sign spectral results were not used. Kato's five-page 1957 trace-class paper was read in full as supporting context for the parent's Cook route. Behrndt–Malamud–Neidhardt (2009) introduction, Theorems 3.1/3.2 and Appendix-A theorem statements were inspected, but their boundary-triplet construction was not imported. Yafaev's 2004 lecture statements were inspected as context, not used to replace the checked 1992 abstract hypotheses. These literature readings are not an independent proof of this probe's threshold estimates.

The following boundaries remain: the supplied model has not been selected from the minimal axioms; there is no many-body or kinetic-rate theorem; the other total-corner threshold regimes are not covered by (12)–(23); mixed channels outside the strict energy gap are retained rather than dismissed; no dimension-two threshold extension is claimed; no explicit numerical maximal E* or all-orders derivative constant was computed; and a placement-dependent full energy-current theorem requires its stated correction. None of these boundaries invalidates the explicit domain (3), finite denominator bound (9), or finite-time bound (23).

Recovery history: the interrupted checkpoint had SHA-256 `350f3aa5de9f79c4daa50048d80d1985f16818d56ef6a536e009a0979822b51b`; its proof gaps are resolved above rather than counted as earlier evidence. The separately completed particle report is preserved. The current probe, source manifests, finite-control helper/log and primary-paper hash are frozen in `excluded_walk_probe/identity_manifest.json` after the final read. No formal review or landing verdict is issued.
