"""Independent controls for EXCLUDED_WALK_TRANSPORT_PROBE.md.

No repository or author-runner imports. SymPy exact identities, followed by
explicitly labelled mpmath finite-dimensional unitary controls. These tests
do not certify a PV integral, uniform remainder, or scattering theorem.
"""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import json
import sympy as s
import mpmath as mp

start=perf_counter()
a=s.symbols("a1:4", real=True)
b=s.symbols("b1:4", real=True)
z=s.symbols("z")
sx=s.Matrix([[0,1],[1,0]])
sy=s.Matrix([[0,-s.I],[s.I,0]])
sz=s.diag(1,-1)
pauli=[sx,sy,sz]
identity=s.eye(4)
h=lambda v:sum((v[j]*pauli[j] for j in range(3)),s.zeros(2))
H=s.kronecker_product(h(a),s.eye(2))+s.kronecker_product(s.eye(2),h(b))
u=s.Matrix([0,1,-1,0])
aa=sum(x*x for x in a)
bb=sum(x*x for x in b)
ab=sum(x*y for x,y in zip(a,b))
def zero_matrix(m):
    return all(s.expand(x)==0 for x in m)
def expect(m):
    return s.expand((u.T*m*u)[0]/2)

# Polynomial proof valid for arbitrary six real vector components.
minimal=H**4-2*(aa+bb)*H**2+(aa-bb)**2*identity
assert zero_matrix(minimal)
numerator=(H+z*identity)*(2*(aa+bb)*identity-z*z*identity-H**2)
denominator=(aa+bb-z*z)**2-4*aa*bb
assert zero_matrix((H-z*identity)*numerator-denominator*identity)
assert expect(H)==0 and expect(H**3)==0
assert s.expand(expect(H**2)-(aa+bb-2*ab))==0
assert s.expand(expect(numerator)-z*(aa+bb+2*ab-z*z))==0
print("Exact symbolic minimal polynomial and singlet resolvent identity: arbitrary six real components.")

A,B,d=s.symbols("A B d", nonzero=True)
four=(1-d/(A*B))/4*(1/(A+B-z)+1/(-A-B-z))
four+=(1+d/(A*B))/4*(1/(A-B-z)+1/(-A+B-z))
closed=z*(A*A+B*B+2*d-z*z)/(((A+B)**2-z*z)*((A-B)**2-z*z))
assert s.factor(four-closed)==0
assert s.limit(z*closed,z,s.oo)==-1
# Mixed channels remain virtual in the gap, even without an on-shell pole.
virtual_weight=Fraction(1)-Fraction(1,25)
virtual_weight/=Fraction(1)-Fraction(9,625)
assert virtual_weight==Fraction(75,77)
assert virtual_weight!=1
print("Exact four-channel partial fractions and (H-z)^-1 sign; a limiting virtual-channel weight is 75/77, not 1.")

# Derive the continuum coarea coefficient directly in centered radial coordinates.
# e>k>=0; mu is the cosine with the k-axis. Every equality below is algebraic.
e,k,mu=s.symbols("e k mu", positive=True)
r=e*s.sqrt(e*e-k*k)/(2*s.sqrt(e*e-k*k*mu*mu))
AB=e*e/4-r*r*k*k*mu*mu/(e*e)
weight=(e*e-k*k)/(8*AB)
slope=r*(e*e-k*k*mu*mu)/(e*AB)
F=weight*r*r/slope
expected=e*e*(e*e-k*k)**s.Rational(3,2)/(16*(e*e-k*k*mu*mu)**s.Rational(3,2))
assert s.simplify(F-expected)==0
primitive=mu/(e*e*s.sqrt(e*e-k*k*mu*mu))
assert s.simplify(s.diff(primitive,mu)-(e*e-k*k*mu*mu)**s.Rational(-3,2))==0
angular=2*s.pi*e*e*(e*e-k*k)**s.Rational(3,2)/16*2/(e*e*s.sqrt(e*e-k*k))
coefficient=s.simplify(8*angular/(2*s.pi)**3)
assert s.simplify(coefficient-(e*e-k*k)/(4*s.pi**2))==0
assert s.simplify(coefficient.subs(k,0)-e*e/(4*s.pi**2))==0
print("Exact centered-radial continuum coarea: eight cones give (e^2-k^2)/(4*pi^2); direct k=0 limit agrees.")

# Exact constants in the regular-domain and finite-time estimates.
assert Fraction(1,3)-Fraction(5,96)>Fraction(1,4)
assert Fraction(16,3)<6
assert Fraction(128,3)<44
assert Fraction(6+1,1)*4+Fraction(1,2)*44*8==204
assert 4*204==816
lam=s.symbols("lambda", positive=True)
rho_band=s.integrate(4*z*z/s.pi**2,(z,lam,2*lam))
assert s.simplify(rho_band-28*lam**3/(3*s.pi**2))==0
assert Fraction(2)*4*Fraction(128,5)==Fraction(1024,5)
assert Fraction(1024,5)/4==Fraction(256,5)
print("Exact constant propagation: slope, density derivative, band mass, and coherent-current prefactors.")

# A genuinely nonzero state-comparison remainder cannot in general be linear.
eps=Fraction(3,5)
# phi=(1,0), chi=(4/5,3/5), O=diag(0,2); O phi=0.
quadratic_drift=2*eps*eps
difference_norm_squared=(Fraction(4,5)-1)**2+eps**2
assert quadratic_drift>0 and quadratic_drift<=2*difference_norm_squared
print("Exact quadratic-remainder discriminator: O*phi=0 but expectation difference=18/25.")

# Finite-dimensional version of the exact compression preparation/Duhamel/current argument.
# This is a control of the abstract inequalities, not an approximation to the infinite walk.
mp.mp.dps=70
rows=[]
for lam0 in [mp.mpf(1)/16,mp.mpf(1)/64]:
    t0=lam0**mp.mpf("1.5")/4
    av=2*t0/(1+2*t0*t0)
    bv=(1-2*t0*t0)/(1+2*t0*t0)
    cv=mp.matrix([av,av,bv,av,av,bv])/mp.sqrt(2)
    H0=mp.diag([lam0,2*lam0,1,-lam0,-2*lam0,-1])
    C=cv*cv.H
    P=mp.eye(6)-C
    Hext=P*H0*P
    V=Hext-H0
    bvect=H0*cv
    assert mp.norm(cv.H*H0*cv)<mp.mpf("1e-65")
    assert mp.norm(V+bvect*cv.H+cv*bvect.H)<mp.mpf("1e-65")
    phi=mp.matrix([1,1j,0,0,0,0])/mp.sqrt(2)
    beta=mp.norm(C*phi)
    contact_band=av
    eta=mp.sqrt(28/(3*mp.pi**2))*lam0**mp.mpf("1.5")
    assert contact_band<=eta<1
    chi=P*phi/mp.norm(P*phi)
    assert abs(mp.norm(chi)-1)<mp.mpf("1e-65")
    assert abs(mp.norm(P*phi)-1)>mp.mpf("1e-10")
    sa=lam0/4
    O=mp.diag([8*sa*lam0**2,-8*sa*lam0**2,2*sa,2*sa,-2*sa,-2*sa])
    assert mp.norm(O*phi)<=8*sa*lam0**2+mp.mpf("1e-65")
    initial=(chi.H*O*chi)[0]
    d0=mp.sqrt(2)*eta
    for time in [mp.mpf(0),mp.mpf(1),-mp.mpf(3),2/mp.sqrt(lam0)]:
        free=mp.expm(-1j*time*H0)*phi
        actual=mp.expm(-1j*time*Hext)*chi
        dt=eta*(mp.sqrt(2)+(mp.sqrt(6)+2*lam0)*abs(time))
        assert mp.norm(actual-free)<=dt+mp.mpf("1e-60")
        defect=abs((actual.H*O*actual)[0]-initial)
        bound=16*sa*lam0**2*(dt+d0)+2*sa*(dt**2+d0**2)
        assert defect<=bound+mp.mpf("1e-60")
        rows.append({"lambda":str(lam0),"time":str(time),"state_error":mp.nstr(mp.norm(actual-free),18),
                     "state_bound":mp.nstr(dt,18),"current_drift":mp.nstr(defect,18),
                     "current_bound":mp.nstr(bound,18)})
print("Floating high-precision finite compression controls:",json.dumps(rows,sort_keys=True))
print("Scope: no author helper imported; no numerical principal-value evidence or all-size theorem certification.")
print("Elapsed seconds:",format(perf_counter()-start,".3f"))
print("Control source SHA256:",sha256(Path(__file__).read_bytes()).hexdigest())

