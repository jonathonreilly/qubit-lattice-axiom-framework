#!/usr/bin/env python3
"""Finite-chain energy-history source identity only; zero mathematical predicates."""
from pathlib import Path, PurePosixPath
import difflib, gzip, hashlib, json, re, sys
AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = __DECLARED_INPUTS__
EXTRA_PINS = __EXTRA_PINS__
PACKET = '.claude/science/physics-loops/toe-finite-apparatus-20261014'
CLAIM = 'finite_chain_energy_history_bounded_theorem_note_2026-10-14'
MAP_SHA = '__MAP_SHA__'
EDITS_SHA = '__EDITS_SHA__'
PARENTS_SHA = '__PARENTS_SHA__'
STATUS_SHA = '__STATUS_SHA__'
GRAPH_SHA = '__GRAPH_SHA__'
SOURCE_FREEZE_SHA = '69ed5806185823738779cb64666cf68de8c75d16e63527469fc984679af3f1e1'
CORE_HASHES = __CORE_HASHES__

def need(ok, message):
    if not ok: raise ValueError(message)
def sha(b): return hashlib.sha256(b).hexdigest()
def diff(a,b,old,new):
    return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=old.encode(),tofile=new.encode(),n=3))
def verify(root):
    root=root.resolve(); reads={}
    def read(name):
        p=PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts, 'Unsafe declared input')
        path=root.joinpath(*p.parts)
        need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root), 'Declared input missing or outside repository')
        if name not in reads: reads[name]=path.read_bytes()
        return reads[name]
    def pinned(name,digest,message):
        b=read(PACKET+'/'+name);need(sha(b)==digest,message);return json.loads(b)
    evidence=pinned('EVIDENCE_MAP.json',MAP_SHA,'Archive map changed')
    contents,origins={},{}
    for obj in evidence['objects']:
        need(obj['sha256'] not in contents,'Duplicate archive object')
        z=read(PACKET+'/'+obj['path'])
        need(sha(z)==obj['stored_sha256'] and len(z)==obj['stored_bytes'],'Compressed archive changed')
        b=gzip.decompress(z)
        need(sha(b)==obj['sha256'] and len(b)==obj['bytes'] and len(b.splitlines())==obj['lines'],'Archived source changed')
        contents[obj['sha256']]=b
        for origin in obj['origins']:
            need(origin['path'] not in origins,'Duplicate original alias');origins[origin['path']]=obj['sha256']
    def archived(name): return contents[origins[name]]
    contract=evidence['accepted_source_package']; prefix=contract['path']+'/'
    def source(name): return archived(prefix+name)
    need(contract['freeze_sha256']==SOURCE_FREEZE_SHA and sha(source('FINAL_FREEZE.json'))==SOURCE_FREEZE_SHA,'Accepted source freeze differs')
    seal=json.loads(source('FINAL_FREEZE.json'));members=contract['members'];extras=contract['additional_files']
    need(seal['members']==members and len(members)==contract['member_count']==180,'Assembly membership differs')
    need(len(extras)==1 and extras[0]['path']=='FINAL_FREEZE.json' and contract['complete_file_count']==181,'Assembly additional membership differs')
    need({p for p in origins if p.startswith(prefix)}=={prefix+r['path'] for r in members+extras},'Complete assembly aliases differ')
    for r in members+extras:
        b=source(r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Assembly member identity differs')
    selection=json.loads(source('ARCHIVE_MANIFEST.json'))['sources']
    need(len(selection)==evidence['original_source_selection_count']==163,'Original source selection differs')
    for r in selection:
        b=source(r['archive'])
        need(b==archived(r['source']) and sha(b)==r['sha256'] and len(b)==r['bytes'],'Original source alias differs')
    mapping=json.loads(source('EXTRACTION_MANIFEST.json'));accepted=source(mapping['candidate'])
    wrapper=mapping['wrapper'];original_wrapper=source(wrapper['path'])
    need(sha(accepted)==mapping['candidate_sha256'] and len(accepted)==mapping['candidate_bytes'],'Accepted candidate differs')
    need(accepted[wrapper['start_byte']:wrapper['end_byte_exclusive']]==original_wrapper
         and sha(original_wrapper)==wrapper['sha256'],'Original wrapper boundary differs')
    cores=[]
    for r in mapping['sources']:
        a,z=r['start_byte'],r['end_byte_exclusive'];c=source(r['archive'])
        need(accepted[a:z]==c and sha(c)==r['sha256'] and len(c)==r['bytes'],'Original extraction differs')
        need(accepted[:a].count(b'\n')+1==r['start_line'] and accepted[:z].count(b'\n')==r['end_line_inclusive'],'Original extraction lines differ')
        cores.append(c)
    need([sha(c) for c in cores]==CORE_HASHES,'Immutable complete body order differs')
    edits=pinned('PUBLICATION_EDITS.json',EDITS_SHA,'Publication transformation changed')
    need(edits['source_freeze_sha256']==SOURCE_FREEZE_SHA and edits['additional_mathematical_body_edits']==[]
         and len(edits['notes'])==1,'Publication scope differs')
    renderings=edits['nonmathematical_link_renderings']
    need(len(renderings)==2 and all(r['source_sha256']==CORE_HASHES[7] for r in renderings)
         and {r['label'] for r in renderings}=={'STATE.yaml','HANDOFF.md'},'Historical link rendering scope differs')
    rendered_cores=list(cores)
    for r in renderings:
        old=r['original'].encode();new=r['rendered'].encode()
        need(rendered_cores[7].count(old)==1 and old.startswith(('['+r['label']+'](/Users/').encode())
             and new==('`'+r['label']+'` (historical path: `'+r['absolute_target']+'`)').encode(), 'Unreviewed historical-link rendering')
        rendered_cores[7]=rendered_cores[7].replace(old,new,1)
    note=edits['notes'][0];assembled=b'';order=[];wrappers={}
    need(archived(note['accepted_candidate_path'])==accepted and sha(accepted)==note['accepted_candidate_sha256'],'Accepted candidate differs')
    for r in note['pieces']:
        if r['kind']=='accepted_core_slice':
            original=archived(r['source_path']);need(sha(original)==r['source_sha256'],'Full original source differs')
            b=b''.join(original.splitlines(True)[r['source_line_start']-1:r['source_line_end']])
            need(sha(b)==r['expected_slice_sha256'] and r['additional_mathematical_body_edits']==[],'Core slice differs')
            for item in [x for x in renderings if x['source_sha256']==r['source_sha256']]:
                old,new=item['original'].encode(),item['rendered'].encode()
                need(b.count(old)==1,'Historical-link source differs');b=b.replace(old,new,1)
            order.append(b)
        else:
            need(r['kind']=='publication_wrapper','Unknown publication piece');b=r['text'].encode()
            need(r['wrapper_path'] not in wrappers,'Duplicate wrapper');wrappers[r['wrapper_path']]=b
        need(sha(b)==r['sha256'] and len(b)==r['bytes'] and r['byte_offset']==len(assembled),'Publication piece bytes differ')
        need(r['first_line']==assembled.count(b'\n')+1 and r['last_line']==(assembled+b).count(b'\n'),'Publication piece lines differ')
        assembled+=b
    actual=read(note['note'])
    need(order==rendered_cores and actual==assembled and sha(actual)==note['published_sha256']
         and len(actual)==note['published_bytes'] and len(actual.splitlines())==note['published_lines'],'Published source does not reconstruct')
    def diff_bytes(r):
        z=read(PACKET+'/'+r['diff']);d=gzip.decompress(z)
        need(sha(z)==r['diff_stored_sha256'] and sha(d)==r['diff_sha256'] and len(d)==r['diff_bytes']
             and len(z)==r['stored_bytes'] and r['context_lines']==3,'Raw diff archive changed');return d
    need(diff_bytes(note)==diff(accepted,actual,note['fromfile'],note['tofile']),'Full publication diff differs')
    h=edits['historical_link_diff'];need(diff_bytes(h)==diff(cores[7],rendered_cores[7],h['fromfile'],h['tofile']),'Historical-link diff differs')
    bindings=pinned('PARENT_BINDINGS.json',PARENTS_SHA,'Parent bindings changed')
    need(bindings['binding_complete'] is True and bindings['direct_edges_verified'] is True
         and bindings['publication_ancestry_is_not_mathematical_dependency'] is True,'Actual published parent binding remains unresolved')
    parents=bindings['parents'];need(len(parents)==len({p['path'] for p in parents})==5,'Canonical parent membership differs')
    for p in parents:
        b=read(p['path']);need(sha(b)==p['published_sha256'] and len(b)==p['bytes'] and archived(p['archive_alias'])==b,'Canonical parent bytes changed')
    link_re=re.compile(r'\[[^\]]*\]\(([^)\s#]+\.md)(?:#[^)]*)?\)')
    citations=bindings['markdown_citations']
    need(bindings['markdown_citations_verified'] is True and len(citations)==len(parents),'Parent Markdown citation review incomplete')
    begin,end='<!-- BEGIN CANONICAL PARENT BINDING -->','<!-- END CANONICAL PARENT BINDING -->';text=actual.decode()
    need(text.count(begin)==text.count(end)==1,'Parent citation block differs');block=text.split(begin,1)[1].split(end,1)[0]
    for p,r in zip(parents,citations):
        path=PurePosixPath(p['path'])
        need(path.parts==('docs',path.name) and path.suffix=='.md' and p['claim_id']==path.stem.lower(),'Unreviewed canonical parent path class')
        need(r['parent_path']==p['path'] and r['claim_id']==p['claim_id'] and r['target']==path.name,'Parent citation target differs')
        need(r['label'].strip()==r['label'] and ' ' in r['label'] and not any(c in r['label'] for c in '[]\n\r'),'Descriptive parent label required')
        literal='['+r['label']+']('+r['target']+')'
        need(r['markdown']==literal and block.count(literal)==text.count(literal)==1 and link_re.findall(literal)==[r['target']],'Parent Markdown citation differs')
    need(link_re.findall(text)==[r['target'] for r in citations],'Recognized Markdown citations differ from declared parents')
    need(len(bindings['required_roles'])==5 and all(r['complete_body_identity_verified'] is True
         and r['relied_role_checked'] is True and r['actual_claim_id'] in {p['claim_id'] for p in parents}
         for r in bindings['required_roles']),'Direct premise role binding differs')
    graph=pinned('CLAIM_REGISTRY_ADDITIONS.json',GRAPH_SHA,'Graph proposal changed');deps=[p['claim_id'] for p in parents]
    need(graph['binding_complete'] is True and len(graph['nodes'])==1 and graph['nodes'][0]['claim_id']==CLAIM
         and graph['nodes'][0]['deps']==deps,'Graph node differs')
    need(graph['direct_edges']==[{'from':CLAIM,'to':d} for d in deps]
         and graph['expected_delta']=={'nodes':1,'edges':5},'Direct edge proposal differs')
    status=pinned('SOURCE_REVIEW_STATUS.json',STATUS_SHA,'Review scope changed')
    acceptance=read(PACKET+'/FINITE_APPARATUS_ASSEMBLY_ROOT_ACCEPTANCE.json');review=read(PACKET+'/FINITE_APPARATUS_ASSEMBLY_ROOT_REVIEW.md')
    need(sha(acceptance)==status['source_assembly_root_acceptance_sha256'] and sha(review)==status['source_assembly_root_review_sha256'],'Assembly root review changed')
    scope=json.loads(acceptance)
    need(scope==status['source_review_coverage_verbatim'] and scope['assembly_freeze_sha256']==SOURCE_FREEZE_SHA
         and scope['review_sha256']==sha(review) and scope['canonical_execution_authorized'] is False,'Assembly acceptance scope differs')
    need(status['no_go_packet_pass'] is False and status['new_independent_mathematical_review'] is False
         and status['unchanged_complete_core_coverage_reused'] is True and status['mathematical_core_edits']==0
         and status['publication_runtime_executed_by_source_preparer'] is False,'Review limitation differs')
    need(all(status[k] is True for k in ['fixed_finite_protocol_only','full_unnormalized_CQ_reference_output',
         'one_common_physical_chain','supplied_model_preparation_controls_and_gates',
         'effective_volume_data_distinct_from_drive_synthesis','canonical_parent_binding_complete'])
         and all(status[k] is False for k in ['native_realization_proved','kinetic_joint_limit_proved',
         'countable_partition_modulus_supplied','normalized_rare_branch_control','retained_audit_status']),'Mandatory export scope changed')
    for name,p in EXTRA_PINS.items():
        b=read(name);need(sha(b)==p['sha256'] and len(b)==p['bytes'],'Additional publication integrity input changed')
    need(set(reads)==set(AUDIT_INPUT_PATHS) and len(AUDIT_INPUT_PATHS)==len(set(AUDIT_INPUT_PATHS)),'Declared read closure differs')
    return {'result':'source_identities_and_reconstruction_match','claim_id':CLAIM,'meaning':'Byte integrity only; no mathematical calculation, proof or audit executed.',
        'mathematical_operations_executed':False,'mathematical_predicates_executed':0,'scientific_mutations_executed':0,
        'no_go_packet_pass_supplied_by_tool':False,'independent_review_supplied_by_tool':False,
        'external_scientific_input_reads':[p['path'] for p in parents],
        'package_local_integrity_reads':sorted(set(reads)-{p['path'] for p in parents})}
def main():
    print(json.dumps(verify(Path(__file__).resolve().parents[1]),sort_keys=True))
    print('per_element: checked and not executed — source integrity only; no spectral endpoint estimate was calculated.')
    print('per_site: checked and not executed — source integrity only; finite spin preparation and local controls remain supplied.')
    print('per_mode: checked and not executed — source integrity only; no propagator or strip-mass bound was evaluated.')
    print('per_block: checked and not executed — source integrity only; no history recursion or compiler error was executed.')
    print('lattice_wide: checked and not executed — source integrity only; no native realization, kinetic limit or no-go theorem was verified.')
if __name__=='__main__':
    try: main()
    except Exception as error:
        print(json.dumps({'result':'identity_verification_incomplete','error':str(error),'mathematical_operations_executed':False,
            'mathematical_predicates_executed':0,'scientific_mutations_executed':0}),file=sys.stderr)
        raise SystemExit(1)
