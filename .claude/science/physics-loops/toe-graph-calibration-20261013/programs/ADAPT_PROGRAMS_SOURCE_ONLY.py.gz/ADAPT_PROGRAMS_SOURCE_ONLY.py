"""Construct driver source from a fully read template; do not execute it."""
from pathlib import Path
import ast, difflib, gzip, hashlib, json
Q = Path(__file__).resolve().parent
T = Q/'procedural_template/threshold_crossing_chirp_publication_preparation'
sha = lambda b: hashlib.sha256(b).hexdigest()
def raw(p): return Path(p).read_bytes()
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(b if isinstance(b,bytes) else b.encode())
def replace(text,old,new):
    assert old in text, old[:80]
    return text.replace(old,new)

old = raw(T/'prepare_verify_threshold_crossing_chirp.py')
text = old.decode()
for a,b in [
 ('threshold_crossing_chirp','graph_calibration'),
 ('threshold-crossing-chirp','graph-calibration'),
 ("BASE = 'af2e44428a10e59cf5eb7130df4265d2949db8df'", "BASE = json.loads((Q / 'SPECIFICATIONS.json').read_text())['base']"),
 ('datetime(2026, 10, 13, 16, 42, 30, tzinfo=timezone.utc)', 'datetime(2026, 10, 14, 21, 37, 33, tzinfo=timezone.utc)'),
 ("'refs/heads/physics-loop/toe-chirped-kinetic-energy-20261013'", "'refs/heads/' + spec['stack_parent']"),
 ("'Exact three-edge delta differs'", "'Exact direct-edge delta differs'"),
 ("delta == {'nodes': 1, 'edges': 3}", "delta == spec['expected_graph_delta']"),
 ("'one_time_conditional_scope': True", "'conditional_common_H_fixed_finite_protocol_scope': True"),
 ("['cumulative PR9520 stack plus this milestone review',", "['cumulative actual parent stack plus this milestone review',"),
 ("'four byte-integrity tamper probes, one canonical identity-only cache and the exact one-node/three-edge '", "'four byte-integrity tamper probes, one canonical identity-only cache and the exact reviewed node/edge '"),
]: text = replace(text,a,b)
start = text.index('def source_guards(run, args):')
end = text.index('\ndef repeated_procedure_guard():',start)
guards = '''def source_guards(run, args):
    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
    need(sha(read(__file__)) == args.program_sha256, 'Root program anchor differs')
    need(WORKTREE == WORKTREE.resolve() and STAGE == STAGE.resolve(), 'Resolved paths differ')
    spec = js(Q / 'SPECIFICATIONS.json')
    bindings = js(STAGE / PACKET / 'PARENT_BINDINGS.json')
    need(spec['binding_complete'] is True and bindings['binding_complete'] is True
         and bindings['direct_edges_verified'] is True
         and bindings['markdown_citations_verified'] is True, 'Actual published parent binding remains unresolved')
    need(isinstance(BASE, str) and re.fullmatch(r'[0-9a-f]{40}', BASE), 'Exact published base required')
    need(spec['base'] == BASE and spec['branch'] == BRANCH and spec['worktree'] == str(WORKTREE)
         and spec['packet'] == PACKET and spec['deadline_utc'] == '2026-10-14T21:37:33Z', 'Publication target differs')
    need(spec['stack_parent'] and isinstance(spec['stack_parent_regular_pr'], int)
         and isinstance(spec['main'], str) and re.fullmatch(r'[0-9a-f]{40}', spec['main']), 'Actual parent/main identities required')
    need(bindings['actual_parent_head'] == BASE and bindings['actual_parent_pr']['number'] == spec['stack_parent_regular_pr'], 'Parent receipt differs')
    need(all(r['verified_against_complete_body'] is True for r in bindings['required_roles']), 'Direct premise role coverage incomplete')
    need(sha(read(Q / 'SOURCE_FREEZE.json')) == args.source_freeze_sha256, 'Source freeze changed')
    need(args.acceptance.resolve().is_relative_to(S) and not args.acceptance.resolve().is_relative_to(Q)
         and not args.acceptance.is_symlink(), 'Separate regular root acceptance required')
    need(sha(read(args.acceptance)) == args.acceptance_sha256, 'Root acceptance changed')
    accepted = js(args.acceptance)
    required = ['unchanged_source_coverage_reused', 'new_publication_wrappers_read',
        'publication_byte_maps_and_diffs_verified', 'complete_driver_read',
        'identity_tools_and_archive_map_read', 'packet_and_dependency_delta_read',
        'whitespace_and_link_policy_reviewed', 'final_assembly_review_read',
        'root_authorizes_execution', 'root_execution_acceptance',
        'block_handoff_and_review_history_read', 'twelve_section_conformance_reviewed',
        'exact_source_diff_producer_conventions_reviewed', 'canonical_parent_maps_reviewed',
        'uniform_graph_and_fixed_protocol_scope_reviewed', 'calibration_order_notation_reviewed',
        'common_H_and_regular_ideal_law_assumptions_reviewed', 'abstract_control_limits_reviewed',
        'canonical_parent_markdown_citations_reviewed']
    need(all(accepted.get(k) is True for k in required) and accepted.get('placeholder_only') is False,
         'Root source/program review incomplete')
    original_source = S / 'graph_calibration_source_assembly'
    original_seal = '281a36b1dc50d9eb2c052ce5b16bf8fbdcfc96998abaf775705c5879a6fdd035'
    need(sha(read(original_source / 'FINAL_FREEZE.json')) == original_seal, 'Accepted source freeze changed')
    old = js(original_source / 'FINAL_FREEZE.json'); members = {r['path'] for r in old['members']}
    need(len(members) == len(old['members']) == old['member_count'] == 112, 'Accepted membership differs')
    need(not any(p.is_symlink() for p in original_source.rglob('*')) and
         {str(p.relative_to(original_source)) for p in original_source.rglob('*') if p.is_file()}
         == members | {'FINAL_FREEZE.json'}, 'Accepted complete113-file membership changed')
    for row in old['members']:
        need(pin(original_source / row['path']) == {k:row[k] for k in ['sha256','bytes']}, 'Accepted source changed')
    old_acceptance = STAGE / PACKET / 'GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json'
    old_review = STAGE / PACKET / 'GRAPH_CALIBRATION_ASSEMBLY_ROOT_REVIEW.md'
    status = js(STAGE / PACKET / 'SOURCE_REVIEW_STATUS.json')
    need(sha(read(old_acceptance)) == status['source_assembly_root_acceptance_sha256']
         and sha(read(old_review)) == status['source_assembly_root_review_sha256'], 'Earlier source review changed')
    need(js(old_acceptance)['freeze_sha256'] == original_seal
         and js(old_acceptance)['root_review_sha256'] == sha(read(old_review)), 'Earlier review scope differs')
    anchors = ['base','branch','prepared_source_freeze_sha256','source_assembly_root_review_sha256',
        'source_assembly_root_acceptance_sha256','disposition','root_core_sha256',
        'independent_core_sha256','no_go_packet_pass']
    need(all(accepted.get(k) == status[k] for k in anchors) and status['base'] == BASE
         and status['branch'] == BRANCH and status['no_go_packet_pass'] is False, 'Accepted scope differs')
    need(status['source_review_coverage_verbatim'] == js(old_acceptance)
         and status['mathematical_core_edits'] == 0 and status['new_independent_mathematical_review'] is False
         and status['unchanged_complete_core_coverage_reused'] is True, 'Source coverage copy differs')
    need(all(status[k] is True for k in ['uniform_C_G_required_for_full_theorem',
         'growing_C_G_single_propagator_only','calibration_order_p_distinct_from_chain_count',
         'common_H_assumed_not_retained','regular_ideal_law_is_application_assumption',
         'canonical_parent_binding_complete']) and status['fixed_slot_continuum_necessity_proved'] is False,
         'Mandatory export scope changed')
    need(accepted.get('publication_source_freeze_sha256') == args.source_freeze_sha256
         and accepted.get('publication_program_sha256') == args.program_sha256, 'Acceptance does not bind package/program')
    review_path = Path(accepted.get('final_assembly_review_path') or '')
    need(review_path.is_absolute() and review_path.resolve().is_relative_to(S)
         and not review_path.resolve().is_relative_to(Q) and not review_path.is_symlink(), 'Separate root review required')
    need(review_path.is_file() and sha(read(review_path)) == accepted.get('final_assembly_review_sha256')
         and accepted.get('final_assembly_review_disposition') == 'accepted_for_source_integration', 'Exact root review incomplete')
    for record in [args.acceptance, review_path]:
        data = read(record); need(data.endswith(b'\\n') and not data.endswith(b'\\n\\n'), 'Root records require one terminal newline')
    write(run / 'ROOT_ACCEPTANCE.json', read(args.acceptance))
    write(run / 'FINAL_ASSEMBLY_REVIEW.md', read(review_path))
    write(run / 'SOURCE_FREEZE.json', read(Q / 'SOURCE_FREEZE.json'))
    freeze = js(Q / 'SOURCE_FREEZE.json'); declared = {r['path'] for r in freeze['files']}
    need(freeze['parent_binding_complete'] is True, 'Unbound source cannot authorize execution')
    need(len(declared) == len(freeze['files']) == freeze['file_count'], 'Duplicate frozen membership')
    need(not any(p.is_symlink() for p in Q.rglob('*')) and
         {str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file() and p != Q/'SOURCE_FREEZE.json'} == declared,
         'Frozen package membership differs')
    for row in freeze['files']:
        path = Q / row['path']
        need(path.resolve().is_relative_to(Q) and pin(path) == {k:row[k] for k in ['sha256','bytes']}, 'Frozen source changed')
    payload = {r['path'][8:]:{k:r[k] for k in ['sha256','bytes']} for r in freeze['files'] if r['path'].startswith('payload/')}
    need({str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()} == set(payload), 'Payload membership differs')
    repeated_procedure_guard()
    branch = js(STAGE / PACKET / 'GRAPH_CALIBRATION_BRANCH_PLAN.json')
    need(branch['binding_complete'] is True and branch['base'] == BASE and branch['branch'] == BRANCH
         and branch['parent_pr'] == bindings['actual_parent_pr']['url']
         and branch['branch_created_by_source_preparer'] is False, 'Branch plan differs')
    need(all((STAGE/PACKET/n).is_file() for n in ['HANDOFF.md','REVIEW_HISTORY.md','CONFORMANCE.md','TRACE_GATE.md',
         'CLAIM_STATUS_CERTIFICATE.md','NO_GO_DISCIPLINE_CHECKLIST.md','NO_GO_LEDGER.md']), 'Required block record missing')
    expected = set(payload) | {'logs/runner-cache/'+Path(n['runner']).stem+'.txt' for n in spec['notes']} | {MANIFEST,ROOT_ACCEPTANCE_COPY,ROOT_REVIEW_COPY}
    need(expected == set(js(Q/'EXPECTED_INSTALL_AND_STAGE_PATHS.json')['paths']), 'Planned footprint differs')
    additions = js(STAGE/PACKET/'CLAIM_REGISTRY_ADDITIONS.json')
    need(additions['binding_complete'] is True and additions['expected_delta'] == spec['expected_graph_delta'], 'Graph delta unresolved')
    need({n['claim_id'] for n in additions['nodes']} == {n['claim_id'] for n in spec['notes']} and
         {(e['from'],e['to']) for e in additions['direct_edges']} == {(n['claim_id'],d) for n in spec['notes'] for d in n['deps']}, 'Graph proposal differs')
    need(spec['expected_graph_delta'] == {'nodes':len(spec['notes']),'edges':len(additions['direct_edges'])}, 'Graph counts differ')
    for row in bindings['parents']:
        need(pin(WORKTREE/row['path']) == {'sha256':row['published_sha256'],'bytes':row['bytes']}, 'Canonical parent drift before installation')
    return payload, spec

'''
text = text[:start] + guards + text[end:]
text = replace(text, "need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')\n    run = EXECUTIONS", "need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')\n    need(js(Q/'SPECIFICATIONS.json')['binding_complete'] is True, 'Actual parent unresolved; no execution allowed')\n    run = EXECUTIONS")
dest = 'prepare_verify_graph_calibration.py'
save(Q/dest,text)

combined_old = raw(T/'run_combined_validation.py')
combined = combined_old.decode().replace('datetime(2026,10,13,16,42,30,tzinfo=timezone.utc)','datetime(2026,10,14,21,37,33,tzinfo=timezone.utc)').replace('threshold_crossing_chirp_combined_validation_execution','graph_calibration_combined_validation_execution')
save(Q/'run_combined_validation.py',combined)
rows=[]
for name, original, new in [(dest,old,text.encode()),('run_combined_validation.py',combined_old,combined.encode())]:
    ast.parse(new, filename=name)
    template = 'prepare_verify_threshold_crossing_chirp.py' if name==dest else name
    d=b''.join(difflib.diff_bytes(difflib.unified_diff,original.splitlines(True),new.splitlines(True),fromfile=('template/'+template).encode(),tofile=name.encode(),n=3))
    path='program_diffs/'+name+'.diff';save(Q/path,d)
    rows.append({'program':name,'program_sha256':sha(new),'template':'threshold_crossing_chirp_publication_preparation/'+template,'template_sha256':sha(original),'diff':path,'diff_sha256':sha(d),'context_lines':3})
save(Q/'PROGRAM_DIFFS.json',json.dumps({'programs':rows,'scope':'Complete producer-exact source diffs; proposed programs not executed.'},indent=2)+'\n')
print(json.dumps({'proposed_driver_AST_parsed':True,'combined_driver_AST_parsed':True,'proposed_programs_executed':False,'mathematical_predicates':0},indent=2))
