"""Bind supplied published parent and reconstruct source; no proposed runtime."""
from pathlib import Path
import difflib, gzip, hashlib, json
Q=Path(__file__).resolve().parent; Z=Q.parent; W=Z.parent/'correlation_worktree'
A=Z/'graph_calibration_source_assembly'; R=Z.parent/'resume_20261012'; P=Q/'payload'
K='.claude/science/physics-loops/toe-graph-calibration-20261013'; D=P/K
PK='.claude/science/physics-loops/toe-energy-tail-20261013'
NOTE='docs/GRAPH_CALIBRATION_BOUNDED_THEOREM_NOTE_2026-10-13.md'
PARENT='docs/POSTMEASUREMENT_ENERGY_TAIL_BOUNDED_THEOREM_NOTE_2026-10-13.md'
CID='postmeasurement_energy_tail_bounded_theorem_note_2026-10-13'
HEAD='ccbeddd0c04b70ee2b6c5f1cffeeeefa23df2989'
PARENT_SHA='dc6510563d6fcf2e9db38590b2004f3e5e24677b4fd8b0e0d6ffb83cef9eb592'
pending_writes={}
def raw(p): return Path(p).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p): return json.loads(raw(p))
def need(ok,message):
    if not ok: raise ValueError(message)
def save(p,b):
    p=Path(p);need(p.resolve().is_relative_to(Q),'Write outside preparation')
    pending_writes[p]=b if isinstance(b,bytes) else b.encode()
def put(p,v): save(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
def replace(text,old,new):
    need(text.count(old)==1,'Unique binding edit anchor required: '+old[:80])
    return text.replace(old,new,1)
def diff(a,b,x,y):
    return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=x.encode(),tofile=y.encode(),n=3))
spec=js(Q/'SPECIFICATIONS.json')
need(spec['binding_complete'] is False and not (Q/'SOURCE_FREEZE.json').exists(),'Initial binding requires preserved unbound state')
parent=raw(W/PARENT);need(sha(parent)==PARENT_SHA and len(parent.splitlines())==964,'Published parent changed')
receipt=js(Z/'ENERGY_TAIL_PR_CREATED.json');pr=receipt['pr']
need(receipt['head']==HEAD and receipt['canonical_note_sha256']==PARENT_SHA,'Actual parent receipt differs')
need(pr['number']==9526 and pr['headRefOid']==HEAD and pr['headRefName']=='physics-loop/toe-energy-tail-20261013'
     and pr['state']=='OPEN' and pr['isDraft'] is False,'Actual regular parent differs')
need(pr['url']=='https://github.com/jonathonreilly/qubit-lattice-axiom-framework/pull/9526','Actual PR URL differs')
ev=js(D/'EVIDENCE_MAP.json'); objects={r['sha256']:r for r in ev['objects']}
aliases={o['path']:r['sha256'] for r in ev['objects'] for o in r['origins']}
selection=[]
def archive(path,role):
    path=Path(path);b=raw(path);h=sha(b);alias=str(path)
    if alias in aliases: need(aliases[alias]==h,'Original alias changed')
    else:
        if h not in objects:
            packed=gzip.compress(b,mtime=0);name='objects/'+h+'.gz';save(D/name,packed)
            objects[h]={'path':name,'sha256':h,'bytes':len(b),'lines':len(b.splitlines()),'stored_sha256':sha(packed),'stored_bytes':len(packed),'origins':[]}
        objects[h]['origins'].append({'path':alias,'role':role});aliases[alias]=h
    selection.append({'source':alias,'sha256':h,'bytes':len(b),'lines':len(b.splitlines()),'role':role})
archive(W/PARENT,'Complete actual direct canonical parent; full964-line source read')
for name in ['IMPORTS.json','PARENT_BINDINGS.json','J_PRECISION.md','SOURCE_REVIEW_STATUS.json','PUBLICATION_ROOT_ACCEPTANCE.json','PUBLICATION_ASSEMBLY_REVIEW.txt']:
    archive(W/PK/name,'Complete selected parent provenance record read; not a recursive parent archive or audit')
archive(Z/'ENERGY_TAIL_PR_CREATED.json','Actual regular open parent PR creation/verification receipt')
save(D/'ACTUAL_PARENT_PR_CREATED.json',raw(Z/'ENERGY_TAIL_PR_CREATED.json'))
ev['objects']=list(objects.values());ev['actual_parent_source_selection']=selection
ev['actual_parent_scope']='Complete canonical note plus six selected source/status records and actual PR receipt; no claim to reproduce or audit the whole parent packet.'
put(D/'EVIDENCE_MAP.json',ev)
parent_record={'path':PARENT,'claim_id':CID,'archive_alias':str(W/PARENT),'published_sha256':PARENT_SHA,'bytes':len(parent),'lines':964,'present_at_base':HEAD,'published_commit':HEAD,'regular_pr':9526}
maps=[]
for name,h,lines in [('POSTMEASUREMENT_ENERGY_UI_ROOT_PROBE.md','1dfe0c91716ade6e0cfc81ac4e185fa8e0783098963e2fea2460077ba768f639',306),('postmeasurement_energy_ui_independent/DERIVATION.md','9597693aa9fc6aebb93de7419d4e4dbb74a6156531179fef27e6107e75cf7c96',390)]:
    path=R/name;core=raw(path)
    need(sha(core)==h and len(core.splitlines())==lines and aliases[str(path)]==h,'Previously archived premise differs')
    need(parent.count(core)==1,'Parent does not contain exact complete core uniquely')
    start=parent.index(core);end=start+len(core)
    maps.append({'canonical_path':PARENT,'canonical_sha256':PARENT_SHA,'archive_alias':str(path),'core_sha256':h,'bytes':len(core),'lines':lines,'byte_start_inclusive':start,'byte_end_exclusive':end,'line_start_inclusive':parent[:start].count(b'\n')+1,'line_end_inclusive':parent[:end].count(b'\n')})
roles=[{'role':'ideal_uniform_forward_and_inverse_graph_bounds','actual_claim_id':CID,'canonical_path':PARENT,'canonical_sha256':PARENT_SHA,'body_locations':[[49,57],[187,210],[226,349],[503,727]],'verified_against_complete_body':True,'scope':'Supplied massive strict-gap smooth-slot model and its fixed resources; U6/U9 and T11/T19. Abstract theorem still states these assumptions.'},
 {'role':'regular_ideal_first_energy_tails_and_conditional_law_upgrade','actual_claim_id':CID,'canonical_path':PARENT,'canonical_sha256':PARENT_SHA,'body_locations':[[59,113],[351,419],[729,851]],'verified_against_complete_body':True,'scope':'Finite-first-energy tails and conditional law upgrade. Regular normal-state weak law remains an additional supplied provisional premise, not a consequence of graph bounds or the canonical vacuum parent.','discharges_normal_state_weak_law_assumption':False}]
label='Finite-first-energy tails and ideal forward/inverse graph bounds'
citation={'parent_path':PARENT,'claim_id':CID,'label':label,'target':Path(PARENT).name,'markdown':'['+label+']('+Path(PARENT).name+')'}
bindings=js(D/'PARENT_BINDINGS.json')
bindings.update(binding_complete=True,actual_parent_pr=pr,actual_parent_head=HEAD,actual_attachment=None,
 attachment_scope='No separate attachment receipt supplied to this source preparer; no attachment verification claimed. Root owns PR attachment.',
 parents=[parent_record],canonical_core_maps=maps,required_roles=roles,direct_edges_verified=True,
 markdown_citations=[citation],markdown_citations_verified=True,reason_unresolved=None,
 parent_creation_receipt_sha256=sha(raw(Z/'ENERGY_TAIL_PR_CREATED.json')),
 provisional_normal_state_weak_law_remains_assumption=True,
 parent_provisional_dependency_inventory=js(W/PK/'IMPORTS.json')['provisional_supplied_scientific_dependencies'])
put(D/'PARENT_BINDINGS.json',bindings);put(Q/'PARENT_PUBLICATION_BINDING.json',bindings)
graph={'binding_complete':True,'nodes':[{'claim_id':spec['notes'][0]['claim_id'],'path':NOTE,'runner':spec['notes'][0]['runner'],'deps':[CID],'claim_type':'bounded_theorem'}],
 'direct_edges':[{'from':spec['notes'][0]['claim_id'],'to':CID}],'expected_delta':{'nodes':1,'edges':1},'publication_ancestry_is_not_additional_dependency':True}
put(D/'CLAIM_REGISTRY_ADDITIONS.json',graph)
imports=js(D/'THEOREM_APPLICATION_IMPORTS.json')
imports.update(application={'required_roles':roles,'actual_canonical_imports':[parent_record],'regular_ideal_normal_state_weak_law':'Explicit application assumption; published parent preserves prepared340/512 and initial407 as supplied provisional sources, not canonically proved normal-state laws.'},unresolved=False)
put(D/'THEOREM_APPLICATION_IMPORTS.json',imports)
status=js(D/'SOURCE_REVIEW_STATUS.json');status.update(base=HEAD,canonical_parent_binding_complete=True,
 canonical_parent_markdown_citations_verified=True,provisional_normal_state_weak_law_remains_assumption=True)
put(D/'SOURCE_REVIEW_STATUS.json',status)
put(D/'GRAPH_CALIBRATION_BRANCH_PLAN.json',{'base':HEAD,'branch':spec['branch'],'parent_pr':pr['url'],'branch_created_by_source_preparer':False,'binding_complete':True})
spec.update(base=HEAD,main='583c699e859b64ff01c8bc92d1c04bdfe9994509',stack_parent=pr['headRefName'],stack_parent_regular_pr=9526,
 binding_complete=True,expected_graph_delta={'nodes':1,'edges':1},parent_runner_diagnostics=['scripts/energy_tail_identity_2026_10_13.py'])
spec['notes'][0]['deps']=[CID];put(Q/'SPECIFICATIONS.json',spec)
prefix=raw(Q/'wrappers/note_prefix.md').decode()
need(sha(prefix.encode())=='2781d91b48c72505b1d2e052fef1b07b079d6b8dfa061a3c894d6af44e538a2d','Unbound wrapper changed')
for old,new in [
 ('assembly_status: publication_preparation_parent_unresolved','assembly_status: parent_bound_source_ready_for_root_review'),
 ('canonical_parent_binding_complete: false','canonical_parent_binding_complete: true'),
 ('next_trace_action: bind the actual published energy-tail parent, complete direct-edge review, then obtain separate root source-integration acceptance','next_trace_action: obtain separate root source-integration acceptance of the bound publication package'),
 ('upstream_dependencies: []','upstream_dependencies:\n  - '+CID),
 ('Publication binding is incomplete. The empty dependency list above is a\npreparation placeholder, not a reviewed assertion of a dependency-free\napplication. This source must not be installed until the exact parent roles,\ncanonical bodies and graph delta are reviewed and the marker is resolved.','The canonical parent is bound to its actual regular PR and exact published\nsource. Separate root acceptance of this publication package is still required\nbefore installation or runtime. Source checks establish byte identities only.'),
 ('| Supplied model\'s ideal graph theorem | Historical postmeasurement sources are archived as premise provenance with their \\(J=\\Gamma C\\) precision. This candidate does not silently promote them to a new canonical retained dependency. |','| Supplied model\'s ideal graph theorem | The exact published tail parent supplies U6/U9 and T11/T19 in its strict-gap fixed-resource model, with the required \\(J=\\Gamma C\\) precision. No retained status is inferred. |'),
 ('| Future canonical energy-tail publication | Not supplied at this freeze. Root will provide it after its regular PR publication; no dependency edge, source path, PR identity or base head is invented. |','| Canonical tail application | Regular PR9526 supplies finite-first-energy tails and a conditional limiting-law upgrade. Its prepared normal-state weak law remains a supplied provisional assumption; the vacuum canonical parent does not establish it. |'),
 ('Connecting this application to that canonical publication is a later\nsource-integration step, not a missing proof inside the abstract theorem.','The application is now bound to the exact published tail parent. Its prepared\nnormal-state weak-law premise remains conditional; no scientific hypothesis\nis discharged solely by Git ancestry or source-identity checks.'),
 ('wrapper and programs require their own exact root acceptance; parent binding\nand publication integration remain open.','wrapper and programs require their own exact root acceptance. Actual parent\nbinding is complete; publication integration and retained audit remain open.')]:prefix=replace(prefix,old,new)
begin='<!-- BEGIN CANONICAL PARENT BINDING -->';end='<!-- END CANONICAL PARENT BINDING -->'
start=prefix.index(begin)+len(begin);stop=prefix.index(end)
block='''
The direct parent is '''+citation['markdown']+''',
published in regular open PR9526 at commit
`ccbeddd0c04b70ee2b6c5f1cffeeeefa23df2989`. Its complete964-line source has SHA-256
`dc6510563d6fcf2e9db38590b2004f3e5e24677b4fd8b0e0d6ffb83cef9eb592`.

The parent supplies ideal full and half graph bounds for both evolution
directions in its supplied massive strict-gap smooth-slot setting, together
with fixed-protocol finite-first-energy tails. Its regular normal-state
weak-law corollary explicitly assumes the archived prepared-state theorem;
that law remains a supplied provisional scientific dependency here. The
canonical vacuum multi-time parent does not establish the normal-state law.
The abstract result below continues to state graph regularity and the ideal
regular history law as assumptions when applied outside that supplied setting.

One new claim node and one direct canonical edge are proposed. Historical
source aliases, the tail parent's ancestors and sibling PR9518 do not create
additional direct edges. Exact complete-core containment and premise-role
locations are recorded in PARENT_BINDINGS.json. The original J sentence is
read with the required linear/unitary J=Gamma C precision. The parent's
epsilon=o(h^2) comparison remains valid; this note proves the stated sharper
sufficient calibration scale under the uniform ideal graph hypotheses.
'''
prefix=prefix[:start]+block+prefix[stop:];save(Q/'wrappers/note_prefix.md',prefix)
edits=js(D/'PUBLICATION_EDITS.json');n=edits['notes'][0];n['pieces'][0]['text']=prefix
built=b''
for piece in n['pieces']:
    if piece['kind']=='publication_wrapper':b=piece['text'].encode()
    else:
        original=raw(piece['source_path']);b=b''.join(original.splitlines(True)[piece['source_line_start']-1:piece['source_line_end']])
        need(sha(b)==piece['expected_slice_sha256'],'Immutable mathematical body changed')
    piece.update(sha256=sha(b),bytes=len(b),byte_offset=len(built),first_line=built.count(b'\n')+1,last_line=(built+b).count(b'\n'));built+=b
save(P/NOTE,built)
def refresh_diff(row,old,new,name):
    delta=diff(old,new,row['fromfile'],row['tofile']);packed=gzip.compress(delta,mtime=0)
    save(D/row['diff'],packed);save(Q/'readable_diffs'/name,delta)
    row.update(diff_sha256=sha(delta),diff_bytes=len(delta),diff_stored_sha256=sha(packed),stored_bytes=len(packed))
n.update(published_sha256=sha(built),published_bytes=len(built),published_lines=len(built.splitlines()))
refresh_diff(n,raw(A/'CURRENT_CANDIDATE.md'),built,'accepted_assembly_to_publication.diff')
change=edits['wrapper_changes'][0];change['publication_sha256']=sha(prefix.encode())
refresh_diff(change,raw(A/'CURRENT_WRAPPER.md'),prefix.encode(),'current_wrapper_to_publication.diff')
put(D/'PUBLICATION_EDITS.json',edits)
put(Q/'ACTUAL_PARENT_SOURCE_BINDING.json',{'parent':parent_record,'receipt_sha256':sha(raw(Z/'ENERGY_TAIL_PR_CREATED.json')),'complete_parent_read_outputs':['0585f3','09b625','d0b806'],'selected_parent_records_read_output':'e23b28','parent_roles':roles,'core_maps':maps,'direct_edges':graph['direct_edges'],'ordinary_source_binding_not_retained_audit':True,'provisional_weak_law_assumption_preserved':True,'mathematical_core_edits':0,'mathematical_predicates':0})
for path,content in pending_writes.items():
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(content)
print(json.dumps({'parent_bound':True,'parent_pr':9526,'base':HEAD,'direct_edges':1,'parent_source_selection':len(selection),'archive_objects':len(objects),'archive_aliases':len(aliases),'note_sha256':sha(built),'mathematical_core_edits':0,'proposed_programs_executed':False,'mathematical_predicates':0},indent=2))
