"""Deterministic publication-source construction; never executes a proposed runner."""
from pathlib import Path
import difflib, gzip, hashlib, json

Q = Path(__file__).resolve().parent
Z = Q.parent
R = Z.parent / 'resume_20261012'
A = Z / 'graph_calibration_source_assembly'
W = Z.parent / 'correlation_worktree'
P = Q / 'payload'
K = '.claude/science/physics-loops/toe-graph-calibration-20261013'
NOTE = 'docs/GRAPH_CALIBRATION_BOUNDED_THEOREM_NOTE_2026-10-13.md'
RUNNER = 'scripts/graph_calibration_identity_2026_10_13.py'
CLAIM = 'graph_calibration_bounded_theorem_note_2026-10-13'
BRANCH = 'physics-loop/toe-graph-calibration-20261013'
SEAL = '281a36b1dc50d9eb2c052ce5b16bf8fbdcfc96998abaf775705c5879a6fdd035'
CANDIDATE = '1e75e8f37995f7ba00a1b7b630d3957d61b1d12ad265da55acd2f7969ae11a89'
WRAPPER = '9142b08d248873a5a080b63db861cc0c120abbc20a1ca929cb4ce7058e785017'

def raw(p): return Path(p).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p): return json.loads(raw(p))
def save(p, b):
    p = Path(p)
    assert p.resolve().is_relative_to(Q)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b if isinstance(b, bytes) else b.encode())
def put(p, value): save(p, json.dumps(value, indent=2, sort_keys=True) + '\n')
def packet(n, value): put(P / K / n, value)
def need(v, why):
    if not v: raise ValueError(why)
def diff(a, b, old, new):
    return b''.join(difflib.diff_bytes(difflib.unified_diff, a.splitlines(True), b.splitlines(True), fromfile=old.encode(), tofile=new.encode(), n=3))
def replace_once(text, old, new):
    need(text.count(old) == 1, 'Unique wrapper edit anchor required')
    return text.replace(old, new, 1)

if (Q / 'SPECIFICATIONS.json').exists():
    need(js(Q / 'SPECIFICATIONS.json')['binding_complete'] is False,
         'Initial unbound construction cannot overwrite resolved parent bindings')
need(sha(raw(A / 'FINAL_FREEZE.json')) == SEAL, 'Assembly freeze drift')
need(sha(raw(A / 'CURRENT_CANDIDATE.md')) == CANDIDATE, 'Candidate drift')
need(sha(raw(A / 'CURRENT_WRAPPER.md')) == WRAPPER, 'Wrapper drift')
assembly_seal = js(A / 'FINAL_FREEZE.json')
need(len(assembly_seal['members']) == assembly_seal['member_count'] == 112, 'Assembly membership differs')
need({str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()} ==
     {r['path'] for r in assembly_seal['members']} | {'FINAL_FREEZE.json'}, 'Complete assembly differs')
for r in assembly_seal['members']:
    b = raw(A / r['path'])
    need(sha(b) == r['sha256'] and len(b) == r['bytes'], 'Assembly member drift')
need(js(Z / 'GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json')['freeze_sha256'] == SEAL, 'Assembly acceptance differs')

templates = {
 'threshold_crossing_chirp_publication_preparation': [
  'README.md', 'SPECIFICATIONS.json', 'PARENT_PUBLICATION_BINDING.json',
  'ROOT_REPRODUCTION.md', 'SOURCE_ONLY_EXECUTION_POLICY.json', 'COMBINED_VALIDATION_PLAN.json',
  'BUILD_SOURCE_ONLY.py', 'IDENTITY_TOOL.template.py', 'prepare_verify_threshold_crossing_chirp.py',
  'CHECK_PREPARATION_SOURCES.py', 'FINALIZE_SOURCE_ONLY.py', 'ROOT_ACCEPTANCE.template.json',
  'run_combined_validation.py'],
 'multitime_kinetic_energy_publication_preparation': [
  'README.md', 'SPECIFICATIONS.json', 'PARENT_PUBLICATION.json', 'ROOT_REPRODUCTION.md',
  'SOURCE_ONLY_EXECUTION_POLICY.json', 'SOURCE_CHECK_PROTOCOL.json', 'PROCEDURE_REUSE.json']}
template_rows = []
for folder, names in templates.items():
    for n in names:
        source = R / folder / n
        dest = Q / 'procedural_template' / folder / n
        save(dest, raw(source))
        template_rows.append({'source':str(source), 'archive':str(dest.relative_to(Q)), 'sha256':sha(raw(source)), 'bytes':len(raw(source)), 'coverage':'complete source read; template only'})
T = R / 'threshold_crossing_chirp_publication_preparation'
TK = '.claude/science/physics-loops/toe-threshold-crossing-chirp-20261013'
for n in ['HANDOFF.md','REVIEW_HISTORY.md','CONFORMANCE.md','TRACE_GATE.md','CLAIM_STATUS_CERTIFICATE.md','ASSUMPTIONS_AND_IMPORTS.md','NO_GO_DISCIPLINE_CHECKLIST.md','NO_GO_LEDGER.md']:
    source = T / 'payload' / TK / n
    dest = Q / 'procedural_template' / 'packet' / n
    save(dest, raw(source))
    template_rows.append({'source':str(source), 'archive':str(dest.relative_to(Q)), 'sha256':sha(raw(source)), 'bytes':len(raw(source)), 'coverage':'complete source read; template only'})
put(Q / 'TEMPLATE_SELECTION.json', {'files':template_rows, 'scope':'Procedural source patterns only; no mathematical dependency on these historical publications.'})

objects, aliases = {}, {}
def archive(path, role):
    path = Path(path)
    b = raw(path); h = sha(b); alias = str(path)
    if alias in aliases:
        need(aliases[alias] == h, 'Alias changed'); return
    aliases[alias] = h
    if h not in objects:
        z = gzip.compress(b, mtime=0)
        name = 'objects/' + h + '.gz'
        save(P / K / name, z)
        objects[h] = {'path':name, 'sha256':h, 'bytes':len(b), 'lines':len(b.splitlines()), 'stored_sha256':sha(z), 'stored_bytes':len(z), 'origins':[]}
    objects[h]['origins'].append({'path':alias, 'role':role})
for p in sorted(A.rglob('*')):
    if p.is_file(): archive(p, 'complete accepted assembly, including its immutable archive')
selection = js(A / 'ARCHIVE_MANIFEST.json')['sources']
for r in selection:
    need(sha(raw(r['source'])) == r['sha256'] and raw(r['source']) == raw(A / r['archive']), 'Original alias drift')
    archive(r['source'], 'original alias already pinned in accepted assembly')
for row in template_rows: archive(row['source'], 'procedural template; no mathematical dependency')
for n in ['GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json','GRAPH_CALIBRATION_ASSEMBLY_ROOT_REVIEW.md','PRIOR_PROCEDURE_REUSE_CHECK.json']:
    archive(Z / n, 'actual root source acceptance or procedure identity receipt')
    save(P / K / n, raw(Z / n))
evidence = {'objects':list(objects.values()), 'accepted_source_package':{
 'path':str(A), 'freeze_sha256':SEAL, 'members':assembly_seal['members'], 'member_count':112,
 'additional_files':[{'path':'FINAL_FREEZE.json','sha256':SEAL,'bytes':len(raw(A/'FINAL_FREEZE.json'))}],
 'complete_file_count':113}, 'original_source_selection_count':len(selection),
 'scope':'Complete accepted assembly, its selected original aliases and explicit procedural templates. Historical freezes have only their recorded scopes; no recursive scientific audit.'}
packet('EVIDENCE_MAP.json', evidence)

front = '''---
title: "Conditional calibration stability for finite energy measurements"
claim_id: graph_calibration_bounded_theorem_note_2026-10-13
status: conditional-support
claim_type: bounded_theorem
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
artifact_role: theorem
assembly_status: publication_preparation_parent_unresolved
canonical_parent_binding_complete: false
scientific_execution: none_in_publication_source_preparation
runner: scripts/graph_calibration_identity_2026_10_13.py
trace_class: upstream_support
target_claim_id: null
target_blocker_text: null
source_of_blocker_text: frontier_question
reachability_to_target: supports
conditional_surface_status: assumed common H and spectral instrument; uniform ideal graph bounds; bounded control and first-commutator calibration errors; regular ideal history law for application; fixed resources
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: conditional positive graph perturbation theorem with explicit common-model hypotheses and preserved analytic checks
next_trace_action: bind the actual published energy-tail parent, complete direct-edge review, then obtain separate root source-integration acceptance
audit_required_before_effective_retained: true
bare_retained_allowed: false
upstream_dependencies: []
---

Claim type: bounded_theorem

Publication binding is incomplete. The empty dependency list above is a
preparation placeholder, not a reviewed assertion of a dependency-free
application. This source must not be installed until the exact parent roles,
canonical bodies and graph delta are reviewed and the marker is resolved.

<!-- BEGIN CANONICAL PARENT BINDING -->
The regular energy-tail parent PR, head, canonical note paths, claim IDs,
source hashes, containment maps and resulting direct edges remain unresolved.
No unfinished parent preparation has been read or used. The abstract theorem
below explicitly assumes its ideal graph bounds and regular ideal history law.
Each final direct parent must have a descriptive Markdown citation in this
block. YAML dependency metadata alone does not create a citation-graph edge.
The source-only guard will compare the recognized citations with every final
declared parent; that comparison remains unresolved until actual binding.
<!-- END CANONICAL PARENT BINDING -->

'''
wrapper = raw(A / 'CURRENT_WRAPPER.md').decode()
wrapper = replace_once(wrapper, 'This source candidate packages a checked conditional perturbation theorem.', 'This publication candidate packages a checked conditional perturbation theorem.')
wrapper = replace_once(wrapper, 'This assembly adds no independent mathematical review, retained', 'This publication preparation adds no independent mathematical review, retained')
wrapper = replace_once(wrapper, 'This packet creates no driver, branch, PR or audit verdict.', 'A root-owned publication driver is proposed as reviewable source. It has not\nbeen executed. This preparation creates no branch, PR or audit verdict.')
wrapper = replace_once(wrapper, 'No editable prompt, physical axiom, audit status or original scientific\nsource was changed in this assembly. Ordinary source acceptance applies to\nthe reviewed mathematics; this current wrapper still awaits root source\nacceptance and publication integration.', 'No editable prompt, physical axiom, audit status or original scientific\nsource is changed by this preparation. The accepted assembly received root\nsource acceptance at 21:56:52 UTC on 2026-10-13. The present publication\nwrapper and programs require their own exact root acceptance; parent binding\nand publication integration remain open.')
prefix = (front + wrapper).encode()
candidate = raw(A / 'CURRENT_CANDIDATE.md')
old_wrapper = raw(A / 'CURRENT_WRAPPER.md')
need(candidate.startswith(old_wrapper), 'Accepted wrapper not exact prefix')
published = prefix + candidate[len(old_wrapper):]
save(Q / 'wrappers/note_prefix.md', prefix)
save(Q / 'wrappers/unchanged_appendix_framing.md', candidate[len(old_wrapper):])
save(P / NOTE, published)
extractions = js(A / 'EXTRACTION_MANIFEST.json')['extractions']
pieces = []
cursor = len(old_wrapper)
assembled = prefix
pieces.append({'kind':'publication_wrapper','wrapper_path':'wrappers/note_prefix.md','text':prefix.decode(),'sha256':sha(prefix),'bytes':len(prefix),'byte_offset':0,'first_line':1,'last_line':prefix.count(b'\n')})
for r in extractions:
    begin, end = r['body_start_byte'], r['body_end_byte']
    framing = candidate[cursor:begin]
    name = 'wrappers/before_' + r['label'] + '.md'
    save(Q / name, framing)
    pieces.append({'kind':'publication_wrapper','wrapper_path':name,'text':framing.decode(),'sha256':sha(framing),'bytes':len(framing),'byte_offset':len(assembled),'first_line':assembled.count(b'\n')+1,'last_line':(assembled+framing).count(b'\n')})
    assembled += framing
    core = candidate[begin:end]
    need(core == raw(A / r['archive']) and sha(core) == r['sha256'], 'Immutable extraction differs')
    pieces.append({'kind':'accepted_core_slice','source_path':str(A/r['archive']),'source_sha256':r['sha256'],'source_line_start':1,'source_line_end':r['lines'],'expected_slice_sha256':r['sha256'],'additional_mathematical_body_edits':[],'sha256':r['sha256'],'bytes':len(core),'byte_offset':len(assembled),'first_line':assembled.count(b'\n')+1,'last_line':(assembled+core).count(b'\n')})
    assembled += core; cursor = end
ending = candidate[cursor:]
save(Q / 'wrappers/note_suffix.md', ending)
pieces.append({'kind':'publication_wrapper','wrapper_path':'wrappers/note_suffix.md','text':ending.decode(),'sha256':sha(ending),'bytes':len(ending),'byte_offset':len(assembled),'first_line':assembled.count(b'\n')+1,'last_line':(assembled+ending).count(b'\n')})
assembled += ending
need(assembled == published, 'Publication reconstruction differs')
def record_diff(name, old, new, oldname, newname):
    d = diff(old, new, oldname, newname); z = gzip.compress(d, mtime=0)
    save(Q / 'readable_diffs' / (name+'.diff'), d)
    save(P / K / 'diffs' / (name+'.diff.gz'), z)
    return {'diff':'diffs/'+name+'.diff.gz','diff_sha256':sha(d),'diff_bytes':len(d),'diff_stored_sha256':sha(z),'stored_bytes':len(z),'context_lines':3,'fromfile':oldname,'tofile':newname}
note = {'note':NOTE,'accepted_candidate_path':str(A/'CURRENT_CANDIDATE.md'),'accepted_candidate_sha256':CANDIDATE,'published_sha256':sha(published),'published_bytes':len(published),'published_lines':len(published.splitlines()),'pieces':pieces,**record_diff('accepted_assembly_to_publication',candidate,published,'accepted_assembly/CURRENT_CANDIDATE.md',NOTE)}
change = {'source_line_range':[1,223],'source_sha256':WRAPPER,'publication':'wrappers/note_prefix.md','publication_sha256':sha(prefix),**record_diff('current_wrapper_to_publication',old_wrapper,prefix,'accepted_assembly/CURRENT_WRAPPER.md','wrappers/note_prefix.md')}
packet('PUBLICATION_EDITS.json', {'source_freeze_sha256':SEAL,'notes':[note],'wrapper_changes':[change],'additional_mathematical_body_edits':[]})

roles = [
 {'role':'ideal_uniform_forward_and_inverse_graph_bounds','actual_claim_id':None,'canonical_path':None,'canonical_sha256':None,'body_locations':None,'verified_against_complete_body':False},
 {'role':'regular_ideal_finite_history_law_and_first_energy_tails','actual_claim_id':None,'canonical_path':None,'canonical_sha256':None,'body_locations':None,'verified_against_complete_body':False}]
bindings = {'binding_complete':False,'actual_parent_pr':None,'actual_parent_head':None,'actual_attachment':None,
 'markdown_citations':[],'markdown_citations_verified':False,
 'parents':[],'canonical_core_maps':[],'required_roles':roles,
 'historical_premise_archive_is_not_automatically_a_direct_edge':True,
 'standalone_hypotheses':js(A/'DEPENDENCIES.json')['abstract_hypotheses'],
 'application_hypotheses':js(A/'DEPENDENCIES.json')['application_hypotheses'],
 'direct_edges_verified':False,'reason_unresolved':'Root has not yet supplied the actual published regular energy-tail parent.'}
packet('PARENT_BINDINGS.json', bindings)
put(Q / 'PARENT_PUBLICATION_BINDING.json', bindings)
graph = {'binding_complete':False,'nodes':[{'claim_id':CLAIM,'path':NOTE,'runner':RUNNER,'deps':None,'claim_type':'bounded_theorem'}], 'direct_edges':None,'expected_delta':{'nodes':1,'edges':None},'empty_or_null_is_placeholder_not_no_dependency_claim':True}
packet('CLAIM_REGISTRY_ADDITIONS.json', graph)
packet('THEOREM_APPLICATION_IMPORTS.json', {'abstract_theorem':{'import_mode':'explicit hypotheses','canonical_edges_implied_by_hypotheses':[]},'application':{'required_roles':roles,'actual_canonical_imports':None},'publication_ancestry_is_not_mathematical_dependency':True,'unresolved':True})
packet('SOURCE_REVIEW_STATUS.json', {'base':None,'branch':BRANCH,'disposition':'source_only_publication_preparation_of_accepted_conditional_cores','prepared_source_freeze_sha256':SEAL,'source_assembly_root_acceptance_sha256':sha(raw(Z/'GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json')),'source_assembly_root_review_sha256':sha(raw(Z/'GRAPH_CALIBRATION_ASSEMBLY_ROOT_REVIEW.md')),'source_review_coverage_verbatim':js(Z/'GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json'),'root_core_sha256':extractions[0]['sha256'],'independent_core_sha256':extractions[1]['sha256'],'no_go_packet_pass':False,'mathematical_core_edits':0,'new_independent_mathematical_review':False,'unchanged_complete_core_coverage_reused':True,'publication_runtime_executed_by_source_preparer':False,'uniform_C_G_required_for_full_theorem':True,'growing_C_G_single_propagator_only':True,'calibration_order_p_distinct_from_chain_count':True,'common_H_assumed_not_retained':True,'regular_ideal_law_is_application_assumption':True,'fixed_slot_continuum_necessity_proved':False,'canonical_parent_binding_complete':False,'scientific_predicates':0})
packet('GRAPH_CALIBRATION_BRANCH_PLAN.json', {'base':None,'branch':BRANCH,'parent_pr':None,'branch_created_by_source_preparer':False,'binding_complete':False})
packet('MARKDOWN_NOTATION_CLASSIFICATION.json', {'note':NOTE,'note_sha256':sha(published),'exclusions':[],'classification':'Unresolved pending exact source scan; no broad mathematical-link exemption.'})
packet('SOURCE_WHITESPACE_CLASSIFICATION.json', {'preserved_source_whitespace':[],'policy':'Exact gzip archives preserve raw bytes; no broad text exemption.'})
spec = {'base':None,'branch':BRANCH,'deadline_utc':'2026-10-14T21:37:33Z','expected_graph_delta':{'nodes':1,'edges':None},'main':None,'notes':[{'claim_id':CLAIM,'deps':None,'key':'graph_calibration','path':NOTE,'runner':RUNNER}],'packet':K,'parent_runner_diagnostics':None,'preserved_source_whitespace':[],'notation_exclusions':[],'raw_diff_payload_policy':'gzip archives only; exact raw and stored pins','stack_parent':None,'stack_parent_regular_pr':None,'worktree':str(W),'binding_complete':False}
put(Q / 'SPECIFICATIONS.json', spec)
procedure = js(R/'multitime_kinetic_energy_publication_preparation/PROCEDURE_REUSE.json')
for r in procedure['files']:
    b = raw(W/r['path']); need(sha(b)==r['sha256'] and len(b)==r['bytes'], 'Procedure drift requires renewed review')
procedure['scope'] = 'Exact18 procedure identities refreshed during source preparation; prior procedure coverage reused. No canonical procedure execution.'
put(Q/'PROCEDURE_REUSE.json', procedure)
put(Q/'SOURCE_ONLY_EXECUTION_POLICY.json', {'allowed':'Deterministic source construction, hashing/diffing, exact extraction and archive checking, AST parsing; no import or execution of proposed programs.','prohibited':['proposed identity runner','prepare/verify driver','combined validation','canonical cache','graph/pipeline','Git/CW mutation','science runtime','audit/axiom/prompt changes'],'mathematical_predicates':0,'editable_prompt_files_changed':[]})
print(json.dumps({'status':'unbound_source_structure_constructed','archive_objects':len(objects),'archive_aliases':len(aliases),'assembly_files':113,'canonical_parent_bindings_resolved':False,'proposed_runtime_executed':False,'mathematical_predicates':0},indent=2))
