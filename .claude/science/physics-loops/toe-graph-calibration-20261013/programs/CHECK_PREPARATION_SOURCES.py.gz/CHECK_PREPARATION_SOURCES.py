"""Read-only source reconstruction; never import or execute proposed programs."""
from pathlib import Path, PurePosixPath
import argparse, ast, difflib, gzip, hashlib, json, re, urllib.parse
Q=Path(__file__).resolve().parent
def raw(p): return Path(p).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p): return json.loads(raw(p))
def need(ok,message):
    if not ok: raise ValueError(message)
def diff(a,b,x,y):
    return b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=x.encode(),tofile=y.encode(),n=3))
def check_parent_markdown(spec,parents,note):
    """Source-only, lane-scoped link/edge check; never runs the graph producer."""
    worktree=Path(spec['worktree']).resolve(); docs=worktree/'docs'
    procedure='docs/audit/scripts/build_citation_graph.py'
    source=raw(worktree/procedure)
    need(sha(source)=='df4e1a20357554d15f630faf5bab3c37f758097fe7c66e93572ac3b9b792ccae','Citation builder revision changed')
    patterns=[ast.literal_eval(n.value.args[0]) for n in ast.parse(source).body
              if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LINK_RE' for t in n.targets)]
    pattern=r'\[[^\]]*\]\(([^)\s#]+\.md)(?:#[^)]*)?\)'
    need(patterns==[pattern],'Pinned builder link pattern differs')
    link_re=re.compile(pattern); text=note.decode(); raw_targets=link_re.findall(text)
    citations=parents['markdown_citations']
    if not spec['binding_complete']:
        need(parents['markdown_citations_verified'] is False and citations==[] and raw_targets==[], 'Unbound parent citation or false verification')
        return {'status':'unresolved_until_actual_parent_binding','recognized_parent_citations':0,'canonical_graph_executed':False}
    need(parents['markdown_citations_verified'] is True and len(citations)==len(parents['parents']), 'Final parent citation coverage incomplete')
    begin,end='<!-- BEGIN CANONICAL PARENT BINDING -->','<!-- END CANONICAL PARENT BINDING -->'
    need(text.count(begin)==text.count(end)==1 and text.index(begin)<text.index(end),'Canonical parent block differs')
    block=text.split(begin,1)[1].split(end,1)[0]
    # Top-level docs notes are outside every skip class at the pinned revision.
    # The builder's axiom alias exception is checked as data, not assumed away.
    alias_file=worktree/'docs/audit/data/axiom_premise_nodes.json'
    alias_data=js(alias_file) if alias_file.exists() else {}
    alias_paths={str(p) for v in (alias_data.get('nodes') or {}).values() for p in v.get('aliased_paths',[])}
    expected=[]
    for p,r in zip(parents['parents'],citations):
        path=PurePosixPath(p['path'])
        need(path.parts==('docs',path.name) and path.suffix=='.md' and p['path'] not in alias_paths,'Unreviewed canonical parent path/alias class')
        need(p['claim_id']==path.stem.lower(),'Builder-derived parent claim ID differs')
        need(r['parent_path']==p['path'] and r['claim_id']==p['claim_id'] and r['target']==path.name,'Parent citation target differs')
        need(r['label'].strip()==r['label'] and ' ' in r['label'] and not any(c in r['label'] for c in '[]\n\r'),'Descriptive parent label required')
        literal='['+r['label']+']('+r['target']+')'
        need(r['markdown']==literal and block.count(literal)==text.count(literal)==1 and link_re.findall(literal)==[r['target']],'Parent citation literal differs')
        canonical=worktree/p['path']
        need(canonical.is_file() and not canonical.is_symlink() and canonical.resolve()==canonical,'Canonical graph parent path missing or redirected')
        need(sha(raw(canonical))==p['published_sha256'],'Citation target canonical bytes differ')
        expected.append(canonical)
    need(raw_targets==[r['target'] for r in citations],'Recognized citations do not equal declared parents')
    # Same URL decoding, absolute /docs/ rewrite, containment and existence
    # rules as the pinned resolver; same ordered deduplication as extractor.
    source_path=(worktree/spec['notes'][0]['path']).resolve(); resolved={}
    for target in raw_targets:
        decoded=urllib.parse.unquote(target)
        if decoded.startswith('/'):
            marker='/docs/'; idx=decoded.find(marker)
            if idx<0: continue
            candidate=(docs/decoded[idx+len(marker):]).resolve()
        else: candidate=(source_path.parent/decoded).resolve()
        try: candidate.relative_to(docs)
        except ValueError: continue
        if not candidate.exists() or candidate==source_path: continue
        resolved.setdefault(candidate,None)
    need(list(resolved)==expected,'Builder-resolved parent citations differ')
    return {'status':'source_only_parent_citations_match_declared_edges','recognized_parent_citations':len(expected),'canonical_graph_executed':False}
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify-originals',action='store_true')
    ap.add_argument('--require-bound',action='store_true')
    ap.add_argument('--require-freeze',action='store_true')
    args=ap.parse_args()
    spec=js(Q/'SPECIFICATIONS.json'); P=Q/'payload'; D=P/spec['packet']
    ev=js(D/'EVIDENCE_MAP.json'); contents={}; aliases={}; originals=0
    for r in ev['objects']:
        packed=raw(D/r['path']); b=gzip.decompress(packed)
        need(sha(packed)==r['stored_sha256'] and len(packed)==r['stored_bytes'],'Compressed archive identity')
        need(sha(b)==r['sha256'] and len(b)==r['bytes'] and len(b.splitlines())==r['lines'],'Raw archive identity')
        need(r['sha256'] not in contents,'Duplicate object'); contents[r['sha256']]=b
        for o in r['origins']:
            need(o['path'] not in aliases,'Duplicate alias'); aliases[o['path']]=b
            if args.verify_originals:
                need(raw(o['path'])==b,'Live original drift: '+o['path']); originals+=1
    c=ev['accepted_source_package']; prefix=c['path']+'/'
    source=lambda n:aliases[prefix+n]
    need(sha(source('FINAL_FREEZE.json'))==c['freeze_sha256'],'Assembly freeze')
    seal=json.loads(source('FINAL_FREEZE.json'))
    need(seal['members']==c['members'] and len(c['members'])==c['member_count']==112,'Frozen assembly membership')
    need(len(c['additional_files'])==1 and c['complete_file_count']==113,'Complete assembly membership')
    need({p for p in aliases if p.startswith(prefix)}=={prefix+r['path'] for r in c['members']+c['additional_files']},'Complete assembly aliases')
    for r in c['members']+c['additional_files']:
        b=source(r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Assembly member')
    selection=json.loads(source('ARCHIVE_MANIFEST.json'))['sources']
    need(len(selection)==ev['original_source_selection_count']==98,'Original selection')
    for r in selection:
        need(source(r['archive'])==aliases[r['source']] and sha(aliases[r['source']])==r['sha256'],'Original-to-archive map')
    mapping=json.loads(source('EXTRACTION_MANIFEST.json')); accepted=source(mapping['candidate']); expected=[]
    for r in mapping['extractions']:
        a,z=r['body_start_byte'],r['body_end_byte']; b=source(r['archive'])
        need(accepted[a:z]==b and sha(b)==r['sha256'],'Accepted extraction')
        need(accepted[:a].count(b'\n')+1==r['body_start_line'] and accepted[:z].count(b'\n')==r['body_end_line'],'Accepted extraction lines')
        expected.append(b)
    edits=js(D/'PUBLICATION_EDITS.json'); need(len(edits['notes'])==1 and edits['additional_mathematical_body_edits']==[],'Publication scope')
    n=edits['notes'][0]; actual=raw(P/n['note']); built=b''; bodies=[]; wrappers={}
    for r in n['pieces']:
        if r['kind']=='accepted_core_slice':
            original=aliases[r['source_path']]
            b=b''.join(original.splitlines(True)[r['source_line_start']-1:r['source_line_end']])
            need(sha(original)==r['source_sha256'] and sha(b)==r['expected_slice_sha256'] and r['additional_mathematical_body_edits']==[],'Immutable body')
            bodies.append(b)
        else:
            need(r['kind']=='publication_wrapper','Piece type'); b=r['text'].encode(); wrappers[r['wrapper_path']]=b
            need(raw(Q/r['wrapper_path'])==b,'Wrapper source')
        need(sha(b)==r['sha256'] and len(b)==r['bytes'] and r['byte_offset']==len(built),'Piece bytes')
        need(r['first_line']==built.count(b'\n')+1 and r['last_line']==(built+b).count(b'\n'),'Piece lines'); built+=b
    need(built==actual and sha(actual)==n['published_sha256'] and bodies==expected,'Published note reconstruction')
    def checkdiff(r,a,b):
        packed=raw(D/r['diff']); d=gzip.decompress(packed)
        need(sha(packed)==r['diff_stored_sha256'] and sha(d)==r['diff_sha256'] and len(d)==r['diff_bytes'] and len(packed)==r['stored_bytes'],'Diff identity')
        need(d==diff(a,b,r['fromfile'],r['tofile']) and r['context_lines']==3,'Diff producer')
    checkdiff(n,accepted,actual)
    for r in edits['wrapper_changes']:
        a,z=r['source_line_range']; checkdiff(r,b''.join(accepted.splitlines(True)[a-1:z]),wrappers[r['publication']])
    parents=js(D/'PARENT_BINDINGS.json'); graph=js(D/'CLAIM_REGISTRY_ADDITIONS.json')
    need(spec['binding_complete']==parents['binding_complete']==graph['binding_complete'],'Binding status consistency')
    citation_guard=check_parent_markdown(spec,parents,actual)
    citation_controls=[]
    if spec['binding_complete']:
        # Inert note-text omissions exercise only this source checker. No
        # canonical runner, graph producer or four runtime tamper probes run.
        for citation in parents['markdown_citations']:
            omitted=actual.replace(citation['markdown'].encode(),citation['label'].encode(),1)
            try: check_parent_markdown(spec,parents,omitted)
            except ValueError as error:
                need(str(error)=='Parent citation literal differs','Unexpected source-only citation rejection')
                citation_controls.append({'parent':citation['parent_path'],'result':'missing_markdown_citation_rejected','error':str(error),'note_hash_guard_used':False})
            else: need(False,'YAML-only parent citation omission was accepted')
    need(raw(Q/'PR_TITLE.proposed.txt')==b'[physics-loop] toe-graph-calibration-20261013 bounded_theorem conditional-support: Uniform energy-graph calibration\n','Required PR title prefix/slug/type/status differs')
    if args.require_bound or args.require_freeze: need(spec['binding_complete'] is True,'Actual parent unresolved')
    if spec['binding_complete']:
        need(parents['actual_parent_head']==spec['base'] and parents['direct_edges_verified'] is True,'Actual parent/head binding')
        deps=[p['claim_id'] for p in parents['parents']]
        need(graph['direct_edges']==[{'from':spec['notes'][0]['claim_id'],'to':d} for d in deps] and spec['notes'][0]['deps']==deps,'Exact direct edges')
        need(graph['expected_delta']==spec['expected_graph_delta']=={'nodes':1,'edges':len(deps)},'Exact delta')
        for r in parents['parents']:
            b=aliases[r['archive_alias']]; need(sha(b)==r['published_sha256'] and len(b)==r['bytes'],'Canonical archived parent')
            if args.verify_originals: need(raw(Path(spec['worktree'])/r['path'])==b,'Current parent drift')
        for r in parents['canonical_core_maps']:
            b=next(aliases[p['archive_alias']] for p in parents['parents'] if p['path']==r['canonical_path']); core=aliases[r['archive_alias']]
            a,z=r['byte_start_inclusive'],r['byte_end_exclusive']
            need(b[a:z]==core and b.count(core)==1 and sha(core)==r['core_sha256'],'Canonical core containment')
    else:
        need(spec['base'] is None and spec['stack_parent_regular_pr'] is None and parents['actual_parent_pr'] is None and parents['actual_parent_head'] is None,'Guessed parent identity')
        need(graph['direct_edges'] is None and graph['expected_delta']['edges'] is None and parents['parents']==[],'Unverified parent edge')
    for r in js(Q/'PROGRAM_DIFFS.json')['programs']:
        old=raw(Q/'procedural_template'/r['template']); new=raw(Q/r['program']); d=raw(Q/r['diff'])
        need(sha(old)==r['template_sha256'] and sha(new)==r['program_sha256'] and sha(d)==r['diff_sha256'],'Program identity')
        need(d==diff(old,new,'template/'+Path(r['template']).name,r['program']),'Program diff producer')
    for r in js(D/'PROGRAM_ARCHIVES.json')['files']:
        packed=raw(P/r['path']); b=gzip.decompress(packed)
        need(sha(packed)==r['sha256'] and len(packed)==r['bytes'] and sha(b)==r['raw_sha256'] and len(b)==r['raw_bytes'],'Program archive identity')
        relative=Path(r['path']).relative_to(spec['packet'])
        current=(Q/'program_diffs'/relative.name[:-3]) if relative.parts[0]=='program_diffs' else (Q/relative.name[:-3])
        need(raw(current)==b,'Current program/source diff archive drift')
    rendering=js(Q/'IDENTITY_RENDERING.json'); rendered=raw(Q/'IDENTITY_TOOL.template.py').decode()
    for token,value in rendering['substitutions'].items():
        need(token in rendered,'Missing rendering token'); rendered=rendered.replace(token,value)
    runner=raw(P/spec['notes'][0]['runner'])
    need(runner==rendered.encode() and sha(runner)==rendering['sha256'],'Identity source rendering')
    tree=ast.parse(runner); values={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['AUDIT_INPUT_PATHS','EXTRA_PINS']}
    inputs={str(p.relative_to(P)) for p in D.rglob('*') if p.is_file()}|{spec['notes'][0]['path']}|{r['path'] for r in parents['parents']}
    need(set(values['AUDIT_INPUT_PATHS'])==inputs and len(values['AUDIT_INPUT_PATHS'])==len(inputs),'Declared closure')
    metadata=['EVIDENCE_MAP.json','PUBLICATION_EDITS.json','PARENT_BINDINGS.json','SOURCE_REVIEW_STATUS.json','CLAIM_REGISTRY_ADDITIONS.json','GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json','GRAPH_CALIBRATION_ASSEMBLY_ROOT_REVIEW.md']
    sites={spec['packet']+'/'+name for name in metadata}|{spec['packet']+'/'+r['path'] for r in ev['objects']}|{n['note']}|{r['path'] for r in parents['parents']}|set(values['EXTRA_PINS'])
    sites|={spec['packet']+'/'+r['diff'] for r in [n]+edits['wrapper_changes']}
    need(sites==inputs,'Fully read identity-body read-site closure')
    for name,r in values['EXTRA_PINS'].items():
        b=raw(P/name); need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Additional pin')
    parsed=[]
    for p in sorted(Q.glob('*.py')):
        ast.parse(raw(p),filename=p.name); parsed.append(p.name)
    packet_source=ast.parse(raw(Q/'WRITE_PACKET_SOURCE_ONLY.py'))
    packet_literals=[]
    for statement in packet_source.body:
        if isinstance(statement,ast.Expr) and isinstance(statement.value,ast.Call) and isinstance(statement.value.func,ast.Name) and statement.value.func.id=='save':
            name,text=[ast.literal_eval(a) for a in statement.value.args]
            need(raw(D/name)==(text.rstrip('\n')+'\n').encode(),'Authored packet literal differs: '+name)
            packet_literals.append(name)
    need(set(packet_literals)=={'HANDOFF.md','REVIEW_HISTORY.md','CONFORMANCE.md','ASSUMPTIONS_AND_IMPORTS.md','DEPENDENCY_PLAN.md','CLAIM_STATUS_CERTIFICATE.md','TRACE_GATE.md','NO_GO_DISCIPLINE_CHECKLIST.md','NO_GO_LEDGER.md'},'Authored packet literal coverage')
    need(b'\nClaim type: bounded_theorem\n' in actual,'Body claim-type line')
    notation=js(D/'MARKDOWN_NOTATION_CLASSIFICATION.json')
    need(notation['note_sha256']==sha(actual) and notation['exclusions']==spec['notation_exclusions'],'Notation source identity')
    for r in spec['notation_exclusions']:
        lines=actual.decode().splitlines(True)
        need(lines[r['canonical_line']-1]==r['exact_line'] and actual.decode().count(r['context'])==1,'Exact notation exclusion')
    for p in P.rglob('*'):
        if p.is_file() and p.suffix!='.gz':
            b=raw(p);need(b.endswith(b'\n') and not b.endswith(b'\n\n'),'Terminal newline: '+str(p))
            need(not any(s.rstrip(b'\r\n').endswith((b' ',b'\t')) for s in b.splitlines(True)),'Trailing whitespace: '+str(p))
    if args.require_freeze:
        f=js(Q/'SOURCE_FREEZE.json'); names={r['path'] for r in f['files']}
        need(f['parent_binding_complete'] is True and len(names)==f['file_count'],'Final freeze scope')
        need({str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file() and p!=Q/'SOURCE_FREEZE.json'}==names,'Final freeze membership')
        for r in f['files']:
            b=raw(Q/r['path']); need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Final frozen identity')
    print(json.dumps({'scope':'source identity, reconstruction and AST only','parent_binding_complete':spec['binding_complete'],'parent_citation_guard':citation_guard,'source_only_citation_omission_controls':citation_controls,'review_ready_final_publication':bool(spec['binding_complete'] and args.require_freeze),'archive_objects':len(contents),'archive_aliases':len(aliases),'verified_live_originals':originals,'complete_assembly_files':113,'unchanged_mathematical_bodies':len(bodies),'AST_parsed':parsed,'proposed_programs_executed':False,'mathematical_predicates':0},indent=2))
if __name__=='__main__': main()
