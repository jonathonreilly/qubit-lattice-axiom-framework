"""Render literal source and manifests only; no proposed program execution."""
from pathlib import Path
import ast, gzip, hashlib, json, re
Q=Path(__file__).resolve().parent; P=Q/'payload'
def raw(p): return Path(p).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p): return json.loads(raw(p))
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def put(p,v): save(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
spec=js(Q/'SPECIFICATIONS.json'); K=spec['packet']; D=P/K
note=raw(P/spec['notes'][0]['path']); rows=note.decode().splitlines(True)
exclusions=[]
for number,line in enumerate(rows,1):
    for target in re.findall(r'\]\(([^)\s]+)\)',line):
        if target not in ['G','H']: continue
        expected={'G':'For interpolation, let P_L=1_[1,L](G). D_L=P_L D P_L has operator norm\n',
                  'H':'uniformly. Put P_K=1_[0,K](H). Splitting rho^(1/2) at this initial\n'}[target]
        assert line==expected and rows.count(line)==1
        exclusions.append({'note':spec['notes'][0]['path'],'note_sha256':sha(note),'canonical_line':number,'exact_line':line,'context':line,'raw_match':']('+target+')','reason':'Exact immutable analytic-evidence spectral projection notation; no source edit or broad formula exemption.'})
assert len(exclusions)==2
spec['notation_exclusions']=exclusions
put(Q/'SPECIFICATIONS.json',spec)
put(D/'MARKDOWN_NOTATION_CLASSIFICATION.json',{'note':spec['notes'][0]['path'],'note_sha256':sha(note),'exclusions':exclusions,'classification':'Two exact spectral-projection factors in immutable evidence are mathematical notation, not local Markdown links.'})
programs=['prepare_verify_graph_calibration.py','run_combined_validation.py','IDENTITY_TOOL.template.py','BUILD_SOURCE_ONLY.py','BIND_PUBLICATION_SOURCE_ONLY.py','ADAPT_PROGRAMS_SOURCE_ONLY.py','WRITE_PACKET_SOURCE_ONLY.py','CHECK_PREPARATION_SOURCES.py','FINALIZE_SOURCE_ONLY.py','RUN_SOURCE_CHECKS.py','FREEZE_PACKAGE.py']
archives=[]
for n in programs:
    b=raw(Q/n); z=gzip.compress(b,mtime=0); dest=D/'programs'/(n+'.gz'); save(dest,z)
    archives.append({'path':str(dest.relative_to(P)),'raw_sha256':sha(b),'raw_bytes':len(b),'sha256':sha(z),'bytes':len(z)})
for f in sorted((Q/'program_diffs').glob('*.diff')):
    b=raw(f);z=gzip.compress(b,mtime=0);dest=D/'program_diffs'/(f.name+'.gz');save(dest,z)
    archives.append({'path':str(dest.relative_to(P)),'raw_sha256':sha(b),'raw_bytes':len(b),'sha256':sha(z),'bytes':len(z)})
put(D/'PROGRAM_ARCHIVES.json',{'files':archives,'scope':'Exact program source and producer-exact diffs; no proposed program executed.'})
known={'EVIDENCE_MAP.json','PUBLICATION_EDITS.json','PARENT_BINDINGS.json','SOURCE_REVIEW_STATUS.json','CLAIM_REGISTRY_ADDITIONS.json','GRAPH_CALIBRATION_ASSEMBLY_ROOT_ACCEPTANCE.json','GRAPH_CALIBRATION_ASSEMBLY_ROOT_REVIEW.md'}
extra={str(f.relative_to(P)):{'sha256':sha(raw(f)),'bytes':len(raw(f))} for f in sorted(D.rglob('*')) if f.is_file() and str(f.relative_to(D)) not in known and f.parent not in [D/'objects',D/'diffs']}
parents=js(D/'PARENT_BINDINGS.json')['parents']
inputs=sorted({str(f.relative_to(P)) for f in D.rglob('*') if f.is_file()}|{r['path'] for r in parents}|{r['path'] for r in spec['notes']})
subs={'__DECLARED_INPUTS__':repr(inputs),'__EXTRA_PINS__':repr(extra),'__MAP_SHA__':sha(raw(D/'EVIDENCE_MAP.json')),'__EDITS_SHA__':sha(raw(D/'PUBLICATION_EDITS.json')),'__PARENTS_SHA__':sha(raw(D/'PARENT_BINDINGS.json')),'__STATUS_SHA__':sha(raw(D/'SOURCE_REVIEW_STATUS.json')),'__GRAPH_SHA__':sha(raw(D/'CLAIM_REGISTRY_ADDITIONS.json'))}
text=raw(Q/'IDENTITY_TOOL.template.py').decode()
for token,value in subs.items():
    assert token in text; text=text.replace(token,value)
ast.parse(text)
runner=P/spec['notes'][0]['runner'];save(runner,text)
put(Q/'IDENTITY_RENDERING.json',{'template_sha256':sha(raw(Q/'IDENTITY_TOOL.template.py')),'sha256':sha(raw(runner)),'bytes':len(raw(runner)),'substitutions':subs,'scope':'Literal source reconstruction and AST only; not executed.'})
status=js(D/'SOURCE_REVIEW_STATUS.json')
required=['unchanged_source_coverage_reused','new_publication_wrappers_read','publication_byte_maps_and_diffs_verified','complete_driver_read','identity_tools_and_archive_map_read','packet_and_dependency_delta_read','whitespace_and_link_policy_reviewed','final_assembly_review_read','root_authorizes_execution','root_execution_acceptance','block_handoff_and_review_history_read','twelve_section_conformance_reviewed','exact_source_diff_producer_conventions_reviewed','canonical_parent_maps_reviewed','uniform_graph_and_fixed_protocol_scope_reviewed','calibration_order_notation_reviewed','common_H_and_regular_ideal_law_assumptions_reviewed','abstract_control_limits_reviewed','canonical_parent_markdown_citations_reviewed']
accept={k:False for k in required}
for k in ['base','branch','prepared_source_freeze_sha256','source_assembly_root_review_sha256','source_assembly_root_acceptance_sha256','disposition','root_core_sha256','independent_core_sha256','no_go_packet_pass']:accept[k]=status[k]
accept.update(placeholder_only=True,publication_source_freeze_sha256=None,publication_program_sha256=sha(raw(Q/'prepare_verify_graph_calibration.py')),final_assembly_review_path=None,final_assembly_review_sha256=None,final_assembly_review_disposition=None,mathematical_predicates=0)
put(Q/'ROOT_ACCEPTANCE.template.json',accept)
put(Q/'COMBINED_ROOT_ACCEPTANCE.template.json',{'purpose':'combined_current_main_validation_only','placeholder_only':True,'program_sha256':sha(raw(Q/'run_combined_validation.py')),'package_source_freeze_sha256':None,'candidate_worktree':None,'candidate_head':None,'candidate_tree':None,'current_main':None,'allowed_generated_paths':[],'procedure_pins':[],'root_authorizes_execution':False,'cumulative_unit_reviewed':False,'source_footprint_reviewed':False,'generation_scope_reviewed':False,'recovery_owned_by_root':False})
files=[{'path':str(f.relative_to(P)),'sha256':sha(raw(f)),'bytes':len(raw(f))} for f in sorted(P.rglob('*')) if f.is_file()]
put(Q/'PAYLOAD_MANIFEST.json',{'files':files,'count':len(files),'parent_binding_complete':spec['binding_complete']})
put(Q/'BINARY_PAYLOAD_PINS.json',{'files':[r for r in files if r['path'].endswith('.gz')],'scope':'Exact gzip files only; no blanket text-whitespace exception.'})
expected=sorted({r['path'] for r in files}|{'logs/runner-cache/'+Path(spec['notes'][0]['runner']).stem+'.txt','docs/audit/data/citation_graph_manifest.json',K+'/PUBLICATION_ROOT_ACCEPTANCE.json',K+'/PUBLICATION_ASSEMBLY_REVIEW.txt'})
put(Q/'EXPECTED_INSTALL_AND_STAGE_PATHS.json',{'paths':expected,'only_existing_tracked_change':'docs/audit/data/citation_graph_manifest.json','parent_binding_complete':spec['binding_complete'],'not_actual_staging':True})
put(Q/'CORRUPTION_CONTROL_PLAN.json',{'execution':'Root-only after a successful canonical baseline; unexecuted by preparer.','mathematical_predicates':0,'cases':[{'label':'archive','target':'first declared objects/*.gz input','expected_error':'Compressed archive changed'},{'label':'publication','target':spec['notes'][0]['path'],'expected_error':'Published source does not reconstruct'},{'label':'metadata','target':K+'/PUBLICATION_EDITS.json','expected_error':'Publication transformation changed'},{'label':'parent','target':None if not parents else parents[0]['path'],'expected_error':'Canonical parent bytes changed'}],'mutations':'Append exactly newline + byte-integrity-tamper + newline to a temporary copied fixture only.','exact_nonzero_exit_required':1,'stderr_exact_object_required':True,'canonical_parent_case_binding_unresolved':not spec['binding_complete']})
print(json.dumps({'status':'source_rendered_only','parent_binding_complete':spec['binding_complete'],'payload_files':len(files),'declared_identity_inputs':len(inputs),'expected_stage_paths':len(expected),'proposed_programs_executed':False,'mathematical_predicates':0},indent=2))
