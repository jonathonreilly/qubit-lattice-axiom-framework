"""Seal fully bound reviewed source bytes only; never execute publication runtime."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
Q=Path(__file__).resolve().parent
def raw(p): return Path(p).read_bytes()
def js(p): return json.loads(raw(p))
def need(ok,message):
    if not ok: raise ValueError(message)
need(not (Q/'SOURCE_FREEZE.json').exists(),'A final freeze already exists; preserve it')
spec=js(Q/'SPECIFICATIONS.json')
need(spec['binding_complete'] is True,'Actual parent unresolved; no final publication freeze permitted')
need(datetime.now(timezone.utc)<datetime(2026,10,14,21,37,33,tzinfo=timezone.utc),'Campaign hard stop reached')
coverage=js(Q/'AUTHOR_READ_COVERAGE.json')
need(coverage['final_changed_source_read_complete'] is True and coverage['canonical_parent_body_roles_verified'] is True,'Final changed reads and parent coverage incomplete')
status=js(Q/'SOURCE_PREPARATION_DISPOSITION.json')
need(status['parent_binding_complete'] is True and status['source_checks_complete'] is True,'Final source checks incomplete')
need(not any(p.is_symlink() for p in Q.rglob('*')),'Source package contains a symlink')
rows=[{'path':str(p.relative_to(Q)),'sha256':hashlib.sha256(raw(p)).hexdigest(),'bytes':len(raw(p))} for p in sorted(Q.rglob('*')) if p.is_file()]
value={'utc':datetime.now(timezone.utc).isoformat(),'parent_binding_complete':True,'file_count':len(rows),'files':rows,'scope':'Source identity only. Proposed publication programs unexecuted; zero mathematical predicates.','canonical_programs_executed_by_preparer':False,'mathematical_predicates':0}
(Q/'SOURCE_FREEZE.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
print(json.dumps({'freeze_sha256':hashlib.sha256(raw(Q/'SOURCE_FREEZE.json')).hexdigest(),'file_count':len(rows),'mathematical_predicates':0}))
