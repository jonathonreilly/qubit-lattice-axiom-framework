"""Capture only the read-only source checker; no proposed runtime is invoked."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, time, uuid
Q=Path(__file__).resolve().parent
folder=Q/'evidence'/('source_check_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:8])
folder.mkdir(parents=True,exist_ok=False)
rows=[]
bound_flags=['--require-bound'] if json.loads((Q/'SPECIFICATIONS.json').read_text())['binding_complete'] else []
for label,flags in [('archive_only',[]),('originals',['--verify-originals'])]:
    d=folder/label;d.mkdir()
    argv=[sys.executable,'-B',str(Q/'CHECK_PREPARATION_SOURCES.py'),*bound_flags,*flags]
    started=datetime.now(timezone.utc).isoformat(); start=time.monotonic()
    result=subprocess.run(argv,cwd=Q,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    (d/'stdout').write_bytes(result.stdout);(d/'stderr').write_bytes(result.stderr)
    record={'argv':argv,'cwd':str(Q),'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'exit_code':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),'proposed_programs_executed':False,'mathematical_predicates':0}
    (d/'execution.json').write_text(json.dumps(record,indent=2)+'\n');rows.append(record)
    if result.returncode:
        print(json.dumps({'status':'source_check_failed','evidence':str(d),'exit_code':result.returncode}));raise SystemExit(result.returncode)
(folder/'RESULT.json').write_text(json.dumps({'checks':rows,'proposed_programs_executed':False,'mathematical_predicates':0},indent=2)+'\n')
print(json.dumps({'status':'source_checks_completed','evidence':str(folder),'checks':len(rows),'proposed_programs_executed':False,'mathematical_predicates':0}))
