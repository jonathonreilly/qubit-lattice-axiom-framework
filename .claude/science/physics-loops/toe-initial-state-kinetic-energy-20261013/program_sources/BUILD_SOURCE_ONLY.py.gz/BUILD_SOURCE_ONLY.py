#!/usr/bin/env python3
"""Create source files only inside this package; no scientific or repo execution."""
from pathlib import Path
import datetime, difflib, gzip, hashlib, json, re, shutil

Q = Path(__file__).resolve().parent
R = Q.parent
A = R / 'finite_initial_energy_kinetic_source_assembly'
CW = R.parent / 'correlation_worktree'
BASE = 'c5eaa6bf752a0893c83c0509c7c349dab53bff14'
BRANCH = 'physics-loop/toe-initial-state-kinetic-energy-20261013'
PACKET = '.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013'
P = Q / 'payload' / PACKET
NOTE = 'docs/FINITE_INITIAL_ENERGY_KINETIC_BOUNDED_THEOREM_NOTE_2026-10-13.md'
CLAIM = 'finite_initial_energy_kinetic_bounded_theorem_note_2026-10-13'
RUNNER = 'scripts/initial_state_kinetic_identity_2026_10_13.py'
SOURCE_FREEZE = '8ce9cbb235c6696f760e867192942bb2d0e85867bb333bb75671d890fa59a819'
def raw(p): return Path(p).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def js(p): return json.loads(raw(p))
def put(p, b):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b if isinstance(b, bytes) else b.encode())
def record(p, d): put(p, json.dumps(d, indent=2, sort_keys=True) + '\n')
def diff(a, b, x, y):
    return b''.join(difflib.diff_bytes(difflib.unified_diff, a.splitlines(True), b.splitlines(True), fromfile=x.encode(), tofile=y.encode(), n=3))
def pin(p):
    b = raw(p); return {'sha256': sha(b), 'bytes': len(b), 'lines': len(b.splitlines())}

assert sha(raw(A/'FINAL_FREEZE.json')) == SOURCE_FREEZE
assert sha(raw(R/'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md')) == '002d3585f3ca5b17ab0eaad81e03f10d97337cace053a4a2393eb6ffe539117c'
assert sha(raw(R/'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json')) == '963bb68b3456a0b746f6c227156417c41c837ff7723523b84a1e2ff1e2b0d80d'
objects = {}; aliases = {}; closures = []
def archive(path, role):
    path = Path(path).resolve(); b = raw(path); h = sha(b)
    if str(path) in aliases:
        assert aliases[str(path)] == h
        return h
    aliases[str(path)] = h
    if h not in objects:
        z = gzip.compress(b, mtime=0); rel = 'objects/'+h+'.gz'; put(P/rel, z)
        objects[h] = {'sha256': h, 'bytes': len(b), 'lines': len(b.splitlines()), 'path': rel, 'stored_sha256': sha(z), 'stored_bytes': len(z), 'origins': []}
    objects[h]['origins'].append({'path': str(path), 'role': role})
    return h
for folder in [A, R/'finite_initial_energy_kinetic_independent', R/'finite_initial_energy_kinetic_comparison']:
    seal = folder/'FINAL_FREEZE.json'; f = js(seal); members = []
    for row in f['files']:
        p = Path(row['path']); p = p if p.is_absolute() else folder/p
        current = pin(p)
        assert all(current[k] == row[k] for k in ['sha256','bytes','lines'] if k in row)
        archive(p, 'exact frozen source/evidence member')
        members.append({'path': str(p.resolve()), **current})
    archive(seal, 'exact frozen source/evidence receipt')
    closures.append({'receipt': str(seal.resolve()), 'receipt_sha256': sha(raw(seal)), 'members': members, 'kind': 'files', 'scope': 'all directly bound members; nested historical references remain opaque'})
for n in ['FINITE_INITIAL_ENERGY_BRANCH_START.json', 'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md', 'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json', 'FINITE_INITIAL_ENERGY_KINETIC_ROOT_PROBE.md', 'FINITE_INITIAL_ENERGY_KINETIC_ROOT_REVIEW.md', 'FINITE_INITIAL_ENERGY_KINETIC_ROOT_REVIEW_PRECISION.md', 'FINITE_INITIAL_ENERGY_KINETIC_ROOT_ACCEPTANCE.json', 'FINITE_INITIAL_ENERGY_KINETIC_ROOT_IDENTITY.json']:
    archive(R/n, 'authoritative original or root publication/source record')
    if n in ['FINITE_INITIAL_ENERGY_BRANCH_START.json','FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md','FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json']:
        put(P/n, raw(R/n))
for row in js(Q/'evidence/N8_SELECTED_SOURCES.json')['files']:
    archive(CW/row['path'], 'bounded historical N8 ledger source; not a mathematical premise')

parent_specs = [
 ('MODULATED_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE_2026-10-13.md','modulated_kinetic_energy_bounded_theorem_note_2026-10-13','modulated_kinetic_identity_2026_10_13.py',[('MODULATED_KINETIC_LAW_ROOT_PROBE.md','Vacuum law, mean, weighted full-input remainder and kinetic/BV resource estimates')]),
 ('GENERAL_COMPACT_CONTROL_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE_2026-10-13.md','general_compact_control_kinetic_energy_bounded_theorem_note_2026-10-13','general_kinetic_identity_2026_10_13.py',[('GENERAL_KINETIC_LAW_ROOT_PROBE.md','General-control signed-input Born bounds, pair density and positive-production examples'),('KINETIC_MEAN_RELAXED_CONTROLS_DERIVATION.md','Transitive mean/Volterra support sharing the same canonical owner')]),
 ('TWO_ZERO_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE_2026-10-13.md','two_zero_kinetic_energy_bounded_theorem_note_2026-10-13','two_zero_kinetic_identity_2026_10_13.py',[('WEAK_DRIVE_KINETIC_RESPONSE_INDEPENDENT_V2.md','Corrected pictures/CAR/graph normalization and energy-domain/work machinery')]),
 ('KINETIC_CORRELATION_LIMITS_BOUNDED_THEOREM_NOTE_2026-10-13.md','kinetic_correlation_limits_bounded_theorem_note_2026-10-13','correlation_kinetic_identity_2026_10_13.py',[('KINETIC_CORRELATION_ROOT_PROBE.md','Fixed CAR, finite-mode and compact-Fock topology proof machinery')])]
parents=[]; maps=[]
for name, claim, runner, cores in parent_specs:
    path='docs/'+name; b=raw(CW/path); archive(CW/path,'canonical direct parent at PR9517 head')
    parents.append({'path':path,'claim_id':claim,'runner':'scripts/'+runner,'archive_alias':str((CW/path).resolve()),'published_sha256':sha(b),'bytes':len(b),'lines':len(b.splitlines()),'status':'conditional-support; no retained status inferred'})
    for core_name, scope in cores:
        cp=A/'support/sources'/core_name; c=raw(cp); assert b.count(c)==1; a=b.index(c); z=a+len(c)
        maps.append({'canonical_path':path,'canonical_claim_id':claim,'canonical_sha256':sha(b),'archive_alias':str(cp.resolve()),'core_sha256':sha(c),'byte_start_inclusive':a,'byte_end_exclusive':z,'line_start_inclusive':b[:a].count(b'\n')+1,'line_end_inclusive':b[:z].count(b'\n'),'bytes':len(c),'lines':len(c.splitlines()),'scope':scope})
deps=[p['claim_id'] for p in parents]
bindings={'base':BASE,'regular_parent_pr':9517,'parents':parents,'canonical_core_maps':maps,'same_packet_parents':[],'archived_provisional_relations':[],'history_only_relations':[],'standalone_hypotheses':{'edges_created':[],'items':['Supplied massive free CAR representation and fixed smooth real spatial slots','Exact common free energy and actual-cell embedding','M23 control/commutator calibration and epsilon_a=o(h^2)','Weighted trace convergence of embedded initial preparations to one fixed finite-energy state']},'boundary':'Four directly used parent nodes and five exact core maps. Mean301 shares the general-control owner. Historical ledgers, review evidence and Git ancestry create no scientific edge. No chirp dependency.'}
record(P/'PARENT_BINDINGS.json',bindings)
record(P/'CLAIM_REGISTRY_ADDITIONS.json',{'nodes':[{'claim_id':CLAIM,'path':NOTE,'runner':RUNNER,'deps':deps,'claim_type':'bounded_theorem','actual_current_surface_status':'conditional-support'}],'direct_edges':[{'from':CLAIM,'to':x} for x in deps],'archived_proof_import_relations':[],'history_only_relations':[],'expected_delta':{'nodes':1,'edges':4}})

old = raw(A/'payload/FINITE_INITIAL_ENERGY_KINETIC_NOTE.md'); oldlines=old.splitlines(True)
prefix = '''---
title: "Single-time kinetic energy laws for fixed normal initial states"
claim_id: finite_initial_energy_kinetic_bounded_theorem_note_2026-10-13
status: conditional-support
claim_type: bounded_theorem
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
artifact_role: theorem
runner: scripts/initial_state_kinetic_identity_2026_10_13.py
upstream_dependencies:
'''+''.join('  - '+x+'\n' for x in deps)+'''assembly_status: publication_prepared_root_review_and_runtime_pending
scientific_execution: none_in_publication_preparation
trace_class: upstream_support
target_claim_id: null
target_blocker_text: null
source_of_blocker_text: frontier_question
reachability_to_target: supports
conditional_surface_status: "Supplied massive free CAR model, fixed normal input, fixed smooth real controls and carrier above threshold, bounded kinetic and BV resources; finite input energy separately for mean/W1; explicit actual-cell premises."
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: "Unchanged conditional analytic cores, separately derived and source-exposed checked; source identity is not a mathematical certificate."
next_trace_action: "Root reviews and executes exact source integration; cumulative current-main validation and independent retained audit remain separate. Downstream consumer not yet selected."
audit_required_before_effective_retained: true
bare_retained_allowed: false
dependency_resolution: exact_published_parent_core_maps
---

# Single-time kinetic energy laws for fixed normal initial states

Claim type: bounded_theorem

Claim status: conditional-support. This note preserves two accepted analytic cores with their exact hypotheses. It adds publication metadata, an explicit notation dictionary and exact source/dependency maps. It supplies no retained-audit, formal Lean, model-diverse or empirical verdict.

## Target and quantifiers

For each fixed normal initial density matrix in the supplied massive free CAR/Fock model, the single-time free-energy law approaches its initial law convolved with the vacuum kinetic Poisson comparison; finite initial free energy separately yields additive mean convergence and W1 convergence.

Fix m,v>0, real compact smooth spatial slots, carrier omega>2m, and finite bounds on kinetic horizon, envelope supremum and total variation. The real BV envelope and terminal time may vary with h=|lambda|. With J_h=lambda^2 integral_0^T A(t)^2dt, the comparison law is the initial energy law convolved with omega times Poisson(nu_omega J_h). Weak convergence to a single limiting law is asserted along convergent J_h; the characteristic-function comparison and finite-energy W1 comparison retain the current J_h. Drive uniformity is for each fixed rho, which is independent of coupling, terminal time and envelope. No W1 rate or multi-time process follows.

The weak-law theorem needs normality but no energy moment. The mean/W1 theorem needs finite initial free energy, treats arbitrary nonquasifree states and keeps anomalous covariance. The separate zero-anomalous subclass has the stated uniform mean control. The explicit inverse-vacuum and two-particle families vary with the drive and delimit uniform extensions over energy-bounded input classes at positive production; they do not contradict any fixed-state theorem.

Zero envelope, zero pair-production rate and bounded kinetic windows including T=0 remain included. The positive-production hypothesis belongs to the uniformity counterexamples. The proof does not establish threshold, massless, high-variation, changing spatial-slot, physical state-selection or trajectory limits.

## Proof obligations, imports and notation

The obligation graph is explicit: modulated464 supplies the vacuum law/mean and weighted full-input remainder; general470 supplies signed Born/pair-density machinery; corrected859 supplies the CAR pictures, skew graph and energy-domain conventions; correlation335 supplies the older fixed-test topology machinery. The new cores prove the weighted full operator estimate, arbitrary-state covariance/energy identity, echo argument, compact-test extensions and conditional initial-state transfer. These are ordinary conditional analytic results, not cited retained authorities. All four directly used canonical parents and five exact core maps are in the [parent bindings](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/PARENT_BINDINGS.json). Mean301 is transitive support under the general-control owner. No chirp theorem is imported.

Part A is root407 lines9-383; Part B is independent224 lines20-216. Full originals and omitted historical status sections remain recoverable from the [source archive](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/SOURCE_RECOVERY.md). Full-source digests are different from extracted-core digests. The [publication map](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/PUBLICATION_EDITS.json) identifies both.

Part B's U is Part A's Y, and its H is H0. Its field F is b in Part A. The generalized densities obey Q=I-C, n_B=N_A and kappa_B=-kappa_A; this accounts for the opposite anomalous-term signs. The bare C in Part B's pair graph is the scalar-band conjugation from corrected859, distinct from C_rho. J_real=Gamma C is distinct from J_h.

Part A's exact trace-distance identity applies only to pure initial states. Part B adds an asymptotic result for each fixed normal mixed state, not an exact finite-coupling mixed-state identity or a state-uniform limit. Its full-picture compact statement uses the additional uniform freely rotated creator-word lemma, not an illicit moving compact test in Part A. Finite-mode statements are for finite-rank detectors with their stated rank dependence; a continuum spatial region or energy band is not automatically finite rank. A vacuum-based necessary detector-rank bound is retained only for initially empty modes.

## Explicit actual-cell hypotheses

The actual-cell application assumes an exact common free energy and embedding, all required M23 calibration bounds, and weighted trace convergence ||(H+I)^(1/2)(rho_a-rho)(H+I)^(1/2)||_1 -> 0 to one fixed finite-energy rho. M23 supplies bounds ||V_a-V||<=d0 epsilon_a, ||[H,V_a-V]||<=d1 epsilon_a and the stated uniform individual commutator bound; the parent also states its one-particle-generator comparison. With fixed resources, epsilon_a=o(h^2) is sufficient for the mean/law/W1 transfer. The weaker unweighted scale alone supplies no mean conclusion. An energy cap or convergence of initial energy distributions does not supply weighted trace convergence.

No missing theorem lemma is asserted within the supplied model and stated hypotheses. The strongest open physical-application obligation is to establish the actual common-energy/calibration and weighted preparation hypotheses for the desired realization; this package proves no preparation rate or model selection. They remain assumptions rather than new scientific parent claims.

## Review record and negative scope

The root derivation froze before its author opened the independent findings. The later focused comparison resolves the covariance dictionary, weighted domains, exact pure versus asymptotic mixed distance, and two-particle (one-pair) counterexample. It is source-exposed and same-family; the comparison author also wrote Part B. Root's separate proof and complete later checking are distinguished from that self-check. The unchanged original review's phrase "two-pair sector" is a transcription error corrected by its preserved precision note; no formula or acceptance scope changed.

The [N1-N8 checklist](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/NO_GO_DISCIPLINE_CHECKLIST.md) and [ledger](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/NO_GO_LEDGER.md) preserve exact uniformity witnesses and the procedural FAIL/partial-narrowing classification. Only the real families are counted; N1's five-family minimum is unmet. The bounded historical N8 search is recorded with its actual coverage. The proposed identity runner emits honest N5 nonexecution statements, not a mathematical certificate. No packet PASS, exhaustive impossibility or independent-wall count is claimed. Narrowed positive publication is allowed with these missed routes and limitations queued.

The actual regular parent is PR9517 at c5eaa6bf752a0893c83c0509c7c349dab53bff14. The former provisional wrapper remains archived. No prior source is rewritten. All new source integration, staging and publication remain root-owned; later combined validation and independent retained audit remain separate.

## Part A — unchanged root mathematical core

This complete selected core preserves I23's pure-state scope and section8's conditional application.

<!-- BEGIN EXACT CORE root407:9-383 -->
'''
middle = b''.join(oldlines[409:416]).decode()
suffix = '''<!-- END EXACT CORE independent224:20-216 -->

## Source verification and direct imports

The [review history](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/REVIEW_HISTORY.md), [handoff](../.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013/HANDOFF.md) and source map distinguish prior complete analytic reading from current identity checks. The two selected mathematical slices are unchanged. Full original sources, precision, direct frozen evidence and acceptance remain archived. Nested historical receipts are preserved as provenance, not recursively audited.

The primary identity runner checks archive bytes, exact core reconstruction and canonical parent maps only. It executes zero mathematical predicates, no numerical science and no Lean build. No canonical runner/cache/graph/pipeline ran during publication preparation. Its cached output, if later created by root through the canonical envelope, is source-integrity evidence only.

Direct scientific imports:

'''+''.join('- ['+p['claim_id']+']('+Path(p['path']).name+')\n' for p in parents)
pieces=[]; joined=b''
for kind, content, extra in [
 ('publication_wrapper',prefix.encode(),{'wrapper_path':'wrappers/initial_state.0.md','old_line_range':[1,34]}),
 ('accepted_core_slice',b''.join(oldlines[34:409]),{'source_path':str((A/'support/sources/FINITE_INITIAL_ENERGY_KINETIC_ROOT_PROBE.md').resolve()),'source_line_start':9,'source_line_end':383,'expected_slice_sha256':'17e33786ddb4fe51ea94292bcba21ab0c7dc35959ec43dfd4b979709d144cee6'}),
 ('publication_wrapper',middle.encode(),{'wrapper_path':'wrappers/initial_state.2.md','old_line_range':[410,416]}),
 ('accepted_core_slice',b''.join(oldlines[416:613]),{'source_path':str((A/'support/sources/FINITE_INITIAL_ENERGY_KINETIC_INDEPENDENT.md').resolve()),'source_line_start':20,'source_line_end':216,'expected_slice_sha256':'5434448a79ec72c182e938139abf4360146e17120b6d4b08b370fd52ef33d2dc'}),
 ('publication_wrapper',suffix.encode(),{'wrapper_path':'wrappers/initial_state.4.md','old_line_range':[614,620]})]:
    entry={'kind':kind,'sha256':sha(content),'bytes':len(content),'byte_offset':len(joined),'first_line':joined.count(b'\n')+1,'last_line':(joined+content).count(b'\n'),**extra}
    if kind=='publication_wrapper': entry['text']=content.decode();put(Q/extra['wrapper_path'],content)
    else:
        assert sha(content)==extra['expected_slice_sha256'];entry['source_sha256']=sha(raw(extra['source_path']));entry['additional_mathematical_body_edits']=[]
    pieces.append(entry);joined+=content
put(Q/'payload'/NOTE,joined)
diffrows=[]
def store_diff(key,before,after,fromfile,tofile):
    b=diff(before,after,fromfile,tofile); rel='diffs/'+key+'.diff.gz'; z=gzip.compress(b,mtime=0)
    put(P/rel,z);put(Q/'readable_diffs'/(key+'.diff'),b)
    row={'diff':rel,'diff_sha256':sha(b),'diff_stored_sha256':sha(z),'diff_bytes':len(b),'stored_bytes':len(z),'fromfile':fromfile,'tofile':tofile,'context_lines':3,'handling':'raw unified diff archived losslessly; space-only context markers are literal syntax'};diffrows.append(row);return row
whole=store_diff('initial_state.publication',old,joined,'accepted/payload/FINITE_INITIAL_ENERGY_KINETIC_NOTE.md',NOTE)
wrappers=[]
for piece in pieces:
    if piece['kind']!='publication_wrapper':continue
    a,z=piece['old_line_range']; before=b''.join(oldlines[a-1:z]); after=piece['text'].encode()
    wrappers.append({'source_line_range':[a,z],'publication':piece['wrapper_path'],'source_sha256':sha(before),'publication_sha256':sha(after),**store_diff(Path(piece['wrapper_path']).stem,before,after,'accepted/wrapper_lines_'+str(a)+'_'+str(z),piece['wrapper_path'])})
record(P/'PUBLICATION_EDITS.json',{'source_freeze_sha256':SOURCE_FREEZE,'additional_mathematical_body_edits':[],'notes':[{'key':'initial_state','note':NOTE,'accepted_candidate_path':str((A/'payload/FINITE_INITIAL_ENERGY_KINETIC_NOTE.md').resolve()),'accepted_candidate_sha256':sha(old),'published_sha256':sha(joined),'published_bytes':len(joined),'published_lines':len(joined.splitlines()),'pieces':pieces,**whole}],'wrapper_changes':wrappers,'diff_convention':'difflib.diff_bytes(unified_diff), n=3, original LF bytes, fixed labels, no timestamps; gzip mtime=0','raw_diff_policy':'Only gzip forms enter payload. Readable raw diffs remain source-preparation evidence. No context-marker normalization and no broad whitespace skipping.'})

side=(A/'payload/NO_GO_DISCIPLINE_CHECKLIST.md').read_text()
side=side.replace('(FINITE_INITIAL_ENERGY_KINETIC_NOTE.md)','(../../../../docs/'+Path(NOTE).name+')')
side=re.sub(r'\]\(\.\./[^)]+\)','](SOURCE_RECOVERY.md)',side)
first_end=side.index('\n\n',side.index('This sidecar accompanies'))
side=side[:side.index('This sidecar accompanies')]+'''This sidecar accompanies the [primary source note](../../../../docs/FINITE_INITIAL_ENERGY_KINETIC_BOUNDED_THEOREM_NOTE_2026-10-13.md). It applies the exact installed no-go-discipline skill, its case studies and proof-search route-family normalization. The accepted assembly's GOVERNANCE_IDENTITIES.json and exact governing sources are recoverable through the [source archive](SOURCE_RECOVERY.md); those historical identities and read coverage are preserved unchanged.'''+side[first_end:]
side=side.replace('The five-family rule, the absent primary-runner cached N5 certificate and the unperformed repository-wide N8 search prevent a packet PASS. This source-only assembly does not waive those requirements, invent families, or ship a negative-claim PR.','N1 remains below the five-family minimum. N5 reports identity-only nonexecution; root cache execution is pending. N8 now has the bounded repository search recorded below, without a global-completion claim. This publication copy preserves FAIL/partial-narrowing and ships the useful positive theorem with explicit limits, as permitted by the skill stop conditions; it does not waive requirements or invent families.')
start=side.index('| Assembled note line |');end=side.index('\nOther load-bearing conditions',start)
side=side[:start]+'''The historical line-hit table is archived unchanged with the accepted assembly. The publication copy has a fresh complete hit inventory and classification in [N3_SCAN.json](N3_SCAN.json). Hits referring to canonical source identity/publication are provenance only. Negated quasifree/moment assumptions do not add premises; finite input energy is explicitly imposed for mean/W1. Actual-cell assumptions are stated in the new wrapper and both cores. No wall-independence claim is inferred from this scan.
'''+side[end:]
side=side.replace('There is no mathematical primary runner or authorized cache/pipeline execution in this source-only task. The read-only helper may report these applicability statements as metadata, but its output is not presented as the required cached scientific execution artifact. That procedural item remains incomplete.','The proposed primary runner checks byte identity only and prints all five substantive nonexecution lines. Root may later produce its cache through the canonical envelope. No cache was executed during preparation, and even a fresh identity cache supplies no scientific execution or mathematical certificate. N5 is described as nonexecution, not a mathematical PASS.')
start=side.index('## N8 — Cross-cycle echo');end=side.index('## Gate outcome and handoff',start)
side=side[:start]+'''## N8 — Cross-cycle echo

Publication preparation performed a bounded read-only filesystem search of the pinned worktree's docs and .claude/science trees. Filename discovery found 714 matching paths; only four directly relevant prior ledger/checklist bodies were selected and read completely. [N8_HISTORICAL_SCAN.md](N8_HISTORICAL_SCAN.md) records exact paths, hashes, reported retirement mechanisms, applicability and limits. No Git command, ref walk, audit-ledger query or current remote-status check ran. The wider filename inventory is not body-read coverage.

The energy-correlation packet reports that spectral ceilings, two-sided form control, norm leakage and fixed ordinary-cell convergence provide useful positive routes under stronger observation/state conditions. Its N1/N5 remain pending. These are reported sufficient mechanisms, not an independently rechecked theorem import. The applicable lesson is to retain the weighted preparation/compact-family strengthening route in N7; energy-bounded varying-state witnesses do not defeat it. The kinetic and modulated packets retain their scoped topology boundaries and picture repair, without an exhaustive no-go. None of these four records reports retirement of the present exact inverse-vacuum or two-particle witnesses. No global absence of a retirement mechanism is asserted.

The already-read skill case studies add the process warnings against resolution mixing, dependent-wall counting and residual mismatch. N8's newly completed bounded scan does not remove N1's deficiency or turn the packet into PASS. Broader historical/ref coverage and genuinely distinct scientific routes remain queued if a broader negative claim is later pursued.

'''+side[end:]
start=side.index('## Gate outcome and handoff')
side=side[:start]+'''## Gate outcome and handoff

N1 fails the present five-family procedural minimum. N5 is explicit identity-only nonexecution, with cache execution pending root. N8 has the bounded four-record search above; it claims no exhaustive repository or ref-history coverage. The negative packet remains FAIL / procedurally incomplete and partial-narrowing. The skill stop conditions permit publishing the positive conditional theorem and exact witness limits with missed routes queued. No validator, threshold, prompt, axiom or audit status changes. Actual canonical parents are now bound; root owns source integration and later publication/landing gates.
'''
put(P/'NO_GO_DISCIPLINE_CHECKLIST.md',side)
store_diff('no_go_checklist',raw(A/'payload/NO_GO_DISCIPLINE_CHECKLIST.md'),side.encode(),'accepted/NO_GO_DISCIPLINE_CHECKLIST.md',PACKET+'/NO_GO_DISCIPLINE_CHECKLIST.md')
put(P/'NO_GO_LEDGER.md','''# Initial-state negative-boundary ledger

The [checklist](NO_GO_DISCIPLINE_CHECKLIST.md) preserves the exact source witnesses and separates them from procedural readiness.

| Result or limitation | Current scope | Remaining obligation |
|---|---|---|
| Fixed-state positive theorem | Weak law for every fixed normal state; finite initial energy separately for mean/W1 | Root source integration and later independent audit; no new mathematical gap is invented |
| Fixed odd-state witness | Unshifted vacuum-law universality fails | Keep parity/gap and target distinction |
| Inverse-vacuum witness | Varying bounded-energy inputs violate the uniform convolution, mean and W1 extension at positive production | Reopen for restricted preparation classes or an actual calculation defect, not broad impossibility |
| Two-particle variant | Uniform weak/W1 fails even with zero anomalous covariance and convergent initial energy laws | Preserve uniform mean in that subclass; one pair, not two pairs |
| N1 | Five-family procedural quota unmet; real families not inflated | Queue genuinely distinct routes only if scientifically justified; no packet PASS |
| N5 | Identity runner has zero mathematical predicates; cache execution pending root | Report five honest nonexecution lines, never a mathematical certificate |
| N8 | Four relevant historical bodies read after 714-path filename discovery | No all-ref/global scan claimed; broader search queued for any broader negative claim |
| Actual-cell implication | Common energy, calibration, weighted state approximation | Establish or retain these exact premises for the intended physical realization |

Packet classification remains FAIL/procedurally incomplete, partial-narrowing. Narrowed positive publication with missed routes queued is permitted by the skill stop conditions. This ledger asserts no independent-wall count, exhaustive no-go, retained verdict or physical-model selection.
''')
store_diff('no_go_ledger',raw(A/'payload/NO_GO_LEDGER.md'),raw(P/'NO_GO_LEDGER.md'),'accepted/NO_GO_LEDGER.md',PACKET+'/NO_GO_LEDGER.md')
selected=js(Q/'evidence/N8_SELECTED_SOURCES.json')
record(P/'N8_SELECTED_SOURCES.json',selected)
put(P/'N8_HISTORICAL_SCAN.md','''# Bounded historical uniformity and topology search

Read-only filesystem discovery at the PR9517 base searched docs and .claude/science for NO_GO, LEDGER, COUNTEREXAMPLE, TOPOLOGY, CORRELATION and KINETIC filenames. The complete 714-path inventory is archived. Four directly adjacent historical bodies were read in full; no Git command, ref walk, remote update or audit-ledger query occurred. This is bounded N8 coverage, not 714 proof-body reads or an exhaustive search.

| Historical surface | What the record reports | Retirement and applicability here |
|---|---|---|
| toe-energy-correlations-20261012/NO_GO_LEDGER.md | Conditional positive results and exact witnesses; N1/N5 pending | No negative-packet retirement reported |
| toe-energy-correlations-20261012/NO_GO_DISCIPLINE_CHECKLIST.md | Spectral ceilings, form control, norm leakage and fixed ordinary-cell/CAR subsequence routes | Useful sufficient routes retire some overbroad interpretations of energy/observation limits, under added hypotheses. These record-level reports are not newly re-proved or imported as premises. Weighted preparation/compact-family control remains a live narrowing route here. |
| toe-kinetic-energy-20261013/NO_GO_DISCIPLINE_CHECKLIST.md | Distinct control/topology scopes and historical picture defect/repair | A correct picture convention retires that specific erroneous identity; it does not retire initial-state uniformity witnesses |
| toe-modulated-kinetic-energy-20261013/NO_GO_DISCIPLINE_CHECKLIST.md | BV resource scope; other scales and controls not excluded | Positive amplitude modulation extends a prior scope, not an exhaustive no-go or an initial-state counterexample repair |

Exact full paths, hashes and line extents are in [selected sources](N8_SELECTED_SOURCES.json); raw bytes and filename discovery are recoverable through [the archive map](EVIDENCE_MAP.json). None of the four selected records reports retirement of the present inverse-vacuum/two-particle constructions. That sentence is limited to those records, not a global historical claim. The N7 weighted-compact preparation route remains explicitly queued. N1 still fails and no negative packet PASS follows.
''')
for p in [Q/'evidence/N8_FILENAME_INVENTORY.txt',Q/'evidence/N8_FILENAME_INVENTORY.stderr',Q/'evidence/N8_DISCOVERY.json',Q/'evidence/N8_SELECTED_SOURCES.json',Q/'evidence/N8_CONTENT_HITS.txt',Q/'evidence/N8_CONTENT_HITS.stderr',Q/'evidence/N8_CONTENT_SEARCH.json']:
    archive(p,'bounded N8 discovery evidence')
hits=[]
pattern=re.compile(r'we assume|by construction|as is standard|the framework provides|bridge context|background|naturally|obviously|standard QFT|registered|canonical|assum',re.I)
for i,line in enumerate(joined.decode().splitlines(),1):
    if pattern.search(line):
        if 'Assume E_rho' in line or 'assumes an exact common' in line or 'remain assumptions' in line:
            classification='explicit conditional hypothesis, repeated in target/application scope; no independence assertion'
        elif any(x in line for x in ['without assuming','No initial moment','quasifree or gauge-invariant assumption']):
            classification='proof qualification or negated shortcut; no hidden imported assumption'
        else: classification='source/provenance context or explicit premise statement; no retained authority inferred'
        hits.append({'line':i,'exact_line':line,'classification':classification})
record(P/'N3_SCAN.json',{'note':NOTE,'note_sha256':sha(joined),'pattern':pattern.pattern,'hits':hits,'mathematical_predicates_executed':0,'scope':'complete text location scan; classifications manually inspected before freeze'})

status={'base':BASE,'branch':BRANCH,'prepared_source_freeze_sha256':SOURCE_FREEZE,'source_assembly_root_review_sha256':'002d3585f3ca5b17ab0eaad81e03f10d97337cace053a4a2393eb6ffe539117c','source_assembly_root_acceptance_sha256':'963bb68b3456a0b746f6c227156417c41c837ff7723523b84a1e2ff1e2b0d80d','source_review_coverage_verbatim':js(R/'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json'),'disposition':'conditional_fixed_initial_state_theorem_with_exact_uniformity_witnesses_and_partial_narrowing_FAIL','N1':'FAIL: fewer than five real route families; no fabricated routes','N5':'identity-only nonexecution; root canonical cache pending; no mathematical certificate','N8':'bounded four-record historical scan; no exhaustive/ref-history claim','no_go_packet_pass':False,'new_independent_mathematical_review':False,'fresh_full_final_core_manual_read':False,'unchanged_complete_core_coverage_reused':True,'mathematical_core_edits':0,'pure_root_vs_mixed_independent_scope_preserved':True,'two_particle_precision_preserved':True,'chirp_dependency':False}
record(P/'SOURCE_REVIEW_STATUS.json',status)
record(P/'SOURCE_WHITESPACE_CLASSIFICATION.json',{'preserved_source_whitespace':[],'raw_diff_policy':'All payload diffs are gzip archived with declared compressed and raw hashes. Literal space-only context markers are retained, never normalized or broadly skipped. Text payload has no trailing whitespace allowance.'})
record(P/'MARKDOWN_NOTATION_CLASSIFICATION.json',{'exclusions':[],'policy':'No broad formula exclusion; any observed notation false-positive needs an exact pinned classification before execution.'})
record(P/'RAW_DIFF_INTEGRITY.json',{'diffs':diffrows,'handling':'All raw diff bytes losslessly gzip archived; decoded content is diff syntax, not authored Markdown whitespace. Exact digest/reconstruction checks apply. No raw .diff enters staged payload.','prior_failure':'Parent modulated first verify retained exit2 at required_normalization_correction.diff lines6/14. Root supplemental verifier bf2fbc652dda04cc79b39c3c58d81e3a140d76d69e96657572c279d0bd6f5910 classified exact context markers. This package does not rewrite that history.'})

put(P/'ASSUMPTIONS_AND_IMPORTS.md','''# Assumptions and scientific ownership

The target is fixed-state, single-time free-energy convolution; finite initial energy is separately required for mean/W1. Arbitrary nonquasifree covariance and anomalous terms are retained. See the [canonical note](../../../../docs/FINITE_INITIAL_ENERGY_KINETIC_BOUNDED_THEOREM_NOTE_2026-10-13.md).

| Input | Role and provenance | Open bridge |
|---|---|---|
| Supplied massive free CAR/Fock representation, real structure, common H | Mathematical model in the exact accepted parent cores | Physical realization/selection is not established |
| Fixed smooth real controls, carrier above threshold, bounded kinetic/BV resources | Explicit theorem data | No varying-frequency or unbounded-resource claim |
| Modulated/general/corrected/correlation parent cores | Exact canonical maps in PARENT_BINDINGS.json; four direct parents | Ordinary conditional support, not retained authority |
| Fixed normal initial rho | Weak-law and topology quantifier | No state-uniform promotion over energy-bounded families |
| Finite initial energy | Separate arbitrary-state mean/W1 proof | Not needed for weak characteristic-law result |
| M23/common-energy calibration plus weighted trace preparation | Explicit actual-cell implication in root section8 | No new calibration, embedding or preparation rate proof |

Mean301 shares the general-control owner. Review/precision/N8 ledgers are evidence or history, not scientific parent edges. No chirp dependency, fitted physical value, observation claim or added axiom.
''')
put(P/'TRACE_GATE.md','''# Scope and reachability

This is upstream conditional support; a downstream physical consumer has not been selected. The target is a single-time energy-law theorem for each fixed normal state and a separate mean/W1 theorem for finite initial energy. The arbitrary-state covariance proof is not a quasifree reduction. Root's exact pure-state distance and the independent fixed-mixed-state asymptotic extension remain distinct. Compact-Fock, CAR and finite-rank detector results use different test classes.

Actual-cell transfer assumes the exact common energy, M23 and weighted trace convergence of preparations. Positive production is required for the explicit varying-state counterexamples. The negative packet is FAIL/partial-narrowing, not exhaustive impossibility. No new physical primitive or retained status is proposed.
''')
put(P/'CLAIM_STATUS_CERTIFICATE.md','''# Source status boundary

Claim class: bounded_theorem. Actual surface status: conditional-support. Ordinary root analytic acceptance and the later source-assembly acceptance are preserved exactly. This publication preparation supplies zero mathematical-predicate executions, no numerical science, no Lean build, no independent audit verdict and no retained promotion. All checking is source-exposed and within the inherited model family/effort.

No editable prompt files, physical axioms, protected audit outputs or effective-status records are changed. The proposed source runner is identity-only. N1 fails, N5 is explicit nonexecution, N8 is bounded historical coverage; no packet PASS.
''')
put(P/'SOURCE_AUTHORITY_BOUNDARY.md','''# Authority and integrity limits

Cryptographic identities check frozen bytes and maps. They do not establish mathematical truth or authenticate wholesale replacement of a program and all its embedded anchors. Root must separately supply and review the exact driver/package hashes and separate acceptance. A template boolean is not authorization.

Complete prior analytic reads are reused only at unchanged source identities. Current wrapper/code reads are recorded separately. Historical pending statements and the earlier review transcription remain preserved; the precision record supplies the corrected two-particle wording. Parent wrapper histories are not silently promoted into new premises or retention.
''')
put(P/'SOURCE_RECOVERY.md','''# Exact source recovery

EVIDENCE_MAP.json maps absolute historical aliases to content-addressed gzip objects. Decompress an object's declared path to recover exact original bytes; verify both compressed and raw digests. The accepted 52-member assembly freeze, its complete bound files, all immediate independent/comparison freeze members, full original cores, precision and root acceptance records are carried. Nested historical receipt paths are provenance only and are not claimed recursively audited.

PUBLICATION_EDITS.json reconstructs the canonical note from three new wrapper segments and two unchanged slices: root407 lines9-383 and independent224 lines20-216. Slice digests are distinct from full-original digests. PARENT_BINDINGS.json identifies four canonical parents and five complete prior-core maps at PR9517 head. No replacement of the mathematical core occurs.

Full note, wrapper, checklist and ledger diffs are gzip archived under diffs. They preserve unified-diff context markers literally. Readable copies and full program/template diffs are in the external frozen preparation package; their exact integrity records are preserved with that package. No broad whitespace normalization is used.
''')
sections=[
('Self-containment','The complete accepted source assembly and directly bound independent/comparison evidence are archived. Four canonical parents at actual PR9517 head are bound by five core maps. The stacked parent must be inside the reviewed cumulative delta or landed before dependent review; no parent merge is invented. Nested historical receipts remain opaque.'),
('Cache and execution discipline','No canonical runner/cache ran during preparation. The proposed primary identity runner declares 60 seconds. Root prepare uses execute_and_write_cache, preserves exact INNER/OUTER returns and complete available streams, and never calls identity stdout a proof certificate.'),
('Claim scope','Each fixed normal rho has the single-time weak-law comparison. Finite input energy separately supplies additive mean and W1. Uniform drive resources are for that fixed rho; arbitrary nonquasifree covariance is retained. Exact pure versus asymptotic mixed distance and the full-picture rotating-test lemma remain distinct.'),
('Negative scope','The linked N1-N8 packet remains FAIL/procedurally incomplete, partial-narrowing. Real counterexamples are preserved; no five-family invention or independent-wall count. Narrowed positive publication with missed routes queued follows the skill stop conditions. N5 is explicit nonexecution and N8 is a bounded four-record search.'),
('Proof obligations','Exact root and independent slices carry the full weighted-operator, energy-domain, covariance, echo, topology and counterexample arguments. The wrapper states their obligation graph, hypotheses and degeneracies. Actual-cell embedding/calibration and weighted initial-state approximation remain explicit physical-application obligations.'),
('Runner validity','The source identity tool evaluates no mathematical predicate. Four future byte-corruption controls target archive, publication, transformation metadata and canonical parent bytes after a successful baseline. They test integrity only. Prior analytic checking, not those controls, supports mathematics.'),
('Packet completeness and exposure','The primary runner reads every payload support input and the four canonical parents; there is no helper registry change. Full originals, precision and directly bound evidence are recoverable. The independent author also wrote the comparison; root had a separately frozen proof. All reviews are same-family/source-exposed, not blinded or model-diverse.'),
('Links and citation graph','Exactly one node and four direct edges are proposed. Mean301 shares the general-control parent. Review records, N8 ledgers and Git ancestry create no theorem edges. Root checks the complete old graph unchanged, then explicitly stages the generated manifest only after inspecting the exact delta.'),
('Note structure and review record','The complete metadata, target, imports, proof obligations, boundary cases and review record precede exact cores. Former provisional parent pointers are replaced only in this publication copy. All raw n=3 diffs are archive-only in the staged payload; literal space-only context markers are not normalized. Full-source and slice identities are separate.'),
('Propose/ratify boundary','No audit status, effective status, axiom, primitive registry, prompt or generated authority ledger is proposed. Citation manifest is the only existing tracked target. Ordinary analytic acceptance and identity cache supply no retained status; independent audit remains separate.'),
('Provenance and generators','Counts and hashes derive from current frozen source bytes. Programs and templates have complete n=3 diffs, exact rendering maps and external root anchors. Existing source assembly and the review typo/precision are preserved. No unavailable future PR number or candidate hash is invented.'),
('Focused and combined gates','Root prepare/verify is unexecuted here. Root owns exact staging and focused compatibility, with the index checked before include-worktree. Combined current-main pipeline, strict lint, cumulative stack review and retained audit remain separate future gates; combined_current_main_gate is false.')]
put(P/'REVIEW_HISTORY.md','# Initial-state publication review history\n\n'+''.join('## '+str(i)+'. '+title+'\n\n'+body+'\n\n' for i,(title,body) in enumerate(sections,1)).rstrip()+'\n')
put(P/'CONFORMANCE.md','# Twelve-section conformance map\n\nThe [review history](REVIEW_HISTORY.md) addresses all twelve sections at their actual scope. The governing specification is pinned at SHA256 2e6cb71957cfa42040e5445184f081eb830709db2c10f23e747e9df0adb2eeb1. Pending runtime and negative-packet limitations are not passed by source preparation.\n\n'+''.join(str(i)+'. '+title+' — source record and separate pending obligations.\n' for i,(title,_) in enumerate(sections,1)))
put(P/'HANDOFF.md',f'''# Initial-state kinetic publication handoff

Source preparation only, for clean child {BRANCH} at {BASE}, regular parent PR9517. Root owns complete publication review, prepare/verify execution, exact staging, commit, push and PR creation. No publication driver or canonical runtime ran here.

The accepted assembly is preserved unchanged. Root407 lines9-383 and independent224 lines20-216 are exact. Full originals, two-particle precision, evidence and acceptances remain archived. Four direct canonical parents have five core maps. No chirp dependency. The pure-state exact identity and additional mixed asymptotic result remain separate; actual-cell transfer remains conditional.

N1 is below five real families. The packet remains FAIL/partial-narrowing with honest N5 nonexecution and a bounded N8 historical search. Skill stop conditions permit the narrowed positive result with missed routes queued; no negative packet PASS or new permission gate is invented.

Root supplies separate exact review/acceptance. Prepare installs frozen additions, one identity cache, four corruption controls and one-node/four-edge graph delta; it emits an exact staging list. Root inspects and stages that list. Verify checks exact stage-0 blobs and absence of unstaged drift before the focused include-worktree checker. Empty checked lists establish no scientific result. All raw diffs enter the payload only as exact gzip archives, avoiding the prior literal-context-marker whitespace failure without suppressing any text diagnostic.

The driver does not stage, publish, retry or clean up after failure. Logs and partial state remain for root recovery. Combined current-main validation and independent retained audit remain distinct.
''')

procedure=js(R/'modulated_kinetic_energy_publication_preparation/PROCEDURE_REUSE.json')
for row in procedure['files']:
    assert pin(CW/row['path'])['sha256']==row['sha256']
    archive(CW/row['path'],'unchanged governance or root-integration procedure source; not executed here')
record(Q/'PROCEDURE_REUSE.json',procedure)
for name in ['prepare_verify_modulated_kinetic_energy.py','IDENTITY_TOOL.template.py','CHECK_PREPARATION_SOURCES.py','run_combined_validation.py','ROOT_ACCEPTANCE.template.json','COMBINED_ROOT_ACCEPTANCE.template.json']:
    p=R/'modulated_kinetic_energy_publication_preparation'/name
    put(Q/'procedural_template'/name,raw(p));archive(p,'fully inspected publication procedure template; no execution')
spec={'base':BASE,'branch':BRANCH,'main':'516cb69d8487ff04f8a48e065d3dcbe71d7dd237','worktree':str(CW.resolve()),'packet':PACKET,'stack_parent':'physics-loop/toe-modulated-kinetic-energy-20261013','stack_parent_regular_pr':9517,'deadline_utc':'2026-10-13T16:42:30Z','expected_graph_delta':{'nodes':1,'edges':4},'notes':[{'key':'initial_state','path':NOTE,'claim_id':CLAIM,'runner':RUNNER,'deps':deps}],'parent_runner_diagnostics':[p['runner'] for p in parents],'notation_exclusions':[],'preserved_source_whitespace':[],'raw_diff_payload_policy':'gzip archives only; exact raw and stored integrity; no broad whitespace exclusion'}
record(Q/'SPECIFICATIONS.json',spec)
record(P/'EVIDENCE_MAP.json',{'objects':sorted(objects.values(),key=lambda x:x['sha256']),'accepted_source_package':{'path':str(A.resolve()),'freeze_sha256':SOURCE_FREEZE,'members':js(A/'FINAL_FREEZE.json')['files'],'all_files':len(js(A/'FINAL_FREEZE.json')['files'])+1},'source_provenance_closure':closures,'scope':'Direct frozen package members and selected explicit source/procedure/history aliases only; nested historical references are not recursively audited.'})
record(Q/'BUILD_RECORD.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_objects':len(objects),'archive_aliases':len(aliases),'source_closure_extents':[len(c['members']) for c in closures],'core_slice_lines':[375,197],'canonical_parent_count':4,'canonical_core_maps':5,'note':pin(Q/'payload'/NOTE),'mathematical_core_edits':0,'mathematical_predicates_executed':0,'canonical_runner_cache_graph_pipeline_executed':False})
print(json.dumps(js(Q/'BUILD_RECORD.json'),indent=2))
