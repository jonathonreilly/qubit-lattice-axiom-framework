#!/usr/bin/env python3
"""Root-only, two-phase source integration; zero mathematical predicates.

Author preparation executes neither this driver nor identity regressions. Prepare installs only a frozen
payload and produces an exact staging list. Root then stages it. Verify rejects
index/worktree drift BEFORE any --include-worktree checker. No Git mutation,
scientific computation, pipeline, PR, audit verdict or retry occurs here.
Prior source acceptance preserves its honest read limits; new wrapper and
complete-driver acceptance must be separately supplied by root.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ast
import hashlib
import importlib.util
import json
import os
import pickle
import re
import signal
import subprocess
import sys
import tempfile
import time
import traceback
from urllib.parse import unquote
import uuid

Q = Path(__file__).resolve().parent
S = Q.parent
WORKTREE = S.parent / 'correlation_worktree'
STAGE = Q / 'payload'
BASE = 'c5eaa6bf752a0893c83c0509c7c349dab53bff14'
BRANCH = 'physics-loop/toe-initial-state-kinetic-energy-20261013'
PACKET = '.claude/science/physics-loops/toe-initial-state-kinetic-energy-20261013'
GRAPH = 'docs/audit/data/citation_graph.json'
MANIFEST = 'docs/audit/data/citation_graph_manifest.json'
EXECUTIONS = S / 'finite_initial_energy_kinetic_publication_execution'
ROOT_ACCEPTANCE_COPY = PACKET + '/PUBLICATION_ROOT_ACCEPTANCE.json'
ROOT_REVIEW_COPY = PACKET + '/PUBLICATION_ASSEMBLY_REVIEW.txt'
DEADLINE = datetime(2026, 10, 13, 16, 42, 30, tzinfo=timezone.utc)
sys.dont_write_bytecode = True


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return Path(path).read_bytes()


def js(path):
    return json.loads(read(path))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if isinstance(value, bytes) else
                     (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def pin(path):
    data = read(path)
    return {'sha256': sha(data), 'bytes': len(data)}


def run_command(run, label, argv, timeout, cwd=WORKTREE, expected_code=0):
    remaining = (DEADLINE - datetime.now(timezone.utc)).total_seconds()
    need(remaining > 0, 'Campaign hard stop reached')
    timeout = min(timeout, remaining)
    folder = run / label
    folder.mkdir(parents=True, exist_ok=False)
    started, start = datetime.now(timezone.utc).isoformat(), time.monotonic()
    out, err, code, timed_out, launch_error = b'', b'', None, False, None
    try:
        process = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0'})
        try:
            out, err = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            out, err = process.communicate()
        code = process.returncode
    except OSError as exc:
        launch_error, err = repr(exc), repr(exc).encode()
    write(folder / 'stdout', out)
    write(folder / 'stderr', err)
    write(folder / 'execution.json', {'argv': argv, 'cwd': str(cwd),
        'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - start, 'timeout_seconds': timeout,
        'timed_out': timed_out, 'exit_code': code, 'expected_code': expected_code,
        'launch_error': launch_error, 'stdout_sha256': sha(out), 'stderr_sha256': sha(err),
        'stdout_bytes': len(out), 'stderr_bytes': len(err)})
    allowed_codes = (expected_code,) if isinstance(expected_code, int) else tuple(expected_code)
    need(not timed_out and launch_error is None and code in allowed_codes,
         'Command result differs; complete streams retained: ' + label)
    return out


def git_read(run, label, *args):
    return run_command(run, label, ['git', *args], 60)


def nul_paths(data):
    return {x.decode() for x in data.split(b'\0') if x}


def cache_api():
    sys.path.insert(0, str(WORKTREE / 'scripts'))
    spec = importlib.util.spec_from_file_location('runner_cache', WORKTREE / 'scripts/runner_cache.py')
    cache = importlib.util.module_from_spec(spec)
    sys.modules['runner_cache'] = cache
    spec.loader.exec_module(cache)
    need(cache.REPO_ROOT.resolve() == WORKTREE, 'Wrong cache repository')
    return cache


def source_guards(run, args):
    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
    need(sha(read(__file__)) == args.program_sha256, 'Root program anchor differs')
    need(WORKTREE == WORKTREE.resolve() and STAGE == STAGE.resolve(), 'Resolved paths differ')
    need(sha(read(Q / 'SOURCE_FREEZE.json')) == args.source_freeze_sha256, 'Source freeze changed')
    need(args.acceptance.resolve().is_relative_to(S) and not args.acceptance.resolve().is_relative_to(Q)
         and not args.acceptance.is_symlink(), 'Separate regular root acceptance required')
    need(sha(read(args.acceptance)) == args.acceptance_sha256, 'Root acceptance changed')
    accepted = js(args.acceptance)
    required = ['unchanged_source_coverage_reused', 'new_publication_wrappers_read',
        'publication_byte_maps_and_diffs_verified', 'complete_driver_read',
        'identity_tools_and_archive_map_read', 'packet_and_dependency_delta_read',
        'whitespace_and_link_policy_reviewed', 'final_assembly_review_read',
        'root_authorizes_execution', 'root_execution_acceptance',
        'block_handoff_and_review_history_read', 'twelve_section_conformance_reviewed',
        'exact_source_diff_producer_conventions_reviewed', 'canonical_parent_maps_reviewed',
        'pure_mixed_scope_and_precision_reviewed', 'conditional_actual_cell_hypotheses_reviewed',
        'negative_partial_narrowing_FAIL_and_bounded_N8_reviewed']
    need(all(accepted.get(k) is True for k in required), 'Root source/program review incomplete')
    original_source = S / 'finite_initial_energy_kinetic_source_assembly'
    original_seal = '8ce9cbb235c6696f760e867192942bb2d0e85867bb333bb75671d890fa59a819'
    need(sha(read(original_source / 'FINAL_FREEZE.json')) == original_seal, 'Accepted source freeze changed')
    old = js(original_source / 'FINAL_FREEZE.json'); members = {r['path'] for r in old['files']}
    need(len(members) == len(old['files']) == 52, 'Accepted source count differs')
    need(not any(p.is_symlink() for p in original_source.rglob('*')) and
        {str(p.relative_to(original_source)) for p in original_source.rglob('*') if p.is_file()}
        == members | {'FINAL_FREEZE.json'}, 'Accepted source membership changed')
    for row in old['files']:
        need(pin(original_source / row['path']) == {k:row[k] for k in ['sha256','bytes']}, 'Accepted source changed')
    old_acceptance = STAGE / PACKET / 'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json'
    old_review = STAGE / PACKET / 'FINITE_INITIAL_ENERGY_SOURCE_ASSEMBLY_ROOT_REVIEW.md'
    need(sha(read(old_acceptance)) == '963bb68b3456a0b746f6c227156417c41c837ff7723523b84a1e2ff1e2b0d80d'
         and sha(read(old_review)) == '002d3585f3ca5b17ab0eaad81e03f10d97337cace053a4a2393eb6ffe539117c',
         'Earlier source review changed')
    status = js(STAGE / PACKET / 'SOURCE_REVIEW_STATUS.json')
    anchors = ['base','branch','prepared_source_freeze_sha256','source_assembly_root_review_sha256',
        'source_assembly_root_acceptance_sha256','disposition','N1','N5','N8','no_go_packet_pass']
    need(all(accepted.get(k) == status[k] for k in anchors) and status['base'] == BASE
         and status['branch'] == BRANCH and status['no_go_packet_pass'] is False,
         'Accepted source or negative scope differs')
    need(status['source_review_coverage_verbatim'] == js(old_acceptance)
         and status['mathematical_core_edits'] == 0 and status['new_independent_mathematical_review'] is False
         and status['unchanged_complete_core_coverage_reused'] is True, 'Source coverage copy differs')
    need(accepted.get('publication_source_freeze_sha256') == args.source_freeze_sha256
         and accepted.get('publication_program_sha256') == args.program_sha256, 'Acceptance does not bind package/program')
    review_path = Path(accepted.get('final_assembly_review_path') or '')
    need(review_path.is_absolute() and review_path.resolve().is_relative_to(S)
         and not review_path.resolve().is_relative_to(Q) and not review_path.is_symlink(), 'Separate root review required')
    need(review_path.is_file() and sha(read(review_path)) == accepted.get('final_assembly_review_sha256')
         and accepted.get('final_assembly_review_disposition') == 'accepted_for_source_integration', 'Exact root review incomplete')
    for record in [args.acceptance, review_path]:
        data=read(record); need(data.endswith(b'\n') and not data.endswith(b'\n\n'), 'Root records require exactly one terminal newline')
    write(run / 'ROOT_ACCEPTANCE.json', read(args.acceptance))
    write(run / 'FINAL_ASSEMBLY_REVIEW.md', read(review_path))
    write(run / 'SOURCE_FREEZE.json', read(Q / 'SOURCE_FREEZE.json'))
    freeze=js(Q / 'SOURCE_FREEZE.json'); declared={r['path'] for r in freeze['files']}
    need(len(declared)==len(freeze['files'])==freeze['file_count'], 'Duplicate frozen membership')
    need(not any(p.is_symlink() for p in Q.rglob('*')) and
         {str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file() and p != Q/'SOURCE_FREEZE.json'} == declared,
         'Frozen package membership differs')
    for row in freeze['files']:
        path=Q/row['path']
        need(path.resolve().is_relative_to(Q) and pin(path)=={k:row[k] for k in ['sha256','bytes']}, 'Frozen source changed')
    payload={r['path'][8:]:{k:r[k] for k in ['sha256','bytes']} for r in freeze['files'] if r['path'].startswith('payload/')}
    need({str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()}==set(payload), 'Payload membership differs')
    for row in js(Q/'PROCEDURE_REUSE.json')['files']:
        need(pin(WORKTREE/row['path'])=={k:row[k] for k in ['sha256','bytes']}, 'Current integration procedure changed')
    spec=js(Q/'SPECIFICATIONS.json')
    need(spec['base']==BASE and spec['branch']==BRANCH and spec['worktree']==str(WORKTREE)
         and spec['packet']==PACKET and spec['stack_parent']=='physics-loop/toe-modulated-kinetic-energy-20261013'
         and spec['stack_parent_regular_pr']==9517 and spec['expected_graph_delta']=={'nodes':1,'edges':4}
         and spec['deadline_utc']=='2026-10-13T16:42:30Z', 'Publication target differs')
    branch=js(STAGE/PACKET/'FINITE_INITIAL_ENERGY_BRANCH_START.json')
    need(branch['base']==BASE and branch['branch']==BRANCH and branch['parent_pr'].endswith('/pull/9517'), 'Branch receipt differs')
    need(all((STAGE/PACKET/n).is_file() for n in ['HANDOFF.md','REVIEW_HISTORY.md','CONFORMANCE.md','TRACE_GATE.md',
         'CLAIM_STATUS_CERTIFICATE.md','NO_GO_DISCIPLINE_CHECKLIST.md','NO_GO_LEDGER.md','N8_HISTORICAL_SCAN.md']), 'Required block record missing')
    expected=set(payload)|{'logs/runner-cache/'+Path(n['runner']).stem+'.txt' for n in spec['notes']}|{MANIFEST,ROOT_ACCEPTANCE_COPY,ROOT_REVIEW_COPY}
    need(expected==set(js(Q/'EXPECTED_INSTALL_AND_STAGE_PATHS.json')['paths']), 'Planned footprint differs')
    additions=js(STAGE/PACKET/'CLAIM_REGISTRY_ADDITIONS.json')
    need({n['claim_id'] for n in additions['nodes']}=={n['claim_id'] for n in spec['notes']} and
         {(e['from'],e['to']) for e in additions['direct_edges']}=={(n['claim_id'],d) for n in spec['notes'] for d in n['deps']}, 'Graph proposal differs')
    for row in js(STAGE/PACKET/'PARENT_BINDINGS.json')['parents']:
        need(pin(WORKTREE/row['path'])=={'sha256':row['published_sha256'],'bytes':row['bytes']}, 'Canonical parent drift before installation')
    return payload,spec


def repeated_procedure_guard():
    for row in js(Q / 'PROCEDURE_REUSE.json')['files']:
        need(pin(WORKTREE / row['path']) == {'sha256': row['sha256'], 'bytes': row['bytes']},
             'Procedure changed during execution: ' + row['path'])


def source_checks(run, spec):
    import yaml
    inputs = None
    parsed, tool_bodies = [], []
    for row in spec['notes']:
        raw_tool = read(WORKTREE / row['runner'])
        tree = ast.parse(raw_tool, filename=row['runner'])
        attribution = ('CLAIM = ' + repr(row['claim_id']) + '\n').encode()
        need(raw_tool.count(attribution) == 1, 'Claim attribution assignment differs')
        tool_bodies.append(raw_tool.replace(attribution, b"CLAIM = 'COMMON_CLAIM'\n", 1))
        values = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body
            if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
            and n.targets[0].id in ['AUDIT_TIMEOUT_SEC', 'AUDIT_INPUT_PATHS']}
        need(values['AUDIT_TIMEOUT_SEC'] == 60, 'Declared timeout differs')
        if inputs is None:
            inputs = values['AUDIT_INPUT_PATHS']
        need(values['AUDIT_INPUT_PATHS'] == inputs, 'Shared identity read closure differs')
        front = yaml.safe_load(read(WORKTREE / row['path']).decode().split('---', 2)[1])
        expected = {'claim_id': row['claim_id'], 'claim_type': 'bounded_theorem',
            'target_claim_type': 'bounded_theorem', 'actual_current_surface_status': 'conditional-support',
            'upstream_dependencies': row['deps'], 'runner': row['runner'], 'artifact_role': 'theorem',
            'bare_retained_allowed': False, 'audit_required_before_effective_retained': True}
        need(all(front.get(k) == v for k, v in expected.items()), 'Note metadata differs')
        need(all(k in front for k in ['trace_class', 'target_claim_id', 'target_blocker_text',
            'source_of_blocker_text', 'reachability_to_target', 'conditional_surface_status',
            'hypothetical_axiom_status', 'admitted_observation_status', 'claim_type_reason', 'next_trace_action']),
            'Required trace metadata absent')
        parsed.append(front)
    need(len(tool_bodies) == 1 and all(body == tool_bodies[0] for body in tool_bodies),
         'Identity tools differ beyond claim attribution; integrity coverage must be reconsidered')
    links, excluded = [], []
    tracked = nul_paths(git_read(run, 'link_tracked_inventory', 'ls-files', '-z'))
    planned = {str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()} | {ROOT_ACCEPTANCE_COPY, ROOT_REVIEW_COPY}
    need(js(WORKTREE / PACKET / 'MARKDOWN_NOTATION_CLASSIFICATION.json')['exclusions'] ==
         spec['notation_exclusions'], 'Notation inventory differs from frozen specification')
    for path in [*[WORKTREE / n['path'] for n in spec['notes']], *sorted((WORKTREE / PACKET).glob('*.md'))]:
        relative = str(path.relative_to(WORKTREE))
        raw_text = path.read_text()
        text = raw_text
        for row in [x for x in spec['notation_exclusions'] if x['note'] == relative]:
            lines = raw_text.splitlines(keepends=True)
            need(lines[row['canonical_line'] - 1] == row['exact_line'] and
                 raw_text.count(row['context']) == 1 and row['context'].count(row['raw_match']) == 1 and
                 row['exact_line'].count(row['raw_match']) == 1,
                 'Exact reviewed LaTeX notation exclusion no longer matches')
            # Remove only this exact target-shaped factor from the scan, never from the file.
            replacement = row['context'].replace(row['raw_match'], ']EXACT_LATEX_NOTATION', 1)
            text = text.replace(row['context'], replacement, 1)
            excluded.append(row)
        text = re.sub(r'(?m)^(?: {4}|\t).*(?:\n|$)', '', text)
        tick = chr(96)
        text = re.sub(tick * 3 + r'[\s\S]*?' + tick * 3 + r'|~~~[\s\S]*?~~~|' +
                      tick + '[^' + tick + ']*' + tick, '', text)
        for target in re.findall(r'\]\(([^)\s]+)\)', text):
            if target.startswith(('http:', 'https:', '#', 'mailto:')):
                links.append({'source': relative, 'target': target, 'kind': 'external_or_fragment'})
                continue
            need(not target.startswith('/'), 'Absolute Markdown link forbidden')
            raw_dest = path.parent / unquote(target.split('#', 1)[0].strip('<>'))
            dest = raw_dest.resolve()
            need(dest.is_relative_to(WORKTREE) and dest.is_file() and not raw_dest.is_symlink(),
                 'Broken, escaped or nonregular local link: ' + target)
            need(str(dest.relative_to(WORKTREE)) in tracked | planned, 'Untracked unplanned link target: ' + target)
            links.append({'source': relative, 'target': target, 'kind': 'resolved_local'})
    need(excluded == spec['notation_exclusions'], 'Not all exact notation exclusions were accounted for')
    write(run / 'syntax_metadata_links.json', {'frontmatter': parsed, 'links': links,
        'explicit_notation_exclusions': excluded,
        'broad_formula_link_exclusion': False,
        'primary_python_syntax_parsed': True, 'mathematical_predicates_executed': 0})
    compile_dir = run / 'python_compile_files'
    compile_dir.mkdir()
    pairs = [(str(WORKTREE / n['runner']), str(compile_dir / (Path(n['runner']).stem + '.pyc')))
             for n in spec['notes']]
    compile_code = 'import json,py_compile,sys; [(py_compile.compile(a,cfile=b,doraise=True)) for a,b in json.loads(sys.argv[1])]'
    run_command(run, 'python_compile', [sys.executable, '-c', compile_code, json.dumps(pairs)], 60)
    report = run / 'vocabulary.json'
    paths = [n['path'] for n in spec['notes']] + [n['runner'] for n in spec['notes']] + [PACKET]
    vocabulary_before = {name: pin(WORKTREE / name) for name in planned}
    run_command(run, 'vocabulary_fix', [sys.executable, 'scripts/vocab_lint.py', '--fix', *paths], 120)
    need({name: pin(WORKTREE / name) for name in planned} == vocabulary_before,
         'Vocabulary changed frozen source; preserve failure and prepare a separately reviewed repair')
    run_command(run, 'vocabulary', [sys.executable, 'scripts/vocab_lint.py', '--report-only',
        '--report-path', str(report), *paths], 120)
    result = js(report)
    need(result['summary']['total_auto_correctable'] == 0 and result['summary']['total_needs_human'] == 0,
         'Vocabulary needs root review; changed frozen bytes cannot be accepted')
    return inputs


def integrity_tamper_probes(run, spec, inputs):
    # Called only after successful canonical baselines. Exact error reasons
    # distinguish meaningful byte rejection from unrelated startup failures.
    archive = next(p for p in inputs if '/objects/' in p)
    parent = js(WORKTREE / PACKET / 'PARENT_BINDINGS.json')['parents'][0]['path']
    cases = [('archive', archive, 'Compressed archive changed'),
             ('publication', spec['notes'][0]['path'], 'Published source does not reconstruct'),
             ('metadata', PACKET + '/PUBLICATION_EDITS.json', 'Publication transformation changed'),
             ('parent', parent, 'Canonical parent bytes changed')]
    runner = spec['notes'][0]['runner']
    outcomes = []
    for label, target, error in cases:
        with tempfile.TemporaryDirectory(prefix='initial-state-kinetic-integrity-') as folder:
            root = Path(folder)
            for name in inputs + [runner]:
                write(root / name, read(WORKTREE / name))
            write(root / target, read(root / target) + b'\nbyte-integrity-tamper\n')
            output = run_command(run, 'integrity_tamper_' + label,
                [sys.executable, str(root / runner)], 60, cwd=root, expected_code=1)
            need(output == b'', 'Tampered identity tool unexpectedly emitted success stdout')
            failure = json.loads(read(run / ('integrity_tamper_' + label) / 'stderr'))
            need(failure == {'result': 'identity_verification_incomplete', 'error': error,
                 'mathematical_operations_executed': False, 'mathematical_predicates_executed': 0,
                 'scientific_mutations_executed': 0}, 'Corruption failed for an unexpected reason')
            outcomes.append({'case': label, 'target': target, 'expected_error': error, 'observed': failure})
    write(run / 'integrity_tamper_scope.json', {'cases': outcomes,
        'successful_canonical_baselines_preceded_controls': True,
        'expected_nonzero_exits': 4, 'scientific_mutations_executed': 0,
        'meaning': 'Four corrupted byte inputs were rejected for their exact expected reasons; no mathematical claims were executed.'})


def preserve_return(folder, stem, value):
    (folder / (stem + '.raw.pickle')).write_bytes(pickle.dumps(value, protocol=5))
    write(folder / (stem + '.raw.json'), value if isinstance(value, dict) else
          [value[0], str(value[1]) if value[1] is not None else None])


def canonical_identity(cache, run, row):
    need((DEADLINE - datetime.now(timezone.utc)).total_seconds() >= 65, 'Insufficient campaign time for declared cache timeout')
    folder = run / ('canonical_' + row['key'])
    folder.mkdir()
    original, inner = cache.execute_runner, []
    def capture(*args, **kwargs):
        need(args == (row['runner'],) and kwargs == {'timeout_sec': 60}, 'Unexpected canonical API call')
        write(folder / 'CHILD_INVOCATION.json', {
            'argv': [sys.executable, '-u', str(WORKTREE / row['runner'])],
            'cwd': str(WORKTREE), 'timeout_seconds': 60,
            'argv_source': 'Exact pinned runner_cache.execute_runner implementation',
            'started_utc': datetime.now(timezone.utc).isoformat(),
            'child_stderr_merged_with_stdout_by_API': True})
        value = original(*args, **kwargs)
        preserve_return(folder, 'INNER', value)
        if value.get('live_log') and Path(value['live_log']).exists():
            write(folder / 'INNER.complete_merged_live_log', read(value['live_log']))
        inner.append(value)
        return value
    cache.execute_runner = capture
    try:
        outer = cache.execute_and_write_cache(row['runner'], 60)
        preserve_return(folder, 'OUTER', outer)
    except BaseException:
        write(folder / 'OUTER.exception.txt', traceback.format_exc().encode())
        raise
    finally:
        cache.execute_runner = original
    need(len(inner) == 1 and outer[0] == inner[0], 'Canonical INNER/OUTER result differs')
    result, path = outer
    write(folder / 'canonical.stdout', result['stdout'].encode())
    write(folder / 'canonical.stderr', result['stderr'].encode())
    need(result['status'] == 'ok' and result['exit_code'] == 0 and result['timeout_sec'] == 60 and
         result['stderr'] == '' and path == cache.cache_path_for(row['runner']), 'Canonical identity failed')
    write(folder / 'canonical.cache', read(path))
    lines = result['stdout'].splitlines()
    need(len(lines) == 6, 'Unexpected identity-only output')
    report = json.loads(lines[0])
    need(report['result'] == 'source_identities_and_reconstruction_match' and
         report['claim_id'] == row['claim_id'] and report['mathematical_operations_executed'] is False and
         report['no_go_packet_pass_supplied_by_tool'] is False and
         report['mathematical_predicates_executed'] == report['scientific_mutations_executed'] == 0,
         'Identity-only interpretation differs')
    for prefix, line in zip(['per_element:', 'per_site:', 'per_mode:', 'per_block:', 'lattice_wide:'], lines[1:]):
        need(line.startswith(prefix + ' checked and not executed — source integrity only;'),
             'Resolution statement no longer excludes scientific execution')
    write(folder / 'interpretation.json', {'identity_report': report,
        'canonical_child_stderr_merged_into_complete_stdout': True,
        'separate_original_child_stderr_not_exposed_by_API': True,
        'mathematical_proof_verified_by_program': False, 'no_go_packet_pass': False})
    return str(path.relative_to(WORKTREE))


def topology_check(graph, manifest):
    edges = [(e['from'], e['to']) for e in graph['edges']]
    need(all(set(e) == {'from', 'to'} for e in graph['edges']) and len(edges) == len(set(edges)), 'Edge schema/duplicates')
    need(set(graph['nodes']) == set(manifest['nodes']), 'Graph/manifest node membership differs')
    for key, row in graph['nodes'].items():
        deps = sorted(row['deps'])
        need(len(deps) == len(set(deps)) and set(deps) == {b for a, b in edges if a == key} and
             all(d in graph['nodes'] for d in deps), 'Dependency mismatch or unresolved edge')
        need(manifest['nodes'][key] == {'out_degree': len(deps), 'deps_hash': sha('\n'.join(deps).encode())[:12]},
             'Manifest topology fingerprint differs')
    need(graph['roots'] == sorted(k for k, v in graph['nodes'].items() if not v['deps']), 'Roots differ')
    need(manifest['node_count'] == graph['stats']['node_count'] == len(graph['nodes']) and
         manifest['edge_count'] == graph['stats']['edge_count'] == len(edges), 'Topology count differs')
    hint_counts, seed_counts = {}, {}
    for node in graph['nodes'].values():
        hint = node.get('claim_type_author_hint') or 'none'
        seed = node.get('claim_type_seed_hint') or 'none'
        hint_counts[hint] = hint_counts.get(hint, 0) + 1
        seed_counts[seed] = seed_counts.get(seed, 0) + 1
    indegree_nodes = {target for _, target in edges}
    computed_stats = {'node_count': len(graph['nodes']), 'edge_count': len(edges),
        'claim_type_author_hint_counts': hint_counts, 'claim_type_seed_hint_counts': seed_counts,
        'runners_with_path': sum(bool(n['runner_path']) for n in graph['nodes'].values()),
        'root_count': len(graph['roots']),
        'leaf_count': sum(n not in indegree_nodes for n in graph['nodes'])}
    need(graph['stats'] == computed_stats and
         set(graph) == {'schema_version', 'stats', 'nodes', 'edges', 'roots'},
         'Complete graph aggregates or object schema differ')
    return set(edges)


def graph_compare(run, spec, old, before):
    run_command(run, 'graph_after', [sys.executable, 'docs/audit/scripts/run_citation_graph_build.py'], 300)
    run_command(run, 'graph_manifest', [sys.executable, 'docs/audit/scripts/write_citation_graph_manifest.py'], 300)
    graph, after = js(WORKTREE / GRAPH), js(WORKTREE / MANIFEST)
    write(run / 'citation_graph.complete.json', read(WORKTREE / GRAPH))
    write(run / 'citation_graph_manifest.complete.json', read(WORKTREE / MANIFEST))
    old_edges, edges = topology_check(old, before), topology_check(graph, after)
    new = {r['claim_id'] for r in spec['notes']}
    wanted = {(r['claim_id'], d) for r in spec['notes'] for d in r['deps']}
    need(graph['schema_version'] == old['schema_version'] and after['schema_version'] == before['schema_version'], 'Schema changed')
    need(set(graph['nodes']) == set(old['nodes']) | new and not new & set(old['nodes']), 'New node delta differs')
    need(edges == old_edges | wanted and not wanted & old_edges, 'Exact four-edge delta differs')
    need(all(graph['nodes'][k] == v for k, v in old['nodes'].items()) and
         all(after['nodes'][k] == v for k, v in before['nodes'].items()), 'Old complete node changed')
    old_edge_objects = {json.dumps(e, sort_keys=True) for e in old['edges']}
    actual_old_edge_objects = {json.dumps(e, sort_keys=True) for e in graph['edges'] if e['from'] not in new}
    need(actual_old_edge_objects == old_edge_objects, 'Old full edge object changed')
    # Every edge out of a new note is explicitly enumerated. Existing roots
    # retain their bytes. Check only new-node cycles; old topology is unchanged.
    need(graph['roots'] == old['roots'], 'Existing root objects changed')
    active, done = set(), set()
    def visit(node):
        if node not in new:
            return
        need(node not in active, 'Citation cycle introduced')
        if node in done:
            return
        active.add(node)
        for dep in graph['nodes'][node]['deps']:
            visit(dep)
        active.remove(node)
        done.add(node)
    for node in new:
        visit(node)
    for row in spec['notes']:
        node = graph['nodes'][row['claim_id']]
        need(node['claim_type_author_hint'] == node['claim_type_seed_hint'] == 'bounded_theorem',
             'New graph claim-type hint differs')
        need(node['path'] == row['path'] and node['runner_path'] == row['runner'] and
             node['helper_runner_paths'] == [] and node['note_hash'] == sha(read(WORKTREE / row['path'])) and
             sorted(node['deps']) == sorted(row['deps']), 'New graph source/dependencies differ')
    delta = {'nodes': len(graph['nodes']) - len(old['nodes']), 'edges': len(edges) - len(old_edges)}
    need(delta == {'nodes': 1, 'edges': 4}, 'Exact graph delta differs')
    write(run / 'graph.comparison.json', {'delta': delta, 'new_edges': sorted(wanted),
        'old_complete_nodes_and_edges_unchanged': True})
    return delta


def staged_whitespace_guard(run, label, expected):
    policy = js(Q / 'SPECIFICATIONS.json')['preserved_source_whitespace']
    need(js(WORKTREE / PACKET / 'SOURCE_WHITESPACE_CLASSIFICATION.json')['preserved_source_whitespace'] == policy,
         'Exact source whitespace policy differs')
    literal_hashes = {piece['source_sha256']
        for note in js(WORKTREE / PACKET / 'PUBLICATION_EDITS.json')['notes']
        for piece in note['pieces'] if piece['kind'] == 'accepted_core_slice'}
    approved = []
    for row in policy:
        note = read(WORKTREE / row['note']).decode()
        need(row['source_sha256'] in literal_hashes and
             note.splitlines(keepends=True)[row['canonical_line'] - 1] == row['exact_line'] and
             note.count(row['context']) == 1 and sha(row['exact_line'].encode()) == row['line_sha256'] and
             sha(row['context'].encode()) == row['context_sha256'], 'Preserved literal whitespace fingerprint changed')
        approved.append((row['note'], row['canonical_line'], row['exact_line']))
    archive_policy = js(Q / 'BINARY_PAYLOAD_PINS.json')
    archive_pins = {row['path']: row for row in archive_policy['files']}
    need(set(archive_pins) <= set(expected), 'Declared archive path outside staged footprint')
    found = []
    for name in sorted(expected):
        if name in archive_pins:
            need(pin(WORKTREE / name) == {k: archive_pins[name][k] for k in ['sha256','bytes']},
                 'Exact declared archive changed during whitespace check')
            continue
        for number, line in enumerate(read(WORKTREE / name).decode().splitlines(keepends=True), 1):
            if line.rstrip('\r\n').endswith((' ', '\t')):
                found.append((name, number, line))
    need(sorted(found) == sorted(approved), 'Unexpected trailing whitespace beyond the exact literal allowlist')
    command_label = label + '_whitespace'
    out = run_command(run, command_label,
        ['git', 'diff', '--no-color', '--check', '--cached', BASE, '--'], 60,
        expected_code=(0, 2))
    result = js(run / command_label / 'execution.json')
    need(read(run / command_label / 'stderr') == b'', 'Unexpected whitespace-check stderr')
    diagnostic = b''.join((name + ':' + str(number) + ': trailing whitespace.\n+' + line).encode()
                          for name, number, line in sorted(approved))
    need((result['exit_code'] == 0 and out == b'') or
         (bool(approved) and result['exit_code'] == 2 and out == diagnostic),
         'Whitespace-check result is not exactly the reviewed literal diagnostic set')
    write(run / (label + '_SOURCE_WHITESPACE_SCOPE.json'), {
        'policy': policy, 'actual_git_exit_code': result['exit_code'],
        'actual_git_stdout_sha256': sha(out), 'all_other_trailing_whitespace_rejected': True,
        'original_mathematical_bytes_changed': False, 'root_explicit_review_required': True,
        'scope': 'Only exact declared gzip archives bypass text decoding; their byte pins remain mandatory. Literal text allowlist only; raw nonzero diagnostics are never reported as zero exits.'})


def footprint_guard(run, label, expected, staged):
    need(git_read(run, label + '_head', 'rev-parse', 'HEAD').decode().strip() == BASE, 'HEAD changed')
    need(git_read(run, label + '_branch', 'branch', '--show-current').decode().strip() == BRANCH, 'Branch changed')
    records = [x.decode() for x in git_read(run, label + '_status', 'status', '--porcelain=v1', '-z', '--untracked-files=all').split(b'\0') if x]
    need({x[3:] for x in records} == set(expected), 'Publication footprint differs')
    for x in records:
        allowed = ('M ' if x[3:] == MANIFEST else 'A ') if staged else (' M' if x[3:] == MANIFEST else '??')
        need(x[:2] == allowed, 'Index/worktree state differs: ' + x)
    if staged:
        need(not git_read(run, label + '_unstaged', 'diff', '--name-only', '-z'), 'Unstaged tracked changes exist')
        need(nul_paths(git_read(run, label + '_staged', 'diff', '--cached', '--name-only', '-z', BASE, '--')) == set(expected),
             'Exact required payload/cache/manifest set is not staged')
        staged_whitespace_guard(run, label, expected)
    else:
        need(not git_read(run, label + '_index', 'diff', '--cached', '--name-only', '-z'), 'Index changed during prepare')



def staged_blob_guard(run, label, expected, prepared_pins):
    """Read the Git index only; compare actual stage-0 blob OIDs to prepared bytes."""
    fmt = git_read(run, label + '_object_format', 'rev-parse', '--show-object-format').decode().strip()
    need(fmt in {'sha1', 'sha256'}, 'Unsupported Git object format')
    raw = git_read(run, label + '_index_blobs', 'ls-files', '--stage', '-z', '--', *sorted(expected))
    actual = {}
    for item in raw.split(b'\0'):
        if not item:
            continue
        meta, name = item.split(b'\t', 1)
        mode, oid, stage = meta.decode().split()
        path = name.decode()
        need(path not in actual and stage == '0' and mode == '100644',
             'Duplicate, nonregular or unresolved index entry')
        actual[path] = oid
    need(set(actual) == set(expected), 'Exact index membership differs')
    checked = {}
    for path in sorted(expected):
        data = read(WORKTREE / path)
        need(pin(WORKTREE / path) == prepared_pins[path], 'Prepared source changed before blob check')
        oid = hashlib.new(fmt, b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        need(actual[path] == oid, 'Staged bytes differ from prepared source: ' + path)
        checked[path] = {'index_oid': oid, **prepared_pins[path]}
    write(run / (label + '_EXACT_STAGED_BLOBS.json'), {'object_format': fmt,
        'stage_zero_regular_blob_identities': checked, 'git_mutation': False})

def prepare(run, args, payload, spec):
    need(git_read(run, 'initial_head', 'rev-parse', 'HEAD').decode().strip() == BASE, 'Wrong base')
    need(git_read(run, 'initial_branch', 'branch', '--show-current').decode().strip() == BRANCH, 'Wrong branch')
    need(not git_read(run, 'initial_status', 'status', '--porcelain=v1', '-z', '--untracked-files=all'), 'Child is not clean')
    need(git_read(run, 'stack_parent_head', 'rev-parse', 'refs/heads/physics-loop/toe-modulated-kinetic-energy-20261013').decode().strip() == BASE,
         'Reported stack parent no longer points at the accepted base')
    need(git_read(run, 'reported_main_ref', 'rev-parse', 'refs/remotes/origin/main').decode().strip() == spec['main'],
         'Reported local main ref differs; root must refresh and review changed dependencies')
    known_caches = {'logs/runner-cache/' + Path(row['runner']).stem + '.txt' for row in spec['notes']}
    for name in set(payload) | known_caches | {ROOT_ACCEPTANCE_COPY, ROOT_REVIEW_COPY}:
        need(not (WORKTREE / name).exists(), 'Refuse duplicate or partial install: ' + name)
    before = js(WORKTREE / MANIFEST)
    need(git_read(run, 'base_manifest', 'show', BASE + ':' + MANIFEST) == read(WORKTREE / MANIFEST), 'Base manifest changed')
    write(run / 'base_graph_manifest.json', read(WORKTREE / MANIFEST))
    run_command(run, 'graph_before', [sys.executable, 'docs/audit/scripts/run_citation_graph_build.py'], 300)
    old = js(WORKTREE / GRAPH)
    write(run / 'base_graph.json', read(WORKTREE / GRAPH))
    topology_check(old, before)
    for name in sorted(payload):
        need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
        target = WORKTREE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        need(target.parent.resolve().is_relative_to(WORKTREE), 'Install parent escaped worktree')
        with target.open('xb') as handle:
            handle.write(read(STAGE / name))
    for name, source in [(ROOT_ACCEPTANCE_COPY, 'ROOT_ACCEPTANCE.json'),
                         (ROOT_REVIEW_COPY, 'FINAL_ASSEMBLY_REVIEW.md')]:
        target = WORKTREE / name
        need(target.parent.resolve().is_relative_to(WORKTREE), 'Root-record destination escaped worktree')
        with target.open('xb') as handle:
            handle.write(read(run / source))
    inputs = source_checks(run, spec)
    immutable = {n: pin(WORKTREE / n) for n in set(inputs) | {x['runner'] for x in spec['notes']}}
    cache = cache_api()
    caches = [canonical_identity(cache, run, row) for row in spec['notes']]
    integrity_tamper_probes(run, spec, inputs)
    need(set(caches) == known_caches and len(caches) == len(known_caches), 'Canonical cache footprint differs')
    delta = graph_compare(run, spec, old, before)
    statuses = {r['runner']: cache.cache_status(r['runner']) for r in spec['notes']}
    need(all(v == 'fresh' for v in statuses.values()), 'New primary identity cache is not fresh')
    expected = set(payload) | set(caches) | {MANIFEST, ROOT_ACCEPTANCE_COPY, ROOT_REVIEW_COPY}
    footprint_guard(run, 'prepare_final', expected, staged=False)
    need({n: pin(WORKTREE / n) for n in immutable} == immutable, 'Declared input changed during integration')
    need({n: pin(WORKTREE / n) for n in payload} == payload, 'Frozen installed payload changed during prepare')
    repeated_procedure_guard()
    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
    pins = {n: pin(WORKTREE / n) for n in sorted(expected)}
    prepared = {'status': 'ready_for_explicit_root_staging', 'base': BASE, 'branch': BRANCH,
        'program_sha256': args.program_sha256, 'source_freeze_sha256': args.source_freeze_sha256,
        'acceptance_sha256': args.acceptance_sha256, 'expected_paths': sorted(expected), 'pins': pins,
        'declared_inputs': immutable, 'cache_paths': caches, 'cache_statuses': statuses,
        'graph_delta': delta, 'mathematical_predicates_executed': 0, 'scientific_mutations_executed': 0,
        'identity_tamper_cases': 4, 'include_worktree_checker_executed': False,
        'root_staging_required': True, 'git_mutation': False, 'pipeline_executed': False, 'combined_current_main_gate': False}
    write(run / 'PREPARED.json', prepared)
    write(run / 'ROOT_STAGE_PATHS.nul', b''.join(n.encode() + b'\0' for n in sorted(expected)))
    write(run / 'ROOT_STAGE_PATHS.json', {'exact_paths_for_root_staging': sorted(expected),
        'only_existing_tracked_path': MANIFEST, 'root_must_inspect_graph_before_staging': True})
    return prepared


def verify(run, args, payload, spec):
    previous = args.prepared_run.resolve()
    need(previous.is_relative_to(EXECUTIONS) and previous != run and previous.is_dir(), 'Wrong prepare evidence directory')
    receipt = previous / 'PREPARED.json'
    need(sha(read(receipt)) == args.prepared_receipt_sha256, 'Prepared receipt changed')
    prepared = js(receipt)
    need(prepared['status'] == 'ready_for_explicit_root_staging' and
         all(prepared[k] == getattr(args, k) for k in ['program_sha256', 'source_freeze_sha256', 'acceptance_sha256']) and
         prepared['base'] == BASE and prepared['branch'] == BRANCH, 'Prepared acceptance/target differs')
    expected = set(payload) | set(prepared['cache_paths']) | {MANIFEST, ROOT_ACCEPTANCE_COPY, ROOT_REVIEW_COPY}
    need(expected == set(prepared['expected_paths']) == set(prepared['pins']), 'Prepared footprint differs')
    need({n: pin(WORKTREE / n) for n in expected} == prepared['pins'], 'Prepared bytes changed')
    need({n: pin(WORKTREE / n) for n in payload} == payload, 'Installed payload differs from frozen source')
    need({n: pin(WORKTREE / n) for n in prepared['declared_inputs']} == prepared['declared_inputs'], 'Declared inputs changed')
    # Critical order: exact staged index + no unstaged differences BEFORE checker.
    footprint_guard(run, 'before_include_worktree', expected, staged=True)
    staged_blob_guard(run, 'before_include_worktree', expected, prepared['pins'])
    write(run / 'STAGE_BEFORE_INCLUDE_WORKTREE.json', {'exact_prepared_bytes_staged': True,
        'no_unstaged_changes': True, 'expected_paths': sorted(expected),
        'prepared_receipt_sha256': args.prepared_receipt_sha256})
    output = run_command(run, 'focused_compatibility', [sys.executable,
        'docs/audit/scripts/check_changed_audit_evidence.py', '--base', BASE, '--include-worktree', '--json'], 120)
    report = json.loads(output)
    need(report['base'] == BASE and report['diff_scope'] == 'committed_and_worktree' and
         not report['failures'] and not report['control_failures'], 'Focused existing-ledger compatibility failed')
    write(run / 'focused_scope.json', {'actually_checked_claims': [r['claim_id'] for r in report['checked']],
        'checked_count': len(report['checked']), 'mathematical_predicates_executed_by_this_driver': 0,
        'scope': 'Existing selected ledger compatibility only. checked[] may be empty; that verifies no scientific claim. No new-claim audit or retained verdict.'})
    cache = cache_api()
    statuses = {r['runner']: cache.cache_status(r['runner']) for r in spec['notes']}
    need(all(v == 'fresh' for v in statuses.values()), 'New identity cache freshness changed')
    parents = spec['parent_runner_diagnostics']
    write(run / 'parent_cache_diagnostics.json', {'statuses': {p: cache.cache_status(p) for p in parents},
        'scope': 'Diagnostics only; no parent runner rerun, refresh, proof coverage or audit authority.'})
    footprint_guard(run, 'verify_final', expected, staged=True)
    staged_blob_guard(run, 'verify_final', expected, prepared['pins'])
    need({n: pin(WORKTREE / n) for n in expected} == prepared['pins'], 'Checker changed publication bytes')
    need({n: pin(WORKTREE / n) for n in prepared['declared_inputs']} == prepared['declared_inputs'], 'Late input drift')
    repeated_procedure_guard()
    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
    result = {'status': 'source_integration_and_staged_compatibility_completed', 'base': BASE,
        'graph_delta': prepared['graph_delta'], 'cache_statuses': statuses, 'source_footprint_staged': True,
        'mathematical_predicates_executed': 0, 'scientific_mutations_executed': 0,
        'identity_tamper_cases': 4, 'mathematical_proof_verified_by_program': False,
        'no_go_packet_pass': False, 'N1': 'FAIL: five-family minimum unmet', 'N5': 'identity-only nonexecution',
        'audit_verdict_applied': False, 'retained_promotion': False, 'git_mutation': False,
        'pipeline_executed': False, 'combined_current_main_gate': False, 'root_publication_required': True,
        'later_obligations': ['cumulative PR9517 stack plus this milestone review', 'combined current-main landing validation', 'strict audit lint', 'formal retained audit']}
    write(run / 'VERIFICATION_RESULT.json', result)
    actual = ('Root execution completed source reconstruction, syntax/metadata/local-link and vocabulary checks, '
        'four byte-integrity tamper probes, one canonical identity-only cache and the exact one-node/four-edge '
        'graph delta with old complete nodes/edges unchanged. Root staged the exact frozen payload, caches and '
        'manifest before the focused existing-ledger checker; the driver verified index equality before and '
        'after that checker. These are source-integration checks, with zero mathematical predicates or '
        'scientific mutations and no new-claim audit. Complete available merged canonical streams and raw '
        'INNER/OUTER returns are preserved. Exact mathematical notation exclusions are source-bound; '
        'there is no broad formula exclusion. Whitespace diagnostics retain their actual codes. '
        'Vocabulary fix/report and explicit Python compilation ran; frozen installed bytes stayed exact. '
        'The initial payload includes HANDOFF and REVIEW_HISTORY with all twelve conformance sections. '
        'Every unclassified finding fails. N1 fails the route minimum; N5 reports identity-only nonexecution; bounded N8 coverage is explicit. '
        'Combined current-main landing validation, strict audit lint and retained audit remain later obligations.')
    proposed = (Q / 'PR_BODY.proposed.md').read_text()
    need('<!-- VALIDATION_START -->' in proposed and '<!-- VALIDATION_END -->' in proposed, 'PR template validation markers missing')
    first, rest = proposed.split('<!-- VALIDATION_START -->', 1)
    _, last = rest.split('<!-- VALIDATION_END -->', 1)
    ready = first + actual + last
    ready = ready.replace("The new publication wrappers remain subject to root's exact review and acceptance.",
        'Root accepted the exact publication wrappers, program and packet; the frozen root review and acceptance are carried in the installed packet.')
    write(run / 'PR_BODY.ready.md', (ready.rstrip('\n') + '\n').encode())
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=['prepare', 'verify'], required=True)
    parser.add_argument('--program-sha256', required=True)
    parser.add_argument('--source-freeze-sha256', required=True)
    parser.add_argument('--acceptance', type=Path, required=True)
    parser.add_argument('--acceptance-sha256', required=True)
    parser.add_argument('--prepared-run', type=Path)
    parser.add_argument('--prepared-receipt-sha256')
    args = parser.parse_args()
    need((args.phase == 'verify' and args.prepared_run is not None and args.prepared_receipt_sha256 is not None) or
         (args.phase == 'prepare' and args.prepared_run is None and args.prepared_receipt_sha256 is None),
         'Verify requires both prepared-run and its exact receipt hash; prepare requires neither')
    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')
    run = EXECUTIONS / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '_' + args.phase + '_' + uuid.uuid4().hex[:12])
    run.mkdir(parents=True, exist_ok=False)
    phase = 'source_guards'
    try:
        write(run / 'program.py', read(__file__))
        write(run / 'invocation.json', {'argv': sys.argv, 'interpreter': sys.executable,
            'python': sys.version, 'worktree': str(WORKTREE), 'base': BASE})
        payload, spec = source_guards(run, args)
        phase = args.phase
        result = prepare(run, args, payload, spec) if args.phase == 'prepare' else verify(run, args, payload, spec)
        phase = 'completed_' + args.phase
        print(json.dumps({'status': result['status'], 'run': str(run),
            'mathematical_predicates_executed': 0, 'root_publication_required': True}))
    except BaseException as exc:
        write(run / 'FAILURE.json', {'phase': phase, 'exception': repr(exc), 'traceback': traceback.format_exc(),
            'automatic_retry': False, 'partial_installed_files_and_prior_streams_preserved': True})
        raise
    finally:
        write(run / 'EVIDENCE_MANIFEST.json', {'phase': phase, 'self_excluded': True,
            'files': [{'path': str(p.relative_to(run)), **pin(p)} for p in sorted(run.rglob('*'))
                      if p.is_file() and p.name != 'EVIDENCE_MANIFEST.json']})


if __name__ == '__main__':
    main()
