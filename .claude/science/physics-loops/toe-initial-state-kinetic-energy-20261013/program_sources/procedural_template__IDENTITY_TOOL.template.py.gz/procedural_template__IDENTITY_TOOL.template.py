#!/usr/bin/env python3
"""Modulated-kinetic-energy archive/reconstruction identity only; zero mathematical predicates."""
from pathlib import Path, PurePosixPath
import difflib, gzip, hashlib, json, sys
AUDIT_TIMEOUT_SEC = 60
AUDIT_INPUT_PATHS = __DECLARED_INPUTS__
EXTRA_PINS = __EXTRA_PINS__
PACKET = '.claude/science/physics-loops/toe-modulated-kinetic-energy-20261013'
CLAIM = '__CLAIM__'
MAP_SHA = '__MAP_SHA__'
EDITS_SHA = '__EDITS_SHA__'
PARENTS_SHA = '__PARENTS_SHA__'
STATUS_SHA = '__STATUS_SHA__'
GRAPH_SHA = '__GRAPH_SHA__'
SOURCE_FREEZE_SHA = 'c32a537caaa2be0dd08cb45c3a1f9b07f0e1956db116e73b78b214f2ee330b92'
ROOT_ACCEPTANCE_SHA = '__ROOT_ACCEPTANCE_SHA__'
ROOT_REVIEW_SHA = '754fa7b9913c75b32665db816a3c9b6673172d1b8c2471e16acf19effddc555f'

def need(ok,message):
    if not ok: raise ValueError(message)
def sha(b): return hashlib.sha256(b).hexdigest()
def diff(a,b,old,new):
    return ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=old,tofile=new,n=3)).encode()
def verify(root):
    reads={}
    def read(name):
        p=PurePosixPath(name)
        need(not p.is_absolute() and '..' not in p.parts,'Unsafe declared input')
        path=root.joinpath(*p.parts)
        need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root),'Declared input missing or outside repository')
        if name not in reads: reads[name]=path.read_bytes()
        return reads[name]
    def pinned(name,digest,message):
        b=read(PACKET+'/'+name);need(sha(b)==digest,message);return json.loads(b)
    evidence=pinned('EVIDENCE_MAP.json',MAP_SHA,'Archive map changed')
    contents,origins={},{}
    for obj in evidence['objects']:
        need(obj['sha256'] not in contents,'Duplicate archive object')
        z=read(PACKET+'/'+obj['path'])
        need(sha(z)==obj['stored_sha256'] and len(z)==obj['stored_bytes'],'Compressed archive changed')
        b=gzip.decompress(z)
        need(sha(b)==obj['sha256'] and len(b)==obj['bytes'],'Archived source changed')
        contents[obj['sha256']]=b
        for origin in obj['origins']:
            need(origin['path'] not in origins,'Duplicate original alias');origins[origin['path']]=obj['sha256']
    contract=evidence['accepted_source_package'];prefix=contract['path']+'/'
    def archived(name):return contents[origins[name]]
    def source(name):return archived(prefix+name)
    need(contract['freeze_sha256']==SOURCE_FREEZE_SHA and sha(source('FINAL_FREEZE.json'))==SOURCE_FREEZE_SHA,'Accepted source freeze differs')
    seal=json.loads(source('FINAL_FREEZE.json'));members=contract['members']
    need(seal['files']==members and seal['file_count']==len(members)==174 and seal['total_files']==contract['all_files']==175,'Original membership differs')
    wanted={prefix+r['path'] for r in members}|{prefix+'FINAL_FREEZE.json'}
    need(len(wanted)==175 and {p for p in origins if p.startswith(prefix)}==wanted,'Source package aliases differ')
    for r in members:
        b=source(r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'] and len(b.splitlines())==r['lines'],'Source member identity differs')
    selection=json.loads(source('SOURCE_SELECTION.json'));selected={r['path']:r for r in selection['sources']};inputs=json.loads(source('INPUT_FREEZE.json'));selection_seal=json.loads(source('SOURCE_SELECTION_SEAL.json'))
    need(len(selected)==len(selection['sources'])==135 and sha(source('SOURCE_SELECTION.json'))==selection_seal['sha256']==inputs['source_selection_sha256'],'Source selection differs')
    need({r['archive_path'] for r in selected.values()}=={r['path'] for r in inputs['files']} and len(inputs['files'])==135,'Input membership differs')
    for r in selected.values():
        b=source(r['archive_path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'] and len(b.splitlines())==r['lines'],'Raw selected source differs')
    for r in inputs['files']:
        b=source(r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'] and len(b.splitlines())==r['lines'],'Input freeze identity differs')
    need(selection['closures']==evidence['source_provenance_closure'] and len(selection['closures'])==7 and selection['recursive_upstream_audit'] is False,'Immediate closure scope differs')
    counts=[]
    for closure in selection['closures']:
        receipt_path=closure['receipt'];receipt=json.loads(source(selected[receipt_path]['archive_path']));rows=[]
        if closure['kind']=='files':
            for r in receipt['files']:
                p=PurePosixPath(r['path']);rows.append((str(p if p.is_absolute() else PurePosixPath(receipt_path).parent/p),r))
        elif closure['kind']=='root_seal':
            for r in [receipt['primary']]+receipt['source_snapshots']:rows.extend((r[k],r) for k in ['source','snapshot'])
        elif closure['kind']=='modulated_refresh':
            for group in ['new_source_and_authorized_metadata','prior_freezes','prior_bound_files','reused_live_scientific_sources']:
                for r in receipt[group]:
                    need(r['expected_sha256']==r['sha256'],'Refresh disagreement');rows.append((r['path'],r))
        else:raise ValueError('Unknown immediate closure kind')
        need([p for p,r in rows]==closure['members'],'Immediate receipt members differ');counts.append(len(rows))
        for p,r in rows:
            need(all(r[k]==selected[p][k] for k in ['sha256','bytes','lines'] if k in r),'Immediate receipt binding differs')
    need(counts==[32,14,57,14,29,23,7],'Closure extents differ')
    oldroot='payload/.claude/science/physics-loops/toe-modulated-kinetic-law-20261013';mapping=json.loads(source('SOURCE_MAP.json'));assembled=b'';cores={}
    for part in mapping['pieces']:
        b=source(part['source_path']);need(sha(b)==part['sha256'] and len(b)==part['bytes'] and b.count(b'\n')==part['lines'],'Accepted piece identity differs')
        need(part['output_bytes_0_half_open']==[len(assembled),len(assembled)+len(b)] and part['output_lines_1_inclusive']==[assembled.count(b'\n')+1,(assembled+b).count(b'\n')],'Accepted piece boundary differs')
        if part['role']=='unchanged_scientific_core':cores[prefix+part['source_path']]=b
        assembled+=b
    accepted_path=mapping['artifact']['path'];need(assembled==source(accepted_path) and sha(assembled)==mapping['artifact']['sha256'],'Accepted note differs')
    need(len(cores)==1 and len(next(iter(cores.values())).splitlines())==464 and sha(next(iter(cores.values())))=='422a92a8a24daa8fa240251ccae041fcca737af0335a486f33f3b20de0fb665a','Core extent differs')
    source_notes={'modulated':{'path':accepted_path,'pieces':[{'kind':'core','path':p[len(prefix):]} for p in cores]}}
    for pair in json.loads(source('SOURCE_DIFFS.json'))['pairs']:
        need(source(pair['diff'])==diff(source(pair['old']),source(pair['new']),pair['old_label'],pair['new_label']),'Historical complete source diff differs')
    edits=pinned('PUBLICATION_EDITS.json',EDITS_SHA,'Publication transformation changed')
    need(edits['source_freeze_sha256']==SOURCE_FREEZE_SHA and edits['additional_mathematical_body_edits']==[] and len(edits['notes'])==1,'Publication scope differs')
    published,wrappers={},{}
    for note in edits['notes']:
        assembled=b'';order=[]
        need(sha(archived(note['accepted_candidate_path']))==note['accepted_candidate_sha256'] and note['additional_mathematical_body_edits']==[],'Accepted candidate differs')
        for piece in note['pieces']:
            if piece['kind']=='accepted_complete_core':
                b=cores[piece['source_path']];order.append(piece['source_path'])
                need(sha(b)==piece['source_sha256'] and piece['additional_mathematical_body_edits']==[] and piece['historical_status_and_exposure_bytes_preserved'] is True,'Core contract differs')
            else:
                need(piece['kind']=='publication_wrapper','Unknown publication piece');b=piece['text'].encode()
                need(piece['wrapper_path'] not in wrappers,'Duplicate wrapper');wrappers[piece['wrapper_path']]=b
            need(piece['byte_offset']==len(assembled) and piece['bytes']==len(b) and piece['sha256']==sha(b) and piece['first_line']==assembled.count(b'\n')+1 and piece['last_line']==(assembled+b).count(b'\n'),'Publication piece boundary differs')
            assembled+=b
        accepted=source_notes[note['key']]
        need(order==[prefix+p['path'] for p in accepted['pieces'] if p['kind']=='core'],'Core order differs')
        actual=read(note['note'])
        need(actual==assembled and len(actual)==note['published_bytes'] and sha(actual)==note['published_sha256'] and len(actual.splitlines())==note['published_lines'],'Published source does not reconstruct')
        published[note['note']]=actual
        need(note['context_lines']==3 and note['fromfile']==accepted['path'] and note['tofile']==note['note'],'Publication diff convention differs')
        z=read(PACKET+'/'+note['diff']);d=gzip.decompress(z)
        need(sha(z)==note['diff_stored_sha256'] and sha(d)==note['diff_sha256'] and d==diff(archived(note['accepted_candidate_path']),actual,note['fromfile'],note['tofile']),'Complete publication diff differs')
    for w in edits['wrapper_changes']:
        old,new=archived(w['source']),wrappers[w['publication']]
        need(sha(old)==w['source_sha256'] and sha(new)==w['publication_sha256'] and w['context_lines']==3,'Wrapper identity or diff convention differs')
        z=read(PACKET+'/'+w['diff']);d=gzip.decompress(z)
        need(sha(z)==w['diff_stored_sha256'] and sha(d)==w['diff_sha256'] and d==diff(old,new,w['fromfile'],w['tofile']),'Complete wrapper diff differs')
    correction=edits['required_wrapper_correction'];oldprefix=source(oldroot+'/pieces/note_prefix.md');newprefix=next(iter(wrappers.values()))
    oldtext=correction['old_exact'].encode();newtext=correction['new_exact'].encode()
    need(oldprefix.count(oldtext)==1 and newprefix.count(newtext)==1 and oldtext not in newprefix,'Required normalization repair differs')
    repair=read(PACKET+'/'+correction['standalone_diff'])
    need(sha(repair)==correction['diff_sha256'] and repair==diff(oldprefix,oldprefix.replace(oldtext,newtext),'original_wrapper_prefix','normalization_corrected_wrapper_prefix'),'Required correction diff differs')
    bindings=pinned('PARENT_BINDINGS.json',PARENTS_SHA,'Parent bindings changed');parents=bindings['parents']
    need(len(parents)==len({p['path'] for p in parents})==3,'Canonical parent membership differs')
    for p in parents:
        b=read(p['path']);need(sha(b)==p['published_sha256'] and len(b)==p['bytes'],'Canonical parent bytes changed')
    need(bindings['same_packet_parents']==[] and len(bindings['canonical_core_maps'])==4,'Canonical input map scope differs')
    for m in bindings['canonical_core_maps']:
        body=read(m['canonical_path']);core=archived(m['archive_alias']);a=m['byte_start_inclusive'];b=m['byte_end_exclusive']
        need(sha(body)==m['canonical_sha256'] and sha(core)==m['core_sha256'] and body.count(core)==1 and body[a:b]==core and len(core)==m['bytes'] and len(core.splitlines())==m['lines'],'Published parent core map differs')
        need(body[:a].count(b'\n')+1==m['line_start_inclusive'] and body[:b].count(b'\n')==m['line_end_inclusive'],'Canonical line map differs')
    need(bindings['standalone_hypotheses']['edges_created']==[],'Supplied M23 hypotheses gained an edge')
    for h in bindings['history_only_relations']:need(sha(archived(h['archive_alias']))==h['sha256'] and h['direct_edge'] is False,'History identity or scope differs')
    graph=pinned('CLAIM_REGISTRY_ADDITIONS.json',GRAPH_SHA,'Graph proposal changed')
    edges={(r['from'],r['to']) for r in graph['direct_edges']};nodes={n['claim_id']:n for n in graph['nodes']}
    need(len(nodes)==1 and len(edges)==len(graph['direct_edges'])==3 and edges=={(n['claim_id'],d) for n in nodes.values() for d in n['deps']} and CLAIM in nodes,'Graph proposal differs')
    need(graph['archived_proof_import_relations']==bindings['archived_provisional_relations'] and len(bindings['archived_provisional_relations'])==0,'Archived proof relations differ')
    for p in bindings['archived_provisional_relations']:
        need(sha(archived(p['archive_alias']))==p['sha256'] and set(p['owner_claim_ids'])<=set(nodes),'Provisional proof input or owner differs')
    need(graph['history_only_relations']==bindings['history_only_relations'] and len(graph['history_only_relations'])==3,'History/math relation split changed')
    status=pinned('SOURCE_REVIEW_STATUS.json',STATUS_SHA,'Review scope changed')
    acceptance=read(PACKET+'/MODULATED_KINETIC_LAW_ASSEMBLY_ROOT_DISPOSITION.json')
    need(sha(acceptance)==ROOT_ACCEPTANCE_SHA and sha(read(PACKET+'/MODULATED_KINETIC_LAW_ASSEMBLY_ROOT_REVIEW.md'))==ROOT_REVIEW_SHA,'Root source review changed')
    scope=json.loads(acceptance)
    need(scope==status['source_review_coverage_verbatim'] and scope['freeze_sha256']==SOURCE_FREEZE_SHA and len(scope['required_publication_repairs'])==1 and status['required_publication_copy_repair_applied'] is True and scope['publication_preparation_authorized'] is True and scope['publication_execution_approved_by_this_receipt'] is False and status['N1']==status['N5']=='pending' and status['no_go_packet_pass'] is False and status['new_independent_mathematical_review'] is False and status['fresh_full_final_core_manual_read'] is True,'Review coverage or pending scope changed')
    for name,p in EXTRA_PINS.items():
        b=read(name);need(sha(b)==p['sha256'] and len(b)==p['bytes'],'Additional publication integrity input changed')
    need(set(reads)==set(AUDIT_INPUT_PATHS) and len(AUDIT_INPUT_PATHS)==len(set(AUDIT_INPUT_PATHS)),'Declared read closure differs')
    return {'result':'source_identities_and_reconstruction_match','claim_id':CLAIM,'meaning':'Byte integrity only; no mathematical calculation, proof or audit executed.','mathematical_operations_executed':False,'mathematical_predicates_executed':0,'scientific_mutations_executed':0,'no_go_packet_pass_supplied_by_tool':False,'independent_review_supplied_by_tool':False,'external_scientific_input_reads':[p['path'] for p in parents],'package_local_integrity_reads':sorted(set(reads)-{p['path'] for p in parents})}
def main():
    print(json.dumps(verify(Path(__file__).resolve().parents[1]),sort_keys=True))
    print('per_element: checked and not executed — source integrity only; no coefficient or moment formula was verified.')
    print('per_site: checked and not executed — source integrity only; no CAR or cell-locality theorem was tested.')
    print('per_mode: checked and not executed — source integrity only; no dispersion, alias or endpoint estimate was computed.')
    print('per_block: checked and not executed — source integrity only; no graph norm, commutator or domain theorem was tested.')
    print('lattice_wide: checked and not executed — source integrity only; no all-time, driven, energy-law or no-go theorem was verified.')
if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'result':'identity_verification_incomplete','error':str(error),'mathematical_operations_executed':False,'mathematical_predicates_executed':0,'scientific_mutations_executed':0}),file=sys.stderr)
        raise SystemExit(1)
