# Interspecies current-rigidity publication composition

This is an author packaging record, not a new independent mathematical
review or audit. The source note, complete mathematical review, complete
Lean statement review and the original standard-library helper are frozen
and preserved. No repository, original source, boost source, editable prompt,
runtime or installed dependency was changed.

## Result and exact composition

- Candidate: FINAL_INTERSPECIES_CURRENT_RIGIDITY_NOTE.md, 713 lines,
  SHA-256 148340524d00ce17dd01d3cbe34bca01c7e1ea844021cd4c08c147b9450c30a7.
- Primary: interspecies_collision_current_rigidity_2026_10_11.py, 229 lines,
  SHA-256 3123877c48021d189d288245138a6b7cb0a321141d124ca0b733de8279d7fd12.
- Composition map: SOURCE_COMPOSITION.json,
  SHA-256 8f85461788616992bc48523951f7b010a20f1bcc7580504cc81f40ddad4441f0.

The canonical claim ID and accepted intended paths are
interspecies_collision_current_rigidity_bounded_theorem_note_2026-10-11,
docs/INTERSPECIES_COLLISION_CURRENT_RIGIDITY_BOUNDED_THEOREM_NOTE_2026-10-11.md
and scripts/interspecies_collision_current_rigidity_2026_10_11.py.
The evidence root is
.claude/science/physics-loops/toe-interspecies-rigidity-20261011/.
Current support is conditional-support, author status provisional.
The independent audit path alone decides effective retained status.

Original proof lines 57–513 become candidate lines 87–543 without any
byte change. This is every argument, hypothesis, adverse case and restriction
in Sections 2–9, including all 24 equation labels I1–I24, each still present
exactly once. The common fragment SHA-256 is
b03944cf7a90d984914e2b54949fb3c80af25689a636f56b68ce98b8174759c6.
No assertion from C1, candidate PR9476 or the excluded-walk results is added
as a mathematical premise.

Original source lines 1–56 are replaced by the new claim metadata, scope
summary and historical-provenance presentation in fragments/note_front.txt.
Original lines 514–551 are retained with exactly six recorded replacements:
the evidence heading, a phrase identifying the old run as the original
author run, and four evidence-link relocations. Original lines 552–559,
which anticipated an independent review, are replaced by the completed
review/evidence status and limits in fragments/note_tail.txt. That fragment
also gives the six-declaration Lean scope and preserves its exclusions.
All replaced original prose survives in the historical source copy.
No mathematical content is removed by those replacements.

The complete original executable helper body, lines 9–209, becomes primary
lines 24–224 without any byte change. Its common fragment SHA-256 is
b210856e6cf5464f91efa658641642ffdfe99f7f9022cee8e744aa381980d82b.
Only the original shebang/docstring/prefix is replaced with a scripts-style
scope, timeout/input declaration and assertion-enabled guard. A final
TOTAL line counts eight matrix families plus five algebraic families.
It does not count assertions, theorem obligations or independent evidence.
There is no dynamic-code wrapper, imported helper or nonstandard package.

SOURCE_COMPOSITION.json and reconstruct.py determine every output byte from
the archived originals and the four presentation fragments. Every original
Markdown file is stored as gzip with zero timestamp and its decoded hash;
all other selected evidence files retain their literal bytes. The package
preserves 82 historical files. Three compiled Lean objects are explicitly
omitted; no Lean runtime, mathlib installation or installed package is copied.
Historical wrappers retain their original absolute runtime paths as provenance
and are not claimed to be portable fresh-build instructions.

## Actual checks and evidence boundaries

The primary was executed once with Python 3.13.5 under a 30-second timeout:
exit 0, 0.072 seconds, no timeout, TOTAL: PASS=13 FAIL=0.
The full primary.log and primary_execution.json are preserved.
The replay's original output through its final original PASS line matches
the original author log byte for byte; its only extra output is TOTAL.
This is author-evidence replay. No new independent analytic proof, Lean
execution or source mutation is claimed.

The reconstruction command exited 0 and its entire output was read.
All four frozen evidence receipts were checked: 235 path/hash records
matched. The original proof, mathematical review, principal Lean source,
Lean statement review, helper, receipts and frozen boost note also matched
their specified guards. These identity checks establish preservation and
scope binding, not mathematical truth or authenticity of an entire runtime.
The original source/primary core equivalence and all equation-label counts
were checked independently of the prose scope summary.

The completed mathematical review at
78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6
and completed Lean statement review at
14d5a11bf7476975b8067fd5d9c7f9e91381804a1b926fb324ff5b9bfd57b519
are distinct frozen evidence. The latter did not rerun Lean. Its six finite
declarations do not cover anchor extraction, universal confinement and
propagation, the other exceptional-case branch, the shell argument,
integration, measure upgrade, cubic symmetry or the current corollary.
The publication does not broaden that formal scope.

The declared input of the self-contained primary is the canonical note as
the claim contract. Runtime execution reads no files or physical inputs.
Canonical cache generation, meaningful whole-primary semantic mutations,
repository conformance, publication-composition review and Git/publication
remain root integration tasks. This packet does not certify any of them.

## Reading coverage and source limits

Read completely during this composition: the 559-line mathematical source,
268-line mathematical review, 246-line Lean statement review, 209-line
author helper, 146-line principal Lean source, 91-line control source,
17-line axiom inventory, all four false-control sources, statement map,
scope report, scoped obligations, author development log, runtime identity
and Lean wrappers. The original helper's full output, accepted principal,
positive-control and inventory output, the initial principal output, failed
positive-control output and all four false-case outputs were inspected.
The historical positive-control source difference was inspected exactly.
Receipt scopes and executions were read structurally and all declared
path/hash bindings in the four receipts were verified, without treating
large truncated displays as completed evidence.

The independent mathematical review's full analytic and check-coverage
report was read; its separate helper and complete transitive library proof
implementation were not newly re-reviewed in this packaging task. The
historical C1 report/referee reading is reused at the unchanged exact
identities, and the complete snapshots are preserved. No fresh global
prior-art search, new literature theorem or candidate-PR certification
is asserted. Applicable methodology and workflow instructions were read
at the pinned b568c14df54a5e64f904f54f0251b2173f9302c3 revision; the task's
external-only scope excluded repository lifecycle actions.

The new header, footer, changed evidence presentation, primary prefix/tail,
assembler and reconstruction code were read completely. The unchanged
proof and primary bodies were covered by the complete original reading
plus byte-equivalence checks, not inferred from headings.

## Preserved failed evidence and development history

The original author helper and independent finite-control runs recorded
no failed formal executions. Their adverse fixtures are finite changed
inputs, not whole-primary source mutants.

The Lean packet preserves one failed positive-control development run:
a missing explicit Finset.univ argument caused a type error, unsolved goal
and printed sorryAx dependencies. That failed source is not accepted
evidence. The corrected control source changes exactly that invocation;
the principal source is unchanged by the repair. All four separate
known-false statements reach their intended mathematical False goals with
exit 1. They are not mutations of the principal Lean theorem.
The author scope report also retains the rejected runtime-identity command,
which created no process, and read-only discovery of an obsolete library
path before selecting an already installed import.

In this packaging task, one oversized instruction display was recovered
by separate complete reads. One attempted read of an illustrative walk
note at b568c14 found that path absent; no proof premise was inferred from
it. The first attempt to submit the new presentation fragments was rejected
by JavaScript parsing because of literal Markdown backticks; it executed
no file operation. The corrected submission succeeded. A cold read then
made one precision edit to the new Lean-scope prose, distinguishing the
residual theorem's explicit hypotheses from its two consequences. No
original source, mathematical equation or primary body changed.

## Remaining application and integration work

The physical shell-selection identity and full-support collision measure,
species/domain match, full affine span or valid individual cubic-domain
alternative, and the identification/conservation of J_s=E_s grad E_s
remain supplied application hypotheses. A positive common quadratic
coefficient needs the additional curvature/minimum condition; continuity
is needed for any stated extension across excluded points. There is no
current loss, collision clock, many-body closure or native gravity theorem.

The candidate is ready for root's source-bound composition check and
publication integration. Original historical review-pending wording is
preserved as history; the new note accurately records both completed
reviews without assigning retained or audit status.
