from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

S=Path(__file__).resolve().parent;W=S.parent/'rigidity_worktree'
P=W/'.claude/science/physics-loops/toe-interspecies-rigidity-20261011'
old=S/'interspecies_pre_stage_identity_manifest.json'
assert not old.exists();old.write_bytes((P/'SOURCE_IDENTITIES.json').read_bytes())
p=P/'DELIVERY_CHECKS.md';p.write_text(p.read_text()+'''
The first pre-stage inventory found one archived SOURCE_IDENTITIES.json omitted
by a filename-wide self-exclusion filter. The corrected filter excludes only
the current root manifest path. The earlier inventory is preserved, and the
full staged-path check is repeated; no mathematical source or cache changed.
''')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
editable=list(P.glob('*.md'))
for mode in ('fix','report-only'):
    prefix=S/('interspecies_precommit_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(prefix.with_suffix('.json'))]
      +[str(p.relative_to(W)) for p in editable],cwd=W,capture_output=True,text=True)
    prefix.with_suffix('.log').write_text(r.stdout+r.stderr);assert r.returncode==0
emap=json.loads((P/'EVIDENCE_MAP.json').read_text())
sources=[old,Path(__file__)]+[S/('interspecies_precommit_vocab_'+m+s) for m in ('fix','report-only') for s in ('.json','.log')]
for src in sources:
    raw=src.read_bytes();enc='identity' if src.suffix=='.json' else 'gzip'
    p=P/'evidence'/(src.name+('.gz' if enc=='gzip' else ''))
    assert not p.exists();p.write_bytes(gzip.compress(raw,mtime=0) if enc=='gzip' else raw)
    emap['records'].append({'source_path':str(src),'source_sha256':sha(src),'repository_path':str(p.relative_to(W)),
                            'encoding':enc,'stored_sha256':sha(p)})
(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
current=P/'SOURCE_IDENTITIES.json'
files=[W/r['publication_path'] for r in json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']]
files+=[W/'docs/audit/data/citation_graph_manifest.json']
files+=list((W/'logs/runner-cache').glob('interspecies*_2026_10_11.txt'))
files+=[p for p in P.rglob('*') if p.is_file() and p!=current]
rows=[]
for p in sorted(set(files)):
    row={'path':str(p.relative_to(W)),'sha256':sha(p)}
    if p.suffix=='.gz':row['decompressed_sha256']=hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()
    rows.append(row)
current.write_text(json.dumps({'base_revision':'a13caa4885f547c8d206265b031ba7649e539fd9',
 'scope':'Every final publication file except this current root manifest itself; historical manifests included.',
 'files':rows},indent=2)+'\n')
print('Corrected final publication file count:',len(rows)+1)
