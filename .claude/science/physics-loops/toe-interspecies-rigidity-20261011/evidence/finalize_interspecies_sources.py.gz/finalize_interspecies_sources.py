from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

S=Path(__file__).resolve().parent;W=S.parent/'rigidity_worktree'
P=W/'.claude/science/physics-loops/toe-interspecies-rigidity-20261011'
sha=lambda b:hashlib.sha256(b).hexdigest()
mp=P/'PUBLICATION_EDITS.json';mapping=json.loads(mp.read_text())
for row in mapping['outputs']:
    if row['publication_path']!='docs/INTERSPECIES_RIGIDITY_STABILITY_BOUNDED_THEOREM_NOTE_2026-10-11.md':continue
    p=W/row['publication_path'];body=p.read_text();assert sha(body.encode())==row['publication_sha256']
    old='independent_review: pending';new='independent_review: completed_for_frozen_S1_S31_source'
    assert body.count(old)==1;body=body.replace(old,new)
    row['edits'].append({'before':old,'after':new,'count':1})
    appendix='''
## 11. Completed source-bound review and publication controls

The complete independent review of S1–S31 is preserved at
`evidence/INTERSPECIES_RIGIDITY_STABILITY_REVIEW.md.gz` in this milestone,
SHA-256 `6fc511af23a82defd672c9c2c2febd7aa542604a9fbac25fd9e1438119504eee`.
Its receipt is `interspecies_rigidity_stability_review/receipt.json`,
SHA-256 `84be0fc8b21555b5000d99c8cf7cb91a1ffa7638f565a040039674da4b6b3cb9`.
The reviewer reconstructed every argument before inspecting author controls,
used a separate exact smooth-current example on a domain excluding the origin,
and requested no mathematical repair. It does not supply the physical premises.
Root read the complete source, review, helpers and raw outputs and verified
the final source bindings. The earlier pending-review source remains unchanged.

The publication primary preserves the entire executable mathematical helper
body. Its new metadata binds this note and the exact companion; generated
finite dual certificates use a temporary directory. The original full
certificates remain in the historical evidence. Its summary counts nine
finite control families, not proof obligations. Six actual whole-primary
mutations test the cycle sign, projection denominator, anchor-height cost,
wedge scale, potential factor two and cubic average. Their full sources and
logs are preserved separately from the four original author mutations.

The [delivery record](../.claude/science/physics-loops/toe-interspecies-rigidity-20261011/DELIVERY_CHECKS.md)
and exact publication map bind final canonical and repository checks. All
Sections 2–9, including S1–S31, retain the frozen source's mathematical bytes.
The scoped Lean packet covers exact finite geometry only; no Lean certificate
of the stability inequalities is claimed. No audit verdict is applied.
'''
    body+=appendix;row['appended_text']+=appendix;row['publication_sha256']=sha(body.encode());p.write_text(body)
mp.write_text(json.dumps(mapping,indent=2)+'\n')

(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete root composition check

The main-based milestone joins the complete exact I1-I24 argument, conditioned
stability S1-S31 and scoped Lean evidence. The exact publication candidate is
148340524d00ce17dd01d3cbe34bca01c7e1ea844021cd4c08c147b9450c30a7;
the stability source is61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a.
PUBLICATION_EDITS.json records every final presentation or primary change.
SOURCE_COMPOSITION.json first reconstructs the frozen external exact candidate.
These maps distinguish historical evidence from the final publication bytes.

Root read all559 original exact-source lines, its full209-line helper, complete
268-line independent review,188-line reconstruction, separate helper and full
outputs. The exact review uses actual quadratic collisions with distinct masses
and different anchor geometry; it is not author replay. Root verified the
source-bound receipts, including43 review bindings representing42 distinct files.
All mathematical proof bytes in original sections2-9 remain identical.

Root read all617 stability lines, the full262-line author helper, its complete
baseline and all four failure logs. Root reconstructed the initial four-cycle,
uniform triangle propagation, both exceptional tubes, equal-edge omissions,
wedge scaling, thin-image witness, path integrals and Hessian/cubic corollaries.
The complete288-line independent review,142-line separate smooth-current helper
and full output were then inspected; all28 final bindings match. This report
supports the stated conditional theorem without requiring a physical source
for the supplied tangent errors. No proof repair was requested.

Root also read the full six-declaration Lean module, eight positive controls,
all four false-statement controls, wrappers, scope maps, the final axiom
inventory, all compiler outcomes and the complete246-line statement review.
Accepted declarations use only propext,Classical.choice,Quot.sound. The original
failed control attempt with missing Finset.univ remains preserved; its printed
sorryAx is failed evidence, not an accepted theorem. Neither full analytic
rigidity nor the quantitative inequalities have been formalized here.

The frozen external composition reconstructs exactly. Its proof fragment hash
is b03944cf7a90d984914e2b54949fb3c80af25689a636f56b68ce98b8174759c6;
its executable exact-helper body hash is
b210856e6cf5464f91efa658641642ffdfe99f7f9022cee8e744aa381980d82b.
All final headers, footers, map edits and primary wrappers were read completely;
unchanged full arguments are reused only after exact byte comparison.

One meaningful finite-control defect was found by actual source mutation:
reversing the curl sign preserved rank six and a=0 in the original primary.
It therefore survived the original checks. Root appended six independent
symmetric matrix modes and checked their kernel membership. With the existing
rank this identifies the claimed finite kernel. The original helper body and
analytic proof remain unchanged. All seven final whole-primary mutants now
fail at intended mathematical assertions. The original survivor and the earlier
cross-product diagnostic-marker mismatch remain preserved. The latter was an
intended mathematical failure occurring earlier than the initial marker expected.

The stability primary changes only input/scope metadata, assertion-enabled
guard, temporary certificate-output directory and summary. All mathematical
helper functions and fixtures are identical. Its six actual primary mutants
fail at the intended assertions; two supplement the author's four by changing
the potential factor and cubic average. Root checked full source replacement
reconstruction and all complete raw logs. Canonical runs remain author-evidence
replay and do not establish independence or prove the continuum theorem.

Root wrote the publication packaging and added exact kernel control; this is
explicit composition work, not a new anonymous audit. Distinct source reviews
and the Lean statement review retain their precise authorship and scope. No
physical assumption, audit verdict, main branch or editable prompt was changed.
Global audit pipeline and strict audit lint remain independent landing gates.
''')
p=P/'REVIEW_HISTORY.md';t=p.read_text().replace('The new S1-S31 stability argument receives its own source-bound review;',
 'The new S1-S31 stability argument has its own completed source-bound review\nat6fc511af23a82defd672c9c2c2febd7aa542604a9fbac25fd9e1438119504eee;');p.write_text(t)

emap=json.loads((P/'EVIDENCE_MAP.json').read_text());records={r['repository_path']:r for r in emap['records']}
sources=[S/'INTERSPECIES_RIGIDITY_STABILITY_REVIEW.md',S/'interspecies_rigidity_stability_review_root_identity_check.json',
         S/'prepare_interspecies_milestone.py',S/'finalize_interspecies_sources.py']
sources += [p for p in (S/'interspecies_rigidity_stability_review').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for src in sources:
    data=src.read_bytes();enc='identity' if src.suffix=='.json' else 'gzip'
    dst=P/'evidence'/(str(src.relative_to(S))+('.gz' if enc=='gzip' else ''))
    dst.parent.mkdir(parents=True,exist_ok=True);raw=gzip.compress(data,mtime=0) if enc=='gzip' else data
    dst.write_bytes(raw);records[str(dst.relative_to(W))]={'source_path':str(src),'source_sha256':sha(data),
        'repository_path':str(dst.relative_to(W)),'encoding':enc,'stored_sha256':sha(raw)}
emap['records']=[records[k] for k in sorted(records)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
# Vocabulary is a pre-commit source gate; frozen historical Markdown is gzipped.
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in mapping['outputs'] if r['kind']=='note']
for mode in ('fix','report-only'):
    target=S/('interspecies_source_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(target.with_suffix('.json'))]
        +[str(p.relative_to(W)) for p in editable],cwd=W,capture_output=True,text=True)
    target.with_suffix('.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
for row in mapping['outputs']:
    body=Path(row['source_path']).read_text()
    for e in row['edits']:
        assert body.count(e['before'])==e.get('count',1);body=body.replace(e['before'],e['after'])
    body+=row['appended_text']
    assert body==(W/row['publication_path']).read_text()
    assert sha(body.encode())==row['publication_sha256']
print(json.dumps({'four_final_sources_exactly_reconstructed':True,'frozen_extra_evidence_files':len(records),
                  'source_hashes':[{r['publication_path']:r['publication_sha256']} for r in mapping['outputs']]}))
