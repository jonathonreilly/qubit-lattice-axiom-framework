from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess
import sys
from urllib.parse import unquote

S=Path(__file__).resolve().parent;W=S.parent/'rigidity_worktree'
P=W/'.claude/science/physics-loops/toe-interspecies-rigidity-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(W/'scripts'));import runner_cache
mapping=json.loads((P/'PUBLICATION_EDITS.json').read_text())
old=json.loads(subprocess.check_output(['git','show','a13caa4885f547c8d206265b031ba7649e539fd9:docs/audit/data/citation_graph_manifest.json'],cwd=W))
manifest=W/'docs/audit/data/citation_graph_manifest.json';new=json.loads(manifest.read_text())
assert new['node_count']==old['node_count']+2 and new['edge_count']==old['edge_count']+1
assert all(new['nodes'][k]==v for k,v in old['nodes'].items())
assert set(new['nodes'])-set(old['nodes'])=={
 'interspecies_collision_current_rigidity_bounded_theorem_note_2026-10-11',
 'interspecies_rigidity_stability_bounded_theorem_note_2026-10-11'}
compat=json.loads((S/'interspecies_audit_compatibility.json').read_text())
assert compat['checked']==compat['control_failures']==compat['failures']==[]
(P/'DELIVERY_CHECKS.md').write_text('''# Interspecies milestone delivery

Two complete theorem notes package exact AB-only rigidity and conditioned
stability together. Their exact publication maps preserve every I1-I24 and
S1-S31 argument. All new frontmatter, scope/status prose, evidence links and
primary changes were read. ROOT_COMPOSITION_REVIEW.md records source-level
coverage and distinguishes preservation, analytic review and finite controls.

The exact argument's separate review and the new stability review are complete;
the latter is6fc511af23a82defd672c9c2c2febd7aa542604a9fbac25fd9e1438119504eee.
Root inspected their full arguments, distinct helpers and complete outputs.
Both retain physical shell-selection, domain/current and approximation premises.
The six principal finite-geometry Lean declarations and eight positive controls
compiled with standard logical axioms and received independent statement/evidence
inspection. The full analytic theorem and quantitative inequalities are not
Lean verified. Compiler failures and all adverse source examples are preserved.

The exact canonical primary finished with exit0, empty stderr and14 finite
control families in0.135134935 seconds under a30-second timeout. The stability
primary finished with exit0, empty stderr and9 families in0.433321953 seconds
under a120-second timeout. Both cache and declared input identities are fresh.
The runtime was Python3.13.5; the stability primary used SymPy1.14.0. Its
computed certificates go to a temporary directory; full original certificates
are preserved in the evidence packet. These are finite exact checks, not
continuum proofs or independently discovered empirical facts.

All seven exact-primary and six stability-primary semantic mutants fail at
intended mathematical assertions. Root verified the complete changed-source
copies and log identities and inspected every full outcome. The original wrong
curl-sign survivor is preserved. Adding six independent symmetric kernel modes
repaired that finite test without changing the analytic proof or old helper body.
The stability mutations include both wrong scaling factors and current/potential
normalizations. Four separate false Lean statements are a different control
scope; they are not principal-source mutants. No success count substitutes
for scope or independent mathematical reconstruction.

The final citation build has6,871 nodes,15,419 edges and4,566 attached runners.
The deterministic manifest adds two nodes and one dependency edge; all old
nodes are unchanged. Focused changed-audit-evidence compatibility selects no
applied audit rows and reports no failures. The global combined audit pipeline
and strict audit lint were not run and remain independent landing gates.
No audit verdict or effective retained status is applied by this publication.

Final source reconstruction, ordinary links, syntax, all frozen-copy identities,
vocabulary correction/report and cache freshness are checked in the preserved
delivery evidence. SOURCE_IDENTITIES.json binds every publication file except
itself. Explicit index/worktree hashes and whitespace are checked before commit.
The local OPEN decision groups exact and quantitative work in one milestone.
This branch is based directly on main a13caa4885f547c8d206265b031ba7649e539fd9;
it has no dependency on the transport or excluded-walk PR stack. No editable
prompt, physical axiom or main branch was changed.
''')
p=P/'STATE.yaml';p.write_text(p.read_text().replace('pr_status: preparation','pr_status: ready_for_regular_PR').replace(
 'next_action: finish_source_bound_review_and_delivery_then_regular_PR','next_action: open_regular_PR_after_final_staged_checks'))
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in mapping['outputs'] if r['kind']=='note']
for mode in ('fix','report-only'):
    target=S/('interspecies_final_vocab_'+mode)
    result=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(target.with_suffix('.json'))]
        +[str(p.relative_to(W)) for p in editable],cwd=W,capture_output=True,text=True)
    target.with_suffix('.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stdout+result.stderr

for row in mapping['outputs']:
    raw=gzip.decompress((P/row['preserved_source']).read_bytes()).decode()
    assert hashlib.sha256(raw.encode()).hexdigest()==row['source_sha256']
    for e in row['edits']:
        assert raw.count(e['before'])==e.get('count',1);raw=raw.replace(e['before'],e['after'])
    raw+=row['appended_text'];assert raw==(W/row['publication_path']).read_text()
    assert sha(W/row['publication_path'])==row['publication_sha256']
    if row['kind']=='primary':
        ast.parse(raw);assert runner_cache.cache_status(row['publication_path'])==runner_cache.cache_identity_status(row['publication_path'])=='fresh'
links=[]
for p in editable:
    prose=[];fenced=False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
    for target in re.findall(r'\]\(([^)\s]+)\)','\n'.join(prose)):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(str(p),target)
        links.append({'source':str(p.relative_to(W)),'target':target})

emap=json.loads((P/'EVIDENCE_MAP.json').read_text());records={r['repository_path']:r for r in emap['records']}
def preserve(src):
    raw=src.read_bytes();enc='identity' if src.suffix=='.json' else 'gzip'
    dst=P/'evidence'/(str(src.relative_to(S))+('.gz' if enc=='gzip' else ''))
    stored=gzip.compress(raw,mtime=0) if enc=='gzip' else raw
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():assert dst.read_bytes()==stored
    else:dst.write_bytes(stored)
    records[str(dst.relative_to(W))]={'source_path':str(src),'source_sha256':hashlib.sha256(raw).hexdigest(),
        'repository_path':str(dst.relative_to(W)),'encoding':enc,'stored_sha256':sha(dst)}
for name in ['finish_interspecies_delivery.py','interspecies_collision_current_rigidity_2026_10_11_canonical_execution.json',
 'interspecies_rigidity_stability_2026_10_11_canonical_execution.json','interspecies_graph_build.log','interspecies_audit_compatibility.json',
 'interspecies_source_vocab_fix.json','interspecies_source_vocab_fix.log','interspecies_source_vocab_report-only.json','interspecies_source_vocab_report-only.log',
 'interspecies_final_vocab_fix.json','interspecies_final_vocab_fix.log','interspecies_final_vocab_report-only.json','interspecies_final_vocab_report-only.log']:
    preserve(S/name)
for row in records.values():
    p=W/row['repository_path'];raw=p.read_bytes();assert sha(p)==row['stored_sha256']
    decoded=gzip.decompress(raw) if row['encoding']=='gzip' else raw
    assert hashlib.sha256(decoded).hexdigest()==row['source_sha256']
frozen=json.loads((P/'SOURCE_COMPOSITION.json').read_text())
for row in frozen['historical_files']:
    p=P/row['preserved_path'];assert sha(p)==row['stored_sha256']
    raw=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['original']['sha256']
mech={'four_sources_exactly_reconstructed':True,'two_caches_and_inputs_fresh':True,'ordinary_links':links,
      'frozen_exact_historical_files':len(frozen['historical_files']),'additional_evidence_files':len(records),
      'citation_delta':{'nodes':2,'edges':1},'old_graph_nodes_unchanged':True,'compatibility_failures':[],
      'scope':'Mechanical source/evidence binding, not an audit verdict or new proof.'}
out=S/'interspecies_delivery_mechanical.json';out.write_text(json.dumps(mech,indent=2)+'\n');preserve(out)
emap['records']=[records[k] for k in sorted(records)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in mapping['outputs']]+[manifest]
files += [W/'logs/runner-cache'/Path(r['publication_path']).with_suffix('.txt').name for r in mapping['outputs'] if r['kind']=='primary']
files += [p for p in P.rglob('*') if p.is_file() and p.name!='SOURCE_IDENTITIES.json']
identities=[]
for p in sorted(set(files)):
    row={'path':str(p.relative_to(W)),'sha256':sha(p)}
    if p.suffix=='.gz':row['decompressed_sha256']=hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()
    identities.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps({'base_revision':'a13caa4885f547c8d206265b031ba7649e539fd9',
    'scope':'Every final publication file except this manifest itself.','files':identities},indent=2)+'\n')
print(json.dumps({'publication_files':len(identities)+1,'ordinary_links':len(links),
                  'historical_exact_files':len(frozen['historical_files']),'additional_frozen_files':len(records),
                  'two_caches_fresh':True,'citation_delta':mech['citation_delta']}))
