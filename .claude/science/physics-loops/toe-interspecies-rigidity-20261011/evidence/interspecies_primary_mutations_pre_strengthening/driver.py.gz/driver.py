from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

S = Path(__file__).resolve().parent
source = Path(sys.argv[1]).resolve()
destination = S / sys.argv[2]
destination.mkdir(exist_ok=False)
body = source.read_text()
changes = [
    ('drop_anchor_edge', 'if (i, j) in omit:',
     'if (i, j) in omit or (i, j) == (1, 1):', 'n - actual_rank == expected'),
    ('reverse_cross_species_sign', 'row[3*(len(x)+j) + axis] = -value',
     'row[3*(len(x)+j) + axis] = value', 'dot(row, mode) == 0'),
    ('wrong_cross_product_component', '((0, dz, -dy), (-dz, 0, dx), (dy, -dx, 0))',
     '((0, dz, dy), (-dz, 0, dx), (dy, -dx, 0))', 'dot(row, mode) == 0'),
    ('wrong_cubic_invariance_sign', 'r[a][i]*r[b][j] - int(a == i and b == j)',
     'r[a][i]*r[b][j] + int(a == i and b == j)', 'rank(matrix_rows) == 8'),
    ('wrong_current_curl_sign', 'row[3+3*j+i] -= 1',
     'row[3+3*j+i] += 1', 'symmetric_current_modes'),
    ('wrong_collision_charge_sign', 'a[0]**3 + b[0]**3 - c[0]**3 - d[0]**3',
     'a[0]**3 + b[0]**3 - c[0]**3 + d[0]**3', 'defect == Q(3, 4)'),
    ('overlapping_cubic_orbit_balls', 'inner_radius = Q(1, 100)',
     'inner_radius = Q(1, 2)', 'distance2 > (4*inner_radius)**2'),
]
records = []
for name, old, new, intended in changes:
    assert body.count(old) == 1, (name, body.count(old))
    mutant = body.replace(old, new)
    p = destination/(name+'.py')
    p.write_text(mutant)
    t = time.monotonic()
    try:
        r = subprocess.run([sys.executable, str(p)], capture_output=True,
                           text=True, timeout=30)
        code, output = r.returncode, r.stdout+r.stderr
    except subprocess.TimeoutExpired as e:
        code = 124
        raw = e.stdout or b''
        output = raw.decode() if isinstance(raw, bytes) else raw
        output += '\nPROCESS TIMEOUT\n'
    log = destination/(name+'.log')
    log.write_text(output)
    records.append({'name': name, 'original_source': str(source),
                    'original_sha256': hashlib.sha256(body.encode()).hexdigest(),
                    'old': old, 'new': new, 'mutation_count': 1,
                    'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                    'log_path': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
                    'returncode': code, 'elapsed_seconds': time.monotonic()-t,
                    'timeout_seconds': 30, 'intended_assertion': intended,
                    'intended_failure': code == 1 and 'AssertionError' in output and intended in output,
                    'survived': code == 0})
    print(name, 'exit', code, 'intended', records[-1]['intended_failure'], flush=True)
(destination/'manifest.json').write_text(json.dumps(records, indent=2)+'\n')
print('All attempted outcomes preserved; inspect any survivor or unintended failure.')
