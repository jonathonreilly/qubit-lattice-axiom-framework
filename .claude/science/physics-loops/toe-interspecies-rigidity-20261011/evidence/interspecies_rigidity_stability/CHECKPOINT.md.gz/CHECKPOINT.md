# Current checkpoint — interspecies rigidity stability

Target: a uniform, explicitly conditioned stability version of the labeled
cross-species geometric theorem. Work is external only. The exact theorem,
independent review, Lean packet, and repository remain frozen.

Sources: INTERSPECIES_CURRENT_RIGIDITY_PROBE.md
ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8;
INTERSPECIES_CURRENT_RIGIDITY_REVIEW.md
78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6.
Both were read completely for this task. Initial source hashes are in
initial_sources.json. Applicable physics-loop source-bound derivation rules
are used; this bounded task does not authorize a campaign, repository mutation,
dependency update, publication, or audit verdict.

Main route: quantify the four-cycle with sigma_min[u,v,d], use wedge differences
to confine arbitrary residuals near the opposite anchor directions without
dividing by arbitrary cross-edge lengths, then split one extra B anchor by its
distance from the A anchor line. A normal-to-plane estimate handles the skew-line
case. Two noncollinear anchor triangles propagate the final uniform bound.
Candidate constant C <= 5586 (D/h)^2 (D/sigma)^5.

Alternatives: a finite constraint-matrix inverse gives a useful independent-form
control but is not the proof for arbitrary labeled sets. Dividing by the angle
from each arbitrary point to the opposite line fails uniformly near that line.
Initial four-cycle conditioning alone fails: a connected full-span thin-image
family has secant defect O(delta) and homothety error at least 1/6.

Completed: the full note proves the geometric bound, direct wedge variant,
integration with intrinsic path length, and a conditional approximate current
corollary using derivative-of-current secants. Every argument and the complete
262-line helper were read after drafting. The helper's first baseline exits 0;
four actual source mutants fail at their intended mathematical assertions.
Four exact dual-matrix certificates check finite configurations by a different
algebraic route. All 8 artifacts in the exact source receipt and all 53 in the
Lean receipt rehash unchanged.

This checkpoint and the final note/evidence are frozen by receipt.json.
Next decision: independent reconstruction of S1–S31, then matching actual
velocity-anchor and tangent-defect scales in an application. No new physical
law, automatic derivative control from charge defects, optimized constant,
or new Lean verification is claimed. No repository or editable prompt file
was changed by this task; no independent review or audit verdict is asserted.
