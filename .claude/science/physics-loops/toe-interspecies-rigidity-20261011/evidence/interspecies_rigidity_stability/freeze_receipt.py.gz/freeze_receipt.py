#!/usr/bin/env python3
"""One-time source/coverage freeze; this does not rerun or review mathematics."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import platform
import sys
import sympy

D = Path(__file__).resolve().parent
S = D.parent
NOTE = S/'INTERSPECIES_RIGIDITY_STABILITY_PROBE.md'
assert not (D/'receipt.json').exists()


def record(path, role):
    raw = path.read_bytes()
    return {'path':str(path), 'relative_to_S':str(path.relative_to(S)) if path.is_relative_to(S) else None,
            'role':role, 'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw),
            'logical_lines':len(raw.decode().splitlines()) if path.suffix not in ('.olean',) else None}


guards = []
for initial in json.loads((D/'initial_sources.json').read_text()):
    current = record(Path(initial['path']), 'initial frozen source guard')
    assert current['sha256'] == initial['sha256']
    guards.append(current)

prior_artifact_groups = []
for name in ['interspecies_current_rigidity/receipt.json', 'interspecies_rigidity_lean/receipt.json']:
    path = S/name
    prior = json.loads(path.read_text())
    checked = []
    for old in prior['artifacts']:
        current = record(Path(old['path']), 'prior packet artifact guard; not a fresh content review')
        assert current['sha256'] == old['sha256']
        checked.append(current)
    prior_artifact_groups.append({'receipt':str(path), 'receipt_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                                  'checked_artifacts':checked})

instruction_paths = [
    Path('/Users/jonreilly/.codex/skills/physics-loop/SKILL.md'),
    *[Path('/Users/jonreilly/.codex/skills/physics-loop/references')/x for x in
      ['DISCOVERY.md','CLAIM_STATUS.md','DELIVERY.md','proof-search-governance.md',
       'abstract-algebraic-core-extraction.md']],
    S.parent/'worktree/AGENTS.md',
    S.parent/'worktree/docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md',
    S.parent/'worktree/docs/ai_methodology/SCIENCE_WORKFLOW.md',
]
instructions = [record(p, 'applicable instruction read; fixed external scope overrides unrelated campaign actions')
                for p in instruction_paths]
checks = {'initial_source_guards':guards, 'prior_artifact_groups':prior_artifact_groups,
          'instructions':instructions, 'all_recorded_protected_artifacts_unchanged':True,
          'no_repository_or_prompt_edits_performed':True}
(D/'source_checks.json').write_text(json.dumps(checks,indent=2)+'\n')

baseline = json.loads((D/'runs/baseline01/execution.json').read_text())
assert baseline['exit_code'] == 0 and not baseline['timed_out']
assert hashlib.sha256((D/'stability_controls.py').read_bytes()).hexdigest() == baseline['source_sha256']
mutations = json.loads((D/'mutation_manifest.json').read_text())
assert all(r['intended_failure'] and r['exit_code'] == 1 and not r['timed_out']
           for r in mutations['mutants'])
for r in mutations['mutants']:
    root = D/'mutants'/r['name']
    assert hashlib.sha256((root/'stability_controls.py').read_bytes()).hexdigest() == r['source_sha256']
    assert hashlib.sha256((root/'full.log').read_bytes()).hexdigest() == r['log_sha256']

artifacts = [record(NOTE, 'complete authored conditional stability theorem and adverse examples')]
artifacts += [record(p, 'new helper, snapshot, exact certificate, log, command, checkpoint or source guard')
              for p in sorted(D.rglob('*')) if p.is_file() and p.name != 'receipt.json']
receipt = {
    'schema':'source_bound_authored_mathematics_receipt_v1',
    'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
    'task':'Explicit quantitative stability of labeled cross-species rigidity',
    'claim_type':'bounded_theorem', 'actual_current_surface_status':'conditional-support',
    'independent_review':'pending', 'audit_verdict':None,
    'selected_model_and_effort':'unchanged; no delegation',
    'strongest_statement':{
        'domain':'arbitrary labeled subsets of R3 with velocity diameter <= D',
        'conditioning':'six anchors, sigma_min[u,v,d]>=sigma; both third-anchor line heights>=h',
        'hypothesis':'normalized perpendicular cross-secant error <= epsilon on every nonzero cross edge',
        'conclusion':'one explicit lambda,b; all residuals <= C epsilon, C <= 5586(D/h)^2(D/sigma)^5',
        'wedge_variant':'uniform unnormalized wedge error omega gives residual <=2C omega/sigma',
        'exception_scope':'equal velocities, duplicate labels, arbitrary near/opposite-line positions; no minimum all-pair speed',
    },
    'conditional_interfaces':[
        'C1 integration with intrinsic path-distance factor',
        'current Hessian approximation requires secant control of DJ rows and the exact specified gradient current',
        'cubic profile additionally requires individual species scalar symmetry and invariant domains with finite intrinsic diameter',
        'small value defect implies derivative control only with a separately supplied curve scale and second-derivative bound',
    ],
    'counterexamples':[
        'connected bounded full-span images, fixed initial noncoplanarity: defect<=delta/2 but every homothety error>=1/6',
        'small sinusoidal charge amplitude with arbitrarily large regular-shell tangent derivative',
    ],
    'reading_coverage':{
        'frozen_exact_note':'complete 559-line source at its requested SHA256',
        'frozen_independent_review':'complete source at requested SHA256',
        'new_note':'entire argument S1-S31, then all changed formatting/evidence lines',
        'new_helper':'complete 262-line final source; no prior helper imported',
        'wrappers':'complete run_controls.py, run_mutants.py, freeze_receipt.py',
        'logs':'complete baseline and all four intended assertion-failure tracebacks',
        'rational_certificates':'generated exact matrix identity checked for every entry; no claim of manually reading every numeric entry',
        'old_receipts':'source/artifact identities inspected and rehashed; not a new full reading of old Lean/memory arguments',
        'truncation_recovery':'initial combined instruction display truncated; applicable reference text recovered in bounded calls',
    },
    'independence_limits':'Authored extension. Finite dual certificates use a different algebraic formulation, not a separate author/reviewer. Old exact review/Lean evidence does not certify new inequalities.',
    'proof_imports':'Elementary Euclidean linear algebra and integration only; no external theorem, physical primitive, or literature value imported.',
    'search_scope':'Bounded stored-local-ref search only; commands/results in bounded_search.json. No freshness or global novelty claim.',
    'failed_routes':'Pointwise angle division loses uniformity at exceptional lines; finite inverse alone hides conditioning; value-defect differentiation fails. No failed baseline process.',
    'baseline_execution':baseline, 'mutations':mutations,
    'runtime':{'python':sys.version,'sympy':sympy.__version__,'platform':platform.platform(),
               'installation_changes':False,'global_configuration_changes':False},
    'protected_sources':guards, 'prior_artifact_groups':prior_artifact_groups,
    'artifacts':artifacts,
    'remaining_obligations':['Independent check of S1-S31','Actual tangent-error and anchor conditioning at application scale',
                             'Physical/current/domain premises remain supplied','Constant optimality and new Lean formalization not claimed'],
    'receipt_self_hash':'reported externally; not included recursively',
}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for item in artifacts:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
for p in [NOTE,D/'stability_controls.py',D/'runs/baseline01/controls.log',D/'mutation_manifest.json',D/'receipt.json']:
    print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
print('artifact_records',len(artifacts),'prior_artifacts_guarded',sum(len(x['checked_artifacts']) for x in prior_artifact_groups))
