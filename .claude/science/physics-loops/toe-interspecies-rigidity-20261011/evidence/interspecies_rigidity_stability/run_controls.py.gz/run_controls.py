#!/usr/bin/env python3
"""Run a frozen snapshot with a 120-second process-group timeout."""
from pathlib import Path
import hashlib
import json
import os
import platform
import signal
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
run_id = sys.argv[1] if len(sys.argv) > 1 else 'baseline01'
assert run_id.replace('_','').isalnum()
out = base / 'runs' / run_id
out.mkdir(parents=True, exist_ok=False)
source = base / 'stability_controls.py'
snapshot = out / source.name
snapshot.write_bytes(source.read_bytes())
start = time.monotonic()
command = [sys.executable, str(snapshot)]
process = subprocess.Popen(command, cwd=out, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, text=True, start_new_session=True)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=120)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate()
log = stdout + ('\nSTDERR:\n'+stderr if stderr else '')
(out/'controls.log').write_text(log)
record = {'command':command, 'cwd':str(out), 'timeout_seconds':120,
          'timed_out':timed_out, 'exit_code':process.returncode,
          'elapsed_seconds':time.monotonic()-start,
          'python':sys.version, 'platform':platform.platform(),
          'source_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest()}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print(log)
sys.exit(process.returncode if not timed_out else 124)
