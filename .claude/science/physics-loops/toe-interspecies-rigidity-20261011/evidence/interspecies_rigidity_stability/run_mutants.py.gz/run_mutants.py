#!/usr/bin/env python3
"""Execute four actual source mutants; require intended assertion failures."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base/'stability_controls.py'
original = source.read_text()
expected = 'f468cc2d3e67ae7f1337ea859a1fe7579f719440e628954884f2e92b3752bc7f'
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
specs = [
    ('cycle_sign', '-l11+l21-l22+l12', '-l11+l21+l22-l12', 1,
     'assert (cycle - M*c).applyfunc(sp.expand) == ZERO'),
    ('projection_denominator', 'd11.T / norm2(d11)', 'd11.T', 2,
     'assert coeff * B == R'),
    ('drop_extra_anchor_height', 'rho, tau = D / sigma, D / h',
     'rho, tau = D / sigma, sp.Integer(1)', 1,
     'h conditioning cannot be dropped'),
    ('drop_wedge_inverse_scale', 'return 2 * C * omega / sigma',
     'return 2 * C * omega', 1,
     'wedge factor 1/sigma is necessary'),
]
records = []
for name, before, after, count, diagnostic in specs:
    assert original.count(before) == count
    directory = base/'mutants'/name
    directory.mkdir(parents=True, exist_ok=False)
    mutant = directory/'stability_controls.py'
    mutant.write_text(original.replace(before, after))
    command = [sys.executable, str(mutant)]
    start = time.monotonic()
    process = subprocess.Popen(command, cwd=directory, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, start_new_session=True)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
    full = stdout+'\nSTDERR:\n'+stderr
    (directory/'full.log').write_text(full)
    intended_failure = (not timed_out and process.returncode == 1
                        and 'AssertionError' in stderr and diagnostic in stderr)
    record = {'name':name, 'before':before, 'after':after, 'replacements':count,
              'command':command, 'cwd':str(directory), 'timeout_seconds':120,
              'timed_out':timed_out, 'elapsed_seconds':time.monotonic()-start,
              'exit_code':process.returncode, 'intended_failure':intended_failure,
              'expected_diagnostic':diagnostic,
              'source_sha256':hashlib.sha256(mutant.read_bytes()).hexdigest(),
              'log_sha256':hashlib.sha256((directory/'full.log').read_bytes()).hexdigest()}
    (directory/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    records.append(record)
    print(f'{name}: exit={process.returncode}, intended_failure={intended_failure}')
    print(stderr)
    assert intended_failure
(base/'mutation_manifest.json').write_text(json.dumps({
    'base_source_sha256':expected, 'mutants':records,
    'scope':'Four selected mathematical/source controls, not exhaustive mutation coverage.'
},indent=2)+'\n')
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
