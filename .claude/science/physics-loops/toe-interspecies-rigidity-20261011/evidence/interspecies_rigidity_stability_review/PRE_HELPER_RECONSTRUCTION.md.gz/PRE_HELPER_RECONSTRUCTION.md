# Independent reconstruction before author-helper inspection

Target: `INTERSPECIES_RIGIDITY_STABILITY_PROBE.md`, all 617 lines,
SHA256 `61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a`.
The proof and its descriptions of author controls were visible. No author
helper, log, snapshot, rational certificate, or receipt contents have been
opened. The receipt was only hashed against the supplied identity. This is
independent reconstruction from a visible proposed proof, not blind discovery.

The unchanged exact theorem and my prior full review were rehashed. I reread
the complete prior review and the necessary exact current interface I20–I24.
Prior I7–I15 coverage is reused only at the unchanged source identities.
No old Lean compilation is evidence for the new inequalities.

## Geometric obligations S1–S18

S2 implies every column of M has norm at least sigma, hence D >= sigma;
the two stated heights are <= D, hence D >= h. It also makes u,v independent
and d transverse to their span. The initial four edges have coefficient
vectors (0,0,-1), (1,0,-1), (0,-1,-1), (1,-1,-1) in M, so none vanishes.
Full affine span of each image supplies these six anchors: choose two A
points, one B point off their line, a second B point off their plane, and
a third point of each species off its own first line. The actual theorem
uses only the six finite conditions, not full affine span or measurability.

Translate x1 to zero for the cycle calculation. The four edges are -d,
u-d, u-v-d, -v-d. The identity (P1-Q1)-(P2-Q1)+(P2-Q2)-(P1-Q2)=0 has
coefficient vector c=(lambda22-lambda21,lambda12-lambda22,
-lambda11+lambda21-lambda22+lambda12) in M. Its error side has signs
-e11+e21-e22+e12. Thus |c| <= 4 epsilon/sigma. The two multiplier
differences used in the proof are c3-c2 and c1+c3, each <=8 epsilon/sigma.
With the explicit S5 lambda and b, r1=0, s1=-e11,
r2=(lambda21-lambda)(x2-y1)+e21+s1, and
s2=-(lambda12-lambda)(x1-y2)-e12. Their bounds are exactly S10.
Subtracting the homothety changes no perpendicular or wedge defect.

For arbitrary x and two opposite anchors with residuals <=eta, let
E=epsilon+eta. The wedge of r with each edge has norm <=D E, also when an
edge is zero: then its wedge is identically zero, without any constraint
on the missing charge difference. Subtracting wedges gives
|r cross q|<=2 D E. If r=alpha qhat+e with e perpendicular to q,
|e|<=2 rho E. The first wedge then gives
|alpha| ell_x<=D E+D|e| and hence S13. For ell_x>=sigma/4 the coefficient
is 2rho+4rho(1+2rho)=6rho+8rho^2=Z.

A third opposite anchor gives |r cross (z3-z1)|<=2 D E. Its height >=h
implies |alpha|h<=2 D E+D|e|. Adding |e| gives
T=2rho+2tau(1+rho), uniformly on lines, vertices, and near equal edges.
This divides by a fixed anchor difference and a fixed triangle height,
not the variable relative velocity or an arbitrary cross-edge angle.

After the original pair estimates every A residual is within
p=2rho B0 epsilon of span(V), every B residual within p of span(U).
If y3 is at least sigma/4 away from LX, S13 bounds s3 by Z B0 epsilon.
This also bounds the first B pair; the B triangle then gives S15 for all A.

In the remaining case take n perpendicular to span(u,v), oriented with
n dot d>0. Minimizing |d-au-bv| and applying S2 to (-a,-b,1) proves
n dot d>=sigma. If x is within sigma/4 of LY and y3 within sigma/4 of LX,
then n dot (x-y3)>=sigma/2. This edge is therefore nonzero even when
other selected or arbitrary cross edges vanish. Write
r=alpha V+e, s3=beta U+f, with |e|,|f|<=p. S3 supplies
r-s3=gamma(x-y3)+e_star, |e_star|<=epsilon.
The n component gives |gamma|<=2(2p+epsilon)/sigma, and consequently
|alpha V-beta U|<=(2rho+1)(2p+epsilon).
S2 on (-beta/|u|,alpha/|v|,0), with |u|,|v|<=D, bounds the left side
below by (sigma/D)sqrt(alpha^2+beta^2). Therefore
|r|<=p+rho(2rho+1)(2p+epsilon)<=W B0 epsilon,
where W=8rho^3+6rho^2+3rho. W>=Z for rho>=1, since
W-Z=rho(8rho^2-2rho-3)>=3rho.
This also covers A velocities outside the tube, already bounded by Z.

Thus R=max(T(1+ZB0),WB0) bounds all A residuals. The A triangle then
bounds every B residual by C=T(1+R); T>=1 also bounds all A. This is a
pointwise-in-label proof valid for infinite, disconnected, nonmeasurable,
and repeated label sets. Equal velocities impose no direct equation;
any same-velocity residual difference is nevertheless <=2C epsilon by
the proved common approximation. Epsilon=0 is covered without taking a
limit or dividing by epsilon.

For the simplified constant, T<=6tau rho, B0<=11rho, Z<=14rho^2,
W<=17rho^3. The two branches of R are <=930tau rho^4 and <=187rho^4,
respectively. Thus C<=6tau rho(1+930tau rho^4)<=5586tau^2 rho^5.
All inequalities use only rho,tau>=1, and no small-error assumption.

## Wedges, scales, and angular anchors S19–S21

S19 does not imply a normalized defect bound omega. Rerun the proof with
epsilon_star=2omega/sigma. Initial anchor lengths >=sigma give projection
errors <=omega/sigma. Every other arbitrary-edge step before S17 only
uses a wedge bound, and omega<=D epsilon_star is sufficient after adding
the known anchor residual. The only further normalized projection is the
tube-to-tube edge with length >=sigma/2. It has perpendicular defect
<=epsilon_star. No lower bound on all relative speeds has been assumed.
This proves the stated 2C omega/sigma estimate with the same S5 lambda,b.

Translation changes b to b-lambda times the translation. Under a positive
velocity dilation kappa, D,sigma,h scale by kappa, rho,tau,C stay fixed,
lambda scales by 1/kappa, and the P residuals are unchanged. Wedges scale
by kappa, compensating the inverse scaling of 1/sigma. This is distinct
from an anisotropic affine transform, which may change conditioning.

For S21, a/s=t<=1. The four off-pole points are on a circle of radius s,
so their mutual distances are <=2s. Their distances to the pole are
sqrt(s^2+a^2)<=sqrt(2)s; hence D=2s is valid. The squared heights are
s^2(s^2+2a^2)/(s^2+a^2) and a^2+s^2/2, at least s^2 and s^2/2.
Direct inversion of M gives ||M^-1||_F^2=3/(2s^2)+3/(4a^2), at most
9/(4a^2)<4/a^2. Therefore sigma=a/2 is valid, h=s/2 is conservative,
rho=4/t and tau=4. The resulting t^-5 upper bound is a property of this
constant and anchor family, not a universal physical or optimal exponent.

## Adverse family and scalar integration S22–S26

Both sets in S22 are connected compact unions of segments with full affine
span for every delta>0. They fit in coordinate ranges of lengths 1,2,2,
so diameter<=3. M for the fixed four-cycle is a coordinate permutation,
with sigma=1. The P values are continuous at intersections and zero on
the shared part of the two vertical segments. The only nonzero defects
occur for t>1 against a transverse B arm. Their magnitude is
(t-1)s delta/sqrt(t^2+s^2 delta^2)<=delta(t-1)/t<=delta/2.
For any homothety with uniform error eta, differences at 0,e1 give
|lambda|<=2eta; differences at e2,e2+2e3 give |1-2lambda|<=2eta.
The triangle inequality yields eta>=1/6. Thus fixed D and initial sigma,
qualitative full span, and connectedness do not supply a uniform stability
constant as the B transverse height collapses. This is a counterexample
to that specific uniform estimate, not necessity of the particular S2.

For C1 E_s,F_s on connected open O_s, S6 gives S24 directly. Subtract the
exact base-point value and integrate the gradient along a piecewise C1
path to obtain delta_g times its length; take the infimum for S25.
Connected open subsets of R3 are polygonally connected, so each intrinsic
distance is finite. Boundedness alone need not bound their intrinsic radius.

At a regular fixed-total-momentum pair the shell gradient is x-y. Unit
tangents in its q coordinate are perpendicular to x-y, and the derivative
of F_A(q)+F_B(K-q) is (P-Q) dot t. This is precisely S3. The high-frequency
example has all collision value defects <=2nu, yet at (0,e2) tangent e1
the derivative is nu*m. The value-error premise cannot replace S3.
For the separately assumed C2 shell curve, Taylor's integral remainder
bounds |r g'(0)| by nu+H r^2/2. Minimization gives sqrt(2nu H) only when
the positive optimizer sqrt(2nu/H) lies in the permitted interval. H=0
or nu=0 is handled by the unreduced bound or a limit, not division by zero.
Uniform curve length and curvature-sensitive second derivative control
are additional hypotheses, not consequences of local regularity alone.

## Actual-current implications S27–S31

Apply S6 to each row of DJ_s, using the supplied current
J_s=grad(E_s^2/2), not an unidentified current. It produces one common a
and B with row errors <=delta_g; each error matrix has Frobenius norm
<=sqrt(3)delta_g. E_s^2 in C2 makes DJ_s symmetric. Subtracting the skew
identity between the A anchor x1 and either x2 or x3 gives three skew
components bounded by 4delta_g, hence |a cross w|<=4sqrt(3)delta_g.
Writing a along u yields an orthogonal part <=4sqrt(3)delta_g/sigma;
the x3 height bounds its parallel coefficient by
4sqrt(3)delta_g(1+D/sigma)/h. Adding them proves S28 and its T/D form.

At x1, B_star=B+a x1^T is within sqrt(3)delta_g in Frobenius norm of its
symmetric part S. In fact the explicit S5 row choices make the x1 residual
zero, so B_star=DJ_A at the anchor exactly; the stated conservative estimate
is still correct. For arbitrary velocity v, |v-x1|<=D, whence
||DJ_s-S||_F<=|a|D+2sqrt(3)delta_g<=eta_J=2sqrt(3)(T+1)delta_g.
No derivative of any unknown value error is taken.

For a chosen base point, c_s=J_s(k_s)-S k_s makes the vector residual zero
there. Along a path parametrized by arclength r its magnitude is <=eta_J r.
Integration gives the first S30 bound. The gradient of E_s^2/2 minus the
quadratic/linear approximation is that same residual; integrating once more
gives eta_J L^2/2, hence eta_J L^2 for E_s^2. The constants are fixed at
the base point, not chosen separately for different paths or endpoints.

On a domain invariant under the proper cubic group, individual scalar
invariance gives J(Rk)=R J(k) and DJ(Rk)=R DJ(k)R^T. Apply S29 at Rk,
conjugate, and average to obtain ||DJ_s-beta I||_F<=eta_J with common
beta=tr(S)/3. Half-turns kill the off-diagonals and quarter-turns equalize
diagonals. For W=J-beta k, the orbit average of W at any fixed base point
is zero. Its derivative norm <=eta_J and intrinsic diameter <=L_s give
|W(k)-W(R k_s)|<=eta_J L_s, and averaging yields |W(k)|<=eta_J L_s.
Integrating grad(E_s^2-beta|k|^2)=2W gives 2eta_J L_s^2. The origin is
not required to be in O_s. Neither the sign nor a positive magnitude of
beta is forced by this approximate conclusion.

## Planned distinct check and current assessment

No mathematical repair has emerged from this reconstruction. A separate
exact smooth-current fixture will use E_A=2+|k|^2/2 and E_B=3+|k|^2/2
on the cubic-invariant annulus 1/2<|k|<3/2. Its velocities are k, its actual
currents E_s k, and its symmetric nonconstant Jacobians are
(M_s+|k|^2/2)I+k k^T. Six signed-axis anchors have controlled geometry and
include both species at every common velocity. A uniform cross-row defect
bound can be supplied directly without assuming a physical collision law.
The check will reconstruct the S5 row coefficients, cubic orbit averaging,
and the potential integration on an explicit path, with wrong-current and
wrong-integration discriminators. This differs from the author's described
finite cross-wedge dual certificates. It will not certify arbitrary-set
stability or provide a physical tangent-defect premise.
