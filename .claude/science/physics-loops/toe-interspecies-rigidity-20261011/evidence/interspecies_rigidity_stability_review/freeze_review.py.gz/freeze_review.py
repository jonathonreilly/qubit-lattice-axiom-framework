from pathlib import Path
import datetime,hashlib,json
R=Path(__file__).resolve().parent
S=R.parent
NOTE=S/'INTERSPECIES_RIGIDITY_STABILITY_REVIEW.md'
assert not (R/'receipt.json').exists()
assert not (R/'receipt_validation.json').exists()
def record(path,role):
    raw=path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'lines':len(raw.decode().splitlines()),'role':role}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pre=json.loads((R/'pre_helper_receipt.json').read_text())
verification=json.loads((R/'source_verification.json').read_text())
for group in verification['groups'].values():
    for row in group['records']:
        assert sha(row['path'])==row['expected_sha256'],row['path']
for row in pre['inputs']:
    assert sha(row['path'])==row['sha256'],row['path']
run=json.loads((R/'independent_execution.json').read_text())
assert run['exit_code']==0 and not run['timed_out']
assert sha(R/'smooth_current_control.py')==run['helper_sha256']
assert sha(R/'smooth_current_control.log')==run['log_sha256']
assert sha(run['runtime_executable'])==run['runtime_executable_sha256']
artifacts=[record(NOTE,'complete independent review S1-S31')]
artifacts += [record(p,'review reconstruction, independent check, full log, source verification, or freeze script') for p in sorted(R.iterdir()) if p.is_file()]
receipt={'schema':'bounded_independent_physics_review_receipt_v1','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'Independent source-bound review of quantitative interspecies rigidity stability','review_result':'No consequential mathematical defect identified in S1-S31; no source repair requested at target identity','target_sha256':'61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a','author_receipt_sha256':'5cdd8a3d902e1034f1ae81ac90f6cdec87d6b65b61d4b2781fbb8d3a249bc905','audit_verdict':None,'retained_status_granted':False,'native_law_or_physical_premises_verified':False,'model_and_reasoning':'inherited unchanged; no delegation','independence':{'reviewer_authored_target':False,'source_proof_and_control_descriptions_visible':True,'analytic_reconstruction_frozen_before_author_evidence':True,'independent_helper_first_execution_before_author_evidence':True,'author_helper_executed_or_imported':False,'old_exact_review_reused_at_unchanged_identity':True,'old_lean_not_recertification_of_new_inequalities':True,'author_baseline':'inspected as author consistency evidence only'},'coverage':{'new_note':'All 617 lines, S1-S31, including normalized/wedge variants, scale covariance, angular family, counterexample, derivative bridge and scalar/current integration','exact_source':'Prior full I1-I24 review reused at unchanged identity; complete prior report reread, and I20-I24 source interface reread','author_helper':'Complete 262-line source; baseline snapshot verified identical','author_logs':'Full baseline and all four intended assertion-failure logs; none rerun','author_wrappers':'Complete run_controls.py, run_mutants.py, freeze_receipt.py','author_receipt':'Complete JSON parsed and all 108 path/hash bindings checked; structured recovery of truncated raw display','rational_certificates':'All four parsed and coefficient row norms/finite bounds recomputed; no fresh full dual-identity replay or claim of manual inspection of every entry','historical_hashes':'Preservation checks only, not a new review of unrelated claims'},'independent_control':{'fixture':'Exact smooth two-species gradient current on an origin-excluding annulus; nonzero a and equal-velocity row differences','execution':run,'scope':'Selected actual-field consistency and adverse alternatives. Analytic reconstruction establishes universal theorem; definitional decomposition identity is bookkeeping only.','failed_independent_runs':0,'independent_source_mutant_processes':0,'dependency_installations':False},'author_evidence':{'receipt_bindings_verified':108,'receipt_distinct_paths':104,'source_checks_bindings_verified':77,'initial_guards_verified':5,'pre_helper_bindings_verified':18,'mutation_sources_exactly_match_manifest':True,'mutation_names':['cycle_sign','projection_denominator','drop_extra_anchor_height','drop_wedge_inverse_scale'],'all_mutations_fail_at_intended_assertion':True,'historical_failures_preserved':True},'application_obligations':['actual uniform tangent/Jacobian secant defect and conditioned anchors at desired scale','current identification and regularity','individual scalar cubic symmetry, invariant species domains and finite intrinsic diameter for radial conclusions','physical collision law and measure if required by intended application'],'inputs':pre['inputs'],'artifacts':artifacts,'mutations_performed':{'repository':False,'authored_sources':False,'prior_review_or_composition_packets':False,'editable_prompts':False,'external_messages':False},'receipt_self_hash':'reported externally, not embedded recursively'}
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
rows=[]
for group in ['inputs','artifacts']:
    for x in receipt[group]:
        actual=sha(x['path'])
        assert actual==x['sha256'],x['path']
        rows.append({'group':group,'path':x['path'],'expected_sha256':x['sha256'],'actual_sha256':actual,'matches':True})
validation={'validated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipt_path':str(R/'receipt.json'),'receipt_sha256':sha(R/'receipt.json'),'all_match':True,'binding_count':len(rows),'distinct_paths':len({r['path'] for r in rows}),'bindings':rows,'author_evidence_nested_bindings_also_rechecked':True}
(R/'receipt_validation.json').write_text(json.dumps(validation,indent=2)+'\n')
for p in [NOTE,R/'receipt.json',R/'receipt_validation.json',R/'source_verification.json',R/'smooth_current_control.py',R/'smooth_current_control.log']:
    print(json.dumps(record(p,'final identity')))
print(json.dumps({'final_receipt_bindings':len(rows),'all_match':True}))
