from pathlib import Path
import datetime,hashlib,json,platform,subprocess,sys,time
R=Path(__file__).resolve().parent
cmd=[sys.executable,str(R/'smooth_current_control.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.monotonic()
timed_out=False
try:
    p=subprocess.run(cmd,cwd=str(R),capture_output=True,text=True,timeout=90)
    log=p.stdout+p.stderr
    code=p.returncode
except subprocess.TimeoutExpired as ex:
    timed_out=True
    def decode(v): return v.decode() if isinstance(v,bytes) else (v or '')
    log=decode(ex.stdout)+decode(ex.stderr)
    code=None
elapsed=time.monotonic()-t0
(R/'smooth_current_control.log').write_text(log)
r={'command':cmd,'cwd':str(R),'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':90,'timed_out':timed_out,'elapsed_seconds':elapsed,'exit_code':code,'python':platform.python_version(),'runtime_executable':sys.executable,'runtime_executable_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((R/'smooth_current_control.py').read_bytes()).hexdigest(),'log_sha256':hashlib.sha256((R/'smooth_current_control.log').read_bytes()).hexdigest(),'author_helper_inspected_before_run':False,'first_execution':True}
(R/'independent_execution.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
print(log)
raise SystemExit(0 if code==0 and not timed_out else 1)
