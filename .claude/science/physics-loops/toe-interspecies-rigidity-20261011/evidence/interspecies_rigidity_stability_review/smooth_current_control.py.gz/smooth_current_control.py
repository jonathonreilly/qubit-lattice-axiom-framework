#!/usr/bin/env python3
"""Independent exact actual-current fixture; no author helper import.

Domain: 1/2 < |k| < 3/2, E_A=2+|k|^2/2, E_B=3+|k|^2/2.
The proof, including the continuum interval bounds, is in the review.
This checks a nonempty conditional example; it is not a physical law or
an exhaustive verification of the universal arbitrary-label theorem.
"""
from itertools import permutations, product
import json
import platform
import sympy as sp

Q=sp.Rational
k=sp.Matrix(sp.symbols('k1 k2 k3', real=True))
q=(k.T*k)[0]
I=sp.eye(3)
e=[I[:,i] for i in range(3)]
zero=sp.zeros(3,1)

def clean(M):
    return M.applyfunc(sp.simplify)

def at(M,point):
    return clean(M.subs(dict(zip(k,point)), simultaneous=True))

def sq(v):
    return sp.simplify((v.T*v)[0])

def frob_sq(M):
    return sp.simplify(sum(x*x for x in M))

def require(condition,label):
    assert condition, label
    print('CHECK '+label)

energies={name:sp.Integer(m)+q/2 for name,m in [('A',2),('B',3)]}
currents={name:sp.Matrix([sp.diff(E*E/2,x) for x in k]) for name,E in energies.items()}
jacobians={name:clean(J.jacobian(k)) for name,J in currents.items()}
for name,E in energies.items():
    require(clean(currents[name]-E*k)==zero, name+' actual E grad(E) current')
    require(clean(jacobians[name]-(E*I+k*k.T))==sp.zeros(3), name+' product-rule Jacobian')
    require(jacobians[name]==jacobians[name].T,name+' exact Hessian symmetry')
    # Removing E from the current breaks the actual potential-gradient identity.
    require(sq(at(currents[name]-k,e[0]))>0,name+' rejects velocity substituted for current')

X=[e[0],e[1],-e[2]]
Y=[e[2],-e[0],-e[1]]
u=X[1]-X[0]; v=Y[1]-Y[0]; d=Y[0]-X[0]
M=sp.Matrix.hstack(u,v,d)
require(frob_sq(M.inv())==Q(5,2),'anchor inverse Frobenius norm squared')
# ||M^-1||_2 <= sqrt(5/2) < 2 gives sigma=1/2.
require(frob_sq(M.inv())<4,'fixed sigma=1/2 is valid')
heights=[sp.simplify(sq((X[2]-X[0]).cross(u))/sq(u)),sp.simplify(sq((Y[2]-Y[0]).cross(v))/sq(v))]
require(heights==[Q(3,2),Q(3,2)],'both triangle squared heights exceed h^2=1')
# D=3 bounds all velocity differences on the annulus.  For each cross row:
# |M_A-M_B| + |q_k-q_l|/2 + |k_i k|+|l_i l| <= 1+1+9/4+9/4.
epsilon=sp.Integer(1)+(Q(9,4)-Q(1,4))/2+2*Q(9,4)
require(epsilon==Q(13,2),'uniform direct cross-row defect bound')
# Equal-velocity cross labels have a nonzero charge-gradient difference.
equal_difference=at(jacobians['A']-jacobians['B'],e[0])
require(equal_difference==-I,'equal-velocity pair has nonzero row differences')

edge=X[0]-Y[0]
P1=at(jacobians['A'],X[0]); Q1=at(jacobians['B'],Y[0])
a=sp.Matrix([sp.simplify((P1-Q1)[i,:].dot(edge)/sq(edge)) for i in range(3)])
B=P1-a*X[0].T
Bstar=B+a*X[0].T
S=clean((Bstar+Bstar.T)/2)
beta=sp.trace(S)/3
require(a==e[2],'S5 yields a genuinely nonzero a in this approximate example')
require(B!=B.T and Bstar==P1,'common B need not be symmetric before anchor shift')
require(S==sp.diag(Q(7,2),Q(5,2),Q(5,2)),'symmetric matrix reconstructed from actual anchor rows')
require(beta==Q(17,6),'common beta from the actual reconstructed S')
for name in energies:
    err=clean(jacobians[name]-a*k.T-B)
    require(clean(a*k.T+B+err-jacobians[name])==sp.zeros(3),name+' full row decomposition')
    # This comparison would fail if the nonzero a term were silently omitted.
    require(at(err+B-jacobians[name],e[1])!=sp.zeros(3),name+' rejects dropping a v^T term')

rotations=[]
for p in permutations(range(3)):
    for signs in product([-1,1], repeat=3):
        R=sp.zeros(3)
        for i in range(3): R[i,p[i]]=signs[i]
        if R.det()==1: rotations.append(R)
require(len(rotations)==24,'proper cubic rotations enumerated')
average=sum((R*S*R.T for R in rotations),sp.zeros(3))/24
require(average==beta*I,'actual anisotropic S averages to beta I')
for name,J in currents.items():
    W=J-beta*k
    orbit=sum((at(W,R*e[0]) for R in rotations),zero)/24
    require(orbit==zero,name+' orbit cancellation at nonzero base point')
    for R in rotations:
        require_cov=clean(at(J,R*k)-R*J)==zero
        require_jac=clean(at(jacobians[name],R*k)-R*jacobians[name]*R.T)==sp.zeros(3)
        assert require_cov and require_jac,(name,'cubic covariance')
    print('CHECK '+name+' actual current and Jacobian covariance for all 24 rotations')
    require(sq(at(W,e[0]))>0,name+' rejects exact beta k from nonzero defect premise')

# The exact Frobenius residual is a convex quadratic in q, so its maximum
# on the closed radial interval occurs at an endpoint.  The annulus is open.
z=sp.Symbol('z', real=True)
endpoint_bounds={}
for name,m in [('A',2),('B',3)]:
    b=sp.Integer(m)-beta
    norm_poly=3*b*b+5*b*z+Q(11,4)*z*z
    require(sp.simplify(frob_sq(jacobians[name]-beta*I)-norm_poly.subs(z,q))==0,name+' full radial Frobenius polynomial')
    require(sp.diff(norm_poly,z,2)>0,name+' endpoint reduction has positive second derivative')
    vals=[sp.simplify(norm_poly.subs(z,r)) for r in [Q(1,4),Q(9,4)]]
    require(all(x<16 for x in vals),name+' uniform annular derivative bound eta=4')
    endpoint_bounds[name]=list(map(str,vals))

# A path wholly inside the origin-excluding domain; constants fixed at k0.
r=sp.Symbol('r', nonnegative=True)
path=(1+r)*e[0]
L=Q(1,4)
path_rows={}
for name,E in energies.items():
    c=at(currents[name],e[0])-S*e[0]
    ebase=sp.simplify(E.subs(dict(zip(k,e[0])))**2-(e[0].T*S*e[0])[0]-2*c.dot(e[0]))
    residual=clean(at(currents[name],path)-S*path-c)
    exact_potential=sp.simplify(E.subs(dict(zip(k,path)))**2-(path.T*S*path)[0]-2*c.dot(path)-ebase)
    actual_integral=sp.integrate(residual.dot(e[0]),(r,0,L))
    endpoint=sp.simplify(exact_potential.subs(r,L))
    require(endpoint==2*actual_integral,name+' potential equals twice integral of actual residual')
    require(endpoint!=actual_integral,name+' rejects missing potential factor two')
    require(at(currents[name],e[0])-S*e[0]-c==zero,name+' fixed base-point current constant')
    path_rows[name]={'potential_error':str(endpoint),'integral_of_current_error':str(actual_integral),'c':list(map(str,c))}

# The origin is excluded; radius-1 radial/great-circle/radial paths have
# length < 1+pi < 5.  The orbit proof therefore supplies S31 with eta=4,L_s=5.
# No origin evaluation, conditional measure, or physical collision premise
# is required for that conditional approximation statement.
# Actual AB energy and momentum conservation does NOT conserve this current.
incoming=e[0]; outgoing=e[1]
energy_defect=sp.simplify(sum(E.subs(dict(zip(k,p))) for E,p in [(energies['A'],incoming),(energies['B'],-incoming)])-sum(E.subs(dict(zip(k,p))) for E,p in [(energies['A'],outgoing),(energies['B'],-outgoing)]))
current_defect=clean(at(currents['A'],incoming)+at(currents['B'],-incoming)-at(currents['A'],outgoing)-at(currents['B'],-outgoing))
require(energy_defect==0 and incoming-incoming==outgoing-outgoing,'actual regular AB rotation conserves energy and momentum')
require(current_defect==-e[0]+e[1],'same collision has nonzero actual current defect')
print(json.dumps({'python':platform.python_version(),'sympy':sp.__version__,'geometry':{'D':3,'sigma':'1/2','h':1,'heights_squared':list(map(str,heights))},'epsilon':str(epsilon),'a':list(map(str,a)),'beta':str(beta),'annular_frobenius_endpoint_squares':endpoint_bounds,'path':path_rows,'regular_collision_current_defect':list(map(str,current_defect))},indent=2))
print('COMPLETE: exact smooth-current fixture and adverse alternatives passed.')
