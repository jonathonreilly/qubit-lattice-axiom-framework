from pathlib import Path
import datetime,hashlib,json
import sympy as sp
S=Path(__file__).resolve().parent.parent
R=Path(__file__).resolve().parent
A=S/'interspecies_rigidity_stability'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def records(data,where='$'):
    out=[]
    if isinstance(data,dict):
        if 'path' in data and 'sha256' in data:
            out.append({'json_location':where,'path':data['path'],'expected_sha256':data['sha256']})
        if 'receipt' in data and 'receipt_sha256' in data:
            out.append({'json_location':where+'.receipt','path':data['receipt'],'expected_sha256':data['receipt_sha256']})
        for k,v in data.items(): out+=records(v,where+'.'+k)
    elif isinstance(data,list):
        for i,v in enumerate(data): out+=records(v,where+'['+str(i)+']')
    return out
expected={'target':(S/'INTERSPECIES_RIGIDITY_STABILITY_PROBE.md','61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a'),'author_receipt':(A/'receipt.json','5cdd8a3d902e1034f1ae81ac90f6cdec87d6b65b61d4b2781fbb8d3a249bc905')}
for role,(p,h) in expected.items(): assert sha(p)==h,(role,'source changed')
groups={}
for name,p in [('pre_helper',R/'pre_helper_receipt.json'),('author_receipt',A/'receipt.json'),('author_initial_sources',A/'initial_sources.json'),('author_source_checks',A/'source_checks.json')]:
    rows=records(json.loads(p.read_text()))
    for row in rows:
        row['actual_sha256']=sha(row['path'])
        row['matches']=row['actual_sha256']==row['expected_sha256']
        assert row['matches'],row
    groups[name]={'manifest_path':str(p),'manifest_sha256':sha(p),'record_count':len(rows),'distinct_paths':len({x['path'] for x in rows}),'records':rows}
source=(A/'stability_controls.py').read_text()
assert (A/'stability_controls.py').read_bytes()==(A/'runs/baseline01/stability_controls.py').read_bytes()
manifest=json.loads((A/'mutation_manifest.json').read_text())
mutation_checks=[]
for x in manifest['mutants']:
    d=A/'mutants'/x['name']
    execution=json.loads((d/'execution.json').read_text())
    assert execution==x
    assert source.count(x['before'])==x['replacements']
    expected_source=source.replace(x['before'],x['after'])
    assert (d/'stability_controls.py').read_text()==expected_source
    assert sha(d/'stability_controls.py')==x['source_sha256']
    assert sha(d/'full.log')==x['log_sha256']
    log=(d/'full.log').read_text()
    assert x['expected_diagnostic'] in log and 'AssertionError' in log
    assert x['exit_code']==1 and not x['timed_out'] and x['intended_failure']
    mutation_checks.append({'name':x['name'],'replacements':x['replacements'],'source_exactly_matches_declared_replacement':True,'execution_matches_manifest':True,'exit_code':x['exit_code'],'timeout_seconds':x['timeout_seconds'],'timed_out':x['timed_out'],'intended_diagnostic':x['expected_diagnostic']})
certificates=[]
for p in sorted((A/'runs/baseline01').glob('certificate_*.json')):
    c=json.loads(p.read_text())
    rows=c['residual_dual_coefficients']
    coeff=sp.Matrix([[sp.Rational(v) for v in row] for row in rows])
    l1=max(sum(abs(v) for v in coeff.row(i)) for i in range(coeff.rows))
    assert l1==sp.Rational(c['max_dual_row_l1'])
    assert 2*sp.Rational(c['D'])*l1==sp.Rational(c['finite_normalized_bound'])
    assert 2*l1==sp.Rational(c['finite_wedge_bound'])
    assert coeff.cols==len(c['basis_row_indices'])==len(c['basis_edge_components'])
    certificates.append({'path':str(p),'sha256':sha(p),'fixture':c['fixture'],'unknowns':c['unknowns'],'constraint_rows':c['constraint_rows'],'rank':c['rank'],'omitted_equal_edges':c['omitted_equal_edges'],'coefficient_shape':list(coeff.shape),'max_dual_row_l1':str(l1),'finite_normalized_bound':c['finite_normalized_bound'],'finite_wedge_bound':c['finite_wedge_bound'],'theorem_C':c['theorem_C'],'scope':'parsed complete rational data and recomputed coefficient norms; did not rerun author constraint identities or universal proof'})
r={'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':groups,'all_bindings_match':True,'baseline_source_identical_to_live_author_helper':True,'mutation_checks':mutation_checks,'rational_certificate_metadata':certificates,'no_author_helper_execution':True,'prior_hashes_are_preservation_checks_not_new_content_reviews':True}
(R/'source_verification.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'groups':{k:{'records':v['record_count'],'distinct_paths':v['distinct_paths']} for k,v in groups.items()},'mutation_checks':mutation_checks,'certificates':[{k:v for k,v in c.items() if k not in ['path','sha256','scope','omitted_equal_edges']} for c in certificates],'source_verification_sha256':sha(R/'source_verification.json')},indent=2))
