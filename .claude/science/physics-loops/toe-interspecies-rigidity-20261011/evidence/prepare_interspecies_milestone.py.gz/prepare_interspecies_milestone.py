from pathlib import Path
import gzip
import hashlib
import json
import shutil

S=Path(__file__).resolve().parent
W=S.parent/'rigidity_worktree'
P=W/'.claude/science/physics-loops/toe-interspecies-rigidity-20261011'
assert not P.exists()
P.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
# Preserve the author's complete exact-theorem composition and its 82 historical
# files, with historical status prose compressed instead of presented as live state.
for src in sorted((S/'interspecies_rigidity_publication').rglob('*')):
    if not src.is_file():continue
    rel=src.relative_to(S/'interspecies_rigidity_publication')
    if src.suffix=='.md':
        dst=P/(str(rel)+'.gz');data=gzip.compress(src.read_bytes(),mtime=0)
    else:dst=P/rel;data=src.read_bytes()
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)

mapping={'scope':'Final main-based exact/stability milestone; all proof text preserved with explicit source maps.', 'outputs':[]}
for name in ['PUBLICATION_EDITS.json','STABILITY_PUBLICATION_EDITS.json']:
    original=json.loads((S/'final_interspecies_root'/name).read_text())
    for row in original['outputs']:
        src=Path(row['source_path']);body=src.read_text()
        assert sha(src.read_bytes())==row['source_sha256']
        for e in row['edits']:
            assert body.count(e['before'])==e.get('count',1)
            body=body.replace(e['before'],e['after'])
        body+=row['appended_text']
        assert sha(body.encode())==row['publication_sha256']
        if row['publication_path'].endswith('INTERSPECIES_COLLISION_CURRENT_RIGIDITY_BOUNDED_THEOREM_NOTE_2026-10-11.md'):
            extra='''
The quantitative companion in this same milestone supplies a stability estimate
for the extension left open by Section 9 of this preserved exact argument.
Its explicit anchor conditioning and derivative-defect premises are separate
from the exact collision identity used here.
'''
            body+=extra;row['appended_text']+=extra;row['publication_sha256']=sha(body.encode())
        dst=W/row['publication_path'];assert not dst.exists();dst.write_text(body)
        row['preserved_source']='evidence/'+str(src.relative_to(S))+('.gz' if src.suffix!='.json' else '')
        mapping['outputs'].append(row)
(P/'PUBLICATION_EDITS.json').write_text(json.dumps(mapping,indent=2)+'\n')

texts={
'STATE.yaml':'''loop: toe-interspecies-rigidity-20261011
mode: milestone_snapshot
active_branch: physics-loop/toe-interspecies-rigidity-20261011
base_revision: a13caa4885f547c8d206265b031ba7649e539fd9
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
milestone: exact_and_conditioned_interspecies_rigidity_with_scoped_Lean
pr_status: preparation
next_action: finish_source_bound_review_and_delivery_then_regular_PR
live_checkpoint: ../toe-dynamics-bridge-20261009/STATE.yaml_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md':'''# Interspecies conservation and stability

Prove the common-coefficient step using only cross-species collisions, then
quantify its stability under explicit geometric conditioning and tangent errors.
Keep the mathematical theorem separate from supplying a physical collision law.
''',
'ASSUMPTIONS_AND_IMPORTS.md':'''# Premises

Exact: C1 charges and energies on connected open domains, full affine span of
both velocity images, and every local regular AB shell identity. Measure and
current consequences require their own full-support, continuity, current
identification, conservation and individual scalar-domain symmetry premises.

Approximate: six conditioned labeled anchors, finite velocity diameter and a
uniform normalized tangent or unnormalized wedge defect. Integration costs
intrinsic path length. The current corollary assumes derivative control for
the current components themselves; small charge values alone do not supply it.
Neither conclusion fixes a positive common quadratic coefficient.
''',
'OPPORTUNITY_QUEUE.md':'''# Subsequent questions

Supply a microscopic shell selection law and current identification for an
actual species construction. Prove uniform tangent defects and conditioning
at a chosen scale before applying stability. The active campaign separately
tests boost/current evolution and boost/rotation contact terms in a supplied
excluded walk. These questions are not premises imported into this milestone.
''',
'APPROACH_REGISTRY.md':'''# Proof routes

The exact route differentiates regular shells, solves a labeled bipartite
four-cycle, handles exceptional skew lines, propagates all labels and integrates.
The quantitative route conditions the cycle, controls both exceptional tubes,
uses two well-conditioned triangles and keeps derivative/path-length costs.
Independent reviews use distinct finite quadratic collisions and smooth
current examples. Finite tests supplement the universal arguments.
''',
'NO_GO_LEDGER.md':'''# Adverse findings

No framework no-go or exhaustive route closure is asserted. Collinear images,
deficient collision support and non-invariant regular domains delimit exact
hypotheses. Thin connected images defeat a uniform four-anchor-only bound;
oscillatory charges separate value defects from derivative defects. Preserve
these constructions and every failed control as scoped adverse evidence.
''',
'LITERATURE_BRIDGES.md':'''# Mathematical provenance

The elementary geometric and calculus arguments are self-contained. Historical
C1 at d009fb786d36a6cab4a7d410630b9382992faa08 motivated the missing AB-only
step but is not a mathematical dependency. No global novelty or literature
exhaustion claim is made. Scoped Lean uses pinned mathlib definitions and
ordinary kernel compilation; it does not formalize the analytic theorem.
''',
'ARTIFACT_PLAN.md':'''# Coherent milestone

Two theorem notes and their self-contained primaries package exact rigidity
and conditioned stability together. Canonical caches, scoped Lean sources and
compiler history, distinct reviews, source maps and actual primary mutants
accompany them. Historical evidence retains exact bytes, with gzip used where
noted. No runtime, dependency checkout or compiled Lean object is copied.
''',
'ROUTE_PORTFOLIO.md':'''# Independent evidence boundaries

The source-author controls are replay evidence. Separate exact and stability
reviews reconstruct the corresponding arguments and use distinct controls.
The Lean statement reviewer inspects accepted declarations, source and compiler
history but does not recompile. Root's composition check preserves those
scopes and strengthens one finite kernel test. None is an audit verdict.
''',
'TRACE_GATE.md':'''# Connection to the research target

```yaml
trace_class: direct_blocker_closure
reachability_to_target: partially_closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Prove and quantify the interspecies-only common-coefficient step."
source_of_blocker_text: historical_C1_and_exact_theorem_extension
```

The missing mathematical implication is proved under explicit conditions.
Matching an actual physical collision process to those conditions remains
separate. This milestone supplies no native gravity or many-body law.
''',
'CLAIM_STATUS_CERTIFICATE.md':'''# Claim status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
audit_required_before_effective_retained: true
bare_retained_allowed: false
conditional_surface_status: "Explicit shell, geometry, derivative and current premises."
hypothetical_axiom_status: null
admitted_observation_status: null
```

Original proofs are authorized. Lean is scoped proof-audit evidence, not a
requirement to await outside formal verification. Selective source checks and
author compilation do not assign effective retained status or adopt new axioms.
''',
'REVIEW_HISTORY.md':'''# Review history

The exact I1-I24 argument has a complete selective independent review at
78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6.
The six principal Lean declarations and eight positive controls have a separate
statement/evidence review at14d5a11bf7476975b8067fd5d9c7f9e91381804a1b926fb324ff5b9bfd57b519.
The new S1-S31 stability argument receives its own source-bound review; the old
exact review and Lean packet do not certify these inequalities.

Root read all proof text, necessary premises, controls and outputs. Exact
source reconstruction preserves mathematical bytes. An actual wrong-sign
primary mutation survived the original curl rank check; six explicit symmetric
kernel modes now distinguish it. The original survivor remains preserved.
The final delivery record binds subsequent review and conformance outcomes.
''',
'HANDOFF.md':'''# Fixed interspecies milestone snapshot

This isolated branch is based directly on main a13caa4885f547c8d206265b031ba7649e539fd9.
It combines exact and conditioned interspecies rigidity with narrowly scoped
Lean evidence. It has no excluded-walk or transport science dependency.
The campaign's single live recovery checkpoint remains in the transport
worktree at toe-dynamics-bridge-20261009/STATE.yaml and HANDOFF.md.
Follow DELIVERY_CHECKS.md and exact source maps for publication verification.
''',
'PR_BACKLOG.md':'''# Local milestone decision

OPEN — combine the exact theorem, quantitative extension and scoped Lean
evidence in one reviewable main-based milestone.

The complete mathematical sources, controls and raw outputs were read before
this decision. The existing campaign PRs concern supplied stochastic transport
or the excluded walk's scattering and memory dynamics. They do not prove the
cross-species-only collision-invariant classification. The historical C1
proposal explicitly left that step open. This result supplies a common energy
and momentum coefficient from regular AB collisions, with no AA or BB identity.
The proof retains labels and equal velocities, covers the exceptional skew-line
configurations, and states the measure and current conditions separately.

The quantitative extension adds a usable error interface. Merely perturbing
the initial four-cycle would leave unbounded constants near exceptional lines.
The full proof controls both tubes and identifies the additional anchor
conditioning needed for a uniform estimate over arbitrary label sets. It then
tracks the units of wedge errors, intrinsic path lengths and the separate
derivative assumptions for approximate current rigidity. A continuous thin-image
counterexample and an oscillatory-charge example preserve the limits of those
conclusions. These are substantive additions to the exact theorem, so both
are packaged together rather than issued as successive corollary PRs.

The Lean component verifies six universal finite-geometry steps with explicit
scope and preserved failed development history. It does not replace the
analytic proof or formalize the stability inequalities. Distinct source reviews,
complete controls and whole-primary mutations support the milestone's review
value; PASS counts and source-author replay are not independent mathematics.
The OPEN decision does not assign retained status or adopt a physical law.
Actual collision selection, current identification, scale-dependent conditioning
and approximation errors remain application obligations. The next campaign
work attacks those interfaces while this regular PR remains available for review.
'''
}
assert len(texts)==14
for name,text in texts.items():(P/name).write_text(text)

records=[]
paths=[S/'FINAL_INTERSPECIES_CURRENT_RIGIDITY_NOTE.md',S/'interspecies_collision_current_rigidity_2026_10_11.py',
       S/'INTERSPECIES_RIGIDITY_STABILITY_PROBE.md',S/'strengthen_interspecies_publication.py',
       S/'prepare_interspecies_stability_publication.py',S/'run_interspecies_primary_mutants.py',
       S/'interspecies_rigidity_stability_root_identity_check.json']
for directory in ['interspecies_rigidity_stability','interspecies_primary_mutations_pre_strengthening',
                  'interspecies_primary_mutations','interspecies_stability_primary_mutations','final_interspecies_root']:
    paths.extend(p for p in (S/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for src in sorted(set(paths)):
    raw=src.read_bytes();enc='identity' if src.suffix=='.json' else 'gzip'
    dst=P/'evidence'/(str(src.relative_to(S))+('.gz' if enc=='gzip' else ''))
    dst.parent.mkdir(parents=True,exist_ok=True)
    data=gzip.compress(raw,mtime=0) if enc=='gzip' else raw
    dst.write_bytes(data)
    records.append({'source_path':str(src),'source_sha256':sha(raw),'repository_path':str(dst.relative_to(W)),
                    'encoding':enc,'stored_sha256':sha(data)})
(P/'EVIDENCE_MAP.json').write_text(json.dumps({'scope':'Supplement to the exact composition historical-file map.', 'records':records},indent=2)+'\n')
print(json.dumps({'snapshot_files':len(texts),'additional_frozen_files':len(records),'publication_sources':len(mapping['outputs'])}))
