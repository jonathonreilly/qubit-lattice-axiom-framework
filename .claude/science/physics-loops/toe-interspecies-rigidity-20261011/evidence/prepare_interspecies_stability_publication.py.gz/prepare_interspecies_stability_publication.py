from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
D = S/'final_interspecies_root'
sha = lambda b: hashlib.sha256(b).hexdigest()
source = S/'INTERSPECIES_RIGIDITY_STABILITY_PROBE.md'
helper = S/'interspecies_rigidity_stability/stability_controls.py'
assert sha(source.read_bytes()) == '61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a'
assert sha(helper.read_bytes()) == 'f468cc2d3e67ae7f1337ea859a1fe7579f719440e628954884f2e92b3752bc7f'
note = source.read_text()
primary = helper.read_text()
edits = {'note': [], 'primary': []}

def change(kind, body, old, new, count=1):
    assert body.count(old) == count, (kind, old, body.count(old))
    edits[kind].append({'before': old, 'after': new, 'count': count})
    return body.replace(old, new)

note = change('note', note, '---\ntitle:', '''---
claim_id: interspecies_rigidity_stability_bounded_theorem_note_2026-10-11
runner: scripts/interspecies_rigidity_stability_2026_10_11.py
status: provisional
claim_scope: "Uniform quantitative homothety control under explicit six-anchor conditioning and normalized tangent or wedge defects; conditional integration and current consequences."
upstream_dependencies:
  - interspecies_collision_current_rigidity_bounded_theorem_note_2026-10-11
target_claim_type: bounded_theorem
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Quantify the interspecies invariant step under approximate conservation."
source_of_blocker_text: companion_exact_theorem_open_extension
conditional_surface_status: null
hypothetical_axiom_status: null
admitted_observation_status: null
audit_required_before_effective_retained: true
promotion_path: "Source-bound independent review and the independent audit path; separately prove physical tangent-defect and conditioning premises."
title:''')
note = change('note', note, '(INTERSPECIES_CURRENT_RIGIDITY_PROBE.md)',
              '(INTERSPECIES_COLLISION_CURRENT_RIGIDITY_BOUNDED_THEOREM_NOTE_2026-10-11.md)')
note = change('note', note, '(INTERSPECIES_CURRENT_RIGIDITY_REVIEW.md)',
              '(../.claude/science/physics-loops/toe-interspecies-rigidity-20261011/historical/INTERSPECIES_CURRENT_RIGIDITY_REVIEW.md.gz)')
note = change('note', note, '[Exact theorem]', '[Exact theorem; frozen source identity below]')
note = change('note', note, 'The author also authored the exact source.',
              'The linked exact publication preserves the mathematical source at the hash\nabove; the hash identifies that frozen source, not its new presentation.\nThe author also authored the exact source.')
for target in ('stability_controls.py', 'runs/baseline01/controls.log',
               'runs/baseline01/execution.json', 'mutation_manifest.json', 'receipt.json'):
    note = change('note', note, '('+'interspecies_rigidity_stability/'+target+')',
                  '(../.claude/science/physics-loops/toe-interspecies-rigidity-20261011/evidence/interspecies_rigidity_stability/'+target+('.gz' if target.endswith(('.py','.log')) else '')+')')
note = change('note', note,
'''The extension awaits a separate
independent check; the exact source's prior review does not certify this new
proof, and the old Lean compilation does not verify these inequalities.''',
'''The source-bound independent stability review is recorded in the milestone
delivery packet; the exact source's earlier review does not certify this new
proof, and the old Lean compilation does not verify these inequalities.''')

old_prefix = primary[:primary.index('from itertools import')]
new_prefix = '''#!/usr/bin/env python3
"""Exact finite controls for conditional six-anchor interspecies stability.

Uses SymPy and fixed rational/symbolic fixtures; no network or physical input.
The unchanged mathematical control body writes its finite dual certificates
only into a temporary directory. Historical full certificates are preserved
in the milestone evidence. These controls are author replay, not independent
continuum proof or scoped Lean verification. TOTAL counts nine control
families, not individual assertions or mathematical proof obligations.
"""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "docs/INTERSPECIES_RIGIDITY_STABILITY_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/INTERSPECIES_COLLISION_CURRENT_RIGIDITY_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]
if not __debug__:
    raise RuntimeError("Run without -O: exact control assertions must be enabled")

'''
primary = change('primary', primary, old_prefix, new_prefix)
primary = change('primary', primary, 'import sympy as sp', 'import sympy as sp\nimport tempfile')
primary = change('primary', primary, 'HERE = Path(__file__).resolve().parent',
                 '_certificate_workspace = tempfile.TemporaryDirectory(prefix="toe-rigidity-control-")\nHERE = Path(_certificate_workspace.name)')
primary = change('primary', primary, "if __name__ == '__main__':\n    main()\n",
                 "if __name__ == '__main__':\n    main()\n    print('TOTAL: PASS=9 FAIL=0')\n")
proof = note[note.index('## 2. Quantified'):note.index('## 10. Proof obligations')]
original = source.read_text()
assert proof == original[original.index('## 2. Quantified'):original.index('## 10. Proof obligations')]
body = helper.read_text()[helper.read_text().index('Q = sp.Rational'):helper.read_text().index("if __name__ == '__main__':")]
assert primary.count(body) == 1
note_name = 'FINAL_INTERSPECIES_RIGIDITY_STABILITY_NOTE.md'
primary_name = 'interspecies_rigidity_stability_2026_10_11.py'
for name, content in [(note_name,note),(primary_name,primary)]:
    dst=D/name
    if dst.exists(): assert dst.read_text()==content
    else: dst.write_text(content)
mapping={'scope':'Exact preservation of all S1-S31 proof text and executable mathematical helper body; presentation, input metadata and temporary certificate output only.',
         'proof_sha256':sha(proof.encode()),'helper_body_sha256':sha(body.encode()),'outputs':[]}
for kind, src, name, content, rel in [
    ('note',source,note_name,note,'docs/INTERSPECIES_RIGIDITY_STABILITY_BOUNDED_THEOREM_NOTE_2026-10-11.md'),
    ('primary',helper,primary_name,primary,'scripts/'+primary_name)]:
    mapping['outputs'].append({'kind':kind,'source_path':str(src),'source_sha256':sha(src.read_bytes()),
        'edits':edits[kind],'appended_text':'','publication_path':rel,'publication_sha256':sha(content.encode())})
(D/'STABILITY_PUBLICATION_EDITS.json').write_text(json.dumps(mapping,indent=2)+'\n')
print(json.dumps({'proof_unchanged':True,'helper_math_unchanged':True,
                  'note_sha256':sha(note.encode()),'primary_sha256':sha(primary.encode())}))
