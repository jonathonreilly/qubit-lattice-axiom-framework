from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

S = Path(__file__).resolve().parent
D = S / 'final_interspecies_root'
D.mkdir(exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
note_name = 'FINAL_INTERSPECIES_CURRENT_RIGIDITY_NOTE.md'
primary_name = 'interspecies_collision_current_rigidity_2026_10_11.py'
note = (S / note_name).read_text()
primary = (S / primary_name).read_text()
assert sha(note.encode()) == '148340524d00ce17dd01d3cbe34bca01c7e1ea844021cd4c08c147b9450c30a7'
assert sha(primary.encode()) == '3123877c48021d189d288245138a6b7cb0a321141d124ca0b733de8279d7fd12'
edits = {'note': [], 'primary': []}

def replace(kind, body, old, new):
    assert body.count(old) == 1, (kind, old)
    edits[kind].append({'before': old, 'after': new})
    return body.replace(old, new)

primary = replace('primary', primary,
    'TOTAL counts eight finite matrix families plus five additional algebraic\nfamilies,',
    'A root-added exact symmetric-family check follows the unchanged original\nbody. TOTAL counts eight finite matrix families plus six algebraic families,')
primary = replace('primary', primary,
'''# The preceding body reaches this line only after all original checks complete.
# Five additional families: skew determinant, cubic group, closed current,
# collision/support witness, and orbit-ball separation.
print(f"TOTAL: PASS={len(results) + 5} FAIL=0")
''',
'''# Identify the six-dimensional kernel itself, not just its dimension.
# A wrong curl sign can preserve rank and a=0 while replacing symmetry by
# antisymmetry off the diagonal. These six independent symmetric modes must
# all solve the original curl constraints.
symmetric_current_modes = []
for i in range(3):
    for j in range(i, 3):
        mode = [Q(0)] * 12
        mode[3+3*i+j] = 1
        mode[3+3*j+i] = 1
        symmetric_current_modes.append(mode)
assert rank(symmetric_current_modes) == 6
assert all(dot(row, mode) == 0 for row in curl_rows for mode in symmetric_current_modes)
print('closed-current symmetric family: six independent modes in kernel')

# Eight matrix families and six algebraic families, including this kernel check.
print(f"TOTAL: PASS={len(results) + 6} FAIL=0")
''')
note = replace('note', note, 'publication_composition_review: pending',
               'publication_composition_review: completed_with_root_control_strengthening')
note = replace('note', note,
'''in Sections 11–12; neither formalizes the full theorem. This publication
composition is new and awaits its own source-bound review.''',
'''in Sections 11–12; neither formalizes the full theorem. Root checked this
publication composition against the frozen sources and strengthened one
finite control after a deliberate wrong-sign mutation survived. The complete
mathematical argument is unchanged; Section 10 records that test limitation.''')
note = replace('note', note,
'''that force \\(a=0\\). They verify''',
'''that force \\(a=0\\). The publication also checks six independent symmetric
matrix modes in the kernel, identifying the full claimed symmetric family.
They verify''')
note = replace('note', note,
'''as the checked claim contract. Its summary counts thirteen completed finite
check families: eight matrix configurations and five additional algebraic
families. That count is not a count of proof obligations or assertions.
The external packaging replay and source-identity checks are recorded in the
publication receipt. Canonical-cache validation, whole-primary semantic
mutation runs, repository conformance and final publication are separate
integration work and are not certified here.''',
'''as the checked claim contract. Its summary counts fourteen completed finite
check families: eight matrix configurations and six algebraic families.
That count is not a count of proof obligations or assertions.

The frozen external packaging replay completed thirteen families. In root's
first seven whole-primary semantic mutations, changing the closed-current
curl sign survived: rank six and vanishing energy coefficient alone did not
distinguish symmetric from antisymmetric off-diagonal coefficients. The final
primary appends six explicit symmetric basis modes and checks their linear
independence and membership in the kernel. Together with the original rank,
these checks identify that finite kernel. The I1–I24 analytic proof and the
entire original helper body are unchanged. Both the surviving execution and
the strengthened-source mutation runs are preserved. They are finite tests,
not a replacement for the continuum argument or independent mathematical
review. The separate delivery record gives final canonical-cache,
mutation and repository-conformance outcomes.''')
note = replace('note', note,
'''`reconstruct.py` rebuilds the note and primary from those local fragments
and preserved originals; `receipt.json` records the actual external
composition checks. Gzip source copies decode to the exact historical
Markdown bytes, including obsolete pending-review text.''',
'''`reconstruct.py` rebuilds the frozen external note and primary from those
local fragments and preserved originals; `receipt.json` records the author's
external composition checks. `PUBLICATION_EDITS.json` then maps every root
publication edit to the final repository note and strengthened primary.
Gzip source copies decode to exact historical Markdown bytes, including
obsolete pending-review text. `ROOT_COMPOSITION_REVIEW.md` distinguishes
source preservation from mathematical review and documents the test repair.''')
footer = '''
## Publication delivery

The [delivery record](../.claude/science/physics-loops/toe-interspecies-rigidity-20261011/DELIVERY_CHECKS.md)
binds source identities, independent review scopes, canonical execution,
actual primary mutations and final repository checks. This main-based note
has no science dependency on the campaign's excluded-walk or transport PRs.
The independent audit path retains responsibility for effective retained
status; this publication applies no audit verdict.
'''
note += footer

old_proof = ''.join((S/note_name).read_text().splitlines(keepends=True)[86:543])
assert sha(old_proof.encode()) == 'b03944cf7a90d984914e2b54949fb3c80af25689a636f56b68ce98b8174759c6'
assert note.count(old_proof) == 1
old_body = ''.join((S/primary_name).read_text().splitlines(keepends=True)[23:224])
assert sha(old_body.encode()) == 'b210856e6cf5464f91efa658641642ffdfe99f7f9022cee8e744aa381980d82b'
assert primary.count(old_body) == 1
for name, data in [(note_name, note), (primary_name, primary)]:
    dst = D/name
    if dst.exists(): assert dst.read_text() == data
    else: dst.write_text(data)
mapping = {'scope': 'Exact source-preserving presentation changes and an appended finite kernel control; no proof change.',
           'outputs': []}
for kind, name, body in [('note', note_name, note), ('primary', primary_name, primary)]:
    mapping['outputs'].append({'kind': kind, 'source_path': str(S/name),
        'source_sha256': sha((S/name).read_bytes()), 'edits': edits[kind],
        'appended_text': footer if kind == 'note' else '',
        'publication_path': ('docs/INTERSPECIES_COLLISION_CURRENT_RIGIDITY_BOUNDED_THEOREM_NOTE_2026-10-11.md'
                             if kind == 'note' else 'scripts/'+name),
        'publication_sha256': sha(body.encode())})
(D/'PUBLICATION_EDITS.json').write_text(json.dumps(mapping, indent=2)+'\n')
r = subprocess.run([sys.executable, str(S/'interspecies_rigidity_publication/reconstruct.py')],
                   capture_output=True, text=True, timeout=30)
(D/'frozen_reconstruction.log').write_text(r.stdout+r.stderr)
assert r.returncode == 0, r.stdout+r.stderr
print(r.stdout, end='')
print(json.dumps({'proof_unchanged': True, 'original_primary_body_unchanged': True,
                  'final_note_sha256': sha(note.encode()), 'final_primary_sha256': sha(primary.encode())}))
