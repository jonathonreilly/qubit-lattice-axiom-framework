---
title: Independent bounded review of interspecies-only current rigidity
date: 2026-10-11
review_type: independent_reconstruction
target_sha256: ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8
scope: conditional I1-I24 theorem and explicitly supplied application premises
audit_verdict: none
native_law_or_physical_measure_verified: false
---

No consequential mathematical defect was found in I1–I24 of the frozen
`INTERSPECIES_CURRENT_RIGIDITY_PROBE.md`. No source repair is requested for
that revision. The result is a conditional theorem about scalar charges on
three-dimensional momentum domains. Its use as a microscopic current law
still requires the source-specific domain, band, collision-measure, and
conservation premises identified below.

The main conclusion is correctly common across species: regular local AB
shell invariance and full affine span of both velocity images force
`F_s = lambda E_s + b dot k + c_s`, with one lambda and one b and independent
species constants. No AA or BB collision identity is used. If the vector
charge is additionally supplied as `J_s = E_s grad E_s`, satisfies those
same componentwise shell identities, and has the stated regularity and
individual scalar cubic symmetry on invariant domains, then
`E_s^2 = e_s + beta |k|^2` with one common real nonzero beta. A positive beta
is not a conclusion of the stated hypotheses.

## Sources and independence

The complete 559-line target was read. The complete C1 report and both
referees were read as the source of the previously open interspecies step,
not as permission to adopt their other claims or broad dispositions.

| Source | SHA-256 | Coverage |
|---|---|---|
| `INTERSPECIES_CURRENT_RIGIDITY_PROBE.md` | `ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8` | All 559 lines, I1–I24 and evidence prose |
| `repo_sync_rc_2045/agents/RC_C1_report.md` | `e26566ce5cdbbd3ef1a3c1621109cefe294cf120d319f0a43cc09e4425054a78` | All 266 lines |
| `repo_sync_rc_2045/agents/RC_C1_referee.md` | `46b3b3624ac3c217651ef3c1820625079b414fb535dc206be8410f43d61f4a5c` | All 21 logical lines; no final newline |
| `repo_sync_rc_2045/agents/RC_C1_referee_full.md` | `a36b43eaf213e34ae9852c79a93f808a4e2bfb6dc307f8ca388b78a6db5132e4` | All 23 long lines |
| `repo_sync_rc_2045/SOURCE_IDENTITIES.json` | `4bcc8fc339fafe9a42d2bc17ad67c23f3e55a21a35f13d740567ecaa41c44e57` | Fixed extraction identities |
| Author receipt | `283511b410dafa614c1e4453483b540e744604e66b538a803516c8294379267f` | Complete receipt and all 23 path/hash bindings verified |

All three C1 copies also match their exact Git blobs at
`d009fb786d36a6cab4a7d410630b9382992faa08`. That fixed revision defines the
historical source boundary; this review does not claim a fresh-main or
global novelty search. No Spohn classification or historical C1 script is
imported as a proof premise.

The analytic reconstruction was frozen before author-helper, log, or receipt
contents were opened. Its 188-line record is
`interspecies_current_rigidity_review/PRE_HELPER_RECONSTRUCTION.md`, SHA-256
`567890a3674cddb262bc2320b200d7b106c5a18615f0eae6b69670bf53951836`.
The associated pre-helper receipt records the chronology and source hashes.
The target note's proof, control descriptions, and expected finite-table
outcomes were already visible, so this is not a blind discovery claim.
The reviewer did not author the target theorem. The separate exact helper
and its first run were completed before inspecting the author helper.

## Analytic reconstruction

For I1–I6, fix a regular incoming pair `(a,b)` and its lifted momentum
`K=a+b`. The admissible q set `O_A intersect (K-O_B)` is open. Its energy
sum has gradient `v_A(a)-v_B(b)`, which is nonzero. The C1 implicit-function
theorem therefore produces a local two-dimensional shell. Differentiating
the constant charge sum only along shell tangents puts its gradient in the
one-dimensional normal space. This gives the cross-species secant relation
I6. It does not require a second derivative, differentiate a pair multiplier,
or assert a constraint at an equal-velocity pair.

For I7–I11, the geometry must retain momentum labels, since equal velocities
do not initially imply equal charge gradients. Choose distinct x1,x2 from
X, then y1 in Y off their line and y2 in Y off their plane. Full affine span
supplies these choices. The four anchors are affinely independent and all
four cross edges are nonzero. The labeled K2,2 charge differences telescope
around the cycle. Their velocity coefficients are differences of adjacent
edge multipliers and sum to zero. Affine independence forces each coefficient
to vanish, so the four multipliers agree. The anchor charge gradients share
one scalar lambda and one vector b. This uses a bipartite cycle, without a
same-species triangle or connectedness of the velocity images.

I12–I14 correctly finish the exceptional cases. Subtract the anchor
homothety. An A residual is zero off the B anchor line, and on that line it
is parallel to the line's direction v. Even at the velocity of one B anchor,
the other anchor edge is nonzero and supplies this restriction. Symmetrically,
possible B residuals lie on the A anchor line and are parallel to its
direction u. This reasoning applies separately to every repeated label.

The two anchor lines are skew, with independent directions. Choose a B
velocity y outside the B anchor line. If it is also outside the A anchor
line, its residual is zero and kills every exceptional A residual by two
distinct directions. If y lies on the A line, the displacement from any
point of the B line to y lies outside `span(u,v)`: otherwise all four
anchors would be coplanar. The corresponding residual difference is both
in that plane of directions and parallel to the transverse displacement,
so it is zero. Independence of u and v makes both residuals zero. The
cross edge cannot vanish because the lines are disjoint. Finally an A
velocity outside its own anchor line kills all remaining B residuals.
These steps explicitly cover equal velocities and both exceptional lines;
no division by a line parameter is hidden.

I15 integrates a zero gradient on each connected open momentum domain,
using polygonal path connectedness. It supplies the two species constants.
Full affine span makes the common lambda and b unique. The converse follows
from energy conservation, lifted momentum conservation, and preservation
of one particle of each species. Full affine span is a sufficient premise;
the note does not claim it is necessary. The collinear example
`E_A=E_B=10+k1^2/2`, `F_A=F_B=k1^3` is valid: fixed sum and sum of squares
fix the unordered pair of longitudinal momenta, while the cubic charge is
not of the classified form on an open domain.

For I16–I17, the allowed `(K,a,c)` coordinates form an open subset of R9.
On the regular-regular collision locus the a derivative of the energy
defect Phi is the nonzero incoming relative velocity. Thus `Phi=0` is a
C1 embedded manifold of dimension eight there. Outgoing regularity is an
open condition. For every regular incoming pair the diagonal outgoing pair
belongs to this joint manifold, and sufficiently nearby points on the
fixed-K shell remain regular at the outgoing end.

A Borel measure giving positive measure to every nonempty relative open
set, together with `T Delta F=0` almost everywhere and `T != 0` almost
everywhere, makes `Delta F=0` almost everywhere. Continuity then makes it
zero everywhere: a nonzero value would give a relative open neighborhood
bounded away from zero and of positive measure. This argument works on
the joint manifold and needs no unsupported conditional-shell Fubini
step. Matrix-valued T causes no change when the defect is scalar. It proves
the stated implication without constructing a physical collision measure.

The deficient-support counterexample checks. The Dirac measure at a regular
diagonal collision with T=1 satisfies the almost-everywhere selection rule
but gives no support near other collisions. For equal quadratic energies,
the displayed `(e1,0)` to `((1/2,1/2,0),(1/2,-1/2,0))` collision conserves
momentum and energy, is regular at both ends, and has cubic-charge defect
3/4. Ambient R12 volume is not a substitute for measure on the constrained
eight-dimensional relation.

I18 requires individual scalar cubic invariance and an appropriate regular
domain. On an invariant connected open domain, the chain rule gives
`grad E(Rk)=R grad E(k)`. Nonconstancy supplies a nonzero gradient. Its
proper-cubic orbit has zero mean and spans R3: half-turns isolate a nonzero
coordinate and proper rotations move that axis among the three axes.
Its affine span is consequently R3 as required. The alternative dense
regular-domain hypothesis also works. Global equality of the actual
function makes E C1 on each rotated regular domain; derivatives agree on
open overlaps. Density puts each rotated gradient in the closure of the
original velocity image. Finite-dimensional affine subspaces are closed,
so the same orbit argument applies. Differentiability at every excluded
point is not being assumed.

I19 isolates the missing domain inference correctly. The 24 rotations of
`q=(1,2,3)/5` have minimum squared separation 6/25. Balls of radius `2r`
with `r=1/100` around these points are disjoint and contained in the cube.
The smooth group-summed bump is scalar cubic invariant, but on the single
ball `D=B(q,r)` only the identity term contributes, giving
`E=10+k1^2/2`. Taking the closed set `S=R3 minus D` gives connected
`U minus S=D`, with a line-valued velocity image. This refutes the isolated
inference from an arbitrary connected regular domain to full affine span,
not the entire physical C1 theorem. Likewise, covariance permuting species
does not give scalar invariance of each species; `E_j=k_j^2` demonstrates
that distinction.

For I20–I23, `E_s^2 in C2` makes `J_s=grad(E_s^2)/2` C1. Componentwise
application of the scalar theorem gives
`J_s=a E_s+B k+c_s`, with common a and B. The current's symmetric Jacobian
imposes `a_i v_j-a_j v_i+B_ij-B_ji=0`. Subtracting at two momenta puts all
velocity differences parallel to a if a is nonzero, contradicting full
affine span. Thus a=0 and B is symmetric. Integration gives
`E_s^2=k^T B k+2 c_s dot k+e_s` with one common B.

For I24, on the invariant species domains scalar cubic symmetry makes the
quadratic polynomial's rotation difference vanish on an open set. Its
coefficients give `R^T B R=B` and `R^T c_s=c_s`. Half-turns remove the
off-diagonal terms and vector terms; quarter-turns equate all diagonal
entries. Thus B is a common scalar beta times the identity. Beta cannot
be zero: continuous E_s with constant square on a connected domain would
be constant, contrary to full affine span. The sign remains free. On an
invariant ball inside both square-root domains,
`E_s=sqrt(C_s-|k|^2)` has full velocity span and `J_s=-k`; all normal AB
collisions conserve this current. A positive coefficient needs the
separate curvature/minimum premise. Extension through excluded points
also needs an appropriate extension premise.

## Distinct exact controls and author evidence

`interspecies_current_rigidity_review/independent_collision_controls.py`
uses SymPy exact rational and symbolic arithmetic. It imports no author
helper. Its geometry uses a nonorthogonal affine tetrahedron with determinant
82, solves for edge multipliers, and checks a constant nonzero determinant
for every pair of exceptional-line parameters, including equal-anchor
endpoints. This checks the exceptional-line elimination without sampling
those parameters or copying the author's charge-vector rank matrix.

The principal distinct fixture imposes actual continuum AB collisions for
`E_A=|k|^2/4`, `E_B=|k|^2/6`. With masses 2 and 3, write
`a=2K/5+p`, `b=3K/5-p`; the total energy is
`|K|^2/10+5|p|^2/12`. Rotations of p therefore preserve energy and momentum
for arbitrary K and p. Two quarter-turn families impose polynomial
constraints on general quadratic scalar charges. The exact system has
20 unknowns, rank 14, and precisely the six-dimensional family consisting
of one common energy coefficient, three common momentum coefficients,
and two species constants. This is an ansatz check on an actual continuum
collision family, not a proof for unrestricted C1 charges.

The same fixture rejects the wrong assignment of equal Hessians to the
two charges: common energy coefficients scale their Hessians by inverse
mass. It also detects why the current corollary needs an additional charge
identity. At K=0, rotating p from e1 to e2 conserves the quadratic energies,
but the defect in `E_A grad E_A+E_B grad E_B` is
`(5/72)(e1-e2)`. A separate exact radial collision conserves the current
with common beta=-1 and rejects unequal beta values 2 and 3, at regular
incoming and outgoing velocities. The cube-orbit separation is also
checked with rational arithmetic.

All 15 independent checks passed in the first execution, exit 0, with a
recorded 90-second timeout and no timeout reached. The subprocess took
0.372 seconds, using Python 3.13.5 and SymPy 1.14.0. Complete stdout/stderr
is preserved in `independent_controls.log`; the command and runtime record
are in `independent_execution.json`. No separate source-mutant process or
failed independent run is claimed.

After that execution, the entire 209-line author helper, full controls log,
execution record, development log, checkpoint, bounded search log, source
checks, and receipt were inspected. The eight rational matrix cases show
the stated nullities 4, 6, 5, 4, 4, 4, 8, and 5 respectively. They cover the
noncoplanar anchor cycle, deletion of an edge, one and two exceptional
lines, full-span labels with equal velocities and a duplicate, disjoint
full-span images, collinear images, and a coplanar flex. The cubic fixed
spaces, closed-current constraints, defect 3/4, and orbit separation agree
with the analytic argument. The adverse finite inputs are not separately
executed source mutants. The author helper was inspected, not rerun;
its prior exit-0 execution is author consistency evidence.

| Review evidence | SHA-256 |
|---|---|
| `pre_helper_receipt.json` | `c188863dec03f09cc91e2e6cf44a866f80db25358ff6157cde8dfe35392354ec` |
| `independent_collision_controls.py` | `0b213ffb0dafd0745346b93c39531198057c3595624f71249705682b3bcf5e8c` |
| `independent_controls.log` | `51ffdbf17e81029bb4e23bbdca3fb74ab2f18af29394baf33335b312b6d9df72` |
| `source_verification.json` | `6c0ba92b299c1dd78c4e04ea1b84a73be8901c755fac7021d54691e5ebf71262` |

These files are in `interspecies_current_rigidity_review/`. Source verification
matches all 13 pre-helper input records, all 23 author receipt records,
the frozen reconstruction, four reused applicable instruction identities,
four prior-composition freeze guards, and the three exact C1 Git blobs.
Repeated bindings are counted separately. Hash checks of historical or
instruction files do not certify unrelated scientific content. Initial
truncated combined displays were recovered in bounded reads before they
were treated as complete evidence inspection. Full evidence is preserved
on disk; the final receipt binds this report and all review artifacts.

## Application limits and disposition

The intended physical application must still supply individual scalar-band
energies and the stated connected open regular domains, prove full affine
span directly or satisfy one of the checked cubic-domain hypotheses, and
identify a full-support regular collision measure with the required
nonzero-amplitude and additive-conservation identities. For the current
corollary it must additionally justify the actual current symbol
`J_s=E_s grad E_s`, its regularity, and its componentwise conservation.
None of these physical inputs follows from this review's rank calculations
or from the mathematical rigidity theorem itself.

This bounded review supports I1–I24 under their explicit hypotheses and
does not recommend a source correction at the reviewed hash. It does not
certify native gravity, a microscopic scattering model, a positive speed
coefficient, a physical support measure, matrix bands, gapless continua,
or the historical C1 no-go and approximation claims. It applies no audit
verdict and grants no retained status. Only this report and its separate
external evidence directory were written; no authored source, repository,
prior composition, or editable prompt file was changed.
