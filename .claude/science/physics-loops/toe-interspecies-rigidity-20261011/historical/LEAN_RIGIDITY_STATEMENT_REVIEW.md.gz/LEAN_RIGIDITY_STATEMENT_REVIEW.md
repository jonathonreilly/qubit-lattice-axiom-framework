---
title: Independent statement review of the scoped interspecies Lean geometry
date: 2026-10-11
review_type: independent_statement_and_evidence_review
principal_sha256: c72e7a9a961d1eec1ff60842ac3e8a5530c8b71dfc1505dc098d7cab780044df
author_receipt_sha256: 4f1512919a9e4aa41cac168882d3975e4b95f72cd4620876aa7cc959201c9048
scope: six finite affine-geometry declarations and their actual evidence
additional_lean_executions: 0
audit_verdict: none
---

No consequential statement mismatch or proof defect was found in the six
principal declarations. The frozen statement map accurately limits the
formal coverage to the four-anchor cycle of I9–I10, the exceptional-line
argument around I14, and the stated finite geometric consequences. No
source repair is requested for this packet. It must not be described as
a formalization of every step I9–I14 or of the complete I1–I24 theorem.

The distinction is substantive: the Lean residual theorem assumes the
line parameterizations and residual-direction representations. It does
not derive the confinement assertions I12–I13 for all labels. Anchor
extraction, the other branch of the exceptional-case argument, and final
propagation to every label remain outside the packet, as its existing
scope documents explicitly say.

## Exact sources and review method

The complete final 146-line `RigidityGeometry.lean`, 91-line
`ControlData.lean`, 17-line `AxiomInventory.lean`, all four false-control
sources, statement map, scoped obligations, scope report, checkpoint,
runtime identity, runners, and receipt-generation script were inspected.
All nine complete compiler logs and four wrapper logs were read. Historical
source snapshots were compared to the complete final sources; their full
differences were inspected. Duplicate final snapshots and convenience logs
were checked byte for byte.

| Bound source | SHA-256 |
|---|---|
| `interspecies_rigidity_lean/RigidityGeometry.lean` | `c72e7a9a961d1eec1ff60842ac3e8a5530c8b71dfc1505dc098d7cab780044df` |
| `interspecies_rigidity_lean/RigidityGeometry.olean` | `08a9c74f5f2b8f8591b05dd548ed0e42b10b283330536f11254fa1ac63de20e2` |
| `interspecies_rigidity_lean/ControlData.lean` | `4ae162a8a457a47db40816c53ff4fee97ef3c47639ab0fe16d3d4268c65916af` |
| `interspecies_rigidity_lean/STATEMENT_MAP.md` | `b1ad69bff414bb6095e8ea5426e832ac0fffd59cf8c7e9d57a652d2fd4b1b468` |
| `interspecies_rigidity_lean/SCOPE_REPORT.md` | `7c57cfd772de71e483791bfc8caa4166cf9c51c23b2ae2d11da005148ad8fe24` |
| `interspecies_rigidity_lean/axioms.txt` | `35e6b4915e0c50fbf41c0442b271ddd35ff9aa25d664761692ac3dc7c22140d5` |
| `interspecies_rigidity_lean/receipt.json` | `4f1512919a9e4aa41cac168882d3975e4b95f72cd4620876aa7cc959201c9048` |

The source mathematics is the unchanged authored note
`INTERSPECIES_CURRENT_RIGIDITY_PROBE.md`, SHA-256
`ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8`.
Its I1–I24 arguments had already been independently reconstructed by this
reviewer in `INTERSPECIES_CURRENT_RIGIDITY_REVIEW.md`, SHA-256
`78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6`.
That complete reading is reused at unchanged identities, and the full
finite-geometry section was reread for this statement comparison. The prior
analytic review is preserved; the present report is a separate check of
formal statements, proof terms as expressed by the source, and provenance.
The reviewer did not author the Lean packet.

## Statement and proof reconstruction

Every principal theorem quantifies over a field K and an additive commutative
group V with a K-module structure. This includes real three-space. There is
no coordinate sampling, real-number approximation, generic-position
restriction on line parameters, or extra finite-dimensional assumption in
the statements. In spaces too small to contain four affinely independent
points the premise is unavailable; this does not weaken the intended
application to the four chosen anchors in real three-space.

The common premise `AffineIndependent K ![x1,x2,y1,y2]` is the standard
mathlib definition. Its zero-sum weighted-subtraction characterization and
the exact linear-combination lemma used here were read in the pinned
library. It does not assert multiplier equality or residual elimination.
It is the affine-independence/noncoplanarity premise already supplied at
the beginning of the note's Section 4.1. Its extraction from the velocity
images is a separate argument.

`four_affine_coefficients_zero` at line 24 is a faithful four-point adapter:
the scalar sum and vector sum are explicit premises, and their four
coefficients are concluded zero. The proof expands a `Fin 4` sum and applies
`AffineIndependent.eq_zero_of_sum_eq_zero` on `Finset.univ`. It proves every
required scalar and vector equality at subsequent call sites. No desired
rigidity conclusion is smuggled into this adapter.

`four_cycle_multipliers` at line 40 requires all four cross-edge equations
`Pi-Qj = lij • (xi-yj)`. Its cancellation is
`(P1-Q1)-(P2-Q1)+(P2-Q2)-(P1-Q2)=0`. After substitution, its coefficients
at x1,x2,y1,y2 are exactly
`l11-l12`, `-l21+l22`, `-l11+l21`, and `-l22+l12`.
They sum to zero. Affine independence makes them zero and gives the stated
chain `l11=l21`, `l21=l22`, `l22=l12`. This directly covers I9–I10. It uses
no same-species edge and does not drop a cross edge. Affine independence
already excludes zero anchor edges. The explicit multipliers are the
mathematical witnesses supplied by I7 after that anchor choice; their
existence is not independently formalized here.

`four_anchor_homothety` at line 89 uses that result to construct
`l=l11` and `b=P1-l11 • x1`. Its four conclusions cover P1,P2,Q1,Q2,
with the same l and b. This matches the last paragraph of Section 4.1.
It asserts existence on exactly four anchors, not uniqueness or the
universal labeled-family conclusion I8.

`opposite_skew_line_residuals` at line 62 takes explicit equations
`x=y1+tx • (y2-y1)`, `y=x1+ty • (x2-x1)`,
`r=alpha • (y2-y1)`, `s=beta • (x2-x1)`, and
`r-s=gamma • (x-y)`. Expanding the last equation gives the four coefficients

```
beta + gamma*(1-ty),  -beta + gamma*ty,
-alpha - gamma*(1-tx),  alpha - gamma*tx.
```

They sum to zero, so the adapter makes each zero. The first two sum to
gamma, giving gamma=0; the first and fourth then give beta=alpha=0.
Substitution gives r=s=0. This is the exact exceptional branch in
Section 4.3, with a stronger explicit conclusion about its scalar
multipliers. The proof works for all tx and ty, including 0 and 1.
It never divides by a parameter or assumes a nonzero residual.

That endpoint coverage is conditional on the given residual-direction
equations. It must not be confused with having proved I12–I13 for every
momentum label at an equal velocity. The two-direction confinement argument
and label discipline that supply those equations remain in the analytic
note and its earlier independent review.

`opposite_skew_direction_not_span` at line 116 is I14 in coefficient form:
for arbitrary a,b it excludes
`x-y=a • (x2-x1)+b • (y2-y1)`. If this equality held, set the residual
coefficients to b and -a and the cross multiplier to 1 in the preceding
theorem. It would force 1=0, contradicting the field structure. Quantifying
over both coefficients is precisely exclusion from the span of the two
directions; a separate line-skewness axiom is not assumed.

`opposite_skew_lines_disjoint` at line 130 specializes direction exclusion
to zero coefficients and proves x is not y. It therefore supplies the
nonzero exceptional cross edge used in the analytic proof. It does not
assert every clause of I11 as a separate general line theorem, nor is that
needed for these derived declarations.

The statement map's exclusions are accurate. The six declarations leave
unformalized the existence of the anchors from full affine span, the
off-line confinement I12–I13, the branch where the extra B velocity is off
both lines, the final propagation to all remaining labels, and thus the
full I7–I8 result. Shell differentiation, the measure upgrade, integration,
cubic symmetry, and the current corollary are also outside this packet.
No missing step in that larger proof can be supplied merely by citing the
successful compilation of these six statements.

## Controls, axiom inventory, and retained failures

The eight accepted control theorems use exact rational three-vectors.
`tetra_independent` proves the standard tetrahedron independent from the
library definition by projecting its vector equation onto three coordinates
and using the zero-sum equation for the fourth coefficient. The positive
four-cycle fixture supplies nonzero dilation 3 and translation `(2,-1,5)`.
Its conclusion consists of reflexive scalar equalities, so the universal
theorem source, not that conclusion alone, carries the general proof.
The positive exceptional fixture retains arbitrary alpha,beta,gamma and
instantiates the two line parameters as -1 and 2.

The adverse data are genuine witnesses. The square has anchors
`x1=0`, `x2=(1,1,0)`, `y1=e1`, `y2=e2`, with all four edges true and
multipliers 2,3,2,3. For independent tetrahedron anchors the three-edge
example has multipliers 1,1,2 and no compatible fourth edge enforcing
equality. The coplanar residual witness takes
`u=(1,1,0)`, `v=(-1,1,0)`, `x=e1`, `y=0`, and
`alpha=beta=-1/2`, `gamma=1`; its residual equation is true and gamma
does not vanish. The cycle-sign witness is exactly `(2,-2,0)`.

The four separate false files attempt respectively `2=3`, `1=2`, `1=0`,
and a zero sign-corrupted cycle after importing the verified data. The
complete logs reach the intended mathematical goals `False`, with exit 1;
the last case reaches two component goals. They do not fail at imports,
parsing, type synthesis, or timeout. These are concrete false-statement
controls, not mutations of the principal source and not a completeness
test for all possible statement mistakes. The accepted witnesses and
their exact arithmetic establish their mathematical relevance; a failed
tactic invocation alone would not prove a proposed assertion false.

The entire recorded history consists of nine compiler executions: two
successful principal versions, one failed initial positive-control version,
one successful corrected positive-control version, one successful axiom
inventory, and four deliberate false-control rejections. Each has a
120-second timeout. The final principal, corrected controls, and inventory
took 34.870, 26.968, and 31.327 seconds respectively. Commands, snapshots,
hashes, local paths, exit codes, and logs agree with the receipt.

The first principal snapshot contains the same three core proofs as the
final source; the final version adds three consequences. The failed
positive-control snapshot differs from its successful successor only by
the missing explicit `Finset.univ` argument. Its application-type error,
unsolved goal, and printed `sorryAx` dependencies remain preserved and
are correctly excluded from accepted evidence.

The final inventory covers all six principal and all eight control
theorems, including `square_multipliers_unequal`, which is not printed by
the control module's shorter local inventory. Every final dependency list
is exactly `propext`, `Classical.choice`, `Quot.sound`. The accepted sources
contain no `sorry`, `admit`, custom `axiom`, `unsafe`, or `native_decide`.
`noncomputable section` and the heartbeat option do not waive proof
obligations. These are ordinary Lean proofs within the stated standard
logical foundation, not axiom-free proofs.

## Runtime binding and verification limit

The pinned runtime is Lean 4.35.0-rc4, with mathlib at
`939d5d5d9e6f07d1d8c80a16fa3fa39a7518b716`. The executable, selected library
source and cached-object, manifest, toolchain, and prior-runtime-receipt
hashes in the packet still match. The current mathlib checkout and all eight
package checkouts have the expected commits and clean tracked status.
The ordinary recorded commands use `lake env lean`, with no kernel-checking
bypass. Their compiler outputs and source snapshots are consistently bound.

The specific upstream material read for this review is
`AffineSpace/Independent.lean` lines 25–150 and 770–840,
`AffineSpace/Combination.lean` lines 220–272 and 407–429, and
`Tactic/Module.lean` lines 1–75, all under the pinned mathlib tree. These
cover the affine definition, zero-sum characterization, weighted-subtraction
adapter, and the module tactic's coefficient-normalization contract.
Other imported proofs and the complete transitive cache were not manually
reverified or rebuilt. Hash consistency does not independently authenticate
an entire toolchain or prove unreviewed library implementation correctness.

No focused statement concern remained that required an additional runtime
test. Accordingly this reviewer did not execute Lean or Lake, install
anything, change dependencies, or rerun author controls. The evidence here
combines independent mathematical/statement inspection with the preserved
ordinary compiler results, not an independently repeated compilation.

`interspecies_rigidity_lean_review/source_verification.json`, SHA-256
`79421ceb7c268d7397382db5869267f679090a619d5d205e5beecfd8ed1735f9`,
records 86 matching path/hash bindings: 26 author protected sources,
53 author artifacts, the author receipt, two prior analytic-review guards,
and four reused applicable instruction identities. It also records all
nine executions, all fourteen axiom inventories, exact historical source
differences, and package identities. An initial oversized receipt display
was truncated; its omitted fields were recovered through structured reads
and complete binding checks before review completion.

The strongest supported description is: independently reviewed formal
statements and preserved Lean compilation for the two specified finite
affine-geometry arguments and their declared consequences. The full
collision-invariant theorem, its physical application premises, and any
native-law or retained-status conclusion are not thereby formally verified.
This review applies no audit verdict. Only this report and its separate
evidence directory were written; authored sources, historical failures,
worktrees, the prior review, and editable prompt files were preserved.
