# Interspecies current rigidity — frozen checkpoint

Completed one bounded external derivation at the requested fixed C1 revision d009fb786d36a6cab4a7d410630b9382992faa08. Prior finished packets and repository sources were not edited.

Strongest result: the cross-species regular-shell identities force F_s=lambda E_s+b.k+c_s on connected open three-dimensional momentum domains when both velocity images have full affine span. Image connectedness is not needed in the geometric lemma. The noncoplanar K2,2 cycle and both exceptional skew-line cases, including equal velocities and repeated labels, are proved explicitly.

Conditional current consequence: E_s grad E_s shares one symmetric B before symmetry reduction; individual cubic symmetry on invariant regular domains gives E_s^2=e_s+beta |k|^2 with common nonzero beta, without AA or BB scattering. The sign of beta is not fixed by these hypotheses.

Remaining source match: the actual regular domains must support the cubic orbit argument, and an explicit full-support regular collision measure plus T*charge_defect=0 and T nonzero almost everywhere must supply the pointwise shell identity. A connected arbitrary U\S does not itself ensure rotation invariance. Counterexamples and a dense-domain sufficient alternative are retained.

Evidence: complete C1 report and both referees read; bytes match the extraction manifest and exact Git blobs. Eight exact rational rigidity-matrix cases and cubic/current/measure controls completed in the first formal run, exit 0, 30-second timeout. Finite controls are an alternate formulation by the same author, not independent review or a continuum proof. Source search was fixed-revision and bounded, not a global novelty claim.

Next action: independent reconstruction of the geometric proof and source-specific matching of the domain, scalar-species, collision-measure and current-symbol premises. No physical-law adoption or retained-status decision is requested or made. See ../INTERSPECIES_CURRENT_RIGIDITY_PROBE.md and receipt.json for frozen identities.
