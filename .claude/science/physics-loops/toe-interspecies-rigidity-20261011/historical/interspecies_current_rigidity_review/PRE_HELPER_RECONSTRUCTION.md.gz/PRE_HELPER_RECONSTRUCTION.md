# Reconstruction before author-helper inspection

2026-10-11. Target: `INTERSPECIES_CURRENT_RIGIDITY_PROBE.md`, 559 lines,
SHA-256 `ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8`.
The complete target and the three C1 source/referee files were read. The
target's evidence descriptions were visible, including its finite-table
outcomes. The author helper, logs and receipt contents have not been opened.
This is independent reconstruction, not a blind discovery or formal audit.

## 1. Exact source boundary

C1 report `e26566ce5cdbbd3ef1a3c1621109cefe294cf120d319f0a43cc09e4425054a78`,
short referee `46b3b3624ac3c217651ef3c1820625079b414fb535dc206be8410f43d61f4a5c`,
full referee `a36b43eaf213e34ae9852c79a93f808a4e2bfb6dc307f8ca388b78a6db5132e4`
match their exact Git blobs at `d009fb786d36a6cab4a7d410630b9382992faa08`.
The C1 same-species triangle proof does not establish the interspecies-only
step. The referees also separate almost-everywhere amplitudes from pointwise
shell invariance and do not infer positive beta from cubic symmetry alone.
Their other reduction/no-go/approximation judgments are outside this review.
No cited Spohn theorem or unexamined historical C1 script is imported.

## 2. Shell differential and label discipline: I1–I7

For a regular incoming pair, fix K=a+b. The admissible q set
O_A intersect (K-O_B) is open and contains a. Its energy function has
gradient v_A(a)-v_B(b), nonzero by hypothesis. The C1 implicit-function
theorem supplies a two-dimensional local level surface. Differentiating the
constant charge sum along its tangent vectors makes p_A(a)-p_B(b)
orthogonal to that tangent plane. Its annihilator is exactly the one
dimensional span of the energy gradient, giving I6. The conclusion makes
no assertion on a zero relative velocity and does not differentiate any
pair multiplier. C1 regularity is sufficient.

The subsequent geometry must retain momentum labels: equality of velocities
does not initially identify charge gradients. The source does so in I7.
There is no assumption of a locally invertible velocity map or a Hessian.

## 3. Four anchors: I8–I11

Choose distinct x1,x2 from X. Full affine span of Y supplies y1 off their
line and y2 off their plane with y1. Thus x1,x2,y1,y2 are affinely
independent. In particular none of the four required cross edges vanishes.
The four charge differences telescope around this K2,2 cycle. Its velocity
coefficients are precisely the four differences of edge multipliers in I10,
and their sum is zero. Affine independence forces all four coefficients to
vanish. Hence the four multipliers equal one lambda, and all four labeled
charge gradients equal lambda times their velocity plus one common vector.

This is a bipartite cycle, not a disguised same-species triangle. The two
opposite anchor lines have independent directions and are skew, since
coplanarity, intersection or parallelism would put the four anchors in a
plane. These facts do not require connected velocity images.

## 4. Exceptional and equal-velocity labels: I12–I14

After subtracting that common homothety, both B anchors have zero residual.
An A label outside their line has a residual in two distinct nonzero
one-dimensional spans, so it is zero. A label on their line has a residual
parallel to its direction v. Even at one B anchor's velocity the other
cross edge is nonzero, so this statement still follows. The symmetric
argument puts all possible B residuals on the A anchor line, parallel to u.
It applies to every repeated label separately.

Choose y_* in Y outside the B anchor line. If it is also outside the A line,
its residual is zero, and every exceptional A residual is parallel both to
v and to the line from its velocity to y_*, two distinct directions.
If instead y_* is on the A line, the displacement from any point of the B
line to y_* lies outside span(u,v). Otherwise subtracting line parameters
would make the four anchors coplanar. The cross constraint then puts the
residual difference simultaneously in span(u,v) and in that transverse
one-dimensional span; it must be zero. Independence of u,v makes each
residual zero individually. This cross edge is nonzero because the lines
are disjoint.

All A residuals now vanish. Full affine span of X supplies x_* outside the
A anchor line. Comparing it with any remaining B residual on that line
forces that residual to be zero. Thus every label, including each duplicate
velocity, obeys I8. Full affine span is sufficient; necessity is not claimed.

## 5. Integration and uniqueness: I4, I15

The gradient of F_s-lambda E_s-b dot k is zero on O_s. A connected open
subset of Euclidean space is polygonally path connected; integrating along
a finite polygonal path gives a species constant. This is the use of domain
connectedness. Energy and lifted momentum conservation make the converse
identity immediate, with the two species constants cancelling separately.
If two lambda,b pairs worked, their difference would annihilate all X in
the affine relation (lambda-lambda')x+(b-b')=0. Full affine span makes both
differences zero. No AA or BB identity has entered.

## 6. Joint collision manifold and support: I16–I17

The domain of (K,a,c), with a,c in O_A and K-a,K-c in O_B, is open in
R9. On the regular-regular locus, the a derivative of Phi is the nonzero
incoming relative velocity. Hence Phi=0 there is a C1 embedded manifold of
dimension eight. The outgoing regularity condition is open by continuity.
For each regular incoming pair, the diagonal outgoing pair lies in this
manifold; all sufficiently nearby outgoing points on its fixed-K shell
remain in it.

The two almost-everywhere assumptions imply Delta F=0 outside a union of
null sets. If continuous Delta F were nonzero at a manifold point, it would
be bounded away from zero on a nonempty relative open neighborhood. Full
support gives that neighborhood positive measure, a contradiction. Thus the
identity holds everywhere on the joint manifold and implies I3 locally.
No conditional-shell Fubini assertion, amplitude continuity, or surface
measure derived from a microscopic theory is needed or proved here.
For a matrix amplitude the defect is scalar: a nonzero matrix times a
nonzero scalar cannot vanish. The same conclusion therefore holds.

The support qualifier is substantive. The source's atomic diagonal measure
has T=1 and satisfies the selection rule almost everywhere. The displayed
nontrivial collision is regular at both ends, conserves momentum and energy,
and has cubic-charge defect 1-1/8-1/8=3/4. Thus that deficient measure cannot
establish pointwise invariance. Ambient R12 volume is also the wrong measure
for this constrained eight-dimensional relation.

## 7. Cubic hypotheses and the domain counterexample: I18–I19

On an invariant connected open domain, scalar invariance of a C1 E gives
grad E(Rk)=R grad E(k) by the chain rule. Nonconstancy supplies a nonzero
gradient. Its proper-cubic orbit has zero average and spans R3: half-turns
isolate any nonzero coordinate, and proper rotations carry that axis to all
three axes. The orbit's affine span is therefore also R3.

For the alternative dense O in an invariant cube U, global equality of the
actual function supplies a C1 restriction on RO via E(R^-1 k). On the open
overlap with O its derivative agrees with the original derivative. Density
gives overlap points tending to Rk, so R grad E(k) is in the closure of the
velocity image. Every affine subspace in finite dimensions is closed; the
same orbit argument then forces full affine span. This reasoning does not
assume differentiability of E at arbitrary excluded points.

Closed S and connected U minus S alone do not give either invariance or
density. In I19 the 24 distinct rotations of q=(1,2,3)/5 are separated by
at least sqrt(6)/5. Twice-support radius 2r=1/50, so the radius-2r balls are
disjoint and fit inside U. The group sum is invariant by reindexing. On
D=B(q,r), only the identity term contributes and the plateau is one, giving
E=10+k1^2/2 and grad E=(k1,0,0). S=R3 minus D is closed, and U minus S is
the connected open ball D, yet its velocity image is an affine line.
This isolates the domain inference; it does not audit the full C1 law.

Species-permuting covariance also differs from scalar invariance of each
species. The family E_j=k_j^2 is covariant under permutations of axes,
whereas each individual velocity image is a line. Neither illustration
claims that such a family is a physical scattering multiplet.

## 8. Common quadratic current and its sign: I20–I24

E_s^2 in C2 makes J_s=grad(E_s^2)/2 a C1 charge, even though C2 regularity
of E_s itself was not assumed. Apply the scalar result to each component,
obtaining common vector a and matrix B, and independent constant vectors c_s.
Symmetry of its Jacobian gives I22 with the displayed signs. Subtracting at
two momenta gives a wedge (v-v')=0. For nonzero a this puts every velocity
difference in span(a), contradicting full affine span. Hence a=0 and B is
symmetric. Integration gives I23 with one common B.

With scalar cubic invariance and invariant species domains, the difference
of the quadratic polynomial at Rk and k vanishes on an open set. Coefficient
comparison gives R^TBR=B and R^Tc_s=c_s. The half-turns remove off-diagonal
terms and all vector entries; quarter-turns equate the diagonal entries.
This proves I24 with the same real beta for both species. If beta were zero,
continuous E_s would have constant square and hence constant sign/value on
its connected domain, contrary to nonconstancy (already implied by I2).

Its sign is not fixed. On an invariant ball inside both positive square-root
domains, E_s=sqrt(C_s-|k|^2) is nonconstant with full velocity span and
J_s=-k. Every momentum-conserving AB collision conserves this vector charge.
Thus beta=-1 satisfies the conditional corollary. A positivity conclusion
would require the separate minimum/curvature premise that the source names.

## 9. Preliminary disposition and distinct control design

No consequential defect has appeared in I1–I24. The physical selection
rule, support measure, scalar-species interpretation, and actual regular
domains remain application inputs. This review does not import a C1 broad
negative verdict, verify microscopic scattering, or establish native law.

Before author-helper inspection, construct a distinct exact control using
symbolic edge multipliers and all-parameter skew-line residuals, including
the equal-anchor endpoints. Also impose conservation on an actual continuum
AB quadratic-energy collision family with unequal masses and general
quadratic scalar charges. This tests shell conservation directly rather
than the author's finite velocity-label constraint matrix. A regular
radial-energy collision with unequal current coefficients should fail,
whereas the common negative-beta example should conserve exactly. These
finite/ansatz comparisons will not prove the unrestricted C1 theorem or
full support of a physical measure.
