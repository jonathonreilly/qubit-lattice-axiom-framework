# Scoped finite-geometry formalization

Frozen mathematical source: `../INTERSPECIES_CURRENT_RIGIDITY_PROBE.md`, SHA256 `ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8`; its receipt is `283511b410dafa614c1e4453483b540e744604e66b538a803516c8294379267f`.

Targets: (1) the four noncoplanar cross-edge equations in I9–I10 force all four multipliers equal; (2) the residual equation between opposite skew anchor lines in I14 forces both residuals zero. An explicit labeled extension may be added only if the formal machinery is tractable. Four-point affine independence is an explicit mathematical premise, not assumed as a custom axiom.

Outside this initial obligation: existence of anchors from full affine span, regular shell IFT, full-support a.e.-to-pointwise upgrade, gradient integration, current identification and physical assumptions. Exact final coverage will be reported; a useful narrowed result is permitted.

Pinned read-only dependencies: `../lean_audit/mathlib` at `939d5d5d9e6f07d1d8c80a16fa3fa39a7518b716`, Lean `4.35.0-rc4`, runtime under `../lean_audit/lean-4.35.0-rc4-darwin_aarch64/`. No fetch, install, dependency change, global tooling change, prior-source edit, repository edit or audit-status change is authorized. All new files, snapshots, logs and temporary directories stay here.

Completion requires ordinary successful Lean compilation without proof holes or custom axioms, full compiler output, printed axiom dependencies, precise theorem-to-note mapping, and positive/false mathematical controls. Failed attempts remain preserved. This is scoped formal evidence, not independent recertification of the complete paper or a retained-status decision.
