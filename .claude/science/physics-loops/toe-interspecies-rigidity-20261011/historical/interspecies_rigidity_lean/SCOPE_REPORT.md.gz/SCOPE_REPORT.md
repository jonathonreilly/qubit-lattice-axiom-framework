# Scoped Lean evidence for the finite interspecies geometry

The [146-line theorem source](RigidityGeometry.lean) compiled with Lean
4.35.0-rc4 against mathlib commit
`939d5d5d9e6f07d1d8c80a16fa3fa39a7518b716`. It contains six universal
declarations, including the two requested arguments: equality of all four
cross-edge multipliers at affinely independent anchors, and elimination of
the residuals on opposite skew anchor lines. Its source SHA256 is
`c72e7a9a961d1eec1ff60842ac3e8a5530c8b71dfc1505dc098d7cab780044df`.

The exact hypotheses and correspondence to I9–I14 are in
[STATEMENT_MAP.md](STATEMENT_MAP.md). Four-point affine independence is the
standard mathlib definition and an explicit premise. The proofs also derive
the common affine map on the four anchors, I14's direction exclusion, and
disjointness of the two lines. They apply to arbitrary vector spaces over a
field, including real three-space. They use neither floating arithmetic nor
a finite enumeration as the principal proof.

This is scoped formal evidence by the note's author, not an independent
recertification of the full result. The full labeled-family extension I7–I8,
anchor extraction from full affine span, regular-shell IFT, a.e.-to-pointwise
upgrade, integration and physical/current hypotheses remain outside the
formalization. There is no claim that the entire collision-invariant theorem
or a native physical law has been Lean verified. No formal audit verdict or
retained-status decision is made.

## Compilation and logical assumptions

The [final principal compiler log](final_compiler.log) is complete, with exit
0 and no errors or warnings. The first attempt compiled the original three
core declarations; the second compiled the final six. Each Lean process had
an explicit 120-second wall timeout and used ordinary `lake env lean`, with
no bypass of kernel checking. The final principal compilation took about
35 seconds. Exact commands, source snapshots, hashes and durations are in
`logs/attempt01.*` and `logs/attempt02.*`.

[AxiomInventory.lean](AxiomInventory.lean) imports the accepted principal and
control modules and prints the dependencies of every theorem declared in
them: six principal and eight control theorems. The full
[axiom output](axioms.txt) lists only `propext`, `Classical.choice`, and
`Quot.sound`. No accepted theorem depends on `sorryAx` or a custom axiom.
The accepted source files contain no `sorry`, `admit`, custom `axiom`,
`unsafe`, or `native_decide` declaration/use. This is normal Lean evidence
with its standard logical foundation, not a claim of an axiom-free system.

The runtime was reused from the earlier task-local installation after reading
its complete receipt and entrypoint. The Lean and Lake executable hashes were
checked against that receipt, and their versions were read again. The mathlib
commit, clean tracked status, `lake-manifest.json` and `lean-toolchain` hashes
were verified. Details are in [runtime_identity.json](runtime_identity.json).
No network fetch, package installation, dependency change, archive extraction
or global Lean configuration change occurred. All new files, logs and temporary
paths are inside this directory.

The imports use the existing pinned upstream cache. This run did not rebuild
or manually reprove the whole mathlib dependency closure. The affine
independence definition, the zero-sum characterization actually invoked, the
weighted-subtraction reduction used in the controls, and the module tactic's
normalization contract were inspected. Exact library file identities and
manual reading ranges are recorded in the receipt; uninspected imported
library proofs are not described as independently reviewed.

## Positive and false controls

[ControlData.lean](ControlData.lean) proves the standard rational tetrahedron
affinely independent and supplies eight accepted theorems. It instantiates the
four-edge theorem with nonzero dilation and translation, and the exceptional
residual theorem at `tx=-1`, `ty=2` with arbitrary residual coefficients. It
also proves the adverse finite data used by the following separate tests.

| False assertion tested | Verified data | Actual result |
|---|---|---|
| Equality without noncoplanarity | Four square edges with alternating multipliers 2 and 3 | Exit 1, mathematical goal `False` |
| Equality with one cross edge omitted | Independent tetrahedron with three multipliers 1,1,2 | Exit 1, mathematical goal `False` |
| Zero residual without skewness | Coplanar example with `α=β=-1/2`, `γ=1` | Exit 1, mathematical goal `False` |
| Wrong sign in the four-cycle cancellation | Corrupted cycle is `(2,-2,0)` | Exit 1, two component goals `False` |

All four complete compiler failures were read. They reached the intended
mathematical assertion after importing the verified data. None failed due to
missing imports, parsing, type mismatch, resource exhaustion or timeout.
Sources, raw logs and commands are bound by
[false_controls_manifest.json](false_controls_manifest.json). These are
concrete false-statement controls, not a claim that all possible incorrect
proofs or source mutations were tested.

## Preserved unsuccessful work

The first positive-control attempt used a mathlib helper with its explicit
finite-set argument omitted. It exited 1 with an application type mismatch.
The full source, log and execution record remain at `logs/controls01.*`.
The correction supplied `Finset.univ`; the second attempt compiled without
errors or warnings. The main geometric theorem source did not change in
response to this tooling error. The failed elaboration's printed `sorryAx`
diagnostics are preserved as failed evidence, never counted as an accepted
proof. The final complete axiom inventory has no such dependency.

One runtime-identity command initially had a duplicated component in its
working-directory path and was rejected before process creation. It wrote
nothing; the corrected invocation succeeded. There were no other unexpected
compiler failures or omitted successful-run warnings. All four deliberate
false-case failures are retained separately from that development error.

## Frozen-source and scope boundary

The authored 559-line note remains at
`ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8`,
and its prior receipt remains at
`283511b410dafa614c1e4453483b540e744604e66b538a803516c8294379267f`.
The prior `lean_audit` receipt and entrypoint were also left unchanged.
The new [receipt](receipt.json) records final source/object/log identities,
protected dependencies, complete source/log reading and the remaining scope.

The requested finite obligation is complete at this scope. The separate
review of I1–I24 remains independent work. Further formalization could target
the full labeled extension, but no obstruction to it or closure of it is
claimed here. Root retains sole authority over repository edits and PRs.
