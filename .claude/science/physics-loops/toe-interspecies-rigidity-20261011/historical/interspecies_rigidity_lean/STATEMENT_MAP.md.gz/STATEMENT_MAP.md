# Exact mapping to the frozen note

Source: `../INTERSPECIES_CURRENT_RIGIDITY_PROBE.md`, SHA256
`ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8`.
This map concerns its finite geometry, not its full collision-invariant theorem.

All six principal declarations in `RigidityGeometry.lean` quantify over an
arbitrary field `K` and an additive commutative group `V` with a `Module K V`
structure. They therefore specialize to `K = ℝ`, `V = Fin 3 → ℝ`.
The real type and field instance are provided by the pinned mathlib imports.
There is no numerical approximation or coordinate bound in the principal proofs.

The explicit anchor premise is mathlib's
`AffineIndependent K ![x₁, x₂, y₁, y₂]`. In real three-space this says that the
four points are affinely independent, the noncoplanarity premise of Section 4.1.
It is the existing library definition about every zero-sum affine relation,
not a newly declared axiom or an assumption that already mentions multiplier
equality or residual elimination. The library definition and the exact
linear-combination characterization used by the proofs were inspected.

## Principal declarations

1. **`four_affine_coefficients_zero`**: given the anchor premise, four scalar
   coefficients whose sum is zero, and a zero vector linear combination of the
   four anchors, all four coefficients vanish. This is the direct library-to-
   four-point adapter used in I10. Its scalar-sum and vector-sum hypotheses are
   explicit; each application proves both.

2. **`four_cycle_multipliers`**: given four vectors `P₁,P₂,Q₁,Q₂` and the four
   equations
   `Pᵢ-Qⱼ = lᵢⱼ • (xᵢ-yⱼ)`, all four multipliers agree. The theorem explicitly
   has all four cross edges and no same-species edge. It proves I9's signed
   cancellation, forms exactly I10's four coefficients, proves their sum is
   zero, and invokes declaration 1. Its conclusion is
   `l₁₁=l₂₁ ∧ l₂₁=l₂₂ ∧ l₂₂=l₁₂`.

3. **`opposite_skew_line_residuals`**: besides the anchor premise, let
   `x = y₁ + tx • (y₂-y₁)` and `y = x₁ + ty • (x₂-x₁)`; let
   `r = α • (y₂-y₁)`, `s = β • (x₂-x₁)`, and
   `r-s = γ • (x-y)`. The conclusion is
   `α=0 ∧ β=0 ∧ γ=0 ∧ r=0 ∧ s=0`.
   This directly formalizes the second, exceptional case in Section 4.3.
   Both line parameters and the three scalar multipliers are arbitrary.
   There is no nonzero-residual assumption, division, isolated generic case,
   or excluded endpoint. The proof expands the residual equation in the four
   anchor vectors, proves the coefficient sum is zero, and forces each
   coefficient to vanish. The first two coefficients sum to `γ`.

4. **`four_anchor_homothety`**: with the same four-edge and independence
   hypotheses as declaration 2, there exist one scalar `l` and vector `b`
   such that all four vectors are `l • anchor + b`. This is the finite labeled
   conclusion in the final paragraph of Section 4.1, not the conclusion for
   every label in I8. The proof constructs `l=l₁₁`, `b=P₁-l₁₁•x₁` explicitly.

5. **`opposite_skew_direction_not_span`**: for arbitrary points `x,y` on the
   two opposite parameterized anchor lines and arbitrary scalars `a,b`,
   `x-y ≠ a • (x₂-x₁) + b • (y₂-y₁)`. This is I14 as an explicit coefficient
   statement. It follows from declaration 3 by setting the cross multiplier
   to one and obtaining the contradiction `1=0`. It does not require a separate
   geometric picture or an imported assertion that the two lines are skew.

6. **`opposite_skew_lines_disjoint`**: under the same parameterized-line
   premises, `x ≠ y`. This proves the regularity of the exceptional cross edge
   used at the end of that case in Section 4.3. It specializes declaration 5
   to zero coefficients.

## Outside the formal coverage

The following remain mathematical arguments in the frozen authored note, and
are not certified by this Lean packet:

- extraction of a noncoplanar K2,2 anchor and extra velocities from two full
  affine-span images;
- the full labeled-family rigidity theorem I7–I8, including the off-line
  two-direction argument in I12–I13 and the final propagation to every label;
- the other branch in Section 4.3 where the extra B velocity lies off both
  anchor lines;
- the shell implicit-function argument I5–I6, measure/continuity upgrade
  I16–I17, and gradient integration I15–I4;
- domain symmetry, cubic orbit span, current identification and the common
  energy-square coefficient I18–I24;
- hypotheses concerning amplitudes, asymptotic bands, or native physical laws.

No obstruction to the fuller formalization is asserted. This scoped packet
finishes the two requested load-bearing finite arguments and three immediate
geometric consequences. The universal statement for arbitrary labels was not
silently replaced with a finite sample and is not described as Lean verified.

## Concrete controls

`ControlData.lean` proves affine independence of the rational standard
tetrahedron from the library definition. It also applies the universal
four-cycle theorem to explicit nonzero coefficients and translated vectors,
and applies the skew residual theorem at the exact exceptional parameters
`tx=-1`, `ty=2`, with arbitrary residual multipliers.

Its adverse witnesses are themselves proved true before the false controls:
all four square edges with multipliers alternating 2 and 3; three edges of a
noncoplanar tetrahedron with multipliers 1,1,2; a coplanar residual equation
with `α=β=-1/2`, `γ=1`; and a sign-corrupted cycle equal to `(2,-2,0)`.
The separate false files assert the corresponding incorrect equality/zero
conclusion. Correct rejection requires reaching the intended mathematical
goal, not merely an import, parser, timeout, or type error.

These controls distinguish noncoplanarity, completeness of the four-edge data,
skewness, and cycle signs. They do not establish physical hypotheses or add
independence of authorship: the formalization and controls were made by the
same author as the frozen note, while its separate independent review proceeds.
