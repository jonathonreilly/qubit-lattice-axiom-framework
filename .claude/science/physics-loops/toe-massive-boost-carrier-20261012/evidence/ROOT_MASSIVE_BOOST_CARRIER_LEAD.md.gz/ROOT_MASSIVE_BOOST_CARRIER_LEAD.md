# Proposed massive boost carrier route — unverified follow-on

Root research proposal, 2026-10-12. Do not treat this as checked science.
Do not substantially reuse the integrated-covariance candidate until its
fresh source review is complete. The named task is whether actual 1+1 boost
covariance plus geometric translation covariance removes the supplied product
carrier/gauge hypothesis from the centre-regularity theorem.

Use the SAME actual canonical H,P,B and beta>0. Candidate identities are
[H,P]=0 strongly, i[H,B]=P, i[P,B]=beta H, integrated on full generators.
Supply a geometric lattice translation T with T Omega=Omega and canonical
GNS covariance T pi(A)T*=pi(tau_1 A). Do not infer translation invariance of
the state from a simple ground vector within one GNS representation; different
translation-broken ground representations are a separate possibility.

Tasks requiring proof:
1. Derive T B T*=B-H as a FULL self-adjoint equality from the actual weighted
algebra flow and GNS uniqueness. With integrated [P,B] and [H,P], compare this
to exp(-iP/beta) B exp(iP/beta). Identify the correct central mismatch V and
prove it commutes with H,P and B, including signs and domains.
2. On a nonzero positive mass eigenspace of C_beta=H²-P²/beta=M², M>0,
show that boosts preserve the projection and that R=asinh(P/(M sqrt(beta)))
has a genuine Weyl covariance with B. Establish a product carrier including
V's spectral measure, not merely a momentum marginal. A spectral theorem or
imprimitivity argument needs its actual separability/regularity/multiplicity
hypotheses checked; no formal differentiation of generalized eigenvectors.
3. Find a checked gauge identifying actual B with its complete translation
operator in rapidity. Under k=P/beta the expected invariant-measure expression
is B=i E(k) d/dk, and in Lebesgue gauge i(E d/dk+E'/2); both are UNVERIFIED
here and differ in sign/scale from the earlier supplied scalar boost notation.
Derive the normalization, do not silently equate generators.
4. Prove the resulting boost-domain implication for the residual momentum H1
norm on a fixed compact geometric chart and fixed central/lift components,
with legitimate cutoffs, direct-integral multiplicity and zero extension.
Apply the centre-regularity bound only after matching all its vector premises.

Central spectral power rates and actual regular creator density would STILL
be separate obligations: B commuting with V cannot smooth the central spectral
variable by itself. No mass eigenvalue, particle existence, full channel
coverage, rotations, multiboost algebra or higher-dimensional Poincare model
is asserted by this proposed 1+1 route. A singular gauge counterexample must
remain valid unless an actual carrier/gauge equivalence has been established.
