# Bounded target and approach registry

Target: decide whether the actual one-direction integrated boost, with
geometric same-state covariance and a supplied positive nonzero mass atom,
forces a product carrier and an adapted momentum derivative gauge adequate
for the existing centre bridge. Quantifiers cover the full separable mass
subspace, arbitrary central spectral type/multiplicity, and complete
self-adjoint domains. State invariance, mass existence, exact spin-model
realization, central power regularity, qualified-creator density, and other
boosts/rotations are not permitted conclusions without additional proof.

Allowed premises and exact versions are the frozen source notes/reviews in
SOURCE_BINDINGS.json. The initial root lead is a proposal only. Completion
requires actual unitary group identities, a constructive full carrier,
domains and compatible charts/cutoffs, with independent review still pending.
Finite samples, matching formal commutators, smooth marginal measure, or a
new declared primitive do not close the target.

| Family | Object / mechanism | Terminal obligation | Strength | Author status / evidence | Reopen condition |
|---|---|---|---|---|---|
| Regular Weyl classification | Actual rapidity/boost pair; integrated kernel matrix units and nondegeneracy | Full carrier and central commutant, then full Stone domain | Target-equivalent with the preceding actual-covariance step | Candidate proof M5–M35; author controls; independent review pending | A concrete defect in an analytic step, domain or source premise |
| Transitive system of imprimitivity | Spectral measure covariant under rapidity translations; translation orbit and stabilizer | Carrier with compatible central commutant and generator domain | Comparable, not worked out here | Considered, unexecuted; not declared blocked or failed | Execute if needed to repair or independently check the current proof |
| Joint-marginal shortcut | Geometric momentum marginal alone; scalar absolute continuity | A full joint product carrier and ambient derivative gauge | Weaker than target | Frozen centre-note counterexamples show why the weaker premise alone does not supply its conclusion | Add and prove a relevant joint-covariance premise, as the present Weyl route does |

Prasad's Stone–von Neumann theorem and the direct kernel proof are two
presentations of the same classification mechanism, not distinct families.
Different arithmetic controls and different authors do not add mathematical
families. No exhaustive negative-search packet or five-family PASS is claimed.
The exact residual is now actual central-rate-qualified creator density;
boost smoothness alone has the explicit abstract counterexample M42, while
microscopic rate and central-isolation mechanisms remain open.
