# Operational and failed-route history

- 2026-10-12: The first combined instruction read exceeded the tool display
  limit. DISCOVERY and CLAIM_STATUS were subsequently read in complete bounded
  pieces. The combined second-half centre probe plus review display also
  truncated the centre probe's final scope paragraphs; lines 283–325 were
  reread in full. No truncated display is treated as completed verification.
- The initial broad statement search was retained in full on disk. Its
  displayed prefix was only an inventory aid. It returned irrelevant uses of
  “joint carrier”; the relevant Weyl hit was a single-site finite-dimensional
  CCR note, which does not establish the present infinite-dimensional
  representation theorem. The current centre note is the closest supplied
  unresolved bridge, already read as the frozen input.
- Primary-source discovery returned a misleading search excerpt for
  `giuseppe.pdf`: the fetched PDF is Dito's 58-page 2017 lecture deck,
  containing an image of only the first page of von Neumann's paper. The
  bytes and acquisition log are preserved under the initially assigned
  filename `external_raw/von_neumann_1931.pdf`; this filename is erroneous.
  The file is excluded as a mathematical proof source. Opening the Springer
  DOI PDF in the web tool failed. Prasad's original paper is acquired
  separately, with its exact version and metadata, for theorem comparison.
- The baseline control command's displayed output was truncated, and the
  combined proof/baseline/skill read also exceeded the outer tool display
  limit. The complete baseline stdout was then read alone. All mutant
  execution displays were intentionally compact; every changed row,
  including still-passing refinement rows, was subsequently read in two
  bounded full-value reports. The untouched rows were compared exactly
  as JSON objects to the already read baseline by `check_evidence.py`.
- One read used the incorrect relative path
  `sources/proof-search-governance.md` and returned “No such file or directory.”
  An `rg --files sources` inventory supplied the correct snapshot name
  `sources/physics-loop__references__proof-search-governance.md`, which was
  then read in full. No mathematical premise was inferred from the failed read.
- The original 732-line proof was frozen before controls. Root's full coauthor
  read flagged that the cited centre bridge explicitly states isolated mass.
  Five lines before M37 now retain that condition for direct source reuse,
  while distinguishing the carrier/domain/projection results that do not
  require isolation. This is a premise-scope correction, not an alteration of
  the computed formulas. The original proof and final diff are preserved.
- The baseline completed with 84 passing predicates. All eight deliberately
  defective whole-source variants completed with nonzero exit: 15, 6, 6,
  18, 18, 18, 1 and 1 rejected predicates. No scientific runner timeout or
  unexpected baseline failure occurred. Kernel quadrature refinement alone
  remained nondiscriminating on both kernel defects; coordinate-overlap
  comparisons rejected them. Both outcomes remain in the logs.
- Provenance testing retained three separate fixtures. The intact copy
  returned exit 0; a same-size sign-byte alteration and a missing complete
  source returned exit 1 with their actual hash/missing-file reasons.
  The verifier does not import the science source or turn provenance into
  mathematical evidence.
