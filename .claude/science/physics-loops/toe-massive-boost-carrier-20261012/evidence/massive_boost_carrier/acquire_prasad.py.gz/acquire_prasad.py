#!/usr/bin/env python3
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.request

root = Path(__file__).resolve().parent / "external_raw"
root.mkdir(exist_ok=True)
url = "https://arxiv.org/pdf/0912.0574v1"
with urllib.request.urlopen(url, timeout=25) as response:
    body = response.read()
    metadata = {"source_url": url, "final_url": response.url,
                "headers": dict(response.headers), "http_status": response.status,
                "acquired_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body),
                "role": "Primary mathematical source; theorem 4.1 and real-case proof compared with self-contained derivation."}
assert body.startswith(b"%PDF")
(root / "prasad_0912_0574v1.pdf").write_bytes(body)
(root / "prasad_acquisition.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(metadata, indent=2))
