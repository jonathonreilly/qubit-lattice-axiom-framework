#!/usr/bin/env python3
"""Provenance and arithmetic-of-results checks; never imports science code."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def check_record(record, failures):
    path = Path(record["path"])
    if not path.is_file():
        failures.append({"path": str(path), "reason": "missing file"})
        return
    if sha(path) != record["sha256"]:
        failures.append({"path": str(path), "reason": "hash mismatch"})
    if "bytes" in record and path.stat().st_size != record["bytes"]:
        failures.append({"path": str(path), "reason": "size mismatch"})

def manifest_mode(manifest):
    data = json.loads(Path(manifest).read_text())
    failures = []
    for record in data["files"]:
        check_record(record, failures)
    result = {"manifest": str(Path(manifest).resolve()), "checked": len(data["files"]),
              "failures": failures, "valid": not failures}
    print(json.dumps(result, indent=2))
    return 0 if result["valid"] else 1

def summarize(destination):
    failures = []
    runs = []
    baseline = json.loads((ROOT / "controls_initial.json").read_text())
    base_rows = {row["name"]: row for row in baseline["rows"]}
    mutant_info = json.loads((ROOT / "mutants/manifest.json").read_text())
    primary = (ROOT / "controls.py").read_text()
    sources = [("controls_initial", ROOT / "controls_initial.json", None)]
    for mutant in mutant_info:
        path = Path(mutant["path"])
        check_record(mutant, failures)
        if primary.count(mutant["before"]) != 1 or path.read_text() != primary.replace(
                mutant["before"], mutant["after"], 1):
            failures.append({"path": str(path), "reason": "not exact one-defect copy"})
        sources.append(("mutant_"+mutant["name"],
                        ROOT / "mutants" / (mutant["name"]+".result.json"), mutant["name"]))
    for run_name, result_path, mutant in sources:
        run = ROOT / "logs" / run_name
        receipt = json.loads((run / "receipt.json").read_text())
        result = json.loads(result_path.read_text())
        for record in receipt["sources"]:
            check_record(record, failures)
        for stream in ["stdout", "stderr"]:
            check_record({"path": str(run / (stream+".txt")), **receipt[stream]}, failures)
        stdout = (run / "stdout.txt").read_text().splitlines()
        emitted = [json.loads(line) for line in stdout if line.startswith("{")]
        if emitted != result["rows"]:
            failures.append({"path": str(result_path), "reason": "JSON rows differ from full stdout"})
        failed = [row["name"] for row in result["rows"] if not row["passed"]]
        if (result["total"] != len(result["rows"]) or result["failed"] != failed
                or result["fail_count"] != len(failed)
                or result["pass_count"] != len(result["rows"])-len(failed)):
            failures.append({"path": str(result_path), "reason": "counts inconsistent with rows"})
        if not stdout or stdout[-1] != f"TOTAL: PASS={result['pass_count']} FAIL={result['fail_count']}":
            failures.append({"path": str(result_path), "reason": "terminal inconsistent with rows"})
        if receipt["timed_out"] or receipt["exit_code"] != bool(failed):
            failures.append({"path": str(run), "reason": "exit/timeout inconsistent with complete results"})
        if [r["name"] for r in result["rows"]] != list(base_rows):
            failures.append({"path": str(result_path), "reason": "row inventory changed"})
        changed = [r for r in result["rows"] if r != base_rows.get(r["name"])]
        runs.append({"run": run_name, "mutant": mutant, "exit_code": receipt["exit_code"],
                     "timeout_seconds": receipt["timeout_seconds"],
                     "elapsed_seconds": receipt["elapsed_seconds"],
                     "timed_out": receipt["timed_out"], "total": result["total"],
                     "failed": failed, "fail_count": len(failed),
                     "changed_rows": changed})
    report = {"role": "Author provenance check only; no mathematical independence claimed.",
              "failures": failures, "integrity_valid": not failures, "runs": runs,
              "baseline_numerical_maxima": {prefix: max(r.get("error", 0) for r in baseline["rows"]
                  if r["name"].startswith(prefix)) for prefix in ["kernel_rank_one", "kernel_quadrature_refinement",
                      "actual_flat_boost_derivative", "actual_T_boost_derivative", "rapidity_Weyl",
                      "central_mismatch_commutation"]}}
    Path(destination).write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps({"integrity_valid": report["integrity_valid"], "failures": failures,
                      "runs": [{k: v for k, v in run.items() if k not in ["changed_rows", "failed"]} for run in runs],
                      "baseline_numerical_maxima": report["baseline_numerical_maxima"]}, indent=2))
    return 0 if not failures else 1

def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--manifest")
    group.add_argument("--summarize")
    args = parser.parse_args()
    return manifest_mode(args.manifest) if args.manifest else summarize(args.summarize)

if __name__ == "__main__":
    raise SystemExit(main())
