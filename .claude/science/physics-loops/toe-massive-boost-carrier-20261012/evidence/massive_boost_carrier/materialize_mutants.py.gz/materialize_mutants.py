#!/usr/bin/env python3
"""Create complete one-defect sources and exact diffs without executing them."""
import difflib
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / "controls.py").read_text()
changes = {
    "translation_plus": ("TRANSLATION_ENERGY_SIGN = -1", "TRANSLATION_ENERGY_SIGN = 1"),
    "kernel_half": ("KERNEL_FACTOR = 2.0 / math.sqrt(math.pi)", "KERNEL_FACTOR = 1.0 / math.sqrt(math.pi)"),
    "kernel_reverse_shift": ("KERNEL_SHIFT_SIGN = -1", "KERNEL_SHIFT_SIGN = 1"),
    "omit_weight": ("FLAT_WEIGHT_COEFFICIENT = 0.5", "FLAT_WEIGHT_COEFFICIENT = 0.0"),
    "reverse_B": ("BOOST_GENERATOR_SCALE = 1.0", "BOOST_GENERATOR_SCALE = -1.0"),
    "wrong_V": ("MISMATCH_CURRENT_SIGN = 1", "MISMATCH_CURRENT_SIGN = -1"),
    "intersection_domain": ("REQUIRE_ENERGY_IN_DIFFERENCE_DOMAIN = False", "REQUIRE_ENERGY_IN_DIFFERENCE_DOMAIN = True"),
    "wrong_Radon_Nikodym": ("RN_USE_SQUARE_ROOT = True", "RN_USE_SQUARE_ROOT = False"),
}
destination = root / "mutants"
destination.mkdir(exist_ok=False)
manifest = []
for name, (before, after) in changes.items():
    assert source.count(before) == 1, (name, "ambiguous mutation")
    changed = source.replace(before, after, 1)
    path = destination / (name+".py")
    path.write_text(changed)
    diff = "".join(difflib.unified_diff(source.splitlines(keepends=True),
                     changed.splitlines(keepends=True), fromfile="controls.py", tofile=path.name))
    (destination / (name+".diff")).write_text(diff)
    manifest.append({"name": name, "path": str(path),
                     "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                     "before": before, "after": after})
(destination / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
print(json.dumps(manifest, indent=2))
