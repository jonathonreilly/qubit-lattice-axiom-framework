#!/usr/bin/env python3
"""Run one bounded command with immutable evidence, including failures."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

def digest(path):
    p = Path(path).resolve()
    return {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True)
    p.add_argument("--timeout", required=True, type=float)
    p.add_argument("--source", action="append", default=[])
    p.add_argument("command", nargs=argparse.REMAINDER)
    args = p.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        p.error("a command is required")
    if not args.timeout > 0:
        p.error("timeout must be positive")
    root = Path(__file__).resolve().parent
    run = root / "logs" / args.name
    run.mkdir(parents=True, exist_ok=False)
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    begin = time.monotonic()
    receipt = {"command": command, "cwd": str(Path.cwd()), "timeout_seconds": args.timeout,
               "started_at": start, "sources": [digest(s) for s in args.source],
               "python": sys.version, "platform": platform.platform()}
    code = 2
    out = err = b""
    try:
        result = subprocess.run(command, input=b"", capture_output=True, timeout=args.timeout)
        code, out, err = result.returncode, result.stdout, result.stderr
        receipt["timed_out"] = False
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b"", exc.stderr or b""
        code = 124
        receipt["timed_out"] = True
        receipt["exception"] = repr(exc)
    except OSError as exc:
        receipt["timed_out"] = False
        receipt["exception"] = repr(exc)
        err = str(exc).encode()
    receipt.update({"ended_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                    "elapsed_seconds": time.monotonic()-begin, "exit_code": code})
    for label, data in [("stdout", out), ("stderr", err)]:
        (run / (label + ".txt")).write_bytes(data)
        receipt[label] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    (run / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    sys.stdout.buffer.write(out)
    sys.stderr.buffer.write(err)
    print(json.dumps({"evidence": str(run), "exit_code": code,
                      "elapsed_seconds": receipt["elapsed_seconds"]}))
    return code

if __name__ == "__main__":
    raise SystemExit(main())
