# Independent review of the microscopic weighted boost flow

**PASS for the stated conditional theorem at the frozen source.** I found no
material mathematical defect and require no source correction. This is a
source review, not a scientific audit verdict, retained promotion or
construction of a physical Lorentz model.

The complete reviewed note is `MICROSCOPIC_BOOST_FLOW_PROBE.md`, all 758
lines, SHA-256 `7ec1d7eecb4eba020548eba8b56dff66712f52b4eba634ba276dd67440d28de7`.
Its author receipt is SHA-256
`556db66a03600f637ba47663e4faca9202d48baab65cbf81828e08015faa15c9`.
The current premise note and its review were read in full at respectively
`bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`
and `305fa33efebf1e9f9dc09d0854eddf23065877004888f55e964d31cc403f6d17`.
Neither the pending joint-flow work nor a centre-regularity result was used
as a scientific premise.

Root proposed the mechanism and is a coauthor. This reviewer separately read
and reconstructed the complete argument, froze a distinct control, then
inspected the author helper and results. The candidate note itself exposed
the formulas and reported author-control outcomes, so the review was not
blind. It used a separate context with inherited model/effort and no model
override; no cross-family independence is claimed. Root's primary reading is
not counted as independent evidence for this review.

| Load-bearing claim | Source review |
|---|---|
| TWW all-time point-norm flow and p_nu preservation, B5–B10 | Checked against the entire 959-line original TWW TeX and complete macros. The normalized LR kernel has convolution constant at most one, the telescopic interaction has norm at most CDM, and the speed is 2CDM. Both selected decay exponents are infinite, so TWW's finite-nu restriction imposes no loss here. |
| Finite-spin adaptation and generator sign | The TWW and NSY proofs use contractive nested expectations, bimodularity, bounded unitary ODEs and disjoint-support commutation, all valid for tensor factors. The positive generator is i times the local commutator sum. No odd-CAR theorem is imported. |
| Explicit graph approximation and loss, B11–B17 | The nested-expectation estimate, local support/counting bound and dyadic geometric sum yield exactly q>nu+d+kappa. Thus d+2 integer loss suffices for boosts, d+1 for energy/current. The extension agrees with the absolutely convergent weighted commutator series. No endpoint is asserted. |
| Closed-generator inclusion and actual C1 flow, B18–B21 | Local graph approximants and closedness put every rapid-AL element in the C*-generator domain. Interpolation upgrades norm continuity to each seminorm; Frechet integration then establishes differentiability. Bounded seminorms alone are not mistaken for continuity. |
| Local state identity to invariant GNS implementation, B22–B26 | The identity extends by graph convergence, applies to the actual evolved rapid-AL observable, and integrates to invariance. The canonical action respects GNS null vectors and is strongly continuous. Full adjoint implementation follows on dense cyclic vectors without vacuum separation. |
| Supplied self-adjoint operator identification, B27–B29 | Closedness extends its local action to rapid AL. The actual orbit solves a C1 Hilbert-space Schrödinger equation; a product difference quotient makes exp(-is Btilde)xi(s) constant. Dense-column equality identifies the complete self-adjoint operators. No local-core or analytic-radius assertion is assumed. |
| Canonical H/B/P and current sign, B30–B37 | The finite padded identity gives [delta_h,delta_b]=delta_p. B3/B4 imply the current state identity, hence construct P. Locality establishes invariant D before products are taken, and i(HB-BH)=P there has the displayed sign. The negative momentum clock divides by beta exactly once. |
| State and approximation counterexamples, section 9 | The telescoping density is stationary and translation invariant in the X-product state but has omega(delta_b Y_0)=2. It refutes dropping B3 under the stated premises. The norm-null sequence with derivative norm 2 is not graph convergent and does not contradict closedness. |

The primary literature examined was [TWW, arXiv:2511.02941v2](https://arxiv.org/abs/2511.02941v2),
main TeX SHA-256
`bd67842f411193b3727a1d90aa7c47573c1db63e4b58a3a8d8bcf57ad5d4be0d`,
and the preamble and complete Section 3 of
[NSY, arXiv:1705.08553v3](https://arxiv.org/abs/1705.08553v3), TeX SHA-256
`291568f356212c003993ac38e719292c202f7afc2c58b591ac96c0ce32dbe722`.
These were local original-source snapshots; no fresh network acquisition is
claimed. The two TWW literal issues disclosed in the note are real: its
local-observable corollary needs an enlarged norm-plus-tail constant, and its
appendix first cutoff-tail term needs radius k/2. The note handles both
correctly. For the finite-range hypothesis the generator even stabilizes
exactly once k/2 is at least L+R. An independent finite-range cutoff estimate
in the reconstruction recovers all polynomial rates directly from the LR
bound and avoids the faulty appendix radius line.

The distinct decisive control is an infinite trace-GNS example:
`h_x=Z_x`, `A=sum_(n>=1) exp(-sqrt(n)) X_n`. The observable is rapid AL,
its actual flow is C1 and its local approximants converge in graph norm, but
`r^k ||B^k A Omega||/k! >= (8 r exp(-2) k)^k` for every r>0.
Thus it has zero analytic radius. This demonstrates why finite-dimensional
analytic-vector checks cannot replace the graph/C1 proof. It does not claim
that local vectors in this example are nonanalytic.

A separate exact sparse-Pauli implementation checks the local current on
all 64 words of a disconnected three-site seed. The independent canonical
run had 71 passing predicates; sign reversal, omitted displacement and
insufficient padding each failed on all 63 nonidentity probes. A spectral
finite-difference control converged with ratios approximately 1.9993, 1.9998
and 2.0000; reversed clock and omitted spatial weight instead plateaued.
All five mutations exited 1. The infinite-domain conclusion comes from the
written spectral proof, not these finite computations.

I also read the complete 268-line author helper and 63-line logger. An
unmodified copy reproduced all 49 canonical rows and all four mutation
runs byte for byte in stdout; result JSONs differed only in timestamps.
The mutations reproduced 13, 12, 6 and 2 failed predicates. Their
nondiscriminating checks remain explicit: norm preservation accepts the
wrong clock; full adjoint implementation accepts a left-only GNS action;
the finite dyadic upper bound is loose. The cyclic-vector/local-action and
actual-orbit derivative tests detect the relevant GNS defects. The earlier
weak C1 gate and initial log collisions remain preserved as history.

All eleven review science runs have declared timeouts, exact commands,
source bindings, complete streams and elapsed/exit receipts. The independent
canonical and author replay used 60-second limits and completed in about
0.870 and 0.510 seconds. Mutations used 30-second limits. All 103 unique
file identities in the author receipt matched. These provenance checks do
not establish the mathematics; the complete reconstruction and control
analysis do that work within the stated conditional scope.

The theorem removes separately supplied self-adjoint B/P existence,
their local cyclic actions and the local current closure once B1/B3/B4 are
given. The density and same-state identities remain supplied conditions.
Positive energy, physical state selection, the remaining joint Lie/strong
commutation relations, integrated Lorentz/Poincare representation, particles,
scattering and centre/regular-target identifications are not derived.
The premise counterexamples are narrow controls, not universal no-go claims.

This was one source-review iteration: zero material findings, zero fixes and
zero skipped findings. The proof disposition is **CONDITIONAL**, with
disclosed literature and supplied-model inputs. Source status language
respects the propose/ratify boundary. Repository discovery/link wiring,
combined pipeline, strict lint, changed-evidence checks and any later
publication are root's integration work; none was run or certified here.
No claim ID or audit verdict was created. The review grants no Nature-grade
retention or audit readiness of an unexamined repository candidate.

Recovery and complete evidence are under `microscopic_boost_flow_review/`,
especially `INDEPENDENT_RECONSTRUCTION.frozen.md`, `CONTROL_FREEZE.md`,
`CONTROL_REVIEW.md`, `source_manifest.final.json`, `receipt.json` and the
per-run `logs/` receipts. Instruction authority was the supplied main
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; planning bytes matched
`3d409e93abb3b58796a9c10ca6d21ba93b7edc73b8fb24e7364da97c805580a9`.
The checkout's `FIXES_AND_REPORTING.md` hash `8fdc997ce173...` was used,
not the different installed distribution.

Only this review and its assigned evidence directory were written. Frozen
sources, editable prompts, axioms, audit state, repository files and Git refs
were unchanged; no PR action, other-chat message or subdelegation occurred.
Formalization was not run. Changed scientific source or premises require
affected-source confirmation in this reviewer session. Campaign deadline:
2026-10-12 16:00:52 UTC.
