# Reviewer control refinement

2026-10-12T08:14:43.389575+00:00

The first independent baseline had 64 passing predicates. Cold source inspection identified that its three constructed tensor commutators commute by construction for any kernel matrix, so they did not test commutant classification. They are not used as scientific evidence. The initial complete source, source pins, all nine executions and every row remain preserved. Before inspecting author helpers, replace those three rows by a finite cyclic Weyl group average of an arbitrary full matrix, compared with an independently computed multiplicity partial trace. Add a whole-source omission of the translation average. This finite analogue tests a relevant classification defect; the continuum factorization remains a written-proof conclusion. All final variants will be rerun because the control source changed.
