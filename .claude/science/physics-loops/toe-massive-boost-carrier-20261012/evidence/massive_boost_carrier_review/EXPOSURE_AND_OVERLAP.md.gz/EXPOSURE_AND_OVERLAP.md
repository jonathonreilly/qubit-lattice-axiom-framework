# Exposure and actual method overlap

The reviewer used the inherited selected model and reasoning effort in a
separate context of the same model family. There was no model override or
subdelegation. This was not blinded: parent supplied the claim and concerns;
the entire target, including M41 and the author's control descriptions, was
read before the independent reconstruction was frozen. Root is a coauthor.
The raw author helper, results, streams and operational history were read only
after that freeze and after the reviewer controls had been implemented.

The freeze receipt is `independent_freeze_receipt.json`, at
2026-10-12T08:06:44.929490+00:00. The reviewer control refinement at
2026-10-12T08:14:43.389575+00:00 preceded author helper inspection too.
Copying and reading author evidence began at the snapshot timestamp
2026-10-12T08:15:33.739668+00:00. These timestamps describe exposure ordering,
not a measure of mathematical independence.

The freeze anticipated that a rapidity profile `g(r)=sqrt(sech r)` would be a
distinct domain witness. That is incorrect as a claim of mathematical
distinctness: with M=beta=1, k=sinh(r), the author's current-coordinate
profile `(1+k^2)^(-1/4)` is exactly `sqrt(sech r)`. The invariant/current and
rapidity Hilbert spaces differ by the displayed constant normalization. The
reviewer's direct cutoff integrals and parameter choices independently check
the cancellation calculation, but they do not add a different counterexample
family. The freeze is preserved without retroactive editing; this comparison
corrects the final evidential classification.

The finite cyclic Weyl transform on arbitrary nonsymmetric matrices differs
from the author's continuum Gaussian phase-space quadrature. The full-matrix
Weyl average compared with a separate partial trace challenges commutant
factorization; it replaces three initially tautological tensor commutators.
The compact-polynomial matrix-element integration tests symmetry instead of
the author's finite-difference boost pullback. The continuous central density
`dtheta/[theta log(1/theta)^2]` differs from the atomic sequence in measure class,
but expresses the same scoped nonimplication, not an additional independent
physical wall. The rational Radon–Nikodym controls are direct finite checks of
the same square-root isometry mechanism.

All these methods still share the target formulas and premises. Reconstructed
proof, different calculations and useful mutations add scrutiny; hashes,
different filenames, separate contexts and larger row counts alone do not
establish independence. The proof's strongest load-bearing infinite-dimensional
steps were checked analytically, not inferred from finite diagnostics.
