# Failures, survivors and verification limits

No scientific baseline failed unexpectedly or timed out. The failures below
are retained rather than converted into a cleaner-looking history.

- The parent first named `massive_boost_carrier/manifest.json`. The initial
  hash command returned exit 1 because that path does not exist. Parent
  corrected it to `evidence_manifest.json`, whose supplied SHA-256 matched.
  `source_manifest.json` is a different file with a different supplied digest.
  This was an operational naming mistake, not altered scientific source.
  Initial exploratory filesystem/instruction reads were tool calls, not
  separately timed scientific subprocess runs; their full terminal transcript
  is not repackaged as a nonexistent logger receipt. All scientific controls,
  replays, guard tests and closing packet checks have preserved run logs.
- Combined instruction, review and metadata displays exceeded tool output
  limits. Missing instruction portions were reread; the Centre review was
  reread alone in full. The statement-search omission was repaired with bounded
  line reads. All 27 source-binding records were emitted separately in compact
  form after a long repeated-metadata display truncated. A truncated display
  is not counted as completed verification.
- The first reviewer baseline included three constructed tensor commutators
  that commute for any kernel by construction. They do not test classification
  and are not used as scientific evidence. Before author helper inspection,
  they were replaced by Weyl averaging of an arbitrary full matrix compared
  with a separate multiplicity partial trace. Both full versions, their
  complete runs, and all initial rows are preserved. `CONTROL_REFINEMENT.md`
  explains the correction; 61 unchanged rows are exactly matched across the
  two versions and corresponding variants.
- Nine final reviewer whole-source mutations exited 1. The failed predicate
  counts are 12, 12, 12, 6, 12, 9, 6, 2 and 3 in the declared manifest order.
  Their 89 changed rows include 15 still-passing rows, all inspected. A real
  scalar kernel factor preserves adjoints; the reversed Fourier phase still
  reconstructs the identity; the current commutator does not detect the
  half-density term; a loose norm bound may survive its omission; reversing
  the generator preserves symmetry and the norm bound. No one passing
  invariant is treated as validating the complete operator.
- The frozen plan called the rapidity domain witness distinct from the
  author's described current-coordinate example. Full comparison shows that
  `sqrt(sech r)=(1+k^2)^(-1/4)` when M=beta=1 and k=sinh(r), up to the
  constant relating the Hilbert-space normalizations. It is the same witness
  in other coordinates. The original freeze is left intact, but the final
  report counts this only as a reconstructed calculation. The genuinely
  different finite-kernel, commutant, matrix-element and continuous-measure
  controls do not rely on treating it as a new counterexample family.
- The author's eight source mutations exited 1, with 15, 6, 6, 18, 18, 18, 1
  and 1 failed predicates. All 95 changed rows were read, including the 12
  kernel-refinement survivors. Convergence of quadrature for a wrong formula
  is not correctness; the separate coordinate-overlap comparisons detect
  those two defects. No extra author-mutation replay was needed after full
  source/diff/stream inspection and the distinct reviewer controls.
- The preserved author history records a misleading acquisition: a file
  initially named `von_neumann_1931.pdf` is actually Dito's 58-page lecture
  deck. The author excludes it from proof evidence and records an unsuccessful
  Springer PDF open. The latter is a narrative history entry, not a local
  subprocess receipt. This reviewer does not claim to have read either PDF
  or Prasad's paper. The kernel proof is self-contained.
- The author preserved a wrong relative instruction-file read and subsequent
  corrected full read, and retained all original proof bytes. The complete
  original/final source comparison shows the five-line isolated-mass
  qualification before M37 plus appended evidence/status sections. No other
  old proof line was deleted or replaced. Root's correction is a coauthor
  contribution, not independent review.
- The author's broad 109-line statement-search stream and receipt are
  preserved and read. Its receipt records command, return code, timeout and
  stdout digest, but not actual elapsed/start/end time. Those historical
  timings are unavailable; none was invented. Irrelevant search matches do
  not establish novelty or exhaustion.
- Reviewer provenance fixtures deliberately reject a same-size source change,
  a missing source and a rewritten manifest against an external manifest pin.
  The intact fixture and final real source pins pass. These are provenance
  controls, not independent science checks.

Finite controls cannot prove strong continuity, infinite-dimensional
nondegeneracy, maximal self-adjoint domains, disintegration or creator density.
Those are checked in the written argument. The finite cyclic Weyl system is
explicitly an analogue on a finite group; it is not a finite-dimensional
regular real-line Weyl representation.

Actual microscopic realization of the common Lie/state package, geometric
same-state invariance, positivity and nonzero mass are supplied conditions.
Mass isolation is retained for direct G1–G7/M37 reuse and the exact-mass
operator filter. Rate-qualified almost-local creator density and a positive
central power rate remain unproved. The abstract counterexamples do not prove
a lattice-wide physical impossibility.

The review is same-family, separate-context and non-blinded. The candidate's
control descriptions were visible before the independent freeze; raw author
helpers/results were first read afterwards. Parent is a coauthor. There was
no model/effort override, subdelegation, other-chat message, repository write,
PR/merge/push, applied audit or retained-status action. Read-only local Git
identity queries were made; no remote fetch/freshness claim is made. Editable
prompt files changed: none.
