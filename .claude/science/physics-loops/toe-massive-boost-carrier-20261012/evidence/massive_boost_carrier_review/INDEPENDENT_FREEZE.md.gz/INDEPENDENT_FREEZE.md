# Independent reconstruction before author helpers

Frozen source: `target.md`, SHA-256
`eb85ee2fda1690373e7bb7bdf96bc255e86235d672e8e9f18e46c6553078e310`.
Instruction authority: `a13caa4885f547c8d206265b031ba7649e539fd9`.
This record is to be frozen, hashed and retained before reading any author
helper, result JSON, stdout/stderr or operational-history file. The complete
target note, including its aggregate control descriptions and counts, has
already been read. Its four actual mathematical source notes have also been
read completely; their identities are in `premise_manifest.json`.

The review uses a separate context of the same model family. It is not
blinded, and the supplied target and concerns are shared exposure. No model
override, subdelegation or independent-family claim is made. Root is a
coauthor. These checks will not confer formal retained or audit status.

## Reconstructed implication

### Geometric conjugation and complete domains

Write the three derivations as h, p and b, with positive implementation
clocks. Translation of the weighted density sends its coefficient x_b to
x_b-1. Thus on the local algebra,

    tau b tau^-1 = b-h,
    tau h tau^-1 = h,    tau p tau^-1 = p.

The current is the actual translated finite commutator expression, so its
geometric covariance is available. A fixed shift is continuous on the
rapid-almost-local Frechet algebra F. The supplied finite-loss graph
approximation extends all these identities to F. Its actual current flow
has C1 F-valued orbits, so differentiating the conjugate derivation gives

    rho_u b rho_-u = b + beta*u*h.

The two existing groups tau lambda_s tau^-1 and
rho_-1/beta lambda_s rho_1/beta consequently have equal generators on F.
Their F-orbits are classical solutions for the other existing Banach-space
group generator. Differentiating the inverse group times that curve proves
equality. This is not uniqueness inferred from an arbitrary dense domain.

The separately supplied same-state geometric invariance gives the canonical
unitary T fixing Omega. Every factor in the preceding identity fixes Omega;
its action on pi(A)Omega therefore identifies the full bounded unitaries:

    T exp(isB) T* = exp(-iK) exp(isB) exp(iK),  K=P/beta.

Stone uniqueness gives S=TBT*=exp(-iK)Bexp(iK), with exact domain
exp(-iK)Dom(B). S agrees with B-H on the local cyclic domain D.
To justify the closure rather than merely a restriction, D_infinity=pi(F)Omega
is invariant under the conjugated group and contained in Dom(S). For xi in
D_infinity, Riemann sums of exp(-t)exp(itS)xi approximate its resolvent
(1-iS)^-1 xi in S graph norm: the graph integrand is continuous and has
an integrable norm bound. Density of D_infinity and boundedness of the
resolvent into the graph domain show D_infinity is a core. The simultaneous
local graph approximation for b and h then makes D a core for S.

Under positivity, the integrated covariance puts joint spectrum in
|P|<=sqrt(beta)H and gives Dom(H) subset Dom(P). The exact identity

    exp(isS)=exp(-i d_s H) exp(i(c_s-1)P/beta) exp(isB)

has derivative i(B-H)xi on Dom(B) intersection Dom(H), because d_s/s tends
to one and (c_s-1)/s tends to zero. This proves that algebraic difference
is a restriction of S. Containing the already established core proves its
closure equals S; the intersection itself need not equal Dom(S).

Since T commutes with the H and P groups, V=exp(iK)T commutes with both.
The conjugation equality makes VBV*=B on the complete domain. V therefore
belongs to the commutant of these three groups, not necessarily the centre
of the represented observable algebra.

### Fixed mass, the Weyl relation, and product multiplicity

The joint-spectral Casimir is boost invariant. Its nonzero projection at
M^2 reduces the groups. With H>=0 and M>0, define

    R=asinh(P/(M gamma)), H=M cosh R, P=M gamma sinh R,
    gamma=sqrt(beta).

The integrated P formula gives W(s)RW(s)*=R-gamma*s by spectral functional
calculus. Consequently U(a)=W(a/gamma), Z(t)=exp(itR) obey
U(a)Z(t)=exp(-iat)Z(t)U(a) for all real parameters, with strong continuity.
The fixed mass need not be isolated for these statements.

The central carrier step can be reconstructed directly from the integrated
Weyl relation. For a Schwartz kernel L define its diagonal-coordinate
Fourier coefficient l(t,a)=integral exp(-itx)L(x,x-a)dx and use the
strong integral A(L)=(2pi)^-1 integral l(t,a)Z(t)U(a)dt da. The L1 bound
controls its operator norm. Multiplication of two integrals gives the
twisted convolution phase exp(-ia(q-t)); inverse Fourier transformation
identifies this with composition of integral kernels. The adjoint phase
is exp(-iat), giving A(L)*=A(L*).

Rank-one kernels therefore obey the exact matrix-unit law. This law alone
does not prove a nonzero or nondegenerate representation. An approximate
identity in the coefficient variables, of integral 2pi, converges strongly
to I by strong continuity and dominated convergence. Finite sums of
separated Schwartz functions approximate its inverse-transform kernel in
Schwartz topology: use smooth product cutoffs and rapidly convergent double
Fourier series on a containing square. The L1 coefficient bound turns
this into operator-norm approximation. Hence the matrix-unit ranges span
dense space.

For a unit Schwartz vector h, P_h=E_h,h is a nonzero projection. If P_h
vanished, the matrix-unit relations would annihilate E_g,h and then E_g,g
and every rank-one image, contradicting nondegeneracy. Let N=P_h H_M.
The map f tensor xi -> E_f,h xi is isometric by the matrix-unit law.
Its range contains every E_f,g range, so it extends onto H_M.
Left multiplication by Z and U identifies the two actual groups with
modulation and translation on the full real line. Operators commuting
with both commute with all E_f,g; in particular V acts as I tensor v.
The same reasoning applied to a unitary intertwiner rules out any residual
rapidity-dependent change of gauge between adapted carriers.

This proof establishes multiplicity and regularity; it does not declare a
Stone-von Neumann classification as an unexplained hypothesis. I do not
need to use Prasad's paper to check it. Its author citation is not a claim
that this reviewer independently read that paper.

### Central disintegration and derivative normalization

The cyclic GNS space is separable, since the countable-site spin algebra
has a countable norm-dense subset. So does the closed space N. Decompose
the unitary v into countably many reducing cyclic subspaces with probability
measures mu_j. With positive summable b_j, nu=sum b_j mu_j is a finite
control measure. The Radon--Nikodym map is multiplication by sqrt(w_j),
not w_j. Its range consists precisely of the l2 components supported
where w_j>0. These closed fibres are measurable and independent of r.
Fubini yields L2(dr dnu;N_theta), with V=e^(i theta).

W(s)g(r,theta)=g(r-gamma*s,theta). Fourier transformation in r gives
B=i gamma partial_r with full H1 domain. No half-line extension or
momentum-dependent multiplicity has been hidden. Change to k=(M/gamma)sinh r,
so dr=gamma*dk/E and psi=sqrt(2gamma)g. The invariant measure is dk/(2E).
The full generator becomes iE partial_k, with distributional domain
E partial_k psi in invariant L2.

After f=psi/sqrt(2E), the full generator is i(E f'+E'f/2).
Since |E'|<=gamma, its domain is equivalent to E f' in flat L2.
The inverse formula is

    f'=(-i/E)J_w B psi - beta*k*f/(2E^2).

The exact multiplier maximum is gamma/(4M), attained at |k|=M/gamma.
This gives ||f'|| <= ||B psi||/M + gamma||psi||/(4M). It establishes
ordinary H1 only in the adapted gauge just constructed.

T=e^-ik V fixes Q=k-theta modulo 2pi. On a declared chart and fixed lift
k=p+theta+2pi*n the Jacobian is one and the multiplicity constraint remains
p independent. A bounded central multiplier q(theta) and a smooth compact
momentum cutoff chi(p) preserve Dom(B), because E partial_k m is bounded
on their fixed compact k support. The zero extension across the p chart
is H1 because the support is strictly interior. Applying the preceding
bound before the cutoff gives exactly the M35 terms, including ||chi'||.

### Consequences and separately retained hypotheses

The centre bridge's G1--G7 are now matched in dimension one once its
isolated-mass condition and the actual vector's positive-power central
rate are additionally supplied. Splitting at central radius r gives
C^2 r^(2a)+epsilon S_ell^2/(c ell r); choosing
r=r0(epsilon/(c ell r0))^(1/(2a+1)) gives M37. No rate is proved merely
from boost membership. The alternative affine-slab coefficient beta/E_*
also matches the source proof.

For fixed off-target theta, equality of the two squared massive energies
has one p solution. Product Lebesgue/central measure makes that set null
by Fubini, proving M38 even without a rate or H1. A nonempty open current
interval has a nonzero projection on the scalar L2 factor; tensoring with
a nonzero central projection is nonzero, proving M39. These statements
remain limited to the fixed mass and, for M38, the selected chart/lift.

Local columns lie in Dom(B), and reducing mass projection preserves it.
When the mass is isolated, the fixed smooth H/K filter of I18--I19 gives
the actual almost-local column h(K)Pi_M A Omega. Its compact k multiplier
preserves the boost domain. The already proved fixed central/geometric
operator filters preserve their stated properties; a sharp vector lift
projection is not asserted to be an almost-local operator operation.
Rate-qualified creator density remains the separate G24 obligation.

## Anticipated failures and distinct control plan

1. Wrong shift sign or missing beta in the geometric/current comparison.
   Independently derive the transport/conjugation identities on actual
   rapidity test functions and include wrong-sign whole-source variants.
2. A degenerate kernel representation, wrong 2pi factor or wrong translation
   sign. Test a finite cyclic Weyl transform on arbitrary complex matrices
   against direct matrix kernels, including composition, adjoint and
   nondegeneracy. This discrete Fourier reconstruction is distinct from
   the author's described continuum phase-space quadrature; it cannot
   establish the infinite-dimensional theorem by itself.
3. Omitted half-density term. Test symmetry of the proposed flat generator
   through independent integration of its matrix elements on compact
   polynomial profiles, and verify its current commutator. This does not
   reuse the author's described finite difference of a boost pullback.
4. Intersection-domain substitution. Use g(r)=sqrt(sech r) and
   psi(r)=exp(-i k(r))g(r). Its L2 norm is pi, its boost norm squared is
   beta*pi/8, while its energy norm diverges. Derive exact cutoff integrals
   and the S cancellation. This is a distinct rapidity-domain witness.
5. Incorrect Radon--Nikodym factor. Check an explicit rational finite
   central multiplicity system and inactive components against the
   original cyclic norms. Compare sqrt(w) with w in a whole-source mutant.
6. Overclaimed central rates. Use the continuous probability measure
   dtheta/[theta log(1/theta)^2] on (0,e^-1]. Its near-zero mass is
   1/log(1/r). Tensor it with a compact smooth current vector to obtain
   all boost powers but no positive central or geometric power rate.
   This differs from the author's discrete atomic example and is a
   scoped abstract representation witness, not a microscopic model.
7. Source substitution/tamper controls. Materialize complete variants of
   the reviewer-owned helper and retain exact diffs, stdout, stderr,
   elapsed time and declared real subprocess timeouts. Pin all target and
   helper bytes before execution; missing or altered source must fail
   closed before scientific controls. Inspect every baseline and changed
   row, including survivors. Counts and hashes are provenance only.

After this freeze, read the complete author helper/logger/provenance source,
all baseline and changed mutation rows, all preserved failures and
operational history. Replays, if useful, must write only to reviewer-owned
paths. Avoid redundant reruns whose only purpose is to add PASS lines.

## Current provisional assessment

No mathematical defect has been identified in the reconstructed implication.
This is not the final review result: controls, author evidence inspection,
final source revalidation and exact scope synthesis are still pending.
The actual density/state/Lie package, geometric same-state invariance,
positive nonzero mass sector, and application rate/density conditions are
not derived by this note. The construction is one-directional. Physical
realization, scattering completeness and TOE completion are not conclusions.
