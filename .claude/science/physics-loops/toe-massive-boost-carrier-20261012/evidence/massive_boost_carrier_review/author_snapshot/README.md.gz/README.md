# Massive boost carrier author evidence

The requested note is `../MASSIVE_BOOST_CARRIER_PROBE.md`.
`FINAL_NOTE.md` is its exact final snapshot. `receipt.json` binds that note
to `evidence_manifest.json`, the complete sources, controls, execution and
read records. Source acceptance and author calculations are conditional;
a fresh independent proof review remains required.

The analytic proof was frozen before the controls were written.
`PROOF_BEFORE_CONTROLS.md`, `PROOF_FREEZE.json` and `PROOF_CHANGES.diff`
preserve that history. The substantive post-freeze amendment explicitly
retains isolated mass when reusing the old bridge's stated quantitative
theorem. No such extra condition is imposed on the new carrier theorem.

`controls.py` is the complete author diagnostic. `mutants/` contains
complete one-defect sources, exact diffs and full result JSON. Every run's
exact command, closed stdin, real timeout, complete output and source/output
hashes are in `logs/<run>/`. `control_report.json` preserves all changed
rows, including nondiscriminating but still-passing rows. No finite-count
proof or model construction is claimed.

The source-independent provenance checker can be run here as:

```text
python3 check_evidence.py --manifest evidence_manifest.json
```

This reads and checks all inventoried bytes; it does not check the proof.
For scientific reproduction use the exact commands in the execution
receipts in a separate scratch copy, giving each new log a fresh name and
never replacing this frozen evidence. `run_logged.py` rejects reused names.
The intentionally bad whole-source mutants exit nonzero. The intact,
same-size-altered and missing-source provenance fixtures are separate files
under `tamper_fixtures/`; their recorded results are retained in `logs/`.

The manifest excludes only its own file, the receipt and their final
freeze/verification log directories to avoid circular hashes. The final
receipt explicitly declares those exclusions; its own SHA is reported at
handoff. Missing target files inside the intentional missing-file fixture
are not real lost evidence: its manifest and rejection log preserve the
test.

`EXTERNAL_RAW_INVENTORY.json` lists URLs, hashes and read scopes. The two
PDFs in `external_raw/` are research reference bytes, outside publication.
The file named `von_neumann_1931.pdf` is actually a Dito lecture deck;
its original wrong name and acquisition script are retained as failure
history, and it is excluded as a mathematical proof source. Prasad's
versioned primary paper is the actual theorem comparison.

No repository files, prompts, axioms, audit statuses, PRs or publications
were changed by this worker. The packet records no five-family no-go PASS.
