#!/usr/bin/env python3
"""Acquire the original primary paper as context, outside publication."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.request

root = Path(__file__).resolve().parent / "external_raw"
root.mkdir(exist_ok=True)
url = "https://www.lpthe.jussieu.fr/~dito/benin2017/files/giuseppe.pdf"
request = urllib.request.Request(url, headers={"User-Agent": "mathematical-source-check/1.0"})
with urllib.request.urlopen(request, timeout=25) as response:
    body = response.read()
    metadata = {"source_url": url, "final_url": response.url,
                "headers": dict(response.headers), "http_status": response.status,
                "acquired_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body),
                "role": "Historical comparison; self-contained kernel proof is supplied in the note."}
assert body.startswith(b"%PDF"), "Unexpected response: original PDF not acquired"
(root / "von_neumann_1931.pdf").write_bytes(body)
(root / "acquisition.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(metadata, indent=2))
