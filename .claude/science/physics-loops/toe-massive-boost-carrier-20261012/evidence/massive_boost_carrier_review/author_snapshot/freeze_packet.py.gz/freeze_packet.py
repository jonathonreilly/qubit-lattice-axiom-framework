#!/usr/bin/env python3
"""Freeze this author packet without modifying any upstream or repository file."""
import datetime as dt
import difflib
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
NOTE = ROOT.parent / "MASSIVE_BOOST_CARRIER_PROBE.md"

def record(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data)}

def write_json(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2)+"\n")

def main():
    for name in ["evidence_manifest.json", "receipt.json", "FINAL_NOTE.md"]:
        if (ROOT / name).exists():
            raise RuntimeError("Refusing to replace frozen artifact: "+name)
    bound = json.loads((ROOT / "SOURCE_BINDINGS.json").read_text())
    if bound["failures"]:
        raise RuntimeError("Source bindings contain unresolved failures")
    for entry in bound["source_bindings"]:
        for key in ["source", "snapshot"]:
            if record(entry[key])["sha256"] != entry["sha256"]:
                raise RuntimeError("Source changed since bounded read: "+entry[key])
    proof = (ROOT / "PROOF_BEFORE_CONTROLS.md").read_text()
    final = NOTE.read_text()
    (ROOT / "FINAL_NOTE.md").write_bytes(NOTE.read_bytes())
    (ROOT / "PROOF_CHANGES.diff").write_text("".join(difflib.unified_diff(
        proof.splitlines(keepends=True), final.splitlines(keepends=True),
        fromfile="PROOF_BEFORE_CONTROLS.md", tofile=NOTE.name)))
    covered_scripts = ["controls.py", "run_logged.py", "materialize_mutants.py",
                       "check_evidence.py", "prepare_tamper.py", "prepare_source_bindings.py",
                       "freeze_packet.py", "acquire_reference.py", "acquire_prasad.py"]
    write_json("READ_COVERAGE.json", {
        "role": "Author read record, not independent review.",
        "source_coverage": "SOURCE_BINDINGS.json records complete note/instruction reads and explicit upstream-evidence limits.",
        "proof": {**record(NOTE), "lines": final.count("\n"),
                  "coverage": "Complete original sections 1-8 read in bounded pieces; five-line M37 qualification and complete sections 9-10 read after amendment."},
        "complete_authored_source_reads": [record(ROOT / name) for name in covered_scripts],
        "controls": {"baseline": "All 84 full result rows and all five scope lines read.",
                     "mutants": "All changed rows read with their full values; exact comparison identifies the unchanged baseline rows. Full materialized sources verified against the complete primary plus the declared one-line defect.",
                     "provenance": "Tamper fixtures, all their results, and source/output binding results read.",
                     "independence": "Same author context; root coauthor read is also not independent. Fresh reviewer still required."},
        "literature": "EXTERNAL_RAW_INVENTORY.json gives exact read sections and preserves the excluded misidentified PDF.",
        "truncated_outputs": "Not counted as completed reads; repaired as described in OPERATIONAL_HISTORY.md."})
    versions = {name: importlib.metadata.version(name) for name in ["numpy", "scipy", "sympy"]}
    write_json("ENVIRONMENT.json", {"python": sys.version, "platform": platform.platform(),
               "packages": versions, "model_effort": "Inherited selected model/effort; no override or subdelegation used. No model-family independence claimed."})
    execution = []
    for path in sorted((ROOT / "logs").glob("*/receipt.json")):
        receipt = json.loads(path.read_text())
        for stream in ["stdout", "stderr"]:
            actual = record(path.parent / (stream+".txt"))
            if actual["sha256"] != receipt[stream]["sha256"] or actual["bytes"] != receipt[stream]["bytes"]:
                raise RuntimeError("Execution output changed: "+str(path))
        for entry in receipt["sources"]:
            if record(entry["path"])["sha256"] != entry["sha256"]:
                raise RuntimeError("Executed source changed: "+entry["path"])
        execution.append({**record(path), "command": receipt["command"],
                          "elapsed_seconds": receipt["elapsed_seconds"],
                          "timeout_seconds": receipt["timeout_seconds"],
                          "timed_out": receipt["timed_out"], "exit_code": receipt["exit_code"]})
    write_json("EXECUTION_INVENTORY.json", execution)
    exclusions = ["evidence_manifest.json", "receipt.json", "logs/freeze_packet/", "logs/verify_packet/"]
    files = [NOTE]
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT).as_posix()
        if any(relative == item or (item.endswith("/") and relative.startswith(item)) for item in exclusions):
            continue
        files.append(path)
    manifest = {"scope": "All existing packet files plus the external note; explicit self/final-verification log exclusions avoid circular hashes.",
                "excluded": exclusions, "files": [record(path) for path in files]}
    write_json("evidence_manifest.json", manifest)
    controls = json.loads((ROOT / "control_report.json").read_text())
    receipt = {
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "note": record(NOTE), "manifest": record(ROOT / "evidence_manifest.json"),
        "file_count": len(files), "source_bindings": record(ROOT / "SOURCE_BINDINGS.json"),
        "original_proof": record(ROOT / "PROOF_BEFORE_CONTROLS.md"),
        "original_proof_pin": json.loads((ROOT / "PROOF_FREEZE.json").read_text()),
        "proof_changes": record(ROOT / "PROOF_CHANGES.diff"),
        "complete_execution_inventory": record(ROOT / "EXECUTION_INVENTORY.json"),
        "scientific_result": "Author conditional proof: actual massive product carrier and adapted boost Sobolev gauge. Requires source hypotheses, explicit geometric state invariance, positivity and nonzero mass eigenspace; quantitative prior bridge additionally retains isolation.",
        "open_obligations": ["Actual central power regularity", "Density of actual creators satisfying that rate and declared support/transfer conditions", "Microscopic density/state/mass existence or realization is not established"],
        "controls": {"report": record(ROOT / "control_report.json"),
                     "integrity_valid": controls["integrity_valid"],
                     "baseline_failed": controls["runs"][0]["fail_count"],
                     "mutant_fail_counts": [r["fail_count"] for r in controls["runs"][1:]],
                     "scope": "Finite diagnostics and exact explicit examples, not proof by count. Kernel refinement alone is nondiscriminating on two defects."},
        "tamper_results": {name: json.loads((ROOT / "logs" / ("tamper_"+name) / "receipt.json").read_text())["exit_code"] for name in ["intact", "altered", "missing"]},
        "provisional_dependency": {"integrated_author": "71fe0b4cc1df0b34ef0ca55484ad8faffabe8155efa582bf09fc2eec8622c5ed", "integrated_review": "273ea8db025c5c469864867d55ea0afe7adb05987c2eaef15b8c06825d0738f1", "root_acceptance": "d9c0a81cf2066c1bc6fff5cba9a7e3b06a7e98c32d3c663bc67ec0db216fd753", "scope": "Accepted conditional source reuse, not retained status."},
        "review": "Fresh independent reviewer required. Author and root are contributors; no independent assessment is claimed by this packet.",
        "model_effort": "Inherited user-selected model and effort, no override or subdelegation.",
        "no_go_packet": "No five-family no-go PASS. Scoped explicit nonimplications and open microscopic routes only.",
        "changes": {"owned": [str(NOTE), str(ROOT)], "editable_prompt_files": [], "git_used": False, "canonical_science_execution": False, "audit_status_changed": False, "publication_action": False},
        "failures_preserved": record(ROOT / "OPERATIONAL_HISTORY.md"),
        "verification_exclusions": exclusions,
        "verification_command": ["python3", "check_evidence.py", "--manifest", "evidence_manifest.json"]}
    write_json("receipt.json", receipt)
    print(json.dumps({"note": record(NOTE), "receipt": record(ROOT / "receipt.json"),
                      "manifest": record(ROOT / "evidence_manifest.json"), "file_count": len(files)}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
