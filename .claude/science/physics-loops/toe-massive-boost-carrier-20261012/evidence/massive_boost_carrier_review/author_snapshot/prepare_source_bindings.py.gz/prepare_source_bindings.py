#!/usr/bin/env python3
"""Bind frozen inputs and refresh only their identities, never their contents."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
S = ROOT.parent
REPO = S.parent / "scattering_worktree"

def digest(path):
    data = Path(path).read_bytes()
    return hashlib.sha256(data).hexdigest(), len(data), data.count(b"\n")

def main():
    entries = json.loads((ROOT / "source_manifest.json").read_text())
    additions = {
        "PRIMITIVE_REGISTRY_CHECK.md": REPO / "docs/ai_methodology/skills/PRIMITIVE_REGISTRY_CHECK.md",
        "axiom_premise_nodes.json": REPO / "docs/audit/data/axiom_premise_nodes.json",
        "MINIMAL_AXIOMS_2026-06-29.md": REPO / "docs/MINIMAL_AXIOMS_2026-06-29.md",
        "no-go-discipline__SKILL.md": REPO / "docs/ai_methodology/skills/no-go-discipline/SKILL.md",
        "integrated_boost_root_review_coverage.json": S / "Integrated_boost_root_review_coverage.json",
        "NO_PER_SITE_BOSONIC_CCR_THEOREM_NOTE_2026-05-02.md": REPO / "docs/NO_PER_SITE_BOSONIC_CCR_THEOREM_NOTE_2026-05-02.md",
        "integrated_author_receipt.json": S / "integrated_boost_covariance/receipt.json",
        "integrated_review_receipt.json": S / "integrated_boost_covariance_review/receipt.json",
    }
    for name, source in additions.items():
        snapshot = ROOT / "sources" / name
        if not snapshot.exists():
            shutil.copyfile(source, snapshot)
        hashed, size, lines = digest(snapshot)
        entries.append({"source": str(source), "snapshot": str(snapshot),
                        "sha256": hashed, "bytes": size, "lines": lines})
    failures = []
    for entry in entries:
        live = digest(entry["source"])[0]
        frozen = digest(entry["snapshot"])[0]
        entry["live_sha256_at_freeze"] = live
        entry["unchanged"] = live == frozen == entry["sha256"]
        if not entry["unchanged"]:
            failures.append(entry)
        name = Path(entry["snapshot"]).name
        if name in ["integrated_author_receipt.json", "integrated_review_receipt.json"]:
            entry["role"] = "Upstream provenance snapshot; upstream full execution review belongs to root, not this author."
            entry["author_read_scope"] = "Source identities verified; full upstream helper/control re-review not claimed."
        elif name == "integrated_boost_root_review_coverage.json":
            entry["role"] = "Root source-acceptance record, not a mathematical premise or retained audit."
            entry["author_read_scope"] = "Complete text."
        elif name == "NO_PER_SITE_BOSONIC_CCR_THEOREM_NOTE_2026-05-02.md":
            entry["role"] = "Statement-search comparison only; not a load-bearing theorem for this proof."
            entry["author_read_scope"] = "Complete text."
        else:
            entry["role"] = "Frozen conditional mathematical source/review or applicable instructions, as identified in the note."
            entry["author_read_scope"] = "Complete text; initial truncated displays repaired by bounded reads."
    data = {"created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "provided_checkout": "3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe",
            "provided_main": "a13caa4885f547c8d206265b031ba7649e539fd9",
            "provided_planning": "3a4b2c66a1ead7a1c48b4359627e968f681e3c39",
            "git_used": False, "source_bindings": entries, "failures": failures}
    (ROOT / "SOURCE_BINDINGS.json").write_text(json.dumps(data, indent=2)+"\n")
    literature = []
    for name, metadata, role, coverage in [
        ("prasad_0912_0574v1.pdf", "prasad_acquisition.json",
         "Primary theorem comparison; raw paper outside publication. Self-contained proof also supplied.",
         "Theorem 4.1 including strong-continuity footnote and real-case section 4.3, via web extraction. Full PDF read is not claimed."),
        ("von_neumann_1931.pdf", "acquisition.json",
         "Incorrect original filename: actual Dito 2017 lecture deck. Excluded as a mathematical proof source; preserved failed acquisition.",
         "Inspected title/content to identify mismatch, not treated as full primary-paper proof.")]:
        path = ROOT / "external_raw" / name
        meta = json.loads((path.parent / metadata).read_text())
        hashed, size, _ = digest(path)
        literature.append({"path": str(path), "sha256": hashed, "bytes": size,
                           "url": meta["source_url"], "role": role, "read_scope": coverage,
                           "acquisition_matches": hashed == meta["sha256"] and size == meta["bytes"]})
    (ROOT / "EXTERNAL_RAW_INVENTORY.json").write_text(json.dumps(literature, indent=2)+"\n")
    print(json.dumps({"bound_sources": len(entries), "failures": failures,
                      "external_raw": literature}, indent=2))
    return 1 if failures or not all(r["acquisition_matches"] for r in literature) else 0

if __name__ == "__main__":
    raise SystemExit(main())
