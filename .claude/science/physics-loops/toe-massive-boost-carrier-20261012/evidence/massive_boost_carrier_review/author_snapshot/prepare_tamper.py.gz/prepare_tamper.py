#!/usr/bin/env python3
"""Materialize good, altered and absent whole-source provenance fixtures."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
destination = root / "tamper_fixtures"
destination.mkdir(exist_ok=False)
original = (root / "controls.py").read_bytes()
for name in ["intact", "altered", "missing"]:
    folder = destination / name
    folder.mkdir()
    path = folder / "controls.py"
    if name != "missing":
        data = original if name == "intact" else original.replace(
            b"TRANSLATION_ENERGY_SIGN = -1", b"TRANSLATION_ENERGY_SIGN = +1", 1)
        path.write_bytes(data)
    manifest = {"files": [{"path": str(path), "bytes": len(original),
                            "sha256": hashlib.sha256(original).hexdigest()}]}
    (folder / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    print(json.dumps({"fixture": name, "target": str(path),
                      "file_exists": path.exists(), "manifest": manifest}))
