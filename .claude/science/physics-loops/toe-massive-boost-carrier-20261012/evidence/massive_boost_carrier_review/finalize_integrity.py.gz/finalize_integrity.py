#!/usr/bin/env python3
"""Read-only provenance verification plus reviewer-owned inventory output.

This script neither imports scientific helpers nor assigns a science verdict.
It recognizes the disclosed, preserved reviewer control refinement by hash.
"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

O = Path(__file__).resolve().parent
S = O.parent
A = S / 'massive_boost_carrier'
REPO = S.parent / 'microscopic_boost_worktree'
PIN = '6079f5b2f6193f4beb968bbe1c62acaa7953de421546f009fee12cd4be7035d1'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    failures = []
    manifest = O / 'source_pins.final.json'
    if sha(manifest) != PIN:
        raise RuntimeError('Final source manifest external digest mismatch')
    source_rows = []
    for record in json.loads(manifest.read_text())['files']:
        path = Path(record['path'])
        actual = sha(path) if path.is_file() else None
        row = dict(path=str(path), expected=record['sha256'], observed=actual,
                   passed=actual == record['sha256'])
        source_rows.append(row)
        if not row['passed']:
            failures.append(row)

    snap_manifest = json.loads((O / 'author_snapshot_manifest.json').read_text())
    snapshot_rows = []
    for record in snap_manifest['files']:
        frozen = O / 'author_snapshot' / record['path']
        live = A / record['path']
        observed_frozen = sha(frozen) if frozen.is_file() else None
        observed_live = sha(live) if live.is_file() else None
        row = dict(path=record['path'], expected=record['sha256'],
                   frozen=observed_frozen, live=observed_live,
                   passed=observed_frozen == observed_live == record['sha256'])
        snapshot_rows.append(row)
        if not row['passed']:
            failures.append(row)
    expected_names = {r['path'] for r in snap_manifest['files']}
    observed_names = {str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()}
    if expected_names != observed_names:
        failures.append(dict(kind='author inventory changed',
                             added=sorted(observed_names - expected_names),
                             removed=sorted(expected_names - observed_names)))

    bindings = json.loads((O / 'author_snapshot/SOURCE_BINDINGS.json').read_text())
    binding_rows = []
    for record in bindings['source_bindings']:
        path = Path(record['source'])
        actual = sha(path) if path.is_file() else None
        row = dict(path=str(path), expected=record['sha256'], observed=actual,
                   passed=actual == record['sha256'], role=record['role'])
        binding_rows.append(row)
        if not row['passed']:
            failures.append(row)

    history = {}
    for name, old in [('review_controls.py', 'review_controls_initial.py'),
                      ('materialize_and_run.py', 'materialize_and_run_initial.py')]:
        path = O / 'history' / old
        history[(str(O / name), sha(path))] = path
    execution_rows = []
    for receipt_path in sorted((O / 'logs').glob('*/receipt.json')):
        receipt = json.loads(receipt_path.read_text())
        source_checks = []
        for record in receipt.get('sources', []):
            path = Path(record['path'])
            resolved = path
            if not path.is_file() or sha(path) != record['sha256']:
                resolved = history.get((str(path), record['sha256']), path)
            actual = sha(resolved) if resolved.is_file() else None
            row = dict(recorded_path=str(path), resolved_evidence_path=str(resolved),
                       expected=record['sha256'], observed=actual,
                       passed=actual == record['sha256'])
            source_checks.append(row)
            if not row['passed']:
                failures.append(row)
        stream_checks = []
        for stream in ['stdout', 'stderr']:
            path = receipt_path.parent / (stream + '.txt')
            record = receipt[stream]
            row = dict(stream=stream, sha256=sha(path), bytes=path.stat().st_size,
                       passed=sha(path) == record['sha256']
                       and path.stat().st_size == record['bytes'])
            stream_checks.append(row)
            if not row['passed']:
                failures.append(row)
        execution_rows.append(dict(run=receipt_path.parent.name,
                                   command=receipt['command'],
                                   exit_code=receipt['exit_code'],
                                   timed_out=receipt['timed_out'],
                                   timeout_seconds=receipt['timeout_seconds'],
                                   elapsed_seconds=receipt['elapsed_seconds'],
                                   sources=source_checks, streams=stream_checks))

    revision_rows = []
    for ref, expected in [('HEAD', '3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe'),
                          ('origin/main', 'a13caa4885f547c8d206265b031ba7649e539fd9'),
                          ('origin/ai/execution', '3a4b2c66a1ead7a1c48b4359627e968f681e3c39')]:
        command = ['git', '-C', str(REPO), 'rev-parse', ref]
        result = subprocess.run(command, capture_output=True, text=True, timeout=10,
                                stdin=subprocess.DEVNULL)
        row = dict(command=command, exit_code=result.returncode,
                   stdout=result.stdout, stderr=result.stderr, expected=expected,
                   passed=result.returncode == 0 and result.stdout.strip() == expected)
        revision_rows.append(row)
        if not row['passed']:
            failures.append(row)

    report = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  role='Provenance only, no scientific independence or verdict.',
                  source_pins=source_rows, author_snapshot=snapshot_rows,
                  author_source_bindings=binding_rows, executions=execution_rows,
                  local_revisions=revision_rows, failures=failures,
                  remote_fetch_performed=False)
    destination = O / 'closing_integrity.json'
    destination.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(source_pins=len(source_rows),
                          author_snapshot_files=len(snapshot_rows),
                          author_source_bindings=len(binding_rows),
                          prior_reviewer_executions=len(execution_rows),
                          local_revisions=revision_rows, failures=failures), indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
