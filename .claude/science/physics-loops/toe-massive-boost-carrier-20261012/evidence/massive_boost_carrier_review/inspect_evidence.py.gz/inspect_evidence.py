#!/usr/bin/env python3
"""Mechanical comparison of complete evidence. No science-module imports."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
AUTHOR=ROOT/'author_snapshot'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_run(log,result,style):
    receipt=json.loads((log/'receipt.json').read_text())
    data=json.loads(result.read_text())
    for stream in ['stdout','stderr']:
        record=receipt[stream]
        assert digest(log/(stream+'.txt'))==record['sha256'],(log,stream)
    rows=[json.loads(x) for x in (log/'stdout.txt').read_text().splitlines() if x.startswith('{')]
    assert rows==data['rows'],('stream mismatch',log)
    assert len({r['name'] for r in rows})==len(rows),('duplicate names',log)
    failed=sum(not r['passed'] for r in rows)
    assert not receipt['timed_out'] and receipt['exit_code']==bool(failed),(log,receipt)
    last=(log/'stdout.txt').read_text().splitlines()[-1]
    assert last==f'TOTAL: PASS={len(rows)-failed} FAIL={failed}',log
    if style=='author':
        assert data['total']==len(rows) and data['fail_count']==failed
        assert data['pass_count']==len(rows)-failed
        assert data['failed']==[r['name'] for r in rows if not r['passed']]
    else:
        assert data['failed']==failed and data['passed']==len(rows)-failed
    return rows,receipt


def variants_report(style,folder,base_result,base_log,manifest):
    base,receipt=validate_run(base_log,base_result,style)
    lookup={r['name']:r for r in base}
    information=json.loads(manifest.read_text())
    entries=information if style=='author' else information['variants']
    baseline=(folder/('controls.py' if style=='author' else 'review_controls.py')).read_text()
    rows=[]
    records=[]
    for entry in entries:
        name=entry['name']
        source=(folder/'mutants'/(name+'.py') if style=='author' else ROOT/'mutants_final'/(name+'.py'))
        assert baseline.count(entry['before'])==1
        assert source.read_text()==baseline.replace(entry['before'],entry['after'],1)
        assert digest(source)==entry['sha256']
        log=folder/'logs'/('mutant_'+name) if style=='author' else ROOT/'logs'/('final_'+name)
        result=folder/'mutants'/(name+'.result.json') if style=='author' else ROOT/'mutants_final'/(name+'.result.json')
        changed,execution=validate_run(log,result,style)
        assert [r['name'] for r in changed]==list(lookup)
        actual_changes=[r for r in changed if r!=lookup[r['name']]]
        rows.extend(dict(run=name,row=r) for r in actual_changes)
        records.append(dict(name=name,rows=len(changed),changed=len(actual_changes),
                            failures=sum(not r['passed'] for r in changed),
                            changed_survivors=[r['name'] for r in actual_changes if r['passed']],
                            identical_rows=len(changed)-len(actual_changes),
                            elapsed_seconds=execution['elapsed_seconds'],
                            timeout_seconds=execution.get('timeout_seconds'),
                            stderr_bytes=(log/'stderr.txt').stat().st_size))
    (ROOT/(style+'_changed_rows.ndjson')).write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
    (ROOT/(style+'_evidence_comparison.json')).write_text(json.dumps(dict(
        role='Provenance and comparison only; no science certification.',
        baseline=dict(rows=len(base),failed=sum(not r['passed'] for r in base),
                      elapsed_seconds=receipt['elapsed_seconds'],
                      timeout_seconds=receipt.get('timeout_seconds')),
        variants=records),indent=2)+'\n')
    print(json.dumps(dict(style=style,baseline_rows=len(base),variant_records=records),indent=2))


def history_reuse():
    initial=json.loads((ROOT/'independent_baseline.json').read_text())['rows']
    final={x['name']:x for x in json.loads((ROOT/'independent_baseline_final.json').read_text())['rows']}
    common=[x for x in initial if x['name'] in final]
    assert all(x==final[x['name']] for x in common)
    variants=[]
    for entry in json.loads((ROOT/'mutants/manifest.json').read_text())['variants']:
        name=entry['name']
        old=json.loads((ROOT/'mutants'/(name+'.result.json')).read_text())['rows']
        new={x['name']:x for x in json.loads((ROOT/'mutants_final'/(name+'.result.json')).read_text())['rows']}
        shared=[x for x in old if x['name'] in new]
        assert all(x==new[x['name']] for x in shared)
        variants.append(dict(name=name,identical_reused_rows=len(shared),
                             retired_rows=[x for x in old if x['name'] not in new]))
    (ROOT/'reviewer_initial_history_comparison.json').write_text(json.dumps(dict(
        initial_baseline_reused_rows=len(common),retired_baseline_rows=[x for x in initial if x['name'] not in final],
        variants=variants),indent=2)+'\n')


def log_inventory():
    records=[]
    for receipt_path in sorted((AUTHOR/'logs').glob('*/receipt.json')):
        receipt=json.loads(receipt_path.read_text())
        for stream in ['stdout','stderr']:
            assert digest(receipt_path.parent/(stream+'.txt'))==receipt[stream]['sha256']
        records.append(dict(run=receipt_path.parent.name,command=receipt['command'],
                            exit_code=receipt['exit_code'],timed_out=receipt['timed_out'],
                            timeout_seconds=receipt['timeout_seconds'],elapsed_seconds=receipt['elapsed_seconds'],
                            stdout_bytes=(receipt_path.parent/'stdout.txt').stat().st_size,
                            stderr_bytes=(receipt_path.parent/'stderr.txt').stat().st_size))
    (ROOT/'author_log_inventory.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(dict(author_runs=records),indent=2))


variants_report('author',AUTHOR,AUTHOR/'controls_initial.json',AUTHOR/'logs/controls_initial',AUTHOR/'mutants/manifest.json')
variants_report('reviewer',ROOT,ROOT/'independent_baseline_final.json',ROOT/'logs/independent_baseline_final',ROOT/'mutants_final/manifest.json')
history_reuse()
log_inventory()
