#!/usr/bin/env python3
"""Freeze the completed reviewer packet without changing any source evidence."""
import datetime
import hashlib
import json
from pathlib import Path

O = Path(__file__).resolve().parent
S = O.parent
REPORT = S / 'MASSIVE_BOOST_CARRIER_REVIEW.md'
EXCLUDED_FILES = {'evidence_manifest.json', 'receipt.json'}
EXCLUDED_DIRS = {'logs/freeze_packet/', 'logs/verify_packet/'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path, role):
    path = Path(path)
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size, role=role)


def main():
    for name in EXCLUDED_FILES:
        if (O / name).exists():
            raise RuntimeError('Refusing to overwrite existing freeze: ' + name)
    external = json.loads((O / 'source_pins.final.json').read_text())
    if sha(O / 'source_pins.final.json') != '6079f5b2f6193f4beb968bbe1c62acaa7953de421546f009fee12cd4be7035d1':
        raise RuntimeError('Source manifest external pin mismatch')
    rows = {}
    for path in sorted(O.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(O).as_posix()
        if relative in EXCLUDED_FILES or any(relative.startswith(d) for d in EXCLUDED_DIRS):
            continue
        rows[str(path)] = record(path, 'Reviewer evidence, frozen snapshot or original history')
    rows[str(REPORT)] = record(REPORT, 'Completed source-review report')
    for item in external['files']:
        path = Path(item['path'])
        if sha(path) != item['sha256']:
            raise RuntimeError('Externally pinned source changed: ' + str(path))
        if str(path) not in rows:
            rows[str(path)] = record(path, 'Externally pinned live source')
    snapshot = json.loads((O / 'author_snapshot_manifest.json').read_text())
    for item in snapshot['files']:
        path = S / 'massive_boost_carrier' / item['path']
        if sha(path) != item['sha256']:
            raise RuntimeError('Original author evidence changed: ' + str(path))
        rows[str(path)] = record(path, 'Original author evidence, separately checked against snapshot pin')
    binding = json.loads((O / 'author_snapshot/SOURCE_BINDINGS.json').read_text())
    for item in binding['source_bindings']:
        path = Path(item['source'])
        if sha(path) != item['sha256']:
            raise RuntimeError('Author-bound external input changed: ' + str(path))
        if str(path) not in rows:
            rows[str(path)] = record(path, 'Author-bound upstream input; read limits in READ_COVERAGE.json')
    manifest = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    role='Byte integrity only, not scientific evidence or independent review.',
                    exclusions=dict(files=sorted(EXCLUDED_FILES),
                                    directories=sorted(EXCLUDED_DIRS),
                                    reason='Avoid manifest/receipt and closing-log cycles; final tool return binds their digests.'),
                    files=[rows[k] for k in sorted(rows)])
    destination = O / 'evidence_manifest.json'
    destination.write_text(json.dumps(manifest, indent=2) + '\n')

    receipt = dict(
        completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        role='One bounded independent source review; no applied audit verdict.',
        disposition='Supported at explicit hypotheses; no required mathematical source correction found.',
        target=record(S / 'MASSIVE_BOOST_CARRIER_PROBE.md', 'Reviewed frozen complete 912-line proof'),
        report=record(REPORT, 'Completed review'),
        evidence_manifest=record(destination, 'Complete non-circular packet and fixed external-source inventory'),
        manifest_records=len(rows),
        independent_freeze=record(O / 'INDEPENDENT_FREEZE.md', 'Reconstruction frozen before author helper/raw-output exposure'),
        exposure_and_overlap=record(O / 'EXPOSURE_AND_OVERLAP.md', 'Actual pairing and method overlap, including coordinate-equivalent domain witness'),
        read_coverage=record(O / 'READ_COVERAGE.json', 'Direct read scope distinguished from byte integrity'),
        failures=record(O / 'FAILURES.md', 'Preserved failures, survivors and unavailable timing'),
        current_checkpoint=record(O / 'CHECKPOINT.md', 'Recovery and final source state'),
        reviewer_controls=dict(baseline_rows=64, failed_baseline_rows=0,
                               complete_source_mutants=9, changed_rows_read=89,
                               changed_survivors_read=15,
                               result=record(O / 'reviewer_evidence_comparison.json', 'Full row comparison summary')),
        author_controls=dict(baseline_rows=84, complete_source_mutants=8,
                             changed_rows_read=95, changed_survivors_read=12,
                             baseline_stdout_byte_identical=True,
                             replay=record(O / 'author_replay_comparison.json', 'Reproducibility only'),
                             manifest_checked=143, verbatim_snapshot_files=150),
        science_limits=['Supplied actual microscopic density/same-state/Lie package and geometric same-state invariance.',
                        'Supplied positivity, beta>0 and a nonzero positive fixed-mass eigenspace.',
                        'Isolated mass retained for direct Centre G1–G7/M37 reuse and exact almost-local mass filtering.',
                        'Actual creator central power rate, support/transfer predicates and density after those restrictions remain open.',
                        'One direction only; no microscopic realization, other boosts/rotations, scattering/completeness or TOE closure.'],
        required_source_changes=[], applied_audit=False, retained_status_assigned=False,
        model_pairing=dict(model='Inherited user-selected model; no override',
                           reasoning='Inherited user-selected effort; no override',
                           same_family=True, separate_context=True, blinded=False,
                           diverse_family=False, root_is_coauthor=True, subdelegation=False),
        source_revisions=dict(checkout='3faf1cf7167d8f9ef78ed84f50e9f3ebb277a9fe',
                              main_instructions='a13caa4885f547c8d206265b031ba7649e539fd9',
                              planning='3a4b2c66a1ead7a1c48b4359627e968f681e3c39',
                              verified_local_only=True, remote_fetch=False),
        editable_prompt_files_changed=[], author_or_repository_files_changed=[],
        allowed_outputs=[str(REPORT), str(O)],
        deadline_utc='2026-10-12 16:00:52 UTC',
        closing_verification='A separate logged pin_guard invocation must verify this manifest using its returned digest.')
    destination = O / 'receipt.json'
    destination.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(report=record(REPORT, 'review'), receipt=record(destination, 'receipt'),
                          manifest=receipt['evidence_manifest'], manifest_records=len(rows)), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
