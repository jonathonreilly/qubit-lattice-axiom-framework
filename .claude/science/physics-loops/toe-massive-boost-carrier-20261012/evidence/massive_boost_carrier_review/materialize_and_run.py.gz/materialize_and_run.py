#!/usr/bin/env python3
"""Complete source substitutions, preserving every original and result."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

root=Path(__file__).resolve().parent
baseline=root/'review_controls.py'
original=baseline.read_text()
changes=[
 ('kernel_half_normalization','KERNEL_FACTOR = 1.0','KERNEL_FACTOR = 0.5'),
 ('kernel_reverse_shift','KERNEL_SHIFT = 1','KERNEL_SHIFT = -1'),
 ('kernel_reverse_fourier','KERNEL_FOURIER = -1','KERNEL_FOURIER = 1'),
 ('omit_half_density','HALF_DENSITY = 0.5','HALF_DENSITY = 0.0'),
 ('reverse_boost','BOOST_SIGN = 1','BOOST_SIGN = -1'),
 ('opposite_difference_energy','DIFFERENCE_ENERGY_SIGN = -1','DIFFERENCE_ENERGY_SIGN = 1'),
 ('opposite_V_current','V_CURRENT_SIGN = 1','V_CURRENT_SIGN = -1'),
 ('RN_without_square_root','RN_EXPONENT = 0.5','RN_EXPONENT = 1.0'),
 ('commutant_omit_translations','COMMUTANT_SHIFT = 1','COMMUTANT_SHIFT = 0'),
]
directory=root/'mutants_final'
directory.mkdir(exist_ok=False)
records=[]
for name,before,after in changes:
    assert original.count(before)==1,(name,'source match is not unique')
    changed=original.replace(before,after)
    source=directory/(name+'.py')
    source.write_text(changed)
    diff=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),
                                    fromfile='review_controls.py',tofile=source.name))
    (directory/(name+'.diff')).write_text(diff)
    output=directory/(name+'.result.json')
    command=[sys.executable,str(root/'run_logged.py'),'--directory',str(root/'logs'/('final_'+name)),
             '--timeout','60','--source',str(source),'--source',str(root/'run_logged.py'),
             '--',sys.executable,str(source),'--output',str(output)]
    run=subprocess.run(command,cwd=root)
    records.append(dict(name=name,before=before,after=after,
                        path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                        output=str(output),exit_code=run.returncode))
    print(json.dumps(records[-1],sort_keys=True),flush=True)
(directory/'manifest.json').write_text(json.dumps(dict(
    baseline_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),variants=records),indent=2)+'\n')
if any(row['exit_code']!=1 for row in records):
    raise SystemExit('At least one planted defect survived or failed operationally; inspect all streams.')
