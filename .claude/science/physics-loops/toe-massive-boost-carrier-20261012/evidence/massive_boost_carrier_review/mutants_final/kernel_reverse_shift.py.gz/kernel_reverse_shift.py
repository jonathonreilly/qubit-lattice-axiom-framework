#!/usr/bin/env python3
"""Independent finite controls; no author code or result imports.

The continuum operator theorem is checked in the written review. The cyclic
Weyl controls below are a finite Fourier analogue, not a finite-dimensional
real-line Weyl representation. All mutations change these computed objects;
comparison targets and declared tolerances remain fixed.
"""
import argparse
import json
import math
import platform
from fractions import Fraction as F

import numpy as np
import scipy
from scipy.integrate import quad

KERNEL_FACTOR = 1.0
KERNEL_SHIFT = -1
KERNEL_FOURIER = -1
HALF_DENSITY = 0.5
BOOST_SIGN = 1
DIFFERENCE_ENERGY_SIGN = -1
V_CURRENT_SIGN = 1
RN_EXPONENT = 0.5
COMMUTANT_SHIFT = 1

rows = []


def check(name, observed, expected=0.0, tol=1e-10, **details):
    error = float(abs(observed - expected))
    row = dict(name=name, observed=float(observed), expected=float(expected),
               error=error, tolerance=tol, passed=math.isfinite(error) and error <= tol,
               details=details)
    rows.append(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def integrate(fun, lo=-1.0, hi=1.0):
    return (quad(lambda x: complex(fun(x)).real, lo, hi,
                 epsabs=2e-13, epsrel=2e-13, limit=200)[0]
            + 1j * quad(lambda x: complex(fun(x)).imag, lo, hi,
                        epsabs=2e-13, epsrel=2e-13, limit=200)[0])


def weyl_kernel(kernel):
    n = len(kernel)
    indices = np.arange(n)
    coefficients = np.zeros((n, n), complex)
    for a in range(n):
        diagonal = kernel[indices, (indices - a) % n]
        for t in range(n):
            coefficients[t, a] = np.sum(
                np.exp(KERNEL_FOURIER * 2j * np.pi * t * indices / n) * diagonal)
    result = np.zeros((n, n), complex)
    for a in range(n):
        shift = np.zeros((n, n), complex)
        shift[indices, (indices - KERNEL_SHIFT * a) % n] = 1
        for t in range(n):
            modulation = np.diag(np.exp(2j * np.pi * t * indices / n))
            result += (KERNEL_FACTOR / n) * coefficients[t, a] * modulation @ shift
    return result


def finite_weyl():
    for n in (5, 9, 13):
        x, y = np.indices((n, n))
        left = (((3*x + 5*y + 2) % 11 - 5)
                + 1j*((7*x + 2*y + 1) % 13 - 6)) / 7
        right = (((5*x + 2*y + 4) % 7 - 3)
                 + 1j*((3*x + 4*y + 2) % 9 - 4)) / 9
        a, b = weyl_kernel(left), weyl_kernel(right)
        err = lambda v: np.linalg.norm(v, ord='fro')
        check(f'cyclic_{n}_direct_kernel', err(a-left), tol=3e-11)
        check(f'cyclic_{n}_composition', err(a@b-weyl_kernel(left@right)), tol=3e-10)
        check(f'cyclic_{n}_adjoint', err(a.conj().T-weyl_kernel(left.conj().T)), tol=3e-11)
        check(f'cyclic_{n}_identity_nondegeneracy', err(weyl_kernel(np.eye(n))-np.eye(n)), tol=3e-11)
        f = (np.arange(n)+1) + 1j*(np.arange(n)**2+2)
        g = (np.arange(n)[::-1]+2) - 2j*np.arange(n)
        f, g = f/np.linalg.norm(f), g/np.linalg.norm(g)
        rank_one = np.outer(f, g.conj())
        check(f'cyclic_{n}_matrix_unit', err(weyl_kernel(rank_one)-rank_one), tol=3e-11)
        # Project an arbitrary full matrix into the Weyl commutant, using
        # group averaging, and compare with a separate partial trace.
        # Unlike a constructed tensor commutator this tests factorization.
        i, j = np.indices((2*n, 2*n))
        arbitrary = (((5*i+7*j+3) % 17-8)+1j*((2*i+3*j+1) % 11-5))/11
        averaged = np.zeros_like(arbitrary)
        ix = np.arange(n)
        for translation in range(n):
            shift = np.zeros((n,n),complex)
            shift[ix,(ix-COMMUTANT_SHIFT*translation)%n] = 1
            for modulation in range(n):
                z = np.diag(np.exp(2j*np.pi*modulation*ix/n))
                unitary = np.kron(z@shift,np.eye(2))
                averaged += unitary@arbitrary@unitary.conj().T/(n*n)
        partial = sum(arbitrary[2*k:2*k+2,2*k:2*k+2] for k in range(n))/n
        check(f'cyclic_{n}_commutant_factorization',
              err(averaged-np.kron(np.eye(n),partial)),tol=3e-11)


def massive_transport():
    for m, gamma in ((0.7, 0.5), (1.0, 1.0), (2.3, 1.7)):
        for s in (-0.21, 0.43):
            errors = []
            central = []
            for r in (-0.9, 0.4, 1.2):
                h, k = m*math.cosh(r), m/gamma*math.sinh(r)
                shifted = r-BOOST_SIGN*gamma*s
                ks = m/gamma*math.sinh(shifted)
                actual = np.exp(-1j*k+1j*ks)
                d, c = math.sinh(gamma*s)/gamma, math.cosh(gamma*s)
                predicted = np.exp(1j*DIFFERENCE_ENERGY_SIGN*d*h+1j*(c-1)*k)
                errors.append(abs(actual-predicted))
                vr = np.exp(1j*(V_CURRENT_SIGN-1)*k)
                vs = np.exp(1j*(V_CURRENT_SIGN-1)*ks)
                central.append(abs(vr-vs))
            suffix=f'M{m}_g{gamma}_s{s}'
            check('massive_difference_group_'+suffix, max(errors), tol=2e-12)
            check('massive_central_group_'+suffix, max(central), tol=2e-12)


def flat_generator():
    # Compact profiles vanish to order three at both endpoints. Their
    # zero extensions have the required derivative and no boundary flux.
    bump = np.polynomial.Polynomial([1, 0, -1])**3
    f = bump*np.polynomial.Polynomial([1, 0.3j])
    g = bump*np.polynomial.Polynomial([-0.08j, 1, 0.4j])
    kf = f*np.polynomial.Polynomial([0, 1])
    for m, gamma in ((0.2, 2.1), (1.4, 0.6), (3.2, 1.3)):
        beta = gamma**2
        energy = lambda k: math.sqrt(m*m+beta*k*k)
        ep = lambda k: beta*k/energy(k)
        action = lambda poly, k: 1j*BOOST_SIGN*(energy(k)*poly.deriv()(k)
                                             + HALF_DENSITY*ep(k)*poly(k))
        ab = integrate(lambda k: np.conjugate(f(k))*action(g,k))
        ba = integrate(lambda k: np.conjugate(action(f,k))*g(k))
        check(f'flat_symmetry_M{m}_g{gamma}', abs(ab-ba), tol=2e-11,
              first=[ab.real, ab.imag], second=[ba.real, ba.imag])
        commutator = integrate(lambda k: abs(action(kf,k)-k*action(f,k)
                                             - 1j*energy(k)*f(k))**2).real
        check(f'flat_current_commutator_M{m}_g{gamma}', commutator, tol=2e-11)
        inverse = integrate(lambda k: abs((-1j/energy(k))*action(f,k)
                                           - ep(k)/(2*energy(k))*f(k)-f.deriv()(k))**2).real
        check(f'flat_inverse_derivative_M{m}_g{gamma}', inverse, tol=2e-11)
        stationary = m/gamma
        actual = beta*stationary/(2*(m*m+beta*stationary**2))
        check(f'weight_multiplier_maximum_M{m}_g{gamma}', actual,
              gamma/(4*m), tol=2e-14)
        norm_f = math.sqrt(integrate(lambda k: abs(f(k))**2).real)
        norm_df = math.sqrt(integrate(lambda k: abs(f.deriv()(k))**2).real)
        norm_bf = math.sqrt(integrate(lambda k: abs(action(f,k))**2).real)
        rhs = norm_bf/m+gamma*norm_f/(4*m)
        check(f'global_derivative_inequality_M{m}_g{gamma}',
              max(0.0,norm_df-rhs), tol=2e-12,
              derivative_norm=norm_df, rhs=rhs)


def central_disintegration():
    mu = [[F(1,2),F(1,3),F(1,6),F(0)],
          [F(0),F(1,5),F(3,10),F(1,2)],
          [F(1,4),F(0),F(1,4),F(1,2)]]
    weights = [F(1,2),F(1,3),F(1,6)]
    nu = [sum(weights[j]*mu[j][a] for j in range(3)) for a in range(4)]
    values = [[complex(j+2*a+1,2*j-a+1)/3 for a in range(4)] for j in range(3)]
    source_norm = sum(float(mu[j][a])*abs(values[j][a])**2
                      for j in range(3) for a in range(4))
    image = [[float(mu[j][a]/nu[a])**RN_EXPONENT*values[j][a]
              for a in range(4)] for j in range(3)]
    target_norm = sum(float(nu[a])*abs(image[j][a])**2
                      for j in range(3) for a in range(4))
    check('central_RN_norm',target_norm,source_norm,tol=2e-12,
          mu=[[str(x) for x in row] for row in mu],nu=[str(x) for x in nu])
    inactive = max(abs(image[j][a]) for j in range(3) for a in range(4) if not mu[j][a])
    check('central_RN_inactive_coordinates',inactive,tol=0)
    inverse_error = max(abs(image[j][a]/math.sqrt(float(mu[j][a]/nu[a]))-values[j][a])
                        for j in range(3) for a in range(4) if mu[j][a])
    check('central_RN_surjective_inverse',inverse_error,tol=2e-12)


def domain_and_tail():
    m, gamma = 1.3, 0.8
    for cutoff in (2.0,4.0,6.0):
        sech = lambda r: 1/math.cosh(r)
        bg = lambda r: -0.5j*gamma*math.tanh(r)*math.sqrt(sech(r))
        hg = lambda r: m*math.cosh(r)*math.sqrt(sech(r))
        gnorm=integrate(lambda r: sech(r),-cutoff,cutoff).real
        bnorm=integrate(lambda r: abs(bg(r))**2,-cutoff,cutoff).real
        hnorm=integrate(lambda r: abs(hg(r))**2,-cutoff,cutoff).real
        # Actual conjugation gives Bpsi=e^-ik(Bg+Hg); the stated difference
        # subtracts H. The comparison is independently Bg's norm.
        snorm=integrate(lambda r: abs(bg(r)+(1+DIFFERENCE_ENERGY_SIGN)*hg(r))**2,
                       -cutoff,cutoff).real
        check(f'domain_g_norm_R{cutoff}',gnorm,2*math.atan(math.sinh(cutoff)),tol=2e-11)
        check(f'domain_Bg_norm_R{cutoff}',bnorm,
              gamma**2/4*(math.atan(math.sinh(cutoff))-sech(cutoff)*math.tanh(cutoff)),tol=2e-11)
        check(f'domain_Hg_growth_R{cutoff}',hnorm,2*m*m*math.sinh(cutoff),tol=2e-10)
        check(f'domain_difference_cancellation_R{cutoff}',snorm,bnorm,tol=2e-10,
              energy_cutoff_norm_squared=hnorm)
    for length in (2.0,5.0,20.0,100.0):
        # u=log(1/theta) turns the continuous central density into du/u^2.
        observed=quad(lambda u: 1/(u*u),length,math.inf,epsabs=1e-13,epsrel=1e-13)[0]
        check(f'continuous_central_tail_L{length}',observed,1/length,tol=2e-12,
              radius_log=-length,
              log_rate_ratio_a01=0.1*length-0.5*math.log(length))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    finite_weyl()
    massive_transport()
    flat_generator()
    central_disintegration()
    domain_and_tail()
    summary=dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),
                 rows=rows,versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),
                 scope='Finite algebra/transport/integration diagnostics; written proof supplies continuum domains and disintegration.')
    with open(args.output,'x') as stream:
        json.dump(summary,stream,indent=2,sort_keys=True)
        stream.write('\n')
    print('TOTAL: PASS=%d FAIL=%d'%(summary['passed'],summary['failed']),flush=True)
    return 0 if not summary['failed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
