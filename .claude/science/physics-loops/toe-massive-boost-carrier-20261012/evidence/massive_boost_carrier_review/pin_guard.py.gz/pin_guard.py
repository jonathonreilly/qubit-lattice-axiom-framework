#!/usr/bin/env python3
"""Fail closed on both the supplied manifest and every named source byte."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',required=True)
    parser.add_argument('--expected-manifest-sha',required=True)
    args=parser.parse_args()
    manifest=Path(args.manifest)
    try:
        data=manifest.read_bytes()
        if sha(data)!=args.expected_manifest_sha:
            raise ValueError('manifest digest differs from external pin')
        rows=json.loads(data)['files']
        failures=[]
        for row in rows:
            file=Path(row['path'])
            if not file.is_absolute():
                file=manifest.parent/file
            try:
                observed=sha(file.read_bytes())
                passed=observed==row['sha256']
                status=dict(path=str(file),expected=row['sha256'],observed=observed,passed=passed)
            except OSError as exc:
                status=dict(path=str(file),expected=row['sha256'],passed=False,error=str(exc))
            print(json.dumps(status,sort_keys=True))
            if not status['passed']:
                failures.append(status)
        print(json.dumps(dict(kind='provenance_only',rows=len(rows),failures=len(failures))))
        return 1 if failures else 0
    except (OSError,ValueError,KeyError) as exc:
        print(json.dumps(dict(passed=False,error=str(exc),kind='provenance_only')))
        return 1


if __name__=='__main__':
    raise SystemExit(main())
