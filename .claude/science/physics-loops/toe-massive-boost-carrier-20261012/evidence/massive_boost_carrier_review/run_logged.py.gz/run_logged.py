#!/usr/bin/env python3
"""Preserve exact commands, source identities, streams and real timeouts."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def digest(path):
    path=Path(path)
    data=path.read_bytes()
    return dict(path=str(path.resolve()),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--directory',required=True)
    p.add_argument('--timeout',type=float,required=True)
    p.add_argument('--source',action='append',default=[])
    p.add_argument('command',nargs=argparse.REMAINDER)
    a=p.parse_args()
    command=a.command[1:] if a.command and a.command[0]=='--' else a.command
    if not command:
        p.error('missing command')
    directory=Path(a.directory)
    directory.mkdir(parents=True,exist_ok=False)
    receipt=dict(command=command,cwd=str(Path.cwd()),timeout_seconds=a.timeout,
                 sources=[digest(x) for x in a.source],
                 start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    start=time.monotonic()
    try:
        child=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True,timeout=a.timeout)
        stdout,stderr=child.stdout,child.stderr
        receipt.update(exit_code=child.returncode,timed_out=False)
    except subprocess.TimeoutExpired as exc:
        stdout,stderr=exc.stdout or b'',exc.stderr or b''
        receipt.update(exit_code=None,timed_out=True,error=str(exc))
    except OSError as exc:
        stdout,stderr=b'',str(exc).encode()
        receipt.update(exit_code=None,timed_out=False,error=str(exc))
    receipt.update(elapsed_seconds=time.monotonic()-start,
                   end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    for name,data in [('stdout',stdout),('stderr',stderr)]:
        dest=directory/(name+'.txt')
        dest.write_bytes(data)
        receipt[name]=digest(dest)
    (directory/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:receipt[k] for k in ['command','exit_code','timed_out','elapsed_seconds']}))
    return receipt['exit_code'] if receipt['exit_code'] is not None else 124


if __name__=='__main__':
    sys.exit(main())
