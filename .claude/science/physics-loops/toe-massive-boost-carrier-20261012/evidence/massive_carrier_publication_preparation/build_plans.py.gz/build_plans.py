"""Build exact source-only publication maps/previews in this preparation folder.

No scientific helper or publication program is imported or executed. Complete
source maps, reversible administrative diffs and compile-only syntax checks
are the only transformations. Existing evidence is never changed.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
CONFIG = json.loads((Q / "SPECIFICATIONS.json").read_text())
SP = CONFIG["specs"][0]
PACKET = CONFIG["packet"]
PAIRING = "Same selected model family in separate author/reviewer contexts, with the inherited selected model and reasoning effort preserved. The full candidate and its reported control descriptions were visible before the reviewer reconstruction and distinct controls were frozen; raw author helpers/results were inspected afterwards. This was not blinded or diverse-family checking. Root proposed the route and is a coauthor, not the independent reviewer. Mechanical preparation adds no new scientific review."


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Transform:
    def __init__(self, relative):
        self.relative = relative
        self.original = (S / relative).read_bytes()
        self.text = self.original.decode()
        self.edits = []

    def replace(self, before, after, category, reason):
        if self.text.count(before) != 1:
            raise RuntimeError("Ambiguous exact administrative anchor: " + reason)
        self.text = self.text.replace(before, after, 1)
        self.edits.append({"before": before, "after": after, "category": category,
                           "reason": reason, "occurrences": 1})

    def finish(self, kind, target, appended=""):
        data = (self.text + appended).encode()
        return data, {"kind": kind, "source_path": str(S / self.relative), "source_sha256": sha(self.original),
                      "source_bytes": len(self.original), "preserved_source": "evidence/" + self.relative + ".gz",
                      "edits": self.edits, "appended_text": appended,
                      "appended_text_role": "Separate publication evidence appendix" if appended else "No appended scientific or administrative output",
                      "publication_path": target, "publication_sha256": sha(data), "publication_bytes": len(data),
                      "mathematical_changes": [], "pairing": PAIRING}


header = {
    "claim_id": SP["claim"], "claim_type": "bounded_theorem",
    "claim_scope": "For one actual boost direction, the supplied microscopic same-state/Lie package, same-state geometric shift invariance, positive H, beta>0 and a nonzero positive fixed-mass eigenspace imply the central mismatch, regular Weyl product carrier with arbitrary central multiplicity and the full adapted boost domain. Boost-domain vectors give ambient momentum H1 after legitimate chart cutoffs. Centre M37 and exact almost-local mass filtering additionally retain isolated mass. Actual central power rates, rate-qualified creator density and microscopic realization remain open.",
    "upstream_dependencies": SP["deps"], "runner": "scripts/" + SP["runner"],
    "actual_current_surface_status": "conditional-support", "target_claim_type": "bounded_theorem",
    "trace_class": "direct_blocker_closure", "target_claim_id": "centre_regularity_to_geometric_bounded_theorem_note_2026-10-12",
    "target_blocker_text": "Identify a checked joint carrier and boost gauge for actual almost-local seed vectors, then prove their central rate and target density.",
    "source_of_blocker_text": "handoff", "reachability_to_target": "partially_closes", "artifact_role": "theorem",
    "next_trace_action": "Supply a common intended microscopic density/state/Lie/mass realization and prove the central power rate and dense target projections for actual almost-local creators with the declared support/transfer conditions.",
    "conditional_surface_status": "The actual one-direction boost fixes a massive product carrier and a momentum Sobolev gauge, given geometric state invariance and a nonzero positive mass eigenspace.",
    "hypothetical_axiom_status": None, "admitted_observation_status": None,
    "claim_type_reason": "The actual common microscopic symmetry/state package, positivity and nonzero positive mass remain supplied; the derived carrier/gauge does not imply actual central rates, creator density or a physical realization.",
    "audit_required_before_effective_retained": True, "bare_retained_allowed": False,
}
header_lines = ["---"]
for key, value in header.items():
    if isinstance(value, list):
        header_lines.append(key + ":")
        header_lines.extend("  - " + item for item in value)
    else:
        header_lines.append(key + ": " + json.dumps(value, ensure_ascii=False))
header_text = "\n".join(header_lines) + "\n---\n\n"

note = Transform(SP["source"])
if sha(note.original) != SP["source_sha"]:
    raise RuntimeError("Frozen author note changed")
old_header = note.text[:note.text.index("\n---\n", 4) + len("\n---\n\n")]
note.replace(old_header, header_text, "claim_metadata", "Complete conditional bounded-theorem metadata and exact direct dependency IDs; retain original direct-blocker/partial-closure trace and conditional status")
note.replace("**Author conditional theorem, 2026-10-12. Independent review pending.**",
             "**Conditional bounded theorem, 2026-10-12; completed separate source review found no required mathematical correction.**",
             "review_status", "Record completed source review without retained promotion or a new preparer scientific verdict")
deps = "\n".join("- [" + d["label"] + "](" + d["note"] + "): " + d["role"] for d in SP["dependencies"])
note.replace("Write S for this note's directory. Complete frozen inputs, mathematical\ncontrols, raw literature bytes, execution history and the source-bound\nreceipt are in `S/massive_boost_carrier/`. No upstream file is modified.",
             "S denotes the original research collection. The [evidence map](../" + PACKET + "/EVIDENCE_MAP.json) preserves its complete own sources, controls, execution history and source-bound receipts. Raw third-party paper bytes stay external with the exact [source inventory](../" + PACKET + "/EXTERNAL_SOURCE_INVENTORY.json). The direct canonical proof dependencies are:\n\n" + deps + "\n\nThe broader carrier/domain result does not need mass isolation; M37 and the exact-mass operator filter explicitly do. No concrete-chain result supplies a premise or application.",
             "portable_provenance", "Replace scratch recovery paths with portable source-map links and four actual direct proof dependencies; distinguish isolation scopes and exclude a concrete-chain application")
note.replace("[no-go-discipline instructions](massive_boost_carrier/sources/no-go-discipline__SKILL.md)",
             "[frozen no-go-discipline instructions](../" + PACKET + "/evidence/massive_boost_carrier/sources/no-go-discipline__SKILL.md.gz)",
             "portable_provenance", "Point the original process reference to its exact preserved snapshot; no new science graph edge")
note.replace("No author control or file hash replaces\nthe pending independent proof review.",
             "No author control or file hash replaces\nthe independent proof review that was pending at the author freeze.",
             "historical_status", "Retain the original review obligation as historical author status; completion is separately recorded")
note.replace("Only this note and its evidence directory were authored.",
             "Frozen author operational record: only this note and its evidence directory were authored.",
             "historical_status", "Label the unchanged author-only write-scope and no-publication record as history")
note.replace("The conclusion\nis ready for a focused independent review at the stated conditional\nscope; it is not a retained result or a physical realization.",
             "At the author freeze, the conclusion\nwas ready for a focused independent review at the stated conditional\nscope; that review is now complete and recorded below. It is not a retained result or a physical realization.",
             "historical_status", "Complete the pending-review handoff administratively while preserving the conditional conclusion")

author = SP["baseline"]
review = SP["review_evidence"]["baseline"]
author_failure_counts = ", ".join(str(m["observed_failed"]) for m in SP["mutations"])
review_failure_counts = ", ".join(str(m["observed_failed"]) for m in SP["review_evidence"]["mutations"])
appendix = f"""

## Publication evidence and review record

The full original 912-line source is `{SP['source']}`, SHA-256
`{SP['source_sha']}`. The separate completed review is `{SP['report']}`,
SHA-256 `{SP['report_sha']}`, with receipt
`{SP['review_receipt_sha']}`. Root's completed coverage record is
`{SP['root_coverage']}`, SHA-256 `{SP['root_coverage_sha']}`.
The [evidence map](../{PACKET}/EVIDENCE_MAP.json) preserves complete own
author/reviewer sources, prior versions, all controls and materialized variants,
full original results/streams, execution receipts, failures and root read/binding
records. The [exact administrative map](../{PACKET}/PUBLICATION_EDITS.json)
and [reconstruction program](../{PACKET}/reconstruct.py) recover this complete
note and entire finite primary from their frozen originals. Publication makes
no mathematical correction. All M1–M42 proofs and their scope remain intact.

**Author/checker pairing:** {PAIRING}

The reviewed implication supplies the actual mismatch, product carrier and
adapted full boost domain under its explicit premises. The microscopic
density/same-state/Lie package, geometric invariance of that same state, positive
H, beta>0 and nonzero positive fixed mass remain supplied. The broader carrier,
domain and exact projection results need no mass isolation; direct Centre
G1–G7/M37 reuse and the actual exact-mass almost-local filter retain it. Actual
central power rates and density after imposing the rate and support/transfer
restrictions remain open. The finite-a concrete gapped chain fails exact Lie
closure, so this theorem is not applied to it. No new concrete-chain dependency,
physical realization, multi-direction covariance, scattering/exhaustion result,
nonzero target atom or TOE closure follows.

The full author helper recorded {author['observed_passed']} passing finite
predicates and {author['observed_failed']} failures. Its eight original
whole-source one-defect variants retain the original gates; their historical
failed-predicate counts are {author_failure_counts}, in the frozen manifest
order. Twelve changed kernel-refinement rows survive the two wrong kernels:
convergence of an incorrect integrand is not correctness, while the separate
coordinate-overlap comparison detects both defects. All passing and failing
rows remain. These controls do not prove the infinite-dimensional theorem.

The separate reviewer baseline recorded {review['observed_passed']} passing
predicates and {review['observed_failed']} failures. Its nine final whole-source
variants have historical failed-predicate counts {review_failure_counts}.
The review read all 89 changed rows, including 15 changed survivors. Arbitrary
cyclic kernels, the full-matrix Weyl average versus an independent partial
trace, compact-polynomial matrix-element integrations and a continuous central
tail provide distinct checks at their stated finite scope. Finite cyclic Weyl
systems are not finite-dimensional regular real-line CCR representations.
These counts are separate records; they are not added to the author TOTAL.

Three original tensor-commutator rows were tautological and are retired from
scientific support. Their full initial source, nine original executions and
results are preserved. Before author helper exposure, they were replaced by
the averaging/partial-trace controls, with an additional omission variant.
Exactly 61 original rows remain byte-identical in the baseline and eight
preexisting variants. The reviewer's `sqrt(sech r)` domain witness is the
author's algebraic-tail witness in different coordinates at M=beta=1, not a
distinct counterexample family. The mistaken anticipated distinction in the
initial freeze and its later explicit correction are both preserved.

The reviewer replayed the author baseline once and matched all 21,569 stdout
bytes and the complete result JSON. This is reproducibility evidence, not a
new independent argument. Root read the complete source, review and bound
evidence as coauthor; mechanical preparation did not rerun them or issue a
new scientific verdict. Floating quadrature and finite differences have no
interval error certificate. No Lean formalization is claimed.

The original 732-line proof and the five-line isolation qualification before
M37 remain in the preserved history. The exact versioned Prasad PDF and the
misnamed file that is actually a Dito lecture deck stay external. The latter
is excluded as a proof source, and the failed Springer acquisition remains
documented. Root and the reviewer did not freshly audit those papers; the
complete self-contained kernel argument supports the stated representation
step. No new literature search or full-paper read is claimed here.

The [canonical finite primary](../scripts/{SP['runner']}) preserves every
calculation, row, tolerance, failure gate and original stdout byte, including
the five scope lines and TOTAL. Publication adds only timeout/input declarations
and an assertion guard, makes the now-unused output destination optional, and
suppresses its JSON file write. The entire original output dictionary, including
actual version metadata, remains computed. [Specifications](../{PACKET}/SPECIFICATIONS.json)
bind its original baseline, all eight source edits, every stream/result and
all nine reviewer variants. Root's later canonical verification must compare
complete stdout and the observed output dictionary; no numeric or environment
comparison rewrite is authorized by this preparation.

Preparation executes no primary, mutation, independent control, cache,
vocabulary, graph or audit check. [Delivery checks](../{PACKET}/DELIVERY_CHECKS.md)
record the pending root-owned canonical and whole-source replay, raw INNER and
OUTER capture before identity/freshness inspection, reconstruction, graph and
focused compatibility work. Historical results are not fresh canonical results.
Combined candidate validation and strict audit lint remain separate landing
gates. No applied audit verdict, retained promotion, PR update or completed
landing is asserted by this packet. This is a frozen milestone record; root
owns the sole live campaign checkpoint. Editable prompt files changed: none.
"""
note_data, note_map = note.finish("note", "docs/" + SP["note"], appendix)

runner = Transform(SP["folder"] + "/" + SP["helper"])
if sha(runner.original) != SP["helper_sha"]:
    raise RuntimeError("Original scientific helper changed")
tree = ast.parse(runner.text)
body = list(tree.body)
if isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
    body.pop(0)
while body and isinstance(body[0], ast.ImportFrom) and body[0].module == "__future__":
    body.pop(0)
anchor = runner.text.splitlines(keepends=True)[body[0].lineno - 1]
declarations = ("AUDIT_TIMEOUT_SEC = 60\nAUDIT_INPUT_PATHS = " + json.dumps(SP["audit_inputs"], indent=4)
                + '\nif not __debug__:\n    raise RuntimeError("Run without -O: finite control assertions must be enabled")\n\n')
runner.replace(anchor, declarations + anchor, "runner_declarations", "Declare the note, four direct dependencies and evidence map; set 60-second audit timeout and assertion guard after the docstring/all future imports")
runner.replace('parser.add_argument("--output", required=True)', 'parser.add_argument("--output", default=None)',
               "canonical_cli", "Permit the no-argument canonical API while preserving the parser and all computation; the destination is now unused")
runner.replace('    Path(args.output).write_text(json.dumps(output, indent=2)+"\\n")',
               "    # Publication suppresses the result-file write only; the complete output dictionary remains computed.",
               "suppress_output_side_effect", "Suppress only the JSON file write; preserve the complete main-local output dictionary, versions, original stdout/TOTAL and exact failure return")
runner_data, runner_map = runner.finish("primary", "scripts/" + SP["runner"])
compile(runner_data, runner_map["publication_path"], "exec")
outputs = [(note_data, note_map), (runner_data, runner_map)]
for data, row in outputs:
    destination = Q / "previews" / row["publication_path"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    before = Path(row["source_path"]).read_text()
    difference = "".join(difflib.unified_diff(before.splitlines(True), data.decode().splitlines(True),
                                           fromfile=row["source_path"], tofile=row["publication_path"]))
    (Q / "previews" / (Path(row["publication_path"]).name + ".diff")).write_text(difference)
mutation_preview_rows = []
for mutation in SP["mutations"]:
    before, after = mutation["before"], mutation["after"]
    text = runner_data.decode()
    if text.count(before) != 1:
        raise RuntimeError("Canonical mutation target is ambiguous")
    data = text.replace(before, after, 1).encode()
    compile(data, mutation["name"], "exec")
    destination = Q / "previews/mutants" / (mutation["name"] + ".py")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    mutation_preview_rows.append({"name": mutation["name"], "preview": str(destination.relative_to(Q)),
                                  "sha256": sha(data), "bytes": len(data), "before": before, "after": after,
                                  "original_source": mutation["original_source"], "original_bindings": mutation["original_bindings"],
                                  "policy": "Entire canonical source with the exact original one-defect edit; no new gate or tolerance."})
mapping = {"packet": PACKET, "base_policy": CONFIG["base_policy"], "required_base": CONFIG["required_base"],
           "mathematical_changes": [], "pairing": PAIRING, "outputs": [row for data, row in outputs],
           "execution_status": "Literal source mapping and compile-only checks; no science or publication script executed"}
(Q / "TRANSFORM_PLANS.json").write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + "\n")
(Q / "CANONICAL_MUTATION_PREVIEWS.json").write_text(json.dumps(mutation_preview_rows, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"notes": 1, "entire_primaries": 1, "administrative_edits": sum(len(r["edits"]) for data,r in outputs),
                  "canonical_mutant_source_previews": len(mutation_preview_rows), "mathematical_changes": 0,
                  "science_or_preparation_program_executed": False, "worktree_files_written": 0}, indent=2))
