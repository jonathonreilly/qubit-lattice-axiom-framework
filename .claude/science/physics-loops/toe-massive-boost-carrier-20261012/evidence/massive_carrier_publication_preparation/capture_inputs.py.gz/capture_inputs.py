"""Source/data bookkeeping only; write this preparation folder, never a worktree.

Read existing JSON, complete source bytes and AST literals. Do not import or
execute any science, prior verifier, preparation program, Git or cache API.
"""
import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "microscopic_boost_worktree"
BASE = "358fdf795a5504d4d7fd13344bbbd5df5504ebea"
PACKET = ".claude/science/physics-loops/toe-massive-boost-carrier-20261012"


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(relative):
    return json.loads((S / relative).read_text())


def bind(path):
    need(path.is_file() and not path.is_symlink(), "Missing/nonregular source: " + str(path))
    data = path.read_bytes()
    return {"original": str(path), "bytes": len(data), "sha256": sha(data)}


def save(name, value):
    (Q / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


PINS = {
    "MASSIVE_BOOST_CARRIER_PROBE.md": "eb85ee2fda1690373e7bb7bdf96bc255e86235d672e8e9f18e46c6553078e310",
    "MASSIVE_BOOST_CARRIER_REVIEW.md": "8a90df17d977c347b8b26b7b9fee933e4617c6fff6e099a7d7ef55d76574764f",
    "massive_boost_carrier/controls.py": "bd7a1bdce6cb0416adaedb88e144f52106b20b48af7a94582bdcc1680e8619b1",
    "massive_boost_carrier/receipt.json": "10f408ded24c9f65a3b5a8205bc0b6e78b8b63aae7242888058339bfa10c53f0",
    "massive_boost_carrier/evidence_manifest.json": "37d0b050a9b81750d7fd190515ad3ce886e804286d19f301a56156b851840f87",
    "massive_boost_carrier_review/receipt.json": "c861afa9074c22198531bd890976c7154f25e0e08899ef3b2de2792535bf985d",
    "massive_boost_carrier_review/evidence_manifest.json": "9be077726fec56a7bd2b915f84d5c368dd77e674f449d026fd5b7f0526cf5d6c",
    "Massive_carrier_root_review_coverage.json": "f6c2c7470d8bdf81fbfc3e76d19aa5e0dd2dd143cbc23aa9efd6f120a930be9b",
}
for relative, expected in PINS.items():
    need(bind(S / relative)["sha256"] == expected, "Explicit source pin changed: " + relative)
manifest_checks = []
for relative in ["massive_boost_carrier/evidence_manifest.json", "massive_boost_carrier_review/evidence_manifest.json"]:
    manifest = load(relative)
    checked = []
    for row in manifest["files"]:
        current = bind(Path(row["path"]))
        need(current["sha256"] == row["sha256"] and current["bytes"] == row["bytes"], "Source-reviewed manifest binding changed: " + row["path"])
        checked.append(current)
    manifest_checks.append({"manifest": relative, "sha256": PINS[relative], "checked_entries": len(checked), "checked_files": checked})
save("CHECKED_ORIGINAL_MANIFEST_BINDINGS.json", {"scope": "Existing-byte hash checks only; no source checker or science program imported/executed", "manifests": manifest_checks})

dependency_roles = [
    ("Integrated covariance", "INTEGRATED_BOOST_COVARIANCE", "integrated_boost_covariance",
     "c791d1d7871442253f066348311e81c0b9b8c539cbb7c1c405630d960df639ee",
     "C1–C28 supplies the actual rapid almost-local product rule, integrated H/P/B covariance, positive-energy domain inclusion and group uniqueness used in M1–M14."),
    ("Microscopic boost flow", "MICROSCOPIC_BOOST_FLOW", "microscopic_boost_flow",
     "95f6c72698ea71396aa5f4c18ec9c6f210aebdaa5e73a9c91c2003a3f0651d75",
     "B1–B37 supplies the actual flows and simultaneous local graph approximation; B24–B25 is directly used for local boost-domain columns in M40."),
    ("Centre regularity", "CENTRE_REGULARITY_TO_GEOMETRIC", "centre_regularity_to_geometric",
     "eaddd8b34a8f4786927244c7ccc24ec25dd4e03d23d18f840b4e755dc081c1eb",
     "G1–G7 supplies the dimension-one rate implication M37, explicitly retaining isolated mass, the actual central rate, support and fixed chart/lift; G24 remains an open creator-density obligation."),
    ("Isolated Centre filtering", "ISOLATED_CENTRE_FILTERING", "isolated_centre_filtering",
     "1671b4cfa7a24e42875b3aa142444cdc034b1087a26325514d1dc0de8615051f",
     "I1–I4 fixes clocks/signs; I18–I20 supplies the fixed exact-mass almost-local filters and the separate isolated-central selection route. No downstream scattering or detector conclusion is imported."),
]
dependencies = []
for label, stem, claim, expected, role in dependency_roles:
    note = stem + "_BOUNDED_THEOREM_NOTE_2026-10-12.md"
    need(bind(W / "docs" / note)["sha256"] == expected, "Canonical dependency changed: " + note)
    dependencies.append({"label": label, "note": note, "claim_id": claim + "_bounded_theorem_note_2026-10-12",
                         "sha256": expected, "role": role, "publication_target": False})


def existing_run(folder, source, result, log, baseline_rows=None, reviewer=False):
    source_path, result_path, log_path = S / folder / source, S / folder / result, S / folder / log
    data = json.loads(result_path.read_text())
    receipt = json.loads((log_path / "receipt.json").read_text())
    source_pin = next(row for row in receipt["sources"] if Path(row["path"]) == source_path)
    need(source_pin["sha256"] == bind(source_path)["sha256"], "Run source binding changed")
    row_list = data["rows"]
    names = [r["name"] for r in row_list]
    need(len(set(names)) == len(names), "Duplicate finite predicate label")
    failed = [r["name"] for r in row_list if r["passed"] is False]
    passed_count = len(row_list) - len(failed)
    need(all(type(r["passed"]) is bool for r in row_list), "Nonboolean recorded result")
    if reviewer:
        need((data["passed"], data["failed"]) == (passed_count, len(failed)), "Reviewer result totals differ")
        expected_stdout = "".join(json.dumps(r, sort_keys=True) + "\n" for r in row_list)
    else:
        need((data["total"], data["pass_count"], data["fail_count"], data["failed"])
             == (len(row_list), passed_count, len(failed), failed), "Author result totals differ")
        expected_stdout = "".join(json.dumps(r, sort_keys=True) + "\n" for r in row_list)
        expected_stdout += "".join(k + ": " + v + "\n" for k, v in data["scope"].items())
    expected_stdout += f"TOTAL: PASS={passed_count} FAIL={len(failed)}\n"
    need((log_path / "stdout.txt").read_bytes() == expected_stdout.encode(), "Complete stdout/result binding differs")
    need(receipt["exit_code"] == (1 if failed else 0) and receipt["timed_out"] is False, "Historical run disposition mismatch")
    for channel in ["stdout", "stderr"]:
        content = (log_path / (channel + ".txt")).read_bytes()
        need(receipt[channel]["sha256"] == sha(content) and receipt[channel]["bytes"] == len(content), "Historical stream pin mismatch")
    changed = [] if baseline_rows is None else [r for r, b in zip(row_list, baseline_rows) if r != b]
    if baseline_rows is not None:
        need(names == [r["name"] for r in baseline_rows], "Original variant row ordering changed")
    return {
        "original_source": str(source_path.relative_to(S)), "original_result": str(result_path.relative_to(S)),
        "original_receipt": str((log_path / "receipt.json").relative_to(S)),
        "original_stdout": str((log_path / "stdout.txt").relative_to(S)),
        "original_stderr": str((log_path / "stderr.txt").relative_to(S)),
        "original_bindings": [bind(p) for p in [source_path, result_path, log_path / "receipt.json", log_path / "stdout.txt", log_path / "stderr.txt"]],
        "original_command": receipt["command"], "original_timeout_seconds": receipt["timeout_seconds"],
        "original_elapsed_seconds": receipt["elapsed_seconds"], "original_timed_out": receipt["timed_out"],
        "original_versions": data["versions"], "observed_passed": passed_count, "observed_failed": len(failed),
        "observed_exit": receipt["exit_code"], "row_names": names, "failed_rows": failed,
        "changed_rows": [r["name"] for r in changed], "changed_surviving_rows": [r["name"] for r in changed if r["passed"]],
        "unchanged_row_names": [] if baseline_rows is None else [r["name"] for r, b in zip(row_list, baseline_rows) if r == b],
        "comparison_contract": "Observed frozen result only, not a future pass claim. Preserve complete bytes/values, original gates, return status, timeouts and every surviving row.",
    }


author_folder = "massive_boost_carrier"
review_folder = "massive_boost_carrier_review"
author_source = (S / author_folder / "controls.py").read_text()
review_source = (S / review_folder / "review_controls.py").read_text()
author_baseline = existing_run(author_folder, "controls.py", "controls_initial.json", "logs/controls_initial")
review_baseline = existing_run(review_folder, "review_controls.py", "independent_baseline_final.json", "logs/independent_baseline_final", reviewer=True)
author_rows = load(author_folder + "/controls_initial.json")["rows"]
review_rows = load(review_folder + "/independent_baseline_final.json")["rows"]
author_mutations = []
review_mutations = []
for folder, source, manifest, baseline, output in [
    (author_folder, author_source, load(author_folder + "/mutants/manifest.json"), author_rows, author_mutations),
    (review_folder, review_source, load(review_folder + "/mutants_final/manifest.json")["variants"], review_rows, review_mutations),
]:
    for row in manifest:
        name, before, after = row["name"], row["before"], row["after"]
        reviewer = folder == review_folder
        source_rel = ("mutants_final/" if reviewer else "mutants/") + name + ".py"
        full_source = (S / folder / source_rel).read_text()
        need(source.count(before) == 1 and full_source == source.replace(before, after, 1), "Whole-source one-defect mapping differs")
        need(sha(full_source.encode()) == row["sha256"], "Mutation manifest source hash differs")
        source_name = "review_controls.py" if reviewer else "controls.py"
        exact_diff = "".join(difflib.unified_diff(source.splitlines(True), full_source.splitlines(True), fromfile=source_name, tofile=name + ".py"))
        diff_path = S / folder / (source_rel[:-3] + ".diff")
        need(diff_path.read_text() == exact_diff, "Original mutation diff differs")
        logged = existing_run(folder, source_rel, source_rel[:-3] + ".result.json",
                              "logs/" + ("final_" if reviewer else "mutant_") + name,
                              baseline, reviewer=reviewer)
        output.append({"name": name, "before": before, "after": after, "occurrences": 1,
                       "original_diff": str(diff_path.relative_to(S)), **logged})

history = load(review_folder + "/reviewer_initial_history_comparison.json")
retired_names = [r["name"] for r in history["retired_baseline_rows"]]
need(len(retired_names) == 3 and history["initial_baseline_reused_rows"] == 61, "Control-refinement history drift")
initial = load(review_folder + "/independent_baseline.json")["rows"]
retained_initial = [r for r in initial if r["name"] not in retired_names]
need(retained_initial == [r for r in review_rows if r["name"] in {x["name"] for x in retained_initial}], "Retained baseline rows changed")
for record in history["variants"]:
    first = load(review_folder + "/mutants/" + record["name"] + ".result.json")["rows"]
    final = load(review_folder + "/mutants_final/" + record["name"] + ".result.json")["rows"]
    same = [r for r in first if r["name"] not in retired_names]
    need(same == [r for r in final if r["name"] in {x["name"] for x in same}]
         and len(same) == record["identical_reused_rows"] == 61, "Retained initial mutation rows changed")

sp = {
    "key": "Massive_carrier", "claim": "massive_boost_carrier_bounded_theorem_note_2026-10-12",
    "source": "MASSIVE_BOOST_CARRIER_PROBE.md", "source_sha": PINS["MASSIVE_BOOST_CARRIER_PROBE.md"],
    "report": "MASSIVE_BOOST_CARRIER_REVIEW.md", "report_sha": PINS["MASSIVE_BOOST_CARRIER_REVIEW.md"],
    "folder": author_folder, "review": review_folder, "helper": "controls.py", "helper_sha": PINS[author_folder + "/controls.py"],
    "author_receipt": "receipt.json", "author_receipt_sha": PINS[author_folder + "/receipt.json"],
    "review_receipt": "receipt.json", "review_receipt_sha": PINS[review_folder + "/receipt.json"],
    "root_coverage": "Massive_carrier_root_review_coverage.json", "root_coverage_sha": PINS["Massive_carrier_root_review_coverage.json"],
    "note": "MASSIVE_BOOST_CARRIER_BOUNDED_THEOREM_NOTE_2026-10-12.md", "runner": "massive_boost_carrier_2026_10_12.py",
    "dependencies": dependencies, "deps": [r["claim_id"] for r in dependencies],
    "baseline": author_baseline, "mutations": author_mutations,
    "mutation_kind": "original_literal_whole_source", "mutation_authority": author_folder + "/materialize_mutants.py",
    "baseline_totals": {"passed": author_baseline["observed_passed"], "failed": author_baseline["observed_failed"], "semantics": "Original finite predicates; no combined reviewer count"},
    "mutation_count": len(author_mutations), "expected_mutation_survivors": [r["name"] for r in author_mutations if r["observed_exit"] == 0],
    "review_evidence": {"baseline": review_baseline, "mutations": review_mutations,
                        "refinement_history": {"source": review_folder + "/reviewer_initial_history_comparison.json", "retired_rows": retired_names,
                                               "retained_per_original_run": 61, "original_mutants_with_retained_rows": len(history["variants"]),
                                               "new_mutant": "commutant_omit_translations", "retired_rows_scientific_support": False},
                        "replay_status": "Previously reviewed independent evidence; no fresh independent run in this preparation or required solely to increase counts."},
    "canonical_stdout_policy": "Exact complete original stdout, including all 84 rows, five original scope lines and original TOTAL; no output suffix or environment mapping is authorized.",
    "canonical_json_policy": "Preserve and compare the complete main-local output dictionary, including rows, scope, all counts, failures and actual versions. Only the JSON file write is suppressed; no field or result calculation is changed. Differences fail closed unless root later explicitly approves and records a narrow administrative map.",
    "canonical_result_observation": {"function": "main", "local_name": "output", "event": "return", "policy": "Future observational hook may record the existing object without altering values, branches, exceptions, stdout/stderr or exit status; restrict any injection to exact pinned canonical/mutant paths and preserve full instrumentation/environment maps."},
    "audit_inputs": ["docs/MASSIVE_BOOST_CARRIER_BOUNDED_THEOREM_NOTE_2026-10-12.md"] + ["docs/" + d["note"] for d in dependencies] + [PACKET + "/EVIDENCE_MAP.json"],
    "future_timeout_seconds": 60, "science_executed_during_preparation": False,
}
config = {"packet": PACKET, "required_base": BASE,
          "base_policy": "Explicit --worktree and --base, exact frozen HEAD and clean checkout/index required before writes. No preparer Git lookup. All dependency/instruction/source bytes and membership must remain pinned.",
          "root_reported_checkout": str(W), "root_reported_publication_context": "Extend existing regular PR9488, stacked on PR9486; no preparation PR action.",
          "specs": [sp], "planned_graph_delta": {"new_nodes": 1, "new_direct_edges": len(dependencies), "old_nodes": "All prior nodes/edges must remain intact; actual graph validation is root-owned."},
          "status": "Frozen source/data specifications only; future canonical outcomes are not predeclared."}
save("SPECIFICATIONS.json", config)

paths, directory_membership, root_membership, excluded = set(), {}, {}, []
for folder in [author_folder, review_folder]:
    members = []
    for path in sorted((S / folder).rglob("*")):
        need(not path.is_symlink(), "Symlink in source bundle")
        if not path.is_file():
            continue
        if "__pycache__" in path.parts or path.name == ".DS_Store":
            excluded.append({"original": str(path), "reason": "Transient bytecode/desktop metadata; no own source excluded"})
            continue
        members.append(str(path.relative_to(S)))
        paths.add(path)
    directory_membership[folder] = members
for pattern in ["Massive_carrier_root_*", "root_massive_*", "verify_massive_*"]:
    members = []
    for top in sorted(S.glob(pattern)):
        for path in [top] if top.is_file() else sorted(top.rglob("*")):
            need(not path.is_symlink(), "Symlink in root evidence")
            if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
                members.append(str(path.relative_to(S)))
                paths.add(path)
    root_membership[pattern] = sorted(members)
paths.update(S / name for name in [sp["source"], sp["report"], "ROOT_MASSIVE_BOOST_CARRIER_LEAD.md"])
external_sources = load(author_folder + "/EXTERNAL_RAW_INVENTORY.json")
external_by_name = {Path(row["path"]).name: row for row in external_sources}
rows = []
for path in sorted(paths):
    row = bind(path)
    if "external_raw" in path.parts and path.name in external_by_name:
        reference = external_by_name[path.name]
        need(row["sha256"] == reference["sha256"] and row["bytes"] == reference["bytes"], "External original/copy binding mismatch")
        row.update({"classification": "external_primary_content", "source_url": reference["url"],
                    "source_version": "arXiv:0912.0574v1" if "prasad" in path.name else "2017 lecture deck; not von Neumann 1931",
                    "source_record": reference, "disposition": "Inventory only; raw paper content remains external, unchanged, and is not bundled."})
    else:
        need(path.suffix.lower() not in {".pdf", ".tex", ".png", ".jpg", ".jpeg", ".webp", ".html", ".gz", ".zip", ".tar"}, "Unclassified possible external content")
        row.update({"classification": "own_or_repository_evidence", "preserved": "evidence/" + str(path.relative_to(S)) + ".gz"})
    rows.append(row)

previous = json.loads((S / "boost_gap_fock_closure_preparation/INPUT_INVENTORY.json").read_text())
previous_instructions = {r["worktree_relative"]: r["sha256"] for r in previous["files"] if "worktree_relative" in r
                         and (r["worktree_relative"] == "AGENTS.md" or r["worktree_relative"].startswith("docs/ai_methodology/"))}
instruction_checks = []
repo_paths = set(previous_instructions) | {"docs/" + d["note"] for d in dependencies} | {
    ".claude/science/physics-loops/toe-boost-gap-fock-closure-20261012/reconstruct.py",
    "scripts/runner_cache.py", "scripts/codex_audit_runner.py", "scripts/vocab_lint.py",
}
for relative in sorted(repo_paths):
    row = bind(W / relative)
    if relative in previous_instructions:
        need(row["sha256"] == previous_instructions[relative], "Previously read instruction identity changed; reread required")
        instruction_checks.append({"path": relative, "sha256": row["sha256"], "unchanged_from_previously_read": True})
    row.update({"classification": "own_or_repository_evidence", "worktree_relative": relative,
                "preserved": "evidence/consulted_worktree/" + relative + ".gz"})
    rows.append(row)
skill = Path("/Users/jonreilly/.codex/skills/ai-physics-lane-builder/SKILL.md")
old_skill = next(r for r in previous["files"] if r["original"] == str(skill))
need(bind(skill)["sha256"] == old_skill["sha256"], "Previously read packaging skill changed")
rows.append({**bind(skill), "classification": "own_or_repository_evidence", "preserved": "evidence/consulted_skill/ai-physics-lane-builder/SKILL.md.gz"})
for path in [S / "prepare_boost_gap_fock_closure_publication.py", S / "boost_gap_fock_closure_preparation/reconstruct.py"]:
    rows.append({**bind(path), "classification": "own_or_repository_evidence", "preserved": "evidence/pattern_sources/" + str(path.relative_to(S)) + ".gz"})
need(len({r["original"] for r in rows}) == len(rows), "Duplicate frozen origin")
for row in rows:
    if row["classification"] == "own_or_repository_evidence":
        content = Path(row["original"]).read_bytes()
        packed = gzip.compress(content, mtime=0)
        snapshot = "frozen_inputs/" + row["preserved"]
        path = Q / snapshot
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(packed)
        row["preparation_snapshot"] = snapshot
        row["compressed_sha256"] = sha(packed)
inventory = {"base_policy": config["base_policy"], "required_base": BASE,
             "capture_scope": "Complete two original evidence folders, source/review, root massive coverage/read/evidence results and helpers, original lead, current direct canonical dependencies/instructions and named pattern/API sources. Full own bytes are frozen compressed; four raw third-party PDF originals/copies remain external with identities.",
             "files": rows, "source_directory_membership": directory_membership, "root_evidence_glob_membership": root_membership,
             "external_reference_sources": external_sources, "excluded_transient_files": excluded}
save("INPUT_INVENTORY.json", inventory)
save("CURRENT_INSTRUCTION_IDENTITIES.json", {"previous_read_source": "boost_gap_fock_closure_preparation/INPUT_INVENTORY.json",
     "checks": instruction_checks, "skill": bind(skill), "new_instruction_read_required": False,
     "git_or_remote_lookup": False, "root_reported_base": BASE})
save("ORIGINAL_EVIDENCE_MAP_PREVIEW.json", {"scope": "Exact own-input gzip map; runtime preparation-source/receipt metadata will be added without self-reference.",
     "files": [{k:r[k] for k in ["original", "preserved", "bytes", "sha256", "compressed_sha256", "preparation_snapshot"]}
               for r in rows if r["classification"] == "own_or_repository_evidence"],
     "external_files": [r for r in rows if r["classification"] == "external_primary_content"]})
print(json.dumps({"frozen_inputs": len(rows), "own": sum(r["classification"] == "own_or_repository_evidence" for r in rows),
                  "external": sum(r["classification"] == "external_primary_content" for r in rows),
                  "author_mutations": len(author_mutations), "reviewer_mutations": len(review_mutations),
                  "no_science_no_worktree_writes": True}, indent=2))
