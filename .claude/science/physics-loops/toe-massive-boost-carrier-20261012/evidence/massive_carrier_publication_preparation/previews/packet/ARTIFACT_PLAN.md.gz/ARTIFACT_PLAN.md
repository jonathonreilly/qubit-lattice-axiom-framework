# One whole primary and complete original evidence

The proposed note is docs/MASSIVE_BOOST_CARRIER_BOUNDED_THEOREM_NOTE_2026-10-12.md.
Its primary is scripts/massive_boost_carrier_2026_10_12.py, preserving the entire
author controls.py. Its original 84 rows, five scope lines and TOTAL are
unchanged. Only input/timeout declarations, an assertion guard, optional unused
--output and suppression of the JSON file write are mapped. All predicates,
thresholds, row values, output-dictionary calculations and exit gates remain.

SPECIFICATIONS.json binds the complete original baseline/results and all eight
author source variants, plus the original reviewer baseline and nine variants.
Canonical mutation previews are whole mapped helpers with precisely the one
original literal substitution. This package executes none of them. All prior
source versions and original stdout/stderr/results are preserved, including
author source before the isolated-mass qualification, the 61-row refinement
history and the coordinate-equivalent witness disclosure. Counts retain their
original meanings and are not aggregated into an apparent stronger check.
