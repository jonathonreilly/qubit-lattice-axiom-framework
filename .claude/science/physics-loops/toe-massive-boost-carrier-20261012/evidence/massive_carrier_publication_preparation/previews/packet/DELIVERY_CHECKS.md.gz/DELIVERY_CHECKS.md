# Actual preparation status and remaining gates

Completed by preparation: source/data identity inventory, complete own-input
snapshots, exact administrative previews/maps, source-only mutation binding
and syntax/anchor/AST checks. No scientific helper, canonical primary, mutation,
cache API, reconstruction program, vocabulary command, graph, lint or audit
compatibility program has been executed by the preparer. No worktree, Git,
remote, prompt or applied audit state changed. No future result is predeclared.

The original complete stdout is the future comparison specimen; no new scope
suffix or rewritten original version line is permitted. The complete existing
output dictionary must also be captured and compared. Save INNER raw returns
before outer identity checks and OUTER raw tuples before later inspection or
freshness. Preserve all failed attempts and original evidence untouched.

Pending root gates: full instantiated source read, reconstruction before and
after checked vocabulary --fix/report-only, canonical execution/cache, eight
exact whole-source mutant replays, graph one-node/four-edge acknowledgment,
focused audit-system compatibility against the exact base, metadata/link checks,
current source/stream/manifests, freshness and final changed-evidence read.
Global combined candidate validation and strict audit lint remain separate
independent landing gates. SOURCE_IDENTITIES initially covers all prepared
payload paths except itself and must be refreshed/supplemented after later
verification changes. No unrun gate is marked passed by this record.
