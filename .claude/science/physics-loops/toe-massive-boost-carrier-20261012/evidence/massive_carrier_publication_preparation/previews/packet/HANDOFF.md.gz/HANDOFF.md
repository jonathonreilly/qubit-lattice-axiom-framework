# Root-owned execution and publication handoff

Required explicit base: `@BASE@`. Required explicit checkout: `@WORKTREE@`.
Root reported the base as 358fdf795a5504d4d7fd13344bbbd5df5504ebea, clean,
with the preceding five-note milestone in regular PR9488 stacked on PR9486.
Preparation made no Git/ref query. The script must refuse a different explicit
base, dirty checkout/index, changed source/instruction/dependency/freeze,
duplicate target, existing target or symlink. It creates only the one new note,
one whole primary and this separate packet, and never changes existing files.

Root reads the entire previews, exact 10 administrative edits and appendix,
all packet templates and complete source specifications before execution.
After preparation, run reconstruct.py first; run vocabulary --fix with checked
JSON, then report-only and reconstruction again. Any canonical-byte change
requires an explicit reviewed source map before caching; fail closed otherwise.

Call runner_cache.execute_and_write_cache(path,60) for the canonical primary.
Preserve the full raw INNER execute_runner return immediately after return,
outside the cache and before the outer wrapper can inspect identity or reject
the run. Preserve the entire OUTER returned tuple immediately before any later
inspection/freshness call. Failures, exceptions, partial output, nonzero exits
and timeouts must remain durable even if the outer wrapper rejects the run.
An observational shim must keep the original object/API/command identity and
must not alter values, branches, exceptions, streams or status. Pin all shim
source/environment mapping and restrict injection to this exact primary or
its exact whole-source mutants. No raw returned result may be discarded.

Observe the existing main-local output dictionary without changing it, and
compare its complete JSON calculation and full stdout with frozen originals.
No comparison map, numeric tolerance or environment normalization is authorized
by this preparation. Replay all eight canonical whole-source mutations using
only the original literal edits and gate definitions. Preserve complete source,
stdout/stderr, raw returns, observed output dictionaries, timing, timeout and
exit status. Expected historical failures/survivors are comparison specimens,
not declared future passes. No redundant independent science rerun is needed.

Build and inspect the graph/manifest: intended delta is one node and four direct
edges, with every old node/edge intact. Run focused audit-system compatibility
against exactly @BASE@ with durable raw logs. Root owns final metadata, links
with display/inline math stripped, source manifests, actual cache freshness,
full final source/evidence read and extension of existing PR9488. Combined
candidate validation and strict audit lint remain separate landing gates.
Preparation performs no Git mutation, PR action, audit application or prompt
edit. Do not rerun or alter the completed five-note delivery solely because
this packet is added. The sole live campaign checkpoint stays root-owned.
