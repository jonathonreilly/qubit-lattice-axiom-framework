"""Source/data-only validation; never import/execute the prepared programs.

Writes only STATIC_CHECKS.json here. No Git, cache, science, graph, lint or
worktree action. This does not substitute for root runtime verification.
"""
import ast
import copy
import gzip
import hashlib
import json
import posixpath
import re
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "microscopic_boost_worktree"
CONFIG = json.loads((Q / "SPECIFICATIONS.json").read_text())
SP = CONFIG["specs"][0]
MAP = json.loads((Q / "TRANSFORM_PLANS.json").read_text())
INV = json.loads((Q / "INPUT_INVENTORY.json").read_text())
TEMPLATES = json.loads((Q / "PACKET_TEMPLATES.json").read_text())
PACKET = CONFIG["packet"]


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strip_math_and_code(text):
    for pattern in [r"```[\s\S]*?```", r"~~~[\s\S]*?~~~", r"\\\[[\s\S]*?\\\]", r"\\\([\s\S]*?\\\)", r"\$\$[\s\S]*?\$\$", r"(?<!\\)\$[^$\n]*?(?<!\\)\$", r"`[^`\n]*`"]:
        text = re.sub(pattern, "", text)
    return text


def members(folder):
    need(folder.is_dir() and not folder.is_symlink(), "Source directory changed")
    result = []
    for path in sorted(folder.rglob("*")):
        need(not path.is_symlink(), "Symlink in source directory")
        if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
            result.append(str(path.relative_to(S)))
    return result


input_bytes = {}
for row in INV["files"]:
    path = W / row["worktree_relative"] if "worktree_relative" in row else Path(row["original"])
    need(path.is_file() and not path.is_symlink(), "Missing/nonregular original")
    data = path.read_bytes()
    need(sha(data) == row["sha256"] and len(data) == row["bytes"], "Original identity changed: " + str(path))
    need(row["original"] not in input_bytes, "Duplicate input original")
    input_bytes[row["original"]] = data
    if row["classification"] == "own_or_repository_evidence":
        packed = (Q / row["preparation_snapshot"]).read_bytes()
        need(sha(packed) == row["compressed_sha256"] and gzip.decompress(packed) == data, "Input gzip snapshot changed")
    else:
        need(row["classification"] == "external_primary_content" and "preserved" not in row and "preparation_snapshot" not in row, "Raw third-party content was bundled")
for folder, expected in INV["source_directory_membership"].items():
    need(members(S / folder) == expected, "Source-folder membership changed")
for pattern, expected in INV["root_evidence_glob_membership"].items():
    actual = []
    for top in sorted(S.glob(pattern)):
        need(not top.is_symlink(), "Root source symlink")
        for path in [top] if top.is_file() else sorted(top.rglob("*")):
            need(not path.is_symlink(), "Root source symlink")
            if path.is_file() and "__pycache__" not in path.parts and path.name != ".DS_Store":
                actual.append(str(path.relative_to(S)))
    need(sorted(actual) == expected, "Root evidence membership changed")

prospective = {}
for row in MAP["outputs"]:
    original = input_bytes[row["source_path"]]
    need(sha(original) == row["source_sha256"] and len(original) == row["source_bytes"], "Mapped source mismatch")
    text = original.decode()
    for edit in row["edits"]:
        need(edit["occurrences"] == 1 and text.count(edit["before"]) == 1, "Ambiguous exact map")
        text = text.replace(edit["before"], edit["after"], 1)
    text += row["appended_text"]
    final = (Q / "previews" / row["publication_path"]).read_bytes()
    need(final == text.encode() and sha(final) == row["publication_sha256"] and len(final) == row["publication_bytes"], "Preview reconstruction differs")
    if row["appended_text"]:
        need(text.endswith(row["appended_text"]), "Appendix position changed")
        text = text[:-len(row["appended_text"])]
    for edit in reversed(row["edits"]):
        need(text.count(edit["after"]) == 1, "Ambiguous reverse administrative map")
        text = text.replace(edit["after"], edit["before"], 1)
    need(text.encode() == original, "Reverse map lost original bytes")
    need(row["publication_path"] not in prospective, "Duplicate prospective target")
    prospective[row["publication_path"]] = final

note = prospective["docs/" + SP["note"]].decode()
original_note = (S / SP["source"]).read_text()
original_argument = original_note[original_note.index("## 1. Inputs"):original_note.index("## 9. No-Go")]
publication_argument = note[note.index("## 1. Inputs"):note.index("## 9. No-Go")]
need(publication_argument == original_argument, "Any proof section 1–8 byte changed")
original_math = re.findall(r"\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)", original_note)
need(original_math == re.findall(r"\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)", note), "A displayed or inline mathematical span changed")
need(re.findall(r"\\tag\{(M\d+)\}", original_note) == re.findall(r"\\tag\{(M\d+)\}", note), "Equation tags changed")

original_runner = (S / SP["folder"] / SP["helper"]).read_text()
canonical_runner = prospective["scripts/" + SP["runner"]].decode()
original_tree = ast.parse(original_runner)
canonical_tree = ast.parse(canonical_runner)
# Verify the complete AST after exactly the three declared administrative
# operations. All other nodes, including prints, rows, thresholds, output
# construction, computation branches and the original return, must be equal.
expected_tree = copy.deepcopy(original_tree)
main = next(node for node in expected_tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
removed_writes, changed_cli = 0, 0
kept = []
for node in main.body:
    if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
        call = node.value
        if isinstance(call.func, ast.Attribute) and call.func.attr == "write_text":
            need(ast.unparse(node) == "Path(args.output).write_text(json.dumps(output, indent=2) + '\\n')", "Unexpected result-file write shape")
            removed_writes += 1
            continue
        if isinstance(call.func, ast.Attribute) and call.func.attr == "add_argument" and call.args and isinstance(call.args[0], ast.Constant) and call.args[0].value == "--output":
            need(len(call.keywords) == 1 and call.keywords[0].arg == "required" and ast.literal_eval(call.keywords[0].value) is True, "Unexpected original CLI declaration")
            call.keywords = [ast.keyword(arg="default", value=ast.Constant(value=None))]
            changed_cli += 1
    kept.append(node)
main.body = kept
need((removed_writes, changed_cli) == (1, 1), "Administrative AST operation count differs")
canonical_clean = copy.deepcopy(canonical_tree)
declarations, guard = {}, []
kept = []
for node in canonical_clean.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {"AUDIT_TIMEOUT_SEC", "AUDIT_INPUT_PATHS"}:
        declarations[node.targets[0].id] = ast.literal_eval(node.value)
    elif isinstance(node, ast.If) and ast.unparse(node.test) == "not __debug__":
        guard.append(ast.dump(node, include_attributes=False))
    else:
        kept.append(node)
canonical_clean.body = kept
need(declarations == {"AUDIT_TIMEOUT_SEC": 60, "AUDIT_INPUT_PATHS": SP["audit_inputs"]}, "Canonical audit declarations differ")
expected_guard = ast.parse('if not __debug__:\n    raise RuntimeError("Run without -O: finite control assertions must be enabled")').body[0]
need(guard == [ast.dump(expected_guard, include_attributes=False)], "Assertion guard differs")
need(ast.dump(expected_tree, include_attributes=False) == ast.dump(canonical_clean, include_attributes=False), "Scientific AST or original output/exit gate changed")
mutation_previews = json.loads((Q / "CANONICAL_MUTATION_PREVIEWS.json").read_text())
for mutation, preview in zip(SP["mutations"], mutation_previews):
    need(preview["name"] == mutation["name"] and canonical_runner.count(mutation["before"]) == 1, "Mutation identity/anchor changed")
    data = (Q / preview["preview"]).read_bytes()
    need(data == canonical_runner.replace(mutation["before"], mutation["after"], 1).encode()
         and sha(data) == preview["sha256"] and len(data) == preview["bytes"], "Whole-source canonical mutation preview changed")
need(len(mutation_previews) == len(SP["mutations"]) == SP["mutation_count"], "Original mutation membership changed")

for name, template in TEMPLATES.items():
    need((Q / "previews/packet" / name).read_text() == template, "Packet template preview changed")
    rendered = template.replace("@BASE@", CONFIG["required_base"]).replace('"@WORKTREE@"', json.dumps(str(W))).replace("@WORKTREE@", str(W))
    need("@BASE@" not in rendered and "@WORKTREE@" not in rendered, "Unresolved runtime packet placeholder")
    prospective[PACKET + "/" + name] = rendered.encode()
for name in ["PUBLICATION_EDITS.json", "SPECIFICATIONS.json", "INPUT_INVENTORY.json", "EVIDENCE_MAP.json", "EXTERNAL_SOURCE_INVENTORY.json", "reconstruct.py", "PREPARATION_RECEIPT.json", "SOURCE_IDENTITIES.json"]:
    prospective[PACKET + "/" + name] = b""  # Declared runtime-generated targets, not invented payload bytes.
for row in INV["files"]:
    if row["classification"] == "own_or_repository_evidence":
        target = PACKET + "/" + row["preserved"]
        need(target not in prospective, "Duplicate own evidence target")
        prospective[target] = (Q / row["preparation_snapshot"]).read_bytes()
link_records = []
for relative, data in list(prospective.items()):
    if not relative.endswith(".md"):
        continue
    clean = strip_math_and_code(data.decode())
    for label, target in re.findall(r"\[([^\]\n]+)\]\(([^)\s]+)\)", clean):
        if re.match(r"(?:https?|mailto):", target) or target.startswith("#"):
            link_records.append({"source": relative, "target": target, "scope": "External or document anchor; not fetched"})
            continue
        target = target.split("#", 1)[0]
        need(not Path(target).is_absolute(), "Nonportable publication link")
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(relative), target))
        need(not resolved.startswith("../") and (resolved in prospective or (W / resolved).is_file()), "Broken local prospective link: " + resolved)
        link_records.append({"source": relative, "target": target, "resolved": resolved})
direct_links = {r["resolved"] for r in link_records if r["source"] == "docs/" + SP["note"] and r.get("resolved", "").startswith("docs/")}
need(direct_links == {"docs/" + d["note"] for d in SP["dependencies"]}, "Actual readable proof links differ from the four specified dependencies")
header = note.split("---", 2)[1]
for key in ["claim_id", "claim_type", "claim_scope", "upstream_dependencies", "runner", "actual_current_surface_status", "target_claim_type", "trace_class", "target_claim_id", "target_blocker_text", "source_of_blocker_text", "reachability_to_target", "artifact_role", "next_trace_action", "conditional_surface_status", "hypothetical_axiom_status", "admitted_observation_status", "claim_type_reason", "audit_required_before_effective_retained", "bare_retained_allowed"]:
    need(re.search(r"(?m)^" + key + ":", header) is not None, "Missing claim metadata field")
need(MAP["pairing"] in note and MAP["pairing"] in TEMPLATES["REVIEW_HISTORY.md"] and MAP["pairing"] in TEMPLATES["PR_BACKLOG.md"], "Pairing disclosure missing")

compiled = []
for path in [S / "prepare_massive_carrier_publication.py", Q / "reconstruct.py", Q / "capture_inputs.py", Q / "build_plans.py", Q / "build_packet_templates.py", Q / "static_validate.py"] + sorted((Q / "previews/scripts").glob("*.py")) + sorted((Q / "previews/mutants").glob("*.py")):
    compile(path.read_bytes(), str(path), "exec")
    compiled.append({"path": str(path), "sha256": sha(path.read_bytes())})
script_bytes = (S / "prepare_massive_carrier_publication.py").read_bytes()
normalized, n = re.subn(rb'(?m)^PREPARATION_FREEZE_SHA256 = "[0-9a-f]{64}"$', b'PREPARATION_FREEZE_SHA256 = "' + b'0' * 64 + b'"', script_bytes)
need(n == 1, "Ambiguous script freeze normalization")
for row in compiled:
    if row["path"] == str(S / "prepare_massive_carrier_publication.py"):
        row.pop("sha256")
        row["normalized_sha256"] = sha(normalized)
checks = {"status": "Source-only checks completed; no runtime outcome or scientific verdict", "source_input_files": len(INV["files"]),
          "complete_own_input_snapshots": sum(r["classification"] == "own_or_repository_evidence" for r in INV["files"]),
          "external_files_not_bundled": sum(r["classification"] == "external_primary_content" for r in INV["files"]),
          "exact_forward_and_reverse_maps": len(MAP["outputs"]), "administrative_edits": sum(len(r["edits"]) for r in MAP["outputs"]),
          "proof_sections_1_to_8_byte_exact": True, "original_math_spans_byte_exact": len(original_math), "equation_tags_unchanged": True,
          "full_primary_ast_equal_modulo_three_declared_admin_operations": True,
          "original_prints_output_dictionary_all_calculations_gates_unchanged": True, "canonical_whole_source_mutant_previews": len(mutation_previews),
          "packet_templates": len(TEMPLATES), "math_aware_local_links_checked": link_records,
          "intended_direct_dependency_edges": sorted(direct_links), "compiled_only": compiled,
          "preparation_script_normalized_sha256": sha(normalized),
          "not_executed": ["preparation program", "reconstruct.py", "canonical/mutant/independent science", "runner/cache API", "vocabulary fixer/lint", "graph", "audit compatibility", "Git"],
          "worktree_writes": 0, "editable_prompt_files_changed": [], "root_runtime_and_final_review_still_required": True}
(Q / "STATIC_CHECKS.json").write_text(json.dumps(checks, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({k:checks[k] for k in ["source_input_files", "complete_own_input_snapshots", "external_files_not_bundled", "exact_forward_and_reverse_maps", "administrative_edits", "proof_sections_1_to_8_byte_exact", "original_math_spans_byte_exact", "full_primary_ast_equal_modulo_three_declared_admin_operations", "canonical_whole_source_mutant_previews", "packet_templates", "worktree_writes"]}, indent=2))
