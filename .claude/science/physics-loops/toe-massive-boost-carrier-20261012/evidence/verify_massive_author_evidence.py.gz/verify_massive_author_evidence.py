from pathlib import Path
from datetime import datetime, timezone
import difflib, hashlib, json, subprocess, time

S = Path(__file__).resolve().parent
D = S / 'massive_boost_carrier'
O = S / 'root_massive_author_verification'
O.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = {
    S/'MASSIVE_BOOST_CARRIER_PROBE.md':'eb85ee2fda1690373e7bb7bdf96bc255e86235d672e8e9f18e46c6553078e310',
    D/'receipt.json':'10f408ded24c9f65a3b5a8205bc0b6e78b8b63aae7242888058339bfa10c53f0',
    D/'evidence_manifest.json':'37d0b050a9b81750d7fd190515ad3ce886e804286d19f301a56156b851840f87',
    D/'controls.py':'bd7a1bdce6cb0416adaedb88e144f52106b20b48af7a94582bdcc1680e8619b1',
    D/'check_evidence.py':'4ce4308d69c54604ea9f370272a4c6989b7ae09c79fc6058acd9e2d5094e5a03',
}
for p,h in pins.items():
    assert sha(p)==h, p
files=load(D/'evidence_manifest.json')['files']
assert len(files)==143
for row in files:
    p=Path(row['path'])
    assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],p
bindings=load(D/'SOURCE_BINDINGS.json')['source_bindings']
assert len(bindings)==27
for row in bindings:
    assert sha(row['source'])==row['live_sha256_at_freeze']==row['sha256']==sha(row['snapshot']),row
before=(D/'PROOF_BEFORE_CONTROLS.md').read_text()
after=(S/'MASSIVE_BOOST_CARRIER_PROBE.md').read_text()
assert sha(D/'PROOF_BEFORE_CONTROLS.md')=='b26cc4c0f9536ad4a6763083aed8a0d70fa9b21086b712389a4882b3e843065c'
delta=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
    fromfile='PROOF_BEFORE_CONTROLS.md',tofile='MASSIVE_BOOST_CARRIER_PROBE.md'))
assert delta==(D/'PROOF_CHANGES.diff').read_text()
runs=[]
for name,args in [('bindings',['--manifest',str(D/'evidence_manifest.json')]),
                  ('controls',['--summarize',str(O/'control_report.json')])]:
    cmd=['python3',str(D/'check_evidence.py'),*args]
    start=datetime.now(timezone.utc).isoformat(); t=time.monotonic()
    r=subprocess.run(cmd,cwd=D,capture_output=True,timeout=60)
    for label,data in [('stdout',r.stdout),('stderr',r.stderr)]:
        (O/(name+'.'+label)).write_bytes(data)
    receipt={'command':cmd,'utc':start,'elapsed_seconds':time.monotonic()-t,
             'timeout_seconds':60,'exit_code':r.returncode,
             'stdout_sha256':sha(O/(name+'.stdout')),'stderr_sha256':sha(O/(name+'.stderr'))}
    (O/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    runs.append(receipt)
    r.check_returncode()
assert load(O/'control_report.json')==load(D/'control_report.json')
base=load(D/'controls_initial.json')
base_rows={r['name']:r for r in base['rows']}
assert len(base_rows)==84
report=load(O/'control_report.json')
lines=['BASELINE: every original row, all fields.']
lines.extend(json.dumps(r,sort_keys=True) for r in base['rows'])
lines.append('SCOPE '+json.dumps(base['scope'],sort_keys=True))
for run in report['runs'][1:]:
    lines.append('RUN '+json.dumps({k:v for k,v in run.items() if k!='changed_rows'},sort_keys=True))
    changed={r['name']:r for r in run['changed_rows']}
    for name,row in changed.items():
        differences={k:v for k,v in row.items() if base_rows[name].get(k)!=v}
        removed=[k for k in base_rows[name] if k not in row]
        rebuilt={**base_rows[name],**differences}
        for k in removed:rebuilt.pop(k)
        assert rebuilt==row
        lines.append('DELTA '+json.dumps({'name':name,'changed_fields':differences,'removed_fields':removed},sort_keys=True))
    lines.append('UNCHANGED '+json.dumps([n for n in base_rows if n not in changed]))
(O/'all_rows_lossless.txt').write_text('\n'.join(lines)+'\n')
result={'utc':datetime.now(timezone.utc).isoformat(),'pins':{str(p):h for p,h in pins.items()},
        'evidence_bindings':len(files),'live_upstream_bindings':len(bindings),'proof_diff_exact':True,
        'eight_whole_source_mutations_exact':True,'baseline_rows':84,
        'author_executions':len(report['runs']),'science_rerun':False,
        'provenance_runs':runs,'original_failure_counts':[r['fail_count'] for r in report['runs'][1:]],
        'read_aid':str(O/'all_rows_lossless.txt'),'read_aid_sha256':sha(O/'all_rows_lossless.txt'),
        'limitations':'Root coauthor binding check, not independent proof review. Row read coverage is recorded separately only after inspection.',
        'operational_recovery':'Initial source_manifest metadata read wrongly assumed a dict instead of a list; corrected read only. Initial reviewer brief used manifest.json instead of evidence_manifest.json, corrected before source work.'}
(S/'Massive_carrier_root_author_evidence_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['pins','provenance_runs']},indent=2))
