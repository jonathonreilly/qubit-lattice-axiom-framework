#!/usr/bin/env python3
"""Root read-only source/evidence validation; writes only a new root report.

No scientific helper is imported or rerun. No audit verdict is assigned.
"""
from pathlib import Path
import datetime, hashlib, json, time

S = Path(__file__).resolve().parent
R = S / 'massive_boost_carrier_review'
O = S / 'root_massive_review_verification'
PIN = '9be077726fec56a7bd2b915f84d5c368dd77e674f449d026fd5b7f0526cf5d6c'

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tic = time.monotonic()
    O.mkdir(exist_ok=False)
    assert digest(R / 'evidence_manifest.json') == PIN
    assert digest(R / 'receipt.json') == 'c861afa9074c22198531bd890976c7154f25e0e08899ef3b2de2792535bf985d'
    checked = []
    for row in read(R / 'evidence_manifest.json')['files']:
        p = Path(row['path'])
        assert p.stat().st_size == row['bytes'] and digest(p) == row['sha256'], str(p)
        checked.append(row)
    receipt = read(R / 'receipt.json')
    for key in ['target','report','evidence_manifest','independent_freeze','exposure_and_overlap','read_coverage','failures','current_checkpoint']:
        row = receipt[key]
        assert digest(row['path']) == row['sha256']
        assert Path(row['path']).stat().st_size == row['bytes']
    history = {}
    for name, old in [('review_controls.py','review_controls_initial.py'),('materialize_and_run.py','materialize_and_run_initial.py')]:
        p = R / 'history' / old
        history[(str(R / name), digest(p))] = p
    logs = []
    for p in sorted((R / 'logs').glob('*/receipt.json')):
        d = read(p)
        for source in d.get('sources', []):
            actual = history.get((source['path'],source['sha256']), Path(source['path']))
            assert digest(actual) == source['sha256'], str(actual)
        for stream in ['stdout','stderr']:
            q = p.parent / (stream + '.txt')
            assert digest(q) == d[stream]['sha256'] and q.stat().st_size == d[stream]['bytes']
        logs.append(dict(run=p.parent.name, **{k:d[k] for k in ['command','started_utc','ended_utc','exit_code','timed_out','timeout_seconds','elapsed_seconds'] if k in d}))
    base = read(R / 'independent_baseline_final.json')
    rows = {r['name']:r for r in base['rows']}
    assert len(rows) == 64 and base['failed'] == 0
    out = ['BASE_METADATA ' + json.dumps({k:v for k,v in base.items() if k != 'rows'}, separators=(',',':'))]
    out.extend('BASE '+json.dumps(r,separators=(',',':')) for r in base['rows'])
    source = (R / 'review_controls.py').read_text()
    manifest = read(R / 'mutants_final/manifest.json')
    assert digest(R / 'review_controls.py') == manifest['baseline_sha256']
    variant_reports, total_changed, changed_survivors = [], 0, 0
    for v in manifest['variants']:
        assert source.count(v['before']) == 1
        assert Path(v['path']).read_text() == source.replace(v['before'],v['after'],1)
        assert digest(v['path']) == v['sha256']
        d = read(v['output'])
        assert {r['name'] for r in d['rows']} == set(rows)
        changed = [r for r in d['rows'] if r != rows[r['name']]]
        unchanged = [r['name'] for r in d['rows'] if r == rows[r['name']]]
        failures = [r for r in d['rows'] if not r['passed']]
        assert len(failures) == d['failed'] > 0 and v['exit_code'] == 1
        total_changed += len(changed)
        changed_survivors += sum(r['passed'] for r in changed)
        vr = dict(name=v['name'],before=v['before'],after=v['after'],failures=len(failures),unchanged=unchanged)
        variant_reports.append(vr)
        out.append('VARIANT '+json.dumps(vr,separators=(',',':')))
        out.extend('CHANGED '+json.dumps(r,separators=(',',':')) for r in changed)
    assert (total_changed, changed_survivors) == (89,15)
    old = read(R / 'independent_baseline.json')
    retired = [r for r in old['rows'] if r['name'] not in rows]
    reused = [r for r in old['rows'] if r['name'] in rows]
    assert len(retired) == 3 and len(reused) == 61
    assert all(r == rows[r['name']] for r in reused)
    out.extend('RETIRED_BASE '+json.dumps(r,separators=(',',':')) for r in retired)
    for v in read(R / 'mutants/manifest.json')['variants']:
        old_rows = read(v['output'])['rows']
        new_rows = {r['name']:r for r in read(R / 'mutants_final' / (v['name']+'.result.json'))['rows']}
        kept = [r for r in old_rows if r['name'] in new_rows]
        assert len(kept) == 61 and all(r == new_rows[r['name']] for r in kept)
        out.append('RETIRED_VARIANT '+json.dumps(dict(name=v['name'],reused_exactly=61,retired=[r for r in old_rows if r['name'] not in new_rows]),separators=(',',':')))
    original = S / 'massive_boost_carrier/logs/controls_initial/stdout.txt'
    replay = R / 'logs/author_baseline_replay/stdout.txt'
    assert original.read_bytes() == replay.read_bytes()
    out.extend('EXECUTION '+json.dumps(r,separators=(',',':')) for r in logs)
    (O / 'all_rows_lossless.txt').write_text('\n'.join(out)+'\n')
    report = dict(started_utc=started,elapsed_seconds=time.monotonic()-tic,manifest_bindings=len(checked),reviewer_executions=len(logs),baseline_rows=64,mutants=len(variant_reports),changed_rows=total_changed,changed_survivors=changed_survivors,original_author_stdout_bytes=original.stat().st_size,original_author_stdout_sha256=digest(original),readable_rows_sha256=digest(O / 'all_rows_lossless.txt'),verified_records=checked,role='Provenance and complete result projection only; root still must read scientific values; no new scientific runs or verdict.')
    (O / 'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'verified_records'},indent=2))

if __name__ == '__main__':
    main()
