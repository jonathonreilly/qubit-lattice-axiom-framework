#!/usr/bin/env python3
"""Exact procedural source adaptation only; never execute proposed runtime programs."""
from pathlib import Path
import ast, hashlib, json
Q=Path(__file__).resolve().parent;T=Q/'procedural_template'
def replace(s,a,b):
    if a not in s:raise ValueError('Missing exact adaptation context: '+a)
    return s.replace(a,b)
def put(name,s):
    ast.parse(s,filename=name);(Q/name).write_text(s)
def main():
    spec=json.loads((Q/'SPECIFICATIONS.json').read_bytes());base=spec['base'];pr=spec['stack_parent_regular_pr']
    s=(T/'prepare_verify_chirped_kinetic_energy.py').read_text()
    pairs=[('chirped_kinetic_energy_publication_execution','multitime_kinetic_energy_publication_execution'),('toe-chirped-kinetic-energy-20261013','toe-multitime-kinetic-energy-20261013'),('chirped-kinetic-integrity-','multitime-kinetic-integrity-'),("BASE = 'c5eaa6bf752a0893c83c0509c7c349dab53bff14'",'BASE = '+repr(base)),("'chirped_kinetic_law_source_assembly'","'multitime_kinetic_energy_source_assembly'"),('fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38','53f2bfac081b7af2181a162c9b9ec839b982b7a89828b2a18107d65b274bed4a'),("original_source / 'FINAL_FREEZE.json'","original_source / 'SOURCE_FREEZE.json'"),("members | {'FINAL_FREEZE.json'}","members | {'SOURCE_FREEZE.json'}"),("== 161, 'Accepted source count differs'","== 175, 'Accepted source count differs'"),('CHIRPED_SOURCE_ASSEMBLY','MULTITIME_SOURCE_ASSEMBLY'),('fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e','2df2022fb72bbccd1611749d5ab3980f6c9dcbeccb956e80c081437f486c7ea7'),('3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134','6f62765f8bbd09f87e62cb76688d0532846b4788039898f26303411616eef450'),("'independent_core_sha256','no_go_packet_pass'","'independent_core_sha256','comparison_core_sha256','no_go_packet_pass'"),('one_time_scope_and_BV_integrated_phase_reviewed','finite_word_and_measurement_scope_reviewed'),('root_independent_strength_and_phase_precision_reviewed','chirp_and_constant_carrier_parent_distinctions_reviewed'),("'conditional_actual_cell_hypotheses_reviewed',","'conditional_actual_cell_hypotheses_reviewed', 'negative_packet_fail_and_queued_routes_reviewed',"),('physics-loop/toe-modulated-kinetic-energy-20261013','physics-loop/toe-chirped-kinetic-energy-20261013'),("spec['stack_parent_regular_pr']==9517","spec['stack_parent_regular_pr']=="+repr(pr)),("{'nodes':1,'edges':4}","{'nodes':1,'edges':5}"),("{'nodes': 1, 'edges': 4}","{'nodes': 1, 'edges': 5}"),('CHIRPED_BRANCH_PLAN.json','MULTITIME_BRANCH_PLAN.json'),(".endswith('/pull/9517')",".endswith('/pull/'+str("+repr(pr)+"))")]
    for a,b in pairs:s=replace(s,a,b)
    s=replace(s,"status['no_go_packet_pass'] is False,","status['no_go_packet_pass'] is False and status['publication_bound'] is True and\n         status['negative_packet_status'] == 'FAIL / partial-narrowing',")
    s=replace(s,"def source_guards(run, args):\n    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')","def source_guards(run, args):\n    need(datetime.now(timezone.utc) < DEADLINE, 'Campaign hard stop reached')\n    need(isinstance(BASE,str) and re.fullmatch(r'[0-9a-f]{40}',BASE), 'Actual chirp publication head is not bound')")
    s=replace(s,'one_time_conditional_scope','fixed_finite_multitime_conditional_scope')
    s=replace(s,'one-node/four-edge','one-node/five-edge')
    s=replace(s,'Exact four-edge delta differs','Exact five-edge delta differs')
    s=replace(s,'cumulative PR9517 stack plus this milestone review','cumulative chirp parent PR'+str(pr)+' stack plus this milestone review')
    s=replace(s,"        parsed.append(front)","        need(read(WORKTREE / row['path']).count(b'\\nClaim type: bounded_theorem\\n') == 1, 'Standalone graph claim-type line differs')\n        parsed.append(front)")
    put('prepare_verify_multitime_kinetic_energy.py',s)
    c=(T/'run_combined_validation.py').read_text();c=replace(c,'chirped_kinetic_energy_combined_validation_execution','multitime_kinetic_energy_combined_validation_execution');put('run_combined_validation.py',c)
    s=(T/'IDENTITY_TOOL.template.py').read_text()
    for a,b in [('Chirped kinetic','Multi-time kinetic'),('import difflib, gzip, hashlib, json, sys','import difflib, gzip, hashlib, json, posixpath, re, sys'),('toe-chirped-kinetic-energy-20261013','toe-multitime-kinetic-energy-20261013'),('fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38','53f2bfac081b7af2181a162c9b9ec839b982b7a89828b2a18107d65b274bed4a'),('fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e','2df2022fb72bbccd1611749d5ab3980f6c9dcbeccb956e80c081437f486c7ea7'),('3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134','6f62765f8bbd09f87e62cb76688d0532846b4788039898f26303411616eef450')]:s=replace(s,a,b)
    start=s.index('    contract = evidence[\'accepted_source_package\']');end=s.index("    edits = pinned('PUBLICATION_EDITS.json'",start)
    block='''    contract = evidence['accepted_source_package']; prefix = contract['path']+'/'
    def source(name): return archived(prefix+name)
    need(contract['freeze_sha256'] == SOURCE_FREEZE_SHA and sha(source('SOURCE_FREEZE.json')) == SOURCE_FREEZE_SHA, 'Accepted source freeze differs')
    seal = json.loads(source('SOURCE_FREEZE.json')); members = contract['members']
    need(seal['members'] == members and len(members) == 175 and contract['all_files'] == 176, 'Original membership differs')
    wanted = {prefix+r['path'] for r in members} | {prefix+'SOURCE_FREEZE.json'}
    need({p for p in origins if p.startswith(prefix)} == wanted, 'Source package aliases differ')
    for r in members:
        b = source(r['path']); need(sha(b) == r['sha256'] and len(b) == r['bytes'], 'Source member identity differs')
    support = 'payload/docs/multitime_kinetic_energy_support/'
    index = json.loads(source(support+'SOURCE_INDEX.json')); oldrows = {}; decoded = {}
    for row in index['aliases']:
        alias = row['alias']; need(alias not in oldrows, 'Duplicate original source alias'); oldrows[alias] = row
        z = source(row['object']); b = gzip.decompress(z)
        need(sha(z) == row['object_sha256'] and len(z) == row['object_bytes'] and sha(b) == row['sha256'] and len(b) == row['bytes'] and len(b.splitlines()) == row['lines'], 'Original nested source changed')
        decoded[alias] = b
        if row['original_path']: need(archived(row['original_path']) == b, 'Immediate original-source alias differs')
    need(len(oldrows) == 181 and len({r['object'] for r in oldrows.values()}) == index['unique_objects'] == 119, 'Original alias extent differs')
    corrections = json.loads(source(support+'SOURCE_CORRECTIONS.json'))['corrections']
    need(len(corrections) == 4, 'Historical correction extent differs')
    for row in corrections:
        prior = reverse_diff(decoded[row['new_alias']], decoded[row['diff_alias']])
        need(prior == decoded[row['old_alias']] and sha(prior) == row['old_sha256'], 'Exact historical reconstruction differs')
    closures = json.loads(source(support+'SOURCE_CLOSURES.json'))['closures']; closure_count = 0
    need(closures == evidence['source_provenance_closure'] and len(closures) == 7, 'Immediate closure selection differs')
    def closure_pin(alias, expected):
        nonlocal closure_count
        need(alias in oldrows, 'Missing immediate closure member')
        for key in ['sha256','bytes','lines']:
            if key in expected: need(oldrows[alias][key] == expected[key], 'Immediate closure pin differs')
        closure_count += 1
    for closure in closures:
        seal0=json.loads(decoded[closure['seal_alias']]); schema=closure['schema']; base0=closure['base_alias']
        def under(path): return posixpath.normpath(base0+'/'+path)
        if schema == 'root_files':
            for name, expected in seal0['files'].items(): closure_pin(under(name),expected)
        elif schema in ['members','members_note','files']:
            for expected in seal0['files' if schema=='files' else 'members']: closure_pin(under(expected['path']),expected)
            if schema=='members_note': closure_pin(under(seal0['note']['path']),seal0['note'])
        elif schema == 'chirp_root':
            for expected in [seal0['primary']]+seal0['source_snapshots']:
                for key in ['source','snapshot']:
                    names=[a for a,r in oldrows.items() if r['original_path']==expected[key]]
                    need(len(names)==1,'Exact root source/snapshot alias');closure_pin(names[0],expected)
        else: raise ValueError('Unknown closure schema')
    need(closure_count == evidence['source_closure_rows'] == 145, 'Immediate closure row extent differs')
    mapping=json.loads(source(support+'CANONICAL_CORE_MAP.json'));accepted=source('payload/docs/MULTITIME_KINETIC_ENERGY_BOUNDED_THEOREM_NOTE.md');cores=[];oldassembled=b''
    need(sha(accepted)==mapping['note_sha256']=='56c5ebf8c83741b48cf2476d40d8331b3d047d45466064e623fe9525222904ae','Accepted complete note differs')
    need(len(mapping['cores'])==3 and len(mapping['wrappers'])==4,'Accepted piece count differs')
    for i,c in enumerate(mapping['cores']):
        full=decoded[c['source_alias']];lo,hi=c['source_lines'];a,z=c['canonical_lines'];core=b''.join(full.splitlines(True)[lo-1:hi])
        need(sha(full)==c['source_sha256'] and sha(core)==c['core_sha256'] and len(core)==c['bytes'] and b''.join(accepted.splitlines(True)[a-1:z])==core,'Exact accepted core slice differs')
        cores.append(core);oldassembled+=source(mapping['wrappers'][i])+core
    oldassembled+=source(mapping['wrappers'][-1]);need(oldassembled==accepted,'Accepted wrapper/core concatenation differs')
    need([sha(c) for c in cores]==['27fcecebb52a909896c70da2e6c69376c2f56ed1ea8461133ea75ab5e11f3eda','96c61dfd1dc076ba673049635eb18fc7e3a2ac1a9844643f617c2f3928e0dab8','681f6508bb49510ba82d66dbfc028756a00f57f241957fbe78e0f847dfcfa7e9'],'Core order or extent differs')
'''
    s=s[:start]+block+s[end:]
    helper='''def reverse_diff(current, patch):
    lines=current.splitlines(True);delta=patch.splitlines(True);result=[];cursor=0;index=2
    need(len(delta)>=2 and delta[0].startswith(b'--- ') and delta[1].startswith(b'+++ '),'Historical diff header')
    while index<len(delta):
        match=re.fullmatch(rb'@@ -(\\d+)(?:,(\\d+))? \\+(\\d+)(?:,(\\d+))? @@[^\\n]*\\n',delta[index]);need(match is not None,'Historical diff hunk')
        oldstart,oldcount,newstart,newcount=[int(x) if x else 1 for x in match.groups()];target=newstart-1 if newstart else 0
        need(target>=cursor,'Overlapping historical diff');result.extend(lines[cursor:target]);cursor=target;index+=1;oldseen=newseen=0
        while index<len(delta) and not delta[index].startswith(b'@@ '):
            row=delta[index];prefix,body=row[:1],row[1:];need(prefix in [b' ',b'+',b'-'],'Historical diff marker')
            if prefix in [b' ',b'+']:
                need(cursor<len(lines) and lines[cursor]==body,'Literal historical diff context');cursor+=1;newseen+=1
            if prefix in [b' ',b'-']:result.append(body);oldseen+=1
            index+=1
        need((oldseen,newseen)==(oldcount,newcount),'Historical diff hunk count')
    result.extend(lines[cursor:]);return b''.join(result)
'''
    s=replace(s,'def verify(root):',helper+'def verify(root):')
    for a,b in [('== 4 and len(bindings[\'canonical_core_maps\']) == 5','== 5 and len(bindings[\'canonical_core_maps\']) == 6'),("{'nodes':1,'edges':4}","{'nodes':1,'edges':5}"),('CHIRPED_SOURCE_ASSEMBLY','MULTITIME_SOURCE_ASSEMBLY'),("scope['status'] == 'accepted_for_source_only_publication_preparation' and scope['publication_execution_authorized_by_this_receipt'] is False","scope['mathematical_repairs_required'] == [] and scope['retained_audit'] is False and scope['new_independent_derivation'] is False"),("status['one_time_marginals_only'] is True","status['fixed_finite_protocols_only'] is True and status['negative_packet_status'] == 'FAIL / partial-narrowing' and status['publication_bound'] is True"),('the chirped BV secular construction was not simulated','no ordered-word or spectral-projection limit was simulated')]:s=replace(s,a,b)
    support_block='''    support=json.loads(read(PACKET+'/SUPPORT_PUBLICATION_EDITS.json'))
    need(support['scientific_text_edits']==0 and support['original_archives_unchanged'] is True and len(support['files'])==2,'Support publication scope differs')
    for r in support['files']:
        before=archived(r['source_path']);after=read(PACKET+'/'+r['publication'])
        need(sha(before)==r['source_sha256'] and sha(after)==r['publication_sha256'] and after==before.rstrip(b'\\n')+b'\\n','Support terminal-LF copying differs')
        need(diff_bytes(r)==diff(before,after,r['fromfile'],r['tofile']),'Complete support publication diff differs')
'''
    s=replace(s,'    for name,p in EXTRA_PINS.items():',support_block+'    for name,p in EXTRA_PINS.items():')
    put('IDENTITY_TOOL.template.py',s)
    # Separate reconstruction program: same declared schema, no proposed-program import.
    c=(T/'CHECK_PREPARATION_SOURCES.py').read_text()
    c=replace(c,'import argparse, ast, difflib, gzip, hashlib, json, pprint, re','import argparse, ast, difflib, gzip, hashlib, json, posixpath, pprint, re')
    c=replace(c,'def main():',helper+"SOURCE_FREEZE_SHA = '53f2bfac081b7af2181a162c9b9ec839b982b7a89828b2a18107d65b274bed4a'\ndef main():")
    start=c.index("    contract=evidence['accepted_source_package']");end=c.index("    edits=js(P/'PUBLICATION_EDITS.json')",start)
    c=c[:start]+"    def archived(name):return origins[name]\n"+block+c[end:]
    c=replace(c,"checkdiff(r,origins[r['source_path']],joined[r['byte_offset']:r['byte_offset']+r['bytes']]","checkdiff(r,b''.join(origins[r['source_path']].splitlines(True)[r['source_line_start']-1:r['source_line_end']]),joined[r['byte_offset']:r['byte_offset']+r['bytes']]")
    for a,b in [("len(parents['parents'])==4 and len(parents['canonical_core_maps'])==5","len(parents['parents'])==5 and len(parents['canonical_core_maps'])==6"),("{'nodes':1,'edges':4}","{'nodes':1,'edges':5}"),('CHIRPED_BRANCH_PLAN.json','MULTITIME_BRANCH_PLAN.json'),("'accepted_source_files':162,'original_source_selection':106","'accepted_source_files':176,'original_source_selection':181"),("'canonical_parents':4,'canonical_core_maps':5","'canonical_parents':5,'canonical_core_maps':6")]:c=replace(c,a,b)
    c=replace(c,"parents=js(P/'PARENT_BINDINGS.json');", "parents=js(P/'PARENT_BINDINGS.json');need(parents['publication_bound'] is True and isinstance(spec['base'],str) and re.fullmatch(r'[0-9a-f]{40}',spec['base']), 'Actual canonical publication parent is not bound');")
    c=replace(c,"    for r in js(Q/'PROGRAM_DIFFS.json')['diffs']:","    status=js(P/'SOURCE_REVIEW_STATUS.json');acc=raw(P/'MULTITIME_SOURCE_ASSEMBLY_ROOT_ACCEPTANCE.json');review=raw(P/'MULTITIME_SOURCE_ASSEMBLY_ROOT_REVIEW.md')\n    need(sha(acc)=='2df2022fb72bbccd1611749d5ab3980f6c9dcbeccb956e80c081437f486c7ea7' and sha(review)=='6f62765f8bbd09f87e62cb76688d0532846b4788039898f26303411616eef450' and status['source_review_coverage_verbatim']==json.loads(acc),'Exact source review scope')\n    need(status['negative_packet_status']=='FAIL / partial-narrowing' and status['fixed_finite_protocols_only'] is True and status['initial_state_dependency'] is False and status['no_go_packet_pass'] is False and status['mathematical_core_edits']==0,'Theorem and negative packet scope')\n    for r in js(Q/'PROGRAM_DIFFS.json')['diffs']:")
    c=replace(c,"    status=js(P/'SOURCE_REVIEW_STATUS.json');acc=","    need(joined.count(b'\\nClaim type: bounded_theorem\\n')==1,'Standalone graph claim-type line differs')\n    status=js(P/'SOURCE_REVIEW_STATUS.json');acc=")
    support_check='''    support=js(P/'SUPPORT_PUBLICATION_EDITS.json')
    need(support['scientific_text_edits']==0 and support['original_archives_unchanged'] is True and len(support['files'])==2,'Support publication scope')
    for r in support['files']:
        before=origins[r['source_path']];after=raw(P/r['publication'])
        need(sha(before)==r['source_sha256'] and sha(after)==r['publication_sha256'] and after==before.rstrip(b'\\n')+b'\\n','Exact support terminal-LF copy')
        checkdiff(r,before,after,'readable_diffs/'+Path(r['diff']).name.removesuffix('.gz'))
'''
    c=replace(c,"    for r in js(Q/'PROGRAM_DIFFS.json')['diffs']:",support_check+"    for r in js(Q/'PROGRAM_DIFFS.json')['diffs']:")
    put('CHECK_PREPARATION_SOURCES.py',c)
    record={'template':'chirped publication preparation at exact selected freeze','changes':[{'old':a,'new':b} for a,b in pairs],'source_schema':'Complete176-file multi-time archive;181 aliases;7 immediate closures/145 rows;4 strict historical diffs;3 exact unchanged core slices;5 canonical parents/6 direct parent cores.','publication_bound':base is not None,'executed_runtime_programs':False,'scientific_predicates':0}
    (Q/'PROGRAM_ADAPTATION.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'programs_generated':4,'publication_bound':base is not None,'scientific_predicates':0}))
if __name__=='__main__':main()
