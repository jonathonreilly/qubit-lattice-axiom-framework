#!/usr/bin/env python3
"""Finalize local bookkeeping and write the source seal last; no runtime program runs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

Q = Path(__file__).resolve().parent
CW = Q.parent.parent / 'correlation_worktree'

def raw(path):
    return Path(path).read_bytes()

def read_json(path):
    return json.loads(raw(path))

def pin(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
            'lines': len(data.splitlines())}

def write_json(name, value):
    path = Q / name
    if path.parent != Q:
        raise ValueError('Bookkeeping output outside assigned package root')
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

def main():
    if Q.name != 'multitime_kinetic_energy_publication_preparation':
        raise ValueError('Unexpected assigned package')
    if (Q / 'SOURCE_FREEZE.json').exists():
        raise ValueError('Package already frozen')
    spec = read_json(Q / 'SPECIFICATIONS.json')
    assert isinstance(spec['base'], str) and len(spec['base']) == 40 and isinstance(spec['stack_parent_regular_pr'], int)
    packet = Q / 'payload' / spec['packet']
    checks = []
    for label, archive_only in [('source_check_final', False), ('archive_check_final', True)]:
        folder = Q / 'evidence' / label
        receipt = read_json(folder / 'RECEIPT.json')
        output = read_json(folder / 'stdout')
        assert receipt['exit_code'] == 0 and receipt['scientific_predicates'] == 0
        assert receipt['program_sha256'] == pin(raw(Q / 'CHECK_PREPARATION_SOURCES.py'))['sha256']
        assert output['archive_only'] is archive_only and output['mathematical_predicates'] == 0
        for kind in ['stdout', 'stderr']:
            assert pin(raw(folder / kind))['sha256'] == receipt[kind + '_sha256']
        checks.append({'path': str(folder.relative_to(Q)), 'receipt': pin(raw(folder / 'RECEIPT.json')),
                       'elapsed_seconds': receipt['elapsed_seconds'], 'result': output})
    aliases = []
    evidence = read_json(packet / 'EVIDENCE_MAP.json')
    for obj in evidence['objects']:
        for origin in obj['origins']:
            actual = pin(raw(origin['path']))
            assert actual == {key: obj[key] for key in ['sha256', 'bytes', 'lines']}
            aliases.append({'path': origin['path'], **actual})
    procedures = []
    for item in read_json(Q / 'PROCEDURE_REUSE.json')['files']:
        path = Path(item['path'])
        path = path if path.is_absolute() else CW / path
        actual = pin(raw(path))
        assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
        procedures.append({'path': str(path), **actual})
    parents = []
    for item in read_json(packet / 'PARENT_BINDINGS.json')['parents']:
        actual = pin(raw(CW / item['path']))
        assert actual['sha256'] == item['published_sha256']
        parents.append({'path': item['path'], 'base_commit': item['base_commit'], **actual})
    utc = datetime.now(timezone.utc).isoformat()
    write_json('SOURCE_REFRESH.json', {'utc': utc, 'scientific_predicates': 0,
        'archive_aliases': aliases, 'procedures': procedures, 'canonical_parents': parents,
        'parent_tree_evidence': ['evidence/parent_'+str(i)+'_'+spec['base'][:8]+'/RECEIPT.json' for i in range(5)],
        'scope': 'Exact live identities only; no new scientific or recursive audit verdict.'})
    payload = read_json(Q / 'PAYLOAD_MANIFEST.json')
    stages = read_json(Q / 'EXPECTED_INSTALL_AND_STAGE_PATHS.json')
    write_json('SOURCE_PREPARATION_DISPOSITION.json', {'utc': utc,
        'status': 'source_only_complete_pending_root_review_and_runtime',
        'scientific_predicates': 0, 'runtime_executed': False,
        'editable_prompt_files_changed': [], 'source_checks': checks,
        'payload_files': payload['file_count'], 'planned_stage_paths': stages['total'],
        'archive_objects': len(evidence['objects']), 'archive_aliases': len(aliases),
        'root_execution_acceptance': 'Required separately; false/null templates are not approval.'})
    checkpoint = {'utc': utc, 'state': 'source_only_complete_seal_written_last',
        'base': spec['base'], 'branch_plan': spec['branch'], 'runtime_executed': False,
        'scientific_predicates': 0, 'concrete_source_blockers': [],
        'failed_routes_and_tools': 'evidence/FAILURE_HISTORY.json',
        'recovery': 'SOURCE_FREEZE.json plus SOURCE_PREPARATION_DISPOSITION.json',
        'remaining': ['root full source/program review and external acceptance',
            'root prepare, exact stage and verify', 'regular PR creation and attachment',
            'separate current-main combined landing checks and independent retained audit']}
    (Q / 'CHECKPOINT.json').write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + '\n')
    paths = sorted(path for path in Q.rglob('*') if path.is_file())
    assert not any(path.is_symlink() for path in Q.rglob('*'))
    rows = [{'path': str(path.relative_to(Q)), **pin(raw(path))} for path in paths]
    write_json('SOURCE_FREEZE.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Complete source preparation, exact immediate archive, actual source-only logs.',
        'file_count': len(rows), 'scientific_predicates': 0, 'runtime_executed': False,
        'files': rows, 'self_excluded': 'SOURCE_FREEZE.json'})
    print(json.dumps({'source_freeze': pin(raw(Q / 'SOURCE_FREEZE.json')),
        'member_files': len(rows), 'total_files': len(rows) + 1,
        'payload_files': payload['file_count'], 'planned_stage_paths': stages['total'],
        'scientific_predicates': 0}, sort_keys=True))

if __name__ == '__main__':
    main()
