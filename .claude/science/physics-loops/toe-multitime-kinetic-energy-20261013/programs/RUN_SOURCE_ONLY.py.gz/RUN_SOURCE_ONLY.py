#!/usr/bin/env python3
"""Run only enumerated source-generation/bookkeeping programs with complete logs."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, subprocess, sys, time
Q=Path(__file__).resolve().parent
ALLOWED={'ADAPT_PROGRAMS.py','BUILD_SOURCE_ONLY.py','FINALIZE_SOURCE_ONLY.py','CHECK_PREPARATION_SOURCES.py'}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('program',choices=sorted(ALLOWED));ap.add_argument('label');ap.add_argument('arguments',nargs='*');a=ap.parse_args()
    if not a.label.replace('_','').isalnum(): raise ValueError('Label must be alphanumeric with underscores')
    outdir=Q/'evidence'/a.label;outdir.mkdir(parents=True,exist_ok=False)
    program=(Q/a.program).read_bytes();(outdir/'program.py').write_bytes(program)
    cmd=[sys.executable,str(Q/a.program),*a.arguments];start=datetime.now(timezone.utc).isoformat();tick=time.monotonic()
    p=subprocess.run(cmd,cwd=Q,stdin=subprocess.DEVNULL,capture_output=True,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'})
    (outdir/'stdout').write_bytes(p.stdout);(outdir/'stderr').write_bytes(p.stderr)
    receipt={'program_sha256':hashlib.sha256(program).hexdigest(),'argv':cmd,'cwd':str(Q),'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':p.returncode,'timeout_seconds':60,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'scientific_predicates':0,'proposed_runner_or_driver_executed':False}
    (outdir/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps(receipt,sort_keys=True))
    if p.returncode: sys.stderr.buffer.write(p.stderr)
    else: sys.stdout.buffer.write(p.stdout)
    raise SystemExit(p.returncode)
if __name__=='__main__': main()
