#!/usr/bin/env python3
"""Root-only shared current-main validation; not executed during preparation.

Requires a separately reviewed exact integrated candidate and explicit generated
path allowance. It never stages, restores, commits, pushes or applies audits.
Generated outputs and every failure remain for root-owned recovery. No result
from this driver supplies a scientific or retained-audit verdict.
"""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import argparse,hashlib,json,os,signal,subprocess,sys,time,uuid
Q=Path(__file__).resolve().parent
DEADLINE=datetime(2026,10,13,16,42,30,tzinfo=timezone.utc)
def need(value,message):
 if not value:raise RuntimeError(message)
def raw(p):return Path(p).read_bytes()
def js(p):return json.loads(raw(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(value if isinstance(value,bytes) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
def run(folder,label,argv,cwd,timeout=60):
 remain=(DEADLINE-datetime.now(timezone.utc)).total_seconds();need(remain>0,'Campaign deadline reached')
 d=folder/label;d.mkdir();start=time.monotonic();out=err=b'';code=None;expired=False
 try:
  p=subprocess.Popen(argv,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_OPTIONAL_LOCKS':'0'})
  try:out,err=p.communicate(timeout=min(timeout,remain))
  except subprocess.TimeoutExpired:expired=True;os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
  code=p.returncode
 finally:
  save(d/'stdout',out);save(d/'stderr',err);save(d/'execution.json',{'argv':argv,'cwd':str(cwd),'exit_code':code,'timed_out':expired,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(out),'stderr_sha256':sha(err)})
 need(code==0 and not expired,'Command failed; preserve all generated state and logs: '+label)
 return out
def frozen_package(expected):
 need(sha(raw(Q/'SOURCE_FREEZE.json'))==expected,'Package receipt changed')
 f=js(Q/'SOURCE_FREEZE.json');wanted={r['path'] for r in f['files']}
 need(not any(p.is_symlink() for p in Q.rglob('*')),'Package symlink')
 need({str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file() and p != Q/'SOURCE_FREEZE.json'}==wanted,'Package membership differs')
 for row in f['files']:
  b=raw(Q/row['path']);need(sha(b)==row['sha256'] and len(b)==row['bytes'],'Frozen package member differs')
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--acceptance',type=Path,required=True);ap.add_argument('--acceptance-sha256',required=True);ap.add_argument('--program-sha256',required=True);ap.add_argument('--package-source-freeze-sha256',required=True);args=ap.parse_args()
 need(datetime.now(timezone.utc)<DEADLINE,'Campaign deadline reached')
 need(sha(raw(__file__))==args.program_sha256,'Program differs');frozen_package(args.package_source_freeze_sha256)
 acceptance=args.acceptance.resolve();need(acceptance.is_relative_to(Q.parent) and not acceptance.is_relative_to(Q) and not args.acceptance.is_symlink(),'Separate regular root acceptance required')
 need(sha(raw(acceptance))==args.acceptance_sha256,'Root combined acceptance changed');a=js(acceptance)
 need(a['purpose']=='combined_current_main_validation_only' and a['program_sha256']==args.program_sha256 and a['package_source_freeze_sha256']==args.package_source_freeze_sha256,'Acceptance does not bind exact program/package')
 need(all(a.get(k) is True for k in ['root_authorizes_execution','cumulative_unit_reviewed','source_footprint_reviewed','generation_scope_reviewed','recovery_owned_by_root']),'Root combined review incomplete')
 cwd=Path(a['candidate_worktree']);need(cwd.is_absolute() and cwd==cwd.resolve() and cwd.is_dir(),'Exact regular candidate required')
 allowed=a['allowed_generated_paths'];need(len(allowed)==len(set(allowed)),'Duplicate generated allowance')
 forbidden=('scripts/','docs/audit/scripts/','docs/ai_methodology/','.claude/','logs/runner-cache/')
 for n in allowed:
  p=PurePosixPath(n);need(not p.is_absolute() and '..' not in p.parts and not n.startswith(forbidden),'Unsafe generated allowance')
  need(n.startswith(('docs/audit/','docs/publication/ci3_z3/')) or n=='docs/repo/FRONT_DOOR_STATUS.md','Generated allowance outside reviewed authority outputs')
 folder=Q.parent/'multitime_kinetic_energy_combined_validation_execution'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:12]);folder.mkdir(parents=True)
 save(folder/'acceptance.json',raw(acceptance));save(folder/'program.py',raw(__file__))
 git=lambda label,*argv:run(folder,label,['git',*argv],cwd)
 try:
  need(git('initial_head','rev-parse','HEAD').decode().strip()==a['candidate_head'],'Candidate HEAD drift')
  need(git('initial_tree','rev-parse','HEAD^{tree}').decode().strip()==a['candidate_tree'],'Candidate tree drift')
  need(git('current_main','rev-parse','refs/remotes/origin/main').decode().strip()==a['current_main'],'Current-main ref drift')
  git('main_ancestry','merge-base','--is-ancestor',a['current_main'],'HEAD')
  need(not git('initial_status','status','--porcelain=v1','-z','--untracked-files=all'),'Combined candidate must enter clean')
  index=git('initial_index','ls-files','--stage','-z')
  payload=js(Q/'PAYLOAD_MANIFEST.json')['files']
  for r in payload:
   b=raw(cwd/r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Integrated publication payload differs')
  for r in a['procedure_pins']:
   b=raw(cwd/r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Integrated procedure differs')
  required={'docs/audit/scripts/run_pipeline.sh','docs/audit/scripts/audit_lint.py','docs/audit/scripts/check_changed_audit_evidence.py'}
  need(required<={r['path'] for r in a['procedure_pins']},'Three command procedures require exact pins')
  for n in allowed:
   p=cwd/n
   if p.exists():need(p.is_file() and not p.is_symlink(),'Generated recovery path not regular');save(folder/'generated_before'/n,raw(p))
  run(folder,'pipeline',['bash','docs/audit/scripts/run_pipeline.sh'],cwd,1200)
  run(folder,'strict_lint',[sys.executable,'docs/audit/scripts/audit_lint.py','--strict'],cwd,300)
  out=run(folder,'changed_evidence',[sys.executable,'docs/audit/scripts/check_changed_audit_evidence.py','--base',a['current_main'],'--include-worktree','--json'],cwd,300)
  report=json.loads(out);need(not report['failures'] and not report['control_failures'],'Combined evidence incompatibility')
  need(git('final_head','rev-parse','HEAD').decode().strip()==a['candidate_head'],'Candidate HEAD changed')
  need(git('final_index','ls-files','--stage','-z')==index,'Pipeline changed index; root must inspect')
  need(git('final_main','rev-parse','refs/remotes/origin/main').decode().strip()==a['current_main'],'Current-main ref changed during validation')
  for r in payload+a['procedure_pins']:
   b=raw(cwd/r['path']);need(sha(b)==r['sha256'] and len(b)==r['bytes'],'Late source/procedure drift')
  records=[s.decode() for s in git('final_status','status','--porcelain=v1','-z','--untracked-files=all').split(b'\0') if s]
  need(all(x[:2] in {' M','??'} and x[3:] in allowed for x in records),'Unclassified generated/source drift; no automatic recovery')
  for x in records:
   name=x[3:];p=cwd/name;need(p.is_file() and not p.is_symlink(),'Generated output nonregular');save(folder/'generated_after'/name,raw(p))
  save(folder/'RESULT.json',{'status':'shared_pipeline_commands_completed_recovery_pending','candidate_head':a['candidate_head'],'current_main':a['current_main'],'changed_generated_paths':[x[3:] for x in records],'actually_checked_claims':[r['claim_id'] for r in report['checked']],'retained_audit_verdict':False,'scientific_proof_validated':False,'root_generated_output_recovery_required':True,'commit_or_staging_authorized_by_result':False,'scope':'Actual command outcomes only; an empty checked list verifies no scientific claim. Root must restore generated authority output to this candidate own committed state, regenerate/review the intended manifest, and verify exact source/stage footprint.'})
  print(json.dumps({'evidence':str(folder),'status':'shared_pipeline_commands_completed_recovery_pending'}))
 except BaseException as e:
  save(folder/'FAILURE.json',{'error':repr(e),'automatic_retry':False,'automatic_cleanup':False,'generated_files_preserved':True});raise
 finally:
  save(folder/'EVIDENCE_MANIFEST.json',{'self_excluded':True,'files':[{'path':str(p.relative_to(folder)),'sha256':sha(raw(p)),'bytes':len(raw(p))} for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='EVIDENCE_MANIFEST.json']})
if __name__=='__main__':main()
