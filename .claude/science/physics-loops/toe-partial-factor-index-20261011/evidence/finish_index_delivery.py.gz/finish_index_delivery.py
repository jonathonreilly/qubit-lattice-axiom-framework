"""Final source/evidence checks and explicit staging for the index milestone."""
from pathlib import Path
import ast,gzip,hashlib,json,re,subprocess,sys
from urllib.parse import unquote
S=Path(__file__).resolve().parent
W=S.parent/'index_worktree'
P=W/'.claude/science/physics-loops/toe-partial-factor-index-20261011'
BASE='a13caa4885f547c8d206265b031ba7649e539fd9'
sha=lambda b:hashlib.sha256(b).hexdigest()
sys.path.insert(0,str(W/'scripts'));import runner_cache
m=json.loads((P/'PUBLICATION_EDITS.json').read_text())
primary=W/m['outputs'][1]['publication_path'];body=primary.read_text()
mutants=json.loads((S/'index_primary_mutations/manifest.json').read_text())
assert sha(primary.read_bytes())==mutants['primary_sha256'] and len(mutants['runs'])==13
baseline=(S/'partial_factor_index/baseline.log').read_text().splitlines()
for row in mutants['runs']:
    d=S/'index_primary_mutations';path=d/(row['name']+'.py')
    assert body.count(row['before'])==1 and path.read_text()==body.replace(row['before'],row['after'])
    assert sha(path.read_bytes())==row['source_sha256']
    out=(d/(row['name']+'.stdout')).read_bytes();err=(d/(row['name']+'.stderr')).read_bytes()
    assert sha(out)==row['stdout_sha256'] and sha(err)==row['stderr_sha256']
    lines=out.decode().splitlines();assert lines==baseline[:len(lines)]
    assert row['exit_code']==1 and not row['timed_out'] and row['intended_failure']
    assert err.decode().splitlines()[-1]==row['expected_assertion']
    assert row['elapsed_seconds']<row['timeout_seconds']==120

graph=W/'docs/audit/data/citation_graph_manifest.json'
old=json.loads(subprocess.check_output(['git','show',BASE+':docs/audit/data/citation_graph_manifest.json'],cwd=W))
new=json.loads(graph.read_text())
assert (new['node_count'],new['edge_count'])==(old['node_count']+1,old['edge_count'])
assert all(new['nodes'][k]==v for k,v in old['nodes'].items())
assert set(new['nodes'])-set(old['nodes'])=={'approximate_partial_factor_index_bounded_theorem_note_2026-10-11'}
compat=json.loads((S/'index_focused_audit_compat.json').read_text())
assert compat['checked']==compat['failures']==compat['control_failures']==[]
(S/'index_citation_build_received.json').write_text(json.dumps({
 'command':['python3','docs/audit/scripts/run_citation_graph_build.py','--help'],
 'cwd':str(W),'exit_code':0,
 'tool_received_output':'Wrote docs/audit/data/citation_graph.json\n  nodes: 6870  edges: 15418\n  roots: 3173  leaves: 2784\n  runners attached: 4565\n  claim_type_seed_hint_counts: {\'meta\': 386, \'bounded_theorem\': 3748, \'open_gate\': 247, \'no_go\': 351, \'positive_theorem\': 686, \'none\': 1449, \'decoration\': 3}\n',
 'argument_behavior':'The helper does not implement a help CLI; this invocation performed its normal serialized build. No duplicate build was run.'
},indent=2)+'\n')

(P/'ROOT_COMPOSITION_REVIEW.md').write_text('''# Complete-source review and publication mapping

Root read the entire original P1–P29 argument and all changed P11 import
text, checked the required RWW primary statements/constants and NSY pages
17–20 and 26–28, and read the full independent report, pre-control
reconstruction, geometric proof, exact helper and complete output. The
author's complete 298-line control source, 33-record baseline and every
mutant traceback were inspected. Earlier output not repeated verbatim in
the current baseline was read separately, including the initial setup
failure and the 24-control baseline's different completion record.

The load-bearing distinctions are full-block operator norm, quadratic Bell
loss, dimension-aware entropy continuity, dimension-independent QCA constants,
the safe fine-site radius for index stabilization, and microscopic locality
before supersite coarsening. No global ALPU entropy limit, dense-group
rounding, global gluing or automatic norm amplification is substituted.
The review checked all those steps. Root proposed the entropy approach and
requested the LR-prefactor clarification; this is disclosed contribution,
not a claim that root is the independent reviewer.

The exact source is bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441.
Separate report9118707fdcc85cdfd0a1160598872fb8544a9de757b3a1efe8e93292719c533c
and receipt03b9c5236179f02220f16f4770f7386eb4673aa78d8881be9b8076c6afe267bf
found no material correction under the specified conditional hypotheses.
All 521 original author/review artifact bindings were checked. Their actual
coverage, including imported proofs not independently rebuilt, remains
explicit. Full N1/B1/M1 physics is not certified by this review.

The publication map preserves every equation and argument. Changes add
metadata, current recovery/runner pointers and the actual review status.
The primary's mathematical body is unchanged; timeout/input declarations,
an optimization guard and explicit resolution statements are added. Complete
note and primary reconstruct exactly from frozen original bytes. New scope,
status, source and recovery prose was read completely. No editable prompt,
physical axiom, main branch or existing candidate-law source was changed.

All authored evidence and failed runs are preserved losslessly. Complete
third-party papers, extracted pages and web retrievals remain at their
external research paths with exact hashes and official URLs recorded in
EVIDENCE_MAP.json. Their full bytes are not redistributed in this PR. The
independent reconstruction and matched statement/page references are included
and readable without treating an unavailable local path as a theorem premise.
''')

(P/'DELIVERY_CHECKS.md').write_text('''# Index milestone delivery

The canonical primary exited 0 in 0.556218863 seconds under its declared
120-second timeout, with empty stderr and 33 finite control records. Its
complete scientific stdout is byte-identical to the fully read author
baseline, followed by the publication's explicit resolution statements.
Source and declared note input are fresh. Runtime: Python 3.13.5, NumPy
2.4.4 and SymPy 1.14.0. No finite count certifies the infinite-chain theorem.

Thirteen complete publication-primary semantic variants each fail at the
intended assertion. Every full changed source is exactly one declared edit;
all output hashes match and every pre-failure stdout is an identical prefix
of the baseline. Root read all final traceback text. These runs discriminate
the Bell normalization/loss, intertwiner, block phase, amplification, index
factor, boundary capacity, covering count, normalized projection, trace
distance, entropy dimension, microscopic volume and radius calculations.
The original author variants and earlier baseline are also preserved.

The separate reviewer's geometric helper exited 0 in 0.216226333 seconds
under 30 seconds. Its 1,920 exact parameter cases and three adverse formulas
support its independently written all-size geometric derivation; they do
not prove the imported LR theorem or all automorphism claims.

The citation build contains 6,870 nodes, 15,418 edges and 4,565 runners.
The manifest adds one theorem node and no edges; all older nodes are unchanged.
Focused changed-audit-evidence compatibility selected no applied rows and
reported no failures. The global combined audit pipeline and strict audit
lint were not run and remain independent landing gates. No audit verdict or
retained status is applied. The build helper executed normally when passed
--help; the actual command and returned build output are recorded, without
claiming an unsupported help response or running a duplicate build.

Final vocabulary correction/report, exact note/primary reconstruction,
syntax, ordinary links, every preserved/external source identity and source
cache freshness are checked. SOURCE_IDENTITIES.json binds every publication
file except itself. Explicit staged/worktree hashes and whitespace are
checked before commit. The branch is based directly on main a13caa4885f547c8d206265b031ba7649e539fd9.
The exact full-algebra shift and preceding physical/representation premises
remain separate; no unmerged candidate-law science is adopted by this PR.
''')
p=P/'STATE.yaml';p.write_text(p.read_text().replace('pr_status: preparation','pr_status: ready_for_regular_PR').replace('next_action: complete_source_bound_publication_checks_then_regular_PR','next_action: open_regular_PR_after_final_staged_checks'))
p=P/'PR_BACKLOG.md';p.write_text(p.read_text().replace('Publication\nstill requires its canonical finite execution, actual complete-source mutation\nchecks and source-bound conformance.','Publication\nnow includes the successful canonical finite execution, actual complete-source\nmutation checks and source-bound conformance recorded in DELIVERY_CHECKS.md.'))

editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in m['outputs']]
for mode in ['fix','report-only']:
    target=S/('index_final_vocab_'+mode)
    r=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(target.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],cwd=W,capture_output=True)
    target.with_suffix('.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
reconstruction=subprocess.run([sys.executable,str(P/'reconstruct.py')],cwd=W,capture_output=True)
(S/'index_final_reconstruction.log').write_bytes(reconstruction.stdout+reconstruction.stderr);assert reconstruction.returncode==0
ast.parse(primary.read_text())
assert runner_cache.cache_status(str(primary.relative_to(W)))==runner_cache.cache_identity_status(str(primary.relative_to(W)))=='fresh'
links=[]
for path in editable:
    if path.suffix!='.md':continue
    prose=[];fenced=False
    for line in path.read_text().splitlines():
        if line.lstrip().startswith('```'):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(r'`[^`]*`','',line))
    for target in re.findall(r'\]\(([^)\s]+)\)','\n'.join(prose)):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (path.parent/unquote(target.split('#',1)[0])).resolve().exists(),(path,target)
        links.append({'source':str(path.relative_to(W)),'target':target})

emap=json.loads((P/'EVIDENCE_MAP.json').read_text());rows={r['preserved']:r for r in emap['files']}
def preserve(src):
    b=src.read_bytes();dst=P/'evidence'/(str(src.relative_to(S))+'.gz')
    dst.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(b,mtime=0)
    if dst.exists():assert dst.read_bytes()==packed,dst
    else:dst.write_bytes(packed)
    rel=str(dst.relative_to(P));rows[rel]={'original':str(src),'preserved':rel,'sha256':sha(b),'bytes':len(b)}
for src in sorted((S/'index_primary_mutations').iterdir()):preserve(src)
for name in ['prepare_index_publication.py','run_index_primary_mutants.py','index_primary_mutations_driver.log',
 'finish_index_delivery.py','index_canonical_execution.json','index_focused_audit_compat.json','index_citation_build_received.json',
 'index_initial_vocab_fix.json','index_final_vocab_fix.json','index_final_vocab_fix.log',
 'index_final_vocab_report-only.json','index_final_vocab_report-only.log','index_final_reconstruction.log']:
    preserve(S/name)
for row in rows.values():
    b=gzip.decompress((P/row['preserved']).read_bytes());assert sha(b)==row['sha256'] and len(b)==row['bytes']
for row in emap['external_reference_sources']:
    b=Path(row['original']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
mech={'note_and_primary_reconstructed':True,'primary_mutants':13,'all_preserved_bindings':len(rows),
      'external_reference_identities':len(emap['external_reference_sources']),'citation_delta':{'nodes':1,'edges':0},
      'old_graph_nodes_unchanged':True,'cache_and_inputs_fresh':True,'ordinary_links':links,
      'scope':'Mechanical source-bound delivery, not a mathematical or audit verdict.'}
out=S/'index_delivery_mechanical.json';out.write_text(json.dumps(mech,indent=2)+'\n');preserve(out)
emap['files']=[rows[k] for k in sorted(rows)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
files=[W/r['publication_path'] for r in m['outputs']]+[graph,runner_cache.cache_path_for(str(primary.relative_to(W)))]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for path in sorted(set(files)):
    row={'path':str(path.relative_to(W)),'sha256':sha(path.read_bytes())}
    if path.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(path.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps({'base_revision':BASE,'scope':'Every publication file except this manifest itself.','files':ident},indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,cwd=W,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
for row in ident:assert sha(subprocess.check_output(['git','show',':'+row['path']],cwd=W))==row['sha256']
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=W).decode().split('\0')
assert set(staged)-{''}==set(paths)
final={'staged_files':len(paths),'index_worktree_hashes_match':True,'whitespace_clean':True,**mech}
(S/'index_final_staged_verification.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps(final))
