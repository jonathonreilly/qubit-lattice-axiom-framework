# Frozen author checkpoint

Note SHA-256: `bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441`.
Primary SHA-256: `f48ad394b16fb96d31f4841defeafa2598a4131f04c8726ce0909e4c799fee9e`.

Proved authored statement: under the explicit full-interior block norm and ALPU tail threshold, `|ind gamma| <= 2j log d_B + 8j delta log(d_I d_B) + 3g(delta)`, with `delta=(epsilon+4 C_Q f(j))/sqrt(2)`, `C_Q=435*25*97^4*385^3`, and `C_Q f(j)<=1/3456`. The finite Choi projection has quadratic Bell loss, without a diamond-norm amplification factor. Dimension-independent QCA constants and adjacent-scale stabilization are displayed.

For the fixed-constant exponential tube family, explicit logarithmic j and R make the normalized index bound O(log^2 L/L). P11 derives suitable prefactors from finite-range microscopic LR bounds once the exact global shift identity is supplied. C_t=2 exp(2 C_F |t| N_F)>=2 explicitly covers small-radius and overlapping-support cases. N1's exact integrated/gapped/continuous-momentum AC/rational-centre reduction remains supplied; no global-band shortcut or physical dynamics adoption is made.

Source versions and coverage are in SOURCE_IDENTITIES.json, SOURCE_RECHECK.json and READING_COVERAGE.json. N1 report and both referees are byte-identical between b568c14d and 7df738ee. No new Y1/RZ assessment. Initial CONTRACT.md is preserved; its radius-2j shorthand is superseded by radius two in coarse cells and safe radius 3j in the original metric.

Controls: 33 finite records, baseline exit 0; thirteen actual source mutants each exit 1 at an intended assertion. Full sources/logs and 120-second timeout records are retained. Exact arithmetic and floating examples are distinguished. They do not verify imported hyperfinite stability or infinite-chain classification. No redundant replay was performed after prose/source additions.

Failures and routes: the initial invalid-cwd setup failure ran no process; retained. The weaker sqrt(eta) Bell route was valid but unnecessary. A qualitative C_f route had untracked transverse-volume dependence; explicit Proposition 5.5 constants replaced it. Global gluing and direct infinite-half-chain entropy were not proved or needed. These are not claims of impossibility. The pre-NSY note variant preserves the original carriage return and implicit LR lower-bound issue; both are corrected in the final note.

Next obligation: independent reading of the full authored proof, especially explicit RWW constants/stabilization, full-factor norm scope and uniform microscopic LR derivation. This packet has no independent retained status, Lean claim, audit application, PR modification, or certification of a future delivery pack. All earlier sources and completed probes remain unchanged.
