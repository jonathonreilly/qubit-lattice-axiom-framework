# Fixed mathematical target

Pinned source: candidate-law N1 at b568c14df54a5e64f904f54f0251b2173f9302c3; N1 unchanged at later 7df738ee434d7732adff53fb42cee7564f3e341f per parent. RWW arXiv:2012.00741v2, PDF SHA-256 03fc3e67ccd36c1f6ac7e5336bdf6977010cc12d615f90e095ded550268eda17. No claim about new Y1/RZ work.

Target, not a proof certificate: a one-dimensional chain has the same finite supersite algebra M_(d_I) tensor M_(d_B) at each integer. Interior and boundary refer to these tensor factors, not to longitudinal endpoints. The natural logarithm convention gives index log d for a one-step shift of one d-dimensional factor. Fix a cut between 0 and 1 and X_j=[-2j+1,2j], with half-window length 2j.

Hypothesis on gamma: an automorphism with non-increasing tails f(r) tending to zero in the RWW near-inclusion sense, for every finite or infinite longitudinal interval, uniformly in its position and length. On the full interior matrix algebra in X_j require sup_(||a||<=1) ||gamma(a)-a|| <= epsilon_j. This is a uniform operator norm on the entire block algebra, not a state expectation, average over observables, or separate one-site estimate.

Candidate conclusion: after a quantified tail threshold at j, bound |index gamma| by 2j log d_B plus an explicit error proportional to j log(d_I d_B) and a binary-entropy term. The ALPU-to-QCA approximation must use constants universal in supersite dimension and tail amplitude; a qualitative C_f with untracked L-dependence is insufficient.

Chosen proof route: first use a radius-2j QCA approximation and index stabilization. For its finite Choi state use normalized Weyl averaging to test Bell-pair fidelity on the whole interior block; then project to those pairs and estimate finite entropies. Check amplification directly rather than replace the operator norm by a diamond norm. Near-commutant correction remains an alternate route; no global gluing is presumed.

Tube specialization to test: V=L^(d-1) qubits per slice, I=(L-2R)^(d-1), B=V-I; f_L(r)<=A L^(d-1) exp(-mu r), epsilon_L(n)<=E n L^(d-1) exp(-nu R), with A,E,mu,nu independent of L,R,n. Choose both longitudinal j and transverse R explicitly, expected O(log L). The supplied small errors must hold for the entire n=4j interior algebra. Prove this conditional resource implication separately from any Hamiltonian LR derivation and N1's global integrated/gapped/AC/rational-centre reduction.

No framework-wide obstruction is targeted. Positive mathematical support is conditional on these definitions and imported RWW theorems. A counterexample must obey the exact chosen hypotheses to refute the target. Finite controls do not prove the infinite-chain theorem.
