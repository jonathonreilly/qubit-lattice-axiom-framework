#!/usr/bin/env python3
"""Source and execution checks; no scientific replay or repository mutation.

Run from this file's directory or any cwd. Writes only this packet's new
coverage, checkpoint and receipt. Expected timeout: 30 seconds. Freezes the
delivered note and packet files read-only after all assertions succeed.
"""
from pathlib import Path
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
import numpy
import sympy
import pypdf

root = Path(__file__).resolve().parent
note = root.parent / 'APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md'

def identity(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def write_json(name, value):
    (root/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

sources = json.loads((root/'SOURCE_IDENTITIES.json').read_text())
for item in sources['records']:
    assert identity(root/item['copy'])['sha256'] == item['sha256']
    if 'source_path' in item:
        assert identity(Path(item['source_path']))['sha256'] == item['sha256']

execution = json.loads((root/'EXECUTION_AND_MUTATIONS.json').read_text())
for item in execution['records']:
    assert identity(root/item['runner'])['sha256'] == item['runner_sha256']
    assert identity(root/item['log'])['sha256'] == item['log_sha256']
    assert item['matched_expected_outcome']
    assert item['timeout_seconds'] == 120
    raw = (root/item['log']).read_text()
    if item['expected_failure']:
        assert item['exit_code'] == 1 and 'AssertionError' in raw
        assert 'SyntaxError' not in raw and 'ModuleNotFoundError' not in raw
    else:
        assert item['exit_code'] == 0
        assert json.loads(raw.splitlines()[-1])['completed_finite_control_records'] == 33
assert len(execution['records']) == 14

old = json.loads((root/'baseline_execution_1.json').read_text())
old_runner = root/'versions/partial_factor_controls_attempt1.py'
assert identity(old_runner)['sha256'] == old['runner_sha256']
assert b'\r' not in note.read_bytes()
assert note.read_text().count('\\tag{P') == 29

coverage = {
 'kind': 'Authored mathematics and source-hypothesis check; not an independent review',
 'N1_B1_M1': {
   'basis': 'Complete report arguments, all copied short referees, and N1 full referee were read during the frozen C4 assessment; exact unchanged readings reused',
   'assessment_sha256': '340046ef7f5a979f18a4b3047c338dc7a1ec2cd9f7d249d87fe52997a0a5ae75',
   'candidate_revision': sources['candidate_revision'],
   'latest_N1_identity_check': 'SOURCE_RECHECK.json; three unchanged paths at 7df738ee434d7732adff53fb42cee7564f3e341f',
   'excluded': 'No reading or conclusions about new Y1/RZ work'},
 'RWW': {
   'pdf_sha256': '03fc3e67ccd36c1f6ac7e5336bdf6977010cc12d615f90e095ded550268eda17',
   'complete_pdf_pages_read': list(range(11,50))+[51,68],
   'load_bearing': ['Theorem 2.6(i)', 'Lemmas 2.4 and 2.7', 'Section 3.1 and Lemma 3.8 tracial extension', 'Definition 3.5 and Lemma 3.10 tails', 'Theorem 3.2 LR statement', 'Propositions 4.7 and 4.10; Remark 4.11', 'Lemmas 5.1(i) and 5.3(i)', 'Propositions 5.4(i) and 5.5', 'Theorem 5.6 and Definition 5.7 index identification', 'Theorem 5.15'],
   'limits': 'Appendix B near-inclusion theorem proof not independently reconstructed; multi-prime index rounding claim unused; no full-paper reading claimed'},
 'NSY': {
   'pdf_sha256': '42fc3029fa582f14a01f858463f481d5cacf21ed785791d32c72dd9df97f66cd',
   'complete_pdf_pages_read': list(range(17,22))+list(range(25,29)),
   'load_bearing': ['Interactions and F-functions, equations (3.1)-(3.19)', 'Theorem 3.1, equations (3.21)-(3.24), and explicit volume-uniformity remark', 'Theorem 3.4 and Duhamel comparison (3.70)-(3.76)', 'Theorem 3.5 and Corollary 3.6'],
   'limits': 'Theorem 3.1 is imported; its proof on pages 22-24 was not independently reconstructed. Only listed pages read; all 106 pages extracted for source recovery, not represented as read.'},
 'authored_packet': {
   'note': identity(note),
   'full_argument_read': 'All P1-P15, including final NSY addition and carriage-return fix',
   'runner': identity(root/'partial_factor_controls.py'),
   'runner_read': 'Complete source, baseline, and all thirteen complete assertion-failure logs',
   'initial_contract_correction': 'CONTRACT.md preserved as initial target. Its radius-2j shorthand is superseded by the proof: radius two in j-blocked units; safe radius 3j in fine-site comparisons.',
   'prior_variant': 'versions/probe_before_lr_primary_9fa85ff6d266.md preserves the draft before the two clarity fixes and NSY primary-source check'},
 'process': {
   'current_workflow_sha256_reused': '05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce',
   'AGENTS_sha256_reused': 'f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f',
   'physics_loop': 'SKILL and DISCOVERY/CLAIM_STATUS/DELIVERY read; exact installed/main identities in PROCESS_SOURCE_IDENTITIES.json',
   'no_go_discipline': 'Read and applied only to the displayed conditional tube consequence; N1-N8 in P15. No formal no-go packet PASS or audit applied.',
   'editable_prompt_files_changed': [],
   'repository_changes': [],
   'external_messaging': 'None; parent-agent coordination only'}}
write_json('READING_COVERAGE.json', coverage)

checkpoint = f'''# Frozen author checkpoint

Note SHA-256: `{identity(note)['sha256']}`.
Primary SHA-256: `{identity(root/'partial_factor_controls.py')['sha256']}`.

Proved authored statement: under the explicit full-interior block norm and ALPU tail threshold, `|ind gamma| <= 2j log d_B + 8j delta log(d_I d_B) + 3g(delta)`, with `delta=(epsilon+4 C_Q f(j))/sqrt(2)`, `C_Q=435*25*97^4*385^3`, and `C_Q f(j)<=1/3456`. The finite Choi projection has quadratic Bell loss, without a diamond-norm amplification factor. Dimension-independent QCA constants and adjacent-scale stabilization are displayed.

For the fixed-constant exponential tube family, explicit logarithmic j and R make the normalized index bound O(log^2 L/L). P11 derives suitable prefactors from finite-range microscopic LR bounds once the exact global shift identity is supplied. C_t=2 exp(2 C_F |t| N_F)>=2 explicitly covers small-radius and overlapping-support cases. N1's exact integrated/gapped/continuous-momentum AC/rational-centre reduction remains supplied; no global-band shortcut or physical dynamics adoption is made.

Source versions and coverage are in SOURCE_IDENTITIES.json, SOURCE_RECHECK.json and READING_COVERAGE.json. N1 report and both referees are byte-identical between b568c14d and 7df738ee. No new Y1/RZ assessment. Initial CONTRACT.md is preserved; its radius-2j shorthand is superseded by radius two in coarse cells and safe radius 3j in the original metric.

Controls: 33 finite records, baseline exit 0; thirteen actual source mutants each exit 1 at an intended assertion. Full sources/logs and 120-second timeout records are retained. Exact arithmetic and floating examples are distinguished. They do not verify imported hyperfinite stability or infinite-chain classification. No redundant replay was performed after prose/source additions.

Failures and routes: the initial invalid-cwd setup failure ran no process; retained. The weaker sqrt(eta) Bell route was valid but unnecessary. A qualitative C_f route had untracked transverse-volume dependence; explicit Proposition 5.5 constants replaced it. Global gluing and direct infinite-half-chain entropy were not proved or needed. These are not claims of impossibility. The pre-NSY note variant preserves the original carriage return and implicit LR lower-bound issue; both are corrected in the final note.

Next obligation: independent reading of the full authored proof, especially explicit RWW constants/stabilization, full-factor norm scope and uniform microscopic LR derivation. This packet has no independent retained status, Lean claim, audit application, PR modification, or certification of a future delivery pack. All earlier sources and completed probes remain unchanged.
'''
(root/'CHECKPOINT.md').write_text(checkpoint)

artifacts = []
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name != 'receipt.json':
        artifacts.append({'path': str(path.relative_to(root)), **identity(path)})
receipt = {
 'created_utc': datetime.now(timezone.utc).isoformat(),
 'claim_status': 'Authored bounded mathematical theorem with explicit imported hypotheses; independent review pending',
 'note': {'path': str(note), **identity(note), 'lines': len(note.read_text().splitlines())},
 'primary': {'path': str(root/'partial_factor_controls.py'), **identity(root/'partial_factor_controls.py')},
 'runtime': {'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'numpy':numpy.__version__,'sympy':sympy.__version__,'pypdf':pypdf.__version__},
 'execution': {'records':'EXECUTION_AND_MUTATIONS.json','baseline_records':33,'actual_source_mutants':13,'all_expected_outcomes':True,'command_convention':'[recorded Python executable, runner path]; cwd this packet; no user inputs; capture stdout and stderr to full log; timeout 120 seconds per execution','replay_status':'No replay claimed as independence'},
 'source_and_old_execution_rechecks': 'All ten source records and all fourteen execution source/log hashes checked; previous baseline runner retained and hash-matched',
 'scope_limits': ['No repository or prior frozen source modifications', 'No physical law, native Record interpretation, broad no-go or audit outcome', 'Imported RWW near-inclusion and index theorems are not finite-control consequences', 'N1 reduction premises remain supplied; no Y1/RZ work assessed', 'Illustrative resource examples do not set physical numerical limits', 'No independent proof review claimed'],
 'artifacts':artifacts,
 'self_hash': 'Excluded to avoid circularity; returned in completion message',
 'freeze': 'After successful receipt creation, note and all packet regular files set read-only; directories left traversable'}
write_json('receipt.json',receipt)
for path in root.rglob('*'):
    if path.is_file(): path.chmod(0o444)
note.chmod(0o444)
print(json.dumps({'note':receipt['note'],'receipt':identity(root/'receipt.json'),'primary':receipt['primary'],'artifact_count':len(artifacts),'all_rechecks_passed':True},indent=2))
