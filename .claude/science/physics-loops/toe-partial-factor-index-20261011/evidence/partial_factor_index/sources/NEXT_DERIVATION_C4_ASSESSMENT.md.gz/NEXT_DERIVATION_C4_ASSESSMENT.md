# C4 source sync and next-derivation assessment

Assessment date: 2026-10-11. Scope: read-only opportunity assessment, not a theorem note, audit verdict, retained-status decision, observational exclusion, or implementation task.

## 1. Source boundary and result

The assessed candidate-law revision is `b568c14df54a5e64f904f54f0251b2173f9302c3`, compared with `d009fb786d36a6cab4a7d410630b9382992faa08`. The source prefix is `.claude/science/exercises/gravity-current-state-20261009/`. Exact Git-object copies, blob identities, SHA-256 hashes, byte counts, and line counts are in `SOURCE_IDENTITIES.json`; the complete changed-path inventory and diff are preserved alongside this report. There are 19 changed head files, including the three synthesis/preregistration files. The copies were extracted without changing the repository and made read-only.

The most useful new work would be either (i) a quantitative finite-distance version of RL4's fixed-epsilon asymptotic renewal estimate, or (ii) N1's approximate partial-factor index lemma with all tube-size dependencies explicit. The first directly tests an inference currently used in the phenomenological synthesis; the second attacks a genuinely unresolved structural step. Neither is established by this assessment. X1 does not supply a model-matched collider limit for the event operator. RY is a proposed source-covariance test, not a completed calculation.

The new material does not alter the frozen interspecies exact or conditioned-stability arguments. Their local collision-shell premises differ from N1's exact integrated Poincare hypotheses. The checked boost/current notes concern approximate brackets on specified states and domains, not N1's global representation. Boost/rotation is active and unassessed: the parent confirmed that no frozen source yet exists for it.

No scientific runner was executed here. Source code and stored outputs were read; deterministic extraction, identity comparison, and bookkeeping were performed. Referee labels are reported only as source labels, never substituted for proof. No physical primitive, new mathematical theorem, numerical observational limit, repository edit, prompt edit, or audit application is made here.

## 2. Exact reading coverage

The following changed arguments were read completely, including every line of their listed source code and stored output:

| Head source | Lines | SHA-256 |
|---|---:|---|
| `agents/C4_N1_report.md` | 301 | `c284a41bfee8a1238643330ddd46f3a7c4f6f1a865509a9aaec5ab6f4238ad13` |
| `agents/C4_N1_referee.md` | 34 | `d3784f9d92335ed0d76f9a43db16b77f0ad240e0ea7aface76bcfa062732729e` |
| `agents/C4_N1_referee_full.md` | 160 | `b6748580efd4e9c180db3e56d1f65d2175efa2835e764902e960a10816bb571e` |
| `agents/C4_RL4_report.md` | 244 | `1840ae817e673af96790829db73634182f85be8cea6719c825eb017a8d95de6a` |
| `agents/C4_RL4_referee.md` | 25 | `669f04b50d39768998e4212c5221e0e904e6e2305816ec70ce6d1921f6ed288c` |
| `agents/C4_X1_report.md` | 134 | `7be167fbe77a50b731e15a168de2da93bee507c812c7105f9e158c9f0f0a04d3` |

The complete script/output reading comprises `N1/n1_tower_geometry.py/.out` and, under `RL4/`, `rl2_core.py`, `rl4_A_lemmaU_constants.py/.out`, `rl4_B_endfactor_turnon.py/.out`, `RL4_referee_checks.py/.out`, and `rl4_C_bound_vs_RL3B.out`. Each exact identity is in the manifest. No corresponding `rl4_C_bound_vs_RL3B.py` is tracked at this revision.

The changed synthesis arguments were read in full with adjacent context: `SUMMARY.md` lines 350–489; `PRICE_NOTE.md` lines 240–413; and `TESTS.md` lines 1–14 and 1930–2080. These spans contain all their changed arguments, including the RN2/RL4 readings and RX/RY proposals. The entire unchanged historical content of these three large files was not re-read. Their exact head identities are respectively `35d9e53d7d8681650876346319825ddabc0173c20d0c3cd50604ee8ec68160ba`, `481e2c158942f38ceefb44a9acc71981788e4f4f503875759c923d4803ab04eb`, and `c58510b12d50b3e59aceb18b52c5134f0bde83bf5d1cc5b9282af48ce5733764`.

Necessary unchanged premises read completely in this task were C4 I1, M1, B1, RL2, RL3, and RL3b reports and their short referee files. The separate longer I1/M1/B1/RL2 referee files were captured and identified but not read completely; they are not additional independent evidence here. The changed N1 full referee was read completely. Truncated tool output was recovered by targeted reads before the corresponding argument was treated as complete.

Four current external sources were read completely and copied:

| Source | Lines | SHA-256 |
|---|---:|---|
| `EXCLUDED_WALK_BOOST_CURRENT_PROBE.md` | 744 | `903261f54d72d6e81d0c82d5cd976bd4dd46a55c1dd4567fe23d8bce07fe1923` |
| `EXCLUDED_WALK_EVOLVED_BOOST_CONTROL_DRAFT.md` | 185 | `d89611986626dbabcf6f9f5c487733d2a520cb9249b7ed0b3a27be35874fd929` |
| `EXCLUDED_WALK_EVOLVED_BOOST_REVIEW.md` | 271 | `9cd540482c4cef79471530223dbbde93d36a6ba0aded1c99becf36a68ae263b9` |
| `ROOT_EXCLUDED_WALK_BOOST_CURRENT_REVIEW.md` | 188 | `c019d73e57462fd5e71ff3dc0552cc49fdcf02f604184e6c779ffc7e5dacd300` |

`UNCHANGED_C1_C2_C3.json` records byte equality between the two candidate-law revisions for all eight tracked RC C1/C2/C3 report/referee files. This mechanical fact is not a new verification of their arguments. Prior complete C1 reading and the author's exact/stability/Lean work are reused at the guarded identities in Section 6. This report does not claim a fresh independent re-review of that work or complete independent C2 premise review.

The workflow and local-instruction identities were checked against the previously read coherent-task sources: `SCIENCE_WORKFLOW.md` SHA-256 `05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce` and repository `AGENTS.md` `f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f`. The bounded assessment does not invoke an audit or publication workflow.

## 3. N1: useful reductions with a global-hypothesis wall

### 3.1 What the source actually assumes

N1 starts with finite-dimensional sites and a bounded finite-range translation-covariant energy density. It also assumes much more than a local low-energy bracket: closing rotations, exact commutators on suitable common domains that integrate to a positive-energy Poincare representation, and first-moment covariance. Its gap assumption is a unique vacuum plus a positive spectral gap. Its additional asymptotic-completeness hypothesis is used only in the scattering-to-algebraic-shift reduction.

Under these premises the mass Casimir is invariant, and a gapped non-vacuum representation cannot contain a massless component. If an isolated positive mass subspace exists, the folded tower has energies

\[
E_n(Q)=\sqrt{M_1^2+\beta|Q-\theta+2\pi n|^2},\qquad n\in\mathbb Z^d.
\]

This is a fibrewise description; centres can form direct-integral families and internal multiplicities remain possible. This conditional representation statement does not establish the existence of an isolated mass, finite-site implementation, or a preferred particle interpretation. An infinite tower in a global spectral representation is not by itself an infinite on-site algebra. The finite grid script illustrates this tower's geometry; it does not construct the assumed interacting theory.

### 3.2 The smooth-band obstruction is narrower than some summary language

N1 Theorem 5 uses a joint lattice-translation/energy eigenband with a globally regular eigenprojection, `u=E²/2` in `W^{2,1}` on the full Brillouin torus, and valid strong or weak-form commutator/domain manipulations. Its periodicity contradiction is the requirement `Hess u=beta I` integrated over that torus. Those global regularity and domain hypotheses must remain attached to the result.

N1 lines 21, 35, and 136 treat a lattice Haag–Ruelle isolated shell as supplying this global situation. The cited primary definition instead permits a shell over an open momentum set, with local isolation; it does not require one globally regular band over the whole torus. Thus that citation does not retire the global-band premise. This matters for folded branches, whose local regular patches can avoid their seams. The source's Corollary 6 and its claim that every eigenprojection must be discontinuous also omit qualifications explicitly used in Theorem 5; this assessment retains the theorem's full hypotheses rather than endorsing the stronger shorthand. [Bachmann–Dybalski–Naaijkens, Definition 4.1 and Section 4](https://arxiv.org/pdf/1412.2970v2).

Likewise, N1 line 152's assertion that the only boost-invariant sectors are mass spectral subspaces is too restrictive as stated: invariant internal multiplicity or charge subspaces can occur within a fixed mass representation. The useful bounded-sector obstruction does not require this exhaustive classification. A sector with bounded energy/momentum and exact invariant boost dynamics remains a separate conditional target; absence of particle-number conservation alone does not prove that no such sector can exist.

### 3.3 The index reduction remains a worthwhile open step

With the additional exact asymptotic-completeness/intertwining premises and rational tower centres with a common denominator, N1 obtains a lattice shift as a finite-time flow generated by the local momentum sum. For a tube `Z × B_L`, its putative one-dimensional supersite dimension is `2^{L^{d-1}}`, and a shift by `q` carries logarithmic index `q L^{d-1} log 2`. The flow truncated to that tube is connected to the identity. The remaining comparison must control an automorphism approximately equal to the identity on the tube interior, while allowing action on its lateral boundary.

The source's approximate Lemma B is still open. A fidelity estimate for a Choi state does not by itself bound the mutual-information index with every growing local dimension, longitudinal window, and tail error controlled. The desired comparison is of an `L^{d-1}` shift index against a boundary contribution of order `R L^{d-2}`, with `R` typically logarithmic in `L`, plus errors small on the same scale. One-dimensional index robustness for norm-close automorphisms on whole finite blocks does not immediately imply this partial-factor statement. The relevant primary results impose uniform locality/tail hypotheses and distinguish operator-norm robustness from entropy formulas. [Ranard–Walter–Witteveen, Theorem 5.8, Section 5.4 and Corollary 6.1](https://arxiv.org/pdf/2012.00741v2).

There is also a repairable normalization error before the tube argument: N1 line 178 takes both `G=P_1/beta` and flow time `s=q/beta`, whereas its preceding shift identity is `exp(-i q P_1/beta)`. Use `G=P_1`, `s=q/beta`, or `G=P_1/beta`, `s=q`. This does not close the missing index lemma.

The energy-density/Lieb–Robinson comparison yields a compatible speed inequality, not a contradiction; N1 correctly notes this in its detailed argument. No modular/Bisognano–Wichmann localization property is supplied. Irrational centres, absence of exact asymptotic completeness, massless sectors, or absence of isolated mass remain outside the stated reduction. Local nonlinear reparametrizations of momentum are also not ruled out by a global linear Poincare hypothesis alone; the cited deformed-kinematics comparator works patchwise. [Bisio–D'Ariano–Perinotti, Section V and Appendix B](https://arxiv.org/html/1503.01017v3).

## 4. RL4: a new all-order comparison, but not a finite-distance exclusion

### 4.1 What is new relative to RL2/RL3/RL3b

This is a supplied Poisson causal-event model with a scalar retarded layer inverse. It is not the native qubit excluded walk, a derivation of GKSL noise, or an inherited physical law. In the dimensionless convention `ell_k=1`, the source writes the layer kernel as `f(m)=exp(-m) sum_j C_j m^j/j!`, with four-dimensional interval volume `m=pi tau^4/24`, and the mean renewal equation `h=f+f*h`. Physical length restoration and the joint epsilon scaling must be stated separately.

The nonnegative chaos expansion `Var=sum_k epsilon^k a_k` belongs to the particular simultaneous change of intensity and binomial layer weight used by the source. It is not a generic statement that thinning always produces such epsilon-independent coefficients. In each add-one difference, node and interval-count insertions are combined before squaring. A node-only ladder is consequently not automatically a lower bound on the full variance.

RL4's useful new step is the renewal-in-index comparison replacing RL3's restriction on collision order relative to the rapidity gap. With normalized terms of the form

\[
\widetilde G_n=\widetilde G_{n-1}+\sum_{a\le n-2}\rho_{a,n}\widetilde G_a,
\qquad |\rho_{a,n}|\leq\delta^{n-a-1}\quad(n-a\ge2),
\]

the source obtains an all-order lower ratio from a small `delta`; its induction closes using `delta/(1-3 delta) <= 2 delta` for `delta <= 1/10`. This removes the earlier order-uniformity obstruction within the restricted chain geometry. It neither proves the full node-only exponent nor gives a global upper bound for the stochastic inverse.

The source restricts the proper-time window and imposes separated rapidities, uses local chain-volume bounds for the mean inverse, and then employs alternating angular caps. These restrictions are part of the lower-bound construction. The stored numerical values near `delta=0.044–0.047` and the resulting positive rate constants are floating computations, not interval-certified decimals. The separate referee calculation is useful consistency evidence but does not change that numerical status. The script's label “EXACT” for a massless normalization includes floating quadrature; an exact integral normalization and its certified numerical evaluation are different claims.

### 4.2 The unresolved step needed for the synthesis's observational reading

The alternating-cap transform provides an asymptotic singularity mechanism. Passing from that transform to a fixed-endpoint density lower bound uses a local central-limit/renewal argument for tilted paired steps. The tilt must be at the actual root, not merely an explicit lower estimate for its location. The report names bounded-density, nondegeneracy, and moment conditions, but this assessment has not matched and checked a complete primary local-limit theorem with quantitative constants. It therefore treats that part as the source's asymptotic route, not an independently certified theorem here.

Even granting the fixed-epsilon large-distance rate, it does not give the prefactor, onset distance, or error radius uniformly in tiny epsilon. Restricting to an endfactor patch with a nonzero regular turn-on can preserve an asymptotic exponent while imposing a very small prefactor. A limit as distance tends to infinity for each fixed epsilon cannot be substituted directly at a specified astronomical distance with epsilon of order `10^-64`. Several synthesis passages turn this rate information into failure of a finite observational bar; that inference needs an additional quantitative estimate.

RL4 addresses the RL3b cancellation concern by a different restricted positive construction. It does not prove the previously estimated full rate around `2.7–3.3`. Its very conservative analytic majorants and unverified finite-distance prefactors cannot be replaced by that fitted number in a rigorous consequence. The source's choice of an enormously loose majorant has ample slack; that slack is not a substitute for the missing onset estimate.

Two further scope restrictions matter. The curved-space mean has an exact local Van Vleck cancellation in the source calculation, but the passage to the complete renewal/needle limit is separately argued; the synthesis's abbreviated “GR mean proved” should not erase that distinction. Also, an absolute-value obstruction requiring a source bounded below throughout the infinite past does not automatically apply to a Gaussian source, which decays there. This assessment does not promote such an obstruction to all smooth or Gaussian sources.

### 4.3 Reproducibility boundary

The head's `RL4/rl2_core.py` imports a generated `../RL1/RL1_F4b_stable_L6.npy` file absent from the tracked tree at the pinned revision. The A-constant helper also expects generated `../RL3/rl3_H_op*.npz` files absent there. The failed attempt to extract the former is recorded in `extraction_failure.txt`. The C comparison has a tracked output without its correspondingly named source script. These facts limit checkout-level replay; they do not by themselves falsify the formulas or imply that the author's local inputs never existed. This assessment read all available changed scripts and outputs and did not claim a successful replay.

## 5. X1 and RY: model matching and the observable must come first

X1 is a worker report without a corresponding independent referee in the changed set. It acknowledges using memory, snippets, and a summarizer pass. Its numerical collider comparison needs more than a shared nonlocality length.

The primary Biswas–Okada paper studies specified exponential modifications of gauge theories, including a Drell–Yan calculation and limits around a few TeV. Anderson–Carone uses a specified nonlocal/asymptotically nonlocal SU(3) Lagrangian, momentum-dependent vertices as well as propagators, and a particular leading-order dijet fit; its quoted limits differ between the nonlocal limit and a finite-order example. These are model-dependent analyses, not bounds on every retarded scalar kernel with the same named length. I checked their model definitions and the passages supporting the reported limits, not all amplitudes, datasets, or likelihoods. [Biswas–Okada](https://arxiv.org/html/1407.3331v2), [Anderson–Carone](https://arxiv.org/html/2406.12073v1).

The event-route operator is a retarded scalar layer inverse. A matching theorem would have to specify the relevant matter/gauge completion, propagator prescription, interaction vertices, and observable before transporting a collider limit. The causal-set Green-function literature exhibits branch-cut/continuum structure for particular scalar operators; this does not supply that gauge completion or identify the stable six-layer operator with an entire exponential model. Nor does an extra continuum automatically make every collider constraint stronger: interference and the full amplitude matter. No such matching is established in the changed sources. [Belenchia–Benincasa–Liberati, Sections 4–5 and discussion](https://arxiv.org/pdf/1411.6513v2).

Accordingly, the quoted exclusion of a shared matter length around `4–7 × 10^-19 m` is not adopted here. Sharing a parameter, a naturalness argument for universality, or agreement of a first infrared coefficient is insufficient. The gravity-only and optomechanical numerical claims were not checked against their primary experimental analyses and are not used as conclusions in this assessment. X1's noise table also uses a candidate full growth constant, not the conservative restricted rate plus a proved finite-distance estimate.

RY is newly preregistered source modelling, not a result at this revision. A useful calculation must identify whether the observable is a field amplitude, intensity, or an interference correlation. Independent emitters need not have independent propagated intensities after averaging over one shared random substrate. Conversely, zero-mean independent source amplitudes can make a cross-field second moment vanish even when fourth-order intensity correlations remain. One must condition on the medium, specify source statistics, then average the appropriate joint quantity; source/medium correlations may require Palm corrections. A finite emission window or coherence length cannot be inserted as a cutoff solely by intuition. This issue is a sharper version of the existing RY question, not evidence that one answer is already correct.

## 6. Compatibility with the current research lanes

The following prior identities were rechecked, without edits:

| Frozen work | SHA-256 |
|---|---|
| Exact interspecies note | `ca44d1c852e6cd0437cf9e98913fb5fb106abb1b42567c68fb6bf3e9a60c80b8` |
| Independent exact review | `78c3bc3c8f223b988713cb5bd5210c1a801e8cdc5f428ee648d6284c400d97d6` |
| Conditioned stability note | `61f240d5e35f9c94d759f63e1d94c2a0677e53f52752c53700faeb50a546039a` |
| Scoped `RigidityGeometry.lean` | `c72e7a9a961d1eec1ff60842ac3e8a5530c8b71dfc1505dc098d7cab780044df` |

Receipt identities and additional guards are in `PRIOR_SOURCE_GUARDS.json`. The exact and stability notes and finite Lean geometry were authored by this agent; reuse is not independent recertification. Stability's separate review is outside this assessment and its not-yet-frozen contents are not certified here.

The exact interspecies theorem obtains common coefficients from cross-species regular-shell/tangent identities and explicit velocity-image geometry. Its exceptional skew-line argument and equal-velocity labels do not require same-species scattering or a globally regular lattice mass shell. The stability result assumes a quantitative tangent/secant defect and conditioned noncoplanar anchors; it explicitly does not derive derivative control from a small undifferentiated collision defect. N1's common Poincare coefficient comes from an assumed exact global algebra. It is a different statement and does not supply the collision, full-support, smoothness, or anchor-conditioning hypotheses of either interspecies theorem.

The current prepared boost note uses the actual canonical current and the bracket remainder `R_ab=-i[D_a,J_b]-delta_ab H`. Its differential term includes `[H,J_b] partial_{K_a}`, so a derivative/domain assumption is load-bearing. On its normalized globally projected positive-band origin-cone packets, with the stated scaled derivative bound, it gives

\[
\|R\chi\|\le384\lambda^{3/2},\qquad
\|[H,J]\chi\|\le6\lambda^{5/2},\qquad
\langle H\rangle\in[\lambda/2,3\lambda].
\]

The note keeps the mixed-band counterexample: small total energy and total momentum alone do not imply this bracket control. It does not claim a selfadjoint exponentiating boost group or exact closure on the entire Hilbert space.

The evolved note proves, with its stated domains and units,

\[
\|R\psi(t)\|\le\lambda^{3/2}(384+1129t+18\lambda t^2),\quad
\|[H,J]\psi(t)\|\le\lambda^{5/2}(6+18t),
\]
\[
|\langle J\rangle_t-\langle J\rangle_0|
\le\lambda^{5/2}(6t+9t^2).
\]

These bounds give `o(lambda)` bracket error on `t <= lambda^-gamma` for `gamma < 1/2`. They do not yet reach the inverse-energy scale `t ~ 1/lambda`; in the proved window `lambda t` tends to zero. Conserved mean energy also does not imply preservation of a narrow spectral band. B1's exact bounded-sector boost obstruction therefore neither contradicts nor completes these state-dependent estimates. No claim about the active boost/rotation calculation is made.

## 7. Ranked bounded questions

The ranking is a research judgment based on novelty, falsifiability, and the current claim gaps. It does not launch any of these tasks.

1. **Quantify RL4 at finite epsilon and finite separation.** Start with one fixed, smooth compact source and the exact restricted chain model. Establish a bound with an explicit prefactor, onset distance, and remainder as functions of epsilon, window, and source patch, or show constructively why the asymptotic rate cannot imply the proposed finite-distance threshold. The analytic window estimates and numerical coefficient inputs should be certified separately. A root-location lower bound alone is not an endpoint local-limit estimate. This is new relative to RL4's order-uniform rate argument and directly tests the most consequential unsupported synthesis step; it is not a request to derive an astronomical exclusion.

2. **Prove or refute N1's approximate partial-factor index lemma.** Fix a one-dimensional supersite tensor split into tube interior and boundary factors, precise ALPU tails, a norm notion on an explicit longitudinal window, and the dependence of every error on `L`, `R`, and the supersite dimension. Seek a boundary-size upper bound on the logarithmic index, with the interior approximation error controlled, or a counterexample to the proposed formulation. This is the highest-leverage structural question. Even a successful lemma closes only the stated gapped, exactly integrated, asymptotically complete, rational-centre route, not a universal obstruction to qubit models.

3. **Compute the RY source/detector covariance for a minimal specified observable.** Begin with a finite collection of emitters and compact smooth envelopes in the same Poisson medium. Derive conditional and unconditional field or intensity covariances from that joint law before taking an extended-source limit. A useful discriminator is whether the proposed independent-intensity scaling survives common-medium fourth-order correlations. This refines an already preregistered question; it must not be sold as an entirely new lane or settled by emitter independence alone.

4. **Test X1's operator-to-observable matching.** Specify one gauge-consistent matter model if such a supplied extension is authorized, then compare its amplitude or spectral response with the exact scalar layer inverse over a controlled range. Alternatively, establish a precise failure of the claimed matching assumptions without adopting a new matter model. The deliverable would be a model-matching statement or counterexample, not a transported TeV bound. It should precede any numerical application of the cited collider papers.

5. **After boost/rotation freezes, identify the next controlled time/domain scale.** Read that result first. A possible remaining target is a state-dependent canonical-bracket estimate at a nonvanishing inverse-energy time, or a separately defined finite-rapidity action with checked generator domains. The present `gamma < 1/2` evolution estimate does not settle either. This is adjacent to active work, not an invitation to duplicate it, assume a boost exponentiation, or impose N1's exact global hypotheses on a local approximation.

For the interspecies lane, the application obligation remains to obtain the exact or approximate tangent/secant hypothesis from a specified physical collision model with explicit regularity and shell scales. Approximate charge conservation alone is not that derivation. This is already an identified wall of the frozen stability note; C4 has not removed it, and repeating the existing geometric proof would not be new progress.

## 8. Primary-source and execution limits

The primary lookup was selective, because no literature theorem is imported as a new proved result here. `literature/DOWNLOAD_IDENTITIES.json` pins the actual downloaded bytes; `web_lookup_1.json` through `web_lookup_6.json` preserve the returned lookup evidence. Unversioned BDN and BBL PDF URLs resolved to the v2 texts checked in the lookup metadata; the hashes, rather than the mutable URL alone, identify the reading.

| Primary source | Actual inspection | Limit |
|---|---|---|
| BDN `1412.2970v2` | Definitions 4.1–4.2, Section 4 assumptions/discussion, Section 7.2 completeness discussion | No full-paper proof audit; verifies that the definition does not require a full-torus band |
| RWW `2012.00741v2` | Theorem 5.6, Definition 5.7, Theorem 5.8, relevant locality/periodic-limit discussion, Corollary 6.1 | Does not prove the higher-dimensional partial-factor extension |
| Biswas–Okada `1407.3331v2` | Model/interaction and quoted Drell–Yan limit passages | No independent cross-section or statistical fit reproduction |
| Anderson–Carone `2406.12073v1` | Lagrangian/vertex definitions and quoted fit/limit passages | No independent parton-amplitude, detector, or likelihood reproduction |
| Bisio–D'Ariano–Perinotti `1503.01017v3` | Section V and Appendix B patch/domain discussion | Does not certify a global symmetry or a physical realization |
| Belenchia–Benincasa–Liberati `1411.6513v2` | Scalar retarded Green-function/branch-cut sections and discussion | Not a gauge completion or a stability result for the supplied six-layer operator |

No complete primary quantitative local-limit theorem was checked for RL4, no astronomical dataset was reanalysed, and no experimental exclusion is asserted. No native one-qubit implementation of the causal-event model was sought or established. The failed generated-input extraction and unavailable optional local text-extraction utilities are preserved; no global package installation was used to work around them.

`READING_COVERAGE.json` distinguishes complete, partial, reused, and captured-only reading. `ASSESSMENT_RECEIPT.json` records final identity checks and the assessment artifacts. All copies and prior-source guards were checked again before the packet was frozen. There is no claim to have checked material that appeared later, future delivery evidence, or an independent audit outcome.
