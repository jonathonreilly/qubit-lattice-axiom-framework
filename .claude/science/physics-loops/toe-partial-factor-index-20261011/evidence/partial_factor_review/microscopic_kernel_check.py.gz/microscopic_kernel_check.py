"""Independent exact checks of the microscopic kernel summed in P26.

No author control is imported. Fraction arithmetic only; no Hilbert-space
construction and no finite-ring index. General validity is from the geometric
series proof in microscopic_kernel_proof.md, not the finite case count.
"""

from fractions import Fraction as Q
import json


def transverse_direct(rho, length):
    return sum((rho ** abs(x - y) for x in range(1, length + 1)
                for y in range(1, length + 1)), Q(0))


def transverse_closed(rho, length):
    return length * (1 + rho) / (1 - rho) - 2 * rho * (1 - rho ** length) / (1 - rho) ** 2


def longitudinal_by_site(rho, n, radius, shift):
    assert radius >= abs(shift)
    left, right = Q(0), Q(0)
    for i in range(1, n + 1):
        # Sum each of the two infinite geometric tails for this one site.
        left += rho ** (i - shift + radius) / (1 - rho)
        right += rho ** (n + radius + 1 - i + shift) / (1 - rho)
    return left + right


def longitudinal_closed(rho, n, radius, shift):
    return ((rho ** (radius - shift + 1) + rho ** (radius + shift + 1))
            * (1 - rho ** n) / (1 - rho) ** 2)


def main():
    count_t = count_z = count_total = 0
    max_transverse_ratio = max_longitudinal_ratio = max_kernel_ratio = Q(0)
    for rho in [Q(1, 101), Q(1, 2), Q(2, 3), Q(9, 10)]:
        for length in [1, 2, 5, 13]:
            direct_t = transverse_direct(rho, length)
            closed_t = transverse_closed(rho, length)
            assert direct_t == closed_t
            count_t += 1
            for d in [2, 3, 6]:
                volume = length ** (d - 1)
                exact_t = direct_t ** (d - 1)
                bound_t = volume * ((1 + rho) / (1 - rho)) ** (d - 1)
                assert exact_t <= bound_t
                max_transverse_ratio = max(max_transverse_ratio, exact_t / bound_t)
                for n in [1, 2, 7, 63]:
                    for radius in [0, 1, 4, 9]:
                        for shift in sorted({-radius, 0, radius}):
                            direct_z = longitudinal_by_site(rho, n, radius, shift)
                            closed_z = longitudinal_closed(rho, n, radius, shift)
                            assert direct_z == closed_z
                            count_z += 1
                            # The target uses 4; the exact sum already obeys 2*rho.
                            bound_z = 4 * rho ** (radius - abs(shift)) / (1 - rho) ** 2
                            assert direct_z <= bound_z
                            max_longitudinal_ratio = max(max_longitudinal_ratio, direct_z / bound_z)
                            assert exact_t * direct_z <= bound_t * bound_z
                            max_kernel_ratio = max(max_kernel_ratio, exact_t * direct_z / (bound_t * bound_z))
                            count_total += 1
    # The fixtures deliberately choose n>0, shift!=0, length>1. These wrong
    # formulas alter a genuine quantity and must fail an exact equality check.
    rho, n, radius, shift, length = Q(2, 3), 7, 4, 2, 5
    actual_z = longitudinal_by_site(rho, n, radius, shift)
    missing_endpoint = rho ** (radius - shift + 1) * (1 - rho ** n) / (1 - rho) ** 2
    ignored_shift = longitudinal_closed(rho, n, radius, 0)
    fictitious_transverse_multiplicity = length * transverse_closed(rho, length)
    defects = {
        "drop_one_longitudinal_endpoint": actual_z != missing_endpoint,
        "ignore_nonzero_shift_in_exact_sum": actual_z != ignored_shift,
        "insert_extra_transverse_length_in_exact_sum": transverse_direct(rho, length) != fictitious_transverse_multiplicity,
    }
    assert all(defects.values())
    result = {
        "scope": "exact finite parameter controls of independently derived infinite geometric tails; no infinite-chain index computed",
        "transverse_pair_equalities": count_t,
        "longitudinal_equalities": count_z,
        "combined_bound_cases": count_total,
        "max_transverse_exact_over_bound": str(max_transverse_ratio),
        "max_longitudinal_exact_over_target_bound": str(max_longitudinal_ratio),
        "max_total_exact_over_target_bound": str(max_kernel_ratio),
        "max_total_ratio_float": float(max_kernel_ratio),
        "relevant_wrong_formulas_rejected": defects,
        "general_proof": "microscopic_kernel_proof.md",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
