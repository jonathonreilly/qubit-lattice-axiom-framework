# Independent microscopic geometric-sum check

Let 0<ρ<1, n,L≥1 be integers, r≥|q| nonnegative integers, and d≥2. Take an input interval {1,…,n} shifted to {1−q,…,n−q}; the second longitudinal support is outside the unshifted expanded interval {1−r,…,n+r}. The exact infinite longitudinal kernel sum is

\[
K_{n,r,q}=\sum_{i=1}^{n}\left(\sum_{j\le-r}\rho^{|i-q-j|}+\sum_{j\ge n+r+1}\rho^{|i-q-j|}\right)
=\frac{(\rho^{r-q+1}+\rho^{r+q+1})(1-\rho^n)}{(1-\rho)^2}.
\]

The condition r≥|q| keeps the signs inside each absolute value fixed. Sum the two tails first and then the n-term geometric progression. Since r±q≥r−|q| and 1−ρ^n≤1,

\[
K_{n,r,q}\le\frac{2\rho^{r-|q|+1}}{(1-\rho)^2}\le\frac{4\rho^{r-|q|}}{(1-\rho)^2}.
\]

This is uniform in n. For real radii, using the integer distance of outside sites gives the same loose target bound.

On one transverse coordinate the open-box pair sum is

\[
T_L=\sum_{u,v=1}^{L}\rho^{|u-v|}=L+2\sum_{h=1}^{L-1}(L-h)\rho^h
=L\frac{1+\rho}{1-\rho}-\frac{2\rho(1-\rho^L)}{(1-\rho)^2}
\le L\frac{1+\rho}{1-\rho}.
\]

The middle equality follows by differentiating the finite geometric polynomial, or direct multiplication by (1−ρ)². The last subtracted term is positive. The ℓ¹ metric factorizes over coordinates, so the full transverse sum is T_L^(d−1)≤L^(d−1)((1+ρ)/(1−ρ))^(d−1)=V S_(d−1)(a) for ρ=e^(−a). Combining the two sums gives exactly the microscopic prefactor used in P26, with slack. There is no second factor V and no longitudinal interval-length factor. This argument holds for arbitrary finite d,L,n and then for infinite intervals by the stated local-algebra norm approximation.

The separate boundary-Duhamel sum does need the support volume nV. Reversing its nonnegative sums gives

\[
\sum_{Z\text{ crosses }W}\|h_Z\|\sum_{z\in\operatorname{supp}x}\sum_{w\in Z}e^{-a|z-w|_1}
\le J\sum_{z\in\operatorname{supp}x}\sum_{w:\,|z-w|_1\ge R-\ell_0}e^{-a|z-w|_1}
\le J nV e^{-a(R-\ell_0)/2}S_d(a/2).
\]

The first inequality uses the original per-site sum J, not a norm assigned to a whole supersite Hamiltonian. The second uses e^(−aD)≤e^(−a(R−ell0)/2)e^(−aD/2) whenever D≥R−ell0. If R<ell0, the same bound remains valid because the right-hand prefactor only increases. Multiplication by |t|Ct gives P27. Every sum is absolutely convergent for fixed finite support, uniformly in finite-volume truncation, permitting the norm thermodynamic limit.

The accompanying script checks the exact formulas by rational arithmetic on declared finite parameter cases and rejects three wrong formulas. It supports implementation accuracy; this algebraic derivation is the general proof. It does not prove NSY's LR theorem, RWW's index theory, or any physical identification.
