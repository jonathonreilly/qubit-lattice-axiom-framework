"""Compose the checked partial-factor theorem without changing its argument."""
from pathlib import Path
import gzip, hashlib, json
S=Path(__file__).resolve().parent
W=S.parent/'index_worktree'
P=W/'.claude/science/physics-loops/toe-partial-factor-index-20261011'
P.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
note_path='docs/APPROXIMATE_PARTIAL_FACTOR_INDEX_BOUNDED_THEOREM_NOTE_2026-10-11.md'
primary_path='scripts/approximate_partial_factor_index_2026_10_11.py'
source=S/'APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md'
raw=source.read_text()
assert sha(raw.encode())=='bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441'
edits=[]
def edit(before,after,reason):
    global raw
    assert raw.count(before)==1,(before,raw.count(before))
    edits.append({'before':before,'after':after,'reason':reason})
    raw=raw.replace(before,after)
edit('---\nactual_current_surface_status:', '''---
claim_id: approximate_partial_factor_index_bounded_theorem_note_2026-10-11
claim_type: bounded_theorem
claim_scope: "For spin-chain automorphisms satisfying explicit uniform tails and full-interior block-norm control, a quantified partial-factor index inequality yields a normalized O(log^2 L/L) tube bound. Microscopic finite-range Hamiltonian constants are matched; the full-algebra shift identity and physical representation premises remain supplied."
upstream_dependencies: []
runner: scripts/approximate_partial_factor_index_2026_10_11.py
actual_current_surface_status:''','Publication metadata; no new physical dependency.')
edit('Author research probe, 2026-10-11. Independent review pending.',
     'Source date: 2026-10-11. Status: conditional-support. The complete mathematical argument received a separate source review; no audit verdict or retained status is applied.',
     'Record the completed source-bound review without changing status authority.')
edit("The target is N1 Section 2.2's unproved approximate partial-factor lemma:",
     "The target is N1 Section 2.2's previously unproved approximate partial-factor lemma:",
     'Distinguish the original source obligation from the new proof.')
edit('Its exact source, B1/M1 premises and prior assessment are copied under `partial_factor_index/sources/`; identities are in `partial_factor_index/SOURCE_IDENTITIES.json`. N1 is unchanged in the later revision reported by the parent. New Y1/RZ material is outside this probe.',
     'Its exact source, B1/M1 premises and prior assessment are preserved in the [milestone packet](../.claude/science/physics-loops/toe-partial-factor-index-20261011/), with original identities in EVIDENCE_MAP.json. N1 is unchanged through candidate-law revision `407f99203a553b336f98e832213045ed49f7fc13`. New Y1/RZ material is outside this theorem.',
     'Make source recovery and latest checked identity explicit.')
edit('The primary support runner is `partial_factor_index/partial_factor_controls.py`; its complete baseline, mutation failures and execution identities are recorded in that directory\'s receipt.',
     'The publication runner is [finite partial-factor controls](../scripts/approximate_partial_factor_index_2026_10_11.py). The milestone packet preserves the original author runner, full baseline and mutation records, the separate review, and publication execution identities.',
     'Point to the self-contained publication runner and preserved source evidence.')
edit('Independent review of this authored proof and the extracted constants remains pending. No Lean verification, audit outcome, source edit to PR9476, or future publication packet is asserted. The source receipt, baseline and actual source-mutant logs are supporting evidence at their exact identities, not a replacement for those remaining checks.',
     'Independent review of the complete proof and extracted constants found no material correction at the stated mathematical scope. Its report SHA-256 is `9118707fdcc85cdfd0a1160598872fb8544a9de757b3a1efe8e93292719c533c`; the milestone packet records the full reconstruction, source coverage and independent geometric check. No Lean verification, audit outcome or source edit to PR9476 is claimed. Original receipts and finite controls remain supporting evidence at their exact identities; they do not replace the analytic proof or the independent audit path.',
     'Replace superseded author status with actual reviewed scope.')
edit('This is mathematical retirement of the named approximate-index estimate under imports already identified by N1.',
     'This proves the named approximate-index estimate under imports already identified by N1.',
     'Avoid confusing a mathematical proof with a repository status action.')
edit('Those three steps remain priority targets for independent review.',
     'Those three steps were explicit targets of the independent source reconstruction.',
     'Record actual review coverage.')
edit('This external author probe does not request a formal no-go packet PASS, apply an audit verdict, or claim independent retained authority.',
     'This milestone does not request a formal no-go packet PASS, apply an audit verdict, or claim independent retained authority.',
     'Identify the publication surface while preserving the authority boundary.')
(W/note_path).write_text(raw)
outputs=[{'kind':'note','source_path':str(source),'source_sha256':sha(source.read_bytes()),
          'preserved_source':'evidence/APPROXIMATE_PARTIAL_FACTOR_INDEX_PROBE.md.gz',
          'edits':edits,'appended_text':'','publication_path':note_path,'publication_sha256':sha(raw.encode())}]

src=S/'partial_factor_index/partial_factor_controls.py'
original=src.read_text()
assert sha(original.encode())=='f48ad394b16fb96d31f4841defeafa2598a4131f04c8726ce0909e4c799fee9e'
before='from fractions import Fraction\n'
after='''AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "docs/APPROXIMATE_PARTIAL_FACTOR_INDEX_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]
if not __debug__:
    raise RuntimeError("Run without -O: finite control assertions must be enabled")

from fractions import Fraction
'''
assert original.count(before)==1
body=original.replace(before,after)
suffix='''
print("per_element: exact Weyl, Bell, entropy-count and rational geometric identities checked in the declared fixtures")
print("per_site: finite qubit-factor matrices and single-site/full-block error discriminators checked")
print("per_mode: checked and not executed — the theorem uses full algebra map norms, not Fourier-mode sampling")
print("per_block: explicit full interior/reference density matrices checked; no claim of exhausting every block dimension")
print("lattice_wide: checked and not executed — infinite-chain index and thermodynamic results use matched primary theorems and analytic proofs")
print("TOTAL: PASS=33 FAIL=0")
print("SCOPE: finite author-control records only; no audit verdict or infinite-chain proof by enumeration")
'''
body+=suffix
(W/primary_path).write_text(body)
outputs.append({'kind':'primary','source_path':str(src),'source_sha256':sha(src.read_bytes()),
 'preserved_source':'evidence/partial_factor_index/partial_factor_controls.py.gz',
 'edits':[{'before':before,'after':after,'reason':'Declare timeout/input and reject optimized execution; no control body changed.'}],
 'appended_text':suffix,'publication_path':primary_path,'publication_sha256':sha(body.encode())})
(P/'PUBLICATION_EDITS.json').write_text(json.dumps({'outputs':outputs},indent=2)+'\n')

texts={
'STATE.yaml':'''loop: toe-partial-factor-index-20261011
mode: milestone_snapshot
active_branch: physics-loop/toe-partial-factor-index-20261011
base_revision: a13caa4885f547c8d206265b031ba7649e539fd9
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
milestone: approximate_partial_factor_index_and_uniform_tube_scaling
pr_status: preparation
next_action: complete_source_bound_publication_checks_then_regular_PR
live_checkpoint: toe-dynamics-bridge-20261009_in_transport_worktree
stop_condition: fixed_campaign_deadline_2026-10-12T16:00:52Z
''',
'GOAL.md':'''# Quantified partial-factor index

Prove the missing dimension-controlled index estimate and match uniform
microscopic locality constants. Keep the preceding physical/representation
reduction to a full-algebra shift as a separate obligation.
''',
'ASSUMPTIONS_AND_IMPORTS.md':'''# Exact mathematical premises

The abstract object is an automorphism of a spin-chain tensor algebra with
uniform interval tails and a small map norm on the full interior block algebra.
Supersite dimensions are finite and fixed for each chain. The error is not a
single-site or selected-state approximation. RWW's near-inclusion construction,
finite Choi index formula and stability theorem are matched primary imports.
NSY's microscopic Lieb–Robinson and thermodynamic-limit statements supply the
Hamiltonian application. Their PDFs and extracted texts remain in the external
research directory with exact hashes and official source URLs; reference
metadata is included without redistributing complete third-party papers.

The tube specialization supplies a finite-range uniformly bounded interaction,
fixed time and a full-algebra identity with an integer shift. It does not
derive that identity from N1's representation/scattering premises, adopt a
native Hamiltonian law, or identify automorphism evolution with Records.
''',
'OPPORTUNITY_QUEUE.md':'''# Next obligations

Assess the exact shift reduction under N1's explicit representation and
scattering hypotheses. Where it holds conditionally, identify the still
supplied physical premise. Consider weaker state/observable comparisons
without silently substituting them into this full-algebra index theorem.
''',
'APPROACH_REGISTRY.md':'''# Proof route

Extract explicit dimension-independent QCA correction constants, stabilize
the index using safe fine-site radii, and use a finite Choi window. Quadratic
Bell loss controls the full interior/reference pair; entropy continuity keeps
its dimension cost. Choose longitudinal/transverse widths logarithmically.
Sum microscopic propagation kernels before coarsening into supersites.
''',
'NO_GO_LEDGER.md':'''# Preserved scope and adverse tests

Single-site control does not imply the required full-block norm; a product
phase example makes the distinction explicit. Arbitrary linear maps need
not obey the homomorphism amplification behavior; transpose is a discriminator.
Boundary shifts saturate the exact capacity, with their range retained.
No global gluing of one-block intertwiners was proved or declared impossible.
The source note's N1–N8 assessment narrows the exact conditional implication;
it does not assert a formal negative-packet PASS or a framework obstruction.
''',
'LITERATURE_BRIDGES.md':'''# Matched primary imports

[Ranard–Walter–Witteveen](https://arxiv.org/pdf/2012.00741v2) supplies the
ALPU/QCA definitions, hyperfinite near-inclusion machinery, finite-window
index formula and stability. PDF SHA-256
03fc3e67ccd36c1f6ac7e5336bdf6977010cc12d615f90e095ded550268eda17.
[Nachtergaele–Sims–Young](https://arxiv.org/pdf/1810.02428v2) supplies the
matched microscopic propagation and norm-limit results. PDF SHA-256
42fc3029fa582f14a01f858463f481d5cacf21ed785791d32c72dd9df97f66cd.
The note and independent review identify exact statements, pages and limits.
No complete-paper proof or global novelty claim is made. Repository N1/B1/M1
reports are frozen context, not imported physics authority.
''',
'ARTIFACT_PLAN.md':'''# Coherent milestone

One complete theorem note, one self-contained finite runner, exact publication
map, raw author/independent evidence and reference-source identities. The
index inequality and uniform tube application belong together: neither alone
settles the original dimension-growth concern. This branch is main-based.
''',
'ROUTE_PORTFOLIO.md':'''# Independent checking

The author proof and controls are separate from the reviewer's pre-control
reconstruction and microscopic geometric derivation. The reviewer's exact
implementation checks 1,920 finite parameter cases of its all-size formulas.
The author also has smaller geometric controls, discovered afterward; this
is independent implementation, not a second LR theorem. Root suggested the
entropy route and requested the explicit LR prefactor; root reading is not
the independent source review. No model or effort override was used.
''',
'TRACE_GATE.md':'''# Research connection

```yaml
trace_class: direct_blocker_closure
reachability_to_target: closes
artifact_role: theorem
target_claim_id: null
target_blocker_text: "Quantified approximate partial-factor index lemma and uniform tube-size dependence in N1 Section 2.2."
source_of_blocker_text: frozen_candidate_law_N1_c284a41bfee8a1238643330ddd46f3a7c4f6f1a865509a9aaec5ab6f4238ad13
```

The named mathematical estimate is proved under explicit imports. The
preceding physical/representation reduction and model selection remain separate.
''',
'CLAIM_STATUS_CERTIFICATE.md':'''# Claim status

```yaml
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
status: provisional
audit_required_before_effective_retained: true
bare_retained_allowed: false
conditional_surface_status: "Specified spin-chain automorphism/tail/block-norm hypotheses and separately supplied Hamiltonian/shift application."
hypothetical_axiom_status: null
admitted_observation_status: null
```

Original proof is authorized and the complete argument received a separate
source review. No Lean verification or applied audit verdict is claimed.
''',
'REVIEW_HISTORY.md':'''# Completed source review

Target bccf07d0ca041c9c0585beccb912ac35e1da12deadae3c50efb78d439cb9b441.
Independent report9118707fdcc85cdfd0a1160598872fb8544a9de757b3a1efe8e93292719c533c;
receipt03b9c5236179f02220f16f4770f7386eb4673aa78d8881be9b8076c6afe267bf.
No material correction at P1–P29's stated conditional scope. The full argument
and imported hypotheses were reconstructed before author-helper inspection.
Root read the report, reconstruction, geometric proof, helper/full output,
author helper/baseline and every new mutant traceback. All 521 author/review
artifact bindings matched; mutation prefixes match the fully read baseline.
RWW Appendix B is a matched import, not independently re-proved. Full physical
N1/B1/M1 claims and later Y1/RZ work are not certified by this review.
''',
'HANDOFF.md':'''# Fixed index milestone snapshot

Based on main a13caa4885f547c8d206265b031ba7649e539fd9; root is the sole
publication writer. This is not a second live campaign checkpoint. Current
campaign state remains in the transport worktree's toe-dynamics-bridge-20261009
STATE.yaml and HANDOFF.md. Fixed deadline: 2026-10-12 16:00:52 UTC.
Keep exact references and local recovery paths if source review is resumed.
''',
'PR_BACKLOG.md':'''# Local milestone decision

OPEN — the complete partial-factor inequality and its uniform microscopic
tube estimate form one regular reviewable mathematical milestone.

The existing candidate-law work identifies a missing approximate-index step.
An informal boundary-capacity intuition is insufficient because the transverse
slice dimension grows exponentially with its width. A qualitative locality
approximation with an untracked constant would leave the same problem hidden
inside a symbol. This proof exposes the correction constants and finite
window, then retains every logarithmic dimension factor in the entropy bound.
The final normalized tube bound tends to zero with explicit resource choices.

The microscopic application is part of this milestone because a supersite
Hamiltonian estimate could introduce a spurious propagation speed depending
on slice volume. The proof instead sums in the original metric, keeps one
transverse volume factor in the localization tail, and retains the separate
support-volume factor where Duhamel actually needs it. The independent
geometric-series reconstruction targets that exact potential failure.

The preceding physical interpretation remains out of scope. The theorem
assumes the full-algebra shift identity when using its conditional consequence;
it does not infer that identity from a local scattering shell or a finite
sample of observables. The existing candidate-law PR remains unchanged, and
this standalone note needs no unmerged science dependency. Its source report
is preserved so the named obligation and its later use can be assessed.

The complete source review found no required mathematical repair. Publication
still requires its canonical finite execution, actual complete-source mutation
checks and source-bound conformance. These checks support reproducibility;
the new infinite-algebra proof is not established by finite PASS counts.
No science merge, audit verdict, retained-status assignment, physical axiom
or main-branch change follows from this local OPEN decision.
'''
}
for name,text in texts.items():(P/name).write_text(text)

# Preserve all original author/reviewer bytes locally. The repository packet
# carries our own evidence and reference identities/URLs for third-party papers.
rows=[];references=[]
paths=[source,S/'APPROXIMATE_PARTIAL_FACTOR_INDEX_REVIEW.md',S/'partial_factor_root_evidence_validation.json']
for folder in ['partial_factor_index','partial_factor_review']:
    paths.extend(p for p in sorted((S/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
for src in paths:
    rel=src.relative_to(S);b=src.read_bytes()
    is_reference=(src.suffix=='.pdf' or src.name.startswith(('nsy_page_','rww_page_','partial_index_')))
    row={'original':str(src),'sha256':sha(b),'bytes':len(b)}
    if is_reference:
        row['recovery']='Exact original remains at the external path; retrieve primary paper through official URL and verify its identity.'
        if 'nsy' in src.name:row['primary_url']='https://arxiv.org/pdf/1810.02428v2'
        elif 'rww' in src.name:row['primary_url']='https://arxiv.org/pdf/2012.00741v2'
        else:row['primary_urls']=['https://arxiv.org/pdf/2012.00741v2','https://arxiv.org/pdf/1810.02428v2']
        references.append(row);continue
    dst=P/'evidence'/(str(rel)+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(gzip.compress(b,mtime=0));row['preserved']=str(dst.relative_to(P));rows.append(row)
(P/'EVIDENCE_MAP.json').write_text(json.dumps({'scope':'Lossless authored/repository evidence; complete third-party reference sources remain external, with hashes and URLs.',
    'files':rows,'external_reference_sources':references},indent=2)+'\n')
(P/'reconstruct.py').write_text('''from pathlib import Path
import gzip,hashlib,json
P=Path(__file__).resolve().parent
W=P.parents[3]
for row in json.loads((P/'PUBLICATION_EDITS.json').read_text())['outputs']:
    b=gzip.decompress((P/row['preserved_source']).read_bytes())
    assert hashlib.sha256(b).hexdigest()==row['source_sha256']
    t=b.decode()
    for edit in row['edits']:
        assert t.count(edit['before'])==1
        t=t.replace(edit['before'],edit['after'])
    t+=row['appended_text']
    assert (W/row['publication_path']).read_text()==t
    assert hashlib.sha256(t.encode()).hexdigest()==row['publication_sha256']
print('PASS: complete theorem and primary reconstructed from unchanged frozen arguments and explicit publication edits')
''')
print(json.dumps({'note_sha256':sha((W/note_path).read_bytes()),'primary_sha256':sha((W/primary_path).read_bytes()),
 'preserved_authored_evidence':len(rows),'external_reference_identity_records':len(references),'snapshot_files':len(texts)}))
