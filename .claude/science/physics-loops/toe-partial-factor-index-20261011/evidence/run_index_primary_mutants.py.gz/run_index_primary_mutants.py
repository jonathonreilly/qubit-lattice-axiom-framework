from pathlib import Path
import hashlib,json,subprocess,sys,time
from datetime import datetime,timezone
S=Path(__file__).resolve().parent
W=S.parent/'index_worktree'
D=S/'index_primary_mutations';D.mkdir(exist_ok=False)
p=W/'scripts/approximate_partial_factor_index_2026_10_11.py';body=p.read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(body.encode())=='02911089b93ec2feef68453997af046db2a0141f0d8fe71e7731a806189c8298'
author=json.loads((S/'partial_factor_index/EXECUTION_AND_MUTATIONS.json').read_text())
rows=[]
for original in author['records']:
    if not original['edit']:continue
    name=original['name'];e=original['edit'];assert body.count(e['before'])==1
    source=D/(name+'.py');source.write_text(body.replace(e['before'],e['after']))
    started=datetime.now(timezone.utc).isoformat();start=time.monotonic()
    try:
        r=subprocess.run([sys.executable,str(source)],cwd=W,capture_output=True,timeout=120)
        code,out,err,timed_out=r.returncode,r.stdout,r.stderr,False
    except subprocess.TimeoutExpired as ex:
        code,out,err,timed_out=124,ex.stdout or b'',ex.stderr or b'',True
    elapsed=time.monotonic()-start
    (D/(name+'.stdout')).write_bytes(out);(D/(name+'.stderr')).write_bytes(err)
    old=(S/'partial_factor_index'/original['log']).read_text().splitlines()
    expected=old[-1]
    intended=code==1 and not timed_out and err.decode().splitlines()[-1]==expected
    rows.append({'name':name,'before':e['before'],'after':e['after'],
       'command':[sys.executable,str(source)],'cwd':str(W),'started_utc':started,
       'timeout_seconds':120,'elapsed_seconds':elapsed,'exit_code':code,'timed_out':timed_out,
       'source_sha256':sha(source.read_bytes()),'stdout_sha256':sha(out),'stderr_sha256':sha(err),
       'expected_assertion':expected,'intended_failure':intended})
    (D/'manifest.json').write_text(json.dumps({'primary_path':str(p),'primary_sha256':sha(body.encode()),
       'scope':'Actual entire publication-primary variants; no infinite-algebra proof by finite enumeration.',
       'runs':rows},indent=2)+'\n')
    print(json.dumps({'name':name,'exit_code':code,'intended_failure':intended}),flush=True)
    assert intended,(name,err)
assert len(rows)==13 and p.read_text()==body
print('COMPLETE: thirteen whole-publication-primary variants fail at their intended assertions')
