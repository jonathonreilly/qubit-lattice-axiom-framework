---
title: Preparation energy moments for finite multi-port Hamiltonians
claim_id: multi_port_preparation_energy_moments_bounded_theorem_note_2026-10-14
claim_type: bounded_theorem
target_claim_type: bounded_theorem
actual_current_surface_status: conditional-support
artifact_role: theorem
trace_class: upstream_support
target_claim_id: null
target_blocker_text: Preparation accuracy required for the supplied finite multi-port Hamiltonian
source_of_blocker_text: user_goal
reachability_to_target: supports
conditional_surface_status: same installed finite Hamiltonian, full original/reference marginal and actual auxiliary-defect premises
hypothetical_axiom_status: null
admitted_observation_status: null
status: proposed_retained
canonical_parent_binding_complete: true
audit_required_before_effective_retained: true
bare_retained_allowed: false
upstream_dependencies: ["simultaneous_multi_port_three_pauli_bounded_theorem_note_2026-10-14"]
runner: scripts/preparation_moment_source_identity_2026_10_14.py
claim_type_reason: checked conditional moment bounds with a complete restricted-chain prerequisite; physical preparation and energy identification remain supplied
next_trace_action: establish or independently certify the stated preparation and physical calibration premises before physical use
---

Claim type: bounded_theorem

# What does imperfect auxiliary preparation cost in energy moments?

A mediator construction can approximate its target dynamics while carrying a large energy variance in its bare auxiliary vacuum. Imperfect preparation changes that distribution again. This note bounds the second change without discarding the first. It combines two checked finite arguments for the same installed Hamiltonian, and supplies the complete restricted-chain prerequisite used in the generic argument's length-dependent examples.

The scientific bodies are unchanged: the generic vacuum-block proof `be126506`, the sharper local-defect proof `de7e7916`, and the restricted placement proof `79d2388a`. Each appears in full below. Their original proposed or pending-review sentences are historical source text. Current conditional analytic acceptances are respectively `237b2dad`, `d7fa3588` and `8d3de83e`; their source assemblies were separately accepted under `702367be`, `825da3a2` and `b104daaf`. Exact identities and dispositions are preserved in the accompanying source manifest. These source decisions do not confer independent audit or retained status.

## Domain, comparison and actual energy costs

Both moment comparisons use exactly the same finite installed K, including every original factor, all auxiliaries and the actual scalar reserve. The original H is arbitrary within its stated finite norm bound and remains unchanged. The actual preparation may correlate old data, dirty factors, auxiliaries and an arbitrary passive reference. The required old-marginal estimate is a full old/reference trace-norm estimate; one-site data marginals do not replace it. Auxiliary excitation expectations and their certified upper bounds are supplied preparation information, not an apparatus for measuring them.

For the multi-port application, write

    K = H + c I + Delta L + sqrt(Delta) V,  Delta > 0,
    c = s0 + r_installed,
    kappa_vac = J*V^2J = (209/16) sum_i |lambda_i| times I.

The exact ideal mean is Tr(rho H)+c. The exact ideal variance is Var_rho(H)+Delta kappa_vac. Original covariances, the coupling variance, full penalty strengths, scalar, elapsed time, precision and any installed positivity reserve remain charged. A smaller sensitivity bound does not lower those baseline costs or identify K with a native physical-energy observable. Conservation refers to two specified preparations evolved under this same closed K; it does not permit appending a new vacuum to a later old marginal.

The generic argument uses a scalar vacuum-column identity C*C=kappa I and its actual full excited block. The sharper argument uses the literal local penalty and the actual one- and two-excitation columns. In particular, two-flip contributions of anticommuting old Pauli ports cancel, while commuting pairs contribute. Shared old factors are therefore retained rather than replaced by independent cells.

The two proofs use different local symbols. In the generic proof, kappa is the physical column value Delta kappa_vac and q is the nonvacuum probability. In the sharper proof, kappa denotes kappa_vac, p is the nonvacuum probability and eta is the sum of local auxiliary excitation probabilities. The generic epsilon_old and sharper epsilon both control the complete old/reference marginal. Equation numbers belong to their own proof, not to a shared numbering system.

For normalized states, the source bounds cover mean, centered second moment and scalar variance. Reference-valued moments require the additional epsilon_R=||sigma_R-rho_R||_1 terms stated in the sharper proof, including Delta kappa_vac epsilon_R for its centered second moment and the scalar-dependent contribution to its uncentered mean. Positive unnormalized blocks inherit homogeneous linear moment statements; a normalized rare outcome requires its actual probability. No operator-valued variance or complete-output accuracy theorem follows merely from these moment estimates.

## Proof obligations and dependency roles

The generic block expansion, positivity estimate and variance bookkeeping are proved in Part I. The literal local-population, square-column and reference-valued refinements are proved in Part II. Their common external mathematical parent is the [simultaneous multi-port theorem](SIMULTANEOUS_MULTI_PORT_THREE_PAULI_BOUNDED_THEOREM_NOTE_2026-10-14.md), canonical SHA256 `f02e80d2c69be61819c9fc43a8a3125cc1432f895c01b93a5e7081ec2b4d8755`, whose complete raw body remains `be8f8d49362f5d9e363bd1df8b70b6e46b475beaa52e9ee5e18e0bece4293ddc`. The canonical identity is observed at commit `463fa381d9fe9403b6b6f3e3ce19505aa947edf2`, regular PR9574. The parent supplies the exact global K, full auxiliary-domain facts, vacuum scalar and paid resource contract.

The complete Appendix supplies the restricted `3 by 3` reserved-site chain construction used by Part I. It is an explicit internal prerequisite, not an invented canonical chain citation and not a new independent retained result. Its own sole theorem import is the same multi-port parent. Its fixed-time sufficient prescription Delta=D0 M^6, growing strengths and literal geometry remain conditional on all displayed premises. The newer chain-scaling proposal is not imported by this note, keeping later composition acyclic.

The earlier local-defect trace estimate `c163db2d` is preserved as comparison evidence. The two moment proofs already state and prove their required preparation estimates, so that trace result is not an additional theorem supplied by this publication. Its full body remains recoverable to check the historical coarse-bound comparison. Mathematical block, trace-norm, variance and projection tools are established machinery; no generic novelty claim is made.

The displayed local-defect exponents are sufficient bounds with tolerance-dependent constants. Exact inequalities take precedence over big-O notation, including at zero coefficients or H=0. Optional exact block dephasing has extra implementation, elapsed-time, control, calibration and reset costs. The appendix applies only to its reserved-site family and supplies no arbitrary occupied-site packing algorithm.

## Evidence and unresolved physical premises

The generic source was reviewed by a separate source-exposed block argument. The sharper source has an author's exact one-cell moment calculation on the full 16-dimensional auxiliary space and a separate reviewer's exact overlapping-port column calculation over all 32 old basis inputs with eight auxiliaries. The latter rejects a forced-commuting treatment. The restricted placement has its complete author and separate review evidence, including its incompatible-spare control. All recorded source exposure, actual programs, outputs, receipts and failures remain recoverable. A shared source family, prior parent authorship and exposure before selected checks are disclosed; the evidence is not presented as blind or model-diverse. No historical scientific computation was replayed for this publication.

The primary runner is a source-identity checker with zero mathematical predicates. It checks the declared complete inputs and reconstructs the three exact bodies and archived records; it does not prove the inequalities, rerun controls, certify geometry or supply an audit verdict. The identity manifest and byte/line maps distinguish current framing from historical records and allow exact reconstruction without duplicating complete proofs.

The strongest missing physical obligation is an implemented or certified preparation meeting the full old/reference marginal and auxiliary-defect premises while retaining the stated physical Hamiltonian and cost contract. Native preparation, local statistical certification and disturbance, common available strength caps, calibrated controls, physical energy identification, reader/reset and arbitrary occupied geometry remain supplied or open. This finite conditional result establishes no continuum, permanent-record or native-apparatus claim.

## Review record

The three accepted raw bodies are preserved verbatim. This grouping adds explanatory framing, a notation map and complete prerequisite placement; it alters no mathematical assertion or source boundary. Actual component review, integration checks and any later retained audit have distinct records. No audit verdict or platform, editable-prompt or physical-axiom change is part of the result. Provenance-only references are written as source identifiers; the one Markdown theorem link is the sole external citation edge.

## Part I. Complete generic vacuum-block argument

