
## Appendix. Complete restricted-chain prerequisite

This unchanged accepted argument supplies the restricted geometry and sufficient resource scaling invoked in Part I. Its opening pending-assessment language is historical. The later chain-scaling refinement is not used here.

