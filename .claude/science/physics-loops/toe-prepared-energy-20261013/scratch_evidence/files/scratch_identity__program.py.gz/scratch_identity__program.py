#!/usr/bin/env python3
"""Isolated identity and diff-format controls; no mathematical predicate or canonical API."""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import traceback

Q = Path(__file__).resolve().parent
CW = Q.parent.parent / 'correlation_worktree'
PACKET = '.claude/science/physics-loops/toe-prepared-energy-20261013'
DEADLINE = datetime(2026, 10, 13, 16, 42, 30, tzinfo=timezone.utc)
E = Q / 'scratch_identity'
sys.dont_write_bytecode = True


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(path):
    return json.loads(path.read_bytes())


def save(path, value):
    assert path.resolve().is_relative_to(Q)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(value if isinstance(value, bytes) else
                     (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def run(label, root, runner, expected, error=None):
    folder = E / label
    folder.mkdir()
    argv = [sys.executable, '-B', str(root / runner)]
    timeout = min(60, (DEADLINE - datetime.now(timezone.utc)).total_seconds())
    assert timeout > 0
    start, tick = datetime.now(timezone.utc).isoformat(), time.monotonic()
    out, err, code, timed_out, launch_error = b'', b'', None, False, None
    try:
        process = subprocess.Popen(argv, cwd=root, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        try:
            out, err = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            out, err = process.communicate()
        code = process.returncode
    except OSError as exc:
        launch_error, err = repr(exc), repr(exc).encode()
    save(folder / 'stdout', out)
    save(folder / 'stderr', err)
    record = {'argv': argv, 'cwd': str(root), 'interpreter': sys.executable, 'python': sys.version,
        'started_utc': start, 'finished_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - tick, 'timeout_seconds': timeout,
        'timed_out': timed_out, 'exit_code': code, 'expected_exit_code': expected,
        'expected_error': error, 'launch_error': launch_error, 'runner_sha256': sha((root / runner).read_bytes()),
        'stdout_sha256': sha(out), 'stderr_sha256': sha(err), 'stdout_bytes': len(out), 'stderr_bytes': len(err),
        'canonical_cache_api_used': False, 'mathematical_predicates_executed': 0}
    save(folder / 'execution.json', record)
    assert not timed_out and launch_error is None and code == expected, record
    if expected == 1:
        assert out == b'' and json.loads(err) == {'result': 'identity_verification_incomplete',
            'error': error, 'mathematical_operations_executed': False,
            'mathematical_predicates_executed': 0, 'scientific_mutations_executed': 0}
    return out, err, record


def main():
    assert Q.name == 'prepared_energy_publication_preparation' and not E.exists()
    assert datetime.now(timezone.utc) < DEADLINE and not (Q / 'SOURCE_FREEZE.json').exists()
    E.mkdir()
    save(E / 'program.py', Path(__file__).read_bytes())
    spec = js(Q / 'SPECIFICATIONS.json')
    rendering = js(Q / 'RUNNER_SOURCE_RENDERING.json')
    parents = {p['path']: p for p in js(Q / 'payload' / PACKET / 'PARENT_BINDINGS.json')['parents']}
    inputs = rendering['inputs']
    assert len(inputs) == len(set(inputs))
    values, origins = {}, []
    for name in inputs + [r['runner'] for r in spec['notes']]:
        source = CW / name if name in parents else Q / 'payload' / name
        raw = source.read_bytes()
        if name in parents:
            assert sha(raw) == parents[name]['published_sha256'] and len(raw) == parents[name]['bytes']
        values[name] = raw
        origins.append({'path': name, 'source': str(source), 'sha256': sha(raw), 'bytes': len(raw)})
    save(E / 'SCRATCH_INPUTS.json', {'files': origins, 'file_count': len(origins),
        'scope': 'Exact temporary copies; no source is loaded from a canonical cache.'})
    successes, controls = [], []
    with tempfile.TemporaryDirectory(prefix='prepared-energy-identity-') as directory:
        root = Path(directory).resolve()
        assert not root.is_relative_to(CW) and not root.is_relative_to(Q)
        for name, raw in values.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(raw)
        for note in spec['notes']:
            out, err, record = run('baseline_' + note['key'], root, note['runner'], 0)
            lines = out.decode().splitlines()
            assert err == b'' and len(lines) == 6
            result = json.loads(lines[0])
            assert result['result'] == 'source_identities_and_reconstruction_match'
            assert result['claim_id'] == note['claim_id'] and result['mathematical_operations_executed'] is False
            assert result['mathematical_predicates_executed'] == result['scientific_mutations_executed'] == 0
            assert result['independent_review_supplied_by_tool'] is result['no_go_packet_pass_supplied_by_tool'] is False
            assert set(result['external_scientific_input_reads']) == set(parents)
            assert sorted(result['external_scientific_input_reads'] + result['package_local_integrity_reads']) == inputs
            for prefix, line in zip(['per_element:', 'per_site:', 'per_mode:', 'per_block:', 'lattice_wide:'], lines[1:]):
                assert line.startswith(prefix + ' checked and not executed — source integrity only;')
            successes.append({'key': note['key'], 'runner': note['runner'], 'runner_sha256': record['runner_sha256'],
                'exit_code': record['exit_code'], 'stdout_sha256': record['stdout_sha256'], 'stderr_sha256': record['stderr_sha256']})
        first = spec['notes'][0]['runner']
        original = values[first].decode()
        changes = [
            ('wrong_full_context', 'n=3)).encode()', 'n=max(len(a.splitlines()), len(b.splitlines())))).encode()'),
            ('wrong_corrected_labels', "accepted_source_diff(baseline, assembled, note['baseline'], note['candidate'])",
             "accepted_source_diff(baseline, assembled, 'original/' + Path(core_paths[0]).name, source_notes[note['key']]['path'])"),
        ]
        for label, old, new in changes:
            assert original.count(old) == 1
            changed = original.replace(old, new, 1).encode()
            save(E / (label + '.runner.py'), changed)
            delta = ''.join(difflib.unified_diff(original.splitlines(True), changed.decode().splitlines(True),
                'correct/' + first, label + '/' + first, n=3)).encode()
            save(E / (label + '.diff'), delta)
            (root / first).write_bytes(changed)
            _, _, record = run(label, root, first, 1, 'Complete accepted assembly diff differs')
            controls.append({'case': label, 'expected_error': record['expected_error'], 'exit_code': record['exit_code']})
            (root / first).write_bytes(values[first])
        archive = next(p for p in inputs if '/objects/' in p)
        cases = [('archive', archive, 'Compressed archive changed'),
                 ('publication', spec['notes'][0]['path'], 'Published source does not reconstruct'),
                 ('metadata', PACKET + '/PUBLICATION_EDITS.json', 'Publication transformation changed'),
                 ('parent', next(iter(parents)), 'Canonical parent bytes changed')]
        for label, target, error in cases:
            (root / target).write_bytes(values[target] + b'\nbyte-integrity-tamper\n')
            _, _, record = run('tamper_' + label, root, first, 1, error)
            controls.append({'case': label, 'target': target, 'expected_error': error, 'exit_code': record['exit_code']})
            (root / target).write_bytes(values[target])
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(values)
        assert all((root / name).read_bytes() == raw for name, raw in values.items())
    for row in origins:
        raw = Path(row['source']).read_bytes()
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    result = {'utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Temporary noncanonical source-identity regression only; no canonical prepare, verify, cache, graph or Git action.',
        'successes': successes, 'controls': controls, 'scratch_identity_processes_executed': len(successes) + len(controls),
        'successful_identity_processes': len(successes), 'expected_nonzero_controls': len(controls),
        'actual_declared_input_count': len(inputs), 'external_parent_count': len(parents),
        'scratch_inputs_restored': True, 'original_inputs_unchanged': True,
        'canonical_identity_processes_executed': 0, 'prepare_verify_executed': False,
        'scientific_programs_executed': 0, 'mathematical_predicates_executed': 0,
        'canonical_writes': 0, 'cache_api_calls': 0, 'git_commands': 0,
        'root_publication_source_review': 'pending', 'root_canonical_runtime': 'pending', 'audit_verdict': False}
    save(E / 'RESULT.json', result)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        if E.exists():
            save(E / 'FAILURE.json', {'traceback': traceback.format_exc(), 'automatic_retry': False,
                'canonical_writes': 0, 'mathematical_predicates_executed': 0})
        raise
