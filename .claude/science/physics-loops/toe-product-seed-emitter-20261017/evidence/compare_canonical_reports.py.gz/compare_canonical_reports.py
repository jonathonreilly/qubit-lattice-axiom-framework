"""Compare every returned scientific value to the already reviewed reports."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

D = Path(__file__).resolve().parent
N = D.parent
W = N.parent / 'correlation_worktree'
S = N / 'emitter_publication_draft'
Q = W / '.claude/science/physics-loops/toe-product-seed-emitter-20261017'
programs = json.loads((S / 'PROGRAM_INPUTS.json').read_text())['programs']
roles = json.loads((Q / 'SOURCE_ADAPTATION.json').read_text())['programs']
mapping = json.loads((W / 'outputs/product_seed_emitter_2026_10_17_inputs/INPUT_MAP.json').read_text())
result = json.loads((D / 'canonical_02/result.json').read_text())
initial = json.loads((D / 'canonical_01/result_emitted_before_cache_rejection.json').read_text())
shared = {'cpu_soft_hard_seconds': [120, 120], 'external_wall_cap_seconds': 120,
          'wall_enforcement': 'Required canonical runner_cache execution; this class does not enforce wall time.'}
cap_keys = {'cpu_cap_seconds', 'wrapper_wall_cap_seconds', 'cpu_seconds_cap', 'parent_wall_seconds_cap', 'wall_cap_seconds', 'external_wall_cap_seconds'}

def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def historical_normalized(value):
    if isinstance(value, list):
        return [historical_normalized(v) for v in value]
    if not isinstance(value, dict):
        return value
    out = {}
    caps = {k: v for k, v in value.items() if k in cap_keys}
    for k, v in value.items():
        if k == 'elapsed_seconds' or k in cap_keys:
            continue
        name = 'historical_source_program_sha256' if k == 'script_sha256' else k
        out[name] = historical_normalized(v)
    if caps:
        out['historical_source_run_limits'] = caps
        out['actual_shared_process_limits'] = shared
    return out

def current_normalized(value):
    if isinstance(value, list):
        return [current_normalized(v) for v in value]
    if isinstance(value, dict):
        return {k: current_normalized(v) for k, v in value.items() if k not in {'elapsed_seconds', 'portable_execution'}}
    return value

comparisons = []
assert set(result['reports']) == {r['role'] for r in roles}
for program, role in zip(programs, roles):
    key = role['role']
    oldpath = S / 'sources' / program['output']
    old = json.loads(oldpath.read_text())
    actual = result['reports'][key]
    meta = actual['portable_execution']
    expected_meta = {'source_role': key,
                     'historical_source_run_limits': mapping['roles'][key]['historical_limits'],
                     'actual_shared_process_limits': shared,
                     'source_statement_scope': 'Original report scope/limitations strings retain their historical scientific meaning. This is a portable replay, not a new review.',
                     'original_program_sha256': mapping['roles'][key]['aliases']['__original_program__']['sha256']}
    assert meta == expected_meta, key
    normalized = historical_normalized(old)
    assert current_normalized(actual) == normalized, key
    assert current_normalized(initial['reports'][key]) == normalized, key
    payload = json.dumps(normalized, sort_keys=True, separators=(',', ':')).encode()
    comparisons.append({'role': key, 'historical_output': pin(oldpath),
                        'entire_scientific_payload_equal': True,
                        'normalized_payload_sha256': hashlib.sha256(payload).hexdigest(),
                        'allowed_differences': ['All mathematical values, point diagnostics, check records and limits other than execution metadata are exactly equal.', 'Only elapsed_seconds values, the explicitly nested historical cap metadata, two historical self-hash key labels, and separately checked portable_execution metadata differ.']})
assert result['actual_combined_process_limits'] == shared
assert (W / 'outputs/product_seed_emitter_2026_10_17.json').read_bytes() == (D / 'canonical_02/result.json').read_bytes()
for path, sha in result['input_sha256'].items():
    assert hashlib.sha256((W / path).read_bytes()).hexdigest() == sha
assert len(result['input_sha256']) == 168
for row in result['resolved_reads']:
    assert row['sha256'] == mapping['roles'][row['role']]['aliases'][row['logical_identity']]['sha256']
    assert hashlib.sha256((W / row['path']).read_bytes()).hexdigest() == row['sha256']
record = {'checked_utc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Exact data comparison of six returned payloads, not another scientific execution or theorem review.',
          'canonical_result': pin(D / 'canonical_02/result.json'),
          'canonical_receipt': pin(D / 'canonical_02/EXECUTION.json'),
          'preserved_cache_rejected_attempt': pin(D / 'canonical_01/FAILURE.json'),
          'report_comparisons': comparisons, 'current_declared_inputs_verified': 168,
          'resolved_reads_verified': len(result['resolved_reads']),
          'scientific_discrepancies': [],
          'failure_limit': 'The first attempt emitted an equal scientific JSON but has no valid cache; its deleted merged child stream is unavailable. Only canonical_02 is the successful canonical execution.'}
(D / 'REPORT_COMPARISON.json').write_text(json.dumps(record, indent=2) + '\n')
(Q / 'REPORT_COMPARISON.json').write_bytes((D / 'REPORT_COMPARISON.json').read_bytes())
print(json.dumps({'report': pin(D / 'REPORT_COMPARISON.json'), 'six_complete_scientific_payloads_equal': True, 'declared_inputs': 168, 'resolved_reads': len(result['resolved_reads'])}, indent=2))
