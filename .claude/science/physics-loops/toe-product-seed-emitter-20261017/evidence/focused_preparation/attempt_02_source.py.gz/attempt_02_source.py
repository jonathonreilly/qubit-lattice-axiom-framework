"""Focused publication checks of frozen proofs, canonical evidence and packaging.

No scientific checker is re-executed. Integrated-main landing gates stay separate.
"""
from pathlib import Path
import ast
import datetime
import gzip
import hashlib
import json
import re
import subprocess
import sys

sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
W=D.parents[1]/'correlation_worktree'
Q=W/'.claude/science/physics-loops/toe-product-seed-emitter-20261017'
E=Q/'evidence'
F=W/'outputs/product_seed_emitter_2026_10_17_inputs'
sys.path[:0]=[str(W/'scripts'),str(W/'docs/audit/scripts')]
import runner_cache
import build_citation_graph
import forensic_evidence_readiness
import no_go_discipline_gate

primary='scripts/product_seed_emitter_2026_10_17.py'
helpers=sorted('scripts/product_seed_emitter_'+x+'_2026_10_17.py' for x in ['local','installed','weighted'])
note='docs/PRODUCT_SEED_EMITTER_BOUNDED_THEOREM_NOTE_2026-10-17.md'
claim='product_seed_emitter_bounded_theorem_note_2026-10-17'
output='outputs/product_seed_emitter_2026_10_17.json'
cache='logs/runner-cache/product_seed_emitter_2026_10_17.txt'
graph='docs/audit/data/citation_graph_manifest.json'
def digest(p):
    b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def read(p):return json.loads(p.read_text())

manifest=read(F/'ARTIFACT_MANIFEST.json')
assert len(manifest['files'])==163
for row in manifest['files']:
    p=W/row['path'];assert p.is_file() and not p.is_symlink()
    assert digest(p)=={k:row[k] for k in ('bytes','sha256')},row['path']
assert {str(p.relative_to(W)) for p in F.rglob('*') if p.is_file()}=={r['path'] for r in manifest['files']}|{str((F/'ARTIFACT_MANIFEST.json').relative_to(W))}
bodymap=read(F/'EMBEDDED_SOURCE_MAP.json');nb=(W/note).read_bytes()
assert digest(W/note)=={k:bodymap[k] for k in ('bytes','sha256')}
assert len(bodymap['bodies'])==3
for body in bodymap['bodies']:
    source=(W/body['source']).read_bytes()
    assert nb[body['offset_bytes_zero_based']:body['end_byte_exclusive']]==source
    assert len(source)==body['length_bytes'] and hashlib.sha256(source).hexdigest()==body['sha256']
source=read(Q/'SOURCE_MANIFEST.json')
for row in [source['primary'],*source['helpers']]:
    assert digest(W/row['path'])=={k:row[k] for k in ('bytes','sha256')}
assert digest(Q/'SOURCE_ADAPTATION.json')['sha256']==source['source_adaptation_map']['sha256']
assert digest(Q/'ROOT_PORTABILITY_ACCEPTANCE.json')['sha256']=='4442fa7f1409992d37feb8f56065e2f36ca44d83ab8d398c4fd18e0d4f2451f6'

archive_maps=[];raw_by_hash={}
for path,count in [(E/'ROOT_EVIDENCE_MAP.json',67),(E/'MUTATION_EVIDENCE_MAP.json',127)]:
    mapping=read(path);assert len(mapping['files'])==count
    for row in mapping['files']:
        p=W/row['path'];assert digest(p)=={k:row[k] for k in ('bytes','sha256')}
        raw=gzip.decompress(p.read_bytes()) if row['compression']=='gzip' else p.read_bytes()
        assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256']
        raw_by_hash[row['raw_sha256']]=row['path']
    archive_maps.append({'path':str(path.relative_to(W)),**digest(path)})
historical=read(Q/'PORTABILITY_FREEZE.json');assert len(historical['files'])==220
allowed={note,str((F/'EMBEDDED_SOURCE_MAP.json').relative_to(W)),str((F/'ARTIFACT_MANIFEST.json').relative_to(W)),str((Q/'PUBLISH_CHECKS.json').relative_to(W))}
transitions=[]
for row in historical['files']:
    current=digest(W/row['path'])
    if current!={k:row[k] for k in ('bytes','sha256')}:
        assert row['path'] in allowed and row['sha256'] in raw_by_hash,row['path']
        transitions.append({'path':row['path'],'historical':{k:row[k] for k in ('bytes','sha256')},'current':current,'archived_original':raw_by_hash[row['sha256']]})
assert {r['path'] for r in transitions}>=allowed-{str((Q/'PUBLISH_CHECKS.json').relative_to(W))}

declared=runner_cache.declared_input_paths(W/primary)
result=read(W/output);execution=read(D/'canonical_02/EXECUTION.json')
assert len(declared)==168 and set(declared)==set(result['input_sha256'])
for rel,sha in result['input_sha256'].items():assert digest(W/rel)['sha256']==sha
assert execution['status']=='ok' and execution['exit_code']==0 and execution['cache_status']=='fresh'
assert execution['all_source_input_bytes_unchanged'] and execution['runner_cache_also_checked_filesystem_generation_tokens']
assert execution['caps']=={'CPU_soft_hard_seconds':[120,120],'external_wall_seconds':120}
assert digest(W/output)=={k:execution['result'][k] for k in ('bytes','sha256')}
assert digest(W/cache)=={k:execution['cache'][k] for k in ('bytes','sha256')}
pre=read(D/'canonical_02/PRELAUNCH.json')
for row in [pre['runner'],*pre['inputs']]:assert digest(row['path'])=={k:row[k] for k in ('bytes','sha256')}
for key in ('prelaunch','stdout_merged','stderr_protocol'):
    row=execution[key];assert digest(row['path'])=={k:row[k] for k in ('bytes','sha256')}
comparison=read(Q/'REPORT_COMPARISON.json')
assert comparison['scientific_discrepancies']==[] and len(comparison['report_comparisons'])==6
assert comparison['canonical_result']['sha256']==digest(W/output)['sha256']
assert result['actual_combined_process_limits']['cpu_soft_hard_seconds']==[120,120]
assert result['actual_combined_process_limits']['external_wall_cap_seconds']==120
mutation=read(Q/'ROOT_MUTATION_REVIEW.json')
assert len(mutation['cases'])==12 and mutation['unexpected_failures']==0 and mutation['all_initial_attempts']
assert mutation['current_bytes_verified_for_every_prelaunch_binding']

found_helpers=build_citation_graph.resolve_helper_runner_paths(primary)
assert found_helpers==helpers,found_helpers
row={'claim_id':claim,'note_path':note,'runner_path':primary,'helper_runner_paths':helpers,'claim_type':'bounded_theorem'}
issue=forensic_evidence_readiness.cached_row_readiness_issue(row,{claim:row},W)
assert issue is None,issue
assert runner_cache.cache_status(primary)=='fresh'
g=read(D/'GRAPH_VERIFICATION.json')
assert g['added']==[claim] and not g['removed'] and not g['rewired']
assert g['new_edges']==[{'from':claim,'to':'two_body_autonomous_halt_bounded_theorem_note_2026-10-17'}]
assert g['manifest_sha256']==digest(W/graph)['sha256']
assert g['new_node']['note_hash']==digest(W/note)['sha256']
assert g['new_node']['helper_runner_paths']==helpers
assert all(r['exit_code']==0 for r in g['executions'])
trigger=no_go_discipline_gate.source_requires_no_go_discipline(note,nb.decode(),'bounded_theorem')
assert not trigger,trigger

compiled=[]
for p in [W/primary,*[W/h for h in helpers],*[p for root in (F,Q) for p in root.rglob('*.py')]]:
    compile(p.read_bytes(),str(p),'exec');compiled.append(str(p.relative_to(W)))
texts=[W/note,*sorted(Q.glob('*.md'))]
vocab=subprocess.run([sys.executable,'scripts/vocab_lint.py','--report-only','--report-path',str(E/'VOCAB_REPORT.json'),*[str(p.relative_to(W)) for p in texts],primary,*helpers],cwd=W,capture_output=True,text=True,timeout=20)
(E/'vocab.stdout').write_text(vocab.stdout);(E/'vocab.stderr').write_text(vocab.stderr)
assert vocab.returncode==0 and '0 files with violations' in vocab.stdout,vocab.stdout+vocab.stderr
def outside_code(text):
    lines=[];fence=None
    for line in text.splitlines():
        match=re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$',line)
        if fence:
            if match and match[1][0]==fence[0] and len(match[1])>=len(fence) and not match[2].strip():fence=None
            continue
        if match:fence=match[1];continue
        lines.append(line)
    assert fence is None
    return re.sub(r'(`+).*?\1','','\n'.join(lines))
links=[]
for p in texts:
    for target in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)',outside_code(p.read_text())):
        if target.startswith(('http:','https:','#')):continue
        raw=p.parent/target.split('#')[0];dest=raw.resolve()
        assert dest.is_file() and not raw.is_symlink(),(str(p),target)
        links.append({'source':str(p.relative_to(W)),'target':str(dest.relative_to(W))})

branch=subprocess.check_output(['git','branch','--show-current'],cwd=W,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert branch=='physics-loop/toe-product-seed-emitter-20261017' and head=='0e8375354c42963234cc4b15b14ab6bb553c713d'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=W,text=True)
record={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status':'Focused publication checks complete; regular PR preparation allowed. No retained audit or integrated-main landing result.',
        'scope':'Root packaging/portability review and actual canonical replay of already qualified source mathematics.',
        'branch':branch,'parent_head':head,'artifact_hashes_verified':163,'declared_inputs_verified':168,
        'byte_identical_proof_bodies':bodymap['bodies'],'canonical_execution':execution,
        'six_payload_scientific_discrepancies':0,'canonical_input_changes_after_successful_execution':False,
        'first_attempt_failure':'Output-directory generation change rejected cache; full emitted JSON and outer error preserved. Removed first merged child stream unavailable.',
        'mutation_cases':12,'root_mutation_review':digest(Q/'ROOT_MUTATION_REVIEW.json'),
        'helper_discovery':helpers,'readiness_issue':issue,'cache_status':'fresh','graph':g,
        'no_go_gate_trigger':trigger,'compiled_sources':compiled,'vocabulary_violating_files':0,'local_links':links,
        'archive_maps':archive_maps,'historical_preparation_transitions':transitions,
        'historical_publish_checks_archive':'evidence/prepared_PUBLISH_CHECKS.json',
        'editable_prompt_files_changed':[],
        'remaining_gates':['Exact staged-path/root publication review and regular PR creation','Parent9661 landing or reviewed joint integration','Shared actual integrated-current-main full pipeline, strict lint and changed-evidence checks','Independent retained audit']}
write(Q/'PUBLICATION_EVIDENCE.json',{'scope':'Publication and mutation receipts outside the declared canonical closure. Historical bytes are preserved, not silently updated.',
      'files':[{'path':str(p.relative_to(W)),**digest(p)} for p in sorted(E.rglob('*')) if p.is_file()]})
ready=sorted(set([W/note,W/primary,*[W/h for h in helpers],W/output,W/cache,W/graph,*[p for root in (F,Q) for p in root.rglob('*') if p.is_file()]]))
whitespace=[]
for p in ready:
    rel=str(p.relative_to(W))
    proc=subprocess.run(['git','diff','--no-index','--check','/dev/null',rel],cwd=W,capture_output=True,text=True)
    assert not proc.stdout and not proc.stderr,(rel,proc.stdout,proc.stderr)
    whitespace.append(rel)
tracked=subprocess.run(['git','diff','--check'],cwd=W,capture_output=True,text=True)
assert tracked.returncode==0,tracked.stdout+tracked.stderr
assert runner_cache.cache_status(primary)=='fresh'
record['publication_paths_whitespace_checked']=len(whitespace)
record['tracked_diff_whitespace_exit_code']=tracked.returncode
write(Q/'PUBLISH_CHECKS.json',record)
write(D/'FOCUSED_VERIFICATION.json',record)
final_text_check=subprocess.run(['git','diff','--no-index','--check','/dev/null',str((Q/'PUBLISH_CHECKS.json').relative_to(W))],cwd=W,capture_output=True,text=True)
assert not final_text_check.stdout and not final_text_check.stderr
write(D/'READY_PATHS.json',{'scope':'Exact publication paths; generated citation_graph.json and unrelated paths excluded.',
      'parent_head':head,'files':[{'path':str(p.relative_to(W)),**digest(p)} for p in ready],
      'file_count':len(ready),'whitespace_checked':len(whitespace),'tracked_diff_check_exit':tracked.returncode})
print(json.dumps({'status':record['status'],'files':len(ready),'artifact_hashes':163,'declared_inputs':168,
                  'cache':'fresh','readiness_issue':issue,'mutations':12,'vocabulary_violations':0,
                  'proof_bodies':3,'graph_nodes_added':1,'graph_edges_added':1,'ready_map':digest(D/'READY_PATHS.json')},indent=2))
