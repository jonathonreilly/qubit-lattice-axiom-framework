# Product-seed emitter: twelve copied-source mutation checks

All twelve approved cases reached their intended scientific `AssertionError` on their sole initial attempts. There were no timeouts, checksum/import/path/syntax/harness failures, unexpected successes or retries. The complete streams, tracebacks, executed copies and receipts are preserved. No canonical source, declared input, note, Git state, checkpoint, prompt or audit verdict was edited by this task.

Root portability acceptance SHA256 is `4442fa7f1409992d37feb8f56065e2f36ca44d83ab8d398c4fd18e0d4f2451f6`. The accepted plan SHA256 is `3f7d1924a6d8e0b5ba28eecc3cf80ba3b1c62df9ca78b7b671c46c336d5aba97`. The root completion signal arrived before any mutation was launched. The successful root `canonical_02` run, whose receipt SHA256 is `40b90d012a3358b22225955cdb77c3ac988c8550a24d09fafe6b71338d514783`, supplies the unmutated baseline. The infrastructure-failed `canonical_01` attempt is not used as a baseline. No unmutated program was replayed here.

Every case had CPU soft/hard limits of60 seconds and an external wall cap of60 seconds; these are per-case limits. The initial plan allowed at most12 attempts and720 seconds of total case wall allowance. Actual summed child wall time was 29.179187751 seconds; summed child user plus system CPU time was 27.962596 seconds. Wall timings include process startup, binding checks and imports. Per-function timings are also preserved in each `OUTCOME.json`.

Before each child launch, a real serialized `PRELAUNCH.json` bound the current primary plus168 declared inputs, original and executed source, harness, case, resolver snapshot, launcher, Python executable, package metadata, command, environment and caps. The selected source and every bound file were checked again after the child, including file-generation fields. The169 canonical source/input bindings stayed unchanged throughout all twelve cases. Neither directory ancestors nor unrelated publication records are represented as scientific inputs.

The exact canonical `FrozenInputs` class was extracted as a source slice with identical AST. Its existing global `AUDIT_TIMEOUT_SEC` was bound to60 for mutation metadata; the class itself was unchanged. Its generic wall-enforcement text still names canonical runner-cache execution. For these mutation attempts, the actual external enforcement was `subprocess.run(timeout=60)` in [run_mutations.py](run_mutations.py), with CPU limits set in the child before its harness started. The unchanged generic string is preserved and qualified here, not rewritten after execution. Only the selected calculation function was invoked.

The harness and launcher are [case_harness.py](case_harness.py) and [run_mutations.py](run_mutations.py). [FINAL_CHECK.json](FINAL_CHECK.json) gives all source/stream/receipt hashes and the exact assertions. It independently rechecks the recorded bytes, single-source replacements, AST change scope, exception type, message and final traceback location; it does not rerun the mathematics. The adapter read all twelve complete stdout/stderr streams.

| Case | Scientific assertion reached | Wall seconds | Executed source SHA256 |
|---|---|---:|---|
| local_vacancy_scalar | `full 16-dimensional scalar-reserve identity` | 0.585099 | `5a8b394f9ba4a64f0254d487771b5141d7936a2beab930ca1efb08f499c6bf31` |
| local_phase_conjugation | `return/right-emission central notch` | 0.369577 | `d03d71a7afd3b8cb99e080feadba5587b1f53ef273968914444b80a2d8aaff25` |
| installed_noncommuting_order | `assert exact_zero(sigma_direct - (sigma_free + Y * T * X))` | 0.538171 | `80b53cfb8478af56ae8e8893407d9c07f05549ce598ed6aa0ed44e8e3bdadeea` |
| installed_lower_sign | `assert exact_zero(direct_aug - aug)` | 0.489453 | `9db815edbeffd596e0a857570b600e2af07dd7ff71698c351b6ff62bd30e4a4d` |
| installed_density_jacobian | `assert simp(jump_dk_times_pi - weights_dk_times_pi) == 0` | 0.599104 | `d65b6abea4b16fceb6105be5db8133c5a6b17918eff483d461294dfce0e32923` |
| installed_overlap_diagonal_only | `assert exact_zero(error_gram - (2 * eye - overlap - overlap.H))` | 0.659040 | `de07bba1505fa7e99166a644b45e5ebb9440e5f7b47d5a979a6d5a26b44491a9` |
| installed_grouped_localization | `assert Dj < 5 * 10 ** 42 and 2 * Dj ** 2 < Dpacket ** 2` | 0.268963 | `7c8fefd88afbebe6e5ae2ea22584a0acf7e46960c29ff2b9dd71319935e8aadd` |
| weighted_closed_inverse | `full_eight_coordinate_rank_one_inverse` | 4.053271 | `ca4623efbc7d5f9a91614d6e47a5b3ef1fdf1a74b721c1955020a8c61c865282` |
| weighted_cutoff_derivative | `cutoff_and_quotient_derivative` | 0.428295 | `35eb5456d32583be3bfd86d7338f9c60d1b9c07a9bac69384fdbcf4d79042a6f` |
| weighted_localized_derivative | `U_coefficient_complete` | 10.344992 | `1e0718a9d1f9b365ac8b7d5ff531030d65cd9ac2a6f185e835995e28547223f7` |
| weighted_first_omitted_hops | `graph_distance_formula` | 10.643350 | `152ca1ecc3b21b43bafeda645ea95b3f12c7faf7b4df73dc1c73cfb3d9c260c3` |
| weighted_grouped_ceiling | `assert 2 * Dj * Dj < D * D` | 0.199871 | `387a7cb2c4f13736aab876fbd5aa738620cca5d9e0620ae45978abe1cb1e1ae8` |

Original helper identities remain:

- Local: `c567cfeaaddff24d9f59d70e99a7d59cb324e389a10d18db04e46a173407f25e`.
- Installed: `a0394a9655d785b05ff61124400600cf9de5afa0dc998c3be5f1bdc191a7310d`.
- Weighted: `9591a45a5566d5c32501fcb007b4ecc8ae79abd9b956134761e29dbef5463669`.

The exact Python binary hash, platform and library distribution metadata were captured before launch; each child also reported its actual Python, SymPy and mpmath versions. Single-thread environment requests are recorded, but thread count was not measured. Bytecode writes were disabled. The complete baseline receipt and root finalization metadata are preserved in `snapshots/`.

These are source-exposed same-model fault-sensitivity checks of the accepted calculations. They do not add blind independence, a proof from finite samples, hardware or preparation closure, practical resources, a coefficient-box theorem, or retained status. The original qualified proofs, canonical replay and later publication/audit decisions remain distinct.
