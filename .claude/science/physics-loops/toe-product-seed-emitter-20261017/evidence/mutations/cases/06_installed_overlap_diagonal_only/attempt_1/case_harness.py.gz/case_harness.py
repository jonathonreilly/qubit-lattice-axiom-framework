"""Invoke exactly one accepted mutated function using the unchanged resolver."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import platform
import resource
import sys
import time
import traceback

ATTEMPT=Path(__file__).resolve().parent
case=json.loads((ATTEMPT/'CASE.json').read_text())
prelaunch=json.loads((ATTEMPT/'PRELAUNCH.json').read_text())
assert resource.getrlimit(resource.RLIMIT_CPU)==(60,60)
assert sys.dont_write_bytecode and sys.flags.optimize==0
def identity(path):
 p=Path(path);b=p.read_bytes();st=p.stat()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
         'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
for row in prelaunch['input_and_source_bindings']:
 assert identity(row['path'])==row,row['path']
assert identity(sys.executable)['sha256']==prelaunch['python_binary']['sha256']
resolver_path=Path(case['resolver_source'])
resolver_text=resolver_path.read_text()
resolver_tree=ast.parse(resolver_text)
assert len(resolver_tree.body)==1 and isinstance(resolver_tree.body[0],ast.ClassDef)
assert resolver_tree.body[0].name=='FrozenInputs'
env={'Path':Path,'json':json,'hashlib':hashlib,'resource':resource,'AUDIT_TIMEOUT_SEC':60}
# The class source and AST are unchanged. Its existing global wall-cap variable
# is supplied as60 for this process, not the canonical primary's120.
exec(compile(resolver_text,str(resolver_path),'exec'),env)
inputs=env['FrozenInputs'](case['repo'],Path(case['repo'])/'outputs/product_seed_emitter_2026_10_17_inputs/INPUT_MAP.json')
executed=ATTEMPT/'executed_helper.py'
namespace={'__name__':'copied_scientific_mutant','__file__':str(executed)}
exec(compile(executed.read_text(),str(executed),'exec'),namespace)
function=namespace[case['function']]
assert callable(function)
start=time.monotonic()
runtime={'case':case['id'],'selected_function':case['function'],'python':sys.version,
         'python_executable':sys.executable,'platform':platform.platform(),
         'sympy_distribution_version':importlib.metadata.version('sympy'),
         'mpmath_distribution_version':importlib.metadata.version('mpmath'),
         'actual_process_limits':inputs.shared_limits(),
         'thread_environment_in_prelaunch':prelaunch['thread_environment'],
         'thread_count_measured':False,'other_functions_invoked':False}
(ATTEMPT/'RUNTIME_START.json').write_text(json.dumps(runtime,indent=2)+'\n')
print(json.dumps({'case':case['id'],'function':case['function'],
                  'actual_limits':inputs.shared_limits()},indent=2),flush=True)
try:
 result=function(inputs)
except BaseException as error:
 frames=[{'filename':f.filename,'lineno':f.lineno,'name':f.name,'line':f.line}
         for f in traceback.extract_tb(error.__traceback__)]
 outcome={'exception_type':type(error).__name__,'exception_message':str(error),
          'traceback_frames':frames,'selected_function_elapsed_seconds':time.monotonic()-start,
          'actual_process_limits':inputs.shared_limits(),'resolved_input_reads':inputs.reads,
          'python':sys.version,'loaded_scientific_modules':{
              name:{'version':getattr(sys.modules[name],'__version__',None),
                    'path':getattr(sys.modules[name],'__file__',None)}
              for name in ('sympy','mpmath') if name in sys.modules}}
 (ATTEMPT/'OUTCOME.json').write_text(json.dumps(outcome,indent=2)+'\n')
 traceback.print_exc(file=sys.stderr)
 raise SystemExit(1)
else:
 (ATTEMPT/'UNEXPECTED_RETURN.json').write_text(json.dumps(result,indent=2)+'\n')
 (ATTEMPT/'OUTCOME.json').write_text(json.dumps({'exception_type':None,
     'status':'Unexpected successful return; this is not an intended scientific rejection.',
     'selected_function_elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
 raise SystemExit(2)
