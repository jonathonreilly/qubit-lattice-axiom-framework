"""Verify preserved mutation receipts and freeze the report; no science replay."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

D=Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(D)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def external_pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,x):
 with p.open('x') as f:f.write(json.dumps(x,indent=2)+'\n')
results=json.loads((D/'RESULTS.json').read_text())
plan=json.loads((D/'snapshots/MUTATION_PLAN.json').read_text())
assert len(results['cases'])==len(plan['cases'])==12 and results['unexpected_failures']==0
summaries=[];all_cpu=0;loaded={};total_bindings=[]
for item,case in zip(results['cases'],plan['cases']):
 assert item['case']==case['id'] and item['intended_scientific_rejection']
 receiptpath=Path(item['receipt']['path']);receipt=json.loads(receiptpath.read_text());attempt=receiptpath.parent
 assert external_pin(receiptpath)==item['receipt']
 for key in ('prelaunch','executed_source','stdout','stderr','outcome'):
  row=receipt[key];assert external_pin(row['path'])==row
 assert receipt['returncode']==1 and not receipt['timeout']
 assert receipt['intended_scientific_rejection'] and receipt['all_source_input_bytes_and_file_generations_unchanged']
 assert receipt['cpu_soft_hard_seconds']==[60,60] and receipt['external_wall_seconds']==60
 pre=json.loads((attempt/'PRELAUNCH.json').read_text());outcome=json.loads((attempt/'OUTCOME.json').read_text())
 assert pre['before_child_execution'] and pre['captured_utc']<=receipt['started_utc']
 assert pre['accepted_case']==case and pre['attempt_number']==1
 raw=(attempt/'executed_helper.py').read_text()
 original=(D/'snapshots'/(Path(case['source']).name+'.txt')).read_text()
 assert hashlib.sha256(original.encode()).hexdigest()==case['source_sha256']
 assert original.count(case['old'])==1 and raw==original.replace(case['old'],case['new'])
 functions_original={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original).body if isinstance(n,ast.FunctionDef)}
 functions_mutated={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
 assert [name for name in functions_original if functions_original[name]!=functions_mutated[name]]==[case['function']]
 frames=outcome['traceback_frames'];last=frames[-1]
 assert outcome['exception_type']=='AssertionError' and last['filename']==str(attempt/'executed_helper.py')
 assert any(f['name']==case['function'] and f['filename']==last['filename'] for f in frames)
 expected=case['expected_scientific_assertion']
 if expected.startswith('assert '):assert last['line']==expected
 else:assert outcome['exception_message']==expected and last['name'] in {'ck','require'}
 stderr=(attempt/'stderr.txt').read_text()
 assert 'Traceback (most recent call last)' in stderr and 'AssertionError' in stderr
 assert (expected in stderr) and ('File "'+last['filename']+'", line '+str(last['lineno'])) in stderr
 stdout=json.loads((attempt/'stdout.txt').read_text())
 assert stdout['case']==case['id'] and stdout['function']==case['function']
 limits=stdout['actual_limits']
 assert limits['cpu_soft_hard_seconds']==[60,60] and limits['external_wall_cap_seconds']==60
 assert outcome['actual_process_limits']==limits
 runtime=json.loads((attempt/'RUNTIME_START.json').read_text())
 loaded[case['id']]={k:runtime[k] for k in ('python','sympy_distribution_version','mpmath_distribution_version')}
 all_cpu+=receipt['child_user_cpu_seconds']+receipt['child_system_cpu_seconds']
 total_bindings.append(len(pre['input_and_source_bindings']))
 summaries.append({'case':case['id'],'selected_function':case['function'],
   'original_helper_sha256':case['source_sha256'],'executed_helper':pin(attempt/'executed_helper.py'),
   'assertion_reached':expected,'final_assertion_line':last['lineno'],
   'exception_message':outcome['exception_message'],'elapsed_seconds':receipt['elapsed_seconds'],
   'user_cpu_seconds':receipt['child_user_cpu_seconds'],'system_cpu_seconds':receipt['child_system_cpu_seconds'],
   'CPU_soft_hard_seconds':[60,60],'external_wall_seconds':60,'returncode':1,
   'scientific_assertion_rejection_confirmed':True,'receipt':pin(receiptpath),
   'prelaunch':pin(attempt/'PRELAUNCH.json'),'stdout':pin(attempt/'stdout.txt'),'stderr':pin(attempt/'stderr.txt')})
assert not list(D.rglob('attempt_2')) and not (D/'STOPPED_FOR_ROOT.json').exists()
assert results['all_canonical_bindings_unchanged']
first=json.loads((D/summaries[0]['prelaunch']['path']).read_text())
last=json.loads((D/summaries[-1]['prelaunch']['path']).read_text())
assert first['input_and_source_bindings'][:169]==last['input_and_source_bindings'][:169]
baseline=json.loads((D/'snapshots/canonical_02_EXECUTION.json').read_text())
assert baseline['status']=='ok' and baseline['cache_status']=='fresh' and baseline['exit_code']==0
qualification={
 'scope':'Post-run bookkeeping recheck only. No mutation or baseline re-executed.',
 'cases':summaries,'cases_count':12,'all_single_attempt':True,'unexpected_failures':0,
 'source_binary_input_bindings_serialized_before_every_launch':True,
 'binding_counts_per_case':total_bindings,'canonical_source_and_declared_inputs_bound_per_case':169,
 'metadata_qualification':'The unchanged FrozenInputs source retains the literal generic canonical runner_cache wall-enforcement description. These mutations used the external subprocess.run(timeout=60) enforcement in run_mutations.py, not runner_cache. Both the recorded CPU and wall limits are60. No source/output is rewritten to obscure that distinction.',
 'runtime_versions':loaded,'sum_child_user_plus_system_cpu_seconds':all_cpu,
 'sum_child_wall_seconds':sum(r['elapsed_seconds'] for r in summaries),
 'baseline':'Successful root canonical_02 only; canonical_01 is explicitly excluded. No baseline replay here.',
 'limitations':'Sensitivity of these twelve existing scientific checks, not a new independent theorem proof, interval proof from samples, native realization, practical cost, retained audit or parameter-box composition.',
 'editable_prompt_changes':[],'canonical_changes_by_this_task':[],'git_changes_by_this_task':[]}
dump(D/'FINAL_CHECK.json',qualification)
lines=['# Product-seed emitter: twelve copied-source mutation checks','',
 'All twelve approved cases reached their intended scientific `AssertionError` on their sole initial attempts. There were no timeouts, checksum/import/path/syntax/harness failures, unexpected successes or retries. The complete streams, tracebacks, executed copies and receipts are preserved. No canonical source, declared input, note, Git state, checkpoint, prompt or audit verdict was edited by this task.','',
 'Root portability acceptance SHA256 is `4442fa7f1409992d37feb8f56065e2f36ca44d83ab8d398c4fd18e0d4f2451f6`. The accepted plan SHA256 is `3f7d1924a6d8e0b5ba28eecc3cf80ba3b1c62df9ca78b7b671c46c336d5aba97`. The root completion signal arrived before any mutation was launched. The successful root `canonical_02` run, whose receipt SHA256 is `40b90d012a3358b22225955cdb77c3ac988c8550a24d09fafe6b71338d514783`, supplies the unmutated baseline. The infrastructure-failed `canonical_01` attempt is not used as a baseline. No unmutated program was replayed here.','',
 'Every case had CPU soft/hard limits of60 seconds and an external wall cap of60 seconds; these are per-case limits. The initial plan allowed at most12 attempts and720 seconds of total case wall allowance. Actual summed child wall time was '+format(qualification['sum_child_wall_seconds'],'.9f')+' seconds; summed child user plus system CPU time was '+format(all_cpu,'.6f')+' seconds. Wall timings include process startup, binding checks and imports. Per-function timings are also preserved in each `OUTCOME.json`.','',
 'Before each child launch, a real serialized `PRELAUNCH.json` bound the current primary plus168 declared inputs, original and executed source, harness, case, resolver snapshot, launcher, Python executable, package metadata, command, environment and caps. The selected source and every bound file were checked again after the child, including file-generation fields. The169 canonical source/input bindings stayed unchanged throughout all twelve cases. Neither directory ancestors nor unrelated publication records are represented as scientific inputs.','',
 'The exact canonical `FrozenInputs` class was extracted as a source slice with identical AST. Its existing global `AUDIT_TIMEOUT_SEC` was bound to60 for mutation metadata; the class itself was unchanged. Its generic wall-enforcement text still names canonical runner-cache execution. For these mutation attempts, the actual external enforcement was `subprocess.run(timeout=60)` in [run_mutations.py](run_mutations.py), with CPU limits set in the child before its harness started. The unchanged generic string is preserved and qualified here, not rewritten after execution. Only the selected calculation function was invoked.','',
 'The harness and launcher are [case_harness.py](case_harness.py) and [run_mutations.py](run_mutations.py). [FINAL_CHECK.json](FINAL_CHECK.json) gives all source/stream/receipt hashes and the exact assertions. It independently rechecks the recorded bytes, single-source replacements, AST change scope, exception type, message and final traceback location; it does not rerun the mathematics. The adapter read all twelve complete stdout/stderr streams.','',
 '| Case | Scientific assertion reached | Wall seconds | Executed source SHA256 |',
 '|---|---|---:|---|']
for r in summaries:
 lines.append('| '+r['case']+' | `'+r['assertion_reached'].replace('|','\\|')+'` | '+format(r['elapsed_seconds'],'.6f')+' | `'+r['executed_helper']['sha256']+'` |')
lines+=['','Original helper identities remain:','',
 '- Local: `c567cfeaaddff24d9f59d70e99a7d59cb324e389a10d18db04e46a173407f25e`.','- Installed: `a0394a9655d785b05ff61124400600cf9de5afa0dc998c3be5f1bdc191a7310d`.','- Weighted: `9591a45a5566d5c32501fcb007b4ecc8ae79abd9b956134761e29dbef5463669`.','',
 'The exact Python binary hash, platform and library distribution metadata were captured before launch; each child also reported its actual Python, SymPy and mpmath versions. Single-thread environment requests are recorded, but thread count was not measured. Bytecode writes were disabled. The complete baseline receipt and root finalization metadata are preserved in `snapshots/`.','',
 'These are source-exposed same-model fault-sensitivity checks of the accepted calculations. They do not add blind independence, a proof from finite samples, hardware or preparation closure, practical resources, a coefficient-box theorem, or retained status. The original qualified proofs, canonical replay and later publication/audit decisions remain distinct.','']
(D/'REPORT.md').write_text('\n'.join(lines))
files=[pin(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='FREEZE.json']
dump(D/'FREEZE.json',{'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Twelve accepted copied-source mutation attempts, complete actual evidence and final report. No retries or baseline rerun.',
 'files':files,'self_excluded':'FREEZE.json','report':pin(D/'REPORT.md'),
 'results':pin(D/'RESULTS.json'),'final_check':pin(D/'FINAL_CHECK.json')})
print(json.dumps({'report':pin(D/'REPORT.md'),'results':pin(D/'RESULTS.json'),
 'final_check':pin(D/'FINAL_CHECK.json'),'freeze':pin(D/'FREEZE.json'),
 'frozen_files':len(files),'cases':12,'total_child_wall_seconds':qualification['sum_child_wall_seconds'],
 'total_child_CPU_seconds':all_cpu,'unexpected_failures':0},indent=2))
