"""Serialize twelve accepted fault-sensitivity cases; stop on any surprise.

All writes stay under this new mutation directory. No canonical scientific
input, Git state, note, checkpoint, prompt or audit verdict is modified.
"""
from pathlib import Path
import ast
import datetime
import hashlib
import importlib.metadata
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import time

D=Path(__file__).resolve().parent
N=D.parent;W=N.parent/'correlation_worktree'
Q=W/'.claude/science/physics-loops/toe-product-seed-emitter-20261017'
B=N/'product_seed_emitter_integration/canonical_02'
assert not (D/'RUN_STARTED.json').exists(),'One initial run only; root reviews any retry.'
def digest(p):
 p=Path(p);b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def identity(p):
 p=Path(p);st=p.stat()
 return {**digest(p),'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
def dump(p,x):
 with p.open('x') as f:
  f.write(json.dumps(x,indent=2)+'\n');f.flush();os.fsync(f.fileno())
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

acceptance=Q/'ROOT_PORTABILITY_ACCEPTANCE.json'
plan_path=Q/'MUTATION_PLAN.json'
assert digest(acceptance)['sha256']=='4442fa7f1409992d37feb8f56065e2f36ca44d83ab8d398c4fd18e0d4f2451f6'
assert digest(plan_path)['sha256']=='3f7d1924a6d8e0b5ba28eecc3cf80ba3b1c62df9ca78b7b671c46c336d5aba97'
plan=json.loads(plan_path.read_text());assert len(plan['cases'])==12
baseline=json.loads((B/'EXECUTION.json').read_text())
assert baseline['status']=='ok' and baseline['exit_code']==0 and baseline['cache_status']=='fresh'
assert baseline['all_source_input_bytes_unchanged'] and baseline['runner_cache_also_checked_filesystem_generation_tokens']
for key in ('prelaunch','stdout_merged','stderr_protocol','cache','result'):
 row=baseline[key];assert digest(row['path'])==row
baseline_pre=json.loads((B/'PRELAUNCH.json').read_text())
for row in [baseline_pre['runner'],*baseline_pre['inputs']]:assert digest(row['path'])==row

snap=D/'snapshots';snap.mkdir()
for src in (acceptance,plan_path,B/'EXECUTION.json',B/'PRELAUNCH.json',N/'product_seed_emitter_integration/WRAPPER_FINALIZATION.json'):
 name=src.name if src.parent!=B else 'canonical_02_'+src.name
 shutil.copyfile(src,snap/name)
primary=W/'scripts/product_seed_emitter_2026_10_17.py'
primary_raw=primary.read_text();primary_tree=ast.parse(primary_raw)
shutil.copyfile(primary,snap/'canonical_primary.py.txt')
resolver=next(x for x in primary_tree.body if isinstance(x,ast.ClassDef) and x.name=='FrozenInputs')
resolver_text=''.join(primary_raw.splitlines(keepends=True)[resolver.lineno-1:resolver.end_lineno])
resolver_path=snap/'FrozenInputs.py.txt';resolver_path.write_text(resolver_text)
assert ast.dump(ast.parse(resolver_text).body[0],include_attributes=False)==ast.dump(resolver,include_attributes=False)
declared=next(ast.literal_eval(x.value) for x in primary_tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in x.targets))
assert len(declared)==len(set(declared))==168
canonical_paths=[primary,*[W/p for p in declared]]
initial_canonical=[identity(p) for p in canonical_paths]
for source in sorted({c['source'] for c in plan['cases']}):
 p=W/source;shutil.copyfile(p,snap/(p.name+'.txt'))
binary=Path(sys.executable).resolve()
metadata=[]
for name in ('sympy','mpmath'):
 dist=importlib.metadata.distribution(name)
 metadata.append({'distribution':name,'version':dist.version,
                  'metadata':digest(Path(dist._path)/'METADATA')})
thread_env={name:'1' for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS')}
env=os.environ.copy();env.update(thread_env);env['PYTHONDONTWRITEBYTECODE']='1'
dump(D/'RUN_STARTED.json',{'started_utc':utc(),'completion_signal':
 'Root explicitly reported canonical_02 success/cache freshness and authorized mutation execution in this turn; canonical_01 is not used as the baseline.',
 'baseline_execution':digest(B/'EXECUTION.json'),'root_acceptance':digest(acceptance),'accepted_plan':digest(plan_path),
 'launcher':digest(Path(__file__)),'harness':digest(D/'case_harness.py'),'cases':12,'initial_attempts_per_case':1,
 'per_case_CPU_soft_hard_seconds':[60,60],'per_case_external_wall_seconds':60,'aggregate_initial_wall_cap_seconds':720,
 'scientific_scope':'Fault sensitivity of approved finite calculations; no new interval/theorem proof or retained verdict.'})
results=[]
for index,case in enumerate(plan['cases'],1):
 attempt=D/'cases'/f'{index:02d}_{case["id"]}'/'attempt_1';attempt.mkdir(parents=True)
 source=W/case['source'];original=source.read_text()
 assert digest(source)['sha256']==case['source_sha256']
 assert original.count(case['old'])==1
 mutated=original.replace(case['old'],case['new'])
 original_tree=ast.parse(original);mutated_tree=ast.parse(mutated)
 original_functions={x.name:ast.dump(x,include_attributes=False) for x in original_tree.body if isinstance(x,ast.FunctionDef)}
 mutated_functions={x.name:ast.dump(x,include_attributes=False) for x in mutated_tree.body if isinstance(x,ast.FunctionDef)}
 assert original_functions.keys()==mutated_functions.keys()
 changed=[name for name in original_functions if original_functions[name]!=mutated_functions[name]]
 assert changed==[case['function']],changed
 compile(mutated,str(attempt/'executed_helper.py'),'exec')
 (attempt/'executed_helper.py').write_text(mutated)
 shutil.copyfile(D/'case_harness.py',attempt/'case_harness.py')
 run_case={**case,'repo':str(W),'resolver_source':str(resolver_path),
           'original_helper_snapshot':str(snap/(source.name+'.txt')),
           'single_function_AST_changed':changed,'canonical_helper_sha256':digest(source)['sha256']}
 dump(attempt/'CASE.json',run_case)
 binding_paths=[*canonical_paths,acceptance,plan_path,resolver_path,snap/'canonical_primary.py.txt',
                attempt/'executed_helper.py',attempt/'case_harness.py',attempt/'CASE.json',Path(__file__)]
 bindings=[identity(p) for p in binding_paths]
 assert bindings[:len(initial_canonical)]==initial_canonical,'Canonical source/input changed before case.'
 argv=[sys.executable,'-B','-u',str(attempt/'case_harness.py')]
 prelaunch={'captured_utc':utc(),'before_child_execution':True,'case_id':case['id'],
  'accepted_case':case,'expected_scientific_assertion':case['expected_scientific_assertion'],
  'selected_function':case['function'],'input_and_source_bindings':bindings,
  'primary_FrozenInputs_class':'Exact source slice and equal AST; only its global AUDIT_TIMEOUT_SEC binding is60 for mutation metadata.',
  'original_source':digest(source),'executed_source':digest(attempt/'executed_helper.py'),
  'python_binary':digest(binary),'package_metadata':metadata,'python':sys.version,'platform':platform.platform(),
  'cpu_soft_hard_seconds':[60,60],'external_wall_seconds':60,'argv':argv,'cwd':str(attempt),
  'thread_environment':thread_env,'thread_count_measured':False,'PYTHONDONTWRITEBYTECODE':'1',
  'baseline_execution':digest(B/'EXECUTION.json'),'attempt_number':1}
 dump(attempt/'PRELAUNCH.json',prelaunch)
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();started=utc()
 def limits():resource.setrlimit(resource.RLIMIT_CPU,(60,60))
 with (attempt/'stdout.txt').open('wb') as out,(attempt/'stderr.txt').open('wb') as err:
  try:
   child=subprocess.run(argv,cwd=attempt,env=env,stdout=out,stderr=err,timeout=60,preexec_fn=limits)
   code,timeout=child.returncode,False
  except subprocess.TimeoutExpired:
   code,timeout=None,True
 elapsed=time.monotonic()-start;after=resource.getrusage(resource.RUSAGE_CHILDREN)
 unchanged=all(identity(row['path'])==row for row in bindings)
 outcome_path=attempt/'OUTCOME.json'
 outcome=json.loads(outcome_path.read_text()) if outcome_path.exists() else None
 intended=False;reason='Missing structured outcome, timeout, wrong exit or changed binding.'
 if code==1 and not timeout and unchanged and outcome and outcome.get('exception_type')=='AssertionError':
  frames=outcome['traceback_frames'];last=frames[-1] if frames else {}
  selected_reached=any(f['filename']==str(attempt/'executed_helper.py') and f['name']==case['function'] for f in frames)
  assertion=case['expected_scientific_assertion']
  if assertion.startswith('assert '):
   intended=selected_reached and last.get('filename')==str(attempt/'executed_helper.py') and last.get('line')==assertion
  else:
   intended=selected_reached and last.get('filename')==str(attempt/'executed_helper.py') and outcome['exception_message']==assertion and last.get('name') in {'ck','require'}
  reason='Exact intended scientific AssertionError and traceback confirmed.' if intended else 'AssertionError did not match the intended scientific assertion/traceback.'
 receipt={'started_utc':started,'finished_utc':utc(),'case':case['id'],'attempt':1,
  'prelaunch':digest(attempt/'PRELAUNCH.json'),'executed_source':digest(attempt/'executed_helper.py'),
  'returncode':code,'timeout':timeout,'elapsed_seconds':elapsed,
  'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime,
  'cpu_soft_hard_seconds':[60,60],'external_wall_seconds':60,
  'all_source_input_bytes_and_file_generations_unchanged':unchanged,
  'stdout':digest(attempt/'stdout.txt'),'stderr':digest(attempt/'stderr.txt'),
  'outcome':digest(outcome_path) if outcome_path.exists() else None,
  'intended_scientific_rejection':intended,'classification':reason}
 dump(attempt/'EXECUTION.json',receipt)
 results.append({'case':case['id'],'expected':case['expected_scientific_assertion'],
                 'intended_scientific_rejection':intended,'elapsed_seconds':elapsed,
                 'receipt':digest(attempt/'EXECUTION.json'),'outcome':outcome})
 print(json.dumps({'case':case['id'],'intended_scientific_rejection':intended,'elapsed_seconds':elapsed,'classification':reason}),flush=True)
 if not intended:
  dump(D/'STOPPED_FOR_ROOT.json',{'case':case['id'],'reason':reason,'results':results,
                                'remaining_cases_not_executed':12-len(results)})
  raise SystemExit(1)
dump(D/'RESULTS.json',{'status':'All twelve intended scientific assertions rejected their copied-source faults.',
 'cases':results,'executed_cases':len(results),'unexpected_failures':0,'baseline_replayed_here':False,
 'baseline_execution':digest(B/'EXECUTION.json'),'all_canonical_bindings_unchanged':all(identity(r['path'])==r for r in initial_canonical),
 'total_child_wall_seconds':sum(r['elapsed_seconds'] for r in results),
 'per_case_CPU_soft_hard_seconds':[60,60],'per_case_external_wall_seconds':60,
 'claim_limit':'These are sensitivity checks of existing calculations, not independent theorem/interval proofs or audit verdicts.'})
