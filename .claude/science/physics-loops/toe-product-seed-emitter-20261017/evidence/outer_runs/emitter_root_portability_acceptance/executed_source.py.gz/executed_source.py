"""Bind root's completed source review and the unchanged preparation packet."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess

D = Path(__file__).resolve().parent
N = D.parent
W = N.parent / 'correlation_worktree'
Q = W / '.claude/science/physics-loops/toe-product-seed-emitter-20261017'
F = W / 'outputs/product_seed_emitter_2026_10_17_inputs'
assert not (Q / 'ROOT_PORTABILITY_ACCEPTANCE.json').exists()

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

ready = json.loads((D / 'READY_FOR_PORTABILITY_REVIEW.json').read_text())
for row in ready['files']:
    actual = pin(W / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
assert len(ready['files']) == 221
freeze = json.loads((Q / 'PORTABILITY_FREEZE.json').read_text())
assert len(freeze['files']) == 220
for row in freeze['files']:
    actual = pin(W / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
primary = W / ready['primary']['path']
tree = ast.parse(primary.read_text())
declared = next(ast.literal_eval(x.value) for x in tree.body if isinstance(x, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'AUDIT_INPUT_PATHS' for t in x.targets))
assert len(declared) == len(set(declared)) == 168
pre = json.loads((Q / 'PRE_EXECUTION_IDENTITIES.json').read_text())
assert set(declared) == {r['path'] for r in pre['inputs']}
for row in pre['inputs']:
    actual = pin(W / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
report = json.loads((Q / 'STATIC_CHECKS.json').read_text())
counts = report['AST_roundtrip']
assert sum(x['unchanged'] + x['adapted'] for x in counts.values()) == 868
assert sum(x['removed_transport_only'] for x in counts.values()) == 25
assert sum(x['adaptation_events'] for x in counts.values()) == 21
assert sum(x['preserved_assert_ASTs'] for x in counts.values()) == 201
assert report['scientific_functions_executed'] == report['mutations_executed'] == 0
assert not (W / 'outputs/product_seed_emitter_2026_10_17.json').exists()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=W).strip()
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=W, text=True).strip() == 'physics-loop/toe-product-seed-emitter-20261017'

record = {
    'reviewed_utc': datetime.now(timezone.utc).isoformat(),
    'disposition': 'Canonical portability accepted for the declared bounded execution and copied-source science mutation plan. No canonical execution or publication result is claimed by this decision.',
    'root_coverage': [
        'Complete previously qualified local, installed and weighted proof/program/report bodies reused at their recorded identities; full new draft lead, plan, inventory and three exact embedded proof bodies already reviewed.',
        'Complete changed wrapper diff from the qualified draft; complete executable primary body, helper setup and final status-neutral docstrings. The long168-path declaration was verified as a literal unique inventory, not treated as mathematical prose.',
        'Every one of25 actual removed statements and21 adaptation events inspected. Complete330-line static verifier and its exact latest delta inspected: reverse transforms restore868 source statements, including201 Assert ASTs; removed operations are transport/resource only.',
        'Complete pre-run plan, twelve mutation anchors/expected assertions, portability report, source manifest, preparation failures and actual static execution receipts. All221 prepared files,220 freeze members and168 declared input identities checked against current bytes.'
    ],
    'binding': {'readiness': pin(D / 'READY_FOR_PORTABILITY_REVIEW.json'), 'preparation_freeze': pin(Q / 'PORTABILITY_FREEZE.json'), 'source_manifest': pin(Q / 'SOURCE_MANIFEST.json'), 'static_checker': pin(D / 'verify_adaptation.py'), 'static_result': pin(Q / 'STATIC_CHECKS.json'), 'static_receipt': pin(Q / 'portability_evidence/static_verify_attempt_2/RECEIPT.json'), 'primary': pin(primary), 'helpers': [pin(W / r['path']) for r in ready['helpers']], 'note': pin(W / ready['note']['path']), 'mutation_plan': pin(Q / 'MUTATION_PLAN.json')},
    'portability_judgments': [
        'Historical absolute paths are finite lookup keys only; every actual file read is confined to declared local regular-file bytes with checked hash/size. There is no live renewal-directory fallback.',
        'Original function order, exact coefficients, matrix dimensions, precision, twelve installed point diagnostics, inequalities and mathematical helper calls survive. No global/nonlocal or unhandled ROOT/__file__ reference remains in adapted functions.',
        'Original per-program CPU setters and output writes/CLI are removed in favor of one primary CPU120/wall120 process and returned reports. Original caps and self hashes are explicitly historical; actual limits and input hashes are separate.',
        'New guards compare existing exact returned budgets and fixed diagnostic counts. They do not replace a mathematical proof or turn point diagnostics into an interval certificate.',
        'Root requested only status-neutral module documentation. Historical pending labels and reports remain unchanged; current publication status must be recorded separately after execution.'
    ],
    'execution_requirements': {'canonical_attempt': 'One initial combined six-body run under CPU120/wall120 through runner_cache.execute_and_write_cache, with real serialized prelaunch source/input bindings and preserved complete streams.', 'mutations': 'Twelve planned copied-source cases, each CPU60/wall60, at most one initial attempt per case. Only intended scientific assertion failures count; all harness/timeout failures remain failures.', 'before_publication': 'Inspect complete scientific result and exact comparison to frozen outputs; finish focused packet and wrapper review, graph delta and family-value evaluation. A later note/input edit requires preserved old receipt and actual fresh execution.'},
    'scope_limits': 'Same-model source-exposed portability review; the source adapter authored/reviewed earlier work. This does not add independent mathematical evidence, native realization, practical cost, calibration/structural composition, retained status, integrated-main landing permission or merge authorization.',
    'canonical_execution_performed_by_this_recorder': False,
    'editable_prompt_changes': [],
    'source_science_changes': [],
}
(Q / 'ROOT_PORTABILITY_ACCEPTANCE.json').write_text(json.dumps(record, indent=2) + '\n')
(D / 'ROOT_PORTABILITY_ACCEPTANCE.json').write_bytes((Q / 'ROOT_PORTABILITY_ACCEPTANCE.json').read_bytes())
print(json.dumps({'root_acceptance': pin(Q / 'ROOT_PORTABILITY_ACCEPTANCE.json'), 'prepared_files_verified': 221, 'declared_inputs_verified': 168}, indent=2))
