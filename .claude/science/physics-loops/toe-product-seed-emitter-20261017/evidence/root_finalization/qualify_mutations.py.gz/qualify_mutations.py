"""Root record and lossless archival of already completed mutation evidence."""
from pathlib import Path
import ast
import datetime
import gzip
import hashlib
import json

D=Path(__file__).resolve().parent
N=D.parent
W=N.parent/'correlation_worktree'
Q=W/'.claude/science/physics-loops/toe-product-seed-emitter-20261017'
M=N/'product_seed_emitter_mutations'
def digest(p):
    b=Path(p).read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,x):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2)+'\n')
freeze=json.loads((M/'FREEZE.json').read_text())
assert digest(M/'FREEZE.json')['sha256']=='2d20d28a9d705485e2e8309b6fa487f95274b6bdd47ec204e0f22a73553b3b15'
assert len(freeze['files'])==126
for row in freeze['files']:
    assert digest(M/row['path'])=={k:row[k] for k in ('bytes','sha256')},row['path']
assert {str(p.relative_to(M)) for p in M.rglob('*') if p.is_file()}=={r['path'] for r in freeze['files']}|{'FREEZE.json'}
plan=json.loads((M/'snapshots/MUTATION_PLAN.json').read_text())
assert (M/'snapshots/MUTATION_PLAN.json').read_bytes()==(Q/'MUTATION_PLAN.json').read_bytes()
results=json.loads((M/'RESULTS.json').read_text())
assert results['executed_cases']==12 and results['unexpected_failures']==0
assert results['all_canonical_bindings_unchanged'] and not results['baseline_replayed_here']
assert digest(results['baseline_execution']['path'])=={k:results['baseline_execution'][k] for k in ('bytes','sha256')}
canonical=json.loads((D/'canonical_02/EXECUTION.json').read_text())
assert canonical['status']=='ok' and canonical['cache_status']=='fresh'
cases=[]
for i,(case,item) in enumerate(zip(plan['cases'],results['cases']),1):
    folder=M/'cases'/f'{i:02d}_{case["id"]}'/'attempt_1'
    pre=json.loads((folder/'PRELAUNCH.json').read_text())
    receipt=json.loads((folder/'EXECUTION.json').read_text())
    outcome=json.loads((folder/'OUTCOME.json').read_text())
    assert item['case']==case['id']==receipt['case']==pre['case_id']
    assert pre['captured_utc']<=receipt['started_utc'] and pre['before_child_execution']
    assert receipt['returncode']==1 and not receipt['timeout'] and receipt['intended_scientific_rejection']
    assert receipt['all_source_input_bytes_and_file_generations_unchanged']
    assert receipt['cpu_soft_hard_seconds']==[60,60] and receipt['external_wall_seconds']==60
    for key in ('prelaunch','executed_source','stdout','stderr','outcome'):
        assert digest(receipt[key]['path'])=={k:receipt[key][k] for k in ('bytes','sha256')}
    for row in pre['input_and_source_bindings']:
        assert digest(row['path'])=={k:row[k] for k in ('bytes','sha256')},row['path']
    assert digest(pre['python_binary']['path'])=={k:pre['python_binary'][k] for k in ('bytes','sha256')}
    for row in pre['package_metadata']:
        assert digest(row['metadata']['path'])=={k:row['metadata'][k] for k in ('bytes','sha256')}
    original=(W/case['source']).read_text();executed=(folder/'executed_helper.py').read_text()
    assert hashlib.sha256(original.encode()).hexdigest()==case['source_sha256']
    assert original.count(case['old'])==1 and executed==original.replace(case['old'],case['new'])
    def functions(raw):return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef)}
    old,new=functions(original),functions(executed)
    assert old.keys()==new.keys() and [k for k in old if old[k]!=new[k]]==[case['function']]
    assert outcome['exception_type']=='AssertionError'
    last=outcome['traceback_frames'][-1];expected=case['expected_scientific_assertion']
    assert last['filename']==str(folder/'executed_helper.py')
    assert any(f['name']==case['function'] for f in outcome['traceback_frames'])
    assert last['line']==expected if expected.startswith('assert ') else outcome['exception_message']==expected
    assert expected in (folder/'stderr.txt').read_text()
    stdout=json.loads((folder/'stdout.txt').read_text())
    assert stdout['case']==case['id'] and stdout['actual_limits']['cpu_soft_hard_seconds']==[60,60]
    cases.append({'case':case['id'],'scientific_assertion':expected,'elapsed_seconds':receipt['elapsed_seconds'],
                  'receipt':{'path':str(folder/'EXECUTION.json'),**digest(folder/'EXECUTION.json')}})
assert len(cases)==12
rows=[]
for p in sorted(M.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(M);raw=p.read_bytes()
    compressed=p.suffix!='.json'
    dest=Q/'evidence/mutations'/str(rel)
    if compressed:dest=dest.with_name(dest.name+'.gz')
    dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
    dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
    assert (gzip.decompress(dest.read_bytes()) if compressed else dest.read_bytes())==raw
    rows.append({'original_path':str(p),'path':str(dest.relative_to(W)),
                 'compression':'gzip' if compressed else 'none','raw_bytes':len(raw),
                 'raw_sha256':hashlib.sha256(raw).hexdigest(),**digest(dest)})
evidence={'scope':'Lossless complete mutation packet; historical paths remain evidence identities, not live runner dependencies.','files':rows}
write(Q/'evidence/MUTATION_EVIDENCE_MAP.json',evidence)
record={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':'Root source/traceback/binding check of existing fault-sensitivity evidence, not a new mathematical proof or retained audit.',
        'reviewed_completely':['mutation plan reused by exact identity','report','case harness','launcher','post-run bookkeeping verifier','all twelve complete stdout/stderr streams','all twelve exact source deltas and assertion locations'],
        'freeze':digest(M/'FREEZE.json'),'frozen_files_verified':126,'archived_files':len(rows),
        'cases':cases,'all_initial_attempts':True,'unexpected_failures':0,
        'current_bytes_verified_for_every_prelaunch_binding':True,
        'historical_generation_stability':'Reported by executed launcher; root checked the launcher and preserved receipts, not a retroactive observation of execution.',
        'successful_baseline':{'path':str(D/'canonical_02/EXECUTION.json'),**digest(D/'canonical_02/EXECUTION.json')},
        'total_child_wall_seconds':results['total_child_wall_seconds'],
        'metadata_limit':'FrozenInputs retains its generic canonical-runner wall-enforcement string. The mutation launcher actually enforces subprocess timeout=60 and child CPU60; both numeric recorded caps are60.',
        'evidence_map':digest(Q/'evidence/MUTATION_EVIDENCE_MAP.json'),
        'scientific_limit':'Twelve copied-source fault checks only; source-exposed same-model execution. Canonical payload replay and inherited analytic/independent theorem evidence remain distinct.',
        'editable_prompt_changes':[]}
write(D/'ROOT_MUTATION_REVIEW.json',record);write(Q/'ROOT_MUTATION_REVIEW.json',record)
print(json.dumps({'cases':len(cases),'archive_files':len(rows),'total_child_wall_seconds':results['total_child_wall_seconds'],'review':digest(D/'ROOT_MUTATION_REVIEW.json')},indent=2))
