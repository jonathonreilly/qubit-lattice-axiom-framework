---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Exact memory and coherent transfer of the effective dressing state

2026-10-11. External author derivation for the supplied excluded Weyl walk.

The dressing amplitude obeys an exact scalar Volterra equation. Its kernel
and resolvent are explicit torus integrals. For every fixed nonzero kappa,
the continuum dressing spectral measure is absolutely continuous, so the
amplitude tends to zero and the transverse probability tends to one.
The proof uses a quantitative cone-region lower bound on the bath measure
and a separate endpoint argument. It introduces no Markov approximation,
reset, stochastic bath or decoherence premise.

This is a result for the bounded effective generator on the entire physical
zero space, starting from its normalized dressing vector. It does not give
a decay rate, a limit of the weighted canonical current, a growing-time
error estimate for the original walk, or a result for arbitrary free-band
preparations. In particular, the two limits in the last section have a
specified order. The finite bath counterexample below is preserved.

## 1. Exact source boundary and conventions

Let S be `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and W be its sibling `worktree`. The direct sources are:

| Source | SHA-256; coverage |
|---|---|
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`; all 549 lines read, especially D1–D8 and D15–D24 |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2`; all 375 lines read |
| `excluded_walk_degenerate/receipt.json` | `369bebc245e0e7794608d6a1ef29a4ccd3d374a85f3f3bcc20f0f2dd81288dde`; parsed identities rechecked |
| `excluded_walk_degenerate_review/independent_review_receipt.json` | `c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa`; parsed identities rechecked |

The unchanged source chain includes the long-time note `09998aec...`,
canonical-current note `79bc9fb3...`, threshold chart `8bc423b2...`, and
M6 walk contract `e0536f80...`; complete earlier readings are reused after
identity checks. The supplied walk, pair Hilbert space, exclusion rule,
coordinates, clock and canonical energy placement remain premises. The
independent review of the parent result does not review this new proof.

Inner products are linear in their second slot. All q integrals use
`dmu(q)=dq/(2pi)^3` on the periodic three-torus. Write

    s_j=sin q_j,  epsilon=|s|,  n=s/epsilon,
    I0=integral 1/(4epsilon^2),
    zeta=n/(2epsilon sqrt(I0)).                              (E1)

Cone points form a null set. The parent proves `0<I0<infinity`, the useful
bounds `1/12<=I0<=9/8`, and `||zeta||=1`. The physical zero space is
`Z=F direct-sum span{zeta}`, where F consists of odd transverse triplet
fields `u(q)` satisfying `n·u=0`. The auxiliary constant singlet is absent.

Fix kappa in R^3, put `b=|kappa|`, and define

    d_j=kappa_j cos q_j,     f=d·n,
    J u=i n cross u,        D=f J,
    g=i(d cross n)/(2epsilon sqrt(I0)),
    G=|g|^2=(|d|^2-f^2)/(4epsilon^2 I0),
    A=[ D       g ],
      [ <g|     0 ].                                       (E2)

All these operators have the domains specified in the parent: D is bounded
self-adjoint on F, `g in F`, and `A=Pi B Pi` on Z, where
`B u=i d cross u` and `||A||<=||B||<=b`. Both pointwise factors in D
change sign under q to -q, so D preserves the odd parity; g is odd.
No inverse of a gapless Hamiltonian or derivative of zeta is used.

The new theorem concerns

    exp(-it A)zeta=(u(t),a(t)),   u(0)=0, a(0)=1.            (E3)

When `kappa=0`, A is zero, `a(t)=1`, and no transfer occurs. Every decay
statement below explicitly assumes `b>0`.

## 2. Elimination of the transverse field

On a transverse fiber, `J*=J`, `J^2=I`, and `D^2=f^2 I`.
Since g is i times a real vector, `g*Jg=0` pointwise. Consequently

    <g,exp(-it D)g>=K(t),
    K(t)=integral G(q) cos(t f(q)) dmu(q).                  (E4)

Here and below a bra without a point argument denotes the Hilbert-space
inner product; pointwise equalities are identified explicitly. To check
E4, use `exp(-itD)=cos(tf)I-i sin(tf)J`. This also handles `f=0`
without a division. The kernel is continuous, real and even, and
`|K(t)|<=eta:=||g||^2`. It need not be positive at every time.

The exact block equations and bounded variation of constants give

    i u'=Du+a g,   i a'=<g,u>,
    u(t)=-i integral_0^t exp[-i(t-s)D]g a(s) ds,
    a'(t)=-integral_0^t K(t-s)a(s) ds,  a(0)=1.             (E5)

The minus sign is fixed by the two factors of -i. All integrals are
Bochner or ordinary integrals of bounded continuous functions. Iteration
of the integrated equation bounds the n-th uniqueness remainder on
`[0,T]` by a constant times `eta^n T^(2n)/(2n)!`; hence E5 determines
a uniquely. Real coefficients and real initial data make a real for
positive times. Unitarity gives `a(-t)=conj(a(t))`, so a is real and even.
Unitarity also supplies the exact transfer identity

    P_F(t):=||u(t)||^2=1-a(t)^2.                            (E6)

For example, the parent bound on `||epsilon g||^2` and `epsilon^2<=3`
give `2b^2/81<=eta<=b^2` for b>0. The upper bound follows also from
`||A zeta||<=b`. A useful finite-time consequence is

    eta t^2/2 <= P_F(t) <= eta t^2,
    P_F(t)>=b^2 t^2/81,       whenever |bt|<=1.             (E7)

For a direct proof, let nu be the probability spectral measure of A at
zeta. It is supported in `[-b,b]`, and real a gives
`a(t)=integral cos(tE) dnu(E)`. Its second moment is eta and its fourth
moment is

    mu4=||A^2 zeta||^2=||Dg||^2+eta^2<=b^2 eta.

The elementary cosine remainders imply
`a>=1-eta t^2/2>=1/2` and
`eta t^2/2-mu4 t^4/24<=1-a<=eta t^2/2` on E7's interval.
Thus `1-a>=11 eta t^2/24`, while `1+a>=3/2`; their product is at
least `11 eta t^2/16`, which is stronger than the displayed lower bound.
The upper bound uses `1+a<=2`. This is coherent transfer, not a rate law.

## 3. Scalar resolvent and Laplace transform

Define the finite positive bath measure beta by

    beta(L)=1/2 integral G(q)[1_L(f(q))+1_L(-f(q))] dmu(q).
                                                                  (E8)

Its mass is eta, its support lies in `[-b,b]`, and it is symmetric.
The factor 1/2 follows from the two helicity projections `(I+/-J)/2`:
each has pointwise g weight G/2. It is not a probability normalization.
For `Im z != 0`, block elimination in `(z-A)(v,alpha)=(0,1)` proves

    Sigma(z)=<g,(z-D)^(-1)g>
            =integral z G/(z^2-f^2) dmu
            =integral (z-E)^(-1) dbeta(E),
    M(z):=<zeta,(z-A)^(-1)zeta>
            =1/[z-Sigma(z)].                               (E9)

In the upper half-plane, `Im Sigma(z)<=0`, so the denominator has
strictly positive imaginary part. This verifies its nonvanishing with
the displayed resolvent convention. Fubini in E5, or `i M(ip)`, gives

    integral_0^infinity exp(-pt)a(t)dt
       =1/[p+integral pG/(p^2+f^2) dmu],   Re p>0.          (E10)

The formula is exact for the bounded generator. Replacing its denominator
by a constant damping coefficient is an additional approximation that
is not made here.

There is also an exact formula for the produced field's q distribution.
Let `C_q(t)=integral_0^t cos[f(q)(t-s)]a(s)ds` and define `S_q` by
replacing cosine with sine. E5 gives

    u(q,t)=-i C_q(t)g(q)-S_q(t)J(q)g(q),
    |u(q,t)|^2=G(q)[C_q(t)^2+S_q(t)^2]
       =G(q)|integral_0^t exp[-if(q)s]a(s)ds|^2.            (E11)

The cross term vanishes because `g*Jg=0`; a is real. In particular,
`P_F` is the integral of E11, while the weighted quantity in the actual
diagonal-kappa current is

    W(t)=||epsilon u(t)||^2
        =integral epsilon^2 G |integral_0^t exp(-ifs)a(s)ds|^2 dmu.
                                                                  (E12)

For `kappa=k(1,1,1)`, the checked parent identity remains
`<exp(-itA)zeta,calJ_a exp(-itA)zeta>=1-(2/3)W(t)`.
E6 and E12 are different observables. Decay of a alone does not supply
a limit of W or a limiting canonical current.

## 4. A quantitative continuum bath lower bound

Assume b>0. For `0<delta<b` set

    chi=delta/b,       r0=sqrt(chi)/8,
    c_delta=b chi^(3/2)/(16384 pi^2 I0).                    (E13)

Then, as a measure inequality,

    dbeta(E) >= c_delta 1_{|E|<=b-delta/2} dE.             (E14)

This inequality does not assert that beta has no additional singular
part. The lower bound is all that the subsequent proof needs. It is
uniform in the direction of kappa, with the literal normalized torus
measure. The proof uses only a small shell about q=0.

Write `q=r omega`, where omega is on the unit sphere, `0<r<=1/2`,
and `e=kappa/b`. Define

    X(r,omega)=sin(2r omega)/(2r),
    Y(r,omega)=sin(r omega)/r,   h=|Y|,
    v=X/h,    n=Y/h,    f/b=e·v.

Componentwise sine bounds give

    ||X-omega||<=2r^2/3,  ||Y-omega||<=r^2/6,
    1-r^2/6<=h<=1,       ||v-omega||<=r^2,
    ||n-omega||<=r^2/2.                                  (E15)

For a tangent vector H at omega, differentiate the explicit expressions.
One has `||dX[H]-H||<=2r^2||H||`,
`||dY[H]-H||<=r^2||H||/2`, and

    |dh[H]|<=2r^2||H||/(3h),
    ||dv[H]-H||
      <=r^2[13/(6h)+2/(3h^3)]||H||<=4r^2||H||.           (E16)

For the first line, use `omega·H=0`, `||dY[H]||<=||H||`, and
`Y·dY[H]=(Y-omega)·dY[H]+omega·(dY[H]-H)`.
For the second, differentiate X/h and use `||X||<=1`.
Since `h>=23/24`, the final numerical constant is strictly below 4.
Also `||d/b-e||<=r^2/2`, so

    ||(d/b) cross n-e cross omega||<=r^2.                 (E17)

Choose any oriented orthonormal completion of e and parameterize the
sphere by `t=e·omega` and azimuth phi. This is only a change of integration
coordinates; lattice rotational symmetry is not assumed. Here
`|partial_t omega|=(1-t^2)^(-1/2)` and the volume element is
`r^2 dr dt dphi`. Restrict to

    r0/2<=r<=r0,
    -1+chi/4<=t<=1-chi/4,    0<=phi<2pi.

E15–E17 imply on this set

    |f/b-t|<=r^2<=chi/64,
    |partial_t(f/b)-1|<=4r^2/sqrt(1-t^2)<=sqrt(chi)/8,
    7b/8<=partial_t f<=9b/8<2b,
    |d cross n|>=b[sqrt(chi)/2-r^2]>=b sqrt(chi)/4.
                                                                  (E18)

At the two t endpoints, the range of f contains
`[-b+delta/2,b-delta/2]`, since `chi/4+chi/64<chi/2`.
For each r,phi the map t to f is strictly increasing. Moreover
`epsilon<=r`, so `G>=b^2 chi/(64 I0 r^2)` on this shell.
Changing the t variable to E in just the positive-f term of E8 gives,
for each Borel set L in that interval,

    beta(L)>= (1/2)(1/(2pi)^3)
       integral_(r0/2)^r0 integral_0^(2pi)
          [b^2 chi/(64 I0 r^2)] [r^2/(2b)] |L| dphi dr
       = b chi r0 |L|/(2048 pi^2 I0)=c_delta |L|.          (E19)

Only one helicity contribution is used, so no doubling is hidden. The
other term is nonnegative. This proves E14, including every power of r,
b, chi, I0 and the torus normalization.

## 5. Absolute continuity of the dressing spectral measure

Let nu be as in Section 2, so `M(z)=integral (z-E)^(-1)dnu(E)`.
For `|x|<=b-delta` and `0<y<=delta/2`, E14 supplies

    -Im Sigma(x+iy)
      >=c_delta integral_(x-delta/2)^(x+delta/2)
                        y/[(x-E)^2+y^2] dE
      =2c_delta arctan[delta/(2y)]>=pi c_delta/2.

Consequently

    |M(x+iy)|<=C_delta:=2/(pi c_delta)
          =32768 pi I0/[b chi^(3/2)].                     (E20)

This is a bound throughout the indicated upper-half-plane strip, not
merely an almost-everywhere boundary value. It controls singular measure:

    nu([x-y,x+y])<=2y[-Im M(x+iy)]<=2 C_delta y.           (E21)

The first inequality follows by integrating the Poisson kernel, which
is at least `1/(2y)` on that interval. Interval covers and outer regularity
now give absolute continuity of nu on `(-b,b)`, with density at most
C_delta almost everywhere on `[-b+delta,b-delta]`. Indeed every interval
inside that compact interval with length at most delta has nu mass at
most C_delta times its length, by E21 at its midpoint. Subdivision extends
the same bound to longer contained intervals. Countable interval covers
then give domination by C_delta times Lebesgue measure on its interior;
its two endpoints have zero mass by E21 as y tends to zero. Exhausting
`(-b,b)` proves the assertion. Thus no interior atom or singular-continuous
part of the dressing measure is left untreated.

Its only remaining possible singular support is `{−b,b}`. The source's
compression structure excludes both endpoint atoms without an endpoint
integral estimate. For nonzero kappa,

    |d(q)|^2=sum_j kappa_j^2 cos^2(q_j)<b^2

almost everywhere: equality requires `sin q_j=0` for every nonzero
kappa_j, a null set. For any nonzero physical zero-space vector z,
viewed as its triplet field,

    ||A z||<=||B z||
       <=(integral |d(q)|^2|z(q)|^2 dmu)^(1/2)<b||z||.     (E22)

An eigenvector of A at either endpoint would contradict E22. A spectral
atom there would provide such an eigenvector through the spectral
projection. Since the spectrum is contained in `[-b,b]`, nu is therefore
entirely absolutely continuous:

    dnu(E)=rho(E)dE,  rho>=0,  integral rho=1,
    supp rho subset [-b,b].                               (E23)

Strict inequality for each vector in E22 is not an operator-norm gap.
No such gap was used. Nor does this argument classify the entire spectrum
on every reducing subspace of Z: E23 concerns the dressing spectral
measure and its cyclic subspace.

The elementary Fourier consequence can be proved here without a limiting
absorption or scattering theorem. Approximate rho in L1 by finite linear
combinations of interval indicators. The integral of `exp(-itE)` over
each fixed interval tends to zero; the L1 approximation error bounds the
Fourier error uniformly in t. Thus

    a(t)=integral exp(-itE)rho(E)dE ->0 as |t|->infinity,
    P_F(t)->1.                                             (E24)

The same argument applies to `E^j rho(E)`, for each nonnegative integer
j, so every derivative of a tends to zero. No monotonicity, exponential
law, relaxation of the full state, or incoherent mixture follows.

## 6. A finite-horizon bound with an explicit spectral edge term

The proof gives a quantitative mean-transfer bound even before a pointwise
Fourier rate is available. For `0<delta<b`, define directly from E9

    e_delta=min{1, 4delta[-Im M(b+i delta)]},
    H_delta(T)={2C_delta[1+log(2bT)]/T}^(1/2),
    T>=1/(2b).                                            (E25)

Then

    (1/T) integral_0^T P_F(t)dt
      >=max{0,1-[e_delta+H_delta(T)]^2}.                   (E26)

To prove the edge estimate, apply the first inequality in E21 at x=b,
y=delta, without using its second inequality. The upper edge mass is
at most `2delta[-Im M(b+i delta)]`. E9 implies
`M(-conj z)=-conj M(z)`, so the lower edge has the same bound. Hence
`nu({|E|>b-delta})<=e_delta`. Endpoint absence and dominated convergence
also give `e_delta->0`: the relevant integrand is
`delta^2/[(b-E)^2+delta^2]`, which tends to the endpoint indicator.

Split a into the Fourier transforms of the central and edge restrictions
of nu. The latter has absolute value at most e_delta. For the former,
the density bound C_delta and

    |(1/T) integral_0^T exp[-it(E-E')]dt|
                  <=min{1,2/[T|E-E'|]}

alone would give a slightly weaker constant. The squared modulus has an
even difference measure: swapping E,E' cancels the imaginary terms, leaving
`sin[T(E-E')]/[T(E-E')]`, whose absolute value is at most
`min{1,1/[T|E-E'|]}`. Integrating this bound against a density bounded
by C_delta, over differences of absolute value at most 2b, yields

    (1/T) integral_0^T |a_central(t)|^2 dt
           <=2C_delta[1+log(2bT)]/T.

Minkowski's inequality in normalized `L2([0,T])` proves E26. The cancellation
does not require a pointwise positivity claim for sinc or symmetry of the
central measure itself.

All quantities in E25 are explicit in the torus resolvent formula and
E13. C_delta has inverse-frequency units, T has inverse-frequency units,
and e_delta is dimensionless. The bound is conservative and may initially
be zero. First choosing delta small and then T large makes its right side
arbitrarily close to one. This does not supply a simple power or exponential
rate in T: no quantitative bound on e_delta as delta tends to zero is
proved. An unvalidated numerical torus integral is not a certified value
for that remaining term.

## 7. A finite bath that does not decay

The block algebra and memory identity do not imply E24 for an arbitrary
bath. In two transverse dimensions let

    D=[0,-i f; i f,0],   g=(i h,0)^T,
    A=[ 0   -i f   i h ],
      [ i f   0     0  ],
      [-i h   0     0  ].                                 (E27)

For `f=3/5,h=4/5`, direct multiplication gives `A^3=A`.
The exact exponential `I-i sin(t)A+[cos(t)-1]A^2` therefore gives

    K(t)=(16/25)cos(3t/5),
    a(t)=(9+16cos t)/25,
    nu({0})=9/25,     a(2pi n)=1.                         (E28)

The scalar resolvent and Volterra equation remain exactly correct. The
continuum lower bound E14 fails for this finite bath, so the example does
not contradict E24. It rules out deriving irreversible transfer from the
block form alone, and shows why taking an infinite-time limit on a fixed
finite momentum grid would be invalid evidence for this continuum theorem.

## 8. Relation to the original walk and remaining obligations

For the fixed dressing vector and each fixed compact interval of t, the
checked parent theorem proves strong convergence of
`U_lambda(t)=exp[-it H_D(lambda kappa)/lambda]` to `exp(-itA)` as
lambda tends to zero. Since F is bounded, E24 implies the ordered limit

    lim_(t->infinity) lim_(lambda->0) ||F U_lambda(t)zeta||^2=1.
                                                                  (E29)

This is not a joint-limit bound or a large-time theorem at a fixed nonzero
lambda. The parent source explicitly exhibits failure of uniform state
convergence over the zero-space unit ball; its vector-dependent compact-time
bound supplies no automatic interchange with the new infinite-time limit.

The open interfaces are specific:

1. Quantify the spectral edge term in E25 or establish enough regularity
   of rho for an explicit pointwise Fourier decay rate. The current proof
   establishes absolute continuity, not such a rate.
2. Control W(t) and the dressing/transverse contributions to the actual
   canonical current at long effective times. E11–E12 are exact starting
   formulas, but unweighted transfer E24 alone is insufficient.
3. Obtain a quantitative low-spectral-mass estimate in the parent's
   cutoff proof, sufficient for a chosen growing rescaled-time regime.
4. Relate this dressing preparation to the lambda-dependent states from
   arbitrary projected positive free-band packets, including their
   dispersive components and observable cross terms.

Failed or unused routes are retained: dropping g freezes the dressing
artificially; a zero-frequency damping substitution changes E5; finite
bath recurrence cannot establish continuum decay; positivity of a bath
density only almost everywhere would not by itself exclude singular
dressing measure; excluding endpoint atoms needs E22 separately; and
unweighted probability does not determine the epsilon-weighted current.
The successful argument uses the stronger uniform local Poisson bound
E20 and does not assume absence of an eigenstate in advance.

## 9. Evidence, status and recovery

The new deterministic support is in `effective_memory/`. It imports no
parent runner. Exact symbolic matrix inversion checks E9 against a direct
three-by-three inverse and an unrelated two-frequency five-by-five inverse.
An actual matrix exponential, its differential equation and symbolic
convolution check E5 and the finite recurrence E28. Direct matrix powers
check the convolution moment recurrence through order twelve. Fresh
floating quadratures of the eliminated field are compared with full
matrix evolution. They are finite controls, not continuum limits.

The cone proof's rational inequalities and single-helicity Jacobian
constant are checked symbolically. A separately implemented direct
q-gradient and spherical determinant test the geometry for axis, diagonal
and oblique kappa. These samples do not replace E15–E19's uniform proof.
An unrelated atomic spectral measure checks the Poisson interval inequality.
There is no torus-grid inference of absolute continuity or long-time decay.

The main baseline completed 19 controls. A separate three-check helper
derives the finite-horizon integration constant and compares the mean
bound against an unrelated continuous uniform spectral measure, using its
exact sinc Fourier transform. Six actual source-copy defects test the
Schur sign, Volterra sign, finite-bath atom, helicity half, Poisson factor
two and mean-integral factor two. Every mutant exited 1 at its intended
assertion; every full failure log was read. Both unmutated helpers exited
zero on their first executions. Complete logs, literal sources, commands,
runtime, timeout and source identities are bound by `effective_memory/receipt.json`.
The packet records actual failed attempts if any; check counts are not a
scientific verdict. No Lean verification of this new analytic theorem or
independent review of its final argument is claimed.

The research-lane skill and source workflow were read from the locally
available main revision `a13caa4885f547c8d206265b031ba7649e539fd9`; the
planning instructions were read at `3a4b2c66a1ead7a1c48b4359627e968f681e3c39`.
No remote freshness check or global novelty claim is made. The worktree
head was `31aacf9b83d7992674867e351b68404c18c39627`. The exact source
and instruction identities, and any unchanged-content reuse, are in the
receipt. Standard bounded spectral calculus, measure integration and
elementary change of variables are used with their hypotheses shown;
no specialized averaging, limiting-absorption, or scattering theorem is
imported. The Fourier decay step is proved above.

Reproduce the finite controls with Python 3.13 and the recorded SymPy,
NumPy and SciPy versions by running `effective_memory/memory_controls.py`
and `effective_memory/mean_controls.py`; all inputs are literal and
deterministic, with a 120-second timeout per recorded process. Use fresh
output paths when replaying to preserve the frozen logs. The receipt
records versions 1.14.0, 2.4.4 and 1.17.1 respectively. Their numerical
checks are explicitly floating; exact symbolic algebra is labeled separately.

This is a proposed bounded conditional theorem and author check packet.
It is ready for source-bound independent examination of the cone-density,
resolvent-to-measure, endpoint and time-average arguments. Formal retained
status remains outside this task. Only this new note and its new support
directory were written; frozen probes, reviews, Lean evidence, the shared
repository, global tooling, editable prompts and publication state remain
unchanged.
