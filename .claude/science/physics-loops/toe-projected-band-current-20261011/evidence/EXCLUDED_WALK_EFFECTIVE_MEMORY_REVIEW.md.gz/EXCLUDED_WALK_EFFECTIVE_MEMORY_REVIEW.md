# Independent review of effective dressing memory and coherent transfer

2026-10-11. Source-bound mathematical research check; no formal audit verdict
or retained-status action. The complete reviewed source is the 500-line
`EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md`, SHA-256
`b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c`.
Its author receipt is `effective_memory/receipt.json`, SHA-256
`99cad79eeb712071bfc48a04a161df7280cea694f80523dc86c563537f272557`.

## 1. Outcome and supported scope

No consequential defect was found in E1–E29 or their stated domains.
For each fixed nonzero kappa, the exact scalar Volterra equation and
Friedrichs resolvent are correct. The actual torus geometry gives the
claimed uniform local lower bound on the bath measure. The resulting
Poisson bound excludes interior singular dressing measure, and the
compression argument separately excludes endpoint atoms. The dressing
spectral measure is therefore absolutely continuous, the amplitude and
all its time derivatives tend to zero, and the unweighted transverse
probability tends to one.

The finite-horizon mean-transfer estimate E25–E26 is also supported,
including its one-sided-time sinc cancellation, edge term and constants.
It is not an explicit power or exponential decay theorem: its spectral
edge term remains unquantified as the edge width tends to zero. E29 is
an ordered limit for the original excluded walk. It is not a growing-time
error estimate, a uniform approximation over the zero-space unit ball,
or a fixed-nonzero-momentum infinite-time statement.

The result retains the supplied walk, spin sector, hard contact exclusion,
normalizations and clock. It establishes coherent transfer for the chosen
dressing preparation, not a Markov law, decoherence mechanism, full-state
relaxation or asymptotic weighted canonical current. The explicit finite
bath counterexample is correct and remains part of the supported record.

The independent reconstruction was recorded before reading the author
memory draft. It obtained the same scalar decay through an alternative
cone chart, local positivity and the strict-compression endpoint argument.
The subsequent check covers the complete frozen argument, including its
additional explicit constants and finite-horizon bound. Author replay and
PASS counts were not used as mathematical independence.

## 2. Exact sources and reading coverage

Paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| File | SHA-256 | Coverage |
| --- | --- | --- |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Complete 500 lines, all E1–E29 and evidence/scope prose. An initially truncated combined tool result was followed by a complete tail read. |
| `effective_memory/receipt.json` | `99cad79eeb712071bfc48a04a161df7280cea694f80523dc86c563537f272557` | Complete receipt, all declared file identities checked; author provenance is distinct from independent evidence. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Previous complete 549-line review reused unchanged; fixed physical zero space, bounded block D6, compact-time limit and current premises refreshed. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Previous complete independent reconstruction reused unchanged. |
| `excluded_walk_degenerate_review/independent_review_receipt.json` | `c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa` | Frozen provenance checked unchanged. |
| `excluded_walk_memory_review/PRE_FREEZE_RECONSTRUCTION.md` | `25a7cb608f6db544cb8fe15d7010d559b5597d75cd08cb06039fd2add7893b1d` | Independent 155-line reconstruction written before reading the new source. |
| `excluded_walk_memory_review/pre_freeze_receipt.json` | `d66d5e3dd853f6fa4f8dad57f8e7178c76129444e2709a313a29be91827ab34a` | Preserved identity record for the pre-reading argument and first exact controls. |

The complete author helpers `effective_memory/memory_controls.py` and
`effective_memory/mean_controls.py`, both complete baseline logs, the
mutation manifests, the development log, all six actual source differences
and all six complete failure logs were read. Every mutated file is exactly
its declared one-occurrence substitution of the inspected baseline. The
31 distinct path/hash records in the author receipt match. This includes
the identity of its historical Lean receipt; I did not perform or certify
a new Lean audit or reread every historical artifact behind that receipt.
The detailed inventory and literal source differences are saved separately
in `excluded_walk_memory_review/author_evidence_identity_check.json`.

Unchanged earlier source-chain readings are reused only for the premises
already checked. No new generic-K scattering theorem, literature novelty
claim, remote freshness claim or repository-wide survey is used. Applicable
reviewer instructions and the source workflow remain the previously read
revisions. No repository, author source, prior review, editable prompt,
commit, PR, registry or audit record was modified.

## 3. Independent block, memory and finite-time reconstruction

On the supplied physical zero space, use `b=|kappa|`,
`omega=d dot n`, `J=i n cross`, `D=omega J` and
`g=i(d cross n)/(2epsilon sqrt(I0))`. The scalar coordinate of the
initial dressing vector is one. On each transverse fiber,

    J*=J, J^2=I, D^2=omega^2 I, g*Jg=0.

The last identity follows because g is i times a real transverse vector.
The two helicity weights of g are exactly `|g|^2/2`. Therefore

    K(t)=integral |g|^2 cos(t omega),
    Sigma(z)=integral |g|^2 z/(z^2-omega^2),
    <zeta,(z-A)^-1 zeta>=1/[z-Sigma(z)].

The sign and normalization agree with E8–E10. In the upper half-plane
Sigma has nonpositive imaginary part, so the scalar denominator cannot
vanish there. Block variation of constants gives

    u(t)=-i integral_0^t exp[-i(t-s)D]g a(s) ds,
    a'(t)=-integral_0^t K(t-s)a(s) ds.

The two factors of -i fix the minus sign. Boundedness makes the Bochner
integrals legitimate; iteration of the integrated Volterra equation gives
the stated factorial uniqueness bound. Real coefficients imply a is real
for positive time, and unitarity makes it even. Consequently
`||u(t)||^2=1-a(t)^2` exactly. The Laplace transform has denominator
`p+integral p|g|^2/(p^2+omega^2)` for `Re p>0`.

For E7, the second spectral moment is `eta=||g||^2`; the fourth is
`||Dg||^2+eta^2<=b^2 eta` because `||A||<=b`. On `|bt|<=1`,
`a>=1-eta t^2/2>=1/2` and

    11eta t^2/24 <=1-a<=eta t^2/2.

Multiplication by `1+a` gives the stronger lower bound `11eta t^2/16`
and upper bound `eta t^2`. The advertised lower bound `eta t^2/2`
therefore holds. The parent estimate `||epsilon g||^2>=2b^2/27` and
`epsilon^2<=3` imply `eta>=2b^2/81`, yielding E7's last inequality.
At kappa=0, g and A vanish and a remains one, as the source states.

Expanding the propagator as `cos(t omega)I-i sin(t omega)J` also gives
the E11 field with signs `-i C_q g-S_q Jg`. The cross term vanishes and
a is real, giving its modulus-squared Fourier integral. Multiplication
by epsilon squared then gives E12. This weighted integral is not fixed
by the unweighted transfer probability; the source makes no such inference.

## 4. Explicit cone lower bound, with all measure factors

The independent pre-reading proof used `q_j=arcsin(r n_j)`. The source
instead uses the Euclidean chart `q=r omega`, which permits its simple
uniform constants. I checked that argument directly.

For `r<=1/2`, Taylor's inequality and `||omega||=1` give
`||X-omega||<=2r^2/3`, `||Y-omega||<=r^2/6`, and
`23/24<=1-r^2/6<=h<=1`. Thus

    ||v-omega|| <=(5/6)r^2/h <r^2,
    ||n-omega|| <=r^2/(3h) <r^2/2.

For a tangent H, the derivative bounds of sine give
`||dX[H]-H||<=2r^2||H||` and
`||dY[H]-H||<=r^2||H||/2`. Using `omega dot H=0` in
`dh=(Y dot dY)/h` gives `|dh[H]|<=2r^2||H||/(3h)`.
Differentiating X/h then gives the E16 coefficient

    13/(6h)+2/(3h^3) <=13/(6(23/24))+2/(3(23/24)^3)<4.

No derivative of the singular dressing field is involved. Also
`||d/b-e||<=r^2/2`; together with the n bound this proves E17.

Set `chi=delta/b in (0,1)` and `r0=sqrt(chi)/8`. On the declared angular
interval, `1-t^2>=chi/2-chi^2/16>=chi/4`. Consequently

    |partial_t(f/b)-1|<=4r^2/sqrt(1-t^2)<=sqrt(chi)/8,
    |d cross n|>=b[sqrt(chi)/2-r^2]>=b sqrt(chi)/4.

The bounds hold uniformly for every direction of nonzero kappa; choosing
spherical coordinates about e does not assume rotational symmetry of the
lattice symbol. At either t endpoint, the value error `chi/64` plus the
angular deficit `chi/4` is below `chi/2`. Hence each monotone t map
covers the entire required energy interval. Its inverse derivative is
at least `1/(2b)` and `epsilon<=r` gives
`G>=b^2 chi/(64I0 r^2)`.

The factors in the resulting lower measure are independently

    (one helicity 1/2) * (torus normalization (2pi)^-3)
      * (azimuth 2pi) * (radial width r0/2)
      * (b^2 chi/(64I0)) * (inverse derivative 1/(2b)).

Their product is exactly

    b chi r0/(2048pi^2 I0)
       =b chi^(3/2)/(16384pi^2 I0)=c_delta.

Only one cone shell and one helicity term are retained. Their positivity
gives E14 for every Borel subset of the claimed interval, with no missing
eight-cone multiplicity, r power, factor two, or normalization factor.
The lower bound is a measure domination statement; it need not establish
absolute continuity of the whole bath measure for the next argument.

## 5. From a strip resolvent bound to absolute continuity and decay

For `|x|<=b-delta`, `0<y<=delta/2`, the interval `x+[-delta/2,delta/2]`
lies in the range controlled by E14. Its Poisson integral is

    2c_delta arctan(delta/(2y)) >=pi c_delta/2.

Thus `|M(x+iy)|<=2/(pi c_delta)=C_delta`, with the displayed constant
`32768pi I0/(b chi^(3/2))`. This is a uniform strip bound, not merely
positivity of a density almost everywhere.

For the dressing probability measure nu, the Poisson kernel is at least
`1/(2y)` on `[x-y,x+y]`, so

    nu([x-y,x+y])<=2y[-Im M(x+iy)]<=2C_delta y.

An atom at an interval endpoint saturates the first factor-two inequality;
the independent exact control detects deleting that factor. For every
contained interval of length at most delta, apply this bound at its
midpoint. Subdivision gives the same length bound on longer contained
intervals. Countable covers and outer regularity give domination by
`C_delta` times Lebesgue measure in the compact interval's interior.
Letting y tend to zero at its two endpoints excludes endpoint atoms of
that compact interval. Exhaustion covers all of `(-b,b)`. This proves the
source's exclusion of both interior atoms and singular-continuous mass.

The remaining spectral endpoints require an independent step. For b>0,

    b^2-|d(q)|^2=sum_j kappa_j^2 sin^2 q_j>0

almost everywhere, including when only one kappa component is nonzero.
For any nonzero physical zero-space triplet field z,
`||A z||<=||B z||<b||z||`. An endpoint eigenvector would contradict this
strict inequality. The inequality is vectorwise and gives no uniform norm
gap; none is needed. Since `||A||<=b`, no support remains outside the
closed interval, and its two endpoints have no atoms. Hence nu is entirely
absolutely continuous as claimed in E23.

This conclusion was independently reconstructed before reading the draft.
That reconstruction additionally showed bath absolute continuity using
real analyticity and coarea away from the eight cones, and obtained local
positivity from an arcsin cone chart. Those stronger bath facts are not
silently imported into the source proof; E14–E22 alone suffice.

Fourier approximation of the L1 density proves E24. Since its support is
bounded, every `E^j rho(E)` also lies in L1, justifying the assertion that
all time derivatives of a vanish. There is no inferred Fourier rate,
monotonicity, Markov approximation, limiting mixed state or current limit.
The source only claims this measure and its cyclic subspace; a broader
spectral classification is not needed for, or attributed to, E23.

## 6. Finite-horizon transfer and edge term

Apply the interval Poisson inequality at `x=b`, `y=delta`. It bounds
the upper edge mass by `2delta[-Im M(b+i delta)]`. Symmetry of the
spectral measure follows from E9 (or the real amplitude), giving the same
bound at the lower edge. Thus

    nu({|E|>b-delta}) <=min{1,4delta[-Im M(b+i delta)]}=e_delta.

The limit `e_delta->0` uses endpoint absence:
`delta[-Im M(b+i delta)]` is the integral of
`delta^2/((b-E)^2+delta^2)`, which converges boundedly to the endpoint
indicator. This argument gives no rate for that limit.

Let nu_c be the central restriction. Its density is bounded by C_delta,
its mass is at most one, and its support has diameter at most 2b. Direct
integration of `|a_c(t)|^2` in normalized time yields a double integral.
Swapping the two energy variables cancels its imaginary part, leaving
`sin(T(E-E'))/[T(E-E')]`. The original central measure itself need not
be symmetric for this cancellation.

For each fixed E, integrate `min(1,1/(T|E-E'|))` against the density
bound. When `T>=1/(2b)`, including equality, the result is at most

    2C_delta [ integral_0^(1/T) 1 dd
                  +integral_(1/T)^(2b) 1/(Td) dd ]
      =2C_delta[1+log(2bT)]/T.

Integrating the other probability factor cannot enlarge it. The edge
Fourier transform has absolute value at most e_delta. Minkowski's
inequality in normalized `L2([0,T])` then gives exactly E26, and the
extra maximum with zero follows from nonnegative transfer probability.
There is no missing factor two, central-mass normalization or assertion
that sinc is pointwise nonnegative.

All E25 quantities are defined by explicit torus resolvents at nonreal
arguments, where the formulas are nonsingular. They are not certified by
an unvalidated torus quadrature. Choosing delta small first and then T
large does make the bound tend to one. This is weaker than an explicit
power law in T, precisely as the source says.

## 7. Counterexample, original-walk interface and evidence limits

For E27, direct multiplication gives
`A^3=(f^2+h^2)A`. At `f=3/5`, `h=4/5`, this is `A^3=A` and the
last diagonal entry of A squared is 16/25. Thus the displayed exponential
gives `a(t)=(9+16cos t)/25`, zero-energy dressing weight 9/25 and exact
returns at multiples of 2pi. The memory and resolvent identities still
hold; the continuum lower bound fails. This is a valid counterexample to
decay from the block form alone, not a counterexample to the torus theorem.

The original walk is controlled only at each fixed compact effective-time
interval as lambda tends to zero. Its physical time is t/lambda. Boundedness
of F transfers that fixed-time convergence to its probability, after which
the effective t limit may be taken. This gives E29 in the written order.
No uniform growing-time remainder or exchange of these limits was proved.

New independent files are under `excluded_walk_memory_review/`:

- `PRE_FREEZE_RECONSTRUCTION.md` and `pre_freeze_receipt.json`: preserved
  argument and input identities from before reading the new source.
- `independent_memory_controls.py` and its complete 36-line log: a weighted
  two-antipodal-pair, actual-sine/cosine fixture, with non-diagonal kappa.
  The effective 5-by-5 block is obtained by an independent 6-by-6 compression.
  Exact helicity weights, three nonreal scalar resolvents and Volterra
  derivatives through order twelve are checked. First execution exited
  zero, about 0.658 seconds outer runtime.
- `independent_measure_controls.py` and its complete successful log:
  exact cone constants, sharp atomic Poisson factor, exchange cancellation
  for an unsymmetric atomic measure and the horizon-threshold coefficient.
  This passed after the reporting-only repair described below.
- Both execution JSON files, the preserved failed first supplemental
  source/log/metadata, the author identity/difference inventory, the current
  checkpoint and the final independent receipt.

The supplemental helper's first run completed every mathematical assertion
but exited 1 while printing elapsed time: a SymPy symbol named `time` had
shadowed the imported module. That exact source, complete traceback and
execution metadata are preserved as `independent_measure_*attempt1*`.
Renaming the symbol to `duration` repaired reporting; no mathematical
assertion, constant or tolerance changed. The successful run exited zero
in about 0.297 seconds. Both helpers use Python 3.13.5 and SymPy 1.14.0,
with a 120-second process timeout and no author imports.

The independent finite fixture is pure point. Neither it nor the author
finite fixtures establish continuum decay. The scientific evidence is
the separate analytical reconstruction and the full source-bound checking
of the cone, measure, endpoint and averaging proofs. Author baselines and
six deliberate failures were inspected as finite evidence, not replayed
or counted as additional independent proofs. The author's development
record also preserves an unrelated failed prose-match operation.

No mathematical correction to these frozen source bytes is requested.
The remaining interfaces are the ones the source names: spectral edge or
pointwise decay rates, weighted-current asymptotics, growing-time original-
walk control and arbitrary lambda-dependent free-band preparations. This
review supplies no Lean verification; a formalization would still need
the operator calculus, cone change of variables, measure-domination,
endpoint and time-average arguments. Formal retained status remains outside
this independent research check.
