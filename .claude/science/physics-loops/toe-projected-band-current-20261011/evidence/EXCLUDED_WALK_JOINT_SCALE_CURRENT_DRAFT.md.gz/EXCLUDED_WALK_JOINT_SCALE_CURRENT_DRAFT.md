---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# A growing-time canonical-current limit for actual projected free-band packets

2026-10-11. Root research draft, not yet independently checked or published.

The finite transverse comparison can accommodate a growing effective time.
Together with the effective dressing state's absolutely continuous spectrum
and a trace-class comparison, it gives a joint small-band/long-time limit for
the actual supplied excluded walk. The preparation is a single normalized
projection of a genuine positive free-band packet. No phase average or
encounter process is introduced.

All quantities below have the lattice, generator-clock, antisymmetric-pair,
contact-exclusion and canonical-energy-placement premises of the checked
sources. The result is a constructed family, not an assertion about generic
states, a physical relaxation rate, or a many-body collision law.

## 1. Source identities and exact hypotheses

Sources are in the same external research directory:

- EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md, SHA-256
  ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400:
  complete prior reading, Q11-Q33 refreshed, especially the finite all-T Q16.
- EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md, SHA-256
  0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c:
  complete prior reading; finite-momentum B18-B24 refreshed.
- EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md, SHA-256
  09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324:
  complete prior reading; L6-L10 refreshed for the exact leading band weight.
- EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md, SHA-256
  b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876:
  complete prior reading; D1-D7 refreshed for the fixed physical space.
- EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md, SHA-256
  b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c:
  complete new reading; E1-E29 checked, including the singular-measure step.
  Its complete independent review is c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0.
- Kato, Perturbation of Continuous Spectra by Trace Class Operators (1957),
  Theorem 1, p.260, equations (1.1)-(1.2). The checked primary PDF is
  excluded_walk_review/kato_1957_primary.pdf, SHA-256
  12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5.
  The exact strong limits and initial/final subspaces are refreshed here.

The new weighted-memory author draft is not a source of this argument.
Section 2 derives the needed implication directly from the identified theorem.
Independent checking of that implication and the new joint-scale composition
is still required. All previous frozen arguments and failed controls remain.

Use H_*=H_D(0), F the free transverse kernel projection, and
Pi=F+|zeta><zeta|, with zeta=n/(2 epsilon sqrt(I0)). Fix kappa0=(1,1,1).
On Z=ran Pi=F direct-sum C, write

    A=[D,g;g*,0], D=i(d dot n)n cross,
    g=i(d cross n)/(2 epsilon sqrt(I0)), d_j=cos q_j.

Here 1/12<=I0<=9/8, A is bounded self-adjoint with norm at most sqrt(3),
and (u(tau),a(tau))=exp(-i tau A)zeta. The memory theorem establishes that
the probability spectral measure of zeta under A is absolutely continuous.

For 0<lambda<=1/16, let phi_lambda be the normalized free spectral slice of
zeta on [5lambda/4,7lambda/4], chi_lambda=P phi_lambda/n_lambda, and
A_lambda=<zeta,chi_lambda>. The checked sources give

    F chi_lambda=0, Pi chi_lambda=A_lambda zeta,
    sqrt(lambda)/12 <= A_lambda <=2sqrt(lambda), A_lambda<=1,
    A_lambda^2/lambda=1/(8pi^2 I0)+O(lambda^2).             (G1)

The last identity follows from L10 and n_lambda^2=1-O(lambda^3), not a
numerical threshold fit. All torus integrals retain dq/(2pi)^3.

## 2. The weighted effective limit

On the single Hilbert space Z set A0=D direct-sum 0. Both A and A0 are
bounded self-adjoint. Their difference V=[0,g;g*,0] is self-adjoint of
rank at most two, with trace norm 2||g||. Kato's Theorem 1 therefore applies.
Its reverse strong limit maps the absolutely continuous subspace of A
isometrically onto that of A0. Since zeta has absolutely continuous spectral
measure, there is a vector (u_+,0) in ac(D) direct-sum {0} of norm one with

    ||exp(-i tau A)zeta-(exp(-i tau D)u_+,0)|| ->0
                                      as tau->+infinity. (G2)

Explicitly, (u_+,0)=lim exp(i tau A0)exp(-i tau A)zeta. The scalar zero
summand of A0 is purely atomic, so its absolutely continuous projection
vanishes. No assertion that all of D is absolutely continuous is needed.
The theorem's initial/final-subspace statement gives norm one, not merely
existence of a weak limit. This fixes the sign convention in G2.

Multiplication by epsilon^2 is bounded by 3 and commutes with the pointwise
operator D. Strong comparison G2 then gives

    W(tau):=||epsilon u(tau)||^2 -> W_+:=||epsilon u_+||^2,
    0<W_+<3.                                             (G3)

The strict inequalities follow from ||u_+||=1 and 0<epsilon^2<3 almost
everywhere; the exceptional cones and maximum sets have zero torus measure.
There is no uniform positive lower bound over all unit vectors implicit
in this reasoning. In particular it proves no rate for W(tau)-W_+.

## 3. Uniform finite comparison on a growing effective-time interval

Choose any fixed gamma with 0<gamma<1/2 and set

    delta=lambda^3, sigma=lambda^2, T_lambda=lambda^(-gamma),
    p=1/2-gamma>0.                                       (G4)

Use U_delta(tau)=exp[-i tau H_D(delta kappa0)/delta]. The Q16 bound is
finite for every T and was proved before T was specialized to 1/20.
Its spectral-cutoff domain holds because sigma<=min(1/2,5lambda/8).
With b=sqrt(3), r_delta=3delta/4+3sqrt(3)delta^2/24<=delta, it gives

    e:=sup_(|tau|<=T_lambda)
          ||F U_delta(tau)chi_lambda-A_lambda u(tau)||,

    e/A_lambda <=108 delta T_lambda/(sigma sqrt(lambda))
             +58 T_lambda^2 sqrt(sigma)
             +96 sigma/lambda^(3/2)
             +13 T_lambda delta/sqrt(lambda)
       =108lambda^p+58lambda^(2p)+96lambda^(1/2)
                                      +13lambda^(2+p)
       <=275lambda^p.                                   (G5)

For the first term, divide Q16 by A_lambda and use b<2, T>=1 and
1/A_lambda<=12/sqrt(lambda): (4+8T)+(4+4T)/A_lambda is at most
108T/sqrt(lambda). For the second use I0^(-1/2)<4 and
4[4+(21/2)T^2]<=58T^2. The last two terms use C_lambda<=4/lambda,
A_lambda<=1 and the same lower bound on A_lambda. Thus no fixed-vector
limit or compact-time convergence is substituted for the finite estimate.
The inequalities also make clear why gamma must be strictly below 1/2
for these particular scale choices.

## 4. Actual current comparison, valid at every finite time

For the diagonal fiber the checked full-space identity is

    sum_a L_a=3P-H_*^2/2-2epsilon^2 F,
    ||J_a(delta kappa0)/delta-L_a||<=((13+sqrt(3))/24)delta^2.

The initial state and evolution are cyclically invariant, so all three
changes of <L_a> agree. Initially F chi_lambda=0. Conservation of the
actual H_D(delta kappa0)^2 gives

    |Delta <H_*^2>|<=8sqrt(3)delta(sqrt(3)+r_delta).

These facts hold for every time, not only 1/20. The norm error in G5
also gives | ||epsilon F U_delta chi_lambda||^2-A_lambda^2 W(tau)|
<=3e(2A_lambda+e). Combining both signs of these inequalities proves

    |Delta<J_a>/delta+(2/3)A_lambda^2 W(tau)|
                           <=4A_lambda e+2e^2+8delta      (G6)

for |tau|<=T_lambda. For the last constant the energy-square error divided
by six is at most 4delta+(8/3)delta^2; twice the current remainder is at
most (5/4)delta^2, whose sum is below 8delta when delta<=1.

In particular, at tau=T_lambda, G1,G5-G6 give

    Delta<J_a>/(delta lambda)
       =-W(T_lambda)/(12pi^2 I0)+O(lambda^p), a=1,2,3.    (G7)

One direct finite error budget before replacing A_lambda^2/lambda by its
limit is 16 E_lambda+8 E_lambda^2+8lambda^2, where E_lambda=275lambda^p.
The O(lambda^2) band-weight remainder is bounded using W<=3.

## 5. A genuine global free-band preparation

Let h be any fixed smooth unit vector in L2(dy/(2pi)^3), supported in
the unit ball and nonzero on an open set. Set eta_lambda=lambda^2 and

    f_lambda(kappa)=eta_lambda^(-3/2)
                         h((kappa-kappa0)/eta_lambda).

For |K|<=lambda/16, take the checked actual free-band vector
phi_(lambda,K)=Pi_++(K)phi_lambda/||Pi_++(K)phi_lambda||. Define

    Phi_lambda(K,q)=delta^(-3/2)f_lambda(K/delta)phi_(lambda,K)(q),
    Chi_lambda=P Phi_lambda/||P Phi_lambda||.              (G8)

This is one global contact normalization. The free packet has norm one
and lies in the actual positive [lambda,2lambda] free band. Its physical
norm before normalization lies between 1-lambda^3/3 and 1 in squared norm.
Its total-momentum center is lambda^3(1,1,1), with radius lambda^5; it has
nonempty three-dimensional support away from zero. Since lambda<=1/16,
the support lies in |K|<=lambda/16 and |kappa-kappa0|<=1/10.

For every finite tau, bounded Duhamel and the exact current estimates B20
give ||U_(delta,kappa)(tau)-U_(delta,kappa0)(tau)||<=|tau||kappa-kappa0|,
current norm at most 4 after division by delta, and current Lipschitz
constant 4. At fixed initial chi_lambda the scaled current drift therefore
changes by at most 8(1+|tau|)|kappa-kappa0|. Replacing this vector by
chi_(lambda,delta kappa) costs at most 512delta/lambda, as in B19-B20.
After division by lambda the uniform errors at T_lambda are at most

    8(1+T_lambda)eta_lambda/lambda+512delta/lambda^2
                      =520lambda+8lambda^(1-gamma)=o(lambda^p). (G9)

The actual kappa weights after the single projection are
|f_lambda|^2 n_(lambda,delta kappa)^2/||P Phi_lambda||^2. They are positive,
integrate to one and stay inside this ball. Integrating a uniform error
against those exact weights preserves G7 without replacing their law.

Let Psi_lambda(t)=exp(-it H_D)Chi_lambda in the full direct integral.
At the common physical time t_lambda=T_lambda/delta=lambda^(-(3+gamma)),

    [<Psi_lambda(t_lambda),J_a Psi_lambda(t_lambda)>
       -<Chi_lambda,J_a Chi_lambda>]/lambda^4
       =-W(lambda^(-gamma))/(12pi^2 I0)+O(lambda^(1/2-gamma))
       ->-W_+/(12pi^2 I0)<0,             a=1,2,3.         (G10)

This is a joint limit along explicit polynomial scales. G3 supplies its
strict limiting sign; G5-G9 control the original walk at the growing time.
An example is gamma=1/8, t_lambda=lambda^(-25/8), comparison error
O(lambda^(3/8)). The convergence of W itself has no proved rate, so G10
does not give an explicit numerical onset for the final sign.

## 6. Status and remaining checks

The new obligations are an independent check of the Kato application,
the all-T use of Q16, both signs in the current error, exponent arithmetic,
and the global preparation at the moving momentum scale. The final packet
has an actual finite time and positive momentum volume for every lambda;
the limit does not exchange two uncontrolled limits.

No claim about optimal exponents, monotonic current, a fixed-density gas,
the K-comparable-to-lambda regime, or arbitrary initial data follows. The
finite-bath recurrence and state-uniformity counterexamples remain intact.
This draft is new conditional mathematics; no independent audit, Lean proof,
external verification, publication or retained status is claimed for it.
