# Selective review of the joint-scale projected-band current limit

2026-10-11. Independent check of the new root-authored composition, not a
formal audit or retained-status decision. The complete reviewed target is
`EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md`, 236 lines, SHA-256
`4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278`.

## 1. Finding and dependency boundary

No consequential defect was found in the new scale, observable or global
preparation arguments G1 and G4-G10. The finite Q16 estimate can be used at
T_lambda=lambda^(-gamma); the proof does not substitute the earlier
fixed-time convergence theorem. The small dressing amplitude is retained
through the current estimate. For fixed 0<gamma<1/2, the proposed
delta=lambda^3, sigma=lambda^2 and kappa-width eta=lambda^2 make every
required error vanish after division by delta lambda=lambda^4.

The strictly negative limiting constant remains conditional on the
effective weighted-scattering implication G2-G3. Its new source is frozen
at `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324`,
but its separate independent review was pending when this report was
written. I checked the matching fixed-space hypotheses and the elementary
strong-to-weighted implication; I did not independently verify the primary
Kato import or re-review the memory theorem's absolute-continuity proof.
Neither that pending dependency nor the earlier independent memory review
is silently converted into completed review of the new weighted theorem.

The downstream conclusion supported here is therefore: **if the stated
unit-norm outgoing datum exists as in G2, then the actual normalized
projected free-band family in G8 satisfies G10**, with its strictly negative
constant supplied by G3. No source repair is requested in this scope.

## 2. Sources, reading coverage and independence

All names in this report are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The receipt records absolute paths and final byte identities.

| Source | SHA-256 | Exact reading scope |
| --- | --- | --- |
| `EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md` | `4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278` | Complete 236 lines, all G1-G10, hypotheses and scope. The first complete read already had the subsequently frozen bytes. |
| `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md` | `ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400` | Earlier complete 420-line author reading reused; lines 60-296 refreshed here, including the full all-T Q7-Q16 chain and actual-current Q18-Q22. |
| `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_REVIEW.md` | `a530a7b1507e7d22af11f08c236af865ec1c8acb004069b249c9b281bcf4cbda` | Complete 329-line reading from the immediately preceding composition reused after identity check. This is the independent check of the quantitative source. |
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | Earlier complete 327-line reading reused; lines 217-306, all B18-B24, refreshed here. Complete B5/B7-B13 arguments were refreshed in the immediately preceding composition. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Earlier complete 457-line author reading reused; lines 134-179, L6-L10 and preparation, refreshed here. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Earlier complete 549-line reading reused; full D3-D7/D9-D11 and current remainder were refreshed in the immediately preceding composition. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Only lines 29-81 and 300-331 read here: operator/parity contract and exact E23-E24 conclusions. Not a complete review of the 500-line memory proof. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | Lines 1-78 read for findings, source identity and stated limits; not a re-review of all 329 lines or its independent evidence. |
| `EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md` | `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324` | Complete 339 lines read to identify the provisional implication and its precise scope. Its primary PDF, controls and mutations were not inspected or replayed in this review. |

This reviewer authored the earlier quantitative and long-time probes. Their
new author replay would not constitute independent review of those sources;
their frozen independent reviews remain the relevant prior checks. The
present independent work concerns the new root-authored growing-time
composition and is reconstructed below. Root's new scale runner and its
output were not read or executed before or after my own controls. Exact
rational bookkeeping necessarily overlaps in subject matter with author
scale controls; the analytic reconstruction, not a differing PASS count,
is the basis of this finding.

## 3. Reconstructing the growing-time estimate

The pointwise variation-of-constants estimate Q7 is valid for every finite
T. It gives |u(tau,q)|<=Tb/(2epsilon sqrt(I0)), and the removed dressing
component costs the second half in Q8. The cutoff inverse thus yields
M_zeta(sigma,T)<=(7/2)b^2 T sqrt(sigma)/sqrt(I0). This T is explicit.
The zero-space corrector integrates that estimate once, producing T^2 in
Q16. The complementary corrector has its own T term and annihilation by F.
There is no compactness argument with an unspecified T-dependent modulus
left in this estimate. In particular the fast complementary state is not
assumed small in norm or convergent.

Write A=A_lambda and E=e/A. At b=sqrt(3), T>=1 and lambda<=1/16, Q16 gives

    E <= delta/sigma [(2b+6T)+(2b+3T)/A]
       +[4+(21/2)T^2]sqrt(sigma)/sqrt(I0)
       +2sigma C_lambda/A+(1+1/A)T r_delta.

I obtain the following alternative rational relaxations, using
sqrt(lambda)<=1/4, 1/A<=12/sqrt(lambda), 1/sqrt(I0)<7/2,
C_lambda<=4/lambda and r_delta<=delta:

    E <= (173/2) delta T/(sigma sqrt(lambda))
         +(203/4)T^2 sqrt(sigma)
         +96sigma/lambda^(3/2)
         +(49/4)T delta/sqrt(lambda).

For example 2b+6T<=10T and 2b+3T<=7T; their combined coefficient is
10/4+7*12=173/2. Also (4+21/2)*(7/2)=203/4. These are each no larger
than G5's 108, 58, 96 and 13. The generator bound is uniform for delta<=1:
using sqrt(3)<7/4 gives r_delta/delta<=3/4+7/32=31/32<1.

To test the scale conditions independently, take delta=lambda^d,
sigma=lambda^s, T=lambda^(-gamma), eta=lambda^r. The required powers are:

| Error before taking the limit | Exponent of lambda |
| --- | --- |
| High-spectral correctors in e/A | d-s-gamma-1/2 |
| Dressing-orbit cutoff in e/A | s/2-2gamma |
| Band-complement cutoff in e/A | s-3/2 |
| Generator remainder in e/A | d-gamma-1/2 |
| Energy-square error divided by lambda | d-1 |
| Actual-preparation error divided by lambda | d-2 |
| Packet current variation divided by lambda | r-1 |
| Packet evolution variation divided by lambda | r-1-gamma |

A sufficient open region is s>max(3/2,4gamma),
d>max(2,s+gamma+1/2), r>1+gamma, gamma>0. This is only a sufficient
region for these estimates, not an optimal restriction on the dynamics.
At d=3,s=2,r=2 and p=1/2-gamma, the first four exponents are
p,2p,1/2,2+p. Thus E<=275lambda^p for every fixed 0<gamma<1/2.
The cutoff domains hold on the whole stated band range:
sigma=lambda^2<=5lambda/8 and sigma<=1/2; delta<=1 and T>=1.

At gamma=1/2 these estimates do not give E->0. That is a limitation of
this bound, not a counterexample to the actual dynamics. Nor does the
proof allow a lambda-dependent gamma approaching 1/2 without additional
control. The draft explicitly fixes gamma in the open interval.

## 4. Two-sided actual current and the leading coefficient

Let psi=U_delta(tau)chi_lambda. Cyclic symmetry is exact at kappa0 and
the full physical trace gives, at every finite tau,

    Delta<L_a>=-(1/6)Delta<H_*^2>-(2/3)||epsilon F psi||^2.

The initial transverse component is zero. Add and subtract the conserved
H_D(delta kappa0)^2 to bound the first term at both endpoints. For the
second term, put F psi=A u+v, ||v||<=e. Boundedness of epsilon gives

    | ||epsilon F psi||^2-A^2||epsilon u||^2 |
        <=3(2Ae+e^2).

Multiplication by 2/3 therefore gives exactly 4Ae+2e^2. The argument
controls both signs; it does not merely reuse the earlier one-sided
small-time current conclusion. The energy-square and the two current
Taylor remainders are at most 8delta for delta<=1. Independently,
sqrt(3)<7/4 bounds their combined coefficient by 121/16<8. This proves
G6 for every |tau|<=T_lambda without a time-dependent current remainder.

The A factor is essential at this normalization. An amplitude-independent
O(e) error divided by lambda would behave as lambda^(p-1/2)=lambda^(-gamma),
and would not establish G7. With the proved quadratic-form bound and
A^2/lambda<=4, the normalized finite error is instead

    16E+8E^2+8delta/lambda=16E+8E^2+8lambda^2.

The L6 Jacobian is uniformly 1+O(lambda^2) on the band. Its interval has
length lambda/2, so w_lambda=lambda/(8pi^2 I0)[1+O(lambda^2)]. The
positive contact amplitude has square O(lambda^3), hence division by
n_lambda^2=1-O(lambda^3) yields
A_lambda^2/lambda=1/(8pi^2 I0)+O(lambda^2). Together with W<=3 this
gives the coefficient -W(T_lambda)/(12pi^2 I0) and the G7 error O(lambda^p).
Neither the contact normalization nor a factor of two from exchange is lost.

## 5. Moving momentum and the normalized global packet

The preparation projector acts on the actual positive free band and
preserves the original q support. On the packet's kappa ball,
|kappa|<=sqrt(3)+lambda^2<2, so
|K|<2lambda^3<=lambda/16 at lambda<=1/16. Its radius lambda^2 is less
than 1/10. Thus all B18-B20 preparation and current bounds apply. Sharp
relative-momentum band endpoints cause no domain issue for the bounded
Hamiltonian and current extension used here.

For a common initial vector, the scaled drift difference consists of two
observable changes, each costing 4|kappa-kappa0|, and one evolved-state
change costing 8|tau||kappa-kappa0|. This is the stated
8(1+|tau|)|kappa-kappa0|. Bounded Duhamel supplies the factor |tau| for
every finite time; the special tau0=1/20 is not reused. Replacing the
initial vector costs two expectation endpoints, hence
4||J_a/delta||*||chi_(lambda,delta kappa)-chi_lambda||
<=4*4*32delta/lambda=512delta/lambda.

After division by lambda, the two uniform costs are

    8(1+T_lambda)eta/lambda+512delta/lambda^2
      =520lambda+8lambda^(1-gamma)=o(lambda^p).

No uniform scattering statement in kappa is needed: the growing-time
comparison first reduces every shrinking-ball fiber to the same fixed
kappa0 orbit. This avoids importing continuity of its outgoing datum.

The factors delta^(-3/2) and eta^(-3/2) cancel the corresponding normalized
three-dimensional Jacobians. The free packet is unit norm before contact
projection. Let N=||P Phi_lambda||. Then
1-lambda^3/3<=N^2<=1, and the physical kappa law is exactly
|f_lambda|^2 n_(lambda,delta kappa)^2/N^2. Its total mass is one. Since
the approximation to the same central expression is uniform throughout
the ball, integrating against these actual weights adds no error term and
does not require replacing the weights by |f_lambda|^2.

The physical center lambda^3(1,1,1), positive radius lambda^5 and common
time t_lambda=lambda^(-(3+gamma)) agree with the definition of U_delta.
Consequently the normalization in G10 is lambda^4=delta lambda. For
gamma=1/8 its comparison error is O(lambda^(3/8)) and its physical time
is lambda^(-25/8), as stated.

## 6. The provisional weighted input and the limit's scope

The memory theorem's exact needed premise is zeta in H_ac(A), not just
decay of its scalar survival amplitude. The weighted source uses the same
space Z=F direct-sum C, A0=D direct-sum 0, and the rank-two bounded
self-adjoint perturbation [0,g;g*,0]. Its scalar A0 summand is purely
atomic. Given the reverse complete wave-operator statement in G2, the
outgoing comparison vector therefore has the form (u_+,0), with norm one.

The remaining elementary implication is correct: the even bounded scalar
weight epsilon^2 preserves F and commutes with D. Strong comparison changes
its quadratic form by at most six times the state error. Thus W(tau) has
the asserted limit. Since 0<epsilon^2<3 almost everywhere, a nonzero L2
datum of norm one gives 0<W_+<3. This does not supply a numerical positive
lower bound, a convergence rate, or a uniform bound over possible data.

Conditional on that still separately reviewed implication, T_lambda->infinity
and G5-G9 give the joint limit directly. There is no exchange of two
uncontrolled limits. The O(lambda^p) in G10 estimates the difference from
the moving W(T_lambda), not the entire difference from W_+. The draft
correctly supplies no explicit onset for its eventual sign.

The result remains one coherent supplied-model family. It is not monotonic
decay, a claim about arbitrary preparations, a collision clock or many-body
closure. The earlier finite-bath recurrence and state-uniformity limitations
are untouched.

## 7. Exact controls, receipt and limits

The independently written `joint_scale_review/independent_controls.py`
does not import or execute an author runner. It verifies affine exponent
inequalities on the entire open p interval through endpoint arithmetic,
the alternative Q16 coefficients above, both signs of the amplitude-sensitive
quadratic-form error, the actual-current remainder, preparation constants,
support domains, Jacobians and common time. A nonuniform three-point
normalization fixture confirms that actual projected weights differ from
the original envelope law while preserving a uniform error bound.

- Helper SHA-256: `20c4bb4a4a96129786a909cafef0246e4d3285c587195493366954e9be46911b`.
- Complete first-run log SHA-256: `ede9bffc64e05ab63803980cd09c9dc92e12eca90cb2c1783ad70ac78d4ee588`.
- Execution: Python 3.13.5, standard library only, exit 0; the complete log
  was read. No failed helper or mutation run occurred in this review.

Those controls check exact algebraic budgets. They do not simulate or prove
the continuum walk, justify a wave operator from finite matrices, or verify
the memory source's singular-measure argument. Root's author controls were
not replayed, and no claim about their execution is made here. The receipt
binds all nine listed source identities, coverage, helper, full log and this
report; it keeps the pending weighted review explicit.

Only this report and `joint_scale_review/` were written. No frozen source,
repository file, editable prompt, model setting, PR, registry or audit state
was changed. The existing source workflow and bounded-review instructions
were reused at their previously verified identities.
