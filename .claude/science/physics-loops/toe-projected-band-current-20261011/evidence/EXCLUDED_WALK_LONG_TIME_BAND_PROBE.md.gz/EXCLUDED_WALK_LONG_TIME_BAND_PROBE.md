---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Threshold dressing and a constructive long-time band-leakage estimate

2026-10-11. External author derivation for the supplied excluded Weyl walk.
The strongest result is an explicit zero-energy vector and a finite-time
averaged leakage construction, including normalizable packets with nonzero
total momentum. It does not assert a uniform-in-time current law. In
particular, the canonical-current correction cancels a tempting leading
dressing contribution; leakage is not a current counterexample.

## 1. Sources, target, and premise boundary

S denotes `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`;
W denotes `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/worktree`.
All mathematical quantities use lattice and clock units of the supplied walk,
normalized relative-torus measure dq/(2pi)^3, and inner products linear in
the second slot. No physical dynamics or reading rule is adopted.

The supplied bounded free symbol and exclusion are

    H0(K,q)=sigma_1·sin(K/2+q)+sigma_2·sin(K/2-q),
    C=|c><c|, P=I-C, H_D(K)=P H0(K)P on the allowed space P.

Here c is the constant normalized spin singlet. When an operator on the
full fiber is needed, H_D has its zero extension on C. The Hilbert space
is the antisymmetric pair fiber; total-momentum packets use its measurable
direct integral in a coordinate chart.

| Source read | SHA-256 and coverage |
|---|---|
| S/EXCLUDED_WALK_TRANSPORT_PROBE.md | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526`; all 322 lines |
| S/EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`; all 190 lines |
| S/EXCLUDED_WALK_CANONICAL_REVIEW.md | `ced416dce3a7de31b503d73460e2fa449f6ed4e7175400d8376179cbeead0f9c`; all 52 lines; it is not independent evidence for its author's threshold proof |
| S/EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7`; prior complete reading reused after identity verification |
| S/EXCLUDED_WALK_COOK_REVIEW.md | `a145780abbc767a71dd72b5a9fe3fa4ea6c59015ad57818623fcc81d3c62c75c`; this worker's frozen independent check; unchanged |
| W/docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`; prior complete 226-line reading reused |
| W/docs/ADMISSIBILITY_RULE_A_REST_ENERGY_FROM_BINDING_TWO_WALKERS_IS_EXACT_WITH_THE_WALKERS_OWN_SPEED_IN_ONE_DIMENSION_INVISIBLE_UNDER_ONE_RECORD_PER_SITE_AND_ANISOTROPIC_IN_THREE_BOUNDED_THEOREM_NOTE_2026-09-24.md | `50c708e3742f9a5daa59f6f1fb48b44fe388d71b9fc2454ede1a9595185d332d`; all 106 lines |

The last note's attractive-contact and off-spectrum results do not classify
this kinetic threshold state. Its T4 explicitly leaves kinetic boundary
effects open after projection eliminates the supplied attractive contact.
The frozen threshold probe proves contact regularity in a positive band;
it does not classify the compressed zero eigenspace. The Cook bridge needs
both incoming and outgoing contact regularity for its quantitative tails,
and uses remote-time scattering preparation. Those hypotheses cannot be
silently applied to an arbitrary band packet projected at time zero.

The bounded local-main statement search used
`e485eab6b09b3957df5772104d3ea3980108d7fa`. Its complete commands and output
are in `excluded_walk_long_time/prior_statement_search.{json,log}`. It
searched the admissibility-rule notes for both orders of excluded/threshold/
zero-energy/flat-band terms and for contact inverse or square-integrability
terms. The matching binding note was read completely; the other hit
statements concern different radiation or static models. This is a scoped
comparison, not a global novelty claim or a fresh remote-main survey.

The selected physics-loop procedure and its applicable discovery, premise,
delivery, and proof-search requirements were used with the owner's narrower
external-file brief. No branch, primitive, audit, prompt, or prior packet was
edited. Local-main instruction identities and source checks are in the
receipt. No new specialized scattering theorem is imported below: the
estimates use explicit bounded operators, integration, and the spectral
theorem; the averaging identity is proved directly.

## 2. Exact zero-space decomposition at K=0

Write s(q)=sin q, epsilon(q)=|s(q)|, let c be the normalized singlet, and
let T_j=sigma_(1,j)c. The three T_j are an orthonormal Cartesian triplet
basis. In singlet/triplet coordinates the supplied free symbol at K=0 is

    H0(0,q) = [ 0       2s(q)^T ]
              [ 2s(q)  0_(3x3) ].                         (L1)

The antisymmetric fiber has an even singlet coefficient and odd triplet
coefficients under q -> -q. The vectors below have those parities. At
almost every q the free kernel consists of transverse triplets u with
s·u=0. The two remaining energies are +/-2epsilon. Values at the eight
cone points can be chosen arbitrarily because they have measure zero.

Define

    I0 = integral dq/[4epsilon(q)^2],
    zeta(q) = [s(q)·T]/[2epsilon(q)^2 sqrt(I0)].            (L2)

Near each cone the squared norm has an integrable 1/|q|^2 singularity in
three dimensions. Therefore I0 is finite and zeta is a normalized vector.
It is orthogonal to c pointwise and orthogonal to every free transverse
zero mode. Direct multiplication gives

    H0(0) zeta = c/sqrt(I0),
    H_D(0) zeta = P H0(0) P zeta = 0.                    (L3)

Thus the notation H0^{-1}c is valid only as the reduced inverse on the
orthogonal complement of the free kernel, evaluated on this particular
vector c. H0 has no bounded inverse on the whole fiber.

This is the entire additional physical zero space. If psi belongs to P
and H_D(0)psi=0, then H0(0)psi=alpha c for some scalar alpha. Subtract
alpha sqrt(I0) zeta and obtain a free-kernel vector. Conversely every such
vector lies in P and is killed by H_D(0). Consequently

    ker H_D(0)|_P = ker H0(0) direct-sum span{zeta}.        (L4)

The full extension P H0 P also has the auxiliary vector c. It must not be
counted as a physical state. Neither the free flat band nor the dispersive
energies approaching zero leave a spectral gap around zero. An isolated
finite-multiplicity eigenvalue perturbation theorem is inapplicable.

For later explicit estimates, changing variables u=sin q in the eight
charts gives, for 0<r<=1/2,

    integral_(epsilon<r) epsilon^-2 dq <= r,
    integral_(epsilon<r) dq <= r^3/3,
    integral_(epsilon>=r) epsilon^-4 dq <= 9/r,
    1/12 <= I0 <= 9/8.                                  (L5)

Indeed the radial coefficient is at most
4/[pi^2(1-r^2)^(3/2)] <=32/(3sqrt(3)pi^2)<1. The first
two inequalities follow by radial integration. For the third, integrate
u^-2 from r to 1/2 with that coefficient and bound the remaining integrand
by 16; 1/r+16<=9/r. The last bound uses epsilon^2<=3, the first inequality
at r=1/2, and epsilon^-2<=4 outside that region.

## 3. Arbitrary free-band packets and an explicit maximizing family

At K=0 the positive contact spectral density for 0<E<2 is

    rho(0,E)=E^2/(16pi^3) integral_(S^2)
                 product_j (1-E^2 n_j^2/4)^(-1/2) dOmega. (L6)

This can be derived without a limiting-absorption theorem: the ++ contact
weight is 1/2, E=2epsilon, and the eight sin-coordinate charts have the
Jacobian displayed in L6. In particular

    E^2/(4pi^2) <= rho(0,E)
       <= E^2/[4pi^2(1-E^2/4)^(3/2)].                    (L7)

For any positive spectral interval I, the squared norm of the free-band
part of zeta is

    w_I = ||1_I(H0)zeta||^2
        = I0^-1 integral_I rho(0,E)/E^2 dE.              (L8)

Thus every normalized free-band phi satisfies |<zeta,phi>|^2<=w_I,
with equality for phi=1_I(H0)zeta/sqrt(w_I). If chi=Pphi/||Pphi||,
then its conserved zeta weight is |<zeta,phi>|^2/(1-|<c,phi>|^2).
The contact loss is O(lambda^3) for I contained in [lambda,2lambda],
whereas w_I can be of order lambda. This is a statement about a component
of the physical state, not about canonical current.

Use a=5/4, b=7/4, I_lambda=[a lambda,b lambda], 0<lambda<=1/16, and set

    Gamma_lambda=1_I_lambda(H0(0)),
    w_lambda=||Gamma_lambda zeta||^2,
    phi_lambda=Gamma_lambda zeta/sqrt(w_lambda),
    beta_lambda=<c,phi_lambda> >0,
    n_lambda=sqrt(1-beta_lambda^2),
    chi_lambda=Pphi_lambda/n_lambda,
    A_lambda=<zeta,chi_lambda>=sqrt(w_lambda)/n_lambda.    (L9)

All these are explicit normalized L2 vectors. Sharp spectral endpoints
are permitted. They require no Cook smoothness assumption. Equations
L6–L8 give

    w_lambda=lambda/(8pi^2 I0) [1+O(lambda^2)],
    beta_lambda^2=9lambda^3/(32pi^2) [1+O(lambda^2)].       (L10)

The constants follow by integrating E^0 and E^1, respectively; more
explicitly beta_lambda=(I0 w_lambda)^(-1/2) integral_I rho(0,E)/E dE.
The state lies in the singlet/longitudinal-triplet subspace and has no
free flat-band component. Its physical zero projection is exactly
A_lambda zeta. In particular

    liminf_(t->infinity)
       ||exp(-itH_D(0))chi_lambda-exp(-itH0(0))phi_lambda||
       >= A_lambda.                                    (L11)

To prove L11, test the difference against zeta. The first scalar
coefficient is A_lambda; the second is the Fourier transform of the
integrable positive density rho(E)/(I0 sqrt(w_lambda) E^2) on I_lambda,
and tends to zero. This rules out uniformly retaining the original
O(lambda^(3/2)) state comparison for this family. It says nothing by
itself about a uniform O(lambda^4) canonical-current bound.

## 4. An explicit finite-time averaging bound

Let M_T=T^-1 integral_0^T exp(-itH_D(0)) dt. For the family in L9,
the following estimate is valid whenever T>=max(2,2/(a lambda)):

    ||M_T chi_lambda-A_lambda zeta|| <= E_lambda(T),

    E_lambda(T)=4/(a lambda n_lambda T)
       +2 beta_lambda sqrt(I0)/(n_lambda T)
       +3 A_lambda/[sqrt(I0) sqrt(T)].                   (L12)

Here is a constructive proof, so no unquantified mean-ergodic convergence
rate is being used. Put n(q)=s/epsilon and write vectors in the invariant
singlet/longitudinal space as (F,G), meaning F c+G n·T. On P, integral F=0,
and the compressed operator acts as

    H_D(F,G)=(P_s[2epsilon G], 2epsilon F),
    P_s f=f-integral f.                                 (L13)

Write chi_lambda=(F,G). For x=chi_lambda-A_lambda zeta, the formal
inverse singlet component is

    f=G/(2epsilon)-A_lambda/(4sqrt(I0)epsilon^2).

It has integral zero but is generally not square-integrable. This is
precisely a place where a naive inverse/gap argument fails. Its triplet
partner g=F/(2epsilon) is square-integrable. For 0<r<=min(1/2,a lambda/2),
use the allowed singlet

    f_r=1_(epsilon>=r) f-m_r,
    m_r=integral 1_(epsilon>=r) f
       =A_lambda/(4sqrt(I0)) integral_(epsilon<r)epsilon^-2.

Set xi_r=(f_r,g). Direct application of L13 shows that the residual
H_D xi_r-x has only a triplet component,

    A_lambda/(2sqrt(I0)epsilon) 1_(epsilon<r)-2epsilon m_r.

Using L5, the free-band lower bound 2epsilon>=a lambda, and triangle
inequalities gives

    ||H_D xi_r-x|| <= A_lambda sqrt(r)/sqrt(I0),
    ||xi_r|| <=2/(a lambda n_lambda)
       +beta_lambda sqrt(I0)/n_lambda
       +A_lambda/[sqrt(I0) sqrt(r)].                    (L14)

For example the two terms in the residual have norms at most
A_lambda[ sqrt(r)+sqrt(3/2)r ]/(2sqrt(I0)), which is bounded
as stated for r<=1/2. The epsilon^-4 estimate controls f_r; the
subtracted constant uses |m_r|<=A_lambda r/(4sqrt(I0)).

Boundedness of H_D allows direct differentiation of its unitary group:

    M_T H_D xi_r = i[exp(-iT H_D)-I]xi_r/T.

Its norm is at most 2||xi_r||/T. The residual contributes its norm.
Set r=1/T to obtain L12. This argument explicitly handles the threshold
singularity rather than assuming x belongs to the range of H_D.

Let Q be multiplication by 1_(epsilon>=1/2). Write

    Z_Q=||Qzeta||^2 >=23/324.                            (L15)

Indeed the excluded low-epsilon volume is at most 1/24, and
epsilon^-2>=1/3 elsewhere; combine this with I0<=9/8. Jensen's inequality
and L12 now give the finite-time bound

    (1/T) integral_0^T ||Q exp(-itH_D(0))chi_lambda||^2 dt
       >= [ A_lambda sqrt(Z_Q)-E_lambda(T) ]_+^2.         (L16)

Initially Qphi_lambda=0, and the projected state has Q-weight only
beta_lambda^2 ||Qc||^2/n_lambda^2=O(lambda^3). At T=lambda^(-7/4),
E_lambda(T)=O(lambda^(3/4))=o(A_lambda), whereas A_lambda^2 is of
order lambda. Thus the actual finite-time averaged high-momentum weight
is bounded below by a positive constant times lambda. No matching upper
bound is asserted here. The statement concerns this explicit family;
other packets can have zero overlap with zeta.

## 5. Transfer to nonzero K without an eigenvalue-persistence claim

In the fixed coordinate chart P and c are K independent. The sine
Lipschitz bound and the Pauli norm give

    ||H_D(K)-H_D(0)|| <= |K|,
    ||exp(-itH_D(K))zeta-zeta|| <= |K| |t|.               (L17)

These are bounded-operator estimates, not analytic perturbation of an
isolated eigenvalue. They do not prove a zero eigenstate at K!=0.

For |K|<=lambda/16, let Pi_++(K,q) be the product of the two positive
one-body projectors, and form the normalized vector

    phi_(lambda,K)=Pi_++(K)phi_lambda/
                              ||Pi_++(K)phi_lambda||.    (L18)

It has the same q support as phi_lambda. There each one-body energy
at K=0 is at least 5lambda/8, and changes by at most |K|/2. The
positive-projector formula (I+ahat·sigma)/2 therefore gives

    ||Pi_++(K)phi_lambda-phi_lambda|| <=2|K|/lambda,
    ||phi_(lambda,K)-phi_lambda|| <=4|K|/lambda.          (L19)

The sum of the positive one-body energies changes by at most |K|;
hence L18 is an actual free [lambda,2lambda]-band packet at K. Its
support also has normalized q volume at most lambda^3/3 by L5, so
the contact weight is at most lambda^3/3. Normalized projection is
Lipschitz with constant at most four here, yielding for the two allowed
initial states

    ||chi_(lambda,K)-chi_lambda|| <=16|K|/lambda.

Duhamel applied to the two bounded generators then gives

    ||exp(-itH_D(K))chi_(lambda,K)
                 -exp(-itH_D(0))chi_lambda||
       <=16|K|/lambda+|K| |t|.                          (L20)

The same estimate holds for normalizable total-momentum packets using
one global contact projection and normalization. To see this, choose
any normalized scalar K envelope f_lambda supported in
|K|<=kappa<=lambda/16 and start from
Phi_lambda(K)=f_lambda(K)phi_(lambda,K). Compare it to
f_lambda(K)phi_lambda, apply the global projection inequality, and
use the direct-integral generator norm bound kappa. No fiberwise
renormalization of the prepared global state is assumed.

With actual normalized global preparation Chi_lambda=P Phi_lambda/
||P Phi_lambda||, the finite estimate is

    (1/T) integral_0^T ||Q exp(-itH_D)Chi_lambda||^2 dt
       >= [ A_lambda sqrt(Z_Q)-E_lambda(T)
                        -16kappa/lambda-kappa T ]_+^2.  (L21)

The initial Q-weight is at most
(lambda^3/3)/(1-lambda^3/3)<=lambda^3. As one explicit choice, take
T=lambda^(-7/4) and a normalized envelope supported in the ball of
radius lambda^(5/2)/4 centered at (lambda^(5/2),0,0). This avoids
K=0, has kappa<=2lambda^(5/2), and lies in the prescribed central
domain for sufficiently small lambda. The two extra errors in L21
are O(lambda^(3/4)), so its lower bound is of order lambda.

A conservative entirely explicit range is 0<lambda<=10^-12. From
L5–L10, n_lambda>=1/2, beta_lambda<=1/2,

    sqrt(lambda)/(3pi) <= A_lambda <=2sqrt(lambda).

The total error in L21 is bounded by

    (42/5)lambda^(3/4)+6sqrt(12)lambda^(11/8)
                     +32lambda^(3/2)+4lambda^(7/4).

On the displayed range this is at most
sqrt(23) sqrt(lambda)/(108pi), half the lower estimate of
A_lambda sqrt(Z_Q). For an elementary numerical certificate, after division
by sqrt(lambda) use sqrt(12)<4 to bound the four terms by
42/5000+24/10^10+32/10^12+4/10^15<9/1000<1/108;
pi<4<sqrt(23) gives the claimed comparison. Consequently

    (1/T) integral_0^T ||Q exp(-itH_D)Chi_lambda||^2 dt
       >= 23lambda/(11664pi^2),
    ||Q Chi_lambda||^2 <=lambda^3.                      (L22)

The small numerical range is a conservative proof choice, not a
physical threshold or an optimized timescale. These nonzero-K
packets establish leakage without asserting that the K=0 eigenvector
continues as an eigenvector, and without using the unproved K~lambda
degenerate effective dynamics.

## 6. Why this does not yet give a canonical-current counterexample

The checked canonical placement has

    J_a(K)=P[sin K_a cos(2q_a)]P
             -|h'_a><h|-|h><h'_a|,
    h(0)=2s·T,
    h'_a/K_a -> -(1/2)s_a T_a.

On P define its linear coefficient L_a by J_a(K)=K_a L_a+O(|K_a||K|^2).
Let v=s·T and v_a=s_a T_a. Then

    L_a=P cos(2q_a)P+|v_a><v|+|v><v_a|.                 (L23)

Cubic symmetry of the normalized measure gives

    <zeta,s_a^2 zeta>=1/(12I0),
    <h,zeta>=1/sqrt(I0),
    <h'_a/K_a,zeta> -> -1/(12sqrt(I0)).

The free centered term and the finite-rank correction therefore give,
respectively,

    <zeta,(cos(2q_a)-1)zeta>=-1/(6I0),
    <zeta,(|v_a><v|+|v><v_a|)zeta>=+1/(6I0).

Thus <zeta,(L_a-I)zeta>=0 exactly. Omitting the physical placement
correction would produce a spurious leading current argument.

There is a stronger check for the particular cubic-invariant family
in L9. Let R project onto the singlet/longitudinal-triplet space.
It reduces H_D(0), contains c, and has H0(0)^2=4epsilon^2 I on R.
The square of the compression is P H0(0)^2 P-|h><h|. Combining this
with L23 yields the operator identity

    P R [sum_a(L_a-I)] R P = -H_D(0)^2/2.                (L24)

The evolved family remains cubic invariant. Its three expectations
of L_a-I are equal, so each is -||H_D(0)chi_lambda||^2/6 for every
time. Thus even its exact linear-in-K current response supplies no
drift witness. A proof or falsifier of uniform-in-time O(lambda^4)
canonical current needs more than the leakage construction.

## 7. Checks, failed routes, and the next obligation

The supporting helper and complete logs are in
`excluded_walk_long_time/`. They check the spin-block identity,
compression kernel, projection preparation, cutoff inverse residual,
finite-time averaging identity, and canonical cancellation from actual
matrices or rational fields. Exact and floating checks are identified
separately in the receipt. They are author checks, not an independent
review or an infinite-volume numerical proof. No prior source runner
was replayed as independent evidence.

`long_time_checks.py`, SHA-256
`4ddc0e1972c6ab13c269ac2f7c18b38811be1d9087a4052df53940cc24245a86`,
completed 36 checks with no failure. The exact nine-pair antipodal fixture
has free-kernel dimension 18 and physical compressed-kernel dimension 19;
its I0 is 301/48 and its two canonical coefficients are -8/301 and +8/301.
Those are the finite fixture's actual values, not torus quadrature estimates.
Actual spectral matrix averages at T=3.4,20,50 obey the residual bound.
Six actual source-copy mutants separately change the inverse factor,
measure normalization, compression, physical/auxiliary zero-space split,
cutoff mean, and canonical correction. Every process exited 1 at its
intended assertion; complete tracebacks were read. The harness used Python
3.13.5, NumPy 2.4.4 and SymPy 1.14.0, with a 90-second limit per process.
Inputs are literal and deterministic. The source/log manifest and receipt
bind exact commands, versions, changes and outputs; this count does not
establish independent verification or completeness of the proof checks.

The attempted or excluded inferences are precise:

1. The contact atom of the free K=0 spectral measure is zero, but that
   does not remove the new compressed zero vector. The reduced inverse
   explicitly constructs it.
2. Projecting a small-contact free band packet does not keep it in that
   band for all times. L21–L22 give a constructive longer-time example.
3. A bounded inverse of H_D on the complement of zeta is unavailable;
   the formal inverse in Section 4 fails to be L2. Cutting it off gives
   the usable quantitative averaging estimate.
4. Ordinary isolated-eigenvalue perturbation cannot handle K~lambda.
   The proved transfer uses a bounded-generator estimate and the
   smaller regime K=O(lambda^(5/2)).
5. Treating compressed free current as the canonical placement current
   gives the wrong leading dressing contribution. The cancellation in
   L23 and the conserved trace identity L24 preserve this failed route.

The remaining target is an estimate for the actual canonical current
of arbitrary projected central-band packets on times of order
lambda^-1 and beyond, uniformly for K=O(lambda), or a correctly
constructed counterexample. A possible next object is the effective
generator on the full degenerate zero space, including both zeta and
the free transverse modes. That analysis is not supplied here and
is not hidden inside the transfer estimate. Uniform current control
is a distinct, stronger obligation than proving this zero-mode and
leakage result. All supplied walk, clock, Hilbert-space, exclusion,
and canonical-density premises remain explicit.
