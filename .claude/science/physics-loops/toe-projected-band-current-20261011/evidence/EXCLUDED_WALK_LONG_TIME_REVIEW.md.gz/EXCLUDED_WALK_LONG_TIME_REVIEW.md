# Independent check of the long-time band-leakage probe

2026-10-11. This is a source-bound research review, not a formal audit,
retained-status decision, or machine-checked proof. No repository or worktree
source, author draft, previous review, audit record, or editable prompt was
changed. The selected model and reasoning effort were preserved.

No consequential defect was found in the frozen probe's stated zero-space,
finite-time averaged leakage, small-nonzero-K transfer, or canonical-cancellation
claims. In particular, L22 follows with its displayed constants and conservative
range. The physical zero vector is distinct from both the free flat modes and
the auxiliary contact vector. The leakage construction does not establish a
canonical-current counterexample; L23–L24 correctly preserve the failure of
that proposed inference.

## 1. Exact sources and coverage

S is `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The sibling publication worktree is
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/walk_worktree`.
Unqualified paths below are relative to S.

| Source | SHA-256 and actual coverage |
| --- | --- |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324`; all 457 lines read and all L1–L24 reconstructed. |
| `excluded_walk_long_time/receipt.json` | `bdd9d7b0caedbf168f4e45dead01b7a816f321b5894ae5671c1dcdedb81d35dc`; read completely. Its historical local-main identity is preserved as historical evidence. |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526`; prior complete 322-line reading and independent threshold reconstruction reused unchanged. Only the actual stated model/density premises are used here. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`; prior complete 190-line reading and independent current reconstruction reused unchanged. |
| `EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md` | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7`; prior complete 262-line reading reused for the distinction between remote-time regular packets and the present sharp-band, time-zero projection. Its quantitative scattering hypotheses are not imported into this proof. |
| `EXCLUDED_WALK_THRESHOLD_REVIEW.md` | `9168b32dac2634152aa54431dc47dbb91e019818afdc9d84c40c717d51c3f952`; unchanged prior independent premise record. |
| `EXCLUDED_WALK_PUBLICATION_REVIEW.md` | `fe27f1404d47207a20c815912033d575c79bce6cfb915833460db27a871b9c5b`; unchanged prior combined current/scattering review, not changed by this new investigation. |
| Supplied M6 walk-contract note | `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`; the exact long filename is in the probe's source table. Prior complete 226-line reading reused; current publication-worktree bytes and the identified main object agree. |
| Supplied two-walker binding note | `50c708e3742f9a5daa59f6f1fb48b44fe388d71b9fc2454ede1a9595185d332d`; exact filename is in the probe's source table. Prior complete 106-line reading reused; its attractive-contact result is not a classification of this compressed kinetic threshold state. |
| `excluded_walk_long_time/long_time_checks.py` | `4ddc0e1972c6ab13c269ac2f7c18b38811be1d9087a4052df53940cc24245a86`; complete author helper read after constructing the independent fixture. It was not replayed as independent evidence. |

The author baseline log, mutation driver, full manifest, and all six complete
mutant tracebacks were also read. Their source-copy edits and identities were
checked, but those author executions were not rerun or counted as independence.
The new receipt records the necessary source and evidence hashes.

In the publication worktree, `origin/main` resolves to the supplied current
object `a13caa4885f547c8d206265b031ba7649e539fd9`, while the local branch named
`main` still resolves to `e485eab6b09b3957df5772104d3ea3980108d7fa`. The new
bounded repository statement search explicitly used the a13 object. Its
13 matching lines concerned other threshold/static statements and the known
conditional scattering boundaries, not a matching statement of L4 or L22.
The command and complete output are saved in
`excluded_walk_long_time_review/main_statement_search.{json,log}`. This
literal search is not an exhaustive novelty or literature claim. No fetch
or other network action was taken by this review.

## 2. Physical zero space and the threshold inverse

The Pauli/singlet identities give an orthonormal triplet basis
`T_j=sigma_(1,j)c`. At K=0 the difference of the two Pauli spins exchanges
the singlet and the triplet parallel to s, and annihilates transverse
triplets. Thus its matrix is exactly L1, with off-diagonal row `2s^T`.
Even singlet and odd triplet coefficients implement the required exchange
antisymmetry. The cone points are a null set and create no additional L2
states supported only there.

The vector `u=s·T/(2epsilon^2)` satisfies `H0 u=c`, has squared norm I0,
and is pointwise orthogonal to the singlet. In three dimensions its squared
norm behaves as `1/(4|q-C|^2)` near each cone and is locally integrable.
Consequently `zeta=u/sqrt(I0)` is a normalized physical vector and
`P H0 P zeta=0`. It is pointwise longitudinal and therefore orthogonal to
all free transverse flat modes.

Completeness of the zero-space description does not require a scattering
argument. If psi is in P and `P H0 P psi=0`, then `H0 psi=alpha c` for one
global scalar alpha. Pointwise, its triplet equation forces its singlet
coefficient to vanish almost everywhere. Subtracting
`alpha sqrt(I0) zeta` leaves precisely a transverse free-kernel field.
Conversely, those fields and zeta all lie in P and are killed by H_D.
This proves the orthogonal sum in L4. The full zero extension also kills c;
that vector is not an allowed physical state.

In particular, a zero contact atom in the free K=0 measure does not exclude
the new compressed zero vector: the contact has zero overlap with the free
flat kernel, yet has an L2 reduced inverse. Writing H0 inverse without the
reduced-domain qualification would be false; the source gives that
qualification explicitly.

There is no positive gap on the physical complement of the zero space.
For an explicit check, an even singlet field proportional to
`1_(epsilon<r)(cos(2q1)-cos(2q2))c` has zero mean by coordinate exchange.
After normalization it lies in P and is orthogonal to both zeta and the
free transverse kernel, while `||H_D psi||<=2r`. This also shows directly
why isolated-eigenvalue or bounded-inverse arguments cannot be substituted
for the source's cutoff construction.

## 3. Measure estimates and the prepared band family

For epsilon<r<=1/2 the eight inverse-sine charts give radial measure
coefficient at most

    4/[pi^2(1-r^2)^(3/2)]<=32/(3 sqrt(3) pi^2)<1.

There is no half-torus or extra exchange normalization. Integrating this
coefficient against 1 and against u squared gives respectively
`integral_(epsilon<r) epsilon^-2<=r` and
`volume(epsilon<r)<=r^3/3`. For the inverse fourth moment, split at 1/2.
The inner contribution is at most `1/r-2`, and the outer one at most 16.
The source's looser bound `1/r+16<=9/r` remains valid for r<=1/2.
Finally, `epsilon^2<=3` gives I0>=1/12, and
`I0<=(1/2+4)/4=9/8`. All four L5 constants follow.

The exact density L6 has contact weight 1/2 and energy E=2epsilon. The
energy delta function contributes an additional factor 1/2, yielding
`E^2/(16pi^3)` times the sphere integral. These are different factors;
dropping either would change the prepared state's weight. The product of
the inverse-sine Jacobians gives L7 for 0<E<2.

The spectral relation `zeta=H0_reduced_inverse c/sqrt(I0)` proves L8.
For `I_lambda=[5lambda/4,7lambda/4]`, direct leading integrals give

    w_lambda=lambda/(8pi^2 I0)[1+O(lambda^2)],
    integral_I rho(E)/E dE=3lambda^2/(16pi^2)[1+O(lambda^2)],
    beta_lambda^2=9lambda^3/(32pi^2)[1+O(lambda^2)].

The second line divided by `sqrt(I0 w_lambda)` is the positive contact
amplitude, as stated. The initial positive-band projection of zeta contains
only a singlet and a longitudinal triplet. Removing its constant singlet
mean does not add a transverse component, so its physical zero projection
is exactly `A_lambda zeta`, with `A_lambda=sqrt(w_lambda)/n_lambda`.

Testing the time-evolved comparison against zeta proves L11: its interacting
coefficient stays A_lambda, whereas the free coefficient is the Fourier
transform of an L1 band density and tends to zero. This is a state-norm
obstruction for the particular preparation, not an observable-current
obstruction. Sharp spectral endpoints are allowed in this argument.

## 4. Constructive cutoff and every constant in L12–L16

In the longitudinal representation, P subtracts the **global singlet mean**;
it does not remove the singlet at every momentum. The operator therefore
acts as `(F,G)->(P_s(2epsilon G),2epsilon F)`. For the normalized allowed
state, let `x=chi-A zeta`. Its forced inverse singlet component is

    f=G/(2epsilon)-A/(4sqrt(I0)epsilon^2).

The first term integrates to A sqrt(I0), as follows directly from
`<zeta,chi>=A`; hence f has zero mean. Below the band it equals the negative
second term. Its square has a nonintegrable inverse-fourth-power cone
singularity whenever A is nonzero. Thus for this family x is not in the
range of H_D on L2, even though it is orthogonal to its kernel. Adding
kernel vectors cannot repair the forced singlet component.

The triplet inverse `g=F/(2epsilon)` is in L2: write
`F=(F0-beta)/n`, with F0 band-supported and `||F0||<=1`. The constant
term is controlled by `||1/(2epsilon)||=sqrt(I0)`.

For `r<=min(1/2,a lambda/2)`, G vanishes on epsilon<r. Therefore the
cutoff mean is exactly

    m_r=A/(4sqrt(I0)) integral_(epsilon<r)epsilon^-2.

Subtracting m_r makes f_r an allowed singlet. Direct application of H_D
gives only the triplet residual displayed in the source. Its two terms
have norms at most

    A sqrt(r)/(2sqrt(I0)),
    A sqrt(3/2) r/(2sqrt(I0)).

Here `||epsilon||=sqrt(3/2)` uses the normalized torus average of each
sin squared. Since `sqrt(3/2) sqrt(r)<=1` for r<=1/2, their sum is at
most `A sqrt(r)/sqrt(I0)`, as in L14.

For the inverse norm, the band pieces of f_r and g each cost at most
`1/(a lambda n)`. The constant part of g costs `beta sqrt(I0)/n`.
The singular part of f_r costs at most
`3A/(4sqrt(I0)sqrt(r))`, using the inverse-fourth-power estimate. The
subtracted mean costs at most `A r/(4sqrt(I0))`. Since r<=1/2 and
`3+r^(3/2)<=4`, these last two costs are bounded by
`A/(sqrt(I0)sqrt(r))`. This reconstructs the full L14 norm bound.

For the bounded generator the exact averaging identity is

    M_T H_D xi=i(exp(-iT H_D)-I)xi/T.

Its norm is at most `2||xi||/T`, and `||M_T||<=1`. Since M_T zeta=zeta,
choosing r=1/T gives the three terms of L12 with coefficients 4, 2, 3.
The hypotheses `T>=2` and `T>=2/(a lambda)` are exactly what make this
choice of r allowed. No unquantified ergodic rate or spectral gap is used.

For Q at epsilon>=1/2, the low-region volume is at most 1/24. Thus

    ||Q zeta||^2
       >=(1/(4 I0))(1/3)(23/24)>=23/324.

Jensen applied to the Hilbert-space time average gives L16 with the
positive part. Initially Q phi=0 and `Q chi=-beta Qc/n`, so its squared
norm is of order lambda cubed. Q need not preserve P to define this
positive observable on physical states; its expectation there is its
quadratic-form compression. The time average lower bound concerns
probability in a high-free-momentum region, not canonical current.

## 5. Nonzero K and a single normalized direct-integral preparation

For each one-particle Pauli symbol the sine Lipschitz bound costs |K|/2.
Adding the two costs and compressing gives
`||H_D(K)-H_D(0)||<=|K|`, with no extra factor two. Duhamel proves L17
without requiring any eigenstate to persist at nonzero K.

On the original band's support, epsilon>=5lambda/8. For a nonzero vector
a, changing it by d changes its unit direction by at most `2|d|/|a|`.
The factor 1/2 in the positive Pauli projector therefore bounds each
one-body projector change by `4|K|/(5lambda)`. The tensor-product
projector changes by at most `8|K|/(5lambda)<=2|K|/lambda`. Normalizing
the projected unit vector costs at most twice its unnormalized distance,
which proves the two L19 constants. Its norm cannot vanish on the
specified |K| range.

The summed positive energy shifts by at most |K|. Hence L18 stays inside
the actual free [lambda,2lambda] band. Its q support remains contained
in epsilon<lambda, of normalized volume at most lambda cubed divided by
three. Cauchy-Schwarz against the unit constant singlet bounds the squared
contact amplitude by that volume, irrespective of the spin projector.

For two unit free states whose P projections have norms at least 1/2,
normalized projection is Lipschitz with constant at most four. Combining
this with L19 yields `16|K|/lambda`; the generator comparison adds
`|K| |t|`, exactly L20.

The global argument also checks. The scalar envelope is normalized using
the normalized K measure, and each free vector phi_(lambda,K) has unit
norm. Thus both Phi and its K=0 comparison field are normalized. Applying
the projection inequality to these two **global** fields gives
`16kappa/lambda`. Duhamel on their common K support adds kappa times t.
The reference allowed field is f_lambda(K)chi_lambda, with its one common
normalization n_lambda; no prepared fiber is individually renormalized.

Q is K-independent and the reference time average factors as
`f_lambda M_T(0)chi_lambda`. Its norm is therefore the single-fiber norm.
Averaging the state comparison costs at most
`16kappa/lambda+kappa T`; replacing the exact average T/2 by T is a
valid overestimate. Jensen then gives L21 without any additional volume,
normalization, or expectation-comparison factor.

The initial global removed contact mass is at most lambda cubed divided
by three. Since Q Phi=0, the initial Q probability is at most
`(lambda^3/3)/(1-lambda^3/3)<=lambda^3`. This holds even though the global
projection changes the normalized K law. The ball centered at
`(lambda^(5/2),0,0)` with radius `lambda^(5/2)/4` excludes zero and is
contained in `|K|<=2lambda^(5/2)`. A normalized L2 envelope on it exists;
a smooth bump can be used. This proves a normalizable nonzero-K statement,
not a fixed-K distributional one.

## 6. The explicit L22 certificate

The lower density bound gives
`w>=lambda/(8pi^2 I0)>=lambda/(9pi^2)`, so
`A>=sqrt(lambda)/(3pi)`. For an elementary upper estimate, the density
Jacobian factor is at most two on this band. Thus
`w<=lambda/(4pi^2 I0)<=3lambda/pi^2<=lambda`. The support-volume estimate
gives beta<=1/2 and n>=1/2, hence `A<=2sqrt(lambda)`. These finite
inequalities justify the source constants without extracting an unspecified
numerical constant from the O terms in L10.

At `T=lambda^(-7/4)` and `kappa<=2lambda^(5/2)`, the first term of L12
is at most `(32/5)lambda^(3/4)`; kappa T supplies another
`2lambda^(3/4)`. The third L12 term is at most
`6sqrt(12)lambda^(11/8)`. The preparation-distance term is at most
`32lambda^(3/2)`, and the remaining L12 term is bounded by
`4lambda^(7/4)`. This gives exactly the displayed total error with 42/5.

For `0<lambda<=10^-12`, division by sqrt(lambda)
and the elementary bounds in the source give

    42/5000+24/10^10+32/10^12+4/10^15
                         <9/1000<1/108
                         <sqrt(23)/(108pi).

The strict last inequality follows from pi<4<sqrt(23). All powers are
monotone on this range, so the endpoint check controls the full interval.
The same range satisfies the cutoff-time requirement and the central K
restriction. It follows that the error is at most half the lower estimate
`sqrt(23) sqrt(lambda)/(54pi)` for `A sqrt(Z_Q)`. Squaring yields

    averaged Q probability >=23lambda/(11664pi^2).

No matching upper bound of order lambda follows from this proof. The
explicit range is mathematically sufficient but not an optimized physical
threshold or time scale. The very long averaging time is in the supplied
clock units; no rate interpretation has been established.

## 7. Canonical current: both cancellations are valid

The checked current has h(K)=2 sum_j cos(K_j/2)s_j T_j and
`h'_a=-sin(K_a/2)s_a T_a`. Taylor expansion in the bounded operator norm
gives L23 with error `O(|K_a||K|^2)`. The sign and both rank-one terms
are necessary. Cubic symmetry gives the source's three scalar integrals,
and the negative centered free contribution `-1/(6I0)` is exactly
cancelled by the positive finite-rank contribution `1/(6I0)`.

The trace identity admits a direct operator verification. Summing the
centered free multipliers gives `-2epsilon^2`. Summing the corrections
gives `2|v><v|=|h><h|/2`. On the singlet/longitudinal reducing space,
`H0^2=4epsilon^2`, while squaring the compression gives

    H_D^2=P H0^2 P-|h><h|.

R commutes with P because c belongs to R. Multiplying by RP as in the
source therefore gives precisely `-H_D^2/2`, proving L24. There is no
assumption here that a general individual L_a preserves R.

The L9 family is invariant under the proper cubic rotations acting
simultaneously on momentum and spin. These rotations permute the three
L_a coefficients; H_D(0) commutes with them. Thus the three expectations
of L_a-I are equal at every time and their sum is the conserved
`-||H_D(0)chi_lambda||^2/2`. Each equals the stated one-sixth expression.
This is the reference K=0 evolution and its current coefficient at zero;
it is not a uniform expansion of nonzero-K dynamics over arbitrarily
long times. The source does not make that stronger inference.

Accordingly, neither the dressing weight, L11, nor the L22 leakage lower
bound proves drift of the specified canonical current. Removing the
placement correction would change the observable and create a spurious
leading-current argument. The still-open arbitrary-packet, K of order
lambda, long-time current question remains open after this check.

## 8. Independent controls, failures, and verification limits

New files are in `excluded_walk_long_time_review/`:

| Artifact | SHA-256 |
| --- | --- |
| `independent_long_time_controls.py` | `eabc48691f43da37b1c77a5a3bebaa11b0b6e4c2dcba6871a0a1ac36ec1d7775` |
| `independent_long_time_controls.log` | `49fc49dd0c2e99e3e018d314e85871d3ba18fcc37fea115854beb51f123a6538` |
| `independent_long_time_controls_initial_type_failure.py` | `bb10b13ea6b871a33969de4ec37b5f0654a92e4c573187dfe59477e437282253` |
| `independent_long_time_controls_initial_type_failure.log` | `aac0d1c8b6772e1d927811d88743453a3801664e82144216b5049fdfa1371209` |

The new helper imports no author or repository science code. Its fixture is
four non-cubic antipodal momentum pairs with exact rational sine vectors;
it differs from the author's nine-pair cubic fixture. Exact matrices give
free-kernel dimension 8, physical compressed-kernel dimension 9, and full
extended-kernel dimension 10. The physical projector is the sum of the
free transverse projector and the zeta projector, and kills c.

The helper builds an actual positive-band eigenvector, normalizes its
contact projection, and computes the cutoff inverse and residual exactly.
It also checks all three canonical zeta cancellations on this non-cubic
fixture. Their unequal individual values emphasize that the trace operator
identity does not itself need cubic symmetry; equal expectations for the
source's evolving family additionally use that family's symmetry.

Actual finite spectral averages at T=7/3,19,101 verify the averaging sign,
the cutoff residual bound, Jensen's inequality, and the conserved trace.
These are finite-matrix identities, not a numerical simulation of the
torus continuum or an empirical confirmation of L22. In particular, this
fixture's I0 is 5860/9 and does not obey the torus measure bound 9/8; no
continuum estimate is inferred from that artificial measure. The continuum
constants were checked analytically above and by separate exact rational
arithmetic for the final certificate. Direct leading-band integrals also
recover both coefficients in L10.

The initial helper run reached the zero-space checks, then failed because
Python `int` does not accept SymPy's BooleanFalse. The source and complete
traceback are preserved. Replacing this conversion with an explicit Boolean
branch was the only repair; no mathematical formula or assertion was
weakened. The final run exited 0 in 0.158 seconds under Python 3.13.5,
SymPy 1.14.0, and NumPy 2.4.4. Its full log was read. The command was
`python3 independent_long_time_controls.py` in the new evidence directory.

The author's complete helper, baseline log, and six source-mutation
tracebacks are consistent with their reported finite-algebra scope. Those
records do not prove the infinite-dimensional theorem and are not counted
as an independent replay. No actual theorem counterexample was found or
discarded during this review.

Possible future formalization obligations include the antisymmetric
singlet/triplet decomposition, the reduced-inverse domain and complete
physical kernel, the cone-measure inequalities, cutoff residual and
averaging bound, global normalization under the K direct integral, and
the canonical compressed-square identity. No Lean execution is claimed.
These are separate from adopting the supplied walk or proving a physical
transport law. The frozen probe requires no source repair within the
bounded claims checked here.
