# Memory/current publication composition review

2026-10-11. Bounded source-bound review of the frozen external composition.
This report does not apply an audit verdict, certify future delivery, or
independently re-certify this reviewer's own earlier memory/weighted proofs.

## 1. Finding and frozen target

No consequential composition defect was found. The complete assembled
argument preserves the physical space, current placement, absolutely
continuous dressing premise, same-space Kato comparison, regulated outgoing
formula, exact selected-datum lower bound and the specified global
growing-time packet limit. The finite all-T comparison is used with its
actual parameter domain; no fixed-time limit is substituted at a growing T.
No source repair is requested within this review's scope.

| Frozen input | SHA-256 |
|---|---|
| `FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md`, all 1,556 lines | `c05465cee9acb7ee1bc9b0296b4fd5546432bd8188043194b1701a2d3654ef87` |
| `excluded_walk_memory_current_2026_10_11.py`, all 507 lines | `b5cfe4af2e2e56f6a531afaa36c19daded1003d91b3a861ebe177ba87a0ebc33` |
| `memory_current_composition/SOURCE_COMPOSITION.json` | `ffe3df5cd8633fa927bbe78e7fbfbeffd7c96efc30dbc969d0c0bf24a31e0fa2` |
| `memory_current_composition/receipt.json` | `9dea961421ca868bd4def5eecb5c45982b5c5a421ed49c945f31cac8dd2f2ea6` |

All paths without a prefix are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The companion receipt supplies absolute identities and the exact reading
scope. These findings concern these bytes, not subsequent publication edits.

The result remains a supplied-model conditional theorem for the dressing
and one specified projected free-band family. In particular, the current
change has a strictly negative joint-limit coefficient, while its explicit
lower bound does not provide a convergence rate or finite sign-onset time.
The current's final absolute sign, arbitrary preparations, a collision clock,
Markovianity and many-body closure are not conclusions of this composition.

## 2. Sources, reused readings and independence

The full composed note and primary were read in this task. The map's
original/new source substitutions, editorial descriptions and all new prose
were read, and every source/output byte range was independently reconstructed.
An oversized initial map display was truncated; it was not treated as
completed coverage. The subsequent bounded reads and reconstruction close
that inspection gap.

| Key and source | SHA-256 | Actual source coverage |
|---|---|---|
| M: `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Complete earlier 500-line author reading reused; every selected E1-E29 proof passage was read again in the assembled note and exact source matching was verified. |
| W: `EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md` | `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324` | Complete earlier 339-line author reading reused; the full selected W1-W17 proof chain was read again in the composition. |
| G: `EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md` | `4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278` | Complete 236-line reading from the immediately preceding outgoing review reused; full G1-G10 composition and bridges read here. |
| P: `FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md` | `ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969` | Complete earlier 859-line composition reading reused. Lines 169-362 and 403-510 refreshed here, including general D11, both finite comparisons and Q16. All newly selected physical/current/preparation passages read in the assembled note. |
| D: `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Complete earlier 549-line author reading reused. All selected D12-D16/D18-D21 passages read here in their matched publication positions. |
| L: `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Complete earlier 457-line author reading reused; the selected L10 normalization/asymptotic paragraph read here. |
| R: `EXCLUDED_WALK_OUTGOING_RESOLVENT_DRAFT.md` | `58a96a049701667e673bde1acf98e5346356483101654b3464fe11e94fd02c21` | Complete 245-line independent extension review just finished at unchanged bytes; full R1-R14 re-read in Section 15 and all substitutions inspected. |

The parent low-energy/current note remains
`9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401`.
The earlier reading of its lines 1-103 and complete canonical Section 7,
lines 393-472, is reused; this is not a new full reading or review of its
1,280 lines. Its other stationary-scattering, Cook and flux arguments are
not premises of this composition.

The prior complete review readings remain bound to memory review
`c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0`
(329 lines), weighted review
`a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484`
(319), and joint review
`2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6`
(252). The complete new joint dependency addendum and its receipt were
read here: `8ef5245b3301a19338eedfc8f3f98610b6d3162538b80fbe01bfaf27e5a1273a`
and `151aeb2e37648b0ef468e40538b4d0ce11707a1fe3a704239b946e559a5d82bb`.
They bind the completed weighted review without changing the old joint
report. This dependency matches G2-G3 exactly.

The preceding outgoing review is
`8eb1d81e91227a0cda36e75459e32be80b1523709a5f82fc5af4c1e8fd6d74de`,
and its receipt is
`c5fb2219ef98d4abce39ef98be784e5c7d1ffde0054cd867214f4713226ba6e0`.
The preceding projected-current composition review is
`076021427ff4e2cbb473363e09b3a043c2a4bae01d24bdfc69a6a42a55be8cf1`.
Those completed checks are reused at exact identities, without relabeling
old author work as new independent review.

I authored M, W, D and L. This check independently assesses root's selection,
substitution, connecting arguments and wrapper; it does not independently
certify those original proofs. The separate source reviews retain their
own scope. Earlier primary Kato reading is likewise reused at archived PDF
`12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`:
all five extracted pages and original pages 260 and 263 had been inspected.
The theorem and hypotheses are unchanged; no new network import was made.

## 3. Exact source selection and substitutions

The note is exactly the concatenation of all 59 ordered map chunks:
29 source fragments and 30 editorial chunks, many of the latter only
headings or paragraph separators. Source line ranges, UTF-8 byte ranges,
original hashes, each unique replacement and final output ranges match.
All 36 source substitutions produce exactly the supplied note, with no
unlisted changes. The full edit inventory is preserved in the controls JSON.

All E1-E29, W1-W17 and R1-R14 tagged display paragraphs are byte-identical
to their original sources, as are G1 and G4-G10: 68 exact blocks in total.
G2-G3 are the two deliberate restatements, using the already reproduced
W7/W9 norm-one comparison and weighted limit. Their changed grouping does
not change a vector, norm, sign, quantifier or convergence hypothesis.

The substitutions in chunks 3, 7, 13, 17, 21, 25, 27, 29, 35, 43,
45 and 49 change source pointers, local definitions, grammar, headings or
limit-order context. Their new referents exist and have matching hypotheses.
Chunk 15 scopes the old no-numerical-lower-bound sentence to the null-set
argument. Chunk 51 integrates the whole R proof with eleven internal
reference/heading substitutions. Chunk 57 preserves the distinction between
the newly bounded selected datum and arbitrary unit transverse vectors.
These limitation changes are justified by the included R proof; they do
not silently strengthen the earlier positivity argument.

The historical recovery index was also checked. All 16 recorded recovery
files match their original hashes. Applying the exact historical line edits
reconstructs both the current note and primary from their preserved earlier
bytes. Historical receipts can still name the then-current original paths;
the explicit recovery index supplies the correct preserved files. This is
identity/recovery verification, not substantive re-review of every historical
artifact or claim.

## 4. New bridges and premise compatibility

The new introduction names the supplied walk, clock, antisymmetric pair
sector, exclusion and canonical placement. Its summary coefficients and
current-limit normalization match G10 and R13-R14. It correctly distinguishes
the current change from a universal sign or monotone decay law.

The L4/Q3 zero-space definition, E1/E2 block, D21 nonzero coupling and W2
fixed Hilbert space are compatible: F is the odd transverse space (also
used for its projection), zeta is normalized and longitudinal, and the
auxiliary constant singlet is excluded. The new transverse-block bridge
uses (I-nn^T)(d cross u)=(d dot n)n cross u for n dot u=0. B zeta is
transverse and its zeta expectation vanishes, giving the same signed g and
adjoint entry. No derivative or gapless inverse is applied to zeta.

The canonical-placement bridge names the actual additive symmetric density
and invokes the companion's bounded current extension from a finite-support
core. The reproduced D12-D16 formula retains both rank-one terms and the
exact dressing cancellation. D18's cross term, D19's full zero-space trace
and D20's proper cyclic symmetry all survive. The current is not replaced
by a derivative of the effective A.

The general fixed-vector bridge at the start of Section 11 is valid from
the companion's general D11 bound, not just its special zeta estimate.
For fixed z and finite T, the orbit {B exp(-itA)z: |t|<=T} is compact in
norm. E_sigma tends strongly to zero, with norm at most one, because its
spectral interval excludes the zero eigenspace. A finite norm net then
gives M_z(sigma,T)->0 uniformly on that orbit. Choose sigma small, then
the weak parameter small in D11. This proves the asserted compact-time
strong limit without a gap, but supplies no unit-ball uniformity or
automatic interchange with infinite time. The W13-W15 ordered limits and
their error separation retain exactly that scope.

The L10-to-G1 bridge is algebraically consistent: n_lambda^2=1-O(lambda^3)
and w_lambda=lambda/(8pi^2 I0)[1+O(lambda^2)] give the stated A_lambda^2/lambda
coefficient. The singular inverse, positive-band contact phase and one
physical normalization retain their original conventions.

The repeated delta and lambda symbols are explicitly separated: delta is
an edge margin in Sections 4-6 and R11-R12, but the weak momentum in the
original-walk comparison; lambda is weak momentum in Section 11 and a
free-band parameter from Section 12 onward. The equations use those local
meanings consistently. The genuine global packet uses common physical
time tau/delta, not different physical times for different fibers.

## 5. The finite all-T and global-current chain

Section 12 reproduces the complete domains needed from the companion:
0<lambda<=1/16, every finite T>0, delta>0, and
0<sigma<=min(1/2,5lambda/8). It states both the complementary low-mass
bound and the dressing-orbit bound before Q16. The complete two-cutoff-inverse
and finite evolution proofs remain in the explicitly named companion.
The present note does not claim that they follow from scalar memory decay.

At delta=lambda^3, sigma=lambda^2 and T=lambda^(-gamma), all cutoff domains
hold. For fixed 0<gamma<1/2, p=1/2-gamma is positive and the relative error
powers in G5 are p, 2p, 1/2 and 2+p. The explicit coefficients and
r_delta<=delta follow under the stated lambda range. There is no hidden
T-dependent compactness modulus in Q16 being treated as a constant.

The full physical-space trace Q18 is retained, including H_*^2 and
epsilon^2 F. It is not replaced by the compressed zero-space trace D19.
Conservation of H_D(delta kappa0)^2 bounds both endpoint energy errors
without a growing-time factor. In the current quadratic form the small
dressing amplitude A_lambda is retained: the transverse error costs
4A_lambda e+2e^2. Losing that factor would invalidate the normalization
by delta lambda. The canonical remainder and the complete two-sided G6
estimate are preserved.

The finite-K projector proof ensures an actual positive free-band vector
before contact projection, with the original q support. It does not claim
that projection or excluded evolution preserves the free band. Its
preparation Lipschitz constant and the bounded current norm/Lipschitz
estimates match the companion. Bounded Duhamel gives the new text's
all-finite-time form directly:

    ||U_(delta,kappa)(tau)-U_(delta,kappa0)(tau)||
      <= |tau| ||H_D(delta kappa)-H_D(delta kappa0)||/delta
      <= |tau| |kappa-kappa0|.

Consequently the stated uniform packet error is
520lambda+8lambda^(1-gamma)=o(lambda^p). Integrating against the actual
post-projection probability weights preserves it. The measure factors,
single global norm, positive-width support away from zero, physical center
lambda^3(1,1,1), radius lambda^5 and time lambda^(-(3+gamma)) agree.
No globally trace-class direct-integral perturbation or uniform scattering
theorem over the packet's momentum ball is assumed.

## 6. Memory, scattering and R1-R14 integration

The assembly preserves the complete local bath-density proof, the uniform
Poisson bound excluding interior singular dressing measure, and the
separate endpoint saturation argument. The E22 strict vector inequality
is not promoted to an operator-norm spectral gap. E23 concerns the dressing
spectral measure, not all of A's spectrum.

The Kato import remains on the same Z with bounded self-adjoint trace-class
V of rank two. The scalar block of A0 is atomic; only P_ac(D) is needed.
E23 places zeta in ac(A). The reverse positive-time wave operator supplies
the norm-one outgoing datum. These facts, rather than a(t)->0 alone,
justify W7-W12. The frozen primary theorem convention and the earlier
separate weighted review match the composition exactly.

Section 15 keeps every R1-R14 argument and its scope. In particular, the
Abel sign is positive M(D+ih)g; the helicity fields are pointwise and their
sum preserves odd parity; no pointwise boundary value is inserted. E24
supplies derivative decay for R9's second-moment comparison. The cone-mass
bound stays uniform for positive h and passes to the selected outgoing
datum by strong convergence. All powers, rational constants and the
selected-datum restriction match the preceding independent R review.

Replacing R14's external conditional pointer by Sections 12-14 is
legitimate: those sections establish the same G premises with explicit
companion inputs. It yields the same -c0/135 limiting upper bound, not a
computed onset. The comparison error remains relative to moving W(T),
and no rate for W(T)-W_+ is silently included.

The finite recurrence example and the continuous conjugacy toy remain
distinct controls with their proper scopes. The new evidence/footer text
does not turn either into a proof of continuum scattering. Earlier
leakage/nonuniformity observations and separate spectral-edge work are
not imported as stronger theorems or broad impossibility claims.

## 7. Primary execution, namespace and failure controls

All five string literals were extracted from the primary AST and matched
byte-for-byte to their original source files, including line counts and
declared hashes. The complete helper bodies and wrapper were read. The
five source blocks retain their mathematical code; no helper was silently
rewritten or only partly included.

The wrapper allocates a new namespace inside each iteration, uses that
same dictionary as globals and locals, sets __name__ to __main__ and gives
each body a synthetic source filename. Reading found no helper mutation
of shared imported-module state. Synthetic blocks passed through the
unchanged actual main function confirm order, main-guard execution,
function access to its own globals, and isolation of colliding variable
names. These are independently written wrapper controls, not author
mathematical replay.

Four deliberate cases confirm failure propagation: a wrong body hash, a
body assertion, an ordinary runtime exception and a syntax error. Each
exception escapes main, prevents the later helper and prevents the final
PASS. Their full expected tracebacks are preserved. They are in-memory
synthetic inputs to the actual wrapper, not separately executed source
mutations of the scientific helper programs.

The original author execution first stopped at a missing SciPy import,
before a mathematical control. Its complete traceback and the subsequent
development record were read. The final extended log records all five
blocks completing in order, bound to the current note/primary/map and exit
0 with Python 3.13.5, SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1. Its
declared timeout is 180 seconds. That record was inspected rather than
replayed; it remains author execution evidence.

The new control helper has SHA-256
`6f409349b6461d55c43f71689923912c5efd9dcef6615aef170b6cfb1a2c4203`;
its complete log has SHA-256
`ddd337a012791e6d1ce62181e2b6d86b61b105fd56e83ed4985ced7ca10de27c`.
The first formal run exited 0 under Python 3.13.5 with a 30-second timeout.
Its 921 assertions are mostly identity/range bookkeeping plus the wrapper
controls above, not 921 independent scientific tests. No original author
mathematical helper or builder was executed. Read-only inspection/launch
path mistakes and their corrections are recorded in DEVELOPMENT_LOG.md.

## 8. Remaining boundaries

This review covers the frozen composition and its actual wrapper. It does
not certify a future repository delivery pack, publication metadata refresh,
runner cache, new scientific mutations, Lean coverage, audit disposition or
landing. No numerical outgoing convergence rate, explicit final-sign onset,
arbitrary-state transfer law or native physical primitive follows here.

Only this report and `memory_current_publication_review/` were written.
Frozen inputs, earlier reviews and receipts, repository files, the Lean
packet and editable prompt files were not changed. No network request,
global tool change, model/effort change, delegation, commit, PR or formal
audit-state mutation occurred. The existing local workflow and review
instructions were reused at their previously checked revisions.
