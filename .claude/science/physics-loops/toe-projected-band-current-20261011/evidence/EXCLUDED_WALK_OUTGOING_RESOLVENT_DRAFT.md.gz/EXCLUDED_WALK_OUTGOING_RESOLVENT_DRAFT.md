---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Outgoing resolvent formula and an explicit weighted-transfer lower bound

2026-10-11. Root author derivation for the supplied excluded Weyl walk.
Independent review of this extension is pending.

The effective outgoing datum can be obtained from a regulated scalar
resolvent integral. Combining this identity with the already proved
interior resolvent bound and a separate energy-moment estimate gives a
positive numerical lower bound for its epsilon-weighted norm, uniform over
all fixed nonzero kappa. The constants are deliberately conservative.
No convergence rate, finite sign-onset time, or encounter clock follows.

## 1. Exact premises and physical scope

S denotes the containing resume_20261011 directory. The frozen sources are:

- EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md,
  b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c:
  full earlier proof read; E1-E9 and E20-E24 refreshed here.
- EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md,
  10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324:
  full earlier proof read; complete W1-W12 refreshed here. Its separate
  independent review remains a dependency while this draft is written.
- EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md,
  09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324:
  the previously checked cone integral bound L5 is used below.
- EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md,
  4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278:
  complete root-authored G1-G10, used only for the last corollary.

All q integrals use dmu=dq/(2pi)^3 on the three-torus. Set s_j=sin q_j,
epsilon=|s|, n=s/epsilon almost everywhere, and

    I0=integral (4epsilon^2)^(-1),  1/12<=I0<=9/8,
    Z=F direct-sum C,   zeta=(0,1),
    d_j=kappa_j cos q_j,  b=|kappa|>0,  f=d dot n,
    J=i n cross,  D=f J,
    g=i(d cross n)/(2epsilon sqrt(I0)),
    G=|g|^2=(|d|^2-f^2)/(4epsilon^2 I0),
    A=[D,g;g*,0],   A0=[D,0;0,0].                         (R1)

F is the physical odd transverse L2 triplet space. On each transverse
fiber J is self-adjoint, J^2=I and g*Jg=0. D is bounded self-adjoint;
A is the physical zero-space compression and ||A||<=b. The scalar zeta
coordinate is the physical dressing vector, not an auxiliary singlet.

The memory source proves, for exp(-itA)zeta=(u(t),a(t)),

    u(t)=-i integral_0^t exp[-i(t-s)D]g a(s) ds,
    a(t)->0, a'(t)->0,
    M(z)=<zeta,(z-A)^(-1)zeta>=1/[z-Sigma(z)],
    Sigma(z)=integral G z/(z^2-f^2) dmu.                  (R2)

Its dressing spectral measure is an even absolutely continuous probability
measure on [-b,b]. The weighted source, using the checked trace-class
wave-operator theorem on this same Z, supplies a vector u_+ in F with

    ||u_+||=1,
    ||(u(t),a(t))-(exp(-itD)u_+,0)||->0,
    W(t)=||epsilon u(t)||^2 -> W_+=||epsilon u_+||^2.       (R3)

R3 is a premise of this extension, not inferred from scalar decay alone.
The given walk, pair space, exclusion, canonical energy placement and
continuous generator clock are unchanged. The argument introduces no
new physical axiom, bath reset, statistical independence or Markov law.

## 2. Abel representation on the exact physical space

For h>0 let w(t)=exp(itD)u(t). It has norm at most one and tends strongly
to u_+ by R3. Its exponential average therefore obeys

    u_h:=h integral_0^infinity exp(-ht)w(t) dt ->u_+,
    ||u_h||<=1.                                          (R4)

Indeed, split the integral of ||w(t)-u_+|| at any fixed T. Its part up to T
is at most 2(1-exp(-hT)), while the tail is bounded by
sup_(t>=T)||w(t)-u_+||. First choose T, then let h decrease to zero.
This proves norm convergence without assuming an integrable decay rate.

Insert R2 into R4 and interchange the two integrals. The norm of the
absolute majorant is at most
h integral_0^infinity exp(-ht)t||g||dt=||g||/h, so the Bochner interchange
is valid for every h>0. The exact result is

    u_h=-i integral_0^infinity exp(-hs)exp(isD)g a(s) ds
       =M(D+ih)g.                                        (R5)

The last equality follows from the spectral theorem for bounded A:
-i integral_0^infinity exp(izs)a(s)ds=M(z) for Im z>0.
Applying the bounded functional calculus of D then gives R5. No boundary
value of M on the real axis is used, and no singular inverse is taken.

Pointwise on the transverse fiber put P_+=(I+J)/2 and P_-=(I-J)/2.
These are orthogonal projections, with |P_+g|^2=|P_-g|^2=G/2. Thus

    u_h(q)=M(f(q)+ih)P_+g(q)+M(-f(q)+ih)P_-g(q),
    |u_h(q)|^2=(G/2)(|M(f+ih)|^2+|M(-f+ih)|^2)
               =G|M(f+ih)|^2.                            (R6)

Evenness of the dressing measure gives M(-x+ih)=-overline(M(x+ih)),
which proves the last equality, including x=0. Although the individual
helicity labels swap under q to -q, f also changes sign, so the sum is
an odd physical field; no enlargement of F is being assumed.

For every bounded real even scalar weight m(q), R4-R6 give the regulated
integral formula

    integral m|u_+|^2
       =lim_(h down to 0) integral m(q)G(q)|M(f(q)+ih)|^2 dmu,
    |integral m|u_h|^2-integral m|u_+|^2|
       <=2||m||_infinity ||u_h-u_+||.                     (R7)

In particular m=1 gives a limit of one; m=epsilon^2 gives W_+; and
m=sin^2 q_a gives each canonical-current coefficient W_(a,+). Every
integral at h>0 is well defined because |M(x+ih)|<=1/h and G is integrable.
R7 does not authorize exchanging a pointwise h-limit with q integration,
removing the regulator in numerical quadrature, or assigning an error rate.

## 3. A uniform upper bound on the second energy moment

Let eta_g=||g||^2. Separate the diagonal and mixed kappa terms in G.
Each mixed term integrates to zero: reflecting one of its q coordinates
changes the corresponding sine sign while preserving cosines, epsilon
and the torus measure. The remaining expression is

    eta_g=(1/(4I0)) sum_j kappa_j^2
                  integral cos^2(q_j)(1-n_j^2)/epsilon^2
          <=(2/3)b^2.                                    (R8)

For the inequality, use cos^2(q_j)<=1. Permutation symmetry of the
normalized torus gives
integral n_j^2/epsilon^2=(1/3)integral epsilon^(-2), and
integral epsilon^(-2)=4I0. These integrals are finite by the cone bound.
Only lattice permutations and coordinate reflections are used, not a
continuous rotational symmetry of the supplied dispersion.

The outgoing datum has exactly this second energy moment:

    ||D u_+||^2=eta_g.                                   (R9)

Here is a direct proof, avoiding any extra wave-operator import. Set
psi(t)=(u(t),a(t)). The difference (A-A0)psi(t)=(a(t)g,<g,u(t)>) has
squared norm eta_g|a(t)|^2+|a'(t)|^2 by the scalar block equation.
It tends to zero by R2. Conservation gives ||A psi(t)||=||A zeta||
=sqrt(eta_g), so ||D u(t)|| tends to sqrt(eta_g). Since D is bounded
and R3 compares u(t) with exp(-itD)u_+, the same norm tends to ||D u_+||.
This proves R9. On transverse fibers D^2=f^2 I.

Let R be the scalar projection 1_(|f|<=7b/8) on F. Chebyshev's inequality
applied to R9 and then R8 gives the fixed interior-energy mass

    ||R u_+||^2 >=1-eta_g/(7b/8)^2
                  >=1-128/147=19/147=:m0.                (R10)

Thus a fixed positive part of the outgoing norm lies at interior energies.
No estimate on the endpoint density, spectral gap or Fourier decay rate
is assumed in this step.

## 4. Interior mass cannot all concentrate at the cones

The memory source E20 supplies, for chi=delta/b in (0,1),

    |M(x+ih)|<=C_delta=32768 pi I0/[b chi^(3/2)]
    whenever |x|<=b-delta, 0<h<=delta/2.                  (R11)

Use delta=b/8, hence chi=1/8. For 0<r<=1/2 let Q_r=1_(epsilon<r).
The checked cone estimate is integral_(epsilon<r)epsilon^(-2)<=r.
For 0<h<=b/16, R6 and R11 therefore imply

    ||Q_r R u_h||^2
       <=C_(b/8)^2 integral_(epsilon<r)G
       <=C_(b/8)^2 b^2 r/(4I0)
        =2^37 pi^2 I0 r
       <=K0 r,     K0:=90*2^34=1546188226560.             (R12)

The last relaxation uses I0<=9/8 and pi^2<10. All projections in R12
are bounded and commute, so the strong limit R4 proves the same bound
with u_+ in place of u_h. This passage needs no pointwise limit of M.

Choose r_*=m0/(2K0)=19/454579338608640, which is between zero and 1/2.
Subtract R12 from R10 to obtain
||(1-Q_(r_*))R u_+||^2>=m0/2. Since epsilon>=r_* on this set,

    W_+>=r_*^2 m0/2=m0^3/(8K0^2)=:c0,
    c0=6859/60752858276421362793738298982400
       >1.128*10^(-28).                                  (R13)

The rational expression is the certified value; the decimal is only a
conservative readable bound. This is uniform over fixed kappa!=0 because
the powers of b cancel in R12. It is a bound on the actual outgoing data
selected by the dressing preparation, not a lower bound for arbitrary
unit vectors in F. The latter can concentrate arbitrarily near a cone.

Together with the weighted source, 0<c0<=W_+<3. This bound does not fix
the sign of the final canonical current 1-(2/3)W_+ for diagonal kappa,
nor give a useful physical magnitude estimate or an optimal constant.

## 5. The prepared-packet consequence and scope

For the already constructed family in G1-G10, fix any 0<gamma<1/2,
delta=lambda^3, sigma=lambda^2, effective time T=lambda^(-gamma), and
kappa-envelope radius lambda^2 about (1,1,1). Its actual positive free-band
packet is contact-projected and globally normalized once. Physical time
is lambda^(-(3+gamma)), center lambda^3(1,1,1), and radius lambda^5.
The checked comparison there is

    Delta<J_a>/lambda^4
       =-W(lambda^(-gamma))/(12pi^2 I0)
          +O(lambda^(1/2-gamma)),    a=1,2,3.

If the separately reviewed G1-G10 premises are used, R13 gives

    lim_(lambda down to 0) Delta<J_a>/lambda^4
       =-W_+/(12pi^2 I0) <=-c0/135 <0.                   (R14)

Here 12pi^2 I0<=135 by the same elementary bounds. The denominator 135
and c0 are explicit, but the onset in lambda is not: no rate for
W(T)->W_+ is established. The O term bounds comparison to the moving
W(T), not all of the error from its limiting value.

The theorem concerns this supplied effective generator and the specified
prepared-packet family. It proves no generic-current decay law, collision
frequency, Boltzmann closure, monotonicity, incoherent state or new physical
primitive. The finite-bath recurrence counterexample in the memory source
remains valid: norm-one outgoing data require the absolutely continuous
scattering input R3, not only the algebraic resolvent identity R5.

## 6. Evidence boundary

The accompanying author controls check exact finite resolvent/Abel algebra,
the powers and rational constants in R8-R14, and an actual finite-bath
counterexample to discarding the scattering premise. They do not establish
the torus cone inequality, Kato's theorem or a continuum limit by a grid.
The new proof and any completed independent review are source-bound by
separate receipts. No Lean verification of this analytic extension,
retained-status audit or repository landing is asserted here.
