# Review of the regulated outgoing datum and uniform weighted bound

2026-10-11. Source-bound independent assessment of the new root-authored
R1-R14 extension. This is not a retained-status audit or a new review of
the reviewer's own earlier memory/scattering proofs.

## 1. Finding and exact scope

No consequential defect was found in the complete 245-line target
`EXCLUDED_WALK_OUTGOING_RESOLVENT_DRAFT.md`, SHA-256
`58a96a049701667e673bde1acf98e5346356483101654b3464fe11e94fd02c21`.
The upper-half-plane Abel formula has the correct sign and acts on the
original odd transverse space. The moment argument and the uniform
positive-regulator cone estimate give the stated exact rational lower
bound. No pointwise real-axis resolvent limit is needed.

The new result is conditional on the supplied effective operator and the
previously proved unit-norm outgoing comparison R3. Given those premises,
R4-R13 prove

    u_h = M(D+ih)g -> u_+ in norm,
    W_+ >= 6859/60752858276421362793738298982400
         > 1.128 * 10^(-28).

The lower bound holds for the outgoing datum selected by the dressing
preparation, at every fixed nonzero kappa. It is not a coercive inequality
for arbitrary transverse vectors or a uniform scattering-time estimate.
R14 additionally uses the separate G1-G10 prepared-packet composition.
Its limiting negative current difference follows with the stated sign;
neither a convergence rate nor an explicit finite sign-onset time follows.
No source repair is requested in this scope.

## 2. Reading coverage, identities and independence

All names below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
The companion receipt records absolute paths, complete identities and
new evidence. Frozen earlier sources were not changed.

| Source | SHA-256 | Reading and use |
|---|---|---|
| `EXCLUDED_WALK_OUTGOING_RESOLVENT_DRAFT.md` | `58a96a049701667e673bde1acf98e5346356483101654b3464fe11e94fd02c21` | All 245 lines, every R1-R14 argument and scope paragraph. Independently reconstructed before author-helper inspection. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Prior complete 500-line author reading reused after identity check; lines 29-150 and 220-390 refreshed, covering the operator/parity contract, resolvent convention, strip bound, absolute continuity and derivative decay. |
| `EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md` | `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324` | Prior complete 339-line author reading reused; lines 36-195 refreshed, including the fixed-space Kato import and outgoing/weighted implications. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Prior complete 457-line author reading reused; lines 95-143 refreshed, including the complete L5 normalized cone bounds. |
| `EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md` | `4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278` | All 236 lines read in this task. Checked the implication and limit scopes needed by R14. |
| `EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md` | `a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484` | All 319 lines read in this task. Separate completed review of R3's weighted/scattering premise and its primary theorem import. |
| `EXCLUDED_WALK_JOINT_SCALE_CURRENT_REVIEW.md` | `2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6` | All 252 lines read in this task. Its historical pending weighted-review dependency now has the preceding exact completed review; the frozen report is not rewritten. |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | Earlier complete 329-line reading reused at unchanged identity. Separate independent check of the memory premise, not a new re-review here. |
| `EXCLUDED_WALK_LONG_TIME_REVIEW.md` | `b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f` | Earlier complete 378-line reading reused at unchanged identity. The L5 source remains a previously checked premise. |

The completed weighted review is additionally bound by
`excluded_walk_weighted_review/independent_review_receipt.json`, SHA-256
`74990de59ab11a8011f4164ce689b0f80153d261c073c486f47b78a1beaf1a28`.
The joint-scale review receipt has SHA-256
`49bd1d8872a07aea1e5266cb2f07f3ea2aff4d9a9602f7a141e0051037d92b80`.
These receipt identities were checked; no claim of replaying all their
older helper artifacts is made. The exact completed reviews identify
their own independent coverage and limitations.

This reviewer authored the long-time, degenerate, effective-memory and
weighted-memory probes. Reusing them cannot independently certify them.
The new independent work here concerns root's regulated representation,
energy-moment estimate, their cone-mass combination and the R14 implication.
The pre-helper reconstruction was saved before inspecting the author
runner or its logs. Our controls do not import or execute an author helper.
The later author-evidence inspection is distinct from those controls.
No new mathematical scattering theorem was imported here; the existing
Kato premise and its separate review were matched rather than re-certified.

## 3. R1-R7: the physical space and the Abel formula

On the full three-dimensional fiber, writing C_n for cross product with n,

    (i C_n)^2 = I_3 - n n^T = Q_tr.

Thus J^2=I in R1 is correct precisely on a transverse fiber. The formula
P_+/-=(I+/-J)/2 is likewise fiberwise. J and the individual helicity
projections do not themselves preserve the global odd space F: under
q -> -q, J changes sign and the two helicities exchange. At the same
time f and g are odd, so D=fJ preserves F and the complete R6 field is
odd. This distinction is already stated correctly in the target; no
unphysical independent helicity space is substituted.

The integrability of g follows from G<=b^2/(4 I0 epsilon^2) and finite I0.
The operators in R1-R3 are bounded on the same fixed Z=F direct-sum C.
The last coordinate is the physical dressing mode. It is not the removed
constant singlet. In particular R3 is a strong comparison for this exact
space and initial vector, not an inference from scalar survival decay.

For R4, let w(t)=exp(itD)u(t). R3 gives w(t)->u_+, and both norms are at
most one. Splitting the exponential average of their difference at T
gives exactly the displayed bound

    2(1-exp(-hT)) + sup_(t>=T)||w(t)-u_+||.

Choosing T first, then h, proves norm convergence without an integrable
tail or a quantified scattering rate.

For R5 the integral interchange is justified at every h>0 by
||g||/h. With the target convention M(z)=<zeta,(z-A)^(-1)zeta>,

    integral_0^infinity exp(i(z-E)s) ds = i/(z-E),

for Im(z)>0. The preceding -i is therefore essential: it produces the
positive resolvent, evaluated at D+ih. Both the scalar spectral integral
and the bounded functional calculus for D have the same absolutely
integrable majorant at fixed h. No singular inverse or real-axis value
of M is introduced by this calculation.

For R6, g is i times a real transverse vector, so g*Jg=0 and each
orthogonal helicity receives G/2. The even probability spectral measure
of zeta implies M(-x+ih)=-conj(M(x+ih)); this includes x=0. Orthogonality
and conjugacy give the stated norm density G|M(f+ih)|^2, with no missing
factor of two.

For R7 every bounded real even multiplier preserves F. The ordinary
two-vector quadratic-form inequality gives

    |<u_h,m u_h>-<u_+,m u_+>|
      <= ||m||_infinity (||u_h||+||u_+||)||u_h-u_+||.

This proves the factor two and the regulated integral formula. The
pointwise bound |M(x+ih)|<=1/h and G in L1 establish finite-h
integrability. None of these steps exchanges the h limit with q
integration, proves pointwise boundary values, or supplies a numerical
regulator-removal error. The target explicitly preserves those limits.

## 4. R8-R10: a conserved second moment supplies interior mass

Expanding |d|^2-(d dot n)^2 yields diagonal terms
kappa_j^2 cos^2(q_j)(1-n_j^2) and mixed sine products. The transformation
q_i -> -q_i reverses an off-diagonal sine product while keeping its
cosines, epsilon and normalized measure unchanged. Each such integral
is absolutely bounded by a multiple of epsilon^(-2), so cancellation is
legitimate. The exact reflection-orbit identity is also checked in our
symbolic controls, before integration.

After dropping cos^2<=1, coordinate permutations and sum n_j^2=1 give

    integral n_j^2/epsilon^2 = (4 I0)/3,
    eta_g <= (1/(4 I0)) sum_j kappa_j^2 [4 I0-(4 I0)/3]
          = (2/3)b^2.

No rotational invariance beyond those actual torus symmetries is used.

For R9 the scalar block equation is i a'= <g,u>. Therefore

    ||(A-A0)psi(t)||^2 = eta_g |a(t)|^2 + |a'(t)|^2.

The derivative decay used here is explicitly part of memory E24: the
compact absolutely continuous spectral measure has E rho(E) in L1, and
the same elementary Fourier argument applies. This uses the spectral
premise explicitly rather than differentiating an already taken limit.
Since all generators are bounded,
conservation of ||A psi(t)|| and the preceding vanishing difference imply
||D u(t)|| -> ||A zeta|| = sqrt(eta_g). R3 then gives R9 because D
commutes with exp(-itD) and is bounded. No extra wave-operator
intertwining result or unbounded-domain identity is needed.

Finally D^2=f^2 on transverse fields. Chebyshev at 7b/8 gives

    ||1_(|f|<=7b/8)u_+||^2
      >= 1 - (2/3)/(7/8)^2 = 19/147.

This remains valid if there is mass exactly on the cutoff, and it uses
no additional endpoint spectral regularity. The projection is an even
scalar multiplier, so it acts on the physical F.

## 5. R11-R13: uniform positive-regulator control and the exact constant

Memory E20 is the strip estimate actually needed by R11. Its domain
matches with delta=b/8: |x|<=7b/8 and 0<h<=b/16. It is stronger than
an almost-everywhere boundary statement. Combining it with the matched
L5 normalized cone estimate and G's pointwise bound yields

    C_(b/8)^2 * b^2/(4 I0)
       = [2^30 pi^2 I0^2/(b^2 (1/8)^3)] * b^2/(4 I0)
       = 2^37 pi^2 I0.

Using I0<=9/8 and pi^2<10 gives exactly

    K0 = 90*2^34 = 1546188226560.

The bounded projections Q_r=1_(epsilon<r) and R commute and preserve F.
Their action on u_h converges in norm to their action on u_+. Thus R12
passes to the limit with the same bound K0 r. There is no boundary-value
interchange hidden in this key step. It is enough that b>0 is fixed
while h decreases; the admissible h interval may shrink with b.

Taking m0=19/147 gives

    r_* = m0/(2K0) = 19/454579338608640 < 1/2,
    ||(1-Q_(r_*))R u_+||^2 >= m0/2,
    W_+ >= r_*^2 m0/2 = m0^3/(8K0^2).

Exact rational arithmetic confirms the R13 numerator and denominator
and the strict comparison with 1.128*10^(-28). The powers of b cancel
before numerical relaxation, proving the bound for all selected outgoing
data at fixed nonzero kappa. This gives no common convergence time over
kappa, including near zero. At kappa=0 the coupling vanishes, R3 does
not hold, and no transfer conclusion is asserted.

For arbitrary unit transverse fields the weight epsilon^2 has no positive
coercivity constant: support can concentrate near the cone points. The
proof avoids that false conclusion by combining the special outgoing
spectral moment and its resolvent control. It also does not determine the
sign of the final diagonal current 1-(2/3)W_+.

## 6. R14 and the prepared-packet limit

The complete G source and its separate review preserve the needed
distinctions: the finite all-T Q16 bound is used at the growing time,
the small dressing amplitude remains in the quadratic current error,
and the physical packet is globally normalized once after projection.
The actual projected kappa probability weights are integrated; they are
not replaced silently by the free envelope law.

With fixed 0<gamma<1/2, setting p=1/2-gamma, the four relative state-error
powers are p, 2p, 1/2 and 2+p. The momentum/preparation comparison adds
520 lambda+8 lambda^(1-gamma), which is o(lambda^p). These are the
finite growing-time estimates required for the quoted R14 precursor;
a fixed-time convergence theorem is not being substituted.

The earlier G review explicitly left its weighted-scattering premise
pending. That dependency is now matched to the completed separate
weighted review at `a2bb951a...`, with the same source `10991ee0...`.
This does not retroactively change either frozen review's stated coverage.
It does allow the independently checked outgoing premise to be composed
with G's independently checked scale/current/global-preparation argument.

At the fixed central direction (1,1,1), T=lambda^(-gamma) tends to
infinity and W(T)->W_+. R13 and 12 pi^2 I0<=135 give

    -W_+/(12 pi^2 I0) <= -c0/135 < 0.

The negative sign reverses neither inequality incorrectly. The physical
time, center, radius and current normalization are respectively
lambda^(-(3+gamma)), lambda^3(1,1,1), lambda^5 and lambda^4. No uniform
scattering limit over the shrinking kappa ball is required: G's finite
comparison reduces those fibers to the central orbit. The O(lambda^p)
term measures error relative to the moving W(T), so it does not become a
rate for convergence to W_+ or a finite sign-onset estimate.

## 7. Independent controls and later author-evidence inspection

The independent helper uses a full finite propagator's Sylvester equation,
rather than integrating the author's scalar spectral decomposition. For
D=(2/5) sigma_y, g=i(3/7,4/7), h=3/11, its exact solution obeys

    hX-iDX+iXA=hP_F,
    X zeta = M(D+ih)g.

The opposite overall sign and lower half-plane fail this nonzero fixture.
Full three-dimensional cross-product matrices separately test the
transverse projections and physical parity. The single helicity branch
is demonstrably not an odd field, while the complete regulated field is.
Symbolic reflection and exact rational calculations cover the moment,
cone coefficient, cone radius and final constant.

The same finite bath has a zero-energy dressing atom of 196/821 and its
Abel datum tends to zero. It therefore supplies an actual counterexample
to deriving a unit outgoing norm from R5 alone. It is not a counterexample
to R3 or a finite proof of continuum absolute continuity.

- Independent helper: `outgoing_resolvent_review/independent_controls.py`,
  SHA-256 `5ae7e904b8fd4624e09abb153f3d64c77bad157e06c62bead1cd3e883fe8f593`.
- Complete log: `outgoing_resolvent_review/independent_controls.log`,
  SHA-256 `f03aa1cf99f35911aa4fba3ae38de2861ec09aaff16f34a6d9e482c9d5241f51`.
- First execution: Python 3.13.5, SymPy 1.14.0, exit 0, 120-second declared
  timeout; 33 exact controls. No floating integration, first-run failure,
  helper repair or new source-mutant execution occurred in this review.
  The full log was read. Built-in wrong-sign comparisons are discriminators,
  not claims of separately executed source mutants.

Only after this execution did I inspect the complete author helper,
baseline, failed first run, execution records, mutation manifest and all
five failure logs. The final helper hash is `5959a175...`; the author
receipt hash is `333d6201...`. Exact byte reconstruction confirms that the
initial failed helper differs by only three symbolic-simplification edits.
The failure was structural equality of an unsimplified zero, not a changed
tolerance or scientific premise.

Each author mutant is exactly its declared single source replacement,
and its full preserved traceback ends at the intended assertion: causal
sign, helicity weight, moment factor, cone power or weighted lower-bound
factor. All 24 author-receipt records match their frozen hashes. Those
are checks of actual preserved author evidence; I did not reexecute it or
count it as independent evidence for continuum scattering. The detailed
byte checks are in `outgoing_resolvent_review/source_check.json`.

## 8. Limits and preservation

The continuum hypotheses are essential. The new finite controls do not
prove the L5 cone integral, memory absolute continuity, Kato's theorem,
or the original walk approximation. Their exact source premises and
separate reviews remain explicit. This extension has no Lean certificate,
computed regulator-removal rate, numerical quadrature certification,
generic-current law, monotonicity, collision clock or new physical axiom.

Only this report and `outgoing_resolvent_review/` were written for this
check. Earlier frozen probes, the Lean packet, repository files and
editable prompt files were unchanged. No network lookup, global tool
change, model change, delegation, commit, PR or audit-state mutation was
performed. The previously read local instructions and review skill were
reused at their unchanged exact identities.
