# Projected-band canonical-current publication composition review

2026-10-11. External source-bound review, not a formal audit or a retained-status
decision. No author note, primary, frozen source, repository file or prompt was
edited by this review.

**No consequential composition or claim-scope defect was found in the exact
candidate and publication copies identified below.** The required definitions,
both cutoff inverses, both evolution correctors, finite estimates, actual
canonical current and single global normalization survive assembly. No new
mathematical repair is requested for those bytes.

This finding has a specific independence boundary. I authored the frozen
long-time source L and degenerate-dynamics source D, and their original finite
helpers. Their old mathematics is not newly independently certified by this
report. Their existing separate reviews remain the independent records. This
review newly checks another author's composition, the Q/B arguments as used
there, the source-selection boundaries, the literal runner embedding and the
publication-only changes. It was not a blinded pre-source reconstruction.

The pending-review sentences and the delivery footer are provenance surfaces,
not additional mathematical premises. Root plans a later narrow status/evidence
refresh. That changed text will need its own exact-byte confirmation; this
report does not certify a future delivery record or an unread cumulative branch.

## 1. Exact sources and actual reading coverage

S is `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
NW is its sibling `walk_worktree`. Paths in this table are relative to S unless
explicitly prefixed NW. Full SHA-256 identities are retained here and in the
review receipt.

| Object | SHA-256 | Actual coverage |
|---|---|---|
| `FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md` | `ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969` | All 859 lines, including every proof, metadata field and scope paragraph. |
| `PROJECTED_BAND_CURRENT_SOURCE_COMPOSITION.json` | `5a48688b7694336051ade340089989f0bcc8a50d4e7d6a23c805990f945c8341` | Entire JSON parsed; all 31 replacements reconstructed; all operation reasons/before-text inspected against the fully read final after-content; all 13 exact source fragments and 38 unchanged line ranges checked. Initial combined tool output truncated; structured reads and complete source reads replaced that incomplete view. |
| `FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_PRIMARY.py` | `a5bec672fe34491dc597a69366af105bb25e6b1e67f5176c0b2b189b5677f162` | All 713 lines, including all four complete embedded programs and the wrapper. |
| `projected_current_primary_composition.json` | `ffdc0a26f9caea83e70f41a471c63959e5672dc43379e43172f7ec906e6551b1` | Complete 30-line map; exact original helper bytes verified by independent AST extraction. |
| Q: `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md` | `ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400` | All 420 lines newly read. No previous full reading was assumed. |
| B: `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | All 327 lines newly read. No previous full reading was assumed. |
| L: `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Prior complete 457-line author reading reused at unchanged bytes. Source ranges 75–179, 205–243 and 282–304 reread for selection/normalization; included arguments read fully in the candidate. |
| D: `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Prior complete 549-line author reading reused at unchanged bytes. Ranges 111–158, 172–201, 234–245 and 293–333 reread; included arguments read fully in the candidate. |
| P: NW `docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md` | `9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401` | Lines 1–103 and complete canonical Section 7, lines 393–472, read here. I do not claim a new full reading/review of this 1,280-line parent. Its other scattering/Cook/flux arguments are not premises of this unit. |
| `EXCLUDED_WALK_LONG_TIME_REVIEW.md` | `b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f` | All 378 lines read here. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Prior complete 375-line reading reused at unchanged bytes. |
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_REVIEW.md` | `7fa575475439af53c7c0cf4af74fea66537b75ce42afd7418504de4dd0e31051` | All 316 lines read here. |
| `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_REVIEW.md` | `a530a7b1507e7d22af11f08c236af865ec1c8acb004069b249c9b281bcf4cbda` | All 329 lines read here. |

The four helpers were read completely in their byte-identical embedded form:

| Original helper | SHA-256 | Lines |
|---|---|---|
| `excluded_walk_long_time/long_time_checks.py` | `4ddc0e1972c6ab13c269ac2f7c18b38811be1d9087a4052df53940cc24245a86` | 149 |
| `excluded_walk_degenerate/degenerate_checks.py` | `8313796d2a462c37ed1aea0dc32182c9f7dc5b7ba34707d80a033b1c53f3a41a` | 264 |
| `two_scale_band_current/root_two_scale_controls.py` | `3957104cf4362b83c6f6e11c5cbbff365d34e232dc1134cd09cdc9a97312e4ec` | 122 |
| `quantitative_band_current/quantitative_controls.py` | `0e9a63cd42abd9fc3d4f68bb1a8568825e25c36c589f2a6f028ad690654f1df9` | 130 |

## 2. Every assembly operation and source selection

The new helper starts with the exact Q bytes and applies each before/after
replacement once, in the map's order. Every before-text occurs exactly once at
its turn. The result equals every byte of the 859-line candidate. This is an
integrity check, not a mathematical proof; the semantic checks were separate.

All 33 Q equation blocks remain once each. Thirty-two are byte-identical.
Q4 alone adds the already proved L5 cone-volume bound and writes the normalized
measure explicitly. No asymptotic estimate with an unknown remainder constant
replaces the finite Q13/Q25–Q27 inequalities.

| Operation | Checked change and source boundary |
|---|---|
| 1 | Title, claim scope and status retain the supplied-model, specified-family contract. `proposed_retained` is accompanied by `conditional-support` and an explicit absence of applied audit status. |
| 2 | Defines the actual current difference and global preparation; Q1–Q2 are unchanged. |
| 3 | Replaces research history with definitions, normalized measures, chart and explicit parent scope; the map preserves source identities. |
| 4 | Includes complete L1–L5 kernel/cone arguments; retains auxiliary-contact exclusion and lack of a gap. Q4's only extra inequality is the original L5 volume bound. |
| 5 | Includes D3–D5 with the small total-momentum parameter renamed delta; the separate band parameter lambda is not conflated with it. |
| 6 | Includes the full D6–D7 transverse/scalar coupling, signs, parity and boundedness. |
| 7 | The phrase about an existential D11 input is replaced by a reference to the now-included finite comparison; Q11 is unchanged. |
| 8 | Retains the special-orbit restriction and disclaims zero-space unit-ball uniformity; the separate counterexample remains frozen. |
| 9 | Includes L6–L8 with the positive contact weight, energy Jacobian and all eight sine charts. |
| 10 | Makes the real positive beta phase and absence of a transverse component explicit using L8–L10. |
| 11 | Replaces an external density reference by the included argument without weakening its domain. |
| 12 | Changes L5 to Q4 at the support-volume use; the required inequality is now present locally. |
| 13 | Replaces the external inverse citation by the actual construction below Q14. |
| 14 | Includes the two-component L13–L14 inverse, mean subtraction, contact term and every norm cost; scalar coefficient names avoid collision with projection F. |
| 15 | Includes complete D9–D11 and B5/B7–B9. The opposite corrector signs, inverse order, low-spectral terms, endpoint costs and R_delta costs remain distinct. |
| 16 | Reproduces the complete parent J1–J6 current derivation, including core/H1 qualification. No unbounded dipole is applied to zeta. |
| 17 | Replaces the scratch-source observable reference by the just-derived canonical extension. |
| 18 | Includes full-space B12, preserving the placement correction and the distinction between commuting with F and commuting with P. |
| 19 | Includes D14's operator-norm current remainder and its constants before the diagonal specialization. |
| 20 | Includes D21–D22's coupling and Taylor proof in weighted-transverse form. It does not substitute the earlier longitudinal-only cancellation for the full-space current argument. |
| 21 | Includes the actual positive-projector, energy-band and physical-normalization proof with all support and antisymmetry conditions. |
| 22 | Includes B20's finite-delta continuity proof and both preparation endpoints, giving the literal 512 delta/lambda cost. |
| 23 | Replaces historical future-review prose with the four exact existing review identities and an explicit pending composition check; earlier existential limitations are not misrepresented as part of Q's explicit onset. |
| 24 | Restricts the parent import to the supplied walk and canonical placement; no stationary scattering, Cook regularity or effective-memory statement is used. |
| 25 | Defines n before use and removes a duplicate c definition; cone-point values remain irrelevant null-set choices. |
| 26 | Replaces dangling D6/Z wording by A_kappa and the already defined ran Pi. |
| 27 | Identifies the normalized effective orbit and alpha(0)=1 before the pointwise bound. |
| 28 | States the actual positive L1 eigenvector that yields contact weight 1/2; no limiting-absorption hypothesis enters. |
| 29 | Uses H_* consistently for the zero-momentum inverse; the K-dependent operator is not silently inverted. |
| 30 | Defines the one-body symbol and site projection locally, matching the parent's supplied density. |
| 31 | Includes the two-endpoint energy-square bound and proper cyclic covariance on the actual prepared state and evolution; it does not require an improper-rotation convention. |

All 13 exact selected fragments pass source-byte, hash, line, column and byte
offset checks. The 38 stated unchanged quantitative line ranges also match.
The selected L/D/B/P pieces contain the complete arguments required at their
uses. In particular, the scalar and triplet inverse norm accounting added to
L14 is the same accounting written in the existing long-time independent
review, not a new numerical bound.

The map's unpromoted results remain in their original sources: high-momentum
leakage, the pure-dressing/longitudinal cancellation, qualitative fixed-vector
limits, and state-comparison nonuniformity. The current proof neither infers
current drift from leakage nor asserts a universal relaxation obstruction.

## 3. Reconstructed load-bearing interfaces

The assembled note defines the physical fiber, full-torus measure, exchange
parities, c/P, the spin basis, epsilon/n/I0/zeta, F/Pi/Q, both Hamiltonians,
and all preparation amplitudes before their essential use. The physical kernel
is the free transverse space plus zeta; the auxiliary c is excluded. The
reduced inverse H0^{-1}c is only evaluated on its stated dispersive-domain
vector. None of this is promoted to a physical primitive derived from axioms.

For the special effective orbit, Q B exp(-i tau A)zeta=f n, with zero
integrable inverse mean and |f|<=b^2 T/(sqrt(I0) epsilon). The first inverse is
the singlet-only `P[1_(epsilon>=r) f c/(2epsilon)]`. Its residual is
`[-f 1_(epsilon<r)-2epsilon m_r]n`; the mean term survives. Its two bounds are
`2L sqrt(r)` and `3L/(2sqrt(r))`, giving `(7/2)L sqrt(sigma)` at r=sigma.
No spatial-cutoff/spectral-projector commutation is assumed.

For the projected-band complement x=chi_lambda-A_lambda zeta, the second
inverse instead has the singlet component
`1_(epsilon>=r)[G_l/(2epsilon)-A_lambda/(4sqrt(I0)epsilon^2)]-m_r`
and triplet component `F_s/(2epsilon)`. The triplet inverse's constant
contact subtraction costs `beta_lambda sqrt(I0)/n_lambda`. The singular
singlet cutoff and its mean cost the final `A_lambda/(sqrt(I0)sqrt(r))`.
Its domain r<=min(1/2,5lambda/8) is preserved. Thus Q14–Q15 are not an
application of the first inverse to the wrong vector.

The evolution correctors are also different. On the zero space one uses
`y=-H_*^-1 Q_sigma Bv`; its residual includes `-E_sigma Bv` and the
endpoint/integrated costs yield D11. On the high nonzero spectrum one uses
`y=B H_*^-1 v`; BQ=FBQ implies H_*y=0, and its residual is `-delta By`.
The discarded low part costs `2||E_sigma x||`. Both comparisons are finite
for each T>0, with their stated cutoff domains and positive delta. They do
not rely on an exchange of qualitative limits.

Combining them with the factor A_lambda on the first state gives exactly
Q16, including its T^2 contribution from the special-orbit spectral estimate.
F annihilates the remaining fast Q evolution exactly. It is not discarded
by decoherence or a phase average. At T=1/20 the relaxed coefficients in Q17
and the scale choice in Q25 satisfy the entire interval 0<lambda<=1/16.

For the observable, the reproduced J1–J6 calculation cancels the K derivatives
and supplies the bounded decomposable current on L2. The full-space identity
`sum L_a=3P-H_*^2/2-2epsilon^2 F` includes all placement terms. The change of
H_*^2 is bounded by twice the norm difference from the conserved actual
Hamiltonian square; this is valid for every time. Proper cyclic symmetry of
chi_lambda and H_D(delta(1,1,1)) then gives the individual component bound.

If the transverse state error is e, the squared weighted norm error is
`3e(2A_lambda+e)`, hence the current cost is `4A_lambda e+2e^2`.
The small amplitude has not been replaced by a unit-vector bound. D21–D22
give the weighted response `1/10800` at tau0. Together with the energy/current
remainders these establish the diagonal margin in Q24 at the explicit
Q25–Q27 parameters. This is a finite estimate at the given long physical
time, not an assertion of a uniform-in-time approximation.

The actual ++ projector is well defined on the original support since each
one-body energy is at least 5lambda/8 before a perturbation of at most |K|/2.
Its normalized preparation and the subsequent normalized P projection give
the two factors leading to `16|K|/lambda`. The interior band stays in the
actual [lambda,2lambda] free band. This statement concerns the free input,
not invariance of the projected or evolved state under the free projector.

The current continuity and two-endpoint state error give respectively
`9|kappa-kappa0|` and `512delta/lambda`. On the Q29 ball each is at most
A_lambda^2/86400. The common negative bound Q30 therefore holds on a full
three-dimensional momentum set. Both delta and eta amplitude factors in Q31
cancel their corresponding volume Jacobians. One global projection produces
the actual weights `|f_lambda|^2 n_(lambda,delta kappa)^2/N^2`; these integrate
to one and are generally not the original |f_lambda|^2 law. The Hamiltonian
and bounded current are decomposable, and every fiber uses the same physical
time. Integrating Q30 with those actual weights proves the stated Q2 bound.

## 4. Primary composition, fresh controls and execution evidence

Independent AST extraction finds four literal `_run_block` calls. Each decoded
string equals every byte of its named frozen helper, including the terminal
newline. The four identities are also printed in the author's baseline log.
No author helper is imported at runtime. The original source-file reads are
self-hash metadata; `__file__` intentionally identifies the combined runner.
They are not data input for any scientific calculation.

Each `_run_block` call constructs a fresh dictionary containing only its
`__name__`/`__file__` metadata before Python supplies builtins. I extracted
that actual wrapper and used new synthetic programs, not the old calculations,
to check isolation and exception propagation. A deliberately transformed
wrapper using `globals()` leaks a sentinel and is rejected. A separately
altered embedded derivative sign fails the exact-source identity test.
These are composition discriminators; they are not claimed as newly executed
scientific mutants of the full primary.

The new standard-library helper also regroups the relative-error budget with
x=lambda^(1/4), 0<x<=1/2. Its nonnegative monomials are maximized at x=1/2,
recovering `57352588089098243/23611832414348226068480<1/200000`.
It checks the combined diagonal sign margin directly, the two preparation
endpoints and the remaining global sign budget. A new unequal-loss three-fiber
fixture verifies the distinction between one global normalization and the old
momentum law; those laws predict different observable values. This is finite
normalization algebra, not a numerical proof of the continuum packet theorem.

The fresh helper's first execution exited zero under a 120-second outer
timeout, in approximately 0.0772 seconds. Its 127 checks include bookkeeping
checks and must not be read as 127 independent scientific confirmations.
The complete log was read; no formula, tolerance or assertion was changed
after a failure. The intentional wrapper failures were caught explicitly.
Artifacts are in `projected_current_publication_review/`, with exact identities
in its receipt.

The author's complete `projected_current_primary_checks/baseline.log` and
`baseline_execution.json` were read and matched to the frozen primary. The
baseline exited zero in approximately 1.3591 seconds under an outer 180-second
timeout, with every block entered and completed. The brief's `execution.json`
pathname did not exist; `baseline_execution.json` is the actual record. This
was a read-only path resolution, not a missing execution.

The combined primary retains historical per-helper 90/120-second declarations;
they are metadata, not active inner timers. The supplied combined baseline
uses the actual 180-second outer timeout declared by the wrapper. No old
runner was replayed by this review, and no baseline replay is counted as
independent evidence. The exact finite fixtures, unvalidated quadrature and
floating examples retain their original limited roles.

## 5. Exact publication-copy refresh

The reviewed NW note is
`docs/EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md`,
877 lines, SHA-256
`7543767f5f2377812f78630238e73959b170752de0455fb6ab5f556a2f1868bb`.
It adds only the literal runner frontmatter field and the 17-line publication
execution/dependency footer. Removing those additions gives the exact frozen
859-line candidate. The entire added footer was read. The mathematical body
has no changed line.

The reviewed NW primary is
`scripts/excluded_walk_projected_free_band_canonical_current_2026_10_11.py`,
713 lines, SHA-256
`4451005b466c114b40c943509b13aaa34607b7b8e884ab584df4c19d8b1f30ff`.
Its sole change is the declared note input path: `...FREE_BAND_CURRENT...`
becomes `...FREE_BAND_CANONICAL_CURRENT...`. All four literals and the wrapper
AST remain unchanged. This is consistent with the complete
`.claude/science/physics-loops/toe-projected-band-current-20261011/PUBLICATION_EDITS.json`.

The footer correctly excludes flux/form and effective-memory premises and
preserves the upstream dependency. The parent canonical note at commit
`b9b032ae790c66e762a6296a1306bfb64ae7cd70` has exactly the reviewed P hash;
that commit was NW HEAD at this check. The footer's requirement that the parent
delta land first, or that the cumulative delta be reviewed together, is not
discharged by this narrow unit review. I did not review that cumulative delta
or certify a later DELIVERY_CHECKS.md, publication execution, cache or mutation
record. Root's later evidence/status-only update requires a narrow refresh.

## 6. Disposition and remaining limits

The exact reviewed composition supports the stated conditional theorem for the
specified projected-band family and explicit finite time. It retains the
physical suppliers, sharp-band preparation, full current placement, one global
normalization, conservative scale constants, and positive momentum width.
No missing terminal mathematical lemma was identified within that scope.

This report supplies no new physical law, current-positivity theorem,
monotonicity, generic-packet claim, optimized onset, many-body transport rate,
formal Lean continuum proof or retained-status verdict. It does not newly
independently certify my old L/D arguments or certify the parent's unused
scattering/Cook/flux results. No remote freshness or global novelty search was
performed. The selected model and reasoning effort were preserved.

Only this report and `projected_current_publication_review/` were written.
All reviewed source identities were checked again at receipt creation.
No editable prompt, global configuration, commit, PR or audit state changed.
