---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# An explicit weak-momentum onset for projected free-band current response

External author derivation, 2026-10-11. This is a new quantitative continuation
of three frozen arguments, not an independent review of them. The supplied
walk, clock, spin sector, contact exclusion and canonical energy placement
remain premises. No physical event clock or kinetic equation is derived.

For every 0<lambda<=1/16, the construction below gives a normalized projection
of an actual free [lambda,2lambda] positive-band packet. Set

    delta=2^-68 lambda^2,   tau0=1/20,
    physical time t=tau0/delta=2^68/(20lambda^2).           (Q1)

All three actual canonical energy-current components then obey

    Delta <J_a> <= -delta A_lambda^2/43200
                <= -2^-68 lambda^3/(388800pi^2), a=1,2,3. (Q2)

The factor A_lambda and every preparation normalization are defined below.
The total-momentum packet has center delta(1,1,1) and a strictly positive
specified three-dimensional width. The numerical constants are conservative;
no claim of an optimal exponent, constant or physical onset scale is made.

## 1. Frozen inputs, reading coverage and the exact new obligation

All paths are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Input | SHA-256 | Actual coverage and role |
| --- | --- | --- |
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | All 327 lines read. B1-B13 supply the complementary corrector and full physical-space current trace; B14-B20 supply the band preparation and finite momentum-continuity estimates; B21-B24 give the existential target that is quantified here. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | All 457 lines read. L1-L5 classify the physical zero space and give explicit cone integrals; L9-L14 define the band and its approximate inverse; L18-L20 control actual free-band preparation. Its leakage result is not used as a current argument. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | All 549 lines read. D6-D11 give the effective orbit and its vector-dependent cutoff error; D12-D14 give the actual current remainder; D19-D23 give the diagonal dressing response. The nonuniformity example is preserved. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Previous complete reading and reconstruction reused; it fixes the supplied local-energy placement. |

These source identities were verified and their bytes remain unchanged.
No source review or audit status is conferred by this continuation. The exact
missing obligation is the finite vector-dependent low-spectral bound in D11,
and its combination with B9 for the lambda-dependent projected band. The
three source arguments are the matched prior work for this continuation;
no new repository-wide novelty or open-PR inventory is claimed. No new
literature theorem, scattering completeness or Cook regularity is used.

The new proof uses pointwise bounded evolution, the complete longitudinal
cutoff including its subtracted mean, and bounded spectral/Duhamel estimates.
The parameter choice is made only after these estimates are obtained. All
new output is external, with separate controls and a source-bound receipt.

## 2. Fixed physical space and estimates available without a spectral gap

All relative-torus integrals use dq/(2pi)^3 and inner products are linear
in the second slot. Let c be the constant normalized singlet, P=I-|c><c|,
and H_D(K)=P H0(K)P restricted to ran P, where

    H0(K,q)=sigma_1.sin(K/2+q)+sigma_2.sin(K/2-q),
    s=sin q, epsilon=|s|, n=s/epsilon,
    I0=integral 1/(4epsilon^2),
    zeta(q)=n(q)/(2epsilon(q)sqrt(I0)) in triplet coordinates.

Values at the eight cones are immaterial. Write H_*=H_D(0), let F be the
pointwise transverse-triplet projection, and put

    Pi=F+|zeta><zeta|, Q=P-Pi,
    E_sigma=1_(0<|H_*|<=sigma)(H_*).                       (Q3)

Pi is the complete physical zero projection. The auxiliary contact c is
excluded. The source proves, for 0<r<=1/2,

    integral_(epsilon<r) epsilon^-2 <=r,
    integral_(epsilon>=r) epsilon^-4 <=9/r,
    integral epsilon^2=3/2,  1/12<=I0<=9/8.               (Q4)

These are continuum torus bounds, not finite-fixture estimates. They retain
all eight corner charts and the normalized measure.

For fixed kappa put b=|kappa|, d_j=kappa_j cos q_j and

    B_kappa u=i d cross u, B_kappa kills the singlet,
    H_D(delta kappa)/delta=H_*/delta+B_kappa+R_delta,
    ||R_delta||<=r_delta=delta b^2/4+delta^2 b^3/24,
    A_kappa=Pi B_kappa Pi, U_delta(tau)=exp[-i tau H_D(delta kappa)/delta].
                                                               (Q5)

The effective orbit from zeta has coordinates

    exp(-i tau A_kappa)zeta=u(tau)+alpha(tau)zeta,
    i u'=D_kappa u+alpha g_kappa, u(0)=0,
    D_kappa u=i(d.n)n cross u,
    g_kappa=i(d cross n)/(2epsilon sqrt(I0)).             (Q6)

Its norm is one, so |alpha|<=1. The multiplication operator D_kappa(q) is
Hermitian on the transverse plane at almost every q. Its pointwise exponential
is unitary. The bounded-operator variation-of-constants formula therefore
also has the following almost-everywhere representative for either sign of
tau:

    |u(tau,q)|<=|tau| |g_kappa(q)|
              <=T b/(2epsilon(q)sqrt(I0)), |tau|<=T.      (Q7)

No spatial derivative of zeta or uniform pointwise bound at a cone is used.

## 3. Quantifying the low nonzero spectral mass of the dressing orbit

Because B_kappa zeta=g_kappa is transverse, the longitudinal part of
Q B_kappa exp(-i tau A_kappa)zeta comes entirely from B_kappa u. Put

    f_raw(q)=n(q).B_kappa u(q), beta(tau)=<zeta,B_kappa u>,
    f(q)=f_raw(q)-beta(tau)/(2epsilon(q)sqrt(I0)).

Then exactly

    Q B_kappa exp(-i tau A_kappa)zeta=f(q)n(q),
    integral f/(2epsilon)=0,
    |f(q)|<=L/epsilon(q), L=b^2 T/sqrt(I0).              (Q8)

To check the constant, Q7 bounds f_raw by b^2T/(2epsilon sqrt(I0)).
Also ||u(tau)||<=T||g_kappa||<=Tb, so |beta|<=b||u||<=Tb^2.
The removed zeta component costs another equal half in the pointwise bound.
The orthogonality of Q to zeta gives the integral identity. It is legitimate
as an ordinary integral because epsilon^-2 is integrable. Both f and its
formal singlet inverse are exchange even.

Let y=f n. The formal inverse f/(2epsilon) has zero mean but need not be
in L2. For 0<r<=1/2 define the allowed singlet vector

    xi_r=P[(f/(2epsilon))1_(epsilon>=r)c],
    m_r=integral (f/(2epsilon))1_(epsilon>=r)
        =-integral (f/(2epsilon))1_(epsilon<r).           (Q9)

Here P subtracts the constant singlet mean. Its contribution cannot be
omitted. Since H_* maps an allowed singlet coefficient h to 2epsilon h n,

    H_*xi_r-y=[-f1_(epsilon<r)-2epsilon m_r]n,
    |m_r|<=Lr/2,
    ||H_*xi_r-y||<=L[sqrt(r)+sqrt(3/2)r]<=2Lsqrt(r),
    ||xi_r||<=3L/(2sqrt(r)).                             (Q10)

The residual bounds use Q4 and |f|<=L/epsilon. The last norm bound uses
that P is an orthogonal contraction before applying the epsilon^-4 bound.
The second residual inequality holds because r<=1/2<2/3.

The spectral theorem, with the zero eigenspace explicitly omitted, gives

    ||E_sigma y||<=||H_*xi_r-y||+sigma||xi_r||.

Set r=sigma<=1/2. Since E_sigma annihilates Pi, Q8-Q10 prove the uniform
bound that was existential in D11:

    M_zeta(sigma,T):=sup_(|tau|<=T)
             ||E_sigma B_kappa exp(-i tau A_kappa)zeta||
        <=(7/2) b^2 T sqrt(sigma)/sqrt(I0).              (Q11)

This is a special-vector estimate. Q7 used u(0)=0; no uniform estimate over
the zero-space unit ball or contradiction of the frozen nonuniformity
example is asserted.

## 4. The projected band and its complementary spectral estimate

Set a=5/4 and, for 0<lambda<=1/16, define

    Gamma_lambda=1_[5lambda/4,7lambda/4](H0(0)),
    w_lambda=||Gamma_lambda zeta||^2,
    phi_lambda=Gamma_lambda zeta/sqrt(w_lambda),
    beta_lambda=<c,phi_lambda>, n_lambda=sqrt(1-beta_lambda^2),
    chi_lambda=P phi_lambda/n_lambda,
    A_lambda=<zeta,chi_lambda>=sqrt(w_lambda)/n_lambda.     (Q12)

All are explicit through the given spectral interval. In particular
F chi_lambda=0 and Pi chi_lambda=A_lambda zeta. The source's exact contact
spectral density and volume bound imply

    n_lambda>=1/2, 0<=beta_lambda<=1/2,
    sqrt(lambda)/(3pi)<=A_lambda<=2sqrt(lambda),
    A_lambda<=1, A_lambda^2>=lambda/(9pi^2).              (Q13)

For explicit bounds on the entire stated range, the q support has
volume at most lambda^3/3 by L5, so Cauchy-Schwarz gives
beta_lambda^2<=lambda^3/3 and n_lambda>=1/2. In L7 the upper Jacobian
factor is less than two for E<=7lambda/4 and lambda<=1/16. Thus

    lambda/(8pi^2 I0)<=w_lambda<=lambda/(4pi^2 I0)
                                       <=3lambda/pi^2<lambda/3.

Dividing the upper bound by n_lambda^2>=1/4 gives A_lambda<=2sqrt(lambda).
The lower bound uses I0<=9/8 and n_lambda<=1. Finally A_lambda<=1 follows
from Cauchy-Schwarz between the two normalized physical vectors. These
finite bounds do not replace a source O(lambda^2) remainder by an assumed
numerical constant.

Let x=Q chi_lambda=chi_lambda-A_lambda zeta, so ||x||<=1. The complete
approximate inverse in L14, for 0<r<=min(1/2,a lambda/2), has

    ||H_*xi_r-x||<=A_lambda sqrt(r)/sqrt(I0),
    ||xi_r||<=C_lambda+A_lambda/[sqrt(I0)sqrt(r)],
    C_lambda=2/(a lambda n_lambda)+beta_lambda sqrt(I0)/n_lambda.
                                                               (Q14)

This inverse has both singlet and longitudinal components; it is not the
singlet-only inverse of Section 3. Its cutoff mean and the contribution from
the contact projection are retained. Applying E_sigma and taking r=sigma
proves, with no unquantified limit,

    ||E_sigma x||<=2A_lambda sqrt(sigma)/sqrt(I0)+sigma C_lambda,
    C_lambda<=4/lambda.                                  (Q15)

For the last inequality, Q13 and sqrt(I0)<2 give
C_lambda<=16/(5lambda)+2<4/lambda on the stated lambda range.

Combine the finite D11 estimate with Q11 for zeta. Combine B9 with Q15
for x, using B_kappa Q=F B_kappa Q and Q B_kappa Q=0. Finally use
F exp(-i tau H_*/delta)x=0. For |tau|<=T the transverse error satisfies

    e_perp:=sup ||F U_delta(tau)chi_lambda
                           -A_lambda u(tau)||
     <= delta[ A_lambda(2b+2Tb^2)+(2b+Tb^2)]/sigma
        +A_lambda[4+(7/2)b^2T^2]sqrt(sigma)/sqrt(I0)
        +2sigma C_lambda+(A_lambda+1)T r_delta.          (Q16)

The fast complementary evolution has been annihilated by F, not discarded
by a phase average. All displayed bounds are finite for their stated
parameters, so sigma may now be chosen as a function of lambda and delta.

At kappa0=(1,1,1), T=tau0=1/20, 0<delta<=1, the elementary bounds b<2,
1/sqrt(I0)<4, A_lambda<=1, and Q15 yield

    e_perp<=9delta/sigma+17A_lambda sqrt(sigma)
                              +8sigma/lambda+delta/5.   (Q17)

For example the four relaxed coefficients before rounding are 43/5,
807/50, 8, and 2/15, respectively. This estimate quantifies the
lambda-dependent initial vector; fixed-vector convergence alone would not.

## 5. Actual current: a finite error with the dressing amplitude retained

Write v=s.T and v_a=s_a T_a, with T_a=sigma_(1,a)c, and use the bounded
canonical current from the source. On the full physical space its linear
coefficient and trace identity are

    L_a=P cos(2q_a)P+|v_a><v|+|v><v_a|,
    sum_a L_a=3P-H_*^2/2-2epsilon^2 F.                   (Q18)

The placement correction is included. Since H_D(delta kappa0)^2 is exactly
conserved and both Hamiltonian norms are at most 2sqrt(3),

    |Delta <H_*^2>|<=8sqrt(3)delta(b+r_delta).            (Q19)

At the diagonal kappa0 the initial state and evolution are cyclically
invariant, so the three changes of <L_a> agree. Initially F chi_lambda=0.
The source also gives the actual-current remainder

    ||J_a(delta kappa0)/delta-L_a||
                              <=[(13+sqrt(3))/24]delta^2. (Q20)

Put e=e_perp. The comparison F U_delta chi_lambda=A_lambda u+error, with
||error||<=e, implies

    | ||epsilon F U_delta chi_lambda||^2
                       -A_lambda^2||epsilon u||^2 |
        <=3e(2A_lambda+e).                               (Q21)

This keeps the small dressing amplitude. Bounding the sum of these norms
by a constant independent of A_lambda would needlessly lose a lambda power.
Using Q18-Q21 and r_delta<=delta at kappa0 proves at tau0

    (actual a-current drift)/delta
      <=-(2/3)A_lambda^2||epsilon u(tau0)||^2
                          +4A_lambda e+2e^2+8delta.      (Q22)

For the final 8delta, the energy-square error contributes at most
4delta+(8/3)delta^2, and the two current remainders contribute at most
(5/4)delta^2; their sum is less than 8delta for delta<=1.
The explicit dressing response D23 gives

    (2/3)||epsilon u(tau0)||^2>=1/10800.                 (Q23)

Consequently the following fully finite conditions suffice for the diagonal
scaled drift to be at most -A_lambda^2/21600:

    e/A_lambda<=1/200000, delta/A_lambda^2<=1/345600.     (Q24)

Indeed 4/200000+2/200000^2+8/345600<1/21600. This step uses the actual
bounded current, not the free current or a leakage observable.

## 6. One polynomial choice valid on the whole stated band range

For every 0<lambda<=1/16 choose

    sigma=2^-40 lambda^(3/2), delta=2^-68 lambda^2.       (Q25)

This lies in 0<sigma<=min(1/2,a lambda/2) and delta<=1. Since pi<4,
Q13 gives A_lambda>=sqrt(lambda)/12. Divide Q17 by A_lambda to obtain

    e/A_lambda
     <=108delta/[sigma sqrt(lambda)]+17sqrt(sigma)
          +96sigma/lambda^(3/2)+(12/5)delta/sqrt(lambda)
     <=108*2^-28+17*2^-23+96*2^-40+(3/80)*2^-68
      <1/200000.                                       (Q26)

The second line uses lambda^(3/4)<=1/8 and lambda^(3/2)<=1/64.
The remaining margins are also explicit:

    delta/A_lambda^2<=9*2^-68<1/345600,
    delta/(A_lambda^2 lambda)<=144*2^-68<1/44236800,
    delta<=lambda/32.                                   (Q27)

Thus Q24 holds for every lambda in the stated range. No unidentified
lambda-dependent onset remains. The exponents and fractions in Q26-Q27
are checked by exact rational arithmetic in the separate control.

## 7. Actual K-dependent free preparation and one global normalization

For |K|<=lambda/16 use the actual positive projector and define

    phi_(lambda,K)=Pi_++(K)phi_lambda/||Pi_++(K)phi_lambda||,
    n_(lambda,K)=||P phi_(lambda,K)||,
    chi_(lambda,K)=P phi_(lambda,K)/n_(lambda,K).          (Q28)

The source's projector formula gives
||chi_(lambda,K)-chi_lambda||<=16|K|/lambda. Its unchanged q support
has epsilon<=7lambda/8 and normalized volume at most lambda^3/3.
The free energies move by at most |K|, so phi_(lambda,K) is an actual
positive free [lambda,2lambda]-band vector. It follows also that
n_(lambda,K)^2>=1-lambda^3/3. No free-band confinement after projection
or excluded evolution is asserted.

On |kappa-kappa0|<=1/10, the current and bounded-Duhamel estimates B20 give
||J_a(delta kappa)/delta||<=4, a current Lipschitz constant four, and an
evolution Lipschitz constant tau0. Therefore the scaled drift at fixed
chi_lambda changes by at most 9|kappa-kappa0|. Replacing that initial
state by chi_(lambda,delta kappa) costs at most 512delta/lambda.
These estimates apply directly at finite delta; no off-diagonal limiting
current formula is used.

Choose the fully explicit kappa radius

    eta_lambda=lambda/(6998400pi^2)<=A_lambda^2/777600.   (Q29)

It is smaller than 1/10, and |kappa|<2 on its ball. Q27 ensures
|delta kappa|<=lambda/16. Equations Q27,Q29 make each of the two preceding
errors at most A_lambda^2/86400. Combining with the diagonal bound Q24
therefore gives, for every |kappa-kappa0|<=eta_lambda,

    actual a-current drift <=-delta A_lambda^2/43200.    (Q30)

Let h be any fixed smooth scalar function supported in the unit ball,
nonzero on an open subset, with integral |h|^2 dy/(2pi)^3=1. For example,
normalize exp[-1/(1-|y|^2)] inside the ball and extend by zero. Put

    f_lambda(kappa)=eta_lambda^(-3/2)
                                  h((kappa-kappa0)/eta_lambda),
    Phi_(lambda,delta)(K,q)=delta^(-3/2)
                         f_lambda(K/delta)phi_(lambda,K)(q),
    N_(lambda,delta)=||P Phi_(lambda,delta)||,
    Chi_(lambda,delta)=P Phi_(lambda,delta)/N_(lambda,delta). (Q31)

The free packet has norm one by the exact K=delta kappa Jacobian, and is
supported in the actual free [lambda,2lambda] band. The physical packet
has one global normalization, with

    1-lambda^3/3<=N_(lambda,delta)^2<=1.                  (Q32)

Its actual kappa probability density is
|f_lambda(kappa)|^2 n_(lambda,delta kappa)^2/N_(lambda,delta)^2.
It integrates to one, generally differs from |f_lambda|^2, and retains the
same support. In physical total momentum, the center and radius are

    K_center=2^-68 lambda^2(1,1,1),
    K_radius=2^-68 lambda^3/(6998400pi^2).               (Q33)

This radius is positive, has nonempty three-dimensional support through h,
and the support stays away from K=0. The physical time is the common value
Q1 in every fiber. Integrating the pointwise estimate Q30 with these actual
weights proves Q2 without any fiberwise renormalization assumption.

## 8. Evidence, limits and next check

The separate helper `quantitative_band_current/quantitative_controls.py`
first checks all parameter/current/support budgets with exact fractions.
An exact three-antipodal-pair fixture then has I0=1 and a longitudinal
vector orthogonal to zeta. Its cutoff has nonzero removed mean, and the
complete mean-subtracted residual is checked exactly. The floating matrix
part uses actual sine/cosine points, constructs the physical zero projection,
and checks five effective orbit times, pointwise bounds, the longitudinal
Q B component, a nontrivial low-spectral projection, both corrector residuals,
and the full-space current trace identity. The fixture is not cubic, and no
componentwise rotational equality is claimed for it.

The finite fixture's weights are not torus quadrature weights satisfying Q4.
It checks operator/cutoff algebra; the continuum cone bounds and infinite-
dimensional evolution estimates rest on the proofs above and the frozen
sources. No enormous-time floating simulation is offered as verification of
Q2. The complete source, successful log, tool versions, source identities,
reading coverage and any failed runs are bound in the separate receipt.
These are author controls, not independent research review.

The incomplete routes remain visible. The uncut formal inverse need not be
L2. Omitting the singlet mean or the removed zeta coefficient invalidates its
residual bound. Strong convergence for fixed vectors does not control all
lambda-dependent states. Replacing Q21 by an amplitude-blind norm estimate
loses the useful parameter margin. The source's canonical dressing cancellation
and its zero-space nonuniformity example are unchanged. This note proves a
positive response for the specified family; it does not assert a universal
sign, monotone decay, all-state kinetic approximation or adopted event rate.

Independent checking is still required for the pointwise-to-spectral step,
the finite transverse bound, the small-amplitude current estimate and the
global preparation. The constants are proof choices, not fitted quantities.
The previous existential theorem remains intact, and this explicit family
needs no gap, absolute-continuity hypothesis or high-order spectral profiles.
No repository, frozen science source, registry, prompt, commit, PR or audit
status was changed.
