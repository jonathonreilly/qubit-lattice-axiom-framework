# Independent review of the explicit weak-momentum band-current onset

2026-10-11. This is a source-bound mathematical research check, not a formal
audit verdict, retained-status change, or numerical certification of an
infinite-dimensional theorem. No repository, author source, prior frozen
review, prompt, registry, commit or PR was changed.

## 1. Outcome and exact scope

I found no consequential defect in Q1–Q33 of the frozen 420-line
`EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md`. The claimed explicit
choice

    0<lambda<=1/16,
    sigma=2^-40 lambda^(3/2), delta=2^-68 lambda^2,
    t=1/(20delta)=2^68/(20lambda^2)

does remove the existential onset for the specified constructed packet
family. On the supplied walk, spin sector, hard contact exclusion, clock and
canonical local-energy placement, the proof supports the actual current
estimate in every component

    Delta <J_a> <= -delta A_lambda^2/43200
                <= -2^-68 lambda^3/(388800pi^2).

The result concerns one explicit normalizable family with a positive
three-dimensional total-momentum width. It does not establish a universal
current sign, monotonic decay, an all-state approximation, a physical event
clock or a kinetic rate. It is not an operator-norm approximation on the
zero-space unit ball. The frozen nonuniformity example remains applicable.

The decisive new estimate is a quantitative spectral-mass bound for the
particular effective orbit starting from the normalized dressing vector.
The state-dependent inverse truncation and the dressing amplitude in the
current error are both necessary. I reconstructed these before reading the
frozen quantitative source, with a slightly looser cutoff coefficient, and
then checked the complete changed argument against that reconstruction.

## 2. Sources, coverage and provenance

All files below are under
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| File | SHA-256 | Coverage in this review |
| --- | --- | --- |
| `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md` | `ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400` | Complete 420-line source; all new Q1–Q33, proof prose and limits. |
| `quantitative_band_current/receipt.json` | `2eaa2eda5f5fec364669e2d6709421a69528843bc43f55f8a1340d3a158967b5` | Complete receipt; every input/output identity, byte count and line count checked. |
| `quantitative_band_current/quantitative_controls.py` | `0e9a63cd42abd9fc3d4f68bb1a8568825e25c36c589f2a6f028ad690654f1df9` | Complete 130-line author helper read. No replay counted as independent evidence. |
| `quantitative_band_current/quantitative_controls.log` | `e7f76bd5e5389431094e9fe0ffc7d89ef4212cfebec39658080a24b1169a3597` | Complete 7-line author log read. |
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | Earlier complete independent review reused unchanged; B5–B13 and B17–B24 reread for this composition. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Earlier complete independent review reused unchanged; continuum cone estimates and complete L13–L14 inverse reconstructed as needed. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Earlier complete independent review reused unchanged; effective block, cutoff-Duhamel estimate D11, current expansion and D23 response. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Complete earlier reading and reconstruction reused unchanged; fixes the actual bounded current and its placement terms. |

The new identity inventory also verifies that all three immediately preceding
long-time, degenerate and two-scale review/report-receipt pairs remain
unchanged. The inventory is
`excluded_walk_quantitative_review/source_identity_verification.json`.
Its 14 records all match the expected hashes. The new receipt records exact
identities of this report and the independent controls separately.

I did not perform a new repository-wide novelty search, inspect unrelated
open PRs, use a generic-K scattering theorem or infer a current response
from leakage. The supplied-model and canonical-current premises are the
already reviewed, unchanged ones. This continuation uses bounded evolution
and spectral calculus, without a spectral gap or absolute-continuity input.

## 3. Independent reconstruction of the new spectral bound

Use the normalized torus measure. On the physical space `ran P`, with the
constant singlet removed, write

    H=H_D(0), Pi=F+|zeta><zeta|, Q=P-Pi,
    zeta=n/(2epsilon sqrt(I0)), B=i d cross on triplets.

The physical zero space is exactly `ran Pi`; the auxiliary constant
singlet is not an additional allowed zero vector. For the effective orbit
`z(tau)=exp(-i tau Pi B Pi)zeta=u(tau)+alpha(tau)zeta`, the transverse
multiplication block is Hermitian at almost every q. Its pointwise
variation-of-constants formula gives, for both signs of time,

    |u(tau,q)|<=T b/(2epsilon sqrt(I0)),
    ||u(tau)||<=Tb, |alpha(tau)|<=1, |tau|<=T.

This uses `u(0)=0` and `||g||<=b`. Since g is in L2 and its multiplying
propagator is pointwise unitary, the representative and the almost-everywhere
bound are legitimate; no derivative of the singular dressing vector is
taken.

Let `beta=<zeta,Bu>` and `G=n dot Bu-beta/(2epsilon sqrt(I0))`. The exact
projection algebra gives

    Q B z=nG, integral G/(2epsilon)=0,
    |G|<=L/epsilon, L=T b^2/sqrt(I0).

Indeed `Bzeta=g` is transverse and Q removes it, while Q removes the
remaining dressing coefficient of Bu. The two terms in the pointwise
bound each cost at most `T b^2/(2epsilon sqrt(I0))`. The mean identity is
ordinary integration, since `epsilon^-2` is integrable. The scalar G and
its formal singlet inverse are exchange even.

For `0<r<=1/2`, let

    f=G/(2epsilon), m_r=integral 1_(epsilon>=r) f,
    f_r=1_(epsilon>=r)f-m_r, xi_r=f_r c.

Then xi_r is physical. The complete residual has the sign and mean term

    H xi_r-nG=[-G 1_(epsilon<r)-2epsilon m_r]n.

The low-cone integral bounds give

    |m_r|<=Lr/2,
    ||H xi_r-nG||<=L[sqrt(r)+sqrt(3/2)r]<=2L sqrt(r).

For the inverse norm, orthogonal projection onto mean-zero singlets is a
contraction. Thus the *source's* sharper constant is justified:

    ||xi_r|| <= ||1_(epsilon>=r)G/(2epsilon)||
              <=3L/(2sqrt(r)).

My pre-freeze derivation used the weaker `2L/sqrt(r)` obtained by separate
triangle bounds; it still sufficed for the final constants. This difference
is an improvement in the source, not an unproved substitution.

For `E_sigma=1_(0<|H|<=sigma)(H)`, the bounded spectral theorem yields

    ||E_sigma nG||<=||H xi_r-nG||+sigma||xi_r||.

No commutation between a spatial cutoff and the spectral projection is
assumed. Taking `r=sigma<=1/2` proves uniformly on `|tau|<=T`

    ||E_sigma B exp(-i tau Pi B Pi)zeta||
       <=(7/2)T b^2 sqrt(sigma)/sqrt(I0).

The zero spectral projection is explicitly excluded. The full inverse
need not exist in L2, and the argument never uses it. This confirms Q7–Q11.

## 4. Complementary state, finite transverse error and parameter domains

For the band state, `x=chi_lambda-A_lambda zeta` lies in ran Q and has
norm at most one. Reusing the complete two-component inverse in L14 gives

    ||H xi_r-x||<=A_lambda sqrt(r)/sqrt(I0),
    ||xi_r||<=C_lambda+A_lambda/(sqrt(I0)sqrt(r)),
    C_lambda=2/(a lambda n_lambda)+beta_lambda sqrt(I0)/n_lambda,
    a=5/4, 0<r<=min(1/2,a lambda/2).

Both components, the subtracted singlet mean, and the contact contribution
are present. Applying E_sigma at `r=sigma` gives precisely Q15. This is a
different inverse from the pure-singlet construction in Section 3.

The finite bounds in Q13 are justified for the entire declared lambda
interval, rather than by an asymptotic remainder with an unknown constant.
The q-support volume is at most `lambda^3/3`, so
`beta_lambda^2<=lambda^3/3` and `n_lambda>=1/2`. The exact density Jacobian
is bounded above by two on the band and below by one. Consequently

    lambda/(8pi^2 I0)<=w_lambda<=lambda/(4pi^2 I0),
    sqrt(lambda)/(3pi)<=A_lambda<=2sqrt(lambda), A_lambda<=1.

The upper bound on C_lambda is valid: `C_lambda<=16/(5lambda)+2<4/lambda`
on `0<lambda<=1/16`. The phase choice makes beta_lambda nonnegative;
the weaker bound `beta_lambda<=1/2` is already sufficient.

For completeness, the two evolution correctors have opposite signs and
different ranges. For the zero-space orbit use
`y=-H^-1 1_(|H|>sigma) Bv`; its residual contains `-E_sigma Bv` plus
`delta(i y'-By)`. For the high-spectral complementary state use
`y=B H^-1 v`; the special identity `BQ=FBQ` gives `Hy=0` and residual
`-delta By`. Both inverses are restricted to the high-spectral subspace.
These are the checked D11 and B9 estimates, not a norm-averaging claim.

Adding them with the factor A_lambda on the first estimate gives Q16.
Applying F annihilates the remaining fast Q evolution exactly. At
`T=1/20`, `b=sqrt(3)<2`, their relaxed coefficients are

    delta/sigma: 4b+3Tb^2 <=43/5<9,
    A_lambda sqrt(sigma):
      [4+(7/2)b^2T^2]/sqrt(I0) <807/50<17,
    sigma/lambda: 2C_lambda lambda<=8,
    remainder: (A_lambda+1)T r_delta<=2delta/15<delta/5.

Thus Q17 is a finite estimate for the lambda-dependent state, not an
exchange of two qualitative limits. With the proposed sigma and delta,

    sigma/lambda<=2^-42<5/8, sigma<=2^-46<1/2,
    delta/lambda<=2^-72<1/32, delta<=2^-76<1.

All cutoff, momentum-preparation and generator-remainder domains therefore
hold simultaneously, including the endpoint `lambda=1/16`.

## 5. Actual current, explicit margins and global normalization

The full physical-space identity is

    sum_a L_a=3P-H^2/2-2epsilon^2 F.

It includes the canonical rank-one placement correction. Multiplication
by epsilon squared commutes with F but need not commute with P. The proof
uses this full identity, not only its zero-space compression.

At diagonal kappa the initial state and actual evolution are cyclically
invariant, so the three L-current changes agree. The initial transverse
part vanishes. If `e=||F U_delta chi_lambda-A_lambda u||`, then

    | ||epsilon F U_delta chi_lambda||^2
                -A_lambda^2||epsilon u||^2 |
        <=3e(2A_lambda+e).

After multiplication by 2/3, this is `4A_lambda e+2e^2`; replacing the
small amplitude by a unit-state bound would lose the useful margin.
Conservation of the bounded actual Hamiltonian squared controls the other
trace term for arbitrary time. The source's bound contributes at most
`4delta+(8/3)delta^2`; two canonical-current remainders cost at most
`(5/4)delta^2`. Their sum is below `8delta` for `delta<=1`. Independently,
the exact Lipschitz bound `||H_D(delta kappa0)-H||<=delta sqrt(3)` gives
the slightly stronger energy contribution `4delta` directly.

D23 applies at `tau0=1/20`, since this is below its small-time threshold,
and gives `(2/3)||epsilon u(tau0)||^2>=1/10800`. The sufficient margins
in Q24 are consistent:

    4/200000+2/200000^2+8/345600<1/21600.

Using `A_lambda>=sqrt(lambda)/12`, the relative error from Q17 is at most

    108*2^-28+17*2^-23+96*2^-40+(3/80)*2^-68
      =57352588089098243/23611832414348226068480
      <1/200000.

The exact rational controls separately check this strict inequality and
all cutoff/support budgets. Moreover

    delta/A_lambda^2<=9*2^-68<1/345600,
    delta/(A_lambda^2 lambda)<=144*2^-68<1/44236800.

Thus the diagonal current drift is at most `-delta A_lambda^2/21600`
without an unidentified onset. The source uses a smaller, fully explicit
envelope radius than the older existential construction:

    eta_lambda=lambda/(6998400pi^2)<=A_lambda^2/777600.

The scaled-current continuity error is `9eta_lambda<=A_lambda^2/86400`.
The change to the actual K-dependent ++ preparation costs
`512delta/lambda<=A_lambda^2/86400`. Since

    -1/21600+2/86400=-1/43200,

the same strict negative bound holds on every fiber of the packet support.
The norm and Lipschitz constants from B20 apply: `eta_lambda<1/10`,
`|kappa|<2`, `|delta kappa|<=lambda/16`. Projecting the original free
vector into the actual ++ sector retains its q support; the free energy
change is at most |K| and the band remains inside `[lambda,2lambda]`.
It is the preparation that has this support, not the subsequent excluded
evolution or the contact-projected state as a free spectral assertion.

The free envelope in Q31 has norm one in `dK/(2pi)^3` by the exact
`K=delta kappa` Jacobian, including both delta and eta prefactors. Its
support radius is `2^-68 lambda^3/(6998400pi^2)>0`, its center is
`2^-68 lambda^2(1,1,1)`, and it lies away from K=0. Smoothness of h and
the fixed support margin make this an ordinary normalizable direct-integral
vector; no delta-fiber state is substituted for it.

The physical normalization is applied once:

    N^2=integral |f_lambda(kappa)|^2 n_(lambda,delta kappa)^2
                       d kappa/(2pi)^3,
    1-lambda^3/3<=N^2<=1.

The actual momentum weights are `|f_lambda|^2 n_(lambda,delta kappa)^2/N^2`,
not generally `|f_lambda|^2`. They are nonnegative, integrate to one and
have the same support. All fibers are evaluated at the same physical time
`1/(20delta)`. Integrating the uniform signed fiber bound proves Q2 with
the stated global normalization and constants. There is no lost volume
factor or inferred off-diagonal limiting-current formula.

## 6. Independent finite controls and remaining limits

New independent evidence is under `excluded_walk_quantitative_review/`:

- `independent_quantitative_controls.py`: 122 lines, authored before the
  quantitative-source freeze and importing no author helper.
- `independent_quantitative_controls.log`: complete 28-line log, read in
  full; first execution exited zero with no failed runs or changed tolerance.
- `independent_execution.json`: Python 3.13.5 / SymPy 1.14.0; 120-second
  timeout, approximately 0.426 seconds outer runtime.
- `source_identity_verification.json`: exact source and prior-review
  identity verification, with all 14 records matching.
- `CHECKPOINT.md`: initial independent reconstruction and completion state.
- `independent_review_receipt.json`: final source/report/evidence binding.

The independent algebra fixture consists of four equally weighted implicit
antipodal pairs with sine vectors `(1/5,0,0)`, `(0,3/5,0)`, `(0,0,4/5)`,
and `(3/5,4/5,0)`, and non-diagonal `kappa=(2/3,-3/7,5/4)`. Actual cosine
values enter B. Taking `u=g` gives a nonzero removed dressing coefficient.
The controls derive QBu, its mean-zero formal inverse, and the cutoff
residual exactly. A cutoff at r=1/2 has the nonzero mean

    -22068041 sqrt(4369)/44895354672.

Reversing the mean-restoration residual sign fails the exact discriminator.
The fixture has `I0=4369/2304`; this is not a continuum value and does not
satisfy the continuum upper bound. No torus-integral or spectral-mass
certification is drawn from the fixture. It checks the operator and cutoff
algebra. The continuum estimate instead follows from Section 3 and the
already checked eight-cone integral bounds. The remaining independent
controls use exact rational arithmetic for the scale powers and budgets.

I read the entire separate author helper and its successful log but did not
replay it or count its matrix checks as additional independence. Its stated
scope is honest: the finite weighted fixture is not torus quadrature. The
new analytic check, the independently chosen algebra fixture and the exact
budget calculation are the evidence supplied by this review.

There is no remaining mathematical fix requested for these frozen bytes.
This does not certify an optimal exponent or constant, an experimentally
relevant onset, or a theorem for arbitrary band states. The uncut reduced
inverse may fail to belong to L2; removing either the singlet cutoff mean or
the dressing subtraction invalidates the argument. Qualitative fixed-vector
convergence alone would not establish this quantitative family. None of
those failed routes has been promoted into a premise.

No Lean proof or machine-checked continuum derivation was produced. A
formalization would still have to encode the spectral-cutoff inequality,
the bounded Duhamel estimates, the continuum cone integrals, and the
direct-integral/current normalization argument. The source remains a
conditional supplied-model theorem with the selected independent research
check recorded here; formal retained status is outside this review.
