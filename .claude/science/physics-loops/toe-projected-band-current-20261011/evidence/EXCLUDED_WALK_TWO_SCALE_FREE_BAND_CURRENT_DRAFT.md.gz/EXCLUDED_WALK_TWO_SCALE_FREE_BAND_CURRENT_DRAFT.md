---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Long-time canonical-current response from projected free-band preparation

2026-10-11. Root derivation in progress, with a separate independent check.

Two scales are used in a stated order. Fix a small free energy-band scale
lambda, then take total momentum K=delta kappa much smaller. The initial
state is the normalized contact projection of an actual free positive-band
packet. At a time proportional to 1/delta its canonical energy current
changes by at least a positive constant times delta lambda. A normalized
packet with three-dimensional total-momentum support has this property.
The onset in delta is existential for each fixed lambda; no polynomial
relation delta(lambda) is proved here.

This is a supplied-walk theorem. Coordinates, clock, antisymmetric spin
pair, contact exclusion, and local energy placement are inherited model
premises. It does not derive a physical clock or a many-body relaxation
law. It concerns a constructed family, not all initial free-band states.

## 1. Frozen inputs and new obligations

All torus measures are dq/(2pi)^3; inner products are linear in the second
argument. The complete arguments in the following frozen sources were
read and their identities checked before this extension:

- `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md`, 457 lines, SHA-256
  `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324`.
  Its zero space, explicit projected band, spectral weight, and perturbed
  free-band preparation are used. Independent review SHA-256
  `b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f`.
- `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md`, 549 lines, SHA-256
  `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`.
  Its generator expansion, fixed-zero-vector limit, current expansion,
  and diagonal dressing response are used. Its new independent review
  exists separately; it does not review the new argument below.
- The canonical-current source SHA-256
  `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe`
  fixes the energy-placement convention throughout.

New obligations are: decoupling for the nonzero spectral component;
the full-space current trace identity; transfer of the resulting current
response to actual K-dependent free-band preparation; and global packet
normalization. Neither scattering completeness nor Cook regularity is used.

## 2. Operator setting

Write c for the constant singlet, C=|c><c|, P=I-C, and

    H_D(K)=P H0(K)P on ran P,
    H0(K,q)=sigma_1.sin(K/2+q)+sigma_2.sin(K/2-q),
    H_*=H_D(0), s=sin q, epsilon=|s|, n=s/epsilon,
    I0=integral 1/(4epsilon^2),
    zeta=n/(2epsilon sqrt(I0)) in Cartesian triplet coordinates.

Let F be the pointwise transverse-triplet projection, with zero singlet
block. The full physical zero projection and its complement are

    Pi=F+|zeta><zeta|, Q=P-Pi.                              (B1)

All following identities act on the fixed physical Hilbert space ran P.
In particular c is excluded; it is not an additional physical zero mode.
The bounded generator expansion at K=delta kappa is

    H_D(delta kappa)/delta=H_*/delta+B_kappa+R_delta,
    B_kappa u=i d cross u, d_j=kappa_j cos q_j,
    B_kappa kills the singlet,
    ||B_kappa||<=b=|kappa|,
    ||R_delta||<=r_delta=delta b^2/4+delta^2 b^3/24.        (B2)

The zero-space generator A_kappa=Pi B_kappa Pi, on (u,alpha) in
ran F direct-sum span{zeta}, has the block

    A_kappa=[ i(d.n)n cross       g_kappa ],
             [ <g_kappa|             0    ],
    g_kappa=i(d cross n)/(2epsilon sqrt(I0)).              (B3)

The frozen cutoff proof gives, for each fixed z in ran Pi and finite T,

    sup_(|tau|<=T)||U_delta(tau)z-exp(-i tau A_kappa)z|| ->0,
    U_delta(tau)=exp[-i tau H_D(delta kappa)/delta].        (B4)

## 3. Decoupling of every fixed nonzero-spectral component

A vector in ran Q has only singlet and longitudinal-triplet components.
The derivative B kills its singlet component and maps its longitudinal
component to a transverse one. Therefore

    B_kappa Q=F B_kappa Q,  Q B_kappa Q=0.                 (B5)

This identity is special to the supplied symbol; it is not asserted for
an arbitrary bounded perturbation. It permits the following complementary
strong comparison, for every fixed x in ran Q:

    sup_(|tau|<=T)||U_delta(tau)x-exp(-i tau H_*/delta)x|| ->0. (B6)

Here is a direct proof with its missing uniform estimate exposed.
First take x supported spectrally on |H_*|>sigma, sigma>0. Put

    v(tau)=exp(-i tau H_*/delta)x,
    y(tau)=B_kappa H_*^-1 v(tau),
    w(tau)=v(tau)+delta y(tau).                            (B7)

The inverse is restricted to that spectral support, so its norm is at
most 1/sigma. By B5, y is in ran F and H_*y=0. Differentiation yields
`i delta partial_tau y=B_kappa v`. Hence

    [i partial_tau-(H_*/delta+B_kappa)]w=-delta B_kappa y. (B8)

Initial and final correctors have norm at most delta b||x||/sigma;
the integrated residual costs T delta b^2||x||/sigma. Duhamel for R_delta
adds T r_delta||x||. For general fixed x in ran Q, cutting away its
low nonzero spectral part E_sigma x gives the bound

    sup_(|tau|<=T)||U_delta(tau)x-exp(-i tau H_*/delta)x||
      <=2||E_sigma x||
        +delta(2b+T b^2)||x||/sigma+T r_delta||x||,
    E_sigma=1_(0<|H_*|<=sigma)(H_*).                      (B9)

The first term tends to zero as sigma decreases to zero. Taking delta
to zero at fixed sigma, then sigma to zero, proves B6. No inverse on
the entire gapless complement, spectral gap, or absolute continuity
claim has been used. Combining B4 and B6 gives, for every fixed z,

    U_delta(tau)z
      =exp(-i tau A_kappa)Pi z+exp(-i tau H_*/delta)Qz+o(1),
    F U_delta(tau)z -> F exp(-i tau A_kappa)Pi z.           (B10)

Both errors are strong and uniform on compact tau intervals. The fast
Q term is retained, not declared convergent or discarded by a phase
average. In the second line F annihilates that term exactly.

## 4. An identity for the full canonical-current trace

Set v=s.T and v_a=s_a T_a, where T_a=sigma_(1,a)c. The canonical bounded
current and its weak-momentum expansion are

    J_a(K)=P[sin K_a cos(2q_a)]P-|h'_a><h|-|h><h'_a|,
    h=2 sum_j cos(K_j/2)v_j, h'_a=-sin(K_a/2)v_a,
    J_a(delta kappa)/delta=kappa_a L_a+O(delta^2),
    L_a=P cos(2q_a)P+|v_a><v|+|v><v_a|.                  (B11)

The entire physical-space identity is

    sum_a L_a=3P-H_*^2/2-2epsilon^2 F.                   (B12)

Indeed H0(0)^2=4epsilon^2(I-F), H0(0)c=2v, and Pc=0 give

    H_*^2=4P epsilon^2 P-4epsilon^2 F-4|v><v|.

Summing B11 gives `3P-2P epsilon^2 P+2|v><v|`, proving B12.
Multiplication by epsilon^2 commutes with F; it need not commute with P.
Its placement in the displayed formulas matters.

Exact conservation of H_D(delta kappa)^2 controls the other term in B12.
Since both H_D(K) and H_* have norm at most 2sqrt(3), for any normalized z
and all tau,

    |<U_delta z,H_*^2 U_delta z>-<z,H_*^2 z>|
      <=2||H_D(delta kappa)^2-H_*^2||
      <=8sqrt(3) delta(b+r_delta).                       (B13)

Thus the limiting current trace sees the transverse population in B10.
This uses a bounded operator identity, not an unbounded dipole acting
on the singular dressing vector.

## 5. An explicit fixed-band initial vector

For 0<lambda<=1/16 set I_lambda=[5lambda/4,7lambda/4] and

    Gamma_lambda=1_(I_lambda)(H0(0)),
    w_lambda=||Gamma_lambda zeta||^2,
    phi_lambda=Gamma_lambda zeta/sqrt(w_lambda),
    beta_lambda=<c,phi_lambda>, n_lambda=sqrt(1-beta_lambda^2),
    chi_lambda=P phi_lambda/n_lambda,
    A_lambda=<zeta,chi_lambda>=sqrt(w_lambda)/n_lambda.     (B14)

This normalized physical vector obeys F chi_lambda=0 and
Pi chi_lambda=A_lambda zeta. Its construction and norm are explicit.
The frozen contact-density calculation gives

    A_lambda^2=lambda/(8pi^2 I0)[1+O(lambda^2)],
    A_lambda^2>=w_lambda>=lambda/(8pi^2 I0)>=lambda/(9pi^2),
    n_lambda>=1/2, 0<A_lambda<=1.                        (B15)

The lower bound uses rho(0,E)>=E^2/(4pi^2), the interval length lambda/2,
and I0<=9/8. Sharp spectral endpoints are allowed: all operators used
here are bounded, and no Cook profile condition is imposed.

Take kappa0=(1,1,1), tau0=1/20, and let
`exp(-i tau A_kappa0)zeta=(u(tau),alpha(tau))` in B3. Proper cyclic
coordinate rotation fixes chi_lambda and H_D(delta kappa0), while
permuting the three currents. Thus their expectations are equal.
Combining B10-B13 and the current expansion gives the actual fiber limit

    lim_(delta->0) [<U_delta(tau)chi_lambda,J_a(delta kappa0)
                       U_delta(tau)chi_lambda>
                    -<chi_lambda,J_a(delta kappa0)chi_lambda>]/delta
       =-(2/3)A_lambda^2 ||epsilon u(tau)||^2.             (B16)

The frozen diagonal dressing response at tau0 gives

    (2/3)||epsilon u(tau0)||^2>=1/10800.                 (B17)

In particular there exists delta_1(lambda)>0 such that, for all
0<delta<delta_1(lambda), each scaled drift in B16 is at most
`-A_lambda^2/21600`. This is a fixed-lambda limit. Neither B9 nor the
zero-space cutoff estimate supplies a polynomial delta_1(lambda).

## 6. Actual free-band preparation at nonzero K

For |K|<=lambda/16 use the actual positive spin projector to define

    phi_(lambda,K)=Pi_++(K)phi_lambda/||Pi_++(K)phi_lambda||,
    n_(lambda,K)=||P phi_(lambda,K)||,
    chi_(lambda,K)=P phi_(lambda,K)/n_(lambda,K).           (B18)

The original q support is unchanged. Both one-particle energies there
are separated from zero by a constant times lambda, so the projector
formula gives

    ||phi_(lambda,K)-phi_lambda||<=4|K|/lambda,
    ||chi_(lambda,K)-chi_lambda||<=16|K|/lambda.           (B19)

The ++ energy changes by at most |K|, so phi_(lambda,K) belongs to the
actual free [lambda,2lambda] positive band at that K. This is not a
claim that its excluded evolution remains in that free band.

Here are explicit margins for a full-dimensional K packet. On
|kappa-kappa0|<=1/10 and 0<delta<=1, B11 gives

    ||J_a(delta kappa)/delta||<=4,
    ||J_a(delta kappa)/delta-J_a(delta kappa0)/delta||
      <=4|kappa-kappa0|,
    ||U_(delta,kappa)(tau0)-U_(delta,kappa0)(tau0)||
      <=tau0|kappa-kappa0|.                              (B20)

For the second bound, the multiplication term costs |kappa-kappa0|.
The two rank-one terms cost at most
`(sqrt(3)+delta/2)|kappa-kappa0|`, since
`||h||<=sqrt(6)`, `||h'_a(K)-h'_a(K0)||<=delta|kappa-kappa0|/(2sqrt(2))`,
`||h(K)-h(K0)||<=delta|kappa-kappa0|/sqrt(2)`, and
`||h'_a(K0)||<=delta/(2sqrt(2))`.
Their sum is less than four. The last bound follows from
`||H_D(K)-H_D(K0)||<=|K-K0|` and bounded Duhamel.

Holding the initial chi_lambda fixed, B20 bounds the change of the scaled
drift between kappa and kappa0 by `9|kappa-kappa0|`.
Replacing it by the actual initial chi_(lambda,delta kappa) costs at most
`4*4*32delta/lambda=512delta/lambda`, using B19 and |kappa|<2.

Set

    rho_lambda=A_lambda^2/777600,
    delta_0(lambda)=min(delta_1(lambda), 1, lambda/32,
                        A_lambda^2 lambda/44236800).      (B21)

The last two errors are each at most A_lambda^2/86400. Consequently,
for 0<delta<delta_0(lambda), every |kappa-kappa0|<=rho_lambda and each a,

    <U_(delta,kappa)(tau0)chi_(lambda,delta kappa),
         J_a(delta kappa)U_(delta,kappa)(tau0)chi_(lambda,delta kappa)>
       -<chi_(lambda,delta kappa),J_a(delta kappa)chi_(lambda,delta kappa)>
      <=-delta A_lambda^2/43200.                         (B22)

All three actual current components have the same strict sign bound.
No componentwise limit away from the diagonal has been assumed; the
finite-delta continuity estimate transfers the sign instead.

## 7. One globally normalized projected free packet

Choose any scalar envelope f_lambda with norm one in dkappa/(2pi)^3,
supported in the ball B(kappa0,rho_lambda). Its support may have nonempty
three-dimensional interior. Define the actual free packet and its single
global contact projection by

    Phi_(lambda,delta)(K,q)
      =delta^(-3/2) f_lambda(K/delta) phi_(lambda,K)(q),
    N_(lambda,delta)=||P Phi_(lambda,delta)||,
    Chi_(lambda,delta)=P Phi_(lambda,delta)/N_(lambda,delta). (B23)

The free packet has norm one and lies in its actual positive free band
[lambda,2lambda]. The physical packet has norm one after the stated
single global normalization. In kappa variables its probability weights
are

    |f_lambda(kappa)|^2 n_(lambda,delta kappa)^2/N_(lambda,delta)^2.

They integrate to one, need not equal |f_lambda|^2, and stay inside the
same support. Integrating B22 with these weights proves

    Delta <J_a> at physical time t=tau0/delta
      <=-delta A_lambda^2/43200
      <=-delta lambda/(388800pi^2),  a=1,2,3.             (B24)

This is an ordinary L2 packet with nonzero total-momentum support away
from K=0. It has an actual, finite time for every chosen delta. The proof
has not quantified the existential threshold delta_1(lambda).

## 8. Scope and next check

The construction fills a specific preparation interface: the input to the
excluded dynamics is now the projection of an actual free positive-band
packet, with one global normalization. Its order-lambda dressing weight
feeds the transverse sector on the much longer time scale 1/delta, and
the full trace identity converts that population into current response.
The initial dressing cancellation is preserved rather than bypassed.

The ordering is `fix lambda; delta ->0`, followed, if desired, by selecting
lambda ->0 and delta below its individual threshold. It does not give
K comparable to lambda, a common polynomial time law, a generic initial
state result, a monotone decay statement, or a many-body transport rate.
The existing finite-time band bounds and the zero-space nonuniformity
example retain their stated domains.

Before publication: independently check B1-B24, run targeted controls of
B5/B8/B12 and the packet constants, record source identities and failed
routes, and apply the repository's negative-claim scope checks to any
corollary ruling out a uniform all-time bound. This draft is not a Lean
certificate, an audit verdict, or a retained theorem.
