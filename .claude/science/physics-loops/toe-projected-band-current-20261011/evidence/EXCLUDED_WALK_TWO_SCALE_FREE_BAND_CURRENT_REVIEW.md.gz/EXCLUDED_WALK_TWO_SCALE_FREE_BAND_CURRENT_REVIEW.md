# Independent review of the two-scale free-band current construction

2026-10-11. Research review, not an audit verdict or retained-status action.
The complete reviewed source is
`EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md`, 327 lines, SHA-256
`0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c`.

**Finding: no consequential defect found in B1–B24 within the stated
supplied-model and ordered-limit scope.** The complement comparison, full
physical-space current trace, actual positive-band preparation, finite-delta
sign transfer, and single global normalization compose as claimed. The
result concerns a constructed family. Its threshold in delta is
existential for each fixed lambda; the proof supplies neither a polynomial
delta(lambda) choice nor a uniform convergence rate. The author's proposed
identities and numerical constants were reconstructed explicitly, rather
than accepted as premises merely because they appeared in the review brief.

## 1. Sources and independence

All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Source | SHA-256 | Coverage |
|---|---|---|
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | All 327 lines and every equation B1–B24. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Complete 549-line argument previously read and independently reconstructed; unchanged. |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Frozen previous review; supports only the premises it actually reviewed. |
| `excluded_walk_degenerate_review/independent_review_receipt.json` | `c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa` | Frozen previous source/evidence binding. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Prior complete 457-line review reused: kernel, density, projected band, and perturbed ++ preparation. |
| `EXCLUDED_WALK_LONG_TIME_REVIEW.md` | `b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f` | Prior independent reconstruction, unchanged. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | All 190 lines reread here; bounded current, energy placement, and earlier finite-time scope. |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526` | Prior complete 322-line reading reused; normalized torus, chart and density conventions. |

The supplied walk/antisymmetry/exclusion contract and instructions remain
the unchanged revisions already bound in the degenerate review. No
stationary scattering theorem, Cook regularity, or absolute-continuity
claim is used to discard the fast spectral component.

Before reading the new author draft, I derived the Q-to-F mapping, the
complement corrector residual, the full trace identity, the diagonal
current limit, and the packet error budget from those frozen premises.
An independent helper was written from that reconstruction before reading
the draft. It imports no author code. The final source was then read
completely and compared with the derivation. Shared hints identify the
target; they are not counted as an independent check of its truth.

## 2. Complement dynamics: B5–B10

Within the physical space, F removes all transverse triplet fields and
the remaining zero vector zeta is longitudinal. Consequently every vector
in `Q=P-Pi` has only a mean-zero singlet coefficient and a longitudinal
triplet coefficient orthogonal to zeta. The derivative B kills the
singlet coefficient and takes a longitudinal triplet `n G` to
`i(d cross n)G`, which is pointwise transverse. Therefore

    B Q = F B Q,   Q B Q = 0,   H_* B Q = 0.

This is an exact property of this symbol, including non-diagonal kappa.
It would be false for a generic bounded perturbation; no generic gapless
averaging theorem is being silently substituted.

For x supported on `|H_*|>sigma`, write

    v=exp(-i tau H_*/delta)x,
    y=B H_*^-1 v,   w=v+delta y.

The cutoff inverse preserves Q. Thus y lies in F, `H_*y=0`, and
`i delta y'=Bv`. Direct substitution gives

    i w'-(H_*/delta+B)w = -delta B y.

Both the positive corrector sign and the order of B and the inverse
matter. The endpoint corrections cost `2delta b||x||/sigma`, and the
integrated residual costs `Tdelta b^2||x||/sigma`. The exact-generator
remainder costs `T r_delta||x||`. For a general fixed Q vector, the
discarded low-spectral part contributes at most `2||E_sigma x||`, because
both compared evolutions are unitary. This proves B9 with every displayed
factor, for both signs of time.

The low spectral norm tends to zero as sigma tends to zero, since x has
no zero-spectral component. Letting delta tend to zero at fixed sigma and
then taking sigma to zero proves B6 uniformly on compact rescaled times.
The argument does not require a full reduced inverse or a spectral gap.

Combining this comparison with the independently checked zero-space
comparison gives B10 for every fixed physical z. The fast term stays in Q
because Q is a spectral projection of H_*. F annihilates it exactly. It
has not been declared strongly convergent or replaced by a phase average.
This distinction is essential: it permits convergence of the transverse
population without a claim about the fast vector's limit.

## 3. Full trace and the actual diagonal current: B11–B17

The canonical bounded-current identity is inherited from the specified
compressed local energy placement. In the singlet/triplet representation,

    H0(0)^2 = 4epsilon^2(I-F),   H0(0)c=2v.

Expanding the middle contact projection in `P H0 P H0 P` gives

    H_*^2 = 4P epsilon^2 P - 4epsilon^2 F - 4|v><v|.

Here F commutes with epsilon^2 and with P, but epsilon^2 does not in
general commute with P. On the other hand, summing the actual L_a gives
`3P-2P epsilon^2 P+2|v><v|`. Eliminating the middle expression yields

    sum_a L_a = 3P-H_*^2/2-2epsilon^2 F.

This proves B12 on the entire physical space, including all cross terms.
The earlier identity restricted to singlet/longitudinal fields would
miss its last term. The new independent exact fixture has unequal radii,
so the test does not accidentally assume that epsilon^2 commutes with P.
It also explicitly rejects the identity with the transverse term deleted.

Exact H_D(K)-energy conservation provides a uniform-in-time bound for the
change in the H_*^2 expectation. For a unit vector, that change is at most
`2||H_D(K)^2-H_*^2||`. Since both Hamiltonian norms are at most `2sqrt(3)`
and B2 gives `||H_D(delta kappa)-H_*||<=delta(b+r_delta)`, B13 follows
with `8sqrt(3)delta(b+r_delta)`. The exact Lipschitz bound in K gives the
slightly smaller `8sqrt(3)delta b`, but the source's stated bound is valid.
No estimate grows with the physical time tau/delta in this step.

For the explicit band preparation, `Gamma_lambda zeta` contains only
singlet and longitudinal triplet components. P preserves this property,
so `F chi_lambda=0`. Since Pzeta=zeta and Gamma is an orthogonal spectral
projection,

    <zeta,chi_lambda> = w_lambda/(sqrt(w_lambda)n_lambda)
                       =sqrt(w_lambda)/n_lambda.

Thus `Pi chi_lambda=A_lambda zeta` exactly. The inherited positive-energy
density formula also makes beta_lambda real and positive; the displayed
`n_lambda=sqrt(1-beta_lambda^2)` is consistent with that phase convention.

The density bound and the interval length give
`w_lambda>=lambda/(8pi^2 I0)>=lambda/(9pi^2)` already for the stated
`0<lambda<=1/16`. Since `n_lambda<=1`, this also bounds A_lambda^2 below.
The upper bound `A_lambda<=1` follows from the projection of the unit
physical vector. The density expansion gives the stated relative
O(lambda^2) asymptotic; the normalization correction from beta_lambda^2
is O(lambda^3). There is no substitution of a finite-fixture spectral
weight for this continuum density estimate.

For kappa0=(1,1,1), proper cyclic rotation fixes the band preparation and
the exact compressed Hamiltonian, and permutes the three actual currents.
Their expectations are equal, including at finite delta. Equivalently the
same covariance holds for the L_a. Combining B10 and B12 with
`F chi_lambda=0`, the transverse energy tends to
`A_lambda^2 ||epsilon u(tau)||^2`. The other trace term changes by o(1)
by B13. Finally `J_a(delta kappa0)/delta=L_a+O(delta^2)` proves B16.
This is an actual canonical-current limit; the derivation does not use an
unbounded energy dipole on zeta or neglect unknown individual cross terms.

At tau0=1/20 the previously checked dressing response gives B17's
`1/10800`. Therefore for every fixed lambda there is a positive
delta_1(lambda) making the scaled drift at most `-A_lambda^2/21600`
for all smaller positive delta. This existence follows from the limit,
not from the finite control. Both cutoff errors depend on the fixed
band vector and, potentially, on lambda. The source correctly refrains
from claiming a polynomial onset or an interchangeable pair of limits.

## 4. Actual positive-band preparation: B18–B19

On the original support, `epsilon>=5lambda/8` and
`epsilon<=7lambda/8`. A one-body sine vector changes by at most |K|/2
when K is introduced. For `|K|<=lambda/16`, both one-body energies
therefore stay away from zero. The positive-spin projector is well defined.

For completeness, the unit-direction inequality
`|a/|a|-b/|b||<=2|a-b|/|b|` bounds each spin projector's change by
`4|K|/(5lambda)`. The product projector changes by at most
`8|K|/(5lambda)<=2|K|/lambda`. Its action on the original unit vector
differs by the same bound and is nonzero. Normalizing changes the vector
by at most twice that error, giving the first B19 estimate.

The q support remains inside `epsilon<lambda`. Its normalized volume is
at most `lambda^3/3`, by the already checked cone-volume bound. Thus the
contact amplitude of any normalized supported spin field is at most
`lambda^(3/2)/sqrt(3)`. Both physical projection norms are nonzero and
at least 1/2. Normalization after P costs at most another factor four,
giving the second B19 estimate. These estimates respect the antisymmetric
pair sector because the actual ++ projector respects exchange.

The ++ energy changes by at most |K|. The internal interval
`[5lambda/4,7lambda/4]` therefore stays inside `[lambda,2lambda]` with
the stated margin. This establishes actual free-band preparation at K;
it says nothing about subsequent free-band invariance under exclusion.
Sharp spectral endpoints cause no domain problem for the bounded
Hamiltonians and current extension used in this proof.

## 5. Finite-delta sign transfer and every numerical margin

From the exact current formula,

    ||J_a(delta kappa)/delta||
      <=(1+sqrt(3))|kappa_a| <=1.1(1+sqrt(3))<4

on the specified 0.1 ball. For the difference from its center, the free
term costs at most `|kappa-kappa0|`. Pairing the change in h'_a with h
costs at most `sqrt(3)|kappa-kappa0|`; pairing h'_a at the center with
the change in h costs at most `delta|kappa-kappa0|/2`. These give the
source's sharper bound in B20, less than four for delta<=1. Independently,
the global derivative bound
`||D J_a(K)[v]||<=(1+sqrt(3))|v_a|+|v|<=4|v|` confirms it.

The exact Hamiltonian is Lipschitz in K with constant one. Dividing by
delta and applying bounded Duhamel gives the last B20 bound. Comparing
the two drift endpoints at a fixed initial chi_lambda then costs at most

    (8+8tau0)|kappa-kappa0|=8.4|kappa-kappa0|
      <9|kappa-kappa0|.

Since `|kappa|<2`, the preparation change is at most `32delta/lambda`.
Each current expectation is 2||J_a/delta||-Lipschitz on the unit sphere.
Both drift endpoints together thus cost at most
`16*(32delta/lambda)=512delta/lambda`. There is no missing endpoint or
normalization factor.

The source's choices give exactly

    9rho_lambda = A_lambda^2/86400,
    512[A_lambda^2 lambda/44236800]/lambda
      = A_lambda^2/86400,
    -A_lambda^2/21600 + 2A_lambda^2/86400
      = -A_lambda^2/43200.

Also `A_lambda<=1` ensures `rho_lambda<1/10`, and
`delta<=lambda/32` ensures `|K|<2delta<=lambda/16` throughout the
envelope. The min defining delta_0 is positive for each fixed lambda.
The strict inequality `delta<delta_0` preserves the eventual base bound.
This proves B22 for every fiber in the whole ball and each component.
No off-diagonal-kappa componentwise limiting formula is needed.

## 6. Single global normalization and theorem scope

With normalized measures, the Jacobian `dK=delta^3 dkappa` cancels the
squared amplitude `delta^-3`. The actual free packet has norm one because
each phi_(lambda,K) is normalized. Its positive-band property holds
fiberwise and hence globally. The K support lies inside the chart and
away from K=0 for the stated parameter range. A nonzero L2 envelope on
the indicated ball gives ordinary three-dimensional momentum support.

After applying P once and normalizing globally, the physical fiber weights
are exactly

    |f_lambda(kappa)|^2 n_(lambda,delta kappa)^2/N_(lambda,delta)^2.

They are positive, integrate to one, and need not equal |f_lambda|^2.
They are time independent because the Hamiltonian is decomposable in K.
The bounded canonical current is also decomposable; its derivation already
cancelled K derivatives. Thus the common signed B22 estimate integrates
without an additional weight or regularity error. Substituting B15 yields
the constant `1/(388800pi^2)` in B24.

The construction first fixes lambda and then chooses delta below its
individual threshold. Lambda can subsequently be selected arbitrarily
small, with a fresh suitable delta. It does not supply K comparable to
lambda, a simultaneous polynomial scale, monotonicity, a generic-initial
state claim, or a many-body transport rate. The physical time is finite
for each chosen delta and can lie well beyond the previous fixed-time
estimates. There is no contradiction with those earlier finite-time
bounds. The present source does not state a uniform-all-time no-go
corollary; such a separately worded claim would require its own exact
quantifier and scope check.

## 7. Independent finite evidence and formalization limits

Independent artifacts are in `excluded_walk_band_current_review/`,
separate from all author evidence and previous review packets:

- `independent_band_current_controls.py`;
- its complete `.log` and `independent_execution.json`;
- `independent_review_receipt.json`, binding the final report and inputs.

The new helper uses two cyclic rational sine/cosine orbits, with unequal
radii 1 and 4/5, and implicit antipodes. It reconstructs a 24-dimensional
singlet/triplet matrix and its physical compression, the full trace, and
BQ=FBQ for a non-diagonal kappa. It checks the exact complement residual with a finite
reduced inverse, which is explicitly only a test of the cutoff algebra.
The continuum proof cannot replace its cutoff inverse with this finite
matrix inverse.

A literal free positive spectral projection selects one orbit. The exact
fixture has `I0=41/128`, `w=25/82`, `beta=1/2`, and dressing weight
`50/123`. These are fixture values, not continuum integral evaluations.
Actual compressed Hamiltonian exponentials, the full bounded current,
and freshly projected actual ++ initial states are evaluated at four
delta values. The predicted scaled drift is `-0.01112882106187463`;
at delta=0.0005 the actual positive-band-prepared drift is approximately
`-0.011128726204803`. The mixed-state comparison, exact energy
conservation, and equal cyclic current components are also checked.
These computations would expose deleting the F term or losing the
dressing contribution; they do not prove a continuum limit or its rate.

The helper also checks the packet error arithmetic exactly. It imports no
author code and uses no continuum quadrature. Its first execution exited
zero in 1.035293 seconds under a 120-second timeout. Python was 3.13.5,
SymPy 1.14.0, NumPy 2.4.4, and SciPy 1.17.1. The full output was read;
no failure or tolerance change was suppressed.

The author's separately prepared control packet was not an input to this
review and has not been reviewed or certified here. The evidence above is
the new independent computation and the analytical reconstruction of the
frozen 327-line theorem source.

No Lean or other proof-assistant certification was performed. Formal
obligations would include the Q mapping on the physical Hilbert space,
the complementary spectral-cutoff estimate, full trace with its contact
compression, current/energy limits, spin-projector preparation estimates,
and decomposable global normalization. Exact finite algebra alone cannot
discharge these analytic obligations.

Only this new review and its separate evidence directory were written.
Previous reports and receipts, author sources, repository files, audit
state, and editable prompt files remain unchanged. No commit, PR, network
operation, or external message was performed.
