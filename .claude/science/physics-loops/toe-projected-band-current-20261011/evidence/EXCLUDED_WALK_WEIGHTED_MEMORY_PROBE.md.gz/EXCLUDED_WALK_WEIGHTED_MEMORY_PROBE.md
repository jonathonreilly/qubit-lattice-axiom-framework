---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: partially_closes
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Positive asymptotic weighted transfer and the effective canonical current

2026-10-11. External conditional extension for the supplied excluded Weyl walk.

The dressing preparation has an outgoing transverse scattering state of
norm one. Its epsilon-weighted norm is strictly positive and is the limit
of the actual effective weighted transfer. Consequently the effective
canonical current has a limit with a nonzero signed change in every
component for which kappa_a is nonzero. This is a positive weighted
transfer and a signed current deficit; the final current itself is not
proved positive.

The extra mathematical input is Kato's trace-class wave-operator theorem,
with its precise fixed-space hypotheses checked below. No Markov or
decoherence premise is introduced. There is no scattering rate, no
interchange of the small-parameter and long-time limits, and no result
for arbitrary free-band preparation.

## 1. Frozen sources and exact primary import

S denotes `/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.
All new outputs are this note and `weighted_memory/` within S.

| Source | SHA-256; coverage |
|---|---|
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c`; previous complete 500-line reading reused after identity check, especially E2–E3 and E13–E24 |
| `effective_memory/receipt.json` | `99cad79eeb712071bfc48a04a161df7280cea694f80523dc86c563537f272557`; all recorded output identities rechecked |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0`; complete 329-line independent review read; no consequential defect found in the parent memory argument |
| `excluded_walk_memory_review/independent_review_receipt.json` | `5a73e562741e0e10e84101206a0c98d2f3daf4d534898260d14fe85a1f101fe6`; source/review and recorded artifact identities rechecked |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`; complete earlier 549-line reading reused, especially D6–D8 and D12–D20 |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2`; complete earlier 375-line reading reused |
| `excluded_walk_review/kato_1957_primary.pdf` | `12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`; all five extracted pages read; original embedded page images for pp.260 and 263 inspected visually |

The primary theorem is Theorem 1, p.260, in Tosio Kato, *Perturbation of
Continuous Spectra by Trace Class Operators*, Proceedings of the Japan
Academy 33 (1957), 260–264, [official PDF](https://www.jstage.jst.go.jp/article/pjab1945/33/5/33_5_260/_pdf).
Its proof of completeness is in Section 3, p.263. The locally archived
source was sufficient; no new network lookup was used.

Kato takes a self-adjoint H0 and a bounded self-adjoint trace-class V on
one Hilbert space, and sets H1=H0+V. If P0 and P1 are their absolutely
continuous projections, his equations (1.1)–(1.2) assert

    Omega_+/- = s-lim_(t->+/-infinity) exp(itH1)exp(-itH0)P0,
    Omega_+/-^* = s-lim_(t->+/-infinity) exp(itH0)exp(-itH1)P1,
    Omega_+/-^* Omega_+/-=P0,
    Omega_+/- Omega_+/-^*=P1.                               (W1)

In particular the final subspace is the entire absolutely continuous
subspace of H1. The theorem does not require either operator to be wholly
absolutely continuous, or absence of other bound states. The source's
adjoint stars and both signs were checked on the page image: extracted
text drops some stars and misreads the year in the heading. The proof's
use of both forward and reverse limits was also checked against p.263.
This is an imported mathematical theorem, not a new proof of Kato's result.

The supplied walk, physical pair space, contact exclusion, coordinates,
clock, and specified canonical energy placement remain exactly those of
the frozen parent notes. No physical primitive or Record interpretation is
adopted. The parent's independent review does not review this new extension.

## 2. The same Hilbert space and the trace-class perturbation

Use normalized relative-torus measure `dmu=dq/(2pi)^3` and inner products
linear in the second slot. Set `s_j=sin q_j`, `epsilon=|s|`,
`n=s/epsilon` almost everywhere, and use the normalized dressing vector

    zeta=n/(2epsilon sqrt(I0)),  I0=integral 1/(4epsilon^2).

The fixed physical zero space is `Z=F direct-sum C`, with zeta represented
by `(0,1)` and F the odd transverse L2 triplet fields. The auxiliary
constant singlet is not part of this space. Fix `kappa!=0` and `b=|kappa|`.
The parent supplies

    d_j=kappa_j cos q_j,  f=d·n,
    D u=i f n cross u,
    g=i(d cross n)/(2epsilon sqrt(I0)),
    A=[ D       g ],      A0=[ D       0 ].
      [ <g|     0 ]          [ 0       0 ]                 (W2)

D and A are bounded self-adjoint operators, and `g in F`. All domains
are the full indicated Hilbert spaces. In particular A and A0 act on the
same Z, rather than on different constrained and unconstrained spaces.

Let `gamma=(g,0)` and keep zeta for `(0,1)`. Then

    V=A-A0=|gamma><zeta|+|zeta><gamma|,
    <gamma,zeta>=0,
    ||V||=||g||,       ||V||_1=2||g||.                    (W3)

For a direct trace-norm check, on the orthonormal pair
`gamma/||g||,zeta`, V is `[[0,||g||],[||g||,0]]`; it is zero on the
orthogonal complement. Its only nonzero eigenvalues are `+/-||g||`.
The parent proves `||g||>0` when kappa is nonzero. Thus V has rank two,
is self-adjoint and belongs to the trace class. This matches every
operator and domain hypothesis of W1, with `H0=A0`, `H1=A`.

The scalar zero block of A0 is a pure eigenvalue, so

    P0=P_ac(A0)=P_ac(D) direct-sum 0.                      (W4)

It is not necessary to prove `P_ac(D)=I_F`. Any singular or point subspace
of D is automatically excluded by P0, and Kato's completeness identifies
the part actually needed. The memory theorem establishes the stronger
spectral fact `dnu_zeta=rho(E)dE` for A, hence

    P1 zeta=P_ac(A)zeta=zeta.                             (W5)

W5 uses the full absolute-continuity result E23, not just the scalar
survival-amplitude limit. Its endpoint step was already proved there by
strict pointwise compression, so no possible endpoint atom of the dressing
measure is omitted. Kato itself demands no separate endpoint regularity
or density bound. Other spectral vectors of A are not classified here.

## 3. Unit-norm outgoing datum and weighted limit

For positive time, define

    (u_+,0)=Omega_+^* zeta.                               (W6)

W1, W4 and W5 give `u_+ in ran P_ac(D)` and
`||u_+||^2=<zeta,P1 zeta>=1`. The reverse limit in W1 reads

    exp(itA0)exp(-itA)zeta ->(u_+,0).

Multiplication by the time-dependent unitary `exp(-itA0)` preserves the
norm of the difference, and therefore proves

    r_+(t):=||exp(-itA)zeta-(exp(-itD)u_+,0)|| ->0.
                                                                  (W7)

This implication uses the adjoint wave operator, with the same positive
time sign. Using `Omega_+ zeta` instead would be wrong: zeta is in the
scalar point subspace of A0 and P0 zeta=0. The free outgoing datum lies
in F, not in the scalar channel.

Write `exp(-itA)zeta=(u(t),a(t))`. Every bounded scalar multiplication
operator m(q) preserves F when m is even, and it commutes with D pointwise.
For such a real m, put `Q_m=diag(M_m,0)` on Z. W7 gives

    |<exp(-itA)zeta,Q_m exp(-itA)zeta>
                         -integral m(q)|u_+(q)|^2 dmu|
                    <=2||m||_infinity r_+(t).             (W8)

The right comparison vector in W7 has norm one; the ordinary two-vector
quadratic-form estimate proves the displayed factor. Its expectation is
constant because Q_m commutes with A0. This is the exact point where
strong scattering and the conserved comparison observable are used.

Apply W8 to `m=epsilon^2`, for which `0<=m<=3` and the zero set consists
of finitely many cone points. Since `||u_+||=1`,

    W(t):=||epsilon u(t)||^2 -> W_+:=||epsilon u_+||^2,
    0<W_+<3,
    |W(t)-W_+|<=6r_+(t).                                  (W9)

The lower inequality follows because epsilon is positive almost everywhere
and u_+ is a nonzero L2 vector. The upper inequality is also strict:
`epsilon^2=3` only on a null set. These are strict inequalities for the
actual outgoing datum; they are not a computed numerical lower bound.
The multiplication weight has no positive uniform lower bound near a cone.

The same reasoning works for negative times with `u_-=Omega_-^*zeta`.
Each sign has its own unit-norm datum. The conclusions below use the
positive-time convention only; no equality of the two data is assumed.

## 4. The actual canonical-current consequence

The checked parent current compression is

    calJ_a=[ m_a I_F       r_a ],
           [ <r_a|          1  ],
    m_a=cos(2q_a),
    r_a=s_a(e_a-n_a n)/(2sqrt(I0)),
    ||calJ_a||<=1+sqrt(3).                                 (W10)

It comes from the named compressed local energy placement; it is not
defined by differentiating A with respect to kappa. W7 and boundedness
show that its expectation has the same limit as on `(exp(-itD)u_+,0)`.
Both off-diagonal terms have zero expectation on that comparison vector.
The scalar multiplier m_a commutes with D, so

    <exp(-itA)zeta,calJ_a exp(-itA)zeta>
        -> j_(a,+):=integral cos(2q_a)|u_+(q)|^2 dmu
         =1-2W_(a,+),
    W_(a,+):=||sin(q_a)u_+||^2,
    0<W_(a,+)<1,        sum_a W_(a,+)=W_+.                 (W11)

The strict bounds hold for every coordinate a: each zero set of sin q_a
and each set where `sin^2 q_a=1` has three-dimensional measure zero.
Thus `-1<j_(a,+)<1` and the coefficient changes strictly from its initial
value 1. Quantitatively the comparison error is at most
`2(1+sqrt(3))r_+(t)`. No decay rate for r_+ is supplied by W1.

For diagonal `kappa=k(1,1,1)`, k nonzero, the parent's proper cyclic
symmetry makes the three expectations equal at every time. Hence their
limits obey `W_(a,+)=W_+/3`, and

    j_(a,+)=1-(2/3)W_+,      a=1,2,3.                     (W12)

This establishes a persistent, nonzero limiting deficit. It does not fix
whether the final coefficient is above or below zero: W9 alone permits
either sign. In particular the word positive in this note describes the
weighted transfer W_+, not a universal direction or positivity of current.

## 5. The order of limits for the original walk

Let `U_lambda(t)=exp[-it H_D(lambda kappa)/lambda]`. The parent's fixed-vector
strong limit and current expansion give, for every fixed compact t interval,

    <U_lambda(t)zeta,J_a(lambda kappa)U_lambda(t)zeta>/lambda
          ->kappa_a <exp(-itA)zeta,calJ_a exp(-itA)zeta>.

Combining this with W11 proves exactly the ordered limit

    lim_(t->infinity) lim_(lambda->0)
      <U_lambda(t)zeta,J_a(lambda kappa)U_lambda(t)zeta>/lambda
                      =kappa_a[1-2W_(a,+)].              (W13)

The initial scaled current tends to kappa_a. The corresponding ordered
limit of its change is therefore

    Delta_(a,+)=-2kappa_a W_(a,+).                         (W14)

It is nonzero, with sign opposite to kappa_a, whenever kappa_a is nonzero.
If kappa_a=0 the actual a-th current is identically zero, as in the parent.
For diagonal kappa, W14 becomes `-(2k/3)W_+`.

The separation of errors is explicit. Put
`E_lambda(t)=||U_lambda(t)zeta-exp(-itA)zeta||` and use the parent's

    C_a(kappa)=(1/6+sqrt(3)/24)|kappa_a|^3+|kappa_a|b^2/8.

Then the absolute difference between the finite-lambda expression in W13
and its limiting right side is at most

    lambda^2 C_a(kappa)
      +2|kappa_a|(1+sqrt(3))[E_lambda(t)+r_+(t)].           (W15)

The two errors vanish in different proved regimes: E_lambda on fixed
compact t intervals as lambda tends to zero, and r_+ as t tends to infinity
at fixed kappa. No joint schedule, finite-lambda onset, rate, or reversed
order is justified here. The physical walk time is t/lambda. There is no
assertion of global trace class after a total-momentum direct integral.
These conclusions are for the stated fixed-total-momentum fiber; a new
normalizable envelope statement is not included in this extension.

When kappa=0, the effective dressing remains a zero eigenvector. W5 fails,
and this scattering preparation argument is inapplicable. That case is
excluded explicitly rather than forced into W9 or W14.

## 6. Independent-form controls and limits of those controls

The literal helpers under `weighted_memory/` do not import prior runners.
An exact complex-vector matrix checks W3's rank-two spectrum and trace
norm. A separate solvable continuous model checks the outgoing convention
and passage from strong comparison to a positive weighted limit.

In that control, take `F_toy=L2([-1,1],dx/2)`, `D_toy=x`, the normalized
constant f0=1, and an extra scalar vector zeta0. Let U swap f0 and zeta0
and fix their orthogonal complement, and set
`A_toy=U(D_toy direct-sum 0)U*`. With h0=x one computes

    A_toy-A_(0,toy)
      =|h0><zeta0-f0|+|zeta0-f0><h0|,
    exp(-itA_toy)zeta0=(exp(-itx)-a0(t),a0(t)),
    a0(t)=sin(t)/t,
    ||exp(-itA_toy)zeta0-(exp(-itx),0)||=sqrt(2)|a0(t)|.
                                                                  (W16)

These formulas follow directly from U; the asymptotic conclusion does
not invoke Kato in this check. The free datum is f0 with norm one.
For the positive weight x^2, exact integration gives

    integral x^2|exp(-itx)-a0(t)|^2 dx/2
       =1/3+a0(t)^2/3+2a0(t)a0''(t) ->1/3.                (W17)

Symbolic integrations, the continuous norm identity, and separate numerical
quadrature check these formulas. This is an independently designed toy
control, not a numerical solution of the continuum walk or a proof of
Kato's theorem. The finite-dimensional matrix tests do not assert existence
of finite-grid scattering limits. The frozen finite-bath recurrence example
continues to apply to such an unsupported extrapolation.

The new analytic claim rests on W1–W15 and the exact source chain. All 17
new controls passed; four actual source-copy mutations failed at their
intended assertions: halving the trace norm, reversing the wave-operator
adjoint, changing the weighted cross-term sign, and removing the normalized
measure factor. These are author checks, not independent review. Full
logs and literal old/new source changes are preserved, including the
separate floating quadrature errors (maximum about 2.51e-14).
The first PDF extraction attempt lacked pymupdf; local pypdf succeeded.
Its OCR warnings and the original page images are retained. No package
installation or global tool change was needed.

The run used Python 3.13.5, SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1.
Inputs are literal in `weighted_memory/weighted_controls.py`; the runner
`weighted_memory/run_controls.py` records commands and a 120-second timeout
per execution. The final receipt binds the note, helpers, actual executions,
source-copy mutants, primary-source evidence and preserved parent identities.
Reproductions should use fresh log paths to preserve this packet's evidence.

## 7. Remaining obligations and status

The bounded extension closes the asymptotic weighted-transfer and effective
canonical-current limit for the dressing preparation, conditional on the
frozen memory theorem and the verified primary import. The remaining
questions are quantitative and preparational:

1. Bound r_+(t), or otherwise control a joint weak-momentum/long-time regime.
2. Evaluate or rigorously bound the actual W_(a,+) beyond strict positivity.
3. Match arbitrary lambda-dependent projected positive-band preparations
   to these scattering data, including dispersive and current cross terms.
4. Review the new complete source argument independently before downstream
   reuse as a checked theorem. No new Lean certification is claimed.

The route would have remained incomplete without W5: completeness of the
wave operators does not put an arbitrary vector in ac(A). Keeping only
existence of a forward wave operator would also omit the onto-ac statement
needed for the norm-one outgoing datum. Both premises are explicitly
present here. Positivity almost everywhere supplies a strict weight for
that datum, but no numerical coercivity constant. No universal relaxation
law or broad impossibility statement is proposed.

Only this new note and `weighted_memory/` were written. Recorded frozen
source and Lean-packet identities were rechecked. This task made no edits
to repository files, editable prompts or global configuration, and no
commits, PRs or audit-state changes. The current research-lane
instructions are reused at the same verified identities. The next gate is
source-bound independent examination; no retained-status decision is made.
