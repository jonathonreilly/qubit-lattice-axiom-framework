# Independent review of the weighted-memory extension

2026-10-11. Source-bound mathematical review, not an audit verdict or a
retained-status decision. The selected model and reasoning were preserved.

**Outcome:** no consequential defect found in W1–W17 of the frozen
339-line `EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md` at SHA-256
`10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324`.
The extension establishes a normalized outgoing transverse datum, strictly
positive asymptotic weighted transfer, and each stated effective-current
limit, conditional on the identified supplied walk and the dressing
absolute-continuity theorem E23. The original-walk consequence is the
ordered limit stated in W13–W15. No rate, joint scale, or new global packet
theorem is established by this review.

No author or repository source needed a correction. No repository file,
prior frozen review, prior receipt, editable prompt, or platform instruction
was modified. All new writes are this report and the external directory
`excluded_walk_weighted_review/`.

## 1. Exact sources, coverage, and independence

Here S is
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Source relative to S | SHA-256 | Coverage |
|---|---|---|
| `EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md` | `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324` | All 339 lines, including every new argument W1–W17 and the scope/footer |
| `weighted_memory/receipt.json` | `a9a25c7df59b6efe058b4496038a8232e39baba04826290c6f1ffa8f32cbf8ca` | Every non-inventory field inspected; all explicit path/hash records checked mechanically |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Prior complete 500-line reading and independent reconstruction reused at identical bytes; E23 is the essential spectral premise |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | Prior complete independent review reused, without changing its scope |
| `excluded_walk_memory_review/independent_review_receipt.json` | `5a73e562741e0e10e84101206a0c98d2f3daf4d534898260d14fe85a1f101fe6` | Prior source/evidence identities preserved |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Prior complete 549-line reading reused; fixed zero space, D6–D8, current D12–D18, cyclic symmetry and coupling refreshed as needed |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md` | `c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2` | Prior independent proof and limitations reused at unchanged bytes |
| `excluded_walk_degenerate_review/independent_review_receipt.json` | `c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa` | Prior source/evidence identities preserved |
| `excluded_walk_review/kato_1957_primary.pdf` | `12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5` | All five pages' newly extracted text read; original whole-page images of printed pp.260 and 263 visually inspected |

Before reading the new argument, I recorded the reconstruction in
[`PRE_FREEZE_RECONSTRUCTION.md`](excluded_walk_weighted_review/PRE_FREEZE_RECONSTRUCTION.md),
SHA `42648b16c2cb46d544c1cd1130446e0efa7813bece3c8773336fbc3923647eff`.
Its frozen receipt is
[`pre_source_receipt.json`](excluded_walk_weighted_review/pre_source_receipt.json),
SHA `da6a9f1585b09c9cdf61e8734ed25297e281baaf8b946170ca2b46dd68e77e16`.
The author freeze arrived after the reconstruction file had been written.
These files remain unchanged.

There was limited incidental exposure before that reconstruction: a broad
local Kato lookup printed four matching lines from the then-unfrozen draft.
They named the theorem, described primary-PDF coverage, began the H0/V
hypotheses, and warned that wave operators do not put arbitrary vectors in
ac(A). No draft equation or proof was read before recording the derivation.
This was disclosed at the time and in the preserved reconstruction; the
review is not described as completely blind to every draft byte.

The independent substance is the reconstruction from the frozen parent
operators and the original Kato theorem, including the L1-density route in
Section 3 below. New controls use separate necessity counterexamples and
the full two-helicity transverse fiber, with no author helper imported.
The author baseline and mutations were examined as author evidence, not
replayed or relabeled independent evidence.

The source-identity check verified 197 explicit path/hash occurrences,
representing 181 distinct files in the author receipt, including its
historical records. This is identity coverage, not a new substantive review
of every historical file. The one pathless historical Git-blob identity
for `origin/ai/execution:AGENTS.md` was not independently retrieved in this
check; it is not a mathematical premise. The complete result is
[`source_identity_check.json`](excluded_walk_weighted_review/source_identity_check.json).

## 2. The primary theorem and the normalized outgoing state

The imported result is Theorem 1, printed p.260, in Tosio Kato,
*Perturbation of Continuous Spectra by Trace Class Operators*,
Proc. Japan Acad. 33 (1957), 260–264. Its completeness and adjoint argument
is on p.263. The [archived original PDF](excluded_walk_review/kato_1957_primary.pdf)
was sufficient; no new network request was made. This review does not
reprove the general trace-class theorem or use Theorem 2's continuity claim.

On one Hilbert space, Kato takes self-adjoint H0 and bounded self-adjoint
trace-class V, with H1=H0+V. For Pj=P_ac(Hj), his theorem gives

    Omega_+ = s-lim_(t->+infinity) exp(itH1)exp(-itH0)P0,
    Omega_+^* = s-lim_(t->+infinity) exp(itH0)exp(-itH1)P1,
    Omega_+^* Omega_+=P0,   Omega_+ Omega_+^*=P1.

The negative-time limits also hold. The original page images resolve
adjoint stars that the extracted text loses; they also establish the
publication year 1957, which extraction misreads in one heading.
The reverse strong limit and the onto-ac statement are actual parts of
the primary theorem, not conclusions inferred from an isometric embedding
alone.

For each fixed nonzero kappa, the supplied physical zero space is
Z=F direct-sum C, with dressing zeta=(0,1). On that same space,

    A0=D direct-sum 0,
    A=[[D,g],[<g|,0]],
    V=|gamma><zeta|+|zeta><gamma|,   gamma=(g,0).

The scalar channel is the physical normalized dressing, not the auxiliary
constant singlet excluded from the physical space. D and A are bounded
self-adjoint on all Z. The previously checked g belongs to F and is
nonzero for nonzero kappa. Since gamma is orthogonal to zeta, V has
eigenvalues +||g|| and -||g|| on their span and vanishes on its orthogonal
complement. Consequently rank V=2 and ||V||_1=2||g||. The same-space,
self-adjointness, boundedness, and trace-class hypotheses all match.

The absolutely continuous subspace of A0 is
H_ac(D) direct-sum {0}; its scalar zero eigenvector is absent. No claim
that all of F is H_ac(D) is necessary. Separately, the memory theorem E23
establishes the full absolute continuity of the dressing spectral measure
for A. That implies P1 zeta=zeta. Merely knowing a(t)->0 would not justify
this step, and rank two by itself would not justify it either.

Completeness therefore gives the unique vector

    Phi_+=Omega_+^* zeta=(u_+,0),
    u_+ in H_ac(D),   ||u_+||=1,
    r_+(t):=||exp(-itA)zeta-(exp(-itD)u_+,0)|| ->0.

The norm identity follows from Omega_+ Omega_+^*=P1. The last assertion
follows by multiplying Kato's reverse-limit difference by exp(-itA0), a
unitary which preserves that difference's norm for each t. Conversely,
applying the forward Omega_+ to zeta gives zero because P0 zeta=0. W6–W7
use the correct adjoint, source channel, and positive-time sign.

The same argument produces a separate u_- at negative time. No identity
between u_+ and u_- or a scattering rate is needed or asserted.

## 3. Weighted convergence: a separate density reconstruction

Write exp(-itA)zeta=(u(t),a(t)). For almost every q the free generator is
the Hermitian two-dimensional transverse operator i f(q)n(q) cross.
Thus its exponential is pointwise unitary on the entire transverse plane,
not just on a selected helicity. In particular

    |exp(-itD(q))u_+(q)|=|u_+(q)|.

Cauchy–Schwarz and the difference-of-squares inequality give the stronger
probability-density conclusion

    || |u(t)|^2-|u_+|^2 ||_L1
      <= (||u(t)||+||u_+||)
                   ||u(t)-exp(-itD)u_+||
      <=2r_+(t).

This route independently yields W8 for every bounded q weight in the
quadratic-form sense. The note instead uses a bounded even real
multiplier preserving the odd transverse space, which is sufficient for
all its stated weights. Evenness preserves odd parity; scalar
multiplication commutes with D pointwise. The comparison expectation is
therefore constant. The factor 2 in W8 is valid since both full states
being compared have norm one.

For epsilon^2=sum_a sin^2(q_a), 0<=epsilon^2<=3. Applying the inequality
above gives exactly

    W(t)->W_+=integral epsilon^2|u_+|^2,
    |W(t)-W_+|<=6r_+(t).

The zero set of epsilon is finite, and the equality set epsilon^2=3 is
also null. A normalized L2 field cannot be supported on either set, so
0<W_+<3. This is a strict statement for the actual outgoing vector; it
does not provide a numerical coercivity constant near a cone.

For each coordinate set W_a=integral sin^2(q_a)|u_+|^2. The sets
sin(q_a)=0 and sin^2(q_a)=1 are null planes. Hence 0<W_a<1 for every a,
and sum_a W_a=W_+. This does not require every component of kappa to be
nonzero. The nonzero-current conclusion additionally requires kappa_a!=0.

The bounded-current comparison is also correct. The exact parent
compression retains both the dressing diagonal and its cross terms:

    calJ_a=[[cos(2q_a) I_F,r_a],[<r_a|,1]],
    ||calJ_a||<=1+sqrt(3).

Its expectation on the free comparison vector is
integral cos(2q_a)|u_+|^2=1-2W_a. Only that vector's scalar coordinate is
zero; the cross terms have not been deleted from the current operator.
The two-vector bound gives the stated error
2(1+sqrt(3))r_+(t). It follows that -1<j_(a,+)<1 and the coefficient
changes strictly from its initial value 1. No sign of the final current
itself is determined. For diagonal kappa, the independently checked proper
cyclic symmetry makes W_a=W_+/3, as W12 states.

## 4. Original current, constants, and exact limit order

The original-walk statement uses the existing fixed-vector weak-momentum
limit with the same zeta and physical zero-space embedding. It uses the
specified bounded canonical current J_a, not the derivative of A with
respect to kappa or an unbounded dipole applied to the singular dressing.

The refreshed parent D14 is

    ||J_a(lambda kappa)/lambda-kappa_a L_a||<=lambda^2 C_a,
    C_a=(1/6+sqrt(3)/24)|kappa_a|^3+|kappa_a||kappa|^2/8,
    ||L_a||<=1+sqrt(3).

First compare the finite-lambda current operator with kappa_a L_a,
then the exact state with exp(-itA)zeta, then the effective state with
its free scattering profile. For normalized states, each latter
comparison costs twice the operator norm times the state difference.
This reconstructs W15 without an omitted factor:

    error <=lambda^2 C_a
      +2|kappa_a|(1+sqrt(3))[E_lambda(t)+r_+(t)].

E_lambda(t) tends to zero on each fixed compact effective-time interval;
r_+(t) tends to zero at fixed kappa for large effective time. Thus the
justified order is first lambda->0, then t->+infinity. Subtracting the
initial scaled current, whose limit is kappa_a, gives

    lim_(t->infinity) lim_(lambda->0) scaled current change
      =-2 kappa_a W_a.

This is strictly opposite in sign to kappa_a for a nonzero component.
If kappa_a=0 the original component current is exactly zero, including
its contact contribution; no division by kappa_a occurs. The case
kappa=0 is excluded because zeta is then a point eigenvector, and the
normalization argument through ac(A) fails.

The physical walk time is t/lambda. W15 does not permit an unspecified
t=t(lambda) or reversal of the limits. The theorem is for a fixed
total-momentum fiber and the fixed dressing preparation. It does not
prove trace class after a non-atomic direct integral over kappa, does
not add a normalizable K envelope, and does not match arbitrary
lambda-dependent positive-free-band preparations. The root's separate
joint-scale analysis was not a premise of this review.

## 5. Decisive checks and limits of computational evidence

The new independent helper is
[`independent_weighted_controls.py`](excluded_walk_weighted_review/independent_weighted_controls.py),
SHA `77878741814c03b127cd88eb6c65a315eea00ec7a8243bef7a0410de5d0b6b53`.
Its [complete log](excluded_walk_weighted_review/independent_weighted_controls.log)
has SHA `47a88fc3e3b73bbf7d183cc20f3eaefa23df8efe65fd620a581871a6d3a504ec`.
It completed on its first run, exit 0, in about 0.45 seconds including
startup, using Python 3.13.5 and SymPy 1.14.0 with a 60-second timeout.
All 11 literal checks were inspected. Their substantive content is:

1. A continuous multiplication spectator plus a two-state point block
   has the exact same off-diagonal rank-two perturbation structure.
   Its dressing survival is cos(t), with exact recurrence. Kato remains
   valid, but the dressing lies outside ac(A). This is a counterexample
   to dropping W5, not to the note which proves W5 from E23.
2. On L2([-1,1],dx/2;C^2), A=A0=x I+sigma_x is wholly absolutely
   continuous and has zero scattering error. The scalar x^2 weight has
   constant expectation 1/3, whereas a noncommuting spin projection has
   expectation cos^2(t) and no limit. This independently discriminates
   the commutation step in W8; strong scattering alone is insufficient
   for an arbitrary bounded observable.
3. The exact exponential for D_perp=f sigma_y preserves the full
   transverse two-component norm and solves the Schrödinger equation.
   It checks the pointwise-density premise used above without replacing
   the two helicities by a scalar phase.

These exact auxiliary controls do not numerically prove Kato, E23, or
the continuum walk's long-time limit. There was no finite-grid scattering
fit, imported author code, or additional claim of independent evidence
from the number of successful assertions.

The author's full 106-line helper, 52-line execution driver, complete
baseline log, four actual mutant source differences and their complete
failure tracebacks were read. Their helper hash is
`70807cce821d3e2eca3fc96cefd52fa1cfe83c4496801b9c9f2f7b9dd5108c24`;
baseline-log hash is
`c4dfc5aa6457871d653eb55d3c8d3fc24664cec6cdf479658e364d980554ce5a`.
The mutants do change literal source and fail at the stated trace-norm,
adjoint, weighted-sign and normalized-measure assertions. Their 17 baseline
checks and four rejections remain author evidence. They were not rerun.

I also reconstructed the author's continuous conjugacy model directly:
U swaps the normalized constant f0 with the scalar zeta0, while fixing
their complement. With h0=x and <f0,h0>=0,
U A0 U*-A0=|h0><zeta0-f0|+adjoint. Applying U to the free orbit gives
(exp(-itx)-a0,a0), a0=sin(t)/t. Its norm comparison is sqrt(2)|a0|.
Since integral x^2 cos(tx) dx/2=-a0''(t), the weighted expression is
1/3+a0^2/3+2a0 a0'', with the plus sign in W17 and limit 1/3.
The source correctly presents this as a toy, not the actual walk.

The initial full author-receipt display was truncated; coverage was
completed by inspecting every non-inventory field and verifying every
explicit path/hash record with the saved script. One read-only command
used a nonexistent work-directory path and failed before execution; it
was rerun with the correct directory and complete output. A documentation
patch expected the wrong checkpoint heading and failed atomically; reads
confirmed that no report or development log had been created. These
tooling failures did not change any source or mathematical assertion.
The new independent PDF extraction emitted pypdf encoding warnings;
the primary images resolved the material symbols. The author's separate
unavailable-pymupdf attempt and extraction warnings remain in its original
logs. No tolerance, assertion, source claim, or prior output was changed
to hide a failure.

## 6. Supported reuse and open obligations

The frozen source can be reused for its stated conditional fixed-fiber
weighted-transfer and ordered-current theorem. The explicit dependence
on the supplied physical model, E23 and Kato's complete wave operators
must be retained. The theorem does not need absence of all eigenstates
of A or absolute continuity of the whole free generator D.

Open questions remain exactly where the source places them: rates for
r_+(t), a controlled joint weak-momentum/long-time schedule, quantitative
values or lower bounds for W_a, and a separately justified preparation
or direct-integral extension. They are not gaps in W1–W17's scoped claim.

No new Lean proof was checked or produced. A formalization of this new
extension would need the fixed-space self-adjoint operators, trace-class
rank-two perturbation, the imported complete wave-operator theorem,
the E23 ac membership, pointwise/free-observable invariance, and the
ordered-limit/current estimates. Historical Lean-file identity checks
do not discharge these obligations.

The final [review receipt](excluded_walk_weighted_review/independent_review_receipt.json)
binds this report, the pre-source reconstruction, primary evidence,
new independent controls, complete execution logs and the exact reviewed
source identities. No remote freshness or universal novelty assertion
is made, and no formal audit state is changed.
