from pathlib import Path
import hashlib,json,subprocess,time,shutil
S=Path(__file__).resolve().parent;D=S/'memory_current_primary_mutations';W=S.parent/'walk_worktree';P=W/'scripts/excluded_walk_memory_current_2026_10_11.py'
manifest_path=D/'manifest.json';old=manifest_path.read_bytes();backup=D/'manifest_attempt1.json';assert not backup.exists();backup.write_bytes(old)
shutil.copyfile(S/'run_memory_current_mutations.py',D/'harness_attempt1.py')
m=json.loads(old);r=m['mutations'][-1];assert r['name']=='joint_delta_power' and not r['intended_failure']
log=Path(r['log']).read_text();helper=(S/r['block']).read_text()
assert helper.splitlines()[20].strip()=='assert exact_relaxed<=four_term<=275*leading'
assert 'File "<frozen-author:joint_scale_current/scale_controls.py>", line 21, in <module>\nAssertionError' in log
r['intended_failure']=True;r['failure_location_verified']='The compile/exec virtual file omits assertion source text. Complete traceback names line 21, whose exact frozen source is the stated finite comparison assertion; no replay or mathematical repair.'
m['harness_recovery']={'original_manifest':str(backup),'original_manifest_sha256':hashlib.sha256(old).hexdigest(),'failure':'Expected source text is absent from virtual-source traceback. The process did fail at exactly the intended frozen helper line 21. Full original harness and unfinished record preserved. Only remaining mutation is executed below.'}
original=P.read_text();blockname='joint_scale_current/scale_controls.py';block=(S/blockname).read_text()
oldcode='physical=[w*n/normalization for w,n in zip(weights,survival)]';newcode='physical=[w*n for w,n in zip(weights,survival)]'
assert block.count(oldcode)==1;changed=block.replace(oldcode,newcode)
oldsha=hashlib.sha256(block.encode()).hexdigest();newsha=hashlib.sha256(changed.encode()).hexdigest()
assert original.count(block)==1 and original.count(oldsha)==1
mutated=original.replace(block,changed).replace(oldsha,newsha)
p=D/'mutant_global_normalization_removed.py';assert not p.exists();p.write_text(mutated)
begin=time.monotonic();v=subprocess.run(['/opt/homebrew/opt/python@3.13/bin/python3.13',str(p)],cwd=W,capture_output=True,text=True,timeout=180)
l=D/'mutant_global_normalization_removed.log';l.write_text(v.stdout+v.stderr)
line=next(i+1 for i,t in enumerate(block.splitlines()) if t.startswith('assert sum(physical)==1'))
expected='File "<frozen-author:'+blockname+'>", line '+str(line)+', in <module>\nAssertionError'
row={'block':blockname,'name':'global_normalization_removed','old':oldcode,'new':newcode,'expected':expected,'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'helper_sha256_before':oldsha,'helper_sha256_after':newsha,'log':str(l),'log_sha256':hashlib.sha256(l.read_bytes()).hexdigest(),'exit_code':v.returncode,'elapsed_seconds':time.monotonic()-begin,'timeout_seconds':180,'intended_failure':v.returncode==1 and expected in v.stderr}
m['mutations'].append(row);manifest_path.write_text(json.dumps(m,indent=2)+'\n');assert row['intended_failure'];assert P.read_text()==original
print(json.dumps({'total_actual_mutants':len(m['mutations']),'all_intended_failures':all(r['intended_failure'] for r in m['mutations']),'last_failure_frame':expected,'historical_harness_failure_preserved':True}))
