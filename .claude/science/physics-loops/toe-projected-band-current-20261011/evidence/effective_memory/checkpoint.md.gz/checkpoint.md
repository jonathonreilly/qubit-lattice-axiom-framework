# Effective memory checkpoint

Task: exact scalar memory and spectral consequences for the frozen full-zero-space
generator. Writes remain restricted to the new note and this directory. No agents.

The 549-line parent probe b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876
and 375-line independent review c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2
were read fully. Their block, norm bound, parity and fixed-vector limit are the
supplied starting theorem. No prior source, evidence or Lean file is edited.

Derived: f=d dot n, G=|g|^2, K(t)=integral G cos(tf),
a'=-K*a, M(z)=[z-integral G z/(z^2-f^2)]^-1. The real amplitude gives
P_transverse=1-a^2 and an exact time-integral formula for its spatial weight.

Completed proof route: for b=|kappa|>0, chi=delta/b in (0,1), radius
r0=sqrt(chi)/8, spherical t=(kappa/b) dot omega, a near-cone radial shell
gives bath measure at least c_delta dx on |x|<=b-delta/2, with
c_delta=b chi^(3/2)/(16384 pi^2 I0). The derivative and cross-product
constants have exact algebra and separate numerical-coordinate controls. Poisson lower bounds give
dressing density <=2/(pi c_delta) on |x|<=b-delta. Compression of B excludes
atoms at +/-b by strict pointwise |d|<b almost everywhere. The dressing
measure is entirely absolutely continuous and a(t)->0. This new theorem
awaits independent examination of its complete final argument.

No Markov approximation, irreversible law or weighted-current limit follows.
The source's lambda->0 limit is uniform only on fixed compact rescaled times;
the new t->infinity limit cannot be interchanged with it without a new estimate.

The note also gives an explicit finite-horizon mean-transfer bound in terms
of its resolvent at b+i delta and the cone density constant. It gives no
power-law or exponential pointwise decay rate. The finite one-frequency
recurrence counterexample is retained. Twenty-two selective author controls
passed; six actual source-copy defects failed at intended assertions.

Next: source-bound independent review. Frozen hashes and preserved-source
checks are in receipt.json. Later research may examine a complete scattering
comparison to D direct-sum 0 and the weighted current; that theorem and its
applicability have not been imported or proved in this packet.
