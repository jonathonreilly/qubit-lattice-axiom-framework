# Development evidence

Both new mathematical control baselines exited zero on their first runs.
All six deliberately defective source copies exited one at their intended
assertions. Their full stdout/stderr logs are retained individually.

One atomic prose-edit invocation failed before changing a file because the
patch's expected line accidentally contained a literal leading plus. The
tool response was:

    apply_patch verification failed: Failed to find expected lines in
    EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md:
    +The same interval bound gives the stated
    +local density bound by Lebesgue differentiation. Thus no interior atom

The corrected patch changed the intended paragraph to the direct measure
domination argument. This was a failed text-match operation, not a failed
mathematical check, suppressed compiler error, or tolerance adjustment.
