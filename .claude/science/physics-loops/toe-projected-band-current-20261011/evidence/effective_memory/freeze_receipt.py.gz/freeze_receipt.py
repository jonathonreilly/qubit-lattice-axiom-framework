"""Bind the new proof and checks while verifying the frozen source chain."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

D = Path(__file__).resolve().parent
S = D.parent
W = S.parent/'worktree'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def info(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}


expected = {
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md':
        'b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876',
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md':
        'c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2',
    'excluded_walk_degenerate/receipt.json':
        '369bebc245e0e7794608d6a1ef29a4ccd3d374a85f3f3bcc20f0f2dd81288dde',
    'excluded_walk_degenerate_review/independent_review_receipt.json':
        'c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa',
    'lean_audit/receipt.json':
        '1564b0bf532aca6c7f43c301455163b1af0afb96405e620eb56c481bdf7ed96d',
}
for path, identity in expected.items():
    assert sha(S/path) == identity, path
author = json.loads((S/'excluded_walk_degenerate/receipt.json').read_text())
review = json.loads((S/'excluded_walk_degenerate_review/independent_review_receipt.json').read_text())
lean = json.loads((S/'lean_audit/receipt.json').read_text())
verified = []
for record in author['artifacts']:
    p = S/record['path']
    assert sha(p) == record['sha256'], str(p)
    verified.append(info(p))
for record in author['sources'].values():
    p = Path(record['path'])
    assert sha(p) == record['sha256'], str(p)
    verified.append(info(p))
for record in review['independent_artifacts']:
    p = Path(record['path'])
    assert sha(p) == record['sha256'], str(p)
    verified.append(info(p))
for record in lean['artifacts']:
    p = S/'lean_audit'/record['path']
    assert sha(p) == record['sha256'], str(p)
    verified.append(info(p))
sources = {path: info(S/path) for path in expected}
sources['parent_reading_coverage'] = {
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md': 'all 549 lines, current task',
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md': 'all 375 lines, current task',
    'prior_chain': 'previous complete readings reused after exact identities verified; no prior runner replay',
    'receipts': 'parsed identities, not a claim of new manual reading of every historical receipt field',
}
instruction_files = ['docs/ai_methodology/SCIENCE_WORKFLOW.md',
                     'docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md',
                     'docs/ai_methodology/skills/ai-physics-lane-builder/SKILL.md']
instructions = {}
for path in instruction_files:
    raw = subprocess.check_output(['git', 'show', 'origin/main:'+path], cwd=W)
    assert raw == (W/path).read_bytes(), path
    instructions[path] = hashlib.sha256(raw).hexdigest()
raw = subprocess.check_output(['git', 'show', 'origin/ai/execution:AGENTS.md'], cwd=W)
instructions['origin/ai/execution:AGENTS.md'] = hashlib.sha256(raw).hexdigest()
instructions['worktree:AGENTS.md'] = sha(W/'AGENTS.md')
installed = Path('/Users/jonreilly/.codex/skills/ai-physics-lane-builder/SKILL.md')
assert sha(installed) == instructions['docs/ai_methodology/skills/ai-physics-lane-builder/SKILL.md']
identities = {'direct_sources': sources, 'verified_unchanged_records': verified,
              'instructions': instructions, 'all_matched': True,
              'new_main_source_reading': 'none; exact parent result and independent review are supplied mathematical sources',
              'local_main': subprocess.check_output(['git','rev-parse','origin/main'],cwd=W,text=True).strip(),
              'planning_ref': subprocess.check_output(['git','rev-parse','origin/ai/execution'],cwd=W,text=True).strip(),
              'worktree_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()}
(D/'source_identity_check.json').write_text(json.dumps(identities, indent=2)+'\n')

execution = json.loads((D/'baseline_execution.json').read_text())
mean_execution = json.loads((D/'mean_execution.json').read_text())
assert execution['returncode'] == mean_execution['returncode'] == 0
baseline = [json.loads(line) for line in (D/'baseline.log').read_text().splitlines()]
meanlog = [json.loads(line) for line in (D/'mean_controls.log').read_text().splitlines()]
assert baseline[-1]['checks'] == 19 and meanlog[-1]['checks'] == 3
mutations = json.loads((D/'mutation_manifest.json').read_text())
mutations.append(json.loads((D/'mean_mutation.json').read_text()))
assert len(mutations) == 6
for record in mutations:
    assert record['returncode'] == 1 and record['failed_at_intended_assertion']
    assert sha(D/record['source']) == record['source_sha256']
    assert sha(D/record['log']) == record['log_sha256']
    baseline_name = 'mean_controls.py' if record['name'] == 'mean_factor_two_omission' else 'memory_controls.py'
    source = (D/baseline_name).read_text()
    assert source.count(record['old']) == 1
    assert (D/record['source']).read_text() == source.replace(record['old'],record['new'])
    assert 'AssertionError: '+record['intended_assertion'] in (D/record['log']).read_text()

note = S/'EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md'
artifacts = [info(note)]
artifacts += [info(p) for p in sorted(D.iterdir()) if p.is_file() and p.name != 'receipt.json']
receipt = {
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'task': 'exact effective dressing memory and continuum coherent transfer',
    'scope': 'external bounded conditional theorem candidate; author checks, no audit verdict',
    'note': {**info(note), 'lines': len(note.read_text().splitlines()),
             'coverage': 'complete final source read; all E1-E29 reconstructed while writing and checked in final read'},
    'source_identity_check': info(D/'source_identity_check.json'),
    'direct_sources': sources,
    'protected_records_verified_unchanged': len(verified),
    'lean_packet_unchanged': {'receipt': expected['lean_audit/receipt.json'],
                             'all_small_artifacts_verified': len(lean['artifacts'])},
    'environment': {k: baseline[-1][k] for k in ['python','sympy','numpy','scipy']},
    'executions': [execution, mean_execution],
    'controls': {'counts': [19,3], 'independent_form': 'direct matrix inverses/powers and convolution, separate q gradient/Jacobian, unrelated continuous and atomic measures',
                 'exact_vs_floating': 'symbolic finite algebra and elementary constants exact; numerical matrix/quadrature/geometry controls floating',
                 'all_baseline_and_mutation_logs_read_completely': True,
                 'unmutated_runs': 'both exited zero first time', 'mutations': mutations,
                 'not_independent_review': True, 'not_continuum_numerical_proof': True},
    'strongest_proved_statements': [
        'Exact real Volterra memory, scalar resolvent and Laplace transform for the normalized dressing amplitude.',
        'Exact produced transverse probability and weighted q-distribution formulas; finite-time lower and upper transfer bounds.',
        'For every nonzero kappa, explicit one-cone one-helicity bath lower density on compact interior energies.',
        'Uniform local dressed-resolvent bound implies absence of interior singular dressing measure; strict compression excludes endpoint atoms.',
        'Dressing spectral measure is absolutely continuous, so its amplitude and every time derivative vanish at infinite effective time; transverse probability tends to one.',
        'Finite-horizon mean-transfer bound with explicit resolvent edge term and exact constants.',
        'The original-walk conclusion has lambda-to-zero before effective-time-to-infinity order only.'
    ],
    'preserved_counterexample': 'Finite 3x3 bath with exact return at 2pi multiples and dressing zero-atom 9/25; no generic block-form decay claim.',
    'open_obligations': ['quantitative edge and pointwise decay rates', 'weighted-current asymptotics',
                         'growing-time original-walk comparison', 'arbitrary lambda-dependent free-band preparation',
                         'independent review of complete new analytic proof'],
    'imports': 'bounded spectral theorem and elementary measure/calculus facts; specialized scattering or limiting-absorption theorem not imported',
    'freshness': 'local identified refs only; no remote freshness or global novelty assertion',
    'editable_prompt_files_changed': [],
    'writes': 'only the new named note and effective_memory directory',
    'artifacts': artifacts,
    'receipt_scope': 'All new files except this receipt are hashed; protected parent and Lean artifacts checked; receipt intentionally does not hash itself.'
}
(D/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'note_sha256':sha(note), 'receipt_sha256':sha(D/'receipt.json'),
                  'artifacts':len(artifacts), 'protected_unchanged':len(verified),
                  'controls':22, 'actual_mutants':len(mutations)}))
