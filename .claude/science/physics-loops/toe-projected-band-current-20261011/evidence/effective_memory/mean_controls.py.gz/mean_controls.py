"""Independent continuous-measure controls for the finite-horizon inequalities."""
import json
import numpy as np
import sympy as sp
from scipy.integrate import quad
from scipy.special import sici

T, b, C, x = sp.symbols('T b C x', positive=True)
split_integral = 2*C*(sp.integrate(1, (x, 0, 1/T))+
                        sp.integrate(1/(T*x), (x, 1/T, 2*b)))
displayed = 2*C*(1+sp.log(2*b*T))/T
assert sp.simplify(sp.expand_log(split_integral-displayed, force=True)) == 0, 'mean_kernel_constant'
print(json.dumps({'check': 'mean_kernel_constant', 'domain': '2*b*T>=1'}))

# Unrelated continuous probability measure: uniform on [-1,1]. Its exact
# Fourier transform is sinc, so these are independent of any matrix fixture.
records = []
for delta in [0.01, 0.1, 0.4]:
    z = 1+1j*delta
    m = 0.5*np.log((z+1)/(z-1))
    e = min(1.0, 4*delta*(-m.imag))
    assert delta <= e+1e-14, 'edge_mass_bound'
    for time in [10., 100., 1000.]:
        integral = sici(2*time)[0]+(np.cos(2*time)-1)/(2*time)
        survival_mean = integral/time
        bound = (e+np.sqrt((1+np.log(2*time))/time))**2
        assert survival_mean <= bound, 'finite_mean_bound'
        records.append({'delta': delta, 'T': time, 'survival_mean': survival_mean,
                        'upper_bound': min(1., bound)})
print(json.dumps({'check': 'edge_mass_and_finite_mean_bound', 'records': records}))
time = 7.3
exact = sici(2*time)[0]+(np.cos(2*time)-1)/(2*time)
numeric = quad(lambda y: np.sinc(y/np.pi)**2, 0, time, epsabs=1e-12)[0]
assert abs(exact-numeric) < 1e-11, 'direct_sinc_integral'
print(json.dumps({'check': 'direct_sinc_integral', 'error': abs(exact-numeric), 'checks': 3,
                  'scope': 'continuous toy measure and exact elementary integral; not a numerical continuum walk proof'}))
