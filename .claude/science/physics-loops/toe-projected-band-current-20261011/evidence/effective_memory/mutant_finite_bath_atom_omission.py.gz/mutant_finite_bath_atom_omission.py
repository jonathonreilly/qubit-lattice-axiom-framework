"""Selective independent-form controls; finite examples do not prove continuum decay."""
import json
import platform
import numpy as np
import scipy
from scipy.linalg import expm
from scipy.integrate import quad
import sympy as sp

checks = 0


def check(name, condition, detail=None):
    global checks
    assert bool(condition), name
    checks += 1
    print(json.dumps({'check': name, 'detail': detail}))


def zero(x):
    if isinstance(x, sp.MatrixBase):
        return all(sp.simplify(y) == 0 for y in x)
    return sp.simplify(x) == 0


I = sp.I
f, h, z = sp.symbols('f h z', real=True, nonzero=True)
D = sp.Matrix([[0, -I*f], [I*f, 0]])
g = sp.Matrix([I*h, 0])
A = D.row_join(g).col_join(g.conjugate().T.row_join(sp.zeros(1)))
e = sp.Matrix([0, 0, 1])
check('direct_block_selfadjoint', zero(A-A.conjugate().T))
direct_resolvent = ((z*sp.eye(3)-A).inv())[2, 2]
self_energy = h**2*z/(z**2-f**2)
scalar_resolvent = 1/(z-self_energy)
check('Schur_sign_and_denominator', zero(direct_resolvent-scalar_resolvent))
check('balanced_helicity_weights', zero((g.conjugate().T*D*g)[0]))

# An independently expanded three-by-three exponential gives a nondecaying
# finite bath, instead of assigning a survival amplitude by the memory formula.
A1 = A.subs({f: sp.Rational(3, 5), h: sp.Rational(4, 5)})
t, s = sp.symbols('t s', real=True)
check('finite_fixture_cubic', zero(A1**3-A1))
U1 = sp.eye(3)-I*sp.sin(t)*A1+(sp.cos(t)-1)*A1**2
check('finite_fixture_exponential_ODE', zero(I*sp.diff(U1, t)-A1*U1))
a1 = (e.T*U1*e)[0]
K1 = (g.conjugate().T*(sp.cos(f*t)*sp.eye(2)-I*sp.sin(f*t)*D/f)*g)[0]
K1 = sp.simplify(K1.subs({f: sp.Rational(3, 5), h: sp.Rational(4, 5)}))
conv = sp.integrate(K1.subs(t, t-s)*a1.subs(t, s), (s, 0, t))
check('Volterra_sign_actual_matrix', zero(sp.diff(a1, t)+conv))
check('finite_bath_exact_recurrence', zero(a1.subs(t, 2*sp.pi)-1))
zero_projection = sp.eye(3)-A1**2
atom = (e.T*zero_projection*e)[0]
check('finite_bath_nonzero_dressing_atom', atom == 0, str(atom))
check('finite_bath_not_exponential_decay', zero(sp.diff(a1, t).subs(t, 0)) and
      sp.diff(a1, t, 2).subs(t, 0) < 0, str(a1))

# Two distinct bath frequencies: direct powers and matrix inversion are compared
# with the convolution recurrence and scalar expression, with no imported code.
freqs = [sp.Rational(2, 3), sp.Rational(5, 7)]
couplings = [sp.Rational(1, 4), sp.Rational(2, 5)]
D2 = sp.diag(*[sp.Matrix([[0, -I*x], [I*x, 0]]) for x in freqs])
g2 = sp.Matrix([I*couplings[0], 0, I*couplings[1], 0])
A2 = D2.row_join(g2).col_join(g2.conjugate().T.row_join(sp.zeros(1)))
e2 = sp.Matrix([0, 0, 0, 0, 1])
za = sp.Rational(2, 5)+I*sp.Rational(3, 7)
m2_direct = ((za*sp.eye(5)-A2).inv())[4, 4]
m2_scalar = 1/(za-sum(y*y*za/(za*za-x*x) for x, y in zip(freqs, couplings)))
check('two_frequency_resolvent', zero(m2_direct-m2_scalar))
ad = [sp.simplify((e2.T*((-I*A2)**n)*e2)[0]) for n in range(14)]
kd = [sp.simplify((g2.conjugate().T*((-I*D2)**n)*g2)[0]) for n in range(12)]
check('convolution_derivative_moments', all(zero(ad[n+1]+
      sum(kd[j]*ad[n-1-j] for j in range(n))) for n in range(1, 12)))
check('dressing_even_moments', all(zero(ad[n]) for n in range(1, 14, 2)))

# At nonzero times a fresh quadrature of the eliminated-field formula is
# compared with the full matrix exponential; this is a floating finite control.
An = np.array(A2, dtype=complex)
Dn = np.array(D2, dtype=complex)
gn = np.array(g2, dtype=complex).ravel()
en = np.array(e2, dtype=complex).ravel()
errors = []
for time in [0.3, 2.1, 7.0]:
    psi = expm(-1j*time*An)@en
    def alpha(x):
        return (expm(-1j*x*An)@en)[-1].real
    un = np.empty(4, dtype=complex)
    for j in range(4):
        fun = lambda x: (-1j*expm(-1j*(time-x)*Dn)@gn)[j]*alpha(x)
        un[j] = quad(lambda x: fun(x).real, 0, time, epsabs=2e-11)[0]+1j*quad(
            lambda x: fun(x).imag, 0, time, epsabs=2e-11)[0]
    p_memory = 0.0
    for omega, coupling in zip(map(float, freqs), map(float, couplings)):
        C = quad(lambda x: np.cos(omega*(time-x))*alpha(x), 0, time, epsabs=2e-11)[0]
        S = quad(lambda x: np.sin(omega*(time-x))*alpha(x), 0, time, epsabs=2e-11)[0]
        p_memory += coupling**2*(C*C+S*S)
    errors.append(max(np.linalg.norm(un-psi[:-1]),
                      abs(p_memory-np.vdot(psi[:-1], psi[:-1]).real),
                      abs(p_memory-(1-abs(psi[-1])**2))))
check('field_and_transfer_integrals_floating', max(errors) < 2e-10, errors)

# Exact constants in the cone proof are derived from the Jacobian integral.
H = sp.Rational(23, 24)
check('cone_derivative_constant_four', sp.Rational(13, 6)/H+
      sp.Rational(2, 3)/H**3 < 4)
check('cone_value_constant_one', sp.Rational(5, 6)/H < 1)
check('cone_direction_constant_half', sp.Rational(1, 3)/H < sp.Rational(1, 2))
b, chi, I0, rad = sp.symbols('b chi I0 rad', positive=True)
r0 = sp.sqrt(chi)/8
G_lower = b*b*chi/(64*I0*rad**2)
density_integrand = sp.Rational(1, 2)*G_lower*rad**2/(2*b)/(2*sp.pi)**3
cone_density = sp.simplify(2*sp.pi*sp.integrate(density_integrand, (rad, r0/2, r0)))
target_density = b*chi**sp.Rational(3, 2)/(16384*sp.pi**2*I0)
check('normalized_single_helicity_density_constant', zero(cone_density-target_density), str(cone_density))

# Direct q-gradient and coordinate determinant check the cone geometry through
# a second implementation. Samples do not replace the uniform Taylor proof.
worst = {'value_ratio': 0.0, 'derivative_ratio': 0.0, 'jacobian_error': 0.0}
for kappa in [np.array([1., 1., 1.]), np.array([1., 0., 0.]), np.array([2., -3., 6.])]:
    bn = np.linalg.norm(kappa)
    axis = kappa/bn
    helper = np.eye(3)[np.argmin(abs(axis))]
    p = np.cross(axis, helper); p /= np.linalg.norm(p)
    q = np.cross(axis, p)
    for cn in [1/256, 1/4, 3/4]:
        rn0 = np.sqrt(cn)/8
        for rn in [rn0/2, rn0]:
            for tn in [-1+cn/4, 0, 1-cn/4]:
                for phi in [0.17, 2.03]:
                    lateral = np.cos(phi)*p+np.sin(phi)*q
                    omega = tn*axis+np.sqrt(1-tn*tn)*lateral
                    domega = axis-tn/np.sqrt(1-tn*tn)*lateral
                    dphi = np.sqrt(1-tn*tn)*(-np.sin(phi)*p+np.cos(phi)*q)
                    point = rn*omega
                    sn, cs = np.sin(point), np.cos(point)
                    eps = np.linalg.norm(sn)
                    nn, dn = sn/eps, kappa*cs
                    fn = np.dot(dn, nn)
                    gradf = kappa*np.cos(2*point)/eps-fn*sn*cs/eps**2
                    ft = np.dot(gradf, rn*domega)
                    worst['value_ratio'] = max(worst['value_ratio'], abs(fn/bn-tn)/rn**2)
                    worst['derivative_ratio'] = max(worst['derivative_ratio'],
                        abs(ft/bn-1)*np.sqrt(1-tn*tn)/rn**2)
                    determinant = abs(np.linalg.det(np.column_stack([omega, rn*domega, rn*dphi])))
                    worst['jacobian_error'] = max(worst['jacobian_error'], abs(determinant/rn**2-1))
                    assert 7*bn/8 <= ft <= 9*bn/8, 'cone_monotone_coordinate'
                    assert np.linalg.norm(np.cross(dn, nn)) >= bn*np.sqrt(cn)/4, 'cone_nonzero_coupling'
check('cone_direct_gradient_and_jacobian_floating', worst['value_ratio'] <= 1 and
      worst['derivative_ratio'] <= 4 and worst['jacobian_error'] < 1e-12, worst)

# The interval/Poisson inequality is checked directly against an unrelated
# finite positive spectral measure, including atoms. Such atoms are precisely
# what the continuum lower-bound argument must exclude in the theorem.
energies = np.array([-1.3, -0.2, 0.7, 1.8])
weights = np.array([0.1, 0.35, 0.4, 0.15])
ratios = []
for center, eta in [(-0.1, 0.3), (0.9, 1.2), (1.7, 0.15)]:
    mass = weights[abs(energies-center) <= eta].sum()
    mv = (weights/(center+1j*eta-energies)).sum()
    rhs = 2*eta*(-mv.imag)
    ratios.append(float(mass/rhs))
check('Poisson_interval_bound_independent_measure', max(ratios) <= 1, ratios)
print(json.dumps({'checks': checks, 'python': platform.python_version(),
                  'sympy': sp.__version__, 'numpy': np.__version__, 'scipy': scipy.__version__,
                  'scope': 'exact finite algebra, floating finite controls and sampled geometry; continuum conclusions use the proof'}))
