"""Run actual source-copy defects, retaining complete failures."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

D = Path(__file__).resolve().parent
original = (D/'memory_controls.py').read_text()
cases = [
    ('Schur_sign', 'scalar_resolvent = 1/(z-self_energy)',
     'scalar_resolvent = 1/(z+self_energy)', 'Schur_sign_and_denominator'),
    ('memory_sign', 'zero(sp.diff(a1, t)+conv)',
     'zero(sp.diff(a1, t)-conv)', 'Volterra_sign_actual_matrix'),
    ('finite_bath_atom_omission', "atom > 0, str(atom)",
     "atom == 0, str(atom)", 'finite_bath_nonzero_dressing_atom'),
    ('helicity_half_omission', 'density_integrand = sp.Rational(1, 2)*G_lower',
     'density_integrand = G_lower', 'normalized_single_helicity_density_constant'),
    ('Poisson_factor_two_omission', 'rhs = 2*eta*(-mv.imag)',
     'rhs = eta*(-mv.imag)', 'Poisson_interval_bound_independent_measure'),
]
records = []
for name, old, new, assertion in cases:
    assert original.count(old) == 1, name
    source = D/f'mutant_{name}.py'
    source.write_text(original.replace(old, new))
    log = D/f'mutant_{name}.log'
    cmd = ['/opt/homebrew/opt/python@3.13/bin/python3.13', str(source)]
    begin = time.monotonic()
    with log.open('w') as f:
        try:
            p = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, timeout=120)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = 124
    outcome = {'name': name, 'old': old, 'new': new, 'intended_assertion': assertion,
               'command': cmd, 'returncode': rc, 'elapsed_seconds': time.monotonic()-begin,
               'timeout_seconds': 120, 'source': source.name, 'log': log.name,
               'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
               'failed_at_intended_assertion': rc == 1 and 'AssertionError: '+assertion in log.read_text()}
    records.append(outcome)
    print(json.dumps(outcome))
(D/'mutation_manifest.json').write_text(json.dumps(records, indent=2)+'\n')
assert all(x['failed_at_intended_assertion'] for x in records)
