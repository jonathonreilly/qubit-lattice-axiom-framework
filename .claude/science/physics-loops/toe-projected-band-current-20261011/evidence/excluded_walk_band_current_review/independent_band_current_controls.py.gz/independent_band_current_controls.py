#!/usr/bin/env python3
"""Independent controls of the proposed two-parameter band-current bridge.

Written from the operator reconstruction before reading an author draft.
No author imports, source mutations, or continuum quadrature. Literal
finite fixtures check algebra and actual current evolution, not continuum
spectral estimates or the existence of a uniform rate.
"""
import json
import platform
import time
import numpy as np
import scipy
from scipy.linalg import expm
import sympy as sp

START = time.monotonic()
R, I = sp.Rational, sp.I


def cross(x):
    return sp.Matrix([[0, -x[2], x[1]], [x[2], 0, -x[0]], [-x[1], x[0], 0]])


def exact(name, a, b):
    d = a-b
    vals = list(d) if isinstance(d, sp.MatrixBase) else [d]
    assert all(sp.simplify(v) == 0 for v in vals), name
    print("EXACT", name, flush=True)


def array(x):
    return np.array(x.evalf(17).tolist(), dtype=complex)


print(json.dumps({"python": platform.python_version(), "numpy": np.__version__,
                  "scipy": scipy.__version__, "sympy": sp.__version__,
                  "inputs": "literal independent finite fixtures"}))

# Two cyclic orbits, with radii 1 and 4/5, and their implicit antipodes.
# The even singlet / odd triplet coordinates make contact compression
# explicit. These values are not a torus quadrature or a small-band model.
bases = [([R(7,25), R(24,25), 0], [R(24,25), R(7,25), 1]),
         ([R(4,5), 0, 0], [R(3,5), 1, 1])]
fixture = [(sp.Matrix(ss[j:]+ss[:j]), sp.Matrix(cc[j:]+cc[:j]))
           for ss, cc in bases for j in range(3)]
m, dim = len(fixture), 4*len(fixture)
c, zeta, v = (sp.zeros(dim,1) for _ in range(3))
va = [sp.zeros(dim,1) for _ in range(3)]
Hfree, F, E2, Bd = (sp.zeros(dim) for _ in range(4))
I0 = sum(1/(4*ss.dot(ss)) for ss,_ in fixture)/m
kap = sp.Matrix([1, 1, 1])
for j,(ss,cc) in enumerate(fixture):
    o = 4*j
    e2 = ss.dot(ss)
    c[o] = 1/sp.sqrt(m)
    zeta[o+1:o+4,0] = ss/(2*e2*sp.sqrt(m*I0))
    v[o+1:o+4,0] = ss/sp.sqrt(m)
    Hfree[o,o+1:o+4] = 2*ss.T
    Hfree[o+1:o+4,o] = 2*ss
    F[o+1:o+4,o+1:o+4] = sp.eye(3)-ss*ss.T/e2
    E2[o:o+4,o:o+4] = e2*sp.eye(4)
    Bd[o+1:o+4,o+1:o+4] = I*cross(cc)
    for a in range(3):
        va[a][o+1+a] = ss[a]/sp.sqrt(m)
C = c*c.H
P = sp.eye(dim)-C
Pi = F+zeta*zeta.H
Q = P-Pi
H = P*Hfree*P
A = Pi*Bd*Pi
Ls=[]
for a in range(3):
    mult=sp.diag(*[1-2*ss[a]**2 for ss,_ in fixture for _ in range(4)])
    Ls.append(P*mult*P+va[a]*v.H+v*va[a].H)
exact("full physical canonical trace identity", sum(Ls, sp.zeros(dim)),
      3*P-H*H/2-2*E2*F)
assert sum(Ls,sp.zeros(dim))-(3*P-H*H/2) != sp.zeros(dim)
print("DISCRIMINATOR deleting transverse trace term changes the full operator")

# Non-diagonal kappa checks the structural mapping without cyclic symmetry.
Bn=sp.zeros(dim)
for j,(_,cc) in enumerate(fixture):
    dn=cc.multiply_elementwise(sp.Matrix([R(2,3),-R(3,7),R(5,4)]))
    Bn[4*j+1:4*j+4,4*j+1:4*j+4]=I*cross(dn)
exact("Q perturbation lands in free transverse kernel", Bn*Q, F*Bn*Q)
exact("no Q-Q averaged block", Q*Bn*Q, sp.zeros(dim))
exact("mapped perturbation killed by H", H*Bn*Q, sp.zeros(dim))
# The finite inverse is only a control of the cutoff algebra. In the
# continuum proof it must be replaced by H^-1 1_{|H|>sigma}.
Hinv=(H+Pi+C).inv()*Q
exact("finite reduced inverse", H*Hinv, Q)
Y=Bn*Hinv
delta=sp.Symbol("delta", positive=True)
vp=-I*H*Q/delta
yp=Y*vp
residual=I*(vp+delta*yp)-(H/delta+Bn)*(Q+delta*Y)
exact("complement corrector residual", residual, -delta*Bn*Y)
assert Bn*Y != sp.zeros(dim)

# Prepare a literal free positive spectral band: 3/2 < E < 17/10 selects
# the 4/5-radius orbit, whose positive free eigenvalue is 8/5.
Gamma=sp.zeros(dim)
for j,(ss,_) in enumerate(fixture):
    e=sp.sqrt(ss.dot(ss))
    if R(3,2) < 2*e < R(17,10):
        plus=sp.Matrix([1, *(ss/e)])/sp.sqrt(2)
        Gamma[4*j:4*j+4,4*j:4*j+4]=plus*plus.H
w=sp.simplify((zeta.H*Gamma*zeta)[0])
phi=Gamma*zeta/sp.sqrt(w)
beta=sp.simplify((c.H*phi)[0])
n=sp.sqrt(1-beta**2)
chi=P*phi/n
amp=sp.sqrt(w)/n
x=chi-amp*zeta
exact("band preparation normalized", (chi.H*chi)[0], 1)
exact("band preparation has no transverse part", F*chi, sp.zeros(dim,1))
exact("band zero projection is exactly dressing", Pi*chi, amp*zeta)
exact("remaining datum belongs to Q", Q*x, x)
assert amp != 0 and x != sp.zeros(dim,1)
print("EXACT_BAND_FIXTURE", json.dumps({"dimension":dim,"I0":str(I0),
      "w":str(w),"beta":str(beta),"dressing_weight":str(sp.simplify(amp**2)),
      "scope":"finite algebra only; no continuum lambda coefficient"}))

Hn,Bdn,An,Pn,Fn,En=map(array,[H,Bd,A,P,F,E2])
zn,chin,xn,phin=(array(a).ravel() for a in [zeta,chi,x,phi])
vn=array(v).ravel()
van=[array(a).ravel() for a in va]
Lns=[array(a) for a in Ls]


def actual(k):
    block=np.zeros((dim,dim),complex)
    for j,(ss,cc) in enumerate(fixture):
        ss=np.array(ss,float).ravel();cc=np.array(cc,float).ravel()
        h=2*np.cos(k/2)*ss;d=2*np.sin(k/2)*cc
        o=4*j
        block[o,o+1:o+4]=h
        block[o+1:o+4,o]=h
        block[o+1:o+4,o+1:o+4]=1j*np.array([[0,-d[2],d[1]],[d[2],0,-d[0]],[-d[1],d[0],0]])
    h=sum((2*np.cos(k[a]/2)*van[a] for a in range(3)), np.zeros(dim,complex))
    js=[]
    for a in range(3):
        hp=-np.sin(k[a]/2)*van[a]
        diag=np.array([np.sin(k[a])*(1-2*float(ss[a])**2)
                       for ss,_ in fixture for _ in range(4)])
        js.append(Pn@np.diag(diag)@Pn-np.outer(hp,h.conj())-np.outer(h,hp.conj()))
    return Pn@block@Pn, block, js


tau=0.17
eff=expm(-1j*tau*An)@zn
predicted=-2/3*float(amp**2)*float(np.vdot(Fn@eff,En@(Fn@eff)).real)
assert predicted < -1e-3
rows=[]
for dv in [0.032,0.008,0.002,0.0005]:
    hk,hkfree,js=actual(dv*np.ones(3))
    U=expm(-1j*tau*hk/dv)
    state=U@chin
    mixed=float(amp)*(eff)+expm(-1j*tau*Hn/dv)@xn
    # Reproject the free preparation to the true ++ eigenspace at K.
    # In this small-K fixture the highest local eigenvalue is ++.
    phik=np.zeros(dim,complex)
    for j in range(m):
        vals,vecs=np.linalg.eigh(hkfree[4*j:4*j+4,4*j:4*j+4])
        top=vecs[:,-1]
        phik[4*j:4*j+4]=top*np.vdot(top,phin[4*j:4*j+4])
    phik/=np.linalg.norm(phik)
    chik=Pn@phik;chik/=np.linalg.norm(chik)
    statek=U@chik
    drifts=[float((np.vdot(state,j@state)-np.vdot(chin,j@chin)).real/dv) for j in js]
    adjusted=[float((np.vdot(statek,j@statek)-np.vdot(chik,j@chik)).real/dv) for j in js]
    assert max(drifts)-min(drifts) < 2e-11
    # Physical energy is conserved exactly by the actual matrix evolution.
    conservation=abs(np.vdot(state,hk@hk@state)-np.vdot(chin,hk@hk@chin))
    assert conservation < 3e-12
    rows.append({"delta":dv,"mixed_state_error":float(np.linalg.norm(state-mixed)),
                 "fixed_initial_scaled_drift":drifts,"actual_positive_preparation_scaled_drift":adjusted,
                 "limit":predicted})
assert abs(rows[-1]['fixed_initial_scaled_drift'][0]-predicted) < 2e-5
assert abs(rows[-1]['actual_positive_preparation_scaled_drift'][0]-predicted) < 2e-5
print("ACTUAL_FINITE_BAND_CURRENT", json.dumps(rows))

# Check the independent packet sign budget, including both endpoint costs.
a2,lambda_band=sp.symbols("a2 lambda_band", positive=True)
rho=a2/777600
delta_bound=a2*lambda_band/44236800
exact("kappa envelope drift budget",9*rho,a2/86400)
exact("positive band preparation drift budget",512*delta_bound/lambda_band,a2/86400)
exact("surviving per-fiber signed bound",-a2/21600+9*rho+512*delta_bound/lambda_band,-a2/43200)
exact("global continuum lower-weight constant",(lambda_band/(9*sp.pi**2))/43200,lambda_band/(388800*sp.pi**2))
assert 2+sp.sqrt(3) < 4
assert R(11,10)*(1+sp.sqrt(3)) < 4
assert 8+8*R(1,20) < 9
print(json.dumps({"elapsed_seconds":time.monotonic()-START,
                  "limitations":"finite controls do not prove the gapless complementary comparison or its ordered-limit quantifiers"}))
