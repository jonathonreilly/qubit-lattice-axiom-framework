#!/usr/bin/env python3
"""Bind this external author's proof/control packet and verify frozen parents."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

D = Path(__file__).resolve().parent
S = D.parent
W = S.parent / "worktree"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=W, text=True).strip()


parent_path = S / "excluded_walk_long_time/receipt.json"
parent_hash = "bdd9d7b0caedbf168f4e45dead01b7a816f321b5894ae5671c1dcdedb81d35dc"
assert sha(parent_path) == parent_hash
parent = json.loads(parent_path.read_text())
for record in parent["artifacts"]:
    assert sha(S / record["path"]) == record["sha256"], record["path"]
for record in parent["sources"].values():
    assert sha(record["path"]) == record["sha256"], record["path"]
for path, digest in parent["protected_publication_files_unchanged"].items():
    assert sha(S / path) == digest, path
instructions = {}
for path, digest in parent["instructions"].items():
    if path.startswith("worktree:"):
        actual = sha(W / path[9:])
    else:
        data = subprocess.check_output(["git", "show", "main:" + path], cwd=W)
        actual = hashlib.sha256(data).hexdigest()
    assert actual == digest, path
    instructions[path] = actual

manifest = json.loads((D / "mutation_manifest.json").read_text())
base_path = D / manifest["baseline_source"]
base = base_path.read_text()
assert sha(base_path) == manifest["baseline_sha256"]
for record in manifest["mutations"]:
    assert (D / record["source"]).read_text() == base.replace(record["before"], record["after"], 1)
    assert sha(D / record["source"]) == record["source_sha256"]
    assert sha(D / record["log"]) == record["log_sha256"]
    assert record["exit_code"] == 1 and record["intended_assertion_reached"]
baseline = (D / "baseline.log").read_text().splitlines()
summary = json.loads(baseline[-1])
assert summary["checks"] == 61
execution = json.loads((D / "baseline_execution.json").read_text())
assert execution["exit"] == 0

note = S / "EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md"
sources = {key: parent["sources"][key] for key in
           ["threshold", "canonical_current", "canonical_review", "cook_bridge", "cook_review", "walk_contract"]}
sources["long_time_probe"] = {"path": str(S / "EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md"),
    "sha256": "09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324",
    "coverage": "complete 457-line argument; re-read in current extension"}
sources["long_time_receipt"] = {"path": str(parent_path), "sha256": parent_hash,
    "coverage": "all recorded source, artifact and instruction identities checked unchanged"}
artifacts = []
for path in [note, *sorted(p for p in D.iterdir() if p.is_file() and p.name != "receipt.json")]:
    artifacts.append({"path": str(path.relative_to(S)), "sha256": sha(path),
                      "bytes": path.stat().st_size})
receipt = {
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "task": "bounded weak-K full-zero-space dynamics and actual canonical current",
    "status": "external author derivation with finite controls; no independent review or audit verdict",
    "note": {"path": str(note), "sha256": sha(note), "lines": len(note.read_text().splitlines()),
             "coverage": "entire final argument read; final three wording/hypothesis edits read in full diff"},
    "sources": sources,
    "instructions": instructions,
    "local_main": git("rev-parse", "main"),
    "worktree_head_at_freeze": git("rev-parse", "HEAD"),
    "freshness_scope": "file-identity bound; local-main comparison only; no remote fetch or external theorem import",
    "parent_packet": {"receipt": str(parent_path), "sha256": parent_hash,
                      "all_artifacts_rechecked_unchanged": len(parent["artifacts"]),
                      "all_sources_rechecked_unchanged": len(parent["sources"])},
    "protected_publication_files_unchanged": parent["protected_publication_files_unchanged"],
    "execution": execution,
    "environment": json.loads(baseline[0]),
    "control_outcomes": {"baseline_checks": summary["checks"], "actual_mutants": len(manifest["mutations"]),
                         "all_failed_at_intended_assertion": True, "complete_failure_logs_read": True,
                         "numerical_scope": "finite matrix examples and unvalidated torus quadrature; no grid proof of continuum assertions"},
    "strongest_proved_statements": [
        "Explicit bounded effective block on ker H0(0) direct-sum span zeta, including both off-diagonal couplings.",
        "Gapless strong evolution limit for every fixed initial zero-space vector, uniformly on compact rescaled times; vector-dependent spectral-cutoff error.",
        "Actual canonical-current block and strong current limit; preserved initial dressing cancellation.",
        "Strict quadratic effective current response from zeta for equal nonzero kappa components, including a normalizable total-momentum envelope.",
        "Explicit cone-concentrating transverse family disproves an operator-norm upgrade of the state limit on the entire zero-space unit ball."
    ],
    "limits": [
        "No conclusion for arbitrary lambda-dependent projected positive-band packets.",
        "No uniform quantitative low-spectral-mass bound or finite-lambda onset for the global current limit.",
        "No current counterexample follows from the nonuniform state comparison.",
        "No isolated-eigenvalue continuation, unbounded-dipole identity on zeta, physical-law adoption, universal relaxation, or completeness claim.",
        "All controls are author controls; independent review of this new proof remains outstanding."
    ],
    "editable_prompt_files_changed": [],
    "writes": "only the named new note and its new excluded_walk_degenerate support directory",
    "artifacts": artifacts,
    "receipt_scope": "receipt intentionally does not hash itself; its SHA-256 is reported separately"
}
(D / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"note_sha256": sha(note), "note_lines": len(note.read_text().splitlines()),
                  "helper_sha256": sha(base_path), "receipt_sha256": sha(D / "receipt.json"),
                  "bound_artifacts": len(artifacts), "baseline_checks": 61, "mutants": 8,
                  "frozen_parent_artifacts_verified": len(parent["artifacts"])}))
