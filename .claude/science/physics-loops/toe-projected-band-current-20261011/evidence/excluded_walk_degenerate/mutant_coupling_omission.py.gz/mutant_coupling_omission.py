#!/usr/bin/env python3
"""Author controls for the gapless zero-space derivation; no continuum proof by grid.

Literal inputs; no network or repository writes. Exact SymPy algebra is separated
from floating finite-dimensional evolution and unvalidated torus quadrature.
Intended outer process timeout: 120 seconds. Python >=3.10, NumPy/SciPy/SymPy.
"""
import json
import platform
import time

import numpy as np
import scipy
from scipy.linalg import expm
import sympy as sp

START = time.monotonic()
COUNT = 0
ii = sp.I


def check(label, condition):
    global COUNT
    if not condition:
        raise AssertionError(label)
    COUNT += 1
    print(f"PASS {label}", flush=True)


def exact(label, left, right):
    delta = left - right
    if isinstance(delta, sp.MatrixBase):
        good = all(sp.simplify(x) == 0 for x in delta)
    else:
        good = sp.simplify(delta) == 0
    check(label, good)


def cross(x):
    return sp.Matrix([[0, -x[2], x[1]], [x[2], 0, -x[0]], [-x[1], x[0], 0]])


def farray(x):
    return np.array(x.evalf(17).tolist(), dtype=complex)


print(json.dumps({"python": platform.python_version(), "numpy": np.__version__,
                  "scipy": scipy.__version__, "sympy": sp.__version__,
                  "timeout_seconds": 120, "inputs": "literal, deterministic"}))

# Independent Pauli construction fixes the first derivative sign.
pauli = [sp.Matrix([[0, 1], [1, 0]]), sp.Matrix([[0, -ii], [ii, 0]]),
         sp.diag(1, -1)]
spin_c = sp.Matrix([0, 1, -1, 0]) / sp.sqrt(2)
trip = [sp.kronecker_product(x, sp.eye(2)) * spin_c for x in pauli]
ST = sp.Matrix.hstack(spin_c, *trip)
exact("spin basis unitary", ST.H * ST, sp.eye(4))
d = sp.Matrix(sp.symbols("d_1 d_2 d_3", real=True))
raw_B = sp.zeros(4)
for j in range(3):
    raw_B += d[j] * (sp.kronecker_product(pauli[j], sp.eye(2))
                     + sp.kronecker_product(sp.eye(2), pauli[j])) / 2
FIRST_DERIVATIVE_SIGN = 1
expected_B = sp.diag(sp.zeros(1), FIRST_DERIVATIVE_SIGN * ii * cross(d))
exact("Pauli derivative cross sign", ST.H * raw_B * ST, expected_B)
s = sp.Matrix(sp.symbols("s_1 s_2 s_3", real=True))
e2 = (s.T * s)[0]
transverse = sp.eye(3) - s * s.T / e2
PROJECT_BOTH_SIDES = True
candidate_D = (transverse * cross(d) * transverse if PROJECT_BOTH_SIDES else cross(d))
exact("transverse projected cross identity", candidate_D, (d.dot(s) / e2) * cross(s))

# Six positive representatives and their implicit antipodes. The reduced
# pair coordinate has an even singlet and odd triplet. Actual sin/cos pairs
# are rational; the equal probability of each antipodal pair is 1/6.
R = sp.Rational
bases = [(sp.Matrix([R(3, 5), 0, 0]), sp.Matrix([R(4, 5), 1, 1])),
         (sp.Matrix([R(3, 5), R(5, 13), 0]), sp.Matrix([R(4, 5), R(12, 13), 1]))]
fixture = []
for sv, cv in bases:
    for shift in range(3):
        fixture.append((sp.Matrix([sv[(j - shift) % 3] for j in range(3)]),
                        sp.Matrix([cv[(j - shift) % 3] for j in range(3)])))
m = len(fixture)
dim = 4 * m
I0 = sum(1 / (4 * sv.dot(sv)) for sv, _ in fixture) / m
c = sp.zeros(dim, 1)
zeta = sp.zeros(dim, 1)
v = sp.zeros(dim, 1)
va = [sp.zeros(dim, 1) for _ in range(3)]
Hfree = sp.zeros(dim)
F = sp.zeros(dim)
B = sp.zeros(dim)
E2 = sp.zeros(dim)
kap = sp.Matrix([1, 1, 1])
for p, (sv, cv) in enumerate(fixture):
    off = 4 * p
    eps2 = sv.dot(sv)
    c[off] = 1 / sp.sqrt(m)
    Hfree[off, off + 1:off + 4] = 2 * sv.T
    Hfree[off + 1:off + 4, off] = 2 * sv
    F[off + 1:off + 4, off + 1:off + 4] = sp.eye(3) - sv * sv.T / eps2
    zeta[off + 1:off + 4, 0] = sv / (2 * eps2 * sp.sqrt(m * I0))
    v[off + 1:off + 4, 0] = sv / sp.sqrt(m)
    for a in range(3):
        va[a][off + 1 + a] = sv[a] / sp.sqrt(m)
    B[off + 1:off + 4, off + 1:off + 4] = ii * cross(kap.multiply_elementwise(cv))
    E2[off:off + 4, off:off + 4] = eps2 * sp.eye(4)
C = c * c.H
P = sp.eye(dim) - C
Hstar = P * Hfree * P
INCLUDE_DRESSING = True
Pi = F + (zeta * zeta.H if INCLUDE_DRESSING else sp.zeros(dim))
exact("dressing normalization", (zeta.H * zeta)[0], 1)
exact("physical zero projector", Pi * Pi, Pi)
exact("physical zero annihilation", Hstar * Pi, sp.zeros(dim))
check("entire physical zero dimension", Pi.rank() == dim - Hstar.rank() - 1 == 13)
exact("physical zero excludes contact", Pi * c, sp.zeros(dim, 1))
A = Pi * B * Pi
g = F * B * zeta
exact("dressing self coupling zero", (zeta.H * B * zeta)[0], 0)
KEEP_G = False
A_blocks = F * B * F + (g * zeta.H + zeta * g.H if KEEP_G else sp.zeros(dim))
exact("full effective generator includes g", A, A_blocks)
g_reference = sp.zeros(dim, 1)
for p, (sv, cv) in enumerate(fixture):
    dv = kap.multiply_elementwise(cv)
    g_reference[4*p + 1:4*p + 4, 0] = ii * dv.cross(sv) / (2 * sv.dot(sv) * sp.sqrt(m * I0))
exact("actual transverse dressing source", g, g_reference)
check("nonzero dressing source", sp.simplify((g.H * g)[0]) > 0)
exact("effective generator self adjoint", A.H, A)

Ls = []
Js = []
KEEP_PLACEMENT_CORRECTION = True
for a in range(3):
    ma = sp.diag(*[1 - 2 * sv[a]**2 for sv, _ in fixture for _spin in range(4)])
    placement = va[a] * v.H + v * va[a].H
    La = P * ma * P + (placement if KEEP_PLACEMENT_CORRECTION else sp.zeros(dim))
    Ja = Pi * La * Pi
    ra = F * va[a] / (2 * sp.sqrt(I0))
    block = F * ma * F + ra * zeta.H + zeta * ra.H + zeta * zeta.H
    exact(f"canonical block including cross {a}", Ja, block)
    exact(f"canonical dressing cancellation {a}", (zeta.H * La * zeta)[0], 1)
    Ls.append(La)
    Js.append(Ja)
exact("full zero space trace identity", sum(Js, sp.zeros(dim)) - 3 * Pi, -2 * F * E2 * F)
gamma2 = sp.simplify((g.H * E2 * g)[0])
for a in range(3):
    comm = A * Js[a] - Js[a] * A
    exact(f"cyclic first derivative zero {a}", (ii * zeta.H * comm * zeta)[0], 0)
    curvature = -(zeta.H * (A * comm - comm * A) * zeta)[0]
    exact(f"cyclic current second derivative {a}", curvature, -4 * gamma2 / 3)
print("EXACT_FIXTURE", json.dumps({"positive_pairs": m, "dimension": dim,
      "physical_zero_dimension": Pi.rank(), "I0": str(I0), "gamma_squared": str(gamma2)}))

# Numerical finite-dimensional controls: these do not prove a gapless continuum
# limit. They check the cutoff corrector algebra and the actual exponentials.
Hn, Bn, An, Pin, Fn = map(farray, [Hstar, B, A, Pi, F])
cn, zn = farray(c).ravel(), farray(zeta).ravel()
Pn = farray(P)
vn = farray(v).ravel()
van = [farray(x).ravel() for x in va]
Jn = [farray(x) for x in Js]
eig, U = np.linalg.eigh(Hn)
positive = np.abs(eig[np.abs(eig) > 1e-9])
cut = float(np.median(positive))
sel = np.abs(eig) > cut
Q = (U[:, sel] * 1.0) @ U[:, sel].conj().T
inv_cut = (U[:, sel] / eig[sel]) @ U[:, sel].conj().T
Low = np.eye(dim) - Pin - np.outer(cn, cn.conj()) - Q
tau, lam = 0.37, 0.031
vt = expm(-1j * tau * An) @ zn
CORRECTOR_SIGN = -1
y = CORRECTOR_SIGN * inv_cut @ Bn @ vt
yp = -1j * CORRECTOR_SIGN * inv_cut @ Bn @ An @ vt
residual = 1j * (-1j * An @ vt + lam * yp) - (Hn / lam + Bn) @ (vt + lam * y)
reference_residual = -Low @ Bn @ vt + lam * (1j * yp - Bn @ y)
check("cutoff corrector residual sign", np.linalg.norm(residual - reference_residual) < 2e-12)


def supplied_at(lam):
    K = lam * np.ones(3)
    symbol = np.zeros((dim, dim), dtype=complex)
    for p, (sv, cv) in enumerate(fixture):
        sf, cf = np.array(sv, float).ravel(), np.array(cv, float).ravel()
        aa = 2 * np.cos(K / 2) * sf
        dd = 2 * np.sin(K / 2) * cf
        off = 4 * p
        symbol[off, off+1:off+4] = aa
        symbol[off+1:off+4, off] = aa
        symbol[off+1:off+4, off+1:off+4] = farray(ii * cross(sp.Matrix(dd)))
    h = sum((2 * np.cos(K[j] / 2) * van[j] for j in range(3)), np.zeros(dim, complex))
    currents = []
    for a in range(3):
        CURRENT_HPRIME_SIGN = -1
        hp = CURRENT_HPRIME_SIGN * np.sin(K[a] / 2) * van[a]
        diag = np.array([np.sin(K[a]) * (1 - 2 * float(sv[a])**2)
                         for sv, _ in fixture for _spin in range(4)])
        currents.append(Pn @ np.diag(diag) @ Pn - np.outer(hp, h.conj()) - np.outer(h, hp.conj()))
    return Pn @ symbol @ Pn, currents


tau = 0.29
target = expm(-1j * tau * An) @ zn
trans = Fn @ target
trace_target = 1 - 2 * float(np.real(trans.conj() @ farray(E2) @ trans)) / 3
for a in range(3):
    check(f"actual effective cyclic current {a}", abs(np.vdot(target, Jn[a] @ target) - trace_target) < 3e-13)
check("strict effective dressing current response", trace_target < 1 - 1e-4)
rows = []
for lam in [0.04, 0.02, 0.01, 0.005]:
    Hl, Jl = supplied_at(lam)
    b = np.sqrt(3)
    rem = np.linalg.norm((Hl - Hn) / lam - Bn, 2)
    rem_bound = lam * b*b / 4 + lam*lam*b**3 / 24
    check(f"bounded generator expansion lambda={lam}", rem <= rem_bound + 1e-12)
    actual = expm(-1j * tau * Hl / lam) @ zn
    err = np.linalg.norm(actual - target)
    eps = float(np.min(positive) / 2)
    bound = (2 * lam * b + 2 * tau * lam * b*b) / eps + tau * rem_bound
    check(f"finite evolution cutoff bound lambda={lam}", err <= bound + 1e-12)
    current_remainder_bound = lam*lam*((1/6 + np.sqrt(3)/24) + 3/8)
    for a in range(3):
        check(f"actual canonical expansion lambda={lam} axis={a}",
              np.linalg.norm(Jl[a]/lam-farray(Ls[a]), 2) <= current_remainder_bound+1e-12)
    curerr = max(abs(np.vdot(actual, Jl[a] @ actual) / lam - np.vdot(target, Jn[a] @ target)) for a in range(3))
    rows.append({"lambda": lam, "state_error": float(err), "scaled_current_error": float(curerr)})
check("finite evolution tends to effective example", rows[-1]["state_error"] < 0.003)
check("finite canonical current tends to block example", rows[-1]["scaled_current_error"] < 0.003)
print("FLOATING_FINITE_EVOLUTION", json.dumps(rows))

# Actual local cone matrix, rather than assigned oscillation constants.
CONE_STREAMING = 2
M = sp.Matrix([[0, -ii, 0], [ii, 0, CONE_STREAMING], [0, CONE_STREAMING, 0]])
exact("cone matrix cubic polynomial", M**3, 5 * M)
ey = sp.Matrix([1, 0, 0])
at_half_period = (sp.eye(3) - 2 * M**2 / 5) * ey
exact("cone limiting state", at_half_period, sp.Matrix([R(3, 5), 0, -R(4, 5)*ii]))
exact("cone nonuniform squared separation", ((at_half_period-ey).H * (at_half_period-ey))[0], R(4, 5))
actual_cone = expm(-1j * np.pi / np.sqrt(5) * farray(M)) @ np.array([1, 0, 0], complex)
check("actual cone exponential", np.linalg.norm(actual_cone-farray(at_half_period).ravel()) < 1e-14)
eta = R(1, 100)
# pi<4 and 2<sqrt(5)<5/2 give a rational lower margin.
check("cone packet separation rational margin", R(4, 5) - 16*eta > R(1, 2))

# These grid values are floating quadrature illustrations, not error bars for
# the continuum integrals. The analytic integral inequalities are in the note.
qrows = []
for ngrid in [16, 24, 32]:
    axis = -np.pi + (np.arange(ngrid) + 0.5) * (2*np.pi/ngrid)
    q = np.stack(np.meshgrid(axis, axis, axis, indexing="ij"), axis=-1).reshape(-1, 3)
    ss, cc = np.sin(q), np.cos(q)
    ee = np.sum(ss*ss, axis=1)
    Igrid = np.mean(1/(4*ee))
    nn = ss/np.sqrt(ee[:, None])
    numerator = np.sum(cc*cc, axis=1)-np.sum(cc*nn, axis=1)**2
    gamgrid = np.mean(numerator)/(4*Igrid)
    qrows.append({"grid": ngrid, "I0_quadrature": float(Igrid), "gamma2_kappa111_quadrature": float(gamgrid)})
    check(f"quadrature symmetry and analytic bracket n={ngrid}",
          3/(12*Igrid)-1e-12 <= gamgrid <= 3/(8*Igrid)+1e-12)
print("UNVALIDATED_TORUS_QUADRATURE", json.dumps(qrows))
print(json.dumps({"checks": COUNT, "elapsed_seconds": time.monotonic()-START,
                  "scope": "author controls; no independent review or continuum proof by discretization"}))
