#!/usr/bin/env python3
"""Execute bounded source-copy defects against the new author's controls."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
source_path = D / "degenerate_checks.py"
source = source_path.read_text()
mutations = [
    ("derivative_sign", "FIRST_DERIVATIVE_SIGN = 1", "FIRST_DERIVATIVE_SIGN = -1", "Pauli derivative cross sign"),
    ("transverse_projection", "PROJECT_BOTH_SIDES = True", "PROJECT_BOTH_SIDES = False", "transverse projected cross identity"),
    ("full_zero_space", "INCLUDE_DRESSING = True", "INCLUDE_DRESSING = False", "entire physical zero dimension"),
    ("coupling_omission", "KEEP_G = True", "KEEP_G = False", "full effective generator includes g"),
    ("placement_omission", "KEEP_PLACEMENT_CORRECTION = True", "KEEP_PLACEMENT_CORRECTION = False", "canonical block including cross 0"),
    ("corrector_sign", "CORRECTOR_SIGN = -1", "CORRECTOR_SIGN = 1", "cutoff corrector residual sign"),
    ("actual_current_sign", "CURRENT_HPRIME_SIGN = -1", "CURRENT_HPRIME_SIGN = 1", "actual canonical expansion lambda=0.04 axis=0"),
    ("cone_streaming_factor", "CONE_STREAMING = 2", "CONE_STREAMING = 1", "cone matrix cubic polynomial"),
]
records = []
for name, before, after, assertion in mutations:
    if source.count(before) != 1:
        raise AssertionError(f"mutation anchor is not unique: {name}")
    target = D / f"mutant_{name}.py"
    log = D / f"mutant_{name}.log"
    target.write_text(source.replace(before, after, 1))
    command = [sys.executable, str(target)]
    start = time.monotonic()
    run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, timeout=120)
    log.write_text(run.stdout)
    intended = f"AssertionError: {assertion}" in run.stdout
    record = {"name": name, "before": before, "after": after,
              "expected_assertion": assertion, "command": command,
              "timeout_seconds": 120, "exit_code": run.returncode,
              "intended_assertion_reached": intended,
              "elapsed_seconds": time.monotonic() - start,
              "source": target.name, "source_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
              "log": log.name, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
    records.append(record)
    print(json.dumps(record), flush=True)
    if run.returncode != 1 or not intended:
        raise AssertionError(f"unexpected mutation outcome: {name}")
(D / "mutation_manifest.json").write_text(json.dumps({
    "baseline_source": source_path.name,
    "baseline_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
    "scope": "actual source-copy executions; author controls, not independent scientific review",
    "mutations": records}, indent=2) + "\n")
