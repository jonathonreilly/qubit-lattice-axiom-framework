#!/usr/bin/env python3
"""Independent finite controls for the frozen degenerate walk probe.

No author code imports or torus quadrature. Exact tests use a different
three-pair cyclic rational fixture, an unrelated signed-spectrum cutoff
matrix, and a different perfect-transfer cone. None proves a continuum
limit by finite approximation. Intended process timeout: 120 seconds.
"""
import json
import platform
import time

import numpy as np
import scipy
from scipy.linalg import expm
import sympy as sy

START = time.monotonic()
R = sy.Rational
I = sy.I


def equal(name, lhs, rhs):
    delta = lhs-rhs
    vals = list(delta) if isinstance(delta, sy.MatrixBase) else [delta]
    assert all(sy.simplify(x) == 0 for x in vals), name
    print("EXACT", name, flush=True)


def arr(x):
    return np.array(x.evalf(17).tolist(), complex)


def cross(x):
    return sy.Matrix([[0, -x[2], x[1]], [x[2], 0, -x[0]], [-x[1], x[0], 0]])


def quadratic(x, op):
    return sy.simplify((x.H*op*x)[0])


print(json.dumps({"python": platform.python_version(), "numpy": np.__version__,
                  "scipy": scipy.__version__, "sympy": sy.__version__,
                  "scope": "independent finite controls; literal inputs; no author imports"}))

# Rebuild the spin symbols directly, including the convention for T_j.
sx = sy.Matrix([[0, 1], [1, 0]])
sz = sy.diag(1, -1)
sy_ = -I*sz*sx
pauli = [sx, sy_, sz]
cspin = sy.Matrix([0, 1, -1, 0])/sy.sqrt(2)
left = [sy.kronecker_product(x, sy.eye(2)) for x in pauli]
right = [sy.kronecker_product(sy.eye(2), x) for x in pauli]
ST = sy.Matrix.hstack(cspin, *(x*cspin for x in left))
sv = sy.Matrix(sy.symbols("s0:3", real=True))
dv = sy.Matrix(sy.symbols("d0:3", real=True))
actual = sum((sv[j]*(left[j]-right[j]) +
              dv[j]*(left[j]+right[j])/2 for j in range(3)), sy.zeros(4))
expected = sy.zeros(4)
expected[0, 1:4] = 2*sv.T
expected[1:4, 0] = 2*sv
expected[1:4, 1:4] = I*cross(dv)
equal("full linearized Pauli symbol", ST.H*actual*ST, expected)
Q = sy.eye(3)-sv*sv.T/sv.dot(sv)
equal("tangent compression from cross algebra", Q*cross(dv)*Q,
      dv.dot(sv)*cross(sv)/sv.dot(sv))

# This is an exact finite algebra fixture, not torus quadrature. All three
# radii are one, giving a closed three-dimensional cyclic orbit from zeta.
base_s = [R(7, 25), R(24, 25), R(0)]
base_c = [R(24, 25), R(7, 25), R(1)]
fixture = [(sy.Matrix(base_s[j:]+base_s[:j]),
            sy.Matrix(base_c[j:]+base_c[:j])) for j in range(3)]
N = 12
c = sy.zeros(N, 1)
zeta = sy.zeros(N, 1)
v = sy.zeros(N, 1)
va = [sy.zeros(N, 1) for _ in range(3)]
H0 = sy.zeros(N)
F = sy.zeros(N)
B = sy.zeros(N)
for a, (ss, cc) in enumerate(fixture):
    equal(f"rational sin cos pair {a}", ss.multiply_elementwise(ss)+cc.multiply_elementwise(cc), sy.ones(3, 1))
    equal(f"unit radius {a}", ss.dot(ss), 1)
    k = 4*a
    c[k] = 1/sy.sqrt(3)
    zeta[k+1:k+4, 0] = ss/sy.sqrt(3)
    v[k+1:k+4, 0] = ss/sy.sqrt(3)
    H0[k, k+1:k+4] = 2*ss.T
    H0[k+1:k+4, k] = 2*ss
    F[k+1:k+4, k+1:k+4] = sy.eye(3)-ss*ss.T
    B[k+1:k+4, k+1:k+4] = I*cross(cc)
    for j in range(3):
        va[j][k+1+j] = ss[j]/sy.sqrt(3)
P = sy.eye(N)-c*c.H
H = P*H0*P
Pi = F+zeta*zeta.H
equal("normalized physical dressing", quadratic(zeta, sy.eye(N)), 1)
equal("entire zero projection idempotent", Pi*Pi, Pi)
equal("zero projection physical", Pi*c, sy.zeros(N, 1))
equal("zero projection annihilated", H*Pi, sy.zeros(N))
assert H.rank() == 4 and Pi.rank() == 7
equal("auxiliary zero separated", N-H.rank(), Pi.rank()+1)
A = Pi*B*Pi
g = B*zeta
equal("dressing derivative is transverse", F*g, g)
equal("both effective off-diagonal blocks", A, F*B*F+g*zeta.H+zeta*g.H)
Ls = []
for j in range(3):
    mult = sy.diag(*[1-2*ss[j]**2 for ss, _ in fixture for _spin in range(4)])
    La = P*mult*P+va[j]*v.H+v*va[j].H
    r = F*va[j]  # 1/(2 sqrt(I0))=1 in this fixture.
    equal(f"full canonical block {j}", Pi*La*Pi,
          F*mult*F+r*zeta.H+zeta*r.H+zeta*zeta.H)
    equal(f"initial placement cancellation {j}", quadratic(zeta, La), 1)
    assert quadratic(zeta, P*mult*P) != 1
    Ls.append(La)
equal("zero-space trace uses transverse population", sum((Pi*x*Pi for x in Ls), sy.zeros(N)), 3*Pi-2*F)
tangent_frequency = R(336, 625)
gamma2 = sy.simplify((g.H*g)[0])
equal("closed-orbit coupling weight", gamma2, 2-tangent_frequency**2)
equal("closed-orbit cubic relation", A**3*zeta, 2*A*zeta)

# Exact exponential on the dressing cyclic subspace at tau=pi/(2 sqrt(2)).
target = zeta-I*g/sy.sqrt(2)-A*A*zeta/2
alpha = 1-gamma2/2
equal("closed-orbit exponential normalized", quadratic(target, sy.eye(N)), 1)
equal("closed-orbit dressing amplitude", (zeta.H*target)[0], alpha)
current = 1-R(2, 3)*(1-alpha**2)
for j in range(3):
    equal(f"exact evolved current {j}", quadratic(target, Ls[j]), current)
    comm = A*Ls[j]-Ls[j]*A
    equal(f"exact first current derivative {j}", quadratic(zeta, I*comm), 0)
    equal(f"exact second current derivative {j}", -quadratic(zeta, A*comm-comm*A), -4*gamma2/3)
print("DISTINCT_CYCLIC_FIXTURE", json.dumps({"pairs": 3, "dimension": N,
      "physical_zero_dimension": 7, "I0": "1/4", "gamma_squared": str(gamma2),
      "current_at_pi_over_2sqrt2": str(current), "torus_integral_values": False}))
assert np.linalg.norm(expm(-1j*np.pi/(2*np.sqrt(2))*arr(A))@arr(zeta)-arr(target)) < 3e-14

# A signed-spectrum matrix with a nontrivial low spectral subspace tests
# the cutoff identity independently of the walk fixture and its gap.
Hs = sy.diag(0, 0, R(1, 29), -R(1, 17), R(2, 3), -R(7, 5))
Pis = sy.diag(1, 1, 0, 0, 0, 0)
Es = sy.diag(0, 0, 1, 1, 0, 0)
Qs = sy.diag(0, 0, 0, 0, 1, 1)
inv = sy.diag(0, 0, 0, 0, R(3, 2), -R(5, 7))
Bs = sy.Matrix([[R(1, 7), I/3, R(1, 5), 0, I/7, R(1, 2)],
                [-I/3, -R(2, 9), I/4, R(2, 7), 0, I/5],
                [R(1, 5), -I/4, R(3, 11), I/8, R(1, 3), 0],
                [0, R(2, 7), -I/8, -R(4, 13), 0, R(1, 6)],
                [-I/7, 0, R(1, 3), 0, R(5, 17), I/9],
                [R(1, 2), -I/5, 0, R(1, 6), -I/9, -R(6, 19)]])
As = Pis*Bs*Pis
equal("signed cutoff matrix Hermitian", Bs.H, Bs)
lam = sy.Symbol("lam", real=True, positive=True)
vp = -I*As*Pis
y = -inv*Bs*Pis
yp = -inv*Bs*vp
residual = I*(vp+lam*yp)-(Hs/lam+Bs)*(Pis+lam*y)
reference = -Es*Bs*Pis+lam*(I*yp-Bs*y)
equal("nontrivial cutoff residual for every kernel vector", residual, reference)
assert Es*Bs*Pis != sy.zeros(6)
assert y != sy.zeros(6)
wrong_y = -y
wrong_yp = -yp
wrong = I*(vp+lam*wrong_yp)-(Hs/lam+Bs)*(Pis+lam*wrong_y)
assert wrong-(-Es*Bs*Pis+lam*(I*wrong_yp-Bs*wrong_y)) != sy.zeros(6)
print("DISCRIMINATOR positive corrector sign leaves nonzero leading high-spectrum residual")
bound_b = max(sum(abs(x) for x in Bs.row(j)) for j in range(6))
Mz_upper = sy.sqrt(sum(abs(x)**2 for x in Es*Bs*Pis))
z = sy.Matrix([1, I, 0, 0, 0, 0])/sy.sqrt(2)
rows = []
for lv in [0.08, 0.02, 0.004]:
    for tau in [-0.8, 0.25, 0.8]:
        err = float(np.linalg.norm(expm(-1j*tau*(arr(Hs)/lv+arr(Bs)))@arr(z)-expm(-1j*tau*arr(As))@arr(z)))
        bound = float((2*lv*bound_b+2*abs(tau)*lv*bound_b**2)/R(1, 10)+abs(tau)*Mz_upper)
        assert err <= bound+1e-13
        rows.append({"lambda": lv, "tau": tau, "state_error": err, "D11_upper": bound})
print("SIGNED_CUTOFF_FINITE_EVOLUTION", json.dumps(rows))

# Independent cone: kappa=e3, p=(1/2)e1, initial T2. It has perfect
# singlet transfer at pi/sqrt(2), stronger than needed for the author's
# separate e1/e3 example. Build it from the actual four-spin symbol.
ps = sy.Matrix([R(1, 2), 0, 0])
ks = sy.Matrix([0, 0, 1])
raw_cone = sum((ps[j]*(left[j]-right[j])+ks[j]*(left[j]+right[j])/2
                for j in range(3)), sy.zeros(4))
cone = sy.simplify(ST.H*raw_cone*ST)
eT2 = sy.Matrix([0, 0, 1, 0])
eC = sy.Matrix([1, 0, 0, 0])
equal("perfect-transfer cone cubic", cone**3, 2*cone)
transfer = (sy.eye(4)-cone**2)*eT2
equal("perfect transfer from actual Pauli matrix", transfer, I*eC)
equal("perfect-transfer squared state separation", ((transfer-eT2).H*(transfer-eT2))[0], 2)
assert np.linalg.norm(expm(-1j*np.pi/np.sqrt(2)*arr(cone))@arr(eT2)-arr(transfer)) < 2e-14

# Explicit packet and constant arithmetic; these are algebra checks of
# the already separately derived inequalities, not a continuum proof.
eps = sy.Symbol("eps", positive=True)
mu = eps**6/(3*sy.pi**2)  # paired q balls of radius lambda^2.
equal("narrow cone contact factor order", sy.sqrt(mu)/eps, eps**2/(sy.sqrt(3)*sy.pi))
equal("global direct-integral normalization", eps**3*(eps**(-R(3, 2)))**2, 1)
tau0 = R(1, 20)
equal("diagonal current drift lower bound", tau0**2*3/81, R(1, 10800))
C0 = 2+sy.sqrt(3)+(1+sy.sqrt(3))/10
rho = 1/(21600*C0)
equal("packet Lipschitz loss", C0*rho, R(1, 21600))
equal("packet surviving signed drift", -R(1, 10800)+C0*rho, -R(1, 21600))
assert tau0**2 <= R(2, 243)
eta = R(1, 100)
assert R(4, 5)-16*eta > R(1, 2)
print(json.dumps({"elapsed_seconds": time.monotonic()-START,
                  "limitations": "finite matrices do not prove gapless convergence, torus integrals, or continuum packet limits"}))
