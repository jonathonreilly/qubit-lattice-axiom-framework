"""Author finite controls of the zero-mode/leakage proof, not continuum numerics.

Inputs are literal exact fields below. Each process has a 90-second harness
timeout. No repository or earlier author runner is imported.
"""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
import sympy as s

CHECK_TIMEOUT_SECONDS=90
checks=0
def check(value,label):
    global checks
    assert bool(value),label
    checks+=1
def zm(M):return all(s.simplify(x)==0 for x in M)
def norm2(x):return s.simplify((x.H*x)[0])

# Actual singlet/Pauli matrices, before using a scalar radial representation.
pauli=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
singlet=s.Matrix([0,1,-1,0])/s.sqrt(2)
triplet=[s.kronecker_product(p,s.eye(2))*singlet for p in pauli]
coin_basis=s.Matrix.hstack(singlet,*triplet)
check(zm(coin_basis.H*coin_basis-s.eye(4)),'orthonormal actual singlet/triplet basis')
sx=s.symbols('s0:3',real=True)
spinH=sum((sx[j]*(s.kronecker_product(pauli[j],s.eye(2))-s.kronecker_product(s.eye(2),pauli[j])) for j in range(3)),s.zeros(4))
cart=s.zeros(4)
for j in range(3):cart[0,j+1]=cart[j+1,0]=2*sx[j]
check(zm(coin_basis.H*spinH*coin_basis-cart),'exact zero-K longitudinal block')

# Nine antipodal pairs, represented with even singlet/odd triplet parity.
# This rational cubically symmetric measure tests algebra; it is NOT torus
# quadrature or an approximation used to claim the continuum scaling.
radii=[s.Rational(1,8),s.Rational(1,3),s.Rational(2,3)]
nodes=[(r,j) for r in radii for j in range(3)]
N=len(nodes);dim=4*N
H0=s.zeros(dim);R=s.zeros(dim);eps2=s.zeros(dim)
c=s.zeros(dim,1);inverse_c=s.zeros(dim,1)
v=s.zeros(dim,1);va=[s.zeros(dim,1) for _ in range(3)]
for p,(r,j) in enumerate(nodes):
    at=4*p;c[at]=s.Rational(1,3)
    H0[at,at+j+1]=H0[at+j+1,at]=2*r
    R[at,at]=R[at+j+1,at+j+1]=1
    inverse_c[at+j+1]=c[at]/(2*r)
    v[at+j+1]=r/3;va[j][at+j+1]=r/3
    for k in range(4):eps2[at+k,at+k]=r*r
I0=sum(1/(4*r*r) for r,j in nodes)
zeta=inverse_c/s.sqrt(I0)
C=c*c.H;P=s.eye(dim)-C
H=P*H0*P
check(norm2(c)==1,'normalized finite contact measure')
check(zm(H0*inverse_c-c),'reduced inverse contact coefficient')
check(norm2(inverse_c)==I0 and norm2(zeta)==1,'inverse norm uses averaged measure')
check((c.H*zeta)[0]==0 and zm((s.eye(dim)-R)*zeta),'physical and free-flat orthogonality')
check(zm(H*zeta),'actual compression has extra zero vector')
check(H0.rank()==2*N and H.rank()==2*N-2,'actual kernel dimension increase beyond the flat band')
physical_kernel=s.eye(dim)-R+zeta*zeta.H
check(zm(physical_kernel*c),'auxiliary contact zero mode excluded from physical kernel')
check(zm(H*physical_kernel) and zm(physical_kernel**2-physical_kernel),'physical zero-space projector')
check(s.trace(physical_kernel)==2*N+1,'free-flat plus one physical zero dimension')

# Exact free spectral projection onto the high radial value, so the cutoff
# below genuinely lies below the initial band. No asymptotic claim uses this
# discrete fixture's radial values or zero spectral gap.
Gamma=s.zeros(dim)
for p,(r,j) in enumerate(nodes):
    if r==radii[-1]:
        e=s.zeros(dim,1);e[4*p]=e[4*p+j+1]=1/s.sqrt(2)
        Gamma+=e*e.H
check(zm(Gamma**2-Gamma) and zm(H0*Gamma-s.Rational(4,3)*Gamma),'actual positive-band projector')
w=norm2(Gamma*zeta);phi=Gamma*zeta/s.sqrt(w)
beta=s.simplify((c.H*phi)[0]);normal=s.sqrt(1-beta**2)
chi=P*phi/normal;A=s.sqrt(w)/normal
check(norm2(chi)==1 and (c.H*chi)[0]==0,'normalized immediate contact projection')
check(s.simplify((zeta.H*chi)[0]-A)==0,'retained threshold amplitude after projection')
check(zm(physical_kernel*chi-A*zeta),'complete physical zero projection of prepared band state')

# Cutoff inverse: compare an actual H application with the claimed residual.
cut=s.Rational(1,4)
F=[];G=[];formal=[]
for p,(r,j) in enumerate(nodes):
    F.append(s.simplify(chi[4*p]/c[4*p]))
    G.append(s.simplify(chi[4*p+j+1]/c[4*p]))
    formal.append(s.simplify(G[-1]/(2*r)-A/(4*s.sqrt(I0)*r*r)))
check(s.simplify(sum(formal)/N)==0,'formal inverse has zero integrable mean')
mean_cut=s.simplify(sum(f for f,(r,j) in zip(formal,nodes) if r>=cut)/N)
xi=s.zeros(dim,1);residual=s.zeros(dim,1)
for p,((r,j),f) in enumerate(zip(nodes,formal)):
    f_cut=(f if r>=cut else 0)-mean_cut
    xi[4*p]=c[4*p]*f_cut
    xi[4*p+j+1]=c[4*p]*F[p]/(2*r)
    residual[4*p+j+1]=c[4*p]*((A/(2*s.sqrt(I0)*r) if r<cut else 0)-2*r*mean_cut)
check(s.simplify((c.H*xi)[0])==0,'cutoff inverse restores the excluded singlet mean')
check(zm(H*xi-(chi-A*zeta)-residual),'cutoff inverse actual residual identity')

# Actual canonical-current coefficient and its cancellation, with no assigned
# expectation values replacing matrices. Coordinate points are cubic symmetric.
L=[]
for a in range(3):
    free=s.eye(dim)
    for p,(r,j) in enumerate(nodes):
        if a==j:
            for k in range(4):free[4*p+k,4*p+k]-=2*r*r
    correction=va[a]*v.H+v*va[a].H
    current=P*free*P+correction
    L.append(current)
    free_centered=s.simplify((zeta.H*(free-s.eye(dim))*zeta)[0])
    contact=s.simplify((zeta.H*correction*zeta)[0])
    check(s.simplify(free_centered+1/(6*I0))==0,'free threshold current deviation coefficient')
    check(s.simplify(contact-1/(6*I0))==0,'canonical correction cancels threshold deviation')
    check(s.simplify((zeta.H*current*zeta)[0]-1)==0,'canonical centered threshold current is zero')
sum_center=sum(L,s.zeros(dim))-3*P
check(zm(P*R*sum_center*R*P+H**2/2),'conserved canonical trace from squared compression')

# Floating actual finite-time averaging via spectral decomposition. This
# checks the averaging/cutoff identity, not a continuum time-evolution proof.
Hn=np.array(H,dtype=complex);xin=np.array(xi,dtype=complex).ravel()
chin=np.array(chi,dtype=complex).ravel();zn=np.array(zeta,dtype=complex).ravel()
rn=np.array(residual,dtype=complex).ravel();An=float(A)
ev,U=np.linalg.eigh(Hn)
floating=[]
for time in [3.4,20.0,50.0]:
    multiplier=np.exp(-1j*ev*time/2)*np.sinc(ev*time/(2*np.pi))
    mean=U@(multiplier*(U.conj().T@chin))
    actual=float(np.linalg.norm(mean-An*zn))
    bound=2*np.linalg.norm(xin)/time+np.linalg.norm(rn)
    check(actual<=bound+1e-12,'actual finite-time averaging residual bound')
    lhs=U@(multiplier*(U.conj().T@(Hn@xin)))
    rhs=1j*(U@(np.exp(-1j*ev*time)*(U.conj().T@xin))-xin)/time
    check(np.linalg.norm(lhs-rhs)<1e-12,'averaging identity sign from actual unitary')
    floating.append({'T':time,'actual_mean_error':actual,'cutoff_bound':float(bound)})

# Rational certificate for the deliberately conservative lambda<=10^-12
# range in L22. sqrt(12)<4, pi<4, sqrt(23)>4; exponents are bounded at
# the largest lambda, so no floating log-power comparison proves the range.
error_bound=s.Rational(42,5000)+s.Rational(24,10**10)+s.Rational(32,10**12)+s.Rational(4,10**15)
check(error_bound<s.Rational(9,1000)<s.Rational(1,108),'exact finite leakage range certificate')
check(s.Rational(23,324)*s.Rational(1,9)/4==s.Rational(23,11664),'leakage lower coefficient with pi squared separate')

print('Exact finite field: pairs =',N,'I0 =',I0,'free kernel =',dim-H0.rank(),'physical compressed kernel =',s.trace(physical_kernel))
print('Exact packet: band weight =',w,'contact loss =',s.simplify(beta**2),'physical zero weight =',s.simplify(A**2))
print('Canonical coefficients: free =',-1/(6*I0),'correction =',1/(6*I0))
print('Floating averaging controls:',json.dumps(floating,sort_keys=True))
print('Conservative range certificate:',error_bound,'< 9/1000 < 1/108')
print('Scope: exact finite operator/field algebra and floating averaging controls; no finite-grid inference of continuum threshold density, isolated zero mode, or current relaxation.')
print('TOTAL: PASS='+str(checks)+' FAIL=0')
print('Source SHA256:',sha256(Path(__file__).read_bytes()).hexdigest())
