"""Execute finite author controls and actual source-copy mutants, 90 s each."""
from pathlib import Path
from hashlib import sha256
import subprocess,sys,json,time
d=Path(__file__).resolve().parent
source=d/'long_time_checks.py';body=source.read_text()
changes=[
 ('inverse_factor','inverse_c[at+j+1]=c[at]/(2*r)','inverse_c[at+j+1]=c[at]/r','reduced inverse contact coefficient'),
 ('measure_normalization','I0=sum(1/(4*r*r) for r,j in nodes)/N','I0=sum(1/(4*r*r) for r,j in nodes)','inverse norm uses averaged measure'),
 ('missing_compression','H=P*H0*P','H=H0','actual compression has extra zero vector'),
 ('auxiliary_state','physical_kernel=s.eye(dim)-R+zeta*zeta.H','physical_kernel=s.eye(dim)-R+zeta*zeta.H+C','auxiliary contact zero mode excluded from physical kernel'),
 ('cutoff_mean','f_cut=(f if r>=cut else 0)-mean_cut','f_cut=(f if r>=cut else 0)+mean_cut','cutoff inverse restores the excluded singlet mean'),
 ('missing_current_correction','correction=va[a]*v.H+v*va[a].H','correction=s.zeros(dim)','canonical correction cancels threshold deviation'),
]
rows=[]
def run(path,name,expected=None):
 log=d/(name+'.log');start=time.monotonic()
 with log.open('w') as f:proc=subprocess.run([sys.executable,str(path)],stdout=f,stderr=subprocess.STDOUT,timeout=90)
 output=log.read_text()
 correct=proc.returncode==0 if expected is None else proc.returncode==1 and 'AssertionError:' in output and expected in output
 row={'name':name,'source':path.name,'sha256':sha256(path.read_bytes()).hexdigest(),'command':[sys.executable,str(path)],'exit_code':proc.returncode,'expected_assertion':expected,'intended_result':correct,'seconds':time.monotonic()-start,'log':log.name}
 rows.append(row);print(json.dumps(row),flush=True)
 assert correct,row
run(source,'baseline')
for name,before,after,expected in changes:
 assert body.count(before)==1,(name,body.count(before))
 path=d/('mutant_'+name+'.py');path.write_text(body.replace(before,after,1));run(path,name,expected)
(d/'control_manifest.json').write_text(json.dumps({'baseline_sha256':sha256(source.read_bytes()).hexdigest(),'mutations':[{'name':n,'before':b,'after':a,'expected':e} for n,b,a,e in changes],'executions':rows},indent=2)+'\n')
print('Baseline and six actual source mutants completed.')
