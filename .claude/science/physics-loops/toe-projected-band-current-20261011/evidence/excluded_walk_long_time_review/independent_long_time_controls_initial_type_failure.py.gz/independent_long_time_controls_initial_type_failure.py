#!/usr/bin/env python3
"""Independent finite controls; no author or repository science imports.

Four non-cubic antipodal momentum pairs discriminate the physical/auxiliary
zero spaces and cutoff inverse. This is finite algebra, not torus quadrature
or a numerical proof of continuum leakage. Analytic constants are checked
separately by exact rational arithmetic. No random inputs.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from time import perf_counter
import sys
import sympy as s
import numpy as np

started=perf_counter()
source=Path(__file__).read_bytes()
qvec=[s.Matrix([s.Rational(1,100),0,0]),
      s.Matrix([s.Rational(3,100),s.Rational(1,25),0]),
      s.Matrix([0,0,s.Rational(1,4)]),
      s.Matrix([s.Rational(1,2),s.Rational(1,4),s.Rational(1,2)])]
N=len(qvec);size=4*N
eps=[s.sqrt(v.dot(v)) for v in qvec]
assert eps==[s.Rational(1,100),s.Rational(1,20),s.Rational(1,4),s.Rational(3,4)]
H=s.zeros(size)
c=s.zeros(size,1)
flat=s.zeros(size)
for j,v in enumerate(qvec):
    c[4*j]=s.Rational(1,2)
    for a in range(3):
        H[4*j,4*j+1+a]=2*v[a]
        H[4*j+1+a,4*j]=2*v[a]
    transverse=s.eye(3)-v*v.T/eps[j]**2
    for a in range(3):
        for b in range(3):flat[4*j+1+a,4*j+1+b]=transverse[a,b]
C=c*c.T;P=s.eye(size)-C;HD=P*H*P
raw=s.zeros(size,1)
for j,v in enumerate(qvec):
    for a in range(3):raw[4*j+1+a]=v[a]/(4*eps[j]**2)
I0=s.factor(raw.dot(raw));zeta=raw/s.sqrt(I0)
assert I0==s.Rational(5860,9)
assert H*raw==c and HD*raw==s.zeros(size,1) and c.dot(raw)==0
assert H.rank()==8 and HD.rank()==6 and (HD+C).rank()==7
Ezero=flat+zeta*zeta.T
assert s.simplify(Ezero*Ezero-Ezero)==s.zeros(size)
assert Ezero*c==s.zeros(size,1) and Ezero*HD==s.zeros(size)
assert Ezero.rank()==9 and flat.rank()==8
print('Exact non-cubic four-pair fixture: I0=',I0,
      '; free kernel 8, physical compressed kernel 9, full extended kernel 10.')
print('Physical zero projector equals free transverse projector plus |zeta><zeta|; auxiliary c is excluded.')

# An actual normalized positive free eigenvector on the second momentum pair.
phi=s.zeros(size,1);phi[4]=1/s.sqrt(2)
for a in range(3):phi[5+a]=(qvec[1][a]/eps[1])/s.sqrt(2)
assert H*phi==s.Rational(1,10)*phi and phi.dot(phi)==1
beta=s.simplify(c.dot(phi));normal=s.sqrt(1-beta**2)
chi=P*phi/normal;A=s.simplify(zeta.dot(chi))
assert s.simplify(chi.dot(chi))==1 and c.dot(chi)==0
assert s.simplify(Ezero*chi-A*zeta)==s.zeros(size,1)
assert s.simplify((chi-phi).dot(chi-phi)-2*(1-normal))==0

# Build the cutoff inverse from the function coefficients, in the normalized
# four-point measure. The cutoff must have its mean subtracted globally.
Fcoef=[s.simplify(2*chi[4*j]) for j in range(N)]
Gcoef=[s.simplify(2*(qvec[j]/eps[j]).dot(chi[4*j+1:4*j+4,0])) for j in range(N)]
f=[s.simplify(Gcoef[j]/(2*eps[j])-A/(4*s.sqrt(I0)*eps[j]**2)) for j in range(N)]
g=[s.simplify(Fcoef[j]/(2*eps[j])) for j in range(N)]
assert s.simplify(sum(f)/N)==0
cut=s.Rational(1,40)
outside=[int(e>=cut) for e in eps]
mean=s.simplify(sum(outside[j]*f[j] for j in range(N))/N)
expected_mean=s.simplify(A/(4*s.sqrt(I0))*sum((1-outside[j])/eps[j]**2 for j in range(N))/N)
assert mean==expected_mean and mean!=0
xi=s.zeros(size,1);predicted=s.zeros(size,1)
for j in range(N):
    xi[4*j]=(outside[j]*f[j]-mean)/2
    residual_scalar=A*(1-outside[j])/(2*s.sqrt(I0)*eps[j])-2*eps[j]*mean
    for a in range(3):
        xi[4*j+1+a]=g[j]*(qvec[j][a]/eps[j])/2
        predicted[4*j+1+a]=residual_scalar*(qvec[j][a]/eps[j])/2
assert c.dot(xi)==0
residual=s.simplify(HD*xi-(chi-A*zeta))
assert residual==s.simplify(predicted)
uncentered=xi+mean*c
assert c.dot(uncentered)==mean
assert s.simplify(HD*uncentered-(chi-A*zeta)-predicted)==s.zeros(size,1)
print('Exact cutoff inverse: residual is the low-epsilon tail minus 2 epsilon times its subtracted mean.')
print('Omitting that mean leaves the proposed inverse outside P; actual mean=',mean)

# Canonical correction and the trace identity at arbitrary discrete momenta.
h=H*c;v=h/2;L=[]
R=s.eye(size)-flat
for a in range(3):
    va=s.zeros(size,1)
    cosine=s.zeros(size)
    for j in range(N):
        va[4*j+1+a]=qvec[j][a]/2
        for b in range(4):cosine[4*j+b,4*j+b]=1-2*qvec[j][a]**2
    correction=va*v.T+v*va.T
    La=P*cosine*P+correction
    L.append(La)
    free=s.factor((zeta.T*(P*cosine*P-s.eye(size))*zeta)[0])
    added=s.factor((zeta.T*correction*zeta)[0])
    assert free!=0 and free+added==0
    print('Exact axis',a,'free centered zeta coefficient=',free,'canonical correction=',added)
assert s.simplify(P*R*(sum(L,s.zeros(size))-3*s.eye(size))*R*P+HD*HD/2)==s.zeros(size)
print('Exact compressed cubic trace identity holds without assuming a gap.')

# Check the spectral averaging identity and Jensen inequality on actual
# finite matrices. This does not use the continuum cutoff norm constants.
def numeric(M):return np.array(M.evalf(18),dtype=complex)
Hn=numeric(HD);chin=numeric(chi).ravel();zn=numeric(zeta).ravel();xin=numeric(xi).ravel()
An=float(A);rn=numeric(residual).ravel()
values,U=np.linalg.eigh(Hn)
def mean_phase(values,T):
    out=np.ones_like(values,dtype=complex)
    mask=np.abs(values)>1e-12
    out[mask]=np.expm1(-1j*T*values[mask])/(-1j*T*values[mask])
    return out
Q=np.zeros((size,size),complex)
for j,energy in enumerate(eps):
    if energy>=s.Rational(1,2):Q[4*j:4*j+4,4*j:4*j+4]=np.eye(4)
coef=U.conj().T@chin;Qe=U.conj().T@Q@U
for T in (7/3,19.,101.):
    MT=(U*mean_phase(values,T)[None,:])@U.conj().T
    UT=(U*np.exp(-1j*T*values)[None,:])@U.conj().T
    lhs=MT@Hn@xin;rhs=1j*(UT-np.eye(size))@xin/T
    assert np.linalg.norm(lhs-rhs)<2e-12
    error=np.linalg.norm(MT@chin-An*zn)
    bound=2*np.linalg.norm(xin)/T+np.linalg.norm(rn)
    assert error<=bound+1e-12
    phase=mean_phase(values[None,:]-values[:,None],T)
    averaged=(np.conj(coef)[:,None]*coef[None,:]*Qe*phase).sum().real
    jensen=np.linalg.norm(Q@MT@chin)**2
    assert averaged+1e-12>=jensen
    total=numeric(sum(L,s.zeros(size))-3*s.eye(size))
    evolved=UT@chin
    invariant=np.vdot(evolved,total@evolved).real
    target=-np.linalg.norm(Hn@chin)**2/2
    assert abs(invariant-target)<1e-12
    print('Finite spectral average T=',T,'state error=',format(error,'.10g'),
          'constructive bound=',format(bound,'.10g'),'high-weight average=',format(averaged,'.10g'),
          'Jensen lower quantity=',format(jensen,'.10g'))

# All numerical constants used in the small-lambda conclusion, independently
# assembled from the two cone-measure bounds and the stated norm inequalities.
assert F(1,4)*F(23,24)*F(1,3)/F(9,8)==F(23,324)
assert F(4)*2/F(5,4)+2==F(42,5)
assert 16*2==32
certificate=F(42,5000)+F(24,10**10)+F(32,10**12)+F(4,10**15)
assert certificate<F(9,1000)<F(1,108)
assert F(23,1)/(108**2)==F(23,11664)
ll=F(1,10**12)
assert 2*F(1,10**30)<=ll/16
assert F(10**21)>=2/(F(5,4)*ll)
assert (ll**3/3)/(1-ll**3/3)<=ll**3
print('Exact L22 rational certificate:',certificate,'<9/1000<1/108; coefficient 23/11664 before pi^-2.')
print('K support, averaging-time cutoff requirement, and initial high-weight bound verified at the explicit maximal lambda.')

# Direct leading-band integrals also check the nontrivial beta coefficient.
energy,llsym,I=s.symbols('energy llsym I',positive=True)
w=s.integrate(1/(4*s.pi**2*I),(energy,s.Rational(5,4)*llsym,s.Rational(7,4)*llsym))
bnum=s.integrate(energy/(4*s.pi**2),(energy,s.Rational(5,4)*llsym,s.Rational(7,4)*llsym))
assert s.simplify(w-llsym/(8*s.pi**2*I))==0
assert s.simplify(bnum**2/(I*w)-9*llsym**3/(32*s.pi**2))==0
print('Exact leading spectral integrals recover w=lambda/(8*pi^2*I0) and beta^2=9lambda^3/(32*pi^2).')
assert source==Path(__file__).read_bytes()
print('Finite controls only: no continuum time evolution, gap, K!=0 eigenstate, or current counterexample asserted.')
print('python='+sys.version.split()[0]+'; sympy='+s.__version__+'; numpy='+np.__version__)
print('runtime_seconds=%.6f'%(perf_counter()-started))
print('script_sha256='+sha256(source).hexdigest())
