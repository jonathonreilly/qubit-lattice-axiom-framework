# Independent effective-memory reconstruction before reading the new draft

2026-10-11. Input: the unchanged full effective-generator source
`EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md`, SHA-256
`b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`,
and the previous complete independent review, SHA-256
`c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2`.
No content from `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` has been read.
This is an independent argument record, not yet a source-bound review of
that forthcoming draft. All integrals below use normalized torus measure.

## 1. Scalar resolvent and memory equation

Let `b=|kappa|>0`, `d_j=kappa_j cos q_j`, `epsilon=|sin q|`,
`n=sin q/epsilon`, `omega=d dot n`, and

    D=i omega n cross on the transverse plane,
    g=i(d cross n)/(2epsilon sqrt(I0)),
    A=[[D,g],[<g|,0]], w(q)=|g(q)|^2.

The source proves `A=Pi B Pi`, `||A||<=b`, and `g in L2`.
On the transverse plane, `D^2=omega^2 I`. Since g is i times a real
transverse vector, `<g,Dg>` vanishes pointwise. Consequently the D-spectral
measure of g is

    nu(S)=integral (w/2)[1_S(omega)+1_S(-omega)],

and, for nonreal z,

    Sigma(z)=<g,(z-D)^-1 g>
            =integral w z/(z^2-omega^2),
    R(z)=<zeta,(z-A)^-1 zeta>=1/[z-Sigma(z)].

There is no extra factor two in Sigma. With this resolvent convention,
`Im R(z)<0` for `Im z>0`. The source's Hilbert-space convention is linear
in the second argument; the displayed formulas respect it.

For `exp(-itA)zeta=(u(t),a(t))`, variation of constants gives, for t>=0,

    u(t)=-i integral_0^t exp[-i(t-s)D]g a(s) ds,
    a'(t)=-integral_0^t K(t-s)a(s) ds, a(0)=1,
    K(t)=<g,exp(-itD)g>=integral w cos(t omega).

Thus, for Re p>0,

    Laplace[a](p)=1/[p+Laplace[K](p)],
    Laplace[K](p)=integral w p/(p^2+omega^2).

Both a and K are real and even. For a this follows from the real Volterra
equation and uniqueness on positive time, and `a(-t)=conjugate(a(t))`.
In particular `a'(0)=0`, `a''(0)=-||g||^2<0`. A negative initial second
derivative alone does not prove long-time decay or monotonicity.

## 2. Absolute continuity and interior positivity of the bath measure

Away from the eight zeroes of epsilon, omega is real analytic on the
connected punctured torus. It is not constant: if kappa_j!=0, along
`q=t e_j`, `0<t<pi`, it equals `kappa_j cos t`. Hence at least one partial
derivative is a nonzero real-analytic function. Its zero set has Lebesgue
measure zero, so the full critical set has measure zero.

Coarea, or local inverse-coordinate charts on the noncritical set, then
implies that the pushforward of `w dq` by omega is absolutely continuous.
Here w is integrable, and no bound on it at the cones is needed. The cones
and the critical set are null for this weighted measure. The reflected
pushforward is also absolutely continuous, proving `nu(dx)=rho(x)dx`.
The same reasoning makes D purely absolutely continuous on its transverse
Hilbert space, although the scalar claim needs only nu.

For every `x0 in (-b,b)`, rho has a strictly positive lower bound on some
neighborhood of x0. A constructive local chart suffices. Use one cone,
`q_j=arcsin(r n_j)` with small r>0, and parameterize the sphere near a
point with `kappa dot n=x0` by `t=(kappa dot n)/b` and an azimuth phi.
On a compact angular patch contained in `|t|<1`,

    omega(r,t,phi)=b t+O(r^2),
    partial_t omega=b+O(r^2),
    w dq = [|d|^2-omega^2]
       /[4I0(2pi)^3 product_j sqrt(1-r^2 n_j^2)] dr dOmega.

The numerator tends uniformly to `b^2(1-t^2)>0` on that patch. Choose a
small fixed radial interval `[r0/2,r0]` and small fixed azimuth interval.
The derivative in t is bounded above and away from zero. The images of
the t interval have a common neighborhood of x0. Changing variable from
t to omega there gives a uniform strictly positive density contribution.
Only one helicity and one chart are needed; a factor 1/2 can be retained
throughout. No assertion about a uniform lower bound up to the endpoints
is made. This works for every nonzero kappa, including axial directions.

## 3. Dressing spectral measure: interior singular mass and endpoints

Let `mu` be the A-spectral measure of normalized zeta. For `z=x+i eta`,

    Im[z-Sigma(z)]=eta+integral eta/[(x-y)^2+eta^2] nu(dy).

If `rho>=c>0` on an open interval I, this denominator is bounded below by
a positive constant uniformly for x in a smaller interval and sufficiently
small eta. Therefore `|R(x+i eta)|` is locally uniformly bounded in the
interior `(-b,b)`. Since `-Im R` is the Poisson transform of mu, integration
over intervals and the Poisson approximation identity show that mu has a
locally bounded density there. In particular there is no interior singular
continuous part and no interior atom in the dressing spectral measure.
This argument does not assume an everywhere-existing principal value.

If the Cauchy principal value boundary exists at x, its usual expression is

    density_mu(x)=rho(x)/[(x-PV integral rho(y)/(x-y)dy)^2
                                      +pi^2 rho(x)^2].

This formula is not needed for exclusion of singular mass; the positive
Poisson-denominator argument above is sufficient.

The entire spectrum of A lies in `[-b,b]`, by compression of B. The two
possible endpoint atoms are absent. Indeed

    |d(q)|^2=b^2-sum_j kappa_j^2 sin^2 q_j < b^2

almost everywhere, since at least one kappa_j is nonzero. Every nonzero
physical vector psi therefore has `||B psi||<b||psi||`. An eigenvector of
`A=Pi B Pi` at either endpoint would give
`b||psi||=||A psi||<=||B psi||<b||psi||`, a contradiction. This avoids any
assumed endpoint inverse integrability or endpoint self-energy expansion.

Thus mu is fully absolutely continuous, with compactly supported L1
density of mass one. The Riemann-Lebesgue conclusion is

    a(t)=integral exp(-itx) mu(dx) ->0 as |t|->infinity.

One can obtain it directly by approximating the density in L1 by smooth
compactly supported functions and integrating their Fourier transforms by
parts. The same argument gives `K(t)->0`. It does not produce a rate,
integrability of K, exponential damping or monotonicity of |a|.

For the scalar question, embedded eigenvectors orthogonal to zeta would
not matter. In fact the usual cyclic decomposition yields a stronger
optional conclusion: on `clos span{p(D)g} plus C`, zeta is cyclic for A;
its orthogonal complement carries D alone. As D is absolutely continuous,
the preceding argument makes the entire effective A absolutely continuous.
This extension should be stated only with that decomposition proved, and
is not needed to establish the requested scalar decay.

The exact scaling is `A_kappa=b A_(kappa/b)`, so
`a_kappa(t)=a_(kappa/b)(bt)`. No uniform decay down to kappa=0 is implied.
The finite weak-K derivation in the source controls compact rescaled time
intervals; `t->infinity` for this effective generator is not automatically
a uniform long-time theorem for the original excluded walk.

## 4. Pending source-bound work

Implement an independent exact finite Friedrichs fixture for resolvent,
helicity and Volterra coefficients. Such a fixture is pure point and cannot
certify the continuum decay argument. Wait for the author's frozen source,
then read it completely and compare the endpoint, positivity, singular-
measure and model/time-scope claims with the argument above. No source-bound
outcome for the forthcoming draft has yet been issued.
