#!/usr/bin/env python3
"""Exact checks of the reviewed cone and finite-measure constants.

No author imports or continuum quadrature. These algebra checks supplement
the independent measure proof; the atomic example is not a decay model.
"""
import json
import time
import sympy as sp

start = time.monotonic()
R = sp.Rational
H = R(23,24)
assert R(5,6)/H < 1
assert R(1,3)/H < R(1,2)
assert R(13,6)/H+R(2,3)/H**3 < 4
# Valid at every 0<chi<1: 1-t^2 >= chi/2-chi^2/16 >= chi/4;
# 4r^2/sqrt(1-t^2) <= sqrt(chi)/8; coupling >= sqrt(chi)/4.
assert R(1,2)-R(1,16) > R(1,4)
assert 4*R(1,64)*2 == R(1,8)
assert R(1,2)-R(1,64) > R(1,4)
assert R(1,4)+R(1,64) < R(1,2)
print('EXACT all uniform cone inequalities and endpoint-image margins')

# The lower density coefficient follows by multiplying independent measure
# factors: one helicity, normalized torus, azimuth, radial thickness,
# pointwise G lower bound, and inverse t-Jacobian.
b, chi, I0 = sp.symbols('b chi I0', positive=True)
r0 = sp.sqrt(chi)/8
coefficient = R(1,2)/(2*sp.pi)**3 * (2*sp.pi) * (r0/2) * (b*b*chi/(64*I0)) / (2*b)
c = b*chi**R(3,2)/(16384*sp.pi**2*I0)
assert sp.simplify(coefficient-c)==0
assert sp.simplify(2/(sp.pi*c)-32768*sp.pi*I0/(b*chi**R(3,2)))==0
print('EXACT one-cone/one-helicity density and Poisson-strip constants')

# A single mass at the interval endpoint saturates the interval inequality.
# Its Cauchy transform is exact and detects deletion of the factor two.
x, y = R(2,7), R(3,5)
M = 1/(x+sp.I*y-(x+y))
rhs = sp.simplify(2*y*(-sp.im(M)))
assert rhs == 1 and sp.simplify(y*(-sp.im(M))) < 1
print('EXACT sharp interval Poisson factor; omitted factor two fails')

# Two unequal atoms give a difference measure that is even despite their
# unsymmetric original measure. At this T their nonzero cross differences
# make individual exponential kernels imaginary while their sum is real.
energies, weights = [R(-2,3),R(1,5)],[R(2,5),R(3,5)]
T = 15*sp.pi/13
total = sp.S.Zero
for E,w in zip(energies,weights):
    for Ep,wp in zip(energies,weights):
        d=E-Ep
        kernel=1 if d==0 else (1-sp.exp(-sp.I*T*d))/(sp.I*T*d)
        total += w*wp*kernel
assert sp.simplify(total)==R(13,25)
assert sp.simplify(sp.im(total))==0
print('EXACT exchange cancellation without symmetric original spectral measure')

# Integrating min(1,1/(T|d|)) on [-2b,2b] gives the displayed two-sided
# coefficient. The parameter v=2bT>=1 removes logarithm-branch ambiguity.
v, C, time = sp.symbols('v C time', positive=True)
split = 2*C/time + 2*C*sp.log(v)/time
displayed = 2*C*(1+sp.log(v))/time
assert sp.expand(split-displayed)==0
assert sp.simplify(split.subs(v,1)-2*C/time)==0
assert sp.simplify(split.subs(v,1)-C/time)!=0
print('EXACT finite-horizon kernel coefficient including its threshold case')
print(json.dumps({'elapsed_seconds':time.monotonic()-start,
                  'scope':'exact constants and finite measures; analytic source review establishes continuum statements'}))
