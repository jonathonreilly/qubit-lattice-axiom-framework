#!/usr/bin/env python3
"""Independent exact effective-memory algebra; no author imports.

Two actual antipodal sine/cosine pairs give a finite pure-point fixture.
It checks the resolvent, helicity normalization and Volterra time jets.
Continuum absolute continuity and decay are analytic claims, not outputs
of this finite fixture.
"""
from fractions import Fraction
import json
import platform
import time
import sympy as sp

START = time.monotonic()
R, I = sp.Rational, sp.I


def exact(label, lhs, rhs):
    diff = lhs-rhs
    values = list(diff) if isinstance(diff, sp.MatrixBase) else [diff]
    assert all(sp.simplify(x) == 0 for x in values), label
    print("EXACT", label, flush=True)


def cross(v):
    x, y, z = v
    return sp.Matrix([[0, -z, y], [z, 0, -x], [-y, x, 0]])


print(json.dumps({"python":platform.python_version(), "sympy":sp.__version__,
                  "scope":"finite exact algebra, not continuum decay certification"}))
kap = sp.Matrix([R(2,3), -R(3,7), R(5,4)])
eps = [R(3,5), R(5,13)]
weights = [R(621,896), R(275,896)]
sines = [sp.Matrix([eps[0],0,0]), sp.Matrix([0,eps[1],0])]
cosines = [sp.Matrix([R(4,5),1,1]), sp.Matrix([1,R(12,13),1])]
normals = [sp.eye(3)[:,0], sp.eye(3)[:,1]]
tangents = [sp.Matrix.hstack(sp.eye(3)[:,1],sp.eye(3)[:,2]),
            sp.Matrix.hstack(sp.eye(3)[:,2],sp.eye(3)[:,0])]
I0 = sum(w/(4*e*e) for w,e in zip(weights,eps))
exact("finite dressing normalization I0", I0, 1)
assert all(w > 0 for w in weights) and sum(weights) == 1
ds = [kap.multiply_elementwise(c) for c in cosines]
omega = [(d.T*n)[0] for d,n in zip(ds,normals)]
gs = [t.T*(I*d.cross(n)/(2*e))
      for t,d,n,e in zip(tangents,ds,normals,eps)]
Ds = [t.T*(I*o*cross(n))*t for t,o,n in zip(tangents,omega,normals)]
b2 = (kap.T*kap)[0]
for j,(d,s) in enumerate(zip(ds,sines)):
    deficit = b2-(d.T*d)[0]
    exact(f"pointwise endpoint deficit {j}", deficit,
          sum(k*k*x*x for k,x in zip(kap,s)))
    assert deficit > 0

W6 = sp.diag(*([weights[0]]*3+[weights[1]]*3))
W5 = sp.diag(weights[0],weights[0],weights[1],weights[1],1)
embed = sp.zeros(6,5)
B6 = sp.zeros(6)
A = sp.zeros(5)
for j in range(2):
    embed[3*j:3*j+3,2*j:2*j+2] = tangents[j]
    embed[3*j:3*j+3,4] = normals[j]/(2*eps[j])
    B6[3*j:3*j+3,3*j:3*j+3] = I*cross(ds[j])
    A[2*j:2*j+2,2*j:2*j+2] = Ds[j]
    A[2*j:2*j+2,4] = gs[j]
    A[4,2*j:2*j+2] = weights[j]*gs[j].H
exact("orthogonal weighted effective embedding", embed.H*W6*embed, W5)
exact("effective block from independent compression", W5.inv()*embed.H*W6*B6*embed, A)
exact("weighted self adjointness", A.H*W5, W5*A)

bath_mass = []
for j,(D,g,o,w) in enumerate(zip(Ds,gs,omega,weights)):
    exact(f"transverse square {j}", D*D, o*o*sp.eye(2))
    exact(f"helicity cross moment {j}", (g.H*D*g)[0], 0)
    mass = sp.simplify(w*(g.H*g)[0]); bath_mass.append(mass)
    for sign in (-1,1):
        proj = (sp.eye(2)+sign*D/o)/2
        exact(f"equal helicity weight {j} sign {sign}",
              w*(g.H*proj*g)[0], mass/2)

e = sp.zeros(5,1); e[4] = 1
for z in (2+3*I, -2+I, I/4):
    sigma = sum(m*z/(z*z-o*o) for m,o in zip(bath_mass,omega))
    value = ((z*sp.eye(5)-A).inv()*e)[4]
    exact(f"Schur scalar resolvent at {z}", value, 1/(z-sigma))
    assert sp.simplify(value-1/(z-2*sigma)) != 0
    assert sp.simplify(value-1/z) != 0
    assert sp.im(value).simplify() < 0
print("DISCRIMINATORS missing helicity half and deleted dressing coupling both fail")

# The convolution Taylor identity has no binomial factor: the integral
# of t^k/k! times s^l/l! contributes t^(k+l+1)/(k+l+1)!.
order = 12
Kjet = [sum(m*((-1)**(n//2))*o**n for m,o in zip(bath_mass,omega))
        if n%2 == 0 else sp.S.Zero for n in range(order)]
ajet = [sp.S.One,sp.S.Zero]
for n in range(2,order+1):
    ajet.append(-sum(Kjet[k]*ajet[n-2-k] for k in range(n-1)))
for n in range(order+1):
    exact(f"Volterra versus unitary derivative order {n}",
          ajet[n], ((-I)**n)*(e.T*(A**n)*e)[0])
assert ajet[2] == -sum(bath_mass) < 0
assert ajet[2] != sum(bath_mass)
print("DISCRIMINATOR reversing the Volterra sign fails at second order")

# The cone density includes the r^2 volume factor that cancels the
# inverse-radius-squared dressing weight. This one exact angular sample
# checks that cancellation, not the continuum change-of-variables proof.
r = sp.symbols('r', positive=True)
n = sp.Matrix([R(3,5),R(4,5),0])
d = kap.multiply_elementwise(sp.Matrix([sp.sqrt(1-r*r*x*x) for x in n]))
o = (d.T*n)[0]
radial_weight = ((d.T*d)[0]-o*o)/(4*I0*sp.prod(sp.sqrt(1-r*r*x*x) for x in n))
limit = sp.limit(radial_weight,r,0,dir='+')
exact("finite positive cone-weight limit",limit,(b2-(kap.T*n)[0]**2)/(4*I0))
assert limit > 0
print("FINITE_FIXTURE",json.dumps({"I0":str(I0),"weights":[str(x) for x in weights],
      "omega":[str(x) for x in omega],"bath_mass":[str(x) for x in bath_mass],
      "scope":"finite pure-point measure; no inference of long-time decay from this fixture"}))
print(json.dumps({"elapsed_seconds":time.monotonic()-START,
      "scope":"exact finite controls plus analytic pre-freeze reconstruction; no grids"}))
