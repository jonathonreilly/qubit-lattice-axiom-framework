# Current quantitative-review checkpoint

Completion state, 2026-10-11: the complete 420-line quantitative source at
`ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400`
and its full author helper/log/receipt have now been read. All Q1-Q33 were
checked against the independent reconstruction below and the unchanged
reviewed premises. The source's improved 7/2 spectral coefficient is valid
because mean-zero singlet projection contracts the truncated inverse norm.
No consequential defect was found. The final source-bound report is
`../EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_REVIEW.md`; exact identities
are bound by `independent_review_receipt.json`. No author replay was used
as independent evidence. All prior frozen reports and receipts remain
unchanged, as verified in `source_identity_verification.json`.

There are no unresolved mathematical fixes requested for the reviewed
bytes. Scope limits remain: selected packet family, supplied model/current,
no operator-norm uniformity, no continuum certification from finite points,
and no formal retained status or Lean proof. The next decision belongs to
the root: whether to compose this reviewed result into a publication source.

## Pre-freeze reconstruction retained verbatim

2026-10-11. Awaiting the frozen SHA and complete source for
`EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md`; no draft content has
been read yet. No source-bound outcome has been issued for that source.
All prior author sources and reviews remain frozen.

Inputs reused after previous complete reading:

- Long-time probe `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324`,
  particularly L5 and L13–L14, reread for this task.
- Degenerate probe `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`,
  particularly D6, D11 and its bounded-current expansion.
- Two-scale draft `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c`,
  reviewed completely; frozen review `7fa575475439af53c7c0cf4af74fea66537b75ce42afd7418504de4dd0e31051`.

Independent derivation before new-source freeze:

1. For `z(t)=exp(-it A_kappa)zeta=u(t)+alpha(t)zeta`, pointwise Duhamel
   gives `|u(t,q)|<=T b/(2epsilon sqrt(I0))`, and
   `|<g,u>|<=T b^2`. Thus `Q B z=nG`,
   `G=n dot(i d cross u)-<g,u>/(2epsilon sqrt(I0))`, obeys
   `|G|<=T b^2/(epsilon sqrt(I0))` and `integral G/(2epsilon)=0`.
2. Set `f=G/(2epsilon)` and
   `f_r=1_(epsilon>=r)f-integral 1_(epsilon>=r)f`. The latter is an
   allowed mean-zero singlet. For `0<r<=1/2`, L5 yields
   `||nG-H_*(f_r,0)||<=2T b^2 sqrt(r)/sqrt(I0)` and
   `||f_r||<=2T b^2/(sqrt(I0)sqrt(r))`. Therefore, with `r=sigma`,
   `sup_|t|<=T ||E_sigma Q B z(t)||<=4T b^2 sqrt(sigma)/sqrt(I0)`.
   No full reduced inverse or spectral gap is assumed.
3. L14 separately gives for `x_lambda=chi_lambda-A_lambda zeta`
   `||E_sigma x_lambda||<=2A_lambda sqrt(sigma)/sqrt(I0)+sigma C_lambda`,
   `C_lambda=2/(a lambda n_lambda)+beta_lambda sqrt(I0)/n_lambda`,
   provided `sigma<=min(1/2,a lambda/2)`, `a=5/4`.
4. D11 plus the new complementary B9 gives at `T=1/20`, `b<=2`,
   `e_perp<=9delta/sigma+17A_lambda sqrt(sigma)+8sigma/lambda+delta/5`.
   The squared-transverse current error is at most
   `4A_lambda e_perp+2e_perp^2`; exact energy conservation and the bounded
   current expansion contribute less than `8delta` at kappa=(1,1,1).
5. For `sigma=2^-40 lambda^(3/2)`, `delta=2^-68 lambda^2`, and
   `0<lambda<=1/16`, use `A_lambda>sqrt(lambda)/12`. The four relative
   error terms are bounded by `108*2^-28`, `17*2^-23`, `96*2^-40`, and
   `(3/80)*2^-68`. Their exact sum is below `1/200000`.
   The current error is below `A_lambda^2/21600`; existing full-dimensional
   packet and positive-band preparation margins also hold explicitly.

Evidence already run: `independent_quantitative_controls.py` and its
complete `.log`, exit zero on the first run, outer runtime 0.426052 s,
Python 3.13.5 / SymPy 1.14.0. No author imports or grids. The independent
four-pair fixture checks the longitudinal projection, exact mean-zero
constraint, and cutoff residual sign; its integral values are not continuum
values. The polynomial/error inequalities use exact rational arithmetic.

Open review obligations: read the entire frozen source once supplied;
check its constants, cutoff ranges, prepared-state and global-weight
definitions, parameter quantifiers, and claimed scope against the above.
The quantitative spectral estimate is specific to the dressing orbit and
does not establish uniform control for arbitrary zero-space unit vectors.
Produce one new source-bound review and receipt after that comparison.
