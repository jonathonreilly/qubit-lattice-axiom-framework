#!/usr/bin/env python3
"""Independent algebra/constants for the proposed quantitative onset.

No author imports and no continuum quadrature. The finite longitudinal
fixture checks projection and mean-corrected inverse signs only. Exact
rational inequalities check the polynomial parameter and current budgets.
"""
from fractions import Fraction as F
import json
import platform
import time
import sympy as sp

START = time.monotonic()
I = sp.I
R = sp.Rational


def exact(name, left, right):
    diff = left-right
    values = list(diff) if isinstance(diff, sp.MatrixBase) else [diff]
    assert all(sp.simplify(x) == 0 for x in values), name
    print("EXACT", name, flush=True)


def lt(name, left, right):
    assert left < right, (name, left, right)
    print("RATIONAL", name, str(left), "<", str(right), flush=True)


print(json.dumps({"python":platform.python_version(),"sympy":sp.__version__,
                  "scope":"independent finite algebra and rational constants, not torus certification"}))

# Four implicit antipodal pairs, with even scalar coefficients. The
# global inner product is the arithmetic mean over these four pairs.
# Each pair is an actual rational-sine point; d uses its actual cosine.
ss = [sp.Matrix([R(1,5),0,0]), sp.Matrix([0,R(3,5),0]),
      sp.Matrix([0,0,R(4,5)]), sp.Matrix([R(3,5),R(4,5),0])]
eps = [sp.sqrt(s.dot(s)) for s in ss]
nn = [s/e for s,e in zip(ss,eps)]
cs = [sp.Matrix([sp.sqrt(1-x*x) for x in s]) for s in ss]
kap = sp.Matrix([R(2,3),-R(3,7),R(5,4)])
dd = [c.multiply_elementwise(kap) for c in cs]
I0 = sum(1/(4*e*e) for e in eps)/4
zeta = [n/(2*e*sp.sqrt(I0)) for n,e in zip(nn,eps)]
g = [I*d.cross(n)/(2*e*sp.sqrt(I0)) for d,n,e in zip(dd,nn,eps)]
# A chosen transverse field u=g makes the dressing coefficient nonzero;
# the algebra being checked holds for arbitrary transverse u.
u = g
ell = [sp.simplify((n.T*(I*d.cross(v)))[0]) for n,d,v in zip(nn,dd,u)]
a = sp.simplify(sum((v.H*w)[0] for v,w in zip(g,u))/4)
G = [sp.simplify(l-a/(2*e*sp.sqrt(I0))) for l,e in zip(ell,eps)]
field = [n*GG for n,GG in zip(nn,G)]
direct = []
for n,d,v,z in zip(nn,dd,u,zeta):
    Bu=I*d.cross(v)
    direct.append(n*(n.T*Bu)[0]-a*z)
for j,(v,w) in enumerate(zip(field,direct)):
    exact(f"Q B field longitudinal component {j}",v,w)
exact("global removed dressing coefficient",sum((z.H*(I*d.cross(v)))[0]
      for z,d,v in zip(zeta,dd,u))/4,a)
ff = [sp.simplify(GG/(2*e)) for GG,e in zip(G,eps)]
exact("formal inverse has mean zero",sum(ff)/4,0)
assert a != 0

# The cutoff excludes the first pair, with epsilon=1/5. It is an algebra
# fixture, not a quadrature to which the continuum cone bounds may be applied.
r=R(1,2)
keep=[e >= r for e in eps]
m=sp.simplify(sum(f if k else 0 for f,k in zip(ff,keep))/4)
fr=[sp.simplify((f if k else 0)-m) for f,k in zip(ff,keep)]
exact("cut singlet restored to physical mean zero",sum(fr)/4,0)
assert m != 0
for j,(GG,e,f,k) in enumerate(zip(G,eps,fr,keep)):
    residual=sp.simplify(GG-2*e*f)
    expected=(0 if k else GG)+2*e*m
    exact(f"mean-corrected inverse residual sign {j}",residual,expected)
assert any(sp.simplify(GG-2*e*f-((0 if k else GG)-2*e*m)) != 0
           for GG,e,f,k in zip(G,eps,fr,keep))
print("DISCRIMINATOR reversing the mean-restoration residual sign fails")
print("FINITE_LONGITUDINAL_FIXTURE",json.dumps({"I0":str(I0),"mean_cutoff_coefficient":str(m),
      "scope":"no continuum spectral-mass or integral claim from these four points"}))

# Coefficients obtained independently from the cone truncation and the
# two cutoff-Duhamel estimates, using T=1/20, b<=2 and I0^-1/2<=sqrt(12).
T=R(1,20)
assert 4*2+3*T*4 < 9
assert (4+4*T*T*4)**2*12 < 17**2
assert R(32,5)+R(6,16)/sp.sqrt(2) < 8
assert R(2,15) < R(1,5)
print("EXACT combined coefficients bounded by 9,17,8,1/5")

# sigma=2^-40 lambda^(3/2), delta=2^-68 lambda^2, lambda<=1/16,
# and A>=sqrt(lambda)/(3pi)>sqrt(lambda)/12. No decimal rounding enters.
part1=F(108,2**28)
part2=F(17,2**23)
part3=F(96,2**40)
part4=F(3,80*2**68)
eta=part1+part2+part3+part4
lt("relative transverse error",eta,F(1,200000))
lt("sigma/lambda cutoff margin",F(1,2**42),F(5,8))
lt("sigma absolute cutoff margin",F(1,2**46),F(1,2))
lt("delta/lambda band margin",F(1,2**72),F(1,32))
lt("delta absolute margin",F(1,2**76),F(1,1))

# Error in the actual scaled diagonal current, relative to A^2.
# The bound delta/A^2 <= 9*2^-68 uses lambda<=1/16 and pi<4.
current_error=4*F(1,200000)+2*F(1,200000)**2+F(72,2**68)
lt("current error leaves half of the dressing sign",current_error,F(1,21600))
assert 4+(13+sp.sqrt(3))/12 < 8
print("EXACT energy plus canonical expansion error bounded by 8 delta")

# Ensure the pre-existing full-dimensional packet/preparation budget can
# be used with the proposed explicit delta, without an existential onset.
lt("explicit delta satisfies old preparation threshold",F(144,2**68),F(1,44236800))
lt("actual preparation scaled error per A^2",F(512*144,2**68),F(1,86400))
exact("envelope error per A squared",R(9,777600),R(1,86400))
exact("final fiber margin",-R(1,21600)+2*R(1,86400),-R(1,43200))
exact("physical time polynomial",1/(20*R(1,2**68)),R(2**66,5))
print(json.dumps({"elapsed_seconds":time.monotonic()-START,
                  "relative_error_decimal_for_orientation_only":float(eta),
                  "scope":"exact arithmetic supports, but does not replace, the analytical spectral-cutoff proof"}))
