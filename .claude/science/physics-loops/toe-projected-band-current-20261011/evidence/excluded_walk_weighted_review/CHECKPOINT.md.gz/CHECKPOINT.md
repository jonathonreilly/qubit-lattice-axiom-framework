# Weighted-memory review checkpoint

2026-10-11. The independent reconstruction is recorded in
`PRE_FREEZE_RECONSTRUCTION.md` and bound by `pre_source_receipt.json`.
The incidental four-line search exposure is documented there. No new
author equation or proof had been read when the reconstruction was saved.
Primary Kato Theorem 1 was checked from all five extracted pages and the
original page images of printed pp.260 and 263.

Result of the independent reconstruction: on fixed Z, rank-two trace-class
completeness plus the checked condition zeta in ac(A) supplies a unique
normalized transverse asymptotic profile u+. Pointwise unitarity of D
gives L1 convergence of q probability and strict positive limits of the
epsilon and coordinate-sine weighted probabilities. The general ordered
component drift is -2 kappa_a integral sin^2(q_a)|u+|^2. No rate, uniform
lower constant, fixed-lambda infinite-time result or joint scale follows.

Completed: all 339 lines of the frozen author source at
`10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324`,
all new helper/driver contents, baseline, mutation source differences and
complete failure logs were inspected. The complete source-bound report is
`../EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md`. No consequential defect was
found in W1–W17. The outcome is conditional and is not a formal audit.

The new helper `independent_weighted_controls.py` ran successfully on its
first execution. Its exact counterexamples discriminate the indispensable
ac(A) membership and comparison-observable commutation requirements; its
transverse two-helicity control checks the pointwise norm premise. These
are finite/exact controls, not numerical certification of Kato or continuum
scattering. All 11 checks and the complete log were inspected.

The author-receipt check verified 197 explicit path/hash occurrences,
181 distinct files. Historical-file identity is not substantive coverage.
The pathless historical Git-blob record was not retrieved. Tooling failures
and incidental exposure are preserved in `development_log.md`.

The final `independent_review_receipt.json` binds the completed report and
all new evidence. `finalize_review.py` checks the frozen source, pre-source,
instruction and recorded artifact identities before writing that receipt.
Preserve these completed outputs; no new research task is authorized by
this checkpoint. The remaining open research obligations are rates,
joint limits, quantitative weighted coefficients and preparation matching.
