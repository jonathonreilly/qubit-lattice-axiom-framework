# Independent weighted-memory reconstruction before reading the new argument

2026-10-11. This records the mathematical reconstruction before reading the
new weighted-memory argument. A broad local filename/text search for the
Kato primary source incidentally printed four matching lines from the
unfrozen new draft: its theorem-name line, primary-PDF coverage table entry,
the first line describing Kato's H0/V hypotheses, and a warning that wave
operators do not place arbitrary vectors in ac(A). No equation or proof
from that draft was read. This limited exposure is disclosed rather than
describing the reconstruction as completely blind to every draft byte.

The inputs actually used are the frozen effective-memory note
`b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c`,
the full effective-generator note
`b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`,
and the archived primary Kato paper
`12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`.
All five primary pages' newly extracted text were read. The original
whole-page images of printed pp.260 and 263 were extracted directly from
that PDF and inspected visually, resolving the OCR's missing adjoint marks
and incorrect year glyph. No new network or author-derived extraction was
used. The local extraction record binds the exact PDF and images.

## 1. Exact imported theorem and matching operators

Kato, *Perturbation of Continuous Spectra by Trace Class Operators*,
Proc. Japan Acad. 33 (1957), pp.260–264, Theorem 1 p.260, states for
self-adjoint H0 and bounded self-adjoint trace-class V that H1=H0+V
has complete wave operators

    W_+ = strong-lim_(t->+infinity) exp(it H1)exp(-it H0)P_ac(H0).

The initial space is H_ac(H0) and the final space is exactly H_ac(H1).
The theorem also supplies the reverse strong limit with P_ac(H1), equal
to W_+ adjoint. The corresponding minus limits hold. Its proof of the
onto assertion and adjoint relation is on p.263. No assertion that all
states lie in either ac subspace follows from the theorem. Theorem 2's
parameter-continuity statements are not needed here.

For fixed nonzero kappa, take the fixed Hilbert space

    Z=F direct-sum C,
    A0=D direct-sum 0,
    A=[[D,g],[<g|,0]], V=A-A0=[[0,g],[<g|,0]].

Both generators are bounded self-adjoint on all Z. The two nonzero
eigenvalues of V are `+||g||` and `-||g||`, on the span of g and the
scalar coordinate, so V has rank two and trace norm `2||g||`. The parent
proves g is nonzero for kappa nonzero; rank at most two would also suffice.
Thus Kato applies with no small-coupling, gap, Cook regularity or Markov
hypothesis.

The scalar block of A0 is a zero eigenvector and contributes no ac part:

    H_ac(A0)=H_ac(D) direct-sum {0} subset F direct-sum {0}.

It is not necessary to prove that the entire D space is absolutely
continuous. The checked memory theorem supplies the separate essential
condition `zeta in H_ac(A)`, because its normalized spectral measure is
entirely absolutely continuous. Rank two alone would not supply that fact.

## 2. Normalized transverse scattering vector

By completeness define `Phi_+=W_+* zeta`. Then

    Phi_+=(u_+,0), ||u_+||=1, W_+ Phi_+=zeta.

The wave-operator definition therefore yields

    ||exp(-itA)zeta-exp(-itA0)Phi_+|| ->0,
    ||(u(t),a(t))-(exp(-itD)u_+,0)|| ->0.                 (R1)

This uses the wave-operator direction correctly: the free asymptotic vector
is W_+ adjoint applied to the interacting initial vector. Existence without
completeness would not suffice to infer that zeta is in the range.

The vector is unique, because two possible transverse profiles would have
a constant norm difference under exp(-itD), while (R1) makes it tend to zero.
The reverse limit also gives the convergent Hilbert-space improper integral

    u_+=strong-lim_(T->infinity) exp(iTD)u(T)
       =-i strong-lim_(T->infinity) integral_0^T exp(isD)g a(s) ds.

No pointwise Fourier-integral convergence or absolute integrability of
a(t) is inferred. This is qualitative scattering, without a remainder rate.

## 3. Weighted probability and each canonical-current component

The multiplication generator D(q) is Hermitian on each transverse fiber,
so its propagator preserves pointwise vector length. With
`r(t)=||(u(t),a(t))-(exp(-itD)u_+,0)||`,

    || |u(t,q)|^2-|u_+(q)|^2 ||_L1
       <= (||u(t)||+||u_+||) ||u(t)-exp(-itD)u_+||
       <=2r(t) ->0.                                      (R2)

This proves convergence for every bounded q weight directly, without
assuming that an arbitrary multiplication operator preserves odd parity.
For the weights used in the current, preservation is automatic since they
are even. In particular,

    W(t)=||epsilon u(t)||^2 -> W_+=||epsilon u_+||^2,
    0<W_+<3.

The lower inequality is strict because epsilon vanishes only at eight
measure-zero cones, whereas u_+ is a normalized L2 field. The strict upper
bound follows similarly since epsilon squared is strictly below three
almost everywhere. These are qualitative positive bounds, not uniform
lower constants in kappa or an explicit value for W_+.

More specifically put

    s_a^+=integral sin^2(q_a)|u_+(q)|^2,  0<s_a^+<1,
    W_+=sum_a s_a^+.

Each coordinate sine vanishes only on null planes, and equals unit
absolute value only on null planes; this proves both strict inequalities.
For the checked canonical compression

    calJ_a=[[cos(2q_a) I_F,r_a],[<r_a|,1]],

(R1) and boundedness of calJ_a give

    <exp(-itA)zeta,calJ_a exp(-itA)zeta>
           -> integral cos(2q_a)|u_+|^2 =1-2s_a^+.

No derivative of the effective generator replaces this current. The
dressing diagonal and cross terms vanish in this asymptotic comparison
because the reference scalar coordinate is zero, not because they were
deleted from the operator.

For the actual original current use the checked fixed-time weak-momentum
limit first:

    lim_(t->infinity) lim_(lambda->0)
       [<U_lambda(t)zeta,J_a(lambda kappa)U_lambda(t)zeta>
                            -<zeta,J_a(lambda kappa)zeta>]/lambda
       =-2 kappa_a s_a^+.

This is strictly opposite in sign to kappa_a when that component is nonzero.
If kappa_a=0, the actual J_a(lambda kappa) is identically zero. For
`kappa=k(1,1,1)`, cyclic symmetry already proved at every effective time
gives `s_a^+=W_+/3`, recovering the common drift `-2kW_+/3`.

The original physical time is t/lambda. Nothing here interchanges the two
limits, supplies a joint scale, or controls fixed lambda for infinite time.
No conclusion for arbitrary lambda-dependent positive free-band states is
obtained from this dressing preparation. The root's separate joint-scale
investigation is not a premise of this check.

## 4. Failure mode and pending review

The frozen memory source's finite bath has a dressing atom 9/25 and exact
recurrences. For a finite-dimensional bath the ac subspaces are zero, so
Kato's theorem is still true but cannot provide a normalized scattering
profile for that dressing vector. This is a direct counterexample to
dropping the separate ac(A) hypothesis, not a counterexample to (R1).

Wait for the new author's frozen identity, then read its entire argument
and compare theorem conventions, normalization, observable compression,
weighted positivity and limit order. No source-bound outcome has yet been
issued for the new draft. All old author/review files remain unchanged.
