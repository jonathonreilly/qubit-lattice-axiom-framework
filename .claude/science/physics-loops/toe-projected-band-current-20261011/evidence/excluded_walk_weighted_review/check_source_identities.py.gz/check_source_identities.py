"""Check every explicit path/hash pair in the frozen author receipt."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


D = Path(__file__).resolve().parent
S = D.parent
receipt = S / "weighted_memory/receipt.json"
expected_receipt = "a9a25c7df59b6efe058b4496038a8232e39baba04826290c6f1ffa8f32cbf8ca"
assert hashlib.sha256(receipt.read_bytes()).hexdigest() == expected_receipt
data = json.loads(receipt.read_text())
occurrences = []
pathless = []


def collect(value, location):
    if isinstance(value, dict):
        if "sha256" in value:
            if "path" in value:
                occurrences.append((location, value))
            else:
                pathless.append({"location": location, **value})
        for key, item in value.items():
            collect(item, location + "/" + str(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            collect(item, location + "/" + str(index))


collect(data, "author_receipt")
records = {}
for location, record in occurrences:
    path = Path(record["path"])
    if not path.is_absolute():
        path = receipt.parent / path
    key = str(path.resolve())
    prior = records.get(key)
    if prior is not None:
        assert prior["expected_sha256"] == record["sha256"], (key, "conflicting identities")
        prior["receipt_locations"].append(location)
        continue
    blob = path.read_bytes()
    actual = hashlib.sha256(blob).hexdigest()
    checks = {"sha256": actual == record["sha256"]}
    if "bytes" in record:
        checks["bytes"] = len(blob) == record["bytes"]
    if "lines" in record:
        checks["lines"] = len(blob.splitlines()) == record["lines"]
    assert all(checks.values()), (key, checks)
    records[key] = {"path": key, "expected_sha256": record["sha256"],
                    "actual_sha256": actual, "bytes": len(blob),
                    "receipt_locations": [location], "checks": checks}


result = {"created_utc": datetime.now(timezone.utc).isoformat(),
          "receipt": {"path": str(receipt), "sha256": expected_receipt},
          "scope": "All explicit path/hash records in this author receipt, including historical identity records. Hash identity is not a new substantive review of historical files.",
          "path_hash_occurrences": len(occurrences), "distinct_files_verified": len(records),
          "pathless_hash_records_not_independently_retrieved": pathless,
          "verified": list(records.values())}
output = D / "source_identity_check.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"receipt_sha256": expected_receipt,
                  "path_hash_occurrences": len(occurrences),
                  "distinct_files_verified": len(records),
                  "pathless_records": len(pathless),
                  "output": str(output)}))
