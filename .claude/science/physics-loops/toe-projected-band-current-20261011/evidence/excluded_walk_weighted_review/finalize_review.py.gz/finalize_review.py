"""Bind the completed independent weighted-memory review without source edits."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


D = Path(__file__).resolve().parent
S = D.parent
RUN = S.parent


def identify(path):
    path = Path(path)
    blob = path.read_bytes()
    record = {"path": str(path), "sha256": hashlib.sha256(blob).hexdigest(),
              "bytes": len(blob)}
    if path.suffix not in {".pdf", ".png"}:
        record["lines"] = len(blob.splitlines())
    return record


expected = {
    "EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md": "10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324",
    "weighted_memory/receipt.json": "a9a25c7df59b6efe058b4496038a8232e39baba04826290c6f1ffa8f32cbf8ca",
    "EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md": "b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c",
    "EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md": "c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0",
    "excluded_walk_memory_review/independent_review_receipt.json": "5a73e562741e0e10e84101206a0c98d2f3daf4d534898260d14fe85a1f101fe6",
    "EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md": "b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876",
    "EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md": "c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2",
    "excluded_walk_degenerate_review/independent_review_receipt.json": "c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa",
    "excluded_walk_review/kato_1957_primary.pdf": "12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5",
    "excluded_walk_weighted_review/PRE_FREEZE_RECONSTRUCTION.md": "42648b16c2cb46d544c1cd1130446e0efa7813bece3c8773336fbc3923647eff",
    "excluded_walk_weighted_review/pre_source_receipt.json": "da6a9f1585b09c9cdf61e8734ed25297e281baaf8b946170ca2b46dd68e77e16",
    "EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md": "a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484",
}
inputs = []
for name, expected_hash in expected.items():
    record = identify(S / name)
    assert record["sha256"] == expected_hash, name
    inputs.append(record)

instructions = {
    str(RUN / "worktree/AGENTS.md"): "f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f",
    str(RUN / "worktree/docs/ai_methodology/SCIENCE_WORKFLOW.md"): "05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce",
    "/Users/jonreilly/.codex/skills/physics-claim-reviewer/SKILL.md": "9d841edd05b9dc4c5145abcfd5352cd45460a1cc57c23c1eabd131590dbb1455",
}
instruction_records = []
for name, expected_hash in instructions.items():
    record = identify(name)
    assert record["sha256"] == expected_hash, name
    instruction_records.append(record)
instruction_records.append(identify("/Users/jonreilly/.codex/plugins/cache/openai-primary-runtime/pdf/26.1007.11041/skills/pdf/SKILL.md"))

author_receipt = json.loads((S / "weighted_memory/receipt.json").read_text())
author_artifacts = author_receipt["artifacts"]
for old in author_artifacts:
    actual = identify(old["path"])
    assert actual["sha256"] == old["sha256"], old["path"]

identity = json.loads((D / "source_identity_check.json").read_text())
for old in identity["verified"]:
    actual = identify(old["path"])
    assert actual["sha256"] == old["expected_sha256"], old["path"]
    assert actual["bytes"] == old["bytes"], old["path"]

pre_receipt = json.loads((D / "pre_source_receipt.json").read_text())
for old in pre_receipt["inputs"] + pre_receipt["outputs"]:
    assert identify(old["path"])["sha256"] == old["sha256"], old["path"]

own_outputs = [identify(p) for p in sorted(D.iterdir())
               if p.is_file() and p.name != "independent_review_receipt.json"]
own_outputs.append(identify(S / "EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md"))
receipt = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "task": "Independent fixed-fiber weighted-memory and ordered-current review",
    "outcome": "No consequential defect found in W1-W17 at the stated frozen source identity; conditional mathematical review, not a formal audit or retained-status decision.",
    "input_identities": inputs,
    "source_coverage": {
        "new_note": "All 339 lines and all new arguments W1-W17 read; no argument accepted solely from author controls.",
        "parents": "Complete earlier 500-line memory and 549-line degenerate readings and independent proofs reused at identical bytes. The actual current D12-D18 was refreshed; E23 ac membership is an essential separate premise.",
        "primary": "Kato 1957 Theorem 1 p.260 and completeness/adjoint proof p.263. All five newly extracted pages read; original pp.260 and 263 images visually inspected. Theorem 2 is not used.",
        "author_controls": "Full 106-line helper, 52-line driver, baseline, four actual source differences and complete failure logs inspected. No author runner replay and no independence credit from author PASS counts.",
        "author_receipt": "All non-inventory fields inspected; every explicit path/hash occurrence checked. Historical identity verification does not claim substantive review of all historical files.",
    },
    "pre_source_reconstruction": {
        "identity": identify(D / "PRE_FREEZE_RECONSTRUCTION.md"),
        "receipt": identify(D / "pre_source_receipt.json"),
        "timing": "Reconstruction file was saved before the author freeze and before reading the new argument.",
        "incidental_exposure": pre_receipt["limited_incidental_exposure"],
        "preserved_unchanged": True,
    },
    "primary_import": {
        "source": identify(S / "excluded_walk_review/kato_1957_primary.pdf"),
        "hypotheses_matched": "A0=D direct-sum 0 and A act on the same Z; bounded self-adjoint operators; V rank two with trace norm 2||g||.",
        "convention": "Omega_+=s-lim e^{itA}e^{-itA0}P_ac(A0); outgoing datum is Omega_+ adjoint zeta.",
        "completeness_premise": "The checked dressing measure is fully absolutely continuous by E23, hence P_ac(A)zeta=zeta.",
        "limitations": "The general Kato theorem is imported rather than reproved. No all-vector ac claim for A or D and no global direct-integral trace-class assertion.",
        "network": "No new network request; local original PDF used.",
    },
    "independent_execution": json.loads((D / "independent_execution.json").read_text()),
    "independent_controls": {
        "checks": 11,
        "content": [
            "Rank-two coupling with a continuous spectator still admits a recurrent point dressing, discriminating the E23 hypothesis.",
            "Purely ac exact comparison A=A0 can have a noncommuting observable with expectation cos(t)^2; scalar weights remain constant.",
            "Exact transverse two-helicity exponential is pointwise unitary and solves its evolution equation.",
        ],
        "scope": "Exact necessity and fiber controls, not numerical certification of the continuum walk, Kato, or asymptotic scattering.",
        "author_code_imported": False,
        "first_run_success": True,
    },
    "author_artifacts_inspected_or_identity_bound": author_artifacts,
    "historical_identity_check": {
        "manifest": identify(D / "source_identity_check.json"),
        "execution": json.loads((D / "source_identity_execution.json").read_text()),
        "path_hash_occurrences": identity["path_hash_occurrences"],
        "distinct_files_verified": identity["distinct_files_verified"],
        "pathless_records_not_retrieved": identity["pathless_hash_records_not_independently_retrieved"],
        "final_recheck": "All recorded distinct path/hash identities rechecked before this receipt was written.",
    },
    "supported_scope": [
        "For each fixed nonzero kappa, a unique normalized u_+ in ac(D) with strong scattering from the physical dressing.",
        "L1 convergence of transverse q probability; epsilon-weighted limit strictly between 0 and 3.",
        "Each coordinate sine-squared weighted limit lies strictly between 0 and 1; current coefficient tends to 1-2W_a.",
        "Original current change is -2 kappa_a W_a only in the stated ordered lambda then long-effective-time limit.",
        "W15 constants and the separation of its two state errors match the parent current expansion.",
    ],
    "limits": [
        "No rate or numerical lower value for W_a.",
        "No joint time/momentum schedule, reversed limit order, or fixed-lambda infinite-time statement.",
        "No new normalizable K envelope or arbitrary lambda-dependent positive-free-band preparation theorem.",
        "No new Lean certification; historical Lean-file hashes do not certify this extension.",
        "No remote freshness or universal novelty claim.",
    ],
    "tooling_and_failures": "See development_log.md: disclosed four-line pre-source exposure, truncated receipt display completed by targeted read and identity checks, read-only wrong-directory command retried, documentation patch failed atomically at the checkpoint heading then corrected, and primary extraction encoding warnings resolved visually. Independent mathematical controls passed first run; no assertion or tolerance was weakened.",
    "instructions_reused_or_applied": instruction_records,
    "editable_prompt_files_changed": [],
    "repository_files_changed": [],
    "formal_audit_state_changed": False,
    "writes": [str(S / "EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md"), str(D)],
    "outputs": own_outputs,
    "receipt_scope": "Identity and coverage record; excludes its own hash. Prior source/review/pre-source bytes were preserved.",
}
path = D / "independent_review_receipt.json"
path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"review": identify(S / "EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md"),
                  "receipt": identify(path), "own_output_files": len(own_outputs),
                  "author_artifacts_bound": len(author_artifacts),
                  "historical_files_rechecked": len(identity["verified"])}))
