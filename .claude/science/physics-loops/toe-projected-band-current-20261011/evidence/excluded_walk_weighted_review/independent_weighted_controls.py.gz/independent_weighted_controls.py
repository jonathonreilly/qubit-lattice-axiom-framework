"""Exact scope discriminators for the weighted-memory review.

These use different auxiliary models from the author's conjugacy toy.
They do not prove continuum scattering for the excluded walk or Kato's
theorem. No author helper or runner is imported.
"""
import json
import platform
import time

import sympy as sp


started = time.monotonic()
checks = []


def check(name, condition, detail):
    assert bool(condition), name
    record = {"check": name, "detail": detail}
    checks.append(record)
    print(json.dumps(record, sort_keys=True))


def zero(value):
    values = list(value) if isinstance(value, sp.MatrixBase) else [value]
    return all(sp.simplify(v) == 0 for v in values)


# Control 1: rank two and trace class do not put the dressing in ac(A).
# F=L2([-1,1], dx/2) direct-sum C e, D=M_x direct-sum 0,
# Z=F direct-sum C zeta, and g=e. The continuous M_x channel is a
# spectator; the exact finite (e,zeta) block gives a(t)=cos(t).
# The ac projections of A0 and A are both the spectator channel.
t = sp.symbols("t", real=True)
finite_A = sp.Matrix([[0, 1], [1, 0]])
zeta = sp.Matrix([0, 1])
finite_evolution = sp.cos(t) * sp.eye(2) - sp.I * sp.sin(t) * finite_A
check("rank_two_trace_class_does_not_supply_ac_datum",
      finite_A.rank() == 2 and sum(finite_A.singular_values()) == 2,
      "The exact perturbation has eigenvalues -1,+1 and trace norm 2.")
check("finite_block_evolution_and_unitarity",
      zero(sp.I * sp.diff(finite_evolution, t) - finite_A * finite_evolution)
      and zero(finite_evolution.H * finite_evolution - sp.eye(2)),
      "The continuous spectator is ac; zeta lies in the finite point block.")
orbit = finite_evolution * zeta
check("missing_ac_hypothesis_has_recurrence",
      zero(orbit[1] - sp.cos(t))
      and zero(orbit.subs(t, 2 * sp.pi) - zeta),
      "The survival amplitude recurs and P_ac(A) zeta=0.")
check("no_transverse_unit_scattering_state_for_point_datum",
      zero((finite_evolution * zeta).H * (finite_evolution * zeta)
           - sp.ones(1)),
      "The point-block norm stays one, orthogonal to every outgoing ac vector.")

# Control 2: even exact scattering does not force a bounded observable
# to have a limit if the comparison expectation does not settle.
# On L2([-1,1],dx/2;C^2), A=A0=D(x)=x I+sigma_x is purely ac
# (diagonalize the constant sigma_x). Hence wave operators are I and
# the scattering error is identically zero. Scalar q weights commute;
# the spin projection B does not and retains an exact oscillation.
x = sp.symbols("x", real=True)
sigma_x = sp.Matrix([[0, 1], [1, 0]])
D = x * sp.eye(2) + sigma_x
B = sp.diag(1, 0)
M = x**2 * sp.eye(2)
spin_evolution = sp.cos(t) * sp.eye(2) - sp.I * sp.sin(t) * sigma_x
field = sp.exp(-sp.I * t * x) * spin_evolution * sp.Matrix([1, 0])
check("pure_ac_comparison_diagonalization",
      sp.simplify(D.charpoly().as_expr()
                  - ((D.charpoly().gen - x)**2 - 1)) == 0,
      "D is unitarily equivalent to M_(x+1) direct-sum M_(x-1), both ac.")
check("comparison_field_solves_evolution",
      zero(sp.I * sp.diff(field, t) - D * field),
      "A=A0, so the wave operators are the identity and r(t)=0 exactly.")
check("comparison_density_is_pointwise_constant",
      zero((field.H * field)[0] - 1),
      "All scalar q-weight expectations are constant under this dynamics.")
check("observable_commutation_is_material",
      zero(M * D - D * M) and not zero(B * D - D * B),
      {"nonzero_commutator": str(B * D - D * B)})
weighted = sp.integrate(sp.simplify((field.H * M * field)[0]), (x, -1, 1)) / 2
spin_expected = sp.integrate(sp.simplify((field.H * B * field)[0]), (x, -1, 1)) / 2
check("scalar_weight_has_exact_limit",
      zero(weighted - sp.Rational(1, 3)),
      {"weight": "x^2", "expectation": str(weighted)})
check("noncommuting_observable_oscillates_despite_zero_scattering_error",
      zero(spin_expected - sp.cos(t)**2)
      and spin_expected.subs(t, 0) == 1
      and spin_expected.subs(t, sp.pi / 2) == 0,
      {"expectation": str(spin_expected),
       "subsequences": "t=n*pi gives 1; t=n*pi+pi/2 gives 0."})

# The actual frozen model's free generator is i f n cross on a
# transverse plane. Choosing an oriented orthonormal plane gives
# D_perp=f*sigma_y; test its full two-component exponential, not a
# scalar phase or a projection onto one helicity.
f = sp.symbols("f", real=True)
D_perp = sp.Matrix([[0, -sp.I * f], [sp.I * f, 0]])
U_perp = sp.Matrix([[sp.cos(f*t), -sp.sin(f*t)],
                    [sp.sin(f*t), sp.cos(f*t)]])
check("actual_transverse_fiber_two_helicities",
      zero(D_perp - D_perp.H)
      and zero(sp.I * sp.diff(U_perp, t) - D_perp * U_perp)
      and zero(U_perp.H * U_perp - sp.eye(2)),
      "Pointwise density conservation holds on the full transverse plane.")

print(json.dumps({"checks": len(checks), "python": platform.python_version(),
                  "sympy": sp.__version__, "elapsed_seconds": time.monotonic()-started,
                  "scope": "Exact necessity and transverse-fiber controls; no numerical continuum scattering proof."},
                 sort_keys=True))
