"""Exact finite scale budgets; no continuum/time-asymptotic inference."""
from fractions import Fraction as F
import json

# Direct finite Q16 upper expression, preserving A rather than replacing it by 1.
# These rational samples have lambda^(1/2) and T exactly rational.
rows=[]
for q in (F(1,8),F(1,4),F(3,8)):
    for power in (1,2,4):
        x=F(1,2**power); lam=x**8; root= x**4
        delta=lam**3; sigma=lam**2; T=x**(-int(8*q))
        for A in (root/12,root,2*root):
            assert A<=1 and root/12<=A<=2*root
            # b<2, b^2=3, I0^-1/2<4, C_lambda<=4/lambda, r_delta<=delta.
            exact_relaxed=(delta/sigma*(A*(4+6*T)+(4+3*T))/A
                +(4+F(21,2)*T*T)*lam*4
                +8*sigma/(lam*A)+(A+1)*T*delta/A)
            four_term=(108*delta*T/(sigma*root)+58*T*T*lam
                +96*sigma/(lam*root)+13*T*delta/root)
            leading=x**(4-int(8*q))
            assert exact_relaxed<=four_term<=275*leading
        rows.append({'gamma':str(q),'lambda':str(lam),'relative_bound':str(four_term),'leading_power':str(leading)})
print(json.dumps({'finite_exact_budget_rows':rows}))

# Symbolic exponents from the original general bound, using gamma=1/2-p.
# For 0<p<1/2 all resulting exponents are positive. This is an exact affine
# calculation, not extrapolation from the finite samples above.
import sympy as s
p=s.symbols('p', positive=True)
gamma=F(1,2)-p
exponents=[3-gamma-2-F(1,2), 1-2*gamma, F(1,2), 3-gamma-F(1,2)]
assert [s.simplify(v) for v in exponents]==[p,2*p,F(1,2),p+2]
parameter=s.symbols('parameter', positive=True)
sub={p:1/(2*(1+parameter))}
assert all(s.simplify(v.subs(sub) if hasattr(v,'subs') else v).is_positive for v in exponents)
assert s.simplify(1-gamma-p)==F(1,2)
assert s.simplify(1-p).subs(sub).is_positive
assert F(2,3)*F(1,8)==F(1,12)
assert sum([108,58,96,13])==275
# Using delta=lambda^2 with the same sigma makes its leading error exponent
# negative. The current scale choice is material, not a cosmetic convention.
wrong_delta=2-gamma-2-F(1,2)
assert s.simplify(wrong_delta.subs(sub)).is_negative
print('Exact affine exponents, packet errors and leading coefficient verified; delta=lambda^2 fails these scales.')

# Global physical weights change, but still preserve a uniform fiber bound.
lam=F(1,64); weights=[F(1,5),F(3,10),F(1,2)]
survival=[1-lam**3/F(d) for d in (7,8,9)]
normalization=sum(w*n for w,n in zip(weights,survival))
physical=[w*n/normalization for w,n in zip(weights,survival)]
assert sum(physical)==1 and physical!=weights and min(physical)>0
errors=[F(-1,3),F(2,5),F(5,7)]
assert abs(sum(w*e for w,e in zip(physical,errors)))<=max(map(abs,errors))
print('Exact single global normalization preserves the uniform error; original weights are not substituted.')
