#!/usr/bin/env python3
"""Exact controls for the downstream joint-scale review.

No author runner is imported or replayed. These elementary rational controls
check exponent inequalities and finite error coefficients. They do not prove
the continuum spectral estimate, wave-operator theorem or weighted limit.
"""

from fractions import Fraction as F


# An affine polynomial c + k*p, where p ranges over the open interval (0,1/2).
def affine_positive(poly, strict=True):
    c, k = poly
    ends = (c, c + k / 2)
    assert min(ends) >= 0
    if strict:
        assert max(ends) > 0


def difference(left, right):
    return tuple(a - b for a, b in zip(left, right))


# Terms are derived as powers of delta, sigma, T, eta and lambda, in that order.
# delta=lambda^3, sigma=lambda^2, T=lambda^(-1/2+p), eta=lambda^2.
def exponent(powers):
    pd, ps, pt, pe, pl = map(F, powers)
    return 3 * pd + 2 * ps - pt / 2 + 2 * pe + pl, pt


terms = {
    "high-spectrum correctors / A": (1, -1, 1, 0, F(-1, 2)),
    "zero-orbit spectral cutoff": (0, F(1, 2), 2, 0, 0),
    "band-complement spectral cutoff / A": (0, 1, 0, 0, F(-3, 2)),
    "generator remainder / A": (1, 0, 1, 0, F(-1, 2)),
    "energy-square current error / lambda": (1, 0, 0, 0, -1),
    "actual preparation error / lambda": (1, 0, 0, 0, -2),
    "current variation across packet": (0, 0, 0, 1, -1),
    "evolution variation across packet": (0, 0, 1, 1, -1),
    "band-weight expansion": (0, 0, 0, 0, 2),
}
expected = {
    "high-spectrum correctors / A": (F(0), F(1)),
    "zero-orbit spectral cutoff": (F(0), F(2)),
    "band-complement spectral cutoff / A": (F(1, 2), F(0)),
    "generator remainder / A": (F(2), F(1)),
    "energy-square current error / lambda": (F(2), F(0)),
    "actual preparation error / lambda": (F(1), F(0)),
    "current variation across packet": (F(1), F(0)),
    "evolution variation across packet": (F(1, 2), F(1)),
    "band-weight expansion": (F(2), F(0)),
}
for name, powers in terms.items():
    value = exponent(powers)
    assert value == expected[name]
    affine_positive(value)
    affine_positive(difference(value, (F(0), F(1))), strict=False)
    print(f"Exponent: {name}: {value[0]} + ({value[1]}) p")
for name in ("actual preparation error / lambda", "current variation across packet",
             "evolution variation across packet"):
    affine_positive(difference(expected[name], (F(0), F(1))))

# An amplitude-independent O(e) current error would instead give lambda^(p-1/2).
bad_current_exponent = (F(-1, 2), F(1))
affine_positive(tuple(-v for v in bad_current_exponent))
assert expected["high-spectrum correctors / A"][0] == 0
assert expected["zero-orbit spectral cutoff"][0] == 0
print("Boundary controls: gamma=1/2 supplies no decaying bound; losing A fails.")

# Reconstruct Q16 with b=sqrt(3), T>=1, sqrt(lambda)<=1/4,
# A>=sqrt(lambda)/12, I0^(-1/2)<7/2 and r_delta<=delta.
# The independent rational relaxations are stricter than the author's G5.
coefficients = (
    F(10, 4) + 7 * 12,
    (4 + F(21, 2)) * F(7, 2),
    2 * 4 * 12,
    F(1, 4) + 12,
)
assert F(7, 2) ** 2 > 12
assert coefficients == (F(173, 2), F(203, 4), F(96), F(49, 4))
for own, author in zip(coefficients, (108, 58, 96, 13)):
    assert own <= author
assert sum(coefficients) == F(491, 2) < 275
print("Independent Q16 coefficients:", ", ".join(map(str, coefficients)))

# The exact canonical-current trace multiplies the weighted norm error by 2/3.
for amplitude, error in ((F(1, 5), F(1, 13)), (F(3, 5), F(1, 5))):
    for sign in (-1, 1):
        weighted_error = 3 * ((amplitude + sign * error) ** 2 - amplitude ** 2)
        current_error = F(2, 3) * abs(weighted_error)
        budget = 4 * amplitude * error + 2 * error ** 2
        assert current_error <= budget
        if sign == 1:
            assert current_error == budget
assert F(7, 4) ** 2 > 3
current_remainder = 4 + F(4, 3) * F(7, 4) + (13 + F(7, 4)) / 12
assert current_remainder == F(121, 16) < 8
print("Both current-error signs checked; positive parallel error saturates 4Ae+2e^2.")
print("Independent energy/current remainder coefficient:", current_remainder)

# Reconstruct the two-endpoint preparation and varying-K costs.
current_norm, current_lipschitz, preparation_distance = F(4), F(4), F(32)
assert 2 * current_lipschitz == 8
assert 2 * current_norm == 8
assert 4 * current_norm * preparation_distance == 512
assert 8 + 512 == 520
lam_max = F(1, 16)
assert F(7, 4) + lam_max ** 2 < 2
assert 2 * lam_max ** 2 <= F(1, 16)
assert lam_max ** 2 <= F(1, 10)
assert 1 - lam_max ** 3 / 3 > 0
assert 3 + 2 == 5  # K width delta*eta, not eta alone.
assert 3 + F(1, 8) == F(25, 8)
assert 3 * 3 - 2 * F(3, 2) * 3 == 0  # K Jacobian versus squared amplitude.
assert 3 * 2 - 2 * F(3, 2) * 2 == 0  # kappa-envelope normalization.
print("Finite preparation domain, common time, Jacobians and packet width checked.")

# A nonuniform normalization fixture discriminates the actual projected law.
mass = (F(1, 6), F(1, 3), F(1, 2))
loss = lam_max ** 3 / 3
projection_norm_squared = (1 - loss, 1 - loss / 2, F(1))
normalization = sum(p * n for p, n in zip(mass, projection_norm_squared))
actual_mass = tuple(p * n / normalization for p, n in zip(mass, projection_norm_squared))
assert sum(actual_mass) == 1
assert 1 - loss <= normalization <= 1
assert actual_mass != mass
unit_errors = (F(-1), F(1, 3), F(1, 2))
actual_error = sum(p * e for p, e in zip(actual_mass, unit_errors))
unprojected_error = sum(p * e for p, e in zip(mass, unit_errors))
assert abs(actual_error) <= 1
assert actual_error != unprojected_error
print("Actual normalized packet weights:", ", ".join(map(str, actual_mass)))
print("Uniform error survives the actual weights; replacing their law changes the fixture.")
print("All exact controls completed. No continuum dynamics or Kato proof is asserted.")
