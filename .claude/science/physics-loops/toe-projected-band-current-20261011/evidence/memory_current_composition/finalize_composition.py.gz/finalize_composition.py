#!/usr/bin/env python3
"""Freeze external composition identities and coverage; no scientific verdict."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
S = HERE.parent

def identity(path):
    raw = path.read_bytes()
    out = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    if path.suffix in ('.py', '.md', '.json', '.log', '.txt'):
        out['lines'] = len(raw.splitlines())
    return out

mapping = json.loads((HERE/'SOURCE_COMPOSITION.json').read_text())
note = S/mapping['note']['path']
primary = S/mapping['primary']['path']
assert identity(note)['sha256'] == mapping['note']['sha256']
assert identity(primary)['sha256'] == mapping['primary']['sha256']
assert ''.join(c['text'] for c in mapping['chunks']).encode() == note.read_bytes()
inputs = []
for item in mapping['inputs'].values():
    ident = identity(S/item['name'])
    assert ident['sha256'] == item['sha256']
    inputs.append(ident)
for chunk in mapping['chunks']:
    if chunk['kind'] != 'source_fragment':
        continue
    raw = (S/chunk['source']).read_bytes()[chunk['source_start_byte']:chunk['source_end_byte_exclusive']]
    assert raw.decode() == chunk['original_text']
    changed = raw.decode()
    for edit in chunk['edits']:
        assert changed.count(edit['before']) == edit['occurrences'] == 1
        changed = changed.replace(edit['before'], edit['after'], 1)
    assert changed == chunk['text']
    assert changed.encode() == note.read_bytes()[chunk['output_start_byte']:chunk['output_end_byte_exclusive']]

tag_checks = []
def code_blocks(text):
    blocks = []
    lines = text.splitlines(keepends=True)
    block = ''
    for line in lines+['']:
        if line.startswith('    '):
            block += line
        elif block:
            blocks.append(block)
            block = ''
    return blocks

note_blocks = code_blocks(note.read_text())
for key, prefix, count in [('M', 'E', 29), ('W', 'W', 17), ('G', 'G', 10), ('R', 'R', 14)]:
    original_blocks = code_blocks((S/mapping['inputs'][key]['name']).read_text())
    for i in range(1, count+1):
        tag = f'({prefix}{i})'
        before = [b for b in original_blocks if tag in b]
        after = [b for b in note_blocks if tag in b]
        assert len(before) == len(after) == 1, (tag, len(before), len(after))
        if tag not in ('(G2)', '(G3)'):
            assert before[0] == after[0], tag
        tag_checks.append({'tag': tag, 'comparison': 'byte-identical tagged display block' if tag not in ('(G2)', '(G3)') else 'same implication restated together, with complete W1-W9 proof included; mapped literal bridge'})

tree = ast.parse(primary.read_text())
assignments = {n.targets[0].id: n.value for n in tree.body
               if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
for helper in mapping['primary']['helpers']:
    raw = ast.literal_eval(assignments[helper['variable']]).encode()
    assert raw == (S/helper['source']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == helper['sha256']
    inputs.append(identity(S/helper['source']))

reviews = {
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md': 'c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0',
    'EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md': 'a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484',
    'EXCLUDED_WALK_JOINT_SCALE_CURRENT_REVIEW.md': '2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6',
    'EXCLUDED_WALK_OUTGOING_RESOLVENT_REVIEW.md': '8eb1d81e91227a0cda36e75459e32be80b1523709a5f82fc5af4c1e8fd6d74de',
    'outgoing_resolvent_review/receipt.json': 'c5fb2219ef98d4abce39ef98be784e5c7d1ffde0054cd867214f4713226ba6e0',
    'joint_scale_review/receipt.json': '49bd1d8872a07aea1e5266cb2f07f3ea2aff4d9a9602f7a141e0051037d92b80',
    'excluded_walk_weighted_review/independent_review_receipt.json': '74990de59ab11a8011f4164ce689b0f80153d261c073c486f47b78a1beaf1a28',
    'joint_scale_review/DEPENDENCY_ADDENDUM.md': '8ef5245b3301a19338eedfc8f3f98610b6d3162538b80fbe01bfaf27e5a1273a',
    'joint_scale_review/dependency_addendum_receipt.json': '151aeb2e37648b0ef468e40538b4d0ce11707a1fe3a704239b946e559a5d82bb',
    'excluded_walk_review/kato_1957_primary.pdf': '12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5',
}
for name, expected in reviews.items():
    ident = identity(S/name)
    assert ident['sha256'] == expected
    inputs.append(ident)
parent = S.parent/'walk_worktree/docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md'
parent_identity = identity(parent)
assert parent_identity['sha256'] == '9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401'
inputs.append(parent_identity)

historical = json.loads((HERE/'pre_extension/INDEX.json').read_text())
for item in historical['files']:
    assert identity(Path(item['recovery_path']))['sha256'] == item['sha256']
for filename, changes in [(note.name, mapping['pre_extension']['note_exact_edits']),
                          (primary.name, mapping['pre_extension']['primary_exact_edits'])]:
    restored = (HERE/'pre_extension'/filename).read_text().splitlines(keepends=True)
    for change in reversed(changes):
        a,b = change['old_first_line_zero_based'],change['old_end_line_exclusive']
        assert ''.join(restored[a:b]) == change['old_text']
        restored[a:b] = change['new_text'].splitlines(keepends=True)
    assert ''.join(restored) == (S/filename).read_text()

execution = json.loads((HERE/'primary_execution_extended.json').read_text())
assert execution['returncode'] == 0
assert execution['primary_sha256'] == identity(primary)['sha256']
assert execution['log_sha256'] == identity(Path(execution['log']))['sha256']
headings = re.findall(r'^## (\d+)\.', note.read_text(), flags=re.M)
assert headings == [str(i) for i in range(1,18)]

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
map_identity = identity(HERE/'SOURCE_COMPOSITION.json')
report = f'''# Memory/current publication composition report

2026-10-11. External author assembly, with no repository edits or audit decision.

The publication candidate is `FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md` ({identity(note)['lines']:,} lines), SHA-256 `{identity(note)['sha256']}`. The primary is `excluded_walk_memory_current_2026_10_11.py` ({identity(primary)['lines']} lines), SHA-256 `{identity(primary)['sha256']}`. The claim ID and intended repository names are exactly those in `SOURCE_COMPOSITION.json`, SHA-256 `{map_identity['sha256']}`.

The note contains the complete memory proof, including the uniform cone lower bound, strip Poisson bound excluding singular measure, separate endpoint argument and finite-bath recurrence; the complete Kato hypothesis/subspace check and weighted/current limits; the complete growing-time error and globally normalized preparation argument; and every required R1–R14 regulated-outgoing, second-moment, cone-removal and exact lower-bound argument. It reproduces the actual current compression, cyclic symmetry, coupling lower bound and leading band-weight calculation. The companion remains an explicit dependency for the finite spectral-cutoff/evolution estimates and canonical-current core derivation; every formula and domain actually used is reproduced. There is no sole scratch-file proof reference for a newly composed step.

The map contains {len(mapping['chunks'])} ordered exact-source or literal-editorial chunks, with input identities, source line/byte ranges, unique before/after edits and output byte ranges. Concatenating them reconstructs the final note exactly. All E1–E29, W1–W17 and R1–R14 tagged display blocks are byte-identical to their sources, as are G1 and G4–G10. G2–G3 are restated together with the already-included full W1–W9 proof. Every substantive argument of the four sources is retained; obsolete source inventories and then-pending status prose are replaced by final scope and evidence. The separate spectral-edge work is excluded.

Complete reading coverage: the 500-line memory source and all five helpers were read in this task. Complete unchanged readings of the 339-line weighted source, 236-line joint source, 859-line companion, 549-line degenerate source and 457-line long-time source were reused and the selected arguments refreshed. The full 329-line memory review, 319-line final weighted review and 474-line weighted receipt were read. The frozen original 252-line joint review remains unchanged; the separate dependency addendum binds the now-final weighted review. All five locally extracted Kato pages were read and original pp.260/263 visually checked. The entire 1,316-line first assembled candidate was cold-read, followed by all corrections to its 1,320-line historical freeze. For the extension, the complete 245-line source, 306-line independent review, 426-line receipt and 96-line author helper were read, followed by every changed argument and metadata/status passage in the complete pre-extension-to-final diff, including the explicit local spectral-edge delta convention. No incomplete or truncated display is counted as coverage.

All five embedded helper strings were independently extracted from the primary AST and found byte-for-byte equal to the frozen sources. A fresh namespace is allocated inside each loop iteration; the helpers have no cross-block mutable-module changes. The wrapper and every helper family have been read. The original system Python 3.13.5 extended replay exited 0 in {execution['elapsed_seconds']:.3f} seconds, with SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1. Its complete output is `primary_replay_extended.log`, SHA-256 `{execution['log_sha256']}`. The earlier three-source attempt used the bundled runtime and stopped before any mathematical check because SciPy was absent; that source, receipt and full traceback are preserved, as is its subsequent successful four-helper replay. No dependency was installed and no assertion or tolerance was weakened.

The exact three-source candidate, its executed four-helper primary and all then-current composition artifacts were copied before any extension edit to `pre_extension/`; INDEX.json maps original paths to content-identical recovery paths. The old note, primary and receipt hashes are respectively `17103b2c0c1c0d5a84f7e39ebed5de110857ea349140a666caa9e60e2e26af29`, `690be0f97d4b72ffd2360326c883148674ca355daddf09d278eeb6677d9ff7c5` and `9ad615753f62b8d2015a6f51d7447489b51e15e7559cbc6af675f3aed5d28526`. The current map includes exact old/new line edits that reconstruct both extended note and primary from those historical bytes. The successful five-helper replay is bound to the final extended source identities. This is author-evidence replay and composition bookkeeping, not a new independent continuum proof. The earlier independent joint review preceded this task's reading of the root author scale helper; its original scope is not rewritten.

Provenance and limits remain explicit: proposed_retained, actual conditional-support, upstream_support for the named microscopic-current consumer, no retained audit claim. The four component reviews found no consequential defect in their stated scope, but the new composition still awaits its own source-bound check. R13 now supplies the exact positive c0 lower bound for the selected outgoing datum at every fixed nonzero kappa, and R14 supplies the prepared-family limiting bound -c0/135. Earlier no-numerical-lower-bound statements are narrowed to the null-set argument or arbitrary unit fields. There is still no numerical W convergence rate, finite final-sign onset, arbitrary-preparation theorem, collision clock or many-body law. No repo file, frozen source, editable prompt or model setting was changed.
'''
(HERE/'COMPOSITION_REPORT.md').write_text(report)

development = '''# Composition development record

External files only. All mathematical sources and original reviews preserved.

- Read-only tooling: one accidental duplicated directory and one guessed primary filename failed; both corrected by exact source lookup. One aggregate source display truncated in the weighted middle; the omitted complete lines 71–214 were then read. None changed a file.
- The first assembled candidate ended one copied paragraph mid-sentence. The selected L fragment was narrowed to complete lines 169–177 before the full cold read; no source theorem was changed.
- The full cold read corrected an inherited `## 4` heading inside the new Section 13, added one blank section separator and the explicit inherited orbit definition z(tau)=exp(-i tau A_kappa)z, made the Q16 supremum interval explicit, and repaired two paragraph joins/grammar. Every final edit is represented in the builder/map. No mathematical display or estimate was changed.
- First primary attempt: the bundled interpreter lacked SciPy; the process exited before any mathematical control. Preserve `verify_and_replay_attempt01.py`, `primary_execution.json` and `primary_replay.log` as that attempt. Its identities are in the final receipt.
- Second attempt: same unchanged primary and helper bytes, original recorded system interpreter, exit 0. Full output read. No assertion or tolerance was weakened, and no helper mutation or package installation occurred.
- Before the newly authorized outgoing extension, the exact three-source candidate and complete composition packet were preserved under pre_extension with an original-to-recovery path index. That historical note/primary/receipt remains unchanged.
- The frozen outgoing source, full independent review/receipt and fifth helper were read. Complete R1–R14 was appended with source pointers converted to internal references and original headings demoted; every tagged display remains byte-identical. Earlier no-numerical-lower-bound language was narrowed to its historical/null-set or arbitrary-vector scope. A local-delta convention prevents confusing the edge margin with weak momentum. No new mathematics or spectral-edge work is included.
- The five-helper primary replay uses the same recorded system environment and source-identical old four blocks plus the exact fifth block, all in isolated namespaces. Full output read. No failure or helper change in this extension replay.
- Final source-only bookkeeping revalidates all exact fragments, 68 byte-identical tagged displays plus the two mapped G2/G3 restatements, exact edits from historical to extended outputs, every historical recovery hash, all helper literals, all source/review identities and 17 section headings. These are provenance controls, not independent scientific tests.
'''
(HERE/'DEVELOPMENT_LOG.md').write_text(development)
checkpoint = f'''# Frozen memory/current composition checkpoint

2026-10-11. External author assembly complete; no repository changes.

Final note SHA-256: `{identity(note)['sha256']}` ({identity(note)['lines']:,} lines).
Final primary SHA-256: `{identity(primary)['sha256']}` ({identity(primary)['lines']} lines).
Reconstructable source map: `{map_identity['sha256']}`.

All four proof arguments and exact required companion premises are composed. All five literal helper blocks ran successfully in isolated namespaces under the original system environment; the earlier bundled-Python missing-SciPy failure and successful four-helper run are preserved. Complete reading and original-vs-final evidence identities are in COMPOSITION_REPORT.md and receipt.json. The complete historical three-source composition is under pre_extension/ with an exact recovery index.

The final weighted-review dependency is resolved in the separate frozen joint addendum; original joint review/receipt are unchanged. New composition review, root repository packaging and any formal retained-status audit remain outside this task. The checked outgoing extension supplies its exact selected-datum c0 lower bound. No numerical weighted convergence rate, sign-onset time, arbitrary-preparation result or physical clock is inferred. The separate spectral-edge work is not included.

Recovery: SOURCE_COMPOSITION.json contains every exact source fragment and editorial chunk, plus exact line edits from pre_extension; build_publication.py checks all seven original source hashes and reconstructs the note and literal primary. Do not rewrite frozen originals or historical logs when replaying.
'''
(HERE/'CHECKPOINT.md').write_text(checkpoint)
bookkeeping = {
    'created_utc': now, 'tag_checks': tag_checks,
    'chunks_verified': len(mapping['chunks']), 'section_numbers': headings,
    'helper_literals_verified': mapping['primary']['helpers'],
    'outcome': 'All exact reconstruction/identity assertions passed; no new analytic test.',
}
(HERE/'final_identity_check.json').write_text(json.dumps(bookkeeping, indent=2)+'\n')

output_paths = [note, primary] + sorted(p for p in HERE.iterdir() if p.is_file() and p.name != 'receipt.json')
receipt = {
    'created_utc': now,
    'task': 'Self-contained memory -> weighted current -> joint growing-time and explicit selected-datum lower-bound publication composition',
    'role': 'Author composition only; new-composition review and retained-status audit remain separate.',
    'claim_id': mapping['claim_id'],
    'repository_names': [mapping['intended_repo_note'], mapping['intended_repo_primary']],
    'inputs': inputs, 'outputs': [identity(p) for p in output_paths],
    'frozen_source_preservation': 'Every listed input was rehashed unchanged at freeze. The original joint report and receipt were not edited.',
    'coverage': {
        'math': 'Complete M500 newly read; complete unchanged W339/G236/P859/D549/L457 readings reused, with all selected argument fragments refreshed. Complete outgoing R245 read. All changed arguments read in full.',
        'reviews': 'Complete memory329, weighted319 and weighted receipt474 read. Complete own joint252 review reused at unchanged identity; separate final dependency addendum. Complete outgoing review306 and receipt426 read; not an independent recertification or replay of that review.',
        'primary_import': 'All five local Kato extracted pages read; original pp.260 and 263 visually checked. No network request. General theorem remains explicitly imported.',
        'final_note': 'Complete 1316-line first assembled source cold-read, then all changes to its1320-line historical freeze. Full extension source and complete historical-to-extended diff, including new R1-R14 and all header/footer/limitation changes, read; final1556. 59 exact/literal chunks verified.',
        'runner': 'All five helper sources fully read (165+36+106+54+96 lines), all new wrapper code read, literal strings verified against originals, execution namespaces checked; no namespace interaction found.',
        'historical_limits': 'No claim of substantive review of every historical item in source receipts; no replay or certification of their mutation/Lean evidence.',
    },
    'successful_author_replay': execution,
    'failed_attempt': {'execution': identity(HERE/'primary_execution.json'), 'log': identity(HERE/'primary_replay.log'), 'reason': 'Bundled Python missing SciPy before mathematical controls.'},
    'replay_source_binding': 'Successful extended replay binds the exact current note/primary/map. Historical four-helper replay and its associated earlier note identities are preserved separately.',
    'historical_pre_extension': {'index': identity(HERE/'pre_extension/INDEX.json'), 'records_rechecked': len(historical['files']), 'frozen_receipt': identity(HERE/'pre_extension/receipt.json'), 'exact_note_primary_delta_reconstruction': True},
    'independence': 'Literal author control replay and deterministic bookkeeping do not constitute independent science. Existing component reviews retain their original chronology and scope. In particular the old joint independent review preceded reading the root scale helper, which was read now for author packaging.',
    'remaining_dependencies': ['New publication-composition independent check', 'Explicit companion physical/current and finite all-T comparison support', 'Imported Kato trace-class theorem with checked hypotheses', 'Formal audit before effective retained status'],
    'limitations': ['No new math beyond the four frozen source proofs; separate spectral-edge work excluded', 'Exact c0 bound applies to selected outgoing data, not arbitrary unit fields; no rate for W(t)-W_+', 'No numerical final-sign onset', 'One specified projected free-band family only', 'No physical collision clock, decoherence or many-body closure'],
    'repository_files_changed': [], 'editable_prompt_files_changed': [],
    'formal_audit_state_changed': False, 'network_actions': [], 'model_or_reasoning_changed': False,
    'receipt_scope': 'Identity/coverage record, excluding its own hash; not an audit or new independent scientific verdict.',
}
(HERE/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'note': identity(note), 'primary': identity(primary), 'map': map_identity,
                  'report': identity(HERE/'COMPOSITION_REPORT.md'), 'receipt': identity(HERE/'receipt.json')}, indent=2))
