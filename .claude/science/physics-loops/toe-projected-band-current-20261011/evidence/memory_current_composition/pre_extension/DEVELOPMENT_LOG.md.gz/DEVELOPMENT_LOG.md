# Composition development record

External files only. All mathematical sources and original reviews preserved.

- Read-only tooling: one accidental duplicated directory and one guessed primary filename failed; both corrected by exact source lookup. One aggregate source display truncated in the weighted middle; the omitted complete lines 71–214 were then read. None changed a file.
- The first assembled candidate ended one copied paragraph mid-sentence. The selected L fragment was narrowed to complete lines 169–177 before the full cold read; no source theorem was changed.
- The full cold read corrected an inherited `## 4` heading inside the new Section 13, added one blank section separator and the explicit inherited orbit definition z(tau)=exp(-i tau A_kappa)z, made the Q16 supremum interval explicit, and repaired two paragraph joins/grammar. Every final edit is represented in the builder/map. No mathematical display or estimate was changed.
- First primary attempt: the bundled interpreter lacked SciPy; the process exited before any mathematical control. Preserve `verify_and_replay_attempt01.py`, `primary_execution.json` and `primary_replay.log` as that attempt. Its identities are in the final receipt.
- Second attempt: same unchanged primary and helper bytes, original recorded system interpreter, exit 0. Full output read. No assertion or tolerance was weakened, and no helper mutation or package installation occurred.
- Final source-only bookkeeping revalidates all exact fragments, 54 byte-identical tagged displays plus the two mapped G2/G3 restatements, all helper literals, all source/review identities and 16 section headings. These are provenance controls, not independent scientific tests.
