#!/usr/bin/env python3
"""Deterministic external composition; never changes a frozen input."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
NOTE = S / 'FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md'
PRIMARY = S / 'excluded_walk_memory_current_2026_10_11.py'
SOURCES = {
    'M': ('EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md', 'b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c'),
    'W': ('EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md', '10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324'),
    'G': ('EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md', '4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278'),
    'P': ('FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md', 'ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969'),
    'D': ('EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md', 'b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876'),
    'L': ('EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md', '09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324'),
}
HELPERS = [
    ('MEMORY_CONTROLS_SOURCE', 'effective_memory/memory_controls.py', '10980b8195c33ac813f59632cc028a1dbd8a04e066930786dabea338ed162c4a'),
    ('MEAN_CONTROLS_SOURCE', 'effective_memory/mean_controls.py', '8376f00539c79b580b6c142b5b71b8d0d4ec39cd98f47e9577170e915d5b097c'),
    ('WEIGHTED_CONTROLS_SOURCE', 'weighted_memory/weighted_controls.py', '70807cce821d3e2eca3fc96cefd52fa1cfe83c4496801b9c9f2f7b9dd5108c24'),
    ('SCALE_CONTROLS_SOURCE', 'joint_scale_current/scale_controls.py', '1a71fb0d680630d0581fe4f982520d4bc3bc51a2649c2359815c3445c2b4d233'),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

inputs = {}
for key, (name, expected) in SOURCES.items():
    raw = (S / name).read_bytes()
    assert sha(raw) == expected, (name, sha(raw), expected)
    inputs[key] = {'name': name, 'sha256': expected, 'bytes': len(raw), 'lines': raw.decode().splitlines(keepends=True)}

chunks = []

def literal(text, reason):
    chunks.append({'kind': 'new_editorial_text', 'reason': reason, 'text': text})

def source(key, first, last, reason, edits=()):
    item = inputs[key]
    lines = item['lines']
    original = ''.join(lines[first-1:last])
    text = original
    edit_records = []
    for before, after in edits:
        count = text.count(before)
        assert count == 1, (key, first, last, before, count)
        text = text.replace(before, after, 1)
        edit_records.append({'before': before, 'after': after, 'occurrences': count})
    chunks.append({
        'kind': 'source_fragment', 'source_key': key, 'source': item['name'],
        'source_sha256': item['sha256'], 'first_line': first, 'last_line': last,
        'source_start_byte': len(''.join(lines[:first-1]).encode()),
        'source_end_byte_exclusive': len(''.join(lines[:last]).encode()),
        'original_text': original, 'original_sha256': sha(original.encode()),
        'edits': edit_records, 'reason': reason, 'text': text,
    })

literal('''---
claim_id: excluded_walk_memory_current_bounded_theorem_note_2026-10-11
claim_type: bounded_theorem
claim_scope: "For the supplied antisymmetric excluded Weyl pair and canonical compressed energy placement, prove the effective dressing's exact memory equation and absolutely continuous spectral measure, its positive weighted-current limit, and a joint growing-time current limit for one normalized projected positive-free-band packet family."
upstream_dependencies:
  - excluded_walk_projected_free_band_canonical_current_bounded_theorem_note_2026-10-11
  - excluded_walk_low_energy_energy_current_bounded_theorem_note_2026-10-11
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: upstream_support
reachability_to_target: supports
target_claim_id: null
target_blocker_text: "Construct controlled links from microscopic dynamics to macroscopic transport."
source_of_blocker_text: user_goal
artifact_role: theorem
next_trace_action: "Quantify the outgoing-state convergence or test additional specified preparations before using this coherent current result in a macroscopic transport argument."
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Exact effective memory and a joint growing-time canonical-current limit

**Date:** 2026-10-11

**Type:** bounded_theorem

**Status:** proposed_retained

Current surface status: conditional-support. The three source arguments have
completed selective independent mathematical checks at the identities recorded
in Section 16. This publication composition is new and still requires its own
source-bound check. No independent retained-status audit is claimed.

For each fixed nonzero kappa, the normalized physical dressing under the
bounded effective generator has an exact Volterra memory equation and an
absolutely continuous spectral measure. Its survival amplitude tends to zero.
An application of Kato's trace-class theorem on the same fixed Hilbert space
gives a unit-norm outgoing transverse datum and a strictly positive weighted
limit W_+. The specified canonical-current observable consequently has the
weighted limit proved below.

For the actual excluded walk, fix any 0<gamma<1/2. The final construction uses
the band parameter 0<lambda<=1/16, weak total-momentum scale delta=lambda^3,
an actual positive free [lambda,2lambda] packet with total-momentum center
lambda^3(1,1,1) and radius lambda^5, and one global contact projection and
normalization. At physical time t_lambda=lambda^(-(3+gamma)), each component
obeys

    Delta<J_a>/lambda^4
      =-W(lambda^(-gamma))/(12pi^2 I0)+O(lambda^(1/2-gamma))
      ->-W_+/(12pi^2 I0)<0,                    a=1,2,3.

The error estimates the difference from the moving W(lambda^(-gamma)). No
rate for W(t)-W_+, numerical positive lower value of W_+, or numerical onset
for the final sign is proved. This is a constructed coherent preparation and
current change in the supplied generator clock. It is not a collision clock,
Markov law, monotonic decay, arbitrary-preparation result or many-body closure.

## 1. Supplied model and physical effective space

The [projected-band current companion](EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md)
supplies the physical contract and the finite all-time comparison used in
Section 12. Its frozen composition source has SHA-256
`ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969`.
The [parent low-energy walk theorem](EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md),
SHA-256 `9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401`,
fixes the supplied walk and selected additive symmetric energy placement.
Their proposed status is not promoted by this composition. No stationary
hard-core scattering or Cook-regularity theorem is needed here.

All relative-torus and local total-momentum integrals use dq/(2pi)^3 and
dK/(2pi)^3. The local chart is K=k_1+k_2, q=(k_1-k_2)/2. Even singlet and
odd triplet coefficients implement antisymmetry, with no extra exchange or
half-torus factor. The lattice, generator clock, pair sector, contact rule,
coordinates and canonical placement remain supplied premises.

''', 'New publication metadata, scope, exact existing conclusion, dependency contract and notation bridge; no new mathematics.')
source('P', 96, 167, 'Physical operator, entire kernel and cone bounds; the companion proof is reproduced here.')
literal('\n', 'Paragraph separation.')
source('M', 48, 80, 'Exact effective block and dressing evolution conventions.', [
    ('The parent proves', 'The preceding calculation proves'),
    ('All these operators have the domains specified in the parent:', 'All these operators have the following full-space domains:'),
    ('The new theorem concerns', 'The effective evolution is'),
])
literal('''
For completeness, the transverse-block identity is
(I-nn^T)(d cross u)=(d dot n)n cross u for n dot u=0.
B zeta is already transverse and <zeta,B zeta>=0 pointwise. These facts
verify both entries g and <g| of E2 and their signs. The entire physical
zero projection is Pi of Q3; the auxiliary constant singlet remains absent.
The nonzero coupling also has the following quantitative bound.

''', 'Restates the companion Q6 transverse-block proof at P211–218 and introduces unchanged D21.')
source('D', 306, 321, 'Nonzero coupling bound and full reflection/Cauchy-Schwarz proof needed by E7.')
literal('\n', 'Paragraph separation.')
source('M', 82, 182, 'Complete Volterra, finite-time transfer, scalar resolvent, Laplace and field-density arguments E4–E12.', [
    ('the parent bound on `||epsilon g||^2`', 'D21 for `||epsilon g||^2`'),
    ('For `kappa=k(1,1,1)`, the checked parent identity remains', 'For `kappa=k(1,1,1)`, the identity D20 proved in Section 10 gives'),
])
literal('''The delta in Sections 4–6 is a spectral edge margin with 0<delta<b.
It is local to those sections. The later weak-momentum parameter delta
has a separate definition in the original-walk comparison.

''', 'Disambiguates two inherited local parameter names without altering formulas.')
source('M', 183, 405, 'Complete cone-density, local Poisson, endpoint, ac, Fourier, finite-horizon and finite-bath proofs E13–E28.')
literal('''## 8. Same-space trace-class comparison

''', 'Publication section heading.')
source('W', 43, 64, 'Exact primary Kato import including forward/reverse limits and complete initial/final subspaces.')
literal('\n', 'Paragraph separation.')
source('W', 73, 122, 'Complete operator/domain matching and essential ac dressing premise W2–W5.', [
    ('The parent supplies', 'E2 supplies'),
    ('The parent proves `||g||>0`', 'D21 proves `||g||>0`'),
])
literal('\n', 'Blank line before the new section heading.')
source('W', 124, 174, 'Complete norm-one outgoing-state and weighted-limit argument W6–W9.', [
    ('## 3. Unit-norm outgoing datum and weighted limit', '## 9. Unit-norm outgoing datum and weighted limit'),
])
literal('''
## 10. The specified canonical-current observable

The current is fixed by the additive symmetric placement
e_x^0=(1/2) sum_i {Pi_(i,x),h_i}, e_x=P e_x^0 P and its energy first
moment D_a=P D0,a P, where
D0,a=(1/2)({X_(1,a),h_1}+{X_(2,a),h_2}). The companion Section 5 proves
the following bounded extension of i[H_D,D_a] on a common finite-support
core. Its unbounded dipole is not applied to the singular dressing vector.

''', 'Names the exact physical placement and its companion bounded-current derivation, reproducing J1 premises.')
source('D', 218, 261, 'Actual bounded current, exact weak-momentum remainder, full effective compression and scalar cancellation D12–D16.', [
    ("Use the source's bounded canonical current extension, derived from its\nspecified compressed local energy densities:", 'The bounded canonical current is'),
    ('The lower-right entry retains the exact canonical\ncancellation proved in the frozen probe:', 'The lower-right entry retains the exact canonical\ncancellation:'),
])
literal('''
For z=(u,alpha) in Z, the D15 quadratic form is

''', 'Introduces the exact existing D18 expression without importing an unused fixed-time proof reference.')
source('D', 273, 274, 'Dressing/transverse cross term retained exactly (D18).')
literal('\n', 'Paragraph separation.')
source('D', 282, 287, 'Full-zero-space trace identity D19.', [
    ("The full-zero-space trace identity differs from the frozen probe's\nsinglet/longitudinal identity. Since sum_a r_a=0 and", 'On the entire physical zero space, sum_a r_a=0 and'),
    ('sum_a m_a=3-2epsilon^2, D15 gives, for any normalized (u,alpha),', 'sum_a m_a=3-2epsilon^2. Thus D15 gives, for any normalized (u,alpha),'),
])
literal('\nWrite z(tau)=exp(-i tau A_kappa)z for the following cyclic argument.\n\n', 'Restores the local orbit definition D263 that was outside the selected current fragment.')
source('D', 293, 301, 'Proper cyclic symmetry and complete effective diagonal-current identity D20.')
literal('\n', 'Paragraph separation.')
source('W', 178, 213, 'Complete actual effective-current limit and strict coordinate weights W10–W12.', [
    ('The checked parent current compression is', 'The compression D15 is'),
    ("the parent's proper cyclic\nsymmetry", 'the proper cyclic\nsymmetry just proved'),
])
literal('''
## 11. Ordered limits for a fixed dressing preparation

In this section lambda denotes only the weak-momentum parameter; the band
parameter used from Section 12 onward is separate. The companion's finite
spectral-cutoff comparison implies, for each fixed z in Z and fixed finite T,
sup_(|t|<=T)||exp[-it H_D(lambda kappa)/lambda]z-exp(-itA)z||->0.
It is a strong fixed-vector statement, not uniform convergence over Z's unit
ball. All current operators below are the bounded extensions in Section 10.

''', 'Exact fixed-vector hypothesis from companion D11, plus parameter-scope and bounded-domain clarification.')
source('M', 408, 419, 'Ordered unweighted limit and limit-order limitation E29.', [
    ('the\nchecked parent theorem proves', 'the\ncompanion proves'),
    ('The parent source explicitly exhibits failure of uniform state\nconvergence over the zero-space unit ball; its vector-dependent compact-time\nbound supplies no automatic interchange with the new infinite-time limit.', "The earlier source exhibits failure of uniform state convergence over the\nzero-space unit ball; the companion's vector-dependent compact-time bound\nsupplies no automatic interchange with this infinite-time limit."),
])
literal('\n', 'Paragraph separation.')
source('W', 217, 259, 'Complete ordered actual-current limit and separated error W13–W15.', [
    ("The parent's fixed-vector", "The companion's fixed-vector"),
    ("and use the parent's", 'and use D14 with'),
    ('No joint schedule, finite-lambda onset, rate, or reversed\norder is justified here. The physical walk time is t/lambda. There is no\nassertion of global trace class after a total-momentum direct integral.\nThese conclusions are for the stated fixed-total-momentum fiber; a new\nnormalizable envelope statement is not included in this extension.', 'These ordered estimates alone justify no joint schedule, finite-lambda\nonset, rate, or reversed order. The physical walk time is t/lambda. There\nis no assertion of global trace class after a total-momentum direct integral.\nThe joint theorem below instead uses the finite all-time comparison and a\nspecific actual positive-free-band preparation with a global envelope.'),
])
literal('''
## 12. Actual band preparation and finite comparison hypotheses

From this point lambda is the free-band parameter, delta is the independent
weak-momentum parameter, and tau is effective time, with physical time
t=tau/delta. Fix kappa0=(1,1,1) and b=|kappa0|=sqrt(3). All absolute
continuity and weighted conclusions above apply at this fixed kappa0.

''', 'Parameter separation and the joint theorem fixed fiber.')
source('P', 294, 352, 'Exact density, contact weight, preparation normalization and uniform band bounds L6–L8, Q12–Q13.')
literal('\n', 'Paragraph separation.')
source('L', 169, 177, 'Exact leading band-weight and contact-loss asymptotics L10, with analytic integration explanation.')
literal('''
The O(lambda^2) remainder follows uniformly from the displayed Jacobian
on 0<E<=7lambda/4. Together with n_lambda^2=1-O(lambda^3), these identities
give the following form used by the joint comparison.

''', 'Explains the already-present L10 to G1 algebra; no new asymptotic claim.')
source('G', 68, 77, 'Joint preparation bounds including the exact leading coefficient G1.', [
    ('The checked sources give', 'Q13 and L10 give'),
])
literal('''
The finite all-time estimates used next are proved in Sections 3–4 of the
projected-band companion. We reproduce their exact hypotheses and formulas;
the present proof does not substitute a fixed-time limit at a growing T.
Use H_*=H_D(0), F, Pi and Q=P-Pi from Q3.

''', 'Explicit companion proof boundary permitted by the composition task.')
source('P', 169, 175, 'Exact weak-momentum Taylor remainder and evolution Q5.')
literal('''
For 0<lambda<=1/16, a=5/4, x=Q chi_lambda and
0<sigma<=min(1/2,a lambda/2), define

    C_lambda=2/(a lambda n_lambda)+beta_lambda sqrt(I0)/n_lambda.

The cutoff inverse in the companion retains the singlet mean subtraction
and the longitudinal contact term. It yields

''', 'Reproduces full Q14 cutoff domain and C_lambda definition; refers to complete companion proof.')
source('P', 414, 418, 'Complementary spectral estimate and explicit C_lambda bound Q15.')
literal('''
For the dressing orbit, the companion's longitudinal cutoff inverse gives

    sup_(|tau|<=T)||E_sigma Q B_kappa exp(-i tau A_kappa)zeta||
        <=(7/2)(b^2 T/sqrt(I0))sqrt(sigma), 0<sigma<=1/2.

Together with its two finite evolution comparisons, this proves the next
estimate for every finite T>0, every delta>0 and the cutoff domain just
specified. Here u(tau)=F exp(-i tau A_kappa)zeta, as in E3. In particular,
T has not been fixed before this bound is applied. The supremum defining
e_perp is over |tau|<=T.

''', 'Reproduces Q11 and all domains as exact companion inputs to Q16; no new bound.')
source('P', 488, 496, 'Complete all-T transverse error bound Q16 and no-phase-average mechanism.')
literal('''
The actual-current trace needed with this comparison also holds on the full
physical space, not just Z:

''', 'Introduces exact full-space trace input.')
source('P', 593, 622, 'Full-space current trace and energy-square conservation bound Q18–Q19, with complete short proof and symmetry.', [
    ('At the diagonal kappa0', 'At the diagonal kappa0=(1,1,1)'),
])
literal('''
The operator-norm remainder D14 and the trace identity are time independent.
They can therefore be combined with Q16 on any finite interval, as done
next. They require no unbounded observable applied to chi_lambda.

## 13. A growing effective-time comparison and actual current

The fixed-fiber conclusions W7 and W9 give exactly

    ||exp(-i tau A)zeta-(exp(-i tau D)u_+,0)||->0,          (G2)
    W(tau)=||epsilon u(tau)||^2->W_+=||epsilon u_+||^2,
    ||u_+||=1,                 0<W_+<3.                  (G3)

The proof is Sections 8–9: the reverse wave-operator limit and E23 supply
the norm-one datum, and epsilon^2 commutes with D. Nothing here assumes
a rate for this limit or a uniform positive lower weight over unit vectors.

''', 'Replaces duplicate G79–106 with precisely the same statements and the complete proof already included at W1–W9.')
source('G', 110, 171, 'Complete scale substitution and both-sided actual-current comparison G4–G7.', [
    ('## 4. Actual current comparison, valid at every finite time', '### Actual current comparison, valid at every finite time'),
])
literal('''
## 14. A genuine global actual free-band preparation

The following finite-K estimates, proved by direct projector comparison and
bounded Duhamel in the companion, are used before taking the direct integral.

''', 'Explicit global preparation input boundary.')
source('P', 727, 754, 'Actual ++ projector, support, two normalizations and full proof of 16|K|/lambda preparation estimate.')
literal('''
On |kappa-kappa0|<=1/10 and 0<delta<=1, the exact current gives
||J_a(delta kappa)/delta||<=4 and Lipschitz constant 4 in kappa. Indeed the
multiplication term costs |kappa-kappa0|. The two rank-one terms together
cost at most (sqrt(3)+delta/2)|kappa-kappa0|, using
||h||<=sqrt(6),
||h'_a(delta kappa)-h'_a(delta kappa0)||<=delta|kappa-kappa0|/(2sqrt(2)),
||h(delta kappa)-h(delta kappa0)||<=delta|kappa-kappa0|/sqrt(2), and
||h'_a(delta kappa0)||<=delta/(2sqrt(2)). Their sum is less than four.
The norm bound follows from
(1+sqrt(3))|kappa_a|<=1.1(1+sqrt(3))<4.
Also ||H_D(K)-H_D(K0)||<=|K-K0|, so for every finite tau,

    ||U_(delta,kappa)(tau)-U_(delta,kappa0)(tau)||
         <=|tau||kappa-kappa0|.                           (B20)

This is the same bounded-Duhamel estimate used in G9; unlike the companion's
single-time application, it is kept here at its arbitrary finite time.

''', 'Reproduces companion P756–774 finite norm/Lipschitz proof, with the all-finite-time form already stated/proved in G194–199.')
source('G', 175, 222, 'Complete global normalized construction, exact projected momentum law and joint limit G8–G10.', [
    ('as in B19-B20.', 'by Q28 and B20.'),
])
literal('''
## 15. Distinct finite controls and preserved limitations

The finite-bath recurrence E27–E28 remains a counterexample to inferring
continuum decay from the block form alone. A separate exactly solvable
continuous toy checks the outgoing convention and weighted expectation
without purporting to solve the continuum walk:

''', 'Introduces existing weighted toy as finite support only.')
source('W', 268, 292, 'Complete unrelated continuous toy and analytic scope W16–W17.')
literal('\n', 'Paragraph separation.')
source('M', 435, 442, 'Preserved failed routes and distinct ac/endpoint/weight obligations, now within the complete composition.')
literal('\n', 'Paragraph separation.')
source('W', 326, 332, 'Essential ac and onto-ac premises plus absence of numerical coercivity.')
literal('''
The joint theorem resolves the previously open weighted and growing-time
interfaces only for the stated construction. Still open here are a rate for
the outgoing-state comparison or W(t)-W_+, a certified numerical positive
value of W_+, and extensions to arbitrary projected positive-band data.
There is no claim about optimal exponents, fixed-density gases, the regime
K comparable to lambda, monotonic current or generic unitary dissipation.
The earlier leakage and nonuniform-state-convergence findings remain
preserved research; they are not broadened into impossibility claims.

The separate outgoing-resolvent/coercivity extension is not a source or
conclusion of this publication candidate.

## 16. Evidence, exact sources and publication status

The primary is `scripts/excluded_walk_memory_current_2026_10_11.py`.
It embeds the four complete frozen author helpers byte-for-byte, verifies
their identities, and executes each in a fresh namespace. Its source blocks
are memory_controls.py, mean_controls.py, weighted_controls.py and
scale_controls.py from the source map. They retain their original exact
symbolic, rational and explicitly floating controls; no helper has been
rewritten to mirror this composition.

The memory controls check direct Schur inverses, finite-bath evolution and
Volterra convolution, moment recurrences, eliminated-field quadratures,
cone constants and selected geometry samples, and a Poisson interval bound.
The mean controls check the integration constant and an unrelated continuous
sinc measure. The weighted controls check the rank-two trace norm, adjoint
convention, continuous toy and current cross term. The scale controls check
the stated exponent budgets and an exact nonuniform normalization fixture.
These are author controls. Their replay is not an independent proof of
absolute continuity, Kato completeness, or the infinite-time walk theorem.
The uniform cone and singular-measure arguments are the analytic proofs in
Sections 4–5, and the growing-time conclusion uses the finite estimates in
Sections 12–14.

The reconstructable `memory_current_composition/SOURCE_COMPOSITION.json`
records every retained line range and literal editorial addition. Source
identities are:

| Source | SHA-256 | Role |
|---|---|---|
| Effective memory source | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Complete E1–E29 proof chain and recurrence limitation |
| Weighted memory source | `10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324` | Complete W1–W17 import, scattering, current and toy arguments |
| Joint-scale source | `4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278` | G1–G10 scale, current and global-preparation proof |
| Projected-band companion source | `ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969` | Physical contract, all-time finite estimate and explicit band/current inputs |
| Degenerate source | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Reproduced current compression, cyclic argument and nonzero coupling proof |
| Long-time source | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Reproduced leading band-weight and contact-loss asymptotics |

The complete memory review is
`c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0`;
the complete weighted review is
`a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484`;
the complete joint review is
`2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6`.
The latter's originally pending weighted-review dependency is updated by a
separate source-bound addendum, leaving the frozen original report unchanged.
These reviews found no consequential defect within their exact scopes. The
weighted review covers the fixed-fiber and ordered-limit result; the joint
review separately covers the all-time substitution, current errors and
single global normalization. Neither source status nor a passing helper is
an independent retained-status audit of this new publication composition.

The exact primary Kato PDF has SHA-256
`12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5`.
The theorem and reverse-limit/onto-ac argument were checked in the original
pages 260 and 263. The general trace-class theorem is an explicit imported
mathematical result. It is not reproved by the finite toy or controls.

The external composition receipt records source identities, complete changed
argument coverage and actual primary replay separately from historical
evidence. New mutation runs, Lean coverage and formal audit outcomes must be
reported by their own execution records; none is inferred here. The supplied
physical contract, actual-current placement and companion finite-estimate
dependency remain explicit conditional support.
''', 'New publication evidence/status footer; resolves only already-reviewed component dependencies and preserves exact limitations.')

offset = 0
line = 1
for i, chunk in enumerate(chunks):
    chunk['index'] = i
    chunk['output_start_byte'] = offset
    chunk['output_first_line'] = line
    raw = chunk['text'].encode()
    offset += len(raw)
    line += chunk['text'].count('\n')
    chunk['output_end_byte_exclusive'] = offset
    chunk['output_last_line'] = line - (1 if chunk['text'].endswith('\n') else 0)
    chunk['output_sha256'] = sha(raw)
note_text = ''.join(c['text'] for c in chunks)
NOTE.write_text(note_text)

wrapper = '''#!/usr/bin/env python3
"""Literal author finite controls for the memory/current publication candidate.

Four frozen helpers execute in separate namespaces. This replay supplies exact
finite algebra and explicitly floating controls, not a new independent proof
of the continuum spectral, wave-operator, or growing-time theorem.
"""
import hashlib
import json

AUDIT_TIMEOUT_SEC = 180
AUDIT_INPUT_PATHS = [
    "docs/EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]

'''
helper_records = []
for variable, relative, expected in HELPERS:
    raw = (S / relative).read_bytes()
    assert sha(raw) == expected
    text = raw.decode()
    assert "'''" not in text
    block = variable + " = r'''" + text + "'''\n\n"
    first = wrapper.count('\n') + 1
    wrapper += block
    helper_records.append({'variable': variable, 'source': relative, 'sha256': expected,
                           'bytes': len(raw), 'lines': len(text.splitlines()),
                           'primary_first_line': first, 'primary_last_line': wrapper.count('\n')-1})
wrapper += 'AUTHOR_BLOCKS = [\n'
for variable, relative, expected in HELPERS:
    wrapper += f'    ({relative!r}, {expected!r}, {variable}),\n'
wrapper += ''']


def main():
    for name, expected_sha256, source in AUTHOR_BLOCKS:
        actual = hashlib.sha256(source.encode("utf-8")).hexdigest()
        assert actual == expected_sha256, (name, actual, expected_sha256)
        print(json.dumps({"author_block": name, "sha256": actual, "phase": "begin"}), flush=True)
        namespace = {"__name__": "__main__", "__file__": "<frozen-author:" + name + ">"}
        exec(compile(source, namespace["__file__"], "exec"), namespace, namespace)
        print(json.dumps({"author_block": name, "phase": "complete"}), flush=True)
    print(json.dumps({"status": "PASS", "isolated_author_blocks": len(AUTHOR_BLOCKS),
                      "scope": "literal author finite controls; no independent continuum proof"}), flush=True)


if __name__ == "__main__":
    main()
'''
PRIMARY.write_text(wrapper)

mapping = {
    'schema': 'exact-fragment-composition-v1',
    'role': 'External author publication composition, no new science and no audit verdict.',
    'claim_id': 'excluded_walk_memory_current_bounded_theorem_note_2026-10-11',
    'intended_repo_note': 'docs/EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md',
    'intended_repo_primary': 'scripts/excluded_walk_memory_current_2026_10_11.py',
    'inputs': {key: {k: v for k, v in item.items() if k != 'lines'} for key, item in inputs.items()},
    'note': {'path': NOTE.name, 'sha256': sha(NOTE.read_bytes()), 'bytes': NOTE.stat().st_size, 'lines': len(note_text.splitlines())},
    'primary': {'path': PRIMARY.name, 'sha256': sha(PRIMARY.read_bytes()), 'bytes': PRIMARY.stat().st_size, 'lines': len(wrapper.splitlines()), 'helpers': helper_records},
    'reconstruction': 'Concatenate chunk.text in index order. For each source fragment, verify original_sha256 and apply each unique before/after edit in order to original_text; it must equal text. Full original input hashes are supplied. New text is literal and explained. This map therefore reconstructs the note without depending on mutable source paths.',
    'chunks': chunks,
    'selection_and_omissions': {
        'M': 'Retains all E1–E29 equations and complete load-bearing proof, plus finite-bath and failed-route limitations. Omits original header/source inventory and historical status/evidence prose; replaces open weighted/growing-time status with already-completed W/G results for the specified family only.',
        'W': 'Retains all W1–W17 and complete arguments. Original source inventory, execution history and then-pending review language are replaced by current source-bound evidence/status. Ordered-limit warning is scoped to those estimates alone so it does not contradict the later specific joint construction.',
        'G': 'Retains all G1–G10 and the complete scale/current/global preparation proof. G2–G3 duplicate Kato argument is replaced by exactly the same formulas and internal reference to the complete W proof above. Original pending-review/source-status text is replaced by final review identities and new-composition status.',
        'P': 'Reproduces physical kernel/cone premises, exact preparation, all-T Q16 inputs, full-space current trace and finite-K projector proof. Complete cutoff/evolution and canonical-core derivations remain in the allowed companion dependency, with all formulas and domains actually used reproduced here.',
        'D': 'Adds unchanged D12–D16, D18–D21 argument fragments needed to make actual effective-current compression, cyclic identity and coupling lower bound reviewable without citing a scratch source as sole proof.',
        'L': 'Adds unchanged L10 and its integration explanation. The earlier leakage/state-uniformity results remain preserved external research, not new corollaries of this composition.',
    },
    'new_extension_excluded': 'Root outgoing-resolvent/coercivity extension is not imported.',
    'independence': 'This is author composition. Exact helper embeddings and replay do not acquire independence. Frozen component reviews retain their own precise scope; the new composition awaits source-bound review.',
}
(OUT / 'SOURCE_COMPOSITION.json').write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + '\n')
assert ''.join(c['text'] for c in mapping['chunks']).encode() == NOTE.read_bytes()
for chunk in mapping['chunks']:
    if chunk['kind'] == 'source_fragment':
        replay = chunk['original_text']
        for edit in chunk['edits']:
            assert replay.count(edit['before']) == edit['occurrences'] == 1
            replay = replay.replace(edit['before'], edit['after'], 1)
        assert replay == chunk['text']
print(json.dumps({'note': mapping['note'], 'primary': mapping['primary'], 'chunks': len(chunks)}, indent=2))
