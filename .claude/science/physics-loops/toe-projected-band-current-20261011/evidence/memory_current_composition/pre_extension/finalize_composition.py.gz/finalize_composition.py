#!/usr/bin/env python3
"""Freeze external composition identities and coverage; no scientific verdict."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
S = HERE.parent

def identity(path):
    raw = path.read_bytes()
    out = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    if path.suffix in ('.py', '.md', '.json', '.log', '.txt'):
        out['lines'] = len(raw.splitlines())
    return out

mapping = json.loads((HERE/'SOURCE_COMPOSITION.json').read_text())
note = S/mapping['note']['path']
primary = S/mapping['primary']['path']
assert identity(note)['sha256'] == mapping['note']['sha256']
assert identity(primary)['sha256'] == mapping['primary']['sha256']
assert ''.join(c['text'] for c in mapping['chunks']).encode() == note.read_bytes()
inputs = []
for item in mapping['inputs'].values():
    ident = identity(S/item['name'])
    assert ident['sha256'] == item['sha256']
    inputs.append(ident)
for chunk in mapping['chunks']:
    if chunk['kind'] != 'source_fragment':
        continue
    raw = (S/chunk['source']).read_bytes()[chunk['source_start_byte']:chunk['source_end_byte_exclusive']]
    assert raw.decode() == chunk['original_text']
    changed = raw.decode()
    for edit in chunk['edits']:
        assert changed.count(edit['before']) == edit['occurrences'] == 1
        changed = changed.replace(edit['before'], edit['after'], 1)
    assert changed == chunk['text']
    assert changed.encode() == note.read_bytes()[chunk['output_start_byte']:chunk['output_end_byte_exclusive']]

tag_checks = []
def code_blocks(text):
    blocks = []
    lines = text.splitlines(keepends=True)
    block = ''
    for line in lines+['']:
        if line.startswith('    '):
            block += line
        elif block:
            blocks.append(block)
            block = ''
    return blocks

note_blocks = code_blocks(note.read_text())
for key, prefix, count in [('M', 'E', 29), ('W', 'W', 17), ('G', 'G', 10)]:
    original_blocks = code_blocks((S/mapping['inputs'][key]['name']).read_text())
    for i in range(1, count+1):
        tag = f'({prefix}{i})'
        before = [b for b in original_blocks if tag in b]
        after = [b for b in note_blocks if tag in b]
        assert len(before) == len(after) == 1, (tag, len(before), len(after))
        if tag not in ('(G2)', '(G3)'):
            assert before[0] == after[0], tag
        tag_checks.append({'tag': tag, 'comparison': 'byte-identical tagged display block' if tag not in ('(G2)', '(G3)') else 'same implication restated together, with complete W1-W9 proof included; mapped literal bridge'})

tree = ast.parse(primary.read_text())
assignments = {n.targets[0].id: n.value for n in tree.body
               if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
for helper in mapping['primary']['helpers']:
    raw = ast.literal_eval(assignments[helper['variable']]).encode()
    assert raw == (S/helper['source']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == helper['sha256']
    inputs.append(identity(S/helper['source']))

reviews = {
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md': 'c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0',
    'EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md': 'a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484',
    'EXCLUDED_WALK_JOINT_SCALE_CURRENT_REVIEW.md': '2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6',
    'joint_scale_review/receipt.json': '49bd1d8872a07aea1e5266cb2f07f3ea2aff4d9a9602f7a141e0051037d92b80',
    'excluded_walk_weighted_review/independent_review_receipt.json': '74990de59ab11a8011f4164ce689b0f80153d261c073c486f47b78a1beaf1a28',
    'joint_scale_review/DEPENDENCY_ADDENDUM.md': '8ef5245b3301a19338eedfc8f3f98610b6d3162538b80fbe01bfaf27e5a1273a',
    'joint_scale_review/dependency_addendum_receipt.json': '151aeb2e37648b0ef468e40538b4d0ce11707a1fe3a704239b946e559a5d82bb',
    'excluded_walk_review/kato_1957_primary.pdf': '12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5',
}
for name, expected in reviews.items():
    ident = identity(S/name)
    assert ident['sha256'] == expected
    inputs.append(ident)
parent = S.parent/'walk_worktree/docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md'
parent_identity = identity(parent)
assert parent_identity['sha256'] == '9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401'
inputs.append(parent_identity)

execution = json.loads((HERE/'primary_execution_attempt02.json').read_text())
assert execution['returncode'] == 0
assert execution['primary_sha256'] == identity(primary)['sha256']
assert execution['log_sha256'] == identity(Path(execution['log']))['sha256']
headings = re.findall(r'^## (\d+)\.', note.read_text(), flags=re.M)
assert headings == [str(i) for i in range(1,17)]

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
map_identity = identity(HERE/'SOURCE_COMPOSITION.json')
report = f'''# Memory/current publication composition report

2026-10-11. External author assembly, with no repository edits or audit decision.

The publication candidate is `FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md` (1,320 lines), SHA-256 `{identity(note)['sha256']}`. The primary is `excluded_walk_memory_current_2026_10_11.py` (408 lines), SHA-256 `{identity(primary)['sha256']}`. The claim ID and intended repository names are exactly those in `SOURCE_COMPOSITION.json`, SHA-256 `{map_identity['sha256']}`.

The note contains the complete memory proof, including the uniform cone lower bound, strip Poisson bound excluding singular measure, separate endpoint argument and finite-bath recurrence; the complete Kato hypothesis/subspace check and weighted/current limits; and the complete growing-time error and globally normalized preparation argument. It reproduces the actual current compression, cyclic symmetry, coupling lower bound and leading band-weight calculation. The companion remains an explicit dependency for the finite spectral-cutoff/evolution estimates and canonical-current core derivation; every formula and domain actually used is reproduced. There is no sole scratch-file proof reference for a newly composed step.

The map contains 57 ordered exact-source or literal-editorial chunks, with input identities, source line/byte ranges, unique before/after edits and output byte ranges. Concatenating them reconstructs the final note exactly. All E1–E29 and W1–W17 tagged display blocks are byte-identical to their sources, as are G1 and G4–G10. G2–G3 are restated together with the already-included full W1–W9 proof. Every substantive argument of the three sources is retained; obsolete source inventories and then-pending status prose are replaced by the final scope and evidence. The separate outgoing-resolvent/coercivity extension is excluded.

Complete reading coverage: the 500-line memory source and all four helpers were read in this task. Complete unchanged readings of the 339-line weighted source, 236-line joint source, 859-line companion, 549-line degenerate source and 457-line long-time source were reused and the selected arguments refreshed. The full 329-line memory review, 319-line final weighted review and 474-line weighted receipt were read. The frozen original 252-line joint review remains unchanged; the separate dependency addendum binds the now-final weighted review. All five locally extracted Kato pages were read and original pp.260/263 visually checked. The entire 1,316-line assembled candidate was cold-read, followed by all changed final passages, including the restored orbit definition, explicit supremum domain and corrected heading/fragment joins. No incomplete or truncated display is counted as coverage.

All four embedded helper strings were independently extracted from the primary AST and found byte-for-byte equal to the frozen sources. A fresh namespace is allocated inside each loop iteration; the helpers have no cross-block mutable-module changes. The wrapper and every helper family have been read. The original system Python 3.13.5 replay exited 0 in {execution['elapsed_seconds']:.3f} seconds, with SymPy 1.14.0, NumPy 2.4.4 and SciPy 1.17.1. Its complete output is `primary_replay_attempt02.log`, SHA-256 `{execution['log_sha256']}`. The first attempt used the bundled runtime and stopped before any mathematical check because SciPy was absent; that source, receipt and full traceback are preserved. No dependency was installed and no assertion or tolerance was weakened.

The successful replay records the pre-final-prose candidate note identity; its primary bytes are identical to the final primary. The final note/map reconstruction and source identities were refreshed separately after those prose edits. Re-executing unchanged mathematics was unnecessary. This is author-evidence replay and composition bookkeeping, not a new independent continuum proof. The earlier independent joint review preceded this task's reading of the root author scale helper; its original scope is not rewritten.

Provenance and limits remain explicit: proposed_retained, actual conditional-support, upstream_support for the named microscopic-current consumer, no retained audit claim. The three component reviews found no consequential defect in their stated scope, but the new composition still awaits its own source-bound check. There is no numerical W convergence rate, positive W lower constant, final-sign onset, arbitrary-preparation theorem, collision clock or many-body law. No repo file, frozen source, editable prompt or model setting was changed.
'''
(HERE/'COMPOSITION_REPORT.md').write_text(report)

development = '''# Composition development record

External files only. All mathematical sources and original reviews preserved.

- Read-only tooling: one accidental duplicated directory and one guessed primary filename failed; both corrected by exact source lookup. One aggregate source display truncated in the weighted middle; the omitted complete lines 71–214 were then read. None changed a file.
- The first assembled candidate ended one copied paragraph mid-sentence. The selected L fragment was narrowed to complete lines 169–177 before the full cold read; no source theorem was changed.
- The full cold read corrected an inherited `## 4` heading inside the new Section 13, added one blank section separator and the explicit inherited orbit definition z(tau)=exp(-i tau A_kappa)z, made the Q16 supremum interval explicit, and repaired two paragraph joins/grammar. Every final edit is represented in the builder/map. No mathematical display or estimate was changed.
- First primary attempt: the bundled interpreter lacked SciPy; the process exited before any mathematical control. Preserve `verify_and_replay_attempt01.py`, `primary_execution.json` and `primary_replay.log` as that attempt. Its identities are in the final receipt.
- Second attempt: same unchanged primary and helper bytes, original recorded system interpreter, exit 0. Full output read. No assertion or tolerance was weakened, and no helper mutation or package installation occurred.
- Final source-only bookkeeping revalidates all exact fragments, 54 byte-identical tagged displays plus the two mapped G2/G3 restatements, all helper literals, all source/review identities and 16 section headings. These are provenance controls, not independent scientific tests.
'''
(HERE/'DEVELOPMENT_LOG.md').write_text(development)
checkpoint = f'''# Frozen memory/current composition checkpoint

2026-10-11. External author assembly complete; no repository changes.

Final note SHA-256: `{identity(note)['sha256']}` (1,320 lines).
Final primary SHA-256: `{identity(primary)['sha256']}` (408 lines).
Reconstructable source map: `{map_identity['sha256']}`.

All three proof arguments and exact required companion premises are composed. All four literal helper blocks ran successfully in isolated namespaces under the original system environment; the bundled-Python missing-SciPy failure is preserved. Complete reading and original-vs-final evidence identities are in COMPOSITION_REPORT.md and receipt.json.

The final weighted-review dependency is resolved in the separate frozen joint addendum; original joint review/receipt are unchanged. New composition review, root repository packaging and any formal retained-status audit remain outside this task. No numerical weighted decay rate, lower W constant, arbitrary-preparation result or physical clock is inferred. The separate outgoing-resolvent/coercivity extension is not included.

Recovery: SOURCE_COMPOSITION.json contains every exact source fragment and editorial chunk; build_publication.py checks all six original source hashes and reconstructs the note and literal primary. Do not rewrite frozen originals or historical logs when replaying.
'''
(HERE/'CHECKPOINT.md').write_text(checkpoint)
bookkeeping = {
    'created_utc': now, 'tag_checks': tag_checks,
    'chunks_verified': len(mapping['chunks']), 'section_numbers': headings,
    'helper_literals_verified': mapping['primary']['helpers'],
    'outcome': 'All exact reconstruction/identity assertions passed; no new analytic test.',
}
(HERE/'final_identity_check.json').write_text(json.dumps(bookkeeping, indent=2)+'\n')

output_paths = [note, primary] + sorted(p for p in HERE.iterdir() if p.is_file() and p.name != 'receipt.json')
receipt = {
    'created_utc': now,
    'task': 'Self-contained memory -> weighted current -> joint growing-time publication composition',
    'role': 'Author composition only; new-composition review and retained-status audit remain separate.',
    'claim_id': mapping['claim_id'],
    'repository_names': [mapping['intended_repo_note'], mapping['intended_repo_primary']],
    'inputs': inputs, 'outputs': [identity(p) for p in output_paths],
    'frozen_source_preservation': 'Every listed input was rehashed unchanged at freeze. The original joint report and receipt were not edited.',
    'coverage': {
        'math': 'Complete M500 newly read; complete unchanged W339/G236/P859/D549/L457 readings reused, with all selected argument fragments refreshed. All changed arguments read in full.',
        'reviews': 'Complete memory329, weighted319 and weighted receipt474 read. Complete own joint252 review reused at unchanged identity; separate final dependency addendum.',
        'primary_import': 'All five local Kato extracted pages read; original pp.260 and 263 visually checked. No network request. General theorem remains explicitly imported.',
        'final_note': 'Complete 1316-line first assembled source cold-read, then every final changed passage and added definition/domain read; final1320. 57 exact/literal chunks verified.',
        'runner': 'All four helper sources fully read (165+36+106+54 lines), all new wrapper code read, literal strings verified against originals, execution namespaces checked; no namespace interaction found.',
        'historical_limits': 'No claim of substantive review of every historical item in source receipts; no replay or certification of their mutation/Lean evidence.',
    },
    'successful_author_replay': execution,
    'failed_attempt': {'execution': identity(HERE/'primary_execution.json'), 'log': identity(HERE/'primary_replay.log'), 'reason': 'Bundled Python missing SciPy before mathematical controls.'},
    'replay_source_binding': 'Primary bytes unchanged after successful run. Only note prose/heading/definition joins changed after replay; final map and all identities were revalidated without repeating unchanged controls.',
    'independence': 'Literal author control replay and deterministic bookkeeping do not constitute independent science. Existing component reviews retain their original chronology and scope. In particular the old joint independent review preceded reading the root scale helper, which was read now for author packaging.',
    'remaining_dependencies': ['New publication-composition independent check', 'Explicit companion physical/current and finite all-T comparison support', 'Imported Kato trace-class theorem with checked hypotheses', 'Formal audit before effective retained status'],
    'limitations': ['No new math or outgoing-resolvent/coercivity extension', 'No rate for W(t)-W_+ or numerical positive W lower bound', 'No numerical final-sign onset', 'One specified projected free-band family only', 'No physical collision clock, decoherence or many-body closure'],
    'repository_files_changed': [], 'editable_prompt_files_changed': [],
    'formal_audit_state_changed': False, 'network_actions': [], 'model_or_reasoning_changed': False,
    'receipt_scope': 'Identity/coverage record, excluding its own hash; not an audit or new independent scientific verdict.',
}
(HERE/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'note': identity(note), 'primary': identity(primary), 'map': map_identity,
                  'report': identity(HERE/'COMPOSITION_REPORT.md'), 'receipt': identity(HERE/'receipt.json')}, indent=2))
