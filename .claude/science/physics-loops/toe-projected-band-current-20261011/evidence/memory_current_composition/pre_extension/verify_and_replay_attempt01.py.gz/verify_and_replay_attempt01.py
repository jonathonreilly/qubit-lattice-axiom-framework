#!/usr/bin/env python3
"""Identity/reconstruction controls and one literal-author replay, not new physics."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import subprocess
import time

HERE = Path(__file__).resolve().parent
S = HERE.parent
PYTHON = '/Users/jonreilly/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

mapping = json.loads((HERE/'SOURCE_COMPOSITION.json').read_text())
source_checks = []
for key, item in mapping['inputs'].items():
    path = S/item['name']
    raw = path.read_bytes()
    assert sha(raw) == item['sha256']
    source_checks.append({'source_key': key, 'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)})

note = S/mapping['note']['path']
reconstructed = ''.join(c['text'] for c in mapping['chunks']).encode()
assert reconstructed == note.read_bytes()
assert sha(reconstructed) == mapping['note']['sha256']
for chunk in mapping['chunks']:
    if chunk['kind'] != 'source_fragment':
        continue
    original = (S/chunk['source']).read_bytes()[chunk['source_start_byte']:chunk['source_end_byte_exclusive']]
    assert original == chunk['original_text'].encode()
    assert sha(original) == chunk['original_sha256']
    transformed = original.decode()
    for edit in chunk['edits']:
        assert transformed.count(edit['before']) == edit['occurrences'] == 1
        transformed = transformed.replace(edit['before'], edit['after'], 1)
    assert transformed == chunk['text']
    assert note.read_bytes()[chunk['output_start_byte']:chunk['output_end_byte_exclusive']] == transformed.encode()

primary = S/mapping['primary']['path']
raw_primary = primary.read_bytes()
assert sha(raw_primary) == mapping['primary']['sha256']
tree = ast.parse(raw_primary)
assignments = {node.targets[0].id: node.value for node in tree.body
               if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
literal_checks = []
for item in mapping['primary']['helpers']:
    literal = ast.literal_eval(assignments[item['variable']]).encode()
    original = (S/item['source']).read_bytes()
    assert literal == original
    assert sha(literal) == item['sha256']
    literal_checks.append({'source': item['source'], 'sha256': sha(literal), 'bytes': len(literal)})
main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
loop = next(node for node in main.body if isinstance(node, ast.For))
namespace_assignment = next(node for node in loop.body if isinstance(node, ast.Assign)
                            and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'namespace')
assert isinstance(namespace_assignment.value, ast.Dict)
assert {ast.literal_eval(k) for k in namespace_assignment.value.keys} == {'__name__', '__file__'}
execution = next(node for node in loop.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                 and isinstance(node.value.func, ast.Name) and node.value.func.id == 'exec')
assert [arg.id for arg in execution.value.args[1:]] == ['namespace', 'namespace']

log = HERE/'primary_replay.log'
assert not log.exists(), 'Preserve prior replay; choose a new explicit run path.'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic()
with log.open('wb') as stream:
    result = subprocess.run([PYTHON, str(primary)], cwd=S, stdout=stream, stderr=subprocess.STDOUT,
                            timeout=180, check=False)
elapsed = time.monotonic()-begin
record = {
    'created_utc': started,
    'task': 'Exact external composition identity controls and literal author primary replay',
    'command': [PYTHON, str(primary)], 'cwd': str(S), 'timeout_seconds': 180,
    'returncode': result.returncode, 'elapsed_seconds': elapsed,
    'note_sha256': sha(note.read_bytes()), 'primary_sha256': sha(raw_primary),
    'map_sha256': sha((HERE/'SOURCE_COMPOSITION.json').read_bytes()),
    'source_checks': source_checks, 'literal_helper_checks': literal_checks,
    'namespace_check': 'AST verifies a newly constructed dict inside each iteration and exec with that same dict as globals and locals. Complete helper reading found no cross-block imported-module mutations.',
    'reconstruction': 'Every exact source range, unique edit, output byte range and full concatenation verified.',
    'log': str(log), 'log_sha256': sha(log.read_bytes()),
    'independence': 'Author helper replay plus deterministic composition bookkeeping; not new independent mathematics.',
}
(HERE/'primary_execution.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
assert result.returncode == 0
