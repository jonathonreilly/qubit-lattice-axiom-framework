from pathlib import Path
import ast,hashlib,json,subprocess,time,shutil
S=Path(__file__).resolve().parent;W=S.parent/'walk_worktree'
N=W/'docs/EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md'
P=W/'scripts/excluded_walk_memory_current_2026_10_11.py'
for src,dst in [(S/'FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md',N),(S/'excluded_walk_memory_current_2026_10_11.py',P)]:
 if dst.exists():assert dst.read_bytes()==src.read_bytes()
 else:shutil.copyfile(src,dst)
D=S/'memory_current_primary_mutations';D.mkdir(exist_ok=True)
original=P.read_text();cases=[]
for folder,helper in [('effective_memory','memory_controls.py'),('weighted_memory','weighted_controls.py'),('outgoing_resolvent','outgoing_controls.py')]:
 data=json.loads((S/folder/'mutation_manifest.json').read_text())
 if isinstance(data,dict):data=data['mutations']
 for row in data:cases.append({'block':folder+'/'+helper,'name':folder+'_'+row['name'],'old':row['old'],'new':row['new'],'expected':row['intended_assertion']})
cases.extend([
 {'block':'effective_memory/mean_controls.py','name':'mean_kernel_half','old':'displayed = 2*C*(1+sp.log(2*b*T))/T','new':'displayed = C*(1+sp.log(2*b*T))/T','expected':'mean_kernel_constant'},
 {'block':'joint_scale_current/scale_controls.py','name':'joint_delta_power','old':'delta=lam**3; sigma=lam**2;','new':'delta=lam**2; sigma=lam**2;','expected':'assert exact_relaxed<=four_term<=275*leading'},
 {'block':'joint_scale_current/scale_controls.py','name':'global_normalization_removed','old':'physical=[w*n/normalization for w,n in zip(weights,survival)]','new':'physical=[w*n for w,n in zip(weights,survival)]','expected':'assert sum(physical)==1'}
])
manifest={'primary_path':str(P),'primary_sha256':hashlib.sha256(original.encode()).hexdigest(),'method':'One semantic replacement inside one frozen helper, plus only its expected SHA metadata refresh so a failed content fingerprint does not substitute for the intended mathematical control. Actual complete-primary source copies executed; original unchanged.','mutations':[]}
for case in cases:
 block=(S/case['block']).read_text(); assert block.count(case['old'])==1
 mutated_block=block.replace(case['old'],case['new']);oldsha=hashlib.sha256(block.encode()).hexdigest();newsha=hashlib.sha256(mutated_block.encode()).hexdigest()
 assert original.count(block)==1 and original.count(oldsha)==1
 mutated=original.replace(block,mutated_block).replace(oldsha,newsha)
 path=D/('mutant_'+case['name']+'.py');path.write_text(mutated)
 start=time.monotonic();result=subprocess.run(['/opt/homebrew/opt/python@3.13/bin/python3.13',str(path)],cwd=W,text=True,capture_output=True,timeout=180)
 log=D/('mutant_'+case['name']+'.log');log.write_text(result.stdout+result.stderr)
 record={**case,'source':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'helper_sha256_before':oldsha,'helper_sha256_after':newsha,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'timeout_seconds':180,'intended_failure':result.returncode!=0 and case['expected'] in result.stderr}
 manifest['mutations'].append(record);(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(case['name'],result.returncode,record['intended_failure'],flush=True)
 assert record['intended_failure']
assert P.read_text()==original
print('Completed',len(cases),'actual primary semantic controls plus disclosed hash metadata updates.')
