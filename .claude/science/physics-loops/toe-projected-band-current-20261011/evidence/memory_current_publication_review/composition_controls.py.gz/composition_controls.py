#!/usr/bin/env python3
"""Independent composition and actual-wrapper controls, not author math replay.

Inputs: the four frozen publication artifacts and their declared source files.
No author builder/checker is imported or executed. The actual primary module
is loaded with its main guard disabled; only fresh synthetic block bodies are
then executed through its unchanged main function. Timeout: 30 seconds.
"""

from pathlib import Path
from collections import Counter
from contextlib import redirect_stdout
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import io
import json
import re
import traceback


BASE = Path(__file__).resolve().parents[1]
DEST = Path(__file__).resolve().parent
PACK = BASE / "memory_current_composition"
EXPECTED = {
    "FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md": "c05465cee9acb7ee1bc9b0296b4fd5546432bd8188043194b1701a2d3654ef87",
    "excluded_walk_memory_current_2026_10_11.py": "b5cfe4af2e2e56f6a531afaa36c19daded1003d91b3a861ebe177ba87a0ebc33",
    "memory_current_composition/SOURCE_COMPOSITION.json": "ffe3df5cd8633fa927bbe78e7fbfbeffd7c96efc30dbc969d0c0bf24a31e0fa2",
    "memory_current_composition/receipt.json": "9dea961421ca868bd4def5eecb5c45982b5c5a421ed49c945f31cac8dd2f2ea6",
}
CHECKS = []


def check(label, condition):
    assert bool(condition), label
    CHECKS.append(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=sha(raw), bytes=len(raw), lines=len(raw.splitlines()))


for name, expected in EXPECTED.items():
    check("frozen input " + name, identity(BASE / name)["sha256"] == expected)
note_path = BASE / "FINAL_EXCLUDED_WALK_MEMORY_CURRENT_NOTE.md"
primary_path = BASE / "excluded_walk_memory_current_2026_10_11.py"
note_bytes = note_path.read_bytes()
note_text = note_bytes.decode()
primary_text = primary_path.read_text()
mapping = json.loads((PACK / "SOURCE_COMPOSITION.json").read_text())
author_receipt = json.loads((PACK / "receipt.json").read_text())

sources = {}
for key, item in mapping["inputs"].items():
    path = BASE / item["name"]
    raw = path.read_bytes()
    check("source input identity " + key, sha(raw) == item["sha256"] and len(raw) == item["bytes"])
    sources[key] = raw

offset = 0
fragments = []
pieces = []
for index, chunk in enumerate(mapping["chunks"]):
    text = chunk["text"]
    raw = text.encode()
    check(f"chunk {index} index", chunk["index"] == index)
    check(f"chunk {index} exact output slice", note_bytes[offset:offset+len(raw)] == raw)
    check(f"chunk {index} byte bounds", chunk["output_start_byte"] == offset and chunk["output_end_byte_exclusive"] == offset+len(raw))
    first = note_bytes[:offset].count(b"\n") + 1
    last = first + len(text.splitlines()) - 1
    check(f"chunk {index} line bounds", (chunk["output_first_line"], chunk["output_last_line"]) == (first, last))
    check(f"chunk {index} output digest", sha(raw) == chunk["output_sha256"])
    if chunk["kind"] == "source_fragment":
        source = sources[chunk["source_key"]]
        source_lines = source.splitlines(keepends=True)
        low, high = chunk["first_line"] - 1, chunk["last_line"]
        original = b"".join(source_lines[low:high])
        source_start = len(b"".join(source_lines[:low]))
        check(f"chunk {index} original source bytes", original.decode() == chunk["original_text"])
        check(f"chunk {index} original digest", sha(original) == chunk["original_sha256"])
        check(f"chunk {index} source identity", sha(source) == chunk["source_sha256"])
        check(f"chunk {index} source byte bounds", chunk["source_start_byte"] == source_start and chunk["source_end_byte_exclusive"] == source_start+len(original))
        edited = original.decode()
        for n, edit in enumerate(chunk["edits"]):
            check(f"chunk {index} edit {n} unique", edited.count(edit["before"]) == edit["occurrences"] == 1)
            edited = edited.replace(edit["before"], edit["after"])
        check(f"chunk {index} exact edited result", edited == text)
    else:
        check(f"chunk {index} explicit editorial kind", chunk["kind"] == "new_editorial_text")
    fragments.append({k: chunk[k] for k in ["index", "kind", "source_key", "first_line", "last_line", "output_first_line", "output_last_line", "edits", "reason"] if k in chunk})
    pieces.append(raw)
    offset += len(raw)
check("full note reconstructed", b"".join(pieces) == note_bytes and offset == len(note_bytes))
check("17 ordered section headings", re.findall(r"^## (\d+)\.", note_text, re.M) == [str(i) for i in range(1, 18)])

# Compare equation paragraphs independently of the author mapping's ranges.
def tagged_blocks(text):
    result = {}
    for block in text.split("\n\n"):
        for tag in re.findall(r"\(((?:E|W|G|R)\d+)\)", block):
            if any(line.startswith("    ") for line in block.splitlines()):
                check("unique tagged block " + tag, tag not in result)
                result[tag] = block
    return result


published_blocks = tagged_blocks(note_text)
formula_checks = []
for key, prefix, count in [("M", "E", 29), ("W", "W", 17), ("G", "G", 10), ("R", "R", 14)]:
    old_blocks = tagged_blocks(sources[key].decode())
    for n in range(1, count+1):
        tag = prefix + str(n)
        check("tag exists " + tag, tag in old_blocks and tag in published_blocks)
        identical = old_blocks[tag] == published_blocks[tag]
        if tag not in ["G2", "G3"]:
            check("exact tagged mathematical block " + tag, identical)
        formula_checks.append(dict(tag=tag, byte_identical=identical, scope="Internal restatement backed by complete W proof" if tag in ["G2", "G3"] else "Exact source paragraph"))

# Literal AST values must match both independent source bytes and metadata.
tree = ast.parse(primary_text, filename=str(primary_path))
literal_nodes = {stmt.targets[0].id: stmt.value for stmt in tree.body if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name)}
literal_records = []
for helper in mapping["primary"]["helpers"]:
    value = ast.literal_eval(literal_nodes[helper["variable"]])
    raw = (BASE / helper["source"]).read_bytes()
    check("literal helper " + helper["variable"], value.encode() == raw and sha(raw) == helper["sha256"] and len(raw) == helper["bytes"])
    check("literal helper line count " + helper["variable"], len(raw.splitlines()) == helper["lines"])
    assignment = next(stmt for stmt in tree.body if isinstance(stmt, ast.Assign) and isinstance(stmt.targets[0], ast.Name) and stmt.targets[0].id == helper["variable"])
    check("literal primary line bounds " + helper["variable"], (assignment.lineno, assignment.end_lineno) == (helper["primary_first_line"], helper["primary_last_line"]))
    literal_records.append(identity(BASE / helper["source"]))

# This executes imports/definitions/string literals only, with no author block.
module = {"__name__": "publication_review_inspection", "__file__": str(primary_path)}
startup_stdout = io.StringIO()
with redirect_stdout(startup_stdout):
    exec(compile(tree, str(primary_path), "exec"), module, module)
check("primary import guard prevents author execution", startup_stdout.getvalue() == "")
check("five production block records", len(module["AUTHOR_BLOCKS"]) == 5)
for (name, expected, body), helper in zip(module["AUTHOR_BLOCKS"], mapping["primary"]["helpers"]):
    check("production block correspondence " + name, name == helper["source"] and expected == helper["sha256"] and body == ast.literal_eval(literal_nodes[helper["variable"]]))
main_ast = next(stmt for stmt in tree.body if isinstance(stmt, ast.FunctionDef) and stmt.name == "main")
loop = next(stmt for stmt in main_ast.body if isinstance(stmt, ast.For))
check("fresh dict constructed inside actual loop", any(isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Dict) and any(isinstance(target, ast.Name) and target.id == "namespace" for target in stmt.targets) for stmt in loop.body))


def synthetic_record(name, body):
    return name, sha(body.encode()), body


fixtures = []
for number in range(3):
    name = f"review_fixture_{number}.py"
    body = f'''assert __name__ == "__main__"
assert __file__ == "<frozen-author:{name}>"
assert "private_token" not in globals()
private_token = {number + 11}
def own_global():
    return private_token
assert own_global() == {number + 11}
if __name__ == "__main__":
    print("REVIEW_FIXTURE_COMPLETE_{number}")
'''
    fixtures.append(synthetic_record(name, body))
module["AUTHOR_BLOCKS"] = fixtures
success_stdout = io.StringIO()
with redirect_stdout(success_stdout):
    module["main"]()
success = success_stdout.getvalue()
check("three synthetic bodies execute in order", [line for line in success.splitlines() if line.startswith("REVIEW_FIXTURE_COMPLETE")] == [f"REVIEW_FIXTURE_COMPLETE_{i}" for i in range(3)])
check("helper globals do not leak into wrapper module", "private_token" not in module and "own_global" not in module)
check("actual final success records synthetic block count", json.loads(success.splitlines()[-1])["isolated_author_blocks"] == 3)

failures = []
bad_cases = [
    ("hash_mismatch", ("review_bad_hash.py", "0" * 64, "print('SHOULD_NOT_EXECUTE')\n"), AssertionError),
    ("body_assertion", synthetic_record("review_assert.py", "assert False, 'deliberate assertion fixture'\n"), AssertionError),
    ("body_exception", synthetic_record("review_runtime.py", "raise RuntimeError('deliberate runtime fixture')\n"), RuntimeError),
    ("compile_failure", synthetic_record("review_syntax.py", "if:\n"), SyntaxError),
]
for label, bad_block, expected_exception in bad_cases:
    module["AUTHOR_BLOCKS"] = [fixtures[0], bad_block, fixtures[2]]
    captured = io.StringIO()
    failure = None
    try:
        with redirect_stdout(captured):
            module["main"]()
    except expected_exception:
        failure = traceback.format_exc()
    check("expected actual wrapper failure " + label, failure is not None)
    out = captured.getvalue()
    check("failure aborts later helper " + label, "REVIEW_FIXTURE_COMPLETE_2" not in out)
    check("failure prevents final PASS " + label, '"status": "PASS"' not in out)
    failures.append(dict(case=label, stdout=out, traceback=failure, expected_exception=expected_exception.__name__))
    print("EXPECTED_WRAPPER_FAILURE", label)
    print(out, end="")
    print(failure, end="")

# Historical recovery is checked from map-relative paths, not assumed mutable
# original paths; source/primary recovery is an extra reconstruction route.
history = mapping["pre_extension"]
index_path = PACK / history["index"]
check("historical recovery index identity", identity(index_path)["sha256"] == history["index_sha256"])
index = json.loads(index_path.read_text())
recovery = {}
for row in index["files"]:
    path = Path(row["recovery_path"])
    check("recovery file " + path.name, identity(path)["sha256"] == row["sha256"] and path.stat().st_size == row["bytes"])
    recovery[row["original_path"]] = path
history_checks = []
for current_path, edits_key, digest_key in [(note_path, "note_exact_edits", "note_sha256"), (primary_path, "primary_exact_edits", "primary_sha256")]:
    old_path = recovery[str(current_path)]
    check("historical identity " + current_path.name, identity(old_path)["sha256"] == history[digest_key])
    lines = old_path.read_text().splitlines(keepends=True)
    edits = history[edits_key]
    for item in reversed(edits):
        low, high = item["old_first_line_zero_based"], item["old_end_line_exclusive"]
        check("historical exact edit " + current_path.name + " " + str(low), "".join(lines[low:high]) == item["old_text"])
        lines[low:high] = item["new_text"].splitlines(keepends=True)
    check("historical reconstruction " + current_path.name, "".join(lines) == current_path.read_text())
    history_checks.append(dict(current=str(current_path), recovery=identity(old_path), exact_edit_count=len(edits)))

author_records = []
for row in author_receipt["inputs"] + author_receipt["outputs"]:
    record = identity(Path(row["path"]))
    check("author receipt identity " + row["path"], record["sha256"] == row["sha256"] and record["bytes"] == row["bytes"])
    author_records.append(record)
replay = author_receipt["successful_author_replay"]
check("successful author replay is exact current primary", replay["primary_sha256"] == EXPECTED[primary_path.name] and replay["note_sha256"] == EXPECTED[note_path.name] and replay["map_sha256"] == EXPECTED["memory_current_composition/SOURCE_COMPOSITION.json"] and replay["returncode"] == 0)
raw_log = Path(replay["log"]).read_bytes()
check("complete author replay log identity", sha(raw_log) == replay["log_sha256"])
parsed_events = []
for line in raw_log.decode().splitlines():
    try:
        event = json.loads(line)
    except ValueError:
        continue
    if "author_block" in event:
        parsed_events.append((event["author_block"], event["phase"]))
expected_events = [(h["source"], phase) for h in mapping["primary"]["helpers"] for phase in ["begin", "complete"]]
check("recorded production replay completed all five blocks in order", parsed_events == expected_events)

result = dict(
    checked_utc=datetime.now(timezone.utc).isoformat(),
    scope="Composition bytes, inherited formula identity, actual-wrapper synthetic execution and preserved author evidence; not continuum proof or author mathematical replay.",
    checks=CHECKS,
    counts=dict(total=len(CHECKS),chunks=len(fragments),source_fragments=sum(c["kind"]=="source_fragment" for c in fragments),source_substitutions=sum(len(c.get("edits",[])) for c in fragments),tagged_blocks=len(formula_checks),literal_helpers=len(literal_records)),
    direct_inputs=[identity(BASE / name) for name in EXPECTED],
    source_fragments=fragments,
    tagged_formula_checks=formula_checks,
    literal_helpers=literal_records,
    synthetic_success_stdout=success,
    expected_wrapper_failures=failures,
    historical_reconstructions=history_checks,
    author_receipt_records=author_records,
    author_math_helpers_executed=False,
    metadata_validation_is_independent_science=False,
)
(DEST / "composition_controls.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print("SUCCESS", json.dumps(result["counts"]))
print("No author mathematical helper or builder was executed.")
