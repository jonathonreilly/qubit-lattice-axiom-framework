#!/usr/bin/env python3
"""Exact author controls for the regulated outgoing formula and constants.

The continuum proof is in the note. The finite bath intentionally violates
the absolutely continuous scattering premise and has no unit outgoing datum.
"""
from fractions import Fraction as F
import sympy as s


def check(name, condition):
    assert bool(condition), name
    print('EXACT', name)


def zero(expr):
    return s.simplify(expr) == 0


z = s.symbols('z')
h = s.symbols('h', positive=True)
D = s.diag(-1, 1)
g = s.Matrix([s.Rational(1, 2), s.Rational(1, 2)])
A = D.row_join(g).col_join(g.T.row_join(s.zeros(1, 1)))
zeta = s.Matrix([0, 0, 1])
eta_g = (g.T*g)[0]
Sigma = (g.T*(z*s.eye(2)-D).inv()*g)[0]
M = 1/(z-Sigma)
check('finite Schur resolvent', zero(M-((z*s.eye(3)-A).inv())[2, 2]))
check('finite even bath', zero(Sigma-z/(2*(z*z-1))))
check('finite energy second moment', zero((zeta.T*A*A*zeta)[0]-eta_g))
check('finite scalar spectral decomposition',
      zero(M-2/(3*z)-z/(3*(z*z-s.Rational(3, 2)))))

# Integrate the explicit scalar spectral decomposition, with the causal sign.
omega = s.sqrt(s.Rational(3, 2))
u_abel = []
for j, energy in enumerate((-1, 1)):
    integrated = -s.I*g[j]*(s.Rational(2, 3)/(h-s.I*energy)
        +s.Rational(1, 6)/(h-s.I*(energy-omega))
        +s.Rational(1, 6)/(h-s.I*(energy+omega)))
    candidate = g[j]*M.subs(z, energy+s.I*h)
    check('Abel causal sign channel '+str(j), zero(integrated-candidate))
    u_abel.append(candidate)
norm2 = s.factor(sum(s.conjugate(v)*v for v in u_abel))
check('finite bath has zero Abel outgoing norm', s.limit(norm2, h, 0) == 0)
check('finite dressing retains a point atom',
      s.limit(z*M, z, 0) == s.Rational(2, 3))
check('positive regulator finite norm', norm2.subs(h, 1) > 0)
check('positive regulator contraction fixture', norm2.subs(h, 1) < 1)
print('FINITE_BATH_NORM', norm2)

# A nontrivial two-dimensional transverse helicity decomposition.
J = s.Matrix([[0, -s.I], [s.I, 0]])
coupling = s.I*s.Matrix([s.Rational(3, 5), s.Rational(4, 5)])
Pplus, Pminus = (s.eye(2)+J)/2, (s.eye(2)-J)/2
check('helicity cross term absent',
      (coupling.conjugate().T*Pplus*Pminus*coupling)[0] == 0)
weight_plus = (coupling.conjugate().T*Pplus*coupling)[0]
weight_minus = (coupling.conjugate().T*Pminus*coupling)[0]
claimed_each_helicity_weight = s.Rational(1, 2)
check('helicity half measure', weight_plus == weight_minus == claimed_each_helicity_weight)
check('even measure resolvent conjugacy',
      zero(M.subs(z, -1+s.I*h)+s.conjugate(M.subs(z, 1+s.I*h))))

# These algebraic margins are distinct from the analytic symmetry proof R8.
symmetry_complement = F(1)-F(1, 3)
energy_moment_ceiling = F(2, 3)
check('permutation complement factor', symmetry_complement == energy_moment_ceiling)
interior_cutoff = F(7, 8)
m0 = 1-energy_moment_ceiling/interior_cutoff**2
check('interior mass exact', m0 == F(19, 147))
check('interior mass strictly positive', 0 < m0 < 1)

# Retain pi^2 and I0 symbolically until the last rational relaxation.
pi2, I0, b, chi = s.symbols('pi2 I0 b chi', positive=True)
C_squared = s.Integer(32768)**2*pi2*I0**2/(b*b*chi**3)
cone_coefficient = s.simplify(C_squared*b*b/(4*I0))
claimed_cone_coefficient = 2**37*pi2*I0
check('cone coefficient exact powers',
      zero(cone_coefficient.subs(chi, s.Rational(1, 8))-claimed_cone_coefficient))
K0 = 90*2**34
check('cone rational relaxation',
      claimed_cone_coefficient.subs({pi2:10, I0:s.Rational(9, 8)}) == K0)
rstar = m0/(2*K0)
c0 = m0**3/(8*K0*K0)
check('valid positive cone radius', 0 < rstar < F(1, 2))
check('interior mass after cone removal', m0-K0*rstar == m0/2)
check('weighted mass constant', rstar*rstar*m0/2 == c0)
check('published rational constant',
      c0 == F(6859, 60752858276421362793738298982400))
check('readable conservative decimal', c0 > F(1128, 1000)*F(1, 10**28))
check('canonical current denominator bound', 12*10*F(9, 8) == 135)
print('RATIONAL_BOUNDS', {'K0':K0, 'm0':str(m0), 'rstar':str(rstar),
                           'c0':str(c0), 'current_gap':str(c0/135)})
print('Complete author controls; no continuum theorem is proved by this finite bath.')
