# Pre-helper reconstruction of the outgoing-resolvent extension

2026-10-11. Written before reading or executing the author's outgoing helper,
its failed first implementation, logs or mutations. The complete root-authored
245-line target was read: `EXCLUDED_WALK_OUTGOING_RESOLVENT_DRAFT.md`, SHA-256
`58a96a049701667e673bde1acf98e5346356483101654b3464fe11e94fd02c21`.
This reconstruction is independent of the helper, not blinded to the note.
The reviewer previously authored the memory and weighted-scattering premises;
reusing those premises is not an independent re-review of their proofs.

## Analytic reconstruction

1. R1-R3 specify the existing fixed physical space, not a new scattering
   hypothesis inferred from decay. Pointwise `J=i n cross` satisfies
   `J^2=Q_tr=I_3-n n^T`; restricted to a transverse fiber this is the identity.
   The individual helicity projections need not preserve the odd global
   field space: they exchange under q -> -q. Both f and g change sign, so
   the full R6 sum is odd. D=fJ itself preserves that space.
2. R4 follows by the standard direct split of the exponential average at a
   fixed T. It uses the strong outgoing comparison R3 and supplies no rate.
3. At fixed h>0 the double Bochner integral has absolute norm majorant
   ||g||/h. For a scalar energy E,
   integral_0^infinity exp(i(z-E)s) ds = i/(z-E), Im(z)>0.
   Hence the preceding -i gives +(z-E)^(-1). The sign and upper half-plane
   in R5 agree with M(z)=<zeta,(z-A)^(-1)zeta>.
4. Since g is i times a real transverse vector, g*Jg=0 and the two
   helicity weights are each G/2. The even spectral measure gives
   M(-x+ih)=-conj(M(x+ih)). Orthogonality gives R6. For bounded real even
   m, the quadratic-form difference is at most
   ||m||_infinity (||u_h||+||u_+||)||u_h-u_+||, proving R7.
   No real-axis boundary formula, dominated limit or regulator error rate
   has been used.
5. Expanding G and reflecting one sine coordinate kills each mixed
   kappa_i kappa_j term. Dropping cos^2, then using permutations and
   sum n_j^2=1, gives eta_g <= (2/3)b^2. The singular integrals are bounded
   by integral epsilon^(-2)=4 I0, finite in three dimensions.
6. The block equation gives <g,u>=i a'. Thus
   ||(A-A0)psi||^2=eta_g |a|^2+|a'|^2 -> 0. The compact absolutely
   continuous dressing spectral measure supplies a' -> 0 as well as
   a -> 0. Conservation of ||A psi|| and bounded-D scattering comparison
   then give ||D u_+||^2=eta_g. No unbounded-domain argument is needed.
7. D^2=f^2 on transverse fibers. Markov/Chebyshev at 7b/8 gives an
   interior norm mass at least 1-(2/3)/(7/8)^2=19/147.
8. Memory E20 is a uniform upper-half-plane estimate: for delta=b/8,
   |x|<=7b/8 and 0<h<=b/16,
   |M(x+ih)|<=2^15 pi I0/[b(1/8)^(3/2)]. Combining this with
   G<=b^2/(4 I0 epsilon^2) and the cone integral <=r gives
   ||Q_r R u_h||^2<=2^37 pi^2 I0 r<=90*2^34 r.
   The bounded, even projections permit the same bound on u_+ by strong
   convergence. This is precisely where no boundary-value interchange is
   required.
9. Taking r=m0/(2K0) leaves at least m0/2 norm mass with epsilon>=r.
   Thus W_+>=m0^3/(8 K0^2). The displayed integer fraction and strict
   decimal relaxation still need exact independent arithmetic below.
   The cancellation of b proves a uniform bound on this selected outgoing
   family at each fixed nonzero kappa, not a uniform convergence time as
   kappa -> 0. It is not coercivity on arbitrary unit transverse vectors.
10. The complete joint-scale G1-G10 source and its independent review have
    been read. The original all-finite-T estimate, amplitude-sensitive
    current quadratic form, actual post-projection global weights and
    powers delta=lambda^3, sigma=lambda^2, T=lambda^(-gamma), eta=lambda^2
    match R14. The new step is then W(T)->W_+ and
    12 pi^2 I0 <=135. No rate for the first convergence or explicit sign
    onset follows. R14 depends on the separate G composition; R1-R13 do not.

## Independent controls to implement before author-helper inspection

- Solve an actual finite matrix Sylvester equation
  hX-iDX+iXA=hP_F, which independently represents the Abel average;
  compare X zeta with the two-helicity evaluation of M(D+ih)g.
  Test causal sign and half-plane alterations. This finite bath is an
  algebra fixture, not a continuum absolute-continuity model.
- Use full three-dimensional cross-product matrices to check transverse
  projections, g*Jg, helicity factor and physical parity, keeping the
  distinction between pointwise fibers and the global odd space explicit.
- Derive the reflection cancellation and rational coefficient chain with
  exact arithmetic, including the final c0 fraction and decimal comparison.
- Retain the finite-bath counterexample: its rational M vanishes at the
  bath energies as h -> 0, so the Abel datum can tend to zero when R3 fails.

No consequential new defect is identified at this stage. This is a
checkpoint rather than the final review; exact execution, source hashes,
the full final report and the evidence receipt remain to be completed.
