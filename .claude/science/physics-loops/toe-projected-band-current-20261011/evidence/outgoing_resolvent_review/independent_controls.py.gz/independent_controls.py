#!/usr/bin/env python3
"""Independent finite/algebra controls for R1-R14; no continuum simulation.

Inputs: exact rational matrices and symbolic variables declared below.
External inputs: none. No author helper is imported or executed.
Suggested timeout: 120 seconds. Requires SymPy; all assertions are exact.
The finite bath intentionally fails the outgoing AC-scattering premise.
"""

from fractions import Fraction
from itertools import product
import platform
import sys

import sympy as sp


COUNT = 0


def check(label, condition):
    global COUNT
    if not bool(condition):
        raise AssertionError(label)
    COUNT += 1
    print(f"CHECK {COUNT:02d}: {label}", flush=True)


def zero_matrix(matrix):
    return all(sp.cancel(sp.simplify(x)) == 0 for x in matrix)


print("Python:", sys.version.replace("\n", " "))
print("Platform:", platform.platform())
print("SymPy:", sp.__version__)
print("Exact arithmetic only; finite fixtures do not establish continuum AC.")

I = sp.I
rat = sp.Rational
f0 = rat(2, 5)
h0 = rat(3, 11)
J2 = sp.Matrix([[0, -I], [I, 0]])
D2 = f0 * J2
g2 = sp.Matrix([3 * I / 7, 4 * I / 7])
A3 = D2.row_join(g2).col_join(g2.conjugate().T.row_join(sp.zeros(1)))
PF = sp.Matrix([[1, 0, 0], [0, 1, 0]])
zeta3 = sp.Matrix([0, 0, 1])
check("actual finite A is self-adjoint", zero_matrix(A3 - A3.conjugate().T))
check("finite bath has zero helicity bias", (g2.conjugate().T * J2 * g2)[0] == 0)

# Alternative form: integrate the full interaction-picture propagator first.
# h X - i D X + i X A = h P_F follows by integration by parts.
xvars = sp.symbols("x0:6")
X = sp.Matrix(2, 3, xvars)
residual = h0 * X - I * D2 * X + I * X * A3 - h0 * PF
coefficient, rhs = sp.linear_eq_to_matrix(list(residual), xvars)
Xexact = sp.Matrix(2, 3, coefficient.inv() * rhs)
check(
    "full Sylvester solution has the required Abel equation",
    zero_matrix(h0 * Xexact - I * D2 * Xexact + I * Xexact * A3 - h0 * PF),
)
u_sylvester = Xexact * zeta3

z = sp.symbols("z")
M = sp.factor(((z * sp.eye(3) - A3).inv())[2, 2])
eta = (g2.conjugate().T * g2)[0]
M_expected = (z**2 - f0**2) / (z * (z**2 - f0**2 - eta))
check("finite scalar M comes from the actual inverse matrix", sp.cancel(M - M_expected) == 0)
Pplus2 = (sp.eye(2) + J2) / 2
Pminus2 = (sp.eye(2) - J2) / 2
u_upper = M.subs(z, f0 + I * h0) * Pplus2 * g2 + M.subs(z, -f0 + I * h0) * Pminus2 * g2
u_lower = M.subs(z, f0 - I * h0) * Pplus2 * g2 + M.subs(z, -f0 - I * h0) * Pminus2 * g2
check("upper-half-plane positive-resolvent Abel sign matches Sylvester", zero_matrix(u_sylvester - u_upper))
check("reversing the overall Abel sign fails this exact fixture", not zero_matrix(u_sylvester + u_upper))
check("switching to the lower half-plane fails this exact fixture", not zero_matrix(u_sylvester - u_lower))
u_norm2 = sp.simplify((u_upper.conjugate().T * u_upper)[0])
Mplus = sp.simplify(M.subs(z, f0 + I * h0))
check("finite equal-helicity sum has factor one after symmetry", sp.simplify(u_norm2 - eta * sp.conjugate(Mplus) * Mplus) == 0)
check("the regulator fixture has a nonzero norm below one", 0 < u_norm2 < 1)

# The eigenvalues are 0 and +/-omega, so this same finite fixture is not AC.
omega2 = f0**2 + eta
check("finite spectrum is atomic at zero and two energies", sp.factor(A3.charpoly(z).as_expr() - z * (z**2 - omega2)) == 0)
contact_mass_zero = sp.limit(z * M, z, 0)
check("finite zeta has a strictly positive zero-energy atom", 0 < contact_mass_zero < 1)
h = sp.symbols("h", positive=True)
u_general_h = M.subs(z, f0 + I * h) * Pplus2 * g2 + M.subs(z, -f0 + I * h) * Pminus2 * g2
u_limit = u_general_h.applyfunc(lambda entry: sp.limit(entry, h, 0, dir="+"))
check("without the scattering premise the Abel datum tends to zero", zero_matrix(u_limit))

# Full three-dimensional fibers, including the longitudinal complement.
def cross_matrix(n):
    return sp.Matrix([[0, -n[2], n[1]], [n[2], 0, -n[0]], [-n[1], n[0], 0]])


n3 = sp.Matrix([rat(3, 5), rat(4, 5), 0])
d3 = sp.Matrix([rat(2, 3), -rat(1, 4), rat(5, 6)])
epsilon_fixture = rat(1, 2)
I0_fixture = sp.Integer(1)  # A fiber fixture, not a torus integral estimate.
J3 = I * cross_matrix(n3)
Qtr = sp.eye(3) - n3 * n3.T
f3 = (d3.T * n3)[0]
g3 = I * d3.cross(n3) / (2 * epsilon_fixture * sp.sqrt(I0_fixture))
Pplus3 = (Qtr + J3) / 2
Pminus3 = (Qtr - J3) / 2
check("cross-product J squared is transverse Q, not I_3", zero_matrix(J3**2 - Qtr) and not zero_matrix(J3**2 - sp.eye(3)))
check("full-matrix helicity projectors are orthogonal", zero_matrix(Pplus3**2 - Pplus3) and zero_matrix(Pminus3**2 - Pminus3) and zero_matrix(Pplus3 * Pminus3))
check("fiber coupling is transverse and has zero J expectation", (n3.T * g3)[0] == 0 and (g3.conjugate().T * J3 * g3)[0] == 0)
G3 = sp.simplify((g3.conjugate().T * g3)[0])
plus_weight = sp.simplify((g3.conjugate().T * Pplus3 * g3)[0])
minus_weight = sp.simplify((g3.conjugate().T * Pminus3 * g3)[0])
check("each physical fiber helicity has exactly G/2", plus_weight == G3 / 2 and minus_weight == G3 / 2)
field_q = M.subs(z, f3 + I * h0) * Pplus3 * g3 + M.subs(z, -f3 + I * h0) * Pminus3 * g3
field_minus_q = M.subs(z, -f3 + I * h0) * Pminus3 * (-g3) + M.subs(z, f3 + I * h0) * Pplus3 * (-g3)
check("complete field, with exchanged helicities, is physically odd", zero_matrix(field_minus_q + field_q))
first_branch_q = M.subs(z, f3 + I * h0) * Pplus3 * g3
first_branch_minus_q = M.subs(z, -f3 + I * h0) * Pminus3 * (-g3)
check("individual helicity branch need not be an odd global field", not zero_matrix(first_branch_minus_q + first_branch_q))
check("even-measure M reflection has the stated minus-conjugate sign", sp.simplify(M.subs(z, -f3 + I * h0) + sp.conjugate(M.subs(z, f3 + I * h0))) == 0)

# Coordinate reflection is an exact rational identity before integration.
sx, sy, sz = sp.symbols("sx sy sz", real=True)
cx, cy, cz = sp.symbols("cx cy cz", real=True)
kx, ky, kz = sp.symbols("kx ky kz", real=True)
svec = [sx, sy, sz]
cvec = [cx, cy, cz]
kvec = [kx, ky, kz]
epsilon2 = sum(t**2 for t in svec)
norm_d2 = sum((kvec[j] * cvec[j])**2 for j in range(3))
reflected_average = 0
for signs in product((-1, 1), repeat=3):
    dot = sum(kvec[j] * cvec[j] * signs[j] * svec[j] for j in range(3))
    reflected_average += (norm_d2 - dot**2 / epsilon2) / 8
expected_diagonal = sum(kvec[j]**2 * cvec[j]**2 * (1 - svec[j]**2 / epsilon2) for j in range(3))
check("all mixed kappa terms cancel under the exact reflection orbit", sp.cancel(reflected_average - expected_diagonal) == 0)
check("sum of the singular coordinate weights is epsilon^-2", sp.cancel(sum(t**2 / epsilon2**2 for t in svec) - 1 / epsilon2) == 0)

# Exact rational inequalities, not numerical integration of the torus.
I0 = sp.symbols("I0", positive=True)
per_coordinate_integral = (4 * I0) / 3
moment_coefficient = sp.simplify((4 * I0 - per_coordinate_integral) / (4 * I0))
check("permutation and sum identities yield the 2/3 moment coefficient", moment_coefficient == rat(2, 3))
m0 = Fraction(1) - Fraction(2, 3) / Fraction(7, 8)**2
check("interior energy mass is exactly 19/147", m0 == Fraction(19, 147))
chi = Fraction(1, 8)
cone_coefficient_without_pi2_I0 = Fraction(2**30, 4) / chi**3
check("squared interior resolvent bound produces cone power 2^37", cone_coefficient_without_pi2_I0 == 2**37)
K0 = cone_coefficient_without_pi2_I0 * 10 * Fraction(9, 8)
check("elementary I0 and pi relaxations give K0 exactly", K0 == 90 * 2**34 == 1546188226560)
check("Archimedes pi upper bound implies pi squared below ten", Fraction(22, 7)**2 < 10)
rstar = m0 / (2 * K0)
check("chosen cone radius is exact and within the proved range", rstar == Fraction(19, 454579338608640) and 0 < rstar <= Fraction(1, 2))
remaining_mass = m0 - K0 * rstar
check("the chosen radius retains half the interior mass", remaining_mass == m0 / 2)
c0 = rstar**2 * remaining_mass
check("weighted mass algebra gives m0 cubed over 8 K0 squared", c0 == m0**3 / (8 * K0**2))
check("displayed certified fraction for c0 is exact", c0 == Fraction(6859, 60752858276421362793738298982400))
decimal_lower = Fraction(1128, 1000) * Fraction(1, 10**28)
check("displayed decimal is a strict lower bound by rational comparison", c0 > decimal_lower)
denominator_upper = 12 * 10 * Fraction(9, 8)
check("joint-limit denominator is at most 135", denominator_upper == 135)
check("sign reversal in the R14 upper bound is correct", -c0 / Fraction(134) < -c0 / denominator_upper < 0)

print("FIXTURE finite eta:", eta)
print("FIXTURE regulated squared norm:", u_norm2)
print("FIXTURE zero-energy spectral atom:", contact_mass_zero)
print("EXACT m0:", m0)
print("EXACT K0:", K0)
print("EXACT r_star:", rstar)
print("EXACT c0:", c0)
print("EXACT c0 minus displayed decimal lower bound:", c0 - decimal_lower)
print(f"SUCCESS: {COUNT} exact finite/algebra controls. No continuum or rate certification.")
