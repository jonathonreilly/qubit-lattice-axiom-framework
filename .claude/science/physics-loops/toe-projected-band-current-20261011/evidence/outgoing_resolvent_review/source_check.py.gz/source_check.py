#!/usr/bin/env python3
"""Read-only source/author-evidence identity check; writes this review's record.

This script does not execute any author source and is not a theorem test.
Suggested timeout: 30 seconds. All paths are task-local except frozen local
workflow instructions and the locally installed review skill.
"""

from pathlib import Path
import difflib
import hashlib
import json


BASE = Path(__file__).resolve().parents[1]
DEST = Path(__file__).resolve().parent
EXPECTED = {
    "EXCLUDED_WALK_OUTGOING_RESOLVENT_DRAFT.md": "58a96a049701667e673bde1acf98e5346356483101654b3464fe11e94fd02c21",
    "EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md": "b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c",
    "EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md": "10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324",
    "EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md": "09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324",
    "EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md": "4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278",
    "EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md": "c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0",
    "EXCLUDED_WALK_WEIGHTED_MEMORY_REVIEW.md": "a2bb951a15a90ca8dba4cba928f6307fdde078f30a41f9f07e818561f7bf0484",
    "excluded_walk_weighted_review/independent_review_receipt.json": "74990de59ab11a8011f4164ce689b0f80153d261c073c486f47b78a1beaf1a28",
    "EXCLUDED_WALK_LONG_TIME_REVIEW.md": "b9525df21cac9721603776dc703314b73e2572b874ac5ef733b35933d6260e2f",
    "EXCLUDED_WALK_JOINT_SCALE_CURRENT_REVIEW.md": "2867fc1179a7b82b095e7719bc2f9015fdd87b5190626f61b0adfbd4fc318bf6",
    "joint_scale_review/receipt.json": "49bd1d8872a07aea1e5266cb2f07f3ea2aff4d9a9602f7a141e0051037d92b80",
    "outgoing_resolvent/receipt.json": "333d620163722af83291fb19ade6ac9ea28101b2877daff028cae5beb1d5ecc8",
    "outgoing_resolvent_review/independent_controls.py": "5ae7e904b8fd4624e09abb153f3d64c77bad157e06c62bead1cd3e883fe8f593",
    "outgoing_resolvent_review/independent_controls.log": "f03aa1cf99f35911aa4fba3ae38de2861ec09aaff16f34a6d9e482c9d5241f51",
    str(BASE.parent / "worktree/AGENTS.md"): "f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f",
    str(BASE.parent / "worktree/docs/ai_methodology/SCIENCE_WORKFLOW.md"): "05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce",
    "/Users/jonreilly/.codex/skills/physics-claim-reviewer/SKILL.md": "9d841edd05b9dc4c5145abcfd5352cd45460a1cc57c23c1eabd131590dbb1455",
}


def identify(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "lines": len(raw.splitlines())}


records = []
for name, expected in EXPECTED.items():
    path = Path(name) if Path(name).is_absolute() else BASE / name
    record = identify(path)
    assert record["sha256"] == expected, (path, expected, record["sha256"])
    records.append(record)

author_receipt = json.loads((BASE / "outgoing_resolvent/receipt.json").read_text())
author_records = []
for expected in author_receipt["records"]:
    actual = identify(Path(expected["path"]))
    assert actual["sha256"] == expected["sha256"], actual["path"]
    assert actual["bytes"] == expected["bytes"], actual["path"]
    author_records.append(actual)

final_helper = (BASE / "outgoing_resolvent/outgoing_controls.py").read_text()
initial_helper = (BASE / "outgoing_resolvent/attempt01_outgoing_controls.py").read_text()
simplification_edits = [
    ("      (coupling.conjugate().T*Pplus*Pminus*coupling)[0] == 0)",
     "      zero((coupling.conjugate().T*Pplus*Pminus*coupling)[0]))"),
    ("weight_plus = (coupling.conjugate().T*Pplus*coupling)[0]",
     "weight_plus = s.simplify((coupling.conjugate().T*Pplus*coupling)[0])"),
    ("weight_minus = (coupling.conjugate().T*Pminus*coupling)[0]",
     "weight_minus = s.simplify((coupling.conjugate().T*Pminus*coupling)[0])"),
]
reconstructed_helper = initial_helper
for old, new in simplification_edits:
    assert reconstructed_helper.count(old) == 1
    reconstructed_helper = reconstructed_helper.replace(old, new)
assert reconstructed_helper == final_helper
initial_diff = "".join(difflib.unified_diff(initial_helper.splitlines(True), final_helper.splitlines(True), fromfile="attempt01", tofile="final"))

manifest = json.loads((BASE / "outgoing_resolvent/mutation_manifest.json").read_text())
assert hashlib.sha256(final_helper.encode()).hexdigest() == manifest["primary_sha256"]
mutant_checks = []
for mutant in manifest["mutations"]:
    assert final_helper.count(mutant["old"]) == 1
    actual_source = (BASE / mutant["source"]).read_text()
    assert actual_source == final_helper.replace(mutant["old"], mutant["new"]), mutant["name"]
    assert hashlib.sha256(actual_source.encode()).hexdigest() == mutant["source_sha256"]
    raw_log = (BASE / mutant["log"]).read_bytes()
    assert hashlib.sha256(raw_log).hexdigest() == mutant["log_sha256"]
    log = raw_log.decode()
    assert log.rstrip().endswith("AssertionError: " + mutant["intended_assertion"]), mutant["name"]
    assert mutant["exit_code"] == 1
    mutant_checks.append({"name": mutant["name"], "exact_single_replacement_verified": True,
        "recorded_exit_code": mutant["exit_code"], "intended_assertion": mutant["intended_assertion"],
        "full_log_inspected": True, "reexecuted_by_reviewer": False,
        "diff": "".join(difflib.unified_diff(final_helper.splitlines(True), actual_source.splitlines(True), fromfile="final", tofile=mutant["name"]))})

result = {
    "direct_records": records,
    "author_receipt_records_checked": author_records,
    "author_first_failure_only_simplification_edits": simplification_edits,
    "author_initial_to_final_diff": initial_diff,
    "author_mutant_checks": mutant_checks,
    "author_execution_replayed": False,
    "scope": "Byte integrity and inspection of preserved author records, not independent execution or continuum evidence.",
}
(DEST / "source_check.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"All {len(records)} direct identity records match.")
print(f"All {len(author_records)} frozen author-receipt records match.")
print("Initial helper repair is exactly three symbolic simplification edits.")
print(f"All {len(mutant_checks)} author mutants match their exact one-site edit and intended recorded failure.")
print("No author source was executed by this checker.")
