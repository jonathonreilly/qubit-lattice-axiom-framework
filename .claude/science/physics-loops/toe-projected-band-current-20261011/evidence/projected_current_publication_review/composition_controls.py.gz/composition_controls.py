"""Composition-only independent controls; no author runner is replayed.

Reads the frozen publication inputs and runs the extracted wrapper on new
synthetic namespace programs. Exact rational checks assess assembly margins.
No continuum theorem follows from these finite checks. Standard library only.
"""
import ast
import contextlib
from fractions import Fraction as R
import hashlib
import io
import json
from pathlib import Path
import re

S = Path(__file__).resolve().parent.parent
NW = S.parent/'walk_worktree'
OUT = Path(__file__).resolve().parent
NOTE = S/'FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md'
PRIMARY = S/'FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_PRIMARY.py'
MAP = S/'PROJECTED_BAND_CURRENT_SOURCE_COMPOSITION.json'
PMAP = S/'projected_current_primary_composition.json'
PNOTE = NW/'docs/EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md'
PPRIMARY = NW/'scripts/excluded_walk_projected_free_band_canonical_current_2026_10_11.py'
EDITS = NW/'.claude/science/physics-loops/toe-projected-band-current-20261011/PUBLICATION_EDITS.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def record(path):
    data = path.read_bytes()
    return {'path':str(path),'sha256':sha(data),'bytes':len(data),'lines':len(data.splitlines())}

CHECKS = []
def check(label, condition, detail=None):
    assert condition, label
    CHECKS.append(label)
    print(json.dumps({'check':label,'detail':detail}))

expected = {
    NOTE:'ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969',
    PRIMARY:'a5bec672fe34491dc597a69366af105bb25e6b1e67f5176c0b2b189b5677f162',
    MAP:'5a48688b7694336051ade340089989f0bcc8a50d4e7d6a23c805990f945c8341',
    PMAP:'ffdc0a26f9caea83e70f41a471c63959e5672dc43379e43172f7ec906e6551b1',
    PNOTE:'7543767f5f2377812f78630238e73959b170752de0455fb6ab5f556a2f1868bb',
    PPRIMARY:'4451005b466c114b40c943509b13aaa34607b7b8e884ab584df4c19d8b1f30ff',
}
for path, digest in expected.items():
    check('frozen identity '+path.name,sha(path.read_bytes())==digest)
m = json.loads(MAP.read_text())
pm = json.loads(PMAP.read_text())
publication = NOTE.read_text()
sources = {}
source_records = []
for key,item in {**m['sources'],**m['reviews']}.items():
    path=Path(item['path']);data=path.read_bytes()
    check('mapped source identity '+key,sha(data)==item['sha256'] and
          len(data.splitlines())==item['lines'])
    source_records.append(record(path));sources[key]=data.decode()

# Reconstruct in listed order; even small later clarifications must be recorded.
text = sources[m['base_source']]
operations = []
for op in m['all_editorial_operations_in_order']:
    check('unique editorial input '+str(op['id']),text.count(op['before'])==1)
    text=text.replace(op['before'],op['after'],1)
    operations.append({'id':op['id'],'reason':op['reason'],'sources':op['source_ids'],
                       'before_sha256':sha(op['before'].encode()),
                       'after_sha256':sha(op['after'].encode())})
check('all 31 operations reconstruct every candidate byte',len(operations)==31 and text==publication)

# Independent byte-offset and line/column checks on each selected original.
for fragment in m['extracted_argument_fragments']:
    original=sources[fragment['source']].encode()
    start,end=fragment['start_byte'],fragment['end_byte_exclusive']
    content=original[start:end]
    prefix=original[:start].decode()
    first=prefix.count('\n')+1
    last=original[:end].decode().count('\n')+1
    column=len(prefix.rsplit('\n',1)[-1])+1
    check('exact selected fragment '+fragment['id'],
          content.decode()==fragment['original_text'] and sha(content)==fragment['sha256'] and
          first==fragment['start_line'] and last==fragment['end_line'] and
          column==fragment['start_column_1_based'])
for k,item in enumerate(m['unchanged_quantitative_ranges'],1):
    a,b=item['source_lines'];c,d=item['publication_lines']
    check('unchanged quantitative range '+str(k),
          sources[item['source']].splitlines()[a-1:b]==publication.splitlines()[c-1:d])

def equation_blocks(text):
    lines=text.splitlines();blocks={}
    for i,line in enumerate(lines):
        found=re.search(r'\(Q([0-9]+)\)\s*$',line)
        if found and line.startswith('    '):
            begin=i
            while begin>0 and lines[begin-1].startswith('    '):begin-=1
            key='Q'+found[1]
            assert key not in blocks
            blocks[key]='\n'.join(lines[begin:i+1])
    return blocks

qb,pb=equation_blocks(sources['Q']),equation_blocks(publication)
check('all quantitative equations exactly once',set(qb)==set(pb)=={'Q'+str(i) for i in range(1,34)})
check('32 quantitative blocks unchanged',all(qb[k]==pb[k] for k in qb if k!='Q4'))
q4=m['quantitative_equation_preservation']['editorial_block_difference']
check('only recorded Q4 expansion',qb['Q4']==q4['before'] and pb['Q4']==q4['after'] and
      'integral_(epsilon<r) dq <= r^3/3,' in sources['L'])

# The whole canonical proof remains, except the local h_i/Pi_(i,x) definition.
p_section='\n'.join(sources['P'].splitlines()[394:472])
old='For particle i=1,2 let h_i be the repo\'s one-body walk and X_(i,a) its\nposition operator. Use the additive symmetric local energy densities'
new='For particle i=1,2 let h_i be the supplied one-body walk with symbol\nsigma_i.sin k_i, X_(i,a) its position operator, and Pi_(i,x) its projection\nonto site x. Use the additive symmetric local energy densities'
check('complete canonical section retained',p_section.replace(old,new) in publication)

def literal_blocks(path):
    tree=ast.parse(path.read_text())
    calls=[n.value for n in tree.body if isinstance(n,ast.Expr) and
           isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and
           n.value.func.id=='_run_block']
    assert len(calls)==4
    return [(ast.literal_eval(c.args[0]),ast.literal_eval(c.args[1])) for c in calls],tree

blocks,tree=literal_blocks(PRIMARY)
final_blocks,final_tree=literal_blocks(PPRIMARY)
for (label,body),item in zip(blocks,pm['sources']):
    path=S/item['source'];data=path.read_bytes()
    check('literal original bytes '+label,label==item['namespace'] and body.encode()==data and
          sha(data)==item['sha256'] and len(data.splitlines())==item['lines'])
    source_records.append(record(path))
check('publication keeps all four literals',blocks==final_blocks)

wrapper=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_run_block')
final_wrapper=next(n for n in final_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_run_block')
check('publication wrapper AST unchanged',ast.dump(wrapper)==ast.dump(final_wrapper))

# Execute the actual wrapper only, using fresh synthetic programs rather than
# the four author calculations. Retained references expose shared globals.
def load_wrapper(node):
    env={'sha256':hashlib.sha256,'__file__':str(PRIMARY)}
    module=ast.Module(body=[node],type_ignores=[])
    exec(compile(ast.fix_missing_locations(module),'<wrapper-review>','exec'),env)
    return env['_run_block'],env

run,env=load_wrapper(wrapper)
captured=io.StringIO()
with contextlib.redirect_stdout(captured):
    run('first',"sentinel=37\nheld=lambda: sentinel\nassert held()==37\n")
    run('second',"assert 'sentinel' not in globals()\nassert 'held' not in globals()\nassert __name__=='__main__'\nassert __file__.endswith('FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_PRIMARY.py')\n")
check('actual wrapper isolates independent synthetic globals','sentinel' not in env and 'held' not in env)
try:
    with contextlib.redirect_stdout(captured):run('failure',"raise AssertionError('synthetic failure propagated')")
except AssertionError as exc:
    check('wrapper propagates a failed check',str(exc)=='synthetic failure propagated')
else:
    raise AssertionError('wrapper swallowed synthetic failure')

# An actual transformed wrapper supplies a discriminating wrong-object control.
mutant_text=ast.unparse(wrapper).replace("namespace = {'__name__': '__main__', '__file__': __file__}",
                                       'namespace = globals()')
assert mutant_text!=ast.unparse(wrapper)
mutant_node=ast.parse(mutant_text).body[0]
wrong,_=load_wrapper(mutant_node)
try:
    with contextlib.redirect_stdout(captured):
        wrong('first',"sentinel=37\n")
        wrong('second',"assert 'sentinel' not in globals(), 'shared namespace leak'\n")
except AssertionError as exc:
    check('shared-namespace competitor rejected',str(exc)=='shared namespace leak')
else:
    raise AssertionError('shared namespace escaped detector')
(OUT/'namespace_control.log').write_text(captured.getvalue())
(OUT/'shared_namespace_competitor.py').write_text(mutant_text+'\n')

# Separate literal-byte discriminator: an altered sign is no longer the source.
wrong_body=blocks[1][1].replace('FIRST_DERIVATIVE_SIGN = 1','FIRST_DERIVATIVE_SIGN = -1',1)
check('altered embedded sign fails source-identity gate',wrong_body!=blocks[1][1] and
      sha(wrong_body.encode())!=pm['sources'][1]['sha256'])

# Derive the scale certificate using x=lambda^(1/4), so 0<x<=1/2.
# The four relative-error terms are constant or positive monomials in x.
x=R(1,2);sig0=R(1,2**40);del0=R(1,2**68)
relative_terms=[108*del0/sig0,17*R(1,2**20)*x**3,96*sig0,R(12,5)*del0*x**6]
relative=sum(relative_terms)
check('independently regrouped polynomial scale margin',relative<R(1,200000),str(relative))
check('cutoff and preparation domains at maximal lambda',
      sig0*x**2<R(5,8) and sig0*x**6<R(1,2) and del0*x**4<R(1,32))
current_upper=-R(1,10800)+4*relative+2*relative**2+8*9*del0
check('direct combined diagonal current budget',current_upper<-R(1,21600),str(current_upper))
check('both finite preparation endpoints',4*4*32==512 and 2*4+2*4*R(1,20)<9)
check('fiber-to-global remaining sign budget',-R(1,21600)+R(1,86400)+R(1,86400)==-R(1,43200))

# A fresh unequal-loss packet tests the distinction between the actual and
# pre-projection total-momentum laws. This is finite normalization algebra.
weights=[R(2,9),R(1,9),R(2,3)];survival=[R(7,9),R(4,5),R(3,4)]
n2=sum(w*p for w,p in zip(weights,survival))
actual=[w*p/n2 for w,p in zip(weights,survival)]
fiber=[-R(1,43200),-R(1,21600),-R(1,14400)]
observable=sum(p*j for p,j in zip(actual,fiber))
wrong_observable=sum(p*j for p,j in zip(weights,fiber))
check('one global projection normalization',sum(actual)==1 and actual!=weights and
      sum(w*p for w,p in zip(weights,survival))!=1)
check('common fiber current bound survives actual weights',observable<=-R(1,43200))
check('old momentum law predicts a different observable',observable!=wrong_observable,
      {'actual':str(observable),'old_law':str(wrong_observable)})

edits=json.loads(EDITS.read_text())
field='runner: scripts/excluded_walk_projected_free_band_canonical_current_2026_10_11.py\n'
with_runner=publication.replace('claim_type: bounded_theorem\n','claim_type: bounded_theorem\n'+field,1)
pub_text=PNOTE.read_text()
check('publication mathematical body unchanged',pub_text.startswith(with_runner))
footer=pub_text[len(with_runner):]
check('publication footer is exactly 17 appended lines',len(footer.splitlines())==17 and
      'No flux/form or effective-memory result is a premise' in footer)
check('publication primary differs only by declared input path',
      PRIMARY.read_text().replace(edits['primary_edit']['before'],edits['primary_edit']['after'])==PPRIMARY.read_text())
check('publication edit identities bind current files',
      edits['note_sha256']==sha(PNOTE.read_bytes()) and edits['primary_sha256']==sha(PPRIMARY.read_bytes()))

execution=json.loads((S/'projected_current_primary_checks/baseline_execution.json').read_text())
log=(S/'projected_current_primary_checks/baseline.log').read_text()
check('author baseline identity and external timeout',execution['returncode']==0 and
      execution['timeout_seconds']==180 and execution['primary_sha256']==sha(PRIMARY.read_bytes()) and
      execution['log_sha256']==sha(log.encode()))
check('author baseline ran each exact literal',all(
    'BEGIN '+label+' embedded_source_sha256='+sha(body.encode()) in log and
    'END '+label in log for label,body in blocks))
check('author baseline identifies combined runner','Runner SHA256: '+sha(PRIMARY.read_bytes()) in log)

result={'check_count':len(CHECKS),'checks':CHECKS,'input_identities':[record(p) for p in expected]+[record(EDITS)],
        'source_identities':source_records,'operations':operations,'fragment_count':len(m['extracted_argument_fragments']),
        'range_count':len(m['unchanged_quantitative_ranges']),'primary_blocks':len(blocks),
        'author_baseline':execution,'publication_footer':footer,
        'scope':'New assembly, wrapper and finite budget/normalization checks; no author-runner replay, no independent recertification of reviewer-authored L/D arguments.'}
(OUT/'composition_control_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(CHECKS),'scope':result['scope']}))
