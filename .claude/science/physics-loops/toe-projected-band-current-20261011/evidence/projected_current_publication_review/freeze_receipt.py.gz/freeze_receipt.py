"""Freeze the composition review with exact sources; no parent writes/replays."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess

D=Path(__file__).resolve().parent
S=D.parent
NW=S.parent/'walk_worktree'
W=S.parent/'worktree'
REPORT=S/'EXCLUDED_WALK_PROJECTED_CURRENT_PUBLICATION_REVIEW.md'

def identify(path):
    data=path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),
            'bytes':len(data),'lines':len(data.splitlines())}

def verify(record):
    actual=identify(Path(record['path']))
    for key in ['sha256','bytes','lines']:
        if key in record:assert actual[key]==record[key],(actual['path'],key)
    return actual

results=json.loads((D/'composition_control_results.json').read_text())
execution=json.loads((D/'composition_execution.json').read_text())
assert execution['returncode']==0 and execution['timeout_seconds']==120
assert identify(D/'composition_controls.py')['sha256']==execution['source_sha256']
assert identify(D/'composition_controls.log')['sha256']==execution['log_sha256']
assert results['check_count']==127
sources=[verify(r) for r in results['input_identities']+results['source_identities']]
for name in ['projected_current_primary_checks/baseline.log',
             'projected_current_primary_checks/baseline_execution.json']:
    sources.append(identify(S/name))
assert identify(S/'projected_current_primary_checks/baseline.log')['sha256']==results['author_baseline']['log_sha256']

# Previous weighted-memory evidence is protected provenance, not a new premise.
previous=S/'weighted_memory/receipt.json'
assert identify(previous)['sha256']=='a9a25c7df59b6efe058b4496038a8232e39baba04826290c6f1ffa8f32cbf8ca'
prior=json.loads(previous.read_text())
protected=[verify(r) for r in prior['artifacts']+prior['verified_unchanged_records']]
protected.append(identify(previous))

instruction_specs={
 'AGENTS.md':('f9a7b41213cee9ff0b7e9a28f79b555c152de52ef012ff3bcdd09b996d3aa32f','Prior applicable instructions reused unchanged.'),
 'docs/ai_methodology/SCIENCE_WORKFLOW.md':('05f3ec8e58ccd7a4d2a87643fb7ed4f12998c6a1d5721e3632a502de8a0ad6ce','Prior complete workflow reading reused unchanged.'),
 'docs/ai_methodology/skills/physics-claim-reviewer/SKILL.md':('9d841edd05b9dc4c5145abcfd5352cd45460a1cc57c23c1eabd131590dbb1455','Complete current skill read; installed bytes match the main-backed worktree file.'),
 'docs/ai_methodology/skills/review-loop/SKILL.md':('c20291887b2a4dd00244bdc6a0d165ddef7a6f72c63cd808cc037e6a1ad58d13','Referenced focused review contract and boundaries read at lines 1-160 and 265-305; no branch-review/landing process invoked.'),
 'docs/ai_methodology/skills/SKILL_FRESHNESS_CHECK.md':('b2593401141d5f88f65feb428b8a4b2072455e038ace1cf313ecbb5a667e64b0','Complete source read, local identified main only.'),
}
instructions=[]
for name,(sha,coverage) in instruction_specs.items():
    row=verify({'path':str(W/name),'sha256':sha})
    raw=subprocess.check_output(['git','-C',str(W),'show','origin/main:'+name])
    assert hashlib.sha256(raw).hexdigest()==sha
    row['coverage']=coverage;instructions.append(row)
governance=W/'docs/ai_methodology/skills/physics-loop/references/proof-search-governance.md'
raw=subprocess.check_output(['git','-C',str(W),'show','origin/main:'+str(governance.relative_to(W))])
assert raw==governance.read_bytes()
instructions.append({**identify(governance),'coverage':'Complete referenced proof-search governance read; task remains a scoped review, with no new research/audit process.'})
installed=Path('/Users/jonreilly/.codex/skills/physics-claim-reviewer/SKILL.md')
assert installed.read_bytes()==(W/'docs/ai_methodology/skills/physics-claim-reviewer/SKILL.md').read_bytes()
instructions.append(identify(installed))

parent_commit='b9b032ae790c66e762a6296a1306bfb64ae7cd70'
parent_name='docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md'
parent_blob=subprocess.check_output(['git','-C',str(NW),'show',parent_commit+':'+parent_name])
assert hashlib.sha256(parent_blob).hexdigest()=='9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401'
refs={label:subprocess.check_output(['git','-C',str(path),'rev-parse',ref],text=True).strip()
      for label,path,ref in [('NW_HEAD',NW,'HEAD'),('local_main',W,'origin/main'),
                             ('local_planning_ref',W,'origin/ai/execution')]}

receipt={
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'review_kind':'Composition and claim-scope review; no audit verdict or retained-status action.',
 'outcome':'No consequential composition or claim-scope defect found for the exact reviewed candidate and publication bytes.',
 'report':identify(REPORT),
 'independence':{
   'reviewer_authored':['L long-time source','D degenerate-dynamics source','L/D original finite helpers'],
   'new_work':'Another author\'s assembly, complete Q/B source usage, source-selection and current/global proof interfaces, literal embedding, wrapper and exact publication diff.',
   'not_claimed':'No independent recertification of reviewer-authored old L/D mathematics; not a pre-source/blinded reconstruction; no old author runner replay.'},
 'source_coverage':{
   'candidate_note':'All 859 lines read completely.',
   'candidate_primary':'All 713 lines read; four embedded literal bodies and wrapper included.',
   'note_map':'Entire JSON parsed and exact replay checked; 31 reasons/before fragments inspected against final read after-content; 13 byte/line/column source fragments, 38 unchanged ranges and all 33 Q blocks checked.',
   'source_Q':'All 420 lines newly read.',
   'source_B':'All 327 lines newly read.',
   'source_L':'Previous complete 457-line author reading reused at verified identity; 75-179, 205-243, 282-304 refreshed; included arguments fully read in assembled candidate.',
   'source_D':'Previous complete 549-line author reading reused at verified identity; 111-158, 172-201, 234-245, 293-333 refreshed; included arguments fully read in assembled candidate.',
   'parent_P':'Lines 1-103 and complete canonical section 393-472; no claim of a new full 1280-line parent review.',
   'reviews':'L 378, B 316 and Q 329 lines read fully here; prior full D 375-line review reading reused at unchanged identity.',
   'helper_sources':'All four complete embedded originals read and independently byte-compared; separate redundant reading/replay of original files not claimed.',
   'logs':'Full author baseline, execution metadata, new composition log and synthetic namespace output read.',
   'publication_refresh':'Complete exact two-file diff and PUBLICATION_EDITS.json read; note +1 runner line/+17 footer lines, primary one input-path replacement.'},
 'sources_verified_unchanged':sources,
 'protected_prior_packet':{'receipt':identify(previous),'verified_records':protected,
                            'role':'Preservation only; no memory/scattering theorem imported into projected-current proof.'},
 'controls':{'execution':execution,'checks':127,
   'analytical_roles':['Two inverse constructions and their domains distinguished.','Both correctors and finite arbitrary-T bounds reconstructed.','Full physical trace and amplitude-sensitive current bound checked.','Actual positive-band/global-normalization proof checked.'],
   'finite_roles':['Exact source/edit reconstruction and literal identities.','Actual wrapper tested on new synthetic namespace programs.','Shared-namespace competitor rejected and failure propagation checked.','Altered literal-sign source identity rejected.','Polynomial budgets regrouped with lambda^(1/4), both state endpoints retained.','New unequal-loss packet distinguishes actual from old momentum law.'],
   'limits':'127 includes bookkeeping; finite controls do not prove continuum dynamics. Intentional synthetic failures are caught controls, not full-primary science mutation executions.'},
 'author_baseline':results['author_baseline'],
 'publication_copy':{'note':results['input_identities'][4],'primary':results['input_identities'][5],
   'edits':results['input_identities'][6],'footer':results['publication_footer'],
   'parent_commit':parent_commit,'parent_note_sha256':hashlib.sha256(parent_blob).hexdigest(),
   'pending':'Root plans narrow pending-review/evidence prose update; any new bytes need affected confirmation. Future DELIVERY_CHECKS/cache/mutations and cumulative parent delta are not certified here.'},
 'instructions':instructions,
 'local_refs_only':refs,
 'remaining_limits':['Supplied walk, clock, antisymmetry, exclusion, coordinates and canonical placement remain premises.',
   'Constructed family at explicit finite time; no universal sign, monotonicity, generic packet or physical kinetic law.',
   'No new continuum Lean proof, formal audit verdict, retained status, remote freshness or novelty assertion.',
   'Parent must land first or cumulative delta receive its own review; this unit check is not that cumulative review.'],
 'failures':'No unexpected execution failure or tolerance change. Initial large tool output truncated and replaced with complete scoped source reads; named execution record resolved read-only to baseline_execution.json.',
 'selected_model_and_effort':'Preserved without delegation or model change; no unsupported exact runtime model metadata asserted.',
 'editable_prompt_files_changed':[],
 'writes':[str(REPORT),str(D)],
 'artifacts':[identify(REPORT)]+[identify(p) for p in sorted(D.iterdir()) if p.is_file() and p.name!='receipt.json'],
 'receipt_scope':'Source and execution identity evidence, not an independent formal science audit; excludes its own hash.'}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'report':identify(REPORT),'receipt':identify(D/'receipt.json'),
                  'artifacts':len(receipt['artifacts']),'protected_records':len(protected)}))
