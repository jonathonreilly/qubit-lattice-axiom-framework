def _run_block(label, source):
    print('BEGIN', label, 'embedded_source_sha256=' + sha256(source.encode()).hexdigest(), flush=True)
    namespace = globals()
    exec(compile(source, __file__ + '::' + label, 'exec'), namespace)
    print('END', label, flush=True)
