#!/usr/bin/env python3
"""Exact status-only publication refresh comparison; no runner execution.

Inputs are the frozen before/after note and declared three-edit manifest.
The existing canonical execution/cache are inspected, not replayed. No
future delivery record is certified. Suggested timeout: 30 seconds.
"""

from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json


BASE = Path(__file__).resolve().parents[1]
DEST = Path(__file__).resolve().parent
NW = BASE.parent / "walk_worktree"
BEFORE = BASE / "PROJECTED_CURRENT_PRE_PUBLICATION_REFRESH.md"
MANIFEST = BASE / "projected_current_status_refresh.json"
PRIMARY = NW / "scripts/excluded_walk_projected_free_band_canonical_current_2026_10_11.py"
REVIEW = BASE / "EXCLUDED_WALK_PROJECTED_CURRENT_PUBLICATION_REVIEW.md"
PRIOR_RECEIPT = BASE / "projected_current_publication_review/receipt.json"
EXECUTION = BASE / "projected_current_canonical_execution.json"
EXPECTED_PRIMARY = "4451005b466c114b40c943509b13aaa34607b7b8e884ab584df4c19d8b1f30ff"


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), lines=len(raw.splitlines()))


manifest = json.loads(MANIFEST.read_text())
assert identity(MANIFEST)["sha256"] == "ec7777a9ae9442f7bb7f7658f01b6e35fede27b054ce44f548fd0217fade7858"
AFTER = Path(manifest["note_path"])
before = BEFORE.read_text()
after = AFTER.read_text()
assert identity(BEFORE)["sha256"] == manifest["before_sha256"] == "7543767f5f2377812f78630238e73959b170752de0455fb6ab5f556a2f1868bb"
assert identity(AFTER)["sha256"] == manifest["after_sha256"] == "bf894a323464c17faf78ae3402af8ef964635fb8fe2240ece671c0aaffcf5e5d"
assert identity(REVIEW)["sha256"] == manifest["prior_composition_review_sha256"] == "076021427ff4e2cbb473363e09b3a043c2a4bae01d24bdfc69a6a42a55be8cf1"
assert identity(PRIOR_RECEIPT)["sha256"] == "f2c75a99df4eb6139f5f2329c9471716779a8c2ecb61b180ec5788321b5aab03"
assert identity(PRIMARY)["sha256"] == EXPECTED_PRIMARY

assert len(manifest["changes"]) == 3
reconstructed = before
edit_records = []
for change in manifest["changes"]:
    assert reconstructed.count(change["before"]) == 1
    reconstructed = reconstructed.replace(change["before"], change["after"])
    edit_records.append(dict(before=change["before"], after=change["after"], exact_unique_replacement=True))
assert reconstructed == after
math_before = before[before.index("## 1. "):before.index("## 8. ")]
math_after = after[after.index("## 1. "):after.index("## 8. ")]
assert math_before == math_after
diff = "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(BEFORE), tofile=str(AFTER)))
(DEST / "exact_note_diff.patch").write_text(diff)

execution_record = json.loads(EXECUTION.read_text())
execution = execution_record["execution"]
assert execution["status"] == "ok" and execution["exit_code"] == 0
assert execution["stderr"] == "" and execution["timeout_sec"] == 180
assert f"Runner SHA256: {EXPECTED_PRIMARY}" in execution["stdout"]
cache_path = Path(execution_record["cache_path"])
cache = cache_path.read_text()
header, payload = cache.split("----- stdout -----\n", 1)
cache_stdout, cache_stderr = payload.split("----- stderr -----\n", 1)
assert f"runner_sha256: {EXPECTED_PRIMARY}\n" in header
assert "exit_code: 0\n" in header and "status: ok\n" in header
assert cache_stdout.rstrip("\n") == execution["stdout"].rstrip("\n")
assert cache_stderr.strip() == ""
assert execution_record["identity_status"] == "fresh" and execution_record["cache_status"] == "fresh"

delivery_link = "../.claude/science/physics-loops/toe-projected-band-current-20261011/DELIVERY_CHECKS.md"
assert f"[delivery checks]({delivery_link})" in after
delivery_path = (AFTER.parent / delivery_link).resolve()
delivery_observation = dict(path=str(delivery_path), exists_at_inspection=delivery_path.exists(), inspected_contents=False, certified_future_contents=False)

record = dict(
    inspected_utc=datetime.now(timezone.utc).isoformat(),
    inputs=[identity(p) for p in [BEFORE, AFTER, MANIFEST, PRIMARY, REVIEW, PRIOR_RECEIPT, EXECUTION, cache_path]],
    exact_edits=edit_records,
    other_bytes_unchanged=True,
    mathematical_sections_1_through_7_sha256=hashlib.sha256(math_before.encode()).hexdigest(),
    mathematical_sections_bytes=len(math_before.encode()),
    primary_unchanged=True,
    canonical_execution_recorded_exit_code=execution["exit_code"],
    canonical_cache_stdout_matches_record=True,
    cache_fingerprint_algorithm_recomputed=False,
    canonical_execution_replayed=False,
    delivery_link=delivery_observation,
    scope="Narrow status/evidence/link change review. No new science verification or certification of future delivery-pack contents."
)
(DEST / "check_refresh.json").write_text(json.dumps(record, indent=2) + "\n")
print("Exactly three declared status/evidence/link edits reconstruct the complete current note.")
print("All mathematical sections 1-7 and every other undeclared byte remain unchanged.")
print("The primary and prior composition report/receipt retain their exact identities.")
print("The completed canonical record reports exit 0 and its stdout exactly matches the identified cache.")
print("Delivery target exists at inspection:", delivery_observation["exists_at_inspection"])
print("Delivery target contents and future delivery-pack completion are outside this check.")
