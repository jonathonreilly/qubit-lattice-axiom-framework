"""Separate author controls for quantitative weak-momentum band-current onset.

Exact rational parameter budgets and cutoff identities; floating matrices for
pointwise effective orbits, the longitudinal complement and spectral correctors.
The finite fixture is not an infinite torus quadrature or an independent review.
"""
from fractions import Fraction as F
from math import sqrt
import numpy as np

# Exact budget certificate, with 0<lambda<=1/16, sigma=2^-40 lambda^(3/2),
# delta=2^-68 lambda^2, and A>=sqrt(lambda)/12.
eta=F(108,2**28)+F(17,2**23)+F(96,2**40)+F(3,80*2**68)
assert eta<F(1,200000)
assert F(9,2**68)<F(1,345600)             # delta/A^2
assert F(144,2**68)<F(1,44236800)          # delta/(A^2 lambda)
assert F(1,2**42)<F(5,8)                  # sigma/lambda <= a/2
assert F(1,2**68*16)<F(1,32)              # delta/lambda
assert F(4,200000)+F(2,200000**2)+F(8,345600)<F(1,21600)
assert -F(1,21600)+2*F(1,86400)==-F(1,43200)
assert 9*777600==6998400 and 9*43200==388800
assert F(43,5)<=9 and F(807,50)<=17 and F(133,40)<=4 and F(2,15)<=F(1,5)
assert F(4)+F(47,12)<8
print('Exact parameter budget e_perp/A upper bound:',eta,'< 1/200000')
print('Exact current, preparation, support, cutoff-domain and global-drift constant margins verified.')

# Three antipodal pairs, represented in their even-singlet/odd-triplet sectors.
# Each representative is an actual axis sine/cosine point. Choose positive
# weights with sum one and I0 exactly one so the dressing coefficients are rational.
eps=[F(3,5),F(5,13),F(1)]
qcos=[F(4,5),F(12,13),F(0)]
w3=F(1,4)
w1=(F(1)-w3/(4*eps[2]**2)-(1-w3)/(4*eps[1]**2))/(F(1)/(4*eps[0]**2)-F(1)/(4*eps[1]**2))
weights=[w1,1-w1-w3,w3]
assert all(x>0 for x in weights) and sum(weights)==1
assert sum(w/(4*e*e) for w,e in zip(weights,eps))==1
for e,c in zip(eps,qcos):assert e*e+c*c==1

# Exact pure-longitudinal fixture orthogonal to zeta. The cutoff removes one
# atom and has nonzero mean; forgetting the mean would fail this identity.
f=[F(1),-weights[0]*eps[1]/(weights[1]*eps[0]),F(0)]
assert sum(w*x/(2*e) for w,x,e in zip(weights,f,eps))==0
r=F(1,2);m=sum(w*x/(2*e) for w,x,e in zip(weights,f,eps) if e>=r)
xi=[(x/(2*e) if e>=r else F(0))-m for x,e in zip(f,eps)]
res=[2*e*y-x for e,y,x in zip(eps,xi,f)]
assert m!=0 and sum(w*y for w,y in zip(weights,xi))==0
assert res==[-(x if e<r else 0)-2*e*m for x,e in zip(f,eps)]
assert sum(w*y*y for w,y in zip(weights,xi))<=sum(w*(x/(2*e))**2 for w,x,e in zip(weights,f,eps) if e>=r)
print('Exact longitudinal cutoff: I0=1, nonzero removed mean',m,'and complete residual identity verified.')

N=12;c=np.zeros(N,complex);zeta=np.zeros(N,complex);H0=np.zeros((N,N),complex)
Fflat=np.zeros((N,N),complex);B=np.zeros((N,N),complex);kap=np.array([1.,2.,-1.]);b=np.linalg.norm(kap)

def cross(d):
    x,y,z=d;return np.array([[0,-z,y],[z,0,-x],[-y,x,0]],complex)

for i,(wi,ei,ci) in enumerate(zip(weights,eps,qcos)):
    weight=float(wi);epsilon=float(ei);normal=np.eye(3)[i]
    c[4*i]=sqrt(weight);zeta[4*i+1:4*i+4]=sqrt(weight)*normal/(2*epsilon)
    H0[4*i,4*i+1:4*i+4]=2*epsilon*normal;H0[4*i+1:4*i+4,4*i]=2*epsilon*normal
    Fflat[4*i+1:4*i+4,4*i+1:4*i+4]=np.eye(3)-np.outer(normal,normal)
    cq=np.ones(3);cq[i]=float(ci)
    B[4*i+1:4*i+4,4*i+1:4*i+4]=1j*cross(kap*cq)
P=np.eye(N)-np.outer(c,c.conj());Hstar=P@H0@P
Pi=Fflat+np.outer(zeta,zeta.conj());Q=P-Pi;A=Pi@B@Pi
assert np.linalg.norm(zeta)==1
assert np.linalg.norm(Hstar@zeta)<1e-14 and np.linalg.norm(Pi@Pi-Pi)<1e-14
assert np.linalg.norm(Q@B@Q)<1e-14 and np.linalg.norm(B@Q-Fflat@B@Q)<1e-14


def evolve(H,t,v):
    e,U=np.linalg.eigh(H);return U@(np.exp(-1j*t*e)*(U.conj().T@v))

es,Vs=np.linalg.eigh(Hstar);positive=sorted(set(round(abs(x),8) for x in es if abs(x)>1e-8))
sigma=(positive[0]+positive[-1])/2
mask=(np.abs(es)>1e-8)&(np.abs(es)<=sigma)
Es=Vs[:,mask]@Vs[:,mask].conj().T
assert 0<np.count_nonzero(mask)<np.count_nonzero(np.abs(es)>1e-8)
max_cut_mean=0.
for tau in (-.2,-.05,0.,.05,.2):
    orbit=evolve(A,tau,zeta);u=Fflat@orbit;alpha=np.vdot(zeta,orbit);y=Q@B@orbit
    assert abs(alpha)<=1+1e-13 and np.linalg.norm(Fflat@y)<1e-13 and abs(np.vdot(zeta,y))<1e-13
    fs=[]
    for i,(wi,ei) in enumerate(zip(weights,eps)):
        ui=u[4*i+1:4*i+4]/sqrt(float(wi));normal=np.eye(3)[i]
        assert np.linalg.norm(ui)<=abs(tau)*b/(2*float(ei))+1e-13
        fi=np.dot(normal,y[4*i+1:4*i+4])/sqrt(float(wi));fs.append(fi)
        assert abs(fi)<=b*b*abs(tau)/float(ei)+1e-13
    mean=sum(float(wi)*fi/(2*float(ei)) for wi,fi,ei in zip(weights,fs,eps) if ei>=r)
    max_cut_mean=max(max_cut_mean,abs(mean))
    cut=np.zeros(N,complex)
    for i,(wi,fi,ei) in enumerate(zip(weights,fs,eps)):
        cut[4*i]=sqrt(float(wi))*((fi/(2*float(ei)) if ei>=r else 0)-mean)
    residual=Hstar@cut-y;formula=np.zeros(N,complex)
    for i,(wi,fi,ei) in enumerate(zip(weights,fs,eps)):
        formula[4*i+1+i]=sqrt(float(wi))*(-(fi if ei<r else 0)-2*float(ei)*mean)
    assert np.linalg.norm(residual-formula)<1e-13
    assert np.linalg.norm(Es@y)<=np.linalg.norm(residual)+sigma*np.linalg.norm(cut)+1e-13
assert max_cut_mean>1e-4
print('Five actual effective orbits: pointwise bound, pure-longitudinal Q B orbit, cutoff mean and nontrivial spectral-cutoff inequality verified.')

# Corrector identities and finite estimates tested without replacing Hstar's
# complement by a pointwise uncompressed inverse.
Hinv=Vs@np.diag([1/x if abs(x)>sigma else 0 for x in es])@Vs.conj().T
v=evolve(A,.13,zeta);vprime=-1j*A@v;y=-Hinv@B@v;yprime=-Hinv@B@vprime
delta=.017;w=v+delta*y
lhs=1j*(vprime+delta*yprime)-(Hstar/delta+B)@w
rhs=-Es@B@v+delta*(1j*yprime-B@y)
assert np.linalg.norm(lhs-rhs)<1e-12
x=Vs[:,np.argmax(es)];v=evolve(Hstar,.13/delta,x);y=B@Hinv@v
assert np.linalg.norm(Hstar@y)<1e-13
vprime=-1j*Hstar@v/delta;yprime=B@Hinv@vprime
lhs=1j*(vprime+delta*yprime)-(Hstar/delta+B)@(v+delta*y)
assert np.linalg.norm(lhs+delta*B@y)<1e-12
print('Both zero-space and complementary high-spectral corrector residuals reconstructed from matrices.')

# Full-space trace identity: a fixture need not be cubically invariant for it.
V=np.zeros(N,complex);va=[];Ls=[];eps2=np.zeros((N,N),complex)
for a in range(3):
    vj=np.zeros(N,complex);mult=np.zeros((N,N),complex)
    for i,(wi,ei) in enumerate(zip(weights,eps)):
        sj=float(ei) if a==i else 0.
        vj[4*i+1+a]=sqrt(float(wi))*sj
        mult[4*i:4*i+4,4*i:4*i+4]=(1-2*sj*sj)*np.eye(4)
        eps2[4*i:4*i+4,4*i:4*i+4]=float(ei)**2*np.eye(4)
    va.append(vj);V+=vj;Ls.append(P@mult@P)
for a in range(3):Ls[a]+=np.outer(va[a],V.conj())+np.outer(V,va[a].conj())
assert np.linalg.norm(sum(Ls)-(3*P-Hstar@Hstar/2-2*eps2@Fflat))<1e-13
print('Full physical-space current trace identity verified; no rotational equality of components assumed for this non-cubic fixture.')
print('Controls complete. Floating finite matrices do not prove the torus cone integral bounds or the infinite-dimensional evolution estimate.')
