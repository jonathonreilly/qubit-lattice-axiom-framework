#!/usr/bin/env python3
"""Exact finite controls for B5, B8, B12 and the packet margins.

This is author evidence for the two-scale theorem. It proves no gapless
limit by a finite fixture and supplies no quantitative delta onset.
Literal data, no network or author-helper imports. Requires SymPy.
"""
import json
import platform
import time
import sympy as s

start = time.monotonic()
R, I = s.Rational, s.I


def exact(label, lhs, rhs):
    delta = lhs-rhs
    terms = list(delta) if isinstance(delta, s.MatrixBase) else [delta]
    assert all(s.simplify(x) == 0 for x in terms), label
    print("EXACT", label, flush=True)


print(json.dumps({"python": platform.python_version(), "sympy": s.__version__,
                  "scope": "author exact finite controls; no continuum quadrature"}))
pauli = [s.Matrix([[0, 1], [1, 0]]), s.Matrix([[0, -I], [I, 0]]), s.diag(1, -1)]
singlet = s.Matrix([0, 1, -1, 0])/s.sqrt(2)
left = [s.kronecker_product(p, s.eye(2)) for p in pauli]
right = [s.kronecker_product(s.eye(2), p) for p in pauli]
ST = s.Matrix.hstack(singlet, *(p*singlet for p in left))
kap = [R(2, 3), -R(1, 5), R(4, 7)]
fixture = [([R(3, 5), 0, 0], [R(4, 5), 1, 1], R(1, 2)),
           ([0, R(5, 13), 0], [1, R(12, 13), 1], R(1, 3)),
           ([0, 0, R(7, 25)], [1, 1, R(24, 25)], R(1, 6))]
dim = 4*len(fixture)
H0, B, F, E2 = (s.zeros(dim) for _ in range(4))
c, v, zeta = (s.zeros(dim, 1) for _ in range(3))
va = [s.zeros(dim, 1) for _ in range(3)]
I0 = sum(prob/(4*sum(x*x for x in sv)) for sv, cv, prob in fixture)
for j, (sv, cv, prob) in enumerate(fixture):
    off = 4*j
    sv = s.Matrix(sv)
    eps2 = sv.dot(sv)
    c[off] = s.sqrt(prob)
    v[off+1:off+4, 0] = s.sqrt(prob)*sv
    zeta[off+1:off+4, 0] = s.sqrt(prob)*sv/(2*eps2*s.sqrt(I0))
    for a in range(3):
        va[a][off+1+a] = s.sqrt(prob)*sv[a]
    raw_H = sum((sv[a]*(left[a]-right[a]) for a in range(3)), s.zeros(4))
    raw_B = sum((kap[a]*cv[a]*(left[a]+right[a])/2 for a in range(3)), s.zeros(4))
    H0[off:off+4, off:off+4] = ST.H*raw_H*ST
    B[off:off+4, off:off+4] = ST.H*raw_B*ST
    F[off+1:off+4, off+1:off+4] = s.eye(3)-sv*sv.T/eps2
    E2[off:off+4, off:off+4] = eps2*s.eye(4)
P = s.eye(dim)-c*c.H
H = P*H0*P
Pi = F+zeta*zeta.H
Q = P-Pi
exact("physical zero projector", Pi*Pi, Pi)
exact("physical zero excludes auxiliary singlet", Pi*c, s.zeros(dim, 1))
exact("physical zero annihilation", H*Pi, s.zeros(dim))
exact("nonzero subspace projection", Q*Q, Q)
assert Q.rank() == 4
exact("nonzero derivative lands in transverse zero space", B*Q, F*B*Q)
exact("nonzero derivative has no diagonal block", Q*B*Q, s.zeros(dim))
assert B*Q != s.zeros(dim)

L = []
PLACEMENT_FACTOR = 1
for a in range(3):
    ma = s.diag(*[1-2*sv[a]**2 for sv, cv, prob in fixture for _ in range(4)])
    L.append(P*ma*P+PLACEMENT_FACTOR*(va[a]*v.H+v*va[a].H))
TRANSVERSE_TRACE_FACTOR = 2
exact("full physical canonical trace identity", sum(L, s.zeros(dim)),
      3*P-H*H/2-TRANSVERSE_TRACE_FACTOR*E2*F)
assert E2*F != s.zeros(dim)
exact("full trace restricted to nonzero spectrum", Q*sum(L, s.zeros(dim))*Q,
      3*Q-H*H/2)

# The inverse is harmless in this finite fixture; the continuum proof cuts
# it off at sigma and carries the missing low spectral mass explicitly.
Hinv = Q*(H+Pi+c*c.H).inv()*Q
exact("finite nonzero inverse", H*Hinv, Q)
delta = s.symbols("delta", positive=True)
HIGH_CORRECTOR_SIGN = -1
y = HIGH_CORRECTOR_SIGN*B*Hinv*Q
vprime = -I*H*Q/delta
yprime = HIGH_CORRECTOR_SIGN*B*Hinv*vprime
residual = I*(vprime+delta*yprime)-(H/delta+B)*(Q+delta*y)
exact("high-spectrum corrector residual", residual, -delta*B*y)
exact("high-spectrum corrector is a physical zero vector", H*y, s.zeros(dim))
assert y != s.zeros(dim)
print("NONCUBIC_FIXTURE", json.dumps({"pair_probabilities": ["1/2", "1/3", "1/6"],
      "I0_fixture": str(I0), "physical_dimension": dim-1,
      "zero_dimension": Pi.rank(), "nonzero_dimension": Q.rank(),
      "continuum_integral_values": False}))

# Exact sign margins and one global contact normalization.
A2 = s.symbols("A2", positive=True)
radius = A2/777600
delta_over_lambda = A2/44236800
exact("momentum-envelope error budget", 9*radius, A2/86400)
exact("actual-band preparation error budget", 512*delta_over_lambda, A2/86400)
exact("surviving three-component current drift",
      -A2/21600+9*radius+512*delta_over_lambda, -A2/43200)
lam = s.symbols("lambda", positive=True)
exact("explicit band lower coefficient", (-A2/43200).subs(A2, lam/(9*s.pi**2)),
      -lam/(388800*s.pi**2))
free_weights = [R(1, 7), R(2, 7), R(4, 7)]
survival = [R(9, 10), R(4, 5), R(3, 4)]
norm2 = sum(w*n for w, n in zip(free_weights, survival))
GLOBAL_RENORMALIZATION = True
physical_weights = [w*n/(norm2 if GLOBAL_RENORMALIZATION else 1)
                    for w, n in zip(free_weights, survival)]
exact("single global projection normalization", sum(physical_weights), 1)
assert physical_weights != free_weights
fiber_drifts = [-A2/43200, -A2/21600, -A2/14400]
total = s.simplify(sum(w*d for w, d in zip(physical_weights, fiber_drifts)))
assert s.simplify(total/A2) <= -R(1, 43200)
print("EXACT positive global weights preserve the common current bound")
print(json.dumps({"elapsed_seconds": time.monotonic()-start,
                  "limits": "No continuum spectral-mass bound, delta(lambda) rate, or all-state relaxation theorem is computed."}))
