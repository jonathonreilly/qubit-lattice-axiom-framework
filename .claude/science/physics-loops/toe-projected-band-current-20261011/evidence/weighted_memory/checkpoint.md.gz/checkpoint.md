# Weighted-memory checkpoint

The frozen memory source b667b092 and full-zero-space source b8f923be are
unchanged. Their complete readings are reused after identity verification.
The exact Kato primary PDF 12ce9d67 has been found locally. All five pages'
extracted text were read; page 260's theorem and page 263's completeness proof
were inspected visually from the embedded page images. OCR dropped adjoint
stars and misread the date; the page images resolve those details.

Checked route: A0=D direct-sum 0 on the same Z=F direct-sum C,
V=A-A0 has eigenvalues +/-||g|| and trace norm 2||g||. The memory proof
establishes zeta in ac(A), not just amplitude decay. Kato's reverse strong
limit gives (u_plus,0)=Omega_plus^* zeta in ac(D) direct-sum 0 with norm one.
Hence the full state tends in norm to (exp(-itD)u_plus,0).

For every bounded even scalar multiplication weight w(q), w preserves F
and commutes with D.
Its expectation therefore tends to integral w |u_plus|^2. In particular
0<W_plus=||epsilon u_plus||^2<3 and 0<W_a=||sin(q_a)u_plus||^2<1.
The actual canonical current coefficient tends to 1-2W_a. For every
nonzero kappa_a, the ordered original-walk scaled drift is -2kappa_a W_a.
For diagonal kappa, W_a=W_plus/3. This is positive weighted transfer and
a nonzero signed drift; positivity of the final current is not asserted.

The complete source-bound proof W1-W17 and exact rank/continuous toy controls
are finished. All 17 baseline checks passed; four actual source-copy mutants
failed at their intended assertions. Full logs are preserved. The independent
parent memory review c8dbb786 was read completely (329 lines); it does not
review this new extension. The weighted extension now awaits its own
source-bound independent examination.

The receipt freezes the final note, helper/control evidence, primary theorem
extracts/images, and verified unchanged parent identities. No rate, Markov
premise, global trace-class statement, new normalizable envelope theorem,
arbitrary free-band preparation or exchange of lambda/time limits is claimed.
No final-current positivity is claimed. Root's separate joint-scaling work
is outside this packet.
