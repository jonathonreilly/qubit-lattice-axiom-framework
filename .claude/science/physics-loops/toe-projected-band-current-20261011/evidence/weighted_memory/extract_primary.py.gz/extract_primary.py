"""Reproducible extraction of the frozen primary source; no network."""
from pathlib import Path
import hashlib
import json
import pypdf
from PIL import Image

D = Path(__file__).resolve().parent
pdf = D.parent/'excluded_walk_review/kato_1957_primary.pdf'
assert hashlib.sha256(pdf.read_bytes()).hexdigest() == '12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5'
reader = pypdf.PdfReader(pdf)
text = '\n'.join(f'PAGE {i+1}\n'+p.extract_text() for i,p in enumerate(reader.pages))
(D/'kato_extracted.txt').write_text(text)
for i in [0,3]:
    image = reader.pages[i].images[0]
    target = D/f'kato_page_{i+1}_image_0_{image.name}'
    target.write_bytes(image.data)
    with Image.open(target) as im:
        im.save(D/f'kato_page_{i+1}.png')
print(json.dumps({'pages':len(reader.pages),'extractor':'pypdf','version':pypdf.__version__,
                  'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
                  'visual_pages':[260,263],
                  'warning_scope':'OCR text has lost adjoint stars and a date digit; embedded primary images are decisive'}))
