"""Verify source-bound evidence and write the external weighted-memory receipt.

No mathematical test is replayed and no parent artifact is written.
Run only before freezing; a future reproduction must use a fresh output path.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

D = Path(__file__).resolve().parent
S = D.parent
W = S.parent / 'worktree'
NOTE = S / 'EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identify(path):
    data = path.read_bytes()
    out = {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(),
           'bytes': len(data)}
    if path.suffix in {'.py', '.md', '.json', '.log', '.txt'}:
        out['lines'] = len(data.splitlines())
    return out


verified = {}


def verify(record):
    p = Path(record['path'])
    actual = identify(p)
    assert actual['sha256'] == record['sha256'], str(p)
    if 'bytes' in record:
        assert actual['bytes'] == record['bytes'], str(p)
    if 'lines' in record:
        assert actual['lines'] == record['lines'], str(p)
    verified[str(p)] = actual
    return actual


expected = {
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md':
        'b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c',
    'effective_memory/receipt.json':
        '99cad79eeb712071bfc48a04a161df7280cea694f80523dc86c563537f272557',
    'effective_memory/source_identity_check.json':
        'b1cb81f2e5ee520c647a4c95c0921e23d4a0a2df0bb56fe51e63cf69fc7d022b',
    'EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md':
        'c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0',
    'excluded_walk_memory_review/independent_review_receipt.json':
        '5a73e562741e0e10e84101206a0c98d2f3daf4d534898260d14fe85a1f101fe6',
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md':
        'b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876',
    'EXCLUDED_WALK_DEGENERATE_DYNAMICS_REVIEW.md':
        'c0a788f05c291a900acf3bc1002e139f2c0eba749ee6cdc7b08c6bf4812dc9a2',
    'excluded_walk_degenerate/receipt.json':
        '369bebc245e0e7794608d6a1ef29a4ccd3d374a85f3f3bcc20f0f2dd81288dde',
    'excluded_walk_degenerate_review/independent_review_receipt.json':
        'c4d07a7e025986d1bfc2ba2e479ff34c0c4b73cabe21f1ccc68aaedd64144baa',
    'lean_audit/receipt.json':
        '1564b0bf532aca6c7f43c301455163b1af0afb96405e620eb56c481bdf7ed96d',
    'excluded_walk_review/kato_1957_primary.pdf':
        '12ce9d67ed67d096f82b55a6ef7b778a83c16d5e2f020d4946d58112f3f93fe5',
}
direct_sources = {name: verify({'path': str(S/name), 'sha256': sha})
                  for name, sha in expected.items()}
memory = json.loads((S/'effective_memory/receipt.json').read_text())
identity = json.loads((S/'effective_memory/source_identity_check.json').read_text())
review = json.loads((S/'excluded_walk_memory_review/independent_review_receipt.json').read_text())
assert len(memory['artifacts']) == 26
assert len(identity['verified_unchanged_records']) == 104
assert len(review['outputs']) == 14
for records in [memory['artifacts'], identity['verified_unchanged_records'],
                review['outputs']]:
    for record in records:
        verify(record)

instructions = {}
for name, sha in identity['instructions'].items():
    if name.startswith('origin/ai/execution:'):
        data = subprocess.check_output(['git', '-C', str(W), 'show', name])
        actual = hashlib.sha256(data).hexdigest()
        assert actual == sha, name
        instructions[name] = {'sha256': actual, 'bytes': len(data)}
    else:
        p = W/name.removeprefix('worktree:')
        instructions[name] = verify({'path': str(p), 'sha256': sha})
local_refs = {ref: subprocess.check_output(
    ['git', '-C', str(W), 'rev-parse', ref], text=True).strip()
              for ref in ['HEAD', 'origin/main', 'origin/ai/execution']}

source = (D/'weighted_controls.py').read_text()
baseline = json.loads((D/'baseline_execution.json').read_text())
assert baseline['returncode'] == 0 and baseline['timeout_seconds'] == 120
assert digest(D/baseline['source']) == baseline['source_sha256']
assert digest(D/baseline['log']) == baseline['log_sha256']
assert baseline['source_sha256'] == '70807cce821d3e2eca3fc96cefd52fa1cfe83c4496801b9c9f2f7b9dd5108c24'
rows = [json.loads(line) for line in (D/baseline['log']).read_text().splitlines()]
assert len(rows) == 18 and rows[-1]['checks'] == 17
assert sum('check' in row for row in rows) == 17
mutations = json.loads((D/'mutation_manifest.json').read_text())
assert len(mutations) == 4
for mutation in mutations:
    assert source.count(mutation['old']) == 1
    assert (D/mutation['source']).read_text() == source.replace(mutation['old'], mutation['new'])
    assert digest(D/mutation['source']) == mutation['source_sha256']
    assert digest(D/mutation['log']) == mutation['log_sha256']
    assert mutation['returncode'] == 1 and mutation['timeout_seconds'] == 120
    assert mutation['failed_at_intended_assertion']
    assert 'AssertionError: '+mutation['intended_assertion'] in (D/mutation['log']).read_text()
extraction = json.loads((D/'extraction.json').read_text())
assert extraction['pages'] == 5
assert digest(Path(extraction['pdf'])) == extraction['sha256']
assert (D/'kato_extracted.txt').read_text().count('PAGE ') == 5
assert 'ModuleNotFoundError' in (D/'extraction_attempt01.log').read_text()
assert 'pdf_sha256' in (D/'extraction_final.log').read_text()

artifacts = [identify(NOTE)] + [identify(p) for p in sorted(D.iterdir())
                              if p.is_file() and p.name != 'receipt.json']
receipt = {
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'task': 'Asymptotic weighted transfer and the effective canonical current',
    'status': 'External conditional bounded theorem candidate; no audit or retained-status decision',
    'note': identify(NOTE),
    'source_coverage': {
        'memory_note': 'Complete earlier 500-line reading reused at identical bytes; E23 absolute continuity is essential.',
        'memory_review': 'Complete 329-line new independent review read; supports parent E1-E29 only, not this extension.',
        'degenerate_note': 'Complete earlier 549-line reading reused; current D12-D18 refreshed against the current bound.',
        'degenerate_review': 'Complete earlier 375-line reading reused at identical bytes.',
        'primary_kato': 'All five extracted pages read; original embedded page images for theorem p.260 and completeness proof p.263 visually inspected. OCR drops stars; images settle conventions.',
        'new_note': 'Entire final argument W1-W17 read after drafting; all new controls and runner read completely.',
        'new_logs': 'Complete baseline, four intended-failure tracebacks and extraction logs read; no prior runner replay claimed.'
    },
    'direct_sources': direct_sources,
    'verified_unchanged_records': list(verified.values()),
    'parent_identity_groups': {'memory_artifacts': 26, 'protected_earlier_records': 104,
                               'independent_memory_review_outputs': 14,
                               'lean_packet_in_protected_earlier_records': True},
    'primary_import': {
        'author': 'Tosio Kato', 'year': 1957,
        'title': 'Perturbation of Continuous Spectra by Trace Class Operators',
        'url': 'https://www.jstage.jst.go.jp/article/pjab1945/33/5/33_5_260/_pdf',
        'theorem': 'Theorem 1 p.260, with Section 3 completeness proof p.263',
        'hypotheses': ['H0 selfadjoint on a Hilbert space',
                       'V bounded selfadjoint trace class on that same space', 'H1=H0+V'],
        'matched_objects': 'H0=D direct-sum 0, H1=A, V rank two with trace norm 2||g||; all domains are Z=F direct-sum C.',
        'conventions': 'Omega_+=s-lim e^{itA}e^{-itA0}P0; reverse adjoint limit e^{itA0}e^{-itA}P1; outgoing datum Omega_+^* zeta.',
        'completeness_use': 'Omega_+Omega_+^*=P_ac(A); parent E23 places zeta in that subspace.',
        'not_required': 'No claim that all of D or A is absolutely continuous; no endpoint estimate imported here.',
        'access': 'Locally archived PDF; no new network request'
    },
    'executions': {'baseline': baseline, 'mutations': mutations},
    'controls': {'passed': 17, 'mutants_rejected_as_intended': 4,
                 'scope': 'Exact finite rank/current/conjugacy identities; a solvable continuous toy and separate floating quadrature. These are author checks, not independent review or a continuum-walk numerical proof.'},
    'environment': {key: rows[-1][key] for key in ['python', 'sympy', 'numpy', 'scipy']},
    'strongest_proved_statements': [
        'For each fixed nonzero kappa, the dressing has a unit-norm outgoing transverse datum u_+ in ac(D).',
        '||epsilon u(t)||^2 tends to W_+=||epsilon u_+||^2 strictly between zero and three.',
        'Each canonical current coefficient tends to 1-2W_a with 0<W_a<1.',
        'The ordered small-lambda then large-effective-time current drift is -2 kappa_a W_a.',
        'For diagonal kappa, W_a=W_+/3.'
    ],
    'limits_and_open_obligations': [
        'No rate, numerical positive lower bound, Markov or decoherence premise.',
        'No assertion that the final current itself is positive.',
        'Only ordered lambda/time limits; no joint schedule or reversal.',
        'Fixed total-momentum fiber, with no new normalizable envelope or global trace-class theorem.',
        'No theorem for arbitrary lambda-dependent projected free-band preparation.',
        'kappa=0 is excluded because the dressing remains a point vector.',
        'Weighted extension awaits its own source-bound independent review; parent reviews cover their own frozen sources.'
    ],
    'failed_routes_and_tooling': 'See development_log.md and extraction_attempt01.log; no failed analytic claim was silently replaced. Positivity alone gives no coercivity constant.',
    'instructions_reused_after_identity_verification': instructions,
    'local_refs_only_no_fetch': local_refs,
    'freshness_scope': 'Local identified sources only; no remote freshness or global novelty assertion.',
    'editable_prompt_files_changed': [],
    'writes': [str(NOTE), str(D)],
    'artifacts': artifacts,
    'receipt_scope': 'Identity and execution record, not an independent scientific review; receipt excludes itself.'
}
(D/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'note': identify(NOTE), 'receipt': identify(D/'receipt.json'),
                  'artifacts': len(artifacts), 'verified_unchanged_records': len(verified),
                  'controls_passed': 17, 'intended_mutations_rejected': 4}))
