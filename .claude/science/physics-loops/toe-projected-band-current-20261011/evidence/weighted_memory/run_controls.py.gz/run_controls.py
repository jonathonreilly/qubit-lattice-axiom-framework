"""Save full baseline and actual source-copy mutation logs."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

D=Path(__file__).resolve().parent
PY='/opt/homebrew/opt/python@3.13/bin/python3.13'
source=(D/'weighted_controls.py').read_text()


def execute(path,log):
    begin=time.monotonic()
    cmd=[PY,str(path)]
    with log.open('w') as f:
        try:
            p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
            rc=p.returncode
        except subprocess.TimeoutExpired:
            rc=124
    return {'command':cmd,'returncode':rc,'elapsed_seconds':time.monotonic()-begin,
            'timeout_seconds':120,'source':path.name,'log':log.name,
            'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}


baseline=execute(D/'weighted_controls.py',D/'baseline.log')
(D/'baseline_execution.json').write_text(json.dumps(baseline,indent=2)+'\n')
print(json.dumps(baseline))
assert baseline['returncode']==0
cases=[
    ('trace_norm_half','claimed_trace_norm = 2*sp.sqrt(eta)',
     'claimed_trace_norm = sp.sqrt(eta)','trace_norm_factor_two'),
    ('forward_not_reverse','outgoing = Omega.conjugate().T*zeta',
     'outgoing = Omega*zeta','reverse_wave_operator_norm_one'),
    ('weighted_cross_sign','sp.Rational(1,3)+a*a/3+2*a*sp.diff(a,t,2)',
     'sp.Rational(1,3)+a*a/3-2*a*sp.diff(a,t,2)','continuous_weighted_formula'),
    ('continuous_measure_factor','a = sp.integrate(sp.cos(t*x), (x,-1,1))/2',
     'a = sp.integrate(sp.cos(t*x), (x,-1,1))','normalized_continuous_amplitude'),
]
records=[]
for name,old,new,intended in cases:
    assert source.count(old)==1
    p=D/f'mutant_{name}.py';p.write_text(source.replace(old,new))
    result=execute(p,D/f'mutant_{name}.log')
    result.update({'name':name,'old':old,'new':new,'intended_assertion':intended,
                   'failed_at_intended_assertion':result['returncode']==1 and
                       'AssertionError: '+intended in (D/result['log']).read_text()})
    records.append(result);print(json.dumps(result))
(D/'mutation_manifest.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(x['failed_at_intended_assertion'] for x in records)
