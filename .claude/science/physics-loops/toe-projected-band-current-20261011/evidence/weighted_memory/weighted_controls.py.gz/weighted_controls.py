"""Exact and independent-form controls for the weighted scattering implication."""
import json
import platform
import numpy as np
import sympy as sp
import scipy
from scipy.integrate import quad

count = 0


def check(name, condition, detail=None):
    global count
    assert bool(condition), name
    count += 1
    print(json.dumps({'check':name,'detail':detail}))


def zero(value):
    if isinstance(value, sp.MatrixBase):
        return all(sp.simplify(x) == 0 for x in value)
    return sp.simplify(value) == 0


I = sp.I
g = sp.Matrix([sp.Rational(3,13)+I*sp.Rational(4,13), -I*sp.Rational(12,13)])
eta = sp.simplify((g.conjugate().T*g)[0])
V = sp.zeros(2).row_join(g).col_join(g.conjugate().T.row_join(sp.zeros(1)))
check('rank_two_selfadjoint', zero(V-V.conjugate().T))
check('rank_two_actual_rank', V.rank() == 2)
check('rank_two_minimal_polynomial', zero(V**3-eta*V))
singulars = V.singular_values()
trace_norm = sp.simplify(sum(singulars))
claimed_trace_norm = 2*sp.sqrt(eta)
check('trace_norm_factor_two', zero(trace_norm-claimed_trace_norm),
      {'eta':str(eta),'singular_values':list(map(str,singulars))})

# The continuous conjugacy example below has Omega=U P0 on its ac part.
# These exact matrices only test the adjoint/source-channel convention.
U = sp.Matrix([[0,1],[1,0]])
P0 = sp.diag(1,0)
Omega = U*P0
zeta = sp.Matrix([0,1])
check('partial_isometry_initial_final', zero(Omega.conjugate().T*Omega-P0) and
      zero(Omega*Omega.conjugate().T-U*P0*U.conjugate().T))
outgoing = Omega.conjugate().T*zeta
check('reverse_wave_operator_norm_one', zero((outgoing.conjugate().T*outgoing)[0]-1))
check('forward_wave_operator_wrong_source_zero', zero(Omega*zeta))

# Independent continuous model: multiplication by x on L2([-1,1],dx/2)
# conjugated by the exact swap of the constant function and scalar channel.
x = sp.symbols('x', real=True)
t = sp.symbols('t', real=True, positive=True)
a = sp.integrate(sp.cos(t*x), (x,-1,1))/2
check('normalized_continuous_amplitude', zero(a-sp.sin(t)/t))
norm_u = sp.integrate(1+a*a-2*a*sp.cos(t*x), (x,-1,1))/2
check('continuous_full_state_norm', zero(norm_u+a*a-1))
comparison_norm_squared = sp.integrate(a*a, (x,-1,1))/2+a*a
check('strong_comparison_error_exact', zero(comparison_norm_squared-2*a*a))
direct_weight = sp.integrate(x*x*(1+a*a-2*a*sp.cos(t*x)), (x,-1,1))/2
memory_weight = sp.Rational(1,3)+a*a/3+2*a*sp.diff(a,t,2)
check('continuous_weighted_formula', zero(direct_weight-memory_weight))
limit_weight = sp.limit(memory_weight,t,sp.oo)
check('continuous_positive_weighted_limit', limit_weight == sp.Rational(1,3), str(limit_weight))

# The perturbation of the conjugacy model, in (f0,sqrt(3)*x,zeta0),
# is independently represented as an actual finite-rank matrix.
h = sp.Matrix([0,1/sp.sqrt(3),0])
w = sp.Matrix([-1,0,1])
Vtoy = h*w.T+w*h.T
check('continuous_toy_rank_two', Vtoy.rank() == 2 and
      zero(sum(Vtoy.singular_values())-2*sp.sqrt(sp.Rational(2,3))))

# Fresh numerical integrals compare the direct field expression with the
# symbolic weighted formula; no walk grid or finite-time scattering fit.
fn = sp.lambdify(t,memory_weight,'numpy')
errors=[]
for time in [0.13,1.7,8.2,31.0]:
    av=np.sinc(time/np.pi)
    result=quad(lambda q:q*q*abs(np.exp(-1j*time*q)-av)**2/2,-1,1,epsabs=1e-12)[0]
    errors.append(abs(result-float(fn(time))))
check('weighted_integral_floating',max(errors)<2e-10,errors)

# The actual current block, unlike its multiplication block alone, includes
# scalar cross terms. They drop out only on a zero-scalar comparison vector.
m=sp.diag(sp.Rational(-1,3),sp.Rational(2,5))
r=sp.Matrix([sp.Rational(1,7),I*sp.Rational(2,9)])
J=m.row_join(r).col_join(r.conjugate().T.row_join(sp.ones(1)))
v=sp.Matrix([sp.Rational(3,5),I*sp.Rational(4,5),0])
field=sp.Matrix(v[:2])
check('current_on_outgoing_field',zero((v.conjugate().T*J*v)[0]-(field.conjugate().T*m*field)[0]))
perturbed=sp.sqrt(sp.Rational(3,4))*v+sp.Matrix([0,0,sp.Rational(1,2)])
without_cross=sp.diag(sp.Rational(-1,3),sp.Rational(2,5),1)
check('finite_scalar_cross_term_cannot_be_dropped',
      not zero((perturbed.conjugate().T*(J-without_cross)*perturbed)[0]))

# Strict positivity of a weight gives no numerical coercivity constant by
# itself. This exact sequence is a scope control, not the actual u_plus.
n=sp.symbols('n',positive=True)
concentrated_norm=sp.integrate(n,(x,-1/n,1/n))/2
concentrated_weight=sp.integrate(n*x*x,(x,-1/n,1/n))/2
check('positive_weight_no_inferred_uniform_constant',zero(concentrated_norm-1) and
      zero(concentrated_weight-1/(3*n*n)))
print(json.dumps({'checks':count,'python':platform.python_version(),'sympy':sp.__version__,
                  'numpy':np.__version__,'scipy':scipy.__version__,
                  'scope':'exact rank/conjugacy/current identities and floating toy quadrature; not a numerical proof of Kato or continuum-walk scattering'}))
