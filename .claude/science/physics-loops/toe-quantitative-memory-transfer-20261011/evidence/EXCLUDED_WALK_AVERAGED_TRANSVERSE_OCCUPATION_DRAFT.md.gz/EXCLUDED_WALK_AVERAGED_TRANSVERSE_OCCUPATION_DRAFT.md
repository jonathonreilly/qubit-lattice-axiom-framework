---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
reachability_to_target: supports
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# A quantitative time-averaged transverse occupation for actual free-band packets

2026-10-11. Root research draft. The spectral-edge estimate used below is a
frozen provisional dependency whose independent review is pending. This composition has
not been independently reviewed. It is not part of the current publication
milestone until those obligations are completed.

The observable is the fixed transverse projection F in the physical pair
Hilbert space. It is a probability of occupying this specified subspace, not
a canonical current or an encounter rate. The supplied excluded walk,
continuous generator clock, contact projection and actual free-band
preparation are the same as in the identified sources.

## 1. Exact imported statements and unresolved dependency

The following frozen sources have already been read completely; the cited
arguments were refreshed for this composition:

- EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md, SHA-256
  09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324:
  L6-L10 give the band measure and projected preparation.
- EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md, SHA-256
  0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c:
  B18-B24 give the actual positive-band preparation and global weights.
- EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md, SHA-256
  4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278:
  G1,G4-G5 supply a finite estimate uniformly over a growing interval;
  G8 defines the globally normalized packet.

The spectral-edge proof is EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md, SHA-256
e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623.
Its source-bound independent review remains an explicit open dependency.
Its S20 statement for the effective dressing amplitude a(tau) is

    (1/T) integral_0^T |a(tau)|^2 dtau
       <= min(1,C_edge (bT)^(-4/5)),                         (A1)
    C_edge=24^(6/5) (327680 pi)^(4/5) I0^2,
    b=|kappa|>0, 1/12<=I0<=9/8.

The proposed proof combines the inverse-defect moment with the interior
density bound, giving

    integral rho(E)^(5/3) dE
       <=24 I0 (32768 pi I0)^(2/3) b^(-2/3).

Young's inequality in the particular (5/3,5/3,5) exponents and
||min(1,1/(T|x|))||_(5/4)=(10/T)^(4/5) then give A1. This paragraph
records the exact required input, not certification of its pending proof.
The constant in A1 follows by raising the density integral to power 6/5.

## 2. A finite band-weight remainder

Fix kappa0=(1,1,1), b=sqrt(3), and 0<lambda<=1/16. Use the actual normalized
free spectral slice phi_lambda of zeta on [5lambda/4,7lambda/4], its physical
projection chi_lambda=P phi_lambda/n_lambda, and
A_lambda=sqrt(w_lambda)/n_lambda. Put c_A=1/(8pi^2 I0).

The L7-L9 measure bounds imply

    c_A <= w_lambda/lambda
        <= c_A F_lambda,
    F_lambda=(1-49lambda^2/64)^(-3/2).

Cauchy-Schwarz against the free contact spectral projection gives
beta_lambda^2=|<c,phi_lambda>|^2<=integral_I rho(0,E)dE. Hence

    beta_lambda^2 <=49lambda^3 F_lambda/(128pi^2)
                   <=lambda^3/3.                         (A2)

For x<=1/16 the derivative of (1-x)^(-3/2) is below 2. Therefore
F_lambda<=1+2lambda^2. With pi^2>9 and I0>=1/12 we have c_A<=1/6, and

    0<=A_lambda^2/lambda-c_A
       <=c_A [(1+2lambda^2)/(1-lambda^3/3)-1]
       <=lambda^2.                                      (A3)

For the last inequality it suffices to use lambda<=1/16 and
2+lambda/3 <= 6(1-lambda^3/3). This also checks the denominator is positive.
Thus the band asymptotic used below has a finite uniform error bound.
The previously checked bounds F chi_lambda=0 and A_lambda<=2sqrt(lambda)
remain in force.

## 3. The central fiber on a growing time interval

For any fixed 0<gamma<1/2 set

    delta=lambda^3, sigma=lambda^2, T_lambda=lambda^(-gamma),
    p=1/2-gamma, E_lambda=275lambda^p.

Write psi_c(tau)=exp[-i tau H_D(delta kappa0)/delta]chi_lambda and
(u(tau),a(tau))=exp(-i tau A)zeta. The finite G5 estimate gives

    sup_(0<=tau<=T_lambda)
      ||F psi_c(tau)-A_lambda u(tau)||<=A_lambda E_lambda.

Since ||u(tau)||<=1, the difference of squared norms is bounded by
A_lambda^2(2E_lambda+E_lambda^2). Dividing by lambda and averaging yields

    |(1/(lambda T_lambda)) integral_0^T_lambda
           ||F psi_c(tau)||^2 dtau
       -(A_lambda^2/lambda)
           [1-(1/T_lambda)integral_0^T_lambda |a(tau)|^2 dtau]|
        <=8E_lambda+4E_lambda^2.                          (A4)

This uses a vector comparison for the actual evolving state. No norm limit
uniform over arbitrary initial vectors or uncontrolled infinite-time
substitution occurs. Combining A1,A3,A4 gives the finite conditional bound

    |(1/(lambda T_lambda)) integral_0^T_lambda
          ||F psi_c(tau)||^2 dtau-c_A|
       <=8E_lambda+4E_lambda^2+lambda^2
          +4 min(1,C_edge (sqrt(3)T_lambda)^(-4/5)).      (A5)

## 4. A packet with positive momentum volume

Use exactly the actual free-band family G8: eta_lambda=lambda^2,
f_lambda(kappa)=eta_lambda^(-3/2)h((kappa-kappa0)/eta_lambda), with a fixed
smooth normalized h supported in the unit ball and nonzero on an open set.
Let Phi_lambda(K,q)=delta^(-3/2) f_lambda(K/delta)phi_(lambda,K)(q),
and Chi_lambda=P Phi_lambda/||P Phi_lambda||. The total-momentum support
has center lambda^3 kappa0 and radius lambda^5; it is contained in the
actual positive free [lambda,2lambda] band before contact projection.

The same bounded Duhamel estimate and B19 give, uniformly in this support,

    ||exp[-i tau H_D(delta kappa)/delta]chi_(lambda,delta kappa)
         -psi_c(tau)||
       <=32delta/lambda+|tau|eta_lambda.                 (A6)

The observable F has norm one and is a fixed fiberwise projection. For
unit vectors the difference of its expectations is at most twice their
norm difference. Thus dividing by lambda and averaging over time costs
at most 64lambda+2lambda^(1-gamma), using the uniform endpoint bound.
The exact global weights are |f_lambda|^2 n_(lambda,delta kappa)^2 /
||P Phi_lambda||^2; they are positive and integrate to one. Integrating
this uniform estimate against those weights is legitimate without
changing the preparation or its probability law.

Set Psi_lambda(t)=exp(-it H_D)Chi_lambda and
H_lambda=T_lambda/delta=lambda^(-(3+gamma)). Define the actual occupation
average over physical time by

    O_lambda=(1/(lambda H_lambda)) integral_0^H_lambda
                     <Psi_lambda(t),F Psi_lambda(t)> dt.

The substitution tau=delta t exactly gives the previous time average.
Equations A5-A6 yield

    |O_lambda-c_A|
       <=8E_lambda+4E_lambda^2+lambda^2+64lambda
          +2lambda^(1-gamma)
          +4 min(1,C_edge (sqrt(3)T_lambda)^(-4/5)).      (A7)

In particular, under the pending A1 premise,

    |O_lambda-c_A|=O(lambda^min(1/2-gamma,4gamma/5)).      (A8)

Taking gamma=5/18 balances these two error exponents and gives

    H_lambda=lambda^(-59/18),
    O_lambda=1/(8pi^2 I0)+O(lambda^(2/9)).                (A9)

This balance is optimal only for the displayed pair of error exponents
with the already chosen delta and sigma. It is not an optimality theorem
for other scales or other arguments. All constants can be read from A7.

At time zero each actual prepared fiber has F-norm at most 32lambda^2
by A6 and F chi_lambda=0. Therefore <Chi_lambda,F Chi_lambda>/lambda
<=1024lambda^3. Subtracting the initial occupation from the averaged
occupation preserves A9, with that explicit additional error. A9 describes
an O(lambda) physical probability transferred to the fixed transverse
subspace. It does not say that most of the entire normalized packet ends
there.

## 5. Review obligations and claim limits

Freeze and check the full spectral-edge proof of A1; independently reconstruct
A2-A7 including the amplitude-sensitive squared-norm error, actual preparation,
exact global weights and physical-time Jacobian. Finite arithmetic controls
are consistency evidence only. This note proves no pointwise decay rate for
a(t), no rate for the limiting weighted current, no stochastic dynamics and
no many-body or native-law selection. Its status remains conditional and
provisional until the stated source and composition obligations are resolved.
