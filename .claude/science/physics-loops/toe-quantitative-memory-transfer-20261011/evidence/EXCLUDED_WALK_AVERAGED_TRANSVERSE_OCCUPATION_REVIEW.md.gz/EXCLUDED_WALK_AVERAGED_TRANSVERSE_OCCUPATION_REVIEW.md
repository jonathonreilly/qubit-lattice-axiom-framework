# Independent composition check of the averaged transverse occupation

2026-10-11. Source-bound review of the 192-line
`EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md`, SHA-256
`9729bbbfb26de3c7cf450b8eb81efea6fe2f3597b40289426cf6e9171de30c3d`.
No source correction is requested for these bytes.

## 1. Outcome and independence boundary

No consequential mathematical defect was found in A2–A9 under the explicit
A1 premise. The finite band remainder, amplitude-sensitive squared-norm
bound, growing-time use of Q16, actual nonzero-K free preparation, exact
global normalization and physical-time change all support the stated
conditional result

    H_lambda=lambda^(-59/18),
    O_lambda=1/(8pi^2 I0)+O(lambda^(2/9)).

The observable is the fixed projection F. This statement describes an
order-lambda time-averaged occupation of that subspace for the specified
constructed family; it is not a canonical-current rate or a many-body law.

I authored the spectral-edge note supplying S20/A1. I therefore treat A1
as a declared provisional input and do not independently recertify it in
this review. Its separate source-bound review was pending at dispatch and
is assigned to another reviewer. The present check supports the new
composition conditional on that input. It supplies no formal audit verdict,
retained status, publication authorization or Lean verification.

The target conclusion and exponent were visible in the dispatch and draft.
Before opening the author's controls, I reconstructed A2–A9 from the
identified sources and saved the complete argument in
`averaged_transverse_occupation_review/PRE_CONTROL_RECONSTRUCTION.md`,
SHA-256 `ceded0652dbf1ebdbb6fffb792175cffa18f9f163a98b40a3246ca8587d43967`.
The timestamped `pre_control_receipt.json` freezes that chronology and
the input identities. Independence is supplied by this reconstruction and
the separate exact projected-state/evolution fixture, not by a different
agent name or replaying the author controls.

## 2. Exact source coverage

All paths are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Source | SHA-256 | Coverage and role |
| --- | --- | --- |
| `EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md` | `9729bbbfb26de3c7cf450b8eb81efea6fe2f3597b40289426cf6e9171de30c3d` | Complete 192 lines, A1–A9 and all status/scope text; A2–A9 are the checked composition. |
| `EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md` | `ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400` | Complete 420 lines read; the finite all-T Q16, cutoff hypotheses and Q12–Q15 constants are load-bearing. This is not a new review of all its current conclusions. |
| `EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md` | `0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c` | Complete 327 lines read; B18–B19 actual preparation, Hamiltonian Lipschitz control, and B23 global normalization used. |
| `EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md` | `4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278` | Complete 236 lines read; G1/G4–G5/G8 used and reconstructed. Its Kato/weighted-current argument is unnecessary here and receives no new certification. |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Previous complete 457-line reading reused at identical bytes; L6–L10 supply the exact contact density and band normalization. |
| `EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md` | `e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623` | My authored 452-line source, completely read in the previous task. S20 is an explicit premise, not independently reviewed here. |

The unchanged degenerate and effective-memory sources, with hashes
`b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876`
and `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c`,
were completely read in the preceding task and supply the same physical
space and effective-unitarity identity. The receipt records their identities.
All reused source bytes were rechecked. No frozen parent or author source
was changed.

## 3. Band normalization and finite remainder

For `I_lambda=[5lambda/4,7lambda/4]`, the contact density satisfies
`rho(0,E)/E^2` between `1/(4pi^2)` and
`F_lambda/(4pi^2)`, with
`F_lambda=(1-49lambda^2/64)^(-3/2)`. Integrating over interval length
lambda/2 and dividing by I0 proves the claimed bounds on
`w_lambda/lambda`, including the coefficient `c_A=1/(8pi^2 I0)`.

Because phi_lambda lies in the free spectral slice and is normalized,
Cauchy-Schwarz gives
`beta_lambda^2<=||Gamma_lambda c||^2=integral_I rho(0,E)dE`.
Using the maximum `E^2=49lambda^2/16` proves the first A2 coefficient
`49/(128pi^2)`. The derivative bound for `(1-x)^(-3/2)` on `[0,1/16]`
and `49lambda^2/64<=lambda^2<=1/256` imply
`F_lambda<=1+2lambda^2<2`. Along with pi^2>9 this gives
`beta_lambda^2<=lambda^3/3`.

Both n_lambda and A_lambda use the actual physical normalization:
`A_lambda^2=w_lambda/(1-beta_lambda^2)`. Since c_A<=1/6,

    0<=A_lambda^2/lambda-c_A
      <=(lambda^2/6)(2+lambda/3)/(1-lambda^3/3)
      <=lambda^2,   0<lambda<=1/16.

The last inequality follows from
`2+lambda/3<=6(1-lambda^3/3)` on that interval. No unquantified band
asymptotic is substituted for A3's finite remainder.

## 4. Growing-time control and the small-amplitude square

Q16 is finite for every stated T before its later specialization to 1/20.
Its cutoff domain holds at sigma=lambda^2. With delta=lambda^3,
`T=lambda^(-gamma)>=1`, `0<gamma<1/2`, and b=sqrt(3), divide its four
terms by A_lambda. The valid relaxed bounds are

    108delta T/(sigma sqrt(lambda)),
    58T^2sqrt(sigma),
    96sigma/lambda^(3/2),
    13Tdelta/sqrt(lambda).

They use `1/A_lambda<=12/sqrt(lambda)`, `C_lambda<=4/lambda`,
`1/sqrt(I0)<4`, and `r_delta<=delta`. In particular the first bracket
is at most `(4+8T)+(4+4T)/A_lambda<=108T/sqrt(lambda)`, while the
second coefficient is at most `16+42T^2<=58T^2`.

Writing p=1/2-gamma, the resulting powers are p, 2p, 1/2 and 2+p.
All are at least p, giving the stated `275lambda^p=E_lambda`.
This is a direct substitution into a finite inequality; no compact-time
limit is silently extended to a growing interval.

At each effective time, let x=F psi_c and y=A_lambda u. Then

    abs(||x||^2-||y||^2)
      <=||x-y||(2||y||+||x-y||)
      <=A_lambda^2(2E_lambda+E_lambda^2).

After division by lambda, `A_lambda^2/lambda<=4` gives exactly
`8E_lambda+4E_lambda^2` in A4. Using `||u||^2=1-|a|^2`, the A3
band remainder, and the assumed A1 mean bound proves A5 with its
displayed constants. The small dressing amplitude is retained in both
factors of the squared-norm estimate.

## 5. Actual preparation, global weights, and time Jacobian

The packet's kappa support lies in the radius-lambda^2 ball about
kappa0=(1,1,1), where `|kappa|<2`. Its physical K support stays away
from zero and satisfies `|K|<=lambda/16` throughout the stated lambda
range. Thus the actual ++ projector construction of B18 applies, retains
the q support and remains in the free positive [lambda,2lambda] band.
This asserts free-band preparation, not preservation of that band under
the excluded evolution.

B19 supplies initial norm error at most `32delta/lambda`. The divided
generators differ in norm by at most `|kappa-kappa0|`; bounded Duhamel
adds `|tau|lambda^2`. This is exactly A6. For unit states a norm-one
projection's expectation changes by at most twice the state norm error.
Division by lambda and the uniform endpoint bound therefore give
`64lambda+2lambda^(1-gamma)`. Integrating the linear time error would
improve its last coefficient to one; the source's two is conservative.

Write `N^2=||P Phi_lambda||^2`. The globally normalized packet has
fiber amplitude `delta^(-3/2) f_lambda n_(lambda,delta kappa)/N`
times the unit physical fiber state. Hence its exact occupation is the
weighted integral of those fiber occupations with probability density

    |f_lambda(kappa)|^2 n_(lambda,delta kappa)^2/N^2.

These weights integrate to one and retain the prescribed support.
The uniform bound may therefore be integrated without assuming bare
envelope weights or a different physical preparation.

For H=T/delta, the change tau=delta t gives

    (1/(lambda H))integral_0^H q(delta t)dt
      =(1/(lambda T))integral_0^T q(tau)dtau.

Both the upper endpoint and the differential carry the same scaling.
The delta factors cancel exactly. This proves A7 from A5–A6.

The two leading powers are `1/2-gamma` and `4gamma/5`. Their intersection
is gamma=5/18, with common value 2/9; the physical horizon has exponent
`3+5/18=59/18`. Every remaining term in A7 has a larger exponent for
the allowed gamma. The stated optimization is correctly confined to the
displayed two-power balance and chosen delta/sigma scales.

Finally, `F chi_lambda=0` and B19 give initial F norm at most
32lambda^2 in every actual prepared fiber. Exact global weights thus
give initial probability at most 1024lambda^4, or 1024lambda^3 after
division by lambda. Its subtraction does not change A9's error order.

## 6. Controls and verification limits

After freezing the reconstruction, I read the complete author helper,
its complete 14-control log and execution metadata. Their identities
match. The controls check exact arithmetic and finite normalization
inequalities; the source accurately treats them as consistency evidence.
They were not replayed or used as proof of the continuum inputs.

The subsequently frozen author receipt has SHA-256
`b2cccd048ee59f6cc4581284eec16e9a82b0787fe2a8598fcaf813e88f71dd24`.
I verified all 16 recorded file identities, read its mutation harness and
three complete failure logs, and checked the unique literal replacements.
Halving the normalized cross-term coefficient, changing the physical
clock exponent, and dropping the global normalization each fail at the
intended assertion. These remain author consistency evidence and do not
alter the independent reconstruction or its scope.

The separate helper
`averaged_transverse_occupation_review/independent_packet_controls.py`
does not import the author helper. It builds three normalized input
vectors, applies a contact projection to their actual nine-dimensional
direct sum, and evolves the projected vector under three explicit
self-adjoint generators. Matrix exponentials are checked against their
differential equations. The projected squared norm is `67/90`; its actual fiber
weights are `27/134,27/134,40/67`, obtained from norm losses
`3/4,1/2,8/9`. At effective horizon pi/4, direct integration yields

    mean=(53+67pi)/(134pi).

Replacing the exact weights by the original envelope weights changes
that mean by `32/(335pi)`. A separate direct integration of the physical
evolution at delta=1/8000 and horizon 2000pi verifies the time change.
An actual unit state also realizes the amplitude-sensitive squared-norm
error: it is 9/1024, while the incorrect quadratic-only value is 1/1024.

The independent baseline passed nine exact controls on its first run.
Two actual source-copy defects replace exact weights by bare weights and
omit the time Jacobian. Each exits 1 at its intended assertion. Complete
sources, logs and exact differences were read. The runtime was Python
3.13.5 with SymPy 1.14.0, using 120-second process limits. This finite
comparator tests the normalization and probability algebra; it is not a
torus quadrature, free-band realization, numerical proof of Q16 or test
of A1. The continuum result rests on the source-bound reconstruction.

The frozen receipt in `averaged_transverse_occupation_review/receipt.json`
binds this review, the reconstruction, all inputs, author evidence,
independent controls, execution records and failures. The current
checkpoint names the same source and remaining dependency. The applied
reviewer skill and proof-search reference match main at
`a13caa4885f547c8d206265b031ba7649e539fd9`; previously read scientific
workflow and premise instructions were reused at verified unchanged
identities. No editable prompt, repository source, author source, PR,
primitive registry or audit state was changed.

The safe disposition is support for A2–A9 conditional on the declared A1
and supplied-model inputs. A separate S20 source review remains necessary
for independent coverage of that premise. No pointwise decay, weighted
canonical-current convergence rate, generic-state theorem, empirical clock
calibration or many-body interpretation is certified here.
