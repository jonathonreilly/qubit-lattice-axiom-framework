---
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: upstream_support
reachability_to_target: partially_closes
conditional_surface_status: exact estimates for the supplied effective generator
hypothetical_axiom_status: null
admitted_observation_status: null
claim_type_reason: Quantitative spectral and mean-survival estimates under the frozen supplied-model hypotheses.
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Spectral-edge mass and a mean-survival rate for the effective dressing state

2026-10-11. External author composition for the supplied excluded Weyl walk.
Independent examination of this completed source is pending.

The dressing spectral measure has a finite inverse-edge moment. Its combined
edge mass is at most linear in the edge width. The moment and the previously
proved interior density bound imply an explicit mean-survival estimate
of order `(bT)^(-4/5)`, uniformly in the direction of nonzero kappa, where
`b=|kappa|`. The proof uses bounded compression, pointwise transverse
orthogonality, a regulated inverse form, and an elementary convolution bound.

The result concerns evolution by the fixed effective generator from its
normalized dressing vector. It supplies no pointwise amplitude decay rate,
weighted-current convergence rate, or growing-time approximation of the
original excluded walk. All supplied-model premises remain in force.

## 1. Frozen sources, target, and exact setup

Let S be
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
and W be
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/walk_worktree`.
The following four source files were read completely in this recovery and
their SHA-256 identities rechecked before freezing:

| Source relative to S | SHA-256 | Coverage used |
| --- | --- | --- |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | All 500 lines; E1–E29, especially E20–E26 |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | All 329 lines; source-bound check of the frozen memory theorem |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | All 457 lines; normalized torus, L2–L5 and L23 |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | All 549 lines; physical zero space and D4–D8 |

The assigned quantitative obligation is the memory note's Section 6:
“no quantitative bound on e_delta as delta tends to zero is proved.”
Equations S8 and S12 below discharge that edge estimate within the same
supplied model; S20 then gives a stronger mean-survival rate. The remaining
pointwise-rate alternative in the source's Section 8 is not discharged.
This is upstream support for the dressing-memory/transfer calculation,
with no claim of native physical derivation or formal retention.

Work in the Hilbert space of odd square-integrable complex triplet fields on
the three-torus, with normalized measure `dmu=dq/(2pi)^3`. Inner products
are linear in the second slot. Put

    s_j=sin q_j,  epsilon=|s|,  n=s/epsilon,
    I0=integral (4epsilon^2)^(-1) dmu,
    zeta=n/(2epsilon sqrt(I0)),
    F={odd u in L2: n·u=0 almost everywhere},
    Z=F direct-sum span{zeta},  Pi=F+|zeta><zeta|.          (S1)

The same letter F denotes the orthogonal projection onto that closed
subspace. Cone points form a null set. The source proves
`1/12<=I0<=9/8` and `||zeta||=1`; its inverse-radius singularities are
square-integrable. Z is the full physical zero space. The auxiliary
constant singlet is not in Z and is not added to the calculation.

For fixed `kappa in R^3`, define

    b=|kappa|,  d_j=kappa_j cos q_j,
    Bv=i d cross v,  A=Pi B Pi restricted to Z,
    w(q)=sum_j kappa_j^2 sin^2 q_j,
    C=b^2 I_Z-A^2.                                       (S2)

B is bounded self-adjoint, preserves odd parity, and has norm at most b.
A is bounded self-adjoint on all Z, with norm at most b. All multipliers
and compressions used below are bounded. No derivative of zeta or inverse
of the gapless Hamiltonian is used. Let nu be A's probability spectral
measure at zeta. It is supported in `[-b,b]`. The source's block generator
gives

    exp(-itA)zeta=(u(t),a(t)),
    a(t)=integral exp(-itE) dnu(E),
    ||u(t)||^2=1-|a(t)|^2.                               (S3)

For `b=0`, A is zero and `a(t)=1`. All subsequent estimates assume `b>0`.
They hold for every direction of kappa, including `kappa=k(1,1,1)` with
nonzero k. The supplied walk, exclusion rule, pair Hilbert space, chosen
preparation, torus normalization and effective clock remain premises.
No approved primitive is being reclassified, and none supplies these
model choices or a physical identification of S3.

## 2. A rank-one lower bound for the spectral defect

Pointwise, the cross-product square is

    B^2=|d|^2 I-dd^T,
    b^2 I-B^2=w I+dd^T.                                 (S4)

The real vector d makes `dd^T` a positive Hermitian multiplication
operator, also on complex fields. Keep the positive compression defect:
on Z,

    C=Pi(b^2 I-B^2)Pi+Pi B(I-Pi)B Pi
     =Pi w Pi+Pi dd^T Pi+R*R,
    R=(I-Pi)B Pi.                                       (S5)

For `z=u+alpha zeta in Z`, u is pointwise transverse and zeta is
pointwise longitudinal. Multiplication by the scalar w preserves that
orthogonality, so

    <z,w z>=<u,w u>+|alpha|^2<zeta,w zeta>.

The dressing coefficient is exact. Coordinate permutation invariance
of the normalized torus measure and
`sum_j sin^2(q_j)/epsilon^2=1` almost everywhere give

    integral sin^2(q_j)/epsilon^2 dmu=1/3,
    <zeta,w zeta>=(1/(4I0))sum_j kappa_j^2/3
                 =b^2/(12I0)=:c>0.                     (S6)

Thus `Pi w Pi=F w F+c|zeta><zeta|` on Z. Combining the three positive
terms in S5 proves the bounded quadratic-form inequality

    C >= c |zeta><zeta|,     c=b^2/(12I0).               (S7)

This estimate is about the dressing direction. It is not a positive
uniform lower bound on C. Indeed `||A||=b`: the transverse compression
`D=FBF` acts as `D u=i(d·n)n cross u`, hence `|Du|=|d·n||u|` for
transverse u. Along `q=r kappa/b` as positive r tends to zero,
`d·n->b`. For every positive tolerance, continuity away from the cone
gives a positive-measure small neighborhood on which `|d·n|` is within
that tolerance of b. A normalized transverse field supported there and
its negative, extended oddly, belongs to F and has D norm arbitrarily
close to b. The F component of A on this vector is D, so `||A||>=b`.
Together with S2 this gives equality. S7 therefore cannot be replaced by
a positive operator-norm spectral gap.

## 3. Actual combined-edge mass

For `0<delta<b`, write `chi=delta/b`, and use the spectral projection

    P_delta=1_{|A|>=b-delta},
    m_delta=<zeta,P_delta zeta>
           =nu({E: |E|>=b-delta}).

For `z=P_delta zeta`, both `||z||^2` and `<zeta,z>` equal m_delta.
On the range of this projection, `0<=C<=h_delta I`, where
`h_delta=2b delta-delta^2`. Consequently S7 gives

    c m_delta^2 <=<z,Cz><=h_delta m_delta,
    m_delta<=min{1,12I0(2chi-chi^2)}.                    (S8)

If m_delta is zero there is nothing to divide; otherwise division by
`c m_delta` proves the estimate. Both spectral edges are already inside
P_delta. There is no additional doubling in S8. This is a bound for the
actual spectral mass; it does not identify that mass with the Poisson
quantity used by the memory note.

## 4. A regulated inverse-form estimate

The useful stronger fact is

    integral_[−b,b] dnu(E)/(b^2-E^2) <=12I0/b^2.         (S9)

Here an infinite integrand at an endpoint is interpreted in the
nonnegative extended-integral sense. To prove S9 without assuming a
bounded inverse of C, take `eta>0` and define

    x_eta=(C+eta I_Z)^(-1)zeta,
    t_eta=<zeta,(C+eta I_Z)^(-1)zeta> >0.

The regulator makes the inverse bounded everywhere. Since
`(C+eta I)x_eta=zeta`, S7 gives

    c t_eta^2 <=<x_eta,Cx_eta>
              =t_eta-eta||x_eta||^2 <=t_eta,
    t_eta<=1/c.                                         (S10)

By bounded spectral calculus,
`t_eta=integral (b^2-E^2+eta)^(-1)dnu(E)`. Let eta decrease to zero and
apply monotone convergence. This proves S9, and also excludes dressing
atoms at both endpoints. Equivalently, zeta belongs to the domain of
the spectral inverse square root `C^(-1/2)` and its squared norm is at
most `1/c`. No bounded `C^(-1)` on all Z is asserted.

S9 also reproves S8: on its edge set, `1/(b^2-E^2)>=1/h_delta`.
The direct projection proof was retained to expose the squared overlap
and the combined-edge normalization.

## 5. The source's Poisson edge term

The memory note defines the scalar resolvent and its computable edge
upper bound by

    M(z)=<zeta,(z-A)^(-1)zeta>,
    e_delta=min{1,4delta[-Im M(b+i delta)]}.             (S11)

That note proves symmetry of nu, for example from
`M(-conjugate(z))=-conjugate(M(z))`. It also proves absolute continuity,
so using strict or non-strict finite endpoints in m_delta has the same
value. In particular `m_delta<=e_delta`: on the upper edge the Poisson
factor `delta^2/((b-E)^2+delta^2)` is at least one half, and symmetry
accounts for the second edge.

For every `x>0`, elementary completion of a square gives

    delta/(2x)-delta^2/(x^2+delta^2)
       =delta(x-delta)^2/[2x(x^2+delta^2)]>=0.

S9 makes both `1/(b-E)` and `1/(b+E)` integrable: each is at most
`2b/(b^2-E^2)`. Symmetry then gives

    integral dnu(E)/(b-E)
       =b integral dnu(E)/(b^2-E^2)<=12I0/b.

Apply the scalar inequality with `x=b-E`, integrate, and retain the
factor four in S11. The result is

    e_delta<=min{1,24I0 chi}.                            (S12)

Endpoint absence handles the null exceptional point E=b. The actual mass
bound in S8 is slightly stronger than this bound on e_delta. The two
quantities remain distinct: e_delta includes a Poisson contribution from
energies outside the edge region.

## 6. From the inverse moment to an L^(5/3) density

The memory theorem E20–E23 supplies
`dnu(E)=rho(E)dE`, with rho nonnegative, integral one and support in
`[-b,b]`. Its uniform strip-resolvent proof gives, for each `0<delta<b`,

    rho(E)<=32768 pi I0 b^(1/2) delta^(-3/2)
             for almost every |E|<=b-delta.             (S13)

This is an inherited, source-bound conditional result, not an inference
from the finite controls in this packet. The frozen memory review checked
its cone-measure, Poisson domination and endpoint argument. That review
does not independently certify this new composition.

Set `K=32768 pi I0` and `d(E)=b-|E|`. Choose a single full-measure set
on which S13 holds for every rational delta in `(0,b)`. At any E in
that set, let rational delta increase to d(E), including d(E)=b if
E=0. This proves the usable pointwise envelope

    rho(E)<=K b^(1/2) d(E)^(-3/2),   |E|<b.             (S14)

There is no uncountable union of exceptional null sets. Raising only the
extra `2/3` density power in S14 gives

    rho(E)^(5/3)
       <=K^(2/3)b^(1/3) rho(E)/d(E).

Also `1/d(E)=(b+|E|)/(b^2-E^2)<=2b/(b^2-E^2)`.
After integration, S9 therefore yields

    integral rho(E)^(5/3)dE
       <=24I0 K^(2/3)b^(-2/3)=:R_b<infinity.            (S15)

In particular `||rho||_(5/3)^2<=R_b^(6/5)`. The unweighted envelope
S14 is not integrable at the edges; it is the weighted moment S9 that
makes S15 possible. A linear bound on cumulative edge mass by itself
would not supply the same finite inverse moment.

## 7. Direct convolution proof and the mean-survival rate

Here is the required special Young inequality, proved rather than
imported. Let f,g be nonnegative functions in `L^(5/3)(R)`, and put
`U=integral f^(5/3)`, `V=integral g^(5/3)`. At each x write

    f(x-y)g(y)
       =[f(x-y)^(5/3)g(y)^(5/3)]^(1/5)
          f(x-y)^(2/3)g(y)^(2/3).

Hölder in y with exponents `5,5/2,5/2` gives

    (f*g)(x)^5
       <=[f^(5/3)*g^(5/3)](x) U^2 V^2.

Integrating in x and using Tonelli gives
`integral(f*g)^5<=U^3 V^3`. One may first truncate f,g to bounded
compactly supported functions and then use monotone convergence. Thus

    ||f*g||_5<=||f||_(5/3)||g||_(5/3).                   (S16)

Extend rho by zero and set `tilde-rho(E)=rho(-E)` and
`h=rho*tilde-rho`. This difference density is nonnegative, even,
integrable with total mass one, and by S15–S16 satisfies
`||h||_5<=R_b^(6/5)`. For `T>0`, Fubini against the finite product
probability measure and exchange of the two energies give exactly

    Q(T):=(1/T)integral_0^T |a(t)|^2 dt
         =integral h(x) sinc(Tx) dx,
    sinc(v)=sin(v)/v,  sinc(0)=1.                       (S17)

The imaginary part cancels under exchanging the energies. No symmetry
of the original probability measure is needed for that cancellation,
and sinc is not assumed nonnegative. Its absolute value is at most

    K_T(x)=min{1,1/(T|x|)},  K_T(0)=1.

The exact whole-line norm is

    integral K_T(x)^(5/4)dx
       =2/T+2T^(-5/4)integral_(1/T)^infinity x^(-5/4)dx
       =10/T,
    ||K_T||_(5/4)=(10/T)^(4/5).                         (S18)

Hölder with exponents 5 and 5/4 now proves

    Q(T)<=||h||_5 ||K_T||_(5/4)
          <=R_b^(6/5)(10/T)^(4/5).                     (S19)

Substitution of S15, with `tau=bT`, gives the explicit statement

    D0=24^(6/5)(327680 pi)^(4/5) I0^2,
    Q(T)<=min{1,D0 tau^(-4/5)},
    (1/T)integral_0^T ||u(t)||^2dt
          >=max{0,1-D0 tau^(-4/5)},  T>0.              (S20)

All constants are independent of the direction of kappa. The large
constant is a conservative consequence of the inherited cone estimate;
no optimal exponent or prefactor is claimed. The result controls a mean
of the survival probability. It does not imply a pointwise `t^(-2/5)`
amplitude bound, a monotone transfer law, or weighted-current convergence.

## 8. Preserved earlier mean bound

The original edge worker used the source's central/edge split before
the L^(5/3) improvement was proposed. That route remains valid and its
helper and logs remain unchanged. For `tau=bT>=1/2`, put
`L=1+log(2tau)`. Combining source E25–E26 with S12 gives

    Q(T)^(1/2)
       <=24I0 chi+256sqrt(pi I0 L/tau) chi^(-3/4).

For

    Q0=64pi L/(I0 tau)<1,
    chi=Q0^(2/7),

the right side is `56I0 chi`, by direct differentiation or substitution.
Consequently

    Q(T)<=min{1,3136 I0^2 Q0^(4/7)}.                    (S21)

For example `tau>=2^16` guarantees Q0<1. Indeed L/tau decreases for
tau>=1/2; at `2^16`, use `I0>=1/12`, `pi<22/7`, and `L<18` to get
`Q0<297/448`. S21 is the earlier logarithmic estimate. S20 has a stronger
asymptotic power and removes this cutoff restriction. Either bound can
be used where numerically useful. The earlier briefly considered cone
cutoff gave only an O(sqrt(delta)) edge estimate; it was superseded by
the exact coefficient S6, not disproved by a counterexample.

## 9. Evidence, contributions, and remaining checks

The original worker produced the S5–S12 route, the S21 mean estimate,
`spectral_edge/edge_controls.py`, its execution record and five literal
source-copy mutants. Its two streaming disconnects left a checkpoint
and no completed edge note. The coordinator then proposed the S15–S20
improvement. The recovery worker checked the complete named source
arguments, completed the operator/domain and convolution proofs, wrote
this composition, and added a separately scoped `rate_controls.py`.
These are author contributions; the completed result still needs a
separate source-bound independent examination.

The original 20-control helper uses a finite three-antipodal-pair cubic
orbit with `I0_fixture=25/36` and physical zero-space dimension seven.
It reconstructs the compression square, its nonzero positive defect,
the exact scalar dressing coefficient and the two-edge projector. In
its diagonal-kappa example, the two-edge dressing mass is `25/33`, the
direct inverse moment is `649/297=59/27`, and the bound is `25/9`.
Those are finite fixture values, not certified torus-integral values.
The helper also checks the Poisson coefficient and the S21 constants.
Its five altered source copies separately delete the compression defect,
double the dressing coefficient, count only one edge, halve the Poisson
constant, and halve the earlier mean coefficient. Each existing process
log ends at the intended failed assertion. Their source differences,
execution records and full logs were inspected; the old evidence was
not overwritten or replayed as independent proof.

The new 15-control helper first uses a singular positive three-by-three
matrix with an exact rank-one Gram lower bound. Its regulated inverse
form has the finite predicted limit despite the matrix kernel. It then
integrates the S18 kernel exactly. As an unrelated continuous comparator
it uses `rho(E)=(3/4)(1-E^2)` on `[-1,1]`, computes its Fourier transform
and difference density symbolically, and checks the exact derivative and
origin of the one-sided sinc mean. Separate 50-digit time quadratures
agree with that spectral expression at four horizons, including horizons
where the Lp upper bound is below one. These floating checks have no
certified error enclosure. They are not a sample or limit of the torus
model and do not prove its continuum theorem.

Three new literal source-copy defects halve the S18 coefficient, the
one-sided mean, and the Young comparison bound. Each exited 1 at its
intended assertion. All full failure logs and exact differences were
read. The first new-helper execution failed at parsing because a closing
parenthesis was missing; its exact source and log are preserved as
`rate_controls_attempt1.py` and `rate_baseline.log`. Only that syntax
defect was repaired before the successful `rate_baseline_attempt2.log`.
No mathematical constant, assertion or tolerance changed in the repair.

The receipt `spectral_edge/receipt.json` binds this note, all input and
instruction identities, helper versions, logs, execution commands,
timeouts, literal mutations and the pre-recovery inventory. Every
pre-existing file remains byte-identical except the current checkpoint,
whose original bytes are preserved as `CHECKPOINT.before_recovery.md`.
The executable helpers use Python 3.13.5 and SymPy 1.14.0; the new helper
also uses mpmath 1.3.0. Recorded processes had 120-second timeouts.

Reproduce the finite controls directly, writing any new logs to fresh
paths so the frozen evidence is preserved:

```text
/opt/homebrew/opt/python@3.13/bin/python3.13 S/spectral_edge/edge_controls.py
/opt/homebrew/opt/python@3.13/bin/python3.13 S/spectral_edge/rate_controls.py
```

Here S denotes the literal absolute directory defined in Section 1.
The original `run_controls.py` is historical and would overwrite its old
logs if rerun; use the direct helper commands above. The new harness
refuses to overwrite existing logs. Test counts, source hashes and
mutation failures establish only their stated bookkeeping/control facts.
The analytical continuum claims rest on S4–S20 and the frozen memory
theorem, not on those counts.

The physics-loop and lane-builder skill texts and applicable references
match fetched `origin/main` at `a13caa4885f547c8d206265b031ba7649e539fd9`.
Planning instructions were read at
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`; W's observed HEAD was
`b9b032ae790c66e762a6296a1306bfb64ae7cd70`. A limited statement search
of matching walk/excluded source notes at the fetched main commit found
no matching edge/moment/mean-survival statement. Its commands and full
output are in `spectral_edge/recovery_statement_search.json`; it is not
a global literature or open-PR novelty claim. No specialized Fourier,
scattering or decay theorem is imported; S16 supplies the needed Young
case directly, while bounded spectral calculus, Hölder, Fubini/Tonelli
and monotone convergence are used with the domains above.

The next check is an independent reading of this exact frozen proof,
especially the rank-one compression, regulated inverse, density
interpolation, and one-sided time-average constants. No Lean verification
of these new steps is supplied. The inherited original-walk result still
has only the ordered limit in E29. Pointwise Fourier rates, weighted
canonical-current asymptotics, growing-time original-walk control and
arbitrary lambda-dependent free-band preparations remain separate open
questions. No repository source, frozen parent, editable prompt,
publication state, physical primitive, PR or audit verdict was changed
by this recovery.
