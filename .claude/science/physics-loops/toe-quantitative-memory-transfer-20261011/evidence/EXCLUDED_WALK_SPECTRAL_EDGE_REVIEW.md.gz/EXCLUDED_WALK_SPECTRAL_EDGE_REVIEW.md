# Selective mathematical review of the spectral-edge probe

2026-10-11. External source-bound review; no formal audit disposition.

The stated conditional estimates S4–S21 survive this check. I found no
mathematical repair needed in the compression, domain, density, or mean-rate
arguments. One terminal scope sentence should be narrowed before publication:
some selected weighted-current and joint-time conclusions already exist in
other frozen campaign sources. That wording issue does not change the edge
theorem. All author sources and evidence remain untouched.

## Exact scope and identities

All paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`
(S). The review covers the supplied fixed effective generator and its
normalized dressing vector. It does not review the later original-walk
averaged-occupation draft, adopt a physical law or clock, certify a native
derivation, or issue a retained/audit verdict.

| Source | SHA-256 | Reading coverage |
| --- | --- | --- |
| `EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md` | `e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623` | Complete 452 lines, all arguments and evidence/scope prose |
| `spectral_edge/receipt.json` | `7a96b9213a8c0faf014f35e4e4bcbdecd54d688bdc6b829b57d189b97fd7bec6` | Complete 659 lines |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md` | `b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c` | Earlier complete 500-line reading reused; E13–E26 refreshed, including the full cone/density argument |
| `EXCLUDED_WALK_EFFECTIVE_MEMORY_REVIEW.md` | `c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0` | Earlier complete 329-line reading reused at unchanged identity |
| `EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md` | `09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324` | Earlier complete 457-line reading reused; normalized torus, I0, physical-space premises |
| `EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md` | `b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876` | Earlier complete 549-line reading reused; physical kernel and effective compression |

I authored older long-time/degenerate material and participated in prior
composition. Those inherited premises are not independently recertified by
me here. The new edge/rate source and both author helpers were produced by
other workers. Root supplied the L^(5/3)/T^(-4/5) suggestion; I do not claim
independent discovery of that route. The complete new source was read before
reconstruction, including its evidence descriptions. The reconstruction and
different controls below were completed before opening author helper code,
receipt contents, or logs. This is independent checking of the new argument,
not a blind calculation or a claim that all historical premises are new.

## Load-bearing reconstruction

The pre-helper calculations are preserved in
`spectral_edge_review/PRE_HELPER_RECONSTRUCTION.md` (98 lines, SHA-256
`afba71d956943673b620e9d69e00dffa95b4c53c69743ceda7fb88bdc00cfe4d`).
They give the following checks.

**Compression and scalar coefficient.** On the odd triplet ambient space,
B is bounded Hermitian and preserves parity. Pythagoras gives
`b^2||z||^2-||Az||^2=<z,(b^2-B^2)z>+||(1-Pi)Bz||^2`
for z in Z, fixing the positive sign of the compression defect without
assuming Pi commutes with B. The pointwise cross square is valid for complex
fields because d is real. Scalar w preserves transverse/longitudinal
orthogonality. The three torus integrals of `sin^2(q_j)/epsilon^2` sum to one
and are equal by coordinate permutation. Hence
`C>=c|zeta><zeta|`, with exactly `c=b^2/(12I0)`.

This is not a gap. Odd transverse fields concentrated near q=r kappa/b and
its negative show `||A||=b`; the localization can avoid the cone itself.
All multipliers/compressions are bounded on the indicated spaces, so these
steps introduce no derivative domain. This remains valid on axis and diagonal
directions for b>0. The separate b=0 exception is necessary and supplied.

**Both-edge projection and inverse domain.** With z=P_delta zeta,
the lower form bound is c m_delta^2 and the upper form bound is
`(2b delta-delta^2)m_delta`. S8 therefore already counts both edges; adding
another factor two is wrong. The regulated vector `(C+eta)^(-1)zeta` gives
`c t_eta^2<=t_eta-eta||x_eta||^2<=t_eta`. Monotone spectral integration proves
S9, excludes endpoint mass, and places zeta in Dom C^(-1/2). It neither uses
a bounded inverse nor places zeta in Dom C^(-1). The stated domain claim is
exactly the one justified.

**Poisson proxy.** Evenness of the inherited dressing measure and the finite
inverse moment give
`integral (b-E)^(-1)dnu=b integral (b^2-E^2)^(-1)dnu`.
The scalar positive remainder in Section 5 then yields
`4delta[-Im M(b+i delta)]<=24I0 delta/b`. Its factor four is the stated
Poisson upper bound for two equal edge masses. It is not an identification
of that proxy with the actual mass in S8.

**Almost-everywhere density and integrability.** The inherited E20–E23
argument supplies absolute continuity, including exclusion of endpoint
atoms. Its coefficient gives exactly S13. Intersecting the full-measure sets
for rational delta and increasing delta to b-|E| makes S14 valid on one
full-measure set. The extra two-thirds density power is then controlled by
the envelope, while the remaining rho uses the inverse moment. This proves
`integral rho^(5/3)<=24I0(32768 pi I0)^(2/3)b^(-2/3)`.
The inverse moment cannot be replaced by cumulative linear edge mass alone.

**Convolution, one-sided time average, and scaling.** The three Holder
exponents are 5,5/2,5/2; after the fifth power and Tonelli integration the
result is U^3 V^3. Positive truncations justify the full L^(5/3) domain.
For the difference density h, exchanging the two energies cancels the
imaginary part of the one-sided time integral. This yields exactly sinc,
even without symmetry of the original probability law. Taking its absolute
majorant does not assume sinc is nonnegative. The whole-line kernel power
integral is 10/T, and the final coefficient is precisely

    D0=24^(6/5)(327680 pi)^(4/5)I0^2,
    Q(T)<=min{1,D0(bT)^(-4/5)},  b>0, T>0.

The powers of I0 add as 6/5+4/5, and b and T each carry exponent -4/5.
The conversion to the mean transverse occupation follows from unit norm.
The old S21 optimization is also valid on its stated Q0<1 domain: the
optimizer has terms in ratio 1:4/3, total 56I0 chi, square 3136I0^2 chi^2.
The universal threshold calculation gives the stated 297/448<1.

These arguments concern the scalar dressing spectral measure and its
effective evolution. They prove no uniform operator gap, pointwise Fourier
rate, monotonic loss, full-state dissipation, weighted-current convergence
rate, or growing-time original-walk comparison by themselves.

## Independent evidence and author-evidence inspection

`spectral_edge_review/independent_controls.py` is 86 lines, SHA-256
`7fe6580d565adf2d382e62ca3c5b8ba2e0667ae905f2d86223a78db934acb30e`.
Its first execution exited 0 in about 1.16 seconds with 20 exact symbolic
controls. The complete 26-line log is
`spectral_edge_review/independent_controls_attempt1.log`, SHA-256
`de98c048e0ea3ad369d75124270c20a73e78655feb75549d56d82e9f6a17c3a7`.
The command, timeout and executed source identity are in
`independent_execution_attempt1.json`, SHA-256
`c46eefa94078c2586071b5514da06d2d4cc7e9cb6683608517be34ce405cf5fc`.

The independent controls use a four-dimensional diagonal ambient operator
and a Hadamard compression, not the author's cubic orbit. They reconstruct
the nonzero defect and a sharp finite rank-one constant. A continuous model
C=x on L2(0,1), zeta=sqrt(2x), independently demonstrates a finite inverse
form although the full inverse cannot be applied to zeta. Uniform density
on [-b,b] gives a distinct exact one-sided sinc mean and Young comparison;
it also has linear edge mass and an infinite inverse-edge moment. These are
controls/counterexamples for intermediate reasoning, not torus samples or
new claims about the supplied model. Scalar kernel and homogeneity checks
naturally overlap in method with the author algebra; the finite fixture and
continuous comparators differ. The analytical proof remains essential.

I then read all 161 lines of `spectral_edge/edge_controls.py`
(`22bf0002efc0c7f188eaf789e86848f5e02051e37070a61231ed121a5c7999ee`)
and all 132 lines of `spectral_edge/rate_controls.py`
(`a3b6b61e17b0deaeced2e0d267e47b583cdbe219cd9d0004b89f184405f945a5`),
both complete harnesses, baseline execution records, both complete mutation
manifests, every full baseline/failure log, the preserved syntax-failure
source delta, both checkpoints, and the search/inventory records. Every
mutant was checked as the entire fully read base plus exactly one declared
substitution; every difference was read. Thus unchanged repeated source was
not inferred from a filename or a truncated log.

The finite cubic helper checks the stated 7-dimensional physical fixture,
nonzero compression defect, both-edge projector and direct finite inverse
moment. The rate helper checks a singular finite Gram form, the exact kernel,
and a parabolic continuous comparator. Its 50-digit quadrature comparisons
have no certified error enclosure; the note says so. The two successful
author logs report 20 and 15 controls. All eight literal mutant logs end at
their intended assertion. The earlier failed rate run is a missing closing
parenthesis; the exact repair adds that parenthesis and changes no assertion,
constant or tolerance. The harness change only chooses fresh attempt-2 paths.

No author runner or mutation was rerun in this review, and no historical log
was overwritten. Reading their outputs is evidence inspection, not independent
execution or proof. `verify_author_packet.py` mechanically checked 98 listed
identity occurrences covering 57 distinct paths/git blobs, without mismatch,
plus all eight whole-file literal substitutions and log endings. Its detailed
output is `author_identity_verification.json`, SHA-256
`ca6b135885f4a6309d5eb929aa714c6231e7e1b3fbc4005337fe4d3d7e098b88`.
The fully inspected diff file is `author_mutation_and_repair_diffs.txt`,
SHA-256 `c3fc5b024fc1b1109734ea1692eacb98c57de43c5448357e8afc74426b759d3c`.

## Publication precision and limits

The note's lines 446–450 state that weighted canonical-current asymptotics
and growing-time original-walk control “remain separate open questions.”
The receipt's `open_obligations` repeats that broad wording. The inherited
memory source E29 indeed gives only its ordered limit. However, the selected
weighted and joint-time claims are addressed separately by the unchanged
`EXCLUDED_WALK_WEIGHTED_MEMORY_PROBE.md`
(`10991ee05a61e3fcd2931b9cd90de007c2c2848771450db787e4634dcce3d324`)
and `EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md`
(`4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278`).
Their earlier complete readings are reused only to identify this scope issue.
Before publication, say these results are outside the edge note and cite the
selected W/G conclusions where appropriate, retaining genuinely unresolved
rate/uniform-preparation questions. Root acknowledged this wording issue.
The frozen probe and receipt were not edited.

The mathematical disposition above is limited to S4–S21 with the supplied
model, physical zero-space identification and frozen memory premises. No
new literature search, global novelty claim, Lean verification, independent
audit verdict, repo mutation or prompt-file edit was performed. The author
prior-art search is only the bounded search recorded in its packet. The
later original-walk averaged-occupation draft remains unread and outside
this review. Exact final identities and preservation checks are recorded in
`spectral_edge_review/receipt.json`.
