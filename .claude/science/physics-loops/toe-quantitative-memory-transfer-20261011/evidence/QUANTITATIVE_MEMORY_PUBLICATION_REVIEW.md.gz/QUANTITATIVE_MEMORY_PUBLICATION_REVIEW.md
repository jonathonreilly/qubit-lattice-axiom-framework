# Quantitative memory-transfer publication check

2026-10-11. Root read the complete 743-line combined theorem at
`284686962fe4cce3c59a93b89a9fc33776ffa2310dbc9c8e9c1e8bda809d049e`,
all new imported-premise text, the full wrapper and complete execution log.
The primary is `bf1a83f21e06818ba1182bfa186d13ccf971777afb52f70a09da0c69e0eaa85d`.
No consequential composition defect or mathematical repair was found.

Root authored A2-A9 and suggested the L^(5/3) route. This is therefore a
composition and claim-boundary check, not independent recertification of those
arguments. Their separate independent source checks are respectively
`e4f0f730b1d14d1d444e9e22eb0f6995fdc2dab4c130375491d6b61528d2d12a`
and `8a6741ea9ea890fb9fdece7a8c241fed537a1fe899dafe34f716f1211171bd40`.
Root read those complete reports, pre-helper reconstructions, distinct helpers,
successful outputs and actual control failures. All recorded file identities
were verified; prior authorship of older premises is disclosed in the reports.
The occupation reviewer authored S20 and kept that premise conditional. The
separate completed edge review supplies its independent coverage. This closes
the source-review dependency without modifying the historical report.

## Mathematical interfaces checked

The fixed physical space, normalized torus measure and auxiliary-singlet
exclusion match the parent. The positive compression defect in S5 is retained;
S7 only dominates the dressing rank-one form. The actual two-edge projection
uses its squared overlap, and the regulated inverse proves exactly the
inverse-square-root domain. No uniform gap or bounded full inverse is inferred.
The Poisson proxy and actual combined-edge mass remain distinct.

The inherited absolutely continuous density and countable rational-strip
exhaustion justify one almost-everywhere envelope. Combining that envelope
with the inverse moment gives L^(5/3), which the explicit Holder/Tonelli
argument maps to an L^5 difference density. The one-sided time integral gives
sinc with no positivity assumption; its absolute majorant has L^(5/4) power
integral 10/T. The stated coefficient, b scaling and T^(-4/5) time-mean bound
match these operations. The older logarithmic route is preserved with its
own domain, without an optimality claim.

The new premise restatements retain the band density, contact loss and
A_lambda normalization. Q16 is used at finite growing T with its actual
cutoff domain. Dividing by the small amplitude before squaring yields exactly
the probability-error coefficients 8 and 4. The actual ++ projector proof
retains antisymmetry, its original q support, the single physical projection
and the exact global momentum weights. Bounded Duhamel applies to F, which
is bounded; no unbounded dipole comparison is inserted. The explicit physical
time Jacobian cancels both delta factors. Gamma=5/18 balances only the two
displayed exponents, giving 2/9 at horizon lambda^(-59/18).

This concerns an order-lambda occupation in a specified fixed subspace. It
does not prove a weighted-current rate, generic preparation theorem,
irreversible evolution, physical collision clock or many-body closure. The
edge source's overbroad sentence calling all weighted/growing-time results
open is correctly narrowed in the composition, while its frozen bytes remain.

## Exact source and wrapper evidence

The reconstruction map is
`c29df627eeedeaa21f1ce04abdec65f04aa58d5e3ce0b5266342497a5c9d586f`.
The composition receipt is
`c1e09e3b251469b7c27d02d79e8a1221c99598850454f02e42ba287f8592269e`.
Root verified its 116 artifact records and 13 instruction records, every
section/source-slice hash, current dependency-note identity and literal helper.
Complete S1-S21 is recovered by reversing only section numbering and the
c_edge symbol. Complete A2-A9 is recovered after removing only the fully read
premise insertions and recorded notation/status clarifications. The three
payloads match earlier fully read sources exactly. No author replay was used
as independent mathematical evidence.

The root helper uses the actual main function with new synthetic programs.
It verifies distinct namespaces and the __main__/virtual-file contract, then
confirms that wrong hashes, wrong counts, assertions, runtime exceptions and
syntax errors propagate. All five expected failure messages were read. This
does not execute or recertify the mathematical helper payloads. The result is
`quantitative_memory_publication_review/root_composition_check.json`; its 159
assertions mainly concern identities, not 159 separate scientific checks.

Eleven actual complete-primary source copies also execute semantic defects:
five compression/edge/older-mean cases, three rate cases and three occupation
cases. Each replaces one helper expression and explicitly refreshes that
helper's expected hash, so it reaches the intended mathematical assertion.
Every copy exits 1 at that assertion. Root reconstructed each complete mutant,
verified source/log hashes, matched every successful prefix to the fully read
baseline after removing only elapsed time and changed hash metadata, and read
every distinct complete traceback. The old source failures are also preserved.

The completed historical baseline reports 49 author finite controls under a
180-second process timeout with empty stderr. Its floating continuous
comparators have no certified numerical enclosure. The continuum result rests
on the displayed proof and scoped mathematical checks. Final canonical cache,
metadata/footer updates and repository delivery checks are separate subsequent
steps; this report does not certify future files, Lean analysis, retained
status or a completed independent audit. No editable prompt was changed.
