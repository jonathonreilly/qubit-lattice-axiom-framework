"""Exact finite controls for A2-A9; these do not prove the continuum inputs."""
from fractions import Fraction as F
import sympy as s

checks=0
def check(name,condition):
    global checks
    assert bool(condition), name
    checks+=1
    print('EXACT',name)

l=s.symbols('lambda',positive=True)
g=s.symbols('gamma',real=True)
E,A=s.symbols('E A',nonnegative=True)
# Universal interval reductions used by the analytic A2-A3 proof.
check('Jacobian derivative bound at larger endpoint',F(9,4)*F(16,15)**5<4)
check('Jacobian upper bound below two',1+2*F(1,16)**2<2)
check('contact projection coefficient',F(49*2,128*9)<F(1,3))
check('band remainder rational margin',4-F(1,48)-2*F(1,16)**3>0)
# Collinear vectors attain the full squared-norm difference. Omitting the
# quadratic term or half the cross term violates this exact identity.
a=s.Matrix([A,0]);err=s.Matrix([A*E,0])
diff=((a+err).T*(a+err)-a.T*a)[0]
check('full amplitude-sensitive probability difference',s.expand(diff-A*A*(2*E+E*E))==0)
normalized_budget=8*E+4*E**2
check('normalized probability coefficients',s.expand(normalized_budget-4*(2*E+E**2))==0)
comparison_exponent=s.Rational(1,2)-g
survival_exponent=s.Rational(4,5)*g
balance=s.solve(comparison_exponent-survival_exponent,g)[0]
check('allowed balanced gamma',0<balance<s.Rational(1,2))
check('balanced gamma value',balance==s.Rational(5,18))
check('survival and comparison exponents',comparison_exponent.subs(g,balance)==survival_exponent.subs(g,balance)==s.Rational(2,9))
check('physical time clock',3+balance==s.Rational(59,18))
check('packet error faster than leading error',1-balance>comparison_exponent.subs(g,balance))
check('state preparation occupation at initial time',32**2==1024)
# Unequal contact factors must be retained in one global normalization.
weights=[F(1,6),F(1,3),F(1,2)];normsq=[F(9,10),F(4,5),F(7,10)]
N=sum(w*n for w,n in zip(weights,normsq));actual=[w*n for w,n in zip(weights,normsq)]
check('single normalization exact probability',sum(actual)==1 and actual!=weights)
values=[F(1,4),F(1,3),F(2,5)];center=F(1,3);bound=max(abs(x-center) for x in values)
check('uniform estimate survives exact weights',abs(sum(w*x for w,x in zip(actual,values))-center)<=bound)
print('Complete exact finite controls:',checks)
