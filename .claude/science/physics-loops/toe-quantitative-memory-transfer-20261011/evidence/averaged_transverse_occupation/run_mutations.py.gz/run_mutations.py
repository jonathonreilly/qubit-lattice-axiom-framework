from pathlib import Path
import hashlib,json,subprocess,time
D=Path(__file__).resolve().parent;P=D/'occupation_controls.py';original=P.read_text()
cases=[('probability_cross_half','normalized_budget=8*E+4*E**2','normalized_budget=4*E+4*E**2','normalized probability coefficients'),('clock_power','3+balance==s.Rational(59,18)','2+balance==s.Rational(59,18)','physical time clock'),('drop_global_normalization','actual=[w*n/N for w,n in zip(weights,normsq)]','actual=[w*n for w,n in zip(weights,normsq)]','single normalization exact probability')]
rows=[]
for name,before,after,expected in cases:
 assert original.count(before)==1
 p=D/('mutant_'+name+'.py');assert not p.exists();p.write_text(original.replace(before,after))
 t=time.monotonic();r=subprocess.run(['/opt/homebrew/opt/python@3.13/bin/python3.13',str(p)],capture_output=True,text=True,timeout=60)
 log=D/('mutant_'+name+'.log');log.write_text(r.stdout+r.stderr)
 row={'name':name,'old':before,'new':after,'intended_assertion':expected,'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-t,'timeout_seconds':60,'intended_failure':r.returncode==1 and expected in r.stderr}
 rows.append(row);(D/'mutation_manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,row['intended_failure']);print(r.stderr);assert row['intended_failure']
assert P.read_text()==original
S=D.parent
sources=['EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md','EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md','EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md','EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md','EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md']
files=[S/x for x in sources]+[p for p in sorted(D.iterdir()) if p.is_file() and p.name!='receipt.json']
receipt={'scope':'Root original-walk averaged transverse-occupation composition; author evidence, not independent review. Spectral-edge independent review remains an open dependency.','records':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],'coverage':'Complete new A2-A9 argument and finite helper read. Exact earlier L/B/G premises reused, relevant full passages refreshed. New S4-S20 source read completely after authoring this conditional implication. Baseline and all three complete failure tracebacks read. All source replacements are literal and unique.','obligations':['Separate independent check of S20','Separate independent check of new A2-A9 composition'],'publication_status':'External research only; not in the active current/memory milestone','editable_prompt_files_changed':[]}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('NOTE',hashlib.sha256((S/sources[0]).read_bytes()).hexdigest());print('RECEIPT',hashlib.sha256((D/'receipt.json').read_bytes()).hexdigest())
