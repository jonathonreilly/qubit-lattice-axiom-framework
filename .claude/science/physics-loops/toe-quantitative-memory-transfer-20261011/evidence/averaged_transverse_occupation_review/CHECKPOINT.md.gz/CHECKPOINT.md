# Averaged transverse occupation composition review checkpoint

2026-10-11. This bounded assignment is complete. The frozen review and
receipt are the handoff; no repository edit or audit action was performed.

## Exact target and result

Target: `../EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md`, SHA-256
`9729bbbfb26de3c7cf450b8eb81efea6fe2f3597b40289426cf6e9171de30c3d`.
The full 192-line argument was read. No consequential defect was found in
A2–A9 conditional on A1 and the stated supplied-model premises. No source
correction is requested. The composition supports the fixed F projection
mean `O_lambda=1/(8pi^2 I0)+O(lambda^(2/9))` at model physical horizon
`H_lambda=lambda^(-59/18)` for the constructed actual nonzero-K packet.

The complete review is
`../EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_REVIEW.md`.
`receipt.json` binds its final bytes and all inputs/evidence; the separate
`receipt_verification.json` checks that manifest without a circular hash.

## Independence and coverage

The reviewer authored the S20/A1 spectral-edge premise, source SHA-256
`e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623`.
It is not independently recertified here. Its separate independent review
was pending at dispatch. This assignment checks the new A2–A9 composition.

`PRE_CONTROL_RECONSTRUCTION.md` was frozen before author-control contents
were read, as recorded by `pre_control_receipt.json`. It reconstructs the
finite band remainder, Q16 on growing intervals, amplitude-sensitive
probability estimate, actual free preparation, exact global weights,
physical-time Jacobian and 5/18 balance. The complete quantitative,
two-scale and joint-scale notes were read; prior complete long-time,
degenerate and effective-memory readings were reused at unchanged hashes.

The author helper, 14-control baseline and execution metadata were then
read. The subsequently supplied author receipt, SHA-256
`b2cccd048ee59f6cc4581284eec16e9a82b0787fe2a8598fcaf813e88f71dd24`,
has 16 matching file identities. Its mutation harness, three complete
failure logs and literal source differences were also inspected. No
author evidence was replayed or modified.

## Decisive independent fixture and preserved failures

`independent_packet_controls.py` constructs an actual nine-dimensional
projected packet and unitary dynamics, then compares direct norm-squared
integration with the exact normalized fiber expression and physical-time
change. Nine exact controls passed on the first run. This is a finite
comparator of the normalization and probability algebra, not a torus
simulation, Q16 test, S20 review or free-band realization.

Two actual single-replacement copies fail at their intended assertions:
bare envelope weights change the direct mean by `32/(335pi)`, and a
missing time Jacobian gives the wrong physical mean. Both full failure
logs, source files and literal replacement metadata remain preserved.
There was no unintended failure in this independent fixture run.

## Remaining dependency and scope

Independent coverage of S20 belongs to the separately assigned reviewer.
This handoff neither changes that status nor applies an audit verdict.
No pointwise survival estimate, weighted-current rate, generic-state
theorem, empirical clock calibration or many-body law is claimed. No
physical primitive was adopted. All prior sources, edge evidence and
failures remain intact. No editable prompt file changed.

The next decision belongs to the parent: combine this exact-source A2–A9
review with the separately frozen S20 review if its scope supports that
composition. Refresh only affected evidence if any input changes.
