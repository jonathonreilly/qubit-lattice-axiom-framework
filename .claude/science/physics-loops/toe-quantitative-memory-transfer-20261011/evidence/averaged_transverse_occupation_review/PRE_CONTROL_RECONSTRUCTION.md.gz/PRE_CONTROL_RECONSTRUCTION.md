# Reconstruction before reading the averaged-occupation author controls

2026-10-11. Independent check of the composition A2–A9. The draft was read
at SHA-256 `9729bbbfb26de3c7cf450b8eb81efea6fe2f3597b40289426cf6e9171de30c3d`
(192 lines). No file in the author's `averaged_transverse_occupation/`
control directory has yet been opened. The predicted exponent was already
in the dispatch and draft; independence here is mathematical reconstruction
and separately designed evidence, not blindness to the proposed answer.

I authored the edge note supplying S20/A1. Its exact bytes
`e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623` are used
only as an explicit provisional premise; this review does not independently
recertify it. The new object checked here is the composition to the actual
projected free-band packet and the fixed transverse projection F.

The complete two-scale (327 lines), quantitative (420 lines), and joint-scale
(236 lines) source arguments have now been read. The unchanged long-time
note (457 lines), degenerate note (549 lines), and memory note (500 lines)
were read completely during the preceding bounded task and are reused only
at their already checked byte identities. The new calculation needs no
Kato/weighted-current theorem from the joint-scale source.

## Band probability and its finite error

The contact density bounds are
`E^2/(4pi^2)<=rho(0,E)<=E^2(1-E^2/4)^(-3/2)/(4pi^2)` on the chosen
interval `I=[5lambda/4,7lambda/4]`. Its length is lambda/2. Hence

    c_A lambda <= w_lambda <=c_A lambda F_lambda,
    c_A=1/(8pi^2 I0),
    F_lambda=(1-49lambda^2/64)^(-3/2).

Since phi_lambda is normalized and lies in ran Gamma_lambda,
`|<c,phi_lambda>|^2<=||Gamma_lambda c||^2=integral_I rho(0,E)dE`.
Bounding E^2 by `(7lambda/4)^2` yields the coefficient
`49lambda^3 F_lambda/(128pi^2)` in A2.

For `0<=x<=1/16`, `(3/2)(1-x)^(-5/2)<2`. Since
`49lambda^2/64<=lambda^2<=1/256`, the mean value theorem gives
`F_lambda<=1+2lambda^2<2`. Thus the beta bound is below lambda^3/3
already using pi^2>9. All denominators are positive. With
`A_lambda^2=w_lambda/(1-beta_lambda^2)` and c_A<=1/6,

    0<=A_lambda^2/lambda-c_A
      <= (lambda^2/6)(2+lambda/3)/(1-lambda^3/3)
      <=lambda^2.

The last inequality is equivalent to
`2+lambda/3<=6(1-lambda^3/3)`, immediate on `(0,1/16]`.
This independently reconstructs A2–A3 from the density and Cauchy-Schwarz.

## Finite Q16 at a growing horizon

The quantitative source Q16, before its fixed-time specialization, is

    e_perp <=delta[A(2b+2Tb^2)+(2b+Tb^2)]/sigma
          +A[4+(7/2)b^2T^2]sqrt(sigma)/sqrt(I0)
          +2sigma C_lambda+(A+1)T r_delta.

Its cutoff hypotheses include `sigma<=min(1/2,5lambda/8)`; they hold
for sigma=lambda^2 and lambda<=1/16. Here A=A_lambda>0, b=sqrt(3),
delta=lambda^3<=1, T=lambda^(-gamma)>=1, `0<gamma<1/2`. The sources give
`1/A<=12/sqrt(lambda)`, `C_lambda<=4/lambda`, `1/sqrt(I0)<4`, and
`r_delta=(3/4)delta+(sqrt(3)/8)delta^2<=delta`.

Divide the four Q16 terms by A separately. Their bounds are

    108delta T/(sigma sqrt(lambda)),
    58T^2 sqrt(sigma),
    96sigma/lambda^(3/2),
    13T delta/sqrt(lambda).

For the first term, relax b<2 and b^2<4 to obtain
`(4+8T)+(4+4T)/A<=108T/sqrt(lambda)`. For the second use the exact
b^2=3 and `16+42T^2<=58T^2`. The other two coefficients follow directly
from the preceding finite bounds.

Writing p=1/2-gamma, substitution gives respectively powers
`lambda^p,lambda^(2p),lambda^(1/2),lambda^(2+p)`. All exponents are
at least p, so `e_perp/A<=275lambda^p=:E_lambda`. This is a finite
inequality for every specified lambda and horizon, not an exchange of
two asymptotic limits.

## Squared norm and conditional effective mean

Let x=F psi_c(tau), y=A u(tau). Then
`||x-y||<=A E_lambda` and `||y||<=A`. Therefore

    abs(||x||^2-A^2||u||^2)
      <=||x-y||(2||y||+||x-y||)
      <=A^2(2E_lambda+E_lambda^2).

Because A^2/lambda<=4, dividing and averaging gives precisely
`8E_lambda+4E_lambda^2`. Keeping A in both factors is essential.
The effective unitary identity `||u||^2=1-|a|^2`, the finite band error
above, and the assumed A1 estimate give A5 by a triangle inequality:
the remaining terms are at most lambda^2 and four times A1's mean bound.

## Actual nonzero-K packet, exact weights, and physical time

For kappa in the radius-lambda^2 ball about kappa0=(1,1,1),
`|kappa|<2`, `|K|=lambda^3|kappa|<=lambda/16`, and K stays away
from zero. The exact ++ projector construction is therefore valid,
preserves the q support, and keeps the free energies in [lambda,2lambda].
The source B19 gives
`||chi_(lambda,K)-chi_lambda||<=16|K|/lambda<=32lambda^2`.

The divided generators differ by at most |kappa-kappa0|, since the
undivided Hamiltonians are Lipschitz with constant one in K. Duhamel
therefore adds at most `|tau|lambda^2`. This proves A6 on the entire
growing interval. Applying F expectations of normalized vectors costs
at most twice their norm difference. After division by lambda and
averaging, the author's endpoint bound is `64lambda+2lambda^(1-gamma)`.
(Integrating the linear time error would improve the last coefficient
to one, but the displayed factor two is valid.)

In the actual full direct integral, change K=delta kappa. If
`N^2=||P Phi_lambda||^2`, then

    N^2=integral |f_lambda(kappa)|^2 n_(lambda,delta kappa)^2 dkappa/(2pi)^3.

The evolved normalized packet has fiber amplitude
`delta^(-3/2) f_lambda n_(lambda,delta kappa)/N` times the unit fiber
state `U_(delta,kappa)(tau)chi_(lambda,delta kappa)`. Thus its exact
F expectation is the integral of fiber expectations with weights
`|f_lambda|^2 n_(lambda,delta kappa)^2/N^2`. They integrate to one and
can carry the uniform bound above without replacing them by bare
envelope weights. The Jacobians in both envelope rescalings have power
three and are cancelled by the squared amplitude factors.

Set H=T/delta and tau=delta t. Then

    (1/(lambda H))integral_0^H q(delta t)dt
      =(1/(lambda T))integral_0^T q(tau)dtau.

The factors delta and 1/delta cancel exactly. Combining the preceding
uniform errors gives A7, with no need for current identities or weighted
observables.

## Balance and initial population

The leading comparison power is p=1/2-gamma. The assumed A1 term has
power 4gamma/5; its b=sqrt(3) coefficient is fixed. All other A7 powers
are strictly higher than p for gamma in (0,1/2). Thus the error has
power `min(1/2-gamma,4gamma/5)`. The decreasing and increasing linear
functions intersect at gamma=5/18, giving power 2/9 and physical
horizon exponent 3+gamma=59/18. This optimizes only those two displayed
powers at delta=lambda^3 and sigma=lambda^2.

At time zero, F chi_lambda=0, so the nonzero-K preparation estimate
gives `||F chi_(lambda,K)||<=32lambda^2`. Exact global weights yield
initial probability at most 1024lambda^4 and hence scaled initial
occupation at most 1024lambda^3. Its subtraction preserves A9.

No consequential defect is exposed by this reconstruction. The result is
conditional on A1 and on the stated supplied model/preparation. The present
review does not independently examine A1, infer a canonical-current rate,
claim generic-state transfer, or interpret F as a many-body collision law.

## Independent fixture planned before author-control inspection

Use a small direct sum with unequal contact losses and different bounded
unitary evolutions. Compute its globally projected-and-normalized state
directly, then compare its F probability and time mean with the exact
weighted fiber formula. The bare-envelope-weight substitution must fail.
An exact physical two-level state will also saturate the amplitude-sensitive
squared-norm bound and reject deletion of its linear cross term. This
tests the decisive normalization/algebra rather than a continuum limit.
