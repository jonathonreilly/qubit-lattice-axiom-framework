"""Independent exact matrix controls for the occupation composition.

Three finite fibers with contact projection, unequal actual norm losses,
and different bounded unitary evolutions. This is an algebraic comparator,
not a finite approximation to the continuum walk or evidence for S20.
"""
import json
import platform
import time

import sympy as sp


began = time.monotonic()
checks = 0
t = sp.symbols("t", real=True)
P = sp.diag(0,1,1)
F = sp.diag(0,0,1)
phis = [sp.Matrix([sp.Rational(1,2),sp.sqrt(3)/2,0]),
        sp.Matrix([1/sp.sqrt(2),sp.Rational(1,2),sp.I/2]),
        sp.Matrix([sp.Rational(1,3),sp.Rational(2,3),sp.Rational(2,3)])]
envelope_weights = [sp.Rational(1,5),sp.Rational(3,10),sp.Rational(1,2)]
Hs = [sp.Matrix([[0,0,0],[0,0,1],[0,1,0]]),
      sp.diag(0,1,-1),
      sp.Matrix([[0,0,0],[0,0,-2*sp.I],[0,2*sp.I,0]])]


def simplify(expr):
    return sp.simplify(sp.expand_complex(expr))


def zero(expr):
    if isinstance(expr,sp.MatrixBase):
        return all(simplify(x)==0 for x in expr)
    return simplify(expr)==0


def check(name,condition,detail=None):
    global checks
    assert bool(condition), name
    checks += 1
    print(json.dumps({"check":name,"detail":detail},sort_keys=True))


check("literal_normalized_free_fibers_and_envelope",
      all(zero((v.H*v)[0]-1) for v in phis) and sum(envelope_weights)==1)
check("physical_selfadjoint_generators",
      all(H==H.H and H==P*H*P for H in Hs))
Us = [(-sp.I*t*H).exp() for H in Hs]
check("actual_matrix_exponentials_solve_evolution",
      all(zero(sp.I*U.diff(t)-H*U) and zero(U.subs(t,0)-sp.eye(3))
          for H,U in zip(Hs,Us)))

# Build the global vector before computing the fiber normalization weights.
free_global = sp.Matrix.vstack(*[sp.sqrt(w)*v for w,v in zip(envelope_weights,phis)])
P_global, F_global, U_global = sp.diag(P,P,P), sp.diag(F,F,F), sp.diag(*Us)
projected_global = P_global*free_global
N2 = simplify((projected_global.H*projected_global)[0])
chi_global = projected_global/sp.sqrt(N2)
evolved_global = U_global*chi_global
direct_probability = simplify((evolved_global.H*F_global*evolved_global)[0])
check("one_global_contact_projection_is_normalized",
      zero((free_global.H*free_global)[0]-1)
      and zero((chi_global.H*chi_global)[0]-1),{"N_squared":str(N2)})

norm_losses = [simplify((v.H*P*v)[0]) for v in phis]
chis = [P*v/sp.sqrt(n2) for v,n2 in zip(phis,norm_losses)]
actual_weights = [simplify(w*n2/N2) for w,n2 in zip(envelope_weights,norm_losses)]
fiber_probabilities = [simplify(((U*v).H*F*(U*v))[0]) for U,v in zip(Us,chis)]
weights_used = actual_weights
weighted_probability = sum(w*q for w,q in zip(weights_used,fiber_probabilities))
check("direct_global_vector_matches_exact_normalization_weights",
      zero(direct_probability-weighted_probability),
      {"norm_losses":list(map(str,norm_losses)),"actual_weights":list(map(str,actual_weights)),
       "fiber_probabilities":list(map(str,fiber_probabilities))})

T = sp.pi/4
direct_mean = simplify(sp.integrate(direct_probability,(t,0,T))/T)
weighted_mean = simplify(sum(w*sp.integrate(q,(t,0,T))/T
                             for w,q in zip(actual_weights,fiber_probabilities)))
bare_mean = simplify(sum(w*sp.integrate(q,(t,0,T))/T
                         for w,q in zip(envelope_weights,fiber_probabilities)))
check("exact_global_time_mean_and_wrong_bare_weights",
      zero(direct_mean-weighted_mean) and not zero(direct_mean-bare_mean),
      {"direct_mean":str(direct_mean),"wrong_bare_mean":str(bare_mean),
       "difference":str(simplify(direct_mean-bare_mean))})

# Integrate the physical-time state with the actual rescaled generators.
# The upper limit and dt Jacobian are therefore supplied by the same
# literal evolution, rather than by assigning an expected exponent.
lam = sp.Rational(1,20)
delta = lam**3
Horizon = T/delta
physical_probability = direct_probability.subs(t,delta*t)
physical_scaled_mean = simplify(sp.integrate(physical_probability,(t,0,Horizon))/(lam*Horizon))
effective_scaled_mean = direct_mean/lam
jacobian_used = delta
check("physical_time_integral_has_exact_jacobian_cancellation",
      zero(physical_scaled_mean-jacobian_used*effective_scaled_mean),
      {"delta":str(delta),"physical_horizon":str(Horizon),
       "scaled_mean":str(physical_scaled_mean)})
check("omitted_dt_factor_would_change_probability_mean",
      not zero(physical_scaled_mean-delta*effective_scaled_mean))

# An actual unit vector realizes equality in the small-amplitude norm
# error with F a projection; deleting the linear cross term is detected.
amp, rel = sp.Rational(1,8), sp.Rational(1,4)
target = sp.Matrix([0,0,amp])
perturbed_length = amp*(1+rel)
physical_state = sp.Matrix([0,sp.sqrt(1-perturbed_length**2),perturbed_length])
projected = F*physical_state
actual_squared_difference = simplify((projected.H*projected-target.H*target)[0])
check("unit_state_realizes_amplitude_sensitive_probability_error",
      zero((physical_state.H*physical_state)[0]-1)
      and zero(((projected-target).H*(projected-target))[0]-(amp*rel)**2)
      and actual_squared_difference==amp**2*(2*rel+rel**2)
      and actual_squared_difference>amp**2*rel**2,
      {"actual_difference":str(actual_squared_difference),
       "wrong_quadratic_only":str(amp**2*rel**2)})

print(json.dumps({"checks":checks,"elapsed_seconds":time.monotonic()-began,
                  "python":platform.python_version(),"sympy":sp.__version__,
                  "scope":"Exact independent finite projected-state and unitary comparator; no continuum, free-band, Q16, or S20 certification."},sort_keys=True))
