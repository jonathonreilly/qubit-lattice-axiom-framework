"""Run independent controls and preserve literal discriminating defects."""
from pathlib import Path
import hashlib
import json
import subprocess
import time


D = Path(__file__).resolve().parent
PY = "/opt/homebrew/opt/python@3.13/bin/python3.13"
source = (D/"independent_packet_controls.py").read_text()


def execute(path,log):
    assert not log.exists()
    began = time.monotonic()
    with log.open("w") as out:
        try:
            p = subprocess.run([PY,str(path)],stdout=out,stderr=subprocess.STDOUT,timeout=120)
            code = p.returncode
        except subprocess.TimeoutExpired:
            code = 124
    return {"command":[PY,str(path)],"returncode":code,"timeout_seconds":120,
            "elapsed_seconds":time.monotonic()-began,
            "source":path.name,"source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
            "log":log.name,"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()}


baseline = execute(D/"independent_packet_controls.py",D/"baseline.log")
(D/"baseline_execution.json").write_text(json.dumps(baseline,indent=2)+"\n")
print(json.dumps(baseline))
assert baseline["returncode"] == 0
records = []
for name,old,new,assertion in [
    ("bare_envelope_weights","weights_used = actual_weights","weights_used = envelope_weights",
     "direct_global_vector_matches_exact_normalization_weights"),
    ("missing_time_jacobian","jacobian_used = sp.Integer(1)","jacobian_used = delta",
     "physical_time_integral_has_exact_jacobian_cancellation")]:
    assert source.count(old)==1
    path = D/("mutant_"+name+".py")
    assert not path.exists()
    path.write_text(source.replace(old,new))
    r = execute(path,D/("mutant_"+name+".log"))
    r.update({"name":name,"old":old,"new":new,"intended_assertion":assertion,
              "failed_at_intended_assertion":r["returncode"]==1 and
                  "AssertionError: "+assertion in (D/r["log"]).read_text()})
    records.append(r);print(json.dumps(r))
(D/"mutation_manifest.json").write_text(json.dumps(records,indent=2)+"\n")
assert all(r['failed_at_intended_assertion'] for r in records)
