from pathlib import Path
import ast
import contextlib
import hashlib
import io
import json
import re
import runpy
import subprocess
import time

S = Path(__file__).resolve().parent
D = S/'quantitative_memory_publication_review'
D.mkdir(exist_ok=True)
M = json.loads((S/'quantitative_memory_transfer_composition/reconstruction_map.json').read_text())
rows = []
sha = lambda data: hashlib.sha256(data).hexdigest()
def require(name, test):
    assert test, name
    rows.append(name)

receipt_path = S/'quantitative_memory_transfer_composition/receipt.json'
receipt = json.loads(receipt_path.read_text())
for r in receipt['records']:
    require('receipt:'+r['path'], sha(Path(r['path']).read_bytes()) == r['sha256'])
for r in receipt['instructions']:
    source = r['source']
    data = Path(source).read_bytes() if source.startswith('/') else subprocess.check_output(
        ['git','show',source],cwd=S.parent/'walk_worktree')
    require('instruction:'+source,sha(data)==r['sha256'])
note = Path(M['note']['path']).read_text()
primary_path = Path(M['primary']['path'])
primary = primary_path.read_text()
require('note identity',sha(note.encode())=='284686962fe4cce3c59a93b89a9fc33776ffa2310dbc9c8e9c1e8bda809d049e')
require('primary identity',sha(primary.encode())=='bf1a83f21e06818ba1182bfa186d13ccf971777afb52f70a09da0c69e0eaa85d')
for name,digest in M['input_identities'].items():
    require('input:'+name,sha((S/name).read_bytes())==digest)
for r in M['dependency_notes']:
    require('dependency:'+r['path'],sha(Path(r['path']).read_bytes())==r['sha256'])
lines = note.splitlines(keepends=True)
for r in M['sections']:
    a,b = r['output_lines']
    require('final section:'+r['label'],sha(''.join(lines[a-1:b]).encode())==r['output_sha256'])
    for origin in r['origins']:
        if isinstance(origin,dict):
            a,b=origin['lines'];original=(S/origin['path']).read_text().splitlines(keepends=True)
            require('source slice:'+origin['path'],sha(''.join(original[a-1:b]).encode())==origin['extracted_sha256'])

# Independently form the expected unchanged effective proof, using only its
# documented section-number and scalar-symbol presentation changes.
original=(S/'EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md').read_text()
original=original[original.index('Work in the Hilbert space'):original.index('## 9. Evidence')].rstrip()
expected=re.sub(r'\bc\b','c_edge',original)
expected=re.sub(r'^## ([2-8])\.',lambda m:'## '+str(int(m[1])+1)+'.',expected,flags=re.M)
actual=note[note.index('Work in the Hilbert space'):note.index('## 10. Imported band')].rstrip()
require('complete effective proof exact transformed source',expected==actual)

# The complete new 743-line note has been read by root, including all premise
# insertions and A2-A9 interfaces. Recover the old occupation proof after
# reversing the explicit insertions, so unchanged text is checked as bytes.
original=(S/'EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md').read_text()
original=original[original.index('## 2. A finite band-weight remainder'):original.index('## 5. Review obligations')].rstrip()
actual=note[note.index('## 11. A finite band-weight remainder'):note.index('## 14. Evidence')].rstrip()
actual=re.sub(r'^## (11|12|13)\.',lambda m:'## '+str(int(m[1])-9)+'.',actual,flags=re.M)
actual=actual.replace('In particular, using A1=S20,','In particular, under the pending A1 premise,')
actual=actual.replace('has center lambda^3 kappa0 and radius lambda^5. The free packet is in the\nactual positive free [lambda,2lambda] band before contact projection.',
                      'has center lambda^3 kappa0 and radius lambda^5; it is contained in the\nactual positive free [lambda,2lambda] band before contact projection.')
for left,right,replacement in [
    ('The inherited all-T Q16 gives','Write psi_c(tau)',''),
    ('For |K|<=lambda/16 use the actual positive projector','Use exactly the actual free-band family G8:',''),
    ('The substitution tau=delta t has dt=','Equations A5-A6 yield',
     'The substitution tau=delta t exactly gives the previous time average.\n')]:
    a=actual.index(left);b=actual.index(right,a);actual=actual[:a]+replacement+actual[b:]
actual=actual.replace('smooth h supported in the unit ball and nonzero on an open set, with\nintegral |h(y)|^2dy/(2pi)^3=1.',
                      'smooth normalized h supported in the unit ball and nonzero on an open set.')
require('complete occupation proof recovered',actual==original)

tree=ast.parse(primary)
assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)
             and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
for r in M['helper_payloads']:
    payload=ast.literal_eval(assignments[r['variable']]).encode()
    require('literal full helper:'+r['variable'],payload==Path(r['source']).read_bytes() and sha(payload)==r['sha256'])

# Exercise the actual wrapper with new small programs, never the author's
# finite mathematical helpers. Their distinct namespaces and __main__ contract
# are observable, and each failure must propagate out of main().
ns=runpy.run_path(str(primary_path))
main=ns['main'];g=main.__globals__
one="assert __name__ == '__main__'\nassert __file__.startswith('<frozen-author:')\nsentinel=17\nchecks=2\n"
two="assert 'sentinel' not in globals()\nchecks=3\n"
def block(name,source,count):return (name,sha(source.encode()),count,source)
g['AUTHOR_BLOCKS']=[block('root-one',one,2),block('root-two',two,3)]
output=io.StringIO()
with contextlib.redirect_stdout(output):main()
last=json.loads(output.getvalue().splitlines()[-1])
require('actual wrapper isolated source execution',last['author_checks']==5 and last['isolated_author_blocks']==2)
failures=[]
cases=[('hash',('bad-hash','0'*64,1,'checks=1\n'),AssertionError),
       ('count',block('bad-count','checks=1\n',2),AssertionError),
       ('assertion',block('assertion','assert False, "root deliberate assertion"\n',1),AssertionError),
       ('runtime',block('runtime','raise RuntimeError("root deliberate runtime")\n',1),RuntimeError),
       ('syntax',block('syntax','for bad syntax\n',1),SyntaxError)]
for label,row,expected_error in cases:
    g['AUTHOR_BLOCKS']=[row]
    output=io.StringIO()
    try:
        with contextlib.redirect_stdout(output):main()
    except expected_error as exc:
        failures.append({'case':label,'exception':type(exc).__name__,'message':str(exc),'stdout':output.getvalue()})
    else:raise AssertionError('wrapper swallowed '+label)

result={'scope':'Root composition/claim-boundary and actual-wrapper check. Root authored A2-A9 and suggested the Lp route; this does not independently recertify them.',
        'note_sha256':sha(note.encode()),'primary_sha256':sha(primary.encode()),
        'receipt_sha256':sha(receipt_path.read_bytes()),'complete_final_note_lines_read':743,
        'checks':rows,'wrapper_failure_controls':failures,'math_repairs_requested':[]}
out=D/'root_composition_check.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'mechanical_assertions':len(rows),'expected_wrapper_failures':failures,'finding':'No composition defect; source independence remains scoped.'},indent=2))
