# Exact quantitative memory-transfer reconstruction map

Claim: `excluded_walk_quantitative_memory_transfer_bounded_theorem_note_2026-10-11`. Future note: `docs/EXCLUDED_WALK_QUANTITATIVE_MEMORY_TRANSFER_BOUNDED_THEOREM_NOTE_2026-10-11.md`.

The machine map binds every generated segment by its final line span and exact text hash.
`compose_candidate.py` gives the full literal source slicing and deterministic replacements.
No mathematical constant, domain or claimed estimate is strengthened.

| Segment | Final note lines | Reconstruction |
| --- | --- | --- |
| metadata, result and dependency contract | 1–112 | new editorial wrapper; no additional mathematical assertion |
| S1-S21 complete effective proof | 113–417 | section numbers incremented; scalar c renamed c_edge; mathematical text otherwise unchanged |
| band and normalization premises | 418–454 | explicit restatement of imported definitions and bounds; A1 identified with proved S20 |
| A2-A9 complete original-walk composition | 455–652 | section numbers; pending A1 phrase resolved to S20; full imported Q16/G5 and actual projector proof inserted; exact h normalization and time Jacobian displayed; no constants or claims strengthened |
| evidence, resolved source reviews and scoped limits | 653–733 | obsolete pending-source-review prose replaced by exact completed review scopes; globally-open wording narrowed; final composition review remains pending |

The full S1–S21 proof slice is preserved apart from section numbering and
the scalar `c` → `c_edge` rename that avoids the contact-singlet collision.
A2–A9 retain the original proof with the full Q16/G5 specialization, actual
projector construction and exact time Jacobian made explicit from checked sources.
A1 is the proved S20. All source source-review limitations remain explicit.

The old edge terminal wording is superseded only in this new composition: selected
weighted/current and growing-time results are outside this theorem, not globally open.
The frozen source notes and their receipts are not edited.

| Embedded helper | Exact SHA-256 | Controls |
| --- | --- | --- |
| `spectral_edge/edge_controls.py` | `22bf0002efc0c7f188eaf789e86848f5e02051e37070a61231ed121a5c7999ee` | 20 |
| `spectral_edge/rate_controls.py` | `a3b6b61e17b0deaeced2e0d267e47b583cdbe219cd9d0004b89f184405f945a5` | 15 |
| `averaged_transverse_occupation/occupation_controls.py` | `a81f727a4d2f813e6c58515127fa9836179e24180f90c50224d42bc7368237a1` | 14 |

Payloads are decoded and compared byte-for-byte with their complete source files before freezing.
The primary checks the same hashes again and runs each helper in a fresh namespace.
The combined run is author consistency replay only. The reconstruction and metadata
of this new publication candidate still require final source-bound review.
