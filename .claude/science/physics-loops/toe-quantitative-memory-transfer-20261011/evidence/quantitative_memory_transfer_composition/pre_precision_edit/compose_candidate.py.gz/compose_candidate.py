"""Deterministic external composition of frozen proofs and literal helpers.

No scientific calculation is introduced by this packaging program. It refuses
to overwrite the note, primary, or reconstruction map.
"""
from pathlib import Path
import hashlib
import json
import re

D = Path(__file__).resolve().parent
S = D.parent
W = S.parent / "walk_worktree"
NOTE = S / "FINAL_EXCLUDED_WALK_QUANTITATIVE_MEMORY_TRANSFER_NOTE.md"
PRIMARY = S / "excluded_walk_quantitative_memory_transfer_2026_10_11.py"
CLAIM = "excluded_walk_quantitative_memory_transfer_bounded_theorem_note_2026-10-11"
FUTURE_NOTE = "docs/EXCLUDED_WALK_QUANTITATIVE_MEMORY_TRANSFER_BOUNDED_THEOREM_NOTE_2026-10-11.md"
INPUTS = {
    "EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md": "e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623",
    "EXCLUDED_WALK_SPECTRAL_EDGE_REVIEW.md": "8a6741ea9ea890fb9fdece7a8c241fed537a1fe899dafe34f716f1211171bd40",
    "EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md": "9729bbbfb26de3c7cf450b8eb81efea6fe2f3597b40289426cf6e9171de30c3d",
    "EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_REVIEW.md": "e4f0f730b1d14d1d444e9e22eb0f6995fdc2dab4c130375491d6b61528d2d12a",
    "EXCLUDED_WALK_QUANTITATIVE_BAND_CURRENT_PROBE.md": "ab8de5c1d0d90a3c15ca9cf47133a856947714f6aee5fd5127fc9dcb82263400",
    "EXCLUDED_WALK_JOINT_SCALE_CURRENT_DRAFT.md": "4d6c82f7c46e0ae1a34f8c0c4ebdab90361ab6f3753a5bf95e89e7d40694c278",
    "FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md": "ecb7eacddc0a11b2636030ed5e4759fabb9945568f3f3f4699f650463f5bf969",
    "EXCLUDED_WALK_LONG_TIME_BAND_PROBE.md": "09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324",
    "EXCLUDED_WALK_DEGENERATE_DYNAMICS_PROBE.md": "b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876",
    "EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md": "b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c",
    "EXCLUDED_WALK_TWO_SCALE_FREE_BAND_CURRENT_DRAFT.md": "0f88cc71227a51e4f03069d985b535685735cd6f0b7fc80ca6cb6ad46c059c3c",
}
HELPERS = [
    ("EDGE_CONTROLS_SOURCE", "spectral_edge/edge_controls.py", "22bf0002efc0c7f188eaf789e86848f5e02051e37070a61231ed121a5c7999ee", 20),
    ("RATE_CONTROLS_SOURCE", "spectral_edge/rate_controls.py", "a3b6b61e17b0deaeced2e0d267e47b583cdbe219cd9d0004b89f184405f945a5", 15),
    ("OCCUPATION_CONTROLS_SOURCE", "averaged_transverse_occupation/occupation_controls.py", "a81f727a4d2f813e6c58515127fa9836179e24180f90c50224d42bc7368237a1", 14),
]
sha = lambda data: hashlib.sha256(data).hexdigest()
for name, expected in INPUTS.items():
    assert sha((S / name).read_bytes()) == expected, name
for _, name, expected, _ in HELPERS:
    assert sha((S / name).read_bytes()) == expected, name
texts = {name: (S / name).read_text() for name in INPUTS}
parts = []
mapping = []


def add(label, text, origins, changes):
    text = text.rstrip() + "\n\n"
    first = 1 + sum(x.count("\n") for x in parts)
    parts.append(text)
    mapping.append({"label": label, "output_lines": [first, first + text.count("\n") - 1],
                    "output_sha256": sha(text.encode()), "origins": origins, "changes": changes})


def source(name, begin, end):
    text = texts[name]
    a = text.index(begin)
    b = text.index(end, a)
    return text[a:b], {"path": name, "sha256": INPUTS[name],
                       "lines": [text[:a].count("\n") + 1, text[:b].count("\n")],
                       "extracted_sha256": sha(text[a:b].encode())}


header = '''---
claim_id: excluded_walk_quantitative_memory_transfer_bounded_theorem_note_2026-10-11
claim_type: bounded_theorem
claim_scope: "For the supplied antisymmetric excluded Weyl pair, prove an inverse-edge moment and an explicit mean-survival rate for its fixed effective dressing, then a quantitative time-averaged fixed-transverse-projection occupation for one globally normalized actual positive-free-band packet family."
upstream_dependencies:
  - excluded_walk_memory_current_bounded_theorem_note_2026-10-11
  - excluded_walk_projected_free_band_canonical_current_bounded_theorem_note_2026-10-11
  - excluded_walk_low_energy_energy_current_bounded_theorem_note_2026-10-11
actual_current_surface_status: conditional-support
target_claim_type: bounded_theorem
trace_class: upstream_support
reachability_to_target: supports
target_claim_id: null
target_blocker_text: "Construct controlled links from microscopic dynamics to macroscopic transport."
source_of_blocker_text: user_goal
artifact_role: theorem
next_trace_action: "Independently check this exact publication composition and its preserved source premises before any retained-status decision."
conditional_surface_status: "Exact estimates for the supplied effective generator and the specified actual free-band preparation."
hypothetical_axiom_status: null
admitted_observation_status: null
audit_required_before_effective_retained: true
bare_retained_allowed: false
---

# Quantitative effective memory and time-averaged transverse occupation

**Date:** 2026-10-11

**Type:** bounded_theorem

**Status:** proposed_retained

Current surface status: conditional-support. This is an external publication
candidate for a separate follow-on milestone. The exact edge and occupation
source arguments have received the selective mathematical checks identified
below. This combined note has not received final publication review or an
independent retained-status audit. It changes no status of the prior milestone.

For every nonzero kappa, put b=|kappa|. The normalized dressing spectral
measure of the supplied effective generator has the inverse moment
`integral dnu(E)/(b^2-E^2)<=12I0/b^2`. Its actual combined-edge mass is
at most `12I0[2delta/b-(delta/b)^2]`. Together with the inherited interior
density estimate, this gives the explicit mean-survival bound

    (1/T)integral_0^T |a(t)|^2dt
      <=min{1,D0(bT)^(-4/5)},
    D0=24^(6/5)(327680pi)^(4/5)I0^2.                    (A1 = S20)

For the actual excluded walk, use the constructed free positive-band packet
with band parameter 0<lambda<=1/16, total-momentum center lambda^3(1,1,1),
radius lambda^5, and one global contact projection and normalization.
For the fixed transverse projection F its time-averaged probability obeys

    H_lambda=lambda^(-59/18),
    (1/(lambda H_lambda))integral_0^H_lambda
                  <Psi_lambda(t),F Psi_lambda(t)>dt
       =1/(8pi^2 I0)+O(lambda^(2/9)).                   (A9)

The finite error and every scale domain appear below. This is an order-lambda
occupation of a specified subspace for a constructed family. It neither
describes most of the entire normalized packet nor supplies a convergence
rate for the weighted canonical current.

## 1. Supplied model, exact dependencies, and proof organization

All relative-torus and total-momentum integrals use dq/(2pi)^3 and
dK/(2pi)^3 respectively. Inner products are linear in the second argument.
On the fixed antisymmetric pair fiber, the singlet coefficient is even in q
and the Cartesian triplet coefficients are odd. The supplied free symbol,
contact exclusion, and bounded physical generator are

    H0(K,q)=sigma_1·sin(K/2+q)+sigma_2·sin(K/2-q),
    P=I-|c><c|,
    H_D(K)=P H0(K)P restricted to ran P,

where c is the constant normalized spin singlet. The full operator H_D is
the measurable direct integral of these bounded fibers. The auxiliary c in
the zero extension is not a physical state. Coordinates, lattice and clock
units, this continuous generator, exclusion rule, Hilbert space and
preparation are supplied-model premises. No physical primitive or empirical
clock calibration is selected here.

This note is self-contained for the new S4–S21 and A1–A9 implications given
the following explicitly imported theorems. Their upstream proofs remain in:

- [Projected positive-free-band canonical current](EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md):
  the physical zero-space identification, cone integrals, L6–L8 band measure,
  Q12–Q16 finite comparison and the actual nonzero-K preparation. Q16 is used
  as an all-finite-T inequality, not merely at its later 1/20 specialization.
- [Effective memory and canonical current](EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md):
  E20–E23 give absolute continuity, symmetry and the interior density bound;
  E25–E26 give the earlier finite-horizon split; G5 gives the stated growing
  interval substitution. Its weighted/outgoing/current conclusions remain
  separate results and are not needed to infer this fixed-F probability.
- [Low-energy energy current](EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md):
  the inherited supplied-model and physical-space provenance used by those
  two notes. No canonical-current formula is required by the new proof.

The exact source revisions and corresponding current repository-note
identities are in the reconstruction map and receipt. These dependency
references do not assert that a pending PR has landed or been audited.

The effective compression below uses the inherited `ker H_D(0)=Z` and
`1/12<=I0<=9/8`. The effective density assumptions are stated in Section 7;
the complete band/preparation hypotheses and finite comparison are restated
in Sections 10–13. Thus the composition exposes every imported estimate used
by its new steps. It makes no new inference from finite-control counts.

In Sections 3–9 delta denotes an edge width. In Sections 10–13 it denotes
the weak total-momentum scale lambda^3. The scalar compression coefficient
is written c_edge to distinguish it from the contact singlet c.
'''
add("metadata, result and dependency contract", header,
    ["frozen edge/occupation statements and prior model sources listed in INPUTS"],
    ["new editorial wrapper; no additional mathematical assertion"])

edge, origin = source("EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md",
                      "Work in the Hilbert space", "## 9. Evidence")
edge = re.sub(r"\bc\b", "c_edge", edge)
edge = re.sub(r"^## ([2-8])\.", lambda m: "## " + str(int(m[1]) + 1) + ".", edge, flags=re.M)
add("S1-S21 complete effective proof", "## 2. Fixed physical effective space\n\n" + edge,
    [origin], ["section numbers incremented; scalar c renamed c_edge; mathematical text otherwise unchanged"])

band_setup = '''## 10. Imported band preparation and the reused mean bound

The estimate A1 is now S20 proved above, with C_edge=D0; it is no longer an
unproved dependency within this note. It still depends on the supplied-model
memory theorem stated in Section 7. Set kappa0=(1,1,1), so b=sqrt(3), and
take 0<lambda<=1/16. Define the actual central free slice and projection by

    I_lambda=[5lambda/4,7lambda/4],
    Gamma_lambda=1_I_lambda(H0(0)),
    w_lambda=||Gamma_lambda zeta||^2,
    phi_lambda=Gamma_lambda zeta/sqrt(w_lambda),
    beta_lambda=<c,phi_lambda>, n_lambda=sqrt(1-beta_lambda^2),
    chi_lambda=P phi_lambda/n_lambda,
    A_lambda=<zeta,chi_lambda>=sqrt(w_lambda)/n_lambda.

This beta_lambda is real and nonnegative for the specified slice. The exact
positive contact density (distinct from the effective rho(E) in S13) and
band mass are, for 0<E<2,

    rho(0,E)=E^2/(16pi^3) integral_(S^2)
                product_j(1-E^2 n_j^2/4)^(-1/2)dOmega,
    E^2/(4pi^2)<=rho(0,E)
                  <=E^2/[4pi^2(1-E^2/4)^(3/2)],
    w_lambda=I0^(-1)integral_I_lambda rho(0,E)/E^2 dE.

The inherited finite bounds used below are

    F chi_lambda=0, Pi chi_lambda=A_lambda zeta,
    n_lambda>=1/2, 0<=beta_lambda<=1/2,
    sqrt(lambda)/12<=A_lambda<=2sqrt(lambda), A_lambda<=1,
    C_lambda=2/[(5/4)lambda n_lambda]
                        +beta_lambda sqrt(I0)/n_lambda<=4/lambda.

These are the L6–L8/Q12–Q15 statements of the prior current note. They use
the normalized torus measure, not a fitted low-energy density. The weaker
lower constant 1/12 follows from the source's 1/(3pi) bound.
'''
add("band and normalization premises", band_setup,
    ["long-time L6-L8; quantitative Q12-Q15; joint-scale G1"],
    ["explicit restatement of imported definitions and bounds; A1 identified with proved S20"])

occupation, occupation_origin = source("EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md",
                                      "## 2. A finite band-weight remainder", "## 5. Review obligations")
occupation = re.sub(r"^## ([2-4])\.", lambda m: "## " + str(int(m[1]) + 9) + ".", occupation, flags=re.M)
occupation = occupation.replace("In particular, under the pending A1 premise,", "In particular, using A1=S20,")
occupation = occupation.replace("has center lambda^3 kappa0 and radius lambda^5; it is contained in the\nactual positive free [lambda,2lambda] band before contact projection.",
                                "has center lambda^3 kappa0 and radius lambda^5. The free packet is in the\nactual positive free [lambda,2lambda] band before contact projection.")
finite_comparison = '''The inherited all-T Q16 gives the following finite estimate. Put
H_*=H_D(0), U_delta(tau)=exp[-i tau H_D(delta kappa0)/delta] and
r_delta=delta b^2/4+delta^2 b^3/24. For T>=0 and
0<sigma<=min(1/2,5lambda/8),

    e_perp=sup_(|tau|<=T)||F U_delta(tau)chi_lambda-A_lambda u(tau)||
      <=delta[A_lambda(2b+2Tb^2)+(2b+Tb^2)]/sigma
        +A_lambda[4+(7/2)b^2T^2]sqrt(sigma)/sqrt(I0)
        +2sigma C_lambda+(A_lambda+1)T r_delta.            (Q16, imported)

This estimate already annihilates the fast complementary evolution with F;
no infinite-time or arbitrary-vector approximation is asserted. At the
stated scales sigma=lambda^2 is in its domain. Also delta<=1, b=sqrt(3),
r_delta<=delta and T_lambda>=1. Dividing its four terms by A_lambda gives

    e_perp/A_lambda
       <=108delta T_lambda/[sigma sqrt(lambda)]
          +58T_lambda^2 sqrt(sigma)+96sigma/lambda^(3/2)
          +13T_lambda delta/sqrt(lambda)
       =108lambda^p+58lambda^(2p)+96lambda^(1/2)
                                      +13lambda^(2+p)
       <=275lambda^p=E_lambda.                            (G5, imported)

For the first coefficient use b<2, T>=1 and
1/A_lambda<=12/sqrt(lambda):
`(4+8T)+(4+4T)/A_lambda<=108T/sqrt(lambda)`.
For the second use `I0^(-1/2)<4` and `16+42T^2<=58T^2`.
The last two use C_lambda<=4/lambda, A_lambda<=1 and the same lower bound
on A_lambda. All four powers are at least p because 0<gamma<1/2.
This is the complete finite specialization already proved as G5.

'''
assert occupation.count("Write psi_c(tau)") == 1
occupation = occupation.replace("Write psi_c(tau)", finite_comparison + "Write psi_c(tau)")
preparation, prep_origin = source("FINAL_EXCLUDED_WALK_PROJECTED_BAND_CURRENT_NOTE.md",
    "For |K|<=lambda/16 use the actual positive projector", "Here are explicit margins for a full-dimensional K packet.")
preparation = preparation.replace("(Q28)", "(B18-B19, imported)")
preparation = preparation.replace("by Q4", "by the inherited cone-volume bound")
preparation += '''Here Pi_++(K) is the tensor product of the positive one-particle
projectors for momenta K/2+q and K/2-q. The physical generator also obeys
`||H_D(K)-H_D(K')||<=|K-K'|`; compression preserves the sine Lipschitz
bound. Bounded Duhamel therefore applies at every finite effective time.
For |kappa-kappa0|<=lambda^2 we have |kappa|<2 and
|delta kappa|<=lambda/16, so all these preparation estimates apply.

'''
assert occupation.count("Use exactly the actual free-band family G8:") == 1
occupation = occupation.replace("Use exactly the actual free-band family G8:", preparation + "Use exactly the actual free-band family G8:")
occupation = occupation.replace("smooth normalized h supported in the unit ball and nonzero on an open set.",
                                "smooth h supported in the unit ball and nonzero on an open set, with\nintegral |h(y)|^2dy/(2pi)^3=1.")
occupation = occupation.replace("The substitution tau=delta t exactly gives the previous time average.",
'''The substitution tau=delta t has dt=dtau/delta and 1/H_lambda=delta/T_lambda,
so both factors cancel exactly:

    (1/(lambda H_lambda))integral_0^H_lambda q(delta t)dt
       =(1/(lambda T_lambda))integral_0^T_lambda q(tau)dtau.

It gives the previous time average with its actual normalization.''')
add("A2-A9 complete original-walk composition", occupation,
    [occupation_origin, prep_origin, "quantitative Q16; joint-scale G4-G5; occupation review Sections 3-5"],
    ["section numbers; pending A1 phrase resolved to S20; full imported Q16/G5 and actual projector proof inserted; exact h normalization and time Jacobian displayed; no constants or claims strengthened"])

footer = '''## 14. Evidence, attribution, and precise claim limits

This composition preserves the entire S4–S21 and A1–A9 mathematics. The
original edge worker supplied the compression/edge route, earlier S21 bound
and edge_controls.py. Root suggested the L^(5/3)/T^(-4/5) improvement. The
recovery worker completed its proof and rate_controls.py. Root then authored
the original-walk occupation implication and occupation_controls.py.

The complete independent spectral-edge review is
`EXCLUDED_WALK_SPECTRAL_EDGE_REVIEW.md`, SHA-256
`8a6741ea9ea890fb9fdece7a8c241fed537a1fe899dafe34f716f1211171bd40`,
with receipt `1cc248fc02fedd81a2e8d9a91d5b8d7157ad9abc18e2a4b5cfa4f8c87954e055`.
It found no mathematical repair in S4–S21. Its reviewer disclosed authorship
of inherited long-time/degenerate premises and did not independently
recertify them. The review did not cover A2–A9.

The occupation composition review is
`EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_REVIEW.md`, SHA-256
`e4f0f730b1d14d1d444e9e22eb0f6995fdc2dab4c130375491d6b61528d2d12a`,
with receipt `4398c9bd17e25281efa1dfd2ae1d5f22eafc8415adc8b2a736a11b45c40b789d`.
It reconstructed A2–A9 before opening the author controls and found no
consequential defect conditional on S20. That reviewer authored S20 and
explicitly did not recertify it; S20's coverage is the separate edge review.
Neither review supplies final review of this new publication composition.

The matching primary is
`scripts/excluded_walk_quantitative_memory_transfer_2026_10_11.py`.
It embeds the complete unchanged edge_controls.py (20 controls),
rate_controls.py (15) and occupation_controls.py (14), verifies their exact
SHA-256 identities and executes them in three separate global namespaces.
It imports no historical helper file at runtime. Required libraries are
SymPy and mpmath. AUDIT_TIMEOUT_SEC=180 records the intended process limit;
the external execution harness enforces it. AUDIT_INPUT_PATHS names this
note and the three prior dependencies in Section 1.

The edge helper is an exact finite cubic compression/projection fixture;
the rate helper has exact Gram/kernel identities and an unrelated parabolic
continuous comparator. Its 50-digit floating comparisons have no certified
error enclosure. The occupation helper checks exact scalar and finite
normalization identities. They are author consistency controls, not torus
quadrature, proof of a continuum spectral law, or independent final review.
The separate source reviews used different controls within their stated
scope; their outcomes remain source-bound, not a substitute for this proof.

The original five edge mutations, three rate mutations and three occupation
mutations, all complete failure logs, and the first rate helper's preserved
missing-parenthesis failure remain unchanged. The successful helpers embed
only the frozen corrected versions; no failed artifact is hidden or replaced.
The reconstruction map identifies every proof-source slice, editorial change,
helper payload and current dependency-note identity. The fresh execution
record binds the exact primary, command, timeout, full log and return code.
The receipt and preservation check bind these files and the old evidence.

From a repository root with the stated dependencies installed, reproduce with

```text
python3 scripts/excluded_walk_quantitative_memory_transfer_2026_10_11.py
```

For this external candidate the same basename is in the research directory;
its recorded invocation uses the explicit Python executable in the receipt.
New executions must write fresh logs rather than overwrite the frozen record.

S8 controls actual combined-edge mass; S12 controls the distinct Poisson
proxy. S9 is an inverse-form domain statement, not a positive uniform gap or
a bounded inverse on the whole physical space. S20 controls a time mean;
it proves no pointwise amplitude power, monotonic loss or dissipation.
A7–A9 control the specified actual packet's fixed-F probability with the
given scales. They do not imply a weighted-current convergence rate,
generic-state theorem, stochastic process or many-body transport law.

The earlier memory/current note already establishes selected weighted
asymptotics and a joint growing-time current comparison, and states its
own selected-datum lower bound. Those results are outside the new proof's
scope. This note therefore does not call all weighted-current asymptotics
or all growing-time original-walk control globally open. A rate for the
limiting weighted current and broader preparation-uniform conclusions are
not supplied by the present estimates. No optimal exponent or prefactor,
global novelty result, Lean verification, physical primitive adoption,
publication authorization or retained/audit verdict is claimed.
'''
add("evidence, resolved source reviews and scoped limits", footer,
    ["complete edge and occupation reviews; frozen helper/evidence packets"],
    ["obsolete pending-source-review prose replaced by exact completed review scopes; globally-open wording narrowed; final composition review remains pending"])

note_text = "".join(parts)
assert not NOTE.exists()
NOTE.write_text(note_text)

primary_header = '''#!/usr/bin/env python3
"""Literal author consistency controls for quantitative memory transfer.

Three complete frozen helpers execute in separate global namespaces. This
replay checks their exact finite algebra and explicitly floating comparators;
it is not independent proof of the continuum or final publication review.
Runtime dependencies: SymPy and mpmath. No helper file is read or imported.
"""
import hashlib
import json
import platform
import time

AUDIT_TIMEOUT_SEC = 180
CLAIM_ID = "excluded_walk_quantitative_memory_transfer_bounded_theorem_note_2026-10-11"
AUDIT_INPUT_PATHS = [
    "docs/EXCLUDED_WALK_QUANTITATIVE_MEMORY_TRANSFER_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
    "docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
]

'''
primary_parts = [primary_header]
for variable, name, expected, count in HELPERS:
    src = (S / name).read_text()
    assert "'''" not in src
    primary_parts.append(variable + " = r'''" + src + "'''\n\n")
primary_parts.append("AUTHOR_BLOCKS = [\n")
for variable, name, expected, count in HELPERS:
    primary_parts.append(f"    ({name!r}, {expected!r}, {count}, {variable}),\n")
primary_parts.append("]\n\n\n" + '''def main():
    started = time.monotonic()
    total_checks = 0
    for name, expected_sha256, expected_checks, source in AUTHOR_BLOCKS:
        actual = hashlib.sha256(source.encode("utf-8")).hexdigest()
        assert actual == expected_sha256, (name, actual, expected_sha256)
        print(json.dumps({"author_block": name, "sha256": actual, "phase": "begin"}), flush=True)
        namespace = {"__name__": "__main__", "__file__": "<frozen-author:" + name + ">"}
        exec(compile(source, namespace["__file__"], "exec"), namespace, namespace)
        assert namespace["checks"] == expected_checks, (name, namespace["checks"], expected_checks)
        total_checks += namespace["checks"]
        print(json.dumps({"author_block": name, "checks": namespace["checks"], "phase": "complete"}), flush=True)
    print(json.dumps({"status": "PASS", "claim_id": CLAIM_ID,
                      "isolated_author_blocks": len(AUTHOR_BLOCKS), "author_checks": total_checks,
                      "python": platform.python_version(), "elapsed_seconds": time.monotonic()-started,
                      "scope": "author consistency replay; no independent continuum or final publication proof"}), flush=True)


if __name__ == "__main__":
    main()
''')
assert not PRIMARY.exists()
PRIMARY.write_text("".join(primary_parts))

dependencies = []
for name in ["EXCLUDED_WALK_MEMORY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
             "EXCLUDED_WALK_PROJECTED_FREE_BAND_CANONICAL_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md",
             "EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md"]:
    p = W / "docs" / name
    dependencies.append({"path": str(p), "future_relative_path": "docs/" + name,
                         "sha256": sha(p.read_bytes()), "lines": len(p.read_text().splitlines()),
                         "coverage": "Dependency identity only; necessary complete source arguments reused/refreshed at the frozen research-source revisions."})
record = {"claim_id": CLAIM, "future_note": FUTURE_NOTE,
          "note": {"path": str(NOTE), "sha256": sha(NOTE.read_bytes()), "lines": len(note_text.splitlines())},
          "primary": {"path": str(PRIMARY), "sha256": sha(PRIMARY.read_bytes())},
          "input_identities": INPUTS, "sections": mapping,
          "helper_payloads": [{"variable": var, "source": str(S / name), "sha256": expected,
                               "expected_controls": count, "modification": "none; exact decoded string bytes"}
                              for var, name, expected, count in HELPERS],
          "dependency_notes": dependencies,
          "preservation": "All source proofs, author evidence and historical failures are kept unchanged; the new note resolves only stale review/status prose and scope wording.",
          "review_boundary": "No new mathematics or final composition review claimed; selective source reviews retain their stated independence limits."}
mpath = D / "reconstruction_map.json"
assert not mpath.exists()
mpath.write_text(json.dumps(record, indent=2) + "\n")
human = ["# Exact quantitative memory-transfer reconstruction map\n\n",
         f"Claim: `{CLAIM}`. Future note: `{FUTURE_NOTE}`.\n\n",
         "The machine map binds every generated segment by its final line span and exact text hash.\n",
         "`compose_candidate.py` gives the full literal source slicing and deterministic replacements.\n",
         "No mathematical constant, domain or claimed estimate is strengthened.\n\n",
         "| Segment | Final note lines | Reconstruction |\n| --- | --- | --- |\n"]
for row in mapping:
    human.append(f"| {row['label']} | {row['output_lines'][0]}–{row['output_lines'][1]} | {'; '.join(row['changes'])} |\n")
human.extend(["\nThe full S1–S21 proof slice is preserved apart from section numbering and\n",
              "the scalar `c` → `c_edge` rename that avoids the contact-singlet collision.\n",
              "A2–A9 retain the original proof with the full Q16/G5 specialization, actual\n",
              "projector construction and exact time Jacobian made explicit from checked sources.\n",
              "A1 is the proved S20. All source source-review limitations remain explicit.\n\n",
              "The old edge terminal wording is superseded only in this new composition: selected\n",
              "weighted/current and growing-time results are outside this theorem, not globally open.\n",
              "The frozen source notes and their receipts are not edited.\n\n",
              "| Embedded helper | Exact SHA-256 | Controls |\n| --- | --- | --- |\n"])
for _, name, expected, count in HELPERS:
    human.append(f"| `{name}` | `{expected}` | {count} |\n")
human.extend(["\nPayloads are decoded and compared byte-for-byte with their complete source files before freezing.\n",
              "The primary checks the same hashes again and runs each helper in a fresh namespace.\n",
              "The combined run is author consistency replay only. The reconstruction and metadata\n",
              "of this new publication candidate still require final source-bound review.\n"])
hpath = D / "RECONSTRUCTION_MAP.md"
assert not hpath.exists()
hpath.write_text("".join(human))
print(json.dumps({"note": record["note"], "primary": record["primary"],
                  "segments": len(mapping), "embedded_helpers": len(HELPERS)}, indent=2))
