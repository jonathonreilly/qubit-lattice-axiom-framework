"""Run the exact combined author primary once, preserving all execution output."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import time

D = Path(__file__).resolve().parent
S = D.parent
PRIMARY = S / "excluded_walk_quantitative_memory_transfer_2026_10_11.py"
PYTHON = "/opt/homebrew/opt/python@3.13/bin/python3.13"
TIMEOUT = 180
outputs = {name: D / name for name in
           ["primary_attempt1.stdout.log", "primary_attempt1.stderr.log",
            "primary_attempt1.log", "primary_attempt1_execution.json"]}
assert all(not p.exists() for p in outputs.values()), "Preserve existing execution evidence"
before = hashlib.sha256(PRIMARY.read_bytes()).hexdigest()
command = [PYTHON, str(PRIMARY)]
started_utc = datetime.now(timezone.utc).isoformat()
started = time.monotonic()
timed_out = False
try:
    result = subprocess.run(command, cwd=S, capture_output=True, text=True, timeout=TIMEOUT)
    stdout, stderr, returncode = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as exc:
    timed_out = True
    stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
    stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
    returncode = None
elapsed = time.monotonic() - started
outputs["primary_attempt1.stdout.log"].write_text(stdout)
outputs["primary_attempt1.stderr.log"].write_text(stderr)
outputs["primary_attempt1.log"].write_text(stdout + stderr)
record = {"command": command, "cwd": str(S), "started_utc": started_utc,
          "elapsed_seconds": elapsed, "timeout_seconds": TIMEOUT,
          "timed_out": timed_out, "returncode": returncode,
          "executed_source_sha256": before,
          "source_unchanged": hashlib.sha256(PRIMARY.read_bytes()).hexdigest() == before,
          "logs": [{"path": str(outputs[name]),
                    "sha256": hashlib.sha256(outputs[name].read_bytes()).hexdigest()}
                   for name in ["primary_attempt1.stdout.log", "primary_attempt1.stderr.log", "primary_attempt1.log"]],
          "scope": "Literal author consistency replay; not independent continuum proof or final publication review."}
outputs["primary_attempt1_execution.json"].write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
assert returncode == 0 and not timed_out and record["source_unchanged"], "Combined primary execution failed; full logs preserved"
