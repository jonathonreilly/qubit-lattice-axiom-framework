"""Mechanical source reconstruction and preservation checks, not a physics review."""
from datetime import datetime, timezone
from pathlib import Path
import ast
import hashlib
import json
import re

D = Path(__file__).resolve().parent
S = D.parent
M = json.loads((D / "reconstruction_map.json").read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
rows = []


def check(name, condition, details=None):
    rows.append({"check": name, "passed": bool(condition), "details": details})
    assert condition, name


for row in json.loads((D / "source_inventory_before.json").read_text())["records"]:
    check("preserved:" + row["path"], sha(Path(row["path"]).read_bytes()) == row["sha256"])
for name, expected in M["input_identities"].items():
    check("source:" + name, sha((S / name).read_bytes()) == expected)
for row in M["dependency_notes"]:
    check("dependency:" + row["future_relative_path"], sha(Path(row["path"]).read_bytes()) == row["sha256"])
for key in ["note", "primary"]:
    check("final_identity:" + key, sha(Path(M[key]["path"]).read_bytes()) == M[key]["sha256"])

note = Path(M["note"]["path"]).read_text()
note_lines = note.splitlines(keepends=True)
for row in M["sections"]:
    lo, hi = row["output_lines"]
    check("note_segment:" + row["label"],
          sha("".join(note_lines[lo - 1:hi]).encode()) == row["output_sha256"])
    for origin in row["origins"]:
        if isinstance(origin, dict):
            src_lines = (S / origin["path"]).read_text().splitlines(keepends=True)
            a, b = origin["lines"]
            check("origin_slice:" + origin["path"],
                  sha("".join(src_lines[a - 1:b]).encode()) == origin["extracted_sha256"])

edge_source = (S / "EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md").read_text()
edge_original = edge_source[edge_source.index("Work in the Hilbert space"):edge_source.index("## 9. Evidence")].rstrip()
edge_final = note[note.index("Work in the Hilbert space"):note.index("## 10. Imported band")].rstrip()
edge_reversed = re.sub(r"\bc_edge\b", "c", edge_final)
edge_reversed = re.sub(r"^## ([3-9])\.", lambda m: "## " + str(int(m[1]) - 1) + ".", edge_reversed, flags=re.M)
check("entire_S1_S21_source_recovered", edge_reversed == edge_original,
      "Only section labels and c/c_edge notation differ.")

occupation_source = (S / "EXCLUDED_WALK_AVERAGED_TRANSVERSE_OCCUPATION_DRAFT.md").read_text()
occupation_original = occupation_source[occupation_source.index("## 2. A finite band-weight remainder"):occupation_source.index("## 5. Review obligations")].rstrip()
occupation_final = note[note.index("## 11. A finite band-weight remainder"):note.index("## 14. Evidence")].rstrip()
occupation_reversed = re.sub(r"^## (11|12|13)\.", lambda m: "## " + str(int(m[1]) - 9) + ".", occupation_final, flags=re.M)
occupation_reversed = occupation_reversed.replace("In particular, using A1=S20,", "In particular, under the pending A1 premise,")
occupation_reversed = occupation_reversed.replace("has center lambda^3 kappa0 and radius lambda^5. The free packet is in the\nactual positive free [lambda,2lambda] band before contact projection.",
                                                "has center lambda^3 kappa0 and radius lambda^5; it is contained in the\nactual positive free [lambda,2lambda] band before contact projection.")
a = occupation_reversed.index("The inherited all-T Q16 gives")
b = occupation_reversed.index("Write psi_c(tau)", a)
occupation_reversed = occupation_reversed[:a] + occupation_reversed[b:]
a = occupation_reversed.index("For |K|<=lambda/16 use the actual positive projector")
b = occupation_reversed.index("Use exactly the actual free-band family G8:", a)
occupation_reversed = occupation_reversed[:a] + occupation_reversed[b:]
occupation_reversed = occupation_reversed.replace("smooth h supported in the unit ball and nonzero on an open set, with\nintegral |h(y)|^2dy/(2pi)^3=1.",
                                                "smooth normalized h supported in the unit ball and nonzero on an open set.")
a = occupation_reversed.index("The substitution tau=delta t has dt=")
b = occupation_reversed.index("Equations A5-A6 yield", a)
occupation_reversed = occupation_reversed[:a] + "The substitution tau=delta t exactly gives the previous time average.\n" + occupation_reversed[b:]
check("entire_A2_A9_source_recovered", occupation_reversed == occupation_original,
      "Reverses only the fully recorded premise insertions, labels and review-status edits.")

primary_path = Path(M["primary"]["path"])
primary = primary_path.read_text()
tree = ast.parse(primary)
assignments = {node.targets[0].id: node.value for node in tree.body
               if isinstance(node, ast.Assign) and len(node.targets) == 1
               and isinstance(node.targets[0], ast.Name)}
payload_names = {row["variable"] for row in M["helper_payloads"]}
for row in M["helper_payloads"]:
    payload = ast.literal_eval(assignments[row["variable"]]).encode()
    original = Path(row["source"]).read_bytes()
    check("literal_payload:" + row["variable"], payload == original and sha(payload) == row["sha256"],
          {"bytes": len(payload), "sha256": sha(payload)})
check("primary_claim_id", ast.literal_eval(assignments["CLAIM_ID"]) == M["claim_id"])
check("primary_timeout", ast.literal_eval(assignments["AUDIT_TIMEOUT_SEC"]) == 180)
check("primary_inputs", ast.literal_eval(assignments["AUDIT_INPUT_PATHS"]) ==
      [M["future_note"]] + [row["future_relative_path"] for row in M["dependency_notes"]])
wrapper_nodes = []
for node in tree.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in payload_names:
        wrapper_nodes.append("# Exact verified embedded payload: " + node.targets[0].id)
    else:
        wrapper_nodes.append(ast.get_source_segment(primary, node))
wrapper = D / "primary_wrapper_readback.txt"
assert not wrapper.exists()
wrapper.write_text("\n\n".join(wrapper_nodes) + "\n")

execution = json.loads((D / "primary_attempt1_execution.json").read_text())
check("executed_exact_final_primary", execution["executed_source_sha256"] == sha(primary_path.read_bytes()))
check("execution_completed_with_timeout", execution["returncode"] == 0 and not execution["timed_out"] and execution["timeout_seconds"] == 180)
for row in execution["logs"]:
    check("execution_log:" + row["path"], sha(Path(row["path"]).read_bytes()) == row["sha256"])
summary = json.loads((D / "primary_attempt1.stdout.log").read_text().splitlines()[-1])
check("three_blocks_49_author_controls", summary["status"] == "PASS" and summary["isolated_author_blocks"] == 3 and summary["author_checks"] == 49)
check("no_stderr", (D / "primary_attempt1.stderr.log").read_bytes() == b"")

result = {"verified_utc": datetime.now(timezone.utc).isoformat(),
          "scope": "Deterministic composition, exact payload and preservation verification only; no final physics/publication review.",
          "checks": len(rows), "all_match": all(x["passed"] for x in rows),
          "note_sha256": sha(Path(M["note"]["path"]).read_bytes()),
          "primary_sha256": sha(primary_path.read_bytes()), "records": rows}
out = D / "composition_verification.json"
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "records"}, indent=2))
