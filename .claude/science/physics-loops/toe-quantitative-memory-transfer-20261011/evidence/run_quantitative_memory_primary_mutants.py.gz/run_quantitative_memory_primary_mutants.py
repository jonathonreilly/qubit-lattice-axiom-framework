from pathlib import Path
import ast
import hashlib
import json
import subprocess
import time

S=Path(__file__).resolve().parent
D=S/'quantitative_memory_primary_mutations'
D.mkdir(exist_ok=True)
primary_path=S/'excluded_walk_quantitative_memory_transfer_2026_10_11.py'
source=primary_path.read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(source.encode())=='bf1a83f21e06818ba1182bfa186d13ccf971777afb52f70a09da0c69e0eaa85d'
tree=ast.parse(source)
assignments={n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign)
             and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
PY='/opt/homebrew/opt/python@3.13/bin/python3.13'
rows=[]
for directory,manifest,var in [
    ('spectral_edge','mutation_manifest.json','EDGE_CONTROLS_SOURCE'),
    ('spectral_edge','rate_mutation_manifest.json','RATE_CONTROLS_SOURCE'),
    ('averaged_transverse_occupation','mutation_manifest.json','OCCUPATION_CONTROLS_SOURCE')]:
    old_assignment=ast.get_source_segment(source,assignments[var])
    helper=ast.literal_eval(assignments[var].value)
    helper_sha=sha(helper.encode())
    for row in json.loads((S/directory/manifest).read_text()):
        assert helper.count(row['old'])==1
        changed=helper.replace(row['old'],row['new'])
        new_assignment=var+' = '+repr(changed)
        assert source.count(old_assignment)==1
        mutant=source.replace(old_assignment,new_assignment)
        assert mutant.count(helper_sha)==1
        new_hash=sha(changed.encode())
        mutant=mutant.replace(helper_sha,new_hash)
        p=D/('mutant_'+row['name']+'.py');log=p.with_suffix('.log')
        assert not p.exists() and not log.exists()
        p.write_text(mutant)
        began=time.monotonic()
        with log.open('w') as output:
            result=subprocess.run([PY,str(p)],stdout=output,stderr=subprocess.STDOUT,timeout=180)
        raw=log.read_text()
        rec={'name':row['name'],'helper_variable':var,'old':row['old'],'new':row['new'],
             'metadata_refresh':{'before':helper_sha,'after':new_hash},
             'source':str(p),'source_sha256':sha(p.read_bytes()),'log':str(log),
             'log_sha256':sha(log.read_bytes()),'exit_code':result.returncode,
             'elapsed_seconds':time.monotonic()-began,'timeout_seconds':180,
             'intended_assertion':row['intended_assertion'],
             'intended_failure':result.returncode==1 and 'AssertionError: '+row['intended_assertion'] in raw}
        rows.append(rec)
        (D/'manifest.json').write_text(json.dumps({'primary':str(primary_path),
            'primary_sha256':sha(source.encode()),'scope':'Actual whole-primary semantic mutations, each with an explicit expected embedded-hash refresh.',
            'cases':rows},indent=2)+'\n')
        print(json.dumps({k:rec[k] for k in ('name','exit_code','intended_failure')}),flush=True)
assert len(rows)==11 and all(r['intended_failure'] for r in rows)
