# Spectral-edge author checkpoint

2026-10-11. Bounded external derivation; independent review pending.
Only the new note and `spectral_edge/` may be written. Prior sources and
reviews, repositories, prompts, PRs and audit state remain unchanged.

Frozen inputs:

- memory note: b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c;
- memory review: c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0;
- long-time note: 09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324;
- degenerate note: b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876.

The complete earlier source readings and checked proofs are reused at
identical bytes; compression, cone normalization, E20 and E25–E29 were
refreshed for the present interaction.

Current derived route: on the fixed zero space Z, for b=|kappa|>0 and
W(q)=sum kappa_j^2 sin^2(q_j),

    C=b^2 I-A^2 >=Pi W Pi >=[b^2/(12I0)] |zeta><zeta|.

The first step retains the nonnegative compression defect
Pi B(I-Pi)B Pi. The second uses pointwise transverse/longitudinal
orthogonality, which scalar W preserves, and exact cubic symmetry of
the normalized torus integral. Thus, for 0<chi=delta/b<1,

    nu({|E|>=b-delta}) <= min{1,12I0(2chi-chi^2)},
    integral (b^2-E^2)^-1 dnu <=12I0/b^2,
    e_delta <= min{1,24I0 chi}.

The inverse-form proof uses (C+eta)^-1 before monotone convergence.
The original e_delta is a Poisson-resolvent upper bound, distinct from
the actual edge mass. Either bound can be used in the mean-survival split.
With tau=bT, L=1+log(2tau), and
chi=[64 pi L/(I0 tau)]^(2/7)<1, the inherited finite-horizon estimate gives

    mean |a|^2 <=min{1,3136 I0^2 [64 pi L/(I0 tau)]^(4/7)}.

The proposed result is uniform in the direction of nonzero kappa, so the
diagonal requested case is included without a separate extra hypothesis.
No pointwise amplitude/current rate or joint original-walk time limit is
claimed. The operator still has norm b; the rank-one form lower bound is
not a positive uniform gap.

The initially considered cone-cutoff estimate would yield only O(sqrt(delta)).
It is superseded by the exact scalar dressing coefficient and is not a
counterexample or failed proof. Remaining work: complete source-bound note,
exact finite controls and literal mutants, full logs and identity receipt;
then freeze for a separate independent check.
