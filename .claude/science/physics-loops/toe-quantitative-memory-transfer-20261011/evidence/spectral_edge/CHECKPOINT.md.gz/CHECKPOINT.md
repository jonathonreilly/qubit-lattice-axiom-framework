# Spectral-edge author checkpoint

2026-10-11. Recovery complete; final source-bound independent review pending.
The original checkpoint is preserved byte-for-byte as
`CHECKPOINT.before_recovery.md`; its initial identity is recorded in
`recovery_initial_inventory.json`.

Current note: S/EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md, 452 lines.
S=/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011.
The frozen source and evidence identities are in spectral_edge/receipt.json.
This checkpoint is author recovery state, not an independent verdict.

Direct frozen inputs, read completely in recovery:

- memory note b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c;
- memory review c8dbb7860af01dc8c8d0203e23a9bfe34cc26c0895cace0c51af46f3f70669e0;
- long-time note 09998aec1dafc9198609237dce2238bc672182d6c1baca3294b8772a5888c324;
- degenerate note b8f923be6e50de14ba0bb1a35ccfd71aec7575fd710693535cf0417c76daa876.

Completed conditional derivation:

- S5-S7: C=b^2 I-A^2 >= [b^2/(12I0)] |zeta><zeta|; exact compression defect kept.
- S8: actual combined-edge mass <= min{1,12I0(2chi-chi^2)}.
- S9-S10: regulated inverse form gives integral dnu/(b^2-E^2)<=12I0/b^2.
- S11-S12: the separate Poisson term e_delta <= min{1,24I0 chi}.
- S15: integral rho^(5/3)<=24I0(32768pi I0)^(2/3)b^(-2/3).
- S16-S20: direct Holder proof of special Young plus exact kernel norm gives
  mean survival <=min{1,24^(6/5)(327680pi)^(4/5)I0^2(bT)^(-4/5)}.
- S21: original weaker logarithmic estimate preserved with its exact domain.

The original worker supplied the rank-one/edge route and original helper.
Root supplied the candidate Lp rate improvement. Recovery checked and wrote
this complete author composition and added a separate rate helper.
No part of this authorship is presented as independent review.

Evidence: all 18 pre-existing files have been preserved at their original
bytes except this checkpoint, whose original bytes have a separate copy.
The original helper/logs were inspected without replaying or overwriting.
The new helper passed 15 controls; its three actual source-copy mutants
failed at their intended assertions. The first new-helper execution had a
missing closing parenthesis; rate_controls_attempt1.py, rate_baseline.log
and rate_baseline_execution.json preserve that failed source/run. The only
repair was the missing parenthesis. Successful evidence uses the distinct
rate_baseline_attempt2.log and rate_baseline_attempt2_execution.json.

Limits and next decision:

The theorem remains conditional on the supplied effective generator and
frozen memory theorem, especially E20-E23. It is uniform in direction for
b>0 and is not an operator-norm gap. No pointwise Fourier rate, weighted
canonical-current convergence rate, or growing-time original-walk estimate
is supplied. No Lean verification is supplied. Obtain a separate reviewer
for the exact final source before substantial downstream use. Root owns
any later original-walk composition; this bounded worker does not expand
into it. No repository source, prompt, PR, primitive or audit state changed.
