"""Exact author controls for the spectral-edge proof.

The finite cubic orbit checks compression and spectral-projection algebra;
it is not quadrature certification of the continuum spectral measure.
No earlier runner is imported. Runtime dependency: SymPy.
"""
import json
import platform
import time

import sympy as sp


began = time.monotonic()
checks = 0


def zero(value):
    entries = list(value) if isinstance(value, sp.MatrixBase) else [value]
    return all(sp.simplify(x) == 0 for x in entries)


def check(name, condition, detail=None):
    global checks
    assert bool(condition), name
    checks += 1
    print(json.dumps({"check": name, "detail": detail}, sort_keys=True))


def cross(v):
    x, y, z = v
    return sp.Matrix([[0, -z, y], [z, 0, -x], [-y, x, 0]])


# Three antipodal pairs q=+/-arcsin(3/5)e_j, each pair weight 1/3.
# Odd fields are represented by their positive member divided by sqrt(3).
# This is an exact finite model with I0_fixture=25/36, not an estimate of
# the continuum I0. Both signs of each q pair are included by odd parity.
sine, cosine = sp.Rational(3, 5), sp.Rational(4, 5)
axes = [sp.eye(3)[:, j] for j in range(3)]
I0_fixture = 1 / (4 * sine**2)
F = sp.diag(*[sp.eye(3) - e*e.T for e in axes])
zeta = sp.Matrix.vstack(*axes) / sp.sqrt(3)
Pz = zeta * zeta.H
Pi = F + Pz
identity = sp.eye(9)
check("physical_zero_projection",
      zero(Pi*Pi-Pi) and zero(Pi-Pi.H) and Pi.rank() == 7
      and zero((zeta.H*zeta)[0]-1) and zero(F*zeta),
      {"rank": Pi.rank(), "I0_fixture": str(I0_fixture)})


def build(kappa):
    b2 = (kappa.T*kappa)[0]
    ds = []
    for j in range(3):
        dj = kappa.copy()
        dj[j] *= cosine
        ds.append(dj)
    B = sp.diag(*[sp.I*cross(dj) for dj in ds])
    W = sp.diag(*[sine**2*kappa[j]**2*sp.eye(3) for j in range(3)])
    dd = sp.diag(*[dj*dj.T for dj in ds])
    A = Pi*B*Pi
    c = b2/(12*I0_fixture)
    return b2, B, W, dd, A, c


kappa = sp.Matrix([sp.Rational(2, 3), -sp.Rational(3, 7), sp.Rational(5, 4)])
b2, B, W, dd, A, c = build(kappa)
check("pointwise_cross_square_defect", zero(b2*identity-B*B-W-dd))
check("bounded_compression_is_selfadjoint", zero(A-A.H))
compression_defect = Pi*B*(identity-Pi)*B*Pi
check("compression_square_keeps_positive_defect",
      zero(Pi*B*B*Pi-A*A-compression_defect)
      and not zero(compression_defect))
check("scalar_weight_preserves_transverse_longitudinal_orthogonality",
      zero(F*W*Pz) and zero(Pz*W*F))
check("exact_cubic_dressing_coefficient", zero((zeta.H*W*zeta)[0]-c))
C = b2*Pi-A*A
check("rank_one_defect_gram_identity",
      zero(C-c*Pz-(F*W*F+Pi*dd*Pi+compression_defect)))
raw = sp.Matrix([sp.Rational(j+1, 11)+sp.I*sp.Rational((-1)**j, 13) for j in range(9)])
psi = Pi*raw
alpha = (zeta.H*psi)[0]
u = F*psi
check("actual_weighted_vector_decomposition",
      zero((psi.H*W*psi)[0]-(u.H*W*u)[0]-c*sp.conjugate(alpha)*alpha))
positive_remainder = sp.simplify((psi.H*(C-c*Pz)*psi)[0])
check("nontrivial_form_vector_control", positive_remainder > 0, str(positive_remainder))


# A literal combined two-edge spectral projection in the finite diagonal
# model: positive and negative high eigenvalues are +/-sqrt(66)/5.
# The remaining physical eigenvalues are 0 and +/-4/5.
b2, B, W, dd, A, c = build(sp.ones(3, 1))
C = b2*Pi-A*A
f2, high2 = sp.Rational(16, 25), sp.Rational(66, 25)
Pedge = A*A*(A*A-f2*Pi)/(high2*(high2-f2))
check("combined_edge_projector_is_exact",
      zero(Pedge*Pedge-Pedge) and zero(Pedge-Pedge.H)
      and zero(A*A*Pedge-high2*Pedge) and Pedge.rank() == 2)
edge_mass = sp.simplify((zeta.H*Pedge*zeta)[0])
edge_vector = Pedge*zeta
check("two_edge_mass_and_longitudinal_coefficient",
      edge_mass == sp.Rational(25, 33)
      and zero((edge_vector.H*edge_vector)[0]-edge_mass)
      and zero((zeta.H*edge_vector)[0]-edge_mass), str(edge_mass))
edge_energy = sp.simplify((edge_vector.H*C*edge_vector)[0])
check("projection_uses_squared_overlap",
      zero(edge_energy-(b2-high2)*edge_mass)
      and sp.simplify(edge_energy-c*edge_mass**2) == sp.Rational(8, 121),
      {"c": str(c), "edge_energy": str(edge_energy),
       "rank_one_form": str(c*edge_mass**2)})

# Only this finite fixture is invertible on all of its physical space.
# The continuum proof instead uses a regulator and monotone convergence.
inverse_moment = sp.simplify((zeta.H*(C+identity-Pi).inv()*zeta)[0])
check("finite_inverse_moment_direct_matrix_check",
      inverse_moment == sp.Rational(649, 297) and inverse_moment <= 1/c,
      {"inverse_moment": str(inverse_moment), "bound": str(1/c)})
check("symmetric_measure_removes_odd_inverse_part",
      zero((zeta.H*A*(C+identity-Pi).inv()*zeta)[0]))


# Exact scalar certificate for the Poisson-resolvent edge bound.
x, delta = sp.symbols("x delta", positive=True)
poisson_majorant = delta/(4*x)
positive_difference = delta*(x-delta)**2/(2*x*(x*x+delta*delta))
check("poisson_bound_factor_two",
      zero(poisson_majorant-delta**2/(x*x+delta*delta)-positive_difference))
b = sp.symbols("b", positive=True)
chi = sp.symbols("chi", positive=True)
check("edge_spectral_defect_exact",
      zero((b*b-(b-delta)**2).subs(delta,b*chi)-b*b*(2*chi-chi*chi)))


# Reconstruct the mean-survival optimization from the actual coefficient
# in the inherited E20/E25 density bound, retaining its logarithm.
I0, q = sp.symbols("I0 q", positive=True)
H_coefficient = 256*sp.sqrt(sp.pi*I0)
bound_root = 24*I0*chi + H_coefficient*q*chi**(-sp.Rational(3, 4))
q_at_optimizer = chi**sp.Rational(7, 4)/(8*sp.sqrt(sp.pi/I0))
check("mean_bound_optimizer_stationary",
      zero(sp.diff(bound_root,chi).subs(q,q_at_optimizer)))
check("mean_bound_optimizer_value",
      zero(bound_root.subs(q,q_at_optimizer)-56*I0*chi)
      and 56**2 == 3136)
tau = sp.symbols("tau", positive=True)
L = 1+sp.log(2*tau)
check("optimizer_domain_monotonicity",
      zero(sp.diff(L/tau,tau)+sp.log(2*tau)/tau**2))
universal_domain_certificate = sp.Rational(64)*sp.Rational(22,7)*12*18/(2**16)
check("universal_large_horizon_domain",
      universal_domain_certificate < 1,
      {"tau_at_least": 2**16, "upper_bound_for_Q_at_threshold": str(universal_domain_certificate),
       "elementary_inputs": "pi<22/7, log(2)<1, I0>=1/12; L/tau decreases for tau>=1/2"})

print(json.dumps({"checks": checks, "python": platform.python_version(),
                  "sympy": sp.__version__, "elapsed_seconds": time.monotonic()-began,
                  "scope": "Exact finite compression/projection and scalar proof controls; author evidence, not independent review or continuum quadrature certification."},
                 sort_keys=True))
