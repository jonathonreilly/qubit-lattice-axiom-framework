"""Author controls for the L^(5/3) mean-survival estimate.

No prior helper is imported. Exact identities use SymPy. Continuous-density
comparators use 50-digit mpmath arithmetic without certified error bounds.
The parabolic density is an unrelated comparator, not a torus quadrature.
"""
import json
import platform
import time

import mpmath as mp
import sympy as sp


started = time.monotonic()
mp.mp.dps = 50
checks = 0


def check(name, condition, detail=None):
    global checks
    assert bool(condition), name
    checks += 1
    print(json.dumps({"check": name, "detail": detail}, sort_keys=True))


def zero(expr):
    return sp.simplify(expr) == 0


# C has a genuine kernel, but zeta has a finite inverse-form moment.
# The rank-one bound is checked as a Gram identity, not by assigning an
# inverse-moment value. This fixture does not model the entire torus.
eta = sp.symbols("eta", positive=True)
C = sp.Matrix([[1, 1, 0], [1, 2, 0], [0, 0, 0]])
zeta = sp.Matrix([1, 0, 0])
c = sp.Rational(1, 2)
gram = sp.Matrix([[1/sp.sqrt(2), sp.sqrt(2), 0]])
check("singular_C_rank_one_gram_bound",
      C.det() == 0 and C-c*zeta*zeta.T == gram.T*gram)
xeta = (C+eta*sp.eye(3)).inv()*zeta
teta = (zeta.T*xeta)[0]
check("regulated_inverse_form_identity",
      zero((xeta.T*C*xeta)[0]-teta+eta*(xeta.T*xeta)[0])
      and zero(teta-(eta+2)/(eta*eta+3*eta+1)))
check("regulated_bound_and_finite_limit_without_C_inverse",
      zero(1/c-teta-eta*(2*eta+5)/(eta*eta+3*eta+1))
      and sp.limit(teta, eta, 0, dir="+") == 1/c)


# The L^(5/4) kernel mass comes from an actual integral on the whole line.
x, duration = sp.symbols("x duration", positive=True)
kernel_power_integral = 2*(sp.integrate(1, (x, 0, 1/duration))
    +sp.integrate((duration*x)**(-sp.Rational(5, 4)),
                  (x, 1/duration, sp.oo)))
kernel_coefficient = sp.Integer(10)
check("kernel_L5over4_mass_exact", zero(kernel_power_integral-kernel_coefficient/duration),
      str(kernel_power_integral))


# An unrelated absolutely continuous probability law rho=(3/4)(1-E^2)
# on [-1,1]. Compute its Fourier transform and difference density directly.
E, u = sp.symbols("E u", real=True)
rho = sp.Rational(3, 4)*(1-E*E)
amplitude = sp.integrate(rho*sp.cos(duration*E), (E, -1, 1))
amplitude_closed = 3*(sp.sin(duration)-duration*sp.cos(duration))/duration**3
check("parabolic_probability_and_Fourier_transform",
      sp.integrate(rho, (E, -1, 1)) == 1 and zero(amplitude-amplitude_closed)
      and sp.limit(amplitude, duration, 0, dir="+") == 1)
h = sp.factor(sp.integrate(rho.subs(E,u)*rho.subs(E,u-x), (u, x-1, 1)))
check("difference_density_from_actual_convolution",
      zero(2*sp.integrate(h,(x,0,2))-1)
      and zero(h.subs(x,0)-sp.integrate(rho*rho,(E,-1,1))), str(h))
qpoly = sp.cancel((h-h.subs(x,0))/x)
mean_from_sinc = 2*(h.subs(x,0)*sp.Si(2*duration)
    +sp.integrate(qpoly*sp.sin(duration*x),(x,0,2)))/duration
check("one_sided_sinc_mean_has_correct_derivative_and_origin",
      zero(sp.diff(duration*mean_from_sinc,duration)-amplitude_closed**2)
      and sp.limit(mean_from_sinc,duration,0,dir="+") == 1)


# The interpolation uses a weighted first inverse moment. The comparator's
# envelope rho(E) <= (3/4)*(1-|E|)^(-3/2) is elementary on [-1,1].
inverse_moment = sp.integrate(sp.cancel(rho/(1-E*E)), (E,-1,1))
check("parabolic_inverse_moment_direct_integral", inverse_moment == sp.Rational(3,2))
rho_mp = lambda energy: mp.mpf(3)/4*(1-energy*energy)
rho_p_mass = mp.quad(lambda energy: rho_mp(energy)**(mp.mpf(5)/3), [-1,0,1])
interpolation_bound = 2*(mp.mpf(3)/4)**(mp.mpf(2)/3)*mp.mpf(3)/2
check("continuous_density_weighted_moment_interpolation", rho_p_mass < interpolation_bound,
      {"L5over3_power_integral": str(rho_p_mass), "moment_bound": str(interpolation_bound)})

# A nontrivial direct continuous-density check of the special Young bound.
convolution_L5_power = sp.integrate(2*h**5, (x,0,2))
convolution_L5 = mp.mpf(str(sp.N(convolution_L5_power,60)))**(mp.mpf(1)/5)
young_rhs = rho_p_mass**(mp.mpf(6)/5)
check("continuous_convolution_Young_bound", convolution_L5 <= young_rhs,
      {"L5_convolution": str(convolution_L5), "L5over3_density_squared": str(young_rhs),
       "exact_convolution_fifth_power_integral": str(convolution_L5_power)})

# Compare the spectral difference expression with an independently
# integrated time-domain Fourier amplitude; then test the nontrivial bound.
mean_mp = sp.lambdify(duration, mean_from_sinc, "mpmath")
def amplitude_mp(t):
    if abs(t) < mp.mpf("0.0001"):
        return mp.fsum([(-1)**n*3*t**(2*n)/(mp.factorial(2*n+1)*(2*n+3))
                        for n in range(10)])
    return 3*(mp.sin(t)-t*mp.cos(t))/t**3

for horizon in (mp.mpf("0.5"),mp.mpf(2),mp.mpf(12),mp.mpf(80)):
    cutoffs = [mp.mpf(0)] + [mp.pi*n for n in range(1,int(horizon/mp.pi)+1)] + [horizon]
    direct = mp.quad(lambda t: amplitude_mp(t)**2,cutoffs)/horizon
    spectral = mean_mp(horizon)
    estimate = young_rhs*(mp.mpf(int(kernel_coefficient))/horizon)**(mp.mpf(4)/5)
    check("continuous_time_and_difference_mean_T_"+str(horizon),
          abs(direct-spectral)<mp.mpf("1e-35") and spectral <= min(mp.mpf(1),estimate),
          {"direct_time_mean":str(direct),"sinc_mean":str(spectral),"Lp_bound":str(estimate)})


# Homogeneity is checked from the separately derived moment and kernel
# formulas. bT is dimensionless; no fitted horizon or torus I0 is supplied.
I0, b, tau = sp.symbols("I0 b tau", positive=True)
K = 32768*sp.pi*I0
R = 24*I0*K**sp.Rational(2,3)*b**(-sp.Rational(2,3))
from_norms = R**sp.Rational(6,5)*(10/duration)**sp.Rational(4,5)
rate_constant = 24**sp.Rational(6,5)*(327680*sp.pi)**sp.Rational(4,5)*I0**2
check("rate_scaling_and_literal_constant",
      zero(sp.powdenest(from_norms-rate_constant*(b*duration)**(-sp.Rational(4,5)),force=True)))

print(json.dumps({"checks":checks,"python":platform.python_version(),
                  "sympy":sp.__version__,"mpmath":mp.__version__,
                  "elapsed_seconds":time.monotonic()-started,
                  "scope":"Author algebra/continuous-comparator controls; no continuum torus quadrature, independent review, or certified floating error."},sort_keys=True))
