"""Preserve baseline and actual source-copy mutant logs for the edge probe."""
from pathlib import Path
import hashlib
import json
import subprocess
import time


D = Path(__file__).resolve().parent
PY = "/opt/homebrew/opt/python@3.13/bin/python3.13"
source = (D / "edge_controls.py").read_text()


def execute(path, log):
    begin = time.monotonic()
    command = [PY, str(path)]
    with log.open("w") as out:
        try:
            cp = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT, timeout=120)
            code = cp.returncode
        except subprocess.TimeoutExpired:
            code = 124
    return {"command": command, "returncode": code, "timeout_seconds": 120,
            "elapsed_seconds": time.monotonic()-begin,
            "source": path.name, "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "log": log.name, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}


baseline = execute(D / "edge_controls.py", D / "baseline.log")
(D / "baseline_execution.json").write_text(json.dumps(baseline, indent=2)+"\n")
print(json.dumps(baseline))
assert baseline["returncode"] == 0
mutations = [
    ("drop_compression_defect", "compression_defect = Pi*B*(identity-Pi)*B*Pi",
     "compression_defect = sp.zeros(9)", "compression_square_keeps_positive_defect"),
    ("double_dressing_coefficient", "c = b2/(12*I0_fixture)",
     "c = b2/(6*I0_fixture)", "exact_cubic_dressing_coefficient"),
    ("count_one_edge", "edge_mass = sp.simplify((zeta.H*Pedge*zeta)[0])",
     "edge_mass = sp.simplify((zeta.H*Pedge*zeta)[0])/2", "two_edge_mass_and_longitudinal_coefficient"),
    ("poisson_half_constant", "poisson_majorant = delta/(2*x)",
     "poisson_majorant = delta/(4*x)", "poisson_bound_factor_two"),
    ("mean_half_coefficient", "H_coefficient = 256*sp.sqrt(sp.pi*I0)",
     "H_coefficient = 128*sp.sqrt(sp.pi*I0)", "mean_bound_optimizer_stationary"),
]
records = []
for name, old, new, assertion in mutations:
    assert source.count(old) == 1
    path = D / ("mutant_"+name+".py")
    path.write_text(source.replace(old, new))
    record = execute(path, D / ("mutant_"+name+".log"))
    record.update({"name": name, "old": old, "new": new,
                   "intended_assertion": assertion,
                   "failed_at_intended_assertion": record["returncode"] == 1 and
                       "AssertionError: "+assertion in (D / record["log"]).read_text()})
    records.append(record)
    print(json.dumps(record))
(D / "mutation_manifest.json").write_text(json.dumps(records, indent=2)+"\n")
assert all(r["failed_at_intended_assertion"] for r in records)
