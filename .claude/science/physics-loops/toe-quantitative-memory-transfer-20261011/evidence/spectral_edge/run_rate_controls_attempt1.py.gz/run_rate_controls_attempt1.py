"""Run the separate rate helper, preserving all original edge evidence."""
from pathlib import Path
import hashlib
import json
import subprocess
import time


D = Path(__file__).resolve().parent
PY = "/opt/homebrew/opt/python@3.13/bin/python3.13"
source = (D/"rate_controls.py").read_text()


def execute(path,log):
    assert not log.exists(), "Refuse to overwrite a frozen or failed log"
    began = time.monotonic()
    command = [PY,str(path)]
    with log.open("w") as out:
        try:
            cp = subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,timeout=120)
            code = cp.returncode
        except subprocess.TimeoutExpired:
            code = 124
    return {"command":command,"returncode":code,"timeout_seconds":120,
            "elapsed_seconds":time.monotonic()-began,
            "source":path.name,"source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
            "log":log.name,"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest()}


baseline = execute(D/"rate_controls.py",D/"rate_baseline.log")
(D/"rate_baseline_execution.json").write_text(json.dumps(baseline,indent=2)+"\n")
print(json.dumps(baseline))
assert baseline["returncode"] == 0
mutations = [
    ("kernel_half_constant", "kernel_coefficient = sp.Integer(10)",
     "kernel_coefficient = sp.Integer(5)","kernel_L5over4_mass_exact"),
    ("sinc_half_mean", "mean_from_sinc = 2*(h.subs(x,0)*sp.Si(2*duration)",
     "mean_from_sinc = 1*(h.subs(x,0)*sp.Si(2*duration)",
     "one_sided_sinc_mean_has_correct_derivative_and_origin"),
    ("young_half_bound", "young_rhs = rho_p_mass**(mp.mpf(6)/5)",
     "young_rhs = rho_p_mass**(mp.mpf(6)/5)/2","continuous_convolution_Young_bound"),
]
records = []
for name,old,new,assertion in mutations:
    assert source.count(old) == 1
    path = D/("rate_mutant_"+name+".py")
    assert not path.exists()
    path.write_text(source.replace(old,new))
    r = execute(path,D/("rate_mutant_"+name+".log"))
    r.update({"name":name,"old":old,"new":new,"intended_assertion":assertion,
              "failed_at_intended_assertion":r["returncode"]==1 and
                  "AssertionError: "+assertion in (D/r["log"]).read_text()})
    records.append(r)
    print(json.dumps(r))
(D/"rate_mutation_manifest.json").write_text(json.dumps(records,indent=2)+"\n")
assert all(r["failed_at_intended_assertion"] for r in records)
