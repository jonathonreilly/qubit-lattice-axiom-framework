# Spectral-edge review: reconstruction before author-helper inspection

This checkpoint was written after the complete 452-line theorem source was
read, but before opening the author receipt, helper sources, execution logs,
or mutation sources. The theorem's own evidence descriptions were visible.
It is an independent calculation from the stated operators, not a blind
rediscovery. The root coordinator supplied the L^(5/3)/T^(-4/5) idea to the
authors before this review; no independent authorship of that idea is claimed.

Target source: `EXCLUDED_WALK_SPECTRAL_EDGE_PROBE.md`, SHA-256
`e63683cdd57ad3994523732ba58b88fbbcc82be815cbde2c2320f0ff9ef3c623`.
The memory premise is `EXCLUDED_WALK_EFFECTIVE_MEMORY_PROBE.md`, SHA-256
`b667b092d202f3657493983e284ff94b5c02c929e6bc8508c691d6155865567c`.
Earlier complete readings of the unchanged memory, long-time, and degenerate
arguments are reused; the active interior-density and earlier mean estimates
E13–E26 were read again in this task. Our authorship of the older long-time
and degenerate probes is inherited-source authorship, not their independent
review here.

## Operator and domain reconstruction

1. In the odd-triplet ambient Hilbert space, real even d makes B=i[d cross]
   bounded Hermitian and parity preserving. For z in Z,
   `||Bz||^2=||Pi Bz||^2+||(1-Pi)Bz||^2`. Therefore
   `b^2||z||^2-||Az||^2=<z,(b^2-B^2)z>+||(1-Pi)Bz||^2`.
   This gives the positive sign of the compression defect directly from
   Pythagoras, independently of multiplying out S5. The complex cross-product
   identity gives `b^2-B^2=w I+d d^T`, with two nonnegative terms.
2. Scalar w preserves the pointwise orthogonality of transverse u and
   longitudinal zeta. Coordinate permutation invariance gives three equal
   integrals whose sum is one. Thus `<zeta,w zeta>=b^2/(12 I0)=c`, and the
   form bound is `C>=c |zeta><zeta|`, with normalized zeta. It does not control
   arbitrary transverse vectors by c. Odd localized transverse fields near
   the rays q=r kappa/b and their negatives give `||A||=b`; hence no bounded
   inverse of C follows. Pointwise w>0 almost everywhere for b>0 also implies
   C has no nonzero zero vector, though its inverse remains unbounded.
3. On the joint two-edge projection, z=P_delta zeta has both norm squared
   and overlap equal to m_delta. The lower bound is c m_delta^2, not c m_delta.
   The upper bound is `(2b delta-delta^2)m_delta`. Dividing only for positive
   mass gives S8 without an extra factor of two.
4. Let t_eta=<zeta,(C+eta)^(-1)zeta>. Applying the form inequality to this
   regulated vector gives `c t_eta^2<=t_eta-eta||(C+eta)^(-1)zeta||^2<=t_eta`.
   Spectral monotone convergence gives the inverse-edge moment <=1/c,
   including absence of endpoint mass. This establishes exactly the
   C^(-1/2) domain assertion. It need not put zeta in Dom C^(-1), and it does
   not produce a bounded inverse on Z.
5. For even nu, the inverse moment implies
   `integral (b-E)^(-1) dnu=b integral (b^2-E^2)^(-1)dnu`.
   The positive scalar identity
   `delta/(2x)-delta^2/(x^2+delta^2)
    =delta(x-delta)^2/[2x(x^2+delta^2)]`
   yields `4delta[-Im M(b+i delta)]<=24 I0 delta/b`.
   Endpoint absence and integrability justify x=b-E. The factor four is a
   Poisson upper bound for both equal edge masses, not an identity with mass.

## Density and mean estimate reconstruction

6. Memory E13–E23 gives absolute continuity on the open band, excludes the
   endpoint atoms, and supplies the stated compact-interior density bound.
   A countable intersection over rational delta produces one full-measure
   set. Letting delta increase to b-|E| gives S14 without an uncountable
   exceptional-set claim. Its coefficient is the inherited conservative
   `K=32768 pi I0`.
7. Multiply the two-thirds power of that envelope by rho, and use
   `1/(b-|E|)<=(2b)/(b^2-E^2)`. This gives
   `integral rho^(5/3)<=24 I0 K^(2/3)b^(-2/3)=R_b`.
   Uniform density on [-b,b] is a useful counterexample to replacing the
   inverse-moment premise by linear cumulative edge mass alone: its edge
   mass is delta/b but its inverse-edge moment diverges.
8. The three-factor Holder argument has exponents 5,5/2,5/2. Raising its
   result to the fifth power and integrating gives U^3 V^3, and hence the
   exact norm statement `||f*g||_5<=||f||_(5/3)||g||_(5/3)`.
   Positive truncations and Tonelli supply the stated general domain.
9. For the difference density h, interchange E and E' cancels the imaginary
   part of the one-sided time integral. Its real kernel is sinc(T(E-E')),
   not twice this kernel and not a nonnegative kernel. The absolute majorant
   min(1,1/(T|x|)) has whole-line L^(5/4) integral exactly 10/T. Thus
   `Q(T)<=R_b^(6/5)(10/T)^(4/5)`.
10. Substitution yields precisely
    `24^(6/5)(327680 pi)^(4/5) I0^2 (bT)^(-4/5)`.
    The two I0 powers arise as 6/5+4/5; b and T have the same -4/5 power.
    Taking min with one and converting `||u||^2=1-|a|^2` are valid for all
    T>0, b>0. The b=0 case is separately excluded as required.
11. In the old cutoff route, minimizing A chi+B chi^(-3/4), with
    A=24 I0 and B=256 sqrt(pi I0 L/tau), gives
    chi=(64 pi L/(I0 tau))^(2/7). The two terms have ratio 1:4/3, so their
    sum is 56 I0 chi and its square is 3136 I0^2 chi^2. The stated
    tau>=2^16 threshold follows from the exact rational 297/448<1.

No mathematical repair is indicated by this reconstruction. The terminal
scope prose should say the weighted/current growing-time results are outside
this edge note, rather than globally open: selected W/G conclusions already
exist elsewhere. Root agrees this is a source-scope precision issue and that
the frozen source should be preserved. No later original-walk averaged-
occupation draft has been read or used in this review.

Next: run the independent rational-compression and continuous-density
controls, then inspect the complete author receipt/helpers/logs/mutations.
