"""Independent finite/continuous comparators for the spectral-edge review.

Written before reading author helper sources. No torus discretization or
proof-by-numerics claim. All assertions use exact symbolic algebra.
"""
import itertools
import sympy as s


def check(name, assertion):
    assert assertion, name
    print("PASS", name)


# A four-dimensional diagonal ambient operator compressed using a Hadamard
# frame. This is a different fixture and basis from the author's described
# finite cubic orbit. Pythagoras, not a reused cross-product fixture, is used.
H = s.Matrix([[1, 1, 1, 1], [1, -1, 1, -1],
              [1, 1, -1, -1], [1, -1, -1, 1]]) / 2
U = H[:, :3]
q = H[:, 3]
B = s.diag(-1, -s.Rational(2, 3), s.Rational(1, 4), 1)
A = U.T * B * U
C = s.eye(3) - A * A
ambient = U.T * (s.eye(4) - B * B) * U
defect = (q.T * B * U).T * (q.T * B * U)
check("orthonormal compression frame", H.T * H == s.eye(4))
check("compression square by orthogonal decomposition", C == ambient + defect)
check("strict nonzero positive compression defect", defect.rank() == 1 and s.trace(defect) > 0)
check("omitting the defect changes the operator", C != ambient)
check("compressed C is strictly positive", all(C[:j, :j].det() > 0 for j in range(1, 4)))
zeta = s.Matrix([1, 0, 0])
inverse_moment = (zeta.T * C.inv() * zeta)[0]
csharp = 1 / inverse_moment
rankone_difference = C - csharp * zeta * zeta.T
principal_minors = [rankone_difference.extract(ix, ix).det()
                    for size in range(1, 4)
                    for ix in itertools.combinations(range(3), size)]
check("dual rank-one domination at the sharp finite constant", all(x >= 0 for x in principal_minors))
check("finite inverse-form equality at the sharp constant", s.simplify(csharp * inverse_moment) == 1)
print("DATA compression_defect_trace", s.trace(defect))
print("DATA sharp_inverse_form", inverse_moment, "constant", csharp)


# A continuous gapless multiplication example: C=x on L2(0,1), zeta=sqrt(2x).
# C >= (1/2)|zeta><zeta| follows from weighted Cauchy--Schwarz. The inverse
# square-root form is finite; the full inverse does not have zeta in its domain.
x, eta = s.symbols("x eta", positive=True)
teta = s.integrate(2 * x / (x + eta), (x, 0, 1))
check("continuous normalized dressing", s.integrate(2*x, (x, 0, 1)) == 1)
check("gapless regulated inverse form has finite limit", s.limit(teta, eta, 0, dir="+") == 2)
check("inverse square-root form is finite", s.integrate(2, (x, 0, 1)) == 2)
check("full inverse domain is not implied", s.integrate(2/x, (x, 0, 1)) == s.oo)
print("DATA regulated_continuum_form", s.simplify(teta))


# Uniform continuous density supplies an exact, different comparator for the
# one-sided average. It also separates linear edge mass from the inverse moment.
b, T = s.symbols("b T", positive=True)
E = s.symbols("E", real=True)
h = (2*b-x)/(4*b*b)  # positive half of the difference density, 0 <= x <= 2b
check("uniform difference density has unit mass", s.integrate(2*h, (x, 0, 2*b)) == 1)
check("uniform inverse-edge moment diverges", s.integrate(1/(2*b*(b*b-E*E)), (E, -b, b)) == s.oo)
rho_power = (2*b)**(-s.Rational(2, 3))
h_power = s.integrate(2*h**5, (x, 0, 2*b))
check("exact different-density Young comparison", s.simplify(h_power / rho_power**6) == s.Rational(1, 3))
Q = s.Si(2*b*T)/(b*T) + (s.cos(2*b*T)-1)/(2*b*b*T*T)
check("one-sided mean primitive", s.simplify(s.diff(T*Q, T) - (s.sin(b*T)/(b*T))**2) == 0)
check("one-sided normalization at the origin", s.limit(Q, T, 0, dir="+") == 1)
Q_spectral = 2*s.integrate(h*s.sin(T*x)/(T*x), (x, 0, 2*b))
check("spectral and time means agree exactly", s.simplify(Q_spectral-Q) == 0)
kernel_power = 2/T + 2/T**s.Rational(5, 4) * s.integrate(x**(-s.Rational(5, 4)), (x, 1/T, s.oo))
check("whole-line kernel normalization", s.simplify(kernel_power-10/T) == 0)
print("DATA uniform_mean", Q)
print("DATA whole_line_kernel_power", s.simplify(kernel_power))


# Raise the two positive symbolic constants to fifth powers to compare all
# fractional powers without branch simplifications.
I0 = s.symbols("I0", positive=True)
K = 32768*s.pi*I0
Rb = 24*I0*K**s.Rational(2, 3)*b**(-s.Rational(2, 3))
D0 = 24**s.Rational(6, 5)*(327680*s.pi)**s.Rational(4, 5)*I0**2
check("final I0 b T factors", s.simplify((Rb**s.Rational(6,5)*(10/T)**s.Rational(4,5))**5 / (D0*(b*T)**(-s.Rational(4,5)))**5) == 1)
check("old cutoff threshold arithmetic", s.Rational(64*22*18*12, 7*2**16) == s.Rational(297,448) < 1)
print("All independent exact controls completed; continuum operator arguments remain analytical.")
