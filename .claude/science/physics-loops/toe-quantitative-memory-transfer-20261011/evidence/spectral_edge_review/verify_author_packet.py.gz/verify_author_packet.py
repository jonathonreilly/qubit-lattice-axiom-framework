"""Read-only verification of the frozen author packet; writes here only."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
S = HERE.parent
D = S / 'spectral_edge'
W = S.parent / 'walk_worktree'
receipt_path = D / 'receipt.json'
assert hashlib.sha256(receipt_path.read_bytes()).hexdigest() == '7a96b9213a8c0faf014f35e4e4bcbdecd54d688bdc6b829b57d189b97fd7bec6'
r = json.loads(receipt_path.read_text())
records = []


def record(path, expected, role, data=None):
    path = str(path)
    if data is None:
        data = Path(path).read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    result = {'source': path, 'role': role, 'expected_sha256': expected,
              'actual_sha256': actual, 'bytes': len(data),
              'lines': len(data.splitlines()), 'matches': actual == expected}
    records.append(result)
    assert result['matches'], result


for x in [r['primary_source'], *r['direct_inputs'], *r['artifacts']]:
    record(x['path'], x['sha256'], 'author-listed source/artifact')
for x in r['instructions']:
    data = subprocess.check_output(['git', 'show', x['source']], cwd=W)
    record(x['source'], x['sha256'], 'author instruction identity only', data)
    if 'matching_installed_path' in x:
        record(x['matching_installed_path'], x['sha256'], 'installed author instruction identity only')
for x in r['original_files_preserved']:
    record(S/x['preserved_as'], x['sha256'], 'preserved original')
for x in [*r['successful_executions'], *r['literal_mutations']]:
    record(D/x['source'], x['source_sha256'], 'execution source')
    record(D/x['log'], x['log_sha256'], 'execution log')
failed = r['preserved_failure']
record(D/failed['preserved_source_path'], failed['source_sha256'], 'preserved syntax-failure source')
record(D/failed['log'], failed['log_sha256'], 'preserved syntax-failure log')

mutations = []
diff_text = []
for manifest, base_name in [('mutation_manifest.json', 'edge_controls.py'),
                            ('rate_mutation_manifest.json', 'rate_controls.py')]:
    base = (D/base_name).read_text()
    for m in json.loads((D/manifest).read_text()):
        observed = (D/m['source']).read_text()
        literal = base.count(m['old']) == 1 and observed == base.replace(m['old'], m['new'])
        log = (D/m['log']).read_text()
        ends_at_assertion = log.rstrip().endswith('AssertionError: '+m['intended_assertion'])
        assert literal and ends_at_assertion and m['returncode'] == 1
        mutations.append({'source': m['source'], 'base': base_name,
                          'whole_file_exact_single_substitution': literal,
                          'recorded_returncode': m['returncode'],
                          'full_log_ends_at_intended_assertion': ends_at_assertion,
                          'intended_assertion': m['intended_assertion']})
        diff_text.extend(difflib.unified_diff(base.splitlines(True), observed.splitlines(True),
                                            fromfile=base_name, tofile=m['source']))
for old, new in [('rate_controls_attempt1.py', 'rate_controls.py'),
                 ('run_rate_controls_attempt1.py', 'run_rate_controls.py')]:
    diff_text.extend(difflib.unified_diff((D/old).read_text().splitlines(True),
                                        (D/new).read_text().splitlines(True),
                                        fromfile=old, tofile=new))

inventory = [{'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
              'bytes': p.stat().st_size, 'lines': len(p.read_bytes().splitlines())}
             for p in sorted(D.iterdir()) if p.is_file()]
result = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Identity/literal-mutation verification, not independent scientific proof or execution replay.',
          'author_receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
          'records_checked': len(records), 'unique_sources_checked': len({x['source'] for x in records}),
          'mismatches': [], 'records': records, 'literal_mutations': mutations,
          'frozen_author_directory_inventory': inventory}
(HERE/'author_identity_verification.json').write_text(json.dumps(result, indent=2)+'\n')
(HERE/'author_mutation_and_repair_diffs.txt').write_text(''.join(diff_text))
print(json.dumps({key: result[key] for key in ['records_checked','unique_sources_checked','mismatches']},indent=2))
print('Verified eight exact single-change mutants and their complete failure-log endings.')
