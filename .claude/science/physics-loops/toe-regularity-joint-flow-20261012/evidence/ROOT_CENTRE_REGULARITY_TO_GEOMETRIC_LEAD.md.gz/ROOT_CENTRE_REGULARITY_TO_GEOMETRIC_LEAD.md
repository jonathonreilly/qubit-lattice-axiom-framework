# Proposed bridge from central spectral regularity to a geometric shell

Root research sketch, 2026-10-12. Not an accepted theorem or physical model.
The current nonisolated-mass author task is separate; do not silently add this
proposal to that source. A bounded derivation and independent check are needed.

The new centre-filtering argument supplies almost-local smooth central
smearings without requiring an exact point selector. Its exact point step
still requires isolation. Time-averaged creators may instead work at a
nonisolated central atom if the residual geometric detuning has a power bound.
Mass regularity alone does not supply this: preserve the current author's
off-mass/nearby-centre counterexample. The proposed bridge below keeps an
isolated Casimir mass, so a fixed joint H/K filter removes all off-mass vectors.

Supply a single compact joint lift chart with p=k-theta (one fixed integer
lift), mass energy E(k)=sqrt(M²+beta|k|²), M,beta>0, and a target atom theta0.
Use the actual direct-integral Hilbert representation on this mass component,
with vector f(p,theta) in L²(dp dnu(theta); multiplicity space). Compact
momentum support and an H1 norm in p, integrated over theta, are explicit
additional hypotheses. Equivalent smooth invariant-measure weights can be
absorbed only after their Sobolev effect has been checked. This is not inferred
from smoothness of the marginal geometric momentum measure.

For 0<r<=r0 suppose

    ||1_{0<|theta-theta0|<=r} f|| <= C r^a, a>0.

Let the target graph be Sigma(p)=E(p+theta0), and D(p,theta)=
E(p+theta)-E(p+theta0). The theta0 component is the exact graph part.
The target atom is nonzero only when the corresponding vector is nonzero.
The fixed lift/chart restriction must be enforced, not assumed away: other
lifts can have crossing energy graphs. A finite partition may handle them
separately, but no such general extension is proved by this sketch.

On a fixed convex compact momentum region containing both arguments, the
massive Hessian has a positive lower eigenvalue c. Put u=(theta-theta0)/
|theta-theta0|. Then

    partial_u D >= c |theta-theta0|.

For |theta-theta0|>=r, each line parallel to u meets {|D|<=epsilon} in an
interval of length at most 2epsilon/(cr). For Hilbert-valued H1 functions on
the line, sup ||g||² <= ||g||²_L2+||g'||²_L2 (verify the constant and
representative). Integrate over perpendicular coordinates and theta; a
theta-dependent rotation must be handled measurably or by an invariant
directional-derivative/Fubini formulation. Proposed conclusion:

    ||1_{|D|<=epsilon} 1_{|theta-theta0|>=r} f||²
       <= (2epsilon/(cr)) ||f||²_H1_p.

The near-centre and far-centre pieces are orthogonal. Thus

    ||1_{|D|<=epsilon} (1-P_theta0) f||²
       <= C² r^(2a) + (2epsilon/(cr)) ||f||²_H1_p.

Taking r=epsilon^(1/(2a+1)) within the declared scale gives a geometric
regularity exponent alpha=a/(2a+1)>0, including the exact zero detuning.
The latter removes any residual graph atom by monotone spectral continuity.
The time-averaged scattering candidate would then allow a width exponent
nu>1/(1+alpha), nu<1, if all its other direct hypotheses are supplied.

Check the full uniform constants, chart boundaries, multiplicity, zero
centres and small-scale units. The regularity of a class of almost-local
seeds and density of their target vectors must remain explicit. Ordinary
cyclic density does not imply density of seeds satisfying a quantitative
spectral rate. It may be possible to derive the H1 condition from actual
boost local-vector domains in a fixed massive finite-spin representation,
but this requires its own checked representation formula and domain argument.
No such bridge, integrated Lorentz disintegration or physical realization is
assumed established here. Root is a contributor; this sketch is not review.
