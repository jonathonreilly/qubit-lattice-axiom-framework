# Targeted tent-integral check

The author control reproduced, but replacing its tent integral by zero or
deleting its quadratic term survived all its upper-bound assertions. This is
an evidence-coverage limitation. G21 itself is correct: on 0<=t<=L, differentiating
2(t−t²/L+t³/(3L²)) gives 2(1−t/L)², with zero value at t=0. Multiplication by
3/(2L) normalizes the total mass at t=L to one.

Before running this follow-up, use exact rational Simpson integration of the
actual squared normalized tent on [0,min(t,L)] as a separate prediction.
Extract only the current author's tent_mass AST, never execute its driver.
Compare at two widths and five relative endpoints, including t=0, t=L and
t>L. The authentic function must match; both observed surviving mutants must
be rejected. This check is deliberately post-evidence and is not represented
as part of the initial blinded numerical control.
