# Reconstruction and distinct-control plan before author evidence

This is an independent source review of the frozen candidate
`CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md`, SHA-256
`9ec8c3148442f981d6b3d4d38027ffde0d2a64adbd6e4664d6a24b5d3d06608a`.
It is not a formal audit or physical realization. The reviewer has read candidate
lines 1–310, including its displayed proof, analytic control formulas, and named
counterexamples, but has not opened the current author's numerical helper,
result files, draft correction, or §10. Thus the mathematical target and author
proof are known; the control implementation and results are not. The preceding
filtering source and its review were read completely. A predecessor review's
control findings are shared context, unrelated to the new helper.

## Exact contract and dependency boundary

For one positive mass M, beta > 0, one fixed lift n0, and injective compact
coordinate charts, use actual current k = p + theta + 2 pi n0. Put
E(k) = sqrt(M² + beta |k|²), b = theta0 + 2 pi n0, q = theta − theta0,
delta = |q|, D = E(p+b+q) − E(p+b). The carrier is explicitly an isometric
spectral realization inside L²(dp dnu; F), with sigma-finite nu and separable
fixed ambient F. Its p-dependent measurable range is allowed, but Sobolev
derivatives use the given ambient trivialization. The residual f_perp excludes
the atom theta0; it has finite S_ell² = ||f_perp||² + ell² ||grad_p f_perp||².
Its central mass obeys ||1_(0<delta<=r) f|| <= C r^a for 0<r<=r0 and a>0.

The full p support is in a closed ball B_P, and both endpoint momenta for every
p in that ball and theta in the declared set lie in B_R. With E_*²=M²+beta R²,
c=beta M²/E_*³, and eps_*=c ell r0, the target is the norm bound
sqrt(C²r0^(2a)+S_ell²) (eps/eps_*)^(a/(2a+1)). It is conditional on these
hypotheses; no nonzero target atom, creator density, microscopic boost,
Poincare realization, scattering theorem, or retained status follows by itself.

The earlier filtering source is used only for I1–I4 (supplied commuting flows
and positive isolated mass), I7–I19 (fixed smooth central filtering and exact
mass filtering), I21 (lift/sign convention), and I28 (only a smooth marginal).
Its I5 central isolation is not assumed here. Exact positive mass is enough
for the analytic theorem; mass isolation explains how a fixed smooth
almost-local filter can produce that exact restriction from actual seeds.

## Reconstructed line estimate, with a different proof

The candidate's two-ended fundamental-theorem proof is correct: m=||g||² is
in W^(1,1), its integrability forces zero limits at both ends, and averaging
the two integral identities gives m(s)<=||g|| ||g'||. Young's inequality gives
m(s)<=(||g||²+ell²||g'||²)/(2ell). The example exp(-|s|/ell)v attains the
second constant, so dividing it by two is false.

A distinct derivation uses the unitary Fourier transform. For any unit v in F,
Fourier inversion and Cauchy–Schwarz with weight 1+ell²xi² give
|<v,g(s)>|² <= (1/(2pi)) integral(1+ell²xi²)^(-1) dxi
                    * integral(1+ell²xi²)||g_hat(xi)||² dxi
              = (||g||²+ell²||g'||²)/(2ell).
The weighted Cauchy–Schwarz argument first gives a continuous inverse Fourier
representative because the reciprocal weight is integrable, and extends from
smooth functions by H¹ density. Taking the supremum over unit v handles
arbitrary Hilbert multiplicity without a component-count constant. This is
an independent mathematical route to the shared load-bearing line bound.

## Measurable slicing and range issues

For delta>0, the displayed Householder R(u) is Borel, orthogonal, and satisfies
R(u)e1=u. It is allowed to be a reflection. At u=e1 its assigned value I is
valid; in d=1 it gives +1 or -1, and no z variable remains. Composing a jointly
measurable representative with (s,z,theta)->(R(u(theta))(s,z),theta) is measurable.
For every theta the orthogonal p map preserves Lebesgue measure, so Tonelli
also proves that changing the original representative on a product-null set
does not alter the pullback in L².

Approximate f_perp in L²_theta H¹_p by finite theta-simple, smooth finite-rank
p functions. Their pullbacks have weak s derivative u dot grad f. Orthogonality
and |u|=1 bound the pullback H¹_s norm by the original H¹_p norm, so the limit
belongs to L²_(z,theta) H¹_s with that derivative. This gives an a.e. slicing
statement directly, avoiding an invalid intersection of uncountably many
direction-dependent full-measure sets. Approximants need not stay in J's range:
the estimate is ambient and asserts no physical smoothing operation. H¹
inside a chart needs support strictly inside for the asserted zero extension.

## Geometry and exponent reconstruction

The Hessian has eigenvalues beta/E in transverse directions and beta M²/E³
radially. Thus D_u D = delta integral_0^1 u^T Hess E(p+b+tq)u dt >= c delta.
The convex endpoint ball contains the segment. Intersecting a u-line with
B_P gives an interval. On that interval, a |D|<=eps band has length at most
2eps/(c delta), even if the actual vector support is disconnected.

The line estimate bounds its f-mass by eps/(c delta ell) times the line H¹
energy. Integrating and using delta>r gives eps S_ell²/(c r ell). The sets
0<delta<=r and delta>r are disjoint even when nu has an atom at r, so their
squared norms add and give C²r^(2a) + eps S_ell²/(c r ell). Setting
t=eps/(c ell r0), r=r0 t^(1/(2a+1)) makes both terms proportional to
t^(2a/(2a+1)); taking a square root proves the candidate exponent. This radius
lies in (0,r0] for eps in (0,eps_*]. Zero C or S needs no optimizer; a zero
residual is harmless. No optimality claim is justified or needed. A finite
collection of creator-dependent positive exponents has a positive minimum;
this does not give a uniform countable-class bound.

Rationalizing the actual energy difference gives
D = beta(2(p+b) dot q + |q|²)/(E(p+b+q)+E(p+b)). For every q != 0 its zero
set is an affine hyperplane in p, hence dp-null. Sigma-finite product measure
allows Fubini even for singular or atomic nu. At q=0, D is identically zero.
Thus the whole chart graph projection is exactly the central atom projection,
including arbitrary multiplicity and arbitrary measurable physical ranges.
This uses G3 and the exact fixed mass/lift, but needs neither H¹ nor a central
rate. It does not assert that the projection is nonzero.

The same identity and E+E0<=2E_* put the band inside a slab
|u dot (p+b+q/2)|<=E_* eps/(beta delta). Its length yields the same argument
with kappa=beta/E_* in place of c. Kappa is an affine-slab coefficient, not a
claimed lower derivative bound. In general it is not such a derivative bound.
The 1D endpoint formula G20 follows by solving the squared equation, but its
unsquared sign and eps<sqrt(beta)delta condition remain required. At or above
that threshold, the whole line is in the band.

## Scalar boost-domain reconstruction

In the supplied scalar carrier dk/(2E) dnu with k-independent multiplicity,
write k_i=m_perp sinh t/sqrt(beta), E=m_perp cosh t. The measure in the i
direction is dt/(2sqrt(beta)). The pullback boost is psi(t-s), a full-line
translation. Under U(s)=exp(-is B), its generator is B=-i partial_t on the
usual weak-derivative domain; Fourier multiplication by frequency gives both
self-adjointness and the full domain without a boundary/core inference.
The smooth coordinate change gives B=-i E partial_(k_i)/sqrt(beta).

Flattening by f=(2E)^(-1/2)psi gives
partial_i f = i sqrt(beta)/E J_w B_i psi − beta k_i/(2E²) f.
The second term is the derivative of the invariant-measure density and cannot
be dropped. The Euclidean multiplier sup beta|k|/(2E²)=sqrt(beta)/(4M) occurs
at |k|=M/sqrt(beta); E>=M bounds the first term. Vector-valued triangle and
Cauchy–Schwarz give G30, with no extra dimension factor. Smooth chart cutoffs
then preserve H¹, and k=p+theta+2pi n0 gives exactly partial_p=partial_k.

Compact smooth k functions tensored with measurable multiplicity sections are
dense in this explicit carrier and lie in every boost domain. Central point
projection commutes with all these explicit boosts. This proves abstract
domain density only. It proves neither that local/almost-local vacuum columns
have these domains nor their central rate or density after imposing both.
The finite-spin sentence is conditional on a separately checked distributional
connection formula and a bounded connection on the actual compact chart.

## Hypothesis-deletion witnesses and the density correction

1. Smooth p marginal: support theta=-2p with p in (1/4,1/3), M=beta=1 gives
   k=-p and D=0 away from theta0=0. Every fixed-theta p slice of the diagonal
   is null, so the graph is product-null for any sigma-finite nu. It cannot
   fit G3. Adding a target atom does not repair the off-atom witness.
2. H¹ without central rate: weights 1/[n(n+1)], theta_n=exp(-n), and one fixed
   smooth g give finite total H¹. Lipschitz E puts the n>=N tail in eps=exp(-N),
   with exact squared norm 1/N. This defeats every positive power and fails G5.
3. Central rate without H¹: theta_n=1+1/n, tent width exp(-n²), and the same
   weights give a central gap. The entire n>=N tail fits eps=2exp(-N²), again
   with squared norm 1/N; normalized tent derivative energy is 3/w_n², whose
   weighted sum diverges. Exact residual D=0 still has zero measure.
4. Omitted exact mass restriction: m(p)²=3−2p and k=p+1 give E²=4+p² while
   the central character is 1. The target Casimir 4 can be an isolated added
   summand, but the off-mass vector is not in it. I19 removes it.
5. Omitted fixed lift: at theta=0 the n=1 branch differs in squared energy
   from the n0=0 graph by 4pi p+4pi². A target central vector can miss that
   selected graph. This challenges G18's global extension, not G16's residual.
6. Omitted regular gauge formula: conjugation by exp(i/k1) preserves abstract
   boost-domain membership under the conjugated representation, but creates
   a non-L² derivative proportional to k1^(-2) for a vector nonzero near zero.
   It does not refute the smooth scalar gauge in G25–G30.
7. Arbitrary p-dependent range: let the non-target fibre be scalar L² on a
   positive-measure closed nowhere-dense set C in a compact interval. An
   ambient H¹ section has a continuous representative and vanishes on the
   dense open complement, hence is identically zero. Thus ambient smoothing
   cannot supply regular-section existence or density in every physical range.
   At the target atom only residual H¹ is required, so this example is applied
   to an off-atom fibre; it does not claim every target vector must be H¹.

In the full ambient carrier and in G25, p-independent fibres permit dense
smooth p approximations followed by theta cutoffs away from theta0. In an
arbitrary p-dependent range this approximation can leave the range. Even
where abstract density holds, it is not an operator-level creator construction.
Ordinary cyclicity of all local A Omega has no assertion that the restricted
rate/domain class projects densely onto the target atom. The final candidate
appears to state this corrected distinction; the preserved draft must be
compared after this freeze. These spectral witnesses are not microscopic
finite-range countermodels, and no universal obstruction is inferred.

## Distinct controls fixed before reading the author helper or outputs

All executions will have declared timeouts and stdout/stderr/receipt files.
No numerical experiment is used to prove a general rate, Fubini assertion,
density, or infinite-volume realization.

1. **Two-dimensional band mass from direct dispersion:** independently code
   bisection on E(k+q)−E(k), in direction u=q/|q| with nonzero transverse
   offsets and mixed-sign q. Use compact radial polynomial amplitude
   h(p)=(1−|p|²/L²)_+², with two orthogonal Hilbert components h and
   lambda exp(i omega dot p)h. Integrate its polynomial squared density in
   the line coordinate, and integrate the transverse coordinate by adaptive
   quadrature. Its exact norms are N=pi L²/5 and G=4pi/3 per base component;
   the phase adds lambda²|omega|²N. Compare computed masses to G14/G15/G16
   and the affine-slab bound using explicit finite central atoms. Direct
   endpoint finding will not call the author's G20/tent code. Vary tolerances
   or resolution once to expose numerical error. No fitted exponent.
2. **Actual flat boost action:** finite-difference the flat-measure unitary
   pullback sqrt(E(Phi(-s)k)/E(k)) f(Phi(-s)k) on a complex Gaussian-polynomial
   test function in d=2. Compare its generator with the derivative/measure
   formula. Require second-order convergence over four step sizes. The
   omitted measure term and wrong sign must leave an error plateau.
3. **Decisive exact/analytic controls:** Fourier proof above of the sharp
   line coefficient; exact telescoping tails and divergent derivative sums
   for the two sequence witnesses; diagonal product-null proof; fat-set
   no-H¹ proof; fixed lift and off-mass polynomial identities. Check the
   wrong high Hessian bound on an explicit radial point. Distinguish kappa's
   valid slab role from an invalid derivative-bound substitution.
4. **Author evidence later:** inspect the complete helper, all reported
   corrections/failures and the initial draft. Replay its current helper in
   the reviewer directory, with the same frozen candidate dependency and
   a bounded timeout. On reviewer-owned copies, perturb selected scientific
   expressions to see which assertions catch genuine defects. Any surviving
   mutation limits evidence coverage; it is not silently called successful.

## Recovery and verification limits at freeze

Initial 157-file binding validation had zero mismatches. The two self-binding
freeze files and eight post-freeze log artifacts are separately inventoried
as unlisted in `logs/initial_binding_inventory.json`. A combined display was
truncated during intake; complete candidate argument and predecessor source
were re-read in bounded calls, and the failure is preserved in `FAILURES.md`.
No author numerical result has been used for this reconstruction. No Git
command, publication, audit verdict, model/effort override, or subdelegation
has been performed. Local installed reviewer/workhorse/proof references match
the local repository bytes. No live remote freshness verification was possible
within the explicit no-Git assignment. Planning is the named frozen snapshot.
