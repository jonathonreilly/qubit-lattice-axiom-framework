#!/usr/bin/env python3
"""Independent direct-dispersion and actual-pullback checks; stdlib only.

No imports from the author helper, no G20 endpoint formula and no tent basis.
Finite numerical controls supplement, rather than prove, the reconstruction.
"""
import cmath
import json
import math
import sys


def dot(x, y):
    return sum(a*b for a, b in zip(x, y))


def energy(k, mass, beta):
    return math.sqrt(mass*mass + beta*dot(k, k))


def adaptive_simpson(fun, lo, hi, tolerance, depth=22):
    """Adaptive quadrature with an error estimate, not interval certification."""
    calls = 0

    def ev(x):
        nonlocal calls
        calls += 1
        return fun(x)

    def rec(a, b, fa, fm, fb, old, tol, remaining):
        m = (a+b)/2
        fl, fr = ev((a+m)/2), ev((m+b)/2)
        left = (m-a)*(fa+4*fl+fm)/6
        right = (b-m)*(fm+4*fr+fb)/6
        change = left+right-old
        if abs(change) <= 15*tol:
            return left+right+change/15, abs(change)/15
        if remaining <= 0:
            raise RuntimeError('adaptive Simpson exhausted its depth')
        lv, le = rec(a, m, fa, fl, fm, left, tol/2, remaining-1)
        rv, re = rec(m, b, fm, fr, fb, right, tol/2, remaining-1)
        return lv+rv, le+re

    fa, fm, fb = ev(lo), ev((lo+hi)/2), ev(hi)
    val, err = rec(lo, hi, fa, fm, fb, (hi-lo)*(fa+4*fm+fb)/6,
                   tolerance, depth)
    return val, err, calls


def band_mass(q, eps, mass, beta, radius, b, tolerance):
    delta = math.sqrt(dot(q, q))
    u = tuple(t/delta for t in q)
    transverse = (-u[1], u[0])
    largest_width = 0.0

    def difference(s, z):
        k0 = tuple(b[i]+s*u[i]+z*transverse[i] for i in range(2))
        k1 = tuple(k0[i]+q[i] for i in range(2))
        return energy(k1, mass, beta)-energy(k0, mass, beta)

    def crossing(target, low, high, z):
        if difference(low, z) >= target:
            return low
        if difference(high, z) <= target:
            return high
        for _ in range(70):
            middle = (low+high)/2
            if difference(middle, z) < target:
                low = middle
            else:
                high = middle
        return (low+high)/2

    def primitive(s, z):
        a = max(0.0, 1-z*z/(radius*radius))
        return sum(math.comb(4, j)*a**(4-j)*(-1)**j
                   * s**(2*j+1)/((2*j+1)*radius**(2*j))
                   for j in range(5))

    def transformed_integrand(phi):
        nonlocal largest_width
        z = radius*math.sin(phi)
        extent = max(0.0, radius*math.cos(phi))
        left = crossing(-eps, -extent, extent, z)
        right = crossing(eps, -extent, extent, z)
        largest_width = max(largest_width, right-left)
        return max(0.0, primitive(right, z)-primitive(left, z))*extent

    val, err, calls = adaptive_simpson(transformed_integrand,
                                     -math.pi/2, math.pi/2, tolerance)
    return val, err, calls, largest_width


def geometry_control():
    mass, beta, radius, ell = 1.4, 0.7, 0.6, 0.23
    b = (0.14, -0.21)
    central = [((0.30, 0.15), 0.50), ((-0.23, 0.41), 0.30),
               ((0.60, -0.20), 0.20)]
    lam, omega, exponent, r0 = 0.6, (1.1, -0.7), 0.75, 0.8
    hilbert_factor = 1+lam*lam
    nbase, gradbase = math.pi*radius*radius/5, 4*math.pi/3
    norm2 = hilbert_factor*nbase
    sob2 = hilbert_factor*(nbase+ell*ell*gradbase) + lam*lam*ell*ell*dot(omega, omega)*nbase
    R = radius+max([math.sqrt(dot(b, b))] +
                   [math.sqrt(sum((b[i]+q[i])**2 for i in range(2))) for q, w in central])
    emax = energy((R, 0), mass, beta)
    c, kappa = beta*mass*mass/emax**3, beta/emax
    epsstar = c*ell*r0
    ordered = sorted((math.sqrt(dot(q, q)), w) for q, w in central)
    prefix = 0
    constant = 0
    for delta, weight in ordered:
        prefix += weight*norm2
        if delta <= r0:
            constant = max(constant, math.sqrt(prefix)/delta**exponent)
    split = ordered[0][0]/2
    records = []
    for eps in [0.003, 0.0003, 0.00003]:
        assert eps <= epsstar
        totals = []
        per_atom = []
        for tol in [2e-9, 1e-10]:
            total = 0
            for q, weight in central:
                val, err, calls, width = band_mass(q, eps, mass, beta,
                                                  radius, b, tol)
                delta = math.sqrt(dot(q, q))
                slab_width = 2*emax*eps/(beta*delta)
                assert width <= slab_width*(1+1e-8)+1e-12
                total += weight*hilbert_factor*val
                if tol == 1e-10:
                    per_atom.append({'q': q, 'mass2_before_weight': val,
                                     'quadrature_estimated_error': err,
                                     'calls': calls,
                                     'max_line_width_over_slab': width/slab_width})
            totals.append(total)
        assert abs(totals[1]-totals[0]) < 2e-8
        far_bound = eps*sob2/(c*split*ell)
        slab_bound = eps*sob2/(kappa*split*ell)
        final_bound = (constant*constant*r0**(2*exponent)+sob2)*(eps/epsstar)**(2*exponent/(2*exponent+1))
        assert 0 < totals[1] < min(far_bound, slab_bound, final_bound, norm2)
        records.append({'eps': eps, 'band_norm_squared': totals[1],
                        'refinement_difference': totals[1]-totals[0],
                        'G14_bound_squared': far_bound,
                        'affine_bound_squared': slab_bound,
                        'G16_bound_squared': final_bound, 'atoms': per_atom})
    all_mass = band_mass(central[0][0], 10, mass, beta, radius, b, 1e-11)
    assert abs(all_mass[0]-nbase) < 1e-9
    return {'name': 'direct_2d_dispersion_band', 'parameters': {
        'M': mass, 'beta': beta, 'radius': radius, 'ell': ell, 'b': b,
        'central_atoms': central, 'hilbert_components': 2, 'lambda': lam,
        'omega': omega, 'a': exponent, 'r0': r0, 'C': constant,
        'R': R, 'c': c, 'kappa': kappa, 'S_ell_squared': sob2},
        'base_full_mass_error': all_mass[0]-nbase, 'records': records}


def flat_function(k):
    poly = 1+0.2j*k[0]+0.15*k[1]
    return poly*math.exp(-0.7*k[0]**2-1.1*k[1]**2)


def flat_derivative(k, i):
    poly = 1+0.2j*k[0]+0.15*k[1]
    return ((0.2j if i == 0 else 0.15)-(1.4 if i == 0 else 2.2)*k[i]*poly)*math.exp(-0.7*k[0]**2-1.1*k[1]**2)


def boost_action(k, s, i, mass, beta):
    olde = energy(k, mass, beta)
    kp = list(k)
    kp[i] = k[i]*math.cosh(s)-olde*math.sinh(s)/math.sqrt(beta)
    return math.sqrt(energy(kp, mass, beta)/olde)*flat_function(kp)


def boost_control():
    mass, beta = 1.7, 0.6
    points = [(0.4, -0.8), (-1.1, 0.3), (0, 0), (1.5, 0.7)]
    records = []
    for step in [0.04, 0.02, 0.01, 0.005]:
        exact_error, omitted_error, sign_error = 0.0, 0.0, 0.0
        for k in points:
            en = energy(k, mass, beta)
            for i in range(2):
                observed = 1j*(boost_action(k, step, i, mass, beta)-boost_action(k, -step, i, mass, beta))/(2*step)
                transport = -1j*en/math.sqrt(beta)*flat_derivative(k, i)
                exact = transport-1j*math.sqrt(beta)*k[i]/(2*en)*flat_function(k)
                exact_error += abs(observed-exact)**2
                omitted_error += abs(observed-transport)**2
                sign_error += abs(observed+exact)**2
        records.append({'step': step, 'correct_error': math.sqrt(exact_error),
                        'omit_measure_error': math.sqrt(omitted_error),
                        'wrong_sign_error': math.sqrt(sign_error)})
    ratios = [records[i]['correct_error']/records[i+1]['correct_error'] for i in range(3)]
    assert all(3.5 < ratio < 4.5 for ratio in ratios)
    assert records[-1]['correct_error'] < 0.001
    assert records[-1]['omit_measure_error'] > 0.001
    assert 0.8 < records[-2]['omit_measure_error']/records[-1]['omit_measure_error'] < 1.25
    assert records[-1]['wrong_sign_error'] > 0.1
    return {'name': 'flat_boost_pullback_finite_difference', 'parameters': {
        'M': mass, 'beta': beta, 'points': points}, 'records': records,
        'second_order_error_ratios': ratios}


def exact_controls():
    mass = beta = 1.0
    k0, q, R = 4.0, 0.1, 5.0
    derivative = (k0+q)/energy((k0+q,), mass, beta)-k0/energy((k0,), mass, beta)
    c = beta*mass*mass/energy((R,), mass, beta)**3
    kappa = beta/energy((R,), mass, beta)
    slope = derivative/q
    assert c < slope < kappa < beta/mass
    # Exact series identities are proved in the reconstruction, not by truncation.
    tail_examples = [{'N': n, 'tail2': 1/n, 'log_eps_h1': -n,
                      'log_eps_tent': math.log(2)-n*n} for n in [5, 20, 80]]
    return {'name': 'analytic_mutation_witnesses',
            'radial_secant_derivative_per_delta': slope,
            'valid_hessian_lower_bound': c,
            'slab_kappa_not_a_derivative_lower_bound': kappa,
            'invalid_upper_eigenvalue_substitution': beta/mass,
            'sharp_line_at_ell_1': {'sup_squared': 1, 'H1_squared': 2,
                                    'correct_bound': 1, 'halved_coefficient_bound': 0.5},
            'sequence_tail_examples': tail_examples,
            'scope': 'Finite controls; analytic proofs give the infinite and null-set claims.'}


if __name__ == '__main__':
    for control in [geometry_control, boost_control, exact_controls]:
        print(json.dumps(control(), sort_keys=True), flush=True)
