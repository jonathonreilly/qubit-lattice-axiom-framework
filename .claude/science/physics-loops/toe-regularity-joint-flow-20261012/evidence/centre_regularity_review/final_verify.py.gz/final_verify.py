#!/usr/bin/env python3
from pathlib import Path
import datetime
import hashlib
import json
import platform
import re
import sys

root = Path(__file__).resolve().parent
parent = root.parent
author = parent/'centre_regularity_to_geometric'
report = parent/'CENTRE_REGULARITY_TO_GEOMETRIC_REVIEW.md'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = json.loads((author/'FREEZE_MANIFEST.json').read_text())
errors = []
for entry in manifest['files']:
    p = Path(entry['path'])
    if not p.exists() or sha(p) != entry['sha256'] or p.stat().st_size != entry['bytes']:
        errors.append({'kind':'author_binding','path':str(p)})
initial = json.loads((root/'logs/initial_binding_inventory.json').read_text())
listed = {x['path'] for x in manifest['files']}
now_unlisted = {str(p) for p in author.rglob('*') if p.is_file()} - listed
before_unlisted = {e['path']:e for e in initial['unlisted_in_author_directory']}
if now_unlisted != set(before_unlisted):
    errors.append({'kind':'changed_unlisted_inventory','new':sorted(now_unlisted-set(before_unlisted)),
                   'removed':sorted(set(before_unlisted)-now_unlisted)})
closing = []
for path in sorted(now_unlisted):
    p = Path(path)
    closing.append({'path':path,'sha256':sha(p),'bytes':p.stat().st_size})
    if path in before_unlisted and sha(p) != before_unlisted[path]['sha256']:
        errors.append({'kind':'closing_file_changed','path':path})
coverage = json.loads((root/'READ_INPUTS_FINAL.json').read_text())
for entry in coverage['initial_inputs'] + coverage['after_freeze_inputs']:
    p = Path(entry['path'])
    if not p.exists() or sha(p) != entry['sha256']:
        errors.append({'kind':'read_input_changed','path':str(p)})
preregistered = json.loads((root/'PREREGISTERED_FREEZE.json').read_text())
for entry in preregistered['files']:
    if sha(entry['path']) != entry['sha256']:
        errors.append({'kind':'preregistered_file_changed','path':entry['path']})
for entry in json.loads((root/'POST_EVIDENCE_CONTROL_FREEZE.json').read_text())['files']:
    if sha(entry['path']) != entry['sha256']:
        errors.append({'kind':'post_evidence_contract_changed','path':entry['path']})
assert len((parent/'CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md').read_text().splitlines()) == 325
assert (root/'logs/author_control_replay.stdout').read_bytes() == (author/'logs/analytic_control_frozen_candidate.stdout').read_bytes()
for name in ['independent_controls_initial','author_control_replay','author_mutation_study','tent_integral_control']:
    r = json.loads((root/'logs'/f'{name}.receipt.json').read_text())
    assert r['returncode'] == 0 and not r['timed_out']
    assert r['stdout_sha256'] == sha(root/'logs'/f'{name}.stdout')
    assert r['stderr_sha256'] == sha(root/'logs'/f'{name}.stderr')
author_receipts = list((author/'logs').glob('*.receipt.json'))
for p in author_receipts:
    r = json.loads(p.read_text())
    assert r['exit_code'] == 0 and not r['timed_out']
for target in re.findall(r'\]\((/[^)]+)\)', report.read_text()):
    p = Path(re.sub(r':\d+$', '', target))
    if not p.exists():
        errors.append({'kind':'report_link_missing','path':str(p)})
data = {'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'candidate_sha256':sha(parent/'CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md'),
        'author_receipt_sha256':sha(author/'FREEZE_RECEIPT.json'),
        'manifest_sha256':sha(author/'FREEZE_MANIFEST.json'),
        'report_sha256':sha(report),'author_bound_files_checked':len(manifest['files']),
        'unlisted_author_closing_files':closing,
        'read_input_records_checked':len(coverage['initial_inputs'])+len(coverage['after_freeze_inputs']),
        'successful_author_execution_receipts':len(author_receipts),
        'python_executable':sys.executable,'python_version':sys.version,
        'platform':platform.platform(),'errors':errors,
        'limit':'No Git command or remote ref check; local source hashes are the reviewed identity.'}
(root/'logs/final_integrity.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ['unlisted_author_closing_files']},indent=2))
if errors:
    raise SystemExit(1)
