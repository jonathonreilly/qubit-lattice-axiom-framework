#!/usr/bin/env python3
"""Selected scientific-expression mutations on reviewer-owned source copies."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
author = root.parent/'centre_regularity_to_geometric/analytic_control.py'
base = author.read_text()
assert hashlib.sha256(base.encode()).hexdigest() == 'b0623963415f4b0ad04b035832c5be793404eb885933c9150cd58133dcc4fbfb'
out = root/'mutations'
out.mkdir(exist_ok=True)
cases = [
    ('endpoint_beta_missing',
     'return (e*e*(m*m+b*q*q/4-e*e/4)/(b*(b*q*q-e*e))).sqrt()',
     'return (e*e*(m*m+b*q*q/4-e*e/4)/(b*q*q-e*e)).sqrt()'),
    ('endpoint_sign_wrong',
     'return (e*e*(m*m+b*q*q/4-e*e/4)/(b*(b*q*q-e*e))).sqrt()',
     'return (e*e*(m*m+b*q*q/4+e*e/4)/(b*(b*q*q-e*e))).sqrt()'),
    ('householder_factor_missing',
     '2*v[i]*v[j]/vv if vv else 0',
     'v[i]*v[j]/vv if vv else 0'),
    ('invariant_weight_removed',
     'def flat_weight(k):return (2*(1+k*k).sqrt()).sqrt()**(-1)',
     'def flat_weight(k):return D(1)'),
    ('lift_removed',
     'def lifted_energy_squared(m,b,p,theta,n):return m*m+b*(p+theta+2*math.pi*n)**2',
     'def lifted_energy_squared(m,b,p,theta,n):return m*m+b*(p+theta)**2'),
    ('offmass_identity_sign_wrong',
     'offmass=3-2*p', 'offmass=3+2*p'),
    ('tent_mass_zero',
     'return (3/(2*L))*2*(t-t*t/L+t*t*t/(3*L*L))',
     'return D(0)'),
    ('tent_quadratic_term_missing',
     'return (3/(2*L))*2*(t-t*t/L+t*t*t/(3*L*L))',
     'return (3/(2*L))*2*(t+t*t*t/(3*L*L))'),
]
results = []
for name, old, new in cases:
    assert base.count(old) == 1, (name, base.count(old))
    mutated = base.replace(old, new)
    path = out/(name+'.py')
    path.write_text(mutated)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    timed_out = False
    try:
        run = subprocess.run([sys.executable, str(path)], cwd=root,
                             stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=20)
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b'', exc.stderr or b'', None
        timed_out = True
    (out/(name+'.stdout')).write_bytes(stdout)
    (out/(name+'.stderr')).write_bytes(stderr)
    record = {'name':name,'old':old,'new':new,'source_path':str(path),
              'source_sha256':hashlib.sha256(mutated.encode()).hexdigest(),
              'started_utc':start,'elapsed_seconds':time.monotonic()-begin,
              'timeout_seconds':20,'timed_out':timed_out,'returncode':code,
              'outcome':'timeout' if timed_out else ('rejected' if code else 'survived'),
              'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
              'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
              'stderr':stderr.decode()}
    (out/(name+'.receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
    results.append(record)
    print(json.dumps({'name':name,'outcome':record['outcome'],'returncode':code,
                      'stderr':record['stderr']},sort_keys=True),flush=True)
(root/'MUTATION_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
