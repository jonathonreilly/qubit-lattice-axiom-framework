#!/usr/bin/env python3
"""Execute a bounded command and retain complete evidence in this review dir."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import subprocess
import time

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--timeout', type=float, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic()
timed_out = False
try:
    result = subprocess.run(command, cwd=root, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=args.timeout)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as exc:
    stdout, stderr, code = exc.stdout or b'', exc.stderr or b'', None
    timed_out = True
prefix = root/'logs'/args.label
prefix.with_suffix('.stdout').write_bytes(stdout)
prefix.with_suffix('.stderr').write_bytes(stderr)
receipt = {'started_utc': stamp, 'elapsed_seconds': time.monotonic()-begin,
           'command': command, 'cwd': str(root), 'timeout_seconds': args.timeout,
           'timed_out': timed_out, 'returncode': code,
           'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr),
           'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
           'command_input_hashes': {str(Path(x).resolve()): hashlib.sha256(Path(x).read_bytes()).hexdigest()
                                    for x in command if Path(x).is_file()}}
prefix.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(code if code is not None else 124)
