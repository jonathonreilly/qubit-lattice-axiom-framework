#!/usr/bin/env python3
"""Post-evidence targeted check of the tent integral and surviving mutants.

The expected mass comes from exact Simpson integration of the actual squared
linear tent. Only the isolated function AST is executed; no author driver or
expected value is imported. Simpson is exact here because the integrand is a
quadratic polynomial on [0,min(t,L)].
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import ast
import hashlib
import json

root = Path(__file__).resolve().parent
paths = [root.parent/'centre_regularity_to_geometric/analytic_control.py',
         root/'mutations/tent_mass_zero.py',
         root/'mutations/tent_quadratic_term_missing.py']
rows = []
for path in paths:
    source = path.read_text()
    tree = ast.parse(source)
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'tent_mass']
    assert len(nodes) == 1
    isolated = ast.Module(body=nodes, type_ignores=[])
    namespace = {'__builtins__': {'min': min}, 'D': Decimal}
    exec(compile(isolated, str(path), 'exec'), namespace)
    function = namespace['tent_mass']
    mismatches = []
    for width in [F(1, 2), F(3, 4)]:
        for ratio in [F(0), F(1, 7), F(1, 3), F(1), F(2)]:
            endpoint = ratio*width
            t = min(endpoint, width)
            density = lambda x: (1-x/width)**2
            direct = F(3, width)*t/F(6)*(density(0)+4*density(t/2)+density(t))
            actual = function(endpoint, width)
            if actual != direct:
                mismatches.append({'width':str(width),'endpoint':str(endpoint),
                                   'reported':str(actual),'direct_integral':str(direct)})
    rows.append({'path':str(path),'sha256':hashlib.sha256(source.encode()).hexdigest(),
                 'mismatches':mismatches,'outcome':'rejected' if mismatches else 'matched',
                 'exact_cases':10})
assert rows[0]['outcome'] == 'matched'
assert all(row['outcome'] == 'rejected' for row in rows[1:])
for row in rows:
    print(json.dumps(row,sort_keys=True))
