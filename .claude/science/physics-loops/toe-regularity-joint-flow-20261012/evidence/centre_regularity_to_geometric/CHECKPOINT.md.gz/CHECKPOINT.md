# Current recovery checkpoint

Updated UTC: 2026-10-12T03:26:23.612830+00:00
Status: conditional-support author proof complete; ready for root's independent source review. No audit verdict or retained-status claim.
Candidate: /Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011/CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md
Candidate SHA-256: 9ec8c3148442f981d6b3d4d38027ffde0d2a64adbd6e4664d6a24b5d3d06608a
Deadline: 2026-10-12 16:00:52 UTC.

Result: G14-G16 prove the proposed alpha=a/(2a+1) bound under a fixed positive isolated mass, fixed lift, supplied joint dp dnu representation with declared ambient trivialization, residual momentum H1, and central L2 rate. The line constant improves the sketch by two. G17-G19 give a distinct affine-slab derivation with stronger constant beta/E_* and an exact zero-detuning projection identity on the declared chart. G25-G30 derive H1 from actual boost domains in an explicitly supplied scalar massive representation, including full-line rapidity and invariant-to-flat measure derivatives.

Application obligations stay explicit: actual joint representation, regularity and central rate of almost-local seed vacuum columns, and target-vector density. No physical model or nonisolated-mass author result is consumed. No finite-spin representation formula is silently inferred. Only the assigned note and this directory were written. Root is sole Git/publication writer; no subdelegation.

Frozen prerequisites: probe 1dcb9580d128d8fc41b76517ce0fe18842291e8e32681fa9c6b22f0feb1e13de; review 68ea0c2f00d0808ce5a6a63632b0bc84a05398260478510fb4f66256e885cbc9; root sketch e03a75616f2341b7b9d2f332f40bf05d6d4486787e0d558818b550af8aed3266. Complete source reads and 19 matching input bindings in SOURCE_LEDGER.json. Local main a13caa4885f547c8d206265b031ba7649e539fd9; planning 3a4b2c66a1ead7a1c48b4359627e968f681e3c39. Shared checkout advanced f6f4348151734908dea3b32048ee1f36f694035b -> dc7f415f73df3754653f4985382ca0fb96f07cda. Complete change inventory preserved; no bound repository path changed. No refs fetched or written.

Final control: timeout 60.0 s, exit 0, elapsed 0.077857375 s; all full stdout/stderr in logs/analytic_control_frozen_candidate.*. Four compact tent band cases satisfy both bounds; three original-energy root comparisons agree within 2.71521e-70 (fixed 1e-60 tolerance); eight deliberate formula/premise defects rejected; exact rational exponent/rotation controls included. These are author controls, not independent proof review.

Preserved failures: bootstrap argument-order error before any source read; initial broad discovery display truncated and not scientific evidence; author draft overclaimed abstract H1 density for a general momentum-dependent range, corrected after a concrete empty-interior-support witness. Original draft and prior controls retained in archive/. No mathematical control baseline failure or timeout.

Six explicit shortcut witnesses remain in the note: smooth marginal versus joint measure; H1 without central rate; central rate without H1; omitted exact mass selection; lift merging; arbitrary measurable gauge/domain mismatch. These have spectral scope only. No universal no-go packet PASS is claimed.

Next action: root arranges independent source review of the frozen candidate and its exact receipt. If a reviewer requests corrections, preserve this freeze and edit a new candidate revision; do not overwrite evidence or infer an audit verdict. Read original §§2-7 for mathematical reuse; this checkpoint cannot replace those arguments.
