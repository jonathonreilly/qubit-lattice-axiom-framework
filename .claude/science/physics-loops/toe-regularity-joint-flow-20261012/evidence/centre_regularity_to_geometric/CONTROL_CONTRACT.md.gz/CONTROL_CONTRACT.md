# Analytic and finite control contract — frozen before implementation

The main proof will use Hessian transversality and line Sobolev slicing. The distinct control uses the exact massive squared-energy equation, never the Hessian lower bound to predict shell endpoints. For d=1, beta,M,delta>0, x=p+delta/2, solve |E(x+delta/2)-E(x-delta/2)|=epsilon independently as
x_epsilon^2 = epsilon^2 (M^2+beta delta^2/4-epsilon^2/4) / (beta (beta delta^2-epsilon^2)), epsilon<sqrt(beta)delta.
Integrate the normalized tent profile explicitly over this interval; compare with the proven bounds at declared compact support and Sobolev scale. Include multiple rational parameter sets, finite central atoms, and a nontrivial two-component vector multiplicity whose norm is computed explicitly.

Exact rational controls: squared-energy difference, the endpoint polynomial equation, central near/far exponent balancing (rational exponents with integer powers), torus-lift misidentification and off-mass wrong-filter witness. Floating values only display evaluations; exact fractions decide algebraic controls.

Deliberate defects must be caught by an explicit witnessed inequality or identity: omit the 2 in the squared-energy cross term; omit beta; pretend the upper Hessian value beta/M is a uniform lower value; lose the factor 2 in whole-line Sobolev endpoint accounting; equate smooth marginal Q density with joint dp dnu domination; omit mass restriction; merge different lifts at the target atom; omit invariant-measure derivative term in boost conversion. Additional analytic sequence witnesses check loss of central rate or H1 without claiming a microscopic countermodel.

No fitted constants or asserted PASS quota. A failed baseline is preserved and repaired only after identifying its cause. Finite checks do not certify the general Sobolev/domain argument. The final note must state exact scope, all failures and whether each planted defect was actually detected.
