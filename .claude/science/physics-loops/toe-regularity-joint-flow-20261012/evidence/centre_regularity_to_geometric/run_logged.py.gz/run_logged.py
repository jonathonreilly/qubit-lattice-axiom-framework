from pathlib import Path
import argparse,datetime,json,subprocess,time,hashlib,sys,traceback
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--timeout',type=float,default=60);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
root=Path(__file__).resolve().parent; logs=root/'logs';logs.mkdir(exist_ok=True)
stdin=sys.stdin.buffer.read() if a.command and a.command[-1]=='-' else None
if stdin is not None:(logs/(a.name+'.stdin')).write_bytes(stdin)
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic(); timed_out=False
try:
 r=subprocess.run(a.command,input=stdin,capture_output=True,timeout=a.timeout);out=r.stdout;err=r.stderr;code=r.returncode
except subprocess.TimeoutExpired as e:
 out=e.stdout or b'';err=e.stderr or b'';code=None;timed_out=True
except OSError:
 out=b'';err=traceback.format_exc().encode();code=127
end=datetime.datetime.now(datetime.timezone.utc).isoformat();duration=time.monotonic()-t
(logs/(a.name+'.stdout')).write_bytes(out);(logs/(a.name+'.stderr')).write_bytes(err)
receipt={'name':a.name,'argv':a.command,'cwd':str(Path.cwd()),'start_utc':start,'end_utc':end,'elapsed_seconds':duration,'timeout_seconds':a.timeout,'timed_out':timed_out,'exit_code':code,'stdout_bytes':len(out),'stderr_bytes':len(err),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()}
(logs/(a.name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print(out.decode(errors='replace'));print(err.decode(errors='replace'))
raise SystemExit(code if code is not None else 124)
