"""Close/stage exact publication; no commit or PR mutation."""
from pathlib import Path
from urllib.parse import unquote
from datetime import datetime, timezone
import ast, gzip, hashlib, json, os, re, subprocess, sys
S=Path(__file__).resolve().parent; W=S.parent/'scattering_worktree'
P=W/'.claude/science/physics-loops/toe-regularity-joint-flow-20261012'
V=S/'regularity_joint_verification_preparation/runs/20261012T065248-de62ea0d'
REC=S/'regularity_joint_delivery_recovery'; BASE='dc7f415f73df3754653f4985382ca0fb96f07cda'
sha=lambda b:hashlib.sha256(b).hexdigest(); js=lambda p:json.loads(p.read_text())
os.chdir(W);sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'scripts'));import runner_cache
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
state=js(V/'STATE.json');assert state['status']==state['stage']=='completed'
mapping=js(P/'PUBLICATION_EDITS.json');specs=js(P/'SPECIFICATIONS.json')['specs']
assert mapping['base_revision']==BASE and len(mapping['outputs'])==6
for r in mapping['outputs']:
    b=(W/r['publication_path']).read_bytes();assert sha(b)==r['publication_sha256']
    if r['kind']=='primary':ast.parse(b)
    else:assert b'Checker pairing:' in b
canonical={r['key']:r for r in state['canonical']}
assert set(canonical)=={s['key'] for s in specs}
for sp in specs:
    d=Path(canonical[sp['key']]['evidence']);a=js(d/'execute_runner.raw_return.json');b=js(d/'execute_and_write_cache.raw_return.json')
    assert a==b and a['status']=='ok' and a['exit_code']==0 and a['timeout_sec']==60 and not a['stderr']
    assert (d/'execute_runner.stdout').read_bytes()==(d/'complete_stdout.expected').read_bytes()
    assert js(d/'complete_stdout.comparison.json')['equal']
mutants=state['mutations'];assert len(mutants)==27 and sum(r['expected_survival'] for r in mutants)==5
for r in mutants:
    d=Path(r['evidence']);assert sha((d/'whole_source_mutant.py').read_bytes())==r['source_sha256']
    assert r['actual_exit']==r['expected_exit']==(0 if r['expected_survival'] else 1)
    for stream in ['stdout','stderr']:
        b=(d/'execution'/stream).read_bytes()
        assert sha(b)==r[stream+'_sha256'] and b==(d/('complete_'+stream+'.expected')).read_bytes()
        assert js(d/('complete_'+stream+'.comparison.json'))['equal']
graph=W/'docs/audit/data/citation_graph_manifest.json'
before=json.loads(subprocess.check_output(['git','show',BASE+':'+str(graph.relative_to(W))]));after=js(graph)
assert after['node_count']==before['node_count']+3==6880 and after['edge_count']==before['edge_count']+4==15435
assert all(after['nodes'].get(k)==v for k,v in before['nodes'].items())
assert {k:v['out_degree'] for k,v in after['nodes'].items() if k not in before['nodes']}=={s['claim']:len(s['deps']) for s in specs}
compat=js(V/'focused_audit_compatibility.parsed.json');assert compat['checked']==compat['failures']==compat['control_failures']==[]
REC.mkdir(exist_ok=False)
for p in list(P.glob('*.md'))+[P/'EVIDENCE_MAP.json',P/'SOURCE_IDENTITIES.json']:(REC/p.name).write_bytes(p.read_bytes())
pairing="""Checker pairing: authors and focused reviewers used separate contexts of the
same configured model family, preserving the user's selected model and reasoning
effort. Root contributed mechanisms. Distinct reconstruction/control methods
are documented; blind checking, different model families and independent-audit
status are not claimed.
"""
delivery=f"""# Actual scoped delivery evidence

Three canonical runner-cache envelopes exited0 with60second limits. Elapsed:
mass{canonical['Nonisolated_mass']['elapsed_sec']:.9f}s,
centre{canonical['Centre_regularity']['elapsed_sec']:.9f}s,
joint{canonical['Joint_flow']['elapsed_sec']:.9f}s. Complete scientific outputs
match their preserved originals through explicit administrative output maps.
Returned stderr fields are empty; the API merges process stderr into stdout.
Full inner execute_runner and outer cache API returns were saved immediately
outside the cache before later identity checks.

All27whole-primary mutations ran with60second limits:11of14mass,6of8centre
and all5joint variants reject at their original gates. Three mass variants
still pass: copied energy-bound RHS, zero off-mass detuning and weakened padding.
Two wrong centre tent integrals pass author upper-bound gates; the distinct
exact Simpson control rejects both. Full outputs, survivors, commands, elapsed
times and unchanged-source traceback mappings are preserved. These finite
controls do not establish the analytic limits.

Graph6880nodes/15435edges adds exactly3nodes and4direct proof-dependency edges;
every old node is unchanged. Focused changed-evidence compatibility selected
no existing applied row and found no failures; it does not audit the new claims.
Global combined pipeline and strict audit lint were not run and remain
independent landing gates. No verdict or retained promotion is applied.

The final delivery script checks full reconstruction, source/cache/input
identities, syntax, ordinary local links, vocabulary fix/report, exact file set,
staged hashes and whitespace before commit. External paper artifacts remain
inventoried outside this packet and were not newly read by packaging.
"""
composition="""# Complete source composition review

Root read all three complete author arguments, necessary antecedents, separate
source reviews/reconstructions, complete control sources, full outputs and
failures within the preserved coverage records. Root is a contributor.

The sole mathematical edit is the review-required N36 weighted Casimir
C_beta=H^2-beta|K|^2, repairing its whole-residual conversion. The original
definition and beta=1 counterexample remain preserved. Centre and joint proofs
are unchanged. All other note edits declare claims, dependencies, status,
portable links, history or pairing. Every primary calculation is preserved;
joint's adjacent JSON write is suppressed and its source hash is remapped.

Mass reuses SC/Fock proof mechanisms at matched displayed hypotheses without
their isolated-shell/Fock conclusions. Centre's product carrier, fixed lift,
central rate and actual Sobolev vector remain supplied. Joint adds same-domain
commutation to current's finite-range implementation hypotheses. No common
physical model, dense regular creators, nonzero particle sector, ND/EX or
full spectral/scattering exhaustion is constructed.

The exact spectral nonimplication and deleted-hypothesis witnesses retain
their full source N1-N8 discussions and failed routes. Root read those complete
scopes; no universal lattice no-go or invented five-route PASS is asserted.
No Lean certificate is claimed for these analytic arguments.
"""
history="""# Source review and final conformance

Complete source reports, evidence and coverage are preserved. Only the reviewed
N36 definition repair changes mathematics. Original failures, superseded drafts,
helper exposure and nondiscriminating controls remain explicit.

| Section | Actual disposition |
|---|---|
| 1 Self-containment | Full own sources, exact edits, pins and portable links; external paper inventory. |
| 2 Cache/execution | Three actual envelopes, full inner/outer raw returns captured first,60second limits, fresh same-run identities. |
| 3 Scope | Conditional surfaces retain all model and creator obligations. |
| 4 Negative scope | Complete source stress tests and exact counterexamples; no broad no-go or universal five-route PASS. |
| 5 Proof | Complete arguments and necessary antecedents read; N36 repair and full-source reconstruction checked. |
| 6 Runner validity | All27whole-source variants:22rejections/5survivors; distinct reviewer controls and their limits preserved. |
| 7 Packet | Own sources/outputs reachable via EVIDENCE_MAP and reconstruct.py; finite controls supplement proofs. |
| 8 Links/graph | Ordinary local links checked;3nodes/4edges added, every old node unchanged. |
| 9 Structure | Conditional claim/trace fields and application premises explicit. |
| 10 Propose/ratify | New notes/primaries/caches/packet and graph acknowledgment only; no axiom/prompt/audit authority edits. |
| 11 Facts/counts | Complete source-bound outputs, missing/limited evidence not relabelled. |
| 12 Final gates | Vocabulary fix/report, reconstruction, syntax/cache identities, scoped compatibility and staged hashes/whitespace; global combined pipeline/strict audit lint remain unrun landing gates. |

The first sync guard stopped before preparation on changed checkpoint/PR9477
heads; the two new9477notes were read for ownership with no dependency import.
An initial link regex misread display math; final parsing excludes math/code.
Pairing disclosures were added before canonical executions with exact old bytes
and edit maps retained. Two attempts to create the finisher failed in patch/JS
parsing before writing any file; the corrected creation changed no science.
No computational gate or result was repaired.
"""
(P/'DELIVERY_CHECKS.md').write_text(delivery)
(P/'ROOT_COMPOSITION_REVIEW.md').write_text(composition+'\n'+pairing)
(P/'REVIEW_HISTORY.md').write_text(history+'\n'+pairing)
(P/'ARTIFACT_PLAN.md').write_text("""# Regular milestone artifact

Three full notes, three canonically executed finite primaries and this complete
source-bound packet extend existing regular PR9486 after exact staged-byte
verification. No merge, main push, audit verdict or axiom change is included.
""")
(P/'PR_BACKLOG.md').write_text("""# Regular milestone publication

Extend existing regular PR9486 after final staged-byte verification. Three
source reviews and root composition checks are complete. Global combined audit
pipeline and strict audit lint remain independent landing gates. Final commit
and remote PR verification are recorded in the sole live campaign checkpoint.
""")
(P/'HANDOFF.md').write_text(f"""# Frozen milestone handoff

Publication base:{BASE}. This packet records three complete notes/primaries,
source reviews, original failures, actual canonical executions and27whole-source
mutation outcomes. PUBLICATION_EDITS reconstructs every complete source exactly.
Only N36 changes mathematics. Source/evidence maps preserve raw results.

All application premises/control limits remain explicit. No dense regular
creators, model, full channel coverage, audit or Lean certificate is supplied.
The sole live campaign checkpoint remains in the transport worktree's
toe-dynamics-bridge-20261009 directory. This packet is a frozen milestone.
Fixed deadline2026-10-12T16:00:52Z. Editable prompt files changed:none.
""")
p=P/'CLAIM_STATUS_CERTIFICATE.md';old=p.read_text()
new=old.replace('Canonical/mechanical validation\nand final publication disposition remain unrun by preparation.','Canonical/mechanical validation is in DELIVERY_CHECKS; independent landing\naudit gates remain unrun. Publication follows exact staged-byte checks.')
assert new!=old;p.write_text(new+'\n'+pairing)
p=P/'ROUTE_PORTFOLIO.md';p.write_text(p.read_text()+'\n'+pairing)
p=P/'NO_GO_LEDGER.md';old=p.read_text()
new=old.replace("Preparation asserts no universal five-route gate PASS; final scope/gate\nconformance remains root's documented responsibility before publication.","Root read these complete source stress tests and exact scopes.\nNo universal five-route gate PASS or general lattice impossibility is asserted.")
assert new!=old;p.write_text(new)
editable=sorted(P.glob('*.md'))+[W/r['publication_path'] for r in mapping['outputs']]+[P/'reconstruct.py']
for mode in ['fix','report-only']:
    prefix=S/('regularity_joint_final_vocab_'+mode)
    run=subprocess.run([sys.executable,'scripts/vocab_lint.py','--'+mode,'--report-path',str(prefix.with_suffix('.json'))]+[str(p.relative_to(W)) for p in editable],capture_output=True,timeout=60)
    prefix.with_suffix('.stdout').write_bytes(run.stdout);prefix.with_suffix('.stderr').write_bytes(run.stderr);assert run.returncode==0
    report=js(prefix.with_suffix('.json'));assert report['summary']['total_auto_correctable']==report['summary']['total_needs_human']==0
links=[]
for p in editable:
    if p.suffix!='.md':continue
    prose=[];fenced=False
    for line in p.read_text().splitlines():
        if line.lstrip().startswith(chr(96)*3):fenced=not fenced;continue
        if not fenced and not line.startswith(('    ','\t')):prose.append(re.sub(chr(96)+'[^'+chr(96)+']*'+chr(96),'',line))
    body=re.sub(r'\\\[.*?\\\]','','\n'.join(prose),flags=re.S);body=re.sub(r'\\\(.*?\\\)','',body,flags=re.S)
    for target in re.findall(r'\]\(([^)\s]+)\)',body):
        if target.startswith(('http:','https:','#','mailto:')):continue
        assert (p.parent/unquote(target.split('#',1)[0])).resolve().exists(),(p,target)
        links.append({'source':str(p.relative_to(W)),'target':target})
for sp in specs:
    path='scripts/'+sp['runner'];assert runner_cache.cache_status(path)==runner_cache.cache_identity_status(path)=='fresh'
emap=js(P/'EVIDENCE_MAP.json');evidence={r['preserved']:r for r in emap['files']}
def preserve(src):
    b=src.read_bytes();packed=gzip.compress(b,mtime=0);dst=P/'evidence'/(str(src.relative_to(S))+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():assert dst.read_bytes()==packed
    dst.write_bytes(packed);evidence[str(dst.relative_to(P))]={'original':str(src),'preserved':str(dst.relative_to(P)),'bytes':len(b),'sha256':sha(b),'compressed_sha256':sha(packed)}
for folder in ['regularity_joint_verification_preparation','regularity_joint_packaging_recovery','regularity_joint_delivery_recovery']:
    for p in sorted((S/folder).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:preserve(p)
for name in ['run_regularity_joint_verification.py','finish_regularity_joint_delivery.py','repair_regularity_pairing_disclosure.py','regularity_joint_verification_run.stdout','regularity_joint_verification_run.stderr','regularity_joint_link_check_initial.json','regularity_joint_instantiated_edits.json']:preserve(S/name)
for p in sorted(S.glob('regularity_joint_final_vocab_*')):preserve(p)
for r in evidence.values():
    packed=(P/r['preserved']).read_bytes();b=gzip.decompress(packed)
    assert sha(packed)==r['compressed_sha256'] and len(b)==r['bytes'] and sha(b)==r['sha256']
mech={'checked_utc':datetime.now(timezone.utc).isoformat(),'base_revision':BASE,'canonical':state['canonical'],'mutation_count':27,'intended_rejections':22,'preserved_survivors':5,'citation_delta':{'nodes':3,'edges':4},'old_graph_nodes_unchanged':True,'focused_compatibility_claim_coverage':[],'ordinary_links':links,'pairing':pairing,'global_combined_pipeline_run':False,'strict_audit_lint_run':False,'scope':'Mechanical evidence only; complete mathematical review is separately preserved.'}
(S/'regularity_joint_delivery_mechanical.json').write_text(json.dumps(mech,indent=2)+'\n');preserve(S/'regularity_joint_delivery_mechanical.json')
emap['files']=[evidence[k] for k in sorted(evidence)];(P/'EVIDENCE_MAP.json').write_text(json.dumps(emap,indent=2)+'\n')
run=subprocess.run([sys.executable,str(P/'reconstruct.py')],capture_output=True,timeout=60)
(S/'regularity_joint_final_reconstruction.stdout').write_bytes(run.stdout);(S/'regularity_joint_final_reconstruction.stderr').write_bytes(run.stderr);assert run.returncode==0
files=[W/r['publication_path'] for r in mapping['outputs']]+[graph]+[runner_cache.cache_path_for('scripts/'+s['runner']) for s in specs]+[p for p in P.rglob('*') if p.is_file() and p!=P/'SOURCE_IDENTITIES.json']
ident=[]
for p in sorted(set(files)):
    row={'path':str(p.relative_to(W)),'sha256':sha(p.read_bytes())}
    if p.suffix=='.gz':row['decompressed_sha256']=sha(gzip.decompress(p.read_bytes()))
    ident.append(row)
(P/'SOURCE_IDENTITIES.json').write_text(json.dumps({'base_revision':BASE,'scope':'All intended publication bytes except this self-referential manifest.','files':ident},indent=2)+'\n')
paths=[r['path'] for r in ident]+[str((P/'SOURCE_IDENTITIES.json').relative_to(W))]
subprocess.run(['git','add','--']+paths,check=True,timeout=60);subprocess.run(['git','diff','--cached','--check'],check=True,timeout=60)
for r in ident:assert sha(subprocess.check_output(['git','show',':'+r['path']]))==r['sha256']
assert set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0'))-{''}==set(paths)
assert not subprocess.check_output(['git','diff','--name-only'])
assert all(x.startswith('A\t') or x=='M\tdocs/audit/data/citation_graph_manifest.json' for x in subprocess.check_output(['git','diff','--cached','--name-status'],text=True).splitlines())
result={'staged_files':len(paths),'evidence_files':len(evidence),'staged_hashes_match':True,'whitespace_clean':True,'reconstruction_passed':True,'mechanical':mech}
(S/'regularity_joint_final_staged_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='mechanical'}))

