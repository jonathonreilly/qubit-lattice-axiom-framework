# Joint-flow derivation before controls

Author task, 2026-10-12. Root contributed the route. Independent review pending.

Let a finite family of self-adjoint G_j have exact local-vector action
G_j pi(A)Ω=-i pi(delta_j A)Ω, where delta_j is a bounded finite-range spin
interaction derivation. D=pi(A_loc)Ω is dense, invariant under every G_j,
and contained in all finite-word domains by successive local actions. G_jΩ=0
follows at A=1. Supply [G_j,G_k]xi=0 for every xi in D. No strong
commutation, exponential invariance of D or core condition is assumed.

Take s to bound every interaction's cardinality, J_j its per-site norm, and
a=|Y| for local A in A(Y). For ANY prescribed generator word j_1...j_N,

    ||delta_(j_1)...delta_(j_N) A||
       <= ||A|| 2^N product_l J_(j_l)
                   product_(k=0..N-1) (a+k(s-1)).

This follows by following the nested commutator from the innermost operation:
each interaction set must meet the preceding union and adds at most s-1 sites;
the weighted next-branch sum is bounded by its own J_j times that union size.
All sums are finite at each local order. Contractivity gives the same mixed
word estimate for products of the actual G_j on AΩ, with the (-i)^N factors.

For r=s-1>0 the two-variable series is absolutely convergent whenever
z=2r(J_j|u|+J_k|v|)<1, since grouping by N=m+n gives

    sum_(m,n) (2J_j|u|)^m(2J_k|v|)^n/(m!n!)
                product_(l<N)(a+lr)
      = (1-z)^(-a/r).

For s=1 use exp(2a(J_j|u|+J_k|v|)); J_j=0 gives a zero derivation and
G_j=0 on D and hence on the full supplied self-adjoint domain (closedness
applied to approximating sequences). Scalars have zero positive derivatives.

Direct unitary route: expand exp(ivG_k) AΩ by the self-adjoint spectral
Taylor remainder. Apply bounded exp(iuG_j) termwise, then expand its action
on every G_k^n AΩ, which remains in D. The same support-independent
single-variable radius applies to each fixed n, while the mixed bound gives
absolute double convergence in the diamond. This avoids moving an exponential
through an unproved domain. [G_j,G_k]=0 on invariant D permits adjacent swaps
of every finite word, so G_j^m G_k^n AΩ=G_k^n G_j^m AΩ. Reorder the convergent
double sum. Thus the two unitary products agree on dense D and hence as
bounded operators for all (u,v) in the diamond. Split arbitrary u and v into
fixed sufficiently small increments and commute the resulting finite powers.
The supplied self-adjoint operators therefore have commuting unitary groups.
Spectral projections commute: any bounded operator commuting with every
exp(itG) commutes with its spectral calculus, obtained by Fourier-integrable
Gaussian approximations to interval indicators, strong limits, and monotone
limits. Apply this successively to the two groups/projections. No unverified
Nelson integrability theorem or unspecified closure is used.

Algebra route/check: C=[delta_j,delta_k] is a derivation on locals. The exact
vector commutator gives pi(C(A))Ω=0 for every local A. Applying this to AB,
then using the Leibniz rule and the same assertion for B, gives
pi(C(A))pi(B)Ω=0. Cyclic density makes pi(C(A))=0; faithfulness of the unital
spin representation makes C(A)=0 in the algebra. The same mixed Taylor
argument for the previously constructed norm flows proves their commutation.
Canonical GNS action on all cyclic columns makes their implementers commute
exactly, eliminating any projective phase or commutant ambiguity. This shares
the mixed bound with the direct route and is not an independent review.

For translation-covariant local densities g_j(x) of radii L_j and bounds h_j,
define

    q_jk(x)=i sum_(|y-x|<=L_j+L_k) [g_j(y),g_k(x)].

Finite padded Jacobi gives [delta_j,delta_k]=delta_q. q_jk is Hermitian,
translation-covariant, supported inside x+B_(2L_j+L_k), and has norm at most
2 |B_(L_j+L_k)| h_j h_k. Assigning that ball gives finite per-site norm.
The ordered pair j,k is fixed; no pair factor one-half is inserted here.

For any translation-covariant Hermitian local density q of radius L,
delta_q=0 iff, for every member E of a COMPLETE one-site matrix basis at 0,

    i sum_(|x|<=L) [tau_x(q),E_0]=0

as an operator in A(B_(2L)). This is a finite algebra identity, not merely
a vacuum expectation. Sufficiency follows by translation and Leibniz on
tensor products; necessity is immediate. For H/current, use L_h=R and
L_p=3R, giving L_q=5R and finite test support B_(10R). For current/current,
use L_q=9R and test support B_(18R). These bounds are conservative.

Proposed complete coboundary classification, to be checked carefully:
expand q in a tensor basis made from 1 plus traceless one-site matrices.
Group every nonidentity finite tensor word into its translation orbit.
The derivation is zero iff the coefficient sum in every nonidentity orbit
is zero. To justify necessity, the formal local Hamiltonian coefficient of
each fixed nonidentity word is precisely that finite orbit sum. For a site z,
only finitely many words containing z occur, all in z+B_(2L). The finite
operator made from these terms has zero commutator with every matrix at z,
so its nonidentity-at-z coefficients vanish by the matrix-factor commutant
and linear independence of the other tensor factors. This isolates all
nonidentity word coefficients without summing infinitely many scalars.

If an orbit has sum zero, select one reference translate w. Its contribution
is a finite sum c_v(tau_v w-w). Each translation difference telescopes along
a finite coordinate path, giving sum_b(a_b-tau_(e_b)a_b) with local a_b.
Thus q=c 1+sum_b(a_b-tau_(e_b)a_b). For Hermitian q choose a Hermitian tensor
basis and real coefficients to make every a_b Hermitian. Conversely these
differences have zero derivation by finite local cancellation. For commutator
densities c=0 by the product trace. This is a statement about finite local
spin densities, not arbitrary quasilocal densities, fermions or physical
continuity laws. q itself need not vanish.

Planned exact negative conservation fixture:

    h_x=Z_x Z_(x+1)+X_x,
    p_x=-Z_x Y_(x+1)-Z_(x-1)Y_x,
    p'_x=-2 Z_x Y_(x+1).

p-p' is a translation difference and gives the same derivation. For p',
q'_x=i sum_y[h_y,p'_x]
    =-4 X_(x+1)-4Y_xY_(x+1)-4Z_xX_(x+1)Z_(x+2)+4Z_xZ_(x+1).
Consequently

    [delta_h,delta_p](Z_0)
      =-8Y_0+8Y_(-1)X_0+8X_0Y_1-8Z_(-1)Y_0Z_1 !=0.

This is a counterexample to generic energy-current conservation from the
current formula, not to the lemma with exact commutation supplied. A positive
control is homogeneous h_x=X_xX_(x+1)+Y_xY_(x+1), whose current is expected
to conserve through nonzero density divergence. Also test q=Z0-Z1 (zero
derivation but nonzero density), q=Z0 (a Z-only test misses nonzero X action),
vacuum-only commutation, and discrete projective X/Z implementers.

Controls should use exact binary symplectic Pauli arithmetic and a separately
assembled dense finite periodic matrix route. Count mixed-color support
histories, mutate support growth, compare finite unitary compositions, and
preserve every actual failed run. Finite controls cannot prove unbounded
domains, infinite-volume limits or physical realization. Independent review
is required after the complete candidate and evidence freeze.
