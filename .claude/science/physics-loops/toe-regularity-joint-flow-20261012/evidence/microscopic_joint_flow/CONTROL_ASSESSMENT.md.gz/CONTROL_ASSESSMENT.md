# Author control assessment

The analytic draft preceded control execution. This is author evidence. The separately assembled dense matrix calculation provides a distinct arithmetic path, but it is not an independent agent review. Neither row counts nor numerical residuals prove the unbounded-operator theorem.

The baseline runner has SHA-256 `25ebb1eb9068fc7586eb2fa207cbcb28e245f2eb32bcfe4b7600f8dca34575b9`. Its complete 273 lines and all 37 output rows were read. The initial run completed in 0.3202945408411324 seconds, exit 0, with a declared 60-second timeout. Full source, stdout, empty stderr, structured results, dependency versions and execution record are saved under `logs/controls.run1.*`. The scientific runner was not changed after that run.

The exact Pauli engine uses Gaussian rational coefficients and binary symplectic multiplication. Its negative fixture derives the current with the prescribed half and checks a four-word, nonzero `[delta_h,delta_p](Z_0)`. Separately assembled six-site Kronecker matrices form the Hamiltonian and once-oriented pair current without calling the sparse current routine. They reproduce that polynomial with zero matrix residual and nonzero action norm 25.888543819998326. This is a useful finite sign/factor/control-volume check. It is not an infinite-volume approximation claim. The tensor helper rejects support aliases within a word; the complete finite local criterion, not a small ring alone, supplies the theorem's algebraic gate.

The XX+YY fixture has a nonzero eight-word commutator density with zero translation-orbit sums. A constructed local primitive reproduces the density as `a - tau(a)`, and all three one-site Pauli basis actions vanish exactly. The theorem proves the identity-matrix case automatically. The general-dimensional local-density classification is proved by the finite tensor-basis/partial-trace argument; these one-dimensional examples do not numerically establish that classification.

Mixed red/blue connected histories are enumerated with accumulated support unions, including a disconnected initial set. Their order dependence is retained. All ten selected counts are below the proposed common-cardinality bound and above the bound obtained by deleting support growth. Four exact binomial rows test the grouping arithmetic only; they do not independently derive the history estimate or an analytic radius.

## Actual source defects

Each defect is an exact single replacement in an isolated copy of the original runner. `run_mutations.py` records the replacement, original and mutant hashes, exact command and cwd, timeout, elapsed time and exit. All 37 rows are retained for every mutant; no early assertion hid later nondiscriminating cases.

| Defect | Failed rows | Expected exit | Elapsed seconds |
| --- | ---: | ---: | ---: |
| Reverse current sign | 3 | 1 | 0.480472 |
| Omit current factor one half | 3 | 1 | 0.215279 |
| Delete history-support growth | 10 | 1 | 0.216347 |
| Reverse Jacobi-density sign | 3 | 1 | 0.226094 |
| Drop a cancelling divergence term | 1 | 1 | 0.211890 |

Every mutant has a declared 60-second timeout. All completed before it, with empty stderr. These deliberately failed executions are preserved. There were no unintended execution failures. Baseline versus mutant complete-row differences are in `logs/packet_checks.results.json`; unchanged rows remain in each full result. Passing rows in a mutant are nondiscriminating for that particular defect, not additional evidence against it.

The generic-current-conservation claim, one-observable test, vacuum-only test and projective-implementer shortcut are addressed explicitly. In both tracial fixtures the vacuum commutator residual is zero, although the negative fixture has nonzero local action. The positive fixture's reversed unitary order is also nondiscriminating; the negative unitary-product defect is about 0.04513. The qubit X/Z projective example concerns discrete fixed group elements, and is not claimed to give commuting continuous one-parameter automorphism groups.

`check_packet.py` compared every stdout row and terminal summary against its full structured result, verified the source hashes, all row and failure counts, exits, empty stderr and declared timeouts. It also verified all 119 file entries in the two frozen upstream receipts (entries may overlap; this is not a distinct-file count), plus the three initial source copies. Its own 60-second execution completed in 0.046574333216995 seconds, exit 0, with no failed checks.

No finite control establishes self-adjoint realization, invariant unbounded domains, a thermodynamic limit, an intended-model conservation identity, or physical Poincaré symmetry. The source proves the first conditional analytic implication with supplied actual operators; model realization and independent review remain open.
