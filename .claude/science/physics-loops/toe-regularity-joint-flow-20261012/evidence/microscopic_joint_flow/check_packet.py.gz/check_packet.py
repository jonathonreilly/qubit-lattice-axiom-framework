"""Check complete recorded controls and all upstream receipt identities."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parent
S = ROOT.parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

failures = []
sources = []
for item in json.loads((ROOT/'source_manifest.initial.json').read_text())['items']:
    source = Path(item['source'])
    observed = sha(source)
    copied = sha(ROOT/item['copy'])
    passed = observed == copied == item['sha256']
    sources.append(dict(path=str(source),expected=item['sha256'],observed=observed,
                        copied=copied,passed=passed))
    if not passed: failures.append('input identity '+str(source))

upstream = []
for receipt in [S/'microscopic_current_implementation/receipt.json',S/'microscopic_current_review/receipt.json']:
    data=json.loads(receipt.read_text())
    for item in data['files']:
        path = Path(item['path'])
        if not path.is_absolute(): path = S/path
        observed = sha(path) if path.exists() else None
        size = path.stat().st_size if path.exists() else None
        passed = observed == item['sha256'] and size == item['bytes']
        upstream.append(dict(receipt=str(receipt),path=str(path),observed=observed,bytes=size,passed=passed))
        if not passed: failures.append('upstream receipt identity '+str(path))

baseline=json.loads((ROOT/'logs/controls.run1.results.json').read_text())
records=[('baseline',ROOT/'logs/controls.run1.results.json',ROOT/'logs/controls.run1.stdout.jsonl',
          ROOT/'logs/controls.run1.stderr.txt',ROOT/'logs/controls.run1.execution.json',
          ROOT/'logs/controls.run1.py')]
for folder in sorted((ROOT/'mutations').iterdir()):
    if folder.is_dir():records.append((folder.name,folder/'joint_controls_results.json',folder/'stdout.jsonl',
                                      folder/'stderr.txt',folder/'execution.json',folder/'joint_controls.py'))
controls=[]
for name,result_path,stdout_path,stderr_path,exec_path,source_path in records:
    result=json.loads(result_path.read_text()); execution=json.loads(exec_path.read_text())
    stdout=[json.loads(x) for x in stdout_path.read_text().splitlines()]
    expected_summary={k:result[k] for k in ['total','failed','source_sha256']}
    checks=dict(all_stdout_rows_match=stdout[:-1]==result['rows'],stdout_summary_matches=stdout[-1]==expected_summary,
                row_count_matches=len(result['rows'])==result['total']==37,
                failures_match=sum(not x['passed'] for x in result['rows'])==result['failed'],
                source_identity_matches=sha(source_path)==result['source_sha256'],
                stderr_empty=stderr_path.stat().st_size==0,
                completed=execution['status']=='completed',declared_timeout=execution['declared_timeout_seconds']==60,
                expected_exit=execution['exit_code']==(0 if name=='baseline' else 1))
    changes=[dict(name=a['name'],baseline=a,observed=b) for a,b in zip(baseline['rows'],result['rows']) if a!=b]
    controls.append(dict(name=name,checks=checks,failed_predicates=[x['name'] for x in result['rows'] if not x['passed']],
                         changed_complete_rows=changes))
    if not all(checks.values()):failures.append('control log check '+name)

out=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_copies=sources,
         upstream_receipt_files=upstream,upstream_file_count=len(upstream),control_logs=controls,
         failures=failures,passed=not failures)
(ROOT/'logs/packet_checks.results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(bool(failures))
