"""Freeze and execute deliberate source defects; preserve every outcome."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'controls/joint_controls.py'
BASE = SOURCE.read_text()
DEFECTS = [
    ('reverse_current_sign', 'F(k,2)', 'F(-k,2)',
     'Reverse the signed pair-current coefficient.'),
    ('omit_current_half', 'F(k,2)', 'F(k)',
     'Omit the factor one half in the two-oriented-pair current.'),
    ('omit_history_growth', 'prod(a+2*k for k in range(n))', 'prod(a for k in range(n))',
     'Delete accumulated-support growth from the proposed mixed bound.'),
    ('reverse_jacobi_density', 'qbad=deriv(pbad,hbad)', 'qbad=scale(deriv(pbad,hbad),-1)',
     'Reverse the commutator-density sign while retaining derivation order.'),
    ('drop_divergence_term', "divergence=add(word([(0,'Z')]),word([(1,'Z')],-1))",
     "divergence=word([(0,'Z')])", 'Delete the cancelling translated density.'),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

rows = []
for name, before, after, purpose in DEFECTS:
    assert BASE.count(before) == 1, (name, BASE.count(before))
    folder = ROOT / 'mutations' / name
    folder.mkdir(parents=True, exist_ok=True)
    runner = folder / 'joint_controls.py'
    runner.write_text(BASE.replace(before, after))
    command = ['python3', str(runner)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.perf_counter()
    timeout = 60
    try:
        result = subprocess.run(command, cwd=folder, capture_output=True,
                                timeout=timeout, check=False)
        stdout, stderr = result.stdout, result.stderr
        status, code = 'completed', result.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr = error.stdout or b'', error.stderr or b''
        status, code = 'timeout', None
    elapsed = time.perf_counter() - clock
    (folder / 'stdout.jsonl').write_bytes(stdout)
    (folder / 'stderr.txt').write_bytes(stderr)
    metadata = dict(name=name, purpose=purpose, replacement={'before': before, 'after': after},
                    original_sha256=sha(SOURCE), mutant_sha256=sha(runner), command=command,
                    cwd=str(folder), started_utc=started, declared_timeout_seconds=timeout,
                    elapsed_seconds=elapsed, status=status, exit_code=code)
    output = folder / 'joint_controls_results.json'
    if output.exists():
        observed = json.loads(output.read_text())
        metadata.update(total=observed['total'], failed=observed['failed'],
                        failed_predicates=[r['name'] for r in observed['rows'] if not r['passed']],
                        nondiscriminating_predicates=[r['name'] for r in observed['rows'] if r['passed']])
    (folder / 'execution.json').write_text(json.dumps(metadata, indent=2) + '\n')
    rows.append(metadata)
    print(json.dumps(metadata), flush=True)

summary = dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               original_sha256=sha(SOURCE), defects=rows,
               all_rejected=all(r['status']=='completed' and r['exit_code']==1 and r.get('failed',0)>0
                                for r in rows))
(ROOT / 'mutations/summary.json').write_text(json.dumps(summary, indent=2) + '\n')
raise SystemExit(not summary['all_rejected'])
