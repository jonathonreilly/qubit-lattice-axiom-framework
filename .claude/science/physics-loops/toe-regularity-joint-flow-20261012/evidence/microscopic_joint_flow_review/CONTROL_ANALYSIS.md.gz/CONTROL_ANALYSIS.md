# Control and evidence review

The analytic reconstruction and the new control source were frozen at
2026-10-12 03:43:59 UTC, before opening the author runner, helpers, result
artifacts or source mutants. Prior exposure is explicit: the candidate's own
verification prose, upstream note and receipt source metadata were visible.
This review is independent implementation and proof checking, not blinded
checking. No author helper was imported into the independent program.

## Independent implementation and decisive outcomes

`independent_controls.py` has SHA-256
`4a378e97577c9e5b592ea900cfa2aa8bda98bd8be58d4083ada92350c67fc923`.
It uses literal Kronecker tensor matrices represented by pairs of sparse
integer matrices. There is no Pauli multiplication table or binary symplectic
engine. Conservative integer-operation bounds are checked before arithmetic;
the largest observed coefficient is 42 and the largest guarded bound is 210,
far below its 2^62 guard. Integer divisions by two are checked for divisibility.
Norm-zero decisions are exact sparse Gaussian-integer equalities, with no
floating tolerance. Frobenius squares use Python integers.

The independent execution used Python 3.13.5, NumPy 2.4.4 and SciPy 1.17.1,
with a declared 60-second timeout. It completed in 1.160284 seconds, exit 0,
with empty stderr. All 123 finite predicates were satisfied. This is an
execution count; many rows are individual basis members or elementary
bookkeeping identities, not independent proofs.

- The negative density's pair-current formula agrees exactly with the two
  displayed terms. Direct local derivations on seven padded open sites
  reproduce J21, including every sign and factor. The J21 residual is zero;
  its nonzero action has Frobenius square 32768 and entrywise l1 sum 3072.
  The sign-reversed current produces residual Frobenius square 131072;
  omitting the half produces 32768. These are matrix norms on the stated
  finite tensor space, not Pauli coefficient l1 sums or an infinite-volume
  physical observable.
- The XX density's actual current gives J22 exactly on its six-site support.
  The q matrix is nonzero, with Frobenius square 2048, and equals the stated
  divergence exactly. Its complete site-zero basis actions vanish on an
  eleven-site padded tensor space. Deleting the cancelling t term produces
  nonzero residuals for X, Y and Z, with Frobenius squares 196608, 196608 and
  131072 respectively. The identity basis member remains nondiscriminating.
- A separately assembled once-oriented current on nine open XX sites has
  nonzero [H,P], with Frobenius square 32768. Its commutator with each of
  X_0,Y_0,Z_0 is exactly zero. This directly checks the distinction between a
  boundary term and the infinite local derivation criterion.
- A complete qutrit basis is verified Hermitian and trace orthogonal: its
  Gram diagonal is (3,2,2,2,2,2,2,2,6). Zero, scalar, local divergence,
  scalar-plus-divergence, a single diagonal-orbit perturbation, and a
  nonadjacent two-site word all agree with the J20 orbit criterion under
  full operator basis tests. The K_0 partial trace vanishes in every case,
  including the two nonconserving cases where K_0 itself is nonzero.
  Adding diag(1,1,-2) at site zero is missed by selected diagonal tests but
  detected by four off-diagonal basis members. This tests the full matrix
  criterion beyond the author's qubit fixtures.
- Weighted two-dimensional square/edge support histories are computed by
  dynamic programming over unions, including a disconnected seed. Red
  plaquettes have per-site weight 4 and blue horizontal/vertical edges have
  per-site weight 6. All 18 selected mixed histories respect the common
  cardinality bound. Fourteen reject the no-growth competitor. For one
  initial site, rb has weight 72 and br has weight 36, although both have
  the common bound 96. On-site and zero/scalar edge cases also agree.

The tracial-vacuum, selected-observable and discrete X/Z phase diagnostics
are deliberately recorded as insufficient criteria. They cannot establish
joint strong commutation. The independent K_0 projection identities are
finite tensor identities; their numerous rows do not prove the all-density
classification. That classification and the analytic/domain theorem are
supported by the reconstructed proofs.

## Complete author source and replay inspection

The complete 273-line `controls/joint_controls.py`, 69-line
`run_mutations.py` and 65-line `check_packet.py` were read. The five actual
mutant sources differ by exactly their recorded single substitutions; their
complete differences were read. Unchanged source bodies are covered by the
baseline read and exact byte comparison. The author controls import only
the standard library, NumPy and SciPy; there is no hidden repository helper.

The author's Gaussian-rational symplectic product has the correct phase
`|x&z|+|v&w|-|(x^v)&(z^w)|+2|z&v|` modulo four. Its one-dimensional derivation
sum has sufficient center padding. The current's two-oriented pair coefficient
is i*k/2. Its orbit primitive telescopes with the correct sign for both
positive and negative translations. The sparse negative polynomial and the
separately assembled six-site periodic matrix calculation agree. The dense
control rejects support aliases within an individual tensor word; that finite
guard does not replace the theorem's general padding criterion.

The unmodified baseline and every actual saved source mutant were copied
byte-for-byte into `author_replays/` before execution. Every replay used a
declared 60-second timeout, completed, and had empty stderr. For every run,
all 37 rows and the complete stdout bytes exactly reproduce the original.
Every structured-result field except its fresh execution timestamp also
matches, including source hash and library versions.

| Replayed source | Exit | Failed predicates | Seconds |
|---|---:|---:|---:|
| baseline | 0 | 0 | 0.404763 |
| drop_divergence_term | 1 | 1 | 0.207048 |
| omit_current_half | 1 | 3 | 0.212530 |
| omit_history_growth | 1 | 10 | 0.215897 |
| reverse_current_sign | 1 | 3 | 0.205554 |
| reverse_jacobi_density | 1 | 3 | 0.204821 |

Current sign and half defects fail the exact current, current-improvement,
and nonzero J21 polynomial gates. The support-growth defect fails every
selected history-bound row. Reversing the Jacobi density fails the X,Y,Z
comparison against independently ordered derivations. Dropping the divergence
term fails its complete-basis cancellation row. These are intentional failures
of actual executable source mutations, not fabricated expected results.

Every passing mutant row is also retained, with full values, in each
`comparison.json`. In particular:

- The XX null-density and divergence reconstruction gates accept current
  sign reversal and rescaling, as they should: those changes preserve zero
  derivation. They do not test the normalization of the current.
- The dense matrices are assembled independently of the sparse current
  helper, so they remain unchanged when that helper is mutated. They check
  the finite formula and expected polynomial through a separate arithmetic
  route; they do not directly inspect the mutated helper's output.
- The q-prime gate uses its explicit simplified density, so mutating the
  other current helper leaves it unchanged. Its passing status does not
  validate that helper.
- The binomial-grouping identities still pass when the history bound is
  corrupted; they only test arithmetic grouping. The explicit growth-mutant
  detector also still reports the same rejecting history counts.
- The tracial-vacuum checks are zero for both conserving and nonconserving
  fixtures. The positive unitary-order test cannot reject false generic
  conservation. The negative fixture's unitary-product defect is
  0.045134712124742606 and its local action norm is 25.888543819998326.
- The X/Z example concerns fixed discrete elements, not commuting continuous
  automorphism groups. Its scope is accurately stated in source and output.

No timeout or unintended execution failure occurred. No failed or
nondiscriminating row was removed. The author's mutation/check orchestrators
were inspected but not executed in place, because they would write into the
frozen author directory. The independent replay driver performs the relevant
checks and writes only within this review directory.

A final administrative identity check did fail for one installed reporting
reference. The original failure is preserved as
`logs/final_verification.initial_instruction_drift.json`, with the exact diff
in `logs/instruction_distribution_drift.diff`. The complete current checkout
reference was then read and applied. Its added paragraph concerns canonical
output reproducibility and external sidecar/cache capture. Neither runner's
output handling was changed; both use ordinary overwrite writes, each replay
preserves stdout and JSON from the same run, and `runner_cache` is unused.
No additional science run or source change was required. This resolved
distribution issue does not alter the candidate proof or any evidence binding.

## Artifact-chain verification

`source_bindings.before_replays.json` and `source_bindings.after_replays.json`
verify all 73 candidate receipt entries and all 119 entries in the two
necessary upstream receipts: 192 entries, with duplicates counted as entries,
not as distinct files. All hashes and byte sizes match. The complete author
directory inventory contains exactly the 72 files declared beneath it,
excluding the receipt's own self-hash; the candidate note is the 73rd entry.
The source-input originals and their saved copies match all declared hashes.

For every author result, the result source hash, execution source hash,
stdout rows, stdout terminal summary, row count, failure count, completion,
exit and declared timeout agree. The independent replay checks every row,
including all changed mutant data, not only the overall exit.

The predecessor review is source-bound context. Its actual proof input was
read and reconstructed here; this review does not re-certify unrelated
scattering/index predecessors or apply an audit result. The author's limited
statement-search record is not a literature novelty claim and was not rerun.

Reproduction sources, complete stdout/stderr, results, commands, timeouts,
elapsed times, exact diffs and comparison records are all preserved on disk.
Administrative reading calls remain in the tool history; no complete terminal
transcript or invented per-read timing record is claimed.
