# Independent reconstruction and frozen control design

This document is frozen before opening the joint-flow author's control source,
helper source, result JSON, stdout, stderr, or mutation files. It is not a claim
of no prior exposure: the complete candidate itself contains author-result
summaries in sections 8 and 10, and the upstream note contains its own control
summaries. Those prose summaries were read. They are not used as proof evidence.
The author receipt has so far been inspected only for top-level keys,
source-input bindings, and upstream-integrity metadata. No author helper was
imported or executed.

Candidate: `MICROSCOPIC_JOINT_FLOW_PROBE.md`, 279 lines,
SHA-256 `35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd`.
Receipt: SHA-256
`afdfaff1e0a1c4a6843cbfd0d49c449d37bed0d62052b967c92ac9c38582984c`.
Necessary actual upstream proof: `MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md`,
399 lines, SHA-256
`bcc9b9503e49c17b6e6140c22f3971f35ccd3ed72de16f0371666dc9162dfd9a`.
Its complete scientific argument, including I1--I31 and limitations, was read.

## Exact target and hypotheses

For a finite family of finite-range bounded interactions on a spin tensor
algebra, let each supplied self-adjoint Hilbert operator act on the entire
local cyclic space by minus i times that interaction's local derivation. If
the supplied operators commute pairwise on that space, prove strong
commutation of their spectral measures and exact canonical implementation of
commuting microscopic flows. In the translation-covariant density subcase,
identify a finite complete operator criterion for the commutators to vanish,
including cancellation by local divergences.

This is an implication under supplied self-adjointness and exact local vector
actions. It neither constructs those operators nor verifies conservation for
an intended physical Hamiltonian. No positivity, gap, particle structure,
physical Lorentz group, or empirical identification enters the proof. The
registered scale, kinetic-isotropy, and realized-state primitives have no role.

## Reconstruction of the load-bearing proof

### Local domain and common estimates

If A is local, every derivation delta_j A is local by finite range. Therefore
the assumed vector relation maps pi(A) Omega back into the same dense linear
space D. Induction establishes the domain and identity for every mixed word;
there is no use of an unbounded product outside D. Applying the vector action
to the identity gives G_j Omega = 0. This supplies vacuum fixing by the already
self-adjoint unitary group.

For a prescribed sequence of N colors, expand the commutator from the inside.
Let Z be the union of the original support and all interaction sets selected
so far along one branch of the expansion. Terms not meeting Z vanish. If the
original support has a sites and every interaction set has at most s sites,
the k-th union has at most a+k(s-1) sites. The total norm weight of choices of
the next color is at most J_color times that union size. Multiplying these
conditional bounds down the finite history tree and inserting 2 for each
commutator yields

    ||delta_{j1} ... delta_{jN}(A)||
      <= ||A|| 2^N product_l J_{jl} product_{k=0}^{N-1}(a+k(s-1)).

Counting the entire radius-N ball would not yield this bound; counting the
individual union does. Disconnected starting support is allowed. Empty
interaction sets do not act. Deleting terms in a finite-volume cutoff can
only decrease this majorant. Contractivity transfers the bound to mixed
operator words on D.

For r=s-1>0, the homogeneous degree N part of the double absolute sum is

    product_{k=0}^{N-1}(a+kr) [2(J_j |u|+J_k |v|)]^N/N!.

The ratio of successive terms tends to z=2r(J_j |u|+J_k |v|), so the series
converges when z<1. Equivalently it is (1-z)^(-a/r). The crucial uniformity is
the radius, not the value of the bound, as the initial support changes.
For s=1 the product is a^N and gives an exponential entire majorant. Scalars
have no positive derivatives. If J_j=0, the closed graph of G_j contains
D x {0}, hence its closure contains H x {0}; G_j is the zero operator on H.
No zero denominator is needed.

### Sequential Taylor comparison and strong commutation

For real x the integral Taylor remainder of exp(ix) has magnitude at most
|x|^N/N!. Apply this scalar bound through the spectral measure of a supplied
self-adjoint G and integrate its square against a vector in Dom G^N. The
result is the Hilbert remainder bound |t|^N ||G^N xi||/N!.

First expand exp(iv G_k) xi on a local cyclic vector and apply the bounded
operator exp(iu G_j) to the convergent series. For every fixed n, G_k^n xi is
again local cyclic, so it has a convergent G_j expansion at the same radius.
The mixed estimate makes the resulting double sum absolutely summable. Thus
both unitary product orders equal their respective double word sums. This
step does not apply G_j to exp(iv G_k) xi and therefore does not assume that
vector is in Dom G_j.

The exact commutator identity on D permits adjacent swaps in any finite
word: both its prefix and suffix keep all intermediate vectors in D. The
two double sums are equal termwise after reordering and hence the bounded
unitary products agree on D, then on H. For arbitrary real u,v choose positive
integers p,q so that (u/p,v/q) lies in the open convergence diamond. The two
small-step bounded unitaries commute, hence so do their p-th and q-th powers.
This uses the separate spectral group laws, not any joint domain assumption.

To recover strong spectral commutation, a bounded operator commuting with
every exp(itG) commutes with all Fourier-integrable functions of G. Gaussian
smoothings of finite-interval indicators converge spectrally to the interval
projection with half endpoint atoms. The atoms are recovered by the bounded
strong limit exp[-n(G-c)^2]. Subtract those terms and then use interval
generation and bounded strong limits to recover every Borel projection.
Apply the argument once with the other group, then once with its projections.
There is no use of formal unbounded products here.

Finite pairwise strongly commuting generators possess a joint spectral
measure. Its real linear functions give the stated self-adjoint generator
with the stated square-integrability domain, possibly larger than the
intersection of individual domains because of cancellations. It agrees with
the finite sum on D. No assertion about a formal infinite Hamiltonian or an
unbounded boost sum follows.

### Upstream norm dynamics and GNS implementation

For a finite cutoff, the real-time automorphism is isometric. Its norm Taylor
remainder is bounded by the same derivative majorant. At each fixed degree N,
finite range makes the coefficient exactly equal to the infinite local
coefficient once the cutoff contains the N-step neighborhood. Choosing N
first and the volume second gives the small-time norm limit on locals.
Isometry and density extend it to every quasilocal observable.

Composition is continuous in point-norm on uniformly isometric maps:
||F_L G_L A-F G A|| <= ||G_L A-G A|| + ||(F_L-F)G A||.
This permits fixed finite subdivisions to construct the limit at every time,
independently of subdivision, and to pass the finite-volume group law to the
limit. This proves the required individual groups before any joint argument.

The spectral Taylor coefficients of G and the algebra Taylor coefficients
match on local vacuum columns. Since G fixes Omega, those equalities imply
small-time state invariance. The group law extends invariance to every time.
The canonical formula W_t pi(A) Omega = pi(alpha_t(A)) Omega respects null
vectors by state invariance, is unitary, and is strongly continuous. It agrees
with exp(itG) first locally in time and then everywhere by the group laws.
Applying it to pi(A alpha_{-t}(B)) Omega proves the full adjoint formula.
This prevents the invalid inference from an equality on Omega alone.

### Algebra versus cyclic vectors and phases

Set C=[delta_j,delta_k], which is again a local derivation. The vector
commutator is -pi(C(A)) Omega. If it vanishes for every local A, use AB:

    0 = pi(C(AB)) Omega
      = pi(C(A)) pi(B) Omega + pi(A) pi(C(B)) Omega.

The second term is zero and local cyclic vectors are dense, so the bounded
operator pi(C(A)) is zero. A nonzero unital representation is isometric on
each local full matrix algebra, and norm density makes it faithful on the
spin algebra. Therefore C(A)=0. This is not a separating-vacuum argument.
Conversely C=0 immediately gives the vector commutator identity.

The algebra double-series proof is then valid with the same majorant.
Equivalently, faithful exact GNS implementation transfers commuting unitary
products to commuting flows. Conversely, canonical actions of commuting
flows agree on every local cyclic vector, so a potential commutant-valued
commutator implementer is eliminated. Agreement of adjoint actions without
the canonical action and common fixed cyclic vector would be insufficient.

### Commutator density, finite basis criterion, and divergence classification

For radii L_j,L_k, only density centers separated by at most L_j+L_k can
have a nonzero commutator. Defining q_jk(x)=i sum_y [g_j(y),g_k(x)] over those
centers, finite Jacobi on a padded center set gives

    [delta_j,delta_k](A) = -[[F_j,F_k],A]
                           = i sum_x [q_jk(x),A].

The signs contain i twice; there is no 1/2 because the two labels are ordered.
The support union lies in x+B_(2L_j+L_k). Each term has norm at most 2h_jh_k,
with at most |B_(L_j+L_k)| terms. An assigned interaction therefore has
per-site norm at most 2|B_(2L_j+L_k)||B_(L_j+L_k)|h_jh_k. The finite padded
set Y+B_(2(L_j+L_k)) includes every inner/outer pair that can act on A.

For one finite density q of radius L, only centers x in B_L can affect the
site-zero full matrix factor. Their commutators are finite operators on
B_(2L). If the sum vanishes on a complete one-site basis, translation gives
vanishing at all sites and Leibniz gives vanishing on every finite tensor
product. One selected commuting observable or expectations cannot replace
these operator equalities. Necessity is immediate.

Choose a Hermitian, trace-orthogonal one-site basis with identity and
traceless nonidentity elements. Every finite nonempty labeled tensor word
has no nonzero translation stabilizer, because its finite support cannot be
invariant under infinitely many translations. For each word orbit let s_O
be the total coefficient in q. For fixed z, take only translated word terms
having a nonidentity factor at z, producing the finite matrix K_z. Each
target word with support containing z receives exactly coefficient s_O.

If delta_q vanishes on the site-z full matrix algebra, K_z commutes with
that full factor and therefore has form 1_z tensor B. Yet its normalized
partial trace at z is zero, because all its terms are traceless at z. Thus
B=0 and every s_O is zero. Conversely zero orbit sums make each K_z zero.
This proves necessity without manipulating an infinite global Hamiltonian.

Within an orbit with zero total coefficient, choose a reference w. The
orbit contribution is a finite sum c_v(tau_v(w)-w). Along a finite coordinate
path from 0 to v, positive and negative steps respectively have form
-(1-tau_e)tau_u(w) and (1-tau_e)tau_(u-e)(w). Collecting them gives finitely
supported Hermitian a_b with q=c1+sum_b(a_b-tau_(e_b)(a_b)). Conversely each
such difference has zero derivation by a finite relabeling on each local A.
For q_jk, the product trace annihilates every commutator, so c=0. This is a
classification of finite local spin densities; it does not cover generic
quasilocal cohomology or graded fermions.

### Example checks to be computed independently

Use the upstream convention p_x=(i/2) sum_r r[h_x,h_(x+r)]. For h_x=Z_xZ_(x+1)
+X_x, direct 2x2 multiplication gives p_x=-Z_xY_(x+1)-Z_(x-1)Y_x. Its difference
from p'_x=-2Z_xY_(x+1) is a translation difference. The full local double
commutator must be compared with the four-term J21 polynomial, including
every sign and factor, using open padded matrices rather than the author's
six-site periodic or binary-symplectic implementation.

For h_x=X_xX_(x+1)+Y_xY_(x+1), assemble p from the same upstream pair formula,
then compute i sum_y[h_y,p_0] directly on its actual six-site support. Compare
with J22 and its explicit a-tau(a). Test its full one-site derivation using
padded open matrices. A nonzero open-boundary commutator is compatible with
zero interior local derivation; this difference is itself a decisive check.

## Frozen decisive-control design

The new reviewer program will import no author file. Its arithmetic path is
literal tensor Kronecker matrices over pairs of integer sparse matrices for
real and imaginary parts. It will not implement a Pauli multiplication table
or binary symplectic representation. Integer overflow will be guarded using
conservative operation bounds; any exact division by 2 must be verified.

1. Reconstruct the negative current and commutator on padded open matrices.
   Compare its nested derivations with J21. Reverse the current and double
   its normalization in the independent construction: both must change a
   nonzero local result. Selected-observable and tracial-vacuum-only tests
   must be explicitly recorded as nondiscriminating.
2. Reconstruct the XX current and q directly, compare with J22, and verify
   q=a-tau(a) although q is nonzero. Drop one term of a displayed divergence
   expression and require a nonzero local complete-basis residual.
3. On finite open cutoffs, test that positive XX [H,P] can be nonzero at the
   boundary while its commutator with a padded interior observable is zero.
   This distinguishes the infinite local criterion from finite-boundary
   commutation. It does not numerically prove a thermodynamic limit.
4. Test J17/J20 outside the author's qubit examples using a complete qutrit
   basis with eight traceless Hermitian matrices plus identity. Construct
   finite divergence densities and perturb one orbit sum. Full operator
   basis tests must separate them, even where a selected diagonal observable
   does not. Recover K_0's zero partial trace and commutant consequence on
   explicit small tensor factors.
5. Use exact weighted dynamic programming over support-union states for
   mixed two-dimensional edge/plaquette histories with different cardinalities
   and a disconnected seed. Compare with the common growing-support bound,
   and require the no-growth competitor to be rejected in at least one case.
   Include on-site and zero-interaction cases. These finite checks stress
   the estimate but do not prove its all-order statement.
6. Record scalar/multinomial arithmetic only as arithmetic checks. A finite
   matrix unitary check cannot establish unbounded self-adjoint domains,
   and no such claim will be made. The proof above bears those obligations.
7. After the reconstruction and the new control source are frozen, inspect
   all author sources, helpers and exact source diffs. Reproduce the baseline
   and each actual source mutant from copies inside the review directory,
   with a declared 60-second subprocess timeout and captured commands,
   versions, elapsed time, exit, full stdout and stderr. Preserve failures,
   timeouts, and passing mutant predicates. Do not modify frozen author files.
8. Verify all author receipt file bindings and relevant upstream manifests,
   source/output hashes, and final unchanged input bytes. A mismatch is an
   evidence finding even if an executable exits successfully.

## Provisional assessment before author-artifact access

No mathematical defect has yet been found in the conditional proof. The
analytic-vector/domain bridge appears closed under precisely the supplied
hypotheses. The intended model's conservation identities, actual generators,
boost closure and physical representation remain open supplied obligations.
This provisional assessment will not be promoted by predicate counts.
