#!/usr/bin/env python3
"""Deterministic final source/output binding; never reruns scientific controls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

O = Path(__file__).resolve().parent
S = O.parent
W = Path('/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/scattering_worktree')
CHECKS = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')


def check(name, passed, **details):
    CHECKS.append({'name': name, 'passed': bool(passed), **details})


def main():
    for entry in read(O/'input_manifest.before_author_controls.json'):
        path, copy = Path(entry['path']), Path(entry['snapshot'])
        check('original_input_and_snapshot_unchanged', sha(path) == sha(copy) == entry['sha256'],
              path=str(path), sha256=sha(path))
    for entry in read(O/'INDEPENDENT_FREEZE.json')['files']:
        path = Path(entry['path'])
        check('independent_freeze_unchanged', sha(path) == entry['sha256'], path=str(path), sha256=sha(path))
    for name in ['physics-claim-reviewer/SKILL.md', 'review-loop/SKILL.md',
                 'physics-loop/references/proof-search-governance.md',
                 'review-loop/references/SCIENCE_LENSES.md']:
        installed = Path('/Users/jonreilly/.codex/skills')/name
        current = W/'docs/ai_methodology/skills'/name
        check('matching_installed_instruction', sha(installed) == sha(current), path=name,
              installed_sha256=sha(installed), current_sha256=sha(current))
    installed_reporting = Path('/Users/jonreilly/.codex/skills/review-loop/references/FIXES_AND_REPORTING.md')
    current_reporting = W/'docs/ai_methodology/skills/review-loop/references/FIXES_AND_REPORTING.md'
    reporting_snapshot = O/'inputs/FIXES_AND_REPORTING.checkout_current.md'
    expected_reporting = '8fdc997ce1735a7a132a2fe21732e5f9c9197ac386ea7dd0b4e4a1aa7269702e'
    check('applied_current_reporting_reference_unchanged', sha(current_reporting) == sha(reporting_snapshot) == expected_reporting,
          installed_sha256=sha(installed_reporting), applied_sha256=sha(current_reporting),
          installed_matches_current=sha(installed_reporting) == sha(current_reporting),
          disposition='Known distribution mismatch; failed first verification preserved; complete current reference read and applied')
    initial = read(O/'logs/final_verification.initial_instruction_drift.json')
    initial_failures = [c for c in initial['checks'] if not c['passed']]
    check('original_identity_failure_preserved', len(initial_failures) == 1 and initial_failures[0]['path'] == 'review-loop/references/FIXES_AND_REPORTING.md',
          failure_record_sha256=sha(O/'logs/final_verification.initial_instruction_drift.json'),
          diff_sha256=sha(O/'logs/instruction_distribution_drift.diff'))
    check('planning_blob_identity', sha(S/'centre_regularity_to_geometric/sources/planning_AGENTS.md') ==
          '3d409e93abb3b58796a9c10ca6d21ba93b7edc73b8fb24e7364da97c805580a9')

    receipts = [S/'microscopic_joint_flow/receipt.json',
                S/'microscopic_current_implementation/receipt.json',
                S/'microscopic_current_review/receipt.json']
    bindings = []
    for receipt in receipts:
        for entry in read(receipt)['files']:
            path = Path(entry['path'])
            path = path if path.is_absolute() else S/path
            passed = sha(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
            bindings.append({'receipt': str(receipt), 'path': str(path), 'sha256': sha(path),
                             'bytes': path.stat().st_size, 'passed': passed})
    check('all_candidate_and_upstream_file_bindings_current', all(x['passed'] for x in bindings),
          entries=len(bindings), by_receipt=[len(read(p)['files']) for p in receipts])
    candidate = S/'MICROSCOPIC_JOINT_FLOW_PROBE.md'
    check('exact_candidate_identity', sha(candidate) == '35bcb1013b0716a4faa33fdbd75ff067427c1dec8e377f63ebb17ac301786ebd'
          and len(candidate.read_text().splitlines()) == 279)
    check('exact_author_receipt_identity', sha(receipts[0]) == 'afdfaff1e0a1c4a6843cbfd0d49c449d37bed0d62052b967c92ac9c38582984c')

    independent = read(O/'logs/independent_results.json')
    output = [json.loads(x) for x in (O/'logs/independent.stdout.jsonl').read_text().splitlines()]
    check('independent_source_output_binding', independent['source_sha256'] == sha(O/'independent_controls.py'))
    check('independent_complete_stdout_rows', output[:-1] == independent['rows'])
    check('independent_terminal_counts', output[-1] == {'TOTAL': {'PASS': independent['passed'], 'FAIL': independent['failed']}}
          and independent['failed'] == 0 and len(independent['rows']) == 123)
    execution = read(O/'logs/independent.execution.json')
    check('independent_execution_completed', execution['exit_code'] == 0 and not execution['timed_out'] and execution['timeout_seconds'] == 60)
    for name in ['independent.stdout.jsonl', 'independent.stderr.txt', 'independent_results.json']:
        path = O/'logs'/name
        check('independent_execution_output_hash', sha(path) == execution[name]['sha256'] and path.stat().st_size == execution[name]['bytes'], path=str(path))
    reproduction = read(O/'logs/author_reproduction.summary.json')
    check('all_author_replays_verified', reproduction['passed'] and len(reproduction['runs']) == 6)
    for run in reproduction['runs']:
        folder = O/'author_replays'/run['name']
        result = read(folder/'joint_controls_results.json')
        output = [json.loads(x) for x in (folder/'stdout.jsonl').read_text().splitlines()]
        record = read(folder/'execution.json')
        check('author_replay_source_and_outputs_current',
              sha(folder/'joint_controls.py') == run['source_sha256'] == result['source_sha256'] == record['source_sha256']
              and sha(folder/'joint_controls_results.json') == run['result_sha256']
              and output[:-1] == result['rows']
              and sha(folder/'stdout.jsonl') == record['stdout_sha256']
              and sha(folder/'stderr.txt') == record['stderr_sha256'], replay=run['name'])
    report = S/'MICROSCOPIC_JOINT_FLOW_REVIEW.md'
    for link in re.findall(r'\]\(([^)]+)\)', report.read_text()):
        check('report_link_exists', (report.parent/link).exists(), link=link)
    verification = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'checks': CHECKS,
                    'source_bindings': bindings, 'passed': all(c['passed'] for c in CHECKS),
                    'resolved_distribution_mismatch': {'installed_reporting_sha256': sha(installed_reporting),
                                                      'applied_current_reporting_sha256': sha(current_reporting),
                                                      'first_failure_preserved': True}}
    save(O/'final_verification.json', verification)
    if not verification['passed']:
        print(json.dumps([c for c in CHECKS if not c['passed']], indent=2))
        return 1
    paths = [report] + sorted(p for p in O.rglob('*') if p.is_file() and p != O/'receipt.json')
    receipt = {
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'role': 'Independent focused source reviewer of exactly one frozen conditional mathematics candidate',
        'disposition': 'PASS for the stated conditional theorem; PASS WITH BOUNDED CLAIMS for source readiness; no author correction required',
        'review_path': str(report), 'review_sha256': sha(report), 'review_lines': len(report.read_text().splitlines()),
        'target_path': str(candidate), 'target_sha256': sha(candidate), 'target_lines': 279,
        'author_receipt_sha256': sha(receipts[0]),
        'upstream_proof_sha256': sha(S/'MICROSCOPIC_CURRENT_IMPLEMENTATION_PROBE.md'),
        'upstream_review_sha256': sha(S/'MICROSCOPIC_CURRENT_IMPLEMENTATION_REVIEW.md'),
        'upstream_author_receipt_sha256': sha(receipts[1]), 'upstream_review_receipt_sha256': sha(receipts[2]),
        'proof_coverage': [
            'Complete J1-J24 candidate and actual-current I1-I31 source read',
            'Local actions derive invariant D and all finite mixed-word domains',
            'Mixed support-growth estimate, common absolute analytic diamond, degenerate cases',
            'Self-adjoint Taylor remainder, sequential products, finite-word swaps, subdivision and spectral passage',
            'Separate norm thermodynamic limits and canonical GNS implementation',
            'AB argument, cyclic density, faithfulness and canonical phase elimination',
            'Padded finite Jacobi, ordered density sign, support and per-site norm bounds',
            'Complete one-site basis criterion and finite orbit-sum/partial-trace/divergence classification',
            'Exact conservation/nonconservation examples and single-beta negative-clock convention'],
        'findings': {'material_candidate_findings': 0, 'author_source_fixes': 0,
                     'resolved_instruction_distribution_issue': 1, 'remaining_review_obligations': 0},
        'independence': {
            'prior_exposure': 'Candidate/upstream author-result prose and receipt source metadata were visible; no claim of blinding',
            'pre_author_helper_output_freeze_path': str(O/'INDEPENDENT_FREEZE.json'),
            'pre_author_helper_output_freeze_sha256': sha(O/'INDEPENDENT_FREEZE.json'),
            'independent_control_sha256': sha(O/'independent_controls.py'),
            'no_author_helper_imported_into_independent_control': True,
            'mechanisms': 'Gaussian-integer Kronecker matrices on open padded cutoffs; complete qutrit basis and orbit perturbations; weighted 2D support-union dynamic programming',
            'model_and_effort': 'Inherited selected configuration without override; no inferred engine identity claimed'},
        'independent_execution': {'execution_record': str(O/'logs/independent.execution.json'),
                                  'source_sha256': independent['source_sha256'],
                                  'passed_predicates': independent['passed'], 'failed_predicates': independent['failed'],
                                  'timeout_seconds': execution['timeout_seconds'],
                                  'elapsed_seconds': execution['elapsed_seconds'], 'finite_scope_only': True},
        'author_reproduction': {
            'all_complete_rows_and_stdout_exact': True, 'all_failed_and_nondiscriminating_rows_preserved': True,
            'runs': [{'name': x['name'], 'source_sha256': x['source_sha256'], 'total': x['total'], 'failed': x['failed'],
                      'exit': x['execution']['exit_code'], 'elapsed_seconds': x['execution']['elapsed_seconds'],
                      'timeout_seconds': x['execution']['timeout_seconds'],
                      'complete_comparison_path': str(O/'author_replays'/x['name']/'comparison.json')}
                     for x in reproduction['runs']]},
        'source_bindings': {'receipt_entries': 192, 'candidate_entries': 73, 'upstream_entries': 119,
                            'author_directory_files_excluding_receipt': 72, 'all_current': True,
                            'final_verification_sha256': sha(O/'final_verification.json')},
        'instruction_authority': {'main_parent_reported': 'a13caa4885f547c8d206265b031ba7649e539fd9',
                                  'planning_parent_reported': '3a4b2c66a1ead7a1c48b4359627e968f681e3c39',
                                  'planning_blob_sha256': '3d409e93abb3b58796a9c10ca6d21ba93b7edc73b8fb24e7364da97c805580a9',
                                  'current_local_file_bindings_checked': True,
                                  'reporting_distribution_mismatch': verification['resolved_distribution_mismatch'],
                                  'applied_reporting_reference': str(reporting_snapshot),
                                  'additional_obligation_disposition': 'No output handling changed; normal overwrite writes and same-run stdout/JSON preserved; runner_cache unused; no further science execution required'},
        'remaining_supplied': ['Actual self-adjoint boost/current realizations and exact local actions',
                              'Upstream boost closure on the actual D',
                              'Intended-model conservation/cross-current identities; equivalent to strong commutation once J1/J2 are fixed',
                              'Invariant geometric implementation and physical positivity/gap/particle/centre/scattering/exhaustion/completeness assumptions'],
        'verification_limits': ['Finite controls do not prove unbounded domains, thermodynamic convergence or physical applicability',
                                'No audit/retained status, Lean, literature theorem, broad novelty search or unrelated index/scattering certification',
                                'No repository integration/publication pipeline; root owns those operations',
                                'Author-result prose exposure disclosed; administrative tool history is not a complete terminal transcript'],
        'review_iterations': 1, 'writes_scope': ['MICROSCOPIC_JOINT_FLOW_REVIEW.md', 'microscopic_joint_flow_review/'],
        'editable_prompt_files_changed': [], 'git_commands': False,
        'repository_pr_merge_push_audit_axiom_changes': False, 'other_chat_actions': False,
        'model_override': False, 'subdelegation': False, 'campaign_deadline_utc': '2026-10-12T16:00:52Z',
        'next_action': 'Root may reuse this conditional implication at the frozen sources. Reopen affected review if proof, premise, input or interaction changes. No author correction requested.',
        'freeze_exclusion': 'This receipt self-hash only; every other current file under the review directory plus the report is inventoried.',
        'files': [{'path': str(p.relative_to(S)), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in paths]
    }
    save(O/'receipt.json', receipt)
    print(json.dumps({'final_checks': len(CHECKS), 'all_passed': True, 'source_binding_entries': len(bindings),
                      'review_sha256': sha(report), 'review_receipt_sha256': sha(O/'receipt.json'),
                      'review_artifacts': len(paths), 'completed_utc': receipt['recorded_utc']}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
