#!/usr/bin/env python3
"""Independent exact Kronecker and support-state controls; no author imports."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
from collections import defaultdict
from pathlib import Path

import numpy as np
import scipy
from scipy import sparse

ROWS = []
MAX_COEFFICIENT = 0
MAX_OPERATION_BOUND = 0
SAFE = 2**62


def maxabs(a):
    return max((abs(int(x)) for x in a.data), default=0)


def cleaned(a):
    global MAX_COEFFICIENT
    a = a.tocsr()
    a.eliminate_zeros()
    MAX_COEFFICIENT = max(MAX_COEFFICIENT, maxabs(a))
    return a


def safe_bound(bound):
    global MAX_OPERATION_BOUND
    MAX_OPERATION_BOUND = max(MAX_OPERATION_BOUND, int(bound))
    if bound >= SAFE:
        raise OverflowError(f"integer operation bound {bound} exceeds {SAFE}")


def plus(a, b):
    safe_bound(maxabs(a) + maxabs(b))
    return cleaned(a + b)


def times(a, b):
    # Each entry is a sum over at most max row nnz(A) terms.
    terms = int(np.max(np.diff(a.indptr), initial=0))
    safe_bound(terms * maxabs(a) * maxabs(b))
    return cleaned(a @ b)


class GI:
    """Sparse matrices over Gaussian integers, with no floating arithmetic."""
    def __init__(self, real, imag=None):
        self.r = cleaned(sparse.csr_matrix(real, dtype=np.int64))
        self.i = cleaned(sparse.csr_matrix(self.r.shape, dtype=np.int64)
                         if imag is None else sparse.csr_matrix(imag, dtype=np.int64))
        assert self.r.shape == self.i.shape

    def __add__(self, other):
        return GI(plus(self.r, other.r), plus(self.i, other.i))

    def __neg__(self):
        return self.scale(-1)

    def __sub__(self, other):
        return self + (-other)

    def __matmul__(self, other):
        return GI(plus(times(self.r, other.r), -times(self.i, other.i)),
                  plus(times(self.r, other.i), times(self.i, other.r)))

    def scale(self, n):
        assert isinstance(n, int)
        safe_bound(abs(n) * max(maxabs(self.r), maxabs(self.i)))
        return GI(self.r * n, self.i * n)

    def half(self):
        assert all(int(x) % 2 == 0 for a in [self.r, self.i] for x in a.data)
        r, i = self.r.copy(), self.i.copy()
        r.data //= 2
        i.data //= 2
        return GI(r, i)

    def mul_i(self):
        return GI(-self.i, self.r)

    def dagger(self):
        return GI(self.r.T, -self.i.T)

    def iszero(self):
        return self.r.nnz == 0 and self.i.nnz == 0

    def residual(self):
        return {"real_nnz": int(self.r.nnz), "imag_nnz": int(self.i.nnz),
                "entry_l1": sum(abs(int(x)) for a in [self.r, self.i] for x in a.data),
                "frobenius_squared": sum(int(x)**2 for a in [self.r, self.i] for x in a.data)}


def kron(a, b):
    safe_bound(maxabs(a.r)*maxabs(b.r)+maxabs(a.i)*maxabs(b.i))
    safe_bound(maxabs(a.r)*maxabs(b.i)+maxabs(a.i)*maxabs(b.r))
    return GI(sparse.kron(a.r, b.r, format="csr") - sparse.kron(a.i, b.i, format="csr"),
              sparse.kron(a.r, b.i, format="csr") + sparse.kron(a.i, b.r, format="csr"))


def comm(a, b):
    return a @ b - b @ a


def row(name, passed, **details):
    item = {"name": name, "pass": bool(passed), **details}
    ROWS.append(item)
    print(json.dumps(item, sort_keys=True), flush=True)


def qubit_basis():
    return {"I": GI(np.eye(2, dtype=np.int64)),
            "X": GI([[0, 1], [1, 0]]),
            "Y": GI([[0, 0], [0, 0]], [[0, -1], [1, 0]]),
            "Z": GI([[1, 0], [0, -1]])}


def qutrit_basis():
    result = {"I": GI(np.eye(3, dtype=np.int64))}
    for u, v in [(0, 1), (0, 2), (1, 2)]:
        a = np.zeros((3, 3), dtype=np.int64)
        a[u, v] = a[v, u] = 1
        result[f"S{u}{v}"] = GI(a)
        b = np.zeros((3, 3), dtype=np.int64)
        b[u, v], b[v, u] = -1, 1
        result[f"A{u}{v}"] = GI(np.zeros((3, 3), dtype=np.int64), b)
    result["D1"] = GI(np.diag([1, -1, 0]))
    result["D2"] = GI(np.diag([1, 1, -2]))
    return result


class Tensor:
    def __init__(self, sites, basis):
        self.sites = tuple(sites)
        self.basis = basis
        self.d = basis["I"].r.shape[0]
        self.dim = self.d ** len(self.sites)
        self.cache = {}

    def zero(self):
        return GI(sparse.csr_matrix((self.dim, self.dim), dtype=np.int64))

    def word(self, word):
        word = tuple(sorted(dict(word).items()))
        assert all(x in self.sites for x, label in word)
        if word not in self.cache:
            labels = dict(word)
            result = GI([[1]])
            for x in self.sites:
                result = kron(result, self.basis[labels.get(x, "I")])
            self.cache[word] = result
        return self.cache[word]

    def polynomial(self, terms, shift=0):
        result = self.zero()
        for coefficient, word in terms:
            result = result + self.word([(x+shift, a) for x, a in word]).scale(coefficient)
        return result


def h(factory, kind, x):
    if kind == "negative":
        return factory.polynomial([(1, [(x, "Z"), (x+1, "Z")]), (1, [(x, "X")])])
    if kind == "xx":
        return factory.polynomial([(1, [(x, "X"), (x+1, "X")]),
                                   (1, [(x, "Y"), (x+1, "Y")])])
    raise ValueError(kind)


def current(factory, kind, x):
    hx = h(factory, kind, x)
    oriented = comm(hx, h(factory, kind, x+1)) - comm(hx, h(factory, kind, x-1))
    return oriented.mul_i().half()


def negative_controls():
    f = Tensor(range(-3, 4), qubit_basis())
    p = current(f, "negative", 0)
    expected_p = f.polynomial([(-1, [(0, "Z"), (1, "Y")]), (-1, [(-1, "Z"), (0, "Y")])])
    row("negative_current_from_pair_formula", (p-expected_p).iszero(), residual=(p-expected_p).residual())
    pp = f.polynomial([(-2, [(0, "Z"), (1, "Y")])])
    a = f.polynomial([(-1, [(-1, "Z"), (0, "Y")])])
    ta = f.polynomial([(-1, [(0, "Z"), (1, "Y")])])
    row("negative_current_improvement_is_divergence", (p-pp-a+ta).iszero())
    qp = f.zero()
    for y in range(-1, 2):
        qp = qp + comm(h(f, "negative", y), pp).mul_i()
    expected_qp = f.polynomial([(-4, [(1, "X")]), (-4, [(0, "Y"), (1, "Y")]),
                               (-4, [(0, "Z"), (1, "X"), (2, "Z")]),
                               (4, [(0, "Z"), (1, "Z")])])
    row("negative_qprime_direct_density", (qp-expected_qp).iszero(), residual=(qp-expected_qp).residual())
    hh, pp_sum = f.zero(), f.zero()
    for x in range(-3, 3):
        hh = hh + h(f, "negative", x)
    for x in range(-2, 2):
        pp_sum = pp_sum + current(f, "negative", x)
    z0 = f.word([(0, "Z")])
    dh = lambda a: comm(hh, a).mul_i()
    dp = lambda a: comm(pp_sum, a).mul_i()
    nested = dh(dp(z0)) - dp(dh(z0))
    polynomial = f.polynomial([(-8, [(0, "Y")]), (8, [(-1, "Y"), (0, "X")]),
                               (8, [(0, "X"), (1, "Y")]),
                               (-8, [(-1, "Z"), (0, "Y"), (1, "Z")])])
    row("negative_J21_open_padded_nested_derivation", (nested-polynomial).iszero(), residual=(nested-polynomial).residual(), action=nested.residual())
    row("negative_J21_is_nonzero", not nested.iszero(), action=nested.residual())
    jacobi = comm(comm(hh, pp_sum), z0).scale(-1)
    row("negative_Jacobi_sign", (nested-jacobi).iszero(), wrong_sign=(nested+jacobi).residual())
    row("independent_current_sign_mutant_rejected", not (-nested-polynomial).iszero(), residual=(-nested-polynomial).residual())
    row("independent_current_half_mutant_rejected", not (nested.scale(2)-polynomial).iszero(), residual=(nested.scale(2)-polynomial).residual())
    identity = f.word([])
    vacuum = dh(dp(identity))-dp(dh(identity))
    row("vacuum_only_is_nondiscriminating", vacuum.iszero() and not nested.iszero(), vacuum_residual=vacuum.residual(), local_action=nested.residual(), scope="Diagnostic only: a tracial vacuum check cannot establish conservation")
    single = f.word([(0, "Z")])
    selected = comm(single, z0).mul_i()
    rejected = comm(single, f.word([(0, "X")])).mul_i()
    row("selected_observable_is_nondiscriminating", selected.iszero() and not rejected.iszero(), selected=selected.residual(), other_basis_member=rejected.residual())


def xx_terms(x):
    return [(1, [(x, "X"), (x+1, "X")]), (1, [(x, "Y"), (x+1, "Y")])]


def t_terms(x):
    return [(1, [(x, "X"), (x+1, "Z"), (x+2, "Z"), (x+3, "X")]),
            (1, [(x, "Y"), (x+1, "Z"), (x+2, "Z"), (x+3, "Y")])]


def combine(*weighted_terms):
    return [(coefficient*factor, word) for factor, terms in weighted_terms for coefficient, word in terms]


def positive_controls():
    f = Tensor(range(-2, 4), qubit_basis())
    p = current(f, "xx", 0)
    q = f.zero()
    for y in range(-2, 3):
        q = q + comm(h(f, "xx", y), p).mul_i()
    qterms = combine((2, xx_terms(-1)), (-2, xx_terms(1)), (-2, t_terms(-2)), (2, t_terms(0)))
    aterms = combine((2, xx_terms(-1)), (2, xx_terms(0)), (-2, t_terms(-2)), (-2, t_terms(-1)))
    expected = f.polynomial(qterms)
    divergence = f.polynomial(aterms)-f.polynomial(aterms, shift=1)
    row("XX_J22_direct_actual_current", (q-expected).iszero(), residual=(q-expected).residual(), q=q.residual())
    row("XX_J22_nonzero_divergence", not q.iszero() and (q-divergence).iszero(), residual=(q-divergence).residual())
    pad = Tensor(range(-5, 6), qubit_basis())
    qsum, mutant = pad.zero(), pad.zero()
    bad_terms = combine((1, qterms), (2, t_terms(-2)))
    for x in range(-3, 3):
        qsum = qsum + pad.polynomial(qterms, shift=x)
        mutant = mutant + pad.polynomial(bad_terms, shift=x)
    mutant_residuals = []
    for label in ["I", "X", "Y", "Z"]:
        observable = pad.word([] if label == "I" else [(0, label)])
        good = comm(qsum, observable).mul_i()
        bad = comm(mutant, observable).mul_i()
        row(f"XX_complete_basis_{label}", good.iszero(), good=good.residual(), dropped_term=bad.residual(), sites=11)
        mutant_residuals.append(not bad.iszero())
    row("XX_dropped_divergence_term_rejected", any(mutant_residuals))
    # An independently assembled once-oriented current on a nine-site open chain.
    op = Tensor(range(-4, 5), qubit_basis())
    hh, pp = op.zero(), op.zero()
    for x in range(-4, 4):
        hh = hh+h(op, "xx", x)
    for x in range(-4, 3):
        pp = pp+comm(h(op, "xx", x), h(op, "xx", x+1)).mul_i()
    boundary = comm(hh, pp)
    row("XX_open_cutoff_commutator_nonzero", not boundary.iszero(), boundary=boundary.residual())
    for label in ["X", "Y", "Z"]:
        interior = comm(boundary, op.word([(0, label)]))
        row(f"XX_open_boundary_commutes_with_interior_{label}", interior.iszero(), interior=interior.residual())


def orbit_sums(terms):
    result = defaultdict(int)
    for coefficient, word in terms:
        if not word:
            continue
        origin = min(x for x, label in word)
        canonical = tuple(sorted((x-origin, label) for x, label in word))
        result[canonical] += coefficient
    return {str(word): c for word, c in result.items() if c}


def partial_trace(matrix, d, n, factor):
    stride = d**(n-factor-1)
    dimension = d**(n-1)
    def part(component):
        a = component.tocoo()
        r_digit = (a.row//stride) % d
        c_digit = (a.col//stride) % d
        keep = r_digit == c_digit
        rows = (a.row//(stride*d))*stride + a.row%stride
        cols = (a.col//(stride*d))*stride + a.col%stride
        # At most d terms coalesce into an output entry.
        safe_bound(d*maxabs(component))
        return sparse.coo_matrix((a.data[keep], (rows[keep], cols[keep])), shape=(dimension, dimension)).tocsr()
    return GI(part(matrix.r), part(matrix.i))


def qutrit_controls():
    basis = qutrit_basis()
    one = Tensor([0], basis)
    gram = []
    for a in basis:
        line = []
        for b in basis:
            product = basis[a] @ basis[b]
            line.append((int(product.r.diagonal().sum()), int(product.i.diagonal().sum())))
        gram.append(line)
    orthogonal = all(gram[i][j] == (0, 0) for i in range(9) for j in range(9) if i != j)
    nonsingular = all(gram[i][i][0] > 0 and gram[i][i][1] == 0 for i in range(9))
    row("qutrit_complete_Hermitian_basis", len(basis) == 9 and orthogonal and nonsingular and all((m-m.dagger()).iszero() for m in basis.values()), gram=gram)
    f = Tensor(range(-2, 3), basis)
    divergence = [(1, [(0, "S01")]), (-1, [(1, "S01")]),
                  (2, [(-1, "D1"), (0, "S12")]), (-2, [(0, "D1"), (1, "S12")])]
    cases = {"zero": [], "scalar": [(7, [])], "divergence": divergence,
             "scalar_plus_divergence": [(7, [])]+divergence,
             "diagonal_orbit_perturbation": divergence+[(1, [(0, "D2")])],
             "nonadjacent_word": [(1, [(-1, "D1"), (1, "S12")])]}
    for name, terms in cases.items():
        total, kz = f.zero(), f.zero()
        for shift in [-1, 0, 1]:
            total = total+f.polynomial(terms, shift=shift)
            selected = [(c, [(x+shift, a) for x, a in w]) for c, w in terms if any(x+shift == 0 for x, a in w)]
            kz = kz+f.polynomial(selected)
        residuals = {}
        for label in basis:
            a = f.word([] if label == "I" else [(0, label)])
            residuals[label] = comm(total, a).mul_i().residual()
            row(f"qutrit_K0_commutator_matches_{name}_{label}", (comm(total, a)-comm(kz, a)).iszero())
        vanishes = all(v["entry_l1"] == 0 for v in residuals.values())
        orbits = orbit_sums(terms)
        row(f"qutrit_orbit_criterion_{name}", vanishes == (not orbits), orbit_sums=orbits, residuals=residuals)
        pt = partial_trace(kz, 3, 5, 2)
        row(f"qutrit_K0_partial_trace_{name}", pt.iszero(), partial_trace=pt.residual(), K0=kz.residual())
        if name == "diagonal_orbit_perturbation":
            row("qutrit_selected_diagonal_test_misses_perturbation", residuals["D1"]["entry_l1"] == 0 and not vanishes, full_basis=residuals)


def histories(seed, sequence, interactions):
    states = {frozenset(seed): 1}
    for color in sequence:
        new = defaultdict(int)
        for union, weight in states.items():
            for support, normweight in interactions[color]:
                if union.intersection(support):
                    new[union.union(support)] += weight*normweight
        states = new
    return sum(states.values()), len(states)


def history_controls():
    red, blue = [], []
    for x in range(-7, 8):
        for y in range(-7, 8):
            red.append((frozenset([(x, y), (x+1, y), (x, y+1), (x+1, y+1)]), 1))
            blue.append((frozenset([(x, y), (x+1, y)]), 1))
            blue.append((frozenset([(x, y), (x, y+1)]), 2))
    interactions = {"r": red, "b": blue}
    js = {}
    for color, terms in interactions.items():
        per_site = defaultdict(int)
        for support, weight in terms:
            for site in support:
                per_site[site] += weight
        js[color] = max(per_site.values())
    row("two_dimensional_interaction_norms", js == {"r": 4, "b": 6}, per_site_norms=js, cardinality=4)
    failed_nogrowth = 0
    ordered = {}
    for seed in [{(0, 0)}, {(0, 0), (3, 2)}]:
        for sequence in ["r", "b", "rr", "rb", "br", "rrr", "rbr", "brr", "rbbr"]:
            count, states = histories(seed, sequence, interactions)
            a, n = len(seed), len(sequence)
            color_factor = math.prod(js[c] for c in sequence)
            bound = color_factor*math.prod(a+3*k for k in range(n))
            nogrowth = color_factor*a**n
            failed_nogrowth += count > nogrowth
            row(f"weighted_2d_histories_a{a}_{sequence}", count <= bound, weighted_history_count=count, union_states=states, growing_bound=bound, no_growth_competitor=nogrowth, no_growth_rejected=count > nogrowth)
            if a == 1:
                ordered[sequence] = count
    row("two_dimensional_support_growth_mutant_rejected", failed_nogrowth > 0, rejecting_cases=failed_nogrowth)
    row("mixed_history_order_cannot_be_identified", ordered["rb"] != ordered["br"], rb=ordered["rb"], br=ordered["br"])
    singles = {"o": [(frozenset([x]), 3) for x in range(-3, 4)], "z": []}
    for n in range(1, 5):
        count, states = histories({-2, 2}, "o"*n, singles)
        row(f"onsite_entire_history_n{n}", count == 6**n, count=count, exact_bound=6**n)
        zero, unused = histories({-2, 2}, "z"*n, singles)
        empty, unused = histories(set(), "o"*n, singles)
        row(f"zero_and_scalar_histories_n{n}", zero == empty == 0, zero=zero, scalar=empty)


def phase_control():
    basis = qubit_basis()
    x, z = basis["X"], basis["Z"]
    anticommutator = x@z+z@x
    row("discrete_adjoint_phase_diagnostic", anticommutator.iszero() and not comm(x, z).iszero(), scope="Discrete pair only; no continuous one-parameter assertion")
    for label in basis:
        a = basis[label]
        first = x@z@a@z@x
        second = z@x@a@x@z
        row(f"discrete_adjoint_actions_commute_{label}", (first-second).iszero())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    negative_controls()
    positive_controls()
    qutrit_controls()
    history_controls()
    phase_control()
    result = {"source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
              "arithmetic": "pairs of sparse int64 matrices; Gaussian integer tensor arithmetic; guarded operation bounds",
              "maximum_integer_coefficient": MAX_COEFFICIENT,
              "maximum_conservative_operation_bound": MAX_OPERATION_BOUND,
              "safe_bound": SAFE, "rows": ROWS,
              "passed": sum(r["pass"] for r in ROWS), "failed": sum(not r["pass"] for r in ROWS),
              "scope": "Finite controls support but do not prove infinite-dimensional domains or the analytic theorem"}
    Path(args.out).write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({"TOTAL": {"PASS": result["passed"], "FAIL": result["failed"]}}), flush=True)
    raise SystemExit(0 if result["failed"] == 0 else 1)


if __name__ == "__main__":
    main()
