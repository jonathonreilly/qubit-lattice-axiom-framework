#!/usr/bin/env python3
"""Read-only verification of author bindings; isolated replay of exact sources."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
S = ROOT.parent
AUTHOR = S / "microscopic_joint_flow"
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+"\n")


def utc():
    return datetime.now(timezone.utc).isoformat()


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else S/path


def verify_manifest(receipt):
    data = json.loads(receipt.read_text())
    checks = []
    for entry in data["files"]:
        path = resolve(entry["path"])
        exists = path.is_file()
        observed = sha(path) if exists else None
        size = path.stat().st_size if exists else None
        checks.append({"path": str(path), "expected_sha256": entry["sha256"],
                       "observed_sha256": observed, "expected_bytes": entry["bytes"],
                       "observed_bytes": size,
                       "passed": observed == entry["sha256"] and size == entry["bytes"]})
    return {"receipt": str(receipt), "receipt_sha256": sha(receipt), "checks": checks,
            "entries": len(checks), "failed": sum(not x["passed"] for x in checks)}


def main():
    freeze = json.loads((ROOT/"INDEPENDENT_FREEZE.json").read_text())
    assert all(sha(Path(f["path"])) == f["sha256"] for f in freeze["files"])
    receipts = [AUTHOR/"receipt.json", S/"microscopic_current_implementation/receipt.json",
                S/"microscopic_current_review/receipt.json"]
    manifests = [verify_manifest(p) for p in receipts]
    authored = json.loads(receipts[0].read_text())
    source_checks = []
    for entry in authored["source_inputs"]:
        original = Path(entry["source"])
        check = {"path": str(original), "expected_sha256": entry["sha256"],
                 "observed_sha256": sha(original), "bytes_match": original.stat().st_size == entry["bytes"]}
        if "copy" in entry:
            check["copy"] = str(AUTHOR/entry["copy"])
            check["copy_sha256"] = sha(AUTHOR/entry["copy"])
        check["passed"] = (check["observed_sha256"] == entry["sha256"] and check["bytes_match"]
                           and check.get("copy_sha256", entry["sha256"]) == entry["sha256"])
        source_checks.append(check)
    actual_tree = {str(p.relative_to(S)) for p in AUTHOR.rglob("*") if p.is_file() and p != receipts[0]}
    declared_tree = {e["path"] for e in authored["files"] if e["path"].startswith("microscopic_joint_flow/")}
    tree = {"actual_files": len(actual_tree), "declared_files": len(declared_tree),
            "undeclared": sorted(actual_tree-declared_tree), "missing": sorted(declared_tree-actual_tree)}
    integrity = {"recorded_utc": utc(), "manifests": manifests, "source_checks": source_checks,
                 "author_tree_inventory": tree,
                 "passed": not any(m["failed"] for m in manifests)
                           and all(x["passed"] for x in source_checks)
                           and not tree["undeclared"] and not tree["missing"]}
    write(LOGS/"source_bindings.before_replays.json", integrity)
    if not integrity["passed"]:
        print(json.dumps({"binding_failure": True, "report": str(LOGS/"source_bindings.before_replays.json")}))
        return 2

    sources = [("baseline", AUTHOR/"controls/joint_controls.py", AUTHOR/"logs/controls.run1.results.json",
                AUTHOR/"logs/controls.run1.stdout.jsonl", AUTHOR/"logs/controls.run1.stderr.txt",
                AUTHOR/"logs/controls.run1.execution.json")]
    for folder in sorted((AUTHOR/"mutations").iterdir()):
        if folder.is_dir():
            sources.append((folder.name, folder/"joint_controls.py", folder/"joint_controls_results.json",
                            folder/"stdout.jsonl", folder/"stderr.txt", folder/"execution.json"))
    original_baseline = json.loads(sources[0][2].read_text())
    baseline_source = sources[0][1].read_text().splitlines(keepends=True)
    reports = []
    for name, source, resultpath, stdoutpath, stderrpath, execpath in sources:
        original = json.loads(resultpath.read_text())
        old_stdout = [json.loads(line) for line in stdoutpath.read_text().splitlines()]
        old_execution = json.loads(execpath.read_text())
        ast.parse(source.read_text())
        checks = {
            "source_result_binding": sha(source) == original["source_sha256"],
            "source_execution_binding": sha(source) == old_execution.get("source_sha256", old_execution.get("mutant_sha256")),
            "original_stdout_rows_match": old_stdout[:-1] == original["rows"],
            "original_stdout_summary_matches": old_stdout[-1] == {k: original[k] for k in ["total", "failed", "source_sha256"]},
            "original_row_count_matches": len(original["rows"]) == original["total"],
            "original_failures_match": sum(not r["passed"] for r in original["rows"]) == original["failed"],
            "original_stderr_empty": stderrpath.stat().st_size == 0,
            "original_completed": old_execution["status"] == "completed",
            "original_exit_matches_rows": old_execution["exit_code"] == int(original["failed"] > 0),
            "original_timeout_declared": old_execution["declared_timeout_seconds"] == 60,
        }
        destination = ROOT/"author_replays"/name
        destination.mkdir(parents=True, exist_ok=True)
        copied = destination/"joint_controls.py"
        copied.write_bytes(source.read_bytes())
        (destination/"original.execution.json").write_bytes(execpath.read_bytes())
        (destination/"original.results.json").write_bytes(resultpath.read_bytes())
        (destination/"source.diff").write_text("".join(difflib.unified_diff(baseline_source, source.read_text().splitlines(keepends=True), fromfile="baseline", tofile=name)))
        command = [sys.executable, str(copied)]
        started = utc()
        tick = time.monotonic()
        try:
            process = subprocess.run(command, cwd=destination, capture_output=True, timeout=60,
                                     env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
            stdout, stderr = process.stdout, process.stderr
            status, exit_code = "completed", process.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr = error.stdout or b"", error.stderr or b""
            status, exit_code = "timeout", None
        elapsed = time.monotonic()-tick
        (destination/"stdout.jsonl").write_bytes(stdout)
        (destination/"stderr.txt").write_bytes(stderr)
        execution = {"command": command, "cwd": str(destination), "started_utc": started,
                     "timeout_seconds": 60, "elapsed_seconds": elapsed, "status": status,
                     "exit_code": exit_code, "source_sha256": sha(copied),
                     "stdout_sha256": sha(destination/"stdout.jsonl"),
                     "stderr_sha256": sha(destination/"stderr.txt")}
        output = destination/"joint_controls_results.json"
        report = {"name": name, "source": str(source), "source_sha256": sha(source),
                  "original_binding_checks": checks, "execution": execution}
        if output.exists():
            observed = json.loads(output.read_text())
            streamed = [json.loads(line) for line in stdout.decode().splitlines()]
            stable_original = {k:v for k,v in original.items() if k != "recorded_utc"}
            stable_observed = {k:v for k,v in observed.items() if k != "recorded_utc"}
            report["replay_checks"] = {
                "source_copy_exact": sha(copied) == sha(source) == observed["source_sha256"],
                "all_37_rows_exactly_reproduced": original["rows"] == observed["rows"] and len(observed["rows"]) == 37,
                "all_timestamp_independent_fields_reproduced": stable_original == stable_observed,
                "stdout_bytes_exactly_reproduced": stdout == stdoutpath.read_bytes(),
                "stdout_rows_match_result": streamed[:-1] == observed["rows"],
                "stdout_summary_matches_result": streamed[-1] == {k:observed[k] for k in ["total","failed","source_sha256"]},
                "exit_matches_original": exit_code == old_execution["exit_code"],
                "stderr_empty": not stderr,
            }
            report["result_sha256"] = sha(output)
            report["total"] = observed["total"]
            report["failed"] = observed["failed"]
            report["failed_predicates"] = [r for r in observed["rows"] if not r["passed"]]
            report["passing_predicates_nondiscriminating_for_this_mutation"] = [r for r in observed["rows"] if r["passed"]] if name != "baseline" else []
            report["complete_changes_from_baseline"] = [
                {"baseline": a, "mutant": b} for a,b in zip(original_baseline["rows"], observed["rows"]) if a != b]
        else:
            report["replay_checks"] = {"result_created": False}
        report["passed"] = all(checks.values()) and all(report["replay_checks"].values()) and status == "completed"
        write(destination/"execution.json", execution)
        write(destination/"comparison.json", report)
        reports.append(report)
        print(json.dumps({"name": name, "exit": exit_code, "elapsed_seconds": elapsed,
                          "total": report.get("total"), "failed": report.get("failed"),
                          "all_bindings_and_reproduction_match": report["passed"],
                          "failed_predicates": [r["name"] for r in report.get("failed_predicates",[])]}), flush=True)
    summary = {"recorded_utc": utc(), "reviewer_driver_sha256": sha(Path(__file__)),
               "integrity_passed": integrity["passed"], "runs": reports,
               "passed": integrity["passed"] and all(r["passed"] for r in reports)}
    write(LOGS/"author_reproduction.summary.json", summary)
    final_bindings = [verify_manifest(p) for p in receipts]
    write(LOGS/"source_bindings.after_replays.json", {"recorded_utc": utc(), "manifests": final_bindings,
                                                    "passed": not any(m["failed"] for m in final_bindings)})
    print(json.dumps({"receipt_entries_checked": sum(m["entries"] for m in manifests),
                      "author_files_in_inventory": tree["actual_files"],
                      "replays": len(reports), "all_passed": summary["passed"],
                      "final_bindings_passed": not any(m["failed"] for m in final_bindings)}), flush=True)
    return int(not summary["passed"] or any(m["failed"] for m in final_bindings))


if __name__ == "__main__":
    raise SystemExit(main())
