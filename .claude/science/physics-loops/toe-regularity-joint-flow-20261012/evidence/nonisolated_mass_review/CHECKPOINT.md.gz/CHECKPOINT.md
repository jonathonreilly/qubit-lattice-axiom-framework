# Current checkpoint — independent nonisolated-mass review

Target: NONISOLATED_MASS_SCATTERING_PROBE.md (359 lines), SHA256
afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d.
Author receipt SHA256 2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6.
Fixed deadline 2026-10-12 16:00:52 UTC. No model/effort change or delegation.

Complete target, all 673 Dybalski TeX lines, relevant PDF equations, necessary
BDN arguments, and all published prerequisite differences have been read. Exact
unchanged previous full SC/Fock/centre readings are reused with that limitation.
N1–N31 core theorem and N32–N35 beta=1 spectral example are supported. Required
local correction: N36 must explicitly define and use C_beta=H^2-beta|K|^2.
The exact proposed publication paragraph and its algebraic/spectral verification
are frozen in N36_PUBLICATION_REPAIR.json; author source remains unchanged.

Pre-author reconstruction/control frozen 03:29:17 UTC. First independent run
failed a numerical quadrature gate; v2 tightened integration tolerances with
unchanged cases/gates and passed. Full author code/output inspected afterward;
exact scientific reproduction and source-specific check passed. Fourteen actual
helper mutants: 11 rejected, two substantive gate limitations and one benign
weakened bound survived. All sources, outputs and failures are preserved.
The initial reconstruction's preliminary no-defect assessment is superseded by
the explicit post-freeze N36 finding, which was reported promptly to root.

Review complete. Final refresh at 03:42:35 UTC checked 189 exact source bindings,
all 103 author evidence files and preservation of the prior centre report/receipt.
The original TeX exactly matches the downloaded compressed source. The report,
reviewed correction and final receipt form the handoff. The required N36 repair
is prepared and independently verified, but is deliberately not applied to the
frozen author note. Root will source-map it into publication. No further review
work remains unless the proposed correction or another bound argument changes.
No mathematical extension, publication or audit is performed by this reviewer.

Known operational limits: one display combining primary text and the large old
centre receipt was truncated. The full affected Dybalski tail (511–673) was
re-read in an untruncated bounded result. The old receipt was already verified
in its completed review; that truncated redisplay is not new verification.
System Python lacks PyMuPDF; existing primary PDF page renders were inspected
instead. All author helper/output inspection took place after the independent
freeze. Complete download/receipt writer code was read but not reexecuted into
the protected author directory.

Only nonisolated_mass_review/ and the assigned report may be written. Preserve
ISOLATED_CENTRE_FILTERING_REVIEW.md and isolated_centre_review/ unchanged.
No Git/ref/PR/repo/audit/axiom/prompt/other-chat mutations. Editable prompts: none.
