# Controls and their limits

The initial source reconstruction and independent control were frozen at
2026-10-12T03:29:17.490432+00:00, before new author helper/output inspection.
Reconstruction SHA256 e99c69ed3fbb734410d483d1eac8e0707f04f63e36d2f211583a0c2b7c99c32a;
control v1 SHA256 0919557115970d9c83115981e3d61d1b800a0810fa0a6ecb154be9a2ac00d1f8.
The source and prior reviews were visible; this was not a blind review.

The first independent continuum control ran with a 60-second limit, returned 1
in 0.73480 seconds, and retained both complete streams. Its 54 direct detuning
quadratures passed, but one finite-difference convergence ratio was
3.795938750495109, below the frozen gate 3.8. The squared error was approaching
the quadrature absolute tolerance. V2 tightened only the integration tolerances
from absolute 2e-12/relative 2e-11 to 2e-20/2e-12; cases, formulas and acceptance
gates were unchanged. That amendment was frozen before author inspection.

V2 returned 0 in 0.51070 seconds with empty stderr. All 54 scaling comparisons
had relative discrepancy at most 4.44e-16. Continuous-measure finite differences
had step-halving error ratios 3.99723–3.99997. Omitted width errors were
0.03930–0.07274; omitted centre errors 0.02707–0.11522, versus final correct
errors 1.59e-7–9.85e-7. The analytic direct-integral calculation proves the
two-sided derivative power, including a nonintegrable exponent 0.45, while the
vacuum error has positive exponent 0.15. The exact finite tensor-product error
goes to zero for the three slow widths 0.2, 0.25, 0.3. Numerical sampling is a
corroboration; the infinite-T statement is the explicit power-law formula.

The distinct two-site matrix control gives equal-time commutator norm 0,
unequal-time norm 1.540912893841582, and common-time transport identity error
6.93e-16. It rejects identifying the two averaging times. It does not measure
infinite-lattice LR tails. Neither auxiliary model is offered as a realization
of all theorem premises.

After the freeze and independent runs, the full author helper and ten output
records were inspected. Its exact reproduction returned 0 in 0.04566 seconds
under a 60-second limit. Both stdout and stderr are byte-identical to the
frozen author streams. The read-only author source checker returned 0 in
0.64334 seconds under 60 seconds, rechecking 27 original/frozen source records,
15 pinned instruction files, all 39 predecessor artifacts, and 36 equation tags.
Its current worktree context differs from the author's historical inventory;
the bound input bytes do not. The proof does not depend on global cleanliness.

Independent inventory verification checked the note plus all 103 author evidence
bindings and found no unlisted author files outside the declared self-reference
exclusions. Original and frozen paths in all 27 reading records were rehashed.
The 48,420-byte historical source-check JSON was parsed completely; no truncated
display is verification. The failed historical global-cleanliness check is
preserved, as are the predecessor stream-disconnect record and bad layout
extracts. The render warning file has exactly 17,872 lines in two distinct
classes: one fontconfig configuration error and 17,871 Type-3 glyph bounding-box
warnings. Original TeX and visually checked equations supply source reading.

All actual author-code mutants and exact changes, timing, declared 15-second
limits, exits and full streams are under `controls/author_mutations/`.
`AUTHOR_MUTATION_RESULTS.json` records 11 rejected defects and three survivors.
The two useful nondiscriminating cases and the benign inequality weakening are
described in POSTAUTHOR_FINDINGS.md. The author helper is not a proof of the
common-kernel induction, energy-word bounds, unequal-time locality, refinement,
infinite tail, or general-beta Casimir identity.

The supplemental exact general-beta control was added after a final literal
source reread. It explicitly binds the source's actual definitions and checks
48 rational cases. It distinguishes the unweighted inherited definition from
the required weighted one. This supports the narrow N36 repair and is recorded
as a post-author-inspection control, not part of the initial independence claim.

The source-download/extraction and receipt-building scripts were fully read but
were not reexecuted: they write the protected author packet, and the downloaded
versioned primary bytes and every saved evidence binding are already frozen.
No source download, whole-paper BDN rereview, prior-science rerun, audit, Lean
assertion, or physical realization is claimed by these controls.
