# Independent reconstruction, before new author helper/output inspection

Review target: `NONISOLATED_MASS_SCATTERING_PROBE.md`, all 359 lines,
SHA256 `afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d`.
This document is frozen with the separately written continuum/two-site control
before opening any new author helper, author numerical stdout, or author self-check.
The target text, its descriptions of author tests, receipt filename/hash and
top-level key names, file inventory, all primary source text, and prior reviews
were visible. This is source independence, not a blind review. Root proposed the
route and is a coauthor; root is not counted as a reviewer.

## Scope and source identities

The frozen author receipt is SHA256
`2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6`.
Dybalski hep-th/0412226v4 was read in full from all 673 original TeX lines,
SHA256 `c425cfecc20136576180271a1e8e9c12df48ded2ae941655ad4e842363ee64a6`.
The PDF SHA256 is
`3c616a4d6c8b52793bb669387a237de31ee66417450ddc5f29b7c93ece7b534d`;
the already saved page renders 2, 3, 6, 7, 8 were visually checked against the
TeX equations. They are primary-source derivatives, not author control outputs.
No malformed large layout extraction is evidence for this review.

BDN v2 PDF SHA256
`3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126`:
full saved texts of pages 6, 7, 10, 11, 12, 14, 15, 16, 38–43 were read here.
They cover the finite-range interaction/LR framework, full-operator transfer,
almost locality, energy bounds, compact packets, and complete appendices B/C.
The candidate independently proves the adaptations that use unequal times.

Prior full direct readings of SC, Fock and centre notes are reused at their exact
unchanged hashes, not counted as new independent reviews. Original SC hash
`d1d8ace7a450e0c00d780443f83a333223fff395b170994a83e1b65653302a4a`;
published SC `3adc57d0236fced52704aa76e4fa7d38abbe08204623162c8fd07404a2a44a05`.
Original Fock `9bc3a309e8fc35978bcac0c360b8557fb6a3c4484cfc2034a277a94072369404`;
published Fock `494c283c163e88f959841462bbfbcfcc7c470072a0525d0dd6e2b44dd6f9b12b`.
The complete original-to-published diffs were read. Changes are publication
metadata, source/review provenance, whitespace, and the already reviewed SC EX
scope repair. The load-bearing F7–F9 argument was reread completely. Centre
note `1dcb9580d128d8fc41b76517ce0fe18842291e8e32681fa9c6b22f0feb1e13de`
and its completed frozen review remain unchanged. No Fock Gram formula, density,
detector theorem, or downstream completeness statement is a premise here.

Instruction authority remains pinned main
`a13caa4885f547c8d206265b031ba7649e539fd9` and planning
`3a4b2c66a1ead7a1c48b4359627e968f681e3c39`. The previously read exact instruction
copies are reused; the review skill was additionally refreshed here. Local
branch `main` is stale and is not authority. Concurrent SW HEAD is contextual,
not a requirement for global cleanliness. All new writes are confined to this
review folder and the single assigned report; the completed centre report and
receipt are preserved.

## What the theorem actually assumes

N1 supplies an actual norm-continuous automorphism group on the quasi-local
finite-dimensional-site lattice algebra, implemented by positive H and commuting
with geometric shifts T_x=exp(-ixQ). Translation invariance and finite range with
bounded interaction norm give an exponential LR estimate. N2 supplies an invariant
unique gapped vacuum. The proof below only needs positivity plus the stipulated
vacuum; it conservatively retains N2 and does not advertise a massless-vacuum
extension.

N3–N4 supply a reducing graph sector E1, a compact single-lift smooth momentum
chart, and the specified positive dispersion. E1 commutes with H and Q, and its
restriction to the packet support is in ker(H-Sigma(Q)). These are supplied
one-particle data. A global smooth extension of Sigma from a neighbourhood of
the compact chart exists by a smooth cutoff; nothing outside packet support
enters the vacuum vector. The square-root formula is more than the existence
argument needs, but no reduction to an actually realized microscopic law follows.

N5 is about the full temporal Arveson spectrum of B, not just B Omega. It supplies
an interval [epsilon,L] inside positive energy, almost locality, and smooth
almost-local time derivatives. A vacuum spectral column cannot supply the
uniform bounds on excited inputs used later.

N6 fixes Fourier signs. N7 is vector-specific geometric detuning regularity:
for r=(1-E1) fhat(Q) B Omega and D=H-Sigma(Q),
||1_{|D|<=eta} r|| <= c eta^a, a>0. The interval is closed at zero. Spectral
continuity from above then gives 1_{D=0}r=0. A punctured estimate would not.
N7 neither establishes existence nor density of regular nonzero creators.
N8 supplies a positive separation between compact velocity supports for every
pair of distinct labels. N9 supplies h in Schwartz, compact smooth hhat with
hhat(0)=1. Positivity of h is unnecessary because all operator estimates use
absolute L1 norms. N10 uses fixed exponents 0<nu<1 and either common sign sigma.
There is no uniform assertion as n grows, separation shrinks, or nu approaches
the endpoints. Mixed incoming/outgoing products are outside this statement.

## Filters and full operator energy transfer

For k(t)=(2pi)^-1 int exp(-iEt)chi(E)dE and
b(x)=int exp(ipx)zeta(p)dp/(2pi)^d, a matrix coefficient from (Ein,qin) to
(Eout,qout) is multiplied by chi(Eout-Ein) zeta(qout-qin).
This checks the time/spatial signs using Ad(exp(itH)exp(-ixQ)). On Omega the
incoming spectral point is zero, so the column is chi(H)zeta(Q)A Omega.
Because E1,fhat(Q),chi(H),zeta(Q) commute, choosing cutoffs one on the target
graph preserves the exact target. Bounded commuting multipliers preserve the
same N7 exponent and change only its constant. They cannot create regularity.

Convolution under a second smearing puts the *operator* transfer in the cutoff
support. The spectral transfer lemma then gives B P_R into P_{R+L} and B* P_R
into P_{R-epsilon}. The latter is zero if R<epsilon. Finite linear combinations,
norm integrals, translations, time evolution, and time derivatives preserve the
fixed temporal interval; derivative multiplication by energy does not enlarge it.

For a local seed supported in a fixed X, the conditional-expectation LR error at
padding r is C |X| ||A|| exp[-lambda(r-v|t|)]. To localize its Schwartz smearing
in radius R, first restrict |x|+|t|<=cR with c small relative to 1+v. After
geometric displacement and LR growth the remaining padding is at least R/2 for
large R. The integral over this restricted region is exponentially small. The
discarded region is bounded by 2||A|| times absolute Schwartz tails, hence by
every inverse power of R. Integrating exp(v|t|) over an unrestricted Schwartz
kernel is neither necessary nor justified. The same split with (-partial_t)^m k
proves almost locality of every norm time derivative. Direct-property creators
can also be used; their hypotheses must be established separately.

## Finite-energy lemma reconstructed without an isolated graph

Set L_x=tau_x(B*), S=sum_z ||[B*,tau_z B]||. Almost locality, choosing two local
approximants of radii below |z|/2, makes S finite. Let Pcal_r be the common kernel
of every ordered r-fold word in all L_x, not the kernel of one power L_0^r.
Then L_x Ran(Pcal_r) is contained in Ran(Pcal_{r-1}). For finite Lambda let
Q=sum_x L_x* L_x. Expanding its square yields

<Phi,Q^2 Phi> = sum_xy <L_x Phi,[L_x,L_y*]L_y Phi>
                 + sum_xy <L_y L_x Phi,L_x L_y Phi>.

The commutator matrix has both row and column absolute sums bounded by S, so
the first term has modulus <= S <Q>. Cauchy-Schwarz on the complete (x,y) sum
and relabelling bounds the second by sum_xy ||L_y L_x Phi||^2. The common-kernel
inclusion bounds this by b_{r-1}<Q>, where b_r=||Pcal_r Q Pcal_r|| and b_1=0.
For unit Phi, <Q>^2<=<Q^2>; division if <Q>>0, followed by the supremum, gives
b_r <= b_{r-1}+S <= (r-1)S. Mixed negative transfers show P_R is contained in
Pcal_r once r epsilon>R. Taking r=floor(R/epsilon)+1 proves Gamma_B(R)<=
floor(R/epsilon)S. Monotone bounded positive compressed sums have a strong
limit. No exact shell, gap above a shell, or constant vacuum vector was used.

Parseval fixes ||f_t||_2=F2. Vector Cauchy-Schwarz bounds C(t)* P_R by
F2 sqrt(Gamma_B(R)). To dualize the creator, its output from P_R lies in
P_{R+L}; this padding is indispensable. Thus ||C(t)P_R||<=
F2 sqrt(Gamma_B(R+L)). Commutation of P_R with H removes the common time.
The averaged bound acquires ||h||_1 and is otherwise uniform in T.

For any prescribed finite word (including mixed comparison families and
adjoints), R*=R+sum L_j bounds every intermediate energy. Insert P_R* at each
stage and multiply the individual creator/annihilator bounds. This accounts
for *all* spectators. Sums/differences use the triangle inequality and the
larger finite ceiling. Applying unrestricted polynomial norms to a slowly
vanishing vacuum vector would not establish convergence.

## Vacuum limits and exact derivatives

Fourier inversion gives C(t)Omega=exp(itD)v. Substituting t=sigma T+s u gives
A(T)Omega=exp(i sigma T D) hhat(sD)v. The target is fixed because D psi=0 and
hhat(0)=1. The residual has no zero atom. Dominated spectral convergence gives
the vacuum limit for every s going to infinity, even without a rate. Compact
support hhat subset [-b,b] and N7 improve it to O(s^-a).

At fixed physical t,
partial_T g = -s^-2 {sigma h'(u)+s'[h(u)+u h'(u)]}.
The absolute integral is bounded by s^-1||h'||_1+|s'|s^-1||h+u h'||_1.
In the substituted integral instead differentiate C(sigma T+s u):
A' = int h(u)(sigma+s'u) [C(delta_H B,f)+C(B,-i Sigma fhat)] du.
The physical generator and packet clock are both required. Integrating by parts
connects these formulas; polynomial norms and Schwartz decay kill boundaries.
Norm differentiability follows locally in T by dominated norm differentiation;
no moving spatial collar is differentiated.

On the vacuum the exact derivative is
exp(i sigma TD)[i sigma D hhat(sD)+s'D hhat'(sD)]r.
Each multiplier is supported in |D|<=b/s and bounded by a constant/s.
The N7 bound therefore gives c b^a(a0+|s'|a1)s^(-1-a).
Since s'=nu T^(nu-1) is bounded for T>=1, this is O(T^(-nu(1+a))).
The width term is smaller asymptotically but nonzero; dropping it is a wrong
identity. The residual derivative remains in P_L by full temporal transfer.

## Unequal-time lattice locality

For a fixed pair take max(nu_i,nu_j)<mu<1. Restrict t,u independently to
|t-sigma T|,|u-sigma T|<=T^mu. Both |t| and |u| are comparable to T, their
difference is O(T^mu), and positions in disjoint compact velocity collars have
distance at least delta T-C T^mu. This also holds for the negative common sign.
The operator-norm identity is
||[alpha_t tau_x B_i,alpha_u tau_y B_j]|| =
||[tau_x B_i,alpha_{u-t}tau_y B_j]||.
It is essential to remove the common time before LR. Replacing B_i,B_j by
radius delta T/16 local approximants costs O(T^-N) for every N. Remaining local
supports have separation >=3 delta T/8. LR gives a polynomial volume prefactor
times exp[-lambda(3 delta T/8-2v T^mu)], rapidly decreasing since mu<1.

Repeated integration by parts in p outside a smooth velocity collar has phase
gradient bounded below by c(|x|+|t|). Compact amplitude/dispersion derivatives
give every inverse power and summing d additional powers gives an l1 tail of
O(|t|^-N). The inside collar has O(|t|^d) sites and bounded Fourier integrals.
No Hessian hypothesis is needed for these deliberately loose l1 estimates.
Two packet sums cost T^(2d), absorbed by arbitrary N.

For the time tail, t=sigma T+T^nu z and nu<mu give |z|>T^(mu-nu).
Because 1+|t|<=C T(1+|z|) for T>=1, integration against any Schwartz k gives
O(T^[d-(mu-nu)N]) for arbitrary N. The other full packet costs T^d. Derivative
kernels are h', h+zh', with bounded coefficients -sigma/s,-s'/s, so the same
estimate covers one or both averaged derivatives, and absolute weights cover
adjoints. Every two-label commutator is O(T^-P) for arbitrary P. The proof does
not require individual packet speeds smaller than the LR velocity; only
sublinear *relative physical time* enters the relevant bound.

## Cook convergence with every factor retained

Leibniz differentiation followed by moving A_i' rightwards gives one term for
every i<j with [A_i',A_j] and exactly n-2 remaining factors in their original
relative order. It also gives a residual term with all n-1 other factors acting
on A_i'Omega. The first class is bounded by T^-P T^[d(n-2)]; choose P>d(n-2)+2.
The residual vector lies in P_L_i, so the full n-1 spectator word is uniformly
bounded by the finite-energy lemma. Thus
||Psi'|| <= K T^-2 + sum_i K_i T^[-nu_i(1+a_i)].
All terms are integrable for reference exponents nu_i>1/(1+a_i). Integrating
from T to infinity gives N31 with each correct denominator and exponent.
For n=1 only the residual term remains; for n=0 the vector is constant.
Adjacent permutations differ by a rapid commutator times n-2 polynomial
spectators, hence have the same limit. Nothing here computes a multiparticle
norm or proves that a nonzero set of targets produces a nonzero product.

## Creator comparison, refinement, and all fixed 0<nu<1

A zero target implies A_i(T)Omega tends to zero, not that it is identically
zero at finite T. Move the factor to the right within its internally separated
family, discard rapid commutator errors with every spectator, and apply the
finite-energy word bound to the final residual. The product tends to zero.

For cross-compatible families with equal ordered targets, telescope their
products. Each difference Z_i is a sum of two creators and its vacuum vector
tends to zero within a fixed finite-energy ceiling. Every commutator needed to
move it right is rapid; the other word is uniformly energy-bounded. Thus the
product difference tends to zero, even if one of the product limits was not
previously established.

For merely internally separated families, common graph assignments matter.
The compact Q-spectral support S_i of their common nonzero target lies in both
packet supports. Its velocity image is therefore separated from every other
label's support in either family. Compactness permits a smooth q_i equal to one
near S_i, supported in a sufficiently small neighbourhood inside the common
chart whose velocity image avoids all those other supports. Replace the first
family's amplitude by q_i fhat_i. The discarded *actual packet*, with amplitude
(1-q_i)fhat_i and unchanged B/kernel/width, has zero target and velocity support
inside the original support. Bounded Q multipliers preserve regularity and the
absence of an extra kernel atom. Telescope original and refined products; all
other factors still lie in their original supports, so the zero-target proof
applies. This is a vector estimate, not an assertion that unchanged operators
have smaller velocity support or small norm. The refined family is now
cross-compatible with the full alternative family. This supplies the step
that should not be inferred just from the abbreviated cross-family commutation
in Dybalski Lemma 2.4.

Choose a regular reference exponent for every label. Its product limit exists
by Cook, and the comparison transfers it to *any fixed* exponents in (0,1) and
any allowed kernel. A family known only to have no extra zero atom can be
compared to an existing regular realization of the same targets; this does not
prove existence for arbitrary unregularized targets in the absence of a
reference realization. No endpoint nu=0 or nu=1, variable nu(T), different
graph assignments, raw overlapping products, or uniform channel conclusion is
proved.

## Spectral counterexamples and conversion checked directly

The finite zero-detuning example has E1 selecting just one of two degenerate
states on the graph. Punctured residual neighbourhoods are empty, but averaging
preserves the unwanted degenerate component exactly. N7 rejects it. It is an
abstract spectral control and does not realize the lattice hypotheses.

In the infinite example n>=2, J=[1/4,1/2], H_n=sqrt(1+p^2)+exp(-n^2),
K_n=p+1/n. Subtracting C=H^2-K^2 from 1 gives
2p/n+1/n^2-2sqrt(1+p^2)exp(-n^2)-exp(-2n^2).
Multiplying the positive correction terms by n gives less than 1/10, whereas
2p>=1/2. Thus 2/(5n)<=|C_n-1|<=3/(2n), with negative signed C_n-1 and
C_n>=1-3/(2n)>=1/4. The target is exactly the C=1 projection and the vacuum
is unique and separated by positive energy. For r_n=a(p)/n, the small-C norm
squared is bounded by a sum over n>=2/(5eta), hence O(eta); the norm exponent
is 1/2. At geometric eta_N=exp(-N^2), the residual norm squared is the entire
tail sum n>=N, at least int_N^infinity x^-2 dx=1/N. Its norm dominates every
eta_N^a. More generally the tail is comparable to (log(1/eta))^-1/4 in norm.

The centre character is 0 on the exact mass sector, and 1/n off it. Every
continuous multiplier phi with phi(0)=1 has |phi(1/n)|>=1/2 eventually, so even
a smooth compact centre filter cannot remove the slow residual tail. A fixed
positive temporal cutoff one on the displayed bounded energies cannot either.
These facts refute only the implication from the stated commuting spectral
data; no UHF algebra, finite-range dynamics or almost-local creator was
constructed. Additional microscopic information could change the conclusion.

For the sufficient conversion, suppose the selected K lift identity holds on
the *whole* residual vector. Then C-M^2=D(H+Sigma). The factors strongly commute,
and the latter is bounded above and bounded away from zero on the bounded
positive-energy compact patch. The inclusion |D|<=eta => |C-M^2|<=C eta,
with a matching kernel projection, transports a mass regularity bound to N7.
A selector known only on the exact mass sector does not furnish this identity
off that sector. No common q, global centre identity, density, ND, EX, Lorentz
covariance, Fock factorization, or physical realization follows.

## Distinct decisive control frozen here

The new `continuum_time_width_control.py` uses a direct-integral residual model
with spectral density 2a r^(2a-1)dr on (0,1), rather than the author's advertised
finite-frequency/algebraic checks. Choose a real smooth compact bump
g(y)=exp[-y^2/(1-y^2)] for |y|<1, g=0 otherwise. It is hhat and g(0)=1.
With s=T^nu, direct substitution y=sr proves exactly, for s>=1,

||A(T)Omega-psi||^2 = I0 s^(-2a),
||A'(T)Omega||^2 = s^(-2a-2) [I2+(s')^2 J2],

where I0=2a int_0^1 y^(2a-1)g(y)^2dy,
I2=2a int_0^1 y^(2a+1)g(y)^2dy>0,
J2=2a int_0^1 y^(2a+1)g'(y)^2dy>0.
There is no cross term because centre and width multipliers are respectively
imaginary and real after the common phase is removed. The exact derivative
therefore need not be integrable when nu(1+a)<=1; its norm has two-sided leading
power T^[-nu(1+a)]. Nevertheless the vacuum residual tends to zero for every
nu>0. Taking finite tensor products yields exact error squared
product_i(1+I0_i T^[-2a_i nu_i])-1, showing simultaneous slow-width convergence
with uniformly bounded spectators despite nonintegrable direct Cook norms.
This auxiliary spectral model is not claimed to realize the lattice premises.

The independent script numerically integrates in the original detuning variable,
compares the exact scaling constants, and checks a direct finite-difference
derivative over the continuous measure at successively halved steps. It must
discriminate omission of width and omission of centre terms. It also checks
tensor-product error bounds and an added zero atom. A separate two-site spin
Hamiltonian, with initially commuting different-site observables, gives an
exactly vanishing common-time commutator and a nonzero unequal-time one; direct
matrix exponentiation checks the transport identity in N28. This control
rejects identifying the two independent times but cannot establish infinite
lattice LR estimates. The mathematical locality proof above is the evidence
for those estimates. Constants, cases, tolerances, and timeouts are frozen in
the code before inspecting author helper/output. Failures will be preserved.

Pre-author mathematical assessment: no blocking defect found in N1–N36. This
is provisional until the frozen author evidence and source bindings are checked.
Finite control success would corroborate its named identities, not replace the
analytic proof or establish any physical premise.
