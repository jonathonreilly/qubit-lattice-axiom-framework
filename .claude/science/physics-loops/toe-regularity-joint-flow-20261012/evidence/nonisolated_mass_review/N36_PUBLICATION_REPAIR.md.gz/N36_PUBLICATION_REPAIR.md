# Exact reviewed N36 publication replacement

There is a precise sufficient conversion route. For this general-beta statement, define \(\mathcal C_\beta:=H^2-\beta|K|^2\), using the same \(\beta\) as the dispersion. If a current momentum K strongly commuting with H and Q is supplied and, on the whole residual vector under consideration (including off-mass components), one has the selected lift relation \(K=Q+\theta+2\pi n\) and \(\Sigma(Q)^2=M^2+\beta|K|^2\), then
\[
\mathcal C_\beta-M^2=(H-\Sigma(Q))(H+\Sigma(Q)).                    \tag{N36}
\]
On the residual vector's bounded positive-energy support and compact patch, \(H+\Sigma(Q)\) is bounded above and away from zero. A regularity bound for \(\mathcal C_\beta-M^2\) and matching zero-kernel projection then convert to (N7) by the spectral theorem. A selector proved only on the exact mass space does not supply this off-mass identity. We do not rule out deriving it in a stronger model.

Only replace the source paragraph at lines 341–345 with the text above. The frozen author note is unchanged. N36_PUBLICATION_REPAIR.json binds the exact old/new strings and verifies the algebra and spectral conversion.
