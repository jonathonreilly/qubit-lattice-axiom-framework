# Independent nonisolated-mass review history

This was a fresh bounded task in the same reviewer context after completion of
the separate centre review. The previous report and receipt remain frozen.
Root is a coauthor and was not counted as independent review. No subagent,
model/effort override, Git/ref/index/repository, PR/publication, audit, axiom,
primitive, prompt or other-chat action was taken. The one finding was reported
through the parent collaboration channel; no external chat was messaged.

Source inspection began by 2026-10-12 03:18:26 UTC. Target, receipt and TeX hashes
were checked, author directory names/sizes and receipt top-level key names were
visible, but new author helpers and numerical results remained unopened. The
target was read in contiguous slices 1–130, 131–250, 251–359. Dybalski TeX was
read in slices 1–180, 181–340, 341–510, 511–673. A combined result with the large
old centre receipt exceeded the outer display budget; the full affected TeX
tail 511–673 was explicitly reread in a bounded untruncated call. The old receipt
had already been verified in its completed task; its redisplay was not counted
as verification. The initial inventory and read calls are represented by their
exact preserved source files and the recorded coverage, not invented execution
timestamps. Scientific executions from the freeze onwards all have full wrapper
records with command, timeout, start/end, elapsed time, exit and complete streams.

Pinned repository instruction copies from the prior review were reused at main
a13caa4885f547c8d206265b031ba7649e539fd9 and planning
3a4b2c66a1ead7a1c48b4359627e968f681e3c39. Seven principal pinned blobs were directly
rehash-checked in the pre-author freeze. The full review skill was already read
in the prior coherent review and its first 210 lines additionally refreshed here.
The selected user model and effort take precedence over skill profile defaults.
The user write/delegation restrictions take precedence over optional workflow
operations. Old SC/Fock/centre full readings were reused only at exact hashes;
complete original-to-published diffs and full F7–F9 were inspected here.

Dybalski's complete original source and PDF page renders 2,3,6,7,8 were read.
The system Python probe found no PyMuPDF; it made no changes. Existing primary
page renders were used for visual equation checks. No malformed megabyte layout
extract was used as a substitute for mathematical reading. The relevant complete
BDN passages in pages 6,7,10,11,12,14,15,16,38–43 were read.

At 03:29:17.490432 UTC the independent reconstruction and distinct continuum/
two-site control were frozen. The initial independent run failed one numerical
integration convergence gate at 03:29:18.282011 UTC. Both streams, code and
failure are preserved. Only quadrature tolerances were tightened in a separately
frozen v2, with identical scientific cases and acceptance gates. Its run passed
at 03:29:52.934213 UTC. Neither version used new author helper/output contents.

Only after that freeze and independent run was the new author helper, all ten
records, self-check, operations, current/pre-recovery checkpoints, source/reading
ledgers and full supporting script code inspected. The complete author receipt
and all evidence bindings were independently checked. The original source
download and receipt-building writers were read but not rerun; the author inputs
are protected and their exact bytes are bound. Primary downloads are not new
scientific experiments. The historical failed source check, all retry output,
disconnect recovery and extraction warnings are retained.

At 03:31:57.661708 UTC the exact author scientific helper reproduced with
byte-identical streams. At 03:31:58.378338 UTC the read-only source checker also
passed, verifying the named inputs at current SW HEAD dc7f415f73df3754653f4985382ca0fb96f07cda.
The historical author HEAD f6f4348151734908dea3b32048ee1f36f694035b and its 353
untracked root-package paths are history, not current proof inputs. Origin/main
remained pinned a13caa48; stale local main was not used as authority.

Fourteen exact-source helper mutations were run with individual 15-second limits
inside a 60-second parent wrapper, completed at 03:33:16.730104 UTC. Eleven
defects were rejected. Removing both compensating energy-expansion terms,
replacing detuning by zero, and weakening a padded bound all survived; their
limits are explicitly assessed rather than discarded or called successful
scientific discrimination.

A final literal reread of N36 exposed the general-beta Casimir definition
ambiguity. The initial reconstruction had implicitly used the weighted C; its
preliminary no-defect assessment is preserved and superseded by
POSTAUTHOR_FINDINGS.md. The parent was promptly told that the core theorem and
beta=1 counterexample are unaffected, while the general-beta clause needs a
definition repair. Parent agreed to preserve the frozen author source and
source-map the reviewed correction into publication. The exact scalar witness
and 48 rational cases completed at 03:37:30.749600 UTC. The exact proposed
paragraph was algebraically and spectrally checked at 03:38:29.096415 UTC and
bound in N36_PUBLICATION_REPAIR.json. These supplemental controls are explicitly
post-author-inspection.

The final review separately classifies N1–N31, N32–N35, and corrected N36. At
03:42:35.578458 UTC the source-specific final refresh completed successfully:
189 exact bindings, all 103 author evidence files, unchanged prior centre report
and receipt, and exact TeX identity with the downloaded source archive. The
report was then read fully. A final output receipt and its verification complete
the bounded review; wrapper logs carry their exact timestamps.
Only the assigned review report and nonisolated_mass_review/ were written.
Editable prompt files changed: none. Deadline remains 2026-10-12 16:00:52 UTC.
