# Post-freeze findings and exact repair

The core existence/comparison proof N1–N31 remains supported. One narrow
definition clarification is required before the last conversion paragraph is
reused for general beta. This supersedes the preliminary no-defect assessment
in the frozen pre-author reconstruction; that file is deliberately not edited.

At source line 318 the beta=1 example defines `C=H^2-K^2`. Lines 341–345 then
state the conversion with `Sigma^2=M^2+beta|K|^2` and reuse the same symbol C in
N36 without declaring its general-beta definition. If beta is still restricted
to 1 throughout that paragraph, N36 is correct but the general conversion has
not been stated. Under the natural general-beta reading, the only explicitly
defined C gives a discrepancy `(beta-1)|K|^2`. For beta=2, M=K=1, H=2, the
literal left side is 2 and the right side is 1. This is an exact scalar control,
not an approximate numerical disagreement.

The minimal repair is to define a distinct general-beta symbol immediately
before the conditional sentence at line 341, then use it in N36 and the
regularity sentence:

> For this general-beta statement, define \(\mathcal C_\beta:=H^2-\beta|K|^2\), using the same \(\beta\) as the dispersion.

Replace the left side of N36 by `C_beta-M^2` and specify a regularity bound for
`C_beta-M^2` in the next sentence. With that definition, N36 is the exact
factorization `H^2-Sigma^2`, and the
subsequent bounded positive factor/zero-kernel spectral argument is valid. No
core theorem premise, proof, or beta=1 counterexample changes. Alternatively,
explicitly restrict this paragraph to beta=1. The report recommends the first
repair because the rest of the note permits arbitrary beta>0. The exact complete
old/new paragraph and its byte binding are in N36_PUBLICATION_REPAIR.json.

The pre-author reconstruction implicitly read C with the weighted general-beta
definition. A final literal source reread exposed that the definition was not
actually present. The discrepancy was reported promptly to the parent as a
source correction; the frozen target was not edited. The supplemental exact
control is explicitly post-author-inspection, and is not mislabelled as part of
the initial independent freeze.

No other required mathematical correction was found in the bounded review.
The author-helper limitations below do not obstruct the independently checked
analytic proof:

- The N16 word check survives deleting both compensating terms, leaving a
  copied left-hand expression. Its successful output alone cannot verify that
  the source's commutator and inner-product terms were mapped correctly. The
  reconstruction explicitly maps and bounds those terms.
- The finite N33 check survives replacing every detuning by zero. It checks the
  Casimir inequalities, not the strictly positive sequence or logarithmic
  detuning tail in N35. Those were checked by the infinite-series argument.
- Replacing the padded Gamma value 1 by 2 survives because it weakens a valid
  inequality. This is expected and is not evidence of a defect. That control
  uses the analytic hard-core orthogonality values, not an independently formed
  finite Hamiltonian or an infinite-volume energy-bound calculation.

All 14 exact helper mutants are retained: 11 intended defects were rejected,
the two limited gates above survived, and the valid weakened inequality survived.
No count of successful tests is treated as mathematical closure.
