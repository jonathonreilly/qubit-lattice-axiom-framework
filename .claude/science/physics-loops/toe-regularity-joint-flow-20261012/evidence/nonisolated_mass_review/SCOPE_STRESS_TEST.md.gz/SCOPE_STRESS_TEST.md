# Scoped negative-claim stress test

This applies the previously read no-go discipline to the exact failures
actually stated, not to a universal no-go for scattering or physical models.
The main result is a conditional positive theorem.

1. **Alternatives retained.** Dybalski's complete Section 4 explicitly treats
   regularity as a sufficient technical condition, and the source's generalized
   free-field discussion motivates other constructions. Here spectral dominated
   convergence already gives one-factor limits without a power rate, and
   comparison gives all fixed positive sublinear widths from a regular reference.
   Failure of a Cook integral is not failure of the limit.
2. **Independence of named requirements.** Positive full-operator transfer is a
   condition on every spectral transition. N7 is a condition on the chosen
   residual vacuum vector. Centre isolation restricted to the exact mass sector
   does not control off-mass residual detuning. None is silently inferred from
   one of the others.
3. **Hidden-wall scan.** The infinite counterexample supplies commuting
   generators and the named spectral data. It supplies no finite-dimensional-site
   algebra, finite-range interaction, local regular seed, or independently
   realized dynamics. It therefore cannot rule out additional microscopic
   implications. The finite atom control has the same limitation.
4. **Residual matching.** The counterexample tests exactly the residual after
   removing the selected target. Its Casimir tail is O(eta) in squared norm and
   its geometric detuning tail is at least 1/N at eta=exp(-N^2). Centre filtering
   bounded below on all sufficiently large n leaves that failure intact.
5. **Rhetoric check.** The supported statement is a spectral nonimplication and
   a sufficient theorem with supplied premises. It is not impossibility of
   nonisolated scattering, of microscopic regularity, or of physical realization.
6. **Partial positive route.** The corrected weighted-Casimir factorization
   with a whole-residual lift relation supplies a precise sufficient conversion.
   This route is still open to a stronger model. It is not furnished by an
   on-mass selector alone. The one missing definition in the source is recorded
   as a required local repair, not hidden in the reconstruction.
7. **Steelman.** On identical fixed graphs, the compact-support refinement
   allows the compared families to have individually separated but mutually
   overlapping extra amplitude supports. Uniform finite-energy bounds handle
   discarded packets that merely tend to zero. This avoids a spurious
   cross-family-separation restriction or a false necessity claim for large nu.
8. **Cross-cycle check.** The completed centre theorem selects exact on-mass
   characters. It never promised off-mass regularity. The present counterexample
   therefore identifies a distinct additional obligation, and does not refute
   that prior theorem. Old Fock and detector proofs are not imported into this
   nonexact-vacuum setting. No common-q, ND, EX, all-channel density, boost
   covariance or new primitive is inferred.

Disposition: retain the exact scoped spectral controls and positive conditional
theorem; require the N36 general-beta definition repair. No broad no-go status,
retained status, formal audit verdict or Lean verification is assigned.
