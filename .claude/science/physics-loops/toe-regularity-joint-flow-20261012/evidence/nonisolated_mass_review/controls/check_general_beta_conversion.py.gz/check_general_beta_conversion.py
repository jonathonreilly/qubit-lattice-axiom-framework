#!/usr/bin/env python3
"""Exact polynomial check of the literal source definition versus N36.

This supplemental control was written after the pre-author freeze and helper
inspection, when a final reread exposed the general-beta definition ambiguity.
"""
from fractions import Fraction as F
import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parents[1]
p=r/'sources/NONISOLATED_MASS_SCATTERING_PROBE.md';text=p.read_text()
assert r'\mathcal C=H^2-K^2' in text
assert r'\Sigma(Q)^2=M^2+\beta|K|^2' in text
assert r'\mathcal C-M^2=(H-\Sigma(Q))(H+\Sigma(Q))' in text
assert r'\mathcal C=H^2-\beta' not in text
rows=[]
for beta in [F(1,2),F(1),F(2),F(4)]:
 for mass2 in [F(1),F(4)]:
  for h2 in [F(9),F(16)]:
   for k2 in [F(0),F(1),F(5,4)]:
    sigma2=mass2+beta*k2
    rhs=h2-sigma2
    inherited_c_lhs=h2-k2-mass2
    weighted_c_lhs=h2-beta*k2-mass2
    assert inherited_c_lhs-rhs==(beta-1)*k2
    assert weighted_c_lhs==rhs
    rows.append({'beta':str(beta),'M2':str(mass2),'H2':str(h2),'K2':str(k2),'literal_difference':str(inherited_c_lhs-rhs),'repaired_difference':str(weighted_c_lhs-rhs)})
example={'beta':2,'M2':1,'K2':1,'H2':4,'Sigma2':3,'literal_lhs':2,'rhs':1,'repaired_lhs':1}
result={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows,'cases':len(rows),'literal_general_beta_failures':sum(v['literal_difference']!='0' for v in rows),'weighted_definition_failures':sum(v['repaired_difference']!='0' for v in rows),'exact_counterexample':example,'finding':'N36 requires explicit general-beta definition C:=H^2-beta|K|^2, or an explicit beta=1 restriction. Core scattering theorem and beta=1 counterexample unaffected.','phase':'supplemental post-author-inspection source reread'}
(r/'GENERAL_BETA_CONTROL.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
