#!/usr/bin/env python3
"""Independent pre-author continuum spectral and unequal-time control.

No author helper is imported. This auxiliary spectral/two-site calculation
tests explicit identities; it is not a lattice scattering realization.
"""
import json
import math
import numpy as np
from scipy.integrate import quad
from scipy.linalg import expm


def record(name, **values):
    print(json.dumps({'control': name, **values}, sort_keys=True), flush=True)


def bump(y):
    return math.exp(-y*y/(1-y*y)) if abs(y)<1 else 0.0


def bump_prime(y):
    return -2*y*bump(y)/(1-y*y)**2 if abs(y)<1 else 0.0


def integral(a, fn, upper=1.0):
    value, error = quad(lambda r: 2*a*fn(r), 0, upper,
                        weight='alg', wvar=(2*a-1, 0),
                        epsabs=2e-20, epsrel=2e-12, limit=250)
    assert error < 2e-9, (value, error)
    return value


def vector(t, nu, sigma, r):
    return np.exp(1j*sigma*t*r)*bump(t**nu*r)


def derivative(t, nu, sigma, r, omit=None):
    s=t**nu
    sp=nu*t**(nu-1)
    centre=1j*sigma*r*bump(s*r)
    width=sp*r*bump_prime(s*r)
    if omit=='width': width=0
    if omit=='centre': centre=0
    return np.exp(1j*sigma*t*r)*(centre+width)


def main():
    constants={}
    for a in [0.125,0.5,1.5]:
        constants[a]=[
            integral(a,lambda y:bump(y)**2),
            integral(a,lambda y:y*y*bump(y)**2),
            integral(a,lambda y:y*y*bump_prime(y)**2)]
        assert min(constants[a])>0
    record('continuum_constants', constants=constants)

    relative=[]
    cases=0
    for a in constants:
      c0,c2,j2=constants[a]
      for nu in [0.2,0.67,0.9]:
       for t in [3.0,10.0,50.0]:
        for sigma in [-1,1]:
         s=t**nu;sp=nu*t**(nu-1)
         direct0=integral(a,lambda r:abs(vector(t,nu,sigma,r))**2,1/s)
         direct1=integral(a,lambda r:abs(derivative(t,nu,sigma,r))**2,1/s)
         expected0=c0*s**(-2*a)
         expected1=s**(-2*a-2)*(c2+sp*sp*j2)
         relative.extend([abs(direct0/expected0-1),abs(direct1/expected1-1)])
         cases+=1
    assert max(relative)<2e-8
    record('original_detuning_quadrature',cases=cases,max_relative_error=max(relative))

    rows=[]
    for nu in [0.3,0.9]:
     for sigma in [-1,1]:
      t=5.0;a=0.5
      errors=[];badwidth=[];badcentre=[]
      for step in [0.02,0.01,0.005]:
       upper=max((t-step)**(-nu),(t+step)**(-nu))
       def fd(r):
           return (vector(t+step,nu,sigma,r)-vector(t-step,nu,sigma,r))/(2*step)
       errors.append(math.sqrt(integral(a,lambda r:abs(fd(r)-derivative(t,nu,sigma,r))**2,upper)))
       badwidth.append(math.sqrt(integral(a,lambda r:abs(fd(r)-derivative(t,nu,sigma,r,'width'))**2,upper)))
       badcentre.append(math.sqrt(integral(a,lambda r:abs(fd(r)-derivative(t,nu,sigma,r,'centre'))**2,upper)))
      ratios=[errors[i]/errors[i+1] for i in [0,1]]
      assert min(ratios)>3.8 and max(ratios)<4.2,(nu,sigma,errors,ratios)
      assert badwidth[-1]>1000*errors[-1] and badcentre[-1]>1000*errors[-1]
      rows.append(dict(nu=nu,sigma=sigma,errors=errors,ratios=ratios,
                       omitted_width_error=badwidth[-1],omitted_centre_error=badcentre[-1]))
    record('continuous_measure_finite_difference',rows=rows)

    a=0.5;nu=0.3;c0,c2,j2=constants[a]
    scaled=[]
    for t in [10,100,10000,100000000]:
        s=t**nu;sp=nu*t**(nu-1)
        norm=math.sqrt(s**(-2*a-2)*(c2+sp*sp*j2))
        scaled.append(norm*t**(nu*(1+a)))
    assert nu*(1+a)<1 and scaled[-1]>0.99*math.sqrt(c2)
    assert abs(scaled[-1]/math.sqrt(c2)-1)<1e-9
    record('nonintegrable_derivative_but_vacuum_convergence',a=a,nu=nu,
           derivative_power=nu*(1+a),scaled_derivative_norms=scaled,
           exact_vacuum_power=nu*a,analytic_divergence='norm >= sqrt(I2) T^-0.45')

    nus=[0.2,0.25,0.3]
    tensor=[]
    for t in [10,100,10000,100000000]:
        errors=[math.sqrt(c0)*t**(-0.5*v) for v in nus]
        exact=math.sqrt(math.prod(1+e*e for e in errors)-1)
        telescope=sum(errors[i]*math.prod(math.sqrt(1+errors[j]**2) for j in range(i)) for i in range(3))
        assert exact<=telescope+1e-12
        tensor.append({'T':t,'exact_tensor_error':exact,'telescope_bound':telescope,
                       'spectator_uniform_bound':(1+c0)**1.5})
    assert tensor[-1]['exact_tensor_error']<tensor[0]['exact_tensor_error']/3
    record('three_slow_widths_uniform_spectators',rows=tensor,
           limit_proof='Each exponent 2 a nu is positive in product(1+I0 T^-2anu)-1.')

    atom=0.375
    assert all(abs(atom*bump(0))==atom for _ in [1,10,100000000])
    record('zero_atom',unwanted_norm=atom,punctured_norm=0,
           closed_interval_regular_bound_fails=True)

    x=np.array([[0,1],[1,0]],complex)
    z=np.diag([1,-1]).astype(complex);eye=np.eye(2)
    h=np.kron(x,x)+0.31*np.kron(z,eye)+0.19*np.kron(eye,z)
    h=h-np.linalg.eigvalsh(h)[0]*np.eye(4)
    aop=np.kron(z,eye);bop=np.kron(eye,z)
    def alpha(t,a):
        u=expm(1j*t*h)
        return u@a@u.conj().T
    def comm(a,b): return a@b-b@a
    t=0.37;u=0.81
    same=np.linalg.norm(comm(alpha(t,aop),alpha(t,bop)),2)
    different=comm(alpha(t,aop),alpha(u,bop))
    transported=alpha(t,comm(aop,alpha(u-t,bop)))
    error=np.linalg.norm(different-transported,2)
    different_norm=np.linalg.norm(different,2)
    assert same<1e-12 and error<1e-12 and different_norm>0.1
    record('unequal_time_two_site',same_time_norm=same,
           unequal_time_norm=different_norm,transport_identity_error=error,
           equal_time_replacement_error=different_norm)
    record('summary',status='PASS',limits=['auxiliary models, not an infinite lattice realization',
           'quadrature corroborates analytic formulas, not a universal convergence proof',
           'finite two-site control does not measure asymptotic LR tails'])


if __name__=='__main__':
    main()
