#!/usr/bin/env python3
"""Mutate exact frozen author helper copies; preserve every source and stream."""
import datetime,difflib,hashlib,json,os,pathlib,subprocess,sys,time
r=pathlib.Path(__file__).resolve().parents[1]
source=r/'sources/author_packet/check_nonisolated_controls.py'
original=source.read_text();out=r/'controls/author_mutations';out.mkdir(exist_ok=True)
cases=[
 ('kernel_width_removed',[('exact = -(sign*hp(u)+sp*(h(u)+u*hp(u)))/s**2','exact = -sign*hp(u)/s**2')],1,'Incorrect moving-kernel derivative'),
 ('spectral_width_removed',[('width = phase*sp*detuning*bump_prime(s*detuning)','width = 0')],1,'Incorrect vacuum derivative'),
 ('packet_clock_sign',[('packet = -1j*clock','packet = 1j*clock')],1,'Wrong packet clock sign'),
 ('cook_residual_removed',[('        add(rhs,A[:i]+A[i+1:]+[D])\n','')],1,'False exact vacuum cancellation'),
 ('cook_pair_sign',[('add(target,prefix+[A[j],D]+suffix,-1)','add(target,prefix+[A[j],D]+suffix,1)')],1,'Wrong commutator order sign'),
 ('energy_positive_term_reordered',[('            add(rhs,[Xs,Ys,X,Y])\n','            add(rhs,[Ys,Xs,X,Y])\n')],1,'Wrong inner-product expansion word'),
 ('creator_padding_removed',[('gamma_padded = 1','gamma_padded = 0')],1,'Unpadded vacuum creator estimate'),
 ('zero_atom_erased',[('target,residual = 1.0,3.0','target,residual = 1.0,0.0')],1,'Counterexample loses contaminating atom'),
 ('casimir_upper_constant_too_small',[('abs(diff) <= 1.5/n','abs(diff) <= .4/n')],1,'False displayed Casimir inequality'),
 ('pair_spectators_omitted',[('pair_order=max(0,dimension*(n-2))+3','pair_order=3')],1,'Order fails to absorb all pair spectators'),
 ('time_spectator_order_omitted',[('order=math.ceil(F(dimension*n+3)/(mu-nu))','order=math.ceil(F(dimension+3)/(mu-nu))')],1,'Time-tail order ignores n-dependent growth'),
 ('energy_rhs_copy_only',[('            add(rhs,[Xs,Ys,X,Y],-1)\n',''),('            add(rhs,[Xs,Ys,X,Y])\n','')],0,'Nondiscrimination: removing both compensating terms leaves copied LHS=RHS'),
 ('offmass_detuning_zero',[('delta = math.exp(-n*n)','delta = 0.0')],0,'Nondiscrimination: finite Casimir gate does not check strictly positive logarithmic detuning'),
 ('padded_bound_weakened',[('gamma_padded = 1','gamma_padded = 2')],0,'Expected survivor: a looser padding inequality remains valid; no sharpness test'),
]
rows=[]
for name,replacements,expected,scope in cases:
 changed=original
 for before,after in replacements:
  assert changed.count(before)==1,(name,before,changed.count(before))
  changed=changed.replace(before,after)
 p=out/(name+'.py');p.write_text(changed)
 diff=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile=source.name,tofile=p.name))
 (out/(name+'.diff')).write_text(diff)
 command=[sys.executable,str(p)]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 timed_out=False;launch_error=None
 try:
  result=subprocess.run(command,cwd=r,capture_output=True,timeout=15,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  stdout,stderr,code=result.stdout,result.stderr,result.returncode
 except subprocess.TimeoutExpired as e:
  stdout,stderr,code=e.stdout or b'',e.stderr or b'',None;timed_out=True
 except OSError as e:
  stdout,stderr,code=b'',str(e).encode(),None;launch_error=repr(e)
 for ext,data in [('stdout',stdout),('stderr',stderr)]: (out/(name+'.'+ext)).write_bytes(data)
 row={'name':name,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'command':command,'cwd':str(r),'declared_timeout_seconds':15,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'returncode':code,'timed_out':timed_out,'launch_error':launch_error,'expected_returncode':expected,'expectation_met':code==expected,'scope':scope,'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
 (out/(name+'.execution.json')).write_text(json.dumps(row,indent=2)+'\n')
 rows.append(row)
 print(json.dumps({'name':name,'returncode':code,'scope':scope,'expectation_met':row['expectation_met']},sort_keys=True),flush=True)
report={'author_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':rows,'total':len(rows),'rejected':sum(v['returncode']==1 for v in rows),'survived':sum(v['returncode']==0 for v in rows),'all_expectations_met':all(v['expectation_met'] for v in rows),'limits':'Mutants test exact helper gates, not infinite-dimensional proof validity. Surviving deletions and loosenings are preserved.'}
(r/'AUTHOR_MUTATION_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['all_expectations_met']
