#!/usr/bin/env python3
"""Freeze the completed review and exact proposed correction only."""
import datetime,hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent;s=r.parent
now=datetime.datetime.now(datetime.timezone.utc)
assert now<datetime.datetime(2026,10,12,16,0,52,tzinfo=datetime.timezone.utc)
def binding(p):
 raw=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
exclusions=['FINAL_RECEIPT.json','RECEIPT_VERIFICATION.json']
for label in ['freeze_final','verify_final']:
 exclusions += ['logs/'+label+'.'+ext for ext in ['stdout','stderr','execution.json']]
report=s/'NONISOLATED_MASS_SCATTERING_REVIEW.md'
files=[binding(report)]+[binding(p) for p in sorted(r.rglob('*')) if p.is_file() and str(p.relative_to(r)) not in exclusions]
source_manifest=json.loads((r/'FINAL_SOURCE_MANIFEST.json').read_text())
for row in source_manifest['sources']:
 assert binding(pathlib.Path(row['path']))==row,row
assert source_manifest['all_bound_bytes_match']
repair=json.loads((r/'N36_PUBLICATION_REPAIR.json').read_text())
assert repair['frozen_note_sha256']=='afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d'
mutations=json.loads((r/'AUTHOR_MUTATION_RESULTS.json').read_text())
execution_labels=['freeze_pre_author','independent_continuum','refine_independent_control','independent_continuum_v2','author_inventory','author_controls_reproduction','author_sources_reproduction','author_mutations','general_beta_conversion','n36_repair_verification','final_source_refresh']
executions={label:json.loads((r/'logs'/f'{label}.execution.json').read_text()) for label in execution_labels}
assert executions['independent_continuum']['returncode']==1
assert all(row['returncode']==0 and not row['timed_out'] for name,row in executions.items() if name!='independent_continuum')
receipt={'schema':'source-bound-independent-review-v1','reviewer':'/root/isolated_centre_review','task':'Fresh nonisolated-mass scattering review, distinct from completed centre review','frozen_at_utc':now.isoformat(),'fixed_deadline_utc':'2026-10-12T16:00:52Z','status':'review_complete_with_one_required_local_source_correction','disposition':{'N1-N31':'supported conditional finite-product theorem with stated premises','N32-N35':'supported beta=1 commuting spectral nonimplication, not a lattice realization','N36':'general-beta conversion supported after exact reviewed weighted-Casimir definition and consistent notation','publication_requirement':'Apply exact N36_PUBLICATION_REPAIR.json replacement or keep this clause explicitly beta=1; frozen author note unchanged','no_other_required_mathematical_correction_found':True},'target':binding(s/'NONISOLATED_MASS_SCATTERING_PROBE.md'),'author_receipt':binding(s/'nonisolated_mass_scattering/FINAL_RECEIPT.json'),'report':binding(report),'preauthor_freeze':binding(r/'PREAUTHOR_FREEZE.json'),'preauthor_reconstruction':binding(r/'INDEPENDENT_RECONSTRUCTION_PREAUTHOR.md'),'required_repair':binding(r/'N36_PUBLICATION_REPAIR.json'),'repair_after_fragment_sha256':repair['after_sha256'],'repair_only_prospective_note_sha256':repair['prospective_note_sha256'],'independence':{'root_is_coauthor':True,'source_and_prior_reviews_visible':True,'author_receipt_metadata_visible':True,'new_author_helpers_and_outputs_unopened_until_preauthor_freeze_and_independent_runs':True,'supplemental_N36_control_phase':'post-author-inspection final literal reread; preliminary reconstruction implicitly used corrected weighted definition','model_effort':'inherited user-selected, no override','subdelegation':False},'executions':executions,'mutation_summary':{'total':mutations['total'],'rejected':mutations['rejected'],'survived':mutations['survived'],'survivors':[v['name'] for v in mutations['cases'] if v['returncode']==0]},'source_refresh':{'distinct_bindings':len(source_manifest['sources']),'all_author_evidence_files':103,'prior_centre_review_preserved':True,'observed_refs':source_manifest['observed_refs']},'outputs':files,'self_reference_exclusions':exclusions,'exclusion_reason':'Receipt self-reference and final freeze/verification wrapper logs are excluded and reported separately. All other outputs, including copied author receipts, are bound.','limits':['No physical realization, regular-creator existence/density or nonzero multiparticle-norm result','No Fock/isometry, detector, common-q, ND, EX, all-channel exhaustion or boost-covariance conclusion','No formal audit verdict, retained status or Lean assertion','Initial independent quadrature failure and three surviving author-helper mutants retained','Exact original TeX and selected primary PDF/BDN coverage; no whole-BDN-paper reading claimed','Protected author download/extraction and receipt writers inspected but not rerun','Current concurrent repository cleanliness is not a scientific requirement; only bound inputs checked'],'writes_confined_to_review_report_and_folder':True,'author_note_edited':False,'prior_centre_report_or_receipt_edited':False,'repository_git_pr_audit_axiom_mutations':[],'editable_prompt_files_changed':[]}
path=r/'FINAL_RECEIPT.json'
with path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':binding(path),'report':binding(report),'repair':binding(r/'N36_PUBLICATION_REPAIR.json'),'after_fragment_sha256':repair['after_sha256'],'prospective_note_sha256':repair['prospective_note_sha256'],'bound_outputs':len(files),'frozen_at_utc':receipt['frozen_at_utc']},indent=2))
