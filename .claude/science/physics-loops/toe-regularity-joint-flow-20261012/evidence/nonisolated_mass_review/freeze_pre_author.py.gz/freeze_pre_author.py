#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,shutil,subprocess
r=pathlib.Path(__file__).resolve().parent;s=r.parent
sw=s.parent/'scattering_worktree';author=s/'nonisolated_mass_scattering'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def binding(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
records=[]
for n in [6,7,10,11,12,14,15,16,38,39,40,41,42,43]:
 p=author/'sources/BDN_pages'/f'{n:02}.txt';q=r/'sources/BDN_pages'/p.name
 q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);records.append({'source':str(p),**binding(q),'read_full':True})
for n in [2,3,6,7,8]:
 p=author/'sources/rendered'/f'page-{n:02}.png';q=r/'sources/Dybalski_pages'/p.name
 q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);records.append({'source':str(p),**binding(q),'visually_inspected':True})
previous=json.loads((s/'isolated_centre_review/INITIAL_SOURCES.json').read_text())
checks=[]
for row in previous['sources']:
 if row['kind']!='instruction':continue
 command=['git','show',row['git_revision']+':'+row['git_path']]
 result=subprocess.run(command,cwd=sw,capture_output=True,timeout=15,check=True)
 old=pathlib.Path(row['copy']);copy=r/'sources/instructions'/old.name
 assert hashlib.sha256(result.stdout).hexdigest()==row['sha256']==sha(copy)
 checks.append({'command':command,'cwd':str(sw),'timeout_seconds':15,'exit_code':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr':result.stderr.decode(),'copy':str(copy),'matches':True})
records+= [binding(s/'ISOLATED_CENTRE_FILTERING_REVIEW.md'),binding(s/'isolated_centre_review/receipt.json')]
record={'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'before author helper/output inspection','independence':'Target/source/prior review text and receipt metadata visible. New author helper and outputs unopened. No subdelegation. Root is coauthor.',
 'fixed_deadline_utc':'2026-10-12T16:00:52Z','files':[binding(r/'INDEPENDENT_RECONSTRUCTION_PREAUTHOR.md'),binding(r/'controls/continuum_time_width_control.py'),binding(r/'sources/NONISOLATED_MASS_SCATTERING_PROBE.md'),binding(r/'sources/FINAL_RECEIPT.json')],'additional_sources':records,'pinned_instruction_checks':checks,'independent_control_timeout_seconds':60}
(r/'PREAUTHOR_FREEZE.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'frozen_at':record['frozen_at_utc'],'freeze_sha256':sha(r/'PREAUTHOR_FREEZE.json'),'files':record['files'],'instruction_checks':len(checks)},indent=2))
