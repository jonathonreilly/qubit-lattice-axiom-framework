#!/usr/bin/env python3
"""Preserve the failed frozen first control; tighten quadrature only in v2."""
import datetime,difflib,hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
p=r/'controls/continuum_time_width_control.py';q=r/'controls/continuum_time_width_control_v2.py'
old=p.read_text();new=old.replace('epsabs=2e-12, epsrel=2e-11, limit=250','epsabs=2e-20, epsrel=2e-12, limit=250')
assert old!=new and old.count('epsabs=2e-12, epsrel=2e-11, limit=250')==1
q.write_text(new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=p.name,tofile=q.name))
(r/'controls/independent_v2.diff').write_text(diff)
record={'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_helper_output_still_unopened':True,'reason':'The first continuous-measure derivative error squared approached the quadrature absolute tolerance; measured step ratio 3.795938750495109 failed the frozen lower gate 3.8. Tighten integration accuracy, retain identical cases, gates and formulas.','original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'v2_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'change':diff}
(r/'PREAUTHOR_CONTROL_REFINEMENT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
