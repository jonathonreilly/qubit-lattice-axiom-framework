#!/usr/bin/env python3
"""Refresh exact bound inputs and declared reading coverage, not global cleanliness."""
import collections,datetime,gzip,hashlib,io,json,pathlib,subprocess,tarfile
r=pathlib.Path(__file__).resolve().parent;s=r.parent;a=s/'nonisolated_mass_scattering';sw=s.parent/'scattering_worktree'
def binding(p):
 data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
initial=json.loads((r/'INITIAL_SOURCE_MANIFEST.json').read_text());fresh=[]
for row in initial['sources']:
 for key in ['source','copy']:
  actual=binding(pathlib.Path(row[key]));assert actual['sha256']==row['sha256'],(row,key,actual)
  fresh.append(actual)
freeze=json.loads((r/'PREAUTHOR_FREEZE.json').read_text())
for row in freeze['files']+freeze['additional_sources']:
 actual=binding(pathlib.Path(row['path']));assert actual['sha256']==row['sha256'],(row,actual)
 fresh.append(actual)
refine=json.loads((r/'PREAUTHOR_CONTROL_REFINEMENT.json').read_text())
assert binding(r/'controls/continuum_time_width_control_v2.py')['sha256']==refine['v2_sha256']
receipt=json.loads((a/'FINAL_RECEIPT.json').read_text())
assert binding(a/'FINAL_RECEIPT.json')['sha256']=='2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6'
for row in [receipt['note'],*receipt['evidence_files']]:
 actual=binding(pathlib.Path(row['path']));assert actual==row,(row,actual);fresh.append(actual)
for row in json.loads((r/'AUTHOR_INVENTORY_VERIFICATION.json').read_text())['coverage_bindings']:
 actual=binding(pathlib.Path(row['path']));assert actual==row,(row,actual);fresh.append(actual)
prior={s/'ISOLATED_CENTRE_FILTERING_REVIEW.md':'68ea0c2f00d0808ce5a6a63632b0bc84a05398260478510fb4f66256e885cbc9',s/'isolated_centre_review/receipt.json':'8eeb364e11eb54d3cb4a6127596d6f9d422f6acd9d88b1275346922661c99abc'}
for p,expected in prior.items():
 actual=binding(p);assert actual['sha256']==expected;fresh.append(actual)
refs={name:subprocess.run(['git','rev-parse',name],cwd=sw,capture_output=True,text=True,timeout=15,check=True).stdout.strip() for name in ['HEAD','origin/main','main']}
assert refs['origin/main']=='a13caa4885f547c8d206265b031ba7649e539fd9'
raw=gzip.decompress((a/'sources/Dybalski_hep-th_0412226v4.source').read_bytes())
expected_tex=(r/'sources/Dybalski_hep-th_0412226v4.tex').read_bytes()
archive_members=[]
if raw==expected_tex:
 source_archive={'type':'gzip-compressed original TeX','tex_exact_match':True}
else:
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as tf:
  for member in tf.getmembers():
   if member.isfile():
    data=tf.extractfile(member).read();archive_members.append({'name':member.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'matches_read_tex':data==expected_tex})
 assert any(x['matches_read_tex'] for x in archive_members)
 source_archive={'type':'gzip-tar source','members':archive_members,'tex_exact_match':True}
historic=json.loads((a/'source_check_retry.stdout').read_text())
assert len(historic['worktree_status_lines'])==353
assert historic['source_reading_records_checked']==27 and historic['pinned_instruction_files_checked']==15
warning_lines=(a/'sources/render.stderr').read_text().splitlines()
unique_warnings=collections.Counter(warning_lines)
execution_verification=[]
for p in sorted((a).glob('*.execution.json')):
 row=json.loads(p.read_text());label=p.name.removesuffix('.execution.json')
 streams={}
 for ext in ['stdout','stderr']:
  stream=a/(label+'.'+ext)
  if stream.exists():
   actual=binding(stream);streams[ext]=actual
   if ext+'_bytes' in row: assert actual['bytes']==row[ext+'_bytes']
 execution_verification.append({'record':binding(p),'metadata':row,'streams':streams})
old_execution_hash=binding(r/'sources/author_packet/check_nonisolated_controls.py')['sha256']
assert (r/'logs/author_controls_reproduction.stdout').read_bytes()==(a/'author_controls.stdout').read_bytes()
assert (r/'logs/author_controls_reproduction.stderr').read_bytes()==(a/'author_controls.stderr').read_bytes()
coverage=[
 {'item':'Frozen target','path':str(s/'NONISOLATED_MASS_SCATTERING_PROBE.md'),'coverage':'All 359 lines; slices 1-130, 131-250, 251-359; N36 literal final reread.'},
 {'item':'Dybalski original TeX','path':str(a/'sources/Dybalski_hep-th_0412226v4.tex'),'coverage':'All 673 lines; 1-180, 181-340, 341-510, 511-673. Last slice repeated after one oversized display.'},
 {'item':'Dybalski PDF','path':str(a/'sources/Dybalski_hep-th_0412226v4.pdf'),'coverage':'Original PDF bound; existing renders pages 2,3,6,7,8 visually inspected against TeX. No whole-PDF visual read claimed.'},
 {'item':'BDN original PDF','path':str(a/'sources/BDN_1412.2970v2.pdf'),'coverage':'Complete saved texts of pages 6,7,10,11,12,14,15,16,38-43 read here; no complete-paper reading claimed.'},
 {'item':'SC/Fock/centre prerequisites','path':str(r/'sources/prerequisites'),'coverage':'Previous complete exact original source readings reused. Complete published diffs read; F7-F9 and SC packet/locality arguments refreshed. No Fock/detector conclusion imported.'},
 {'item':'Instructions','path':str(r/'sources/instructions'),'coverage':'Previously read exact pinned main/planning instruction bundle reused. Review skill refreshed; seven principal pinned blobs rechecked directly before freeze. No stale local-main authority.'},
 {'item':'Author scientific helper and results','path':str(a/'check_nonisolated_controls.py'),'coverage':'Entire source and all ten JSON records read; exact byte-identical reproduction; fourteen actual-source variants inspected and preserved.'},
 {'item':'Author supporting code','path':str(a),'coverage':'Complete check_source_bindings.py, build_final_receipt.py, run_with_timeout.py, fetch_primary.py read. Read-only source checker reproduced. Protected-output writers not reexecuted.'},
 {'item':'Author metadata','path':str(a),'coverage':'Complete self-check, operations, both checkpoints, claim certificate, source manifests/diff, all reading record declarations, all execution metadata/streams. Every source/evidence binding checked by full-byte hashing. Receipt metadata read; all hash rows verified programmatically.'},
 {'item':'Malformed source extracts and warnings','path':str(a/'sources'),'coverage':'Large malformed layout extracts hashed, not used as reading. Complete render stderr classified into exact line counts; source TeX and PDF equations used.'},
]
for row in coverage:
 p=pathlib.Path(row['path'])
 if p.is_file():row['binding']=binding(p)
(r/'READING_COVERAGE.json').write_text(json.dumps({'reviewer':'/root/isolated_centre_review','scope':'Fresh nonisolated-mass review, distinct from completed centre review','items':coverage,'source_archive_verification':source_archive,'new_author_helper_inspection':'After preauthor freeze and independent v2 run; receipt metadata/target control descriptions already visible'},indent=2)+'\n')
unique={row['path']:row for row in fresh}
manifest={'refreshed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':list(unique.values()),'observed_refs':refs,'pinned_main':'a13caa4885f547c8d206265b031ba7649e539fd9','pinned_planning':'3a4b2c66a1ead7a1c48b4359627e968f681e3c39','prior_centre_review_preserved':True,'source_archive':source_archive,'author_scientific_helper_sha256':old_execution_hash,'author_evidence_files':103,'all_bound_bytes_match':True,'exact_source_checks_not_global_cleanliness':True}
(r/'FINAL_SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
evidence={'executions':execution_verification,'historic_source_retry_complete_parse':historic,'render_stderr_complete_lines':len(warning_lines),'render_stderr_unique_lines':dict(unique_warnings),'author_reproduction_streams_byte_identical':True,'source_download_writers_rerun':False,'reason':'Frozen primary/source bytes checked; protected author packet must not be mutated.'}
(r/'EVIDENCE_INSPECTION.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'sources_rechecked':len(unique),'author_evidence_files':103,'prior_centre_review_preserved':True,'original_tex_matches_source_archive':True,'observed_refs':refs,'all_bound_bytes_match':True,'historical_status_paths_parsed':353,'render_warning_lines':len(warning_lines),'render_warning_classes':len(unique_warnings)},indent=2))
