"""Freeze only this bounded author's note and evidence; no repository mutation."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOTE = HERE.parent / "NONISOLATED_MASS_SCATTERING_PROBE.md"
DEADLINE = datetime(2026, 10, 12, 16, 0, 52, tzinfo=timezone.utc)
EXPECTED_NOTE = "afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d"
EXCLUDED = {"FINAL_RECEIPT.json", "RECEIPT_VERIFICATION.json"}


def binding(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def exclusive_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


now = datetime.now(timezone.utc)
assert now < DEADLINE, "Fixed campaign deadline reached; do not extend."
note = binding(NOTE)
assert note["sha256"] == EXPECTED_NOTE
files = [binding(path) for path in sorted(HERE.rglob("*"))
         if path.is_file() and path.name not in EXCLUDED]
source_check = json.loads((HERE / "source_check_retry.stdout").read_text())
assert source_check["note_sha256"] == EXPECTED_NOTE
controls = json.loads((HERE / "author_controls.execution.json").read_text())
retry = json.loads((HERE / "source_check_retry.execution.json").read_text())
failed = json.loads((HERE / "source_check.execution.json").read_text())
assert controls["returncode"] == retry["returncode"] == 0
assert failed["returncode"] == 1
inventory = json.loads((HERE / "concurrent_inventory_summary.json").read_text())
assert inventory["full_status_count"] == 353 and not inventory["unexpected_paths"]

receipt = {
    "schema": "bounded-author-recovery-receipt-v1",
    "frozen_at_utc": now.isoformat(),
    "fixed_deadline_utc": DEADLINE.isoformat(),
    "author_task": "/root/nonisolated_mass_recovery",
    "recovered_predecessor": "/root/compact_detector_convergence",
    "interrupted_request_id": "ffab7dff-5c98-4e5b-bd40-7633f1540561",
    "note": note,
    "status": "conditional-support; bounded author theorem; independent review pending",
    "conclusion": "Incoming/outgoing finite internally velocity-separated product limits and creator independence on fixed geometric dispersion charts, under explicit stable sector, actual finite-range dynamics and per-packet geometric-detuning regularity including zero. All fixed widths T^nu, 0<nu<1, are covered by comparison to integrable reference widths.",
    "load_bearing_premises": [
        "Actual finite-range translation-invariant H dynamics, positive H, unique gapped invariant vacuum",
        "Supplied reducing stable geometric graph sectors on smooth compact charts",
        "Almost-local creators with fixed strictly positive full temporal transfer and almost-local time derivatives",
        "Regularity for D=H-Sigma(Q) on the complete off-target packet vector, including its zero kernel",
        "Fixed finite number of compact pairwise separated velocity supports"
    ],
    "preserved_failures": [
        "Excluded-zero regularity alone permits extra graph-kernel contamination and the wrong vacuum limit",
        "An infinite commuting spectral example has mass-Casimir regularity of exponent 1/2 but only logarithmic geometric-detuning regularity; an on-mass centre selector alone does not remove its off-mass tail",
        "The displayed Cook derivative estimate may fail to be integrable for small nu; comparison to a regular reference width still proves the stated product limit",
        "First source-check attempt failed on unrelated global cleanliness, and was preserved before a source-specific retry"
    ],
    "limits": [
        "No regular-seed existence or density, stable-sector construction, or physical microscopic realization",
        "No nonzero multiparticle norm, Fock Gram/isometry result, detector/PC convergence, ND, EX, channel exhaustion, or boost covariance",
        "No massless-vacuum extension; the supplied unique vacuum gap is retained",
        "Spectral failure examples are not UHF finite-range microscopic countermodels",
        "Finite author controls and file hashes are not independent proof review or a retained-status audit"
    ],
    "source_revisions": {
        "science_instructions": "a13caa4885f547c8d206265b031ba7649e539fd9",
        "planning_instructions": "3a4b2c66a1ead7a1c48b4359627e968f681e3c39",
        "worktree_head_at_source_check": source_check["worktree_head"],
        "bound_source_identity_status": "All original/frozen source bytes matched; original inputs checked again after the concurrent inventory",
        "source_reading_records": source_check["source_reading_records_checked"],
        "pinned_instruction_files": source_check["pinned_instruction_files_checked"],
        "preserved_predecessor_artifacts": source_check["predecessor_artifacts_preserved"],
        "equation_tags": source_check["equation_tags"]
    },
    "primary_reading": {
        "Dybalski_hep_th_0412226v4": "Complete original TeX; original rendered PDF pages 2,3,6,7,8 visually checked",
        "BDN_arxiv_1412_2970v2": "Selected pages 6-17 and 38-43, including complete relevant transfer and almost-locality proofs; no whole-paper reading claimed",
        "repository": "Complete published SC/Fock arguments and external isolated-centre argument read; only matched finite-energy machinery reused",
        "details": "READING_COVERAGE.json and source_manifest.json"
    },
    "executions": {"author_controls": controls,
                   "preserved_failed_global_cleanliness_check": failed,
                   "source_specific_retry": retry},
    "concurrent_worktree_context": inventory,
    "independence": "Root supplied proof mechanisms and is a coauthor. This author check is not independent; fresh focused proof reconstruction is the next action.",
    "operational_constraints": {
        "model_and_effort": "User-selected model and effort inherited without override",
        "subdelegation": False,
        "repository_or_git_mutations": False,
        "publication_PR_or_audit_actions": False,
        "axiom_or_primitive_changes": False,
        "editable_prompt_files_changed": [],
        "writes_confined_to_note_and_evidence_directory": True,
        "new_unpublished_root_package_imported": False
    },
    "evidence_files": files,
    "self_reference_exclusions": sorted(EXCLUDED),
}
receipt_path = HERE / "FINAL_RECEIPT.json"
exclusive_json(receipt_path, receipt)
saved = json.loads(receipt_path.read_text())
for entry in [saved["note"], *saved["evidence_files"]]:
    assert binding(Path(entry["path"])) == entry, entry["path"]
verification = {
    "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    "receipt": binding(receipt_path),
    "note_sha256": saved["note"]["sha256"],
    "evidence_files_verified": len(saved["evidence_files"]),
    "all_bound_bytes_match": True,
    "scope": "Byte identity and receipt consistency only; no mathematical verdict"
}
exclusive_json(HERE / "RECEIPT_VERIFICATION.json", verification)
print(json.dumps(verification, sort_keys=True))
