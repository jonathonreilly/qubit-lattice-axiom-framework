#!/usr/bin/env python3
"""Read-only verification of recorded source identities, not mathematics."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parent
S = root.parent
SW = S.parent / 'scattering_worktree'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


coverage = json.loads((root/'READING_COVERAGE.json').read_text())
for row in coverage['sources']:
    for key in ['original_path','frozen_path']:
        assert sha(Path(row[key])) == row['sha256'], (key,row[key])

manifest = json.loads((root/'source_manifest.json').read_text())
instruction_count = 0
for row in manifest['files']:
    if row.get('revision') in [manifest['science_revision'],manifest['planning_revision']]:
        data = subprocess.check_output(['git','show',row['revision']+':'+row['path']],cwd=SW)
        assert hashlib.sha256(data).hexdigest() == row['sha256'],row['path']
        instruction_count += 1

recovery = json.loads((root/'root_disconnect_recovery.json').read_text())
preserved = 0
for row in recovery['saved_files']:
    path = S/row['path']
    if row['path'] == 'nonisolated_mass_scattering/CHECKPOINT.md':
        path = root/'CHECKPOINT.pre_recovery.md'
    assert sha(path) == row['sha256'],str(path)
    assert path.stat().st_size == row['bytes'],str(path)
    preserved += 1

note = S/'NONISOLATED_MASS_SCATTERING_PROBE.md'
tags = re.findall(r'\\tag\{N(\d+)\}',note.read_text())
assert [int(x) for x in tags] == list(range(1,37)),tags
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=SW,text=True).strip()
status = subprocess.check_output(['git','status','--short','--untracked-files=all'],cwd=SW,text=True)
# The coordinator can publish unrelated frozen blocks concurrently. Verify
# each actually bound source again after the inventory rather than demanding
# global worktree cleanliness. The complete inventory remains in stdout.
for row in coverage['sources']:
    assert sha(Path(row['original_path'])) == row['sha256'],row['original_path']
print(json.dumps({'source_reading_records_checked':len(coverage['sources']),
                  'pinned_instruction_files_checked':instruction_count,
                  'predecessor_artifacts_preserved':preserved,
                  'note_sha256':sha(note),'equation_tags':len(tags),
                  'worktree_head':head,'worktree_clean':not status,
                  'worktree_status_lines':status.splitlines(),
                  'concurrent_scope':'Root confirmed packaging unrelated frozen centre/current lemmas; new unpublished files are not proof inputs.',
                  'scope':'Source identities and bookkeeping only; no proof or review verdict'},sort_keys=True))
