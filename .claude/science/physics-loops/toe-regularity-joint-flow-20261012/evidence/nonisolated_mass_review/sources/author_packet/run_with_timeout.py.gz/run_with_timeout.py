#!/usr/bin/env python3
"""Run one command with complete output and an explicit <=60s limit."""
from pathlib import Path
import datetime as dt
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, seconds, *command = sys.argv[1:]
limit = float(seconds)
if not label.replace('_', '').isalnum() or not command or not 0 < limit <= 60:
    raise SystemExit('invalid label, command, or timeout')
start = dt.datetime.now(dt.timezone.utc)
before = time.monotonic()
launch_error = None
try:
    done = subprocess.run(command, cwd=root, capture_output=True, timeout=limit)
    stdout, stderr, code, timed_out = done.stdout, done.stderr, done.returncode, False
except subprocess.TimeoutExpired as error:
    stdout, stderr, code, timed_out = error.stdout or b'', error.stderr or b'', None, True
except OSError as error:
    stdout, stderr, code, timed_out = b'', str(error).encode(), None, False
    launch_error = repr(error)
end = dt.datetime.now(dt.timezone.utc)
(root / (label + '.stdout')).write_bytes(stdout)
(root / (label + '.stderr')).write_bytes(stderr)
record = dict(command=command, cwd=str(root), declared_timeout_seconds=limit,
              started_at=start.isoformat(), finished_at=end.isoformat(),
              elapsed_seconds=time.monotonic()-before, returncode=code,
              timed_out=timed_out, launch_error=launch_error,
              stdout_bytes=len(stdout), stderr_bytes=len(stderr))
(root / (label + '.execution.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, sort_keys=True))
raise SystemExit(124 if timed_out else (127 if launch_error else code))
