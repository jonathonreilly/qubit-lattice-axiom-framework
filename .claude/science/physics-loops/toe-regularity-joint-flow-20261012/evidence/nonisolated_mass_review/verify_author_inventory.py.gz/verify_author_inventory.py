#!/usr/bin/env python3
"""Independent full-byte inspection of author bindings; never writes author inputs."""
import datetime,hashlib,json,pathlib,shutil,subprocess
r=pathlib.Path(__file__).resolve().parent;s=r.parent;a=s/'nonisolated_mass_scattering'
def binding(p):
 raw=p.read_bytes()
 return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
receipt=json.loads((a/'FINAL_RECEIPT.json').read_text())
assert binding(a/'FINAL_RECEIPT.json')['sha256']=='2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6'
checked=[]
for row in [receipt['note'],*receipt['evidence_files']]:
 actual=binding(pathlib.Path(row['path']))
 assert actual==row,(actual,row)
 checked.append(actual)
listed={pathlib.Path(v['path']).resolve() for v in receipt['evidence_files']}
unlisted=[str(p) for p in a.rglob('*') if p.is_file() and p.resolve() not in listed and p.name not in receipt['self_reference_exclusions']]
assert not unlisted,unlisted
dest=r/'sources/author_packet';dest.mkdir(exist_ok=True)
copies=[]
for p in sorted(a.iterdir()):
 if p.is_file():
  q=dest/p.name;shutil.copyfile(p,q);copies.append({'original':str(p),**binding(q)})
for name in ['download_receipt.json','source_download_metadata.json','BDN_download.json','render.stdout','render.stderr']:
 p=a/'sources'/name;q=dest/'primary_metadata'/name
 q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);copies.append({'original':str(p),**binding(q)})
coverage=json.loads((a/'READING_COVERAGE.json').read_text())
coverage_checks=[]
for row in coverage['sources']:
 for key in ['original_path','frozen_path']:
  p=pathlib.Path(row[key]);actual=binding(p)
  assert actual['sha256']==row['sha256'],(row,key)
  coverage_checks.append(actual)
author_output=(a/'author_controls.stdout').read_text().splitlines()
outputs=[json.loads(line) for line in author_output]
assert len(outputs)==10 and outputs[-1]['records_before_summary']==9
metadata={k:v for k,v in receipt.items() if k!='evidence_files'}
result={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'all_author_bindings_match':True,'author_note_and_evidence_bound':len(checked),
 'coverage_original_and_frozen_checks':len(coverage_checks),'unlisted_author_files':unlisted,
 'author_outputs_parsed_in_full':outputs,'author_receipt_metadata':metadata,
 'files':checked,'copied_files':copies,'coverage_bindings':coverage_checks,
 'large_primary_layout_extractions':'Hashed only; not used as source reading. Complete original TeX and selected PDF pages used.',
 'render_stderr':'Preserved in full; repetitive font extraction warnings are not scientific evidence.'}
(r/'AUTHOR_INVENTORY_VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_author_bindings_match':True,'bound_files':len(checked),'copied_top_level_and_primary_metadata':len(copies),'coverage_checks':len(coverage_checks),'records':len(outputs),'author_frozen_at':receipt['frozen_at_utc'],'verification_path':str(r/'AUTHOR_INVENTORY_VERIFICATION.json')},indent=2))
