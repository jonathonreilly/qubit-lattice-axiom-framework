#!/usr/bin/env python3
import datetime,hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
def binding(p):
 raw=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
receipt=json.loads((r/'FINAL_RECEIPT.json').read_text())
checked=[]
for row in receipt['outputs']+[receipt['target'],receipt['author_receipt']]:
 assert binding(pathlib.Path(row['path']))==row,row
 checked.append(row['path'])
source=json.loads((r/'FINAL_SOURCE_MANIFEST.json').read_text())
for row in source['sources']:assert binding(pathlib.Path(row['path']))==row,row
listed={row['path'] for row in receipt['outputs']}
unlisted=[str(p) for p in r.rglob('*') if p.is_file() and str(p) not in listed and str(p.relative_to(r)) not in receipt['self_reference_exclusions']]
assert not unlisted,unlisted
result={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receipt':binding(r/'FINAL_RECEIPT.json'),'report':receipt['report'],'bindings_checked':len(checked),'source_bindings_refreshed':len(source['sources']),'all_bytes_match':True,'unlisted_outputs':unlisted,'prior_centre_review_preserved':True,'required_correction':'Exact N36_PUBLICATION_REPAIR.json; original source unchanged','scope':'Byte identity and source-bound review consistency; not a formal mathematical audit'}
with (r/'RECEIPT_VERIFICATION.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
