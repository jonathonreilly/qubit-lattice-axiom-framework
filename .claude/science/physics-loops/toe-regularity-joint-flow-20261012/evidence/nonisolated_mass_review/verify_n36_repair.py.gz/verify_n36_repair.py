#!/usr/bin/env python3
"""Create and verify an exact proposed publication fragment inside review only."""
import datetime,difflib,hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
source=r/'sources/NONISOLATED_MASS_SCATTERING_PROBE.md';old=source.read_text()
expected='afd35b7b1ec2e564e7ea418b1233148009509359212db8312599cb535bb6b80d'
sha=lambda x:hashlib.sha256(x.encode() if isinstance(x,str) else x).hexdigest()
assert sha(source.read_bytes())==expected
start=old.index('There is a precise sufficient conversion route.')
end=old.index('\n\n**The Cook exponent',start)
before=old[start:end]
after=before.replace('There is a precise sufficient conversion route. If',
 'There is a precise sufficient conversion route. For this general-beta statement, define \\(\\mathcal C_\\beta:=H^2-\\beta|K|^2\\), using the same \\(\\beta\\) as the dispersion. If')
after=after.replace(r'\mathcal C-M^2=(H-\Sigma(Q))(H+\Sigma(Q)).',r'\mathcal C_\beta-M^2=(H-\Sigma(Q))(H+\Sigma(Q)).')
after=after.replace('A mass regularity bound and matching zero-kernel projection',r'A regularity bound for \(\mathcal C_\beta-M^2\) and matching zero-kernel projection')
assert after!=before and after.count(r'\mathcal C_\beta')==3
assert r'\mathcal C-M^2' not in after
assert r'\mathcal C_\beta:=H^2-\beta|K|^2' in after
assert r'\Sigma(Q)^2=M^2+\beta|K|^2' in after
assert r'\mathcal C_\beta-M^2=(H-\Sigma(Q))(H+\Sigma(Q)).' in after
assert r'A regularity bound for \(\mathcal C_\beta-M^2\)' in after
prospective=old[:start]+after+old[end:]
assert prospective[:start]==old[:start] and prospective[start+len(after):]==old[end:]
assert prospective.count(r'\mathcal C=H^2-K^2')==1 # beta=1 example unchanged
target=r/'controls/N36_REPAIRED_NOTE_FOR_VERIFICATION.md';target.write_text(prospective)
diff=''.join(difflib.unified_diff(old.splitlines(True),prospective.splitlines(True),fromfile='frozen_author_note',tofile='prospective_N36_repair_only'))
(r/'N36_PUBLICATION_REPAIR.diff').write_text(diff)
data={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_note_sha256':expected,'old_start_line':old[:start].count('\n')+1,'old_end_line':old[:end].count('\n')+1,'before':before,'after':after,'before_sha256':sha(before),'after_sha256':sha(after),'prospective_note_sha256':sha(prospective),'sole_change':'General-beta Casimir definition and consistent symbol in N36/conversion sentence; all preceding mathematics and following Cook discussion unchanged.','algebraic_verification':'C_beta-M^2=H^2-beta|K|^2-M^2=H^2-Sigma(Q)^2=(H-Sigma(Q))(H+Sigma(Q)); strong commutation supplies the operator product identity.','spectral_verification':'On the residual bounded-energy compact patch, c<=H+Sigma<=C, c>0. Then 1_{|D|<=eta} <= 1_{|C_beta-M^2|<=C eta}; matching zero projection and the same exponent give N7.','literal_old_counterexample':{'beta':2,'M':1,'K':1,'H':2,'Sigma_squared':3,'old_lhs':2,'rhs':1,'repaired_lhs':1},'verification_limits':'Prospective source fragment only; no publication or author source edited. Source-bound general-beta control is post-author-inspection.'}
(r/'N36_PUBLICATION_REPAIR.json').write_text(json.dumps(data,indent=2)+'\n')
(r/'N36_PUBLICATION_REPAIR.md').write_text('# Exact reviewed N36 publication replacement\n\n'+after+'\n\nOnly replace the source paragraph at lines 341–345 with the text above. The frozen author note is unchanged. N36_PUBLICATION_REPAIR.json binds the exact old/new strings and verifies the algebra and spectral conversion.\n')
print(json.dumps({k:v for k,v in data.items() if k not in ['before','after']},indent=2))
