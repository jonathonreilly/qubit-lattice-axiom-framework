# Author proof check and independence boundary

The complete final mathematical note was read in two contiguous bounded slices, followed by inspection of the three final clarification diffs. This was the author's cold read, not independent review. Root supplied candidate mechanisms and is a coauthor. The model and effort were inherited without override; no subagent was spawned.

The proof's load-bearing checks were:

- The precise regularity variable is D = H - Sigma(Q), and its bound includes zero; this is not replaced by a Casimir estimate. The extra-kernel counterexample verifies the distinction.
- Fixed full positive temporal transfer supplies exact energy lowering for every mixed word. The F7-F9 proof was read in full and reproduced, including the common kernel of all lowering words and the creator's output-energy padding.
- Differentiating the kernel and differentiating the scaled-time packet give equal formulas. Both the width term and the physical/packet clock terms remain present. The spectral multiplier gives the integrable T^[-nu(1+a)] vacuum derivative.
- The two averaging variables remain independent. Removing their common physical time leaves an O(T^mu) difference; LR acts across O(T) separation. Separate spatial and temporal tails absorb every unrestricted commutator spectator.
- Every residual derivative or zero-target difference has a fixed finite-energy ceiling. The finite-energy word bound controls all remaining spectators uniformly.
- Cutoff refinement restricts an actual packet amplitude; discarded packets have zero target and tend to zero on the vacuum. This does not assume exact finite-time annihilation or replace operator support by spectral support.
- Comparison to an integrable reference width, rather than a false Cook estimate for every width, establishes the stated 0 < nu < 1 result.
- The infinite Casimir/centre example has C-detuning comparable to 1/n, D-detuning exp(-n^2), and l2 amplitudes 1/n. Its regularity and failure claims follow from infinite-series bounds; it is explicitly not a microscopic lattice model.

The finite author controls completed once under a 60-second timeout, with exit 0 and empty stderr. All ten JSON output records were read. Their finite-difference, free-word and rational-margin checks are controls of the displayed formulas and bookkeeping, not independent analytic evidence. No theorem is inferred from a PASS count or finite numerical agreement.

Final clarification changes made after the complete read: compact closure inside a larger smooth chart makes the global functional-calculus extension legitimate; the mass-to-D conversion is confined to the residual's bounded positive-energy support; and the derivative multiplier comparison explicitly removes its common phase.

No unresolved mathematical step was identified by this author within the exact conditional theorem. The next necessary step before substantial downstream reuse or publication is a fresh focused reconstruction of the frozen note, especially the unequal-time estimate, spectral-variable condition and creator-independence comparison. This statement does not predict that review's result. Fock/isometry, detectors, ND/EX, all-channel coverage, regular-seed density and physical realization remain outside this theorem.
