#!/usr/bin/env python3
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import urllib.request
from pypdf import PdfReader

here = Path(__file__).resolve().parent
source = here/"sources"
url = "https://arxiv.org/pdf/hep-th/0412226v4"
request = urllib.request.Request(url, headers={"User-Agent": "Codex bounded research source check"})
with urllib.request.urlopen(request, timeout=30) as response:
    data = response.read()
    metadata = dict(url=url, final_url=response.url, status=response.status,
                    content_type=response.headers.get("Content-Type"))
assert data.startswith(b"%PDF"), metadata
pdf = source/"Dybalski_hep-th_0412226v4.pdf"
pdf.write_bytes(data)
reader = PdfReader(pdf)
assert len(reader.pages) == 13, len(reader.pages)
pages = source/"pages"
pages.mkdir(exist_ok=True)
bindings = []
for i, page in enumerate(reader.pages, 1):
    text = page.extract_text(extraction_mode="layout")
    target = pages/(str(i).zfill(2)+".txt")
    target.write_text(text)
    bindings.append(dict(path=str(target), sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                         bytes=target.stat().st_size))
images = source/"rendered"
images.mkdir(exist_ok=True)
render = subprocess.run(["/Users/jonreilly/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm",
                         "-r", "100", "-png", str(pdf), str(images/"page")],
                        capture_output=True, timeout=45)
(source/"render.stdout").write_bytes(render.stdout)
(source/"render.stderr").write_bytes(render.stderr)
assert render.returncode == 0, render.stderr.decode(errors="replace")
image_paths = sorted(images.glob("page-*.png"))
assert len(image_paths) == 13, len(image_paths)
receipt = dict(downloaded_at=dt.datetime.now(dt.timezone.utc).isoformat(), **metadata,
               pdf_path=str(pdf), pdf_sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
               pages=13, extraction="pypdf layout", page_bindings=bindings,
               rendered_images=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
                                     bytes=p.stat().st_size) for p in image_paths],
               render_returncode=render.returncode)
(source/"download_receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps(dict(status="pass", pdf_sha256=receipt["pdf_sha256"], bytes=len(data),
                      pages=13, rendered_pages=len(image_paths)), sort_keys=True))
