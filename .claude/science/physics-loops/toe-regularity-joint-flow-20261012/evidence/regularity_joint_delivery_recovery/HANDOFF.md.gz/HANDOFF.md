# Frozen milestone handoff

Expected clean publication base: `dc7f415f73df3754653f4985382ca0fb96f07cda`.
Fixed deadline: 2026-10-12 16:00:52 UTC; it is not extended.

Root reviews the complete note/primary transformations and executes the actual
canonical controls, source mutants and mechanical gates before recording a
regular milestone publication. SPECIFICATIONS.json supplies exact primary,
baseline, mutation, supplemental-control and dependency paths. The preparation
script does not run them, change Git state, write caches or publish anything.
Source and evidence identities are frozen in INPUT_INVENTORY and EVIDENCE_MAP.
The original N36 defect is preserved and mapped to its exact reviewed repair.

All application hypotheses and finite-control limits remain explicit. No
current conservation, regular-seed density, Fock/detector extension or actual
microscopic model is inferred beyond each theorem's conditions. This packet
is not a live checkpoint; the sole live campaign checkpoint stays in the
transport worktree. Editable prompt files changed: none.
