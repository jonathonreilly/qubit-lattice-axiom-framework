# Three-note publication preparation

The parent-root owns review, execution, repository writes and publication.
The child preparer writes only the preparation script and this scratch folder.
The preparation script has **not been executed**, including its check-only mode.

`SPECIFICATIONS.json` is an import-free, literal-configuration preview for root's
canonical verification. `INPUT_INVENTORY.json` binds every file in the six
source/evidence folders, the selected root coverage/verifier files and current
consulted repository instructions/predecessors. It records 802 own/repository
files and 70 external third-party content files. The preparation script pins
the inventory hash and refreshes every binding before worktree writes.

The only mathematical replacement is the exact reviewed N36 weighted-Casimir
definition. Its repair-only note hash is checked before any publication edits.
All other changes are explicit metadata, portable references, historical status
labels, a separate publication appendix and primary output/timeout declarations.
The joint helper suppresses its adjacent JSON-file write; calculations and
self-hash behavior remain intact. Future imports precede injected declarations.
Each output has a complete before/after reconstruction map.

The script prepares exactly the three proposed notes, three primaries and the
`toe-regularity-joint-flow-20261012` packet. It requires clean worktree/index
HEAD `dc7f415f73df3754653f4985382ca0fb96f07cda` and nonexistent output paths.
It does not commit, push, fetch, edit the index, execute science, write caches,
change a graph manifest, create a PR or apply an audit. Root can run `--check-only`
first to build the full payload in memory without any worktree writes.

All original controls and their limitations remain visible. In particular, the
centre tent upper-bound gates still allow the two known wrong integrals; the
separate exact Simpson check rejects them. The mass nondiscriminating controls,
initial quadrature failure, corrected density draft and all joint passing-mutant
rows remain preserved. A control count does not establish a proof.

Remaining root work: inspect the exact transformations, verify canonical stdout
against frozen baselines and source hashes, rerun the actual-source mutation
families, create current caches, assess negative-claim/helper-packet conformance,
read the intended citation graph changes and finish focused checks. The packet
records those as pending, not PASS. Global combined pipeline and strict audit
lint remain landing gates. Update the preparation-time source-identity manifest
after adding fresh verification/caches or changing metadata.

The first inline specification capture encountered a guessed, nonexistent
`centre_regularity_review/run_mutations.py` path and exited before writing any
specification or worktree file. File discovery identified the actual
`centre_regularity_review/mutation_study.py`, now bound in the final inventory.
This was a bookkeeping failure, not a science-control result.

No Git commands, preparation-script execution, science controls, repository
writes, source deletion, prompt changes, PR actions or audit actions were
performed by this child. The transport worktree remains the sole live campaign
checkpoint. Weighted-boost work belongs to a later packet and is excluded here.
