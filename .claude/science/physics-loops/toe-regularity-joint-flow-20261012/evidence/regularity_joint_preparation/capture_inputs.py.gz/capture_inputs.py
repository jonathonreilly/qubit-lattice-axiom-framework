"""Bookkeeping only: capture input identities to scratch, never touch a worktree.

This parses literal configuration from the unexecuted preparation script. It
does not import it, run its functions, execute science or invoke Git.
"""
import ast
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "scattering_worktree"
script = S / "prepare_regularity_joint_publication.py"
module = ast.parse(script.read_text())
literal = {}
for node in module.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in {"BASE", "PACKET", "DEADLINE", "SPECS", "DEPENDENCIES"}:
            literal[node.targets[0].id] = ast.literal_eval(node.value)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"Nonregular or absent input: {path}")
    data = path.read_bytes()
    return {"original": str(path), "bytes": len(data), "sha256": sha(data)}


papers = {
    "Dybalski": {
        "source_id": "Dybalski_hep-th_0412226v4",
        "version": "hep-th/0412226v4",
        "abstract_url": "https://arxiv.org/abs/hep-th/0412226v4",
        "pdf_url": "https://arxiv.org/pdf/hep-th/0412226v4",
        "source_url": "https://arxiv.org/src/hep-th/0412226v4",
        "pdf_sha256": "3c616a4d6c8b52793bb669387a237de31ee66417450ddc5f29b7c93ece7b534d",
        "tex_sha256": "c425cfecc20136576180271a1e8e9c12df48ded2ae941655ad4e842363ee64a6",
        "source_archive_sha256": "938490c5750f8344f0c450ec1e36c8048cdfdd392f308269aa9d2cab6e4ed5f7",
        "local_original": str(S / "nonisolated_mass_scattering/sources/Dybalski_hep-th_0412226v4.pdf"),
    },
    "BDN": {
        "source_id": "BDN_1412.2970v2",
        "version": "arXiv:1412.2970v2",
        "abstract_url": "https://arxiv.org/abs/1412.2970v2",
        "pdf_url": "https://arxiv.org/pdf/1412.2970v2",
        "pdf_sha256": "3edeb48a167b9ae6a26d6d885ccde03b068423d432176a256eb0a4ee42a14126",
        "local_original": str(S / "nonisolated_mass_scattering/sources/BDN_1412.2970v2.pdf"),
    },
}


def classification(path):
    relative = path.relative_to(S)
    parts = relative.parts
    if parts[0] not in {"nonisolated_mass_scattering", "nonisolated_mass_review"}:
        selected = None
    elif "BDN_pages" in parts or path.name == "BDN_1412.2970v2.pdf":
        selected = papers["BDN"]
    elif any(p in {"pages", "rendered", "Dybalski_pages"} for p in parts):
        selected = papers["Dybalski"]
    elif path.name in {"Dybalski_hep-th_0412226v4.pdf", "Dybalski_hep-th_0412226v4.tex", "Dybalski_hep-th_0412226v4.source"}:
        selected = papers["Dybalski"]
    else:
        selected = None
    if selected:
        url = selected.get("source_url") if path.suffix in {".source", ".tex"} else selected["pdf_url"]
        return {
            "classification": "external_primary_content",
            "source_id": selected["source_id"], "version": selected["version"],
            "source_url": url, "upstream_pdf_sha256": selected["pdf_sha256"],
            "disposition": "Remain external; full original or derived extraction/render bytes are hashed but not bundled or deleted.",
        }
    if path.suffix.lower() in {".pdf", ".tex", ".source", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".tar", ".gz"}:
        raise RuntimeError("Unclassified possible external content: " + str(path))
    return {"classification": "own_or_repository_evidence", "preserved": "evidence/" + str(relative) + ".gz"}


paths = set()
membership = {}
excluded = []
for sp in literal["SPECS"]:
    for name in [sp["source"], sp["report"], sp["key"] + "_root_author_coverage.json", sp["key"] + "_root_review_coverage.json"]:
        paths.add(S / name)
    for folder in [sp["folder"], sp["review"]]:
        members = []
        for path in sorted((S / folder).rglob("*")):
            if not path.is_file():
                continue
            if "__pycache__" in path.parts or path.name == ".DS_Store":
                excluded.append({"original": str(path), "reason": "Transient bytecode or desktop metadata; source files remain included."})
                continue
            members.append(str(path.relative_to(S)))
            paths.add(path)
        membership[folder] = members
    for field in ["baseline_stdout", "mutation_source", "mutation_results", "supplemental_control"]:
        if S / sp[field] not in paths:
            raise RuntimeError("Missing explicit verification source: " + sp[field])
    for field, expected in [("source", sp["source_sha"]), ("report", sp["report_sha"])]:
        if binding(S / sp[field])["sha256"] != expected:
            raise RuntimeError("Frozen task identity mismatch: " + sp[field])

paths.update(S / name for name in [
    "Nonisolated_mass_root_primary_coverage.json",
    "verify_mass_author_and_sync_0330.py",
    "verify_mass_review_and_joint_author.py",
    "verify_centre_regularity_author.py",
    "verify_centre_regularity_review.py",
    "ROOT_CENTRE_REGULARITY_TO_GEOMETRIC_LEAD.md",
    "prepare_centre_current_publication.py",
])
rows = []
for path in sorted(paths):
    rows.append({**binding(path), **classification(path)})

worktree_inputs = [
    "AGENTS.md",
    "docs/ai_methodology/SCIENCE_WORKFLOW.md",
    "docs/ai_methodology/REVIEW_LOOP_PR_CONFORMANCE_SPEC.md",
    "docs/ai_methodology/skills/physics-loop/references/DELIVERY.md",
    "docs/ai_methodology/skills/physics-loop/references/CLAIM_STATUS.md",
    ".claude/science/physics-loops/toe-centre-current-20261012/reconstruct.py",
    ".claude/science/physics-loops/toe-centre-current-20261012/PUBLICATION_EDITS.json",
]
worktree_inputs += ["docs/" + d["note"] for d in literal["DEPENDENCIES"].values()]
for relative in worktree_inputs:
    path = W / relative
    rows.append({**binding(path), "classification": "own_or_repository_evidence", "preserved": "evidence/consulted_worktree/" + relative + ".gz"})
for dep in literal["DEPENDENCIES"].values():
    if binding(W / "docs" / dep["note"])["sha256"] != dep["sha256"]:
        raise RuntimeError("Published predecessor mismatch: " + dep["note"])
for paper in papers.values():
    if binding(Path(paper["local_original"]))["sha256"] != paper["pdf_sha256"]:
        raise RuntimeError("Official paper-byte binding mismatch")

inventory = {
    "base_revision": literal["BASE"],
    "capture_scope": "Read-only file inventory from the exact named source bundles, root coverage and consulted worktree files. No Git, science execution or new scientific review.",
    "files": rows, "source_directory_membership": membership,
    "external_reference_sources": list(papers.values()), "excluded_transient_files": excluded,
}
(Q / "INPUT_INVENTORY.json").write_text(json.dumps(inventory, indent=2, ensure_ascii=False) + "\n")

specs = literal["SPECS"]
for sp in specs:
    sp["note"] = sp["prefix"] + "_BOUNDED_THEOREM_NOTE_2026-10-12.md"
    sp["runner"] = sp["slug"] + "_2026_10_12.py"
    sp["claim"] = sp["slug"] + "_bounded_theorem_note_2026-10-12"
    sp["dependencies"] = [literal["DEPENDENCIES"][key] for key in sp["dependency_keys"]]
    sp["prerequisites"] = [d["note"] for d in sp["dependencies"]]
    sp["deps"] = [n.removesuffix(".md").lower() for n in sp["prerequisites"]]
    sp["timeout_sec"] = 60
    for field, relative in {
        "helper_sha": sp["folder"] + "/" + sp["helper"],
        "author_receipt_sha": sp["folder"] + "/" + sp["author_receipt"],
        "review_receipt_sha": sp["review"] + "/" + sp["review_receipt"],
    }.items():
        sp[field] = binding(S / relative)["sha256"]
    sp["audit_inputs"] = ["docs/" + sp["note"]] + ["docs/" + n for n in sp["prerequisites"]]
    sp["canonical_execution_status"] = "not_run_by_preparation"
preview = {"base_revision": literal["BASE"], "packet": literal["PACKET"], "specs": specs}
(Q / "SPECIFICATIONS.json").write_text(json.dumps(preview, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({
    "input_files": len(rows), "external_files": sum(x["classification"] == "external_primary_content" for x in rows),
    "own_files": sum(x["classification"] == "own_or_repository_evidence" for x in rows),
    "input_inventory_sha256": sha((Q / "INPUT_INVENTORY.json").read_bytes()),
    "specifications_sha256": sha((Q / "SPECIFICATIONS.json").read_bytes()),
    "worktree_files_written": 0, "preparation_script_executed": False,
}, indent=2))
