"""Read-only compile/literal/anchor checks; do not execute preparation code."""
import ast
import hashlib
import json
from pathlib import Path

Q = Path(__file__).resolve().parent
S = Q.parent
W = S.parent / "scattering_worktree"
script = S / "prepare_regularity_joint_publication.py"
data = script.read_bytes()
compile(data.decode(), str(script), "exec")
tree = ast.parse(data)
config = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in {"SPECS", "DEPENDENCIES", "INPUT_INVENTORY_SHA256", "REPAIRED_MASS_SHA256", "PACKET", "RECONSTRUCT"}:
            config[node.targets[0].id] = ast.literal_eval(node.value)
sha = lambda b: hashlib.sha256(b).hexdigest()
inventory_raw = (Q / "INPUT_INVENTORY.json").read_bytes()
assert sha(inventory_raw) == config["INPUT_INVENTORY_SHA256"]
inventory = json.loads(inventory_raw)
for row in inventory["files"]:
    raw = Path(row["original"]).read_bytes()
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], row["original"]
notes = {}
primaries = {}
for sp in config["SPECS"]:
    notes[sp["key"]] = (S / sp["source"]).read_text()
    assert sha(notes[sp["key"]].encode()) == sp["source_sha"]
    primaries[sp["key"]] = (S / sp["folder"] / sp["helper"]).read_text()
    compile(primaries[sp["key"]], sp["helper"], "exec")
    assert not (W / "docs" / (sp["prefix"] + "_BOUNDED_THEOREM_NOTE_2026-10-12.md")).exists()
    assert not (W / "scripts" / (sp["slug"] + "_2026_10_12.py")).exists()
assert not (W / config["PACKET"]).exists()

# These are string identity checks, not evaluations of any physical formula.
repair = json.loads((S / "nonisolated_mass_review/N36_PUBLICATION_REPAIR.json").read_text())
original = notes["Nonisolated_mass"]
assert original.count(repair["before"]) == 1
assert sha(original.replace(repair["before"], repair["after"], 1).encode()) == config["REPAIRED_MASS_SHA256"]

fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "transform_note")
literal_note_replacements = []
for node in ast.walk(fn):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "replace":
        if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
            before = node.args[0].value
            count = sum(text.count(before) for text in notes.values())
            assert count == 1, (before, count)
            literal_note_replacements.append(before)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "transform_primary")
literal_primary_replacements = []
for node in ast.walk(fn):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "replace":
        if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
            before = node.args[0].value
            count = sum(text.count(before) for text in primaries.values())
            assert count == 1, (before, count)
            literal_primary_replacements.append(before)
for key, prefix in [("Nonisolated_mass", "Write S for `/Users/"), ("Centre_regularity", "Let S be `/Users/"), ("Joint_flow", "Write S for this note's directory.")]:
    assert sum(line.startswith(prefix) for line in notes[key].splitlines()) == 1
for key, prefix in [("Nonisolated_mass", "The fixed campaign deadline is"), ("Centre_regularity", "Only this note and"), ("Joint_flow", "Only this note and")]:
    assert sum(line.startswith(prefix) for line in notes[key].splitlines()) == 1
assert primaries["Joint_flow"].count("    raise SystemExit(bool(out['failed']))") == 1
compile(config["RECONSTRUCT"], "reconstruct.py", "exec")

result = {
    "preparation_script_sha256": sha(data),
    "preparation_script_executed": False,
    "worktree_files_written": 0,
    "git_commands_executed": 0,
    "science_controls_run": False,
    "checks": {
        "preparation_syntax": "compiled_only",
        "reconstruction_syntax": "compiled_only",
        "original_primary_syntax": "compiled_only",
        "frozen_input_byte_bindings": len(inventory["files"]),
        "sole_repair_only_note_hash": config["REPAIRED_MASS_SHA256"],
        "literal_note_replacement_anchors": len(literal_note_replacements),
        "literal_primary_replacement_anchors": len(literal_primary_replacements),
        "output_paths": "absent",
    },
    "limits": [
        "No preparation function was imported or executed, including check-only mode.",
        "No canonical primary or science calculation was executed; final transformed payload and complete conformance require root execution.",
        "No Git state was inspected; the preparation script itself checks exact HEAD and cleanliness when root runs it.",
    ],
    "bookkeeping_failure": "Initial inline specification capture guessed run_mutations.py; discovery resolved the actual centre mutation_study.py before final capture.",
}
(Q / "STATIC_CHECKS.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
