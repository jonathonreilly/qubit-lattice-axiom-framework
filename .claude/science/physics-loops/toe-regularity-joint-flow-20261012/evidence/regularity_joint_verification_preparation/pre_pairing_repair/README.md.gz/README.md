# Prepared regularity/joint verification

The deliverable is `../run_regularity_joint_verification.py`. Its author has
only parsed syntax, inspected source, checked literal mutation anchors and
captured hashes. The deliverable has not been imported or executed. No science,
Git command or repository/worktree write was performed during preparation.

`SOURCE_FREEZE.json` binds 1,008 selected files (4,680,095 bytes), including the
complete prepared packet, its six published surfaces, exact declared proof
dependencies, original helpers/baselines/mutation evidence, relevant current
workflow instructions and the local Python verification-tool closure.
Its SHA-256 is
`1faffe7ae20fa6e44fc74436754ea4ec1aa5094b9e8ba2dccd7922ca7a4e3cdd`.
`ANCHOR_CHECKS.json` records the mutation source anchors and their prospective
whole-canonical-source hashes. `STATIC_CHECKS.json` records final syntax and
output-map checks together with the deliverable's hash.

Root execution first checks the fixed `dc7f415f73df3754653f4985382ca0fb96f07cda`
base and source freeze. It runs reconstruction before vocabulary repair, saves
the vocabulary JSON, then requires reconstruction and every frozen byte still
to match before running any primary. Each primary uses exactly
`runner_cache.execute_and_write_cache(path, 60)`. A scoped in-memory observer
preserves the complete inner `execute_runner` return immediately, because the
outer API's identity check can otherwise discard it. The complete outer result
is also saved before cache freshness checks. The original function is restored
even if the API fails. This adds no second execution and does not edit tooling.

Every scientific stdout byte must equal its original frozen baseline. The only
allowed changes come from `PUBLICATION_EDITS.json`: the mass historical review
wording, mapped completion/scope lines, and the joint final source hash/totals.
The two `TOTAL: PASS=1 FAIL=0` markers mean completion of those finite drivers;
they are not inferred counts of mathematical predicates. The joint total comes
from its 37 recorded predicate rows. Mapped traceback changes are restricted to
the executed filename and exact unchanged source lines moved by packaging.
Full raw stdout, stderr, sources, timing, timeout and failure artifacts remain
under a unique `runs/<UTC>-<id>/` directory; original evidence is untouched.

The original mutation definitions and results justify these expected outcomes:

| Family | Cases | Expected survivors |
| --- | ---: | ---: |
| Nonisolated mass | 14 | 3 |
| Centre regularity | 8 | 2 |
| Joint flow | 5 | 0 |

All 27 mutations are applied to each entire canonical source using the exact
original replacements. The mass survivors include two nondiscriminating gates
and a benign weaker padding inequality. Both bad centre tent integrals remain
survivors of the author's upper-bound checks; the earlier independent Simpson
finding is not silently installed as a new gate. Joint passing rows remain
visible alongside each mutation's failed predicates. New replay timeouts are
explicitly 60 seconds; original result records and their original timing are
retained. There are no automatic retries or scientific repairs.

After the canonical/mutation runs, root execution runs the serialized citation
graph builder and manifest writer, then focused compatibility against the
fixed base, preserving their raw logs. These requested tools may write their
normal cache/graph/manifest outputs. Focused compatibility uses existing ledger
rows, so the script separately records actual checked claim IDs and does not
infer that a successful exit covers all newly authored claims.

The freeze does not bind external Python/system libraries or every unrelated
repository input consumed by the global graph. Final metadata/link checks,
complete repository source manifests, graph interpretation and publication
remain root's later work. No audit application, retained claim, model claim,
commit, push, PR or prompt change is performed by this deliverable.
