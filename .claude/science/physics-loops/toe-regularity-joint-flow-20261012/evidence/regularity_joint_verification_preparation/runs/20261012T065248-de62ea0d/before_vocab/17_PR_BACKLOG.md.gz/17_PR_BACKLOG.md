# Publication actions pending root

No PR is created, updated, merged or claimed by preparation. Root is responsible
for the complete final-source read, exact canonical execution and mutation
comparison, cache creation through runner_cache, intended citation-graph
acknowledgment, focused conformance and regular milestone publication. Preserve
all failed checks and recoverable source versions. Global combined pipeline,
strict audit lint and changed-evidence readiness remain separate landing gates.
