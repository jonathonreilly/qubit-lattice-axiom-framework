# Evidence roles and exposure

Each author note has a separate full source reconstruction and a distinct finite
control implementation. The reviews disclose prior source/metadata exposure;
their pre-author-helper freezes do not imply blind checking. Root proposed the
mechanisms and remains a coauthor. The mechanical preparer performs no new
scientific review. Full author/reviewer evidence and root coverage records are
preserved with source identities. The external paper inventory is provenance,
not a new paper-read or independent-check claim.
