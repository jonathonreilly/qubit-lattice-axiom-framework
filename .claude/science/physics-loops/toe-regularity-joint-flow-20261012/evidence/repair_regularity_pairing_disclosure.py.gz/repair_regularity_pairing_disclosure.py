"""Add the required honest checker-pairing disclosure; preserve all prior bytes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

S = Path(__file__).resolve().parent
W = S.parent / 'scattering_worktree'
P = W / '.claude/science/physics-loops/toe-regularity-joint-flow-20261012'
R = S / 'regularity_joint_packaging_recovery'
R.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
path = P / 'PUBLICATION_EDITS.json'
old = path.read_bytes()
(R / 'PUBLICATION_EDITS.before_pairing.json').write_bytes(old)
mapping = json.loads(old)
addition = '''

Checker pairing: the authors and focused reviewers used separate worker
contexts of the same configured model family, preserving the user's selected
model and reasoning effort. Different model families and blind checking are
not claimed. The distinct reconstruction/control mechanisms and actual source
exposure are documented above and in each complete source review. This pairing
disclosure is not an independent-audit grade or a retained-status decision.
'''
changes = []
for row in mapping['outputs']:
    if row['kind'] != 'note':
        continue
    p = W / row['publication_path']
    data = p.read_bytes()
    assert sha(data) == row['publication_sha256']
    assert b'Checker pairing:' not in data
    (R / p.name).write_bytes(data)
    updated = data + addition.encode()
    row['appended_text'] += addition
    before = row['publication_sha256']
    row['publication_sha256'] = sha(updated)
    p.write_bytes(updated)
    changes.append(dict(path=row['publication_path'], before_sha256=before,
                        after_sha256=sha(updated), appended_text=addition))
mapping['administrative_followups'] = [dict(
    reason='Required same-model-family/separate-context checker-pairing disclosure',
    changes=changes, mathematical_changes=False)]
path.write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + '\n')
(R / 'repair_receipt.json').write_text(json.dumps(dict(
    utc=datetime.now(timezone.utc).isoformat(), old_map_sha256=sha(old),
    new_map_sha256=sha(path.read_bytes()), changes=changes,
    source_proofs_and_primaries_unchanged=True), indent=2) + '\n')
print(json.dumps(dict(new_map_sha256=sha(path.read_bytes()), notes=len(changes),
                     mathematical_changes=False)))
