#!/usr/bin/env python3
"""Execute the frozen three-primary verification once per explicit invocation.

Prepared for root; not executed by its author. Preserve raw same-run returns,
all canonical scientific output, whole-source mutants, failures and timeouts.
No scientific formula/gate repair, audit application, Git mutation or publication
is performed. Graph/cache tools have their normal explicitly requested outputs.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import textwrap
import time
import traceback
import uuid

S = Path(__file__).resolve().parent
W = S.parent / "scattering_worktree"
P = W / ".claude/science/physics-loops/toe-regularity-joint-flow-20261012"
Q = S / "regularity_joint_verification_preparation"
BASE = "dc7f415f73df3754653f4985382ca0fb96f07cda"
FREEZE_SHA256 = "9b35c7e362c4ed050e702a0fa9cbefc825d87c5e955e30ddac16ba3d165ac2d9"
TIMEOUT = 60
sys.dont_write_bytecode = True


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def raw(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), f"Missing/nonregular source: {path}")
    return path.read_bytes()


def js(path):
    return json.loads(raw(path))


def write_json(path, value):
    # All calls target this invocation's unique evidence attempt directory.
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def file_binding(path):
    data = raw(path)
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}


def check_freeze(freeze):
    need(sha(raw(Q / "SOURCE_FREEZE.json")) == FREEZE_SHA256, "Verification freeze changed")
    for row in freeze["files"]:
        data = raw(row["path"])
        need(len(data) == row["bytes"] and sha(data) == row["sha256"], "Source drift: " + row["path"])


def check_base():
    # Read only. The expected worktree is dirty with the prepared publication.
    head = subprocess.check_output(["git", "rev-parse", "--verify", "HEAD"], cwd=W,
                                   env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"}, text=True).strip()
    need(head == BASE, f"Expected {BASE}; found {head}")


def literal_assignment(path, name):
    nodes = [n for n in ast.parse(raw(path)).body if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    need(len(nodes) == 1, f"Ambiguous literal {name} in {path}")
    return ast.literal_eval(nodes[0].value)


def replace_once(text, before, after, label):
    need(text.count(before) == 1, f"Nonunique {label} source replacement: {before!r}")
    return text.replace(before, after, 1)


def render_print_argument(node, output):
    """Interpret only the mapped output expression, never primary/helper code."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name) and node.value.id == "out":
        key = ast.literal_eval(node.slice)
        need(key in {"total", "failed"}, "Unexpected dynamic output field")
        return output[key]
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
        left = render_print_argument(node.left, output)
        right = render_print_argument(node.right, output)
        return left + right if isinstance(node.op, ast.Add) else left - right
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str":
        need(len(node.args) == 1 and not node.keywords, "Unexpected output conversion")
        return str(render_print_argument(node.args[0], output))
    raise RuntimeError("Unexpected mapped output expression: " + ast.dump(node))


def render_prints(code, output, allow_final_raise=False):
    nodes = ast.parse(textwrap.dedent(code)).body
    lines = []
    for index, node in enumerate(nodes):
        if allow_final_raise and index == len(nodes) - 1 and isinstance(node, ast.Raise):
            need(ast.unparse(node) == "raise SystemExit(bool(out['failed']))", "Changed final joint failure gate")
            continue
        need(isinstance(node, ast.Expr) and isinstance(node.value, ast.Call), "Mapped suffix is not print-only")
        call = node.value
        need(isinstance(call.func, ast.Name) and call.func.id == "print" and len(call.args) == 1 and not call.keywords,
             "Unexpected mapped print")
        value = render_print_argument(call.args[0], output)
        need(isinstance(value, str), "Mapped print did not yield a string")
        lines.append(value)
    return "".join(line + "\n" for line in lines).encode()


def expected_stdout(key, old_stdout, primary_row, canonical_sha, completed):
    """Exact output transport across the reviewed administrative source edits."""
    if key == "Joint_flow":
        need(completed, "Joint source should report every predicate even when rejecting a mutant")
        lines = old_stdout.decode().splitlines(keepends=True)
        need(bool(lines) and lines[-1].endswith("\n"), "Incomplete frozen joint stdout")
        summary = json.loads(lines[-1])
        need(set(summary) == {"total", "failed", "source_sha256"}, "Unexpected frozen joint summary")
        scientific = [json.loads(line) for line in lines[:-1]]
        need(summary["total"] == len(scientific), "Frozen joint predicate total disagrees")
        need(all(isinstance(row.get("passed"), bool) for row in scientific), "Missing frozen predicate result")
        need(summary["failed"] == sum(not row["passed"] for row in scientific), "Frozen joint failure total disagrees")
        summary["source_sha256"] = canonical_sha
        mapped = [e for e in primary_row["edits"] if e["before"] == "    raise SystemExit(bool(out['failed']))"]
        need(len(mapped) == 1 and primary_row["appended_text"] == "", "Joint output map is ambiguous")
        return ("".join(lines[:-1]) + json.dumps(summary) + "\n").encode() + render_prints(mapped[0]["after"], summary, True)
    if not completed:
        # Assertions terminate before the historical summary and mapped suffix.
        return old_stdout
    updated = old_stdout.decode()
    if key == "Nonisolated_mass":
        matches = [e for e in primary_row["edits"] if e["before"].startswith("independence=")]
        need(len(matches) == 1, "Mass historical-summary map is ambiguous")
        old_value = ast.literal_eval(matches[0]["before"].split("=", 1)[1])
        new_value = ast.literal_eval(matches[0]["after"].split("=", 1)[1])
        updated = replace_once(updated, old_value, new_value, "historical summary output")
    return updated.encode() + render_prints(primary_row["appended_text"], {})


def mutation_cases(sp):
    """Read original literal edits and recorded gates without running drivers."""
    original = raw(S / sp["folder"] / sp["helper"]).decode()
    need(sha(original.encode()) == sp["helper_sha"], "Original helper identity mismatch")
    report = js(S / sp["mutation_results"])
    key = sp["key"]
    cases = []
    if key == "Nonisolated_mass":
        definitions = literal_assignment(S / sp["mutation_source"], "cases")
        recorded = {r["name"]: r for r in report["cases"]}
        need(report["author_source_sha256"] == sp["helper_sha"], "Mass mutation authority mismatch")
        need(report["total"] == len(definitions) == len(recorded), "Mass mutation count mismatch")
        for name, replacements, expected, scope in definitions:
            r = recorded[name]
            need(r["returncode"] == r["expected_returncode"] == expected and r["expectation_met"], "Mass recorded gate mismatch")
            folder = S / sp["review"] / "controls/author_mutations"
            cases.append({"name": name, "replacements": replacements, "expected_exit": expected,
                          "scope": scope, "record": r, "source": folder / (name + ".py"),
                          "stdout": folder / (name + ".stdout"), "stderr": folder / (name + ".stderr")})
    elif key == "Centre_regularity":
        definitions = literal_assignment(S / sp["mutation_source"], "cases")
        recorded = {r["name"]: r for r in report}
        need(len(definitions) == len(recorded), "Centre mutation count mismatch")
        for name, before, after in definitions:
            r = recorded[name]
            need((r["old"], r["new"]) == (before, after), "Centre recorded replacement mismatch")
            need(r["returncode"] in (0, 1) and not r["timed_out"], "Unresolved original centre run")
            folder = S / sp["review"] / "mutations"
            cases.append({"name": name, "replacements": [(before, after)], "expected_exit": r["returncode"],
                          "scope": r["outcome"], "record": r, "source": folder / (name + ".py"),
                          "stdout": folder / (name + ".stdout"), "stderr": folder / (name + ".stderr")})
    else:
        definitions = literal_assignment(S / sp["mutation_source"], "DEFECTS")
        recorded = {r["name"]: r for r in report["defects"]}
        need(report["original_sha256"] == sp["helper_sha"] and len(definitions) == len(recorded), "Joint mutation authority mismatch")
        for name, before, after, scope in definitions:
            r = recorded[name]
            need(r["replacement"] == {"before": before, "after": after}, "Joint recorded replacement mismatch")
            need(r["status"] == "completed" and r["exit_code"] == 1 and r["failed"] > 0, "Unresolved original joint gate")
            folder = S / sp["folder"] / "mutations" / name
            cases.append({"name": name, "replacements": [(before, after)], "expected_exit": r["exit_code"],
                          "scope": scope, "record": r, "source": folder / "joint_controls.py",
                          "stdout": folder / "stdout.jsonl", "stderr": folder / "stderr.txt"})
    need(len({r["name"] for r in cases}) == len(cases), "Duplicate mutation name")
    for case in cases:
        mutated = original
        for before, after in case["replacements"]:
            mutated = replace_once(mutated, before, after, case["name"])
        need(mutated.encode() == raw(case["source"]), "Frozen mutant differs from literal edits: " + case["name"])
        recorded_sha = case["record"].get("source_sha256", case["record"].get("mutant_sha256"))
        need(sha(mutated.encode()) == recorded_sha, "Frozen mutant source hash mismatch")
        for stream in ["stdout", "stderr"]:
            value = case["record"].get(stream + "_sha256")
            if value is not None:
                need(sha(raw(case[stream])) == value, "Frozen mutant stream mismatch")
    return cases


def log_run(folder, command, timeout, cwd):
    folder.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    timed_out, launch_error = False, None
    try:
        run = subprocess.run(command, cwd=cwd, stdin=subprocess.DEVNULL,
                             capture_output=True, timeout=timeout,
                             env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        stdout, stderr, code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", None
        timed_out = True
    except OSError as exc:
        stdout, stderr, code = b"", str(exc).encode(), None
        launch_error = repr(exc)
    elapsed = time.monotonic() - clock
    (folder / "stdout").write_bytes(stdout)
    (folder / "stderr").write_bytes(stderr)
    receipt = {"command": command, "cwd": str(cwd), "started_utc": started,
               "finished_utc": datetime.now(timezone.utc).isoformat(), "timeout_seconds": timeout,
               "elapsed_seconds": elapsed, "exit_code": code, "timed_out": timed_out,
               "launch_error": launch_error, "stdout_bytes": len(stdout), "stderr_bytes": len(stderr),
               "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)}
    write_json(folder / "execution.json", receipt)
    return receipt, stdout, stderr


def require_exit(receipt, expected=0):
    need(not receipt["timed_out"] and receipt["launch_error"] is None and receipt["exit_code"] == expected,
         "Unexpected execution result; complete streams and receipt were preserved: " + str(receipt))


def compare_output(folder, actual, expected, label):
    # Keep full streams even when a single byte differs; never accept a tail.
    (folder / (label + ".expected")).write_bytes(expected)
    record = {"label": label, "actual_bytes": len(actual), "expected_bytes": len(expected),
              "actual_sha256": sha(actual), "expected_sha256": sha(expected), "equal": actual == expected}
    write_json(folder / (label + ".comparison.json"), record)
    if actual != expected:
        diff = "".join(difflib.unified_diff(expected.decode(errors="replace").splitlines(True),
                                           actual.decode(errors="replace").splitlines(True),
                                           fromfile="frozen_expected", tofile="actual"))
        (folder / (label + ".diff")).write_text(diff)
    need(record["equal"], "Complete " + label + " mismatch; full evidence preserved in " + str(folder))


def mapped_stderr(data, original_script, canonical_mutant):
    # Only an unchanged source line may move. Do not erase arbitrary traceback
    # line numbers or accept a different assertion merely because its type fits.
    old_lines = raw(original_script).decode().splitlines(keepends=True)
    new_lines = raw(canonical_mutant).decode().splitlines(keepends=True)
    line_map = {}
    for block in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_matching_blocks():
        for offset in range(block.size):
            line_map[block.a + offset + 1] = block.b + offset + 1
    records = []
    pattern = re.compile(r'^(\s*File ")([^"\n]+)(", line )(\d+)(, in [^\n]*\n?)$', re.MULTILINE)

    def adapt(match):
        if match[2] != str(original_script):
            return match[0]
        old_line = int(match[4])
        need(old_line in line_map, "Frozen traceback points to an altered source line")
        new_line = line_map[old_line]
        need(old_lines[old_line - 1] == new_lines[new_line - 1], "Traceback line map is not byte preserving")
        records.append({"original_path": str(original_script), "original_line": old_line,
                        "canonical_mutant_path": str(canonical_mutant), "canonical_mutant_line": new_line,
                        "unchanged_source_line": old_lines[old_line - 1]})
        return match[1] + str(canonical_mutant) + match[3] + str(new_line) + match[5]

    expected = pattern.sub(adapt, data.decode())
    need(str(original_script) not in expected, "Unmapped original source path in frozen stderr")
    return expected.encode(), records


def canonical_run(runner_cache, sp, primary_row, folder):
    folder.mkdir(parents=True, exist_ok=False)
    path = "scripts/" + sp["runner"]
    current = raw(W / path)
    need(sha(current) == primary_row["publication_sha256"], "Canonical primary changed")
    (folder / "canonical_source.py").write_bytes(current)
    cache_before = W / "logs/runner-cache" / (Path(path).stem + ".txt")
    if cache_before.exists():
        (folder / "cache.before.txt").write_bytes(raw(cache_before))
    captured = []
    original_execute_runner = runner_cache.execute_runner

    def preserve_execute_return(runner_path, timeout_sec):
        result = original_execute_runner(runner_path, timeout_sec=timeout_sec)
        # FIRST action after execute_runner returns: preserve the FULL raw
        # return before execute_and_write_cache's internal identity check.
        write_json(folder / "execute_runner.raw_return.json", result)
        (folder / "execute_runner.stdout").write_text(result.get("stdout") or "")
        (folder / "execute_runner.stderr").write_text(result.get("stderr") or "")
        captured.append(result)
        return result

    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    runner_cache.execute_runner = preserve_execute_return
    try:
        result, cache = runner_cache.execute_and_write_cache(path, 60)
        # FIRST action after the public API returns: save its entire result,
        # before cache_status or any other later cache/API identity call.
        write_json(folder / "execute_and_write_cache.raw_return.json", result)
    except BaseException:
        (folder / "api_exception.traceback").write_text(traceback.format_exc())
        write_json(folder / "api_exception.json", {"started_utc": started,
                   "elapsed_seconds": time.monotonic() - clock, "raw_inner_return_preserved": len(captured) == 1,
                   "reexecution_performed": False})
        raise
    finally:
        runner_cache.execute_runner = original_execute_runner
    write_json(folder / "envelope.json", {"started_utc": started, "elapsed_seconds": time.monotonic() - clock,
               "cache_path": str(cache) if cache is not None else None,
               "canonical_source_sha256": sha(current), "timeout_seconds": TIMEOUT,
               "raw_stream_convention": "runner_cache merges stderr into returned stdout; its stderr field is empty by design"})
    need(len(captured) == 1 and result == captured[0], "Unexpected envelope execution count/result rewrite")
    need(result["status"] == "ok" and result["exit_code"] == 0 and result["timeout_sec"] == TIMEOUT,
         "Canonical execution failed; full return preserved")
    need(not result["stderr"] and cache is not None, "Canonical stderr/cache result is unexpected")
    expected = expected_stdout(sp["key"], raw(S / sp["baseline_stdout"]), primary_row, sha(current), True)
    compare_output(folder, result["stdout"].encode(), expected, "complete_stdout")
    need(not (W / "scripts/joint_controls_results.json").exists(), "Canonical joint helper wrote an adjacent JSON result")
    # All raw returns and complete streams already exist outside the cache.
    status = runner_cache.cache_status(path)
    write_json(folder / "cache_identity.json", {"status": status, "cache_path": str(cache)})
    need(status == "fresh", "Fresh canonical cache check failed; raw output is preserved")
    (folder / "cache.after.txt").write_bytes(raw(cache))
    return {"key": sp["key"], "source_sha256": sha(current), "elapsed_sec": result["elapsed_sec"],
            "stdout_bytes": len(result["stdout"].encode()), "stdout_sha256": sha(result["stdout"].encode()),
            "cache": str(cache), "evidence": str(folder)}


def run_mutant(sp, case, primary_row, folder):
    folder.mkdir(parents=True, exist_ok=False)
    original = raw(W / primary_row["publication_path"]).decode()
    changed = original
    for before, after in case["replacements"]:
        changed = replace_once(changed, before, after, case["name"])
    path = folder / "whole_source_mutant.py"
    path.write_text(changed)
    (folder / "source.diff").write_text("".join(difflib.unified_diff(
        original.splitlines(True), changed.splitlines(True), fromfile=primary_row["publication_path"], tofile=path.name)))
    write_json(folder / "source_provenance.json", {
        "key": sp["key"], "name": case["name"], "canonical_source_sha256": sha(original.encode()),
        "source_sha256": sha(changed.encode()), "original_mutant_source": file_binding(case["source"]),
        "original_stdout": file_binding(case["stdout"]), "original_stderr": file_binding(case["stderr"]),
        "replacements": case["replacements"], "expected_exit": case["expected_exit"],
        "expected_survival": case["expected_exit"] == 0, "scope": case["scope"],
        "original_execution_record": case["record"],
    })
    receipt, stdout, stderr = log_run(folder / "execution", [sys.executable, str(path)], TIMEOUT, W)
    require_exit(receipt, case["expected_exit"])
    completed = sp["key"] == "Joint_flow" or case["expected_exit"] == 0
    expected = expected_stdout(sp["key"], raw(case["stdout"]), primary_row, sha(changed.encode()), completed)
    compare_output(folder, stdout, expected, "complete_stdout")
    expected_error, stderr_map = mapped_stderr(raw(case["stderr"]), case["source"], path)
    write_json(folder / "stderr_source_map.json", stderr_map)
    compare_output(folder, stderr, expected_error, "complete_stderr")
    need(not (folder / "joint_controls_results.json").exists(), "Mutant wrote the suppressed adjacent result file")
    return {"key": sp["key"], "name": case["name"], "expected_exit": case["expected_exit"],
            "actual_exit": receipt["exit_code"], "expected_survival": case["expected_exit"] == 0,
            "elapsed_seconds": receipt["elapsed_seconds"], "source_sha256": sha(changed.encode()),
            "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "evidence": str(folder)}


def main():
    freeze = js(Q / "SOURCE_FREEZE.json")
    check_freeze(freeze)
    check_base()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    run_root = Q / "runs" / run_id
    run_root.mkdir(parents=True, exist_ok=False)
    (run_root / "verification_script.py").write_bytes(raw(__file__))
    (run_root / "SOURCE_FREEZE.json").write_bytes(raw(Q / "SOURCE_FREEZE.json"))
    state = {"attempt": str(run_root), "base_revision": BASE, "stage": "initial_reconstruction",
             "status": "running", "canonical": [], "mutations": [], "graph": {},
             "runtime": {"python_executable": sys.executable, "python_version": sys.version,
                         "platform": sys.platform, "assertions_enabled": __debug__}}

    def checkpoint(stage):
        state["stage"] = stage
        write_json(run_root / "STATE.json", state)

    try:
        checkpoint("initial_reconstruction")
        receipt, _, _ = log_run(run_root / "reconstruct.before", [sys.executable, str(P / "reconstruct.py")], TIMEOUT, W)
        require_exit(receipt)
        mapping = js(P / "PUBLICATION_EDITS.json")
        specs = js(P / "SPECIFICATIONS.json")["specs"]
        need(mapping["base_revision"] == BASE, "Publication map has wrong base")
        primary_rows = {row["publication_path"]: row for row in mapping["outputs"] if row["kind"] == "primary"}
        need(len(primary_rows) == len(specs), "Primary mapping/specification mismatch")
        cases = {sp["key"]: mutation_cases(sp) for sp in specs}
        expected_counts = {key: {"cases": len(values), "survivors": sum(c["expected_exit"] == 0 for c in values)}
                           for key, values in cases.items()}
        write_json(run_root / "expected_mutations.json", expected_counts)
        editable = [W / row["publication_path"] for row in mapping["outputs"]] + sorted(P.glob("*.md")) + [P / "reconstruct.py"]
        snapshots = run_root / "before_vocab"
        snapshots.mkdir()
        for index, path in enumerate(editable):
            (snapshots / (str(index) + "_" + path.name)).write_bytes(raw(path))
        write_json(snapshots / "manifest.json", [file_binding(path) for path in editable])
        checkpoint("vocabulary_fix")
        vocab_report = run_root / "vocab_report.json"
        command = [sys.executable, "scripts/vocab_lint.py", "--fix", "--report-path", str(vocab_report)]
        command += [str(path.relative_to(W)) for path in editable]
        receipt, _, _ = log_run(run_root / "vocab", command, TIMEOUT, W)
        require_exit(receipt)
        report = js(vocab_report)
        need(report["summary"]["total_auto_correctable"] == report["summary"]["total_needs_human"] == 0,
             "Vocabulary report is not clean; no science was executed")
        checkpoint("post_vocabulary_reconstruction")
        receipt, _, _ = log_run(run_root / "reconstruct.after_vocab", [sys.executable, str(P / "reconstruct.py")], TIMEOUT, W)
        require_exit(receipt)
        check_freeze(freeze)
        check_base()
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        sys.path.insert(0, str(W / "scripts"))
        import runner_cache
        need(Path(runner_cache.__file__).resolve() == (W / "scripts/runner_cache.py").resolve(), "Wrong runner_cache module")
        for sp in specs:
            checkpoint("canonical_" + sp["key"])
            check_freeze(freeze)
            row = primary_rows["scripts/" + sp["runner"]]
            need(sp["timeout_sec"] == TIMEOUT, "Timeout specification drift")
            state["canonical"].append(canonical_run(runner_cache, sp, row, run_root / ("canonical_" + sp["key"])))
            checkpoint("mutations_" + sp["key"])
            for case in cases[sp["key"]]:
                check_freeze(freeze)
                entry = run_mutant(sp, case, row, run_root / ("mutation_" + sp["key"] + "_" + case["name"]))
                state["mutations"].append(entry)
                checkpoint("mutations_" + sp["key"])
        for key, counts in expected_counts.items():
            actual = [r for r in state["mutations"] if r["key"] == key]
            need(len(actual) == counts["cases"] and sum(r["actual_exit"] == 0 for r in actual) == counts["survivors"],
                 "Mutation result aggregation disagrees with its source authority")
        check_freeze(freeze)
        check_base()
        manifest = W / "docs/audit/data/citation_graph_manifest.json"
        (run_root / "citation_graph_manifest.before.json").write_bytes(raw(manifest))
        for name, script in [("build", "docs/audit/scripts/run_citation_graph_build.py"),
                             ("manifest", "docs/audit/scripts/write_citation_graph_manifest.py")]:
            checkpoint("citation_" + name)
            receipt, _, _ = log_run(run_root / ("citation_" + name), [sys.executable, script], 180, W)
            state["graph"][name] = receipt
            checkpoint("citation_" + name)
            require_exit(receipt)
        (run_root / "citation_graph_manifest.after.json").write_bytes(raw(manifest))
        checkpoint("focused_audit_compatibility")
        command = [sys.executable, "docs/audit/scripts/check_changed_audit_evidence.py", "--base", BASE,
                   "--include-worktree", "--json"]
        receipt, stdout, _ = log_run(run_root / "focused_audit_compatibility", command, 120, W)
        state["focused_compatibility"] = receipt
        require_exit(receipt)
        js_result = json.loads(stdout)
        write_json(run_root / "focused_audit_compatibility.parsed.json", js_result)
        need(js_result["base"] == BASE and js_result["diff_scope"] == "committed_and_worktree",
             "Focused compatibility report has the wrong base or scope")
        need(not js_result["failures"] and not js_result["control_failures"], "Focused compatibility JSON reports failures")
        state["focused_claim_coverage"] = {
            "requested_publication_claims": [sp["claim"] for sp in specs],
            "checked_claims": [entry["claim_id"] for entry in js_result["checked"]],
            "limit": "This gate uses existing ledger rows; a successful exit does not establish coverage of newly authored claims.",
        }
        check_freeze(freeze)
        check_base()
        state["status"] = "completed"
        state["verification_script_sha256"] = sha(raw(__file__))
        state["limits"] = ["Scientific proofs and model premises are not established by finite outputs.",
                           "Known mutation survivors are preserved; no scientific gate was repaired.",
                           "Source manifests, final metadata/link review, graph interpretation and publication remain root's later work.",
                           "No audit application, main push, prompt edit or PR action was performed."]
        checkpoint("completed")
        print(json.dumps({"attempt": str(run_root), "canonical_runs": len(state["canonical"]),
                          "mutation_cases": len(state["mutations"]), "expected_counts": expected_counts,
                          "status": "completed", "publication_performed": False}, indent=2))
    except BaseException:
        state["status"] = "failed"
        (run_root / "FAILURE.traceback").write_text(traceback.format_exc())
        write_json(run_root / "STATE.json", state)
        print("Verification stopped; all completed/partial evidence is preserved at " + str(run_root), file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
