"""Verify frozen bytes and record completed root reading; not independent review."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
S=Path(__file__).resolve().parent; A=S/'centre_regularity_to_geometric'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((A/'FREEZE_RECEIPT.json').read_text())
assert sha((A/'FREEZE_RECEIPT.json').read_bytes())=='08c7d067c972b8351d491f799f7c397d060b38c8bacec4b47dfb6f76727e4ca6'
m=json.loads((A/'FREEZE_MANIFEST.json').read_text())
assert sha((A/'FREEZE_MANIFEST.json').read_bytes())==r['manifest_sha256']
for e in m['files']:
    b=Path(e['path']).read_bytes();assert sha(b)==e['sha256'] and len(b)==e['bytes'],e['path']
l=json.loads((A/'SOURCE_LEDGER.json').read_text())
for e in l['inputs']:
    b=Path(e['path']).read_bytes() if e['kind']=='file' else subprocess.check_output(['git','show',e['revision']+':'+e['path']],cwd=e['repository'])
    assert sha(b)==e['sha256'] and b==Path(e['snapshot']).read_bytes(),e
actual={str(p) for p in A.rglob('*') if p.is_file()}|{str(S/'CENTRE_REGULARITY_TO_GEOMETRIC_PROBE.md')}
listed={e['path'] for e in m['files']};extras=actual-listed
closing={str(A/'logs'/(name+'.'+ext)) for name in ['freeze_candidate','verify_freeze'] for ext in ['stdin','stdout','stderr','receipt.json']}
expected=closing|{str(A/'FREEZE_MANIFEST.json'),str(A/'FREEZE_RECEIPT.json')}
assert extras==expected,extras
ops=json.loads((A/'OPERATIONS.json').read_text())
for e in ops['recorded_executions']:
    for stream in ['stdout','stderr']:
        p=Path(e['receipt_path'].replace('.receipt.json','.'+stream))
        assert sha(p.read_bytes())==e[stream+'_sha256'] and p.stat().st_size==e[stream+'_bytes']
for name in ['freeze_candidate','verify_freeze']:
    e=json.loads((A/'logs'/(name+'.receipt.json')).read_text())
    for stream in ['stdout','stderr']:
        b=(A/'logs'/(name+'.'+stream)).read_bytes()
        assert len(b)==e[stream+'_bytes'] and sha(b)==e[stream+'_sha256']
original=(A/'archive/candidate_before_multiplicity_density_correction.md').read_text()
print('Original density paragraph:',next(x for x in original.splitlines() if x.startswith('Cyclicity')))
coverage=dict(utc=datetime.now(timezone.utc).isoformat(),note_sha256=m['candidate_sha256'],receipt_sha256=sha((A/'FREEZE_RECEIPT.json').read_bytes()),
              files_verified=len(m['files']),source_pairs_verified=len(l['inputs']),execution_streams_verified=len(ops['recorded_executions'])*2+4,
              closing_files_outside_original_manifest=[dict(path=p,sha256=sha(Path(p).read_bytes()),bytes=Path(p).stat().st_size) for p in sorted(extras)],
              read_scope=['Complete 325-line frozen argument G1-G32 and N1-N8 in three bounded reads',
                          'Complete final 157-line helper and all final stdout records',
                          'AUTHOR_CHECK, AUTHOR_CORRECTIONS, final control diff, original density overstatement and corrected paragraph',
                          'Complete compact execution metadata and bootstrap failure; closing freeze outputs and receipts',
                          'Necessary isolated-centre argument/review reused at unchanged source hashes; old Dirac notes are context, not newly recertified'],
              limitations=['Root is coauthor, not independent reviewer','Eight inline defect comparisons are not complete-primary mutation executions',
                           'Initial author bootstrap exact timing/full discovery stdout unavailable and explicitly preserved',
                           'No actual regular-seed density, microscopic representation, applied audit or Lean certificate'],
              root_checker_recovery=dict(failed_inline_assertion="assert extras == {FREEZE_MANIFEST.json, FREEZE_RECEIPT.json}",
                                         failure='The inline checker omitted eight expected post-freeze logging files, after all 157 bindings and 19 source pairs had matched; exit 1, no source writes.',
                                         correction='Exact ten-file closing allowlist; every closing stdout/stderr hash checked; all extra bytes individually hashed here.',
                                         timing='First failure tool elapsed 0.18296425 s; no separate start-time receipt was recorded.',
                                         other='A separate rg against three guessed nonexistent vocab script names exited 2; rg --files found scripts/vocab_lint.py. No source writes.'))
(S/'Centre_regularity_root_author_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
print(json.dumps({k:v for k,v in coverage.items() if k in ['note_sha256','files_verified','source_pairs_verified','execution_streams_verified']},indent=2))
