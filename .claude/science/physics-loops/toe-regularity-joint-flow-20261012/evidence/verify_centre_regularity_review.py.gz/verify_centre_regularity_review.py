from pathlib import Path
import hashlib, json, datetime

S=Path(__file__).resolve().parent
R=S/'centre_regularity_review'
A=S/'centre_regularity_to_geometric'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=json.loads((R/'FINAL_REVIEW_RECEIPT.json').read_text())
assert sha(R/'FINAL_REVIEW_RECEIPT.json')=='0032ce4b7688228cc8200acd2997ac0978474f5ee8c6347636349a215798e6bc'
assert sha(receipt['report_path'])==receipt['report_sha256']
assert sha(receipt['review_output_manifest'])==receipt['review_output_manifest_sha256']
manifest=json.loads(Path(receipt['review_output_manifest']).read_text())
bound=set()
for row in manifest['files']:
    p=Path(row['path'])
    assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
    bound.add(str(p))
extras={str(p) for p in R.rglob('*') if p.is_file()}-bound
assert extras=={str(R/n) for n in manifest['excluded_self_binding_files']},extras
inputs=json.loads((R/'READ_INPUTS_FINAL.json').read_text())
inputs=inputs['initial_inputs']+inputs['after_freeze_inputs']
nonpath_snapshots=[]
for row in inputs:
    assert sha(row['path'])==row['sha256'],row['path']
    if row.get('snapshot'):
        if Path(row['snapshot']).is_absolute():
            assert Path(row['snapshot']).read_bytes()==Path(row['path']).read_bytes(),row
        else:
            nonpath_snapshots.append(row)
for name in ['PREREGISTERED_FREEZE.json','POST_EVIDENCE_CONTROL_FREEZE.json']:
    for row in json.loads((R/name).read_text())['files']:
        assert sha(row['path'])==row['sha256']
for row in json.loads((A/'FREEZE_MANIFEST.json').read_text())['files']:
    assert sha(row['path'])==row['sha256']
original=(A/'analytic_control.py').read_text()
mutations=json.loads((R/'MUTATION_RESULTS.json').read_text())
parse_line=lambda x:json.loads(x) if x.lstrip().startswith('{') else x
baseline=[parse_line(x) for x in (A/'logs/analytic_control_frozen_candidate.stdout').read_text().splitlines()]
control=[]
for row in mutations:
    assert original.count(row['old'])==1
    assert Path(row['source_path']).read_text()==original.replace(row['old'],row['new'])
    assert sha(row['source_path'])==row['source_sha256']
    for kind in ('stdout','stderr'):
        assert sha(R/'mutations'/(row['name']+'.'+kind))==row[kind+'_sha256']
    assert not row['timed_out']
    records=[parse_line(x) for x in (R/'mutations'/(row['name']+'.stdout')).read_text().splitlines()]
    control.append(dict(name=row['name'],exit_code=row['returncode'],elapsed_seconds=row['elapsed_seconds'],changed_records=[x for x in records if x not in baseline],stderr=row['stderr']))
executions=[]
for name in ['independent_controls_initial','author_control_replay','author_mutation_study','tent_integral_control']:
    row=json.loads((R/'logs'/(name+'.receipt.json')).read_text())
    assert row['returncode']==0 and not row['timed_out']
    for kind in ('stdout','stderr'):
        assert sha(R/'logs'/(name+'.'+kind))==row[kind+'_sha256']
    executions.append(dict(name=name,**row))
assert (R/'logs/author_control_replay.stdout').read_bytes()==(A/'logs/analytic_control_frozen_candidate.stdout').read_bytes()
out=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),report_sha256=receipt['report_sha256'],receipt_sha256=sha(R/'FINAL_REVIEW_RECEIPT.json'),bound_output_files=len(bound),input_records_checked=len(inputs),nonpath_snapshot_metadata=nonpath_snapshots,closing_files=[dict(path=p,sha256=sha(p)) for p in sorted(extras)],author_manifest_entries=157,executions=executions,mutations=control,root_reading='Complete final report, all 227 reconstruction lines, all 227 distinct control lines, 47-line post-evidence exact tent integration and 73-line actual mutation driver, full independent outputs, failures and source correction rationale read. Original author proof/helper/outputs and density draft diff read previously at exact unchanged identities. Root is a coauthor, not independent reviewer.',root_failed_second_check=dict(exit_code=1,elapsed_seconds=0.030691583,error='JSONDecodeError: author stdout has five prose inventory lines as well as JSON records',repair='Parse JSON object lines and preserve every other line as text; no scientific source change.'),root_failed_check=dict(stage='Initial inline binding check',elapsed_seconds=0.000010917,exit_code=1,error="FileNotFoundError: snapshot metadata string 'identical installed copy already snapshotted' treated as a filename",repair='Interpret only absolute snapshot values as paths; still hash every actual source and preserve all other snapshot metadata. No source or protected evidence changed.'),limits=['No applied audit or retained status','Two actual source mutations survive author bounds; separate exact Simpson comparison rejects both','No root fresh mathematical rerun was needed'],passed=True)
(S/'Centre_regularity_root_review_coverage.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'outputs':len(bound),'inputs':len(inputs),'nonpath_snapshot_metadata':nonpath_snapshots,'executions':[{k:e[k] for k in ['name','elapsed_seconds','returncode']} for e in executions],'mutations':control},indent=2))
