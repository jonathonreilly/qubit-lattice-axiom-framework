"""Deterministic identity checks; no mathematical verdict or source mutations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

S=Path(__file__).resolve().parent
W=S.parent/'worktree'
SW=S.parent/'scattering_worktree'
sha=lambda b: hashlib.sha256(b).hexdigest()
git=lambda *a: subprocess.check_output(['git',*a],cwd=W)
def check(e,pathkey='path'):
    p=Path(e[pathkey]);b=p.read_bytes()
    assert sha(b)==e['sha256'],str(p)
    if 'bytes' in e: assert len(b)==e['bytes'],str(p)
    return str(p)

A=S/'nonisolated_mass_scattering'
rp=A/'FINAL_RECEIPT.json'
assert sha(rp.read_bytes())=='2a225e88a77732d8ca02db35f8d4c50371b9e57fdfe3d186b5c9210911df64f6'
r=json.loads(rp.read_text())
check(r['note'])
bound={check(e) for e in r['evidence_files']}
actual={str(p) for p in A.rglob('*') if p.is_file()}
expected=bound|{str(A/n) for n in r['self_reference_exclusions']}
assert actual==expected, {'unlisted':sorted(actual-expected),'missing':sorted(expected-actual)}
for e in json.loads((A/'source_manifest.json').read_text())['files']:
    b=git('show',e['revision']+':'+e['path']) if 'revision' in e else Path(e['path']).read_bytes()
    assert sha(b)==e['sha256'] and len(b)==e['bytes'],e
    if 'frozen' in e: assert Path(e['frozen']).read_bytes()==b,e
reading=json.loads((A/'READING_COVERAGE.json').read_text())['sources']
for e in reading:
    for k in ['original_path','frozen_path']:
        assert sha(Path(e[k]).read_bytes())==e['sha256'],e[k]
out=json.loads((A/'author_controls.execution.json').read_text()) if (A/'author_controls.execution.json').exists() else r['executions']['author_controls']
rows=[json.loads(x) for x in (A/'author_controls.stdout').read_text().splitlines()]
assert len(rows)==10 and rows[-1]['records_before_summary']==9
assert not (A/'author_controls.stderr').read_bytes()
coverage=dict(utc=datetime.now(timezone.utc).isoformat(),author_receipt_sha256=sha(rp.read_bytes()),note=r['note'],
             identity_checks=dict(evidence_files=len(bound),source_manifest_entries=20,reading_source_pairs=len(reading),unlisted_files=[]),
             semantic_reading=['Complete 359-line frozen author argument, including N1-N36, read in preceding coherent root session',
                               'Complete 220-line helper; AUTHOR_CHECK.md and OPERATIONS.md read in preceding coherent root session',
                               'All ten original stdout records and complete execution receipts read',
                               'Complete 673-line Dybalski original TeX: see Nonisolated_mass_root_primary_coverage.json',
                               'Prior SC/Fock full arguments reused at unchanged identities; no fresh full BDN-paper certification'],
             exclusions=['Root contributed mechanisms and is not the independent reviewer','Finite controls do not prove LR, analytic tail estimates or physical realization'],
             execution=r['executions']['author_controls'])
(S/'Nonisolated_mass_root_author_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')

previous=json.loads((S/'repo_sync_0305.json').read_text())
prs=json.loads((S/'repo_sync_0330_open_prs.json').read_text())
refs={k:git('rev-parse',k).decode().strip() for k in previous['refs']}
instructions={p:sha(git('show','origin/main:'+p)) for p in previous['instructions']}
oldprs={e['number']:e for e in previous['open_prs']}
changes=[]
for e in prs:
    old=oldprs.get(e['number'])
    if old and old['headRefOid']==e['headRefOid']:continue
    paths=git('diff','--name-status',old['headRefOid'],e['headRefOid']).decode().splitlines() if old else []
    item=dict(number=e['number'],old=old['headRefOid'] if old else None,new=e['headRefOid'],changed_paths=paths)
    changes.append(item)
    (S/f"sync_0330_pr{e['number']}_changed_paths.txt").write_text('\n'.join(paths)+'\n')
sync=dict(utc=datetime.now(timezone.utc).isoformat(),fetch=dict(exit_code=0,stdout_bytes=0,stderr_bytes=0),refs=refs,instructions=instructions,
          open_prs=prs,changed_prs=changes,pr9486=next(e for e in prs if e['number']==9486),
          worktree_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SW,text=True).strip(),
          worktree_status=subprocess.check_output(['git','status','--porcelain'],cwd=SW,text=True),
          lock_refreshed_utc='2026-10-12T03:29:40.684447+00:00',lock_expires_utc='2026-10-12T04:29:40.684447+00:00')
(S/'repo_sync_0330.json').write_text(json.dumps(sync,indent=2)+'\n')
print(json.dumps(dict(mass_identity_checks=coverage['identity_checks'],refs=refs,instructions_changed=instructions!=previous['instructions'],
                     changed_prs=[dict(number=e['number'],old=e['old'],new=e['new'],paths=len(e['changed_paths'])) for e in changes],
                     active_pr=sync['pr9486'],worktree_clean=not sync['worktree_status']),indent=2))
