from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import json
import time

S = Path(__file__).resolve().parent
START = time.monotonic()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def bind(row, base=S):
    p = Path(row['path'])
    if not p.is_absolute(): p = base / p
    assert sha(p) == row['sha256'], p
    assert p.stat().st_size == row['bytes'], p
    return dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)

def save(name, data):
    data['recorded_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    data['elapsed_seconds'] = time.monotonic() - START
    (S/name).write_text(json.dumps(data, indent=2)+'\n')

M = S/'nonisolated_mass_review'
receipt = json.loads((M/'FINAL_RECEIPT.json').read_text())
assert sha(M/'FINAL_RECEIPT.json') == '9f2a7ef9c691f0edfbcc257340444b4923dcb48e771fa5e41a9d4f19f5573da4'
outputs = [bind(r) for r in receipt['outputs']]
sources = [bind(r) for r in json.loads((M/'FINAL_SOURCE_MANIFEST.json').read_text())['sources']]
inventory = {str(p.resolve()) for p in M.rglob('*') if p.is_file()}
bound = {r['path'] for r in outputs}
extras = sorted(inventory-bound)
assert set(extras) == {str(M/p) for p in receipt['self_reference_exclusions']}, extras
streams = []
for label, ex in receipt['executions'].items():
    assert ex['declared_timeout_seconds'] == 60 and not ex['timed_out']
    for kind in ('stdout','stderr'):
        p=M/'logs'/f'{label}.{kind}'
        assert sha(p)==ex[kind+'_sha256'] and p.stat().st_size==ex[kind+'_bytes']
        streams.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size))
original = (M/'sources/author_packet/check_nonisolated_controls.py').read_text()
tree=ast.parse((M/'controls/run_author_mutations.py').read_text())
cases=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets))
mutations=[]
for name,replacements,expected,scope in cases:
    changed=original
    for before,after in replacements:
        assert changed.count(before)==1
        changed=changed.replace(before,after)
    prefix=M/'controls/author_mutations'/name
    p=prefix.with_suffix('.py')
    assert p.read_text()==changed
    diff=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='check_nonisolated_controls.py',tofile=p.name))
    assert prefix.with_suffix('.diff').read_text()==diff
    ex=json.loads(prefix.with_suffix('.execution.json').read_text())
    assert ex['source_sha256']==sha(p) and ex['returncode']==expected and not ex['timed_out']
    for kind in ('stdout','stderr'):
        q=prefix.with_suffix('.'+kind)
        assert sha(q)==ex[kind+'_sha256'] and q.stat().st_size==ex[kind+'_bytes']
    lines=prefix.with_suffix('.stdout').read_text().splitlines()
    records=[json.loads(x) for x in lines]
    mutations.append(dict(name=name,expected_exit=expected,scope=scope,source_sha256=sha(p),complete_records=records,stderr=prefix.with_suffix('.stderr').read_text(),elapsed_seconds=ex['elapsed_seconds']))
assert (M/'logs/author_controls_reproduction.stdout').read_bytes()==(S/'nonisolated_mass_scattering/author_controls.stdout').read_bytes()
v1=(M/'controls/continuum_time_width_control.py').read_text()
v2=(M/'controls/continuum_time_width_control_v2.py').read_text()
assert v1.count('epsabs=2e-12, epsrel=2e-11')==1
assert v1.replace('epsabs=2e-12, epsrel=2e-11','epsabs=2e-20, epsrel=2e-12')==v2
repair=json.loads((M/'N36_PUBLICATION_REPAIR.json').read_text())
note=(S/'NONISOLATED_MASS_SCATTERING_PROBE.md').read_text()
assert hashlib.sha256(note.encode()).hexdigest()==repair['frozen_note_sha256']
assert note.count(repair['before'])==1
repaired=note.replace(repair['before'],repair['after'])
assert hashlib.sha256(repaired.encode()).hexdigest()==repair['prospective_note_sha256']
assert repaired==(M/'controls/N36_REPAIRED_NOTE_FOR_VERIFICATION.md').read_text()
save('Nonisolated_mass_root_review_coverage.json',dict(report=bind(receipt['report']),receipt_sha256=sha(M/'FINAL_RECEIPT.json'),outputs=outputs,sources=sources,closing_files=[dict(path=p,sha256=sha(Path(p))) for p in extras],streams=streams,mutations=mutations,repair=repair,root_reading='Full 70-line report, 337-line reconstruction, post-author findings, control/operational/stress-test prose, complete v2 and its sole v1 difference, general-beta helper, all 48 exact general-beta rows, mutation driver, every mutant complete output/trace and original/final independent outputs read; all mathematical source bytes and exact correction bound. Root is a coauthor, not an independent reviewer.',limits=['No applied audit or retained status','No new mathematical rerun by root: independent execution evidence verified','Primary Dybalski full source reading recorded separately; no fresh full BDN reread claimed'],passed=True))
print(json.dumps({'mass_review_outputs':len(outputs),'source_bindings':len(sources),'closing_exclusions':len(extras),'mutations':len(mutations),'rejected':sum(x['expected_exit']==1 for x in mutations),'survivors':[x['name'] for x in mutations if x['expected_exit']==0]}))

J=S/'microscopic_joint_flow'
jr=json.loads((J/'receipt.json').read_text())
assert sha(J/'receipt.json')=='afdfaff1e0a1c4a6843cbfd0d49c449d37bed0d62052b967c92ac9c38582984c'
jfiles=[bind(r) for r in jr['files']]
assert {str(p) for p in J.rglob('*') if p.is_file()}-{r['path'] for r in jfiles}=={str(J/'receipt.json')}
inputs=[]
for r in jr['source_inputs']:
    p=Path(r['source']);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
    if 'copy' in r: assert (J/r['copy']).read_bytes()==p.read_bytes()
    inputs.append(r)
upstream=[]
for name in ['microscopic_current_implementation/receipt.json','microscopic_current_review/receipt.json']:
    upstream += [bind(r) for r in json.loads((S/name).read_text())['files']]
summary=json.loads((J/'mutations/summary.json').read_text())
base=(J/'controls/joint_controls.py').read_text()
jcontrols=[]
baseline=json.loads((J/'logs/controls.run1.results.json').read_text())
for ex in summary['defects']:
    name=ex['name'];folder=J/'mutations'/name;before=ex['replacement']['before'];after=ex['replacement']['after']
    assert base.count(before)==1 and (folder/'joint_controls.py').read_text()==base.replace(before,after)
    result=json.loads((folder/'joint_controls_results.json').read_text())
    stdout=[json.loads(x) for x in (folder/'stdout.jsonl').read_text().splitlines()]
    assert stdout[:-1]==result['rows'] and stdout[-1]=={k:result[k] for k in ['total','failed','source_sha256']}
    assert len(result['rows'])==result['total']==37
    assert sum(not r['passed'] for r in result['rows'])==result['failed']>0
    assert sha(folder/'joint_controls.py')==result['source_sha256']==ex['mutant_sha256']
    assert ex['status']=='completed' and ex['exit_code']==1 and not (folder/'stderr.txt').read_bytes()
    jcontrols.append(dict(name=name,failed=result['failed'],changed_rows=[dict(baseline=a,mutant=b) for a,b in zip(baseline['rows'],result['rows']) if a!=b],elapsed_seconds=ex['elapsed_seconds']))
out=[json.loads(x) for x in (J/'logs/controls.run1.stdout.jsonl').read_text().splitlines()]
assert out[:-1]==baseline['rows'] and out[-1]=={k:baseline[k] for k in ['total','failed','source_sha256']}
assert baseline['failed']==0 and len(baseline['rows'])==37
assert sha(J/'logs/controls.run1.py')==baseline['source_sha256']==sha(J/'controls/joint_controls.py')
save('Joint_flow_root_author_coverage.json',dict(receipt_sha256=sha(J/'receipt.json'),files=jfiles,inputs=inputs,upstream_receipt_entries=upstream,mutation_checks=jcontrols,root_reading='Complete 279-line proof, all 273 helper lines, all 37 baseline records and all changed/failing source-mutant rows read before this binding check; full control assessment, operations, packet checker and mutation driver read. Root coauthored route and is not independent.',passed=True))
print(json.dumps({'joint_files':len(jfiles),'inputs':len(inputs),'upstream_entries':len(upstream),'controls':[{'name':r['name'],'failed':r['failed']} for r in jcontrols]}))
