# Probability flux and normalized beams for the supplied excluded walk

External author derivation, 2026-10-11. Proposed mathematical results for the
supplied three-dimensional two-record unitary, with the singlet contact removed
in its antisymmetric sector. This is not an independent review, an audit
verdict, a new physical law, a many-body closure, or a collision-clock supplier.
Lengths and times below are the supplied lattice and generator units.

The strongest result is a stationary probability-flux cross section with an
explicit incident normalization. For the antisymmetric paired incident state
defined below, at K=0,

    sigma_pair(E,q_in)=2pi rho(0,E)/[v_in |G(0,E+i0)|^2],
    lim_(E->0+) sigma_pair=1/(4pi I0^2)>0,
    I0=integral_(T^3) dq/[(2pi)^3 4|sin q|^2].                (F1)

All eight outgoing corners are included. A weak angular lattice-flux measure
is proved below, including its exact normalization and the parity interference
that prevents a pointwise incoherent sum. Thus the small eigenphase of S does
not, by itself, mean a small cross section in lattice-area units.

A separate exactly normalized finite-beam construction gives an outgoing
probability into the other seven corners of

    P_other=(7/64)|s-1|^2                                  (F2)

on a fixed regular shell. Energy and K envelopes make it a normalizable
two-record state. Under the named scaled Cook regularity input, it also gives
an actual finite-time excluded-unitary experiment with P_other of order
lambda^2 and a positive explicit leading coefficient. This probability is
not (and need not equal) the squared norm of the full scattered difference.

## 1. Exact sources, reading and dependency limits

External source directory:
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Frozen input | SHA-256 | Actual role |
| --- | --- | --- |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526` | Model, central channel map, stationary S convention. Its general scaled G coefficient and order-seven derivatives are inputs only to the explicitly marked central-scaling and finite-time extensions. |
| `EXCLUDED_WALK_COOK_BRIDGE_DRAFT.md` | `2c54b891deeb43a19c5f41de5059aadac7fc8d672dfb68e0b8aa575d27eb3fc7` | C1-C7 and direct-integral preparation/tails for the optional finite-time beam. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Identifies the distinct energy-current observable. Its canonical correction is not used as a probability current. |
| `EXCLUDED_WALK_COHERENT_PACKET_DRAFT.md` | `b4ae921cc065fb2f38c1caee5aca3a1cf69bac317a6f6f0f537becd393b6cd38` | Reused direct-integral normalization and Cook scaling convention. The coherent-current coefficient is not a premise of this flux derivation. |

These sources were read in full in the preceding work. Their reuse is author
composition, not independent evidence for the author's threshold proof. The
K=0 resolvent, low-energy G limit, local probability current, parity structure,
flux normalization and paired incident normalization are derived explicitly
here, without the high-order threshold derivative input.

The matched repository source is M6 at frozen main
`a13caa4885f547c8d206265b031ba7649e539fd9`:
`docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md`,
SHA `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`.
Its complete 226 lines were reread from `git show`; an exact copy is
`flux_bridge/M6_frozen.md`. T2 contains the rank-one resolvent and a formally
normalized shell transition expression. Its Premises explicitly supplies a
Fermi-golden-rule transition rate at definition level. It does not prove the
incident-flux, spatial far-field or plane-versus-normalized-beam bridge here.
The common conditional outgoing shell weight is prior art, not new in this
note. M3/M9 and their exact paths/hashes retain the earlier complete coverage
record in `excluded_walk_probe/identity_manifest.json`; their no-current
conservation conclusions do not supply this flux normalization.

Three broader frozen-main regex searches and their full raw hits are saved in
`flux_bridge/repo_search_0.log` through `repo_search_2.log`, with commands and
counts in `repo_search_manifest.json`. They returned 146, 231 and 551 hits.
This was a targeted matched-source review, not a read of every unrelated hit:
ice transfer cross sections, thermal Sommerfeld imports, classical capturing
bodies, raw historical prompts and unrelated matrix references are context-only.
No global novelty claim follows from those searches. No new open-PR inventory
or repository status audit was performed for this bounded derivation.

The new primary mathematical source is W. Shaban and B. Vainberg,
[*Radiation Conditions for the Difference Schrödinger Operators*](https://arxiv.org/pdf/1812.06390).
The Fourier convention/setup, Theorem 1, Lemma 2, Theorem 4, its amplitude
formula (13), and the asymptotic argument through (21) were read; formula (13)
was also checked on rendered PDF page 8. The import is the regular strictly
convex scalar lattice resolvent expansion. At K=0 the exact scalar reduction
below has paper energy 6-E^2 in (2,6), finite-support source, nonzero group
velocity and positive curvature. The central matrix extension below repeats
its coarea/stationary-phase argument with those hypotheses checked, rather
than applying a scalar theorem to a matrix without justification.
Local PDF SHA: `95cd35e4045482e4c7885e598be980cd2e75d426cdbe0d1880fa5bcd02103ffa`.
The paper's remaining nonconvex, uniqueness and perturbed-operator arguments
were not needed or claimed as fully read. No continuum Dirac
flux-across-surfaces theorem is imported for this lattice.

## 2. Hilbert-space and incident-normalization conventions

Use the ordered-coordinate embedding with relative coordinate x=x1-x2 in
Z^3 and normalized Fourier measure dq/(2pi)^3. A local total-momentum chart
has k1=K/2+q, k2=K/2-q. Its Jacobian is one; no half-volume factor enters.
In that embedding the physical antisymmetric fiber consists of spinor fields

    psi(-x)=-Swap psi(x),   ||psi||^2=sum_x ||psi(x)||^2.       (F3)

For x!=0, passing to one representative of each orbit {x,-x} multiplies its
amplitude by sqrt(2), so the norm on unordered configurations is the same.
In particular a full oriented angular flux integral is not divided by two
again. A detector on the unoriented axis identifies n and -n and adds their
two equal densities on a representative hemisphere.

Let c be the normalized singlet, both as a spin vector and as the contact
vector delta_(x,0)c. The generator and compression are

    H0(K,q)=sigma_1 dot sin(K/2+q)+sigma_2 dot sin(K/2-q),
    C=|c><c|, P=I-C, H=PH0P.                              (F4)

The restriction of H to P is the physical excluded unitary. On the full fiber
it also has a decoupled zero vector c, which is not an incident state. Write
R0(z)=(H0-z)^(-1), G(z)=<c,R0(z)c>, rho=Im G(E+i0)/pi.

The quantity called probability current below is the continuity current of
the squared norm of this supplied unitary. It is a different observable from
the canonical energy current. At K=0 the latter vanishes, whereas outgoing
relative-coordinate probability flux need not vanish. No framework-level
measurement or record-selection law is inferred from this Hilbert-space use.

## 3. A local source identity fixes the total outgoing flux

For a nearest-neighbor Bloch generator write

    (H0 psi)(x)=sum_a [T_a psi(x+e_a)+T_a^* psi(x-e_a)],
    T_a=(sin(K_a/2)/2)(sigma_(1,a)+sigma_(2,a))
                   -(i cos(K_a/2)/2)(sigma_(1,a)-sigma_(2,a)).

Its oriented outward bond current is

    j_a(x;psi)=-2 Im[psi(x)^* T_a psi(x+e_a)].             (F5)

Direct differentiation of ||psi(x)||^2 under i dot psi=H0 psi gives
dot rho_x=-sum_a[j_a(x)-j_a(x-e_a)]. For a stationary inhomogeneous field
(H0-E)psi=f the same algebra gives

    div j(x)=-2 Im[psi(x)^* f(x)].                        (F6)

This identity is local and requires no asymptotic scattering assumption.
For the outgoing boundary field R_E(x)=(R0(E+i0)c)(x), it implies

    div j(x;R_E)=2 Im G(E+i0) delta_(x,0),
    total outward flux through every finite enclosing boundary
                           =2 Im G=2pi rho.             (F7)

Boundary currents are summed with their oriented signs. Pointwise boundary
values and the homogeneous equation away from zero follow either from the
K=0 scalar reduction below or from smooth regular-shell coarea subtraction.
There is no infinity-limit exchange in (F7): any enclosing finite region
satisfies it after taking the pointwise resolvent boundary value.

At z=E+i eta the exact precursor is
div j=2 Im G(z) delta_0-2 eta ||R0(z)c(x)||^2. This also fixes the sign of
(F7) and is tested exactly on a finite periodic lattice in the helper.

If psi_in is any generalized free solution at E with contact amplitude
a=<c,psi_in>, the hard-core stationary field is

    psi=psi_in+psi_sc,
    psi_sc=-R_E a/G,
    <c,psi>=0,   P(H0-E)P psi=0.                         (F8)

Thus its scattered field alone has total outward flux

    Flux_sc=2pi rho |a|^2/|G|^2.                         (F9)

This is obtained from an actual stationary field and continuity, not by
calling an S-matrix element a collision rate. The full field has zero net
flux through an enclosing surface: its contact source is orthogonal to its
contact-free value. The interference between incident and scattered fields
therefore cancels (F9), as required by conservation. Ignoring that interference
and treating the full squared scattered difference as a probability would
be incorrect.

## 4. K=0: exact scalar reduction and eight-corner parity

At K=0, let t_a=sigma_(1,a)c. The four vectors c,t1,t2,t3 are orthonormal.
The matrices A_a=sigma_(1,a)-sigma_(2,a) obey

    A_a c=2t_a,   A_a t_b=2 delta_ab c.

Consequently H0^2 c=4|sin q|^2 c, and exactly

    R0(z)c(q)=[z+2 sigma_1 dot sin q]c/[4|sin q|^2-z^2].  (F10)

The mixed zero-energy spin directions carry no contact weight at K=0.
They are not omitted positive-energy channels.

Put

    L_z(x)=integral e^(iq.x)/[4|sin q|^2-z^2] dq/(2pi)^3.

The denominator is pi-periodic in each q coordinate. Hence L_z(x)=0 unless
all x_a are even, and

    L_z(2m)=integral e^(ip.m)/[6-2 sum_a cos p_a-z^2] dp/(2pi)^3,
    R0(z)c(x)=z L_z(x)c
                 -i sum_a [L_z(x+e_a)-L_z(x-e_a)]t_a.     (F11)

The first expression is the standard nearest-neighbor scalar lattice
resolvent at z^2, with the supplied spacing change explicit. It also proves
the exact parity selection: all-even x carry only c; exactly-one-odd x
carry only the corresponding t_a; two or three odd coordinates give zero.
This holds before taking any low-energy or large-distance limit.

For 0<E<=1/8, each of the eight open ++ shells is C0+Sigma_E, where C0 is a
corner in {0,pi}^3 and

    Sigma_E={p near 0: 4 sum_a sin^2 p_a=E^2}.

The Hessian of its defining function is 8 diag(cos 2p_a)>0 on the entire
small enclosed region. Thus it is strictly convex with a smooth Gauss map.
Let p_E(n) be its unique point whose outward group velocity points along
n, let v_E(n)=|grad(2|sin p|)| there, and let k_E(n)>0 be its Gaussian
curvature in physical relative q coordinates. Finally set
s_hat_E=sin p_E/|sin p_E|.

The outgoing far field, with r=|x| and n=x/r, is

    R_E(x)=sum_C0 e^(i(C0+p_E(n)).x)
           (1+sigma_1 dot D_C0 s_hat_E)c
                         /[4pi r v_E(n) sqrt(k_E(n))]+O_E(r^-2), (F12)

where D_C0=diag(cos C0_a). Equivalently its leading term is

    2 e^(ip_E(n).x)/[pi r v_E sqrt(k_E)]
          [1_(x even)c+sum_a 1_(parity(x)=e_a) s_hat_(E,a)t_a].

The second expression agrees with the exact parity rule. It is not the
pointwise sum of eight intensities.

Since p_E=(E/2)n+O(E^3), v_E=2+O(E^2), k_E=4/E^2+O(1), each individual
cone has leading low-energy amplitude

    E(1+sigma_1 dot D_C0 n)c/[16pi r].                   (F13)

This verifies the proposed coefficient and spin factor. Its exact phase is
e^(ip_E(n).x). Replacing that phase by e^(iEr/2) requires controlling
E^3 r; it is not a uniform fixed-E far-field formula as r tends to infinity.
No jointly uniform r,E remainder is asserted here.

## 5. Stationary-phase normalization and the compact central extension

The coefficient in (F12) can be reconstructed from the Fourier integral.
Near a simple positive shell, retain its matrix spectral projector Pi(q).
Coarea writes the singular part using Pi(q)c/|grad E(q)|. The boundary
identity (t-i0)^(-1)=PV(1/t)+i pi delta(t), followed by stationary phase
on a smooth strictly convex surface, selects the outgoing critical point.
The two-dimensional surface Hessian is negative definite there. Its factor
(2pi/r)e^(-i pi/2)/sqrt(k) and the outgoing normal integral 2pi i, divided
by (2pi)^3, give precisely

    e^(iq(n).x) Pi(q(n))c/[2pi r v(n) sqrt(k(n))].          (F14)

The opposite normal stationary point cancels between PV and delta terms.
Away from the shell the matrix inverse is smooth and repeated integration
by parts gives rapid decay. This is the coarea/PV argument of the primary
source with our Fourier convention and outgoing sign restored explicitly.
At K=0, Pi_(++)c=(1+sigma_1 dot D_C0 s_hat_E)c/2, giving (F12).

The same argument is available on any compact scaled central domain
K=lambda kappa,E=lambda e with e>=e_min>0 and |kappa|<=e/4. For sufficiently
small lambda only ++ is open. In one corner write q=C0+lambda y. The
scaled energy tends in C^m, for every fixed m, to

    e_0(y)=|y+kappa/2|+|y-kappa/2|.

On its level e, both one-particle lengths are at least (e-|kappa|)/2>0.
Its surface is the ellipsoid

    y^T B^(-1)y=1, B=[D I+kappa kappa^T]/4,
    D=e^2-|kappa|^2>0.                                  (F15)

It has uniformly positive curvature on the compact parameter set. The
lattice shell is a small C^2 perturbation there and hence remains strictly
convex, with a uniformly nonsingular Gauss map in scaled coordinates. This
checks the needed geometry; no global convexity at arbitrary energy is used.

All eight lattice shells are identical translates: changing C0 applies
the same coordinate signs to both sine vectors. Their energy, group velocity,
curvature and singlet weight are identical. Their spin projectors need not
be replaced by one projector. With q(n)=C0+p_(K,E)(n), define

    w(n)=||Pi_C0(n)c||^2
       =[1-n1(n) dot n2(n)]/4,
    n1=sin(K/2+p)/|sin(K/2+p)|,
    n2=sin(K/2-p)/|sin(K/2-p)|.

Then the full outgoing field is

    R_E(x)=e^(ip_(K,E)(n).x)/[2pi r v(n) sqrt(k(n))]
                       sum_C0 e^(iC0.x) Pi_C0(n)c+O_(K,E)(r^-2). (F16)

At fixed small (K,E), all remainders and their one-lattice-step versions
are uniform in n. This suffices for the flux limit. Uniformity when r and
lambda tend to their limits together is not used or claimed.

## 6. A defined angular lattice-flux measure, including interference

Choose a smooth radial cutoff chi with chi=1 for radius<=1 and chi=0 for
radius>=2. For a smooth real angular test function a(n), define

    Flux_R[a;psi]=sum_(x,b) a(x/|x|)
         [chi(|x|/R)-chi(|x+e_b|/R)] j_b(x;psi).          (F17)

The angular value at x=0 is irrelevant because the bracket is zero there.
This is a smoothed outward bond-flux functional on an annulus, not a count
of hypothetical collisions. For a=1, summation by parts and (F7) give
Flux_R[1;R_E]=2pi rho for every sufficiently large R.

For general a insert (F16). The phase of a neighbor obeys
p(n').(x+e_b)=p(n).x+p_b(n)+O_(K,E)(r^-1), because derivatives of p along
the shell are orthogonal to n. In the leading current, products of corners
C0 and C1 carry exp(i(C1-C0).x). Averaging over a 2-by-2-by-2 parity cell
annihilates every cross term with C0!=C1. The slowly varying coefficients
produce only O_(K,E)(R^-1) error in (F17). This is a Riemann-sum statement
with eight parity cosets, not an assumption of incoherent preparation.

For a diagonal term, the band Hellmann-Feynman identity gives

    (Pi_C0 c)^* partial_(q_b)H0 (Pi_C0 c)=v_b ||Pi_C0 c||^2.

It follows that the limiting angular outward flux density of R_E is

    lim_(R->infinity) Flux_R[a;R_E]
       =integral_(S^2) a(n) F_(K,E)(n) dOmega,
    F_(K,E)(n)=2w(n)/[pi^2 v(n) k(n)].                   (F18)

The local bond-current remainder is O_(K,E)(r^-3); multiplying the cutoff
difference O(R^-1) and summing O(R^3) annular sites proves its O(R^-1)
contribution. Standard Riemann sums on each parity sublattice then prove
the limit. In particular (F18) is positive for a>=0.

The total normalization checks independently through the Gauss map:
dOmega=k dSigma on one corner shell, and

    rho=8/(2pi)^3 integral_(one shell) w dSigma/v,
    integral F_(K,E) dOmega=2pi rho.                     (F19)

At K=0, w=1/2 and F=1/(pi^2 v_E k_E). One can also compute the averaged
current directly from (F12): only the all-even and the corresponding
one-odd site contribute to each bond direction. The parity average of
their singlet-triplet currents is n/[pi^2 r^2 v_E k_E]. This reproduces
(F18) while preserving exact zeros on the other site classes.

## 7. Paired incident flux and a stationary cross section

Fix a regular incoming ++ momentum q_in=C_in+p_in. Let u be a unit spin
vector in its one-dimensional band, with c^*u=sqrt(w_in) by phase choice.
The antisymmetric generalized incident field is

    psi_in(x)=[e^(iq_in.x)u-e^(-iq_in.x)Swap u]/sqrt(2).   (F20)

It has mean squared norm per relative lattice site equal to one, since the
cross term averages to zero on large boxes for q_in away from a corner.
At K=0 its two spin components are orthogonal and its density is identically
one. Because Swap c=-c,

    a=<c,psi_in>=sqrt(2w_in).                            (F21)

The two ordered travelling components have densities 1/2 and opposite
group velocities of magnitude v_in. Define the paired incident flux density
as the sum of their incoming flux magnitudes through their respective
transverse planes: j_in=v_in/2+v_in/2=v_in. Equivalently, on the unordered
configuration space this counts one incoming pair flux, using (F3).
The net vector current of the two opposed components is not that incident
flux; using the net zero vector as a denominator would be meaningless.

Define the stationary paired-beam cross section to be the outward flux of
the scattered field alone divided by this j_in. Equations (F9),(F18),(F21)
then prove

    d sigma_pair/dOmega
       =4 w_in w(n)/[pi^2 v_in v(n) k(n) |G|^2],
    sigma_pair=4pi rho w_in/[v_in |G|^2].                 (F22)

This is an explicitly defined relative-coordinate probability-flux cross
section, with area in the supplied lattice units. It includes every outgoing
corner through the coarse angular flux. Resolving individual outgoing corners
in Fourier space assigns one eighth of that flux to each corner, with its
own projector. No spatial pointwise corner incoherence is assumed.

A single unit-density ordered travelling component would have contact
intensity w_in and the same speed, producing half of (F22) in the formal
rank-one comparison. That component is not itself an antisymmetric state.
Nor does this comparison assert a distinguishable-particle hard-core theorem:
removing all distinguishable contact spin states would be a different model.

The wave (F20) is generalized and is not a normalized angular delta state.
It is used solely to define an incident flux density. The normalizable beam
result in Section 10 supplies a different, explicitly probability-normalized
experiment; this note does not assert an unproved plane-beam limiting theorem
equating the two experiments.

## 8. The K=0 low-energy limit is self-contained

Equation (F10) gives G(0,z)=z J(z), with
J(z)=integral [4|sin q|^2-z^2]^(-1)dq/(2pi)^3. The finite positive number
I0=J(0) is integrable because its eight singularities are inverse squares
in three dimensions. Here is a direct boundary-value estimate:

    J(E+i0)=I0+O(E),
    G(0,E+i0)=E I0+O(E^2).                              (F23)

Near each corner use p=sin q and its smooth Jacobian. Outside |p|<=2E,
the difference of denominators is bounded by a constant times E^2/|p|^4;
its three-dimensional integral is O(E). Inside |p|<=2E, rescale p=E y.
Both the zero-energy integral and the boundary-value integral have overall
factor E. The latter has a fixed simple radial pole at |y|=1/2; subtracting
the smooth radial numerator at that pole bounds its principal value, and
the delta term is also uniformly bounded. Smooth cutoffs can be inserted
between the two regions. The remainder outside fixed corner charts is
O(E^2). This proves (F23) without a numerical principal-value extrapolation.

The same change of variables gives exactly, for 0<E<2,

    rho(0,E)=E^2/(16pi^3) integral_(S^2)
                 product_a(1-E^2 n_a^2/4)^(-1/2) dOmega
             =E^2/(4pi^2)+O(E^4).                       (F24)

At K=0 the incoming w_in=1/2, v_in=2+O(E^2), uniformly in direction and
corner. Equations (F22)-(F24) prove (F1), and also

    d sigma_pair/dOmega=1/(16pi^2 I0^2)+O(E),
    sigma_pair=1/(4pi I0^2)+O(E),
    s-1=-i E/(2pi I0)+O(E^2).                           (F25)

Thus the cross section has a finite nonzero threshold limit while the
scattering eigenphase tends to zero. These are different normalizations.
The eight-cone and antisymmetric factors are already included. There is
no additional multiplication by eight or division by two.

For explicit rough bounds, I0>=1/12 since 4|sin q|^2<=12. Folding to the
cube [-pi/2,pi/2]^3, using |sin x|>=2|x|/pi, and enclosing that cube in a
ball gives I0<=sqrt(3)pi/8. Hence the positive limit in (F1) lies between
16/(3pi^3) and 36/pi. No fitted numerical value of I0 is needed.

## 9. Central scaled cross sections and their inherited input

This section additionally uses the frozen threshold coefficient

    G(lambda kappa,lambda e+i0)=lambda A(kappa,e)+O(lambda^2),
    rho=lambda^2 D/(4pi^2)+O(lambda^4),
    A=e integral [(e^2-|kappa odot cos q|^2)
           / (4|sin q|^2(e^2-(kappa dot v0(q))^2))] dq/(2pi)^3,
    v0_a(q)=sin q_a cos q_a/|sin q|.                     (F26)

Its positivity and uniform remainder are named inputs from that source,
not independently certified by this flux derivation. For K=0 they reduce
to the independently calculated (F23)-(F24).

The limiting outgoing geometry can be computed directly from (F15). Put
gamma(n)=D+(kappa dot n)^2. The point with outward normal n and its speed,
contact weight and scaled Gaussian curvature are

    y(n)=[D n+(kappa dot n)kappa]/[2sqrt(gamma)],
    v_lim(n)=2sqrt(gamma)/e,
    w_lim(n)=gamma/(2e^2),
    k_lim(n)=4 gamma^2/(D^2 e^2).                        (F27)

For the curvature, the implicit ellipsoid formula gives k=(n^T B n)^2/det B;
det B=D^2 e^2/64. The two one-particle lengths have product e^2 D/(4gamma),
which proves the displayed contact weight and speed. The actual lattice
quantities differ by O(lambda^2) after this scaling; its curvature is
lambda^-2[k_lim+O(lambda^2)]. Consequently

    F_(lambda kappa,lambda e)(n)
       =lambda^2 D^2 e/[8pi^2 gamma(n)^(3/2)]+O(lambda^4),
    d sigma_pair/dOmega
       =D^2 sqrt(gamma(n_in))
                    /[16pi^2 A^2 gamma(n)^(3/2)]+O(lambda),
    sigma_pair=D sqrt(gamma(n_in))/[4pi e A^2]+O(lambda).   (F28)

Here n_in is the incoming relative group-velocity direction, not necessarily
the radial momentum direction. The elementary identity
integral_(S^2) gamma^(-3/2)dOmega=4pi/(D e) checks both total normalizations.
All statements are uniform on the selected compact central parameter set,
including incoming and outgoing directions, once lambda is sufficiently
small. The angular flux uses the large-radius limit first. No joint
far-field/threshold error estimate is hidden in (F28).

## 10. A normalized finite-beam analogue with actual probabilities

On a regular shell let v=Zc/sqrt(rho), so S=I+(s-1)|v><v|. Let Q_j select
one of the eight corner components. Exchange maps q to -q within the same
corner, so Q_j preserves the antisymmetric shell space. The eight contact
masses are exactly equal, giving

    ||Q_j v||^2=1/8,
    chi_j=sqrt(8) Q_j v, ||chi_j||=1,
    v=(1/sqrt(8))sum_j chi_j.                            (F29)

These are unit angular states distributed across a whole corner shell, not
directional delta states. The exact outgoing shell state is

    S chi_j=[(7+s)/8]chi_j+sum_(k!=j)[(s-1)/8]chi_k.       (F30)

Thus each other corner has probability |s-1|^2/64, their total is (F2),
and the same-corner probability is 1-7|s-1|^2/64. Their sum is exactly one.

More generally, a normalized angular beam chi with support A and an angular
detector B disjoint from A satisfies

    ||Q_B S chi||^2=|s-1|^2 |<v,chi>|^2 ||Q_B v||^2.       (F31)

All sets must be exchange invariant, or the corresponding detector must be
defined on unordered channels. If chi=Q_A v/sqrt(nu(A)), the probability in
a disjoint set B is |s-1|^2 nu(A)nu(B), and in A's complement it is
|s-1|^2 nu(A)[1-nu(A)]. Smooth angular windows give the
same formula with their actual normalization and contact overlap. A shrinking
angular cap has shrinking contact overlap; it does not become a unit delta
direction. Inside A, interference with the incident amplitude must be kept.
The pure contact vector v has S v=s v and exactly zero angular-probability
redistribution, despite ||(S-I)v||^2=|s-1|^2.

For a fully normalizable packet choose smooth compact alpha(kappa),f(e) in
the same strict central domain, normalized by
integral |alpha|^2 d^3kappa/(2pi)^3=integral |f|^2de=1, and set

    Psi_lambda(K,E)=lambda^-2 alpha(K/lambda) f(E/lambda) chi_j(K,E). (F32)

Its squared amplitude lambda^-4 exactly cancels the measure factors
lambda^3 and lambda. It is smooth for each positive lambda after inverse
coarea restriction; its bump support stays inside the regular corner charts.
The outgoing other-corner probability is exactly the weighted integral of
(F2). Under (F26) it becomes

    P_other^asym=lambda^2 C_beam+O(lambda^3),
    C_beam=(7pi^2/16) integral |alpha|^2|f|^2
                    [D/(4pi^2)]^2/A^2 d^3kappa/(2pi)^3 de>0. (F33)

This is a norm-squared transition probability for one prepared packet.
Its O(lambda^2) behavior differs from the O(1) flux cross section of the
generalized incident field. Neither supplies an event frequency or gas
collision rate, and no fixed beam-area identification equating them is assumed.

There is also an optional finite-time realization, using the frozen Cook
source and the threshold source's uniform scaled derivatives through order
seven. The contact profiles of (F32) and its outgoing packet are

    b_c^in(K,E)=lambda^-1 alpha(kappa) B^in(lambda,kappa,e),
    B^in=f sqrt(r_lambda)/sqrt(8), B^out=s B^in,
    b_h^b=E b_c^b, r_lambda=rho/lambda^2.                 (F34)

Define L_(j,r)^b by the L2_(kappa) norm, weighted by |alpha|^2, of the
L1_e norm of partial_e^r(e^j B^b), j=0,1, and let bar L be their supremum
over the compact scaled family. These constants are finite by the named
order-seven threshold input and smooth envelopes. Then

    ||A_r^b||_(L2_K)=lambda^(3/2-r) L_(0,r)^b,
    ||D_r^b||_(L2_K)<=lambda^(3/2-r)
                            [sqrt(6)L_(0,r)^b+lambda L_(1,r)^b]. (F35)

Put D_star=sqrt(6)(bar L_(0,7)^in+bar L_(0,7)^out)
+lambda_0(bar L_(1,7)^in+bar L_(1,7)^out). At T=lambda^(-3/2), prepare

    Eta_-=P exp(iTH0)Psi_lambda/||P exp(iTH0)Psi_lambda||,
    Eta_+=exp(-2iTH)Eta_-.

The one global normalization is legitimate for sufficiently small lambda,
since removed mass p<= [bar L_(0,7)^in]^2 lambda^10. Cook gives

    ||Eta_+-exp(-iTH0)S Psi_lambda||
       <= (D_star/6)lambda^(7/2)+sqrt(2)bar L_(0,7)^in lambda^5. (F36)

Let Q_other be the free positive-band projector onto the other seven corner
windows on the actual packet support. Its expectation on Eta in P is the
compression P Q_other P; Q_other need not preserve P. Since its norm is one,
the difference between its outgoing probability and (F33) is at most twice
the right side of (F36). Its initial leakage after the projection is at most
2p=O(lambda^10). Thus the actual finite-time probability, and also its change
from the prepared initial probability, has the same positive leading
lambda^2 C_beam as (F33). Global projection reweights K; this norm estimate
already includes that change and assumes no fiberwise renormalization.

## 11. Evidence, failed shortcuts and remaining obligations

The complete helper `flux_bridge/flux_controls.py` and its full exit-0 log
`flux_bridge/flux_controls.log` were read. Source SHA-256:
`9803c454d4cc7610e0056ef47d389891cecb1680b2dc666c92d6d9ed36476a36`;
log SHA-256: `cea70a1a1fc9bf42b9ae087ab525cbb0f0a934fb872964e2375faab01b5edfb1`.
Exact Gaussian-rational calculations verify all 64 local source/absorption
identities on a 4^3 torus, its finite-box outward-flux identity, all parity
zeros, paired incident density and contact factors, and a normalized
eight-channel example with other-corner probability 7/80 and total probability
one. The floating controls construct original tensor-product spin projectors
on actual lattice shells, sum their eight coherent parity fields, and compute
the bond currents. Across 24 shell cases they agree with the proposed parity-
averaged current within relative error 3.92e-16 and approach the limiting
ellipsoid density. A separate one-dimensional angular quadrature checks its
total normalization. Floating quadrature is not interval certified. None of
these finite checks proves stationary phase or a uniform PV estimate.

Failed or insufficient shortcuts are preserved:

- Adding eight intensities at each lattice site misses exact parity zeros.
  Only the defined weak annular flux averages the interference terms away.
- The candidate e^(iEr/2) phase is not valid at fixed E for arbitrarily large
  r; the lattice phase p_E(n).x is retained.
- A unit directional delta is not an L2 shell state; (F20) is explicitly a
  generalized flux-density reference, while (F29)-(F32) are normalized beams.
- The net vector current of an antisymmetric paired incident field is not
  its total incoming flux density. Ordered and unordered normalization factors
  cannot be silently interchanged.
- ||(S-I)chi||^2 is not generally a detector probability. The disjoint-output
  construction (F31) removes incident/scattered interference only where the
  incident state is actually zero.
- A continuum flux-across-surfaces theorem was not applied to this lattice.
  The stationary flux functional is defined and proved directly here.

The K=0 stationary result has a supplied-model proof above. Independent
checking is still needed, especially for incident/quotient normalization,
the matrix stationary-phase extension and the parity-averaged flux limit.
The general central asymptotics inherit the frozen threshold coefficient
and remainder; the finite-time normalized beam additionally inherits its
order-seven derivative estimate. These are named provisional dependencies,
not consequences of the finite helper. No common simultaneous large-radius/
low-energy error bound or beam-width-to-plane-wave cross-section limit has
been proved. The latter would be a useful further bridge, not a condition
silently assumed in the stated separate experiments. No physical collision
clock, many-body closure, Boltzmann equation, relaxation rate, adopted law,
or universal current loss follows from this note.

All work is external. No W or walk_worktree science, registry, audit status,
commit or PR was changed. PDF-tool setup initially lacked `pdftotext` on PATH
and `fitz` in the bundled Python; the bundled Poppler executable then produced
the text and rendered page used above. Those were tooling failures, not
failed mathematical tests. Exact final identities and reading scope are
recorded in `flux_bridge/identity_manifest.json` after the cold read.
