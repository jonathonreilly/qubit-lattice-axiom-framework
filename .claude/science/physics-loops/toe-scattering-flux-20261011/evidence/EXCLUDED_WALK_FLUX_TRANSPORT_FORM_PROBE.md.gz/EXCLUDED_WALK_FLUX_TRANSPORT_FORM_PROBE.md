# Scattering-flux transport form for the supplied excluded walk

External author derivation, 2026-10-11. Claim type: bounded theorem proposal;
author support status: conditional support. This is a continuation of the
frozen probability-flux proof, not an independent review or an audit verdict.
The supplied walk, singlet exclusion, antisymmetric sector, lattice units and
canonical energy placement remain premises. No many-body closure, loss of
coherence, collision clock or physical transport law is adopted.

The exact result, in the conventions defined below, is

    Q_mu(f)=4pi rho^2 Var_nu(f)/|G|^2
           =(1/pi)||S^* f S-f||_op^2.                    (T1)

Here mu is the unnormalized full-shell phase-space measure and nu=w mu/rho
is the normalized contact probability measure. The leading three-component
canonical-current form has an order-lambda^8 expansion, calculated below.
Its rank is the number of nonzero components of kappa. Dividing the form by
the total phase-space mass changes its order to lambda^6. These statements
refer to different normalizations, not to competing physical rates.

## 1. Exact contract, sources and prior-art coverage

Target: derive the scattering-flux quadratic form from the actual paired
incident normalization; prove its positivity, coercivity and coherent-norm
identity; calculate its full energy-current tensor on a compact central
scaling domain. The new obligation is the measure-normalized transport form
and its tensor, rather than another one-component scattering-phase estimate.
The proof route is flux disintegration, exact rank-one algebra, then the
fourth moments of the limiting contact ellipsoid. Separate finite controls
within this author run use weighted matrix algebra and direct polynomial
integration, followed by actual lattice-shell quadrature. They do not confer
independent-review status.

All external paths below are relative to
`/Users/jonreilly/Documents/Codex/research_runs/toe_leap_20261009/resume_20261011`.

| Source | SHA-256 | Exact role |
| --- | --- | --- |
| `EXCLUDED_WALK_FLUX_BRIDGE_PROBE.md` | `35cfa3095d1abaaeef0e6b77296b42a218615b23f680ee312576adbf924dfc17` | F3-F9 and F18-F22: outgoing source flux, eight-corner measure, and paired incident convention. F26 supplies the named central G expansion; F29-F31 distinguish normalized coherent beam probabilities. No bytes changed. |
| `ROOT_EXCLUDED_WALK_FLUX_REVIEW.md` | `8fbc4a36dc351460bfc151a4bb3c40ea569f437057e2b72da47540c508608214` | Entire independent selective review read; reports complete frozen flux-note coverage and no requested repair. Its reviewed scope and limits remain attached. It is not a review of the present transport derivation. |
| `EXCLUDED_WALK_TRANSPORT_PROBE.md` | `8bc423b2d5adf368f4ae09a2bb87730517be243a050b4289dad3a0b217f09526` | Supplied walk, regular central channels, stationary S, contact threshold coefficient and G expansion. The general central expansion remains an inherited analytical input. |
| `EXCLUDED_WALK_COHERENT_PACKET_DRAFT.md` | `b4ae921cc065fb2f38c1caee5aca3a1cf69bac317a6f6f0f537becd393b6cd38` | Entire note reread. P9-P16 supply the fixed coarea convention and limiting contact distribution; the scalar moment is rederived and extended to all cross moments here. P3 and the asymptotic paragraph after P22 identify the canonical-current observable. Its finite-time Cook theorem is not used. |
| `EXCLUDED_WALK_CANONICAL_CURRENT_DRAFT.md` | `79bc9fb3b9fd9b703f12de0a4ca4ebd62644c81bd6e15c07f723b6b7a1c977fe` | Previously fully read and independently reconstructed identity J=P g P+F for the stated placement; asymptotic current mapping only. |

The first threshold source and both new derivations are this author's work;
reusing their proofs is not an independent check of them. The parent campaign
holds their source-bound checks. The present note requires a new selective
check of its normalization, off-diagonal moments and tensor rank.

The repository comparison remains the identified local main snapshot
`a13caa4885f547c8d206265b031ba7649e539fd9`. Three new statement searches,
commands and all eleven raw hits are saved under `flux_transport_form/`.
All eleven hit lines were read. The only matched walk source is the previously
fully read M6 note
`docs/ADMISSIBILITY_RULE_UNDER_ONE_RECORD_PER_SITE_A_COLLISION_CHANGES_THE_RECORDS_TWO_STEP_MOMENTUM_ONLY_AT_THIRD_ORDER_IN_THEIR_OFFSETS_FROM_THE_CONES_BOUNDED_THEOREM_NOTE_2026-09-26.md`,
SHA `e0536f80a25feb0b368c10a0016a9d09b07b5bd06827751c30029d2eb1d70065`.
Its rank-one/contact angular weight is prior art. It supplies an FGR-rate
convention and does not derive this incident-flux form or current tensor.
Other hits concern plane-chain cross sections, cq-channel covariance, winding
covariance, or ice-estimator covariance and are context-only at the returned
scope. Their complete unrelated proofs were not read for this task. No global
novelty or refreshed open-PR inventory is claimed.

No new literature theorem is used. The primary lattice stationary-phase
source and its checked hypotheses remain in the unchanged flux note. The
physics-loop instructions and applicable references matched local main at
a13caa; the bounded external-file brief overrides campaign branch/PR/output-
pack operations. No network freshness, repository mutation, or audit operation
was performed. The receipt records exact current identities and reading limits.

## 2. Shell space, measures, spin and paired incidence

Fix 0<E<=1/8 and |K|<=E/4 on a regular positive shell for which G is nonzero.
The supplied free fiber is

    H0(K,q)=sigma_1 dot sin(K/2+q)+sigma_2 dot sin(K/2-q).

Only the ++ band is open. Its eight corner components together form Sigma.
Write v_g(q)=|grad_q E_(++)(K,q)|, Pi(q) for its rank-one spin projector, and

    dmu(q)=dSigma(q)/[(2pi)^3 v_g(q)],
    w(q)=<c,Pi(q)c>,   rho=integral_Sigma w dmu,
    M=mu(Sigma),      dnu=w dmu/rho.                      (T2)

Thus mu is finite but not normalized, while nu is a probability measure.
The regular central geometry gives 1/4<=w<=1/2. The constant spin vector c
is the normalized singlet. G=<c,(H0-E-i0)^(-1)c> has Im G=pi rho>0.

The fiber norm uses the entire relative q torus, restricted by exchange
antisymmetry. Scalar observables f below are real and exchange even,
f(-q)=f(q), so multiplication preserves that physical subspace. All eight
corners and both antipodal points are already present in (T2). If instead
one works on exchange orbits, the measure is the pushforward of the full
mu, namely twice its restriction to a representative half-shell. This and
the corresponding norm isometry preserve every formula below. No further
factor of two or eight is inserted.

A paired generalized incident field at a in Sigma has mean full-relative-
space density one, speed v_g(a), and contact intensity 2w(a). Its two opposed
components each have density one half. Its defined incoming flux is the sum
of their incoming magnitudes, v_g(a), not their net vector current. The
outgoing resolvent source has angular flux 2pi w(b)dmu(b). This is the
spectral/coarea disintegration of the weak spatial flux in F18-F19; the
projector weight w retains the spin dependence. Therefore the paired
cross-section measure and its speed multiple are exactly

    d sigma_pair(a,b)=4pi w(a)w(b)dmu(b)/[v_g(a)|G|^2],
    k(a,db):=v_g(a)d sigma_pair(a,b)
             =c_G w(a)w(b)dmu(b), c_G=4pi/|G|^2.         (T3)

The input factor 2w(a) is essential. A formal unit-density ordered component
would give half this coefficient, but it is not the antisymmetric incident
state of the frozen flux result. Using that alternative normalization without
changing all later constants is an error.

Equation (T3) defines a scattering-flux kernel. Its total weight at a is

    ell(a)=c_G rho w(a),   k(a,db)=ell(a)dnu(b).           (T4)

This disintegration is not a count of actual encounters per unit time. The
coherent scattering operator does not discard the incident amplitude or its
interference. In particular, k is not inferred to be its repeated-collision
Markov transition law.

## 3. Exact variance identity, boundedness and coercivity

For real exchange-even f in L2(mu), define

    Q_mu(f,h)=(1/2)integral dmu(a) k(a,db)
                                [f(b)-f(a)][h(b)-h(a)],
    Q_mu(f)=Q_mu(f,f).                                   (T5)

Symmetry holds because dmu(a)k(a,db) is invariant under exchanging a and b.
Expanding the square and using integral w dmu=rho proves

    Q_mu(f,h)=c_G rho^2 Cov_nu(f,h),
    Q_mu(f)=c_G rho^2 Var_nu(f).                         (T6)

All integrals exist for L2(mu) because w is bounded and mu is finite. This
also proves positivity without a dynamical or incoherence hypothesis.

Let w_- be a positive lower bound for w and w_+ an upper bound. Define

    dist_mu(f,constants)^2=min_b integral |f-b|^2 dmu.

Since variance minimizes the corresponding squared distance, comparison
of the measures w mu and mu gives the two-sided estimate

    c_G rho w_- dist_mu(f,constants)^2
       <=Q_mu(f)<=c_G rho w_+ dist_mu(f,constants)^2.      (T7)

For the upper bound, evaluate the weighted minimization at the mu mean;
for the lower bound use w>=w_- before minimizing. Thus the nullspace is
exactly the constants, up to mu-null sets, and the form is coercive on their
L2(mu) orthogonal complement. It is a bounded quadratic form, represented by

    (A_mu f)(a)=c_G rho w(a)[f(a)-integral f dnu],
    0<=A_mu, ||A_mu||<=c_G rho w_+.                      (T8)

Indeed its L2(mu) inner product with h equals (T5). The weighted mean is
not generally the mu mean; substituting one for the other in (T8) would
break this identity. All bounds restrict correctly to exchange-even functions.

Here coercivity is a statement about a mathematical form and its normed
space. It does not assert exponential decay under the actual unitary walk.
A Markov evolution built using -A_mu would be an additional construction,
requiring a specified physical encounter process and loss of coherence before
it could represent collisions in a many-body system. Neither is derived.

## 4. Exact relation to coherent shell-current change

In the actual shell Hilbert space let

    v=Zc/sqrt(rho), S=I+(s-1)|v><v|, s=conj(G)/G.

The probability measure induced by v is precisely nu. For bounded real
exchange-even f, put m=integral f dnu and W=(f-m)v. Then W is orthogonal
to v, and direct expansion of S^* f S gives

    D_f:=S^* f S-f
       =(s-1)|W><v|+(conj(s)-1)|v><W|.                  (T9)

The diagonal term cancels using |s|=1. If W is nonzero, this is a two-by-two
off-diagonal Hermitian block on span(v,W); otherwise it is zero. Therefore

    ||D_f||_op^2=|s-1|^2 Var_nu(f),
    Tr(D_f D_h)=2|s-1|^2 Cov_nu(f,h),
    |s-1|^2=4pi^2 rho^2/|G|^2.                         (T10)

Combining (T6) and (T10) proves (T1) and its polarized form

    Q_mu(f,h)=(1/(2pi))Tr(D_f D_h).                     (T11)

The trace exists because these differences have finite rank, regardless of
the infinite dimension of the angular shell. The operator norm equals the
largest absolute coherent expectation change over unit vectors, not the
change of every vector. The form is its square divided by pi.

Dark coherent channels are retained exactly: S psi=psi whenever
<v,psi>=0, so their expectation of every bounded f is unchanged. Also S v=s v,
so v itself has unchanged angular probability and unchanged f expectation.
When Q_mu(f)>0, W/||W|| is an explicit normalized dark preparation.
These states give zero current change despite the positive form. A finite-beam transfer
probability additionally depends on its overlap with v and the detector;
it is not Q_mu(f), and the flux note's formula for disjoint detectors retains
that dependence. Positivity of (T6) is not universal unitary dissipation.

## 5. Central scaling and the three relevant measures

Take (kappa,e) in any compact set with 0<e_min<=e<=e_max and
|kappa|<=e/4, and set K=lambda kappa,E=lambda e. Choose lambda sufficiently
small for the regular-shell hypotheses. Write

    D=e^2-|kappa|^2, B=[D I+kappa kappa^T]/4,
    rho=lambda^2[r0+O(lambda^2)], r0=D/(4pi^2),
    G=lambda[A(kappa,e)+O(lambda)],                     (T12)

uniformly on that compact set. The named threshold input supplies

    A=e integral [(e^2-|kappa odot cos q|^2)
        /(4|sin q|^2(e^2-(kappa dot v0(q))^2))]dq/(2pi)^3,
    v0_i(q)=sin(q_i)cos(q_i)/|sin q|,
    (D/e)I0<=A<=e I0,
    I0=integral dq/[(2pi)^3 4|sin q|^2]>0.               (T13)

No new PV proof is asserted here. Only this order-zero expansion is needed;
the high-order threshold derivatives and Cook estimates are not used.

The limiting contact law can be reconstructed directly. On one cone put
p=kappa/2+y. The shell is |p|+|kappa-p|=e, with contact weight
w0=D/[8|p||kappa-p|]. For k=|kappa|>0, prolate coordinates with
u=(|p|+|kappa-p|)/k, t=(|p|-|kappa-p|)/k and azimuth phi have volume
Jacobian k^3(u^2-t^2)/8. Multiplication by w0 and delta(e-ku) leaves
D dt dphi/16. Integrating, restoring (2pi)^-3 and all eight cones, yields
r0=D/(4pi^2). After normalization, t is uniform on [-1,1] and phi on
[0,2pi]. Equivalently,

    y=L n, n uniform on S^2, L=B^(1/2),                 (T14)

with equal weight at each corner. The k=0 statement is its regular spherical
limit. This reproduces P13-P15 of the frozen packet source without treating
its scalar variance as an assumption for the new cross moments.

For later normalization the unweighted phase-space mass is also needed.
On this parametrization, 1/w0=2(e^2-k^2 t^2)/D. Consequently

    M=lambda^2[M0+O(lambda^2)],
    M0=r0 integral (1/w0)dnu0
       =(e^2-|kappa|^2/3)/(2pi^2).                     (T15)

The measure and shell geometry are smooth in lambda^2 in scaled coordinates,
so these order-two corrections are uniform. The spectral gap bound (T7) in
L2(mu) does not vanish merely because M does. Indeed

    c_G rho=D/[pi A^2]+O(lambda),
    15/(16pi I0^2)<=D/(pi A^2)<=16/(15pi I0^2).           (T16)

After decreasing lambda uniformly if necessary, (T7) thus implies the
explicit sufficiently-small-lambda bounds

    15/(128pi I0^2) dist_mu(f,constants)^2
         <=Q_mu(f)<=16/(15pi I0^2) dist_mu(f,constants)^2. (T17)

Here we used w_-=1/4,w_+=1/2 and a factor-two allowance in (T16).
The same constants hold if both Q and the squared L2 distance are divided
by M. They do not give a physical decay frequency.

Keep the measures separate:

- mu is the unnormalized phase-space measure, of mass M=O(lambda^2).
- bar mu=mu/M is normalized phase space. Its associated form with the same
  outgoing kernel is Q_bar_mu=Q_mu/M.
- nu=w mu/rho is normalized contact probability. The bare contact variance
  Var_nu(f) is Q_mu(f)/(c_G rho^2), not Q_mu itself.

In particular, normalizing the outer measure silently removes a factor
lambda^2. Replacing only the outer mu by nu while retaining (T3) generally
breaks detailed balance under a/b exchange and changes the variance identity
(T6). The resulting difference-product integral is still a symmetric bilinear
form in f,h, but it has different weights.

## 6. Energy-current tensor from full fourth moments

For the specified canonical energy placement the current is

    J_i=P g_i P+F_i,  g_i(K,q)=sin K_i cos(2q_i),
    F_i=-|partial_(K_i)(H0c)><H0c|-|H0c><partial_(K_i)(H0c)|.
                                                               (T18)

The bounded finite-rank F_i has vanishing free asymptotic expectation on
the regular packets with the integrable spectral profiles specified in the
canonical/packet sources. Wave-operator convergence transfers that statement
to scattering states. Thus g_i is the asymptotic canonical-current multiplier.
This section computes its angular form. It does not apply (T5) to the full
finite-time operator F_i, which is not a scalar angular multiplier.

On a corner q=C+lambda y, subtract the shell-constant sin(lambda kappa_i):

    g_i-sin(lambda kappa_i)
         =lambda^3 gamma_i(y)+O(lambda^5),
    gamma_i(y)=-2 kappa_i y_i^2.                         (T19)

The expansion is uniform in the scaled shell coordinates. Constants vanish
from every covariance. If C_ij denotes Cov_nu0(gamma_i,gamma_j), then

    Cov_nu(g_i,g_j)=lambda^6 C_ij+O(lambda^8).            (T20)

For n uniform on S^2,
E(n_alpha n_beta)=delta_(alpha,beta)/3 and its fourth moment is the sum
of the three pairings divided by 15. Using y=Ln and LL^T=B gives

    E(y_i^2)=B_ii/3,
    E(y_i^2 y_j^2)=[B_ii B_jj+2 B_ij^2]/15,
    C_ij=(8/45)kappa_i kappa_j[3B_ij^2-B_ii B_jj]
        =(kappa_i kappa_j/90)
          [3(D delta_ij+kappa_i kappa_j)^2
                   -(D+kappa_i^2)(D+kappa_j^2)].        (T21)

For i=j this reduces to kappa_i^2(D+kappa_i^2)^2/45, agreeing with
P15-P16 after squaring its one-component standard deviation. Off-diagonal
entries generally do not vanish; treating the three squares y_i^2 as
independent would give an incorrect tensor.

Define the transport tensor T_ij(lambda,kappa,e)=Q_mu(g_i,g_j). Equations
(T6),(T12),(T20) give the explicit result

    T_ij=lambda^8 T0_ij+O(lambda^9),
    T0_ij=[D^2/(4pi^3 A^2)] C_ij
         =[D^2 kappa_i kappa_j/(360pi^3 A^2)]
           [3(D delta_ij+kappa_i kappa_j)^2
                     -(D+kappa_i^2)(D+kappa_j^2)].       (T22)

The error is uniform in matrix norm on the selected compact central set.
The order-nine remainder comes from the inherited O(lambda) correction to
G/lambda; the angular covariance itself has the stronger order-eight error.
For a real current direction z,

    Q_mu(z dot g)=z^T T z,
    ||S^*(z dot g)S-z dot g||_op^2=pi z^T T z.           (T23)

For a single component with kappa_i nonzero, the coherent packet's leading
signed coefficient has magnitude
c_i=|kappa_i|(D+kappa_i^2)D/(6pi sqrt(5) A). Accordingly
T0_ii=c_i^2/pi. This checks the normalization against the earlier coherent
construction, but is not its independent review. At finite lambda that
specific v plus/minus i u preparation attains |Im s| times the standard
deviation; the operator optimum uses |s-1|. Only their leading small-phase
coefficients coincide.

The measure comparison is now explicit:

    Q_mu(g_i,g_j)=O(lambda^8),
    Q_bar_mu(g_i,g_j)=lambda^6 T0_ij/M0+O(lambda^7),
    Cov_nu(g_i,g_j)=lambda^6 C_ij+O(lambda^8).            (T24)

Energy E and total momentum K are constants on each fixed shell and have
zero form. The current is an angular observable and can have positive form
without either conserved quantity changing.

## 7. Tensor rank, null directions and explicit bounds

Let I={i:kappa_i!=0}, let a_i=kappa_i z_i and A_z=diag(a_1,a_2,a_3).
The quadratic form of the covariance tensor is

    z^T C z=(8/15)||L A_z L-[Tr(L A_z L)/3]I_3||_F^2.    (T25)

This follows either from the fourth moments above or from the uniform-sphere
variance of a quadratic form. Hence it vanishes exactly when

    A_z=t B^(-1), B^(-1)=(4/D)[I_3-kappa kappa^T/e^2]     (T26)

for some real t. If I is a proper subset, an inactive diagonal entry of A_z
is zero whereas the corresponding entry of B^(-1) is positive; therefore
t=0. If I is all three coordinates, a nonzero off-diagonal entry of B^(-1)
again forces t=0. Thus, for every kappa,

    ker C={z:kappa_i z_i=0 for each i}, rank C=|I|.       (T27)

As a useful nondegenerate example, when kappa=b(1,1,1) with b!=0,
substitution in (T21) gives eigenvalue b^6/15 along (1,1,1) and the
double eigenvalue b^2 D(D+2b^2)/30 on its orthogonal complement. The third
direction is weak for small b but positive; replacing the contact ellipsoid
by an exactly spherical law would incorrectly erase this contribution.

At kappa=0 all entries are zero. The same rank holds for T0 because its
scalar factor in (T22) is positive. At actual K=lambda kappa, each inactive
current component g_i is exactly zero. On a compact set with a fixed active
pattern bounded away from kappa_i=0, the active finite-lambda tensor retains
rank |I| for sufficiently small lambda, by (T20) and positivity below.
There is no uniform rank-three coercivity across coordinate planes.

A quantitative lower bound avoids relying only on a rank calculation. For
nonempty I put

    eta_I=1-[sum_(i in I) (B^(-1)_ii)^2]/||B^(-1)||_F^2>0.

The strict inequality follows from an unused positive diagonal term when I
is proper, or from off-diagonal terms when I is all three. For any diagonal
A_z supported on I, Cauchy-Schwarz gives

    dist_F(A_z,span(B^(-1)))^2>=eta_I sum_i a_i^2.

Since ||L^(-1)||^2=4/D, conjugating the traceless minimization in (T25)
gives the lower bound; ||L||^2=e^2/4 gives the upper bound:

    (D^2 eta_I/30)sum_i kappa_i^2 z_i^2
       <=z^T C z<=(e^4/30)sum_i kappa_i^2 z_i^2.         (T28)

These explicit bounds, multiplied by D^2/(4pi^3 A^2), bound T0. They also
supply uniform active-subspace coercivity on any of the compact sets just
described. Constants and a sufficiently small lambda range can be chosen
from their positive minima and the finite uniform remainder in (T20).
No numerical largest validity range is certified here.

In particular, K=0 has positive paired probability-flux cross section but
zero canonical energy current, and hence a zero current tensor. If kappa
has one or two zero components, the corresponding exact current directions
remain null. Coherent dark preparations remain stationary under S even when
all three current directions give a positive tensor. These are separate,
compatible facts about the observable, measure and prepared state.

## 8. Controls, scope and next check

The separate helper `flux_transport_form/transport_controls.py` and complete
log `flux_transport_form/transport_controls.log` are author evidence. Its
first family uses a genuinely nonuniform unnormalized eight-atom measure,
with different mu and nu, and exact Gaussian-rational S matrices. It verifies
the variance identity, squared operator norm, Hilbert-Schmidt polarization,
coercivity on the chosen fixture and exact dark/pure-contact zero-change controls. Multiplying by
pi makes all tested coefficients rational without substituting a decimal pi.
The finite atoms are exchange-orbit quadrature analogues, not a claim that
the actual eight corner masses differ.

The second family directly integrates polynomials on the unit sphere using
exact monomial moments, rather than inserting the tensor formula. Five
rational ellipsoid geometries have ranks 0,1,2,3,3 as their active components
predict; exact principal-minor tests check the proposed upper and lower
quadratic bounds. The last family evaluates the actual sine-dispersion
coarea moments, retaining all eight corners, in nine shell cases at two
quadrature resolutions. It checks mass, contact density and the full current
covariance against the limiting formulas. This floating calculation is not
interval certified and does not prove the analytic uniform remainders.
The method overlaps this author's earlier radial-shell controls; it is
separate finite evidence, not an independent scientific review.

The complete 228-line helper and 18-line exit-0 log were read. Their SHA-256
identities are `befeb5d995039a55031ce697e1098370ebed1c3a846657ef3cc1cd1d01830d23`
and `aeaec385f509e049b7175c8b7987219ab2e77781b193fa0a352d9dd08a9c44d4`,
respectively. Exact identities, execution status, source coverage and tooling
failures are recorded in `flux_transport_form/receipt.json`. The note and controls do not
recompute G by a numerical PV fit. The general central expansion remains
the named analytical dependency; the abstract identities T3-T11 hold on
any regular supplied shell satisfying their explicit conditions.

Insufficient routes retained: replacing the paired incident state by an
ordered component loses a factor of two; normalizing mu silently changes a
lambda power; discarding cross covariances can change rank; and treating the
positive form as a statewise unitary current loss conflicts with its exact
dark and phase-only controls. These are normalization/interpretation checks,
not a universal no-go claim about future kinetic constructions.

The strongest remaining task is an independent source-bound check of T3,
T11, T21 and the coercivity/rank proof. Interpreting this form as a closed
Markov collision equation would require further hypotheses or derivations,
including a justified encounter process and loss of phase information. This
note neither adopts those inputs nor proves they are impossible. No W or
walk_worktree source, prompt, registry, commit, PR or audit status was changed.
