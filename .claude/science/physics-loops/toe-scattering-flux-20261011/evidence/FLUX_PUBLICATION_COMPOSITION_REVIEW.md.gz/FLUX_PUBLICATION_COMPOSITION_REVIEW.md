# Source-bound flux/form publication composition check

2026-10-11. No composition repair is requested for the frozen note and primary
identified below. The complete mathematical content of both author sources is
preserved, and the combined primary does not change the checks through its
shared namespace. This is an author-source composition check, not an independent
scientific review of those derivations, a landing verdict, or an audit decision.

The publication's `DELIVERY_CHECKS.md` did not yet exist when inspected.
The prospective mutation, canonical-cache and packaging claims at note lines
1207-1211 are therefore outside this report's verified scope. Root reports completion of
that separate work; its new outputs were not inspected by this check. The historical Lean scope and review statements were
source-matched; no new compiler execution or full formalization-package review
was performed here.

## Frozen identities and reading coverage

Paths below use W=`../walk_worktree` relative to the external source directory S.
All exact absolute paths and additional evidence hashes are in
`flux_publication_review/receipt.json` and `composition_checks.json`.

| Artifact | SHA-256 | Coverage |
| --- | --- | --- |
| W/docs/EXCLUDED_WALK_SCATTERING_FLUX_TRANSPORT_FORM_BOUNDED_THEOREM_NOTE_2026-10-11.md | `c70ad03ede2a01c0b49282043a4b20824f64a6b42c3440facae1b6c5e231c0bc` | All new header lines 1-83, footer lines 1178-1218, and all 11 changed prose blocks read. Complete body compared against both previously fully read frozen sources. |
| W/scripts/excluded_walk_scattering_flux_transport_form_2026_10_11.py | `f8bdf9f014eae164ab283d73910ff38968933637ff25349f5e9c5d1f974dff2a` | All 470 lines read, including every check family and wrapper. |
| W/docs/EXCLUDED_WALK_LOW_ENERGY_ENERGY_CURRENT_BOUNDED_THEOREM_NOTE_2026-10-11.md | `9f551fc8d3592e83d15a007495a8f9165a5ddb9bc1e98d9dd3f51b6a2584f401` | Identity refreshed; contract/provenance lines 1-96 and scope/evidence lines 1210-1280 inspected. No new full 1280-line parent review claimed. |
| S/EXCLUDED_WALK_FLUX_BRIDGE_PROBE.md | `35cfa3095d1abaaeef0e6b77296b42a218615b23f680ee312576adbf924dfc17` | Previous complete 628-line author reading reused; all bytes matched into publication after declared prose changes. |
| S/EXCLUDED_WALK_FLUX_TRANSPORT_FORM_PROBE.md | `52e8b10cc7db84d65372bfac18a0a0839889b03003190ee0ec310b503115f143` | Previous complete 468-line author reading reused; all bytes matched into publication after declared prose changes. |
| W/.claude/science/physics-loops/toe-scattering-flux-20261011/SOURCE_COMPOSITION.json | `8e457c06daf37e38a5c620ceea8e058a1cd28587c5b7ea8e38384294d77eb851` | All declared replacements inspected; every evidence-copy entry checked. |
| S/flux_publication_source_diff.txt | `252958f1577d901eb54b76334853e19d69ddb3f7c3c8bd495934c57ef06b0881` | All 323 lines read. |

## Preservation, dependency and status findings

The check reconstructed each publication body from its original using only the
11 declared prose substitutions and one extra heading level for the numbered
sections. Every remaining byte matches, allowing only trailing newline padding
at the two composition boundaries. No equation, hypothesis, normalization,
proof argument, exceptional case, limit order, negative control or stated
analytical limitation was removed or changed.

The new header preserves the distinction between the stationary paired-flux
cross section and normalized finite-beam probability. It keeps the mu versus
normalized-mu powers separate, states the tensor's active-coordinate rank,
restricts the scalar current in the form to its asymptotic meaning, and names
the unproved encounter/phase-memory bridge as a future target. It introduces
no collision clock, universal unitary current loss or many-body closure.
The conditional-support surface and absence of independent audit remain
explicit despite the `proposed_retained` proposal label.

The single declared upstream claim is the unchanged complete low-energy
parent. The text explicitly requires its full stacked delta or cumulative
review from a13caa, rather than a bare reference to rejected or partial work.
Its threshold, Cook, canonical-current and coherent-packet research sources
are all present in the parent's evidence directory and decompress to the four
exact inherited identities. Their prior full-source reading is reused for
premise matching; the parent's publication composition is not re-certified
here. The K=0 flux calculation stays self-contained at threshold; general
central and finite-time claims retain their respective threshold and
order-seven Cook inputs. Those are analytical dependencies, not conclusions
of the Python controls.

All 26 evidence representations in SOURCE_COMPOSITION match both their stored
hashes and original bytes, including the lossless compressed author sources.
The complete independent root flux and form reports were read and their
identities checked: `8fbc4a36dc351460bfc151a4bb3c40ea569f437057e2b72da47540c508608214`
and `5ff79b0756214eb75f94b8b64e8eeae4dbb7eefcba4640dc9b97e6be78fbe572`.
Their actual scope supports the revised review-status prose. It does not
promote this author's composition work to independent science.

The scoped Lean footer agrees with the complete root statement/evidence
review `3735e869cfd20c5ac15b5d4e081c1da14851567e4bba5cd033ba8edddbcf771c`,
README and SCOPE_REPORT. The installed 202-line theorem source matches
`2f5260a23eecc90c6bf3fabe9e26c4c05a5595fa151b98010097a7ee501b22ae`.
Unitarity, observable difference, coherent expectation and disjoint-cap
algebra remain distinguished from the unformalized lattice flux, threshold,
Cook, operator-norm and tensor proofs. This check relies on the recorded
source-bound compiler review; it is not a new Lean statement/proof review.

## Primary composition and actual replay

Both embedded programs are byte-for-byte copies of their 206-line flux and
228-line transport helpers. Their original SHA-256 values are
`9803c454d4cc7610e0056ef47d389891cecb1680b2dc666c92d6d9ed36476a36` and
`befeb5d995039a55031ce697e1098370ebed1c3a846657ef3cc1cd1d01830d23`.

There are real name collisions: the second block redefines Q and inner, and
reuses several scalar/array names. They do not change this execution. Every
flux check completes before the redefinitions. The form block imports or
defines its own required globals and does not call the first block's functions
or reuse its old Q instances. Shared F/sin/cos/sqrt/pi imports have the same
meaning. Wrapper names Path, sha256, perf_counter, sys, _source and _started
are not rebound by either helper. No deferred callback or later rerun of the first block occurs; the second
block does not inspect earlier fixtures or condition its checks on their names.
This finding applies to the actual sequential primary; later code calling
old functions after Q is rebound would need a fresh check.

For a direct composition control, each helper was executed in a fresh
namespace, then the actual full primary in a fresh namespace. Both complete
standalone outputs equal their frozen author logs, and the primary contains
those exact two complete outputs in order. All three executions completed;
the composition checker exited zero. The primary's own-byte integrity check
also ran. The entire 37-line primary output and 8-line composition log were
read. These are author-control replays for execution consistency, not a new
independent mathematical derivation. They do not certify the analytical
limits, non-certified quadrature, Lean execution, future mutations or cache.

The wrapper declares the publication note, unchanged parent and Lean source
as cache inputs. It does not execute or validate those proofs; the source and
footer correctly keep that distinction. The mutation/cache/publication-pack
work is deliberately left to root's separate final evidence.

## Recovery and limits

The external composition checker and full logs are preserved under
`flux_publication_review/`; all control replays succeeded. The first receipt
freeze stopped on a concurrent manifest identity change, from 3b446be1 to
8e457c06. A targeted refresh verified the only representation changes: three
historical review Markdown files now use gzip with identical decompressed
bytes. No scientific replay was repeated. The original check record and
receipt-attempt traceback are preserved alongside the refreshed identities. No repository, frozen
author source, editable prompt, branch, commit, PR or audit state was changed
by this task. All original sources remain recoverable unchanged.

The applicable installed reviewer skill and selected workflow/reference
files match local main a13caa. Local planning instructions were read at
3a4b2c66a1ead7a1c48b4359627e968f681e3c39; no network freshness was claimed.
The bounded composition brief governs the scope: no new global novelty scan,
full parent re-review, independent re-derivation of this author's mathematics,
formal retained-status decision or blanket publication certification is given.
