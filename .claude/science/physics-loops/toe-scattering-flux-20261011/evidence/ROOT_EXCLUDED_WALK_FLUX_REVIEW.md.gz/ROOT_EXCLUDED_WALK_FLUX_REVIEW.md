# Source-bound independent check of the excluded-walk flux bridge

2026-10-11. Root review of another agent's frozen derivation. This is a
selective independent research check, not an applied audit verdict or a
retained-status decision.

The reviewed note is `EXCLUDED_WALK_FLUX_BRIDGE_PROBE.md`, all 628 lines,
SHA-256 `35cfa3095d1abaaeef0e6b77296b42a218615b23f680ee312576adbf924dfc17`.
Its author manifest is `flux_bridge/identity_manifest.json`, SHA-256
`bce0efccd70fb05701321215727f78c06cacacd8aa332b2d7b9ceb68177a46f5`.
All fifteen input/artifact identities in that manifest were reverified.
The entire 206-line author helper and complete successful log were read.
I did not count replay of those controls as independent evidence.

The frozen threshold, canonical-current, Cook, and coherent-packet inputs
were already read in full during the preceding walk milestone. Their
unchanged identities and the source-bound independent checks were reused.
In particular the full threshold expansion and its fixed-order scaled
derivatives are inherited analytical results, not consequences of the
finite controls in this report.

## Finding and permitted scope

No consequential defect was found in the supplied-model statements.
The stationary cross section, angular flux, and normalized packet transfer
are suitable for conditional-support publication with their stated
normalizations, order of limits, and preparation hypotheses intact.

The strongest self-contained threshold result is the positive paired-flux
limit `sigma_pair -> 1/(4 pi I0^2)` at K=0. The general central coefficient
additionally uses the frozen expansion of G. The finite-time normalized
beam additionally uses order-seven spectral-profile regularity and the
Cook comparison. Neither a physical collision clock nor a many-body
kinetic law is derived by any of these statements.

## Independent reconstruction of the load-bearing argument

1. For the stated nearest-neighbor coefficient T, summing the bond current
   `-2 Im(psi_x^* T psi_(x+e))` gives
   `div j=-2 Im(psi_x^* f_x)` when `(H0-E)psi=f`. For
   `R=(H0-E-i0)^(-1)c`, the source product at the origin is `bar G`.
   Hence the outward source flux is `2 Im G=2 pi rho`, with positive
   outgoing sign. At finite eta the extra term is
   `-2 eta ||R(x)||^2`; it cannot be discarded in a finite-eta identity.
   The boundary-value field satisfies the source identity on any finite
   set, so no unproved exchange of an infinite-volume eta limit is needed.

2. The contact-subtracted wave `psi_in-R a/G` has exactly zero contact
   amplitude and solves the compressed stationary equation. Its scattered
   field has flux `2 pi rho |a|^2/|G|^2`. The full field has zero net source
   flux because the incident/scattered interference remains present.
   The scattered flux is not loss of total probability.

3. At K=0, squaring the free symbol gives `4 sum sin(q_j)^2`.
   The scalar Green function therefore vanishes unless every coordinate
   of x is even. Substituting `2q=p` on the even sublattice gives the
   scalar lattice denominator `6-2 sum cos p_j-z^2` with no residual
   factor of eight. Applying the original numerator yields exactly the
   singlet/all-even and one-odd/triplet parity pattern in the note.
   This independently checks the spinor numerator and demonstrates why
   pointwise addition of eight positive cone intensities would be wrong.

4. In local energy/normal coordinates, the positive outgoing normal has
   PV normal Fourier factor `i pi` and delta factor `i pi`. Tangential
   stationary phase has signature -2 and contributes `-i 2 pi/r`.
   With Fourier measure `(2 pi)^(-3)`, their product is
   `1/(2 pi r v sqrt(curvature))`. The opposite normal cancels.
   At each fixed regular (K,E), the projector and coarea numerator are
   smooth on the relevant shell; the full resolvent matrix is smooth
   away from that shell. The argument therefore extends componentwise
   without requiring a smooth eigenbasis at unrelated band crossings.

5. Strict convexity is justified locally, not assumed for all lattice
   energies. At K=0 the relevant Hessian is `8 diag(cos 2p_j)>0`.
   In the scaled central domain the ellipsoid B has positive eigenvalues,
   both one-particle lengths stay bounded away from zero, and the shell
   converges in C^2. This supplies the nonvanishing velocity, curvature,
   and Gauss map needed in the preceding calculation.

6. The annular flux functional includes a cutoff difference of order R^-1.
   A current error of order r^-3 then sums to O(R^-1). In each parity
   cell, distinct-corner cross terms cancel exactly at frozen leading
   coefficients. Variation of those coefficients also costs O(R^-1).
   The diagonal Hellmann-Feynman current is the group velocity times
   the contact projector weight. Thus the weak angular density is
   `2w/(pi^2 v curvature)`. Integrating with the Gauss map gives
   `2 pi rho`, independently matching the exact source-flux identity.
   This proves a weak angular flux limit; it does not assert pointwise
   cone incoherence or a simultaneous R/lambda error bound.

7. The paired incident wave has mean relative-site density one, with
   two components of density one half. Since Swap c=-c, its contact
   intensity is `2 w_in`. The explicitly defined sum of incoming flux
   magnitudes is v_in. This gives
   `sigma_pair=4 pi rho w_in/(v_in |G|^2)`.
   The unordered-space norm map contributes no further division by two.
   The note correctly calls this a defined paired relative-coordinate
   cross section and distinguishes it from an ordered component.
   General K requires mean density; K=0 has pointwise unit density.

8. The K=0 threshold estimate follows by splitting the scalar integral
   into corner balls and their complement, rescaling the inner radial
   pole, and subtracting its smooth numerator in the PV integral.
   The inner and outer differences are each O(E), proving
   `G=E I0+O(E^2)`. The exact change `p=sin q` gives
   `rho=E^2/(4 pi^2)+O(E^4)`. With w=1/2 and v=2+O(E^2), the threshold
   constant follows. The eight-cone multiplicity has already entered rho;
   multiplying the cross section by eight again would double count it.

9. For the central ellipsoid, `gamma=D+(kappa.n)^2` gives speed
   `2 sqrt(gamma)/e`, weight `gamma/(2e^2)`, and scaled curvature
   `4 gamma^2/(D^2 e^2)`. These follow from its support function and
   `det B=D^2 e^2/64`. Independently substituting them in the flux
   expression reproduces both angular coefficients. Rotating kappa to
   the z axis, the antiderivative
   `z/[D sqrt(D+|kappa|^2 z^2)]` proves the required angular integral
   `4 pi/(D e)`. The general threshold coefficient A remains an explicit
   inherited input rather than a fitted value.

10. A contact-adapted normalized corner vector has contact overlap 1/sqrt(8).
    Applying the actual rank-one S gives amplitudes `(7+s)/8` in that
    corner and `(s-1)/8` in each other corner. Squaring yields
    `7 |s-1|^2/64` elsewhere, with the same-corner interference restoring
    total probability one. For disjoint A,B the exact probability is
    `|s-1|^2 nu(A)nu(B)`. Pure v changes phase only, so its detector
    distribution is unchanged even though `(S-I)v` is nonzero.

11. The packet factor lambda^-2 matches the four spectral integration
    dimensions (three K, one E); no fiberwise renormalization is inserted.
    The inherited r=7 Cook estimate at T=lambda^-3/2 gives an O(lambda^3.5)
    state error, hence an O(lambda^3.5) error for the norm-one compressed
    detector. The contact projection costs O(lambda^5) in state norm and
    O(lambda^10) in initial leakage. These errors are smaller than the
    positive lambda^2 inter-corner probability. This is a different
    normalized experiment from the generalized plane field; no beam-area
    or narrow-angle limiting theorem has been silently supplied.

## Primary-source match

Shaban and Vainberg, *Radiation Conditions for the Difference Schrodinger
Operators*, https://arxiv.org/pdf/1812.06390, was checked for its setup,
Fourier convention, Theorem 1, Lemma 2, Theorem 4, amplitude (13), and
the relevant proof through (21). Equation (13) on PDF page 8 was also
visually inspected. Its unitary Fourier source normalization gives the
same `1/(2 pi)` amplitude coefficient. The K=0 transformed scalar energy
`6-E^2` lies in the convex upper interval (2,6) at the stated energies.
Boundary-side and sign conventions were independently reconstructed above.
The later nonconvex and perturbed-operator results were not fully read or
used. The matrix extension rests on the supplied componentwise proof,
not a blanket application of the scalar theorem. The PDF SHA-256 is
`95cd35e4045482e4c7885e598be980cd2e75d426cdbe0d1880fa5bcd02103ffa`.

## Independent finite evidence and limits

`flux_review/independent_flux_controls.py` uses a nonparallel rational
Pauli-spin fixture, rather than the author's shell fixtures, to reconstruct
the paired normalization and contact factor. A nonuniform three-channel
matrix checks disjoint-detector probability, interference, and the dark
pure-contact preparation. Symbolic ellipsoid substitutions check the
central coefficients and angular antiderivative. The helper completed
successfully; its entire log was read. There were no failed runs of this
new helper. These finite/symbolic controls do not prove the analytical
limits in the argument above and are not claimed to do so.

The root report and receipt should accompany publication. No source
repair is requested. Recheck any changed mathematics, normalization,
dependency, or limit order; formatting/link substitutions alone need a
source-map refresh. No Lean verification of this flux analysis is claimed.
No editable prompt files, audit verdicts, or primitive declarations were
changed by this review.
