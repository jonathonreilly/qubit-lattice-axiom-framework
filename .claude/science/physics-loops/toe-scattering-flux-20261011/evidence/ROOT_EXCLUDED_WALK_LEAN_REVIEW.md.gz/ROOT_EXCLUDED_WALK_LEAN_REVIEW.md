# Root statement and evidence review of scoped Lean algebra

2026-10-11. The complete 202-line RankOneScattering.lean source at
2f5260a23eecc90c6bf3fabe9e26c4c05a5595fa151b98010097a7ee501b22ae
was read against the rank-one scattering identities used in the excluded-walk
source. The inner product is linear in its second entry. Vector and phase
normalization, self-adjointness, cap idempotence, and disjointness are explicit
where needed. The no-normalization observable expansion is algebraically
valid: the phase-defect term contains the centered mean, not a hidden unit
vector premise. The normalized cap transfer keeps both cap weights.
The coherent theorem uses the +i relative phase and gives +sigma Im(s).
A sign reversal must change that state or sigma; it is not an extra theorem
silently inferred with unchanged data.

The final normal Lake/Lean command, source snapshot and complete successful
compiler log were read. All ten requested axiom reports have only propext,
Classical.choice and Quot.sound. The current seven control sources and their
complete logs were read: the three positive scalar boundary witnesses
compile, while the six intended false statements reach mathematical failures.
Failure to close a false general goal is supplementary evidence, not a
completeness test of tactics. The true compiled statements are the certificate.
The compile and control harnesses use ordinary task-local runtime invocations;
there is no trusted skip-kernel flag or replacement axiom in the source.

All 67 artifact hashes in receipt.json were independently checked. The pinned
relevant Mathlib source hashes and the three runtime binary hashes also match.
The official runtime archive verification recorded by the author is retained;
root did not download it again. Source inspection of the full Mathlib dependency
closure is not claimed. Old failed developments are bound as historical
evidence, not mistaken for successful proofs. The original SCOPED_OBLIGATIONS
file is a pre-compilation planning record; SCOPE_REPORT and the final compiler
receipt give the completed state.

No consequential statement-mapping defect was found. The physical identification
of S, its threshold expansion, continuum coarea law, finite-time wave-operator
estimates and actual walk dynamics remain separate analytic obligations. This
review verifies the scope of the algebra certificate and its recorded execution;
it neither applies an audit verdict nor certifies those analytic theorems in Lean.
No editable prompt, shared repository source or audit state changed.
