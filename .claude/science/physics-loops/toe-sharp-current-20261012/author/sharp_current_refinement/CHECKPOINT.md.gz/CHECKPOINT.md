# Current sharp-current checkpoint

Complete author pure-proof proposal frozen 2026-10-12T14:45:12.524095Z.
Main source: ../SHARP_CURRENT_REFINEMENT_PROBE.md, SHA-256
2a6948ab1d98584ac77b3486f8ec1927d88fbb55cd0276123b6c24750f9d6a42.
Frozen copy is byte-identical. There are no pending author calculations.
Campaign hard stop remains 2026-10-12T16:00:52Z.

The exact minimum is P[sqrt(1-b²P²/4)-sqrt(1-a²P²/4)] over all complex
linear isometries preserving the supplied coefficient energy, and over
their real subclass. A single real signed-momentum map attains every
band minimum. The norm invariant supplies the lower bound without a
momentum-diagonal or state condition. Endpoint packets are genuine L2
vectors. The primitive-current normalization was checked directly from
the actual density; it was not inferred from dispersion alone.

The coefficient defect is injective but not bounded below. Full-band
minimum is 2sqrt(1-r²)/a for b=ra. Fixed-r moving-band error tends to
zero iff P=o(a^(-2/3)); explicit remainder and full-domain bounds are
in Q23–Q25. The even-CAR result is a separately proved upper bound for
the attaining map, fixed word length and bounded normalized-current time.
No even-algebra lower bound or finite position support is asserted.

Six exact sources/briefs are copied and pinned. The energy-adapted parent
remains provisional; only its proposed map is reused and proved again.
Instruction revision72a7cf00adf0756a215a247d344df21d06a1d582 was refreshed
read-only and matched previous full reads. Root subsequently reported
main92b59cd4600153221926a88146f66ebcb9a81791 with unchanged instructions;
no fetch or Git mutation was performed. Other interacting/additive-charge
work remains outside this lane and supplies no premise.

No scientific executable ran. No numerical PASS rows, INNER/OUTER scientific
receipts or Lean results are claimed. Plan chronology is clarified in its
separate preserved correction. The N1 five-family packet and N5 runner
certificate are not satisfied; there is no no-go packet PASS. These are
procedural limits separate from the authored theorem's mathematical claim.

Next action: root-arranged fresh independent proof review on this exact
hash, especially actual current normalization, the unrestricted lower
bound, real attainment, endpoint essential suprema and window constants.
Any publication or retained audit disposition remains outside this worker.
No editable prompt files, physical axioms, Git state or audit verdicts changed.
