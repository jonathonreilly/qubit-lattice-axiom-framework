# Neutral proof plan

Recorded before this worker's new derivation. The root-authored route brief
is a candidate, not evidence. The task concerns the actual supplied free
massive chain at m,v>0 and 0<b<a, with all linear isometries intertwining
the bounded actual energy operators; no decomposability or state condition
will be inserted into the lower-bound class.

1. Pin and inspect actual D and primitive-current normalization. Check the
   proposed polynomial square identity directly from those symbols.
2. Test whether energy intertwining forces the norm of the fine current
   on each embedded vector. If it does, obtain a lower bound using actual
   coarse spectral packets, including endpoint essential spectra. If it
   does not, preserve the failed identity and an admissible counterexample.
3. Independently check an attaining isometry, its Jacobian and complex and
   real admissibility. The energy-adapted parent's review is provisional;
   reproduce only the necessary proof rather than import its acceptance.
4. Determine the sharp band-restricted supremum, monotonicity, fixed-band
   asymptotics with an explicit uniform remainder domain, and full-band
   behavior. Keep equality/zero-mode and out-of-domain cases distinct.
5. Check the proposed exact-current defect identity separately. Do not
   infer an even-CAR flow theorem from a coefficient norm without proof.
6. Write a complete source-bound theorem or counterexample and honest
   N1–N8 scope analysis. A five-family packet PASS is not a success target.
   Request root's independent proof review after the analytic freeze.

This is initially a pure proof task. No numerical or symbolic scientific
process is planned. Bookkeeping hashes, source copies and syntax-free text
inventories are not mathematical evidence. If a decisive computation is
later needed, freeze a separate source/protocol before executing it with
full bounded INNER/OUTER records; preserve all failures and survivors.

Acceptance means a correct proof for an explicit class, or an exact
counterexample/refuted premise, after fresh independent checking. Author
completion alone supplies provisional conditional support, never retained
audit status. No prompts, axioms, Git state or publication is changed.
