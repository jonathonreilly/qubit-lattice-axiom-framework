# Sharp-current pure-proof packet

The complete author theorem proposal is ../SHARP_CURRENT_REFINEMENT_PROBE.md.
Its frozen SHA-256 is
2a6948ab1d98584ac77b3486f8ec1927d88fbb55cd0276123b6c24750f9d6a42.
The freeze occurred at 2026-10-12T14:45:12.524095Z. The live note and
frozen/SHARP_CURRENT_REFINEMENT_PROBE.md are identical. Fresh independent
proof review and any formal audit are open at this author seal.

Q19 gives the exact minimum of the actual normalized-current defect over
all complex linear exact-energy isometries, and the same minimum over the
position-real subclass. Q4 rederives the actual current sign and factor
from the supplied spin density. Q8–Q12 give the universal lower bound
without decomposability. Q13–Q17 give a real attaining map with its full
endpoint Jacobian. The current identity, injective but noncoercive defect,
full-band value, uniform remainder and growing-window criterion are
Q20–Q25. Q26–Q28 separately prove only a current-flow/even-word upper bound.

This is a pure proof. There are no mathematical executable runs, numerical
PASS counts, scientific process receipts or author helper reruns. None is
manufactured to make the packet look more empirical. Ordinary file copies,
hashes and phrase scans are bookkeeping. Independent scrutiny should read
the proof and actual source assumptions, not treat those hashes as proof.

source_inventory.json pins six parent/context/brief files, with complete
copies in sources/. The provisional energy parent is used only as a
candidate for the upper map, whose necessary proof is rederived. The
current theorem does not depend on acceptance of that parent's continuum
net or boost conclusions. parent_final_refresh.json verifies current and
copied source hashes. instruction_refresh.json binds six instruction files
to exact revision72a7cf00adf0756a215a247d344df21d06a1d582, unchanged from
earlier fully read campaign instructions.

PLAN.md and plan_freeze.json preserve the original plan. See
PLAN_CHRONOLOGY_CLARIFICATION.md for the precise distinction between a
plan written before the complete proof and a blinded/prereasoning plan.
Neither the plan nor this author packet is an independent review.

PROOF_MAP.md gives the author claim/dependency map for navigation.
NO_GO_LEDGER.md records the unmet five-family packet quota and absence of
a runner certificate. The main note's N1–N8 scope record is not a packet
PASS. Boundary cases, near-zero packets, a changed-current exact remedy
and the absence of an even-flow lower bound remain explicit.

CHECKPOINT.md is the current recovery state. final_manifest.json and
final_receipt.json seal the packet. No editable prompts, physical axioms,
audit verdicts, Git state, publication surfaces or other workers' files
were changed.
