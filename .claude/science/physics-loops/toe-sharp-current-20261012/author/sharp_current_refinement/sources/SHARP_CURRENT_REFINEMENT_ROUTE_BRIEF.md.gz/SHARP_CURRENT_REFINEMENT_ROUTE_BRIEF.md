# Sharp current error under exact energy refinement: provisional route

Root-authored candidate question, 2026-10-12. Deadline for all campaign research
is 16:00:52 UTC. Aim for a reviewable analytic core by 14:55; do not shorten
proof obligations to meet that target. A counterexample is a valid result.

Use the actual chosen infinite-chain coefficient energy D_a and normalized
primitive current K_a from the exact concrete-chain and continuum parents.
Keep m,v>0 and 0<b<a. The new energy-adapted source at
65d49c82eb14b88e4880983eb8b41ecb5141cb0ff00f4e5e4760bbb12a151b9d
is provisional and under independent review. Its map may supply an upper-bound
witness only after its assumptions are checked. Do not import acceptance.

Question: among *all* linear isometries G from the coarse to fine coefficient
space satisfying D_b G=G D_a, what is the smallest operator-norm error in
K_b G-G K_a, including its restriction to a coarse low-energy spectral band?
Do not assume translation covariance, decomposability, sign-preserving
momentum matching or quasifree state preservation in the lower bound. Distinguish
complex from real isometries and identify an admissible real attaining map.
This is a sharp approximation theorem for a supplied free scaling family;
it does not answer whether arbitrary physical coarse graining is possible.

## Root candidate calculation: unverified, may be refuted

Let R_a=D_a^2-m^2 I. Actual lattice symbols suggest

    K_a^2=R_a/v^2-a^2 R_a^2/(4v^4).

Exact energy intertwining and isometry might therefore force

    ||K_b G f||^2=<f,(R_a/v^2-b^2 R_a^2/(4v^4))f>.

For packets spectrally concentrating near p0=sqrt(R_a)/v, reverse norm
triangle suggests a universal lower bound kappa_b(p0)-kappa_a(p0), where
kappa_c(p)=p sqrt(1-c^2 p^2/4). Prove that the required packets exist in
the actual coarse Hilbert space; point spectrum must not be assumed.

Candidate sharp answer for 0<P<=2/a, Q_P=1_{sqrt(R_a)/v<=P}:

    inf_G ||(K_b G-G K_a)Q_P||
       =delta_ab(P)=P(sqrt(1-b^2P^2/4)-sqrt(1-a^2P^2/4)).

The proposed energy-adapted map aligns signed p and might attain the bound.
Check strict monotonicity in p and endpoint essential suprema, reality,
all operator domains (D_a,K_a are bounded at fixed a), and the exact physical
normalization of K. For b=r a, the candidate fixed-P asymptotic is
(1-r^2)a^2 P^3/8, whereas the full band is 2 sqrt(1-r^2)/a. An asymptotic
remainder needs a uniform domain if it is claimed.

Possible exact-current consequence: for X=K_bG-GK_a,

    K_b X+X K_a=(a^2-b^2)G R_a^2/(4v^4).

Treat this as a separate proposed identity to verify, not an expected PASS.
Do not promote a one-particle norm statement into an even-CAR flow theorem
without a separate proof; global scalar phases can disappear on even sectors.

## Scope, escapes and evidence

Consider b=a, v=0, p=0 null sets versus finite periodic zero modes, approximate
energy preservation, general nonisometric channels, interactions and changed
currents. These lie in different classes; an escape outside the stated theorem
does not disprove it, and this theorem does not close those physical routes.
Do not call all possible refinements impossible.

Use a neutral frozen plan and exact proof first. If numerical diagnostics add
something decisive, freeze sources and thresholds before execution, retain all
rows, controls and survivors, use bounded process-group receipts. A pure proof
may receive an independent proof check without invented numerical evidence.
No new Lean result is required or implied; identify a useful finite-algebra
obligation if it warrants formalization in a subsequent audit.

Apply current no-go-discipline before shipping any negative consequence. Read
the exact main revision 72a7cf00adf0756a215a247d344df21d06a1d582 skill and
proof-search governance; root checked installed skill matches SHA
9020ba5c2797d8f026ddb72871b13f18a18cad4e0ec326c0f4653ceb438751bc.
Do not fabricate five approach families or a packet PASS. If the procedural
quota cannot honestly be met, record that limitation and narrow the claim,
separately from its mathematical validity. Preserve all counterexamples.

Deliver one source-bound theorem note SHARP_CURRENT_REFINEMENT_PROBE.md with
evidence/recovery under sharp_current_refinement/. Write incrementally. Own
only these paths; no Git, worktree, publication, audit, axioms or prompts.
Root owns integration and publication. Keep selected model/effort. Fresh
independent review is required before publication or extensive downstream use.
