# Sharp-current refinement source gate and publication disposition

Source gate: OPEN for a regular review proposal with explicit partial-narrowing
disposition. The source-bound ordinary proof and independent reconstruction
support the exact conditional minimum, its real attainer, the fixed-r growing
spectral-window criterion and fixed-even-word upper bound. No mathematical
source correction is requested. This is not a retained audit or completed
negative-claim submission. Exact coverage is in
Sharp_current_refinement_root_review_coverage.json.

The minimum ranges over all complex-linear exact-energy isometries, without
assumed translation covariance or fiber decomposability. Root reconstructed
the invariant proof and checked the reviewer's separate spectral-multiplicity
argument. The same real coordinate map attains every band. The proof depends
on the supplied actual-current normalization and even-spin identification;
the coordinate attainer is proved here, without importing the energy-adapted
continuum theorem. No numerical or Lean scientific process is claimed.

The no-go-discipline SKILL.md requires five real route families for packet
PASS; this proof has no such packet. Its FAIL path permits a partial-narrowing
proposal with remaining alternatives queued. Use that limited disposition:
preserve the exact proof and its scoped corollary as proposed mathematical
source, retain the explicit N1/N5 limitations, and do not label a no-go closed,
retained, submission-ready or mechanically passed. No validator threshold is
changed or waived. Approximate energy preservation, nonisometric maps, changed
currents, interacting models and other dimensions remain untested alternatives.

An identity/reconstruction support tool may be supplied for source traceability.
Its output must separate bookkeeping success from mathematical proof checking,
state that no scientific calculation was executed at each N5 resolution, and
retain the no-go packet's pending status. Do not manufacture numerical cases,
mutants, five families or mathematical PASS counts. The independent proof
review is evidence on its exact source, not an automatic audit verdict.

Publication must preserve the complete frozen 456-line source, author plan
chronology correction, independent neutral plan and sealed findings, full final
review and all source identities. Root is a coauthor; review used a separate
context of the same selected model and effort. No blind/model-diverse claim.
Do not promote coefficient lower bounds to even-algebra lower bounds or
fixed-word estimates to a full-algebra unit-ball bound. Repository source/graph
checks, final regular-PR verification, combined landing validation and retained
audit remain distinct. No physical axiom, prompt or audit verdict changes.
