from pathlib import Path
from datetime import datetime, timezone
import json, hashlib

S = Path(__file__).resolve().parent
R = S / 'sharp_current_refinement_review'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
anchors = {
    'SHARP_CURRENT_REFINEMENT_PROBE.md': '2a6948ab1d98584ac77b3486f8ec1927d88fbb55cd0276123b6c24750f9d6a42',
    'SHARP_CURRENT_REFINEMENT_REVIEW.md': '158995f5f225fe7654aa842a03108566c5d72d7a916e799d8b28089f8499d30d',
    'sharp_current_refinement/final_manifest.json': 'd704de97de804fa72b4968c1f8bab0197f5b2df3bdadc2d2204f67d2c3565433',
    'sharp_current_refinement_review/manifest.json': '89bcad3ab8eb9e6597f76778159ffd12ae2987138989e6a016ba60bd75d8b9cc',
    'sharp_current_refinement_review/INDEPENDENT_FINDINGS_SEALED.md': '99c9fd5076ea2be51809884486f0b76400d632749295d29ea2079eeb708ec4d2',
    'sharp_current_refinement_review/PACKET_RECONCILIATION.json': '4427274eefc2e6dd52407be9d96b664cf5a90c5c956f5bb84f87750bd18dd66d',
}
for p,h in anchors.items():
    assert sha(S/p) == h, p
a = json.loads((S/'sharp_current_refinement/final_manifest.json').read_text())
for p,h in a['files'].items():
    assert sha(p) == h, p
assert len(a['files']) == 31
for row in json.loads((S/'sharp_current_refinement/parent_final_refresh.json').read_text())['rows']:
    assert sha(row['source']) == sha(row['copy']) == row['sha256'], row
m = json.loads((R/'manifest.json').read_text())
for row in m['source_reads'] + m['author_packet_reads']:
    assert sha(row['source']) == sha(row['snapshot']) == row['sha256'], row
for row in m['post_seal_source_coverage'].values():
    if 'source' in row:
        assert sha(row['source']) == sha(row['snapshot']) == row['sha256'], row
for row in m['final_source_refresh']['rows']:
    assert sha(row['path']) == row['sha256'] == row['expected_sha256'], row
for k in ['plan','sealed_findings','final_review']:
    assert sha(m[k]['path']) == m[k]['sha256'], k
f = json.loads((R/'FINAL_RECEIPT.json').read_text())
for field,name in [('review_sha256','../SHARP_CURRENT_REFINEMENT_REVIEW.md'),('manifest_sha256','manifest.json'),('plan_sha256','FROZEN_PLAN.md'),('independent_findings_sha256','INDEPENDENT_FINDINGS_SEALED.md'),('packet_reconciliation_sha256','PACKET_RECONCILIATION.json'),('checkpoint_sha256','CHECKPOINT.md')]:
    assert sha(R/name) == f[field], field
review_files = {str(p.relative_to(S)):sha(p) for p in R.rglob('*') if p.is_file()}
coverage = {
    'utc':datetime.now(timezone.utc).isoformat(),
    'status':'complete_source_bound_root_proof_review', 'anchors':anchors,
    'author_manifest_files':31, 'parent_source_pairs':6,
    'review_sources_and_snapshots_checked':len(m['source_reads'])+len(m['author_packet_reads'])+1,
    'final_source_refresh_rows':4, 'review_files':review_files,
    'complete_manual_read':[
        'All 456 target lines, author scope/chronology/plan clarification and necessary exact parent premises.',
        'Full frozen reviewer plan, complete sealed independent proof findings, final review and source/chronology qualifications.',
        'Direct Pauli/JW current factors, polynomial norm invariant, genuine near-endpoint L2 packets, real complexification and coordinate attainer.',
        'Independent spectral multiplicity proof: energy functional calculus forces measurable two-channel unitaries; pointwise traceless-matrix norm checks unrestricted quantifier.',
        'Essential supremum, injectivity without uniform lower bound, asymptotic remainder constant and a^(-2/3) transition, Duhamel sign and fixed even-word upper estimate.',
    ],
    'scientific_executables_run':0,
    'mathematical_disposition':'The exact conditional minimum, real attainment, fixed-r growing-band criterion and fixed-even-word upper estimate are supported by ordinary checked proofs.',
    'publication_disposition':'Regular review proposal under the skill permitted partial-narrowing path; no negative-claim packet PASS or retained closure.',
    'limits':[
        'Root coauthor. Separate same-family reviewer used a neutral plan before target exposure and sealed findings before author packet exposure; not a blind or diverse-family result.',
        'No five-family N1 completion, scientific N5 execution, numerical proof certificate or Lean theorem. Identity checks establish provenance only.',
        'Exact actual-energy complex-linear coefficient isometries in one supplied 1D massive free model; finite spacing and fixed ratio hypotheses explicit.',
        'No uniqueness, finite spatial locality, even-algebra lower bound, arbitrary-growing-word estimate, finite-volume, interacting, higher-dimensional or empirical theorem.',
        'Actual even-spin/current identification is inherited at exact supplied-parent scope; no whole dependency-chain retained audit.',
        'Approximate-energy maps, nonisometric channels and altered current observables remain open alternatives and are queued, not called failed approaches.',
    ],
    'pending_mathematical_corrections':[],
    'pending_publication_checks':['Final pure-proof package, identity-only support execution, exact graph/source preservation and regular PR verification.'],
    'no_go_packet_pass':False, 'audit_verdict_applied':False,
    'editable_prompt_files_changed':[],
}
cp=S/'Sharp_current_refinement_root_review_coverage.json';assert not cp.exists()
cp.write_text(json.dumps(coverage,indent=2)+'\n')
gp=S/'SHARP_CURRENT_REFINEMENT_MILESTONE_GATE.md';assert not gp.exists()
gp.write_text('''# Sharp-current refinement source gate and publication disposition

Source gate: OPEN for a regular review proposal with explicit partial-narrowing
disposition. The source-bound ordinary proof and independent reconstruction
support the exact conditional minimum, its real attainer, the fixed-r growing
spectral-window criterion and fixed-even-word upper bound. No mathematical
source correction is requested. This is not a retained audit or completed
negative-claim submission. Exact coverage is in
Sharp_current_refinement_root_review_coverage.json.

The minimum ranges over all complex-linear exact-energy isometries, without
assumed translation covariance or fiber decomposability. Root reconstructed
the invariant proof and checked the reviewer's separate spectral-multiplicity
argument. The same real coordinate map attains every band. The proof depends
on the supplied actual-current normalization and even-spin identification;
the coordinate attainer is proved here, without importing the energy-adapted
continuum theorem. No numerical or Lean scientific process is claimed.

The no-go-discipline SKILL.md requires five real route families for packet
PASS; this proof has no such packet. Its FAIL path permits a partial-narrowing
proposal with remaining alternatives queued. Use that limited disposition:
preserve the exact proof and its scoped corollary as proposed mathematical
source, retain the explicit N1/N5 limitations, and do not label a no-go closed,
retained, submission-ready or mechanically passed. No validator threshold is
changed or waived. Approximate energy preservation, nonisometric maps, changed
currents, interacting models and other dimensions remain untested alternatives.

An identity/reconstruction support tool may be supplied for source traceability.
Its output must separate bookkeeping success from mathematical proof checking,
state that no scientific calculation was executed at each N5 resolution, and
retain the no-go packet's pending status. Do not manufacture numerical cases,
mutants, five families or mathematical PASS counts. The independent proof
review is evidence on its exact source, not an automatic audit verdict.

Publication must preserve the complete frozen 456-line source, author plan
chronology correction, independent neutral plan and sealed findings, full final
review and all source identities. Root is a coauthor; review used a separate
context of the same selected model and effort. No blind/model-diverse claim.
Do not promote coefficient lower bounds to even-algebra lower bounds or
fixed-word estimates to a full-algebra unit-ball bound. Repository source/graph
checks, final regular-PR verification, combined landing validation and retained
audit remain distinct. No physical axiom, prompt or audit verdict changes.
''')
print(json.dumps({'source_gate':'OPEN','publication_disposition':'partial-narrowing regular review proposal','review_files':len(review_files),'coverage_sha256':sha(cp),'gate_sha256':sha(gp),'no_go_packet_pass':False}))
