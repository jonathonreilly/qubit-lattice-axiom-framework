# Frozen neutral proof reconstruction and adversarial plan

Status: written before opening the target, its author packet, helper, result, chronology clarification, late appendix, or root derivation brief. This plan uses only the neutral task question and provided source identities.

## Question and admissible objects

Determine, for the stated massive one-dimensional free chain, the infimum of the coefficient-space operator norm defect for normalized primitive-current intertwining, over every linear isometry that exactly intertwines the actual energy on a specified coarse spectral band. Do not add locality, translation covariance, fiber decomposability, complex linearity, or a chosen energy parametrization unless those are explicit premises or follow from the operator relation. Establish the field (real/complex), domains, band measure, endpoints, and multiplicities before using a spectral theorem.

## Independent reconstruction order

1. Read applicable instructions and freeze complete byte identities of the target and necessary parent sources. Derive the energy and primitive current directly from the concrete chain definitions, including signs, factors, real structure, and the normalization used at each lattice scale.
2. State the optimization with every quantifier: source and target Hilbert spaces, isometry class, exact energy equality, current domain, norm, source band, and whether the infimum is attained. Handle trivial/null bands, open/closed endpoints, and target threshold or band-edge degeneracies.
3. Derive the spectral representation without selecting a special refinement map. Prove which spectral supports and multiplicity channels any energy intertwiner must preserve. Check whether exact energy intertwining itself implies the decomposability needed by an eventual lower bound.
4. Prove an operator-norm lower bound for arbitrary admissible isometries using spectral localization or another valid general argument. Test mixing within all energy-degenerate channels and, if relevant, real-linear maps that are not complex-linear. Separately construct an admissible map and verify its normalization, reality, energy equality, and defect.
5. Check the candidate formula and attainment only after the independent mechanism is clear. Inspect pointwise versus essential supremum distinctions and the exact hypotheses needed to turn local spectral estimates into a uniform optimum.
6. Derive any fixed-band and growing-band asymptotics with uniform remainder control. Probe cutoff rates near the available fine spectral edge and distinguish convergence, a positive limiting gap, and divergent defects.
7. Check transfer to current-generated time evolution and even CAR observables. Distinguish generator defect, fixed-time propagator bounds, uniform-time claims, full versus even algebra, and faithful norm witnesses. Record what does and does not follow.

## Adversarial routes

- Energy degeneracy and arbitrary measurable mixing, including non-translation-covariant intertwiners.
- Real versus complex coefficient spaces and anti-linear or sign-channel loopholes.
- Spectral thresholds, null endpoints, partial ranges, Jacobian singularities, and isometry onto a proper spectral subspace.
- Band choices and scale-dependent concentration that defeat unjustified uniform asymptotics.
- Exponentiation, periodic aliasing, and loss of information on the even CAR algebra.

These are candidate adversarial routes, not a pre-certified five-family N1 completion. Count only routes actually analyzed, and do not turn a bounded optimum into a universal no-go.

## Evidence discipline and seal

Use independent proof and explicit counterexamples. No numerical runner is planned; if computation becomes genuinely useful, first freeze a separate protocol and exact code/source identities, and retain full outputs. Parent energy-adapted work is provisional and will not be assumed accepted. Seal the independent findings before reading any author packet, chronology note, late appendix, or root derivation brief. Then compare the final source and its source-bound packet, marking any changed dependencies or unresolved gaps. No retained verdict, publication, audit, axiom, prompt, Git, or worktree mutation is authorized here.
