# Sealed independent proof findings

This document is the independent mathematical checkpoint before opening any author evidence packet, root derivation brief, chronology clarification, or late appendix. The complete target source was visible, including its proposed formula and proof; this is an adversarial proof check, not a blind prediction. A neutral plan was frozen before that source was opened. The reviewer retained the inherited model and reasoning effort and used no numerical or symbolic scientific runner.

## Source scope and conclusion

The target is `SHARP_CURRENT_REFINEMENT_PROBE.md`, SHA256 `2a6948ab1d98584ac77b3486f8ec1927d88fbb55cd0276123b6c24750f9d6a42`, all 456 lines. Necessary passages of Concrete at `0aebc2ded245d9bc9ecae364db0d1a042f9642771ed788794dafd73fb7f621bd` and the provisional Energy-adapted source at `65d49c82eb14b88e4880983eb8b41ecb5141cb0ff00f4e5e4760bbb12a151b9d` were read; exact ranges are in `manifest.json`. No acceptance of the provisional parent was assumed. Its candidate map is checked from its displayed factors here.

No material mathematical error was found in Q1–Q28 under the stated supplied-model hypotheses. The exact minimum is

    δ(a,b;P) = P[√(1−b²P²/4) − √(1−a²P²/4)],
    m,v>0, 0<b<a, 0<P≤2/a.

It holds over all complex-linear isometries of the entire coefficient spaces satisfying `D_b G = G D_a`; the position-real subclass has the same minimum, attained by one map for every P. The word “linear” here has the target's explicit complex-linear meaning. A physical real-linear map between the position-real coefficient spaces is represented by its unique complexification; the target does not purport to classify arbitrary real-linear maps of the full complex Hilbert spaces viewed only as real spaces.

The negative exact-current corollary is confined to this model, these two different spacings, this normalization and this exact-energy isometry class. The no-go packet does not satisfy the five-family schema; mathematical validity is not a packet PASS or a retained verdict.

## 1. Actual current, sign and normalization

For `h_j=−J X_jX_(j+1)−(g/2)(Z_j+Z_(j+1))`, direct Pauli multiplication gives

    [h_0,h_1] = iJg(Y_1X_2 − X_0Y_1),
    [h_0,h_(−1)] = iJg(X_(−1)Y_0 − Y_0X_1).

Thus the primitive moment current `p_0=(i/2)([h_0,h_1]−[h_0,h_(−1)])` is the four-term density in Concrete C3. Summing its translates in a local derivation gives the representative `Jg(X_jY_(j+1)−Y_jX_(j+1))`; equality of the literal local densities is not needed or asserted.

The finite even-JW identities give `X_jY_(j+1)=−i b_jb_(j+1)` and `Y_jX_(j+1)=i a_ja_(j+1)`. Hence the quadratic current is `−iJg Σ_j(a_ja_(j+1)+b_jb_(j+1))`. In the convention `(i/4)γ^T Aγ`, its oriented entries are `A_(j,j+1)=−2Jg`. Therefore

    (iAf)_j = 2iJg(f_(j−1)−f_(j+1)),
    L_c(iA)L_c* = 4Jg sin(cq) I.

The negative-exponent Fourier transform in Q2 fixes the displayed positive sine sign. The onsite term `ig a_jb_j` and bond term `iJ b_ja_(j+1)` likewise give the exact off-diagonal energy matrix Q3, independently of differentiation of a dispersion.

For the given couplings, `4J_cg_c = σ_c²−m²/4 = v²/c²`. Consequently `(c/v²)P_actual,c = sin(cq)/c`, precisely Q4. Removing the `1/c` or replacing sine by the geometric momentum would change the problem. Squaring the actual energy matrix gives `D_c²=m²+4v² sin²(cq/2)/c²`.

The coefficient flow convention is consistent: the field column satisfies `i[Q,γ]=Aγ`, while a smeared coefficient evolves by `e^(−tA)=e^(+it iA)`. This fixes the `+itK_c` in the current-flow statement.

## 2. Direct norm invariant and packets

Set `A_c=(D_c²−m²I)/v²`. It is a nonnegative bounded operator and

    K_c² = A_c − (c²/4)A_c².

For every admissible G, polynomial intertwining gives `A_bG=GA_a`, without a choice of spectral coordinates or decomposability. Isometry and self-adjointness then give, for every f,

    ∥K_bGf∥² = ⟨f,[A_a−(b²/4)A_a²]f⟩,
    ∥GK_af∥² = ⟨f,[A_a−(a²/4)A_a²]f⟩.

Take unit packets whose Fourier support is `q_a(P−ε)<q<q_a(P)`, with either coefficient component fixed. This interval has positive finite measure for every `0<ε<P`, also when `P=2/a` and its right endpoint is approached from below. The spectral variable `ρ=√A_a` on those packets lies in `(P−ε,P)`. Both continuous functions `κ_c(ρ)=ρ√(1−c²ρ²/4)` therefore have norm limits `κ_c(P)`. The reverse triangle inequality proves

    ∥(K_bG−GK_a)Q_P∥ ≥ κ_b(P)−κ_a(P).

This is an actual sequence of Hilbert-space unit vectors, not a delta-normalized endpoint mode. It remains valid when κ_a decreases near the coarse edge, because localization uses continuity rather than monotonicity of κ_a.

For real G, `Γ_c K_c Γ_c=−K_c` and `Q_PΓ_a=Γ_aQ_P`. Hence `i(K_bG−GK_a)Q_P` is a bounded real map's complexification, whose complex norm equals its real norm by writing `f=u+iv`. Reflection-paired versions of the packets give the same bound directly on real coefficients. No factor is lost by passing between these norms.

## 3. Independent multiplicity check of the unrestricted quantifier

This second reconstruction checks the full class of energy intertwiners rather than assuming that G acts at one signed momentum at a time.

The change of variables `p=2 sin(cq/2)/c` has `dq=dp/w_c(p)`, with `w_c=√(1−c²p²/4)`. Therefore `U_ch=w_c^(−1/2)h(q_c(p))` is unitary from `L²(B_c,dq)` to `L²(I_c,dp)`. Its inverse is `√p_c'(q) ψ(p_c(q))`. These identities first hold on compactly supported continuous functions and extend both ways by density. The endpoint multiplier's divergence is allowed by the change of measure; no derivative domain is invoked.

The function `g_c−J_c e^(−icq)` stays in the open right half-plane because `g_c−J_c=m/2>0`. Its continuous argument θ_c is odd and periodic. With `F_c=diag(e^(−iθ_c/2),e^(+iθ_c/2))`, direct matrix multiplication gives

    F_cD_cF_c* = E_cC_0,
    T_cD_cT_c* = E(p)C_0,
    T_cK_cT_c* = p w_c(p)I,

where `T_c=U_cF_cL_c`, `C_0=[[0,i],[−i,0]]` and `E(p)=√(m²+v²p²)`.

Diagonalize C_0 once, using `v_+=(1,−i)/√2` and `v_−=overline(v_+)`. Split signed momentum as `p=±ρ`, `0<ρ<2/c`. At each positive ρ there are two momentum channels for each of the two energy signs. The energy is `sE(ρ)` on sign `s=±1`, while the current on its two momentum channels is `κ_c(ρ)Z`, with `Z=diag(1,−1)`.

For any exact energy intertwiner, bounded spectral functional calculus first forces its image into the fine spectral region `|p|<2/a` and prevents mixing positive and negative energies. Because `ρ↦E(ρ)` is strictly increasing on `(0,2/a)`, it then intertwines every bounded scalar multiplier `h(ρ)`. This consequence is sufficient to prove decomposability: on the finite interval `(0,2/a)`, each scalar matrix component S of the transformed G satisfies `S M_h=M_h S`; putting `u=S1` gives `Sh=hu` on bounded functions, boundedness gives `u∈L∞`, and density extends the identity to all L². Thus G is a measurable 2-by-2 multiplier `U_s(ρ)` on each energy sign. Isometry gives `U_s*U_s=I` almost everywhere, and equal finite multiplicities make U_s unitary. No translation hypothesis entered this deduction.

For each such unitary,

    ∥κ_b ZU_s−κ_a U_sZ∥
      = ∥κ_b Z−κ_a U_sZU_s*∥
      = √(κ_b²+κ_a²−2κ_bκ_a c_s),
    c_s = (1/2)Tr(ZU_sZU_s*) ∈ [−1,1].

The last identity follows because the Hermitian difference is traceless 2-by-2 and its squared eigenvalue is half its squared Hilbert–Schmidt norm. Therefore the pointwise defect is at least `κ_b−κ_a`, even for arbitrary measurable momentum-channel rotations. Momentum-preserving `U_s=I` attains it. This independently diagnoses the possible degeneracy loophole and recovers the same minimum after the essential supremum.

In these coordinates Γ conjugates coefficients and reverses both energy and momentum signs. Thus the real condition is `U_−=S overline(U_+) S`, where S swaps the two momentum channels. `U_+=U_−=I` satisfies it. This also confirms that imposing reality does not raise the minimum.

## 4. Attainment, essential supremum and exact-current corollary

With `i_(b,a)` extension by zero, `G_*=T_b* i_(b,a) T_a` is an isometry and exactly intertwines `E(p)C_0`, hence D. The odd coordinates, even weights and `F_c(−q)=overline(F_c(q))` make it position-real. Its current defect is multiplication, followed by extension, by

    d(p)=p[w_b(p)−w_a(p)].

For positive p the rationalization

    d(p)=(a²−b²)p³/[4(w_b(p)+w_a(p))]

has positive nonincreasing denominator, including at `p=2/a` because `b<a`. Thus d is continuous and strictly increasing on `[0,2/a]`. Every one-sided neighborhood of the band edge P has positive measure. Its essential supremum on `|p|≤P` is d(P), including the full band. The one G_* therefore attains all claimed minima. A finite-scale endpoint value of a representative does not affect the L² map or its norm.

Subtracting squared norms gives exactly

    ∥K_bGf∥²−∥GK_af∥² = ((a²−b²)/4)∥A_af∥².

The zero set of `A_a(q)=4 sin²(aq/2)/a²` is a Lebesgue null set. It follows that `(K_bG−GK_a)f≠0` for every nonzero f. This does not produce a positive lower singular bound: on `Ran Q_P`, both current norms are at most `P∥f∥`, so the defect is at most `2P∥f∥` for every G. Nonzero low-band vectors with P tending to zero give the counterexample to any such stronger claim.

The polynomial operator identity Q20 follows by expanding `K_bX+XK_a=K_b²G−GK_a²`; no commutation of G with K is assumed. Its formalization alone would not prove the L², realness, endpoint, or physical-identification steps.

## 5. Uniform asymptotics and endpoint cases

For `b=ra` with fixed `0<r<1`, write `x=a²P²/4`. Direct integration gives

    δ=P∫_(r²x)^x dt/(2√(1−t)).

On `x≤η²<1`, the derivative bound on `(1−t)^(−1/2)` gives the source's nonnegative remainder

    0≤δ−(1−r²)a²P³/8
      ≤(1−r²)a⁴P⁵/[64(1−η²)^(3/2)].

For example, integrating the sharper `t` bound yields coefficient `(1−r⁴)/128`, which is at most the displayed `(1−r²)/64`. The source constant is therefore valid, although not the smallest constant. This remainder is not used uniformly at the spectral edge.

Across the entire band, `√(1−r²)≤w_(ra)+w_a≤2` instead gives

    ((1−r²)/8)a²P³ ≤ δ ≤ (√(1−r²)/4)a²P³.

Hence for every allowed moving band, `δ→0` iff `a²P³→0` iff `P=o(a^(−2/3))`. At `P∼λa^(−2/3)` the remainder tends to zero and `δ→(1−r²)λ³/8`. At `P=2/a`, `δ=2√(1−r²)/a`. These conclusions require fixed r; a ratio tending to one is a different asymptotic problem.

The source correctly excludes `v=0`, where its normalization is undefined; it does not assert a massless extension. At `b=a`, identity gives zero defect. At `P=0`, the infinite-chain projection is zero. Finite periodic zero modes and possible empty exact-energy intertwiner classes are not covered. No unbounded-operator domain is present at fixed spacing in this theorem.

## 6. Current-time and even-CAR scope

Duhamel's formula for the bounded K operators, together with `K_aQ_P=Q_PK_a`, proves Q27 for G_* uniformly on `|t|≤T` with bound `Tδ`. Its sign matches the coefficient flow convention. As an additional direct check for this particular map, the exact coefficient propagator defect is

    2 sin(min(|t|δ/2, π/2)).

Indeed its multiplier's modulus is `2|sin(t d(p)/2)|`, and the continuous odd d ranges across the full interval `[−δ,δ]` in essential-supremum sense. This optional formula concerns G_* only; it is not a proof that G_* minimizes a fixed-time error among all G.

The groups `e^(itK_c)` preserve real coefficients because `Γ_cK_cΓ_c=−K_c`, with anti-linearity also conjugating i. For real f, `c(f)²=∥f∥²I`, so `∥c(f)∥=∥f∥`. The real isometry induces an isometric CAR map. Telescoping a product of d real fields therefore gives exactly

    d|t|δ ∏_j∥f_j∥

for even d and `f_j∈Ran Q_P`. Every summand has one controlled coefficient difference and norm-preserved other factors; a zero factor makes both words zero. The bound extends to specified finite linear combinations by summing their bounds. For fixed degree, bounded input-norm product and bounded time it vanishes under the growing-band criterion.

This is not a uniform norm estimate on the unit ball of the entire even algebra, a finite spatial support result, or an even-CAR lower bound. In general two real coefficient maps differing by a global sign induce the same action on all even words, so a coefficient norm lower bound alone cannot provide such an algebra lower bound. Within this actual model, proving any stronger flow lower bound would require its own analysis. The parent actual-current/even-spin identification is an explicitly inherited physical-algebraic input; the broader full-spin construction and parent continuum theorems were not re-audited here.

## 7. Adversarial and procedural disposition

The developed mathematical checks cover unrestricted measurable mixing at degenerate energies, real versus complex norm conventions, null threshold and edge modes, singular Jacobians, moving bands, current-clock normalization, and the loss of information on the even algebra. Those checks are not five independent proof families. The polynomial invariant and the additional multiplicity reconstruction cannot honestly be relabeled as a five-family N1 packet.

The source's N1 limitation is accurate. N2 asserts no independent wall count. N3's load-bearing hypotheses are explicit. N4 uses the parent for the actual current rather than an unrelated fixed-map obstruction. N5 separates individual vectors, spectral bands, full coefficient space and even algebra correctly. N6's replacement `K_tilde=p_c(q)` really is intertwined by G_* but changes the specified observable. N7's possible degenerate-channel escape is exhausted inside the stated class by the two proofs above. N8's campaign narrative is not used as evidence for the theorem and was not independently re-audited beyond the necessary supplied parent passages.

No theorem about general channels, approximate energy preservation, different currents, interactions, higher dimensions, finite volume, state selection, or TOE completion follows. No new framework premise or current identification has been adopted. No universal no-go, retained promotion, no-go packet PASS, Lean certification, computational PASS count, or publication decision is issued by this review.

Remaining work after this seal: inspect the author source-bound packet, chronology and any later appendix for provenance or source drift; refresh the final source identities; record any changes separately. The scientific conclusion above is tied to the three exact source hashes listed here.
