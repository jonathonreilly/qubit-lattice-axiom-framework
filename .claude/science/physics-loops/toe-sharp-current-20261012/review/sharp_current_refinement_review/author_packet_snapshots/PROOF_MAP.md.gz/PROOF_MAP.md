# Author proof map, not independent verification

| Claim | Load-bearing argument | Supplied input | Remaining check |
| --- | --- | --- | --- |
| Actual normalized current Q4 | C4 even-JW bilinear gives each A_(j,j+1)=-2Jg; Fourier iA=4Jg sin(cq); physical factor c/v² | Concrete C4,C14,C28 and Local Even L1 | Fresh check of primitive normalization and coefficient sign |
| Polynomial invariant Q7–Q9 | Double-angle identity, bounded energy powers, isometry and self-adjoint squared norms | Actual D and K symbols | Fresh check with no fiber/state condition inserted |
| Lower bound Q10–Q12 | Unit Fourier indicators in genuine positive-measure intervals approaching P; reverse norm triangle | Bilateral Lebesgue spectral realization | Endpoint and real-vector checks |
| Attainment Q13–Q19 | Full weighted coordinate unitary; explicit frame orientation; zero extension; monotone multiplier essential supremum | Actual frame from supplied D, rederived | Reality, Jacobian, endpoint and sharpness checks |
| Exact-current residual Q20–Q21 | Expand products; cancel mixed terms; injectivity of R by null zero set | Same bounded operator identities | Do not confuse injectivity with a uniform lower bound |
| Scales Q22–Q25 | Rationalization; integral remainder on aP/2<=eta<1; global fixed-r denominator bounds | No additional physical premise | Uniform constants and fixed-r quantifier |
| Current-flow bound Q26–Q28 | Bounded Duhamel and product telescoping; no lower-bound transfer | Supplied actual even flow and real CAR field norm | Check that only attaining-map upper estimates are claimed |

The useful possible formalization obligation is the bounded-algebra
cancellation Q20. It would not replace endpoint, spectrum, reality or
actual-spin checks. No Lean or theorem-prover result is claimed.

The prior failures in the dyadic and state-adapted notes are not lower-bound
witnesses here. They concern their particular Haar-based maps. The new
polynomial argument is what quantifies over all exact-energy isometries.
The changed multiplier K_tilde is an exact remedy for a different current;
it is preserved as a concrete escape outside the stated class.
