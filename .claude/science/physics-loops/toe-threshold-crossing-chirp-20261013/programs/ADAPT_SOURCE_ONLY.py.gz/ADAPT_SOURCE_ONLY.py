"""Deterministic source adaptation only; never executes proposed programs."""
from pathlib import Path
import ast, difflib, hashlib, json
Q=Path(__file__).resolve().parent
T=Q/'procedural_template'
R=Q.parent
A=R/'threshold_crossing_chirp_source_assembly'
BASE='af2e44428a10e59cf5eb7130df4265d2949db8df'
OLD='c5eaa6bf752a0893c83c0509c7c349dab53bff14'
SEAL='75a56964dd6cd3e83789f0da0638e4ad5101650f710d5c382fa7487573536d72'
ACCEPT='d661fb65f7117695697265cbc8e3659813151190d7eb7837d2afc3602a0b1fdb'
REVIEW='debdefb510071e12a35ffc2569261bbaa3ccbab638afeeac6e7b986fbcf9eed5'
ROOT='6a5fba2249be73609673ccacc05369af478d4c2adf5feb0d2752a683629183b4'
INDEP='0406c0e397b82a95159a77e47d093771e19f316c46f80c996ec2969ca082cea4'
def save(name,b):
 p=Q/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def replace(s,a,b):
 if a not in s:raise ValueError('missing exact template token '+a[:90])
 return s.replace(a,b)
s=(T/'prepare_verify_chirped_kinetic_energy.py').read_text()
for a,b in [
 ('chirped_kinetic_energy','threshold_crossing_chirp'),
 ('toe-chirped-kinetic-energy-20261013','toe-threshold-crossing-chirp-20261013'),
 ('chirped-kinetic-integrity-','threshold-crossing-chirp-integrity-'),
 (OLD,BASE),('chirped_kinetic_law_source_assembly','threshold_crossing_chirp_source_assembly'),
 ('fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38',SEAL),
 ('fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e',ACCEPT),
 ('3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134',REVIEW),
 ('CHIRPED_SOURCE_ASSEMBLY','THRESHOLD_SOURCE_ASSEMBLY'),
 ('CHIRPED_BRANCH_PLAN','THRESHOLD_BRANCH_PLAN'),
 ('physics-loop/toe-modulated-kinetic-energy-20261013','physics-loop/toe-chirped-kinetic-energy-20261013'),
 ('9517','9520'),("'edges':4","'edges':3"),("'edges': 4","'edges': 3"),
 ('four-edge','three-edge'),('root_independent_strength_and_phase_precision_reviewed','threshold_cancellations_and_finite_algebra_scope_reviewed')
]:s=replace(s,a,b)
start=s.index("    old = js(original_source / 'FINAL_FREEZE.json');")
end=s.index("    old_acceptance =",start)
extra={str(f.relative_to(A)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
 for f in A.rglob('*') if f.is_file() and str(f.relative_to(A)) not in {r['path'] for r in json.loads((A/'FINAL_FREEZE.json').read_text())['records']}}
assert len(extra)==6
block="""    old = js(original_source / 'FINAL_FREEZE.json'); members = {r['path'] for r in old['records']}
    extras = """+repr(extra)+"""
    need(len(members) == len(old['records']) == 104 and len(extras) == 6,
         'Accepted scoped records or additional membership differs')
    need(not any(p.is_symlink() for p in original_source.rglob('*')) and
        {str(p.relative_to(original_source)) for p in original_source.rglob('*') if p.is_file()}
        == members | set(extras), 'Accepted complete 110-file membership changed')
    for row in old['records']:
        need(pin(original_source / row['path']) == {k:row[k] for k in ['sha256','bytes']}, 'Accepted source changed')
    for name, expected in extras.items():
        need(pin(original_source/name) == expected, 'Additional accepted source identity changed')
"""
s=s[:start]+block+s[end:]
# Explicit body claim hint is required by the current graph parser.
needle="        front = yaml.safe_load(read(WORKTREE / row['path']).decode().split('---', 2)[1])"
s=replace(s,needle,needle+"\n        need('\\nClaim type: bounded_theorem\\n' in read(WORKTREE / row['path']).decode(), 'Standalone body claim type absent')")
ast.parse(s);save('prepare_verify_threshold_crossing_chirp.py',s)
c=(T/'run_combined_validation.py').read_text().replace('chirped_kinetic_energy_combined_validation_execution','threshold_crossing_chirp_combined_validation_execution')
ast.parse(c);save('run_combined_validation.py',c)
i=(T/'IDENTITY_TOOL.template.py').read_text()
for a,b in [('Chirped kinetic','Threshold-crossing chirp'),('toe-chirped-kinetic-energy-20261013','toe-threshold-crossing-chirp-20261013'),
 ('fdb082263fabac60eb6f19bce3a60b98c5bf5eb23fc0e0933dc9addae4978f38',SEAL),
 ('fe89af2e4a5d2ad6e8000ff676fe0280da337e71350271ee9bf39a823a57e78e',ACCEPT),
 ('3a79681c561a73831e7222167d823755ab89ed8de03df8d7b629a32d631aa134',REVIEW),
 ('87011c662344ed684a7251f5067bb8193d156837a50a23e71fa29ccff38e92f6',ROOT)]:
 i=replace(i,a,b)
i=replace(i,'279a96bc07b495a59b829cac70586ae8e115f0ddefca0d405bb15f0a7de6e95c',INDEP)
start=i.index("    seal = json.loads(source('FINAL_FREEZE.json'));")
end=i.index("    mapping = json.loads(source('SOURCE_MAP.json'));",start)
i=i[:start]+"""    seal = json.loads(source('FINAL_FREEZE.json')); members = contract['members']
    need(seal['records'] == members and len(members) == 104 and contract['all_files'] == 110,
         'Original scoped membership differs')
    extras = contract['additional_files']
    need(len(extras) == 6 and len({r['path'] for r in extras}) == 6, 'Additional membership differs')
    wanted = {prefix+r['path'] for r in members+extras}
    need({p for p in origins if p.startswith(prefix)} == wanted, 'Complete source package aliases differ')
    for r in members+extras:
        b = source(r['path'])
        need(sha(b) == r['sha256'] and len(b) == r['bytes'], 'Source member identity differs')
    closures = json.loads(source('IMMEDIATE_CLOSURES.json'))['closures']
    need(closures == evidence['source_provenance_closure'] and
         [len(c['bindings']) for c in closures] == [16,16,20], 'Immediate closure selection differs')
    for c in closures:
        source(c['freeze'])
        for row in c['bindings']:
            b=source(row['archive'])
            need(sha(b)==row['sha256'] and len(b)==row['bytes'] and archived(row['source'])==b,
                 'Immediate source/member binding differs')
    selection = json.loads(source('SOURCE_SELECTION.json'))['sources']
    need(len(selection) == 82, 'Original source selection differs')
    for row in selection:
        b = archived(row['source'])
        need(b == source(row['archive']) and sha(b) == row['sha256'] and len(b) == row['bytes'],
             'Original source alias differs')
        if row['lines'] is not None:
            need(len(b.splitlines()) == row['lines'], 'Original text line count differs')
""" +i[end:]
i=i.replace("== 4 and len(bindings['canonical_core_maps']) == 5","== 3 and len(bindings['canonical_core_maps']) == 4")
i=i.replace("{'nodes':1,'edges':4}","{'nodes':1,'edges':3}")
i=i.replace('CHIRPED_SOURCE_ASSEMBLY','THRESHOLD_SOURCE_ASSEMBLY')
i=i.replace("scope['source_freeze_sha256'] == SOURCE_FREEZE_SHA and scope['status'] == 'accepted_for_source_only_publication_preparation' and scope['publication_execution_authorized_by_this_receipt'] is False","scope['source_assembly_freeze_sha256'] == SOURCE_FREEZE_SHA and scope['status'] == 'accepted_for_source_integration' and status['publication_runtime_executed_by_source_preparer'] is False")
ast.parse(i);save('IDENTITY_TOOL.template.py',i)
mapping=[('prepare_verify_chirped_kinetic_energy.py','prepare_verify_threshold_crossing_chirp.py'),('run_combined_validation.py','run_combined_validation.py'),('IDENTITY_TOOL.template.py','IDENTITY_TOOL.template.py')]
rows=[]
for old,new in mapping:
 a=(T/old).read_bytes();b=(Q/new).read_bytes();d=b''.join(difflib.diff_bytes(difflib.unified_diff,a.splitlines(True),b.splitlines(True),fromfile=('template/'+old).encode(),tofile=new.encode(),n=3));name='program_diffs/'+new+'.diff';save(name,d)
 rows.append({'template':old,'program':new,'template_sha256':hashlib.sha256(a).hexdigest(),'program_sha256':hashlib.sha256(b).hexdigest(),'diff':name,'diff_sha256':hashlib.sha256(d).hexdigest(),'context_lines':3})
save('PROGRAM_DIFFS.json',json.dumps({'programs':rows,'execution':'not executed; AST parsing only'},indent=2)+'\n')
save('ASSEMBLY_MEMBERSHIP_PRECISION.json',json.dumps({'scoped_frozen_records':104,'complete_files':110,'additional_files':extra,'meaning':'four nested freeze/log files are indirectly bound by frozen SOURCE_SELECTION; preserve six additional files explicitly without changing accepted freeze','content_or_analytic_repair':False},indent=2)+'\n')
print(json.dumps({'adapted_programs':3,'assembly_complete_files':110,'program_diffs':rows},indent=2))

