# Independent source derivation

Scope: frozen original commit a7536ad7adf51510ba63f811f6ddae3826fc1dc7;
scientific author remains /root. This checker derives consequences of the
supplied candidate action, not its origin in framework axioms. The canonical
runner is not executed here before the parent's UNIT preflight.

## Contract and proof closure

Fix Q0,Hv,rho_unit,nu>0 and a compact set of finite real v,w,x,y,px,py,rhoJ,PJ
with rhoJ>=0. Let k decrease to zero through (0,1/3), u=k²v, pu=kw. Constants
in every absolute remainder may depend on that compact set and the fixed
positive constants. The target is coefficients and instantaneous constraints,
not a uniform-in-time family of solutions. An actual transverse solution limit
is an additional premise only for the limiting differential equation.

Write A=exp(sqrt(a)u), z=sA² and F=1+z. The Weyl kinetic combination is
(1-3az)/F+3az²/F²=[1+(1-3a)z]/F². Since
1-3a=(1-3k)²/4>0 and s>0, all three diagonal kinetic entries are strictly
positive for every finite field at 0<k<1/3; D>=1. This is not uniform strict
positivity as k approaches either endpoint.

After u=k²v, the coefficients are analytic in k near zero once their stated
powers of k are removed. The reciprocal 1+s can be eliminated without any
physical approximation: k(1-3k)(1+s)=1+2k-3k²=4a. The resulting denominators
approach 1 and D0>=1 uniformly on the compact set. Taylor's theorem with
bounded derivatives then supplies the claimed uniform remainders.

A direct expansion of the original V0+sV1 expression yields

 U = 3/2 + k(x²/2+y²/3)
     + k³[(v²/2-v)x²-(2v/3)y²] + O(k⁴).

This separately verifies the missing quadratic coefficient, rather than
inferring it from numerically small values. Differentiating in u at fixed k
is k^-2 differentiation in v, so

 Uu/k = vx²-x²-2y²/3+O(k),  k Uuu=x²+O(k).

The derivative remainders follow from smoothness of the same weighted
expression on a slightly larger compact v domain, not from differentiating an
uncontrolled generic O-symbol. K_u/k ->1/4, K_x/k ->4/(9D0),
K_y/k ->1/(3D0), alpha_B/k ->1/2, and C_B=1+k³v+O(k⁴).
Also U(0,x,y)=3/2+k(x²/2+y²/3) exactly.

## Action normalization and first Hubble correction

For S=Q integral sqrt(-g)[R/2-K_AB dphi^A dphi^B-2Hv²U]+Sm[C_B g],
the homogeneous scalar energy is Q Hhat² T+2QHv²U. The physical fluid energy
in the Einstein equation is C_B² rho_unit rhoJ. Thus

 (3-T) Hhat²/Hv²=2[U+C_B² R rhoJ],
 h=dln Hhat/dN=-T-C_B² R(rhoJ+PJ)/(Hhat²/Hv²),
 R=rho_unit/(2QHv²)=R0/(1+k).

This fixes both the potential factor two and fluid normalization. No prior
cosmological theorem or stored trajectory is needed. gJ=C_B g gives
H_J/Hhat=(1+alpha_B pu)/sqrt(C_B), since
alpha_B=(1/2)partial_u ln C_B.

T=k Tbar+O(k²), its u term is O(k³), and the physical clock factor differs
from unity at O(k²). Hence

 H_J²/Hv² = Hgr² + k[2(Vbar-sigma0)/3 + Hgr² Tbar/3] + O(k²),
 Hgr²=1+2sigma0/3 >=1.

The uniformly positive Hgr² permits division to obtain C1. For the stated
ideal values, Hgr²=D0, Tbar=(x²+4y²/3)/D0 and
2(Vbar-sigma0)=-x²-4y²/3, proving the cancellation. It neither selects an
initial condition nor extends automatically to a thermal state.

The separately assumed local weak-body exchange law uses Q=Q0(1+k), so
G_N/Gref=C_B[1+(partial_u ln sqrt(C_B))²/K_u]/(1+k),
Gref=1/(8pi Q0). Its limit is one. At u=0 it equals one exactly for this
parameter family. This does not establish scalar range or local matching.

## Conditional transverse equation

The homogeneous Euler-Lagrange equation is

 K_i [p_i'+(3+h)p_i]
 + p_i sum_j (partial_j K_i)p_j
 - (1/2)sum_j(partial_i K_j)p_j²
 + [U_i+alpha_i C_B² R(rhoJ-3PJ)]/(Hhat²/Hv²)=0,

where alpha_i=(alpha_B,0,0). For i=x,y, partial_i K_u=0;
partial_u ln K_i is bounded and the pu terms vanish. Divide by k and use
the coefficient limits. N_J'=1+O(k²) gives the same limiting derivative.
This produces exactly the note's transverse equations and h_GR. A regular
transverse limit is assumed, not obtained by these coefficient manipulations.

An independent geometric calculation can set X=2x/3,Y=y/sqrt(3). The limiting
metric is (dX²+dY²)/(1+3X²/2+2Y²). Its Gaussian curvature at the origin is
7/2, so it is not flat. Direct Christoffel contraction yields the two stated
connection polynomials; omitting them changes the equations at generic states.

## Fast coefficient and edge cases

For each fixed nonzero x, Uuu/[K_u(Hhat²/Hv²)] has leading term
4x²/(k² Hgr²). This is the specific positive potential-curvature contribution,
not a proof of an eigenvalue, normal mode, stability or oscillatory solution.
The asymptotic ratio is not uniform over points approaching x=0. At x=0,
a further direct expansion gives Uuu/k ->nu+3+4y²/3, so the potential-curvature
ratio instead has a finite leading limit 4(nu+3+4y²/3)/Hgr².

The example u=k² sin(N/k) obeys u'=k cos(N/k), u''=-sin(N/k).
It shows that bounded scaled amplitudes alone permit O(k) inertial terms
K_u u''; it supplies no solution of the candidate equations. For x=y=0,
rhoJ=0 or vanishing transverse velocities, all absolute coefficient and
constraint statements remain regular. Negative rhoJ or unbounded scaled
states are outside the theorem; no conclusion is drawn there.
