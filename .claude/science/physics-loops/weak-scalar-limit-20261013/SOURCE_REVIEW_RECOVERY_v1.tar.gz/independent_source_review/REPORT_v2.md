# Independent source and physics review, final version 2

Reviewer: `/root/bridge_equation_check`. Scientific author: `/root`.
Review date: 2026-10-13. This is a focused source review, not a formal claim audit,
a canonical-run acceptance, a landing decision, or a replacement author lane.

## Finding and exact reviewed identity

The coefficient theorem, first physical Hubble correction, ideal-state
cancellation, supplied-action normalization, transverse connection formulas,
and fixed-nonzero-x potential-curvature asymptotic are mathematically correct
under their stated algebraic premises. Independent controls returned **328
pass, 0 fail**. Four actual isolated defective runner copies were all detected.
No unchanged positive canonical runner was executed by this reviewer.

The final source also closes the Section 4 wording issue identified in version
1: it now explicitly requires uniform convergence of rho_J and P_J on the fixed
interval to the limiting matter coefficients. Along with sufficient transverse
solution regularity, this is enough for the stated conditional transfer.
Bounded fluid variables alone were not treated as proof of that convergence.
The author made exactly this premise correction; the reviewer verified the
complete affected diff. All findings are closed for the declared conditional
source scope. This is a source-review PASS, with the physical and solution
existence limitations below unchanged.

Original constituent: commit `a7536ad7adf51510ba63f811f6ddae3826fc1dc7`, tree
`09d4661bd9bc50b9d3efa2413321527c723fcf93`, four added paths relative to base
`583c699e859b64ff01c8bc92d1c04bdfe9994509`.

Final reviewed package: commit `8060dd99bafbff1ec18a4f5df1054c34bc655d88`, tree
`bbf76180a1a1ba4af2bc98a306daa602b448a97b`, the same base and exactly twelve
changed paths. `FINAL_FREEZE.json` preserves the preceding 27 identity checks;
`FINAL_FREEZE_v2.json` records 18 successful final and affected-change checks
and new recovery copies. All twelve complete files were read. The entire citation
manifest was structurally compared: its sole semantic change is one empty-edge
canonical node and the node-count increment. The seven process files were read
individually; their status descriptions are historical source-review snapshots,
not proof premises or retrospective execution claims.

Three source issues were repaired by the author; all original evidence remains
intact. First, the original
"persistent fast mode" title exceeded a calculation of a potential-curvature
coefficient; both title lines now identify the coefficient. Second, the original bare
run command was not found by the actual runner-discovery API. The explicit
Primary runner label now resolves correctly. `provenance/ORIGINAL_TO_FINAL_NOTE.diff`
preserves that intermediate correction. Third, the explicit fluid-convergence
premise was added. `provenance/ORIGINAL_TO_FINAL_NOTE_v2.diff` preserves the
complete original-to-final note difference; `AFFECTED_CONVERGENCE_FIX.diff`
is the exact final one-sentence change. All equations, the coefficient proof,
runner, fixture and import ledger remain unchanged. The original report and
its pending finding are preserved in REPORT_v1.md and REVIEW_v1.json; this
version supplies the affected-change closure.

## Independent mathematical route

The derivation in `INDEPENDENT_DERIVATION_v1.md` starts from the original
supplied action, without importing the author's compact helper or numerical
runner. Put r=1/s. The potential becomes

 U=(1+r)/(r+E)^2 [r V0+V1+3E^2/2].

At u=k^2 v, exact finite Taylor arithmetic in r, sqrt(a), and E gives

 U=3/2+k(x^2/2+y^2/3)
   +k^3[(v^2/2-v)x^2-(2v/3)y^2]+O(k^4),
 C_B=1+k^3 v+O(k^4).

This proves the zero quadratic coefficient directly. Differentiating the
analytic scaled expression with d/du=k^-2 d/dv gives the stated U_u/k and
k U_uu limits. Weighted kinetic and alpha_B limits agree. The remainders are
uniform on fixed compact scaled-state sets because the regularized denominators
approach 1 and D0>=1; analytic derivatives remain bounded on a slightly larger
compact neighborhood. No uncontrolled differentiation of a bare O-symbol is
used. These are asymptotic existence bounds, not an explicit uniform numerical
constant for every compact domain.

The original Weyl kinetic expression reduces exactly to J/F^2. Positivity uses
1-3a=(1-3k)^2/4>0, s>0 and D>=1 for 0<k<1/3. The endpoints remain excluded;
vanishing scalar kinetic terms at k=0 are not a nondegenerate endpoint theory.

Independent homogeneous lapse variation gives

 (3-T) Hhat^2 = 2 Hv^2 U + C_B^2 rho_unit rho_J/Q.

Thus both the factor two and R=rho_unit/(2 Q Hv^2)=R0/(1+k) are required.
The physical clock is H_J/Hhat=(1+alpha_B p_u)/sqrt(C_B), with
alpha_B=(1/2) partial_u log C_B. These facts yield exactly

 C1=2(Vbar-sigma0)/(3 H_GR^2)+Tbar/3.

Since rho_J>=0, H_GR^2>=1, and the small-k division is uniformly regular.
At sigma0=x^2+y^2, p_x=-3x/2, p_y=-2y the two terms cancel identically.
The cancellation is not imposed on arbitrary thermal matter. The local Newton
formula tends to one, and equals one at u=0, conditional on the supplied
massless weak-body exchange law; no range or apparatus matching is proved.

The full homogeneous Euler-Lagrange equation written in the independent
math note fixes the connection and matter-trace factors. For x,y, the coupling
has no direct derivative, partial_i K_u=0, and the p_u connection terms vanish
after the weighted limit. Christoffel contraction of the limiting metric
reproduces both connection polynomials. In X=2x/3,Y=y/sqrt(3), its Gaussian
curvature at the origin is 7/2, so the limiting metric is not flat. Transfer to
an actual limiting solution uses the now-explicit convergence premise above.

For each fixed nonzero x the potential-curvature contribution is
4x^2/(k^2 H_GR^2) to leading order. It is not a full coupled eigenvalue or an
existence/stability result. At x=0 the stronger independent expansion gives
U_uu/k -> nu+3+4y^2/3, hence a finite curvature ratio. At x=k,y=0,nu=1 and the
other chosen state variables zero, the ratio tends to 20, while substituting
x=k into only the fixed-x leading expression gives 4. The actual k=10^-9
check gives 20.000000100000000384... . This verifies why a relative asymptotic
must not be asserted uniformly through x=0. The source does not make that
assertion. The sinusoidal scaling example is correctly labeled kinematic,
not a solution. Zero density, zero transverse coordinates/velocities, and
both signs of bounded transverse coordinates cause no coefficient singularity.

## Actual numerical and defect controls

`check_independent_v2.py` uses exact SymPy Taylor arithmetic and raw-action
mpmath differentiation at 110 decimal digits, with Python 3.12.8, SymPy 1.14.0,
and mpmath 1.3.0. It imports no canonical runner. It uses all six frozen decimal
fixture points plus four independently chosen edge points, at k=10^-4,10^-7,
10^-10, and the additional x=k control. All 328 checks pass. The finite tests
support the analytic proof; finite sampling is not its uniformity argument.
The independent finite error bound was chosen before this run. No failed
canonical tolerance was relaxed.

The original direct large-expression symbolic attempt timed out at 120 seconds
before producing any completed result. `execution_v1` and its exact source
remain intact. Version 2 computes the same raw-action expansion using a finite
Taylor ring and completed in approximately 0.503 seconds. This is a computation
recovery, not a reclassification of the timed-out run.

Each negative control is a separate copied runner and copied final input set
inside `mutants/`. Exact source hashes, diffs, commands, standard output/error,
exit codes and full result JSON are retained. The unchanged canonical source
was never run as a positive baseline. All four mutated executions used the
original frozen tolerances and returned exit 1 with their input guards passing:

| Actual mutation | Passing checks | Failing checks | Relevant detection |
|---|---:|---:|---|
| Remove constraint factor 2 | 470 | 40 | C1 and curvature normalization |
| Omit Q(k) fluid normalization | 490 | 20 | First Hubble correction |
| Set explicit connections to zero | 501 | 9 | Lowered-momentum comparison |
| Set U_uu to zero after freezing | 454 | 56 | Derivative, limit and curvature checks |

The author's named connection omission entries only measure a nonzero omitted
term; they are not themselves executed mutant branches. The actual isolated
connection mutant demonstrates that the substantive lower-momentum comparisons
catch the omission. No claim that the author had already run a mutation suite
is made.

## Runtime, helper and premise closure

Full source inspection finds only pathlib, argparse, hashlib, json, mpmath and
sympy imports. There is no repository helper, dynamic loader, subprocess,
network call, ODE input or measured data in the scientific runner. Both actual
transitive-helper APIs and both claim-helper APIs return empty lists. The actual
graph API reproduces the original missing runner and resolves the repaired
primary. No graph rebuild, ledger materialization, audit command or canonical
main was run. `DISCOVERY_CLOSURE_v1.json` pins the functions used.

The note hash changed only through the explicit convergence premise after the
negative-control and discovery executions. Their prior input hashes remain
unaltered in those execution records. The new text changes neither computation
nor discovery; the unchanged mathematical controls were not rerun or restamped.
The final input binding is separately recorded in REVIEW_v2.json.

The three literal runtime paths are the canonical note, FIXTURES_v1.json, and
imports.json. The fixture supplies the operational precision, points and
bounds; the note and import ledger are read and hashed as provenance. The
functions/equations and premises in those files were separately read in full.
The runner hash is independently bound; it is not misleadingly counted as one
of its own three data inputs. Math-library versions are recorded, not claimed
as a full captured environment image.

The complete supplied local action, universal C_B metric, Q(k) normalization,
positive constants, nonnegative fluid density, flat expanding background and
compact scaled-state condition are explicit candidate assumptions. A regular
solution limit is an extra premise for the conditional transverse statement;
the weak-body local formula is another separately supplied approximation.
There are no fitted numbers, observational likelihoods or load-bearing
repository theorem imports. The previous thermal/curvature campaigns motivate
the question but do not enter this proof. No primitive is promoted and no
framework-axiom derivation of this candidate action is claimed.

## Claim type, negative-claim applicability and context

A bounded coefficient theorem is an appropriate type: there are nontrivial
algebraic propositions with named premises, not a naming convention. The
strongest supported scope is a conditional classical coefficient/instantaneous
constraint result. It provides no full-history convergence, solution-selection,
quantum, empirical, stability, local-environment or TOE closure. Those remain
unproved obligations, not impossibility claims. This review changes no formal
status and awards no retained/Nature-grade designation.

N1-N8 negative-claim discipline is not triggered by this source: it asserts no
no-go, route exhaustion, independent-wall census or obstruction theorem.
Specifically, N1 alternative-route exhaustion and N2 wall independence have no
claimed objects here; N3 hidden assumptions were checked as positive-theorem
premises; N4 residual matching leaves the explicitly open solution/physical
bridges open; N5 rhetoric caught and repaired the fast-mode title overreach;
N6 the source does not claim a convention change closes physical dynamics; N7
the supplied action was tested by a distinct mathematical route and actual
mutants; N8 inherited campaign narratives are not treated as independent proof.
This applicability explanation is not a fabricated N1-N8 no-go PASS or five-route
search certificate.

The context note's three primary abstract descriptions are supported at that
limited reading level: scalar-tensor reconstruction from distance information
is established context ([Esposito-Farese and Polarski](https://arxiv.org/abs/gr-qc/0009034));
matter-induced scalar oscillations and background effects have prior discussion
([Perivolaropoulos](https://arxiv.org/abs/hep-ph/0301237v2)); and a weak-field
coupling limit need not remove strong-field effects
([Damour and Esposito-Farese](https://arxiv.org/abs/gr-qc/9602056)). Only abstracts
and metadata were read. Recovery HTML and hashes are preserved. An initial
Python trust-store download failure was preserved; system curl recovered the
pages with ordinary certificate verification. No paper supplies a proof step,
and no uniqueness, novelty or exhaustive literature conclusion follows.
The author's targeted repository/open-PR search descriptions were read as
historical provenance; their full searches and current remote heads were not
independently repeated in this focused source review.

## Handoff boundary

`REVIEW_v2.json` provides final reviewer-owned original four-path dispositions
and all twelve final source identities. Its `/original_dispositions` pointer
is suitable for the constituent mapping in a UNIT record. `FINAL_FREEZE_v2.json`,
the preceding frozen review, mathematical controls, all mutant records,
discovery closure, manifest comparison, external recoveries and failure records
form the evidence set; RECEIPT.json inventories their exact hashes. All three
findings are closed at the final identity above. Subsequent identity or source
changes require separate affected-change confirmation. The author owns actual
UNIT preflight, positive canonical execution and final mechanical integration
checks; none is inferred from this source-review PASS.
