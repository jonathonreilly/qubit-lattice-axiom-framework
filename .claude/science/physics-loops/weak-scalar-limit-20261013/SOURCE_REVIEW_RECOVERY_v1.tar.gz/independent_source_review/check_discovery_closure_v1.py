#!/usr/bin/env python3
"""Read-only actual discovery functions; no runner main, graph build or audit."""
from pathlib import Path
import sys,ast,json,hashlib,datetime,platform
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent;W=R.parents[4]
assert (W/'scripts/weak_scalar_limit_2026_10_13.py').exists(),W
sys.path.insert(0,str(W/'docs/audit/scripts'));sys.path.insert(0,str(W/'scripts'))
import build_citation_graph as graph
import audit_packet_script_deps as deps
import sympy,mpmath
note='docs/WEAK_SCALAR_LIMIT_BOUNDED_THEOREM_NOTE_2026-10-13.md';runner='scripts/weak_scalar_limit_2026_10_13.py';claim='weak_scalar_limit_bounded_theorem_note_2026-10-13'
text=(W/note).read_text();old=(R/'original_source'/note).read_text();found=graph.extract_runner(text,note)
results={'extract_runner_final':found,'extract_runner_original':graph.extract_runner(old,note),'graph_transitive':graph.resolve_helper_runner_paths(found),'graph_claim_helpers':graph.helper_runner_paths_for_claim(claim,found),'deps_transitive':sorted(deps.transitive_helpers(Path(runner).stem)),'deps_claim_helpers':deps.helper_runner_paths_for_claim(claim,Path(runner).stem)}
tree=ast.parse((W/runner).read_text());declared=[];imports=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in node.targets):declared=ast.literal_eval(node.value)
 if isinstance(node,ast.Import):imports.extend(a.name for a in node.names)
 if isinstance(node,ast.ImportFrom):imports.append(node.module)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source_modules=[]
for name,m in sorted(sys.modules.items()):
 fn=getattr(m,'__file__',None)
 if fn:
  pp=Path(fn)
  if pp.suffix=='.py' and pp.is_relative_to(W):source_modules.append({'module':name,'path':str(pp.relative_to(W)),'sha256':sha(pp)})
checks={'runner_expected':found==runner,'original_runner_failure_reproduced':results['extract_runner_original'] is None,'both_claim_helper_APIs_empty':results['graph_claim_helpers']==results['deps_claim_helpers']==[],'both_transitive_APIs_empty':results['graph_transitive']==results['deps_transitive']==[],'declared_exact_three':declared==[note,'outputs/weak_scalar_limit_2026_10_13/FIXTURES_v1.json','outputs/weak_scalar_limit_2026_10_13/imports.json'],'source_imports_only_known':set(imports)=={'pathlib','argparse','hashlib','json','mpmath','sympy'}}
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only actual discovery and static input closure; no canonical runner execution or formal audit.','checks':checks,'discovery':results,'imports':imports,'declared_inputs':[{'path':p,'sha256':sha(W/p),'role':'numerical fixtures' if p.endswith('FIXTURES_v1.json') else 'read and hashed provenance only; proof premises reviewed separately'} for p in declared],'runner':{'path':runner,'sha256':sha(W/runner)},'actual_discovery_source_modules':source_modules,'runtime':{'python':platform.python_version(),'sympy':sympy.__version__,'mpmath':mpmath.__version__},'static_closure':'Runner has no repository helper, dynamic loader, network, subprocess or external trajectory input. The two math packages and Python standard library are environment dependencies; versions are recorded, not claimed as a full reproducible-environment image.'}
(R/'DISCOVERY_CLOSURE_v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':checks,'discovery':results,'source_modules':len(source_modules)}));raise SystemExit(not all(checks.values()))
