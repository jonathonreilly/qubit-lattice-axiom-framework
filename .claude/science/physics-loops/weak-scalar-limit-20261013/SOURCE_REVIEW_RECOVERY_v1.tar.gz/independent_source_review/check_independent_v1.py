#!/usr/bin/env python3
"""Independent raw-action Taylor, lapse normalization, field-space and finite controls."""
from pathlib import Path
import json,hashlib,sys,platform
import sympy as sp
import mpmath as mp
R=Path(__file__).resolve().parent;CHECKS=[]
def ck(n,ok,**d):CHECKS.append(dict(name=n,passed=bool(ok),**d))
def eq(n,e):
 q=sp.factor(sp.cancel(e));ck(n,q==0,residue=str(q))
def near(n,x,y,t):
 err=abs(x-y)/max(1,abs(y));ck(n,err<=t,error=mp.nstr(err,30),bound=mp.nstr(t,30))
def save(n,o):(R/n).write_text(json.dumps(o,indent=2)+'\n')
k,u,E,al,v,w,x,y,px,py,sg,nu=sp.symbols('k u E alpha v w x y px py sigma nu',real=True)
a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));F=1+s*E;D=1+sp.Rational(2,3)*(1+k)*(x*x+y*y);D0=D.subs(k,0)
# Original local action only. No compact formula, author helper or runner import.
Uraw=(1+s)*(sp.Rational(3,2)+(k/2-al*u+2*a*u*u/k)*x*x+k*y*y/3+nu*u*u/2+s*((k/2+al*k*u+2*a*u*u/k)*x*x+k*y*y/3)+sp.Rational(3,2)*s*E**2)/F**2
Du=lambda f:sp.diff(f,u)+2*al*E*sp.diff(f,E)
U1=Du(Uraw);U2=Du(U1)
Ku=(1-3*a*s*E)/F+3*a*s*s*E*E/F**2
Kx=(1+s)*4*k/(9*F*D);Ky=(1+s)*k/(3*F*D);CB=(1+s)*E/F;AB=al/F
aj=sp.series(sp.sqrt(a),k,0,6).removeO();Ej=sp.series(sp.exp(2*aj*k*k*v),k,0,7).removeO()
def jet(ex,n=3):
 ex=sp.cancel(ex);return sp.series(ex.subs({u:k*k*v,E:Ej,al:aj},simultaneous=True),k,0,n).removeO().expand()
print('Deriving raw-action Taylor jets',flush=True)
Uj=jet(Uraw,4);V=x*x/2+y*y/3;B3=(v*v/2-v)*x*x-sp.Rational(2,3)*v*y*y
for n,target in [(0,sp.Rational(3,2)),(1,V),(2,0),(3,B3)]:eq('U.coefficient.'+str(n),Uj.coeff(k,n)-target)
for label,expr,want in [('Ku',Ku/k,sp.Rational(1,4)),('Kx',Kx/k,4/(9*D0)),('Ky',Ky/k,1/(3*D0)),('alpha_B',AB/k,sp.Rational(1,2)),('Uu',U1/k,v*x*x-x*x-2*y*y/3),('Uuu',k*U2,x*x)]:
 eq('weighted.'+label,jet(expr,1).coeff(k,0)-want)
CBj=jet(CB,4)
for n,target in [(0,1),(1,0),(2,0),(3,v)]:eq('CB.coefficient.'+str(n),CBj.coeff(k,n)-target)
eq('raw_Weyl_identity',Ku-(1+(1-3*a)*s*E)/F**2)
eq('alpha_B_clock',sp.diff(sp.log(CB),E)*2*al*E/2-AB)
eq('origin_U',Uraw.subs({u:0,E:1})-sp.Rational(3,2)-k*V)
eq('origin_Newton',((CB*(1+AB**2/Ku)/(1+k)).subs({u:0,E:1,al:sp.sqrt(a)}))-1)
# Different normalization route: vary homogeneous lapse in the gravitational/scalar action.
Q,H,Hv,T,lapse,fluid=sp.symbols('Q H Hv T lapse rhoE',positive=True)
L=-3*Q*H*H/lapse+Q*H*H*T/lapse-2*Q*Hv*Hv*sp.Symbol('U')*lapse
lapse_equation=sp.diff(L,lapse).subs(lapse,1)-fluid
eq('lapse_Friedmann',lapse_equation-(Q*(3-T)*H*H-2*Q*Hv*Hv*sp.Symbol('U')-fluid))
Hg=1+2*sg/3;Tb=(4*px*px/9+py*py/3)/D0;C1=2*(V-sg)/(3*Hg)+Tb/3
# Formal series multiplication, including density normalization independently of author code.
physical_first=sp.expand((2*(sp.Rational(3,2)+k*V+sg*(1-k))/3)*(1+k*Tb/3)).coeff(k,1)/Hg
eq('C1',physical_first-C1)
eq('ideal_C1',C1.subs({sg:x*x+y*y,px:-sp.Rational(3,2)*x,py:-2*y}))
# Christoffel route: compute the inverse metric and all connection components.
coords=[x,y];g=sp.diag(4/(9*D0),1/(3*D0));gi=g.inv();vel=[px,py]
Gamma=[[[sp.simplify(sum(gi[i,l]*(sp.diff(g[l,j],coords[m])+sp.diff(g[l,m],coords[j])-sp.diff(g[j,m],coords[l])) for l in range(2))/2) for m in range(2)] for j in range(2)] for i in range(2)]
con=[sp.factor(sum(Gamma[i][j][m]*vel[j]*vel[m] for j in range(2) for m in range(2))) for i in range(2)]
want=[(-2*x*px*px-4*y*px*py+sp.Rational(3,2)*x*py*py)/(3*D0),(-4*x*px*py-2*y*py*py+sp.Rational(8,3)*y*px*px)/(3*D0)]
for i in range(2):eq('connection.'+str(i),con[i]-want[i])
X,Y=sp.symbols('X Y');Dc=1+sp.Rational(3,2)*X*X+2*Y*Y;curv=sp.simplify(Dc*(sp.diff(sp.log(Dc),X,2)+sp.diff(sp.log(Dc),Y,2))/2)
eq('curved_metric_origin',curv.subs({X:0,Y:0})-sp.Rational(7,2))
edge=jet(U2.subs(x,0)/k,1).coeff(k,0);eq('x_zero_subleading_curvature',edge-(nu+3+4*y*y/3))
eq('kinematic_fast_example',sp.diff(k*k*sp.sin(sp.Symbol('N')/k),sp.Symbol('N'),2)+sp.sin(sp.Symbol('N')/k))
save('SYMBOLIC_v1.json',dict(U_through_cubic=str(Uj),CB_through_cubic=str(CBj),C1=str(sp.factor(C1)),connections=[str(z) for z in con],Gaussian_curvature=str(curv),x_zero_Uuu_over_k=str(edge)))
print('Evaluating independent raw-action finite controls',flush=True)
mp.mp.dps=110
frozen=json.loads((R/'original_source/outputs/weak_scalar_limit_2026_10_13/FIXTURES_v1.json').read_text())
points=frozen['points']+[['-4','2','2','-1','-1','2','0','3'],['4','-2','0','0','2','-1','0','0.5'],['-1','0','0','1','0','-2','1','2'],['0','0','-1','2','1.5','-4','5','1']]
def raw(kk,uu,xx,yy,nn):
 aa=(1-kk)*(1+3*kk)/4;root=mp.sqrt(aa);ss=(1+kk)/(kk*(1-3*kk));ee=mp.exp(2*root*uu);ff=1+ss*ee;dd=1+mp.mpf(2)/3*(1+kk)*(xx*xx+yy*yy)
 Ku=(1-3*aa*ss*ee)/ff+3*aa*(ss*ee/ff)**2
 kinetic=[Ku,(1+ss)/ff*4*kk/(9*dd),(1+ss)/ff*kk/(3*dd)]
 W=mp.mpf('1.5')+(kk/2-root*uu+2*aa*uu*uu/kk)*xx*xx+kk*yy*yy/3+nn*uu*uu/2+ss*((kk/2+root*kk*uu+2*aa*uu*uu/kk)*xx*xx+kk*yy*yy/3)+mp.mpf('1.5')*ss*ee*ee
 return kinetic,(1+ss)*W/(ff*ff),root/ff,(1+ss)*ee/ff
rows=[]
for j,point in enumerate(points):
 vv,ww,xx,yy,p1,p2,sigma,nn=map(mp.mpf,point);DD=1+mp.mpf(2)/3*(xx*xx+yy*yy);HH=1+2*sigma/3;VV=xx*xx/2+yy*yy/3;TT=(4*p1*p1/9+p2*p2/3)/DD;cc=2*(VV-sigma)/(3*HH)+TT/3;third=(vv*vv/2-vv)*xx*xx-2*vv*yy*yy/3
 for power in [4,7,10]:
  kk=mp.mpf(10)**(-power);uu=kk*kk*vv;pu=kk*ww;K,UU,ab,cb=raw(kk,uu,xx,yy,nn);Uu=mp.diff(lambda q:raw(kk,q,xx,yy,nn)[1],uu);Uuu=mp.diff(lambda q:raw(kk,q,xx,yy,nn)[1],uu,2)
  norm=K[0]*pu*pu+K[1]*p1*p1+K[2]*p2*p2;Hh=(2*UU+2*cb*cb*sigma/(1+kk))/(3-norm);nj=1+ab*pu;HJ=Hh*nj*nj/cb
  values=[K[0]/kk,K[1]/kk,K[2]/kk,Uu/kk,kk*Uuu,(HJ/HH-1)/kk,(UU-mp.mpf('1.5')-kk*VV)/kk**3]
  targets=[mp.mpf('.25'),4/(9*DD),1/(3*DD),vv*xx*xx-xx*xx-2*yy*yy/3,xx*xx,cc,third]
  for i,(got,want) in enumerate(zip(values,targets)):near(f'finite.{j}.{power}.{i}',got,want,mp.mpf(300)*kk)
  near(f'Newton.{j}.{power}',cb*(1+ab*ab/K[0])/(1+kk),mp.mpf(1),300*kk)
  ck(f'physical_domain.{j}.{power}',min(K)>0 and norm<3 and nj>0 and HJ>0)
  if xx:near(f'fast_fixed_x.{j}.{power}',kk*kk*Uuu/(K[0]*Hh),4*xx*xx/HH,300*kk)
  else:near(f'finite_x_zero.{j}.{power}',Uuu/(K[0]*Hh),4*(nn+3+4*yy*yy/3)/HH,300*kk)
  rows.append(dict(point=j,k=mp.nstr(kk,30),values=[mp.nstr(t,45) for t in values],targets=[mp.nstr(t,45) for t in targets]))
# Pointwise x!=0 is not a relative-uniform fast asymptotic near x=0.
kk=mp.mpf('1e-9');K,U,ab,cb=raw(kk,0,kk,0,1);Hh=2*U/3;cur=mp.diff(lambda q:raw(kk,q,kk,0,1)[1],0,2)/(K[0]*Hh)
near('approaching_x_zero_actual_limit',cur,mp.mpf(20),mp.mpf('1e-5'))
ck('approaching_x_zero_naive_fixed_x_ratio_not_uniform',abs(cur-4)>10,actual=mp.nstr(cur,45),naive=4)
counts=dict(passed=sum(c['passed'] for c in CHECKS),failed=sum(not c['passed'] for c in CHECKS),total=len(CHECKS))
save('RESULTS_v1.json',dict(scope='Independent controls only; canonical positive runner not executed.',environment=dict(python=platform.python_version(),sympy=sp.__version__,mpmath=mp.__version__,decimal_precision=110),checks=CHECKS,counts=counts,rows=rows))
print(json.dumps(dict(counts=counts,failures=[c for c in CHECKS if not c['passed']])),flush=True)
raise SystemExit(bool(counts['failed']))
