#!/usr/bin/env python3
"""Run only defective isolated copies; never execute the unchanged canonical runner."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,datetime,difflib,os
R=Path(__file__).resolve().parent;SOURCE=R/'final_source';RUNNER='scripts/weak_scalar_limit_2026_10_13.py';text=(SOURCE/RUNNER).read_text()
mutations=[
 ('missing_constraint_two','Hhat=2*(U+cb*cb*sg/(1+k))/(3-T)','Hhat=(U+cb*cb*sg/(1+k))/(3-T)'),
 ('missing_Q_normalization','Hhat=2*(U+cb*cb*sg/(1+k))/(3-T)','Hhat=2*(U+cb*cb*sg)/(3-T)'),
 ('omit_connections',"explicit=[(-2*x*px*px-4*y*px*py+mp.mpf('1.5')*x*py*py)/(3*D0),\n                  (-4*x*px*py-2*y*py*py+mp.mpf(8)/3*y*px*px)/(3*D0)]",'explicit=[mp.mpf(0),mp.mpf(0)]'),
 ('freeze_before_second_derivative','Uuu=mp.diff(lambda t:compact(k,t,x,y,nu)[1],u,2)','Uuu=mp.mpf(0)'),
]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
inputs=['docs/WEAK_SCALAR_LIMIT_BOUNDED_THEOREM_NOTE_2026-10-13.md','outputs/weak_scalar_limit_2026_10_13/FIXTURES_v1.json','outputs/weak_scalar_limit_2026_10_13/imports.json']
for name,before,after in mutations:
 assert text.count(before)==1,(name,text.count(before))
 root=R/'mutants'/name;dest=root/RUNNER;dest.parent.mkdir(parents=True);dest.write_text(text.replace(before,after))
 for item in inputs:
  p=root/item;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((SOURCE/item).read_bytes())
 (root/'MUTATION.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),dest.read_text().splitlines(True),fromfile='frozen_canonical_runner',tofile=name)))
 cmd=[sys.executable,str(dest),'--out',str(root/'RESULTS.json')];start=time.monotonic();rec={'name':name,'source_sha256':sha(dest),'frozen_runner_sha256':sha(SOURCE/RUNNER),'command':cmd,'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_hashes':[{'path':item,'sha256':sha(root/item)} for item in inputs]}
 with (root/'stdout.log').open('w') as out,(root/'stderr.log').open('w') as err:
  try:res=subprocess.run(cmd,cwd=root,stdout=out,stderr=err,timeout=120,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});rec['exit_code']=res.returncode
  except subprocess.TimeoutExpired:rec['exit_code']=None;rec['timeout_seconds']=120
 rec['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['elapsed_seconds']=time.monotonic()-start
 if (root/'RESULTS.json').exists():
  data=json.loads((root/'RESULTS.json').read_text());rec['counts']=data['counts'];rec['failed_checks']=[z['name'] for z in data['checks'] if not z['passed']];rec['input_guards_pass']=all(z['passed'] for z in data['checks'] if z['name'].startswith('input_unchanged.'));rec['results_sha256']=sha(root/'RESULTS.json')
 rec['detected']=rec['exit_code']==1 and rec.get('counts',{}).get('failed',0)>0 and rec.get('input_guards_pass',False)
 (root/'EXECUTION.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec);print(json.dumps({k:rec[k] for k in ['name','exit_code','counts','detected']}),flush=True)
(R/'MUTANT_SUMMARY.json').write_text(json.dumps({'controls':records,'all_detected':all(r['detected'] for r in records),'canonical_positive_executed':False},indent=2)+'\n')
raise SystemExit(not all(r['detected'] for r in records))
