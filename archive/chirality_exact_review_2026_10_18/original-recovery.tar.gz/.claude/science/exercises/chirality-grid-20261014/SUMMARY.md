# Chirality on the grid: exercise report (2026-10-14)

Jon's request: "run the exercise on chirality and the grid … what new approaches or combined disparate approaches could crack this open?"

**Provenance.**
- Supervisor: Claude Opus 5.5.
- Agents: 18 Opus 5.5 agents at xhigh — step 0, literature, a blind check, six routes, three combinations, three kill agents, and the K2b/K2c tests. All are the same model family, so they are **not independent of each other**.
- Other-vendor referee: codex gpt-5.6-sol at xhigh. It refereed F2-R and K2 here, and TW-1/2/3 in the gravity packet.

**Labels.** **proved** (with path) / **checked** (finite or numerical test) / **suggested** / **reading**.

**Where things are.** Details live in `WALL.md`, `ASSUMPTIONS.md`, `ROUTES.md` (all tables, kill verdicts and referee records), `APPROACH_REGISTRY.md`, `OUTSIDE_VIEW.md`, `step0/`, `routes/`, `combos/`, `kills/`, `TESTS.md` and `scripts/`.

---

**Review-loop corrections (2026-10-14 ~20:47Z).** PR #9562 was closed at 19:24Z as a research transfer into J tasks; the branch is retained. The review found that this summary exceeded its referee qualifications. Sections 2 and 5 were rewritten to the referees' scopes: Lemma R's class, F3/F5 scope, K2c's measure and error-estimate scope, and the ν_R condition. The axiom paraphrase in WALL.md that supplied probabilities was corrected. K2c's saved pools were added.

## 1. The wall, in plain words

Matter in nature is handed: the weak force acts only on left-handed electrons and quarks, and the right-handed versions carry different charges. A theorem (Nielsen–Ninomiya) says that if a grid's rules are local, the same everywhere, free (no interactions), and conserve charge in the usual way, then every handed particle comes with a mirror partner of the opposite hand and the same charges. So the grid makes a mirror-symmetric set of particles, and ours is not one.

Getting past the wall means a grid construction whose particles, below the grid's own energy, are exactly the observed handed ones. Any mirrors must be too heavy to have been seen, and the forces must act as observed. The problem has been open, in this form, for over 40 years.

## 2. What the exercise found

1. **The repo had already hit this wall from about twenty directions.** Every attempt sat inside the theorem's class: free, finite-range rules on one-qubit sites, with Hamiltonian or ticking time. None got through.
   - A one-line lemma explains why the mass-term attempts had to fail: no mass term that respects the gauge group can change the net hand count (F6, proved; the kill round narrowed how widely it applies).
2. **Six independent routes and three combinations all end at one of two frontier questions.** Both are open across the whole field, not just here:
   - **(I) Symmetric mass generation.** Can interactions give an anomaly-free set of mirror particles a mass without breaking the protecting symmetry, and without leaving a massless bound state behind? This is Golterman–Shamir's open "propagator zeros" dispute; X1 shows the same question as "lattice completeness". Symmetric gapping, discrete time, extra coordinates, dissipation and the framework's own three-generation package all lead here.
   - **(II) Lüscher's non-abelian measure locality, plus reflection positivity with forces present.** The Euclidean-time "overlap" route reduces to this.
3. **Hard prices on the dead ends, several checked:**
   - **Within a stated class, exact modified chirality cannot be net-chiral** (Lemma R, codex-confirmed core). The class: free, translation-invariant, γ5-Hermitian, scalar-plus-vector Ginsparg–Wilson symbols with canonical R, rational in e^{ik} with a common denominator nonzero on the torus (algebraically, finitely many neighbours and finitely many auxiliaries with an invertible auxiliary block). For these, the local chiral indices of isolated massless zeros sum to zero, whatever the fibre size. **Not established:** the general-R / gauge-background index formula, and that the three listed escape forms (non-rational kernel, infinite auxiliaries, auxiliary vacuum) are exhaustive.
   - **A one-handed free ticking rule hides its mirror at half a tick, inverted, with the same charges.** Once gauge-coupled, no conserved local energy exists, so the vacuum is not stationary (F3-A, two-band free proofs and checks; strengthened in the kill round). Interacting ticks are not covered.
   - **For quasi-free (Gaussian) states, dissipation and record sinks move the mirror's Berry flux into the state.** Every sink tested fails observation (F5, proved for Gaussian states and checked). Non-Gaussian vacua are not covered.
   - **No-interaction extra-coordinate slabs fail on the gauge side.** They need a slab of at least about 10⁴⁶ layers, or world-range couplings (F4-B; proof skeleton plus checked arithmetic).
   - **Mirrors whose mass comes from electroweak breaking are excluded in the scanned models:** S at 4–6σ, gg→h at least 9× (F6, checked; model-scoped).
4. **Constructive gains:**
   - **A framework-native three-generation package** (X2, checked).
     - The three generations are the walker's three left-handed cube corners; the other corners are mirrors made heavy by a cubic-invariant interaction.
     - The light corners are exactly decoupled from that interaction.
     - No anomaly forbids gapping the mirrors: the K1 kill test failed.
     - Its known danger is the 1993 Golterman–Petcher–Rivas symmetry-breaking phase, which mean-field shows is not removed by the filter (K1, wounded).
   - **A Euclidean-time package (set B)** that ties chirality to the gravity campaign's best gravity bill.
     - Its free real-time spectrum is clean: one light handed particle per hand, mirrors heavy and harmless. This was independently rebuilt by K2 and confirmed by the referee.
     - Its strain-protection fixes two gravity-campaign problems (no twins, no strain mass).
     - Its open issue is reflection positivity once forces are included. A counterexample was first found for one gauge measure (Fejér-weighted, open-time lattices; referee-confirmed). **K2c then found quadrature-converged negative eigenvalues for the hard-cutoff measure the package actually uses**, on open-time lattices and on tori Lt = 12, 16, once a masking effect is removed. Codex confirmed this for the finite 2D U(1) vector-like proxy, with Lx = 2, M = 1, m = 0.05, β_g = 0. The error is an a-posteriori quadrature estimate, not a rigorous bound; the saved pools are archived under `scripts/K2c/`. It is **not** shown for infinite volume, 4D, non-abelian groups or the chiral measure. If that holds, reflection positivity with forces fails for the overlap in this 2D proxy, and set B's real-time version needs a price (Π-W, or 5D fermions without Pauli–Villars fields).
5. **Framework facts settled along the way:**
   - one qubit per site is not the obstacle for slab or Euclidean constructions (X1, X3);
   - ν_R is needed for the Z₁₆ gate when Z₄^X is kept exact (F6-tC, X1), and on the staggered carrier for gappings that keep the corner nodes (K1 scope correction). It is **not** forced unconditionally.
   - **cross-lane theorem:** non-trivial quark mixing (CKM) forces a preferred strain direction in the flavour sector (X2-L8, proved; checked over 1120 subgroups). Its size goes back to the gravity/strain lane.

**Did the exercise crack the 40-year wall? No.** It converted the repo's diffuse wall into the field's two sharpest open questions, attached checked prices to every dead end, and produced two concrete framework-native candidates, each with a known decisive test.

## 3. Routes worth doing (at most three)

*This table is the state at the exercise's close (2026-10-14 ~19Z). For what round 2 changed, see §7.*

| # | Route | What you must believe | Cost | First test | What it would change |
|---|---|---|---|---|---|
| 1 | **Set-B Euclidean package**: overlap fermions plus Euclidean hypercubic time plus spatial-TT gravity (X3/F2-H) | Reflection positivity holds for the hard-cutoff gauge measure on the torus or in infinite time; Lüscher's non-abelian measure is local for the SM 16 | K2c done: gauged RP fails in the 2D proxy (codex-confirmed) → test whether a 2D anomaly-free *chiral* U(1) measure or a 4D slice behaves the same (a day) → if so, price Π-W / 5D-without-PV | the chiral-measure RP test | A single package carrying both chirality and the best gravity bill. Prices: Z⁴ time, and a non-rational kernel (with an infinite real-time fibre) |
| 2 | **Framework-native three-generation corner package** (X2) | The filtered mirror interaction has a symmetric strong-coupling phase, with no 10-vector condensation and no massless composite (GS condition 3 fails) | T-G1 exact diagonalisation (hours–day) → 2+1D QMC (weeks; needs compute) | T-G1: does the filter's overlap destroy the symmetric gapped phase? | Three handed generations from the grid's own corners; prices: 16 modes per site plus fermion number mod 4 |
| 3 | **Inflow slab with far-wall symmetric gapping** (F4-A, X1) | A slab's far wall can be gapped symmetrically, leaving a protected propagator zero | Sign-free 2+1D-surface QMC (weeks; needs compute or collaborators) | F4's DQMC test (pre-registered) | Exact on-site gauge invariance, nearest-neighbour range, no Eichten–Preskill leakage; price ~10³ qubits per site |

## 4. What not to do next

- **No more one-body or mass-term blocks aimed at net handedness.** The index lemma kills them.
- **Do not enlarge the site algebra to M₄(C) "for γ5".** Within Lemma R's class, fibre size does not change the conclusion.
- **Do not pursue one-handed ticks, record or dissipative sinks, or heavy mirrors from electroweak breaking.** Each is priced out.
- **Do not treat 0+1D or 1+1D symmetric-gapping toys as 4D evidence.**
- **Do not use plain staggered twins as generations with the minimal splitting term.** The first-order clock hazard is ×4.7–17.8 on that branch (TW-2, refereed: branch-dependent).

## 5. The exact price

There is no single price for the whole wall. The family-level prices:
- **(a) Lemma R (codex-confirmed core).** Within its stated class (rational, pole-free, canonical-R, scalar-plus-vector GW symbols), net chirality is impossible. Exact GW chirality with nonzero index therefore needs to leave that class. The usual forms are a non-rational quasi-local kernel (touching AX:57's "one fixed nearest-neighbor rule") or infinitely many auxiliaries per site (touching AX:47). The referee notes that this list is not proved exhaustive.
- **(b) Interacting routes** need **16 to about 1000 fermion modes per site**. That is the parked site-size decision #4, whose wake condition has literally fired (K3).
- **(c) The set-B route** needs Euclidean hypercubic time (Z⁴): the gravity campaign's B1–B4 prices.

**Owner decisions surfaced by this exercise:**
1. **Matter per site** (#4): yes/no, and how much. Every surviving route needs more than one qubit's worth.
2. **Range:** whether a non-finitely-generated quasi-local kernel is acceptable (route 1).
3. **Time:** continuous (set C) or Euclidean hypercubic (set B) — the same choice as in the gravity campaign.
4. **Compute:** whether to fund the weeks-scale QMC tests for routes 2 and 3, or seek collaborators (Catterall, Hasenfratz, Fukaya/Onogi, Kikukawa).

## 6. Appendix

**Assumptions most likely wrong:**
- A5, "free carriers": the wall dissolves only with interactions.
- A3, "Hamiltonian or finite tick".
- A2's reading of "one qubit per site".

**Most expensive if wrong:**
- **A2:** forces #4.
- **A9:** time choice (set B vs set C) changes which routes exist.
- **A4:** range.

**PR or ledger candidates:**
- Lemma R as a price note, with the referee's corrections.
- F3-A as a bounded no-go/price for ticks.
- The index lemma (F6).
- The X2 flavour–strain theorem (X2-L8), routed to the gravity/strain lane.
- Corrections to T22 :19 and R2-4 :204.

**Literature worth translating:**
- Lüscher 1999/2000.
- Kikukawa–Usui (free overlap reflection positivity).
- Thorngren–Preskill–Fidkowski 2026 (symmetry disentanglers).
- Golterman–Shamir 2023–26.
- Catterall et al. on reduced Kähler–Dirac and SMG.
- Gioia–Thorngren 2025.
- Read 2017 (algebraic K-theory of local bands).

## 7. Round 2: panel D and its tests (2026-10-14 evening; written 2026-10-15T00:30Z)

**Provenance.**
- Panel D: five Opus 5.5 lenses at xhigh (skeptic, lattice, gravity, quantum information, strategy).
- Ten tests: NT-1–3, OBS-1, BLEAK-1, UV-1, SIGN-1 and COL-1. Each was run by one Opus 5.5 agent at xhigh.
- Every test was refereed by codex gpt-5.6-sol at xhigh. Scopes below are the referees', not the workers'. Details are in TESTS.md under each item's referee entry.

**Panel D's advice (owner decisions; nothing adopted).**
- **D1:** a finite enlarged site content, decided once for all lanes.
- **D2:** decline.
- **D3:** set C by default.
- **D4:** collaborators first.

The drafts `panel_D/D1_SITE_CONTENT_PROPOSAL.md` and `panel_D/COLLABORATOR_ASKS.md` are not adopted and not sent.

**Results, at referee scope.**

| Test | Reading | What is established (referee scope) | What is not |
|---|---|---|---|
| NT-2 | PG3-NEG (confirmed with corrections) | The flat hard plaquette weight at β_g = 0 is not link-reflection-positive on finite 3D lattices. Exact witness on the 2×2 periodic slice, every 0 < δ < π/4. A positive-type profile with the same support restores pure-gauge RP. | Every geometry, infinite volume, 4D |
| UV-1 | OPEN, as registered (confirmed with corrections) | The 2D U(1) overlap kernel is negative at finite β_g on tori at t₀ = 1 (triangle and hard), and in the open proxy at t₀ = 2. The normalised β → ∞ torus kernel is negative at t₀ = 3 and 4. This is an exponentially small lattice-scale tail. | A physical-depth or continuum obstruction; a β-independent decay length |
| NT-1 | **NOT CONFIRMED** (strict reading OPEN) | The RP failure of the fractional-power modulus \|det D(1)\|²\|det D(2)\|^{1/2} (Lx = 2, open time) | That the measure was a legitimate local chiral (Lüscher) measure. The chiral question is open and is the campaign's NT-1′. |
| BLEAK-1 | LEAK-PLANCK (confirmed with corrections) | For R19-33's scalar action (spatial-TT plus instantaneous bridge, deleted zero mode, no seagull or speed counterterm), one-graviton exchange gives δc = (π/6)(ℓ_P/a)². The covariant kernel gives 0. | A gauge-complete observable: the result is bare and prescription-dependent, and formal at a = ℓ_P |
| NT-3 | TG1-BROKEN, literal (confirmed with corrections) | In a 1D SU(4) ED proxy (L ≤ 7, W = ∞): a unique singlet ground state, and the 6-vector gap collapses near the filter zero | A mirror gap; symmetry breaking. GPR is neither killed nor defused. |
| OBS-1 | R1 FLAV-NEAR in the E_g proxy; R2 Z4-EXACT conditionally; R3 PDK-SAFE conditionally (confirmed with corrections) | X2 as written conserves U(1)_X. Electroweak breaking leaves an exact U(1)_{B−L}. Branch B's clock rate is 0.12–2.5× the bound in the diagonal-E_g, U(1), bilinear-proxy completion. | The complete X2/SM flavour reading (T₂g, the non-abelian chiral loop and the mirror self-energy are uncomputed); the leakage coefficient for R3 |
| SIGN-1 | SIGN-FREE, narrowly (confirmed with corrections) | Ungauged X2 with a real flavour-blind filter is rigorously Kramers-class sign-free at λ1 = 0, λ2 ≠ 0, and numerically certified for λ1 ≤ 0 with \|λ2/λ1\| ≥ 0.1763 | λ1 > 0; dynamical G_SM links (this fixed-U(1)_c construction fails there) |
| COL-1 | COLOUR-SPREAD-OK in class M (confirmed with corrections) | One-qubit sites can collectively carry exact, finite-range, one-step-translation-covariant SU(3) through gated many-body representations, with a commuting Gauss law. Elementary quadratic charges (class Q) force blocks. | Private physical qubits per colour point (only private tensor factors are forced); cubic rotations; a translation-breaking ground state; QCD universality |

**What changed for the routes (reading).**
- **Route 1 (set B) is weaker.**
  - The gauge weight must be positive-type (law data, not an axiom change).
  - In the 2D proxy, the overlap's own RP failure persists at finite gauge coupling and lattice-scale depth.
  - Set B's only RP-safe gravity bridge on record carries a Planck-size bare light-cone shift, unless a counterterm is added per species.
  - Whether a legitimate chiral measure behaves the same is open (NT-1′).
- **Route 2 (X2) survived its first data screen, conditionally.**
  - It survives only in a narrow flavour corner (branch B). If the mirrors gap symmetrically, it predicts Dirac neutrinos and zero 0νββ.
  - It is now simulable without a sign problem, in the ungauged, λ1 ≤ 0 setting.
  - Open hazards: flavour-pattern Lorentz violation (OBS-2) and the GPR symmetry-breaking phase (QMC-1).
- **D1 is reframed by COL-1.** Colour need not sit on one site; the question becomes per-cell content located by a marker pattern.

**Did round 2 crack the wall? No.** It sharpened route 2's decisive test into a simulation that can actually be run, and weakened route 1 on the reflection-positivity side.

**Campaign (2026-10-15).** A 24-hour campaign, pre-registered in TESTS.md ("24-hour campaign, wave 1"), runs:
- OBS-2: route 2 kill test;
- QMC-1: the sign-free simulation pilot;
- NT-1′: a legitimate chiral measure and RP.

## 8. The 24-hour campaign (2026-10-15 to 10-17)

**Provenance.** Each test was run by one Opus 5.5 agent at xhigh. These agents are all one model family, so none is independent of the others. Each test was pre-registered in TESTS.md before it ran. Referees were codex gpt-5.6-sol at xhigh. **Refereed:** OBS-2, OBS-3, OBS-4, CLS-1, NT-1′, NT-1″, QMC-1, and the F4/X1 lemmas. **Not refereed:** TOR-1, GEN-1, GEN-2, QMC-1b and LOCK-1, because the codex account was out of credit until 10-22; they are queued in `ref_*`. The run was cut short twice, once by a session crash and once by a usage limit, about 2 days in all.

**Route 2: the corner package (X2) and its re-scope (X2′)**

| Test | Reading | What it established, at the scope the referee allowed |
|---|---|---|
| OBS-2 | LV-PRICE (refereed) | With OBS-1's textures, the d quark shifts c_TT by about −2e-8, against a bound of 1e-22. Both the direct vector row and the axial row fail. The minimal number of counterterms needed is not established. |
| OBS-3 | TEXTURE-ESCAPE (refereed) | The exact "B-gen" equal-strength textures fit all quark masses, CKM and J, and leave zero one-loop residual. So OBS-2's violation depends on the texture and is not forced by CKM at one loop. |
| OBS-4 | FCNC-PRICE (refereed) | With exact translations, CKM is a permutation unless something breaks translations: B-gen needs carriers at hw2. In the D3 benchmark those carriers sit at TeV scale, and ΔF = 2 fails by a factor of 180 or more even after tuning. The way out (class S) is a lattice-scale condensate that breaks translations to BCC and gives up X2-L2. |
| CLS-1 | CLS-PRICE (refereed) | Class S allows light–light operators that no symmetry protects. Removing the Lorentz violation they cause needs Θ plus tuning of about 1e-27 (toy one-loop calculation and one-body proxies). |
| GEN-1 | GEN-CONE, n ≤ 8 (unrefereed) | X2′ puts all three generations at Γ as an internal label. That frees CKM, leaves only SM-sized ΔF = 2, removes the strain channel, and keeps light protection. The cost: one-loop LV of about 1e14 over the bound, which needs 2 covariant counterterms tuned to about 1e-16 (the same class as the set-C cone price); 96 modes per site; and the "3" is supplied by hand. |
| GEN-2 | DIR-PRICE (unrefereed; checked only at the symmetry level) | Using the orientation of an extended cell as the generation label brings back a forced Eg strain channel and needs at least 7 LV counterterms. |
| LOCK-1 | LOCK-MIXED (unrefereed) | The landed record gas forms a chessboard only when g < g_N(ρ). At main's g ≥ 1 (neutral scale, and the RP range) it stays liquid. A chessboard folds (π,π,π) onto Γ, which would break X2′'s protection inside that region (supervisor's reading). |
| QMC-1 | OPEN (refereed) | A validated sign-free AFQMC. At L ≤ 6 the 10-vector correlations span the whole box once the mirrors are suppressed, which suggests a GPR-like crossover. It does not establish a gap, GPR or SMG. |
| QMC-1b | OPEN (unrefereed) | At W = 2 and 4, f_Γ does not suppress its (π,0) mirrors. The f2 ratios hold at 4× the statistics. At W = 8 (supplementary), both filters agree, which suggests the signal comes from the 10-vector channel rather than the filter. |

**Route 1: the overlap / set B**

| Test | Reading | What it established |
|---|---|---|
| NT-1′ | OPEN at G-LEG(b) (refereed) | A chart-local Lüscher measure at Lx = 4 on open time. RP is negative on 3 of 3 pools, and the negativity is carried by the modulus. |
| NT-1″ | OPEN at (b″) (refereed) | Open time itself blocks a legitimate measure: H_W has edge zero modes, which make any Wilson-line winding inadmissible. On the torus, C(11112) = 0. |
| TOR-1 | OPEN on power (unrefereed) | A torus Lüscher measure that passes every legitimacy gate. The RP kernel at 4×4 cannot be resolved: every λ_min is at the 1e-7 level, below the error, including the vector reference. |

**Route 3.** The F4-L2 lemma ("a far-wall zero or a gapless composite") is NOT CONFIRMED (refereed). Only a conditional pole–zero alternative survives. F4-L3 and X1 Lemma E are also not confirmed. §2 and §3 above overstate route 3.

**What changed (reading).**
- **Corners as generations is the weak point of X2, not its chirality mechanism.** CKM conflicts with the corner-label protection: carriers at the electroweak scale run into FCNC, and breaking translations at the lattice scale brings in LV tuning.
- **The best placement found is X2′:** generations as an internal label at Γ. Its remaining bill is Lorentz-violation tuning of the same class the framework already owes for gravity's matter light cones. One owner decision would cover both.
- **The mirror-gapping danger (GPR) is now the binding open question for route 2,** and the simulation leans against it at pilot sizes.
- **Route 1 is parked at 2D-proxy scope.** A legitimate measure now exists; deciding its sign needs lattices larger than this machine can run.
- **The record rules are safe at main's neutral setting.** A strongly repulsive record gas would freeze matter into a chessboard.

**Did the campaign crack the wall? No.** It moved route 2's obstacle away from flavour and onto symmetric mass generation, and left route 1 needing lattices beyond this machine.

**Same-family referee corrections to §8 (10-17).**
- QMC-1b: no filter dependence was detected, and none is excluded.
- TOR-1's Wilson side finding is withdrawn.
- GEN-1: the two-sided n is 1, and X2′ also needs Θ (or about 1e-40 tuning) for a dimension-3 flavour offset.
- GEN-2: n exceeds GEN-1's (suggested), not "≥ 7".
- LOCK-1: main's bond-rate notes have conditional period-2 instabilities. A chessboard removes protection but does not prove a gap.

See TESTS.md, "Same-family referees".
