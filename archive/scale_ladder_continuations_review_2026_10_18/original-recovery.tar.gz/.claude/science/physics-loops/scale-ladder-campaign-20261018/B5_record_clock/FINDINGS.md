# B5 findings: the hidden phase-reference hypothesis for Record-apparatus tolerances

Provenance: a worker of the same model family; not reviewed. Saved by the supervisor from the hand-back. 12 of 13 pre-declared checks pass; P7a (random-direction mediator slope) failed because random directions cancel.

## Verdict

**Refuted for the certified tolerances (1e−13 bond, 1e−26 onsite).** It holds only in a narrower form that the repo already handles as a premise.

## Device and arithmetic

- **Device:** the mediated-source complete-output device (PRs #9695 and #9696). No dynamics runner exists in the repo, so reduced devices D1 and D2 were built.
- **Repo metric:** complete-output with literal phase, but against the **actual** scalar e^{−itC(w)}. "Phase knowledge" is a stated premise.
- **Arithmetic (7/7 PASS).**
  - M, T and λ are confounded within the certified family.
  - tol·M differs by a factor of 260 between the structured and mediated devices, so 1e−13 ≈ 1/M is a coincidence.
  - The mediated bond increment is < 5.3e6·ε, a constant: 1e−13 is a budget choice, and ε ≈ 1e−10 would still do.
  - The onsite increment is 422·ξ/λ.
  - With a nominal clock instead, ε would need to be ≲ 7e−22, scaling as 1/(ΣW·T).

## Reduced-device scalings

| Error | Repo metric | Populations | Nominal clock | Co-transported reference |
|---|---|---|---|---|
| Source bonds | flat (≈7.6e−3); adversarial mediator gives 1e−2/(2n+1) | flat | ∝ 1/T | same as repo metric |
| Source onsite | ∝ λ (≈0.0048·λ) | ≈0.19·λ, second order | — | same as repo metric |
| Receiver errors | ∝ T^−0.4…−0.5 (time of flight) | — | — | cancelled exactly |
| Global onsite | ∝ 1/T | invisible | ∝ 1/T | — |

## What a relational reference would do

A reference co-transported inside the same apparatus would:
- share the scalar C(w), so it could replace the phase-knowledge premise;
- cancel receiver errors.

It would not relax the source tolerances. The onsite ∝ λ requirement needs a self-referenced emitter.

## Caveats

- Reduced models only, with λ/g ≥ 5e−3 (the repo is at about 6e−11).
- Budget 1e−2.
- Single-excitation pure states.
