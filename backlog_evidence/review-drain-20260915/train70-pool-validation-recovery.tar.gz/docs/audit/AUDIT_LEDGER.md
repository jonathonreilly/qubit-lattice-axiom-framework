# Audit Ledger

**Source of truth:** `data/ledger/<claim-id-prefix>/<claim-id>.json` plus `data/ledger_meta.json`
**Schema:** see [README.md](README.md), [FRESH_LOOK_REQUIREMENTS.md](FRESH_LOOK_REQUIREMENTS.md), and [ALGEBRAIC_DECORATION_POLICY.md](ALGEBRAIC_DECORATION_POLICY.md); archival handling: [STALE_NARRATIVE_POLICY.md](STALE_NARRATIVE_POLICY.md).

This file is auto-generated. Do not edit by hand. Apply audits via `scripts/apply_audit.py`, then re-run `scripts/compute_effective_status.py` and `scripts/render_audit_ledger.py`.

## Reading rule

- **Bold** = audit-ratified retained grade (`retained`, `retained_no_go`, `retained_bounded`).
- _Italic_ = clean but waiting on retained-grade chain closure (`retained_pending_chain`).
- ~~Strikethrough~~ = audit returned a non-retained verdict (`audited_failed`, `audited_conditional`, etc.). Archived failures remain non-authoritative history and cannot satisfy a live dependency chain.
- Plain = `open_gate`, `unaudited`, `audit_in_progress`, or `meta`.

Publication-facing tables MUST read `effective_status`; `claim_type` is the auditor-owned classification field.

## Summary

| effective_status | count |
|---|---:|
| unaudited | 4537 |
| meta | 376 |

| audit_status | count |
|---|---:|
| `unaudited` | 4913 |

| claim_type | count |
|---|---:|
| `bounded_theorem` | 3269 |
| `decoration` | 8 |
| `meta` | 376 |
| `no_go` | 355 |
| `open_gate` | 221 |
| `positive_theorem` | 684 |

| criticality | count |
|---|---:|
| `critical` | 738 |
| `high` | 339 |
| `medium` | 1186 |
| `leaf` | 2650 |

- **Retained pending chain closure:** 0
- **Citation cycles detected:** 60

### Runner classification (static heuristic)

- runners classified: 3850
- runners with (C) first-principles compute hits: 2008
- runners with (D) external comparator hits: 1255
- decoration candidates (no C, no D): 833

## Top 25 by load-bearing score (topology only)

Criticality and load-bearing score are computed from the citation graph alone. The audit lane intentionally does not use author-declared flagship status — that would let unratified framing drive audit cost on upstream support claims.

| # | claim_id | claim_type | criticality | desc | score | audit_status | effective |
|---:|---|---|---|---:|---:|---|---|
| 1 | `minimal_axioms` | meta | critical | 2316 | 383.18 | `unaudited` | meta |
| 2 | `three_generation_observable_theorem_note` | bounded_theorem | critical | 1193 | 57.22 | `unaudited` | unaudited |
| 3 | `observable_principle_from_axiom_note` | bounded_theorem | critical | 1002 | 53.97 | `unaudited` | unaudited |
| 4 | `graph_first_su3_integration_note` | positive_theorem | critical | 1545 | 52.09 | `unaudited` | unaudited |
| 5 | `kinetic_isotropy_primitive` | meta | critical | 888 | 48.80 | `unaudited` | meta |
| 6 | `plaquette_self_consistency_note` | bounded_theorem | critical | 1221 | 47.76 | `unaudited` | unaudited |
| 7 | `minimal_axioms_2026-05-03` | meta | critical | 1030 | 43.51 | `unaudited` | meta |
| 8 | `key_terminology` | meta | critical | 1273 | 43.31 | `unaudited` | meta |
| 9 | `staggered_dirac_realization_gate_note_2026-05-03` | bounded_theorem | critical | 973 | 38.43 | `unaudited` | unaudited |
| 10 | `staggered_dirac_substep4_ac_narrow_bounded_note_2026-05-07_substep4ac` | bounded_theorem | critical | 616 | 38.27 | `unaudited` | unaudited |
| 11 | `anomaly_forces_time_theorem` | bounded_theorem | critical | 1178 | 36.70 | `unaudited` | unaudited |
| 12 | `yt_ward_identity_derivation_theorem` | bounded_theorem | critical | 928 | 35.36 | `unaudited` | unaudited |
| 13 | `koide_circulant_character_derivation_note_2026-04-18` | bounded_theorem | critical | 624 | 34.79 | `unaudited` | unaudited |
| 14 | `cl3_color_automorphism_theorem` | bounded_theorem | critical | 842 | 34.22 | `unaudited` | unaudited |
| 15 | `axiom_first_reflection_positivity_theorem_note_2026-04-29` | bounded_theorem | critical | 710 | 32.97 | `unaudited` | unaudited |
| 16 | `native_gauge_closure_note` | positive_theorem | critical | 1506 | 32.56 | `unaudited` | unaudited |
| 17 | `alpha_s_derived_note` | bounded_theorem | critical | 1008 | 32.48 | `unaudited` | unaudited |
| 18 | `staggered_dirac_bz_corner_forcing_theorem_note_2026-05-07` | bounded_theorem | critical | 625 | 29.79 | `unaudited` | unaudited |
| 19 | `koide_circulant_q_two_thirds_algebraic_narrow_theorem_note_2026-05-10` | positive_theorem | critical | 835 | 29.71 | `unaudited` | unaudited |
| 20 | `charged_lepton_koide_cone_algebraic_equivalence_note` | positive_theorem | critical | 627 | 28.80 | `unaudited` | unaudited |
| 21 | `admissibility_dirac_kahler_shifted_origin_frame_gauge_nonuniform_hodge_overlap_bounded_theorem_note_2026-08-14` | bounded_theorem | critical | 49 | 28.64 | `unaudited` | unaudited |
| 22 | `cpt_exact_note` | positive_theorem | critical | 907 | 28.33 | `unaudited` | unaudited |
| 23 | `ckm_cp_phase_structural_identity_theorem_note_2026-04-24` | positive_theorem | critical | 846 | 27.73 | `unaudited` | unaudited |
| 24 | `yt_ew_color_projection_theorem` | no_go | critical | 960 | 27.41 | `unaudited` | unaudited |
| 25 | `koide_z3_equivariant_anticommuting_no_go_note_2026-05-16` | bounded_theorem | critical | 814 | 27.17 | `unaudited` | unaudited |


## Applied audits

_No audits applied yet._


## Audit findings (full)
