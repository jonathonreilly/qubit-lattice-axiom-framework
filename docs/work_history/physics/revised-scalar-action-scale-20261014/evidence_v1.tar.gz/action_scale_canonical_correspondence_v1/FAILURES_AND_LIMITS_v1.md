# Preserved failures, corrections and limits

There is no failed reviewer computation in this correspondence stage. The one
correspondence execution returned 405/0 and all four wrapper-only executions
returned their expected statuses. This does not erase earlier failures or imply
new independent physical validation.

The complete original evidence is captured under `source_snapshot`:

- Inverse source v1 omitted a nonrelativistic source restriction. A trace-free
  source need not excite the scalar. The author's v2 restricts the source/readout
  and preserves v1/protocol/execution. The staged body is that qualified v2;
  the unchanged 64 original rows still belong to the historical v1 execution.
- The earlier independent inverse numerical run returned exit 1 because three
  second-normal responses, already at roughly 1e-79 to 1e-77 at 80 digits, were
  required to show quadratic convergence. A separate exact diagnosis proved the
  central difference in that direction is algebraically exact. A fresh v2 test
  required absolute error below 1e-65 for that direction only. Original numeric
  values were unchanged; original run, diagnosis, patch and corrected run remain.
- Readout source v1 did not distinguish scalar excitation stress from constant
  vacuum energy and omitted the exterior-ray condition for a finite body's
  total-monopole lensing formula. Author v2 states both. Its parent equations and
  23 historical rows are unchanged. The staged body preserves the qualified v2.
- The earlier independent readout illustration wrongly combined equal physical
  masses, different k, fixed Q0 and equal raw lensing. Its first automated checks
  all passed because they tested normalized excesses, not Gstar(k). The separate
  correction holds observed m fixed and derives different physical masses
  `M_i=8 pi Q0(1+k_i)c^2 m`. The original erroneous derivation, original numeric
  source/output and all seven successful correction checks remain recoverable.
- The parent's packaging inspection initially guessed a MANIFEST filename for
  the old inverse receipt and raised FileNotFoundError. The retained
  `PARENT_SOURCE_SEAL_VERIFICATION_v1.json` documents this. The two old receipts
  embed their artifact lists; this review follows those actual schemas.

Older independent controls comprise three inverse, three readout and four scale
damaged-expression probes. They are not claimed to be runs of actually altered
producer source. Separately, the newly preserved canonical damaged scripts were
actually executed by the parent: background-first-jet damage 87/24, lensing-sign
damage 110/1, and action-prefactor damage 108/3, all exit 1. This review checks
their complete source/result/command correspondence and named witnesses without
rerunning them. The positive 111/0 staged execution is also reused evidence.

The scientific conclusion remains conditional on the supplied action, known
K/C/frame/trajectory for the first-jet inverse, local embedded curve scope,
specified weak static nonrelativistic sources and local-flat vacuum readout,
source geometry and calibration, and positive fixed action prefactor with an
unchanged variational domain. Finite precision can destroy useful conditioning
without changing exact uniqueness. No measured likelihood, selected action,
selected hierarchy or initial state, global nonlinear stability, rolling-to-local
matching, quantum equivalence, or universal observation no-go is established.

Only staged bytes are covered. A future copy, cache execution, committed tree or
archive requires its own exact delivery binding; this receipt does not supply it.
