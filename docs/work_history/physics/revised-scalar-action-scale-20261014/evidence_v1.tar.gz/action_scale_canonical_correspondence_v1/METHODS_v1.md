# Staged correspondence method

This is a focused correspondence check by `/root/direct_field_check`; `/root`
remains scientific author. It reuses the exact earlier independent derivation
checks and does not rerun the producer's symbolic or numerical science. All
writes are confined to this review directory. No repository, runtime, lock,
formal-audit, PR, or settings operation is part of the check.

The root is `/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go`.
The campaign pack is `.claude/science/physics-loops/revised-scalar-derivation-24h-20261013`
relative to that root. Source paths in both binding records are root-relative;
snapshot and evidence paths are relative to this review directory.

`capture_v1.py` copied 113 original files exactly before the comparison. It
included the complete original inverse/readout/scale units, their prior reviews,
nine staged packaging files, and the two declared canonical dependencies.
After the parent supplied actual altered canonical executions,
`capture_added_v2.py` first checked all 113 old pairs again, then captured 21
additional files. `SOURCE_BINDINGS_v1.json` remains unchanged;
`SOURCE_BINDINGS_v2.json` describes all 134 pairs. These are exact bytes, including
original failure records and historical source versions.

`check_correspondence_v1.py` uses only the Python standard library. It reads the
captured files and compares their hashes with the current originals. It neither
imports SymPy/mpmath nor imports any producer helper. The following operations
are distinct from a fresh scientific derivation:

1. For the inverse and readout reviews, follow the embedded `artifacts` and
   `sources` lists in their receipts. For the scale review, follow its explicit
   manifest and sources. Verify every artifact, source/recovery pair, report,
   closed inventory and declared exclusion. Do not invent a MANIFEST filename
   for the older receipt schema.
2. Remove only the first title from each original active proof, demote its
   remaining headings once, and apply the single explicitly declared status
   replacement. Compare each complete resulting body with the corresponding
   staged section. Save both bodies and empty correspondence diffs. The declared
   body hashes include one final newline.
3. Parse each original and staged runner with Python AST. Compare all scientific
   statements, recursively and without location attributes. The original
   zero-based top-level slices are `[5:88]`, `[6:41]`, and `[8:25]` for inverse,
   readout and scale. They contain 83, 35 and 17 statements. Compare these with
   each staged function's body before its new return statement. Save complete
   AST dumps, slice provenance, return expressions and empty AST diffs.
4. Normalize only the inverse boolean key `pass` to `passed` and prepend the unit
   name to each check name. Compare all 111 ordered row dictionaries, including
   residual strings, details and deliberately nonzero-expression fields. Compare
   every inverse/readout substantive table and the rolling example separately.
   Check historical source hashes against their historical v1 sources, rather
   than attributing those old executions to the later qualified prose.
5. Compare each actual damaged script with precisely one protocol replacement
   in the captured canonical script. Reconstruct the diff independently, bind
   its script and result hashes to the execution record, read every row, and
   verify counts, named witnesses, stdout, stderr and exit code. These actual
   parent executions are inspected and reused, not rerun or credited to this
   reviewer.
6. Extract the exact new main/CLI block and run it in four small independent
   programs whose three scientific functions are replaced by explicit stubs.
   Test all-pass and one failure in each unit. This executes only aggregation,
   normalization, output identity and exit behavior; it does not recompute any
   science. Preserve each generated program, command, stdout, stderr and result.

The implementation produced 405 passing and zero failing correspondence
assertions. These counts include identity and packaging checks; they are not 405
independent physical controls. The four wrapper runs each have three synthetic
rows and must not be confused with the producer's 111 scientific rows.

The full staged note, runner, three active original derivations and runners,
three earlier independent reports, source correction notes, prior failure logs,
protocols, declared dependency notes, lineage, actual-damage protocol/diffs and
execution summaries were read. All saved science rows and tables were consumed
as complete JSON objects by the checker. The other prior evidence files were
bound by exact identity and interpreted through their full existing reports;
their original computations were not replayed or silently counted as new work.

No empirical data, external source or later scientific block was accessed.
There is no new calibration, parameter fit or asserted independent observation
test. The staged declared input paths point to intended canonical destinations;
this check does not establish a live canonical cache or delivery identity.
