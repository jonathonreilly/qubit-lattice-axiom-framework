# Focused staged action/scale correspondence review

Reviewer: `/root/direct_field_check`. Scientific author: `/root`.
Scope: the staged action/inverse/readout/scale canonical port, with exact reuse
of the three prior independent source reviews. This is not a formal audit or a
new review of the entire campaign.

No unresolved correspondence or scientific-scope correction was found. The
complete three proof bodies match the declared transformations; all 135
scientific AST statements match; all 111 saved scientific check rows and every
substantive inverse/readout table match. The new packaging retains the earlier
source and checker corrections. The conclusion applies to the captured staged
files, not a live canonical cache, committed tree or delivered archive.

## Exact source and recovery boundary

The worktree is
`/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go`.
The pack is `.claude/science/physics-loops/revised-scalar-derivation-24h-20261013`
relative to that root. All reviewer writes are under
`action_scale_canonical_correspondence_v1` in that pack.

The two staged scientific paths under `action_scale_packaging/staged` are:

| File | SHA-256 |
| --- | --- |
| `EXPONENTIAL_SCALAR_ACTION_SCALE_BOUNDED_THEOREM_NOTE_2026-10-14.md` | `b54006b786e57dba1b2b5115f96d460485c9b9a86c6afb3ea275401ad3f12a25` |
| `exponential_scalar_action_scale_check.py` | `e1946b6c429f633520b7e39895e8652e5a1cddefcbd8ad81b11fdcad8758ae2a` |

The active original proof sources are:

| Source within pack | SHA-256 |
| --- | --- |
| `inverse_action/DERIVATION_v2.md` | `893fc65b3fb67e6c6676fa51b683b271cbc959b371bd2b443ed6a5007e96dcf4` |
| `inverse_action/READOUT_DERIVATION_v2.md` | `dbaf6dbf90e90e7744e3ae61dbf0ee65a5b2485106c6fe175a88bf116f02d139` |
| `scale_selection/DERIVATION_v1.md` | `a2db5082da526ecdd0b471e5f32176df411aa2f29220122f59854f3b3c2db178` |

`SOURCE_BINDINGS_v1.json` captured 113 originals. Its hash is
`4653829d551a8eb479bd14e9125d71dfbf24ceb31ff280e0b5d6c50b6b4c4799`.
`SOURCE_BINDINGS_v2.json` reverified those bytes and added 21 newly supplied
actual-damage/output-correspondence files, for 134 exact original/snapshot pairs.
Its hash is `91e1cf15d34bd023bac1bb8ef5325984a67903851578eccbdd949a2662e1d4cd`.
The first binding is not overwritten. Every current original and exact snapshot
was independently checked against these pins.

The complete reviewer-owned constituent map is
`correspondence_run01/SOURCE_DISPOSITIONS.json`, whose `original_dispositions`
array contains all 134 originals, SHA-256 values, recovery paths and currently
checked final paths/hashes. Here “final” means the checked original or staged
path. It does not assert that an intended canonical destination has been copied,
run, committed or delivered. All historical versions and failures remain in the
captured original trees.

## Proof-body and implementation correspondence

The staged note's wrapper accurately states conditional support, supplied action
and readout premises, exposed synthetic development, no measured likelihood, and
no unique action/scale selection. It links the exact complete-action and
local-response dependencies captured by this review. It does not treat a third
synthetic radius/scale as an independent observation.

For each of Parts I–III I independently removed only the first original title,
demoted the remaining headings once, and made the one declared provisional-status
replacement. Each full resulting body is byte-identical to its staged part.
The complete expected/staged bodies and empty diffs are saved in
`correspondence_run01/body_*`; `NOTE_CORRESPONDENCE.json` binds the transformations
and declared body hashes. The replacements say that independent checking has
occurred within the stated scope; they do not grant a new audit grade.

The original top-level scientific statements compare recursively equal to the
staged function bodies after excluding only the new return statement:

| Unit | Original source | Statements | Result |
| --- | --- | ---: | --- |
| inverse | `inverse_action/check_inverse_v1.py` | 83 | Exact AST equality |
| readout | `inverse_action/check_readout_v1.py` | 35 | Exact AST equality |
| scale | `scale_selection/check_scale_selection_v1.py` | 17 | Exact AST equality |

The complete AST dumps, slice locations, return expressions and empty diffs are
saved in `correspondence_run01/AST_*` and `AST_CORRESPONDENCE.json`. The imports
and symbolic/numeric library aliases remain suitable for those bodies. Function
localization does not change their helper closures or scientific inputs. Removed
wrappers concern historical path/hash/date/output handling; their original
versions and results are retained. The new returns preserve all scientific tables.

The fresh staged result has 64 inverse, 23 readout and 24 scale rows: 111/0.
Normalizing only `pass` to `passed` for inverse rows and prefixing each name with
its unit reproduces all 111 ordered dictionaries exactly, including residuals,
details and deliberately nonzero-expression fields. The three inverse synthetic
rows, full rolling example (curve, H, potential, deformation and Hessian), and
three readout synthetic rows are exact, without rounding or table reduction.
The scale body has no additional substantive table. Complete paired objects are
saved in `COMPLETE_ROW_CORRESPONDENCE.json` and
`SUBSTANTIVE_OUTPUT_CORRESPONDENCE.json`.

Staged stdout is byte-identical to the saved result JSON; stderr is empty. Its
result self-hash, command path and exit-zero execution bind the captured runner.
Historical inverse/readout executions still bind their original v1 prose and
protocols; this review does not rewrite that provenance as a v2 execution merely
because later source qualifications were adopted in the staged note.

## Scientific interactions and limits retained

The first-jet inverse presupposes known K, C, a field curve, clock and frame
conversion as well as H and matter. Its gradient/value compatibility uses the
same fluid exchange and Raychaudhuri equations. It does not infer those hidden
inputs from expansion alone. The exactly unchanged potential value/gradient
along a regular embedded curve preserves that specified background; the normal
Hessian freedom can change perturbations. The local extension and tangent-kernel
arguments are not promoted to a global recurrent-curve result or stability proof.
The stationary-vacuum nu family is an explicit special case, not a statement
that arbitrary rolling histories or convergence theorems survive changing nu.

The local measurement construction adds real premises: frozen vacuum, weak
nonrelativistic source with negligible pressure/stress, controlled local flatness,
known geometry, and the stated common environment. The corrected trace-free
exception remains explicit. The scalar excitation stress is quadratic beyond
the constant vacuum term; the latter is still part of the curved background.
For finite bodies, the lensing impact parameter and dynamical radii must be
exterior or receive a profile correction. The unknown finite-body scalar form
factor cannot be silently absorbed into an independently measured k.

The lensing sum cancels the Yukawa scalar at the stated order; acceleration
contains the extra derivative factor `(1+mu r)`. The two-radius positive excess
ratio identifies a positive range parameter only under this ideal forward model.
Exact uniqueness is distinct from precision/conditioning. The nu=1, small-k
range/curvature comparison remains: a transition at `mu r~1` has `Hv r/c~1/4`,
which is not arbitrarily deep in the local-flat regime. No imported gamma sign
claim, empirical likelihood, rolling-environment match or actual PPN acceptance
was introduced by the port.

Part III is consistent with Part II's mass normalization. It explicitly varies
an UNKNOWN physical source mass together with Q0; it does not keep equal physical
masses while claiming equal raw lensing for different k or Q. The overall fixed
positive source-free coefficient cancels from stationary equations with a common
parameter-independent variational domain. That cancellation neither selects the
dimensionless hierarchy nor establishes equivalence of calibrated matter or
quantum theories. The vacuum Newton coefficient and expansion scale remain
conditional identifications, not automatic laboratory G or observed H0.

## Exact prior review reuse and preserved failures

All three complete prior independent reports were read. Their exact source
identities, artifact inventories and source/snapshot pairs were verified:

| Review within pack | Artifacts | Source pairs | Receipt SHA-256 |
| --- | ---: | ---: | --- |
| `inverse_action/independent_v1` | 29 | 4 | `e0b4a363c87df90d9c457283834dd2ccc692db88163b82b366767d7b3fe6eb1b` |
| `inverse_action/independent_readout_v1` | 25 | 4 | `ad7de048147b50b7bff3106f109de1113b667b57ea65446387444bedb700b2ee` |
| `scale_selection/independent_v1` | 14 | 2 | `e49e431864b8b853bd4dae9b5288a9109ce3f4787be19d91c87bebe8921c7dc9` |

The first two receipts embed their artifact and source lists; the scale receipt
references a separate manifest. `REUSED_SEALS.json` records these actual schemas,
report hashes and exclusions. All 68 artifacts and ten source pairs match. This
is exact reuse of those independent checks, not a new execution or independent
replication of their computations.

The original inverse scope correction, failed 80-digit convergence criterion,
exact roundoff diagnosis and separately corrected criterion remain preserved.
The original readout source qualifications and independent checker's
equal-mass/equal-lensing mistake also remain explicit. That latter illustration
was corrected to different physical masses at fixed observed monopole, while its
original passing-but-incomplete controls remain recoverable. The parent packaging
inspection's guessed-MANIFEST FileNotFoundError remains documented. None is
erased by the staged 111/0 result. `FAILURES_AND_LIMITS_v1.md` provides the full
chronology and source pointers.

## Failure sensitivity and new wrapper checks

The earlier independent three inverse, three readout and four scale damage
probes evaluated damaged expressions. They are not retrospectively described as
executions of altered producer programs. The new canonical damage evidence is
different and was verified as such:

| Actual parent source mutation | Passed / failed | Required witness | Exit |
| --- | ---: | --- | ---: |
| quadratic zero-first-jet deformation replaced by `f[0]` | 87 / 24 | `inverse::rolling_scalar_U1_1` | 1 |
| sign of the scalar term in Psi reversed | 110 / 1 | `readout::Weyl_potential` | 1 |
| `Xi=Q/H**2` replaced by `Xi=Q/H` | 108 / 3 | `scale::four_dimensional_action_scaling` | 1 |

Each script is exactly the single declared replacement in the frozen staged
source. Independently reconstructed diffs match; the execution records, result
self-hashes, complete row inventories, stdout and empty stderr agree. Every named
witness fails. `ACTUAL_DAMAGE_CORRESPONDENCE.json` records every changed row and
all failed row names. These parent executions were inspected, not rerun.

I separately executed the exact new main/CLI block with small independent stub
functions: all-pass, inverse failure, readout failure and scale failure. It
preserves row namespaces, inverse-key normalization, unit outputs and source
identity, writes the result, and returns exit 1 for a failure in any unit. The
all-pass case exits zero. All four programs, commands and streams are preserved.
No SymPy/mpmath or producer science body is imported or executed by these tests.

## Result and seal

The independent stdlib correspondence program completed once: 405 assertions
passed, zero failed. These are identity, correspondence and wrapper assertions,
not 405 new physical tests. There were no failed reviewer computations in this
stage. Large tool displays were narrowed when truncated; those display limits
were not scientific failures or grounds for claiming an unread source was read.

`METHODS_v1.md` gives the complete recipe and read/identity coverage;
`COMMANDS_v1.md` and `CORRESPONDENCE_*_v1` record the actual execution;
`correspondence_run01/RESULTS.json` contains all assertions. The reviewer-owned
constituent map is `correspondence_run01/SOURCE_DISPOSITIONS.json`. `MANIFEST_v1.json`
binds the complete review artifact set and `RECEIPT_v1.json` binds this report,
manifest, source bindings and disposition map. The receipt sidecar records its
final SHA-256 without a self-hash cycle.

All inherited and current scope qualifications remain necessary. This receipt
supplies no formal grade promotion, empirical acceptance, selected action/state/
scale, or post-delivery identity. No parent source, prior seal, runtime, Git, PR,
lock, settings or audit state was modified.
