#!/usr/bin/env python3
"""Append new actual-damage evidence to a separate freeze; keep v1 intact."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
old = json.loads((OUT / "SOURCE_BINDINGS_v1.json").read_text())
def digest(b):
    return hashlib.sha256(b).hexdigest()
for row in old["sources"]:
    assert digest((ROOT / row["original_path"]).read_bytes()) == row["sha256"]
    assert digest((OUT / row["snapshot_path"]).read_bytes()) == row["sha256"]
files = list((PACK / "action_scale_packaging/damages_v1").rglob("*"))
files.append(PACK / "action_scale_packaging/PARENT_STAGED_OUTPUT_CORRESPONDENCE_v1.json")
added = []
for src in sorted(p for p in files if p.is_file() and not p.is_symlink()):
    data = src.read_bytes()
    rel = src.relative_to(ROOT).as_posix()
    dst = OUT / "source_snapshot" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open("xb") as f:
        f.write(data)
    added.append({"original_path": rel, "snapshot_path": dst.relative_to(OUT).as_posix(),
                  "sha256": digest(data), "bytes": len(data)})
record = {"created_utc": datetime.now(timezone.utc).isoformat(),
          "initial_binding_path": "SOURCE_BINDINGS_v1.json",
          "initial_binding_sha256": digest((OUT / "SOURCE_BINDINGS_v1.json").read_bytes()),
          "initial_source_count": len(old["sources"]), "initial_sources_reverified": True,
          "added_source_count": len(added), "source_count": len(old["sources"]) + len(added),
          "sources": old["sources"] + added,
          "scope": "Initial freeze plus actual altered canonical runs and parent output comparison; no producer science rerun.",
          "parent_sources_modified": False, "science_executed": False}
with (OUT / "SOURCE_BINDINGS_v2.json").open("x") as f:
    json.dump(record, f, indent=2)
    f.write("\n")
print(json.dumps({"initial_sources_reverified": len(old["sources"]), "added": len(added),
                  "total": record["source_count"],
                  "binding_sha256": digest((OUT / "SOURCE_BINDINGS_v2.json").read_bytes())}))
