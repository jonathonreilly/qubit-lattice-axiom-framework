#!/usr/bin/env python3
"""Freeze the scoped staged and original sources, without executing them."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
files = []
for unit in ["inverse_action", "scale_selection"]:
    files += [p for p in (PACK / unit).rglob("*") if p.is_file() and not p.is_symlink()
              and "__pycache__" not in p.parts and p.suffix != ".pyc"]
for name in ["CANONICAL_LINEAGE_v1.json", "PARENT_SOURCE_SEAL_VERIFICATION_v1.json",
             "STAGED_COMMAND_v1.json", "STAGED_EXECUTION_v1.json", "STAGED_RESULTS_v1.json",
             "STAGED_stderr_v1.txt", "STAGED_stdout_v1.txt",
             "staged/EXPONENTIAL_SCALAR_ACTION_SCALE_BOUNDED_THEOREM_NOTE_2026-10-14.md",
             "staged/exponential_scalar_action_scale_check.py"]:
    files.append(PACK / "action_scale_packaging" / name)
files += [ROOT / "docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md",
          ROOT / "docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md"]
rows = []
for src in sorted(set(files)):
    rel = src.relative_to(ROOT).as_posix()
    data = src.read_bytes()
    dst = OUT / "source_snapshot" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open("xb") as f: f.write(data)
    rows.append({"original_path": rel, "snapshot_path": dst.relative_to(OUT).as_posix(),
                 "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
record = {"created_utc": datetime.now(timezone.utc).isoformat(), "source_count": len(rows), "sources": rows,
          "scope": "Original inverse/readout/scale source and evidence plus nine staged packaging files and two exact canonical dependencies. Later canonical damages are not part of this initial freeze.",
          "parent_sources_modified": False, "science_executed": False}
with (OUT / "SOURCE_BINDINGS_v1.json").open("x") as f: json.dump(record, f, indent=2); f.write("\n")
print(json.dumps({"source_count": len(rows), "binding_sha256": hashlib.sha256((OUT / "SOURCE_BINDINGS_v1.json").read_bytes()).hexdigest()}))
