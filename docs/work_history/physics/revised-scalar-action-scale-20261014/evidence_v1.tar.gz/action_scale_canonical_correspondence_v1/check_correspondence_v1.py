#!/usr/bin/env python3
"""Independent byte/AST/output correspondence. Never executes producer science."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
PKREL = PACK.relative_to(ROOT)
RUN = OUT / "correspondence_run01"
RUN.mkdir(exist_ok=False)
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def add(name, passed, detail=None):
    checks.append({"name": name, "passed": bool(passed), "detail": detail})

def save(name, value):
    p = RUN / name
    p.parent.mkdir(parents=True, exist_ok=True)
    data = value if isinstance(value, str) else json.dumps(value, indent=2, ensure_ascii=False) + "\n"
    with p.open("x") as f:
        f.write(data)
    return {"path": p.relative_to(OUT).as_posix(), "sha256": sha(p.read_bytes()), "bytes": p.stat().st_size}

def snap(rel):
    return OUT / "source_snapshot" / rel

def unitpath(rel):
    return snap(PKREL / rel)

def jload(p):
    return json.loads(p.read_text())

bindings = jload(OUT / "SOURCE_BINDINGS_v2.json")
add("freeze_census", bindings["source_count"] == len(bindings["sources"]) == 134)
for row in bindings["sources"]:
    b = (OUT / row["snapshot_path"]).read_bytes()
    live = (ROOT / row["original_path"]).read_bytes()
    add("source:" + row["original_path"], sha(b) == row["sha256"] == sha(live) and len(b) == row["bytes"])

# Three prior reviewer units use two distinct, explicitly inspected seal schemas.
pins = {
    "inverse_action/independent_v1": "e0b4a363c87df90d9c457283834dd2ccc692db88163b82b366767d7b3fe6eb1b",
    "inverse_action/independent_readout_v1": "ad7de048147b50b7bff3106f109de1113b667b57ea65446387444bedb700b2ee",
    "scale_selection/independent_v1": "e49e431864b8b853bd4dae9b5288a9109ce3f4787be19d91c87bebe8921c7dc9",
}
seals = []
for unit, expected in pins.items():
    base = unitpath(unit)
    receipt = jload(base / "RECEIPT_v1.json")
    add(unit + ":receipt_pin", sha((base / "RECEIPT_v1.json").read_bytes()) == expected)
    if "artifacts" in receipt:
        artifacts = receipt["artifacts"]
        excluded = receipt["self_hash_exclusion"]
        schema = "embedded_artifacts_and_sources"
        manifest_hash = None
    else:
        mp = base / receipt["manifest_path"]
        manifest = jload(mp)
        add(unit + ":manifest_pin", sha(mp.read_bytes()) == receipt["manifest_sha256"])
        add(unit + ":report_pin", sha((base / receipt["report_path"]).read_bytes()) == receipt["report_sha256"])
        artifacts = manifest["artifacts"]
        excluded = manifest["excluded_self_and_receipt_files"]
        schema = "separate_manifest"
        manifest_hash = sha(mp.read_bytes())
    actual = sorted(p.relative_to(base).as_posix() for p in base.rglob("*")
                    if p.is_file() and p.relative_to(base).as_posix() not in excluded)
    add(unit + ":closed_inventory", actual == sorted(r["path"] for r in artifacts))
    add(unit + ":artifact_count", len(artifacts) == receipt["artifact_count"])
    for row in artifacts:
        b = (base / row["path"]).read_bytes()
        add(unit + ":artifact:" + row["path"], len(b) == row["bytes"] and sha(b) == row["sha256"])
    for row in receipt["sources"]:
        b = snap(row["original_path"]).read_bytes()
        recovery = (base / row["snapshot_path"]).read_bytes()
        add(unit + ":source_pair:" + row["original_path"], b == recovery and sha(b) == row["sha256"] and len(b) == row["bytes"])
    seals.append({"unit": unit, "receipt_sha256": expected, "schema": schema,
                  "manifest_sha256": manifest_hash, "artifacts": len(artifacts),
                  "source_pairs": len(receipt["sources"]),
                  "report_sha256": sha((base / "REPORT_v1.md").read_bytes()),
                  "excluded_paths": excluded, "reused_not_rerun": True})
save("REUSED_SEALS.json", seals)

stage = unitpath("action_scale_packaging/staged")
note_name = "EXPONENTIAL_SCALAR_ACTION_SCALE_BOUNDED_THEOREM_NOTE_2026-10-14.md"
runner_name = "exponential_scalar_action_scale_check.py"
note = (stage / note_name).read_text()
runner = (stage / runner_name).read_text()
lineage = jload(unitpath("action_scale_packaging/CANONICAL_LINEAGE_v1.json"))
add("note_declared_hash", sha(note.encode()) == lineage["note_sha256"])
add("runner_declared_hash", sha(runner.encode()) == lineage["runner_sha256"])
markers = ["## I. Potential first-jet reconstruction and exact degeneracy\n",
           "## II. Ideal lensing and dynamical readout\n",
           "## III. Classical scale nonselection\n"]
body_records = []
for i, row in enumerate(lineage["note_bodies"]):
    raw = unitpath(row["source"]).read_text()
    old, new = row["explicit_replacement"]
    add("note_source_pin:" + row["source"], sha(raw.encode()) == row["source_sha256"])
    add("single_status_replacement:" + row["source"], raw.count(old) == 1)
    body = raw.split("\n", 1)[1].strip().replace(old, new)
    body = "\n".join("#" + line if line.startswith("#") else line for line in body.split("\n")) + "\n"
    candidate = note.split(markers[i], 1)[1]
    if i + 1 < len(markers):
        candidate = candidate.split(markers[i + 1], 1)[0]
    candidate = candidate.strip() + "\n"
    add("full_note_body:" + row["source"], candidate == body and sha(body.encode()) == row["body_sha256"])
    source_file = save("body_%s_expected.md" % i, body)
    final_file = save("body_%s_staged.md" % i, candidate)
    diff = "".join(difflib.unified_diff(body.splitlines(True), candidate.splitlines(True), fromfile="expected", tofile="staged"))
    save("body_%s.diff" % i, diff)
    body_records.append({"source": row["source"], "expected": source_file, "staged": final_file,
                         "byte_equal": body == candidate, "status_replacement": row["explicit_replacement"]})
save("NOTE_CORRESPONDENCE.json", body_records)

# Compare every scientific AST statement, rather than calling any author helper.
tree = ast.parse(runner)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
source_specs = [
    ("inverse", "inverse_action/check_inverse_v1.py", 5, 88),
    ("readout", "inverse_action/check_readout_v1.py", 6, 41),
    ("scale", "scale_selection/check_scale_selection_v1.py", 8, 25),
]
ast_records = []
for name, source, start, end in source_specs:
    oldtree = ast.parse(unitpath(source).read_text())
    old_nodes = oldtree.body[start:end]
    new_nodes = functions["check_" + name].body[:-1]
    olddump = ast.dump(ast.Module(body=old_nodes, type_ignores=[]), include_attributes=False, indent=2) + "\n"
    newdump = ast.dump(ast.Module(body=new_nodes, type_ignores=[]), include_attributes=False, indent=2) + "\n"
    add("entire_science_AST:" + name, olddump == newdump)
    add("return_wrapper:" + name, isinstance(functions["check_" + name].body[-1], ast.Return))
    oldfile = save("AST_%s_original.txt" % name, olddump)
    newfile = save("AST_%s_staged.txt" % name, newdump)
    save("AST_%s.diff" % name, "".join(difflib.unified_diff(olddump.splitlines(True), newdump.splitlines(True), fromfile="original", tofile="staged")))
    ast_records.append({"unit": name, "source": source, "original_top_level_slice": [start, end],
                        "statements": len(old_nodes), "byte_equal_AST": olddump == newdump,
                        "original_AST": oldfile, "staged_AST": newfile,
                        "new_return_statement": ast.unparse(functions["check_" + name].body[-1])})
save("AST_CORRESPONDENCE.json", ast_records)

original_results = {
    "inverse": jload(unitpath("inverse_action/evidence_v1/RESULTS.json")),
    "readout": jload(unitpath("inverse_action/readout_evidence_v1/RESULTS.json")),
    "scale": jload(unitpath("scale_selection/evidence_v1/RESULTS.json")),
}
staged_result = jload(unitpath("action_scale_packaging/STAGED_RESULTS_v1.json"))
normalized = []
comparisons = []
for name in ["inverse", "readout", "scale"]:
    old = original_results[name]
    for row in old["checks"]:
        new = dict(row)
        if "pass" in new:
            new["passed"] = new.pop("pass")
        new["name"] = name + "::" + new["name"]
        normalized.append(new)
    add("unit_count:" + name, staged_result["units"][name] == {"passed": old["passed"], "failed": old["failed"]})
    if "source_hashes" in old:
        for source in old["source_hashes"]:
            add("historical_execution_pin:" + name + ":" + source["path"],
                sha(unitpath("inverse_action/" + source["path"]).read_bytes()) == source["sha256"])
    else:
        add("historical_scale_note_pin", sha(unitpath("scale_selection/DERIVATION_v1.md").read_bytes()) == old["source_sha256"])
        add("historical_scale_code_pin", sha(unitpath("scale_selection/check_scale_selection_v1.py").read_bytes()) == old["script_sha256"])
add("complete_ordered_row_census", len(normalized) == len(staged_result["checks"]) == 111)
for i, (old, new) in enumerate(zip(normalized, staged_result["checks"])):
    add("saved_row:" + old["name"], old == new)
    comparisons.append({"index": i, "name": old["name"], "equal": old == new, "normalized_original": old, "staged": new})
add("all_ordered_rows_exact", normalized == staged_result["checks"])
expected_outputs = {
    "inverse": {key: original_results["inverse"][key] for key in ["synthetic_examples", "rolling_example"]},
    "readout": {"synthetic": original_results["readout"]["synthetic"]}, "scale": {},
}
add("all_substantive_outputs_exact", staged_result["substantive_outputs"] == expected_outputs)
add("combined_census", staged_result["passed"] == 111 and staged_result["failed"] == 0
    and sum(row["passed"] for row in staged_result["checks"]) == 111)
add("staged_result_runner_pin", staged_result["checker_sha256"] == sha(runner.encode()))
add("staged_stdout_identical", unitpath("action_scale_packaging/STAGED_stdout_v1.txt").read_bytes()
    == unitpath("action_scale_packaging/STAGED_RESULTS_v1.json").read_bytes())
add("staged_stderr_empty", unitpath("action_scale_packaging/STAGED_stderr_v1.txt").stat().st_size == 0)
execution = jload(unitpath("action_scale_packaging/STAGED_EXECUTION_v1.json"))
command = jload(unitpath("action_scale_packaging/STAGED_COMMAND_v1.json"))
add("staged_command_execution", execution["exit_code"] == 0 and execution["argv"] == command["argv"]
    and execution["argv"][2] == str(PACK / "action_scale_packaging/staged" / runner_name))
save("COMPLETE_ROW_CORRESPONDENCE.json", comparisons)
save("SUBSTANTIVE_OUTPUT_CORRESPONDENCE.json", {"all_equal": expected_outputs == staged_result["substantive_outputs"],
     "expected": expected_outputs, "staged": staged_result["substantive_outputs"]})

# Inspect and verify actual parent damaged executions; these are reused evidence.
damage_base = unitpath("action_scale_packaging/damages_v1")
protocol = jload(damage_base / "PROTOCOL_v1.json")
summary = jload(damage_base / "SUMMARY_v1.json")
damages = []
expected_counts = {"background_first_jet": (87, 24), "lensing_sign": (110, 1), "action_scale": (108, 3)}
for index, (name, before, after, witness) in enumerate(protocol["mutations"]):
    script = (damage_base / (name + ".py")).read_text()
    result = jload(damage_base / (name + "_RESULTS.json"))
    execution = jload(damage_base / (name + "_EXECUTION.json"))
    add("single_actual_mutation:" + name, runner.count(before) == 1 and script == runner.replace(before, after, 1))
    actual_diff = "".join(difflib.unified_diff(runner.splitlines(True), script.splitlines(True), fromfile="canonical", tofile=name))
    add("actual_diff_identity:" + name, actual_diff == (damage_base / (name + ".diff")).read_text())
    add("actual_execution_identity:" + name, execution == summary[index] and execution["script_sha256"] == sha(script.encode()) == result["checker_sha256"])
    failed = [r["name"] for r in result["checks"] if not r["passed"]]
    add("actual_failed_witness:" + name, witness in failed and failed == execution["failed_witnesses"])
    add("actual_failure_exit:" + name, execution["exit_code"] == 1 and (result["passed"], result["failed"]) == expected_counts[name]
        and result["failed"] == len(failed) and len(result["checks"]) == 111)
    add("actual_damage_stdout:" + name, (damage_base / (name + "_stdout.txt")).read_bytes() == (damage_base / (name + "_RESULTS.json")).read_bytes())
    add("actual_damage_stderr:" + name, (damage_base / (name + "_stderr.txt")).stat().st_size == 0)
    changed = [{"index": i, "original": a, "damaged": b} for i, (a, b) in enumerate(zip(staged_result["checks"], result["checks"])) if a != b]
    damages.append({"name": name, "expected_witness": witness, "failed_rows": failed, "changed_rows": changed,
                    "script_sha256": sha(script.encode()), "result_sha256": sha((damage_base / (name + "_RESULTS.json")).read_bytes()),
                    "counts": expected_counts[name], "exit_code": execution["exit_code"],
                    "reviewer_reran_this_science": False})
save("ACTUAL_DAMAGE_CORRESPONDENCE.json", damages)

# Exercise only the exact new CLI/aggregation wrapper with independent stubs.
# No symbolic or numerical scientific function is imported or executed here.
main = [n for n in tree.body if isinstance(n, ast.If) and ast.unparse(n.test) == "__name__ == '__main__'"]
add("single_main_wrapper", len(main) == 1)
main_source = ast.get_source_segment(runner, main[0]) + "\n"
save("EXACT_MAIN_WRAPPER.py.fragment", main_source)
wrapper_runs = []
for fail_name in [None, "inverse", "readout", "scale"]:
    tag = "all_pass" if fail_name is None else "fail_" + fail_name
    prologue = "from pathlib import Path\nimport json, hashlib, argparse\n"
    for unit in ["inverse", "readout", "scale"]:
        key = "pass" if unit == "inverse" else "passed"
        record = {"checks": [{"name": "stub", key: unit != fail_name, "detail": [unit, 7]}], "sentinel": unit}
        prologue += "def check_%s():\n    return %r\n" % (unit, record)
    program = RUN / ("wrapper_%s.py" % tag)
    with program.open("x") as f:
        f.write(prologue + main_source)
    output = RUN / ("wrapper_%s_RESULT.json" % tag)
    argv = [sys.executable, "-B", str(program), "--output", str(output)]
    proc = subprocess.run(argv, cwd=RUN, capture_output=True, text=True, timeout=10)
    save("wrapper_%s_stdout.txt" % tag, proc.stdout)
    save("wrapper_%s_stderr.txt" % tag, proc.stderr)
    obj = jload(output)
    add("wrapper_exit:" + tag, proc.returncode == (0 if fail_name is None else 1))
    add("wrapper_aggregate:" + tag, obj["passed"] == (3 if fail_name is None else 2) and obj["failed"] == (0 if fail_name is None else 1)
        and [r["name"] for r in obj["checks"]] == ["inverse::stub", "readout::stub", "scale::stub"]
        and obj["substantive_outputs"] == {u: {"sentinel": u} for u in ["inverse", "readout", "scale"]})
    add("wrapper_identity:" + tag, obj["checker_sha256"] == sha(program.read_bytes()) and json.loads(proc.stdout) == obj and not proc.stderr)
    wrapper_runs.append({"case": tag, "argv": argv, "returncode": proc.returncode, "expected_failed": fail_name,
                         "program_sha256": sha(program.read_bytes()), "output_sha256": sha(output.read_bytes())})
save("WRAPPER_EXECUTIONS.json", wrapper_runs)

dispositions = []
for row in bindings["sources"]:
    dispositions.append({"original_path": row["original_path"], "original_sha256": row["sha256"],
                         "disposition": "Retained byte-identically; captured for this staged-only correspondence review.",
                         "recovery": row["snapshot_path"], "final_path": row["original_path"],
                         "final_sha256": row["sha256"]})
save("SOURCE_DISPOSITIONS.json", {"paths_relative_to": str(ROOT), "recoveries_relative_to": str(OUT),
     "scope": "Final means currently checked original/staged path, not committed/live canonical delivery.",
     "original_dispositions": dispositions})
result = {"created_utc": datetime.now(timezone.utc).isoformat(), "kind": "staged_canonical_correspondence",
          "passed": sum(r["passed"] for r in checks), "failed": sum(not r["passed"] for r in checks),
          "checks": checks, "source_count": len(bindings["sources"]),
          "reused_prior_seals": seals, "scientific_rows_compared": len(normalized),
          "actual_parent_damaged_runs_verified_not_rerun": len(damages),
          "wrapper_only_runs": len(wrapper_runs), "producer_science_executed": False}
save("RESULTS.json", result)
print(json.dumps({k: result[k] for k in ["passed", "failed", "source_count", "scientific_rows_compared", "actual_parent_damaged_runs_verified_not_rerun", "wrapper_only_runs"]}))
raise SystemExit(bool(result["failed"]))
