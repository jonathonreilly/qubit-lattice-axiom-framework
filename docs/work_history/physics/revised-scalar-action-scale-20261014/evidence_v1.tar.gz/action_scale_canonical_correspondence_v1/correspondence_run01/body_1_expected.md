Parent derivation v2, independently checked within the stated conditional scope.
No new observational data are read, fit or tested.
This develops the missing measurement map in the potential-identifiability
block; it does not identify the actual local environment with the vacuum.

Take the same complete candidate action, an exact u=x=y=0 vacuum background,
and work to first order in a weak static nonrelativistic mass source, with
negligible pressure/stress. In a locally flat region relative to the vacuum
curvature and time scale, subtract the background metric. The sole linearly
matter-coupled mode has coupling squared k>0 and inverse length mu=m_u/c>0.
All following equations require the vacuum/frozen-background/linear-source
approximation; no finite-distance error bound for a rolling environment has
been supplied. In particular, a compact astronomical body can require a
form factor and realistic equilibrium; the point-source expressions below
refer to an ideal point mass, or a body with a justified negligible form
factor, and radii outside it.

Let m=Gstar M/c^2, with C=1 at the vacuum, and use positive dimensionless
weak potentials in g00=-(1-2Phi), gij=(1+2Psi)deltaij. The scalar Helmholtz
solution and conformal multiplication give

 Phi(r)=m/r [1+k exp(-mu r)],
 Psi(r)=m/r [1-k exp(-mu r)],
 W=(Phi+Psi)/2=m/r.                                    (1)

At this order the stress of the scalar excitation beyond the constant
vacuum-energy term is quadratic about the vacuum. The constant term still
contributes to the curved-background metric equations and is neglected only
within the stated local-flat approximation. These expressions do not insert
an independent anisotropic-stress function.
Null propagation depends on Phi+Psi. The weak light deflection of the point
source is the transverse integral of grad(Phi+Psi); its magnitude at impact
parameter b is

 theta(b)=4m/b.                                        (2)

The integral is taken along the unperturbed line in the local flat static
approximation. The de Sitter background is not globally asymptotically flat;
(2) is not an exact global-lensing formula or a statement about measured
distances without geometric control.

Slow massive tracers instead measure a_dyn/c^2=-dPhi/dr, so

 a_dyn(r)=c^2 m/r^2 [1+k(1+mu r)exp(-mu r)].             (3)

Inferring m=b theta/4 from the SAME isolated source, with known physical
b,r and the required local geometry, gives the dimensionless excess

 e(r)=4 r^2 a_dyn(r)/(c^2 b theta)-1
     =k F(mu r), F(x)=(1+x)exp(-x).                    (4)

Source-mass normalization cancels in this ideal comparison. No value of Gstar
or M is required by (4), but universal matter/light coupling, source geometry,
weak-source response and a common environment remain assumptions. A mass
profile independently fitted under the tested theory must not silently replace
the lensing determination. The phrase 'mass independent' here concerns this
normalization only, not a real extended profile or source-shape uncertainty.

For 0<r1<r2 and positive inferred excesses e1,e2, take the ratio

 R=e1/e2=F(mu r1)/F(mu r2).
 L(mu)=log R=log(1+mu r1)-log(1+mu r2)+mu(r2-r1).       (5)

Then L(0)=0, L->infinity as mu->infinity, and for mu>0

 L'(mu)=mu [r2^2/(1+mu r2)-r1^2/(1+mu r1)]>0.          (6)

The last sign follows because r^2/(1+mu r) increases strictly for r>0.
Therefore every exact R>1 determines a UNIQUE positive mu within this ideal
model, after which k=e1/F(mu r1). It is compatible with this action only if
0<k<1/3 and the separately calibrated Hv gives
nu=(1-3k)c^2 mu^2/(4Hv^2)-3(1+k)>0. R<1 is incompatible with this specific
single-mode attractive Yukawa readout; R=1 gives mu=0 as a limit, which is not
a finite positive-Hv member of the stated vacuum action. Finite measurement
error and unmodeled environment effects prevent interpreting a noisy ratio
alone as an exclusion. Zero or negative measured excesses also require an
uncertainty analysis, not the positive logarithmic inverse above.

A third-radius measurement predicts e3=k F(mu r3). It can test the shape only
if it was not used in model selection/calibration. No actual measured e_i
or observational uncertainty has been supplied in this calculation.

The mathematical uniqueness is poorly conditioned for a long range:

 F(mu r)=1-(mu r)^2/2+(mu r)^3/3+O((mu r)^4),
 L(mu)=mu^2(r2^2-r1^2)/2-mu^3(r2^3-r1^3)/3+O(mu^4).

Thus small differences, not simply precise agreement in an effective Newton
constant, are needed to determine the range. For nu=1 and small k,
mu is approximately4Hv/c. A range-sensitive transition near mu r=1 then has
Hv r/c about1/4, so a parametrically controlled local-flat treatment cannot
simultaneously assume that transition scale is arbitrarily far below the
vacuum curvature scale. On much shorter scales the mass signal is suppressed
quadratically. A full cosmological/curved-background readout, or an independently
justified much heavier scalar, is needed before using the transition as a
precision measurement. This scale comparison is conditional on nu=1 and small
k and supplies neither a new fitted nu nor an actual measurement.

A finite source need not have the point-source Yukawa charge M. For a prescribed
spherically symmetric density in the same linear approximation, the external
scalar charge is weighted by sinh(mu r')/(mu r'), whereas the tensor/lensing
monopole is M. The point-source cancellation then becomes e=k F_body(mu)F(mu r).
For this finite-body comparison the lensing impact parameter b and every
dynamical radius must lie outside the body; an interior light ray requires
a projected-profile correction to (2). At fixed common body, two-radius
ratios still cancel the unknown constant
amplitude and determine mu ideally, but the recovered amplitude determines
k F_body rather than k until source shape is known. This is an explicit
remaining source input, not permission to introduce a free screening factor.
Nonlinear density feedback, pressure or time dependence can further change
this statement and have not been absorbed into F_body by assumption.
