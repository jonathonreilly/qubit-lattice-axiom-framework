from pathlib import Path
import json, hashlib, argparse
def check_inverse():
    return {'checks': [{'name': 'stub', 'pass': True, 'detail': ['inverse', 7]}], 'sentinel': 'inverse'}
def check_readout():
    return {'checks': [{'name': 'stub', 'passed': False, 'detail': ['readout', 7]}], 'sentinel': 'readout'}
def check_scale():
    return {'checks': [{'name': 'stub', 'passed': True, 'detail': ['scale', 7]}], 'sentinel': 'scale'}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output');args=ap.parse_args()
    checks=[];units={};outputs={}
    for name,fn in [('inverse',check_inverse),('readout',check_readout),('scale',check_scale)]:
        result=fn();rows=result.pop('checks');normalized=[]
        for row in rows:
            item=dict(row)
            if 'pass' in item:item['passed']=item.pop('pass')
            normalized.append({**item,'name':name+'::'+item['name']})
        checks.extend(normalized);outputs[name]=result
        units[name]={'passed':sum(x['passed'] for x in normalized),'failed':sum(not x['passed'] for x in normalized)}
    result={'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'units':units,'substantive_outputs':outputs,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Conditional inverse and nonselection results; no observed fit or selected action/state/scale.'}
    if args.output:
        p=Path(args.output);assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
