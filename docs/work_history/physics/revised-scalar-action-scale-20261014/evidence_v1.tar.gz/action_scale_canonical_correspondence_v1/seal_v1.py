#!/usr/bin/env python3
"""Seal the completed review once, with no report/receipt self-reference."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    with (OUT / name).open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")

for name in ["FINAL_BINDING_VERIFICATION_v1.json", "MANIFEST_v1.json", "RECEIPT_v1.json", "RECEIPT_v1.sha256"]:
    assert not (OUT / name).exists(), name
bindings = json.loads((OUT / "SOURCE_BINDINGS_v2.json").read_text())
disposition_path = "correspondence_run01/SOURCE_DISPOSITIONS.json"
dispositions = json.loads((OUT / disposition_path).read_text())["original_dispositions"]
assert len(dispositions) == len(bindings["sources"]) == 134
verified = []
for row, disp in zip(bindings["sources"], dispositions):
    original = ROOT / row["original_path"]
    snapshot = OUT / row["snapshot_path"]
    assert original.read_bytes() == snapshot.read_bytes()
    assert digest(original) == digest(snapshot) == row["sha256"]
    assert disp["original_path"] == row["original_path"] == disp["final_path"]
    assert disp["original_sha256"] == disp["final_sha256"] == row["sha256"]
    assert disp["recovery"] == row["snapshot_path"]
    verified.append({"original_path": row["original_path"], "snapshot_path": row["snapshot_path"],
                     "final_path": disp["final_path"], "sha256": row["sha256"]})
result_path = "correspondence_run01/RESULTS.json"
result = json.loads((OUT / result_path).read_text())
assert result["passed"] == 405 and result["failed"] == 0
assert all(row["passed"] for row in result["checks"])
created = datetime.now(timezone.utc).isoformat()
write("FINAL_BINDING_VERIFICATION_v1.json", {
    "created_utc": created, "all_current_originals_match_snapshots_and_dispositions": True,
    "verified_source_count": len(verified), "bindings": verified,
    "source_bindings_v1_sha256": digest(OUT / "SOURCE_BINDINGS_v1.json"),
    "source_bindings_v2_sha256": digest(OUT / "SOURCE_BINDINGS_v2.json"),
    "source_dispositions_sha256": digest(OUT / disposition_path),
    "scope": "Staged/source identity only; no canonical live cache, commit or delivery assertion."})
excluded = ["MANIFEST_v1.json", "RECEIPT_v1.json", "RECEIPT_v1.sha256"]
artifacts = []
for path in sorted(OUT.rglob("*")):
    if path.is_file() and path.relative_to(OUT).as_posix() not in excluded:
        assert not path.is_symlink(), path
        artifacts.append({"path": path.relative_to(OUT).as_posix(),
                          "bytes": path.stat().st_size, "sha256": digest(path)})
manifest = {"schema": "focused_staged_correspondence_manifest_v1", "created_utc": created,
            "artifact_count": len(artifacts), "excluded_self_and_receipt_files": excluded,
            "artifacts": artifacts}
write("MANIFEST_v1.json", manifest)
receipt = {
    "schema": "focused_staged_canonical_correspondence_receipt_v1", "created_utc": created,
    "reviewer": "/root/direct_field_check", "scientific_author": "/root", "formal_audit": False,
    "scope": "Exact staged action/inverse/readout/scale port; prior science reused by identity, no live delivery assertion.",
    "report_path": "REPORT_v1.md", "report_sha256": digest(OUT / "REPORT_v1.md"),
    "manifest_path": "MANIFEST_v1.json", "manifest_sha256": digest(OUT / "MANIFEST_v1.json"),
    "artifact_count": len(artifacts),
    "source_bindings_path": "SOURCE_BINDINGS_v2.json", "source_bindings_sha256": digest(OUT / "SOURCE_BINDINGS_v2.json"),
    "original_dispositions_path": disposition_path, "original_dispositions_sha256": digest(OUT / disposition_path),
    "source_pairs": len(verified),
    "result_path": result_path, "result_sha256": digest(OUT / result_path),
    "correspondence_assertions_passed": result["passed"], "correspondence_assertions_failed": 0,
    "complete_proof_bodies": 3, "scientific_AST_statements": 135, "science_rows_compared": 111,
    "substantive_tables_equal": True, "reused_prior_seals": result["reused_prior_seals"],
    "actual_parent_damaged_runs_verified_not_rerun": 3, "reviewer_wrapper_only_runs": 4,
    "science_rerun": False, "empirical_data_accessed": False,
    "failures_preserved": "FAILURES_AND_LIMITS_v1.md", "unresolved_source_corrections": [],
    "parent_source_git_runtime_lock_PR_audit_settings_modified": False,
    "prior_seals_modified": False,
    "seal_policy": "Final report and all artifacts written before manifest/receipt; no sealed artifact is subsequently rewritten."}
write("RECEIPT_v1.json", receipt)
with (OUT / "RECEIPT_v1.sha256").open("x") as f:
    f.write(digest(OUT / "RECEIPT_v1.json") + "  RECEIPT_v1.json\n")
# Verify every artifact after the seal has been written, without writing again.
for row in artifacts:
    p = OUT / row["path"]
    assert p.stat().st_size == row["bytes"] and digest(p) == row["sha256"]
actual = {p.relative_to(OUT).as_posix() for p in OUT.rglob("*") if p.is_file()}
assert actual == {r["path"] for r in artifacts} | set(excluded)
assert digest(OUT / "REPORT_v1.md") == receipt["report_sha256"]
assert digest(OUT / "MANIFEST_v1.json") == receipt["manifest_sha256"]
print(json.dumps({"report_sha256": receipt["report_sha256"], "manifest_sha256": receipt["manifest_sha256"],
                  "receipt_sha256": digest(OUT / "RECEIPT_v1.json"), "artifacts": len(artifacts),
                  "source_pairs": len(verified), "original_dispositions_path": disposition_path,
                  "original_dispositions_sha256": digest(OUT / disposition_path)}))
