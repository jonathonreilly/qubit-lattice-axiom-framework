# What a homogeneous history can determine about the scalar potential

Parent-authored derivation v2, 2026-10-13. Provisional until independently checked.
This block asks what extra observations could determine the remaining potential
assumptions. It does not choose another potential, fit data, or claim an absolute
no-go for reconstructing a theory. All previously accessed observations remain
exposed model-development material. No new empirical data enter this block.

## Conditional first-jet reconstruction

Take the candidate action class

 S=Q integral sqrt(-g)[R/2-K_AB(phi)partial phi^A partial phi^B-2Hv^2 U(phi)]
   +Sm[C(phi)g,psi],

with fixed known positive Q,Hv,K,C and signature (-+++). Put A=sqrt(C),
alpha_A=partial_A log A. These functions and the field coordinates are inputs
to this conditional inverse problem, not quantities already inferred from
expansion data. Use spatially flat homogeneous Einstein proper time t,
v^A=dphi^A/dt, H=da/(a dt), rho and p the Einstein-frame fluid variables.

The background equations in this convention are

 3H^2=K_AB v^A v^B+2Hv^2 U+rho/Q,                       (1)
 Hdot=-K_AB v^A v^B-(rho+p)/(2Q),                        (2)
 D_t v^A+3Hv^A+Hv^2 K^{AB}U_B=-alpha^A(rho-3p)/(2Q),    (3)
 rhodot+3H(rho+p)=alpha_A v^A(rho-3p).                  (4)

In (3), 3Hv^A means 3 H times v^A, not the vacuum scale Hv. If a candidate
regular field curve Gamma=phi(t), its clock, K,C, H,rho,p are known, (1),(3)
reconstruct the value and the full covector gradient of U on that curve:

 U_Gamma=[3H^2-K(v,v)-rho/Q]/(2Hv^2),                    (5)
 (dU)_A|Gamma=-[K_AB(D_t v^B+3H v^B)
                       +alpha_A(rho-3p)/(2Q)]/Hv^2.   (6)

A necessary observable-side check is

 K(v,v)=-Hdot-(rho+p)/(2Q)>=0.                          (7)

For a positive definite metric equality holds exactly where v=0. These
relations do not imply that H alone supplies the hidden field trajectory,
K,C or the Einstein-frame conversion. Even perfect physical-frame expansion
data do not by themselves provide all the inputs of (5),(6).

The value and gradient must be compatible: dU_Gamma/dt=(dU)_A v^A. Differentiate
(5), use d K(v,v)/dt=2K(v,D_t v), and substitute (2),(4). This gives exactly
the contraction of (6) with v. Thus conservation plus the Raychaudhuri equation
are a necessary integrability check; they must not be replaced by separately
chosen potential values and slopes. For a regular embedded curve segment the
compatible value and gradient have local smooth extensions, as follows by
using tubular coordinates (t,n1,n2) and choosing a potential linear in the
normal coordinates with the prescribed normal derivatives. Global extension
across self-intersections or a recurrent path can require additional
compatibility and is not asserted here.

## Exact background degeneracy and its first observable difference

Fix any smooth solution on a regular embedded segment of a three-field
space. In a tubular neighborhood choose two independent smooth functions
f1,f2 that vanish on the curve. For a smooth symmetric 2-by-2 matrix B(phi),
let

 DeltaU=(1/2) f_i B_ij f_j.                             (8)

Then DeltaU=0 and d(DeltaU)=0 everywhere on the curve. Keeping K,C,Q,Hv,
fluid and initial data the same, the original homogeneous solution is also
an exact solution of the modified local potential. Its Einstein metric,
physical metric, fluid history and any observable depending only on that
background are identical. This is exact solution correspondence, not a
numerically close fit or a stability result. A smooth cutoff equal to one
on a smaller tubular neighborhood can localize the change where such a
cutoff exists. No general statement about a whole recurrent infinite curve
or global positivity of a modified potential is required.

On the curve the covariant Hessian changes by

 Delta(U_;AB)=B_ij (partial_A f_i)(partial_B f_j).       (9)

Connection terms vanish because d(DeltaU)=0. Since df_i(v)=0, the Hessian
change annihilates the tangent vector and is otherwise an arbitrary
symmetric form on the two normal directions. Conversely any smooth
potential difference with zero first jet on the curve has Hessian
annihilating its tangent there, by covariantly differentiating d(DeltaU)=0
along the curve. Thus (9) identifies exactly the locally unconstrained
second-derivative directions, rather than just exhibiting one example.

For positive semidefinite B, DeltaU>=0 locally, so this degeneracy does not
require lowering an initially bounded-below potential. Small indefinite B
also remains possible on suitably positive, bounded neighborhoods, but no
global stability statement is made for it. At a stationary single-point
history the tangent argument does not restrict the Hessian: all directions
can change while its first jet remains fixed. If independent histories
sample an open field region and reconstruct the same value there, no such
nonzero local potential difference survives in that region. This is not a
no-go theorem for all observation sets.

Linearized scalar equations contain the mass-map change

 Delta(M^A_B)=Hv^2 K^{AC} Delta(U_;CB).                 (10)

The kinetic curvature, background velocity and matter terms in the full
linear system are unchanged by (8). The potential part of the metric stress
perturbation uses U and dU and is unchanged at first order, but propagation
can change through (10). Turning of the trajectory or matter coupling to
normal directions can make these changes visible. A normal mode decoupled
from all sampled sources and readouts may remain invisible. Neither a
constant vacuum mass nor a single Yukawa equation is being substituted for
the full rolling-background perturbation system.

## An exact degeneracy already present in the revised scalar action

Use the complete revised action fixed in this campaign, with

 a=(1-k)(1+3k)/4, alpha=sqrt(a), s=(1+k)/(k(1-3k)),
 F=1+s exp(2alpha u), J=1+(1-3a)s exp(2alpha u),
 K_u=J/F^2, C=(1+s)exp(2alpha u)/F,
 U=3/2+3s(exp(2alpha u)-1)^2/(2F^2)
   +(k/2)x^2 exp(-(1-k)u/alpha)
   +(k/3)y^2 exp(-(1+k)u/alpha)+nu(1+s)u^2/(2F^2).

For every nu>0 the vacuum u=x=y=0 with v=0,rho=p=0 is exactly the same
physical de Sitter history H=Hv,C=1. Changing nu changes neither U nor dU
there. Nevertheless it changes the matter-coupled vacuum mass by

 m_u^2/Hv^2=4[3(1+k)+nu]/(1-3k),
 Delta m_u^2/Hv^2=4 Delta nu/(1-3k).                   (11)

The vacuum coupling norm remains k. This is a direct, internally supplied
counterexample to determining nu from that history alone, even at fixed k.
It does not assert that the actual present universe is this vacuum or that
non-vacuum histories also remain identical under changing nu. It also does
not transfer the future-convergence theorem to arbitrary nu.

## A concrete additional measurement that could fix the missing mass

In a frozen vacuum, use a weak prescribed nonrelativistic mass source with
negligible pressure and stress, the Newtonian metric/force readout specified
below, and the flat static approximation. A trace-free source would not
excite this scalar response. Let q>0 be an Einstein-frame spatial wavenumber and mu=m_u/c. At C=1 the
frames have identical background lengths. To leading order in source
amplitude, before the density-feedback term (which is second order in a
scaled source) matters, solving the scalar field equation gives the
additional attractive transfer coefficient

 h(q)=k q^2/(q^2+mu^2).                                (12)

This is a defined static transfer function, not a measured PPN parameter,
an astronomical likelihood, or the full cosmological growth observable.
A Yukawa point source equivalently gives potentials proportional to
1 +/- k exp(-mu r); the acceleration instead contains
1+k(1+mu r)exp(-mu r). Mixing a potential ratio with a force readout would
be a false reconstruction. The exact curved vacuum has de Sitter geometry;
this local flat approximation requires curvature and time corrections to
be controlled on the tested scales.

For two distinct sampled q_i and inferred positive h_i, define
x_i=1/q_i^2, y_i=1/h_i. Then

 y_i=c0+c1 x_i, c0=1/k, c1=mu^2/k,
 c1=(y1-y2)/(x1-x2), c0=(x1*y2-x2*y1)/(x1-x2),
 k=1/c0, mu^2=c1/c0.                                  (13)

Compatibility of this particular action requires c0>3, c1>0 and, if Hv
has been independently determined in the same unit convention,

 nu=(1-3k)c^2 mu^2/(4Hv^2)-3(1+k)>0.                  (14)

One measurement leaves a continuous k,mu degeneracy. Two distinct exact
measurements can determine the two conditional parameters; two points
alone cannot test the affine shape. A third scale predicts
1/h3=c0+c1/q3^2. A genuine independent observation would have to be withheld
from choosing and fitting the model, with its errors and readout map fixed
before inspection. No such measurement has been accessed in this block.

The determinant of the Jacobian of (h1,h2) with respect to (k,mu^2) is

 k q1^2 q2^2 (q2^2-q1^2)/[(q1^2+mu^2)^2(q2^2+mu^2)^2]. (15)

It is nonzero for k>0 and distinct positive q_i. Algebraic identifiability
is not adequate conditioning: at q_i>>mu both h_i nearly saturate k, while
at q_i<<mu both nearly determine only k/mu^2. Finite precision and errors
can leave the mass poorly constrained. No numerical precision is supplied
by exact uniqueness.

## Assumption disposition and next derivation

Retired as a permissible inference: identical homogeneous expansion alone
fixes the off-trajectory potential Hessian. Instead its normal part is an
explicit remaining function to be constrained with perturbations or local
response. This conditional non-identifiability proof does not retire the
action, field-count, matter metric, kinetic metric, scales or initial-state
assumptions. Equations (5),(6),(13),(14) provide reconstruction formulas if
their missing physical inputs can actually be obtained; they are not new
empirical parameter determinations. The useful next route is a controlled
cosmological-to-local perturbation/readout map, including which observable
combinations can infer h(q) without presupposing the parameter to be tested.
