#!/usr/local/bin/python3
"""Parent-owned exact controls; no empirical data or fit. Immutable version 1."""
import hashlib,json,sys
from pathlib import Path
import sympy as s
p=Path(__file__).resolve().parent
checks=[]
def zero(name,expr):
    z=s.factor(s.cancel(s.together(expr)))
    checks.append({'name':name,'pass':z==0,'residual':str(z)})
def nonzero(name,expr):
    z=s.factor(s.cancel(s.together(expr)))
    checks.append({'name':name,'pass':z!=0,'deliberate_defect':str(z)})
def condition(name,value,detail=None):
    checks.append({'name':name,'pass':bool(value),'detail':detail})
# Differentiate Friedmann value and check compatibility independently of U.
H,V,W,rho,pressure,Q,Hv,T,av=s.symbols('H V W rho pressure Q Hv T av',real=True,nonzero=True)
Hdot=-V-(rho+pressure)/(2*Q)
rhodot=-3*H*(rho+pressure)+av*(rho-3*pressure)
Udot=(6*H*Hdot-2*W-rhodot/Q)/(2*Hv**2)
grad_contract=-(W+3*H*V+av*(rho-3*pressure)/(2*Q))/Hv**2
zero('first_jet_compatibility',Udot-grad_contract)
wrong_rhodot=-3*H*(rho+pressure)-av*(rho-3*pressure)
nonzero('wrong_fluid_exchange_sign',(6*H*Hdot-2*W-wrong_rhodot/Q)/(2*Hv**2)-grad_contract)
# Curved exact rolling example in flat target metric, C=1, Q=Hv=1.
x,y,z,t=s.symbols('x y z t',real=True)
coords=s.Matrix([x,y,z]); curve=s.Matrix([t,t**2,t**3]); vel=curve.diff(t); acc=vel.diff(t)
Hx=10-x-s.Rational(4,3)*x**3-s.Rational(9,5)*x**5
Ht=Hx.subs(x,t); speed=vel.dot(vel)
Ucurve=(3*Hx**2-(1+4*x**2+9*x**4))/2
g=s.Matrix([-s.diff(curve[i],t,2)-3*Ht*vel[i] for i in range(3)])
f=s.Matrix([y-x**2,z-x**3]); B=s.Matrix([[2,1],[1,3]])
U0=Ucurve+g[1].subs(t,x)*f[0]+g[2].subs(t,x)*f[1]
dU=(f.T*B*f)[0]/2
sub={x:t,y:t**2,z:t**3}
grad0=s.Matrix([s.diff(U0,c) for c in coords]); gradD=s.Matrix([s.diff(dU,c) for c in coords])
zero('rolling_raychaudhuri',s.diff(Ht,t)+speed)
for i in range(3):
    zero('rolling_scalar_U0_'+str(i),(acc+3*Ht*vel+grad0.subs(sub))[i])
    zero('rolling_scalar_U1_'+str(i),(acc+3*Ht*vel+(grad0+gradD).subs(sub))[i])
zero('rolling_Friedmann_U0',3*Ht**2-speed-2*U0.subs(sub))
zero('rolling_Friedmann_U1',3*Ht**2-speed-2*(U0+dU).subs(sub))
zero('deformation_value',dU.subs(sub))
for i in range(3): zero('deformation_gradient_'+str(i),gradD.subs(sub)[i])
hess=s.hessian(dU,coords).subs(sub)
Df=f.jacobian(coords).subs(sub)
for i in range(3):
    for j in range(3): zero('normal_Hessian_'+str(i)+str(j),(hess-Df.T*B*Df)[i,j])
for i in range(3):zero('Hessian_tangent_kernel_'+str(i),(hess*vel)[i])
condition('positive_definite_B',B[0,0]>0 and B.det()>0,{'principal_minors':[str(B[0,0]),str(B.det())]})
condition('normal_rank',Df.rank()==2,str(Df))
# A change with only zero value, not zero gradient, changes the history.
wrong=f[0]
nonzero('missing_square_changes_scalar_equation',s.diff(wrong,y).subs(sub))
nonzero('Hessian_changes',hess[1,1])
# Covariant Hessian identity is valid for arbitrary connection because dD=0.
connections=s.symbols('G0:27')
for a in range(3):
 for b in range(3):
    corr=sum(connections[9*c+3*a+b]*gradD[c].subs(sub) for c in range(3))
    zero('connection_correction_'+str(a)+str(b),corr)
# Supplied scalar action: vary only nu, keeping K,C fixed.
k,nu,dnu=s.symbols('k nu dnu',positive=True)
a=(1-k)*(1+3*k)/4; alpha=s.sqrt(a); ss=(1+k)/(k*(1-3*k)); F=1+ss*s.exp(2*alpha*x); J=1+(1-3*a)*ss*s.exp(2*alpha*x)
Ku=J/F**2
DeltaNu=dnu*(1+ss)*x**2/(2*F**2)
zero('nu_deformation_vacuum_value',DeltaNu.subs(x,0))
zero('nu_deformation_vacuum_gradient',s.diff(DeltaNu,x).subs(x,0))
zero('nu_mass_shift',s.diff(DeltaNu,x,2).subs(x,0)/Ku.subs(x,0)-4*dnu/(1-3*k))
C=(1+ss)*s.exp(2*alpha*x)/F
zero('vacuum_coupling',((s.diff(C,x)/(2*C))**2/Ku).subs(x,0)-k)
# Static transfer inversion: use squared q variables to avoid fake branch choices.
q1,q2,q3,M=s.symbols('q1 q2 q3 M',positive=True)
h=lambda q:k*q/(q+M)
x1,x2=1/q1,1/q2; y1,y2=1/h(q1),1/h(q2)
c1=(y1-y2)/(x1-x2); c0=(x1*y2-x2*y1)/(x1-x2)
zero('transfer_intercept',c0-1/k);zero('transfer_slope',c1-M/k)
zero('k_inversion',1/c0-k);zero('mass_inversion',c1/c0-M)
zero('third_scale_prediction',1/h(q3)-c0-c1/q3)
jac=s.Matrix([h(q1),h(q2)]).jacobian(s.Matrix([k,M])).det()
zero('identifiability_determinant',jac-k*q1*q2*(q2-q1)/((q1+M)**2*(q2+M)**2))
nonzero('wrong_mass_intercept',c1*c0-M)
nonzero('swapped_potential_force',k*s.exp(-x)*(1+x)-k*s.exp(-x))
# Exact rational synthetic controls: verification only, not empirical examples.
examples=[]
for kval,mval in [(s.Rational(1,100000),s.Rational(1,7)),(s.Rational(1,100),s.Rational(5,2)),(s.Rational(8,25),s.Rational(1,1000))]:
 qs=[s.Rational(1,4),s.Rational(2,1),s.Rational(13,3)]
 hs=[kval*q/(q+mval) for q in qs]
 slope=(1/hs[0]-1/hs[1])/(1/qs[0]-1/qs[1])
 intercept=(1/qs[0]/hs[1]-1/qs[1]/hs[0])/(1/qs[0]-1/qs[1])
 zero('synthetic_k_'+str(kval),1/intercept-kval)
 zero('synthetic_mass_'+str(kval),slope/intercept-mval)
 zero('synthetic_prediction_'+str(kval),1/hs[2]-intercept-slope/qs[2])
 examples.append({'k':str(kval),'mu_squared':str(mval),'q_squared':[str(q) for q in qs],'h':[str(v) for v in hs]})
# Two supplied hypotheses can fit one scalar readout; no extra observation.
qobs=s.Rational(3,2);hobs=s.Rational(1,1000)
m1=qobs*(s.Rational(1,100)/hobs-1);m2=qobs*(s.Rational(1,50)/hobs-1)
zero('one_scale_family_first',s.Rational(1,100)*qobs/(qobs+m1)-hobs)
zero('one_scale_family_second',s.Rational(1,50)*qobs/(qobs+m2)-hobs)
condition('distinct_mass_same_readout',m1!=m2 and m1>0 and m2>0,{'mass1':str(m1),'mass2':str(m2)})
source_paths=[p/'DERIVATION_v1.md',p/'PROTOCOL_v1.json',Path(__file__).resolve()]
result={'kind':'parent_exact_inverse_problem_controls','precision':'exact symbolic/rational','empirical_data':False,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'checks':checks,'synthetic_examples':examples,'rolling_example':{'curve':[str(c) for c in curve],'H':str(Ht),'base_potential':str(s.factor(U0)),'deformation':str(dU),'Hessian_on_curve':str(hess)},'source_hashes':[{'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in source_paths]}
out=p/'evidence_v1';out.mkdir(exist_ok=True);(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'output':str(out/'RESULTS.json')}))
for c in checks:
 if not c['pass']:print(json.dumps(c))
sys.exit(bool(result['failed']))
