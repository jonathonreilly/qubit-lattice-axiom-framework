#!/usr/local/bin/python3
"""Exact and numerical parent controls for the ideal local readout, no data."""
from pathlib import Path
import json,hashlib,sys
import sympy as s
import mpmath as mp
p=Path(__file__).resolve().parent;checks=[]
def exact(name,e):
 e=s.factor(s.cancel(s.trigsimp(s.simplify(e))));checks.append({'name':name,'passed':e==0,'residual':str(e)})
def control(name,ok,detail):checks.append({'name':name,'passed':bool(ok),'detail':detail})
r,b,z,mu,m,k,c,x,r1,r2,R,rp=s.symbols('r b z mu m k c x r1 r2 R rp',positive=True)
Phi=m*(1+k*s.exp(-mu*r))/r;Psi=m*(1-k*s.exp(-mu*r))/r
F=lambda x:(1+x)*s.exp(-x)
exact('Weyl_potential',(Phi+Psi)/2-m/r)
exact('radial_acceleration',-s.diff(Phi,r)-m*(1+k*F(mu*r))/r**2)
primitive=2*m*z/(b*s.sqrt(b*b+z*z))
exact('deflection_integrand',s.diff(primitive,z)-2*m*b/(b*b+z*z)**s.Rational(3,2))
exact('deflection_total',s.limit(primitive,z,s.oo)-s.limit(primitive,z,-s.oo)-4*m/b)
acc=c*c*m*(1+k*F(mu*r))/r**2;theta=4*m/b
exact('mass_normalization_cancellation',4*r*r*acc/(c*c*b*theta)-1-k*F(mu*r))
L=s.log(1+mu*r1)-s.log(1+mu*r2)+mu*(r2-r1)
exact('ratio_log_derivative',s.diff(L,mu)-mu*(r2*r2/(1+mu*r2)-r1*r1/(1+mu*r1)))
exact('radius_monotonicity',s.diff(r*r/(1+mu*r),r)-r*(2+mu*r)/(1+mu*r)**2)
exact('zero_mass_ratio',L.subs(mu,0))
exact('force_series',s.series(F(x),x,0,4).removeO()-(1-x*x/2+x**3/3))
exact('ratio_series',s.series(L,mu,0,4).removeO()-(mu**2*(r2*r2-r1*r1)/2-mu**3*(r2**3-r1**3)/3))
# Exterior angular Green integral after replacing separation variable.
angular=(s.exp(-mu*(r-rp))-s.exp(-mu*(r+rp)))/(mu*r*rp)
exact('external_spherical_Yukawa_kernel',angular-2*s.exp(-mu*r)*s.sinh(mu*rp)/(mu*r*rp))
ball=3*(x*s.cosh(x)-s.sinh(x))/x**3
exact('uniform_ball_radial_integral',s.diff(mu*rp*s.cosh(mu*rp)-s.sinh(mu*rp),rp)-mu**2*rp*s.sinh(mu*rp))
exact('uniform_ball_small_mass',s.series(ball,x,0,6).removeO()-(1+x*x/10+x**4/280))
charge=s.symbols('charge',positive=True)
exact('finite_body_ratio_cancellation',(k*charge*F(mu*r1))/(k*charge*F(mu*r2))-F(mu*r1)/F(mu*r2))
# Source trace is mandatory; an equation with rho instead of rho-3p fails.
rho,pressure=s.symbols('rho pressure',positive=True)
exact('trace_free_source', (rho-3*pressure).subs(pressure,rho/3))
control('wrong_force_without_derivative_factor',s.simplify(-s.diff(Phi,r)-m*(1+k*s.exp(-mu*r))/r**2)!=0,str(s.simplify(-s.diff(Phi,r)-m*(1+k*s.exp(-mu*r))/r**2)))
control('wrong_pressure_omission',rho.subs(pressure,rho/3)!=0,'rho source remains nonzero for trace-free pressure=rho/3')
# Independent root solve of the parent analytic inverse, synthetic values only.
mp.mp.dps=80
rows=[]
for ks,ms in [('0.00001','0.1'),('0.01','1'),('0.2','10')]:
 kk=mp.mpf(ks);mm=mp.mpf(ms);rr1=mp.mpf(1);rr2=mp.mpf(2);rr3=mp.mpf(3)
 ff=lambda v:(1+v)*mp.exp(-v)
 e1=kk*ff(mm*rr1);e2=kk*ff(mm*rr2);e3=kk*ff(mm*rr3)
 target=mp.log(e1/e2)
 fn=lambda v:mp.log1p(v*rr1)-mp.log1p(v*rr2)+v*(rr2-rr1)
 lo=mp.mpf(0);hi=mp.mpf(1)
 while fn(hi)<target:hi*=2
 for _ in range(300):
  mid=(lo+hi)/2
  if fn(mid)<target:lo=mid
  else:hi=mid
 est=(lo+hi)/2;kest=e1/ff(est*rr1);pred=kest*ff(est*rr3)
 errors=[abs(est-mm)/max(1,abs(mm)),abs(kest-kk)/kk,abs(pred-e3)/e3]
 control('synthetic_inverse_'+ks,all(e<mp.mpf('1e-60') for e in errors),[mp.nstr(e,12) for e in errors])
 # Numerical line integral is a cross check of exact primitive.
 bend=mp.quad(lambda zz:2/(1+zz*zz)**mp.mpf('1.5'),[-mp.inf,0,mp.inf])
 control('light_integral_'+ks,abs(bend-4)<mp.mpf('1e-65'),mp.nstr(bend,20))
 rows.append({'k':ks,'mu':ms,'radii':['1','2','3'],'excess':[mp.nstr(v,70) for v in [e1,e2,e3]],'recovered_mu':mp.nstr(est,70),'recovered_k':mp.nstr(kest,70),'third_radius_prediction':mp.nstr(pred,70)})
result={'kind':'parent_ideal_static_observation_map_controls','empirical_data':False,'passed':sum(v['passed'] for v in checks),'failed':sum(not v['passed'] for v in checks),'checks':checks,'synthetic':rows,'source_hashes':[{'path':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in [p/'READOUT_DERIVATION_v1.md',p/'READOUT_PROTOCOL_v1.json',Path(__file__).resolve()]]}
o=p/'readout_evidence_v1';o.mkdir(exist_ok=False);(o/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed']}));sys.exit(bool(result['failed']))
