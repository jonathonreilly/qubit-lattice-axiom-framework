# Readout check: executions and preserved checker error

All three scripts were executed once each with a fresh guarded result path:

1. `python3 derive_readout_controls_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt`
   exited 0; all 22 compound checks true; stderr empty.
2. `python3 numeric_readout_controls_v1.py > results/numeric_run01.stdout.txt 2> results/numeric_run01.stderr.txt`
   exited 0; all ten implemented compound checks true; stderr empty.
3. `python3 body_normalization_correction_v1.py > results/body_normalization_correction_run01.stdout.txt 2> results/body_normalization_correction_run01.stderr.txt`
   exited 0; all seven correction checks true; stderr empty.

No runtime exception or failed automated assertion occurred. That does not
mean the first checker interpretation was error-free. Handwritten v1 claimed
two different k values, the same physical mass and the same raw lensing
monopole at fixed canonical Q0. The candidate action has Q(k)=Q0(1+k), so
Gstar depends on k; those three conditions do not hold together. The initial
body check compared normalized excesses and omitted this cross-parameter
mass-normalization condition.

This erroneous illustration is preserved unchanged in `HAND_DERIVATION_v1.md`,
the original numerical script and its outputs. The separate correction derives
the required physical masses at fixed observed lensing monopole and fixed Q0,
then checks the raw lensing and force readouts directly. `HAND_DERIVATION_v2.md`
is the corrected active derivation; `HAND_V1_V2.diff` records the exact change.
No failed or incomplete evidence was overwritten or presented as sufficient.

The candidate's own v1 had two separate scope imprecisions, both corrected in
its preserved v2: scalar excitation stress versus constant vacuum energy, and
the exterior lensing-ray condition for finite bodies. The candidate equations
are unchanged. Its source snapshots and exact source diff are preserved; its
producer runner and outputs were not accessed.
