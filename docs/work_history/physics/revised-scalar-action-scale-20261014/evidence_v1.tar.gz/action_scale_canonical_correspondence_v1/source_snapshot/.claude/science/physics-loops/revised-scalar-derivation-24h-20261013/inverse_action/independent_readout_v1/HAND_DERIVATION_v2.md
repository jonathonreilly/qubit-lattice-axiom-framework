# Independent local readout derivation, corrected v2

This is a separate focused check by `/root/scalar_energy_check`. The parent
remains scientific author. The original inverse-action receipt is sealed
unchanged. No producer runner or its outputs enter this check.

## From the action to the two metric potentials

The supplied action fixes `Gstar=1/(8pi Q)` in c=1 units and at the vacuum
has `C0=1`, `dU0=0`, a single matter-coupled u direction,
`alpha0^2/K_u0=k`, and `m_u^2=Hv^2 U_uu0/K_u0`. These action identities
were derived independently in the preceding inverse check, whose receipt is
`e0b4a363c87df90d9c457283834dd2ccc692db88163b82b366767d7b3fe6eb1b`.
The complete action is also frozen as a source here.

In a locally flat frozen vacuum, the weak static scalar equation for a
prescribed nonrelativistic density is

    (laplacian-mu^2) delta u=alpha0 rho/(2Q K_u0),
    mu=m_u/c.

The Green function satisfies `(laplacian-mu^2)(exp(-mu r)/r)=-4pi delta3`.
For a point mass it therefore gives

    alpha0 delta u=-k m exp(-mu r)/r, m=Gstar M/c^2.

A trace-free source would instead give zero right-hand side. Pressure and
stress must be negligible for the stated Newtonian comparison.

Use the positive-potential convention in the candidate note. To first order,
the Einstein source potentials are `Phi_E=Psi_E=m/r` in the local flat
approximation and `C=1+2alpha0 delta u`. Multiplication of the metric gives

    Phi=Phi_E-alpha0 delta u=(m/r)(1+k exp(-mu r)),
    Psi=Psi_E+alpha0 delta u=(m/r)(1-k exp(-mu r)).

Thus the sum is `Phi+Psi=2m/r`. The scalar excitation kinetic stress and its
potential change begin at second order because `dU0=0`. The constant vacuum
energy itself is not a second-order excitation: it remains the cosmological
term in the curved-background metric equations. The flat approximation drops
that curvature only within its stated regime. V2 correctly makes this
distinction explicit.

## Lensing, dynamical acceleration and normalization

In the weak static straight-ray calculation, with r=sqrt(b^2+z^2), the
magnitude of the transverse gradient is `2m b/(b^2+z^2)^(3/2)`. Therefore

    theta(b)=int_-infinity^infinity 2m b/(b^2+z^2)^(3/2) dz=4m/b.

Slow tracers have inward acceleration magnitude `-c^2 dPhi/dr`. Differentiation
yields

    a_dyn=c^2 m/r^2 [1+k(1+mu r)exp(-mu r)].

Using the same source and the lensing-inferred `m=b theta/4` gives

    4r^2 a_dyn/(c^2 b theta)-1=k F(mu r), F(x)=(1+x)exp(-x).

The source normalization m cancels. Source geometry, a common environment,
physical lengths, the metric coupling and the weak static vacuum approximation
remain required inputs. A mass inferred by presupposing the tested force law
cannot independently serve as this normalization.

The infinite straight-ray integral is an ideal flat calculation, not a global
de Sitter lensing law. Even in flat space, cutting the line at +/-Z gives

    theta_Z=(4m/b) Z/sqrt(Z^2+b^2).

Its fractional omitted tail is `1-Z/sqrt(Z^2+b^2)`, approximately `b^2/(2Z^2)`.
A genuinely local lensing interpretation needs geometry and a sufficiently
long controlled segment, as well as curvature/time control. This flat tail
formula is not an error bound for an actual curved spacetime.

## Positive two-radius inverse

For r2>r1>0 and positive excesses, define `L=log(e1/e2)`. Then

    L(mu)=log(1+mu r1)-log(1+mu r2)+mu(r2-r1),
    L'(mu)=mu(r2-r1)(r1+r2+mu r1 r2)/
                    [(1+mu r1)(1+mu r2)]>0.

This is algebraically equal to the derivative displayed in the candidate.
It proves strict monotonicity for every mu>0. L(0)=0 and
`L(mu)/mu -> r2-r1>0`, so its range is all positive numbers. Every exact
ratio R>1 has one positive mu, and then `k=e1/F(mu r1)` for an ideal point
source. R<1 has no solution in this model; R=1 is the mu=0 limit, incompatible
with finite positive Hv and the positive-mass canonical action. No noisy
ratio, zero excess or negative excess is classified without an error model.

Canonical compatibility also requires `0<k<1/3` and
`nu=(1-3k)c^2 mu^2/(4Hv^2)-3(1+k)>0`, with Hv separately calibrated.
A third radius predicts e3 only after the first two determine parameters;
an empirical test further needs a readout/error protocol independent of model
development. No actual observations occur here.

Expanding at small mu gives

    F(mu r)=1-(mu r)^2/2+(mu r)^3/3+O(mu^4),
    L(mu)=mu^2(r2^2-r1^2)/2-mu^3(r2^3-r1^3)/3+O(mu^4).

The logarithmic sensitivity of mu to a ratio is `1/[mu L'(mu)]`; it diverges
as `1/[mu^2(r2^2-r1^2)]`. Nearby radii also weaken the inverse. For very short
ranges the excess itself is exponentially small, so absolute readout errors
matter even if the formal ratio inversion remains unique. Exact uniqueness
does not provide an observational uncertainty or statistical exclusion.

## Finite sources and an explicit amplitude degeneracy

For a spherical source shell at radius s<r, angular averaging of the Yukawa
Green function gives

    (1/2)int_-1^1 exp(-mu sqrt(r^2+s^2-2rs x))/
                    sqrt(r^2+s^2-2rs x) dx
       =exp(-mu r)/r * sinh(mu s)/(mu s).

This follows directly by changing the integration variable to the separation,
whose endpoints are r-s and r+s. Hence, for nonnegative density supported in
0<=s<=R,

    F_body=(4pi/M) int_0^R rho(s)s^2 sinh(mu s)/(mu s) ds,
    e(r)=k F_body F(mu r), r>R.

The tensor monopole is M. If the lensing ray also has b>R, it stays in that
exterior monopole, and the point-source lensing expression holds. If it crosses
the body, its projected mass replaces M. For example, a uniform sphere has

    M_projected(<b)/M=1-(1-b^2/R^2)^(3/2), 0<b<R.

Using `4m/b` for such an interior ray would give a false mass normalization.
V2 now explicitly requires exterior lensing and dynamical radii or a projected
profile correction.

For a fixed spherical body, F_body is independent of the exterior readout
radius, so e1/e2 still determines mu. The amplitude determines `k F_body`,
not k separately until the profile is supplied. F_body is not arbitrary:
because `sinh x/x` increases for x>0,

    1<=F_body<=sinh(mu R)/(mu R).

For mu R much smaller than one,
`F_body=1+mu^2 <s^2>_mass/6+O(mu^4 R^4)`. Thus a negligible form-factor
effect means F_body approximately one, not F_body approximately zero.

Two explicit radial shapes at the same R are a uniform sphere and a
density proportional to s^2. Their form factors are normalized by each
profile's own physical mass. Writing x=mu R, direct integration gives

    F_uniform=3[x cosh x-sinh x]/x^3,
    F_s2=5[(x^3+6x)cosh x-(3x^2+6)sinh x]/x^5.

At x=1 these are `3/e` and `40/e-5e`, respectively. Choose positive amplitude
A=1/10 and set `k_uniform=A/F_uniform`, `k_s2=A/F_s2`. They give the same
normalized exterior excess at every radius with different couplings. To also
preserve the same observed lensing monopole m at fixed canonical Q0, use
`M_i=8pi Q0(1+k_i)c^2 m`: Q(k)=Q0(1+k) makes Gstar depend on k. These
physical masses generally differ; equal physical masses would not preserve
the same lensing monopole at fixed Q0. This corrects the first handwritten
illustration, whose original version and incomplete numeric check remain
preserved. Taking c=mu=1 and Hv=1e-3 makes both associated
nu values positive; it also permits exterior radii well below c/Hv. These are
constructed ideal source profiles and parameters, not data or claims of a
real equilibrium or cosmological convergence. Shape information would remove
this particular amplitude ambiguity.

## The nu=1 scale limitation

The canonical mass formula gives, at nu=1,

    c mu/Hv=2 sqrt((4+3k)/(1-3k)).

At the transition mu r=1,

    Hv r/c=sqrt(1-3k)/[2sqrt(4+3k)] -> 1/4 as k->0+.

Thus weak coupling with nu=1 does not make the transition radius
parametrically smaller than the vacuum curvature length. Curvature terms
scale in powers of Hv r/c and do not vanish just by taking k small at that
transition. At much smaller radii the mass dependence of F is quadratically
suppressed. The value 1/4 is a scale comparison, not a computed 6.25% error
bound or an assertion of measured accuracy. A heavier mass or a controlled
curved-background readout is a separate input/work item.

All conclusions are conditional on a frozen vacuum, weak nonrelativistic
prescribed source, linear response, local static flat approximation and the
stated common-source geometry. They neither select a physical environment nor
supply a complete rolling, nonlinear, finite-body or observational readout.
