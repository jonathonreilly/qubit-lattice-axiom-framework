# Separate focused readout check

Checker `/root/scalar_energy_check`; parent `/root` remains scientific author.
Completed 2026-10-13. The original inverse-action check is separately sealed;
this report does not enlarge its receipt or issue a formal audit verdict.

The candidate's readout equations, mass-normalization cancellation, positive
two-radius inverse, finite-body amplitude limitation and nu=1 scale comparison
are mathematically consistent within the corrected v2 hypotheses. Two v1 scope
clarifications were requested and supplied: distinguish scalar excitation
stress from constant vacuum energy, and require an exterior lensing impact
parameter as well as exterior dynamical radii for the finite-body monopole
comparison. No candidate equation required correction.

One error in the checker's own first finite-body illustration was also found
and preserved: at fixed canonical Q0, equal physical masses and different k
do not give equal lensing monopoles. The corrected example explicitly adjusts
the unmeasured physical masses to keep the observed monopole fixed. Both the
original statement and its incomplete control remain visible in this pack.

## Frozen source correspondence

The full v1, v2, correction and canonical action were read. The source hashes
are bound by `SOURCE_MANIFEST_v1.json`:

- Readout v1: `21ec656a5f61031f2496da8b105d3053314ac89cce877db1302ccbaf11a32f90`.
- Readout v2: `dbaf6dbf90e90e7744e3ae61dbf0ee65a5b2485106c6fe175a88bf116f02d139`.
- Correction: `2d827e936321437bf668a58cdf6d137fc924fe5f087226f29a9791c5d5ffbac3`.
- Canonical action: `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`.

`SOURCE_V1_V2.diff` and an exact replacement comparison confirm that the only
source changes are the version label and the two stated scope qualifications.
No producer control or output was read/imported, no empirical data were
accessed and no inherited cosmology was rerun. The preceding inverse check's
action normalization and vacuum identities are reused with their receipt
`e0b4a363c87df90d9c457283834dd2ccc692db88163b82b366767d7b3fe6eb1b`;
the new readout, source-profile and inversion controls are separately derived.

## Checked mathematics

The active complete handwritten derivation is `HAND_DERIVATION_v2.md`.
Its v1 and exact correction diff are preserved.

1. The action's scalar Helmholtz equation gives
   `alpha0 delta u=-k m exp(-mu r)/r` for a weak nonrelativistic point source.
   Conformal multiplication in the positive-potential convention yields
   `Phi=Phi_E-alpha0 delta u` and `Psi=Psi_E+alpha0 delta u`.
   Their sum is `2m/r`. Scalar excitation stress is quadratic, whereas the
   vacuum energy remains a curved-background term before the flat approximation.
2. Direct straight-ray integration gives `theta=4m/b`; direct differentiation
   of Phi gives the inward acceleration factor
   `1+k(1+mu r)exp(-mu r)`. The same-source comparison eliminates m and yields
   `e=k F(mu r)`. This eliminates one normalization, not profile, geometry,
   environment, coupling or error-model inputs.
3. With r2>r1>0,
   `L'=mu(r2-r1)(r1+r2+mu r1r2)/[(1+mu r1)(1+mu r2)]>0`.
   L starts at zero and `L/mu->r2-r1`, establishing existence and uniqueness
   of one positive mu for every exact R>1. R<=1 and nonpositive excesses have
   the stated restricted mathematical interpretation; noisy observations are
   not exclusions without an uncertainty model. Canonical k/nu compatibility
   is an additional requirement.
4. The small-mu force and logarithmic-ratio series agree. The inverse logarithmic
   sensitivity is `1/[mu L']`; it diverges in the long-range limit. Nearly
   equal radii also weaken the inverse, and very short ranges leave tiny
   excesses vulnerable to absolute measurement error. Algebraic uniqueness
   supplies no precision guarantee.
5. Direct angular integration of the Green function produces the spherical
   charge weight `sinh(mu s)/(mu s)`. For a fixed prescribed body, this is
   independent of the exterior readout radius, so it cancels from the ratio
   but remains in the amplitude. For nonnegative density supported inside R,
   `1<=F_body<=sinh(mu R)/(mu R)`: this is a constrained source input, not a
   free screening factor. A negligible form-factor effect means F_body near 1.
6. An interior ray measures projected mass. A uniform sphere at b=R/2 gives
   only `1-3sqrt(3)/8`, approximately 0.350481, of the point-monopole deflection.
   This independently demonstrates why v2 must require an exterior ray or
   a projected-profile correction.
7. At nu=1, `c mu/Hv=2sqrt[(4+3k)/(1-3k)]`. At mu r=1,
   `Hv r/c=sqrt(1-3k)/[2sqrt(4+3k)]->1/4`. Weak k therefore does not make that
   transition parametrically local relative to curvature. This is a scale
   comparison, not a computed curved-background error or an observational bound.

The finite flat-ray calculation also gives
`theta_Z=(4m/b)Z/sqrt(Z^2+b^2)`. It makes the infinite-path assumption visible.
Its omitted flat-space tail is not a bound on real de Sitter or rolling
spacetime lensing. Those geometries still require an appropriate readout map.

## Controls and actual outcomes

`derive_readout_controls_v1.py` ran once, exit 0: all 22 compound exact checks
were true. Three damaged expressions produce nonzero residuals when the force
derivative term is omitted, only one metric potential is used for lensing, or
an interior ray is assigned the total-monopole deflection.

`numeric_readout_controls_v1.py` ran once at 80 decimal digits, exit 0: all ten
implemented compound checks were true. It supplies three independent lensing
quadratures, three synthetic inverse cases built from differentiated potentials,
third-radius predictions, mass-scaling checks, three shell angular quadratures,
two body-profile integrals, an interior-ray integral and scale comparisons.
The largest relative recovered-mu error is about `4.26e-73`; third-radius
errors are below `5.21e-81`. These are numerical controls of constructed inputs,
not precision claims for measurements.

The finite-body factors at mu R=1 are independently

    F_uniform=3/e=1.103638323514327,
    F_r_squared=40/e-5e=1.123768504562467.

Taking target amplitude 0.1 gives respectively
`k=0.09060939428196817` and `k=0.08898629886315818`. The first numeric control
checked equal normalized excesses, but did not check the dependence of the
raw lensing monopole on canonical `Q(k)=Q0(1+k)`. The original handwritten
claim of equal physical M and equal raw lensing with these different k values
was therefore wrong at fixed Q0, despite the implemented checks being true.

`body_normalization_correction_v1.py` preserves and diagnoses that error.
For a specified observed m, it derives `M_i=8pi Q0(1+k_i)c^2 m`. Its seven
exact/numerical checks return true, exit 0. With Q0=c=1 and m=1e-6, the two
physical masses are approximately `2.741000369e-5` and `2.736921085e-5`.
Direct mass and charge integrals then give identical exterior lensing and
dynamical readouts with the same radius and different k. Both associated
nu values are positive for mu=1,Hv=1e-3. The construction prescribes ideal
profiles; it does not establish real-body equilibrium, cosmological selection
or the earlier theorem's separate convergence condition.

All three scripts/results, stdout, empty stderr files, the original incomplete
illustration, corrected derivation and exact correction are preserved.
`FAILURE_LOG_v1.md` explicitly distinguishes successful implemented checks
from the checker error those original checks failed to cover.

## Remaining limitations and custody

No measurement has been obtained or fitted. A real application still needs
a justified vacuum/frozen background, weak prescribed nonrelativistic source,
controlled curvature and time dependence, source profile or point approximation,
exterior geometry, common-source normalization, physical distances and a fixed
readout/error model. Pressure, nonlinear density feedback and rolling scalar
evolution are not hidden inside the spherical form factor. Third-radius shape
testing needs data independent of model choice and calibration.

All new files are inside `inverse_action/independent_readout_v1/`. Parent
sources, git/PR/runtime/audit state and prior evidence were not changed. The
original inverse receipt and all its 29 bound artifacts are checked unchanged
when this separate receipt is sealed. No formal audit is performed.
