#!/usr/bin/env python3
"""Affected correction: fixed Q0 means equal k-dependent lensing m, not equal M."""
from pathlib import Path
import hashlib
import json
import sympy as s
import mpmath as mp


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/body_normalization_correction_run01.json'
    if target.exists():raise RuntimeError('Preserve existing correction')
    k1,k2,Q0,M,mobs=s.symbols('k1 k2 Q0 M m_observed',positive=True)
    G1=1/(8*s.pi*Q0*(1+k1));G2=1/(8*s.pi*Q0*(1+k2))
    same_M_difference=s.factor(M*(G1-G2))
    recovered_M1=8*s.pi*Q0*(1+k1)*mobs
    recovered_M2=8*s.pi*Q0*(1+k2)*mobs
    fixed_m_residuals=[s.simplify(G1*recovered_M1-mobs),s.simplify(G2*recovered_M2-mobs)]
    mp.mp.dps=80
    amplitude=mp.mpf('.1');Hv=mp.mpf('.001');Q0n=mp.mpf(1);mn=mp.mpf('1e-6')
    profiles=[]
    for name,power,norm in [('uniform',0,3),('rho_proportional_to_r_squared',2,5)]:
        form=mp.quad(lambda radius:norm*radius**(power+1)*mp.sinh(radius),[0,1])
        kval=amplitude/form
        G=1/(8*mp.pi*Q0n*(1+kval))
        physical_mass=mn/G
        # rho(r)=norm*M*r^power/(4pi) for R=1; direct normalized charge.
        charge=mp.quad(lambda radius:norm*physical_mass*radius**(power+1)*mp.sinh(radius),[0,1])
        total_mass=mp.quad(lambda radius:norm*physical_mass*radius**(power+2),[0,1])
        derived_form=charge/total_mass
        def F(x):return (1+x)*mp.exp(-x)
        profiles.append({'profile':name,'fixed_Q0':str(Q0n),'k':str(kval),
                         'Gstar':str(G),'physical_M':str(physical_mass),
                         'integrated_M':str(total_mass),'lensing_m':str(G*total_mass),
                         'R':1,'mu':1,'Hv':str(Hv),
                         'nu':str((1-3*kval)/(4*Hv*Hv)-3*(1+kval)),
                         'form_factor':str(derived_form),
                         'theta_at_b_2':str(4*G*total_mass/2),
                         'accelerations_at_r_2_3_5':[str(G*total_mass/mp.mpf(rr)**2*(1+kval*derived_form*F(mp.mpf(rr)))) for rr in ['2','3','5']],
                         'excesses_at_r_2_3_5':[str(kval*derived_form*F(mp.mpf(rr))) for rr in ['2','3','5']]})
    checks={'equal_physical_mass_would_change_lensing_normalization':same_M_difference!=0,
            'derived_masses_preserve_fixed_lensing_monopole':all(value==0 for value in fixed_m_residuals),
            'numerical_masses_are_different':profiles[0]['physical_M']!=profiles[1]['physical_M'],
            'both_lensing_monopoles_equal_target':all(abs(mp.mpf(row['lensing_m'])-mn)<mp.mpf('1e-65') for row in profiles),
            'identical_exterior_lensing':abs(mp.mpf(profiles[0]['theta_at_b_2'])-mp.mpf(profiles[1]['theta_at_b_2']))<mp.mpf('1e-65'),
            'identical_exterior_dynamical_readouts':max(abs(mp.mpf(a)-mp.mpf(b)) for a,b in zip(profiles[0]['accelerations_at_r_2_3_5'],profiles[1]['accelerations_at_r_2_3_5']))<mp.mpf('1e-65'),
            'same_excesses_with_different_couplings':profiles[0]['k']!=profiles[1]['k'] and max(abs(mp.mpf(a)-mp.mpf(b)) for a,b in zip(profiles[0]['excesses_at_r_2_3_5'],profiles[1]['excesses_at_r_2_3_5']))<mp.mpf('1e-65')}
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'issue':'The first independent illustration claimed the same physical M, different k, and identical lensing m. Under the canonical Q(k)=Q0(1+k) with fixed Q0, that combination is false. The initial checks did not test Gstar(k) in the profile illustration.',
            'preserved_originals':['HAND_DERIVATION_v1.md','numeric_readout_controls_v1.py','results/numeric_run01.json'],
            'same_M_lensing_difference':str(same_M_difference),
            'corrected_masses':[str(recovered_M1),str(recovered_M2)],
            'fixed_m_symbolic_residuals':list(map(str,fixed_m_residuals)),
            'scope':'Corrected illustration keeps the observed lensing monopole and Q0 fixed, allows the unmeasured physical mass normalization to differ, and keeps all profiles/radii prescribed. Original form factors and range-ratio conclusion are unchanged.',
            'profiles':profiles,'checks':checks,'failures':[key for key,value in checks.items() if not value]}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
