#!/usr/bin/env python3
"""Independent exact readout, inverse, spherical-source and scale controls."""
from pathlib import Path
import hashlib
import json
import sympy as s


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/exact_run01.json'
    if target.exists():raise RuntimeError('Preserve existing result')
    k,mu,r,b,m,c,z,Z,r1,d,x,R,Hv=s.symbols('k mu r b m c z Z r1 d x R Hv',positive=True)
    epsilon,P,ad=s.symbols('epsilon P alpha_delta')
    g00=s.expand((1+2*ad*epsilon)*(-1+2*P*epsilon))
    gij=s.expand((1+2*ad*epsilon)*(1+2*P*epsilon))
    Phi_conformal=g00.coeff(epsilon)/2
    Psi_conformal=gij.coeff(epsilon)/2
    Phi=m*(1+k*s.exp(-mu*r))/r
    Psi=m*(1-k*s.exp(-mu*r))/r
    integrand=2*m*b/(b*b+z*z)**s.Rational(3,2)
    primitive=2*m*z/(b*s.sqrt(b*b+z*z))
    theta=s.simplify(s.limit(primitive,z,s.oo)-s.limit(primitive,z,-s.oo))
    truncated=s.simplify(primitive.subs(z,Z)-primitive.subs(z,-Z))
    acceleration=s.simplify(-c*c*s.diff(Phi,r))
    excess=s.simplify(4*r*r*acceleration/(c*c*b*theta)-1)
    F=lambda y:(1+y)*s.exp(-y)
    r2=r1+d
    L=s.log(1+mu*r1)-s.log(1+mu*r2)+mu*d
    Lprime=s.factor(s.diff(L,mu))
    positive_form=mu*d*(r1+r2+mu*r1*r2)/((1+mu*r1)*(1+mu*r2))
    Fseries=s.series(F(mu*r),mu,0,4).removeO()
    Lseries=s.series(L,mu,0,4).removeO().expand()
    expectedF=1-mu**2*r**2/2+mu**3*r**3/3
    expectedL=mu**2*(r2*r2-r1*r1)/2-mu**3*(r2**3-r1**3)/3
    # Shell angular integral via separation, whose limits are r-s0,r+s0.
    shell_radius,sep=s.symbols('shell_radius sep',positive=True)
    angular=(s.exp(-mu*(r-shell_radius))-s.exp(-mu*(r+shell_radius)))/(2*mu*r*shell_radius)
    shell_expected=s.exp(-mu*r)*s.sinh(mu*shell_radius)/(r*mu*shell_radius)
    uniform=3*(x*s.cosh(x)-s.sinh(x))/x**3
    weighted=5*((x**3+6*x)*s.cosh(x)-(3*x*x+6)*s.sinh(x))/x**5
    y=s.symbols('y',positive=True)
    uniform_integral=3*s.integrate(y*s.sinh(y),(y,0,x))/x**3
    weighted_integral=5*s.integrate(y**3*s.sinh(y),(y,0,x))/x**5
    f_uniform_at_one=s.simplify(s.expand(uniform.subs(x,1)).rewrite(s.exp))
    f_weighted_at_one=s.simplify(s.expand(weighted.subs(x,1)).rewrite(s.exp))
    impact_fraction=1-(1-b*b/R**2)**s.Rational(3,2)
    interior_at_half=s.simplify(impact_fraction.subs(b,R/2))
    transition=s.sqrt(1-3*k)/(2*s.sqrt(4+3*k))
    checks={
       'conformal_time_potential':s.simplify(Phi_conformal-(P-ad))==0,
       'conformal_space_potential':s.simplify(Psi_conformal-(P+ad))==0,
       'lensing_sum_cancels_scalar':s.simplify(Phi+Psi-2*m/r)==0,
       'deflection_primitive':s.simplify(s.diff(primitive,z)-integrand)==0,
       'point_deflection':s.simplify(theta-4*m/b)==0,
       'finite_ray_integral':s.simplify(truncated-4*m*Z/(b*s.sqrt(Z*Z+b*b)))==0,
       'force_readout':s.simplify(acceleration-c*c*m*(1+k*F(mu*r))/r**2)==0,
       'mass_normalization_cancels':s.simplify(excess-k*F(mu*r))==0,
       'inverse_derivative_positive_factorization':s.simplify(Lprime-positive_form)==0,
       'inverse_lower_endpoint':s.simplify(L.subs(mu,0))==0,
       'inverse_unbounded_upper_endpoint':s.simplify(s.limit(L/mu,mu,s.oo)-d)==0,
       'long_range_force_series':s.simplify(Fseries-expectedF)==0,
       'long_range_ratio_series':s.simplify(Lseries-expectedL)==0,
       'shell_charge_kernel':s.simplify((angular-shell_expected).rewrite(s.exp))==0,
       'uniform_body_integral':s.simplify(uniform-uniform_integral)==0,
       'squared_radius_body_integral':s.simplify(weighted-weighted_integral)==0,
       'uniform_body_at_unit_size':s.simplify(f_uniform_at_one-3/s.E)==0,
       'squared_radius_body_at_unit_size':s.simplify(f_weighted_at_one-(40/s.E-5*s.E))==0,
       'pointlike_body_limit':s.limit(uniform,x,0)==1 and s.limit(weighted,x,0)==1,
       'interior_lensing_not_total_monopole':s.simplify(interior_at_half-(1-3*s.sqrt(3)/8))==0 and interior_at_half!=1,
       'nu_one_transition_not_parametrically_local':s.limit(transition,k,0,dir='+')==s.Rational(1,4)}
    # Deliberate readout errors must have nonzero residuals.
    wrong_force_excess=k*s.exp(-mu*r)
    damage={'omit_force_derivative_term':s.simplify(excess-wrong_force_excess),
            'use_single_Phi_for_lensing_sum':s.simplify(Phi-(Phi+Psi)),
            'use_total_monopole_for_interior_uniform_ray':s.simplify(1-interior_at_half)}
    checks['three_damaged_readouts_detected']=all(value!=0 for value in damage.values())
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'conformal_potentials':[str(Phi_conformal),str(Psi_conformal)],
            'deflection':str(theta),'truncated_deflection':str(truncated),
            'acceleration':str(acceleration),'mass_cancelled_excess':str(excess),
            'Lprime_positive_factorization':str(s.factor(positive_form)),
            'long_range_force_series':str(Fseries),'long_range_ratio_series':str(s.factor(Lseries)),
            'uniform_form_factor':str(uniform),'squared_radius_form_factor':str(weighted),
            'interior_projected_mass_fraction_at_half_radius':str(interior_at_half),
            'nu_one_transition_curvature_parameter':str(transition),
            'damaged_readout_residuals':{key:str(value) for key,value in damage.items()},
            'checks':{key:bool(value) for key,value in checks.items()},
            'failures':[key for key,value in checks.items() if not value]}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
