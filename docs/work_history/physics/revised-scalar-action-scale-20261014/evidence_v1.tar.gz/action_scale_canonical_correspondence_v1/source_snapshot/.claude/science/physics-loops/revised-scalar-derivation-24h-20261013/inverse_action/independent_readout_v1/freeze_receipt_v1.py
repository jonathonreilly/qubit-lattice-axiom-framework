#!/usr/bin/env python3
"""Seal this separate readout check and verify custody of the original inverse pack."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json


def main():
    out=Path(__file__).resolve().parent;repo=out.parents[5]
    excluded={'RECEIPT_v1.json','RECEIPT_v1.sha256','RECEIPT_VERIFICATION_v1.json'}
    for name in excluded:
        if (out/name).exists():raise RuntimeError('Preserve frozen output: '+name)
    sha=lambda b:hashlib.sha256(b).hexdigest()
    sources=[]
    for row in json.loads((out/'SOURCE_MANIFEST_v1.json').read_text())['sources']:
        live=(repo/row['original_path']).read_bytes();snap=(out/row['snapshot_path']).read_bytes()
        assert live==snap and sha(snap)==row['sha256'] and len(snap)==row['bytes']
        sources.append({**row,'current_source_matches_snapshot':True})
    original=out.parent/'independent_v1'
    original_receipt=original/'RECEIPT_v1.json'
    expected='e0b4a363c87df90d9c457283834dd2ccc692db88163b82b366767d7b3fe6eb1b'
    assert sha(original_receipt.read_bytes())==expected
    prior=json.loads(original_receipt.read_text())
    for row in prior['artifacts']:
        data=(original/row['path']).read_bytes()
        assert sha(data)==row['sha256'] and len(data)==row['bytes']
    inspection=json.loads((out/'EXECUTION_INSPECTION_v1.json').read_text())
    for run in inspection['runs']:
        assert sha((out/run['script']).read_bytes())==run['script_sha256']
        result=json.loads((out/run['result']).read_text())
        assert result['script_sha256']==run['script_sha256'] and result['status']==run['status']
        assert all(result['checks'].values()) and not result['failures']
    artifacts=[]
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name not in excluded:
            data=path.read_bytes()
            artifacts.append({'path':str(path.relative_to(out)),'bytes':len(data),'sha256':sha(data)})
    receipt={'kind':'separate_focused_independent_mathematics_check',
       'created_utc':datetime.now(timezone.utc).isoformat(),
       'checker':'/root/scalar_energy_check','scientific_author':'/root',
       'scope':'Ideal vacuum lensing/dynamical readout, positive two-radius inverse, prescribed finite-body amplitude ambiguity, flat-background and nu=1 scale limitations.',
       'sources':sources,
       'source_outcome':'No unresolved candidate equation correction within v2 scope. Two source qualifications resolved: excitation stress excludes constant vacuum term; finite-body lensing ray and dynamical radii exterior or profile corrected.',
       'evidence':{'active_hand_derivation':'HAND_DERIVATION_v2.md','report':'REPORT_v1.md',
                   'failure_log':'FAILURE_LOG_v1.md','exact_compound_checks_true':22,
                   'initial_numeric_compound_checks_true':10,'affected_correction_checks_true':7,
                   'damage_probes':3,'synthetic_inverse_cases':3,'shell_quadratures':3,
                   'finite_body_profiles':2,'precision_decimal_digits':80},
       'checker_error':{'preserved':True,
          'description':'Original finite-body illustration incorrectly coupled equal physical M, unequal k and equal raw lensing at fixed Q0. Initial controls did not check Gstar(k).',
          'correction':'Fix observed lensing m and Q0, derive M_i=8pi Q0(1+k_i)c^2 m; direct profile, raw lensing and acceleration controls agree.',
          'original_files':['HAND_DERIVATION_v1.md','numeric_readout_controls_v1.py','results/numeric_run01.json'],
          'corrected_evidence':'results/body_normalization_correction_run01.json'},
       'actual_runtime_or_automated_assertion_failures':[],
       'prior_inverse_receipt':{'sha256':expected,'bound_artifacts_verified_unchanged':len(prior['artifacts'])},
       'producer_runner_or_outputs_read_or_imported':False,'empirical_data_accessed':False,
       'inherited_cosmologies_rerun':False,'formal_audit_performed':False,
       'parent_source_git_pr_runtime_audit_state_modified':False,
       'artifact_count':len(artifacts),'artifact_paths_relative_to':str(out.relative_to(repo)),
       'artifacts':artifacts,'self_hash_exclusion':sorted(excluded)}
    target=out/'RECEIPT_v1.json';target.write_text(json.dumps(receipt,indent=2)+'\n')
    digest=sha(target.read_bytes());(out/'RECEIPT_v1.sha256').write_text(digest+'  RECEIPT_v1.json\n')
    for row in json.loads(target.read_text())['artifacts']:
        data=(out/row['path']).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes']
    verify={'created_utc':datetime.now(timezone.utc).isoformat(),'receipt_sha256':digest,
            'artifact_count_verified':len(artifacts),'live_source_count_verified':len(sources),
            'all_artifact_hashes_and_sizes_match':True,'all_live_sources_match_snapshots':True,
            'all_result_script_bindings_match':True,'prior_inverse_receipt_sha256':expected,
            'prior_inverse_artifacts_verified_unchanged':len(prior['artifacts']),
            'original_checker_error_and_correction_preserved':True}
    (out/'RECEIPT_VERIFICATION_v1.json').write_text(json.dumps(verify,indent=2)+'\n')
    print(json.dumps(verify,indent=2))


if __name__=='__main__':main()
