#!/usr/bin/env python3
"""Independent quadrature, synthetic readout inversion and source-shape controls."""
from pathlib import Path
import hashlib
import json
import mpmath as mp


def main():
    mp.mp.dps=80
    out=Path(__file__).resolve().parent
    target=out/'results/numeric_run01.json'
    if target.exists():raise RuntimeError('Preserve existing result')
    def F(x):return (1+x)*mp.exp(-x)
    def logratio(mu,r1,r2):
        return mp.log1p(mu*r1)-mp.log1p(mu*r2)+mu*(r2-r1)
    def inverse_mu(target,r1,r2):
        lower=mp.mpf(0);upper=mp.mpf(1);expansions=0
        while logratio(upper,r1,r2)<target:
            upper*=2;expansions+=1
        initial_upper=upper
        iterations=0
        for iterations in range(320):
            mid=(lower+upper)/2
            if mid==lower or mid==upper:break
            if logratio(mid,r1,r2)<target:lower=mid
            else:upper=mid
        return (lower+upper)/2,{'initial_upper':str(initial_upper),'expansions':expansions,'iterations':iterations+1}
    inversion=[]
    specs=[('.03','.0001','1','3'),('.1','.7','.5','1.2'),('.2','4','.8','1.5')]
    for ks,mus,r1s,r2s in specs:
        kval,mu,r1,r2=map(mp.mpf,[ks,mus,r1s,r2s]);r3=2*r2
        mass=mp.mpf('1e-7');b=mp.mpf('.4')
        theta=mp.quad(lambda zz:2*mass*b/(b*b+zz*zz)**mp.mpf('1.5'),[-mp.inf,0,mp.inf])
        def read_excess(radius,mass_value=mass):
            acceleration=-mp.diff(lambda rr:mass_value*(1+kval*mp.exp(-mu*rr))/rr,radius)
            lensing=theta*mass_value/mass
            return 4*radius*radius*acceleration/(b*lensing)-1
        e1,e2,e3=map(read_excess,[r1,r2,r3])
        estimate,bracket=inverse_mu(mp.log(e1/e2),r1,r2)
        recovered_k=e1/F(estimate*r1)
        prediction=recovered_k*F(estimate*r3)
        dlog=estimate*((r2*r2)/(1+estimate*r2)-(r1*r1)/(1+estimate*r1))
        mass_values=[mp.mpf(x) for x in ['1e-9','1e-7','1e-5']]
        cancellation=max(abs(read_excess(r1,mm)-e1) for mm in mass_values)
        inversion.append({'input_k':ks,'input_mu':mus,'radii':[r1s,r2s,str(r3)],
                          'lensing_quadrature_error':str(abs(theta-4*mass/b)),
                          'excesses':list(map(str,[e1,e2,e3])),
                          'recovered_mu':str(estimate),'recovered_k':str(recovered_k),
                          'mu_relative_error':str(abs(estimate/mu-1)),
                          'k_absolute_error':str(abs(recovered_k-kval)),
                          'third_radius_prediction_error':str(abs(prediction-e3)),
                          'mass_normalization_cancellation_error':str(cancellation),
                          'dlog_mu_dlog_ratio':str(1/(estimate*dlog)),
                          'bracket':bracket})
    shells=[]
    for rs,ss,mus in [('3','.2','.7'),('2','1','1'),('5','.3','5')]:
        r,shell,mu=map(mp.mpf,[rs,ss,mus])
        numerical=mp.quad(lambda x:mp.exp(-mu*mp.sqrt(r*r+shell*shell-2*r*shell*x))/mp.sqrt(r*r+shell*shell-2*r*shell*x),[-1,1])/2
        expected=mp.exp(-mu*r)/r*mp.sinh(mu*shell)/(mu*shell)
        shells.append({'r':rs,'shell_radius':ss,'mu':mus,'angular_quadrature':str(numerical),
                       'external_shell_formula':str(expected),'relative_error':str(abs(numerical/expected-1))})
    # Same total mass and radius, two distinct nonnegative prescribed profiles.
    form_uniform=mp.quad(lambda radius:3*radius*mp.sinh(radius),[0,1])
    form_squared=mp.quad(lambda radius:5*radius**3*mp.sinh(radius),[0,1])
    amplitude=mp.mpf('.1');Hv=mp.mpf('.001')
    bodies=[]
    for label,form in [('uniform',form_uniform),('rho_proportional_to_r_squared',form_squared)]:
        kval=amplitude/form
        nu=(1-3*kval)/(4*Hv*Hv)-3*(1+kval)
        bodies.append({'profile':label,'M':1,'R':1,'mu':1,'Hv':str(Hv),
                       'form_factor':str(form),'k':str(kval),'nu':str(nu),
                       'excesses_at_r_2_3_5':[str(kval*form*F(mp.mpf(radius))) for radius in ['2','3','5']]})
    # Independent interior-ray integral for a uniform sphere, R=1, b=1/2.
    b=mp.mpf('.5');mass=mp.mpf('1e-7');zc=mp.sqrt(1-b*b)
    interior=2*(mp.quad(lambda zz:2*mass*b,[0,zc])+mp.quad(lambda zz:2*mass*b/(b*b+zz*zz)**mp.mpf('1.5'),[zc,mp.inf]))
    point=4*mass/b
    projected_fraction=1-(1-b*b)**mp.mpf('1.5')
    finite_rays=[]
    for length in ['1','10','100']:
        zz=mp.mpf(length);impact=mp.mpf(1)
        fraction=zz/mp.sqrt(zz*zz+impact*impact)
        finite_rays.append({'Z_over_b':length,'fraction_of_flat_infinite_deflection':str(fraction),'omitted_fraction':str(1-fraction)})
    scale=[]
    for ks in ['.000001','.00001','.01']:
        kval=mp.mpf(ks)
        parameter=mp.sqrt(1-3*kval)/(2*mp.sqrt(4+3*kval))
        scale.append({'k':ks,'nu':1,'Hv_r_over_c_at_mu_r_equal_one':str(parameter)})
    checks={
       'three_synthetic_inverse_cases':all(mp.mpf(row['mu_relative_error'])<mp.mpf('1e-60') and mp.mpf(row['k_absolute_error'])<mp.mpf('1e-65') for row in inversion),
       'three_lensing_quadratures':all(mp.mpf(row['lensing_quadrature_error'])<mp.mpf('1e-65') for row in inversion),
       'third_radius_predictions':all(mp.mpf(row['third_radius_prediction_error'])<mp.mpf('1e-65') for row in inversion),
       'mass_normalization_cancellation':all(mp.mpf(row['mass_normalization_cancellation_error'])<mp.mpf('1e-65') for row in inversion),
       'three_external_shell_quadratures':all(mp.mpf(row['relative_error'])<mp.mpf('1e-65') for row in shells),
       'two_profile_form_factors':abs(form_uniform-3/mp.e)<mp.mpf('1e-65') and abs(form_squared-(40/mp.e-5*mp.e))<mp.mpf('1e-65'),
       'same_mass_radius_distinct_couplings':bodies[0]['k']!=bodies[1]['k'] and max(abs(mp.mpf(a)-mp.mpf(b)) for a,b in zip(bodies[0]['excesses_at_r_2_3_5'],bodies[1]['excesses_at_r_2_3_5']))<mp.mpf('1e-65'),
       'body_examples_canonical_positive_parameters':all(0<mp.mpf(row['k'])<mp.mpf(1)/3 and mp.mpf(row['nu'])>0 for row in bodies),
       'interior_ray_requires_projected_mass':abs(interior/point-projected_fraction)<mp.mpf('1e-65') and abs(interior/point-1)>mp.mpf('.1'),
       'nu_one_small_k_transition_not_deeply_local':mp.mpf(scale[0]['Hv_r_over_c_at_mu_r_equal_one'])>mp.mpf('.24')}
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'precision_decimal_digits':mp.mp.dps,'scope':'Constructed ideal readouts and prescribed profiles only; no empirical data, cosmological reruns or curved-background error certification.',
            'inversion_cases':inversion,'shells':shells,'bodies':bodies,
            'interior_ray':{'b_over_R':'.5','numeric_fraction_of_point_deflection':str(interior/point),'projected_mass_fraction':str(projected_fraction)},
            'finite_flat_rays':finite_rays,'nu_one_scales':scale,
            'checks':checks,'failures':[key for key,value in checks.items() if not value]}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
