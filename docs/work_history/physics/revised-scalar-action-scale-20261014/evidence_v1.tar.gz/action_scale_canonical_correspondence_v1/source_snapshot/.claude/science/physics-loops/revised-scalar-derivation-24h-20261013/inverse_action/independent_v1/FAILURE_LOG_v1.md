# Complete execution record and preserved failure

1. `python3 derive_inverse_controls_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt`
   ran once, exit 0, all 25 compound checks true. Empty stderr.
2. `python3 rolling_numeric_controls_v1.py > results/numeric_run01.stdout.txt 2> results/numeric_run01.stderr.txt`
   ran once, exit 1. No runtime exception; empty stderr. The full result
   records failure of `all_nine_perturbation_response_cases` because the three
   second-normal cases did not exhibit quadratic reduction of errors already
   at approximately 1e-79 to 1e-77. All other compound checks were true.
3. `python3 roundoff_diagnosis_v1.py > results/roundoff_diagnosis_run01.stdout.txt 2> results/roundoff_diagnosis_run01.stderr.txt`
   ran once, exit 0, all five analytic diagnostic checks true. It proves that
   the second-normal central difference is exactly the predicted coefficient
   at every admissible step: background damping differences are even and
   force differences are linear. Empty stderr.
4. `python3 rolling_numeric_controls_v2.py > results/numeric_run02.stdout.txt 2> results/numeric_run02.stderr.txt`
   ran once, exit 0, all five compound checks true. Empty stderr. This fresh
   version/output preserves the original run. The only substantive change is
   to test the analytically exact second-normal direction for absolute error
   below 1e-65 at 80-digit precision, rather than convergence of roundoff.

No failed script/output was overwritten. All run results bind their executing
script SHA-256. The exact source change is preserved in `NUMERIC_V1_V2.diff`.
The corrected numerical values equal the first numerical values; this is a
test-criterion correction, not a replacement of unfavorable science data.

Separately, the source v1 static-transfer premise omitted a nonrelativistic
source restriction. The trace-free source control demonstrates the distinction.
The parent preserved v1 and supplied v2 with the restriction and trace-free
exception. The two source snapshots and exact source diff preserve that
scientific scope correction. No producer runner or output was accessed.
