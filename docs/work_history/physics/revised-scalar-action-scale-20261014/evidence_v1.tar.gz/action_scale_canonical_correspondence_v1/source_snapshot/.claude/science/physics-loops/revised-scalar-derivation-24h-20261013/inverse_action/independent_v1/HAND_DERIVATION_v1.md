# Independent inverse-action derivation and rolling counterexample

Checker `/root/scalar_energy_check`. Parent `/root` remains scientific author.
This derivation uses the supplied action and elementary differential geometry;
no producer runner or outputs have been read or imported. Q,Hv are positive
constants; K is a smooth positive definite field metric; C>0 is smooth.

## Action normalization, exchange, and first-jet reconstruction

For signature (-+++), vary

    S=Q int sqrt(-g)[R/2-K_AB dphi^A dphi^B-2Hv^2 U]+Sm[A^2 g,psi],
    A=sqrt(C), alpha_A=partial_A log A.

The scalar stress is

    Tphi_mn=2Q K_AB partial_m phi^A partial_n phi^B
            -Q g_mn[K_AB partial phi^A partial phi^B+2Hv^2 U].

In a homogeneous flat Einstein-frame metric this gives

    rhophi=Q[K(v,v)+2Hv^2 U],
    pphi=Q[K(v,v)-2Hv^2 U].

Einstein's equations therefore give

    3H^2=K(v,v)+2Hv^2 U+rho/Q,
    Hdot=-K(v,v)-(rho+p)/(2Q).

Matter variation is `delta Sm/sqrt(-g)=alpha_A Tm delta phi^A`, where
`Tm=-rho+3p`. There is no factor 1/2 in front of K in this action; scalar
variation consequently supplies the factor `1/(2Q)` in the matter force:

    D_t v^A+3H v^A+Hv^2 K^AB U_B
       =-K^AB alpha_B(rho-3p)/(2Q).

Contracting this equation with `2Q K_AB v^B` gives scalar energy loss to the
fluid. Total stress conservation then implies

    rhodot+3H(rho+p)=alpha(v)(rho-3p).

It follows directly that a specified curve and clock, known K,C,H,rho,p,
and known scales reconstruct

    U_gamma=[3H^2-T-rho/Q]/(2Hv^2), T=K(v,v),
    g_A=(dU)_A|gamma
       =-[K_AB(D_t v^B+3H v^B)+alpha_A(rho-3p)/(2Q)]/Hv^2.

This is a full covector gradient, not merely its tangent component. It uses
the supplied field trajectory and acceleration; expansion H alone does not
give those data. The necessary kinetic condition is
`T=-Hdot-(rho+p)/(2Q)>=0`, with equality iff v=0 by positive definiteness.

There is an exact off-shell compatibility identity. Define

    R=Hdot+T+(rho+p)/(2Q),
    E=rhodot+3H(rho+p)-alpha(v)(rho-3p).

Metric compatibility gives `Tdot=2K(v,D_t v)`. Substitution into the two
reconstructed expressions yields

    dU_gamma/dt-g(v) = 3H R/Hv^2 - E/(2Q Hv^2).

Thus both background equations make the first jet compatible. A reversed
matter-source sign instead leaves defect
`alpha(v)(3p-rho)/(Q Hv^2)` on shell. This is an explicit sign-sensitive
control, including a nonzero matter trace; the vacuum example below is not
the only check on conservation.

On a regular embedded curve segment choose smooth tubular coordinates
`(t,n1,n2)` whose first coordinate agrees with the curve clock. In the
associated covector basis, prescribe the reconstructed normal components
`g_i(t)` and put

    U(t,n)=U_gamma(t)+g_i(t)n_i.

The t derivative on n=0 agrees with the prescribed tangent covector because
`U_gamma'=g(v)`. This gives a smooth local extension of the compatible first
jet. The statement requires smooth data and a regular embedded segment.
It is not a global extension theorem across intersecting/recurrent paths,
or a claim that arbitrary expansion data satisfy the field equations.

## Exactly which Hessian entries remain free

Let f=(f1,f2) vanish on the curve, with df1,df2 linearly independent there.
They span the conormal covectors to its nonzero tangent. For any smooth
symmetric matrix B along the curve, extend it locally and define

    DeltaU=(1/2) f^T B f.

On the curve, both DeltaU and dDeltaU vanish, and direct differentiation gives

    Delta(U_;AB)=B_ij (partial_A f_i)(partial_B f_j).

Derivatives of B and the connection contribution multiply f or dDeltaU,
so they vanish there. This bilinear form annihilates v. Conversely, for any
smooth difference with zero first jet along the curve,

    0=nabla_v(dDeltaU)=(nabla dDeltaU)(v, .).

Symmetry fixes the corresponding column and row to zero. In three fields,
the remaining three independent Hessian components form an arbitrary
symmetric 2-by-2 normal block. Any such smooth form is represented by the
above B because the df_i are a conormal basis. This is a complete local
classification at second derivative order. It does not assert freedom in
the tangent block or in all higher derivatives independently.

The potential and its gradient are the only potential data in the background
field and Einstein equations. Thus the same curve, fluid, Einstein metric,
physical metric and initial conditions solve both local potentials exactly.
Smooth local uniqueness is consistent with this shared solution. A nonzero
perturbation or neighboring initial trajectory need not be shared.

If B is positive semidefinite throughout the chosen neighborhood, DeltaU>=0.
A nonnegative cutoff equal to one near a smaller compact curve segment may
localize this change without changing its first jet or Hessian there. Small
indefinite changes can preserve positivity where U has a positive lower
bound, but neither construction proves a global stability property.

For a stationary single-point history, only the value and gradient are
specified and the Hessian may change in every direction. This is different
from an isolated turning point of a nonregular curve, which is outside the
regular-segment proof. Multiple trajectories may constrain additional
directions; knowledge of the potential value throughout an open set fixes
its derivatives there. There is no no-go theorem for every observation set.

Linear scalar perturbations change by the potential mass operator

    Delta M^A_B=Hv^2 K^AC Delta(U_;CB).

K, its curvature, C, matter and the shared background are fixed. Linear
potential stress perturbations involve U and dU, so they do not change
directly. The full rolling perturbation system still contains its kinetic,
gravitational and matter terms. A different normal mass block can influence
propagation or coupled readouts; an unsourced, unread mode can remain hidden.
It is not legitimate to replace this rolling system by a static Yukawa mass.

## An independent curved, rolling helix

Use units Q=Hv=1, no fluid, and Euclidean three-field space in a cylindrical
chart `(r,theta,z)`, r>0. Take a small angular chart containing `|theta|<=1/4`.

    K=diag(1,r^2,1), L=1/2, b=1+L^2=5/4,
    f1=r-1, f2=z-L theta,
    C=exp(2 f2/5),
    H(theta)=2-b theta,
    U0=[3H(theta)^2-b]/2+(r-1)-3L H(theta) f2,
    DeltaU=(1/2)[3 f1^2+2 f1 f2+4 f2^2], U1=U0+DeltaU.

The proposed history, in Einstein proper time, is

    r(t)=1, theta(t)=t, z(t)=t/2,
    H(t)=2-5t/4,
    a_E(t)=a0 exp(2t-5t^2/8), rho=p=0.

In Cartesian field coordinates it is `(cos t,sin t,t/2)`: a nongeodesic
rolling helix, not a stationary point or a straight field trajectory.
Its speed squared is 5/4. The chart connection is
`Gamma^r_theta,theta=-r`, `Gamma^theta_r,theta=Gamma^theta_theta,r=1/r`.
Although the coordinate velocity `(0,1,1/2)` is constant, its covariant
acceleration is `(-1,0,0)`, hence nonzero.

Along this curve,

    C=1, U0=[3H(t)^2-5/4]/2,
    dU0=(1,-3H(t),-3H(t)/2),
    3H^2=5/4+2U0, Hdot=-5/4,
    D_t v+3H v+K^-1 dU0=0.

The same equations hold exactly for U1 because its first jet agrees. Both
Einstein and physical histories agree, since C=1 along the entire segment.
There are neighborhoods with r>0 and U0>0; DeltaU is nonnegative because
`B=[[3,1],[1,4]]` is positive definite. This is a local mathematical action
example in the stated general class, not a proposed replacement for the
campaign's exponential action or a fitted cosmology.

At r=1 the metric is the identity. The base covariant Hessian is

    [[0,3H,0],[3H,61/16,15/8],[0,15/8,0]],

and the change is

    Delta Hess U = [[3,-1/2,1],[-1/2,1,-2],[1,-2,4]].

The latter annihilates `(0,1,1/2)` and has eigenvalues `0,5/2,11/2`.
Its two nonzero directions are normal to the helix. The matter coupling
covector is `alpha=(0,-1/10,1/5)`, normal to the curve, with

    alpha^T Delta M alpha=1/4.

Thus even a curved rolling history can have identical first jets and a
different mass operator along a direction coupled to matter. This does not
compute a realizable measurement. A perturbation `DeltaU=f1` would preserve
the value alone but changes its gradient to `(1,0,0)` and fails the scalar
background equation; zero value by itself is insufficient.

## The existing exponential-action vacuum

Differentiate the supplied canonical action at u=x=y=0. In the u sector,

    K_u0=J0/(1+s)^2,
    alpha_0=alpha/(1+s),
    U_uu0=[12s a+nu(1+s)]/(1+s)^2.

The x and y terms are quadratic and have zero first derivatives at the
origin. Hence U0=3/2, dU0=0, C0=1 and H=Hv for every nu>0. Direct division
of U_uu0 by K_u0 gives

    m_u^2/Hv^2=4[3(1+k)+nu]/(1-3k),
    partial_nu(m_u^2/Hv^2)=4/(1-3k),
    alpha_0^2/K_u0=k.

These are positive for `0<k<1/3, nu>0`. The vacuum history alone therefore
does not identify nu even at known k, though perturbations can differ.
This does not preserve arbitrary rolling histories when nu changes, identify
the observed universe as the vacuum, or extend the earlier convergence
theorem beyond its separate nu hypothesis.

## Static transfer, its source, and inverse conditioning

In a locally flat frozen vacuum, linearize the action for a weak prescribed
source. In c=1 units, Fourier transformation of the static scalar equation
gives, for the u mode,

    delta u(q)=-alpha_0[rho_s(q)-3p_s(q)]/
                  [2Q K_u0(q^2+m_u^2)].

This is trace driven: a trace-free source gives zero scalar response. The
Newtonian nonrelativistic comparison uses negligible pressure/stress,
`Phi_N=-rho_s/(2Q q^2)` and physical potential
`Phi_phys=Phi_N+alpha_0 delta u`. It therefore gives

    h(q)=alpha_0 delta u/Phi_N=k q^2/(q^2+mu^2),
    mu=m_u/c.

The factor 1/(2Q) cancels in this ratio. At C=1 the background length units
of the frames agree. This transfer assumes known source normalization and
the stated readout; a weak relativistic source does not in general obey the
same formula. V1 omitted the nonrelativistic source restriction. The parent
has supplied v2 with this qualification and the trace-free exception.

The weak source expansion must also exclude ambient density of zeroth order:
the density-feedback term is second order only when the whole source density
is scaled down with its induced scalar perturbation. A frozen vacuum and
prescribed weak source meet that condition. Curvature, time dependence,
finite source size, boundary conditions and measurement maps still require
control before applying this flat static formula to a physical experiment.

For a point mass, the additional scalar potential is proportional to
`-k exp(-mu r)/r`. Differentiation gives the acceleration multiplier
`1+k(1+mu r)exp(-mu r)`. The spatial metric potential has the opposite scalar
conformal contribution. Thus a metric-potential ratio and a force ratio are
distinct readouts.

Put x_i=1/q_i^2 and y_i=1/h_i. Algebra gives

    y_i=c0+c1 x_i, c0=1/k, c1=mu^2/k,
    c1=(y1-y2)/(x1-x2),
    c0=(x1 y2-x2 y1)/(x1-x2),
    k=1/c0, mu^2=c1/c0.

Direct differentiation of `(h1,h2)` with respect to `(k,mu^2)` gives

    det J = k q1^2 q2^2(q2^2-q1^2)/
       [(q1^2+mu^2)^2(q2^2+mu^2)^2].

It is nonzero for k>0 and distinct positive q. To lie in the particular
exponential model requires c0>3, c1>0 and, with a separately calibrated Hv,

    nu=(1-3k)c^2 mu^2/(4Hv^2)-3(1+k)>0.

An exact compatible control in c=Hv=1 units is `k=1/10, mu^2=20, nu=1/5`:
q1=1,q2=3 give h1=1/210,h2=9/290 and reconstruct c0=10,c1=200. A third
q3=5 predicts h3=1/18. These are constructed algebraic inputs, not data.

Dimensionless conditioning follows from derivatives of log h with respect
to `(log k,log mu^2)`:

    J_log[i,:]=[1,-mu^2/(q_i^2+mu^2)].

When both q are much smaller than mu, both rows approach `(1,-1)`; when both
are much larger, both approach `(1,0)`. Either limit loses a singular value,
even though the finite exact determinant is nonzero. Nearly coincident q
also causes ill conditioning. Two exact samples identify conditional
parameters but do not test the two-parameter shape; a third scale supplies
an additional check only with an independently fixed readout and error map.
No likelihood, measured PPN parameter, cosmological growth reconstruction,
new empirical test, or initial-state selection is supplied here.
