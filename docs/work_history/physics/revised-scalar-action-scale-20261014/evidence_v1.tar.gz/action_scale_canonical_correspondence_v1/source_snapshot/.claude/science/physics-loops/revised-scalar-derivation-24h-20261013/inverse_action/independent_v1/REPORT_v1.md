# Focused independent inverse-action check

Checker `/root/scalar_energy_check`; scientific author remains `/root`.
Completed 2026-10-13. This is an internal mathematical check, not a formal
audit, empirical assessment or replacement authorship.

The first-jet reconstruction/conservation identity, local normal-Hessian
classification, canonical nu-vacuum example, static inverse formulas and
Jacobian determinant are correct within the stated hypotheses. One material
source-class omission was found: a weak source alone does not imply the
static scalar transfer; it must be a nonrelativistic mass source with the
specified Newtonian readout. A trace-free source gives zero scalar response.
The preserved v2 explicitly supplies this restriction. Its equations are
unchanged; no unresolved mathematical correction was found in the scoped v2.

## Sources and independence

The complete candidate v1 and canonical action were read before constructing
the independent checks. Frozen input SHA-256 identities are:

- Inverse v1: `5c313182c2de654674c17e895152976d691176a89709ac28b65bdc53e5e37ed2`.
- Canonical action: `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`.
- Inverse v2: `893fc65b3fb67e6c6676fa51b683b271cbc959b371bd2b443ed6a5007e96dcf4`.
- V2 correction note: `a49cd58934d841861972a45565d4c0fe4334cbe27c71cb99eaeaf6cf118cfa48`.

The full v2 and correction note were read after the issue was raised. The
independently generated `SOURCE_V1_V2.diff` confirms that only the version
label and source/readout qualification change. Both source versions remain
preserved. No producer runner, producer output or inherited cosmological
trajectory was read/imported/rerun. No empirical data were accessed.

## Checked mathematics and precise scope

`HAND_DERIVATION_v1.md` contains the complete ordinary proof from variation of
the declared action, including the normalization without a factor 1/2 before K.

- Direct Einstein and scalar variation reproduces the background equations,
  the matter force `-alpha^A(rho-3p)/(2Q)` and conservation exchange. For
  `R=Hdot+K(v,v)+(rho+p)/(2Q)` and
  `E=rhodot+3H(rho+p)-alpha(v)(rho-3p)`, the exact compatibility defect is
  `dU_gamma/dt-g(v)=3H R/Hv^2-E/(2Q Hv^2)`.
- A known regular curve, its clock and the supplied geometry/fluids determine
  the full first jet. Tubular coordinates extend a compatible smooth first
  jet locally. H alone does not identify the hidden field curve, K,C or frame
  conversion. Self-intersections, recurrence and nonregular turning points
  are outside this local extension argument.
- Two independent defining functions give every locally free symmetric normal
  Hessian block through `(1/2)f^T B f`. Conversely, differentiating the zero
  first jet along the curve forces its Hessian to annihilate the tangent.
  In three fields there are three free second-derivative components in the
  two-dimensional normal block. This is a local classification, not freedom
  in the tangent entries or all higher derivatives independently.
- The background solution is shared exactly because potential value and
  gradient agree. The linear mass operator differs by `Hv^2 K^-1 Delta Hess U`.
  This does not imply stability, a common basin, a global extension, invisibility
  to all perturbations, or a no-go theorem for every possible observation set.
- Direct differentiation at the canonical vacuum gives
  `m_u^2/Hv^2=4[3(1+k)+nu]/(1-3k)` and coupling norm k. For fixed k, every nu>0
  shares the same constant-field de Sitter history, but not the same mass.
  This neither preserves general rolling histories under nu changes nor
  extends the separate future-convergence theorem's nu range.
- A weak nonrelativistic prescribed source in a frozen, locally flat vacuum
  yields `h(q)=k q^2/(q^2+mu^2)`. The trace-free exception, force-versus-potential
  distinction, two-scale inverse, determinant, action compatibility and
  dimensionless conditioning all follow directly. Exact identifiability
  gives no measurement precision or observational acceptance.

## Independent curved rolling construction

The new control is a helix in Euclidean field space, expressed in a cylindrical
chart with `K=diag(1,r^2,1)`. Set Q=Hv=1, rho=p=0,
`f1=r-1`, `f2=z-theta/2`, `C=exp(2f2/5)` and `H(theta)=2-5theta/4`. Define

    U0=[3H(theta)^2-5/4]/2+(r-1)-(3/2)H(theta)f2,
    U1=U0+(1/2)[3f1^2+2f1f2+4f2^2].

Both potentials exactly solve the full homogeneous equations on
`(r,theta,z)=(1,t,t/2)` with `H=2-5t/4` and
`a_E=a0 exp(2t-5t^2/8)`, on a finite embedded chart segment. In Cartesian
fields the curve is `(cos t,sin t,t/2)` and its covariant acceleration is
nonzero. It has C=1 throughout, so the physical histories also agree.

The normal Hessian change is

    [[3,-1/2,1],[-1/2,1,-2],[1,-2,4]].

It annihilates the tangent `(0,1,1/2)` and has eigenvalues `0,5/2,11/2`.
The matter-coupled normal projection changes by `alpha^T Delta M alpha=1/4`.
This demonstrates the degeneracy for a genuinely curved rolling history;
it is a constructed action example, not a proposed physical model or a
static replacement for rolling perturbations. Local positivity is possible
because the base potential is positive on the compact curve segment and the
quadratic change is nonnegative.

## Executed controls, failure, and correction

`derive_inverse_controls_v1.py` ran once, exit 0: all 25 compound checks were
true. Its exact evidence includes the general conservation defect identity,
both helix solutions, connection/Hessian/tangent identities, nonzero normal
mass shift, canonical vacuum formulas, trace-free response, inverse and
determinant, and potential-to-force conversion. Three deliberate damaged
expressions are detected: reversed matter-source sign, preserving only the
potential value, and omitting the source trace.

The exact synthetic inversion control uses `k=1/10, mu^2=20, Hv=c=1`.
Inputs h(1)=1/210 and h(3)=9/290 reconstruct k,mu^2 and nu=1/5 exactly;
the third-scale prediction is h(5)=1/18. These are constructed numbers.

The first 80-digit numerical run exited 1. It reproduced both potentials'
background states and correct force differences, but its three second-normal
cases failed a quadratic-convergence criterion. Their errors were already
between approximately `3.37e-79` and `6.48e-77`: roundoff grew as the step
shrunk. The original script, full result, stdout and empty stderr are preserved.

`roundoff_diagnosis_v1.py` then proved the cause exactly: along that normal
displacement the two potentials are even in epsilon, their Friedmann H values
are even, and the force difference is linear. Its central difference has no
truncation error to converge. All five diagnostic checks returned true.

A separate v2 numerical script changes only its output path and the criterion
for that analytically exact direction to absolute error below `1e-65`; radial
quadratic convergence and tangent zero-response checks are unchanged. The
second run exited 0 with all five compound checks true. Its numerical values
are identical to the first run; `NUMERIC_V1_V2.diff` preserves the precise fix.
The complete failure account is in `FAILURE_LOG_v1.md`.

Each numerical run evaluates five exact background states for both potentials,
nine direction/time cases at three displacement scales, and three synthetic
inverse-conditioning cases. The corrected run's radial errors converge
quadratically to at most `1.66e-8` at epsilon=`1e-4`; tangent differences are
zero and the other normal response agrees within `6.48e-77`. These are
off-trajectory force comparisons, not integrated cosmological histories.

Dimensionless condition numbers for `q/mu=(.001,.002),(1,2),(1000,2000)` are
approximately `1.333337e6`, `7.5`, and `2.666670e6`. The log-Jacobian is
independently differentiated numerically and agrees with the analytic
expression. This verifies the stated conditioning limitation without assigning
an error model to any real observation.

## Remaining physical limitations and custody

The action, fields, metric, matter coupling, scales and trajectory remain
conditional inputs. Static h assumes a vacuum background, weak prescribed
nonrelativistic source, controlled flat/time-independent approximation and
known readout. Ambient density, nonlinear feedback, extended-source modeling,
curvature and rolling effects cannot be inferred from the two-parameter
inverse alone. Two points identify the conditional parameters but cannot
test the affine two-parameter shape. Nothing here fits or validates physical
observations, fixes an initial state or establishes a cosmological-to-local
measurement map.

All writes are confined to `inverse_action/independent_v1/`. Previous evidence,
parent source, git/PR/runtime state and repository authority/audit state remain
untouched. The separately proposed readout bridge is outside this original
receipt and has not been used in this report. No formal audit verdict is issued.
