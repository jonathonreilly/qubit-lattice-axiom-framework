#!/usr/bin/env python3
"""Independent action identities and a curved rolling helix counterexample."""
from pathlib import Path
import hashlib
import json
import sympy as s


def main():
    out = Path(__file__).resolve().parent
    target = out / 'results/exact_run01.json'
    if target.exists():
        raise RuntimeError('Preserve existing result; use a fresh version')
    checks = {}
    result = {}
    simp = lambda x: s.factor(s.simplify(x))
    H, Hd, T, Lacc, rho, p, rhod, av = s.symbols('H Hd T Lacc rho p rhod alpha_v')
    Q, Hv = s.symbols('Q Hv', positive=True)
    Udot = (6*H*Hd - 2*Lacc - rhod/Q)/(2*Hv**2)
    gradient_v = -(Lacc + 3*H*T + av*(rho-3*p)/(2*Q))/Hv**2
    ray_defect = Hd + T + (rho+p)/(2*Q)
    conservation_defect = rhod + 3*H*(rho+p) - av*(rho-3*p)
    identity = simp(Udot-gradient_v - 3*H*ray_defect/Hv**2
                    + conservation_defect/(2*Q*Hv**2))
    on_shell = simp((Udot-gradient_v).subs({Hd:-T-(rho+p)/(2*Q),
                       rhod:-3*H*(rho+p)+av*(rho-3*p)}))
    wrong_source_sign = -(Lacc+3*H*T-av*(rho-3*p)/(2*Q))/Hv**2
    wrong_source_defect = simp((Udot-wrong_source_sign).subs({Hd:-T-(rho+p)/(2*Q),
                       rhod:-3*H*(rho+p)+av*(rho-3*p)}))
    checks['general_first_jet_defect_identity'] = identity == 0
    checks['on_shell_first_jet_compatibility'] = on_shell == 0
    checks['wrong_trace_source_sign_detected'] = wrong_source_defect != 0
    result['first_jet'] = {'defect_identity_residual':str(identity),
                          'on_shell_residual':str(on_shell),
                          'wrong_source_sign_defect':str(wrong_source_defect)}

    # A helix in Euclidean field space, expressed in a cylindrical chart.
    # All geometry is derived from this independently supplied metric.
    r, theta, z, t = s.symbols('r theta z t', real=True)
    coordinates = [r,theta,z]
    K = s.diag(1,r*r,1)
    invK = K.inv()
    connection = [[[simp(sum(invK[i,l]*(s.diff(K[l,j],coordinates[k])
                         +s.diff(K[l,k],coordinates[j])-s.diff(K[j,k],coordinates[l]))
                         for l in range(3))/2)
                   for k in range(3)] for j in range(3)] for i in range(3)]
    pitch = s.Rational(1,2)
    speed2 = 1+pitch**2
    Htheta = 2-speed2*theta
    Ht = Htheta.subs(theta,t)
    f = s.Matrix([r-1,z-pitch*theta])
    beta = s.Rational(1,5)
    C = s.exp(2*beta*f[1])
    U0 = (3*Htheta**2-speed2)/2 + (r-1) -3*pitch*Htheta*f[1]
    B = s.Matrix([[3,1],[1,4]])
    delta = (f.T*B*f)[0]/2
    U1 = U0+delta
    curve = {r:1,theta:t,z:pitch*t}
    velocity = s.Matrix([0,1,pitch])
    covaccel = s.Matrix([simp(sum(connection[i][j][k]*velocity[j]*velocity[k]
                                  for j in range(3) for k in range(3))) for i in range(3)])
    def grad(U):
        return s.Matrix([s.diff(U,c) for c in coordinates])
    def covhess(U):
        g=grad(U)
        return s.Matrix(3,3,lambda i,j:simp(s.diff(g[j],coordinates[i])
                   -sum(connection[c][i][j]*g[c] for c in range(3))))
    full_checks=[]
    for U in (U0,U1):
        Tcurve=simp((velocity.T*K*velocity)[0].subs(curve))
        scalar=(covaccel+3*Ht*velocity+invK*grad(U)).subs(curve).applyfunc(simp)
        friedmann=simp(3*Ht**2-Tcurve-2*U.subs(curve))
        ray=simp(s.diff(Ht,t)+Tcurve)
        full_checks.append({'friedmann_residual':str(friedmann),'raychaudhuri_residual':str(ray),
                            'scalar_residuals':list(map(str,scalar))})
        assert Tcurve == speed2
    dgrad=grad(delta).subs(curve).applyfunc(simp)
    dhess=covhess(delta).subs(curve).applyfunc(simp)
    df=f.jacobian(coordinates).subs(curve)
    normal_formula=(dhess-df.T*B*df).applyfunc(simp)
    tangent_defect=(dhess*velocity).applyfunc(simp)
    # The base Hessian is not zero: this checks a genuinely rolling curved path.
    hess0=covhess(U0).subs(curve).applyfunc(simp)
    gc=grad(U0).subs(curve)
    Dg=s.Matrix([simp(s.diff(gc[i],t)-sum(connection[c][i][j].subs(curve)*velocity[j]*gc[c]
                          for c in range(3) for j in range(3))) for i in range(3)])
    tangent_hessian_identity=(hess0*velocity-Dg).applyfunc(simp)
    alpha=s.Matrix([s.diff(s.log(C)/2,c) for c in coordinates]).subs(curve).applyfunc(simp)
    coupling_mass_shift=simp((alpha.T*invK.subs(curve)*dhess*invK.subs(curve)*alpha)[0])
    simple_bad_change=f[0]
    bad_gradient=grad(simple_bad_change).subs(curve)
    checks['helix_two_exact_background_solutions'] = all(
        row['friedmann_residual']=='0' and row['raychaudhuri_residual']=='0'
        and all(x=='0' for x in row['scalar_residuals']) for row in full_checks)
    checks['helix_zero_value_and_gradient_difference'] = simp(delta.subs(curve))==0 and all(x==0 for x in dgrad)
    checks['helix_hessian_normal_formula'] = all(x==0 for x in normal_formula)
    checks['helix_hessian_annihilates_tangent'] = all(x==0 for x in tangent_defect)
    checks['helix_base_tangent_hessian_fixed'] = all(x==0 for x in tangent_hessian_identity)
    checks['helix_nonzero_covariant_acceleration'] = any(simp(x.subs(curve))!=0 for x in covaccel)
    checks['helix_background_conformal_factor_one'] = simp(C.subs(curve)-1)==0
    checks['helix_psd_nonzero_normal_hessian'] = dhess.eigenvals()=={s.Integer(0):1,s.Rational(5,2):1,s.Rational(11,2):1}
    checks['helix_matter_coupled_normal_shift_nonzero'] = coupling_mass_shift==s.Rational(1,4)
    checks['zero_value_without_zero_gradient_detected'] = any(x!=0 for x in bad_gradient)
    result['helix']={'metric':str(K),'conformal_factor':str(C),'H':str(Ht),
       'curve':['1','t','t/2'],'velocity':list(map(str,velocity)),
       'covariant_acceleration':list(map(str,covaccel.subs(curve))),
       'U0':str(s.expand(U0)),'delta_U':str(s.expand(delta)),'B':str(B),
       'background_checks':full_checks,'delta_gradient':list(map(str,dgrad)),
       'base_covariant_hessian':str(hess0),'delta_covariant_hessian':str(dhess),
       'normal_hessian_formula_residual':str(normal_formula),
       'tangent_annihilation_residual':str(tangent_defect),
       'base_tangent_hessian_identity_residual':str(tangent_hessian_identity),
       'delta_mass_eigenvalues':{str(x):v for x,v in dhess.eigenvals().items()},
       'coupling_projection_of_mass_shift':str(coupling_mass_shift),
       'bad_value_only_change_gradient':list(map(str,bad_gradient))}

    # Independent vacuum differentiation of the canonical potential and metric.
    k, nu, u = s.symbols('k nu u', positive=True)
    a=(1-k)*(1+3*k)/4
    al=s.sqrt(a)
    ss=(1+k)/(k*(1-3*k))
    E=s.exp(2*al*u);F=1+ss*E;J=1+(1-3*a)*ss*E
    Ku=J/F**2
    CC=(1+ss)*E/F
    Uvac=s.Rational(3,2)+3*ss*(E-1)**2/(2*F**2)+nu*(1+ss)*u*u/(2*F**2)
    Ku0=simp(Ku.subs(u,0))
    al0=simp((s.diff(CC,u)/(2*CC)).subs(u,0))
    grad0=simp(s.diff(Uvac,u).subs(u,0))
    mass=simp(s.diff(Uvac,u,2).subs(u,0)/Ku0)
    coupling=simp(al0*al0/Ku0)
    checks['vacuum_value_and_gradient'] = simp(Uvac.subs(u,0)-s.Rational(3,2))==0 and grad0==0
    checks['vacuum_conformal_factor'] = simp(CC.subs(u,0)-1)==0
    checks['vacuum_mass_formula'] = simp(mass-4*(3*(1+k)+nu)/(1-3*k))==0
    checks['vacuum_nu_mass_change'] = simp(s.diff(mass,nu)-4/(1-3*k))==0
    checks['vacuum_coupling_norm'] = simp(coupling-k)==0
    result['vacuum']={'K_u0':str(Ku0),'alpha0':str(al0),'U_gradient0':str(grad0),
                       'm_squared_over_Hv_squared':str(mass),'coupling_norm':str(coupling)}

    # A weak nonrelativistic source is required for the stated Newtonian transfer.
    q, m2, rho_s, w, K0, alpha0 = s.symbols('q m2 rho_s w K0 alpha0', positive=True)
    du=-alpha0*rho_s*(1-3*w)/(2*Q*K0*(q*q+m2))
    PhiN=-rho_s/(2*Q*q*q)
    transfer=simp((alpha0*du/PhiN).subs(alpha0**2,k*K0).subs(w,0))
    checks['static_nonrelativistic_transfer_from_force'] = simp(transfer-k*q*q/(q*q+m2))==0
    checks['static_trace_free_source_zero'] = simp(du.subs(w,s.Rational(1,3)))==0
    wrong_trace_free=simp(du.subs(w,0))
    checks['omit_source_trace_detected'] = wrong_trace_free!=0
    q1,q2 = s.symbols('q1 q2',positive=True)
    h1=k*q1*q1/(q1*q1+m2);h2=k*q2*q2/(q2*q2+m2)
    x1=1/q1**2;x2=1/q2**2;y1=1/h1;y2=1/h2
    c1=simp((y1-y2)/(x1-x2));c0=simp((x1*y2-x2*y1)/(x1-x2))
    jac=s.Matrix([h1,h2]).jacobian([k,m2])
    det=simp(jac.det())
    det_expected=k*q1*q1*q2*q2*(q2*q2-q1*q1)/((q1*q1+m2)**2*(q2*q2+m2)**2)
    checks['two_scale_exact_inverse'] = simp(c0-1/k)==0 and simp(c1-m2/k)==0
    checks['transfer_jacobian_determinant'] = simp(det-det_expected)==0
    # Exact compatible example: k=1/10, m^2=20, Hv=c=1 gives nu=1/5.
    example={k:s.Rational(1,10),m2:s.Integer(20),q1:1,q2:3}
    ex_h1=simp(h1.subs(example));ex_h2=simp(h2.subs(example))
    ex_c0=simp(c0.subs(example));ex_c1=simp(c1.subs(example))
    ex_k=1/ex_c0;ex_m2=ex_c1/ex_c0
    ex_nu=simp((1-3*ex_k)*ex_m2/4-3*(1+ex_k))
    h3=simp(1/(ex_c0+ex_c1/25))
    checks['compatible_three_scale_control'] = ex_k==s.Rational(1,10) and ex_m2==20 and ex_nu==s.Rational(1,5) and h3==s.Rational(1,18)
    radius,mu=s.symbols('radius mu',positive=True)
    potential=-(1+k*s.exp(-mu*radius))/radius
    force_factor=simp(radius**2*s.diff(potential,radius))
    checks['potential_to_acceleration_readout'] = simp(force_factor-(1+k*(1+mu*radius)*s.exp(-mu*radius)))==0
    result['static']={'scalar_amplitude_with_trace':str(du),'nonrelativistic_transfer':str(transfer),
          'trace_free_source_amplitude':str(simp(du.subs(w,s.Rational(1,3)))),
          'wrong_omitted_trace_amplitude':str(wrong_trace_free),
          'c0':str(c0),'c1':str(c1),'jacobian_determinant':str(det),
          'example':{'h1':str(ex_h1),'h2':str(ex_h2),'c0':str(ex_c0),'c1':str(ex_c1),
                     'reconstructed_k':str(ex_k),'reconstructed_m2':str(ex_m2),
                     'reconstructed_nu':str(ex_nu),'third_scale_h':str(h3)},
          'acceleration_factor':str(force_factor)}
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['checks']={name:bool(value) for name,value in checks.items()}
    result['failures']=[name for name,value in checks.items() if not value]
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if result['failures']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
