#!/usr/bin/env python3
"""Seal only the original inverse check, retaining its actual failed run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


def main():
    out=Path(__file__).resolve().parent
    repo=out.parents[5]
    excluded={'RECEIPT_v1.json','RECEIPT_v1.sha256','RECEIPT_VERIFICATION_v1.json'}
    for name in excluded:
        if (out/name).exists():
            raise RuntimeError('Preserve frozen output: '+name)
    sha=lambda b:hashlib.sha256(b).hexdigest()
    sources=[]
    for manifest_name in ['SOURCE_MANIFEST_v1.json','SOURCE_MANIFEST_v2.json']:
        for row in json.loads((out/manifest_name).read_text())['sources']:
            live=(repo/row['original_path']).read_bytes()
            snap=(out/row['snapshot_path']).read_bytes()
            assert live==snap and sha(snap)==row['sha256'] and len(snap)==row['bytes']
            sources.append({**row,'current_source_matches_snapshot':True})
    inspection=json.loads((out/'EXECUTION_INSPECTION_v1.json').read_text())
    for record in inspection['runs']:
        assert sha((out/record['script']).read_bytes())==record['script_sha256']
        result=json.loads((out/record['output']).read_text())
        assert result['script_sha256']==record['script_sha256']
        assert result['status']==record['status']
    first=json.loads((out/'results/numeric_run01.json').read_text())
    second=json.loads((out/'results/numeric_run02.json').read_text())
    assert first['failures']==['all_nine_perturbation_response_cases']
    assert not second['failures'] and all(second['checks'].values())
    assert first['background']==second['background']
    assert first['conditioning']==second['conditioning']
    for a,b in zip(first['responses'],second['responses'],strict=True):
        assert {k:v for k,v in a.items() if k!='checks'}=={k:v for k,v in b.items() if k!='checks'}
    artifacts=[]
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name not in excluded:
            data=path.read_bytes()
            artifacts.append({'path':str(path.relative_to(out)),'bytes':len(data),'sha256':sha(data)})
    receipt={
        'kind':'focused_independent_mathematics_check',
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'checker':'/root/scalar_energy_check','scientific_author':'/root',
        'scope':'Original inverse-action first-jet/conservation identity, local normal-Hessian degeneracy, independent curved helix, canonical nu-vacuum mass, static transfer/inverse/determinant and physical limitations.',
        'readout_bridge_included':False,
        'sources':sources,
        'mathematical_outcome':'No unresolved mathematical correction within scoped v2; v1 weak-source omission resolved by explicit nonrelativistic-source/readout qualification and trace-free exception.',
        'evidence':{'hand_derivation':'HAND_DERIVATION_v1.md','report':'REPORT_v1.md',
                    'failure_log':'FAILURE_LOG_v1.md',
                    'exact_compound_checks_true':25,'damage_probes':3,
                    'curved_rolling_example':'Nongeodesic helix with identical first jet and normal mass shifts 5/2 and 11/2.',
                    'numerical_runs':2,'background_states_per_run':5,'potentials_per_background':2,
                    'direction_time_cases_per_run':9,'step_sizes_per_case':3,
                    'conditioning_cases_per_run':3,'numeric_precision_decimal_digits':80,
                    'failed_run_preserved':'results/numeric_run01.json',
                    'failed_check':'Second-normal roundoff was incorrectly required to converge quadratically.',
                    'analytic_diagnosis':'results/roundoff_diagnosis_run01.json',
                    'corrected_run':'results/numeric_run02.json',
                    'corrected_run_numerical_values_identical':True},
        'producer_runner_or_outputs_read_or_imported':False,
        'inherited_cosmologies_rerun':False,'empirical_data_accessed':False,
        'formal_audit_performed':False,'parent_source_git_pr_runtime_audit_state_modified':False,
        'prior_evidence_modified':False,
        'artifact_count':len(artifacts),'artifact_paths_relative_to':str(out.relative_to(repo)),
        'artifacts':artifacts,'self_hash_exclusion':sorted(excluded)}
    path=out/'RECEIPT_v1.json';path.write_text(json.dumps(receipt,indent=2)+'\n')
    receipt_sha=sha(path.read_bytes())
    (out/'RECEIPT_v1.sha256').write_text(receipt_sha+'  RECEIPT_v1.json\n')
    for row in json.loads(path.read_text())['artifacts']:
        data=(out/row['path']).read_bytes()
        assert sha(data)==row['sha256'] and len(data)==row['bytes']
    verify={'created_utc':datetime.now(timezone.utc).isoformat(),
            'receipt_sha256':receipt_sha,'artifact_count_verified':len(artifacts),
            'live_source_count_verified':len(sources),'all_artifact_hashes_and_sizes_match':True,
            'all_live_sources_match_snapshots':True,'all_result_script_bindings_match':True,
            'original_failed_run_preserved':True,'corrected_run_numerical_values_identical':True}
    (out/'RECEIPT_VERIFICATION_v1.json').write_text(json.dumps(verify,indent=2)+'\n')
    print(json.dumps(verify,indent=2))


if __name__=='__main__':
    main()
