#!/usr/bin/env python3
"""Separate full-action helix force checks and dimensionless inverse conditioning."""
from pathlib import Path
import hashlib
import json
import mpmath as mp


def main():
    mp.mp.dps=80
    out=Path(__file__).resolve().parent
    target=out/'results/numeric_run01.json'
    if target.exists():
        raise RuntimeError('Preserve existing result; use a fresh version')
    def potentials(position):
        r,theta,z=position
        H=2-mp.mpf('1.25')*theta
        f1=r-1;f2=z-theta/2
        base=(3*H*H-mp.mpf('1.25'))/2+f1-mp.mpf('1.5')*H*f2
        shift=(3*f1*f1+2*f1*f2+4*f2*f2)/2
        return base,base+shift
    def homogeneous_acceleration(position,velocity,which):
        r,theta,z=position
        kinetic=velocity[0]**2+r*r*velocity[1]**2+velocity[2]**2
        U=potentials(position)[which]
        H=mp.sqrt((kinetic+2*U)/3)
        gradient=[mp.diff(lambda value,j=j:potentials(position[:j]+[value]+position[j+1:])[which],position[j]) for j in range(3)]
        invK=[1,1/(r*r),1]
        connection_vv=[-r*velocity[1]**2,2*velocity[0]*velocity[1]/r,0]
        acc=[-connection_vv[i]-3*H*velocity[i]-invK[i]*gradient[i] for i in range(3)]
        return H,acc
    velocity=[mp.mpf('0'),mp.mpf('1'),mp.mpf('.5')]
    background=[]
    for ts in ['-.25','-.1','0','.125','.25']:
        t=mp.mpf(ts);position=[mp.mpf(1),t,t/2]
        rows=[]
        for which in [0,1]:
            H,acc=homogeneous_acceleration(position,velocity,which)
            rows.append({'potential':which,'H':str(H),'coordinate_acceleration':list(map(str,acc)),
                         'H_error':str(abs(H-(2-mp.mpf('1.25')*t))),
                         'maximum_acceleration_error':str(max(abs(x) for x in acc))})
        background.append({'t':ts,'rows':rows})
    D=mp.matrix([[3,mp.mpf('-.5'),1],[mp.mpf('-.5'),1,-2],[1,-2,4]])
    directions={'radial':['1','0','0'],'second_normal':['0','-.5','1'],'tangent':['0','1','.5']}
    responses=[]
    for ts in ['-.2','0','.125']:
        t=mp.mpf(ts);position=[mp.mpf(1),t,t/2]
        for label,items in directions.items():
            direction=list(map(mp.mpf,items))
            predicted=-D*mp.matrix(direction)
            rows=[]
            for es in ['.01','.001','.0001']:
                epsilon=mp.mpf(es)
                differences=[]
                for sign in [1,-1]:
                    moved=[position[i]+sign*epsilon*direction[i] for i in range(3)]
                    _,a0=homogeneous_acceleration(moved,velocity,0)
                    _,a1=homogeneous_acceleration(moved,velocity,1)
                    differences.append([a1[i]-a0[i] for i in range(3)])
                observed=[(differences[0][i]-differences[1][i])/(2*epsilon) for i in range(3)]
                error=max(abs(observed[i]-predicted[i]) for i in range(3))
                rows.append({'epsilon':es,'central_difference':list(map(str,observed)),
                             'max_error':str(error),'error_over_epsilon_squared':str(error/epsilon**2)})
            errors=[mp.mpf(row['max_error']) for row in rows]
            if label=='tangent':
                checks={'zero_tangent_response':max(errors)<mp.mpf('1e-65')}
            else:
                checks={'second_order_convergence':all(errors[i+1]<errors[i]/90 for i in range(2)),
                        'small_final_error':errors[-1]<mp.mpf('1e-6')}
            responses.append({'t':ts,'direction':label,'vector':items,'predicted_acceleration_difference':list(map(str,predicted)),
                              'rows':rows,'checks':checks})
    conditioning=[]
    for scale_s in ['.001','1','1000']:
        scale=mp.mpf(scale_s);qvalues=[scale,2*scale]
        logk=mp.log(mp.mpf('.1'));logm2=mp.mpf(0)
        def logh(logparameters,q):
            kval=mp.exp(logparameters[0]);m2=mp.exp(logparameters[1])
            return mp.log(kval*q*q/(q*q+m2))
        point=[logk,logm2]
        numerical=mp.matrix([[mp.diff(lambda value,j=j,q=q:logh(point[:j]+[value]+point[j+1:],q),point[j])
                                    for j in range(2)] for q in qvalues])
        expected=mp.matrix([[1,-1/(1+q*q)] for q in qvalues])
        eig=mp.eigsy(numerical.T*numerical,eigvals_only=True)
        singular=[mp.sqrt(eig[i]) for i in range(2)]
        conditioning.append({'q_over_mu':list(map(str,qvalues)),'log_jacobian':[[str(numerical[i,j]) for j in range(2)] for i in range(2)],
                             'derivative_residual':str(max(abs(x) for x in numerical-expected)),
                             'singular_values_ascending':list(map(str,singular)),
                             'spectral_condition_number':str(singular[1]/singular[0])})
    checks={'two_potentials_match_five_background_states':all(mp.mpf(row['H_error'])<mp.mpf('1e-65') and mp.mpf(row['maximum_acceleration_error'])<mp.mpf('1e-65') for case in background for row in case['rows']),
            'all_nine_perturbation_response_cases':all(all(case['checks'].values()) for case in responses),
            'dimensionless_conditioning_derivatives':all(mp.mpf(case['derivative_residual'])<mp.mpf('1e-65') for case in conditioning),
            'extreme_scales_poorly_conditioned':all(mp.mpf(conditioning[i]['spectral_condition_number'])>mp.mpf('1e6') for i in [0,2]),
            'middle_scales_better_conditioned':mp.mpf(conditioning[1]['spectral_condition_number'])<10}
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'precision_decimal_digits':mp.mp.dps,
            'scope':'Constructed helix background and first-order full homogeneous acceleration differences, plus synthetic transfer conditioning; no empirical data or inherited trajectories.',
            'background':background,'responses':responses,'conditioning':conditioning,
            'checks':checks,'failures':[key for key,value in checks.items() if not value]}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if result['failures']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
