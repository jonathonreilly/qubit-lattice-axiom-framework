#!/usr/bin/env python3
"""Diagnose the preserved convergence-test failure without editing that run."""
from pathlib import Path
import hashlib
import json
import sympy as s


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/roundoff_diagnosis_run01.json'
    if target.exists():
        raise RuntimeError('Preserve existing diagnostic')
    r,theta,z,t,e=s.symbols('r theta z t epsilon',real=True)
    H=2-s.Rational(5,4)*theta
    f1=r-1;f2=z-theta/2
    U0=(3*H*H-s.Rational(5,4))/2+f1-s.Rational(3,2)*H*f2
    DU=(3*f1*f1+2*f1*f2+4*f2*f2)/2
    normal_shift={r:1,theta:t-e/2,z:t/2+e}
    oncurve={r:1,theta:t,z:t/2}
    U0_shift=s.expand(U0.subs(normal_shift))
    DU_shift=s.expand(DU.subs(normal_shift))
    gradDU=s.Matrix([s.diff(DU,c) for c in [r,theta,z]]).subs(normal_shift).applyfunc(s.expand)
    U0_even=s.simplify(U0_shift-U0_shift.subs(e,-e))
    DU_even=s.simplify(DU_shift-DU_shift.subs(e,-e))
    U0_coefficient=s.simplify((U0_shift-U0.subs(oncurve))/e**2)
    DU_coefficient=s.simplify(DU_shift/e**2)
    force=-gradDU/e
    expected=s.Matrix([-s.Rational(5,4),s.Rational(5,2),-5])
    force_residual=(force-expected).applyfunc(s.simplify)
    checks={'base_potential_exactly_even':U0_even==0,
            'potential_difference_exactly_even':DU_even==0,
            'base_normal_quadratic_coefficient':U0_coefficient==-s.Rational(75,128),
            'difference_normal_quadratic_coefficient':DU_coefficient==s.Rational(25,8),
            'exact_normal_force_coefficient':all(x==0 for x in force_residual)}
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'failed_run':'results/numeric_run01.json',
            'cause':'The second-normal central difference has no truncation error: both Friedmann H values are even in epsilon, the metric stays fixed, and the force difference is exactly linear. Requiring error to decay as epsilon^2 tests roundoff instead of convergence.',
            'base_potential_even_residual':str(U0_even),'difference_even_residual':str(DU_even),
            'base_normal_quadratic_coefficient':str(U0_coefficient),
            'difference_normal_quadratic_coefficient':str(DU_coefficient),
            'exact_acceleration_difference_over_epsilon':list(map(str,force)),
            'force_residual':str(force_residual),'checks':checks,
            'revision':'Preserve the first script/output; for this analytically exact normal direction require max error <1e-65 at 80-digit precision. Retain quadratic convergence for radial perturbations and zero tangent response.',
            'status':'diagnosed_exact_cancellation' if all(checks.values()) else 'diagnosis_failed'}
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__=='__main__':
    main()
