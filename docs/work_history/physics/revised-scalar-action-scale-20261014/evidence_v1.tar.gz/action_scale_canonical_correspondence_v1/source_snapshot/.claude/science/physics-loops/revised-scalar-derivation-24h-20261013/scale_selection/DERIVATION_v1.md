# The remaining classical scale: a precise obstruction to selecting it

Direct author /root, October 14, 2026. New personally derived conditional
result; focused independent checking is pending. No quantum theory, observation
fit or universal impossibility theorem is claimed. Units c=hbar=1 throughout.

## Which observation would identify which parameter?

At the specified constant-scalar vacuum, the supplied candidate action gives
H_E=Hv, alpha_m^2=k, Q=Q0(1+k). In its weak, unsuppressed local vacuum regime,
the measured Newton coefficient would be

    G_vac=(1+k)/(8 pi Q)=1/(8 pi Q0).

Here G_vac refers to that stipulated regime, not an assumed experimental
measurement in our actual environment. If the same physical vacuum H_vac=Hv
were independently identified, the dimensionless hierarchy would be

    r=Hv^2/Q0=8 pi G_vac H_vac^2.                      (1)

Both environmental identifications remain to be checked. In a rolling or
matter-filled cosmology, the observed present expansion H0 is not automatically
Hv; it cannot silently replace H_vac in (1). Knowing a laboratory unit standard
does not supply a gravitational/vacuum ratio. An observation can calibrate r
once its forward model is justified; that is different from a theory selecting
r before calibration.

## Source-free classical action

The inherited action is

    S_g=Q integral sqrt(-g) [R/2-K_AB grad(phi^A)grad(phi^B)-2Hv^2 U] d^4x.

K and U depend on dimensionless fields and supplied dimensionless k,nu. Write
xi=Hv*x and the dimensionless line element dbar(s)^2=Hv^2 ds^2. Thus the
physical curvature is Hv^2 Rbar and the four-volume is Hv^-4 times the barred
volume. The scalar kinetic term scales by Hv^2. Exactly,

    S_g=Xi I[gbar,phi;k,nu],
    Xi=Q/Hv^2=(1+k)/r,
    I=integral sqrt(-gbar)[Rbar/2-K_AB bargrad(phi^A)bargrad(phi^B)-2U] d^4xi.
                                                                  (2)

For every Xi>0, delta S_g=0 is equivalent to delta I=0 when Xi is a fixed
parameter rather than a varied field. The entire source-free dimensionless
classical solution set, not merely the constant vacuum, is independent of Xi.
This includes dimensionless geometric/scalar boundary or initial data held
fixed. Choosing those data is still a separate assumption. A boundary condition
that explicitly depends on Xi, a measure over histories, or variation with
respect to Xi would add a premise; none follows from the supplied equations.

Therefore the source-free classical equations and Xi-independent dimensionless
boundary data cannot select one value of r from this positive parameter family.
This is an exact limited nonselection statement. It does not assert that all
physical observations are identical when Q is changed, that matter is absent
from the universe, or that a quantum completion cannot select a hierarchy.

## A units choice is not a selection mechanism

Under a change of length unit by a factor lambda>0 with c=hbar=1, the numerical
Hv changes to lambda*Hv and the numerical Q0 to lambda^2*Q0. Thus r and Xi are
unchanged. Two theories with unequal r are not identified by a units convention.
The prefactor cancellation in the classical vacuum equations is a degeneracy
of those equations with respect to physical parameters, not license to call
an observed dimensionless hierarchy a unit choice.

## What matter and an independently known mass change

The matter stress in the metric equation enters as T/(Q Hv^2) after this
rescaling. Holding known physical matter parameters fixed does not generically
leave the same dimensionless histories when Q changes. No scaling symmetry of
the complete measured matter theory is asserted.

For a prescribed point-source worldline, S_m=-M integral ds_J. In barred
variables S_m=-(M/Hv) integral dbar(s)_J. Dividing the total classical action
by Xi leaves the dimensionless source coefficient

    M Hv/Q=8 pi m Hv,  m=M/(8 pi Q).

At fixed Hv,k,nu, scaling Q0->lambda Q0 and an UNKNOWN source mass
M->lambda M preserves this coefficient and the weak exterior geometry, clock
ratios and lensing/force parameters. It changes the physical hierarchy r by
1/lambda. This is a family of different source-mass assignments, not equal
physical masses, and is removed if M is independently known in fixed units.
It makes explicit why a gravitational readout with an uncalibrated source
cannot alone fix Q0. No universal rescaling of atomic clocks, particle masses,
thermal distributions or known laboratory masses is being adopted.

More generally, supplied stress profiles that scale with Q keep T/Q fixed;
known thermal matter with fixed particle masses need not obey that operation.
The already derived initial-value and inverse results therefore remain
conditional on matter calibration. Their dimensionless mathematics cannot be
counted as an independent prediction of Q0 or r.

## Where a new mechanism would have to enter

In a quantum amplitude exp(i Xi I), Xi is relevant even in the vacuum sector;
the preceding classical cancellation is not a quantum equivalence. Defining a
quantum state, renormalized action, measure or dynamical extra field could change
the selection problem. Those are unconstructed inputs here, not derived rules.
Extremizing over Xi merely because it is free would change the variational
problem and must not be counted as a consequence of the inherited action.
No value of r, Q0, Hv, k,nu or an initial state is selected by this argument.

## Frozen exact controls before execution

Verify the four-dimensional scaling of volume, curvature, kinetic and potential
terms, the Xi-independent variational equation, G_vac cancellation, r's unit
invariance and the physical-parameter/source rescaling separately. Use exact
rational lambda values 1/7,2,11. Keep Hv and k fixed while varying Q0: all
source-free dimensionless equations must be unchanged, while the predicted
force of a FIXED known mass changes. With the simultaneously changed unknown
source mass, m and M Hv/Q must be unchanged. The zero-Q and zero-Hv limits are
outside the stated positive domain and must not be divided through. These are
exact algebraic controls of a scoped argument, not actual observation tests.
