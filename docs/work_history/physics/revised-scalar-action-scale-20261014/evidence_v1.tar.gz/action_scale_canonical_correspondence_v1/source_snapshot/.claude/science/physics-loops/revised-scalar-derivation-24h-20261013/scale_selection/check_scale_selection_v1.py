#!/usr/local/bin/python3
from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
import sympy as s
p=Path(__file__).resolve().parent;o=p/'evidence_v1';assert not o.exists();o.mkdir()
Q0,H,k,lam,M=s.symbols('Q0 H k lambda M',positive=True);Q=Q0*(1+k);r=H**2/Q0;Xi=Q/H**2;R,K,U,V=s.symbols('R K U V');rows=[]
def check(n,expr):rows.append({'name':n,'passed':s.simplify(expr)==0})
original=Q*H**-4*V*(H**2*R/2-H**2*K-2*H**2*U)
check('four_dimensional_action_scaling',original-Xi*V*(R/2-K-2*U))
check('variation_prefactor',s.diff(Xi*V*(R/2-K-2*U),U)/Xi-s.diff(V*(R/2-K-2*U),U))
check('vacuum_newton_cancellation',(1+k)/(8*s.pi*Q)-1/(8*s.pi*Q0))
check('physical_hierarchy',r-8*s.pi*(1/(8*s.pi*Q0))*H**2)
check('units_invariance',(lam*H)**2/(lam**2*Q0)-r)
check('prefactor_relation',Xi-(1+k)/r)
check('worldline_coefficient',(M/H)/Xi-M*H/Q)
for v in [s.Rational(1,7),s.Integer(2),s.Integer(11)]:
 check('unknown_mass_coefficient_'+str(v),(v*M)*H/(v*Q)-M*H/Q)
 check('unknown_mass_m_'+str(v),(v*M)/(8*s.pi*v*Q)-M/(8*s.pi*Q))
 check('known_mass_force_changes_'+str(v),M/(8*s.pi*v*Q)-(M/(8*s.pi*Q))/v)
 check('physical_hierarchy_changes_'+str(v),H**2/(v*Q0)-r/v)
 check('dimensionless_vacuum_equation_'+str(v),(v*Xi*s.Symbol('E'))/(v*Xi)-s.Symbol('E'))
rows.extend([{'name':'positive_domain_required','passed':bool(Q.is_positive and H.is_positive and Xi.is_positive)},{'name':'nonselection_is_not_equal_known_mass_force','passed':bool(s.simplify(M/(16*s.pi*Q)-M/(8*s.pi*Q))!=0)}])
rout={'source_sha256':hashlib.sha256((p/'DERIVATION_v1.md').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'completed_at':datetime.now(timezone.utc).isoformat(),'passed':sum(v['passed'] for v in rows),'failed':sum(not v['passed'] for v in rows),'checks':rows,'scope':'Exact dimensional/action argument, no empirical or quantum inference'}
(o/'RESULTS.json').write_text(json.dumps(rout,indent=2)+'\n');print(json.dumps(rout,indent=2));raise SystemExit(rout['failed']!=0)
