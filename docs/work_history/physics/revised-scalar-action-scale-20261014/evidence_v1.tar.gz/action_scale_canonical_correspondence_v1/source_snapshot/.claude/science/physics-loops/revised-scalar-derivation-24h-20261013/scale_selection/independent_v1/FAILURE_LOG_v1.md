# Actual execution and damage-control record

This independent scale block has one scientific execution,
`check_scale_v1.py`, with exit 0, 36 passing top-level compound checks and
no failed checks. Full stdout and empty stderr are preserved. No earlier
failed version of this program exists and no output was overwritten.

Four deliberately incorrect symbolic expressions were detected by nonzero
residuals. They test the volume power, unit power for Q0, fixed-known-mass
amplitude, and a time-dependent coefficient incorrectly treated as constant.
They are controlled algebra mutations and are not reported as failed source
executions. No producer program or result was read or imported.

No source correction is requested by this check. The positive fixed
parameter, fixed dimensionless variational domain, prescribed vacuum/local
regime and conditional source/matter limitations are essential. The report
does not extend cancellation of field equations to canonical/quantum/matter
equivalence or selection of a physical hierarchy.

All prior independent receipts and their actual failures remain unchanged.
