# Independent classical scale derivation

Checker /root/scalar_energy_check; scientific author /root. This is a focused
check of the supplied scale-selection source, not a formal audit or a new
physical selection mechanism. The full source and complete action were read.
No producer code/output is used. This derivation and the separate protocol
were written before the control program was executed.

Use c=hbar=1. Q and Q0 have mass dimension two, Hv has mass dimension one,
the scalar fields and k,nu are dimensionless, and K,U,C contain no Hv or Q0.
The action is

    S_g=Q integral sqrt(-g)[R/2-K_AB partial phi^A partial phi^B-2Hv^2 U],
    Q=Q0(1+k)>0.

In coordinates xi=Hv x define dbar(s)^2=Hv^2 ds^2. Thus, in the xi
coordinate basis, the physical metric components equal Hv^-2 times the
barred ones. Constant rescaling leaves the connection and covariant Ricci
tensor unchanged, multiplies the inverse metric by Hv^2 and multiplies the
four-volume by Hv^-4. Both R and the contracted scalar kinetic term acquire
Hv^2. The explicit potential coefficient already contains Hv^2. Therefore

    S_g=(Q/Hv^2) I,
    I=integral sqrt(-gbar)[Rbar/2-K_AB bargrad phi^A bargrad phi^B-2U].

This is a four-dimensional statement. It uses one dimensionless variational
domain/function space, with initial/boundary data and allowed variations
independent of Xi=Q/Hv^2. Any boundary terms needed for that chosen
variational problem must be handled consistently. Multiplication of the
whole chosen functional by the fixed nonzero constant Xi leaves its
stationary set unchanged: delta S_g=Xi delta I. This applies to every
metric/scalar configuration in that domain, not just de Sitter or a homogeneous
example. It does not assert existence for every possible boundary condition.

For fixed k,nu and any dimensionless solution, changing Q0 at fixed Hv
already provides a family with different Xi and the same dimensionless
classical field equations. Since r=Hv^2/Q0=(1+k)/Xi, those equations and
Xi-independent dimensionless data cannot single out a value of r. This is
nonselection by a specified variational problem. It is not a universal
impossibility theorem. Xi-dependent boundary data, a parameter-dependent
ensemble, matter calibration or variation of Xi adds something to that
problem. Xi=0 destroys the equivalence, while Hv=0 makes these barred
variables undefined; neither is in the positive domain.

The claim concerns field equations and their solution sets. Even classically,
action values, canonical momenta/symplectic normalization and corresponding
charges scale with an overall action coefficient. It would be too strong to
call the complete classical theories equivalent merely from equal stationary
sets. The source does not make that stronger claim. Quantum phases exp(i Xi I)
likewise retain Xi, so the cancellation is not a quantum equivalence or a
calculation of radiative stability, a measure, a state or a renormalized action.

## Vacuum calibration and units

At the supplied stationary scalar point, U=3/2 and C=1. The metric equation
has cosmological constant Lambda=2Hv^2 U=3Hv^2. The stipulated expanding,
spatially flat de Sitter solution has H_E=Hv. This does not imply that every
constant-scalar vacuum geometry has one FLRW expansion rate, or that an
observed rolling/matter-filled H0 equals Hv.

From the exact supplied K,C at that point, alpha_m^2=k. With the action's
normalization Gstar=1/(8 pi Q), a weak nonrelativistic point source has the
local flat-leading physical potential

    Phi=-Gstar M[1+k exp(-mu R)]/R.

Its force coefficient is Gstar[1+k(1+mu R)exp(-mu R)]. In a weak regime
with mu R and Hv R small, with the required compact/unsuppressed source,
the limiting Newton coefficient is

    G_vac=(1+k)/(8 pi Q)=1/(8 pi Q0).

The short-distance limit is a regime statement; taking R to zero at fixed
nonzero source mass would eventually violate weak fields. Such a regime
requires an appropriate scale window and source. It is not guaranteed for
an arbitrary finite body, stressed source or actual environment. The source
note explicitly stipulates the weak unsuppressed local vacuum regime and
does not claim its measurement. Under that identification and the separate
vacuum expansion identification,

    r=Hv^2/Q0=8 pi G_vac H_vac^2.

This is a calibration identity, not a prediction of either input. A known
clock/length standard defines units, not the value of this dimensionless
gravitational ratio.

For clarity take the new length unit to be lambda times the old one. With
c=hbar=1 the numerical values transform as

    R_new=R/lambda, M_new=lambda M,
    Hv_new=lambda Hv, Q0_new=lambda^2 Q0.

Consequently r, Xi, Hv R, m/R and M Hv/Q are invariant. This is a unit
conversion. It cannot map unequal r values into each other. By contrast,
changing the physical coefficient Q0 to lambda Q0 at fixed Hv in fixed
units sends Xi to lambda Xi and r to r/lambda. Confusing these two
operations would incorrectly erase the physical parameter family.

## Matter and the unknown source

Physical energy density/orthonormal stress has mass dimension four. In the
barred metric equation it is weighted by T/(Q Hv^2). Coordinate components
must also be transformed if changing coordinates; the stated ratio refers
to physical stress/density components with the corresponding barred frame.
An equivalent derivation varies the matter action after the coordinate and
metric rescaling. Keeping a known stress scale fixed while Q changes alters
this dimensionless forcing. It does not cancel with the vacuum prefactor.

For the specified point worldline,

    S_m=-M integral ds_J=-(M/Hv) integral dbar(s)_J.

Because C(phi) is dimensionless and does not contain Q0 or Hv, the same
rescaling holds in the physical frame. Dividing S_g+S_m by Xi leaves the
source coefficient

    gamma=M Hv/Q=8 pi m Hv, m=M/(8 pi Q).

At fixed Hv,k,nu, a physical change Q0->lambda Q0 combined with an unknown
mass reassignment M->lambda M preserves gamma and m. All specified weak
exterior readouts depending on m,Hv,k,nu at fixed physical events/radii are
therefore unchanged within that model. In fact the formal gravity plus
point-worldline action is simply multiplied by lambda. This algebra does
not resolve its source singularity or construct a supported finite body;
the source's limited weak exterior statement is sufficient here.

The reassigned masses are not physically equal in fixed units. If M is
known and held fixed, gamma and m instead scale as 1/lambda. The predicted
unsuppressed force coefficient G_vac M also scales as 1/lambda; the specific
unknown-mass degeneracy is then broken. This does not by itself prove that
every inverse problem with a known mass is unique, because other unknown
model/environment/source parameters can remain.

Likewise scaling a prescribed stress profile with Q keeps T/Q fixed, but
that creates different matter assignments. It is not a symmetry of a
complete measured matter theory with fixed masses, temperatures, clocks or
laboratory calibration. No universal matter or quantum equivalence is
asserted. The checked conclusion is restricted to the source-free classical
equations with Xi-independent dimensionless data, plus the stated conditional
unknown-source rescaling. No positive value of r is selected by either.
