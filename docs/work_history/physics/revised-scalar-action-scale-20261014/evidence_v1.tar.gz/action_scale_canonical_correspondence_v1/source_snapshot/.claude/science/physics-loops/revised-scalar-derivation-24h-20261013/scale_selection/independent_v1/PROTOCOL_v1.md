# Independent control protocol

Written before executing the controls. Frozen sources: scale derivation v1
and the complete supplied canonical action, with identities recorded in
SOURCE_MANIFEST_v1.json. No producer code/output, empirical data or inherited
cosmology is accessed. This is a local exact-algebra check, not an integration
of a history or delegation of main scientific authorship.

The handwritten argument proves the full functional prefactor result.
Controls will separately verify four-dimensional metric scaling, the
three action terms, the supplied vacuum coupling and calibration identity,
unit conversion, known stress/source response, and unknown-source rescaling.
An explicit dimensionless lapse/scale-factor/scalar minisuperspace Lagrangian
will illustrate the same constant-prefactor cancellation in nontrivial
Euler-Lagrange equations. It is a symbolic illustration, not a restriction
of the general proof or a new cosmology run.

Use exact rational independent input values

    Q0=13/5, Hv=7/11, k=2/17, nu=5/9,
    M=19/130000000, R=1/101, rho=23/17000000.

The radius is a bookkeeping input for dimensionless unit invariants and a
force-coefficient expression, not a claim of an exact measured finite-radius
Newton limit. Test physical scaling factors lambda=1/7,2,11 and an additional
5/3. In physical-parameter tests Hv,k,nu and the unit conventions stay fixed.
Compare both fixed M and reassigned M->lambda M, and fixed versus reassigned
stress. In unit tests length unit changes by lambda, so numerical Hv,M
multiply by lambda, Q0 by lambda^2 and R divides by lambda.

Planned damage controls are: use the wrong volume power; use the wrong Q0
unit power; hold M fixed but claim its source amplitude is invariant; and
promote the fixed overall parameter to a time-dependent coefficient in a
test variational problem. Each should produce a nonzero residual. Zero Q
and zero Hv are explicitly excluded, with a separate zero-prefactor witness
showing why cancellation cannot be extended there.

All check results, residual expressions, exact rational cases, stdout,
stderr and any actual failures will be retained. No approximate numerical
solver is needed. No complete classical/matter/quantum equivalence, actual
vacuum identification, global inverse or selected hierarchy is inferred.
