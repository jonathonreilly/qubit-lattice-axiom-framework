# Focused independent scale-selection check

The scale derivation is mathematically correct within its declared scope.
No source correction is requested. An overall positive fixed coefficient
Xi=Q/Hv^2 multiplies the entire dimensionless source-free classical action.
It cancels from its stationary equations on one Xi-independent variational
domain. Thus those equations and dimensionless initial/boundary data cannot
select r=Hv^2/Q0=(1+k)/Xi when k,nu are fixed. This is a limited classical
nonselection statement, not a universal impossibility theorem or an
equivalence of full classical, matter or quantum theories.

/root remains scientific author. /root/scalar_energy_check performed this
focused independent check. No producer code/output was read or imported;
no empirical input, cosmological trajectory, subagent, git/PR/runtime/lock/
audit mutation or parent-source edit was used. This is not a formal audit.

## Exact sources and derivation

The complete source and complete canonical action were read. Their immutable
snapshots and original paths are in SOURCE_MANIFEST_v1.json.

| Source | SHA-256 |
|---|---|
| scale_selection/DERIVATION_v1.md | `a2db5082da526ecdd0b471e5f32176df411aa2f29220122f59854f3b3c2db178` |
| Complete canonical action note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |

HAND_DERIVATION_v1.md reconstructs the argument directly. In xi=Hv x
coordinates, g_phys=Hv^-2 gbar. Constant scaling leaves the connection and
covariant Ricci tensor unchanged; the inverse metric gives Hv^2, and the
four-volume gives Hv^-4. Curvature, scalar kinetic and explicit potential
terms consequently share the coefficient Q/Hv^2. The general variational
identity delta(Xi I)=Xi delta I proves the full stated stationary-set result;
the symbolic homogeneous example is an illustration, not its replacement.

The variational domain, allowed variations and boundary treatment must be
the same and independent of Xi. The source correctly excludes Xi-dependent
boundary prescriptions, a measure over histories, and variation of Xi itself.
Q and Hv must be positive in the declared construction. The zero-Q case
would have an identically zero gravitational variation; the Hv=0 case
cannot be divided through in these barred coordinates. No claim that a
separate zero-Hv theory is impossible follows from this coordinate failure.

Equal classical stationary sets do not imply equal action values, canonical
normalizations or charges. Quantum phases retain the prefactor. These
distinctions reinforce the source's stated boundary rather than contradict
it. The action or a quantum/matter selection mechanism has not been derived
from this cancellation. k and nu occur in I and are held fixed; their own
dependence is not erased by the argument.

## Calibration, units and source mass

At the supplied scalar vacuum U=3/2, C=1 and alpha_m^2=k. The specified
expanding de Sitter solution has H_E=Hv. In the stipulated weak unsuppressed
local regime, G_vac=(1+k)/(8 pi Q)=1/(8 pi Q0), so
r=8 pi G_vac H_vac^2 if that vacuum and local forward model are independently
identified. This remains calibration, not parameter selection. A rolling
or matter-filled observed H0 cannot silently replace H_vac.

The Newton expression is a short-distance/unsuppressed regime coefficient
for the stated weak nonrelativistic point or sufficiently compact source.
It does not hold automatically for arbitrary finite bodies, profiles,
stresses or environments. The weak and short-range conditions need a
compatible scale window; R->0 at fixed nonzero mass is not a uniformly weak
limit. No existence of that window for an observed source, or actual
measurement of G_vac, was inferred here. The source explicitly stipulates
the regime and recognizes the environmental identifications.

A unit change with new length unit lambda times the old one makes numerical
Hv and masses multiply by lambda, Q0 by lambda^2 and radii divide by lambda.
It leaves r and Xi unchanged. A physical coefficient change at fixed units,
Q0->lambda Q0 with Hv,k,nu fixed, instead gives r->r/lambda and Xi->lambda Xi.
Unequal r values therefore remain distinct under unit conversion.

For the prescribed physical worldline, ds_J=dbar(s)_J/Hv because C is
dimensionless. Dividing the total action by Xi leaves gamma=M Hv/Q=8 pi m Hv,
m=M/(8 pi Q). An unknown mass reassignment M->lambda M along with the
physical Q0 change leaves gamma and m fixed. The specified exterior kernels
at fixed physical radii depend on those quantities and the unchanged Hv,k,nu,
so their weak-model readouts are unchanged. The assigned physical masses
are different. The entire formal gravity plus that worldline action scales
by lambda; this does not resolve the point-source interior or construct a body.

If M is independently known and held fixed, m, gamma and the stipulated
unsuppressed force coefficient instead change by 1/lambda. This breaks that
specific scaling family; it does not prove uniqueness of every inverse
problem with other unknown parameters. Likewise fixed physical stress
changes T/(Q Hv^2), while a prescribed stress reassignment T->lambda T
preserves it. The latter is different matter data, not a symmetry of measured
thermal/particle matter. The stress notation refers to physical density or
orthonormal stress; coordinate tensor components require their coordinate
and frame conversion too. No complete matter equivalence is assumed.

## Exact controls and actual results

The hand derivation and PROTOCOL_v1.md were written before executing the
control program; their hashes are embedded in its output. Independent exact
inputs are Q0=13/5, Hv=7/11, k=2/17, nu=5/9, M=19/130000000, R=1/101 and
rho=23/17000000. The finite R is bookkeeping for unit invariants and a
force-coefficient expression, not an observed or exact finite-radius
Newton-limit assertion. Test factors are 1/7,2,11 and the additional 5/3.

At the baseline,

    r=245/1573, Xi=29887/4165, B=2392/99,
    m=17/(2704000000 pi), gamma=119/3718000000.

All following factors are exact, with Hv,k,nu and physical radii fixed in
the physical-parameter cases:

| Physical Q0 factor | r factor | Xi factor | Known-M force and gamma factor | Reassigned-M m and gamma factor |
|---|---:|---:|---:|---:|
| 1/7 | 7 | 1/7 | 7 | 1 |
| 2 | 1/2 | 2 | 1/2 | 1 |
| 11 | 1/11 | 11 | 1/11 | 1 |
| 5/3 | 3/5 | 5/3 | 3/5 | 1 |

The separate unit transformations leave r,Xi,gamma and m/R unchanged at
every factor. Known stress remains different under physical scaling even
in the table's reassigned-M column, because rho was not silently rescaled.
A separate exact identity checks the distinct prescribed-stress rescaling.

The command
`python3 check_scale_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt`
completed once with exit 0. All 36 top-level named compound checks passed.
Four exact factor cases also retain their six subchecks each; these are
included in the compound count, not counted as additional independent proofs.
The program uses exact symbolic/rational SymPy algebra, without a numerical
orbit solver. Full symbolic Euler-Lagrange expressions are retained.

Four deliberate algebra errors yield nonzero residuals: the wrong volume
power, the wrong Q0 unit power, a falsely unchanged known-mass amplitude,
and treating a time-dependent action coefficient as constant. The last
introduces the extra term 2 K b^3 Xi' q'/N in the scalar Euler-Lagrange
equation, showing why promoting the parameter changes the problem. These
are explicit damaged expressions, not altered producer-source executions.

No execution or named check failed in this independent block; stderr is
preserved and empty. FAILURE_LOG_v1.md records that fact without erasing
failures from earlier independent blocks. Source snapshots, derivation,
protocol, code, full results/stdout/stderr, report and receipt are hash-bound.
No observational value of r, Q0, Hv, k,nu or an initial state is obtained.
