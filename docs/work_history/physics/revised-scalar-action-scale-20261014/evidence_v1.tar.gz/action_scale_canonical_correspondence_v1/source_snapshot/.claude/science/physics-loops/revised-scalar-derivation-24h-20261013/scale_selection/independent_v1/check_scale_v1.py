#!/usr/bin/env python3
"""Independent exact scale controls; no producer imports or empirical input."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import sys
import sympy as s


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/exact_run01.json'
    if target.exists():raise RuntimeError('Preserve existing result')
    Q0,Hv,k,nu,M,R,rho,lam,Xi=s.symbols('Q0 Hv k nu M R rho lambda Xi',positive=True)
    Q=Q0*(1+k);ratio=Hv**2/Q0;prefactor=Q/Hv**2
    checks={}
    def check(name,value):checks[name]=bool(value)
    def zero(expr):return s.simplify(expr)==0
    g0,g1,g2,g3=s.symbols('g0 g1 g2 g3',positive=True)
    gbar=s.diag(-g0*g0,g1*g1,g2*g2,g3*g3)
    gphys=gbar/Hv**2
    check('four_volume_Hv_to_minus_four',zero(s.sqrt(-gphys.det())-s.sqrt(-gbar.det())/Hv**4))
    check('inverse_metric_Hv_squared',all(zero(x) for x in gphys.inv()-Hv**2*gbar.inv()))
    # Abstract derivative and inverse components for one general Christoffel
    # contraction: all factors are arbitrary, so cancellation is structural.
    gi=s.symbols('inverse0:4');dg=s.symbols('derivative0:4')
    gammabar=sum(gi[i]*dg[i] for i in range(4))/2
    gammaphys=sum((Hv**2*gi[i])*(dg[i]/Hv**2) for i in range(4))/2
    check('constant_metric_scaling_connection_cancels',zero(gammaphys-gammabar))
    Ric=s.Matrix(4,4,lambda i,j:s.Symbol(f'Ric{i}{j}'))
    curvature_bar=s.trace(gbar.inv()*Ric)
    curvature_phys=s.trace(gphys.inv()*Ric)
    check('curvature_Hv_squared',zero(curvature_phys-Hv**2*curvature_bar))
    grad=s.Matrix(s.symbols('gradient0:4'))
    check('scalar_kinetic_Hv_squared',zero((grad.T*gphys.inv()*grad)[0]-Hv**2*(grad.T*gbar.inv()*grad)[0]))
    Rbar,Tbar,U=s.symbols('Rbar Tbar U')
    density=Rbar/2-Tbar-2*U
    transformed=Q/Hv**4*(Hv**2*Rbar/2-Hv**2*Tbar-2*Hv**2*U)
    check('all_action_terms_share_Q_over_Hv_squared',zero(transformed-prefactor*density))
    check('Xi_equals_one_plus_k_over_r',zero(prefactor-(1+k)/ratio))
    # A nontrivial symbolic action-derived homogeneous illustration, without
    # solving or integrating any cosmological trajectory.
    t=s.symbols('xi_time',real=True)
    b=s.Function('b')(t);q=s.Function('q')(t);N=s.Function('N')(t)
    K=s.Function('K')(q);V=s.Function('U')(q)
    L=-3*b*s.diff(b,t)**2/N+b**3*K*s.diff(q,t)**2/N-2*N*b**3*V
    def EL(ll,field):return s.diff(s.diff(ll,s.diff(field,t)),t)-s.diff(ll,field)
    unscaled={name:s.factor(EL(L,field)) for name,field in [('scale_factor',b),('scalar',q),('lapse',N)]}
    for name,field in [('scale_factor',b),('scalar',q),('lapse',N)]:
        check('constant_prefactor_EL_'+name,zero(EL(Xi*L,field)-Xi*EL(L,field)))
    aa=(1-k)*(1+3*k)/4;ss=(1+k)/(k*(1-3*k))
    J0=1+(1-3*aa)*ss
    coupling=aa/J0
    check('supplied_vacuum_alpha_squared_is_k',zero(coupling-k))
    Gstar=1/(8*s.pi*Q)
    Gvac=(1+coupling)*Gstar
    check('vacuum_Newton_cancellation',zero(Gvac-1/(8*s.pi*Q0)))
    check('vacuum_hierarchy_calibration_identity',zero(8*s.pi*Gvac*Hv**2-ratio))
    check('deSitter_expanding_vacuum_constraint',zero(3*Hv**2-2*Hv**2*s.Rational(3,2)))
    zz=s.symbols('mu_R',nonnegative=True)
    check('unsuppressed_force_kernel_limit',s.limit((1+zz)*s.exp(-zz),zz,0)==1)
    m=M/(8*s.pi*Q);gamma=M*Hv/Q
    check('worldline_coefficient_after_dividing_Xi',zero((M/Hv)/prefactor-gamma))
    check('source_coefficient_equals_8pi_m_Hv',zero(gamma-8*s.pi*m*Hv))
    unit={Q0:lam**2*Q0,Hv:lam*Hv,M:lam*M,R:R/lam}
    check('unit_r_invariant',zero(ratio.subs(unit,simultaneous=True)-ratio))
    check('unit_Xi_invariant',zero(prefactor.subs(unit,simultaneous=True)-prefactor))
    check('unit_source_coefficient_invariant',zero(gamma.subs(unit,simultaneous=True)-gamma))
    check('unit_Hv_R_and_m_over_R_invariant',zero((Hv*R).subs(unit,simultaneous=True)-Hv*R) and zero((m/R).subs(unit,simultaneous=True)-m/R))
    known={Q0:lam*Q0}
    unknown={Q0:lam*Q0,M:lam*M}
    check('physical_r_changes_by_inverse_lambda',zero(ratio.subs(known,simultaneous=True)-ratio/lam))
    check('physical_Xi_changes_by_lambda',zero(prefactor.subs(known,simultaneous=True)-lam*prefactor))
    check('known_mass_m_and_source_change',zero(m.subs(known,simultaneous=True)-m/lam) and zero(gamma.subs(known,simultaneous=True)-gamma/lam))
    force=Gvac*M/R**2
    check('known_mass_unsuppressed_force_changes',zero(force.subs(known,simultaneous=True)-force/lam))
    check('unknown_mass_m_and_source_unchanged',zero(m.subs(unknown,simultaneous=True)-m) and zero(gamma.subs(unknown,simultaneous=True)-gamma))
    Ii,Jj=s.symbols('I J')
    total=prefactor*Ii-M/Hv*Jj
    check('gravity_and_reassigned_worldline_action_scale_together',zero(total.subs(unknown,simultaneous=True)-lam*total))
    stress=rho/(Q*Hv**2)
    check('fixed_stress_forcing_changes',zero(stress.subs(known,simultaneous=True)-stress/lam))
    check('reassigned_stress_forcing_invariant',zero(stress.subs({Q0:lam*Q0,rho:lam*rho},simultaneous=True)-stress))
    # The control domain is strictly positive; a zero overall action would
    # have zero variation even for a nonstationary unit-variation witness.
    check('zero_prefactor_not_equivalent_witness',0*s.Integer(1)==0 and s.Integer(1)!=0)
    varying=s.Function('Xi')(t)
    time_damage=s.factor(EL(varying*L,q)-varying*EL(L,q))
    damages={
        'wrong_volume_power':s.factor(Q/Hv**3*(Hv**2*density)-prefactor*density),
        'wrong_Q0_unit_power':s.factor(ratio.subs({Q0:lam*Q0,Hv:lam*Hv},simultaneous=True)-ratio),
        'known_mass_falsely_invariant':s.factor(m.subs(known,simultaneous=True)-m),
        'time_dependent_coefficient_falsely_constant':time_damage,
    }
    check('four_symbolic_damage_residuals_nonzero',all(value!=0 for value in damages.values()))
    check('time_coefficient_damage_has_derivative_term',zero(time_damage-s.diff(varying,t)*s.diff(L,s.diff(q,t))))
    inputs={Q0:s.Rational(13,5),Hv:s.Rational(7,11),k:s.Rational(2,17),nu:s.Rational(5,9),M:s.Rational(19,130000000),R:s.Rational(1,101),rho:s.Rational(23,17000000)}
    cases=[]
    B=4*(3*(1+k)+nu)/(1-3*k)
    base={'r':ratio,'Xi':prefactor,'m':m,'gamma':gamma,'fixed_mass_force_coefficient_at_R':force,'normalized_stress':stress,'B':B}
    for factor in [s.Rational(1,7),s.Integer(2),s.Integer(11),s.Rational(5,3)]:
        rows={}
        for name,expr in base.items():
            rows[name]={'baseline':str(s.simplify(expr.subs(inputs))),
                        'physical_known_M':str(s.simplify(expr.subs(known,simultaneous=True).subs(lam,factor).subs(inputs))),
                        'physical_reassigned_M':str(s.simplify(expr.subs(unknown,simultaneous=True).subs(lam,factor).subs(inputs)))}
        local_checks={
            'r_ratio':zero(ratio.subs(known,simultaneous=True).subs(lam,factor).subs(inputs)/ratio.subs(inputs)-1/factor),
            'Xi_ratio':zero(prefactor.subs(known,simultaneous=True).subs(lam,factor).subs(inputs)/prefactor.subs(inputs)-factor),
            'known_force_ratio':zero(force.subs(known,simultaneous=True).subs(lam,factor).subs(inputs)/force.subs(inputs)-1/factor),
            'known_force_is_different':not zero((force.subs(known,simultaneous=True).subs(lam,factor)-force).subs(inputs)),
            'reassigned_m_and_gamma':zero((m.subs(unknown,simultaneous=True).subs(lam,factor)-m).subs(inputs)) and zero((gamma.subs(unknown,simultaneous=True).subs(lam,factor)-gamma).subs(inputs)),
            'unit_r_Xi_gamma_mR':all(zero((expr.subs(unit,simultaneous=True).subs(lam,factor)-expr).subs(inputs)) for expr in (ratio,prefactor,gamma,m/R)),
        }
        check('exact_lambda_'+str(factor).replace('/','_')+'_case',all(local_checks.values()))
        cases.append({'lambda':str(factor),'values':rows,'checks':local_checks})
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256':hashlib.sha256((out/'PROTOCOL_v1.md').read_bytes()).hexdigest(),
            'hand_derivation_sha256':hashlib.sha256((out/'HAND_DERIVATION_v1.md').read_bytes()).hexdigest(),
            'arithmetic':'Exact SymPy rational and symbolic algebra; no floating solver or producer function.',
            'input':{str(key):str(value) for key,value in inputs.items()},
            'unscaled_minisuperspace_EL':{key:str(value) for key,value in unscaled.items()},
            'damage_residuals':{key:str(value) for key,value in damages.items()},
            'cases':cases,'checks':checks,'failures':[key for key,value in checks.items() if not value],
            'environment':{'python':sys.version,'sympy':s.__version__,'platform':platform.platform()},
            'scope':'Source-free classical fixed-parameter variational set; conditional source/matter assignments and stipulated vacuum calibration. No full matter or quantum equivalence.'}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
