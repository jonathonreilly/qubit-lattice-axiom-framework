#!/usr/bin/env python3
"""Seal or verify only this independent scale evidence folder."""
from pathlib import Path
import datetime
import hashlib
import json
import sys


OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
EXCLUDED={'MANIFEST_v1.json','RECEIPT_v1.json','RECEIPT_v1.sha256'}


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    receipt=json.loads((OUT/'RECEIPT_v1.json').read_text())
    digest=(OUT/'RECEIPT_v1.sha256').read_text().split()[0]
    assert sha(OUT/'RECEIPT_v1.json')==digest
    assert sha(OUT/'MANIFEST_v1.json')==receipt['manifest_sha256']
    manifest=json.loads((OUT/'MANIFEST_v1.json').read_text())
    for row in manifest['artifacts']:
        path=OUT/row['path']
        assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
    for row in receipt['sources']:
        assert sha(ROOT/row['original_path'])==sha(OUT/row['snapshot_path'])==row['sha256']
    expected={row['path'] for row in manifest['artifacts']}|EXCLUDED
    actual={str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file()}
    assert actual==expected
    assert len(manifest['artifacts'])==manifest['artifact_count']==receipt['artifact_count']
    print(json.dumps({'status':'verified','receipt_sha256':digest,'artifact_count':receipt['artifact_count'],
                      'live_source_pairs':len(receipt['sources']),'named_compound_checks':receipt['named_compound_checks']},indent=2))


def seal():
    reserved=EXCLUDED|{'SOURCE_VERIFICATION_v1.json','EXECUTION_RECORD_v1.json'}
    for name in reserved:
        if (OUT/name).exists():raise RuntimeError('Preserve existing '+name)
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    source_manifest=json.loads((OUT/'SOURCE_MANIFEST_v1.json').read_text())
    sources=source_manifest['sources']
    bindings=[]
    for row in sources:
        live=ROOT/row['original_path'];snap=OUT/row['snapshot_path']
        bindings.append({**row,'live_sha256_at_seal':sha(live),'snapshot_sha256_at_seal':sha(snap),
                         'matches':sha(live)==sha(snap)==row['sha256'] and live.stat().st_size==snap.stat().st_size==row['bytes']})
    verification={'verified_utc':stamp,'sources':bindings,'all_match':all(x['matches'] for x in bindings)}
    (OUT/'SOURCE_VERIFICATION_v1.json').write_text(json.dumps(verification,indent=2)+'\n')
    assert verification['all_match']
    result=json.loads((OUT/'results/exact_run01.json').read_text())
    assert result['failures']==[] and all(result['checks'].values())
    assert result['script_sha256']==sha(OUT/'check_scale_v1.py')
    assert result['protocol_sha256']==sha(OUT/'PROTOCOL_v1.md')
    assert result['hand_derivation_sha256']==sha(OUT/'HAND_DERIVATION_v1.md')
    assert (OUT/'results/exact_run01.stderr.txt').read_bytes()==b''
    assert (OUT/'results/exact_run01.stdout.txt').read_bytes()==(OUT/'results/exact_run01.json').read_bytes()
    execution={'command':'python3 check_scale_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt',
               'exit_code_observed':0,'result_sha256':sha(OUT/'results/exact_run01.json'),
               'named_compound_checks':len(result['checks']),'failed_checks':0,'failed_executions':0,
               'damage_expression_count':len(result['damage_residuals']),
               'exact_cases':[x['lambda'] for x in result['cases']],
               'producer_code_output_accessed':False,'cosmology_or_empirical_run':False}
    (OUT/'EXECUTION_RECORD_v1.json').write_text(json.dumps(execution,indent=2)+'\n')
    artifacts=[{'path':str(path.relative_to(OUT)),'bytes':path.stat().st_size,'sha256':sha(path)}
               for path in sorted(OUT.rglob('*')) if path.is_file() and str(path.relative_to(OUT)) not in EXCLUDED]
    manifest={'schema':'focused_independent_artifact_manifest_v1','created_utc':stamp,
              'artifact_count':len(artifacts),'excluded_self_and_receipt_files':sorted(EXCLUDED),'artifacts':artifacts}
    (OUT/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
    receipt={'schema':'focused_independent_math_check_receipt_v1','created_utc':stamp,
             'checker':'/root/scalar_energy_check','scientific_author':'/root','formal_audit':False,
             'scope':'Classical source-free fixed-prefactor nonselection, unit invariants and conditional prescribed-source/matter scaling under the supplied action.',
             'sources':sources,'source_manifest_sha256':sha(OUT/'SOURCE_MANIFEST_v1.json'),
             'source_verification_sha256':sha(OUT/'SOURCE_VERIFICATION_v1.json'),
             'report_path':'REPORT_v1.md','report_sha256':sha(OUT/'REPORT_v1.md'),
             'manifest_path':'MANIFEST_v1.json','manifest_sha256':sha(OUT/'MANIFEST_v1.json'),
             'artifact_count':len(artifacts),'named_compound_checks':len(result['checks']),
             'failed_checks':0,'failed_executions':0,'damage_expression_count':len(result['damage_residuals']),
             'source_corrections_requested':[],
             'essential_boundaries':['Xi is a fixed positive parameter, with k,nu fixed and one Xi-independent variational domain.','The Newton coefficient and de Sitter expansion are conditional vacuum/regime identifications, not measurements.','Known physical matter/source calibration changes the inverse; unknown-mass scaling reassigns physical masses.','Equal classical stationary sets do not imply canonical, complete matter or quantum equivalence.','No parameter hierarchy, quantum mechanism or physical initial state is selected.'],
             'producer_code_or_output_read':False,'empirical_data_accessed':False,
             'parent_source_git_pr_runtime_lock_or_audit_modified':False,'prior_receipts_modified':False}
    (OUT/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
    digest=sha(OUT/'RECEIPT_v1.json');(OUT/'RECEIPT_v1.sha256').write_text(digest+'  RECEIPT_v1.json\n')
    verify()


if __name__=='__main__':
    if sys.argv[1:]==['--verify']:verify()
    elif not sys.argv[1:]:seal()
    else:raise SystemExit('Use no argument to seal, or --verify for read-only verification.')
