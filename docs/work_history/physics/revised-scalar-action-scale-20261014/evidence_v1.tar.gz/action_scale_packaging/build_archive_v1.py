from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'action_scale_packaging';dest=wt/'docs/work_history/physics/revised-scalar-action-scale-20261014'
roots=['inverse_action','scale_selection','action_scale_canonical_correspondence_v1','action_scale_packaging']
seal_units=['inverse_action/independent_v1','inverse_action/independent_readout_v1','scale_selection/independent_v1','action_scale_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional first-jet reconstruction, local same-source lensing/acceleration inverse and classical scale-selection obstruction, with full histories and scoped independent reviews. No selected action/state/scale or measured likelihood.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for revised scalar action/scale reconstruction

Live claim: docs/EXPONENTIAL_SCALAR_ACTION_SCALE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

A known field curve, clock, matter, target metric and conformal coupling determine
only the potential value and first derivatives along that curve. Explicit
zero-first-jet deformations preserve the same background while changing normal
Hessians and perturbations. This is a local construction on a regular embedded
curve, not a global theorem about recurrent trajectories or all observations.

A frozen weak local source model supplies a conditional two-scale/two-radius
inverse for the scalar amplitude and range. It requires a known common exterior
geometry and negligible source pressure. Finite-body response and local curvature
cannot be dropped from that premise. A reserved third synthetic radius is a
prospective shape check, not an independent observed test.

A fixed positive overall source-free classical action coefficient cancels from
stationary equations on a common parameter-independent variational domain. This
neither selects the dimensionless hierarchy nor equates quantum theories.
Unknown-source normalization leaves a real degeneracy; known physical source
mass can break it. Conditional vacuum Newton and Hubble scales are not observed
laboratory G or H0 without a bridge.

Fresh canonical111/0: inverse64, readout23, scale24. The full result matches the
staged object, every row and all substantive tables. Three actual altered programs
are rejected: zero-first-jet loss87/24, lensing sign110/1, scale power108/3.
Independent source results are reused by exact identity; the staged405/0 assertion
count concerns correspondence and wrapper tests, not new physical evidence.

Earlier inverse convergence failure and exact roundoff diagnosis, and the
independent readout equal-mass/equal-lensing illustration error, remain in full.
That illustration now holds the observed monopole fixed with different physical
masses. Original source qualifications, corrected criteria and passing-but-
incomplete controls are recoverable. Earlier independent damaged-expression
probes are not misdescribed as executed altered producer programs.

All synthetic examples are exposed development data. No observed likelihood,
held-out empirical acceptance, unique action, initial state or scale is selected.
Extract only safe regular relative members and verify every manifest size/hash.
Archive-build/commit and delivery/UNIT records follow this archive.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
