"""Freeze selected, checked milestone-5 evidence only; safe regular members."""
import datetime, gzip, hashlib, io, json, pathlib, tarfile
p = pathlib.Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
a = p/'initial_state/alternative_radiation'
out = pathlib.Path('docs/work_history/physics/revised-scalar-alternative-radiation-20261014/evidence_v1.tar.gz')
assert not out.exists(), 'Never overwrite an evidence archive'
names = '''DERIVATION_v1.md DERIVATION_v2.md check_alternative_v1.py check_alternative_v2.py diagnostic_v1.py PROTOCOL_v1.json REPAIR_v2.json EXECUTION_FAILURE_v1.json DIAGNOSTIC_v1.json DIAGNOSTIC_v1.stderr.txt DIAGNOSTIC_v1.stdout.txt EXECUTION_v2.json EXECUTION_v2.stderr.txt EXECUTION_v2.stdout.json PROOF_IDENTITIES_v2.json results_v2/RESULTS.json CHECKER_V1_V2.diff SOURCE_V1_V2.diff PHYSICAL_RADIATION_BRIDGE_v1.md PHYSICAL_RADIATION_BRIDGE_v2.md PHYSICAL_RADIATION_BRIDGE_v3.md check_physical_bridge_v1.py PHYSICAL_BRIDGE_RESULTS_v1.json BRIDGE_EXECUTION_v1.json BRIDGE_EXECUTION_v1.stderr.txt BRIDGE_EXECUTION_v1.stdout.json BRIDGE_PROTOCOL_v1.json PARENT_ALTERNATIVE_VERIFICATION_v1.json PARENT_PHYSICAL_BRIDGE_VERIFICATION_v1.json PARENT_CANONICAL_VERIFICATION_v1.json'''.split()
files = {a/n for n in names}
for d in [a/'independent_v1',a/'physical_bridge_independent_v1',a/'canonical_correspondence_v1',p/'alternative_packaging']:
 files.update(f for f in d.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix != '.pyc')
rows=[]; payloads={}
for f in sorted(files):
 assert f.is_file() and not f.is_symlink(), f
 rel=f.relative_to(p).as_posix(); path=pathlib.PurePosixPath(rel)
 assert not path.is_absolute() and '..' not in path.parts
 b=f.read_bytes(); payloads[rel]=b
 rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema':'campaign-recovery-manifest-v1','campaign':'revised-scalar-derivation-24h-20261013','milestone':5,'scope':'Alternative limiting radiation state and conditional physical expansion only; excludes finite history, matter, mixture and rolling-response blocks.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload_count':len(rows),'files':rows}
payloads['RECOVERY_MANIFEST_v1.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with out.open('xb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz, tarfile.open(fileobj=gz,mode='w') as tar:
 for name,b in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as tar:
 members=tar.getmembers(); assert len(members)==len(payloads)
 assert len(set(m.name for m in members))==len(members)
 for m in members:
  assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
  assert tar.extractfile(m).read()==payloads[m.name]
record={'created_utc':manifest['created_utc'],'archive':str(out),'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'archive_bytes':out.stat().st_size,'payload_count':len(rows),'member_count':len(payloads),'manifest_sha256':hashlib.sha256(payloads['RECOVERY_MANIFEST_v1.json']).hexdigest(),'safe_relative_regular_members':True,'all_payload_bytes_reverified':True}
(p/'alternative_packaging/ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
