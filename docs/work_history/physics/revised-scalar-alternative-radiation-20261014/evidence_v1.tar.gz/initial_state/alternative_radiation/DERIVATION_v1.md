# Alternative constant-ratio radiation branches: handwritten route

Direct author /root, 2026-10-14. Exploratory derivation frozen before its own
symbolic checker. This is not yet independently checked or a delivered claim.
The failure of generic attraction to the x=0 branch motivates checking other
branches of the same supplied action, without adding a state selector.

Use the large-y full-field metric from transverse_radiation/DERIVATION_v1.md.
Look only for constant u,z,v=x/y with q=ell'=-2 and h=-2, with nonzero
positive radiation density, fixed 0<k<1/3 and finite nu. This is a restricted
scaling ansatz, not a classification of general histories.
Let t=v^2, X=exp(-lambda_x u), Y=exp(-lambda_y u),
G=G_ell_ell=B(3+4t)/[3(1+t)], V=G_vell=4Bv/[3(1+t)].
The lowered ell,u,v equations give

    W/Hbar=G,
    W_u/W=2 B_u/B=-4 alpha sE/(1+sE),
    W_v/W=2(V+partial_v G)/G.

For v nonzero, W=exp(2z)k(t X/2+Y/3) yields

    X/Y=4(3+2t)/[3(3+t)] > 1.

Since lambda_y-lambda_x=2k/alpha>0, this requires u>0.
But the u equation is

    [3t lambda_x X+2lambda_y Y]/[3t X+2Y]
                       =4alpha sE/(1+sE).

Its left side is strictly below lambda_y for t>0, while its right side is
strictly above lambda_y at u>0 (lambda_y=4alpha s/(1+s)). Contradiction.
Thus no mixed finite nonzero v constant-ratio branch exists in this class.
This does not exclude v changing in time, finite-y effects or another chart.

The x-only chart y=0 needs its own limit, since v=infinity was omitted.
Set ell_x=log|x| with x nonzero and large, and y=0. Its kinetic coefficient
is Bx=(1+s)2k/[3(1+k)F]. The u balance gives

    lambda_x=4alpha sE_x/(1+sE_x),
    E_x=(1-3k)/[3(1+k)],
    u_x=log(E_x)/(2alpha)<0,
    C_x=(1-k)/(1+k),
    Bx0=2k(1-k)/[(1+k)(1-3k)].

The radiation constraint and radial equation require

    Hbar_x=2 C_x^2/[3(1-2Bx0)], W_x=Bx0 Hbar_x.

Positive radiation and potential therefore require Bx0<1/2, equivalently
0<k<3-2sqrt(2). At equality no finite positive scaling coefficient exists.
For that range define beta_x^2=2 W_x exp(lambda_x u_x)/k and
z_x=log(|x|/(beta_x y_b)); then the candidate point has z_x=0.
These quantities are consequences of the restricted scaling equations,
not fits or empirical parameters. The background remains a limiting ideal
radiation state and the complete action is still a supplied premise.

For a new transverse ratio w=y/x, its field metric is
Bx/(1+w^2)[dell_x^2+(3/4)(dw+w dell_x)^2]. The same ordinary connection
calculation predicts a normal restoring coefficient

    Omega_normal^2=-2/3+(16/9)exp[-(lambda_y-lambda_x)u_x] >10/9.

Thus w''+w'+Omega_normal^2 w=0 would have negative-real-part roots,
contrary to the x=0 branch's normal instability. This does not yet prove
stability in u,z_x,p,q; the full four-dimensional spectrum must be derived.
No full nonlinear basin, actual thermal history or observed state selection
follows from these candidate branches. The next computation tests these
identities, derives the missing spectrum, and checks every physical domain.
