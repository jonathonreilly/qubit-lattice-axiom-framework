# Alternative constant-ratio radiation branches: handwritten route

Direct author /root, 2026-10-14. Original handwritten branch derivation was frozen before its own symbolic
checker. This v2 adds the personally computed spectrum and an all-k stability
proof. It is not yet independently checked or a delivered claim.
The failure of generic attraction to the x=0 branch motivates checking other
branches of the same supplied action, without adding a state selector.

Use the large-y full-field metric from transverse_radiation/DERIVATION_v1.md.
Look only for constant u,z,v=x/y with q=ell'=-2 and h=-2, with nonzero
positive radiation density, fixed 0<k<1/3 and finite nu. This is a restricted
scaling ansatz, not a classification of general histories.
Let t=v^2, X=exp(-lambda_x u), Y=exp(-lambda_y u),
G=G_ell_ell=B(3+4t)/[3(1+t)], V=G_vell=4Bv/[3(1+t)].
The lowered ell,u,v equations give

    W/Hbar=G,
    W_u/W=2 B_u/B=-4 alpha sE/(1+sE),
    W_v/W=2(V+partial_v G)/G.

For v nonzero, W=exp(2z)k(t X/2+Y/3) yields

    X/Y=4(3+2t)/[3(3+t)] > 1.

Since lambda_y-lambda_x=2k/alpha>0, this requires u>0.
But the u equation is

    [3t lambda_x X+2lambda_y Y]/[3t X+2Y]
                       =4alpha sE/(1+sE).

Its left side is strictly below lambda_y for t>0, while its right side is
strictly above lambda_y at u>0 (lambda_y=4alpha s/(1+s)). Contradiction.
Thus no mixed finite nonzero v constant-ratio branch exists in this class.
This does not exclude v changing in time, finite-y effects or another chart.

The x-only chart y=0 needs its own limit, since v=infinity was omitted.
Set ell_x=log|x| with x nonzero and large, and y=0. Its kinetic coefficient
is Bx=(1+s)2k/[3(1+k)F]. The u balance gives

    lambda_x=4alpha sE_x/(1+sE_x),
    E_x=(1-3k)/[3(1+k)],
    u_x=log(E_x)/(2alpha)<0,
    C_x=(1-k)/(1+k),
    Bx0=2k(1-k)/[(1+k)(1-3k)].

The radiation constraint and radial equation require

    Hbar_x=2 C_x^2/[3(1-2Bx0)], W_x=Bx0 Hbar_x.

Positive radiation and potential therefore require Bx0<1/2, equivalently
0<k<3-2sqrt(2). At equality no finite positive scaling coefficient exists.
For that range define beta_x^2=2 W_x exp(lambda_x u_x)/k and
z_x=log(|x|/(beta_x y_b)); then the candidate point has z_x=0.
These quantities are consequences of the restricted scaling equations,
not fits or empirical parameters. The background remains a limiting ideal
radiation state and the complete action is still a supplied premise.

For a new transverse ratio w=y/x, its field metric is
Bx/(1+w^2)[dell_x^2+(3/4)(dw+w dell_x)^2]. The same ordinary connection
calculation predicts a normal restoring coefficient

    Omega_normal^2=-2/3+(16/9)exp[-(lambda_y-lambda_x)u_x] >10/9.

Thus w''+w'+Omega_normal^2 w=0 would have negative-real-part roots,
contrary to the x=0 branch's normal instability. The remaining four-dimensional spectrum is derived below.
No full nonlinear basin, actual thermal history or observed state selection
follows from these candidate branches. The next computation tests these
identities, derives the missing spectrum, and checks every physical domain.

## Exact within-plane spectrum and local attraction of the alternative

Use theta=2alpha(u-u_x) and let p=theta', q=(log|x|)'. Then

    E=E_x exp(theta), A_theta=J/(4a F^2),
    B=Bx(u), C=(1+s)E/F,
    W=W_x exp[2z_x-2theta/(1+3k)],
    T=A_theta p^2+B q^2,
    Hbar=2(C^2+W)/(3-T), h=-4C^2/(3Hbar)-T,
    theta'=p, z_x'=q+2+p/F,
    p'=-(3+h)p-(A_theta,theta/2A_theta)p^2
       +(B_theta/2A_theta)q^2+[2/(1+3k)]W/(A_theta Hbar),
    q'=-(3+h)q-(B_theta/B)pq-2W/(B Hbar).

The exact fixed point is (theta,z_x,p,q)=(0,0,0,-2). The full constrained
Jacobian has characteristic polynomial

    (lambda^2+lambda)^2+S_x(lambda^2+lambda)+P_x,
    n_x=5-7k-21k^2+7k^3,
    S_x=4n_x/[(1+k)(1-3k)(1+3k)],
    P_x=64k(1-k)^2(1-6k+k^2)
          /[(1+k)^2(1-3k)^2(1+3k)].

The primary computation uses a single full-flow constructor, first on the
exact coefficients and then on symbolic coefficient jets for the Jacobian.
It retains precisely the needed derivatives: A through first order, B through
second order, and C,W through first order. Their values and derivatives are
taken from the supplied coefficients, not fitted. The first unnormalized CAS
Jacobian run timed out after120seconds; a25second diagnostic reached that same
step. Both remain preserved. The separate jet-ordered version completed with
18/18 exact conditions and seven60-digit matrix spectra. The finite samples
are implementation checks, not the all-k proof below.

Let k_c=3-2sqrt(2). For 0<k<k_c<1/5, n_x>5-7/5-21/25=69/25.
The positive denominator of S_x is less than1+k<6/5, so S_x>46/5.
Also Delta=1-6k+k^2 obeys 0<Delta<1-3k and
(1-k)^2/(1+k)<1. Consequently

    0<P_x/S_x
      =16k(1-k)^2 Delta/[(1+k)(1-3k)n_x] <80/69.

Thus S_x^2-4P_x=S_x(S_x-4P_x/S_x)>0, since46/5>320/69.
Both roots r_1,r_2 of r^2-S_x r+P_x=0 are positive. Each factor
lambda^2+lambda+r_i has strictly negative real-part roots. Together with the
normal w roots above, all six eigenvalues of this alternative limiting
radiation point have negative real parts. Smoothness on the positive chart
and the same Lyapunov integral argument give local asymptotic stability for
each fixed k in this smaller interval. No common basin or full-action tracking
result follows. The sign-related x-positive and x-negative charts both occur;
no measure or selection of their signs is supplied.

At k->0 the four-dimensional polynomial tends to
lambda(lambda+1)(lambda^2+lambda+20). Its simple zero root obeys
lambda_slow=-(16/5)k+O(k^2), since P_x=64k+O(k^2) and S_x=20+O(k).
The weak-coupling relaxation time therefore still diverges like5/(16k).
This does not establish a finite duration of an actual radiation era, initial
amplitude erasure to a measured tolerance, nonlinear basin capture or a local
coupling constraint. It is a genuine alternative state of the supplied limiting
equations, conditional on the action and radiation approximation. The x=0
saddle theorem remains true and separate.

Independent checks requested next: full-action derivation of both branch
balances and the mixed-branch contradiction; exact Jacobian through an
independent calculation; all-k inequalities including the physical domain;
normal restoring term; finite-y/off-branch correspondence; meaningful damage
controls. Alternative histories, observations and a real matter transition
remain open, not silently supplied.
