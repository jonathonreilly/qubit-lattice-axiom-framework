# Physical radiation expansion on the alternative branch

Direct author /root. New hand derivation frozen before its own exact checker.
This extends the conditional branch in DERIVATION_v2.md. It is not empirical
validation, a derived observed environment, or a new selection premise.

The physical radiation density is rho_J, y_b^2=rho_J/(2 Q Hv^2), Q=Q0(1+k).
On the constant-u x-only ideal radiation branch,

    C_x=(1-k)/(1+k), Bx=2k(1-k)/[(1+k)(1-3k)],
    Hbar_x=2 C_x^2/[3(1-2Bx)], Delta=1-6k+k^2>0.

The physical proper time is dt_J=sqrt(C_x)dt_E and the physical scale
factor is a_J=sqrt(C_x)a_E. Since C_x is constant on this branch,

    H_J^2=H_E^2/C_x=Hbar_x rho_J/(2Q C_x).

For the stipulated constant vacuum, an unsuppressed weak local readout has
G_vac=1/(8pi Q0). This calibration is CONDITIONAL; actual measured gravity
and actual present cosmology are not shown to equal that vacuum. Comparing
the branch with H_GR^2=(8pi G_vac/3)rho_J=rho_J/(3Q0) gives

    R_H(k)=H_J^2/H_GR^2
          =(1-k)(1-3k)/[(1+k)(1-6k+k^2)].

The candidate scale Hv and absolute normalization Q0 cancel from this
conditional ratio. This removes their need for this one diagnostic, not for
the theory or every observation. On0<k<k_c=3-2sqrt(2),

    R_H-1=k(1+8k-k^2)/[(1+k)Delta]>0,
    R_H'= [1+16k-38k^2+8k^3-3k^4]/[(1+k)^2 Delta^2]>0.

For the derivative, k<1/5 gives k(16-38k)>0,
1-3k^4>1-3/625>0 and8k^3>0. Thus R_H increases strictly from1 to infinity
on the allowed branch. An applicable ideal-radiation measurement of this
specific expansion/density/calibrated-gravity ratio would identify a unique
k if R_H>1; a value<=1 would not fit its positive-k exact central prediction.
Statistical uncertainty, model error and actual transition physics must be
included before any observational exclusion or interval is claimed.

The small-k expansion is R_H=1+k+13k^2+O(k^3). The Einstein-frame scalar
energy fraction is2Bx=4k(1-k)/[(1+k)(1-3k)], not R_H-1. The conformal clock
and vacuum gravity calibration matter. Omitting C_x in H_J would give a
wrong physical inference. The older y-only point instead has C=1 and
Hbar=2(1+k)/3, so this same calibrated ratio is exactly1 despite nonzero
scalar energy fraction. This contrast follows within the two supplied limits;
it is not a statement that either is our actual primordial history.

The gradient norm of the conformal coupling on the alternative branch is
|grad log sqrt(C)|_K^2=3k(1-k)/(1+3k). It is not automatically a measured
PPN/fifth-force coupling of a rolling radiation environment: mode mixing,
source response, finite range and time dependence still require a forward
model. This diagnostic therefore retains the real gravity/environment gap.

No new data have been accessed. The proposed fit/test separation is to infer
k only from a controlled expansion-density ratio after establishing its
calibration and regime, then test additional observables with that value
frozen. Nucleosynthesis, radiation composition and other likelihood inputs
are not silently supplied or fitted here.
