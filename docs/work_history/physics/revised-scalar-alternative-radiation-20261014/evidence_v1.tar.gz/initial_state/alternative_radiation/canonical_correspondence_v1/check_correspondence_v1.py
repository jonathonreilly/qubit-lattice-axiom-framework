#!/usr/bin/env python3
"""Read-only identity/output correspondence; never import a science runner."""
import ast
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys
import sympy as s
import traceback

ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
HERE=Path(__file__).resolve().parent
ALT=HERE.parent
checks=[]
records={}

def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(Path(path).read_text())
def ck(name,ok,category='integrity',**extra):
    checks.append(dict(name=name,passed=bool(ok),category=category,**extra))
def counted(data):
    return dict(passed=sum(r['passed'] for r in data['checks']),failed=sum(not r['passed'] for r in data['checks']))
def fingerprint(rel,body):
    d=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
    name=rel.encode()
    for chunk in [len(name).to_bytes(8,'big'),name,len(body).to_bytes(8,'big'),body]: d.update(chunk)
    return d.hexdigest()
def parse_cache(path):
    text=path.read_text()
    head,remaining=text.split('----- stdout -----\n',1)
    stdout,stderr=remaining.split('----- stderr -----\n',1)
    header=dict(line.split(': ',1) for line in head.splitlines() if ': ' in line)
    return header,stdout,stderr,json.loads(stdout)

def main():
    # Verify the complete sealed prior inventories, not just receipt summaries.
    for folder,expected,exclusions,sourcekey in [
        ('independent_v1',29,{'MANIFEST_v1.json'},'source_files'),
        ('physical_bridge_independent_v1',35,{'MANIFEST_v1.json','RECEIPT_v1.json'},'source_bindings')]:
        base=ALT/folder
        manifest=load(base/'MANIFEST_v1.json')
        rows=manifest['artifacts']
        ck(folder+'.manifest_count',manifest['artifact_count']==expected==len(rows))
        listed={r['path'] for r in rows}
        actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}-exclusions
        ck(folder+'.inventory',listed==actual)
        for row in rows:
            data=(base/row['path']).read_bytes()
            ck(folder+'.artifact.'+row['path'],len(data)==row['bytes'] and sha(data)==row['sha256'])
        receipt=load(base/'RECEIPT_v1.json')
        for i,row in enumerate(receipt[sourcekey]):
            original=Path(row.get('source_path',row.get('original_path')))
            if not original.is_absolute():original=ROOT/original
            live,snapshot=original.read_bytes(),(base/row['snapshot_path']).read_bytes()
            ck(folder+'.source_pair.'+str(i),live==snapshot and sha(live)==row['sha256'])
        records[folder]=dict(manifest_sha256=sha((base/'MANIFEST_v1.json').read_bytes()),
            receipt_sha256=sha((base/'RECEIPT_v1.json').read_bytes()),verified_artifacts=expected,
            verified_source_pairs=len(receipt[sourcekey]))

    # Freeze provenance has no dependency on current parent status declarations.
    for manifest,key,live in [('SOURCE_MANIFEST_initial.json','sources',False),
                              ('PARENT_INITIAL_SNAPSHOTS_v1.json','snapshots',False),
                              ('FINAL_SOURCE_SNAPSHOTS_v1.json','sources',True)]:
        for i,row in enumerate(load(HERE/manifest)[key]):
            data=(HERE/row['snapshot_path']).read_bytes()
            ck(manifest+'.snapshot.'+str(i),sha(data)==row['sha256'] and len(data)==row['bytes'])
            if live:
                ck(manifest+'.live.'+str(i),(ROOT/row['original_path']).read_bytes()==data)

    initial=(HERE/'sources/CANONICAL_RUNNER_initial.py').read_text()
    final=(HERE/'parent_final/CANONICAL_RUNNER_final.py').read_text()
    note_rel='docs/EXPONENTIAL_SCALAR_ALTERNATIVE_RADIATION_BOUNDED_THEOREM_NOTE_2026-10-14.md'
    payloads={}
    for version,cache,note,runner,build,expected in [
       (1,'parent_initial/CACHE_v1.txt','sources/CANONICAL_NOTE_initial.md',initial,'parent_initial/CACHE_BUILD_v1.json',83),
       (2,'parent_final/CACHE_final.txt','parent_final/CANONICAL_NOTE_final.md',final,'parent_final/CACHE_BUILD_v2.json',88)]:
        header,stdout,stderr,data=parse_cache(HERE/cache)
        record=load(HERE/build)['result']
        ck(f'cache{version}.runner_identity',header['runner_sha256']==sha(runner.encode()))
        ck(f'cache{version}.declared_input_fingerprint',header['input_fingerprint_sha256']==fingerprint(note_rel,(HERE/note).read_bytes()))
        ck(f'cache{version}.run_status',header['exit_code']=='0' and header['status']=='ok' and header['timeout_sec']=='120' and record['exit_code']==0 and record['status']=='ok')
        ck(f'cache{version}.actual_stdout',stdout.strip()==record['stdout'].strip())
        ck(f'cache{version}.actual_stderr',stderr.strip()==record['stderr'].strip()=='')
        ck(f'cache{version}.counts',counted(data)==data['counts']==dict(passed=expected,failed=0))
        ck(f'cache{version}.unique_criteria',len({r['name'] for r in data['checks']})==expected)
        ck(f'cache{version}.declared_execution_time',float(header['elapsed_sec'])==round(record['elapsed_sec'],2) and record['elapsed_sec']<record['timeout_sec']==120)
        payloads[version]=data
    oldnames={r['name'] for r in payloads[1]['checks']}
    newnames={r['name'] for r in payloads[2]['checks']}
    additions={'action.implemented_B_binding','action.implemented_C_binding','action.implemented_W_binding','action.implemented_W_radial_gradient','action.implemented_W_theta_gradient'}
    ck('repair.retains_all_83_and_adds_five',oldnames<newnames and newnames-oldnames==additions,'binding')
    for token in ['W0:W.subs(at_origin)','W1:s.diff(W,theta).subs(at_origin)','W2:s.diff(W,z).subs(at_origin)']:
        ck('repair.actual_W_jet.'+token,token in final,'binding')
    ck('repair.targeted_snapshot_is_final',(HERE/'sources/CANONICAL_RUNNER_repaired.py').read_text()==final,'binding')
    ck('repair.note_snapshot_is_final',(HERE/'sources/CANONICAL_NOTE_repaired.md').read_bytes()==(HERE/'parent_final/CANONICAL_NOTE_final.md').read_bytes(),'binding')
    tree=ast.parse(final)
    declared={t.id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name) and t.id in ['AUDIT_TIMEOUT_SEC','AUDIT_INPUT_PATHS']}
    ck('runner.declared_scope',declared=={'AUDIT_TIMEOUT_SEC':120,'AUDIT_INPUT_PATHS':(note_rel,)},'binding')

    # Exact comparison with already completed independent mathematics, not a new derivation.
    independent=load(HERE/'reused_science/alternative/RUN_03_CHAINRULE.stdout.json')
    k=s.Symbol('k',positive=True)
    canonical=s.sympify(payloads[2]['matrix'],locals={'k':k,'Matrix':s.Matrix})
    hand=s.Matrix([[s.sympify(v,locals={'k':k}) for v in row] for row in independent['hand_matrix']])
    for i in range(4):
        for j in range(4):
            residual=s.factor(canonical[i,j]-hand[i,j])
            ck(f'correspondence.matrix.{i}{j}',residual==0,'exact_correspondence',residual=str(residual))
    R=s.Symbol('R',real=True)
    normal=s.sympify(payloads[2]['normal_matrix'],locals={'R':R,'Matrix':s.Matrix})
    ck('correspondence.normal_matrix',normal==s.Matrix([[0,1],[s.Rational(2,3)-16*R/9,-1]]),'exact_correspondence')
    records['cached_matrix_equals_sealed_independent_hand_matrix']=True

    # Check the old nine and final eleven genuine mutation executions.
    for version,folder,baseline,total in [(1,'parent_initial',initial,9),(2,'parent_final',final,11)]:
        base=HERE/folder/f'mutations_v{version}'
        protocol=load(base/f'PROTOCOL_v{version}.json')
        result=load(base/f'RESULTS_v{version}.json')
        ck(f'mutations{version}.baseline',protocol['source_sha256']==result['source_sha256']==sha(baseline.encode()),'damage_provenance')
        ck(f'mutations{version}.count',len(protocol['damages'])==len(result['results'])==total,'damage_provenance')
        summaries={r['name']:r for r in result['results']}
        for damage in protocol['damages']:
            name=damage['name']; source=(base/(name+'.py')).read_bytes()
            stdout=(base/(name+'.stdout.json')).read_bytes();stderr=(base/(name+'.stderr.txt')).read_bytes()
            run=load(base/(name+'.execution.json'));data=json.loads(stdout)
            failed=[r['name'] for r in data['checks'] if not r['passed']]
            ck(f'mutations{version}.{name}.exact_damage',baseline.count(damage['old'])==1 and source==baseline.replace(damage['old'],damage['new']).encode(),'damage_provenance')
            ck(f'mutations{version}.{name}.byte_bindings',sha(source)==run['script_sha256'] and sha(stdout)==run['stdout_sha256'] and sha(stderr)==run['stderr_sha256'],'damage_provenance')
            ck(f'mutations{version}.{name}.actual_failed_witness',run['exit_code']==1 and not run['timed_out'] and failed==run['failed_checks'] and damage['witness'] in failed and counted(data)==data['counts'],'damage_provenance')
            ck(f'mutations{version}.{name}.summary',all(summaries[name].get(key)==value for key,value in run.items()),'damage_provenance')
        ck(f'mutations{version}.aggregate',result['all_intended_rejected'] is True,'damage_provenance')

    for version,baseline,expected_detection in [(1,initial,False),(2,final,True)]:
        base=HERE/f'targeted_damages_v{version}'
        protocol=load(base/f'PROTOCOL_v{version}.json')
        result=load(base/f'RESULTS_v{version}.json')
        for damage,run in zip(protocol['controls'],result['controls'],strict=True):
            name=damage['label'];source=(base/(name+'.py')).read_bytes()
            stdout=(base/(name+'.stdout.json')).read_bytes();stderr=(base/(name+'.stderr.txt')).read_bytes()
            data=json.loads(stdout)
            ck(f'own_damage{version}.{name}.exact_bytes',source==baseline.replace(damage['replacement_old'],damage['replacement_new']).encode() and sha(source)==run['source_sha256'] and sha(stdout)==run['stdout_sha256'] and sha(stderr)==run['stderr_sha256'],'damage_provenance')
            ck(f'own_damage{version}.{name}.honest_outcome',run['damage_detected'] is expected_detection and run['exit_code']==int(expected_detection) and data['counts']==run['counts'] and counted(data)==data['counts'],'damage_provenance')
    ck('missed_controls.original_same_stdout',all(r['stdout_sha256']==sha((HERE/'parent_initial/PRIMARY_v1.stdout.json').read_bytes()) for r in load(HERE/'targeted_damages_v1/RESULTS_v1.json')['controls']),'damage_provenance')

    alt_receipt=load(HERE/'sources/REUSED_ALTERNATIVE_RECEIPT_v1.json')
    ck('history.alternative_three_timeouts',[r['actual_exit_code'] for r in alt_receipt['actual_runs']]==[124,124,0,124,0],'history')
    ck('history.alternative_71_and_107',[r['completed_counts'] for r in alt_receipt['actual_runs']]==[None,None,dict(passed=71,failed=0),None,dict(passed=107,failed=0)],'history')
    for filename,expect in [('RESULTS_v1.json',(124,1)),('REPAIR_RESULTS_v1.json',(8,0)),('SOURCE_CORRESPONDENCE_RESULTS_v1.json',(9,0)),('SOURCE_V3_CORRESPONDENCE_RESULTS_v1.json',(8,0))]:
        data=load(HERE/'reused_science/bridge'/filename)
        ck('history.bridge.'+filename,(data['passed'],data['failed'])==expect,'history')
    note=(HERE/'parent_final/CANONICAL_NOTE_final.md').read_text()
    readme=(HERE/'parent_final/README_final.txt').read_text()
    ck('scope.note_pointwise_nu_one','normal-ratio acceleration differences for nu=1 pointwise at six couplings' in note and 'two fixed normal states' in note,'scope_wording')
    ck('scope.note_reused_failures','original 83/0 output and missed controls are retained' in note,'scope_wording')
    ck('scope.readme_reused_failures','incorrectly passed83/0' in readme and 'primary and cache passed88/0' in readme and 'All eleven' in readme,'scope_wording')
    ck('scope.readme_honest_bridge','original124/1' in readme and 'full125/0 rerun' in readme and 'Later9/0 and8/0' in readme,'scope_wording')
    ck('scope.readme_exclusions','separate subsequent blocks and are deliberately outside this milestone' in readme,'scope_wording')

started=dt.datetime.now(dt.timezone.utc).isoformat()
exception=None
try:main()
except Exception:
    exception=traceback.format_exc()
    traceback.print_exc()
groups={}
for row in checks:
    g=groups.setdefault(row['category'],dict(passed=0,failed=0))
    g['passed' if row['passed'] else 'failed']+=1
result=dict(scope='Packaging provenance and exact correspondence to prior sealed results; no science rerun.',
    started_utc=started,finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    checker_sha256=sha(Path(__file__).read_bytes()),checks=checks,
    counts=dict(passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks)),
    counts_by_category=groups,records=records,exception=exception)
print(json.dumps(result,indent=2))
sys.exit(bool(exception or result['counts']['failed']))
