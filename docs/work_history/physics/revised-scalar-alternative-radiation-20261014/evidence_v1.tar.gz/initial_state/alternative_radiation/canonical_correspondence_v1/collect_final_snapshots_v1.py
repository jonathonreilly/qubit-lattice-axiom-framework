#!/usr/bin/env python3
"""Freeze delivery correspondence evidence without touching author files."""
from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json

ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
HERE=Path(__file__).resolve().parent
PK=ROOT/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013'
ALT=PK/'initial_state/alternative_radiation'
out=HERE/'parent_final'
out.mkdir(exist_ok=False)
items=[]

def freeze(source, destination):
    data=source.read_bytes()
    destination.parent.mkdir(parents=True,exist_ok=True)
    assert not destination.exists()
    destination.write_bytes(data)
    items.append(dict(original_path=str(source.relative_to(ROOT)),
        snapshot_path=str(destination.relative_to(HERE)), bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest()))

for name,rel in [
 ('CANONICAL_NOTE_final.md','docs/EXPONENTIAL_SCALAR_ALTERNATIVE_RADIATION_BOUNDED_THEOREM_NOTE_2026-10-14.md'),
 ('CANONICAL_RUNNER_final.py','scripts/exponential_scalar_alternative_radiation_check.py'),
 ('CACHE_final.txt','logs/runner-cache/exponential_scalar_alternative_radiation_check.txt'),
 ('README_final.txt','docs/work_history/physics/revised-scalar-alternative-radiation-20261014/README.txt'),
 ('RUNNER_CACHE_FORMAT.py','scripts/runner_cache.py')]:
    freeze(ROOT/rel,out/name)
for name in ['CACHE_BUILD_v2.json','PRIMARY_SOURCE_v1.py','PRIMARY_SOURCE_v2.py','CANONICAL_NOTE_v3.md','REVIEW_GAP_v1.json','PATCH_TOOL_FAILURES_v1.json']:
    freeze(PK/'alternative_packaging'/name,out/name)
for source in sorted((PK/'alternative_packaging/mutations_v2').iterdir()):
    assert source.is_file() and not source.is_symlink()
    freeze(source,out/'mutations_v2'/source.name)

reuse=HERE/'reused_science'
for name in ['HAND_DERIVATION_v1.txt','RUN_03_CHAINRULE.json','RUN_03_CHAINRULE.stdout.json','RUN_05_FINITE_COMPACT.json','RUN_05_FINITE_COMPACT.stdout.json','FINITE_FIELD_CERTIFICATES_v2.json']:
    freeze(ALT/'independent_v1'/name,reuse/'alternative'/name)
for name in ['REPORT_v1.md','REPORT_SOURCE_V3_ADDENDUM_v1.md','FAILURES_v1.json','RUN_v1.json','RESULTS_v1.json','REPAIR_RUN_v1.json','REPAIR_RESULTS_v1.json','SOURCE_CORRESPONDENCE_RUN_v1.json','SOURCE_CORRESPONDENCE_RESULTS_v1.json','SOURCE_V3_CORRESPONDENCE_RUN_v1.json','SOURCE_V3_CORRESPONDENCE_RESULTS_v1.json']:
    freeze(ALT/'physical_bridge_independent_v1'/name,reuse/'bridge'/name)
for tag,left,right in [
 ('RUNNER_REPAIR','sources/CANONICAL_RUNNER_initial.py','parent_final/CANONICAL_RUNNER_final.py'),
 ('NOTE_REPAIR','sources/CANONICAL_NOTE_initial.md','parent_final/CANONICAL_NOTE_final.md'),
 ('README_REPAIR','parent_initial/README_initial.txt','parent_final/README_final.txt')]:
    diff=''.join(difflib.unified_diff((HERE/left).read_text().splitlines(True),(HERE/right).read_text().splitlines(True),fromfile=left,tofile=right))
    (HERE/(tag+'_v1.diff')).write_text(diff)
manifest=dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),sources=items)
(HERE/'FINAL_SOURCE_SNAPSHOTS_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(snapshot_count=len(items),final_delivery_files=items[:4]),indent=2))
