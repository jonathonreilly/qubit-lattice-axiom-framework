# Narrow source-v3 density correspondence

This addendum supplements the preserved `REPORT_v1.md`; it does not replace
its original v1/v2 source history or rerun the independent mathematics.
The author supplied `PHYSICAL_RADIATION_BRIDGE_v3.md` before this check's
final seal, SHA-256
`900c7ec78bdddc32bfce04a67629c0b3f87cb3418d4a67242b66abe3eb272c83`.
Its full text was read and frozen in `sources/04_PHYSICAL_RADIATION_BRIDGE_v3.md`.

The canonical complete-action note defines rho_J and P_J as physical
densities divided by a fixed positive rho_unit. Bridge v1/v2 and this
check's original derivation explicitly used rho_J for the dimensionful
physical density. V3 eliminates this cross-note symbol collision by writing

    rho_phys = rho_unit rho_J(canonical),
    Rstar = rho_unit/(2Q Hv^2),
    y_b^2 = rho_phys/(2Q Hv^2) = Rstar rho_J(canonical).

This is consistent with the supplied complete action and with the physical
density used in the independent derivation. The matter/clock comparison
now reads `H_J^2=Hbar rho_phys/(2Q C_x)` and
`H_GR^2=rho_phys/(3Q0)`. Their ratio and every previously checked k-dependent
formula are unchanged. No density-unit calibration is inferred from data.

`SOURCE_V2_V3.diff` preserves the exact difference. Removing only the new
density-convention preface and the version/reuse suffix, then replacing
rho_phys by the earlier rho_J symbol, reconstructs v2 byte-for-byte. All
displayed equations likewise match after that explicit symbol translation.
The v2 dynamical-force/lensing qualification is unchanged.

The narrow correspondence execution at 2026-10-14 05:00:08 UTC returned
exit code zero, **8/0**, in 0.262 seconds. It checks the source/live hash,
exact affected text spans, translated displayed equations, the canonical
density-unit premise, and two exact unit-cancellation identities. It is
not a rerun of the main physical-bridge calculations or any producer code.
No additional execution failure occurred. The original **124/1** main run,
separate **8/0** domain repair and **9/0** v2 correspondence remain recorded
as distinct executions. Five source/live pairs are now bound by the final
receipt, including all three bridge versions.

V3 is the final checked source for this focused bridge task. The result and
all limitations in `REPORT_v1.md` carry over under the explicit density
translation. No new science correction is requested; the unsupplied
observational calibration, finite-history and selection assumptions remain
unsupplied. The subsequently requested matter-continuation check is a
separate task and is not part of this receipt.
