# Independent check of the conditional physical radiation bridge

The physical-clock conversion, expansion ratio, monotonic inverse, weak-k
series, Einstein scalar energy fraction and coupling-gradient norm agree with
the action within the supplied ideal x-only radiation background. One narrow
wording issue in bridge v1 concerned the type of gravity calibration. Bridge
v2 resolves it by specifying the unsuppressed nonrelativistic dynamical-force
readout and distinguishing ideal lensing. No further algebraic correction is
identified in this checked scope.

This is a focused independent check by `/root/scalar_energy_check`; `/root`
remains the scientific author. It is not a formal audit, a proof of the entire
alternative background, an empirical validation or an initial-state selection
result. The separate alternative-branch existence/stability review is not
duplicated or represented as completed by this report. No producer checker,
producer functions or producer results files were read, imported or run.
Execution-history statements present in the supplied prose were not used as
independent evidence. No new empirical data, inherited cosmology, repository
state, parent source, git, PR, runtime, lock or audit state was accessed or
changed for this check beyond the scoped source reads and evidence writes.

The four immutable source snapshots are bound to these SHA-256 hashes:

| Source | SHA-256 |
| --- | --- |
| Physical bridge v1 | `bea1eabb88c5d78e4c73c75d798204ef0df42df5a5ed2a9b9c68a94ca84d1f23` |
| Alternative background v2 | `90c30ab24d4dc00106c36144692b5a79e7a6354a5d8db1b0413d886fde9339d3` |
| Complete canonical action note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Physical bridge v2 | `2b73fc7a9d6dbb2f555df7fee689eb376fb1930cf8eac39465df00857e892349` |

`SOURCE_MANIFEST_v1.json` and the separate `SOURCE_V2_BINDING_v1.json` give
the original paths, snapshot paths and byte counts. Full source/live byte
correspondence was verified for all four. `HAND_DERIVATION_v1.md` and
`PROTOCOL_v1.json` were written before the independent checker code and its
first execution. The v2 qualification was checked separately after constructing
the independent mathematics, without replacing the original v1 snapshot.

The action and frame normalization are essential. With

    S = Q int sqrt(-g_E)[R_E/2 - K_AB dphi^A dphi^B - 2 Hv^2 U]
        + S_m[C g_E, psi],       Q=Q0(1+k),

the homogeneous scalar stress is

    rho_phi,E = Q K_AB dot(phi)^A dot(phi)^B + 2Q Hv^2 U,
    p_phi,E   = Q K_AB dot(phi)^A dot(phi)^B - 2Q Hv^2 U.

There is no additional one-half multiplying K in this action. Matter-frame
radiation density transforms as `rho_E=C^2 rho_J`. Using physical unscaled
`rho_J`, `y_b^2=rho_J/(2Q Hv^2)`, `Hbar=H_E^2/(Hv^2 y_b^2)`,
`T=K_AB phi'^A phi'^B` and `W=U_rad/y_b^2`, the constraint is
`(3-T)Hbar=2(C^2+W)`. The fixed density-unit convention in the canonical
action note gives this same normalization upon restoring that unit.

The supplied background holds `u=u_x`, `y=0`, `E_x=(1-3k)/[3(1+k)]`
and `(log|x|)'=-2` in the large-|x| limit, for
`0<k<k_c=3-2sqrt(2)`. Direct evaluation of the original field metric gives

    lim K_xx x^2 = (1+s)2k/[3(1+k)F],
    C_x=(1-k)/(1+k),
    Bx=2k(1-k)/[(1+k)(1-3k)],
    1-2Bx=(1-6k+k^2)/[(1+k)(1-3k)].

The radial potential derivative is `x dU_rad/dx=2U_rad`. The action's
lowered radial equation with `h=H_E'/H_E=-2` gives `W/Hbar=Bx`.
Consequently `T=4Bx` and the constraint gives
`Hbar=2C_x^2/[3(1-2Bx)]`. This checks the normalization needed by the
bridge on the supplied branch; it does not independently establish its
u-balance, full local spectrum or global attraction. The constant and nu
pieces of the full potential are omitted only in this stated limiting
regime. The result is not an exact finite-field cosmological history.

Differentiating both `a_J=sqrt(C)a_E` and `dt_J=sqrt(C)dt_E` first gives
the general clock relation

    H_J=[H_E+(1/2)d(log C)/dt_E]/sqrt(C).

Here C depends only on u, which is constant even though x rolls. Therefore
`H_J^2=H_E^2/C_x=Hbar rho_J/(2Q C_x)`. Omitting this conformal clock
factor changes the ratio to `C_x R_H`; its weak-k linear coefficient is
minus one instead of plus one. At the independent rational point `k=1/97`
it even places the damaged ratio below one while the correct ratio is above
one. A constant conformal transformation of the curvature action to the
coefficient `Q/(2C_x)` supplies a second background consistency check; it
does not license dropping conformal derivatives away from constant u.

The gravity calibration is conditional and readout-specific. At the
stipulated vacuum `u=x=y=0`, C=1. Define
`alpha_B=d_u log sqrt(C)` and `K0=K_uu`. The original action gives
`alpha_B^2/K0=k` and `G_tensor=1/(8pi Q)`. In the weak, locally flat,
static nonrelativistic source approximation,

    (laplacian-mu^2) delta u = alpha_B rho/(2Q K0),
    delta u = -alpha_B M exp(-mu r)/(8pi Q K0 r).

The exterior equation and source flux are independently checked. The
physical dynamical potential is `Phi_J=Phi_E+alpha_B delta u`. Its force
contains the factor `1+k(1+mu r)exp(-mu r)`; negligible range suppression
therefore gives

    G_vac,dynamical=G_tensor(1+k)=1/(8pi Q0).

The other weak metric potential has the opposite conformal perturbation,
so their sum retains the tensor coefficient for ideal lensing with known
mass. Thus the original v1 phrase "unsuppressed weak local readout" was
insufficiently specific. V2 now states the nonrelativistic dynamical readout,
weak potentials, negligible vacuum curvature and range suppression, and a
known point-source mass or justified body charge. For a finite body, a reliable
charge relative to its inertial mass remains part of that premise; it is not
established for an arbitrary object here. Trace-free or relativistic sources,
screening, unknown masses and a rolling cosmological environment are not
interchangeable with this vacuum calibration.

For precisely that stipulated G_vac and the same physical radiation density,

    H_GR^2=rho_J/(3Q0),
    R_H=H_J^2/H_GR^2
       =(1-k)(1-3k)/[(1+k)(1-6k+k^2)].

The cancellations of Hv and Q0 in this diagnostic follow; they neither select
those scales nor remove their role elsewhere. A tensor/lensing calibration
would instead yield `(1+k)R_H`. If the calibration is an unknown positive
`gamma=8pi Q0 G_cal`, the ratio is `R_H/gamma`, and this single diagnostic
cannot identify k. An exact counterexample uses `k=1/97` with
`gamma=72944/108143` and `k=2/37` with `gamma=80290/108693`: both give
the same synthetic calibrated ratio 3/2. No real calibration is supplied.

For `Delta=1-6k+k^2`, direct differentiation gives

    R_H-1=k(1+8k-k^2)/[(1+k)Delta],
    R_H'=(1+16k-38k^2+8k^3-3k^4)/[(1+k)^2 Delta^2].

An independent positivity certificate expands the derivative numerator in
the degree-four Bernstein basis on `t=5k` in `[0,1]`. Its coefficients are
`1, 9/5, 176/75, 332/125, 1712/625`, all at least one. As `k_c<1/5`,
this proves strict positivity throughout the physical interval. The lower
limit of R_H is one and its upper limit is positive infinity; hence the ideal
map is a bijection `(0,k_c) -> (1,infinity)`.

For a specified exact r>1 the inverse polynomial is

    r k^3-(5r+3)k^2+(4-5r)k+(r-1)=0.

It has one negative root, one root in the physical interval, and one further
positive root beyond k_c. Signs at negative infinity, zero, k_c and positive
infinity prove existence in each of these three disjoint intervals; degree
three proves uniqueness in each. The cubic as an unrestricted equation does
not have a unique real solution. Independent exact Sturm counts confirm
the three domains for five synthetic r values. One hundred exact rational
bisections on `(0,171/1000)` give the following physical roots; decimals
are only displays of the exact brackets retained in `RESULTS_v1.json`.

| Synthetic r | Physical k, approximate |
| --- | --- |
| 7/6 | 0.0685033411382720478754185149215 |
| 9/4 | 0.136553368765048617862119933776 |
| 5 | 0.158092603067643396686674677953 |
| 17 | 0.167898238582651900341653134928 |
| 101 | 0.170969352975363399425462628478 |

The small-k expansion is `R_H=1+k+13k^2+O(k^3)`, with the exact remainder

    R_H-(1+k+13k^2)
        =k^3(69+64k-13k^2)/[(1+k)Delta].

On `0<k<=1/100`, positive Bernstein certificates bound the coefficient
numerator below 70 and the denominator above 47/50. The remainder is
therefore strictly between zero and `(3500/47)k^3`. Exact points
`1/10000, 1/1000, 1/250, 1/100` confirm the interval bound. This controlled
weak-k expansion is not uniform near the critical pole.

The action stress gives

    Omega_phi,E=(T+2W/Hbar)/3=2Bx,
    Omega_rad,E=1-2Bx,
    p_phi,E/rho_phi,E=1/3.

Omega_phi,E is not the function R_H-1. The two can only be compared after
accounting for the conformal clock and stipulated vacuum gravity calibration.
The supplied older y-only limit has C=1 and `By=k/[2(1+k)]`, yielding
R_H=1 but scalar fraction `k/(1+k)>0`. These are statements about ideal
limits, not about which background our universe occupies.

Exact independent points probe both weak coupling and proximity to the
critical boundary:

| k | R_H | Omega_phi,E |
| --- | --- | --- |
| 1/97 | 109416/108143 | 96/2303 |
| 2/37 | 40145/36231 | 280/1209 |
| 3/29 | 1885/1312 | 39/80 |
| 1/6 | 90/7 | 20/21 |
| 37/216 | 4059720/18469 | 26492/26565 |

The synthetic unit choices are `Q0=7/3`, `Hv^2=5/11`, `rho_J=13/7`.
Recomputing the physical normalization and coherently rescaling them by
`11/5`, `3/2` and `9/7`, respectively, leaves this calibrated ratio exactly
unchanged. These are rational normalization controls, not fitted inputs.

Finally C depends only on u and K is diagonal. Consequently
`|grad log sqrt(C)|_K^2=a/J`. Evaluation at E_x gives
`J_x=(1+3k)^2/(12k)` and the claimed norm
`3k(1-k)/(1+3k)`. This dimensionless K-norm is nonzero despite zero
directional derivative of C on the branch. A canonical dimensionful field
normalization includes an additional factor `1/(2Q)`. Neither norm is
automatically a measured PPN/fifth-force coupling in the rolling radiation
environment: mass matrices, mixing, source trace/charge, range and time
dependence still require a response calculation.

All actual execution history is retained. The first mathematical checker
ran at 2026-10-14 04:53:28 UTC in Python 3.12.8 / SymPy 1.14.0 and returned
exit code 1: **124 checks passed and one failed** in 1.014 seconds. The
failure was `action.log_coupling_derivative`. SymPy left the equivalent
representations `sqrt(1-k)sqrt(1+3k)` and `sqrt(1+2k-3k^2)` distinct
under a merely positive k assumption. It was an actual failed assertion,
not silently waived. Its complete source, residual, stdout, stderr, JSON
result and run record remain preserved.

The separate narrow repair ran at 04:54:56 UTC, returned exit code zero,
and recorded **8/0** in 0.323 seconds. It reproduced the representation
failure; verified the original derivative divided by nonzero alpha exactly;
proved equality of the radicands; and parameterized the full stated action
domain as `k=z/[3(1+z)]`, z>0. This parameterization is bijective onto
`0<k<1/3` and normalizes the original failed residual to exactly zero.
An intentionally doubled derivative still fails. The first execution is
not relabeled 125/0, and no full mathematics rerun is claimed.

The mathematical sensitivity controls reject omission of the conformal
clock, substitution of tensor calibration for the stipulated dynamical
calibration, an erroneous factor two in scalar exchange, substituting the
energy fraction for expansion excess, the quadratic coefficient 12 in place
of 13, and interpreting zero branch C derivative as zero full gradient.
Root-domain and free-calibration controls check the corresponding inference
limits. These are independently evaluated damaged formula candidates and
scope counterexamples; they are not executions of modified producer runners.
Expected rejection of a damaged candidate is a successful control, distinct
from the actual CAS failure above.

The separate source-correspondence run returned **9/0** at 04:56:09 UTC.
It verified all four source/live byte identities and reconstructed v2 exactly
from v1 using only the revised calibration paragraph and appended version
qualification. All displayed equation lines are byte-identical. The appended
text accurately says the author's original equation checks are reused and
does not claim a new execution. This report does not validate, repeat or
incorporate the author's stated 28/0 results.

Within these assumptions, the source's mathematical diagnostic is supported.
Actual radiation composition, density calibration, measured gravity,
likelihoods, transition physics, finite-field errors and observational
uncertainties remain unsupplied. A value at or below one conflicts only with
the exact positive-k central prediction under the specified ideal regime and
calibration. No empirical exclusion, confidence interval, present-vacuum
identification, background selection or global cosmological conclusion
follows from this check. All evidence is confined to this new folder and
the prior sealed evidence remains unchanged.
