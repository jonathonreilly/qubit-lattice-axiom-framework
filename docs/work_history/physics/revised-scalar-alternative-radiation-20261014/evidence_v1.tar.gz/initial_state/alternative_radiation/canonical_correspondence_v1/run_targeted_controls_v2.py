#!/usr/bin/env python3
"""Affected delivery checks only; preserves both formerly missed damages."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'targeted_damages_v2'
OUT.mkdir(exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

runner = ROOT / 'scripts/exponential_scalar_alternative_radiation_check.py'
data = runner.read_bytes()
assert sha(data) == 'f0cf10d3f4554bf038a11070704ea1ded8eefb15813dddff7c5939a6715ba2a9'
(HERE / 'sources/CANONICAL_RUNNER_repaired.py').write_bytes(data)
note = ROOT / 'docs/EXPONENTIAL_SCALAR_ALTERNATIVE_RADIATION_BOUNDED_THEOREM_NOTE_2026-10-14.md'
(HERE / 'sources/CANONICAL_NOTE_repaired.md').write_bytes(note.read_bytes())
original = json.loads((HERE / 'targeted_damages_v1/PROTOCOL_v1.json').read_text())
source = data.decode()
protocol = dict(utc=utc(), baseline_runner_sha256=sha(data),
                scope='Rerun only the two actually missed damaged-copy controls after action/jet binding repair; not a science rerun.',
                controls=[])
for row in original['controls']:
    assert source.count(row['replacement_old']) == 1
    damaged = source.replace(row['replacement_old'], row['replacement_new']).encode()
    path = OUT / (row['label'] + '.py')
    path.write_bytes(damaged)
    protocol['controls'].append(dict(row, path=str(path.relative_to(HERE)), sha256=sha(damaged)))
put(OUT / 'PROTOCOL_v2.json', protocol)
results = []
for row in protocol['controls']:
    label = row['label']
    path = HERE / row['path']
    cmd = [sys.executable, str(path.relative_to(ROOT))]
    started, tick = utc(), time.monotonic()
    try:
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, timeout=30)
        stdout, stderr, code, timed_out = proc.stdout, proc.stderr, proc.returncode, False
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code, timed_out = exc.stdout or b'', exc.stderr or b'', 124, True
    finished, elapsed = utc(), time.monotonic()-tick
    (OUT / (label+'.stdout.json')).write_bytes(stdout)
    (OUT / (label+'.stderr.txt')).write_bytes(stderr)
    parsed = json.loads(stdout) if stdout.strip() else {}
    failed = [r['name'] for r in parsed.get('checks', []) if not r['passed']]
    result = dict(label=label, started_utc=started, finished_utc=finished,
                  wall_seconds=elapsed, timeout_seconds=30, command=cmd, cwd=str(ROOT),
                  source_sha256=sha(path.read_bytes()), stdout_sha256=sha(stdout),
                  stderr_sha256=sha(stderr), exit_code=code, timed_out=timed_out,
                  counts=parsed.get('counts'), failed_checks=failed,
                  damage_detected=code==1 and len(failed)>0)
    put(OUT / (label+'.RUN.json'), result)
    results.append(result)
put(OUT / 'RESULTS_v2.json', dict(controls=results,
    detected=sum(r['damage_detected'] for r in results),
    undetected=sum(not r['damage_detected'] for r in results)))
print(json.dumps(results, indent=2))
sys.exit(any(not r['damage_detected'] for r in results))
