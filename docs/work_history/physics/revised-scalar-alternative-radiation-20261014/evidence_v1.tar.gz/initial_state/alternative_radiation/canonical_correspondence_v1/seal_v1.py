#!/usr/bin/env python3
"""One-time seal of this bounded correspondence; no parent mutations."""
from pathlib import Path
import datetime as dt
import hashlib
import json

ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
HERE=Path(__file__).resolve().parent

def sha(data):return hashlib.sha256(data).hexdigest()
def put(name,value):(HERE/name).write_text(json.dumps(value,indent=2)+'\n')
def load(name):return json.loads((HERE/name).read_text())
def bound(name):
    data=(HERE/name).read_bytes()
    return dict(path=name,bytes=len(data),sha256=sha(data))

assert not (HERE/'MANIFEST_v1.json').exists()
assert not (HERE/'RECEIPT_v1.json').exists()
final=load('FINAL_SOURCE_SNAPSHOTS_v1.json')['sources'][:4]
for row in final:
    live=(ROOT/row['original_path']).read_bytes()
    assert sha(live)==row['sha256']
    assert live==(HERE/row['snapshot_path']).read_bytes()
results=load('CORRESPONDENCE_RESULTS_v1.json')
assert results['counts']==dict(passed=426,failed=0) and results['exception'] is None
utc=dt.datetime.now(dt.timezone.utc).isoformat()
artifacts=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        artifacts.append(bound(str(path.relative_to(HERE))))
put('MANIFEST_v1.json',dict(schema='focused-correspondence-artifact-manifest-v1',sealed_utc=utc,
    scope='Alternative-radiation canonical delivery correspondence, with unchanged reused mathematics.',
    artifact_count=len(artifacts),artifacts=artifacts,
    excluded=['MANIFEST_v1.json','RECEIPT_v1.json']))
receipt=dict(schema='focused-canonical-correspondence-receipt-v1',sealed_utc=utc,
    checker='/root/scalar_energy_check',scientific_author='/root',formal_audit=False,
    outcome='Final source/cache correspondence agrees within the checked conditional scope. Two initial missed action/jet bindings and overbroad finite-field evidence wording were repaired; original failures remain preserved.',
    final_live_source_bindings=final,
    report=bound('REPORT_v1.md'),manifest=dict(bound('MANIFEST_v1.json'),artifact_count=len(artifacts)),
    reused_science=[
        dict(folder='initial_state/alternative_radiation/independent_v1',
            receipt_sha256='981355b6d666a1cc4a1c3437e0d1facbda97b153c904c5a722ecfad493633b5e',
            manifest_sha256='dbe5612e81165a244a1f88b0ae8b946a1ca9b37e9056c0ad316a85ced0b562a4',
            verified_artifacts=29,verified_live_snapshot_source_pairs=2,
            history='Three exit-124 timeouts; separate successful core 71/0 and nu=1 pointwise normal-acceleration 107/0. No science rerun here.'),
        dict(folder='initial_state/alternative_radiation/physical_bridge_independent_v1',
            receipt_sha256='1bd0582bd2dbd3e6dbf4d5a2bbc37c368acc9cc959348b79c71f8062c0d2b4cb',
            manifest_sha256='14755f21c69a7809cf791df1b3ac5cdce8b93c9ef99422676784580d50f24128',
            verified_artifacts=35,verified_live_snapshot_source_pairs=5,
            history='Original 124/1, separate 8/0 radical repair, 9/0 readout and 8/0 density correspondences. No clean full rerun claimed.')],
    prior_checked_sources=[r for r in load('SOURCE_MANIFEST_initial.json')['sources'] if r['snapshot_path'] in ['sources/ALTERNATIVE_DERIVATION_v2.md','sources/PHYSICAL_BRIDGE_v3.md','sources/COMPLETE_ACTION_NOTE.md']],
    new_correspondence_execution=dict(run=bound('CORRESPONDENCE_RUN_v1.json'),result=bound('CORRESPONDENCE_RESULTS_v1.json'),
        counts=results['counts'],counts_by_category=results['counts_by_category'],
        note='Integrity/output correspondence assertions, including 17 exact comparisons to prior sealed matrices; not new science claims.'),
    actual_targeted_runs=[dict(version=v,protocol=bound(f'targeted_damages_v{v}/PROTOCOL_v{v}.json'),
        results=bound(f'targeted_damages_v{v}/RESULTS_v{v}.json'),
        controls=load(f'targeted_damages_v{v}/RESULTS_v{v}.json')['controls']) for v in [1,2]],
    parent_execution_correspondence=dict(initial_primary_counts=dict(passed=83,failed=0),
        initial_cache_counts=dict(passed=83,failed=0),final_cache_counts=dict(passed=88,failed=0),
        initial_damage_executions_verified=9,final_damage_executions_verified=11,
        parent_mutations_rerun_by_checker=False,
        cache_input_fingerprint='df51ef2e8b3533d035fd050416420dab97e99c81c750662d7675073e5f4722d2'),
    failures_and_repairs=[
        'Two actual initial damages incorrectly passed 83/0; retained byte-exactly in targeted_damages_v1.',
        'Both affected repaired repeats exit 1: W damage 75/13, cubic-B damage 87/1, retained in targeted_damages_v2.',
        'Finite-field evidence wording narrowed to nu=1 instantaneous normal-ratio acceleration at six couplings and two fixed states.',
        'Parent two atomic patch-context failures retained in parent_final/PATCH_TOOL_FAILURES_v1.json as reported history.',
        'One ancillary empty-timeout-stdout JSON inspection error retained in INSPECTION_ERROR_v1.json; corrected filename selection.'],
    scope_limits=[
        'Supplied classical action, flat homogeneous trace-free radiation, fixed k and ideal large-field limiting system.',
        'Full six-variable local stability only for 0<k<3-2sqrt(2); mixed contradiction only its stated constant-ratio ansatz.',
        'No uniform basin, full-action long-time attraction, trajectory shadowing, finite history, matter or mixture claim.',
        'Specified ideal vacuum dynamical-force calibration; actual mass/environment/gravity calibration and empirical tests remain open.',
        'No observed initial state, parameter likelihood, empirical exclusion or absolute-scale selection.',
        'Recovery archive, committed delivery identity and integration validation require a separate check.'],
    independence=dict(prior_scientific_receipts_reused_unchanged=True,
        primary_runner_read_for_delivery_correspondence=True,
        prior_science_rerun=False,new_empirical_data=False,new_agents=False,
        writes_outside_correspondence_folder=False,
        git_pr_runtime_lock_audit_or_authority_changes=False),
    seal_policy='Immutable manifest and receipt. Any later source or delivery identity check requires a new addendum folder.')
put('RECEIPT_v1.json',receipt)
for row in artifacts:
    data=(HERE/row['path']).read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['bytes']
assert sha((HERE/'MANIFEST_v1.json').read_bytes())==receipt['manifest']['sha256']
print(json.dumps(dict(artifact_count=len(artifacts),report=bound('REPORT_v1.md'),
    manifest=bound('MANIFEST_v1.json'),receipt=bound('RECEIPT_v1.json')),
    indent=2))
