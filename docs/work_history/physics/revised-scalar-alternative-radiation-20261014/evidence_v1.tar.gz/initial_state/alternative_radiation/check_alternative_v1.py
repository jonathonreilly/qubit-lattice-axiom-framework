#!/usr/bin/env python3
"""Direct-author restricted alternative radiation branch exploration."""
from pathlib import Path
import json,hashlib
import sympy as s
import mpmath as mp
pdir=Path(__file__).resolve().parent
out=pdir/'results_v1';out.mkdir(exist_ok=False)
rows=[]
def ck(name,ok,**more):rows.append(dict(name=name,passed=bool(ok),**more))
def zero(name,expr):
 r=s.factor(s.cancel(expr));ck(name,r==0,residual=str(r))

k,theta,z,p,q=s.symbols('k theta z p q',real=True)
a=(1-k)*(1+3*k)/4
ss=(1+k)/(k*(1-3*k))
Ex=(1-3*k)/(3*(1+k))
E=Ex*s.exp(theta);F=1+ss*E;J=1+(1-3*a)*ss*E
A=J/(4*a*F**2)
B=(1+ss)*2*k/(3*(1+k)*F)
C=(1+ss)*E/F
Bx=2*k*(1-k)/((1+k)*(1-3*k));Cx=(1-k)/(1+k)
HBx=2*Cx**2/(3*(1-2*Bx));Wx=Bx*HBx
lx=2/(1+3*k)
W=Wx*s.exp(2*z-lx*theta)
zero('branch.kinetic_value',B.subs(theta,0)-Bx)
zero('branch.physical_metric',C.subs(theta,0)-Cx)
zero('branch.u_balance',lx-2*ss*Ex/(1+ss*Ex))
zero('branch.positive_radiation_domain',(1-2*Bx)-(1-6*k+k*k)/((1+k)*(1-3*k)))
crit=3-2*s.sqrt(2)
zero('branch.domain_endpoint',1-6*crit+crit**2)
ck('branch.endpoint_in_candidate_interval',0<crit<s.Rational(1,3))

v,X,Y,Bg=s.symbols('v X Y Bg',real=True)
t=v*v
G=Bg*(3+4*t)/(3*(1+t));V=4*Bg*v/(3*(1+t))
Wmix=k*(t*X/2+Y/3)
mixed=s.factor(s.diff(Wmix,v)/Wmix-2*(V+s.diff(G,v))/G)
ratio=4*(3+2*t)/(3*(3+t))
zero('mixed.required_ratio',mixed.subs(X,ratio*Y))
zero('mixed.ratio_strictly_above_one',ratio-1-(3+5*t)/(3*(3+t)))
lamx,lamy=s.symbols('lamx lamy',real=True)
weighted=(3*t*lamx*X+2*lamy*Y)/(3*t*X+2*Y)
zero('mixed.weighted_strictly_below_lamy',lamy-weighted-3*t*X*(lamy-lamx)/(3*t*X+2*Y))

T=A*p*p+B*q*q;HB=2*(C*C+W)/(3-T);h=-4*C*C/(3*HB)-T
flow=s.Matrix([p,q+2+p/F,
 -(3+h)*p-s.diff(A,theta)*p*p/(2*A)+s.diff(B,theta)*q*q/(2*A)+lx*W/(A*HB),
 -(3+h)*q-s.diff(B,theta)*p*q/B-2*W/(B*HB)])
fp={theta:0,z:0,p:0,q:-2}
for i,x in enumerate(flow.subs(fp)):zero('fixed_point.'+str(i),x)
zero('fixed_point.Hbar',HB.subs(fp)-HBx)
zero('fixed_point.h',h.subs(fp)+2)
M=flow.jacobian([theta,z,p,q]).subs(fp).applyfunc(lambda v:s.factor(s.cancel(v)))
lam=s.symbols('lambda');cp=s.factor(M.charpoly(lam).as_expr())
coef=s.Poly(cp,lam)
S=s.factor(coef.coeff_monomial(lam)-0)
P=s.factor(coef.coeff_monomial(1))
zero('spectrum.paired_polynomial',cp-((lam*lam+lam)**2+S*(lam*lam+lam)+P))
weak=s.factor(s.limit(cp,k,0))

# Independent normal metric for w=y/x, allowing an abstract positive ratio
# R=exp[-(lambda_y-lambda_x)u_x], derived separately from the action.
w,ell,R=s.symbols('w ell R',real=True)
c=s.Rational(3,4)
Gnorm=Bg/(1+w*w)*s.Matrix([[c,c*w],[c*w,1+c*w*w]])
Gi=s.simplify(Gnorm.inv());coord=(w,ell)
Gam=s.simplify(sum(Gi[0,j]*(2*s.diff(Gnorm[j,1],ell)-s.diff(Gnorm[1,1],coord[j]))/2 for j in range(2)))
# Normalize W(0)=Bg*Hbar, so the scale Hbar cancels below.
Vnorm=Bg*s.exp(2*ell)*(1+s.Rational(2,3)*R*w*w)
force=s.simplify(Gi*s.Matrix([s.diff(Vnorm,w),s.diff(Vnorm,ell)])/s.exp(2*ell))
omega=s.factor(4*s.diff(Gam,w).subs(w,0)+s.diff(force[0],w).subs(w,0))
zero('normal.restoring_coefficient',omega-(-s.Rational(2,3)+s.Rational(16,9)*R))
ck('normal.lower_bound_from_R_above_one',s.Rational(16,9)-s.Rational(2,3)==s.Rational(10,9)>s.Rational(1,4))

mp.mp.dps=60;mat=s.lambdify(k,M,'mpmath');numeric=[]
for ks in ['0.000001','0.00001','0.001','0.01','0.1','0.16','0.1715']:
 kv=mp.mpf(ks);eig,_=mp.eig(mat(kv));numeric.append({'k':ks,'eigenvalues':[[mp.nstr(mp.re(ev),45),mp.nstr(mp.im(ev),45)] for ev in eig],'largest_real':mp.nstr(max(mp.re(ev) for ev in eig),45),'all_negative_real':all(mp.re(ev)<0 for ev in eig)})
result={'scope':'Restricted constant-ratio radiation ansatz exploration. Numerical eigenvalues do not establish all-k stability. No observed data.',
 'source_sha256':hashlib.sha256((pdir/'DERIVATION_v1.md').read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'matrix':str(M),'characteristic_polynomial':str(cp),'S':str(S),'P':str(P),'weak_limit_polynomial':str(weak),'checks':rows,
 'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'numeric_spectra':numeric}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(result['failed']!=0)
