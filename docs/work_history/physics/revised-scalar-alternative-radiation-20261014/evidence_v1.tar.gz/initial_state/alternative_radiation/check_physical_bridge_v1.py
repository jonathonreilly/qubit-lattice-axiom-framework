#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,datetime
import sympy as s

root=Path(__file__).resolve().parent;rows=[]
def z(name,expr):
 v=s.factor(s.cancel(expr));rows.append({'name':name,'passed':v==0,'residual':str(v)})
def ck(name,ok):rows.append({'name':name,'passed':bool(ok)})
k,Q0,Hv,rho=s.symbols('k Q0 Hv rho',positive=True)
Q=Q0*(1+k);C=(1-k)/(1+k);B=2*k*(1-k)/((1+k)*(1-3*k));HB=2*C*C/(3*(1-2*B))
HE2=Hv**2*(rho/(2*Q*Hv**2))*HB
HJ2=HE2/C;HGR2=rho/(3*Q0)
Delta=1-6*k+k*k;D=(1+k)*Delta;target=(1-k)*(1-3*k)/D
z('physical_frame_expansion_ratio',HJ2/HGR2-target)
z('scale_Hv_cancels',s.diff(HJ2/HGR2,Hv))
z('scale_Q0_cancels',s.diff(HJ2/HGR2,Q0))
z('strict_excess_identity',target-1-k*(1+8*k-k*k)/D)
poly=1+16*k-38*k*k+8*k**3-3*k**4
z('derivative_identity',s.diff(target,k)-poly/D**2)
z('derivative_positive_decomposition',poly-((1-3*k**4)+k*(16-38*k)+8*k**3))
ck('derivative_rational_lower_coefficients',1-s.Rational(3,625)>0 and 16-s.Rational(38,5)>0)
z('weak_expansion',s.series(target,k,0,3).removeO()-(1+k+13*k*k))
z('weak_endpoint',s.limit(target,k,0)-1)
kc=3-2*s.sqrt(2)
ck('finite_positive_numerator_at_critical',((1-k)*(1-3*k)).subs(k,kc)>0)
z('critical_denominator_zero',D.subs(k,kc))
z('scalar_energy_fraction',(4*B+2*B)/3-4*k*(1-k)/((1+k)*(1-3*k)))
z('older_y_branch_calibrated_expansion',(2*(1+k)/3)/(2*Q)*3*Q0-1)
a=(1-k)*(1+3*k)/4;ss=(1+k)/(k*(1-3*k));Ex=(1-3*k)/(3*(1+k));F=1+ss*Ex;J=1+(1-3*a)*ss*Ex
z('gradient_norm_at_x_branch',(a/F**2)/(J/F**2)-3*k*(1-k)/(1+3*k))
ck('damage.omitted_physical_clock',s.factor(HE2/HGR2-target)!=0)
ck('damage.scalar_fraction_is_not_expansion_excess',s.factor(2*B-(target-1))!=0)
for kval in [s.Rational(1,100000),s.Rational(1,101),s.Rational(1,10),s.Rational(17,100)]:
 ck('example.allowed_'+str(kval),0<kval<kc)
 ck('example.positive_excess_'+str(kval),target.subs(k,kval)>1)
 ck('example.positive_derivative_'+str(kval),s.diff(target,k).subs(k,kval)>0)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Conditional ideal radiation physical-frame identity; no observed-gravity matching, measured data or fitted k.',
 'source_sha256':hashlib.sha256((root/'PHYSICAL_RADIATION_BRIDGE_v1.md').read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':rows,
 'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows)}
dest=root/'PHYSICAL_BRIDGE_RESULTS_v1.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(result['failed']!=0)
