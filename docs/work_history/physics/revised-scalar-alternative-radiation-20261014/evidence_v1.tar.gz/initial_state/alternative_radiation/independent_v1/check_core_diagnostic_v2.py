#!/usr/bin/env python3
"""Independent branch balances and actual-flow Jacobian; no producer imports."""
from pathlib import Path
from itertools import permutations
import hashlib,json,sys
import sympy as s
import mpmath as mp

OUT=Path(__file__).resolve().parent
checks=[]
def record(name,ok,category="exact",evidence=None):
    checks.append({"name":name,"pass":bool(ok),"category":category,"evidence":evidence})
def exact(name,expression,category="exact"):
    reduced=s.factor(s.cancel(expression));record(name,reduced==0,category,str(reduced))
for i,row in enumerate(json.loads((OUT/"SOURCE_MANIFEST_v1.json").read_text())["source_files"]):
    raw=Path(row["source_path"]).read_bytes()
    record("source_identity_"+str(i),raw==(OUT/row["snapshot_path"]).read_bytes()
           and hashlib.sha256(raw).hexdigest()==row["sha256"],"binding")
print("PHASE BEGIN_BALANCES",file=sys.stderr,flush=True)
k=s.symbols("k",positive=True)
a=(1-k)*(1+3*k)/4
ss=(1+k)/(k*(1-3*k))
Ex=(1-3*k)/(3*(1+k));Fx=1+ss*Ex;Jx=1+(1-3*a)*ss*Ex
Cx=(1+ss)*Ex/Fx
b=(1+ss)*2*k/(3*(1+k)*Fx)
A0=Jx/(4*a*Fx**2)
r=1/(1+3*k);c=1-r;d0=3-4*b;L=2*b*r/A0
delta=1-6*k+k*k
H0=2*Cx**2/(3*(1-2*b));W0=b*H0
exact("x_branch_u_balance",4*a*ss*Ex/(1+ss*Ex)-(1-k))
exact("x_branch_C",Cx-(1-k)/(1+k))
exact("x_branch_B",b-2*k*(1-k)/((1+k)*(1-3*k)))
exact("x_branch_A_theta",A0-3*k/(4*(1-k)*(1+3*k)))
exact("physical_domain_factor",1-2*b-delta/((1+k)*(1-3*k)))
exact("radiation_constraint",H0*(3-4*b)-2*(Cx**2+W0))
exact("radiation_h",-4*Cx**2/(3*H0)-4*b+2)

# Lowered mixed-ratio equation, reconstructed from metric entries.
v,B,X,Y=s.symbols("v B X Y",real=True)
G=B*(3+4*v*v)/(3*(1+v*v));V=4*B*v/(3*(1+v*v))
potential=v*v*X/2+Y/3
residual=s.diff(potential,v)/potential-2*(V+s.diff(G,v))/G
mixed_ratio=4*(3+2*v*v)/(3*(3+v*v))
exact("mixed_ratio_solves_lowered_equation",residual.subs(X,mixed_ratio*Y))
exact("mixed_ratio_strict_excess",mixed_ratio-1-(3+5*v*v)/(3*(3+v*v)))
alpha,EE=s.symbols("alpha E",positive=True)
rhs=4*alpha*ss*EE/(1+ss*EE)
exact("mixed_u_monotone_derivative",s.diff(rhs,EE)-4*alpha*ss/(1+ss*EE)**2)
exact("mixed_u_value_at_zero",4*a*ss/(1+ss)-(1+k))
lx,ly=s.symbols("lambda_x lambda_y")
mean=(3*v*v*lx*X+2*ly*Y)/(3*v*v*X+2*Y)
exact("mixed_weighted_mean_gap",ly-mean-3*v*v*X*(ly-lx)/(3*v*v*X+2*Y))

print("PHASE BEGIN_HAND_MATRIX",file=sys.stderr,flush=True)
# Hand first-variation matrix, independent of a coefficient-jet constructor.
M=s.Matrix([[0,0,1,0],[0,0,c,1],
    [L*(-9+6*r+16*b-4*b*r)/d0,6*L*(1-2*b)/d0,-1,3*L/d0],
    [4-2*r-8*b,-4+8*b,-2*r,-1]]).applyfunc(s.cancel)

print("PHASE BEGIN_ACTUAL_FLOW",file=sys.stderr,flush=True)
# Directly differentiate the ACTUAL coefficient functions in R=e^theta,Z=e^(2z).
R,Z,p,q=s.symbols("R Z p q",positive=True)
E=Ex*R;F=1+ss*E;J=1+(1-3*a)*ss*E
A=J/(4*a*F**2);BB=(1+ss)*2*k/(3*(1+k)*F);C=(1+ss)*E/F
eta=2/(1+3*k)
W=W0*Z*R**(-eta)
T=A*p*p+BB*q*q
H=2*(C*C+W)/(3-T);h=-4*C*C/(3*H)-T
Atheta=R*s.diff(A,R);Btheta=R*s.diff(BB,R)
flow=s.Matrix([R*p,2*Z*(q+2+p/F),
    -(3+h)*p-Atheta*p*p/(2*A)+Btheta*q*q/(2*A)+eta*W/(A*H),
    -(3+h)*q-(Btheta/BB)*p*q-2*W/(BB*H)])
point={R:1,Z:1,p:0,q:-2}
for i in range(4):exact("actual_flow_fixed_point_"+str(i),flow[i].subs(point))
print("PHASE BEGIN_ACTUAL_JACOBIAN",file=sys.stderr,flush=True)
actual_J=s.zeros(4)
for i in range(4):
    for jj,var in enumerate([R,Z,p,q]):
        actual_J[i,jj]=s.cancel(s.diff(flow[i],var).subs(point))
print("PHASE BEGIN_MATRIX_COMPARISON",file=sys.stderr,flush=True)
scaling=s.diag(1,2,1,1)
for i in range(4):
    for jj in range(4):
        exact("direct_vs_hand_Jacobian_"+str(i)+str(jj),(scaling.inv()*actual_J*scaling-M)[i,jj])
lam=s.symbols("lambda")
nx=5-7*k-21*k*k+7*k**3
S=4*nx/((1+k)*(1-3*k)*(1+3*k))
P=64*k*(1-k)**2*delta/((1+k)**2*(1-3*k)**2*(1+3*k))
print("PHASE BEGIN_CHARPOLY",file=sys.stderr,flush=True)
polynomial=s.factor(M.charpoly(lam).as_expr())
target=(lam*lam+lam)**2+S*(lam*lam+lam)+P
exact("independent_matrix_characteristic_polynomial",polynomial-target)
exact("source_S_from_matrix_trace_square",(s.trace(M)**2-s.trace(M*M))/2-1-S)
print("PHASE BEGIN_DETERMINANT",file=sys.stderr,flush=True)
exact("source_P_from_matrix_determinant",M.det()-P)

print("PHASE BEGIN_ALL_DOMAIN",file=sys.stderr,flush=True)
# All-domain inequalities: identities with manifestly positive terms.
exact("nx_lower_bound_decomposition",nx-s.Rational(69,25)
    -(7*(s.Rational(1,5)-k)+21*(s.Rational(1,25)-k*k)+7*k**3))
denS=(1+k)*(1-3*k)*(1+3*k)
exact("S_denominator_upper_decomposition",s.Rational(6,5)-denS
      -(s.Rational(1,5)-k+9*k*k*(1+k)))
exact("Delta_less_than_one_minus_3k",1-3*k-delta-k*(3-k))
exact("ratio_one_minus_k_squared_gap",1+k-(1-k)**2-k*(3-k))
record("strict_gap_for_discriminant",s.Rational(46,5)>s.Rational(320,69),"domain")
kc=3-2*s.sqrt(2)
record("critical_coupling_domain",bool(kc>0) and bool(kc<s.Rational(1,5)),"domain")
exact("Delta_zero_at_boundary",delta.subs(k,kc))
hh=s.symbols("H_finite")
exact("no_finite_boundary_coefficient",s.simplify((hh*(3-6*b)-2*Cx*Cx).subs(k,kc))+2*s.simplify(Cx.subs(k,kc))**2)
record("outside_domain_T_alone_is_insufficient",bool((4*b).subs(k,s.Rational(1,5))<3)
       and bool(H0.subs(k,s.Rational(1,5))<0),"negative_control")
record("k_zero_metric_degeneracy",s.limit(A0,k,0)==0 and s.limit(b,k,0)==0,"negative_control")
SS,PP=s.symbols("S P")
hurwitz=2*(1+SS)*SS-SS*SS-4*PP
exact("Hurwitz_third_determinant",hurwitz-(SS*SS+2*SS-4*PP))
record("Hurwitz_all_domain_gap",s.Rational(46,5)+2-s.Rational(320,69)>0,"domain")
exact("weak_limit_polynomial",s.limit(target,k,0)-lam*(lam+1)*(lam*lam+lam+20))
exact("weak_root_slope",-s.limit(s.diff(P,k),k,0)/s.limit(S,k,0)+s.Rational(16,5))

print("PHASE BEGIN_NORMAL",file=sys.stderr,flush=True)
# Independent transformed x-axis geometry and its original-y equation.
w,vel,AA,BBg,Ader,Bder,jj=s.symbols("w vel A B Ader Bder j",real=True)
metric=s.Matrix([[AA,0,0],[0,BBg*(1+s.Rational(3,4)*w*w)/(1+w*w),BBg*s.Rational(3,4)*w/(1+w*w)],
                 [0,BBg*s.Rational(3,4)*w/(1+w*w),BBg*s.Rational(3,4)/(1+w*w)]])
inverse=s.simplify(metric.inv())
partials=[metric.diff(AA)*Ader+metric.diff(BBg)*Bder,s.zeros(3),metric.diff(w)]
gam=[[[s.factor(sum(inverse[ii,ll]*(partials[dd][ll,ee]+partials[ee][ll,dd]-partials[ll][dd,ee])
    for ll in range(3))/2) for ee in range(3)] for dd in range(3)] for ii in range(3)]
exact("normal_connection_linear",s.diff(gam[2][1][1],w).subs(w,0)-s.Rational(1,3))
Wr=s.symbols("Wr",positive=True)
Wnorm=Wr*(1+s.Rational(2,3)*jj*w*w)
gradient=s.Matrix([0,2*Wnorm,s.diff(Wnorm,w)])
force=(inverse*gradient)[2]
exact("normal_force_linear",s.diff(force,w).subs(w,0)-(Wr/BBg)*(-2+s.Rational(16,9)*jj))
Omega=-s.Rational(2,3)+s.Rational(16,9)*jj
original_y_poly=(lam-2)**2+5*(lam-2)+s.Rational(16,3)+s.Rational(16,9)*jj
exact("original_y_to_normal_polynomial",original_y_poly-(lam*lam+lam+Omega))
exact("normal_positive_lower_gap",Omega-s.Rational(10,9)-s.Rational(16,9)*(jj-1))
full_char=s.factor(target*(lam*lam+lam+Omega))

print("PHASE BEGIN_DAMAGES",file=sys.stderr,flush=True)
# Nonvacuous damaged Jacobians and normal equations.
bad_clock=M.copy();bad_clock[1,2]=0
record("damage_omit_physical_clock_changes_spectrum",s.cancel((bad_clock.charpoly(lam).as_expr()-polynomial).subs(k,s.Rational(1,7)))!=0,"negative_control")
gtheta=(6*(1-2*b)*c-8*b*r)/d0
gz=4*b/d0;gq=-4*b/d0
bad_frozen=s.Matrix([[0,0,1,0],[0,0,c,1],[-L,2*L,-1,L],[2*r,-4,-2*r,-1]])
record("damage_freeze_constraints_changes_spectrum",s.cancel((bad_frozen.charpoly(lam).as_expr()-polynomial).subs(k,s.Rational(1,7)))!=0,"negative_control")
bad_no_mixed_force=lam*lam+lam+s.Rational(4,3)+s.Rational(16,9)*jj
record("damage_omit_mixed_normal_force",s.cancel(bad_no_mixed_force-(lam*lam+lam+Omega))==2,"negative_control")
bad_no_connection=lam*lam+lam-2+s.Rational(16,9)*jj
record("damage_omit_normal_connection",s.cancel(bad_no_connection-(lam*lam+lam+Omega))==-s.Rational(4,3),"negative_control")

print("PHASE BEGIN_NUMERIC",file=sys.stderr,flush=True)
# Independent 70-digit matrix eigenspectra on fixed distinct rational k values.
mp.mp.dps=70
ks=[s.Rational(1,41),s.Rational(2,29),s.Rational(3,31),s.Rational(1,7),s.Rational(5,31),s.Rational(17,100)]
rows=[]
def mpq(value):
    num,den=s.fraction(s.cancel(value));return mp.mpf(str(num))/mp.mpf(str(den))
for kk in ks:
    mm=mp.matrix([[mpq(entry.subs(k,kk)) for entry in M.row(i)] for i in range(4)])
    eig=mp.eig(mm,left=False,right=False)
    sval=mpq(S.subs(k,kk));pval=mpq(P.subs(k,kk))
    large=(sval+mp.sqrt(sval*sval-4*pval))/2;small=pval/large
    expected=[(-1+sign*mp.sqrt(1-4*rr))/2 for rr in [small,large] for sign in [-1,1]]
    error=min(max(abs(eig[i]-perm[i]) for i in range(4)) for perm in permutations(expected))
    kval=mpq(kk);exval=mpq(Ex.subs(k,kk))
    jval=mp.power(exval,-4*kval/((1-kval)*(1+3*kval)))
    omega=-mp.mpf(2)/3+mp.mpf(16)/9*jval
    record("matrix_spectrum_"+str(kk),error<mp.mpf('1e-55') and max(mp.re(z) for z in eig)<0,"numeric_display")
    record("normal_domain_"+str(kk),jval>1 and omega>mp.mpf(10)/9,"numeric_display")
    rows.append({"k":str(kk),"plane_eigenvalues":[mp.nstr(z,35) for z in eig],
        "max_real_plane":mp.nstr(max(mp.re(z) for z in eig),35),"matrix_root_discrepancy":mp.nstr(error,8),
        "normal_j":mp.nstr(jval,35),"normal_Omega_squared":mp.nstr(omega,35)})

categories=sorted({row["category"] for row in checks})
result={"scope":"Independent mixed/x-only balances, actual-flow Jacobian and all-domain stability controls; no producer code or output files.",
    "checks":checks,"counts":{"passed":sum(row["pass"] for row in checks),"failed":sum(not row["pass"] for row in checks)},
    "counts_by_category":{category:{"passed":sum(row["pass"] for row in checks if row["category"]==category),"failed":sum(not row["pass"] for row in checks if row["category"]==category)} for category in categories},
    "hand_matrix":[[str(z) for z in M.row(i)] for i in range(4)],"plane_polynomial":str(polynomial),
    "full_six_polynomial":str(full_char),"spectra":rows,"mpmath_digits":70,
    "hand_derivation_sha256":hashlib.sha256((OUT/"HAND_DERIVATION_v1.txt").read_bytes()).hexdigest(),
    "protocol_sha256":hashlib.sha256((OUT/"PROTOCOL_v1.json").read_bytes()).hexdigest()}
print(json.dumps(result,indent=2))
sys.exit(any(not row["pass"] for row in checks))
