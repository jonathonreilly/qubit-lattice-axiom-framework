#!/usr/bin/env python3
"""Full-action finite-x pointwise normal acceleration and rational box bounds."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product
import hashlib,json,sys
import sympy as s
import mpmath as mp

OUT=Path(__file__).resolve().parent
checks=[];certificates=[]
def record(name,ok,category,evidence=None):
    checks.append({"name":name,"pass":bool(ok),"category":category,"evidence":evidence})
def exact(name,expr):
    value=s.factor(s.cancel(expr));record(name,value==0,"exact",str(value))
def q(value):
    value=s.Rational(value);return Q(int(value.p),int(value.q))
def sym(value):
    value=Q(value);return s.Rational(value.numerator,value.denominator)
def show(value):
    value=Q(value);return {"exact":str(value),"decimal":format(float(value),".16g")}
def mul(left,right):
    vals=[x*y for x in left for y in right];return min(vals),max(vals)

k,delta,j,V,w,velocity=s.symbols("k delta j V w velocity",real=True)
variables=[delta,j,V]
d=2*(1+k)/3
b=2*k*(1-k)/((1+k)*(1-3*k))
Cx=(1-k)/(1+k)
H0=2*Cx**2/(3*(1-2*b));W0=b*H0
rad=s.cancel(Cx**2*k/(2*W0)) # sigma/(X*x^2), z_x=0
dn=delta+d*(1+w*w)
kx=b*d/dn;ky=s.Rational(3,4)*kx
xp=s.Integer(-2);yp=velocity-2*w
T=kx*xp*xp+ky*yp*yp
pot=V*delta+k/2+(k/3)*j*w*w
H=2*(rad+pot)/(3-T)
h=-T-4*rad/(3*H)
gx=(-d*xp*xp-2*d*w*xp*yp+s.Rational(3,4)*d*yp*yp)/dn
gy=(s.Rational(4,3)*d*w*xp*xp-2*d*xp*yp-d*w*yp*yp)/dn
# Combine the original x,y equations before inserting the constraints. This
# avoids expanding a generic six-parameter nested rational function.
print("PHASE COMPACT_ACTION",file=sys.stderr,flush=True)
connection_polynomial=-s.Rational(4,3)*w-4*velocity-3*w*w*velocity-w**3+s.Rational(7,4)*w*velocity*velocity
exact("original_connection_combination",-gy+w*gx-d*connection_polynomial/dn)
KX,HH,hh=s.symbols("KX Hbar h")
exact("original_force_combination",-(2*k/3)*j*w/((s.Rational(3,4)*KX)*HH)+w*k/(KX*HH)
      -k*w/(KX*HH)*(1-s.Rational(8,9)*j))
energy=rad+pot
full=(1+T)*velocity+d*connection_polynomial/dn+(3-T)/(2*energy)*(s.Rational(4,3)*rad*velocity
      +k*w*dn/(b*d)*(1-s.Rational(8,9)*j))

# Independently reconstructed limiting metric with free h,H before constraints.
gll=b*(1+s.Rational(3,4)*w*w)/(1+w*w)
glw=s.Rational(3,4)*b*w/(1+w*w)
gww=s.Rational(3,4)*b/(1+w*w)
ivl=-w*(1+w*w)/b;ivv=(w*w+s.Rational(4,3))*(1+w*w)/b
Gll=-ivv*s.diff(gll,w)/2
Glw=ivl*s.diff(gll,w)/2
Gww=ivl*s.diff(glw,w)+ivv*s.diff(gww,w)/2
Tl=gll*xp*xp+2*glw*xp*velocity+gww*velocity*velocity
pl=k/2+(k/3)*j*w*w
force=ivl*2*pl+ivv*s.diff(pl,w)
transformed_free=-(3+hh)*velocity-Gll*xp*xp-2*Glw*xp*velocity-Gww*velocity*velocity-force/HH
original_free=(1-hh)*velocity+connection_polynomial/(1+w*w)+k*w*(1+w*w)/(b*HH)*(1-s.Rational(8,9)*j)
exact("full_diagonal_action_to_limiting_metric",original_free-transformed_free)
exact("kinetic_metric_off_branch_correspondence",T.subs(delta,0)-Tl)
limit=full.subs(delta,0)
exact("limiting_normal_block_w",s.diff(limit,w).subs({w:0,velocity:0})-s.Rational(2,3)+s.Rational(16,9)*j)
exact("limiting_normal_block_velocity",s.diff(limit,velocity).subs({w:0,velocity:0})+1)

# Rigorous physical parameter enclosure for nu=1, no numerical log oracle.
Ex=(1-3*k)/(3*(1+k));power=4*k/((1-k)*(1+3*k))
exact("Ex_above_one_ninth",Ex-s.Rational(1,9)-2*(1-5*k)/(9*(1+k)))
exact("j_exponent_below_one",1-power-(1+k)*(1-3*k)/((1-k)*(1+3*k)))
exact("alpha_above_half",(1-k)*(1+3*k)-1-k*(2-3*k))
record("log9_below3_via_positive_exp_series",1+3+s.Rational(9,2)+s.Rational(27,6)>9,"domain")
record("vacuum_base_upper_below30",s.Rational(3,2)+s.Rational(81,10)+s.Rational(81,4)<30,"domain")

def poly_interval(poly,box):
    lo=hi=Q(0)
    for powers,coefficient in poly.terms():
        term=(Q(1),Q(1))
        for exponent,interval in zip(powers,box):
            if exponent:
                # All three box coordinates are nonnegative.
                term=mul(term,(interval[0]**exponent,interval[1]**exponent))
        term=mul(term,(q(coefficient),q(coefficient)))
        lo+=term[0];hi+=term[1]
    return lo,hi

def prepare_bound(expression):
    numerator,denominator=s.fraction(s.cancel(expression))
    numerator=s.Poly(numerator,*variables,domain=s.QQ)
    coefficient,factors=s.factor_list(denominator,*variables)
    factors=[(s.Poly(factor,*variables,domain=s.QQ),power) for factor,power in factors]
    return numerator,q(coefficient),factors

def bound_box(prepared,box):
    numerator,coefficient,factors=prepared
    ni=poly_interval(numerator,box)
    di=(coefficient,coefficient)
    for factor,power in factors:
        fi=poly_interval(factor,box)
        if fi[0]<=0<=fi[1]:
            raise ArithmeticError("A denominator factor is not separated from zero on the fixed box")
        if fi[0]>0:
            fi=(fi[0]**power,fi[1]**power)
        elif power%2==0:
            fi=(fi[1]**power,fi[0]**power)
        else:
            fi=(fi[0]**power,fi[1]**power)
        di=mul(di,fi)
    if di[0]<=0<=di[1]:raise ArithmeticError("Rational denominator interval includes zero")
    vals=[nn/dd for nn in ni for dd in di]
    return min(vals),max(vals)

ks=[s.Rational(1,41),s.Rational(2,29),s.Rational(3,31),s.Rational(1,7),s.Rational(5,31),s.Rational(17,100)]
pairs=[(s.Rational(1,50),s.Rational(1,75)),(s.Rational(-1,40),s.Rational(1,60))]
mp.mp.dps=70
def mpq(value):
    num,den=s.fraction(s.cancel(value));return mp.mpf(str(num))/mp.mpf(str(den))
for kk in ks:
    print("PHASE BOX_K "+str(kk),file=sys.stderr,flush=True)
    for ratio,speed in pairs:
        substitutions={k:kk,w:ratio,velocity:speed}
        expr=s.cancel(full.subs(substitutions))
        zero=s.cancel(expr.subs(delta,0))
        derivative=s.diff(expr,delta)
        prepared=prepare_bound(derivative)
        lows=[];highs=[]
        for idelta,ij,iV in product(range(4),repeat=3):
            box=[(Q(idelta,400),Q(idelta+1,400)),
                 (Q(1+2*ij),Q(3+2*ij)),
                 (Q(15*iV,2),Q(15*(iV+1),2))]
            low,high=bound_box(prepared,box);lows.append(low);highs.append(high)
        bound=max(abs(min(lows)),abs(max(highs)))
        tmax=q(T.subs({**substitutions,delta:0}))
        record("finite_x_positive_chart_"+str(kk)+"_"+str(ratio),0<tmax<3,"certificate")
        values=[]
        for jv,Vv in [(2,3),(7,19)]:
            for xx in [10,20,50]:
                exact_error=q((expr-zero).subs({delta:s.Rational(1,xx*xx),j:jv,V:Vv}))
                record("box_polynomial_control_"+str(kk)+"_"+str(ratio)+"_"+str(jv)+"_"+str(xx),
                    abs(exact_error)<=bound/Q(xx*xx),"certificate")
                values.append({"j":jv,"V":Vv,"x":xx,"error":show(exact_error),"bound":show(bound/Q(xx*xx))})
        # Readouts from the supplied candidate with nu=1, separate from proof.
        kv=mpq(kk);av=(1-kv)*(1+3*kv)/4;alph=mp.sqrt(av)
        exv=mpq(Ex.subs(k,kk));ux=mp.log(exv)/(2*alph)
        sv=(1+kv)/(kv*(1-3*kv));fv=1+sv*exv
        Xv=mp.power(exv,-2/(1+3*kv))
        jactual=mp.power(exv,-4*kv/((1-kv)*(1+3*kv)))
        Ubase=mp.mpf(3)/2+3*sv*(exv-1)**2/(2*fv*fv)+(1+sv)*ux*ux/(2*fv*fv)
        Vactual=Ubase/Xv
        evaluate=s.lambdify((delta,j,V),expr-zero,"mpmath")
        actual=[{"x":xx,"error":mp.nstr(evaluate(mp.mpf(1)/(xx*xx),jactual,Vactual),30),
                 "rigorous_uniform_bound":show(bound/Q(xx*xx))} for xx in [10,20,50]]
        record("actual_nu1_parameters_inside_proved_box_"+str(kk)+"_"+str(ratio),1<jactual<9 and 0<Vactual<30,"numeric_display")
        certificates.append({"k":str(kk),"ratio_y_over_x":str(ratio),"ratio_velocity":str(speed),
            "physical_parameter_scope":"nu=1, 1<j<9, 0<V<30 proved analytically; fixed branch u_x and z_x=0 instantaneous states",
            "box":{"delta":["0","1/100"],"j":["1","9"],"V":["0","30"]},"subboxes":64,
            "rational_acceleration":str(expr),"delta_derivative_enclosure":[str(min(lows)),str(max(highs))],
            "uniform_error_constant":show(bound),"max_T":str(tmax),"auxiliary_polynomial_controls":values,
            "candidate_nu1_j":mp.nstr(jactual,35),"candidate_nu1_V":mp.nstr(Vactual,35),"candidate_nu1_readouts":actual})

raw=(json.dumps(certificates,indent=2)+"\n").encode()
with (OUT/"FINITE_FIELD_CERTIFICATES_v2.json").open("xb") as stream:stream.write(raw)
categories=sorted({row["category"] for row in checks})
result={"scope":"New finite-x pointwise normal-acceleration correspondence, independent of completed core run; no histories or producer outputs.",
    "checks":checks,"counts":{"passed":sum(row["pass"] for row in checks),"failed":sum(not row["pass"] for row in checks)},
    "counts_by_category":{category:{"passed":sum(row["pass"] for row in checks if row["category"]==category),"failed":sum(not row["pass"] for row in checks if row["category"]==category)} for category in categories},
    "certificate_count":len(certificates),"certificate_sha256":hashlib.sha256(raw).hexdigest(),"certificate_bytes":len(raw),
    "max_uniform_constant":max(float(Q(row["uniform_error_constant"]["exact"])) for row in certificates),
    "mpmath_digits":70,"proof":"Exact rational derivative boxes plus mean-value inequality; numerical candidate readouts are not used as proof."}
print(json.dumps(result,indent=2))
sys.exit(any(not row["pass"] for row in checks))
