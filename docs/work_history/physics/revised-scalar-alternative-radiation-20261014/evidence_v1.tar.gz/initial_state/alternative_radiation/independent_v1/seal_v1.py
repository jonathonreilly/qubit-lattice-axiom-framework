#!/usr/bin/env python3
"""Seal this independent alternative-branch check and all timeout history."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
import sympy,mpmath

BASE=Path(__file__).resolve().parent
def binding(path):
    raw=path.read_bytes()
    return {"path":str(path.relative_to(BASE)),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def write_new(path,value):
    with path.open("x") as stream:stream.write(json.dumps(value,indent=2)+"\n")

source_manifest=json.loads((BASE/"SOURCE_MANIFEST_v1.json").read_text())
sources=source_manifest["source_files"]
for row in sources:
    live=Path(row["source_path"]).read_bytes();saved=(BASE/row["snapshot_path"]).read_bytes()
    assert live==saved and hashlib.sha256(live).hexdigest()==row["sha256"] and len(live)==row["bytes"]
definitions=[
    ("RUN_01_CORE","check_core_v1.py",124,None),
    ("RUN_02_DIAGNOSTIC","check_core_diagnostic_v2.py",124,None),
    ("RUN_03_CHAINRULE","check_core_chainrule_v3.py",0,{"passed":71,"failed":0}),
    ("RUN_04_FINITE","check_finite_field_v1.py",124,None),
    ("RUN_05_FINITE_COMPACT","check_finite_field_compact_v2.py",0,{"passed":107,"failed":0}),
]
runs=[]
for prefix,script,code,expected in definitions:
    metadata=json.loads((BASE/(prefix+".json")).read_text())
    assert metadata["exit_code"]==code and binding(BASE/script)["sha256"]==metadata["script_sha256"]
    for suffix,key in [(".stdout.json","stdout_sha256"),(".stderr.txt","stderr_sha256")]:
        assert binding(BASE/(prefix+suffix))["sha256"]==metadata[key]
    category_counts=None
    if expected is not None:
        output=json.loads((BASE/(prefix+".stdout.json")).read_text())
        assert output["counts"]==expected
        category_counts=output["counts_by_category"]
    else:
        assert (BASE/(prefix+".stdout.json")).read_bytes()==b""
    runs.append({"prefix":prefix,"actual_exit_code":code,"completed_counts":expected,
        "counts_by_category":category_counts,"script":binding(BASE/script),
        "metadata":binding(BASE/(prefix+".json")),"stdout":binding(BASE/(prefix+".stdout.json")),
        "stderr":binding(BASE/(prefix+".stderr.txt"))})
core=json.loads((BASE/"RUN_03_CHAINRULE.stdout.json").read_text())
finite=json.loads((BASE/"RUN_05_FINITE_COMPACT.stdout.json").read_text())
assert binding(BASE/"HAND_DERIVATION_v1.txt")["sha256"]==core["hand_derivation_sha256"]
assert binding(BASE/"PROTOCOL_v1.json")["sha256"]==core["protocol_sha256"]
assert binding(BASE/"FINITE_FIELD_CERTIFICATES_v2.json")["sha256"]==finite["certificate_sha256"]
assert finite["certificate_count"]==12
now=datetime.now(timezone.utc).isoformat()
receipt={
    "kind":"focused_independent_mathematical_receipt",
    "sealed_utc":now,"checker":"/root/local_response_check","direct_author":"/root",
    "source_files":sources,
    "report":binding(BASE/"REPORT_v1.txt"),
    "hand_derivation_before_computation":binding(BASE/"HAND_DERIVATION_v1.txt"),
    "frozen_protocol":binding(BASE/"PROTOCOL_v1.json"),
    "actual_runs":runs,
    "finite_field_certificates":binding(BASE/"FINITE_FIELD_CERTIFICATES_v2.json"),
    "conclusion":{
        "source_correction_required":False,
        "mixed_branch":"No finite nonzero constant-ratio mixed branch in the declared constant-u radiation scaling class.",
        "x_only_physical_domain":"0<k<3-2sqrt(2); finite positive radiation scaling coefficient; positive and negative x charts have the same local spectrum.",
        "plane_spectrum":"Independent hand first-variation matrix and actual-coefficient chain-rule Jacobian reproduce S_x and P_x exactly; all-k inequalities and Hurwitz conditions prove strict stability.",
        "normal_spectrum":"Omega^2=-2/3+(16/9)exp[-(lambda_y-lambda_x)u_x]>10/9; both normal roots have real part -1/2.",
        "full_six_variable_scope":"Reflection symmetry makes both cross blocks vanish. The full limiting autonomous point is locally asymptotically stable for each fixed admissible k.",
        "weak_root":"lambda_slow=-(16/5)k+O(k^2), giving linear relaxation scale 5/(16k) Einstein e-folds."
    },
    "execution_accounting":"Two distinct successful runs: core 71/0 and finite-field 107/0. No single fresh 178-condition run is claimed. Three actual timeout executions are preserved and not counted as successes.",
    "preserved_failures":[
        {"run":"RUN_01_CORE","exit_code":124,"reason":"Nested actual-coefficient symbolic Jacobian calculation exceeded 45 seconds; no completed condition summary."},
        {"run":"RUN_02_DIAGNOSTIC","exit_code":124,"reason":"Instrumented 20-second run located the costly actual-Jacobian expansion; no completed condition summary."},
        {"run":"RUN_04_FINITE","exit_code":124,"reason":"Generic uncombined symbolic finite-field expression exceeded 45 seconds; no completed condition summary."}
    ],
    "recovery_methods":"Actual coefficient derivatives with explicit Hbar/h chain rules; original-coordinate finite-field equations combined algebraically before generic expansion. Sources, states, parameter boxes and mathematical criteria unchanged.",
    "finite_field_scope":"Twelve exact rational derivative-box certificates for instantaneous normal acceleration at six fixed k values and two ratio states, covering candidate nu=1 via analytically proved 1<j<9 and 0<V<30. Error <=M/x^2 for x>=10; M is conservative and can exceed unit accuracy at x=10. No full trajectory or shadowing certificate.",
    "limits":[
        "Restricted constant-u, constant-ratio, ideal trace-free radiation and large-field reduction of the supplied action; fixed finite nu and fixed positive k.",
        "No observed initial-state selection, fitted physical parameters, sign selection, probability measure, global basin or matter-transition history.",
        "No uniform basin at the coupling endpoints and no full-action future radiation attractor or empirical likelihood/exclusion.",
        "Prior completed transverse saddle result remains separate and unchanged; no PR or milestone integration performed here."
    ],
    "independence":{
        "producer_alternative_code_or_output_files_read_imported_or_run":False,
        "producer_narrative_in_source":"Read only as source content; not used as independent evidence.",
        "new_agents_or_other_chats":False,
        "empirical_data":False,
        "parent_source_completed_transverse_git_branch_pr_runtime_lock_audit_or_model_changes":False,
        "write_scope":"initial_state/alternative_radiation/independent_v1 only"
    },
    "environment":{"python":sys.version,"sympy":sympy.__version__,"mpmath":mpmath.__version__},
    "seal_policy":"All listed artifacts are immutable. Any later correspondence requires a new subfolder and receipt; manifest excludes itself. No formal audit or authority/status promotion."
}
write_new(BASE/"RECEIPT_v1.json",receipt)
artifacts=[binding(path) for path in sorted(BASE.rglob("*")) if path.is_file() and path.name!="MANIFEST_v1.json"]
write_new(BASE/"MANIFEST_v1.json",{"version":1,"sealed_utc":now,"scope":"Focused independent alternative radiation check",
    "artifact_count":len(artifacts),"artifacts":artifacts,"excluded":["MANIFEST_v1.json itself"]})
for row in artifacts:assert binding(BASE/row["path"])==row
print(json.dumps({"sealed_artifacts":len(artifacts),"source_pairs_verified":len(sources),
    "report":binding(BASE/"REPORT_v1.txt"),"receipt":binding(BASE/"RECEIPT_v1.json"),
    "manifest":binding(BASE/"MANIFEST_v1.json")},indent=2))
