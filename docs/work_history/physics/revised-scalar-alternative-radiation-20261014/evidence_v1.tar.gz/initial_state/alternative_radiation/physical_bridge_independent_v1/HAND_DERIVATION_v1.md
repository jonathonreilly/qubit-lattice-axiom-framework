# Independent physical-radiation bridge derivation

Checker `/root/scalar_energy_check`; direct scientific author `/root`.
Written before constructing or running this checker's controls. No producer
checker, output or functions have been read, imported or executed.

The alternative constant-u x-only state is a supplied conditional background.
I check its coefficient evaluations and radiation normalization needed here;
I do not duplicate its separate existence, mixed-branch or stability review.
Take fixed `0<k<kc=3-2sqrt(2)`, finite positive nu, positive physical radiation
density, large nonzero x, y=0, u=u_x, and `(log|x|)'=-2` in Einstein e-folds.

The action is `Q[R/2-K_AB dphi^A dphi^B-2 Hv^2 U]+S_m[C g_E]`, with
`Q=Q0(1+k)`. It has no extra one-half before K. For homogeneous fields,

    rho_phi,E = Q K_AB dot(phi)^A dot(phi)^B + 2Q Hv^2 U,
    p_phi,E   = Q K_AB dot(phi)^A dot(phi)^B - 2Q Hv^2 U,
    3Q H_E^2 = rho_phi,E + rho_E.

The conformal matter metric gives `rho_E=C^2 rho_J`. Define
`y_b^2=rho_J/(2Q Hv^2)`, `Hbar=H_E^2/(Hv^2 y_b^2)`,
`W=U_rad/y_b^2`, and `T=K_AB phi'^A phi'^B`.
Then `(3-T)Hbar=2(C^2+W)`. This derivation uses physical, unscaled rho_J;
the older note's rho_J/rho_unit convention gives the same y_b^2.

At y=0, the original metric gives

    lim_(|x|->infinity) K_xx x^2
       = (1+s)2k/[3(1+k)F] = Bx(u).

Substitute only the proposed branch value
`E_x=(1-3k)/[3(1+k)]`. Because `s E_x=1/(3k)`,

    F_x=(1+3k)/(3k),
    C_x=(1-k)/(1+k),
    Bx0=2k(1-k)/[(1+k)(1-3k)].

The radial scalar equation follows from the action's field metric and force
normalization `Hv^2 K^AB U_B`. The limiting radial metric is independent of
ell=log|x|. At u'=0, ell'=-2 and h=-2, its lowered equation is
`Bx(3+h)ell'+2W/Hbar=0`, hence `W/Hbar=Bx`. Thus `T=4Bx`, and the constraint
gives `Hbar=2C_x^2/[3(1-2Bx)]`. Set `Delta=1-6k+k^2`. Directly,

    1-2Bx = Delta/[(1+k)(1-3k)].

Positivity is therefore the supplied branch interval `0<k<kc`. The finite
constant and nu potential pieces are absent only in this large-field radiation
limit; this is not an exact finite-x full-history expansion formula.

For a general homogeneous conformal factor,

    dt_J=sqrt(C)dt_E, a_J=sqrt(C)a_E,
    H_J=(H_E+(1/2)d(log C)/dt_E)/sqrt(C).

Here C depends only on u, which is constant on the ideal branch. Consequently
`H_J^2=H_E^2/C_x=Hbar rho_J/(2Q C_x)`. The rolling x does not invalidate this
clock identity, since C has no x dependence. An independent background check
is that a *constant* conformal transformation changes the Einstein curvature
coefficient Q/2 into the Jordan coefficient Q/(2C_x), consistent with this
factor of C_x. This is a background transformation, not a full scalar-tensor
field redefinition that neglects derivatives when u varies.

The comparison gravity calibration needs a precise readout premise. At the
stipulated vacuum E=1, C=1, write `alpha_B=d_u log sqrt(C)` and `K0=K_uu`.
The action implies `G_tensor=1/(8pi Q)`. In a weak, approximately flat local
region with a nonrelativistic prescribed source and negligible scalar range
suppression, the static linear scalar equation is

    (laplacian-mu^2)delta u = alpha_B rho/(2Q K0),
    mu^2=Hv^2 U_uu/K0.

For a point mass, its exterior solution is
`delta u=-alpha_B M exp(-mu r)/(8pi Q K0 r)`. The physical dynamical
potential is `Phi_J=Phi_E+alpha_B delta u`, giving an unsuppressed force
coefficient `G_tensor(1+alpha_B^2/K0)`. The original C,K give
`alpha_B^2/K0=k`, hence

    G_vac,dynamical = (1+k)/(8pi Q) = 1/(8pi Q0).

This is conditional on the nonrelativistic source/readout, C=1, weak potentials,
negligible local curvature and negligible range suppression. A finite source
also needs a justified exterior scalar charge. It is not every weak local
readout: the conformal scalar terms in the two weak metric potentials have
opposite signs, so ideal lensing with independently known mass uses the tensor
normalization `1/(8pi Q)`. This distinction is the narrow v1 wording issue
reported to the author. No real calibration or measurement is established.

Using the stipulated dynamical G_vac in `H_GR^2=(8pi G_vac/3)rho_J`, the ratio
is independently

    R = 3 Hbar/[2(1+k)C_x]
      = C_x/[(1+k)(1-2Bx)]
      = (1-k)(1-3k)/[(1+k)Delta].

Both Q0 and Hv cancel in this diagnostic at the same physical density and
calibration. They are not thereby selected or irrelevant to all observations.
In particular, replacing G_vac by an unknown positive G_cal gives
`R_cal=R/gamma`, where `gamma=8pi Q0 G_cal`. If gamma is free, a single ratio
does not identify k: any admissible k can fit a given positive ratio by
choosing gamma. The source's explicit calibration premise is essential.

For the monotonicity and inversion, let `D_R=(1+k)Delta`. Then

    R-1 = k(1+8k-k^2)/D_R,
    R' = [1+16k-38k^2+8k^3-3k^4]/[(1+k)^2 Delta^2].

An independent all-interval positivity certificate uses t=5k. The numerator
of R' is the degree-four Bernstein polynomial on 0<=t<=1 whose coefficients
are `1,9/5,176/75,332/125,1712/625`. The basis is nonnegative and sums to one;
every coefficient is at least one. Hence R'>0 on the physical branch, since
`kc<1/5`. R is continuous there, tends to 1 at k=0, and tends to positive
infinity at kc because its numerator stays positive while Delta tends to zero
from above. It is therefore a bijection from `(0,kc)` to `(1,infinity)`.

For an exact specified ratio r>1, the inverse solves

    r k^3-(5r+3)k^2+(4-5r)k+(r-1)=0,

with exactly one root in the physical interval. This domain restriction is
important: the cubic has one negative root, one physical positive root and
one further positive root outside the branch. The first and last follow by
sign changes at negative infinity, zero, kc and positive infinity; degree
three then exhausts the roots. This is a mathematical inverse of the ideal
central prediction, not a statistical estimator, confidence interval or
observational exclusion criterion without uncertainties and model errors.

Direct series division gives `R=1+k+13k^2+O(k^3)`. More precisely,

    R-(1+k+13k^2)=k^3(69+64k-13k^2)/D_R.

For `0<k<=1/100`, this remainder is positive and less than
`(3500/47)k^3`: its numerator coefficient is below 70 and `D_R>47/50`.
This is a controlled weak-k interval, not a uniform approximation near kc.

The Einstein scalar fraction follows from its action stress tensor:

    Omega_phi,E=(T+2W/Hbar)/3=(4Bx+2Bx)/3=2Bx,
    Omega_rad,E=1-2Bx,
    p_phi,E/rho_phi,E=(4Bx-2Bx)/(4Bx+2Bx)=1/3.

It is not R-1. The old y-only state has `C=1`, `By=k/[2(1+k)]`,
`Hbar=2(1+k)/3`; the same calibrated ratio is exactly 1 while its scalar
fraction is `k/(1+k)>0`. This is a comparison of supplied ideal limits,
not a claim about the actual early universe.

Finally, the full metric is diagonal and C only depends on u. Therefore

    |grad log sqrt(C)|_K^2 = (alpha/F)^2/(J/F^2) = a/J.

At E_x, `J_x=(1+3k)^2/(12k)` gives `g_x=3k(1-k)/(1+3k)`. This is the
dimensionless K-metric norm, not the dimensionful canonical normalization
divided by 2Q. The norm is nonzero even though the derivative of C along the
ideal trajectory is zero. It is an input to scalar response; it is not an
automatically measured PPN or fifth-force parameter of a rolling environment.
The source/mass/mixing/range/time-dependent response remains a separate model.

Planned exact controls are frozen in PROTOCOL_v1.json. They test these
identities, polynomial range/inversion and calibration distinctions with
synthetic rational values. No empirical data or broad background proof is used.
