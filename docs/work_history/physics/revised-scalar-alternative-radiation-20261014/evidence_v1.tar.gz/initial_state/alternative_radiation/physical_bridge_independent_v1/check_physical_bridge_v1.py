#!/usr/bin/env python3
"""Independent action-to-physical-ratio check; no producer imports or reads.

The x-only constant-u branch is a supplied conditional background. This does
not independently certify its full existence/stability or a finite history.
All mathematical controls are exact SymPy expressions/rationals. Decimal
numbers in the inverse records are displays of exact rational brackets.
"""
import datetime
import hashlib
import json
import platform
import sys
import traceback
from pathlib import Path

import sympy as S

STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
ROOT = Path(__file__).resolve().parent
checks = []
records = {}


def test(name, condition, detail=None):
    try:
        value = condition() if callable(condition) else condition
        passed = bool(value)
        row = {"name": name, "pass": passed}
        if detail is not None:
            row["detail"] = detail
        if not passed:
            row["failure"] = "Condition evaluated false"
    except Exception:
        row = {"name": name, "pass": False, "failure": traceback.format_exc()}
    checks.append(row)
    print(("PASS " if row["pass"] else "FAIL ") + name, flush=True)
    if not row["pass"]:
        print(row["failure"], flush=True)


def equal(name, actual, expected):
    residual = S.factor(S.cancel(actual - expected))
    test(name, residual == 0, {"residual": str(residual)})


def reject(name, actual, damaged):
    residual = S.factor(S.cancel(actual - damaged))
    test("damage." + name, residual != 0,
         {"kind": "intentional mathematical candidate, not producer execution",
          "correct_minus_damaged": str(residual)})


def bernstein(poly, variable, degree):
    p = S.Poly(S.expand(poly), variable)
    out = [sum(p.nth(i) * S.binomial(j, i) / S.binomial(degree, i)
               for i in range(j + 1)) for j in range(degree + 1)]
    rebuilt = sum(out[j] * S.binomial(degree, j) * variable**j
                  * (1 - variable)**(degree - j) for j in range(degree + 1))
    return out, rebuilt


def sturm_variations(sequence, variable, point):
    signs = []
    for expression in sequence:
        p = S.Poly(expression, variable)
        if point in (S.oo, -S.oo):
            sign = S.sign(p.LC())
            if point == -S.oo and p.degree() % 2:
                sign = -sign
        else:
            sign = S.sign(expression.subs(variable, point))
        if sign:
            signs.append(int(sign))
    return sum(a != b for a, b in zip(signs, signs[1:])), signs


k, E, x = S.symbols("k E x", positive=True)
Q0, V, rho, U, K, v = S.symbols("Q0 Hv_squared rho_J U K velocity", positive=True)
a = (1-k)*(1+3*k)/4
alpha = S.sqrt(a)
s = (1+k)/(k*(1-3*k))
F = 1+s*E
J = 1+(1-3*a)*s*E
Dfield = 1+S.Rational(2, 3)*(1+k)*x**2  # y=0, before large-x limit
C = (1+s)*E/F
Kuu = J/F**2
Kxx = (1+s)*4*k/(9*F*Dfield)
alpha_B = S.simplify(alpha*E*S.diff(S.log(C), E))
Bx_E = S.factor(S.limit(Kxx*x**2, x, S.oo))
Ex = (1-3*k)/(3*(1+k))
Cx = S.factor(C.subs(E, Ex))
Bx = S.factor(Bx_E.subs(E, Ex))
Jx = S.factor(J.subs(E, Ex))
Delta = 1-6*k+k**2
kc = 3-2*S.sqrt(2)
Q = Q0*(1+k)

equal("action.log_coupling_derivative", alpha_B, alpha/F)
equal("action.large_x_radial_metric", Bx_E, (1+s)*2*k/(3*(1+k)*F))
equal("branch.F", F.subs(E, Ex), (1+3*k)/(3*k))
equal("branch.C", Cx, (1-k)/(1+k))
equal("branch.Bx", Bx, 2*k*(1-k)/((1+k)*(1-3*k)))
equal("branch.J", Jx, (1+3*k)**2/(12*k))
equal("branch.positive_density_factor", 1-2*Bx, Delta/((1+k)*(1-3*k)))
test("domain.kc_between_zero_and_one_fifth", 0 < kc < S.Rational(1, 5))

# Legendre transform the homogeneous scalar action, with its actual kinetic
# normalization. No extra half is silently inserted.
Lscalar = Q*(K*v**2-2*V*U)
rho_scalar = S.diff(Lscalar, v)*v-Lscalar
equal("action.scalar_energy", rho_scalar, Q*K*v**2+2*Q*V*U)
equal("action.scalar_pressure", Lscalar, Q*K*v**2-2*Q*V*U)
T, W, Hbar = S.symbols("T W Hbar")
constraint = (3-T)*Hbar-2*(Cx**2+W)
Urad = k*x**2*E**(-(1-k)/(2*a))/2
equal("action.radial_potential_derivative", x*S.diff(Urad, x), 2*Urad)
q, h, w = S.symbols("q h W_over_Hbar")
lowered_radial = Bx*(3+h)*q+2*w
w_branch = S.solve(lowered_radial.subs({q: -2, h: -2}), w)[0]
equal("action.radial_balance", w_branch, Bx)
Hbar_derived = S.factor(S.solve(constraint.subs({T: 4*Bx, W: w_branch*Hbar}), Hbar)[0])
equal("action.friedmann_radiation_normalization", Hbar_derived, 2*Cx**2/(3*(1-2*Bx)))

# General clock conversion, derived by differentiating a_J=sqrt(C)*a_E and
# dividing by dt_J/dt_E=sqrt(C). Only then impose constant C on this branch.
time = S.symbols("time")
afun = S.Function("a_E")(time)
cfun = S.Function("C")(time)
HJ_general = S.diff(S.sqrt(cfun)*afun, time)/(S.sqrt(cfun)**2*afun)
equal("clock.general_derivative", HJ_general,
      S.diff(afun, time)/(afun*S.sqrt(cfun))+S.diff(cfun, time)/(2*cfun**S.Rational(3, 2)))
equal("clock.constant_C", HJ_general.subs(S.diff(cfun, time), 0),
      S.diff(afun, time)/(afun*S.sqrt(cfun)))
yb2 = rho/(2*Q*V)
HE2 = S.factor(V*yb2*Hbar_derived)
HJ2 = S.factor(HE2/Cx)
equal("clock.physical_H_squared", HJ2, Hbar_derived*rho/(2*Q*Cx))

# Local weak static calibration from the original action, independently of
# the radiation background. This is a stipulated dynamical readout at C=1.
K0 = S.factor(Kuu.subs(E, 1))
ab0 = S.simplify(alpha_B.subs(E, 1))
g0 = S.factor(ab0**2/K0)
equal("vacuum.C", C.subs(E, 1), 1)
equal("vacuum.coupling_norm", g0, k)
r, mu, mass = S.symbols("radius mu mass", positive=True)
source_coefficient = ab0/(2*Q*K0)
du = -source_coefficient*mass*S.exp(-mu*r)/(4*S.pi*r)
equal("vacuum.yukawa_exterior_equation", S.diff(du, r, 2)+2*S.diff(du, r)/r-mu**2*du, 0)
equal("vacuum.yukawa_source_flux", S.limit(4*S.pi*r**2*S.diff(du, r), r, 0), source_coefficient*mass)
Gt = 1/(8*S.pi*Q)
PhiE = -Gt*mass/r
PhiJ = PhiE+ab0*du
PsiJ = PhiE-ab0*du
equal("vacuum.scalar_force_range_factor", S.diff(PhiJ, r)/(Gt*mass/r**2), 1+g0*(1+mu*r)*S.exp(-mu*r))
Gdynamic = S.factor((r**2*S.diff(PhiJ, r)/mass).subs(mu, 0))
equal("vacuum.unsuppressed_dynamic_calibration", Gdynamic, 1/(8*S.pi*Q0))
equal("vacuum.lensing_potential_sum", PhiJ+PsiJ, -2*Gt*mass/r)
test("vacuum.dynamic_and_tensor_distinct_at_positive_k", S.factor(Gdynamic/Gt-1) == k)

HGR2 = (8*S.pi*Gdynamic/3)*rho
R = S.factor(HJ2/HGR2)
R_expected = (1-k)*(1-3*k)/((1+k)*Delta)
equal("ratio.action_to_physical_prediction", R, R_expected)
equal("ratio.excess", R-1, k*(1+8*k-k**2)/((1+k)*Delta))
N = 1+16*k-38*k**2+8*k**3-3*k**4
equal("ratio.derivative", S.diff(R, k), N/((1+k)**2*Delta**2))
t = S.symbols("t")
b, rebuilt = bernstein(N.subs(k, t/5), t, 4)
equal("range.bernstein_reconstruction", rebuilt, N.subs(k, t/5))
test("range.bernstein_coefficients", b == [1, S.Rational(9, 5), S.Rational(176, 75), S.Rational(332, 125), S.Rational(1712, 625)])
test("range.strict_derivative_certificate", all(c >= 1 for c in b))
equal("range.lower_limit", S.limit(R, k, 0, dir="+"), 1)
equal("range.critical_zero_Delta", Delta.subs(k, kc), 0)
test("range.critical_numerator_positive", S.simplify(((1-k)*(1-3*k)).subs(k, kc)) > 0)
test("range.positive_blowup", S.limit(R, k, kc, dir="-") == S.oo)
records["derivative_bernstein_coefficients_on_0_to_one_fifth"] = list(map(str, b))

quadratic = 1+k+13*k**2
rem = S.factor(R-quadratic)
equal("weak_k.series", S.series(R, k, 0, 3).removeO(), quadratic)
equal("weak_k.exact_remainder", rem, k**3*(69+64*k-13*k**2)/((1+k)*Delta))
for label, poly, degree in [
        ("remainder_coefficient_positive", 69+64*k-13*k**2, 2),
        ("remainder_coefficient_below_70", 70-(69+64*k-13*k**2), 2),
        ("denominator_above_47_over_50", (1+k)*Delta-S.Rational(47, 50), 3)]:
    coeffs, rebuilt = bernstein(poly.subs(k, t/100), t, degree)
    equal("weak_k."+label+".reconstruction", rebuilt, poly.subs(k, t/100))
    test("weak_k."+label+".positive_certificate", all(c > 0 for c in coeffs))
    records[label+"_bernstein_coefficients"] = list(map(str, coeffs))
for kv in map(S.Rational, ["1/10000", "1/1000", "1/250", "1/100"]):
    rv = rem.subs(k, kv)
    test("weak_k.rational_bound."+str(kv), 0 < rv < S.Rational(3500, 47)*kv**3)

# Recompute fractions directly from the normalized action stress tensor.
Omega = S.factor((4*Bx+2*w_branch)/3)
Omega_rad = S.factor(2*Cx**2/(3*Hbar_derived))
equal("energy.scalar_fraction", Omega, 2*Bx)
equal("energy.radiation_fraction", Omega_rad, 1-2*Bx)
equal("energy.fractions_sum", Omega+Omega_rad, 1)
equal("energy.scalar_equation_of_state", (4*Bx-2*w_branch)/(4*Bx+2*w_branch), S.Rational(1, 3))
By = k/(2*(1+k))
Hbar_y = S.factor(2/(3*(1-2*By)))
equal("comparison.y_branch_Hbar", Hbar_y, 2*(1+k)/3)
equal("comparison.y_branch_physical_ratio", 3*Hbar_y/(2*(1+k)), 1)
equal("comparison.y_branch_scalar_fraction", 2*By, k/(1+k))
gx = S.factor((alpha_B**2/Kuu).subs(E, Ex))
equal("coupling.full_K_norm", alpha_B**2/Kuu, a/J)
equal("coupling.x_branch_K_norm", gx, 3*k*(1-k)/(1+3*k))

units = {Q0: S.Rational(7, 3), V: S.Rational(5, 11), rho: S.Rational(13, 7)}
rescaled = {Q0: units[Q0]*S.Rational(11, 5), V: units[V]*S.Rational(3, 2), rho: units[rho]*S.Rational(9, 7)}
records["rational_backgrounds"] = []
for kv in map(S.Rational, ["1/97", "2/37", "3/29", "1/6", "37/216"]):
    tag = str(kv)
    test("rational.physical_domain."+tag, 0 < kv < kc)
    test("rational.positive_radiation_fraction."+tag, 0 < Omega_rad.subs(k, kv) < 1)
    test("rational.positive_scalar_fraction."+tag, 0 < Omega.subs(k, kv) < 1)
    test("rational.positive_coupling_norm."+tag, gx.subs(k, kv) > 0)
    hj = HJ2.subs(units).subs(k, kv)
    hgr = HGR2.subs(units).subs(k, kv)
    equal("rational.physical_normalization."+tag, hj/hgr, R.subs(k, kv))
    equal("rational.coherent_units_rescaling."+tag,
          (HJ2/HGR2).subs(rescaled).subs(k, kv), hj/hgr)
    records["rational_backgrounds"].append({"k": tag, "C": str(Cx.subs(k, kv)),
        "H_J_squared": str(hj), "H_GR_squared": str(hgr), "ratio": str(R.subs(k, kv)),
        "Omega_scalar_E": str(Omega.subs(k, kv)), "K_coupling_norm": str(gx.subs(k, kv))})

# Exact inverse. The entire cubic is checked, including inadmissible roots.
ratio = S.symbols("specified_ratio", positive=True)
cubic = ratio*k**3-(5*ratio+3)*k**2+(4-5*ratio)*k+(ratio-1)
equal("inverse.cubic_equivalence", cubic, (ratio-R)*(1+k)*Delta)
upper = S.Rational(171, 1000)
test("inverse.common_bracket_inside_branch", 0 < upper < kc)
test("inverse.common_bracket_covers_all_targets", R.subs(k, upper) > 101)
records["inverse_brackets"] = []
for target in map(S.Rational, ["7/6", "9/4", "5", "17", "101"]):
    expression = cubic.subs(ratio, target)
    sequence = S.sturm(expression, k)
    endpoints = [-S.oo, S.Integer(0), upper, S.oo]
    variations = [sturm_variations(sequence, k, p) for p in endpoints]
    counts = [variations[i][0]-variations[i+1][0] for i in range(3)]
    test("inverse.sturm_three_domain_counts."+str(target), counts == [1, 1, 1])
    lo, hi = S.Integer(0), upper
    for _ in range(100):
        mid = (lo+hi)/2
        if expression.subs(k, mid) > 0:
            lo = mid
        else:
            hi = mid
    test("inverse.bracket_residual_signs."+str(target), expression.subs(k, lo) > 0 and expression.subs(k, hi) <= 0)
    equal("inverse.bracket_width."+str(target), hi-lo, upper/2**100)
    test("inverse.physical_prediction_bracket."+str(target), R.subs(k, lo) < target <= R.subs(k, hi))
    records["inverse_brackets"].append({"target_ratio": str(target),
        "root_counts_negative_physical_extra_positive": counts,
        "sturm_endpoint_signs": [row[1] for row in variations],
        "lower_exact": str(lo), "upper_exact": str(hi),
        "midpoint_decimal_display": str(S.N((lo+hi)/2, 32))})

# These deliberately changed candidate formulas must fail the corresponding
# physical identities. This is independent mathematical sensitivity evidence,
# not a claim of executing the author's test suite or damaged runner copies.
reject("omitted_clock_conversion", R, Cx*R)
equal("damage.omitted_clock_weak_linear_coefficient", S.diff(Cx*R, k).subs(k, 0), -1)
test("damage.omitted_clock_reverses_small_k_direction", (Cx*R).subs(k, S.Rational(1, 97)) < 1 < R.subs(k, S.Rational(1, 97)))
R_tensor_calibrated = S.factor(HJ2/((8*S.pi*Gt/3)*rho))
equal("scope.tensor_calibrated_ratio", R_tensor_calibrated, (1+k)*R)
reject("tensor_calibration_substituted_for_dynamic", R, R_tensor_calibrated)
reject("scalar_exchange_wrong_factor_two", Gdynamic, Gt*(1+2*g0))
reject("scalar_fraction_substituted_for_expansion_excess", R-1, Omega)
test("damage.scalar_fraction_counterexample", (R-1).subs(k, S.Rational(2, 37)) != Omega.subs(k, S.Rational(2, 37)))
reject("weak_series_quadratic_12", quadratic, 1+k+12*k**2)
test("damage.weak_series_quadratic_12_fails_order", S.limit((R-(1+k+12*k**2))/k**2, k, 0) == 1)
reject("zero_directional_derivative_as_zero_full_norm", gx, S.Integer(0))
directional_log_C = S.Integer(0)  # u'=0; C has no x/y dependence
test("scope.zero_branch_C_derivative_nonzero_full_norm", directional_log_C == 0 and gx.subs(k, S.Rational(3, 29)) > 0)
records["unknown_calibration_degeneracy"] = []
target_calibrated = S.Rational(3, 2)
gammas = []
for kv in [S.Rational(1, 97), S.Rational(2, 37)]:
    gamma = S.factor(R.subs(k, kv)/target_calibrated)
    gammas.append(gamma)
    test("scope.free_calibration_positive."+str(kv), gamma > 0)
    equal("scope.free_calibration_same_ratio."+str(kv), R.subs(k, kv)/gamma, target_calibrated)
    records["unknown_calibration_degeneracy"].append({"k": str(kv), "gamma": str(gamma), "ratio": str(target_calibrated)})
test("scope.free_calibration_distinct_parameters", gammas[0] != gammas[1])

failed = sum(not row["pass"] for row in checks)
result = {"schema": "independent-physical-radiation-bridge-v1",
    "started_utc": STARTED, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "environment": {"python": sys.version, "sympy": S.__version__, "platform": platform.platform()},
    "producer_code_or_results_used": False,
    "scope": "Conditional physical bridge and exact rational controls, not full branch stability, finite histories, data or audit.",
    "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "hand_derivation_sha256": hashlib.sha256((ROOT/"HAND_DERIVATION_v1.md").read_bytes()).hexdigest(),
    "protocol_sha256": hashlib.sha256((ROOT/"PROTOCOL_v1.json").read_bytes()).hexdigest(),
    "passed": len(checks)-failed, "failed": failed, "checks": checks, "records": records}
with (ROOT/"RESULTS_v1.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(f"TOTAL {len(checks)-failed} passed; {failed} failed", flush=True)
raise SystemExit(1 if failed else 0)
