#!/usr/bin/env python3
"""Source identity and affected v1-to-v2 text correspondence only."""
import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
worktree = root.parents[6]
rows = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def check(name, passed, detail=None):
    rows.append({"name": name, "pass": bool(passed), "detail": detail})
    print(("PASS " if passed else "FAIL ")+name, flush=True)


original = json.loads((root/"SOURCE_MANIFEST_v1.json").read_text())
binding = json.loads((root/"SOURCE_V2_BINDING_v1.json").read_text())
sources = original["sources"] + [{"original_path": binding["original_path"],
    "snapshot_path": binding["snapshot_path"], "sha256": binding["sha256"], "bytes": binding["bytes"]}]
for row in sources:
    live = (worktree/row["original_path"]).read_bytes()
    snap = (root/row["snapshot_path"]).read_bytes()
    check("source.identity."+row["snapshot_path"],
          live == snap and len(snap) == row["bytes"] and sha(snap) == row["sha256"], row)

v1 = (root/"sources/00_PHYSICAL_RADIATION_BRIDGE_v1.md").read_text()
v2 = (root/"sources/03_PHYSICAL_RADIATION_BRIDGE_v2.md").read_text()
old = """For the stipulated constant vacuum, an unsuppressed weak local readout has
G_vac=1/(8pi Q0). This calibration is CONDITIONAL; actual measured gravity
and actual present cosmology are not shown to equal that vacuum. Comparing
"""
new = """For the stipulated constant vacuum C=1, take an unsuppressed weak
nonrelativistic dynamical-force calibration, with negligible local vacuum
curvature, weak potentials, negligible scalar range suppression and a known
point-source mass (or justified body charge). It then has
G_vac=1/(8pi Q0). This specifies the readout: an ideal lensing calibration
with known mass instead measures the tensor normalization 1/[8pi Q0(1+k)].
This calibration is CONDITIONAL; actual measured gravity and actual present
cosmology are not shown to equal that vacuum. Comparing
"""
tail = """
V2 preserves the equations and adds the independent checker's calibration
clarification: the reference is an unsuppressed dynamical-force readout, not
an arbitrary measurement called gravity. Parent v1 checker results are
reused only for unchanged equations; this is not a newly executed run.
"""
check("correspondence.old_calibration_paragraph_once", v1.count(old) == 1)
check("correspondence.exact_two_affected_spans_only", v1.replace(old, new)+tail == v2)
equations1 = [line for line in v1.splitlines() if line.startswith("    ")]
equations2 = [line for line in v2.splitlines() if line.startswith("    ")]
check("correspondence.displayed_equations_byte_equal", equations1 == equations2, {"displayed_lines": len(equations1)})
check("correspondence.calibration_readout_explicit", all(text in new for text in [
    "vacuum C=1", "nonrelativistic dynamical-force", "local vacuum\ncurvature",
    "weak potentials", "scalar range suppression", "known\npoint-source mass",
    "justified body charge", "lensing calibration", "1/[8pi Q0(1+k)]"]))
check("correspondence.no_new_producer_execution_claim", "not a newly executed run" in tail)
result = {"scope": "Four immutable source/live identities and only the added v2 calibration clarification; no producer computation accessed or rerun.",
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "passed": sum(row["pass"] for row in rows), "failed": sum(not row["pass"] for row in rows),
    "sources": sources, "checks": rows}
with (root/"SOURCE_CORRESPONDENCE_RESULTS_v1.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(f"TOTAL {result['passed']} passed; {result['failed']} failed", flush=True)
raise SystemExit(bool(result["failed"]))
