#!/usr/bin/env python3
"""Only the supplied physical-density symbol correction; no science rerun."""
import datetime
import hashlib
import json
from pathlib import Path
import sympy as S

root = Path(__file__).resolve().parent
worktree = root.parents[6]
binding = json.loads((root/"SOURCE_V3_BINDING_v1.json").read_text())
v2 = (root/"sources/03_PHYSICAL_RADIATION_BRIDGE_v2.md").read_text()
v3 = (root/binding["snapshot_path"]).read_text()
action = (root/"sources/02_COMPLETE_ACTION_NOTE.md").read_text()
rows = []


def check(name, value, detail=None):
    rows.append({"name": name, "pass": bool(value), "detail": detail})
    print(("PASS " if value else "FAIL ")+name, flush=True)


preface = """
Density convention: rho_phys denotes dimensionful physical density. In the
canonical complete-action note rho_J is dimensionless, with
rho_phys=rho_unit rho_J and Rstar=rho_unit/(2Q Hv^2). Consequently
 y_b^2=rho_phys/(2Q Hv^2)=Rstar rho_J.
The earlier same-symbol usage in this route is clarified here; no density
normalization is inferred from observations.
"""
tail = """
This version preserves all equations with the explicit density-symbol
translation above. Earlier source versions and execution receipts remain
unchanged; unchanged calculations are reused, not claimed as new runs.
"""
raw = (root/binding["snapshot_path"]).read_bytes()
check("source.v3_live_snapshot_hash", raw == (worktree/binding["original_path"]).read_bytes()
      and hashlib.sha256(raw).hexdigest() == binding["sha256"] and len(raw) == binding["bytes"])
check("correspondence.inserted_spans_once", v3.count(preface) == 1 and v3.count(tail) == 1)
projected = v3.replace(preface, "").replace(tail, "").replace("rho_phys", "rho_J")
check("correspondence.only_density_rename_and_explicit_version_spans", projected == v2)
check("correspondence.all_displayed_equations_after_density_rename",
      [line for line in v2.splitlines() if line.startswith("    ")]
      == [line.replace("rho_phys", "rho_J") for line in v3.splitlines() if line.startswith("    ")])
check("correspondence.canonical_density_unit_premise", "write rho_J and P_J for physical densities divided\nby that unit" in action
      and "Rstar=rho_unit/[2Q(k)Hv^2]" in action)
rho_unit, rho_j, Q, V, C, Hbar, Q0, k = S.symbols("rho_unit rho_J Q Hv_squared C Hbar Q0 k", positive=True)
rho_phys = rho_unit*rho_j
Rstar = rho_unit/(2*Q*V)
check("units.y_b_normalization_identity", S.cancel(rho_phys/(2*Q*V)-Rstar*rho_j) == 0)
ratio_translated = (Hbar*rho_phys/(2*Q0*(1+k)*C))/(rho_phys/(3*Q0))
check("units.physical_ratio_unchanged_by_density_unit", S.cancel(ratio_translated-3*Hbar/(2*(1+k)*C)) == 0)
check("correspondence.reuse_not_new_execution", "unchanged calculations are reused, not claimed as new runs" in tail)
result = {"scope": "Narrow bridge-v3 density notation/source correspondence and exact unit cancellation only; no primary mathematics or producer rerun.",
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_binding": binding,
    "passed": sum(row["pass"] for row in rows), "failed": sum(not row["pass"] for row in rows), "checks": rows}
with (root/"SOURCE_V3_CORRESPONDENCE_RESULTS_v1.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(f"TOTAL {result['passed']} passed; {result['failed']} failed", flush=True)
raise SystemExit(bool(result["failed"]))
