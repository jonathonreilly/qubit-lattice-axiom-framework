#!/usr/bin/env python3
"""Narrow, domain-justified repair of one CAS representation failure.

Preserves the original 124/1 run. This is neither a full rerun nor a weakening
of the derivative identity: it proves that exact identity on the full stated
0<k<1/3 action domain by a positive rational parameterization.
"""
import datetime
import hashlib
import json
from pathlib import Path
import sympy as S

root = Path(__file__).resolve().parent
k, E, z = S.symbols("k E z", positive=True)
a = (1-k)*(1+3*k)/4
alpha = S.sqrt(a)
s = (1+k)/(k*(1-3*k))
F = 1+s*E
C = (1+s)*E/F
raw_derivative = alpha*E*S.diff(S.log(C), E)
original_simplified = S.simplify(raw_derivative)
expected = alpha/F
original_residual = S.factor(S.cancel(original_simplified-expected))
parameterization = z/(3*(1+z))
rows = []


def check(name, value, detail=None):
    passed = bool(value)
    rows.append({"name": name, "pass": passed, "detail": detail})
    print(("PASS " if passed else "FAIL ")+name, flush=True)


main = json.loads((root/"RESULTS_v1.json").read_text())
failed_names = [row["name"] for row in main["checks"] if not row["pass"]]
check("original_failure_is_exactly_the_logged_identity",
      main["passed"] == 124 and main["failed"] == 1 and failed_names == ["action.log_coupling_derivative"])
check("original_representation_failure_reproduced", original_residual != 0, str(original_residual))
check("derivative_divided_by_nonzero_alpha_is_exact",
      S.factor(S.cancel(raw_derivative/alpha-1/F)) == 0)
check("two_radicands_are_identical", S.expand((1-k)*(1+3*k)-(-3*k**2+2*k+1)) == 0)
check("positive_parameterization_stays_in_action_domain",
      parameterization.is_positive and S.simplify(1-3*parameterization) == 1/(1+z))
check("parameterization_covers_entire_open_action_domain",
      S.simplify(parameterization.subs(z, 3*k/(1-3*k))-k) == 0,
      "For every 0<k<1/3, z=3k/(1-3k)>0; conversely positive z gives 0<k<1/3.")
normalized = S.factor(S.simplify(original_residual.subs(k, parameterization)))
check("original_failed_identity_after_domain_justified_normalization", normalized == 0, str(normalized))
check("damaged_factor_two_still_detected", S.factor(S.cancel(raw_derivative/alpha-2/F)) != 0)
result = {"scope": "Only the one preserved original CAS equality failure; no main-suite rerun.",
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "original_result_sha256": hashlib.sha256((root/"RESULTS_v1.json").read_bytes()).hexdigest(),
    "repair_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "passed": sum(row["pass"] for row in rows), "failed": sum(not row["pass"] for row in rows), "checks": rows}
with (root/"REPAIR_RESULTS_v1.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(f"TOTAL {result['passed']} passed; {result['failed']} failed", flush=True)
raise SystemExit(bool(result["failed"]))
