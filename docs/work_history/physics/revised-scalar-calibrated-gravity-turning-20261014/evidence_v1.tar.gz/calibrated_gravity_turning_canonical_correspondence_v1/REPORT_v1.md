# Staged calibrated-gravity turning correspondence

The corrected staged note and runner preserve the checked turning-point argument and its complete executed control. One new introductory phrase required correction: the principal force has a strict maximum along the coupling coordinate, while it is unchanged along transverse scalar coordinates. The author made that one-line correction; the original and corrected bytes, finding and exact diff are preserved. No science equation, runner, fixture or acceptance threshold changed.

This unit is a focused post-seal source and packaging check. It reuses the completed independent mathematics; it is not another blind derivation, a formal audit or authority to publish. /root remains scientific author. The seal applies to the staged note with SHA72652a3 and staged runner with SHA4d24ec2, not a live canonical cache, commit, recovery archive or the separately prepared metadata-formatting copy.

## Fixed identities and access sequence

| Artifact | SHA256 |
| --- | --- |
| Final staged note | `72652a3bb14b31064fd324a88d3f4f46e011c0951cf7d87a138a7ab21cbb8e38` |
| Original staged note before coordinate qualification | `d842a76ad2669130595d4e2bd529ae19bf4e18085b890aa34ad4cc140fc25e5b` |
| Staged runner | `4d24ec2d014f6ee37af35caa7ce91dc8882ec23bb68aafe65f5048a6e0ae8c41` |
| Author hand DERIVATION_v2.md | `02e50e44f4867821ff82e614c3ba2cfa8540ca391b297ff4fcfdea6dd5e2ce87` |
| Original producer check_turning_v2.py | `1298d7572c31711f3bb757ad3304ab4d941597f7e108a3ec3554d36a3d23fd9c` |
| Original producer check_turning_v1.py | `70d85b2bd02a7caaffd5be4926e2c9a379bf11c5a9c71da05801a672ac5510a8` |
| Reused independent REPORT_v2.md | `15d202430e358bd67f60356068f7c23f8d33a035cd572d6e6781aae4c9e7191f` |
| Reused independent MANIFEST_v1.json | `ca996c684241246053fe919d2050a4e6499e219f3a062152bd69e318f41a86c6` |
| Reused independent RECEIPT_v1.json | `42cf4a396dd6e9dea6e3814d532ba74b4faede10499384d51401e11d8c24a198` |

The independent source receipt was sealed before this unit opened producer implementations or output files. The complete prior report was read; all 78 manifest payloads and nine original/snapshot source pairs were verified again, and the entire prior directory was copied without altering it. Its original 287/0 mathematical control, five actual damaged-program failures, 29/0 affected-v2 proof correspondence and historical records remain intact. The parent precision-run aggregate was an unverified late exposure in that prior seal. This separate unit now inspects the actual producer code, outputs and repair history and records that different access role explicitly.

Four source freezes contain 134 exact version bindings from 133 distinct original paths. The one superseded live version is the old staged note; its original bytes are recoverable both here and in the parent's NOTE_before_coordinate_scope_v1.md. All other frozen source versions match their current originals. SOURCE_DISPOSITIONS_v1.json provides every original hash, recovery path/hash and current final path/hash. Intended docs/scripts destinations are marked unverified future destinations rather than silently treated as installed artifacts.

The permitted scope includes the hand/protocol, complete original and staged producer outputs, precision history, three staged damages, declared action/local-response inputs and the reused independent seal. Raw-root figures and unrelated work were not read. No primary paper was fetched. No Git, runtime, lock, audit or parent file was changed.

## Proof and prose correspondence

The entire final hand body occurs exactly once in the staged note after heading demotion only. Its five sections retain the full domain, force normalization, elimination, canonical derivatives, physical Jordan clock, inverse admissibility and finite-window proof. The entire observational-context source is also preserved after heading demotion. The added material declares the action and local-response notes as premises and describes finite controls and open measurement assumptions.

The supplied action note remains SHA`39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`; the local-response note remains SHA`b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68`. Both match the prior independent source seal. The staged runner declares those two inputs and its future canonical note path. Its note input currently maps to the staged bytes; no live-input/cache-freshness claim is made here.

The new wrapper phrase “strict field-space maximum” was stronger than the checked result. At fixed u the principal force is independent of x and y, so the maximum is not strict in all scalar directions. Replacing it with “strict maximum along the coupling coordinate” restores the proved scope. The exact one-line diff recovers the corrected note, and the hand, executable and outputs are unchanged. The prior independent report had already stated this restriction.

The finite-window coefficient is unchanged. The hand and staged producer use full width T on [-T/2,T/2], while the independent source check used a half width H. T=2H converts the independent coefficient -36v^3 H^2/[5(1+k)^2 g^2] to the staged -9v^3 T^2/[5(1+k)^2 g^2]. The remainder bound and the distinction between a q-linear trajectory and an exactly even force history remain explicit. These are prescribed diagnostic curves, not selected or solved histories.

The note does not identify a measured orbital G with the principal coefficient, fix Q0, select the ambient field or crossing phase, bound arbitrarily rapid motion, establish screening/range corrections or claim a fit to LLR. Its quoted observational number is carried from the parent's explicitly exposed abstract-level context and access record. This correspondence check verifies the prose/data role, not the primary paper, its likelihood or a new observed holdout.

## Exact code port and complete results

The full selected scientific AST from check_turning_v2.py equals the staged AST after only renaming run to check_turning. Imports, four control constants and the complete function body match. The independently reconstructed AST hash is `826e49746996322e3d172a1ab5c17b2d913541a509ee2e395c20c29f34415ecf`, matching the declared lineage. The additional nodes are the identified wrapper imports, metadata, main function and main guard. AST reformatting removes comments but changes no scientific expression or control.

Every scientific JSON field in the staged turning unit equals the original baseline_v2 JSON. The only excluded field is checker_sha256, whose two actual file identities were separately checked. This comparison includes all 115 check rows and details, all 15 original-coordinate field cases, all 12 near-vacuum records, all six window records and the scope string. No rounded table, aggregate count or selected subset substitutes for full equality. The explicit profile JSON equals the outer unit; the entire staged stdout bytes equal the saved full wrapper output, and the captured unit stdout equals the original v2 summary.

The 115 controls comprise 13 exact symbolic rows, 75 field-case rows, six two-sided convergence rows, three large-deficit rejection rows and 18 finite-window rows. The fixture sets are k={1/100,1/10,3/10}, five u values per k, two signs and magnitudes near the vacuum, and two chosen q velocities per k. They are exposed synthetic development controls. The general domain and limiting conclusions remain hand arguments, checked independently in the prior seal; this finite control set is not an exhaustive observational inverse or history test.

The producer's squared symbolic derivative identity is supplemented by signed raw-coordinate numerical checks; the independent sealed derivation also checks the signed identity from the metric. The producer computes inverse roots from forward synthetic forces and retains the pre-existing roundoff floor max(0,1-G/Gref). That is not an observed-data inverse prescription. The hand's excluded-endpoint and two-branch restrictions, and the independent exact negative/zero/threshold fixtures, remain necessary.

## Preserved precision failure

The first actual producer run returned 114/1 with exit 1. Its sole failed row is inverse_recovers_original at k=3/10,u=0. Direct decimal subtraction of the complete saved root and q strings gives a nearest-root residual of `1.887660696420815148882225982364919782477E-41`, larger than the unchanged 1e-55 criterion. The square-root inverse at its repeated root amplifies the small forward rounding error, consistently with the hand conditioning result.

The exact source diff is only mp.mp.dps=80 to mp.mp.dps=130. All formulas, fixture choices, controls, the existing roundoff floor and acceptance text remain identical. The second actual run returned 115/0 with exit 0; its saved vacuum roots and q are all 0.3, and its complete result is the one ported to the staged wrapper. Original source files, start/end command records, full profiles and both stdout/stderr sets are preserved. This is an actual precision repair, not an originally clean 115-control execution, and no rerun was performed by this correspondence unit.

## Actual damaged staged programs

All three complete staged altered programs differ from the final runner by one literal assignment only. Their exact sources, independently reconstructed diffs, execution records, full JSON, profile JSON and raw streams are bound.

| Actual alteration | Passed / failed | Example failed witness |
| --- | ---: | --- |
| SCALAR_FORCE_FACTOR: 1 to 0 | 59 / 56 | calibrated_square_deficit |
| CANONICAL_FACTOR: 1 to 2 | 101 / 14 | vacuum_canonical_curvature |
| ACCEPT_ALL_ROOTS: False to True | 110 / 5 | large_deficit_root_rejection_0.01 |

Every child returned exit 1, completed all 115 named rows in the original order and had empty stderr. The full outer JSON equals its raw stdout; its profile equals its embedded unit; the captured summary retains every failed row. The actual failures are mathematical witness failures, not parser errors, missing imports or intentionally substituted exit statuses. These records were inspected, not rerun. The independent original five damaged-program controls are separately retained within the reused science seal and are not conflated with these three staged controls.

## Actual wrapper-only process controls

The new main wrapper was executed in nine labeled subprocess cases after check_turning was replaced with a deliberately artificial stub. The unchanged scientific function was never invoked. Temporary directories were redirected under this owned evidence folder. The controls verify complete arbitrary unit payload retention, captured stdout, aggregate counts, current runner identity, raw stdout/output equality, profile retention, temporary cleanup and process exit propagation.

| Wrapper case | Actual exit | Expected behavior |
| --- | ---: | --- |
| Successful unit, explicit profiles/output | 0 | Full unit and streams preserved |
| Failed unit, explicit profiles/output | 1 | Full failed unit preserved |
| Successful unit, temporary profiles | 0 | Full output retained; temporary profile removed |
| Failed unit, temporary profiles | 1 | Full failed output retained; temporary profile removed |
| Return value disagrees with unit failed count | 1 | Assertion propagates |
| Existing explicit profiles path | 1 | Existing sentinel preserved; stub not called |
| Existing output file | 1 | Existing output preserved; completed profile remains |
| Missing unit result | 1 | FileNotFoundError propagates |
| Malformed unit result | 1 | JSONDecodeError propagates |

The wrapper suite returned 41/0 assertions. Its seven nonzero child exits are expected negative cases and remain fully recorded, including the five error tracebacks. They are not scientific-control failures or additional successful science runs. Existing-output rejection happens after the unit execution, whereas existing-profile rejection happens before it; the report preserves that actual behavior rather than claiming a stronger fail-fast guarantee.

## Evidence boundary and final scope

The full source/AST/output/failure correspondence execution returned 429/0. These are packaging and identity checks, not 429 new mathematical tests. The separately recorded wrapper process suite returned 41/0. There was no unexpected checker failure or repair in this correspondence unit. An initial combined JSON display exceeded the tool output budget; complete source bytes were already frozen, then all rows were inspected using the clearly labeled display-only shortened view while full equality used the unmodified JSON.

The author subsequently reported a separate claim-type metadata formatting issue: Status and Claim type appeared on one line. That formatting copy and its independent format review are outside this seal. The note reviewed here remains the actual staged SHA72652a3 version. A later delivery check must bind any formatted copy, live declared inputs, actual canonical cache and committed recovery archive separately. No current stage assertion is presented as their verification.

The original stronger wording and its correction are both recoverable. The supplied science seal remains immutable. Within the corrected staged science scope, no further source or executable correction was identified. The exact force turning identity and its conditional inverse interpretation remain distinct from a measured-gravity completion, a physical trajectory selection or agreement with temporal gravity data.
