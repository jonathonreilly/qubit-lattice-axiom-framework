#!/usr/bin/env python3
"""Compare frozen artifacts in full; never execute a scientific checker."""
from pathlib import Path
from decimal import Decimal, localcontext
import ast, copy, datetime, difflib, hashlib, json, re

O=Path(__file__).resolve().parent
P=O/'snapshots/calibrated_gravity_turning_packaging'
U=O/'snapshots/rolling_local_response/calibrated_gravity_turning_v1'
C=O/'coordinate_scope_v2'
note_name='EXPONENTIAL_SCALAR_CALIBRATED_GRAVITY_TURNING_BOUNDED_THEOREM_NOTE_2026-10-14.md'
runner_name='exponential_scalar_calibrated_gravity_turning_check.py'
checks=[]; data={}
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sha_text(s):return hashlib.sha256(s.encode()).hexdigest()
def rd(p):return json.loads(p.read_text())
def ck(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
def dump(n):return ast.dump(n,include_attributes=False)
def wr(n,d):
 with (O/n).open('x') as f:json.dump(d,f,indent=2);f.write('\n')

source_pairs=sum([rd(O/f'SOURCE_FREEZE_v{i}.json')['source_pairs'] for i in range(1,5)],[])
historical=[]
for r in source_pairs:
 p=Path(r['snapshot_path']); ck('snapshot:'+str(p.relative_to(O)),sh(p)==r['sha256'] and p.stat().st_size==r['bytes'])
 live=Path(r['original_path'])
 if sh(live)!=r['sha256']:
  historical.append(r)
  ck('historical_old_stage_recovery',live.name==note_name and r['sha256']=='d842a76ad2669130595d4e2bd529ae19bf4e18085b890aa34ad4cc140fc25e5b' and sh(C/'NOTE_before_coordinate_scope_v1.md')==r['sha256'] and sh(live)=='72652a3bb14b31064fd324a88d3f4f46e011c0951cf7d87a138a7ab21cbb8e38')
 else:ck('current:'+str(p.relative_to(O)),live.stat().st_size==r['bytes'])
ck('single_historical_source_version',len(historical)==1)

prior=rd(U/'independent_v1/RECEIPT_v1.json')
ck('prior_receipt_exact',sh(U/'independent_v1/RECEIPT_v1.json')=='42cf4a396dd6e9dea6e3814d532ba74b4faede10499384d51401e11d8c24a198')
ck('prior_report_exact',sh(U/'independent_v1/REPORT_v2.md')==prior['report']['sha256']=='15d202430e358bd67f60356068f7c23f8d33a035cd572d6e6781aae4c9e7191f')
ck('prior_manifest_exact',sh(U/'independent_v1/MANIFEST_v1.json')==prior['manifest']['sha256']=='ca996c684241246053fe919d2050a4e6499e219f3a062152bd69e318f41a86c6')
pm=rd(U/'independent_v1/MANIFEST_v1.json')
ck('prior_78_artifacts',len(pm['artifacts'])==pm['artifact_count']==78)
for r in pm['artifacts']:
 p=U/'independent_v1'/r['path'];live=Path(prior['write_root'])/r['path']
 ck('prior_payload:'+r['path'],sh(p)==sh(live)==r['sha256'] and p.stat().st_size==r['bytes'])
for r in prior['source_pairs']:
 ck('prior_live_source:'+Path(r['original_path']).name,sh(Path(r['original_path']))==sh(Path(r['recovery']))==r['sha256'])

hand=(U/'DERIVATION_v2.md').read_text(); context=(U/'OBSERVATIONAL_CONTEXT_v1.md').read_text()
oldnote=(P/'staged'/note_name).read_text();newnote=(C/'staged'/note_name).read_text()
demoted='\n'.join('#'+s if s.startswith('#') else s for s in hand.split('\n'))
demoted_context='\n'.join('##'+s if s.startswith('#') else s for s in context.split('\n'))
ck('whole_hand_demoted_only',newnote.count(demoted)==1)
ck('whole_observational_context_demoted_only',newnote.count(demoted_context)==1)
oldword='Within that regime the total attraction has a strict field-space maximum,'
newword='Within that regime the total attraction has a strict maximum along the coupling coordinate,'
ck('only_coordinate_scope_prose_change',oldnote.replace(oldword,newword)==newnote and oldnote.count(oldword)==1)
ck('exact_coordinate_scope_diff',''.join(difflib.unified_diff(oldnote.splitlines(True),newnote.splitlines(True),fromfile='NOTE_v1',tofile='NOTE_v2'))==(C/'COORDINATE_SCOPE_v2.diff').read_text())
ck('old_note_parent_recovery',oldnote==(C/'NOTE_before_coordinate_scope_v1.md').read_text())
lineage=rd(C/'CANONICAL_LINEAGE_v2.json')
ck('final_note_lineage',lineage['note_sha256']==sh(C/'staged'/note_name)=='72652a3bb14b31064fd324a88d3f4f46e011c0951cf7d87a138a7ab21cbb8e38')
ck('final_runner_lineage',lineage['runner_sha256']==sh(P/'staged'/runner_name)=='4d24ec2d014f6ee37af35caa7ce91dc8882ec23bb68aafe65f5048a6e0ae8c41')
ck('final_hand_lineage',lineage['hand']['sha256']==sh(U/'DERIVATION_v2.md'))

orig=(U/'check_turning_v2.py').read_text();stage=(P/'staged'/runner_name).read_text()
class Rename(ast.NodeTransformer):
 def visit_FunctionDef(self,n):
  n=self.generic_visit(n)
  if n.name=='run':n.name='check_turning'
  return n
 def visit_Name(self,n):
  if n.id=='run':n.id='check_turning'
  return n
mod=ast.parse(orig);mod.body=[n for n in mod.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))];mod=Rename().visit(mod)
stage_mod=ast.parse(stage)
ck('entire_scientific_ast_port',dump(ast.Module(body=stage_mod.body[6:15],type_ignores=[]))==dump(mod))
ck('exact_declared_transformed_ast_hash',sha_text(dump(mod))==lineage['code_sources'][0]['transformed_ast_sha256'])
ck('exact_original_checker_identity',sh(U/'check_turning_v2.py')==lineage['code_sources'][0]['sha256'])
ck('only_new_wrapper_nodes',len(stage_mod.body)==17 and isinstance(stage_mod.body[15],ast.FunctionDef) and stage_mod.body[15].name=='main' and isinstance(stage_mod.body[16],ast.If))
inputs=ast.literal_eval(stage_mod.body[5].value)
ck('declared_three_inputs',inputs==['docs/'+note_name,'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md'])
ck('declared_timeout',ast.literal_eval(stage_mod.body[4].value)==120)
data['transformed_ast_sha256']=sha_text(dump(mod))
data['declared_inputs']=inputs

v1=(U/'check_turning_v1.py').read_text()
ck('precision_only_byte_change',v1.replace('mp.mp.dps=80;','mp.mp.dps=130;')==orig and v1.count('mp.mp.dps=80;')==1)
ck('precision_diff_exact',''.join(difflib.unified_diff(v1.splitlines(True),orig.splitlines(True),fromfile='v1',tofile='v2'))==(U/'PRECISION_REPAIR_v2.diff').read_text())
ck('acceptance_unchanged',v1.count("tol=mp.mpf('1e-55')")==orig.count("tol=mp.mpf('1e-55')")==1)
repair=rd(U/'PRECISION_FAILURE_AND_REPAIR_v2.json')
ck('precision_record_hashes',repair['original_sha256']==sh(U/'check_turning_v1.py') and repair['corrected_sha256']==sh(U/'check_turning_v2.py'))
old=rd(U/'baseline_v1/RESULTS.json');new=rd(U/'baseline_v2/RESULTS.json');packed=rd(P/'STAGED_RESULTS_v1.json');unit=packed['units']['turning']
for label,d,path,expected in [('original_v1',old,U/'check_turning_v1.py',(114,1)),('original_v2',new,U/'check_turning_v2.py',(115,0)),('staged',unit,P/'staged'/runner_name,(115,0))]:
 ck('actual_counts:'+label,(d['passed'],d['failed'])==expected and len(d['checks'])==115 and sum(c['passed'] for c in d['checks'])==d['passed'] and sum(not c['passed'] for c in d['checks'])==d['failed'])
 ck('actual_identity:'+label,d['checker_sha256']==sh(path))
 ck('complete_tables:'+label,len(d['cases'])==15 and len(d['canonical_near_vacuum'])==12 and len(d['synthetic_windows'])==6)
for key in new:
 if key!='checker_sha256':ck('complete_unit_field:'+key,new[key]==unit[key])
ck('only_identity_field_excluded',set(new)==set(unit))
ck('staged_profile_unit_exact',rd(P/'profiles_v1/turning/RESULTS.json')==unit)
ck('staged_full_stdout_exact',(P/'STAGED_stdout_v1.txt').read_bytes()==(P/'STAGED_RESULTS_v1.json').read_bytes())
ck('staged_captured_summary_exact',packed['unit_stdout']['turning']==(U/'stdout_v2.txt').read_text())
ck('staged_outer_identity_and_counts',packed['checker_sha256']==sh(P/'staged'/runner_name) and (packed['passed'],packed['failed'])==(115,0))
ck('staged_exit_empty_stderr',rd(P/'STAGED_RUN_v1.json')['returncode']==0 and (P/'STAGED_stderr_v1.txt').read_bytes()==b'')
for version in [1,2]:
 rr=rd(U/f'RUN_v{version}.json');start=rd(U/f'RUN_STARTED_v{version}.json');base=old if version==1 else new
 ck('original_command_identity:'+str(version),rr['args']==start['args'] and rr['checker_sha256']==start['checker_sha256']==base['checker_sha256'] and rr['exit_code']==(1 if version==1 else 0))
 sm=rd(U/f'stdout_v{version}.txt')
 ck('original_summary_and_stderr:'+str(version),sm=={'passed':base['passed'],'failed':base['failed'],'cases':15,'failed_checks':[r for r in base['checks'] if not r['passed']]} and (U/f'stderr_v{version}.txt').read_bytes()==b'')
bad=[r for r in old['checks'] if not r['passed']]
ck('single_failed_original_inverse_row',len(bad)==1 and bad[0]['name'].startswith('inverse_recovers_original_') and "mpf('0.0')" in bad[0]['name'] and '0.2999999' in bad[0]['name'])
with localcontext() as ctx:
 ctx.prec=180
 oc=next(c for c in old['cases'] if Decimal(c['k'])==Decimal('.3') and Decimal(c['u'])==0)
 nc=next(c for c in new['cases'] if Decimal(c['k'])==Decimal('.3') and Decimal(c['u'])==0)
 before=min(abs(Decimal(x)-Decimal(oc['q'])) for x in oc['admissible_roots'])
 after=min(abs(Decimal(x)-Decimal(nc['q'])) for x in nc['admissible_roots'])
 ck('saved_failed_residual_exceeds_same_tolerance',before>Decimal('1e-55'))
 ck('saved_repaired_residual_below_same_tolerance',after<Decimal('1e-55'))
 data['precision_failure_saved_residuals']={'original':str(before),'repaired':str(after),'unchanged_tolerance':'1e-55','method':'Decimal subtraction of saved complete root data; not a science rerun.'}

executions=rd(P/'damages_v1/EXECUTIONS_v1.json')
specs={'missing_scalar_force':('SCALAR_FORCE_FACTOR = 1','SCALAR_FORCE_FACTOR = 0',(59,56),'calibrated_square_deficit'),'wrong_canonical':('CANONICAL_FACTOR = 1','CANONICAL_FACTOR = 2',(101,14),'vacuum_canonical_curvature'),'inverse_domain':('ACCEPT_ALL_ROOTS = False','ACCEPT_ALL_ROOTS = True',(110,5),'large_deficit_root_rejection_0.01')}
damage_records=[]
for ex in executions:
 name=Path(ex['args'][1]).stem;oldstr,newstr,expected,witness=specs[name]
 script=P/'damages_v1'/f'{name}.py';body=script.read_text();d=rd(P/'damages_v1'/f'{name}_RESULTS.json');du=d['units']['turning']
 ck('actual_single_damage:'+name,stage.count(oldstr)==1 and stage.replace(oldstr,newstr)==body)
 diff=''.join(difflib.unified_diff(stage.splitlines(True),body.splitlines(True),fromfile=runner_name,tofile=name+'.py'))
 diffpath=O/'actual_damage_diffs'/f'{name}.diff';diffpath.parent.mkdir(exist_ok=True)
 with diffpath.open('x') as f:f.write(diff)
 ck('actual_damage_identity:'+name,sh(script)==ex['source_sha256']==d['checker_sha256']==du['checker_sha256'])
 ck('actual_damage_counts_exit:'+name,ex['returncode']==1 and (ex['passed'],ex['failed'])==expected==(d['passed'],d['failed'])==(du['passed'],du['failed']) and len(du['checks'])==115)
 ck('actual_damage_witness:'+name,any(r['name']==witness and not r['passed'] for r in du['checks']))
 ck('actual_damage_all_checks_preserved:'+name,[r['name'] for r in du['checks']]==[r['name'] for r in unit['checks']])
 ck('actual_damage_profile_and_streams:'+name,rd(P/'damages_v1'/f'{name}_profiles/turning/RESULTS.json')==du and (P/'damages_v1'/f'{name}_stdout.txt').read_bytes()==(P/'damages_v1'/f'{name}_RESULTS.json').read_bytes() and (P/'damages_v1'/f'{name}_stderr.txt').read_bytes()==b'')
 captured=json.loads(d['unit_stdout']['turning'])
 ck('actual_damage_captured_summary:'+name,captured=={'passed':du['passed'],'failed':du['failed'],'cases':15,'failed_checks':[r for r in du['checks'] if not r['passed']]})
 damage_records.append({'name':name,'passed':du['passed'],'failed':du['failed'],'source_sha256':sh(script),'witness':witness,'all_failed_rows':[r for r in du['checks'] if not r['passed']]})
ck('exactly_three_actual_damages',set(specs)=={Path(e['args'][1]).stem for e in executions})
data['actual_damages']=damage_records
data['source_version_count']=len(source_pairs);data['unique_original_paths']=len({r['original_path'] for r in source_pairs})
data['prior_independent_seal']={'receipt_sha256':sh(U/'independent_v1/RECEIPT_v1.json'),'artifact_count':78,'source_pairs':9}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Full frozen source/output/AST correspondence and preserved failures, not a scientific rerun or formal audit.','source_sha256':sh(Path(__file__)),'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'data':data}
wr('CORRESPONDENCE_RESULTS_v1.json',result)
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':[r for r in checks if not r['passed']],'data_summary':{'source_versions':len(source_pairs),'unique_paths':data['unique_original_paths'],'actual_damage_counts':[[r['name'],r['passed'],r['failed']] for r in damage_records]}},indent=2))
raise SystemExit(int(result['failed']!=0))
