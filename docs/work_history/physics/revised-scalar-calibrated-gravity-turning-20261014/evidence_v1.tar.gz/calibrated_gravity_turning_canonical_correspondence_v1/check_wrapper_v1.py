#!/usr/bin/env python3
"""Labeled process controls of the actual wrapper; scientific function never called."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
O=Path(__file__).resolve().parent
root=O/'wrapper_controls_v1';root.mkdir(exist_ok=False)
source=O/'snapshots/calibrated_gravity_turning_packaging/staged/exponential_scalar_calibrated_gravity_turning_check.py'
harness=O/'wrapper_stub_harness_v1.py'
checks=[];executions=[]
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,b,d=None):checks.append({'name':n,'passed':bool(b),'detail':d})
modes=['success_explicit','failed_explicit','success_temporary','failed_temporary','return_mismatch','existing_profiles','existing_out','missing_result','malformed_result']
for mode in modes:
    case=root/mode;case.mkdir()
    sentinel=b'PRESERVED existing path sentinel\n'
    if mode=='existing_profiles':
        (case/'profiles').mkdir();(case/'profiles/SENTINEL.txt').write_bytes(sentinel)
    if mode=='existing_out':(case/'OUTPUT.json').write_bytes(sentinel)
    args=[sys.executable,str(harness),str(source),str(case),mode]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
    proc=subprocess.run(args,cwd=O,env=env,capture_output=True)
    end=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (case/'STDOUT.txt').write_bytes(proc.stdout);(case/'STDERR.txt').write_bytes(proc.stderr)
    rec={'argv':args,'cwd':str(O),'started_utc':start,'ended_utc':end,'elapsed_seconds':time.monotonic()-tick,'exit_code':proc.returncode,'source_sha256':sh(source),'harness_sha256':sh(harness),'environment_overrides':{'PYTHONDONTWRITEBYTECODE':'1'},'science_executed':False}
    (case/'EXECUTION.json').write_text(json.dumps(rec,indent=2)+'\n');executions.append({'mode':mode,**rec})
    ck('exit:'+mode,proc.returncode==(0 if mode.startswith('success') else 1))
    if mode in {'success_explicit','failed_explicit','success_temporary','failed_temporary'}:
        ck('normal_empty_stderr:'+mode,proc.stderr==b'')
        outer=json.loads(proc.stdout);call=json.loads((case/'CALL.json').read_text())
        ck('complete_unit_preserved:'+mode,outer['units']=={'turning':call['payload']})
        ck('captured_stdout_preserved:'+mode,outer['unit_stdout']=={'turning':call['stdout']})
        ck('counts_and_current_identity:'+mode,outer['passed']==3 and outer['failed']==call['payload']['failed'] and outer['checker_sha256']==sh(source))
        if mode.endswith('explicit'):
            ck('stdout_out_bytes:'+mode,(case/'OUTPUT.json').read_bytes()==proc.stdout)
            ck('explicit_profile_retained:'+mode,json.loads((case/'profiles/turning/RESULTS.json').read_text())==call['payload'])
        else:
            ck('temporary_cleaned:'+mode,not Path(call['out']).parent.exists() and not (case/'OUTPUT.json').exists())
    else:
        ck('error_not_masked:'+mode,proc.stderr!=b'' and proc.stdout==b'')
        if mode=='existing_profiles':
            ck('existing_profile_preserved',not (case/'CALL.json').exists() and (case/'profiles/SENTINEL.txt').read_bytes()==sentinel and not (case/'OUTPUT.json').exists())
        elif mode=='existing_out':
            ck('existing_output_preserved',(case/'OUTPUT.json').read_bytes()==sentinel and (case/'CALL.json').exists())
        elif mode=='return_mismatch':ck('return_mismatch_assertion',b'AssertionError' in proc.stderr and (case/'CALL.json').exists() and not (case/'OUTPUT.json').exists())
        elif mode=='missing_result':ck('missing_file_error',b'FileNotFoundError' in proc.stderr and (case/'CALL.json').exists())
        elif mode=='malformed_result':ck('malformed_json_error',b'JSONDecodeError' in proc.stderr and (case/'CALL.json').exists())
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Wrapper process behavior only. Every scientific function invocation replaced with labeled stub before main. No scientific rerun.','source_sha256':sh(Path(__file__)),'harness_sha256':sh(harness),'staged_runner_sha256':sh(source),'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'executions':executions}
with (O/'WRAPPER_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':[r for r in checks if not r['passed']],'process_exit_codes':[[r['mode'],r['exit_code']] for r in executions]},indent=2))
raise SystemExit(int(result['failed']!=0))
