# The calibrated gravity turning point

Scientific author: /root. Observational determinations of temporal gravity
variation motivate deriving the candidate's actual force normalization, rather
than replacing a measured G by its bare tensor coefficient. The result below
is an ideal long-range common-background bridge; it is not a reanalysis of any
ephemeris or an environmental matching theorem.

## 1. Declared readout domain

Use the supplied candidate's canonical scalar chi with chi=0 at u=0, universal
coupling A, beta=d ln A/dchi>0, q=beta^2, 0<k<1/3,
a=(1-k)(1+3k)/4, and Q=Q0(1+k). Freeze a sufficiently slowly varying ambient
background on the duration/size of each ideal weak force measurement. Take
unscreened complete weak bodies, effectively pointlike compared with the scalar
range, with negligible ambient linear response and controlled relativistic,
finite-size, range and apparatus corrections. Within this domain,

    Gforce=A^2(1+q)/(8 pi Q),    Gref=1/(8 pi Q0).

This is the total tensor-plus-scalar attraction coefficient in Jordan physical
units. It is not automatically the G parameter of an orbital likelihood. Q0
and Gref remain free normalization parameters; Gref is not an independently
observed vacuum value. A time derivative below uses a common physical Jordan
clock and assumes the readout approximation remains controlled as it varies.

## 2. Exact elimination of the field coordinate

The supplied coupling gives q=a/[1+(1-3a)s exp(2 sqrt(a) u)] and
A^2=(1+s)exp(2sqrt(a)u)/[1+s exp(2sqrt(a)u)], with
s=(1+k)/[k(1-3k)]. Eliminating u yields

    A^2=4(a-q)/[(1+k)(1-3q)],     0<q<a<1/3.

Consequently

    Gforce/Gref = 1 - 4(q-k)^2/[(1+k)^2(1-3q)].             (1)

Thus the ideal force coefficient has a strict maximum Gref at q=k, u=chi=0.
It stays positive for finite allowed u. The negative-u branch has k<=q<a;
the positive-u branch has 0<q<=k. This is a consequence of the supplied coupling
and Q normalization, not a derivation of Newton's absolute scale.

The bare coefficient Gbare=A^2/(8piQ) varies linearly near chi=0. Its variation
is canceled to first order by the scalar-force factor (1+q). Treating Gforce
as Gbare would miss this cancellation.

## 3. Derivative and inverse conditioning

Write d=-beta_chi=(a-q)(1-3q)/(1-3a). Then

    q_chi=-2 beta d,
    d ln Gforce/dchi = 2 beta [1-d/(1+q)]
      =2 beta(q-k)[2-3(q+k)]/[(1-3a)(1+q)].                (2)

At the vacuum q=k and d=1+k, so this derivative vanishes exactly. Since
q_chi(0)=-2sqrt(k)(1+k), expanding (1) in the canonical coordinate gives

    Gforce/Gref = 1 -16k chi^2/(1-3k)+O(chi^3),
    (ln Gforce)_chichi(0) = -32k/(1-3k).                  (3)

For a smooth physical-time crossing chi(t0)=0,

    (dot Gforce/Gforce)(t0)=0,
    (ddot Gforce/Gforce)(t0)=-32k dot chi(t0)^2/(1-3k).   (4)

The second identity is independent of chi acceleration at that instant because
the first field derivative vanishes. It holds only for the ideal readout; a
time-dependent correction to the readout may have its own first/second
derivatives. A small correction amplitude alone does not bound those derivatives.

A first-derivative limit cannot be uniformly inverted into a scalar-speed limit
near this turning point. If q is known away from k and the full forward model
justifies a pointwise drift error epsilon, then |dot chi|<=epsilon/|d ln G/dchi|
is conditional; its conditioning diverges as q approaches k. This is not an
assertion that arbitrarily rapid fields remain inside the quasistatic regime.

The value inverse also has two branches. Let D=1-Gforce/Gref and
C=D(1+k)^2/4. Then

    q-k = [-3C +/- sqrt(9C^2+4C(1-3k))]/2.              (5)

For D>0 the plus sign is the negative-u branch, and the minus sign is admissible
only while q>0. Allowed q must also satisfy q<a. Near D=0, the displacement is
proportional to sqrt(D), so its derivative with respect to D is singular. Neither
the sign branch nor the free reference scale is supplied by a force value alone.

## 4. Finite observation windows and what is not inferred

An orbital estimate of a linear G drift is obtained from an extended data model,
not an instantaneous derivative. Equation (4) does not establish compatibility
with such data: curvature, source sensitivities, timing, other gravity parameters
and nuisance correlations may be observable. A symmetric synthetic crossing can
have zero leading fitted linear drift while a nonzero quadratic change remains.
The initial phase/time of crossing is not selected by this identity.

The observation source is the published LLR analysis arXiv:2012.12032, exposed
earlier in this campaign. It motivates this bridge check, not a new fit, likelihood
or independent observed test. No uncertainty is converted to a scalar-speed bound.
The absolute scale, actual ambient field, range, source response and full orbital
mapping remain open. Retired within the ideal readout is the extra assumption
that bare and force-calibrated gravity have the same field derivative.
