# Published LLR context and data role

[Biskupek, Mueller and Torre, arXiv:2012.12032](https://arxiv.org/abs/2012.12032) report an estimated temporal variation of G of (-5.0 +/-9.6) times10^-15 per year. The abstract describes a multi-parameter relativistic analysis using lunar laser ranging. The parent re-opened that abstract on2026-10-14; this is not a new raw-data or full-likelihood analysis.

The paper was exposed earlier in this campaign and serves as model-development context. The turning-point identity tests a necessary force-calibration distinction before interpreting such an estimate. It neither predicts that estimate nor converts its uncertainty into a scalar-speed bound. The actual ambient state, body sensitivities, finite-range corrections, orbital dynamics, sampling, covariance and nuisance parameters remain to be supplied and checked. There is no independent observed holdout in this block.
