# Failures and negative-control record

The independent baseline completed 287/0, exit 0, with empty stderr. There was no unexpected computation or source-access failure in this check. No parent code, output or broad directory listing was read.

Five actual changed independent implementations were executed from preserved full copies with exact one-change diffs. Their real results were 177/110, 261/26, 249/38, 281/24 and 275/6; all exited 1 and every named witness failed. Full sources, stdout/stderr, result rows and command records are retained. These failed programs are rejection evidence, not repaired baselines.

The last two total assertion counts differ from 287 because the deliberately wrong inverse functions return different numbers of roots. Every fixed inverse fixture, expected-root-count check and admissibility check still runs. Additional per-root quadratic/forward checks depend on the returned list. Omitting domain filtering produces extra algebraic roots; discarding a branch removes per-root work but is caught by the fixed count and both-branch witnesses. No fixture or acceptance condition was weakened after observing these failures.

The q-linear finite-window control has a small nonzero cubic-order fitted slope, despite its vanishing instantaneous derivative and leading quadratic symmetry. The exactly even-force control has zero fitted slope by proof and a numerical quadrature residual about -6.22e-83, with nonzero curvature. Neither is a solved physical history or an observed fit.

No source correction was required. Original four source snapshots and the hand/protocol remain unchanged. Observational applicability and unknown correction derivatives are retained limitations, not missing computational failures.
