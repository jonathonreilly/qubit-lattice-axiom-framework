# Independent hand derivation before executable controls

This derivation uses only the four explicitly frozen source files. No parent implementation, result or directory inventory has been read. The author of the candidate and proposed bridge remains /root. The calculations below are a focused check of that proposal, not replacement authorship.

## 1. Action normalization and physical force

The supplied action contains Q R/2 and -Q K_AB partial phi^A partial phi^B, so Gstar=1/(8 pi Q). Along a u-coordinate line define chi by dchi/du=sqrt(J)/F and chi(0)=0. This is canonical in the convention with kinetic coefficient -Q; the dimensionful scalar with coefficient -1/2 would instead be sqrt(2Q) chi. Mixing these conventions would change numerical field derivatives.

Varying the universally coupled matter action gives beta T_E in the chi equation. For weak nonrelativistic dust, T_E=-rho_E, and neglecting masses, ambient feedback, time derivatives and curvature on the measurement scale gives

    Delta delta chi = beta rho_E/(2Q) = 4 pi Gstar beta rho_E.

The decaying point-source solution is delta chi=-beta Gstar M_E/r_E. The Einstein positive Newton potential is Ustar=Gstar M_E/r_E. Conformal multiplication gives the Jordan time potential Ustar-beta delta chi=(1+beta^2)Ustar. Constant-background mass/radius conversion is M_E=A_b M_J and r_J=A_b r_E. Therefore Ustar=Gstar A_b^2 M_J/r_J and the total attraction coefficient is Gforce=Gstar A_b^2(1+beta^2). Equivalently the multiscalar principal force uses alpha_A K^{AB} alpha_B=a/J. Thus the displayed coefficient follows with q=beta^2=a/J and Q=Q0(1+k).

This is a conditional weak, complete-body, long-range principal readout. The action does not establish that an actual orbit fit measures this coefficient, or that finite-size, source sensitivity, feedback, mass/mixing or rolling corrections are small. The given source explicitly assumes those controls. Nu and Hv do not enter the algebraic coefficient, but they do enter the omitted range/dynamical terms. The clock used below is Jordan physical proper time, as the new source states. No observational number is inserted.

## 2. Elimination, domains and extrema

Write h=1-3a=(1-3k)^2/4>0, E=exp(2sqrt(a)u)>0, F=1+sE, J=1+h sE. Differentiating log A=log[(1+s)E/F]/2 gives alpha_u=sqrt(a)/F. Dividing by sqrt(K_uu)=sqrt(J)/F gives beta=sqrt(a/J)>0 and q=a/J.

The inverse E=(a-q)/(h s q) shows that finite real u is equivalent to 0<q<a. Also

    a-k=(1+k)(1-3k)/4>0,
    1-3a=(1-3k)^2/4>0,
    F=a(1-3q)/(h q),
    (1+s)/(s a)=4/(1+k).

Substitution into A^2=(1+s)E/F gives A^2=4(a-q)/[(1+k)(1-3q)]. All factors have controlled signs. R=Gforce/Gref=A^2(1+q)/(1+k) is strictly positive, and direct expansion gives

    (1+k)^2(1-3q)-4(a-q)(1+q)=4(q-k)^2.

Hence R=1-4(q-k)^2/[(1+k)^2(1-3q)]. It is <=1, and equality occurs only at q=k, equivalently E=1 and u=chi=0. This is a strict maximum in the u/coupling coordinate, not a statement that every point with u=0 and arbitrary transverse fields is the complete field-space vacuum. On the vacuum scalar channel x=y=0 it is the vacuum. The force coefficient itself is independent of x,y in the principal approximation.

Since q decreases strictly with E and u, u<0 has k<q<a and u>0 has 0<q<k. Endpoints q=a and q=0 are excluded at finite u. R tends to zero as q tends to a. At q tending to zero it tends to 4a/(1+k)^2=1-4k^2/(1+k)^2, a positive limiting value.

## 3. Canonical derivatives

The differential operator from the metric is

    Dchi = [2sqrt(a) E F/sqrt(J)] DE.

Differentiating beta=sqrt(a)/sqrt(J) gives

    -beta_chi = a h s E F/J^2
              = (a-q)(1-3q)/h = d>0,
    q_chi=-2sqrt(q)d.

At q=k, d=1+k and q_chi=-2sqrt(k)(1+k). The logarithmic derivative is

    Lchi = Dchi log R = 2sqrt(q)+q_chi/(1+q)
         = 2sqrt(q)[1-d/(1+q)].

The numerator h(1+q)-(a-q)(1-3q) is exactly
(q-k)[2-3(q+k)], giving the proposed Eq 2. Its second bracket is positive throughout 0<q<a, 0<k<1/3: q+k<a+k<2/3. Thus the finite-coordinate derivative has only the vacuum-u zero. It tends to zero again at the excluded q=0 endpoint, so an estimate uniform over every q away from k would also need a bound away from that endpoint. The source's pointwise formula makes no such uniform assertion.

Expand the exact deficit with delta=q-k. Since delta=-2sqrt(k)(1+k)chi+O(chi^2),

    R=1-16k chi^2/(1-3k)+O(chi^3),
    Lchi(0)=0, Lchichi(0)=Rchichi(0)=-32k/(1-3k).

This is at each fixed interior k. It is not uniform as k tends to 1/3, and its nonzero curvature is not uniformly bounded away from zero as k tends to zero. The bare coefficient has Dchi log Gbare=2sqrt(q), hence 2sqrt(k) at the vacuum. Even after constant calibration of its value, it retains that first derivative and is not interchangeable with Gforce.

## 4. Physical time and conditioning

For any sufficiently smooth crossing within the ideal readout, Ldot=Lchi chidot. The second ratio is

    Gddot/G=(Lchichi+Lchi^2)chidot^2+Lchi chiddot.

At chi=0 this is -32k chidot^2/(1-3k), independent of acceleration, and Gdot/G=0. The clock must be common and specified. Under dt_J=A dt_E, the second clock-conversion term is proportional to the first field derivative and also vanishes at the crossing; A=1 there.

At any finite point with q!=k, the exact local coefficient Lchi is nonzero, so a justified pointwise drift error epsilon implies |chidot|<=epsilon/|Lchi|. This is ill-conditioned as q approaches k; no uniform inverse-speed constant exists in a neighborhood containing the turning point. The exact cancellation does not authorize arbitrarily rapid fields, which may leave the quasistatic readout assumptions. Nor does a bound on a correction's amplitude bound its derivative: e(t)=epsilon sin(omega t) is bounded in amplitude while e'(0)=epsilon omega. An analogous cosine gives unrestricted second derivative. These are diagnostic mathematical witnesses, not proposed physical correction models.

## 5. Two-root value inverse and admissibility

For a fixed supplied k and reference Gref define D=1-R and C=D(1+k)^2/4. The exact forward equation is

    delta^2+3C delta-C(1-3k)=0.

The two displayed roots follow. For C>0, delta_plus>0 and delta_minus<0. Domain filtering is essential. Let D0=4k^2/(1+k)^2. Then:

- D<0 or D>=1 gives no finite physical field.
- D=0 gives the single repeated physical root q=k.
- 0<D<D0 gives two finite physical roots, one on each u branch.
- D0<=D<1 gives only the negative-u root; at D0 the other root is exactly q=0 and excluded.
- At D=1 the plus root is q=a and excluded.

The source correctly retains q>0 and q<a rather than asserting two admissible states for every D. Near zero the leading displacement is plus/minus [(1+k)sqrt(1-3k)/2]sqrt(D); dq/dD diverges. Neither branch sign nor an unknown reference Gref can be inferred from one force value. An absolute measurement alone also does not select k or Q0.

## 6. Finite-window diagnostics

A q-linear diagnostic q=k+v t is not an even force history. At fixed k, letting b=1-3k and B=(1+k)^2 gives

    R(t)=1-4v^2 t^2/[B(b-3v t)].

Its leading quadratic term is even, but a cubic odd term remains. Uniform continuous least-squares regression with an intercept over [-T,T] gives

    slope = -36v^3/(B T^3) integral_0^T t^4/(b^2-9v^2t^2) dt.

For v>0 and 3vT<b this is strictly negative. Its leading term is -36v^3T^2/(5B b^2), with ratio between 1 and 1/[1-9v^2T^2/b^2]. Thus a zero leading linear term is not an exact finite-window zero.

Conversely, the smooth diagnostic delta(t)=-3c t^2/2+t sqrt(9c^2t^2+4c b)/2, with c>0 and a sufficiently short domain-admissible window, solves the inverse for C=c t^2. It gives exactly R(t)=1-4c t^2/B. A symmetric linear fit has exactly zero slope but nonzero curvature. Neither diagnostic is a solved cosmological/body history or a likelihood fit. They demonstrate why instantaneous cancellation and a fitted finite-window drift must not be conflated.

The cited LLR paper remains previously exposed motivation only. This check does not fetch it, borrow an error tolerance, reanalyse a likelihood or infer an observational escape from time-series constraints.
