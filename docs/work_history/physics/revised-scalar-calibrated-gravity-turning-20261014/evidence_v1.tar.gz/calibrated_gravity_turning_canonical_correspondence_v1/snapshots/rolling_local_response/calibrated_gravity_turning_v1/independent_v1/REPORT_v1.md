# Independent calibrated-gravity turning-point check

The proposed ideal-force identity, canonical curvature, two-root inverse and physical-time chain rule follow from the supplied action within the stated readout approximation. No material mathematical correction to DERIVATION_v1.md was required. This is a focused independent check; /root remains scientific author. The result does not establish an actual force/LLR readout, choose a field history, derive the reference scale or show compatibility with temporal gravity data.

## Sources and independence

Exactly four named files were frozen and read completely: the new hand derivation, its protocol, the supplied full-action note and the local-response normalization note. No new producer program or result, broad parent-directory inventory, external data, Git state or runtime/audit state was accessed or changed. Only this independent_v1 directory was written.

| Source | SHA256 |
| --- | --- |
| DERIVATION_v1.md | `ba1c1bff40f0390d0fd1e96a9eea09f5c3f9e8ff23a37b3b8da1256193ee8e07` |
| PROTOCOL_v1.json | `a58725e870565221fef2856ed28c311618a4195f8eabf32416fc773f16975306` |
| Full action: future-confinement note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Local-response normalization note | `b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68` |

The local-response note already records a related cancellation using its bounded energy coordinate. It is an explicitly permitted input, not newly exposed producer output. Independence here means reconstruction from the action/metric, distinct controls and no new producer implementation/results; it does not mean ignorance of the mathematical claim supplied for review.

HAND_DERIVATION_v1.md was written before executable controls. It derives the force normalization, elimination, domains, metric derivatives, clock chain rule, complete inverse admissibility and window diagnostics. SOURCE_DISPOSITIONS_v1.json supplies all four exact original/recovery/final mappings.

## Action normalization and principal readout

The -Q K kinetic term and Q R/2 gravitational term imply Gstar=1/(8 pi Q). The canonical coordinate used here has dchi/du=sqrt(K_uu), retaining the -Q kinetic convention. A dimensionful scalar with kinetic -1/2 would be sqrt(2Q) chi and would not have the same numerical field derivatives.

For a weak nonrelativistic source, scalar variation gives Delta delta chi=beta rho_E/(2Q). Its decaying point-source solution is -beta Gstar M_E/r_E. Conformal conversion supplies the scalar contribution beta^2 times the Einstein Newton potential. Since M_E=A_b M_J and r_J=A_b r_E, the Jordan coefficient is A_b^2(1+beta^2)/(8 pi Q). The complete multiscalar principal norm is alpha_A K^{AB}alpha_B=a/J, so the same result is q=a/J. The Q=Q0(1+k) normalization is necessary for the stated vacuum maximum relative to Gref.

This is exact algebra inside the declared massless/principal, frozen-background weak-source approximation. The source's long-range, complete-body, controlled-source-response and apparatus assumptions matter. Nu and Hv disappear from this coefficient, but they still control possible omitted masses/range and dynamics. No estimate of those errors or their derivatives is supplied by the identity. A present force-fit or orbital G parameter cannot automatically be substituted for this coefficient.

## Elimination, maximum and canonical derivative

Writing h=1-3a=(1-3k)^2/4, the original metric and conformal factor give beta=sqrt(a/J), q=a/J and E=(a-q)/(h s q). Thus finite real u corresponds exactly to 0<q<a<1/3. Also a-k=(1+k)(1-3k)/4>0. Direct substitution yields A^2=4(a-q)/[(1+k)(1-3q)].

Expanding the numerator independently gives

    (1+k)^2(1-3q)-4(a-q)(1+q)=4(q-k)^2.

Hence the stated deficit is correct, its denominator is positive and 0<Gforce/Gref<=1. Equality occurs only at q=k and u=chi=0. The maximum is a statement in the u/coupling coordinate; it does not select arbitrary transverse fields or a complete observed state. Along the vacuum scalar channel it is the vacuum. The nonzero coupling q=k remains present even when the force coefficient equals its reference value.

The metric gives Dchi=[2sqrt(a) E F/sqrt(J)] DE. Differentiating the original beta, rather than an asserted q equation, gives -beta_chi=a h s E F/J^2=(a-q)(1-3q)/h. Therefore q_chi=-2sqrt(q)d and the proposed logarithmic derivative follows exactly. The factor 2-3(q+k) is positive throughout the finite domain, so its only finite-coordinate zero is q=k.

At the vacuum, d=1+k and q_chi=-2sqrt(k)(1+k). The exact deficit then yields

    Gforce/Gref=1-16k chi^2/(1-3k)+O(chi^3),
    (ln Gforce)_chichi=-32k/(1-3k).

The independent raw-u numerical derivatives and raw-E symbolic operator both reproduce this curvature. The bare logarithmic derivative is instead 2sqrt(k) at the same point, even after a constant value recalibration. Omitting the scalar-force factor therefore changes the observable derivative, not just an arbitrary constant normalization.

All these derivatives use fixed interior k. They are not uniform at k approaching 1/3 or zero. The first derivative also tends to zero at the excluded q=0 field-chart endpoint. Thus a bound uniform over an entire region described only as away from k would need further endpoint control. The source gives a pointwise conditional bound and makes no contrary uniform claim.

## Time, drift and observation interpretation

For a common physical Jordan clock, the exact chain rule is

    Gddot/G=(Lchichi+Lchi^2)chidot^2+Lchi chiddot.

At chi=0, both the first drift and acceleration-dependent contribution vanish. The remaining second ratio is -32k chidot^2/(1-3k). A separate test using dt_J=A dt_E and a raw-u crossing reproduces the same coefficient. This is a statement about the canonical u-channel speed, not a bound on the total three-field kinetic norm.

The first-derivative inverse-speed coefficient is unbounded near the turning point. In distinct controls at k=2/17, reducing |q-k| from 1e-4 to 1e-10 raises 1/|Lchi| from about 1.318e3 to 1.318e9 on either side. This confirms conditioning, not permission for rapid backgrounds to remain quasistatic. A pointwise drift bound can be used only after the forward readout/error model and the actual field point are justified.

Small correction amplitude alone cannot control first or second derivatives. Exact sine/cosine counterwitnesses with amplitude 1e-6 exhibit arbitrarily increasing derivative coefficients as their frequency increases. These witnesses are mathematical controls, not claims about actual apparatus corrections. The source already preserves this limitation.

The previously exposed LLR reference remains motivation. No paper or empirical data was fetched here, no observational uncertainty was imported, and no new fit or confidence statement was made. Instantaneous cancellation does not establish evasion of an extended time-series likelihood, whose curvature, other parameters and nuisance/source correlations can still matter. The source correctly retains that distinction.

## Complete inverse domain and window controls

For fixed supplied k and Gref, the inverse solves delta^2+3C delta-C(1-3k)=0, where delta=q-k and C=D(1+k)^2/4. This gives the stated roots. Their physical admissibility is:

- D<0 or D>=1: no finite physical field.
- D=0: one repeated physical root q=k.
- 0<D<D0, D0=4k^2/(1+k)^2: two finite branches.
- D0<=D<1: only the negative-u branch; at D0 the other root is q=0 and excluded.

At D=1 the remaining algebraic root reaches q=a and is also excluded. The displacement near D=0 is proportional to sqrt(D); its derivative is singular. The original source's q>0 and q<a qualifications correctly encode these restrictions. One measured force value does not provide the missing branch, free reference scale or k.

The numerical protocol uses k={1/29,2/17,5/23} and E={1/9,3/7,1,7/3,9}, distinct from the parent's specified fixtures. Exact inverse fixtures include negative D, zero, D0/3, D0, (D0+1)/2, one and 6/5. Every admissible returned root is checked through the original E-coordinate force, not only through its inverse polynomial.

For the diagnostic q(t)=k+v t with k=2/17, v=1/7000 and T=7/3, the continuous symmetric-window fitted slope is -2.1852231925319773940941015743495828534e-10. The leading cubic expression is -2.1852194644942063728263677898530580475e-10. Their ratio is 1.0000017060244207 and lies in the independently derived exact remainder interval. The instantaneous derivative and leading fitted linear term vanish, but the actual finite-window slope is not exactly zero.

A separate smooth inverse-constructed diagnostic with k=5/23, C(t)=t^2/20000 and T=3/2 has exactly even Gforce/Gref=1-4C(t)/(1+k)^2. Its fitted slope is zero by symmetry; numerical quadrature leaves about -6.22e-83. It still has second derivative -0.0002698979591836734694 and canonical crossing speed about -0.0036735402487496545. These are diagnostic curves, not solved matter/cosmological histories or observed signals. They support the source's caution about finite windows rather than an observational compatibility claim.

## Executed controls and actual failures

The independent baseline returned 287/0, exit 0, with empty stderr. It combines exact rational/symbolic identities, 80-digit raw-u differentiation, canonical/physical-clock checks, all inverse-domain fixtures, conditioning and distinct finite-window controls. The positive baseline was not repaired or rerun. The hand proof, not the finite fixture count, carries the general-domain conclusions.

Five complete altered independent programs were created with exact single changes and executed:

| Alteration | Passed / failed | Named witness |
| --- | ---: | --- |
| Omit scalar-force factor | 177 / 110 | calibrated_vacuum_value |
| Reverse deficit denominator sign | 261 / 26 | force_deficit_from_raw_action |
| Multiply canonical differential operator by sqrt(2) | 249 / 38 | canonical_second_derivative |
| Omit inverse-domain filtering | 281 / 24 | inverse_physical_root_count:1/29:1 |
| Discard the second inverse branch | 275 / 6 | inverse_both_sign_branches:1/29:1/675 |

Every altered child exited 1 and each required witness failed mathematically. All full failed rows, code copies, diffs, stdout/stderr and exact commands are retained. The final two assertion totals differ because their returned root lists differ; every fixed inverse fixture and its expected-count/admissibility checks remains unchanged, while per-returned-root checks vary. No post-hoc weakening of the fixtures or acceptance criterion occurred. All four original sources and the hand/protocol were unchanged across the damaged executions.

There was no unexpected source-access or computation failure in this review. FAILURES_v1.md records the deliberate failures and limits without relabeling them as clean controls. The manifest and receipt bind all sources, commands, derivation, programs, results and this report. The source equations and stated approximation survive this focused check; actual environmental matching, controlled error derivatives, state/parameter selection and observational inference remain outside it.
