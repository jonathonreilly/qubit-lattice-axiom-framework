# Affected v2 proof correspondence, before its exact controls

The original independent hand proof, 287/0 baseline and five actual changed programs are complete and remain unchanged. The newly authorized reads are only DERIVATION_v2.md, its diff/extension record, and the two explicitly named observational-context metadata files. No parent implementation or result file has been read. The parent message and final paragraph of v2 expose aggregate 114/1 to 115/0 execution history after our independent core was complete. This is an unverified parent attestation in this unit, not independent computational evidence.

The inverse threshold is already proved in HAND_DERIVATION_v1.md: the forward deficit at the excluded q=0 endpoint is D0=4k^2/(1+k)^2, while at q=a it is 1. The two finite roots exist exactly for 0<D<D0. The positive displacement remains admissible for all 0<D<1. No baseline rerun is needed.

The source's T is the full interval width. Our prior proof and numerical record use H as the half width (called T in those frozen files). Set T=2H. Then

    -36 v^3 H^2/[5(1+k)^2 g^2]
      = -9 v^3 T^2/[5(1+k)^2 g^2],
    9v^2 H^2/g^2 = xi^2 = 9v^2 T^2/(4g^2).

This is a notation conversion, not a new coefficient or a repaired numerical run. For a free-intercept uniform regression on the centered interval, the denominator is integral t^2 dt=T^3/12. Pairing the numerator's t^3/(g-3vt) gives its even part 3v t^4/(g^2-9v^2t^2). Since integral t^4 dt=T^5/80, the leading slope is precisely the source's coefficient. The remaining ratio is the positive t^4-weighted average of 1/[1-(3vt/g)^2]. If xi<1, it lies between 1 and 1/(1-xi^2). This holds for either sign of v. At v=0 the slope is zero and r may be chosen as zero. The physical interval 0<q(t)<a and fixed 0<k<1/3 remain required.

Our previously computed q-linear fixture has H=7/3, hence source T=14/3; its exact leading expression and computed ratio can be compared without repeating quadrature. Its finite slope is nonzero. The separate exactly even force diagnostic is a different imposed trajectory. Neither is a solved field history or an orbital fit.

The two local context records consistently designate arXiv:2012.12032 as previously exposed abstract-level motivation and deny a new fit or scalar-speed bound. This unit has not fetched or independently inspected that paper, and does not certify the quoted observational value or likelihood. Those metadata are preserved only for access and role correspondence. No observed numerical tolerance enters any control.

The original source body is unchanged except for three inverse-domain lines and the appended finite-window section. The appended parent numerical-history paragraph will be recorded as an attestation only. No mathematical correction is required by this affected check.
