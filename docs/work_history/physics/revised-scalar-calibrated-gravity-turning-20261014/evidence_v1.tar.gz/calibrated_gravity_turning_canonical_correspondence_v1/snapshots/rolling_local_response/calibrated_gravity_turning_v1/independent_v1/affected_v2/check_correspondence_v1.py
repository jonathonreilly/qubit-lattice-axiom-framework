#!/usr/bin/env python3
"""Affected source proof/notation correspondence only; no producer program import."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import sympy as S

HERE = Path(__file__).resolve().parent
OWN = HERE.parent
checks = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def same(name, left, right):
    residual = S.factor(left-right)
    check(name, residual == 0, str(residual))

old = (OWN/'sources/DERIVATION_v1.md').read_text()
new = (HERE/'DERIVATION_v2.md').read_text()
inserted = ('For 0<D<1 the plus root is admissible. Both roots are admissible precisely\n'
            'when 0<D<4k^2/(1+k)^2; at that threshold the minus root is q=0 and is\n'
            'excluded from the finite-field domain. D=0 gives one coincident vacuum root.\n')
check('original_body_preserved_except_named_insert', new.split('\n## 5. Explicit finite-window calculation\n')[0].replace(inserted, '') == old)
check('exact_source_diff', ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='DERIVATION_v1.md', tofile='DERIVATION_v2.md')) == (HERE/'DERIVATION_v2.diff').read_text())
ext = json.loads((HERE/'DERIVATION_EXTENSION_v2.json').read_text())
check('extension_old_hash', ext['old_sha256'] == sha(OWN/'sources/DERIVATION_v1.md'))
check('extension_new_hash', ext['new_sha256'] == sha(HERE/'DERIVATION_v2.md'))
for row in json.loads((HERE/'SOURCE_FREEZE_v1.json').read_text())['source_pairs']:
    check('affected_live_snapshot:'+Path(row['original_path']).name, sha(Path(row['original_path'])) == sha(Path(row['recovery'])) == row['sha256'] and Path(row['recovery']).stat().st_size == row['bytes'])

k, q, v, g, t = S.symbols('k q v g t', real=True)
T, H = S.symbols('T H', positive=True)
B = (1+k)**2
a = (1-k)*(1+3*k)/4
D = 4*(q-k)**2/(B*(1-3*q))
same('threshold_at_excluded_q_zero', D.subs(q,0), 4*k**2/B)
same('upper_excluded_q_a', D.subs(q,a), 1)
same('centered_ols_denominator', S.integrate(t*t, (t,-T/2,T/2)), T**3/12)
same('centered_fourth_moment', S.integrate(t**4, (t,-T/2,T/2)), T**5/80)
integrand = t**3/(g-3*v*t)
evenpart = (integrand+integrand.subs(t,-t))/2
same('paired_even_integrand', evenpart, 3*v*t**4/(g*g-9*v*v*t*t))
same('leading_coefficient_from_moments', (-4*v*v/B)*(3*v/g**2)*(T**5/80)/(T**3/12), -9*v**3*T*T/(5*B*g*g))
same('full_half_width_coefficient', (-9*v**3*T*T/(5*B*g*g)).subs(T,2*H), -36*v**3*H*H/(5*B*g*g))
same('full_half_width_remainder', (9*v*v*T*T/(4*g*g)).subs(T,2*H), 9*v*v*H*H/(g*g))
y, xi2 = S.symbols('y xi2', real=True)
same('pointwise_remainder_identity', 1/(1-y)-1, y/(1-y))
same('pointwise_upper_gap_factor', xi2/(1-xi2)-y/(1-y), (xi2-y)/((1-xi2)*(1-y)))

baseline = json.loads((OWN/'baseline_v1/RESULTS.json').read_text())
check('reused_baseline_identity_and_count', baseline['source_sha256'] == sha(OWN/'check_turning_independent_v1.py') and (baseline['passed'], baseline['failed']) == (287,0))
window = baseline['data']['q_linear_window']
kv, vv, hv = (S.Rational(window[key]) for key in ['k','v','T'])
tv = 2*hv
gv = 1-3*kv
leading = -9*vv**3*tv**2/(5*(1+kv)**2*gv**2)
check('frozen_window_full_width', tv == S.Rational(14,3), str(tv))
check('frozen_leading_agrees_without_rerun', abs(leading-S.Rational(window['leading'])) < S.Rational(1,10**72), str(leading))
x2 = 9*vv**2*tv**2/(4*gv**2)
rr = S.Rational(window['ratio'])-1
check('frozen_remainder_in_exact_bound', 0 <= rr <= x2/(1-x2), {'r': str(rr), 'upper': str(x2/(1-x2))})
check('frozen_trajectory_not_solved', window['history_solved'] is False)
check('v_zero_slope', (-9*v**3*T*T/(5*B*g*g)).subs(v,0) == 0)
check('v_sign_reversal', S.simplify((-9*v**3*T*T/(5*B*g*g)).subs(v,-v) + (-9*v**3*T*T/(5*B*g*g))) == 0)
context = (HERE/'OBSERVATIONAL_CONTEXT_v1.md').read_text()
primary = json.loads((HERE/'PRIMARY_SOURCE_v1.json').read_text())
check('context_same_named_abstract', primary['url'] in context and '2012.12032' in new)
check('context_no_new_fit_or_speed_bound', primary['fit_performed'] is False and primary['new_velocity_bound'] is False and 'no independent observed holdout' in context)
check('parent_aggregate_exposure_preserved', '114/1' in new and '115/0' in new and 'from80 to130' in new)

result = {'scope': 'Affected source/notation comparison only; original mathematical controls reused unchanged; no producer implementation/results inspected.', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_sha256': sha(Path(__file__)), 'hand_sha256': sha(HERE/'HAND_CORRESPONDENCE_v1.md'), 'reused_baseline_sha256': sha(OWN/'baseline_v1/RESULTS.json'), 'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks), 'checks': checks, 'parent_execution_history_status': 'Late exposed source/message attestation, not verified in this independent unit.', 'external_paper_verified': False}
path = HERE/'RESULTS_v1.json'
with path.open('x') as f:
    json.dump(result,f,indent=2); f.write('\n')
print(json.dumps(result,indent=2))
raise SystemExit(int(result['failed'] != 0))
