#!/usr/bin/env python3
"""Independent raw-action/physical-readout route; no producer imports or inputs."""
from pathlib import Path
import argparse,hashlib,json
import sympy as S
import mpmath as mp
USE_SCALAR = 1
DEFICIT_SIGN = -1
CANONICAL_FACTOR = S.sqrt(2)
FILTER_DOMAIN = True
BOTH_BRANCHES = True
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);cfg=ap.parse_args();assert not cfg.out.exists();mp.mp.dps=80;checks=[];data={}
def ck(name,ok,detail=None):checks.append(dict(name=name,passed=bool(ok),detail=detail))
def eq(name,expr):
 z=S.factor(S.cancel(expr));ck(name,z==0,str(z))
def close(name,x,y):
 error=abs(x-y);bound=mp.mpf('1e-60')*max(1,abs(x),abs(y));ck(name,error<=bound,dict(actual=mp.nstr(x,65),expected=mp.nstr(y,65),abs_error=mp.nstr(error,12)))
def m(x):return mp.mpf(str(S.N(x,85)))
def parameters(k):
 a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));return a,s
# Raw E coordinate action metric and matter conformal factor.
k,E=S.symbols('k E',positive=True);a,s=parameters(k);h=1-3*a;F=1+s*E;J=1+h*s*E;K=J/F**2;A2=(1+s)*E/F;alpha_u=S.sqrt(a)/F;q=S.factor((alpha_u**2)/K);R=S.factor(A2*(1+USE_SCALAR*q)/(1+k));B2=4*a*E**2/K
qv=S.symbols('q',positive=True);E_inv=(a-qv)/(h*s*qv)
def deficit(k,q):return 4*(q-k)**2/((1+k)**2*(1+DEFICIT_SIGN*3*q))
eq('action_metric_gradient_norm',q-a/J)
eq('positive_metric_parameter_identity',h-(1-3*k)**2/4)
eq('vacuum_coupling',q.subs(E,1)-k)
eq('conformal_elimination',A2.subs(E,E_inv)-4*(a-qv)/((1+k)*(1-3*qv)))
eq('force_deficit_from_raw_action',R.subs(E,E_inv)-(1-deficit(k,qv)))
eq('calibrated_vacuum_value',R.subs(E,1)-1)
d_raw=S.factor(a*h*s*E*F/J**2);d_q=(a-qv)*(1-3*qv)/h
eq('coupling_slope_elimination',d_raw.subs(E,E_inv)-d_q)
L_over_2beta=S.factor(CANONICAL_FACTOR*E*F*S.diff(R,E)/R)
eq('log_derivative_direct_action',L_over_2beta-(1-d_raw/(1+q)))
eq('log_derivative_factored',L_over_2beta.subs(E,E_inv)-(qv-k)*(2-3*(qv+k))/(h*(1+qv)))
eq('vacuum_first_force_derivative',S.diff(R,E).subs(E,1))
# B D_E is the canonical differential operator; logarithmic second derivative is rational.
LE=S.diff(R,E)/R;LEE=S.diff(LE,E);Lcc=S.factor(CANONICAL_FACTOR**2*(B2*LEE+S.diff(B2,E)*LE/2))
eq('canonical_second_derivative',Lcc.subs(E,1)+32*k/(1-3*k))
eq('canonical_coupling_derivative_squared',CANONICAL_FACTOR**2*B2*S.diff(q,E)**2-4*q*d_raw**2)
eq('vacuum_q_derivative_squared',(CANONICAL_FACTOR**2*B2*S.diff(q,E)**2).subs(E,1)-4*k*(1+k)**2)
eq('bare_derivative_squared',B2*(S.diff(A2,E)/A2)**2-4*q)
eq('maximum_deficit_polynomial',(1+k)**2*(1-3*qv)-4*(a-qv)*(1+qv)-4*(qv-k)**2)
eq('a_minus_k_domain',a-k-(1+k)*(1-3*k)/4)
eq('inverse_threshold',deficit(k,0)-4*k**2/(1+k)**2)
eq('negative_endpoint_deficit',deficit(k,a)-1)
# Distinct exact rational E controls; signs are evaluated without floats.
fixture_rows=[];ks=[S.Rational(1,29),S.Rational(2,17),S.Rational(5,23)];Es=[S.Rational(1,9),S.Rational(3,7),S.Integer(1),S.Rational(7,3),S.Integer(9)]
for kv in ks:
 av,sv=parameters(kv);hv=1-3*av
 for ev in Es:
  vals={k:kv,E:ev};qq=S.factor(q.subs(vals));aa=S.factor(A2.subs(vals));rr=S.factor(R.subs(vals));dd=S.factor(d_raw.subs(vals));tag=str(kv)+':'+str(ev)
  ck('finite_q_domain:'+tag,0<qq<av<S.Rational(1,3));ck('derivative_remaining_factor_positive:'+tag,2-3*(qq+kv)>0);ck('raw_force_positive_cap:'+tag,0<rr<=1)
  ck('strict_max_location:'+tag,(rr==1)==(ev==1));ck('branch_order:'+tag,(qq>kv)==(ev<1) and (qq<kv)==(ev>1));eq('rational_forward_deficit:'+tag,rr-(1-deficit(kv,qq)))
  fixture_rows.append(dict(k=str(kv),E=str(ev),q=str(qq),A2=str(aa),R=str(rr),d=str(dd)))
data['exact_rational_fixtures']=fixture_rows
# Independent numerical differentiation in original u, using the metric directly.
def raw(kv,u):
 av,sv=parameters(kv);ev=mp.exp(2*mp.sqrt(av)*u);ff=1+sv*ev;jj=1+(1-3*av)*sv*ev
 return ff,jj,(1+sv)*ev/ff,jj/ff**2,av/jj
def force(kv,u):
 ff,jj,aa,kk,qq=raw(kv,u);return aa*(1+USE_SCALAR*qq)/(1+kv)
cf=m(CANONICAL_FACTOR)
def D(fn,kv,u):return cf*mp.diff(fn,u)/mp.sqrt(raw(kv,u)[3])
def Lchi(kv,u):return D(lambda x:mp.log(force(kv,x)),kv,u)
num=[]
for ks0 in ks:
 kv=m(ks0);av,sv=parameters(kv)
 for es0 in Es:
  u=mp.log(m(es0))/(2*mp.sqrt(av));ff,jj,aa,kk,qq=raw(kv,u);beta=mp.diff(lambda x:mp.log(raw(kv,x)[2])/2,u)/mp.sqrt(kk);lc=Lchi(kv,u);expected=2*mp.sqrt(qq)*(1-(av-qq)*(1-3*qq)/((1-3*av)*(1+qq)));tag=str(ks0)+':'+str(es0)
  close('numeric_metric_beta_squared:'+tag,beta**2,qq);close('numeric_force_identity:'+tag,force(kv,u),1-m(deficit(ks0,S.Rational(str(mp.nstr(qq,82))))));close('numeric_canonical_first:'+tag,lc,expected)
  num.append(dict(k=str(ks0),E=str(es0),u=mp.nstr(u,40),q=mp.nstr(qq,40),force=mp.nstr(force(kv,u),40),Lchi=mp.nstr(lc,40)))
 curvature=D(lambda x:Lchi(kv,x),kv,mp.mpf(0));target=-32*kv/(1-3*kv);close('numeric_canonical_curvature:'+str(ks0),curvature,target);close('numeric_vacuum_first:'+str(ks0),Lchi(kv,0),mp.mpf(0))
 for v0 in [mp.mpf(1)/100,-mp.mpf(1)/250]:
  for acc in [mp.mpf(0),mp.mpf(2)/7,-mp.mpf(5)/11]:
   # Exact chain expression, with independent measured canonical speed/acceleration.
   pred=(curvature+Lchi(kv,0)**2)*v0**2+Lchi(kv,0)*acc
   close('crossing_acceleration_independence:'+str(ks0)+':'+str(v0)+':'+str(acc),pred,target*v0**2)
 # Jordan clock conversion for a raw u(t_E)=speed*t_E crossing.
 uspeed=mp.mpf(3)/200;aa0=raw(kv,0)[2];K0=raw(kv,0)[3];Ru=mp.diff(lambda z:force(kv,z),0);Ruu=mp.diff(lambda z:force(kv,z),0,2);Au=mp.diff(lambda z:mp.sqrt(raw(kv,z)[2]),0)
 actual=(Ruu/aa0-Ru*Au/(aa0**mp.mpf('1.5')))*uspeed**2/force(kv,0)
 close('physical_clock_chain:'+str(ks0),actual,target*K0*uspeed**2/aa0)
 bare_slope=mp.diff(lambda z:mp.log(raw(kv,z)[2]/(1+kv)),0)/mp.sqrt(K0);close('bare_remains_linear:'+str(ks0),bare_slope,2*mp.sqrt(kv))
data['raw_u_derivative_rows']=num
# The inverse is tested against exact domain counts and the raw E forward map.
def inverse(kv,Dval):
 if Dval<0:return []
 cv=Dval*(1+kv)**2/4;disc=S.sqrt(9*cv**2+4*cv*(1-3*kv));roots=[S.simplify(kv+(-3*cv+disc)/2)]
 if BOTH_BRANCHES:roots.append(S.simplify(kv+(-3*cv-disc)/2))
 av,_=parameters(kv)
 if FILTER_DOMAIN:roots=[x for x in roots if bool(x>0) and bool(x<av)]
 return sorted(set(roots),key=lambda x:float(S.N(x,30)))
inverse_rows=[]
for kv in ks:
 av,sv=parameters(kv);D0=4*kv**2/(1+kv)**2
 for dv,nexpect in [(-S.Rational(1,100),0),(S.Integer(0),1),(D0/3,2),(D0,1),((D0+1)/2,1),(S.Integer(1),0),(S.Rational(6,5),0)]:
  roots=inverse(kv,dv);tag=str(kv)+':'+str(dv);ck('inverse_physical_root_count:'+tag,len(roots)==nexpect,[str(x) for x in roots]);ck('inverse_all_roots_admissible:'+tag,all(bool(0<x<av) for x in roots))
  if dv==D0/3:ck('inverse_both_sign_branches:'+tag,len(roots)==2 and roots[0]<kv<roots[1])
  for ri,qq in enumerate(roots):
   cc=dv*(1+kv)**2/4;eq('inverse_exact_quadratic:'+tag+':'+str(ri),(qq-kv)**2+3*cc*(qq-kv)-cc*(1-3*kv))
   if bool(0<qq<av):
    ee=(av-qq)/((1-3*av)*sv*qq);uu=mp.log(m(ee))/(2*mp.sqrt(m(av)));close('inverse_raw_action_reconstruction:'+tag+':'+str(ri),force(m(kv),uu),1-m(dv))
  inverse_rows.append(dict(k=str(kv),D=str(dv),D0=str(D0),expected_roots=nexpect,actual_roots=[str(x) for x in roots]))
data['inverse_domain_rows']=inverse_rows
# Diverging local inverse speed coefficient at the fixed interior turning point.
condition=[]
kv=mp.mpf(2)/17;av,sv=parameters(kv)
for sign in [-1,1]:
 prev=None
 for n in [4,7,10]:
  qq=kv+sign*mp.power(10,-n);ee=(av-qq)/((1-3*av)*sv*qq);uu=mp.log(ee)/(2*mp.sqrt(av));lc=Lchi(kv,uu);ratio=abs(1/lc)
  ck('finite_nonzero_derivative:'+str(sign)+':'+str(n),lc!=0)
  if prev is not None:ck('conditioning_growth:'+str(sign)+':'+str(n),ratio>prev*900)
  prev=ratio;condition.append(dict(side=sign,delta_exponent=-n,inverse_derivative=mp.nstr(ratio,45)))
data['conditioning']=condition
# Diagnostic windows are not dynamics. Direct raw-action forward readout is used.
kv=mp.mpf(2)/17;av,sv=parameters(kv);vv=mp.mpf(1)/7000;T=mp.mpf(7)/3;bb=1-3*kv;BB=(1+kv)**2
def fromq(qq):
 ee=(av-qq)/((1-3*av)*sv*qq);return force(kv,mp.log(ee)/(2*mp.sqrt(av)))
ck('linear_q_window_domain',0<kv-vv*T<kv+vv*T<av and 3*vv*T<bb)
slope=mp.quad(lambda t:t*fromq(kv+vv*t),[-T,0,T])/(2*T**3/3);integral=-36*vv**3/(BB*T**3)*mp.quad(lambda t:t**4/(bb**2-9*vv**2*t**2),[0,T]);leading=-36*vv**3*T**2/(5*BB*bb**2);ratio=slope/leading
close('window_OLS_integral_identity',slope,integral);ck('window_nonzero_cubic_slope',slope<0);ck('window_derived_remainder_bound',1<ratio<1/(1-9*vv**2*T**2/bb**2),dict(ratio=mp.nstr(ratio,50),upper=mp.nstr(1/(1-9*vv**2*T**2/bb**2),50)))
data['q_linear_window']=dict(k='2/17',v='1/7000',T='7/3',slope=mp.nstr(slope,65),leading=mp.nstr(leading,65),ratio=mp.nstr(ratio,65),history_solved=False)
kv=mp.mpf(5)/23;av,sv=parameters(kv);cc=mp.mpf(1)/20000;T=mp.mpf(3)/2;bb=1-3*kv;BB=(1+kv)**2
def qe(t):return kv-3*cc*t*t/2+t*mp.sqrt(9*cc*cc*t*t+4*cc*bb)/2
for t in [-T,-T/3,mp.mpf(0),T/3,T]:
 qq=qe(t);ck('even_force_window_domain:'+str(t),0<qq<av);close('even_force_raw_identity:'+str(t),fromq(qq),1-4*cc*t*t/BB)
even_slope=mp.quad(lambda t:t*fromq(qe(t)),[-T,0,T])/(2*T**3/3);close('even_force_zero_fitted_slope',even_slope,mp.mpf(0));second=mp.diff(lambda t:fromq(qe(t)),0,2);close('even_force_nonzero_curvature',second,-8*cc/BB)
chi_speed=mp.sqrt(cc*bb)/(-2*mp.sqrt(kv)*(1+kv));close('even_force_canonical_time_curvature',second,-32*kv/(1-3*kv)*chi_speed**2)
data['even_force_window']=dict(k='5/23',c='1/20000',T='3/2',OLS_slope=mp.nstr(even_slope,65),second_derivative=mp.nstr(second,65),canonical_crossing_speed=mp.nstr(chi_speed,65),history_solved=False)
# Exact correction-amplitude counterwitnesses do not purport to be physical apparatus models.
epsilon=S.Rational(1,1000000);omegas=[S.Integer(1000),S.Integer(1000000)];counter=[]
for omega in omegas:
 drift=epsilon*omega;curv=-epsilon*omega**2/(1+epsilon);ck('small_amplitude_not_derivative_bound:'+str(omega),drift>epsilon and abs(curv)>epsilon);counter.append(dict(amplitude=str(epsilon),omega=str(omega),sin_drift_at_zero=str(drift),cos_log_second_at_zero=str(curv)))
data['correction_counterexamples']=counter
result=dict(scope='Independent action-to-force, canonical turning, inverse-domain and ideal finite-window controls; no producer access, empirical fit or solved history.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),precision_digits=80,passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),checks=checks,data=data)
cfg.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failed_rows=[x['name'] for x in checks if not x['passed']]),indent=2));raise SystemExit(bool(result['failed']))
