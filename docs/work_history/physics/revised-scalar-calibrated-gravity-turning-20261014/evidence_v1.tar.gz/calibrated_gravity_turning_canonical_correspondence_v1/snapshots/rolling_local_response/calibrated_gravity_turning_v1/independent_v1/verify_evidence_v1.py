#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,difflib
O=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text());rows=[]
def ck(n,v,d=None):rows.append(dict(name=n,passed=bool(v),detail=d))
f=j(O/'SOURCE_FREEZE_v1.json');disp=j(O/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions'];ck('four_explicit_sources',len(f['source_pairs'])==len(disp)==4)
for x in f['source_pairs']:ck('source_snapshot:'+Path(x['original_path']).name,sha(Path(x['original_path']))==sha(Path(x['recovery']))==x['sha256'])
for x in disp:ck('disposition:'+Path(x['original_path']).name,sha(Path(x['original_path']))==x['original_sha256']==sha(Path(x['recovery']))==x['recovery_sha256']==sha(Path(x['final_path']))==x['final_sha256'])
baseline=j(O/'baseline_v1/RESULTS.json');exe=j(O/'baseline_v1/EXECUTION.json');code=O/'check_turning_independent_v1.py'
ck('baseline_287_0',baseline['passed']==287 and baseline['failed']==0 and len(baseline['checks'])==287 and all(x['passed'] for x in baseline['checks']))
ck('baseline_code_binding',baseline['source_sha256']==exe['source_sha256']==sha(code));ck('baseline_exit_stderr',exe['exit_code']==0 and (O/'baseline_v1/STDERR.txt').read_bytes()==b'')
ck('baseline_hand_and_protocol_binding',exe['hand_derivation_sha256']==sha(O/'HAND_DERIVATION_v1.md') and exe['protocol_sha256']==sha(O/'INDEPENDENT_PROTOCOL_v1.json'))
protocol=j(O/'damages_v1/PROTOCOL_v1.json');summary=j(O/'damages_v1/SUMMARY_v1.json');post=j(O/'damages_v1/INPUTS_POST_v1.json');ck('five_actual_damages',len(protocol['changes'])==len(summary)==5)
expected={'omit_scalar_force':(177,110),'wrong_deficit_denominator':(261,26),'wrong_canonical_scale':(249,38),'omit_inverse_domain':(281,24),'discard_inverse_branch':(275,6)}
base_text=code.read_text();fixed=lambda d:[{k:x[k] for k in ['k','D','D0','expected_roots']} for x in d['data']['inverse_domain_rows']]
for change in protocol['changes']:
 name=change['name'];src=O/'damages_v1'/(name+'.py');run=O/'damages_v1'/name;result=j(run/'RESULTS.json');execution=j(run/'EXECUTION.json');summ=next(x for x in summary if x['name']==name)
 ck('actual_one_change:'+name,base_text.count(change['before'])==1 and base_text.replace(change['before'],change['after'])==src.read_text())
 ck('actual_exact_diff:'+name,''.join(difflib.unified_diff(base_text.splitlines(True),src.read_text().splitlines(True),fromfile=code.name,tofile=src.name))==(O/'damages_v1'/(name+'.diff')).read_text())
 ck('actual_source_hash:'+name,sha(src)==result['source_sha256']==execution['source_sha256']==summ['source_sha256'])
 ck('actual_counts_exit:'+name,(result['passed'],result['failed'])==expected[name] and len(result['checks'])==sum(expected[name]) and execution['exit_code']==summ['exit_code']==1 and (run/'STDERR.txt').read_bytes()==b'')
 ck('actual_failed_witness:'+name,summ['required_witness_failed'] and any(x['name']==change['required_witness'] and not x['passed'] for x in result['checks']))
 ck('complete_fixed_inverse_fixtures:'+name,fixed(result)==fixed(baseline) and len(result['data']['inverse_domain_rows'])==21)
 ck('all_failed_rows_preserved:'+name,summ['all_failed_rows']==[x for x in result['checks'] if not x['passed']])
ck('source_hand_protocol_unchanged_across_damages',post['all_unchanged'] and protocol['input_freeze']==post['input_rows'] and all(sha(Path(x['path']))==x['sha256'] for x in post['input_rows']))
for x in j(O/'COMMAND_INDEX_v1.json')['executions']:ck('exact_command_record:'+x['record'],sha(O/x['record'])==x['record_sha256'])
ck('no_parent_access_claim',j(O/'ACCESS_HISTORY_v1.json')['new_producer_source_or_results_read'] is False)
result=dict(at=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,scope='Evidence integrity only, not additional scientific controls.')
(O/'EVIDENCE_VERIFICATION_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failed_rows=[x for x in rows if not x['passed']]),indent=2));raise SystemExit(bool(result['failed']))
