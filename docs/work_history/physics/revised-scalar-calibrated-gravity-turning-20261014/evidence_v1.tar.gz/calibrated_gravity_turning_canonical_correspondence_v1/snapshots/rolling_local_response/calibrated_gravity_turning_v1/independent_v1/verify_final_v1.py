#!/usr/bin/env python3
"""Read-only mathematics artifacts; final metadata verification writes only its result."""
from pathlib import Path
import datetime, hashlib, json
O=Path(__file__).resolve().parent
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((O/p).read_text())
checks=[]
def check(name,value):checks.append({'name':name,'passed':bool(value)})
pairs=read('SOURCE_FREEZE_v1.json')['source_pairs']+read('affected_v2/SOURCE_FREEZE_v1.json')['source_pairs']
check('nine_source_pairs',len(pairs)==9)
for r in pairs:
 check('live_snapshot:'+Path(r['original_path']).name,sh(Path(r['original_path']))==sh(Path(r['recovery']))==r['sha256'] and Path(r['recovery']).stat().st_size==r['bytes'])
rows=read('SOURCE_DISPOSITIONS_v2.json')['original_dispositions']
check('all_nine_dispositions',len(rows)==9)
for r in rows:
 check('disposition:'+Path(r['original_path']).name,sh(Path(r['original_path']))==sh(Path(r['recovery']))==sh(Path(r['final_path']))==r['original_sha256']==r['recovery_sha256']==r['final_sha256'])
for r in read('COMMAND_INDEX_v2.json')['executions']:
 e=read(r['record'])
 check('command:'+r['record'],sh(O/r['record'])==r['record_sha256'] and e['argv']==r['argv'] and sh(Path(e['argv'][1]))==e['source_sha256'])
check('frozen_original_report',sh(O/'REPORT_v1.md')=='385ade2e4319dabecd10b6d901ef2345c58b7d07f7e21317ccddd2bb21463ca9')
check('frozen_original_hand',sh(O/'HAND_DERIVATION_v1.md')=='46b4e5d9784cbc4061d4b37fd7cd28bf56971cb0e6fcbf1ee3c55447684d290e')
check('frozen_original_protocol',sh(O/'INDEPENDENT_PROTOCOL_v1.json')=='c659d8e4a6350b0af85c1f0f3fc850c28198a394ba821e198880305338712d4b')
base=read('baseline_v1/RESULTS.json')
check('original_287_0',base['passed']==287 and base['failed']==0 and base['source_sha256']==sh(O/'check_turning_independent_v1.py'))
meta=read('EVIDENCE_VERIFICATION_v1.json')
check('separate_core_integrity_57_0',meta['passed']==57 and meta['failed']==0 and len(meta['checks'])==57)
aff=read('affected_v2/RESULTS_v1.json')
check('affected_29_0',aff['passed']==29 and aff['failed']==0 and len(aff['checks'])==29)
check('affected_input_bindings',aff['hand_sha256']==sh(O/'affected_v2/HAND_CORRESPONDENCE_v1.md') and aff['reused_baseline_sha256']==sh(O/'baseline_v1/RESULTS.json') and aff['source_sha256']==sh(O/'affected_v2/check_correspondence_v1.py'))
for name,total in [('omit_scalar_force',(177,110)),('wrong_deficit_denominator',(261,26)),('wrong_canonical_scale',(249,38)),('omit_inverse_domain',(281,24)),('discard_inverse_branch',(275,6))]:
 d=read('damages_v1/'+name+'/RESULTS.json');e=read('damages_v1/'+name+'/EXECUTION.json')
 check('actual_failed_damage:'+name,(d['passed'],d['failed'])==total and e['exit_code']==1 and sh(O/'damages_v1'/f'{name}.py')==d['source_sha256']==e['source_sha256'])
check('no_unexpected_stderr',all((O/p).read_bytes()==b'' for p in ['baseline_v1/STDERR.txt','affected_v2/STDERR_v1.txt','EVIDENCE_VERIFICATION_STDERR_v1.txt']+[f'damages_v1/{n}/STDERR.txt' for n in ['omit_scalar_force','wrong_deficit_denominator','wrong_canonical_scale','omit_inverse_domain','discard_inverse_branch']]))
access=read('ACCESS_HISTORY_v2.json')
check('late_access_exposure_distinguished',access['new_producer_source_or_results_read'] is False and access['source_pair_count']==9 and '114/1' in access['parent_aggregate_exposure'])
report=(O/'REPORT_v2.md').read_text()
check('report_current_source_and_counts',all(s in report for s in ['02e50e44f4867821ff82e614c3ba2cfa8540ca391b297ff4fcfdea6dd5e2ce87','29/0','287/0','late parent attestation']))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final artifact/source correspondence, not a scientific rerun','source_sha256':sh(Path(__file__)),'report_sha256':sh(O/'REPORT_v2.md'),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks}
with (O/'FINAL_VERIFICATION_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
raise SystemExit(int(result['failed']!=0))
