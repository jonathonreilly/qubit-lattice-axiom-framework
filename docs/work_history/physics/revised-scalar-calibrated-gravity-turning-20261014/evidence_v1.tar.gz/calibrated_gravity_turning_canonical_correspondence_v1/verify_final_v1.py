#!/usr/bin/env python3
"""Final evidence identities only, no scientific or wrapper rerun."""
from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_text())
checks=[]
def ck(n,b):checks.append({'name':n,'passed':bool(b)})
pairs=sum([rd(O/f'SOURCE_FREEZE_v{i}.json')['source_pairs'] for i in range(1,5)],[])
rows=rd(O/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
ck('all_134_versions_133_paths',len(pairs)==len(rows)==134 and len({r['original_path'] for r in rows})==133)
index={(r['original_path'],r['original_sha256']):r for r in rows}
for p in pairs:
 row=index[(p['original_path'],p['sha256'])]
 ck('binding:'+str(Path(p['snapshot_path']).relative_to(O)),p['snapshot_path']==row['recovery'] and sh(Path(row['recovery']))==p['sha256']==row['original_sha256']==row['recovery_sha256'] and sh(Path(row['final_path']))==row['final_sha256'] and Path(row['recovery']).stat().st_size==p['bytes'])
ck('one_explicit_historical_version',sum(r['historical_version'] for r in rows)==1)
for name,expected in [('CORRESPONDENCE_RESULTS_v1.json',(429,0)),('WRAPPER_RESULTS_v1.json',(41,0))]:
 r=rd(O/name);ck('check_counts:'+name,(r['passed'],r['failed'])==expected and len(r['checks'])==sum(expected) and all(x['passed'] for x in r['checks']))
 code=O/('check_correspondence_v1.py' if name.startswith('CORRESPONDENCE') else 'check_wrapper_v1.py')
 ck('check_code:'+name,r['source_sha256']==sh(code))
for n in ['CORRESPONDENCE','WRAPPER']:
 r=rd(O/f'{n}_EXECUTION_v1.json')
 ck('new_execution:'+n,r['exit_code']==0 and sh(Path(r['argv'][1]))==r['source_sha256'] and (O/f'{n}_STDERR_v1.txt').read_bytes()==b'')
cmds=rd(O/'COMMAND_INDEX_v1.json')['executions']
ck('eleven_command_records',len(cmds)==11)
for c in cmds:
 r=rd(O/c['record']);ok=sh(O/c['record'])==c['record_sha256'] and r['argv']==c['argv']
 if 'harness_sha256' in r:ok=ok and sh(Path(r['argv'][1]))==r['harness_sha256'] and sh(Path(r['argv'][2]))==r['source_sha256']
 else:ok=ok and sh(Path(r['argv'][1]))==r['source_sha256']
 ck('command:'+c['record'],ok)
wr=rd(O/'WRAPPER_RESULTS_v1.json')
ck('nine_wrapper_processes_seven_nonzero',len(wr['executions'])==9 and sum(r['exit_code']!=0 for r in wr['executions'])==7 and all(r['science_executed'] is False for r in wr['executions']))
prior=O/'snapshots/rolling_local_response/calibrated_gravity_turning_v1/independent_v1'
pr=rd(prior/'RECEIPT_v1.json')
ck('reused_science_receipt_immutable',sh(prior/'RECEIPT_v1.json')==sh(Path(pr['write_root'])/'RECEIPT_v1.json')=='42cf4a396dd6e9dea6e3814d532ba74b4faede10499384d51401e11d8c24a198')
report=(O/'REPORT_v1.md').read_text()
ck('report_stage_identities',all(s in report for s in ['72652a3bb14b31064fd324a88d3f4f46e011c0951cf7d87a138a7ab21cbb8e38','4d24ec2d014f6ee37af35caa7ce91dc8882ec23bb68aafe65f5048a6e0ae8c41','429/0','41/0','114/1','115/0','separately prepared metadata-formatting copy']))
ck('report_preserves_coordinate_correction','not strict in all scalar directions' in report and 'No science equation' in report)
access=rd(O/'ACCESS_HISTORY_v1.json')
ck('post_seal_producer_access',access['producer_access_started']>access['prior_sealed_at'][:19]+'Z' and access['scientific_program_rerun'] is False)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final source/artifact/command identities only','source_sha256':sh(Path(__file__)),'report_sha256':sh(O/'REPORT_v1.md'),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'checks':checks}
with (O/'FINAL_VERIFICATION_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_checks':[r for r in checks if not r['passed']]},indent=2))
raise SystemExit(int(result['failed']!=0))
