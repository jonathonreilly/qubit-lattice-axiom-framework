#!/usr/bin/env python3
"""Execute unchanged wrapper main, replacing the scientific function with a labeled stub."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json, runpy, tempfile

source=Path(sys.argv[1]);case=Path(sys.argv[2]);mode=sys.argv[3]
namespace=runpy.run_path(str(source),run_name='canonical_wrapper_stub')
glob=namespace['main'].__globals__
failed=2 if mode in {'failed_explicit','failed_temporary','return_mismatch'} else 0
payload={'passed':3,'failed':failed,'scope':'WRAPPER STUB ONLY: no scientific check executed','checker_sha256':'LABLED-STUB-NOT-SCIENCE','nested':{'case':mode,'complete_payload':[0,False,None,'lambda λ']},'checks':[{'name':'stub-marker','passed':failed==0}]}
marker='WRAPPER STUB stdout '+mode+'\n'

def stub(out):
    out.mkdir(parents=True,exist_ok=False)
    with (case/'CALL.json').open('x') as f:json.dump({'out':str(out),'payload':payload,'stdout':marker,'mode':mode},f,indent=2);f.write('\n')
    if mode=='malformed_result':
        (out/'RESULTS.json').write_text('deliberately malformed stub JSON\n')
    elif mode!='missing_result':
        (out/'RESULTS.json').write_text(json.dumps(payload,indent=2)+'\n')
    print(marker,end='')
    return 0 if mode=='return_mismatch' else failed

glob['check_turning']=stub
glob['TemporaryDirectory']=lambda prefix:tempfile.TemporaryDirectory(prefix=prefix,dir=case)
args=[str(source)]
if mode not in {'success_temporary','failed_temporary'}:
    args+=['--profiles',str(case/'profiles'),'--out',str(case/'OUTPUT.json')]
sys.argv=args
raise SystemExit(namespace['main']())
