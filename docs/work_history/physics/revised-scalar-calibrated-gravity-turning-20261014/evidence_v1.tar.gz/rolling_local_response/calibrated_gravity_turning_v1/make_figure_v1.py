from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import hashlib,json
root=Path(__file__).resolve().parent
k=.1;a=(1-k)*(1+3*k)/4
q=np.linspace(.00001,a*.99999,1000)
A2=4*(a-q)/((1+k)*(1-3*q));bare=A2/(1+k);total=bare*(1+q)
d=(a-q)*(1-3*q)/(1-3*a);derivative=2*np.sqrt(q)*(1-d/(1+q))
fig,axes=plt.subplots(1,2,figsize=(10.8,4.4))
axes[0].plot(q,total,label="Total force / reference",color="#1764ab",lw=2)
axes[0].plot(q,bare,label="Bare metric part / reference",color="#777777",ls="--")
axes[0].plot(q,bare*q,label="Scalar part / reference",color="#c28716")
axes[0].scatter([k],[1],color="#1764ab",zorder=5);axes[0].set(ylabel="Gravity coefficient / free reference",xlabel="Local coupling q = beta squared",title="Total force has a maximum")
axes[1].plot(q,derivative,label="Total force: d ln G / d chi",color="#1764ab",lw=2)
axes[1].plot(q,2*np.sqrt(q),label="Bare metric: d ln G / d chi",color="#777777",ls="--")
axes[1].scatter([k],[0],color="#1764ab",zorder=5);axes[1].axhline(0,color="black",lw=.7)
axes[1].set(xlabel="Local coupling q = beta squared",ylabel="Canonical field derivative",title="First-order scalar sensitivity vanishes")
for ax in axes:
 ax.axvline(k,color="#999999",lw=.7,ls=":");ax.set_xlim(0,a);ax.grid(alpha=.16);ax.legend(fontsize=8,loc="best")
fig.text(.5,.035,"Illustration: supplied k = 0.1; ideal weak, common-background, long-range force. No orbital fit.",ha="center",fontsize=9)
fig.tight_layout(rect=(0,.08,1,1))
for suffix in ["png","pdf"]:fig.savefig(root/("CALIBRATED_GRAVITY_TURNING_v1."+suffix),dpi=180)
np.savez_compressed(root/"FIGURE_CURVES_v1.npz",q=q,A2=A2,bare=bare,total=total,canonical_derivative=derivative,k=k,a=a)
(root/"FIGURE_SOURCE_v1.json").write_text(json.dumps({"k":k,"role":"Analytic illustration of previously checked identities; no new observation or statistical fit","script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"point_count":len(q)},indent=2)+"\n")
