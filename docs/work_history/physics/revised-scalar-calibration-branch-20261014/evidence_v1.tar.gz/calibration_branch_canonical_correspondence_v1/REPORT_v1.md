# Staged calibration and negative-branch correspondence

Scientific author: /root. Correspondence checker: /root/scalar_energy_check. This report concerns the staged canonical bytes only. It reuses two sealed independent mathematical checks; it does not repeat either scientific baseline, provide a formal audit grade, establish a live cache, certify a recovery archive, or authorize landing.

The staged note faithfully retains both checked hand derivations. The two computational blocks are exact AST ports with their run functions renamed, and every scientific output field agrees with the original baseline. The new output wrapper preserves complete unit data and propagates failed controls. No source correction is required for this staged correspondence. The future archive/link, installed files, cache fingerprint and commit identity remain separate delivery checks.

The new correspondence execution passed 552 identity, AST, output and scope checks. The actual main wrapper, executed with controlled stand-ins for the scientific functions, passed 65 checks. Two actual altered wrapper files each failed three intended controls. Those are wrapper controls, not fresh physics. The supplied full staged execution is 174/0, consisting of 40 laboratory and 134 solar-branch checks. Its three actual full damaged runs are preserved as 163/11, 169/5 and 122/52. None of these counts is an empirical sample size or a count of independent theorems.

## Frozen identities and reused mathematics

The staged note is `EXPONENTIAL_SCALAR_CALIBRATION_BRANCH_BOUNDED_THEOREM_NOTE_2026-10-14.md`, SHA256 `f1ba3a93f044c0c75ff3fcc490d36bc2cf78d0d3a9c9551661fc254b8c35ffe2`. The staged runner is `exponential_scalar_calibration_branch_check.py`, SHA256 `91270f0b3d7194db2de8687805df5eb4ff490da94552225427c6b1a178173219`. The complete staged result has SHA256 `a98d4f137f31803d744d33dfd0e62a82717d2e1a01d5b2825b377d4cf0e74021`.

There are 269 byte-exact source/snapshot pairs. These preserve the complete packaging folder, both scoped original units and their sealed independent evidence, and the three named canonical premises. SOURCE_BINDINGS_v1.json records every original path, recovery path, byte count, role and hash. SOURCE_DISPOSITIONS_v1.json gives an unchanged-original/final disposition for every one. Byte preservation does not mean that every archived historical item received a new scientific review.

I read the full laboratory independent report and receipt, verified all 66 manifest artifacts, its 13 receipt references and all three original/snapshot pairs. Its mathematical baseline was 79/0, with five separately executed damaged programs. The report's exact scope, finite high-precision method, signed near-null witnesses, and lack of a real-apparatus likelihood are reused. The primary PDF was previously read and rendered by that independent checker; I verified its identity rather than repeating the PDF review.

The laboratory reused identities are:

- Report: `40c589e38e9063fa328ddab62356fb558f6465d9064ef16c1c5c978d7123fa89`.
- Manifest: `42be6a342b410647df3a62ed23167df5428cc8a52e2cea82bbc837e02e7905ec`.
- Receipt: `3b4ff1addb63ad33521243cb2b31e83733d02c4a966310bc2a4c46263a01754e`.

The solar independent report was completed and fully read in this checker's preceding unit. I verified its 73 manifest artifacts, 39 receipt references and five source pairs without modifying or rerunning them. That independent baseline was 231/0, with five actual changed programs rejected. Its exact action contraction, branch-domain proof, inverse relation, interval counterexamples and normalization/range distinctions remain the mathematical basis of this correspondence.

The solar reused identities are:

- Report: `610d228eab7fd519232c3836c63f7c62a4d98a842011ecb8bab59906253c4743`.
- Manifest: `ef53b8ac2a39d97f3e3e46735686fc3dbddace7deb0dece639a6cd78b2cedac1`.
- Receipt: `366bc2ec66fbaa2e52beb3c0f4539fed2169a3e37ec92dd3c8b5a46a07b3a0e0`.

The original laboratory hand source is `8c4a9f2c8fc668e37355f8955e44dae0c53bf4fcd900c053b456874bab2ac1b1`; the solar hand source is `3ec70620dade0fd5367cd7ec93edaad951e536b3ab2573e34dcce00eaa7e2bc0`. The staged note contains both entire bodies, each exactly once and in the original order, with only one extra heading marker per original Markdown heading. No equation, premise, numerical case or limitation is omitted by that transformation.

## Meaning of the canonical claims

The laboratory block retains the common frozen, weak, unscreened, quasistatic background, pressure-negligible sources, supplied single range/weight, rigid geometry, common gain and common demodulation premises. With nonzero Newtonian harmonics and nonzero calibration response, the measured normalized model is

    R_j=(1+q y_j)/(1+q y_c).

The q inverse additionally requires its denominator to be nonzero. Equal response factors remove identification, while unequal factors do not remove noise or nuisance correlations. At zero inverse range the normalized ratio is exactly one. That is a calibration degeneracy, not equivalence of the whole theory to general relativity.

The leading correction remains q*mu^2*(L_j-L_c)/(2*(1+q)). It is an expansion for each fixed separated compact geometry and nonvanishing normalization, without a universal sign or a uniform bound near a torque null. The two positive-mass ring toys are explicitly distinguished from the actual wedge apparatus. Their prescribed q=0.2 is synthetic. Finite quadrature and displayed asymptotic samples support the hand argument; they are neither certified all-parameter quadrature nor an observed laboratory sensitivity. The separately checked potential-Fourier and full-pair route is reused as independent mathematical support, not relabeled as a new staged run.

The solar block retains 0<k<1/3 and finite u<=0. The original action gives q=a/J, the strict upper limit q<a, the lower floor q>=k, and the exact inverse

    1-A^2=(1-3k)(q-k)/[(1+k)(1-3q)].

Consequently a supplied k<=q<=qmax<1/3 bounds the conformal change. Equality q=k fixes the conformal reference A=1; it does not by itself specify all transverse fields, matter or a complete vacuum state. Positive-u points need not obey the lower floor. The stationary density interpretation is conditional: neither a realized density profile nor a body's nonlinear charge, mass range or relaxation is obtained from the norm inequality.

The supplied gamma relation is a weak, long-range, unscreened local bridge with separately controlled source/matching/error assumptions. The benchmark cap uses a lower-edge condition, 2q/(1+q)<=epsilon_gamma-L. The appended text correctly states that a general two-sided interval also requires the upper-edge condition. Here its positive upper endpoint makes the latter automatic for the symmetric error envelope and nonnegative q. This is existence of an allowed envelope intersection, not a guarantee for the actual unknown correction. Unlimited bridge error gives no useful bound.

The exact benchmark qmax=1/79999 and conformal ceiling 1/79996 are transparent transformations of the chosen central-value plus/minus two-reported-error interval. They are not newly fitted confidence limits. Gvac is explicitly a theoretical bare reference; the locally unsuppressed force normalization is Gbare*(1+q). The source does not derive scalar range, screening, solar matching, a cosmological G calibration, a selected k or state, or a theory-wide exclusion.

The two blocks expose complementary measurement requirements. They are not a joint multi-instrument fit and do not establish that one actual ambient field/range simultaneously realizes both conditional regimes. The complete supplied action, local-response premises and environment definitions remain named inputs.

## Primary access and added prose

The original hand bodies retain the access history as written. The appended canonical paragraph updates that history rather than pretending the first version had already acquired the full source. The parent's public-abstract inspection record and the prior independent inspection bind the same saved Nature HTML, SHA256 `5ac46e690c57f4e7ef1994ed69bc33efd307006b416de290c18b62ecd655e110`. They agree on the reported gamma estimate and the subscription-preview limitation. No full article or likelihood is claimed.

The laboratory source is the same Lee PDF bound by its independent receipt, SHA256 `ffcddf6d2c1a758f07112a3125ae8583254a3089b1022ac2cf459a052652504c`. The staged note distinguishes the published gravitational-strength range limit from this smaller candidate coupling. The real torque data, covariance, numerical supplement and full nuisance likelihood are not present. Both publications are exposed methodological/development inputs, not withheld validation data. This correspondence made no network request or new empirical acquisition.

The prefix and suffix are preserved separately as NOTE_PREFIX_v1.txt and NOTE_SUFFIX_v1.txt. Their new claims are limited to assembly, access history, validation lineage, the general-interval clarification and surviving assumptions. Their recovery-archive link is a prospective delivery link in this staged document. Its eventual target/content must be verified when the archive and live paths are supplied; this report does not assert that archive already exists.

## Exact computational ports and complete outputs

The original parent laboratory v2 runner has SHA256 `42210488397b872377a655d4039bc490a8d431011b39a82ff333253194492c96`; the original solar runner has SHA256 `57d1bd8574391b1d20fd1392396639b0e8b2926469ce757bacd3f2aa4b6eed06`.

I parsed the original programs independently of the builder, retained every top-level import, assignment and function, renamed only run to check_calibration or check_branch, and compared the complete ordered AST with the staged computational region. Both full function bodies and all retained top-level nodes match. The excluded nodes are only the original module docstring where present and command-line main guard. No test, tolerance, data table, conditional or expression was removed. Comments/formatting are not executable AST semantics. The transformed AST hashes also match the declared lineage.

The remaining nodes are the header imports, a 120-second runtime declaration, four input paths, and the new main/entry guard. Repeated Path/json/hashlib/argparse imports refer to the same modules; the symbolic aliases s and S remain distinct. The mp.mp.dps=75 assignment remains inside the calibration function and sets mpmath's process context; the branch expressions use SymPy and acquire no mpmath dependency. There is no new dependency on an older saved result: the wrapper reads the newly generated calibration result and immediately calls the branch function.

The saved staged source hash, exit 0, complete stdout and result bytes agree; stderr is empty. The nested calibration stdout parses to the complete calibration unit, and the profile result is identical. Every original scientific JSON key, value, nested row, diagnostic, threshold comparison and scope string matches. The sole excluded comparison field is the actual checker_sha256, which correctly changes with the assembled runner. All three staged self-hashes point to the staged source.

The retained laboratory data include all nine range records and both Newtonian harmonics and r-moment ratios. The branch unit includes all 20 k/A cases, three error-budget bounds, benchmark definitions and every one of its 134 check rows. The count is a tally of asserted controls; some domain rows are simple witnesses. The complete-domain results still rest on the checked hand proofs, not on the finite grid or tally.

## Failure preservation and actual stage damages

The original laboratory baseline is still 39/1, exit 1. Its only failed row is inverse_mu_100000, returning approximately 0.199999999999999999999999999995105 rather than 0.2 within the frozen 1e-35 requirement. The ratio differs from one by about 4.16e-23. The exact v1-to-v2 source difference is solely mp.mp.dps=50 to 75. All 40 check names, cases, formulas and acceptance thresholds are unchanged. The fresh v2 result is 40/0; neither the failure nor the source bytes were overwritten. The staged body uses that v2, not a claimed clean v1.

The earlier local TLS certificate failure, successful normal-TLS fallback, missing-bs4 parser failure and standard-library parsing route are preserved in the source history. The independent laboratory pre-seal word-count correction, 112 to 106, is preserved with the original draft and exact diff; it did not alter the mathematics or executed inputs. The solar independent seal's late aggregate-count exposure is retained exactly; the present authorized producer-file access is a later correspondence phase and does not rewrite that blind history.

Three actual full staged damaged programs are separate one-replacement copies of the final staged runner. Their source hashes, execution records, full stdout/result bytes, empty stderr, nested calibration output and complete 174-row tallies agree:

| Changed staged expression | Passed/failed | Mathematical witness |
|---|---:|---|
| Omit calibration denominator | 163/11 | massless_calibration_degeneracy |
| Gamma coefficient 2 to 1 | 169/5 | gamma_relation |
| Coupling denominator coefficient 3 to 2 | 122/52 | coordinate_inversion |

Every required witness actually failed and each full process exited 1. These were not rejected merely because their source hash changed. All failed rows are retained in CORRESPONDENCE_RESULTS_v1.json and the failure ledger. The original units' older damaged records are also byte-preserved, but are not relabeled as fresh executions of this assembled runner.

## New wrapper controls and their limits

The wrapper-only checker extracts the actual main AST from the frozen runner and supplies synthetic stand-ins for check_calibration and check_branch. It does not import or invoke the mathematical implementations or their numerical libraries. The stand-ins produce distinguishable complete nested tables, stdout, result files and independent passed/failed counts.

Eight cases cover successful explicit output, calibration failure, branch failure, simultaneous failures, default temporary-directory cleanup, refusal of existing profiles, preservation of an existing output file, and rejection of a calibration return/result-count disagreement. All 65 assertions passed. The temporary-directory constructor was confined to this checker's owned directory. The existing-output guard happens after the calculations; its test confirms preservation of that file, not transactional rollback of profile generation. No broader atomicity claim is made.

Two actual changed full runner copies were then used with the same wrapper-only harness. Dropping the calibration failed count produced 62/3; hiding the failed exit status produced 62/3. Both exited 1 in the control harness and failed the intended aggregation/exit witnesses. These are deliberately altered wrapper executions with stub scientific bodies. They are distinct from the parent's three complete scientific damaged runs. All changed files, diffs, execution records, expected guard exception traces, stdout/stderr and output data are preserved.

There was no unexpected correspondence or wrapper failure and no required correction. Expected guard assertions and deliberately induced failures are labeled rather than erased.

## Disposition and completion boundary

All 269 frozen inputs remain unchanged and recoverable through explicit original/snapshot/final mappings. For the staged note and runner the verified final path is still their staging path; separate fields record the intended docs/scripts destinations. No absent live destination is certified. The final manifest includes the complete recovered source inventory, new comparison code and results, wrapper code/cases/damages, command records, failure ledger and this full report. Old independent receipts remain immutable.

The runner declares the prospective canonical note plus the full-action, local-response and environment canonical notes as cache inputs. These three existing premises are snapshotted. A later installation must preserve the staged bytes and verify the actual cache's input fingerprint and full scientific payload, the recovery README/archive contents, and exact committed delivery identity. No fresh scientific rerun is needed for this correspondence result.

All writes were confined to calibration_branch_canonical_correspondence_v1. No parent/canonical source, old evidence, Git/branch/PR, runtime, lock, settings or audit state was modified. No new agent or external chat was used. The author remains /root. This is a staged correspondence conclusion with explicitly reused mathematical evidence, not landing authority.
