#!/usr/bin/env python3
"""Read-only comparison of frozen correspondence inputs; no science execution."""
from pathlib import Path
from datetime import datetime, timezone
import ast, copy, difflib, hashlib, json
O=Path(__file__).resolve().parent
W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PREFIX='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/'
S=O/'snapshots'/PREFIX
P=S/'calibration_branch_packaging'
L=S/'rolling_local_response/laboratory_yukawa_bridge_v1'
B=S/'rolling_local_response/solar_branch_bound_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=lambda p:json.loads(p.read_text())
rows=[];details={}
def ck(name, ok, detail=None):
 rows.append(dict(name=name,passed=bool(ok),detail=detail))
def dump(x):return ast.dump(x,include_attributes=False)
def ref(p):return {'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)}

bindings=j(O/'SOURCE_BINDINGS_v1.json')['source_pairs']
for x in bindings:
 snap=O/x['snapshot_path'];live=Path(x['original_path'])
 ck('snapshot_identity:'+x['original_repo_path'], live.read_bytes()==snap.read_bytes() and sha(snap)==x['sha256'] and len(snap.read_bytes())==x['bytes'])
seals=[]
for name,root,expect in [('laboratory',L/'independent_v1',66),('solar',B/'independent_v1',73)]:
 receipt=j(root/'RECEIPT_v1.json');manifest=j(root/'MANIFEST_v1.json')
 ck(name+'.manifest_identity',sha(root/'MANIFEST_v1.json')==receipt['manifest']['sha256'])
 ck(name+'.report_identity',sha(root/'REPORT_v1.md')==receipt['report']['sha256'])
 ck(name+'.artifact_count',len(manifest['artifacts'])==manifest['artifact_count']==receipt['artifact_count']==expect)
 for x in manifest['artifacts']:
  q=root/x['path'];ck(name+'.sealed_artifact:'+x['path'],q.is_file() and q.stat().st_size==x['bytes'] and sha(q)==x['sha256'])
 pairs=receipt.get('source_pairs',receipt.get('source_bindings'))
 for x in pairs:
  original=O/'snapshots'/Path(x['original_path']).relative_to(W)
  ck(name+'.reused_source:'+x['snapshot_path'],original.read_bytes()==(root/x['snapshot_path']).read_bytes() and sha(original)==x['sha256'])
 refs=[]
 def walk(x):
  if isinstance(x,dict):
   if {'path','bytes','sha256'}<=x.keys():
    q=root/x['path'];ck(name+'.receipt_ref:'+x['path'],q.stat().st_size==x['bytes'] and sha(q)==x['sha256']);refs.append(x['path'])
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(receipt)
 baseline=receipt.get('baseline_counts', {k:receipt.get('baseline',{}).get(k) for k in ['passed','failed']})
 ck(name+'.baseline_counts',baseline=={'passed':79 if name=='laboratory' else 231,'failed':0})
 seals.append(dict(name=name,receipt=ref(root/'RECEIPT_v1.json'),report=ref(root/'REPORT_v1.md'),manifest=ref(root/'MANIFEST_v1.json'),artifacts=expect,source_pairs=len(pairs),receipt_refs=len(refs),baseline=baseline,science_rerun=False))
details['reused_seals']=seals

lineage=j(P/'CANONICAL_LINEAGE_v1.json')
note=P/'staged'/lineage['canonical_note']['path'];runner=P/'staged'/lineage['canonical_runner']['path']
ck('stage.note_hash',sha(note)==lineage['canonical_note']['sha256']=='f1ba3a93f044c0c75ff3fcc490d36bc2cf78d0d3a9c9551661fc254b8c35ffe2')
ck('stage.runner_hash',sha(runner)==lineage['canonical_runner']['sha256']=='91270f0b3d7194db2de8687805df5eb4ff490da94552225427c6b1a178173219')
nt=note.read_text();nt_parts=[]
for name,src in [('calibration',L/'DERIVATION_v1.md'),('branch',B/'DERIVATION_v1.md')]:
 demoted='\n'.join('#'+line if line.startswith('#') else line for line in src.read_text().splitlines())
 ck(name+'.whole_hand_body_once',nt.count(demoted)==1)
 nt_parts.append(demoted)
left=nt.index(nt_parts[0]);middle=nt.index(nt_parts[1]);right=middle+len(nt_parts[1])
ck('note.body_order_and_separator',nt[left+len(nt_parts[0]):middle]=='\n\n')
(O/'NOTE_PREFIX_v1.txt').write_text(nt[:left]);(O/'NOTE_SUFFIX_v1.txt').write_text(nt[right:])

rt=ast.parse(runner.read_text());expected=[];ast_records=[]
for name,src,target,decl in [('calibration',L/'check_calibrated_torque_v2.py','check_calibration',lineage['scientific_sources'][0]),('branch',B/'check_branch_v1.py','check_branch',lineage['scientific_sources'][1])]:
 tree=ast.parse(src.read_text());keep=[];excluded=[]
 for node in tree.body:
  if isinstance(node,(ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef)):
   node=copy.deepcopy(node)
   if isinstance(node,ast.FunctionDef) and node.name=='run':node.name=target
   keep.append(node)
  else:excluded.append(node)
 ck(name+'.excluded_nodes_only_docstring_and_main_guard',all(isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) or isinstance(n,ast.If) and dump(n.test)==dump(ast.parse("__name__ == '__main__'",mode='eval').body) for n in excluded))
 ck(name+'.source_hash_matches_lineage',sha(src)==decl['sha256'])
 mod=ast.Module(body=keep,type_ignores=[]);digest=hashlib.sha256(dump(mod).encode()).hexdigest()
 ck(name+'.normalized_ast_matches_lineage',digest==decl['transformed_ast_sha256'])
 target_node=next(n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name==target)
 ck(name+'.full_function_ast_identity',dump(next(n for n in keep if isinstance(n,ast.FunctionDef) and n.name==target))==dump(target_node))
 expected+=keep
 ast_records.append(dict(name=name,source=ref(src),target=target,transformed_ast_sha256=digest,top_level_kept=len(keep),excluded_types=[type(n).__name__ for n in excluded]))
ck('all_computational_top_level_ast_in_order',dump(ast.Module(body=rt.body[6:-2],type_ignores=[]))==dump(ast.Module(body=expected,type_ignores=[])))
ck('only_two_final_wrapper_nodes',isinstance(rt.body[-2],ast.FunctionDef) and rt.body[-2].name=='main' and isinstance(rt.body[-1],ast.If))
ck('wrapper_timeout_120',isinstance(rt.body[4],ast.Assign) and ast.literal_eval(rt.body[4].value)==120)
inputs=ast.literal_eval(rt.body[5].value)
ck('four_declared_inputs',inputs==['docs/'+note.name,'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'])
for inp in inputs[1:]:ck('declared_input_snapshot:'+inp,(O/'snapshots'/inp).is_file())
details['ast_ports']=ast_records;details['declared_live_cache_inputs']=inputs

results=j(P/'STAGED_RESULTS_v1.json');execrow=j(P/'STAGED_RUN_v1.json')
ck('stage.execution_matches_source',execrow['runner_sha256']==sha(runner) and execrow['exit_code']==0)
ck('stage.complete_stdout_bytes',(P/'STAGED_RESULTS_v1.json').read_bytes()==(P/'STAGED_RUN_v1.stdout').read_bytes())
ck('stage.stderr_empty',(P/'STAGED_RUN_v1.stderr').read_bytes()==b'')
ck('stage.total_174_0',(results['passed'],results['failed'])==(174,0))
ck('stage.all_three_self_hashes',results['checker_sha256']==results['units']['calibration']['checker_sha256']==results['units']['branch']['checker_sha256']==sha(runner))
origins={'calibration':L/'baseline_v2/RESULTS.json','branch':B/'RESULTS_v1.json'}
output_records=[]
for name,source in origins.items():
 unit=results['units'][name];old=j(source)
 ck(name+'.complete_scientific_output_identity',{k:v for k,v in unit.items() if k!='checker_sha256'}=={k:v for k,v in old.items() if k!='checker_sha256'})
 ck(name+'.substantive_count',len(unit['checks'])==unit['passed']+unit['failed']==(40 if name=='calibration' else 134) and all(x['passed'] for x in unit['checks']))
 ck(name+'.unique_check_names',len({x['name'] for x in unit['checks']})==len(unit['checks']))
 output_records.append(dict(name=name,original=ref(source),all_keys=list(unit),checks=len(unit['checks']),data_tables={k:len(unit[k]) for k in ['records','bridge_bounds','synthetic_cases'] if k in unit},only_ignored_metadata_key='checker_sha256'))
ck('calibration.complete_captured_stdout',json.loads(results['calibration_execution_stdout'])==results['units']['calibration'])
ck('calibration.profile_file_complete',j(P/'staged_outputs_v1/calibration/RESULTS.json')==results['units']['calibration'])
ck('stage.aggregate_counts',results['passed']==sum(x['passed'] for x in results['units'].values()) and results['failed']==sum(x['failed'] for x in results['units'].values()))
details['complete_output_correspondence']=output_records

old=L/'check_calibrated_torque_v1.py';new=L/'check_calibrated_torque_v2.py'
ck('lab.precision_only_exact_change',old.read_text().count('mp.mp.dps=50')==1 and old.read_text().replace('mp.mp.dps=50','mp.mp.dps=75')==new.read_text())
oldres=j(L/'baseline_v1/RESULTS.json');newres=j(L/'baseline_v2/RESULTS.json')
ck('lab.first_failure_retained',(oldres['passed'],oldres['failed'])==(39,1))
failedold=[x for x in oldres['checks'] if not x['passed']]
ck('lab.first_failure_expected_witness',len(failedold)==1 and failedold[0]['name']=='inverse_mu_100000')
ck('lab.same_40_test_names',[x['name'] for x in oldres['checks']]==[x['name'] for x in newres['checks']])
ck('lab.result_source_hashes',oldres['checker_sha256']==sha(old) and newres['checker_sha256']==sha(new))
ck('lab.repair_counts',(newres['passed'],newres['failed'])==(40,0))
details['original_lab_failure']=failedold

plan=j(P/'damages_v1/PLAN_v1.json');summ=j(P/'damages_v1/SUMMARY_v1.json')
ck('stage.damage_base_hash',plan['base_sha256']==sha(runner))
expected_failures={'omit_calibration':(163,11,'massless_calibration_degeneracy'),'gamma_coefficient':(169,5,'gamma_relation'),'coupling_denominator':(122,52,'coordinate_inversion')}
damage_records=[]
for name,oldtext,newtext in plan['cases']:
 base=P/'damages_v1';src=base/(name+'.py');res=j(base/(name+'_results.json'));execution=j(base/(name+'_execution.json'));summary=next(x for x in summ if x['name']==name)
 ck(name+'.one_actual_source_change',runner.read_text().count(oldtext)==1 and runner.read_text().replace(oldtext,newtext)==src.read_text())
 ck(name+'.actual_execution_hash',sha(src)==execution['source_sha256']==summary['source_sha256']==res['checker_sha256'] and execution['exit_code']==summary['exit_code']==1)
 ck(name+'.full_stream_identity',(base/(name+'.stdout')).read_bytes()==(base/(name+'_results.json')).read_bytes() and (base/(name+'.stderr')).read_bytes()==b'')
 ck(name+'.all_self_hashes',all(x['checker_sha256']==sha(src) for x in res['units'].values()))
 ck(name+'.all_174_rows',sum(len(x['checks']) for x in res['units'].values())==174)
 ck(name+'.consistent_tally',res['passed']==sum(sum(t['passed'] for t in x['checks']) for x in res['units'].values()) and res['failed']==sum(sum(not t['passed'] for t in x['checks']) for x in res['units'].values()))
 ck(name+'.actual_counts',(res['passed'],res['failed'])==expected_failures[name][:2])
 failures=[dict(unit=u,**x) for u,r in res['units'].items() for x in r['checks'] if not x['passed']]
 ck(name+'.required_mathematical_witness',expected_failures[name][2] in [x['name'] for x in failures])
 ck(name+'.captured_calibration_stdout',json.loads(res['calibration_execution_stdout'])==res['units']['calibration'])
 ck(name+'.calibration_profile',j(base/(name+'_outputs/calibration/RESULTS.json'))==res['units']['calibration'])
 damage_records.append(dict(name=name,passed=res['passed'],failed=res['failed'],exit_code=execution['exit_code'],source=ref(src),result=ref(base/(name+'_results.json')),execution=ref(base/(name+'_execution.json')),all_failed_rows=failures))
details['actual_staged_damages']=damage_records

primary=j(B/'sources/PRIMARY_ABSTRACT_CHECK_v1.json');prior=j(B/'independent_v1/PRIMARY_INSPECTION_v1.json')
ck('nature.update_same_saved_page',primary['page_sha256']==prior['source_sha256']==sha(B/'sources/BERTOTTI_2003_PAGE_20261014.html'))
ck('nature.no_full_article_promotion','no full article or likelihood' in primary['access'])
ck('note.scope_and_new_upper_edge','upper edge supplies a separate intersection condition' in nt and 'No theory-wide observational exclusion' in nt)
ck('note.original_39_1_retained','laboratory39/1 failure' in nt and 'from50 to75 digits' in nt)
ck('note.explicit_toy_scope','It is not the paper\'s 18/120-fold wedge apparatus' in nt and 'not newly fitted parameter posteriors' in nt)
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,details=details,scope='Metadata, AST, prose-body and complete saved-output correspondence. No scientific function was called.')
(O/'CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[x['name'] for x in rows if not x['passed']],'source_pairs':len(bindings),'reused_seals':[(x['name'],x['artifacts'],x['source_pairs']) for x in seals]},indent=2))
raise SystemExit(bool(result['failed']))
