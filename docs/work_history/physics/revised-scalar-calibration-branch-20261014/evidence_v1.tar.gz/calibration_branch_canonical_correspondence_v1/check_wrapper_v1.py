#!/usr/bin/env python3
"""Execute only the actual main AST, with synthetic stand-ins for both proof bodies."""
from pathlib import Path
from contextlib import redirect_stdout, redirect_stderr
from tempfile import TemporaryDirectory
from datetime import datetime, timezone
import argparse, ast, hashlib, io, json, sys, traceback
p=argparse.ArgumentParser();p.add_argument('--runner',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
args.root.mkdir(parents=True,exist_ok=False)
runner=args.runner.resolve();tree=ast.parse(runner.read_text());main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
maincode=compile(ast.fix_missing_locations(ast.Module(body=[main],type_ignores=[])),str(runner),'exec')
rows=[];cases=[]
def ck(name,ok,detail=None):rows.append(dict(name=name,passed=bool(ok),detail=detail))
def unit(label,failed,passed):
 return dict(passed=passed,failed=failed,checks=[dict(name=label+'.pass'+str(i),passed=True) for i in range(passed)]+[dict(name=label+'.fail'+str(i),passed=False) for i in range(failed)],table=[dict(label=label,exact='-13/17',array=[2,7,19])],sentinel={'nested':['keep','all','rows']})
settings=[('success',0,0,'explicit'),('calibration_failure',2,0,'explicit'),('branch_failure',0,3,'explicit'),('both_failures',2,3,'explicit'),('temporary_success',0,0,'temporary'),('existing_profiles',0,0,'existing_profiles'),('existing_output',0,0,'existing_output'),('return_disagreement',0,0,'disagreement')]
for name,cf,bf,mode in settings:
 root=args.root/name;root.mkdir();cal=unit('calibration',cf,2);branch=unit('branch',bf,3);calls=[];temporaries=[]
 def calibrate(path):
  calls.append(['calibration',str(path)]);path.mkdir(parents=True,exist_ok=False)
  (path/'RESULTS.json').write_text(json.dumps(cal,indent=2)+'\n');print(json.dumps(cal,indent=2))
  return cal['failed']+(1 if mode=='disagreement' else 0)
 def branch_check():calls.append(['branch']);return branch
 def temporary(**kwargs):
  td=TemporaryDirectory(dir=root,**kwargs);temporaries.append(td.name);return td
 ns=dict(__file__=str(runner),argparse=argparse,Path=Path,io=io,json=json,hashlib=hashlib,redirect_stdout=redirect_stdout,TemporaryDirectory=temporary,check_calibration=calibrate,check_branch=branch_check)
 exec(maincode,ns)
 outfile=root/'combined.json';profiles=root/'profiles'
 av=[str(runner),'--out',str(outfile)]
 if mode!='temporary':av+=['--profiles',str(profiles)]
 if mode=='existing_profiles':profiles.mkdir();(profiles/'sentinel.txt').write_text('original')
 if mode=='existing_output':outfile.write_text('original')
 oldargv=sys.argv;sys.argv=av;stdout=io.StringIO();stderr=io.StringIO();error=None;value=None
 try:
  with redirect_stdout(stdout),redirect_stderr(stderr):value=ns['main']()
 except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
 finally:sys.argv=oldargv
 (root/'wrapper_stdout.txt').write_text(stdout.getvalue());(root/'wrapper_stderr.txt').write_text(stderr.getvalue())
 if mode in ['existing_profiles','existing_output','disagreement']:
  ck(name+'.expected_assertion',error is not None and error['type']=='AssertionError',error)
  ck(name+'.no_false_json_output',stdout.getvalue()=='')
  if mode=='existing_profiles':
   ck(name+'.no_proof_calls',calls==[]);ck(name+'.sentinel_preserved',(profiles/'sentinel.txt').read_text()=='original')
  elif mode=='existing_output':ck(name+'.existing_file_preserved',outfile.read_text()=='original')
  else:ck(name+'.branch_not_called',len(calls)==1 and calls[0][0]=='calibration')
 else:
  ck(name+'.no_exception',error is None,error)
  result=json.loads(stdout.getvalue()) if stdout.getvalue() else {}
  ck(name+'.complete_units',result.get('units')==dict(calibration=cal,branch=branch))
  ck(name+'.passed_sum',result.get('passed')==5)
  ck(name+'.failed_sum',result.get('failed')==cf+bf)
  ck(name+'.failure_exit',value==bool(cf+bf))
  ck(name+'.captured_calibration_stdout',result.get('calibration_execution_stdout')==json.dumps(cal,indent=2)+'\n')
  ck(name+'.output_stdout_bytes',outfile.read_text()==stdout.getvalue())
  ck(name+'.actual_runner_hash',result.get('checker_sha256')==hashlib.sha256(runner.read_bytes()).hexdigest())
  ck(name+'.call_order',[x[0] for x in calls]==['calibration','branch'])
  ck(name+'.stderr_empty',stderr.getvalue()=='')
  if mode=='temporary':ck(name+'.temporary_cleaned',len(temporaries)==1 and all(not Path(t).exists() for t in temporaries))
  else:ck(name+'.profile_retained',json.loads((profiles/'calibration/RESULTS.json').read_text())==cal)
 cases.append(dict(name=name,argv=av,calls=calls,main_return=value,error=error,temporary_paths=temporaries))
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,cases=cases,runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(),scientific_bodies_executed=False,scope='Actual main wrapper AST executed with controlled stubs; no SymPy, mpmath, quadrature or science baseline rerun.')
args.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[x['name'] for x in rows if not x['passed']]}));raise SystemExit(bool(result['failed']))
