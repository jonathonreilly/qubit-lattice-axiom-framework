from pathlib import Path
from datetime import datetime, timezone
import subprocess, hashlib, json, difflib, sys, time
O=Path(__file__).resolve().parent;S=O/'snapshots/.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/calibration_branch_packaging/staged/exponential_scalar_calibration_branch_check.py';C=O/'check_wrapper_v1.py'
D=O/'wrapper_damage_sources';D.mkdir(exist_ok=False)
mutations=[('drop_calibration_failure',"failed=calibration['failed']+branch['failed']","failed=branch['failed']"),('hide_failed_exit',"return bool(result['failed'])","return False")]
plan=[]
for name,old,new in mutations:
 text=S.read_text();assert text.count(old)==1;target=D/(name+'.py');target.write_text(text.replace(old,new));(D/(name+'.diff')).write_text(''.join(difflib.unified_diff(text.splitlines(True),target.read_text().splitlines(True),fromfile=S.name,tofile=target.name)));plan.append(dict(name=name,old=old,new=new,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(O/'WRAPPER_FREEZE_v1.json').write_text(json.dumps(dict(created_utc=datetime.now(timezone.utc).isoformat(),checker_sha256=hashlib.sha256(C.read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),mutations=plan,scope='Wrapper-only mutations executed with stub proof bodies; not full primary science executions.'),indent=2)+'\n')
records=[]
for label,source,expected in [('baseline',S,0)]+[(x['name'],D/(x['name']+'.py'),1) for x in plan]:
 output=O/('WRAPPER_'+label+'_RESULTS_v1.json');cmd=[sys.executable,'-B',str(C),'--runner',str(source),'--root',str(O/('wrapper_runtime_'+label)),'--out',str(output)]
 rec=dict(label=label,argv=cmd,cwd=str(Path.cwd()),started_utc=datetime.now(timezone.utc).isoformat(),checker_sha256=hashlib.sha256(C.read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),expected_exit=expected)
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True);rec.update(ended_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-t,exit_code=p.returncode)
 (O/('WRAPPER_'+label+'_STDOUT_v1.txt')).write_text(p.stdout);(O/('WRAPPER_'+label+'_STDERR_v1.txt')).write_text(p.stderr)
 if output.exists():
  z=json.loads(output.read_text());rec.update(passed=z['passed'],failed=z['failed'],failed_names=[x['name'] for x in z['checks'] if not x['passed']],result_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
 (O/('WRAPPER_'+label+'_EXECUTION_v1.json')).write_text(json.dumps(rec,indent=2)+'\n');records.append(rec)
(O/'WRAPPER_EXECUTION_SUMMARY_v1.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{k:r.get(k) for k in ['label','exit_code','passed','failed','failed_names']} for r in records],indent=2));raise SystemExit(any(r['exit_code']!=r['expected_exit'] for r in records))
