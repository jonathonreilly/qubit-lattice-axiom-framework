#!/usr/bin/env python3
"""Final metadata verification and immutable seal; no scientific execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,difflib,sys
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PREFIX='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/'
S=O/'snapshots'/PREFIX;P=S/'calibration_branch_packaging';L=S/'rolling_local_response/laboratory_yukawa_bridge_v1';B=S/'rolling_local_response/solar_branch_bound_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=lambda p:json.loads(p.read_text())
def now():return datetime.now(timezone.utc).isoformat()
def ref(p):return dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def write(name, data):
 p=O/name;assert not p.exists(),name;p.write_text(json.dumps(data,indent=2)+'\n')
assert not (O/'RECEIPT_v1.json').exists()
write('SEAL_COMMAND_v1.json',dict(created_utc=now(),argv=[sys.executable,'-B',str(Path(__file__).resolve())],cwd=str(Path.cwd()),script_sha256=sha(Path(__file__)),scope='Metadata and seal only; no scientific rerun.'))
checks=[]
def ck(name,ok):
 checks.append(dict(name=name,passed=bool(ok)))
 if not ok:
  write('SEAL_FAILURE_v1.json',dict(created_utc=now(),checks=checks));raise AssertionError(name)
pairs=j(O/'SOURCE_BINDINGS_v1.json')['source_pairs'];dispositions=j(O/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
ck('source_and_disposition_counts',len(pairs)==len(dispositions)==269)
for x,y in zip(pairs,dispositions):
 source=Path(x['original_path']);snap=O/x['snapshot_path'];recovery=W/y['recovery']
 ck('source:'+x['original_repo_path'],sha(source)==sha(snap)==x['sha256'] and source.stat().st_size==snap.stat().st_size==x['bytes'])
 ck('disposition:'+x['original_repo_path'],y['original_path']==y['final_path']==x['original_repo_path'] and y['original_sha256']==y['final_sha256']==x['sha256'] and recovery==snap and sha(recovery)==x['sha256'])
corr=j(O/'CORRESPONDENCE_RESULTS_v1.json');ce=j(O/'CORRESPONDENCE_EXECUTION_v1.json')
ck('correspondence_552_0',corr['passed']==552 and corr['failed']==0 and all(x['passed'] for x in corr['checks']))
ck('correspondence_source_execution',sha(O/'check_correspondence_v1.py')==ce['source_sha256'] and ce['exit_code']==0 and (O/'CORRESPONDENCE_STDERR_v1.txt').read_bytes()==b'')
summary=json.loads((O/'CORRESPONDENCE_STDOUT_v1.txt').read_text());ck('correspondence_stdout_counts',summary['passed']==552 and summary['failed']==0)
wf=j(O/'WRAPPER_FREEZE_v1.json');wr=j(O/'WRAPPER_EXECUTION_SUMMARY_v1.json')
ck('wrapper_checker_frozen',sha(O/'check_wrapper_v1.py')==wf['checker_sha256'])
for x in wr:
 label=x['label'];result=j(O/('WRAPPER_'+label+'_RESULTS_v1.json'));execrow=j(O/('WRAPPER_'+label+'_EXECUTION_v1.json'))
 ck('wrapper_result_identity:'+label,sha(O/('WRAPPER_'+label+'_RESULTS_v1.json'))==x['result_sha256'] and result['runner_sha256']==x['runner_sha256'] and execrow==x)
 ck('wrapper_checker_identity:'+label,x['checker_sha256']==wf['checker_sha256'])
 ck('wrapper_counts_and_exit:'+label,(x['passed'],x['failed'],x['exit_code'])==((65,0,0) if label=='baseline' else (62,3,1)))
 ck('wrapper_science_not_called:'+label,result['scientific_bodies_executed'] is False)
 ck('wrapper_stderr_empty:'+label,(O/('WRAPPER_'+label+'_STDERR_v1.txt')).read_bytes()==b'')
 stdout=j(O/('WRAPPER_'+label+'_STDOUT_v1.txt'));ck('wrapper_stdout_matches:'+label,stdout['passed']==x['passed'] and stdout['failed']==x['failed'] and stdout['failed_names']==x['failed_names'])
 for c in result['cases']:
  ck('wrapper_case_root_owned:'+label+':'+c['name'],all(str(O) in v for v in c['argv'] if v.startswith('/')))
  if c['name'] in ['existing_profiles','existing_output','return_disagreement']:
   ck('wrapper_expected_guard:'+label+':'+c['name'],c['error']['type']=='AssertionError')
  else:ck('wrapper_no_unexpected_error:'+label+':'+c['name'],c['error'] is None)
runner=P/'staged/exponential_scalar_calibration_branch_check.py'
for x in wf['mutations']:
 q=O/'wrapper_damage_sources'/(x['name']+'.py');ck('wrapper_one_damage:'+x['name'],runner.read_text().count(x['old'])==1 and runner.read_text().replace(x['old'],x['new'])==q.read_text() and sha(q)==x['sha256'])
 diff=''.join(difflib.unified_diff(runner.read_text().splitlines(True),q.read_text().splitlines(True),fromfile=runner.name,tofile=q.name));ck('wrapper_diff:'+x['name'],diff==(O/'wrapper_damage_sources'/(x['name']+'.diff')).read_text())
for name,old,new in j(P/'damages_v1/PLAN_v1.json')['cases']:
 q=P/'damages_v1'/(name+'.py');diff=''.join(difflib.unified_diff(runner.read_text().splitlines(True),q.read_text().splitlines(True),fromfile=runner.name,tofile=q.name));ck('stage_diff:'+name,diff==(P/'damages_v1'/(name+'.diff')).read_text())
for version,expected in [('v1',(39,1,1)),('v2',(40,0,0))]:
 result=j(L/('baseline_'+version+'/RESULTS.json'));execution=j(L/('EXECUTION_'+version+'.json'));command=j(L/('COMMAND_'+version+'.json'));code=L/('check_calibrated_torque_'+version+'.py')
 ck('lab_history_counts:'+version,(result['passed'],result['failed'],execution['exit_code'])==expected)
 ck('lab_history_result_hash:'+version,result['checker_sha256']==sha(code))
 ck('lab_history_complete_stdout:'+version,(L/('baseline_'+version+'/RESULTS.json')).read_bytes()==(L/('STDOUT_'+version+'.txt')).read_bytes())
 ck('lab_history_empty_stderr:'+version,(L/('STDERR_'+version+'.txt')).read_bytes()==b'')
 ck('lab_history_command_source:'+version,Path(command['command'][1]).name==code.name and command['cwd']==str(W))
old=L/'check_calibrated_torque_v1.py';new=L/'check_calibrated_torque_v2.py'
diff=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=old.name,tofile=new.name));ck('precision_repair_diff_exact',diff==(L/'CHECKER_v1_v2.diff').read_text())
for row in j(L/'sources/DOWNLOADS_v2.json'):
 target=O/'snapshots'/row['command'][row['command'].index('--output')+1]
 ck('recorded_normal_TLS_download:'+target.name,row['exit_code']==0 and '-k' not in row['command'] and '--insecure' not in row['command'] and sha(target)==row['sha256'])
report=(O/'REPORT_v1.md').read_text()
ck('report_staged_hashes',sha(runner) in report and sha(P/'staged/EXPONENTIAL_SCALAR_CALIBRATION_BRANCH_BOUNDED_THEOREM_NOTE_2026-10-14.md') in report)
ck('report_pending_delivery_explicit','prospective delivery link' in report and 'No source correction is required' in report)
write('FINAL_METADATA_VERIFICATION_v1.json',dict(created_utc=now(),passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),checks=checks,scope='Source/disposition, failure history and completed execution identities; no science rerun.'))
# Root manifest and receipt are the only excluded files; nested prior seals are included.
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p not in {O/'MANIFEST_v1.json',O/'RECEIPT_v1.json'}:
  assert not p.is_symlink();files.append(ref(p))
write('MANIFEST_v1.json',dict(created_utc=now(),root=str(O),artifact_count=len(files),artifacts=files,exclusions=['MANIFEST_v1.json','RECEIPT_v1.json'],scope='Complete owned correspondence evidence, including immutable nested prior seals and every preserved failure.'))
write('RECEIPT_v1.json',dict(
 schema='staged_source_correspondence_receipt_v1',created_utc=now(),scientific_author='/root',reviewer='/root/scalar_energy_check',write_root=str(O),
 scope='Staged canonical note/runner and saved execution correspondence; mathematical findings reused by exact independent seals. No primary scientific reruns.',
 conclusion='Exact source bodies/ASTs, full scientific outputs, actual full staged damages and wrapper behavior correspond. No source correction required. Live cache, archive and commit delivery remain pending.',
 formal_audit_or_landing_verdict=False,
 report=ref(O/'REPORT_v1.md'),manifest=ref(O/'MANIFEST_v1.json'),artifact_count=len(files),
 source_pair_count=len(pairs),source_pairs=pairs,source_bindings=ref(O/'SOURCE_BINDINGS_v1.json'),
 original_dispositions=dispositions,source_dispositions=ref(O/'SOURCE_DISPOSITIONS_v1.json'),
 staged_note=ref(P/'staged/EXPONENTIAL_SCALAR_CALIBRATION_BRANCH_BOUNDED_THEOREM_NOTE_2026-10-14.md'),staged_runner=ref(runner),
 staged_results=ref(P/'STAGED_RESULTS_v1.json'),staged_counts={'passed':174,'failed':0,'calibration':40,'branch':134},
 staged_full_damages=[{k:x[k] for k in ['name','passed','failed','exit_code','source','result','execution']} for x in corr['details']['actual_staged_damages']],
 reused_seals=corr['details']['reused_seals'],
 new_correspondence_counts={'passed':552,'failed':0},correspondence_result=ref(O/'CORRESPONDENCE_RESULTS_v1.json'),correspondence_code=ref(O/'check_correspondence_v1.py'),correspondence_execution=ref(O/'CORRESPONDENCE_EXECUTION_v1.json'),
 new_wrapper_counts={'passed':65,'failed':0},wrapper_scope='Actual main AST with synthetic proof stubs only; no mathematical body or numerical library called.',
 wrapper_result=ref(O/'WRAPPER_baseline_RESULTS_v1.json'),wrapper_code=ref(O/'check_wrapper_v1.py'),wrapper_driver=ref(O/'run_wrapper_controls_v1.py'),wrapper_execution_summary=ref(O/'WRAPPER_EXECUTION_SUMMARY_v1.json'),
 wrapper_actual_changed_programs=[{'name':x['label'],'passed':x['passed'],'failed':x['failed'],'exit_code':x['exit_code'],'result':ref(O/('WRAPPER_'+x['label']+'_RESULTS_v1.json'))} for x in wr[1:]],
 failure_ledger=ref(O/'FAILURES_v1.json'),command_index=ref(O/'COMMAND_INDEX_v1.json'),final_metadata_verification=ref(O/'FINAL_METADATA_VERIFICATION_v1.json'),
 protocol=ref(O/'CORRESPONDENCE_PROTOCOL_v1.json'),access_history=ref(O/'ACCESS_HISTORY_v1.json'),
 science_reruns=0,required_source_correction=False,prior_seals_modified=False,new_network_or_empirical_data=False,
 outside_write_or_git_pr_runtime_lock_settings_audit_mutation=False,
 delivery_not_yet_certified=['installed canonical bytes','live runner-cache fingerprint and payload','recovery README/archive and member hashes','commit/index/worktree delivery identity'],
 writes_end_at_this_receipt=True
))
print(json.dumps(dict(artifacts=len(files),source_pairs=len(pairs),dispositions=len(dispositions),final_metadata_checks=len(checks),report=ref(O/'REPORT_v1.md'),manifest=ref(O/'MANIFEST_v1.json'),receipt=ref(O/'RECEIPT_v1.json')),indent=2))
