from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib,subprocess,time
PK=Path(__file__).resolve().parent.parent
DEST=Path(__file__).resolve().parent
STAGE=DEST/'staged';STAGE.mkdir(exist_ok=False)
RR=PK/'rolling_local_response'
NOTE='EXPONENTIAL_SCALAR_CALIBRATION_BRANCH_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='exponential_scalar_calibration_branch_check.py'
PARENTS=['docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[RR/'laboratory_yukawa_bridge_v1/check_calibrated_torque_v2.py',RR/'solar_branch_bound_v1/check_branch_v1.py']
maps=[{'run':'check_calibration'},{'run':'check_branch'}]
class Rename(ast.NodeTransformer):
    def __init__(self,m):self.m=m
    def visit_Name(self,n):n.id=self.m.get(n.id,n.id);return n
    def visit_FunctionDef(self,n):n.name=self.m.get(n.name,n.name);return self.generic_visit(n)
blocks=[];lineage=[]
for p,m in zip(sources,maps):
    original=ast.parse(p.read_text());tree=ast.fix_missing_locations(Rename(m).visit(ast.Module(body=[n for n in original.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))],type_ignores=[])))
    blocks.append(ast.unparse(tree)+'\n');lineage.append(dict(path=str(p),sha256=sha(p),renames=m,transformed_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
header='#!/usr/local/bin/python3\n"""Conditional laboratory calibration and negative-branch light-time constraints."""\nfrom tempfile import TemporaryDirectory\nfrom contextlib import redirect_stdout\nimport io\nAUDIT_TIMEOUT_SEC=120\nAUDIT_INPUT_PATHS='+repr(['docs/'+NOTE]+PARENTS)+'\n'
footer='''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True);stream=io.StringIO()
        with redirect_stdout(stream):failed=check_calibration(root/'calibration')
        calibration=json.loads((root/'calibration'/'RESULTS.json').read_text());assert failed==calibration['failed'];branch=check_branch()
        return dict(passed=calibration['passed']+branch['passed'],failed=calibration['failed']+branch['failed'],units=dict(calibration=calibration,branch=branch),calibration_execution_stdout=stream.getvalue(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Synthetic geometry and an exposed conditional published interval transformation; no empirical fit or derived Solar matching.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-calibration-branch-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='');return bool(result['failed'])
if __name__=='__main__':raise SystemExit(main())
'''
(STAGE/RUNNER).write_text(header+'\n'.join(blocks)+footer)
header_note='''# Calibrated force signals and a conditional scalar branch bound

Status: conditional support; observational bridge premises remain explicit.
Claim type: bounded_theorem. Scientific author: /root.
Primary runner: `scripts/exponential_scalar_calibration_branch_check.py`.

A common laboratory calibration removes a truly long-range scalar enhancement
from the normalized torque ratio. Light propagation compared with matter dynamics
can distinguish that enhancement. The exact negative-field branch inequality below
then bounds what density-driven changes could accomplish, provided the Solar
matching, range and error assumptions actually hold. These statements establish
requirements for a measured comparison; they do not replace its likelihood or
environmental boundary problem.

Premises are the [complete supplied action](EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md),
[local force/light normalization](EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md),
and [environment branch definitions](EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md).
The publications below are exposed development context. No observational sample is
reserved or reused as an independent test, and no measured parameter is fitted.

'''
hands=[RR/'laboratory_yukawa_bridge_v1/DERIVATION_v1.md',RR/'solar_branch_bound_v1/DERIVATION_v1.md'];parts=[]
for p in hands:
    t=p.read_text();t='\n'.join('#'+line if line.startswith('#') else line for line in t.splitlines());parts.append(t)
end='''

## Source access, validation and surviving assumptions

The preserved public Nature HTML was subsequently inspected: its abstract confirms
the quoted gamma value and explicitly labels the rest a subscription preview.
Thus the source now includes direct public-abstract access, beyond the earlier
indexed-abstract check recorded in the original hand derivation. The full article
and likelihood were not acquired. The Lee primary PDF was read; actual torque
data, covariance and its numerical supplement were not acquired. No subscription,
credit purchase or access-control workaround was used.

The light-time inequality uses the lower interval edge as a necessary condition.
For a general interval, the upper edge supplies a separate intersection condition;
the chosen positive upper edge makes that additional condition automatic for
q>=0 and a symmetric nonnegative bridge-error allowance. An unbounded or unknown
bridge error supplies no useful coupling bound. Gvac is a theoretical bare
reference, distinct from the force normalization Gbare(1+q).

The canonical runner preserves the checked original proof bodies with function
renaming and an output wrapper. It executes40 calibration controls and134 branch
controls. The original laboratory39/1 failure arose from subtracting a synthetic
ratio from1 at a signal around4.16e-23; increasing arithmetic from50 to75 digits
resolved it with the same cases and acceptance threshold. The first failure,
repair diff, original programs, full outputs, actual damaged programs, primary
sources and the synthetic geometry plot remain in the
[recovery archive](work_history/physics/revised-scalar-calibration-branch-20261014/README.txt).

An independent geometric route uses potential Fourier coefficients, full pair
forces and signed near-null examples; its79 controls and five actual damages
support the conditional calibration algebra. Independent branch checks are
preserved separately and challenge the original-coordinate contraction, endpoints,
conformal inverse and error-budget transformation. These are mathematical controls,
not extra observations or a formal audit grade.

The negative-u coupling floor does not constrain positive-u backgrounds, nonlinear
body charges or scalar ranges. The common-background and same-gain laboratory
assumptions, real apparatus geometry and nuisance likelihood, actual Solar
matching and approximation error, initial state, supplied action and scales all
remain separate tasks. No theory-wide observational exclusion is asserted.
'''
(STAGE/NOTE).write_text(header_note+'\n\n'.join(parts)+end)
(DEST/'CANONICAL_LINEAGE_v1.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),canonical_note=dict(path=NOTE,sha256=sha(STAGE/NOTE)),canonical_runner=dict(path=RUNNER,sha256=sha(STAGE/RUNNER)),scientific_sources=lineage,hand_sources=[dict(path=str(p),sha256=sha(p)) for p in hands],transforms='AST formatting and run-function renaming only in computational bodies. New output wrapper. Hand prose retained in full with heading demotion; appended public-abstract access update and explicit general-interval scope.'),indent=2)+'\n')
cmd=['/usr/local/bin/python3',str(STAGE/RUNNER),'--profiles',str(DEST/'staged_outputs_v1'),'--out',str(DEST/'STAGED_RESULTS_v1.json')];t=time.time();r=subprocess.run(cmd,capture_output=True,text=True);(DEST/'STAGED_RUN_v1.stdout').write_text(r.stdout);(DEST/'STAGED_RUN_v1.stderr').write_text(r.stderr);(DEST/'STAGED_RUN_v1.json').write_text(json.dumps(dict(command=cmd,at=datetime.now(timezone.utc).isoformat(),elapsed=time.time()-t,exit_code=r.returncode,runner_sha256=sha(STAGE/RUNNER)),indent=2)+'\n');print('STAGED',r.returncode,r.stderr[-1000:])
if r.returncode==0:z=json.loads(r.stdout);print(z['passed'],z['failed'])
raise SystemExit(r.returncode)
