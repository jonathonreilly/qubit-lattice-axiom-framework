# Reconstructing the calibrated laboratory signal before importing a force limit

Personally derived by /root. This is a conditional forward-model result, not a new laboratory exclusion or a fit to measured torques. It is motivated by the calibration and nuisance treatment in Lee et al., Phys. Rev. Lett. 124,101101 (2020), https://arxiv.org/abs/2002.11761. The primary PDF is preserved; the unavailable numerical supplement has not been acquired.

## Observational input and exposure

The paper reports torsion torques at 52 micrometres to 3 mm, calibrated with separate macroscopic spheres. It fits geometry and calibration nuisance parameters and reports a 95% single-Yukawa gravitational-strength range limit of 38.6 micrometres. This does not directly give the limit for the present q<1/3 candidate. We use these published statements to determine the required forward operator, not to claim an independent replication of its likelihood. These statements are now exposed development context. No measured torque table or covariance is used below.

## 1. A common local Yukawa model and the instrument calibration

Assume an unscreened linear scalar with constant physical range lambda=1/mu, positive weight q and a single frozen background shared by calibration and science configurations. Take rigid density distributions, a weak quasistatic metric, pressure-negligible rest sources, and a linear torque readout. These are strong bridge premises, not consequences of the current environmental stationary family.

For a given geometry j and measured harmonic define Newtonian and Yukawa unit-G torque functionals N_j and Y_j(mu), computed from the complete mass geometry and the SAME demodulation functional. The energy kernels are 1/r and exp(-mu r)/r. Both functionals can have signs and cancellations. Suppose N_j and N_c are nonzero, where c denotes the calibration configuration, and put y_j=Y_j/N_j. The actual torques are

    tau_j=Gbare [N_j+q Y_j],
    tau_c=Gbare [N_c+q Y_c].                         (1)

If an instrumental multiplicative gain is calibrated by the Newtonian expectation for c, its same-gain normalized science prediction is

    R_j=(tau_j/N_j)/(tau_c/N_c)
       =(1+q y_j)/(1+q y_c),                        (2)

provided 1+q y_c is nonzero. Thus an exact measured R_j and known geometry/range would yield

    q=(R_j-1)/(y_j-R_j y_c),                        (3)

when the denominator is nonzero. When y_j=y_c, the normalized ratio is 1 for every q; a calibrated ratio does not then identify q. Noise, correlations and nuisance parameters are not removed by this algebra.

The standard short-range approximation y_c~0 permits R_j~1+q y_j. It must be justified at the calibration geometry, not assumed for every mu. If backgrounds differ, the ratio instead carries Gbare,j/Gbare,c and separate q_j,q_c,mu_j,mu_c. An environmental screening boundary problem cannot be replaced by (2) without proving the common-background approximation.

## 2. The massless calibration degeneracy and its leading correction

At mu=0 the Yukawa and Newtonian kernels coincide, so y_j=y_c=1 and R_j=1 exactly, even for finite q. Gbare(1+q) is then the common force normalization. This is a laboratory torque degeneracy, not equivalence to general relativity: lensing, relativistic bodies, time dependence or independent background information can distinguish the models.

For compact rigid bodies with a positive minimum separation and a fixed bounded linear torque/harmonic functional, the uniform kernel expansion is

    exp(-mu r)/r = 1/r - mu + mu^2 r/2 - mu^3 r^2/6 + O(mu^4).

The constant -mu times the product of total masses has zero orientation derivative, so it produces no torque. Let L_j be the ratio of the torque functional applied to r to that applied to 1/r. Then

    y_j = 1+mu^2 L_j/2+O(mu^3),
    R_j = 1+[q/(1+q)] mu^2 (L_j-L_c)/2+O(mu^3).      (4)

There is no universal positive sign or universal length for L_j in a signed torque geometry. The leading calibration-subtracted signal is quadratic in inverse range. The remainder is uniform on each fixed compact geometry with N_j,N_c bounded away from zero; it is not uniform near a Newtonian torque null or as geometry parameters diverge. Equation(4) does not justify extrapolating a published finite-range confidence contour to arbitrarily large lambda.

## 3. A direct geometric control, not the experiment

For two rings of n identical point masses at radii R and r, plane separation z, and relative angle theta, use all n^2 distances

    d_ij^2=R^2+r^2+z^2-2Rr cos(theta+2pi(j-i)/n).

After removing the common G m M, the torque is

    N(theta)=-sum_ij Rr sin(Delta_ij)/d_ij^3,
    Y(theta,mu)=-sum_ij Rr sin(Delta_ij)
                         (1+mu d_ij) exp(-mu d_ij)/d_ij^3.   (5)

Use the coefficient (1/pi) integral_0^(2pi) torque sin(n theta)dtheta. The corresponding r-kernel torque is +sum Rr sin(Delta)/d. Direct differentiation of the potential, periodic quadrature, and the massless/long-range limits independently check (5).

The calibration illustration uses the paper's reported radii R=0.1905 m and r=0.01648 m and n=3, but ASSUMES z=0 and ideal point masses. The science illustration instead uses n=3,R=0.001 m,r=0.0005 m,z=0.00007 m. It is not the paper's 18/120-fold wedge apparatus. No result from these toy geometries is a numerical reinterpretation of that experiment or its bounds. The prescribed synthetic q=0.2 does not estimate the theory's coupling.

## 4. Frozen checks and limits

Freeze q=0.2, the two toy geometries above, and inverse ranges mu={0,0.01,0.1,1,10,100,1000,10000,100000} per metre. Independently integrate each actual torque harmonic and its r-kernel coefficient. Check exact ratio inversion, massless nonidentification, leading mu^2 coefficient, point-force derivative and actual changed-code controls. Save every result and any numerical cancellation failure before repairs. No observational significance threshold is selected or fitted. A measured-theory comparison still needs the actual geometry, torque data/covariance, nuisance likelihood and environmental solution.
