#!/usr/local/bin/python3
"""Toy calibration geometry; not a fit to Lee et al. measurements."""
from pathlib import Path
import json, argparse, hashlib
import sympy as s
import numpy as np
import mpmath as mp

FORCE_DERIVATIVE = 1
USE_CALIBRATION = 1
INVERSE_SIGN = 1
LONG_RANGE_SIGN = 1

def run(out):
    out.mkdir(parents=True,exist_ok=False);mp.mp.dps=50;rows=[]
    def ck(n,ok,detail=None):rows.append(dict(name=n,passed=bool(ok),detail=detail))
    def eq(n,e):v=s.factor(e);ck(n,v==0,str(v))
    q,yj,yc,mu,d=s.symbols('q yj yc mu d',positive=True)
    ratio=(1+q*yj)/(1+USE_CALIBRATION*q*yc)
    eq('inverse',INVERSE_SIGN*(ratio-1)/(yj-ratio*yc)-q)
    eq('massless_calibration_degeneracy',ratio.subs({yj:1,yc:1})-1)
    eq('torque_force_factor',-s.diff(s.exp(-mu*d)/d,d)-(1+FORCE_DERIVATIVE*mu*d)*s.exp(-mu*d)/d**2)
    Lj,Lc=s.symbols('Lj Lc',real=True)
    leading=s.series(ratio.subs({yj:1+mu**2*Lj/2,yc:1+mu**2*Lc/2}),mu,0,3).removeO()
    eq('long_range_coefficient',leading-1-LONG_RANGE_SIGN*q*(Lj-Lc)*mu**2/(2*(1+q)))
    th,R,r,z=s.symbols('theta R r z',real=True)
    dist=s.sqrt(R**2+r**2+z**2-2*R*r*s.cos(th))
    eq('point_torque_from_energy',s.diff(s.exp(-mu*dist)/dist,th)+R*r*s.sin(th)*(1+mu*dist)*s.exp(-mu*dist)/dist**3)
    eq('constant_kernel_zero_torque',s.diff(-mu,th))
    eq('r_kernel_torque',s.diff(dist,th)-R*r*s.sin(th)/dist)
    geoms={'calibration':('.1905','.01648','0',3),'science':('.001','.0005','.00007',3)}
    def harmonic(geometry,inverse_range,kind='yukawa',precision='mp'):
        RR,rr,zz,n=geometry
        if precision=='mp':
            RR,rr,zz=map(mp.mpf,[RR,rr,zz]);mm=mp.mpf(inverse_range)
            def torque(t):
                sm=mp.mpf(0)
                for j in range(n):
                    angle=t+2*mp.pi*j/n;dd=mp.sqrt(RR**2+rr**2+zz**2-2*RR*rr*mp.cos(angle))
                    if kind=='r':sm+=RR*rr*mp.sin(angle)/dd
                    else:sm-=RR*rr*mp.sin(angle)*(1+FORCE_DERIVATIVE*mm*dd)*mp.exp(-mm*dd)/dd**3
                return n*sm
            return n/mp.pi*mp.quad(lambda t:torque(t)*mp.sin(n*t),[2*mp.pi*i/(n*16) for i in range(17)])
        RR,rr,zz=map(float,[RR,rr,zz]);mm=float(inverse_range)
        nn=512;ts=2*np.pi*(np.arange(nn)+.5)/nn;sm=np.zeros_like(ts)
        for j in range(n):
            angle=ts+2*np.pi*j/n;dd=np.sqrt(RR**2+rr**2+zz**2-2*RR*rr*np.cos(angle))
            if kind=='r':sm+=RR*rr*np.sin(angle)/dd
            else:sm-=RR*rr*np.sin(angle)*(1+FORCE_DERIVATIVE*mm*dd)*np.exp(-mm*dd)/dd**3
        return float(2*np.mean(n*sm*np.sin(n*ts)))
    norms={name:harmonic(g,0) for name,g in geoms.items()}
    moments={name:harmonic(g,0,kind='r')/norms[name] for name,g in geoms.items()}
    for name,g in geoms.items():
        ck(name+'.nonzero_harmonic',abs(norms[name])>mp.mpf('1e-8'),str(norms[name]))
        num=harmonic(g,0,kind='r',precision='double')
        ck(name+'.r_moment_quadrature',abs(mp.mpf(num)/norms[name]-moments[name])<mp.mpf('1e-10')*max(mp.mpf('1e-12'),abs(moments[name])),str(moments[name]))
    Q=mp.mpf('.2');mus=['0','.01','.1','1','10','100','1000','10000','100000'];records=[]
    for ms in mus:
        mm=mp.mpf(ms);ys={}
        for name,g in geoms.items():
            hp=harmonic(g,mm);dp=harmonic(g,mm,precision='double');ys[name]=hp/norms[name]
            err=abs(mp.mpf(dp)-hp);bound=mp.mpf('2e-11')*max(mp.mpf('1e-20'),abs(hp))
            ck(name+'.double_mu_'+ms,err<bound,dict(error=str(err),bound=str(bound)))
        Rc=(1+Q*ys['science'])/(1+USE_CALIBRATION*Q*ys['calibration'])
        if mm==0:ck('massless_numeric',abs(Rc-1)<mp.mpf('1e-45'),str(Rc))
        elif abs(ys['science']-Rc*ys['calibration'])>mp.mpf('1e-35'):
            inv=INVERSE_SIGN*(Rc-1)/(ys['science']-Rc*ys['calibration'])
            ck('inverse_mu_'+ms,abs(inv-Q)<mp.mpf('1e-35'),str(inv))
        if ms in ['.01','.1']:
            observed=(Rc-1)/mm**2;pred=LONG_RANGE_SIGN*Q/(1+Q)*(moments['science']-moments['calibration'])/2
            # Absolute difference must decrease by ~100 when mu decreases tenfold.
            records.append(dict(mu=ms,y_calibration=str(ys['calibration']),y_science=str(ys['science']),normalized_ratio=str(Rc),quadratic_coefficient=str(observed),predicted_quadratic_coefficient=str(pred),coefficient_error=str(abs(observed-pred))))
        else:records.append(dict(mu=ms,y_calibration=str(ys['calibration']),y_science=str(ys['science']),normalized_ratio=str(Rc)))
    asym=[r for r in records if 'coefficient_error' in r]
    ck('long_range_relative_coefficient',mp.mpf(asym[0]['coefficient_error'])<mp.mpf('1e-5')*abs(mp.mpf(asym[0]['predicted_quadratic_coefficient'])),asym[0])
    ck('long_range_convergence',mp.mpf(asym[0]['coefficient_error'])<mp.mpf(asym[1]['coefficient_error'])/20,[a['coefficient_error'] for a in asym])
    result=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,newton_harmonics={k:str(v) for k,v in norms.items()},r_moment_ratio_m2={k:str(v) for k,v in moments.items()},records=records,scope='Toy geometries; published calibration radii plus explicitly assumed geometry, no torque-data fit or empirical exclusion.',checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return result['failed']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();raise SystemExit(bool(run(a.out)))
