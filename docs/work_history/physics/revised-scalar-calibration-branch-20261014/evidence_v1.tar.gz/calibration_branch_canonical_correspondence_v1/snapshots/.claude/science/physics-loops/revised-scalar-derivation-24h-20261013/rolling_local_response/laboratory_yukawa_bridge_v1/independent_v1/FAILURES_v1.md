# Preserved failures and corrections

The blind independent baseline completed 79 passed checks and zero failed checks, exit 0, with empty stderr. No unexpected process exception or numerical control failure occurred.

Five deliberately altered programs produced actual failed controls: 43/12, 49/6, 50/5, 52/3 and 46/9, each exit 1. `damages_v1/SUMMARY.json` lists every failed row, the required witness, exact one-change transformation and actual source hash. Each run's `FREEZE.json` hashes its actual altered source and four other inputs; all were unchanged at completion. The failures are mathematical/geometric, not source-identity rejection.

The hand-derivation draft incorrectly labelled its primary-source paragraph as 112 words. A whitespace count gives 106. This non-scientific pre-seal correction is recorded with exact old/new hashes, original draft and diff in `draft_history/`. No executed input, equation, tolerance, result or source version changed.

The parent communicated a separate producer conditioning failure in a progress message, but the producer source/results were deliberately not inspected. This review does not verify, overwrite or reclassify that evidence.
