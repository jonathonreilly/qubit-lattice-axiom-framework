# Independent blind derivation

Only the frozen parent derivation, protocol and primary PDF were opened. The following algebra was developed before reading any parent implementation or numerical results; none are part of this review's inputs.

## Calibration is a quotient of two physical responses

Let a common instrument gain be g and an arbitrary reference Newton constant be Gref. Raw readouts are m_i=g Gbare(N_i+qY_i). Newtonian calibration supplies the multiplier Gref N_c/m_c. Dividing the calibrated science readout by Gref N_j gives

    R=(1+q y_j)/(1+q y_c),   y_i=Y_i/N_i.

Both g and Gref cancel. This requires the same gain after the applicable frequency-response correction, the same physical parameters/background in both configurations, nonzero N_j,N_c, and nonzero calibrated response. Solving R(1+q y_c)=1+q y_j yields

    q=(R-1)/(y_j-R y_c).

If y_j=y_c, every defined response is R=1. If an inconsistent proposed R differs from 1 in that case, the inverse expression can return the forbidden calibration pole rather than a physical solution. More generally a zero inverse denominator with R!=1 is inconsistent; a zero denominator with R=1 is nonidentification. For y_j!=y_c the derivative dR/dq=(y_j-y_c)/(1+q y_c)^2, so the map is locally one-to-one away from the pole. Its inverse becomes ill-conditioned as the two responses approach each other. Positive q does not by itself prevent a pole in an arbitrary signed harmonic geometry, where y_c can be negative. The parent's explicit nonzero-denominator conditions are therefore necessary, not cosmetic.

## Torque expansion from the energy

For rigid fixed-mass source measures, write the unit-strength interaction energy as minus the double integral of a radial kernel. The torque is therefore the positive orientation derivative of the kernel integral. A fixed harmonic is a linear functional of that derivative. A constant kernel has orientation-independent integral M1 M2 and zero torque, regardless of its coefficient. There is no term linear in mu in a physical torque.

For bounded distances dmin<=d<=dmax and fixed geometry,

    K_mu(d)=1/d-mu+mu^2 d/2-mu^3 d^2/6+O(mu^4).
    Y_i=N_i+mu^2 H_i[d]/2-mu^3 H_i[d^2]/6+O(mu^4).

Here H_i is the same torque/harmonic functional used in N_i=H_i[1/d]. Let L_i=H_i[d]/N_i. Expanding the calibration quotient gives

    R-1={q/(1+q)} mu^2(L_j-L_c)/2+O(mu^3).

L_i has dimensions length squared. Under common geometric dilation by a factor s, N_i scales as 1/s, H_i[d] as s, and L_i as s^2. The leading term is dimensionless. Its sign is not fixed by attractive pair forces: harmonic projection and subtraction are signed operations.

At mu=0, Y_i=N_i and R=1 for any finite positive q. This is a common amplitude calibration degeneracy. At very short ranges both Y_i can instead tend to zero and R again approaches 1. Neither limit proves absence of a scalar, nor equivalence of other observables to Einstein gravity.

## An independent geometric computation

For one point pair set d(theta)^2=R^2+r^2+z^2-2Rr cos(theta). Differentiating the negative energy gives the parent torque sign:

    t_mu(theta)=-Rr sin(theta)(1+mu d) exp(-mu d)/d^3.

For the d kernel the torque is +Rr sin(theta)/d. In a pair of n-fold rings, shifting every one of the n^2 pair angles by an integer multiple of 2pi/n leaves the nth Fourier coefficient unchanged. Integration by parts gives a distinct energy route:

    H_n[K]=-(n^3/pi) integral_0^(2pi) K(d(theta)) cos(n theta) dtheta.

This is the primary numerical route used here. It is checked against full pairwise torque integration and independently differentiated point energies; it does not merely re-execute a producer force helper. For exponentially small kernels the integral is rescaled by exp(-mu dmin), retaining the exponent outside the quadrature rather than allowing binary64 underflow to mimic zero.

For n=3, the harmonic of d^2 is exactly zero because d^2 contains only a constant and cos(theta). Thus the cubic term vanishes in these particular toys. The parent's general O(mu^3) remainder remains valid but is not sharp for them; this geometric cancellation must not be promoted to an arbitrary instrument.

A useful absolute remainder follows directly from f(x)=(1+x)exp(-x). For x>=0, |f'''(x)|=|(2-x)exp(-x)|<=2. Hence |f(x)-1+x^2/2|<=x^3/3. The absolute error in a ring's nth torque coefficient is at most (2/3)n^2 Rr mu^3. Dividing by |N| bounds the y remainder. Combining the two bounded remainders with the exact quotient denominator gives a check of the asymptotic expression that does not fit its coefficient to numerical results.

## Signed nulls and nonuniform domains

Take two positive-mass ring contributions with a relative phase pi/n. Their chosen harmonics subtract. If their Newtonian coefficients are N1,N2, choose positive weight w=(N1/N2)(1-delta) when the two original signs agree. The total Newtonian coefficient is delta N1 and

    L_mix=[L1-(1-delta)L2]/delta.

For L1!=L2 this diverges and changes sign as delta crosses zero. The unnormalized physical torque remains finite. The expansion of a normalized ratio is consequently not uniform near a Newtonian harmonic null, and y need not lie between zero and one. An actual zero N makes the chosen normalization unavailable. This does not invalidate the underlying linear torque model.

Bounded source support, fixed masses and a fixed well-defined torque functional are necessary for the uniform expansion. Varying geometry without uniform distance/functional bounds, passing through a torque null, or passing through the calibration pole removes that uniformity. Different backgrounds, screening, gain transfer, pressure response or finite-body scalar charges are additional physical questions; none is solved by this algebra.

## Primary-source scope

The paper's abstract and Fig. 2 support the stated separation range, macroscopic sphere calibration and quoted orbit radii. Its calibration is an expected-to-nominal torque ratio, including instrumental response corrections. Pages 3-4 describe a simultaneous torque analysis with measured geometric and calibration nuisance constraints. The quoted range limit concerns a gravitational-strength single Yukawa interaction. The PDF does not supply the toy's zero plane separation or identify the small science ring with the experimental wedge geometry. Its supplement reference is a placeholder in this preserved arXiv v1 file. I inspected no numerical supplement or website challenge page. No experimental confidence bound is transferred to the candidate's smaller coupling.

This paragraph is the complete primary-paper paraphrase in the review (106 words). All other calculations are conditional mathematical checks of the supplied model.
