# Blind laboratory-calibration mathematical review

Scientific author: `/root`. Independent checker: `/root/direct_field_check`. Date: 2026-10-14.

The calibrated torque ratio, its inverse on the stated domain, the massless degeneracy, the absent linear-in-inverse-range torque, and the quadratic calibration-subtracted term are correct under the supplied assumptions. I found no required correction to the frozen parent derivation. The independent numerical baseline passed 79 checks. Five actual altered independent programs failed their intended mathematical witnesses with freshly computed hashes of every actual input.

This is a focused proof/geometric check. It does not verify a parent implementation, reproduce a laboratory likelihood, constrain the supplied theory, establish an environmental screening solution, or apply a formal audit/status verdict.

## Sources and blind scope

Only three parent/source files were opened and frozen before the checks:

| Input | SHA256 |
|---|---|
| `DERIVATION_v1.md` | `8c4a9f2c8fc668e37355f8955e44dae0c53bf4fcd900c053b456874bab2ac1b1` |
| `PROTOCOL_v1.json` | `c25c43a92a7ba7d9b69f47b92b95c057ffa80a8ba4f0383c4bd050732ee2101c` |
| `sources/LEE_2020_v1.pdf` | `ffcddf6d2c1a758f07112a3125ae8583254a3089b1022ac2cf459a052652504c` |

`FREEZE_v1.json` identifies their exact original and snapshot paths. The complete PDF text and all five rendered pages were inspected; the primary-source paraphrase is confined to the 106-word paragraph in `HAND_DERIVATION_v1.md`. The toy's unsupported geometric choices and the experimental-limit scope are distinguished there. No numerical supplement, laboratory torque data/covariance, HTML page, parent checker or parent output file was read. A parent progress message communicated its execution counts; those counts were not consumed as an oracle or compared to this independent result.

## Independent derivation and domains

Starting with raw readouts `m_i=g Gbare(N_i+qY_i)`, calibration by `Gref N_c/m_c` and normalization to `Gref N_j` cancel both the common gain and the reference constant. This yields `(1+q y_j)/(1+q y_c)`. The same gain means the relevant frequency-response correction has already been supplied. Distinct backgrounds, scalar weights/ranges or gain transfers do not cancel under this argument.

Cross multiplication gives the stated q inverse. Its derivative is `(y_j-y_c)/(1+q y_c)^2`, so the ratio identifies q locally only when the two response factors differ and the calibration denominator is nonzero. Inverting an inconsistent datum at equal response factors can formally return the forbidden calibration pole. This is not an additional physical solution. Positive q alone cannot exclude a pole in an arbitrary signed harmonic geometry. These qualifications are consistent with the parent's stated denominator and degeneracy restrictions.

I differentiated the negative pair interaction energy directly. The constant term in the radial kernel integrates to a product of fixed masses, independent of orientation, and therefore produces zero torque. The next term is `mu^2 H[r]/2`; division by a nonzero Newtonian harmonic gives `L=H[r]/N`, with dimensions of length squared. Expanding the complete calibration quotient then gives `q mu^2(L_j-L_c)/(2(1+q))`. The supplied sign of the point-pair torque and the opposite sign of the r-kernel torque both follow from that differentiation.

The source's uniformity qualifications are substantive. Compact separated bodies make the kernel and its orientation derivative uniformly expandable on a fixed geometry. Dividing by a nearly cancelled Newtonian harmonic, letting the calibration response approach zero, or varying geometries without common bounds can destroy the normalized expansion's uniformity. A fixed physical mass distribution with positive pair attraction does not guarantee a positive harmonic or a normalized Yukawa response between zero and one.

## Distinct computational route

The primary numerical method uses a cosine Fourier coefficient of the potential followed by integration by parts, rather than integrating the stated torque formula as its only oracle. For n-fold rings,

    H_n[K]=-(n^3/pi) integral_0^(2pi) K(d(theta)) cos(n theta) dtheta.

Independent controls differentiate point energies, integrate the full nine-pair torque without the Fourier multiplicity reduction, and compare direct force harmonics at every frozen inverse range. The exponential is scaled by its minimum-separation factor before quadrature, so extremely small responses remain represented rather than underflowing to zero. Arithmetic uses 70 decimal digits; the maximum relative potential-versus-force discrepancy on the 18 geometry/range rows was approximately `1.46e-67`, below the frozen `1e-35` comparison threshold. This is finite high-precision numerical evidence, not interval-certified quadrature over an unlimited parameter domain.

The full baseline consumes all nine declared inverse ranges for both toy geometries. It checks exact rational inversion and degeneracy, constant-kernel torque, the point-force gradient, geometric dimensions under dilation, the n-squared pair multiplicity, three small-mu coefficient comparisons, and signed near-null composite geometries. All 79 checks passed on the first execution with unchanged inputs and empty stderr. No parent helper was imported.

For the stated unit-mass, unit-strength normalization, the independently computed coefficients are:

| Toy | Newtonian harmonic N | L in square metres |
|---|---:|---:|
| Calibration | -0.05753900131865445 | -0.007217302501634926 |
| Science | -2330.399058397885 | -1.637227810472823e-7 |

At synthetic q=0.2 the predicted coefficient of `mu^2` in `R-1` is `0.0006014282315711566` square metres. Direct coefficients at mu=0.01, 0.003 and 0.001 approach it and satisfy an independently derived absolute Taylor remainder bound; no coefficient was fitted. In these n=3 toys the cubic term happens to vanish because the relevant r-squared kernel contains only zeroth and first angular harmonics. The parent's general O(mu^3) statement remains valid and is deliberately less specific.

The final range point has `R-1` approximately `4.15718406618e-23`; subtracting two binary64 numbers near one would discard that signal. The high-precision direct inverse recovers q with error about `4.0e-50`. The result file also stores a cancellation-resistant expression for `R-1`. These are numerical-conditioning observations about synthetic toys, not an experimental sensitivity claim.

To challenge the sign and null assertions, I combined two positive-mass contributions with opposite harmonic phases. As their Newtonian residual fraction changes from 0.01 to 0.0001 to -0.0001, the effective L is approximately +0.7145, +72.1642 and -72.1786 square metres. The exact expression has a simple pole at the Newtonian null while unnormalized torques remain finite. This explicitly demonstrates both signs and the absence of a uniform normalized coefficient bound.

## Actual altered-code sensitivity

Each damaged program was a separate exact copy with one specified source change. Each execution froze the altered source itself, the independent protocol, and the three actual frozen inputs. Thus detection is by failed mathematical comparisons, not by comparing an altered file to the original source hash. The 55-check witness subset includes all exact/geometric controls, three declared range sites, the full-pair integration, and all small-mu/null controls; it does not claim to repeat all 79 baseline checks.

| Actual source damage | Passed/failed | Intended witness | Exit |
|---|---:|---|---:|
| Omit calibration denominator | 43/12 | Massless normalized ratio | 1 |
| Omit force factor 1+mu*d | 49/6 | Differentiated point energy | 1 |
| Omit z-squared separation term | 50/5 | Independent geometric distance | 1 |
| Double quadratic coefficient | 52/3 | Long-range coefficient bound | 1 |
| Use n instead of n-squared pairs | 46/9 | Full pairwise harmonic | 1 |

Every required witness failed. Exact altered sources, diffs, all result rows, command/time/return records and full streams remain preserved. No unexpected baseline or execution failure occurred. A pre-seal draft's stated primary-paragraph word count was corrected from 112 to 106; the original draft and exact non-scientific diff are retained.

## Final scope disposition

All three original inputs remain exact and have explicit original/snapshot/final bindings in the receipt. The complete hand derivation, independent source, execution driver, mutation driver, frozen protocols and every result are inventoried. The proof checks support the parent's conditional forward-model result, including its refusal to transfer a published gravitational-strength bound to a smaller candidate coupling. They do not supply missing geometry, covariance, nuisance inference, finite-body charges or a common environmental background. No parent source was changed or broader research route initiated.
