"""Actual changed independent programs; preserve every result and exact source."""
from pathlib import Path
import difflib
import hashlib
import json
from execute_v1 import execute

OUT=Path(__file__).resolve().parent
base=(OUT/'check_independent_v1.py').read_text()
definitions=[
    ('omit_calibration_denominator','return (1+q*yj)/(1+q*yc)','return (1+q*yj)','ratio_massless_exact'),
    ('omit_force_factor','return -R*r*mp.sin(theta)*(1+mu*d)*mp.exp(-mu*d)/(d*d*d)','return -R*r*mp.sin(theta)*mp.exp(-mu*d)/(d*d*d)','point_force_derivative'),
    ('omit_plane_separation','return mp.sqrt(R*R+r*r+z*z-2*R*r*mp.cos(theta))','return mp.sqrt(R*R+r*r-2*R*r*mp.cos(theta))','point_geometry_distance'),
    ('wrong_leading_coefficient','return q*(Lj-Lc)/(2*(1+q))','return q*(Lj-Lc)/(1+q)','long_range_coefficient'),
    ('wrong_ring_multiplicity','multiplicity = n*n','multiplicity = n','ring_full_pair_harmonic'),
]
damage=OUT/'damages_v1';damage.mkdir(exist_ok=False)
summary=[]
for name,before,after,witness in definitions:
    assert base.count(before)==1
    text=base.replace(before,after)
    p=damage/(name+'.py')
    with p.open('x') as f:f.write(text)
    with (damage/(name+'.diff')).open('x') as f:f.write(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='independent_baseline',tofile=name)))
    execution=execute(p,'damages_v1/'+name,witness=True)
    result=json.loads((damage/name/'RESULTS.json').read_text())
    failed=[r['name'] for r in result['checks'] if not r['passed']]
    summary.append({'name':name,'before':before,'after':after,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'passed':result['passed'],'failed':result['failed'],'exit_code':execution['exit_code'],'inputs_unchanged':execution['inputs_unchanged'],'required_witness':witness,'required_witness_failed':witness in failed,'failed_rows':failed,'baseline_positive_science_not_rerun':True,'scope':'Exact/rational/geometric witness subset, including three declared mu sites, full pair integration and all long-range/null controls.'})
with (damage/'SUMMARY.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if all(r['exit_code']==1 and r['required_witness_failed'] and r['inputs_unchanged'] for r in summary) else 1)
