"""Blind independent calibration and geometry controls; never imports producer code."""
from pathlib import Path
import argparse
import hashlib
import json
import mpmath as mp
import sympy as sp

mp.mp.dps = 70
checks = []
rows = []

def enc(x):
    return mp.nstr(x, 62) if isinstance(x, mp.mpf) else x

def ck(name, ok, **detail):
    checks.append({'name': name, 'passed': bool(ok), 'detail': {k: enc(v) for k, v in detail.items()}})

def close(a, b, tol=mp.mpf('1e-35')):
    return abs(a-b) <= tol*max(abs(a), abs(b))

def calibrated_ratio(q, yj, yc):
    return (1+q*yj)/(1+q*yc)

def invert_ratio(R, yj, yc):
    return (R-1)/(yj-R*yc)

def leading_coefficient(q, Lj, Lc):
    return q*(Lj-Lc)/(2*(1+q))

def distance(R, r, z, theta):
    return mp.sqrt(R*R+r*r+z*z-2*R*r*mp.cos(theta))

def point_torque(R, r, z, theta, mu):
    d = distance(R, r, z, theta)
    return -R*r*mp.sin(theta)*(1+mu*d)*mp.exp(-mu*d)/(d*d*d)

BREAKS = [mp.mpf(0), mp.pi/128, mp.pi/64, mp.pi/16, mp.pi/4, mp.pi/2, mp.pi]

def energy_harmonic(g, kind, mu=mp.mpf(0)):
    R,r,z,n = g
    dmin = mp.sqrt((R-r)**2+z*z)
    scale = mp.exp(-mu*dmin) if kind == 'yukawa' else mp.mpf(1)
    def integrand(theta):
        d = distance(R,r,z,theta)
        if kind == 'yukawa':
            kernel = mp.exp(-mu*(d-dmin))/d
        else:
            kernel = d**{'newton':-1,'linear':1,'square':2,'constant':0}[kind]
        return kernel*mp.cos(n*theta)
    multiplicity = n
    return -n*multiplicity*2/mp.pi*scale*mp.quad(integrand, BREAKS)

def force_harmonic(g, mu):
    R,r,z,n = g
    scale = mp.exp(-mu*mp.sqrt((R-r)**2+z*z))
    return n*n*2/mp.pi*scale*mp.quad(lambda t: point_torque(R,r,z,t,mu)/scale*mp.sin(n*t), BREAKS)

def full_pair_harmonic(g, mu):
    R,r,z,n = g
    def integrand(theta):
        total = mp.mpf(0)
        for i in range(n):
            for j in range(n):
                angle = theta+2*mp.pi*(j-i)/n
                d = mp.sqrt(R*R+r*r+z*z-2*R*r*mp.cos(angle))
                total += -R*r*mp.sin(angle)*(1+mu*d)*mp.exp(-mu*d)/d**3
        return total*mp.sin(n*theta)
    return mp.quad(integrand, [j*mp.pi/6 for j in range(13)])/mp.pi

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--inputs',required=True);ap.add_argument('--witness-only',action='store_true');args=ap.parse_args()
    inputs=Path(args.inputs);protocol=json.loads((inputs/'sources/PROTOCOL_v1.json').read_text())
    q=mp.mpf(protocol['synthetic_q'])
    def geom(key):
        v=protocol[key];return tuple(mp.mpf(v[k]) for k in ['R','r','z'])+(v['n'],)
    cal,sci=geom('calibration_toy'),geom('science_toy')
    qx,jx,cx,Rx=sp.symbols('q j c R')
    ratio=calibrated_ratio(qx,jx,cx)
    ck('ratio_exact_cross_multiply',sp.simplify(ratio*(1+qx*cx)-(1+qx*jx))==0)
    ck('ratio_massless_exact',sp.simplify(calibrated_ratio(qx,1,1)-1)==0)
    ck('inverse_exact',sp.simplify(invert_ratio(ratio,jx,cx)-qx)==0)
    ck('ratio_derivative',sp.simplify(sp.diff(ratio,qx)-(jx-cx)/(1+qx*cx)**2)==0)
    ck('inverse_derivative',sp.simplify(sp.diff(invert_ratio(Rx,jx,cx),Rx)-(jx-cx)/(jx-Rx*cx)**2)==0)
    ck('equal_geometry_nonidentification',sp.simplify(calibrated_ratio(qx,cx,cx)-1)==0)
    for a,b,c in [(sp.Rational(1,5),sp.Rational(2,3),sp.Rational(1,4)),(sp.Rational(1,7),-2,3),(sp.Rational(2,7),4,-1)]:
        rr=calibrated_ratio(a,b,c)
        ck('rational_inverse',sp.simplify(invert_ratio(rr,b,c)-a)==0,case=str((a,b,c)))
    forbidden=invert_ratio(sp.Rational(2),sp.Rational(-2),sp.Rational(-2))
    ck('inconsistent_equal_response_returns_pole',sp.simplify(1+forbidden*(-2))==0)
    d,mu=sp.symbols('d mu', positive=True)
    K=sp.exp(-mu*d)/d
    for order,expected in [(0,1/d),(1,-1),(2,d),(3,-d*d)]:
        ck('kernel_exact_derivative_'+str(order),sp.simplify(sp.diff(K,mu,order).subs(mu,0)-expected)==0)
    angle=sp.symbols('angle',real=True)
    ck('constant_kernel_zero_torque',sp.diff(-mu,angle)==0)
    ck('ring_cubic_term_zero',sp.integrate((5-2*sp.cos(angle))*sp.cos(3*angle),(angle,0,2*sp.pi))==0)
    ck('point_geometry_distance',close(distance(mp.mpf(3),mp.mpf(1),mp.mpf(2),mp.pi/3)**2,mp.mpf(11)))
    for u in [mp.mpf(0),mp.mpf('.3'),mp.mpf(7)]:
        R,r,z,t=mp.mpf('.7'),mp.mpf('.2'),mp.mpf('.4'),mp.mpf('.9')
        derivative=mp.diff(lambda h:mp.exp(-u*mp.sqrt(R*R+r*r+z*z-2*R*r*mp.cos(h)))/mp.sqrt(R*R+r*r+z*z-2*R*r*mp.cos(h)),t)
        actual=point_torque(R,r,z,t,u)
        ck('point_force_derivative',close(actual,derivative),mu=u,actual=actual,derivative=derivative)

    values={}
    for name,g in [('calibration',cal),('science',sci)]:
        N=energy_harmonic(g,'newton');H=energy_harmonic(g,'linear');L=H/N
        values[name]={'N':N,'H_r':H,'L':L}
        ck('newton_nonzero:'+name,abs(N)>mp.mpf('1e-8'),N=N)
        ck('constant_harmonic_zero:'+name,abs(energy_harmonic(g,'constant'))<mp.mpf('1e-65'))
        ck('square_harmonic_zero:'+name,abs(energy_harmonic(g,'square'))<mp.mpf('1e-65'))
        ck('newton_force_crosscheck:'+name,close(N,force_harmonic(g,mp.mpf(0))))
        scaled=tuple(7*v for v in g[:3])+(g[3],)
        Ns=energy_harmonic(scaled,'newton');Hs=energy_harmonic(scaled,'linear')
        ck('length_scaling_N:'+name,close(Ns,N/7))
        ck('length_scaling_L:'+name,close(Hs/Ns,49*L))
    full=full_pair_harmonic(sci,mp.mpf(1000));reduced=energy_harmonic(sci,'yukawa',mp.mpf(1000))
    ck('ring_full_pair_harmonic',close(full,reduced),full=full,reduced=reduced)
    mus=[mp.mpf(v) for v in protocol['mu_per_m']]
    if args.witness_only:mus=[mp.mpf(0),mp.mpf('.01'),mp.mpf(1000)]
    for u in mus:
        row={'mu_per_m':u}
        ys={}
        for name,g in [('calibration',cal),('science',sci)]:
            Y=energy_harmonic(g,'yukawa',u);F=force_harmonic(g,u);ys[name]=Y/values[name]['N']
            ck('Y_force_crosscheck:'+name,close(Y,F),mu=u,relative_error=abs(Y-F)/max(abs(Y),abs(F),mp.mpf('1e-10000')))
            row[name]={'Y':Y,'y':ys[name]}
        ratio=calibrated_ratio(q,ys['science'],ys['calibration'])
        row['R']=ratio;row['stable_R_minus_1']=q*(ys['science']-ys['calibration'])/(1+q*ys['calibration'])
        ck('stable_ratio_identity',abs((ratio-1)-row['stable_R_minus_1'])<mp.mpf('1e-60'),mu=u)
        if u==0:
            ck('numeric_massless_degeneracy',abs(ratio-1)<mp.mpf('1e-60'))
            row['q_inverse']='undefined: equal responses'
        else:
            qi=invert_ratio(ratio,ys['science'],ys['calibration']);row['q_inverse']=qi
            ck('q_inverse_numeric',abs(qi-q)<mp.mpf('1e-28'),mu=u,error=abs(qi-q))
        rows.append(row)
    Lj,Lc=values['science']['L'],values['calibration']['L']
    pred=leading_coefficient(q,Lj,Lc);limits=[]
    for u in [mp.mpf('.01'),mp.mpf('.003'),mp.mpf('.001')]:
        yj=energy_harmonic(sci,'yukawa',u)/values['science']['N'];yc=energy_harmonic(cal,'yukawa',u)/values['calibration']['N']
        D=1+q*yc;A=u*u*(Lj-Lc)/2
        ej=mp.mpf(2)/3*sci[3]**2*sci[0]*sci[1]*u**3/abs(values['science']['N'])
        ec=mp.mpf(2)/3*cal[3]**2*cal[0]*cal[1]*u**3/abs(values['calibration']['N'])
        errbound=q*(ej+ec)/abs(D)+q*q*abs(A)*(u*u*abs(Lc)/2+ec)/((1+q)*abs(D))
        actual=q*(yj-yc)/D
        ck('long_range_coefficient',abs(actual-u*u*pred)<=errbound+mp.mpf('1e-60'),mu=u,observed_coefficient=actual/u**2,predicted=pred,error_bound_div_mu2=errbound/u**2)
        limits.append({'mu':u,'observed_coefficient':actual/u**2,'predicted_coefficient':pred,'remainder_bound':errbound})
    composites=[]
    for delta in [mp.mpf('.01'),mp.mpf('.0001'),mp.mpf('-.0001')]:
        w=values['science']['N']/values['calibration']['N']*(1-delta)
        Nm=values['science']['N']-w*values['calibration']['N'];Hm=values['science']['H_r']-w*values['calibration']['H_r'];Lm=Hm/Nm
        expected=(Lj-(1-delta)*Lc)/delta
        ck('signed_null_composite',w>0 and close(Lm,expected),delta=delta,L_mix=Lm)
        ck('signed_null_sign',mp.sign(Lm)==mp.sign(delta),delta=delta,L_mix=Lm)
        composites.append({'delta':delta,'positive_mass_weight':w,'N':Nm,'L':Lm})
    ck('signed_null_divergence',abs(composites[1]['L'])>90*abs(composites[0]['L']))
    result={'scope':'Blind independent exact/geometric controls; synthetic toy, no empirical inference.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'precision_dps':mp.mp.dps,'witness_only':args.witness_only,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'checks':checks,'geometry_coefficients':values,'responses':rows,'long_range':limits,'signed_composites':composites}
    output=Path(args.output)
    with output.open('x') as f:json.dump(result,f,indent=2,default=enc);f.write('\n')
    print(json.dumps({'passed':result['passed'],'failed':result['failed'],'source_sha256':result['source_sha256'],'output':str(output)}))
    raise SystemExit(1 if result['failed'] else 0)

if __name__=='__main__':main()
