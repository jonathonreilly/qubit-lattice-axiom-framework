"""Freeze every actual independent source and preserve complete run/failure streams."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys

OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def execute(source, name, witness=False):
    run=OUT/name;run.mkdir(exist_ok=False)
    actual=[source,OUT/'INDEPENDENT_PROTOCOL_v1.json',OUT/'sources/DERIVATION_v1.md',OUT/'sources/PROTOCOL_v1.json',OUT/'sources/LEE_2020_v1.pdf']
    identities=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in actual]
    save(run/'FREEZE.json',{'at':datetime.now(timezone.utc).isoformat(),'actual_inputs':identities,'mutation_detection_by_science_not_original_hash':True})
    argv=[sys.executable,'-B',str(source),'--inputs',str(OUT),'--output',str(run/'RESULTS.json')]
    if witness:argv.append('--witness-only')
    started=datetime.now(timezone.utc).isoformat()
    r=subprocess.run(argv,cwd=OUT,capture_output=True,timeout=240)
    finished=datetime.now(timezone.utc).isoformat()
    for label,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
        with (run/label).open('xb') as f:f.write(data)
    record={'argv':argv,'cwd':str(OUT),'started_utc':started,'finished_utc':finished,'exit_code':r.returncode,'inputs_unchanged':all(sha(Path(p['path']))==p['sha256'] for p in identities),'source_sha256':sha(source)}
    save(run/'EXECUTION.json',record)
    print(json.dumps(record),flush=True)
    print(r.stdout.decode(),flush=True)
    if r.stderr:print(r.stderr.decode(),flush=True)
    return record

if __name__=='__main__':execute(OUT/'check_independent_v1.py','baseline_v1')
