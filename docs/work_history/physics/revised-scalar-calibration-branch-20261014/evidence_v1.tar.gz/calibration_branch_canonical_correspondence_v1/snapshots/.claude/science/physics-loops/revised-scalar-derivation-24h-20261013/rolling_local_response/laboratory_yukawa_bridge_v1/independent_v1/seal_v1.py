"""Seal this blind focused review once; all source checks remain read-only."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import platform
import sys
import mpmath
import sympy
import fitz

OUT=Path(__file__).resolve().parent
EXCLUDES=['MANIFEST_v1.json','RECEIPT_v1.json']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def rec(p):return {'path':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
def save(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')

assert not any((OUT/n).exists() for n in EXCLUDES)
frozen=load(OUT/'FREEZE_v1.json')
sources=[]
for row in frozen['sources']:
    original=Path(row['original_path']);snapshot=OUT/row['snapshot_path']
    assert sha(original)==sha(snapshot)==row['sha256']
    assert original.stat().st_size==snapshot.stat().st_size==row['bytes']
    sources.append({'original_path':row['original_path'],'original_sha256':row['sha256'],'disposition':'Read in full; independently checked within the stated blind scope; preserved unchanged.','recovery':{'path':str(snapshot),'review_relative_path':row['snapshot_path'],'sha256':row['sha256'],'bytes':row['bytes']},'final_path':row['original_path'],'final_sha256':sha(original)})
assert load(OUT/'sources/PROTOCOL_v1.json')['hand_source_sha256']==frozen['sources'][0]['sha256']
save('SOURCE_DISPOSITIONS_v1.json',{'original_dispositions':sources})
baseline=load(OUT/'baseline_v1/RESULTS.json');execution=load(OUT/'baseline_v1/EXECUTION.json')
assert baseline['passed']==79 and baseline['failed']==0 and len(baseline['checks'])==79 and all(r['passed'] for r in baseline['checks'])
assert execution['exit_code']==0 and execution['inputs_unchanged'] and (OUT/'baseline_v1/stderr.txt').stat().st_size==0
assert baseline['source_sha256']==sha(OUT/'check_independent_v1.py')==execution['source_sha256']
assert len(baseline['responses'])==9
damages=load(OUT/'damages_v1/SUMMARY.json')
commands=[]
for run in [OUT/'baseline_v1']+[OUT/'damages_v1'/r['name'] for r in damages]:
    e=load(run/'EXECUTION.json');fr=load(run/'FREEZE.json');result=load(run/'RESULTS.json')
    assert result['source_sha256']==e['source_sha256']==sha(Path(e['argv'][2]))
    assert all(sha(Path(r['path']))==r['sha256'] for r in fr['actual_inputs'])
    commands.append({'execution':rec(run/'EXECUTION.json'),'freeze':rec(run/'FREEZE.json'),'result':rec(run/'RESULTS.json'),'argv':e['argv'],'cwd':e['cwd'],'exit_code':e['exit_code']})
for row in damages:
    assert row['exit_code']==1 and row['required_witness_failed'] and row['inputs_unchanged']
    result=load(OUT/'damages_v1'/row['name']/'RESULTS.json')
    assert len(result['checks'])==55 and result['passed']==row['passed'] and result['failed']==row['failed']
    assert any(r['name']==row['required_witness'] and not r['passed'] for r in result['checks'])
    src=(OUT/'check_independent_v1.py').read_text();assert src.count(row['before'])==1
    assert src.replace(row['before'],row['after'])==(OUT/'damages_v1'/(row['name']+'.py')).read_text()
save('COMMAND_INDEX_v1.json',{'at':datetime.now(timezone.utc).isoformat(),'actual_scientific_executions':commands,'baseline_outer_command':['python3','-B',str(OUT/'execute_v1.py')],'mutation_outer_command':['python3','-B',str(OUT/'damage_controls_v1.py')],'seal_command':['python3','-B',str(OUT/'seal_v1.py')],'primary_inspection':'PyMuPDF opened the frozen PDF, extracted get_text() for all five pages, rendered each page at Matrix(1.25,1.25); all rendered pages were inspected. The exact preserved PDF is the primary source, not extracted layout alone.','scope':'No parent implementation/result file was read, imported or executed. All actual independent commands and return records are preserved.'})
save('ENVIRONMENT_v1.json',{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'mpmath':mpmath.__version__,'sympy':sympy.__version__,'pymupdf':fitz.__doc__,'arithmetic_dps':70})
files=sorted(p for p in OUT.rglob('*') if p.is_file())
assert not any(p.is_symlink() for p in OUT.rglob('*'))
artifacts=[rec(p) for p in files if p.relative_to(OUT).as_posix() not in EXCLUDES]
save('MANIFEST_v1.json',{'at':datetime.now(timezone.utc).isoformat(),'excludes':EXCLUDES,'artifact_count':len(artifacts),'artifacts':artifacts})
receipt={'at':datetime.now(timezone.utc).isoformat(),'scope':'Focused blind laboratory-calibration proof/geometric review, not formal audit, empirical fit, or producer implementation check.','report':rec(OUT/'REPORT_v1.md'),'manifest':rec(OUT/'MANIFEST_v1.json'),'hand_derivation':rec(OUT/'HAND_DERIVATION_v1.md'),'protocol':rec(OUT/'INDEPENDENT_PROTOCOL_v1.json'),'independent_code':rec(OUT/'check_independent_v1.py'),'execution_driver':rec(OUT/'execute_v1.py'),'mutation_driver':rec(OUT/'damage_controls_v1.py'),'baseline_results':rec(OUT/'baseline_v1/RESULTS.json'),'baseline_execution':rec(OUT/'baseline_v1/EXECUTION.json'),'damage_summary':rec(OUT/'damages_v1/SUMMARY.json'),'failure_ledger':rec(OUT/'FAILURES_v1.md'),'command_index':rec(OUT/'COMMAND_INDEX_v1.json'),'dispositions':rec(OUT/'SOURCE_DISPOSITIONS_v1.json'),'source_bindings':frozen['sources'],'artifact_count':len(artifacts),'baseline_counts':{'passed':79,'failed':0},'damage_counts':[{'name':r['name'],'passed':r['passed'],'failed':r['failed'],'exit_code':r['exit_code'],'required_witness_failed':r['required_witness_failed']} for r in damages],'no_required_parent_source_correction':True,'primary_pdf_sha256':frozen['sources'][2]['sha256'],'limitations':['Common unscreened frozen-background and gain premises remain supplied.','Signed normalized response is not uniform near torque/calibration nulls.','Finite high-precision toy quadrature is not a certified real-instrument likelihood.','No published range bound is transferred to q<1/3.','Parent execution counts communicated in a message were not used as evidence.']}
save('RECEIPT_v1.json',receipt)
for row in artifacts:assert rec(OUT/row['path'])==row
print(json.dumps({'artifacts':len(artifacts),'source_pairs':len(sources),'report':rec(OUT/'REPORT_v1.md'),'manifest':rec(OUT/'MANIFEST_v1.json'),'receipt':rec(OUT/'RECEIPT_v1.json'),'dispositions':rec(OUT/'SOURCE_DISPOSITIONS_v1.json')},indent=2))
