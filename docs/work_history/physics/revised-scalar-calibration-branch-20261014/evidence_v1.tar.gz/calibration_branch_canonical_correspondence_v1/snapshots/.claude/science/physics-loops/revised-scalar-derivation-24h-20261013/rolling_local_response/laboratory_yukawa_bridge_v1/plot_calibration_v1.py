from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=Path(__file__).parent
result=json.loads((p/'baseline_v2/RESULTS.json').read_text())
rows=[r for r in result['records'] if float(r['mu'])>0]
lam=np.array([1/float(r['mu']) for r in rows])
ys=np.array([float(r['y_science']) for r in rows])
yc=np.array([float(r['y_calibration']) for r in rows])
ratio=np.array([float(r['normalized_ratio']) for r in rows])
order=np.argsort(lam)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(11,4.6),layout='constrained')
ax[0].semilogx(lam[order],ys[order],'o-',label='Science toy')
ax[0].semilogx(lam[order],yc[order],'s-',label='Calibration toy')
ax[0].set(xlabel='Scalar range (m)',ylabel='Yukawa / Newtonian harmonic',title='Both geometries respond at long range')
ax[0].legend(frameon=False)
ax[1].semilogx(lam[order],ratio[order]-1,'o-',color='#7547a8')
ax[1].axhline(0,color='#777777',lw=.8)
ax[1].set(xlabel='Scalar range (m)',ylabel='Calibrated torque ratio minus 1',title='Calibration removes the common limit')
fig.suptitle('Conditional calibration bridge: synthetic q = 0.2')
fig.supxlabel('Ideal three-mass rings, assumed geometry; points are computations, lines guide the eye. No laboratory data fit.',fontsize=9)
fig.savefig(p/'CALIBRATED_TORQUE_v1.png',dpi=180)
fig.savefig(p/'CALIBRATED_TORQUE_v1.pdf')
np.savez_compressed(p/'CALIBRATED_TORQUE_DATA_v1.npz',range_m=lam,y_science=ys,y_calibration=yc,normalized_ratio=ratio)
