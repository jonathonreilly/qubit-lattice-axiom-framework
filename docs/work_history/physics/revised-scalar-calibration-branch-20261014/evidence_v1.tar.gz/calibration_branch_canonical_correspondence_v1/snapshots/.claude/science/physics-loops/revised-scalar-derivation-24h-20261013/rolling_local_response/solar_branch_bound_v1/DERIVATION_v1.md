# Negative-branch coupling floor and a conditional light-time benchmark

Personally derived by /root. Complete candidate action and the existing weak-source/environment derivations remain premises. This is a new exact branch inequality plus a transparent comparison with an exposed published parameter estimate. It is not a reconstructed Cassini likelihood, a derived Solar environmental solution, or a global exclusion of the scalar theory.

## 1. The observation fixes what a bridge must deliver

Bertotti, Iess and Tortora (Nature425,374-376,2003; DOI10.1038/nature01997) report gamma-1=(2.1+/-2.3) times10^-5. The primary publisher's indexed abstract supplies this value; the full article/likelihood was not acquired in this block. We use the explicit central-value plus/minus two reported-error interval [-2.5,6.7] times10^-5 as a compatibility benchmark. We do not equate that construction to a new confidence analysis or independent empirical test. This observation is now exposed development information.

The frozen weak, unscreened, long-range source calculation already gives

    gamma_model-1=-2q/(1+q), q=|d ln A|_K^2.             (1)

Its application to light time requires the same weak potential normalization from matter dynamics and photons, negligible scalar mass/mixing over the relevant Solar-System distances, negligible background evolution and source pressure/strong-field corrections, and a correctly matched ambient field. An actual solar solution was not derived. Introduce a separately established absolute bridge-error bound epsilon_gamma>=0:

    gamma_prediction-1=-2q/(1+q)+delta_gamma,
    |delta_gamma|<=epsilon_gamma.                        (2)

If the predicted value is to intersect an observed interval with lower endpoint L, a necessary condition is

    2q/(1+q)<=epsilon_gamma-L=:eta.

For 0<=eta<2 this gives q<=eta/(2-eta). If eta<0, no nonnegative q works; if eta>=2 this inequality supplies no finite bound. Unknown bridge error does not yield a bound. We do not absorb an arbitrarily large correction into a claim that the weak approximation worked.

## 2. Exact coupling on the already studied branch

For 0<k<1/3, define a=(1-k)(1+3k)/4 and s=(1+k)/[k(1-3k)]. On the negative-u branch z=A in(0,1], let D=1+s-s z^2. The supplied field metric gives

    q(z)=a D/[1+s-3a s z^2].                             (3)

The denominator is positive. Direct differentiation gives

    dq/dz=2a s(1+s)(3a-1)z/[1+s-3a s z^2]^2<0,
    q(1)=k, lim_(z->0)q(z)=a,
    a-k=(1-3k)(1+k)/4>0.                                (4)

Thus k<=q<a on this branch, with the left equality only at z=1. This is independent of nu and of the prescribed density value. Moving to denser negative-u stationary configurations cannot suppress the local coupling norm below its vacuum value. It can change the range and the body's nonlinear scalar charge; neither is determined by this norm statement. We do not assert (4) for positive u or for every possible stationary branch.

Solving(3) yields the exact conformal change

    1-A^2=(1-3k)(q-k)/[(1+k)(1-3q)].                      (5)

For any supplied bound k<=q<=qmax<1/3,

    0<=1-A^2<=(1-3k)(qmax-k)/[(1+k)(1-3qmax)]
              <=qmax/(1-3qmax).                         (6)

At fixed Q, Gbare/Gvac=A^2, where Gvac=1/(8piQ) is a theoretical reference, not an independently measured cosmic G. A controlled light long-range Solar matching to this branch therefore also bounds the local-to-reference conformal change. It does not calibrate Gvac or select a physical cosmology.

## 3. Transparent conditional numbers and failures

With epsilon_gamma=0 and the stated benchmark lower endpoint, eta=2.5e-5 and qmax=eta/(2-eta)=1/79999, approximately1.2500156e-5. Necessarily k<=qmax. The k-independent conformal ceiling is1/79996, approximately1.2500625e-5. These are conditional benchmark transformations, not newly fitted parameter posteriors.

Freeze additional bridge-error examples epsilon_gamma=1e-5 and1e-4 to show how the bound depends on the error premise. Also freeze synthetic couplings k=1e-6,1e-5,0.01,0.1,0.3 and z=1,0.9,0.5,0.01 for exact branch tests. These choices are exposed model-development inputs. No value is selected by the data here.

For a trial q, the smallest bridge-error allowance that can reach the lower observation edge is max(0,L+2q/(1+q)). Moderate q therefore cannot be reconciled by a small unspecified correction within this long-range weak-source class. Finite range, nonlinear source screening, positive-u matching or a different action must instead be explicitly solved and tested if used; their names are not derivations or automatic loopholes. A theory with sufficiently small k is not ruled out by this conditional argument, and no state-preparation or vacuum-energy assumption is eliminated.

## 4. Frozen checks

Check all branch identities, denominator and derivative signs, exact inverse relation, endpoint restrictions and numeric interval transformation. Use independent substitutions in original E=e^(2sqrt(a)u) coordinates, negative/positive-u counterexamples to overbroad claims, and actual altered-program controls for the coupling denominator, gamma coefficient and bound sign. Preserve full computations, sources, failures and source versions. Do not rerun or rewrite older sealed units.
