#!/usr/local/bin/python3
from pathlib import Path
import sympy as S
import json,hashlib,argparse

DENOMINATOR_FACTOR=S.Integer(3)
GAMMA_FACTOR=S.Integer(1)
BOUND_SIGN=S.Integer(1)

def run():
    rows=[];cases=[]
    def ck(n,b,detail=None):rows.append(dict(name=n,passed=bool(b),detail=detail))
    def eq(n,e):v=S.factor(S.cancel(e));ck(n,v==0,str(v))
    k,z,E,Q=S.symbols('k z E Q',positive=True)
    a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));D=1+s-s*z*z
    q=a*D/(1+s-DENOMINATOR_FACTOR*a*s*z*z)
    original=a/(1+(1-3*a)*s*E)
    eq('coordinate_inversion',original.subs(E,z*z/D)-q)
    eq('vacuum_coupling',q.subs(z,1)-k)
    eq('coupling_limit',S.limit(q,z,0)-a)
    eq('a_minus_k',a-k-(1-3*k)*(1+k)/4)
    eq('negative_derivative_coefficient',3*a-1+(1-3*k)**2/4)
    eq('coupling_derivative',S.diff(q,z)-2*a*s*(1+s)*(3*a-1)*z/(1+s-3*a*s*z*z)**2)
    eq('conformal_inverse',1-z*z-(1-3*k)*(q-k)/((1+k)*(1-3*q)))
    g,eta,lo,ep=S.symbols('g eta lo ep',real=True)
    qbound=BOUND_SIGN*eta/(2-eta)
    eq('bound_inversion',GAMMA_FACTOR*qbound/(1+qbound)-eta)
    eq('gamma_relation',(-GAMMA_FACTOR*g/(1+g))-((1-g)/(1+g)-1))
    observed_c=S.Rational(21,1000000);observed_e=S.Rational(23,1000000)
    lower=observed_c-2*observed_e;upper=observed_c+2*observed_e
    eq('published_benchmark_lower',lower+S.Rational(25,1000000));eq('published_benchmark_upper',upper-S.Rational(67,1000000))
    qb0=qbound.subs(eta,-lower);eq('zero_error_q_cap',qb0-S.Rational(1,79999));eq('zero_error_conformal_cap',qb0/(1-3*qb0)-S.Rational(1,79996))
    bridge=[]
    for ev in [S.Integer(0),S.Rational(1,100000),S.Rational(1,10000)]:
        et=ev-lower;qb=qbound.subs(eta,et);pred=-GAMMA_FACTOR*qb/(1+qb)+ev
        eq('edge_matches_'+str(ev),pred-lower)
        ck('finite_bound_domain_'+str(ev),0<=et<S.Rational(1,2),str(et))
        bridge.append(dict(epsilon_gamma=str(ev),q_cap=str(qb),q_cap_decimal=str(S.N(qb,20)),conformal_cap=str(qb/(1-3*qb))))
    for kv in [S.Rational(1,10**6),S.Rational(1,10**5),S.Rational(1,100),S.Rational(1,10),S.Rational(3,10)]:
        av=a.subs(k,kv);sv=s.subs(k,kv)
        for zv in [S.Integer(1),S.Rational(9,10),S.Rational(1,2),S.Rational(1,100)]:
            sub={k:kv,z:zv};qv=S.factor(q.subs(sub));Dv=D.subs(sub);Ev=S.factor(zv*zv/Dv);tag=str(kv)+'_'+str(zv)
            ck('positive_denominator_'+tag,(1+sv-3*av*sv*zv*zv)>0)
            ck('coupling_floor_and_ceiling_'+tag,kv<=qv<av)
            ck('negative_derivative_'+tag,S.diff(q,z).subs(sub)<0)
            eq('independent_E_coordinate_'+tag,original.subs({k:kv,E:Ev})-qv)
            eq('exact_G_change_'+tag,1-zv*zv-(1-3*kv)*(qv-kv)/((1+kv)*(1-3*qv)))
            predicted=-GAMMA_FACTOR*qv/(1+qv);error_need=S.Max(0,lower-predicted)
            cases.append(dict(k=str(kv),A=str(zv),q=str(qv),gamma_minus_one=str(predicted),minimum_bridge_error=str(error_need),passes_zero_error_benchmark=bool(lower<=predicted<=upper)))
        posq=original.subs({k:kv,E:4});ck('positive_u_breaks_floor_'+str(kv),posq<kv,str(posq))
    # Bound monotonicity and exact nonempty subdomain, never promote to a global no-go.
    qq,kk,bb=S.symbols('qq kk bb',positive=True)
    deficit=(1-3*kk)*(qq-kk)/((1+kk)*(1-3*qq))
    eq('deficit_monotonicity',S.diff(deficit,qq)-(1-3*kk)**2/((1+kk)*(1-3*qq)**2))
    for kv in [S.Rational(1,10**6),S.Rational(1,10**5)]:
        upperdef=deficit.subs({kk:kv,qq:qb0})
        ck('conformal_universal_bound_'+str(kv),0<upperdef<=qb0/(1-3*qb0),str(upperdef))
        z2=1-upperdef;eq('qcap_attained_at_derived_z_'+str(kv),q.subs(k,kv).subs(z*z,z2)-qb0)
    ck('eta_negative_impossible',S.Rational(-1,100)<0)
    for test in [S.Rational(1,100),S.Rational(1,2),S.Rational(1,1),S.Rational(100)]:ck('eta_two_no_finite_cap_'+str(test),2*test/(1+test)<2)
    return dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,published_benchmark=dict(central=str(observed_c),reported_error=str(observed_e),lower=str(lower),upper=str(upper),interval_convention='central plus/minus two reported errors; not reconstructed confidence likelihood'),bridge_bounds=bridge,synthetic_cases=cases,scope='Negative-u branch plus explicitly controlled weak long-range light-time bridge; no solved Solar background or global theory exclusion.',checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();r=run();assert not a.out.exists();a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['passed','failed','bridge_bounds']}));raise SystemExit(bool(r['failed']))
