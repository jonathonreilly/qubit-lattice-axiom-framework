# Independent hand derivation before executable controls

Reviewer /root/scalar_energy_check; scientific author /root. The five exact source snapshots are fixed in SOURCE_BINDINGS_v1.json. No author implementation, author result or earlier independent checker has been read or imported. The argument below was constructed before writing the numerical/symbolic checker. The primary HTML was used only to inspect the published abstract and access status.

## Action normalization and the invariant local norm

Write the supplied action as Q integral sqrt(-g)[R/2-K_AB partial phi^A partial phi^B-2Hv^2 U]+Sm[A^2 g,matter]. This normalization is equivalent to (16pi Gstar)^-1[R-2K_AB partial phi^A partial phi^B-4Hv^2U], with Gstar=1/(8pi Q). Its scalar variation, after dividing by 2Q, gives the matter source -K^AB beta_B T_E/(2Q), where beta=d ln A. For a static weak dust perturbation T_E=-rho_E this is +4pi Gstar beta^A rho_E. The factor is 4pi, not 8pi; K has no extra 1/2 in the originally supplied action.

Set E=exp(2sqrt(a)u), F=1+sE and J=1+(1-3a)sE. The conformal factor C=A^2=(1+s)E/F has derivative C_E=(1+s)/F^2. Consequently

    beta_u = sqrt(a) E C_E/C = sqrt(a)/F,
    K_uu = J/F^2,
    q = beta_A K^AB beta_B = a/J.

The other two components of beta vanish. The norm is therefore independent of x,y, nu and the potential; those quantities can still matter to the spectrum and the actual body response. This is a field-metric norm, not the coordinate derivative beta_u^2 alone.

For the declared weak, isolated, nonrelativistic source, frozen ambient background and negligible mass/mixing/time-dependent terms, the Einstein monopole is delta phi^A=-beta^A Ustar. Thus delta ln A=-q Ustar. Multiplying the Einstein weak metric by A^2 gives the positive-potential coefficients Phi_J=(1+q)Ustar and Psi_J=(1-q)Ustar. Photons depend on their sum, whereas slow matter normalizes Phi_J. Hence

    gamma-1 = Psi_J/Phi_J -1 = -2q/(1+q),
    G_dyn = Gstar C(1+q),  G_bare = Gstar C.

The constant-background conversions M_E=A_b M_J and r_J=A_b r_E give Ustar=Gstar C_b M_J/(r_J c^2), consistently in both potentials. This derivation does not bound the neglected operator/body terms or compute a Solar profile. It establishes the conditional principal formula, not a fitted PPN parameter in an arbitrary environment.

## Use E directly for the negative branch

I use E, rather than the source's z coordinate, to expose the signs. In 0<k<1/3,

    1-3a=(1-3k)^2/4 >0,
    a-k=(1-3k)(1+k)/4 >0,
    s>0,
    k(1-3a)s=a-k.

Define B=(1-3a)s=(a-k)/k>0. Then J=1+BE and

    q(E)-k=(a-k)(1-E)/J,
    a-q(E)=aBE/J,
    dq/dE=-aB/J^2<0.

For finite u<=0, 0<E<=1. These identities directly prove k<=q<a; q=k iff E=1 iff u=0. The upper value a occurs only in the excluded E=0 limit u->-infinity. Since a<1/3,1-3q>0 everywhere on this branch. The condition u=0 fixes the conformal reference C=1 and q=k. A complete vacuum additionally requires x=y=0 and the appropriate matter/background state.

C_E>0 and C(1)=1, so 0<C<=1. Let v=C=z^2. Solving only the rational coordinate conversion gives

    E=v/(1+s-sv),
    q(v)=a(1+s-sv)/(1+s-3asv).

For 0<v<=1 the denominator is at least 1+s(1-3a)>0. Differentiating the conversion after the E proof recovers the source's dq/dz, with sign controlled by 3a-1<0. Neither a density value nor a stationary density map is needed for the norm floor: every field point with u<=0 has it. Any statement about a denser stationary family must additionally use its stationary density relation, but it cannot evade this pointwise floor while remaining on the same branch.

For u>0, E>1 instead gives q<k and C>1. An exact positive-E counterexample will be included, so the floor cannot be extended silently to the entire finite chart. The endpoints k=0 and k=1/3 are outside the supplied action parameter domain; singular s formulas there must not be inserted as ordinary theorem points.

## Conformal inverse and inequality directions

From the original E formulas,

    1-C=(1-E)/F,
    1-3q=(1-3a)F/J.

Taking the ratio with q-k eliminates E and yields

    1-C = (1-3k)(q-k)/[(1+k)(1-3q)] = H(k,q).

Here H_q=(1-3k)^2/[(1+k)(1-3q)^2]>0. Thus, for a separately supplied cap k<=q<=qmax<1/3,

    0<=1-C<=H(k,qmax).

The relaxation independent of k has an explicit positive gap:

    qmax/(1-3qmax)-H(k,qmax)
      =k(1-3k+4qmax)/[(1+k)(1-3qmax)]>0.

This proves the stated non-strict upper inequality, with a stronger strict final comparison for each allowed k. At qmax=k the sharp branch result is C=1. If qmax<k there is no branch point satisfying the cap; inserting it into the algebra to obtain a negative upper bound would misuse the hypothesis. If qmax>=1/3 the written comparison is outside its domain. If qmax>=a the cap need not restrict this branch, even when qmax<1/3; the finite-chart bound 1-C<1 remains available. These are limitations of useful bounds, not counterexamples to the stated conditional inequality.

The source reference Gvac=1/(8pi Q) is the bare vacuum reference. At fixed Q, G_bare/Gvac=C exactly. It is not generally the dynamical vacuum coefficient G_dyn,vac=Gvac(1+k). For example at E=1, G_bare/Gvac=1 but G_dyn/Gvac=1+k. No external Newton calibration follows merely from the conformal identity.

## Interval and error-envelope reasoning

Let f(q)=-2q/(1+q) and let a known absolute error bound be epsilon>=0. A possible prediction lies in [f(q)-epsilon,f(q)+epsilon]. For intersection with a supplied observation interval[L,U], the exact two-sided condition is

    f(q)+epsilon>=L and f(q)-epsilon<=U.

The first is the necessary condition 2q/(1+q)<=eta=epsilon-L. Its left side increases from 0 toward 2 for q>=0. Therefore eta<0 permits no nonnegative q; eta=0 permits only q=0; 0<=eta<2 gives q<=eta/(2-eta); eta>=2 imposes no finite cap through this inequality. The candidate has q>=k>0, so eta=0 also excludes the negative branch for every allowed fixed k.

For the exposed benchmark U>0, f(q)<=0 and epsilon>=0 make the second inequality automatic. In that particular case the lower-edge condition is equivalent to intersection of the error envelope and the benchmark interval. It still does not guarantee that the actual unknown delta realizes an allowed value. For a general interval with U<0 the second inequality can fail even when the lower-edge condition holds. I will preserve a rational witness for that distinction.

The exact minimum error allowance for an arbitrary interval is

    max(0,L-f(q),f(q)-U).

For the benchmark's positive U this reduces to max(0,L+2q/(1+q)), matching the source's lower-edge formula. With an unknown/unbounded error budget, one can always enlarge the allowance; no useful data-derived cap follows. Applying the conformal comparison further needs qmax<1/3, equivalent to eta<1/2 when qmax=eta/(2-eta). The listed small-error benchmarks satisfy that condition.

## Exposed observation and exact arithmetic

The saved Nature publisher HTML visibly reports gamma=1+(2.1 +/-2.3)*10^-5 in its abstract, gives DOI 10.1038/nature01997 and explicitly calls the page a preview of subscription content. The full analysis, nuisance fit, covariance and likelihood are not in the acquired page. The source's central plus/minus twice the reported error is a constructed compatibility interval, not a new confidence calculation. The role is exposed benchmark input, not held-out validation.

Using these decimal quantities exactly,

    L=-1/40000, U=67/1000000.
    epsilon=0:       eta=1/40000, qmax=1/79999,
                     qmax/(1-3qmax)=1/79996.
    epsilon=1/100000: eta=7/200000, qmax=7/399993,
                     qmax/(1-3qmax)=7/399972.
    epsilon=1/10000:  eta=1/8000, qmax=1/15999,
                     qmax/(1-3qmax)=1/15996.

The quoted approximate decimals are approximations to exact fractions, not outward-rounded certified ceilings by themselves. The exact fractions carry the inequality. A separate synthetic error allowance and exact endpoint-contact tests will avoid merely copying those three author inputs.

## Range, source matching and state selection remain independent

The local norm does not involve U, but the action's vacuum radial mass is Hv^2 K_uu^-1 U_uu. At the origin,

    U_uu=[12as+nu(1+s)]/(1+s)^2,
    m_u^2/Hv^2=4[3(1+k)+nu]/(1-3k).

It can increase without bound with nu at the same q=k. Thus the norm floor alone cannot prove a long range. Conversely the conditional long-range formula cannot be rescued automatically by saying range or screening is different; such a prediction needs a new controlled operator/source calculation. Nonlinear body charge, ambient matching, pressure, scalar initialization, background evolution and actual experimental normalization are not fixed by q. Small enough k is not excluded by the necessary benchmark transformation. Neither the existence nor preparation of the chosen negative branch follows from this proof.

## Planned independent controls

Use exact rational k=2/17,7/40,5/19,1/170000 and E=1,4/5,2/7,1/23. These are distinct from the author's k/z grid. Derive beta by differentiating the original rational C(E), contract with K, and compare with the source's v=z^2 expression. Symbolic identities and exact rational sign checks support the handwritten all-domain proof; they do not replace it. Include E>1, E=0, qmax=k, qmax<k, eta<0, eta=0, eta=2, a general negative-U interval, and the distinction between bare and dynamical normalization.

Run the original independent checker and actual changed copies: alter the coupling denominator coefficient, spatial potential contribution to gamma, lower-edge error sign, conformal denominator sign, and inverse-bound denominator sign. Every damaged program must execute the same controls, save its own complete results/streams and fail a named mathematical witness. No parent implementation is an oracle. All source versions, failed controls and exact commands will be retained, and any unexpected failure will be diagnosed without overwriting the original evidence.
