# Independent check of the negative-branch solar benchmark bound

Reviewer: /root/scalar_energy_check. Scientific author: /root. This is a focused mathematical check of the exact branch inequalities and the transformation of a separately supplied gamma interval/error budget. It is not a formal audit, Solar-System fit, stellar matching calculation, screening theorem or new selection of a physical state.

The source equations and their stated conditional numerical consequences agree with an independent reconstruction from the full supplied action. No source correction is required. The proof holds on the declared negative-u branch and parameter domain. The experimental interpretation remains contingent on an independently controlled weak-source/light-time model and its error budget; the mathematical bound does not supply those controls.

The independent hand derivation was frozen before the executable checker. The actual baseline returned 231 passed checks and zero failures. Five actual changed programs were executed and each failed its designated mathematical witness, with 19, 15, 22, 31 and 20 failed checks respectively. All results, sources, exact differences, commands and streams remain complete. There was no unexpected baseline or process failure. The author implementation/results files were neither read nor imported.

## Frozen sources and primary observation

| Input | SHA256 |
|---|---|
| solar_branch_bound_v1/DERIVATION_v1.md | 3ec70620dade0fd5367cd7ec93edaad951e536b3ab2573e34dcce00eaa7e2bc0 |
| solar_branch_bound_v1/PROTOCOL_v1.json | e01ebb26596673592bd55bfba1829f1135f1a767f847641037445310528295b0 |
| complete supplied action note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| conditional local-response note | b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68 |
| saved Nature publisher HTML | 5ac46e690c57f4e7ef1994ed69bc33efd307006b416de290c18b62ecd655e110 |

All five original/snapshot pairs are byte-exact and retained under sources/. Only these named external sources were accessed for this unit. No producer code/results file or older independent checker was accessed. The existing canonical action/local-response notes were premises, not executable oracles; the normalization and coupling calculations below were reconstructed directly.

The supplied [Nature publisher page](https://www.nature.com/articles/nature01997) has the title, authors, 2003 publication metadata and DOI 10.1038/nature01997. Its visible abstract reports gamma=1+(2.1±2.3)×10^-5 from the Cassini radio-frequency-shift experiment near the Sun. It explicitly identifies the page as a subscription preview. The saved HTML is 285297 bytes and its local extraction, relevant metadata, exact result text and five verification checks are retained. This unit did not retrieve or inspect the full likelihood or full article. The saved page was inspected locally; no new network request or empirical dataset was introduced.

The central value plus/minus twice the reported error gives L=-1/40000 and U=67/1000000 by exact decimal arithmetic. That construction is a transparent compatibility benchmark. The abstract alone does not justify assigning a new confidence level, nuisance fit or likelihood to it. The result was exposed before these calculations and is not a held-out observational test.

## Independent normalization and branch proof

The action is Q integral sqrt(-g)[R/2-K_AB partial phi^A partial phi^B-2Hv^2U]+Sm[A^2g,matter]. Because the kinetic term has no extra 1/2, the scalar matter source after division by 2Q is -K^AB beta_B T_E/(2Q). For weak nonrelativistic matter T_E=-rho_E, this becomes +4pi Gstar beta^A rho_E, with Gstar=1/(8pi Q). This checks the force normalization used by the weak-source premise.

Starting from E=exp(2sqrt(a)u), C=(1+s)E/(1+sE), F=1+sE and J=1+(1-3a)sE, differentiation gives

    beta_u = sqrt(a) E C_E/C = sqrt(a)/F,
    K_uu = J/F^2,
    q = beta_A K^AB beta_B = a/J.

The transverse beta components vanish. Thus q is independent of the transverse coordinates and potential parameters, but the actual mass/mixing operator and source response need not be. The conditional Einstein monopole has delta phi^A=-beta^A Ustar, hence delta ln A=-qUstar. Conformal multiplication gives Phi_J=(1+q)Ustar and Psi_J=(1-q)Ustar. With matter dynamics normalizing Phi_J and photons probing their sum, gamma-1=Psi_J/Phi_J-1=-2q/(1+q). The constant-frame mass/radius conversions give the same Ustar in both coefficients. This does not derive a finite-distance Solar measurement from the local principal operator.

The proof of the floor uses E directly, rather than copying the source's z derivative. On 0<k<1/3,

    1-3a=(1-3k)^2/4>0,
    a-k=(1-3k)(1+k)/4>0,
    B=(1-3a)s=(a-k)/k>0.

Consequently

    q-k=(a-k)(1-E)/(1+BE),
    a-q=aBE/(1+BE),
    dq/dE=-aB/(1+BE)^2<0.

Finite u<=0 means 0<E<=1, proving k<=q<a exactly. Equality q=k requires E=1, so u=0 and C=1. This is the conformal reference coordinate; a complete vacuum state additionally requires the appropriate transverse and matter/background data. The upper limit q=a is reached only as E->0, corresponding to u->-infinity, not at a finite field point. The endpoint parameters k=0 and k=1/3 are outside the model domain and cannot be inserted into singular s formulas as ordinary cases.

Solving the rational C conversion for E gives E=C/(1+s-sC). Substitution produces the source's q(z) with C=z^2. Its denominator is positive for 0<z<=1, and its differentiated expression agrees exactly. The pointwise floor does not require an assumed stationary density value or a density-history solution. It therefore applies to any negative-u stationary configuration if that configuration is actually realized, but does not construct or select one.

An explicit scope witness is k=2/17,E=5/2, for which q=460/7463<k and C=575/553>1. It is a valid positive-u point and disproves extending the negative-branch floor to all fields. It is not a derived solar environment.

## Exact inverse, signs and endpoints

The identities 1-C=(1-E)/F and 1-3q=(1-3a)F/J eliminate E independently of the source's solved expression:

    1-C = H(k,q)
        = (1-3k)(q-k)/[(1+k)(1-3q)].

Here 1-3q>0 and

    H_q=(1-3k)^2/[(1+k)(1-3q)^2]>0.

Thus k<=q<=qmax<1/3 implies 0<=1-C<=H(k,qmax). The relaxed bound has the explicit positive gap

    qmax/(1-3qmax)-H(k,qmax)
       =k(1-3k+4qmax)/[(1+k)(1-3qmax)]>0.

This confirms the source's inequality directions and even supplies a strict final comparison for each allowed k. At qmax=k the sharp branch conclusion is C=1. If qmax<k there is no allowed branch point; a negative substituted upper bound must not be interpreted as a physical conformal constraint. If qmax>=1/3 the stated rational ceiling is outside its domain. If qmax>=a while remaining below 1/3, it may give no useful new restriction on this branch, although the inequality is still valid. The finite-chart inequality 1-C<1 also remains true.

The ratio G_bare/Gvac=C is correct at fixed Q when Gvac=1/(8pi Q) is the stated bare reference. It does not identify that reference with a calibrated gravitational constant. In particular G_dyn=Gvac C(1+q); at k=2/17,E=1 one has G_bare/Gvac=1 but G_dyn/Gvac=19/17. The scalar norm and the conformal factor are different physical quantities, and the theoretical reference is not selected by the benchmark.

## Error-envelope and observed-interval transformation

Let f(q)=-2q/(1+q). A separately justified absolute error epsilon places a possible prediction in [f(q)-epsilon,f(q)+epsilon]. Intersection with an arbitrary supplied interval [L,U] requires both f(q)+epsilon>=L and f(q)-epsilon<=U. The first condition gives

    2q/(1+q)<=eta=epsilon-L.

For q>=0 this monotone function rises from 0 toward 2. If eta<0 there is no nonnegative solution. At eta=0 only q=0 works in that general algebra; the negative branch has q>=k>0 and therefore no solution. For 0<=eta<2 the cap is eta/(2-eta). For eta>=2 the lower edge supplies no finite cap. An unknown or unlimited bridge error supplies no useful constraint. To apply the additional qmax<1/3 conformal ceiling using this cap, eta must be below 1/2. All listed small-error benchmarks satisfy that condition.

The source correctly calls the lower-edge condition necessary. It is not generally sufficient for a two-sided interval. For example, q=2/17 gives f=-4/19. With [L,U]=[-4/5,-3/5] and epsilon=0, the lower condition holds while the upper condition fails. The exact interval-distance allowance is 37/95. This witness is retained to prevent broadening the source's claim.

For the specific exposed benchmark, U>0 while f<=0 and epsilon>=0, so the upper condition is automatic. In that case the lower condition is equivalent to intersection of the error envelope with the benchmark. This means that some allowed delta can lie in the interval; it does not ensure that the actual unknown physical delta does so. Neither stochastic assumptions nor a prior on delta is supplied.

The exact minimum allowance for a general interval is max(0,L-f,f-U). For the benchmark's positive upper edge it reduces to max(0,L+2q/(1+q)), agreeing with the source. Exact witnesses include zero allowance at q=1/190000, 39989/440000 at q=1/21, and 559953/1880000 at q=7/40. These illustrate dependence on the supplied error premise, not estimates of an actual solar-model error.

| Absolute error epsilon | Exact qmax | Relaxed conformal ceiling qmax/(1-3qmax) |
|---|---|---|
| 0 | 1/79999 | 1/79996 |
| 1/100000 | 7/399993 | 7/399972 |
| 1/10000 | 1/15999 | 1/15996 |
| 9/2000000, separate reviewer case | 59/3999941 | 59/3999764 |

Every boundary-contact identity and a rational point above each cap was checked exactly. The source's approximate decimals agree with the exact fractions to their displayed precision. The fractions carry the ceiling; the approximate decimal strings are not separately certified outward upper bounds. Necessarily k<=qmax for the declared branch/readout/error premises, but this is not a new fitted posterior or a global exclusion.

## Range, screening and solar matching are not established

The norm q contains no nu, whereas the supplied potential's vacuum Hessian gives

    m_u^2/Hv^2=4[3(1+k)+nu]/(1-3k).

I derived that expression from the original potential and K at the origin as a focused limitation control. At the same k=q=2/17, changing nu from 1/7 to 11/2 changes m_u^2/Hv^2 from 1664/77 to 602/11. It can grow without bound with nu while q stays fixed. Hv itself is also supplied. Therefore the norm inequality cannot establish a long physical range. These vacuum coefficients are not substituted for an environmental or rolling perturbation spectrum.

The light-time application needs an actual weak-source normalization, controlled scalar range/mixing, local curvature/time variation, pressure/strong-field corrections and correct ambient/body matching. Nonlinear scalar charge or screening is not fixed by the local norm. Conversely naming one of those effects does not derive a viable alternative prediction. The source explicitly leaves those calculations open and does not claim an actual Cassini likelihood fit, a matched Solar solution, absence of screening, empirical acceptance or universal exclusion of the action. It also does not eliminate state preparation or vacuum-energy premises. Sufficiently small k remains compatible with the necessary algebraic cap under its conditions; no realized k or state is selected.

## Independent computations and actual failed controls

The executable route first differentiates the original C(E), constructs beta squared and contracts with the original radial metric. It then compares that result with the source's z formula. The independent exact rational grid uses k=2/17,7/40,5/19,1/170000 and E=1,4/5,2/7,1/23. These are distinct from the author's k/z grid. The hand proof supplies the complete domain/sign argument; the 16 exact points support it rather than replacing it. Additional exact controls cover the cap endpoints, invalid domains, positive-u extension, bare/dynamical normalization, error intervals and potential/range distinction.

The run used Python 3.12.8 and SymPy 1.14.0 plus standard-library Fraction arithmetic. No approximate cosmological history, root search, quadrature, fit or producer helper was run. The baseline checker hash is `2764f500611acf542436b2d143fcdd2b6b004263c5da2f01773041716f52998a`, and the complete baseline result hash is `cf6274d034a8a2c2a6176addc47253e7d7c9763b85622b762f3cea4945638d18`; the final receipt binds the actual source hash. No floating-point tolerance is used in the 231 mathematical controls.

| Actual changed implementation | Passed / failed | Required failing witness |
|---|---:|---|
| coupling denominator coefficient 3 to 2 | 212 / 19 | symbolic.action_to_z_norm |
| spatial potential q weight 1 to 0 | 216 / 15 | symbolic.gamma_metric_ratio |
| lower observation edge sign -1 to +1 | 209 / 22 | benchmark.zero_error_cap |
| conformal denominator sign -1 to +1 | 200 / 31 | symbolic.exact_conformal_inverse |
| inverse-budget denominator sign -1 to +1 | 211 / 20 | benchmark.zero_error_cap |

Each damaged program is a real, separately executed full copy with exactly one declared replacement. Each retains all 231 control rows, exits 1, has its own matching script/result hash, and fails the named mathematical witness rather than merely a source-identity check. Each stdout equals its full saved result; stderr is empty. The original baseline exits 0. FAILURES_v1.json retains every failed row, and commands/ contains the exact argv/cwd/timestamps, source hashes and streams. Expected domain exceptions are labeled as such, not hidden process errors. CONTROL_EXECUTION_SUMMARY_v1.json has SHA256 `fa84eb61dab47bebb86947d0201bcf1686debc62f168f189e59d89948df29db8`.

The primary-page inspection separately returned 5/0 metadata checks. The subsequent evidence verification returned 84/0 identity checks, confirming all five source pairs, frozen hand/protocol, six actual mathematical runs, exact one-change damaged copies, full streams and designated failures. Those counts are metadata verification, not additional scientific control families or observations.

## Disposition and access limits

The source remains v1 with no requested correction. The complete hand derivation, frozen protocol, all source snapshots, exact code/results, real damaged programs, failure ledger, primary-page extraction, command index and final report are included in the manifest and receipt. The receipt binds all five source/snapshot pairs and an explicit unchanged-original recovery mapping. The original mathematical author remains /root.

All writes stayed within solar_branch_bound_v1/independent_v1. No canonical or parent source, previous evidence, Git/branch/PR, runtime, lock, settings or audit state was modified. No parent implementation/results file, new empirical data, outside chat, new agent or network source was used. The conclusion is confined to the stated exact inequalities and conditional benchmark transformation. After the independent hand derivation, baseline and all five damaged-program runs had finished, a parent message disclosed aggregate counts for prospective packaging: 174/0 staged, comprising lab 40 and solar 134, and referred to a separate lab 79/0 review. Those later counts were not used in the mathematical derivation, controls or conclusion. The new staging code/results and the parent primary-abstract inspection record were not opened. ACCESS_COMPLETION_v1.json preserves this timing and distinguishes the late message exposure from file access. Writes stop after the evidence is sealed.
