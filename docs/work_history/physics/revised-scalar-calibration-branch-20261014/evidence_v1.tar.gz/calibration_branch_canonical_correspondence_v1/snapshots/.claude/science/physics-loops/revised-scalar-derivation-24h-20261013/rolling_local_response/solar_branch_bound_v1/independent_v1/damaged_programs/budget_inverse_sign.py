"""Independent action-coordinate and exact rational controls. No producer access."""
from fractions import Fraction as R
from pathlib import Path
import argparse
import hashlib
import json
import platform
import sympy as S

COUPLING_DENOM_COEFF = 3
SPATIAL_WEIGHT = 1
LOWER_EDGE_SIGN = -1
CONFORMAL_SIGN = -1
BUDGET_INVERSE_SIGN = 1

def parameters(k):
    return (1-k)*(1+3*k)/4, (1+k)/(k*(1-3*k))

def norm_in_z_squared(k, v):
    a,s=parameters(k)
    return a*(1+s-s*v)/(1+s-COUPLING_DENOM_COEFF*a*s*v)

def gamma_from_potentials(q):
    temporal=1+q
    spatial=1-SPATIAL_WEIGHT*q
    return spatial/temporal-1

def conformal_deficit(k, q):
    return (1-3*k)*(q-k)/((1+k)*(1+CONFORMAL_SIGN*3*q))

def conformal_cap(k, qcap):
    if not (0<k<R(1,3) and k<=qcap<R(1,3)):
        raise ValueError('requires 0<k<1/3 and k<=qcap<1/3')
    return conformal_deficit(k,qcap)

def gamma_cap(epsilon, lower):
    if epsilon<0:
        raise ValueError('absolute error allowance must be nonnegative')
    eta=epsilon+LOWER_EDGE_SIGN*lower
    if eta<0:return {'kind':'impossible','eta':eta,'qcap':None}
    if eta>=2:return {'kind':'unbounded_by_lower_edge','eta':eta,'qcap':None}
    return {'kind':'finite','eta':eta,'qcap':eta/(2+BUDGET_INVERSE_SIGN*eta)}

def original_action_rational(k, E):
    """Contraction computed from dC/dE and K, never from the z formula."""
    a,s=parameters(k)
    f=1+s*E
    j=1+(1-3*a)*s*E
    c=(1+s)*E/f
    dc=(1+s)/f**2
    beta_squared=a*E**2*(dc/c)**2
    metric=j/f**2
    return {'a':a,'s':s,'F':f,'J':j,'C':c,'q':beta_squared/metric}

def in_branch(k,E):
    return 0<k<R(1,3) and 0<E<=1

def interval_compatible(q,epsilon,lower,upper):
    f=gamma_from_potentials(q)
    return f+epsilon>=lower and f-epsilon<=upper

def exact_interval_error(q,lower,upper):
    f=gamma_from_potentials(q)
    return max(R(0),lower-f,f-upper)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    checks=[];points=[];budgets=[];witnesses=[]
    def ck(name,value,**details):
        checks.append({'name':name,'passed':bool(value),**details})
    def eq(name,expression):
        reduced=S.factor(S.cancel(expression))
        ck(name,reduced==0,residual=str(reduced))
    def invalid(name,fn):
        try:fn()
        except ValueError as exc:ck(name,True,expected_exception=str(exc))
        else:ck(name,False,expected_exception='missing domain rejection')

    # Start from C(E) and K_uu of the full action. No potential enters this norm.
    k,e,v,z,q,b,eta=S.symbols('k e v z q b eta',positive=True)
    a,s=parameters(k);f=1+s*e;j=1+(1-3*a)*s*e;c=(1+s)*e/f
    beta_sq=a*e**2*(S.diff(c,e)/c)**2
    metric=j/f**2
    norm=S.cancel(beta_sq/metric)
    eq('symbolic.positive_one_minus_3a_factor',1-3*a-(1-3*k)**2/4)
    eq('symbolic.positive_a_minus_k_factor',a-k-(1-3*k)*(1+k)/4)
    eq('symbolic.k_B_identity',k*(1-3*a)*s-(a-k))
    eq('symbolic.beta_from_C_derivative',beta_sq-a/f**2)
    eq('symbolic.norm_from_metric_contraction',norm-a/j)
    eq('symbolic.floor_factor',norm-k-(a-k)*(1-e)/j)
    eq('symbolic.upper_gap_factor',a-norm-a*(1-3*a)*s*e/j)
    eq('symbolic.E_derivative_sign_factor',S.diff(norm,e)+a*(1-3*a)*s/j**2)
    eq('symbolic.C_derivative_sign_factor',S.diff(c,e)-(1+s)/f**2)
    ev=v/(1+s-s*v)
    eq('symbolic.E_C_inverse',c.subs(e,ev)-v)
    eq('symbolic.action_to_z_norm',norm.subs(e,ev)-norm_in_z_squared(k,v))
    nz=norm_in_z_squared(k,z*z)
    expected_dz=2*a*s*(1+s)*(3*a-1)*z/(1+s-3*a*s*z*z)**2
    eq('symbolic.z_derivative',S.diff(nz,z)-expected_dz)
    eq('symbolic.z_denominator_positive_decomposition',(1+s-3*a*s*v)-(1+s*(1-3*a))-3*a*s*(1-v))
    eq('symbolic.z_one_vacuum_endpoint',nz.subs(z,1)-k)
    eq('symbolic.z_zero_limit',nz.subs(z,0)-a)
    eq('symbolic.one_minus_C_factor',1-c-(1-e)/f)
    eq('symbolic.one_minus_3q_factor',1-3*norm-(1-3*a)*f/j)
    eq('symbolic.exact_conformal_inverse',conformal_deficit(k,norm)-(1-c))
    eq('symbolic.conformal_monotonicity',S.diff(conformal_deficit(k,q),q)-(1-3*k)**2/((1+k)*(1-3*q)**2))
    eq('symbolic.relaxed_bound_positive_gap',b/(1-3*b)-conformal_deficit(k,b)-k*(1-3*k+4*b)/((1+k)*(1-3*b)))
    eq('symbolic.gamma_metric_ratio',gamma_from_potentials(q)+2*q/(1+q))
    eq('symbolic.gamma_monotonicity',S.diff(gamma_from_potentials(q),q)+2/(1+q)**2)
    implemented_cap=eta/(2+BUDGET_INVERSE_SIGN*eta)
    eq('symbolic.inverse_budget_boundary',2*implemented_cap/(1+implemented_cap)-eta)
    eq('symbolic.bare_reference_at_E_one',c.subs(e,1)-1)
    eq('symbolic.dynamical_reference_at_E_one',(c*(1+norm)).subs(e,1)-(1+k))

    # The potential supplies an independent range variable even at fixed q.
    alpha,u,nu=S.symbols('alpha u nu',positive=True)
    eu=S.exp(2*alpha*u);fu=1+s*eu
    potential=S.Rational(3,2)+3*s*(eu-1)**2/(2*fu**2)+nu*(1+s)*u**2/(2*fu**2)
    huu=S.diff(potential,u,2).subs(u,0).subs(alpha**2,a)
    eq('symbolic.actual_potential_vacuum_hessian',huu-(12*a*s+nu*(1+s))/(1+s)**2)
    mass=S.cancel(huu/metric.subs(e,1))
    eq('symbolic.vacuum_mass_from_action',mass-4*(3*(1+k)+nu)/(1-3*k))
    eq('symbolic.mass_nu_dependence',S.diff(mass,nu)-4/(1-3*k))
    eq('symbolic.norm_independent_nu',S.diff(norm,nu))

    ks=[R(2,17),R(7,40),R(5,19),R(1,170000)]
    es=[R(1),R(4,5),R(2,7),R(1,23)]
    for ki in ks:
        previous=None
        for ei in es:
            x=original_action_rational(ki,ei);qi=x['q'];ci=x['C'];label=f'{ki}_{ei}'
            ck('rational.domain_'+label,in_branch(ki,ei))
            ck('rational.original_action_vs_z_'+label,qi==norm_in_z_squared(ki,ci),action_q=str(qi),z_formula=str(norm_in_z_squared(ki,ci)))
            ck('rational.floor_'+label,qi>=ki and (qi==ki)==(ei==1))
            ck('rational.strict_upper_'+label,qi<x['a']<R(1,3))
            ck('rational.conformal_branch_'+label,0<ci<=1)
            ck('rational.inverse_'+label,conformal_deficit(ki,qi)==1-ci)
            ck('rational.denominators_'+label,x['J']>0 and 1+x['s']-3*x['a']*x['s']*ci>0 and 1-3*qi>0)
            ck('rational.relaxed_bound_'+label,0<=1-ci<=conformal_cap(ki,qi)<qi/(1-3*qi))
            if previous is not None:ck('rational.monotonic_E_'+label,qi>previous)
            previous=qi
            points.append({'k':str(ki),'E':str(ei),'C':str(ci),'q_action':str(qi),'a':str(x['a']),
                           'conformal_deficit':str(1-ci),'gamma_minus_one':str(gamma_from_potentials(qi))})
        ai,si=parameters(ki);target=(ki+ai)/2;ei=ki*(ai-target)/(target*(ai-ki));x=original_action_rational(ki,ei)
        ck('rational.sharp_conformal_cap_'+str(ki),0<ei<1 and x['q']==target and 1-x['C']==conformal_cap(ki,target))
        ck('rational.equal_cap_is_reference_'+str(ki),conformal_cap(ki,ki)==0)
        invalid('domain.cap_below_floor_'+str(ki),lambda ki=ki:conformal_cap(ki,ki/2))
    invalid('domain.cap_one_third',lambda:conformal_cap(R(2,17),R(1,3)))
    invalid('domain.cap_above_one_third',lambda:conformal_cap(R(2,17),R(2,5)))
    ck('domain.zero_E_excluded',not in_branch(R(2,17),R(0)))
    ck('domain.parameter_endpoints_excluded',not in_branch(R(0),R(1)) and not in_branch(R(1,3),R(1)))
    pos=original_action_rational(R(2,17),R(5,2))
    ck('scope.positive_u_counterexample',pos['q']<R(2,17) and pos['C']>1)
    witnesses.append({'kind':'positive_u_does_not_obey_negative_floor','k':'2/17','E':'5/2','q':str(pos['q']),'C':str(pos['C'])})
    vacuum=original_action_rational(R(2,17),R(1))
    ck('scope.bare_vs_dynamical_reference',vacuum['C']==1 and vacuum['C']*(1+vacuum['q'])==R(19,17))
    witnesses.append({'kind':'bare_vs_dynamical_reference','Gbare_over_Gvac':'1','Gdyn_over_Gvac':'19/17','q':'2/17'})
    msmall=4*(3*(1+R(2,17))+R(1,7))/(1-3*R(2,17));mlarge=4*(3*(1+R(2,17))+R(11,2))/(1-3*R(2,17))
    ck('scope.same_q_different_vacuum_masses',mlarge>msmall)
    witnesses.append({'kind':'same_norm_different_range','k':'2/17','q':'2/17','nu':['1/7','11/2'],'m_squared_over_Hv_squared':[str(msmall),str(mlarge)]})

    central=R(21,1000000);reported_error=R(23,1000000)
    lower=central-2*reported_error;upper=central+2*reported_error
    ck('benchmark.interval_arithmetic',lower==-R(1,40000) and upper==R(67,1000000))
    cases=[('zero',R(0),R(1,79999),R(1,79996)),
           ('ten_micro',R(1,100000),R(7,399993),R(7,399972)),
           ('hundred_micro',R(1,10000),R(1,15999),R(1,15996)),
           ('independent_extra',R(9,2000000),R(59,3999941),R(59,3999764))]
    for name,epsilon,want,relaxed in cases:
        got=gamma_cap(epsilon,lower);cap=got['qcap'];ok=got['kind']=='finite' and cap==want
        ck('benchmark.zero_error_cap' if name=='zero' else 'benchmark.cap_'+name,ok,actual=str(cap),expected=str(want))
        ck('benchmark.conformal_relaxation_'+name,cap is not None and cap<R(1,3) and cap/(1-3*cap)==relaxed)
        ck('benchmark.boundary_contact_'+name,cap is not None and gamma_from_potentials(cap)+epsilon==lower)
        ck('benchmark.true_boundary_not_excluded_'+name,cap is not None and want<=cap and interval_compatible(want,epsilon,lower,upper))
        ck('benchmark.above_cap_cannot_reach_'+name,gamma_from_potentials(want+R(1,1000000))+epsilon<lower)
        ck('benchmark.interior_envelope_intersects_'+name,interval_compatible(want/2,epsilon,lower,upper))
        budgets.append({'name':name,'epsilon':str(epsilon),'lower':str(lower),'upper':str(upper),'eta':str(got['eta']),
                        'qcap':str(cap),'expected_qcap':str(want),'relaxed_conformal_cap':str(relaxed)})
    ck('benchmark.quoted_q_decimal_is_approximation',abs(R(12500156,10**12)-R(1,79999))<R(1,2*10**12))
    ck('benchmark.quoted_C_decimal_is_approximation',abs(R(12500625,10**12)-R(1,79996))<R(1,2*10**12))
    invalid('domain.negative_absolute_error',lambda:gamma_cap(-R(1,1000),lower))
    neg=gamma_cap(R(1,20),R(1,10));zero=gamma_cap(R(1,20),R(1,20));two=gamma_cap(R(0),-R(2))
    ck('budget.eta_negative',neg['kind']=='impossible')
    ck('budget.eta_zero',zero['kind']=='finite' and zero['qcap']==0)
    ck('budget.eta_two',two['kind']=='unbounded_by_lower_edge')
    ck('budget.eta_two_lower_edge_all_finite',all(gamma_from_potentials(qi)>=-2 for qi in [R(0),R(1),R(7),R(10**9)]))
    for qi in [R(1,190000),R(1,21),R(7,40)]:
        need=max(R(0),lower+2*qi/(1+qi));actual_need=exact_interval_error(qi,lower,upper)
        ck('budget.minimum_error_'+str(qi),need==actual_need and interval_compatible(qi,need,lower,upper))
        if need>0:ck('budget.just_below_minimum_fails_'+str(qi),not interval_compatible(qi,need/2,lower,upper))
        witnesses.append({'kind':'minimum_benchmark_error','q':str(qi),'epsilon_required':str(need)})
    qi=R(2,17);lo=-R(4,5);hi=-R(3,5);model=gamma_from_potentials(qi)
    lower_condition=model>=lo;full=interval_compatible(qi,R(0),lo,hi)
    ck('scope.lower_edge_not_general_sufficiency',lower_condition and not full)
    ck('scope.full_interval_error_distance',exact_interval_error(qi,lo,hi)==R(37,95))
    witnesses.append({'kind':'general_interval_needs_upper_edge','q':str(qi),'gamma_minus_one':str(model),'interval':[str(lo),str(hi)],
                      'lower_condition':lower_condition,'full_intersection':full,'minimum_error':str(exact_interval_error(qi,lo,hi))})
    for eta_i in [R(1,4),R(1),R(7,4)]:
        got=gamma_cap(R(0),-eta_i)
        ck('budget.non_candidate_general_eta_'+str(eta_i),got['kind']=='finite' and got['qcap']==eta_i/(2-eta_i))
    ck('budget.conformal_domain_requires_eta_below_half',R(1,2)/(2-R(1,2))==R(1,3))

    result={'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,
            'independent_exact_points':points,'benchmark_transformations':budgets,'counterexample_and_scope_witnesses':witnesses,
            'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'environment':{'python':platform.python_version(),'sympy':S.__version__},
            'scope':'Exact branch and interval controls. Exposed published estimate only; no fitted confidence interval, range, Solar matching, screening or empirical exclusion.'}
    b=(json.dumps(result,indent=2,default=str)+'\n').encode();(out/'RESULTS.json').write_bytes(b)
    print(b.decode(),end='')
    raise SystemExit(int(result['failed']!=0))

if __name__=='__main__':main()
