"""Inspect only the saved supplied publisher HTML. No network or likelihood."""
from pathlib import Path
from html.parser import HTMLParser
import datetime,hashlib,json,re
o=Path(__file__).resolve().parent
class Reader(HTMLParser):
    def __init__(self):super().__init__();self.skip=0;self.parts=[];self.metadata={};self.canonical=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag in ['script','style']:self.skip+=1
        if tag=='meta' and ('name' in a or 'property' in a):self.metadata.setdefault(a.get('name',a.get('property')),[]).append(a.get('content'))
        if tag=='link' and a.get('rel')=='canonical':self.canonical.append(a.get('href'))
    def handle_endtag(self,tag):
        if tag in ['script','style']:self.skip-=1
    def handle_data(self,data):
        if not self.skip and data.strip():self.parts.append(data.strip())
p=o/'sources/BERTOTTI_2003_PAGE_20261014.html';raw=p.read_bytes();reader=Reader();reader.feed(raw.decode())
text='\n'.join(reader.parts)+'\n';flat=' '.join(text.split())
pattern=r'γ\s*=\s*1\s*\+\s*\(2\.1\s*±\s*2\.3\)\s*×\s*10\s*-5'
match=re.search(pattern,flat)
checks=[{'name':'abstract_result_present','passed':match is not None},
        {'name':'doi_in_visible_page','passed':'10.1038/nature01997' in flat},
        {'name':'title_present','passed':'A test of general relativity using radio links with the Cassini spacecraft' in flat},
        {'name':'subscription_preview_explicit','passed':'This is a preview of subscription content' in flat},
        {'name':'publisher_canonical_url','passed':'https://www.nature.com/articles/nature01997' in reader.canonical}]
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(raw).hexdigest(),
        'source_bytes':len(raw),'canonical_urls':reader.canonical,'relevant_metadata':{k:v for k,v in reader.metadata.items() if k in ['citation_doi','citation_title','citation_publication_date','citation_author','citation_journal_title']},
        'observed_abstract_result':match.group(0) if match else None,
        'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,
        'scope':'Local inspection of supplied primary HTML; exposed reported estimate only. No full article, likelihood, new confidence fit or fresh network retrieval is claimed.'}
for name,body in [('PRIMARY_VISIBLE_TEXT_v1.txt',text),('PRIMARY_INSPECTION_v1.json',json.dumps(result,indent=2)+'\n')]:
    q=o/name;assert not q.exists();q.write_text(body)
print(json.dumps(result,indent=2));raise SystemExit(int(result['failed']!=0))
