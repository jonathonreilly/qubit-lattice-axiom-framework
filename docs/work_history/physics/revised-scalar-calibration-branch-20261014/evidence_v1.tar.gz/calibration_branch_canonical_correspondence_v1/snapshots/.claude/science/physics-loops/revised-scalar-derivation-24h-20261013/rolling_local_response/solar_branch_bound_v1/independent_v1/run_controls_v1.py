"""Execute the owned independent checker and actual altered copies; retain all streams."""
from pathlib import Path
import datetime,difflib,hashlib,json,subprocess,sys
o=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,x):
 path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists(),path
 path.write_bytes(x) if isinstance(x,bytes) else path.write_text(json.dumps(x,indent=2)+'\n')
proto=json.loads((o/'CONTROL_PROTOCOL_v1.json').read_text());source=o/'check_branch_v1.py';body=source.read_text()
put(o/'IMPLEMENTATION_FREEZE_v1.json',{'created_utc':now(),'source':source.name,'sha256':sha(source.read_bytes()),
    'hand_sha256':sha((o/'HAND_DERIVATION_v1.md').read_bytes()),'protocol_sha256':sha((o/'CONTROL_PROTOCOL_v1.json').read_bytes()),
    'source_bindings_sha256':sha((o/'SOURCE_BINDINGS_v1.json').read_bytes()),'producer_code_or_results_read':False})
executions=[]
def run(label,script,expected_exit,witness=None):
 output=o/'runs'/label
 argv=[sys.executable,'-B',str(script),'--output',str(output)]
 record={'label':label,'argv':argv,'cwd':str(Path.cwd().resolve()),'started_utc':now(),
         'script_sha256':sha(script.read_bytes()),'expected_exit':expected_exit,'required_witness':witness}
 put(o/'commands'/(label+'_COMMAND.json'),record)
 try:
  r=subprocess.run(argv,capture_output=True,check=False,timeout=45)
  stdout,stderr,code=r.stdout,r.stderr,r.returncode;timed_out=False
 except subprocess.TimeoutExpired as exc:
  stdout,stderr,code=exc.stdout or b'',exc.stderr or b'',None;timed_out=True
 record.update(ended_utc=now(),exit_code=code,timed_out=timed_out,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),
               stdout_bytes=len(stdout),stderr_bytes=len(stderr))
 put(o/'commands'/(label+'_STDOUT.txt'),stdout);put(o/'commands'/(label+'_STDERR.txt'),stderr)
 if (output/'RESULTS.json').exists():
  result=json.loads((output/'RESULTS.json').read_text())
  record.update(result_sha256=sha((output/'RESULTS.json').read_bytes()),passed=result['passed'],failed=result['failed'],
                result_checker_hash_matches=result['checker_sha256']==record['script_sha256'],
                stdout_equals_result=stdout==(output/'RESULTS.json').read_bytes(),
                failed_names=[x['name'] for x in result['checks'] if not x['passed']])
 else:record.update(passed=None,failed=None,failed_names=[],result_missing=True)
 record['expected_outcome']=(code==expected_exit and not timed_out and record.get('result_checker_hash_matches',False)
    and record.get('stdout_equals_result',False) and (not witness or witness in record['failed_names']))
 put(o/'commands'/(label+'_EXECUTION.json'),record);executions.append(record)
 print(json.dumps({k:record.get(k) for k in ['label','exit_code','timed_out','passed','failed','expected_outcome','failed_names']}),flush=True)
 return record
base=run('baseline_v1',source,0)
if not base['expected_outcome'] or base['failed']!=0:
 put(o/'CONTROL_EXECUTION_SUMMARY_v1.json',{'executions':executions,'baseline_failed':True,'damages_started':False})
 raise SystemExit(1)
for item in proto['damages']:
 assert body.count(item['old'])==1,(item['name'],'replacement is not unique')
 altered=body.replace(item['old'],item['new'],1)
 script=o/'damaged_programs'/(item['name']+'.py')
 put(script,altered.encode())
 put(o/'damaged_programs'/(item['name']+'.diff'),''.join(difflib.unified_diff(body.splitlines(True),altered.splitlines(True),fromfile='check_branch_v1.py',tofile=script.name)).encode())
 run(item['name'],script,1,item['witness'])
summary={'created_utc':now(),'executions':executions,'baseline':{'passed':base['passed'],'failed':base['failed']},
         'actual_damaged_programs':len(executions)-1,'all_required_damages_detected':all(x['expected_outcome'] for x in executions),
         'producer_code_or_results_accessed':False,'science_scope':'Focused exact branch/interval control only; no trajectory or empirical fit.'}
put(o/'CONTROL_EXECUTION_SUMMARY_v1.json',summary)
raise SystemExit(int(not summary['all_required_damages_detected']))
