#!/usr/bin/env python3
"""Metadata-only seal of completed independent solar-branch evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

O = Path(__file__).resolve().parent
W = Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(name):
    return json.loads((O / name).read_text())

def write(name, obj):
    p = O / name
    assert not p.exists(), str(p)
    p.write_text(json.dumps(obj, indent=2) + '\n')

def ref(name):
    p = O / name
    return {'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)}

assert not (O / 'RECEIPT_v1.json').exists()
assert not (O / 'MANIFEST_v1.json').exists()
write('SEAL_COMMAND_v1.json', {
    'created_utc': now(),
    'argv': [sys.executable, '-B', str(Path(__file__).resolve())],
    'cwd': str(Path.cwd()),
    'script_sha256': sha(Path(__file__)),
    'purpose': 'Metadata checks and immutable final manifest/receipt; no scientific rerun.'
})
checks = []
def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        write('SEAL_FAILURE_v1.json', {'created_utc': now(), 'checks': checks})
        raise AssertionError(name)

pairs = read('SOURCE_BINDINGS_v1.json')['source_pairs']
check('five_source_pairs', len(pairs) == 5)
for pair in pairs:
    live = Path(pair['original_path'])
    snap = O / pair['snapshot_path']
    check('live_and_snapshot_' + pair['snapshot_path'],
          live.read_bytes() == snap.read_bytes() and sha(live) == pair['sha256']
          and live.stat().st_size == pair['bytes'])
hand = read('HAND_FREEZE_v1.json')
impl = read('IMPLEMENTATION_FREEZE_v1.json')
for name, expected in [
    ('HAND_DERIVATION_v1.md', hand['hand']['sha256']),
    ('CONTROL_PROTOCOL_v1.json', hand['protocol']['sha256']),
    ('SOURCE_BINDINGS_v1.json', hand['source_bindings_sha256']),
    ('check_branch_v1.py', impl['sha256'])
]:
    check('frozen_' + name, sha(O / name) == expected)
check('hand_before_implementation', hand['created_utc'] < impl['created_utc'])
summary = read('CONTROL_EXECUTION_SUMMARY_v1.json')
check('baseline_231_0', summary['baseline'] == {'passed': 231, 'failed': 0})
check('five_actual_damages', summary['actual_damaged_programs'] == 5
      and summary['all_required_damages_detected'])
check('all_six_executions', len(summary['executions']) == 6)
for row in summary['executions']:
    result = O / 'runs' / row['label'] / 'RESULTS.json'
    code = Path(row['argv'][2])
    check('executed_source_result_' + row['label'], sha(code) == row['script_sha256']
          and sha(result) == row['result_sha256']
          and row['passed'] + row['failed'] == 231
          and row['exit_code'] == row['expected_exit']
          and row['expected_outcome'])
verification = read('EVIDENCE_VERIFICATION_v1.json')
check('prior_evidence_identity_84_0', verification['passed'] == 84 and verification['failed'] == 0
      and all(x['passed'] for x in verification['checks']))
primary = read('PRIMARY_INSPECTION_v1.json')
check('primary_metadata_5_0', primary['passed'] == 5 and primary['failed'] == 0)
recovery = read('SOURCE_RECOVERY_v1.json')['original_dispositions']
check('five_recovery_dispositions', len(recovery) == 5)
for row in recovery:
    check('recovery_' + row['original_path'],
          sha(W / row['original_path']) == row['original_sha256']
          == sha(W / row['recovery']) == row['final_sha256']
          == sha(W / row['final_path']))
report = (O / 'REPORT_v1.md').read_text()
check('report_actual_source_hash', impl['sha256'] in report)
check('report_late_exposure_disclosed', 'ACCESS_COMPLETION_v1.json' in report and '174/0' in report)
check('report_no_placeholder', 'PLACEHOLDER' not in report)
access = read('ACCESS_COMPLETION_v1.json')
check('late_counts_not_scientific_reliance',
      not access['later_parent_message_exposure']['scientific_reliance']
      and not access['producer_implementation_or_results_files_accessed'])
failures = read('FAILURES_v1.json')
check('complete_failed_control_ledger', len(failures['actual_changed_program_failures']) == 5
      and not failures['unexpected_baseline_failures']
      and not failures['source_errors_found'])
write('FINAL_VERIFICATION_v1.json', {
    'created_utc': now(), 'passed': sum(c['passed'] for c in checks),
    'failed': sum(not c['passed'] for c in checks), 'checks': checks,
    'scope': 'Metadata identity/recovery verification only; no new mathematical executions.'
})

# Include every owned regular artifact except the two root-level seal files.
files = []
for p in sorted(O.rglob('*')):
    if p.is_file() and p not in {O / 'MANIFEST_v1.json', O / 'RECEIPT_v1.json'}:
        assert not p.is_symlink(), str(p)
        files.append(ref(p.relative_to(O).as_posix()))
write('MANIFEST_v1.json', {
    'created_utc': now(), 'scope_root': str(O),
    'artifact_count': len(files), 'artifacts': files,
    'exclusions': ['MANIFEST_v1.json', 'RECEIPT_v1.json'],
    'exclusion_reason': 'Root manifest does not self-hash; root receipt binds the manifest and report.'
})
write('RECEIPT_v1.json', {
    'schema': 'focused_independent_mathematical_receipt_v1',
    'created_utc': now(), 'reviewer': '/root/scalar_energy_check',
    'scientific_author': '/root', 'write_root': str(O),
    'scope': 'Action normalization, finite negative-u coupling floor, conformal inverse, conditional light-time interval/error transformation and exact domain/scope controls.',
    'conclusion': 'The source v1 equations and declared conditional consequences agree with the independent derivation. No source correction required. No physical Solar model, range/screening result, new confidence fit or empirical acceptance/exclusion is established.',
    'formal_audit_or_landing_verdict': False,
    'report': ref('REPORT_v1.md'), 'manifest': ref('MANIFEST_v1.json'),
    'artifact_count': len(files), 'source_pair_count': len(pairs),
    'source_pairs': pairs, 'source_bindings': ref('SOURCE_BINDINGS_v1.json'),
    'original_dispositions': recovery,
    'recovery_record': ref('SOURCE_RECOVERY_v1.json'),
    'independent_hand_derivation': ref('HAND_DERIVATION_v1.md'),
    'hand_freeze': ref('HAND_FREEZE_v1.json'),
    'control_protocol': ref('CONTROL_PROTOCOL_v1.json'),
    'implementation_freeze': ref('IMPLEMENTATION_FREEZE_v1.json'),
    'checker': ref('check_branch_v1.py'),
    'baseline': {'passed': 231, 'failed': 0, 'exit_code': 0,
                 'result': ref('runs/baseline_v1/RESULTS.json'),
                 'execution': ref('commands/baseline_v1_EXECUTION.json')},
    'actual_damaged_program_count': 5,
    'all_actual_damages_detected': True,
    'actual_damaged_programs': [{
        'label': r['label'], 'passed': r['passed'], 'failed': r['failed'],
        'exit_code': r['exit_code'], 'required_witness': r['required_witness'],
        'source': ref('damaged_programs/' + r['label'] + '.py'),
        'diff': ref('damaged_programs/' + r['label'] + '.diff'),
        'result': ref('runs/' + r['label'] + '/RESULTS.json'),
        'execution': ref('commands/' + r['label'] + '_EXECUTION.json')
    } for r in summary['executions'][1:]],
    'all_execution_summary': ref('CONTROL_EXECUTION_SUMMARY_v1.json'),
    'failure_ledger': ref('FAILURES_v1.json'),
    'command_index': ref('COMMAND_INDEX_v1.json'),
    'primary_metadata_inspection': {'passed': 5, 'failed': 0,
                                    'result': ref('PRIMARY_INSPECTION_v1.json')},
    'evidence_identity_verification': {'passed': 84, 'failed': 0,
                                     'result': ref('EVIDENCE_VERIFICATION_v1.json')},
    'final_metadata_verification': ref('FINAL_VERIFICATION_v1.json'),
    'access_history': ref('ACCESS_HISTORY_v1.json'),
    'access_completion': ref('ACCESS_COMPLETION_v1.json'),
    'late_aggregate_counts_exposed_after_independent_controls': True,
    'producer_implementation_results_files_read_or_imported': False,
    'new_empirical_data_or_network': False,
    'outside_write_or_git_pr_runtime_lock_audit_mutation': False,
    'source_correction_required': False,
    'writes_end_at_this_receipt': True
})
print(json.dumps({
    'artifact_count': len(files), 'source_pairs': len(pairs),
    'final_metadata_checks': len(checks),
    'report': ref('REPORT_v1.md'), 'manifest': ref('MANIFEST_v1.json'),
    'receipt': ref('RECEIPT_v1.json'), 'recovery': ref('SOURCE_RECOVERY_v1.json')
}, indent=2))
