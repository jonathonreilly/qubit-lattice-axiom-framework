"""Verify this unit's actual completed executions and retain all failed checks."""
from pathlib import Path
import datetime,difflib,hashlib,json
o=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def ck(n,x):checks.append({'name':n,'passed':bool(x)})
def ref(p):
 p=Path(p);return {'path':p.relative_to(o).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def put(n,v):
 p=o/n;assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n')
bindings=json.loads((o/'SOURCE_BINDINGS_v1.json').read_text())
for pair in bindings['source_pairs']:
 b=(o/pair['snapshot_path']).read_bytes()
 ck('source_pair_'+pair['snapshot_path'],len(b)==pair['bytes'] and sha(b)==pair['sha256'] and Path(pair['original_path']).read_bytes()==b)
hand=json.loads((o/'HAND_FREEZE_v1.json').read_text());impl=json.loads((o/'IMPLEMENTATION_FREEZE_v1.json').read_text())
ck('hand_hash_unchanged',hand['hand']['sha256']==sha((o/'HAND_DERIVATION_v1.md').read_bytes())==impl['hand_sha256'])
ck('protocol_hash_unchanged',hand['protocol']['sha256']==sha((o/'CONTROL_PROTOCOL_v1.json').read_bytes())==impl['protocol_sha256'])
ck('independent_code_hash_unchanged',impl['sha256']==sha((o/'check_branch_v1.py').read_bytes()))
ck('hand_freeze_before_implementation',hand['created_utc']<impl['created_utc'])
summary=json.loads((o/'CONTROL_EXECUTION_SUMMARY_v1.json').read_text());proto=json.loads((o/'CONTROL_PROTOCOL_v1.json').read_text())
base=(o/'check_branch_v1.py').read_text();damages={x['name']:x for x in proto['damages']};failure_rows=[];command_rows=[]
expected=[('baseline_v1',231,0),('coupling_denominator',212,19),('gamma_spatial_weight',216,15),
          ('lower_edge_sign',209,22),('conformal_sign',200,31),('budget_inverse_sign',211,20)]
ck('all_six_actual_executions',len(summary['executions'])==6)
for execution,(label,passes,fails) in zip(summary['executions'],expected):
 ck('ordered_execution_'+label,execution['label']==label)
 path=o/'runs'/label/'RESULTS.json';r=json.loads(path.read_text());script=Path(execution['argv'][2])
 cmd=json.loads((o/'commands'/(label+'_COMMAND.json')).read_text())
 ex=json.loads((o/'commands'/(label+'_EXECUTION.json')).read_text())
 stdout=(o/'commands'/(label+'_STDOUT.txt')).read_bytes();stderr=(o/'commands'/(label+'_STDERR.txt')).read_bytes()
 ck('source_execution_result_identity_'+label,sha(script.read_bytes())==execution['script_sha256']==r['checker_sha256']==cmd['script_sha256'])
 ck('full_execution_record_'+label,ex==execution)
 ck('stdout_result_complete_'+label,stdout==path.read_bytes() and sha(stdout)==execution['stdout_sha256'] and sha(path.read_bytes())==execution['result_sha256'])
 ck('stderr_empty_'+label,stderr==b'' and sha(stderr)==execution['stderr_sha256'])
 ck('actual_counts_'+label,r['passed']==passes and r['failed']==fails and len(r['checks'])==231
    and sum(x['passed'] for x in r['checks'])==passes and sum(not x['passed'] for x in r['checks'])==fails)
 ck('actual_exit_'+label,execution['exit_code']==(0 if label=='baseline_v1' else 1) and not execution['timed_out'])
 ck('times_and_declared_command_'+label,cmd['argv']==execution['argv'] and cmd['cwd']==execution['cwd'] and cmd['started_utc']==execution['started_utc']<execution['ended_utc'])
 ck('expected_outcome_'+label,execution['expected_outcome'] is True)
 if label!='baseline_v1':
  d=damages[label];altered=script.read_text()
  ck('unique_single_actual_change_'+label,base.count(d['old'])==1 and base.replace(d['old'],d['new'],1)==altered)
  diff=''.join(difflib.unified_diff(base.splitlines(True),altered.splitlines(True),fromfile='check_branch_v1.py',tofile=script.name))
  ck('actual_diff_'+label,diff==(o/'damaged_programs'/(label+'.diff')).read_text())
  failed=[x for x in r['checks'] if not x['passed']]
  ck('designated_mathematical_witness_'+label,any(x['name']==d['witness'] for x in failed))
  failure_rows.append({'name':label,'kind':'intentional_actual_changed_program','change':d,'passed':passes,'failed':fails,
                       'exit_code':execution['exit_code'],'source':ref(script),'result':ref(path),'execution':ref(o/'commands'/(label+'_EXECUTION.json')),
                       'all_failed_checks':failed})
 command_rows.append({'label':label,'command':ref(o/'commands'/(label+'_COMMAND.json')),'execution':ref(o/'commands'/(label+'_EXECUTION.json')),
                      'stdout':ref(o/'commands'/(label+'_STDOUT.txt')),'stderr':ref(o/'commands'/(label+'_STDERR.txt')),'result':ref(path)})
primary=json.loads((o/'PRIMARY_INSPECTION_v1.json').read_text());pex=json.loads((o/'PRIMARY_EXECUTION_v1.json').read_text())
ck('primary_five_checks',primary['passed']==5 and primary['failed']==0 and pex['exit_code']==0)
ck('primary_source_identity',primary['source_sha256']==sha((o/'sources/BERTOTTI_2003_PAGE_20261014.html').read_bytes()))
ck('primary_stdout_result_equal',(o/'PRIMARY_STDOUT_v1.txt').read_bytes()==(o/'PRIMARY_INSPECTION_v1.json').read_bytes())
ck('primary_script_identity',pex['script_sha256']==sha((o/'inspect_primary_v1.py').read_bytes()))
ck('primary_stderr_empty',(o/'PRIMARY_STDERR_v1.txt').read_bytes()==b'')
put('FAILURES_v1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'unexpected_baseline_failures':[],'source_errors_found':[],'source_correction_required':False,
     'actual_changed_program_failures':failure_rows,'scope_findings':'All-domain restrictions and conditional physical interpretation preserved in report; intended failed checks are retained in full, not hidden by aggregate success.',
     'producer_code_or_results_read':False})
put('COMMAND_INDEX_v1.json',{'driver_invocation':{'argv':['python3','-B',str(o/'run_controls_v1.py')],
     'cwd':str(Path.cwd().resolve()),'tool_session_id':58063,'tool_completed_exit_code':0,
     'record_kind':'Actual outer tool invocation; each child has independently captured command/streams/exit below.'},
     'driver_source':ref(o/'run_controls_v1.py'),'executions':command_rows,'primary_execution':ref(o/'PRIMARY_EXECUTION_v1.json')})
put('EVIDENCE_VERIFICATION_v1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,
     'scope':'Read/check existing evidence and source hashes; no science rerun.'})
print(json.dumps({'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'actual_damages':len(failure_rows),'source_pairs':len(bindings['source_pairs'])}))
raise SystemExit(int(any(not x['passed'] for x in checks)))
