from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'calibration_branch_packaging';dest=wt/'docs/work_history/physics/revised-scalar-calibration-branch-20261014'
roots=['rolling_local_response/laboratory_yukawa_bridge_v1','rolling_local_response/solar_branch_bound_v1','calibration_branch_canonical_correspondence_v1','calibration_branch_packaging']
seal_units=['rolling_local_response/laboratory_yukawa_bridge_v1/independent_v1','rolling_local_response/solar_branch_bound_v1/independent_v1','calibration_branch_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional apparatus calibration and negative-field scalar branch bounds, with full source histories and independent checks. No observed fit, chosen environment or scale.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for laboratory calibration and negative scalar branch bounds

Live claim: docs/EXPONENTIAL_SCALAR_CALIBRATION_BRANCH_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

The laboratory calculation retains the scalar response of the calibration source.
Its normalized torque ratio is (1+q*yScience)/(1+q*yCalibration), and its leading
long-range correction depends on both signed geometric moments. A shared massless
response disappears from that normalized ratio, which is a calibration degeneracy,
not equivalence of the complete theory to general relativity. The point-mass rings
are synthetic fixtures, not the observed wedge apparatus.

The candidate negative branch has k<=q<a and an exact relation between q and A.
A conditional long-range unscreened PPN bridge with an independently controlled
error budget translates a supplied gamma interval into necessary branch bounds.
The transparent Cassini central-value plus/minus two-reported-errors benchmark is
not a new confidence fit. The positive interval upper edge and general two-sided
condition are stated; unknown bridge error gives no useful limit. The theoretical
Gvac is not a measured cosmological Newton constant.

Fresh canonical174/0=40 laboratory+134 branch, complete staged JSON equality.
Independent79/0 and231/0 reuse distinct methods and actual damaged programs.
Staged552/0 correspondence and65/0 wrapper controls are metadata, not physics
experiments. Three actual complete staged damages fail11,5,52 controls. Two
wrapper-only damaged programs each fail3 controls.

The original39/1 laboratory precision failure and exact50-to75-digit repair remain.
No formula, fixture or acceptance threshold changed. Source-access TLS/parser
failures and normal-TLS/standard-library alternatives are preserved. The Lee2020
primary PDF and public Nature2003 abstract/preview are bound; no full Nature article,
raw torque/spacecraft data, covariance or nuisance likelihood was acquired. Their
published results are exposed development references, not independent test data.
All source histories, full results and independent seals are retained. The late
parent figure-QA record explicitly refers to an earlier view, not a new inspection.

No unique action, scale, realized state, ambient range, nonlinear body charge,
solar matching or joint-instrument likelihood is derived. The source-control and
actual experimental bridge remain empirical/theoretical obligations.
Extract safe regular relative members and verify each manifest size/hash.
Archive-build/commit, delivery and UNIT records follow this archive.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
