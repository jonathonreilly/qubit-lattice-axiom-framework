# Revised scalar theory: derivation campaign

**Draft prepared before the fixed deadline. This is not a completion record.**

Campaign window: October13,2026 at14:13:22 America/New_York to October14,2026
at14:13:22 America/New_York (18:13:22UTC). Discovery stops17:58:22UTC.
Scientific author: the parent chat, /root; independent agents performed focused
checks. No detached replacement author, formal audit, science merge or main push.

## What the campaign established

The campaign derived several useful consequences and removed specific extra
assumptions **within the supplied revised scalar action**. It did not derive a
unique action, potential, realized initial state, absolute hierarchy or complete
measured environment. It did not complete a TOE or independently validate the
candidate against observations.

The most useful advances are a conditional finite-body force/stability theorem,
a complete-body scalar-charge derivation, finite-history inverse methods that
do not require prescribed wave amplitudes, and clearer distinctions between
bare gravity, measured force and observational parameter estimates. Some
attractor, bounded-history and calibration shortcuts were disproved in their
stated domains. Keeping those failed routes was essential to the result.

There is a documented interruption. The last early checkpoint was20:38:49UTC
on October13; the parent calculation finished20:42:12 and a focused check
finished21:00:56. Recorded parent tool work resumed02:52:49UTC October14.
The cause is not established. The campaign retained its original deadline;
this report must not describe the full window as continuous authorship.

## The four requested assumption targets

| Target | Derived or eliminated conditionally | Still supplied or unresolved |
| --- | --- | --- |
| Initial state and bounded history | Sufficient future trapping; scoped finite-past bounds; actual radiation saddles and alternative limiting states; finite-window inverses eliminate selected initial amplitudes from certain parameter estimates | No realized cosmological state selected. A normalized past germ can still have divergent physical curvature. Spatial curvature, radiation production, incoming waves and initial covariance remain physical inputs |
| Action and potential | A known history fixes a potential value/gradient jet but leaves transverse curvature freedom. Ideal stationary density/force functions reconstruct a scalar-tensor action along one branch up to a real vacuum-energy ambiguity | No actual observed functions acquired; no principle selects the complete action, coupling law or potential. Reconstruction inside a chosen class is not a unique TOE |
| Scales | Several response identities and a physical-duration inequality eliminate separately inserted normalization parameters. Limited classical scaling shows what source-free dynamics cannot determine | k,nu,Hv,Q0 and the vacuum/Planck hierarchy remain unselected. Calibrating a scale from a measurement would not derive it from first principles |
| Measured-gravity/environment bridge | Source coupling, finite-profile response, static field/force bounds, sufficient uniqueness, complete-body charge and force-calibration derivatives derived from the same supplied action | A real Solar/laboratory environment, material support, ambient response, source sensitivities, boundary data, full spacetime and instrument/orbital likelihood remain to be demonstrated |

New candidate constructions were allowed, but none was counted as a retired
assumption merely because it was mathematically possible. Explicit synthetic
states, conserved stress fixtures and chosen time histories remain constructions.

## Strongest checked mathematics

Throughout, the kinetic convention is -Q K_AB partial(phi^A)partial(phi^B),
not -QK/2. The canonical coupled coordinate obeys dchi=sqrt(K_uu)du,
A is the conformal factor, beta=dlnA/dchi, q=beta^2, and0<k<1/3.
The action and universal matter coupling are premises.

**Finite held-body theorem.** For a prescribed nonnegative static particle
source on a fixed flat background, negative scalar branch and zero far boundary,
let -Delta V=c, P=||V||infinity and L=1+k. If LP<1,

    ||-chi|| <= sqrt(k) P/(1-LP),
    -ln A <= k P(1-LP/2)/(1-LP)^2.

A radial uniform sphere then has a derived surface-force bracket; sufficiently
small reachable field intervals give uniqueness and no growing finite-energy
scalar mode with matter and metric held fixed. A canonical Hessian refinement
approaches the exact vacuum mass at fixed parameters. A failed sufficient
criterion is not proof of instability. These results replace an assigned
interior minimum or shell factor in this class; they do not prove that an
observed body realizes the class. Eighteen nonlinear sphere profiles were
checked, with original numerical failures and corrections retained.

**Complete-body charge.** Complete isolated stationary stress conservation,
including all supports and binding contributions, gives

    integral T_ij d^3x=0,
    integral(rho-sum_i T_ii)d^3x=E.

Thus leading massless weak scalar charge equals total inertial energy without
requiring pointwise negligible pressure. For a spherical finite-range source,

    Q_mu=integral[f rho+r f' T_rr]d^3x,
    f=sinh(mu r)/(mu r).

The weighted stress moment survives. Under additionally supplied rho>=0 and
|T_rr|<=rho, its charge satisfies

    2 sinh(x)/x-cosh(x) <= Q_mu/E <= cosh(x), x=mu R.

Equal-energy conserved fixtures have different finite-range charge. Ambient
subtraction alone does not remove ambient linear response; this limitation
was found, repaired and preserved before publication.

**Finite observation windows.** For a complete conserved matter tensor confined
to radiusR during the required finite band, with explicit energy/component
bounds, I=integral r^2rho obeys I''=2integral sum_iT_ii. The signed instantaneous
trace average differs from E by at most2R/(cT). Including retardation gives the
conservative bound18R/(cT) for the leading amplitude from the specified local
worldtube. It does not bound radiation power, force, absolute fluctuations or
arbitrary incoming waves. Earlier/outside global source histories are not
selected by finite-band source data. The exact conserved fixture has different
instantaneous and retarded coefficients3 and2; replacing retarded times by a
common time fails the direct integration controls.

**Force calibration and its turning point.** In the ideal weak, common-background,
long-range readout, with a=(1-k)(1+3k)/4 and Gref=1/(8piQ0),

    Gforce/Gref=1-4(q-k)^2/[(1+k)^2(1-3q)], 0<q<a.

There is a strict maximum along the coupling coordinate at q=k; arbitrary
transverse fields are not selected. At a smooth crossing chi=0,

    dotGforce/Gforce=0,
    ddotGforce/Gforce=-32k dotchi^2/(1-3k).

A first-drift bound has no uniform inverse into coupled-scalar speed near that
point. The finite-window synthetic fit retains curvature and can have a cubic
leading fitted slope. This is not compatibility with a lunar ephemeris or
permission for arbitrarily rapid backgrounds. The unknown reference scale,
actual environment and derivative errors still matter.

**Action reconstruction and remaining freedom.** Under ideal supplied stationary
functions Gbare,rho_J,q on a connected single-field branch, F=Q/A^2 gives

    omega(F)=(1/q-3)/2,
    2F V_J'(F)-4V_J(F)=rho_J(F),
    V_J=F^2[C+integral rho_J(f)/(2f^3)df].

The C F^2 freedom changes the Einstein vacuum energy. It is not an irrelevant
constant. A background history likewise fails to determine transverse Hessians.
No actual density-response functions or independently justified action selector
were provided by the observations used here.

**Finite-history inverse and measured error.** Compact-weight weak equations can
remove free initial amplitudes from parameter reconstruction when actual measured
features have the required rank. Rank failure, source calibration and model error
remain explicit. A paired force/deflection extension re-expresses the earlier
two-epoch relation as H=G(2gamma-1)=P(a-q). Two epochs calibrate, and a third obeys
an affine residual test. New finite error bounds use measured inputs and refuse
an unresolved denominator. These are prospective inference tools, not completed
observed fits. The latest paired-error review/publication state must be updated
before this draft is finalized.

**Past-history and thermal constraints.** Positive radiation and explicit flat,
positive-energy/charge assumptions give a physical-past duration inequality that
removes a separately supplied Hv and global conformal cap. Its CMB/G reference
normalization is about1310.846Gyr, not a measured age prediction. Positive curvature
and source production are distinct escape routes. For a specified ideal equilibrium
photon/electron/positron bath, correlated pressure/entropy bounds strengthen a
strict Einstein-bounce obstruction. The particle content, equilibrium, entropy
and local calibration assumptions remain; no actual thermal history was inferred.

## Observations and separation of evidence roles

| Source | Actual role | What was not done |
| --- | --- | --- |
| Published CMB temperature and CODATA G | Reference normalization for a conditional inequality | No cosmological age or hierarchy fit |
| Cassini gamma summary | Exposed interval benchmark conditional on a controlled Solar long-range bridge | No raw timing likelihood, new confidence region or unconditional k exclusion |
| Laboratory inverse-square result (Lee et al.2020) | Motivation to derive normalized finite-geometry torque response | No raw apparatus torque fit; alpha=1 exclusion was not silently applied to q<1/3 |
| MICROSCOPE final result | Motivation for complete-body charge and common versus differential response | No telemetry fit or universal common-coupling bound from a differential null |
| Lunar-ranging papers | Measurement-method context for a force-to-orbit bridge and its limits | No ephemeris fit; the published dotG estimate was not converted to a scalar-speed limit |
| DESI/other large-scale context | Exposed development context for transfer/readout limitations | No catalogue likelihood or reserved observed test |

All real observational sources were exposed during development or used as
explicit calibration/reference inputs. **There was no completed independent
observational holdout.** Reserved synthetic points test same-model mathematics;
they are not independent empirical validation. Error envelopes in the inverse
certificates are deterministic assumptions, not automatically Gaussian intervals.

## Rejected routes and surviving failures

- The original radiation point is not a full attractor; a transverse direction
  grows. An alternative limiting branch does not select a complete history.
- Bounded normalized variables do not imply a bounded physical past. The checked
  past-convergent branch can reach divergent curvature in finite proper time.
- A unique algebraic density root is not a stability or environment-selection
  proof. Fixed-particle data can have two local minima separated by a saddle.
- Density on the negative-u branch cannot lower the coupling norm below k;
  finite range and nonlinear body response are separate mechanisms.
- A fixed material response p=3 cannot replace fluid dynamics. Conservation
  gives frequency-dependent response plus a homogeneous mode; Jeans limits persist.
- One-epoch covariance feasibility or cancellation of a common amplitude does
  not select the relative initial-mode covariance.
- Bare gravity and total force-calibrated gravity do not have equal scalar
  derivatives. A single drift summary does not supply paired varying readouts.
- Finite-range scalar charge is not fixed by mass alone. A signed source-average
  bound is not a bound on absolute fluctuations or radiation power.

Original failed calculations remain recoverable: serialization errors, finite-body
flux/mesh failures, exact conditioning repairs, proof decay gaps, source-scope
corrections and damaged implementations. A later double-root inverse needed
higher arithmetic precision at unchanged acceptance. Publication metadata also
required a line-start type declaration; that mechanical failure and correction
are separate from scientific results. None was deleted or counted as a clean
initial execution.

A historical evidence gap remains: twelve original Radau mixture profiles were
not recovered. Independent replay and summaries are distinct evidence, not
replacements mislabeled as original files. Temporary cache inputs are identified
only where exact hashes/recoveries exist; absent bytes and historical filesystem
tokens are not inferred from present files. Assertion and file counts are not
numbers of physical experiments.

## Artifacts and unfinished work

Runtime PRS.json is the verified PR index. Canonical milestones each contain a
claim note, executable checker, bound cache and recovery archive. Focused source,
port and delivery checks are separately sealed. All campaign PRs remain unmerged.
Some checked kinetic-radiation, observational-transfer, clock and rolling-inverse
extensions remain in the campaign pack without a separate canonical milestone;
the final inventory must distinguish those from published PR contents.

The next scientific bottleneck is a complete forward calculation for one actual
measurement regime, using measured source/material/environment data and an
explicit calibration/test split. It must derive or bound the environmental and
instrument terms before published statistical errors can become candidate tests.
Separately, action/potential/scale selection needs a justified mechanism that
makes a distinct prediction. Assigning a vacuum, density minimum, ensemble,
thermal history or regulator scale would not solve that task.

Final deadline/process/automation status and final PR index: pending. This draft
must be finalized from the preserved state at the fixed deadline, without extending
discovery or claiming any pending independent result as complete.
