from pathlib import Path
import tarfile,gzip,io,json,hashlib,datetime
wt=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go');pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';out=wt/'docs/work_history/physics/revised-scalar-campaign-20261014/summary_checks_v1.tar.gz';assert not out.exists();files={}
for root in ['final_report_finite_body_scope_v1','final_report_consistency_v1']:
 for f in sorted((pk/root).rglob('*')):
  if f.is_file() and not f.is_symlink() and '__pycache__' not in f.parts:files[f.relative_to(pk).as_posix()]=f
for pattern in ['FINAL_REPORT_DRAFT_v*.md','FINAL_REPORT_DRAFT_v*.diff','PARENT_FINAL_REPORT_SCOPE_VERIFY_v1.json','PARENT_FINAL_REPORT_CONSISTENCY_VERIFY_v1.json']:
 for f in sorted(pk.glob(pattern)):files[f.name]=f
files['build_summary_checks_v1.py']=Path(__file__).resolve()
sha=lambda b:hashlib.sha256(b).hexdigest();rows=[{'path':n,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size,'original_path':str(f)} for n,f in sorted(files.items())];manifest={'scope':'Bounded report consistency and preservation checks. Scientific results reused, not re-proved or empirically validated. Final live report may update operational metadata after these immutable drafts; its final delta is recorded separately.','payloads':rows};mb=(json.dumps(manifest,indent=2)+'\n').encode()
def add(t,n,b):
 i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with out.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as t:
   for n,f in sorted(files.items()):add(t,n,f.read_bytes())
   add(t,'SUMMARY_RECOVERY_MANIFEST_v1.json',mb)
with tarfile.open(out,'r:gz') as t:
 names=t.getnames();assert len(names)==len(set(names))==len(rows)+1
 for x in rows:
  m=t.getmember(x['path']);assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  b=t.extractfile(m).read();assert len(b)==x['bytes'] and sha(b)==x['sha256'] and b==Path(x['original_path']).read_bytes()
 assert t.extractfile('SUMMARY_RECOVERY_MANIFEST_v1.json').read()==mb
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(out.relative_to(wt)),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'payload_count':len(rows),'manifest_sha256':sha(mb),'all_payload_hashes_sizes_and_original_bytes_verified':True,'scope':'Preservation only; no new discovery or full-report scientific endorsement.'};(pk/'final_preservation_v1/SUMMARY_ARCHIVE_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
