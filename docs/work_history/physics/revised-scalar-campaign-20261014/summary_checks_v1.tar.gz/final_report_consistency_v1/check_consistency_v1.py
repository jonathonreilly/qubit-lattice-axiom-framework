from pathlib import Path
import json,hashlib,difflib,datetime
O=Path(__file__).resolve().parent;P=O.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def ck(n,a,b=True):checks.append({'name':n,'passed':a==b,'actual':a,'expected':b})
rows=[]
for f in sorted((O/'sources').rglob('*')):
 if f.is_file():
  src=P/f.relative_to(O/'sources');h=sha(f);ck('snapshot/current '+str(f.relative_to(O)),sha(src),h)
  rows.append({'original_path':str(src),'original_sha256':h,'recovery':str(f),'recovery_sha256':h,'final_path':str(src),'final_sha256':h,'disposition':'Exact frozen source for bounded summary/preservation consistency; source science reused, not rerun.'})
v4=(O/'sources/FINAL_REPORT_DRAFT_v4.md').read_text();v5=(O/'sources/FINAL_REPORT_DRAFT_v5.md').read_text()
ck('frozen v4',sha(O/'sources/FINAL_REPORT_DRAFT_v4.md'),'95e7d5c3ec3eea0ad2e6a10d557a086408ea580ab28a9974ab9e6609ba16568d')
ck('frozen v5',sha(O/'sources/FINAL_REPORT_DRAFT_v5.md'),'916461bf82ff2cb9fa6d4d6e32ee55a3a1c3589b542d9fd2c77750a99e918f50')
patch=''.join(difflib.unified_diff(v4.splitlines(True),v5.splitlines(True),fromfile='FINAL_REPORT_DRAFT_v4.md',tofile='FINAL_REPORT_DRAFT_v5.md'))
ck('exact affected diff',hashlib.sha256(patch.encode()).hexdigest(),sha(O/'sources/FINAL_REPORT_DRAFT_v4_v5.diff'))
a=v4;b=v5
for begin,end in [('**Complete-body charge.**','**Finite observation windows.**'),('**Finite-history inverse and measured error.**','**Past-history and thermal constraints.**')]:
 i=a.index(begin);j=a.index(end,i);a=a[:i]+'[affected paragraph]\n'+a[j:]
 i=b.index(begin);j=b.index(end,i);b=b[:i]+'[affected paragraph]\n'+b[j:]
ck('all other v4 prose unchanged',a==b)
for text in ['formal massless\nlocal-operator limit','R << r << 1/mu','independently negligible ambient linear response','same modeled source and\nenvironment','Each epoch must satisfy its physical q-domain','positive P must pass their admissibility and separation gates','residual alone does not certify','There was no completed independent\nobservational holdout.','This is not a completion record.']:
 ck('scope text '+text,text in v5)
idx=json.loads((O/'INDEX_IDENTITY_CHECK_v1.json').read_text())['rows'];ck('indexed identities',len(idx),62)
for row in idx:
 ck('index hash '+row['path'],row['actual_sha256'],row['expected_sha256'])
 if 'expected_bytes' in row:ck('index size '+row['path'],row['actual_bytes'],row['expected_bytes'])
coverage=json.loads((O/'INDEX_ARCHIVE_COVERAGE_v1.json').read_text())['rows']
for row in coverage:ck('indexed archive binding '+row['path'],row['present_in_primary_manifest'] and row['matches_when_present'])
build=json.loads((O/'sources/final_preservation_v1/BUILD_RESULT_v2.json').read_text());outer=json.loads((O/'ARCHIVE_OUTER_CHECK_v1.json').read_text());manifest=json.loads((O/'ARCHIVE_PRIMARY_MANIFEST_v1.json').read_text())
ck('archive outer hash',outer['actual_sha256'],build['archive_sha256']);ck('archive bytes',outer['actual_bytes'],build['archive_bytes']);ck('archive payload census',len(manifest['artifacts']),7321);ck('archive member census',outer['member_count'],7322)
ck('paired block explicitly excluded',manifest['excluded_active_source'],['rolling_local_response/paired_gravity_certificate_v1'])
ck('paired block absent manifest',not any('paired_gravity_certificate_v1/' in row['path'] for row in manifest['artifacts']))
ck('known original gap retained','Twelve original Radau' in manifest['known_gap'])
receipt=json.loads((O/'sources/rolling_local_response/paired_gravity_certificate_v1/independent_v1/RECEIPT_v1.json').read_text())
ck('paired frozen baseline counts',[receipt['independent_baseline']['passed'],receipt['independent_baseline']['failed'],receipt['independent_baseline']['complete_profiles']],[2772,0,192]);ck('paired domain counts',[receipt['separate_domain_followup']['passed'],receipt['separate_domain_followup']['failed']],[1155,0]);ck('six actual paired damages',len(receipt['actual_damages']),6);ck('damages are failed exits',all(x['actual_exit_code']==1 and x['failed']>0 for x in receipt['actual_damages']))
(O/'SOURCE_DISPOSITIONS_v1.json').write_text(json.dumps({'original_dispositions':rows,'scope':'All current/snapshot identities; superseded drafts retained under separate filenames.'},indent=2)+'\n')
result={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'source_pairs':len(rows),'scope':'Text/source/preservation consistency only, not new scientific checks.'}
(O/'CHECK_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','failed','source_pairs']}))
raise SystemExit(bool(result['failed']))
