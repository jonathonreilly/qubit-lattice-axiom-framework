from pathlib import Path
import hashlib,json,difflib,datetime
HERE=Path(__file__).resolve().parent
checks=[]
def check(name,actual,expected):
 checks.append({"name":name,"passed":actual==expected,"actual":actual,"expected":expected})
rows=[]
for freeze_name in ["FREEZE_v1.json","AFFECTED_FREEZE_v3.json"]:
 freeze=json.loads((HERE/freeze_name).read_text())
 for row in freeze["sources"]:
  original=Path(row["original_path"]);recovery=Path(row["recovery"])
  check("source identity: "+original.name,hashlib.sha256(original.read_bytes()).hexdigest(),row["sha256"])
  check("snapshot identity: "+recovery.name,hashlib.sha256(recovery.read_bytes()).hexdigest(),row["sha256"])
  check("snapshot size: "+recovery.name,recovery.stat().st_size,row["bytes"])
  rows.append(row)
old=(HERE/"sources/FINAL_REPORT_DRAFT_v2.md").read_text()
new=(HERE/"sources/FINAL_REPORT_DRAFT_v3.md").read_text()
patch=(HERE/"sources/FINAL_REPORT_DRAFT_v3.diff").read_text()
expected="".join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="FINAL_REPORT_DRAFT_v2.md",tofile="FINAL_REPORT_DRAFT_v3.md"))
check("complete exact unified diff",patch,expected)
lineage=json.loads((HERE/"sources/FINAL_REPORT_DRAFT_LINEAGE_v3.json").read_text())
check("lineage old identity",lineage["old_sha256"],hashlib.sha256(old.encode()).hexdigest())
check("lineage new identity",lineage["new_sha256"],hashlib.sha256(new.encode()).hexdigest())
check("lineage preserves old",lineage["old_draft_preserved"],True)
# The only changed prose is inside these two reviewed sections.
parts=[("Finite held-body theorem.","Complete-body charge."),("Finite observation windows.","Force calibration and its turning point.")]
a=old;b=new
for start,end in parts:
 sa="**"+start+"**";sb="**"+end+"**"
 i=a.index(sa);j=a.index(sb,i);a=a[:i]+"[REVIEWED SECTION]\n"+a[j:]
 i=b.index(sa);j=b.index(sb,i);b=b[:i]+"[REVIEWED SECTION]\n"+b[j:]
check("all other draft sections byte-identical",b,a)
for text in ["x=y=0", "nu>0", "nonnegative bounded, compactly", "held Einstein particle density rho_star", "chi(u=0)=0", "c=rho_star/(2Q)", "||-chi||infinity", "vacuum mass squared as P approaches\nzero at fixed parameters", "|Qbar/E-1|<=2R/(cT)", "|Fbar_local/E-1|<=18R/(cT)", "in c=1 units"]:
 check("correction present: "+text,text in new,True)
result={"created":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Source/diff identity and explicit-text correspondence only; no scientific execution or new proof.","pass":sum(x["passed"] for x in checks),"fail":sum(not x["passed"] for x in checks),"checks":checks,"sources":rows}
(HERE/"CHECK_RESULTS_v1.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"pass":result["pass"],"fail":result["fail"],"result":"CHECK_RESULTS_v1.json"}))
raise SystemExit(bool(result["fail"]))
