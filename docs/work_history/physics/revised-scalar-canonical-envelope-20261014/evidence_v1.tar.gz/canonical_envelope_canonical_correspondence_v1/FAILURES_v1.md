# Failure and limitation ledger

All earlier failures are retained as evidence, not replaced by successful later counts.

The prior finite-body seal preserves excursion v1's NumPy-boolean serialization failure (no complete count), v2's 216/4 flux failures, v3's 219/1 node-budget failure, and the v4 rescaling repair giving 220/0. Surface v1's serialization failure and bool-only v2 repair to 172/0 also remain. The decay-proof repair, surface radial qualification, uniqueness aggregate exposure, and metadata absolute/relative path-comparison failure are retained in the copied complete prior seal. That seal's complete report and failure ledger were read, and all 1129 artifacts plus 790 original/recovery pairs were verified.

The envelope independent seal preserves its actual tolerance-parser ValueError before a result was written. Parser-only v2 completed 2075/0 using unchanged tolerances, fixtures and mathematics. Its six altered programs and every intended failed witness remain intact. No current producer baseline failure is reported or inferred.

The parent actually executed three full altered staged programs: connection 467/21, regulator 486/2, inverse 487/1. Each exited 1. Their exact source differences, hashes, commands, complete result rows, streams and profiles were inspected and frozen. These are inspected existing runs, not new independent executions.

This correspondence's metadata and baseline wrapper checks had no unexpected failed execution. Three actual full-source wrapper alterations were executed only at main using explicit synthetic stubs: omission of envelope failures gives 112/3, wrong envelope input root gives 47/26, and hidden failure exit gives 111/4, all exit 1. The wrong-root alteration interrupts cases early; fewer assertions execute, and that is not misreported as a full baseline count. All actual source bytes, diffs, commands, inputs, stdout, stderr, exception tracebacks and result rows remain under wrapper_controls_v1.

Expected controls include existing-path assertions, deliberate return/result mismatch, malformed JSON, missing result and a synthetic thrown exception. Successful detection of these is counted as defensive wrapper evidence only. The two truncated tool displays are documented in ACCESS_HISTORY_v1.json; the complete underlying JSON and raw files are saved and inspected.

Default temporary profiles are deleted after completion. Their input paths in emitted JSON become historical. Persistent stage profiles are recoverable here by exact identity. No live cache, installation of the new note/runner, recovery archive or committed delivery was checked. Failed sufficient convexity criteria do not classify physical instability; sampled positive Hessians do not prove global convexity. No observational calibration or formal audit status follows.
