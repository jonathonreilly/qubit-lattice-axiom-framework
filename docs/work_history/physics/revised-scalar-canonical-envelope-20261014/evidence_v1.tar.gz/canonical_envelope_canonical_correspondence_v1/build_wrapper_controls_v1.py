from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json

HERE=Path(__file__).resolve().parent
source=HERE.parent/'canonical_envelope_packaging/staged/exponential_scalar_canonical_envelope_check.py'
root=HERE/'wrapper_controls_v1';root.mkdir(exist_ok=False)
text=source.read_text()
changes=[('omit_envelope_failures',"failed=sum(z['failed'] for z in units.values())","failed=sum(z['failed'] for n,z in units.items() if n!='envelope')"),('wrong_envelope_root',"else:failed=fn(root,root/dirname)","else:failed=fn(root/'surface_baseline_v2',root/dirname)"),('hide_failure_exit',"return bool(result['failed'])","return False")]
rows=[]
for name,before,after in changes:
    assert text.count(before)==1
    folder=root/name;folder.mkdir();changed=text.replace(before,after)
    (folder/'changed.py').write_text(changed)
    (folder/'CHANGE.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='original',tofile='altered')))
    rows.append(dict(name=name,before=before,after=after,path=str(folder/'changed.py'),sha256=hashlib.sha256(changed.encode()).hexdigest()))
(root/'PROTOCOL_v1.json').write_text(json.dumps(dict(created_utc=datetime.now(timezone.utc).isoformat(),source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),scope='Actual full-source alterations; only each main AST executes with explicit science stand-ins. No science rerun.',alterations=rows,expected_exit=1),indent=2)+'\n')
print(json.dumps(dict(controls=len(rows))))
