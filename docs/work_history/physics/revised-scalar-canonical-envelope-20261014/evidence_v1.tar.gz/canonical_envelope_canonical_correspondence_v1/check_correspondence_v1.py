from pathlib import Path
from datetime import datetime, timezone
import ast, copy, difflib, hashlib, json
import numpy as np

HERE=Path(__file__).resolve().parent
PK=HERE.parent
WT=PK.parents[3]
PACK=PK/'canonical_envelope_packaging'
ENV=PK/'rolling_local_response/compactness_canonical_envelope_v1'
BODY=PK/'rolling_local_response/finite_body_excursion_v1'
PRIOR=PK/'finite_body_canonical_correspondence_v1'
NOTE=PACK/'staged/EXPONENTIAL_SCALAR_CANONICAL_ENVELOPE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER=PACK/'staged/exponential_scalar_canonical_envelope_check.py'
rows=[];reuse=[];array_records=[];profile_records=[];all_dispositions={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ck(name,ok,detail=None):rows.append(dict(name=name,passed=bool(ok),detail=detail))
def read(p):return json.loads(Path(p).read_text())
def resolve(p,base=WT):
    p=Path(p);return p if p.is_absolute() else base/p
def record_disposition(original,digest,recovery,role):
    original=resolve(original);recovery=resolve(recovery)
    row=dict(original_path=str(original),original_sha256=digest,disposition='Preserved byte-exact source/evidence identity; no science or status change.',recovery=str(recovery),recovery_sha256=sha(recovery),final_path=str(original),final_sha256=sha(original),role=role)
    if str(original) in all_dispositions:ck('duplicate_source_identity:'+str(original),all_dispositions[str(original)]['original_sha256']==digest)
    else:all_dispositions[str(original)]=row
    ck('disposition_identity:'+str(original),row['recovery_sha256']==digest==row['final_sha256'])

frozen=read(HERE/'SOURCE_BINDINGS_v1.json')['sources']
for r in frozen:
    p=Path(r['original_path']);s=Path(r['snapshot_path'])
    ck('frozen:'+str(p),p.is_file() and s.is_file() and p.stat().st_size==r['bytes'] and s.stat().st_size==r['bytes'] and sha(p)==r['sha256']==sha(s))
    record_disposition(p,r['sha256'],s,'Direct frozen artifact; hashes inspected, with substantive reading/comparison described separately.')

for directory,expected in [(PRIOR,(1129,790,'51417102e3dca3ccec528c570481e0d8859ea54212bc20d0f4b4b42c878e3f71')),(ENV/'independent_v1',(88,18,'e07bca623200a4b994f4d02e5d32ceaca7fa207ada06eaa4b4f9a9570cc08039'))]:
    receipt=read(directory/'RECEIPT_v1.json');manifest=read(directory/'MANIFEST_v1.json')
    ck('reuse_receipt:'+str(directory),sha(directory/'RECEIPT_v1.json')==expected[2])
    ck('reuse_counts:'+str(directory),(receipt['artifact_count'],receipt['source_pair_count'])==expected[:2] and len(manifest['artifacts'])==expected[0])
    for item in manifest['artifacts']:
        path=directory/item['path'];ck('reuse_artifact:'+str(path),path.is_file() and sha(path)==item['sha256'] and ('bytes' not in item or path.stat().st_size==item['bytes']))
    for item in receipt['bindings']:
        path=directory/item['path'];ck('reuse_receipt_binding:'+str(path),path.is_file() and sha(path)==item['sha256'])
    dispositions=read(directory/receipt['original_dispositions'])['original_dispositions']
    ck('reuse_disposition_count:'+str(directory),len(dispositions)==expected[1])
    for item in dispositions:
        original=resolve(item['original_path']);recovery=resolve(item['recovery']);final=resolve(item['final_path'])
        ck('reuse_original_recovery_final:'+str(original),sha(original)==item['original_sha256']==sha(recovery) and sha(final)==item['final_sha256'])
        local_recovery=HERE/'sources'/recovery.relative_to(WT)
        ck('reused_recovery_in_new_snapshot:'+str(original),local_recovery.exists() and sha(local_recovery)==item['original_sha256'])
        record_disposition(original,item['original_sha256'],local_recovery,'Original reviewed version recovered through unchanged prior seal; original science reused, not rerun.')
    reuse.append(dict(path=str(directory),receipt_sha256=sha(directory/'RECEIPT_v1.json'),report_sha256=sha(directory/'REPORT_v1.md'),manifest_sha256=sha(directory/'MANIFEST_v1.json'),artifacts=len(manifest['artifacts']),source_pairs=len(dispositions),new_science_run=False))

lineage=read(PACK/'CANONICAL_LINEAGE_v1.json')
ck('note_expected_hash',sha(NOTE)=='78ff317df690af56b9c3bf486ff44592c64245c37bdd94f4fac6b0ca07c6da6c'==lineage['note_sha256'])
ck('runner_expected_hash',sha(RUNNER)=='b6bd10550a0bd110cf66523484d15c27c92bd248fb8bb68357b8c2e14221a35a'==lineage['runner_sha256'])
hand=Path(lineage['hand']['path']);hand_body='\n'.join('#'+line if line.startswith('#') else line for line in hand.read_text().splitlines())
ck('full_hand_hash',sha(hand)==lineage['hand']['sha256'])
ck('full_hand_once_exact_heading_port',NOTE.read_text().count(hand_body)==1)
tree=ast.parse(RUNNER.read_text());expected=[];ast_reports=[]
class Rename(ast.NodeTransformer):
    def __init__(self,m):self.m=m
    def visit_Name(self,n):n.id=self.m.get(n.id,n.id);return n
    def visit_FunctionDef(self,n):n.name=self.m.get(n.name,n.name);return self.generic_visit(n)
for item in lineage['code_sources']:
    path=Path(item['path']);ck('port_original_hash:'+path.name,sha(path)==item['sha256'])
    old=ast.parse(path.read_text());nodes=[n for n in old.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    transformed=ast.fix_missing_locations(Rename(item['renames']).visit(ast.Module(body=copy.deepcopy(nodes),type_ignores=[])))
    digest=hashlib.sha256(ast.dump(transformed,include_attributes=False).encode()).hexdigest()
    ck('port_declared_ast:'+path.name,digest==item['transformed_ast_sha256'])
    expected.extend(transformed.body);ast_reports.append(dict(path=str(path),source_sha256=sha(path),ast_sha256=digest,renames=item['renames']))
dumps=lambda ns:[ast.dump(n,include_attributes=False) for n in ns]
full=dumps(tree.body);target=dumps(expected)
hits=[i for i in range(len(full)-len(target)+1) if full[i:i+len(target)]==target]
ck('complete_three_port_contiguous_region',len(hits)==1,hits)
if hits:
    start=hits[0];remaining=tree.body[start+len(target):]
    ck('only_main_and_cli_after_ports',len(remaining)==2 and isinstance(remaining[0],ast.FunctionDef) and remaining[0].name=='main' and isinstance(remaining[1],ast.If))
definitions=[n.name for n in tree.body if isinstance(n,ast.FunctionDef)]
ck('isolated_function_names',definitions==['check_excursion','check_surface','check_envelope','main'])
constants={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id.startswith('AUDIT_')}
expected_inputs=['docs/EXPONENTIAL_SCALAR_CANONICAL_ENVELOPE_BOUNDED_THEOREM_NOTE_2026-10-14.md','docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md']
ck('declared_runtime_inputs',constants['AUDIT_INPUT_PATHS']==expected_inputs and constants['AUDIT_TIMEOUT_SEC']==120)
dependencies=[]
for i,name in enumerate(expected_inputs):
    path=NOTE if i==0 else WT/name
    dependencies.append(dict(declared_path=name,reviewed_path=str(path),sha256=sha(path),live_declared_path_exists=(WT/name).exists(),role='staged prospective canonical input' if i==0 else 'existing canonical premise'))
ck('live_finite_body_matches_reused_stage',sha(WT/expected_inputs[-1])=='819c683b881066c736888ec51d735b04afab6d25a70a4515170f71b74cf2fd32')
import_roots=sorted({(n.module.split('.')[0] if isinstance(n,ast.ImportFrom) else a.name.split('.')[0]) for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom)) for a in (n.names if isinstance(n,ast.Import) else [None])})
ck('imports_no_producer_or_repository_helpers',set(import_roots)=={'contextlib','tempfile','io','pathlib','argparse','json','hashlib','itertools','numpy','sympy','scipy','mpmath'},import_roots)

originals={'excursion':BODY/'baseline_v4','surface':BODY/'surface_baseline_v2','envelope':ENV/'baseline_v1'}
dirnames={'excursion':'baseline_v4','surface':'surface_baseline_v2','envelope':'envelope'}
def inspect_run(root,full_result,program,label):
    data=read(full_result);ck(label+':aggregate_counts',data['passed']==sum(v['passed'] for v in data['units'].values()) and data['failed']==sum(v['failed'] for v in data['units'].values()))
    ck(label+':checker_identity',data['checker_sha256']==sha(program))
    ck(label+':units_order',list(data['units'])==['excursion','surface','envelope'])
    for name,unit in data['units'].items():
        directory=root/dirnames[name]
        ck(label+':complete_saved_unit:'+name,read(directory/'RESULTS.json')==unit)
        ck(label+':unit_hash:'+name,unit['checker_sha256']==sha(program))
        ck(label+':check_rows_count:'+name,unit['passed']==sum(r['passed'] for r in unit['checks']) and unit['failed']==sum(not r['passed'] for r in unit['checks']))
        summary=json.loads(data['unit_stdout'][name]);ck(label+':captured_summary:'+name,summary['passed']==unit['passed'] and summary['failed']==unit['failed'] and summary['failed_checks']==[r for r in unit['checks'] if not r['passed']])
        required=[]
        if name=='surface':required=[root/'baseline_v4/RESULTS.json']+[root/'baseline_v4'/c['profile'] for c in data['units']['excursion']['cases']]
        if name=='envelope':required=[root/'baseline_v4/RESULTS.json',root/'surface_baseline_v2/RESULTS.json']
        actual=unit.get('source_bindings',[])
        ck(label+':fresh_input_paths:'+name,[r['path'] for r in actual]==[str(p) for p in required])
        for item in actual:ck(label+':input_sha:'+name+':'+item['path'],sha(item['path'])==item['sha256'])
        for case in unit.get('cases',[]) if name=='excursion' else []:
            ck(label+':excursion_profile_hash:'+str(case['index']),sha(directory/case['profile'])==case['profile_sha256'])
        for case in unit.get('cases',[]) if name=='surface' else []:
            ck(label+':surface_profile_hash:'+str(case['index']),sha(root/'baseline_v4'/('profile_'+str(case['index'])+'.npz'))==case['profile_sha256'])
        profiles=sorted(directory.glob('*.npz'))+sorted(directory.glob('prospective_samples_*.json'))
        ck(label+':profile_count:'+name,len(profiles)==(6 if name=='envelope' else 18))
        for path in profiles:
            if path.suffix=='.npz':
                with np.load(path,allow_pickle=False) as z:
                    ck(label+':finite_npz:'+str(path),all(np.isfinite(z[n]).all() for n in z.files))
            else:ck(label+':sample_count:'+str(path),len(read(path))==41)
    return data

baseline=inspect_run(PACK/'profiles_v1',PACK/'STAGED_RESULTS_v1.json',RUNNER,'baseline')
ck('baseline_expected_counts',(baseline['passed'],baseline['failed'])==(488,0))
ck('full_stdout_exact_saved_result',(PACK/'STAGED_stdout_v1.txt').read_bytes()==(PACK/'STAGED_RESULTS_v1.json').read_bytes())
ck('baseline_stderr_empty',(PACK/'STAGED_stderr_v1.txt').read_bytes()==b'')
run=read(PACK/'STAGED_RUN_v1.json');started=read(PACK/'STAGED_STARTED_v1.json')
ck('recorded_baseline_execution',run['exit_code']==0 and run['checker_sha256']==sha(RUNNER) and run['args']==started['args'] and run['args'][1:]==[str(RUNNER),'--profiles',str(PACK/'profiles_v1'),'--out',str(PACK/'STAGED_RESULTS_v1.json')])
ck('baseline_time_order',started['started_at']==run['started_at']<run['ended_at'])
for name,oldroot in originals.items():
    current=baseline['units'][name];old=read(oldroot/'RESULTS.json')
    strip=lambda obj:{k:v for k,v in obj.items() if k not in ['checker_sha256','source_bindings']}
    ck('complete_scientific_output:'+name,strip(current)==strip(old))
    source=BODY/('check_excursion_v4.py' if name=='excursion' else 'check_surface_v2.py') if name!='envelope' else ENV/'check_envelope_v1.py'
    ck('original_checker_metadata:'+name,old['checker_sha256']==sha(source))
    for item in old.get('source_bindings',[]):ck('original_input_hash:'+item['path'],sha(item['path'])==item['sha256'])
    freshroot=PACK/'profiles_v1'/dirnames[name]
    files=sorted(freshroot.glob('*.npz'))+sorted(freshroot.glob('prospective_samples_*.json'))
    for path in files:
        original=oldroot/path.name;ck('complete_profile_bytes:'+str(path),path.read_bytes()==original.read_bytes())
        profile_records.append(dict(unit=name,original=str(original),staged=str(path),sha256=sha(path),bytes=path.stat().st_size))
        if path.suffix=='.npz':
            with np.load(path,allow_pickle=False) as a,np.load(original,allow_pickle=False) as b:
                ck('profile_keys:'+str(path),a.files==b.files)
                for key in a.files:
                    ck('profile_array:'+str(path)+':'+key,a[key].dtype==b[key].dtype and a[key].shape==b[key].shape and np.array_equal(a[key],b[key]))
                    array_records.append(dict(path=str(path),key=key,shape=list(a[key].shape),dtype=str(a[key].dtype)))
ck('profile_totals',len(profile_records)==42 and sum(r['staged'].endswith('.npz') for r in profile_records)==36)
ck('prospective_new_only_advantage_count',sum(not c['old_criterion_met'] and c['new_criterion_met'] for c in baseline['units']['envelope']['prospective_parameter_cases'])==4)

damages=read(PACK/'damages_v1/SUMMARY_v1.json');damage_protocol=read(PACK/'damages_v1/PROTOCOL_v1.json')
expected_counts={'connection':(467,21),'regulator':(486,2),'inverse':(487,1)}
replacements={r[0]:r[1:] for r in damage_protocol['actual_replacements']}
damage_records=[]
for item in damages:
    name=item['name'];directory=PACK/'damages_v1'/name;program=directory/'changed.py';record=read(directory/'RUN.json')
    before,after=replacements[name];original=RUNNER.read_text();changed=program.read_text()
    ck('damage_exact_replacement:'+name,original.count(before)==1 and changed==original.replace(before,after))
    exactdiff=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='original',tofile='altered'))
    ck('damage_exact_diff:'+name,(directory/'CHANGE.diff').read_text()==exactdiff)
    ck('damage_actual_record:'+name,item==record and record['exit_code']==1 and record['checker_sha256']==sha(program) and record['args'][1:]==[str(program),'--profiles',str(directory/'profiles'),'--out',str(directory/'RESULTS.json')])
    data=inspect_run(directory/'profiles',directory/'RESULTS.json',program,'damage_'+name)
    ck('damage_exact_counts:'+name,(data['passed'],data['failed'])==expected_counts[name] and (record['passed'],record['failed'])==expected_counts[name])
    failures={n:[r['name'] for r in u['checks'] if not r['passed']] for n,u in data['units'].items()}
    ck('damage_complete_failed_rows:'+name,failures==record['failed_checks'])
    ck('damage_full_stream:'+name,(directory/'stdout.txt').read_bytes()==(directory/'RESULTS.json').read_bytes() and (directory/'stderr.txt').read_bytes()==b'')
    damage_records.append(dict(name=name,counts=expected_counts[name],checker_sha256=sha(program),record_sha256=sha(directory/'RUN.json'),failed_checks=failures))

result=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='Identity, source, saved-output and recovery correspondence only. No science execution.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,reused_seals=reuse,ast_ports=ast_reports,runtime_dependencies=dependencies,profile_correspondence=profile_records,npz_arrays=array_records,parent_actual_damages=damage_records)
(HERE/'CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
(HERE/'SOURCE_DISPOSITIONS_v1.json').write_text(json.dumps(dict(scope='All direct frozen and inherited original source versions, retaining exact prior recovery identities.',original_dispositions=list(all_dispositions.values())),indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],source_dispositions=len(all_dispositions),npz_arrays=len(array_records),failed_checks=[r for r in rows if not r['passed']]),indent=2))
raise SystemExit(bool(result['failed']))
