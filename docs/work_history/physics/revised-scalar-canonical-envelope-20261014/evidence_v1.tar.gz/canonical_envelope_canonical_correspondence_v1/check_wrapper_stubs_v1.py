"""Execute only actual main AST using explicitly synthetic scientific stubs."""
from pathlib import Path
from tempfile import TemporaryDirectory
from contextlib import redirect_stdout,redirect_stderr
import argparse,ast,hashlib,io,json,sys,traceback

HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
assert args.out.resolve().is_relative_to(HERE)
args.out.mkdir(parents=True,exist_ok=False)
source=args.source.read_text();tree=ast.parse(source)
mains=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main'];assert len(mains)==1
maincode=compile(ast.fix_missing_locations(ast.Module(body=mains,type_ignores=[])),str(args.source),'exec')
rows=[];scenarios=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ck(name,ok,detail=None):rows.append(dict(name=name,passed=bool(ok),detail=detail))
cases=[('clean',{},False,None),('excursion_failure',{'excursion':1},False,None),('surface_failure',{'surface':2},False,None),('envelope_failure',{'envelope':3},False,None),('all_failure',{'excursion':1,'surface':2,'envelope':3},False,None),('temporary_cleanup',{},True,None),('existing_profiles',{},False,'AssertionError'),('existing_out',{},False,'AssertionError'),('return_mismatch',{},False,'AssertionError'),('malformed_json',{},False,'JSONDecodeError'),('unit_exception',{},False,'RuntimeError'),('missing_result',{},False,'FileNotFoundError')]
for label,failures,temporary,expected_error in cases:
    folder=args.out/label;folder.mkdir();profiles=folder/'profiles';output=folder/'complete.json'
    if label=='existing_profiles':profiles.mkdir();(profiles/'original.txt').write_text('preexisting profile sentinel')
    if label=='existing_out':output.write_text('preexisting output sentinel')
    state=dict(calls=[],results={},streams={},roots=[],input_records=[])
    passed_counts={'excursion':7,'surface':11,'envelope':13}
    def save(name,dest,inputs):
        state['calls'].append(name)
        if label=='unit_exception' and name=='envelope':raise RuntimeError('explicit synthetic unit exception')
        dest.mkdir(parents=True,exist_ok=False)
        result=dict(passed=passed_counts[name],failed=failures.get(name,0),nested=dict(marker=label,unit=name,rows=[dict(x=2,y=[3,5,7]),dict(x=-1,y=[])],inputs=inputs),checks=[dict(name='synthetic_only',passed=not failures.get(name,0))],cases=[dict(index=19,label=name)],checker_sha256=sha(args.source))
        state['results'][name]=result
        stream='synthetic '+name+' for '+label+'\n';print(stream,end='');state['streams'][name]=stream
        if label=='malformed_json' and name=='surface':(dest/'RESULTS.json').write_text('{ malformed explicit control')
        elif not(label=='missing_result' and name=='surface'):(dest/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
        (dest/'synthetic_profile.txt').write_text(json.dumps(dict(unit=name,token=label)))
        return result['failed']+int(label=='return_mismatch' and name=='surface')
    def excursion(dest):
        state['roots'].append(str(dest.parent));assert dest.name=='baseline_v4'
        return save('excursion',dest,[])
    def surface(src,dest):
        assert src==Path(state['roots'][0])/'baseline_v4','surface must consume fresh excursion'
        loaded=json.loads((src/'RESULTS.json').read_text());assert loaded==state['results']['excursion']
        inputs=[dict(path=str(src/'RESULTS.json'),sha256=sha(src/'RESULTS.json'))];state['input_records'].append(dict(unit='surface',inputs=inputs))
        return save('surface',dest,inputs)
    def envelope(src,dest):
        assert src==Path(state['roots'][0]),'envelope must receive fresh common root'
        inputs=[]
        for name,dirname in [('excursion','baseline_v4'),('surface','surface_baseline_v2')]:
            path=src/dirname/'RESULTS.json';assert json.loads(path.read_text())==state['results'][name];inputs.append(dict(path=str(path),sha256=sha(path)))
        state['input_records'].append(dict(unit='envelope',inputs=inputs))
        return save('envelope',dest,inputs)
    def local_temporary(**kwargs):return TemporaryDirectory(dir=folder,**kwargs)
    namespace=dict(__file__=str(args.source),Path=Path,argparse=argparse,json=json,hashlib=hashlib,io=io,redirect_stdout=redirect_stdout,TemporaryDirectory=local_temporary,check_excursion=excursion,check_surface=surface,check_envelope=envelope)
    exec(maincode,namespace)
    argv=[str(args.source),'--out',str(output)]
    if not temporary:argv.extend(['--profiles',str(profiles)])
    oldargv=sys.argv;sys.argv=argv;stdout=io.StringIO();stderr=io.StringIO();error=None;returned=None
    try:
        with redirect_stdout(stdout),redirect_stderr(stderr):returned=namespace['main']()
    except Exception as exc:
        error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
    finally:sys.argv=oldargv
    (folder/'stdout.txt').write_text(stdout.getvalue());(folder/'stderr.txt').write_text(stderr.getvalue())
    record=dict(label=label,argv=argv,expected_exception=expected_error,actual_exception=error,returned=returned,state=state,synthetic_only=True)
    scenarios.append(record);(folder/'SCENARIO.json').write_text(json.dumps(record,indent=2)+'\n')
    ck(label+':expected_exception',(error['type'] if error else None)==expected_error,error)
    ck(label+':no_unexpected_stderr',stderr.getvalue()=='')
    if expected_error is None:
        ck(label+':pipeline_completed',state['calls']==['excursion','surface','envelope'])
        ck(label+':failure_exit',returned==bool(sum(failures.values())),dict(actual=returned,expected=bool(sum(failures.values()))))
        ck(label+':result_exists',output.exists())
        if output.exists() and error is None:
            result=json.loads(output.read_text())
            ck(label+':aggregate_passed',result['passed']==sum(passed_counts.values()))
            ck(label+':aggregate_failed',result['failed']==sum(failures.values()))
            ck(label+':full_nested_payloads',result['units']==state['results'])
            ck(label+':full_captured_streams',result['unit_stdout']==state['streams'])
            ck(label+':source_hash',result['checker_sha256']==sha(args.source))
            ck(label+':stdout_equals_saved_result',stdout.getvalue()==output.read_text())
            ck(label+':source_pipeline_inputs',[x['unit'] for x in state['input_records']]==['surface','envelope'])
        if state['roots']:
            root=Path(state['roots'][0]);ck(label+':temporary_or_retained_root',not root.exists() if temporary else root.exists())
            if temporary:
                ck(label+':temporary_inputs_historical',all(not Path(b['path']).exists() for x in state['input_records'] for b in x['inputs']))
            else:
                ck(label+':retained_inputs_fresh',all(sha(Path(b['path']))==b['sha256'] for x in state['input_records'] for b in x['inputs']))
    else:
        ck(label+':exception_not_success',returned is None)
        ck(label+':no_partial_top_stdout',stdout.getvalue()=='')
        if label=='existing_profiles':
            ck(label+':profiles_not_clobbered',(profiles/'original.txt').read_text()=='preexisting profile sentinel' and not state['calls'])
        elif label=='existing_out':
            ck(label+':output_not_clobbered',output.read_text()=='preexisting output sentinel')
            ck(label+':output_guard_after_units',state['calls']==['excursion','surface','envelope'])
        else:ck(label+':no_complete_output',not output.exists())
result=dict(source=str(args.source),source_sha256=sha(args.source),execution='Only main AST; all three science functions replaced by explicit fresh-output stubs.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,scenarios=scenarios)
(args.out/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failed_checks=[r for r in rows if not r['passed']]),indent=2))
raise SystemExit(bool(result['failed']))
