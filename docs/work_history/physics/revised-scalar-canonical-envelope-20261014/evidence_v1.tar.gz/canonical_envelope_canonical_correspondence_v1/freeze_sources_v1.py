from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
PK=HERE.parent
WT=PK.parents[3]
PACK=PK/'canonical_envelope_packaging'
ENV=PK/'rolling_local_response/compactness_canonical_envelope_v1'
BODY=PK/'rolling_local_response/finite_body_excursion_v1'
PRIOR=PK/'finite_body_canonical_correspondence_v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=set()
for root in [PACK,ENV,PRIOR]:
    paths.update(p for p in root.rglob('*') if p.is_file())
for name in ['check_excursion_v4.py','check_surface_v2.py','DERIVATION_v2.md','SURFACE_FORCE_DERIVATION_v2.md','UNIQUENESS_DERIVATION_v2.md']:
    paths.add(BODY/name)
for name in ['baseline_v4','surface_baseline_v2']:
    paths.update(p for p in (BODY/name).rglob('*') if p.is_file())
for name in ['EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md']:
    paths.add(WT/'docs'/name)
rows=[]
for source in sorted(paths):
    assert source.is_file() and not source.is_symlink(),source
    raw=source.read_bytes();rel=source.relative_to(WT);target=HERE/'sources'/rel
    if target.exists():
        assert target.read_bytes()==raw,('preexisting freeze differs',source)
    else:
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(original_path=str(source),snapshot_path=str(target),bytes=len(raw),sha256=sha(raw)))
out=HERE/'SOURCE_BINDINGS_v1.json'
assert not out.exists()
out.write_text(json.dumps(dict(created_utc=datetime.now(timezone.utc).isoformat(),repository_root=str(WT),scope='Byte-preserved staged sources, original compared outputs and complete reused seals. No source execution.',sources=rows),indent=2)+'\n')
print(json.dumps(dict(sources=len(rows),bytes=sum(r['bytes'] for r in rows),binding_sha256=sha(out.read_bytes()))))
