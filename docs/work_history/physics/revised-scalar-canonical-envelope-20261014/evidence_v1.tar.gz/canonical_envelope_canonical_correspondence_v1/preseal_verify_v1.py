from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json

HERE=Path(__file__).resolve().parent;PK=HERE.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[]
def ck(name,b,detail=None):rows.append(dict(name=name,passed=bool(b),detail=detail))
bindings=read(HERE/'SOURCE_BINDINGS_v1.json')['sources']
dispositions=read(HERE/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
for r in bindings:
    ck('final_direct_pair:'+r['original_path'],sha(r['original_path'])==r['sha256']==sha(r['snapshot_path']))
for r in dispositions:
    ck('final_all_original_recovery_pairs:'+r['original_path'],sha(r['original_path'])==r['original_sha256']==sha(r['recovery']) and sha(r['final_path'])==r['final_sha256'])
correspondence=read(HERE/'CORRESPONDENCE_RESULTS_v1.json')
ck('correspondence_complete',(correspondence['passed'],correspondence['failed'])==(7677,0))
pack=PK/'canonical_envelope_packaging';full=read(pack/'STAGED_RESULTS_v1.json')
for name,path in [('excursion',PK/'rolling_local_response/finite_body_excursion_v1/RUN_v4.stdout'),('surface',PK/'rolling_local_response/finite_body_excursion_v1/SURFACE_RUN_v2.stdout'),('envelope',PK/'rolling_local_response/compactness_canonical_envelope_v1/RUN_v1.stdout')]:
    ck('complete_original_captured_stdout:'+name,full['unit_stdout'][name]==path.read_text())
wrapper=HERE/'wrapper_controls_v1';base=read(wrapper/'baseline/RESULTS_v1.json')
ck('wrapper_baseline',(base['passed'],base['failed'])==(115,0))
ck('wrapper_baseline_actual_execution',read(wrapper/'baseline_run.EXECUTION.json')['exit_code']==0)
summary=[]
expected={'omit_envelope_failures':(112,3,'envelope_failure:aggregate_failed'),'wrong_envelope_root':(47,26,'clean:expected_exception'),'hide_failure_exit':(111,4,'envelope_failure:failure_exit')}
protocol=read(wrapper/'PROTOCOL_v1.json');original=Path(protocol['source']).read_text()
for change in protocol['alterations']:
    name=change['name'];d=wrapper/name;program=d/'changed.py';result=read(d/'execution/RESULTS_v1.json');record=read(d/'run.EXECUTION.json')
    ck('wrapper_damage_program:'+name,sha(program)==change['sha256'] and original.replace(change['before'],change['after'])==program.read_text())
    ck('wrapper_damage_diff:'+name,(d/'CHANGE.diff').read_text()==''.join(difflib.unified_diff(original.splitlines(True),program.read_text().splitlines(True),fromfile='original',tofile='altered')))
    ck('wrapper_damage_actual_counts:'+name,(result['passed'],result['failed'])==expected[name][:2] and record['exit_code']==1 and record['files_unchanged'])
    failed=[r['name'] for r in result['checks'] if not r['passed']]
    ck('wrapper_damage_required_witness:'+name,expected[name][2] in failed)
    ck('wrapper_damage_full_stdout_parse:'+name,read(d/'run.stdout.txt')['failed']==result['failed'])
    ck('wrapper_damage_empty_stderr:'+name,(d/'run.stderr.txt').read_bytes()==b'')
    summary.append(dict(name=name,passed=result['passed'],failed=result['failed'],exit_code=record['exit_code'],source_sha256=sha(program),results_sha256=sha(d/'execution/RESULTS_v1.json'),failed_checks=failed,scientific_body_executed=False))
(wrapper/'SUMMARY_v1.json').write_text(json.dumps(dict(scope='Main AST only with synthetic stubs; not a science run.',baseline=[115,0],actual_altered_wrappers=summary),indent=2)+'\n')
for name in ['staged/EXPONENTIAL_SCALAR_CANONICAL_ENVELOPE_BOUNDED_THEOREM_NOTE_2026-10-14.md','staged/exponential_scalar_canonical_envelope_check.py','STAGED_RESULTS_v1.json','COMPLETE_OUTPUT_CORRESPONDENCE_v1.json','damages_v1/SUMMARY_v1.json']:
    original=pack/name;matches=[r for r in bindings if r['original_path']==str(original)]
    ck('final_staging_record:'+name,len(matches)==1 and sha(original)==matches[0]['sha256'])
ck('every_recovery_inside_new_unit',all(Path(r['recovery']).resolve().is_relative_to(HERE) for r in dispositions))
ck('all_current_artifacts_regular',all(not p.is_symlink() for p in HERE.rglob('*')))
result=dict(at=datetime.now(timezone.utc).isoformat(),passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,direct_pairs=len(bindings),all_original_dispositions=len(dispositions),scope='Final identity and wrapper-output verification; no science rerun.')
(HERE/'PRESEAL_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2));print(json.dumps([r for r in rows if not r['passed']],indent=2))
raise SystemExit(bool(result['failed']))
