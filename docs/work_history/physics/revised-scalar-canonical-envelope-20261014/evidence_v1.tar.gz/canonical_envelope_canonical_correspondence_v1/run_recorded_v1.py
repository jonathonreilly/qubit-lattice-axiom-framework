from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys

HERE=Path(__file__).resolve().parent
prefix=HERE/sys.argv[1]
assert prefix.resolve().is_relative_to(HERE)
argv=sys.argv[2:]
assert argv
files=[Path(x) for x in argv if Path(x).is_file()]
identity=lambda p:dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
before=[identity(p) for p in files]
started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(argv,cwd=HERE,capture_output=True)
for suffix,raw in [('.stdout.txt',r.stdout),('.stderr.txt',r.stderr)]:
    target=Path(str(prefix)+suffix);assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
record=dict(argv=argv,cwd=str(HERE),started_utc=started,ended_utc=datetime.now(timezone.utc).isoformat(),exit_code=r.returncode,executed_files=before,files_unchanged=(before==[identity(p) for p in files]))
target=Path(str(prefix)+'.EXECUTION.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print(r.stdout.decode());print(r.stderr.decode(),file=sys.stderr)
raise SystemExit(r.returncode)
