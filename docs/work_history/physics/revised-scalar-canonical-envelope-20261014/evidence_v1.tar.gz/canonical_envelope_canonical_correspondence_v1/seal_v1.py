from pathlib import Path
from datetime import datetime,timezone
import hashlib,json

HERE=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['MANIFEST_v1.json','RECEIPT_v1.json']:assert not (HERE/name).exists()
sources=read(HERE/'SOURCE_BINDINGS_v1.json')['sources']
dispositions=read(HERE/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
for r in sources:assert sha(r['original_path'])==r['sha256']==sha(r['snapshot_path'])
for r in dispositions:assert sha(r['original_path'])==r['original_sha256']==sha(r['recovery']) and sha(r['final_path'])==r['final_sha256']
assert read(HERE/'CORRESPONDENCE_RESULTS_v1.json')['failed']==0
assert read(HERE/'PRESEAL_RESULTS_v1.json')['failed']==0
assert read(HERE/'wrapper_controls_v1/baseline/RESULTS_v1.json')['failed']==0
at=datetime.now(timezone.utc).isoformat()
artifacts=[]
for path in sorted(HERE.rglob('*')):
    assert not path.is_symlink(),path
    if path.is_file():artifacts.append(dict(path=str(path.relative_to(HERE)),bytes=path.stat().st_size,sha256=sha(path)))
manifest=dict(schema='focused-staged-correspondence-manifest-v1',created_utc=at,scope='Immutable staged canonical-envelope correspondence and exact recovery; no new scientific solver execution or delivery certification.',excludes=['MANIFEST_v1.json','RECEIPT_v1.json'],artifacts=artifacts)
(HERE/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
keys=['REPORT_v1.md','MANIFEST_v1.json','SOURCE_BINDINGS_INITIAL_v1.json','SOURCE_BINDINGS_v1.json','SOURCE_DISPOSITIONS_v1.json','CLAIM_DISPOSITIONS_v1.json','CORRESPONDENCE_PROTOCOL_v1.json','CORRESPONDENCE_RESULTS_v1.json','correspondence_v1.EXECUTION.json','ACCESS_HISTORY_v1.json','FAILURES_v1.md','COMMAND_INDEX_v1.json','COMMAND_INDEX_v2.json','check_correspondence_v1.py','check_wrapper_stubs_v1.py','wrapper_controls_v1/PROTOCOL_v1.json','wrapper_controls_v1/SUMMARY_v1.json','wrapper_controls_v1/baseline/RESULTS_v1.json','wrapper_controls_v1/omit_envelope_failures/execution/RESULTS_v1.json','wrapper_controls_v1/wrong_envelope_root/execution/RESULTS_v1.json','wrapper_controls_v1/hide_failure_exit/execution/RESULTS_v1.json','PRESEAL_RESULTS_v1.json','preseal_v1.EXECUTION.json','seal_v1.py','SEAL_COMMAND_v1.json']
bindings=[dict(path=n,bytes=(HERE/n).stat().st_size,sha256=sha(HERE/n)) for n in keys]
result=read(HERE/'CORRESPONDENCE_RESULTS_v1.json')
receipt=dict(schema='focused-staged-correspondence-receipt-v1',sealed_utc=at,scientific_author='/root',reviewer='/root/local_response_check',scope='Staged canonical-envelope source/code/output/profile/recovery correspondence. Previous science honestly reused; actual main-only synthetic wrapper tests. No formal audit, science rerun, empirical validation or committed/live delivery.',artifact_count=len(artifacts),direct_frozen_source_pair_count=len(sources),source_pair_count=len(dispositions),original_dispositions='SOURCE_DISPOSITIONS_v1.json',original_dispositions_json_pointer='/original_dispositions',bindings=bindings,staged_note_sha256='78ff317df690af56b9c3bf486ff44592c64245c37bdd94f4fac6b0ca07c6da6c',staged_runner_sha256='b6bd10550a0bd110cf66523484d15c27c92bd248fb8bb68357b8c2e14221a35a',metadata_correspondence_controls=[7677,0],wrapper_stub_controls=[115,0],final_identity_controls=[3810,0],actual_changed_wrapper_counts=[[112,3],[47,26],[111,4]],inspected_existing_primary=[488,0],inspected_existing_primary_damage_counts=[[467,21],[486,2],[487,1]],byte_identical_npz_count=36,byte_identical_sample_json_count=6,compared_npz_arrays=234,reused_seals=result['reused_seals'],required_corrections=[],fully_blind=False,science_rerun=False,new_canonical_installation_cache_archive_commit_verified=False,immutable_policy='Do not modify any sealed artifact. Any later correction, installation or delivery mapping must use a separate named unit retaining these identities.')
(HERE/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
for r in artifacts:assert sha(HERE/r['path'])==r['sha256']
for r in bindings:assert sha(HERE/r['path'])==r['sha256']
print(json.dumps(dict(artifact_count=len(artifacts),direct_pairs=len(sources),all_source_pairs=len(dispositions),report_sha256=sha(HERE/'REPORT_v1.md'),manifest_sha256=sha(HERE/'MANIFEST_v1.json'),receipt_sha256=sha(HERE/'RECEIPT_v1.json'),receipt=str(HERE/'RECEIPT_v1.json')),indent=2))
