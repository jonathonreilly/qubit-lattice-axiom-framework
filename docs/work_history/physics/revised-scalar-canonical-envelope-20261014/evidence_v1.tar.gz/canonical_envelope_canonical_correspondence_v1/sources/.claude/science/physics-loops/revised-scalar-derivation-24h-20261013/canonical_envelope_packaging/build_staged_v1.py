from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib

PK=Path(__file__).resolve().parent.parent
DEST=Path(__file__).resolve().parent
STAGE=DEST/'staged';STAGE.mkdir(exist_ok=False)
BODY=PK/'rolling_local_response/finite_body_excursion_v1'
ENV=PK/'rolling_local_response/compactness_canonical_envelope_v1'
NOTE='EXPONENTIAL_SCALAR_CANONICAL_ENVELOPE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='exponential_scalar_canonical_envelope_check.py'
PARENTS=['docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[BODY/'check_excursion_v4.py',BODY/'check_surface_v2.py',ENV/'check_envelope_v1.py']
maps=[{'run':'check_excursion','COMPARISON_SIGN':'FB_COMPARISON_SIGN','KINETIC_FACTOR':'FB_KINETIC_FACTOR','BOOTSTRAP_SIGN':'FB_BOOTSTRAP_SIGN'}, {'run':'check_surface','SPHERE_COEFFICIENT':'SF_SPHERE_COEFFICIENT','ENVELOPE_COEFFICIENT':'SF_ENVELOPE_COEFFICIENT','HESSIAN_CONNECTION_SIGN':'SF_HESSIAN_CONNECTION_SIGN'}, {'run':'check_envelope','REGULATOR_LINEAR':'CE_REGULATOR_LINEAR','REGULATOR_QUADRATIC':'CE_REGULATOR_QUADRATIC','INVERSE_SIGN':'CE_INVERSE_SIGN','UPPER_BASE_SIGN':'CE_UPPER_BASE_SIGN'}]
class Rename(ast.NodeTransformer):
    def __init__(self,m):self.m=m
    def visit_Name(self,n):n.id=self.m.get(n.id,n.id);return n
    def visit_FunctionDef(self,n):n.name=self.m.get(n.name,n.name);return self.generic_visit(n)
blocks=[];lineage=[]
for path,mapping in zip(sources,maps):
    selected=[x for x in ast.parse(path.read_text()).body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    tree=ast.fix_missing_locations(Rename(mapping).visit(ast.Module(body=selected,type_ignores=[])))
    blocks.append(ast.unparse(tree)+'\n');lineage.append(dict(path=str(path),sha256=sha(path),renames=mapping,selected_statement_types=['Import','ImportFrom','FunctionDef','Assign'],transformed_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
header='#!/usr/local/bin/python3\n"""Canonical scalar envelope with fresh held-body comparison pipeline."""\nfrom contextlib import redirect_stdout\nfrom tempfile import TemporaryDirectory\nimport io\nAUDIT_TIMEOUT_SEC=120\nAUDIT_INPUT_PATHS='+repr(['docs/'+NOTE]+PARENTS)+'\n'
footer='''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True);units={};streams={}
        for name,fn,dirname in [('excursion',check_excursion,'baseline_v4'),('surface',check_surface,'surface_baseline_v2'),('envelope',check_envelope,'envelope')]:
            captured=io.StringIO()
            with redirect_stdout(captured):
                if name=='excursion':failed=fn(root/dirname)
                elif name=='surface':failed=fn(root/'baseline_v4',root/dirname)
                else:failed=fn(root,root/dirname)
            result=json.loads((root/dirname/'RESULTS.json').read_text())
            assert failed==result['failed'];units[name]=result;streams[name]=captured.getvalue()
        return dict(passed=sum(z['passed'] for z in units.values()),failed=sum(z['failed'] for z in units.values()),units=units,unit_stdout=streams,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional canonical Hessian envelope and sufficient convexity. Recomputed exposed body controls are not independent observations or selected states.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-canonical-envelope-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='');return bool(result['failed'])
if __name__=='__main__':raise SystemExit(main())
'''
(STAGE/RUNNER).write_text(header+'\n'.join(blocks)+footer)
opening='''# A tighter canonical scalar envelope from the field excursion

Status: conditional support. Claim type: bounded_theorem.
Scientific author: /root.
Primary runner: `scripts/exponential_scalar_canonical_envelope_check.py`.

The finite-body bridge needs a controlled field interval and canonical Hessian,
not an assigned interior equilibrium. Re-expressing the supplied potential in
the conformal factor gives a sharper computable upper envelope and an improved
sufficient convexity criterion. These extend some checked parameter cases where
the earlier sufficient criterion was inconclusive; a failed sufficient test is
not an instability or multiplicity result.

The [supplied action](EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md),
[local normalization](EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md)
and [finite-body theorem](EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md)
are the complete canonical dependencies. Their fixed flat metric, held particle
source, zero infinity boundary and negative-branch restrictions persist. The
canonical scalar here is dchi=sqrt(K_uu)du along x=y=0. The action, scale,
material and realized environment are not derived by this refinement.

The complete personal derivation follows, with original filenames identifying
source history in the recovery archive.

'''
hand=ENV/'DERIVATION_v1.md';body='\n'.join('#'+line if line.startswith('#') else line for line in hand.read_text().splitlines())
closing='''

## Evidence and limits

The original refinement has96/0 controls:18 already exposed body comparisons
and6 prospectively specified mathematical endpoint cases. Four of those six
pass the new criterion while failing the old sufficient criterion. No new BVP
solutions at those six points and no measured physics test are claimed. The
force bound is a radial surface bound, not a lower bound at arbitrary distance.

The canonical runner recomputes the original excursion and surface controls
before supplying their fresh full outputs to the exact refinement body. Its
488 controls are220+172+96; repeated cases are not additional independent
evidence. Full profiles and exact input hashes are recoverable. Default temporary
paths are deleted after execution; recovery is by preserved bytes and hashes.

Independent direct-action checks give2075/0 with distinct parameter fixtures,
216 field points, endpoint sequences and six actual damaged programs. The
reviewer's initial tolerance-parser failure and parser-only correction are
preserved. No tolerance or physics fixture was relaxed. Four sampled cases
that fail a sufficient criterion still have positive sampled Hessians; this
does not imply convexity everywhere or stability outside the theorem's domain.

The original finite-body serialization, flux-resolution, mesh-budget, proof
decay and radial-scope repairs remain in the parent theorem's recovery archive.
The prior uniqueness review's aggregate-output exposure remains disclosed;
the new envelope mathematical check read no producer implementation or outputs.
Canonical correspondence is openly a source comparison, not a blind experiment.

The exact formulas remain conditional on0<k<1/3, nu>0 and LP<1. Fixed-k P->0
recovers the vacuum mass. The limit k->1/3 at fixed nonzero P is nonuniform:
the regulator convexity condition eventually fails. No uniform endpoint,
action selector, empirical confidence level, state or absolute scale follows.
The scalar form bound keeps source and metric fixed. Moving matter, full gravity,
nonlinear settling, actual body composition and observation likelihood remain open.

Recovery source: `docs/work_history/physics/revised-scalar-canonical-envelope-20261014/README.txt`.
'''
(STAGE/NOTE).write_text(opening+body+closing)
(DEST/'CANONICAL_LINEAGE_v1.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'code_sources':lineage,'hand':{'path':str(hand),'sha256':sha(hand)},'note_sha256':sha(STAGE/NOTE),'runner_sha256':sha(STAGE/RUNNER),'new_wrapper':'Fresh excursion -> surface -> envelope, full output propagation and aggregated failure.'},indent=2)+'\n')
print(json.dumps({'note':sha(STAGE/NOTE),'runner':sha(STAGE/RUNNER)}))
