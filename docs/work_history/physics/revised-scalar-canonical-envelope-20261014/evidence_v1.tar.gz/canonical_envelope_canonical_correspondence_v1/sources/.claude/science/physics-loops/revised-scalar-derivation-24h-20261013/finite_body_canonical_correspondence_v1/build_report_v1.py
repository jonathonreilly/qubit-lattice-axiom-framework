#!/usr/bin/env python3
"""Assemble correspondence narrative and complete snapshot dispositions, no science execution."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,hashlib
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go');PREFIX='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text());b=j(O/'SOURCE_BINDINGS_v2.json');rows=[]
for x in b['source_pairs']:
 role=x['role'];rp=x['original_repo_path'];explanation='Preserved byte-exact evidence and current source identity; no source modification or authority change.'
 if '/staged/' in rp:
  role='Final staged canonical source';explanation='Fully reviewed final staged source; current path remains staging. Canonical installation/cache/delivery is a separately required later identity check.'
 elif any(t in rp for t in ['/independent_v1/','/independent_surface_v1/','/independent_uniqueness_v1/']):
  role='Reused independent proof/control seal or constituent';explanation='Preserved exact earlier artifact; its sealed scope, source qualification and failures are reused without rerun.'
 elif '/damages' in rp or 'mutation' in rp:
  role='Actual changed-program evidence';explanation='Deliberately incorrect program, complete execution/output or profile. Retained as rejection evidence, not as an accepted scientific formula.'
 elif any(t in rp for t in ['baseline_v1/','baseline_v2/','baseline_v3/','RUN_v1','RUN_v2','RUN_v3']):
  role='Historical execution/version evidence';explanation='Preserved original success/failure history. No failed or incomplete run is relabeled as final clean evidence.'
 row=dict(original_path=rp,original_sha256=x['sha256'],disposition=explanation,recovery=str(O/x['snapshot_path']),recovery_sha256=x['sha256'],final_path=rp,final_sha256=x['sha256'],bytes=x['bytes'],role=role,current_final_is_original=True)
 if '/staged/' in rp and rp.endswith('.md'):row['intended_delivery_path']='docs/'+Path(rp).name;row['delivery_status']='not yet verified or installed by this review'
 if '/staged/' in rp and rp.endswith('.py'):row['intended_delivery_path']='scripts/'+Path(rp).name;row['delivery_status']='not yet verified or installed by this review'
 rows.append(row)
(O/'SOURCE_DISPOSITIONS_v1.json').write_text(json.dumps(dict(scope='All 790 frozen source/recovery pairs. Final paths denote current reviewed bytes, not future delivery. Relative original/final paths are relative to repository_root.',repository_root=str(W),original_dispositions=rows),indent=2)+'\n')
groups=Counter(r['role'] for r in rows)
(O/'SOURCE_INVENTORY_v1.json').write_text(json.dumps(dict(source_pair_count=len(rows),source_bytes=sum(x['bytes'] for x in b['source_pairs']),roles=dict(groups),complete_snapshot_binding_file='SOURCE_BINDINGS_v2.json',original_binding_file_preserved='SOURCE_BINDINGS_v1.json',stage_only=True,excluded=['Unrelated compactness_canonical_envelope_v1 research','Any live canonical installation, cache, archive, Git/PR or audit authority'],scientific_sources=[dict(path=PREFIX+'rolling_local_response/finite_body_excursion_v1/'+f,sha256=sha(O/'snapshots'/PREFIX/'rolling_local_response/finite_body_excursion_v1'/f)) for f in ['DERIVATION_v2.md','SURFACE_FORCE_DERIVATION_v2.md','UNIQUENESS_DERIVATION_v2.md','check_excursion_v4.py','check_surface_v2.py','check_uniqueness_v1.py']]),indent=2)+'\n')
commands=[]
for f in ['CORRESPONDENCE_EXECUTION_v1.json','UNIQUENESS_REUSE_EXECUTION_v1.json']:
 commands.append(dict(record=f,record_sha256=sha(O/f),**j(O/f)))
for r in j(O/'wrapper_v1/SUMMARY_v1.json'):
 f='wrapper_v1/'+r['name']+'_EXECUTION_v1.json';commands.append(dict(record=f,record_sha256=sha(O/f),**j(O/f)))
(O/'COMMAND_INDEX_v1.json').write_text(json.dumps(dict(scope='Every new checker execution, exact argv/cwd/timing/source hash and real exit status. Source reads and byte copies are separately described in access records; no claim of science rerun.',executions=commands),indent=2)+'\n')
(O/'ACCESS_HISTORY_v2.json').write_text(json.dumps(dict(created_utc=datetime.now(timezone.utc).isoformat(),prior_record=dict(path='ACCESS_HISTORY_v1.json',sha256=sha(O/'ACCESS_HISTORY_v1.json')),scope='Authorized source/code/output correspondence, explicitly not a blind mathematics check',full_reports_read=['independent_v1/REPORT_v1.md','independent_surface_v1/REPORT_v1.md','independent_uniqueness_v1/REPORT_v1.md'],full_note_and_three_hand_bodies_read=True,all_three_original_final_runners_and_staged_runner_read=True,all_complete_saved_scientific_output_fields_compared=True,all_54_npz_bytes_and_arrays_compared=True,uniqueness_arrival='UNIQUENESS_ARRIVAL_v1.json',uniqueness_aggregate_exposure_preserved=True,new_science_execution=False,wrapper_execution='Actual main AST only, labeled unit stubs; three actual altered wrapper sources.',network_access=False,git_access=False,source_writes=False,write_root=str(O),historical_access_limit='Saved literature context/access records and PDF identity preserved. No new primary-paper derivation or independent figure-layout inspection was performed here.'),indent=2)+'\n')
(O/'FAILURES_v1.md').write_text('''# Preserved failures and qualifications

This is a correspondence record. It does not erase or rerun the earlier science failures.

1. Excursion implementation v1 failed serializing a NumPy boolean after producing 18 profiles. No complete result JSON exists and no aggregate count is inferred. Its stderr, command, implementation and all profiles remain frozen.
2. The bool-only v2 repair produced 216/4. Four flux-resolution checks failed (cases 0, 1, 6, 12). The stricter-tolerance v3 attempt produced 219/1 because case 15 reached the node budget. V4 rescaled the unknown using its analytic linear-field normalization, restored the original tolerance and produced 220/0. Exact diffs show unchanged physical equations, boundaries, case grid and acceptance predicates. Every failed row, old source and profile remains recoverable.
3. Surface v1 likewise failed NumPy boolean serialization after its 18 profiles; a bool-only repair produced 172/0. There is no invented clean v1 aggregate.
4. The first excursion hand proof omitted the decay argument after the variational limit. V2 adds the bounded-forcing/uniform-continuity plus L2 argument. Its independent review also preserved a pre-execution draft error involving two unrelated upper bounds. Those records remain untouched.
5. Surface v2 makes radial negative-branch scope explicit. The uniqueness result supplies radial symmetry only under its additional criterion. The earlier surface receipt remains frozen rather than silently rebound to v2.
6. The uniqueness independent review accidentally exposed four producer metadata/stream files, including aggregate 98/0 and 18 cases, before its independent algebra. The exact files, incident record and explicit no-complete-blindness qualification are retained. Its independent method is reused with that qualification.
7. The parent's staged-output path comparison initially compared an absolute fresh path with a relative packaging path and raised AssertionError. Resolving the root repaired this metadata comparison, with no changed science or rerun. The failure record is preserved.
8. Three actual complete staged damaged programs produced 487/3, 486/4 and 486/4 across all 490 controls. They are rejection evidence, not new clean baselines. All failed rows, altered sources, diffs, commands, streams, results and freshly generated profiles remain frozen.
9. This review's first file-list display was truncated. The complete list was saved in INITIAL_INVENTORY_v1.json; the closure is based on the explicit hashed snapshot inventory rather than that display.
10. The new correspondence checker returned 1524/0, the later uniqueness-seal verifier returned 266/0 and actual-wrapper stub controls returned 141/0. No unexpected computation failure occurred in these new executions. The first correspondence result honestly retains pending_uniqueness=true; the separate later result resolves it without overwriting v1.
11. Three actual altered wrapper sources were executed only at main, with labeled synthetic stubs. They returned 138/3, 133/8 and 137/4 (exit 1). Their mathematical functions were not executed. Expected input/assertion/stub exceptions are recorded per case and are successful defensive-control witnesses, not hidden baseline failures.
12. Default TemporaryDirectory paths are historical after normal cleanup. Stage --profiles output is persistent and recoverable. A later cache must be bound by exact source/output hashes to preserved profiles; this stage review does not assert future temporary paths remain live.

All earlier receipts are unchanged. No formal audit, empirical test, state selection, canonical installation, cache freshness, archive, commit or landing claim is made.
''')
report='''# Finite-body staged canonical correspondence

The frozen staged note and runner faithfully preserve the checked excursion, radial surface-force and sufficient uniqueness/scalar-stability results. No required source correction was identified. This is a source-bound packaging check: the author remains /root, the earlier mathematics is reused by exact identity, and no scientific solver was rerun. The result is limited to the staged bytes below; a later canonical installation, live cache, recovery archive and delivery need their own identity checks.

## Frozen sources and complete recovery

The staged note is `finite_body_packaging/staged/EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md`, SHA256 `819c683b881066c736888ec51d735b04afab6d25a70a4515170f71b74cf2fd32` (23572 bytes). The runner is `finite_body_packaging/staged/exponential_scalar_finite_body_check.py`, SHA256 `3d31bb527923d607c08c7607bab8f3ac32a6c20e423573045c5a906d35dfcd64` (26191 bytes). Its eventual `docs/` and `scripts/` destinations are prospective, not certified live paths.

All paths beginning with a campaign directory in this report are relative to the existing revised-scalar campaign pack. The complete source and recovery inventory is `SOURCE_BINDINGS_v2.json`: 790 byte-exact live/snapshot pairs. The initial 694-pair v1 inventory is preserved; v2 adds only the 96 files in the newly completed uniqueness seal. `SOURCE_DISPOSITIONS_v1.json` contains every original/current-final/recovery path, byte count, hash, role and disposition. It retains old errors and deliberate damage programs as such. Current-final means the same reviewed source path; it does not silently claim installation at a canonical destination.

The entire note, all three hand proofs, the original final programs, staged program, full output tables, numerical repair diffs and all three independent reports were read. The three full hand bodies occur once and in order, changed only by adding one heading level. All imports, constants, helper functions and checker bodies are AST-identical after the declared renames. Only each old standalone CLI guard is excluded; the new wrapper follows the three ports. No mathematical expression, grid, physical equation, acceptance predicate or tolerance changed through this port.

| Hand body / producer | Hand source SHA256 | Final producer SHA256 |
| --- | --- | --- |
| Excursion `DERIVATION_v2.md` / `check_excursion_v4.py` | `5b731ef2b77d2282f8b84384095192cca748d8d454d6387a3e8b50349b93c0d5` | `66feee39c6e8cdee957576296520edac8eda369f8db6d148d609dbfe6c35bcee` |
| Surface `SURFACE_FORCE_DERIVATION_v2.md` / `check_surface_v2.py` | `269e10f9778fbb34a62fc3a3a2511516ca92ec30d5b45a002247611000f392b5` | `a9a758298a86787550dab7ee951208cc81f07f0a40b876dde6f025be8abb1f4a` |
| Uniqueness `UNIQUENESS_DERIVATION_v2.md` / `check_uniqueness_v1.py` | `ceea5fc3f6d4630e101ed279218c7b66ff2b9da8a751b6eb461e6707bb4a43ae` | `9a832af55cb01fb87a6d1bf79ce36abd86c60a9525e22f0c4c74d4481a64bcaf` |

The normalized AST digests are respectively `d12ad1ff0c3929dda2101c1bb3e3419d0c4f029b9e19aab791507c105eeb6cfd`, `da679b2e68a9a95f121e6fe0097c85bbe56dfdc56b5d834474757ad15acb6855`, and `dfdc368157b64f0d30eb952ee4a124e13d809e5a0be235590c725fa911d53afe`. The independent correspondence checker verifies the complete concatenated module region, not merely matching function names.

The runner declares the future finite-body note and the existing full-action, local-response and environment notes as its four inputs, with a 120-second budget. The three existing premise documents are frozen in the inventory. The supplied action is bound at `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`. The prospective note input is correctly a future canonical path; this stage does not provide a live declared-input fingerprint.

## Scope preserved from the checked action and proofs

This is the consistent x=y=0 scalar channel in a fixed flat metric with a prescribed nonnegative compact source, fixed particle number per local Einstein proper volume and zero canonical field at spatial infinity. The canonical field here is the integral of sqrt(K_uu) du along that channel; it is explicitly distinguished from the earlier confinement note's bounded-coordinate chi. The matter density convention is rhoStar=m_J n_E and rho_J=rhoStar/A^3. The action's factors give c=rhoStar/(2Q), Y=Hv^2 U and Delta chi=Y_chi+c A_chi. The static boundary/flat approximation does not claim a global Minkowski vacuum for Hv>0 or a dynamically realized body.

The excursion body preserves its negative-branch Newton comparison, compactness P=sup V with -Delta V=c, and the sharper bootstrap under LP<1, L=1+k. In particular W<=sqrt(k)P/(1-LP), q<=k/(1-LP)^2 and -ln A<=kP(1-LP/2)/(1-LP)^2 are necessary bounds in the stated solution class. The uniform-sphere conversion P=3Gvac MStar/(2R) uses a held Einstein source mass and Einstein radius. It is not a conversion to measured Jordan gravitational mass or an empirical screening claim. The corrected existence proof explicitly obtains uniform continuity from bounded elliptic forcing and combines it with L2 to prove decay after the variational limit; H1 alone is not treated as sufficient.

The surface body explicitly assumes a radial negative-branch solution for a uniform held sphere. Its canonical Hessian envelope, source integral and 2/5 coefficient give the stated nonnegative lower bracket and upper bracket. Multiplying by a positive lower coupling only when the flux bracket is positive is essential; a negative bracket becomes zero. Exterior monotonicity gives a nonnegative decreasing force numerator, not a positive lower bound at arbitrary distance. Eleven of the 18 illustrative surface brackets are informative; the others say only zero. The preceding surface-v1 seal is not retroactively upgraded to infer radiality solely from spherical source density.

The uniqueness body imposes the additional convex interval condition 2 alpha Umax<=ln 2 and LP<1. Its mean-value/Kato comparison uses the lower matter Hessian bound -L and the decay boundary, giving uniqueness only in the bounded negative-branch class. Rotational symmetry follows by applying uniqueness to rotated solutions. The source-perturbation bound keeps 1-LP1 in its denominator and needs a common proved convex interval. The appended v2 ground-state form supplies the fixed-source scalar operator lower bound (1-LP)||grad f||^2+mMin^2||f||^2. This excludes growing finite-energy linear scalar normal modes in that fixed problem; it does not show damping, nonlinear attraction, moving-fluid stability or metric stability. The sampled numerical minimum is explicitly not a certified eigenvalue.

All three independent reports support those precise boundaries. No body charge, stationary-density root or shell factor has been inserted as an observed input. The optional newer compactness-envelope work was excluded. The supplied literature context remains a comparison of mechanisms; its PDF and access history are preserved by identity, without a new paper-derived theorem or empirical validation in this review.

## Reused independent seals and qualifications

The earlier reviews were not rerun or relabeled as new science. All of their manifest entries, receipt bindings and original/recovery/final source pairs were verified, and all three reports were read in full.

| Review | Artifacts / source pairs / receipt bindings | Preserved controls | Receipt SHA256 |
| --- | ---: | --- | --- |
| Excursion `independent_v1` | 72 / 6 / 12 | 598/0 plus 22/0 affected-v2 controls; five actual damage programs | `f31cb02003bebee1251a963fdb4b76151c841dd7a023cc4604db5803cb33cb43` |
| Surface `independent_surface_v1` | 77 / 9 / 11 | 1735/0; seven actual damage programs | `2944bb5aeb74440ba1e5954e2e2f4af4275c0c287d94c76f62f57d3812cd0b71` |
| Uniqueness `independent_uniqueness_v1` | 94 / 24 / 12 | 641/0; seven actual damage programs | `aec6987f5aee830451a4118e0b874a3e7f03ef9847a2e8e6bbd9f06350f029c8` |

The excursion report/manifest hashes are `7755ad3771978c31f6dab6868613b1e832003f09ca344f7284e429a243b1832d` / `27542900da607524f8e87f39fc2d4116c3189ca99a042027004ebb1fefea733d`. Surface report/manifest: `7ed51b3c0632b8cfb4d5fd2628912e297066e036c2ff000638d154f144ef5a16` / `3808281356c2bf82c7b16fa423aaeb430e212f54694d2c452a457c437ec9b2ca`. Uniqueness report/manifest: `3f2ffbd250bf96cc85e73fee68863989c732cc2b4f65f2fe5259515de422aada` / `4f93b7405e2c0c7b08649c27a9a8372348052ba9a6e039423603aac981f72020`.

The uniqueness review is independent in method but not fully blind: an early prefix enumeration exposed four metadata/stream files and aggregate 98/0 before its algebra. Its explicit exposure failure and exact bytes are retained. The canonical prose correctly requires that disclosure. This correspondence is itself openly a producer-source/output comparison and makes no blindness claim.

Surface v2 changes only its opening radial negative-branch qualification. The exact v1-to-v2 text/diff was checked here and separately confirmed in the later uniqueness report. Its equations and computations are unchanged, and the original surface receipt remains immutable. Uniqueness v2 retains the complete v1 proof and appends the ground-form stability section.

## Complete executions, rows and profiles

The staged run exited zero and produced 490/0 = 220 excursion + 172 surface + 98 uniqueness. Its complete stdout is byte-identical to the saved full JSON; stderr is empty. The run record binds the actual staged checker hash, argument paths, timestamps and duration. This is an inspected existing execution, not a new reviewer science run.

For each unit every scientific field and every row matches its final original baseline. Only the actual checker SHA and, for downstream units, regenerated source_bindings differ. These fields were not simply ignored: the checker SHA was separately matched to the actual executable, and every source binding was resolved and hashed. The surface has 19 fresh inputs (new excursion result plus 18 profile NPZs); uniqueness has the new excursion result as its one input. Both use the new excursion pipeline, not old scratch results or each other's tables. The new excursion result SHA is `932584d6f3ff387e47e5ca86d6a680016fb164aa1a0108d6e79c36ea18f4c5e6`.

All 54 staged NPZ files are byte-identical to their corresponding final original files: 18 excursion, 18 surface-Hessian and 18 uniqueness-convexity profiles. Every archive key, array shape, dtype and value was also compared using allow_pickle=False. Full records of the 270 arrays are in CORRESPONDENCE_RESULTS_v1.json. The entire 18-case tables, full check rows, counts, captured summaries, fresh input identities and all profile bytes were compared. This is stronger than comparing aggregates, but remains correspondence rather than a fresh discretization or continuum error certificate.

The finite grid is k in {0.01,0.1,0.3}, nu=0.0001, source surface compactness in {0.0001,0.01}, and vacuum mass times radius in {0.1,1,10}, with R as numerical length unit. Finite-domain Dirichlet and enlarged-domain checks approximate infinity. All 18 satisfy the sufficient uniqueness criterion, but finite samples do not replace the analytic interval argument or cover arbitrary bodies, ranges or backgrounds.

The parent preserved three actual complete altered staged programs and their executions. Each contains exactly its declared source replacement, has a matching exact diff and actual source hash, runs all 490 controls, exits 1 and supplies the intended mathematical failed witness. All downstream bindings and 54 fresh profiles for each damage are also preserved and verified.

| Actual staged alteration | Passed / failed | Required failed witness |
| --- | ---: | --- |
| Reverse bootstrap sign | 487 / 3 | bootstrap_supremum_solution |
| Halve uniform-sphere integral coefficient | 486 / 4 | sphere_source_integral |
| Reverse ground-state sign | 486 / 4 | ground_state_integration_by_parts |

The failed bootstrap propagates through the aggregate even though the uniqueness subunit can itself pass. No claim is made that every downstream subunit independently rejects every possible upstream defect. The full failed-row lists are retained.

## Wrapper checks and temporary-path limitation

The new reviewer correspondence program returned 1524/0 before uniqueness was sealed. Its original output truthfully retains that pending flag. The separately named uniqueness reuse check then returned 266/0 and resolves that dependency without rewriting the earlier record.

The actual main AST was extracted and run with clearly labeled synthetic unit stubs; no symbolic or BVP science body executed. Eleven scenarios cover clean success, a failure in each subunit, multiple failures, temporary-directory cleanup, existing profile/output paths, return/result count mismatch, a thrown subunit exception and malformed result JSON. They test complete nested payloads, captured streams, aggregate counts, failure exit, fresh excursion routing and self-hash. These controls returned 141/0.

Three actual altered full wrapper source files were then tested through the same main-only harness. Omitting excursion failures gave 138/3; routing uniqueness to surface output gave 133/8; hiding the failure exit gave 137/4. All exited 1 with the intended wrapper witnesses. These are actual altered-wrapper controls with synthetic data, not 490-row science reruns. All sources, exact diffs, commands, expected exceptions, synthetic outputs and failed assertions are retained.

With --profiles, the stage retains the entire fresh pipeline. The default TemporaryDirectory path is removed on normal completion; any source_bindings naming that directory are historical afterwards. The wrapper controls demonstrate this behavior. A later live cache must be linked by exact source and result/profile hashes to persistent recoveries, rather than claiming temporary paths are still present. The staged recovery link and intended canonical paths are future delivery promises; no recovery archive or live cache was available or certified within this unit.

## Failure lineage and conclusion

The full failure ledger is FAILURES_v1.md. The initial excursion and surface NumPy-boolean serialization failures are retained without invented aggregate counts. Excursion v2's 216/4 flux failures, v3's 219/1 node-budget failure and the v4 unknown-rescaling repair are preserved with all versions/diffs/profiles. The bool-only repairs and unchanged final acceptance predicates were checked exactly. The original hand-proof decay gap, independent draft issue, radial clarification and uniqueness metadata exposure remain visible. The parent's path-comparison AssertionError was a resolved absolute/relative metadata mismatch, not changed science. This review's first file-list display was truncated; the complete saved inventory, not the truncated display, defines closure.

No source correction was required by this staged correspondence. All new writes are confined to this review folder. Earlier seals, author sources, staging, Git, runtime, settings, PR and audit state were not changed. This provides recoverable source correspondence and wrapper evidence for a conditional flat static held-source result. It does not establish observed calibration, a realized environmental state, full gravitational/body matching, nonlinear relaxation, a general Solar-System exclusion or landing authority.
'''
(O/'REPORT_v1.md').write_text(report)
print(json.dumps(dict(source_pairs=len(rows),roles=dict(groups),report_bytes=(O/'REPORT_v1.md').stat().st_size,report_sha256=sha(O/'REPORT_v1.md')),indent=2))
