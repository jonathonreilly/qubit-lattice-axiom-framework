#!/usr/bin/env python3
"""Frozen source, output, profile and failure correspondence; no proof body executes."""
from pathlib import Path
from datetime import datetime,timezone
import ast,copy,difflib,hashlib,json
import numpy as np
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go');PREFIX='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/'
S=O/'snapshots'/PREFIX;P=S/'finite_body_packaging';U=S/'rolling_local_response/finite_body_excursion_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text());dump=lambda x:ast.dump(x,include_attributes=False)
rows=[];details={}
def ck(n,v,d=None):rows.append(dict(name=n,passed=bool(v),detail=d))
def ref(p):return dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def recovered_absolute(path):return O/'snapshots'/Path(path).relative_to(W)
source_pairs=j(O/'SOURCE_BINDINGS_v1.json')['source_pairs']
for x in source_pairs:
 p=Path(x['original_path']);q=O/x['snapshot_path'];ck('input:'+x['original_repo_path'],p.read_bytes()==q.read_bytes() and sha(q)==x['sha256'] and q.stat().st_size==x['bytes'])
seals=[]
for name,expected in [('independent_v1',72),('independent_surface_v1',77)]:
 root=U/name;r=j(root/'RECEIPT_v1.json');m=j(root/'MANIFEST_v1.json');d=j(root/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
 ck(name+'.artifact_count',len(m['artifacts'])==r['artifact_count']==expected)
 for x in m['artifacts']:
  p=root/x['path'];ck(name+'.artifact:'+x['path'],sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
 for x in r['bindings']:ck(name+'.receipt_binding:'+x['path'],sha(root/x['path'])==x['sha256'])
 ck(name+'.source_pair_count',len(d)==r['source_pair_count'])
 for x in d:
  orig=recovered_absolute(x['original_path']);rec=recovered_absolute(x['recovery']);fin=recovered_absolute(x['final_path'])
  ck(name+'.source_pair:'+Path(x['original_path']).name,sha(orig)==x['original_sha256']==sha(rec)==x['recovery_sha256'] and sha(fin)==x['final_sha256'])
 seals.append(dict(name=name,report=ref(root/'REPORT_v1.md'),manifest=ref(root/'MANIFEST_v1.json'),receipt=ref(root/'RECEIPT_v1.json'),artifacts=expected,source_pairs=len(d),receipt_bindings=len(r['bindings']),science_rerun=False))
details['reused_seals']=seals;details['pending_uniqueness_seal']=True
lineage=j(P/'CANONICAL_LINEAGE_v1.json');note=P/'staged'/lineage['canonical_note']['path'];runner=P/'staged'/lineage['canonical_runner']['path'];text=note.read_text();tree=ast.parse(runner.read_text())
ck('note_frozen_hash',sha(note)==lineage['canonical_note']['sha256']=='819c683b881066c736888ec51d735b04afab6d25a70a4515170f71b74cf2fd32')
ck('runner_frozen_hash',sha(runner)==lineage['canonical_runner']['sha256']=='3d31bb527923d607c08c7607bab8f3ac32a6c20e423573045c5a906d35dfcd64')
parts=[]
for x in lineage['hand_sources']:
 p=recovered_absolute(x['path']);body='\n'.join('#'+l if l.startswith('#') else l for l in p.read_text().splitlines());ck('hand_whole_body:'+p.name,text.count(body)==1 and sha(p)==x['sha256']);parts.append(body)
ck('three_hand_bodies_order_and_gaps', '\n\n'.join(parts) in text)
joined='\n\n'.join(parts);start=text.index(joined);(O/'NOTE_PREFIX_v1.txt').write_text(text[:start]);(O/'NOTE_SUFFIX_v1.txt').write_text(text[start+len(joined):])
expected=[];asts=[]
for x in lineage['scientific_sources']:
 p=recovered_absolute(x['path']);t=ast.parse(p.read_text());kept=[];excluded=[]
 for n in t.body:
  if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef)):
   n=copy.deepcopy(n)
   for child in ast.walk(n):
    if isinstance(child,ast.Name):child.id=x['renames'].get(child.id,child.id)
    elif isinstance(child,ast.FunctionDef):child.name=x['renames'].get(child.name,child.name)
   kept.append(n)
  else:excluded.append(n)
 ck('excluded_only_main_guard:'+p.name,all(isinstance(n,ast.If) and dump(n.test)==dump(ast.parse("__name__=='__main__'",mode='eval').body) for n in excluded))
 ck('source_hash:'+p.name,sha(p)==x['sha256'])
 digest=hashlib.sha256(dump(ast.Module(body=kept,type_ignores=[])).encode()).hexdigest();ck('port_ast:'+p.name,digest==x['transformed_ast_sha256'])
 target=x['renames']['run'];actual=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==target)
 ck('whole_function_ast:'+target,dump(actual)==dump(next(n for n in kept if isinstance(n,ast.FunctionDef) and n.name==target)))
 expected+=kept;asts.append(dict(source=ref(p),target=target,renames=x['renames'],ast_sha256=digest,kept_nodes=len(kept)))
ck('all_top_level_ast_ports_in_order',dump(ast.Module(body=tree.body[6:-2],type_ignores=[]))==dump(ast.Module(body=expected,type_ignores=[])))
ck('only_main_and_guard_after_ports',isinstance(tree.body[-2],ast.FunctionDef) and tree.body[-2].name=='main' and isinstance(tree.body[-1],ast.If))
inputs=ast.literal_eval(tree.body[5].value);ck('four_declared_inputs',len(inputs)==4 and inputs[0]=='docs/'+note.name)
ck('timeout_120',ast.literal_eval(tree.body[4].value)==120)
for p in inputs[1:]:ck('canonical_input_snapshot:'+p,(O/'snapshots'/p).is_file())
details['ast_ports']=asts;details['declared_inputs']=inputs
# Source clarification correspondence and complete saved diff bodies.
diffs=[('DERIVATION_v1.md','DERIVATION_v2.md','DERIVATION_v1_to_v2.diff'),('SURFACE_FORCE_DERIVATION_v1.md','SURFACE_FORCE_DERIVATION_v2.md','SURFACE_FORCE_v1_v2.diff'),('UNIQUENESS_DERIVATION_v1.md','UNIQUENESS_DERIVATION_v2.md','UNIQUENESS_v1_v2.diff'),('check_excursion_v1.py','check_excursion_v2.py','check_excursion_v1_to_v2.diff'),('check_excursion_v2.py','check_excursion_v3.py','check_excursion_v2_to_v3.diff'),('check_excursion_v3.py','check_excursion_v4.py','check_excursion_v3_to_v4.diff'),('check_surface_v1.py','check_surface_v2.py','SURFACE_v1_v2.diff')]
for a,b,d in diffs:
 exact=''.join(difflib.unified_diff((U/a).read_text().splitlines(True),(U/b).read_text().splitlines(True),fromfile=a,tofile=b));ck('full_diff:'+d,exact==(U/d).read_text())
surface1=(U/'SURFACE_FORCE_DERIVATION_v1.md').read_text();surface2=(U/'SURFACE_FORCE_DERIVATION_v2.md').read_text()
old='This extension concerns a spherical, uniform held rhoStar of radius R.';new='This extension concerns a radial negative-branch solution for a spherical, uniform held rhoStar of radius R.'
ck('surface_radial_only_premise_clarification',surface1.count(old)==1 and surface1.replace(old,new)==surface2)
ck('surface_v1_independent_snapshot_binding',(U/'independent_surface_v1/sources/SURFACE_FORCE_DERIVATION_v1.md').read_bytes()==(U/'SURFACE_FORCE_DERIVATION_v1.md').read_bytes())
ck('excursion_v2_independent_snapshot_binding',(U/'independent_v1/affected_v2/DERIVATION_v2.md').read_bytes()==(U/'DERIVATION_v2.md').read_bytes())
# Every saved science field is compared; provenance differences get separate verification.
stage=j(P/'STAGED_RESULTS_v1.json');execution=j(P/'STAGED_RUN_v1.json');profiles=P/'staged_profiles_v1'
ck('stage_490_0',(stage['passed'],stage['failed'])==(490,0))
ck('stage_source_execution_identity',execution['exit_code']==0 and execution['runner_sha256']==stage['checker_sha256']==sha(runner))
ck('stage_full_stdout',(P/'STAGED_RUN_v1.stdout').read_bytes()==(P/'STAGED_RESULTS_v1.json').read_bytes())
ck('stage_empty_stderr',(P/'STAGED_RUN_v1.stderr').read_bytes()==b'')
origins={'excursion':U/'baseline_v4','surface':U/'surface_baseline_v2','uniqueness':U/'uniqueness_baseline_v1'};totals={'excursion':220,'surface':172,'uniqueness':98};output=[];profile_records=[]
for name,origin in origins.items():
 unit=stage['units'][name];old=j(origin/'RESULTS.json');ignore={'checker_sha256'}|({'source_bindings'} if name!='excursion' else set())
 ck('full_scientific_json:'+name,{k:v for k,v in unit.items() if k not in ignore}=={k:v for k,v in old.items() if k not in ignore})
 ck('complete_unit_result_file:'+name,j(profiles/name/'RESULTS.json')==unit)
 ck('unit_count:'+name,len(unit['checks'])==unit['passed']+unit['failed']==totals[name] and unit['failed']==0 and all(x['passed'] for x in unit['checks']))
 ck('unit_self_hash:'+name,unit['checker_sha256']==sha(runner))
 ck('all_18_cases:'+name,len(unit['cases'])==18 and [x['index'] for x in unit['cases']]==list(range(18)))
 ck('unique_check_names:'+name,len({x['name'] for x in unit['checks']})==len(unit['checks']))
 summary=json.loads(stage['unit_stdout'][name]);ck('captured_unit_stdout:'+name,summary['passed']==unit['passed'] and summary['failed']==unit['failed'] and summary['cases']==18 and summary['failed_checks']==[])
 newbindings=unit.get('source_bindings',[]);oldbindings=old.get('source_bindings',[])
 ck('source_binding_count:'+name,len(newbindings)==len(oldbindings)==({'excursion':0,'surface':19,'uniqueness':1}[name]))
 binding_records=[]
 for i,x in enumerate(newbindings):
  target=recovered_absolute(x['path']);oldtarget=recovered_absolute(oldbindings[i]['path'])
  ck('fresh_binding_hash:'+name+':'+str(i),target.is_file() and sha(target)==x['sha256'])
  ck('fresh_binding_path:'+name+':'+str(i),target.parent==profiles/'excursion' and target.name==oldtarget.name)
  ck('original_binding_hash:'+name+':'+str(i),sha(oldtarget)==oldbindings[i]['sha256'])
  if target.suffix=='.npz':ck('binding_npz_original_byte_identity:'+name+':'+str(i),target.read_bytes()==oldtarget.read_bytes())
  else:ck('binding_result_science_identity:'+name,{k:v for k,v in j(target).items() if k!='checker_sha256'}=={k:v for k,v in j(oldtarget).items() if k!='checker_sha256'})
  binding_records.append(dict(fresh=x,original=oldbindings[i],recovery=ref(target)))
 newnpz=sorted((profiles/name).glob('*.npz'));oldnpz=sorted(origin.glob('*.npz'));ck('18_profile_names:'+name,len(newnpz)==len(oldnpz)==18 and [p.name for p in newnpz]==[p.name for p in oldnpz])
 for p,q in zip(newnpz,oldnpz):
  ck('npz_bytes:'+name+':'+p.name,p.read_bytes()==q.read_bytes())
  arrays=[]
  with np.load(p,allow_pickle=False) as x, np.load(q,allow_pickle=False) as y:
   ck('npz_keys:'+name+':'+p.name,x.files==y.files)
   for key in x.files:
    aa=x[key];bb=y[key];ck('npz_array:'+name+':'+p.name+':'+key,aa.shape==bb.shape and aa.dtype==bb.dtype and np.array_equal(aa,bb,equal_nan=True));arrays.append(dict(name=key,shape=list(aa.shape),dtype=str(aa.dtype),size=int(aa.size)))
  profile_records.append(dict(unit=name,name=p.name,original=ref(q),staged=ref(p),arrays=arrays))
 output.append(dict(unit=name,original=ref(origin/'RESULTS.json'),scientific_keys=[k for k in unit if k not in ignore],excluded_then_separately_verified=sorted(ignore),fresh_bindings=binding_records,counts=totals[name]))
ck('total_profile_count',len(profile_records)==54)
ck('eleven_informative_surface_bounds',sum(x['lower_informative'] for x in stage['units']['surface']['cases'])==11)
ck('all_uniqueness_criteria_met',all(x['criterion_met'] for x in stage['units']['uniqueness']['cases']))
details['complete_output_comparison']=output;details['profiles']=profile_records
# Failure histories: preserve unavailable counts after serialization failures.
history=[]
for version,counts in [('v1',None),('v2',(216,4)),('v3',(219,1)),('v4',(220,0))]:
 root=U/('baseline_'+version);result=root/'RESULTS.json';run=j(U/('RUN_'+version+'.json'));code=U/('check_excursion_'+version+'.py')
 ck('history_18_profiles:'+version,len(list(root.glob('*.npz')))==18)
 if counts is None:
  ck('initial_serialization_no_result',not result.exists() and 'not JSON serializable' in (U/'RUN_v1.stderr').read_text())
  history.append(dict(version=version,complete_counts=None,reason='Serialization failed before result write',run=run,stderr=ref(U/'RUN_v1.stderr')))
 else:
  data=j(result);ck('history_counts:'+version,(data['passed'],data['failed'])==counts and len(data['checks'])==220)
  ck('history_checker_hash:'+version,data['checker_sha256']==sha(code))
  ck('history_stdout_counts:'+version,(j(U/('RUN_'+version+'.stdout'))['passed'],j(U/('RUN_'+version+'.stdout'))['failed'])==counts)
  history.append(dict(version=version,passed=data['passed'],failed=data['failed'],all_failed_rows=[x for x in data['checks'] if not x['passed']],result=ref(result),run=run))
ck('excursion_bool_only_repair',(U/'check_excursion_v1.py').read_text().replace('violates_necessary_body_bound=disp>wbound+2e-8','violates_necessary_body_bound=bool(disp>wbound+2e-8)')==(U/'check_excursion_v2.py').read_text())
ck('resolution_tolerance_only_repair',(U/'check_excursion_v2.py').read_text().replace('tol=1e-8,max_nodes=20000','tol=1e-11,max_nodes=20000')==(U/'check_excursion_v3.py').read_text())
ck('surface_bool_only_repair',(U/'check_surface_v1.py').read_text().replace('lower_informative=lower>0','lower_informative=bool(lower>0)')==(U/'check_surface_v2.py').read_text())
ck('surface_serialization_failure_preserved',not(U/'surface_baseline_v1/RESULTS.json').exists() and len(list((U/'surface_baseline_v1').glob('*.npz')))==18 and 'not JSON serializable' in (U/'SURFACE_RUN_v1.stderr').read_text())
# All check names and predicates unchanged by the numerical coordinate repair.
def calls_ast(path):
 t=ast.parse(path.read_text());return [dump(ast.Call(func=n.func,args=n.args[:2],keywords=[])) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ['ck','eq']]
ck('rescaling_acceptance_predicates_unchanged',calls_ast(U/'check_excursion_v2.py')==calls_ast(U/'check_excursion_v4.py'))
def solver_keywords(path):
 t=ast.parse(path.read_text());return [{x.arg:dump(x.value) for x in n.keywords} for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='solve_bvp']
ck('rescaling_original_solver_tolerance_and_mesh',solver_keywords(U/'check_excursion_v2.py')==solver_keywords(U/'check_excursion_v4.py'))
details['excursion_history']=history
# Actual full staged damage scripts and fresh downstream source closure.
protocol=j(P/'damages_v1/PROTOCOL_v1.json');summ=j(P/'damages_v1/SUMMARY_v1.json');ck('damages_final_base',protocol['source_sha256']==sha(runner));drecords=[]
expect={'bootstrap':(487,3),'surface':(486,4),'ground':(486,4)};witness={'bootstrap':'bootstrap_supremum_solution','surface':'sphere_source_integral','ground':'ground_state_integration_by_parts'}
for name,old,new in protocol['changes']:
 root=P/'damages_v1';src=root/(name+'.py');result=j(root/(name+'_results.json'));record=next(x for x in summ if x['name']==name);outputs=root/(name+'_profiles')
 ck('damage_one_change:'+name,runner.read_text().count(old)==1 and runner.read_text().replace(old,new)==src.read_text())
 ck('damage_diff:'+name,''.join(difflib.unified_diff(runner.read_text().splitlines(True),src.read_text().splitlines(True),fromfile=runner.name,tofile=src.name))==(root/(name+'.diff')).read_text())
 ck('damage_source_execution:'+name,record['source_sha256']==sha(src)==result['checker_sha256'] and record['exit']==1)
 ck('damage_counts:'+name,(result['passed'],result['failed'])==expect[name])
 stream=root/(name+'.stdout');err=root/(name+'.stderr')
 if not stream.exists():stream=root/(name+'_RUN.stdout');err=root/(name+'_RUN.stderr')
 if not stream.exists():stream=root/(name+'_stdout.txt');err=root/(name+'_stderr.txt')
 ck('damage_complete_stream:'+name,stream.read_bytes()==(root/(name+'_results.json')).read_bytes() and err.read_bytes()==b'')
 failed=[]
 for unit,data in result['units'].items():
  ck('damage_complete_unit:'+name+':'+unit,data['checker_sha256']==sha(src) and j(outputs/unit/'RESULTS.json')==data and len(data['checks'])==totals[unit] and data['passed']==sum(x['passed'] for x in data['checks']) and data['failed']==sum(not x['passed'] for x in data['checks']))
  for x in data.get('source_bindings',[]):
   target=recovered_absolute(x['path']);ck('damage_fresh_input:'+name+':'+unit+':'+target.name,target.parent==outputs/'excursion' and sha(target)==x['sha256'])
  for x in data['checks']:
   if not x['passed']:failed.append(dict(unit=unit,**x))
 ck('damage_witness:'+name,witness[name] in [x['name'] for x in failed])
 ck('damage_all_54_profiles:'+name,sum(len(list((outputs/u).glob('*.npz'))) for u in totals)==54)
 drecords.append(dict(name=name,passed=result['passed'],failed=result['failed'],source=ref(src),result=ref(root/(name+'_results.json')),execution=ref(root/(name+'_EXECUTION.json')),all_failed_rows=failed))
details['actual_full_staged_damages']=drecords
ck('scope_reachable_and_held_source','held fixed' in text and 'not a certified eigenvalue' in text and 'no general\nSolar-System exclusion' in text)
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,details=details,source_pairs=len(source_pairs),pending_uniqueness_receipt=True,science_functions_executed=False)
(O/'CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failed_names=[x['name'] for x in rows if not x['passed']],profile_count=len(profile_records),pending_uniqueness=True),indent=2));raise SystemExit(bool(result['failed']))
