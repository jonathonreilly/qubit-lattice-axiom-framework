#!/usr/bin/env python3
"""Execute only actual main AST against clearly synthetic labeled unit stubs."""
from pathlib import Path
from contextlib import redirect_stdout,redirect_stderr
from datetime import datetime,timezone
import argparse,ast,hashlib,io,json,sys,tempfile,traceback
ap=argparse.ArgumentParser();ap.add_argument('--runner',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);cfg=ap.parse_args()
root=cfg.output.resolve();assert not root.exists();root.mkdir(parents=True)
runner=cfg.runner.resolve();text=runner.read_text();tree=ast.parse(text);main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');module=ast.Module(body=[main],type_ignores=[])
(root/'ACTUAL_MAIN.py').write_text(ast.get_source_segment(text,main)+'\n');rows=[];cases=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,v,d=None):rows.append(dict(name=n,passed=bool(v),detail=d))
configurations=[('success',[0,0,0],None),('excursion_failure',[1,0,0],None),('surface_failure',[0,2,0],None),('uniqueness_failure',[0,0,3],None),('multiple_failures',[1,2,3],None),('default_temporary',[0,0,0],None),('existing_profiles',[0,0,0],'AssertionError'),('existing_out',[0,0,0],'AssertionError'),('count_mismatch',[0,0,0],'AssertionError'),('surface_exception',[0,0,0],'RuntimeError'),('malformed_unique',[0,0,0],'JSONDecodeError')]
for name,failures,expected_exception in configurations:
 case=root/name;case.mkdir();profiles=case/'profiles';out=case/'RESULT.json';calls=[];temporary=[];totals=[3,5,7];names=['excursion','surface','uniqueness'];returned=None;exc=None;captured=io.StringIO();errors=io.StringIO()
 if name=='existing_profiles':profiles.mkdir()
 if name=='existing_out':out.write_text('PREEXISTING_OUTPUT_SENTINEL\n')
 def temporary_factory(*args,**kwargs):
  kwargs['dir']=case;obj=tempfile.TemporaryDirectory(*args,**kwargs);temporary.append(obj.name);return obj
 def make_stub(unit,index):
  def stub(*paths):
   target=paths[-1];source=paths[0] if index else None;target.mkdir(parents=True,exist_ok=True);call={'unit':unit,'args':[str(p) for p in paths]};calls.append(call)
   if index:
    parent=source/'RESULTS.json';parent_data=json.loads(parent.read_text());call.update(source_sha256=sha(parent),source_unit=parent_data['stub_unit'],source_marker=parent_data['marker'],source_failed=parent_data['failed'])
   if name=='surface_exception' and unit=='surface':raise RuntimeError('LABELLED_STUB_EXCEPTION')
   failed=failures[index];obj=dict(stub_only=True,stub_unit=unit,marker=name+':'+unit,passed=totals[index]-failed,failed=failed,checks=[dict(name='synthetic_'+str(i),passed=i>=failed) for i in range(totals[index])],payload={'preserve_all_fields':[index,{'scenario':name}]})
   (target/'RESULTS.json').write_text(json.dumps(obj,indent=2)+'\n');call['output_sha256']=sha(target/'RESULTS.json')
   if name=='malformed_unique' and unit=='uniqueness':(target/'RESULTS.json').write_text('{BAD_JSON')
   print(json.dumps({'stub_only':True,'unit':unit,'passed':obj['passed'],'failed':failed,'payload':obj['payload']}))
   return failed+1 if name=='count_mismatch' and unit=='surface' else failed
  return stub
 env=dict(__file__=str(runner),argparse=argparse,Path=Path,io=io,redirect_stdout=redirect_stdout,json=json,hashlib=hashlib,TemporaryDirectory=temporary_factory)
 env.update({('check_'+unit):make_stub(unit,i) for i,unit in enumerate(names)})
 exec(compile(module,str(runner),'exec'),env)
 argv=[str(runner),'--out',str(out)]
 if name!='default_temporary':argv+=['--profiles',str(profiles)]
 saved=sys.argv;sys.argv=argv
 try:
  with redirect_stdout(captured),redirect_stderr(errors):returned=env['main']()
 except Exception as e:
  exc={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
 finally:sys.argv=saved
 (case/'STDOUT.txt').write_text(captured.getvalue());(case/'STDERR.txt').write_text(errors.getvalue());(case/'CALLS.json').write_text(json.dumps(calls,indent=2)+'\n')
 if exc:(case/'EXPECTED_EXCEPTION.json').write_text(json.dumps(exc,indent=2)+'\n')
 ck(name+'.expected_exception',(exc['type'] if exc else None)==expected_exception,exc)
 ck(name+'.stderr_empty',errors.getvalue()=='')
 expected_calls=[] if name=='existing_profiles' else names[:2] if name in ['count_mismatch','surface_exception'] else names
 ck(name+'.unit_order',[c['unit'] for c in calls]==expected_calls)
 for c in calls:
  if c['unit']!='excursion' and 'source_unit' in c:
   ck(name+'.fresh_excursion_input.'+c['unit'],c['source_unit']=='excursion' and c['source_marker']==name+':excursion' and c['source_sha256']==calls[0].get('output_sha256') and c['source_failed']==failures[0],c)
 if expected_exception is None:
  ck(name+'.has_complete_output',out.is_file())
  data=json.loads(out.read_text()) if out.is_file() else {}
  ck(name+'.aggregate_passed',data.get('passed')==15-sum(failures))
  ck(name+'.aggregate_failed',data.get('failed')==sum(failures))
  ck(name+'.failure_exit',returned==bool(sum(failures)))
  ck(name+'.full_stdout',captured.getvalue()==out.read_text())
  ck(name+'.checker_identity',data.get('checker_sha256')==sha(runner))
  ck(name+'.unit_keys',list(data.get('units',{}))==names)
  for index,unit in enumerate(names):
   obj=data.get('units',{}).get(unit,{})
   ck(name+'.complete_unit.'+unit,obj==dict(stub_only=True,stub_unit=unit,marker=name+':'+unit,passed=totals[index]-failures[index],failed=failures[index],checks=[dict(name='synthetic_'+str(i),passed=i>=failures[index]) for i in range(totals[index])],payload={'preserve_all_fields':[index,{'scenario':name}]}))
   stream=json.loads(data['unit_stdout'][unit]);ck(name+'.captured_stream.'+unit,stream==dict(stub_only=True,unit=unit,passed=totals[index]-failures[index],failed=failures[index],payload=obj['payload']))
  if name=='default_temporary':
   ck(name+'.temporary_deleted',len(temporary)==1 and not Path(temporary[0]).exists())
   ck(name+'.historical_paths_bound_in_call_record',all(c['args'][-1].startswith(temporary[0]+'/') for c in calls))
  else:ck(name+'.persistent_profiles',all((profiles/unit/'RESULTS.json').is_file() for unit in names))
 elif name=='existing_out':ck(name+'.preexisting_output_preserved',out.read_text()=='PREEXISTING_OUTPUT_SENTINEL\n')
 else:ck(name+'.no_false_success_output',not out.exists() and captured.getvalue()=='')
 cases.append(dict(name=name,argv=argv,failures=failures,expected_exception=expected_exception,returned=returned,exception=exc,calls=calls,temporary_paths=temporary))
result=dict(scope='Actual wrapper main AST only with labeled synthetic stubs; no scientific function executed.',runner_sha256=sha(runner),main_sha256=sha(root/'ACTUAL_MAIN.py'),passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,cases=cases,created_utc=datetime.now(timezone.utc).isoformat())
(root/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['scope','runner_sha256','passed','failed']},indent=2));print(json.dumps([r['name'] for r in rows if not r['passed']],indent=2));raise SystemExit(bool(result['failed']))
