#!/usr/bin/env python3
"""Final finite-body staged correspondence closure; metadata only."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,difflib,ast
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go');PK=W/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text());rows=[]
def ck(n,v,d=None):rows.append(dict(name=n,passed=bool(v),detail=d))
b=j(O/'SOURCE_BINDINGS_v2.json');d=j(O/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions'];ck('source_count',len(b['source_pairs'])==b['source_pair_count']==len(d)==790)
ck('unique_originals',len({r['original_path'] for r in b['source_pairs']})==790)
for x,y in zip(b['source_pairs'],d):
 p=Path(x['original_path']);s=O/x['snapshot_path'];f=W/y['final_path'];ck('final_source:'+x['original_repo_path'],p.is_file() and p.read_bytes()==s.read_bytes()==f.read_bytes() and sha(p)==x['sha256']==y['original_sha256']==y['recovery_sha256']==y['final_sha256'] and p.stat().st_size==x['bytes']==y['bytes'] and Path(y['recovery'])==s)
known={x['original_path'] for x in b['source_pairs']};live={str(p) for root in [PK/'finite_body_packaging',PK/'rolling_local_response/finite_body_excursion_v1'] for p in root.rglob('*') if p.is_file()};extras=sorted(live-known)
allowed=[str(PK/'rolling_local_response/finite_body_excursion_v1/PARENT_UNIQUENESS_REVIEW_VERIFICATION_v1.json')]
ck('no_unfrozen_source_versions',extras==allowed,extras)
closure=dict(created_utc=datetime.now(timezone.utc).isoformat(),source_count=790,additional_current_files=[dict(path=p,sha256=sha(Path(p)),bytes=Path(p).stat().st_size,disposition='Post-freeze parent attestation of the independent uniqueness review; not used as independent evidence or as a source input. The actual underlying full seal is already independently checked and frozen.') for p in extras],unrelated_directories_not_enumerated=True)
(O/'SOURCE_CLOSURE_v1.json').write_text(json.dumps(closure,indent=2)+'\n')
for name,counts in [('CORRESPONDENCE_RESULTS_v1.json',(1524,0)),('UNIQUENESS_REUSE_RESULTS_v1.json',(266,0)),('wrapper_v1/baseline/RESULTS_v1.json',(141,0))]:
 r=j(O/name);ck('result_count:'+name,(r['passed'],r['failed'])==counts and len(r['checks'])==sum(counts) and all(x['passed'] for x in r['checks']))
ck('original_pending_preserved',j(O/'CORRESPONDENCE_RESULTS_v1.json')['pending_uniqueness_receipt'] is True)
ck('later_pending_resolved',j(O/'UNIQUENESS_REUSE_RESULTS_v1.json')['pending_uniqueness_receipt'] is False)
wr=O/'wrapper_v1';prot=j(wr/'PROTOCOL_v1.json');runner=O/'snapshots/.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/finite_body_packaging/staged/exponential_scalar_finite_body_check.py';base=runner.read_text();summary=j(wr/'SUMMARY_v1.json')
ck('wrapper_source_identity',sha(runner)==prot['source_sha256'] and sha(O/'check_wrapper_stubs_v1.py')==prot['harness_sha256'])
expected={'omit_excursion_failure':(138,3),'wrong_unique_source':(133,8),'hide_failure_exit':(137,4)}
for x in prot['changes']:
 src=wr/(x['name']+'.py');res=j(wr/x['name']/'RESULTS_v1.json');record=next(r for r in summary if r['name']==x['name'])
 ck('wrapper_actual_one_change:'+x['name'],base.count(x['before'])==1 and base.replace(x['before'],x['after'])==src.read_text())
 ck('wrapper_exact_diff:'+x['name'],''.join(difflib.unified_diff(base.splitlines(True),src.read_text().splitlines(True),fromfile=runner.name,tofile=src.name))==(wr/(x['name']+'.diff')).read_text())
 ck('wrapper_damage_counts:'+x['name'],(res['passed'],res['failed'])==expected[x['name']] and len(res['checks'])==141 and record['exit_code']==1)
 ck('wrapper_actual_source_sha:'+x['name'],sha(src)==record['source_sha256']==res['runner_sha256'])
 ck('wrapper_actual_main_ast:'+x['name'],ast.dump(ast.parse((wr/x['name']/'ACTUAL_MAIN.py').read_text()),include_attributes=False)==ast.dump(ast.Module(body=[n for n in ast.parse(src.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='main'],type_ignores=[]),include_attributes=False))
for x in j(O/'COMMAND_INDEX_v1.json')['executions']:
 rec=O/x['record'];ck('command_record_hash:'+x['record'],sha(rec)==x['record_sha256'])
ck('no_symlink_artifacts',not any(p.is_symlink() for p in O.rglob('*')))
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,scope='Final live-source/recovery/disposition and execution closure. No science rerun.',excluded_parent_attestation=extras)
(O/'PRESEAL_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['passed','failed','scope']},indent=2));print(json.dumps([x for x in rows if not x['passed']],indent=2));raise SystemExit(bool(result['failed']))
