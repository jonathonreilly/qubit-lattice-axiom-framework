from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib,subprocess,time

PK=Path(__file__).resolve().parent.parent
DEST=Path(__file__).resolve().parent
STAGE=DEST/'staged';STAGE.mkdir(exist_ok=False)
BODY=PK/'rolling_local_response/finite_body_excursion_v1'
NOTE='EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='exponential_scalar_finite_body_check.py'
PARENTS=['docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[BODY/'check_excursion_v4.py',BODY/'check_surface_v2.py',BODY/'check_uniqueness_v1.py']
maps=[{'run':'check_excursion','COMPARISON_SIGN':'FB_COMPARISON_SIGN','KINETIC_FACTOR':'FB_KINETIC_FACTOR','BOOTSTRAP_SIGN':'FB_BOOTSTRAP_SIGN'}, {'run':'check_surface','SPHERE_COEFFICIENT':'SF_SPHERE_COEFFICIENT','ENVELOPE_COEFFICIENT':'SF_ENVELOPE_COEFFICIENT','HESSIAN_CONNECTION_SIGN':'SF_HESSIAN_CONNECTION_SIGN'}, {'run':'check_uniqueness','CONNECTION_SIGN':'UN_CONNECTION_SIGN','KATO_SIGN':'UN_KATO_SIGN','DENOMINATOR_SIGN':'UN_DENOMINATOR_SIGN','GROUND_SIGN':'UN_GROUND_SIGN'}]
class Rename(ast.NodeTransformer):
    def __init__(self,m):self.m=m
    def visit_Name(self,n):n.id=self.m.get(n.id,n.id);return n
    def visit_FunctionDef(self,n):n.name=self.m.get(n.name,n.name);return self.generic_visit(n)
blocks=[];lineage=[]
for path,mapping in zip(sources,maps):
    selected=[x for x in ast.parse(path.read_text()).body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    tree=ast.fix_missing_locations(Rename(mapping).visit(ast.Module(body=selected,type_ignores=[])))
    blocks.append(ast.unparse(tree)+'\n');lineage.append(dict(path=str(path),sha256=sha(path),renames=mapping,selected_statement_types=['Import','ImportFrom','FunctionDef','Assign'],transformed_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
header='#!/usr/local/bin/python3\n"""Conditional finite held-body bounds, uniqueness and scalar-only stability."""\nfrom contextlib import redirect_stdout\nfrom tempfile import TemporaryDirectory\nimport io\nAUDIT_TIMEOUT_SEC=120\nAUDIT_INPUT_PATHS='+repr(['docs/'+NOTE]+PARENTS)+'\n'
footer='''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True);units={};streams={}
        for name,fn in [('excursion',check_excursion),('surface',check_surface),('uniqueness',check_uniqueness)]:
            captured=io.StringIO()
            with redirect_stdout(captured):
                if name=='excursion':failed=fn(root/name)
                else:failed=fn(root/'excursion',root/name)
            result=json.loads((root/name/'RESULTS.json').read_text())
            assert failed==result['failed'];units[name]=result;streams[name]=captured.getvalue()
        return dict(passed=sum(z['passed'] for z in units.values()),failed=sum(z['failed'] for z in units.values()),units=units,unit_stdout=streams,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional flat static held-source model, derived force bracket and scalar-only stability. No observed fit, full-metric solution or realized-state selector.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-finite-body-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='');return bool(result['failed'])
if __name__=='__main__':raise SystemExit(main())
'''
(STAGE/RUNNER).write_text(header+'\n'.join(blocks)+footer)
opening='''# Deriving finite-body field, force and uniqueness bounds

Status: conditional support; a prescribed static source in a fixed flat metric.
Claim type: bounded_theorem. Scientific author: /root.
Primary runner: `scripts/exponential_scalar_finite_body_check.py`.

Density-dependent homogeneous extrema do not establish a finite body's interior
field or measured force. This block derives compactness bounds, a radial surface
force bracket and a sufficient uniqueness/stability criterion from the elliptic
equation. A thin-shell factor and a chosen interior stationary point are not
inserted. The action, particle-density source, boundary and approximation regime
remain declared premises.

The [supplied action](EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md),
[local normalization](EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md),
and [environment definitions](EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md)
remain conditional. Here chi is the locally/global-along-this-line canonical
coordinate defined by dchi=sqrt(K_uu)du, not the distinct bounded-coordinate chi
used in the earlier confinement note. The negative-branch restriction is explicit.
No observed likelihood, measured body mass or full relativistic exterior is supplied.

The full hand proofs follow. Their original filenames and version references
identify preserved evidence in the recovery archive rather than new premises.

'''
hands=[BODY/'DERIVATION_v2.md',BODY/'SURFACE_FORCE_DERIVATION_v2.md',BODY/'UNIQUENESS_DERIVATION_v2.md']
sections=['\n'.join('#'+line if line.startswith('#') else line for line in p.read_text().splitlines()) for p in hands]
closing='''

## Numerical and empirical status

The frozen grid has18 synthetic uniform held spheres: k=0.01,0.1,0.3;
nu=0.0001; surface compactness0.0001,0.01; vacuum mass times radius0.1,1,10.
The radius is the numerical length unit. Every field, derivative, conformal
factor, coupling, integrated source flux and enlarged-domain comparison is kept.
The finite-domain Dirichlet solve approximates the stated infinity boundary;
grid checks are not an analytic discretization certificate or a full GR solve.
No state is selected by the sign-bracket search for homogeneous extrema.

Original excursion220/0, surface172/0 and uniqueness98/0 give490 canonical
controls. Surface/uniqueness reuse the already exposed profiles; they are not
independent observational validation. Eleven surface lower brackets are nonzero.
All18 cases meet the sufficient uniqueness criterion. Samples supplement the
analytic Hessian inequalities; a sampled minimum is not a certified eigenvalue.

The original excursion implementation failed while serializing a NumPy boolean;
its18 profiles remain. The serialization repair gave216/4, exposing integral-flux
resolution. A tighter solver attempt gave219/1 because its mesh limit was reached.
Rescaling the unknown by the analytic linear field gave220/0 with the same
physical equations, original solver tolerance and unchanged acceptance tests.
The surface implementation also needed an explicit boolean serialization repair.
All source versions, streams, failures, profiles and exact diffs remain recoverable.

The independent excursion proof check supplies598/0 and22 affected proof controls;
the surface proof check supplies1735/0 and seven actual altered programs. The
uniqueness proof receives a separately sealed focused check. These are mathematical
and numerical controls, not experiments or formal audit grades. Its access record
must disclose that aggregate producer metadata was exposed before independent
algebra; this does not turn the producer count into independent evidence.

The first existence outline lacked a proof of decay after the variational limit.
The corrected proof derives uniform continuity from bounded elliptic forcing and
uses L2 integrability to obtain decay. The surface opening now states radial
solution explicitly. A separate small-compactness theorem derives radial symmetry
from uniqueness; it does not infer symmetry solely from spherical density.

The [recovery archive](work_history/physics/revised-scalar-finite-body-20261014/README.txt)
contains all original proofs, numerical histories, figures, source comparison,
independent reports, source bindings and actual changed-program controls.
The command-line option `--profiles` preserves the complete fresh pipeline. Its
surface/uniqueness source bindings refer to the newly generated excursion output;
different output directories are provenance differences, not changed science.

The primary literature comparison is Khoury and Weltman,
[astro-ph/0309300v3](https://arxiv.org/pdf/astro-ph/0309300), inspected at its static
equation and compact-body discussion. Its established mechanism motivates the
finite-size question. Its runaway potential, constant coupling, ambient minimum
and approximate shell factor are not inserted into this candidate's proofs.

For a weak sufficiently long-range body in the declared class, the source charge
cannot be assigned arbitrary suppression. For a heavier range correction the
zero lower bound is uninformative. Other ambient states, physical density/support
profiles, metric backreaction, moving-matter stability, dynamical relaxation and
conversion to a measured gravitational mass remain open. This is no general
Solar-System exclusion, no complete environmental reconstruction and no TOE.
'''
(STAGE/NOTE).write_text(opening+'\n\n'.join(sections)+closing)
(DEST/'CANONICAL_LINEAGE_v1.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),canonical_note=dict(path=NOTE,sha256=sha(STAGE/NOTE)),canonical_runner=dict(path=RUNNER,sha256=sha(STAGE/RUNNER)),scientific_sources=lineage,hand_sources=[dict(path=str(p),sha256=sha(p)) for p in hands],transforms='Only AST formatting and explicit function/global renaming in scientific blocks. New wrapper executes dependent fresh profiles, preserves all unit JSON and stdout, and aggregates counts.'),indent=2)+'\n')
cmd=['/usr/local/bin/python3',str(STAGE/RUNNER),'--profiles',str(DEST/'staged_profiles_v1'),'--out',str(DEST/'STAGED_RESULTS_v1.json')]
t=time.monotonic();started=datetime.now(timezone.utc).isoformat();r=subprocess.run(cmd,capture_output=True,text=True)
(DEST/'STAGED_RUN_v1.stdout').write_text(r.stdout);(DEST/'STAGED_RUN_v1.stderr').write_text(r.stderr)
(DEST/'STAGED_RUN_v1.json').write_text(json.dumps(dict(command=cmd,started=started,finished=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-t,exit_code=r.returncode,runner_sha256=sha(STAGE/RUNNER)),indent=2)+'\n')
print('STAGED',r.returncode,r.stderr[-1500:])
if r.returncode==0:
    z=json.loads(r.stdout);print(z['passed'],z['failed'])
raise SystemExit(r.returncode)
