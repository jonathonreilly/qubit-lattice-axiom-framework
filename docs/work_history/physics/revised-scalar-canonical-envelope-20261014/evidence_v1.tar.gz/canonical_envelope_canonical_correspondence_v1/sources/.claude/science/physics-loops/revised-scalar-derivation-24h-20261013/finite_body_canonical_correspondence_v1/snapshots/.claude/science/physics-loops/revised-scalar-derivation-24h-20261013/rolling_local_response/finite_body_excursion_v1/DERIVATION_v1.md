# Can a weak finite body reach the homogeneous density minimum?

Personally derived by /root, 2026-10-14. This addresses a missing environment
bridge: a stationary homogeneous density minimum need not be attained inside a
finite object. The complete supplied scalar action remains conditional. No new
observational data, material law, ambient state or absolute scale is selected.

## 1. The explicit local model

Restrict the supplied action to its consistent x=y=0 scalar channel. Let
chi(u)=integral_0^u sqrt(K_uu(v)) dv, A(0)=1, Y=H_v^2 U, and
beta=d ln A/d chi>0. The scalar kinetic term is -Q(partial chi)^2.
Consider a prescribed, nonnegative, bounded, compactly supported conserved
Einstein particle mass density rhoStar=m_J n_E. Particle locations/volume are
held by unspecified supports. This is not a freely falling fluid, a derived
constitutive law, or fixed physical rho_J: rho_J=rhoStar/A^3.

In a frozen flat spatial patch, after subtracting the constant vacuum energy,
the static equation and energy are

    Delta chi=Y_chi+rhoStar A_chi/(2Q),                  (1)
    E[chi]=integral [Q|grad chi|^2+2Q(Y-Y(0))+rhoStar A] d^3x.

The boundary is chi tending to0 at spatial infinity in this mathematical
decoupling problem. Positive H_v means the full spacetime is not asymptotically
Minkowski; this boundary is an ideal local matching model, not a global GR
solution. Applying it to a body needs a patch small compared with background
curvature/evolution lengths and controlled metric/support corrections.

First suppose a bounded regular solution is entirely on the negative-u branch,
so chi<=0. For nu>0 the candidate has Y_chi<0 for chi<0, Y_chi(0)=0,
0<A<=1 and q=beta^2<a<1/3. Write w=-chi>=0 and c=rhoStar/(2Q).
Let V>=0 be the Newton potential magnitude solving -Delta V=c with V->0;
V(x)=Gvac integral rhoStar(y)/|x-y| d^3y, Gvac=1/(8pi Q).
Its maximum P=||V||_infinity is a supplied compactness functional of the held
mass distribution, not an independently measured gravitational constant.

Because -Delta w=Y_chi+c A beta<=c sqrt(a), comparison with the decaying
Newton solution gives

    0<=w(x)<=sqrt(a) V(x),
    0<=-ln A(x)<=a V(x).                               (2)

For comparison, use Delta(w-sqrt(a)V)>=0, zero limiting boundary and the
maximum principle. These are exact inequalities for (1), independent of nu,
density amplitude and the local effective mass. They already forbid arbitrary
field movement in a weak object merely because its homogeneous density is high.

## 2. A sharper vacuum-referenced bound

For 0<k<1/3, a=(1-k)(1+3k)/4 and s=(1+k)/[k(1-3k)], the previous exact
negative-branch relation is q=a(1+s-s A^2)/(1+s-3as A^2), with k<=q<a.
Since dA/dchi=A sqrt(q), direct differentiation gives

    -d beta/dchi=(1+k) A^2 (1-3q)^2/(1-3k)^2
                 <=L:=1+k.                            (3)

At chi=0, beta=sqrt(k), and the derivative has magnitude L. Thus
sqrt(k)<=beta(-w)<=sqrt(k)+Lw throughout this branch. Equation(1) implies
-Delta w<=c[sqrt(k)+Lw]. Comparison, followed by a supremum bound for the
positive Newton integral operator, yields

    W:=||w||_infinity <=sqrt(k) P+L P W.

Whenever LP<1, this closes without assuming a constant coupling:

    W<=sqrt(k) P/(1-LP),
    k<=q(x)<=k/(1-LP)^2,
    -ln A(x)<=sqrt(k)W+L W^2/2
              <=k P(1-LP/2)/(1-LP)^2.                 (4)

The global a ceiling can be combined with the q bound. The last expression
bounds an integral of beta; it does not identify the force charge of the body.
For a uniform held sphere with mass MStar and radius R, P=3Gvac MStar/(2R).
The use of Gvac, rhoStar and Einstein radius is explicit. Measured Jordan
compactness requires the previously unresolved calibration/matching bridge.

The interior density minimum can be used as a physical approximation only if
its displacement satisfies these necessary finite-body bounds. Violation is
a failure of that homogeneous-interior approximation under this matching, not
nonexistence of all static solutions or exclusion of the entire theory. A
potential gradient can cancel the volume source and reduce the external
charge. Equations(2)-(4) alone neither prove nor exclude that screening; they
do prove that its ambient/central values cannot be supplied arbitrarily.

## 3. Existence is different from dynamical state selection

For the same prescribed compact source and nu>0, one may minimize E over
nonpositive H^1 fields with the zero boundary at infinity. On this half-line,
U-U(0) is strictly positive away from zero, quadratic with positive coefficient
near zero, and grows quadratically in chi as chi tends to minus infinity.
Continuity therefore gives a positive coercive lower bound proportional to
chi^2 for fixed parameters. The matter contribution is bounded between0 and
integral rhoStar. The direct method uses weak H^1 compactness, local Rellich
convergence on the source support, Fatou for the nonnegative potential, and
dominated convergence for A rhoStar. It gives a minimizing field.

Clipping a positive field to zero lowers its gradient energy, lowers the
candidate potential because U>=U(0), and lowers its matter energy because
A>=1 on the positive branch. A nonpositive minimizer is consequently also
stationary against small admissible variations into the original positive
canonical neighborhood. Clipping sufficiently negative values also lowers
the energy: for bounded rhoStar, Y_chi+c A_chi is negative uniformly at
sufficiently negative chi. The minimizer is bounded; standard local elliptic
regularity then supports the comparison argument, with the appropriate weak
interpretation across a density jump. This is an existence construction in
the supplied elliptic model. It does not prove uniqueness, dynamical settling,
realization of that minimum, or applicability of the flat/held-source model.

For such a minimizer, E[chi]<=E[0]=MStar. Its scalar energy obeys

    integral [Q|grad chi|^2+2Q(Y-Y(0))]
       <=integral rhoStar(1-A)
       <=MStar ||-ln A||_infinity.                     (5)

Independently, multiplication of (1) by chi and integration gives
integral |grad chi|^2<=integral c beta w, since chi Y_chi>=0.
These are useful self-consistency bounds; they do not supply a complete metric
error estimate or eliminate material supporting stresses.

## 4. Frozen implementation plan and limits

Verify the canonical derivative identity directly in original E=e^(2sqrt(a)u)
coordinates, its positive/negative domains, the maximum-principle sign, the
bootstrap coefficient, the uniform sphere Newton normalization, and the
potential sign/coercive limits. Deliberately reverse the comparison sign,
replace the kinetic normalization by a half-normalization, and remove the
bootstrap denominator; actual damaged programs must fail independent witnesses.

For numerical illustrations use only synthetic held spheres and expose all
calibrations. Compare a direct nonlinear radial boundary-value solution with
an independent integral/flux residual, mesh/domain refinements, and a massless
or linear massive analytic control. Retain full radial profiles and truncation
errors. No real object or observational exclusion is to be inferred from these
examples. The final model-to-data bridge still needs the ambient state, matter
support, measured compactness/range and a controlled curved-spacetime solution.
