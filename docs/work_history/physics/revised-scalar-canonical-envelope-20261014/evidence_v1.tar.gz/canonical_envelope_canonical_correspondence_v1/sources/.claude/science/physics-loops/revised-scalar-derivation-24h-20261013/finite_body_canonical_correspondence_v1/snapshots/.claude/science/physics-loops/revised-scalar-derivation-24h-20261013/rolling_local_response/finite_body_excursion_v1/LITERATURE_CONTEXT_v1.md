# Primary context for the held-density finite-body question

Khoury and Weltman, *Chameleon Fields: Awaiting Surprises for Tests of Gravity in Space*, PRL93,171104(2004), arXiv astro-ph/0309300v3: https://arxiv.org/pdf/astro-ph/0309300 . The saved PDF is126444 bytes, SHA25679a6027bdd201404b1e0f6e420bdedccd559d895817ba05a667a383a635ae83d. The public primary text was inspected, especially Eqs.(2),(4),(5),(7),(8).

Their static equation uses a conserved particle-density variable, and their approximate thin-shell condition depends on compactness and the ambient/interior field difference. Thus density-dependent minima alone are insufficient to assign a finite object's scalar charge. This is established mechanism/context, not a novelty claim for this campaign.

With phi=sqrt(2Q)chi and Mpl^2=Q, their locally constant coupling would be beta_KW=beta_ours/sqrt(2). Their runaway potential, finite-density ambient minimum and approximate shell factor are not our supplied action or vacuum boundary, and none is inserted into our proofs. Our comparison, explicit envelope and integrated source bounds are derived for the stated variable coupling and held-source problem. This comparison supplies no real-environment fit, current experimental limit or dynamical state selector.
