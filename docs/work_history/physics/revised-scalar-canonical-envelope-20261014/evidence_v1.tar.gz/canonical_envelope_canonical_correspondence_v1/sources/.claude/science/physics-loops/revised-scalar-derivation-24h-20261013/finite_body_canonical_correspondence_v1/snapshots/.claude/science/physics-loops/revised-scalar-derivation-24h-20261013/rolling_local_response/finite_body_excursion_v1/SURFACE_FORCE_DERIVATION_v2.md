# From field excursion to a conditional surface-force bracket

Personally derived by /root after the finite-body excursion calculation. Reuse
all hypotheses and the corrected existence/boundary argument in DERIVATION_v2.md.
This extension concerns a radial negative-branch solution for a spherical, uniform held rhoStar of radius R. It is an
exact bound within the flat static model, not an imported thin-shell factor.
No new calibration, observed body or likelihood is supplied.

Put P=3Gvac MStar/(2R), L=1+k, Wb=sqrt(k)P/(1-LP),
B=kP(1-LP/2)/(1-LP)^2, betaMax=sqrt(k)/(1-LP), with LP<1.
The previous comparison also gives the stronger pointwise bound w<=betaMax V.
The surface scalar attraction relative to the chosen Newton reference is

    eta_s=beta(chi(R)) R^2 chi'(R)/(Gvac MStar).          (1)

This normalization uses held Einstein particle mass. It is not the measured
Jordan gravitational mass including scalar energy, pressure and metric corrections.

## 1. A potential slope envelope derived from the supplied action

Let K0=K_uu(0), Umax=Wb/sqrt(K0), Emin=exp(-2sqrt(a)Umax), Fmin=1+s Emin.
Because dK/dE=-s[(1+3a)+(1-3a)sE]/(1+sE)^3<0,
K(u)>=K0 for u<=0. Therefore w<=Wb implies -Umax<=u<=0.

On this interval, writing alpha=sqrt(a), a conservative explicit envelope is

    Mbar^2 = H_v^2/K0 {
       12 a s(1+s)^2/Fmin^4
       +nu(1+s)[1/Fmin^2+8alpha s Umax/Fmin^3
                             +12a s^2 Umax^2/Fmin^4] }. (2)

To prove it, the base-potential second u derivative is

    12a s(1+s) E[2E-1+sE(2-E)]/(1+sE)^4.

Use E<=1, 2E-1<=1 and E(2-E)<=1. The regulator second derivative is

    nu(1+s)[1/F^2-8alpha s E u/F^3
                   -4a s E u^2/F^3+12a s^2 E^2 u^2/F^4].

Drop the negative term and bound the positive terms by Umax,Fmin. Since
K_u<0 and U_u<0, the canonical Hessian

    Y_chichi=H_v^2[U_uu/K-K_u U_u/(2K^2)]

is no larger than the positive envelope(2). Integration from chi=0 gives

    0<=-Y_chi(-w)<=Mbar^2 w, 0<=w<=Wb.                 (3)

This does not assume a positive Hessian everywhere. Mbar is an explicit
consequence of the action and prior excursion bound, not an assigned effective
mass. At P->0 with fixed parameters it approaches the exact vacuum mass,

    Mvac^2/H_v^2=4(3+3k+nu)/(1-3k).

The approach is not asserted uniform at singular parameter boundaries.

## 2. Integrate the actual radial source

Exterior to the body, (r^2 chi')'=r^2 Y_chi<=0. A nonpositive solution tending
to zero cannot have r^2 chi'<0 at an exterior point: monotone decrease of that
flux would prevent its approach to zero from below. Thus exterior scalar
attraction is nonnegative, including at R.

Integrating the exact equation through the body and using A>=exp(-B),
beta>=sqrt(k), and(3) gives

    R^2 chi'(R) >=sqrt(k) exp(-B)c R^3/3
                         -Mbar^2 integral_0^R r^2 w dr,

where c=rhoStar/(2Q). The uniform sphere has V=c(3R^2-r^2)/6 inside and

    integral_0^R r^2 V dr=2c R^5/15,
    Gvac MStar=c R^3/3.

Use w<=betaMax V and multiply by beta(R)>=sqrt(k) only when the lower flux
bound is nonnegative. The resulting unconditional bracket within this model is

    max[0, k exp(-B)-(2/5)k Mbar^2 R^2/(1-LP)]
        <= eta_s <= k/(1-LP)^2.                        (4)

The upper bound follows separately from Y_chi<=0 and A beta<=betaMax in the
volume source. Outside the body, the scalar/Newton-reference ratio is
nonincreasing: differentiate beta r^2 chi', use beta_chi<=0, chi'>=0 and
Y_chi<=0. This monotonicity is a range/property statement, not a positive
lower force bound at an arbitrary distant apparatus.

For small compactness and Mbar R<<1, the lower bound is close to k. Hence a
weak body in this particular vacuum-matched long-range class cannot be assigned
an arbitrarily suppressed scalar charge. If the bracket is zero it says
nothing about the amount of screening. Large range corrections, different
ambient matching, real density/support profiles and full spacetime remain to
be derived. The field excursion theorem alone did not give this lower bound;
the supplied potential envelope and uniform-sphere source integration are new
essential steps.

## 3. Prospective checks on existing synthetic profiles

Before extracting their surface forces, freeze: verify the exact Hessian and
sphere coefficients; challenge the comparison and force directions; compute
the explicit envelope from each previously frozen case; check every recorded
surface flux against(4) with the existing2e-8 absolute numerical slack; and
record cases where the lower bracket is uninformative. Independently sample
the exact Hessian across the whole analytically bounded u interval as a
numerical control, not as the proof of its supremum. Existing profiles are now
exposed development data; this reuse is not a reserved validation sample.
Actual changed envelope/flux-normalization programs must fail exact witnesses.
