# A compactness criterion for a unique negative-branch held-body solution

Personally derived by /root. Conditional support inside the same supplied action,
flat elliptic equation, bounded compact nonnegative held particle density, nu>0,
and vacuum boundary as DERIVATION_v2.md. No dynamical state selection or full
metric/matter solution is claimed. This adds a sufficient small-body criterion;
failure of the criterion is not evidence for multiplicity.

Use P=||V||infinity, L=1+k, LP<1, Wb=sqrt(k)P/(1-LP),
K0=K_uu(0), Umax=Wb/sqrt(K0), and alpha=sqrt(a). Suppose

    2 alpha Umax <= ln 2.                              (1)

This is a computable condition on the held-source compactness and the already
supplied parameter k. It is not an additional potential or mass selector. All
bounded decaying negative-branch solutions obey -Umax<=u<=0 from the previous
comparison, hence E=exp(2 alpha u)>=1/2 and F>=1, J>0.

## 1. Derive convexity on the whole reachable interval

Let b=1-3a>0, F=1+sE, J=1+b sE. Direct canonical differentiation of the base
potential gives

 Ubase_chichi = 6 a s(1+s) E / (F^2 J^2)
     * {2J[(2E-1)+sE] - b s E(E-1)F}.                 (2)

For 1/2<=E<=1 every displayed term in braces is nonnegative and sE>0, so this
is strictly positive. Write the regulator as nu(1+s)g^2/2 with g=u/F. Then

 g_chi = [1-2 alpha s E u/F]/sqrt(J),
 g_chichi = -2 alpha s E/J [1+2 alpha u/F]
            -alpha b s E F/J^2 [1-2 alpha s E u/F].    (3)

Because 2 alpha |u|<=ln2<1 and F>=1, (3) is negative, while g<=0. Thus

 Ureg_chichi = nu(1+s)[g_chi^2+g g_chichi] >0.

The total Y=Hv^2 U has Y_chichi>0 throughout the allowed interval (Hv>0).
This is a derived local convexity domain; no global convexity premise is used.

Also A_chichi=A(beta^2+beta_chi)>=-L, since 0<A<=1, beta^2>=0 and
beta_chi>=-L on the negative branch. This one-sided bound is sufficient; no
absolute upper bound on A_chichi is required.

## 2. Uniqueness from the positive Newton operator

Let chi1,chi2 be two bounded decaying negative-branch solutions for the same
held source and parameters. Let d=chi1-chi2. Their segment stays in the above
convex interval. By the mean-value identities, Y_chi(chi1)-Y_chi(chi2) has the
sign of d, and [A_chi(chi1)-A_chi(chi2)]d>=-L d^2.
The distributional Kato inequality therefore implies

    -Delta |d| <= L c |d|,   c=rhoStar/(2Q)>=0.       (4)

The right side has compact support. Both |d| and the Newton potential of
L c |d| decay to zero. The maximum principle applied to their difference gives

    |d(x)| <= L N[c |d|](x)
             <= L ||d||infinity V(x).

Taking suprema yields ||d||infinity<=LP ||d||infinity. LP<1 forces d=0.
The existence proof in DERIVATION_v2 supplies at least one such negative-branch
solution, so it is unique in this explicitly stated class.

For a rotationally symmetric held density, every spatial rotation of that
solution solves the same problem. Uniqueness therefore derives radial symmetry,
without assuming that spherical density by itself guarantees it. For a uniform
sphere satisfying (1), the surface-force bracket applies to this unique static
negative-branch solution. The elliptic solution is still not a proven realized
state of a freely moving body or cosmological environment.

The same Kato proof also gives a stability estimate for changing the held source,
provided both sources satisfy a common reachable convexity interval: with
Vdiff=N[|c1-c2|] and betaMax a common upper bound on A_chi, the difference obeys
||d||infinity <= betaMax ||Vdiff||infinity/(1-L P1).
This last inequality is conditional on those common bounds; it does not derive
source masses, support stresses or a dynamical settling rate.

## 3. Prospective checks

Verify (2),(3) directly from the original action and canonical Jacobian, the
one-sided A_chichi bound and the contraction sign. Check the exact criterion on
the already exposed 18 synthetic body cases; sample Hessians only as numerical
controls in addition to the analytic proof. Deliberately reverse the Kato sign,
connection term or denominator and preserve the failed mathematical witnesses.
No new observation, fit or independent empirical test is implied.
