#!/usr/local/bin/python3
from pathlib import Path
import argparse,json,hashlib,itertools
import numpy as np
import sympy as S
from scipy.integrate import solve_bvp,quad,cumulative_simpson
from scipy.optimize import brentq

COMPARISON_SIGN=1
KINETIC_FACTOR=2
BOOTSTRAP_SIGN=-1

def run(out,algebra_only=False):
    out.mkdir(parents=True,exist_ok=False)
    rows=[];cases=[]
    def ck(n,b,detail=None):rows.append(dict(name=n,passed=bool(b),detail=detail))
    def eq(n,e):v=S.factor(S.cancel(e));ck(n,v==0,str(v))
    k,E,z,u,nu=S.symbols('k E z u nu',positive=True)
    a=(1-k)*(1+3*k)/4;alpha=S.sqrt(a);s=(1+k)/(k*(1-3*k));F=1+s*E;J=1+(1-3*a)*s*E;K=J/F**2;A=S.sqrt((1+s)*E/F);q=a/J
    # Canonical differentiation d/dchi=(2 alpha E/sqrt(K))d/dE.
    beta_chi=S.factor(2*alpha*E*S.diff(S.sqrt(q),E)/S.sqrt(K))
    beta_chi_rational=-a*(1-3*a)*s*E*F/J**2
    eq('canonical_beta_derivative_squared',beta_chi**2-beta_chi_rational**2)
    eq('vacuum_beta_derivative',beta_chi_rational.subs(E,1)+(1+k))
    D=1+s-s*z*z;qz=a*D/(1+s-3*a*s*z*z)
    eq('canonical_beta_derivative_A',z*S.diff(qz,z)/2+(1+k)*z*z*(1-3*qz)**2/(1-3*k)**2)
    eq('original_E_to_A_derivative',beta_chi_rational.subs(E,z*z/D)-z*S.diff(qz,z)/2)
    phi,L,beta0,W=S.symbols('P L beta0 W',positive=True)
    wb=COMPARISON_SIGN*beta0*phi/(1+BOOTSTRAP_SIGN*L*phi)
    eq('bootstrap_supremum_solution',wb-beta0*phi-L*phi*wb)
    eq('integrated_coupling_bound',beta0*wb+L*wb**2/2-beta0**2*phi*(1-L*phi/2)/(1-L*phi)**2)
    eq('rest_source_normalization',S.Rational(1,KINETIC_FACTOR)-S.Rational(1,2))
    radius,rho,Q,r=S.symbols('R rho Q r',positive=True)
    G=1/(8*S.pi*Q);mass=4*S.pi*rho*radius**3/3;surf=G*mass/radius
    potential=rho/(KINETIC_FACTOR*Q)*(3*radius**2-r*r)/6
    eq('sphere_center_potential',potential.subs(r,0)-3*surf/2)
    eq('sphere_surface_potential',potential.subs(r,radius)-surf)
    eq('sphere_poisson',-(S.diff(potential,r,2)+2*S.diff(potential,r)/r)-rho/(2*Q))
    ck('comparison_positive_witness',wb.subs({beta0:1,phi:S.Rational(1,10),L:1})>0)
    eu=S.exp(2*alpha*u);fu=1+s*eu;ju=1+(1-3*a)*s*eu;ku=ju/fu**2;au=S.sqrt((1+s)*eu/fu)
    U=S.Rational(3,2)+S.Rational(3,2)*s*(eu-1)**2/fu**2+nu*(1+s)*u*u/(2*fu**2)
    Up=S.diff(U,u);Upp=S.diff(U,u,2);Ap=S.diff(au,u);Kp=S.diff(ku,u)
    vacratio=4*(3+3*k+nu)/(1-3*k)
    eq('vacuum_mass_normalization',Upp.subs(u,0)/ku.subs(u,0)-vacratio)
    # Sign decomposition on u<0: first term derivative plus regulator derivative.
    expected_up=6*alpha*s*(1+s)*eu*(eu-1)/fu**3+nu*(1+s)*u*(1-2*alpha*u*s*eu/fu)/fu**2
    eq('negative_branch_potential_sign_decomposition',Up-expected_up)
    for kv in [S.Rational(1,100),S.Rational(1,10),S.Rational(3,10)]:
        for ev in [S.Rational(1,1000),S.Rational(1,10),S.Integer(1)]:
            bv=S.factor(beta_chi_rational.subs({k:kv,E:ev}));qv=q.subs({k:kv,E:ev})
            ck('lipschitz_'+str(kv)+'_'+str(ev),0<=-bv<=1+kv,str(bv))
            ck('coupling_branch_'+str(kv)+'_'+str(ev),kv<=qv<a.subs(k,kv))
        for uv in [-20.,-1.,-.01]:
            vv=float(Up.subs({k:kv,u:uv,nu:S.Rational(1,10000)}));ck('potential_opposes_shift_'+str(kv)+'_'+str(uv),vv<0,vv)
    if not algebra_only:
        for index,(kv,compact,muv) in enumerate(itertools.product([.01,.1,.3],[.0001,.01],[.1,1.,10.])):
            nv=.0001;sub={k:kv,nu:nv}
            fun=S.lambdify(u,[ku.subs(sub),Kp.subs(sub),au.subs(sub),Ap.subs(sub),Up.subs(sub)],'numpy')
            K0=float(ku.subs({**sub,u:0}));beta_v=np.sqrt(kv);mratio=float(vacratio.subs(sub));hv2=muv*muv/mratio;c0=3*compact*(2/KINETIC_FACTOR)
            boundP=1.5*compact;Lv=1+kv;wbound=COMPARISON_SIGN*beta_v*boundP/(1+BOOTSTRAP_SIGN*Lv*boundP);lnbound=kv*boundP*(1-Lv*boundP/2)/(1-Lv*boundP)**2
            def linear(rs,inside):
                v=muv*rs;pref=beta_v*c0/muv**2
                if inside:
                    sh=np.ones_like(v);dsh=np.zeros_like(v);mask=v!=0
                    sh[mask]=np.sinh(v[mask])/v[mask];dsh[mask]=muv*(v[mask]*np.cosh(v[mask])-np.sinh(v[mask]))/v[mask]**2
                    ch=-pref*(1-(1+muv)*np.exp(-muv)*sh);cp=pref*(1+muv)*np.exp(-muv)*dsh
                else:
                    ch=-pref*(muv*np.cosh(muv)-np.sinh(muv))*np.exp(-v)/v;cp=-ch*(muv+1/rs)
                return ch,cp
            def solve(domain):
                span=domain-1
                def rhs(t,y):
                    ki,kpi,ai,api,upi=fun(y[0]);ko,kpo,ao,apo,upo=fun(y[2]);re=1+span*t
                    return np.vstack([y[1],(hv2*upi+c0*api)/ki-kpi*y[1]**2/(2*ki),span*y[3],span*(hv2*upo/ko-kpo*y[3]**2/(2*ko)-2*y[3]/re)])
                def bc(ya,yb):return np.array([ya[1],yb[2],yb[0]-ya[2],yb[1]-ya[3]])
                ts=np.linspace(0,1,301);ci,di=linear(ts,True);co,do=linear(1+span*ts,False);guess=np.array([ci,di,co,do])/np.sqrt(K0);sing=np.zeros((4,4));sing[1,1]=-2
                sol=solve_bvp(rhs,bc,ts,guess,S=sing,tol=1e-8,max_nodes=20000)
                return sol,bc,span
            domain=max(10.,12/muv);sol,bc,span=solve(domain);ref,bc2,span2=solve(1.5*domain)
            ck('bvp_success_'+str(index),sol.success and ref.success,dict(first=sol.message,refined=ref.message,nodes=[len(sol.x),len(ref.x)]))
            ck('boundary_residual_'+str(index),float(np.max(np.abs(bc(sol.y[:,0],sol.y[:,-1]))))<1e-8)
            ck('collocation_residual_'+str(index),float(np.max(sol.rms_residuals))<1e-7,float(np.max(sol.rms_residuals)))
            ri=np.linspace(0,1,1001);ro=np.geomspace(1,domain,2001);yi=sol.sol(ri);yo=sol.sol((ro-1)/span);us=np.r_[yi[0],yo[2,1:]];ups=np.r_[yi[1],yo[3,1:]];rs=np.r_[ri,ro[1:]]
            ch=np.array([quad(lambda v:np.sqrt(float(fun(v)[0])),0,float(uv),epsabs=1e-14,epsrel=1e-11)[0] for uv in us]);kap,kapp,aval,apval,upval=fun(us);bv=apval/(aval*np.sqrt(kap));w=-ch
            ck('negative_solution_'+str(index),float(np.max(us))<2e-8,float(np.max(us)))
            ck('global_compactness_bound_'+str(index),float(np.max(w))<=wbound+2e-8,dict(max_w=float(np.max(w)),bound=wbound))
            qbound=kv/(1-Lv*boundP)**2;ck('q_bootstrap_bound_'+str(index),float(np.max(bv*bv))<=qbound+2e-8,dict(max_q=float(np.max(bv*bv)),bound=qbound))
            ck('conformal_bound_'+str(index),float(np.max(-np.log(aval)))<=lnbound+2e-8,dict(max_deficit=float(np.max(-np.log(aval))),bound=lnbound))
            vi=c0*(3-ri*ri)/6;vo=c0/(3*ro);V=np.r_[vi,vo[1:]]
            ck('pointwise_comparison_'+str(index),float(np.max(w-np.sqrt((1-kv)*(1+3*kv)/4)*V))<2e-8)
            # Independent integral/flux route on separately sampled inside/outside grids.
            ki,kpi,ai,api,upi=fun(yi[0]);ko,kpo,ao,apo,upo=fun(yo[2]);fi=ri**2*(hv2*upi+c0*api)/np.sqrt(ki);fo=ro**2*hv2*upo/np.sqrt(ko)
            int_i=cumulative_simpson(fi,x=ri,initial=0);int_o=int_i[-1]+cumulative_simpson(fo,x=ro,initial=0);flux=rs**2*np.sqrt(kap)*ups;integral=np.r_[int_i,int_o[1:]];ferr=float(np.max(np.abs(flux-integral))/(beta_v*c0/3))
            ck('independent_flux_residual_'+str(index),ferr<1e-7,ferr)
            yir=ref.sol(ri);yor=ref.sol((ro-1)/span2);uref=np.r_[yir[0],yor[2,1:]];domainerr=float(np.max(np.abs(us-uref))/(1e-20+np.max(np.abs(uref))))
            ck('domain_refinement_'+str(index),domainerr<1e-5,domainerr)
            # Homogeneous extrema are comparison candidates, not selected interior states.
            def stationary(uv):kk,kp,aa,app,upp=fun(uv);return hv2*upp+c0*app
            grid=-np.geomspace(1e3,1e-10,2001);roots=[]
            for left,right in zip(grid[:-1],grid[1:]):
                if stationary(left)*stationary(right)<0:
                    root=brentq(stationary,left,right,xtol=1e-13);disp=-quad(lambda v:np.sqrt(float(fun(v)[0])),0,root,epsabs=1e-12)[0];roots.append(dict(u=root,canonical_displacement=disp,violates_necessary_body_bound=disp>wbound+2e-8))
            filename='profile_'+str(index)+'.npz';np.savez_compressed(out/filename,r=rs,u=us,du=ups,chi=ch,A=aval,beta=bv,flux=flux,integral_flux=integral,refined_u=uref,Newton_magnitude=V)
            cases.append(dict(index=index,k=kv,nu=nv,Phi_surface=compact,mu_vac_R=muv,Hv_R_squared=hv2,cR=c0,domain=domain,central_u=float(us[0]),central_w=float(w[0]),max_q=float(np.max(bv*bv)),w_bound=wbound,lnA_bound=lnbound,flux_relative_error=ferr,domain_relative_error=domainerr,sampled_stationary_roots=roots,root_search_scope='Sign brackets on specified finite grid only; not exhaustive',profile=filename,profile_sha256=hashlib.sha256((out/filename).read_bytes()).hexdigest()))
    result=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,cases=cases,algebra_only=algebra_only,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional flat held-particle body with vacuum boundary; synthetic discretization checks, not a measured environment or global GR solution.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=len(cases),failed_checks=[x for x in rows if not x['passed']]),indent=2));return result['failed']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--algebra-only',action='store_true');a=p.parse_args();raise SystemExit(bool(run(a.out,a.algebra_only)))
