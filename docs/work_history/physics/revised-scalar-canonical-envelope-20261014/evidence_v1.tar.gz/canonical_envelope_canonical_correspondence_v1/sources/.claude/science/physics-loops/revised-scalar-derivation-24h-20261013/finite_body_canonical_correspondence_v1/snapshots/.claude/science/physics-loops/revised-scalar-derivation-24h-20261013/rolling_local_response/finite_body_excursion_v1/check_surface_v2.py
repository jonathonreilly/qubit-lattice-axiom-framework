#!/usr/local/bin/python3
from pathlib import Path
import argparse, json, hashlib
import numpy as np
import sympy as S

SPHERE_COEFFICIENT = S.Rational(2, 5)
ENVELOPE_COEFFICIENT = 12
HESSIAN_CONNECTION_SIGN = -1

def run(source, out, algebra_only=False):
    out.mkdir(parents=True, exist_ok=False)
    rows=[]; cases=[]; bindings=[]
    def ck(name, passed, detail=None):
        rows.append(dict(name=name, passed=bool(passed), detail=detail))
    def eq(name, expression):
        value=S.factor(S.cancel(expression)); ck(name, value==0, str(value))
    a,s,E,u,nu,Hv2=S.symbols('a s E u nu Hv2', positive=True)
    alpha=S.sqrt(a); F=1+s*E; J=1+(1-3*a)*s*E; K=J/F**2
    derivative=lambda f:S.diff(f,u)+2*alpha*E*S.diff(f,E)
    Ubase=S.Rational(3,2)+S.Rational(3,2)*s*(E-1)**2/F**2
    Ureg=nu*(1+s)*u**2/(2*F**2); U=Ubase+Ureg
    Up=derivative(U); Upp=derivative(Up); Kp=derivative(K)
    base_second=12*a*s*(1+s)*E*(2*E-1+s*E*(2-E))/F**4
    reg_second=nu*(1+s)*(1/F**2-8*alpha*s*E*u/F**3-4*a*s*E*u**2/F**3+12*a*s*s*E*E*u*u/F**4)
    eq('base_second_derivative',derivative(derivative(Ubase))-base_second)
    eq('regulator_second_derivative',derivative(derivative(Ureg))-reg_second)
    eq('kinetic_monotonicity',S.diff(K,E)+s*((1+3*a)+(1-3*a)*s*E)/F**3)
    exact_hessian=derivative(Up/S.sqrt(K))/S.sqrt(K)
    hessian=Upp/K+HESSIAN_CONNECTION_SIGN*Kp*Up/(2*K*K)
    eq('canonical_connection_normalization',exact_hessian-hessian)
    R,r,c=S.symbols('R r c',positive=True)
    V=c*(3*R*R-r*r)/6
    eq('sphere_source_integral',S.integrate(r*r*V,(r,0,R))/(c*R**3/3)-SPHERE_COEFFICIENT*R**2)
    Umax,Fmin,K0=S.symbols('Umax Fmin K0',positive=True)
    envelope=Hv2/K0*(ENVELOPE_COEFFICIENT*a*s*(1+s)**2/Fmin**4+nu*(1+s)*(1/Fmin**2+8*alpha*s*Umax/Fmin**3+12*a*s*s*Umax**2/Fmin**4))
    eq('vacuum_envelope_equals_actual_mass',envelope.subs({Umax:0,Fmin:1+s,K0:K.subs(E,1)})-Hv2*exact_hessian.subs({E:1,u:0}))
    # Direct exact rational witnesses for the coefficient, independently of profiles.
    ck('surface_flux_attraction_sign',SPHERE_COEFFICIENT>0)
    k=S.symbols('k',positive=True); ak=(1-k)*(1+3*k)/4; sk=(1+k)/(k*(1-3*k))
    eq('candidate_vacuum_mass',exact_hessian.subs({E:1,u:0,a:ak,s:sk})-4*(3+3*k+nu)/(1-3*k))
    if not algebra_only:
        src=source/'RESULTS.json'; data=json.loads(src.read_text())
        bindings.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
        ck('source_result_no_failed_checks',data['failed']==0)
        ck('source_case_count',len(data['cases'])==18)
        for case in data['cases']:
            idx=case['index']; path=source/case['profile']; sha=hashlib.sha256(path.read_bytes()).hexdigest()
            ck('profile_identity_'+str(idx),sha==case['profile_sha256'])
            bindings.append(dict(path=str(path),sha256=sha))
            with np.load(path,allow_pickle=False) as zz: p={n:zz[n] for n in zz.files}
            kv=case['k']; av=float(ak.subs(k,kv)); sv=float(sk.subs(k,kv)); nv=case['nu']; hv=case['Hv_R_squared']
            subs={a:av,s:sv,nu:nv}; kval0=float(K.subs({**subs,E:1})); L=1+kv; P=1.5*case['Phi_surface']
            wb=np.sqrt(kv)*P/(1-L*P); umax=wb/np.sqrt(kval0); emin=np.exp(-2*np.sqrt(av)*umax); fmin=1+sv*emin
            B=kv*P*(1-L*P/2)/(1-L*P)**2
            mbar=float(envelope.subs({**subs,Hv2:hv,K0:kval0,Umax:umax,Fmin:fmin}))
            lower=max(0.,kv*np.exp(-B)-float(SPHERE_COEFFICIENT)*kv*mbar/(1-L*P)); upper=kv/(1-L*P)**2
            hits=np.where(p['r']==1.)[0];ck('unique_surface_point_'+str(idx),len(hits)==1); j=int(hits[0])
            eta=float(p['beta'][j]*p['flux'][j]/case['Phi_surface'])
            ck('surface_lower_'+str(idx),eta>=lower-2e-8,dict(eta=eta,lower=lower))
            ck('surface_upper_'+str(idx),eta<=upper+2e-8,dict(eta=eta,upper=upper))
            grid=np.linspace(-umax,0,1001)
            hfun=S.lambdify(u,(hv*hessian).subs(subs).subs(E,S.exp(2*np.sqrt(av)*u)),'numpy')
            Hess=np.asarray(hfun(grid)); peak=float(np.max(Hess))
            ck('sampled_hessian_envelope_'+str(idx),peak<=mbar*(1+2e-8),dict(maximum=peak,envelope=mbar))
            Kfun=S.lambdify(u,K.subs(subs).subs(E,S.exp(2*np.sqrt(av)*u)),'numpy')
            ck('kinetic_lower_bound_'+str(idx),float(np.min(Kfun(grid)))>=kval0*(1-2e-8))
            ck('pointwise_bootstrap_'+str(idx),float(np.max(-p['chi']-np.sqrt(kv)*p['Newton_magnitude']/(1-L*P)))<=2e-8)
            forces=p['beta'][j:]*p['flux'][j:]/case['Phi_surface']
            ck('exterior_nonnegative_'+str(idx),float(np.min(forces))>=-2e-8)
            ck('exterior_nonincreasing_'+str(idx),float(np.max(np.diff(forces)))<=2e-8)
            rec=dict(index=idx,k=kv,Phi_surface=case['Phi_surface'],mu_vac_R=case['mu_vac_R'],P=P,Umax=umax,Mbar_R_squared=mbar,surface_eta=eta,lower=lower,upper=upper,lower_informative=bool(lower>0),profile_sha256=sha,hessian_sample_peak=peak)
            cases.append(rec)
            np.savez_compressed(out/('hessian_'+str(idx)+'.npz'),u=grid,Y_chichi=Hess,Mbar_squared=mbar)
    result=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,cases=cases,source_bindings=bindings,algebra_only=algebra_only,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Exact conditional radial flat held-source force bound; profile checks reuse exposed synthetic cases, not independent observed tests. Numerical Hessian samples do not prove a supremum.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=len(cases),informative_lower_bounds=sum(x['lower_informative'] for x in cases),failed_checks=[x for x in rows if not x['passed']]),indent=2))
    return result['failed']

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--algebra-only',action='store_true');args=parser.parse_args()
    raise SystemExit(bool(run(args.source,args.out,args.algebra_only)))
