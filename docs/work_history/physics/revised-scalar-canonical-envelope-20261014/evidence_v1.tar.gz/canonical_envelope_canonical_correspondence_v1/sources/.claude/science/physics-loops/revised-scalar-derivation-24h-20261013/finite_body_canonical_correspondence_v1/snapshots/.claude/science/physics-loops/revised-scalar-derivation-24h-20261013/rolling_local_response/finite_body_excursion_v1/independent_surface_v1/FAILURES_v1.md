# Findings and preserved execution failures

No mathematical correction was found in the frozen addendum for its radial held-source scope. The review explicitly distinguishes a radial solution from uniqueness of arbitrary solutions for spherical density, and a held bare-gravity mass from measured physical gravity.

The positive independent calculation passed 1735 checks with exit 0 and empty stderr. Seven actual altered reviewer programs then produced, in protocol order, 1, 1, 3, 6, 2, 1 and 3 failed rows. All intended witnesses failed and all altered children exited 1. These intended failures, actual source bytes, diffs and streams are preserved under `damages_v1`; they are not identity-only detection or unexpected positive-run failures.

Fourteen sampled canonical Hessians are negative. This is not a failure: the proof only needs an upper Hessian envelope and a separately established gradient sign. Twelve synthetic lower brackets are zero and remain explicitly uninformative. The baseline records all rows without filtering them out.

The earlier excursion boundary-at-infinity omission and reviewer pre-execution draft correction remain in the immutable prior review. They are reused as history, not erased or repeated as newly executed evidence. No producer numerical evidence was consumed in this review.
