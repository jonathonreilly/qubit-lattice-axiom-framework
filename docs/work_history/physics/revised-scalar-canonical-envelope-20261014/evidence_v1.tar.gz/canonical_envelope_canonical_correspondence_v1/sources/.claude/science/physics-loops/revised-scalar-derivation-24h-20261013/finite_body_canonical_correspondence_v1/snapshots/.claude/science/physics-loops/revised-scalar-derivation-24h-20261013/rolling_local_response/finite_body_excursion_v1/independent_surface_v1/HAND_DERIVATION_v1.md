# Independent surface-force derivation

This is a blind check of the separately frozen addendum. The full action, the corrected excursion proof and its completed independent review are reused by exact identity. No producer program, profile array, extracted surface value or result is read. All derivatives below hold the theory parameters and Einstein-coordinate particle rest density fixed.

## Canonical geometry and a one-sided Hessian envelope

Let alpha=sqrt(a), b=1-3a>0, E=exp(2alpha u), F=1+sE and J=1+bsE. The canonical coordinate satisfies dchi/du=sqrt(K), K=J/F^2. Differentiating the metric with respect to E gives

    K_E=-s[(1+3a)+bsE]/F^3<0.

Consequently K(u)>=K0 on u<=0. Since w=-chi=integral_u^0 sqrt(K(v)) dv, w>=sqrt(K0)|u|. The old bound w<=Wb therefore restricts u to [-Umax,0], Umax=Wb/sqrt(K0). This implication is one-way; the larger u interval need not consist exclusively of points with w<=Wb. Bounding the Hessian on the whole interval is nevertheless sufficient.

Write U=3/2+Ubase+Ureg, with

    Ubase=3s(E-1)^2/(2F^2),
    Ureg=nu(1+s)u^2/(2F^2).

An independent chain-rule derivative may be taken with the operator D_u=partial_u+2alpha E partial_E. It gives

    D_u^2 Ubase=12a s(1+s)E[2E-1+sE(2-E)]/F^4,
    D_u^2 Ureg=nu(1+s)[F^-2-8alpha sEu/F^3
                           -4a sEu^2/F^3+12a s^2E^2u^2/F^4].

For 0<E<=1, E[2E-1+sE(2-E)]<=1+s. This remains true when its bracket is negative. For the regulator, the term proportional to -u^2/F^3 is nonpositive, while -u>=0. Dropping the former and replacing |u| by Umax, E by 1 in positive numerators, and F by Fmin=1+s exp(-2alpha Umax) gives the parent's stated positive numerator envelope.

The canonical Hessian follows by differentiating U_chi=U_u/sqrt(K):

    Y_chichi=Hv^2[U_uu/K-K_u U_u/(2K^2)].

Both K_u and U_u are negative on u<0, so the connection contribution is nonpositive. If U_uu>=0, division by K>=K0 bounds it by the positive numerator envelope divided by K0. If U_uu<0, the same positive envelope is still an upper bound. This argument does not require convexity at every intermediate field value. It gives a uniform upper bound Mbar^2 for the canonical Hessian on the interval.

At the vacuum Y_chi(0)=0. Hence

    -Y_chi(-w)=integral_(-w)^0 Y_chichi(t) dt<=Mbar^2 w.

The left-hand side is nonnegative by the separately checked potential-gradient sign, not by assuming a positive Hessian. As P tends to zero at fixed parameters, Umax tends to zero and Fmin to 1+s. The envelope becomes [12as+nu(1+s)]Hv^2/J0, exactly 4[3(1+k)+nu]Hv^2/(1-3k). Small compactness by itself does not remove a finite mR range correction.

## Pointwise comparison and radial flux

The old positive-operator inequality is w<=sqrt(k)V+L T w. With W<=Wb, T w<=Wb V, so w<=betaMax V where betaMax=sqrt(k)+LWb=sqrt(k)/(1-LP). This stronger pointwise form follows from the old norm bound; it is not a new assumption.

The radial statements require a radial negative-branch solution. Uniform spherical density alone is not a uniqueness theorem for arbitrary solutions of a nonconvex problem. A radial solution is available within the prior existence construction: minimize in the closed radial subspace of H1, apply the same clipping and compactness steps, then average any compact smooth variation over rotations. The functional and its first variation at a radial field are rotation invariant, so zero first variation against radial tests implies the full weak Euler-Lagrange equation. This supplies a radial minimizer without asserting every minimizer is radial.

For such a solution write Fflux=r^2 chi'. Outside the support, Fflux'=r^2Y_chi<=0. If Fflux were negative at any exterior radius it would remain negative at all larger radii, making chi nonincreasing there and incompatible with its limit zero from the nonpositive branch. Therefore Fflux>=0 and chi'>=0 outside, including the matching limit at R. A bounded source jump does not produce a delta function; the canonical field and its normal derivative match across the sphere.

Inside, regularity sets Fflux(0)=0, and the exact radial equation gives

    Fflux(R)=integral_0^R r^2[Y_chi+c A beta] dr
            >=sqrt(k)e^-B cR^3/3-Mbar^2 integral_0^R r^2 w dr.

The held uniform sphere has V=c(3R^2-r^2)/6 and Gvac MStar=cR^3/3. Direct polynomial integration, without using the claimed coefficient, yields

    integral_0^R r^2 V dr=2cR^5/15,
    [integral r^2 V dr]/[Gvac MStar R^2]=2/5.

Using w<=betaMax V gives the lower flux value. Multiplying it by beta(R)>=sqrt(k) is a direct product inequality when that lower value is nonnegative. When it is negative, use the separate physical flux sign and beta>0 to conclude eta>=0; do not apply a false sign-insensitive product rule. These two cases give exactly

    max(0,k e^-B-(2/5)k Mbar^2R^2/(1-LP))<=eta_s.

For the upper bound, Y_chi<=0 and A beta<=betaMax imply Fflux(R)<=betaMax Gvac MStar. Multiplying by beta(R)<=betaMax gives eta_s<=k/(1-LP)^2. The upper and lower bounds have distinct proofs; neither follows merely from the pointwise q bound.

## Exterior force and limits

The dimensionless ratio at r>=R is eta(r)=beta(chi)Fflux/(Gvac MStar). Its derivative is

    eta'=[beta_chi chi' Fflux+beta r^2Y_chi]/(Gvac MStar)<=0.

Every sign is needed: positive mass, beta>0, beta_chi<=0, chi'>=0, Fflux>=0 and Y_chi<=0. Thus a nonzero surface lower bound is not a lower bound at a remote radius. A finite-range scalar may decay to zero. A surface bracket clipped to zero is uninformative about the size of suppression, not evidence for it.

The numerator beta chi' is the conformal test-particle force in the prescribed static model. Gvac MStar is a chosen bare Newton reference with held Einstein particle mass and Einstein radius. It is not a measured physical gravitational mass or a measured Jordan compactness. Scalar field energy, support pressure, metric corrections and different ambient matching remain outside this comparison. The use of c=1 units makes Mbar an inverse length and both Mbar^2R^2 and eta dimensionless.

## Independent profile route

For a distinct solvable normalization control take Y=m^2chi^2/2 and A=1+beta0 chi on the field range of interest. Then A_chi=beta0 is constant, and the exact field equation is (-Delta+m^2)w=c beta0. On sufficiently weak profiles A stays positive and beta=beta0/(1-beta0 w) has the required sign and Lipschitz bounds. This is a synthetic theory on a restricted interval, not a replacement for the candidate potential.

With z=mR the matched exterior solution is

    w(r)=c beta0 R/m^2 [cosh(z)-sinh(z)/z] exp(-mr)/r.

It follows that Fflux(R)/(beta0 Gvac MStar) is

    T(z)=3(1+z)exp(-z)[z cosh(z)-sinh(z)]/z^3
        =1-(2/5)z^2+(1/3)z^3+O(z^4).

Thus the 2/5 coefficient is independently visible in an exact surface response. Removing the potential correction or halving that coefficient will overstate the lower bound in weak-density, small-but-nonzero-mass fixtures. The matter coupling makes eta_s=k T(z)/(1-beta0 w(R)); its correction disappears with compactness. The profile supplies a full flux and exterior derivative control without requiring an actual nonlinear body solve or parent data.
