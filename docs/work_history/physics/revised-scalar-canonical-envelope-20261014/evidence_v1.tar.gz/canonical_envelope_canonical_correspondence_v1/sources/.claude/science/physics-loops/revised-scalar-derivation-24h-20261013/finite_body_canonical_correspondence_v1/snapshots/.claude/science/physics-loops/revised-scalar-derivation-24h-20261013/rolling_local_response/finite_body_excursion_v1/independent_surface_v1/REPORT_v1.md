# Independent surface-force addendum review

The frozen surface-force bracket follows for radial, bounded, decaying negative-branch solutions in the supplied flat held-density model. I found no algebraic correction needed in the potential envelope, its vacuum limit, the factor 2/5, the nonnegative-flux argument, or exterior force monotonicity. The radial domain and the choice of held mass are essential. This is not a measured gravitational normalization, a remote-apparatus lower bound, or a realized nonlinear body calculation.

## Frozen scope and reused evidence

`SURFACE_FORCE_DERIVATION_v1.md` and `SURFACE_FORCE_PROTOCOL_v1.json` were frozen and read in full. Their hashes are respectively `001cab98015f6544a5cbdc7a605333205f307fcc67607702708d6fa89b987a62` and `6759cad495240ae84facfb0e3b833a804897ab51d6c29314fd3dd0f28af960e7`. The corrected excursion derivation and complete supplied action were reused by exact identity, together with the previously sealed independent report, handwritten proof, manifest, receipt and source dispositions. All nine original/snapshot bindings are in `SOURCE_DISPOSITIONS_v1.json`.

The prior excursion seal remains unchanged. Its 598 positive checks and 22 affected proof checks are explicitly reused, not counted as new executions. Its original boundary omission, correction and actual damage failures remain preserved in that prior package. The new review did not open any producer implementation, existing NPZ profile, extracted surface value or result. In particular it does not validate the producer protocol's proposed 2e-8 profile acceptance slack or any existing nonlinear profile. The independent numerical fixtures here were separately declared and use 65-digit arithmetic.

## Full argument checked

The exact metric derivative is negative. Therefore K>=K0 on u<=0 and the canonical excursion bound implies |u|<=Wb/sqrt(K0). The bounding u interval may contain points beyond the actual canonical excursion interval; this makes the Hessian envelope conservative rather than invalid.

Independent differentiation with `D_u=partial_u+2 alpha E partial_E` reproduces both the base and regulator second derivatives. The regulator's negative u-squared term can be discarded for an upper bound. The base numerator remains bounded even where its sign is negative. Since K_u and U_u are both negative, the canonical connection term is nonpositive. Dividing by K0 is justified separately for nonnegative U_uu; for negative U_uu the same positive envelope is automatic. No assumption of global positive canonical Hessian is required.

Integrating the upper Hessian bound from the zero vacuum gradient gives `-Y_chi(-w)<=Mbar^2 w`; nonnegativity comes from the previously checked gradient sign. The P-to-zero envelope equals the exact vacuum Hessian mass at fixed parameters. Singular parameter limits are not covered uniformly. The envelope is action-derived, not an independently assigned mass or screening factor.

The old comparison also gives the stronger pointwise estimate `w<=betaMax V`. Regularity fixes the radial central flux to zero. Integration of the actual matter-plus-potential source then yields the lower surface flux. Direct polynomial integration gives `integral r^2 V dr=2cR^5/15`, while `Gvac MStar=cR^3/3`; their normalized ratio is exactly 2/5. A separate upper flux estimate uses Y_chi<=0 and A beta<=betaMax.

Outside the source, `Fflux=r^2 chi'` is nonincreasing. A negative value would prevent the field from tending to zero from below, so the flux is nonnegative there. The lower-bound product with beta is justified by a two-case argument: multiply the positive lower flux by sqrt(k), or use nonnegative actual flux if the preliminary lower flux is negative. The zero-clipped final bound is therefore valid. An unqualified multiplication of negative lower bounds would not be valid; an explicit rational counterexample is retained among the controls.

Differentiation of `beta Fflux` gives the sum `beta_chi chi' Fflux+beta r^2Y_chi`, with both terms nonpositive. Thus the exterior scalar-to-reference-Newton ratio is nonincreasing. The result does not transport the positive surface lower bound to an arbitrary distant radius. A zero lower bracket is uninformative about actual suppression.

The flux calculation is radial. Uniform spherical density is not, by itself, a uniqueness theorem for every nonlinear solution. The old existence argument can be restricted to radial H1 functions; rotational averaging of variations then gives the full weak equation for the radial minimizer. Thus a radial solution exists within that construction without claiming all solutions are radial. A later uniqueness addendum is outside this review.

## Independent calculations and genuine sensitivity

`HAND_DERIVATION_v1.md` contains the complete independent proof. `check_independent_v1.py` derives exact identities, uses numerical derivatives of the original u-coordinate potential, integrates the canonical metric, and compares a solvable massive spherical profile with its separately derived surface transfer function. It imports no parent helper.

The positive execution completed 1735 checks with zero failures, exit 0 and empty stderr. It contains 24 potential/envelope parameter cases, 312 sampled field states, 24 synthetic surface profiles and 96 exterior readouts. Fourteen sampled canonical Hessians are negative, consistently with the one-sided proof. Twelve synthetic lower bounds clip to zero. These samples test the implementation of the bounds; the analytic inequalities, not grid sampling, establish their interval scope.

The profile control uses a quadratic potential and affine A on the interval where A remains positive. It solves the constant-source massive scalar equation exactly; it is not the candidate nonlinear potential. Its surface transfer has the independent expansion

    T(mR)=1-(2/5)(mR)^2+(1/3)(mR)^3-(6/35)(mR)^4+... .

This supplies a distinct check on the range coefficient and normalization. The test also checks the affine coupling's interval bounds, the exact surface force, exterior sign and the differentiated force product.

Seven actual altered programs were executed on a declared 42-check witness subset. Each run had 12 freshly hashed actual inputs, unchanged over execution. No hash mismatch was used as mathematical detection. Every intended witness failed and every child exited 1:

| Alteration | Passed / failed |
| --- | ---: |
| Reverse the metric derivative sign | 41 / 1 |
| Halve the regulator cross coefficient | 41 / 1 |
| Reverse the canonical connection sign | 39 / 3 |
| Omit the K0 envelope normalization | 36 / 6 |
| Halve the sphere range coefficient | 40 / 2 |
| Omit the range correction | 41 / 1 |
| Change the held-mass flux normalization | 39 / 3 |

In particular, the last two range alterations produce false lower bounds in an actual exact synthetic profile; they are not merely mismatches between repeated formula strings. Full altered files, exact diffs, all failed rows and streams are retained. There was no unexpected positive-run failure. `FAILURES_v1.md` records the distinction.

## Physical and numerical limits

Both c and Mbar squared have inverse-length-squared units in c=1 conventions; Mbar squared times R squared and eta are dimensionless. The reference mass is the held Einstein-coordinate particle mass and Gvac is the bare vacuum coefficient. Scalar energy, support pressure, spacetime response, a measured Jordan mass and different ambient matching are not included. Small compactness must be accompanied by a sufficiently small range correction to make the lower bracket close to k.

This review supplies no fit, calibration, observational likelihood, effective thin-shell factor, body stability result or dynamical selection claim. It is not a formal audit. The parent remains scientific author. `RECEIPT_v1.json` binds the report, source dispositions, command index, complete manifest and decisive computations. No file in this sealed review will be edited for later work.
