"""Actual single-change programs; fresh input freezes for every child."""
from pathlib import Path
import difflib
import hashlib
import json
from execute_v1 import execute

P=Path(__file__).resolve().parent
source=(P/"check_independent_v1.py").read_text()
changes=[
    ("metric_direction","return -s*((1+3*a)+(1-3*a)*s*E)/(1+s*E)**3","return s*((1+3*a)+(1-3*a)*s*E)/(1+s*E)**3","metric_E_derivative"),
    ("regulator_cross_factor","1/F**2-8*alpha*s*E*u/F**3","1/F**2-4*alpha*s*E*u/F**3","regulator_second_derivative"),
    ("canonical_connection_sign","return Uuu/K-Ku*Uu/(2*K*K)","return Uuu/K+Ku*Uu/(2*K*K)","canonical_hessian_chain_rule"),
    ("omit_K0_normalization","return numerator/K0","return numerator","envelope_vacuum_limit"),
    ("halve_sphere_correction","return sp.Rational(2, 5)","return sp.Rational(1, 5)","sphere_integrated_coefficient"),
    ("omit_range_correction","return max(mp.mpf(0), k*mp.exp(-B)-number(sphere_coefficient())*k*massR2/(1-LP))","return k*mp.exp(-B)","profile_surface_bracket"),
    ("flux_mass_normalization","return c*R**3/3","return c*R**3","profile_flux_normalization"),
]
dest=P/"damages_v1"; dest.mkdir(exist_ok=False); summary=[]
for name,before,after,target in changes:
    assert source.count(before)==1
    altered=source.replace(before,after)
    path=dest/(name+".py");path.write_text(altered)
    (dest/(name+".diff")).write_text("".join(difflib.unified_diff(source.splitlines(True),altered.splitlines(True),fromfile="check_independent_v1.py",tofile=name+".py")))
    execution=execute(path,dest/name,witness=True)
    result=json.loads((dest/name/"RESULTS.json").read_text())
    failures=[row["name"] for row in result["checks"] if not row["passed"]]
    summary.append({"name":name,"before":before,"after":after,"source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"required_witness":target,"required_witness_failed":target in failures,"passed":result["passed"],"failed":result["failed"],"exit_code":execution["exit_code"],"inputs_unchanged":execution["inputs_unchanged"],"all_failed_rows":failures,"scope":"Actual witness subset: first potential k/nu/LP, three interval sites, first synthetic profile and two exterior sites."})
(dest/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary))
raise SystemExit(0 if all(x["required_witness_failed"] and x["exit_code"]==1 and x["inputs_unchanged"] for x in summary) else 1)
