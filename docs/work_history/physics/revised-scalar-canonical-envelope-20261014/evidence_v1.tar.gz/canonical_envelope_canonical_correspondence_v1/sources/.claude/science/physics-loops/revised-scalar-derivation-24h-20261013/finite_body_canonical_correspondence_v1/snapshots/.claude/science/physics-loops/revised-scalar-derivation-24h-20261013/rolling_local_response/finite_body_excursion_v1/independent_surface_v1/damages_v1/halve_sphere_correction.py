"""Independent action derivatives, interval bounds and closed surface profiles."""
from pathlib import Path
import argparse
import hashlib
import json
import mpmath as mp
import sympy as sp

mp.mp.dps = 65
checks = []

def encode(v):
    return mp.nstr(v, 57) if isinstance(v, mp.mpf) else str(v)

def ck(name, passed, **detail):
    checks.append({"name": name, "passed": bool(passed), "detail": {k: encode(v) for k, v in detail.items()}})

def close(x, y):
    return abs(x-y) <= mp.mpf("1e-40") * max(1, abs(x), abs(y))

def le(x, y):
    return x <= y or close(x, y)

def number(x):
    q = sp.Rational(x)
    return mp.mpf(int(q.p)) / int(q.q)

def parameters(k):
    return (1-k)*(1+3*k)/4, (1+k)/(k*(1-3*k))

def metric_E_claim(a, s, E):
    return -s*((1+3*a)+(1-3*a)*s*E)/(1+s*E)**3

def base_second_claim(a, s, E):
    return 12*a*s*(1+s)*E*(2*E-1+s*E*(2-E))/(1+s*E)**4

def regulator_second_claim(alpha, s, nu, E, u):
    F=1+s*E
    return nu*(1+s)*(1/F**2-8*alpha*s*E*u/F**3-4*alpha**2*s*E*u**2/F**3+12*alpha**2*s**2*E**2*u**2/F**4)

def canonical_hessian_claim(Uu, Uuu, K, Ku):
    return Uuu/K-Ku*Uu/(2*K*K)

def envelope_claim(a, s, nu, umax, fmin, K0):
    numerator=12*a*s*(1+s)**2/fmin**4+nu*(1+s)*(1/fmin**2+8*mp.sqrt(a)*s*umax/fmin**3+12*a*s*s*umax*umax/fmin**4)
    return numerator/K0

def sphere_coefficient():
    return sp.Rational(1, 5)

def lower_claim(k, B, LP, massR2):
    return max(mp.mpf(0), k*mp.exp(-B)-number(sphere_coefficient())*k*massR2/(1-LP))

def mass_reference(c, R):
    return c*R**3/3

def action(k, nu, u):
    a,s=parameters(k); E=mp.exp(2*mp.sqrt(a)*u); F=1+s*E; J=1+(1-3*a)*s*E
    U=mp.mpf(3)/2+3*s*(E-1)**2/(2*F**2)+nu*(1+s)*u*u/(2*F**2)
    return U,J/F**2

def synthetic_w(r, R, m, c, beta0):
    z=m*R; pref=c*beta0/(m*m)
    if r == 0:
        return pref*(1-(1+z)*mp.exp(-z))
    if r < R:
        return pref*(1-(1+z)*mp.exp(-z)*mp.sinh(m*r)/(m*r))
    return pref*R*(mp.cosh(z)-mp.sinh(z)/z)*mp.exp(-m*r)/r

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--inputs",required=True); ap.add_argument("--output",required=True); ap.add_argument("--witness-only",action="store_true")
    args=ap.parse_args(); home=Path(args.inputs); protocol=json.loads((home/"INDEPENDENT_PROTOCOL_v1.json").read_text())
    E,u,alpha,s,nu=sp.symbols("E u alpha s nu", positive=True)
    a=alpha**2; F=1+s*E; J=1+(1-3*a)*s*E; K=J/F**2
    D=lambda expression: sp.diff(expression,u)+2*alpha*E*sp.diff(expression,E)
    base=sp.Rational(3,2)*s*(E-1)**2/F**2; reg=nu*(1+s)*u*u/(2*F**2)
    ck("metric_E_derivative",sp.factor(sp.diff(K,E)-metric_E_claim(a,s,E))==0)
    ck("base_second_derivative",sp.factor(D(D(base))-base_second_claim(a,s,E))==0)
    ck("regulator_second_derivative",sp.factor(D(D(reg))-regulator_second_claim(alpha,s,nu,E,u))==0)
    Uu=D(base+reg); Uuu=D(Uu); Ku=D(K)
    direct_hessian=D(Uu/sp.sqrt(K))/sp.sqrt(K)
    ck("canonical_hessian_chain_rule",sp.factor(direct_hessian-canonical_hessian_claim(Uu,Uuu,K,Ku))==0)
    r,R,c=sp.symbols("r R c",positive=True)
    polynomial_integral=sp.integrate(r*r*c*(3*R*R-r*r)/6,(r,0,R))
    coefficient=sp.simplify(polynomial_integral/(c*R**3/3*R*R))
    ck("sphere_integrated_coefficient",coefficient==sphere_coefficient(),derived=coefficient)
    z=sp.symbols("z",positive=True)
    T=3*(1+z)*sp.exp(-z)*(z*sp.cosh(z)-sp.sinh(z))/z**3
    Tseries=sp.series(T,z,0,5).removeO().expand()
    ck("surface_small_mass_constant",Tseries.coeff(z,0)==1)
    ck("surface_small_mass_quadratic",Tseries.coeff(z,2)==-sp.Rational(2,5),series=Tseries)
    ck("surface_small_mass_cubic",Tseries.coeff(z,3)==sp.Rational(1,3))
    # A negative lower flux does not permit an independent beta lower bound
    # to be multiplied without a flux sign. This is a counterexample to that step.
    ck("negative_product_counterexample",3*sp.Rational(-1,2)<1*sp.Rational(-1))
    for lower in [sp.Rational(-2),sp.Rational(0),sp.Rational(1,3)]:
        for actual in [max(0,lower),max(0,lower)+sp.Rational(1,7)]:
            ck("nonnegative_flux_two_case_product",3*actual>=max(0,lower))

    ks=protocol["potential_k"][:1] if args.witness_only else protocol["potential_k"]
    nus=protocol["potential_nu"][:1] if args.witness_only else protocol["potential_nu"]
    lps=protocol["LP"][:1] if args.witness_only else protocol["LP"]
    fractions=[mp.mpf(0),mp.mpf(".5"),mp.mpf(1)] if args.witness_only else [mp.mpf(j)/12 for j in range(13)]
    potential_rows=[]; case_rows=[]
    for kval in ks:
        kr=sp.Rational(kval); ar,sr=parameters(kr); K0r=(1+(1-3*ar)*sr)/(1+sr)**2
        for nval in nus:
            nr=sp.Rational(nval)
            # At Umax=0 the sqrt term vanishes. This route is exact rational.
            claimed_vacuum=(12*ar*sr/(1+sr)**2+nr/(1+sr))/K0r
            ck("vacuum_mass_exact",sp.simplify(claimed_vacuum-4*(3*(1+kr)+nr)/(1-3*kr))==0,k=kval,nu=nval)
            k=number(kval); n=number(nval); a,sn=parameters(k); L=1+k; K0=action(k,n,mp.mpf(0))[1]
            actual_vacuum=mp.diff(lambda uu:action(k,n,uu)[0],mp.mpf(0),2)/K0
            envelope0=envelope_claim(a,sn,n,mp.mpf(0),1+sn,K0)
            ck("envelope_vacuum_limit",close(envelope0,actual_vacuum),k=kval,nu=nval,actual=actual_vacuum,claimed=envelope0)
            for lpval in lps:
                lp=number(lpval); P=lp/L; Wb=mp.sqrt(k)*P/(1-lp); umax=Wb/mp.sqrt(K0); fmin=1+sn*mp.exp(-2*mp.sqrt(a)*umax)
                envelope=envelope_claim(a,sn,n,umax,fmin,K0)
                canonical=lambda uu:mp.quad(lambda vv:mp.sqrt(action(k,n,vv)[1]),[uu,0]) if uu else mp.mpf(0)
                u_bound_w=canonical(-umax)
                ck("excursion_interval_inclusion",le(Wb,u_bound_w),k=kval,nu=nval,LP=lpval)
                min_hessian=mp.inf; max_hessian=-mp.inf
                for fraction in fractions:
                    uu=-umax*fraction; Uval,Kval=action(k,n,uu)
                    grad=mp.diff(lambda vv:action(k,n,vv)[0],uu)/mp.sqrt(Kval)
                    raw_hessian=mp.diff(lambda vv:mp.diff(lambda tt:action(k,n,tt)[0],vv)/mp.sqrt(action(k,n,vv)[1]),uu)/mp.sqrt(Kval)
                    raw_u2=mp.diff(lambda vv:action(k,n,vv)[0],uu,2)
                    raw_u1=mp.diff(lambda vv:action(k,n,vv)[0],uu)
                    raw_K1=mp.diff(lambda vv:action(k,n,vv)[1],uu)
                    formula=canonical_hessian_claim(raw_u1,raw_u2,Kval,raw_K1)
                    ww=canonical(uu)
                    ck("metric_interval_lower_bound",le(K0,Kval),k=kval,nu=nval,LP=lpval,fraction=fraction)
                    ck("hessian_independent_chain",close(raw_hessian,formula),k=kval,nu=nval,LP=lpval,fraction=fraction)
                    ck("potential_hessian_envelope",le(raw_hessian,envelope),k=kval,nu=nval,LP=lpval,fraction=fraction)
                    ck("integrated_slope_envelope",le(0,-grad) and le(-grad,envelope*ww),k=kval,nu=nval,LP=lpval,fraction=fraction)
                    min_hessian=min(min_hessian,raw_hessian); max_hessian=max(max_hessian,raw_hessian)
                    potential_rows.append({"k":kval,"nu":nval,"LP":lpval,"fraction":encode(fraction),"u":encode(uu),"w":encode(ww),"K":encode(Kval),"Ychi_over_Hv2":encode(grad),"Hessian_over_Hv2":encode(raw_hessian),"Mbar2_over_Hv2":encode(envelope)})
                case_rows.append({"k":kval,"nu":nval,"LP":lpval,"P":encode(P),"Umax":encode(umax),"Wb":encode(Wb),"Mbar2_over_Hv2":encode(envelope),"min_sampled_hessian":encode(min_hessian),"max_sampled_hessian":encode(max_hessian)})

    profile_rows=[]; exterior_rows=[]
    pks=protocol["profile_k"][:1] if args.witness_only else protocol["profile_k"]
    pps=protocol["profile_P"][:1] if args.witness_only else protocol["profile_P"]
    pzs=protocol["profile_mR"][:1] if args.witness_only else protocol["profile_mR"]
    for kval in pks:
        k=number(kval); beta0=mp.sqrt(k); L=1+k
        for pval in pps:
            P=number(pval); R=number(protocol["profile_R"]); c=2*P/R**2; LP=L*P; B=k*P*(1-LP/2)/(1-LP)**2
            GM_direct=mp.quad(lambda rr:c*rr*rr,[0,R]); GM=mass_reference(c,R)
            for zval in pzs:
                z=number(zval); m=z/R; wf=lambda rr:synthetic_w(rr,R,m,c,beta0)
                w0=wf(mp.mpf(0)); wR=wf(R); AR=1-beta0*wR; A0=1-beta0*w0; betaR=beta0/AR
                flux=-R*R*mp.diff(wf,R,direction=1)
                Tval=3*(1+z)*mp.exp(-z)*(z*mp.cosh(z)-mp.sinh(z))/z**3
                eta=betaR*flux/GM; lower=lower_claim(k,B,LP,z*z); upper=k/(1-LP)**2
                ck("profile_positive_affine_A",A0>0,k=kval,P=pval,mR=zval)
                ck("profile_beta_L_bound",le(k/(A0*A0),L),k=kval,P=pval,mR=zval)
                ck("profile_log_A_bound",le(-mp.log(A0),B),k=kval,P=pval,mR=zval)
                ck("profile_flux_normalization",close(flux/GM,beta0*Tval) and close(GM,GM_direct),k=kval,P=pval,mR=zval)
                ck("profile_surface_bracket",le(lower,eta) and le(eta,upper),k=kval,P=pval,mR=zval,lower=lower,eta=eta,upper=upper)
                ck("profile_exact_surface_force",close(eta,k*Tval/AR),k=kval,P=pval,mR=zval)
                profile_rows.append({"k":kval,"P":pval,"mR":zval,"w0":encode(w0),"wR":encode(wR),"eta":encode(eta),"lower":encode(lower),"upper":encode(upper),"T":encode(Tval),"Gvac_MStar":encode(GM),"bracket_informative":bool(lower>0)})
                ratios=protocol["exterior_radius_over_R"][:2] if args.witness_only else protocol["exterior_radius_over_R"]
                for ratio in ratios:
                    rr=number(ratio)*R; w=wf(rr); chi1=-mp.diff(wf,rr,direction=1); Fflux=rr*rr*chi1; beta=beta0/(1-beta0*w)
                    eta_fn=lambda zz:beta0/(1-beta0*wf(zz))*(-zz*zz*mp.diff(wf,zz,direction=1))/GM
                    derivative=mp.diff(eta_fn,rr,direction=1)
                    product_derivative=(-beta0**2/(1-beta0*w)**2*chi1*Fflux+beta*rr*rr*(-m*m*w))/GM
                    ck("profile_exterior_sign",le(0,Fflux),k=kval,P=pval,mR=zval,r_over_R=ratio)
                    ck("profile_exterior_monotonic",le(derivative,0),k=kval,P=pval,mR=zval,r_over_R=ratio)
                    ck("profile_exterior_product_rule",close(derivative,product_derivative),k=kval,P=pval,mR=zval,r_over_R=ratio)
                    exterior_rows.append({"k":kval,"P":pval,"mR":zval,"r_over_R":ratio,"flux":encode(Fflux),"eta":encode(eta_fn(rr)),"eta_prime":encode(derivative)})
    result={"scope":"Independent exact action/spherical controls; no producer implementation or profile results read.","source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"precision":mp.mp.dps,"witness_only":args.witness_only,"passed":sum(c["passed"] for c in checks),"failed":sum(not c["passed"] for c in checks),"checks":checks,"exact_surface_series":str(Tseries),"potential_cases":case_rows,"potential_rows":potential_rows,"synthetic_profile_rows":profile_rows,"synthetic_exterior_rows":exterior_rows}
    Path(args.output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"passed":result["passed"],"failed":result["failed"],"potential_cases":len(case_rows),"potential_rows":len(potential_rows),"profile_rows":len(profile_rows),"exterior_rows":len(exterior_rows)}))
    raise SystemExit(1 if result["failed"] else 0)

if __name__=="__main__":main()
