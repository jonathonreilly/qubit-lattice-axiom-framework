"""Freeze actual reviewer inputs and retain the complete execution."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

P=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def execute(source, destination, witness=False):
    destination.mkdir(exist_ok=False)
    frozen=json.loads((P/"FREEZE_v1.json").read_text())
    actual=[source,P/"HAND_DERIVATION_v1.md",P/"INDEPENDENT_PROTOCOL_v1.json"]+[P/x["snapshot_path"] for x in frozen["sources"]]
    rows=[{"path":str(x),"bytes":x.stat().st_size,"sha256":sha(x)} for x in actual]
    (destination/"FREEZE.json").write_text(json.dumps({"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"actual_inputs":rows,"detection_uses_mathematical_witnesses_not_original_hash_comparison":True},indent=2)+"\n")
    argv=[sys.executable,"-B",str(source),"--inputs",str(P),"--output",str(destination/"RESULTS.json")]
    if witness:argv.append("--witness-only")
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc=subprocess.run(argv,cwd=P,text=True,capture_output=True,timeout=120)
    finish=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (destination/"stdout.txt").write_text(proc.stdout);(destination/"stderr.txt").write_text(proc.stderr)
    record={"argv":argv,"cwd":str(P),"started_utc":start,"finished_utc":finish,"exit_code":proc.returncode,"source_sha256":sha(source),"inputs_unchanged":all(sha(Path(x["path"]))==x["sha256"] for x in rows)}
    (destination/"EXECUTION.json").write_text(json.dumps(record,indent=2)+"\n")
    return record

if __name__=="__main__":
    record=execute(P/"check_independent_v1.py",P/"baseline_v1")
    print(json.dumps(record))
    raise SystemExit(record["exit_code"])
