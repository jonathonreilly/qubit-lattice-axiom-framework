# Focused independent finite-body excursion review

The conditional comparison, bootstrap, coupling derivative and energy bounds follow from the supplied action in the stated held-density, flat elliptic model. The original existence outline omitted a necessary justification of decay after taking its weak variational limit. The separately preserved v2 adds a valid argument using the original assumptions; no additional smooth-density premise is needed. This review does not establish a realized environmental state, a nonlinear body's measured charge, a dynamical basin, or a full relativistic solution.

## Source and independence

The complete original handwritten derivation and protocol were frozen before checking. The complete supplied confinement action was frozen separately for its metric, potential, conformal coupling and parameter domain. The complete v2 derivation, exact change diff and correction record were then inspected. Six original/snapshot pairs are enumerated in `SOURCE_DISPOSITIONS_v1.json`; original v1 and its protocol remain unchanged. The protocol's old v1 hash is historical provenance, not a claim to bind the later paragraph.

No parent implementation, grid or result was opened, executed or imported. All positive calculations here are from independent action differentiation, canonical-coordinate quadrature, exact variational identities and a synthetic linear sphere compared with a separately integrated Green kernel. The parent remains the author. This is a bounded mathematical check, not a formal audit or a status promotion. The subsequent surface-force addendum is outside this seal.

## Mathematical disposition

With `E=exp(2 sqrt(a) u)`, `F=1+sE`, `J=1+(1-3a)sE`, the canonical coordinate obeys `dchi/du=sqrt(J)/F`. This chi differs from the bounded coordinate with the same name in the older confinement note. At fixed theory parameters, `beta=sqrt(a)/sqrt(J)` and `q=a/J`. Differentiating in u and dividing by the canonical Jacobian gives exactly

    -d beta/dchi=(1+k) A^2 (1-3q)^2/(1-3k)^2.

On chi<=0 its sharp ceiling is `L=1+k`; the ceiling is attained at the vacuum. It cannot be extended to the positive branch. The two resulting upper bounds on `-ln A` are separate inequalities, not an ordered chain.

The density held fixed is `rhoStar=m_J n_E`, so `rho_E=A rhoStar` and `rho_J=rhoStar/A^3`. The action's gradient coefficient is Q, not Q/2. Variation consequently gives `Delta chi=Y_chi+rhoStar A_chi/(2Q)`. The bare vacuum constant is `Gvac=1/(8 pi Q)`. The dimensionless potential V satisfies `-Delta V=4 pi Gvac rhoStar`; its source has inverse-length-squared units. Replacing held density by physical density without the conformal conversion would alter the problem.

The actual negative-branch potential derivative is negative. Its positive nu regulator produces a strictly positive quadratic tail in the canonical coordinate, and the vacuum Hessian is positive. Continuity supplies coercivity for each fixed parameter choice. The claim is not uniform in nu approaching zero or k approaching the excluded endpoints.

For a bounded decaying negative-branch solution, the weak maximum principle gives `0<=w=-chi<=sqrt(a)V`. A positive Newton operator with norm `P=max V` then gives the sharper closure only when `LP<1`:

    W<=sqrt(k)P/(1-LP),
    q<=k/(1-LP)^2,
    -ln A<=kP(1-LP/2)/(1-LP)^2.

The exact ceiling q<a also remains available. Failure of LP<1 is a failure of this closure, not a nonexistence theorem. For a uniform held sphere, `P=3 Gvac MStar/(2R)` follows from both interior and exterior matching. This is not measured Jordan compactness. Neither a pointwise beta bound nor the excursion bound fixes the integrated exterior scalar force, because the potential term also contributes to the flux.

## Existence finding and v2 closure

The direct method works on the nonpositive H1 cone: coercivity gives weak compactness, local compactness gives an almost-everywhere subsequence, the positive potential is lower semicontinuous, and compactly supported matter permits dominated convergence. Negative-tail clipping makes the minimizer bounded below; positive clipping makes it a local unconstrained minimizer within the canonical chart. Its weak equation has no spurious obstacle measure.

The original statement then needed to recover the stipulated pointwise boundary condition. H1 membership alone cannot do this. A preserved counterexample consists of disjoint unit-height bumps of radii 2^-n centered at escaping points: both L2 and gradient norms converge while the values at their centers stay one. Their Laplacians are not uniformly bounded.

The v2 paragraph removes precisely that gap. The bounded minimizer and bounded density make the elliptic forcing globally bounded. Translation-uniform local W2p estimates with p>3 yield uniform continuity. If the field did not tend uniformly to zero, disjoint balls of a fixed radius would each carry a fixed positive L2 mass, contradicting H1. The repaired variational solution therefore lies in the boundary class needed by the comparisons. Bounded density jumps are allowed; the equation is weak and does not authorize a surface delta source or a separate Dirichlet condition at the matter boundary.

The energy bounds follow from comparison with the zero trial field and from testing the weak equation with cutoff approximations to chi. The needed terms are integrable on the bounded solution range. Existence does not prove uniqueness, stability or dynamical realization. Support stresses, metric backreaction, an ambient cosmological matching prescription, and a measured gravitational normalization remain outside the flat held-source construction. The nonzero vacuum scale especially precludes interpreting its auxiliary infinity as an exact globally Minkowski gravitational spacetime.

## Independent computations and sensitivity

`HAND_DERIVATION_v1.md` gives the full independent derivation. `INDEPENDENT_PROTOCOL_v1.json` fixes rational parameter choices and a 65-digit calculation before execution. The baseline completed 598 checks with zero failures, exit 0 and empty stderr. It includes eight exact coercivity/mass coefficient rows, 24 canonical-coordinate rows and 144 linear-sphere profile rows. The linear massive sphere is a synthetic matching and normalization control, not the nonlinear candidate body. Its closed profile is compared with an independently integrated Yukawa Green formula, and its interface value, flux, differential equation, comparison and energy identity are checked.

Five actual altered programs were run on a declared 51-check witness subset, with fresh hashes of all nine actual inputs for every run. Each exited 1 on its intended mathematical witness; identity mismatches were not used as detection.

| Actual alteration | Passed / failed | Decisive witness |
| --- | ---: | --- |
| Reverse the comparison Laplacian sign | 50 / 1 | Maximum-principle sign |
| Halve the kinetic normalization | 47 / 4 | Held-density force coefficient |
| Omit the bootstrap denominator | 45 / 6 | Positive-operator fixed point |
| Remove a power from the beta denominator | 47 / 4 | Direct action derivative |
| Omit the nu confinement term | 48 / 3 | Canonical negative-tail coercivity |

The affected v2 check completed 22 checks with zero failures. It verifies the exact single-paragraph change, all six original/snapshot identities, the historical protocol binding and the independent H1/continuity argument. It did not rerun the unchanged positive science.

All actual streams, source versions, exact diffs and executions are retained. A reviewer draft also contained an incorrectly chained pair of independent upper bounds; this was caught and corrected before execution or sealing, with both versions and the exact diff preserved. `FAILURES_v1.md` distinguishes that draft error, the original proof omission and intended damage failures. No unexpected baseline execution failure is hidden.

## Recovery and seal

`COMMAND_INDEX_v1.json` records the actual executed argv and outer entrypoints. `SOURCE_DISPOSITIONS_v1.json` maps all six read source versions to exact recovery bytes and current source hashes. `MANIFEST_v1.json` inventories the complete review package except itself and the final receipt; `RECEIPT_v1.json` binds that manifest, this report, dispositions and decisive evidence. Neither receipt nor report will be edited after this seal. Any subsequent correction must be a separately named amendment.
