"""Finalize stored independent evidence without a scientific replay."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import sys

P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def write(name,obj):
    p=P/name;assert not p.exists(),f"Refuse overwrite {p}"
    p.write_text(json.dumps(obj,indent=2)+"\n")

assert not (P/"MANIFEST_v1.json").exists() and not (P/"RECEIPT_v1.json").exists()
dispositions=[]
for row in read("FREEZE_v1.json")["sources"]:
    original=Path(row["original_path"]);snapshot=P/row["snapshot_path"]
    assert sha(original)==sha(snapshot)==row["sha256"]
    assert original.read_bytes()==snapshot.read_bytes()
    dispositions.append({"original_path":str(original),"original_sha256":row["sha256"],"disposition":"Fully read new source or exact reused proof/evidence dependency; preserved unchanged.","recovery":str(snapshot),"recovery_sha256":sha(snapshot),"final_path":str(original),"final_sha256":sha(original)})
prior=P.parent/"independent_v1"
oldm=json.loads((prior/"MANIFEST_v1.json").read_text());oldr=json.loads((prior/"RECEIPT_v1.json").read_text())
assert sha(prior/"RECEIPT_v1.json")=="f31cb02003bebee1251a963fdb4b76151c841dd7a023cc4604db5803cb33cb43"
old_checks=[]
for row in oldm["artifacts"]:
    assert sha(prior/row["path"])==row["sha256"]
    old_checks.append({"path":str(prior/row["path"]),"sha256":row["sha256"]})
for row in oldr["bindings"]:assert sha(prior/row["path"])==row["sha256"]
assert len(old_checks)==72
baseline=read("baseline_v1/RESULTS.json")
assert (baseline["passed"],baseline["failed"])==(1735,0)
assert len(baseline["potential_cases"])==24 and len(baseline["potential_rows"])==312
assert len(baseline["synthetic_profile_rows"])==24 and len(baseline["synthetic_exterior_rows"])==96
assert sha(P/"check_independent_v1.py")==baseline["source_sha256"]
damage=read("damages_v1/SUMMARY.json")
expected=[(41,1),(41,1),(39,3),(36,6),(40,2),(41,1),(39,3)]
runs=["baseline_v1"]+["damages_v1/"+x["name"] for x in damage];commands=[]
for i,run in enumerate(runs):
    r=read(run+"/RESULTS.json");e=read(run+"/EXECUTION.json");f=read(run+"/FREEZE.json")
    assert len(f["actual_inputs"])==12
    for x in f["actual_inputs"]:assert sha(Path(x["path"]))==x["sha256"]
    assert e["inputs_unchanged"] and e["source_sha256"]==r["source_sha256"]
    assert sum(x["passed"] for x in r["checks"])==r["passed"]
    assert sum(not x["passed"] for x in r["checks"])==r["failed"]
    if i:
        d=damage[i-1];assert (r["passed"],r["failed"])==expected[i-1]
        assert d["required_witness_failed"] and e["exit_code"]==1
        assert any(x["name"]==d["required_witness"] and not x["passed"] for x in r["checks"])
        assert sha(P/("damages_v1/"+d["name"]+".py"))==d["source_sha256"]
    else:assert e["exit_code"]==0
    commands.append({"record":run+"/EXECUTION.json",**e})

write("SOURCE_DISPOSITIONS_v1.json",{"original_dispositions":dispositions})
write("REUSE_VERIFICATION_v1.json",{"prior_receipt":str(prior/"RECEIPT_v1.json"),"receipt_sha256":sha(prior/"RECEIPT_v1.json"),"verified_prior_artifacts":old_checks,"prior_receipt_bindings_checked":len(oldr["bindings"]),"reused_not_reexecuted":{"baseline_passed":598,"baseline_failed":0,"affected_v2_passed":22,"affected_v2_failed":0},"no_prior_seal_mutation":True})
write("COMMAND_INDEX_v1.json",{"executions":commands,"outer_entrypoints":["python3 -B execute_v1.py","python3 -B damage_controls_v1.py"],"seal_argv":[sys.executable,"-B",str(Path(__file__).resolve())],"seal_scope":"Identity-only read of stored outputs; no producer or independent scientific replay."})
write("ENVIRONMENT_v1.json",{"python":sys.version,"platform":platform.platform(),"precision":baseline["precision"],"producer_results_read":False})
artifacts=[]
for path in sorted(P.rglob("*")):
    if path.is_file():
        assert not path.is_symlink()
        artifacts.append({"path":str(path.relative_to(P)),"bytes":path.stat().st_size,"sha256":sha(path)})
write("MANIFEST_v1.json",{"schema":"closed-artifacts-v1","excludes":["MANIFEST_v1.json","RECEIPT_v1.json"],"artifacts":artifacts})
names=["REPORT_v1.md","MANIFEST_v1.json","SOURCE_DISPOSITIONS_v1.json","HAND_DERIVATION_v1.md","INDEPENDENT_PROTOCOL_v1.json","FAILURES_v1.md","REUSE_VERIFICATION_v1.json","COMMAND_INDEX_v1.json","baseline_v1/RESULTS.json","baseline_v1/EXECUTION.json","damages_v1/SUMMARY.json"]
write("RECEIPT_v1.json",{"sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Blind surface-force addendum only; radial held-source model, exact prior excursion reuse; no producer implementation/profile evidence or later uniqueness addendum.","artifact_count":len(artifacts),"source_pair_count":len(dispositions),"passed":1735,"failed":0,"actual_damaged_programs":7,"all_intended_damage_witnesses_failed":True,"original_dispositions":"SOURCE_DISPOSITIONS_v1.json","bindings":[{"path":x,"sha256":sha(P/x)} for x in names],"immutable_policy":"No edits after sealing; any amendment must be separately named and preserve these bytes."})
for name in ["REPORT_v1.md","MANIFEST_v1.json","RECEIPT_v1.json","SOURCE_DISPOSITIONS_v1.json"]:print(name,sha(P/name))
print("artifacts",len(artifacts),"source_pairs",len(dispositions))
