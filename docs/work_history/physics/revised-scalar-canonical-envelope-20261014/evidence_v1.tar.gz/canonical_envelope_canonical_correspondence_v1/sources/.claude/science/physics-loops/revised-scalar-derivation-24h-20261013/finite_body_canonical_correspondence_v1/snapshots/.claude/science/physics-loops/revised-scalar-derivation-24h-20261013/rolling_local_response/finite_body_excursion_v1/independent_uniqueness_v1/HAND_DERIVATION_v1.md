# Independent uniqueness and held-source scalar stability derivation

The exact new handwritten versions and protocol were frozen with the supplied action and prior checked proofs. A filename-selection failure also exposed producer execution metadata and an aggregate count, as fully recorded in READ_SCOPE_FAILURE_v1.md. No producer implementation or individual result rows are used. This derivation and its calculations remain independent; complete blindness is not claimed.

## Interval and exact action derivatives

All parameters k, nu, Q and Hv are fixed, with 0<k<1/3 and the positive quantities specified by the supplied action. Set a=(1-k)(1+3k)/4, alpha=sqrt(a), b=1-3a, s=(1+k)/(k(1-3k)), E=exp(2alpha u), F=1+sE, J=1+bsE and K=J/F^2. The canonical coordinate has dchi/du=sqrt(J)/F.

The prior excursion theorem gives w=-chi<=Wb and K>=K0 on u<=0. Thus |u|<=Umax=Wb/sqrt(K0). Under 2alpha Umax<=ln2, the whole solution range and every segment between two solutions lie inside the compact interval u in [-ln2/(2alpha),0], hence E in [1/2,1]. The state range is compact in chi as well, because the coordinate map is smooth and strictly increasing there.

For Ubase=3s(E-1)^2/(2F^2), direct differentiation first gives

    Ubase_chi=6alpha s(1+s) E(E-1)/(F^2 sqrt(J)).

Differentiating this expression and dividing by the canonical Jacobian gives

    Ubase_chichi=6a s(1+s)E/(F^2J^2)
       * {2J[(2E-1)+sE]-bsE(E-1)F}.

The first brace contribution is strictly positive even at E=1/2 because sE>0. The second is nonnegative. Therefore the base curvature is strictly positive throughout the closed interval.

For the regulator, define g=u/F. Its first derivative is h/sqrt(J), h=1-2alpha sEu/F. Differentiate h directly:

    h_u=-2alpha sE/F [1+2alpha u/F].

The canonical second derivative is consequently

    g_chichi=-2alpha sE/J [1+2alpha u/F]
              -alpha bsEF/J^2 [1-2alpha sEu/F].

Here h>=1 and 1+2alpha u/F>=1-ln2/F>0; both terms are negative. Since g<=0,

    Ureg_chichi=nu(1+s)(g_chi^2+g g_chichi)>0.

Thus Y_chichi=Hv^2 U_chichi is strictly positive on the complete reachable interval, including both endpoints. This is an interval theorem, not global convexity of the supplied potential. Continuity on this compact interval gives a positive mMin^2 at fixed interior parameters; no grid minimum is needed as a proof or substituted for that exact definition.

The prior exact beta derivative implies beta_chi>=-L, L=1+k. Since A_chichi=A(beta^2+beta_chi), 0<A<=1 and beta^2>=0, one has A_chichi>=-L. Multiplication of a negative lower bound by A<=1 gives -AL>=-L. At the vacuum the exact value is A_chichi=-1, which is a useful independent normalization check.

An equivalent explicit form of the compactness condition can be obtained without numerical inversion. K0=k(1-3k)^2/(16a), so

    2alpha Umax=8aP/[(1-3k)(1-LP)],
    P<=Pcrit=ln2(1-3k)/[8a+L ln2(1-3k)].

The strict LP<1 premise is retained. This equivalent threshold is only a check of the stated criterion, not a claim that larger sources are nonunique.

## Kato comparison with the boundary kept explicit

For two bounded decaying negative-branch solutions of the same source equation, let d=chi1-chi2. Their bounded fields and bounded source give local W2p regularity for finite p. The difference equation is

    Delta d = hY d+c hA d,

where the mean-value coefficients satisfy hY>=0 and hA>=-L on the shared interval. The distributional Kato inequality states Delta|d|>=sgn(d)Delta d. Therefore

    -Delta|d|<=-hY|d|-c hA|d|<=Lc|d|.

The inequality remains valid at zeros in the distributional sense; a pointwise division by d there is unnecessary. Since c is bounded with compact support and d is bounded, its positive Newton potential is finite and decays. Set z=|d|-L N[c|d|]. Then Delta z>=0 and z tends to zero at infinity. The maximum principle on expanding balls, followed by the boundary limit, gives z<=0. Taking the supremum yields ||d||<=LP||d||; the finite norm and LP<1 force d=0.

The zero boundary is essential. A nonzero ambient difference or a boundary term at a finite apparatus would require an added term in the estimate. The repaired prior existence proof supplies a solution in the required boundary class; uniqueness concerns only bounded decaying negative-branch solutions of this fixed-source equation.

Rotating a solution for a rotationally symmetric density produces another solution in the same class. Uniqueness therefore proves radial symmetry under the new sufficient condition. This does not claim a theorem of symmetry for arbitrary solutions outside that condition. The separately versioned surface-v2 opening makes its radial hypothesis explicit without changing any equation.

## Changing the source

For c1,c2 and the same fixed theory, split the difference as

    Delta d=DeltaY_chi+c1 DeltaA_chi+(c1-c2)A_chi(chi2).

With a common convex interval and a common bound |A_chi|<=betaMax, Kato gives

    -Delta|d|<=Lc1|d|+betaMax |c1-c2|.

After Newton comparison and suprema,

    ||d||<=[betaMax ||N[|c1-c2|]||]/(1-LP1).

The denominator belongs to the source chosen in the splitting, here c1. Both solutions must lie in the same proved interval, and LP1<1 is indispensable. This estimates static field response to a prescribed source perturbation. It does not identify that perturbation with free matter motion, a change of physical mass, or a dynamical settling rate.

## Ground-state identity and form domain

For a nonzero bounded compact source c>=0, V=N[c]>0 everywhere and V<=P. Its positive minimum on each compact set makes grad ln V locally well defined. For compact smooth f, expand the square and integrate the cross term:

    integral |grad f-f grad ln V|^2
      = integral |grad f|^2
        +integral f^2[Delta ln V+|grad ln V|^2]
      = integral |grad f|^2-integral (c/V)f^2.

Only -Delta V=c is used. This sign is not an optional convention. Since c/V>=0 and V<=P,

    integral c f^2<=P integral (c/V)f^2<=P integral |grad f|^2.

For a bounded density jump V and its first derivatives match weakly; no extra interface term appears. The compact-test estimate extends to H1 by density. On the compact source support c/V is bounded. At large radius V behaves as a positive constant divided by r, so grad ln V has the expected inverse-radius behavior; the squared expression also extends to the relevant finite-energy domain by the same bound/approximation argument. Zero source is treated separately instead of dividing by V=0.

Linearizing the fixed-density canonical scalar action gives f_tt+Hf=0 with

    H=-Delta+Y_chichi(chi_static)+c A_chichi(chi_static).

There is no additional factor two: the original kinetic term and the potential variation both have the same 2Q normalization, while c=rhoStar/(2Q). The background coefficients are bounded. The quadratic form on H1 obeys

    <f,Hf> >=(1-LP) integral |grad f|^2+mMin^2 integral f^2.

It defines a self-adjoint operator bounded below by mMin^2>0. A mode exp(lambda t) would require Hf=-lambda^2 f; a positive form rules out growing finite-energy scalar normal modes. The result is linear fixed-source, fixed-flat-metric stability. It neither proves nonlinear global stability nor damping, attraction, support equilibrium, coupled matter/metric stability or environmental realization. No spectral gap uniform in the excluded parameter limits is inferred.

## Distinct controls

Exact symbolic differentiation uses the u/E chain-rule operator, not parent functions. High-precision numerical derivatives of the raw supplied action check positive curvature and the matter lower bound over independently selected threshold-controlled intervals. A scalar Neumann fixed-point witness tests the perturbation denominator. A uniform Newton sphere and compact radial polynomial test functions check the ground-state integral by two distinct integrands and test the form estimate. The test functions are C1 compact functions in H1, justified by the preceding smooth-density extension; no galaxy/body profile or empirical data are used.
