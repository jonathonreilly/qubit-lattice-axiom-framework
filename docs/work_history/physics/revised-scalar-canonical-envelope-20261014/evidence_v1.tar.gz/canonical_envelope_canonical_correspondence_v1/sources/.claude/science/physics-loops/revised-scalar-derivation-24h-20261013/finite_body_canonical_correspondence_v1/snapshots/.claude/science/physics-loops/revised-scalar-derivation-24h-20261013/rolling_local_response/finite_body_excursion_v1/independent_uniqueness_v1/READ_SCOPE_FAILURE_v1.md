# Preserved source-enumeration failure

At the first source freeze, the reviewer enumerated top-level files whose names began with `UNIQUENESS_`, intending to select handwritten source versions, protocol and diff. The parent had meanwhile executed a checker. The enumeration therefore also copied and printed `UNIQUENESS_PRE_RUN_v1.json`, `UNIQUENESS_RUN_v1.json`, `UNIQUENESS_RUN_v1.stderr` and `UNIQUENESS_RUN_v1.stdout`.

The accidental exposure included command/path metadata, producer checker hash, timing, exit 0, empty stderr and an aggregate 98 passed / 0 failed / 18 cases. It did not include the producer checker source, individual check rows, profile values or substantive result tables. The complete accidentally exposed bytes are retained under `sources/`, with their original hashes in the unchanged `FREEZE_v1.json`.

The failure was reported immediately to the parent, who acknowledged it and directed continuation without a fully-blind claim. The producer count is not used as an oracle, target or evidence of validity. Subsequent source reads use explicit filenames. The independent action derivation, fixtures, program and damaged executions are reviewer-owned. This review is independent in method, but it is not completely blind to the producer's aggregate execution status.

The original freeze's short scope label said "Blind uniqueness/stability handwritten check" before the accidental files were displayed. This failure record qualifies that label; the original freeze is preserved instead of rewritten. Neither previous sealed review was modified.
