# Independent uniqueness and scalar-form review

The uniqueness criterion and v2 held-source scalar stability extension follow from the supplied action under their stated compactness, boundary and fixed-source assumptions. The source-perturbation estimate has the stated denominator `1-LP1`. No mathematical correction to these frozen derivations was needed. The separately requested surface-v2 change is confirmed as an opening-sentence qualification only; the earlier surface seal remains unchanged.

This review is independent in derivation and code, but not completely blind to producer execution status. An overly broad filename enumeration exposed execution metadata and an aggregate 98/0 before the independent computation. The incident is preserved and reported explicitly below. No producer checker, individual result rows, body profiles or substantive output tables were read or used as evidence.

## Exact source scope and correspondence

Both uniqueness handwritten versions were read completely. V1 is `1cf4aa92ade42c91f01788472ed5f7deae6b39c56ea4b40e5d009cd69159dc0c`; v2 is `ceea5fc3f6d4630e101ed279218c7b66ff2b9da8a751b6eb461e6707bb4a43ae`. The complete protocol and exact diff were inspected. V2 preserves the full original proof and appends section 4; the protocol binds v2. Its pre-implementation status is a historical statement at its freeze, not a claim that no later execution exists.

The complete prior excursion and surface arguments, supplied canonical action, and both independent seals were reused by exact identity. The old excursion's boundary repair remains necessary. The prior 598/0 plus affected 22/0 and surface 1735/0 were not rerun or relabeled as new checks. The old reports and failures remain intact.

The new surface-v2 note has SHA `269e10f9778fbb34a62fc3a3a2511516ca92ec30d5b45a002247611000f392b5`. Comparing its complete text to frozen v1 shows exactly one opening sentence now specifies a radial negative-branch solution. Its complete diff and correction record agree; equations and tests are unchanged. The new uniqueness result supplies radial symmetry under its additional sufficient criterion. It does not retroactively make every surface-v1 solution unique without that criterion.

All 24 original/snapshot bindings are listed in `SOURCE_DISPOSITIONS_v1.json`, distinguishing requested sources, reused proof/evidence and the four accidentally exposed metadata files.

## Convexity and its domain

The exact action derivatives reproduce both the displayed base canonical Hessian and the first and second derivatives of `g=u/F`. The base Hessian is strictly positive for E in [1/2,1], including the lower endpoint because its `sE` contribution remains positive. The regulator has `g<=0`, `g_chichi<0` and nonzero `g_chi`, so its canonical Hessian is strictly positive as well.

The interval follows from the existing excursion bound and K>=K0. Both candidate solutions and every field segment between them stay in this compact interval. The statement is local in field space; global convexity is not assumed. Continuity and strict positivity on the closed interval give a positive minimum at fixed interior parameters. Numerical samples are not substituted for that infimum.

The one-sided matter bound is also correct: `A_chichi=A(beta^2+beta_chi)>=-AL>=-L`. The vacuum value is exactly -1, not -L. The sufficient compactness condition can independently be rewritten as

    P<=ln2(1-3k)/[8a+(1+k)ln2(1-3k)],

using `K0=k(1-3k)^2/(16a)`. This checks its normalization and domain. Exceeding this threshold is not evidence of multiplicity or instability. The separate LP<1 premise remains explicit.

## Uniqueness, boundary and changing sources

Subtracting the two field equations yields mean-value coefficients with nonnegative potential contribution and matter coefficient bounded below by -L. Distributional Kato comparison gives `-Delta|d|<=Lc|d|`. This avoids division by d at its zeros. Bounded fields and density provide the local elliptic regularity needed by the weak inequality.

Subtracting the positive Newton potential gives a subharmonic function tending to zero at infinity. The maximum principle therefore gives `|d|<=L N[c|d|]`; its supremum is at most LP times the finite supremum of |d|. LP<1 forces equality of the solutions. The zero boundary is an essential premise, not an optional choice of a comparison constant. The already checked existence construction supplies a member of this class.

For a rotationally symmetric source, rotations preserve the equation, branch and boundary. Uniqueness consequently implies radial symmetry. The result does not assert uniqueness of arbitrary positive-branch fields, other ambient boundary data, or full metric/matter configurations.

For two prescribed sources the difference must be split with c1 multiplying the coupling difference. The residual source term is bounded by a common upper bound on |A_chi| times |c1-c2|. Newton comparison then gives exactly `betaMax ||N[|c1-c2|]||/(1-LP1)`. Both solutions need a common proved convex interval and common coupling bound; the theorem is not a rule for inferring those bounds from unspecified physical environments. It estimates static field response and has no implied settling time.

## V2 ground-state and stability extension

Expanding `|grad f-f grad ln V|^2`, integrating the cross term and using `Delta V=-c` gives the displayed minus sign in the weighted term. For nonzero source, V is positive; c/V is bounded on the compact source support. Since V<=P, the identity implies `integral c f^2<=P integral |grad f|^2`. Density jumps do not add a delta-function boundary contribution; the Newton field and normal derivative match weakly. The compact-test inequality extends to H1. Zero source must be treated separately, as the note does.

Linearizing the original canonical action with density and flat metric held fixed gives `f_tt+Hf=0`, `H=-Delta+Y_chichi+c A_chichi`. The factors of 2Q cancel exactly. The form is bounded below by `(1-LP)||grad f||^2+mMin^2||f||^2`, and bounded background coefficients give the usual self-adjoint form realization. This excludes negative spectrum and growing finite-energy scalar normal modes for the fixed problem.

This is a linear scalar result. It does not establish nonlinear stability, damping, attraction to the static solution, free-matter equilibrium, coupled metric/fluid stability or an observed environmental state. No uniform gap in excluded parameter limits follows. These distinctions are correctly retained in v2.

## Independent implementation and controls

`HAND_DERIVATION_v1.md` contains the complete derivation. The independent protocol was saved before execution. The program uses exact action-coordinate differentiation, raw-action high-precision derivatives, threshold-controlled intervals, a Neumann fixed-point witness and two separately integrated forms on a uniform Newton sphere. The compact polynomial test functions are H1/C1; their use follows from the proved smooth-test extension.

The new execution records 641 passing assertions and zero failures, exit 0 and empty stderr. Six assertions concern exact source correspondence; the remainder are algebraic, numerical and logical checks. It includes 16 parameter intervals, 80 action-derivative rows and eight form-integral fixtures. Sample minima are labeled as samples, not certified global minima. The form fixtures use a declared synthetic positive mass coefficient, while the action theorem defines its own minimum by continuity. No nonlinear body history or producer's 18 existing cases was replayed.

Seven actual altered reviewer programs were run on a declared 43-assertion witness subset. Each run freshly hashes 28 actual input files, including the preserved exposure record, and confirms they remain unchanged. Detection comes from mathematical witnesses rather than disagreement with an original source hash.

| Actual alteration | Passed / failed |
| --- | ---: |
| Reverse the base connection contribution | 41 / 2 |
| Reverse the regulator connection contribution | 40 / 3 |
| Reverse the matter lower-bound sign | 41 / 2 |
| Reverse the Kato upper-bound sign | 41 / 2 |
| Replace the perturbation denominator by 1+LP | 41 / 2 |
| Reverse the ground-state weighted sign | 42 / 1 |
| Replace 1-LP by 1+LP in the form bound | 42 / 1 |

Every intended witness failed and every altered child exited 1. Full sources, exact diffs, failed rows and streams are retained. There was no unexpected positive-run computational failure.

## Exposure failure and final recovery

The first file enumeration used the prefix `UNIQUENESS_`. It unintentionally included the newly written pre-run/run records and stdout/stderr alongside the requested notes/protocol/diff. The exposed stdout contained only an aggregate 98 passed, zero failed and 18 cases. The exact metadata and streams remain in the original freeze. `READ_SCOPE_FAILURE_v1.md` records the command-selection error, the immediate parent notification and the exclusion of those counts from the independent oracle. The initial freeze's short "blind" label is explicitly qualified by that preserved record rather than silently rewritten.

Subsequent reads used explicit filenames. This limitation does not alter the exact action differentiation or independently computed controls, but it prevents a claim of complete blindness. The parent acknowledged the exposure and authorized continuation with that distinction.

The manifest covers the complete new package and every failure. The receipt binds the report, full source dispositions, commands, independent derivation, execution evidence, prior-seal verification and this exposure record. Both earlier seals remain immutable. This is a focused source-bound check, not a formal audit, empirical test or status promotion.
