"""Execute actual reviewer-program alterations with full fresh identities."""
from pathlib import Path
import difflib
import hashlib
import json
from execute_v1 import execute

P=Path(__file__).resolve().parent;source=(P/"check_independent_v1.py").read_text()
changes=[
    ("base_connection_sign","*(2*J*(2*E-1+s*E)-b*s*E*(E-1)*F)","*(2*J*(2*E-1+s*E)+b*s*E*(E-1)*F)","base_canonical_derivative"),
    ("regulator_connection_sign","/J*(1+2*alpha*u/F)-alpha*b*s*E*F/(J*J)","/J*(1+2*alpha*u/F)+alpha*b*s*E*F/(J*J)","g_second_derivative"),
    ("matter_lower_sign","def matter_lower(L):return -L","def matter_lower(L):return L","matter_lower_bound"),
    ("kato_sign","def kato_upper(L,c,dabs):return L*c*dabs","def kato_upper(L,c,dabs):return -L*c*dabs","kato_mean_value_witness"),
    ("perturbation_denominator","def perturbation_bound(forcing,t):return forcing/(1-t)","def perturbation_bound(forcing,t):return forcing/(1+t)","source_perturbation_fixed_point"),
    ("ground_state_sign","def ground_rhs(gradient,weighted):return gradient-weighted","def ground_rhs(gradient,weighted):return gradient+weighted","ground_state_integral"),
    ("form_coercivity_sign","return (1-L*P)*gradient+mass2*norm","return (1+L*P)*gradient+mass2*norm","operator_form_bound"),
]
out=P/"damages_v1";out.mkdir(exist_ok=False);summary=[]
for name,before,after,target in changes:
    assert source.count(before)==1
    changed=source.replace(before,after);path=out/(name+".py");path.write_text(changed)
    (out/(name+".diff")).write_text("".join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile="check_independent_v1.py",tofile=name+".py")))
    execution=execute(path,out/name,witness=True);result=json.loads((out/name/"RESULTS.json").read_text())
    failed=[x["name"] for x in result["checks"] if not x["passed"]]
    summary.append({"name":name,"before":before,"after":after,"source_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"required_witness":target,"required_witness_failed":target in failed,"passed":result["passed"],"failed":result["failed"],"exit_code":execution["exit_code"],"inputs_unchanged":execution["inputs_unchanged"],"all_failed_rows":failed,"scope":"Actual witness subset: one k/nu/P interval with both endpoints and one form fixture; full exact identities retained."})
(out/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary))
raise SystemExit(0 if all(x["required_witness_failed"] and x["exit_code"]==1 and x["inputs_unchanged"] for x in summary) else 1)
