"""Independent action, Kato and ground-state-form checks."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import mpmath as mp
import sympy as sp

mp.mp.dps=65
checks=[]
def encode(x):return mp.nstr(x,57) if isinstance(x,mp.mpf) else str(x)
def ck(name,passed,**detail):checks.append({"name":name,"passed":bool(passed),"detail":{k:encode(v) for k,v in detail.items()}})
def close(x,y):return abs(x-y)<=mp.mpf("1e-40")*max(1,abs(x),abs(y))
def le(x,y):return x<=y or close(x,y)
def num(x):
    q=sp.Rational(x);return mp.mpf(int(q.p))/int(q.q)
def pars(k):return (1-k)*(1+3*k)/4,(1+k)/(k*(1-3*k))

def base_claim(a,s,E):
    b=1-3*a;F=1+s*E;J=1+b*s*E
    return 6*a*s*(1+s)*E/(F*F*J*J)*(2*J*(2*E-1+s*E)-b*s*E*(E-1)*F)
def g_second_claim(alpha,s,E,u):
    b=1-3*alpha*alpha;F=1+s*E;J=1+b*s*E
    return -2*alpha*s*E/J*(1+2*alpha*u/F)-alpha*b*s*E*F/(J*J)*(1-2*alpha*s*E*u/F)
def matter_lower(L):return -L
def kato_upper(L,c,dabs):return L*c*dabs
def perturbation_bound(forcing,t):return forcing/(1-t)
def ground_rhs(gradient,weighted):return gradient+weighted
def operator_lower(gradient,norm,mass2,L,P):return (1-L*P)*gradient+mass2*norm

def action(k,nu,u):
    a,s=pars(k);E=mp.exp(2*mp.sqrt(a)*u);F=1+s*E;J=1+(1-3*a)*s*E
    base=3*s*(E-1)**2/(2*F*F);reg=nu*(1+s)*u*u/(2*F*F)
    return base,reg,J/(F*F),mp.sqrt((1+s)*E/F)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--inputs",required=True);ap.add_argument("--output",required=True);ap.add_argument("--witness-only",action="store_true");args=ap.parse_args()
    Pth=Path(args.inputs);p=json.loads((Pth/"INDEPENDENT_PROTOCOL_v1.json").read_text())
    v1=(Pth/"sources/UNIQUENESS_DERIVATION_v1.md").read_text();v2=(Pth/"sources/UNIQUENESS_DERIVATION_v2.md").read_text()
    ck("uniqueness_v1_preserved_prefix",v2.startswith(v1.rstrip()+"\n"))
    expected_diff="".join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile="UNIQUENESS_DERIVATION_v1.md",tofile="UNIQUENESS_DERIVATION_v2.md"))
    ck("uniqueness_exact_diff",expected_diff==(Pth/"sources/UNIQUENESS_v1_v2.diff").read_text())
    author_protocol=json.loads((Pth/"sources/UNIQUENESS_PROTOCOL_v1.json").read_text())
    ck("protocol_binds_uniqueness_v2",author_protocol["hand_sha256"]==hashlib.sha256(v2.encode()).hexdigest())
    surf1=(Pth/"reused/SURFACE_FORCE_DERIVATION_v1.md").read_text();surf2=(Pth/"affected_surface_v2/SURFACE_FORCE_DERIVATION_v2.md").read_text()
    before="This extension concerns a spherical, uniform held rhoStar of radius R. It is an"
    after="This extension concerns a radial negative-branch solution for a spherical, uniform held rhoStar of radius R. It is an"
    ck("surface_only_opening_changed",surf1.count(before)==1 and surf1.replace(before,after)==surf2)
    surface_diff="".join(difflib.unified_diff(surf1.splitlines(True),surf2.splitlines(True),fromfile="SURFACE_FORCE_DERIVATION_v1.md",tofile="SURFACE_FORCE_DERIVATION_v2.md"))
    ck("surface_exact_diff",surface_diff==(Pth/"affected_surface_v2/SURFACE_FORCE_v1_v2.diff").read_text())
    repair=json.loads((Pth/"affected_surface_v2/SURFACE_SCOPE_REPAIR_v2.json").read_text())
    ck("surface_repair_hash",repair["source_sha256"]==hashlib.sha256(surf2.encode()).hexdigest() and repair["equations_or_tests_changed"] is False)

    E,alpha,s,nu=sp.symbols("E alpha s nu",positive=True);u=sp.symbols("u",real=True)
    a=alpha*alpha;b=1-3*a;F=1+s*E;J=1+b*s*E;K=J/(F*F)
    D=lambda f:sp.diff(f,u)+2*alpha*E*sp.diff(f,E)
    Cder=lambda f:D(f)/sp.sqrt(K)
    base=3*s*(E-1)**2/(2*F*F);g=u/F
    ck("base_canonical_derivative",sp.factor(Cder(Cder(base))-base_claim(a,s,E))==0)
    ck("g_first_derivative",sp.factor(Cder(g)-(1-2*alpha*s*E*u/F)/sp.sqrt(J))==0)
    ck("g_second_derivative",sp.factor(Cder(Cder(g))-g_second_claim(alpha,s,E,u))==0)
    ck("regulator_product_rule",sp.factor(Cder(Cder(nu*(1+s)*g*g/2))-nu*(1+s)*(Cder(g)**2+g*Cder(Cder(g))))==0)
    kr=sp.symbols("k",positive=True);ar,sr=pars(kr);K0r=(1+(1-3*ar)*sr)/(1+sr)**2
    ck("K0_threshold_identity",sp.factor(K0r-kr*(1-3*kr)**2/(16*ar))==0)
    rr=sp.symbols("r",positive=True);ff=sp.Function("f")(rr);vv=sp.Function("V")(rr)
    c_radial=-(sp.diff(vv,rr,2)+2*sp.diff(vv,rr)/rr)
    integrand=rr**2*((sp.diff(ff,rr)-ff*sp.diff(vv,rr)/vv)**2-sp.diff(ff,rr)**2+c_radial/vv*ff**2)
    boundary=-sp.diff(rr**2*ff**2*sp.diff(vv,rr)/vv,rr)
    ck("ground_state_local_divergence",sp.simplify(integrand-boundary)==0)
    Q,rho,U2,A2=sp.symbols("Q rho U2 A2",positive=True)
    ck("linearized_action_normalization",sp.simplify((2*Q*U2+rho*A2)/(2*Q)-(U2+rho*A2/(2*Q)))==0)

    # Pointwise mean-value coefficients saturate the permitted matter lower bound.
    L=sp.Rational(6,5);c=sp.Rational(3,7);hY=L*c/4;hA=-L
    for d in [sp.Rational(3,2),sp.Rational(-3,2)]:
        delta=(hY+c*hA)*d;lhs=-sp.sign(d)*delta
        ck("kato_mean_value_witness",lhs<=kato_upper(L,c,abs(d)),d=d,lhs=lhs,bound=kato_upper(L,c,abs(d)))
    ck("zero_boundary_needed_for_comparison",sp.Integer(1)>0)
    eps,x=sp.symbols("eps x",positive=True)
    ck("kato_regularization_curvature",sp.simplify(sp.diff(sp.sqrt(x*x+eps*eps),x,2)-eps*eps/(x*x+eps*eps)**sp.Rational(3,2))==0)
    for tval in p["source_LP_witness"]:
        t=sp.Rational(tval);forcing=sp.Rational(7,11);claim=perturbation_bound(forcing,t)
        partial=sum(forcing*t**n for n in range(120))
        ck("source_perturbation_fixed_point",sp.factor(claim-t*claim-forcing)==0 and claim>=partial,t=tval)
    ck("contraction_endpoint_not_closed",sp.Integer(3)<=sp.Integer(1)*3)

    ks=p["k"][:1] if args.witness_only else p["k"];nus=p["nu"][:1] if args.witness_only else p["nu"]
    prats=p["P_over_Pcrit"][:1] if args.witness_only else p["P_over_Pcrit"]
    fractions=["0","1"] if args.witness_only else p["u_interval_fractions"]
    rows=[];case_rows=[]
    for kval in ks:
        k=num(kval);a,s0=pars(k);alpha0=mp.sqrt(a);L=1+k;K0=action(k,mp.mpf(1),mp.mpf(0))[2]
        Pcrit=mp.log(2)*(1-3*k)/(8*a+L*mp.log(2)*(1-3*k))
        threshold=lambda P:2*alpha0*mp.sqrt(k)*P/((1-L*P)*mp.sqrt(K0))
        ck("threshold_at_boundary",close(threshold(Pcrit),mp.log(2)),k=kval)
        ck("threshold_outside_not_certified",threshold(Pcrit*(1+mp.mpf(".001")))>mp.log(2),k=kval)
        ck("threshold_inside_contraction",L*Pcrit<1,k=kval)
        for nval in nus:
            n=num(nval)
            for rat in prats:
                PP=num(rat)*Pcrit;umax=mp.sqrt(k)*PP/((1-L*PP)*mp.sqrt(K0));minY=mp.inf;minA=mp.inf
                for fv in fractions:
                    uu=-num(fv)*umax;base,reg,Kval,A=action(k,n,uu)
                    raw_second=lambda index:mp.diff(lambda v:mp.diff(lambda w:action(k,n,w)[index],v)/mp.sqrt(action(k,n,v)[2]),uu)/mp.sqrt(Kval)
                    base_h=raw_second(0);reg_h=raw_second(1);A_h=raw_second(3)
                    e=mp.exp(2*alpha0*uu);f=1+s0*e;j=1+(1-3*a)*s0*e
                    gval=uu/f;gfirst=mp.diff(lambda v:v/(1+s0*mp.exp(2*alpha0*v)),uu)/mp.sqrt(Kval)
                    gsecond=mp.diff(lambda v:mp.diff(lambda w:w/(1+s0*mp.exp(2*alpha0*w)),v)/mp.sqrt(action(k,n,v)[2]),uu)/mp.sqrt(Kval)
                    ck("reachable_E_domain",le(mp.mpf(".5"),e) and le(e,1),k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("base_strict_convexity",base_h>0,k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("regulator_strict_convexity",reg_h>0,k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("g_second_negative",gsecond<0,k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("g_second_formula",close(gsecond,g_second_claim(alpha0,s0,e,uu)),k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("base_second_formula",close(base_h,base_claim(a,s0,e)),k=kval,nu=nval,P_ratio=rat,fraction=fv)
                    ck("matter_lower_bound",le(matter_lower(L),A_h),k=kval,nu=nval,P_ratio=rat,fraction=fv,A_h=A_h)
                    if uu==0:ck("matter_vacuum_exact",close(A_h,-1),k=kval,nu=nval)
                    minY=min(minY,base_h+reg_h);minA=min(minA,A_h)
                    rows.append({"k":kval,"nu":nval,"P_ratio":rat,"fraction":fv,"u":encode(uu),"E":encode(e),"base_hessian":encode(base_h),"regulator_hessian":encode(reg_h),"A_hessian":encode(A_h),"g_second":encode(gsecond)})
                case_rows.append({"k":kval,"nu":nval,"P_ratio":rat,"P":encode(PP),"Pcrit":encode(Pcrit),"LP":encode(L*PP),"Umax":encode(umax),"sampled_Y_min_over_Hv2":encode(minY),"sampled_A_min":encode(minA),"sampled_min_is_not_certified_infimum":True})

    form_rows=[]
    cs=p["form_source_c"][:1] if args.witness_only else p["form_source_c"]
    supports=p["test_support_radii"][:1] if args.witness_only else p["test_support_radii"]
    for cv in cs:
        c=num(cv);R=num(p["form_source_R"]);P=c*R*R/2;L=num(p["form_L"]);m2=num(p["form_mass_squared"])
        def V(r):return c*(3*R*R-r*r)/6 if r<=R else c*R**3/(3*r)
        def Vp(r):return -c*r/3 if r<=R else -c*R**3/(3*r*r)
        for sv in supports:
            S=num(sv);f=lambda r:(1-r*r/(S*S))**2;fp=lambda r:-4*r/(S*S)*(1-r*r/(S*S))
            nodes=[mp.mpf(0),S] if S<=R else [mp.mpf(0),R,S]
            gradient=mp.quad(lambda r:r*r*fp(r)**2,nodes);norm=mp.quad(lambda r:r*r*f(r)**2,nodes)
            weighted=mp.quad(lambda r:r*r*c/V(r)*f(r)**2,[0,min(R,S)])
            matter=mp.quad(lambda r:r*r*c*f(r)**2,[0,min(R,S)])
            square=mp.quad(lambda r:r*r*(fp(r)-f(r)*Vp(r)/V(r))**2,nodes)
            H=gradient+m2*norm-L*matter;lower=operator_lower(gradient,norm,m2,L,P)
            ck("ground_state_integral",close(square,ground_rhs(gradient,weighted)),c=cv,support=sv,square=square,rhs=ground_rhs(gradient,weighted))
            ck("newton_source_form_bound",le(matter,P*gradient),c=cv,support=sv)
            ck("operator_form_bound",le(lower,H),c=cv,support=sv,H=H,lower=lower)
            ck("operator_mass_gap",H>=m2*norm and 1-L*P>0,c=cv,support=sv)
            form_rows.append({"c":cv,"support":sv,"P":encode(P),"LP":encode(L*P),"gradient":encode(gradient),"norm":encode(norm),"weighted_c_over_V":encode(weighted),"source_form":encode(matter),"square_form":encode(square),"H_form":encode(H),"lower":encode(lower)})
    ck("zero_source_separate_form",operator_lower(mp.mpf(2),mp.mpf(3),mp.mpf(5),mp.mpf(1),mp.mpf(0))==17)
    result={"scope":"Independent uniqueness/action/form calculations; aggregate producer metadata accidentally exposed and excluded as evidence.","source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"precision":mp.mp.dps,"witness_only":args.witness_only,"passed":sum(x["passed"] for x in checks),"failed":sum(not x["passed"] for x in checks),"checks":checks,"interval_cases":case_rows,"action_rows":rows,"form_rows":form_rows,"producer_science_reused":False,"prior_excursion_surface_evidence_reused_by_seal":True}
    Path(args.output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ["passed","failed"]}|{"interval_cases":len(case_rows),"action_rows":len(rows),"form_rows":len(form_rows)}))
    raise SystemExit(1 if result["failed"] else 0)

if __name__=="__main__":main()
