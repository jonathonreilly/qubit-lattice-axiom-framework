"""Freeze actual sources; capture every independent program execution."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def execute(source,dest,witness=False):
    dest.mkdir(exist_ok=False)
    f1=json.loads((P/"FREEZE_v1.json").read_text());f2=json.loads((P/"FREEZE_v2.json").read_text())
    paths=[source,P/"HAND_DERIVATION_v1.md",P/"INDEPENDENT_PROTOCOL_v1.json",P/"READ_SCOPE_FAILURE_v1.md"]+[P/x["snapshot_path"] for x in f1["sources"]+f2["added_sources"]]
    rows=[{"path":str(x),"bytes":x.stat().st_size,"sha256":sha(x)} for x in paths]
    (dest/"FREEZE.json").write_text(json.dumps({"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"actual_inputs":rows,"accidentally_exposed_metadata_preserved_not_used_as_oracle":True,"mutation_detection_is_mathematical":True},indent=2)+"\n")
    argv=[sys.executable,"-B",str(source),"--inputs",str(P),"--output",str(dest/"RESULTS.json")]
    if witness:argv.append("--witness-only")
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        proc=subprocess.run(argv,cwd=P,text=True,capture_output=True,timeout=120)
        stdout,stderr,code=proc.stdout,proc.stderr,proc.returncode
    except subprocess.TimeoutExpired as exc:
        stdout=exc.stdout or "";stderr=exc.stderr or ""
        if isinstance(stdout,bytes):stdout=stdout.decode(errors="replace")
        if isinstance(stderr,bytes):stderr=stderr.decode(errors="replace")
        stderr += "\nIndependent 120-second execution limit reached.\n";code=124
    (dest/"stdout.txt").write_text(stdout);(dest/"stderr.txt").write_text(stderr)
    record={"argv":argv,"cwd":str(P),"started_utc":start,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit_code":code,"source_sha256":sha(source),"inputs_unchanged":all(sha(Path(x["path"]))==x["sha256"] for x in rows)}
    (dest/"EXECUTION.json").write_text(json.dumps(record,indent=2)+"\n")
    return record

if __name__=="__main__":
    result=execute(P/"check_independent_v1.py",P/"baseline_v1");print(json.dumps(result));raise SystemExit(result["exit_code"])
