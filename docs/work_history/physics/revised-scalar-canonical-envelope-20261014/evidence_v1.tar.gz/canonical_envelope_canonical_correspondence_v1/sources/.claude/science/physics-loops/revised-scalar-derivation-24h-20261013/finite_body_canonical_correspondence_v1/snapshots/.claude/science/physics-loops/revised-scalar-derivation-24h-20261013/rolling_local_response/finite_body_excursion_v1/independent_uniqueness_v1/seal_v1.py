"""Identity-only sealing of the independent uniqueness review."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import sys

P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def write(name,obj):
    path=P/name;assert not path.exists(),f"Refuse overwrite {path}"
    path.write_text(json.dumps(obj,indent=2)+"\n")

assert not (P/"MANIFEST_v1.json").exists() and not (P/"RECEIPT_v1.json").exists()
sources=read("FREEZE_v1.json")["sources"]+read("FREEZE_v2.json")["added_sources"]
accidental={"UNIQUENESS_PRE_RUN_v1.json","UNIQUENESS_RUN_v1.json","UNIQUENESS_RUN_v1.stderr","UNIQUENESS_RUN_v1.stdout"}
dispositions=[]
for x in sources:
    original=Path(x["original_path"]);snapshot=P/x["snapshot_path"]
    assert sha(original)==sha(snapshot)==x["sha256"]
    assert original.read_bytes()==snapshot.read_bytes()
    role="Accidentally exposed producer metadata/aggregate; preserved as failure evidence, excluded from mathematical oracle." if original.name in accidental else "Fully read handwritten source, exact affected clarification, or reused proof/evidence dependency."
    dispositions.append({"original_path":str(original),"original_sha256":x["sha256"],"disposition":role,"recovery":str(snapshot),"recovery_sha256":sha(snapshot),"final_path":str(original),"final_sha256":sha(original)})
assert len(dispositions)==24
reused=[]
for folder,expected,count in [("independent_v1","f31cb02003bebee1251a963fdb4b76151c841dd7a023cc4604db5803cb33cb43",72),("independent_surface_v1","2944bb5aeb74440ba1e5954e2e2f4af4275c0c287d94c76f62f57d3812cd0b71",77)]:
    path=P.parent/folder;m=json.loads((path/"MANIFEST_v1.json").read_text());r=json.loads((path/"RECEIPT_v1.json").read_text())
    assert sha(path/"RECEIPT_v1.json")==expected and len(m["artifacts"])==count
    for row in m["artifacts"]:assert sha(path/row["path"])==row["sha256"]
    for row in r["bindings"]:assert sha(path/row["path"])==row["sha256"]
    reused.append({"directory":str(path),"receipt_sha256":expected,"manifest_sha256":sha(path/"MANIFEST_v1.json"),"verified_artifacts":count,"receipt_bindings":len(r["bindings"]),"science_reexecuted":False,"artifacts":m["artifacts"]})

baseline=read("baseline_v1/RESULTS.json")
assert (baseline["passed"],baseline["failed"])==(641,0)
assert len(baseline["interval_cases"])==16 and len(baseline["action_rows"])==80 and len(baseline["form_rows"])==8
assert sha(P/"check_independent_v1.py")==baseline["source_sha256"]
damage=read("damages_v1/SUMMARY.json");expected=[(41,2),(40,3),(41,2),(41,2),(41,2),(42,1),(42,1)]
commands=[]
for i,run in enumerate(["baseline_v1"]+["damages_v1/"+d["name"] for d in damage]):
    r=read(run+"/RESULTS.json");e=read(run+"/EXECUTION.json");f=read(run+"/FREEZE.json")
    assert len(f["actual_inputs"])==28
    for x in f["actual_inputs"]:assert sha(Path(x["path"]))==x["sha256"]
    assert e["inputs_unchanged"] and e["source_sha256"]==r["source_sha256"]
    assert sum(x["passed"] for x in r["checks"])==r["passed"] and sum(not x["passed"] for x in r["checks"])==r["failed"]
    if i:
        d=damage[i-1];assert (r["passed"],r["failed"])==expected[i-1] and e["exit_code"]==1 and d["required_witness_failed"]
        assert any(x["name"]==d["required_witness"] and not x["passed"] for x in r["checks"])
        assert sha(P/("damages_v1/"+d["name"]+".py"))==d["source_sha256"]
    else:assert e["exit_code"]==0
    commands.append({"record":run+"/EXECUTION.json",**e})

write("SOURCE_DISPOSITIONS_v1.json",{"original_dispositions":dispositions,"accidental_exposure_files":sorted(accidental),"fully_blind":False,"parent_code_or_result_rows_used":False})
write("REUSE_VERIFICATION_v1.json",{"prior_seals":reused,"total_verified_prior_artifacts":149,"prior_science_reexecuted":False})
write("COMMAND_INDEX_v1.json",{"executions":commands,"outer_entrypoints":["python3 -B execute_v1.py","python3 -B damage_controls_v1.py"],"seal_argv":[sys.executable,"-B",str(Path(__file__).resolve())],"initial_source_selection_failure":"Top-level p.is_file() and p.name.startswith('UNIQUENESS_'); copied and printed all selected files. Exact selected files and bytes retained in FREEZE_v1.json.","subsequent_read_policy":"Explicit filenames only; no parent checker or substantive result rows."})
write("ENVIRONMENT_v1.json",{"python":sys.version,"platform":platform.platform(),"precision":baseline["precision"],"producer_aggregate_exposed":True,"producer_code_or_result_rows_read":False})
artifacts=[]
for path in sorted(P.rglob("*")):
    if path.is_file():
        assert not path.is_symlink()
        artifacts.append({"path":str(path.relative_to(P)),"bytes":path.stat().st_size,"sha256":sha(path)})
write("MANIFEST_v1.json",{"schema":"closed-artifacts-v1","excludes":["MANIFEST_v1.json","RECEIPT_v1.json"],"artifacts":artifacts})
bound=["REPORT_v1.md","MANIFEST_v1.json","SOURCE_DISPOSITIONS_v1.json","HAND_DERIVATION_v1.md","INDEPENDENT_PROTOCOL_v1.json","READ_SCOPE_FAILURE_v1.md","FAILURES_v1.md","REUSE_VERIFICATION_v1.json","COMMAND_INDEX_v1.json","baseline_v1/RESULTS.json","baseline_v1/EXECUTION.json","damages_v1/SUMMARY.json"]
write("RECEIPT_v1.json",{"sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Independent handwritten uniqueness v1/v2, held-source scalar stability and affected surface-v2 source clarification; no producer implementation/result-row review.","artifact_count":len(artifacts),"source_pair_count":len(dispositions),"passed":641,"failed":0,"actual_damaged_programs":7,"all_intended_damage_witnesses_failed":True,"fully_blind":False,"exposure_failure":"READ_SCOPE_FAILURE_v1.md","original_dispositions":"SOURCE_DISPOSITIONS_v1.json","bindings":[{"path":name,"sha256":sha(P/name)} for name in bound],"immutable_policy":"No sealed-file changes. Any amendment must use a separately named version preserving these bytes."})
for name in ["REPORT_v1.md","MANIFEST_v1.json","RECEIPT_v1.json","SOURCE_DISPOSITIONS_v1.json"]:print(name,sha(P/name))
print("artifacts",len(artifacts),"source_pairs",len(dispositions))
