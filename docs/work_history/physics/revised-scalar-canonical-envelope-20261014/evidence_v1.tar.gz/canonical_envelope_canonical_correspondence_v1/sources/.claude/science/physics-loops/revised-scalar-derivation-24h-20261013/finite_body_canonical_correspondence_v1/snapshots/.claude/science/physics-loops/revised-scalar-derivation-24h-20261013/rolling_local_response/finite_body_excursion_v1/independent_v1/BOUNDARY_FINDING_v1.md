# Original boundary finding and affected-source closure

Original source: `sources/DERIVATION_v1.md`, SHA256 `cd40b2c50bbb79d279b9a5f20ee80577ce3872e9994d2d50230ff85b04bae99a`.

The comparison theorem initially assumes decay; that conditional argument is sound. The variational existence outline, however, needed to show the weak minimizer actually acquires the limiting boundary. H^1 alone does not imply pointwise decay, and merely local regularity does not give the uniform continuity needed to obtain it. This was reported to the author before the independent numerical execution.

A concrete obstruction to the omitted inference is a sum of smooth unit-height bumps at points 3n e1 with radii 2^-n. Their supports are disjoint. The squared L2 and gradient norms are fixed bump constants times the convergent series sum 2^-3n and sum 2^-n. The function is bounded, smooth on each compact set and in H^1, but remains one at the escaping centers. Its derivatives and elliptic forcing are not uniformly bounded.

The original model already supplies the missing ingredient. Lower clipping bounds the minimizer; bounded density and smooth potential/coupling on that bounded field interval bound the elliptic RHS globally. Translation-uniform local elliptic estimates then give uniform continuity. Infinitely many nonzero-amplitude escaping points would give disjoint balls of fixed radius and divergent L2 norm. Therefore the minimizer decays uniformly. No additional density-interface smoothness assumption is needed.

The author accepted this finding, kept v1 unchanged, and supplied `DERIVATION_v2.md` SHA256 `5b731ef2b77d2282f8b84384095192cca748d8d454d6387a3e8b50349b93c0d5`, its exact diff, and a source-hash repair record. The full changed paragraph is read and checked; it adds precisely the preceding argument. The original equations, parameter domain, source interpretation and numerical protocol remain unchanged. `check_affected_v2.py` verifies the complete narrow change and includes exact scaling controls for the counterexample and the repaired disjoint-ball argument.

Disposition: the v1 existence outline had a boundary-justification omission; the separately preserved v2 closes it with the existing assumptions. This is not a failed maximum-principle inequality, a new physical boundary condition, or a proof of realized environmental state.
