"""Only the boundary-proof repair, source identities, and its exact logical witness."""
from pathlib import Path
import difflib
import hashlib
import json
import sympy as sp

OUT=Path(__file__).resolve().parent
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
old=(OUT/'sources/DERIVATION_v1.md').read_text();new=(OUT/'affected_v2/DERIVATION_v2.md').read_text()
ck('original_pin',sha(OUT/'sources/DERIVATION_v1.md')=='cd40b2c50bbb79d279b9a5f20ee80577ce3872e9994d2d50230ff85b04bae99a')
ck('repaired_pin',sha(OUT/'affected_v2/DERIVATION_v2.md')=='5b731ef2b77d2282f8b84384095192cca748d8d454d6387a3e8b50349b93c0d5')
before='sufficiently negative chi. The minimizer is bounded; standard local elliptic\nregularity then supports the comparison argument, with the appropriate weak\ninterpretation across a density jump. This is an existence construction in'
after='sufficiently negative chi. The minimizer is bounded. Its elliptic right-hand\nside is then uniformly bounded, so translation-uniform local elliptic estimates\ngive uniform continuity. Uniform continuity together with chi in L^2(R^3)\nforces chi to tend uniformly to zero at infinity: otherwise disjoint balls\nof a fixed radius and nonzero amplitude would make its L^2 norm infinite.\nThis establishes the boundary after taking the direct-method limit; H^1 alone\nwould not do so. Local regularity supports weak comparison across density jumps. This is an existence construction in'
ck('one_affected_paragraph',old.count(before)==1 and old.replace(before,after)==new)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='DERIVATION_v1.md',tofile='DERIVATION_v2.md'))
ck('exact_author_diff',diff==(OUT/'affected_v2/DERIVATION_v1_to_v2.diff').read_text())
with (OUT/'affected_v2/INDEPENDENT_DIFF.diff').open('x') as f:f.write(diff)
repair=json.loads((OUT/'affected_v2/BOUNDARY_PROOF_REPAIR_v2.json').read_text())
ck('repair_hashes',repair['original_sha256']==sha(OUT/'sources/DERIVATION_v1.md') and repair['final_sha256']==sha(OUT/'affected_v2/DERIVATION_v2.md'))
ck('protocol_remains_original',json.loads((OUT/'sources/PROTOCOL_v1.json').read_text())['source_sha256']==sha(OUT/'sources/DERIVATION_v1.md'))
sources=json.loads((OUT/'FREEZE_v2.json').read_text())['sources']+json.loads((OUT/'affected_v2/FREEZE_complete.json').read_text())['sources']
for row in sources:
    ck('snapshot:'+row['snapshot_path'],sha(OUT/row['snapshot_path'])==row['sha256'])
    ck('original:'+row['original_path'],sha(Path(row['original_path']))==row['sha256'])
# In dimension 3, disjoint unit-height bumps of radius 2^-n have
# squared L2 norm proportional to sum 2^-3n and gradient norm to sum 2^-n.
# This gives a bounded smooth local H1 counterexample to pointwise decay.
n=sp.symbols('n',integer=True,positive=True)
ck('H1_bump_L2_sum',sp.summation(sp.Rational(1,8)**n,(n,1,sp.oo))==sp.Rational(1,7))
ck('H1_bump_gradient_sum',sp.summation(sp.Rational(1,2)**n,(n,1,sp.oo))==1)
ck('bump_laplacian_not_uniformly_bounded',sp.limit(4**n,n,sp.oo)==sp.oo)
N=sp.symbols('N',positive=True)
ck('uniform_continuity_disjoint_ball_contradiction',sp.limit(N*sp.Rational(1,1000),N,sp.oo)==sp.oo)
result={'scope':'Affected proof/identity check only; no repeated positive science execution.','passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'counterexample':'Let f=sum psi((x-3n e1)/2^-n), with a smooth compact unit bump psi(0)=1 and disjoint supports. L2 and gradient norms sum to finite geometric series, but f(3n e1)=1. Its Laplacian has no uniform bound. Uniform bounded elliptic forcing removes this loophole through uniform continuity.'}
with (OUT/'affected_v2/RESULTS.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed']}))
raise SystemExit(1 if result['failed'] else 0)
