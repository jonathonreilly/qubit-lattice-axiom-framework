"""Execute actual single-change controls with fresh actual-source freezes."""
from pathlib import Path
import difflib
import hashlib
import json
from execute_v1 import execute

OUT=Path(__file__).resolve().parent
base=(OUT/'check_independent_v1.py').read_text()
changes=[
    ('reverse_comparison','return lap_w+sqrt_a*c','return lap_w-sqrt_a*c','maximum_principle_laplacian'),
    ('half_kinetic_normalization','def gradient_coefficient(Q):return Q','def gradient_coefficient(Q):return Q/2','held_density_factor'),
    ('omit_bootstrap_denominator','return beta0*P/(1-L*P)','return beta0*P','positive_operator_fixed_point'),
    ('wrong_beta_normalization','return (1+k)*C*(1-3*q)**2/(1-3*k)**2','return (1+k)*C*(1-3*q)**2/(1-3*k)','beta_derivative_action'),
    ('omit_nu_confinement','return 3*s*(E-1)**2/(2*F**2)+nu*(1+s)*u*u/(2*F**2)','return 3*s*(E-1)**2/(2*F**2)','negative_infinity_coercivity'),
]
folder=OUT/'damages_v1';folder.mkdir(exist_ok=False);summary=[]
for name,old,new,witness in changes:
    assert base.count(old)==1
    text=base.replace(old,new);source=folder/(name+'.py')
    with source.open('x') as f:f.write(text)
    with (folder/(name+'.diff')).open('x') as f:f.write(''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='independent_baseline',tofile=name)))
    execution=execute(source,'damages_v1/'+name,True)
    result=json.loads((folder/name/'RESULTS.json').read_text())
    failed=[x['name'] for x in result['checks'] if not x['passed']]
    summary.append({'name':name,'before':old,'after':new,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'passed':result['passed'],'failed':result['failed'],'exit_code':execution['exit_code'],'inputs_unchanged':execution['inputs_unchanged'],'required_witness':witness,'required_witness_failed':witness in failed,'all_failed_rows':failed,'scope':'Actual witness subset: first rational k/nu, selected canonical sites, first linear sphere family; no producer computation.'})
with (folder/'SUMMARY.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if all(x['exit_code']==1 and x['required_witness_failed'] and x['inputs_unchanged'] for x in summary) else 1)
