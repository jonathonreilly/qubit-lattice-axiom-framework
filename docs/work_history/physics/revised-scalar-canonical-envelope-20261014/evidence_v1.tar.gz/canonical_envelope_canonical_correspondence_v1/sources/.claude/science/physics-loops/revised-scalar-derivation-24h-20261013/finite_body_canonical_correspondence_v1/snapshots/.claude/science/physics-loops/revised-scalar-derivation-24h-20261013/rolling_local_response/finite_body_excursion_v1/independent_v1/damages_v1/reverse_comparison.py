"""Blind action-coordinate identities and distinct finite-body controls."""
from pathlib import Path
import argparse
import hashlib
import json
import mpmath as mp
import sympy as sp

mp.mp.dps=65
checks=[]
def encode(x):return mp.nstr(x,57) if isinstance(x,mp.mpf) else str(x)
def ck(name,ok,**data):checks.append({'name':name,'passed':bool(ok),'detail':{k:encode(v) for k,v in data.items()}})
def close(x,y):return abs(x-y)<=mp.mpf('1e-35')*max(abs(x),abs(y),mp.mpf('1e-35'))
def rat(t):
    q=sp.Rational(t);return mp.mpf(int(q.p))/int(q.q)
def parameters(k):return (1-k)*(1+3*k)/4,(1+k)/(k*(1-3*k))
def gradient_coefficient(Q):return Q
def source_coefficient(Q,rho):return rho/(2*gradient_coefficient(Q))
def barrier_laplacian(lap_w,c,sqrt_a):return lap_w-sqrt_a*c
def bootstrap(beta0,L,P):return beta0*P/(1-L*P)
def claimed_slope(k,C,q):return (1+k)*C*(1-3*q)**2/(1-3*k)**2
def potential_excess(E,u,s,nu):
    F=1+s*E
    return 3*s*(E-1)**2/(2*F**2)+nu*(1+s)*u*u/(2*F**2)
def data(k,t):
    a,s=parameters(k);E=mp.exp(t);F=1+s*E;J=1+(1-3*a)*s*E
    return a,s,E,F,J
def chi_t(k,t):
    a,s,E,F,J=data(k,t);return mp.sqrt(J)/F/(2*mp.sqrt(a))
def canonical_chi(k,t):return mp.quad(lambda z:chi_t(k,z),[0,t]) if t else mp.mpf(0)
def beta(k,t):
    a,s,E,F,J=data(k,t);return mp.sqrt(a/J)
def U(k,nu,t):
    a,s,E,F,J=data(k,t);return potential_excess(E,t/(2*mp.sqrt(a)),s,nu)
def conformal_A(k,t):
    a,s,E,F,J=data(k,t);return mp.sqrt((1+s)*E/F)
def V_sphere(r,R,Phi):return Phi*(3-r*r/(R*R))/2 if r<=R else Phi*R/r
def massive_profile(r,R,m,c,beta0):
    x=m*R;prefactor=c*beta0/(m*m)
    if r==0:return prefactor*(1-(1+x)*mp.exp(-x))
    if r<=R:return prefactor*(1-(1+x)*mp.exp(-x)*mp.sinh(m*r)/(m*r))
    return prefactor*R*(mp.cosh(x)-mp.sinh(x)/x)*mp.exp(-m*r)/r
def massive_green(r,R,m,c,beta0):
    if r==0:return c*beta0*mp.quad(lambda s:s*mp.exp(-m*s),[0,R])
    cut=min(r,R)
    inner=mp.exp(-m*r)*mp.quad(lambda s:s*mp.sinh(m*s),[0,cut])
    outer=mp.sinh(m*r)*mp.quad(lambda s:s*mp.exp(-m*s),[cut,R]) if r<R else mp.mpf(0)
    return c*beta0*(inner+outer)/(m*r)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True);ap.add_argument('--output',required=True);ap.add_argument('--witness-only',action='store_true');args=ap.parse_args()
    out=Path(args.inputs);protocol=json.loads((out/'INDEPENDENT_PROTOCOL_v1.json').read_text())
    ks=protocol['k_rational'][:1] if args.witness_only else protocol['k_rational'];nus=protocol['nu_rational'][:1] if args.witness_only else protocol['nu_rational']
    E,u,Q,rho,g,Yd,Ad=sp.symbols('E u Q rho g Yd Ad',positive=True)
    factor=2*gradient_coefficient(Q)
    EL=(2*Q*Yd+rho*Ad)/factor
    ck('held_density_factor',sp.simplify(source_coefficient(Q,rho)-rho/(2*Q))==0)
    ck('potential_variation_factor',sp.simplify(EL.coeff(Yd)-1)==0 if EL.is_Add else sp.simplify(sp.diff(EL,Yd)-1)==0)
    ck('gradient_variation_factor',sp.diff(gradient_coefficient(Q)*g*g,g)==2*Q*g)
    ck('sphere_newton_normalization',sp.simplify(source_coefficient(Q,rho)*sp.Rational(4,2)-rho/Q)==0)
    c=sp.Rational(7,3);sa=sp.Rational(1,2);lap_w=-sa*c/2
    computed=barrier_laplacian(lap_w,c,sa)
    ck('maximum_principle_laplacian',computed==sa*c/2 and computed>0)
    ck('maximum_principle_boundary_direction',sp.Rational(-1,2)<0)
    exact=[];canonical=[];profile_rows=[]
    for kval in ks:
        kr=sp.Rational(kval);a,s=parameters(kr);b=1-3*a;F=1+s*E;J=1+b*s*E;C=(1+s)*E/F;q=a/J
        direct=-sp.diff(sp.sqrt(a)/sp.sqrt(J),E)*2*sp.sqrt(a)*E/(sp.sqrt(J)/F)
        stated=claimed_slope(kr,C,q)
        ck('beta_derivative_action',sp.simplify(direct-stated)==0,k=kval)
        ck('q_C_relation',sp.simplify(q-a*(1+s-s*C)/(1+s-3*a*s*C))==0,k=kval)
        ck('vacuum_beta_slope',sp.simplify(direct.subs(E,1)-(1+kr))==0,k=kval)
        ck('slope_monotonic',sp.simplify(sp.diff(direct,E)-a*b*s*(1+(2-b)*s*E)/(1+b*s*E)**3)==0,k=kval)
        ck('negative_branch_lipschitz_sharp',a>kr and a<sp.Rational(1,3) and b>0,k=kval)
        ck('positive_branch_exceeds_L',sp.simplify(direct.subs(E,2)-(1+kr))>0,k=kval)
        for pp in [sp.Rational(1,20),sp.Rational(1,4)]:
            beta0=sp.sqrt(kr);L=1+kr;W=bootstrap(beta0,L,pp)
            ck('positive_operator_fixed_point',sp.simplify(W-beta0*pp-L*pp*W)==0,k=kval,P=pp)
            ck('bootstrap_q_bound',sp.simplify((beta0+L*W)**2-kr/(1-L*pp)**2)==0,k=kval,P=pp)
            ck('integrated_beta_bound',sp.simplify(beta0*W+L*W*W/2-kr*pp*(1-L*pp/2)/(1-L*pp)**2)==0,k=kval,P=pp)
        ck('LP_ge_one_does_not_close',sp.Integer(10)**6<=sp.sqrt(kr)*2/(1+kr)+2*sp.Integer(10)**6,k=kval)
        for nval in nus:
            nr=sp.Rational(nval);Eu=sp.exp(2*sp.sqrt(a)*u);Uu=potential_excess(Eu,u,s,nr);K0=(1+b*s)/(1+s)**2
            # The limit is taken along real u -> -infinity; no field redefinition is imported.
            tail=sp.limit(Uu/u**2,u,-sp.oo)
            ck('negative_infinity_coercivity',sp.simplify(tail-nr*(1+s)/2)==0 and tail>0,k=kval,nu=nval,tail=tail)
            mass=sp.simplify(sp.diff(Uu,u,2).subs(u,0)/K0)
            ck('vacuum_mass_normalization',sp.simplify(mass-4*(3*(1+kr)+nr)/(1-3*kr))==0,k=kval,nu=nval)
            ck('negative_potential_sign',sp.simplify(Uu.subs(u,-1))>0,k=kval,nu=nval)
            exact.append({'k':kval,'nu':nval,'coercive_tail':str(tail),'vacuum_mass_Hv2':str(mass)})
        k=rat(kval);L=1+k
        sites=['-3','0','1'] if args.witness_only else protocol['log_E_sites']
        for tval in sites:
            t=mp.mpf(tval);a0,s0,e0,f0,j0=data(k,t);chi=canonical_chi(k,t);bb=beta(k,t);AA=conformal_A(k,t);qq=bb*bb
            derivative=-mp.diff(lambda z:beta(k,z),t)/chi_t(k,t);formula=claimed_slope(k,AA*AA,qq)
            ck('beta_derivative_numeric',close(derivative,formula),k=kval,t=tval)
            if t<=0:
                w=-chi
                ck('beta_lipschitz_negative',bb>=mp.sqrt(k)-mp.mpf('1e-50') and bb<=mp.sqrt(k)+L*w+mp.mpf('1e-50'),k=kval,t=tval)
                ck('beta_global_ceiling',qq>=k-mp.mpf('1e-50') and qq<a0,k=kval,t=tval)
                ck('logA_two_independent_bounds',-mp.log(AA)<=min(mp.sqrt(a0)*w,mp.sqrt(k)*w+L*w*w/2)+mp.mpf('1e-50'),k=kval,t=tval)
                if t<0:
                    for nval in nus:
                        nu=rat(nval);force=mp.diff(lambda z:U(k,nu,z),t)/chi_t(k,t)
                        ck('potential_gradient_negative',force<0,k=kval,t=tval,nu=nval)
            else:ck('L_not_positive_branch_bound',derivative>L,k=kval,t=tval)
            canonical.append({'k':kval,'log_E':tval,'chi':chi,'A':AA,'beta':bb,'minus_beta_chi':derivative})
        # Independent bounded-density tail test supports the truncation argument.
        tcut=-100*mp.sqrt(a0)
        for nval in nus:
            nu=rat(nval);force=mp.diff(lambda z:U(k,nu,z),tcut)/chi_t(k,tcut)+mp.mpf('1e6')*conformal_A(k,tcut)*beta(k,tcut)
            ck('negative_tail_clipping_force',force<0,k=kval,nu=nval,force=force)
        sphere=protocol['linear_synthetic_sphere'];R=mp.mpf(sphere['radius']);phis=sphere['surface_compactness'][:1] if args.witness_only else sphere['surface_compactness'];mRs=sphere['mass_times_radius'][:1] if args.witness_only else sphere['mass_times_radius']
        for pv in phis:
            Phi=rat(pv);c0=3*Phi/(R*R);b0=mp.sqrt(k)
            for mv in mRs:
                m=mp.mpf(mv)/R
                for rv in sphere['radius_sites_over_R']:
                    r=mp.mpf(rv)*R;w=massive_profile(r,R,m,c0,b0);wg=massive_green(r,R,m,c0,b0);VV=V_sphere(r,R,Phi)
                    ck('massive_sphere_green',close(w,wg),k=kval,Phi=pv,mR=mv,rR=rv)
                    ck('massive_sphere_comparison',0<=w<=b0*VV*(1+mp.mpf('1e-45')),k=kval,Phi=pv,mR=mv,rR=rv)
                    profile_rows.append({'k':kval,'Phi':pv,'mR':mv,'rR':rv,'w':w,'green':wg,'beta0_V':b0*VV})
                x=m*R;pref=c0*b0/m**2
                win=lambda rr:pref*(1-(1+x)*mp.exp(-x)*mp.sinh(m*rr)/(m*rr))
                wout=lambda rr:pref*R*(mp.cosh(x)-mp.sinh(x)/x)*mp.exp(-m*rr)/rr
                ck('sphere_interface_value',close(win(R),wout(R)),k=kval,Phi=pv,mR=mv)
                ck('sphere_interface_flux',close(mp.diff(win,R),mp.diff(wout,R)),k=kval,Phi=pv,mR=mv)
                for rr,fn,src in [(R/3,win,c0*b0),(2*R,wout,mp.mpf(0))]:
                    residual=-mp.diff(fn,rr,2)-2/rr*mp.diff(fn,rr)+m*m*fn(rr)-src
                    ck('massive_sphere_equation',abs(residual)<mp.mpf('1e-35')*c0*b0,k=kval,Phi=pv,mR=mv)
                if pv==phis[0] and mv==mRs[0]:
                    integral=lambda fn:mp.quad(fn,[0,R])+mp.quad(fn,[R,mp.inf])
                    energy=integral(lambda rr:rr*rr*(mp.diff(lambda z:massive_profile(z,R,m,c0,b0),rr)**2+m*m*massive_profile(rr,R,m,c0,b0)**2))
                    work=c0*b0*mp.quad(lambda rr:rr*rr*massive_profile(rr,R,m,c0,b0),[0,R])
                    ck('massive_sphere_energy_identity',close(energy,work),k=kval,energy=energy,source_work=work)
    result={'scope':'Blind action/proof controls and synthetic linear matching; no nonlinear producer solver or empirical body inference.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'dps':mp.mp.dps,'witness_only':args.witness_only,'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'exact_coefficients':exact,'canonical_rows':canonical,'linear_profile_rows':profile_rows}
    with Path(args.output).open('x') as f:json.dump(result,f,indent=2,default=encode);f.write('\n')
    print(json.dumps({k:result[k] for k in ['passed','failed','source_sha256','witness_only']}))
    raise SystemExit(1 if result['failed'] else 0)

if __name__=='__main__':main()
