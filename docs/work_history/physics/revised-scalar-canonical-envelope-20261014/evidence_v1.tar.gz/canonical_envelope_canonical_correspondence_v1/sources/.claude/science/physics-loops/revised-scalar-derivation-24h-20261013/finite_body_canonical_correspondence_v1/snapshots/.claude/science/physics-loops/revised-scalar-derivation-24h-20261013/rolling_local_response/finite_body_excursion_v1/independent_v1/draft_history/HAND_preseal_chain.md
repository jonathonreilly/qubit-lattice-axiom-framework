# Independent action and finite-body proof

The original handwritten note and protocol were frozen before review. The full supplied action was then frozen to check its metric, conformal factor and potential. No producer implementation or result was opened. The separately versioned parent v2 was inspected only for the boundary-at-infinity repair identified below.

## Fixed variables and canonical coordinate

Here chi denotes the canonical integral of sqrt(K_uu). It is not the bounded variable s(C-1), also named chi in the older confinement note. On x=y=0 put alpha=sqrt(a), b=1-3a>0, E=exp(2alpha u), F=1+sE and J=1+bsE. Then

    dchi/du=sqrt(J)/F,
    A=sqrt((1+s)E/F),
    beta=d ln A/dchi=alpha/sqrt(J), q=a/J.

The transverse potential derivatives and the relevant connection components vanish when x=y=0, so restricting to this scalar channel is consistent with the supplied fixed-metric field equations. Parameters k, nu, Q and Hv are held fixed when differentiating. The density held fixed is rhoStar=m_J n_E, not rho_J; the latter equals rhoStar/A^3. The corresponding Einstein energy density is A rhoStar.

Varying E[chi] with gradient coefficient Q gives -2Q Delta chi+2Q Y_chi+rhoStar A_chi=0. The matter coefficient is therefore c=rhoStar/(2Q)=4pi Gvac rhoStar, with Gvac=1/(8pi Q). Inserting a half before the gradient energy would change this equation. c has dimensions inverse length squared, while chi, beta and the Newton potential V are dimensionless.

## Exact derivative and branch domain

Solving C=A^2 for E yields E=C/(1+s-sC), hence

    q=a(1+s-sC)/(1+s-3asC).

Direct differentiation of beta in the original u coordinate, followed by division by dchi/du, gives

    -beta_chi=a b s E F/J^2.

Using b=(1-3k)^2/4 and 1+s=4a/[k(1-3k)] converts this exactly to

    (1+k) A^2 (1-3q)^2/(1-3k)^2.

For u<=0, A<=1 and k<=q<a, so its magnitude is at most L=1+k. Equality holds at the vacuum. With t=sE, the derivative of t(1+t)/(1+bt)^2 is [1+(2-b)t]/(1+bt)^3>0. The slope magnitude therefore grows strictly with E; extending the same L bound onto u>0 would be false. On the negative half-line,

    sqrt(k)<=beta(-w)<=sqrt(k)+Lw,
    -ln A(-w)=integral_0^w beta(-z) dz
             <=sqrt(k)w+Lw^2/2 <=sqrt(a)w.

The last displayed two upper bounds are each valid; the quadratic expression need not be less than the sqrt(a) expression. They may be combined by taking their minimum, not by ordering them.

## Potential sign and coercivity

The actual negative-branch excess potential is

    U-U0=3s(E-1)^2/(2F^2)+nu(1+s)u^2/(2F^2), U0=3/2.

Its u derivative is a sum of negative terms for u<0:

    6alpha s(1+s)E(E-1)/F^3
      +nu(1+s)u[1+sE(1-2alpha u)]/F^3 <0.

Division by the positive canonical Jacobian preserves the sign. As u tends to minus infinity, dchi/du tends to 1 and chi/u tends to 1; thus

    (U-U0)/chi^2 ->nu(1+s)/2>0.

At the origin, U_chichi=4[3(1+k)+nu]/(1-3k)>0. The ratio (U-U0)/chi^2 extends continuously there with half this value, is strictly positive at every other finite negative chi, and has a positive limit at minus infinity. A compact-middle-interval argument gives a global positive lower bound for fixed parameters. The coefficient is not asserted uniform in parameter limits. Setting nu to zero removes this particular coercivity proof; it does not itself prove nonexistence of every static solution.

## Comparison and bootstrap

For any bounded negative-branch solution with the stipulated decay, w=-chi obeys

    -Delta w=Y_chi+c A beta <=c sqrt(a).

Because -Delta V=c, Delta(w-sqrt(a)V)>=0. The weak maximum principle on expanding balls, with the limiting boundary zero, gives w<=sqrt(a)V. The lower bound w>=0 is the branch hypothesis, not a second consequence of this comparison. Integrating beta gives -ln A<=sqrt(a)w<=aV.

Likewise -Delta w<=c(sqrt(k)+Lw). Let T f be the positive Newton potential of cf. Since c has bounded compact support and w is bounded, Tf is finite and decays. Comparison gives w<=sqrt(k)V+L T w. The operator norm on bounded nonnegative functions is P=sup V: the constant function 1 attains that norm. Consequently W<=sqrt(k)P+LPW. Only if LP<1 can this inequality close to

    W<=sqrt(k)P/(1-LP),
    q<=[sqrt(k)+LW]^2<=k/(1-LP)^2,
    -ln A<=kP(1-LP/2)/(1-LP)^2.

The exact global ceiling q<a remains available. Neither beta squared nor these displacement bounds alone specify the external integrated force charge. If LP>=1 this particular inequality supplies no finite upper bound; it is not a nonexistence criterion.

For a held uniform sphere, -Delta V=3 Phi_surface/R^2 inside and zero outside. The matched solution is V=Phi_surface(3-r^2/R^2)/2 inside, Phi_surface R/r outside. It has continuous value and radial derivative at R, decays at infinity, and P=3 Phi_surface/2. This uses the supplied Einstein radius and Gvac MStar/R, not a measured Jordan-frame compactness.

## Direct-method existence and the repaired decay step

Minimize the energy over the closed cone of nonpositive H^1(R^3) functions. The excess potential's positive quadratic lower bound controls the L^2 norm; the gradient term controls its derivative. A minimizing sequence is bounded in H^1. A subsequence converges weakly in H^1 and almost everywhere by local Rellich compactness and a diagonal argument. Gradient energy is weakly lower semicontinuous; Fatou applies to the nonnegative excess potential. Since 0<A<=1 and rhoStar is bounded with compact support, dominated convergence applies to its matter term. Zero is admissible and has finite energy MStar. These facts give a minimizer without requiring a smooth density interface or convexity of the potential.

The negative tail can be truncated. Uniformly for 0<=c<=cmax, Y_chi tends to minus infinity while c A_chi tends to zero as chi tends to minus infinity. Choose a finite lower cutoff where the derivative of the total non-gradient energy is strictly negative. Raising values below that cutoff lowers the local energy and cannot increase the Sobolev gradient term. A minimizer is consequently bounded below. It is already bounded above by zero.

Clipping any sufficiently small admissible variation's positive part to zero also lowers its energy: the excess potential is nonnegative, A>=1 there, and the gradient decreases. The nonpositive minimizer is therefore a local unconstrained minimizer with respect to compact smooth variations that stay within the original positive canonical chart. The positive chart has nonzero width even though its remote endpoint is finite. The Euler-Lagrange equation holds distributionally, without an obstacle measure at chi=0.

The original v1 did not explicitly justify the boundary after the weak variational limit. H^1 membership alone does not imply uniform pointwise decay. The accepted v2 repair closes this gap using only the existing assumptions. The bounded minimizer and bounded density give a globally bounded elliptic right-hand side. Translation-uniform interior W^{2,p} estimates for any fixed p>3, with uniform local field bounds, give uniform continuity (in fact local C^{1,alpha} bounds uniform in translations). If |chi| stayed above epsilon along points escaping to infinity, uniform continuity would give disjoint balls of one fixed radius on which |chi|>=epsilon/2. Their L^2 mass would diverge. Thus chi tends uniformly to zero. The maximum-principle comparisons now apply to the constructed minimizer. This is not a new regularity hypothesis on the source.

For a bounded density jump, the equation is interpreted weakly; local W^{2,p} regularity precludes an added delta-function source. At a smooth interface the canonical field and normal derivative match. Neither a hard Dirichlet boundary at the matter surface nor an independently prescribed interior minimum is part of this existence construction.

## Energy and realization limits

Minimality against zero gives scalar energy <=integral rhoStar(1-A)<=MStar sup(-ln A). Testing the weak equation with cutoff approximations to chi and sending the cutoff to infinity gives

    integral |grad chi|^2+integral chi Y_chi
       =integral c A beta w <=integral c beta w.

All terms are integrable: chi is in H^1, Y_chi is bounded by a fixed multiple of |chi| on its bounded negative range, and the matter term has compact support. The nonnegative middle term gives the stated gradient bound. The clipping argument constructs a minimizer; it does not establish uniqueness or a dynamical attraction basin.

The synthetic massive sphere used in the independent code solves (-Delta+m^2)w=c sqrt(k), not the full nonlinear candidate. Its closed matched profile and separate Yukawa Green integral test factors, signs, infinity behavior and comparison without claiming a realized body. The scalar positive-operator fixed point is likewise a bootstrap-algebra witness, not an empirical environmental state.

The entire result remains a held-source flat-patch elliptic model. The positive vacuum scale makes a literal globally Minkowski asymptotic physical spacetime inappropriate, as the parent explicitly states. Support stresses, metric errors, ambient matching, a measured force normalization and dynamical realization remain separate. A forbidden large homogeneous-interior excursion does not exclude all static states or the full theory.
