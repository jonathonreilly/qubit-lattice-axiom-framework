"""Fresh actual-input freezes and complete execution preservation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import subprocess
import sys

OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def execute(source,name,witness=False):
    run=OUT/name;run.mkdir(exist_ok=False)
    docs=json.loads((OUT/'FREEZE_v2.json').read_text())['sources']+json.loads((OUT/'affected_v2/FREEZE_complete.json').read_text())['sources']
    inputs=[source,OUT/'INDEPENDENT_PROTOCOL_v1.json',OUT/'HAND_DERIVATION_v1.md']+[OUT/r['snapshot_path'] for r in docs]
    identities=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in inputs]
    save(run/'FREEZE.json',{'at':datetime.now(timezone.utc).isoformat(),'actual_inputs':identities,'mutation_detection_is_mathematical_not_original_hash_comparison':True})
    argv=[sys.executable,'-B',str(source),'--inputs',str(OUT),'--output',str(run/'RESULTS.json')]
    if witness:argv.append('--witness-only')
    start=datetime.now(timezone.utc).isoformat();r=subprocess.run(argv,cwd=OUT,capture_output=True,timeout=240);end=datetime.now(timezone.utc).isoformat()
    for name_,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
        with (run/name_).open('xb') as f:f.write(data)
    result={'argv':argv,'cwd':str(OUT),'started_utc':start,'finished_utc':end,'exit_code':r.returncode,'source_sha256':sha(source),'inputs_unchanged':all(sha(Path(x['path']))==x['sha256'] for x in identities)}
    save(run/'EXECUTION.json',result)
    print(json.dumps(result),flush=True);print(r.stdout.decode(),flush=True)
    if r.stderr:print(r.stderr.decode(),flush=True)
    return result
if __name__=='__main__':execute(OUT/'check_independent_v1.py','baseline_v1')
