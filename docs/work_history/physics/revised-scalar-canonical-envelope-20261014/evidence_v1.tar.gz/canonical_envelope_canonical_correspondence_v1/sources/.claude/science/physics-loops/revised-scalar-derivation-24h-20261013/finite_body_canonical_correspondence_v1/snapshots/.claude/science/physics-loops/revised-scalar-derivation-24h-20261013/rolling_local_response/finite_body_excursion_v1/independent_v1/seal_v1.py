"""Identity-only finalization; never reruns scientific calculations."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import sys

P = Path(__file__).resolve().parent

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(name):
    return json.loads((P / name).read_text())

def write(name, value):
    path = P / name
    assert not path.exists(), f"Refuse overwrite: {path}"
    path.write_text(json.dumps(value, indent=2) + "\n")

assert not (P / "MANIFEST_v1.json").exists()
assert not (P / "RECEIPT_v1.json").exists()
sources = read("FREEZE_v2.json")["sources"] + read("affected_v2/FREEZE_complete.json")["sources"]
dispositions = []
for source in sources:
    original = Path(source["original_path"])
    snapshot = P / source["snapshot_path"]
    assert sha(original) == sha(snapshot) == source["sha256"]
    assert original.read_bytes() == snapshot.read_bytes()
    dispositions.append({"original_path": str(original), "original_sha256": source["sha256"],
        "disposition": "Fully read and independently checked within the stated proof/action scope; unchanged original preserved.",
        "recovery": str(snapshot), "recovery_sha256": sha(snapshot),
        "final_path": str(original), "final_sha256": sha(original)})
write("SOURCE_DISPOSITIONS_v1.json", {"original_dispositions": dispositions})

baseline = read("baseline_v1/RESULTS.json")
assert (baseline["passed"], baseline["failed"]) == (598, 0)
assert len(baseline["checks"]) == 598
assert len(baseline["exact_coefficients"]) == 8
assert len(baseline["canonical_rows"]) == 24
assert len(baseline["linear_profile_rows"]) == 144
assert sha(P / "check_independent_v1.py") == baseline["source_sha256"]
damage = read("damages_v1/SUMMARY.json")
expected = [(50, 1), (47, 4), (45, 6), (47, 4), (48, 3)]
executions = []
run_dirs = ["baseline_v1"] + ["damages_v1/" + d["name"] for d in damage]
for n, run_dir in enumerate(run_dirs):
    result = read(run_dir + "/RESULTS.json")
    execution = read(run_dir + "/EXECUTION.json")
    freeze = read(run_dir + "/FREEZE.json")
    assert len(freeze["actual_inputs"]) == 9
    for item in freeze["actual_inputs"]:
        assert sha(Path(item["path"])) == item["sha256"]
    assert execution["inputs_unchanged"]
    assert execution["source_sha256"] == result["source_sha256"]
    assert len(result["checks"]) == result["passed"] + result["failed"]
    if n == 0:
        assert execution["exit_code"] == 0
    else:
        d = damage[n - 1]
        assert (result["passed"], result["failed"]) == expected[n - 1]
        assert d["required_witness_failed"] and execution["exit_code"] == 1
        assert sha(P / ("damages_v1/" + d["name"] + ".py")) == d["source_sha256"]
        assert any(c["name"] == d["required_witness"] and not c["passed"] for c in result["checks"])
    executions.append({"record": run_dir + "/EXECUTION.json", **execution})
affected = read("affected_v2/RESULTS.json")
assert (affected["passed"], affected["failed"]) == (22, 0)
affected_exec = read("affected_v2/EXECUTION.json")
assert affected_exec["exit_code"] == 0
assert affected_exec["source_sha256"] == sha(P / "check_affected_v2.py")
executions.append({"record": "affected_v2/EXECUTION.json", **affected_exec})
write("COMMAND_INDEX_v1.json", {"science_execution_records": executions,
    "outer_entrypoints": ["python3 -B execute_v1.py", "python3 -B damage_controls_v1.py"],
    "affected_entrypoint": affected_exec["argv"],
    "seal_entrypoint": [sys.executable, "-B", str(Path(__file__).resolve())],
    "seal_scope": "Read stored results and current identities only; no scientific replay."})
write("ENVIRONMENT_v1.json", {"python": sys.version, "platform": platform.platform(),
    "executable": sys.executable, "precision": baseline["dps"],
    "no_parent_implementation_or_result_read": True})
artifacts = []
for path in sorted(P.rglob("*")):
    if path.is_file():
        assert not path.is_symlink()
        artifacts.append({"path": str(path.relative_to(P)), "bytes": path.stat().st_size, "sha256": sha(path)})
write("MANIFEST_v1.json", {"schema": "closed-artifacts-v1", "excludes": ["MANIFEST_v1.json", "RECEIPT_v1.json"],
    "artifacts": artifacts})
bound = ["REPORT_v1.md", "MANIFEST_v1.json", "SOURCE_DISPOSITIONS_v1.json", "HAND_DERIVATION_v1.md",
    "FAILURES_v1.md", "INDEPENDENT_PROTOCOL_v1.json", "COMMAND_INDEX_v1.json", "baseline_v1/RESULTS.json",
    "baseline_v1/EXECUTION.json", "damages_v1/SUMMARY.json", "affected_v2/RESULTS.json", "BOUNDARY_FINDING_v1.md"]
write("RECEIPT_v1.json", {"sealed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "Independent finite-body excursion v1 and narrow v2 decay proof; no surface-force addendum or producer numerical review.",
    "report": "REPORT_v1.md", "manifest": "MANIFEST_v1.json", "artifact_count": len(artifacts),
    "source_pair_count": len(dispositions), "baseline": {"passed": 598, "failed": 0},
    "affected_v2": {"passed": 22, "failed": 0}, "actual_damaged_programs": 5,
    "all_actual_damage_witnesses_failed": True, "original_dispositions": "SOURCE_DISPOSITIONS_v1.json",
    "bindings": [{"path": name, "sha256": sha(P / name)} for name in bound],
    "immutable_policy": "No edits after seal; any amendment must use a new version and preserve these bytes."})
for name in ["REPORT_v1.md", "MANIFEST_v1.json", "RECEIPT_v1.json", "SOURCE_DISPOSITIONS_v1.json"]:
    print(name, sha(P / name))
print("artifacts", len(artifacts), "source_pairs", len(dispositions))
