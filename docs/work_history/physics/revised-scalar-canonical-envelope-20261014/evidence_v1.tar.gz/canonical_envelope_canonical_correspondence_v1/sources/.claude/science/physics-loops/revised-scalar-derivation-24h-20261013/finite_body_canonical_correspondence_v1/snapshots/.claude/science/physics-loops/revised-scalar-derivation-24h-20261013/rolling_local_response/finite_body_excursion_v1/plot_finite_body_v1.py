from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

p=Path(__file__).resolve().parent
data=json.loads((p/'surface_baseline_v2/RESULTS.json').read_text())
base=json.loads((p/'baseline_v4/RESULTS.json').read_text())
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(1,3,figsize=(11.2,3.8),sharey=True,layout='constrained')
colors=['#007c91','#bb5b21']
for ax,k in zip(axes,[.01,.1,.3]):
    for compact,color,marker in zip([.0001,.01],colors,['o','s']):
        rows=sorted([r for r in data['cases'] if r['k']==k and base['cases'][r['index']]['Phi_surface']==compact],key=lambda r:base['cases'][r['index']]['mu_vac_R'])
        x=[base['cases'][r['index']]['mu_vac_R'] for r in rows];y=[r['surface_eta']/k for r in rows];lo=[r['lower']/k for r in rows];hi=[r['upper']/k for r in rows]
        ax.fill_between(x,lo,hi,color=color,alpha=.09)
        ax.plot(x,lo,color=color,ls=':',lw=1.2);ax.plot(x,hi,color=color,ls='--',lw=1)
        ax.plot(x,y,color=color,marker=marker,lw=1.4,label=r'$\Phi_*='+str(compact)+'$')
    ax.set_xscale('log');ax.set_title(r'$k='+str(k)+'$');ax.set_xlabel(r'Vacuum inverse range $m_{\rm vac}R$');ax.set_ylim(-.02,1.12);ax.grid(alpha=.2)
axes[0].set_ylabel(r'Surface scalar / Newton force, $\eta_s/k$');axes[-1].legend(loc='lower left',frameon=False,fontsize=9)
fig.suptitle('Derived force bracket and nonlinear held-sphere solutions',fontsize=13)
fig.text(.5,-.04,'Synthetic exposed cases; dots: nonlinear solutions; shaded: analytic bracket. Zero lower edge is uninformative.\nFixed flat metric, prescribed uniform particle density, vacuum boundary; not a measured solar or laboratory fit.',ha='center',fontsize=9)
for ext in ['png','pdf']:fig.savefig(p/('SURFACE_FORCE_BRACKET_v1.'+ext),dpi=180,bbox_inches='tight')
plt.close(fig)
rows=[]
fig,axes=plt.subplots(1,2,figsize=(9.6,3.8),layout='constrained')
for row,color in zip([r for r in base['cases'] if r['k']==.1 and r['Phi_surface']==.01],['#007c91','#d68b21','#6c52a3']):
    path=p/'baseline_v4'/row['profile'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['profile_sha256']
    with np.load(path,allow_pickle=False) as d:
        mask=d['r']<=5
        axes[0].plot(d['r'][mask],-d['chi'][mask]/row['w_bound'],label=r'$m_{\rm vac}R='+str(row['mu_vac_R'])+'$',color=color)
        mask=(d['r']>=1)&(d['r']<=5)
        axes[1].plot(d['r'][mask],d['beta'][mask]*d['flux'][mask]/row['Phi_surface']/.1,color=color)
    rows.append(dict(index=row['index'],profile_sha256=row['profile_sha256']))
axes[0].axvline(1,color='.4',lw=.8,ls='--');axes[0].axhline(1,color='.6',lw=.8,ls=':');axes[0].set_ylabel(r'Field displacement / bound, $-\chi/W_b$');axes[0].legend(frameon=False)
axes[1].set_ylabel(r'Exterior scalar / Newton force, $\eta(r)/k$')
for ax in axes:ax.set_xlabel(r'Radius $r/R$');ax.grid(alpha=.2)
fig.suptitle(r'Finite size controls the field and exterior force: $k=0.1$, $\Phi_*=0.01$',fontsize=12)
fig.text(.5,-.04,'Synthetic prescribed source; range suppression is calculated from the field equation, not assigned as a shell factor.',ha='center',fontsize=9)
for ext in ['png','pdf']:fig.savefig(p/('FIELD_FORCE_PROFILES_v1.'+ext),dpi=180,bbox_inches='tight')
plt.close(fig)
(p/'PLOT_SOURCE_BINDINGS_v1.json').write_text(json.dumps(dict(surface_results_sha256=hashlib.sha256((p/'surface_baseline_v2/RESULTS.json').read_bytes()).hexdigest(),baseline_results_sha256=hashlib.sha256((p/'baseline_v4/RESULTS.json').read_bytes()).hexdigest(),selected_profiles=rows),indent=2)+'\n')
