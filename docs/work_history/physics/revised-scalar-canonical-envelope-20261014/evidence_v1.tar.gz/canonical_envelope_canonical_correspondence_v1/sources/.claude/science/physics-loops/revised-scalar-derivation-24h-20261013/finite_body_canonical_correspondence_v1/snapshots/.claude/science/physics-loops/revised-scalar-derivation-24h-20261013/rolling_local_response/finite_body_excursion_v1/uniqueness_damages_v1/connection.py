#!/usr/local/bin/python3
from pathlib import Path
import argparse,json,hashlib
import sympy as S
import numpy as np
import mpmath as mp

CONNECTION_SIGN=1
KATO_SIGN=1
DENOMINATOR_SIGN=-1
GROUND_SIGN=-1

def run(source,out,algebra_only=False):
    out.mkdir(parents=True,exist_ok=False);rows=[];cases=[];bindings=[]
    def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
    def eq(n,e):v=S.factor(S.cancel(e));ck(n,v==0,str(v))
    a,s,E,u,nu=S.symbols('a s E u nu',positive=True);alpha=S.sqrt(a);b=1-3*a;F=1+s*E;J=1+b*s*E;K=J/F**2
    D=lambda f:S.diff(f,u)+2*alpha*E*S.diff(f,E)
    hessian=lambda f:D(D(f))/K+CONNECTION_SIGN*D(K)*D(f)/(2*K*K)
    ub=S.Rational(3,2)+S.Rational(3,2)*s*(E-1)**2/F**2;g=u/F;ur=nu*(1+s)*g*g/2
    hb=6*a*s*(1+s)*E*(2*J*(2*E-1+s*E)-b*s*E*(E-1)*F)/(F*F*J*J)
    gp=(1-2*alpha*s*E*u/F)/S.sqrt(J)
    gpp=-2*alpha*s*E/J*(1+2*alpha*u/F)-alpha*b*s*E*F/(J*J)*(1-2*alpha*s*E*u/F)
    eq('base_hessian_factorization',hessian(ub)-hb)
    eq('regulator_g_first_squared',D(g)**2/K-gp**2)
    eq('regulator_g_second',hessian(g)-gpp)
    eq('regulator_hessian_factorization',hessian(ur)-nu*(1+s)*(gp*gp+g*gpp))
    L,P,R,Beta=S.symbols('L P R Beta',positive=True)
    bound=Beta*R/(1+DENOMINATOR_SIGN*L*P)
    eq('difference_source_contraction',bound-(Beta*R+KATO_SIGN*L*P*bound))
    ck('kato_upper_sign',KATO_SIGN>0)
    # Pointwise identity after the cross term is integrated by parts:
    # |grad(log V)|^2 + Delta(log V) = Delta V/V = -c/V.
    vv,cv,grad2=S.symbols('V c grad2',positive=True)
    laplog=-cv/vv-grad2/vv**2
    eq('ground_state_integration_by_parts',grad2/vv**2+laplog-GROUND_SIGN*cv/vv)
    eq('quadratic_form_gradient_coefficient',1+DENOMINATOR_SIGN*L*P-(1-L*P))
    k=S.symbols('k',positive=True);ak=(1-k)*(1+3*k)/4;sk=(1+k)/(k*(1-3*k));beta=S.sqrt(a/J);beta_chi=-a*b*s*E*F/J**2
    AA=S.sqrt((1+s)*E/F);matter=AA*(a/J+beta_chi)
    for kv in [S.Rational(1,100),S.Rational(1,10),S.Rational(3,10)]:
        for ev in [S.Rational(1,2),S.Rational(3,5),S.Rational(9,10),S.Integer(1)]:
            av=ak.subs(k,kv);sv=sk.subs(k,kv);uv=S.log(ev)/(2*S.sqrt(av));sub={a:av,s:sv,E:ev,u:uv,nu:S.Rational(1,10000)};tag=str(kv)+'_'+str(ev)
            h1=float(hb.subs(sub));h2=float((nu*(1+s)*(gp*gp+g*gpp)).subs(sub))
            ck('base_convex_'+tag,h1>0,h1);ck('regulator_convex_'+tag,h2>0,h2)
            ck('regulator_gpp_'+tag,float(gpp.subs(sub))<0)
            ck('matter_one_sided_'+tag,float(matter.subs(sub))>=-float(1+kv))
    if not algebra_only:
        mp.mp.dps=65
        for slope in [mp.mpf('0.1'),mp.mpf('1'),mp.mpf('10')]:
            f=lambda r:mp.exp(-slope*r*r);df=lambda r:-2*slope*r*f(r)
            V=lambda r:(3-r*r)/6 if r<=1 else 1/(3*r)
            Vp=lambda r:-r/3 if r<=1 else -1/(3*r*r)
            left=mp.quad(lambda r:r*r*(df(r)-f(r)*Vp(r)/V(r))**2,[0,1,mp.inf])
            grad=mp.quad(lambda r:r*r*df(r)**2,[0,1,mp.inf]);weighted=mp.quad(lambda r:r*r*f(r)**2/V(r),[0,1]);mass=mp.quad(lambda r:r*r*f(r)**2,[0,1]);Pval=mp.mpf('.5')
            err=abs(left-(grad+GROUND_SIGN*weighted));ck('radial_ground_identity_'+str(slope),err<mp.mpf('1e-55'),str(err));ck('radial_source_form_bound_'+str(slope),mass<=Pval*grad)
        src=source/'RESULTS.json';data=json.loads(src.read_text());bindings.append(dict(path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
        for row in data['cases']:
            kv=row['k'];av=float(ak.subs(k,kv));sv=float(sk.subs(k,kv));sub={a:av,s:sv,nu:row['nu']};K0=float(K.subs({**sub,E:1}));Pval=1.5*row['Phi_surface'];LP=(1+kv)*Pval;umax=np.sqrt(kv)*Pval/(1-LP)/np.sqrt(K0);criterion=2*np.sqrt(av)*umax
            ok=bool(LP<1 and criterion<=np.log(2));ck('recorded_body_meets_uniqueness_'+str(row['index']),ok,dict(LP=LP,criterion=criterion,ceiling=float(np.log(2))))
            grid=np.linspace(-umax,0,1001);fun=S.lambdify(u,hessian(ub+ur).subs(sub).subs(E,S.exp(2*np.sqrt(av)*u)),'numpy');hv=row['Hv_R_squared'];ys=hv*fun(grid);minimum=float(np.min(ys));ck('sampled_positive_hessian_'+str(row['index']),minimum>0,minimum)
            np.savez_compressed(out/('convexity_'+str(row['index'])+'.npz'),u=grid,Y_chichi=ys)
            cases.append(dict(index=row['index'],k=kv,P=Pval,LP=LP,twice_alpha_Umax=criterion,criterion_met=ok,sampled_hessian_minimum=minimum,interpretation='Sample supplements the analytic proof; it is not a certified global eigenvalue or numerical minimum.'))
    result=dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,cases=cases,source_bindings=bindings,algebra_only=algebra_only,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional unique negative static held-source solution and scalar-only linear stability; no matter/metric stability or settling.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=len(cases),failed_checks=[r for r in rows if not r['passed']]),indent=2));return result['failed']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--algebra-only',action='store_true');args=p.parse_args();raise SystemExit(bool(run(args.source,args.out,args.algebra_only)))
