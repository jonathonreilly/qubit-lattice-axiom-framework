#!/usr/bin/env python3
"""Identity and scope reuse only; no scientific checker is imported or executed."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,difflib
O=Path(__file__).resolve().parent
W=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PREFIX='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/'
U=O/'snapshots'/PREFIX/'rolling_local_response/finite_body_excursion_v1';R=U/'independent_uniqueness_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=lambda p:json.loads(p.read_text())
rows=[]
def ck(n,v,detail=None):rows.append(dict(name=n,passed=bool(v),detail=detail))
def snap(p):return O/'snapshots'/Path(p).relative_to(W)
r=j(R/'RECEIPT_v1.json');m=j(R/'MANIFEST_v1.json');d=j(R/'SOURCE_DISPOSITIONS_v1.json')['original_dispositions']
expected={'REPORT_v1.md':'3f2ffbd250bf96cc85e73fee68863989c732cc2b4f65f2fe5259515de422aada','MANIFEST_v1.json':'4f93b7405e2c0c7b08649c27a9a8372348052ba9a6e039423603aac981f72020','RECEIPT_v1.json':'aec6987f5aee830451a4118e0b874a3e7f03ef9847a2e8e6bbd9f06350f029c8'}
for f,h in expected.items():ck('arrival_hash:'+f,sha(R/f)==h)
ck('94_artifacts',len(m['artifacts'])==r['artifact_count']==94)
listed={x['path'] for x in m['artifacts']};actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}-set(m['excludes'])
ck('complete_closed_manifest',listed==actual)
for x in m['artifacts']:
 p=R/x['path'];ck('artifact:'+x['path'],sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
for x in r['bindings']:ck('receipt_binding:'+x['path'],sha(R/x['path'])==x['sha256'])
ck('24_source_pairs',len(d)==r['source_pair_count']==24)
for x in d:
 ck('source_pair:'+x['original_path'],sha(snap(x['original_path']))==x['original_sha256']==sha(snap(x['recovery']))==x['recovery_sha256'] and sha(snap(x['final_path']))==x['final_sha256'])
for x in j(O/'SOURCE_BINDINGS_v2.json')['source_pairs']:
 if '/independent_uniqueness_v1/' in x['original_path']:
  ck('new_live_snapshot:'+x['original_repo_path'],Path(x['original_path']).read_bytes()==(O/x['snapshot_path']).read_bytes() and sha(O/x['snapshot_path'])==x['sha256'])
b=j(R/'baseline_v1/RESULTS.json');e=j(R/'baseline_v1/EXECUTION.json')
ck('reused_641_0',r['passed']==b['passed']==641 and r['failed']==b['failed']==0 and len(b['checks'])==641 and all(x['passed'] for x in b['checks']))
ck('no_full_blind_claim',r['fully_blind'] is False and 'aggregate 98 passed / 0 failed / 18 cases' in (R/'READ_SCOPE_FAILURE_v1.md').read_text())
report=(R/'REPORT_v1.md').read_text()
ck('surface_v2_source_pair',any(x['original_sha256']=='269e10f9778fbb34a62fc3a3a2511516ca92ec30d5b45a002247611000f392b5' and x['original_path'].endswith('/SURFACE_FORCE_DERIVATION_v2.md') for x in d))
ck('uniqueness_v2_source_pair',any(x['original_sha256']=='ceea5fc3f6d4630e101ed279218c7b66ff2b9da8a751b6eb461e6707bb4a43ae' and x['original_path'].endswith('/UNIQUENESS_DERIVATION_v2.md') for x in d))
ck('full_exact_source_diff',''.join(difflib.unified_diff((U/'UNIQUENESS_DERIVATION_v1.md').read_text().splitlines(True),(U/'UNIQUENESS_DERIVATION_v2.md').read_text().splitlines(True),fromfile='UNIQUENESS_DERIVATION_v1.md',tofile='UNIQUENESS_DERIVATION_v2.md'))==(R/'sources/UNIQUENESS_v1_v2.diff').read_text())
damages=j(R/'damages_v1/SUMMARY.json');ck('seven_actual_damages',len(damages)==r['actual_damaged_programs']==7)
for x in damages:
 root=R/'damages_v1'/x['name'];data=j(root/'RESULTS.json');execution=j(root/'EXECUTION.json')
 ck('damage_counts:'+x['name'],(data['passed'],data['failed'])==(x['passed'],x['failed']) and len(data['checks'])==43)
 ck('damage_named_witness:'+x['name'],x['required_witness_failed'] and any(y['name']==x['required_witness'] and not y['passed'] for y in data['checks']))
 ck('damage_exit:'+x['name'],x['exit_code']==1 and execution['exit_code']==1)
 ck('damage_source_hash:'+x['name'],data['source_sha256']==x['source_sha256'])
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,reused_seal=dict(expected_hashes=expected,artifacts=94,source_pairs=24,receipt_bindings=len(r['bindings']),baseline_counts=[641,0],damages=[dict(name=x['name'],passed=x['passed'],failed=x['failed']) for x in damages]),pending_uniqueness_receipt=False,scientific_functions_executed=False,scope='Exact reuse and affected surface-v2 confirmation; report fully read; independent method is qualified by recorded aggregate-metadata exposure.')
(O/'UNIQUENESS_REUSE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','failed','pending_uniqueness_receipt','scientific_functions_executed']},indent=2));print(json.dumps([x for x in rows if not x['passed']],indent=2));raise SystemExit(bool(result['failed']))
