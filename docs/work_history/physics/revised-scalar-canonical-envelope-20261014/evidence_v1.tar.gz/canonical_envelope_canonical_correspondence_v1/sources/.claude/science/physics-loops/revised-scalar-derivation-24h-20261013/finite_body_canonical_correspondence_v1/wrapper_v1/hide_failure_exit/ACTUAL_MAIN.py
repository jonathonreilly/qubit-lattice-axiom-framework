def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True);units={};streams={}
        for name,fn in [('excursion',check_excursion),('surface',check_surface),('uniqueness',check_uniqueness)]:
            captured=io.StringIO()
            with redirect_stdout(captured):
                if name=='excursion':failed=fn(root/name)
                else:failed=fn(root/'excursion',root/name)
            result=json.loads((root/name/'RESULTS.json').read_text())
            assert failed==result['failed'];units[name]=result;streams[name]=captured.getvalue()
        return dict(passed=sum(z['passed'] for z in units.values()),failed=sum(z['failed'] for z in units.values()),units=units,unit_stdout=streams,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional flat static held-source model, derived force bracket and scalar-only stability. No observed fit, full-metric solution or realized-state selector.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-finite-body-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='');return False
