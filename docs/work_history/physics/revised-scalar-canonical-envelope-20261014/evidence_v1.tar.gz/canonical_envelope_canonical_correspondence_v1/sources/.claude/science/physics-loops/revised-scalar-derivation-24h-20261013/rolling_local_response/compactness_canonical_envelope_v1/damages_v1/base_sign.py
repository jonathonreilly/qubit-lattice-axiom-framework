#!/usr/local/bin/python3
from pathlib import Path
import argparse,json,hashlib
import sympy as S
import numpy as np
import mpmath as mp

REGULATOR_LINEAR=3
REGULATOR_QUADRATIC=2
INVERSE_SIGN=-1
UPPER_BASE_SIGN=-1

def run(source,out,algebra_only=False):
    out.mkdir(parents=True,exist_ok=False);rows=[];old_cases=[];new_cases=[];bindings=[]
    def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
    def eq(n,e):v=S.factor(S.cancel(e));ck(n,v==0,str(v))
    a,s,E,u,nu=S.symbols('a s E u nu',positive=True);alpha=S.sqrt(a);F=1+s*E;J=1+(1-3*a)*s*E;K=J/F**2;q=a/J;d=a*(1-3*a)*s*E*F/J**2;t=s*E/F;z2=(1+s)*E/F;ell=-2*alpha*u
    D=lambda f:S.diff(f,u)+2*alpha*E*S.diff(f,E)
    H=lambda f:D(D(f))/K-D(K)*D(f)/(2*K*K)
    ub=S.Rational(3,2)+S.Rational(3,2)*s*(E-1)**2/F**2;ur=nu*(1+s)*u*u/(2*F*F)
    hb=6*s*z2*(UPPER_BASE_SIGN*d*(1-z2)+2*q*(2*z2-1))
    hr=nu*(1+s)/a*(q*(1+REGULATOR_LINEAR*t*ell+(REGULATOR_QUADRATIC*t*t-t)*ell*ell)+d*(1-t)*ell*(1+t*ell)/2)
    eq('base_conformal_potential',ub-S.Rational(3,2)-S.Rational(3,2)*s*(1-z2)**2)
    eq('base_canonical_hessian',H(ub)-hb)
    eq('regulator_canonical_hessian',H(ur)-hr)
    z=S.symbols('z',positive=True);einverse=z*z/(1+s+INVERSE_SIGN*s*z*z)
    eq('conformal_inverse',(1+s)*einverse/(1+s*einverse)-z*z)
    k=S.symbols('k',positive=True);ak=(1-k)*(1+3*k)/4;sk=(1+k)/(k*(1-3*k))
    eq('vacuum_envelope_mass',(12*s*k+nu*(1+s)*k/a).subs({a:ak,s:sk})-4*(3+3*k+nu)/(1-3*k))
    Delta,ellb,qb,L,h=S.symbols('Delta ellb qb L h',nonnegative=True)
    mc=6*s*(UPPER_BASE_SIGN*L*Delta+2*qb)+nu*(1+s)/a*(qb*(1+REGULATOR_LINEAR*ellb+REGULATOR_QUADRATIC*ellb**2)+L*h*ellb*(1+ellb)/2)
    # A direct rational action witness catches sign/coefficients independently.
    subs={a:S.Rational(3,10),s:S.Integer(10),E:S.Rational(3,5),u:-S.Rational(1,10),nu:S.Rational(1,10000)}
    eq('independent_rational_hessian',H(ub+ur).subs(subs)-(hb+hr).subs(subs))
    if not algebra_only:
        mp.mp.dps=80
        def calculate(kv,Pv,nv,hv):
            av=(1-kv)*(1+3*kv)/4;sv=(1+kv)/(kv*(1-3*kv));Lv=1+kv;B=kv*Pv*(1-Lv*Pv/2)/(1-Lv*Pv)**2;zm=mp.exp(-2*B);delta=-mp.expm1(-2*B);emin=zm/(1+sv*delta);lb=-mp.log(emin);hm=1-sv*zm/(1+sv);qm=min(av,kv/(1-Lv*Pv)**2)
            env=hv*(6*sv*(UPPER_BASE_SIGN*Lv*delta+2*qm)+nv*(1+sv)/av*(qm*(1+REGULATOR_LINEAR*lb+REGULATOR_QUADRATIC*lb*lb)+Lv*hm*lb*(1+lb)/2))
            k0=kv*(1-3*kv)**2/(16*av);wb=mp.sqrt(kv)*Pv/(1-Lv*Pv);oldcriterion=2*mp.sqrt(av)*wb/mp.sqrt(k0);newcriterion=(B<=mp.log(2)/2 and hm*lb<=1)
            fun=S.lambdify((u,E),H(ub+ur).subs({a:S.Rational(str(av)),s:S.Rational(str(sv)),nu:S.Rational(str(nv))}),'mpmath')
            samples=[]
            for j in range(41):
                ll=lb*j/40;uu=-ll/(2*mp.sqrt(av));ee=mp.exp(-ll);HH=hv*fun(uu,ee);samples.append((uu,HH))
            return dict(k=kv,P=Pv,nu=nv,Hv2=hv,B=B,zMin2=zm,EMin=emin,ellMax=lb,hMax=hm,qMax=qm,Mc2=env,old_criterion_value=oldcriterion,new_criterion_met=bool(newcriterion),new_criterion_product=hm*lb),samples
        base=json.loads((source/'baseline_v4/RESULTS.json').read_text());surface=json.loads((source/'surface_baseline_v2/RESULTS.json').read_text())
        for name in ['baseline_v4/RESULTS.json','surface_baseline_v2/RESULTS.json']:
            path=source/name;bindings.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        for case in base['cases']:
            idx=case['index'];kv=mp.mpf(str(case['k']));Pval=mp.mpf('1.5')*mp.mpf(str(case['Phi_surface']));nv=mp.mpf(str(case['nu']));hv=mp.mpf(str(case['Hv_R_squared']));rec,samples=calculate(kv,Pval,nv,hv)
            eta=mp.mpf(str(surface['cases'][idx]['surface_eta']));oldenv=mp.mpf(str(surface['cases'][idx]['Mbar_R_squared']));best=min(oldenv,rec['Mc2']);lo=max(mp.mpf(0),kv*mp.exp(-rec['B'])-mp.mpf('.4')*kv*best/(1-(1+kv)*Pval));newlo=max(mp.mpf(0),kv*mp.exp(-rec['B'])-mp.mpf('.4')*kv*rec['Mc2']/(1-(1+kv)*Pval))
            ck('surface_new_bound_'+str(idx),eta>=newlo-mp.mpf('2e-8'))
            ck('surface_best_bound_'+str(idx),eta>=lo-mp.mpf('2e-8'))
            ck('new_envelope_samples_'+str(idx),all(HH<=rec['Mc2']*(1+mp.mpf('1e-50')) for uu,HH in samples))
            ck('new_convexity_samples_'+str(idx),not rec['new_criterion_met'] or all(HH>0 for uu,HH in samples))
            row={n:str(v) if not isinstance(v,bool) else v for n,v in rec.items()};row.update(index=idx,old_envelope=str(oldenv),eta=str(eta),lower_new=str(newlo),lower_best=str(lo),old_lower=surface['cases'][idx]['lower']);old_cases.append(row)
        ks=[mp.mpf(1)/3-mp.mpf(1)/10000,mp.mpf(1)/3-mp.mpf(1)/100000000,mp.mpf(1)/10000]
        for idx,(kv,Pval) in enumerate((kk,pp) for kk in ks for pp in [mp.mpf(3)/20000,mp.mpf(3)/200]):
            nv=mp.mpf(1)/10000;vac=4*(3+3*kv+nv)/(1-3*kv);hv=1/vac;rec,samples=calculate(kv,Pval,nv,hv)
            ck('prospective_envelope_'+str(idx),all(HH<=rec['Mc2']*(1+mp.mpf('1e-50')) for uu,HH in samples))
            ck('prospective_convexity_'+str(idx),not rec['new_criterion_met'] or all(HH>0 for uu,HH in samples))
            ck('prospective_inverse_'+str(idx),abs((1+((1+kv)/(kv*(1-3*kv))))*rec['EMin']/(1+((1+kv)/(kv*(1-3*kv)))*rec['EMin'])-rec['zMin2'])<mp.mpf('1e-70'))
            row={n:str(v) if not isinstance(v,bool) else v for n,v in rec.items()};row.update(index=idx,sampled_hessian_min=str(min(HH for uu,HH in samples)),sampled_hessian_max=str(max(HH for uu,HH in samples)),old_criterion_met=bool(rec['old_criterion_value']<=mp.log(2)));new_cases.append(row)
            (out/('prospective_samples_'+str(idx)+'.json')).write_text(json.dumps([dict(u=str(uu),Y_chichi=str(HH)) for uu,HH in samples],indent=2)+'\n')
    result=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,exposed_body_cases=old_cases,prospective_parameter_cases=new_cases,source_bindings=bindings,algebra_only=algebra_only,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional canonical envelope and sufficient convexity; original body18cases exposed, new6cases mathematical stress controls only, not new BVP solutions or empirical validation.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],exposed_cases=len(old_cases),prospective_cases=len(new_cases),old_failed_new_passed=sum(not x['old_criterion_met'] and x['new_criterion_met'] for x in new_cases),failed_checks=[x for x in rows if not x['passed']]),indent=2));return result['failed']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--algebra-only',action='store_true');args=p.parse_args();raise SystemExit(bool(run(args.source,args.out,args.algebra_only)))
