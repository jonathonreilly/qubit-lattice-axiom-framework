# Preserved reviewer execution failure

The first actual execution exited 1 after computing local values but before writing RESULTS.json. The endpoint tolerance field contained both its numeric value and explanatory prose. Passing the entire string to mpmath raised ValueError. No pass count or unrecorded intermediate calculation is claimed as completed evidence.

The exact executed v1 source, all actual input hashes and complete traceback remain unchanged. A separately versioned v2 source extracts the leading numeric token at the two parser sites. The frozen tolerance remains 1e-6, and all fixtures and mathematical expressions are unchanged. The failed first run justifies a new execution; it is not an unchanged successful replay.
