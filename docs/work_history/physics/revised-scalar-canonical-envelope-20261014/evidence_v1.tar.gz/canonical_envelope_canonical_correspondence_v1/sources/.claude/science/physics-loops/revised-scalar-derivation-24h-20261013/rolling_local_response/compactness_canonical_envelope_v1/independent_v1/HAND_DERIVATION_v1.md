# Independent canonical-envelope derivation

Only the two explicit new handwritten/protocol files and explicit prior source/proof dependencies were read. No new producer implementation, execution metadata, profile values or results were opened. Earlier seals, including their recorded limitations, remain immutable. Theory parameters and held Einstein-coordinate particle density are fixed during all derivatives.

## Exact coordinate conversion

Write alpha=sqrt(a), b=1-3a>0, E=exp(2alpha u), F=1+sE, J=1+bsE and K=J/F^2. Let y=z^2=A^2. The original action gives y=(1+s)E/F. Solving this equation yields

    E=y/[1+s(1-y)],
    dE/dy=(1+s)/[1+s(1-y)]^2>0.

With r=s/(1+s), t=sE/F=r y and h=1-t=1/F. On the negative branch y in (0,1], E in (0,1] and ell=-ln E>=0. The prior -ln A<=B therefore gives y>=exp(-2B), E>=EMin and ell<=ellMax. Both h and ell are largest at the same lower endpoint EMin. Thus hMax ellMax is the actual endpoint maximum of h ell on this bounding interval, not a product of maxima attained at incompatible states.

The canonical beta is alpha/sqrt(J), q=a/J and d=-beta_chi=abs(a b sE F/J^2)>0 for finite interior parameters and E>0. In particular, strict d positivity is available even though the upper-bound statement writes 0<=d<=L. The old caps q<=qMax and d<=L remain applicable throughout the reachable interval.

## Base Hessian

The relation 1-y=(1-E)/F converts the base potential including its constant into

    Ubase=3/2+(3/2)s(1-y)^2.

Since y_chi=2beta y,

    Ubase_chi=-6s beta y(1-y),
    Ubase_chichi=6s y[d(1-y)+2q(2y-1)].

This directly checks the sign of the canonical connection contribution. If 2y-1 is negative, its contribution is nonpositive and can be discarded when seeking an upper bound. If it is positive, y<=1, 2y-1<=1 and q<=qMax bound it by 2qMax. The remaining term satisfies y d(1-y)<=L Delta. Thus the base part of the proposed envelope is valid without a Hessian-positivity premise.

## Regulator Hessian

Let g=u/F=-ell h/(2alpha). Its canonical first derivative is (1+t ell)/sqrt(J). Differentiating the original u/F expression, rather than differentiating the claimed result, gives

    g_chichi=-2alpha t/(h J)(1-h ell)
              -alpha b t/(h^2 J^2)(1+t ell).

Consequently

    g_chi^2+g g_chichi
      =1/J[1+3t ell+(2t^2-t)ell^2]
        +b t ell/(2h J^2)(1+t ell).

Using q=a/J and d=a b t/(h^2 J^2) produces exactly the stated regulator Hessian

    nu(1+s)/a {q[1+3t ell+(2t^2-t)ell^2]
                +(d/2)h ell(1+t ell)}.

The connection term is included. The first bracket need not be nonnegative at arbitrary negative fields. For an upper bound, remove -t ell^2 before increasing q to qMax; the remaining bracket is positive. Using 0<t<1, 0<=ell<=ellMax, h<=hMax and d<=L then gives precisely the proposed regulator envelope. No reversed inequality results from a negative factor.

## Vacuum and reachable-interval consequences

At fixed interior parameters, P tends to zero with Delta and ellMax tending to zero and qMax tending to k because a-k=(1+k)(1-3k)/4>0. The envelope becomes

    12sk+nu(1+s)k/a=4[3(1+k)+nu]/(1-3k),

in units of Hv^2. This equals the raw-action canonical vacuum Hessian. The envelope has inverse-length-squared units after multiplication by Hv^2.

For each realized field value, the entire canonical segment from that value to zero also has A between its value and one. Therefore the upper Hessian bound can be integrated along that segment, exactly as required by the previously checked surface-force argument. Taking the minimum of two independently valid uniform envelopes is valid. It is not necessary, and not asserted here, that the new formula is smaller for every parameter/source choice. The reference mass, radial hypothesis, finite-radius limitation and held-density qualifications of the surface theorem remain unchanged.

## Improved sufficient convexity domain

If B<=ln2/2, then y>=1/2. The base Hessian is strictly positive: at y=1/2 the d(1-y) contribution is strictly positive; at y=1 the q term is strictly positive; between them at least one is positive. The strict endpoint argument uses d>0 for the actual action, not only its nonnegative abstract bound.

If hMax ellMax<=1, then 1-h ell>=0 everywhere in the interval. Both terms in g_chichi are nonpositive, and the second is strictly negative at finite interior parameters. With g<=0 and g_chi>0, the regulator Hessian is strictly positive. Hence Y_chichi>0 on a compact interval. The previous Kato and ground-state arguments apply without changing their boundary, LP<1 or fixed-source hypotheses. Existence is separately supplied by the old nu>0 coercivity proof.

The two new conditions are sufficient. A failure does not prove a negative total Hessian, multiplicity or instability. The second condition is specifically used to establish g concavity in this proof; it is not an exact classification of all convex regulator states. A mutation that drops that condition may therefore break this concavity witness without establishing physical instability.

## Parameter limits and order of limits

No excluded endpoint is admitted. At fixed P>0 with P<3/4, let delta=1-3k tend to zero. Then s is asymptotic to 4/delta, a tends to 1/3, and B tends to a finite positive B0. If y0=exp(-2B0) and Delta0=1-y0, then

    EMin is asymptotic to delta y0/(4Delta0),
    ellMax=ln(1/delta)+ln(4Delta0/y0)+o(1),
    hMax tends to Delta0>0.

Thus hMax ellMax diverges and the new convexity criterion eventually fails at fixed nonzero P. Scaling P with delta is a different limit. The fixed-k vacuum limit cannot be exchanged silently with this fixed-source endpoint limit.

The opposite endpoint also has a controlled but excluded limit. For k tending to zero at fixed 0<P<1, let f=P(1-P/2)/(1-P)^2 and ell0=-2ln(1-P). Then B/k tends to f, EMin tends to (1-P)^2, hMax/k and qMax/k both tend to (1-P)^-2. The regulator criterion hMax ellMax tends to zero. The dimensionless envelope has the finite limiting value

    12[f+(1-P)^-2]
      +4nu(1-P)^-2[1+(7/2)ell0+(5/2)ell0^2].

This is a limit of the formulas at interior k, not a definition of the original action at k=0. It also shows why the new sufficient conditions can pass while the old coordinate criterion tends to 2P/(1-P)>ln2. None of these flat-model observations certifies gravitational backreaction at a large physical compactness.

## Independent controls

The symbolic route applies the original u/E differentiation operator twice and compares with the new canonical formulas. Numerical controls use raw u-coordinate potential derivatives and independently differentiated ln A to calculate q and d; they do not import a producer function. Synthetic rational points include two near-endpoint regimes and both passing and failing sufficient criteria. Endpoint sequences test the explicitly derived limiting expressions, not observational data. Actual altered programs exercise conformal inversion, connection sign, regulator coefficient, coupling cap, vacuum normalization and the proof's concavity criterion.
