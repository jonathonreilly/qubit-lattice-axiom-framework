# Independent canonical-envelope review

The two canonical Hessian identities, the upper envelope, its vacuum normalization and the improved sufficient convexity criteria follow from the supplied action in the stated negative-branch, held-source domain. No correction to the frozen parent derivation was needed. The inherited force, uniqueness and scalar-stability arguments retain all their original boundary, radial, density and fixed-metric limitations.

The completed independent calculation records 2075 passing assertions and zero failures. A preceding reviewer execution failed before producing results because of a tolerance-parser error; its exact source and traceback are preserved. Six actual altered programs subsequently failed every intended witness. No current producer implementation, execution metadata, body profile or output was read.

## Source coverage and independence

The complete new `DERIVATION_v1.md`, SHA `f37ccfbb738bf0d0803eb3dd008cd9194f68a2a8d0fc256d0b3d655b727800ac`, and its complete protocol were frozen before checking. Only explicit filenames were used. The full original action and exact prior excursion, surface-v2 and uniqueness-v2 sources were reused with the completed independent reports, handwritten proofs, manifests and receipts. All 18 original/snapshot bindings are enumerated in `SOURCE_DISPOSITIONS_v1.json`.

The three older seals remain unchanged. Their calculations were not replayed or counted as new evidence. The prior uniqueness review's accidental aggregate exposure remains disclosed in that immutable dependency; no corresponding exposure occurred for this new block. The new review did not read the producer's 18 existing profiles or any later implementation. Its parameter points differ from the new cases listed in the parent protocol.

## Exact formulas and inequality directions

Solving the action's conformal relation gives `E=y/[1+s(1-y)]` with y=A squared and a strictly positive derivative with respect to y. The endpoint values of both `h=1/(1+sE)` and `ell=-ln E` occur at the same minimum E. The bound on their product therefore has no hidden incompatible-extrema assumption.

Differentiating the base potential directly in y, using `y_chi=2 beta y`, gives the stated `6s y[d(1-y)+2q(2y-1)]`. An independent u-coordinate differentiation gives the same expression, including the positive d connection contribution. The upper bound treats a negative `2y-1` contribution separately before replacing q by its upper cap.

For the regulator, independently differentiating `g=u/F` first produces `g_chi=(1+t ell)/sqrt(J)` and then the two terms in g_chichi. Combining its square and g times its second derivative gives exactly the displayed coefficient `1+3t ell+(2t^2-t)ell^2` and the d term. Dropping the negative `-t ell^2` term before enlarging q is essential. All remaining factors are nonnegative and have the stated bounds. The resulting Mc squared is an upper Hessian envelope, not a positivity assertion or an assigned effective mass.

The inherited q cap is consistent over the conformally bounded interval. Independently, `dq/d(-ln A)=2d<=2L`, so `q<=k+2LB=k/(1-LP)^2`; the exact global ceiling a supplies the other branch of the minimum. This also validates using the new conformal interval in the numerical controls.

At fixed interior parameters and P tending to zero, qMax tends to k, Delta and ellMax tend to zero, and the envelope becomes

    Mc^2/Hv^2 = 12sk+nu(1+s)k/a
               =4[3(1+k)+nu]/(1-3k).

This agrees with independent raw-action differentiation at the vacuum. Mc squared has inverse-length-squared units once Hv squared is restored. The finite-P field segment from any allowed state to the vacuum stays inside the same conformal interval, so integrating the upper Hessian reproduces the earlier surface-force reasoning. Taking the minimum of two independently valid envelopes is legitimate. No theorem that the new expression is smaller at every parameter point is required or claimed.

## Convexity, strict endpoints and inherited conclusions

The base Hessian is strictly positive when y>=1/2. At y=1/2 this uses the actual action's strict d>0 for finite interior parameters; the abstract nonnegative bound alone would not establish strictness. At y=1 the positive q term remains. No excluded endpoint where the relevant coefficient degenerates is silently admitted.

The second condition, hMax ellMax<=1, makes the first term in g_chichi nonpositive; its second term is negative. Since g<=0 and g_chi>0, the regulator Hessian is strictly positive. The compact reachable interval therefore has a positive canonical Hessian minimum at fixed parameters. The previous Kato contraction and ground-state form argument then apply with their existing LP<1 and zero-boundary assumptions. The original nu>0 existence proof is reused; it is not inferred merely from local convexity.

Failure of either new condition is uninformative about physical instability or multiplicity. The regulator condition is a sufficient route to g concavity, not a complete classification of regulator or total-potential convexity. This distinction is exercised explicitly by the damaged eligibility program and retained in all result interpretations.

The force normalization remains a chosen bare-gravity reference using held particle mass and Einstein radius. Surface conclusions require a radial solution, supplied by the uniqueness result only within its sufficient domain. They are not force lower bounds at arbitrary distant apparatus. Linear scalar positivity keeps density and the flat metric fixed; it does not imply damping, environmental selection, free-matter/metric stability or a full relativistic solution.

## Endpoint and order-of-limits check

For fixed nonzero P<3/4 and delta=1-3k tending to zero, s is asymptotic to 4/delta, B tends to B0>0, and with y0=exp(-2B0),

    EMin ~ delta y0/[4(1-y0)],
    ellMax = ln(1/delta)+ln[4(1-y0)/y0]+o(1),
    hMax ->1-y0>0.

Thus the regulator-condition product diverges. A source compactness scaled with delta is a different limit, and the fixed-k vacuum limit cannot be exchanged with this fixed-source endpoint limit.

The opposite excluded endpoint has a different behavior. At k tending to zero with fixed 0<P<1, EMin tends to `(1-P)^2`, hMax/k and qMax/k tend to `(1-P)^-2`, and hMax ellMax tends to zero. The full finite envelope limit is derived in `HAND_DERIVATION_v1.md` and tested numerically. This is a limit of interior formulas, not an admission of k=0 into the original parameterization. It is not uniform as LP approaches one, and it does not certify neglect of gravitational backreaction at large physical compactness.

## Independent execution and actual failures

The program compares exact symbolic canonical identities with direct action differentiation. Numerical controls independently differentiate the original u-coordinate potential and ln A at 80 digits. There are 24 synthetic parameter cases, 216 field points and three paired endpoint-sequence rows. The 2075 assertions include source binding, exact identities, numerical bounds, criterion-controlled signs and endpoint controls; finite sampling supplements rather than proves the analytic interval inequalities.

In these selected cases, 20 satisfy the new sufficient criteria and 12 satisfy the old criterion; eight pass only the new criteria. Four fail the new regulator condition while their sampled total Hessians remain positive. These are not instability detections. Both envelope expressions are retained for every case. The new expression is smaller in these 24 cases, without extrapolating that observed ordering to a universal theorem or interpreting it as a fit.

The first executed reviewer source failed with ValueError after local computations but before writing a result file: a numeric tolerance field also contained explanatory text. No unrecorded intermediate values or pass count are claimed as completed evidence. The unchanged v1 source, 21 actual input hashes and traceback remain preserved. A separately versioned v2 changes only two parser sites to extract the leading token `1e-6`; no fixture, mathematics or tolerance changed. Its actual execution completed 2075/0, exit 0, empty stderr and unchanged inputs.

Six actual alterations of that preserved v2 program were executed with fresh identities of all 21 actual inputs. Each exited 1 and failed its intended mathematical witness:

| Alteration | Passed / failed |
| --- | ---: |
| Incorrect conformal inverse | 50 / 18 |
| Reverse base connection sign | 62 / 6 |
| Change regulator linear coefficient | 63 / 5 |
| Replace qMax by k | 63 / 5 |
| Omit regulator envelope | 63 / 5 |
| Omit the g-concavity condition | 76 / 1 |

The last alteration changes the number of conditional checks. Its failed g-concavity witness identifies the missing premise in that proof; it does not establish a negative total Hessian or an unstable body. All actual altered bytes, diffs, input freezes, result rows and streams are retained. Hash mismatches are not used as mathematical detection.

## Recovery and seal

`EXECUTION_FAILURE_v1.md` and `FAILURES_v1.md` preserve the real parser failure, correction history and intended damage failures. `COMMAND_INDEX_v1.json` records actual argv for the failed, corrected and altered executions. `REUSE_VERIFICATION_v1.json` checks all three prior manifests and receipts without repeating their science. `MANIFEST_v1.json` and `RECEIPT_v1.json` bind the full new package. Subsequent amendments must be separately versioned; no old or new sealed artifact is to be silently changed.

This is a focused independent mathematical check of a supplied construction, not a formal audit, empirical validation, source selection or status promotion. The parent remains scientific author.
