"""Independent canonical formulas, bound domains and endpoint controls."""
from pathlib import Path
import argparse
import hashlib
import json
import mpmath as mp
import sympy as sp

mp.mp.dps=80
checks=[]
def encode(x):return mp.nstr(x,70) if isinstance(x,mp.mpf) else str(x)
def ck(name,passed,**detail):checks.append({"name":name,"passed":bool(passed),"detail":{k:encode(v) for k,v in detail.items()}})
def close(x,y):return abs(x-y)<=mp.mpf("1e-45")*max(1,abs(x),abs(y))
def le(x,y):return x<=y or close(x,y)
def num(x):
    q=sp.Rational(x);return mp.mpf(int(q.p))/int(q.q)
def pars(k):return (1-k)*(1+3*k)/4,(1+k)/(k*(1-3*k))
def inverse_claim(y,s):return y/(1+s*(1-y))
def base_claim(s,y,q,d):return 6*s*y*(d*(1-y)+2*q*(2*y-1))
def reg_claim(nu,s,a,q,d,t,ell):return nu*(1+s)/a*(q*(1+3*t*ell+(2*t*t-t)*ell*ell)+d/2*(1-t)*ell*(1+t*ell))
def q_cap(k,a,LP):return min(a,k/(1-LP)**2)
def envelope_claim(k,nu,P):
    a,s=pars(k);L=1+k;LP=L*P;B=k*P*(1-LP/2)/(1-LP)**2;ymin=mp.exp(-2*B);Delta=-mp.expm1(-2*B)
    Emin=inverse_claim(ymin,s);ell=-mp.log(Emin);hmax=(1+s*Delta)/(1+s);qmax=q_cap(k,a,LP)
    base=6*s*(L*Delta+2*qmax)
    regulator=nu*(1+s)/a*(qmax*(1+3*ell+2*ell*ell)+L/2*hmax*ell*(1+ell))
    return base+regulator,{"a":a,"s":s,"L":L,"LP":LP,"B":B,"ymin":ymin,"Delta":Delta,"Emin":Emin,"ellmax":ell,"hmax":hmax,"qmax":qmax}
def eligible(B,hmax,ellmax):return le(B,mp.log(2)/2) and le(hmax*ellmax,1)
def action(k,nu,u):
    a,s=pars(k);E=mp.exp(2*mp.sqrt(a)*u);F=1+s*E;J=1+(1-3*a)*s*E
    return mp.mpf(3)/2+3*s*(E-1)**2/(2*F*F),nu*(1+s)*u*u/(2*F*F),J/(F*F),mp.sqrt((1+s)*E/F)
def old_envelope(k,nu,P):
    a,s=pars(k);K0=action(k,nu,mp.mpf(0))[2];L=1+k;W=mp.sqrt(k)*P/(1-L*P);umax=W/mp.sqrt(K0);Fmin=1+s*mp.exp(-2*mp.sqrt(a)*umax)
    value=(12*a*s*(1+s)**2/Fmin**4+nu*(1+s)*(1/Fmin**2+8*mp.sqrt(a)*s*umax/Fmin**3+12*a*s*s*umax*umax/Fmin**4))/K0
    return value,2*mp.sqrt(a)*umax

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--inputs",required=True);ap.add_argument("--output",required=True);ap.add_argument("--witness-only",action="store_true");args=ap.parse_args()
    path=Path(args.inputs);p=json.loads((path/"INDEPENDENT_PROTOCOL_v1.json").read_text())
    protocol=json.loads((path/"sources/PROTOCOL_v1.json").read_text())
    ck("source_protocol_binding",protocol["hand_sha256"]==hashlib.sha256((path/"sources/DERIVATION_v1.md").read_bytes()).hexdigest())
    E,s,alpha,nu,y=sp.symbols("E s alpha nu y",positive=True);u=sp.symbols("u",real=True)
    a=alpha*alpha;b=1-3*a;F=1+s*E;J=1+b*s*E;K=J/F**2;C=(1+s)*E/F
    D=lambda v:sp.diff(v,u)+2*alpha*E*sp.diff(v,E)
    Dchi=lambda v:D(v)/sp.sqrt(K)
    qi=a/J;di=a*b*s*E*F/J**2;tt=s*E/F;ell=-2*alpha*u
    rawbase=sp.Rational(3,2)+3*s*(E-1)**2/(2*F*F);rawreg=nu*(1+s)*u*u/(2*F*F)
    ck("inverse_identity",sp.factor(C.subs(E,inverse_claim(y,s))-y)==0)
    ck("inverse_monotonic_derivative",sp.factor(sp.diff(inverse_claim(y,s),y)-(1+s)/(1+s*(1-y))**2)==0)
    ck("base_potential_identity",sp.factor(rawbase-sp.Rational(3,2)-sp.Rational(3,2)*s*(1-C)**2)==0)
    ck("base_hessian_exact",sp.factor(Dchi(Dchi(rawbase))-base_claim(s,C,qi,di))==0)
    ck("regulator_hessian_exact",sp.factor(Dchi(Dchi(rawreg))-reg_claim(nu,s,a,qi,di,tt,ell))==0)
    ck("t_conformal_identity",sp.factor(tt-s/(1+s)*C)==0)
    ck("h_endpoint_identity",sp.factor(1/(1+s*inverse_claim(y,s))-(1-s*y/(1+s)))==0)
    kk,PP=sp.symbols("k P",positive=True);LL=1+kk;BB=kk*PP*(1-LL*PP/2)/(1-LL*PP)**2
    ck("q_bound_from_conformal",sp.factor(kk+2*LL*BB-kk/(1-LL*PP)**2)==0)
    dd,qq=sp.symbols("d q",positive=True)
    ck("base_half_endpoint_strict",base_claim(s,sp.Rational(1,2),qq,dd)==sp.Rational(3,2)*s*dd)
    ar,sr=pars(kk)
    ck("vacuum_cap_branch",sp.factor(ar-kk-(1+kk)*(1-3*kk)/4)==0)
    ck("vacuum_mass_exact",sp.factor(12*sr*kk+nu*(1+sr)*kk/ar-4*(3*(1+kk)+nu)/(1-3*kk))==0)

    ks=[p["k"][0],p["k"][3]] if args.witness_only else p["k"]
    ps=[p["P"][2]] if args.witness_only else p["P"]
    ns=p["nu"][:1] if args.witness_only else p["nu"]
    fractions=[mp.mpf(0),mp.mpf(".5"),mp.mpf(1)] if args.witness_only else [mp.mpf(j)/8 for j in range(9)]
    cases=[];rows=[]
    for kval in ks:
        k=num(kval);a,s0=pars(k)
        for nval in ns:
            n=num(nval);vac,vg=envelope_claim(k,n,mp.mpf(0));K0=action(k,n,mp.mpf(0))[2]
            rawvac=(mp.diff(lambda u:action(k,n,u)[0],mp.mpf(0),2)+mp.diff(lambda u:action(k,n,u)[1],mp.mpf(0),2))/K0
            ck("envelope_vacuum_limit",close(vac,rawvac),k=kval,nu=nval,claimed=vac,raw=rawvac)
            for pval in ps:
                P=num(pval);M,g=envelope_claim(k,n,P);Mold,oldtest=old_envelope(k,n,P);good=eligible(g["B"],g["hmax"],g["ellmax"])
                min_h=mp.inf;max_h=-mp.inf;max_gsecond=-mp.inf
                for fval in fractions:
                    ellv=fval*g["ellmax"];uv=-ellv/(2*mp.sqrt(a));Ev=mp.exp(-ellv);Fv=1+s0*Ev
                    bval,rval,Kv,Av=action(k,n,uv);yv=Av*Av
                    beta=lambda v:mp.diff(lambda w:mp.log(action(k,n,w)[3]),v)/mp.sqrt(action(k,n,v)[2])
                    qv=beta(uv)**2;dv=-mp.diff(beta,uv)/mp.sqrt(Kv);tv=s0*Ev/Fv;hv=1/Fv
                    Hraw=lambda index:mp.diff(lambda v:mp.diff(lambda w:action(k,n,w)[index],v)/mp.sqrt(action(k,n,v)[2]),uv)/mp.sqrt(Kv)
                    Hb=Hraw(0);Hr=Hraw(1);H=Hb+Hr
                    gsecond=mp.diff(lambda v:mp.diff(lambda w:w/(1+s0*mp.exp(2*mp.sqrt(a)*w)),v)/mp.sqrt(action(k,n,v)[2]),uv)/mp.sqrt(Kv)
                    ck("numeric_inverse",close(inverse_claim(yv,s0),Ev),k=kval,nu=nval,P=pval,fraction=fval)
                    ck("base_hessian_raw_action",close(Hb,base_claim(s0,yv,qv,dv)),k=kval,nu=nval,P=pval,fraction=fval)
                    ck("regulator_hessian_raw_action",close(Hr,reg_claim(n,s0,a,qv,dv,tv,ellv)),k=kval,nu=nval,P=pval,fraction=fval)
                    ck("reachable_q_cap",le(qv,g["qmax"]),k=kval,nu=nval,P=pval,fraction=fval,q=qv,qmax=g["qmax"])
                    ck("reachable_d_bound",le(0,dv) and le(dv,g["L"]),k=kval,nu=nval,P=pval,fraction=fval)
                    ck("h_ell_endpoint_bound",le(hv*ellv,g["hmax"]*g["ellmax"]),k=kval,nu=nval,P=pval,fraction=fval)
                    ck("canonical_envelope_bound",le(H,M),k=kval,nu=nval,P=pval,fraction=fval,H=H,envelope=M)
                    if good:
                        ck("eligible_base_convexity",Hb>0,k=kval,nu=nval,P=pval,fraction=fval)
                        ck("eligible_regulator_convexity",Hr>0,k=kval,nu=nval,P=pval,fraction=fval)
                        ck("eligible_g_concavity",le(gsecond,0),k=kval,nu=nval,P=pval,fraction=fval,gsecond=gsecond)
                    min_h=min(min_h,H);max_h=max(max_h,H);max_gsecond=max(max_gsecond,gsecond)
                    rows.append({"k":kval,"nu":nval,"P":pval,"fraction":encode(fval),"u":encode(uv),"E":encode(Ev),"A2":encode(yv),"q":encode(qv),"d":encode(dv),"base_Hessian":encode(Hb),"regulator_Hessian":encode(Hr),"g_second":encode(gsecond),"Mc2_over_Hv2":encode(M),"eligible":good})
                cases.append({"k":kval,"nu":nval,"P":pval,**{key:encode(value) for key,value in g.items()},"Mc2_over_Hv2":encode(M),"old_Mbar2_over_Hv2":encode(Mold),"new_over_old":encode(M/Mold),"new_criteria_pass":good,"old_criterion_value":encode(oldtest),"old_criterion_pass":le(oldtest,mp.log(2)),"sampled_min_Hessian":encode(min_h),"sampled_max_Hessian":encode(max_h),"sampled_max_g_second":encode(max_gsecond)})

    endpoint_rows=[];P=num(p["endpoint_P"]);n=num(p["endpoint_nu"]);ell0=-2*mp.log(1-P);ff=P*(1-P/2)/(1-P)**2
    low_limit=12*(ff+1/(1-P)**2)+4*n/(1-P)**2*(1+mp.mpf(7)/2*ell0+mp.mpf(5)/2*ell0*ell0)
    B0=mp.mpf(1)/3*P*(1-mp.mpf(2)/3*P)/(1-mp.mpf(4)/3*P)**2;y0=mp.exp(-2*B0);Delta0=-mp.expm1(-2*B0)
    low_errors=[];high_errors=[];products=[]
    for ev in p["endpoint_sequence"]:
        e=num(ev);Ml,gl=envelope_claim(e,n,P);Mh,gh=envelope_claim((1-e)/3,n,P)
        lratios=[gl["Emin"]/(1-P)**2,gl["hmax"]/e*(1-P)**2,Ml/low_limit]
        hratios=[gh["Emin"]*4*Delta0/(e*y0),gh["hmax"]/Delta0]
        low_errors.append(max(abs(x-1) for x in lratios));high_errors.append(max(abs(x-1) for x in hratios));products.append(gh["hmax"]*gh["ellmax"])
        endpoint_rows.append({"epsilon":ev,"low_k":encode(e),"low_ratios":[encode(x) for x in lratios],"low_error":encode(low_errors[-1]),"high_k":encode((1-e)/3),"high_ratios":[encode(x) for x in hratios],"high_error":encode(high_errors[-1]),"high_h_ell":encode(products[-1]),"low_Mc_limit":encode(low_limit)})
    ck("low_endpoint_finite_limit",all(low_errors[i+1]<low_errors[i] for i in range(len(low_errors)-1)) and low_errors[-1]<mp.mpf(p["endpoint_final_relative_tolerance"].split(" ",1)[0]),last_error=low_errors[-1])
    ck("high_endpoint_leading_scale",all(high_errors[i+1]<high_errors[i] for i in range(len(high_errors)-1)) and high_errors[-1]<mp.mpf(p["endpoint_final_relative_tolerance"].split(" ",1)[0]),last_error=high_errors[-1])
    ck("high_endpoint_criterion_fails",all(products[i+1]>products[i] for i in range(len(products)-1)) and products[-1]>1,last_product=products[-1])
    result={"scope":"Independent source/action and synthetic canonical-envelope controls; no producer implementation or outputs read.","source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"precision":mp.mp.dps,"witness_only":args.witness_only,"passed":sum(x["passed"] for x in checks),"failed":sum(not x["passed"] for x in checks),"checks":checks,"cases":cases,"point_rows":rows,"endpoint_rows":endpoint_rows,"failed_criteria_are_not_instability":True}
    Path(args.output).write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"passed":result["passed"],"failed":result["failed"],"cases":len(cases),"points":len(rows),"endpoints":len(endpoint_rows)}))
    raise SystemExit(1 if result["failed"] else 0)

if __name__=="__main__":main()
