"""Actual single-change programs based on the preserved parser-corrected source."""
from pathlib import Path
import difflib
import hashlib
import json
from execute_v1 import execute

P=Path(__file__).resolve().parent;source=(P/"check_independent_v2.py").read_text()
changes=[
    ("conformal_inverse","def inverse_claim(y,s):return y/(1+s*(1-y))","def inverse_claim(y,s):return y/(1+s)","inverse_identity"),
    ("base_connection_sign","return 6*s*y*(d*(1-y)+2*q*(2*y-1))","return 6*s*y*(-d*(1-y)+2*q*(2*y-1))","base_hessian_exact"),
    ("regulator_linear_coefficient","q*(1+3*t*ell+(2*t*t-t)*ell*ell)","q*(1+2*t*ell+(2*t*t-t)*ell*ell)","regulator_hessian_exact"),
    ("undersized_q_cap","def q_cap(k,a,LP):return min(a,k/(1-LP)**2)","def q_cap(k,a,LP):return k","reachable_q_cap"),
    ("omit_regulator_envelope","return base+regulator,{","return base,{","envelope_vacuum_limit"),
    ("omit_concavity_condition","return le(B,mp.log(2)/2) and le(hmax*ellmax,1)","return le(B,mp.log(2)/2)","eligible_g_concavity"),
]
out=P/"damages_v1";out.mkdir(exist_ok=False);summary=[]
for name,before,after,target in changes:
    assert source.count(before)==1
    changed=source.replace(before,after);file=out/(name+".py");file.write_text(changed)
    (out/(name+".diff")).write_text("".join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile="check_independent_v2.py",tofile=name+".py")))
    execution=execute(file,out/name,witness=True);result=json.loads((out/name/"RESULTS.json").read_text())
    failures=[x["name"] for x in result["checks"] if not x["passed"]]
    summary.append({"name":name,"before":before,"after":after,"source_sha256":hashlib.sha256(file.read_bytes()).hexdigest(),"required_witness":target,"required_witness_failed":target in failures,"passed":result["passed"],"failed":result["failed"],"exit_code":execution["exit_code"],"inputs_unchanged":execution["inputs_unchanged"],"all_failed_rows":failures,"scope":"Actual predetermined witness subset; altered eligibility may change the number of conditional checks. Concavity-witness failure is not an instability claim."})
(out/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary))
raise SystemExit(0 if all(x["required_witness_failed"] and x["exit_code"]==1 and x["inputs_unchanged"] for x in summary) else 1)
