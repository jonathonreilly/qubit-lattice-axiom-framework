"""Identity-only seal; preserves the real failed first execution."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import platform
import sys

P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def write(name,obj):
    dest=P/name;assert not dest.exists(),f"Refuse overwrite {dest}"
    dest.write_text(json.dumps(obj,indent=2)+"\n")

assert not (P/"MANIFEST_v1.json").exists() and not (P/"RECEIPT_v1.json").exists()
rows=read("FREEZE_v1.json")["sources"]+read("FREEZE_v2.json")["added_sources"]
dispositions=[]
for row in rows:
    original=Path(row["original_path"]);snapshot=P/row["snapshot_path"]
    assert sha(original)==sha(snapshot)==row["sha256"] and original.read_bytes()==snapshot.read_bytes()
    dispositions.append({"original_path":str(original),"original_sha256":row["sha256"],"disposition":"Explicit fully read new source or exactly reused action/proof/evidence dependency; preserved unchanged.","recovery":str(snapshot),"recovery_sha256":sha(snapshot),"final_path":str(original),"final_sha256":sha(original)})
assert len(dispositions)==18
old=P.parent.parent/"finite_body_excursion_v1";reused=[]
for folder,receipt,count in [("independent_v1","f31cb02003bebee1251a963fdb4b76151c841dd7a023cc4604db5803cb33cb43",72),("independent_surface_v1","2944bb5aeb74440ba1e5954e2e2f4af4275c0c287d94c76f62f57d3812cd0b71",77),("independent_uniqueness_v1","aec6987f5aee830451a4118e0b874a3e7f03ef9847a2e8e6bbd9f06350f029c8",94)]:
    directory=old/folder;m=json.loads((directory/"MANIFEST_v1.json").read_text());r=json.loads((directory/"RECEIPT_v1.json").read_text())
    assert sha(directory/"RECEIPT_v1.json")==receipt and len(m["artifacts"])==count
    for x in m["artifacts"]:assert sha(directory/x["path"])==x["sha256"]
    for x in r["bindings"]:assert sha(directory/x["path"])==x["sha256"]
    reused.append({"directory":str(directory),"receipt_sha256":receipt,"manifest_sha256":sha(directory/"MANIFEST_v1.json"),"verified_artifacts":count,"science_reexecuted":False,"artifacts":m["artifacts"]})

v1=(P/"check_independent_v1.py").read_text();v2=(P/"check_independent_v2.py").read_text()
before='mp.mpf(p["endpoint_final_relative_tolerance"])';after='mp.mpf(p["endpoint_final_relative_tolerance"].split(" ",1)[0])'
assert v1.count(before)==2 and v1.replace(before,after)==v2
correction=read("PARSER_CORRECTION_v2.json")
assert correction["original_source_sha256"]==sha(P/"check_independent_v1.py") and correction["new_source_sha256"]==sha(P/"check_independent_v2.py")
assert correction["fixtures_or_tolerance_changed"] is False
assert (P/"PARSER_CORRECTION_v2.diff").read_text()=="".join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile="check_independent_v1.py",tofile="check_independent_v2.py"))
failed=read("baseline_v1/EXECUTION.json")
assert failed["exit_code"]==1 and failed["inputs_unchanged"] and not (P/"baseline_v1/RESULTS.json").exists()
assert "ValueError" in (P/"baseline_v1/stderr.txt").read_text()
baseline=read("baseline_v2/RESULTS.json")
assert (baseline["passed"],baseline["failed"])==(2075,0)
assert len(baseline["cases"])==24 and len(baseline["point_rows"])==216 and len(baseline["endpoint_rows"])==3
assert sum(x["new_criteria_pass"] for x in baseline["cases"])==20
assert sum(x["old_criterion_pass"] for x in baseline["cases"])==12
assert sum(x["new_criteria_pass"] and not x["old_criterion_pass"] for x in baseline["cases"])==8
damages=read("damages_v1/SUMMARY.json");expected=[(50,18),(62,6),(63,5),(63,5),(63,5),(76,1)]
commands=[]
run_names=["baseline_v1","baseline_v2"]+["damages_v1/"+d["name"] for d in damages]
for index,name in enumerate(run_names):
    e=read(name+"/EXECUTION.json");f=read(name+"/FREEZE.json")
    assert len(f["actual_inputs"])==21 and e["inputs_unchanged"]
    for x in f["actual_inputs"]:assert sha(Path(x["path"]))==x["sha256"]
    if index:
        result=read(name+"/RESULTS.json")
        assert e["source_sha256"]==result["source_sha256"]
        assert sum(x["passed"] for x in result["checks"])==result["passed"] and sum(not x["passed"] for x in result["checks"])==result["failed"]
        if index==1:assert e["exit_code"]==0
        else:
            d=damages[index-2];assert (result["passed"],result["failed"])==expected[index-2] and e["exit_code"]==1 and d["required_witness_failed"]
            assert any(x["name"]==d["required_witness"] and not x["passed"] for x in result["checks"])
            assert sha(P/("damages_v1/"+d["name"]+".py"))==d["source_sha256"]
    commands.append({"record":name+"/EXECUTION.json",**e})

write("SOURCE_DISPOSITIONS_v1.json",{"original_dispositions":dispositions})
write("REUSE_VERIFICATION_v1.json",{"prior_seals":reused,"total_verified_prior_artifacts":243,"prior_science_reexecuted":False})
write("COMMAND_INDEX_v1.json",{"executions":commands,"outer_failed_entrypoint":"python3 -B execute_v1.py","corrected_entrypoint":"python3 -B: import execute from execute_v1; execute(check_independent_v2.py, baseline_v2)","outer_damage_entrypoint":"python3 -B damage_controls_v1.py","seal_argv":[sys.executable,"-B",str(Path(__file__).resolve())],"source_read_policy":"Explicit source/protocol and prior prerequisite filenames only."})
write("ENVIRONMENT_v1.json",{"python":sys.version,"platform":platform.platform(),"precision":baseline["precision"],"producer_implementation_or_outputs_read":False})
artifacts=[]
for file in sorted(P.rglob("*")):
    if file.is_file():
        assert not file.is_symlink()
        artifacts.append({"path":str(file.relative_to(P)),"bytes":file.stat().st_size,"sha256":sha(file)})
write("MANIFEST_v1.json",{"schema":"closed-artifacts-v1","excludes":["MANIFEST_v1.json","RECEIPT_v1.json"],"artifacts":artifacts})
bound=["REPORT_v1.md","MANIFEST_v1.json","SOURCE_DISPOSITIONS_v1.json","HAND_DERIVATION_v1.md","INDEPENDENT_PROTOCOL_v1.json","EXECUTION_FAILURE_v1.md","FAILURES_v1.md","PARSER_CORRECTION_v2.json","REUSE_VERIFICATION_v1.json","COMMAND_INDEX_v1.json","baseline_v1/EXECUTION.json","baseline_v1/stderr.txt","baseline_v2/RESULTS.json","baseline_v2/EXECUTION.json","damages_v1/SUMMARY.json"]
write("RECEIPT_v1.json",{"sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Independent canonical-envelope source/action proof and synthetic controls; no producer implementation, execution metadata, profiles or outputs.","artifact_count":len(artifacts),"source_pair_count":len(dispositions),"completed_checks":{"passed":2075,"failed":0},"failed_preceding_execution":{"exit_code":1,"results_written":False,"reason":"Reviewer tolerance parser ValueError; exact original preserved."},"actual_damaged_programs":6,"all_intended_damage_witnesses_failed":True,"original_dispositions":"SOURCE_DISPOSITIONS_v1.json","bindings":[{"path":name,"sha256":sha(P/name)} for name in bound],"immutable_policy":"No edits after seal; any amendment separately versioned with these bytes preserved."})
for name in ["REPORT_v1.md","MANIFEST_v1.json","RECEIPT_v1.json","SOURCE_DISPOSITIONS_v1.json"]:print(name,sha(P/name))
print("artifacts",len(artifacts),"source_pairs",len(dispositions))
