import re
CLAIM_TYPE_LINE_RE = re.compile('^\\s*(?:\\*\\*Claim type:?\\*\\*|Claim type:)\\s*(.+)$', re.IGNORECASE | re.MULTILINE)
TYPE_LINE_RE = re.compile('^\\s*(?:\\*\\*Type:?\\*\\*|Type:)\\s*(.+)$', re.IGNORECASE | re.MULTILINE)
CLAIM_TYPES = {'positive_theorem', 'bounded_theorem', 'no_go', 'open_gate', 'decoration', 'meta'}

def normalize_claim_type(raw: str | None) -> str | None:
    if not raw:
        return None
    token = raw.strip().split()[0].strip('`*_:.').lower()
    token = token.replace('-', '_')
    if token == 'nogo':
        token = 'no_go'
    if token in CLAIM_TYPES:
        return token
    phrase = raw.strip().lower().replace('-', ' ').replace('_', ' ')
    phrase = ' '.join(phrase.split())
    aliases = {'positive theorem': 'positive_theorem', 'bounded theorem': 'bounded_theorem', 'no go': 'no_go', 'open gate': 'open_gate'}
    return aliases.get(phrase)

def extract_claim_type_hint(body: str) -> tuple[str | None, str | None]:
    m = CLAIM_TYPE_LINE_RE.search(body) or TYPE_LINE_RE.search(body)
    if not m:
        return (None, None)
    raw = m.group(1).strip()
    return (raw, normalize_claim_type(raw))
