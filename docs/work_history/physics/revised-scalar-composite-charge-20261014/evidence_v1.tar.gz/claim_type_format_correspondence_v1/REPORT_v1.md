# Four-note claim-type format correspondence

The four parent corrections are exactly one ASCII-space-to-newline
substitution each. All remaining note bytes, including the full scientific
bodies and the literal declared class, are unchanged. The actual live
extractor returns no type for each old note and bounded_theorem for each
new note. All four scientific runner identities match their earlier bound
versions. No scientific program was run or changed.

The result is **58/0 format/source checks plus 4/0 runner identity checks**.
This is publication-format correspondence, not a proof review, an audit,
retained-status promotion or an empirical conclusion. Previous stage and
delivery seals remain immutable. Milestone 20's refreshed cache/README and
amended commit require the separately requested delivery confirmation.

| Milestone | Source | Changed byte offset | Old/new extraction |
|---|---|---:|---|
| 20 | Canonical envelope | 92 | absent → bounded_theorem |
| 21 | Composite charge | 84 | absent → bounded_theorem |
| 22 | Calibrated gravity turning | 83 | absent → bounded_theorem |
| 23 | Paired gravity certificate | 83 | absent → bounded_theorem |

Offsets are zero-based. In each case the replaced byte follows the Status
sentence and immediately precedes Claim type. Byte lengths are identical.
Each exact supplied unified diff was reconstructed from its old/new bytes,
and the separate formatted_v2 install copy equals the new snapshot. Only
milestone 20 is installed live at this point; the other three original
staged notes remain unchanged and their corrected install copies are separate.

The mechanism is confirmed against the current
docs/audit/scripts/build_citation_graph.py. Its CLAIM_TYPE_LINE_RE is
line-anchored; the old Claim type declaration shares the Status line.
check_format_v1.py compiles the exact current extractor and normalization
function AST together with their three actual constants. It does not
reimplement a substitute regex or execute the graph main. The function
returns (None,None) for the original notes and
('bounded_theorem.','bounded_theorem') for the corrected notes. The full
current extractor source and exact selected AST are preserved. No graph,
ledger, runtime or authority file is written by these calls.

The preserved original UNIT stdout records mechanical_status invalid and
the exact Type extractor mismatch for milestone 20. Its command record,
input unit and empty stderr are copied by exact identity. This actual
failure is not rewritten as a successful earlier validation. The correction
does not change the intended declaration; it makes that existing declaration
discoverable by the current parser.

Runner identity checks use the original milestone 20 delivery mapping bound
by its receipt, the sealed milestone 21 correspondence receipt, milestone 22
lineages v1/v2 and milestone 23 lineage v1. All four current hashes equal
those earlier bindings. Milestone 22's prior coordinate-scope prose repair is
already part of its old baseline for this comparison; this format-only check
does not conflate or re-review that separate correction. The current review
does not newly certify the scientific content of milestones 20, 22 or 23.

Exact scripts, commands, streams, results, source copies and all identities
are retained. An initial source lookup included a nonexistent tools directory
and returned exit 2 with a truncated tool display; that lookup failure and
the two subsequent no-match searches are recorded explicitly. The exact
extractor was then located from an existing caller's import path. The lookup
did not execute or modify scientific code. No full raw output was captured
for the initial truncated search, and none is invented.

SOURCE_DISPOSITIONS_v1.json identifies the four superseded note versions,
their exact recovery paths and the correct final install/live paths. All
other input copies are bound in SOURCE_BINDINGS_v1.json. The manifest and
receipt form a closed, acyclic seal. No source outside this review directory
was modified.
