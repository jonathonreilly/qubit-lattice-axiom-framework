from pathlib import Path
import ast, copy, difflib, hashlib, json, re
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
PK = OUT.parent
ROOT = PK.parents[3]
patches = PK / 'claim_type_format_patch_v1/PATCHES_v1.json'
extractor = ROOT / 'docs/audit/scripts/build_citation_graph.py'
SOURCES = OUT / 'sources'
SOURCES.mkdir()
inputs = []

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def freeze(p, rel):
    q = SOURCES / rel
    q.parent.mkdir(parents=True, exist_ok=True)
    assert not q.exists()
    q.write_bytes(p.read_bytes())
    assert p.read_bytes() == q.read_bytes()
    inputs.append(dict(original_path=str(p), original_sha256=sha(p),
        recovery=str(q), recovery_sha256=sha(q)))
    return q

patchcopy = freeze(patches, 'PATCHES_v1.json')
extractcopy = freeze(extractor, 'build_citation_graph.py')
source = ast.parse(extractcopy.read_text())
names = {'CLAIM_TYPE_LINE_RE', 'TYPE_LINE_RE', 'CLAIM_TYPES'}
functions = {'normalize_claim_type', 'extract_claim_type_hint'}
selected = []
for n in source.body:
    if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in names for t in n.targets):
        selected.append(copy.deepcopy(n))
    if isinstance(n, ast.FunctionDef) and n.name in functions:
        selected.append(copy.deepcopy(n))
assert len(selected) == 5
module = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
standalone = 'import re\n' + ast.unparse(module) + '\n'
(OUT / 'EXTRACTOR_AST_v1.py').write_text(standalone)
namespace = {'re': re}
exec(compile(module, str(extractor), 'exec'), namespace)
extract = namespace['extract_claim_type_hint']

checks = []
rows = []
def ck(name, passed, detail=None):
    checks.append(dict(name=name, passed=bool(passed), detail=detail))

for entry in json.loads(patchcopy.read_text())['notes']:
    slug = entry['slug']
    old = freeze(Path(entry['original_snapshot']), slug + '/OLD.md')
    new = freeze(Path(entry['final_snapshot']), slug + '/NEW.md')
    diff = freeze(Path(entry['diff']), slug + '/CHANGE.diff')
    install = freeze(Path(entry['install_source']), slug + '/INSTALL.md')
    current = freeze(Path(entry['source_path']), slug + '/CURRENT_SOURCE.md')
    ob, nb = old.read_bytes(), new.read_bytes()
    changed = [i for i, (a, b) in enumerate(zip(ob, nb)) if a != b]
    ck(slug + '_old_pin', sha(old) == entry['original_sha256'])
    ck(slug + '_new_pin', sha(new) == entry['final_sha256'] == sha(install))
    ck(slug + '_equal_length_one_changed_byte', len(ob) == len(nb) and len(changed) == 1)
    idx = changed[0]
    ck(slug + '_space_to_newline', ob[idx:idx + 1] == b' ' and nb[idx:idx + 1] == b'\n'
       and ob[idx + 1:].startswith(b'Claim type: bounded_theorem.'))
    ck(slug + '_all_other_bytes_identical', ob[:idx] == nb[:idx] and ob[idx + 1:] == nb[idx + 1:])
    expected_diff = ''.join(difflib.unified_diff(ob.decode().splitlines(True), nb.decode().splitlines(True),
        fromfile=Path(entry['original_snapshot']).name, tofile=Path(entry['final_snapshot']).name))
    ck(slug + '_exact_diff', expected_diff == diff.read_text())
    oldtype, newtype = extract(ob.decode()), extract(nb.decode())
    ck(slug + '_old_type_missing', oldtype == (None, None), oldtype)
    ck(slug + '_new_live_type', newtype == ('bounded_theorem.', 'bounded_theorem'), newtype)
    is_live20 = slug == 'canonical_envelope'
    ck(slug + '_live_or_staged_current_role', sha(current) == (entry['final_sha256'] if is_live20 else entry['original_sha256']))
    row = dict(slug=slug, original_sha256=sha(old), final_sha256=sha(new),
        changed_byte_offset=idx, old_type=oldtype, new_type=newtype,
        current_source_role='already installed live note' if is_live20 else 'original staged note preserved; formatted install copy separate',
        no_scientific_body_change=True)
    rows.append(row)
    print(json.dumps(row))

for row in inputs:
    ck('fresh_unchanged_' + row['original_path'], sha(Path(row['original_path'])) == row['original_sha256']
       == sha(Path(row['recovery'])))
result = dict(created=datetime.now(timezone.utc).isoformat(),
    passed=sum(x['passed'] for x in checks), failed=sum(not x['passed'] for x in checks),
    checks=checks, notes=rows, inputs=inputs, extractor_sha256=sha(extractor),
    extractor_mode='Exact live AST function and its three constants plus normalization function; no graph main, audit, ledger or runtime operation.',
    scope='Publication format only. No science execution or change of declared claim class.')
(OUT / 'RESULTS_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(passed=result['passed'], failed=result['failed'], input_pairs=len(inputs))))
raise SystemExit(bool(result['failed']))
