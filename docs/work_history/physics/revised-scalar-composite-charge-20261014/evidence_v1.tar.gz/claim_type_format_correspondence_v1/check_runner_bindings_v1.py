from pathlib import Path
import hashlib, json, re

OUT = Path(__file__).resolve().parent
PK = OUT.parent
ROOT = PK.parents[3]
rows = []
inputs = []

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def freeze(p, name):
    q = OUT / 'sources/runner_bindings' / name
    q.parent.mkdir(parents=True, exist_ok=True)
    assert not q.exists()
    q.write_bytes(p.read_bytes())
    assert sha(q) == sha(p)
    inputs.append(dict(original_path=str(p), original_sha256=sha(p), recovery=str(q), recovery_sha256=sha(q)))
    return q

for entry in json.loads((OUT / 'sources/PATCHES_v1.json').read_text())['notes']:
    slug = entry['slug']
    note = (OUT / 'sources' / slug / 'OLD.md').read_text()
    runner_rel = re.search(r'Primary runner: `([^`]+)`', note).group(1)
    if slug == 'canonical_envelope':
        mapping = freeze(PK / 'canonical_envelope_canonical_delivery_v1/delivery_mapping_v1.json', slug + '/delivery_mapping_v1.json')
        receipt = freeze(PK / 'canonical_envelope_canonical_delivery_v1/RECEIPT_v1.json', slug + '/RECEIPT_v1.json')
        r = json.loads(receipt.read_text())
        assert next(x for x in r['bindings'] if x['path'] == 'delivery_mapping_v1.json')['sha256'] == sha(mapping)
        expected = next(x for x in json.loads(mapping.read_text())['original_dispositions'] if x['final_path'] == runner_rel)['final_sha256']
        runner = ROOT / runner_rel
    elif slug == 'composite_charge':
        receipt = freeze(PK / 'composite_charge_canonical_correspondence_v1/RECEIPT_v1.json', slug + '/RECEIPT_v1.json')
        r = json.loads(receipt.read_text())
        assert sha(receipt) == '3d8f2e744ca0035ce59f6b7d0fc2ab0079a0cf892a417de15f7ba7dd936d3a75'
        expected = r['final_runner']['sha256']
        runner = Path(r['final_runner']['path'])
    else:
        version = 2 if slug == 'calibrated_gravity_turning' else 1
        lin = freeze(PK / (slug + '_packaging') / ('CANONICAL_LINEAGE_v' + str(version) + '.json'), slug + '/LINEAGE.json')
        r = json.loads(lin.read_text())
        assert r['note_sha256'] == entry['original_sha256']
        expected = r['runner_sha256']
        runner = PK / (slug + '_packaging') / 'staged' / Path(runner_rel).name
        if version == 2:
            earlier = freeze(PK / (slug + '_packaging/CANONICAL_LINEAGE_v1.json'), slug + '/LINEAGE_v1.json')
            assert json.loads(earlier.read_text())['runner_sha256'] == expected
    copy = freeze(runner, slug + '/' + runner.name)
    assert sha(copy) == expected
    rows.append(dict(slug=slug, runner_path=str(runner), prior_bound_sha256=expected,
        current_sha256=sha(runner), unchanged=True,
        scope='Identity only; no runner executed or scientific body re-reviewed.'))

for row in inputs:
    assert sha(Path(row['original_path'])) == row['original_sha256'] == sha(Path(row['recovery']))
(OUT / 'RUNNER_BINDINGS_v1.json').write_text(json.dumps(dict(passed=len(rows), failed=0, rows=rows, inputs=inputs), indent=2) + '\n')
print(json.dumps(dict(passed=len(rows), failed=0, inputs=len(inputs), rows=rows), indent=2))
