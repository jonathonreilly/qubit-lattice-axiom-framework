from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
RT = Path('/Users/jonBridger/.codex/campaigns/revised-scalar-derivation-24h-20261013')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name, data):
    p = OUT / name
    assert not p.exists()
    p.write_text(json.dumps(data, indent=2) + '\n')

assert not (OUT / 'RECEIPT_v1.json').exists()
inputs = json.loads((OUT / 'RESULTS_v1.json').read_text())['inputs'] + json.loads((OUT / 'RUNNER_BINDINGS_v1.json').read_text())['inputs']
for name in ['CANONICAL_ENVELOPE_UNIT_stdout_v1.txt', 'CANONICAL_ENVELOPE_UNIT_stderr_v1.txt',
             'CANONICAL_ENVELOPE_UNIT_RUN_v1.json', 'CANONICAL_ENVELOPE_UNIT_v1.json']:
    p = RT / name
    q = OUT / 'sources/original_unit_failure' / name
    q.parent.mkdir(parents=True, exist_ok=True)
    assert not q.exists()
    q.write_bytes(p.read_bytes())
    assert sha(p) == sha(q)
    inputs.append(dict(original_path=str(p), original_sha256=sha(p), recovery=str(q), recovery_sha256=sha(q)))
for row in inputs:
    assert sha(Path(row['original_path'])) == row['original_sha256'] == sha(Path(row['recovery']))
put('SOURCE_BINDINGS_v1.json', dict(bindings=inputs, count=len(inputs)))
dispositions = []
for e in json.loads((OUT / 'sources/PATCHES_v1.json').read_text())['notes']:
    final = Path(e['source_path']) if e['slug'] == 'canonical_envelope' else Path(e['install_source'])
    old = OUT / 'sources' / e['slug'] / 'OLD.md'
    assert sha(old) == e['original_sha256'] and sha(final) == e['final_sha256']
    dispositions.append(dict(original_path=e['source_path'], original_sha256=e['original_sha256'],
        disposition='Exactly one space replaced by newline before the unchanged Claim type declaration; complete other bytes retained.',
        recovery=str(old), recovery_sha256=sha(old), final_path=str(final), final_sha256=sha(final)))
put('SOURCE_DISPOSITIONS_v1.json', dict(original_dispositions=dispositions,
    scope='Four old note versions and final live/install bytes. Runner and metadata bindings remain in SOURCE_BINDINGS_v1.json.'))
artifacts = [dict(path=str(p.relative_to(OUT)), bytes=p.stat().st_size, sha256=sha(p))
             for p in sorted(OUT.rglob('*')) if p.is_file()]
put('MANIFEST_v1.json', dict(created=datetime.now(timezone.utc).isoformat(), artifact_count=len(artifacts), artifacts=artifacts))
put('RECEIPT_v1.json', dict(created=datetime.now(timezone.utc).isoformat(), scope='Four-note publication-format correspondence only.',
    report=dict(path='REPORT_v1.md', sha256=sha(OUT / 'REPORT_v1.md')),
    manifest=dict(path='MANIFEST_v1.json', sha256=sha(OUT / 'MANIFEST_v1.json')),
    original_dispositions='SOURCE_DISPOSITIONS_v1.json', original_dispositions_json_pointer='/original_dispositions',
    dispositions_sha256=sha(OUT / 'SOURCE_DISPOSITIONS_v1.json'), artifact_count=len(artifacts), source_pair_count=len(inputs),
    format_checks=[58,0], runner_identity_checks=[4,0], no_science_execution=True, prior_seals_modified=False))
for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json','SOURCE_DISPOSITIONS_v1.json']:
    print(name,sha(OUT/name))
print(json.dumps(dict(artifacts=len(artifacts), source_pairs=len(inputs))))
