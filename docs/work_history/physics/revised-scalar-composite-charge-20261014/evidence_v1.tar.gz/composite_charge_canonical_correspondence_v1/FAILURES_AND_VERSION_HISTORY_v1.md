# Preserved failures and version boundaries

No accidental source or runtime failure occurred in the new correspondence
or wrapper check. Correspondence457/0 and wrapper36/0 are separate types of
evidence. Expected error routes and altered-program failures remain actual
failed subprocesses and are not relabelled positive scientific runs.

The parent staged prose originally summed137+98 as231. The actual executed
output was235/0. Exact prior note bytes, the single-total repair and its record
are retained. A subsequent attempt to insert the worldtube scope clarification
failed because raw hand headings were compared with demoted note headings.
The saved record states that this occurred before staged mutation; the final
corrected replacement, exact diff, final note and lineages are retained.

The final note incorporates prior substantive scope repairs: the static
ambient-response omission in v1/v2 and the dynamic finite-worldtube/global
retarded-history ambiguity in v1. Original notes, final notes, independent
findings and exact changes remain recoverable. No original proof is silently
described as having already contained its later qualification.

The reused dynamic independent review additionally preserves a SymPy Boolean
conversion execution failure and a diff-header correspondence assertion
failure, with its stated missing standalone stdout limitation. Those files
and the full original report/receipt are copied unchanged. All seven static
and five dynamic actual damaged-program runs from the independent reviews,
and all three parent's staged scientific damages, remain intact.

New wrapper fixtures intentionally trigger return/result mismatch, missing
result and preexisting-output/profile errors. Two actual changed wrappers
also violate the expected exit or complete-unit contract. These are synthetic
wrapper tests; their streams, exact programs and source diffs are preserved.
They do not rerun the producer's mathematical calculation or change its source.
