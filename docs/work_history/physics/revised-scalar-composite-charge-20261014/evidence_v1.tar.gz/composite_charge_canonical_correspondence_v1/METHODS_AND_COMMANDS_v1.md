# Reproducible scope and commands

All paths below are relative to this review folder unless the saved argv is
absolute. The commands were executed with Python 3 from the available local
runtime. The recorder preserves the actual sys.executable, full argv,
timestamps, source identities, exit and streams. No producer mathematical
runner was executed by the reviewer in this stage.

1. The initial inline inventory/freeze copied the 46-file assigned packaging
   directory into source_recovery/packaging, checking bytes immediately.
   PACKAGING_FREEZE_v1.json records every original/snapshot path and hash;
   INITIAL_FREEZE_v1.json separately preserves the supplied final lineage and
   clarification JSON. These were preparation/read operations, not counted
   mathematical executions. The initial inline inventory tool transcript is
   not separately archived; the complete resulting frozen bytes are retained.
2. `python3 prepare_sources_v1.py` copied the explicit original units (excluding
   the primary PDF), both manifest-closed prior reviews and two declared note
   dependencies. PREPARE_RUN_v1.json and its full streams bind the actual
   command/source. The script verifies all reused manifest artifacts and
   source-disposition triples before copying. It adds 283 frozen pairs.
3. `python3 execute_owned_v1.py check_correspondence_v1.py CORRESPONDENCE_v1`
   independently reverses the declared identifier mapping and compares every
   AST node, exact complete proof bodies, both text diffs, source pins, every
   scientific output object and each actual parent altered-program record.
   CORRESPONDENCE_RESULTS_v1.json holds every predicate and detailed census.
   The exact command and fresh 662-path pre/post identities are in its RUN.
4. `python3 execute_owned_v1.py check_wrapper_v1.py WRAPPER_v1` extracts only
   the exact main/entry guard, substitutes synthetic unit stubs, and executes
   eleven separate fixtures. The default temporary route sets TMPDIR inside
   the owned directory. No scientific function is imported or called.
   WRAPPER_RESULTS_v1.json and wrapper_controls_v1 preserve all exact sources,
   changed programs/diffs, per-run argv/results/streams and expected failures.

Complete read coverage includes both source programs, the complete staged
runner and builder, the current note, original/final proof text by exact reuse,
protocols, lineages and correction records, the two previous full reports,
the full local-response dependency and the saved result objects. Programmatic
full-object equality consumes every result row; it is stronger than comparing
counts or a hand-selected subset. Reading old frozen scientific results is
explicitly authorized only for this later correspondence stage; it does not
retroactively change the earlier blind mathematical reviews.

The underlying static and dynamic mathematical derivations, independent
fixtures, executed calculations and actual mathematical damages are in the
two complete source_recovery/prior_independent subtrees. Their exact seals,
including failures and their original evidence limits, are reused without
new scientific execution. The current report makes no additional blind-test,
primary-paper full-read, empirical or retained-status claim.
