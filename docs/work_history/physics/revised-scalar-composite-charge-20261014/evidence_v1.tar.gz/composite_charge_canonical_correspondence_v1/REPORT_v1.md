# Focused staged composite-charge correspondence

The final staged note and runner preserve the independently checked static
and finite-window results, including the repaired ambient-response and local
worldtube restrictions. The complete mathematical program bodies and saved
scientific outputs correspond. No additional material discrepancy was found
within this staged-only scope. The parent remains scientific author; this is
not a formal audit, retained-grade decision, empirical acceptance, committed
delivery check or selection of a physical matter/radiation state.

The checked staged note is
`EXPONENTIAL_SCALAR_COMPOSITE_CHARGE_BOUNDED_THEOREM_NOTE_2026-10-14.md`, SHA
`631eee364559774e0234dd2ec4e8597748b5d89136be562f5f893390348d7eee`.
The checked staged runner is `exponential_scalar_composite_charge_check.py`,
SHA `8a40f1bf964f59951d862ce9c615ad58c23fe4d118a645ed0a1a19163d60c0d4`.
Their originals remain in the parent's composite_charge_packaging/staged
directory, with complete exact copies in this review's source_recovery.

## Complete correspondence and reused science

The full final note, both complete original scientific programs, the complete
staged runner and builder, lineages, correction records, protocols, original
and staged execution records, output structure and actual staged damage
records were inspected. Every stored check, detail, numeric string, table,
scope field and unit stream was compared programmatically, not merely the
pass counts. The supplied action identity was reused from the preceding
review; the full local-response dependency was also read here. These supplied
models and local approximations remain premises, not conclusions of this port.

The staged note contains the complete static DERIVATION_v3 and dynamic
DERIVATION_v2 texts exactly, with only one additional heading marker on
heading lines. It therefore retains the complete earlier proofs, including
their hypotheses, equations and limitations. No paragraph, equation or
substantive table was shortened. Static v1/v2, dynamic v1, exact corrections
and earlier staged prose remain preserved as historical versions.

An independent inverse-renaming comparison matches every AST statement of
both original programs: 10 static statements and 9 dynamic statements,
including imports, constants and complete function bodies. Only the original
CLI guards were removed; declared function and constant renamings isolate
the two programs. The remaining new statements implement the canonical
metadata, main wrapper and entry guard. The duplicated imports resolve to
the same modules; the scientific mutable names and arithmetic are local to
their functions, and both functions explicitly select 70-digit precision.
There is no imported reviewer helper, empirical target or saved scientific
oracle in either scientific function.

The complete saved canonical output is equal to the original output after
removing only each unit's checker_sha256 field. The exact census is:

| Unit | Check rows | Substantive stored rows |
|---|---:|---|
| Static | 137 | 15 source/range cases and 20 angular Green rows |
| Dynamic | 98 | 9 instantaneous/retarded cases and 9 finite-window rows |
| Aggregate | 235 | Both complete unit objects and captured streams |

Every original, profile and aggregate row was consumed. Counts were computed
from the Boolean rows; names are unique; stdout bytes equal the saved
aggregate JSON. Both original runs and the staged run have the recorded
source identity and exit 0, with empty stderr. These are reused actual
producer executions, not new independent numerical integrations.

The current correspondence calculation has **457 passed, 0 failed**,
including 329 fresh original/snapshot identity checks. It independently
compares source, proof text, all saved rows, provenance and parent damage
records. These counts are bookkeeping/implementation evidence, not an
additional scientific theorem battery.

The preceding independent static and dynamic reviews were read in full and
reused only after verifying their receipts, reports, every manifest artifact,
closed inventories and all original/recovery/final source bindings. Static
has 98 artifacts and 9 source pairs; dynamic has 92 artifacts and 7 pairs.
All are copied exactly under source_recovery/prior_independent, including
executed checker versions, calculations, commands, failures and damaged
programs. Their independent 154/0 and 341/0 scientific results are explicitly
reused, not rerun or added to the current correspondence count.

## Actual execution and correction chronology

The parent's staged runner executed at 16:33:55–16:34:12 UTC on 2026-10-14.
Its exact bytes remain current. The initially executed note wrapper said
231 total despite its own 137 and 98 components. The preserved actual output
already had 235. The first prose repair changes only that total. The second
prose repair replaces the complete heading-demoted dynamic v1 body with
heading-demoted v2, making the finite-band worldtube F_R and incoming/earlier
boundary-data freedom explicit. Both exact note diffs and all three note
identities were reconstructed successfully.

The first attempted worldtube replacement asserted that raw hand text was
present in the staged note. That assertion failed because the staged headings
had been demoted. The parent records that it wrote the separate hand v2 and
preserved the old note but did not modify the staged note before the corrected
replacement. This actual packaging failure remains preserved. It is not a
scientific failure or an unreported source rewrite.

The final note was therefore clarified after the saved staged execution.
The current CLI does not read the note or other declared metadata inputs in
its mathematical functions, and the exact program and synthetic inputs did
not change. This report confirms the final text by correspondence; it does
not falsely label the old run as an execution of the later note bytes or as
a fresh canonical cache envelope. Future live/cache/commit delivery remains
outside this staged review. Historical lineage hands identify the initial
dynamic v1, while the explicit dynamic_hand_sha256 and scope_clarification
fields correctly bind v2; both parts of that chronology are preserved.

## Actual sensitivity and wrapper behavior

The three parent altered canonical programs were inspected in full through
exact single-replacement and full-output comparison. All saved diffs,
scripts, profiles, streams, results, recorded exit codes and source hashes
agree. Their unchanged unit retains the complete baseline output; check names
and acceptance expressions are unchanged. The actual outcomes are:

| Actual program change | Passed / failed | Exit | Material failure |
|---|---:|---:|---|
| Trace sign reversed | 219 / 16 | 1 | Finite-range weighted charge and moments |
| Kinetic source factor 2 changed to 1 | 234 / 1 | 1 | Euler/trace normalization |
| Retarded coefficient 2 changed to 3 | 216 / 19 | 1 | Exact coefficient, angular and window comparisons |

These are preserved actual altered executions, not damaged-expression
arguments or source-hash mismatch detections. No producer scientific code
was rerun for this review. The earlier independent reviews also retain their
seven static and five dynamic actual damaged executions under their own
unchanged seals.

Separately, the exact canonical main and guard were extracted into a
reviewer-owned program whose two scientific functions were replaced by
clearly labelled synthetic output stubs. Its AST matches the original main.
Eleven actual subprocess executions test aggregation, both failure routes,
captured streams, written JSON, return-count mismatch, missing result,
preexisting output/profile rejection and default temporary-directory cleanup.
All writes, including temporary files, were confined to this review folder.
This wrapper test has **36 passed, 0 failed** and runs no scientific function.

Two actual copies of that stubbed wrapper were also changed. Ignoring the
failure exit gives exit 0 with a stored failed check; dropping the dynamic
unit gives only the static 2/0 fixture. The independent expected failure-exit
and complete-aggregation contracts reject these respectively. Expected
AssertionError/FileNotFoundError executions are preserved as deliberate
controls, not silently discarded. There was no accidental new reviewer
execution failure in this correspondence stage. The prior dynamic Boolean
conversion and diff-header tooling failures remain intact in the reused seal.

Both new executable checks freshly recorded 662 actual input paths before
and after execution: 329 originals and their 329 snapshots, the two freeze
files, the executing checker and the execution recorder. All remained
unchanged. Complete commands, timestamps, streams, results and source bytes
are preserved. No source hash is substituted for a mathematical damage
witness, and no result from a changed program is represented as the original.

## Physical scope and source disposition

The static theorem concerns a complete isolated stationary stress in a weak
local approximation, including supporting matter, with controlled background
variation and matter-free or independently negligible ambient linear
response. Background subtraction alone is insufficient; the final body
retains the beta_chi Tbg mass term and beta deltaTbg response caveat. Its force
ratio uses the bare metric GE E/r^2, not a separately calibrated total Newton
force. The massless local operator is a formal limit; a finite positive mass
requires the specified local long-range hierarchy. Conservation does not
establish material realization or an equation of state.

The dynamic result is for the signed finite-window average of the specified
local F_R contribution. It does not select global retarded source history,
incoming or homogeneous waves, radiation power, a force, full dynamic metric
or gamma. The 18R/T estimate is sufficient and conservative, not a sharpness
claim. The parent’s exact initial/retarded coefficient distinction and both
source-scope repairs survive the port. No finite-range dynamic conclusion or
stationary metric conclusion is silently extended to the dynamic source.

MICROSCOPE appears only as exposed motivation. The preserved context and
source ledger state the parent's actual access limit and that no telemetry,
likelihood or independent observed test was acquired. The scientific programs
read no measurement input and perform no fit. This review checks that source
role and the absence of an inferred common-coupling bound; it does not newly
read or verify the primary PDF or reproduce an observational likelihood.
The primary PDF remains at its original parent path and is not copied here.

The new seal covers the 46-file frozen packaging inventory, 87 original-unit
source/evidence files, 194 files from the two complete prior independent
seals, and two canonical dependencies: 329 original/snapshot pairs in total.
This is the frozen staged unit, not an assertion about future archive or
delivery files. SOURCE_DISPOSITIONS_v1.json gives every exact original,
recovery and final path/hash, including superseded source/prose recovery and
the explicit transformations into the staged note/runner/output. The full
owned evidence inventory and final receipt are acyclic and immutable once
sealed. No previous seal, parent source, Git state, runtime ownership, model
setting or external chat was modified.
