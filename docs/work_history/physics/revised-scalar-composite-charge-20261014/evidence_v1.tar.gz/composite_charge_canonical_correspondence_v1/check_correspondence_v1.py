from pathlib import Path
import ast, copy, difflib, hashlib, json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
REC = OUT / 'source_recovery'
PACK = REC / 'packaging'
ORIG = REC / 'original'
checks = []

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(p):
    return json.loads(p.read_text())

def ck(name, ok, detail=None):
    checks.append(dict(name=name, passed=bool(ok), detail=detail))

def normalized(d):
    return {k: v for k, v in d.items() if k != 'checker_sha256'}

def astkey(node):
    return ast.dump(node, include_attributes=False)

def counts(label, d):
    rows = d['checks']
    ck(label + '_count_from_every_row', d['passed'] == sum(x['passed'] for x in rows)
       and d['failed'] == sum(not x['passed'] for x in rows))
    ck(label + '_all_rows_boolean', all(type(x['passed']) is bool for x in rows))
    ck(label + '_unique_check_names', len({x['name'] for x in rows}) == len(rows))

lineage = load(PACK / 'CANONICAL_LINEAGE_v3.json')
runner = PACK / 'staged/exponential_scalar_composite_charge_check.py'
note = PACK / 'staged/EXPONENTIAL_SCALAR_COMPOSITE_CHARGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
code = runner.read_text()
cnodes = ast.parse(code).body
ck('final_runner_identity', sha(runner) == lineage['runner_sha256'])
ck('final_note_identity', sha(note) == lineage['note_sha256'])
start = next(i for i, n in enumerate(cnodes) if isinstance(n, ast.ImportFrom) and n.module == 'pathlib')
ast_rows = []
for label, entry, filename in zip(['static', 'dynamic'], lineage['code_sources'],
                                  ['check_stress_v1.py', 'check_dynamic_v1.py']):
    source = ORIG / label / filename
    ck(label + '_original_source_pin', sha(source) == entry['sha256'])
    original_nodes = ast.parse(source.read_text()).body
    selected = [n for n in original_nodes if not isinstance(n, ast.If)]
    ck(label + '_only_dropped_main_guard', len(original_nodes) - len(selected) == 1
       and isinstance(original_nodes[-1], ast.If))
    segment = copy.deepcopy(cnodes[start:start + len(selected)])
    inverse = {v: k for k, v in entry['renames'].items()}
    class UndoNames(ast.NodeTransformer):
        def visit_Name(self, node):
            node.id = inverse.get(node.id, node.id)
            return node
        def visit_FunctionDef(self, node):
            node.name = inverse.get(node.name, node.name)
            return self.generic_visit(node)
    repaired = [UndoNames().visit(n) for n in copy.deepcopy(segment)]
    for i, (a, b) in enumerate(zip(selected, repaired)):
        ck(label + '_AST_statement_' + str(i), astkey(a) == astkey(b), type(a).__name__)
    ast_rows.append(dict(unit=label, complete_statements=len(selected),
                         canonical_first_statement=start, canonical_last_statement=start + len(selected) - 1,
                         original_ast_sha256=hashlib.sha256(astkey(ast.Module(body=selected, type_ignores=[])).encode()).hexdigest(),
                         reverse_renamed_ast_sha256=hashlib.sha256(astkey(ast.Module(body=repaired, type_ignores=[])).encode()).hexdigest()))
    start += len(selected)
ck('only_new_main_and_main_guard_after_bodies', len(cnodes[start:]) == 2
   and isinstance(cnodes[start], ast.FunctionDef) and cnodes[start].name == 'main'
   and isinstance(cnodes[start + 1], ast.If))

def demote(text):
    return '\n'.join(('#' + line if line.startswith('#') else line) for line in text.splitlines()).rstrip() + '\n'

nt = note.read_text()
static_body = demote((ORIG / 'static/DERIVATION_v3.md').read_text())
dynamic_body = demote((ORIG / 'dynamic/DERIVATION_v2.md').read_text())
old_dynamic = demote((ORIG / 'dynamic/DERIVATION_v1.md').read_text())
ck('complete_static_v3_body_once', nt.count(static_body) == 1)
ck('complete_dynamic_v2_body_once', nt.count(dynamic_body) == 1)
oldest = (PACK / 'prose_history/NOTE_before_total_correction_v1.md').read_text()
middle = (PACK / 'prose_history/NOTE_before_worldtube_clarification_v2.md').read_text()
ck('count_only_first_prose_repair', oldest.replace('controls,231 total.', 'controls,235 total.') == middle
   and oldest.count('controls,231 total.') == 1)
ck('worldtube_only_second_prose_repair', middle.count(old_dynamic) == 1
   and middle.replace(old_dynamic, dynamic_body) == nt)
ck('first_diff_exact', ''.join(difflib.unified_diff(oldest.splitlines(True), middle.splitlines(True),
   fromfile='231_stated', tofile='235_actual')) == (PACK / 'prose_history/TOTAL_CORRECTION_v2.diff').read_text())
ck('second_diff_exact', ''.join(difflib.unified_diff(middle.splitlines(True), nt.splitlines(True),
   fromfile='NOTE_v2', tofile='NOTE_v3')) == (PACK / 'WORLD_TUBE_SCOPE_v3.diff').read_text())
tc = load(PACK / 'prose_history/TOTAL_CORRECTION_v2.json')
wc = load(PACK / 'WORLD_TUBE_SCOPE_CLARIFICATION_v3.json')
ck('prose_history_pins', sha(PACK / 'prose_history/NOTE_before_total_correction_v1.md') == tc['old_note_sha256']
   and sha(PACK / 'prose_history/NOTE_before_worldtube_clarification_v2.md') == tc['new_note_sha256'] == wc['note_old_sha256']
   and sha(note) == wc['note_new_sha256']
   and sha(ORIG / 'dynamic/DERIVATION_v1.md') == wc['hand_old_sha256']
   and sha(ORIG / 'dynamic/DERIVATION_v2.md') == wc['hand_new_sha256'])
ck('lineage_explicit_final_dynamic_hand', lineage['dynamic_hand_sha256'] == wc['hand_new_sha256']
   and lineage['scope_clarification'] == wc)

baseline = load(PACK / 'STAGED_RESULTS_v1.json')
ck('canonical_stdout_equals_full_saved_JSON_bytes', (PACK / 'STAGED_stdout_v1.txt').read_bytes()
   == (PACK / 'STAGED_RESULTS_v1.json').read_bytes())
ck('canonical_stderr_empty', (PACK / 'STAGED_stderr_v1.txt').read_bytes() == b'')
ck('canonical_execution_exact_runner_success', load(PACK / 'STAGED_RUN_v1.json')['checker_sha256'] == sha(runner)
   == load(PACK / 'STAGED_STARTED_v1.json')['checker_sha256'] == baseline['checker_sha256']
   and load(PACK / 'STAGED_RUN_v1.json')['exit_code'] == 0)
table_rows = {}
for label, filename in [('static', 'check_stress_v1.py'), ('dynamic', 'check_dynamic_v1.py')]:
    original = load(ORIG / label / 'baseline_v1/RESULTS.json')
    current = baseline['units'][label]
    counts('original_' + label, original)
    counts('canonical_' + label, current)
    ck(label + '_full_science_output_equal', normalized(original) == normalized(current))
    ck(label + '_profile_equal_full_unit', load(PACK / 'profiles_v1' / label / 'RESULTS.json') == current)
    ck(label + '_original_execution_pins', original['checker_sha256'] == sha(ORIG / label / filename)
       == load(ORIG / label / 'RUN_STARTED_v1.json')['checker_sha256']
       == load(ORIG / label / 'RUN_v1.json')['checker_sha256']
       and load(ORIG / label / 'RUN_v1.json')['exit_code'] == 0)
    ck(label + '_unit_stdout_equal_original', baseline['unit_stdout'][label] == (ORIG / label / 'stdout_v1.txt').read_text())
    ck(label + '_original_stderr_empty', (ORIG / label / 'stderr_v1.txt').read_bytes() == b'')
    table_rows[label] = {key: len(value) for key, value in current.items() if isinstance(value, list)}
ck('complete_aggregation', baseline['passed'] == sum(x['passed'] for x in baseline['units'].values()) == 235
   and baseline['failed'] == sum(x['failed'] for x in baseline['units'].values()) == 0)
ck('exact_census_static', table_rows['static'] == dict(checks=137, cases=15, angular_green_checks=20))
ck('exact_census_dynamic', table_rows['dynamic'] == dict(checks=98, cases=9, windows=9))

damage_summaries = []
summary = load(PACK / 'damages_v1/SUMMARY_v1.json')
for name, old, new in load(PACK / 'damages_v1/PROTOCOL_v1.json')['actual_replacements']:
    d = PACK / 'damages_v1' / name
    altered = (d / 'changed.py').read_text()
    result = load(d / 'RESULTS.json')
    run = load(d / 'RUN.json')
    ck(name + '_exact_single_damage', code.count(old) == 1 and code.replace(old, new) == altered)
    ck(name + '_exact_saved_diff', ''.join(difflib.unified_diff(code.splitlines(True), altered.splitlines(True),
       fromfile='original', tofile='altered')) == (d / 'CHANGE.diff').read_text())
    ck(name + '_run_and_output_pins', sha(d / 'changed.py') == run['checker_sha256'] == result['checker_sha256'])
    ck(name + '_actual_nonzero_exit', run['exit_code'] == 1 and run['failed'] == result['failed'] > 0)
    ck(name + '_summary_exact', [z for z in summary if z['name'] == name] == [run])
    ck(name + '_stdout_bytes_equal_saved_JSON', (d / 'stdout.txt').read_bytes() == (d / 'RESULTS.json').read_bytes())
    ck(name + '_stderr_empty', (d / 'stderr.txt').read_bytes() == b'')
    failed = {}
    for label, unit in result['units'].items():
        counts(name + '_' + label, unit)
        ck(name + '_' + label + '_profile_exact', unit == load(d / 'profiles' / label / 'RESULTS.json'))
        ck(name + '_' + label + '_source_exact', unit['checker_sha256'] == sha(d / 'changed.py'))
        ck(name + '_' + label + '_unchanged_check_names', [z['name'] for z in unit['checks']] == [z['name'] for z in baseline['units'][label]['checks']])
        failed[label] = [z['name'] for z in unit['checks'] if not z['passed']]
    ck(name + '_failed_names_complete', failed == run['failed_checks'])
    ck(name + '_counts_complete', result['passed'] == run['passed'] == sum(z['passed'] for z in result['units'].values())
       and result['failed'] == sum(z['failed'] for z in result['units'].values()))
    other = 'static' if name == 'dynamic_retardation' else 'dynamic'
    ck(name + '_other_unit_unchanged', normalized(result['units'][other]) == normalized(baseline['units'][other]))
    damage_summaries.append(dict(name=name, passed=result['passed'], failed=result['failed'], actual_exit=run['exit_code'], failed_checks=failed))

inputs = []
for freeze in ['PACKAGING_FREEZE_v1.json', 'ADDITIONAL_SOURCE_FREEZE_v1.json']:
    f = load(OUT / freeze)
    for row in f['sources']:
        original = Path(row['original_path'])
        snapshot = Path(row['snapshot_path'])
        if not snapshot.is_absolute():
            snapshot = OUT / snapshot
        expected = row['sha256']
        ck('fresh_pin_' + str(original), sha(original) == sha(snapshot) == expected)
        inputs.append(dict(path=str(original), sha256=sha(original), snapshot_path=str(snapshot)))

result = dict(created=datetime.now(timezone.utc).isoformat(), passed=sum(c['passed'] for c in checks),
              failed=sum(not c['passed'] for c in checks), checks=checks, AST=ast_rows,
              complete_output_census=table_rows, actual_parent_damages=damage_summaries,
              fresh_input_count=len(inputs), inputs=inputs,
              scope='Source/text/AST/full saved-output correspondence only. No producer science execution.')
target = OUT / 'CORRESPONDENCE_RESULTS_v1.json'
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['passed', 'failed', 'AST', 'complete_output_census', 'fresh_input_count']}, indent=2))
print(json.dumps([c for c in checks if not c['passed']], indent=2))
raise SystemExit(bool(result['failed']))
