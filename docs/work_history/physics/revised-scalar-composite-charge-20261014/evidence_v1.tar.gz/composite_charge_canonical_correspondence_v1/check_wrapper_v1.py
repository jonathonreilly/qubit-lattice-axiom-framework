from pathlib import Path
import ast, difflib, hashlib, json, os, subprocess, sys
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
WORK = OUT / 'wrapper_controls_v1'
assert not WORK.exists()
WORK.mkdir()
RUNNER = OUT / 'source_recovery/packaging/staged/exponential_scalar_composite_charge_check.py'
nodes = ast.parse(RUNNER.read_text()).body
main = next(n for n in nodes if isinstance(n, ast.FunctionDef) and n.name == 'main')
guard = nodes[-1]
imports = '''from pathlib import Path
from contextlib import redirect_stdout
from tempfile import TemporaryDirectory
import argparse, hashlib, io, json, os
'''
stubs = '''
def stub(out, name):
    out.mkdir(parents=True, exist_ok=False)
    case = os.environ['WRAPPER_FIXTURE']
    failed = (1 if name == 'static' else 2) if case == 'both_fail' else int(case == name + '_fail')
    if case == 'missing_result' and name == 'static':
        return 0
    result = dict(passed=2 if name == 'static' else 3, failed=failed, label=name)
    (out / 'RESULTS.json').write_text(json.dumps(result) + '\\n')
    print('synthetic-' + name)
    return 1 if case == 'return_mismatch' and name == 'static' else failed

def check_static(out):
    return stub(out, 'static')

def check_dynamic(out):
    return stub(out, 'dynamic')
'''
code = imports + stubs + '\n' + ast.unparse(main) + '\n' + ast.unparse(guard) + '\n'
script = WORK / 'wrapper_exact_main_with_stubs.py'
script.write_text(code)
parse = ast.parse(code).body
copied_main = next(n for n in parse if isinstance(n, ast.FunctionDef) and n.name == 'main')
assert ast.dump(copied_main, include_attributes=False) == ast.dump(main, include_attributes=False)
checks = []
records = []

def ck(name, okay, detail=None):
    checks.append(dict(name=name, passed=bool(okay), detail=detail))

def invoke(name, fixture, target=script, default=False, preexisting=None):
    case = WORK / name
    case.mkdir()
    cmd = [sys.executable, str(target)]
    if not default:
        profiles = case / 'profiles'
        if preexisting == 'profiles':
            profiles.mkdir()
        cmd += ['--profiles', str(profiles)]
    destination = case / 'RESULTS.json'
    if preexisting == 'out':
        destination.write_text('original sentinel\n')
    cmd += ['--out', str(destination)]
    tmp = case / 'temporary'
    tmp.mkdir()
    started = datetime.now(timezone.utc).isoformat()
    before = hashlib.sha256(target.read_bytes()).hexdigest()
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10,
        env={**os.environ, 'WRAPPER_FIXTURE': fixture, 'TMPDIR': str(tmp),
             'PYTHONDONTWRITEBYTECODE': '1'})
    (case / 'stdout.txt').write_text(result.stdout)
    (case / 'stderr.txt').write_text(result.stderr)
    after = hashlib.sha256(target.read_bytes()).hexdigest()
    record = dict(command=cmd, fixture=fixture, started=started,
        ended=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode,
        script_sha256_before=before, script_sha256_after=after,
        scope='Exact canonical main/guard with synthetic unit stubs; no scientific functions run.')
    (case / 'RUN.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    assert before == after
    return case, result

for fixture, expected in [('pass', (5, 0)), ('static_fail', (5, 1)),
                          ('dynamic_fail', (5, 1)), ('both_fail', (5, 3))]:
    case, result = invoke(fixture, fixture)
    data = json.loads((case / 'RESULTS.json').read_text())
    ck(fixture + '_complete_counts', (data['passed'], data['failed']) == expected)
    ck(fixture + '_exit', result.returncode == int(expected[1] > 0))
    ck(fixture + '_stdout_and_file_equal', result.stdout == (case / 'RESULTS.json').read_text())
    ck(fixture + '_both_units_preserved', list(data['units']) == ['static', 'dynamic'])
    ck(fixture + '_captured_streams', data['unit_stdout'] == {'static': 'synthetic-static\n', 'dynamic': 'synthetic-dynamic\n'})
    ck(fixture + '_empty_stderr', result.stderr == '')

for fixture in ['return_mismatch', 'missing_result']:
    case, result = invoke(fixture, fixture)
    ck(fixture + '_fails_closed', result.returncode != 0 and not (case / 'RESULTS.json').exists())
    ck(fixture + '_specific_exception', ('AssertionError' if fixture == 'return_mismatch' else 'FileNotFoundError') in result.stderr)

for existing in ['profiles', 'out']:
    case, result = invoke('existing_' + existing, 'pass', preexisting=existing)
    ck(existing + '_collision_nonzero', result.returncode != 0 and 'AssertionError' in result.stderr)
    if existing == 'out':
        ck('existing_output_unchanged', (case / 'RESULTS.json').read_text() == 'original sentinel\n')
    else:
        ck('existing_profiles_unchanged', not list((case / 'profiles').iterdir()))

case, result = invoke('default_temporary', 'pass', default=True)
data = json.loads((case / 'RESULTS.json').read_text())
ck('default_success', result.returncode == 0 and (data['passed'], data['failed']) == (5, 0))
ck('default_temporary_cleanup', not list((case / 'temporary').iterdir()))

damage_rows = []
for label, old, new in [
    ('ignore_failure_exit', "return bool(result['failed'])", 'return False'),
    ('drop_dynamic_unit', "[('static', check_static), ('dynamic', check_dynamic)]", "[('static', check_static)]")]:
    assert code.count(old) == 1
    damaged = code.replace(old, new)
    altered = WORK / (label + '.py')
    altered.write_text(damaged)
    (WORK / (label + '.diff')).write_text(''.join(difflib.unified_diff(code.splitlines(True), damaged.splitlines(True), fromfile='exact_main_with_stubs', tofile=label)))
    case, result = invoke('damage_' + label, 'dynamic_fail', target=altered)
    data = json.loads((case / 'RESULTS.json').read_text())
    expected_science_count = (data['passed'], data['failed']) == (5, 1)
    expected_failure_exit = result.returncode == 1
    witness = expected_failure_exit if label == 'ignore_failure_exit' else expected_science_count
    ck(label + '_actual_damage_detected', not witness, dict(actual_exit=result.returncode, actual_counts=[data['passed'], data['failed']]))
    damage_rows.append(dict(label=label, expected_contract_satisfied=witness,
        actual_exit=result.returncode, passed=data['passed'], failed=data['failed'],
        scientific_runner_executed=False))

result = dict(created=datetime.now(timezone.utc).isoformat(), passed=sum(c['passed'] for c in checks),
    failed=sum(not c['passed'] for c in checks), checks=checks, executions=records,
    actual_wrapper_damages=damage_rows, canonical_runner_sha256=hashlib.sha256(RUNNER.read_bytes()).hexdigest(),
    main_AST_exact=True, scope='Synthetic wrapper behavior only. Deliberate subprocess errors are required controls, not ignored failures.')
(OUT / 'WRAPPER_RESULTS_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(passed=result['passed'], failed=result['failed'], actual_executions=len(records), damages=damage_rows), indent=2))
print(json.dumps([c for c in checks if not c['passed']], indent=2))
raise SystemExit(bool(result['failed']))
