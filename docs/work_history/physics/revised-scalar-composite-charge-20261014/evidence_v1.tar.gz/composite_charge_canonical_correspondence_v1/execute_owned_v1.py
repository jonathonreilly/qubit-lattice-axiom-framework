from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('script')
parser.add_argument('label')
args = parser.parse_args()
script = (OUT / args.script).resolve()
assert script.parent == OUT and script.is_file()
assert args.label.replace('_', '').isalnum()
paths = {Path(__file__).resolve(), script}
for freeze in ['PACKAGING_FREEZE_v1.json', 'ADDITIONAL_SOURCE_FREEZE_v1.json']:
    paths.add(OUT / freeze)
    for r in json.loads((OUT / freeze).read_text())['sources']:
        paths.add(Path(r['original_path']))
        p = Path(r['snapshot_path'])
        paths.add(p if p.is_absolute() else OUT / p)
def pin():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before = pin()
cmd = [sys.executable, str(script)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60,
                      env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1'})
after = pin()
for suffix, text in [('_stdout.txt', proc.stdout), ('_stderr.txt', proc.stderr)]:
    p = OUT / (args.label + suffix)
    assert not p.exists()
    p.write_text(text)
record = dict(command=cmd, started=started, ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              exit_code=proc.returncode, inputs_before=before, inputs_after=after,
              inputs_unchanged=before == after, scope='Reviewer-owned source/output correspondence or synthetic wrapper test; no producer science rerun.')
p = OUT / (args.label + '_RUN.json')
assert not p.exists()
p.write_text(json.dumps(record, indent=2) + '\n')
print(proc.stdout)
print(proc.stderr)
print(json.dumps(dict(exit_code=proc.returncode, inputs=len(before), inputs_unchanged=before == after)))
raise SystemExit(proc.returncode or int(before != after))
