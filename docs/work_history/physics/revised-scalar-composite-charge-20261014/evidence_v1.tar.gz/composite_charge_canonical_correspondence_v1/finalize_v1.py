from pathlib import Path
import datetime, hashlib, json

OUT = Path(__file__).resolve().parent
PK = OUT.parent
PACK = PK / 'composite_charge_packaging'
NOTE = PACK / 'staged/EXPONENTIAL_SCALAR_COMPOSITE_CHARGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER = PACK / 'staged/exponential_scalar_composite_charge_check.py'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(p):
    return json.loads(p.read_text())

def put(name, data):
    p = OUT / name
    assert not p.exists(), str(p)
    p.write_text(json.dumps(data, indent=2) + '\n')

assert not (OUT / 'RECEIPT_v1.json').exists()
assert sha(NOTE) == '631eee364559774e0234dd2ec4e8597748b5d89136be562f5f893390348d7eee'
assert sha(RUNNER) == '8a40f1bf964f59951d862ce9c615ad58c23fe4d118a645ed0a1a19163d60c0d4'
dispositions = []
for filename in ['PACKAGING_FREEZE_v1.json', 'ADDITIONAL_SOURCE_FREEZE_v1.json']:
    for row in load(OUT / filename)['sources']:
        original = Path(row['original_path'])
        recovery = Path(row['snapshot_path'])
        if not recovery.is_absolute():
            recovery = OUT / recovery
        expected = row['sha256']
        assert sha(original) == sha(recovery) == expected
        final = original
        disposition = 'unchanged_exact_bytes_preserved; source/evidence identity, not an additional scientific assertion'
        field = None
        rel = original.relative_to(PK).parts if original.is_relative_to(PK) else ()
        is_direct_unit = len(rel) >= 3 and rel[0] == 'rolling_local_response' and rel[1] in ['composite_stress_bridge_v1', 'dynamic_composite_charge_v1'] and 'independent_v1' not in rel
        if is_direct_unit and original.name.startswith('DERIVATION_v') and len(rel) == 3:
            final = NOTE
            disposition = 'exact original preserved; final scoped staticv3/dynamicv2 body ported with heading demotion; earlier scopes remain historical'
        elif is_direct_unit and original.name in ['check_stress_v1.py', 'check_dynamic_v1.py'] and len(rel) == 3:
            final = RUNNER
            disposition = 'complete scientific AST ported with declared identifier renaming; exact original script retained'
        elif is_direct_unit and rel[-2:] == ('baseline_v1', 'RESULTS.json'):
            final = PACK / 'STAGED_RESULTS_v1.json'
            disposition = 'complete scientific JSON ported; only checker identity changes; exact original result retained'
            field = 'units.static' if rel[1] == 'composite_stress_bridge_v1' else 'units.dynamic'
        elif original.parent == PACK / 'prose_history' and original.suffix == '.md':
            final = NOTE
            disposition = 'superseded staged prose preserved exactly; final note includes recorded count and worldtube scope repairs'
        elif original.parent == PACK and original.name in ['CANONICAL_LINEAGE_v1.json', 'CANONICAL_LINEAGE_v2.json']:
            final = PACK / 'CANONICAL_LINEAGE_v3.json'
            disposition = 'historical lineage preserved; final lineage separately binds final scoped note and unchanged runner'
        elif 'prior_independent' in recovery.parts:
            disposition = 'prior independent evidence/seal preserved unchanged and identity-verified; not a new scientific execution'
        item = dict(original_path=str(original), original_sha256=expected,
                    disposition=disposition, recovery=str(recovery), recovery_sha256=sha(recovery),
                    final_path=str(final), final_sha256=sha(final))
        if field:
            item['final_field'] = field
        dispositions.append(item)
assert len(dispositions) == 329
assert len({d['original_path'] for d in dispositions}) == 329
put('SOURCE_DISPOSITIONS_v1.json', dict(original_dispositions=dispositions,
    scope='Complete frozen staged-source/evidence recovery. No final committed/live-cache claim. Prior independent seals unchanged. Primary PDF retained at original parent path, outside this mathematical correspondence inventory.'))

c = load(OUT / 'CORRESPONDENCE_RESULTS_v1.json')
w = load(OUT / 'WRAPPER_RESULTS_v1.json')
assert (c['passed'], c['failed']) == (457, 0)
assert (w['passed'], w['failed']) == (36, 0)
assert len(w['executions']) == 11
for label in ['CORRESPONDENCE_v1', 'WRAPPER_v1']:
    record = load(OUT / (label + '_RUN.json'))
    assert record['exit_code'] == 0 and record['inputs_unchanged']
    assert record['inputs_before'] == record['inputs_after']
    for path, expected in record['inputs_after'].items():
        assert sha(Path(path)) == expected

summary = dict(created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    final_note=dict(path=str(NOTE), sha256=sha(NOTE)),
    final_runner=dict(path=str(RUNNER), sha256=sha(RUNNER)),
    new_correspondence=dict(passed=c['passed'], failed=c['failed'], source_pairs=329),
    new_wrapper=dict(passed=w['passed'], failed=w['failed'], actual_executions=11,
                     actual_changed_wrapper_witnesses=w['actual_wrapper_damages']),
    reused_producer_science=dict(static_checks=137, dynamic_checks=98, total=235,
        static_cases=15, angular_rows=20, dynamic_cases=9, dynamic_windows=9,
        producer_science_rerun=False),
    reused_independent_seals=load(OUT / 'ADDITIONAL_SOURCE_FREEZE_v1.json')['reused_seals'],
    actual_parent_damages=c['actual_parent_damages'],
    remaining_material_discrepancies_within_staged_scope=[],
    scope='Focused staged correspondence only; no formal audit, empirical acceptance or committed/live-cache delivery confirmation.')
put('FINAL_SUMMARY_v1.json', summary)

artifacts = []
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        assert not p.is_symlink()
        artifacts.append(dict(path=str(p.relative_to(OUT)), bytes=p.stat().st_size, sha256=sha(p)))
put('MANIFEST_v1.json', dict(created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Closed reviewer-owned inventory excluding this manifest and receipt, avoiding self-hash cycles.',
    artifact_count=len(artifacts), artifacts=artifacts))
receipt = dict(created=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    role='Focused independent staged canonical correspondence; parent retains scientific authorship; not a formal audit.',
    report=dict(path='REPORT_v1.md', sha256=sha(OUT / 'REPORT_v1.md')),
    manifest=dict(path='MANIFEST_v1.json', sha256=sha(OUT / 'MANIFEST_v1.json')),
    source_dispositions=dict(path='SOURCE_DISPOSITIONS_v1.json', sha256=sha(OUT / 'SOURCE_DISPOSITIONS_v1.json')),
    summary=dict(path='FINAL_SUMMARY_v1.json', sha256=sha(OUT / 'FINAL_SUMMARY_v1.json')),
    artifact_count=len(artifacts), source_pair_count=len(dispositions),
    final_note=summary['final_note'], final_runner=summary['final_runner'], no_self_hash_cycle=True)
put('RECEIPT_v1.json', receipt)
for name in ['REPORT_v1.md', 'MANIFEST_v1.json', 'RECEIPT_v1.json', 'SOURCE_DISPOSITIONS_v1.json']:
    print(name, sha(OUT / name))
print(json.dumps(dict(artifacts=len(artifacts), source_pairs=len(dispositions))))
