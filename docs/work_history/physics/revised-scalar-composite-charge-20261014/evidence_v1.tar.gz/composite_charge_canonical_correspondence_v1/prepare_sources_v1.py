from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
PK = OUT.parent
ROOT = PK.parents[3]
RR = PK / 'rolling_local_response'
rows = []

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def copy(p, target):
    assert p.is_file() and not p.is_symlink()
    target.parent.mkdir(parents=True, exist_ok=True)
    data = p.read_bytes()
    assert not target.exists()
    target.write_bytes(data)
    assert data == p.read_bytes() == target.read_bytes()
    rows.append(dict(original_path=str(p), original_sha256=sha(p),
                     snapshot_path=str(target), sha256=sha(target), bytes=len(data)))

seals = {}
for label, name in [('static', 'composite_stress_bridge_v1'), ('dynamic', 'dynamic_composite_charge_v1')]:
    unit = RR / name
    for p in sorted(unit.rglob('*')):
        if not p.is_file() or 'independent_v1' in p.relative_to(unit).parts or p.suffix == '.pdf':
            continue
        copy(p, OUT / 'source_recovery' / 'original' / label / p.relative_to(unit))
    old = unit / 'independent_v1'
    receipt = json.loads((old / 'RECEIPT_v1.json').read_text())
    manifest = json.loads((old / 'MANIFEST_v1.json').read_text())
    for key in ['report', 'manifest', 'source_dispositions']:
        assert sha(old / receipt[key]['path']) == receipt[key]['sha256']
    declared = {r['path'] for r in manifest['artifacts']} | {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
    actual = {str(p.relative_to(old)) for p in old.rglob('*') if p.is_file()}
    assert actual == declared
    for item in manifest['artifacts']:
        assert sha(old / item['path']) == item['sha256']
        assert (old / item['path']).stat().st_size == item['bytes']
    dispositions = json.loads((old / 'SOURCE_DISPOSITIONS_v1.json').read_text())['original_dispositions']
    for d in dispositions:
        assert sha(Path(d['original_path'])) == d['original_sha256']
        assert sha(Path(d['recovery'])) == d['recovery_sha256'] == d['original_sha256']
        assert sha(Path(d['final_path'])) == d['final_sha256']
    for rel in sorted(declared):
        copy(old / rel, OUT / 'source_recovery' / 'prior_independent' / label / rel)
    seals[label] = dict(receipt_sha256=sha(old / 'RECEIPT_v1.json'),
                        report_sha256=sha(old / 'REPORT_v1.md'),
                        manifest_sha256=sha(old / 'MANIFEST_v1.json'),
                        verified_artifacts=len(manifest['artifacts']),
                        verified_source_pairs=len(dispositions), closed_inventory=True)

for name in ['EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md',
             'EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md']:
    copy(ROOT / 'docs' / name, OUT / 'source_recovery' / 'dependencies' / name)

result = dict(created=datetime.now(timezone.utc).isoformat(), sources=rows, reused_seals=seals,
              scope='Exact original implementations/results/history, prior independent closed seals and declared note dependencies. No producer execution; primary PDF not copied or newly read.')
(OUT / 'ADDITIONAL_SOURCE_FREEZE_v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(frozen=len(rows), bytes=sum(x['bytes'] for x in rows), reused_seals=seals), indent=2))
