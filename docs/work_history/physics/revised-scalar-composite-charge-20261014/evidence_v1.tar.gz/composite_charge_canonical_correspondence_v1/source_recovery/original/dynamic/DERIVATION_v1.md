# A finite observation window without a stationary matter state

Scientific author: /root. The static composite-body result is useful, but real
observations average over finite windows. This block asks which part of its
stationary-state premise can be replaced by exact conservation and endpoint
bounds. It derives only a source-generated massless scalar amplitude, not a
complete observed force or a selected radiative state.

## 1. Local premises and exact instantaneous identity

Use the same supplied universal conformal coupling and kinetic normalization as
the composite-stress derivation, with constant beta, GE=1/(8 pi Q), weak source
and a local flat background. The massless scalar equation is the formal mu=0
local-operator limit, not a selected massless member of the supplied potential.
Ambient matter response and metric/scalar backreaction are neglected under the
same explicit scope. This calculation does not establish their smallness.

On a finite time band, a complete symmetric matter tensor obeys
partial_mu T^{mu nu}=0 and has support in a fixed ball |x|<=R. Define
rho=T00>=0, j_i=T0i, S=sum_i Tii, E=integral rho d^3x>0 and
I(t)=integral |x|^2 rho(t,x)d^3x. Assume smoothness/decay sufficient for the
following operations and the pointwise component bounds |j|<=rho and
|Tii|<=rho for each i. These inequalities and confinement are declared physical
conditions, not consequences of scalar field dynamics or a derived body state.
Conservation and vanishing surface flux give constant E and

    I'=2 integral x dot j,
    I''=2 integral S,
    Qinstant(t)=integral(rho-S)=E-I''/2.

This is exact matter kinematics in the stated local model. Without stationarity,
the instantaneous integrated scalar trace need not equal energy. It is not yet
the retarded radiative monopole.

For any window [t0,t1] of length T>0,

    Qinstant_bar/E = 1-[I'(t1)-I'(t0)]/(2 E T),
    |Qinstant_bar/E-1| <= 2 R/T.

The bound follows from |I'|<=2RE at both endpoints. No initial phase, periodicity,
relaxation, infinite past or ergodic distribution is required. Restoring units
replaces R/T by R/(c T). This controls an integral of the source, not a direct
finite-distance instrument observable.

## 2. Retardation must be included

The retarded source-generated scalar solution has leading far-zone amplitude

    delta_chi(t,r n)=-beta GE F(u,n)/r+O(r^-2),  u=t-r,
    F(u,n)=integral [rho-S](u+n dot x,x) d^3x.

The large-r expansion assumes compact smooth source on the required retarded
band and sufficient temporal regularity; it is a local flat radiation problem.
The total solution may include an arbitrary homogeneous scalar wave. Defining
the retarded source part does not derive or eliminate that initial-data freedom.

For [u0,u1], use the extended source band [u0-R,u1+R]. The shifted window at
each x differs from the unshifted window only inside endpoint bands of width2R.
Since |rho-S|<=4rho and integral rho(t,x)d^3x=E at every common time,

    |integral_u0^u1 F du - integral_u0^u1 Qinstant du| <=16 E R.

Each of the two endpoint bands contributes at most 4E times2R. Combining the
instantaneous endpoint bound yields the conservative, not sharp, result

    |Fbar/E-1| <=18 R/T.

It holds uniformly in direction n. The bound concerns a signed time average
of the leading scalar source amplitude, not its absolute value, fluctuations,
derivative, scalar energy flux, force, gamma or differential acceleration.
In particular, averaging away an amplitude correction does not bound radiation
power. No constraint on an added homogeneous wave follows. The source need only
satisfy the conditions on the finite extended band, not for an assumed infinite
bounded history.

## 3. A fully conserved time-dependent fixture

Inside R=1 let h(r)=(1-r^2)^m, m>=3, and set it to zero outside. Choose

    rho=rho0+epsilon cos(omega t) Delta h,
    j=epsilon omega sin(omega t) grad h,
    Tij=-epsilon omega^2 cos(omega t) h delta_ij,

with rho0 constant inside the ball and zero outside. Both conservation equations
hold exactly, including absence of boundary distributions because h, its first
derivative and its needed limiting second derivatives vanish at r=1 for m>=3.
The constant base density has no spatial stress/energy flux. This is a conserved
stress fixture, not an equation of state, microscopic material, causal evolution
construction or a demonstrated stable body.

Its energy is E=4 pi rho0/3. With H0=integral h d^3x,

    I=Ibase+6 epsilon cos(omega t) H0,
    Qinstant=E+3 epsilon omega^2 cos(omega t) H0.

The retarded angular integral is spherical and uses sinc(omega r). Define
Hk=integral h(r) sinc(omega r)d^3x. Integration by parts against the regular
Helmholtz wave gives integral Delta h sinc=-omega^2 Hk. Therefore

    F(u)=E+2 epsilon omega^2 cos(omega u) Hk.

The coefficients3 and2 are different even in the small-frequency leading
nontrivial correction. Replacing retarded source time by a common instant
before calculating that correction gives the wrong result. Neither coefficient
is an empirical fit.

For the protocol m=3, rho0=1, epsilon=1/1000, omega<=2, elementary bounds give
|Delta h|<=6m+4m(m-1)=42, |grad h|<=2m=6, h<=1. Hence rho>=0.958,
|j|<=0.012, and each |Tii|<=0.004, establishing the component inequalities
uniformly in time. Finite-window integrals can be computed exactly from sine
endpoint differences, with no assumed random phase.

## 4. Assumption accounting

Conditionally replaced: stationarity for sufficiently long signed averages of
the source-generated massless far-zone amplitude, by finite-band conservation,
confinement and explicit component inequalities. The theorem supplies its own
finite-window error rather than inserting a phase or ensemble distribution.
Still supplied: the action/coupling, weak local massless approximation, source
confinement, stress inequalities and complete material tensor. An arbitrary
homogeneous wave, absolute scales, matter realization and actual measurement
response are still free. The finite-band condition does not derive a globally
bounded cosmological history. No observation likelihood or state selection is
claimed; the fixtures are mathematical development data.
