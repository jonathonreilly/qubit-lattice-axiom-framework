#!/usr/local/bin/python3
from pathlib import Path
import argparse,hashlib,json
import sympy as S
import mpmath as mp

MOMENTUM_SIGN=-1
ENDPOINT_FACTOR=S.Rational(1,2)
RETARDED_COEFFICIENT=2
TIME_SHIFT=1

def run(out):
    out.mkdir(parents=True,exist_ok=False);rows=[];cases=[];windows=[]
    def ck(name,passed,detail=None):rows.append(dict(name=name,passed=bool(passed),detail=detail))
    def eq(name,e):v=S.factor(S.simplify(e));ck(name,v==0,str(v))
    r,t,w,e=S.symbols('r t omega epsilon',positive=True);h=(1-r*r)**3
    lap=S.diff(h,r,2)+2*S.diff(h,r)/r
    rho=1+e*S.cos(w*t)*lap
    j=MOMENTUM_SIGN*e*w*S.sin(w*t)*S.diff(h,r)
    pr=-e*w*w*S.cos(w*t)*h
    eq('energy_conservation',S.diff(rho,t)+S.diff(r*r*j,r)/(r*r))
    eq('momentum_conservation',S.diff(j,t)+S.diff(pr,r))
    for n in range(3):eq('vanishing_h_boundary_jet_'+str(n),S.diff(h,r,n).subs(r,1))
    eq('zero_boundary_flux',j.subs(r,1));eq('zero_boundary_traction',pr.subs(r,1))
    energy=S.integrate(r*r*rho,(r,0,1));moment=S.integrate(r**4*rho,(r,0,1));stress=S.integrate(3*r*r*pr,(r,0,1));qinst=energy-stress;H0=S.integrate(r*r*h,(r,0,1))
    eq('constant_total_energy',energy-S.Rational(1,3))
    eq('moment_first',S.diff(moment,t)-2*S.integrate(r**3*j,(r,0,1)))
    eq('moment_second',S.diff(moment,t,2)-2*stress)
    eq('instantaneous_charge_identity',qinst-(energy-S.diff(moment,t,2)/2))
    eq('moment_polynomial_fixture',moment-S.Rational(1,5)-6*e*S.cos(w*t)*H0)
    eq('instantaneous_coefficient3',qinst-energy-3*e*w*w*S.cos(w*t)*H0)
    sinc=S.sin(w*r)/(w*r)
    eq('radial_Helmholtz',S.diff(sinc,r,2)+2*S.diff(sinc,r)/r+w*w*sinc)
    # Integration by parts: boundary r^2(h' sinc-h sinc') is zero.
    eq('Helmholtz_boundary_outer',(r*r*(S.diff(h,r)*sinc-h*S.diff(sinc,r))).subs(r,1))
    eq('Helmholtz_boundary_center',S.limit(r*r*(S.diff(h,r)*sinc-h*S.diff(sinc,r)),r,0))
    p0,p1,T0,E0=S.symbols('Iprime0 Iprime1 window E')
    eq('finite_window_endpoint_coefficient',-ENDPOINT_FACTOR*(p1-p0)/(E0*T0)+(p1-p0)/(2*E0*T0))
    eq('retarded_coefficient_after_Helmholtz',RETARDED_COEFFICIENT-(-1+3))
    ck('uniform_density_positive',S.Rational(1,1)-S.Rational(42,1000)>0)
    ck('uniform_momentum_bound',S.Rational(12,1000)<S.Rational(958,1000))
    ck('uniform_stress_bound',S.Rational(4,1000)<S.Rational(958,1000))
    eq('retardation_band_error_constant',2*4*2-16)
    eq('full_average_error_constant',16+2-18)
    mp.mp.dps=70;eps=mp.mpf('.001');tol=mp.mpf('1e-45');En=mp.mpf(1)/3
    hf=lambda x:(1-x*x)**3
    dh=lambda x:-6*x*(1-x*x)**2
    lh=lambda x:-18+60*x*x-42*x**4
    hzero=mp.quad(lambda x:x*x*hf(x),[0,1])
    for omega in [mp.mpf(1)/5,mp.mpf(1),mp.mpf(2)]:
        sk=lambda x:mp.sin(omega*x)/(omega*x) if x else mp.mpf(1)
        hk=mp.quad(lambda x:x*x*hf(x)*sk(x),[0,1])
        lapk=mp.quad(lambda x:x*x*lh(x)*sk(x),[0,1])
        ck('weighted_Helmholtz_'+str(omega),abs(lapk+omega**2*hk)<tol,str(lapk+omega**2*hk))
        for tt in [mp.mpf(0),mp.mpf(2)/7,mp.mpf(3)]:
            inst=mp.quad(lambda x:x*x*(1+eps*mp.cos(omega*tt)*(lh(x)+3*omega**2*hf(x))),[0,1])
            predinst=En+3*eps*omega**2*mp.cos(omega*tt)*hzero
            # Direct angular quadrature, not the analytic sinc shortcut.
            direct=En+eps*mp.quad(lambda x:x*x*(lh(x)+3*omega**2*hf(x))*mp.quad(lambda z:mp.cos(omega*(tt+TIME_SHIFT*x*z)),[-1,0,1])/2,[0,1])
            predicted=En+RETARDED_COEFFICIENT*eps*omega**2*mp.cos(omega*tt)*hk
            ck('instantaneous_radial_'+str((omega,tt)),abs(inst-predinst)<tol)
            ck('retarded_angular_'+str((omega,tt)),abs(direct-predicted)<tol,str(direct-predicted))
            ck('retardation_not_instantaneous_'+str((omega,tt)),abs(direct-inst)>mp.mpf('1e-12'))
            cases.append(dict(omega=str(omega),time=str(tt),energy_over_4pi=str(En),Qinstant_over_4pi=str(inst),Fretarded_over_4pi=str(direct),Fformula_over_4pi=str(predicted),H0_over_4pi=str(hzero),Hk_over_4pi=str(hk)))
        for start,length in [(mp.mpf(0),mp.mpf(1)/2),(mp.mpf(1)/7,mp.mpf(3)),(mp.mpf(2)/3,mp.mpf(40))]:
            end=start+length;avgcos=(mp.sin(omega*end)-mp.sin(omega*start))/(omega*length)
            iq=mp.quad(lambda tt:En+3*eps*omega**2*mp.cos(omega*tt)*hzero,[start,end])/length
            fq=mp.quad(lambda tt:En+RETARDED_COEFFICIENT*eps*omega**2*mp.cos(omega*tt)*hk,[start,end])/length
            ip=lambda tt:-6*eps*omega*mp.sin(omega*tt)*hzero
            endpoint=En-mp.mpf(str(ENDPOINT_FACTOR))*(ip(end)-ip(start))/length
            tag=str((omega,start,length))
            ck('window_endpoint_identity_'+tag,abs(iq-endpoint)<tol,str(iq-endpoint))
            ck('window_retarded_integral_'+tag,abs(fq-(En+2*eps*omega**2*avgcos*hk))<tol)
            ck('window_instantaneous_bound_'+tag,abs(iq/En-1)<=2/length)
            ck('window_shift_band_bound_'+tag,abs(fq-iq)/En<=16/length)
            ck('window_retarded_bound_'+tag,abs(fq/En-1)<=18/length)
            windows.append(dict(omega=str(omega),start=str(start),length=str(length),Qinstant_average_over_E=str(iq/En),Fretarded_average_over_E=str(fq/En),instantaneous_bound=str(2/length),shift_bound=str(16/length),retarded_bound=str(18/length),endpoint_formula_over_E=str(endpoint/En)))
    result=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,cases=cases,windows=windows,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite-band source-generated massless amplitude, not force/radiation power or selected homogeneous state. Synthetic complete conserved stress, not derived material.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=len(cases),windows=len(windows),failed_checks=[x for x in rows if not x['passed']]),indent=2));return result['failed']

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();raise SystemExit(bool(run(args.out)))
