# Composite stress and the scalar mass bridge

Scientific author: /root. This is a new personal derivation in the existing
observations-first campaign. Universal weak free fall motivates testing whether
the earlier pressure-negligible source premise is necessary. The supplied
universal conformal matter coupling is still a premise; an experimental null
does not derive exact universality or the complete action. The Laue mechanism
below is established stress-conservation physics, not a novelty claim.

## 1. Explicit local and perturbative domain

Use the supplied action's consistent scalar channel, canonical coordinate chi,
kinetic term -Q (partial chi)^2, and matter action Sm[A(chi)^2 g,matter].
At a constant ambient state write beta=d ln A/d chi, q=beta^2, Q>0,
GE=1/(8 pi Q), and mu^2=Y_chichi>=0. Freeze those coefficients. Work to leading
order in weak gravitational and scalar perturbations, on a local flat background
whose curvature, background evolution and field gradients can be neglected.
No global Minkowski vacuum for the supplied positive vacuum energy is asserted.

The unperturbed body is complete, isolated, stationary, and in its rest frame.
Its symmetric stress tensor has partial_j T^{ij}=0, rho=T^{00}, S=sum_i T^{ii},
and total energy Ebody=integral rho d^3x>0. It is compact or decays so that all
integrations by parts and multipole expansions below are valid. Containers,
support stresses and binding matter must be included. External clamps, omitted
walls, significant self-gravity/scalar binding, time dependence, quantum trace
effects not represented by the complete supplied matter stress, and a strong
ambient profile are outside this leading calculation. A stationary conserved
stress is conditional data, not a derived equation of state or realized body.

Subtract the ambient field equation before linearization: rho and S below
are the compact excess body stress. Constant or slowly changing background
terms are removed in that subtraction; neglected variations require a local
scale separation. This does not assert an arbitrary constant field solves the
full supplied action. At this order, body-induced changes in beta times its
source are of higher weak-source order. Varying the action then gives

    (Delta-mu^2) delta_chi = beta (rho-S)/(2Q).

The sign and factor 2 follow from the -Q kinetic normalization, not the
more common -Q/2 convention. The leading matter trace is -rho+S.

## 2. Massless monopole from conservation

Integrating partial_k(x^i T^{kj}) gives the Laue identity

    integral T^{ij} d^3x = 0,      integral S d^3x = 0.

Consequently the scalar monopole is

    Qscalar(0)=integral(rho-S)d^3x=Ebody.

No pointwise pressure approximation or barotropic law is needed. The static
massless Green function therefore gives, at leading monopole order,

    delta_chi = - beta GE Ebody/r + higher multipoles.

The linearized Einstein equation gives its monopole from integral(rho+S)=Ebody;
the integrated spatial stresses likewise vanish. Thus, in the local asymptotic
monopole zone, the two Jordan potentials obey

    Psi_J = - GE Ebody (1+q)/r,
    Phi_J = - GE Ebody (1-q)/r,
    gamma = (1-q)/(1+q).

Here g00=-(1+2 Psi) and gij=(1-2 Phi)delta_ij in isotropic weak coordinates.
These are leading long-range potentials, not an automatically valid spacecraft
time-delay likelihood, finite-range PPN fit, or nonlinear matched Solar solution.

With ambient Ainf constant, rJ=Ainf rE and Ebody=Ainf MJ. The common potential
coefficient becomes Gbare MJ/rJ, where Gbare=Ainf^2 GE. MJ is the body's total
local inertial energy in Jordan units, not a previously assigned sum of rest
masses. This derives the leading mass conversion for this weak isolated body.

For an external scalar gradient nearly constant across a weak test body,
partial_mu T^{mu i}=beta T partial_i chi gives the integrated force
F_i=-beta Ebody partial_i chi. Thus the acceleration has the same leading beta
for complete stationary test bodies. Under these premises a massless common
scalar changes universal attraction, but produces no leading differential
acceleration between two such bodies. Weak-equivalence-principle null results
alone therefore do not bound this common q. Finite experimental precision does
not establish the premises. Finite-size tidal, self-binding, composition-specific
coupling or environmental corrections must be separately calculated.

## 3. Finite range: the surviving stress moment

For a spherically symmetric source supported in r<=R, define

    f(r)=sinh(mu r)/(mu r), with f=1 at mu r=0,
    Qscalar(mu)=integral f(r)(rho-S) d^3x.

The exact exterior solution of the frozen linear scalar problem is

    delta_chi(r)=-beta GE Qscalar(mu) exp(-mu r)/r,  r>R.

Weighted integration by parts gives

    integral f S = - integral r f'(r) Trr,
    Qscalar(mu)=integral [f rho+r f' Trr] d^3x.

Indeed partial_j(f x_i T^{ij})=f S+r f' Trr under stress conservation.
The unweighted cancellation does not imply weighted cancellation. At fixed
compact stress profile the small-mass expansion is

    Qscalar(mu)/Ebody = 1 + mu^2/(6 Ebody)
        integral r^2 (rho+2 Trr) d^3x + O(mu^4).

The equivalent weighted virial relation is integral r^2 S=-2 integral r^2 Trr.
Finite-range scalar charge therefore depends on a stress moment not determined
by total mass or the unweighted Laue identity.

If the additional pointwise inequalities rho>=0 and |Trr|<=rho hold, then

    2 sinh(x)/x-cosh(x) <= Qscalar(mu)/Ebody <= cosh(x),  x=mu R.

The proof uses f+r f'=cosh(mu r), f-r f'=2f-cosh(mu r).
The first is increasing and the second decreasing for nonnegative argument:
the latter has power coefficients (1-2n)/(2n+1)! for n>=1. This is a conditional
bound, not a derived energy condition. Its lower bound can be negative at large
x. Neither positive density nor conservation alone lets us reuse the earlier
positive-source Yukawa-kernel bounds for the signed trace source.

For a pointlike weak test body outside the sphere, the scalar/Newton force ratio
is q [Qscalar(mu)/Ebody](1+mu r)exp(-mu r), relative to the
bare metric Newton acceleration GE Ebody/r^2. A finite test body requires its own
spatial response; a published constant-gamma bound cannot simply be substituted.

## 4. Explicit conserved synthetic stress family

Take R=1, rho=rho0>0 inside, zero outside, and

    pr=p0(1-r^2)^2,
    pt=pr+(r/2)pr'=p0(1-r^2)(1-3r^2).

Radial conservation pr'+2(pr-pt)/r=0 holds, including the regular center limit.
The radial traction vanishes at the outer boundary, so no missing surface force
is introduced. The density jump has no static spatial-divergence contribution.
For p0/rho0 in {-2/5,0,2/5}, |pr| and |pt| are bounded by rho0. These examples
have the same Ebody and exactly zero integrated S, yet different finite-mu charge.
They are admissible conserved stress fixtures, not derived material equilibria.
An arbitrary overall small density scale can ensure weak self-gravity; it does
not select an observed body's density, rigidity or microscopic state.

A constant isotropic pressure inside a sharp sphere with no wall is a control
that violates isolation/conservation at its boundary. Its nonzero integral S
cannot be used as a counterexample to the complete-body theorem. The missing
boundary force is precisely the failed premise.

## 5. Remaining imports and evidence roles

Retired within the stated massless leading domain: pointwise negligible pressure
as a condition for scalar-charge/total-inertial-mass equality. Derived conditionally:
the universal leading composite-body charge, Jordan mass conversion, finite-range
weighted stress identity and a bound under an additional radial stress inequality.
Still supplied: the universal A, the action and canonical channel, background,
range, coupling/scale, a complete conserved stationary stress, weak-field/local
validity and experimental response model. No equation of state, body history,
action selector or independent observed fit is derived.

The protocol's synthetic stress cases test algebra and Green-function matching.
Any cited MICROSCOPE result is exposed observational context, not a calibration,
held-out test, new likelihood, or numerical limit on a universal scalar q.
