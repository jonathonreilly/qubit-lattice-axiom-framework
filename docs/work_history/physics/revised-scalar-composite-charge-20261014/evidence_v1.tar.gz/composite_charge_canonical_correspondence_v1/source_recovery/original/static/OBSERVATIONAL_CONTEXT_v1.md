# Observational motivation and its limit

[MICROSCOPE final results](https://arxiv.org/abs/2209.15487) report
eta(Ti,Pt)=[-1.5 +/-2.3(stat) +/-1.5(syst)] x 10^-15, with statistical errors
at one standard deviation. The observable compares differential accelerations
of electrostatically controlled test masses; the published response includes
instrument calibration and nuisance terms. These facts motivate deriving the
complete-body charge. They do not establish the exact universal conformal
coupling assumed here.

Our leading massless complete-body calculation predicts a common acceleration
under its explicit premises. Thus this reported differential null alone cannot
be converted to a limit on the common q. Finite range, self-binding, environmental
profiles and the actual instrument require further modeling. The paper is
exposed development context; no likelihood is fitted and no independent observed
test is claimed. The PDF identity and exact access limits are in PRIMARY_SOURCE_v1.json.
