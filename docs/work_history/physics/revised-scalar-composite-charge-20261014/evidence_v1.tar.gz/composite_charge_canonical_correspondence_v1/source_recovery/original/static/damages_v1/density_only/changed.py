#!/usr/local/bin/python3
from pathlib import Path
import argparse, hashlib, json
import sympy as S
import mpmath as mp

TRACE_SIGN = -1
VIRIAL_FACTOR = 2
KINETIC_FACTOR = 2
DENSITY_ONLY = True
BOUNDARY_TERM = 1

def run(out):
    out.mkdir(parents=True, exist_ok=False)
    checks=[];cases=[];angles=[]
    def ck(name,passed,detail=None):checks.append(dict(name=name,passed=bool(passed),detail=detail))
    def eq(name,expr):v=S.factor(S.cancel(expr));ck(name,v==0,str(v))
    r,p,rho=S.symbols('r p rho', positive=True)
    pr=p*(1-r*r)**2;pt=pr+r*S.diff(pr,r)/2;trace=pr+2*pt
    eq('radial_conservation',S.diff(pr,r)+2*(pr-pt)/r)
    eq('regular_center',pr.subs(r,0)-pt.subs(r,0))
    eq('boundary_radial_traction',pr.subs(r,1))
    eq('integrated_Laue',S.integrate(r*r*trace,(r,0,1)))
    eq('weighted_virial',S.integrate(r**4*trace,(r,0,1))+VIRIAL_FACTOR*S.integrate(r**4*pr,(r,0,1)))
    f=S.Function('f')(r)
    eq('weighted_divergence_identity',S.diff(r**3*f*pr,r)-(r*r*f*trace+r**3*S.diff(f,r)*pr))
    # Independent integration of a uniform unsupported pressure: omitted boundary
    # traction would falsely apply Laue to an incomplete system.
    eq('unsupported_pressure_surface_flux',S.integrate(3*p*r*r,(r,0,1))-BOUNDARY_TERM*p)
    ck('unsupported_pressure_is_not_Laue',S.integrate(3*p*r*r,(r,0,1))!=0)
    Q,b,T,box,yprime=S.symbols('Q beta T box Yprime')
    EL=2*Q*(box-yprime)+b*T
    eq('kinetic_trace_normalization',EL.subs(box,yprime-b*T/(KINETIC_FACTOR*Q)))
    A,M,x,G=S.symbols('A M x G', positive=True)
    eq('Jordan_mass_radius_conversion',G*(A*M)/(x/A)-(A*A*G)*M/x)
    q=S.symbols('q',nonnegative=True)
    eq('metric_gamma_ratio',(1-q)/(1+q)-1+2*q/(1+q))
    # Uniform-gradient trace force divided by total inertial energy is -beta.
    E,g=S.symbols('E grad',positive=True)
    eq('passive_trace_force',(-b*E*g)/E+b*g)
    for n in range(1,13):ck('lower_envelope_series_sign_'+str(n),S.Rational(1-2*n,S.factorial(2*n+1))<0)
    mp.mp.dps=70;tol=mp.mpf('1e-45');energy=mp.mpf(1)/3
    fs=lambda x:mp.sinh(x)/x if x else mp.mpf(1)
    weighted=lambda x:mp.cosh(x)-fs(x)
    charges={}
    for pp in [mp.mpf(-2)/5,mp.mpf(0),mp.mpf(2)/5]:
        prf=lambda rr:pp*(1-rr*rr)**2
        ptf=lambda rr:pp*(1-rr*rr)*(1-3*rr*rr)
        sf=lambda rr:prf(rr)+2*ptf(rr)
        moment=mp.quad(lambda rr:rr**4*(1+VIRIAL_FACTOR*prf(rr)),[0,1])
        ck('energy_condition_'+str(pp),all(abs(prf(mp.mpf(j)/100))<=1 and abs(ptf(mp.mpf(j)/100))<=1 for j in range(101)))
        for mu in [mp.mpf(0),mp.mpf('0.0001'),mp.mpf('.1'),mp.mpf(1),mp.mpf(3)]:
            tag=str(pp)+'_'+str(mu)
            charge=mp.quad(lambda rr:rr*rr*fs(mu*rr)*(1+(0 if DENSITY_ONLY else TRACE_SIGN)*sf(rr)),[0,1])
            weighted_charge=mp.quad(lambda rr:rr*rr*(fs(mu*rr)+weighted(mu*rr)*prf(rr)),[0,1])
            density_charge=mp.quad(lambda rr:rr*rr*fs(mu*rr),[0,1])
            ck('weighted_charge_identity_'+tag,abs(charge-weighted_charge)<tol,str(charge-weighted_charge))
            low=2*fs(mu)-mp.cosh(mu);high=mp.cosh(mu)
            ck('conditional_charge_envelope_'+tag,low-tol<=charge/energy<=high+tol)
            approx=energy+mu*mu*moment/6
            remainder=abs(charge-approx)/energy
            rem_bound=4*(fs(mu)-1-mu*mu/6)
            ck('small_mass_remainder_'+tag,remainder<=rem_bound+tol,dict(remainder=str(remainder),bound=str(rem_bound)))
            if not mu:ck('massless_composite_charge_'+tag,abs(charge-energy)<tol)
            if mu and pp:ck('finite_range_density_only_fails_'+tag,abs(charge-density_charge)>tol)
            for rr in [mp.mpf('1.5'),mp.mpf(3)]:
                deriv=mp.diff(lambda rad:mp.exp(-mu*rad)/rad,rr)
                ck('exterior_force_factor_'+tag+'_'+str(rr),abs(-rr*rr*deriv-(1+mu*rr)*mp.exp(-mu*rr))<tol)
            charges[(str(pp),str(mu))]=charge
            cases.append(dict(p0_over_rho0=str(pp),mu_R=str(mu),energy_over_4pi=str(energy),trace_charge_over_4pi=str(charge),weighted_charge_over_4pi=str(weighted_charge),density_charge_over_4pi=str(density_charge),charge_over_energy=str(charge/energy),second_moment_over_4pi=str(moment),lower_bound=str(low),upper_bound=str(high),remainder=str(remainder),remainder_bound=str(rem_bound)))
    for mu in [mp.mpf('.0001'),mp.mpf('.1'),mp.mpf(1),mp.mpf(3)]:
        ck('same_mass_distinct_stress_charge_'+str(mu),charges[(str(mp.mpf(-2)/5),str(mu))]<charges[(str(mp.mpf(0)),str(mu))]<charges[(str(mp.mpf(2)/5),str(mu))])
    # Direct angular quadrature of the three-dimensional Green function. It is
    # independent of the weighted stress integration above; the proof combines
    # this angular identity with the full radial integral, with no saved oracle.
    for mu in [mp.mpf(0),mp.mpf('.0001'),mp.mpf('.1'),mp.mpf(1),mp.mpf(3)]:
        for rr in [mp.mpf('1.5'),mp.mpf(3)]:
            for ss in [mp.mpf('.3'),mp.mpf('.8')]:
                angular=mp.quad(lambda t:mp.exp(-mu*mp.sqrt(rr*rr+ss*ss-2*rr*ss*t))/mp.sqrt(rr*rr+ss*ss-2*rr*ss*t),[-1,0,1])/2
                predicted=mp.exp(-mu*rr)/rr*fs(mu*ss)
                err=abs(angular-predicted)
                ck('angular_Yukawa_'+str((mu,rr,ss)),err<tol,str(err))
                angles.append(dict(mu=str(mu),r=str(rr),source_radius=str(ss),angular=str(angular),predicted=str(predicted),absolute_error=str(err)))
    result=dict(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),checks=checks,cases=cases,angular_green_checks=angles,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional complete isolated stationary leading weak stress; synthetic math only. Universal coupling/action/background/material realization remain premises.')
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=len(cases),failed_checks=[x for x in checks if not x['passed']]),indent=2))
    return result['failed']

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();raise SystemExit(bool(run(args.out)))
