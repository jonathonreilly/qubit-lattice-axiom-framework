from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib
PK=Path(__file__).resolve().parent.parent
DEST=Path(__file__).resolve().parent
STAGE=DEST/'staged';STAGE.mkdir(exist_ok=False)
STATIC=PK/'rolling_local_response/composite_stress_bridge_v1'
DYNAMIC=PK/'rolling_local_response/dynamic_composite_charge_v1'
NOTE='EXPONENTIAL_SCALAR_COMPOSITE_CHARGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='exponential_scalar_composite_charge_check.py'
PARENTS=['docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[STATIC/'check_stress_v1.py',DYNAMIC/'check_dynamic_v1.py']
maps=[{'run':'check_static','TRACE_SIGN':'ST_TRACE_SIGN','VIRIAL_FACTOR':'ST_VIRIAL_FACTOR','KINETIC_FACTOR':'ST_KINETIC_FACTOR','DENSITY_ONLY':'ST_DENSITY_ONLY','BOUNDARY_TERM':'ST_BOUNDARY_TERM'},{'run':'check_dynamic','MOMENTUM_SIGN':'DY_MOMENTUM_SIGN','ENDPOINT_FACTOR':'DY_ENDPOINT_FACTOR','RETARDED_COEFFICIENT':'DY_RETARDED_COEFFICIENT','TIME_SHIFT':'DY_TIME_SHIFT'}]
class Rename(ast.NodeTransformer):
    def __init__(self,m):self.m=m
    def visit_Name(self,n):n.id=self.m.get(n.id,n.id);return n
    def visit_FunctionDef(self,n):n.name=self.m.get(n.name,n.name);return self.generic_visit(n)
blocks=[];lineage=[]
for path,mapping in zip(sources,maps):
    selected=[x for x in ast.parse(path.read_text()).body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    tree=ast.fix_missing_locations(Rename(mapping).visit(ast.Module(body=selected,type_ignores=[])))
    blocks.append(ast.unparse(tree)+'\n');lineage.append(dict(path=str(path),sha256=sha(path),renames=mapping,selected_statement_types=['Import','ImportFrom','FunctionDef','Assign'],transformed_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
header='#!/usr/local/bin/python3\n"""Complete-body scalar charge and finite-window source amplitude."""\nfrom contextlib import redirect_stdout\nfrom tempfile import TemporaryDirectory\nimport io\nAUDIT_TIMEOUT_SEC=120\nAUDIT_INPUT_PATHS='+repr(['docs/'+NOTE]+PARENTS)+'\n'
footer='''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--profiles',type=Path);parser.add_argument('--out',type=Path);args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True);units={};streams={}
        for name,fn in [('static',check_static),('dynamic',check_dynamic)]:
            captured=io.StringIO()
            with redirect_stdout(captured):failed=fn(root/name)
            result=json.loads((root/name/'RESULTS.json').read_text())
            assert failed==result['failed'];units[name]=result;streams[name]=captured.getvalue()
        return dict(passed=sum(z['passed'] for z in units.values()),failed=sum(z['failed'] for z in units.values()),units=units,unit_stdout=streams,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional complete-body scalar charge and finite-window source amplitude; no selected matter or homogeneous wave, full metric, ambient response or empirical likelihood.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-composite-charge-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='');return bool(result['failed'])
if __name__=='__main__':raise SystemExit(main())
'''
(STAGE/RUNNER).write_text(header+'\n'.join(blocks)+footer)
opening='''# Deriving the scalar charge of complete matter bodies

Status: conditional support. Claim type: bounded_theorem.
Scientific author: /root.
Primary runner: `scripts/exponential_scalar_composite_charge_check.py`.

Observed universality of weak free fall motivates checking the source trace,
rather than assigning a pressure-negligible mass or a body charge. Complete
stress conservation removes the pressure restriction for leading massless
stationary monopoles. Finite range retains a weighted stress moment. For
time-dependent conserved sources, a finite-window endpoint estimate replaces
stationarity only for a signed average of the source-generated amplitude.

The [supplied action](EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md)
and [local normalization](EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md)
remain premises. Universal conformal coupling is not derived from a differential
null. Local flatness, weak fields and controlled ambient response are explicit.
The formal massless operator does not select a massless candidate parameter.
The following are full personal derivations, with preserved version references.

'''
hands=[STATIC/'DERIVATION_v3.md',DYNAMIC/'DERIVATION_v1.md']
bodies=['\n'.join('#'+line if line.startswith('#') else line for line in f.read_text().splitlines()) for f in hands]
closing='''

## Computational evidence and physical interpretation

The canonical calculation preserves137 static and98 dynamic controls,231 total.
Static fixtures have15 source/range cases plus direct angular Green checks.
Dynamic fixtures have9 instantaneous/retarded cases and9 finite windows. All
source coefficients, pressure profiles, frequencies and observation windows are
synthetic development choices. Their complete values, results and actual damaged
programs remain in the recovery archive; they are not measurements or a fitted
material law. The analytic inequalities, not finite samples, establish the
theorem's domain. Counts are implementation assertions, not experiments.

The earlier static hand versions omitted an explicit condition on ambient linear
matter response. Subtracting an ambient equation removes its zeroth-order source,
not that response. The complete v1/v2 texts, exact diffs and v3 scope repair are
retained. No changed equation or relaxed tolerance is used to hide that premise.

[MICROSCOPE](https://arxiv.org/abs/2209.15487) is exposed observational motivation.
The archived context records the accessed source, its identity and limits.
No raw telemetry, instrument likelihood or independently reserved test is used.
The ideal massless universal response is common to complete weak test bodies;
this calculation does not convert a differential null to a bound on common q.

The stationary result concerns total inertial energy, including all supports.
The finite-range bounds require additional stress inequalities and can have an
uninformative negative lower edge. A finite-radius test body and actual apparatus
need their own response calculation. The dynamic bound concerns only a signed
source-amplitude average; it does not bound its fluctuations, derivatives,
radiation power, a measured force or an arbitrary homogeneous scalar solution.
No source realization, globally bounded cosmological history, chosen initial
state, complete action, scale or observed confidence region is derived.

Recovery: `docs/work_history/physics/revised-scalar-composite-charge-20261014/README.txt`.
'''
(STAGE/NOTE).write_text(opening+'\n\n'.join(bodies)+closing)
(DEST/'CANONICAL_LINEAGE_v1.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'code_sources':lineage,'hands':[{'path':str(f),'sha256':sha(f)} for f in hands],'note_sha256':sha(STAGE/NOTE),'runner_sha256':sha(STAGE/RUNNER),'new_wrapper':'Full independent static/dynamic source bodies, captured complete results, aggregated failure.'},indent=2)+'\n')
print(json.dumps({'note':sha(STAGE/NOTE),'runner':sha(STAGE/RUNNER)}))
