# Actual failures and scope findings

The initial independent execution `executions/positive_v1` exited 1 before
writing a result file. Python `int()` rejected SymPy's `BooleanTrue` in the
endpoint-band partition checks. The exact executed `check_dynamic_v1.py`,
14-path pre/post input identities and full traceback remain preserved.

The separate `check_dynamic_v2.py` changes only four conversions to
`int(bool(...))`. The complete diff and hash-bound correction record are
preserved. No scientific expression, profile, sample, precision or acceptance
tolerance was changed. The subsequent execution completed 341/0. The failed
attempt is not assigned a fabricated assertion census.

Five genuinely altered copies of the corrected independent program were
executed, not merely described. They all failed their named mathematical
witnesses and exited 1. Their full source, diffs, fresh identities, result
rows and streams are preserved under `damages` and `executions/damage_*`.
These deliberate failures test current conservation, the instantaneous
one-half coefficient, retarded coefficient 2, the actual time shift, and
the distinction between signed and absolute averages.

The parent v1 wording requires care about the source region: finite-band
data fix the specified local-worldtube contribution, not a unique globally
retarded field of an unspecified earlier/outside history. The existing
homogeneous-wave caveat already leaves the intended freedom open, but the
localization should be explicit. The independent hand addendum records this
finding and a conserved earlier/outside extension as a logical witness.
The coefficient identities and finite-window bounds are unaffected.

The final parent DERIVATION_v2 explicitly supplies this localization and leaves
earlier/outside incoming boundary data free. Its complete text has been read,
and the exact diff has been verified. An initial inline diff check failed
because the reviewer assumed headers v1/v2 rather than the supplied full
filenames. The exact inline source and actual returned error are preserved
in `failed_diff_header_attempt`; separate raw stdout was not captured there,
and the recovery record discloses that limitation. The corrected standalone
correspondence execution completed 4/0 with 19 fresh inner input hashes.
This fixes only the reviewer's header expectation, not a parent source error.

No parent checker or result was opened, and no source outside this review
directory was changed. The earlier static review remains sealed unchanged.
