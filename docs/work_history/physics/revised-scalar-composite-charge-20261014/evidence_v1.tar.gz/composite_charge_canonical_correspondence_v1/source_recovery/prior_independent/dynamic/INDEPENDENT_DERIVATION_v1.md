# Independent finite-window charge and retardation check

The parent remains author. This check reads only its frozen handwritten note
and protocol plus the unchanged supplied action and final static-background
scope. It does not use a producer checker or result.

## Matter identity and finite band

Use x0=t and c=1. Symmetric conserved stress gives rho_t=-div j and
j_i,t=-partial_j T_ji. With a fixed compact support and no omitted boundary
flux, E'=0. Two integrations by parts give

    I'=2 integral x dot j,
    I''=-2 integral x_i partial_j T_ji=2 integral T_ii,
    Q(t)=integral(rho-S)=E-I''/2.

For any finite common-time interval of length T, the exact mean is
Qbar=E-[I'(t1)-I'(t0)]/(2T). Since rho>=0, |x|<=R and |j|<=rho,
|I'|<=2RE. The two endpoint values therefore give error at most 2RE/T.
This is not a sharpness assertion and does not require periodicity or a
distribution of initial phases. With dimensional time, I''=2c^2 integral S;
the fractional bound becomes 2R/(cT), as stated.

## Retarded amplitude, including temporal phase

From the action normalization, the source part of the massless retarded field
is -beta GE integral sigma(t-|rn-x|,x)/|rn-x| d^3x, sigma=rho-S. At fixed
u=t-r and large r, |rn-x|=r-n dot x+O(R^2/r), giving

    delta chi=-beta GE F(u,n)/r+O(r^-2),
    F(u,n)=integral sigma(u+n dot x,x) d^3x.

The error requires bounded temporal derivatives and support on the relevant
finite band. These bounds may depend on that band and on source frequency;
there is no uniform infinite-time/frequency limit or finite-distance detector
claim. This is the source-generated part only. The homogeneous solution of
the scalar equation remains free.

For delta=n dot x, time integration at each fixed x changes the interval to
[u0+delta,u1+delta]. Let w_delta(t) be its indicator minus the indicator of
[u0,u1]. For every |delta|<=R,

    |w_delta(t)| <= 1_[u0-R,u0+R](t)+1_[u1-R,u1+R](t).

This remains valid when the endpoint bands overlap or T<R. Applying Fubini
before using conservation is important: energy is constant on common time
slices, not automatically on a tilted retarded slice. The component bounds
imply |sigma|<=rho+sum_i|Tii|<=4rho. Each endpoint band has length 2R, hence
the retarded/common-time integral difference is at most 16ER. Adding the
instantaneous endpoint error gives 18ER and fractional 18R/T. Direction n
enters only through |delta|<=R, so this proof is uniform in direction.

The triangle bound is deliberately loose and need not be attainable by a
physical source. It controls the signed mean Fbar-E. It does not control the
mean absolute fluctuation, the time derivative, scalar radiation energy,
an added homogeneous wave, or a full metric/force observable.

## Source construction and exact coefficient distinction

For any compact spatial h with the necessary vanishing boundary jets, put
psi=epsilon cos(omega t) h and

    delta rho=Delta psi, j=-grad psi_t, Tij=psi_tt deltaij.

Both conservation equations cancel identically. This construction does not
supply a constitutive relation, causal preparation, or a stable material.
It is simply conserved stress data with a positive static base density.

The integral of Delta h is zero, and integral r^2 Delta h=6 integral h=6H0.
Thus I=Ibase+6epsilon cos(omega t)H0 and Qinstant=E+3epsilon omega^2
cos(omega t)H0. For the Fourier weight exp(i omega n dot x), compact
integration by parts gives integral Delta h exp(i omega n dot x)=-omega^2 Hn.
Together with the trace -3epsilon omega^2 cos(omega t)h, this instead gives

    F=E+2epsilon omega^2 Re[exp(i omega u) Hn].

The density's retarded phase contributes one negative omega^2 Hn and cannot
be dropped when computing the leading nontrivial correction. The coefficients
3 and 2 are therefore distinct even as omega R tends to zero. Setting omega
strictly to zero first removes both corrections and is a blind check.

## Distinct anisotropic fixture

The independent fixture takes R=5/4, rho0=3/2 and
h=g(r)(1+z/(4R)), g=(1-r^2/R^2)^4, epsilon=rho0 R^2/3000. It is not the
parent's spherical m=3 fixture. h and the needed first/second boundary jets
vanish; the static base density may have a spatial step without producing
time variation or flux. All conservation statements hold distributionally
as well as in the interior. The integrable spatial step does not obstruct
the temporal regularity needed for the far-zone expansion.

The elementary bounds |Delta h|<=94/R^2, |grad h|<=41/(4R), |h|<=5/4
follow by differentiating g and the linear factor. For omega R<=5/2,
rho>=rho0(1-94/3000), |j|<=rho0*41/(4*3000)*(5/2), and
|Tii|<=rho0*(5/4)*(5/2)^2/3000. These establish all required pointwise
component inequalities for every time, independently of the samples.

Oddness of z preserves H0 and the radial mass moment. E=125pi/32 and
H0=200pi/693. Let Hr(omega)=4pi integral r^2 g sinc(omega r) dr. For a
direction with component n_z, differentiation of its radial Fourier
transform gives

    Hn=Hr-i*n_z*Hr'(omega)/(4R),
    F=E+2epsilon omega^2[Hr cos(omega u)
                        +n_z*Hr'(omega) sin(omega u)/(4R)].

The signs follow from integral z exp(i k dot x)=-i partial_kz Hr. Thus the
fixture tests a directional phase as well as the radial form factor. Direct
angular/radial integrations provide a route distinct from this transform
derivative. Window means follow from exact sine and cosine endpoint terms;
no phase fitting or random averaging is introduced.

For the original parent's m=3 profile, Delta h is obtained from
h''+2h'/r. Its stated absolute bound 6m+4m(m-1)=42 is conservative; first
and second boundary limits vanish, as required. With epsilon=1/1000 and
omega<=2 the stated density/current/stress margins are valid. The parent's
phase-independent component inequalities are therefore justified, although
they do not establish microscopic realization or causality of a matter model.
