# Finite-band data and the meaning of source-generated field

The finite-window inequalities apply to the explicit functional

    F_R(u,n)=integral_{|x|<=R} sigma(u+n dot x,x) d^3x.

Every point used by this functional lies in the declared extended finite
band. The endpoint proof is valid for it. All independent numerical
integrations already used this finite-radius domain.

Finite-band confinement by itself does not determine a unique globally
retarded field of an otherwise unspecified earlier/outside source history.
An event outside the ball at an earlier time can lie on a null slice
t-n dot x=u in the target window. Its radiation is not fixed by the supplied
worldtube data. In a local problem, that incoming or prior radiation belongs
to free boundary/initial data; it can have been source-generated in a larger
global problem. Calling all of it "homogeneous" is local to the chosen
source-free region, not a claim of no earlier source.

A logical smooth extension illustrates the distinction without asserting
real material. Take a compact spatial bump h_ext centered near x=-L n and
a smooth time pulse f(t) near t=u*-L, entirely before the declared band.
For psi=f(t)h_ext(x), define delta T00=Delta psi,
delta T0i=-partial_t partial_i psi and delta Tij=partial_t^2 psi deltaij.
This added tensor is globally conserved and vanishes during the specified
band, leaving every finite-band assumption and numerical row unchanged.
Its earlier density is signed, which is allowed because no hypotheses were
imposed there; no physical realization is claimed. At null time u*, its full
retarded amplitude is generally nonzero: spatial integration by parts gives
delta F=-2 integral h_ext(x) f''(u*+n dot x) d^3x. Thus the unspecified
outside history cannot be inferred from the finite-band assumptions alone.

The appropriate qualification is to call F_R the retarded contribution of
the specified local worldtube and leave all entering/prior radiation free,
or to add explicit global support/history conditions before identifying it
with the full globally retarded source field. The parent already expressly
leaves homogeneous waves open, so this is a localization of that boundary,
not a change to 2R/T, 16ER, 18R/T, the fixture coefficients, or the integrals.

This issue was identified after the independent v2 computation and reported
before sealing. The original handwritten reviewer derivation and executed
sources are preserved unchanged; this addendum makes the locality precise.
