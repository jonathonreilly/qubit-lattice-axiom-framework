#!/usr/bin/env python3
"""Independent finite-band stress and retarded-amplitude controls."""
import argparse
import json
from pathlib import Path
import sympy as sp
import mpmath as mp


def current(epsilon, omega, time, gradient):
    return epsilon * omega * sp.sin(omega * time) * gradient


def instantaneous_charge(energy, second_moment_derivative):
    return energy - second_moment_derivative / 2


def retarded_coefficient():
    return 2


def shifted_time(u, projection):
    return u + projection


def claimed_average_error(signed_error, absolute_error):
    return abs(signed_error)


def run(output, angular=True):
    mp.mp.dps = 65
    checks, data = [], {}
    tol = mp.mpf('1e-42')

    def record(name, passed, **details):
        checks.append({'name':name, 'passed':bool(passed), **details})

    def exact(name, expression):
        value = sp.simplify(expression)
        record(name, value == 0, residual=str(value))

    def close(name, actual, expected, tolerance=tol):
        error = abs(actual-expected)/max(mp.mpf(1), abs(actual), abs(expected))
        record(name, error <= tolerance, actual=mp.nstr(actual, 55),
               expected=mp.nstr(expected, 55), normalized_error=mp.nstr(error, 12))

    x,y,z,t = sp.symbols('x y z t', real=True)
    eps,w,R = sp.symbols('epsilon omega R', positive=True)
    xyz = (x,y,z)
    rad2 = x*x+y*y+z*z
    h = (1-rad2/R**2)**4*(1+z/(4*R))
    lap = sum(sp.diff(h,v,2) for v in xyz)
    density = 1+eps*sp.cos(w*t)*lap
    j = [current(eps,w,t,sp.diff(h,v)) for v in xyz]
    stress = -eps*w*w*sp.cos(w*t)*h
    exact('energy_conservation_full_anisotropic', sp.diff(density,t)+sum(sp.diff(j[i],xyz[i]) for i in range(3)))
    for i,v in enumerate(xyz):
        exact('momentum_conservation_full_anisotropic_%s' % i, sp.diff(j[i],t)+sp.diff(stress,v))

    r = sp.symbols('r', nonnegative=True)
    g = (1-r*r/R**2)**4
    radial_lap = sp.diff(g,r,2)+2*sp.diff(g,r)/r
    for derivative in range(3):
        exact('radial_boundary_jet_%s' % derivative, sp.diff(g,r,derivative).subs(r,R))
    exact('zero_laplacian_integral', sp.integrate(r*r*radial_lap,(r,0,R)))
    H0 = 4*sp.pi*sp.integrate(r*r*g,(r,0,R))
    exact('radial_second_moment_IBP',4*sp.pi*sp.integrate(r**4*radial_lap,(r,0,R))-6*H0)
    exact('independent_H0',H0.subs(R,sp.Rational(5,4))-200*sp.pi/693)
    # Original parent's m=3 boundary and trace moment, independently differentiated.
    hp = (1-r*r)**3
    lp = sp.diff(hp,r,2)+2*sp.diff(hp,r)/r
    for derivative in range(3):
        exact('parent_m3_boundary_jet_%s' % derivative,sp.diff(hp,r,derivative).subs(r,1))
    exact('parent_m3_second_moment',sp.integrate(r**4*lp,(r,0,1))-6*sp.integrate(r*r*hp,(r,0,1)))

    # Check the endpoint-cover inequality on every partition interval of each
    # rational example, including overlapping endpoint bands T<2R.
    for length in (sp.Rational(1,4),sp.Integer(1),sp.Integer(3)):
        for shift in (-sp.Integer(1),-sp.Rational(2,3),sp.Integer(0),sp.Rational(1,3),sp.Integer(1)):
            cuts=sorted(set([-1,1,length-1,length+1,0,length,shift,length+shift]))
            for index,(a,b) in enumerate(zip(cuts,cuts[1:])):
                time=(a+b)/2
                lhs=abs(int(shift<time<length+shift)-int(0<time<length))
                rhs=int(-1<time<1)+int(length-1<time<length+1)
                record('endpoint_band_T%s_d%s_cell%s' % (length,shift,index), lhs<=rhs)
    exact('endpoint_constant_18',sp.Integer(2)+sp.Integer(4)*sp.Integer(2)*sp.Integer(2)-18)

    R=mp.mpf(5)/4
    rho0=mp.mpf(3)/2
    epsilon=rho0*R*R/3000
    energy=125*mp.pi/32
    hzero=200*mp.pi/693
    ibase=4*mp.pi*rho0*R**5/5
    density_floor=rho0*(1-mp.mpf(94)/3000)
    current_ceiling=rho0*mp.mpf(41)/4*(mp.mpf(5)/2)/3000
    stress_ceiling=rho0*mp.mpf(5)/4*(mp.mpf(5)/2)**2/3000
    record('uniform_density_positive',density_floor>0,value=mp.nstr(density_floor,45))
    record('uniform_current_condition',current_ceiling<=density_floor,value=mp.nstr(current_ceiling,45))
    record('uniform_diagonal_stress_condition',stress_ceiling<=density_floor,value=mp.nstr(stress_ceiling,45))

    def radial_g(rr):
        return (1-(rr/R)**2)**4

    def gprime_over_r(rr):
        return -8*(1-(rr/R)**2)**3/R**2

    def lapg(rr):
        v=(rr/R)**2
        return (-24*(1-v)**3+48*v*(1-v)**2)/R**2

    def sinc(q):
        return mp.mpf(1) if q==0 else mp.sin(q)/q

    def transform(fun,omega):
        return 4*mp.pi*mp.quad(lambda rr:rr*rr*fun(rr)*sinc(omega*rr),[0,R/2,R])

    omegaRs=[mp.mpf(1)/3,mp.mpf(5)/4,mp.mpf(5)/2]
    directions=[mp.mpf(-1),mp.mpf(0),mp.mpf(2)/3,mp.mpf(1)]
    times=[-mp.mpf(2)/5,mp.mpf(3)/7,mp.mpf(11)/6]
    windows=[(-mp.mpf(2)/3,mp.mpf(3)/4),(mp.mpf(1)/5,mp.mpf(7)/3),(mp.mpf(4)/7,mp.mpf(37))]
    instantaneous_rows=[]
    retarded_rows=[]
    window_rows=[]
    transforms={}
    lapmass=4*mp.pi*mp.quad(lambda rr:rr*rr*lapg(rr),[0,R])
    lapmoment=4*mp.pi*mp.quad(lambda rr:rr**4*lapg(rr),[0,R])
    hzero_quad=4*mp.pi*mp.quad(lambda rr:rr*rr*radial_g(rr),[0,R])
    close('independent_radial_H0',hzero_quad,hzero)
    for kappa in omegaRs:
        omega=kappa/R
        hr=transform(radial_g,omega)
        hrp=mp.diff(lambda om:transform(radial_g,om),omega)
        lr=transform(lapg,omega)
        l1p=mp.diff(lambda om:transform(lambda rr:lapg(rr)+2*gprime_over_r(rr),om),omega)
        transforms[str(kappa)]=(hr,hrp,lr,l1p)
        close('radial_Helmholtz_'+mp.nstr(kappa),lr,-omega**2*hr)
        close('odd_Helmholtz_'+mp.nstr(kappa),l1p,-omega**2*hrp)
        def moment(tt):
            return ibase+epsilon*mp.cos(omega*tt)*lapmoment
        def common_trace(tt):
            return energy+epsilon*mp.cos(omega*tt)*(lapmass+3*omega**2*hzero_quad)
        for timeR in times:
            tt=timeR*R
            ip=mp.diff(moment,tt)
            ipp=mp.diff(moment,tt,2)
            charge=instantaneous_charge(energy,ipp)
            oracle=common_trace(tt)
            label='w%s_t%s' % (mp.nstr(kappa),mp.nstr(timeR))
            close('instantaneous_trace_'+label,charge,oracle)
            record('moment_endpoint_bound_'+label,abs(ip)<=2*R*energy)
            instantaneous_rows.append({'omega_R':mp.nstr(kappa,50),'t_R':mp.nstr(timeR,50),
                                       'Q_over_E':mp.nstr(charge/energy,50),'Iprime':mp.nstr(ip,50)})
        for nz in directions:
            hn=hr-1j*nz*hrp/(4*R)
            ln=lr-1j*nz*l1p/(4*R)
            trace_transform=ln+3*omega**2*hn
            for timeR in times:
                uu=timeR*R
                predicted=energy+retarded_coefficient()*epsilon*omega**2*mp.re(mp.exp(1j*omega*uu)*hn)
                oracle=energy+epsilon*mp.re(mp.exp(1j*omega*uu)*trace_transform)
                label='w%s_n%s_t%s' % (mp.nstr(kappa),mp.nstr(nz),mp.nstr(timeR))
                close('retarded_Fourier_'+label,predicted,oracle)
                retarded_rows.append({'omega_R':mp.nstr(kappa,50),'n_z':mp.nstr(nz,50),
                                      'u_R':mp.nstr(timeR,50),'F_over_E':mp.nstr(predicted/energy,50)})
            for startR,lengthR in windows:
                start,length=startR*R,lengthR*R
                end=start+length
                exponential_mean=(mp.exp(1j*omega*end)-mp.exp(1j*omega*start))/(1j*omega*length)
                fmean=energy+retarded_coefficient()*epsilon*omega**2*mp.re(hn*exponential_mean)
                direct_mean=energy+epsilon*mp.quad(lambda uu:mp.re(trace_transform*mp.exp(1j*omega*uu)),[start,end])/length
                qmean=instantaneous_charge(energy,(mp.diff(moment,end)-mp.diff(moment,start))/length)
                qdirect=mp.quad(common_trace,[start,end])/length
                label='w%s_n%s_start%s_T%s' % (mp.nstr(kappa),mp.nstr(nz),mp.nstr(startR),mp.nstr(lengthR))
                close('signed_retarded_window_'+label,fmean,direct_mean)
                close('instantaneous_window_endpoint_'+label,qmean,qdirect)
                record('instantaneous_2R_T_'+label,abs(qmean/energy-1)<=2*R/length)
                record('retardation_16R_T_'+label,abs((fmean-qmean)/energy)<=16*R/length)
                record('signed_retarded_18R_T_'+label,abs(fmean/energy-1)<=18*R/length)
                window_rows.append({'omega_R':mp.nstr(kappa,45),'n_z':mp.nstr(nz,45),
                                    'start_R':mp.nstr(startR,45),'length_R':mp.nstr(lengthR,45),
                                    'Fbar_over_E':mp.nstr(fmean/energy,50),'Qbar_over_E':mp.nstr(qmean/energy,50),
                                    'bound_18R_T':mp.nstr(18*R/length,45)})

    angular_rows=[]
    if angular:
        for kappa,nz,timeR in [(mp.mpf(5)/4,mp.mpf(2)/3,mp.mpf(3)/7),(mp.mpf(5)/2,-mp.mpf(1),-mp.mpf(2)/5)]:
            omega=kappa/R; uu=timeR*R
            def shell(rr):
                def integrand(cosine):
                    projection=rr*cosine
                    havg=radial_g(rr)*(1+nz*rr*cosine/(4*R))
                    lavg=lapg(rr)+nz*rr*cosine*(lapg(rr)+2*gprime_over_r(rr))/(4*R)
                    return rho0+epsilon*mp.cos(omega*shifted_time(uu,projection))*(lavg+3*omega**2*havg)
                return 2*mp.pi*rr*rr*mp.quad(integrand,[-1,0,1])
            direct=mp.quad(shell,[0,R/2,R])
            hr,hrp,_,_=transforms[str(kappa)]
            hn=hr-1j*nz*hrp/(4*R)
            predicted=energy+retarded_coefficient()*epsilon*omega**2*mp.re(mp.exp(1j*omega*uu)*hn)
            close('direct_retarded_angular_w%s_n%s' % (mp.nstr(kappa),mp.nstr(nz)),direct,predicted,mp.mpf('1e-38'))
            angular_rows.append({'omega_R':mp.nstr(kappa),'n_z':mp.nstr(nz),'u_R':mp.nstr(timeR),
                                 'direct_F_over_E':mp.nstr(direct/energy,55),'predicted_F_over_E':mp.nstr(predicted/energy,55)})

    # Exact integer periods keep the signed average zero while |F-E| and
    # derivative power remain nonzero. This tests the stated scope, not a
    # stronger claim that the parent makes.
    kappa=mp.mpf(5)/4; omega=kappa/R
    hr=transforms[str(kappa)][0]
    amplitude=2*epsilon*omega**2*hr/energy
    period_count=1000000
    duration=2*mp.pi*period_count/omega
    signed_error=amplitude*mp.sin(omega*duration)/(omega*duration)
    absolute_error=abs(amplitude)*mp.quad(lambda phase:abs(mp.cos(phase)),[0,mp.pi/2,3*mp.pi/2,2*mp.pi])/(2*mp.pi)
    claimed=claimed_average_error(signed_error,absolute_error)
    record('signed_not_absolute_scope',claimed<=18*R/duration,
           signed_error=mp.nstr(signed_error,50),absolute_error=mp.nstr(absolute_error,50),
           bound=mp.nstr(18*R/duration,50))
    record('absolute_average_not_bounded_by_signed_theorem',absolute_error>18*R/duration)
    record('zero_signed_mean_does_not_zero_derivative_power',amplitude**2*omega**2/2>0,
           normalized_derivative_power=mp.nstr(amplitude**2*omega**2/2,50))

    data={'instantaneous_rows':instantaneous_rows,'retarded_rows':retarded_rows,
          'window_rows':window_rows,'direct_angular_rows':angular_rows,
          'precision_digits':mp.mp.dps,'angular_enabled':angular,
          'uniform_bounds':{'density_floor':mp.nstr(density_floor,50),'current_ceiling':mp.nstr(current_ceiling,50),'stress_ceiling':mp.nstr(stress_ceiling,50)}}
    passed=sum(row['passed'] for row in checks)
    result={'passed':passed,'failed':len(checks)-passed,'checks':checks,'data':data}
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':passed,'failed':len(checks)-passed,'output':str(output)}))
    return 0 if passed==len(checks) else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--skip-angular',action='store_true')
    args=parser.parse_args()
    raise SystemExit(run(args.output,not args.skip_angular))
