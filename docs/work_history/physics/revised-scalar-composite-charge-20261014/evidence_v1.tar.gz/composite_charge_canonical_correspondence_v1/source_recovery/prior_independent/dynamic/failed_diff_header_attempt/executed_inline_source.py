from pathlib import Path
import hashlib,json,datetime,difflib
r=Path.cwd();u=r.parent;rows=[]
for name in ['DERIVATION_v2.md','WORLD_TUBE_SCOPE_v2.diff']:
 p=u/name;b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
 if name=='DERIVATION_v2.md':assert h=='1cc7e8d0609113e90d9dd0f8cd0ba832400a44f11577e5b28d7582bcd06bec7c'
 (r/'sources'/name).write_bytes(b);rows.append({'original_path':str(p),'snapshot_path':'sources/'+name,'bytes':len(b),'sha256':h});print(name+'\n'+b.decode())
(r/'AFFECTED_FREEZE_v2.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':rows,'scope':'Post-execution source-domain clarification only; original numerical source scope unchanged.'},indent=2)+'\n')
a=(r/'sources/DERIVATION_v1.md').read_text();b=(r/'sources/DERIVATION_v2.md').read_text();actual=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='v1',tofile='v2'));supplied=(r/'sources/WORLD_TUBE_SCOPE_v2.diff').read_text();assert actual==supplied
(r/'AFFECTED_CORRESPONDENCE_v2.json').write_text(json.dumps({'full_texts_read':True,'exact_diff_matches':True,'old_sha256':hashlib.sha256(a.encode()).hexdigest(),'new_sha256':hashlib.sha256(b.encode()).hexdigest(),'numeric_rerun':False,'reason':'Local worldtube versus arbitrary earlier/outside history; existing numerical integrations are already restricted to the specified ball.'},indent=2)+'\n')
