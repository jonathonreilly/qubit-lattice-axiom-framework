#!/usr/bin/env python3
"""Preserve and execute actual mathematical damages of reviewer v2."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import sys

root=Path(__file__).resolve().parent
base=root/'check_dynamic_v2.py'
text=base.read_text()
positive_path=root/'executions/positive_v2/RESULTS.json'
positive=json.loads(positive_path.read_text())
assert positive['failed']==0
definitions=[
 ('current_sign','return epsilon * omega * sp.sin(omega * time) * gradient',
  'return -epsilon * omega * sp.sin(omega * time) * gradient','energy_conservation_full_anisotropic',False),
 ('moment_half','return energy - second_moment_derivative / 2',
  'return energy - second_moment_derivative','instantaneous_trace_',False),
 ('retarded_coefficient','return 2\n','return 3\n','retarded_Fourier_',False),
 ('drop_retardation','return u + projection','return u','direct_retarded_angular_',True),
 ('absolute_average','return abs(signed_error)','return absolute_error','signed_not_absolute_scope',False),
]
directory=root/'damages'
directory.mkdir(exist_ok=False)
plan={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
      'positive_result_sha256':hashlib.sha256(positive_path.read_bytes()).hexdigest(),'changes':[]}
for label,old,new,witness,angular in definitions:
    assert text.count(old)==1,(label,text.count(old))
    damaged=text.replace(old,new)
    path=directory/(label+'.py');path.write_text(damaged)
    (directory/(label+'.diff')).write_text(''.join(difflib.unified_diff(text.splitlines(True),damaged.splitlines(True),fromfile=base.name,tofile=path.name)))
    plan['changes'].append({'label':label,'path':str(path.relative_to(root)),
       'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'old':old,'new':new,
       'required_failed_witness':witness,'angular_quadrature':angular})
(directory/'PLAN_v1.json').write_text(json.dumps(plan,indent=2)+'\n')
summary=[]
for row in plan['changes']:
    label='damage_'+row['label']
    argv=[sys.executable,str(root/'run_once.py'),label,row['path']]
    if not row['angular_quadrature']:
        argv.append('--skip-angular')
    run=subprocess.run(argv,cwd=root,capture_output=True)
    (directory/(row['label']+'_orchestration_stdout.txt')).write_bytes(run.stdout)
    (directory/(row['label']+'_orchestration_stderr.txt')).write_bytes(run.stderr)
    result=json.loads((root/'executions'/label/'RESULTS.json').read_text())
    execution=json.loads((root/'executions'/label/'EXECUTION.json').read_text())
    failed=[q['name'] for q in result['checks'] if not q['passed']]
    witness=any(n.startswith(row['required_failed_witness']) for n in failed)
    record={'label':row['label'],'argv':argv,'orchestration_exit_code':run.returncode,
       'actual_exit_code':execution['exit_code'],'passed':result['passed'],'failed':result['failed'],
       'failed_checks':failed,'required_witness_failed':witness,
       'all_fresh_inputs_unchanged':execution['all_inputs_unchanged'],
       'fresh_input_count':len(execution['inputs_before']),
       'result_sha256':hashlib.sha256((root/'executions'/label/'RESULTS.json').read_bytes()).hexdigest()}
    summary.append(record);print(json.dumps(record),flush=True)
(directory/'SUMMARY_v1.json').write_text(json.dumps({'damages':summary,
   'all_detected':all(r['actual_exit_code']==1 and r['required_witness_failed'] for r in summary)},indent=2)+'\n')
