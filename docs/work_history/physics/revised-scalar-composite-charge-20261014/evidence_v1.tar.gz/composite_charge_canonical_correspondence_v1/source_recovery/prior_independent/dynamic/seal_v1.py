#!/usr/bin/env python3
"""Seal the complete dynamic review, including failed reviewer v1."""
from pathlib import Path
import datetime
import hashlib
import json

root=Path(__file__).resolve().parent

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(name,content):
    p=root/name;assert not p.exists(),name
    p.write_text(json.dumps(content,indent=2)+'\n')

freeze_names=['FREEZE_v1.json','STATIC_PREMISE_FREEZE_v1.json','AFFECTED_FREEZE_v2.json','AFFECTED_RECORD_FREEZE_v2.json']
rows=[row for name in freeze_names for row in json.loads((root/name).read_text())['sources']]
final_note=root.parent/'DERIVATION_v2.md'
dispositions=[]
for row in rows:
    original=Path(row['original_path']);snapshot=root/row['snapshot_path']
    assert digest(original)==digest(snapshot)==row['sha256']
    historical=original==root.parent/'DERIVATION_v1.md'
    final=final_note if historical else original
    dispositions.append({'original_path':str(original),'original_sha256':row['sha256'],
       'disposition':'historical_v1_preserved_final_worldtube_scope_v2' if historical else 'read_or_exact_identity_reused_unchanged_and_preserved',
       'recovery':str(snapshot),'recovery_sha256':digest(snapshot),
       'final_path':str(final),'final_sha256':digest(final)})
write('SOURCE_DISPOSITIONS_v1.json',{'original_dispositions':dispositions,
   'coverage':'Named hand/protocol and corrections; complete supplied action and unchanged static scope. No producer implementation/results.'})

positive=json.loads((root/'executions/positive_v2/RESULTS.json').read_text())
assert positive['passed']==341 and positive['failed']==0
assert len(positive['checks'])==len({q['name'] for q in positive['checks']})
affected=json.loads((root/'executions/affected_v2/RESULTS.json').read_text())
assert affected['passed']==4 and affected['failed']==0
assert affected['inputs_before']==affected['inputs_after']
for row in affected['inputs_before']:
    assert digest(Path(row['path']))==row['sha256']
damages=json.loads((root/'damages/SUMMARY_v1.json').read_text())
assert damages['all_detected'] and len(damages['damages'])==5
executions=[]
for path in sorted((root/'executions').glob('*/EXECUTION.json')):
    record=json.loads(path.read_text())
    assert record['all_inputs_unchanged'] and record['inputs_before']==record['inputs_after']
    for row in record['inputs_before']:
        assert digest(Path(row['path']))==row['sha256']
    for name,value in record['streams'].items():
        assert digest(path.parent/name)==value
    result=path.parent/'RESULTS.json'
    if path.parent.name=='positive_v1':
        assert record['exit_code']==1 and not result.exists()
        assert 'TypeError' in (path.parent/'stderr.txt').read_text()
        result_hash=None
    else:
        assert digest(result)==record['result_sha256']
        result_hash=digest(result)
    executions.append({'path':str(path.relative_to(root)),'sha256':digest(path),
       'argv':record['argv'],'cwd':record['cwd'],'start':record['start'],'end':record['end'],
       'exit_code':record['exit_code'],'input_count':len(record['inputs_before']),
       'result_sha256':result_hash})
assert len(executions)==8
write('COMMAND_INDEX_v1.json',{'actual_executions':executions,
   'orchestration_commands':['python3 run_once.py positive_v1 check_dynamic_v1.py',
     'python3 run_once.py positive_v2 check_dynamic_v2.py','python3 make_and_run_damages_v1.py',
     'python3 run_once.py affected_v2 verify_affected_v2.py','python3 seal_v1.py'],
   'no_producer_scientific_execution':True,
   'additional_failed_inline_operation':{'record':'failed_diff_header_attempt/TOOL_FAILURE_RECORD.json',
      'record_sha256':digest(root/'failed_diff_header_attempt/TOOL_FAILURE_RECORD.json'),
      'actual_tool_exit_code':1,'recovered_source':'failed_diff_header_attempt/executed_inline_source.py',
      'limitation':'No separate raw stdout captured for that inline operation; exact printed input payloads remain in source snapshots.'},
   'scope':'Source freezing and explicit-name reads are recorded in the freeze files. No parent prefix discovery.'})
summary={'independent_success':{'passed':341,'failed':0,'instantaneous_rows':9,'directional_retarded_rows':36,'window_rows':36,'direct_angular_integrals':2},
   'actual_failed_initial_execution':'Reviewer SymPy BooleanTrue-to-int TypeError before RESULTS; original source and streams preserved.',
   'reviewer_correction':'Separate v2, exactly four bool conversions; equations, inputs, precision and criteria unchanged.',
   'affected_wording_correspondence':{'passed':4,'failed':0,'inner_fresh_inputs':19},
   'additional_actual_reviewer_failure':'Diff-header expectation mismatch, preserved then corrected without source-body change.',
   'actual_damages':[{k:r[k] for k in ['label','passed','failed','actual_exit_code','required_witness_failed']} for r in damages['damages']],
   'scope_finding':'Finite-band data determine the specified local-worldtube F_R; arbitrary globally retarded history remains undetermined.',
   'final_parent_source':{'path':str(final_note),'sha256':digest(final_note)},
   'parent_implementation_or_results_read':False,'formal_audit':False}
write('FINAL_SUMMARY_v1.json',summary)
manifest=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name not in ['MANIFEST_v1.json','RECEIPT_v1.json']:
        assert not p.is_symlink()
        manifest.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p)})
write('MANIFEST_v1.json',{'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Closed reviewer-owned inventory except manifest and receipt','artifact_count':len(manifest),'artifacts':manifest})
receipt={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'role':'Focused independent mathematical check; no formal audit or physical acceptance',
    'report':{'path':'REPORT_v1.md','sha256':digest(root/'REPORT_v1.md')},
    'manifest':{'path':'MANIFEST_v1.json','sha256':digest(root/'MANIFEST_v1.json')},
    'source_dispositions':{'path':'SOURCE_DISPOSITIONS_v1.json','sha256':digest(root/'SOURCE_DISPOSITIONS_v1.json')},
    'artifact_count':len(manifest),'source_pair_count':len(dispositions),
    'final_parent_source':summary['final_parent_source'],'summary':summary,'no_self_hash_cycle':True}
write('RECEIPT_v1.json',receipt)
for row in manifest:
    assert digest(root/row['path'])==row['sha256']
for key in ['report','manifest','source_dispositions']:
    assert digest(root/receipt[key]['path'])==receipt[key]['sha256']
print(json.dumps({'artifacts':len(manifest),'source_pairs':len(dispositions),
    'hashes':{name:digest(root/name) for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json','SOURCE_DISPOSITIONS_v1.json']}},indent=2))
