#!/usr/bin/env python3
"""Affected wording correspondence only; no scientific rerun."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parent
inputs=[Path(__file__).resolve()]
for name in ['FREEZE_v1.json','STATIC_PREMISE_FREEZE_v1.json','AFFECTED_FREEZE_v2.json','AFFECTED_RECORD_FREEZE_v2.json']:
    inputs.append(root/name)
    for row in json.loads((root/name).read_text())['sources']:
        inputs.extend([Path(row['original_path']),root/row['snapshot_path']])
inputs=sorted(set(inputs),key=str)
def identities():
    return [{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in inputs]
before=identities()
a=(root/'sources/DERIVATION_v1.md').read_text()
b=(root/'sources/DERIVATION_v2.md').read_text()
actual=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='DERIVATION_v1.md',tofile='DERIVATION_v2.md'))
supplied=(root/'sources/WORLD_TUBE_SCOPE_v2.diff').read_text()
metadata=json.loads((root/'sources/WORLD_TUBE_SCOPE_CLARIFICATION_v2.json').read_text())
checks=[{'name':'exact_full_filename_diff','passed':actual==supplied},
        {'name':'old_hand_identity','passed':hashlib.sha256(a.encode()).hexdigest()==metadata['hand_old_sha256']},
        {'name':'new_hand_identity','passed':hashlib.sha256(b.encode()).hexdigest()==metadata['hand_new_sha256']}]
after=identities()
checks.append({'name':'all_affected_inputs_unchanged','passed':before==after})
passed=sum(row['passed'] for row in checks)
args.output.write_text(json.dumps({'passed':passed,'failed':len(checks)-passed,'checks':checks,
    'inputs_before':before,'inputs_after':after,'full_v2_text_read_by_reviewer':True,
    'scope':'Exact source-domain clarification; no scientific rerun. Formal F now explicitly means the finite-worldtube F_R and outside/earlier incoming data remain free.'},indent=2)+'\n')
print(json.dumps({'passed':passed,'failed':len(checks)-passed,'input_paths':len(before),'output':str(args.output)}))
raise SystemExit(0 if passed==len(checks) else 1)
