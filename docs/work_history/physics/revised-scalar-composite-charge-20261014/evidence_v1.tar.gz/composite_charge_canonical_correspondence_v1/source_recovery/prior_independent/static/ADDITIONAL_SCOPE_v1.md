# Final handwritten scope checks

The complete parent v3 text has been read. Both exact version diffs were
independently reconstructed from the preserved source bytes. The effective
ambient restoring mass is Y_chichi-beta_chi Tbg/(2Q); a separate ambient
material response contributes -beta deltaTbg/(2Q). The author's new explicit
vacuum/negligible-response restriction therefore addresses the identified
missing condition. Formal mu=0 does not select a zero-mass physical member.

For the parent's particular n=2 polynomial fixture, let v=r^2/R^2. Its
tangential pressure shape is (1-v)(1-3v)=1-4v+3v^2. Its minimum on [0,1]
is -1/3 at v=2/3, and its maximum is 1 at v=0. Thus the stated amplitudes
plus/minus 2/5 obey both radial and tangential stress inequalities. Directly,
S/p0=3-10r^2+7r^4 at R=1, so integral_0^1 r^2 S/p0 dr=1-2+1=0.
The weighted coefficient is not pressure-independent because integral_0^1
r^4 pr dr=p0(1/5-2/7+1/9)=8p0/315, which is nonzero when p0 is nonzero.
The radial traction vanishes, and pr-pt=O(r^2) makes the center regular.
These hand checks cover the exact parent profile; the executed independent
fixtures instead used n=3 and nonconstant density.

Under a constant ambient conformal conversion, mu_J=mu_E/Ainf and
r_J=Ainf r_E, so mu r is unchanged. The finite-range charge changes units
as Qscalar,J=Qscalar,E/Ainf; its ratio to total inertial energy is unchanged.
Thus the finite-range force ratio can be written in either frame after the
bare metric gravitational coefficient is converted consistently. It is not
the ratio to an independently calibrated, range-dependent measured total G.

The density and stresses in these examples can all be scaled by one small
factor. This controls gravitational backreaction at fixed radius and fixed
dimensionless ratios, but does not supply a constitutive law, assembly
history, mechanical stability, or a realized environment. No primary
MICROSCOPE record was needed or read in this focused mathematical task.
