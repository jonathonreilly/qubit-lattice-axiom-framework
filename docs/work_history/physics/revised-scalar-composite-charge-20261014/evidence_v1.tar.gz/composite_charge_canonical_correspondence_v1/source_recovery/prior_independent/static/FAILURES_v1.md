# Preserved findings and failures

The parent v1 and v2 texts lacked an explicit restriction on retained ambient
linear matter response. V2's subtraction clarification did not alone supply
that restriction. The independent finding, exact source versions/diffs and
parent's v3 repair record are preserved. The final v3 text has been read and
checked, and is the source disposition used in the report.

Seven deliberately damaged reviewer programs actually ran and failed named
mathematical controls. Their full source, diff, inputs, output, streams and
exit codes are in `damages/` and `executions/damage_*`. These are actual altered
executions, not unexecuted damaged expressions. The failed counts are expected
sensitivity evidence and do not replace the positive mathematical proof.

The positive independent run had 154 passed and zero failed assertions.
No accidental execution, parser, timeout or tool failure occurred in this
unit. Earlier units' failures and seals were neither reused as new evidence
nor modified. No producer implementation or output was inspected.
