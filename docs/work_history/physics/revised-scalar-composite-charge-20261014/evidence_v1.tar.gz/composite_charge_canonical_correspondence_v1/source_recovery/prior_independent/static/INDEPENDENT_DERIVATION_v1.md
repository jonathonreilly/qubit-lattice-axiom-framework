# Independent composite-stress derivation

This is a focused check of the frozen handwritten parent argument. The action,
universal conformal coupling, local weak-field expansion, and stationary
complete stress are supplied assumptions. No parent implementation is used.
Natural units have c=1; restoration of c follows the usual stress/energy units.

## Variation and local background

Put the consistent scalar channel in canonical field coordinate chi. The local
action is Q integral [R/2-(partial chi)^2-2Y] plus Sm[A^2 g,matter]. With the
stress convention delta Sm=(1/2) integral sqrt(-g) T^{mu nu} delta g_mu_nu,
its scalar variation is integral sqrt(-g) beta T delta chi. Integration by
parts in the kinetic term gives

    2Q Box chi - 2Q Y_chi + beta T = 0.

Thus Box chi=Y_chi-beta T/(2Q). Static T=-rho+S gives the displayed sign
and factor. The Einstein equation is Q G_mu_nu=T_mu_nu at leading source
order, hence GE=1/(8 pi Q). The static Green function of Delta-mu^2 is
-exp(-mu r)/(4 pi r), producing coefficient -beta GE.

An ambient solution must be subtracted before the local perturbation is formed.
Subtraction alone does not discard a retained ambient matter response:

    (Delta-Y_chichi+beta_chi T_bg/(2Q)) delta chi
      = -beta delta T/(2Q),

where delta T may itself include material response of the ambient medium.
For the parent operator with mu^2=Y_chichi, such terms must be absent or
negligible on the local scales. The compact body's own beta_chi delta chi
times its stress is second weak-source order. Background curvature, gradients,
and the scalar potential's metric stress must also remain negligible on the
local scales. An arbitrary constant scalar is not thereby a global solution.

## Complete stationary stress, metric and scalar monopoles

For every i,j, integrate partial_k(x_i T_kj)=T_ij, with the boundary term
zero and partial_k T_kj=0. Thus all nine integrated spatial components vanish,
including off-diagonal ones; integrated S=0 follows. This does not require
pointwise negligible pressure. Consequently the scalar monopole is E=integral
rho and the active metric monopole is integral(rho+S)=E.

More explicitly, the harmonic-gauge trace-reversed perturbation is
bar h_mu_nu=(4GE/r) integral T_mu_nu at leading monopole order. In the rest
frame, bar h_00=4GE E/r and bar h_ij=0. Its trace is -4GE E/r, so trace
reversal gives h_00=2GE E/r and h_ij=2GE E delta_ij/r. This verifies both
metric potentials rather than assuming equality from the scalar result.

After extracting the constant A_inf^2, the conformal change gives
Psi_J=Psi_E+beta delta chi and Phi_J=Phi_E-beta delta chi. Substitution gives
Psi_J=-GE E(1+beta^2)/r and Phi_J=-GE E(1-beta^2)/r. The ratio is valid in
the leading long-range monopole zone, not a finite-range data likelihood.

The invariant body worldline action is -MJ integral dsJ=-A_inf MJ integral
dsE. Thus E=A_inf MJ and rJ=A_inf rE imply
GE E/rE=A_inf^2 GE MJ/rJ. MJ is total inertial energy in physical units;
it need not equal a sum of constituent rest masses.

The conformal Ward identity is nabla_mu T^{mu nu}=beta T nabla^nu chi.
Integrating it in an imposed, nearly uniform weak scalar gradient yields
dP_i/dt=beta integral T partial_i chi=-beta E partial_i chi. The tensor used
here is the complete unperturbed stationary body; the external gradient is
a first-order force perturbation, not a claim that an accelerated body remains
exactly static. This gives the universal leading passive scalar acceleration.
It does not remove metric/scalar binding corrections, tidal effects, or
composition dependence from a nonuniversal matter action.

## Finite range and an independent Green-function calculation

For a spherical compact source sigma=rho-S at radius s, integrate over the
angle using d=sqrt(r^2+s^2-2rs cos theta). For r>s,

    integral_{-1}^1 exp(-mu d)/d dcos(theta)
      = [exp(-mu(r-s))-exp(-mu(r+s))]/(mu r s).

The mu=0 limit is 2/r. Radial integration therefore yields Q_mu=
4pi integral s^2 sigma(s) sinh(mu s)/(mu s) ds and exterior field
-beta GE Q_mu exp(-mu r)/r. Non-spherical sources generally retain angular
Yukawa multipoles, so this exact single-coefficient exterior formula is not
being extended to them.

For any radial weight f, integrate partial_j(f x_i T_ij). The two derivative
terms are f S+r f' Trr. Hence integral f S=-integral r f' Trr. Taking
f=sinh(mu r)/(mu r) gives Q_mu=integral(f rho+r f' Trr). Expanding the weight,
or taking f=r^2 separately, gives

    integral r^2 S=-2 integral r^2 Trr,
    Q_mu/E=1+mu^2 integral r^2(rho+2Trr)/(6E)+O(mu^4).

The second term is not determined by E. If rho>=0 and |Trr|<=rho,
f-rf' <= (f rho+rf' Trr)/rho <= f+rf'. Here rf'>=0,
f+rf'=cosh(mu r), and f-rf'=2sinh(mu r)/(mu r)-cosh(mu r).
The upper weight is increasing. Every nonconstant even coefficient of the
lower weight is negative, (1-2n)/(2n+1)!, so it is decreasing for positive
argument. Integrating yields exactly the parent's radius-only enclosure.
The lower bound may be negative. It is an enclosure, not an assertion of
attainability or of positive scalar charge at every range.

Differentiating the exterior field gives an attractive scalar acceleration
of magnitude beta^2 GE Q_mu(1+mu r)exp(-mu r)/r^2 when Q_mu>0. Relative to
the bare metric Newton term GE E/r^2, this gives the displayed force ratio.
Replacing the denominator by a measured, range-dependent total G would
change the ratio and requires its own calibration model.

## Distinct conserved fixtures and boundary control

The independent family uses R=3/2, rho0=2/7, v=r^2/R^2,

    rho=rho0(1+v/5), pr=p rho0(1-v)^3,
    pt=p rho0(1-v)^2(1-4v), p in {-3/5,0,3/5}.

All fields are zero outside. Direct differentiation gives radial divergence
zero and pr(R)=0. At the center pr=pt. On 0<=v<=1, the tangential shape has
maximum 1 and minimum -1/4, so |pr|,|pt|<=3rho0/5<=rho. For positive p,
the trace source can nevertheless be negative near the center. Total energy
is E=36pi/25 for every p; all integrated stresses vanish. A second, anisotropic
construction T_ij=delta_ij Delta psi-partial_i partial_j psi with Gaussian
psi proves that the full Laue statement is not tied to spherical symmetry.

For the spherical fixtures, exact radial moments are computed by integrating
the polynomial trace source term by term. Their sinh series is compared to
direct trace quadrature, to a weighted-pressure quadrature, and to angular
Green integrals. These are independent calculation paths. The remainder after
1+(mu r)^2/6 is bounded by (mu R)^4 cosh(mu R)/120 times integral|rho-S|/E.
It therefore supplies a useful finite-error oracle for the factor 2 in the
pressure moment, rather than merely fitting an apparent slope.

A constant isotropic pressure cut off at R is divergence-free only in the
open interior. Distributionally its divergence contains -p n_i delta(r-R).
The missing integrated boundary traction is exactly what invalidates the
Laue argument. The reviewer program must reject this fixture as incomplete.

These are conserved stress data, not a claim of microscopic realizability,
stability, assembly, or observed composition. Scaling their entire stress
and energy down preserves every displayed ratio while making the leading
weak-gravity approximation parametrically consistent.
