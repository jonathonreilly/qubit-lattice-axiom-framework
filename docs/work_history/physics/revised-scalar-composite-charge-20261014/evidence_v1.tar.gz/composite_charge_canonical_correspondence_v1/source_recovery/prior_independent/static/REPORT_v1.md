# Focused independent composite-stress review

The displayed static equations and bounds are consistent with the supplied
action under the final v3 scope. One substantive missing background condition
in v1/v2 was identified and repaired in a separately preserved v3. No parent
checker, numerical output, execution stream, aggregate count or observational
context file was opened. This is a mathematical source check, not a formal
audit, physical acceptance, retained-grade decision or proof of material
realization. The scientific author remains the parent.

## Finding and affected-source confirmation

Subtracting an ambient field equation does not remove its linear matter
response. Linearizing Box chi=Y_chi-beta T/(2Q) yields a squared restoring
mass Y_chichi-beta_chi Tbg/(2Q) and a separate source contribution
-beta deltaTbg/(2Q). Thus v1's implicit background simplification, and v2's
subtraction language alone, did not justify the displayed vacuum-mass
operator in an arbitrary ambient material medium. The compact body's own
beta variation is higher weak-source order; a retained ambient trace is a
different term. This was reported promptly, before sealing.

The final **DERIVATION_v3.md**, SHA
`3d3996e6440710829b1b92f0e0235d2ce72e938c684887f87426867a4b8bdce4`,
explicitly requires matter-free ambient conditions or an independently
justified neglect of the ambient linear response. It gives both terms with
the correct signs. It retains local background scale separation and adds
that mu=0 is a formal local-operator limit. Its mu>0 long-range use requires
R much less than r much less than 1/mu, as well as the local controls.
The earlier v2 also makes the force-ratio denominator the bare metric Newton
term GE Ebody/r^2. Both complete source diffs reproduce the preserved texts
exactly. No displayed source equation or original synthetic fixture changed.

V1 and v2 remain preserved as historical sources and are not silently treated
as having contained the final qualification. There is no remaining material
algebraic discrepancy within the stated v3 domain.

## Independent mathematical coverage

The complete three parent note versions, original protocol and supplied
canonical action were read. The separate handwritten derivation records the
variation of -Q(partial chi)^2, conformal matter variation, static Green sign,
full Laue tensor identity, harmonic-gauge trace reversal, Jordan potentials,
body energy/radius conversion, and passive uniform-gradient force. The scalar
source coefficient is beta/(2Q), and GE=1/(8piQ). The integrated scalar and
active metric charges both equal the total inertial energy for the complete
stationary stress. The signs give gamma=(1-q)/(1+q).

The finite-range exterior coefficient was rederived by changing the angular
Green integration variable to source-observer distance. A separate weighted
divergence calculation gives integral f S=-integral r f' Trr. It produces the
factor 2 in the small-mass pressure moment and the stated cosh enclosure.
The lower enclosure can be negative, is not an attainability claim, and
requires the additional pointwise radial stress inequality. A signed trace
source cannot inherit bounds for a positive density source without checking
that separate premise. Exact spherical exterior reduction is not extended
to non-spherical Yukawa multipoles.

The original n=2 pressure fixture was checked by hand, including center,
traction, stress extrema and exact integrated moments. The numerical route
uses a different n=3 pressure profile, nonconstant density, different radius,
amplitudes, mass arguments and exterior sample points. A smooth anisotropic
Gaussian stress construction checks all integrated spatial tensor components.
These controls test conservation beyond a copied spherical identity.

## Actual computation and sensitivity

`check_composite_v1.py` ran once positively: **154 passed, 0 failed** in
14.17 seconds. It uses SymPy exact variation/integration and 70-digit mpmath
quadrature. The 15 finite-range rows compare direct trace quadrature,
weighted radial-pressure quadrature, and a separately integrated polynomial
moment series. There are nine finite-error small-mass remainder checks and
two direct two-dimensional angular/radial Green integrals. The largest
normalized equality residual was about 3.20e-71, below the frozen 1e-48
identity tolerance; the direct angular tolerance was 1e-45.

At mu R=4/3, the three same-energy fixtures have Q/E approximately 1.1793232820,
1.1934457343 and 1.2075681867. At mu=0 all equal 1. The positive-pressure
fixture has a negative trace-source region despite positive density and
bounded principal stresses. A separate conserved positive-density fixture
that deliberately violates the radial stress inequality gives Q/E about
-3.2407965515 at mu R=4; it is a counterexample only to positivity from
conservation plus density alone, not to the conditional enclosure.

Seven actual altered reviewer programs were executed. Each contains one
preserved expression change, a complete source file and exact diff. The
mathematical checks, not a source-hash mismatch, reject each one:

| Alteration | Passed / failed | Decisive witness |
|---|---:|---|
| Missing kinetic factor 2 | 150 / 2 | Euler variation and Green normalization |
| Reversed trace sign | 125 / 27 | Weighted identity, polynomial moments, finite-range charge ordering |
| Pressure moment coefficient 2 changed to 1 | 146 / 6 | Explicit O(mu^4) remainder bounds |
| Density-only finite-range charge | 125 / 27 | Weighted identity and same-mass distinct-charge controls |
| Surface traction omitted from source completeness | 151 / 1 | Sharp constant-pressure ball rejected |
| Jordan G conversion A instead of A^2 | 151 / 1 | Invariant mass/radius conversion |
| Spatial conformal sign reversed | 150 / 2 | Spatial potential and gamma |

Each altered run omits only the two expensive direct angular integrals and
therefore has 152 checks. Every run exited 1 for failed mathematical checks.
The positive run exited 0. Fresh pre/post identities cover 22 actual paths
per run, including all original handwritten inputs and their snapshots.
All were unchanged. No unchanged positive producer or reviewer run was
repeated. Full argv, working directory, timestamps, streams, results and
input identities are preserved for all eight executions.

The wrong trace sign and density-only substitutions still pass the massless
pressure-independence tests, because the unweighted integrated stress vanishes.
Their finite-range failures demonstrate why massless checks alone do not test
the signed source or weighted moment correctly. No accidental computation or
tooling failure occurred in this unit; the deliberate failures and the actual
v1/v2 scope omission are retained rather than rewritten as successes.

## Physical boundary and disposition

The positive result is conditional on a complete isolated stationary body,
weak gravitational/scalar backreaction, universal conformal matter coupling,
the specified local background restriction and the relevant source support
or decay. Walls and binding matter must be included; an externally clamped or
truncated pressure source does not meet the premise. A common leading scalar
acceleration does not by itself produce differential free fall between these
test bodies. That logical statement supplies no measured bound on q and does
not establish the premise in a real experiment.

The calculation does not derive an equation of state, material stability,
source assembly, environment selection, strong-body scalar charge, finite-size
test response, full Solar-system likelihood, zero scalar mass, or cosmological
matching. Its synthetic conserved tensors are not asserted to be realized
matter. No primary-data or observational fit was performed, and no source
outside the owned review directory was edited.

The final source disposition is v3 under its explicit conditions; v1/v2 and
their correction records remain recoverable. `SOURCE_DISPOSITIONS_v1.json`
binds every original/snapshot/final path and hash. `MANIFEST_v1.json` is the
closed evidence inventory; `RECEIPT_v1.json` binds the report, manifest and
dispositions without a self-hash cycle. No sealed earlier review was changed.
