#!/usr/bin/env python3
"""Independent variation, conserved-stress and Green-function controls.

No parent implementation is imported or executed. This file is also the
preserved base for actual mathematical damaged-copy executions.
"""
import argparse
import json
from pathlib import Path
import mpmath as mp
import sympy as sp


def scalar_source(beta, rho, stress, Q):
    return beta * (rho - stress) / (2 * Q)


def trace_source(rho, stress):
    return rho - stress


def small_moment_source(rho, pressure):
    return rho + 2 * pressure


def complete_source(interior_divergence, surface_traction):
    return interior_divergence == 0 and surface_traction == 0


def physical_gravity(A, GE):
    return A * GE


def physical_phi(phi_e, beta, chi):
    return phi_e - beta * chi


def fweight(x):
    return mp.mpf(1) if x == 0 else mp.sinh(x) / x


def compute(out, quick=False):
    mp.mp.dps = 70
    tolerance = mp.mpf('1e-48')
    checks, data = [], {}

    def record(name, passed, **detail):
        checks.append({'name': name, 'passed': bool(passed), **detail})

    def exact(name, expression):
        residual = sp.simplify(expression)
        record(name, residual == 0, residual=str(residual))

    def close(name, value, expected, tol=tolerance):
        error = abs(value - expected) / max(mp.mpf(1), abs(value), abs(expected))
        record(name, error <= tol, value=mp.nstr(value, 65),
               expected=mp.nstr(expected, 65), normalized_error=mp.nstr(error, 12))

    Q, beta, rho, S = sp.symbols('Q beta rho S', real=True, nonzero=True)
    grad, lap, Y1 = sp.symbols('grad lap Y1')
    # Euler-Lagrange variation; the gradient Hessian computes the kinetic factor.
    kinetic = -Q * grad**2
    euler = -2 * Q * Y1 + beta * (-rho + S) - sp.diff(kinetic, grad, 2) * lap
    lap_from_action = sp.solve(euler, lap)[0]
    exact('action_kinetic_normalization', scalar_source(beta, rho, S, Q) - (lap_from_action - Y1))
    exact('green_coefficient', scalar_source(beta, rho, S, Q) / (4 * sp.pi) - beta * (rho-S) / (8*sp.pi*Q))
    eps, dchi, Tbg, dT, dbeta, Y2 = sp.symbols('eps dchi Tbg dT dbeta Y2')
    rhs = Y1 + eps * Y2 * dchi - (beta + eps * dbeta*dchi)*(Tbg+eps*dT)/(2*Q)
    exact('ambient_linear_response_survives_subtraction', sp.diff(rhs, eps).subs(eps, 0) - (Y2*dchi-dbeta*Tbg*dchi/(2*Q)-beta*dT/(2*Q)))

    GE, energy, radius, A, MJ = sp.symbols('GE E r A MJ', positive=True)
    eta = sp.diag(-1, 1, 1, 1)
    hbar = sp.diag(4*GE*energy/radius, 0, 0, 0)
    htrace = sp.trace(eta*hbar)
    h = hbar - eta*htrace/2
    psi_e, phi_e = -h[0, 0]/2, -h[1, 1]/2
    chi = -beta*GE*energy/radius
    psi_j, phi_j = psi_e+beta*chi, physical_phi(phi_e, beta, chi)
    exact('metric_time_monopole', psi_e+GE*energy/radius)
    exact('metric_space_monopole', phi_e+GE*energy/radius)
    exact('conformal_time_sign', psi_j+GE*energy*(1+beta**2)/radius)
    exact('conformal_space_sign', phi_j+GE*energy*(1-beta**2)/radius)
    exact('gamma_ratio', phi_j/psi_j-(1-beta**2)/(1+beta**2))
    exact('physical_mass_radius_conversion', (GE*energy/radius).subs({energy:A*MJ, radius:radius/A})-physical_gravity(A, GE)*MJ/radius)
    exact('passive_uniform_gradient', beta*(-energy)-(-beta*energy))

    # Non-spherical, smooth, conserved stress: not the parent's radial profile.
    x, y, z = sp.symbols('x y z', real=True)
    xyz = (x, y, z)
    psi = sp.exp(-x*x-2*y*y-3*z*z)
    dpsi = sum(sp.diff(psi, v, 2) for v in xyz)
    tensor = sp.Matrix(3, 3, lambda i, j: (dpsi if i == j else 0)-sp.diff(psi, xyz[i], xyz[j]))
    for i in range(3):
        exact('anisotropic_gaussian_divergence_%s' % i, sum(sp.diff(tensor[i, j], xyz[j]) for j in range(3)))
    for i in range(3):
        for j in range(3):
            integrated = tensor[i, j]
            for v in xyz:
                integrated = sp.integrate(integrated, (v, -sp.oo, sp.oo))
            exact('anisotropic_Laue_%s_%s' % (i, j), integrated)

    t, p = sp.symbols('t p', real=True)
    ds_rho = 1+t*t/5
    ds_pr = p*(1-t*t)**3
    ds_pt = sp.expand(ds_pr+t*sp.diff(ds_pr, t)/2)
    ds_S = sp.expand(ds_pr+2*ds_pt)
    exact('distinct_profile_divergence', sp.diff(ds_pr, t)+2*(ds_pr-ds_pt)/t)
    exact('distinct_profile_center', (ds_pr-ds_pt).subs(t, 0))
    exact('distinct_profile_boundary_traction', ds_pr.subs(t, 1))
    exact('distinct_profile_Laue', sp.integrate(t*t*ds_S, (t, 0, 1)))
    exact('distinct_profile_weighted_virial', sp.integrate(t**4*(ds_S+2*ds_pr), (t, 0, 1)))
    exact('distinct_profile_mass', 4*sp.pi*sp.Rational(2, 7)*sp.Rational(3, 2)**3*sp.integrate(t*t*ds_rho, (t, 0, 1))-36*sp.pi/25)
    # Exact extrema of (1-v)^2(1-4v) are 1, -1/4, 0 on [0,1].
    v = sp.symbols('v', real=True)
    pt_shape = (1-v)**2*(1-4*v)
    exact('tangential_extremum_derivative', sp.diff(pt_shape, v).subs(v, sp.Rational(1, 2)))
    exact('tangential_extremum_value', pt_shape.subs(v, sp.Rational(1, 2))+sp.Rational(1, 4))
    record('complete_polynomial_source_admitted', complete_source(sp.Integer(0), sp.Integer(0)))
    record('incomplete_constant_pressure_rejected', not complete_source(sp.Integer(0), sp.Rational(1, 7)))
    # Sharp isotropic pressure has nonzero distributional traction and total S.
    exact('constant_pressure_missing_boundary', sp.integrate(3*sp.Rational(1, 7)*t*t, (t, 0, 1))-sp.Rational(1, 7))

    X = sp.symbols('X', positive=True)
    f = sp.sinh(X)/X
    exact('upper_weight_identity', f+X*sp.diff(f, X)-sp.cosh(X))
    exact('lower_weight_identity', f-X*sp.diff(f, X)-(2*f-sp.cosh(X)))
    for n in range(1, 13):
        coefficient = sp.Rational(2, sp.factorial(2*n+1))-sp.Rational(1, sp.factorial(2*n))
        exact('lower_weight_coefficient_%s' % n, coefficient-sp.Rational(1-2*n, sp.factorial(2*n+1)))
        record('lower_weight_negative_%s' % n, coefficient < 0)

    R, rho0 = mp.mpf(3)/2, mp.mpf(2)/7
    mass = 36*mp.pi/25
    pressures = [mp.mpf(-3)/5, mp.mpf(0), mp.mpf(3)/5]
    muRs = [mp.mpf(0), mp.mpf(1)/1000, mp.mpf(1)/5, mp.mpf(4)/3, mp.mpf(4)]

    def profile(r, amplitude):
        v = (r/R)**2
        density = rho0*(1+v/5)
        radial = amplitude*rho0*(1-v)**3
        tangential = amplitude*rho0*(1-v)**2*(1-4*v)
        return density, radial, tangential

    def quad_charge(mu, amplitude):
        def integrand(r):
            density, radial, tangential = profile(r, amplitude)
            return 4*mp.pi*r*r*fweight(mu*r)*trace_source(density, radial+2*tangential)
        return mp.quad(integrand, [0, R/2, R])

    def weighted_charge(mu, amplitude):
        def integrand(r):
            density, radial, _ = profile(r, amplitude)
            f = fweight(mu*r)
            return 4*mp.pi*r*r*(f*density+(mp.cosh(mu*r)-f)*radial)
        return mp.quad(integrand, [0, R/2, R])

    def exact_moment(n, amplitude):
        # Direct polynomial moment of the original rho-S, separate from runtime trace_source.
        B = mp.mpf(1)/(2*n+3)+mp.mpf(1)/(5*(2*n+5))
        C = mp.mpf(1)/(2*n+3)-mp.mpf(5)/(2*n+5)+mp.mpf(7)/(2*n+7)-mp.mpf(3)/(2*n+9)
        return 4*mp.pi*rho0*R**(2*n+3)*(B-3*amplitude*C)

    def series_charge(mu, amplitude):
        return mp.fsum(mu**(2*n)*exact_moment(n, amplitude)/mp.factorial(2*n+1) for n in range(100))

    rows = []
    for amplitude in pressures:
        for muR in muRs:
            mu = muR/R
            label = 'p%s_x%s' % (mp.nstr(amplitude, 8), mp.nstr(muR, 8))
            direct = quad_charge(mu, amplitude)
            weighted = weighted_charge(mu, amplitude)
            series = series_charge(mu, amplitude)
            close('weighted_trace_identity_'+label, direct, weighted)
            close('independent_polynomial_series_'+label, direct, series)
            lo, hi = 2*fweight(muR)-mp.cosh(muR), mp.cosh(muR)
            record('radius_enclosure_'+label, lo-tolerance <= direct/mass <= hi+tolerance,
                   charge_over_energy=mp.nstr(direct/mass, 65), lower=mp.nstr(lo, 65), upper=mp.nstr(hi, 65))
            if muR == 0:
                close('massless_pressure_independence_'+label, direct, mass)
            for rR in (mp.mpf(5)/4, mp.mpf(5)/2):
                distance = R*rR
                # Differentiate the exterior potential to test the force normalization.
                force = mp.diff(lambda rr: direct*mp.exp(-mu*rr)/rr, distance)
                expected = -direct*(1+mu*distance)*mp.exp(-mu*distance)/distance**2
                close('exterior_force_'+label+'_r'+mp.nstr(rR), force, expected)
            rows.append({'p':mp.nstr(amplitude, 8), 'mu_R':mp.nstr(muR, 65),
                         'energy':mp.nstr(mass, 65), 'Q':mp.nstr(direct, 65),
                         'Q_over_E':mp.nstr(direct/mass, 65), 'series_Q':mp.nstr(series, 65)})
        for muR in (mp.mpf(1)/100, mp.mpf(1)/200, mp.mpf(1)/400):
            mu = muR/R
            M2 = mp.quad(lambda r: 4*mp.pi*r**4*small_moment_source(*profile(r, amplitude)[:2]), [0, R])
            approximation = mass+mu**2*M2/6
            actual = quad_charge(mu, amplitude)
            # Triangle bound on integral |rho-S|, not cancellation-prone subtraction.
            abs_trace_bound = mass+3*abs(amplitude)*rho0*4*mp.pi*R**3/3
            remainder_bound = abs_trace_bound*muR**4*mp.cosh(muR)/120
            record('small_mass_remainder_p%s_x%s' % (mp.nstr(amplitude, 8), mp.nstr(muR, 8)),
                   abs(actual-approximation) <= remainder_bound,
                   actual_error=mp.nstr(abs(actual-approximation), 40), bound=mp.nstr(remainder_bound, 40))
    data['finite_range_rows'] = rows

    for muR in muRs[1:]:
        values = [quad_charge(muR/R, p) for p in pressures]
        record('same_mass_distinct_charges_'+mp.nstr(muR, 8), values[0] < values[1] < values[2],
               charges=[mp.nstr(v, 50) for v in values])
    density, radial, tangential = profile(mp.mpf(0), mp.mpf(3)/5)
    record('positive_density_can_have_negative_trace_source', density > 0 and density-radial-2*tangential < 0)
    negative_charge = quad_charge(mp.mpf(4)/R, mp.mpf(-20))
    record('conservation_and_density_alone_do_not_force_positive_charge', negative_charge < 0,
           charge_over_energy=mp.nstr(negative_charge/mass, 50), radial_energy_inequality_satisfied=False)

    angular_rows = []
    if not quick:
        for amplitude, muR, rR in [(pressures[0], mp.mpf(4)/3, mp.mpf(5)/4),
                                  (pressures[2], mp.mpf(4), mp.mpf(5)/2)]:
            mu, distance = muR/R, rR*R
            def shell(r):
                density, radial, tangential = profile(r, amplitude)
                source = density-radial-2*tangential
                def angular(cosine):
                    d = mp.sqrt(distance**2+r*r-2*distance*r*cosine)
                    return mp.exp(-mu*d)/d
                return 2*mp.pi*r*r*source*mp.quad(angular, [-1, 0, 1])
            direct_3d = mp.quad(shell, [0, R/2, R])
            reduced = quad_charge(mu, amplitude)*mp.exp(-mu*distance)/distance
            close('direct_angular_Green_p%s_x%s_r%s' % (mp.nstr(amplitude), mp.nstr(muR), mp.nstr(rR)),
                  direct_3d, reduced, mp.mpf('1e-45'))
            angular_rows.append({'p':mp.nstr(amplitude), 'mu_R':mp.nstr(muR, 50), 'r_R':mp.nstr(rR),
                                 'direct_3d':mp.nstr(direct_3d, 65), 'reduced':mp.nstr(reduced, 65)})
    data['direct_angular_rows'] = angular_rows
    data['precision_digits'] = mp.mp.dps
    data['quick'] = quick
    passed = sum(row['passed'] for row in checks)
    result = {'passed':passed, 'failed':len(checks)-passed, 'checks':checks, 'data':data}
    out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'passed':passed, 'failed':len(checks)-passed, 'output':str(out)}))
    return 0 if passed == len(checks) else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--quick', action='store_true')
    args = parser.parse_args()
    raise SystemExit(compute(args.output, args.quick))
