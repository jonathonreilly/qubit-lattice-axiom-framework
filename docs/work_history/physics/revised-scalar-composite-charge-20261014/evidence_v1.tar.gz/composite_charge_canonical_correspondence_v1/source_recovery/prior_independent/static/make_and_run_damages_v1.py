#!/usr/bin/env python3
"""Create and execute actual one-expression reviewer-source damages."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
base = root/'check_composite_v1.py'
text = base.read_text()
definitions = [
    ('kinetic_factor', 'return beta * (rho - stress) / (2 * Q)', 'return beta * (rho - stress) / Q', 'action_kinetic_normalization'),
    ('trace_sign', 'return rho - stress', 'return rho + stress', 'weighted_trace_identity_'),
    ('pressure_moment', 'return rho + 2 * pressure', 'return rho + pressure', 'small_mass_remainder_'),
    ('density_only', 'return rho - stress', 'return rho', 'same_mass_distinct_charges_'),
    ('omitted_traction', 'return interior_divergence == 0 and surface_traction == 0', 'return interior_divergence == 0', 'incomplete_constant_pressure_rejected'),
    ('Jordan_power', 'return A ** 2 * GE', 'return A * GE', 'physical_mass_radius_conversion'),
    ('spatial_conformal_sign', 'return phi_e - beta * chi', 'return phi_e + beta * chi', 'conformal_space_sign'),
]
damage_dir = root/'damages'
damage_dir.mkdir(exist_ok=False)
plan = {'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
        'positive_result_sha256':hashlib.sha256((root/'executions/positive_v1/RESULTS.json').read_bytes()).hexdigest(),
        'changes':[]}
for label, old, new, witness in definitions:
    assert text.count(old) == 1, (label, text.count(old))
    damaged = text.replace(old, new)
    path = damage_dir/(label+'.py')
    path.write_text(damaged)
    patch = ''.join(difflib.unified_diff(text.splitlines(True), damaged.splitlines(True), fromfile='check_composite_v1.py', tofile=path.name))
    (damage_dir/(label+'.diff')).write_text(patch)
    plan['changes'].append({'label':label, 'path':str(path.relative_to(root)),
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'old':old, 'new':new, 'required_failed_witness':witness})
(damage_dir/'PLAN_v1.json').write_text(json.dumps(plan, indent=2)+'\n')
summary = []
for row in plan['changes']:
    label = 'damage_'+row['label']
    argv = [sys.executable, str(root/'run_once.py'), label, row['path'], '--quick']
    run = subprocess.run(argv, cwd=root, capture_output=True)
    (damage_dir/(row['label']+'_orchestration_stdout.txt')).write_bytes(run.stdout)
    (damage_dir/(row['label']+'_orchestration_stderr.txt')).write_bytes(run.stderr)
    result = json.loads((root/'executions'/label/'RESULTS.json').read_text())
    execution = json.loads((root/'executions'/label/'EXECUTION.json').read_text())
    failed = [r['name'] for r in result['checks'] if not r['passed']]
    witness_failed = any(n.startswith(row['required_failed_witness']) for n in failed)
    record = {'label':row['label'], 'argv':argv, 'orchestration_exit_code':run.returncode,
              'actual_exit_code':execution['exit_code'], 'passed':result['passed'], 'failed':result['failed'],
              'failed_checks':failed, 'required_witness_failed':witness_failed,
              'all_fresh_inputs_unchanged':execution['all_inputs_unchanged'],
              'fresh_input_count':len(execution['inputs_before']),
              'result_sha256':hashlib.sha256((root/'executions'/label/'RESULTS.json').read_bytes()).hexdigest()}
    summary.append(record)
    print(json.dumps(record), flush=True)
(damage_dir/'SUMMARY_v1.json').write_text(json.dumps({'damages':summary, 'all_detected':all(r['actual_exit_code']==1 and r['required_witness_failed'] for r in summary)}, indent=2)+'\n')
