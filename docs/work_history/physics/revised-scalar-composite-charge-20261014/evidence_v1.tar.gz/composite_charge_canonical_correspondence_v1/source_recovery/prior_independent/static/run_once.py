#!/usr/bin/env python3
"""Record a real reviewer-owned execution with fresh full input identities."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label, source_name = sys.argv[1:3]
run = root/'executions'/label
run.mkdir(parents=True, exist_ok=False)
source = (root/source_name).resolve()
inputs = [source, root/'INDEPENDENT_PROTOCOL_v1.json', root/'INDEPENDENT_DERIVATION_v1.md', Path(__file__).resolve()]
for freeze in ['FREEZE_v1.json', 'ACTION_FREEZE_v1.json', 'AFFECTED_SOURCE_FREEZE_v2.json', 'AFFECTED_SOURCE_FREEZE_v3.json']:
    for row in json.loads((root/freeze).read_text())['sources']:
        inputs.extend([Path(row['original_path']), root/row['snapshot_path']])
inputs = sorted(set(inputs), key=str)

def identities():
    return [{'path':str(p), 'bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs]

before = identities()
argv = [sys.executable, str(source), '--output', str(run/'RESULTS.json'), *sys.argv[3:]]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
(run/'FREEZE.json').write_text(json.dumps({'start':start, 'argv':argv, 'cwd':str(root), 'inputs':before}, indent=2)+'\n')
t0 = time.monotonic()
try:
    result = subprocess.run(argv, cwd=root, capture_output=True, timeout=180, env=None)
    code, stdout, stderr, failure = result.returncode, result.stdout, result.stderr, None
except subprocess.TimeoutExpired as e:
    code, stdout, stderr, failure = None, e.stdout or b'', e.stderr or b'', 'timeout_180_seconds'
(run/'stdout.txt').write_bytes(stdout)
(run/'stderr.txt').write_bytes(stderr)
after = identities()
record = {'start':start, 'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'elapsed_seconds':time.monotonic()-t0, 'argv':argv, 'cwd':str(root),
          'exit_code':code, 'execution_failure':failure, 'inputs_before':before,
          'inputs_after':after, 'all_inputs_unchanged':before == after,
          'streams':{k:hashlib.sha256((run/k).read_bytes()).hexdigest() for k in ['stdout.txt', 'stderr.txt']}}
if (run/'RESULTS.json').exists():
    record['result_sha256'] = hashlib.sha256((run/'RESULTS.json').read_bytes()).hexdigest()
(run/'EXECUTION.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({'label':label, 'exit_code':code, 'elapsed_seconds':record['elapsed_seconds'], 'inputs':len(before), 'unchanged':before == after}))
print(stdout.decode(errors='replace'), end='')
if stderr:
    print(stderr.decode(errors='replace'), file=sys.stderr, end='')
