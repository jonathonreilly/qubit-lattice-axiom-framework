#!/usr/bin/env python3
"""Create one final immutable evidence inventory and source disposition."""
import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    p = root/name
    assert not p.exists(), name
    p.write_text(json.dumps(value, indent=2)+'\n')

freezes = ['FREEZE_v1.json', 'ACTION_FREEZE_v1.json', 'AFFECTED_SOURCE_FREEZE_v2.json', 'AFFECTED_SOURCE_FREEZE_v3.json']
source_rows = [row for name in freezes for row in json.loads((root/name).read_text())['sources']]
current_note = root.parent/'DERIVATION_v3.md'
dispositions = []
for row in source_rows:
    original, snapshot = Path(row['original_path']), root/row['snapshot_path']
    assert digest(original) == digest(snapshot) == row['sha256'], row
    old_note = original.name in ('DERIVATION_v1.md', 'DERIVATION_v2.md')
    final = current_note if old_note else original
    disposition = 'historical_scope_superseded_by_v3_preserved_exactly' if old_note else 'read_complete_unchanged_and_preserved'
    dispositions.append({'original_path':str(original), 'original_sha256':row['sha256'],
                         'disposition':disposition, 'recovery':str(snapshot),
                         'recovery_sha256':digest(snapshot), 'final_path':str(final), 'final_sha256':digest(final)})
write('SOURCE_DISPOSITIONS_v1.json', {'original_dispositions':dispositions,
      'scope':'Nine exact named source/metadata files; supplied action read, no author code/results.'})

positive = json.loads((root/'executions/positive_v1/RESULTS.json').read_text())
assert positive['passed'] == 154 and positive['failed'] == 0
assert len(positive['checks']) == len({r['name'] for r in positive['checks']})
damage_summary = json.loads((root/'damages/SUMMARY_v1.json').read_text())
assert damage_summary['all_detected'] and len(damage_summary['damages']) == 7
executions = []
for path in sorted((root/'executions').glob('*/EXECUTION.json')):
    record = json.loads(path.read_text())
    assert record['all_inputs_unchanged']
    assert record['inputs_before'] == record['inputs_after']
    for row in record['inputs_before']:
        assert digest(Path(row['path'])) == row['sha256']
    output = path.parent/'RESULTS.json'
    assert digest(output) == record['result_sha256']
    for name, value in record['streams'].items():
        assert digest(path.parent/name) == value
    executions.append({'path':str(path.relative_to(root)), 'sha256':digest(path),
                       'argv':record['argv'], 'cwd':record['cwd'], 'exit_code':record['exit_code'],
                       'result_sha256':digest(output), 'start':record['start'], 'end':record['end'],
                       'input_count':len(record['inputs_before'])})
assert len(executions) == 8
write('COMMAND_INDEX_v1.json', {'actual_scientific_executions':executions,
      'orchestration_commands':['python3 run_once.py positive_v1 check_composite_v1.py',
                               'python3 make_and_run_damages_v1.py', 'python3 seal_v1.py'],
      'read_only_scope':'Only explicitly named parent source files were read; no producer runner/output or broad source-prefix enumeration.',
      'no_producer_scientific_execution':True})

# The four freeze files select provenance paths; the mathematical checker does
# not read them. Record their final identities and reconstruct every selected
# source/snapshot path against the actual per-run fresh identities.
reconciliation = []
for name in freezes:
    p = root/name
    rows = json.loads(p.read_text())['sources']
    for source in rows:
        assert digest(Path(source['original_path'])) == source['sha256']
        assert digest(root/source['snapshot_path']) == source['sha256']
    reconciliation.append({'path':name, 'sha256':digest(p), 'selection_rows':len(rows),
                           'role':'Provenance selection metadata, not a mathematical oracle',
                           'per_run_hash_status':'The selected source and snapshot bytes were freshly hashed pre/post each run; this selector file is bound by the final manifest.'})
write('EXECUTION_METADATA_RECONCILIATION_v1.json', {'freeze_metadata':reconciliation,
      'all_selected_original_and_snapshot_hashes_match_actual_execution_records':True})

summary = {'independent_positive':{'passed':154, 'failed':0, 'finite_range_rows':15,
            'direct_angular_integrals':2, 'small_mass_remainder_checks':9},
           'actual_damages':[{k:r[k] for k in ['label','passed','failed','actual_exit_code','required_witness_failed']} for r in damage_summary['damages']],
           'current_parent_note_sha256':digest(current_note), 'source_pairs':len(dispositions),
           'unresolved_material_mathematical_findings_within_v3_scope':[],
           'historical_finding':'v1/v2 lacked explicit negligible ambient linear matter response; repaired by preserved v3.',
           'parent_implementation_or_results_read':False, 'formal_audit':False}
write('FINAL_SUMMARY_v1.json', summary)

manifest = []
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name not in ('MANIFEST_v1.json', 'RECEIPT_v1.json'):
        assert not p.is_symlink()
        manifest.append({'path':str(p.relative_to(root)), 'bytes':p.stat().st_size, 'sha256':digest(p)})
write('MANIFEST_v1.json', {'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'scope':'All reviewer-owned files except manifest and receipt (acyclic seal)',
      'artifact_count':len(manifest), 'artifacts':manifest})
receipt = {'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'role':'Focused independent mathematical source review; not an audit or physical acceptance',
           'report':{'path':'REPORT_v1.md','sha256':digest(root/'REPORT_v1.md')},
           'manifest':{'path':'MANIFEST_v1.json','sha256':digest(root/'MANIFEST_v1.json')},
           'source_dispositions':{'path':'SOURCE_DISPOSITIONS_v1.json','sha256':digest(root/'SOURCE_DISPOSITIONS_v1.json')},
           'artifact_count':len(manifest), 'source_pair_count':len(dispositions),
           'final_parent_source':{'path':str(current_note),'sha256':digest(current_note)},
           'summary':summary, 'no_self_hash_cycle':True}
write('RECEIPT_v1.json', receipt)
for row in manifest:
    assert digest(root/row['path']) == row['sha256']
for key in ['report','manifest','source_dispositions']:
    assert digest(root/receipt[key]['path']) == receipt[key]['sha256']
print(json.dumps({'artifacts':len(manifest),'source_pairs':len(dispositions),
      'hashes':{name:digest(root/name) for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json','SOURCE_DISPOSITIONS_v1.json']}},indent=2))
