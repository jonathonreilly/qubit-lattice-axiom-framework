from pathlib import Path
from contextlib import redirect_stdout
from tempfile import TemporaryDirectory
import argparse, hashlib, io, json, os

def stub(out, name):
    out.mkdir(parents=True, exist_ok=False)
    case = os.environ['WRAPPER_FIXTURE']
    failed = (1 if name == 'static' else 2) if case == 'both_fail' else int(case == name + '_fail')
    if case == 'missing_result' and name == 'static':
        return 0
    result = dict(passed=2 if name == 'static' else 3, failed=failed, label=name)
    (out / 'RESULTS.json').write_text(json.dumps(result) + '\n')
    print('synthetic-' + name)
    return 1 if case == 'return_mismatch' and name == 'static' else failed

def check_static(out):
    return stub(out, 'static')

def check_dynamic(out):
    return stub(out, 'dynamic')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profiles', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()

    def execute(root):
        root.mkdir(parents=True, exist_ok=True)
        units = {}
        streams = {}
        for name, fn in [('static', check_static)]:
            captured = io.StringIO()
            with redirect_stdout(captured):
                failed = fn(root / name)
            result = json.loads((root / name / 'RESULTS.json').read_text())
            assert failed == result['failed']
            units[name] = result
            streams[name] = captured.getvalue()
        return dict(passed=sum((z['passed'] for z in units.values())), failed=sum((z['failed'] for z in units.values())), units=units, unit_stdout=streams, checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), scope='Conditional complete-body scalar charge and finite-window source amplitude; no selected matter or homogeneous wave, full metric, ambient response or empirical likelihood.')
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-composite-charge-') as d:
            result = execute(Path(d))
    else:
        assert not args.profiles.exists()
        result = execute(args.profiles)
    text = json.dumps(result, indent=2) + '\n'
    if args.out:
        assert not args.out.exists()
        args.out.write_text(text)
    print(text, end='')
    return bool(result['failed'])
if __name__ == '__main__':
    raise SystemExit(main())
