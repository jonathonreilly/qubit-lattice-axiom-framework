from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime,argparse
ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,required=True);args=ap.parse_args();cfg=json.loads(args.config.read_text());wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/cfg['pack'];dest=wt/cfg['destination'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (pack/'CACHE_RUN_v1.json').is_file()
for rel in cfg['seals']:
 for name in ['MANIFEST_v1.json','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True);items=[]
for rel in cfg['roots']:
 for p in sorted((pk/rel).rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink()
  if '__pycache__' in p.parts or p.suffix=='.pyc' or p.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((p.relative_to(pk).as_posix(),p.read_bytes()))
assert len(items)==len({n for n,b in items})
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items];manifest={'schema':'campaign-recovery-manifest-v1','artifact_count':len(rows),'source_roots':cfg['roots'],'scope':cfg['scope'],'payloads':rows,'counts_are_not_new_science':True,'exclusions':['Python bytecode and later archive-own-hash build record']};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    ti=tarfile.TarInfo(n);ti.mode=0o644;ti.size=len(b);ti.mtime=0;tar.addfile(ti,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(rows)+1
 for row in rows:
  info=tar.getmember(row['path']);assert info.isfile();b=tar.extractfile(info).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(rows)+1,'manifest_sha256':hashlib.sha256(mb).hexdigest(),'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(rec,indent=2)+'\n')
refs=[]
for rel in cfg['seals']:
 for name in ['REPORT_v1.md','REPORT_v2.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  f=pk/rel/name
  if f.exists():refs.append(rel+'/'+name+' SHA256 '+sha(f))
readme=cfg['readme']+'\n\nArchive SHA256: '+rec['archive_sha256']+'\nArchive bytes: '+str(rec['archive_bytes'])+'\nPayloads: '+str(rec['payloads'])+' plus RECOVERY_MANIFEST_v1.json\nManifest SHA256: '+rec['manifest_sha256']+'\n\n'+'\n'.join(refs)+'\n\nSafe recovery: regular relative members only; verify all manifest hashes and sizes. Later build/commit/delivery/UNIT records are external.\n';(dest/'README.txt').write_text(readme);print(json.dumps(rec))
