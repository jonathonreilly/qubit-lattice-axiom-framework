from pathlib import Path
import argparse,json,hashlib,subprocess,datetime,shutil,sys,base64,zlib
ap=argparse.ArgumentParser();ap.add_argument('--slug',required=True);ap.add_argument('--branch',required=True);ap.add_argument('--base',required=True);ap.add_argument('--passed',type=int,required=True);a=ap.parse_args()
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/(a.slug+'_packaging');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda *x:subprocess.check_output(['git',*x],cwd=wt,text=True).strip()
assert git('rev-parse','HEAD')==a.base;assert not git('diff','--name-only','HEAD');assert (pk/(a.slug+'_canonical_correspondence_v1')/'RECEIPT_v1.json').is_file()
subprocess.run(['git','switch','-c',a.branch],check=True,cwd=wt)
note=next((pack/'formatted_v2').glob('*.md'));runner=pack/'staged'/('exponential_scalar_'+a.slug+'_check.py');nd=wt/'docs'/note.name;rd=wt/'scripts'/runner.name
assert not nd.exists() and not rd.exists();shutil.copyfile(note,nd);shutil.copyfile(runner,rd);assert sha(nd)==sha(note) and sha(rd)==sha(runner)
shutil.copyfile(Path(__file__),pack/'install_cache_milestone_v1.py');shutil.copyfile(Path(__file__).with_name('build_science_archive_v1.py'),pack/'build_science_archive_v1.py')
(pack/'INSTALL_v1.json').write_text(json.dumps({'at':now(),'base':a.base,'branch':a.branch,'note':str(nd.relative_to(wt)),'note_sha256':sha(nd),'runner':str(rd.relative_to(wt)),'runner_sha256':sha(rd)},indent=2)+'\n')
sys.path.insert(0,str(wt/'scripts'));import runner_cache as rc
rel=rd.relative_to(wt).as_posix();start=now();pre=rc.capture_runner_execution_identity(rel)
(pack/'CACHE_STARTED_v1.json').write_text(json.dumps({'started_at':start,'runner':rel,'timeout_sec':120,'pre_execution_identity_repr':repr(pre),'method':'runner_cache.execute_and_write_cache'},indent=2)+'\n')
r,cache=rc.execute_and_write_cache(rel,timeout_sec=120);post=rc.capture_runner_execution_identity(rel)
(pack/'CACHE_EXECUTION_v1.json').write_text(json.dumps(r,indent=2)+'\n');(pack/'CACHE_stdout_v1.txt').write_text(r.get('stdout',''));(pack/'CACHE_stderr_v1.txt').write_text(r.get('stderr',''))
assert pre==post and pre is not None;assert r['status']=='ok' and r['exit_code']==0 and cache is not None
stream=r['stdout'];out=json.loads(stream[stream.index('{'):]);stage=json.loads((pack/'STAGED_RESULTS_v1.json').read_text());assert out==stage,'Complete canonical output differs from stage'
assert out['passed']==a.passed and out['failed']==0;assert len(stream)<=200000;assert stream in cache.read_text();assert rc.cache_status(rel)=='fresh'
if 'complete_unit_payload' in out:
 c=out['complete_unit_payload'];raw=zlib.decompress(base64.b64decode(c['data']));assert len(raw)==c['uncompressed_bytes'] and hashlib.sha256(raw).hexdigest()==c['sha256'];unit=json.loads(raw);(pack/'CACHE_DECODED_UNIT_v1.json').write_text(json.dumps(unit,indent=2)+'\n')
(pack/'CACHE_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n');rec={'started_at':start,'ended_at':now(),'runner':rel,'cache':str(cache.relative_to(wt)),'cache_sha256':sha(cache),'passed':out['passed'],'failed':out['failed'],'stdout_chars':len(stream),'complete_JSON_equal_stage':True,'full_untruncated_stream_in_cache':True,'pre_execution_identity_repr':repr(pre),'post_execution_identity_repr':repr(post),'cache_status':'fresh'};(pack/'CACHE_RUN_v1.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if not k.endswith('_repr')}))
