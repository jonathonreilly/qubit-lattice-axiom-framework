# Canonical curvature milestone: focused source correspondence

The final canonical note, unchanged runner and refreshed cache correspond to the original curvature derivation and the separately sealed independent mathematics check. One narrow source correction was needed: the original canonical decimal upper bound rounded downward in its last digits. The final note now uses the rigorously outward value `r<=2.24327520666367e-6 (rounded outward)`. No mathematical equation changed. No further source correction is identified.

This review concerns source and evidence correspondence, not landing authority or a formal audit. Scientific authorship remains with /root. I did not execute the producer runner or repeat the separate curvature science. The independent mathematics report and hand derivation were read in full and reused by exact identity only after their seal existed.

## Final bytes and reused mathematics

| Final artifact | SHA-256 |
| --- | --- |
| Canonical curvature note | eb42e84185053ee6f51b6ed4700b20bf7d981a0366270f8d1a3ed71281e3760d |
| Canonical curvature runner | c886153bb98ba00f7b2772ab8b44f7dbdfa55bfe4dda8d3b197160a1020449bd |
| Final runner cache | 9f0e8c2c854af14a05278ee1c3406ba854cbf08e876e758294f7ee05f767fa1d |
| Original curvature derivation | 1d3dee4047738e1a8c724b3a99600c191c567f94473bdc29d8d8600c17c1b4dd |
| Full supplied action note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| Declared flat radiation-duration note | c6751e952b5d645f6505ad160c8da8f08b0e01cdf36a3aecc08ac117741dcc08 |

The separate original-mathematics check is by /root/local_response_check, in `initial_state/curvature_loophole_v1/independent_v1`:

| Reused artifact | SHA-256 |
| --- | --- |
| Receipt | cfb2bc28f32e632ea671f9d750ee60da79e9c368cc31215407e55046b090bded |
| Report | d9107fd68eb09178678b9532a121ed7bce2c784f542d8a1078ca5c9beb2d7386 |
| Manifest | 854a7cd9f183ca0705847932cff257143b31c68fc951ddbe89b16446b4ca0e48 |

I verified all 60 manifest artifacts, the exact 62-file inventory, both live/source pairs, and the receipt's selected artifact bindings without altering or rerunning them. The complete report, handwritten derivation, protocol, primary-attribution receipt and failure ledger were read. Selected immutable snapshots and the full identity-verification record are included here. That review reports 107/0 and five actual damaged-formula rejections, with no baseline failure or checker repair. Those are reused science results, not new results of this packaging check.

The initial 34 source/evidence files were frozen before the precision correction. Supplemental snapshots preserve the corrected note/cache, correction records, prior note/cache recovery copies and selected independent seal files. The cache utility was inspected only for its input-fingerprint and parsing algorithm; it was not imported or executed. Final bindings distinguish current files from the two superseded canonical snapshots, whose byte-identical parent recovery copies remain available.

## Claim-by-claim correspondence

`CLAIM_CORRESPONDENCE_v1.json` records fifteen claim groups and their support/limits. The complete original mathematics text is carried into the canonical note, with only the added curvature-convention/numerical paragraph, metadata/dependency introduction and verification/empirical-separation section. All displayed equations are unchanged. The later precision correction changes just one prose line.

The supplied action is used as a covariant definition, not as an import of the earlier theorem's spatially flat conclusion. With the stated parameter domain, the origin has a regular positive kinetic metric, C=1, U=3/2 and vanishing potential gradient. Radiation is trace free, so the scalar remains there; traceful dust generally would not. The physical vacuum density is 3Qh² and the radiation density is 3QD²/a⁴. Thus physical and Einstein clocks coincide for this explicitly chosen state. The action, scales, geometry and matter/state choices remain assumptions.

The closed constraint is H²=h²+D²/a⁴-Kc/a². The independent review derives it and the scale equation by varying the lapse and scale factor, including the radiation fixed-charge term. This matters at the bounce: dividing a differentiated squared constraint by H is not a valid substitute there. The negative curvature term is geometric, not negative radiation or a kinetic ghost. It invalidates the flat theorem's lower bound while leaving that theorem intact on its stated flat domain.

For positive D and strict Delta=Kc²-4h²D²>0, the physical domain has 0<sqrt(Delta)<Kc. The large-X cosh branch is regular at Xplus, whereas the separate small-X branch reaches zero at finite times. The canonical note preserves that branch distinction. The positive symbols used in the producer CAS do not by themselves impose every physical domain inequality; the hand proof and independent classification supply that scope.

The Ricci and Kretschmann expressions preserve the closed spatial-curvature contribution. The separate review explicitly contracts the orthonormal Riemann tensor and verifies Ricci=12h² and Kretschmann=24(h⁴+D⁴/X⁴). Finite Ricci alone does not certify a regular endpoint. The regular upper branch bounds the latter invariant; the positive-radiation lower zero-X endpoints do not.

The causal-completeness claim has the required complete S³ spatial section, smooth all-real-time metric and positive global radius lower bound. The independent proof derives conserved spatial momentum magnitude without assuming constant coordinate components on S³. It verifies both affine/proper rates and supplies the finite-time extension argument using smooth coefficients, bounded momentum and the complete spatial section. The canonical source's general argument is therefore supported beyond its finite sample checks. It does not prove inhomogeneous, nonlinear or quantum stability.

The critical static solution and the nonstatic upper exponential are distinct. The latter is expanding at every finite time and asymptotes to the positive static radius in the past. A fixed-time Delta->0 limit of the cosh formula is only static. The growing scale perturbation and constraint restrictions do not give unrestricted homogeneous attraction. Negative-discriminant and lower branches can be singular; D=0 gives closed de Sitter outside the strict radiation premise. These statements match the sealed review.

At a finite expanding upper-branch event, L+r-d=1 and d²>=4Lr combine with L>r to select the smaller-r root. The independent proof supplies the general increasing bound and its small-d expansion; it also exhibits a lower-branch violation if the branch hypothesis is removed. H-normalized fractions are undefined at a bounce, as the canonical verification section now explicitly says. The energy-density ratio is the appropriate no-radiation-dominance quantity. It is strictly below one on the strict upper branch and at every finite time on the nonstatic critical upper branch; the exactly static critical solution has equality. This is not a radiation-dominated hot history.

The source's new convention `d=-Omega_K` is correct for Kc>0 in the stated natural units: Omega_K=-Kc/(a0²H0²). The selected positive-curvature branch occupies negative Omega_K. The illustrative d bound is not a claim about the mean or confidence level of the quoted Planck posterior.

The Planck numbers and model qualifications are unchanged from the original source. The separate independent reviewer checked the named primary version's Eq.45b and Table4. This packaging review reuses that report and its factual access receipt; it does not claim fresh remote verification or a hash of the full primary paper. The receipt explicitly records that limitation. No likelihood, observed density calibration, raw data, held-out empirical test or survey fit enters this check.

## Runner and cache correspondence

The canonical runner differs from `check_curvature_v1.py` only by imports/output argument handling, a temporary default output destination, timeout/input declarations, and printing the full result JSON. I compared the complete mathematical block from `checks=[]` through result construction byte-for-byte and checked that the complete source change equals exactly the recorded wrapper/output diff. No mathematical target or tolerance was changed during canonicalization.

The actual implemented U and C at the origin match the supplied action expressions. The runner checks both Friedmann equations, conservation, acceleration, branch profiles, invariants, roots and finite endpoints, fraction algebra and sample bounds. Its three synthetic parameter choices remain mathematical controls. The general completeness/domain result comes from the hand proof, not merely the recorded successful booleans.

Some evidence limits remain explicit: `fraction_monotone` evaluates a derivative at the illustrative d value rather than proving general monotonicity by itself; the separate hand proof does give the general sign. The finite completeness examples check positive lower-bound coefficients, not all geodesics. The illustrative float-value assertion uses an absolute tolerance of 1e-13 against a coarse reference; it is not an independent certificate of every printed decimal digit. None of these limits is hidden by the canonical source's separation of exact proof, finite controls and observations.

The original direct result, original canonical result and final canonical cache all have the same 81 check entries and mathematical result payload. The original direct output differs only in its self-reported checker hash. The canonical runner hash is unchanged between cache runs.

I independently recomputed the cache input fingerprint from the ordered declared paths and their exact bytes, using the documented length-prefixed v1 digest construction. The final fingerprint includes the corrected note, full action note and flat-radiation-duration note. It matches the cache header; the runner hash, success status, empty stderr, counts, elapsed-time rounding and recorded stdout also match. Cache pinning is a byte identity condition, not automatic semantic verification of the prose; that comparison was performed separately above.

The author actually reran the unchanged canonical 81/0 calculation to refresh the cache after the declared note input changed. `CACHE_RUN_v2.json` discloses that rerun. I did not execute it and do not call it a new independent science check. The prior note/cache and v1 cache-run evidence remain preserved.

## Actual changed implementations

The original direct suite executed three altered source copies. Their byte changes, protocol replacements, code hashes, result self-hashes, execution records, failed check lists and stdout failure lines agree:

| Original direct damaged copy | Preserved result | Decisive failure |
| --- | --- | --- |
| Wrong bounce frequency | 74/7, exit 1 | Large-branch Friedmann residual |
| Wrong critical exponential rate | 76/5, exit 1 | Critical-branch Friedmann residual |
| Wrong fraction square-root coefficient | 77/4, exit 1 | Fraction discriminant residual -d |

These were actual direct-checker executions. I do not relabel them as newly executed canonical-wrapper damages. Their mathematical block and assertions are exactly the block carried into the canonical runner, so that tested source correspondence is explicit.

The separate independent mathematics report preserves five different actual damages: curvature sign, critical rate, Riemann spatial curvature, fraction root and null-affine power. Their counts and intended failures are bound by the verified independent receipt. Those remain separate from the producer's three controls and from this correspondence's metadata/arithmetic checks.

## Precision finding and preserved verifier repair

The exact critical boundary at d=3/1000 is

    f=(1003/1000-sqrt(503/500))/2
     =0.00000224327520666366184635569953767847021715475177...

The v1 canonical note printed the literal bound `r<=2.24327520666366e-6`. That decimal is below f by approximately 1.8463556995e-21. Equality at the exact boundary is possible on the allowed critical upper branch, so even a last-digit inward rounding is not a valid literal universal upper bound.

This was checked with exact rational arithmetic, not just decimal sampling. For a candidate b with 1+d-2b>0,

    b>=f(d) iff (1+d-2b)^2 <= 1+2d.

The old decimal has positive squared gap

    4629716207170911489 / 625000000000000000000000000000000000000.

The corrected outward decimal has negative squared gap

    -81780686516275021311 / 2500000000000000000000000000000000000000.

It therefore is a strict rational upper bound. The author changed only this prose value and added “rounded outward.” The canonical equations and producer runner were untouched. The number is an algebraic benchmark, with no observational significance assigned to its precision.

The first correspondence execution completed 47/2. One failure was the real source inequality issue above. The other was my own assertion error: I tested a correctly rounded 24-significant-digit cached decimal with a text-prefix comparison against an 80-digit expansion. Rounding legitimately changes the trailing digit. A separate one-check repair used Decimal quantization at the supplied exponent and passed 1/0; the cached value was correct throughout. The failed source, stdout/stderr, full result and repair code/results remain immutable.

After the author's correction and independent science seal were available, the narrow final correspondence execution passed 42/0. It checks the one-line correction, rational bound, unchanged equations/runner, preserved old note/cache, refreshed cache identity and reused independent evidence. The honest lineage is therefore **47/2, then a separate 1/0 verifier repair, then 42/0 affected correspondence**, not a clean replacement of the initial run. These counts are source/metadata/arithmetic controls and are not additional curvature physics tests.

## Remaining scope

The final note consistently retains the supplied action, positive parameter/curvature domain, complete S³, radiation-only origin state and discriminant/branch choices as hypotheses. It does not select a cosmic initial state, derive the geometry or dimensional hierarchy, produce an observed hot-universe history, establish stability, or apply a model likelihood. The result is a regular-history counterexample to overextending the flat theorem, not a contradiction of that theorem within its flat premises.

The metadata says proposed_retained while explicitly displaying actual conditional-support status. This correspondence neither assigns a grade nor approves landing, merging or publishing. No parent science/source, previous seal, Git, PR, runtime, lock or authority state was changed. All writes are confined to this new canonical correspondence directory.
