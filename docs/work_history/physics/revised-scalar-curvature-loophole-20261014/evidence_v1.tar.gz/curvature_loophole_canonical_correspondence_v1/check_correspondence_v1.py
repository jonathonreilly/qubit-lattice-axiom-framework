from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import ast,datetime,difflib,hashlib,json,platform,sys
ROOT=Path(__file__).resolve().parent
SOURCES=ROOT/'sources'
OUT=ROOT/'correspondence_v1'
OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
def read(rel):return (SOURCES/rel).read_text()
def obj(rel):return json.loads(read(rel))
orig=read('direct/check_curvature_v1.py');canon=read('canonical_v1/RUNNER.py')
core=lambda x:x.split('checks=[]\n',1)[1].split('OUT.parent.mkdir',1)[0]
check('runner.mathematical_block_byte_identical',core(orig)==core(canon),{'direct_core_sha256':sha(core(orig).encode()),'canonical_core_sha256':sha(core(canon).encode())})
check('runner.expected_wrapper_only_diff',canon==orig.replace('import sys,json,hashlib\n','import sys,json,hashlib,argparse,tempfile\n').replace("OUT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'RESULTS_v1.json'", "AUDIT_TIMEOUT_SEC = 120\nAUDIT_INPUT_PATHS = [\n    'docs/EXPONENTIAL_SCALAR_CURVATURE_LOOPHOLE_BOUNDED_THEOREM_NOTE_2026-10-14.md',\n    'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md',\n    'docs/EXPONENTIAL_SCALAR_RADIATION_PAST_BOUND_BOUNDED_THEOREM_NOTE_2026-10-14.md',\n]\n_ap=argparse.ArgumentParser();_ap.add_argument('--output');_args=_ap.parse_args()\n_tmp=tempfile.TemporaryDirectory(prefix='scalar-curvature-') if _args.output is None else None\nOUT=Path(_args.output) if _args.output else Path(_tmp.name)/'RESULTS.json'").replace("print(json.dumps({'passed':result['passed'],'failed':result['failed'],'r_limit':str(fnum),'output':str(OUT)}))","print(json.dumps(result,indent=2))"))
relorig='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state/curvature_loophole_v1/check_curvature_v1.py'
reldest='scripts/exponential_scalar_curvature_loophole_check.py'
diff=''.join(difflib.unified_diff(orig.splitlines(True),canon.splitlines(True),fromfile=relorig,tofile=reldest))
check('runner.recorded_diff_exact',diff==read('packaging_v1/PRIMARY_CORRESPONDENCE_v1.diff'))
(OUT/'RUNNER_CORRESPONDENCE.diff').write_text(diff)
source=read('direct/DERIVATION_v1.md');note=read('canonical_v1/NOTE.md')
(OUT/'NOTE_CORRESPONDENCE.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),note.splitlines(True),fromfile='direct/DERIVATION_v1.md',tofile='canonical_v1/NOTE.md')))
# The mathematical body matches after the sole intended fractional-readout prose update.
start='Direct reconstruction by /root'
mainbody=note[note.index(start):].split('\n## Verification and empirical separation',1)[0]
old='the best-fit LambdaCDM fractions in the Planck paper. For a purely illustrative\nd<=0.003, equation(5) requires r<=about2.2433e-6. This number is a conditional'
new='the best-fit LambdaCDM fractions in the Planck paper. With the usual curvature\nconvention d=-Omega_K, this branch has negative Omega_K. For a purely illustrative\nd<=0.003, equation(5) requires r<=2.24327520666366e-6. This number is a conditional'
check('note.original_body_only_expected_prose_change',mainbody.rstrip()==source[source.index(start):].replace(old,new).rstrip())
check('note.displayed_equations_unchanged',[x for x in note.splitlines() if x.startswith('    ')]==[x for x in source.splitlines() if x.startswith('    ')])
check('note.general_completeness_not_sample_inference','finite sample checks alone would not prove it' in note)
check('note.H_normalization_qualification','H-normalized\nfractions diverge at a bounce' in note)
check('note.conditional_surface','**Actual current surface status:** conditional-support' in note)

cache=read('canonical_v1/CACHE.txt')
head,tail=cache.split('----- stdout -----\n',1)
stdout,stderr=tail.split('\n----- stderr -----\n',1)
header={}
for line in head.splitlines():
 if ': ' in line:
  key,value=line.split(': ',1);header[key]=value
payload=json.loads(stdout)
check('cache.runner_path',header['runner']==reldest)
check('cache.runner_sha256',header['runner_sha256']==sha(canon.encode()))
check('cache.success_status',header['status']=='ok' and header['exit_code']=='0' and header['timeout_sec']=='120')
check('cache.stderr_empty',not stderr.strip())
tree=ast.parse(canon)
paths=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
expected_paths=['docs/EXPONENTIAL_SCALAR_CURVATURE_LOOPHOLE_BOUNDED_THEOREM_NOTE_2026-10-14.md','docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_RADIATION_PAST_BOUND_BOUNDED_THEOREM_NOTE_2026-10-14.md']
check('cache.declared_inputs',paths==expected_paths)
source_files=['canonical_v1/NOTE.md','inputs/FULL_ACTION.md','inputs/FLAT_RADIATION_BOUND.md']
h=hashlib.sha256();h.update(b'runner-cache-input-fingerprint-v1\0')
for rel,local in zip(paths,source_files):
 p=rel.encode();body=(SOURCES/local).read_bytes()
 h.update(len(p).to_bytes(8,'big'));h.update(p);h.update(len(body).to_bytes(8,'big'));h.update(body)
check('cache.fingerprint',header['input_fingerprint_sha256']==h.hexdigest(),h.hexdigest())
command=obj('packaging_v1/CACHE_COMMAND_v1.json');run=obj('packaging_v1/CACHE_RUN_v1.json')
check('cache.command_runner_hash',command['runner_sha256']==sha(canon.encode()))
check('cache.command_inputs',command['input_sha256']=={rel:sha((SOURCES/local).read_bytes()) for rel,local in zip(paths,source_files)})
check('cache.recorded_stdout_matches',json.loads(run['result']['stdout'])==payload)
check('cache.recorded_exit',run['result']['exit_code']==0 and run['result']['status']=='ok' and run['result']['stderr']=='')
check('cache.elapsed_header_rounding',header['elapsed_sec']==f"{run['result']['elapsed_sec']:.2f}")
check('cache.primary_results_payload',payload==obj('packaging_v1/PRIMARY_RESULTS_v1.json'))
check('cache.self_reported_checker_hash',payload['checker_sha256']==sha(canon.encode()))
check('cache.counts',payload['passed']==81 and payload['failed']==0 and len(payload['checks'])==81 and all(c['passed'] for c in payload['checks']))
original_results=obj('direct/RESULTS_v1.json')
check('direct.self_reported_checker_hash',original_results['checker_sha256']==sha(orig.encode()))
check('direct.outputs_same_except_code_hash',{k:v for k,v in original_results.items() if k!='checker_sha256'}=={k:v for k,v in payload.items() if k!='checker_sha256'})
check('direct.execution_hash_and_success',obj('direct/RUN_v1.json')['checker_sha256']==sha(orig.encode()) and obj('direct/RUN_v1.json')['exit_code']==0)
check('direct.stderr_empty',read('direct/stderr_v1.txt')=='')

protocol=obj('direct/damages_v1/PROTOCOL_v1.json');summ=obj('direct/damages_v1/SUMMARY_v1.json')
check('damages.protocol_original_hash',protocol['source_sha256']==sha(orig.encode()))
damage_records=[]
required={'wrong_bounce_frequency':'large_Friedmann','wrong_critical_exponent':'critical_upper_Friedmann','wrong_fraction_discriminant':'fraction_boundary'}
for c,meta in zip(protocol['controls'],summ):
 name=c['name'];actual=read('direct/damages_v1/'+name+'.py')
 check(name+'.exact_single_replacement',orig.count(c['replace_from'])==1 and actual==orig.replace(c['replace_from'],c['replace_to']))
 data=obj('direct/damages_v1/'+name+'_results.json')
 failures=[v for v in data['checks'] if not v['passed']]
 check(name+'.executed_code_hash',sha(actual.encode())==meta['script_sha256']==data['checker_sha256'])
 check(name+'.recorded_counts',len(data['checks'])==81 and data['passed']==meta['passed'] and data['failed']==meta['failed']==len(failures) and meta['exit_code']==1 and meta['detected'])
 check(name+'.intended_mathematical_failure',required[name] in [v['name'] for v in failures])
 check(name+'.stderr_empty',read('direct/damages_v1/'+name+'.stderr')=='')
 out=read('direct/damages_v1/'+name+'.stdout')
 check(name+'.stdout_failure_lines',sum(line.startswith('FAILED ') for line in out.splitlines())==data['failed'])
 damage_records.append({'name':name,'script_sha256':sha(actual.encode()),'passed':data['passed'],'failed':data['failed'],'required_failure':required[name],'failure_details':failures,'reused_actual_execution':True,'canonical_wrapper_not_rerun_as_damage':True})

# Independent rational comparison of the printed decimal with the exact root.
d=F(3,1000);printed=F('2.24327520666366e-6');outward=F('2.24327520666367e-6')
def squared_gap(value):return (1+d-2*value)**2-(1+2*d)
old_gap=squared_gap(printed);upper_gap=squared_gap(outward)
check('precision.old_printed_upper_bound_is_valid',old_gap<=0,{'printed':str(printed),'squared_gap':str(old_gap),'logic':'Since 1+d-2b>0, b>=f(d) iff (1+d-2b)^2<=1+2d. Positive gap proves the printed b is too small.'})
check('precision.outward_candidate_is_valid',upper_gap<=0,{'candidate':str(outward),'squared_gap':str(upper_gap)})
with localcontext() as ctx:
 ctx.prec=80
 dd=Decimal(3)/1000
 exact_decimal=(1+dd-(1+2*dd).sqrt())/2
 decimal_gap=exact_decimal-Decimal('2.24327520666366e-6')
check('precision.cache_decimal_matches_24_digit_rounding',str(exact_decimal).startswith('0.00000224327520666366184635570'),str(exact_decimal))
# Curvature convention follows from the normalized Friedmann equation, with c=1.
K,a0,H0=F(7,3),F(5,2),F(11,7)
omega=-K/(a0*a0*H0*H0);dtest=K/(a0*a0*H0*H0)
check('convention.d_equals_minus_OmegaK',dtest==-omega and dtest>0 and omega<0,{'d':str(dtest),'Omega_K':str(omega)})
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_sha256':sha(Path(__file__).read_bytes()),'python':platform.python_version(),'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'total':len(checks)},'checks':checks,'failures':[c for c in checks if not c['passed']],'damage_evidence':damage_records,'precision_witness':{'exact_expression':'(1003/1000-sqrt(503/500))/2','decimal_80_precision':str(exact_decimal),'old_printed_deficit':str(decimal_gap),'exact_squared_gap_old':str(old_gap),'exact_squared_gap_outward':str(upper_gap)},'science_rerun':False,'scope':'Source/cache/static-output correspondence and narrow precision/convention arithmetic; no original proof rerun.'}
(OUT/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'failures':result['failures'],'precision_witness':result['precision_witness']},indent=2))
sys.exit(1 if result['counts']['failed'] else 0)
