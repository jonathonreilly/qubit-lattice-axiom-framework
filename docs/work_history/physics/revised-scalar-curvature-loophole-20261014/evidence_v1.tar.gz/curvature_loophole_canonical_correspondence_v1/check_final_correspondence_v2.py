from pathlib import Path
from fractions import Fraction as F
import ast,datetime,difflib,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
SOURCES=ROOT/'sources'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
def text(p):return (SOURCES/p).read_text()
def obj(p):return json.loads(text(p))
old=text('canonical_v1/NOTE.md');new=text('canonical_v2/NOTE.md');runner=text('canonical_v1/RUNNER.py')
ck('final.expected_note_hash',sha(new.encode())=='eb42e84185053ee6f51b6ed4700b20bf7d981a0366270f8d1a3ed71281e3760d')
ck('final.runner_unchanged',sha((REPO/'scripts/exponential_scalar_curvature_loophole_check.py').read_bytes())==sha(runner.encode())=='c886153bb98ba00f7b2772ab8b44f7dbdfa55bfe4dda8d3b197160a1020449bd')
before='r<=2.24327520666366e-6. This number';after='r<=2.24327520666367e-6 (rounded outward). This number'
ck('final.only_precision_wording_changed',old.count(before)==1 and new==old.replace(before,after))
ck('final.equations_unchanged',[x for x in old.splitlines() if x.startswith('    ')]==[x for x in new.splitlines() if x.startswith('    ')])
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='canonical-v1',tofile='canonical-v2'))
ck('final.recorded_correction_diff',diff==text('packaging_v2/PRECISION_CORRECTION_v2.diff'))
ck('lineage.old_note_preserved',old==text('packaging_v2/pre_precision_correction_v1/NOTE.md'))
ck('lineage.old_cache_preserved',text('canonical_v1/CACHE.txt')==text('packaging_v2/pre_precision_correction_v1/CACHE.txt'))
correction=obj('packaging_v2/PRECISION_CORRECTION_v2.json')
ck('lineage.correction_note_hashes',correction['original_note_sha256']==sha(old.encode()) and correction['final_note_sha256']==sha(new.encode()))
ck('lineage.no_equation_change_claim',correction['science_equations_changed'] is False)
d=F(3,1000);upper=F('2.24327520666367e-6');old_lower=F('2.24327520666366e-6')
gap_upper=(1+d-2*upper)**2-(1+2*d)
gap_lower=(1+d-2*old_lower)**2-(1+2*d)
ck('precision.final_rational_upper',1+d-2*upper>0 and gap_upper<0,{'upper':str(upper),'squared_gap':str(gap_upper)})
ck('precision.original_error_remains_preserved',1+d-2*old_lower>0 and gap_lower>0,{'old_lower':str(old_lower),'squared_gap':str(gap_lower)})
ck('precision.parent_upper_rational',F(correction['exact_upper_rational'])==upper)
ck('precision.rounding_explicit','2.24327520666367e-6 (rounded outward)' in new)

def cache_parts(raw):
 head,body=raw.split('----- stdout -----\n',1);stdout,stderr=body.split('\n----- stderr -----\n',1)
 return dict(line.split(': ',1) for line in head.splitlines() if ': ' in line),json.loads(stdout),stderr
oldhead,oldpayload,_=cache_parts(text('canonical_v1/CACHE.txt'))
head,payload,stderr=cache_parts(text('canonical_v2/CACHE.txt'))
ck('cache.runner_identity',head['runner']=='scripts/exponential_scalar_curvature_loophole_check.py' and head['runner_sha256']==sha(runner.encode()))
ck('cache.success',head['status']=='ok' and head['exit_code']=='0' and not stderr.strip())
ck('cache.timeout',head['timeout_sec']=='120')
paths=next(ast.literal_eval(n.value) for n in ast.parse(runner).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
source_files=['canonical_v2/NOTE.md','inputs/FULL_ACTION.md','inputs/FLAT_RADIATION_BOUND.md']
h=hashlib.sha256();h.update(b'runner-cache-input-fingerprint-v1\0')
for rel,local in zip(paths,source_files):
 p=rel.encode();data=(SOURCES/local).read_bytes();h.update(len(p).to_bytes(8,'big'));h.update(p);h.update(len(data).to_bytes(8,'big'));h.update(data)
ck('cache.new_input_fingerprint',head['input_fingerprint_sha256']==h.hexdigest(),h.hexdigest())
ck('cache.fingerprint_changed_for_note',head['input_fingerprint_sha256']!=oldhead['input_fingerprint_sha256'])
ck('cache.mathematical_output_byte_equivalent_json',payload==oldpayload)
run=obj('packaging_v2/CACHE_RUN_v2.json')
ck('cache.actual_refresh_output',json.loads(run['result']['stdout'])==payload)
ck('cache.actual_refresh_success',run['result']['exit_code']==0 and run['result']['status']=='ok' and run['result']['stderr']=='')
ck('cache.elapsed_record',head['elapsed_sec']==f"{run['result']['elapsed_sec']:.2f}")
ck('cache.record_discloses_unchanged_rerun','unchanged science rerun disclosed' in run['reason'])
ck('cache.counts',payload['passed']==81 and payload['failed']==0 and len(payload['checks'])==81 and all(v['passed'] for v in payload['checks']))
ck('cache.self_hash',payload['checker_sha256']==sha(runner.encode()))
for rel,local in zip(paths,source_files):
 ck('live.'+rel,(REPO/rel).read_bytes()==(SOURCES/local).read_bytes())
ck('live.cache',(REPO/'logs/runner-cache/exponential_scalar_curvature_loophole_check.txt').read_bytes()==(SOURCES/'canonical_v2/CACHE.txt').read_bytes())

receipt=obj('independent_math/RECEIPT_v1.json');ident=json.loads((ROOT/'INDEPENDENT_MATH_IDENTITY_v1.json').read_text())
ck('reuse.receipt_hash',sha((SOURCES/'independent_math/RECEIPT_v1.json').read_bytes())=='cfb2bc28f32e632ea671f9d750ee60da79e9c368cc31215407e55046b090bded')
ck('reuse.report_binding',receipt['report']['sha256']==sha((SOURCES/'independent_math/REPORT_v1.md').read_bytes()))
ck('reuse.manifest_binding',receipt['manifest']['sha256']==sha((SOURCES/'independent_math/MANIFEST_v1.json').read_bytes()))
ck('reuse.original_derivation_matches',receipt['source_bindings'][0]['sha256']==sha((SOURCES/'direct/DERIVATION_v1.md').read_bytes()))
ck('reuse.original_action_matches',receipt['source_bindings'][1]['sha256']==sha((SOURCES/'inputs/FULL_ACTION.md').read_bytes()))
ck('reuse.full_identity_verification',ident['artifact_count']==60 and ident['source_pair_count']==2 and ident['exact_inventory'] is True)
ck('reuse.independent_counts',receipt['baseline_counts']=={'passed':107,'failed':0,'total':107})
ck('reuse.five_actual_damages',len(receipt['actual_damage_counts'])==5 and all(d['exit_code']==1 and d['counts']['failed']>0 for d in receipt['actual_damage_counts']))
ck('reuse.no_formal_audit',receipt['formal_audit'] is False and receipt['formal_grade_or_authority_state_changed'] is False)
ck('reuse.no_source_amendment_requested',obj('independent_math/FAILURES_v1.json')['source_corrections_requested']==[])
attribution=obj('independent_math/PRIMARY_ATTRIBUTION_v1.json')
ck('reuse.primary_attribution_limited',attribution['source_attribution_matches'] is True and 'not a copied full paper' in attribution['storage'])
ck('reuse.Planck_facts_correspond',attribution['facts_checked']['section_7_3_equation_45b']['Omega_K']=='0.0007 +/- 0.0019' and attribution['facts_checked']['table_4']['Omega_K']=='0.0007 +/- 0.0037')
ck('lineage.decimal_assertion_repair_preserved',json.loads((ROOT/'PRECISION_CHECKER_REPAIR_RESULTS_v1.json').read_text())['counts']=={'passed':1,'failed':0,'total':1})
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_sha256':sha(Path(__file__).read_bytes()),'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'total':len(checks)},'checks':checks,'failures':[c for c in checks if not c['passed']],'final_note_sha256':sha(new.encode()),'runner_sha256':sha(runner.encode()),'final_cache_sha256':sha((SOURCES/'canonical_v2/CACHE.txt').read_bytes()),'independent_math_receipt_sha256':sha((SOURCES/'independent_math/RECEIPT_v1.json').read_bytes()),'scope':'Narrow corrected-source/cache/reused-proof correspondence only. No producer runner or original independent science executed by this checker.'}
with (ROOT/'FINAL_CORRESPONDENCE_RESULTS_v2.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
sys.exit(0 if not result['failures'] else 1)
