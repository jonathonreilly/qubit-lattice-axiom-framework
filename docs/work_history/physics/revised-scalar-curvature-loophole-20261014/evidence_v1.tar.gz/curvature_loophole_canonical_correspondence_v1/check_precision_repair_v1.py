from pathlib import Path
from decimal import Decimal,localcontext
import datetime,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
payload=json.loads((ROOT/'sources/packaging_v1/PRIMARY_RESULTS_v1.json').read_text())
with localcontext() as ctx:
 ctx.prec=80
 d=Decimal(3)/1000
 exact=(1+d-(1+2*d).sqrt())/2
 supplied=Decimal(payload['illustrative_r_limit'])
 rounded=exact.quantize(Decimal(1).scaleb(supplied.as_tuple().exponent))
 passed=supplied==rounded
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'passed':int(passed),'failed':int(not passed),'total':1},'check':{'name':'precision.cache_decimal_correctly_rounded','passed':passed,'exact_decimal_80_precision':str(exact),'cached_decimal':str(supplied),'correct_rounded_decimal':str(rounded)},'repair_scope':'The initial correspondence checker incorrectly used text-prefix comparison to verify a rounded 24-significant-digit result. Its mismatch is a checker assertion error, not a source or canonical-runner error. This separate control compares exact Decimal quantization at the supplied exponent. Initial 47/2 output is preserved. The separate rounded-down inequality finding remains valid.'}
with (ROOT/'PRECISION_CHECKER_REPAIR_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
sys.exit(0 if passed else 1)
