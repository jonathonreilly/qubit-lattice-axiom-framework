from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda data:hashlib.sha256(data).hexdigest()
def item(name):
 data=(ROOT/name).read_bytes();return {'path':name,'bytes':len(data),'sha256':sha(data)}
def write(name,obj):
 with (ROOT/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
v1=json.loads((ROOT/'SOURCE_MANIFEST_v1.json').read_text())
v2=json.loads((ROOT/'SOURCE_MANIFEST_v2.json').read_text())
old_names={'sources/canonical_v1/NOTE.md','sources/canonical_v1/CACHE.txt'}
current=[x for x in v1['source_bindings'] if x['snapshot_path'] not in old_names]
reuse=[x for x in v2['additional_bindings'] if x['kind']=='reused_independent_mathematics']
current.extend(x for x in v2['additional_bindings'] if x['kind']!='reused_independent_mathematics')
current.append(json.loads((ROOT/'CACHE_UTILITY_BINDING_v1.json').read_text()))
assert len(current)==40 and len(reuse)==8
for x in current+reuse:
 live=REPO/x['original_path'];snap=ROOT/x['snapshot_path']
 assert live.read_bytes()==snap.read_bytes(),x['original_path']
 assert sha(live.read_bytes())==x['sha256'] and len(live.read_bytes())==x['bytes']
historical=[]
for x in v1['source_bindings']:
 if x['snapshot_path'] not in old_names:continue
 replacement=next(p for p in v2['superseded_mappings'] if p['historical_snapshot']==x['snapshot_path'])
 mapped=next(p for p in current if p['snapshot_path']==replacement['preserved_current_snapshot'])
 assert (ROOT/x['snapshot_path']).read_bytes()==(ROOT/mapped['snapshot_path']).read_bytes()
 historical.append({**x,'status':'superseded_canonical_version_preserved','preserved_original_path':mapped['original_path'],'preserved_snapshot_path':mapped['snapshot_path']})
write('SOURCE_BINDINGS_FINAL_v1.json',{'created_utc':now(),'current_source_bindings':current,'reused_independent_bindings':reuse,'historical_canonical_bindings':historical,'current_source_pair_count':len(current),'reused_pair_count':len(reuse),'historical_recovery_pair_count':len(historical)})
# Selected reuse identity is rechecked at sealing; science remains unexecuted.
ind=REPO/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state/curvature_loophole_v1/independent_v1'
m=json.loads((ind/'MANIFEST_v1.json').read_text());entries=m.get('artifacts') or m.get('files')
for x in entries:
 d=(ind/x['path']).read_bytes();assert len(d)==x['bytes'] and sha(d)==x['sha256']
assert {str(p.relative_to(ind)) for p in ind.rglob('*') if p.is_file()}=={x['path'] for x in entries}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
write('FINAL_IDENTITY_v1.json',{'created_utc':now(),'all_40_current_source_pairs_identical':True,'all_8_reused_pairs_identical':True,'two_historical_canonical_versions_recoverable':True,'reused_independent_artifacts_unchanged':len(entries),'reused_independent_exact_inventory':True,'prior_seals_changed':False,'final_note':item('sources/canonical_v2/NOTE.md'),'final_runner':item('sources/canonical_v1/RUNNER.py'),'final_cache':item('sources/canonical_v2/CACHE.txt')})
initial=json.loads((ROOT/'correspondence_v1/RESULTS_v1.json').read_text());repair=json.loads((ROOT/'PRECISION_CHECKER_REPAIR_RESULTS_v1.json').read_text());final=json.loads((ROOT/'FINAL_CORRESPONDENCE_RESULTS_v2.json').read_text())
assert initial['counts']=={'passed':47,'failed':2,'total':49}
assert repair['counts']=={'passed':1,'failed':0,'total':1}
assert final['counts']=={'passed':42,'failed':0,'total':42}
paths=sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name not in {'MANIFEST_v1.json','RECEIPT_v1.json'})
# Only this top-level manifest/receipt are excluded; imported evidence with the
# same basename is explicitly retained in the inventory.
paths=sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in {'MANIFEST_v1.json','RECEIPT_v1.json'})
artifacts=[item(p) for p in paths]
write('MANIFEST_v1.json',{'schema':'canonical-correspondence-artifact-manifest-v1','created_utc':now(),'artifact_root':str(ROOT.relative_to(REPO)),'artifact_count':len(artifacts),'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts})
rec={
 'schema':'focused-canonical-source-correspondence-receipt-v1','created_utc':now(),'unit':'curvature_loophole_canonical_correspondence_v1','scientific_author':'/root','independent_correspondence_checker':'/root/scalar_energy_check','reused_independent_mathematics_checker':'/root/local_response_check','formal_audit':False,'landing_authority':False,'formal_grade_or_authority_state_changed':False,
 'source_bindings':current,'reused_independent_bindings':reuse,'historical_canonical_bindings':historical,'source_pair_count':len(current),'reused_pair_count':len(reuse),
 'manifest':item('MANIFEST_v1.json'),'report':item('REPORT_v1.md'),'protocol':item('PROTOCOL_v1.json'),'claim_correspondence':item('CLAIM_CORRESPONDENCE_v1.json'),'source_binding_record':item('SOURCE_BINDINGS_FINAL_v1.json'),'final_identity':item('FINAL_IDENTITY_v1.json'),
 'final_science_hashes':{'note':'eb42e84185053ee6f51b6ed4700b20bf7d981a0366270f8d1a3ed71281e3760d','runner':'c886153bb98ba00f7b2772ab8b44f7dbdfa55bfe4dda8d3b197160a1020449bd','cache':'9f0e8c2c854af14a05278ee1c3406ba854cbf08e876e758294f7ee05f767fa1d'},
 'new_execution_lineage':[
  {'stage':'initial_frozen_v1_correspondence','code':item('check_correspondence_v1.py'),'execution':item('CORRESPONDENCE_EXECUTION_v1.json'),'results':item('correspondence_v1/RESULTS_v1.json'),'counts':initial['counts'],'meaning':'One real inward-rounding source issue and one independent checker assertion error'},
  {'stage':'isolated_precision_assertion_repair','code':item('check_precision_repair_v1.py'),'execution':item('PRECISION_REPAIR_EXECUTION_v1.json'),'results':item('PRECISION_CHECKER_REPAIR_RESULTS_v1.json'),'counts':repair['counts'],'meaning':'Correct Decimal quantization confirms the original cached rounded value'},
  {'stage':'affected_final_source_cache_and_reuse','code':item('check_final_correspondence_v2.py'),'execution':item('FINAL_CORRESPONDENCE_EXECUTION_v2.json'),'results':item('FINAL_CORRESPONDENCE_RESULTS_v2.json'),'counts':final['counts'],'meaning':'Final source/cache/reused proof correspondence; not a replacement clean science run'}],
 'reused_science':{'producer_direct_counts':'81/0','producer_actual_damages':[{'name':x['name'],'passed':x['passed'],'failed':x['failed']} for x in initial['damage_evidence']],'canonical_cache_counts':'81/0','cache_refresh_by_author':True,'canonical_mathematical_block_byte_identical_to_direct':True,'independent_mathematics_receipt_sha256':'cfb2bc28f32e632ea671f9d750ee60da79e9c368cc31215407e55046b090bded','independent_mathematics_counts':'107/0','independent_actual_damages':5,'independent_artifacts_verified':60,'independent_live_source_pairs_verified':2,'identity_record':item('INDEPENDENT_MATH_IDENTITY_v1.json')},
 'failure_ledger':item('FAILURES_v1.json'),'command_index':item('COMMAND_INDEX_v1.json'),
 'source_disposition':{'inward_rounding_finding_preserved':True,'outward_rounding_correction_exactly_verified':True,'displayed_equations_changed':False,'producer_mathematics_changed':False,'remaining_source_correction_required':False,'cache_declared_inputs_refreshed_and_verified':True},
 'scope':['Complete canonical claim correspondence to original derivation, declared action and flat-radiation theorem','Exact wrapper/output-only runner change and cache input/runner/output identity','Actual direct damaged-source execution lineage and unchanged canonical mathematics','Updated numerical precision and d=-Omega_K convention','Read and hash-bind sealed independent proof, preserving distinction from finite controls','Empirical/matter/state/completeness assumptions and claim boundaries'],
 'limits':['Source correspondence and reuse only; no landing or formal audit authority.','No independent science was rerun by this checker; the author actual 81/0 cache refresh is separately disclosed.','General sign domains, causal completeness and monotonicity depend on the hand proof; finite controls and loose decimal tolerance do not replace it.','The Planck factual access receipt is reused; no fresh external verification, remote primary-byte snapshot or likelihood is claimed.','The regular histories choose positive curvature, complete S3, radiation-only origin state and branches; no hot radiation era, actual cosmological fit, state/scale selection or stability follows.'],
 'independence_and_mutation_scope':{'producer_code_read_for_correspondence':True,'producer_code_executed_by_checker':False,'new_empirical_acquisition':False,'unrelated_history_inspected':False,'all_writes_confined_to_new_correspondence_directory':True,'prior_seals_parent_sources_git_PR_runtime_lock_authority_changed':False}}
write('RECEIPT_v1.json',rec)
print(json.dumps({'artifact_count':len(artifacts),'current_source_pairs':len(current),'reused_pairs':len(reuse),'historical_recovery_pairs':len(historical),'report':item('REPORT_v1.md'),'manifest':item('MANIFEST_v1.json'),'receipt':item('RECEIPT_v1.json')},indent=2))
