# Direct curvature calculation

The direct exact checker passed81/0. Three actual altered copies were rejected: wrong_bounce_frequency 74/7, wrong_critical_exponent 76/5, wrong_fraction_discriminant 77/4. All original code, streams, full results and execution metadata are preserved. No failed baseline or repair occurred.

At illustrative d=0.003 the conditional bound is r<=0.00000224327520666366184635570. This is not an imported Planck posterior. Exact same-action regular branches use positive spatial curvature and a chosen radiation-only origin state; they never have radiation energy above vacuum. The critical upper branch is always expanding and past asymptotic to an Einstein-static radius. General causal completeness rests on the global positive radius and complete S3 proof, not finite sample tests. No nonlinear stability, selected state/action/scales or empirical fit.
