# Independent curved-radiation derivation before executable checks

Scientific author remains /root. Checker /root/local_response_check has read only the frozen curvature source and the complete supplied action, not producer code/results. The following derivation and controls are fixed before implementation.

At phi=0, the complete action has C=1, U=3/2, U_,A=0 and finite positive K. Since the scalar source from conformal matter is proportional to rho-3p, separately conserved isotropic radiation does not displace this origin. Einstein and physical metrics coincide. This uses a selected radiation-only state and does not make dust disappear: at the same origin a nonzero dust trace sources u. The full action, not the flat future-theorem equations, is used in changing the spatial geometry.

For lapse N, a complete positive-constant-curvature spatial metric gamma with scalar curvature 6Kc, and fixed radiation charge 3QD², the reduced gravitational/vacuum/radiation action per comoving volume is

    L = -3Qa adot²/N + 3Q Kc N a - 3Q h² N a³ - 3Q D² N/a.

The last term is the homogeneous fixed-charge radiation Routhian: its a variation reproduces p=rho/3. Vary N before setting N=1. The resulting constraint is

    H² = h² + D²/a⁴ - Kc/a².

Vary a independently, then use the constraint. This gives

    addot/a = h² - D²/a⁴,
    Hdot = Kc/a² - 2D²/a⁴.

The curvature sign is geometric; neither the radiation density nor the scalar kinetic metric is negative. Densities here are dimensionful, unlike the older normalized canonical rho_J variable.

For X=a²,

    Xdot² = 4(h²X²-Kc X+D²),
    Xddot = 4h²X-2Kc.

The second equation follows from the independent scale equation, so it is valid at a turning point; it must not be inferred only by dividing a differentiated constraint by Xdot. A constant simple root of the quadratic satisfies the squared constraint but is not a full solution.

Let Xm=Kc/(2h²), Y=X-Xm. The general scale solution is Y=Ue^(2ht)+Ve^(-2ht). Substitution in the constraint gives UV=Delta/(16h⁴), Delta=Kc²-4h²D².

- Delta>0: U,V have the same sign. U,V>0 give the translated cosh solution X=[Kc+sqrt(Delta)cosh(2h(t-tb))]/(2h²), all t in R. Its minimum is Xplus>0, with Hdot_b=sqrt(Delta)/Xplus>0. U,V<0 give X=[Kc-sqrt(Delta)cosh(2h(t-tc))]/(2h²), allowed only for |t-tc|<acosh(Kc/sqrt(Delta))/(2h). It expands from X=0, reaches Xminus and recollapses to X=0. Both endpoints have positive radiation and divergent curvature.
- Delta=0: UV=0. U=V=0 is the static X=Xm=D/h solution. One positive exponential gives the critical upper solution X=Xm+B exp(2h(t-t0)), B>0, or its time reversal. It exists for all real t, is strictly expanding in the displayed orientation, approaches the positive static radius in the past and expands without bound in the future. A negative exponential coefficient instead gives a lower branch with a finite-time X=0 endpoint. Setting Delta=0 in the cosh formula at a fixed tb gives only the static solution. The scale perturbation equation delta Xddot=4h²delta X has a growing mode; at fixed radiation charge, the exact constraint additionally restricts the product of its two exponential amplitudes. Linearized acceleration alone does not permit arbitrary finite-amplitude superpositions.
- Delta<0: U,V have opposite signs. An expanding branch may be written X=Xm+sqrt(-Delta)sinh(2h(t-tc))/(2h²). Its unique X=0 crossing is at a finite t, with Xdot approaching 2D. The expanding positive-X branch has a radiation-curvature singular past. The reversed branch has the corresponding future singularity.
- D=0 is outside strict positive radiation. The regular cosh branch becomes a=(sqrt(Kc)/h)cosh(h(t-tb)), the complete closed de Sitter slicing.

Curvature is checked using the orthonormal isotropic Riemann components, not the flat-space expression with Kc omitted:

    R_0i0j = -(addot/a) delta_ij,
    R_ijkl = (H²+Kc/a²)(delta_ik delta_jl-delta_il delta_jk).

Contracting yields Ricci=6[A+B], Kretschmann=12[A²+B²], where A=addot/a=h²-D²/X² and B=H²+Kc/X=h²+D²/X². Hence Ricci=12h² and Kretschmann=24(h⁴+D⁴/X⁴). The regular upper branches have bounded invariants. Finite Ricci does not rule out the singular X=0 lower endpoints.

For a causal geodesic with affine parameter lambda, let v^i=dx^i/dlambda and q=gamma_ij v^i v^j. The spatial geodesic equation gives dq/dlambda=-4H (dt/dlambda)q, so P²=a⁴q is conserved. Normalization gives (dt/dlambda)²=epsilon+P²/a², with epsilon=1 for unit timelike proper time and epsilon=0 for null affine parametrization. Therefore

    dtau/dt=(1+P²/a²)^(-1/2),
    dlambda/dt=a/P for null P>0.

If t ranges over R and a>=amin>0, both accumulated parameters diverge at either infinite t end. Completeness also requires no finite-t escape: on every finite t interval a and its derivatives are smooth, momenta are bounded by their conserved P and amin, and the complete S³ spatial section has no boundary. The geodesic ODE then extends. This supplies all causal geodesics, including comoving timelike P=0. It is not an inhomogeneous stability claim; a coordinate patch of S³ alone would not suffice. The same proof covers the critical upper branch and the static critical state. A finite conformal-time boundary does not imply finite null affine length.

At any finite expanding regular-upper event, L=h²/H², r=D²/(X²H²), d=Kc/(XH²)>0. Then L+r=1+d, d²-4Lr=Delta/(X²H⁴)>=0 and L>r. Selecting this smaller-r branch gives

    r <= f(d)=[1+d-sqrt(1+2d)]/2
       = d²/[2(1+d+sqrt(1+2d))].

The second form avoids cancellation for small d. f is strictly increasing for d>0, f(d)=d²/4-d³/4+5d⁴/16+O(d⁵), and f(d)<d²/4 for d>0. Equality in the r bound is possible on the critical upper branch. Dropping L>r would erroneously admit the singular radiation-heavy lower branch. At a bounce H=0 the fractions are undefined and cannot be used. The usual cosmological curvature convention is Omega_K=-Kc/(a²H²)=-d, so a positive-curvature comparison uses the negative side of that parameter. The paper's model-conditional interval is not a scalar-model likelihood.

The physically relevant radiation/vacuum density ratio is rho_r/rho_vac=D²/(h²X²), with rho_vac=3Qh². For Delta>0, X>=Xplus>D/h, so the ratio is strictly below one throughout the regular branch. For the critical nonstatic upper branch X>Xm=D/h at every finite t, it is also below one and tends to one only in the static past limit. The exact static state has equality. H-normalized r may be large near the bounce, which does not establish radiation energy dominance. Thus the selected regular class lacks a radiation-dominated era; no hot-universe fit, origin-state selection or new physical mechanism follows.

Distinct exact controls fixed before code: k=2/11, nu=7/5, Q0=121/65 (Q=11/5), h=2/3, Kc=5/2. For D=9/8, Delta=4, Xplus=81/16, Xminus=9/16, Xm=45/16, bounce radiation/vacuum ratio=1/9, and the lower-branch endpoints are +/-3 log(2)/4. For critical D=15/8 choose B=7/10. For Delta<0 choose D=2, giving Delta=-31/36. Off-grid ODE controls will use the independently derived second-order scale flow, not producer code. Causal clock quadratures will use finite P=13/7 and the proved lower bounds; numerical samples support rather than replace completeness or asymptotic proofs.

No mathematical source correction has been identified before computation. Five actual damaged implementations are planned: reverse the Friedmann curvature sign; halve the critical exponential rate; omit spatial curvature from the Riemann spatial block; damage the fraction-bound square-root coefficient; invert the null-affine scale-factor power. Each must trigger an equation/normalization failure, not merely a changed byte or a preassigned failure flag.
