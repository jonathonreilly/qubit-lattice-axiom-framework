# Independent check of the closed-radiation loophole

The derivation is mathematically consistent under its stated hypotheses. Positive spatial curvature admits both the regular bouncing branch and the critical nonstatic, always-expanding branch within the supplied action at the chosen scalar origin. The completeness and fraction claims survive this focused independent check. No substantive source amendment is requested. This is a standard closed-FLRW radiation/vacuum reconstruction inside the supplied model, not a new gravitational mechanism, selected initial state or observed cosmological fit.

Scientific authorship remains with `/root`. `/root/local_response_check` independently derived the equations from the full action and froze `HAND_DERIVATION_v1.md` and the control protocol before writing/running the checker. No parent checker or result was read, imported or executed. No other evidence seal, source file, Git state, runtime or authority state was changed; no formal audit or new agent was launched.

## Frozen sources and normalization

| Source/evidence | SHA-256 |
|---|---|
| Curvature `DERIVATION_v1.md` | `1d3dee4047738e1a8c724b3a99600c191c567f94473bdc29d8d8600c17c1b4dd` |
| Complete supplied action note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Independent hand derivation | `29033b8fbe244d9edd56dda09f7043c2c2e7e28e7584ac6d8b8ff813911dee58` |
| Independent executable | `32fd15a9853a1d61aede6da80d4940cce2b906fca8bb0e90d599b89bc02c1408` |

Both sources were copied before review, read fully, and remain byte-identical to the originals. `SOURCE_MANIFEST_v1.json` records paths, sizes and hashes. The future-confinement note is used for its covariant action, not to import its spatially flat theorem into the new geometry.

At the scalar origin the complete potential is stationary with `U=3/2`, the conformal factor is `C=1`, and the kinetic metric is regular and positive. The action therefore supplies constant density `rho_vac=3Qh²`. Radiation has zero conformal trace source; its scalar origin remains exact. Nonzero dust would source the scalar through the nonzero matter coupling, so omitting dust is a consequential state restriction. All densities in this check are dimensionful; the older canonical normalized density symbol is not silently reused.

The reduced lapse action at fixed radiation charge is

    L=-3Qa adot²/N+3QKcNa-3Qh²Na³-3QD²N/a.

Independent lapse and scale-factor variations give

    H²=h²+D²/a⁴-Kc/a²,
    addot/a=h²-D²/a⁴,
    Hdot=Kc/a²-2D²/a⁴.

The fixed-charge radiation term reproduces pressure `rho_r/3`. In particular, the negative term in the constraint is spatial geometry, not negative radiation or a ghost. The acceleration equation is valid at `H=0`; differentiating the squared constraint and dividing by `H` would miss this requirement.

## Branches, curvature and completeness

With `X=a²` and `Xm=Kc/(2h²)`, the independent scale equation is `Xddot=4h²X-2Kc`. Its general solution has `X-Xm=Ue^(2ht)+Ve^(-2ht)`. The constraint imposes `UV=Delta/(16h⁴)`. This provides a direct classification:

- For `Delta>0`, positive `U,V` give the all-time regular upper cosh branch. Negative `U,V` give the separate small-X branch with finite-time radiation singularities. The positive discriminant by itself does not select a complete history. A constant simple root satisfies the squared constraint but fails the scale equation, a tested failure probe.
- For `Delta=0`, `UV=0`. The static solution and single-exponential upper solutions are distinct. `X=Xm+B exp(2h(t-t0))`, `B>0`, is strictly expanding for every finite time and approaches a positive static radius as `t->-infinity`. The time-reversed upper solution also exists. A negative exponential coefficient gives a lower branch with a finite-time zero of X. The fixed-time limit of the cosh family is only static. The scale equation has a growing perturbation mode; at fixed radiation charge, the exact constraint further restricts products of exponential amplitudes. Unrestricted homogeneous attraction is not established.
- For `Delta<0`, the independent sinh solution has a finite-time zero of X on the expanding branch. `D=0` is outside positive radiation and correctly recovers the complete closed de Sitter slicing.

The orthonormal Riemann components were explicitly contracted with Lorentzian signs. The spatial block contains `H²+Kc/a²`, not just `H²`. This gives `Ricci=12h²` and `Kretschmann=24(h⁴+D⁴/X⁴)`. The upper branches have bounded invariants. The lower-branch zero-X endpoints have divergent Kretschmann despite finite Ricci. Radiation, the conformal metric and the scalar fields remain regular at the upper bounce.

For causal geodesics, the spatial equation gives the conserved magnitude `P²=a⁴ gamma_ij xdot^i xdot^j`; constant coordinate momentum components are not assumed on S³. Normalization yields `dtau/dt=(1+P²/a²)^(-1/2)` and `dlambda/dt=a/P` for nonzero null P. The positive lower bound on a makes both integrals infinite at either infinite cosmic-time end. On a finite time interval, smooth coefficients and bounded momenta on complete S³ prevent finite-parameter escape. This closes the extension step beyond merely evaluating an integral. It applies to the regular bounce, critical upper solution and static solution, but requires the complete spatial section, not a coordinate patch. It proves causal geodesic completeness for these exact classical spacetimes; it does not prove inhomogeneous or quantum stability.

## Fractions and physical limits

At a finite expanding upper-branch event, `L+r=1+d`, `d²-4Lr=Delta/(X²H⁴)>=0`, and `L>r`. Selecting the smaller-r quadratic branch produces

    r <= [1+d-sqrt(1+2d)]/2
      = d²/[2(1+d+sqrt(1+2d))].

The rationalized form is useful at small d. Its expansion is `d²/4-d³/4+5d⁴/16+O(d⁵)`, and the bound is increasing for `d>0`. The source benchmark is confirmed independently:

    f(0.003)=0.00000224327520666366184635569953767847021715475177.

The `L>r` branch restriction is essential: an allowed singular lower-branch exact event violates this upper-branch inequality. Fractions normalized by H² are undefined at the bounce. They can become large nearby even though the actual radiation/vacuum energy ratio remains below one; an exact rational witness tests this distinction.

The energy ratio is `rho_r/rho_vac=D²/(h²X²)`. On the strict regular branch it is at most `(Kc-sqrt(Delta))/(Kc+sqrt(Delta))<1`; on the critical nonstatic upper branch it is less than one at every finite time and tends to equality in its static past limit. The exactly static critical state has equality. Thus none of these selected regular histories has a radiation-dominated energy era. This is a substantive limitation of the reconstruction, not an observational acceptance result. An altered matter sector or rolling scalar history requires a new calculation.

The cited Planck values and confidence levels were checked against the primary source: Eq. 45b gives `0.0007 +/- 0.0019` at 68%, and Table 4 gives `0.0007 +/- 0.0037` at 95%, for the stated Planck+lensing+BAO combination in a one-parameter extension of base LambdaCDM. [Planck 2018 VI, v4](https://arxiv.org/html/1807.06209v4) These model-dependent constraints neither establish exact zero curvature nor supply a likelihood for this radiation-only scalar state. In the usual convention `Omega_K=-d`, so positive spatial curvature uses the negative side of that parameter. `PRIMARY_ATTRIBUTION_v1.json` preserves an access/factual receipt, not a full paper or a remote-byte snapshot. No raw data, likelihood, density calibration or empirical fit was used.

## Actual independent controls

The baseline completed **107 passing, zero failing checks**. Controls include full-action origin terms, lapse/scale variations, all discriminant regimes, tensor contractions, geodesic normalization, branch-sensitive fraction elimination, exact failure probes, five numerical scale-flow profiles and six pairs of proper/null clock quadratures. The all-time completeness and branch-domain arguments are the explicit hand proof; finite samples do not replace them.

Distinct exact parameters fixed before execution were `k=2/11`, `nu=7/5`, `Q0=121/65`, `Q=11/5`, `h=2/3`, `Kc=5/2`, and strict-branch `D=9/8`. They give `Delta=4`, `Xplus=81/16`, `Xminus=9/16`, `Xm=45/16`, and bounce radiation/vacuum ratio `1/9`. The small-branch zero-X endpoints are `+/-3 log(2)/4`. The critical charge is `D=15/8`, with independent exponential amplitude `7/10`; `D=2` supplies a negative-discriminant example.

DOP853 integrated the independently derived second-order acceleration equation, without projecting the Friedmann constraint or using the analytic profile as its RHS. The largest relative X/velocity discrepancy was `4.164123617111014e-12`, below the declared `2e-10` tolerance; the largest absolute constraint residual was `2.0034729431017695e-10`, below `1e-8`. Full stored times, X and velocity samples are in `baseline_v1/RESULTS_v1.json`. Numerical integration and quadrature estimates are floating-point diagnostics, not rigorous interval enclosures.

Five actual one-location changed implementations were executed; each exited 1 with its intended equation failure:

| Changed formula | Passing/failing checks | Decisive detected error |
|---|---:|---|
| Reverse curvature sign | 100/7 | Lapse constraint and branch Friedmann equations |
| Halve critical exponential rate | 99/8 | Critical acceleration/constraint and independent ODE comparison |
| Omit Riemann spatial-curvature term | 105/2 | Both curvature invariants |
| Change fraction square-root coefficient | 103/4 | Eliminated discriminant and small-curvature expansion |
| Invert null-affine scale-factor power | 98/9 | Null normalization/time equation and clock lower bounds |

All changed scripts, exact diffs, commands, result files, stdout and stderr are retained. No baseline failure, unexpected exception or post-execution checker repair occurred. `EVIDENCE_VERIFICATION_v1.json` supplies 40/0 separate identity checks; those are not additional physics tests. Executions used Python 3.12.8, SymPy 1.14.0, NumPy 2.4.1 and SciPy 1.17.0; the actual runtime versions are also recorded in the result.

The complete supplied action, positive parameter/curvature domain, chosen origin/radiation-only state, discriminant/branch choice, complete S³ topology and classical homogeneous evolution remain explicit assumptions. This result limits an overbroad extrapolation of the flat theorem while leaving the flat theorem itself intact. It does not select a regular origin for our universe, repair the absent radiation-dominated era or assign any retained/audit grade.
