from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'curvature_loophole_packaging';dest=wt/'docs/work_history/physics/revised-scalar-curvature-loophole-20261014';dest.mkdir(parents=True,exist_ok=False)
roots=['initial_state/curvature_loophole_v1','curvature_loophole_canonical_correspondence_v1','curvature_loophole_packaging'];items=[]
for root in roots:
 for p in sorted((pk/root).rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink(),str(p)
  if '__pycache__' in p.parts or p.suffix=='.pyc':continue
  if p.name=='ARCHIVE_BUILD_v1.json':continue
  b=p.read_bytes();items.append((p.relative_to(pk).as_posix(),b))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Closed origin scalar/radiation geometry result, exact originals and independent checks; no rolling-grid/general-bounce theorem included.','exclusions':['Derived __pycache__/pyc if any; later ARCHIVE_BUILD record of archive own hash.'],'counts_are_not_new_science':True}
mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  ti=tar.getmember(row['path']);assert ti.isfile();b=tar.extractfile(ti).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
readme=f"""Recovery evidence for the revised scalar curvature milestone

Live claim: docs/EXPONENTIAL_SCALAR_CURVATURE_LOOPHOLE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Author: /root. No formal audit verdict, merge or main update.

Archive SHA256: {sha}
Archive bytes: {archive.stat().st_size}
Payloads: {len(rows)} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

The regular bounce and critical upper histories are exact standard closed-FLRW
reconstructions within the supplied scalar action. The selected radiation-only
origin, positive curvature, discriminant branch, complete S3, action and scales
remain hypotheses. No observed hot-era fit, state selection or stability claim.

Included roots preserve the original derivation, all direct/independent code,
full results, actual damaged copies and streams, commands, source snapshots,
claim correspondence and sealed reports. The formula figure is an illustration,
not an empirical fit or extra independent numerical test. Primary web attribution
is an access receipt, not a full remote paper or raw-likelihood snapshot.

Direct mathematics:81/0 and3 actual damaged copies rejected74/7,76/5,77/4.
Canonical code carries the exact same mathematical block. Two actual canonical
81/0 runs are disclosed: first v1, then refreshed after the declared note changed.
These are reruns, not new independent science.

Independent mathematics:107/0 and5 actual damages100/7,99/8,105/2,103/4,98/9.
Report SHA d9107fd68eb09178678b9532a121ed7bce2c784f542d8a1078ca5c9beb2d7386
Receipt SHA cfb2bc28f32e632ea671f9d750ee60da79e9c368cc31215407e55046b090bded
Manifest SHA 854a7cd9f183ca0705847932cff257143b31c68fc951ddbe89b16446b4ca0e48

Canonical correspondence:47/2 original, separate1/0 verifier-decimal repair,
then42/0 affected final check. The real inward-rounded literal bound was fixed
by an exact outward rational upper value; prior note/cache and source diff remain.
The other failure was a verifier prefix comparison of a correctly rounded decimal.
Report SHA 7c6de991b7143978f4b8f6929c88b5a9f2cba799f2ce363e28b762c5d265f822
Receipt SHA 83d607fe2fdbd3c117c9eb8ffeffd008baea7564428d2a285e2dc9d9650c22f0
Manifest SHA 88c8e51a04624add42e981d63b5fb1deec7b833552e3508677c745ef3dbe9e80

General causal completeness follows from the written global radius and geodesic
proof on complete S3; finite controls do not prove it alone. Energy-density ratios
and H-normalized fractions are distinct at a bounce. The illustrated d<=0.003
condition is not a transferred Planck posterior. The regular origin branches
have no radiation-energy-dominated era. Rolling-grid and later generalized
bounce-energy work are separate pending research and are not included here.

Extract only validated regular relative members into an empty directory, then
verify every manifest payload hash and size. The parent verified every payload.
The packaging build record of this archive's own hash is intentionally outside
its own archive. A separate post-commit delivery mapping will bind final Git
paths/head/tree and recovery bytes; it does not alter these science seals.
"""
(dest/'README.txt').write_text(readme);print(json.dumps(record))
