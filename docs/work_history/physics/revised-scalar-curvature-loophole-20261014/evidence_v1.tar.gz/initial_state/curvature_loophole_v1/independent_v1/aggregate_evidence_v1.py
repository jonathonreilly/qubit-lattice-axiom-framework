from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
H=Path(__file__).resolve().parent;ROOT=next(p for p in H.parents if (p/'docs').is_dir() and (p/'scripts').is_dir())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((H/n).read_text())
def write(n,x):
    p=H/n;assert not p.exists();p.write_text(json.dumps(x,indent=2)+'\n')
def bind(n):
    p=H/n;return {'path':n,'bytes':p.stat().st_size,'sha256':sha(p)}
checks=[]
def check(n,b):checks.append({'name':n,'passed':bool(b)})
sources=read('SOURCE_MANIFEST_v1.json')['sources']
for row in sources:
    live=ROOT/row['original_path'];snap=H/row['snapshot_path']
    check('source_pair.'+row['original_path'],live.read_bytes()==snap.read_bytes() and sha(live)==row['sha256'] and live.stat().st_size==row['bytes'])
protocol=read('PROTOCOL_v1.json');dp=read('DAMAGE_PROTOCOL_v1.json');baseline=read('baseline_v1/RESULTS_v1.json')
check('derivation_frozen_before_code',sha(H/'HAND_DERIVATION_v1.md')==protocol['hand_derivation_sha256'])
check('baseline_code_frozen',sha(H/'check_independent_v1.py')==dp['baseline_code_sha256']==baseline['code_sha256'])
check('baseline_107_0',baseline['counts']=={'passed':107,'failed':0,'total':107} and len(baseline['checks'])==107 and all(r['passed'] for r in baseline['checks']))
check('no_producer_access',baseline['producer_code_or_results_accessed'] is False and protocol['producer_code_or_results_accessed'] is False)
records=[]
def execution(tag,expected):
    ex=read(tag+'.json');check('execution_exit.'+tag,ex['exit_code']==expected and not ex['timed_out'])
    check('execution_code.'+tag,sha(Path(ex['command'][2]))==ex['script_sha256'])
    for key in ['stdout','stderr']:
        b=ex[key];check('execution_stream.'+tag+'.'+key,sha(H/b['path'])==b['sha256'] and (H/b['path']).stat().st_size==b['bytes'])
    records.append({'record':bind(tag+'.json'),'command':ex['command'],'cwd':ex['cwd'],'exit_code':ex['exit_code']})
    return ex
execution('baseline_execution_v1',0);controls=[];source=(H/'check_independent_v1.py').read_text()
for control in dp['controls']:
    name=control['name'];prefix='damages_v1/'+name
    exe=execution(prefix+'/execution_v1',1);result=read(prefix+'/results/RESULTS_v1.json');cmd=read(prefix+'/COMMAND_v1.json')
    changed=H/prefix/'changed.py';failed=[r['name'] for r in result['checks'] if not r['passed']]
    check('damage_exact_change.'+name,source.count(control['replace'])==1 and changed.read_text()==source.replace(control['replace'],control['with'])
          and sha(changed)==cmd['changed_sha256']==exe['script_sha256']==result['code_sha256'])
    check('damage_actual_expected_failure.'+name,control['required_failure'] in failed and len(result['checks'])==107
          and result['counts']['failed']==len(failed)>0 and result['counts']['passed']+len(failed)==107
          and cmd['command']==exe['command'])
    controls.append({'name':name,'code':bind(prefix+'/changed.py'),'source_diff':bind(prefix+'/SOURCE.diff'),
        'execution':bind(prefix+'/execution_v1.json'),'results':bind(prefix+'/results/RESULTS_v1.json'),
        'counts':result['counts'],'exit_code':exe['exit_code'],'failed_checks':failed,
        'required_failure':control['required_failure'],'detected':control['required_failure'] in failed})
write('DAMAGES_SUMMARY_v1.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'baseline_code_sha256':sha(H/'check_independent_v1.py'),
    'controls':controls,'all_detected':all(c['detected'] and c['exit_code']==1 for c in controls),'actual_damaged_implementations':5})
write('FAILURES_v1.json',{'unexpected_execution_failures':[],'failed_baseline_checks':[],
    'expected_actual_damage_failures':[{'name':c['name'],'counts':c['counts'],'exit_code':c['exit_code'],'failed_checks':c['failed_checks']} for c in controls],
    'source_corrections_requested':[],'checker_repairs_after_execution':[],'all_failed_controls_preserved':True,
    'no_runs_repeated_to_change_counts':True})
write('COMMAND_INDEX_v1.json',{'executions':records,'exact_child_commands_recorded':True,
    'wrapper':'run_recorded_v1.py','parallelism':'Five independent altered-code children ran concurrently; no agents spawned.',
    'external_read_only_attribution':'PRIMARY_ATTRIBUTION_v1.json; web.run accessed only the cited primary source, no empirical fit.'})
write('EVIDENCE_VERIFICATION_v1.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,
    'counts':{'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'total':len(checks)},
    'scope':'Identity/receipt checks, not additional science controls.'})
print(json.dumps({'metadata_counts':{'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks)},
    'failed_metadata':[r for r in checks if not r['passed']],
    'damages':[{'name':c['name'],'counts':c['counts'],'exit_code':c['exit_code']} for c in controls]},indent=2))
sys.exit(any(not r['passed'] for r in checks))
