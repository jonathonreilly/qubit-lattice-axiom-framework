"""Blind independent closed-radiation check from lapse action and scale ODE."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,math,platform,sys
import sympy as s
import numpy as np
import scipy
from scipy.integrate import solve_ivp,quad

CURVATURE_SIGN = -1
CRITICAL_RATE = 1
SPATIAL_CURVATURE_FACTOR = 1
FRACTION_ROOT_COEFFICIENT = 2
NULL_AFFINE_POWER = 1

ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
rows=[];details={}
def check(name,ok,witness=None):rows.append({'name':name,'passed':bool(ok),'witness':witness})
def zero(name,expr):
    value=s.simplify(s.trigsimp(expr));check(name,value==0,str(value))
def positive(name,expr):check(name,s.simplify(expr).is_positive is True,str(s.simplify(expr)))

# Complete origin scalar configuration, using all supplied potential terms.
k,nu,u,x,y=s.symbols('k nu u x y',real=True)
ak=(1-k)*(1+3*k)/4;alpha=s.sqrt(ak);ss=(1+k)/(k*(1-3*k))
E=s.exp(2*alpha*u);F=1+ss*E;J=1+(1-3*ak)*ss*E
U=s.Rational(3,2)+3*ss*(E-1)**2/(2*F**2)+k*x*x*s.exp(-(1-k)*u/alpha)/2+k*y*y*s.exp(-(1+k)*u/alpha)/3+nu*(1+ss)*u*u/(2*F**2)
C=(1+ss)*E/F;origin={u:0,x:0,y:0}
zero('action.origin_C',C.subs(origin)-1);zero('action.origin_U',U.subs(origin)-s.Rational(3,2))
for z in [u,x,y]:zero('action.origin_gradient_'+str(z),s.diff(U,z).subs(origin))
rho=s.symbols('rho',positive=True);zero('action.radiation_trace',rho-3*rho/3)
kv=s.Rational(2,11);nv=s.Rational(7,5);Q0=s.Rational(121,65)
zero('action.Q_binding',Q0*(1+kv)-s.Rational(11,5))
Dfield=1+2*(1+k)*(x*x+y*y)/3
for i,entry in enumerate([J/F**2,(1+ss)*4*k/(9*F*Dfield),(1+ss)*k/(3*F*Dfield)]):
    positive('action.origin_K_'+str(i),entry.subs(origin).subs(k,kv))
positive('action.dust_has_nonzero_u_coupling',(s.diff(s.log(C),u)/2).subs(origin).subs(k,kv))

# Independent lapse and scale variation of the homogeneous action.
a,v,w,N,Q,h,K,D=s.symbols('a v w N Q h K D',positive=True)
L=-3*Q*a*v*v/N+3*Q*K*N*a-3*Q*h*h*N*a**3-3*Q*D*D*N/a
lapse=s.diff(L,N).subs(N,1)/(3*Q*a**3)
H2=h*h+D*D/a**4+CURVATURE_SIGN*K/a**2
zero('lapse.friedmann_sign_and_normalization',lapse-(v*v/a**2-H2))
dLdv=s.diff(L,v).subs(N,1)
EL=s.diff(dLdv,a)*v+s.diff(dLdv,v)*w-s.diff(L,a).subs(N,1)
scale_w=s.solve(EL,w)[0]
zero('scale.acceleration_from_variation',(scale_w/a).subs(v*v,a*a*(h*h+D*D/a**4-K/a**2))-(h*h-D*D/a**4))
zero('scale.Hdot_from_constraint',h*h-D*D/a**4-H2-(K/a**2-2*D*D/a**4))
zero('scale.radiation_pressure',-s.diff(3*Q*D*D/a,a)/(3*a*a)-Q*D*D/a**4)

# Solve the acceleration equation without dividing by a vanishing H or Xdot.
t,delta=s.symbols('t delta',real=True);delta=s.symbols('delta',positive=True)
X,V=s.symbols('X V',positive=True)
Xacc=4*h*h*X-2*K
zero('scale.X_acceleration',2*(X*(h*h+D*D/X**2-K/X)+X*(h*h-D*D/X**2))-Xacc)
p,q=s.symbols('p q',real=True);Xm=K/(2*h*h)
general=Xm+p*s.exp(2*h*t)+q*s.exp(-2*h*t)
zero('branches.general_acceleration',s.diff(general,t,2)-(4*h*h*general-2*K))
res=s.expand(s.diff(general,t)**2-4*(h*h*general**2-K*general+D*D))
zero('branches.general_product_constraint',res-((K*K-4*h*h*D*D)/h**2-16*h*h*p*q))
Ds=(K*K-delta*delta)/(4*h*h)
upper=(K+delta*s.cosh(2*h*t))/(2*h*h)
lower=(K-delta*s.cosh(2*h*t))/(2*h*h)
def background_checks(prefix,xx,ds):
    hh=s.diff(xx,t)/(2*xx)
    zero(prefix+'.friedmann',s.diff(xx,t)**2-4*xx**2*(h*h+ds/xx**2+CURVATURE_SIGN*K/xx))
    zero(prefix+'.acceleration',s.diff(xx,t,2)-(4*h*h*xx-2*K))
    zero(prefix+'.raychaudhuri',s.diff(hh,t)-(K/xx-2*ds/xx**2))
background_checks('branches.strict_upper',upper,Ds)
background_checks('branches.strict_lower',lower,Ds)
xp=(K+delta)/(2*h*h);xm=(K-delta)/(2*h*h)
zero('bounce.H_zero',s.diff(upper,t).subs(t,0))
zero('bounce.Hdot',s.diff(s.diff(upper,t)/(2*upper),t).subs(t,0)-delta/xp)
zero('branches.roots_product',xp*xm-Ds/h**2)
zero('branches.simple_root_is_not_static',4*h*h*xp-2*K-2*delta)
B=s.symbols('B',positive=True);critical=Xm+B*s.exp(CRITICAL_RATE*h*t);critical_ds=K*K/(4*h*h)
background_checks('branches.critical_upper',critical,critical_ds)
zero('critical.static_equilibrium',4*h*h*Xm-2*K)
zero('critical.static_constraint',h*h*Xm*Xm-K*Xm+critical_ds)
zero('critical.fixed_time_cosh_limit',s.limit(upper,delta,0)-Xm)
critical_lower=Xm-B*s.exp(CRITICAL_RATE*h*t)
background_checks('branches.critical_lower',critical_lower,critical_ds)
negative=Xm+delta*s.sinh(2*h*t)/(2*h*h)
background_checks('branches.negative_discriminant',negative,(K*K+delta*delta)/(4*h*h))
zero('vacuum.closed_deSitter',upper.subs(delta,K)-K*s.cosh(h*t)**2/h**2)

# Explicit tensor contraction retains the spatial curvature contribution.
AA,BB=s.symbols('AA BB',real=True);sgn=[-1,1,1,1]
R={}
for i in range(1,4):
    R[(0,i,0,i)]=-AA;R[(i,0,0,i)]=AA;R[(0,i,i,0)]=AA;R[(i,0,i,0)]=-AA
for i in range(1,4):
 for j in range(1,4):
  for m in range(1,4):
   for n in range(1,4):R[(i,j,m,n)]=BB*(int(i==m)*int(j==n)-int(i==n)*int(j==m))
ricci=sum(sgn[i]*sgn[j]*R.get((j,i,j,i),0) for i in range(4) for j in range(4))
kretsch=sum(sgn[i]*sgn[j]*sgn[m]*sgn[n]*val**2 for (i,j,m,n),val in R.items())
zero('curvature.tensor_Ricci_contraction',ricci-6*(AA+BB))
zero('curvature.tensor_Kretschmann_contraction',kretsch-12*(AA*AA+BB*BB))
Aval=h*h-D*D/X**2;Bval=h*h+D*D/X**2+(SPATIAL_CURVATURE_FACTOR-1)*K/X
zero('curvature.closed_Ricci',ricci.subs({AA:Aval,BB:Bval})-12*h*h)
zero('curvature.closed_Kretschmann',kretsch.subs({AA:Aval,BB:Bval})-24*(h**4+D**4/X**4))
zero('curvature.singular_coefficient',s.limit(X**4*24*(h**4+D**4/X**4),X,0)-24*D**4)

# Spatial momentum/redshift, timelike normalization and null affine equation.
P,adot,HH,tdot,qsp=s.symbols('P adot HH tdot qsp',positive=True)
zero('geodesic.spatial_P_conservation',4*a**3*(HH*a*tdot)*qsp+a**4*(-4*HH*tdot*qsp))
timelike_rate=1/s.sqrt(1+P*P/a**2)
zero('geodesic.timelike_normalization',-1/timelike_rate**2+P*P/a**2+1)
zero('geodesic.timelike_time_equation',s.diff(1/timelike_rate,a)*HH*a/timelike_rate+HH*P*P/a**2)
null_rate=a**NULL_AFFINE_POWER/P
zero('geodesic.null_normalization',-1/null_rate**2+P*P/a**2)
zero('geodesic.null_time_equation',s.diff(1/null_rate,a)*HH*a/null_rate+HH*P*P/a**2)
positive('geodesic.timelike_rate_increases_with_a',s.diff(timelike_rate,a))
positive('geodesic.null_rate_increases_with_a',s.diff(null_rate,a))

# Branch-aware fraction inverse and non-dominance, independently eliminated.
d=s.symbols('d',positive=True)
f=(1+d-s.sqrt(1+FRACTION_ROOT_COEFFICIENT*d))/2
zero('fractions.bound_saturates_discriminant',d*d-4*(1+d-f)*f)
zero('fractions.stable_bound_form',f-d*d/(2*(1+d+s.sqrt(1+2*d))))
zero('fractions.small_d_expansion',s.series(f,d,0,5).removeO()-(d*d/4-d**3/4+5*d**4/16))
zero('fractions.derivative_positive_form',s.diff(f,d)-d/(s.sqrt(1+2*d)*(1+s.sqrt(1+2*d))))
positive('fractions.monotone_bound',d/(s.sqrt(1+2*d)*(1+s.sqrt(1+2*d))))
Lfr=h*h/(h*h+D*D/X**2-K/X);rfr=(D*D/X**2)/(h*h+D*D/X**2-K/X);dfr=(K/X)/(h*h+D*D/X**2-K/X)
zero('fractions.constraint',Lfr+rfr-dfr-1)
zero('fractions.discriminant_conversion',dfr*dfr-4*Lfr*rfr-(K*K-4*h*h*D*D)/(X*X*(h*h+D*D/X**2-K/X)**2))
zero('fractions.bounce_energy_ratio',Ds/(h*h*xp*xp)-(K-delta)/(K+delta))
zero('fractions.critical_static_energy_ratio',critical_ds/(h*h*Xm*Xm)-1)

# Distinct exact witnesses fixed in HAND_DERIVATION before execution.
hv=s.Rational(2,3);kc=s.Rational(5,2);dv=s.Rational(9,8);qv=s.Rational(11,5)
pars={h:hv,K:kc,D:dv};deltav=kc*kc-4*hv*hv*dv*dv
zero('exact.Delta',deltav-4);zero('exact.Xplus',xp.subs({h:hv,K:kc,delta:2})-s.Rational(81,16))
zero('exact.Xminus',xm.subs({h:hv,K:kc,delta:2})-s.Rational(9,16))
zero('exact.Xm',Xm.subs(pars)-s.Rational(45,16))
zero('exact.small_branch_endpoint',lower.subs({h:hv,K:kc,delta:2,t:3*s.log(2)/4}))
zero('exact.bounce_density_ratio',dv*dv/(hv*hv*s.Rational(81,16)**2)-s.Rational(1,9))
dc=s.Rational(15,8);zero('exact.critical_charge',kc*kc-4*hv*hv*dc*dc)
zero('exact.negative_discriminant',kc*kc-4*hv*hv*4+s.Rational(31,36))
small={**pars,X:s.Rational(1,4)};near={**pars,X:s.Rational(81,16)+s.Rational(1,100)}
positive('negative_control.lower_branch_has_L_less_r',(rfr-Lfr).subs(small))
positive('negative_control.lower_branch_violates_upper_fraction_bound',(rfr-f.subs(d,dfr)).subs(small))
positive('negative_control.near_bounce_normalized_r_above_one',rfr.subs(near)-1)
positive('negative_control.near_bounce_radiation_energy_below_vacuum',(h*h-D*D/X**2).subs(near))
positive('negative_control.simple_root_fails_static_acceleration',(4*h*h*xp-2*K).subs({h:hv,K:kc,delta:2}))
benchmark=s.N(f.subs(d,s.Rational(3,1000)),45)
details['fraction_bound_d_003']=str(benchmark)
details['exact_parameters']={'k':str(kv),'nu':str(nv),'Q0':str(Q0),'Q':str(qv),'h':str(hv),'Kc':str(kc),'D':str(dv),
                             'Delta':str(deltav),'critical_D':str(dc),'B':'7/10'}

# Independent numerical flow: acceleration equation, not analytic formula RHS.
hf=float(hv);kf=float(kc);Df=float(dv);xp_f=81/16;xm_f=9/16;mid_f=45/16
def ode(tt,yy):return [yy[1],4*hf*hf*yy[0]-2*kf]
numerics=[]
for branch,xx,vv,end,charge in [
 ('strict_upper_past',xp_f,0.,-2.1,Df),('strict_upper_future',xp_f,0.,2.35,Df),
 ('strict_lower',xm_f,0.,.45,Df),('critical_upper_past',mid_f+.7,2*hf*.7,-3.3,float(dc)),
 ('critical_upper_future',mid_f+.7,2*hf*.7,2.65,float(dc))]:
    times=np.linspace(0,end,39);sol=solve_ivp(ode,(0,end),[xx,vv],t_eval=times,method='DOP853',rtol=2e-12,atol=1e-13)
    if branch.startswith('strict_upper'):
        exactx=mid_f+2.25*np.cosh(2*hf*times);exactv=4.5*hf*np.sinh(2*hf*times)
    elif branch=='strict_lower':
        exactx=mid_f-2.25*np.cosh(2*hf*times);exactv=-4.5*hf*np.sinh(2*hf*times)
    else:
        exactx=mid_f+.7*np.exp(CRITICAL_RATE*hf*times);exactv=CRITICAL_RATE*hf*.7*np.exp(CRITICAL_RATE*hf*times)
    errx=float(np.max(np.abs(sol.y[0]-exactx)/(1+np.abs(exactx))))
    errv=float(np.max(np.abs(sol.y[1]-exactv)/(1+np.abs(exactv))))
    residual=float(np.max(np.abs(sol.y[1]**2-4*(hf*hf*sol.y[0]**2-kf*sol.y[0]+charge*charge))))
    check('ode.'+branch+'.completed',sol.success and len(sol.t)==len(times))
    check('ode.'+branch+'.exact_solution',max(errx,errv)<2e-10,{'x_relative':errx,'v_relative':errv})
    check('ode.'+branch+'.constraint',residual<1e-8,residual)
    check('ode.'+branch+'.positive_scale',bool(np.min(sol.y[0])>0),float(np.min(sol.y[0])))
    numerics.append({'branch':branch,'times':sol.t.tolist(),'X':sol.y[0].tolist(),'V':sol.y[1].tolist(),
                     'max_relative_error':max(errx,errv),'constraint_absolute':residual,'nfev':sol.nfev})
details['ode_profiles']=numerics
clocks=[];mom=13/7
for family,xfun,amin in [('bounce',lambda tt:mid_f+2.25*math.cosh(2*hf*tt),2.25),
                        ('critical',lambda tt:mid_f+.7*math.exp(CRITICAL_RATE*hf*tt),math.sqrt(mid_f))]:
    for T in [1/3,4/3,7/3]:
        proper,pe=quad(lambda tt:1/math.sqrt(1+mom*mom/xfun(tt)),-T,T,epsabs=2e-11,epsrel=2e-11)
        null,ne=quad(lambda tt:xfun(tt)**(NULL_AFFINE_POWER/2)/mom,-T,T,epsabs=2e-11,epsrel=2e-11)
        tlow=2*T/math.sqrt(1+mom*mom/(amin*amin));nlow=2*T*amin/mom
        check('clock_quad.'+family+'.proper.'+str(T),proper+2e-10>=tlow,{'integral':proper,'lower':tlow})
        check('clock_quad.'+family+'.null.'+str(T),null+2e-10>=nlow,{'integral':null,'lower':nlow})
        clocks.append({'family':family,'T':T,'proper':proper,'proper_error':pe,'proper_lower':tlow,'null_affine':null,'null_error':ne,'null_lower':nlow})
details['clock_quadratures']=clocks
result={'schema':'independent-curved-radiation-math-check-v1','created_utc':datetime.now(timezone.utc).isoformat(),
    'scientific_author':'/root','checker':'/root/local_response_check','producer_code_or_results_accessed':False,
    'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'constants':{'curvature_sign':CURVATURE_SIGN,'critical_rate':CRITICAL_RATE,'spatial_curvature_factor':SPATIAL_CURVATURE_FACTOR,
                 'fraction_root_coefficient':FRACTION_ROOT_COEFFICIENT,'null_affine_power':NULL_AFFINE_POWER},
    'versions':{'python':sys.version,'sympy':s.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform()},
    'counts':{'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'total':len(rows)},
    'checks':rows,'details':details,
    'limits':'Exact algebra plus finite numerical controls; causal completeness and all-time branch inequalities use the explicit hand proof. No empirical likelihood, full scalar perturbation stability or state selection.'}
(out/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'failed_checks':[r for r in rows if not r['passed']],
                  'fraction_bound_d_003':str(benchmark),'max_ode_relative_error':max(r['max_relative_error'] for r in numerics)},indent=2))
sys.exit(any(not r['passed'] for r in rows))
