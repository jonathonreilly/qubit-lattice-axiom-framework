"""Preserve exact command, code hash, stdout, stderr, return code for every run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys

here = Path(__file__).resolve().parent
tag, script = sys.argv[1:3]
target = (here / script).resolve()
assert target.is_relative_to(here)
assert not (here / (tag+'.json')).exists()
command = [sys.executable, '-B', str(target), *sys.argv[3:]]
start = datetime.now(timezone.utc).isoformat()
try:
    done = subprocess.run(command, cwd=here, capture_output=True, timeout=180)
    stdout, stderr, code = done.stdout, done.stderr, done.returncode
    timed_out = False
except subprocess.TimeoutExpired as exc:
    stdout, stderr = exc.stdout or b'', exc.stderr or b''
    stderr += b'\nRECORDED_TIMEOUT_AFTER_180_SECONDS\n'
    code, timed_out = 124, True
row = {'command': command, 'cwd': str(here), 'started_utc': start,
       'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': code,
       'timeout_seconds': 180, 'timed_out': timed_out,
       'script_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
for kind, data in [('stdout', stdout), ('stderr', stderr)]:
    name = tag+'.'+kind+'.txt'
    (here/name).write_bytes(data)
    row[kind] = {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(here/(tag+'.json')).write_text(json.dumps(row, indent=2)+'\n')
print(json.dumps(row, indent=2))
