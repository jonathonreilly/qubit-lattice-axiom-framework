"""Seal only this independent curvature check; no source/Git/runtime writes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
H=Path(__file__).resolve().parent;ROOT=next(p for p in H.parents if (p/'docs').is_dir() and (p/'scripts').is_dir())
start=datetime.now(timezone.utc).isoformat()
assert not (H/'MANIFEST_v1.json').exists() and not (H/'RECEIPT_v1.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((H/n).read_text())
def write(n,x):
    p=H/n;assert not p.exists();p.write_text(json.dumps(x,indent=2)+'\n')
def bind(n):
    p=H/n;return {'path':n,'bytes':p.stat().st_size,'sha256':sha(p)}
sources=read('SOURCE_MANIFEST_v1.json')['sources']
for row in sources:
    live=ROOT/row['original_path'];snap=H/row['snapshot_path']
    assert not live.is_symlink() and not snap.is_symlink()
    assert live.read_bytes()==snap.read_bytes() and sha(live)==row['sha256'] and live.stat().st_size==row['bytes']
baseline=read('baseline_v1/RESULTS_v1.json');damages=read('DAMAGES_SUMMARY_v1.json')
assert baseline['counts']=={'passed':107,'failed':0,'total':107}
assert baseline['producer_code_or_results_accessed'] is False
assert sha(H/'check_independent_v1.py')==baseline['code_sha256']==read('DAMAGE_PROTOCOL_v1.json')['baseline_code_sha256']
assert sha(H/'HAND_DERIVATION_v1.md')==read('PROTOCOL_v1.json')['hand_derivation_sha256']
assert read('EVIDENCE_VERIFICATION_v1.json')['counts']=={'passed':40,'failed':0,'total':40}
tags=['baseline_execution_v1','evidence_verification_execution_v1']
for item in damages['controls']:
    assert item['detected'] and item['exit_code']==1
    for key in ['code','source_diff','execution','results']:
        b=item[key];assert sha(H/b['path'])==b['sha256'] and (H/b['path']).stat().st_size==b['bytes']
    tags.append('damages_v1/'+item['name']+'/execution_v1')
assert len(damages['controls'])==5 and damages['all_detected']
execution_records=[]
for tag in tags:
    x=read(tag+'.json');expected=1 if tag.startswith('damages_v1/') else 0
    assert x['exit_code']==expected and not x['timed_out']
    assert sha(Path(x['command'][2]))==x['script_sha256']
    for key in ['stdout','stderr']:
        b=x[key];assert sha(H/b['path'])==b['sha256'] and (H/b['path']).stat().st_size==b['bytes']
    execution_records.append(bind(tag+'.json'))
write('SOURCE_CONFIRMATION_v1.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
    'source_pairs':sources,'whole_source_and_action_read':True,'unchanged_at_seal':True,
    'substantive_source_corrections_requested':[],'producer_code_or_results_accessed':False,
    'independent_baseline':baseline['counts'],'actual_damaged_copies':5,
    'bounded_conclusion':'The exact closed origin/radiation reconstruction is consistent; causal completeness requires the stated complete S3 and all-time positive scale factor. No state selection, radiation era or empirical validation follows.',
    'corrected_source_confirmation':'Not applicable: no author correction required.'})
write('SEAL_EXECUTION_v1.json',{'started_utc':start,'finished_pre_manifest_utc':datetime.now(timezone.utc).isoformat(),
    'command':[sys.executable,'-B',str(Path(__file__).resolve())],'cwd':str(H),'script_sha256':sha(Path(__file__)),
    'source_pairs_verified':len(sources),'execution_records_verified':len(execution_records),
    'operation':'Verify sources and actual execution identities; then hash all artifacts and seal receipt. No writes after successful seal.'})
artifacts=[]
for p in sorted(H.rglob('*')):
    assert not p.is_symlink(),str(p)
    if p.is_file():artifacts.append(bind(str(p.relative_to(H))))
write('MANIFEST_v1.json',{'schema':'independent-curvature-loophole-artifact-manifest-v1',
    'created_utc':datetime.now(timezone.utc).isoformat(),'unit':str(H.relative_to(ROOT)),
    'artifact_count':len(artifacts),'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts})
receipt={'schema':'independent-curvature-loophole-receipt-v1','created_utc':datetime.now(timezone.utc).isoformat(),
    'unit':str(H.relative_to(ROOT)),'scientific_author':'/root','independent_checker':'/root/local_response_check',
    'formal_audit':False,'formal_grade_or_authority_state_changed':False,
    'scope':'Blind focused independent action/branch/curvature/causal-clock/fraction check, standard reconstruction only.',
    'report':bind('REPORT_v1.md'),'manifest':bind('MANIFEST_v1.json'),'artifact_count':len(artifacts),
    'source_bindings':sources,'source_pair_count':len(sources),'source_confirmation':bind('SOURCE_CONFIRMATION_v1.json'),
    'hand_derivation':bind('HAND_DERIVATION_v1.md'),'protocol':bind('PROTOCOL_v1.json'),
    'independent_code':bind('check_independent_v1.py'),'baseline_execution':bind('baseline_execution_v1.json'),
    'baseline_results':bind('baseline_v1/RESULTS_v1.json'),'baseline_counts':baseline['counts'],
    'damage_protocol':bind('DAMAGE_PROTOCOL_v1.json'),'damage_summary':bind('DAMAGES_SUMMARY_v1.json'),
    'actual_damage_counts':[{'name':x['name'],'counts':x['counts'],'exit_code':x['exit_code']} for x in damages['controls']],
    'failure_ledger':bind('FAILURES_v1.json'),'commands':bind('COMMAND_INDEX_v1.json'),
    'execution_records':execution_records,'evidence_verification':bind('EVIDENCE_VERIFICATION_v1.json'),
    'metadata_counts':{'passed':40,'failed':0,'total':40},'seal_execution':bind('SEAL_EXECUTION_v1.json'),
    'primary_attribution_check':bind('PRIMARY_ATTRIBUTION_v1.json'),
    'independence':{'derived_before_code':True,'producer_code_or_results_accessed':False,
        'independent_lapse_scale_variations':True,'independent_tensor_contraction':True,
        'independent_second_order_ODE':True,'exact_and_numerical_controls':True,'actual_changed_code_executions':True},
    'claim_boundaries':['Supplied action and positive parameter/curvature domain remain assumptions.',
        'Origin scalar state, radiation-only matter, complete S3 and branch/discriminant choices are not selected.',
        'Causal completeness is for the exact classical homogeneous regular upper spacetimes, not nonlinear or quantum stability.',
        'Small and lower critical branches can be singular; positive Delta alone does not select a regular branch.',
        'Present fractions require nonzero expanding H and L>r; d=-Omega_K in the usual convention.',
        'No radiation-dominated energy era, observed fit or empirical acceptance is supplied.',
        'Numerical profiles and quadratures are diagnostics, not rigorous error-enclosed all-time proofs.'],
    'source_finding':'No substantive correction required for frozen v1.',
    'git_or_runtime_mutations':0,'prior_seals_modified':False,'new_agents':0}
write('RECEIPT_v1.json',receipt)
for b in artifacts:
    p=H/b['path'];assert sha(p)==b['sha256'] and p.stat().st_size==b['bytes']
assert sha(H/'MANIFEST_v1.json')==receipt['manifest']['sha256']
print(json.dumps({'unit':str(H),'artifacts':len(artifacts),'source_pairs':len(sources),
    'report_sha256':sha(H/'REPORT_v1.md'),'manifest_sha256':sha(H/'MANIFEST_v1.json'),
    'receipt_sha256':sha(H/'RECEIPT_v1.json'),'sealed':True},indent=2))
