from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json,hashlib
out=Path(__file__).parent
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
t=np.linspace(-3,3,1001);tf=np.linspace(.015,3,700)
xb=(3+np.sqrt(5)*np.cosh(2*t))/2;xc=1+np.exp(2*t);xf=np.sinh(2*tf)
hb=np.sqrt(5)*np.sinh(2*t)/(2*xb);hc=np.exp(2*t)/xc;hf=np.cosh(2*tf)/xf
colors=['#176B9A','#B9681A','#747474'];fig,axs=plt.subplots(2,2,figsize=(12,8),layout='constrained')
labels=['Closed bounce: Kc=3','Critical upper branch: Kc=2','Flat radiation history: Kc=0']
for tt,xx,hh,c,lab in zip([t,t,tf],[xb,xc,xf],[hb,hc,hf],colors,labels):
 axs[0,0].plot(tt,np.sqrt(xx),color=c,label=lab,lw=2)
 axs[0,1].plot(tt,hh,color=c,lw=2)
 axs[1,0].plot(tt,1/xx**2,color=c,lw=2)
axs[0,0].set(xlabel='Chosen cosmic time, h t',ylabel='Scale factor a',title='A positive minimum radius is possible')
axs[0,0].legend(frameon=False,fontsize=9,loc='upper center')
axs[0,1].axhline(0,color='#333333',lw=.7);axs[0,1].set(xlabel='Chosen cosmic time, h t',ylabel='H / h',ylim=(-1.2,2.5),title='Bounce and always-expanding regular branch')
axs[1,0].axhline(1,color='#333333',lw=.8,ls='--');axs[1,0].set(xlabel='Chosen cosmic time, h t',ylabel='Radiation energy / vacuum energy',yscale='log',ylim=(1e-6,1e4),title='Regular branches never exceed the vacuum energy')
d=np.logspace(-5,0,500);r=d*d/(2*(1+d+np.sqrt(1+2*d)))
axs[1,1].loglog(d,r,color=colors[0],lw=2,label='Exact upper bound')
axs[1,1].loglog(d,d*d/4,color='#747474',ls='--',label='Small-curvature approximation')
d0=.003;r0=d0*d0/(2*(1+d0+np.sqrt(1+2*d0)))
axs[1,1].scatter([d0],[r0],color=colors[1],zorder=4)
axs[1,1].annotate('Illustration only\nd=0.003; r≤2.2433×10⁻⁶',xy=(d0,r0),xytext=(.012,1e-8),arrowprops={'arrowstyle':'-','color':colors[1]},fontsize=9)
axs[1,1].set(xlabel='Present curvature fraction d = Kc / (a₀² H₀²)',ylabel='Maximum present radiation fraction r',title='Small curvature strongly restricts this exact class')
axs[1,1].legend(frameon=False,fontsize=9)
for ax in axs.ravel():ax.grid(alpha=.16)
fig.suptitle('Exact radiation + constant scalar vacuum histories',fontsize=16)
fig.supxlabel('Synthetic examples use h=D=1 and freely chosen time origins. No cosmological fit, selected initial state or stability claim.',fontsize=10)
fig.savefig(out/'CURVATURE_BRANCHES_v1.png',dpi=180)
fig.savefig(out/'CURVATURE_BRANCHES_v1.svg')
record={'scope':'Exact-formula illustrations, not solver evidence or observed constraints','h':1,'D':1,'Kc':[3,2,0],'time_origins':'freely chosen for display','sample_points':{'regular_each':len(t),'flat':len(tf),'fraction':len(d)},'illustrative_d':d0,'illustrative_r_bound':r0,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out/'FIGURE_METADATA_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
