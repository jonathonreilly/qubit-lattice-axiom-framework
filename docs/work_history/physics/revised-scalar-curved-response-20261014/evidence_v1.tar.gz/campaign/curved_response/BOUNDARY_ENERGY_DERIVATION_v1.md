# Derive the static boundary restriction from exterior energy

Direct author /root, 2026-10-13. This is an extension to DERIVATION_v1/v2,
not a cosmological initial-state prescription. Symbols and candidate action
are the same. No data, selected constants, formal audit or empirical claim.

The static Green calculation used a bounded background-horizon branch. Ask
whether that restriction is independent, or follows from a physically stated
finite-energy class. The point-source ultraviolet singularity must not be
hidden: work on every fixed exterior annulus x0<=x<1 with x0>0. For a finite
body, take x0 outside it. No global finite-energy point-source claim follows.

For a real canonical scalar perturbation phi=delta varphi, its quadratic
Killing energy on the exact de Sitter static patch is, up to a positive
constant depending on the action and units,

    E_ext=1/2 integral_x0^1 x^2 [phi_tau^2/f+f phi_x^2+B phi^2] dx,
    f=1-x^2, tau=H_v t.                                  (9)

This follows by contracting the canonical scalar stress with the static
Killing field and slice normal. The lapse factor cancels the proper radial
volume factor in the static gradient/potential terms. It is Killing energy,
not a claim of a global de Sitter timelike symmetry beyond the static patch.
For static solutions the first term is zero. The constant vacuum stress is
part of the background and is excluded from this quadratic excitation energy.

Let y_R=psi/x be the positive bounded solution constructed earlier. Reduction
of order gives a second independent exterior solution

    y_Q(x)=y_R(x) integral^x dt/[t^2(1-t^2)y_R(t)^2].    (10)

Writing q=y_R(1)>0, as x tends to 1 from below,

    y_Q=-(1/(2q)) log(1-x)+O(1),
    y_Q'=1/[2q(1-x)]+O(|log(1-x)|).

Any nonzero y_Q component therefore makes the static gradient contribution
to (9) diverge logarithmically; a bounded component cannot cancel the leading
positive square. The y_R component has finite exterior energy. Thus among
stationary solutions with the specified source, FINITE EXTERIOR QUADRATIC
KILLING ENERGY implies the bounded horizon branch and the earlier unique
Green kernel. The branch need not be supplied independently after that
energy class is stipulated. Finiteness of this whole exterior energy has
not been measured by local observations; it remains an explicit condition.

This implication does not infer stationarity, the vacuum environment, source
turn-on time, retarded boundary data or our universe's six-state history.
There can be finite-energy time-dependent transients. To show a finite-time
history converges to this particular stationary kernel would require a
separate evolution and local-decay argument, not just (9) or positivity.

## Homogeneous radial dynamics and a restricted stability consequence

For source-free differences on the fixed vacuum background, set
rho=atanh(x), psi=x phi. The angular harmonic with index j=0,1,2,... obeys

    psi_tautau-psi_rhorho+V_j(rho)psi=0,
    V_j=(1-x^2)[B-2+j(j+1)/x^2].                       (11)

The action's B>12 makes V_j nonnegative. For regular-center perturbations,
psi=O(x^(j+1)), and finite-energy horizon behavior, the corresponding
positive wave energy is

    E_psi=1/2 integral_0^infinity
        [psi_tau^2+psi_rho^2+V_j psi^2] d rho.

For j=0, direct integration by parts gives

    E_phi=E_psi-1/2 [f psi^2/x]_boundaries.             (12)

The boundary term vanishes for regular-center perturbations and bounded or
logarithmic static horizon profiles. On an exterior annulus its finite
inner value does not affect the horizon finiteness test. Angular energy
adds the same positive j(j+1) term in both representations.

There is no nonzero separated homogeneous growing mode e^(s tau) w(rho)
with Re(s)>0, regular center and the outgoing/finite-energy horizon branch.
At infinity that branch behaves as exp(-s rho); at the center it is regular.
Multiplying -w''+V_j w=-s^2 w by its conjugate and integrating gives

    integral(|w'|^2+V_j|w|^2)+s^2 integral|w|^2=0.

The integrals are finite for those modes and boundary terms vanish. Its
imaginary part forces Im(s)=0 when Re(s)>0, and then its real part is a sum
of nonnegative terms including a strictly positive s^2 norm. Contradiction.
This is a linear fixed-background scalar-mode statement. It does not prove
a nonlinear cosmological attractor, a decay rate, absence of all nonmodal
effects, global metric stability or convergence after a source turns on.
It derives a useful consistency condition from the supplied positive mass,
while leaving the observed environment and initial state open.

This v1 is a direct derivation pending controls and a focused independent
check. Finite energy is named as a premise and not counted as an empirically
retired cosmological assumption.
