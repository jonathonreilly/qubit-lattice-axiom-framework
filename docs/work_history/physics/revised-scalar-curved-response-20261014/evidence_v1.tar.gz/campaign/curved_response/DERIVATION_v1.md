# Direct-author curved vacuum response, v1

Author: /root. 2026-10-13. Conditional mathematics under a supplied action;
no new observation, fitted parameter, initial-state selector or audit grade.
This block replaces one flat-background calculation with a curved-background
calculation. It does not identify our environment with the candidate vacuum.

## Question and fixed hypotheses

The preceding inverse/readout calculation has been independently checked.
Its two-radius inverse assumes a flat static Yukawa response. In this action,
at nu=1 and small k, sensitivity to the scalar range occurs at H_v r/c near
1/4. Weak coupling does not by itself make curvature negligible there.
Derive the response and an actual local readout before interpreting that
flat-space inverse. All previous observations are exposed development context;
the calculations below use exact identities and synthetic parameters only.

Use the supplied Einstein action Q integral sqrt(-g)[R/2-K_AB dphi^A dphi^B
-2 H_v^2 U]+S_m[C g,psi], with signature -+++, Q=Q0(1+k)>0,
0<k<1/3, nu>0. At its stationary vacuum phi=0, U=3/2, C=1,
the canonical matter-coupled scalar varphi satisfies

    alpha_m^2=k,  m_u^2/H_v^2=B=4[3(1+k)+nu]/(1-3k)>12.

The other two scalar directions have zero linear matter coupling. These
identities were personally and independently checked in earlier blocks;
the complete supplied action is frozen as an input to this block. They do
not derive that action or its constants. Write H=H_v/c, mu=m_u/c,
x=H r, beta=mu/H=sqrt(B), and m=Gstar M/c^2, Gstar=1/(8 pi Q).

The source is a prescribed, weak, static, central nonrelativistic source;
pressure/stress in its scalar trace are negligible. The point limit is used
first. Work to first order in m and the scalar amplitude, on compact exterior
domains with m/(r f)<<1 and |alpha_m delta varphi|<<1, f=1-H^2 r^2.
At a constant vacuum the scalar excitation stress starts at second order;
the nonzero constant potential already supplies the background de Sitter
curvature. The regular background-horizon boundary condition is stated,
not inferred from cosmological initial data or from a retarded evolution.
The linear metric expansion is not asserted uniform at either horizon.

## Scalar equation, source normalization and boundary

Variation gives (Box-mu^2) delta varphi=4 pi Gstar alpha_m rho/c^2
for the stated trace. In the exact vacuum static patch,

    ds_E^2=-f c^2 dt^2+dr^2/f+r^2 dOmega^2,
    (r^2 f delta varphi_r)_r/r^2-mu^2 delta varphi=0  (exterior).

Set delta varphi=-alpha_m m psi(x)/r. The radial equation reduces to

    (1-x^2) psi_xx-2x psi_x+(2-B) psi=0.                 (1)

The point source fixes psi(0)=1, equivalently the outward flux of the
positive radial kernel psi/x is -1 at the origin. It does not by itself fix
the regular additive part. A bounded solution at the background horizon
x=1 excludes the logarithmic Frobenius branch. The remaining solution is

    psi(x)=P_l(x)/P_l(0),   l(l+1)=2-B,
    l=-1/2+i sqrt(B-9/4)  for the candidate domain B>12.   (2)

Here P is equivalently DEFINED by the horizon series below, so no unproved
special-function branch convention is needed. Put v=1-x and A=B-2>0:

    P_l(x)=sum[n>=0] a_n v^n,  a_0=1,
    a_(n+1)=[n(n+1)+A] a_n/[2(n+1)^2].                 (3)

All coefficients are positive. The radius of convergence is 2, hence the
series is real, positive and differentiable on 0<=x<=1. Its x=0 sum is
finite and positive; normalization (2) exists. The local regular singular
equation at x=1 has one analytic solution and one logarithmic solution.
Equivalently, the difference of two bounded same-flux solutions has no
source; multiplying its equation by itself and integrating gives
integral[x^2 f y_x^2+B x^2 y^2]=0. Center and horizon surface terms vanish.
For B>0 the difference is zero. This proves uniqueness in the stated
bounded regular class, not uniqueness among time-dependent states.

At x=1, psi_x=(1-B/2)psi; for y=psi/x, y_x=-B y/2.
The flux equation gives

    x^2 f y_x=-B integral_x^1 t^2 y(t) dt,
    B integral_0^1 x psi(x) dx=1.

Thus y is positive and strictly decreasing. The massless exception is real:
for B=0 a unit Coulomb coefficient gives y=1/x-atanh(x)+constant,
which is unbounded at the horizon. The regular P_1=x has P_1(0)=0 and
cannot be normalized to that source. The candidate's B>12 avoids this case.
At B=2 the regular solution is psi=1, y=1/x; this is an analytic control
outside the candidate's mass range, not a new candidate parameter choice.

## Force kernel and controlled series evaluation

Define D_B(x)=psi-x psi_x. A derivative of the scalar potential alone is
proportional to D_B; it must not be equated to a physical acceleration
without a metric and readout. Its center expansion is

    psi=1+b1 x+(B-2)x^2/2+B b1 x^3/6
          +(B+4)(B-2)x^4/24+O(x^5),
    D_B=1-(B-2)x^2/2-B b1 x^3/3
          -(B+4)(B-2)x^4/8+O(x^5).

The horizon condition fixes b1=P_l'(0)/P_l(0). The flat gradient kernel is
F(beta x)=(1+beta x)exp(-beta x). The leading difference is x^2; the cubic
term depends on the boundary through b1. No finite-radius error estimate
is obtained merely by calling x small.

For rational B>2 and rational 0<=x<=1, (3) gives exact rational enclosures.
Let S_N(v)=sum_0^N a_n v^n, a=a_(N+1), and choose N with

    rho0(v)=v[1+A/(N+2)^2]/2<1,
    rho1(v)=v[1+A/((N+1)(N+2))]/2<1.

For omitted terms the respective value and derivative ratios are bounded
by rho0 and rho1. Hence

    0<=P-S_N<=a v^(N+1)/(1-rho0),
    0<=P_v-S_N'<= (N+1)a v^N/(1-rho1).                (4)

Apply the same denominator bounds at v=1 and divide positive intervals.
They enclose psi and D_B=[P+x P_v]/P(0), without floating roundoff.
Rational exponential-series bounds and rational square-root brackets can
likewise enclose F(beta x). These are pointwise computed certificates, not
a claimed uniform error theorem over all masses or distances.

## Physical metric and a specified acceleration readout

To first order, the Einstein exterior metric is Schwarzschild-de Sitter,
h(r)=1-H^2 r^2-2m/r. Write a(r)=alpha_m delta varphi=-k m psi(Hr)/r.
The physical metric is (1+2a) ds_E^2. Use the PHYSICAL areal radius
R=(1+a)r. Then, to first order at fixed R,

    ds_J^2=-F_J(R)c^2dt^2+dR^2/G_J(R)+R^2 dOmega^2,
    F_J=f-2m/R+2a,
    G_J=f-2m/R+2H^2 R^2 a+2f R a_R,                (5)
    f=1-H^2 R^2,  a=-k m psi(HR)/R.

The same time normalization as the Einstein static patch is used. The
signed outward proper acceleration needed to hold a static observer is
an invariant along that observer: a_hold=c^2 sqrt(G_J) F_J'/(2F_J).
Subtract the source-free value at the SAME physical R,
a_dS=-c^2 H^2 R/sqrt(f). The linear source-induced difference is

    Delta a_hold = c^2 m/R^2 [T(x)+k S_B(x)],       x=HR,
    T=(1-2x^2)/f^(3/2),
    S_B=[f^2 D_B-x^2(1+f)psi]/f^(3/2).             (6)

This signed difference can change sign on sufficiently large domains;
the tensor difference T vanishes at x=1/sqrt(2). A ratio divided by T is
undefined there. On a specified domain with T nonzero, the scalar excess
relative to the tensor prediction is k S_B/T, not generally k D_B or
k F(beta x). Its small-x kernel is

    S_B/T = 1-(B/2+1)x^2+O(x^3).

Consequently a coordinate scalar derivative is not the whole curved-space
measurement correction. Formula (6) assumes an independently specified
background H, common physical radius and tensor mass parameter m; it has
not eliminated their observational reconstruction or error model.

For a circular timelike geodesic, the static-observer speed instead obeys
v_circ^2/c^2=R F_J'/(2F_J), when an admissible orbit exists. Its coordinate
frequency obeys Omega^2/c^2=F_J'/(2R). In this convention

    R F_J'/2=-x^2+(m/R)[1+k D_B(x)].                (7)

A positive circular-orbit frequency is an additional restriction; bound
slow circular tracers cannot be assumed available at every range radius
of a weak source in a de Sitter background. We have not derived orbital
stability. Null paths and local angles at the SAME spacetime events are
conformally invariant; mapping those events to fixed physical areal radii
and clocks is an extra readout step. The flat infinite-ray lensing formula
is not re-used here as a de Sitter mass calibration.

## Prescribed spherical source limitation

The center-regular homogeneous scalar kernel V_B obeys

    (1-x^2)V_xx+(2/x-4x)V_x-B V=0,
    V(0)=1, V_x(0)=0,
    V=sum[n even>=0] d_n x^n,
    d_(n+2)=[n(n+3)+B]d_n/[(n+2)(n+3)].             (8)

The weighted Wronskian of V and y=psi/x is
x^2 f(V y_x-V_x y)=-1. Green's identity gives an exterior scalar charge
factor, relative to the Einstein mass integral, for a prescribed spherical
nonnegative nonrelativistic density supported at r_s<1/H:

    F_body=integral_0^rs rho(r) r^2 V_B(Hr)dr /
           integral_0^rs rho(r) r^2 dr.

Then a=-k m F_body psi/r. Positive series coefficients imply
1<=F_body<=V_B(H r_s). This is a remaining profile input. It includes
neither nonlinear scalar feedback nor a derivation of static equilibrium.
The mass integral is the Einstein static radial mass integral, not an
unqualified proper-volume integral; at this linear order the background
frame has C=1. A physically supported body must also satisfy conservation
and the negligible-trace-stress hypotheses. No arbitrary source profile
is thereby proved realizable.

## What is and is not retired

The exact conditional static vacuum response can be derived without a flat
space approximation. The supplied action, positive vacuum, initial state,
stationarity, horizon regularity, physical source and observational mapping
remain explicit premises. Neither B nor k nor H_v nor Q0 is selected by
solving this boundary-value problem. The earlier flat two-radius inverse is
not automatically a curved-space inverse. No observations have been fitted,
no independent observation test has been passed, and no TOE is established.

This v1 is a derivation awaiting executed controls and focused independent
checking. Preserve it and any later corrections rather than overwriting.
