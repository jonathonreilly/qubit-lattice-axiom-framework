# Preserved direct-author control failure

V1 completed with exit 1, 167 conditions true and six false. All six failures were floating-point membership comparisons for the exact flat exponential bounds. The rational certificates were narrower than the 100-digit comparator: widths range down to about 10^-398. Other mathematical and numerical controls passed. No candidate equation was changed.

FLAT_CERTIFICATE_PRECISION_DIAGNOSIS_v1.json preserves a separate 500-digit recomputation: all eight exact flat intervals contain the correctly resolved value. The rational series, remainder inequalities, point choices and computed certificates are unchanged. V2 recomputes only the floating flat-membership comparator at 500 digits, preserving all scientific formulas and thresholds. CHECK_V1_V2.diff records the change plus the new guarded output path. All v1 evidence and runtime exit/stdout/stderr remain intact. A true automated check alone would not prove an empirical model.
