# Mathematical context and development pilot

On 2026-10-13, the parent opened NIST DLMF 14.2 and 14.3 after deriving the radial ODE. The displayed Legendre equation agrees with (1). For real arguments inside (-1,1), DLMF uses Ferrers-function typography. Our P in (2) is defined by (3), not by an unspecified branch convention. The complex-degree real solution is also documented in 14.2. The recurrence and uniqueness proof here are derived directly from the differential equation; these pages supplied no physical boundary or observational input.

Primary references: https://dlmf.nist.gov/14.2 and https://dlmf.nist.gov/14.3 .

A tool-only 50-digit development pilot at 20:29:46 UTC used mpmath.legenp and direct differentiation for beta=4 at x=.01,.1,.25,.5 and beta=8,16,40 at x=1/beta. At beta=4,x=.25 it gave D=0.769214503892786214, flat=0.735758882342884643, holding-to-tensor kernel=0.717012253039332788. This motivated the fixed comparison list; it was not a held-out test or preregistered empirical comparison. The preserved primary runs subsequently calculate and bound those same development points.
