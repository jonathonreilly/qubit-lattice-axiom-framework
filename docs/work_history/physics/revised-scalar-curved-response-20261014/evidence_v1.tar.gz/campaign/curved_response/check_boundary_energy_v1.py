#!/usr/local/bin/python3
"""Direct-author boundary/energy controls, no observed-data inputs."""
from pathlib import Path
import json,hashlib,datetime
import sympy as s
import mpmath as mp

HERE=Path(__file__).resolve().parent
OUT=HERE/'boundary_evidence_v1'
if OUT.exists(): raise SystemExit('Refusing to replace existing boundary evidence')
OUT.mkdir()
mp.mp.dps=80
checks=[]; detail={}
def rec(name,ok,value=None): checks.append({'name':name,'pass':bool(ok),'value':value})
def exact(name,expr):
    zz=s.simplify(expr);rec(name,zz==0,str(zz))
def fmt(q):return mp.nstr(q,40)

x,t,B,J=s.symbols('x t B J',positive=True)
f=1-x*x
P=s.Function('P')(x,t)
phi=P/x
kg=-s.diff(phi,t,2)/f+s.diff(x*x*f*s.diff(phi,x),x)/(x*x)-B*phi-J*phi/(x*x)
wave=-s.diff(P,t,2)+f*f*s.diff(P,x,2)+f*s.diff(f,x)*s.diff(P,x)-f*(B-2+J/(x*x))*P
exact('full_radial_KG_to_tortoise_wave',x*f*kg-wave)
rho=s.symbols('rho',positive=True)
exact('tortoise_coordinate',s.diff(s.atanh(x),x)-1/f)
V=(1-x*x)*(B-2+J/x**2)
exact('potential_positive_factorization',V-(1-x)*(1+x)*(B-2+J/x**2))

# Covariant stress/slice calculation, leaving all factors visible.
qdot,qgrad,massfield=s.symbols('qdot qgrad massfield',real=True)
Ttt=qdot*qdot-s.Rational(1,2)*(-f)*(-qdot*qdot/f+f*qgrad*qgrad+B*massfield*massfield)
# n^t=1/sqrt(f), slice volume=x^2/sqrt(f) dx dOmega.
E_density=s.simplify(Ttt*x*x/f)
exact('Killing_energy_density_from_stress',E_density-x*x*(qdot*qdot/f+f*qgrad*qgrad+B*massfield*massfield)/2)

P1=s.Function('P1')(x)
ephi=(x*x*f*s.diff(P1/x,x)**2+B*P1**2)/2
epsi=(f*s.diff(P1,x)**2+(B-2)*P1**2)/2
exact('energy_boundary_term',ephi-epsi+s.diff(f*P1**2/(2*x),x))

W=s.Function('W')(rho,t); VV=s.Function('V')(rho)
ed=(s.diff(W,t)**2+s.diff(W,rho)**2+VV*W**2)/2
flux=s.diff(W,t)*s.diff(W,rho)
cons=s.diff(ed,t)-s.diff(flux,rho)
exact('wave_local_energy_identity',cons.subs(s.diff(W,t,2),s.diff(W,rho,2)-VV*W))

y=s.Function('y')(x); I=s.Function('I')(x); p=x*x*f
q=s.simplify(y*I)
qprime=s.diff(q,x).subs(s.diff(I,x),1/(p*y*y))
Lq=s.diff(p*qprime,x)-B*x*x*q
Lq=Lq.subs(s.diff(I,x),1/(p*y*y)).subs(s.diff(y,x,2),(B*x*x*y-s.diff(p,x)*s.diff(y,x))/p)
exact('reduction_of_order_solution',Lq)
exact('static_energy_as_boundary_term',(s.diff(p*y*s.diff(y,x),x)-(p*s.diff(y,x)**2+B*x*x*y*y)).subs(s.diff(y,x,2),(B*x*x*y-s.diff(p,x)*s.diff(y,x))/p))

eps,qh=s.symbols('eps qh',positive=True)
leading_gradient=1/(2*qh*eps)
leading_energy=s.Rational(1,2)*(1-eps)**2*(1-(1-eps)**2)*leading_gradient**2
exact('log_branch_energy_coefficient',s.limit(eps*leading_energy,eps,0)-1/(4*qh*qh))
bad_energy=s.Rational(1,2)*(1-eps)**2*(1-(1-eps)**2)**2*leading_gradient**2
rec('damage_extra_lapse_factor_detected',s.limit(eps*bad_energy,eps,0)==0)

# A true counterexample outside positivity: B=-4, j=0 has a growing mode.
w=s.tanh(rho)/s.cosh(rho)
badV=-6/s.cosh(rho)**2
exact('negative_potential_growing_mode',-s.diff(w,rho,2)+badV*w+w)
rec('negative_potential_mode_regular_and_decaying',s.limit(w,rho,0)==0 and s.limit(w,rho,s.oo)==0)
# Finite energy does not imply a static state, even at a positive candidate mass.
pulse=rho*s.exp(-rho*rho)
pulse_acc=s.diff(pulse,rho,2)-14/s.cosh(rho)**2*pulse
rec('finite_energy_pulse_nonstatic',s.simplify(pulse_acc.subs(rho,1))!=0,str(s.simplify(pulse_acc.subs(rho,1))))
rec('finite_energy_pulse_regular_decay',s.limit(pulse,rho,0)==0 and s.limit(pulse,rho,s.oo)==0)

ll=-mp.mpf('.5')+mp.sqrt(mp.mpf('2.25')-16)
Pmp=lambda xx:mp.re(mp.legenp(ll,0,xx)) # Horizon normalization P(1)=1.
Y=lambda xx:Pmp(xx)/xx
x0=mp.mpf('.5')
regular_limit=-mp.mpf('.5')*x0*x0*(1-x0*x0)*Y(x0)*mp.diff(Y,x0)
rows=[];previous=None
for ee in [mp.mpf('1e-2'),mp.mpf('1e-4'),mp.mpf('1e-6'),mp.mpf('1e-8'),mp.mpf('1e-10'),mp.mpf('1e-12')]:
    xx=1-ee; pp=xx*xx*(1-xx*xx)
    integ=mp.quad(lambda zz:1/((1-zz*zz)*Pmp(zz)**2),[x0,xx])
    qval=Y(xx)*integ; qder=mp.diff(Y,xx)*integ+1/(pp*Y(xx))
    eq=pp*qval*qder/2
    er=pp*Y(xx)*mp.diff(Y,xx)/2+regular_limit
    coeff=ee*pp*qder*qder/2
    row={'epsilon':str(ee),'log_branch_energy':fmt(eq),'regular_energy':fmt(er),'regular_limit':fmt(regular_limit),'log_gradient_coefficient':fmt(coeff)}
    if previous:
        slope=(eq-previous[1])/mp.log(previous[0]/ee);row['energy_log_slope']=fmt(slope)
    rows.append(row); previous=(ee,eq)
rec('logarithmic_divergence_coefficient_numeric',abs(coeff-mp.mpf('.25'))<mp.mpf('1e-8'),fmt(coeff))
rec('logarithmic_integrated_slope_numeric',abs(slope-mp.mpf('.25'))<mp.mpf('1e-7'),fmt(slope))
rec('regular_branch_finite_energy_numeric',abs(er/regular_limit-1)<mp.mpf('1e-9'),fmt(er/regular_limit-1))
detail['cutoff_energy']=rows
pf=lambda rr:rr*mp.exp(-rr*rr)
PE=mp.quad(lambda rr:(mp.diff(pf,rr)**2+14/mp.cosh(rr)**2*pf(rr)**2)/2,[0,1,3,mp.inf])
rec('finite_energy_nonstatic_pulse_numeric',mp.isfinite(PE) and PE>0,fmt(PE))
detail['pulse_energy']=fmt(PE)
source=[]
for pp in [HERE/'DERIVATION_v2.md',HERE/'BOUNDARY_ENERGY_DERIVATION_v1.md',Path(__file__)]:
    data=pp.read_bytes();source.append({'path':str(pp),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
result={'author':'/root','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'checks':checks,'details':detail,'source':source,'empirical_data_accessed':False}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
