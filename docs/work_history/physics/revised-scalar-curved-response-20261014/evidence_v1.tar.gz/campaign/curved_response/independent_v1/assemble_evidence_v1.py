#!/usr/bin/env python3
"""Assemble preserved records; performs no physics calculations or reruns."""
from pathlib import Path
import collections
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent
EXPECTED={
    'RUN_01.stdout.json':'e084adef0c23a073575de99b53391d60a650b88a43febff7a19b0ee0ff160434',
    'RUN_02_REPAIRS.stdout.json':'7e967b054f016e432e862c23a268ddd5239870010d9135d788f6e05d0e67ff09',
    'check_independent_v1.py':'127fef6ee360d1b5cc28659594ee2893a45b6820bddf4950a120407a24ed4e68',
    'check_repairs_v1.py':'a825d05d1ec2ed8984d296c7929fcaf479dccdb6cafde8c2f92073e7d959433c',
}
REPLACEMENTS={
    'center_D_x2','center_D_x3','center_D_x4',
    'log_branch_infinite_energy_coefficient','massless_bounded_branch_wrong_flux',
}
sha=lambda b:hashlib.sha256(b).hexdigest()


def main():
    for path,digest in EXPECTED.items():
        assert sha((HERE/path).read_bytes())==digest,(path,'changed')
    original=json.loads((HERE/'RUN_01.stdout.json').read_text())
    repair=json.loads((HERE/'RUN_02_REPAIRS.stdout.json').read_text())
    assert original['summary']=={'count':111,'satisfied':107,'unsatisfied':4}
    assert repair['summary']=={'count':5,'satisfied':5,'unsatisfied':0}
    assert {r['name'] for r in repair['records']}==REPLACEMENTS
    assert {r['name'] for r in original['records'] if not r['satisfied']}==REPLACEMENTS-{'massless_bounded_branch_wrong_flux'}
    repaired={r['name']:(i,r) for i,r in enumerate(repair['records'])}
    rows=[]
    for i,r in enumerate(original['records']):
        if r['name'] in repaired:
            index,row=repaired[r['name']]
            origin='RUN_02_REPAIRS.stdout.json'
        else:
            index,row=i,r
            origin='RUN_01.stdout.json'
        assert row['satisfied'],row['name']
        rows.append({'name':row['name'],'kind':row['kind'],'satisfied':True,
                     'result_file':origin,'record_index':index,'result_sha256':EXPECTED[origin]})
    assert len(rows)==len({r['name'] for r in rows})==111
    source_status=[]
    for source in json.loads((HERE/'SOURCE_MANIFEST_v1.json').read_text())['files']:
        actual=sha(Path(source['source_path']).read_bytes())
        assert actual==source['sha256'],source['source_path']
        source_status.append({'source_path':source['source_path'],'sha256':actual,'unchanged':True})
    result={'assembled_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope':'111 logical conditions assembled from two preserved actual executions, not a claim of a fresh 111-pass rerun.',
            'input_identities':EXPECTED,'records':rows,
            'summary':{'count':111,'satisfied':111,'unsatisfied':0},
            'categories':dict(collections.Counter(r['kind'] for r in rows)),
            'reused_original_records':106,'repair_or_executable_replacement_records':5,
            'preserved_original_failed_records':4,
            'original_documentary_record_replaced_by_actual_calculation':'massless_bounded_branch_wrong_flux',
            'final_source_identity_check':source_status,
            'science_reruns_during_assembly':0}
    target=HERE/'COMBINED_RESULT_v1.json'
    if target.exists():raise RuntimeError('Refusing to overwrite the combined evidence receipt')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(target),'sha256':sha(target.read_bytes()),'summary':result['summary'],
                      'categories':result['categories'],'reused_records':106,'replacement_records':5},indent=2))


if __name__=='__main__':main()
