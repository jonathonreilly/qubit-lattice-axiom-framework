#!/usr/bin/env python3
"""Read/hash/AST/text correspondence only. Never import or execute science runners."""
from pathlib import Path
from decimal import Decimal
from fractions import Fraction
import ast
import difflib
import hashlib
import json
import sys

OUT = Path(__file__).resolve().parent
OLD = OUT.parent
ROOT = OUT.parents[6]
index = json.loads((OUT / "SOURCE_MANIFEST_v1.json").read_text())
sources = {row["label"]: row for row in index["sources"]}
checks = []
details = {}

def digest(body):
    return hashlib.sha256(body).hexdigest()

def body(label):
    return (OUT / sources[label]["snapshot_path"]).read_bytes()

def text(label):
    return body(label).decode()

def data(label):
    return json.loads(body(label))

def record(name, ok, evidence=None):
    checks.append({"name": name, "pass": bool(ok), "evidence": evidence})

def save_diff(name, before, after):
    difference = "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                            fromfile="checked_source", tofile="canonical_note"))
    with (OUT / name).open("x") as stream:
        stream.write(difference)
    return difference

for label, row in sources.items():
    frozen = body(label)
    live = Path(row["source_path"]).read_bytes()
    record("source_pair_" + label, frozen == live and digest(frozen) == row["sha256"]
           and len(frozen) == row["bytes"], row["sha256"])

prior_manifest = data("prior_manifest")
record("prior_manifest_known_identity", digest(body("prior_manifest")) ==
       "ae4c4ba923b1c8d20626fb2cb5f81f435c9f3b6c3cbbd5a16c00b983c0138d9d")
for row in prior_manifest["files"]:
    raw = (OLD / row["path"]).read_bytes()
    record("prior_artifact_" + row["path"], digest(raw) == row["sha256"] and len(raw) == row["bytes"], row)
record("prior_manifest_has_21_entries", len(prior_manifest["files"]) == 21)
prior_receipt = data("prior_receipt")
for i, row in enumerate(prior_receipt["source_files"]):
    raw = Path(row["source_path"]).read_bytes()
    record(f"prior_live_science_source_{i}", digest(raw) == row["sha256"] and len(raw) == row["bytes"], row)
record("prior_assembled_111_supported_not_fresh_run", data("prior_combined_result")["summary"] ==
       {"count":111,"satisfied":111,"unsatisfied":0}
       and prior_receipt["assembly_provenance"]["not_a_fresh_111_pass_run"])

note = text("canonical_note")
response = text("checked_response_v2")
boundary = text("checked_boundary_energy")
action = text("checked_complete_action")
action_start = "Use signature (-+++), phi=(u,x,y), and"
action_end = "    lambda_x=(1-k)/alpha, lambda_y=(1+k)/alpha."
action_old = action[action.index(action_start):action.index(action_end)+len(action_end)]
action_new = note[note.index(action_start):note.index(action_end)+len(action_end)]
record("full_action_byte_identical", action_old == action_new,
       {"block_sha256":digest(action_old.encode()),"bytes":len(action_old.encode())})
save_diff("ACTION_SOURCE_CANONICAL.diff", action_old, action_new)
old_response = response[response.index("## Question and fixed hypotheses"):response.index("\nV2 makes the circular")].rstrip()+"\n"
new_response = note[note.index("## Question and fixed hypotheses"):note.index("## Deriving the stationary boundary")].rstrip()+"\n"
save_diff("RESPONSE_SOURCE_CANONICAL.diff", old_response, new_response)
expected_response = old_response.replace(
    "The preceding inverse/readout calculation has been independently checked.\nIts two-radius inverse assumes a flat static Yukawa response. In this action,",
    "The flat static Yukawa force law is a possible local approximation. In this action,").replace(
    "identities were personally and independently checked in earlier blocks;\nthe complete supplied action is frozen as an input to this block. They do",
    "identities follow from the complete supplied action above. They do")
record("response_only_two_declared_context_edits", expected_response == new_response)
old_boundary = boundary[boundary.index("The static Green calculation"):boundary.index("\nThis v1 is a direct derivation")].rstrip()+"\n"
new_boundary = note[note.index("The static Green calculation"):note.index("## Executed evidence and limits")].rstrip()+"\n"
save_diff("BOUNDARY_SOURCE_CANONICAL.diff", old_boundary, new_boundary)
record("full_boundary_argument_byte_identical", old_boundary == new_boundary)

runner = text("canonical_runner")
tree = ast.parse(runner)
declarations = {}
for item in tree.body:
    if isinstance(item, ast.Assign):
        for target in item.targets:
            if isinstance(target, ast.Name) and target.id.startswith("AUDIT_"):
                declarations[target.id] = ast.literal_eval(item.value)
imports = []
for item in ast.walk(tree):
    if isinstance(item, ast.Import):
        imports.extend(alias.name for alias in item.names)
    elif isinstance(item, ast.ImportFrom):
        imports.append(item.module)
call_names = []
for item in ast.walk(tree):
    if isinstance(item, ast.Call) and isinstance(item.func, ast.Name):
        call_names.append(item.func.id)
record("runner_imports_only_declared_libraries", sorted(imports) ==
       sorted(["fractions","hashlib","json","math","sys","sympy","mpmath","scipy.integrate"]), imports)
record("no_runner_file_or_dynamic_code_input_calls", not set(call_names).intersection({"open","eval","exec","__import__","compile"}))
record("sole_declared_input_canonical_note", declarations.get("AUDIT_INPUT_PATHS") ==
       ("docs/EXPONENTIAL_SCALAR_CURVED_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-14.md",))
record("runner_timeout_120", declarations.get("AUDIT_TIMEOUT_SEC") == 120)
details["runner_static_inspection"] = {"imports":imports,"declarations":declarations,
    "producer_module_imported_or_executed":False,"science_libraries_imported_by_this_checker":False}

cache = text("canonical_cache")
header_text, remainder = cache.split("----- stdout -----\n",1)
stdout, stderr = remainder.split("----- stderr -----",1)
header = dict(line.split(": ",1) for line in header_text.splitlines() if ": " in line)
cached = json.loads(stdout)
input_hash = hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
for name in declarations["AUDIT_INPUT_PATHS"]:
    path_bytes = name.encode()
    input_bytes = (ROOT/name).read_bytes()
    input_hash.update(len(path_bytes).to_bytes(8,"big"))
    input_hash.update(path_bytes)
    input_hash.update(len(input_bytes).to_bytes(8,"big"))
    input_hash.update(input_bytes)
record("cache_runner_path", header["runner"] == "scripts/exponential_scalar_curved_response_check.py")
record("cache_runner_hash", header["runner_sha256"] == digest(body("canonical_runner")))
record("cache_current_note_input_fingerprint", header["input_fingerprint_sha256"] == input_hash.hexdigest(), input_hash.hexdigest())
record("cache_success_and_empty_stderr", header["status"] == "ok" and header["exit_code"] == "0"
       and header["timeout_sec"] == "120" and not stderr.strip(), header)
primary_checks = cached["response"]["checks"] + cached["energy"]["checks"]
counted = {"passed":sum(row["pass"] is True for row in primary_checks),
           "failed":sum(row["pass"] is not True for row in primary_checks)}
record("cache_actual_checks_match_195_zero", counted == cached["counts"] == {"passed":195,"failed":0})
record("cache_check_names_unique", len({row["name"] for row in primary_checks}) == len(primary_checks))
details["primary_evidence"] = {"header":header,"counts":counted,"executed_by_this_checker":False,
                               "response_records":len(cached["response"]["checks"]),
                               "energy_records":len(cached["energy"]["checks"])}

certificates = body("producer_corrected_certificates")
record("primary_full_rational_certificates_recoverable", cached["response"]["rational_certificates_sha256"] == digest(certificates)
       and cached["response"]["rational_certificates_bytes"] == len(certificates))
record("original_and_corrected_certificates_unchanged", certificates == body("producer_original_certificates"))
old_producer = data("producer_original_result")
new_producer = data("producer_corrected_result")
producer_failures = [row for row in old_producer["checks"] if not row["pass"]]
record("producer_six_precision_failures_preserved", old_producer["checks_passed"] == 167 and old_producer["checks_failed"] == 6
       and len(producer_failures) == 6 and all(row["name"].endswith("_flat") for row in producer_failures), producer_failures)
record("producer_corrected_173_zero_preserved", new_producer["checks_passed"] == 173 and new_producer["checks_failed"] == 0)
diagnosis = data("producer_precision_diagnosis")
record("producer_precision_diagnosis_exact_certificate_binding", diagnosis["source_certificate_sha256"] == digest(certificates)
       and diagnosis["recheck_precision"] == 500 and len(diagnosis["rows"]) == 8
       and all(row["inside_at_500_digits"] for row in diagnosis["rows"]))
details["producer_failure_provenance"] = {"original_counts":[167,6],"corrected_counts":[173,0],
                                         "failure_names":[row["name"] for row in producer_failures],
                                         "independent_result_not_replaced_by_producer_output":True}

points = cached["response"]["details"]["comparison_points"]
record("eight_point_certificates_correspond_to_primary_examples", len(points) == len(json.loads(certificates)) == 8
       and [(row["B"],row["x"]) for row in points] == [(row["B"],row["x"]) for row in json.loads(certificates)])
record("holding_interval_divisor_positive_for_all_executed_cases",
       all(1-2*Fraction(row["x"])**2 > 0 for row in points))
example = next(row for row in points if row["B"] == "16" and row["x"] == "1/4")
for key, shown in [("D","0.769214503893"),("flat","0.735758882343"),("holding_relative_tensor","0.717012253039")]:
    record("canonical_example_"+key, abs(Decimal(example[key])-Decimal(shown)) <= Decimal("0.0000000000005"),example[key])
record("B16_candidate_parameter_example",4*(3*(1+Fraction(1,100))+Fraction(17,20))/(1-3*Fraction(1,100)) == 16)
details["new_computation_scope"] = "Only hashing, JSON counting, AST inspection, text comparisons, quoted-number rounding and simple rational domain/parameter checks. No ODE, BVP, quadrature, symbolic science or producer execution."

result = {"scope":"Narrow canonical correspondence, not a formal audit or new independent science suite.",
          "checks":checks,"counts":{"passed":sum(row["pass"] for row in checks),
                                      "failed":sum(not row["pass"] for row in checks)},"details":details}
print(json.dumps(result,indent=2))
sys.exit(bool(result["counts"]["failed"]))
