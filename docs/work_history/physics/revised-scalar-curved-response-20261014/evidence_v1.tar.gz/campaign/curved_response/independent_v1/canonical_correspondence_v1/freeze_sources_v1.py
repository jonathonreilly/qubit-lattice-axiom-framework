#!/usr/bin/env python3
"""Freeze correspondence inputs only. No producer or science code is executed."""
from pathlib import Path
import datetime
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[6]
OLD = OUT.parent
CURVED = OLD.parent

def sha(body):
    return hashlib.sha256(body).hexdigest()

sources = [
    ("canonical_note", ROOT / "docs/EXPONENTIAL_SCALAR_CURVED_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-14.md"),
    ("canonical_runner", ROOT / "scripts/exponential_scalar_curved_response_check.py"),
    ("canonical_cache", ROOT / "logs/runner-cache/exponential_scalar_curved_response_check.txt"),
    ("prior_report", OLD / "REPORT_v1.txt"),
    ("prior_receipt", OLD / "RECEIPT_v1.json"),
    ("prior_manifest", OLD / "MANIFEST_v1.json"),
    ("prior_combined_result", OLD / "COMBINED_RESULT_v1.json"),
    ("checked_response_v2", OLD / "sources/01_DERIVATION_v2.md"),
    ("checked_boundary_energy", OLD / "sources/02_BOUNDARY_ENERGY_DERIVATION_v1.md"),
    ("checked_complete_action", OLD / "sources/03_EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md"),
    ("producer_failure_log", CURVED / "FAILURE_LOG_v1.md"),
    ("producer_precision_diagnosis", CURVED / "FLAT_CERTIFICATE_PRECISION_DIAGNOSIS_v1.json"),
    ("producer_original_result", CURVED / "evidence_v1/RESULTS.json"),
    ("producer_corrected_result", CURVED / "evidence_v2/RESULTS.json"),
    ("producer_original_certificates", CURVED / "evidence_v1/EXACT_RATIONAL_CERTIFICATES.json"),
    ("producer_corrected_certificates", CURVED / "evidence_v2/EXACT_RATIONAL_CERTIFICATES.json"),
    ("cache_fingerprint_implementation", ROOT / "scripts/runner_cache.py"),
]
snapshot_dir = OUT / "sources"
snapshot_dir.mkdir(exist_ok=False)
rows = []
for index, (label, source) in enumerate(sources):
    body = source.read_bytes()
    destination = snapshot_dir / (f"{index:02d}_" + label + source.suffix)
    with destination.open("xb") as stream:
        stream.write(body)
    rows.append({"label": label, "source_path": str(source),
                 "snapshot_path": destination.relative_to(OUT).as_posix(),
                 "sha256": sha(body), "bytes": len(body)})
payload = {"created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "scope": "Canonical correspondence only; all prior independent evidence preserved; no producer or independent science execution.",
           "sources": rows}
with (OUT / "SOURCE_MANIFEST_v1.json").open("x") as stream:
    json.dump(payload, stream, indent=2)
    stream.write("\n")
print(json.dumps({"frozen_source_count": len(rows), "sources": rows}, indent=2))
