#!/usr/bin/env python3
"""Seal only this new correspondence folder. No science execution or old writes."""
from pathlib import Path
import datetime
import hashlib
import json

OUT = Path(__file__).resolve().parent
OLD = OUT.parent

def sha(body):
    return hashlib.sha256(body).hexdigest()

def identity(path):
    raw = path.read_bytes()
    return {"path":path.relative_to(OUT).as_posix(),"bytes":len(raw),"sha256":sha(raw)}

source_manifest = json.loads((OUT/"SOURCE_MANIFEST_v1.json").read_text())
for row in source_manifest["sources"]:
    live = Path(row["source_path"]).read_bytes()
    frozen = (OUT/row["snapshot_path"]).read_bytes()
    assert live == frozen and sha(live) == row["sha256"] and len(live) == row["bytes"],row
prior_manifest = json.loads((OLD/"MANIFEST_v1.json").read_text())
for row in prior_manifest["files"]:
    raw = (OLD/row["path"]).read_bytes()
    assert sha(raw) == row["sha256"] and len(raw) == row["bytes"],row
prior_receipt = json.loads((OLD/"RECEIPT_v1.json").read_text())
for row in prior_receipt["source_files"]:
    raw = Path(row["source_path"]).read_bytes()
    assert sha(raw) == row["sha256"] and len(raw) == row["bytes"],row
run = json.loads((OUT/"RUN_01.json").read_text())
result = json.loads((OUT/"RUN_01.stdout.json").read_text())
assert result["counts"] == {"passed":69,"failed":0} and run["exit_code"] == 0
assert sha((OUT/"check_correspondence_v1.py").read_bytes()) == run["script_sha256"]
assert sha((OUT/"RUN_01.stdout.json").read_bytes()) == run["stdout_sha256"]
assert sha((OUT/"RUN_01.stderr.txt").read_bytes()) == run["stderr_sha256"]
artifacts = [identity(p) for p in sorted(OUT.rglob("*")) if p.is_file()]
receipt = {
    "completed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "checker":"/root/local_response_check",
    "scope":"Narrow canonical curved-response and exterior-energy correspondence, not a formal audit or new science suite.",
    "conclusion":"No required correction. Complete action, response equations and hypotheses, and full boundary argument correspond to the previously checked sources. Added vacuum algebra and counterexamples are correct on manual inspection.",
    "source_files":source_manifest["sources"],
    "source_snapshot_pairs_verified":17,
    "prior_sealed_artifacts_verified":21,
    "prior_live_science_sources_verified":4,
    "prior_evidence_root":str(OLD),
    "prior_report_sha256":sha((OLD/"REPORT_v1.txt").read_bytes()),
    "prior_receipt_sha256":sha((OLD/"RECEIPT_v1.json").read_bytes()),
    "prior_manifest_sha256":sha((OLD/"MANIFEST_v1.json").read_bytes()),
    "reused_independent_conditions":{"supported":111,"fresh_science_execution":False,
        "original_run":[107,111],"unchanged_original_records":106,"targeted_repair_or_replacement_records":5,
        "original_failures_preserved":True},
    "new_correspondence_conditions":result["counts"],
    "new_run":run,
    "primary_execution":result["details"]["primary_evidence"],
    "canonical_source_correction_required":False,
    "source_correspondence":{"inline_complete_action":"byte-identical",
        "response_v2":"Only two declared contextual edits; equations and hypotheses unchanged",
        "boundary_energy_v1":"Entire mathematical argument byte-identical after procedural wrappers removed",
        "additional_vacuum_algebra":"manually checked; no new CAS execution",
        "finite_energy_nonstatic_pulse":"manually checked as regular finite-energy data with nonzero initial acceleration",
        "negative_potential_mode":"manually checked; B=-4 outside candidate positive-mass domain"},
    "evidence_limits":[
        "Primary 195/0 is existing producer execution, not a fresh independent result.",
        "Original independent 111 conditions are an assembled result, not a fresh uninterrupted 111-pass run.",
        "No ODE, BVP, quadrature, history, physics or empirical runner executed in this correspondence phase.",
        "Eight primary interval cases all have positive holding/tensor divisor; no generalized implementation for a negative divisor is claimed.",
        "Finite exterior energy selects the bounded static branch only in the stipulated stationary exterior class.",
        "No observed-state selection, retarded convergence, decay rate, nonlinear screening or full metric stability is derived.",
        "Archive/commit/five-path delivery correspondence is not included in this receipt."],
    "producer_runner_read":True,"producer_runner_imported_or_executed":False,
    "subagents_spawned":0,"author_git_PR_runtime_lock_or_audit_status_modified":False,
    "write_scope":str(OUT),
    "preserved_procedural_failure":"One mistyped-workdir read failed before process creation; corrected read succeeded. TOOL_FAILURES_v1.json.",
    "artifact_sha256":{row["path"]:row["sha256"] for row in artifacts},
    "fixed_campaign_deadline_utc":"2026-10-14T18:13:22Z"
}
with (OUT/"RECEIPT_v1.json").open("x") as stream:
    json.dump(receipt,stream,indent=2);stream.write("\n")
manifest={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "scope":"Frozen new canonical correspondence evidence. Does not replace the original sealed independent manifest.",
          "files":[identity(p) for p in sorted(OUT.rglob("*")) if p.is_file()]}
with (OUT/"MANIFEST_v1.json").open("x") as stream:
    json.dump(manifest,stream,indent=2);stream.write("\n")
for row in manifest["files"]:
    assert identity(OUT/row["path"]) == row
print(json.dumps({"sealed_artifact_count":len(manifest["files"]),
                  "report":identity(OUT/"REPORT_v1.txt"),
                  "receipt":identity(OUT/"RECEIPT_v1.json"),
                  "manifest":identity(OUT/"MANIFEST_v1.json"),
                  "all_current_source_and_old_evidence_bindings_confirmed":True},indent=2))
