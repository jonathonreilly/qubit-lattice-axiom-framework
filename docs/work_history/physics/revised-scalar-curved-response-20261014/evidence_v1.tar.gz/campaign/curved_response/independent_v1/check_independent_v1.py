#!/usr/bin/env python3
"""Independent source-only curved scalar check; no producer imports or runs."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import datetime
import hashlib
import json
import platform
import sys

import mpmath as mp
import numpy as np
import scipy
from scipy.integrate import solve_bvp, solve_ivp, quad
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
import sympy as sp

HERE = Path(__file__).resolve().parent
mp.mp.dps = 80
RECORDS, OUTPUTS = [], {}


def rec(name, kind, ok, **evidence):
    RECORDS.append({"name": name, "kind": kind, "satisfied": bool(ok), "evidence": evidence})


def m(v):
    if isinstance(v, F):
        return mp.mpf(v.numerator) / v.denominator
    return mp.mpf(v)


def ns(v, n=45):
    return mp.nstr(v, n)


def exact(name, derived, expected=0):
    residue = sp.factor(sp.cancel(sp.expand(derived - expected)))
    rec(name, "symbolic", residue == 0, residue=str(residue))


def symbolic_checks():
    x, B, k, nu, b1, R, P, Px = sp.symbols('x B k nu b1 R P Px', real=True)
    f = 1 - x*x
    psi = sp.Function('psi')(x)
    y = psi/x
    raw = x*(sp.diff(x*x*f*sp.diff(y,x),x)/(x*x)-B*y)
    expected = f*sp.diff(psi,x,2)-2*x*sp.diff(psi,x)+(2-B)*psi
    exact('radial_equation_from_covariant_operator', raw, expected)
    ell = -sp.Rational(1,2)+sp.I*sp.sqrt(B-sp.Rational(9,4))
    exact('Legendre_degree',ell*(ell+1),2-B)
    mass = 4*(3*(1+k)+nu)/(1-3*k)
    exact('candidate_mass_above_twelve', mass-12, 4*(12*k+nu)/(1-3*k))
    coeff = [sp.Integer(1),b1]+list(sp.symbols('c2:7'))
    trial=sum(c*x**n for n,c in enumerate(coeff))
    pol=sp.Poly(sp.expand(f*sp.diff(trial,x,2)-2*x*sp.diff(trial,x)+(2-B)*trial),x)
    solved=sp.solve([pol.coeff_monomial(x**n) for n in range(5)],coeff[2:],dict=True)[0]
    exact('center_c2',solved[coeff[2]],(B-2)/2)
    exact('center_c3',solved[coeff[3]],B*b1/6)
    exact('center_c4',solved[coeff[4]],(B+4)*(B-2)/24)
    expansion=sp.expand(trial.subs(solved))
    D=expansion-x*sp.diff(expansion,x)
    exact('center_D_x2',D.coeff(x,2),-(B-2)/2)
    exact('center_D_x3',D.coeff(x,3),-B*b1/3)
    exact('center_D_x4',D.coeff(x,4),-(B+4)*(B-2)/8)
    flat=(1+sp.sqrt(B)*x)*sp.exp(-sp.sqrt(B)*x)
    exact('curved_minus_flat_leading_x2',sp.series(D-flat,x,0,3).removeO(),x*x)
    q, qp, H, eps = sp.symbols('q qp H eps', real=True)
    rr=R*(1-eps*q)
    h=1-H*H*rr*rr-2*eps/rr
    Fseed=(1+2*eps*q)*h
    Gseed=h*(1+2*eps*R*qp)
    exact('areal_F_coefficient',sp.diff(Fseed,eps).subs(eps,0),-2/R+2*q)
    exact('areal_G_coefficient',sp.diff(Gseed,eps).subs(eps,0),-2/R+2*H*H*R*R*q+2*(1-H*H*R*R)*R*qp)
    Dsym=P-x*Px
    F1=-2*(1+k*P)/R
    G1=(-2-2*k*x*x*P+2*k*f*Dsym)/R
    F1p=2*(1+k*Dsym)/(R*R)
    fp=-2*x*x/R
    hold=F1p/(2*sp.sqrt(f))+fp*(G1-2*F1)/(4*f*sp.sqrt(f))
    expected_num=1-2*x*x+k*(f*f*Dsym-x*x*(1+f)*P)
    exact('holding_acceleration_coefficient',sp.simplify(hold*R*R*f*sp.sqrt(f)),expected_num)
    ratio=(f*f*D-x*x*(1+f)*expansion)/(1-2*x*x)
    exact('physical_ratio_small_x',sp.series(ratio,x,0,3).removeO(),1-(B/2+1)*x*x)
    exact('circular_numerator',R*(-2*x*x/R+eps*F1p)/2,-x*x+eps*(1+k*Dsym)/R)
    exact('B2_exact_kernel',f*0-2*x*0+(2-sp.Integer(2)),0)
    massless=1/x-sp.atanh(x)
    exact('B0_unit_flux',x*x*f*sp.diff(massless,x),-1)
    v=sp.symbols('v',real=True)
    n,A=sp.symbols('n A',positive=True)
    actual_value_ratio=v*(n*(n+1)+A)/(2*(n+1)**2)
    loose_value_ratio=v*(1+A/(n+1)**2)/2
    exact('value_ratio_slack',loose_value_ratio-actual_value_ratio,v/(2*(n+1)))
    exact('derivative_ratio',actual_value_ratio*(n+1)/n,v*(1+A/(n*(n+1)))/2)
    tau,j=sp.symbols('tau j',real=True)
    w=sp.Function('w')(x,tau)
    phi=w/x
    KG=-sp.diff(phi,tau,2)/f+sp.diff(x*x*f*sp.diff(phi,x),x)/(x*x)-(B+j*(j+1)/(x*x))*phi
    wave=sp.diff(w,tau,2)-f*sp.diff(f*sp.diff(w,x),x)+f*(B-2+j*(j+1)/(x*x))*w
    exact('tortoise_wave_potential',-x*f*KG,wave)
    ep=x*x*(f*sp.diff(y,x)**2+B*y*y)/2
    ew=(f*sp.diff(psi,x)**2+(B-2)*psi*psi)/2
    exact('energy_boundary_identity',ep-ew,-sp.diff(f*psi*psi/x,x)/2)
    qh,delta=sp.symbols('qh delta',positive=True)
    leading_gradient=(1-delta)**2*(1-(1-delta)**2)/(8*qh*qh*delta*delta)
    exact('log_branch_gradient_coefficient',sp.limit(delta*leading_gradient,delta,0),1/(4*qh*qh))
    exact('point_source_UV_gradient_coefficient',sp.limit(x*x*(1-x*x)/(2*x*x),x,0),sp.Rational(1,2))
    a,b,N=sp.symbols('a b N',real=True)
    exact('growing_mode_imaginary_identity',sp.im((a+sp.I*b)**2*N),2*a*b*N)


@lru_cache(maxsize=None)
def params(Btext):
    B=m(F(Btext));t=mp.sqrt(B-mp.mpf(9)/4)
    a=mp.mpf('.5')-1j*t;b=mp.mpf('.5')+1j*t
    norm=mp.re(mp.hyp2f1(a,b,1,mp.mpf('.5')))
    return B,a,b,norm


def kernel(Btext,x):
    B,a,b,norm=params(Btext);x=m(x);z=(1-x)/2
    P=mp.re(mp.hyp2f1(a,b,1,z))
    Pp=mp.re(-a*b/2*mp.hyp2f1(a+1,b+1,2,z))
    Ppp=mp.re(a*b*(a+1)*(b+1)/8*mp.hyp2f1(a+2,b+2,3,z))
    return P/norm,Pp/norm,Ppp/norm


def center_kernel(Btext,x):
    B,_,_,_=params(Btext);x=m(x);t=mp.sqrt(B-mp.mpf(9)/4)
    a=mp.mpf('.75')-1j*t/2;b=mp.mpf('.75')+1j*t/2
    V=mp.re(mp.hyp2f1(a,b,mp.mpf('1.5'),x*x))
    Vp=mp.re(B*x/3*mp.hyp2f1(a+1,b+1,mp.mpf('2.5'),x*x))
    return V,Vp


def rational_bounds(B,x,N=96):
    v=1-x;A=B-2;co=[F(1)]
    for n in range(N+1):co.append(co[-1]*(n*(n+1)+A)/(2*(n+1)**2))
    P=sum((co[n]*v**n for n in range(N+1)),F(0))
    Pv=sum((n*co[n]*v**(n-1) for n in range(1,N+1)),F(0))
    r0=v*(1+A/F((N+2)**2))/2
    r1=v*(1+A/F((N+1)*(N+2)))/2
    if not (r0<1 and r1<1):raise ValueError('Tail ratio is not contractive')
    return P,P+co[N+1]*v**(N+1)/(1-r0),Pv,Pv+(N+1)*co[N+1]*v**N/(1-r1)


def kernel_checks(protocol):
    certs=[];bvp_results=[]
    for case in protocol['kernel_cases']:
        bt=case['B'];B=F(bt);bm=m(B)
        den=rational_bounds(B,F(0));q=kernel(bt,1)[0]
        rec('candidate_parameter_correspondence.'+bt,'positive',4*(3*(1+F(case['k']))+F(case['nu']))/(1-3*F(case['k']))==B)
        for xt in protocol['kernel_x']:
            x=F(xt);xm=m(x);p0,p1,pv0,pv1=rational_bounds(B,x)
            plo,phi=p0/den[1],p1/den[0]
            dlo,dhi=(p0+x*pv0)/den[1],(p1+x*pv1)/den[0]
            psi,psip,psipp=kernel(bt,xm);D=psi-xm*psip
            ok=m(plo)<=psi<=m(phi) and m(dlo)<=D<=m(dhi)
            rec('rational_enclosure.'+bt+'.'+xt,'positive',ok,psi=ns(psi),D=ns(D),psi_width=ns(m(phi-plo)),D_width=ns(m(dhi-dlo)))
            certs.append({'B':bt,'x':xt,'N':96,'psi_rational_interval':[str(plo),str(phi)],'D_rational_interval':[str(dlo),str(dhi)]})
        horizon=kernel(bt,1)
        rec('horizon_Robin.'+bt,'positive',abs(horizon[1]-(1-bm/2)*horizon[0])<mp.mpf('1e-65'),residue=ns(horizon[1]-(1-bm/2)*horizon[0]))
        integral=bm*mp.quad(lambda x:x*kernel(bt,x)[0],[0,mp.mpf('.5'),1])
        rec('integrated_point_flux.'+bt,'positive',abs(integral-1)<mp.mpf('1e-65'),integral=ns(integral))
        for xt in ('1/10','1/2','9/10'):
            x=m(F(xt));psi,psip,psipp=kernel(bt,x);V,Vp=center_kernel(bt,x)
            y=psi/x;yp=psip/x-psi/(x*x)
            W=x*x*(1-x*x)*(V*yp-Vp*y)
            residual=(1-x*x)*psipp-2*x*psip+(2-bm)*psi
            rec('ODE_Wronskian.'+bt+'.'+xt,'positive',abs(W+1)<mp.mpf('1e-60') and abs(residual)<mp.mpf('1e-60'),W=ns(W),ODE_residue=ns(residual))
        A=float(B-2)
        S=np.array([[0.,0.],[A/2.,-1.]])
        def fun(t,Y):return np.vstack((Y[1],(A*Y[0]/2+Y[1])/(2-t)))
        def bc(ya,yb):return np.array([ya[1]-A*ya[0]/2,yb[0]-1])
        mesh=np.linspace(0,1,161)
        sol=solve_bvp(fun,bc,mesh,np.vstack((np.ones_like(mesh),np.zeros_like(mesh))),S=S,tol=2e-10,max_nodes=12000)
        errors=[]
        for x in np.linspace(0,1,41):
            actual=sol.sol(1-x);ref=kernel(bt,mp.mpf(str(x)))
            errors.extend([abs(m(str(actual[0]))-ref[0])/max(abs(ref[0]),mp.mpf('1e-20')),
                           abs(m(str(actual[1]))+ref[1])/max(abs(ref[1]),mp.mpf('1'))])
        worst=max(errors)
        rec('independent_singular_endpoint_BVP.'+bt,'BVP',sol.status==0 and worst<mp.mpf('2e-7'),status=int(sol.status),message=sol.message,nodes=len(sol.x),maximum_error=ns(worst),maximum_rms_residual=float(max(sol.rms_residuals)))
        bvp_results.append({'B':bt,'status':int(sol.status),'nodes':len(sol.x),'maximum_comparison_error':ns(worst),'horizon_psi':ns(q)})
    OUTPUTS['rational_certificates']=certs;OUTPUTS['independent_BVPs']=bvp_results


def metric_seed(bt,k,R,mass):
    def a(r):return -k*mass*kernel(bt,r)[0]/r
    rr=mp.findroot(lambda r:r*mp.exp(a(r))-R,(R*(1-mp.mpf('1e-6')),R*(1+mp.mpf('1e-6'))))
    psi,psip,_=kernel(bt,rr);aa=-k*mass*psi/rr
    ap=k*mass*(psi-rr*psip)/(rr*rr)
    h=1-rr*rr-2*mass/rr;hp=-2*rr+2*mass/(rr*rr)
    FF=mp.exp(2*aa)*h;GG=h*(1+rr*ap)**2
    holding=mp.exp(-aa)*(hp+2*ap*h)/(2*mp.sqrt(h))
    return FF,GG,holding


def physical_checks(protocol):
    rows=[]
    for case in protocol['kernel_cases']:
        bt=case['B'];k=m(F(case['k']))
        for xt in protocol['physical_metric_x']:
            R=m(F(xt));f=1-R*R;psi,psip,_=kernel(bt,R);D=psi-R*psip
            q=-k*psi/R;qp=k*D/(R*R)
            expected=[-2/R+2*q,-2/R+2*R*R*q+2*f*R*qp]
            T=(1-2*R*R)/f**mp.mpf('1.5')
            S=(f*f*D-R*R*(1+f)*psi)/f**mp.mpf('1.5')
            expected.append((T+k*S)/(R*R))
            h=mp.mpf('1e-8')*R*f
            errs=[]
            for step in (h,h/2):
                plus=metric_seed(bt,k,R,step);minus=metric_seed(bt,k,R,-step)
                derived=[(a-b)/(2*step) for a,b in zip(plus,minus)]
                errs.append(max(abs(a-b)/max(1,abs(b)) for a,b in zip(derived,expected)))
            rec('physical_areal_metric_holding.'+bt+'.'+xt,'positive',max(errs)<mp.mpf('1e-10'),mass_step=ns(h),errors=[ns(e) for e in errs],T=ns(T),S=ns(S),S_over_T=ns(S/T))
            rows.append({'B':bt,'k':case['k'],'x':xt,'T':ns(T),'S':ns(S),'S_over_T':ns(S/T),'max_error':ns(max(errs))})
    bt='1612/97';k=mp.mpf('.01');mass=mp.mpf('1e-6')
    for xt,expect_orbit in [('1/200',True),('1/4',False)]:
        R=m(F(xt));f=1-R*R;psi,psip,_=kernel(bt,R);D=psi-R*psip
        FF=f-2*mass/R-2*k*mass*psi/R
        numerator=-R*R+mass/R*(1+k*D)
        velocity=numerator/FF
        admissible=FF>0 and 0<velocity<1
        rec('circular_domain.'+xt,'positive' if expect_orbit else 'negative',admissible==expect_orbit,numerator=ns(numerator),v_squared_over_c_squared=ns(velocity),m_over_Rf=ns(mass/(R*f)))
    rec('tensor_ratio_zero_denominator','negative',F(1)-2*F(1,2)==0,x_squared='1/2',implication='Holding difference exists; division by tensor difference is undefined.')
    R=mp.mpf('.5');psi,psip,_=kernel(bt,R);D=psi-R*psip;f=1-R*R
    correct=(f*f*D-R*R*(1+f)*psi)/(1-2*R*R)
    rec('damaged_coordinate_gradient_readout','negative',abs(correct-D)>mp.mpf('1e-3'),proper_ratio=ns(correct),coordinate_kernel=ns(D),difference=ns(correct-D))
    q=-k*psi/R
    rec('damaged_unconverted_areal_radius','negative',abs(2*q-2*f*q)>mp.mpf('1e-6'),missing_time_coefficient=ns(2*q-2*f*q))
    OUTPUTS['physical_readouts']=rows


def source_checks(protocol):
    results=[]
    for case in protocol['prescribed_source_cases']:
        bt=case['B'];B=float(F(bt));radius=float(F(case['radius']));rm=m(F(case['radius']))
        smooth=case['profile']!='constant'
        rho=lambda x:(1-(x/rm)**2)**2 if smooth else mp.mpf(1)
        denominator=mp.quad(lambda x:rho(x)*x*x,[0,rm])
        numerator=mp.quad(lambda x:rho(x)*x*x*center_kernel(bt,x)[0],[0,rm])
        exact_charge=numerator/denominator
        vmax=center_kernel(bt,rm)[0]
        errors=[];estimates=[]
        for N in protocol['source_grids']:
            edges=np.linspace(0,1,N+1);centers=(edges[:-1]+edges[1:])/2;dx=1/N
            p=edges**2*(1-edges**2);vol=(edges[1:]**3-edges[:-1]**3)/3
            diag=(p[:-1]+p[1:])/dx+B*vol
            A=diags([-p[1:-1]/dx,diag,-p[1:-1]/dx],[-1,0,1],format='csc')
            lo=np.minimum(edges[:-1],radius);hi=np.minimum(edges[1:],radius)
            def prim(x):
                return x**3/3-2*x**5/(5*radius**2)+x**7/(7*radius**4) if smooth else x**3/3
            rhs=prim(hi)-prim(lo)
            u=spsolve(A,rhs)
            extracted=[]
            for loc in (.65,.8,.95):
                idx=int(loc*N);xx=mp.mpf(str(centers[idx]));yy=kernel(bt,xx)[0]/xx
                extracted.append(m(str(u[idx]))/(yy*denominator))
            err=max(abs(v-exact_charge)/exact_charge for v in extracted)
            errors.append(err);estimates.append({'grid':N,'charges':[ns(z) for z in extracted],'relative_error':ns(err)})
        rec('prescribed_body_finite_volume.'+bt,'BVP',errors[-1]<mp.mpf('2e-5') and errors[-1]<errors[0]/8,profile=case['profile'],radius=case['radius'],Green_weight_charge=ns(exact_charge),V_support_edge=ns(vmax),errors=[ns(z) for z in errors])
        rec('positive_body_weight_bound.'+bt,'positive',1<=exact_charge<=vmax,charge=ns(exact_charge),upper_bound=ns(vmax))
        rec('damaged_body_weight_unity.'+bt,'negative',abs(exact_charge-1)>mp.mpf('1e-3'),correct_charge=ns(exact_charge),wrong_charge='1')
        results.append({'case':case,'charge':ns(exact_charge),'grids':estimates})
    OUTPUTS['prescribed_body_finite_volume']=results


def damages_and_energy():
    bt='1612/97';B=m(F(bt));x=mp.mpf('.4')
    wrong_bt=str(F(bt)+2)
    wp,wpp,wppp=kernel(wrong_bt,x)
    wrong_res=(1-x*x)*wppp-2*x*wpp+(2-B)*wp
    rec('damaged_Legendre_degree','negative',abs(wrong_res)>mp.mpf('1e-3'),raw_correct_operator_residue=ns(wrong_res))
    norm=params(bt)[3]
    rec('damaged_point_normalization','negative',abs(norm-1)>1,wrong_source_flux=ns(-norm),required_source_flux='-1')
    base=F(bt);A=base-2;N=8;aa=F(1)
    for n in range(N+1):aa*= (n*(n+1)+A)/F(2*(n+1)**2)
    nxt=aa*((N+1)*(N+2)+A)/F(2*(N+2)**2)
    rec('damaged_tail_geometric_factor','negative',aa+nxt>aa,claimed_tail_bound=str(aa),positive_two_term_tail_lower_bound=str(aa+nxt))
    rec('massless_bounded_branch_wrong_flux','negative',True,bounded_psi='x',psi_at_center='0',required='1',independent_unit_source_solution='1/x-atanh(x)+constant')
    horizons=[]
    for eps in ('1e-3','1e-5','1e-7'):
        xx=1-m(eps);psi,_,_=kernel(bt,xx);V,_=center_kernel(bt,xx)
        horizons.append({'epsilon':eps,'bounded':ns(psi/xx),'same_flux_contaminated':ns(psi/xx+V/10),'center_regular_V':ns(V)})
    growth=m(horizons[-1]['same_flux_contaminated'])/m(horizons[0]['same_flux_contaminated'])
    rec('damaged_horizon_branch_same_point_flux','negative',growth>2,growth_factor=ns(growth),point_flux_change='0 because V is center regular',horizon_samples=horizons)
    eb='13';Bm=m(F(eb));qh=kernel(eb,1)[0]
    def eR(xx):
        psi,psip,_=kernel(eb,xx);y=psi/xx;yp=psip/xx-psi/(xx*xx)
        return xx*xx*((1-xx*xx)*yp*yp+Bm*y*y)/2
    def eQ(xx):
        V,Vp=center_kernel(eb,xx)
        return xx*xx*((1-xx*xx)*Vp*Vp+Bm*V*V)/2
    energies=[]
    for eps in ('1e-2','1e-4','1e-6'):
        energies.append(mp.quad(eR,[mp.mpf('.1'),mp.mpf('.5'),1-m(eps)]))
    rec('bounded_branch_finite_exterior_energy','positive',energies[2]>energies[1]>energies[0] and energies[2]-energies[1]<mp.mpf('.01')*(energies[1]-energies[0])*mp.mpf('1.02'),energies=[ns(z) for z in energies])
    eps1=mp.mpf('1e-5');eps2=mp.mpf('1e-7')
    band=mp.quad(eQ,[1-eps1,1-mp.sqrt(eps1*eps2),1-eps2])
    expected=mp.log(eps1/eps2)/(4*qh*qh)
    rec('log_branch_infinite_energy_coefficient','positive',abs(band/expected-1)<mp.mpf('1e-3'),energy_band=ns(band),leading_log_band=ns(expected),ratio=ns(band/expected))
    ep=mp.mpf('1e-5');uv=mp.quad(eR,[ep,2*ep])
    rec('negative_global_point_finite_energy','negative',abs(4*ep*uv-1)<mp.mpf('1e-6'),UV_band=ns(uv),scaled_asymptotic=ns(4*ep*uv))
    xx=sp.symbols('xx');ff=1-xx*xx;trial=xx*xx*(1-xx);phi=trial/xx;BB=sp.Integer(13)
    Eph=sp.integrate((xx*xx*(ff*sp.diff(phi,xx)**2+BB*phi**2))/2,(xx,sp.Rational(1,4),sp.Rational(3,4)))
    Eps=sp.integrate((ff*sp.diff(trial,xx)**2+(BB-2)*trial**2)/2,(xx,sp.Rational(1,4),sp.Rational(3,4)))
    boundary=(ff*trial**2/xx).subs(xx,sp.Rational(3,4))-(ff*trial**2/xx).subs(xx,sp.Rational(1,4))
    exact('finite_annulus_energy_identity',Eph-Eps,-boundary/2)
    rec('damaged_energy_boundary_sign','negative',sp.simplify(Eph-Eps-boundary/2)!=0,wrong_identity_residue=str(sp.simplify(Eph-Eps-boundary/2)))
    rec('damaged_wave_potential_missing_minus_two','negative',2*(1-F(1,4))!=0,at_x='1/2',potential_error=str(2*(1-F(1,4))))
    s=1.;rhmax=12.;Bfloat=13.
    def ode(rho,Y):
        x=np.tanh(rho);V=(1-x*x)*(Bfloat-2)
        return [Y[1],(s*s+V)*Y[0]]
    sol=solve_ivp(ode,(rhmax,0),[np.exp(-rhmax),-np.exp(-rhmax)],method='DOP853',rtol=2e-12,atol=2e-14,dense_output=True)
    scale=sol.sol(0)[0]
    def integrand(rho):
        w,wp=sol.sol(rho)/scale;x=np.tanh(rho);V=(1-x*x)*(Bfloat-2)
        return wp*wp+(V+s*s)*w*w
    val,err=quad(integrand,0,rhmax,epsabs=1e-10,epsrel=1e-10)
    w0,wp0=sol.sol(0)/scale;wh,wph=sol.sol(rhmax)/scale
    bd=wh*wph-w0*wp0
    rec('damaged_regular_center_condition','negative',sol.success and abs(w0-1)<1e-12 and abs(val-bd)<2e-8 and val>1,outgoing_growing_s='1',regular_center_violated_w0=float(w0),positive_bulk=val,boundary_term=bd,integration_error_estimate=err,implication='Outgoing decay plus positive potential does not remove a supplied nonregular inner boundary.')
    OUTPUTS['boundary_energy']={'bounded_cutoff_energies':[ns(z) for z in energies],'logarithmic_band_ratio':ns(band/expected),'point_UV_scaled':ns(4*ep*uv),'outgoing_nonregular_center_bulk':val,'outgoing_nonregular_center_boundary':bd}


def main():
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    protocol=json.loads((HERE/'CONTROL_PROTOCOL_v1.json').read_text())
    manifest=json.loads((HERE/'SOURCE_MANIFEST_v1.json').read_text())
    for row in manifest['files']:
        snapshot=(HERE/row['snapshot_path']).read_bytes()
        live=Path(row['source_path']).read_bytes()
        rec('source_identity.'+row['snapshot_path'],'source_identity',hashlib.sha256(snapshot).hexdigest()==row['sha256'] and live==snapshot,sha256=row['sha256'])
    symbolic_checks()
    kernel_checks(protocol)
    physical_checks(protocol)
    source_checks(protocol)
    damages_and_energy()
    total=len(RECORDS);satisfied=sum(r['satisfied'] for r in RECORDS)
    result={'started_utc':started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope':'Independent supplied-action static-curved kernel, readout, source-weight and boundary-energy check; no producer code/output read or imported.',
            'environment':{'python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__,'scipy':scipy.__version__,'numpy':np.__version__},
            'records':RECORDS,'outputs':OUTPUTS,'summary':{'count':total,'satisfied':satisfied,'unsatisfied':total-satisfied},
            'model_history_or_empirical_fit_runs':0,'no_producer_code_or_output_read':True}
    print(json.dumps(result,indent=2))
    return 0 if satisfied==total else 1


if __name__=='__main__':
    sys.exit(main())
