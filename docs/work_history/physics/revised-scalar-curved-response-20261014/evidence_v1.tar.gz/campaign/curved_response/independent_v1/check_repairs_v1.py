#!/usr/bin/env python3
"""Only failed checker conditions plus an executable massless limit control.

The original 107 passing records are preserved. This script imports this
checker's own kernel functions only; it does not run its main or producer code.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import sympy as sp
import mpmath as mp

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_curved_helpers',HERE/'check_independent_v1.py')
helpers=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
mp.mp.dps=80


def main():
    records=[]
    x,B,b1=sp.symbols('x B b1')
    coeff=[sp.Integer(1),b1]+list(sp.symbols('c2:7'))
    trial=sum(c*x**n for n,c in enumerate(coeff))
    raw=sp.Poly(sp.expand((1-x*x)*sp.diff(trial,x,2)-2*x*sp.diff(trial,x)+(2-B)*trial),x)
    solved=sp.solve([raw.coeff_monomial(x**n) for n in range(5)],coeff[2:],dict=True)[0]
    expansion=sp.expand(trial.subs(solved))
    # Correction: expand the WHOLE subtraction before coefficient extraction.
    D=sp.Poly(sp.expand(expansion-x*sp.diff(expansion,x)),x)
    expected={2:-(B-2)/2,3:-B*b1/3,4:-(B+4)*(B-2)/8}
    for degree,wanted in expected.items():
        actual=D.coeff_monomial(x**degree)
        residue=sp.factor(actual-wanted)
        records.append({'name':'center_D_x'+str(degree),'kind':'symbolic','satisfied':residue==0,
                        'evidence':{'derived':str(actual),'expected':str(wanted),'residue':str(residue)},
                        'repair_reason':'The v1 script called coeff on an unexpanded subtraction, so it missed the differentiated term. The source formula was correct.'})
    q=helpers.kernel('13',1)[0]
    def energy(xx):
        V,Vp=helpers.center_kernel('13',xx)
        return xx*xx*((1-xx*xx)*Vp*Vp+13*V*V)/2
    # Retain the 1e-3 tolerance and refine the asymptotic cutoff by a factor 10.
    # No candidate parameter, equation, or mathematical limit changes.
    eps1=mp.mpf('1e-6');eps2=mp.mpf('1e-8')
    band=mp.quad(energy,[1-eps1,1-mp.sqrt(eps1*eps2),1-eps2])
    leading=mp.log(eps1/eps2)/(4*q*q)
    ratio=band/leading
    records.append({'name':'log_branch_infinite_energy_coefficient','kind':'positive',
                    'satisfied':abs(ratio-1)<mp.mpf('1e-3'),
                    'evidence':{'epsilon1':str(eps1),'epsilon2':str(eps2),'energy_band':mp.nstr(band,60),
                                'leading_log_band':mp.nstr(leading,60),'ratio':mp.nstr(ratio,60),
                                'unchanged_relative_tolerance':'1e-3',
                                'original_ratio':'1.00101712532444808226924095009203935437784901'},
                    'repair_reason':'The original finite cutoff was slightly outside the chosen asymptotic tolerance. Only the cutoff is refined, with the tolerance retained.'})
    bounded_psi=x
    bounded_flux=sp.limit(x*x*(1-x*x)*sp.diff(bounded_psi/x,x),x,0,dir='+')
    unit_kernel=1/x-sp.atanh(x)
    unit_flux=sp.simplify(x*x*(1-x*x)*sp.diff(unit_kernel,x))
    horizon_limit=sp.limit(unit_kernel,x,1,dir='-')
    records.append({'name':'massless_bounded_branch_wrong_flux','kind':'negative',
                    'satisfied':bounded_flux==0 and unit_flux==-1 and horizon_limit==-sp.oo,
                    'evidence':{'bounded_branch_flux':str(bounded_flux),'unit_source_flux':str(unit_flux),
                                'unit_source_horizon_limit':str(horizon_limit)},
                    'repair_reason':'Replaces the original documentary true-valued massless entry with executed symbolic flux and limit calculations; the original entry is retained.'})
    passed=sum(r['satisfied'] for r in records)
    result={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope':'Four targeted checker repairs and one executed replacement for a documentary control; no successful BVP, metric, source, or history computation rerun.',
            'records':records,'summary':{'count':len(records),'satisfied':passed,'unsatisfied':len(records)-passed}}
    print(json.dumps(result,indent=2))
    return 0 if passed==len(records) else 1


if __name__=='__main__':sys.exit(main())
