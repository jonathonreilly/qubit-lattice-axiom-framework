Personally derived by /root. This is an inverse theorem for ideal input functions, not a reconstruction from already measured data. It keeps the action-class and source-control premises visible. No state selector, raw-data fit or fundamental scale value is introduced.

### 1. Scope of the inverse

Restrict the supplied candidate to x=y=0. This is a consistent classical truncation for its matter coupling: K_uu and A depend only on u, partial_x K_uu=partial_y K_uu=0, and U_x=U_y=b_x=b_y=0 there. It does not select that sector dynamically or identify arbitrary transverse action functions. More generally consider a single coupled dimensionless scalar chi with Einstein action

 S=integral sqrt(-g_E)[Q R_E/2-Q(partial chi)^2-V_E(chi)]+S_m[A(chi)^2 g_E,psi].

Let Q>0 be fixed, A>0 and q=(d ln A/d chi)^2>0 on a connected branch. Work in natural units. The ideal reconstruction inputs are the tensor-force coefficient G=G_bare=A^2/(8 pi Q), the coupling q as a function of G, and the stationary physical nonrelativistic rest density rho_J as a function of G, all in common physical units. These would require controlled readout geometry, environment and source response. No such complete measured functions have been obtained here. G_cal alone is not automatically G.

### 2. The conformal action transformation is derived, not chosen

Put F=Q/A^2=1/(8 pi G), lambda=ln A, and V_J=V_E/A^4. For g_E=A^-2 g_J, the Ricci contribution is

 sqrt(-g_E) Q R_E/2
 =sqrt(-g_J)[F R_J/2+3F box_J lambda-3F(partial lambda)^2].

After a boundary integration, 3F box lambda gives -3 partial F partial lambda=+6F(partial lambda)^2. The original scalar kinetic term becomes -F(partial chi)^2=-F(partial lambda)^2/q. Since partial lambda=-partial F/(2F), the action is

 S=integral sqrt(-g_J)[ F R_J/2 - omega(F)(partial F)^2/(2F)-V_J(F)]
     +S_m[g_J,psi],
 omega(F)=(1/q(F)-3)/2.                                  (1)

This field redefinition requires q>0 to use F as a coordinate. A zero coupling point must be treated in a different chart. For the candidate q<1/3, omega>0; the invariant kinetic positivity condition is 2omega+3=1/q>0. Positivity is not inferred merely from an arbitrary Jordan kinetic coefficient. Boundary terms and admissible variations must be handled consistently. No additional free omega function has been postulated: under these class premises it is reconstructed from the supplied ideal response function q(F).

The corresponding Einstein coordinate is determined up to orientation and an additive constant:

 dchi = +/- d ln F/(2 sqrt(q(F))).                       (2)

An absolute Q and a globally chosen Einstein normalization are not obtained by this reparametrization.

### 3. The density family reconstructs a potential, with one surviving constant

Vary the particle action at fixed Einstein proper particle density rho_*=m_J n_E and fixed Einstein metric. Its energy density is rho_* A. The stationary equation is

 dV_E/dchi + rho_* dA/dchi=0.

Because rho_*=rho_J A^3 and A_chi is nonzero, on the stationary family

 dV_E/dA=-rho_J(A) A^3.                                 (3)

Changing to F and V_J gives the exact first-order reconstruction equation

 2F V_J'(F)-4V_J(F)=rho_J(F),
 V_J(F)=F^2[C+integral_(F_ref)^F rho_J(f)/(2 f^3) df].     (4)

Equivalently,

 V_J(G)=[G_ref^2 V_J(G_ref)
             -(1/2)integral_(G_ref)^G rho_J(g) g dg]/G^2. (5)

Thus q(F) and rho_J(F), if they were determined on an interval, reconstruct the single-field Jordan action functions there up to one potential constant C. The homogeneous ambiguity V_J->V_J+C_add F^2 is exactly a constant Einstein potential shift V_E->V_E+C_add Q^2. It leaves the stationary density equation and its scalar derivative unchanged. It changes the gravitational stress and curvature, so it is not an equivalence of complete background solutions. No off-interval extension, transverse field metric/potential or unique three-field action follows.

A reference curvature can remove this remaining constant only with additional justified data. If the scalar is constant in a region and its derivative stress vanishes, the Jordan metric trace for dust is F R_J=rho_J+4V_J. Then one measured R_J and rho_J there supplies V_J=(F R_J-rho_J)/4. A generic rolling or spatially varying region has derivative terms; using that formula there would import a false premise. The present expansion rate alone is not such a curvature measurement.

### 4. The probe's density constraint changes the mass coefficient

Let M_0,E^2 be the scalar Hessian at fixed rho_* divided by the actual kinetic coefficient 2Q. In the notation of the preceding susceptibility theorem it is Hess(V_E/(2Q))+rho_* Hess(A)/(2Q). If an imposed local perturbation instead has

 delta ln rho_* = p delta ln A,

then differentiating the scalar source gives

 M_p,E^2=M_0,E^2+p c_rho beta beta^T, c_rho=rho_E/(2Q).

For several fields this formula is written in a K-orthonormal field frame, with beta_a=e_a^A partial_A ln A and M^2 the corresponding mass matrix. In general field coordinates the covariant Hessian shift is p c_rho beta_A beta_B, while the mass endomorphism shift is p c_rho K^{AC} beta_C beta_B. With that basis convention, the expression holds when the scalar proportional-response law is stipulated. It is a local source prescription; actual material dynamics could be frequency dependent, nonlocal or tensorial and must be derived separately. It does not establish a pressure-supported or self-gravitating source.

For the single coupled mode and a frozen frame,

 m_p,J^2=m_0,J^2+p q rho_J/(2F).

On a positive-density portion with rho_J'(F)!=0, the local inverse and logarithmic derivative are defined, giving B=-d ln G/d ln rho_J=rho_J/(F rho_J'). The mass formulas below do not require division by rho_J or rho_J'; they remain algebraic identities at zero or turning densities wherever the underlying stationary family is smooth. The reconstruction yields

 m_0,J^2=q[rho_J' -3rho_J/(2F)],
 m_p,J^2=q[rho_J' +(p-3)rho_J/(2F)],
 m_3,J^2=q rho_J'.                                      (6)

Here p=0 fixes Einstein particle density, while p=3 fixes the physical density in the source algebra at fixed Einstein metric. They are different source-response prescriptions, not different predictions for the same fully specified experiment. For example keeping physical density fixed can require particle/geometry control; a reservoir or its support stress has not been constructed. A physical Jordan-frame scalar equation after eliminating the metric trace has the corresponding fixed-source coefficient q(2F V_J''-2V_J')=q rho_J' about a constant stationary background. That algebraic agreement does not show that a particular apparatus holds the required source fixed or that its full coupled spectrum is this coefficient.

The earlier stable fixed-particle susceptibility bound is B<2/3. It must not be inferred from positivity of m_3 alone. The function rho_J(F)=rho_ref(F/F_ref)^n, n>0, supplies a counterexample family: B=1/n, m_0^2=q rho_J(n-3/2)/F and m_3^2=q rho_J n/F. Thus 0<n<3/2 has a positive fixed-physical-density coefficient but a negative fixed-particle mass. This does not violate frame equivalence: changing the held-fixed matter data changes the perturbation problem.

### 5. Constructive exact inverse examples and what can be tested

For that power-law family, n!=2 gives

 V_J=C F^2+rho_ref F^n/[2(n-2)F_ref^n].

At n=2 the exact solution is

 V_J=F^2[C+rho_ref ln(F/F_ref)/(2F_ref^2)].

Both satisfy (4). C can be chosen so that V_J>0 on a chosen compact interval, but choosing C in a synthetic control is not a derived vacuum energy. The examples with n=1 and n=3 will explicitly distinguish the two mass prescriptions. A nonconstant positive q(F) will test the kinetic transformation without freezing omega by assumption. Added C F^2 will demonstrate the density/response degeneracy while changing the metric trace.

The candidate's original density map is a conditional specialization of this inverse. It will be checked by differentiating its transformed original potential, not fitted to new data. A density curve alone supplies neither q nor the potential offset; a single density point supplies only one equation, not an entire function. Multiple reconstructed action functions agreeing with these ideal inputs remain unconstrained off the sampled interval and in unprobed field directions. Preparing equilibrium and acquiring an independent validation configuration are unresolved empirical tasks.

### 6. External convention cross-check

The Jordan action, trace-eliminated scalar equation and constant-omega mass convention were checked against Quiros et al., arXiv:1506.05420v2, pp.2-3, Eqs.(1)-(3),(8). Its action is twice ours under F=phi and V=V_J, so the field equations agree. Only this normalization check is used; its environmental phenomenology and broad frame claims are not adopted. The variable-omega term is derived separately by variation here. The earlier Khoury/Weltman particle-density convention remains a separate source.

This source was accessed during model development before the new controls. It is not an independent empirical test. Original PDFs and exact local commands are retained. The calculations and inverse conclusions above are personally derived from the declared action and density definitions.
