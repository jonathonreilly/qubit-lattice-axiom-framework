# Staged canonical correspondence: density response and single-field action inverse

Checker: /root/scalar_energy_check. Scientific author: /root. Scope: staged source, function, output and recovery correspondence for milestone15. This is not new theory authorship, a formal audit, a live-cache validation or a delivery/PR identity check.

The staged note preserves both complete checked hand-derivation bodies. The four science functions preserve their declared source expressions after the documented function/input/metadata transformations. Every one of the 240 actual staged result rows and every substantive output value agrees with the original outputs after only the specified namespace and input-provenance changes. No author-source correction is needed.

The original independently checked mathematics is reused by exact identity. I executed no producer science function, root solve, quadrature or trajectory in this correspondence unit. New execution consisted of static comparisons, byte verification and the actual extracted canonical wrapper with synthetic function stubs. The frozen staged note and runner remain unchanged. Their later copy to canonical paths, live declared-input cache and committed delivery identity require a separate check.

## Exact staged identity and bodies

The staged files are in density_inverse_packaging/staged/:

| File | SHA256 |
|---|---|
| EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md | 40f112537627dd19ea0090a673f355f0d122c52844853798287f55e5b671e3fb |
| exponential_scalar_density_inverse_check.py | d6b9d8a054551b19991d0d7a99cbb36c8824654b02dab87891497042c5cdfc56 |

CANONICAL_LINEAGE_v1.json, SHA256 b3cec9e9542b7f29653524e7d16fedc95ceb4cbd619ece0ca401167aa2881d97, declares the following two note sources:

| Hand source | Source SHA256 | Transformed body SHA256 |
|---|---|---|
| environment_susceptibility_identity_v1/DERIVATION_v1.md | fc8d310cef1ae01b8a709067fdb43ee45ecc58ddd217c2b577cdd86a0c10fcba | d82c973fa922b5f90a6d0bb3a5f0de09ed56c779841b4d95bd6a83bbd19a6192 |
| density_action_reconstruction_v1/DERIVATION_v2.md | 18b59326f5fa496653fb4df6f3faa70e7aabe8d914249ac402d1237abd82d732 | f0f213f18a16846e872cbacb6061ecbf5831424ca6c41dad049168b3d9b46565 |

The transformation removes the first title line, demotes each remaining Markdown heading once, trims boundary blank lines and supplies a final newline. Each complete transformed body occurs exactly once in the staged note. The ESI body occupies lines 26–106 and the DAR body lines 110–209, using the newline extent recorded by the checker. No equation, coefficient, premise, limitation or substantive prose inside either body changed. Transformed body snapshots and their hashes are preserved locally.

The canonical introduction and ending were also read in full. They frame the result as an ideal-input inverse, explicitly distinguish source controls and identify synthetic development data. They add no measured-function, state-selection, scale-selection or full-apparatus claim. The full action, local-response and environment canonical notes remain declared dependencies. They were frozen as dependency bytes; this check does not freshly review all mathematics in those notes.

## Original independent science reused, with its actual history

Three independent reports/receipts/manifests were bound and their entire current inventories were verified by hash. The reports remain earlier evidence, not new runs or independent samples of the staged wrapper.

| Unit | Science evidence reused | Manifest artifacts | Receipt SHA256 |
|---|---|---:|---|
| density environment | original 146/0 and susceptibility 49/0; eight actual changed implementations across those checks; source v3 | 126 | e82004e2c5f13849b603a79cf677e63acca3c403a1e2639fb7b0eac72429ec86 |
| general susceptibility identity | independent 114/0; six actual changed implementations | 81 | e6c936f1bcf4fe11c9c0053ae812fe8d97927aacf853562a80d44f901a3e7e08 |
| density action reconstruction | independent 118/0; eight actual changed implementations; narrow v2 confirmation 33/0 | 91 | 2a119155f2e744d4945eab2365ffa5f6f8b3b6278a2867dfc53fe005c69b6fa9 |

The corresponding report hashes are density 787afa9af5ec790350b51ef96df1e1e0c935690e92266a5242186b4e8f194dd9, ESI 804a12d899096fd418297492373fc6b2720c35e460744bcd258fd566aff7dbd5 and DAR 8ed5d879db6511b0517434dc7686f368d812322e820e5c307af668c742605951. Their manifest hashes are respectively 4277dfc4a1b0bacb8551c8212ba6323343cf51531a15195b437409289a0cc4fd, 3112e208776a31ceb0d6bd7978900eeec4bfebb266ad80068debef8e373e68fb and e4237fcdebdaaef90e0c97cf84f16f0ef77014a24fe451057e58e35dd7f1e8c4.

I read the newly sealed DAR report completely. It confirms the conditional inverse from the action, field-coordinate conversion, potential constant, source-controlled masses and candidate specialization. It also preserves the original two missing qualifications: the logarithmic B inverse needs positive density and a nonzero density derivative, and the multifield mass matrix needs an explicit K-orthonormal basis or the appropriate inverse-metric endomorphism. Its original reviewer read the complete v2 and exact diff; only those qualifications changed, with no equation or coefficient change and no baseline rerun. The staged body is exactly that confirmed v2.

The DAR review independently inspected the stated Quiros primary-PDF convention and explicitly restricted its use to action/equation normalization. This unit relies on that source-bound review; it does not claim a new PDF or phenomenology review. The copied v1, v2 correction record and exact diff preserve the original premise omissions. The DAR review's metadata-schema failure and repair remain in its original sealed inventory and report.

The general susceptibility report confirms the rank-one derivative under a positive fixed-particle mass, the frame/SI conversion, the hidden-instability false converse and the calibration-envelope derivative limitation. It expressly warns that a prospective apparatus must identify its source perturbation constraint. The canonical introduction and DAR body retain that warning rather than treating all measured ranges as prescription independent.

All 298 manifest artifacts across the three units, their six manifest/receipt files, and all 31 source pairs inside those receipts were verified against the retained live bytes. REUSED_SEAL_RECOVERY_v1.json records each original root and every constituent hash. The old density receipt's disclosed metadata-only accidental producer-diff copy after its original science remains preserved. During this packaging check that historical byte artifact was hashed with the rest of the inventory; it was not interpreted as a scientific input. Earlier blind-access histories have not been rewritten.

## Science-function correspondence

The named original producer implementations were read only after the independent science seals, under this task's explicit correspondence authorization. No producer science body was executed here.

| Staged function | Original source | Transformation |
|---|---|---|
| check_density_environment | scripts/exponential_scalar_environment_bridge_check.py, SHA cfff062268624def956d92e737349524153932cbc33195e6f415f8719aa5305d | exact entire function AST |
| check_identity | ESI/check_identity_v1.py, SHA 1d0bbc19b7a23871da5e9914e3f9497da1c6bb8d1c6a282e216f9d7cd9cba6f1 | rename run; add saved parameter; remove only scratch Path/load statements; replace input-hash metadata with in-memory provenance |
| check_reconstruction | DAR/check_reconstruction_v1.py, SHA 698c0ec3392aa6acd43fbc4c1bd00b493a3b283876b0911455dd1d2b01ff3d53 | rename run only |
| check_domains | DAR/check_domains_v1.py, SHA 497f807a7fbedff5b480baeb6e30ac270351455ff9afa0750a3c6e179ffa03f8 | rename run only |

AST comparisons include all mathematical assignments, check expressions, return tables, control tolerances and nested functions. All six named global control constants are unchanged. The density function's original source file also contains unrelated finite-body and other susceptibility functions; those were not transferred, executed or newly endorsed by this milestone.

The original ESI function used source both for a mathematical source vector and, later, a file path. The staged version preserves the mathematical assignment. Only these two later statements are removed:

    source=Path(__file__).parent.parent/'density_environment_v1/RESULTS_v1.json'
    saved=json.loads(source.read_text())

The function receives the freshly computed density dictionary instead. Its return field saved_root_input_sha256 becomes root_input_kind='fresh in-memory density calculation'. Every other AST node agrees after the function rename and argument addition. The function contains no internal file read. The wrapper computes density once and supplies that same object to check_identity; it does not load or fit an independent density scratch input.

The corrected static comparison returned 103/0. An earlier reviewer-normalization error returned 101/2 and is retained; it is described below. The full normalized AST representations and complete comparison details are saved. The correspondence establishes exactly retained expressions, not that every finite control independently proves every prose theorem.

## Actual staged execution and complete original-output comparison

The actual parent staged execution began 13:59:33.049204 UTC and ended 13:59:34.108478 UTC on 2026-10-14. The recorded command exited 0. STAGED_RESULTS_v1.json contains 240 rows: 96 density, 53 general susceptibility, 63 reconstruction and 28 affected basis/domain controls. Counts were recomputed from the actual booleans, and all 240 fully namespaced row names are unique. Parsed stdout equals the complete result JSON; stderr is empty. The command's source hash and output's checker hash match the frozen staged runner.

The240 rows are a mixture of exact identities and finite synthetic/numerical controls. They are neither240 measurements nor240 independent scientific reviews. The original density function executes its root and grid controls afresh in that parent run, while the ESI function uses those fresh roots in memory. This correspondence unit does not rerun them.

The following exact original outputs were frozen and compared in full:

- PK/environment_bridge_packaging/STAGED_RESULTS_v1.json: select density_environment and rename its namespace to density;
- RR/environment_susceptibility_identity_v1/RESULTS_v1.json;
- RR/density_action_reconstruction_v1/RESULTS_v1.json;
- RR/density_action_reconstruction_v1/DOMAIN_RESULTS_v1.json.

All four original output checker hashes match their declared original source scripts. Every normalized row object is equal, including its residual/detail fields. Every substantive value is also equal after the single identity input-provenance substitution. No tolerance, rounding or subset comparison was used to claim equality.

The preserved substantive output inventory is 54 density-grid entries, 3 density roots, 3 general-identity spectra, 3 identity root diagnostics, 5 exact inverse power examples and 4 synthetic numerical-reconstruction rows, plus exact bounds and scope/provenance metadata. Complete array hashes and file hashes are recorded in ORIGINAL_OUTPUT_COMPARISON_v1.json. This comparison independently confirms the parent's output-correspondence summary. Its earlier wrong-key metadata failure is retained separately, rather than presented as a successful first attempt.

## Wrapper-only controls and actual staged damages

I extracted the actual canonical __main__ AST and executed that block with four synthetic sentinel functions replacing the science functions. SymPy, SciPy, NumPy and mpmath scientific bodies were not imported or run by this harness. Two cases supplied eight rows total: all true, and two false rows in separate units. Deliberately wrong embedded totals tested that the wrapper recounts row booleans. Distinct nested table and detail payloads tested complete retention.

The checks confirm call order, a single density computation, delivery of the identical density object, no input mutation, complete row/detail/table preservation, correct per-unit/global counts, stdout/output equality, the file-content hash and appropriate failure exit. Three actual full-source changed copies altered only the wrapper: dropping each unit's last row, dropping output tables, and forcing the final exit to success. The extracted changed wrappers were executed in both sentinel cases. Each damage was detected in an applicable case; forcing success is correctly nondiscriminating when all rows are already true. The wrapper harness returned 28/0 across eight in-process wrapper executions, not additional science tests.

The parent independently executed four actual changed copies of the entire staged scientific runner. I inspected their scripts, diffs, complete results, streams, protocols and execution records without rerunning them:

| Parent staged alteration | Passed / failed | Required failure |
|---|---:|---|
| volume term3 ->0 | 231 / 9 | identity::density_family_jacobian_(0, 0) |
| kinetic integration coefficient6 ->0 | 239 / 1 | reconstruction::Jordan_kinetic_coefficient |
| potential-source sign+1 ->-1 | 235 / 5 | reconstruction::power_density_inverse_1 |
| particle-volume mass coefficient3 ->0 | 226 / 14 | reconstruction::fixed_particle_mass_from_full_potential |

Each script is exactly one declared replacement of the frozen staged runner. Each actual child exited 1, retained 240 rows, failed the intended witness, and has stdout equal to its complete result. Protocol times precede execution, and source hashes agree across script, result, execution record and summary. No mathematical damage is inferred merely from an altered string or a summary count.

The combined existing-output, prior-seal and parent-damage verification returned 437/0. That number is mechanical evidence verification, not new physics or an empirical test.

## Preserved failures and repairs

The new unit retains two reviewer metadata failures:

1. check_correspondence_v1.py removed every assignment named source, including the mathematical source vector, producing101 passes and2 failures. This was an incorrect comparison normalization, not a source change. check_correspondence_v2.py restricts removal to the Path constructor assignment and exact JSON-loading expression; it returns103/0. The full failed result, stdout, script, exact repair diff and diagnosis remain unchanged. All regenerated bodies and AST representations were versioned.
2. The first inline recovery-map builder used u.parents[3], which resolved to .claude instead of the worktree. relative_to failed when it reached the root-level scripts path. No recovery-map or access-completion file had been written. The original inline source and tool traceback are archived, with a record that these are a post-failure transcription of the actual tool invocation, not a rerun. The corrected builder uses its explicitly recorded worktree cwd and completed successfully. No source or computation changed.

The parent's PARENT_OUTPUT_COMPARISON_FAILURE_v1.json preserves its KeyError from looking up density instead of density_environment in the older environment output. Its corrected comparison and this independent full comparison agree without a science rerun. The DAR independent report also preserves its separate pairs/source_pairs metadata-schema failure and correction. All intended mathematical and wrapper-damage failures remain present. These histories are not replaced by a clean combined count.

## Claim boundaries and recovery

The source correspondence preserves these substantive limits:

- The general susceptibility identity assumes a regular local prescribed-particle stationary family and a positive fixed-particle scalar mass. Its B interval is necessary, not a generic multifield stability converse.
- The single-field inverse requires ideal common-unit Gbare, q>0 and stationary physical-density functions on an interval. Those functions have not been measured here; Gcal alone is not Gbare.
- The reconstructed Jordan kinetic function and potential leave one constant Einstein potential shift. That constant changes gravitational stress/curvature and is not an equivalence of complete backgrounds.
- The logarithmic inverse B additionally needs rho_J>0 and rho_J'!=0. Undivided masses can remain meaningful at smooth zero or turning densities.
- The p=0 and p=3 mass coefficients impose different matter controls. Their agreement with a trace-eliminated coefficient is not an apparatus, reservoir, fluid/metric-stability or arbitrary-frame-spectrum theorem.
- Candidate x=y=0 is a consistent classical truncation, not a selected state. Transverse functions, off-interval extensions, initialization, equilibration, body matching and independent empirical validation remain open.

RECOVERY_MAP_v1.json supplies an original_dispositions row for all 63 reviewed live/snapshot pairs. Each row binds the original path/hash to a byte-exact owned recovery snapshot and its unchanged current location. Staged note/runner rows additionally name the planned docs/scripts targets and expressly mark their live identity unverified. Canonical body/function integration maps identify the exact transforms. REUSED_SEAL_RECOVERY_v1.json records complete constituent recovery inventories for the three immutable science units.

The runner's AUDIT_INPUT_PATHS names four planned canonical dependency paths. This staged run did not establish a live canonical cache or commit identity; the staged note target was not substituted into an authority/cache system. These names are dependency declarations, not an audit action. Copying the reviewed bytes, building the live cache, archiving and checking a committed delivery are separate future operations.

All new writes are confined to density_inverse_canonical_correspondence_v1. Parent sources, all prior seals, Git, branch, runtime/lock/settings, PRs and audit state were untouched. No new agent, network request or empirical data acquisition occurred. The final manifest and receipt bind the report, all 63 source pairs, both actual reviewer failures, the full wrapper and parent-damage records, exact commands, recovery map and reused seals. No authority or landing verdict is assigned.
