#!/usr/bin/env python3
"""Static body/AST/result correspondence; no scientific function executed."""
import ast,copy,datetime,difflib,hashlib,json,sys
from pathlib import Path
u=Path(__file__).resolve().parent
rows=[];details={}
def ck(n,b,d=None):rows.append({'name':n,'passed':bool(b),'detail':d})
def h(b):return hashlib.sha256(b).hexdigest()
def read(n):return (u/n).read_text()
def js(n):return json.loads(read(n))
def dump(n):return ast.dump(n,annotate_fields=True,include_attributes=False)
def fun(tree,name):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
lineage=js('records/CANONICAL_LINEAGE_v1.json'); note=read('staged/EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md');runner=read('staged/exponential_scalar_density_inverse_check.py');rt=ast.parse(runner)
ck('staged.note_hash',h(note.encode())==lineage['note_sha256'])
ck('staged.runner_hash',h(runner.encode())==lineage['runner_sha256'])
for i,n in enumerate(['ESI_DERIVATION_v1.md','DAR_DERIVATION_v2.md']):
 text=read('sources/'+n);body='\n'.join(('#'+l if l.startswith('#') else l) for l in text.splitlines()[1:]).strip()+'\n';label=['ESI','DAR'][i]
 ck('body.'+label+'.original_hash',h(text.encode())==lineage['note_bodies'][i]['sha256'])
 ck('body.'+label+'.transformed_hash',h(body.encode())==lineage['note_bodies'][i]['body_sha256'])
 ck('body.'+label+'.unique_exact_inclusion',note.count(body)==1)
 details[label+'_body']={'source':n,'sha256':h(text.encode()),'transformed_body_sha256':h(body.encode()),'canonical_start_line':note[:note.index(body)].count('\n')+1,'canonical_end_line':note[:note.index(body)+len(body)].count('\n'),'transformation':'remove first title line, add one # to every remaining Markdown heading, trim boundary blank lines and add one final newline'}
 (u/(label+'_TRANSFORMED_BODY_v1.md')).write_text(body)
# Exact preserved science ASTs; names only differ for DAR functions.
for original,oldname,newname in [('environment_bridge_check.py','check_density_environment','check_density_environment'),('DAR_check_reconstruction_v1.py','run','check_reconstruction'),('DAR_check_domains_v1.py','run','check_domains')]:
 st=ast.parse(read('sources/'+original));src=copy.deepcopy(fun(st,oldname));dst=fun(rt,newname);src.name=newname
 ck('AST.'+newname+'.exact_after_function_rename',dump(src)==dump(dst))
 details[newname]={'source_path':'sources/'+original,'source_function':oldname,'destination_function':newname,'normalized_source_ast_sha256':h(dump(src).encode()),'staged_ast_sha256':h(dump(dst).encode()),'staged_line':dst.lineno,'staged_end_line':dst.end_lineno}
 (u/(newname+'_NORMALIZED_AST_v1.txt')).write_text(dump(src)+'\n')
 # All named original top-level integer control definitions used by this body stay exact.
 names={x.id for x in ast.walk(src) if isinstance(x,ast.Name)}
 for statement in st.body:
  if isinstance(statement,ast.Assign) and len(statement.targets)==1 and isinstance(statement.targets[0],ast.Name) and statement.targets[0].id in names:
   target=statement.targets[0].id
   staged_assignment=next((x for x in rt.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id==target),None)
   if target in ['IBP_COEFFICIENT','POTENTIAL_SOURCE_SIGN','PARTICLE_VOLUME_POWER']:
    ck('AST.global_constant.'+target,dump(statement)==dump(staged_assignment))
# Identity: exactly documented signature, scratch-read removal and metadata replacement.
st=ast.parse(read('sources/ESI_check_identity_v1.py'));src=copy.deepcopy(fun(st,'run'));src.name='check_identity';src.args.args=[ast.arg(arg='saved')];removed=[];kept=[]
for statement in src.body:
 if isinstance(statement,ast.Assign) and len(statement.targets)==1 and isinstance(statement.targets[0],ast.Name) and statement.targets[0].id in ['source','saved']:
  removed.append(ast.unparse(statement))
 else:kept.append(statement)
src.body=kept
ret=src.body[-1];assert isinstance(ret,ast.Return) and isinstance(ret.value,ast.Call)
replaced=[]
for kw in ret.value.keywords:
 if kw.arg=='saved_root_input_sha256':
  replaced.append(ast.unparse(kw.value));kw.arg='root_input_kind';kw.value=ast.Constant('fresh in-memory density calculation')
dst=fun(rt,'check_identity')
ck('AST.identity.two_scratch_assignments_only',len(removed)==2,removed)
ck('AST.identity.one_metadata_replacement',len(replaced)==1,replaced)
ck('AST.identity.complete_normalized_equality',dump(src)==dump(dst))
ck('AST.identity.no_internal_file_reads',not any(isinstance(x,ast.Attribute) and x.attr in ['read_text','read_bytes','open'] for x in ast.walk(dst)))
for name in ['VOLUME_POWER','KINETIC_DIVISOR','FRAME_POWER']:
 original=next(x for x in st.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id==name)
 final=next(x for x in rt.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id==name)
 ck('AST.global_constant.'+name,dump(original)==dump(final))
details['check_identity']={'removed_assignments':removed,'return_metadata_replaced':replaced,'normalized_source_ast_sha256':h(dump(src).encode()),'staged_ast_sha256':h(dump(dst).encode()),'staged_line':dst.lineno,'staged_end_line':dst.end_lineno}
(u/'check_identity_NORMALIZED_AST_v1.txt').write_text(dump(src)+'\n')
# Full aggregate output, counts and table contents from the actual parent run.
r=js('records/STAGED_RESULTS_v1.json');stdout=js('records/STAGED_stdout_v1.txt');cmd=js('records/STAGED_COMMAND_v1.json');exe=js('records/STAGED_EXECUTION_v1.json')
ck('execution.stdout_full_result_identity',stdout==r)
ck('execution.source_hash_binding',r['checker_sha256']==lineage['runner_sha256']==cmd['source_sha256'])
ck('execution.argv_identity',cmd['argv']==exe['argv'])
ck('execution.actual_success',exe['exit_code']==0 and exe['finished']>exe['started'])
ck('execution.stderr_empty',read('records/STAGED_stderr_v1.txt')=='')
ck('output.total_complete_rows',len(r['checks'])==240)
ck('output.global_counts',r['passed']==sum(x['passed'] for x in r['checks'])==240 and r['failed']==sum(not x['passed'] for x in r['checks'])==0)
ck('output.unique_full_names',len({x['name'] for x in r['checks']})==240)
for name,count in [('density',96),('identity',53),('reconstruction',63),('domains',28)]:
 rr=[x for x in r['checks'] if x['name'].startswith(name+'::')]
 ck('output.'+name+'.row_count',len(rr)==count)
 ck('output.'+name+'.counts',r['units'][name]=={'passed':sum(x['passed'] for x in rr),'failed':sum(not x['passed'] for x in rr)})
 ck('output.'+name+'.nonempty_substantive',isinstance(r['substantive_outputs'][name],dict) and bool(r['substantive_outputs'][name]))
out=r['substantive_outputs']
ck('output.density.grid_complete',len(out['density']['grid'])==54)
ck('output.density.roots_complete',len(out['density']['roots'])==3 and [v['index'] for v in out['density']['roots']]==[0,1,2])
ck('output.identity.spectra_complete',len(out['identity']['synthetic_spectra'])==3)
ck('output.identity.root_results_complete',len(out['identity']['saved_root_results'])==3)
ck('output.identity.fresh_input_metadata',out['identity']['root_input_kind']=='fresh in-memory density calculation')
ck('output.reconstruction.exact_examples_complete',len(out['reconstruction']['exact_power_examples'])==5)
ck('output.reconstruction.quadrature_complete',len(out['reconstruction']['numerical_reconstruction'])==4)
# Ensure root output fields align in order; numeric identity is separately parent-compared.
ck('output.identity.root_index_alignment',[v['index'] for v in out['density']['roots']]==[v['index'] for v in out['identity']['saved_root_results']])
for n in ['checks','units','substantive_outputs']:
 details['complete_'+n+'_sha256']=h(json.dumps(r[n],sort_keys=True,separators=(',',':')).encode())
# Declared input paths are planned live destinations, not an executed cache claim.
inputs=next(x for x in rt.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='AUDIT_INPUT_PATHS')
paths=ast.literal_eval(inputs.value)
ck('declared_inputs.exact_four',len(paths)==4)
ck('declared_inputs.note_planned_path',paths[0]=='docs/EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md')
ck('scope.conditional_ideal_inputs','ideal-input inverse, not an action inferred from measured data' in note)
ck('scope.source_prescription','The probe\'s source constraint' in note and 'not different predictions for the same fully specified experiment' in note)
ck('scope.inverse_domain','rho_J\'(F)!=0' in note and 'positive-density portion' in note)
ck('scope.mass_basis','K-orthonormal' in note and 'endomorphism' in note)
ck('scope.offset_curvature','not an equivalence of complete background solutions' in note)
ck('scope.no_selected_state','selected physical state have been measured here' in note and 'not240 measured experiments' in note)
# Validate all initial source snapshot/live byte identities, without executing anything.
for b in js('SOURCE_BINDINGS_INITIAL_v1.json')['source_pairs']:
 snap=u/b['snapshot_path'];live=Path(b['original_path'])
 ck('binding.snapshot.'+b['snapshot_path'],h(snap.read_bytes())==b['sha256'] and snap.stat().st_size==b['bytes'])
 ck('binding.live.'+b['snapshot_path'],h(live.read_bytes())==b['sha256'])
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Static staged correspondence only, no science functions executed.','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'details':details,'script_sha256':h(Path(__file__).read_bytes()),'staged_note_sha256':h(note.encode()),'staged_runner_sha256':h(runner.encode())}
(u/'CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[x['name'] for x in rows if not x['passed']],'details':details},indent=2));sys.exit(bool(result['failed']))
