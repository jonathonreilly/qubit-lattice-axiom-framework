#!/usr/bin/env python3
"""Run only the actual canonical main wrapper with synthetic function stubs."""
import argparse,ast,contextlib,copy,datetime,difflib,hashlib,io,json,sys
from pathlib import Path
u=Path(__file__).resolve().parent; canonical=u/'staged/exponential_scalar_density_inverse_check.py';original=canonical.read_text(); checks=[]; executions=[]
def ck(n,b,d=None):checks.append({'name':n,'passed':bool(b),'detail':d})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mutations=[('drop_last_row','checks.extend(normalized)','checks.extend(normalized[:-1])'),('drop_tables',"outputs[name]={k:v for k,v in result.items() if k not in ['checks','passed','failed']}","outputs[name]={}"),('hide_failure',"raise SystemExit(bool(out['failed']))","raise SystemExit(False)")]
protocol=[]
for name,old,new in mutations:
 assert original.count(old)==1
 p=u/'wrapper_controls'/name;p.mkdir(parents=True,exist_ok=False)
 changed=original.replace(old,new,1);(p/'runner_damaged.py').write_text(changed)
 (p/'SOURCE.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile='staged_runner',tofile=name)))
 protocol.append({'name':name,'old':old,'new':new,'path':str((p/'runner_damaged.py').relative_to(u)),'sha256':sha(p/'runner_damaged.py')})
(u/'WRAPPER_CONTROL_PROTOCOL_v1.json').write_text(json.dumps({'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only AST-extracted canonical __main__ block executes. All four science functions are replaced by synthetic sentinels; no math function or library is imported/executed.','source_sha256':sha(canonical),'actual_wrapper_damages':protocol,'cases':['all rows true','two failed rows in separate units; deliberately false embedded totals']},indent=2)+'\n')
def run(path,case):
 tree=ast.parse(path.read_text());mains=[n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="__name__ == '__main__'"]
 assert len(mains)==1
 code=compile(ast.fix_missing_locations(ast.Module(body=mains[0].body,type_ignores=[])),str(path)+':main_only','exec')
 names=['density','identity','reconstruction','domains'];data={}
 for i,name in enumerate(names):
  count=[2,2,3,1][i]
  rows=[{'name':'row'+str(j),'passed':not(case=='failed_rows' and ((name=='identity' and j==count-1) or name=='domains')),'detail':{'unit':name,'row':j,'sentinel':['retain',None,17]}} for j in range(count)]
  data[name]={'checks':rows,'passed':-999,'failed':999,'table':[{'unit':name,'values':[i,3*i,None]}],'metadata':{'kind':'synthetic','case':case}}
 density=data['density'];input_copy=copy.deepcopy(data);calls=[];received=[]
 def density_fn():calls.append('density');return density
 def identity_fn(arg):calls.append('identity');received.append(arg is density);return data['identity']
 def reconstruction_fn():calls.append('reconstruction');return data['reconstruction']
 def domains_fn():calls.append('domains');return data['domains']
 casefolder=u/'wrapper_controls'/('baseline' if path==canonical else path.parent.name)/case;casefolder.mkdir(parents=True,exist_ok=False);outfile=casefolder/'OUTPUT.json'
 ns={'__name__':'__main__','__file__':str(path),'argparse':argparse,'json':json,'hashlib':hashlib,'Path':Path,'check_density_environment':density_fn,'check_identity':identity_fn,'check_reconstruction':reconstruction_fn,'check_domains':domains_fn}
 saved_argv=sys.argv;sys.argv=[str(path),'--output',str(outfile)];stream=io.StringIO();exit_value=None;error=None
 try:
  with contextlib.redirect_stdout(stream):
   try:exec(code,ns)
   except SystemExit as e:exit_value=e.code
 except Exception as e:error=repr(e)
 finally:sys.argv=saved_argv
 (casefolder/'STDOUT.txt').write_text(stream.getvalue())
 actual=json.loads(outfile.read_text()) if outfile.exists() else None
 expected_rows=[{**r,'name':n+'::'+r['name']} for n in names for r in input_copy[n]['checks']]
 expected_units={n:{'passed':sum(r['passed'] for r in input_copy[n]['checks']),'failed':sum(not r['passed'] for r in input_copy[n]['checks'])} for n in names}
 expected_outputs={n:{k:v for k,v in input_copy[n].items() if k not in ['checks','passed','failed']} for n in names}
 witnesses={'no_exception':error is None,'call_order_exact':calls==names,'same_density_object_delivered':received==[True],'inputs_not_mutated':data==input_copy,'all_rows_and_payloads_preserved':actual is not None and actual['checks']==expected_rows,'unit_counts_recomputed':actual is not None and actual['units']==expected_units,'global_counts_recomputed':actual is not None and actual['passed']==sum(r['passed'] for r in expected_rows) and actual['failed']==sum(not r['passed'] for r in expected_rows),'all_substantive_outputs_preserved':actual is not None and actual['substantive_outputs']==expected_outputs,'exit_matches_actual_failure':exit_value==bool(sum(not r['passed'] for r in expected_rows)),'self_hash_bound':actual is not None and actual['checker_sha256']==sha(path),'stdout_equals_output':actual is not None and json.loads(stream.getvalue())==actual}
 rec={'source':str(path.relative_to(u)),'source_sha256':sha(path),'case':case,'actual_exit':exit_value,'exception':error,'witnesses':witnesses,'science_functions_executed':False,'output_sha256':sha(outfile) if outfile.exists() else None}
 (casefolder/'EXECUTION.json').write_text(json.dumps(rec,indent=2)+'\n');executions.append(rec);return witnesses
for case in ['all_true','failed_rows']:
 witnesses=run(canonical,case)
 for name,ok in witnesses.items():ck('baseline.'+case+'.'+name,ok)
for d in protocol:
 for case in ['all_true','failed_rows']:
  witnesses=run(u/d['path'],case)
  intended={'drop_last_row':'all_rows_and_payloads_preserved','drop_tables':'all_substantive_outputs_preserved','hide_failure':'exit_matches_actual_failure'}[d['name']]
  applicable=d['name']!='hide_failure' or case=='failed_rows'
  if applicable:ck('damage.'+d['name']+'.'+case+'.detected',not witnesses[intended],{'failed_witness':intended})
  else:ck('damage.hide_failure.all_true.non_discriminating_case',all(witnesses.values()))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'checks':checks,'executions':executions,'scope':'Wrapper-only synthetic execution; zero producer science bodies run. Three altered wrappers executed, all detected in an applicable case.','script_sha256':sha(Path(__file__))}
(u/'WRAPPER_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'wrapper_executions':len(executions),'failed_names':[c['name'] for c in checks if not c['passed']]},indent=2));sys.exit(bool(result['failed']))
