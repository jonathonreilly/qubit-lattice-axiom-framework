#!/usr/bin/env python3
"""Final mechanical source/command/recovery verification, no science execution."""
import datetime,hashlib,json,sys
from pathlib import Path
u=Path(__file__).resolve().parent;w=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go');rows=[]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(n):return json.loads((u/n).read_text())
def ck(n,b,d=None):rows.append({'name':n,'passed':bool(b),'detail':d})
pairs=js('SOURCE_BINDINGS_FINAL_v1.json')['source_pairs'];mapping=js('RECOVERY_MAP_v1.json')['original_dispositions']
ck('inventory.source_pairs_63',len(pairs)==63)
ck('inventory.recovery_rows_63',len(mapping)==63)
for p,m in zip(pairs,mapping):
 live=Path(p['original_path']);snap=u/p['snapshot_path']
 ck('pair.live.'+p['snapshot_path'],h(live)==p['sha256'] and live.stat().st_size==p['bytes'])
 ck('pair.snapshot.'+p['snapshot_path'],h(snap)==p['sha256'] and snap.stat().st_size==p['bytes'])
 ck('recovery.original.'+p['snapshot_path'],w/m['original_path']==live and m['original_sha256']==p['sha256'])
 ck('recovery.snapshot.'+p['snapshot_path'],w/m['recovery']==snap and h(w/m['recovery'])==p['sha256'])
 ck('recovery.current_final.'+p['snapshot_path'],h(w/m['final_path'])==m['final_sha256']==p['sha256'])
 if 'planned_final_path' in m:
  ck('recovery.staged_only.'+p['snapshot_path'],m['status']=='staged_only' and m['planned_final_identity_verified'] is False and m['planned_final_sha256']==p['sha256'])
counts={'CORRESPONDENCE_RESULTS_v1.json':(101,2),'CORRESPONDENCE_RESULTS_v2.json':(103,0),'WRAPPER_RESULTS_v1.json':(28,0),'REUSE_OUTPUT_RESULTS_v1.json':(437,0)}
for n,(passed,failed) in counts.items():
 j=js(n);ck('results.actual_counts.'+n,j['passed']==passed and j['failed']==failed and sum(c['passed'] for c in j['checks'])==passed and sum(not c['passed'] for c in j['checks'])==failed)
for command,expected_exit in [('CORRESPONDENCE_COMMAND_v1.json',1),('CORRESPONDENCE_COMMAND_v2.json',0),('WRAPPER_COMMAND_v1.json',0),('REUSE_OUTPUT_COMMAND_v1.json',0),('RECOVERY_BUILD_COMMAND_v2.json',0)]:
 j=js(command);ck('commands.actual_exit.'+command,j['exit_code']==expected_exit)
 for k in ['script','stdout','stderr','result']:
  a=j[k];ck('commands.hash.'+command+'.'+k,a is not None and h(u/a['path'])==a['sha256'] and (u/a['path']).stat().st_size==a['bytes'])
lineage=js('records/CANONICAL_LINEAGE_v1.json');scriptfiles=['environment_bridge_check.py','ESI_check_identity_v1.py','DAR_check_reconstruction_v1.py','DAR_check_domains_v1.py'];outputfiles=['ENVIRONMENT_STAGED_RESULTS_v1.json','ESI_RESULTS_v1.json','DAR_RESULTS_v1.json','DAR_DOMAIN_RESULTS_v1.json']
for declaration,sn,on in zip(lineage['science_sources'],scriptfiles,outputfiles):
 ck('lineage.original_script.'+sn,h(u/'sources'/sn)==declaration['sha256'])
 ck('lineage.original_output.'+on,js('original_outputs/'+on)['checker_sha256']==declaration['sha256'])
ck('lineage.final_staged_note',h(u/'staged/EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md')==lineage['note_sha256'])
ck('lineage.final_staged_runner',h(u/'staged/exponential_scalar_density_inverse_check.py')==lineage['runner_sha256'])
ck('failures.AST_retained',len([r for r in js('CORRESPONDENCE_RESULTS_v1.json')['checks'] if not r['passed']])==2 and js('AST_FILTER_REPAIR_v2.json')['author_source_changed'] is False)
f=js('failures/RECOVERY_MAP_FAILURE_v1.json');ck('failures.recovery_retained',f['exit_code']==1 and f['partial_output_files_created'] is False and h(u/f['failed_source_path'])==f['failed_source_sha256'])
ck('failures.recovery_trace_retained','ValueError' in (u/'failures/RECOVERY_MAP_STDERR_v1.txt').read_text())
ck('failures.parent_comparison_retained','KeyError density' in js('records/PARENT_OUTPUT_COMPARISON_FAILURE_v1.json')['failure'])
ck('wrapper.zero_science_bodies',all(e['science_functions_executed'] is False for e in js('WRAPPER_RESULTS_v1.json')['executions']))
ck('wrapper.actual_executions',len(js('WRAPPER_RESULTS_v1.json')['executions'])==8)
ck('wrapper.three_actual_damages',len(js('WRAPPER_CONTROL_PROTOCOL_v1.json')['actual_wrapper_damages'])==3)
ck('parent.four_actual_damages',len(js('parent_damages/SUMMARY_v1.json'))==4 and all(v['exit_code']==1 for v in js('parent_damages/SUMMARY_v1.json')))
ck('reuse.full_prior_inventories',sum(x['artifact_count'] for x in js('REUSED_SEAL_RECOVERY_v1.json')['units'])==298)
ck('reuse.full_prior_source_pairs',sum(x['source_pair_count'] for x in js('REUSED_SEAL_RECOVERY_v1.json')['units'])==31)
report=(u/'REPORT_v1.md').read_text()
for phrase in ['No author-source correction is needed','No equation, coefficient, premise','No producer science body was executed here','101/2','103/0','437/0','240','source perturbation constraint','live declared-input cache','No authority or landing verdict']:
 ck('report.scope.'+phrase,phrase in report)
ck('report.note_hash',lineage['note_sha256'] in report)
ck('report.runner_hash',lineage['runner_sha256'] in report)
ck('access.complete',js('ACCESS_COMPLETION_v1.json')['remaining_dependencies']==[])
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final source, command and recovery metadata only; no science rerun.','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'script_sha256':h(Path(__file__)),'report_sha256':h(u/'REPORT_v1.md')}
assert not (u/'FINAL_VERIFICATION_v1.json').exists();(u/'FINAL_VERIFICATION_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[x['name'] for x in rows if not x['passed']]},indent=2));sys.exit(bool(result['failed']))
