# Focused independent check: stationary density action reconstruction

The conditional single-field inverse, its source-controlled mass factors, and its specialization to the supplied candidate agree with the independent action variation and controls. The original source had two missing qualifications: the logarithmic inverse needs positive density and a nonzero local density slope, and the several-field outer product must identify its field-metric basis. The original reviewer read the complete preserved v2 and its exact diff and confirms that both qualifications are now explicit. No additional sign or coefficient issue was found within this scope.

This is a focused mathematical check of a parent-authored conditional construction, not a formal audit, an empirical reconstruction, or an independently authored replacement theory. /root retains scientific authorship. No producer checker, producer output, new observations, fits, Git operations, runtime changes, or prior sealed evidence were used or changed.

## Source and execution boundary

The original source was frozen as sources/DERIVATION_v1.md, SHA256 e87e3c31070092b955cc9bf9378e765f09e15e49e100e6ca68f5e8be51b1f4ba. Its protocol was frozen before the independent implementation. The final author source is source_correspondence_v2/sources/DERIVATION_v2.md, SHA256 18b59326f5fa496653fb4df6f3faa70e7aabe8d914249ac402d1237abd82d732. V1 remains intact. SOURCE_BINDINGS_FINAL_v1.json records all nine live/snapshot pairs, including the original complete action, the two preceding mathematical sources, the primary PDF, and the correction record/diff.

The supplied action is sources/COMPLETE_ACTION.md, SHA256 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000. It was read directly. The earlier density and susceptibility sources serve as mathematical context; no previous control count is presented as a new execution here.

HAND_DERIVATION_v1.md and INDEPENDENT_PROTOCOL_v1.json precede the first independent science execution. HAND_IMPLEMENTATION_BINDINGS_v1.json binds that ordering and the initial implementation hash. The checker is check_inverse_v1.py, SHA256 7af1c700e74876a7c1b7a230eb101fcd4743c84095720ebbf6c805b3423e2241. The first and only unaltered science baseline ran from 13:54:42.722773 to 13:54:44.050058 UTC on 2026-10-14, exited 0, and returned 118 passed / 0 failed. Its unchanged output is BASELINE_RESULTS_v1.json, SHA256 d94a067cb3b893b9f266ef126812c300b269eab047bb5eb5a9a7b658f20cdb82. The baseline was not repeated for the prose clarification.

COMMANDS_v1.json retains exact shell commands and working directories. BASELINE_RUN_v1.json, the damage run records, PDF_READ_RENDER_v1.json, and the source-correspondence run records retain exact child argv, time, status, and relevant hashes. ENVIRONMENT_v1.json records interpreter/library versions. File construction used apply_patch and the explicitly recorded Python wrappers within this independent directory.

## Independent action derivation

Use signature (-+++), fixed Q>0, A>0, and a single dimensionless Einstein scalar with kinetic term -Q(partial chi)^2. The actual scalar kinetic coefficient is therefore 2Q. Defining lambda=ln A, F=Q/A^2 and q=lambda_chi^2, the conformal Ricci term is F R_J/2+3F box lambda-3F(partial lambda)^2. Integration by parts contributes +6F(partial lambda)^2. Combining this with the transformed Einstein kinetic term gives omega=(1/q-3)/2 in the Jordan action F R/2-omega(partial F)^2/(2F)-V_J.

The code computes a conformally flat metric's Christoffel symbols and Ricci tensor directly and tests the total-derivative contribution; it does not only substitute the advertised omega formula. A smooth positive q supplies a usable F coordinate on a connected branch, with dchi=+/-dlnF/(2sqrt(q)). At q=0 this chart fails. Kinetic positivity is 2omega+3=1/q>0, rather than a general requirement omega>0. The synthetic q=1/2 example distinguishes these statements; the supplied candidate's stronger q<1/3 does give positive omega.

A separate direct Euler variation of L=FR/2-w(F)X-V, w=omega/(2F), X=(partial F)^2, gives R/2+2w box F+w'X-V'=0. The metric trace is FR=-T+omega X/F+3box F+4V. Eliminating R yields

    (2omega+3) box F = T + 2F V' - 4V - omega' X.

The sign and normalization of the variable-omega term are tested independently. For constant F and dust T=-rho_J, this reduces to N(F)=2F V'-4V=rho_J. Linearization at a constant stationary background with fixed physical source gives qN'=q(2F V''-2V'); derivatives of q multiply the vanishing equilibrium residual, and omega'X is second order. This is a local coefficient under those conditions, not a claim about the full material/metric spectrum.

The primary Quiros PDF was independently extracted and visually inspected on complete PDF pages 2 and 3. The exact PDF SHA256 is c51fcbba36dbe98fa34fbca3248ad790f3dbabf361c9c4fec279a440a257582b. Its Eqs. (1)-(3) and (8) corroborate the constant-omega convention: the paper's entire action is twice the present action when phi=F and its V=V_J. The variable-omega term above is derived locally, not imported from that constant-omega reference. No environmental phenomenology or broad frame claim from the paper is adopted. The extracted pages, two rendered images, render command, and visual-reading receipt are retained.

## Potential inverse and surviving ambiguity

At fixed Einstein proper particle density rho_*=m_J n_E and fixed Einstein metric, stationarity of V_E+rho_* A gives V_E,A=-rho_*. On a family with rho_*=rho_J A^3, this is V_E,A=-rho_J A^3. Substituting V_E=A^4V_J and F=Q/A^2 yields N(F)=rho_J and

    (V_J/F^2)' = rho_J/(2F^3).

The integration freedom is exactly C F^2 on the sampled interval. The alternative variable G=1/(8pi F) gives (G^2 V_J)_G=-rho_J G/2. Both signs and factors are checked. The homogeneous addition becomes the constant Einstein shift C Q^2. It has no scalar force or Hessian but changes metric stress: for a constant scalar, FR=rho_J+4V_J and the curvature shift is 4CF. Thus the constant cannot be dismissed as an equivalence of complete gravitational solutions.

A curvature datum could fix the offset only if the stated constant-field and vanishing derivative-stress premises hold. The exact trace shows the omitted correction omega X/F+3box F for a varying field. A nonzero synthetic witness checks that substituting the constant-field formula in a rolling region can bias the inferred potential. One expansion-rate datum does not supply the missing curvature or derivative information.

For a smooth density on a compact positive-F interval, a sufficiently large C can make V_J positive there. This is an existence statement about a synthetic family; it determines neither a physical vacuum scale nor a global positive extension.

## Source-control mass and domain

Differentiating the stationary family, while keeping the probe Hessian at fixed rho_*, gives

    H0 = -(rho_*)_chi A_chi
       = A^4 q (2F rho_J' - 3rho_J).

Dividing by 2Q and converting the frozen physical mass by A^-2 gives

    m0,J^2 = q [rho_J' - 3rho_J/(2F)].
    mp,J^2 = q [rho_J' + (p-3)rho_J/(2F)].

Here delta ln rho_*=p delta ln A is an imposed source response. p=0 holds Einstein particle density fixed; p=3 holds physical density fixed in this source algebra at fixed Einstein metric. These are distinct controlled perturbation problems. Neither a reservoir/support mechanism nor a self-gravitating equilibrium or complete material spectrum has been derived. The agreement of m3,J^2=q rho_J' with the trace-eliminated coefficient is valid but does not turn it into a universal apparatus response.

For several fields the covariant mass-bilinear shift is p c_rho beta_A beta_B, where beta_A=partial_A ln A and c_rho=rho_E/(2Q). The corresponding mass endomorphism needs K^{AC}; only in a K-orthonormal frame is the usual symmetric outer product directly the matrix. The exact independent example K=[[2,1],[1,3]], beta=(2/7,-1/5) has beta^T K^-1 beta=538/6125. Its coordinate endomorphism is not ordinarily symmetric, but its orthonormal-frame representation is. Removing K^-1 produces six actual control failures.

For rho_J>0 and rho_J'!=0, B=-dlnG/dlnrho_J=rho_J/(F rho_J') is defined locally. Positive fixed-particle mass forces 0<B<2/3. Positive m3 alone does not. At a constant-density family and at the turning point of rho_J=3+(F-2)^2, the undivided mass formulas remain meaningful but the stated density inverse does not. The latter also supplies two distinct F values with equal density and unequal tensor coefficients.

These two original omissions were reported before independent code execution. The author preserved v1 and added only the two qualified paragraphs in v2. The original reviewer read all of v2 and the exact diff. The corrected metadata correspondence reports 33/0; its domain/basis mathematical evidence is the unchanged original baseline, explicitly reused rather than rerun. No equations or coefficients changed.

## Exact and numerical controls

The 118 independent controls include direct conformal geometry, variable-omega trace elimination, the field-coordinate integral, both potential variables, the offset, fixed-particle and general-p Hessians, inverse-domain counterexamples, nonorthonormal tensor geometry, and the original candidate specialization.

The nonconstant example is q(F)=F/(7+11F), omega=4+7/(2F). An explicit coordinate primitive is sqrt(11)asinh(sqrt(11F/7))-sqrt((7+11F)/F), checked by differentiating. Exact power-law inverse examples use n=1,2,3,5/4,7/2 and p=-2,0,1,3,5. The logarithmic n=2 case is included. At F=7/6, rho_ref=11/7 and F_ref=3/2, representative squared-mass coefficients are:

| n | B | m0,J^2 | m3,J^2 |
|---|---|---|---|
| 1 | 1 | -0.03081232493 | 0.06162464986 |
| 2 | 1/2 | 0.02396514161 | 0.09586056645 |
| 3 | 1/3 | 0.05591866376 | 0.11183732752 |
| 5/4 | 4/5 | -0.01446799520 | 0.07233997600 |
| 7/2 | 2/7 | 0.06575416798 | 0.11506979397 |

These dimensionless synthetic values are not measured masses. In particular n=1 and 5/4 expose the difference between the source controls.

A distinct mixed density rho=9sqrt(F)+6F^(5/2)+10F^2 has particular potential -3sqrt(F)+6F^(5/2)+5F^2 ln(F/Fref). Separate numerical integrals in F and in G reconstruct it with Fref=5/4 and C=17. At F=2/3,7/6,11/5 the reconstructed potentials are approximately 5.88648189653, 28.2499918927, and 134.584155900. The largest residual from these 80-digit computations is 2.70e-79. This numerical agreement is corroboration of the exact identities, not interval certification or an empirical precision claim.

The candidate test starts from the complete supplied K, U, A. It verifies the vanishing transverse connections/forces and matter derivatives on x=y=0, canonicalizes with dchi=sqrt(J)/D_E du, obtains q=a/J, and independently differentiates the transformed original potential to recover the physical density relation. The old Einstein denominator D_E=1+sE is kept distinct from the reconstructed Jordan F=Q D_E/[(1+s)E]. The density normalization is physical rho_J=-2Q Hv^2 U_z/z^3 with z=A, not the original action note's separately normalized fluid variable. This checks a consistent classical truncation, not selection of that sector or uniqueness of unprobed transverse action functions. Adding (x^2+y^2)^2 illustrates unconstrained transverse freedom while preserving the restricted value and relevant derivatives.

## Actual damages and preserved failures

Every damage is an actual separately executed one-edit copy of the independent checker, not an in-memory assertion or a producer result. DAMAGE_PROTOCOL_v1.json was frozen before these eight executions. All eight exited 1 and failed their designated identities:

| Alteration | Passed / failed |
|---|---|
| reversed conformal boundary term | 115 / 3 |
| reversed variable-omega trace sign | 116 / 2 |
| missing scalar kinetic factor 2 | 90 / 28 |
| wrong physical mass frame power | 89 / 29 |
| particle-volume power 4 instead of 3 | 88 / 30 |
| potential homogeneous power 1 instead of 2 | 115 / 3 |
| omitted field-metric inverse | 112 / 6 |
| reversed potential-source integral sign | 83 / 35 |

DAMAGE_SUMMARY_v1.json and damages/ preserve every script, exact diff, stdout, stderr, time, status, and hash. Damage passes are not added to the baseline count.

There was one real metadata-verifier failure at 14:00:07 UTC: KeyError 'pairs', because the initial source ledger uses the key source_pairs. It occurred after the corrected source copies and exact diff had been saved, before a correspondence result was emitted. The failed script, run, empty stdout, and traceback remain unchanged. A separate corrected verifier changed the schema key and verified/reused those existing copies instead of overwriting them. It exited 0 with 33/0 at 14:00:49 UTC. METADATA_REPAIR_v1.json and its exact diff preserve the diagnosis. No mathematics, source, tolerance, baseline output, or damaged run was altered. The earlier system-Poppler lookup simply found no binary; the bundled renderer succeeded. A long tool display was truncated; underlying complete evidence files were not truncated or replaced.

## Bounded conclusion

The final v2 correctly states a conditional inverse for ideal single-field functions Gbare, q and stationary physical density, with a surviving Einstein potential constant and explicitly different source controls. It does not reconstruct observed functions, determine a fundamental scale or initial state, select the candidate's invariant sector, fix unprobed transverse/off-interval behavior, or establish a laboratory body's full response. Measured Gcal is not automatically Gbare; actual geometry, matter response, equilibrium and independent validation inputs remain necessary.

Original source failures, the schema failure, and all damaged computations are retained. The final source correspondence confirms only the two affected qualifications and exact unchanged mathematics. All previous seals remain untouched. This unit is ready for the parent to integrate within that scope; it supplies no audit/status promotion or delivery/PR verdict.

