# Independent density-environment and susceptibility check

The stationary-density formulas, the fixed-physical-density uniqueness result, the fixed-particle multiple-minimum example and the susceptibility/mass identities are supported within the prescribed-source local scalar model. The final source is DERIVATION_v3.md, SHA-256 `0a56a10391b21c30d7d4cff8950ae3d4c2b0d2075050a3430f56b29a0ff381c2`, together with SUSCEPTIBILITY_ADDENDUM_v1.md, SHA-256 `34802c68eb9a15c10acce84c8afef629c261bffe7c8bf6a33be7b26b34d8f1db`.

The independent main checker completed **146/0**, and a separate susceptibility checker completed **49/0** using the six saved independent root values without solving them again. Six main and two addendum actual one-edit implementations all exited 1 and failed their intended witnesses. The narrow version-correspondence and density-convention check completed **23/0**, including an exact non-unit coordinate-volume witness; that count is not another execution of the main science. No producer checker was imported or executed, and no producer code/results informed the hand derivations or science controls.

Two source clarifications were integrated while preserving the originals. V2 identifies the middle radial maximum as a full-field saddle and writes the equivalent mass formula q U0,zz explicitly. V3 corrects the density definition to local Einstein proper three-volume, with Einstein metric held fixed in scalar variation. No stationary or mass equation changed. A packaging access incident after all science computations is disclosed below: one producer checker diff was accidentally copied and hashed as uninterpreted bytes, never displayed or used. This record therefore does not claim zero producer-byte access throughout the later packaging phase.

Scientific authorship remains with `/root`; this is a focused independent check, not a formal audit or a derivation of an experimental environment.

## Action normalization and the density being held fixed

The supplied complete action has kinetic coefficient -Q K_AB partial phi^A partial phi^B and potential -2Q Hv^2 U. Varying it and Sm[A^2 g_E,matter] gives

    D_box phi^A=Hv^2 U^A-b^A T_E/(2Q),  b=d ln A.

For prescribed nonrelativistic rest particles, T_E=-rho_E. Thus the static scalar equation has the positive source b^A rho_E/(2Q), while the corresponding homogeneous time equation has the opposite acceleration force. The factor 2 comes from the actual kinetic action and is not optional.

The particle action -m_J integral A ds_E gives Einstein rest energy m_J A. If n_E is particle number per local Einstein proper volume and is held fixed while varying the scalar at fixed Einstein metric, then rho_*=m_J n_E is scalar independent. The physical three-volume is A^3 times its Einstein counterpart, so rho_E=A rho_* and rho_J=rho_*/A^3. Consequently W=U+rho_* A/(2Q Hv^2), with a positive linear matter term. These rho symbols denote physical densities in the matching natural units; they are not the separately normalized fluid-density variable used elsewhere in the canonical action note.

The original phrase “coordinate volume” was ambiguous outside locally orthonormal coordinates. A concrete exact check uses h_E=diag(4,9,16), so sqrt(det h_E)=24. With coordinate number density 24, m_J=2 and A=1/2, the correct rho_*=2, rho_E=1 and rho_J=16. Treating the coordinate density as proper density instead gives a spurious factor 24. Final v3 states the proper-volume convention and the fixed-metric variation explicitly. This is a definition clarification, not a new physical density assumption or changed equation. Particle-number conservation in an evolving background would generally give rho_* proportional to a_E^-3; the prescribed stationary parameter is not being asserted constant throughout a cosmological history.

The published convention check is limited to [Khoury and Weltman, Chameleon Cosmology, p. 5, Eqs. 7–10](https://arxiv.org/pdf/astro-ph/0309411v2). The page uses a field-independent particle-density variable, a density times conformal-factor effective-potential term, and its Hessian for local fluctuations, under a weak Minkowski-background approximation. That convention agrees after accounting for this candidate's kinetic normalization. None of that paper's screening or observational claims is imported. The exact PDF was recovered with TLS verification enabled, hashed, its page 5 rendered and visually inspected, and its text extracted. The retained PDF SHA-256 is `4c36136350da8104942c34f459aa926aafbdc1ca4bcc12968dd96ebcc97cb406`.

## Reconstructing the stationary maps

The hand derivation in HAND_DERIVATION_v1.md preceded executable mathematics. It reconstructs the potential directly from the action's E=exp(2sqrt(a)u), F=1+sE and C=(1+s)E/F. Writing z=A and Delta=1+s-sz^2 gives

    E=z^2/Delta, F=(1+s)/Delta,
    u=-log(Delta/z^2)/(2sqrt(a)), z_u=sqrt(a)z/F.

Delta is named separately here to avoid collision with the transverse metric denominator in the complete action. On 0<z<1 it is positive, L=log(Delta/z^2)>0, and u<0 exactly. Substitution into the original potential yields the stated U0(z). Direct differentiation then gives d_*(z)=-U0,z with the two positive contributions in source Eq. 3. The executed symbolic check constructs U0 from the action before comparing its derivative with the proposed map; it does not call a producer function.

At fixed rho_*, stationarity is delta_*=d_*(z). If a positive physical density is specified instead, delta_*=z^3 delta_J and stationarity is delta_J=d_J(z)=d_*(z)/z^3. The products Delta L^2 z^-2 and Delta L z^-4 consist of positive decreasing factors on this interval. The vacuum term has derivative -12s/z^3<0. Therefore d_J'<0 without a numerical parameter scan. Its limits are infinity and zero at the left and right endpoints respectively, so every specified positive delta_J has exactly one negative-u stationary point for fixed action parameters.

That uniqueness belongs to an algebraic family at fixed physical density. It is not uniqueness at fixed particle data, nor a proof that a density profile has formed. The fixed-particle curvature is U0,zz, while an externally enforced fixed-rho_J residual has derivative U0,zz+3delta_J z^2. At a stationary point the latter is -z^3 d_J'>0, but the former can have either sign. Substituting fixed rho_J into a fluctuation problem for fixed rho_* changes the problem.

## Exact multiple-extremum proof and independent examples

For the source example k=1/10, nu=1/10000, delta_*=20, the exact values are s=110/7 and a=117/400. The positive exponential series proves exp(1)>8/3, and the rational inequality (8/3)^8>11590/7 proves L(1/10)<8. Independently substituting that upper bound gives

    d_*(1/10) < 229441903/23955750 <20,
    20-229441903/23955750=249673097/23955750>0.

At z=1/2 the vacuum term alone is 495/14>20. At z->0 the nu term grows as nu(1+s)L/(2a z), and at z=1 the density map vanishes. Hence W_z has signs negative, positive, negative, positive on the successive bracket boundaries. Interior extrema exist in all three intervals. Analyticity and nonconstancy exclude flat plateaux and ensure the sign-separated extrema can be chosen strict. This is an existence proof for at least two radial minima separated by a radial maximum, not a proof that exactly three roots exist.

The transverse potential is a sum of positive coefficients times x^2 and y^2. Thus the radial minima are full local minima of the prescribed-source potential, and the radial maximum is a saddle in the three-field space. This full-field distinction is now explicit in source v2/v3. A Hessian with a zero radial eigenvalue would require higher-order analysis; the source's strict-minimum existence argument does not assume all minima are nondegenerate.

The independent second example uses k=1/8, nu=1/20000, delta_*=18. Its exact values s=72/5, a=77/256 give L(1/10)<8 through 7628/5<(8/3)^8. The same construction yields

    d_*(1/10)<20062788562/2316015625<18,
    d_*(1/2)>162/5>18.

Both examples therefore have the same sign-separated existence structure independently of numerical root-finding. Their parameters and densities are synthetic, not calibration inputs.

The numerical checker used 80-digit arithmetic and 250 bisection steps in each of (10^-10,1/10), (1/10,1/2), and (1/2,1), evaluating the derivative of the transformed original potential. It separately reconstructed the u-coordinate action and differentiated it to check the stationary equation, potential and normalized Hessian. The table shows one located root in each interval, rounded for readability:

| Example | z=A | W | m_J^2/Hv^2 | S_env |
| --- | ---: | ---: | ---: | ---: |
| Source, first minimum | 0.00217625615 | 25.2770880 | 2985.57144 | 4.11066184 |
| Source, saddle | 0.22212810537 | 27.2669889 | -23.22606 | 2.11283700 |
| Source, second minimum | 0.86954244035 | 20.2932062 | 26.89315 | 8.20132760 |
| Distinct, first minimum | 0.00116202692 | 23.2053532 | 5177.26446 | 4.11120280 |
| Distinct, saddle | 0.21826460022 | 25.0293617 | -22.11018 | 2.10458331 |
| Distinct, second minimum | 0.87249224339 | 18.4362519 | 26.88291 | 8.37722853 |

The source-example physical dimensionless densities are approximately 1.94044e9, 1824.81759 and 30.41989, respectively. Their inequality is precisely why this example does not contradict uniqueness at fixed physical density. Comparing W values proves neither global minimization over all fields nor dynamical population of the lowest listed minimum. The numerical residuals are about 10^-73 or smaller; this is not a rigorous interval enclosure, a root-exhaustiveness proof or experimental precision. The analytic sign argument supplies existence.

## Hessian, frame conversion and stability scope

At x=y=0 the mixed coordinate Hessian entries vanish. The positive transverse entries are k exp(-lambda_x u) and (2k/3)exp(-lambda_y u). At a full stationary point the covariant Hessian of W equals its coordinate Hessian because grad W=0. One cannot discard connection terms separately for U and A: their terms cancel using U_u+delta_* A_u=0. The independent code checks this distinction explicitly.

For dchi=sqrt(K_uu)du, the kinetic term is -Q(partial chi)^2 and the Einstein squared mass is Hv^2 W_uu/K_uu. At equilibrium W_uu=z_u^2 U0,zz and z_u^2/K_uu=a z^2/J. At a frozen constant conformal background r_J=z r_E, so Laplacian_E=z^2 Laplacian_J and

    m_E^2/Hv^2=(a z^2/J)U0,zz,
    m_J^2/Hv^2=(a/J)U0,zz=q U0,zz.

The physical mass is divided by z, not multiplied by z. These are local scalar fluctuation masses under the specified particle-density prescription. Positive squared mass is not a full gravitating-fluid stability theorem. Hv remains an uncalibrated supplied scale, so the table supplies no experimental range in metres or seconds.

## Susceptibility extension

SUSCEPTIBILITY_HAND_v1.md was written before the separate addendum implementation. The exact derivative of z^2 d_J is strictly negative because its positive product factors decrease and the first term has derivative -12s z. Therefore

    S_env=-z d_J'/d_J>2,
    d ln A_stationary/d ln rho_J=-1/S_env in (-1/2,0).

The Hessian identity is U0,zz=z^2 d_J(S_env-3). Consequently m_J^2/Hv^2=q z^2 delta_J(S_env-3). Positive radial squared mass is equivalent to S_env>3; S_env=3 is zero quadratic mass, and 2<S_env<3 is negative squared mass in this prescribed-source perturbation problem. The two saddle rows provide explicit examples of the last case despite the unique physical-density map.

For fixed nu>0 near z=0, d_J is asymptotic to nu(1+s)L/(2a z^4). The exact derivative expression, together with z L'->-2 and vanishing positive powers of z times log powers, gives S_env->4 and inverse logarithmic slope ->-1/4. This is not inferred by blindly differentiating an uncontrolled asymptotic equivalent. The limit is nonuniform as nu->0: at nu=0 exactly, S_env=2/(1-z^2)->2.

Near z=1, independent expansion gives

    d_J=[12s+nu(1+s)/a](1-z)+O((1-z)^2).

The coefficient is positive. Hence (1-z)S_env->1, S_env diverges positively, and the inverse slope tends to zero from below. The 49/0 addendum checks exact identities and endpoint limits, then evaluates S_env using the six previously saved root strings with a tolerance appropriate to their 55-digit serialization. Finite endpoint samples are exposed supporting controls, not a uniform finite-z accuracy certificate or a real-time tracking law. No main root solve was repeated for this addendum.

## Actual altered implementations and failures

Every listed damage is an actual saved one-edit script, executed with its own command record, stdout, stderr, result JSON, source hash and exact diff. Each returned exit 1 and its named mathematical witness failed:

| Actual alteration | Pass/fail |
| --- | ---: |
| Replace source divisor 2Q by Q | 137/9 |
| Replace particle energy A by A^4 | 137/9 |
| Replace the density volume power 3 by 4 | 133/13 |
| Reverse the stationary-map sign | 133/13 |
| Substitute fixed-rho_J curvature for fixed-particle curvature | 126/20 |
| Multiply instead of divide by A^2 in mass conversion | 132/14 |
| Replace susceptibility mass threshold 3 by 2 | 41/8 |
| Reverse inverse-susceptibility sign | 41/8 |

No unexpected mathematical, numerical, subprocess, PDF retrieval or rendering failure occurred in this independent unit. The source-definition finding, v1-to-v2 and v2-to-v3 correspondence, exact non-unit-volume witness, all actual damaged failures and the packaging access incident are retained in the failure ledger. The parent separately reported its own SSL, symbolic-normalization and finite-asymptotic-tolerance development failures; those were not inspected, imported into this computation, relabeled as independent results, or used as evidence here.

After the 146/0 and 49/0 checks and all eight damage executions had finished, an overbroad `*v3*` source-freeze glob also copied SUSCEPTIBILITY_CHECKER_v2_v3.diff. Its 1937 bytes were hashed and snapshotted without being displayed or interpreted. It was not an input to any derivation or execution. ACCESS_INCIDENT_v1.json preserves the filename, hash, freeze time and all prior completion timestamps; the independent correspondence check verifies their order. The file remains as explicitly labeled contextual recovery evidence. Subsequent source reads use explicit names. This is a transparent access-history limitation, not a claim that the producer mathematics was independently reviewed.

## Final source binding and claim limits

Original DERIVATION_v1 SHA-256 is `24d84aaeafe7aaccbea7b53a0fb8ed1697c9cd6ac495d4c781b05e6f352f8268`; v2 is `94330db06a6b99fe337d9490fae09ed69b9458612cfa51198821c7e88c43c7ce`. Exact text comparisons confirm the two stated v2 clarifications and only the proper-volume paragraph change in final v3. The full supplied action SHA-256 remains `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`. Twelve live/snapshot pairs are retained: eleven intended source/protocol/clarification inputs and the one disclosed metadata-only producer diff. The separately downloaded primary PDF is bound as a remote-source artifact, not counted as a live source pair.

The supported result is a conditional stationary relation, a distinction between two density prescriptions, an explicit nonuniqueness example at fixed particle data, and a local scalar mass/susceptibility diagnostic. It does not provide a pressure-supported finite body, initial preparation, damping mechanism, adiabatic tracking theorem, selected branch, globally stable matter/gravity state, laboratory calibration, screening prediction, measured likelihood or derived action/scale. The final source keeps these limitations explicit.

All work is confined to this new independent_v1 directory. Parent sources and previous seals are unchanged. No Git, PR, runtime, lock, settings, audit or authority state was modified. MANIFEST_v1.json binds every artifact except itself and RECEIPT_v1.json; the receipt binds the report, manifest, exact commands, source versions, actual failures and bounded conclusion. No further writes follow final seal verification.
