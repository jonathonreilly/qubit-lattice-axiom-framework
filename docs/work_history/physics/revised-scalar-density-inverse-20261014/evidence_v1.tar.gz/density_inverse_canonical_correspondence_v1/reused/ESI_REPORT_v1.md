# Focused independent check: stationary susceptibility without separate vacuum scales

Checker: /root/scalar_energy_check. Direct scientific author: /root.

The identities in the frozen DERIVATION_v1.md agree with an independent variation of the supplied action and prescribed-particle source. I found no equation error or required source clarification. The result is a local consistency identity under a positive fixed-particle scalar mass hypothesis. It does not identify the candidate potential, establish a prepared environment, reconstruct an apparatus or determine the fundamental scales. This is not a formal audit or a landing authorization.

The new independent baseline completed 114/0. All six actual changed-formula copies exited 1 with their named mathematical witnesses failing. The hand reconstruction was written and hash-frozen before creation or execution of the checker. The tests include an independently constructed nonlinear two-field source with rational data, a non-diagonal positive mass matrix, a distinct unstable-direction counterexample, spectral/frame/SI checks, a calibration-envelope counterexample and new algebraic comparisons using six own previously sealed roots. No producer implementation, producer result or producer saved root was read or imported.

## 1. Sources and exact checked scope

The main source is rolling_local_response/environment_susceptibility_identity_v1/DERIVATION_v1.md, SHA256 fc8d310cef1ae01b8a709067fdb43ee45ecc58ddd217c2b577cdd86a0c10fcba. Its protocol is SHA256 78a4fece666fea892cee7197959b1674c6e0192dd40bd3a81dde84a8b0a426bf. Both were read in full and copied byte-for-byte before the independent hand derivation and code.

The complete supplied action is the future-confinement canonical note, SHA256 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000. Its no-one-half kinetic normalization, Q>0, conformal A=sqrt(C), candidate field metric and potential are the inputs; this review does not re-review its future-history theorem. Candidate specialization uses the final density DERIVATION_v3.md SHA256 0a56a10391b21c30d7d4cff8950ae3d4c2b0d2075050a3430f56b29a0ff381c2 and SUSCEPTIBILITY_ADDENDUM_v1.md SHA256 34802c68eb9a15c10acce84c8afef629c261bffe7c8bf6a33be7b26b34d8f1db, both read in full. The addendum's original reference to density v2 is read with the preserved final v3 proper-volume clarification; no equation was changed in that earlier clarification.

The exact prior independent seal reused is:

- report: 787afa9af5ec790350b51ef96df1e1e0c935690e92266a5242186b4e8f194dd9;
- manifest: 4277dfc4a1b0bacb8551c8212ba6323343cf51531a15195b437409289a0cc4fd;
- receipt: e82004e2c5f13849b603a79cf677e63acca3c403a1e2639fb7b0eac72429ec86;
- own baseline result: 41948637c37ab00483b15dc7da5329b78aacb04ec61ef50e1bf36c2c73206991;
- own susceptibility result: 01bdb98577358aa94138ed907dd7e3dbd31635db7f26f71a358e974e7619beec.

Only those selected prior artifacts and source identities are reused. The previous 146/0 and 49/0 runs remain earlier evidence, not fresh runs or added assertions in the current 114/0. No root solve, cosmological trajectory, body solution or empirical comparison was repeated. All ten live/source snapshot bindings are given in SOURCE_BINDINGS_v1.json.

## 2. Action, density convention and local existence

At a K-orthonormal normal field frame the relevant local Lagrangian is

    -Q (partial chi)^2 - 2Q Y - rho_* A,
    Y=Hv^2 U, rho_*=m_J n_E.

Here n_E is number per local Einstein proper three-volume; the Einstein metric and the Jordan particle rest mass are held fixed in the scalar variation. The scalar equation is box chi_i=Y_i+rho_* A_i/(2Q). The 2Q denominator is essential because the action has -Q K(partial phi)^2 rather than -Q K(partial phi)^2/2. Hence the fixed-particle mass is the covariant Hessian of Y+rho_* A/(2Q).

For a family indexed by rho_J>0, rho_*=rho_J A^3 and rho_E=rho_J A^4. Differentiating the full stationary residual, with c=rho_E/(2Q) and beta=d ln A, gives

    H dchi=-c beta d ln rho_J,
    H=M_E^2+3c beta beta^T.

The extra term arises only when the source constraint changes from fixed particle data to fixed physical density. The exact independent source differentiation and the separate Hessians of Y+rho_* A/(2Q) and Y+rho_J A^4/(8Q) confirm this distinction. Neither Hessian can silently replace the other.

When M_E^2 is positive definite, H is positive definite. The implicit function theorem therefore gives a unique smooth branch near the already specified stationary point. This is local uniqueness within a neighborhood, not a global branch existence or global uniqueness statement. It does not ensure that a density scan tracks that branch in time or that a real gravitating body sustains it. Finite positive smooth A, positive Q and density, positive kinetic metric, finite smooth local derivatives and the fixed action parameters are part of the application domain. At a stationary point connection terms cancel only in the total residual; the two separate covariant Hessians generally have nonzero connection terms in a non-normal coordinate system.

The independent test changes to a nonorthogonal field basis and checks both the invariant inverse contraction and the generalized mass spectrum of K^{-1}M. A nonlinear coordinate change also verifies that the connection contributions cancel in the total stationary Hessian while the potential Hessian alone changes. Ordinary eigenvalues of a covariant Hessian in arbitrary coordinates are not invariant masses.

## 3. Rank-one identity and its strict domain

Let zeta=c beta^T(M_E^2)^{-1}beta. Multiplication of H by (M_E^2)^{-1}beta/(1+3zeta) establishes the rank-one inverse directly. Thus

    d ln A/d ln rho_J=-zeta/(1+3zeta),
    B=-d ln G_bare/d ln rho_J=2zeta/(1+3zeta),
    zeta=B/(2-3B), G_bare=A^2/(8 pi Q).

The same Q must be held fixed. The checker includes an explicit varying-Q witness with an extra logarithmic derivative, rather than treating that premise as optional.

For the stated positive mass matrix, zeta>=0 and vanishes iff beta=0. The exact gap 2/3-B=2/[3(1+3zeta)] proves 0<=B<2/3 at finite regular points. For a coupled direction the A slope lies in (-1/3,0). The endpoint B=2/3 is excluded; a zero mass can produce that boundary outside the theorem, and a singular rank-one denominator destroys the physical-density implicit derivative. Positive density is needed for the zero-slope iff zero-coupling claim.

My distinct action-jet example used Q=7/3, A0=3/2, rho_J0=5/7, beta=(2/5,-1/3), a nonzero log-A Hessian and fixed-particle M=[[5,1],[1,2]]. The full nonlinear functions are retained in HAND_DERIVATION_v1.md and check_identity_v1.py. Direct differentiation gives

    c=1215/1568,
    H=[[10529/1960,541/784],[541/784,3541/1568]],
    zeta=771/7840,
    dchi/d ln rho_J=(-765,1395)/10153,
    d ln A/d ln rho_J=-771/10153,
    B=1542/10153.

These rational values come from the actual independently constructed source residual, not an imported producer expression. A separate symbolic two-by-two multiplication and determinant-ratio identity support the hand proof's general matrix step; the positive-definite argument is the written quadratic-form argument, not a finite matrix sample.

## 4. Physical mass, spectrum and SI normalization

At constant background A, ds_J=A ds_E and box_E=A^2 box_J. Therefore squared masses satisfy M_J^2=M_E^2/A^2. This is a frozen local conversion. Spatially or temporally varying backgrounds, coupled metric/fluid modes and boundaries may add other response terms; none is solved here.

In an orthonormal mass eigenbasis q_i=(e_i dot beta)^2>=0 and sum q_i=q. Combining rho_E=A^4 rho_J, the mass conversion and G_bare gives

    zeta=4 pi G_bare rho_J sum_i q_i/m_i,J^2.

For q>0 the weighted harmonic squared mass is q/sum(q_i/m_i,J^2). It lies between the smallest and largest coupled squared masses and obeys

    m_eff^2/(4 pi G_bare rho_J)=q(2/B-3).

An independently rotated spectrum with physical squared masses 2 and 11 gave weights 4/5625 and 169/625, q=61/225 and m_eff^2=16775/1543, strictly between 2 and 11. One coupled mode and a degenerate eigenspace were also checked. These are weighted-response statements: the scalar contraction cannot reconstruct the entire spectrum or establish stability in all other directions.

In SI, 4 pi G_SI rho_m has units s^-2 and mu_i has units m^-1. Hence the dimensionless contraction requires 4 pi G_SI rho_m/c_light^2. The single-mode expression c_light^2 mu_J^2/(4 pi G_SI rho_m)=q(2/B-3) is correct. With energy density, rho_m=rho_energy/c_light^2, so the corresponding numerator factor becomes c_light^4. Omitting c_light^2 fails both exact algebra and the independent dimension-vector witness. No measured value of c, G, density or inverse range was used.

This removes Q and Hv as separately displayed symbols from one conditional relation; it does not infer their values. G_bare is a local tensor normalization that would itself need reconstruction under stated assumptions. A prospective apparatus must also identify the perturbation constraint: the fixed-particle mass in this theorem is not automatically the range obtained while holding physical density or another source control fixed. The existing H-M=3c beta beta^T difference makes that limitation explicit. The source already separates the two Hessians and disclaims an apparatus solution, so no wording correction was required. The parent's later separate probe-prescription and Jordan-reconstruction work was not accessed or reviewed.

## 5. Necessary condition, false converse and action nonselection

The source's positive-mass converse warning is correct. My distinct counterexample is

    M=diag(2,-3), beta=(1/3,1/5), c=2,
    zeta=19/225, B=19/141,
    det(M+3c beta beta^T)=-188/25.

The physical-density Jacobian is regular, B is between 0 and 2/3, and an unstable field is present. I also constructed an explicit smooth local potential and positive exponential coupling realizing this stationary source/mass jet, and checked a completely uncoupled negative mode. The source's separate numerical example zeta=3/80 is arithmetically correct. These examples violate the positive-mass premise and defeat its converse; they do not refute the theorem.

The identities apply to general smooth Y and A. Adding 7 chi2^3/19 to my synthetic potential preserves the event value, gradient, Hessian, stationarity, mass and susceptibility, while changing the third derivative. This concrete local-jet witness reinforces the source's nonselection claim. It does not assert equivalence of the models over a finite history or all densities. Agreement with the stationary relation cannot by itself select the candidate potential, a quantum or classical state, an equilibration mechanism, a boundary solution or a fundamental scale.

## 6. Candidate radial specialization without a new root solve

For the supplied candidate, beta_u=alpha/F and K_uu=J/F^2 give q=a/J. At x=y=0 the total stationary mass matrix is diagonal and the two transverse coordinate curvatures are positive. Only the radial mode couples. Using the already checked delta_J=d_J(A), S=-A d_J'/d_J and m_u,J^2/Hv^2=q A^2 delta_J(S-3), one obtains B=2/S and

    m_u,J^2/(4 pi G_bare rho_J)=q(S-3).

Positive radial mass is therefore equivalent to S>3 in this candidate's stated negative-u domain; the earlier S>2 bound alone was not a stability test.

The six previously saved independent roots were used only as exposed synthetic development data. The new B values are:

| Reused case | First minimum | Middle radial maximum | Last minimum |
|---|---:|---:|---:|
| k=1/10, nu=1/10000, delta_*=20 | 0.486539656829091 | 0.946594555104422 | 0.243862957050663 |
| distinct k=1/8, nu=1/20000, delta_*=18 | 0.486475636266649 | 0.950306878935676 | 0.238742442310370 |

The four minima lie inside the positive-mass interval; both middle radial maxima lie above 2/3 and outside the theorem. Their formal one-dimensional algebra still agrees with negative zeta. The comparisons used mpmath at 80 digits and relative tolerance 1e-42 on saved rounded decimals; no new roots or interval enclosures were produced. These checks do not claim those are all stationary roots, or that the multiple fixed-particle roots correspond to the same physical density.

## 7. Calibration derivative and measurement scope

For positive G_cal=gamma G_bare, the source's sign is correct:

    B=-d ln G_cal/d ln rho_J+d ln gamma/d ln rho_J.

The distinct mathematical envelope q=3/7 gives gamma=1+(3/14)[1+sin(omega t)], t=ln(rho_J/rho_ref). It stays in [1,10/7], while its reference logarithmic slope is 3omega/17. Thus the amplitude ceiling alone permits arbitrarily large slopes; at omega=1000 it is 3000/17. A separate explicit G_bare(t) verified the derivative sign. The envelope is not a constructed finite-body solution or a prediction for an actual laboratory. The imported positive-force-kernel amplitude bound is contextual here; this check does not redo its finite-body proof or validate an apparatus.

A real use requires common density/units conventions, adequate source and geometry information, a reconstructed tensor normalization, appropriate coupling weights/ranges, identification of the controlled particle response, and bounds on weak-field/background approximations. A density scan used to estimate B is development/calibration data; a prospective independent test requires a reserved configuration. No survey, laboratory result, current observational limit, likelihood or empirical acceptance is claimed.

## 8. Execution, failures and evidence boundaries

The independent baseline used Python 3.12.8, SymPy 1.14.0 and mpmath 1.3.0. It completed 114/0 in approximately 0.5 seconds including the recorded process. Every actual execution has an argv/cwd/timing record plus stdout, stderr, checker hash and result hash. The baseline source remains unchanged after its run.

Actual damages and their results are preserved separately:

| Altered implementation | Passed / failed | Child exit |
|---|---:|---:|
| volume factor removed | 109 / 5 | 1 |
| kinetic-source factor doubled | 106 / 8 | 1 |
| conformal mass direction reversed | 112 / 2 | 1 |
| susceptibility sign reversed | 111 / 3 | 1 |
| calibration derivative sign reversed | 113 / 1 | 1 |
| SI c_light^2 omitted | 110 / 4 | 1 |

No initial baseline failure, repaired mathematical assertion, source correction or timeout occurred. All intended failures, exact changed files and streams remain under damages/. Finite controls support the explicit written proof and are not a replacement for its arbitrary-field positive-definite argument or an empirical result. Metadata verification is counted separately from these mathematical controls.

ACCESS_HISTORY_v1.json and FAILURE_AND_SCOPE_LOG_v1.md preserve access and limitation details. The prior density seal's historical metadata-only accidental producer-diff copy remains disclosed in its copied report/receipt/manifest; the diff itself was not accessed or copied by this unit and is not a mathematical input. This unit used only explicit allowed paths, with no producer code/results access. No Git, network, runtime, lock, settings, PR, audit or source mutation occurred, and no agent was delegated. All new writes are in this independent_v1. The manifest binds every local artifact except itself and the final receipt; the receipt binds the manifest, report, source pairs, exact selected reused seals and complete actual execution lineage.
