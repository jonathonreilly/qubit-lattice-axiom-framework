#!/usr/local/bin/python3
"""Affected-only basis/domain controls after the v2 source clarification."""
from pathlib import Path
import json,hashlib,argparse
import sympy as s

def run():
    rows=[]
    def eq(name,e):
        r=s.factor(s.cancel(e));rows.append(dict(name=name,passed=r==0,residual=str(r)))
    def ck(name,b,detail=None):rows.append(dict(name=name,passed=bool(b),detail=detail))
    # chi = T psi; covariant Hessians and mixed mass operators transform
    # differently. Verify both conventions without identifying them.
    T=s.Matrix([[2,s.Rational(1,3)],[0,s.Rational(3,2)]])
    K=T.T*T;beta=s.Matrix([s.Rational(2,7),s.Rational(-1,5)])
    M=s.Matrix([[3,s.Rational(1,4)],[s.Rational(1,4),2]])
    c=s.Rational(3,11);p=s.Rational(5,2)
    cov_beta=T.T*beta;cov_H=T.T*M*T
    shifted_cov=T.T*(M+p*c*beta*beta.T)*T
    covariance=shifted_cov-cov_H-p*c*cov_beta*cov_beta.T
    mixed=K.inv()*shifted_cov-K.inv()*cov_H-p*c*K.inv()*cov_beta*cov_beta.T
    transformed=K.inv()*shifted_cov-T.inv()*(M+p*c*beta*beta.T)*T
    for i in range(2):
        for j in range(2):
            eq('covariant_rank_one_'+str((i,j)),covariance[i,j])
            eq('mixed_rank_one_'+str((i,j)),mixed[i,j])
            eq('mass_endomorphism_similarity_'+str((i,j)),transformed[i,j])
    wrong=K.inv()*shifted_cov-K.inv()*cov_H-p*c*cov_beta*cov_beta.T
    ck('omitting_inverse_metric_is_wrong',any(v!=0 for v in wrong))
    ck('positive_kinetic_basis',K[0,0]>0 and K.det()>0)

    F,q=s.symbols('F q',positive=True)
    rho=1+(F-1)**2
    mass0=q*(s.diff(rho,F)-3*rho/(2*F));mass3=q*s.diff(rho,F)
    eq('turning_density_derivative',s.diff(rho,F).subs(F,1))
    eq('turning_density_regular_mass0',mass0.subs(F,1)+3*q/2)
    eq('turning_density_regular_mass3',mass3.subs(F,1))
    ck('turning_density_is_positive',rho.subs(F,1)>0)
    eps=s.symbols('epsilon',positive=True)
    eq('turning_density_inverse_not_unique',rho.subs(F,1+eps)-rho.subs(F,1-eps))
    rho_zero=F-1
    eq('zero_density_point',rho_zero.subs(F,1))
    eq('zero_density_undivided_mass_regular',(q*(s.diff(rho_zero,F)-3*rho_zero/(2*F))).subs(F,1)-q)
    ck('zero_density_logarithm_not_defined',s.log(rho_zero.subs(F,1))==s.zoo)

    # Consistency of the candidate x=y=0 sector follows from the actual
    # coupling and metric dependence, not from an initial-state selector.
    u,x,y,k,nu,aa,ss=s.symbols('u x y k nu a s',positive=True)
    alpha=s.sqrt(aa);E=s.exp(2*alpha*u);FF=1+ss*E;JJ=1+(1-3*aa)*ss*E
    Kuu=JJ/FF**2;CC=(1+ss)*E/FF
    U=s.Rational(3,2)+3*ss*(E-1)**2/(2*FF**2)+k*x*x*s.exp(-(1-k)*u/alpha)/2+k*y*y*s.exp(-(1+k)*u/alpha)/3+nu*(1+ss)*u*u/(2*FF**2)
    for transverse in [x,y]:
        eq('transverse_metric_geodesic_'+str(transverse),s.diff(Kuu,transverse))
        eq('transverse_matter_source_'+str(transverse),s.diff(s.log(CC)/2,transverse))
        eq('transverse_potential_gradient_'+str(transverse),s.diff(U,transverse).subs({x:0,y:0}))
    return dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,scope='Affected source-domain/basis controls only; no rerun of original63 controls.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args()
    result=run();result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out=Path(a.output);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'failed':result['failed']}))
    for row in result['checks']:
        if not row['passed']:print(json.dumps(row))
    raise SystemExit(bool(result['failed']))
