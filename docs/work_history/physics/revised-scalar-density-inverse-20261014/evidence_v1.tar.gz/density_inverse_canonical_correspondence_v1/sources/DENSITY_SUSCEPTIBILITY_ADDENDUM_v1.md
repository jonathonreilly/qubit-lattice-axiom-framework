# Density susceptibility diagnoses the conditional local mass

Direct derivation /root, before the addendum checker. Retain all premises and
fixed-particle versus physical-density distinctions of DERIVATION_v2.md.
No new apparatus, density measurement or state-selection premise is added.

On 0<z=A<1 define S_env=-z d_J'(z)/d_J(z). Multiplying the exact physical-density
map by z^2 gives

    z^2 d_J =6s(1-z^2)
     +nu D/[2a(1+s)] [s L^2+(1+s)L/z^2].                 (1)

Each positive product strictly decreases with z; the first derivative is
-12s z<0. Hence (z^2 d_J)'<0, so S_env>2. At fixed action parameters and scales,
the implicit stationary relation then gives

    d log A_stationary / d log rho_J = -1/S_env,         (2)
    -1/2 < d log A_stationary / d log rho_J <0.

This is the slope of a family of stationary points, not an asserted real-time
adiabatic response. A real body's dynamics and boundary matching remain open.

The fixed-particle Hessian identity gives a sharper local condition:

    m_J^2/Hv^2 =q z^2 delta_J (S_env-3),  q=a/J>0.        (3)

Therefore positive radial scalar mass at a stationary point is equivalent to
S_env>3, or to -1/3 < d log A_stationary/d log rho_J <0. The point S_env=3 has
zero radial mass, and 2<S_env<3 has negative radial mass under the prescribed
particle-density perturbation. Positive transverse masses remain as before.
This supplies a derivative-based diagnostic; merely asserting a unique root
or a slowly varying physical density does not establish the required stability.

For fixed s,a,nu>0 as z->0, D->1+s and L=log(D/z^2)->infinity. The dominant term is

    d_J ~ nu(1+s)L/(2a z^4),  S_env ->4,
    d log A_stationary/d log rho_J ->-1/4.               (4)

At z->1-, d_J has a positive first-order zero; S_env->infinity and the logarithmic
susceptibility tends to0 from below. These are local asymptotic branch statements,
not a cosmological trajectory or an allowed route past the chart endpoints.
The synthetic intermediate root already exhibited can have S_env<3 despite the
strict one-to-one physical-density map. Its physical density is different from
those of the two minima. No density or mass scale has been fitted or derived.
