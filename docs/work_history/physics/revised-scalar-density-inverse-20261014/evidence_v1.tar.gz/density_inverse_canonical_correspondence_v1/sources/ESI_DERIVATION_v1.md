# Density, gravity and scalar response without a vacuum-scale choice

Personally derived by /root. Conditional local theorem, not a measured fit. This extends the prescribed-particle density analysis without changing its final v3 source or any sealed evidence. The complete candidate action remains supplied. Natural units c=1 until section 5; Q is held fixed across the stationary family.

## 1. Precisely varied source and field data

Use local normal field coordinates chi^i at one stationary point for the supplied kinetic action -Q K_AB partial phi^A partial phi^B. Thus the canonical kinetic coefficient is -Q, not -Q/2. Write Y=Hv^2 U, A=sqrt(C)>0, beta_i=partial_i ln A and rho_*=m_J n_E, with particle number per local Einstein proper three-volume. The Einstein metric is fixed for the scalar variation. The physical rest density is rho_J=rho_*/A^3 and rho_E=A rho_*=A^4 rho_J. The scalar stationarity equation is

    F_i=Y_i+rho_* A_i/(2Q)=0.                         (1)

The fixed-particle Einstein squared mass matrix is the covariant Hessian

    M_E^2 = Hess(Y)+rho_* Hess(A)/(2Q).                (2)

These formulas come directly from the particle action -m_J integral A ds_E. Assume a differentiable local stationary family parametrized by positive rho_J, and a positive-definite M_E^2 at the point under consideration. This is scalar stability for the prescribed particles, not a fluid/gravity stability theorem. The implicit function theorem supplies a locally differentiable branch under the positive-definite condition below; it does not prepare or dynamically populate it.

At fixed physical density, rho_* changes as A^3. Defining c_rho=rho_E/(2Q)>0, differentiation of (1) along the stationary family gives

    [M_E^2+3 c_rho beta beta^T] dchi
       = -c_rho beta d ln rho_J.                     (3)

The additional rank-one term is a physical-volume effect. It is not part of the fixed-particle mass (2). Both matrices in (3) are positive definite under the premise above. Local field-coordinate connections cause no extra term in the derivative of the zero covector F; the invariant statement is obtained by using a K-orthonormal frame.

## 2. Exact susceptibility identity

Set zeta=c_rho beta^T (M_E^2)^(-1) beta >=0. The rank-one inverse identity yields

    d ln A / d ln rho_J = -zeta/(1+3 zeta),
    B := -d ln G_bare / d ln rho_J = 2 zeta/(1+3 zeta),
    zeta = B/(2-3B).                                 (4)

Here G_bare=A^2/(8 pi Q) and the same Q is used across the family. Therefore 0<=B<2/3 for finite positive masses; B=0 iff beta=0. The equality B=2/3 is a singular/limiting case, not attained under the finite positive-definite premise. The logarithmic A slope lies in (-1/3,0] on this stable family. An earlier negative-u stationary-map bound (-1/2,0) included unstable stationary points, so these results do not conflict.

At a frozen background M_J^2=M_E^2/A^2. Let m_i,J^2>0 be its eigenvalues in a K-orthonormal frame and q_i=(e_i dot beta)^2. Then

    zeta = 4 pi G_bare rho_J sum_i q_i/m_i,J^2,
    sum_i q_i = q = |beta|^2.                        (5)

No Hv or Q remains separately in this relation. They have been replaced by the local measurable tensor-force normalization and local density, conditional on reconstructing that normalization. This eliminates them from this one consistency relation; it does not derive their fundamental values.

For one coupled mass, or the coupling-weighted harmonic mass

    m_eff^2 = q / sum_i(q_i/m_i,J^2),  q>0,

we obtain

    m_eff^2/(4 pi G_bare rho_J)=q(2/B-3).             (6)

The effective mass is between the smallest and largest coupled masses. This identity constrains a weighted response and cannot determine all masses separately. In the revised candidate at x=y=0, the density source and coupling are radial and the mass matrix is diagonal, so m_eff=m_u,J. Substituting the earlier S_env=-A d_J'/d_J and B=2/S_env recovers

    m_u,J^2/(4 pi G_bare rho_J)=q(S_env-3).           (7)

Positive radial mass is equivalent to S_env>3 for that one coupled direction; the candidate's two transverse masses are separately positive. For a generic multi-field theory, satisfying (4) or 0<B<2/3 is only necessary for the full positive-mass premise, not sufficient. An uncoupled or weakly coupled negative eigenvalue can be hidden from this scalar contraction. For example M_E^2=diag(1,-4), c_rho=1 and beta=(1/5,1/10) give zeta=3/80>0 and the same apparently stable interval for B despite one unstable field. This counterexample lies outside the theorem's positive-definite hypothesis and defeats its converse, not the theorem.

## 3. What has and has not been selected

Equations (3)-(6) hold for any smooth potential and conformal coupling satisfying the explicit local premises. Agreement would test that prescribed-source stationary description, not distinguish this candidate's supplied potential from every alternative. Candidate-specific content still resides in q(A), d_J(A), the mass spectrum and higher responses. A state, equilibration mechanism, finite-body solution, metric backreaction, source pressure, quantum state and action-selection mechanism have not been supplied by this differentiation.

The derivative is between stationary configurations of different densities. It is not the time derivative during an evolving density change; adiabatic tracking requires its own separation of timescales and preparation. Nor is (4) a direct observation of A in universally coupled matter units.

## 4. A laboratory readout still needs its geometry

An actual positive calibrated response has G_cal=gamma(rho_J) G_bare. Thus

    B=-d ln G_cal/d ln rho_J + d ln gamma/d ln rho_J. (8)

For positive Newton-force kernels the earlier finite-body theorem gives 1<=gamma<=1+q in the frozen stable weak regime. That range alone does not bound its derivative. The mathematical envelope example gamma=1+(q/2)[1+sin(omega ln(rho_J/rho_ref))], for fixed q>0, remains in the interval while its logarithmic derivative at rho_ref grows without bound with omega. This is a counterexample to inferring a derivative bound from an amplitude bound; it is not a claimed apparatus solution.

A prospective observational use therefore requires enough spatial-range and source-geometry information to reconstruct G_bare and the coupled q_i,m_i. An ideal point-source sum of Yukawa responses provides such model observables in principle; finite size, readout conditioning and environmental backreaction remain separate. No unpublished experimental precision or independent dataset is assumed here. Density scans used to construct the derivative would be calibration/development data; a separate configuration would need to be reserved before a prediction could be called an independent test.

## 5. SI convention and checks planned before execution

If rho_m is physical mass density in kg/m^3 and mu_i is the inverse range in m^-1, (5) is

    zeta=(4 pi G_bare,SI rho_m/c_light^2) sum_i q_i/mu_i^2.

The single-mode identity is

    c_light^2 mu_J^2/(4 pi G_bare,SI rho_m)=q(2/B-3). (9)

For energy density use rho_energy/c_light^2 in place of rho_m. A missing c_light^2 would mix inverse-length squared and inverse-time squared. Neither SI G nor rho_m is assigned an empirical value in this block.

The executable controls will reconstruct (3) by differentiating an independently built source at a stationary point, verify a rational two-field rank-one inverse and a non-diagonal positive matrix, test the hidden unstable-direction counterexample and amplitude-versus-slope counterexample, and compare with the candidate's saved direct roots without solving or fitting them again. Actual altered implementations will remove the volume term, change the kinetic factor and omit the conformal mass conversion. These are model-development controls, not observed measurements. Full execution and failure records will be retained separately from this hand source.
