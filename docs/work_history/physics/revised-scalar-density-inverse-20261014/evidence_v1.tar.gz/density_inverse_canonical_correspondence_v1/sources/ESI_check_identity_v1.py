#!/usr/local/bin/python3
"""Prescribed-source stationary response; no measured data or parameter fit."""
from pathlib import Path
import argparse, hashlib, json
import sympy as S
import numpy as np
import mpmath as mp

VOLUME_POWER = S.Integer(3)
KINETIC_DIVISOR = S.Integer(2)
FRAME_POWER = S.Integer(2)

def run():
    rows=[]
    def eq(name, value):
        residual=S.factor(S.cancel(value))
        rows.append(dict(name=name,passed=residual==0,residual=str(residual)))
    def ck(name, passed, detail=None):
        rows.append(dict(name=name,passed=bool(passed),detail=detail))

    # Build a separate smooth two-field potential/coupling, then differentiate
    # the actual particle source rather than inserting the proposed response.
    x,y,r=S.symbols('x y rho_J',real=True)
    chi=S.Matrix([x,y]); zero={x:0,y:0}
    A0=S.Rational(3,5); Q=S.Rational(7,3); r0=S.Rational(11,5)
    beta=S.Matrix([S.Rational(1,5),S.Rational(-1,7)])
    L=S.Matrix([[S.Rational(1,9),S.Rational(1,13)],[S.Rational(1,13),S.Rational(-1,11)]])
    M=S.Matrix([[2,S.Rational(1,3)],[S.Rational(1,3),3]])
    A=A0*S.exp((beta.T*chi)[0]+(chi.T*L*chi)[0]/2)
    c_true=r0*A0**4/(2*Q)
    H_Y=M-c_true*(L+beta*beta.T)
    Y=-c_true*(beta.T*chi)[0]+(chi.T*H_Y*chi)[0]/2
    grad=lambda f:S.Matrix([S.diff(f,z) for z in chi])
    F=grad(Y)+r*A**3*grad(A)/(2*Q)
    F0=F.subs({**zero,r:r0})
    Hess_fixed=(S.hessian(Y,chi)+(r0*A0**3/(2*Q))*S.hessian(A,chi)).subs(zero)
    J=F.jacobian(chi).subs({**zero,r:r0})
    source=(r*F.diff(r)).subs({**zero,r:r0})
    c=r0*A0**4/(KINETIC_DIVISOR*Q)
    for i in range(2):
        eq('constructed_stationary_'+str(i),F0[i])
        eq('physical_density_source_'+str(i),source[i]-c*beta[i])
        for j in range(2):
            eq('fixed_particle_mass_'+str((i,j)),Hess_fixed[i,j]-M[i,j])
            eq('density_family_jacobian_'+str((i,j)),J[i,j]-M[i,j]-VOLUME_POWER*c*beta[i]*beta[j])
    ck('positive_fixed_particle_matrix',M[0,0]>0 and M.det()>0)
    ck('positive_family_jacobian',J[0,0]>0 and J.det()>0)
    response=-J.inv()*source
    zeta=c*(beta.T*M.inv()*beta)[0]
    eq('direct_implicit_log_A_response',(beta.T*response)[0]+zeta/(1+VOLUME_POWER*zeta))
    B=-2*(beta.T*response)[0]
    eq('response_inverse',zeta-B/(2-3*B))
    ck('stable_response_interval',0<B<S.Rational(2,3),str(B))

    # Symbolic rank-one algebra checked by multiplication, avoiding an
    # unnecessarily expanded inverse of the full modified matrix.
    h,j,k,b1,b2,cg=S.symbols('h j k b1 b2 c',real=True)
    Ms=S.Matrix([[h,j],[j,k]]); b=S.Matrix([b1,b2]); Mi=Ms.inv()
    zz=cg*(b.T*Mi*b)[0]
    candidate=Mi-VOLUME_POWER*cg*(Mi*b*b.T*Mi)/(1+VOLUME_POWER*zz)
    residual=(Ms+3*cg*b*b.T)*candidate-S.eye(2)
    for i in range(2):
        for t in range(2): eq('symbolic_rank_one_product_'+str((i,t)),residual[i,t])

    G=A0**2/(8*S.pi*Q)
    MJ=M/A0**FRAME_POWER
    zeta_physical=4*S.pi*G*r0*(beta.T*MJ.inv()*beta)[0]
    eq('physical_mass_and_density_conversion',zeta-zeta_physical)
    q=(beta.T*beta)[0]
    meff2=q/(beta.T*MJ.inv()*beta)[0]
    eq('harmonic_mass_identity',meff2/(4*S.pi*G*r0)-q*(2/B-3))
    ck('coupling_within_candidate_envelope',0<q<S.Rational(1,3))

    # Distinct three-field SPD examples verify contraction versus actual
    # orthonormal mass eigenmodes; they are synthetic controls, not observations.
    spectra=[]
    for idx,aa in enumerate([np.array([[2.,.3,-.1],[.3,3.,.2],[-.1,.2,5.]]),
                             np.array([[1.,-.2,.4],[-.2,4.,.7],[.4,.7,7.]]),
                             np.diag([.4,2.,11.])]):
        bb=np.array([.11,-.17,.09]);cc=.23
        vals,vecs=np.linalg.eigh(aa); weights=(vecs.T@bb)**2
        z=cc*float(bb@np.linalg.solve(aa,bb));spectral=cc*float(np.sum(weights/vals))
        v=-np.linalg.solve(aa+3*cc*np.outer(bb,bb),cc*bb)
        bv=-2*float(bb@v); me=float(bb@bb)/float(np.sum(weights/vals))
        ck('spectral_positive_'+str(idx),np.all(vals>0),vals.tolist())
        ck('spectral_inverse_'+str(idx),abs(z-spectral)<2e-16,abs(z-spectral))
        ck('matrix_response_'+str(idx),abs(bv-2*z/(1+3*z))<2e-16)
        ck('harmonic_mass_enclosure_'+str(idx),vals.min()<=me<=vals.max())
        spectra.append(dict(index=idx,mass_eigenvalues=vals.tolist(),coupling_weights=weights.tolist(),zeta=z,B=bv,harmonic_mass_squared=me))

    unstable=S.diag(1,-4); ub=S.Matrix([S.Rational(1,5),S.Rational(1,10)])
    uz=(ub.T*unstable.inv()*ub)[0];uB=2*uz/(1+3*uz)
    eq('unstable_hidden_contraction',uz-S.Rational(3,80))
    ck('unstable_matrix_has_negative_eigenvalue',unstable.det()<0)
    ck('unstable_counterexample_passes_slope_interval',0<uB<S.Rational(2,3),str(uB))

    density,ref,omega,qq=S.symbols('density reference omega q',positive=True)
    gamma=1+qq*(1+S.sin(omega*S.log(density/ref)))/2
    slope=(density*S.diff(gamma,density)/gamma).subs(density,ref)
    eq('bounded_gamma_unbounded_slope',slope-qq*omega/(2+qq))
    ck('slope_grows_without_bound',S.diff(slope,omega).is_positive)
    t=S.symbols('t',real=True)
    for end in [-1,1]:eq('gamma_envelope_endpoint_'+str(end),(1+qq*(1+t)/2).subs(t,end)-(1 if end==-1 else 1+qq))
    Gb,gam=S.Function('Gb')(density),S.Function('gamma')(density)
    eq('readout_slope_correction',-density*S.diff(Gb*gam,density)/(Gb*gam)+density*S.diff(gam,density)/gam+density*S.diff(Gb,density)/Gb)

    light,mu,Gsi,rhom=S.symbols('c_light mu G_SI rho_mass',positive=True)
    time_mass2=light**2*mu**2
    eq('SI_length_time_conversion',time_mass2/(4*S.pi*Gsi*rhom)-light**2*mu**2/(4*S.pi*Gsi*rhom))
    # Dimensions ordered mass,length,time. The numerator and denominator
    # must both be inverse time squared before their ratio is taken.
    dims_c=np.array([0,1,-1]);dims_mu=np.array([0,-1,0]);dims_G=np.array([-1,3,-2]);dims_rho=np.array([1,-3,0])
    ck('SI_ratio_dimensionless',np.all(2*dims_c+2*dims_mu-dims_G-dims_rho==0))
    ck('missing_c_squared_is_dimensionally_wrong',np.any(2*dims_mu-dims_G-dims_rho!=0))

    # Exposed saved direct roots are reused only; no equilibrium solve or fit.
    source=Path(__file__).parent.parent/'density_environment_v1/RESULTS_v1.json'
    saved=json.loads(source.read_text());mp.mp.dps=70
    kval=mp.mpf('0.1');nu=mp.mpf('0.0001');av=(1-kval)*(1+3*kval)/4;sv=(1+kval)/(kval*(1-3*kval))
    def dj(z):
        DD=1+sv-sv*z*z;LL=mp.log(DD/z**2)
        return 6*sv*(z**-2-1)+nu*DD/(2*av*(1+sv))*(sv*LL**2/z**2+(1+sv)*LL/z**4)
    roots=[]
    for row in saved['roots']:
        z=mp.mpf(row['z']);delta=mp.mpf(row['delta_j']);qr=mp.mpf(row['q']);mass=mp.mpf(row['mJ2_over_Hv2'])
        ss=-z*mp.diff(dj,z)/dj(z);bb=2/ss
        lhs=mass/(z*z*delta);rhs=qr*(2/bb-3)
        error=abs(lhs-rhs)/max(1,abs(lhs),abs(rhs))
        ck('saved_candidate_scale_free_identity_'+str(row['index']),error<mp.mpf('1e-34'),mp.nstr(error,15))
        ck('saved_candidate_radial_stability_'+str(row['index']),(bb<mp.mpf(2)/3)==(mass>0))
        roots.append(dict(index=row['index'],B=mp.nstr(bb,45),dimensionless_mass_ratio=mp.nstr(lhs,45),q=mp.nstr(qr,45),positive_radial_mass=mass>0))
    return dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,synthetic_spectra=spectra,saved_root_results=roots,saved_root_input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),scope='Conditional stationary response; general identity, not action selection or empirical fit.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    result=run();result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out=Path(args.output);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['passed','failed','saved_root_results','scope']},indent=2))
    raise SystemExit(bool(result['failed']))
