#!/usr/bin/env python3
"""Read-only comparison of original results, actual damages and three prior seals."""
import datetime,hashlib,json,sys
from pathlib import Path
u=Path(__file__).resolve().parent;pk=u.parent;rr=pk/'rolling_local_response';rows=[];recovery=[]
def js(n):return json.loads((u/n).read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,b,d=None):rows.append({'name':n,'passed':bool(b),'detail':d})
staged=js('records/STAGED_RESULTS_v1.json')
original_files={'density':'original_outputs/ENVIRONMENT_STAGED_RESULTS_v1.json','identity':'original_outputs/ESI_RESULTS_v1.json','reconstruction':'original_outputs/DAR_RESULTS_v1.json','domains':'original_outputs/DAR_DOMAIN_RESULTS_v1.json'}
comparison=[]
for name,filename in original_files.items():
 old=js(filename)
 if name=='density':
  oldrows=[{**r,'name':r['name'].split('::',1)[1]} for r in old['checks'] if r['name'].startswith('density_environment::')]
  oldoutputs=old['substantive_outputs']['density_environment']
 else:
  oldrows=old['checks'];oldoutputs={k:v for k,v in old.items() if k not in ['checks','passed','failed','checker_sha256']}
  if name=='identity':
   del oldoutputs['saved_root_input_sha256'];oldoutputs['root_input_kind']='fresh in-memory density calculation'
 newrows=[{**r,'name':r['name'].split('::',1)[1]} for r in staged['checks'] if r['name'].startswith(name+'::')]
 newout=staged['substantive_outputs'][name]
 ck('output_exact.'+name+'.every_row',newrows==oldrows,{'rows':len(newrows)})
 ck('output_exact.'+name+'.every_substantive_value',newout==oldoutputs)
 comparison.append({'unit':name,'original_snapshot':filename,'original_sha256':h(u/filename),'complete_row_count':len(newrows),'row_array_sha256':hashlib.sha256(json.dumps(newrows,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'normalized_substantive_sha256':hashlib.sha256(json.dumps(newout,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'allowed_metadata_normalization':'density namespace rename' if name=='density' else 'scratch input hash -> in-memory provenance' if name=='identity' else 'none'})
# Actual complete changed-run correspondence; no damaged science is rerun.
protocol=js('parent_damages/PROTOCOL_v1.json');summary=js('parent_damages/SUMMARY_v1.json');original=(u/'staged/exponential_scalar_density_inverse_check.py').read_text();summary_by_name={Path(r['argv'][1]).stem:r for r in summary}
ck('parent_damage.original_hash',protocol['source_sha256']==h(u/'staged/exponential_scalar_density_inverse_check.py'))
ck('parent_damage.four_records',len(protocol['mutations'])==len(summary)==4)
for m in protocol['mutations']:
 name=m['name'];script=u/'parent_damages'/f'{name}.py';result=js(f'parent_damages/{name}_RESULTS.json');exe=js(f'parent_damages/{name}_EXECUTION.json');summ=summary_by_name[name];fails=[r['name'] for r in result['checks'] if not r['passed']]
 ck('parent_damage.'+name+'.single_actual_edit',original.count(m['old'])==1 and script.read_text()==original.replace(m['old'],m['new'],1))
 ck('parent_damage.'+name+'.source_bindings',h(script)==result['checker_sha256']==exe['source_sha256']==summ['source_sha256'])
 ck('parent_damage.'+name+'.actual_exit',exe['exit_code']==summ['exit_code']==1 and exe['finished']>exe['started'])
 ck('parent_damage.'+name+'.preexecution_protocol',protocol['at']<exe['started'])
 ck('parent_damage.'+name+'.all_rows_preserved',len(result['checks'])==240)
 ck('parent_damage.'+name+'.counts_true',result['passed']==sum(r['passed'] for r in result['checks'])==summ['passed'] and result['failed']==sum(not r['passed'] for r in result['checks'])==summ['failed'])
 ck('parent_damage.'+name+'.named_failure',m['witness'] in fails and fails==summ['failed_names'])
 ck('parent_damage.'+name+'.full_stdout_identity',json.loads((u/'parent_damages'/f'{name}_stdout.txt').read_text())==result)
 ck('parent_damage.'+name+'.stderr_empty',(u/'parent_damages'/f'{name}_stderr.txt').read_text()=='')
 ck('parent_damage.'+name+'.execution_summary_identity',all(exe[k]==summ[k] for k in exe))
# Whole prior evidence inventories are verified by hash only, not re-executed or re-reviewed.
expected_receipts={'ESI':'e6c936f1bcf4fe11c9c0053ae812fe8d97927aacf853562a80d44f901a3e7e08','DENSITY':'e82004e2c5f13849b603a79cf677e63acca3c403a1e2639fb7b0eac72429ec86','DAR':'2a119155f2e744d4945eab2365ffa5f6f8b3b6278a2867dfc53fe005c69b6fa9'}
for label,folder in [('ESI','environment_susceptibility_identity_v1'),('DENSITY','density_environment_v1'),('DAR','density_action_reconstruction_v1')]:
 root=rr/folder/'independent_v1';receipt=js('reused/'+label+'_RECEIPT_v1.json');manifest=js('reused/'+label+'_MANIFEST_v1.json')
 ck('reuse.'+label+'.receipt_identity',h(root/'RECEIPT_v1.json')==h(u/'reused'/f'{label}_RECEIPT_v1.json')==expected_receipts[label])
 ck('reuse.'+label+'.manifest_identity',h(root/'MANIFEST_v1.json')==h(u/'reused'/f'{label}_MANIFEST_v1.json')==receipt['manifest']['sha256'])
 ck('reuse.'+label+'.report_identity',h(root/'REPORT_v1.md')==h(u/'reused'/f'{label}_REPORT_v1.md')==receipt['report']['sha256'])
 for a in manifest['artifacts']:
  p=root/a['path'];ck('reuse.'+label+'.artifact.'+a['path'],p.is_file() and not p.is_symlink() and h(p)==a['sha256'] and p.stat().st_size==a['bytes'])
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};expected={a['path'] for a in manifest['artifacts']}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
 ck('reuse.'+label+'.exact_inventory',actual==expected,{'manifest_artifacts':len(manifest['artifacts']),'total_files':len(actual)})
 for b in receipt['source_pairs']:
  ck('reuse.'+label+'.source_pair.'+b['snapshot_path'],h(Path(b['original_path']))==h(root/b['snapshot_path'])==b['sha256'])
 recovery.append({'label':label,'original_root':str(root),'report_sha256':h(root/'REPORT_v1.md'),'manifest_sha256':h(root/'MANIFEST_v1.json'),'receipt_sha256':h(root/'RECEIPT_v1.json'),'artifact_count':len(manifest['artifacts']),'source_pair_count':len(receipt['source_pairs']),'recovery':'Original immutable unit retained at this root; full constituent hashes frozen in the copied manifest, report and receipt. Verified every current byte; no science rerun.','artifacts':manifest['artifacts']})
# The DAR corrected source in canonical body is exactly the independently checked final v2.
dar=js('reused/DAR_RECEIPT_v1.json');esi=js('reused/ESI_RECEIPT_v1.json');density=js('reused/DENSITY_RECEIPT_v1.json')
ck('reuse.DAR.final_source_canonical',dar['correction_confirmation']['final_source_sha256']==h(u/'sources/DAR_DERIVATION_v2.md'))
ck('reuse.DAR.prose_only_correction',dar['correction_confirmation']['source_coefficients_changed'] is False and dar['correction_confirmation']['new_science_rerun'] is False)
ck('reuse.DAR.exact_baseline_and_damages',dar['science']['new_independent_baseline']['passed']==118 and dar['science']['new_independent_baseline']['failed']==0 and dar['science']['actual_damaged_copies']==8)
ck('reuse.ESI.final_source_canonical',esi['final_author_source']['sha256']==h(u/'sources/ESI_DERIVATION_v1.md'))
ck('reuse.ESI.exact_baseline_and_damages',esi['new_mathematics']['passed']==114 and esi['new_mathematics']['failed']==0 and esi['actual_damages']['executed']==6)
ck('reuse.DENSITY.final_source',density['final_author_source']['sha256']==h(u/'sources/DENSITY_DERIVATION_v3.md'))
# Bind every additional snapshot to its exact unchanged live source.
for b in js('SOURCE_BINDINGS_ADDITIONAL_v1.json')['source_pairs']:
 ck('additional_binding.'+b['snapshot_path'],h(Path(b['original_path']))==h(u/b['snapshot_path'])==b['sha256'])
(u/'ORIGINAL_OUTPUT_COMPARISON_v1.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparisons':comparison,'stage_result_sha256':h(u/'records/STAGED_RESULTS_v1.json'),'complete_equality':all(x['passed'] for x in rows if x['name'].startswith('output_exact.')),'science_rerun':False},indent=2)+'\n')
(u/'REUSED_SEAL_RECOVERY_v1.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'units':recovery,'scope':'Full byte identity and recovery inventory only; old results remain old evidence.'},indent=2)+'\n')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact existing output and damaged-run correspondence plus prior-seal hash verification; no science execution.','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'script_sha256':h(Path(__file__))}
(u/'REUSE_OUTPUT_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[x['name'] for x in rows if not x['passed']],'reused_artifact_counts':{x['label']:x['artifact_count'] for x in recovery}},indent=2));sys.exit(bool(result['failed']))
