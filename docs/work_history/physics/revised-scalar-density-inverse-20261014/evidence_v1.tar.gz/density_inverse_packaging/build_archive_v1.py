from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'density_inverse_packaging';dest=wt/'docs/work_history/physics/revised-scalar-density-inverse-20261014'
roots=['rolling_local_response/density_environment_v1','rolling_local_response/environment_susceptibility_identity_v1','rolling_local_response/density_action_reconstruction_v1','density_inverse_canonical_correspondence_v1','density_inverse_packaging']
seal_units=['rolling_local_response/density_environment_v1/independent_v1','rolling_local_response/environment_susceptibility_identity_v1/independent_v1','rolling_local_response/density_action_reconstruction_v1/independent_v1','density_inverse_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional environmental roots, stationary susceptibility and density-to-Jordan-action reconstruction with source-control domains, full histories and scoped independent reviews. No selected action/state/scale or measured likelihood.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for revised scalar density-to-action inverse

Live claim: docs/EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

Exact observed-response inputs are hypothetical here. No density function,
scalar range or coupling has been fitted to an apparatus. All numerical root
examples and calibrations are exposed model-development data.

For a positive fixed-particle scalar mass matrix, the stationary susceptibility
obeys B=2zeta/(1+3zeta), with zeta=4pi Gbare rho sum(q_i/m_i^2) in the physical
frame. Thus 0<=B<2/3 is necessary in that stable class; it is not a converse in
multiple fields. Actual calibrated G carries a separate response derivative.

In a single active scalar direction, exact ideal q(F),rho(F) reconstruct
omega=(1/q-3)/2 and VJ=F^2[C+integral rho/(2F^3)dF]. The arbitrary C is a real
Einstein vacuum-energy ambiguity, not a harmless Jordan additive constant.
The fixed-particle mass q[rho'-3rho/(2F)] differs from the fixed physical-density
coefficient q rho'. Source-control and field-basis qualifications are explicit.

The supplied candidate has a unique stationary negative-u root at each fixed
physical density, while an explicit fixed Einstein particle-density example
has two local minima and a saddle. Neither statement prepares or selects a
realized state. This archive does not include the later fluid dynamical model.

Fresh canonical240/0: density96, susceptibility53, action63, domain28. Complete
staged/live results match. Four actual altered canonical programs fail with
9,1,5,14 failed checks. Independent science seals are reused by exact identity;
new correspondence counts are metadata/wrapper checks, not new observations.

Preserved failures include the original density CAS stall and asymptotic
criterion failure, staged comparison key error, source-path installation error,
review AST filter and recovery-map path errors. Repairs, complete prior
versions, changed programs, streams and source snapshots are retained.

All source bodies and evidence are recoverable. Extract only safe regular
relative members and verify every manifest size/hash. Delivery/UNIT records
follow this archive. No selected action, state, physical scale or empirical
acceptance is claimed.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
