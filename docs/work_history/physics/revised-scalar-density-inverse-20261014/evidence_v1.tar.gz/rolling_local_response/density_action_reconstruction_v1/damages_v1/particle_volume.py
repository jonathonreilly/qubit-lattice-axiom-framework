#!/usr/local/bin/python3
"""Direct conditional action reconstruction; no fitted or hidden empirical data."""
from pathlib import Path
import json,hashlib,argparse
import sympy as s
import mpmath as mp

IBP_COEFFICIENT=s.Integer(6)
POTENTIAL_SOURCE_SIGN=s.Integer(1)
PARTICLE_VOLUME_POWER=s.Integer(0)

def run():
    rows=[]
    def eq(name,e):
        r=s.factor(s.cancel(s.together(e)))
        rows.append(dict(name=name,passed=r==0,residual=str(r)))
    def ck(name,ok,detail=None):rows.append(dict(name=name,passed=bool(ok),detail=detail))

    F,Q,A,q=s.symbols('F Q A q',positive=True)
    lamx=s.symbols('lambda_gradient_squared',real=True)
    omega=(1/q-3)/2
    # Unintegrated Ricci gradient contributes -3F; integrating 3F box ln A
    # contributes +6F from dF=-2F d ln A. Original kinetic gives -F/q.
    transformed=(-3+IBP_COEFFICIENT-1/q)*F*lamx
    expected=-omega*(4*F**2*lamx)/(2*F)
    eq('Jordan_kinetic_coefficient',transformed-expected)
    eq('Jordan_invariant_kinetic_normalization',2*omega+3-1/q)
    eq('conformal_volume_curvature',A**-4*(Q/2)*A**2-Q/(2*A**2))
    qn=s.Function('q')(F)
    chiF=1/(2*F*s.sqrt(qn))
    eq('canonical_coordinate_metric',chiF**2-1/(4*F**2*qn))
    eq('coupling_reconstruction_from_F',(-1/(2*F*chiF))**2-qn)

    # Scalar Euler-Lagrange equation and metric trace are combined before
    # imposing stationarity; variable omega is retained throughout.
    w=s.Function('omega')(F);V=s.Function('V')(F)
    R,Box,X,T=s.symbols('R BoxF X T',real=True)
    scalar=R/2+w*Box/F+(s.diff(w,F)/F-w/F**2)*X/2-s.diff(V,F)
    Rtrace=(-T+w*X/F+3*Box+4*V)/F
    target=(2*w+3)*Box-T+s.diff(w,F)*X-2*F*s.diff(V,F)+4*V
    eq('variable_omega_trace_elimination',2*F*scalar.subs(R,Rtrace)-target)
    rho=2*F*s.diff(V,F)-4*V
    eq('stationary_density_from_trace',target.subs({Box:0,X:0,T:-rho}))
    eq('density_integrating_factor',s.diff(V/F**2,F)-rho/(2*F**3))
    C=s.symbols('C',real=True)
    eq('homogeneous_potential_offset',2*F*s.diff(C*F**2,F)-4*C*F**2)
    eq('offset_is_constant_Einstein_energy',A**4*C*(Q/A**2)**2-C*Q**2)
    ck('offset_changes_metric_trace',s.diff(4*C*F**2/F,C)!=0)
    eq('constant_scalar_reference_curvature',Rtrace.subs({Box:0,X:0,T:-rho})-(rho+4*V)/F)

    # Reconstruct the Einstein potential and differentiate with the actual
    # field-coordinate chain rule. Fixed particle density is substituted
    # after, not before, differentiating the force.
    AA=s.symbols('z',positive=True);VV=s.Function('V');qq=s.Function('q')
    FA=Q/AA**2;VE=AA**4*VV(FA);beta=s.sqrt(qq(FA))
    Dchi=lambda expr:AA*beta*s.diff(expr,AA)
    rstar=s.symbols('rho_star',real=True)
    force=(Dchi(VE)+rstar*Dchi(AA))/(2*Q)
    rhoA=2*FA*s.diff(VV(F),F).subs(F,FA)-4*VV(FA)
    stationary=rstar-rhoA*AA**3
    eq('stationary_particle_force',force-(AA*beta/(2*Q))*stationary)
    massE=Dchi(force).subs(rstar,rhoA*AA**3)
    rhoF=2*F*s.diff(VV(F),F)-4*VV(F)
    expected0=qq(F)*(s.diff(rhoF,F)-PARTICLE_VOLUME_POWER*rhoF/(2*F))
    eq('fixed_particle_mass_from_full_potential',massE/AA**2-expected0.subs(F,FA))
    pp=s.symbols('p',real=True)
    massp=expected0+pp*qq(F)*rhoF/(2*F)
    eq('fixed_physical_density_mass',massp.subs(pp,3)-qq(F)*s.diff(rhoF,F))
    eq('trace_scalar_mass_at_stationarity',qq(F)*(2*F*s.diff(VV(F),F,2)-2*s.diff(VV(F),F))-qq(F)*s.diff(rhoF,F))
    # q' multiplies a zero stationary residual, so it contributes no linear
    # mass term in the trace-eliminated equation about this constant point.
    r0=s.symbols('rho0',real=True)
    eq('variable_q_mass_no_extra_term',s.diff(qq(F)*(rhoF-r0),F).subs(r0,rhoF)-qq(F)*s.diff(rhoF,F))

    G,Gr,Vr=s.symbols('G Gref Vref',positive=True)
    Rho=s.Function('rho')(G)
    # Equivalent linear ODE in physical tensor-force normalization.
    Vg=s.Function('Vg')(G)
    eq('G_variable_ODE',-2*G*s.diff(Vg,G)-4*Vg-(-2*(s.diff(G**2*Vg,G)/G)))
    eq('G_integrating_factor',s.diff(G**2*Vg,G)-G*(G*s.diff(Vg,G)+2*Vg))

    F0=s.Rational(11,10);rho0=s.Rational(13,7)
    examples=[]
    for n in [s.Rational(1,1),s.Rational(3,2),s.Integer(2),s.Integer(3),s.Rational(7,2)]:
        rho_n=rho0*(F/F0)**n
        if n==2: vn=F**2*(C+rho0*s.log(F/F0)/(2*F0**2))
        else: vn=C*F**2+rho0*F**n/(2*(n-2)*F0**n)
        eq('power_density_inverse_'+str(n),2*F*s.diff(vn,F)-4*vn-POTENTIAL_SOURCE_SIGN*rho_n)
        eq('power_density_log_slope_'+str(n),rho_n/(F*s.diff(rho_n,F))-1/n)
        q_fn=1/(12+F/F0)
        m0=q_fn*(s.diff(rho_n,F)-PARTICLE_VOLUME_POWER*rho_n/(2*F))
        m3=m0+3*q_fn*rho_n/(2*F)
        eq('power_fixed_particle_mass_'+str(n),m0-q_fn*rho_n*(n-s.Rational(3,2))/F)
        eq('power_fixed_J_mass_'+str(n),m3-q_fn*rho_n*n/F)
        ev={F:s.Rational(3,2),C:10}
        ck('positive_reference_potential_'+str(n),vn.subs(ev)>0,str(vn.subs(ev)))
        ck('positive_J_coefficient_'+str(n),m3.subs(ev)>0)
        ck('fixed_particle_stability_domain_'+str(n),bool(m0.subs(ev)>0)==bool(n>s.Rational(3,2)))
        examples.append(dict(n=str(n),F='3/2',q=str(q_fn.subs(ev)),rho=str(rho_n.subs(ev)),VJ=str(vn.subs(ev)),mass0=str(m0.subs(ev)),mass3=str(m3.subs(ev)),B=str(1/n)))
    ck('fixed_J_positive_does_not_imply_particle_stability',s.Rational(1,1)<s.Rational(3,2))

    # Specialize to the original candidate potential, treating a,s,nu as
    # positive symbols; no measured density or fitted parameters are inserted.
    aa,ss,nu,Hv=s.symbols('a s nu Hv',positive=True)
    DD=1+ss-ss*AA**2;LL=s.log(DD/AA**2)
    U0=s.Rational(3,2)+s.Rational(3,2)*ss*(1-AA**2)**2+nu*DD**2*LL**2/(8*aa*(1+ss))
    dj=6*ss*(AA**-2-1)+nu*DD/(2*aa*(1+ss))*(ss*LL**2/AA**2+(1+ss)*LL/AA**4)
    candidateV=2*Q*Hv**2*U0/AA**4
    D_F=lambda expr:-AA**3*s.diff(expr,AA)/(2*Q)
    eq('candidate_original_density_inverse',2*(Q/AA**2)*D_F(candidateV)-4*candidateV-2*Q*Hv**2*dj)
    eq('candidate_vacuum_energy',candidateV.subs(AA,1)-3*Q*Hv**2)
    eq('candidate_vacuum_trace',(4*candidateV/(Q/AA**2)).subs(AA,1)-12*Hv**2)
    rho_candidate=2*Q*Hv**2*dj
    q_candidate=aa*DD/(1+ss-3*aa*ss*AA**2)
    eq('candidate_mass_prescription_difference',q_candidate*D_F(rho_candidate)-q_candidate*s.diff(U0,AA,2)*Hv**2-3*q_candidate*rho_candidate/(2*(Q/AA**2)))

    # A separate numerical quadrature recovers a nonlinear power+log potential
    # from its density curve with a supplied reference value. It is synthetic.
    mp.mp.dps=70
    rho_fn=lambda f:mp.mpf('1.7')*f**3+mp.mpf('.9')*f**2
    trueV=lambda f:f*f*(mp.mpf('2.4')+mp.mpf('.85')*f+mp.mpf('.45')*mp.log(f))
    fref=mp.mpf('1.2');vref=trueV(fref);quad=[]
    for val in ['0.7','1.1','2.3','4.2']:
        f=mp.mpf(val);recon=f*f*(vref/fref**2+mp.quad(lambda u:rho_fn(u)/(2*u**3),[fref,f]))
        err=abs(recon-trueV(f))/max(1,abs(trueV(f)))
        ck('density_quadrature_inverse_'+val,err<mp.mpf('1e-60'),mp.nstr(err,15))
        quad.append(dict(F=val,VJ=mp.nstr(recon,60),relative_error=mp.nstr(err,15)))
    return dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,exact_power_examples=examples,numerical_reconstruction=quad,scope='Conditional single-field inverse and source-control distinction; no empirical functions measured or action/state selected.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);a=ap.parse_args()
    result=run();result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out=Path(a.output);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['passed','failed','scope']}))
    for row in result['checks']:
        if not row['passed']:print(json.dumps(row))
    raise SystemExit(bool(result['failed']))
