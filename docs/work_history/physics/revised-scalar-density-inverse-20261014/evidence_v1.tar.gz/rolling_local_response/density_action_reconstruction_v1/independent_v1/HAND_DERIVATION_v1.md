# Independent action reconstruction before computation

Inputs: frozen author DERIVATION_v1, its protocol, the complete supplied action,
and the two preceding mathematical sources. No producer code/results were read.
The primary Quiros PDF pp.2-3 was extracted and visually read; only its action,
metric/scalar normalization and constant-omega mass are used as a cross-check.
This is a focused check; /root retains scientific authorship.

## Direct action and trace variation

Use signature (-+++), X=(partial F)^2 and B=box F temporarily. For
L=F R/2-w(F)X-V, w=omega/(2F), the scalar Euler derivative is

 E_F=R/2+2w B+w' X-V'=0.

The metric variation gives

 F G_mn=T_mn+(omega/F)(F_m F_n-g_mn X/2)
          +nabla_m nabla_n F-g_mn box F-g_mn V.

Its trace is F R=-T+(omega/F)X+3B+4V. Multiplying E_F by 2F
and eliminating R leaves

 (2omega+3)B=T+2F V'-4V-omega' X.

For a constant scalar and physical dust T=-rho this gives
N(F)=2F V'-4V=rho. Linearization at a stationary constant background
with fixed physical rho yields mass q N'=q(2F V''-2V'). The derivative
of q multiplies N-rho=0, and omega' X is quadratic at a constant background.
This coefficient is not the full coupled material/metric spectrum.

## Conformal transformation and field chart

g_E=A^-2 g_J, lambda=ln A and F=Q/A^2 give
sqrt(-g_E)R_E=A^-2 sqrt(-g_J)[R_J+6box lambda-6(partial lambda)^2].
Integration of 3F box lambda gives -3 partial F partial lambda
=+6F(partial lambda)^2. Together with the Ricci gradient term and
-F(partial chi)^2, the coefficient is -F(1/q-3)(partial lambda)^2.
Since d lambda=-dF/(2F), omega=(1/q-3)/2. Thus 2omega+3=1/q>0;
omega itself can be negative in the general ghost-free class. A nonzero smooth
coupling on a connected branch fixes the sign of F_chi, yielding
dchi=+/- dlnF/(2sqrt(q)), up to an additive constant. A q=0 point is
excluded from this chart. Physical F=1/(8pi Gbare)>0 is fixed by the ideal
tensor coefficient, but choosing Q and the Einstein normalization is extra.

A direct geometry control will use g_J=eta and g_E=e^-2lambda(t)eta.
Computing its connection/Ricci tensor gives R_E=6e^2lambda(-lambda_ddot
+lambda_dot^2). The time-density Ricci term differs from -3F lambda_dot^2
by d(-3F lambda_dot)/dt. This tests the boundary coefficient independently
of merely substituting the proposed omega expression.

## Potential family and the constant ambiguity

At fixed Einstein proper particle density r_*=m_J n_E and fixed Einstein
metric, W_E=V_E+r_* A. Stationarity requires V_E,A=-r_*=-rho A^3.
Using V_E=A^4 V(F), F_A=-2F/A, gives A^3(4V-2F V')=-rho A^3.
Therefore (V/F^2)'=rho/(2F^3), determining V on an interval up to C F^2.
Under A^4=Q^2/F^2 that is the constant Einstein shift C Q^2. Its scalar
source and derivatives vanish, but its metric stress does not. At a constant
scalar the trace is F R=rho+4V, so the same shift changes required R by 4CF.
Away from a constant scalar, the neglected trace correction is omega X/F+3box F.
One Hubble value alone does not determine curvature or these derivative terms.

Converting F=1/(8pi G) gives (G^2 V)_G=-rho G/2. A density curve does not
determine q, an isolated density point does not determine the function, and
off-interval/transverse action freedom is not fixed by this inverse.

## Source-controlled Hessian and mass

Differentiate the stationary family V_E,chi+r_*(chi)A_chi=0:
H0=V_E,chichi+r_* A_chichi=-(r_*)_chi A_chi.
With beta=lambda_chi, beta^2=q, r_*=rho(F)A^3 and F_chi=-2F beta,

 H0=A^4 q(2F rho'-3rho).

The actual kinetic coefficient is 2Q, and the frozen physical mass is
m_J^2=H0/(2Q A^2), not H0 A^2/(2Q). Hence

 m0,J^2=q[rho'-3rho/(2F)].

The prescribed law delta ln r_*=p delta ln A adds p rho_E beta^2 to H0,
giving mp,J^2=q[rho'+(p-3)rho/(2F)]. p=0 and p=3 impose different
matter controls; p=3 sets delta rho_J=0 at fixed Einstein metric. It does not
construct a reservoir/support mechanism or establish a physical mode of matter.

In several fields beta_A=partial_A ln A. The covariant mass bilinear changes
by p rho_E/(2Q) beta_A beta_B. The mass endomorphism changes by
p rho_E/(2Q) K^{AC} beta_C beta_B. In a K-orthonormal frame this is the
ordinary symmetric outer product. The v1 notation did not state that basis;
the author has agreed to clarify it. A non-diagonal K will test the distinction.

For rho>0 and rho' nonzero, a local inverse density chart has
B=-dlnG/dlnrho=rho/(F rho'). Stable fixed-particle mass requires rho'>
3rho/(2F), so 0<B<2/3. The undivided mass identities remain valid at rho'=0;
the logarithmic inverse does not. V1 omitted this domain qualification, which
the author has agreed to make explicit. A constant-density family and a density
turning point will test the non-invertible cases without dividing by zero.

## Independent controls selected before code

Use nonconstant q(F)=F/(7+11F), omega=4+7/(2F), with
chi(F)=sqrt(11)asinh(sqrt(11F/7))-sqrt((7+11F)/F).
Its derivative has the required square. Compare q=1/2 (omega<0 but healthy)
and q=0 (invalid chart) to keep kinetic positivity distinct from omega>0.

Power densities with n=1,2,3,5/4,7/2 test the resonant integral, potential
offset, and p=-2,0,1,3,5 masses. n=1 and n=5/4 have positive m3 but negative
m0. rho=constant and rho=3+(F-2)^2 expose inverse-chart failure. A distinct
mixed density rho=9sqrt(F)+6F^(5/2)+10F^2 has particular potential
-3sqrt(F)+6F^(5/2)+5F^2 ln(F/Fref); independent quadrature at off-grid
points will reconstruct it from rho, including reference normalization.

For the multi-field control use K=[[2,1],[1,3]] and covector
beta=(2/7,-1/5); transform with an exact K-orthonormal basis and compare
mixed-index/covariant forms, trace p c_rho q and rank one.

For the candidate keep its old denominator as D_E=1+sE to avoid confusing
it with Jordan F. On x=y=0, Gamma^x_uu=Gamma^y_uu=0 and U_x=U_y=0;
A is independent of transverse fields. Hence this is a consistent truncation,
not a dynamically selected sector. Canonicalize with dchi=sqrt(J)/D_E du.
Then q=a/J and Jordan F=Q D_E/[(1+s)E]. Equivalently
E=Q/[(1+s)F-sQ]. Differentiate the transformed original V_E=2Q Hv^2 U0
to recover the physical density and the inverse equation. Do not use the
canonically normalized fluid rho_J symbol as a physical density: here rho is
the physical rest-energy density in the stated natural units.

Actual one-edit damages will target the boundary sign, trace omega' term,
source 2Q normalization, physical mass conversion, particle volume power,
potential homogeneous ambiguity and omission of the field metric inverse.
All original attempts and failures will remain; no producer implementation
or output will be used as an oracle.
