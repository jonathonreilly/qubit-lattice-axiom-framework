from pathlib import Path
import json,sys,hashlib
import sympy as S
import mpmath as mp
mp.mp.dps=80

# One-edit targets; expected identities below are derived independently.
BOUNDARY_SIGN=1
TRACE_OMEGA_SIGN=-1
KINETIC_DIVISOR=2
FRAME_POWER=-2
VOLUME_POWER=3
AMBIGUITY_POWER=2
INCLUDE_K_INVERSE=1
INVERSE_SIGN=-1

rows=[]
def ck(n,v,**data):rows.append(dict(name=n,passed=bool(v),**data))
def eq(n,v):
    r=S.simplify(v);ck(n,r==0,residual=str(r))
F,Q,Rho,C=S.symbols('F Q rho C',positive=True)
X,B,T,R=S.symbols('X boxF T R')
om=S.Function('omega')(F);V=S.Function('V')(F);q=S.Function('q')(F)

# Geometry independently computed from the conformal flat metric.
t=S.symbols('t',real=True);lam=S.Function('lambda')(t);ex=S.exp(-2*lam)
g=S.diag(-ex,ex,ex,ex);gi=g.inv()
def d(e,i):return S.diff(e,t) if i==0 else S.Integer(0)
Gam={}
for a in range(4):
 for b in range(4):
  for c in range(4):Gam[a,b,c]=S.simplify(sum(gi[a,m]*(d(g[m,c],b)+d(g[m,b],c)-d(g[b,c],m))/2 for m in range(4)))
Ric={}
for a,b in [(0,0),(1,1),(2,2),(3,3),(0,1)]:
 Ric[a,b]=S.simplify(sum(d(Gam[c,a,b],c)-d(Gam[c,a,c],b)+sum(Gam[c,a,b]*Gam[e,c,e]-Gam[e,a,c]*Gam[c,b,e] for e in range(4)) for c in range(4)))
curv=S.simplify(sum(gi[i,i]*Ric[i,i] for i in range(4)))
eq('direct_Ricci_conformal',curv-6*S.exp(2*lam)*(-S.diff(lam,t,2)+S.diff(lam,t)**2))
eq('direct_Ricci_off_diagonal',Ric[0,1])
Ft=Q*S.exp(-2*lam);raw=Q*S.exp(-4*lam)*curv/2;boundary=-3*Ft*S.diff(lam,t)*BOUNDARY_SIGN
eq('Ricci_boundary_density',raw-S.diff(boundary,t)+3*Ft*S.diff(lam,t)**2)
qs=S.symbols('q',positive=True);derived_omega=(1/qs+3-6*BOUNDARY_SIGN)/2
eq('Jordan_kinetic_normalization',derived_omega-(1/qs-3)/2)
eq('kinetic_invariant_positive',2*derived_omega+3-1/qs)

# Direct Euler derivative and independent metric trace elimination.
w=om/(2*F);EL=R/2+2*w*B+S.diff(w,F)*X-S.diff(V,F)
trace_R=(-T+om*X/F+3*B+4*V)/F
eliminated=S.expand((2*F*EL).subs(R,trace_R))
N=2*F*S.diff(V,F)-4*V
pred=(2*om+3)*B-(T+N+TRACE_OMEGA_SIGN*S.diff(om,F)*X)
eq('direct_scalar_trace_elimination',eliminated-pred)
eq('metric_trace_constant_dust',trace_R.subs({T:-Rho,X:0,B:0})-(Rho+4*V)/F)
eq('dust_stationary_equation',pred.subs({T:-Rho,B:0,X:0})-(Rho-N))
qv=F/(7+11*F);ov=(1/qv-3)/2
eq('variable_omega_example',ov-(4+S.Rational(7,2)/F))
eq('variable_omega_sign_witness',(eliminated-pred).subs(om,ov).doit().subs({F:S.Rational(5,3),X:-S.Rational(11,7)}))

# Field coordinate, positivity and zero-coupling boundary.
chi=S.sqrt(11)*S.asinh(S.sqrt(11*F/7))-S.sqrt((7+11*F)/F)
eq('nonconstant_q_coordinate_square',S.diff(chi,F)**2-1/(4*F**2*qv))
eq('coupling_recovered_from_coordinate',(S.diff(-S.log(F)/2,F)/S.diff(chi,F))**2-qv)
eq('coordinate_orientation_sign_independent',(-S.diff(chi,F))**2-S.diff(chi,F)**2)
eq('positive_q_derivative_identity',S.diff(qv,F)-7/(7+11*F)**2)
ck('positive_q_nonconstant',(7/(7+11*F)**2).is_positive)
ck('negative_omega_not_ghost',((1/S.Rational(1,2)-3)/2)<0 and (1/S.Rational(1,2))>0)
ck('zero_q_chart_excluded',not bool(S.Integer(0)>0))
eq('Q_and_G_tensor_normalization',1/(8*S.pi*F)-(Q/F)/(8*S.pi*Q))

# Potential inverse and homogeneous mode.
A=S.sqrt(Q/F);VE=A**4*V
eq('Einstein_stationarity_to_Jordan',S.diff(VE,F)/S.diff(A,F)+N*A**3)
eq('inverse_integrating_factor',S.diff(V/F**2,F)-N/(2*F**3))
offset=C*F**AMBIGUITY_POWER
eq('potential_homogeneous_kernel',2*F*S.diff(offset,F)-4*offset)
eq('Einstein_offset_constant',A**4*offset-C*Q**2)
eq('offset_changes_required_curvature',4*offset/F-4*C*F)
G=S.symbols('G',positive=True);VG=S.Function('VG')(G)
FG=1/(8*S.pi*G)
# Derive N after the F(G) substitution directly by chain rule.
Ng=2*FG*(S.diff(VG,G)/S.diff(FG,G))-4*VG
eq('G_inverse_sign_and_half',S.diff(G**2*VG,G)+Ng*G/2)

# Chain-rule Hessian at fixed particle density; no producer mass formula used.
Fchi=2*F*S.sqrt(q)
def Dc(e):return Fchi*S.diff(e,F)
rstar=S.symbols('rstar',positive=True)
rho_family=N
r_bg=rho_family*A**VOLUME_POWER
H0=Dc(Dc(VE+rstar*A)).subs(rstar,r_bg)
eq('fixed_particle_background_force',Dc(VE+rstar*A).subs(rstar,r_bg))
m0= S.simplify(A**FRAME_POWER*H0/(KINETIC_DIVISOR*Q))
eq('fixed_particle_mass_from_action',m0-q*(S.diff(rho_family,F)-3*rho_family/(2*F)))
p=S.symbols('p',real=True)
add=p*r_bg*Dc(A)**2/A
mpred=S.simplify(A**FRAME_POWER*(H0+add)/(KINETIC_DIVISOR*Q))
eq('general_p_mass_from_action',mpred-q*(S.diff(rho_family,F)+(p-3)*rho_family/(2*F)))
eq('fixed_physical_p3',mpred.subs(p,3)-q*S.diff(rho_family,F))
eq('source_control_increment',mpred-m0-p*q*rho_family/(2*F))
eq('physical_mass_frame_witness',(S.Rational(3,5)**FRAME_POWER)*S.Rational(11,7)-S.Rational(275,63))
eq('rho_control_physical_fraction',p*Dc(A)/A-3*Dc(A)/A-(p-3)*Dc(A)/A)

# Variable q derivative disappears only at a constant stationary background.
f0=S.Rational(7,6);VV=3*F**3-F+5*F**2*S.log(F)
NN=2*F*S.diff(VV,F)-4*VV;rho0=NN.subs(F,f0)
eq('variable_q_stationary_linearization',S.diff(qv*(NN-rho0),F).subs(F,f0)-(qv*S.diff(NN,F)).subs(F,f0))
ck('variable_q_term_off_stationarity_nonzero',S.simplify(S.diff(qv*(NN-rho0-1),F).subs(F,f0)-(qv*S.diff(NN,F)).subs(F,f0))!=0)

# Independent power-law examples; actual source coefficient and potential are retained.
rho_ref=S.Rational(11,7);Fref=S.Rational(3,2);power_results=[]
for n in [S.Integer(1),S.Integer(2),S.Integer(3),S.Rational(5,4),S.Rational(7,2)]:
    density=rho_ref*(F/Fref)**n
    part=rho_ref*F**n/(2*(n-2)*Fref**n) if n!=2 else rho_ref*F**2*S.log(F/Fref)/(2*Fref**2)
    val=10*F**2+INVERSE_SIGN*part
    eq('power_inverse_'+str(n),2*F*S.diff(val,F)-4*val-density)
    for pv in [-2,0,1,3,5]:
        particular=mpred.subs({V:val,q:qv,p:pv}).doit()
        eq('power_mass_'+str(n)+'_p'+str(pv),particular-qv*density/F*(n+S.Rational(pv-3,2)))
    testF=S.Rational(7,6);mass0=(qv*density/F*(n-S.Rational(3,2))).subs(F,testF);mass3=(qv*density*n/F).subs(F,testF)
    ck('power_mass3_positive_'+str(n),mass3>0)
    ck('power_mass0_sign_'+str(n),(mass0>0)==(n>S.Rational(3,2)))
    power_results.append({'n':str(n),'F':str(testF),'rho':str(S.N(density.subs(F,testF),24)),'m0':str(S.N(mass0,24)),'m3':str(S.N(mass3,24)),'B':str(1/n)})
eq('B_power_family',S.Rational(11,7)*F**S.Rational(5,4)/(F*S.diff(S.Rational(11,7)*F**S.Rational(5,4),F))-S.Rational(4,5))
ck('positive_m3_does_not_imply_B_bound',S.Rational(4,5)>S.Rational(2,3))
eq('constant_density_potential',2*F*S.diff(C*F**2-Rho/4,F)-4*(C*F**2-Rho/4)-Rho)
eq('constant_density_m3_zero',S.diff(Rho,F))
ck('constant_density_m0_negative',-3*qv*Rho/(2*F)<0)
rho_turn=3+(F-2)**2
eq('density_turning_point',S.diff(rho_turn,F).subs(F,2))
eq('two_F_same_rho',rho_turn.subs(F,1)-rho_turn.subs(F,3))
ck('same_rho_different_tensor_force',1/(8*S.pi)!=1/(24*S.pi))
ck('B_inverse_requires_nonzero_slope',S.diff(rho_turn,F).subs(F,2)==0)
eq('rolling_trace_derivative_bias',(trace_R*F-(Rho+4*V)).subs(T,-Rho)-(om*X/F+3*B))
ck('rolling_trace_bias_witness',((ov*X/F+3*B)/4).subs({F:S.Rational(5,3),X:-2,B:S.Rational(4,7)})!=0)

# Nonorthonormal several-field geometry.
K=S.Matrix([[2,1],[1,3]]);beta=S.Matrix([S.Rational(2,7),-S.Rational(1,5)]);scale=S.Rational(14,33)
E=K.cholesky().T.inv();qh=(beta.T*K.inv()*beta)[0];bh=E.T*beta
update=scale*(K.inv() if INCLUDE_K_INVERSE else S.eye(2))*beta*beta.T
for i in range(2):
 for j in range(2):
  eq(f'orthonormal_metric_{i}{j}',(E.T*K*E-S.eye(2))[i,j])
  eq(f'mass_basis_{i}{j}',(E.inv()*update*E-scale*bh*bh.T)[i,j])
eq('rank_one_trace',S.trace(update)-scale*qh)
eq('rank_one_determinant',update.det())
ck('covector_norm_positive',qh>0)
ck('mixed_mass_not_ordinary_symmetric',update!=update.T)

# Complete candidate: consistent truncation, canonicalization and density inverse.
u,x,y,k,nu,Hv=S.symbols('u x y k nu Hv',real=True,positive=True)
a=S.symbols('a',positive=True);s=S.symbols('s',positive=True);alpha=S.sqrt(a);EE=S.exp(2*alpha*u);DE=1+s*EE;J=1+(1-3*a)*s*EE
Dtr=1+2*(1+k)*(x*x+y*y)/3
Kuu=J/DE**2;Kxx=(1+s)*4*k/(9*DE*Dtr);Kyy=(1+s)*k/(3*DE*Dtr)
Ac=S.sqrt((1+s)*EE/DE)
U=S.Rational(3,2)+3*s*(EE-1)**2/(2*DE**2)+k*x*x*S.exp(-(1-k)*u/alpha)/2+k*y*y*S.exp(-(1+k)*u/alpha)/3+nu*(1+s)*u*u/(2*DE**2)
eq('candidate_transverse_connection_x',-S.diff(Kuu,x)/(2*Kxx))
eq('candidate_transverse_connection_y',-S.diff(Kuu,y)/(2*Kyy))
eq('candidate_transverse_force_x',S.diff(U,x).subs({x:0,y:0}))
eq('candidate_transverse_force_y',S.diff(U,y).subs({x:0,y:0}))
eq('candidate_matter_x',S.diff(Ac,x));eq('candidate_matter_y',S.diff(Ac,y))
eq('candidate_q',S.diff(S.log(Ac),u)**2/Kuu-a/J)
aval=(1-k)*(1+3*k)/4
eq('candidate_q_cap_gap',S.Rational(1,3)-aval-(1-3*k)**2/12)
FJ=Q/Ac**2
eq('candidate_F_coordinate_metric',Kuu/S.diff(FJ,u)**2-1/(4*FJ**2*(a/J)))
EofF=Q/((1+s)*F-s*Q);uofF=S.log(EofF)/(2*alpha)
eq('candidate_F_inverse',(Q*DE/((1+s)*EE)).subs(u,uofF)-F)
Uline=U.subs({x:0,y:0});VEu=2*Q*Hv**2*Uline
rho_u=-S.diff(VEu,u)/(S.diff(Ac,u)*Ac**3)
VJf=(VEu/Ac**4).subs(u,uofF)
eq('candidate_transformed_density_inverse',2*F*S.diff(VJf,F)-4*VJf-rho_u.subs(u,uofF))
z=S.symbols('z',positive=True);Dz=1+s-s*z*z;uz=-S.log(Dz/z**2)/(2*alpha)
Uz=Uline.subs(u,uz)
expectedUz=S.Rational(3,2)+3*s*(1-z*z)**2/2+nu*Dz**2*S.log(Dz/z**2)**2/(8*a*(1+s))
eq('candidate_U_from_original_action',Uz-expectedUz)
eq('candidate_physical_density_units',rho_u.subs(u,uz)+2*Q*Hv**2*S.diff(expectedUz,z)/z**3)
extra=(x*x+y*y)**2
eq('transverse_action_freedom_value',extra.subs({x:0,y:0}))
eq('transverse_action_freedom_u',S.diff(extra,u))
eq('transverse_action_freedom_Hessian',S.diff(extra,x,2).subs({x:0,y:0}))

# Independent high-precision integral for a mixed, non-power density.
fr=mp.mpf(5)/4;c=mp.mpf(17)
def dens(f):return 9*mp.sqrt(f)+6*f**mp.mpf('2.5')+10*f*f
def particular(f):return -3*mp.sqrt(f)+6*f**mp.mpf('2.5')+5*f*f*mp.log(f/fr)
vref=c*fr*fr+particular(fr)
numerical=[]
for text in ['2/3','7/6','11/5']:
 n,d=text.split('/');f=mp.mpf(n)/int(d)
 integ=mp.quad(lambda w:dens(w)/(2*w**3),[fr,f])
 predicted=f*f*(vref/(fr*fr)+INVERSE_SIGN*integ);actual=c*f*f+particular(f);err=abs(predicted-actual)
 ck('mixed_density_integral_'+text,err<mp.mpf('1e-65'),error=str(err))
 # A different integration variable G=1/(8piF) checks the inverse sign and normalization.
 gr=1/(8*mp.pi*fr);gg=1/(8*mp.pi*f)
 gint=mp.quad(lambda g:dens(1/(8*mp.pi*g))*g,[gr,gg])
 vg=(gr*gr*vref-INVERSE_SIGN*gint/2)/(gg*gg)
 ck('mixed_density_G_integral_'+text,abs(vg-actual)<mp.mpf('1e-65'),error=str(abs(vg-actual)))
 numerical.append({'F':text,'rho':mp.nstr(dens(f),40),'V_from_F_integral':mp.nstr(predicted,40),'V_from_G_integral':mp.nstr(vg,40),'analytic_V':mp.nstr(actual,40),'F_error':str(err),'G_error':str(abs(vg-actual))})
result={'scope':'Independent conditional action inverse and source-control mathematics; synthetic examples, no producer code/results or empirical fit','passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows,'power_examples':power_results,'mixed_density_quadrature':numerical,'metric_control':{'K':str(K),'beta_cov':str(beta),'q':str(qh),'mass_update':str(update)},'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'precision_digits':mp.mp.dps}
print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
