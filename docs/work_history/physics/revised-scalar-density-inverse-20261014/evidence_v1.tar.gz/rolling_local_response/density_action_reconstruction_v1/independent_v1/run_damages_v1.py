from pathlib import Path
import datetime,difflib,hashlib,json,subprocess
H=Path(__file__).resolve().parent;source=(H/'check_inverse_v1.py').read_text();out=H/'damages';out.mkdir(exist_ok=False)
cases=[
 ('boundary_sign','BOUNDARY_SIGN=1','BOUNDARY_SIGN=-1','Ricci_boundary_density'),
 ('variable_omega_sign','TRACE_OMEGA_SIGN=-1','TRACE_OMEGA_SIGN=1','direct_scalar_trace_elimination'),
 ('missing_kinetic_two','KINETIC_DIVISOR=2','KINETIC_DIVISOR=1','fixed_particle_mass_from_action'),
 ('wrong_physical_frame','FRAME_POWER=-2','FRAME_POWER=2','physical_mass_frame_witness'),
 ('wrong_particle_volume','VOLUME_POWER=3','VOLUME_POWER=4','fixed_particle_background_force'),
 ('wrong_potential_kernel','AMBIGUITY_POWER=2','AMBIGUITY_POWER=1','potential_homogeneous_kernel'),
 ('missing_metric_inverse','INCLUDE_K_INVERSE=1','INCLUDE_K_INVERSE=0','mass_basis_00'),
 ('inverse_source_sign','INVERSE_SIGN=1','INVERSE_SIGN=-1','power_inverse_1')
]
(H/'DAMAGE_PROTOCOL_v1.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_sha256':hashlib.sha256(source.encode()).hexdigest(),'before_damage_execution':True,'cases':[{'name':n,'old':a,'new':b,'required_failed_control':r} for n,a,b,r in cases]},indent=2)+'\n')
summary=[]
for name,old,new,required in cases:
    assert source.count(old)==1
    changed=source.replace(old,new);path=out/(name+'.py');path.write_text(changed);(out/(name+'.diff')).write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='check_inverse_v1.py',tofile=name+'.py')))
    argv=['/usr/local/bin/python3','-B',str(path)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=H,capture_output=True);end=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/(name+'_results.json')).write_bytes(r.stdout);(out/(name+'_stderr.txt')).write_bytes(r.stderr)
    result=json.loads(r.stdout);fails=[x['name'] for x in result['checks'] if not x['passed']]
    record={'argv':argv,'cwd':str(H),'started_utc':start,'completed_utc':end,'exit_code':r.returncode,'script_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'passed':result['passed'],'failed':result['failed'],'failed_controls':fails,'required_failed_control':required,'required_failure_observed':required in fails}
    (out/(name+'_run.json')).write_text(json.dumps(record,indent=2)+'\n');summary.append(record)
    assert r.returncode==1 and required in fails,(name,record)
(H/'DAMAGE_SUMMARY_v1.json').write_text(json.dumps({'baseline':'118/0','actual_one_edit_damages':summary},indent=2)+'\n')
print(json.dumps([{'name':n[0],'passed':r['passed'],'failed':r['failed'],'required_failed_control':r['required_failed_control']} for n,r in zip(cases,summary)],indent=2))
