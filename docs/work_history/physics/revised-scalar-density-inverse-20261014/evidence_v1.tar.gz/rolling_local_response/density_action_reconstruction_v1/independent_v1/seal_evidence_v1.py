from pathlib import Path
import hashlib,json,datetime
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.open('x').write(json.dumps(obj,indent=2)+'\n')
assert not (H/'MANIFEST_v1.json').exists()
assert not (H/'RECEIPT_v1.json').exists()
final=json.loads((H/'FINAL_VERIFICATION_v1.json').read_text())
assert final['passed']==123 and final['failed']==0
pairs=json.loads((H/'SOURCE_BINDINGS_FINAL_v1.json').read_text())['pairs']
for p in pairs:
 assert sha(Path(p['original_path']))==sha(H/p['snapshot_path'])==p['sha256']
base=json.loads((H/'BASELINE_RESULTS_v1.json').read_text())
dam=json.loads((H/'DAMAGE_SUMMARY_v1.json').read_text())
corr=json.loads((H/'source_correspondence_v2/RESULTS_v2.json').read_text())
assert base['passed']==118 and base['failed']==0 and len(dam['actual_one_edit_damages'])==8
assert corr['passed']==33 and corr['failed']==0 and not corr['new_science_execution']
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
art=[]
for p in sorted(H.rglob('*')):
 if p.is_file():
  assert not p.is_symlink()
  art.append({'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'unit':'density_action_reconstruction_v1/independent_v1','created_utc':at,'scope':'Frozen independent proof, controls, original failures and final-source correspondence; no formal audit','artifact_count':len(art),'artifacts':art,'excluded_self_and_receipt':['MANIFEST_v1.json','RECEIPT_v1.json'],'source_bindings':'SOURCE_BINDINGS_FINAL_v1.json'}
dump(H/'MANIFEST_v1.json',manifest)
receipt={'unit':'density_action_reconstruction_v1/independent_v1','reviewer':'/root/local_response_check','scientific_author':'/root','sealed_utc':at,'scope':'Focused independent conditional Jordan action inverse and source-control check; original-reviewer v2 confirmation','report':{'path':'REPORT_v1.md','sha256':sha(H/'REPORT_v1.md')},'manifest':{'path':'MANIFEST_v1.json','sha256':sha(H/'MANIFEST_v1.json'),'artifact_count':len(art)},'source_bindings':{'path':'SOURCE_BINDINGS_FINAL_v1.json','sha256':sha(H/'SOURCE_BINDINGS_FINAL_v1.json'),'count':len(pairs)},'source_pairs':pairs,'science':{'new_independent_baseline':{'passed':118,'failed':0,'result':'BASELINE_RESULTS_v1.json','sha256':sha(H/'BASELINE_RESULTS_v1.json')},'actual_damaged_copies':8,'damage_summary':{'path':'DAMAGE_SUMMARY_v1.json','sha256':sha(H/'DAMAGE_SUMMARY_v1.json')},'producer_code_or_results_accessed':False,'old_counts_relabelled_as_new':False,'new_empirical_inputs_or_fits':False},'correction_confirmation':{'original_source_sha256':'e87e3c31070092b955cc9bf9378e765f09e15e49e100e6ca68f5e8be51b1f4ba','final_source_sha256':'18b59326f5fa496653fb4df6f3faa70e7aabe8d914249ac402d1237abd82d732','original_reviewer_read_complete_v2_and_exact_diff':True,'findings':['B domain rho_J>0 and rho_J_prime!=0; undivided masses need neither division','K-orthonormal matrix convention and covariant/mixed-index general forms'],'source_coefficients_changed':False,'new_science_rerun':False,'metadata_passed':33,'metadata_failed':0,'evidence':'source_correspondence_v2/RESULTS_v2.json','evidence_sha256':sha(H/'source_correspondence_v2/RESULTS_v2.json')},'preserved_failures':{'path':'FAILURES_AND_CORRECTIONS_v1.json','sha256':sha(H/'FAILURES_AND_CORRECTIONS_v1.json'),'actual_metadata_failure':'source_correspondence_v2/RUN_v2.json','metadata_repair':'source_correspondence_v2/METADATA_REPAIR_v1.json','eight_intended_damage_failures_preserved':True},'final_identity_verification':{'passed':123,'failed':0,'path':'FINAL_VERIFICATION_v1.json','sha256':sha(H/'FINAL_VERIFICATION_v1.json')},'primary_pdf':{'path':'sources/Quiros_1506.05420v2.pdf','sha256':sha(H/'sources/Quiros_1506.05420v2.pdf'),'pages_read':[2,3],'visual_receipt':'PDF_VISUAL_READ_v1.json'},'limitations':['Ideal measured-input functions are not supplied','Local source law is imposed; no reservoir or full coupled apparatus spectrum','Single-field interval inverse retains one Einstein potential constant','No initial-state selection or unique transverse/off-interval action','No formal audit, authority/status change, or delivery verdict'],'prior_evidence_untouched':True,'writes_stop_after_seal':True}
dump(H/'RECEIPT_v1.json',receipt)
for p in art:
 f=H/p['path'];assert sha(f)==p['sha256'] and f.stat().st_size==p['bytes']
for p in pairs:assert sha(Path(p['original_path']))==sha(H/p['snapshot_path'])==p['sha256']
assert sha(H/'MANIFEST_v1.json')==receipt['manifest']['sha256']
assert sha(H/'REPORT_v1.md')==receipt['report']['sha256']
print(json.dumps({'sealed':True,'artifact_count':len(art),'source_pairs':len(pairs),'report':str(H/'REPORT_v1.md'),'report_sha256':sha(H/'REPORT_v1.md'),'manifest_sha256':sha(H/'MANIFEST_v1.json'),'receipt_sha256':sha(H/'RECEIPT_v1.json'),'science':'118/0','correspondence':'33/0','final_metadata':'123/0'},indent=2))

