from pathlib import Path
import datetime,difflib,hashlib,json,platform,sys
import sympy,mpmath,pypdf

H=Path(__file__).resolve().parent.parent
C=Path(__file__).resolve().parent
P=H.parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value): p.open('x').write(json.dumps(value,indent=2)+'\n')
rows=[]
def ck(name,passed,**data): rows.append(dict(name=name,passed=bool(passed),**data))
expected={
 'DERIVATION_v2.md':'18b59326f5fa496653fb4df6f3faa70e7aabe8d914249ac402d1237abd82d732',
 'SOURCE_CLARIFICATION_v2.json':'d1a346e1db21292ec8c65765129a7b4e2c7fca6b442c87f27a7d5bf08bb64d5a'}
(C/'sources').mkdir(exist_ok=True)
pairs=[]
for name in ['DERIVATION_v2.md','SOURCE_CLARIFICATION_v2.json','DERIVATION_v1_v2.diff']:
 p=P/name; dest=C/'sources'/name; data=p.read_bytes()
 assert dest.read_bytes()==data, 'preserved source drift'
 pairs.append(dict(original_path=str(p),snapshot_path=str(dest.relative_to(H)),sha256=sha(dest),bytes=len(data),role='narrow original-reviewer correction correspondence'))
 if name in expected: ck('expected_hash_'+name,sha(dest)==expected[name])
old=(H/'sources/DERIVATION_v1.md').read_text()
new=(C/'sources/DERIVATION_v2.md').read_text()
old_basis="This expression also holds for several fields when this scalar proportional-response law is stipulated. It is a local source prescription; actual material dynamics could be frequency dependent, nonlocal or tensorial and must be derived separately. It does not establish a pressure-supported or self-gravitating source."
new_basis="For several fields this formula is written in a K-orthonormal field frame, with beta_a=e_a^A partial_A ln A and M^2 the corresponding mass matrix. In general field coordinates the covariant Hessian shift is p c_rho beta_A beta_B, while the mass endomorphism shift is p c_rho K^{AC} beta_C beta_B. With that basis convention, the expression holds when the scalar proportional-response law is stipulated. It is a local source prescription; actual material dynamics could be frequency dependent, nonlocal or tensorial and must be derived separately. It does not establish a pressure-supported or self-gravitating source."
old_domain="Writing B=-d ln G/d ln rho_J=rho_J/(F rho_J'), the reconstruction yields"
new_domain="On a positive-density portion with rho_J'(F)!=0, the local inverse and logarithmic derivative are defined, giving B=-d ln G/d ln rho_J=rho_J/(F rho_J'). The mass formulas below do not require division by rho_J or rho_J'; they remain algebraic identities at zero or turning densities wherever the underlying stationary family is smooth. The reconstruction yields"
ck('original_v1_frozen_hash',sha(H/'sources/DERIVATION_v1.md')=='e87e3c31070092b955cc9bf9378e765f09e15e49e100e6ca68f5e8be51b1f4ba')
ck('original_v1_live_unchanged',sha(P/'DERIVATION_v1.md')==sha(H/'sources/DERIVATION_v1.md'))
ck('two_exact_original_paragraphs',old.count(old_basis)==1 and old.count(old_domain)==1)
ck('only_two_qualified_paragraphs_changed',old.replace(old_basis,new_basis).replace(old_domain,new_domain)==new)
delta=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='DERIVATION_v1.md',tofile='DERIVATION_v2.md'))
assert (C/'INDEPENDENT_v1_v2.diff').read_text()==delta, 'preserved diff drift'
ck('author_diff_exactly_reproduced',delta==(C/'sources/DERIVATION_v1_v2.diff').read_text())
base=json.loads((H/'BASELINE_RESULTS_v1.json').read_text())
by_name={r['name']:r for r in base['checks']}
ck('original_independent_results_118_0',base['passed']==118 and base['failed']==0)
ck('original_independent_code_unchanged',sha(H/'check_inverse_v1.py')==base['code_sha256'])
for name in ['constant_density_potential','constant_density_m3_zero','density_turning_point','two_F_same_rho','B_inverse_requires_nonzero_slope','orthonormal_metric_00','mass_basis_00','mass_basis_01','mass_basis_10','mass_basis_11','rank_one_trace','mixed_mass_not_ordinary_symmetric']:
 ck('reuse_'+name,by_name[name]['passed'],new_science_execution=False)
damage=json.loads((H/'DAMAGE_SUMMARY_v1.json').read_text())['actual_one_edit_damages']
ck('missing_metric_inverse_actual_damage_rejected',any(r['required_failed_control']=='mass_basis_00' and r['required_failure_observed'] and r['exit_code']==1 for r in damage))
clar=json.loads((C/'sources/SOURCE_CLARIFICATION_v2.json').read_text())
ck('clarification_source_hashes',clar['original_sha256']==sha(H/'sources/DERIVATION_v1.md') and clar['final_sha256']==sha(C/'sources/DERIVATION_v2.md'))
ck('unchanged_equations_statement',clar['equations_changed'] is False)
original=json.loads((H/'SOURCE_BINDINGS_v1.json').read_text())
original_pairs=original['source_pairs']
for pair in original_pairs+pairs:
 live=Path(pair['original_path']);snap=H/pair['snapshot_path']
 ck('live_snapshot_'+pair['snapshot_path'],sha(live)==sha(snap)==pair['sha256'] and live.stat().st_size==pair['bytes'])
combined={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_bindings_file':'SOURCE_BINDINGS_v1.json','original_source_preserved':True,'pairs':original_pairs+pairs}
write(H/'SOURCE_BINDINGS_FINAL_v1.json',combined)
write(H/'ENVIRONMENT_v1.json',{'python_executable':sys.executable,'python':sys.version,'platform':platform.platform(),'sympy':sympy.__version__,'mpmath':mpmath.__version__,'pypdf':pypdf.__version__,'new_science_run_for_this_metadata':False})
result={'scope':'Narrow exact final-source correspondence; original 118/0 reused, not rerun','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows,'source_pairs':pairs,'original_reviewer_confirmation':{'reviewer':'/root/local_response_check','read_complete_v2':True,'read_exact_diff':True,'corrected_inverse_domain':'rho_J>0 and rho_J_prime!=0 for B; undivided mass identities remain','corrected_mass_basis':'K-orthonormal frame or explicit covariant/mixed-index tensors','equations_or_coefficients_changed':False,'no_additional_coefficient_or_sign_issue_found':True},'producer_code_or_results_accessed':False,'original_science_results_reused':{'path':'BASELINE_RESULTS_v1.json','sha256':sha(H/'BASELINE_RESULTS_v1.json'),'passed':118,'failed':0},'new_science_execution':False}
write(C/'RESULTS_v2.json',result)
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'source_pairs':len(combined['pairs'])},indent=2))
raise SystemExit(bool(result['failed']))

