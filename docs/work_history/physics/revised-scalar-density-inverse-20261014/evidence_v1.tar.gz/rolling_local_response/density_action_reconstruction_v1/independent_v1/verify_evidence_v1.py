from pathlib import Path
import hashlib,json,difflib,struct,datetime
H=Path(__file__).resolve().parent
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(name,test,**data):rows.append(dict(name=name,passed=bool(test),**data))
j=json.loads((H/'SOURCE_BINDINGS_FINAL_v1.json').read_text())
ck('nine_source_pairs',len(j['pairs'])==9)
for i,p in enumerate(j['pairs']):
 s=H/p['snapshot_path'];live=Path(p['original_path'])
 ck(f'source_{i}_snapshot',sha(s)==p['sha256'] and s.stat().st_size==p['bytes'])
 ck(f'source_{i}_live',sha(live)==p['sha256'] and live.stat().st_size==p['bytes'])
base=json.loads((H/'BASELINE_RESULTS_v1.json').read_text())
r=json.loads((H/'BASELINE_RUN_v1.json').read_text())
ck('baseline_118_0',base['passed']==118 and base['failed']==0 and len(base['checks'])==118 and all(v['passed'] for v in base['checks']))
ck('baseline_exit_zero',r['exit_code']==0)
ck('baseline_code_hash',sha(H/'check_inverse_v1.py')==r['script_sha256']==base['code_sha256'])
ck('baseline_stdout_hash',sha(H/'BASELINE_RESULTS_v1.json')==r['stdout_sha256'])
ck('baseline_stderr_hash',sha(H/'BASELINE_stderr_v1.txt')==r['stderr_sha256'])
bind=json.loads((H/'HAND_IMPLEMENTATION_BINDINGS_v1.json').read_text())
for f in bind['files']:ck('hand_binding_'+f['path'],sha(H/f['path'])==f['sha256'] and (H/f['path']).stat().st_size==f['bytes'])
ck('hand_before_code_before_run',bind['files'][0]['mtime_ns']<bind['files'][2]['mtime_ns'] and datetime.datetime.fromisoformat(bind['at'])<datetime.datetime.fromisoformat(r['started_utc']))
source=(H/'check_inverse_v1.py').read_text()
dp=json.loads((H/'DAMAGE_PROTOCOL_v1.json').read_text())
dam=json.loads((H/'DAMAGE_SUMMARY_v1.json').read_text())['actual_one_edit_damages']
ck('eight_actual_damage_cases',len(dp['cases'])==len(dam)==8)
for case,record in zip(dp['cases'],dam):
 n=case['name'];p=H/'damages'/f'{n}.py';rr=json.loads((H/'damages'/f'{n}_run.json').read_text());res=json.loads((H/'damages'/f'{n}_results.json').read_text())
 ck(n+'_run_exact',record==rr)
 ck(n+'_one_actual_edit',source.count(case['old'])==1 and p.read_text()==source.replace(case['old'],case['new']))
 actual_diff=''.join(difflib.unified_diff(source.splitlines(True),p.read_text().splitlines(True),fromfile='check_inverse_v1.py',tofile=n+'.py'))
 ck(n+'_diff',actual_diff==(H/'damages'/f'{n}.diff').read_text())
 ck(n+'_code_hash',sha(p)==record['script_sha256']==res['code_sha256'])
 ck(n+'_stdout_hash',sha(H/'damages'/f'{n}_results.json')==record['stdout_sha256'])
 ck(n+'_stderr_hash',sha(H/'damages'/f'{n}_stderr.txt')==record['stderr_sha256'])
 fails=[v['name'] for v in res['checks'] if not v['passed']]
 ck(n+'_actual_rejection',record['exit_code']==1 and record['failed_controls']==fails and case['required_failed_control'] in fails)
 ck(n+'_counts',res['failed']==record['failed']==len(fails) and res['passed']+res['failed']==118 and len(res['checks'])==118)
 ck(n+'_protocol_before_execution',datetime.datetime.fromisoformat(dp['created_utc'])<datetime.datetime.fromisoformat(record['started_utc']))
C=H/'source_correspondence_v2'
corr=json.loads((C/'RESULTS_v2.json').read_text())
ck('correspondence_33_0',corr['passed']==33 and corr['failed']==0 and all(v['passed'] for v in corr['checks']))
ck('same_original_reviewer',corr['original_reviewer_confirmation']['reviewer']=='/root/local_response_check' and corr['original_reviewer_confirmation']['read_complete_v2'])
ck('no_science_rerun_for_correction',corr['new_science_execution'] is False and corr['original_science_results_reused']['sha256']==sha(H/'BASELINE_RESULTS_v1.json'))
for stem,script in [('v2','check_correspondence_v2.py'),('v2_retry','check_correspondence_v2_retry.py')]:
 rr=json.loads((C/('RUN_'+stem+'.json')).read_text())
 ck('corr_script_'+stem,sha(C/script)==rr['script_sha256'])
 ck('corr_stdout_'+stem,sha(C/('stdout_'+stem+'.txt'))==rr['stdout_sha256'])
 ck('corr_stderr_'+stem,sha(C/('stderr_'+stem+'.txt'))==rr['stderr_sha256'])
 ck('corr_actual_exit_'+stem,rr['exit_code']==(1 if stem=='v2' else 0))
ck('real_metadata_failure_retained',"KeyError: 'pairs'" in (C/'stderr_v2.txt').read_text())
old=(C/'check_correspondence_v2.py').read_text();new=(C/'check_correspondence_v2_retry.py').read_text()
ck('metadata_repair_diff_exact',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='check_correspondence_v2.py',tofile='check_correspondence_v2_retry.py'))==(C/'METADATA_REPAIR_v1.diff').read_text())
pdf=json.loads((H/'PDF_READ_RENDER_v1.json').read_text())
ck('primary_pdf_hash',sha(H/'sources/Quiros_1506.05420v2.pdf')==pdf['pdf_sha256'])
ck('primary_pdf_extracted_text_hash',sha(H/'pdf_pages/pages_2_3.txt')==pdf['text_sha256'])
ck('primary_pdf_render_exit',pdf['exit_code']==0)
for page in ('02','03'):
 p=H/'pdf_pages'/('Quiros-'+page+'.png');data=p.read_bytes()
 ck('rendered_png_'+page,data[:8]==b'\x89PNG\r\n\x1a\n' and min(struct.unpack('>II',data[16:24]))>800)
cmds=json.loads((H/'COMMANDS_v1.json').read_text())
ck('exact_command_ledger',len(cmds['commands'])>=12 and all((x.get('command') or x.get('cmd')) and x.get('cwd') for x in cmds['commands']))
for name in ('REPORT_v1.md','HAND_DERIVATION_v1.md','source_correspondence_v2/REPORT_v2.md'):
 ck('nonempty_report_'+name,(H/name).stat().st_size>1000)
result={'scope':'Final metadata/evidence identity verification only; no science rerun','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(v['passed'] for v in rows),'failed':sum(not v['passed'] for v in rows),'checks':rows}
print(json.dumps(result,indent=2))
raise SystemExit(bool(result['failed']))

