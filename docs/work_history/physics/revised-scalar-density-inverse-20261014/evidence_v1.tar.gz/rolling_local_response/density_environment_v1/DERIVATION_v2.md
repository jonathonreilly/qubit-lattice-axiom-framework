# Matter density determines a conditional stationary relation, not a realized environment

Direct scientific author /root. Hand derivation frozen before its checker.
The observed-gravity problem requires a local field and scalar mass around a
material apparatus. Earlier response bounds froze that environment. This block
asks what the supplied action itself determines when nonrelativistic matter is
included. No numerical laboratory density, chosen vacuum energy, source profile,
relaxation rate or measured likelihood is supplied as an answer.

## The density held fixed matters

Let A=sqrt(C), 0<k<1/3, nu>0, Q>0, Hv>0, and retain the complete supplied
three-field action. For nonrelativistic particles of fixed Jordan rest mass,
S_particles=-sum m_J integral A(phi) ds_E. At fixed particle number per Einstein
coordinate volume, define rho_*=m_J n_E. Its local matter energy is rho_E=A rho_*,
while rho_J=rho_*/A^3. The scalar source in the exact variation is b rho_E/(2Q).
Consequently, at prescribed rho_* and neglecting gradients and time derivatives,
stationarity is that of

    W(phi)=U(phi)+delta_* A(phi),  delta_*=rho_*/(2Q Hv^2).       (1)

This factor follows from the action's -Q K(partial phi)^2 normalization. A
stationary point is a conditional algebraic solution, not a proof that a real
body, gravity and a pressure-supported density profile reach or sustain it.
Radiation pressure, self-gravity and nonlocal matching are outside this reduction.

For x=y=0, transverse stationarity is automatic, and transverse potential
second derivatives are k exp(-lambda_x u) and (2k/3)exp(-lambda_y u), both positive.
Because A is independent of x,y, it adds no transverse source. At a full stationary
point the field-space covariant Hessian equals the coordinate Hessian. Mixed
entries vanish at x=y=0. Thus the remaining homogeneous stability question is
one dimensional, with positive field metric.

The fixed-particle-density convention agrees with the effective-potential
construction in Khoury and Weltman, Chameleon Cosmology, arXiv:astro-ph/0309411v2,
page5 equations(7)-(10), https://arxiv.org/pdf/astro-ph/0309411. That paper is a
convention cross-check, not evidence that this different candidate screens or
fits an experiment. Its old phenomenological claims are not adopted here.

## Exact physical-density map on the negative-u branch

Use z=A, D=1+s-s z^2, a=(1-k)(1+3k)/4 and s=(1+k)/(k(1-3k)).
For 0<z<1, corresponding precisely to u<0, put

    L=log(D/z^2)>0,
    U0(z)=3/2+(3/2)s(1-z^2)^2+nu D^2 L^2/[8a(1+s)].           (2)

Here u=-L/(2sqrt(a)) and z_u=sqrt(a) z/F>0 with F=(1+s)/D.
Differentiation, using L_z=-2(1+s)/(z D), gives

    d_*(z)=-U0_z
      =6s z(1-z^2)
       +nu D/[2a(1+s)] [s z L^2+(1+s)L/z] >0.                (3)

At a stationary point delta_*=d_*(z). If instead a measured positive physical
density rho_J is specified, define delta_J=rho_J/(2Q Hv^2). Since delta_*=z^3 delta_J,
the same stationary equation becomes

    delta_J=d_J(z)=d_*(z)/z^3
      =6s(z^-2-1)
       +nu D/[2a(1+s)] [s L^2/z^2+(1+s)L/z^4].               (4)

Every positive factor D,L,z^-2,z^-4 strictly decreases on 0<z<1. Their positive
products decrease, and the first term has strictly negative derivative. Hence
d_J'(z)<0. The endpoint limits are d_J(0+)=infinity and d_J(1-)=0. Thus every
specified positive physical density and fixed candidate parameters has exactly
one negative-u stationary solution. This derives a conditional relation; it does
not choose k,nu,Hv,Q or the density, and says nothing about extra u>=0 solutions.

The distinction is operational: changing z at fixed particle density changes
physical volume and rho_J. Holding rho_J fixed instead requires changing the
particle distribution or applying external constraints. One cannot replace the
linearized fixed-particle Hessian by differentiating while artificially holding
rho_J constant. At stationarity,

    U0_zz=-z^3 d_J'(z)-3 z^2 d_J(z),                         (5)

so d_J'<0 alone does not imply U0_zz>0.

## A fixed-particle density need not select one stable branch

An explicit allowed synthetic counterexample will use

    k=1/10, nu=1/10000, delta_*=20.                          (6)

Here s=110/7 and a=117/400. For z->0+, the positive nu term makes d_*(z)->infinity.
At z=1, d_*=0. At z=1/2 the first term alone is 9s/4>20. At z=1/10,
D/z^2=11590/7<exp(8): for instance exp(1)>8/3 by its positive series, and
(8/3)^8>11590/7. Thus 0<L<8. Substituting L<8 in the positive nu term gives an
explicit rational upper bound for d_*(1/10) below20. Therefore W_z=20-d_*(z)
has signs negative, positive, negative, positive as z runs from0 through1/10,
1/2 and1. By continuity and interior extrema on the three intervening intervals,
there are at least two distinct radial local minima separated by a radial local
maximum. In the full three-field potential that radial maximum is a saddle,
since both transverse curvatures are positive; the radial minima are full local
minima.
The function is analytic inside this domain; these sign-separated extrema are
strict. Numerical roots, Hessians and depths are supporting checks to follow,
not the proof of their existence. We do not assert these are all stationary
points, or that their physical densities agree. A prescription to choose the
lowest energy does not prove that a dissipating or gravitational body reaches it.

The counterexample targets universal uniqueness at fixed particle data. It does
not contradict the unique negative-u root at fixed measured rho_J: the different
stationary z values in (6) correspond to different physical densities20/z^3.
No observed theory exclusion is inferred from this synthetic example.

## Local mass and the remaining boundary problem

With prescribed rho_*, dimensionless canonical radial coordinate dchi=sqrt(K_uu)du
has kinetic term -Q(partial chi)^2. In a weak nearly flat static domain,

    Laplacian_E chi=Hv^2 W_chi.

At a stationary point,

    m_E^2/Hv^2=W_uu/K_uu=(z_u)^2 U0_zz/K_uu,
    m_J^2=m_E^2/z^2,  m_J^2/Hv^2=(a/J) U0_zz=q U0_zz.       (7)

The matter term is linear in z, so W_zz=U0_zz when delta_* is fixed. Positive
m_E^2 is a local scalar condition under these external-source assumptions; it
is not full gravitating-fluid stability. The finite-body Yukawa bounds need a
stable background and sufficient separation of scales, which (7) can test but
cannot assume. A finite body still requires a density prescription, center and
exterior boundary conditions, and control of gradients, pressure, relaxation
and metric errors. The action supplies this boundary equation, not its solution
or its observed normalization. The selected field state and apparatus bridge
remain open even though (4) removes an algebraic branch ambiguity in its domain.
