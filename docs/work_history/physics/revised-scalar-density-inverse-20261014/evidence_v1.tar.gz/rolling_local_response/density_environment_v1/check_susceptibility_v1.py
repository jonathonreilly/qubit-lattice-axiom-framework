from pathlib import Path
import json,hashlib,sys
import sympy as S
import mpmath as mp
mp.mp.dps=80
rows=[]
def ck(n,v,detail=None):rows.append(dict(name=n,passed=bool(v),detail=detail))
def eq(n,v):
 r=S.factor(S.together(S.expand(v)));ck(n,r==0,str(r))
z,s,a,nu,q=S.symbols('z s a nu q',positive=True);D=1+s-s*z*z;L=S.log(D/z**2)
U=S.Rational(3,2)+S.Rational(3,2)*s*(1-z*z)**2+nu*D**2*L**2/(8*a*(1+s))
dj=6*s*(z**-2-1)+nu*D/(2*a*(1+s))*(s*L**2/z**2+(1+s)*L/z**4)
slope=-z*S.diff(dj,z)/dj
stable_threshold=3
mass_formula=q*z*z*dj*(slope-stable_threshold)
eq('mass_slope_identity',mass_formula-q*S.diff(U,z,2))
eq('density_slope_definition',slope*dj+z*S.diff(dj,z))
eq('stationary_log_susceptibility',(-1/slope)*(z*S.diff(dj,z))-dj)
eq('weighted_density_decomposition',z*z*dj-(6*s*(1-z*z)+nu*D/(2*a*(1+s))*(s*L**2+(1+s)*L/z**2)))
Dz=-2*s*z;Lz=-2*(1+s)/(z*D)
negative_terms=-12*s*z+nu/(2*a*(1+s))*(Dz*(s*L**2+(1+s)*L/z**2)+D*(2*s*L*Lz+(1+s)*(Lz/z**2-2*L/z**3)))
eq('weighted_density_strict_derivative',S.diff(z*z*dj,z)-negative_terms)
eq('slope_above_two_identity',z*S.diff(z*z*dj,z)-z*z*dj*(2-slope))
eq('near_vacuum_density_derivative',S.diff(dj,z).subs(z,1)+12*s+nu*(1+s)/a)
lead=nu*(1+s)*L/(2*a*z**4)
ratio_decomp=D/(1+s)+D*s*z*z*L/(1+s)**2+12*a*s*z*z*(1-z*z)/(nu*(1+s)*L)
eq('small_A_density_leading_decomposition',dj/lead-ratio_decomp)
# These elementary limits control the subleading terms and their derivatives.
t=S.symbols('t',positive=True)
ck('elementary_log_power_limit',S.limit(z*z*S.log(z),z,0,dir='+')==0)
ck('elementary_inverse_log_power_limit',S.limit(z*z/S.log(z),z,0,dir='+')==0)
ck('constant_density_leading_D',S.limit(D/(1+s),z,0,dir='+')==1)
f=S.lambdify((z,s,a,nu),slope,'mpmath');fd=S.lambdify((z,s,a,nu),dj,'mpmath')
p=Path(__file__).parent;prior=json.loads((p/'RESULTS_v1.json').read_text());ss=mp.mpf(110)/7;aa=mp.mpf(117)/400;nn=mp.mpf(1)/10000
root_rows=[]
for r in prior['roots']:
 zz=mp.mpf(r['z']);dd=fd(zz,ss,aa,nn);sl=f(zz,ss,aa,nn);qq=mp.mpf(r['q']);mm=qq*zz*zz*dd*(sl-stable_threshold);expected=mp.mpf(r['mJ2_over_Hv2'])
 ck('saved_root_mass_'+str(r['index']),abs(mm-expected)/(1+abs(expected))<mp.mpf('1e-37'))
 ck('saved_root_susceptibility_range_'+str(r['index']),-mp.mpf('.5') < -1/sl <0)
 ck('saved_root_stability_equivalence_'+str(r['index']),(sl>3)==(expected>0))
 root_rows.append(dict(index=r['index'],S_env=mp.nstr(sl,40),stationary_log_susceptibility=mp.nstr(-1/sl,40)))
small=[];near=[]
for zz in [mp.mpf('1e-4'),mp.mpf('1e-6'),mp.mpf('1e-9'),mp.mpf('1e-12')]:
 sl=f(zz,ss,aa,nn);ll=mp.log((1+ss-ss*zz*zz)/zz**2);ld=nn*(1+ss)*ll/(2*aa*zz**4);ratio=fd(zz,ss,aa,nn)/ld
 ck('small_A_slope_bound_'+str(zz),sl>4 and sl<mp.mpf('4.2'))
 ck('small_A_density_leading_'+str(zz),abs(ratio-1)<mp.mpf('1e-5'))
 small.append(dict(A=str(zz),S_env=mp.nstr(sl,40),density_over_leading=mp.nstr(ratio,40)))
for eps in [mp.mpf('1e-3'),mp.mpf('1e-5'),mp.mpf('1e-7')]:
 zz=1-eps;sl=f(zz,ss,aa,nn);ratio=fd(zz,ss,aa,nn)/(eps*(12*ss+nn*(1+ss)/aa))
 ck('near_vacuum_positive_mass_slope_'+str(eps),sl>3)
 ck('near_vacuum_first_order_'+str(eps),abs(ratio-1)<2*eps)
 near.append(dict(one_minus_A=str(eps),S_env=mp.nstr(sl,40),density_over_linear=mp.nstr(ratio,40)))
ck('small_A_slope_approaches_four',all(abs(mp.mpf(small[i+1]['S_env'])-4)<abs(mp.mpf(small[i]['S_env'])-4) for i in range(len(small)-1)))
out=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,root_diagnostics=root_rows,small_A_controls=small,near_vacuum_controls=near,prior_results_sha256=hashlib.sha256((p/'RESULTS_v1.json').read_bytes()).hexdigest(),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Conditional stationary family derivative and prescribed-particle scalar mass; saved roots reused without solving again; no dynamic tracking or observed calibration.')
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2));raise SystemExit(bool(out['failed']))
