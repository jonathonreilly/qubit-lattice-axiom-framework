from pathlib import Path
import json,hashlib,sys
import sympy as S
import mpmath as mp
from scipy.optimize import brentq
mp.mp.dps=80
checks=[]
def ck(name,ok,**data):
 checks.append(dict(name=name,passed=bool(ok),**data))
def eq(name,expr):
 v=S.factor(S.together(S.expand(expr)))
 ck(name,v==0,residual=str(v))
z,s,a,nu,ds,Q,H,rj=S.symbols('z s a nu ds Q H rj',positive=True)
D=1+s-s*z*z;L=S.log(D/z**2)
U=S.Rational(3,2)+S.Rational(3,2)*s*(1-z*z)**2+nu*D**2*L**2/(8*a*(1+s))
dstar=6*s*z*(1-z*z)+nu*D/(2*a*(1+s))*(s*z*L**2+(1+s)*L/z)
dj=dstar/z**3
particle_power=1
source_factor=S.Integer(1)
W=U+source_factor*ds*z**particle_power
fixed_density_hessian=S.diff(U,z,2)+3*ds/z
physical_mass_power=2
# Vary actual energy from -sum m A ds_E and the supplied -2QH^2U action.
actual_energy=2*Q*H**2*U+(2*Q*H**2*ds)*z
eq('source_from_actual_particle_and_scalar_energy',S.diff(actual_energy,z)/(2*Q*H**2)-S.diff(W,z))
eq('closed_negative_potential_derivative',S.diff(U,z)+dstar)
eq('physical_density_A_cubed',dj*z**3-dstar)
eq('fixed_particle_stationarity',S.diff(W,z)-(ds-dstar))
eq('physical_density_force_from_trace',rj*z**4/z-rj*z**3)
eq('fixed_particle_hessian',S.diff(W,z,2)-fixed_density_hessian)
eq('density_map_derivative_hessian',fixed_density_hessian+z**3*S.diff(dj,z)+3*z**2*dj)
eq('log_derivative',S.diff(L,z)+2*(1+s)/(z*D))
eq('D_derivative',S.diff(D,z)+2*s*z)
eq('first_monotone_term_derivative',S.diff(6*s*(z**-2-1),z)+12*s/z**3)
# Derivative of each positive product is a sum of negative terms on 0<z<1.
Lz=-2*(1+s)/(z*D);Dz=-2*s*z
term1prime=Dz*L**2/z**2+2*D*L*Lz/z**2-2*D*L**2/z**3
term2prime=Dz*L/z**4+D*Lz/z**4-4*D*L/z**5
eq('first_product_monotonic_decomposition',S.diff(D*L**2/z**2,z)-term1prime)
eq('second_product_monotonic_decomposition',S.diff(D*L/z**4,z)-term2prime)
eq('full_physical_density_monotonic_decomposition',S.diff(dj,z)-(-12*s/z**3+nu*(s*term1prime+(1+s)*term2prime)/(2*a*(1+s))))
eq('endpoint_dstar_one',dstar.subs(z,1))
eq('endpoint_dj_one',dj.subs(z,1))
# Independent exact sign brackets; no decimal logarithm establishes existence.
kr=S.Rational(1,10);sr=S.Rational(110,7);ar=S.Rational(117,400);nr=S.Rational(1,10000)
eq('candidate_a',ar-(1-kr)*(1+3*kr)/4)
eq('candidate_s',sr-(1+kr)/(kr*(1-3*kr)))
zlo=S.Rational(1,10);Dlo=D.subs({z:zlo,s:sr});ratio=S.factor(Dlo/zlo**2)
eq('bracket_log_argument',ratio-S.Rational(11590,7))
ck('exp_one_lower_bound',sum(S.Rational(1,S.factorial(i)) for i in range(5))>S.Rational(8,3))
ck('exp_eight_lower_bound',(S.Rational(8,3))**8>ratio)
upper=(6*s*z*(1-z*z)+nu*D/(2*a*(1+s))*(s*z*64+(1+s)*8/z)).subs({z:zlo,s:sr,a:ar,nu:nr})
ck('dstar_tenth_less_than_twenty',upper<20,exact_upper=str(upper),upper=float(upper))
ck('dstar_half_greater_than_twenty',S.Rational(9,4)*sr>20,exact_lower=str(S.Rational(9,4)*sr))
# Full three-field stationary mass uses K>0 and zero full gradient.
K,zu,mp2=S.symbols('K zu mp2',positive=True)
predicted_mj=mp2/z**physical_mass_power
eq('physical_mass_frame_conversion',predicted_mj*z**2-mp2)
eq('stationary_coordinate_hessian_mass',zu**2*fixed_density_hessian/K-zu**2*S.diff(W,z,2)/K)
# Parameter/grid evaluations only check implementations of the analytic signs.
fn=S.lambdify((z,s,a,nu),dstar,'mpmath');fj=S.lambdify((z,s,a,nu),dj,'mpmath');fjp=S.lambdify((z,s,a,nu),S.diff(dj,z),'mpmath')
fU=S.lambdify((z,s,a,nu),U,'mpmath');fU2=S.lambdify((z,s,a,nu),S.diff(U,z,2),'mpmath')
srmp=mp.mpf(110)/7;armp=mp.mpf(117)/400;nrmp=mp.mpf(1)/10000
rows=[]
for kv in ['0.01','0.1','0.3']:
 k=mp.mpf(kv);sv=(1+k)/(k*(1-3*k));av=(1-k)*(1+3*k)/4
 for nv in ['0.0001','1','100']:
  for zv in ['0.00001','0.01','0.1','0.5','0.9','0.999']:
   zz=mp.mpf(zv);nn=mp.mpf(nv);dv=fj(zz,sv,av,nn);der=fjp(zz,sv,av,nn)
   ck('density_positive_and_decreasing_'+kv+'_'+nv+'_'+zv,dv>0 and der<0)
   rows.append(dict(k=kv,nu=nv,z=zv,dj=mp.nstr(dv,40),dj_prime=mp.nstr(der,40)))
def bisect(lo,hi):
 fl=fn(lo,srmp,armp,nrmp)-20;fh=fn(hi,srmp,armp,nrmp)-20
 assert fl*fh<0
 for _ in range(300):
  mid=(lo+hi)/2;fm=fn(mid,srmp,armp,nrmp)-20
  if abs(fm)<mp.mpf('1e-65'):return mid
  if fl*fm<0:hi=mid;fh=fm
  else:lo=mid;fl=fm
 return (lo+hi)/2
roots=[]
for i,(lo,hi,sign) in enumerate([('0.000001','0.1',1),('0.1','0.5',-1),('0.5','0.999999',1)]):
 zz=bisect(mp.mpf(lo),mp.mpf(hi));res=fn(zz,srmp,armp,nrmp)-20;hess=fU2(zz,srmp,armp,nrmp)
 zz_double=brentq(lambda q:float(fn(mp.mpf(q),srmp,armp,nrmp))-20,float(lo),float(hi),xtol=1e-15,rtol=1e-14)
 dd=1+srmp-srmp*zz*zz;ll=mp.log(dd/zz**2);uu=-ll/(2*mp.sqrt(armp));ee=zz*zz/dd;FF=1+srmp*ee;JJ=1+(1-3*armp)*srmp*ee;kuu=JJ/FF**2;zz_u=mp.sqrt(armp)*zz/FF
 mass=zz_u**2*hess/kuu;massj=mass/zz**physical_mass_power;djv=20/zz**3;qq=armp/JJ;mu=zz**2*(1+qq)/(1+mp.mpf('0.1'))
 ck('root_stationarity_'+str(i),abs(res)<mp.mpf('1e-60'),residual=mp.nstr(res,8))
 ck('root_local_hessian_sign_'+str(i),sign*hess>0)
 ck('independent_bracket_solver_'+str(i),abs(zz-mp.mpf(zz_double))<mp.mpf('2e-14'))
 ck('root_observed_density_map_'+str(i),abs(fj(zz,srmp,armp,nrmp)-djv)/djv<mp.mpf('1e-60'))
 # Check mass by varying the original u parametrization at fixed particle density.
 def orig(uv):
  ev=mp.exp(2*mp.sqrt(armp)*uv);fv=1+srmp*ev;cv=(1+srmp)*ev/fv
  return mp.mpf('1.5')+mp.mpf('1.5')*srmp*(ev-1)**2/fv**2+nrmp*(1+srmp)*uv**2/(2*fv**2)+20*mp.sqrt(cv)
 mh=mp.diff(orig,uu,2)/kuu
 ck('original_u_mass_'+str(i),abs(mh-mass)/(1+abs(mass))<mp.mpf('1e-60'))
 roots.append(dict(index=i,z=mp.nstr(zz,60),u=mp.nstr(uu,40),delta_j=mp.nstr(djv,40),Uzz=mp.nstr(hess,40),mE2_over_Hv2=mp.nstr(mass,40),mJ2_over_Hv2=mp.nstr(massj,40),W=mp.nstr(fU(zz,srmp,armp,nrmp)+20*zz,40),q=mp.nstr(qq,40),principal_G_over_vacuum=mp.nstr(mu,40)))
ck('distinct_physical_densities',len(set(r['delta_j'] for r in roots))==3)
ck('two_positive_one_negative_local_masses',all(float(r['mE2_over_Hv2'])*sg>0 for r,sg in zip(roots,[1,-1,1])))
ck('stability_not_implied_by_monotone_density',float(roots[1]['Uzz'])<0 and fjp(mp.mpf(roots[1]['z']),srmp,armp,nrmp)<0)
out=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),passed=sum(c['passed'] for c in checks),failed=sum(not c['passed'] for c in checks),checks=checks,exact_upper_at_tenth=str(upper),grid=rows,roots=roots,scope='Conditional mathematics and synthetic branches; no measured fit or full body stability; original action and parameters supplied.')
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(bool(out['failed']))
