# Independent derivation before executable controls

This hand reconstruction uses only the supplied complete action, the author's frozen DERIVATION_v1 and PROTOCOL_v1, and the published convention reference. No producer code or result has been read. The following derivation precedes the independent mathematical checker. `/root` remains the scientific author.

## Variation and the fixed-density prescription

With signature (-+++), the scalar action is -Q K_AB partial phi^A partial phi^B-2Q Hv^2 U. Its variation, after integrating by parts, is 2Q[K_AB D_box phi^B-Hv^2 U_A]. For g_J=A^2 g_E and b_A=partial_A ln A, the matter variation is sqrt(-g_E) b_A T_E delta phi^A. Thus

    D_box phi^A = Hv^2 U^A - b^A T_E/(2Q).

For prescribed nonrelativistic rest particles T_E=-rho_E. The static local equation has a positive b^A rho_E/(2Q) on its right side. The homogeneous time equation has the corresponding negative force. There is no missing factor 2: the kinetic coefficient is -Q, not -Q/2.

The particle action is -m_J integral A ds_E. At fixed Einstein metric and particle positions/number, the Einstein rest energy is m_J A. If n_E denotes number per local Einstein proper three-volume, rho_*=m_J n_E is independent of scalar variation, rho_E=A rho_*, and dV_J=A^3 dV_E gives rho_J=rho_*/A^3. A coordinate-volume description is equivalent only after holding its Einstein metric volume factor fixed; it is not a new coordinate-invariant conserved physical density. In a cosmological evolution conserved particle number would give rho_* proportional to a_E^-3, not a time-constant arbitrary rho_*.

Consequently the scalar stationary equation at fixed prescribed rho_* is grad W=0 for W=U+delta_* A, delta_*=rho_*/(2Q Hv^2). The positive sign follows directly from the particle energy. This is an external-source local reduction, not a self-consistent static gravitating dust solution. Pressure, velocity, particle rearrangement and support must be supplied before promoting it to material equilibrium.

## Transforming the actual action into A

Use z=A and denote the new denominator by Delta=1+s-s z^2 to avoid collision with the original transverse metric denominator. From z^2=(1+s)E/(1+sE),

    E=z^2/Delta, F=(1+s)/Delta,
    L=ln(Delta/z^2), u=-L/(2sqrt(a)),
    z_u=sqrt(a)z/F, L_z=-2(1+s)/(z Delta).

Because z_u>0 and z(0)=1, 0<z<1 is exactly u<0. On this branch Delta>0 and L>0. The original potential on x=y=0 becomes

    U0=3/2+(3s/2)(1-z^2)^2+nu Delta^2 L^2/[8a(1+s)].

Differentiating this expression, rather than differentiating a proposed density map, gives

    -U0_z=6s z(1-z^2)
      +nu Delta/[2a(1+s)] [s z L^2+(1+s)L/z]=d_*(z)>0.

The stationary equation is delta_*=d_*. For fixed measured physical density, delta_*=z^3 delta_J, so the same algebraic condition reads delta_J=d_*/z^3=d_J(z). Every factor Delta,L,z^-2,z^-4 is positive and strictly decreasing on (0,1). Both products in the nu contribution to d_J therefore decrease; the vacuum contribution has derivative -12s/z^3<0. Hence d_J'<0 for every allowed k,nu. At z->1 it tends to zero; at z->0 its vacuum term alone tends to infinity. Continuity and strict monotonicity prove precisely one negative-u root for each fixed positive delta_J.

This does not solve a finite-body field equation or choose a density. It also does not establish uniqueness for fixed rho_*, because different equilibria then have different rho_J. Holding rho_J fixed under perturbation is a distinct external feedback prescription. In that prescription the scalar residual is U0_z+delta_J z^3, with derivative U0_zz+3delta_J z^2 at stationarity. By contrast the fixed-particle residual derivative is U0_zz. Equivalently,

    U0_zz=-z^3 d_J'-3z^2 d_J.

The artificial fixed-rho_J derivative -z^3 d_J' is positive, but this does not determine the sign of the correct fixed-particle curvature.

## Sign-separated extrema and exact controls to be executed

For k=1/10, nu=1/10000, delta_*=20, s=110/7 and a=117/400. At z=1/2, the vacuum part of d_* is 9s/4=495/14>20. At z=1/10, Delta/z^2=11590/7. The positive exponential series gives exp(1)>1+1+1/2+1/6=8/3; the rational inequality (8/3)^8>11590/7 therefore gives 0<L<8. Replacing L by 8 in each positive term yields a rational strict upper bound for d_*(1/10), to be evaluated independently. The vacuum part is 3267/350, already below 20.

At z->0 the nu term behaves as nu(1+s)L/(2a z), which diverges positively; nu>0 is essential for this left-end divergence. At z=1, d_*=0. Thus W_z=20-d_* is negative near zero, positive at 1/10, negative at 1/2, and positive near 1. On each consecutive interval, the boundary derivative signs put an extremum in its interior. W is analytic and nonconstant, so an interior minimum/maximum selected this way is strict: a constant plateau or accumulating equal stationary levels would contradict local analyticity.

This proves at least two strict radial minima separated by a radial maximum, not an enumeration of every stationary root. The intermediate extremum is a full three-field saddle, not a three-dimensional maximum. The transverse additions are positive coefficients times x^2 and y^2, so the two strict radial minima are strict minima of the full prescribed-particle potential even if a radial second derivative happened to vanish. Positive Hessian eigenvalues for particular numerical roots are a stronger local diagnostic to be checked, not needed for that existence proof.

A distinct independent example will use k=1/8, nu=1/20000, delta_*=18. It has s=72/5, a=77/256, the same three bracket intervals, and Delta(1/10)/(1/10)^2=7628/5<(8/3)^8. Its half-point vacuum value is 162/5>18. The same exact upper-bound construction applies. Root searches will use bracketed bisection, not root guesses from any producer output. The source example and this distinct example are synthetic development only.

## Full Hessian and physical mass

At x=y=0 the mixed coordinate entries vanish. The total W gradient vanishes at equilibrium, so its covariant Hessian equals its coordinate Hessian there. This statement applies to W, not separately to U and A: the connection terms in their Hessians cancel using U_u+delta_* A_u=0. The transverse coordinate curvatures are U_xx=k exp(-lambda_x u)>0 and U_yy=(2k/3)exp(-lambda_y u)>0. There is no transverse coordinate source from A.

For dchi=sqrt(K_uu)du, the kinetic term is -Q(partial chi)^2; the conventionally normalized field is sqrt(2Q)chi. Either normalization gives m_E^2=Hv^2 W_uu/K_uu at equilibrium. Since W_z=0, W_uu=z_u^2 U0_zz. With K_uu=J/F^2 this simplifies to

    m_E^2/Hv^2=(a z^2/J) U0_zz,
    m_J^2/Hv^2=(a/J) U0_zz.

The second equation follows from r_J=z r_E at a constant background: Laplacian_E=z^2 Laplacian_J. It is not m_J=z m_E. It does not calibrate Hv in physical units. A rolling background, coupled fluid, gravitational constraints, body matching or nonlinear state transitions require more equations.

The proposed exact stationary formulas and existence argument therefore appear correct within their stated scope. No density-dependent mass calculation by itself shows relaxation, a realized stable apparatus, screening or state selection. Numerical depths cannot justify choosing a global energy minimum as a dynamically realized state without a specified preparation/dissipation problem.
