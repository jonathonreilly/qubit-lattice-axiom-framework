# Independent susceptibility derivation before addendum code

The original independent baseline is already frozen at 146/0. The author's new short addendum is a coherent algebraic extension; its producer implementation/results remain unread. No original root computation will be repeated.

Let d(z)=d_J(z)>0 on 0<z<1. Multiplying its independently derived expression by z^2 gives

    z^2 d=6s(1-z^2)+nu/[2a(1+s)]
             {s Delta L^2+(1+s)Delta L z^-2}.

Delta, L and z^-2 are positive decreasing factors. The first derivative is -12s z<0; every product derivative is negative. Thus 2zd+z^2d'<0 and S=-zd'/d>2. The stationary inverse map obeys d ln z/d ln rho_J=d/(z d')=-1/S, holding all action parameters and physical units fixed. This is not a time response law.

The previous exact identity Uzz=-z^3 d'-3z^2 d immediately gives Uzz=z^2d(S-3). The independently derived physical mass is q Uzz, q=a/J>0. Therefore m_J^2/Hv^2=q z^2 delta_J(S-3) at a stationary point. Positive radial squared mass is equivalent to S>3, equivalently -1/3<d ln z/d ln rho_J<0. S=3 establishes zero quadratic mass only; higher derivatives and other degrees of freedom determine any nonlinear conclusion.

At z->0 with fixed nu>0, the term nu(1+s)L/(2a z^4) dominates d, with L=ln[(1+s-sz^2)/z^2]. For the derivative limit one must also control the remainder, rather than differentiate an arbitrary asymptotic equivalent. The exact formula consists of powers of z times L or L^2; z^r L^j tends to zero for r>0 and fixed j. Together with z L'->-2 this gives S=4+2/L+o(1/L), hence S->4 and the inverse slope ->-1/4. This limit is not uniform as nu->0. At nu=0 exactly, d=6s(z^-2-1) and S=2/(1-z^2)->2.

At z->1, L=2(1+s)(1-z)+O((1-z)^2). Substitution gives

    d=[12s+nu(1+s)/a](1-z)+O((1-z)^2).

The coefficient is strictly positive. Thus (1-z)S->1, S->+infinity, and the inverse logarithmic slope tends to zero from below. These limits concern boundary asymptotics of a stationary algebraic branch; they provide no path through a chart boundary or a dynamically tracked solution.

Addendum controls will independently check the exact decreasing-product decomposition, inverse-slope and mass identities, both endpoint coefficients/limits, the nu=0 outside-premise limit, and S/mass consistency at the six existing independent root values. Saved roots have 55-digit serialization and will be used with a compatible numerical tolerance, not treated as exact numbers. Two actual one-edit addendum damage executions will replace the mass threshold 3 by 2 and reverse the inverse-slope sign. Baseline root solves will not be replayed.
