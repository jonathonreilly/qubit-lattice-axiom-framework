from pathlib import Path
import datetime as dt
import hashlib
import json

u=Path(__file__).resolve().parent
def ref(name):
 b=(u/name).read_bytes();return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(name):return json.loads((u/name).read_text())
def write(name,data):
 p=u/name;assert not p.exists();p.write_text(json.dumps(data,indent=2)+'\n')

sources=[]
for name in ['SOURCE_BINDINGS_v1.json','SOURCE_BINDINGS_v2_ADDENDUM.json','SOURCE_BINDINGS_v3_ADDENDUM.json','SUSCEPTIBILITY_SOURCE_BINDINGS_v1.json']:
 for row in load(name)['sources']:
  row=dict(row)
  if 'CHECKER' in row['original_path']:
   row['role']='unintended metadata-only copied producer diff after main/addendum science; not a mathematical input'
  else:row.setdefault('role','frozen author source, protocol or source clarification')
  sources.append(row)
write('CONSOLIDATED_SOURCE_BINDINGS_v1.json',dict(sources=sources,source_pairs=len(sources),intended_pairs=11,unintended_contextual_pairs=1))

main=load('DAMAGE_RESULTS_v1.json');addon=load('SUSCEPTIBILITY_DAMAGE_RESULTS_v1.json')
write('FAILURES_v1.json',dict(
 unexpected_mathematical_or_execution_failures=[],
 source_findings=[
  dict(kind='Radial versus full-field extremum scope',original='DERIVATION_v1.md',resolution='v2 explicitly labels the radial maximum as a full-field saddle and adds the already equivalent q Uzz mass expression.',equations_replaced=False),
  dict(kind='Proper versus coordinate particle-number density',original='DERIVATION_v1.md and v2',resolution='v3 explicitly uses local Einstein proper three-volume with metric fixed in scalar variation. The exact non-unit-volume counterwitness remains in SOURCE_CORRESPONDENCE_RESULTS.',equations_replaced=False)],
 actual_main_damages=main['results'],actual_addendum_damages=addon['results'],
 access_incident=ref('ACCESS_INCIDENT_v1.json'),
 parent_reported_context=dict(inspected=False,used_for_independent_science=False,
   report='Parent reported an initial Python SSL retrieval failure, later symbolic-normalization stall with no result, and a 34/1 finite-asymptotic-tolerance failure. These are parent development history only, not this checker\'s runs.'),
 recovery='All actual independent versions, failed damaged outputs, source versions, clarifications and copied metadata remain present. No failed science run is relabeled clean.'))

write('PDF_VISUAL_CONFIRMATION_v1.json',dict(
 inspected_page=5,source=ref('sources/Khoury_Weltman_0309411v2.pdf'),
 rendered_page=ref('Khoury_Weltman_page5_v1.png'),extracted_text=ref('Khoury_Weltman_page5_v1.txt'),
 confirmation='Visible equations 7-10 and the preceding density definition use a scalar-independent particle-density convention and an effective-potential Hessian in the weak Minkowski regime. Candidate normalization was derived separately from its own action.',
 primary_url='https://arxiv.org/pdf/astro-ph/0309411v2',phenomenological_claims_imported=False))
proofs=[]
for hand,script in [('HAND_DERIVATION_v1.md','check_density_v1.py'),('SUSCEPTIBILITY_HAND_v1.md','check_susceptibility_v1.py')]:
 proofs.append(dict(hand=ref(hand),code=ref(script),hand_mtime_ns=(u/hand).stat().st_mtime_ns,
                    code_mtime_ns=(u/script).stat().st_mtime_ns,hand_precedes_code=(u/hand).stat().st_mtime_ns<(u/script).stat().st_mtime_ns))
write('HAND_PROOF_BINDINGS_v1.json',dict(proofs=proofs,initial_explicit_freeze=ref('HAND_PROTOCOL_FREEZE_v1.json'),
  scope='Current hashes and local creation order supplement the preserved pre-execution tool sequence; no claim of external timestamp authority.'))

commands=[]
for path in sorted(u.glob('*_COMMAND_v1.json')):
 commands.append(dict(record=ref(path.name),content=load(path.name)))
write('COMMANDS_v1.json',dict(commands=commands,primary_access=ref('PRIMARY_ACCESS_v1.json'),
  source_freeze_records=[ref(n) for n in ['SOURCE_BINDINGS_v1.json','SOURCE_BINDINGS_v2_ADDENDUM.json','SOURCE_BINDINGS_v3_ADDENDUM.json','SUSCEPTIBILITY_SOURCE_BINDINGS_v1.json']],
  producer_execution_count=0,standalone_new_main_runs=1,standalone_new_addendum_runs=1,actual_damaged_runs=8,
  source_correspondence_runs=1,primary_retrieval_TLS_disabled=False))
print(json.dumps(dict(sources=len(sources),actual_damaged_runs=8,command_records=len(commands),at=dt.datetime.now(dt.timezone.utc).isoformat())))
