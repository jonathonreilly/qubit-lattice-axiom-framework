from pathlib import Path
from fractions import Fraction as F
import hashlib
import json
import sys

u=Path(__file__).resolve().parent
s=u/'sources'
rows=[]
def ck(name,value,detail=None):rows.append(dict(name=name,passed=bool(value),detail=detail))
v1=(s/'DERIVATION_v1.md').read_text();v2=(s/'DERIVATION_v2.md').read_text();v3=(s/'DERIVATION_v3.md').read_text()
old='there are at least two distinct local minima separated by a local maximum.\n'
new=('there are at least two distinct radial local minima separated by a radial local\n'
     'maximum. In the full three-field potential that radial maximum is a saddle,\n'
     'since both transverse curvatures are positive; the radial minima are full local\nminima.\n')
oldmass='    m_J^2=m_E^2/z^2.                                       (7)'
newmass='    m_J^2=m_E^2/z^2,  m_J^2/Hv^2=(a/J) U0_zz=q U0_zz.       (7)'
ck('v1_v2_only_two_declared_clarifications',v1.replace(old,new,1).replace(oldmass,newmass,1)==v2)
oldproper=('S_particles=-sum m_J integral A(phi) ds_E. At fixed particle number per Einstein\n'
 'coordinate volume, define rho_*=m_J n_E. Its local matter energy is rho_E=A rho_*,\n')
newproper=('S_particles=-sum m_J integral A(phi) ds_E. At fixed particle number per local Einstein proper three-volume, define\n'
 'rho_*=m_J n_E, holding the Einstein metric fixed in the scalar variation. A\n'
 'literal coordinate number density must be divided by the spatial proper-volume\n'
 'factor; locally orthonormal coordinates give the same number at the event. Its local matter energy is rho_E=A rho_*,\n')
ck('v2_v3_only_proper_volume_clarification',v2.replace(oldproper,newproper,1)==v3)
ck('final_v3_expected_hash',hashlib.sha256(v3.encode()).hexdigest()=='0a56a10391b21c30d7d4cff8950ae3d4c2b0d2075050a3430f56b29a0ff381c2')
ck('v2_v3_all_display_equations_unchanged',[x for x in v2.splitlines() if x.startswith('    ')]==[x for x in v3.splitlines() if x.startswith('    ')])

# Exact local coordinate-volume witness for the required definition.
# h_E=diag(4,9,16): dV_E=24 d^3x. n_coord=24, m_J=2, A=1/2.
volume=F(24);ncoord=F(24);mass=F(2);A=F(1,2)
nproper=ncoord/volume;rho_star=mass*nproper
rhoE=mass*A*ncoord/volume
rhoJ=mass*ncoord/(A**3*volume)
ck('proper_density_particle_energy_identity',rhoE==A*rho_star==1)
ck('proper_density_Jordan_volume_identity',rhoJ==rho_star/A**3==16)
ck('coordinate_density_naive_formula_counterexample',A*(mass*ncoord)!=rhoE,{'wrong_E_density':str(A*mass*ncoord),'correct_E_density':str(rhoE),'factor':str(volume)})

all_sources=[]
for name in ['SOURCE_BINDINGS_v1.json','SOURCE_BINDINGS_v2_ADDENDUM.json','SOURCE_BINDINGS_v3_ADDENDUM.json','SUSCEPTIBILITY_SOURCE_BINDINGS_v1.json']:
    all_sources.extend(json.loads((u/name).read_text())['sources'])
for r in all_sources:
    live=Path(r['original_path']).read_bytes();snap=(u/r['snapshot_path']).read_bytes()
    ck('source_binding::'+r['snapshot_path'],live==snap and len(live)==r['bytes'] and hashlib.sha256(live).hexdigest()==r['sha256'])
pdf=u/'sources/Khoury_Weltman_0309411v2.pdf'
ck('published_PDF_identity',hashlib.sha256(pdf.read_bytes()).hexdigest()=='4c36136350da8104942c34f459aa926aafbdc1ca4bcc12968dd96ebcc97cb406')
ck('published_page_five_render_exists',(u/'Khoury_Weltman_page5_v1.png').stat().st_size>10000)
incident=json.loads((u/'ACCESS_INCIDENT_v1.json').read_text())
science_names=['baseline_COMMAND_v1.json','susceptibility_COMMAND_v1.json']
science_names += [x.name for x in u.glob('damage_*_COMMAND_v1.json')]
ck('all_science_executions_precede_unintended_byte_copy',all(json.loads((u/name).read_text())['finished_at']<incident['freeze_timestamp'] for name in science_names))
ck('all_expected_science_commands_present',len(science_names)==10)
result=dict(scope='Narrow source-version correspondence, one exact density-convention witness, and identity/access-order checks. No original science replay.',
    passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,source_pairs=len(all_sources))
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failures=[r for r in rows if not r['passed']]),indent=2))
raise SystemExit(bool(result['failed']))
