"""Independent short extension; reads own saved roots, never producer data."""
from pathlib import Path
import hashlib
import json
import sys
import sympy as sp
import mpmath as mp

MASS_THRESHOLD = 3
INVERSE_SIGN = -1

unit=Path(__file__).resolve().parent
if unit.name=='damages':unit=unit.parent
mp.mp.dps=80
rows=[]
def ck(name,value,detail=None):rows.append(dict(name=name,passed=bool(value),detail=detail))
def eq(name,expr):
    r=sp.factor(sp.cancel(sp.together(expr)));ck(name,r==0,str(r))
def near(name,value,scale=1):ck(name,abs(value)<mp.mpf('1e-48')*max(1,abs(scale)),mp.nstr(value,30))
z,a,s,nu=sp.symbols('z a s nu',positive=True)
D=1+s-s*z**2;L=sp.log(D/z**2)
U=sp.Rational(3,2)+sp.Rational(3,2)*s*(1-z**2)**2+nu*D**2*L**2/(8*a*(1+s))
d=-sp.diff(U,z)/z**3
J=1+(1-3*a)*s*z*z/D;q=a/J
Senv=-z*sp.diff(d,z)/d
weighted=6*s*(1-z*z)+nu*D/(2*a*(1+s))*(s*L*L+(1+s)*L/z**2)
eq('weighted_density_from_action',z*z*d-weighted)
negative_sum=12*s*z+nu/(2*a*(1+s))*(
    s*(2*s*z*L*L+2*D*L*2*(1+s)/(z*D))
    +(1+s)*(2*s*z*L/z**2+D*2*(1+s)/(z*D)/z**2+2*D*L/z**3))
eq('strict_weighted_negative_derivative',-sp.diff(z*z*d,z)-negative_sum)
eq('S_greater_two_equivalence',Senv-2+sp.diff(z*z*d,z)/(z*d))
slope=INVERSE_SIGN/Senv
eq('implicit_stationary_inverse_slope',slope-d/(z*sp.diff(d,z)))
mass=q*z*z*d*(Senv-MASS_THRESHOLD)
eq('mass_susceptibility_threshold',mass-q*sp.diff(U,z,2))
eq('radial_zero_mass_threshold',(q*z*z*d*(sp.Symbol('S')-MASS_THRESHOLD)).subs(sp.Symbol('S'),3))

left_ratio=sp.factor(d/(nu*(1+s)*L/(2*a*z**4)))
eq('left_density_asymptotic_ratio',sp.limit(left_ratio,z,0,dir='+')-1)
eq('left_S_limit',sp.limit(Senv,z,0,dir='+')-4)
eq('left_slope_limit',sp.limit(slope,z,0,dir='+')+sp.Rational(1,4))
rightcoef=12*s+nu*(1+s)/a
eq('right_density_first_order_coefficient',sp.limit(d/(1-z),z,1,dir='-')-rightcoef)
eq('right_S_scaled_limit',sp.limit((1-z)*Senv,z,1,dir='-')-1)
eq('right_slope_limit',sp.limit(slope,z,1,dir='-'))
eq('nu_zero_density',d.subs(nu,0)-6*s*(z**-2-1))
eq('nu_zero_S',sp.factor(Senv.subs(nu,0))-2/(1-z*z))
eq('nu_zero_left_S_limit',sp.limit(Senv.subs(nu,0),z,0,dir='+')-2)

baseline=json.loads((unit/'BASELINE_RESULTS_v1.json').read_text())
numeric=[]
for case in baseline['numeric']:
    kn=mp.mpf(case['k'].split('/')[0])/mp.mpf(case['k'].split('/')[1])
    nv=mp.mpf(case['nu'].split('/')[0])/mp.mpf(case['nu'].split('/')[1])
    an=(1-kn)*(1+3*kn)/4;sn=(1+kn)/(kn*(1-3*kn))
    def Ufun(v):
        de=1+sn-sn*v*v;ell=mp.log(de/v**2)
        return mp.mpf('1.5')+mp.mpf('1.5')*sn*(1-v*v)**2+nv*de*de*ell*ell/(8*an*(1+sn))
    def density(v):return -mp.diff(Ufun,v)/v**3
    def slope_measure(v):return -v*mp.diff(density,v)/density(v)
    for root in case['roots']:
        zz=mp.mpf(root['z']);dd=density(zz);ss=slope_measure(zz)
        jj=1+(1-3*an)*sn*zz*zz/(1+sn-sn*zz*zz);qq=an/jj
        predicted=qq*zz*zz*dd*(ss-MASS_THRESHOLD)
        idx=root['index'];label=case['label']+'::'+str(idx)
        ck(label+'::S_gt_two',ss>2)
        ck(label+'::S_stability_domain',ss>3 if idx!=1 else 2<ss<3)
        ck(label+'::inverse_slope_interval',mp.mpf('-.5')<INVERSE_SIGN/ss<0)
        near(label+'::saved_mass_agreement',predicted-mp.mpf(root['mJ2_over_Hv2']),predicted)
        near(label+'::saved_density_agreement',dd-mp.mpf(root['delta_J']),dd)
        numeric.append(dict(label=label,z=root['z'],S_env=mp.nstr(ss,50),stationary_log_slope=mp.nstr(INVERSE_SIGN/ss,50),
                            mJ2_over_Hv2=mp.nstr(predicted,50),saved_root_only=True))
    small=[mp.mpf('1e-6'),mp.mpf('1e-12'),mp.mpf('1e-30')]
    ss=[slope_measure(v) for v in small]
    ck(case['label']+'::finite_left_approach',ss[0]>ss[1]>ss[2]>4 and ss[-1]-4<mp.mpf('.02'),[mp.nstr(x,30) for x in ss])
    h=mp.mpf('1e-12');sr=slope_measure(1-h)
    ck(case['label']+'::finite_right_scaled_limit',abs(h*sr-1)<mp.mpf('1e-8'),mp.nstr(h*sr,30))

result=dict(scope='Independent susceptibility algebra and reuse of six own saved roots; no root rerun or producer access.',
    passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,numeric=numeric,
    saved_baseline_sha256=hashlib.sha256((unit/'BASELINE_RESULTS_v1.json').read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),precision=mp.mp.dps)
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
if result['failed']:print(json.dumps([r for r in rows if not r['passed']],indent=2))
raise SystemExit(bool(result['failed']))
