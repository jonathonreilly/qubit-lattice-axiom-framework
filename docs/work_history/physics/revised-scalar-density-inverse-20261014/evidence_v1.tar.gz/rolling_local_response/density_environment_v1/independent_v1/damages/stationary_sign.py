"""Independent action reconstruction; no producer import or data access."""
from pathlib import Path
import hashlib
import json
import platform
import sys
import mpmath as mp
import sympy as sp

SOURCE_DIVISOR = 2
MATTER_POWER = 1
DENSITY_POWER = 3
STATIONARY_SIGN = -1
HESSIAN_EXTRA = 0
PHYSICAL_MASS_POWER = -2

mp.mp.dps=80
rows=[]
def ck(name,value,detail=None):
    rows.append(dict(name=name,passed=bool(value),detail=detail))
def eq(name,expr):
    val=sp.factor(sp.cancel(sp.together(expr)))
    ck(name,val==0,str(val))
def near(name,value,scale=1):
    ck(name,abs(value)<mp.mpf('1e-60')*max(1,abs(scale)),mp.nstr(value,30))
def ms(v):return mp.nstr(v,55)

z,a,s,nu,E,u,Q,Hv,rstar,dj=sp.symbols('z a s nu E u Q Hv rho_star delta_J',positive=True)
delta=sp.symbols('delta_star',positive=True)
D=1+s-s*z**2
L=sp.log(D/z**2)
F_E=1+s*E
J_E=1+(1-3*a)*s*E
U_action=sp.Rational(3,2)+3*s*(E-1)**2/(2*F_E**2)+nu*(1+s)*u**2/(2*F_E**2)
U_reconstructed=sp.factor(U_action.subs({E:z**2/D,u:-L/(2*sp.sqrt(a))}))
U=sp.Rational(3,2)+sp.Rational(3,2)*s*(1-z**2)**2+nu*D**2*L**2/(8*a*(1+s))
eq('action_to_A_potential',U_reconstructed-U)
eq('invert_conformal_relation',(1+s)*(z**2/D)/(1+s*z**2/D)-z**2)
eq('F_in_A_coordinate',(1+s*z**2/D)-(1+s)/D)
eq('log_derivative',sp.diff(L,z)+2*(1+s)/(z*D))
eq('u_z_inverse_z_u',sp.diff(-L/(2*sp.sqrt(a)),z)*(sp.sqrt(a)*z*D/(1+s))-1)

# Independently varied point-particle energy and the actual kinetic factor.
particle_energy=rstar*z
source_from_variation=sp.diff(particle_energy,z)/(2*Q)
source_implemented=rstar/(SOURCE_DIVISOR*Q)
eq('particle_source_normalization',source_implemented-source_from_variation)
W=U+sp.Rational(2,SOURCE_DIVISOR)*delta*z**MATTER_POWER
eq('effective_energy_from_particle_action',2*Q*Hv**2*(W-U).subs(delta,rstar/(2*Q*Hv**2))-particle_energy)
eq('stationary_source_gradient',sp.diff(W-U,z)-delta)
rhoJ=rstar/z**DENSITY_POWER
eq('physical_particle_number_volume',rhoJ*z**3-rstar)
eq('stress_density_transform',rstar*z-z**4*rhoJ)

dstar=STATIONARY_SIGN*(6*s*z*(1-z**2)+nu*D/(2*a*(1+s))*(s*z*L**2+(1+s)*L/z))
dphysical=dstar/z**DENSITY_POWER
eq('stationary_density_from_actual_potential',dstar+sp.diff(U_reconstructed,z))
eq('physical_stationary_density_from_trace',dphysical+sp.diff(U_reconstructed,z)/z**3)
eq('particle_physical_stationarity_agreement',(sp.diff(U,z)+delta).subs(delta,z**3*dj)-z**3*(dj-dphysical))
eq('Hessian_density_derivative_identity',sp.diff(U,z,2)+z**3*sp.diff(dphysical,z)+3*z**2*dphysical)

minus_Dprime=2*s*z
minus_Lprime=2*(1+s)/(z*D)
positive_derivative_sum=12*s/z**3+nu/(2*a*(1+s))*(
    s*(minus_Dprime*L**2/z**2+2*D*L*minus_Lprime/z**2+2*D*L**2/z**3)
    +(1+s)*(minus_Dprime*L/z**4+D*minus_Lprime/z**4+4*D*L/z**5))
eq('monotone_map_positive_sum',-sp.diff(dphysical,z)-positive_derivative_sum)
eq('strict_vacuum_derivative',-sp.diff(6*s*(z**-2-1),z)-12*s/z**3)
eq('D_prime_negative_factor',-sp.diff(D,z)-minus_Dprime)
eq('L_prime_negative_factor',-sp.diff(L,z)-minus_Lprime)
eq('inverse_square_prime',-sp.diff(z**-2,z)-2/z**3)
eq('inverse_fourth_prime',-sp.diff(z**-4,z)-4/z**5)
eq('right_endpoint_density',dphysical.subs(z,1))
eq('right_endpoint_particle_density',dstar.subs(z,1))
eq('left_particle_asymptotic',sp.limit(dstar/(nu*(1+s)*L/(2*a*z)),z,0,dir='+')-1)
ck('vacuum_physical_density_left_limit',sp.limit(6*s*(z**-2-1),z,0,dir='+')==sp.oo)

J=sp.factor(J_E.subs(E,z**2/D));F=(1+s)/D
zu=sp.sqrt(a)*z/F
Kuu=J/F**2
eq('radial_kinetic_coordinate_factor',zu**2/Kuu-a*z**2/J)
curvature_claim=sp.diff(U,z,2)+HESSIAN_EXTRA*3*dstar/z
massE=zu**2*curvature_claim/Kuu
massJ=massE*z**PHYSICAL_MASS_POWER
eq('fixed_particle_hessian',curvature_claim-sp.diff(U_reconstructed,z,2))
eq('physical_mass_coordinate_conversion',massJ-a*sp.diff(U_reconstructed,z,2)/J)
eq('physical_wavelength_conversion',massJ*z**2-massE)
eq('external_physical_density_curvature',sp.diff(U,z,2)+3*dphysical*z**2+z**3*sp.diff(dphysical,z))
eq('stationary_full_gradient_chain_rule',sp.diff(W,z,2)*zu**2-sp.diff(U,z,2)*zu**2)

# Full-field Hessian and connection cancellation, using actual action functions.
x,y,lamx,lamy=sp.symbols('x y lambda_x lambda_y',real=True)
Ut=U_action+sp.Symbol('k',positive=True)*x*x*sp.exp(-lamx*u)/2+sp.Symbol('k',positive=True)*y*y*sp.exp(-lamy*u)/3
ks=sp.Symbol('k',positive=True)
eq('transverse_x_curvature',sp.diff(Ut,x,2)-ks*sp.exp(-lamx*u))
eq('transverse_y_curvature',sp.diff(Ut,y,2)-2*ks*sp.exp(-lamy*u)/3)
eq('mixed_ux_zero',sp.diff(Ut,u,x).subs({x:0,y:0}))
eq('mixed_uy_zero',sp.diff(Ut,u,y).subs({x:0,y:0}))
eq('mixed_xy_zero',sp.diff(Ut,x,y))
Ug,Ag,Gamma,Uxx=sp.symbols('U_u A_u Gamma U_xx',real=True)
cov_total=Uxx-Gamma*Ug-delta*Gamma*Ag
eq('connection_cancels_only_for_total_stationary_W',cov_total.subs(Ug,-delta*Ag)-Uxx)
ck('connection_not_discardable_for_U_alone',sp.expand((Uxx-Gamma*Ug).subs(Ug,-delta*Ag)-Uxx)!=0)

k=sp.symbols('k',positive=True)
ak=(1-k)*(1+3*k)/4
sk=(1+k)/(k*(1-3*k))
eq('subcritical_metric_identity',1-3*ak-(1-3*k)**2/4)

brackets=[]
examples=[('source',sp.Rational(1,10),sp.Rational(1,10000),sp.Integer(20)),
          ('distinct',sp.Rational(1,8),sp.Rational(1,20000),sp.Integer(18))]
for label,kv,nv,dv in examples:
    av=ak.subs(k,kv);sv=sk.subs(k,kv)
    zv=sp.Rational(1,10);Dv=D.subs({s:sv,z:zv});ratio=sp.factor(Dv/zv**2)
    upper=6*sv*zv*(1-zv**2)+nv*Dv/(2*av*(1+sv))*(sv*zv*64+(1+sv)*8/zv)
    half=9*sv/4
    ck(label+'::exp_series_bound',sp.Rational(8,3)**8>ratio,{'exp_lower_power':str(sp.Rational(8,3)**8),'ratio':str(ratio)})
    ck(label+'::rational_tenth_upper',upper<dv,{'upper':str(upper),'margin':str(dv-upper)})
    ck(label+'::rational_half_lower',half>dv,{'lower':str(half),'margin':str(half-dv)})
    ck(label+'::positive_nu_tail',nv*(1+sv)/(2*av)>0)
    ck(label+'::right_positive_Wprime',dv>0)
    brackets.append(dict(label=label,k=str(kv),nu=str(nv),delta_star=str(dv),s=str(sv),a=str(av),
                         tenth_log_argument=str(ratio),tenth_dstar_upper=str(upper),upper_margin=str(dv-upper),half_dstar_lower=str(half)))

for kv in [sp.Rational(1,100),sp.Rational(1,12),sp.Rational(1,4),sp.Rational(8,25)]:
    av=ak.subs(k,kv);sv=sk.subs(k,kv)
    ck('metric_signs_'+str(kv),av>0 and sv>0 and 1-3*av>0)
    for zv in [sp.Rational(1,100),sp.Rational(2,7),sp.Rational(9,10)]:
        Dv=D.subs({s:sv,z:zv});Jv=J.subs({a:av,s:sv,z:zv})
        ck('map_factors_'+str((kv,zv)),Dv>0 and Dv/zv**2>1 and Jv>0)

def asmp(r):return mp.mpf(str(r.p))/int(r.q)
numeric=[]
for label,kv,nv,dv in examples:
    kn=asmp(kv);nn=asmp(nv);dd=asmp(dv)
    an=(1-kn)*(1+3*kn)/4;sn=(1+kn)/(kn*(1-3*kn));alpha=mp.sqrt(an)
    def Aof(u):
        ee=mp.exp(2*alpha*u);return mp.sqrt((1+sn)*ee/(1+sn*ee))
    def Uof(u):
        ee=mp.exp(2*alpha*u);ff=1+sn*ee
        return mp.mpf('1.5')+3*sn*(ee-1)**2/(2*ff**2)+nn*(1+sn)*u*u/(2*ff**2)
    def Uofz(v):
        De=1+sn-sn*v*v;ell=mp.log(De/(v*v))
        return mp.mpf('1.5')+mp.mpf('1.5')*sn*(1-v*v)**2+nn*De**2*ell**2/(8*an*(1+sn))
    def Wofz(v):return Uofz(v)+dd*v
    def stationary(v):return mp.diff(Wofz,v)
    def proposed_dstar(v):
        De=1+sn-sn*v*v;ell=mp.log(De/(v*v))
        return STATIONARY_SIGN*(6*sn*v*(1-v*v)+nn*De/(2*an*(1+sn))*(sn*v*ell**2+(1+sn)*ell/v))
    label_roots=[]
    for index,(lo,hi) in enumerate([('1e-10','.1'),('.1','.5'),('.5','1')]):
        left=mp.mpf(lo);right=mp.mpf(hi);fl=stationary(left);fr=stationary(right)
        ck(label+'::numeric_sign_bracket_'+str(index),fl*fr<0,{'left_value':ms(fl),'right_value':ms(fr)})
        if not fl*fr<0:
            label_roots.append(dict(index=index,error='Actual action derivative has no bracket'));continue
        for step in range(250):
            mid=(left+right)/2;fm=stationary(mid)
            if fl*fm<=0:right=mid;fr=fm
            else:left=mid;fl=fm
        root=(left+right)/2
        De=1+sn-sn*root*root;ur=-mp.log(De/(root*root))/(2*alpha)
        ee=mp.exp(2*alpha*ur);ff=1+sn*ee;jj=1+(1-3*an)*sn*ee;ku=jj/ff**2
        z_u=mp.diff(Aof,ur);hess=mp.diff(Uofz,root,2)
        action_hess=mp.diff(lambda vv:Uof(vv)+dd*Aof(vv),ur,2)
        mE_action=action_hess/ku;mJ_action=mE_action/root**2
        hess_claim=hess+HESSIAN_EXTRA*3*proposed_dstar(root)/root
        mE_claim=z_u*z_u*hess_claim/ku;mJ_claim=mE_claim*root**PHYSICAL_MASS_POWER
        near(label+'::action_stationarity_'+str(index),mp.diff(lambda vv:Uof(vv)+dd*Aof(vv),ur))
        near(label+'::transformed_stationarity_'+str(index),stationary(root))
        near(label+'::source_normalization_at_root_'+str(index),mp.diff(Uofz,root)+mp.mpf(2)/SOURCE_DIVISOR*dd*MATTER_POWER*root**(MATTER_POWER-1))
        near(label+'::density_formula_at_root_'+str(index),proposed_dstar(root)-dd)
        near(label+'::density_conversion_at_root_'+str(index),dd/root**DENSITY_POWER-dd/root**3,dd/root**3)
        near(label+'::potential_coordinate_agreement_'+str(index),Uofz(root)-Uof(ur))
        near(label+'::Hessian_coordinate_agreement_'+str(index),z_u*z_u*hess_claim-action_hess,action_hess)
        near(label+'::physical_mass_agreement_'+str(index),mJ_claim-mJ_action,mJ_action)
        qn=an/jj;fixedJ_hess=hess+3*dd/root
        near(label+'::physical_mass_q_identity_'+str(index),mJ_claim-qn*hess,qn*hess)
        ck(label+'::fixed_particle_stability_'+str(index),hess>0 if index!=1 else hess<0,ms(hess))
        ck(label+'::fixed_physical_density_feedback_curvature_'+str(index),fixedJ_hess>0,ms(fixedJ_hess))
        kxx=(1+sn)*4*kn/(9*ff);kyy=(1+sn)*kn/(3*ff)
        mux=kn*mp.exp(-(1-kn)/alpha*ur)/(kxx*root**2)
        muy=2*kn*mp.exp(-(1+kn)/alpha*ur)/(3*kyy*root**2)
        ck(label+'::transverse_physical_masses_positive_'+str(index),mux>0 and muy>0)
        label_roots.append(dict(index=index,z=ms(root),u=ms(ur),W=ms(Wofz(root)),delta_J=ms(dd/root**3),
            Uzz=ms(hess),fixed_J_residual_curvature=ms(fixedJ_hess),q=ms(qn),
            mE2_over_Hv2=ms(mE_action),mJ2_over_Hv2=ms(mJ_action),
            mJx2_over_Hv2=ms(mux),mJy2_over_Hv2=ms(muy),bracket_width=ms(right-left),
            stationarity_residual=ms(stationary(root)),radial_type='strict minimum' if index!=1 else 'radial maximum / full-field saddle'))
    if len(label_roots)==3 and all('z' in r for r in label_roots):
        densities=[mp.mpf(r['delta_J']) for r in label_roots]
        ck(label+'::different_physical_densities',densities[0]>densities[1]>densities[2])
        ck(label+'::maximum_above_both_minima',mp.mpf(label_roots[1]['W'])>max(mp.mpf(label_roots[0]['W']),mp.mpf(label_roots[2]['W'])))
    numeric.append(dict(label=label,k=str(kv),nu=str(nv),delta_star=str(dv),roots=label_roots))

result=dict(scope='Independent synthetic action/density/mass check; no measured density or realized body.',
    passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,
    exact_brackets=brackets,numeric=numeric,precision=mp.mp.dps,
    versions=dict(python=platform.python_version(),sympy=sp.__version__,mpmath=mp.__version__),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),producer_imported=False)
path=Path(sys.argv[1]);assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks']},indent=2))
if result['failed']:print(json.dumps([r for r in rows if not r['passed']],indent=2))
raise SystemExit(bool(result['failed']))
