from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json
import subprocess
import sys

u=Path(__file__).resolve().parent
base=(u/'check_density_v1.py').read_text()
d=u/'damages';d.mkdir(exist_ok=False)
plans=[
 ('source_factor','SOURCE_DIVISOR = 2','SOURCE_DIVISOR = 1','particle_source_normalization'),
 ('particle_A_power','MATTER_POWER = 1','MATTER_POWER = 4','effective_energy_from_particle_action'),
 ('density_volume_power','DENSITY_POWER = 3','DENSITY_POWER = 4','physical_particle_number_volume'),
 ('stationary_sign','STATIONARY_SIGN = 1','STATIONARY_SIGN = -1','stationary_density_from_actual_potential'),
 ('wrong_fixed_density_hessian','HESSIAN_EXTRA = 0','HESSIAN_EXTRA = 1','fixed_particle_hessian'),
 ('physical_mass_power','PHYSICAL_MASS_POWER = -2','PHYSICAL_MASS_POWER = 2','physical_mass_coordinate_conversion')]
record=[]
for name,old,new,witness in plans:
 assert base.count(old)==1,(name,base.count(old))
 changed=base.replace(old,new,1);script=d/(name+'.py');script.write_text(changed)
 (d/(name+'.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),changed.splitlines(True),fromfile='check_density_v1.py',tofile=script.name)))
 record.append(dict(name=name,old=old,new=new,required_failed_check=witness,script=str(script.relative_to(u)),
                    script_sha256=hashlib.sha256(script.read_bytes()).hexdigest()))
(u/'DAMAGE_PLAN_v1.json').write_text(json.dumps(dict(frozen_before_execution=dt.datetime.now(dt.timezone.utc).isoformat(),damages=record),indent=2)+'\n')
results=[]
for row in record:
 name=row['name'];target='damages/'+name+'_RESULTS_v1.json'
 argv=[sys.executable,'-B',str(u/'run_logged_v1.py'),'damage_'+name,row['script'],target]
 started=dt.datetime.now(dt.timezone.utc).isoformat();proc=subprocess.run(argv,cwd=u,capture_output=True,timeout=60)
 (d/(name+'_launcher_stdout_v1.txt')).write_bytes(proc.stdout)
 (d/(name+'_launcher_stderr_v1.txt')).write_bytes(proc.stderr)
 result=json.loads((u/target).read_text()) if (u/target).exists() else None
 failed=[] if result is None else [r['name'] for r in result['checks'] if not r['passed']]
 ok=proc.returncode==1 and row['required_failed_check'] in failed
 results.append(dict(**row,argv=argv,started_at=started,finished_at=dt.datetime.now(dt.timezone.utc).isoformat(),
    exit_code=proc.returncode,passed=None if result is None else result['passed'],failed=None if result is None else result['failed'],
    failed_checks=failed,intended_failure_detected=ok,result=target))
 print(name,proc.returncode,'intended_failure_detected',ok,flush=True)
out=dict(scope='Six actual one-edit independent checker executions, not hypothetical flag inspection.',results=results,
         detected=sum(r['intended_failure_detected'] for r in results),missed=sum(not r['intended_failure_detected'] for r in results))
(u/'DAMAGE_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(bool(out['missed']))
