from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys

unit=Path(__file__).resolve().parent
name=sys.argv[1];script=unit/sys.argv[2];output=unit/sys.argv[3]
assert script.is_file() and not output.exists()
record=unit/(name+'_COMMAND_v1.json');assert not record.exists()
argv=[sys.executable,'-B',str(script),str(output)]
started=dt.datetime.now(dt.timezone.utc).isoformat()
proc=subprocess.run(argv,cwd=unit,capture_output=True,timeout=60)
finished=dt.datetime.now(dt.timezone.utc).isoformat()
streams={}
for label,data in [('stdout',proc.stdout),('stderr',proc.stderr)]:
    path=unit/(name+'_'+label+'_v1.txt');assert not path.exists();path.write_bytes(data)
    streams[label]=dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
result=dict(argv=argv,cwd=str(unit),started_at=started,finished_at=finished,
    script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),exit_code=proc.returncode,streams=streams)
if output.exists():result['output']=dict(path=str(output.relative_to(unit)),bytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest())
record.write_text(json.dumps(result,indent=2)+'\n')
if output.exists():
    r=json.loads(output.read_text());print(json.dumps(dict(passed=r['passed'],failed=r['failed'],failed_checks=[x['name'] for x in r['checks'] if not x['passed']]),indent=2))
if proc.stderr:print(proc.stderr.decode(),file=sys.stderr)
print(json.dumps(dict(record=record.name,exit_code=proc.returncode)))
raise SystemExit(proc.returncode)
