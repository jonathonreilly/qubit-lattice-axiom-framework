from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json
import subprocess
import sys

unit=Path(__file__).resolve().parent
base=(unit/'check_susceptibility_v1.py').read_text()
plan=[]
for name,old,new,witness in [
 ('mass_threshold_two','MASS_THRESHOLD = 3','MASS_THRESHOLD = 2','mass_susceptibility_threshold'),
 ('inverse_slope_sign','INVERSE_SIGN = -1','INVERSE_SIGN = 1','implicit_stationary_inverse_slope')]:
 assert base.count(old)==1
 changed=base.replace(old,new,1);path=unit/'damages'/('susceptibility_'+name+'.py');assert not path.exists();path.write_text(changed)
 diff=path.with_suffix('.diff');diff.write_text(''.join(difflib.unified_diff(base.splitlines(True),changed.splitlines(True),fromfile='check_susceptibility_v1.py',tofile=path.name)))
 plan.append(dict(name=name,old=old,new=new,required_failed_check=witness,script=str(path.relative_to(unit)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(unit/'SUSCEPTIBILITY_DAMAGE_PLAN_v1.json').write_text(json.dumps(dict(at=dt.datetime.now(dt.timezone.utc).isoformat(),damages=plan),indent=2)+'\n')
records=[]
for p in plan:
 name='susceptibility_'+p['name'];target='damages/'+name+'_RESULTS_v1.json'
 cmd=[sys.executable,'-B',str(unit/'run_logged_v1.py'),'damage_'+name,p['script'],target]
 r=subprocess.run(cmd,cwd=unit,capture_output=True,timeout=60)
 (unit/'damages'/(name+'_launcher_stdout_v1.txt')).write_bytes(r.stdout)
 (unit/'damages'/(name+'_launcher_stderr_v1.txt')).write_bytes(r.stderr)
 j=json.loads((unit/target).read_text());failed=[x['name'] for x in j['checks'] if not x['passed']]
 ok=r.returncode==1 and p['required_failed_check'] in failed
 records.append(dict(**p,argv=cmd,result=target,exit_code=r.returncode,passed=j['passed'],failed=j['failed'],failed_checks=failed,intended_failure_detected=ok))
 print(name,r.returncode,'intended_failure_detected',ok,flush=True)
out=dict(results=records,detected=sum(x['intended_failure_detected'] for x in records),missed=sum(not x['intended_failure_detected'] for x in records))
(unit/'SUSCEPTIBILITY_DAMAGE_RESULTS_v1.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(bool(out['missed']))
