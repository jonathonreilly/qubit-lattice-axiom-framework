from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

u=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(name):
 b=(u/name).read_bytes();return dict(path=name,bytes=len(b),sha256=sha(b))
def load(name):return json.loads((u/name).read_text())
def write(name,obj):
 p=u/name;assert not p.exists(),p;p.write_text(json.dumps(obj,indent=2)+'\n')
rows=[]
def ck(name,value):rows.append(dict(name=name,passed=bool(value)))
sources=load('CONSOLIDATED_SOURCE_BINDINGS_v1.json')['sources']
for r in sources:
 live=Path(r['original_path']).read_bytes();frozen=(u/r['snapshot_path']).read_bytes()
 ck('source::'+r['snapshot_path'],live==frozen and len(live)==r['bytes'] and sha(live)==r['sha256'])
for path in sorted(u.glob('*_COMMAND_v1.json')):
 rec=load(path.name)
 if 'script_sha256' not in rec:
  ck('PDF_render_exit',rec['exit_code']==0);continue
 script=Path(rec['argv'][2]);ck('executed_script::'+path.name,sha(script.read_bytes())==rec['script_sha256'])
 for kind,r in rec['streams'].items():
  b=(u/r['path']).read_bytes();ck('stream::'+path.name+'::'+kind,len(b)==r['bytes'] and sha(b)==r['sha256'])
 r=rec['output'];b=(u/r['path']).read_bytes();result=json.loads(b)
 ck('result::'+path.name,len(b)==r['bytes'] and sha(b)==r['sha256'])
 ck('result_counts::'+path.name,result['passed']==sum(r['passed'] for r in result['checks']) and result['failed']==sum(not r['passed'] for r in result['checks']))
 ck('exit_agrees_with_failures::'+path.name,rec['exit_code']==int(result['failed']>0))
 if 'script_sha256' in result:ck('result_self_binding::'+path.name,result['script_sha256']==rec['script_sha256'])
for name,expected in [('BASELINE_RESULTS_v1.json',146),('SUSCEPTIBILITY_RESULTS_v1.json',49),('SOURCE_CORRESPONDENCE_RESULTS_v1.json',23)]:
 result=load(name);ck('clean_count::'+name,result['passed']==expected and result['failed']==0)
for result_name,plan_name,script_name in [
 ('DAMAGE_RESULTS_v1.json','DAMAGE_PLAN_v1.json','check_density_v1.py'),
 ('SUSCEPTIBILITY_DAMAGE_RESULTS_v1.json','SUSCEPTIBILITY_DAMAGE_PLAN_v1.json','check_susceptibility_v1.py')]:
 result=load(result_name);plan=load(plan_name)['damages'];base=(u/script_name).read_text()
 for row,planned in zip(result['results'],plan):
  changed=(u/planned['script']).read_text()
  ck('single_actual_edit::'+row['name'],base.count(planned['old'])==1 and changed==base.replace(planned['old'],planned['new'],1))
  actual=load(row['result']);failed=[r['name'] for r in actual['checks'] if not r['passed']]
  ck('actual_damage_witness::'+row['name'],row['exit_code']==1 and row['required_failed_check'] in failed and row['failed_checks']==failed)
 ck('all_damages_detected::'+result_name,result['missed']==0 and len(plan)==len(result['results'])==result['detected'])
freeze=load('HAND_PROTOCOL_FREEZE_v1.json')
for name,r in freeze['files'].items():
 b=(u/name).read_bytes();ck('hand_preexecution_freeze::'+name,len(b)==r['bytes'] and sha(b)==r['sha256'])
for r in load('HAND_PROOF_BINDINGS_v1.json')['proofs']:
 ck('hand_precedes_code::'+r['hand']['path'],r['hand_precedes_code'])
 for name in ['hand','code']:
  rr=r[name];b=(u/rr['path']).read_bytes();ck('hand_binding::'+rr['path'],sha(b)==rr['sha256'] and len(b)==rr['bytes'])
access=load('PRIMARY_ACCESS_v1.json')
ck('primary_TLS_verified_access',access['exit_code']==0 and not access['tls_verification_disabled'] and '--insecure' not in access['argv'] and '-k' not in access['argv'])
pdf=u/access['output']['path'];ck('primary_PDF_byte_binding',sha(pdf.read_bytes())==access['output']['sha256'] and pdf.read_bytes().startswith(b'%PDF'))
for r in load('COMMANDS_v1.json')['commands']:
 rr=r['record'];b=(u/rr['path']).read_bytes();ck('command_index::'+rr['path'],len(b)==rr['bytes'] and sha(b)==rr['sha256'])
ck('final_source_hash',sha((u/'sources/DERIVATION_v3.md').read_bytes())=='0a56a10391b21c30d7d4cff8950ae3d4c2b0d2075050a3430f56b29a0ff381c2')
ck('addendum_source_hash',sha((u/'sources/SUSCEPTIBILITY_ADDENDUM_v1.md').read_bytes())=='34802c68eb9a15c10acce84c8afef629c261bffe7c8bf6a33be7b26b34d8f1db')
validation=dict(scope='Final evidence identities, actual results and source correspondence; no mathematical rerun.',
 passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows)
write('EVIDENCE_VALIDATION_v1.json',validation)
assert validation['failed']==0

now=dt.datetime.now(dt.timezone.utc).isoformat()
artifacts=[]
for p in sorted(u.rglob('*')):
 if p.is_file():
  assert not p.is_symlink();artifacts.append(ref(str(p.relative_to(u))))
write('MANIFEST_v1.json',dict(at=now,artifact_count=len(artifacts),artifacts=artifacts,
 excludes=['MANIFEST_v1.json','RECEIPT_v1.json'],scope='Immutable independent evidence; includes the explicitly disclosed metadata-only accidental producer diff.'))
main=load('BASELINE_RESULTS_v1.json');addon=load('SUSCEPTIBILITY_RESULTS_v1.json')
receipt=dict(
 created_utc=now,type='focused_independent_scientific_check',checker='/root/scalar_energy_check',direct_scientific_author='/root',unit=str(u),
 report=ref('REPORT_v1.md'),manifest=ref('MANIFEST_v1.json'),artifact_count=len(artifacts),
 source_pair_count=len(sources),intended_source_pair_count=11,contextual_unintended_pair_count=1,
 source_bindings=ref('CONSOLIDATED_SOURCE_BINDINGS_v1.json'),source_pairs=sources,
 final_author_source=ref('sources/DERIVATION_v3.md'),final_addendum_source=ref('sources/SUSCEPTIBILITY_ADDENDUM_v1.md'),
 original_author_versions=[ref('sources/DERIVATION_v1.md'),ref('sources/DERIVATION_v2.md')],
 hand_derivation=ref('HAND_DERIVATION_v1.md'),hand_addendum=ref('SUSCEPTIBILITY_HAND_v1.md'),hand_protocol=ref('CONTROL_PROTOCOL_v1.json'),hand_bindings=ref('HAND_PROOF_BINDINGS_v1.json'),
 new_mathematics=dict(main=dict(passed=146,failed=0,result=ref('BASELINE_RESULTS_v1.json'),script=ref('check_density_v1.py'),command=ref('baseline_COMMAND_v1.json')),
  susceptibility=dict(passed=49,failed=0,result=ref('SUSCEPTIBILITY_RESULTS_v1.json'),script=ref('check_susceptibility_v1.py'),command=ref('susceptibility_COMMAND_v1.json'),root_solves_repeated=False),
  source_correspondence_and_exact_density_witness=dict(passed=23,failed=0,result=ref('SOURCE_CORRESPONDENCE_RESULTS_v1.json'),command=ref('correspondence_COMMAND_v1.json'))),
 actual_damages=dict(main=ref('DAMAGE_RESULTS_v1.json'),susceptibility=ref('SUSCEPTIBILITY_DAMAGE_RESULTS_v1.json'),executions=8,intended_failures_detected=8),
 numerical_examples=main['numeric'],susceptibility_values=addon['numeric'],versions=main['versions'],
 corrected_source_findings=load('FAILURES_v1.json')['source_findings'],failure_ledger=ref('FAILURES_v1.json'),
 primary_source=dict(pdf=ref('sources/Khoury_Weltman_0309411v2.pdf'),access=ref('PRIMARY_ACCESS_v1.json'),visual_confirmation=ref('PDF_VISUAL_CONFIRMATION_v1.json'),role='theoretical convention only; no phenomenology imported'),
 commands=ref('COMMANDS_v1.json'),metadata_validation=dict(passed=validation['passed'],failed=validation['failed'],result=ref('EVIDENCE_VALIDATION_v1.json')),
 producer_access=dict(code_or_results_semantically_read=False,imported_or_executed=False,
   code_bytes_copied_after_main_addendum_and_damage_executions=True,incident=ref('ACCESS_INCIDENT_v1.json'),
   limitation='One producer checker diff was accidentally copied and hashed after all ten main/addendum science executions had finished. It was not displayed, interpreted, or used. Source-correspondence metadata checks followed and disclose the ordering.'),
 conclusion='The final v3 prescribed-source stationary maps, multiple-extremum example, physical mass normalization, and susceptibility addendum are mathematically supported under their explicit assumptions; no remaining source-equation correction is identified.',
 limitations=['No realized finite-body solution, measured density, calibrated mass/range or screening likelihood.',
  'Particle density is defined per Einstein proper volume with the metric fixed during scalar variation; fixed physical density is a distinct perturbation prescription.',
  'Strict local minima and positive local scalar mass do not imply full fluid/gravity stability or dynamical selection.',
  'At least two minima and an intermediate saddle are established; no exhaustive stationary-root census or global minimum claim.',
  'Susceptibility is a stationary-family slope, not real-time adiabatic tracking; endpoint limits hold for fixed nu>0 and are nonuniform at nu=0.',
  'Numeric bisection values support the exact proof but are not rigorous interval enclosures or empirical precision.',
  'No formal audit verdict, delegated scientific authorship, Git/PR/runtime/lock/settings/authority changes.'],
 seal_command=dict(argv=[sys.executable,'-B',str(Path(__file__).resolve())],cwd=str(u),script_sha256=sha(Path(__file__).read_bytes())),
 writes_confined_to_unit=True,prior_seals_modified=False,immutable_after_seal=True)
write('RECEIPT_v1.json',receipt)
# Read-only verification after final write.
for r in artifacts:
 b=(u/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
assert {str(p.relative_to(u)) for p in u.rglob('*') if p.is_file()}=={r['path'] for r in artifacts}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
print(json.dumps(dict(artifact_count=len(artifacts),source_pair_count=len(sources),metadata=f"{validation['passed']}/{validation['failed']}",
 report=ref('REPORT_v1.md'),manifest=ref('MANIFEST_v1.json'),receipt=ref('RECEIPT_v1.json')),indent=2))
