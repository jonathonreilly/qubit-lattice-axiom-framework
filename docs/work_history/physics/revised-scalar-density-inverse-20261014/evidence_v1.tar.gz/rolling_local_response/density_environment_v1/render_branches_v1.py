from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent;results=json.loads((p/'RESULTS_v1.json').read_text())
s=110/7;a=117/400;nu=1e-4;z=np.geomspace(1e-4,1,1000);D=1+s-s*z*z;L=np.log(D/z**2)
u0=1.5+1.5*s*(1-z*z)**2+nu*D**2*L**2/(8*a*(1+s))
ds=6*s*z*(1-z*z)+nu*D/(2*a*(1+s))*(s*z*L**2+(1+s)*L/z)
plt.rcParams.update({'font.size':10,'axes.titlesize':12,'axes.labelsize':11})
fig,axes=plt.subplots(1,2,figsize=(11,4.7),layout='constrained')
axes[0].plot(z,ds,color='#254c76',lw=2);axes[0].axhline(20,color='#8a523b',ls='--',label='Fixed particle density: delta* = 20')
axes[0].set(xscale='log',ylim=(0,70),xlabel='Conformal factor A',ylabel='Required particle-density parameter d*(A)',title='One particle-density parameter, three stationary points')
axes[1].plot(z,u0+20*z,color='#254c76',lw=2);axes[1].set(xscale='log',xlabel='Conformal factor A',ylabel='Effective potential W = U + 20 A',title='Two local minima separated by a radial maximum')
for r in results['roots']:
 x=float(r['z']);i=r['index'];color='#377d4f' if i!=1 else '#a14343';lab='Local minimum' if i!=1 else 'Radial maximum / full-field saddle'
 axes[0].scatter([x],[20],color=color,s=45,zorder=5)
 axes[1].scatter([x],[float(r['W'])],color=color,s=45,zorder=5,label=lab if i!=2 else None)
for ax in axes:
 ax.grid(alpha=.2);ax.legend(fontsize=8,loc='best')
fig.suptitle('The supplied scalar action does not make fixed particle data a unique state selector',fontsize=13)
fig.supxlabel('Synthetic k = 0.1, nu = 0.0001. Physical densities differ between the three states; no observed apparatus is modeled.',fontsize=9)
for ext in ['png','pdf']:fig.savefig(p/('DENSITY_BRANCHES_v1.'+ext),dpi=190)
(p/'FIGURE_PROVENANCE_v1.json').write_text(json.dumps({'source_results_sha256':hashlib.sha256((p/'RESULTS_v1.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Plot evaluation of checked closed form and saved numerical stationary roots; no new model fit, independent check or claim of all roots.','grid_points':1000,'A_range':[1e-4,1],'inputs':{'k':0.1,'nu':0.0001,'delta_star':20}},indent=2)+'\n')
