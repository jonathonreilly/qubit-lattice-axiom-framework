# Full failure and scope log

The first new independent baseline executed once and completed with 114 passed, 0 failed. There was no independent source-equation correction, unexpected symbolic/numerical failure, repaired assertion, timeout or rerun. The complete baseline JSON, stdout, empty stderr, exact argv, times and source/script hashes are preserved.

Six actual changed copies of the independent checker were then executed. These were deliberate negative controls, not failures of the unmodified source theorem:

| Changed implemented formula | Passed / failed | Required failed witness |
|---|---:|---|
| physical-density source volume power 3 -> 0 | 109 / 5 | action.full_physical_density_jacobian |
| source denominator 2Q -> Q | 106 / 8 | action.implemented_source_matches_variation |
| physical squared mass A^-2 -> A^2 | 112 / 2 | frame.physical_mass_from_dalembertian |
| susceptibility minus sign -> plus sign | 111 / 3 | rank_one.source_slope_matches_contraction |
| calibration derivative plus sign -> minus sign | 113 / 1 | calibration.log_derivative_sign |
| SI denominator c_light^2 -> 1 | 110 / 4 | SI.zeta_dimensionless |

Every changed checker exited 1, and every intended mathematical witness failed. All six complete changed scripts, exact unified diffs, individual 114-row result sets, command records and both output streams are retained. The surrounding execution harness intentionally exits 0 after recording a child failure; the recorded child exit code is the evidence of rejection. The 23 failed assertions across these six changed runs are not combined with the clean baseline count.

No producer code or outputs were read for this identity check. Only explicit paths to the new source/protocol, supplied full action, final previous density source/addendum and this reviewer's prior report/receipt/manifest/two saved results were accessed. No source globs were used. The prior density receipt contains a disclosed historical metadata-only accidental producer-diff copy after that unit's science. This unit does not read, recopy or use that diff. Reuse of its report/receipt/manifest therefore preserves rather than erases the historical disclosure. The prior six roots were not recomputed; their rounded saved decimals support new algebraic comparisons at relative tolerance 1e-42, not interval-certified solutions.

A parent message after the six changed controls were started described a separate probe-prescription extension. No file from that extension was accessed and no new extension claim is checked here. It prompted an explicit scope sentence in the report: the mass reconstructed from a prospective apparatus must correspond to the specified fixed-particle perturbation, not merely the same background density. This distinction was already present in the frozen hand proof and the exact two-Hessian controls. The source remains unchanged and no new producer execution is claimed.

All writes are confined to this new independent_v1. No network request, Git command, source edit, runtime/lock/settings edit, PR operation, formal audit or new agent was used. The direct scientific author remains /root.
