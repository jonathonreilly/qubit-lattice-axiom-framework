# Independent hand reconstruction, frozen before executable controls

Checker: /root/scalar_energy_check. Direct source author: /root. This is a focused local mathematical check, not an audit or an independently chosen physical model. The new source and protocol and the complete supplied action have been read; no producer implementation or results have been opened. The preceding density unit is reused only through exact frozen source and own report/receipt/results identities.

## 1. Variation and the two density constraints

At an event choose a K-orthonormal normal field frame. Write Y=Hv^2 U. The scalar and externally prescribed nonrelativistic particle terms are locally

    L = -Q (partial chi)^2 - 2Q Y(chi) - rho_* A(chi),
    rho_* = m_J n_E,  rho_E=A rho_*,  rho_J=rho_*/A^3.

Here n_E is particle number per Einstein proper spatial volume, the Einstein metric is held fixed in the scalar variation, and m_J is fixed. Integrating the kinetic variation by parts gives

    2Q (box chi_i - Y_i) - rho_* A_i = 0.

Thus the stationary residual is F_i=Y_i+rho_* A_i/(2Q), and its fixed-rho_* derivative at a stationary point is the covariant Hessian M=Hess Y+rho_* Hess A/(2Q). The normalization 2Q follows from the absence of 1/2 before K. This is the scalar excitation mass for prescribed particles; it says nothing by itself about a coupled moving fluid or metric mode.

For a family indexed by the physical density let t=ln(rho_J/rho_J0), so rho_*=rho_J A^3. At any stationary point, defining beta=d ln A and c=rho_J A^4/(2Q),

    dF = M dchi + (A beta/(2Q)) d rho_*,
    d rho_* = rho_* (dt+3 beta^T dchi),
    H dchi = -c beta dt,  H=M+3c beta beta^T.

The first line uses the fixed-particle Hessian, so the source differential there means the independently varied rho_*; the second line subsequently changes the constraint. Equivalently, the derivative at fixed rho_J is the Hessian of Y+rho_J A^4/(8Q), evaluated at the stationary point, whereas the fixed-particle Hessian is that of Y+rho_* A/(2Q). Confusing these two Hessians loses the physical-volume term or adds it to the wrong mass.

For positive Q, rho_J and A, c>0. If M is positive definite, v^T H v=v^T M v+3c(beta^T v)^2>0. Smoothness and det H !=0 give a local unique differentiable stationary branch by the implicit function theorem. This is a neighborhood statement at a given stationary point, not existence at every density, uniqueness among distant stationary points, an evolution law or a preparation mechanism. In general coordinates the derivative of the zero covector F is covariant; connection corrections to Y and A cancel in their total at F=0. Invariant masses are eigenvalues of K^{-1}M, represented by an ordinary symmetric matrix only in a K-orthonormal frame.

## 2. Rank-one inversion and its domain

Set zeta=c beta^T M^{-1} beta. For M>0 it is finite, nonnegative and zero exactly when beta=0. Direct multiplication verifies

    H^{-1} beta = M^{-1} beta/(1+3 zeta).

Consequently d ln A/dt=-zeta/(1+3 zeta). With Q fixed and G_bare=A^2/(8 pi Q),

    B=-d ln G_bare/dt=2 zeta/(1+3 zeta),
    zeta=B/(2-3B).

The finite positive-mass hypothesis implies 0<=B<2/3, with B=0 iff beta=0. For a coupled direction B>0 and the A slope lies strictly between -1/3 and 0. B=2/3 is reached only as a limit with unbounded zeta, not at a finite regular point of the stated domain. A zero eigenvalue, indefinite M, infinite beta, vanishing density or a changing Q requires separate analysis. An indefinite but invertible M can still satisfy the algebra when 1+3zeta !=0, but the positivity conclusions and mass interpretation do not follow from that algebra alone.

A distinct exact false converse will use M=diag(2,-3), beta=(1/3,1/5), c=2. Then zeta=19/225 and B=19/141, inside the apparently stable interval, despite the negative eigenvalue. A separate case beta=(1/3,0) hides the unstable mode entirely. Both cases are realizable as local source/potential jets, not a claim that they satisfy M>0. Conversely, an exactly tuned indefinite example can have 1+3zeta=0, in which case the physical-density implicit derivative is singular.

## 3. Frozen conformal frame and physical units

For constant A at the local background, ds_J=A ds_E and box_E=A^2 box_J. Therefore M_J=M/A^2 for squared masses. In the orthonormal eigenbasis of M_J, define nonnegative q_i=(e_i dot beta)^2, whose sum is q=|beta|^2. Since M^{-1}=A^{-2} M_J^{-1},

    zeta=(A^2 rho_J/(2Q)) beta^T M_J^{-1} beta
         =4 pi G_bare rho_J sum_i q_i/m_i,J^2.

This is a frozen local principal-response conversion, not a reduction of a spatially varying background or a global finite-body solution. No value of Q, Hv, density or gravitational calibration is selected by eliminating their separate symbols.

For q>0 the coupling-weighted harmonic squared mass is m_eff^2=q/sum(q_i/m_i,J^2). Division by the positive q-weight sum shows min_coupled m_i,J^2 <= m_eff^2 <= max_coupled m_i,J^2. Equality is possible for one coupled eigenvalue or equal coupled masses. Hence

    m_eff^2/(4 pi G_bare rho_J)=q(2/B-3).

This fixes one positive quadratic contraction, not the individual masses, weights or orthogonal directions. It cannot establish full scalar stability by itself. Degenerate eigenspaces are harmless: the summed weight within a degenerate space is basis independent.

For SI mass density rho_m, 4 pi G_SI rho_m has units s^-2. An inverse range mu has units m^-1. Thus the dimensionless contraction is (4 pi G_SI rho_m/c_light^2) sum(q_i/mu_i^2), and

    c_light^2 mu_eff^2/(4 pi G_SI rho_m)=q(2/B-3).

If the density is an energy density, rho_m=rho_energy/c_light^2, giving c_light^4 mu_eff^2/(4 pi G_SI rho_energy). This conversion assumes a defined common physical density and time/length convention; it is not an empirical calibration.

## 4. Candidate radial specialization, using already sealed roots

The supplied candidate has A=A(u), beta_u=alpha/F, K_uu=J/F^2, hence q=a/J. At x=y=0 the total fixed-particle stationary Hessian is diagonal, with transverse entries k exp(-lambda_x u) and (2k/3) exp(-lambda_y u), positive after metric and A conversion. Only the radial eigenvector couples to matter, so the effective mass is the radial physical mass.

Write z=A and delta_J=rho_J/(2Q Hv^2). The previously checked exact stationary relation is delta_J=d_J(z). Let S=-z d_J'/d_J. It gives B=2/S. Also U0_zz=z^2 delta_J(S-3), so

    m_u,J^2/Hv^2=q U0_zz=q z^2 delta_J(S-3),
    4 pi G_bare rho_J/Hv^2=z^2 delta_J,
    m_u,J^2/(4 pi G_bare rho_J)=q(S-3).

The stable radial criterion is S>3. The earlier weaker S>2 includes unstable radial points. I will reuse my own frozen six roots and S values, without importing the producer's roots or resolving any roots: two minima and one radial maximum for each of the source and distinct parameter sets. The four minima should satisfy B<2/3; the two maxima lie outside this theorem and may still obey the formal scalar algebra with negative zeta.

## 5. Calibration and nonselection boundaries

If G_cal=gamma G_bare with positive differentiable gamma, then

    B=-d ln G_cal/d ln rho_J+d ln gamma/d ln rho_J.

An amplitude bound alone gives no derivative bound. For the distinct choice q=3/7 and gamma=1+(q/2)(1+sin(omega t)), gamma lies in [1,10/7] at all t but gamma'/gamma at t=0 is (3/17) omega. Arbitrarily large positive or negative omega gives an arbitrarily steep local logarithmic slope without leaving that interval. This is a mathematical envelope witness; it does not supply a realizable source geometry or density-dependent apparatus. For any real measurement the local tensor normalization, environmental dependence, finite-body charge/range, density convention and weak-field accuracy must be separately reconstructed. No dataset or observation is used here.

These identities hold for arbitrary smooth local Y,A under their premises. In particular adding a nonzero cubic term in field displacement to Y leaves the value, gradient and Hessian at the chosen event unchanged while changing the potential. Such distinct local models have the same susceptibility identity and source jet. Therefore agreement with this relation alone does not select the candidate action, determine all masses, select a state or establish adiabatic tracking.

## 6. Frozen distinct synthetic test design

I will construct rather than import a two-field action jet with Q=7/3, A0=3/2, rho_J0=5/7, beta=(2/5,-1/3), log-A Hessian T=[[1/7,2/11],[2/11,-1/13]], and desired fixed-particle M=[[5,1],[1,2]]. Put c0=rho_J0 A0^4/(2Q),

    A(chi)=A0 exp(beta^T chi+chi^T T chi/2),
    Y(chi)=17/5-c0 beta^T chi
       +chi^T[M-c0(T+beta beta^T)]chi/2
       +(chi1^3+2chi1 chi2^2)/17.

Then F(0)=0 by direct differentiation and the fixed-particle Hessian is M. I will differentiate the full residual with rho_*=rho_J0 exp(t) A(chi)^3, obtain H and its t derivative independently, solve the exact rational linear system, and compare with the claimed contraction. The tests will also cover a nonorthogonal coordinate change, an explicit spectral example with two coupled positive eigenvalues, hidden unstable directions, the calibration envelope and SI dimensional powers. Actual altered copies will change the volume power, kinetic factor, mass-frame direction, susceptibility sign, calibration derivative sign and SI light-speed power. All executed failures will be retained. Exact finite controls support this written general derivation; their number is not a proof of the full theorem.
