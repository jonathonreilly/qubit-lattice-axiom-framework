#!/usr/bin/env python3
"""Independent hand-to-action controls; no producer modules or outputs imported."""
import argparse
import hashlib
import json
import platform
from pathlib import Path
import sys
import time
import traceback
import sympy as sp
import mpmath as mp

SOURCE_DENOMINATOR = 1
DENSITY_VOLUME_POWER = 3
PHYSICAL_MASS_A_POWER = -2
SUSCEPTIBILITY_SIGN = -1
CALIBRATION_DERIVATIVE_SIGN = 1
SI_LIGHT_SPEED_POWER = 2

parser = argparse.ArgumentParser()
parser.add_argument('--unit', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
unit = Path(args.unit).resolve()
checks, examples = [], {}
start = time.perf_counter()

def record(name, ok, detail=None):
    checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
    if not ok:
        print('FAIL', name, str(detail), flush=True)

def eq(name, left, right):
    if isinstance(left, sp.MatrixBase) or isinstance(right, sp.MatrixBase):
        gap = (left-right).applyfunc(sp.simplify)
        record(name, all(v == 0 for v in gap), str(gap))
    else:
        gap = sp.factor(sp.simplify(left-right))
        record(name, gap == 0, str(gap))

def rat(x):
    return mp.mpf(str(sp.N(sp.Rational(x), 90)))

def near(name, x, y, tol=mp.mpf('1e-42')):
    rel = abs(x-y)/max(mp.mpf(1), abs(x), abs(y))
    record(name, rel < tol, {'relative_error': mp.nstr(rel, 35), 'tolerance': str(tol)})

try:
    R = sp.Rational
    x1, x2, t, rstar = sp.symbols('chi1 chi2 t rho_star', real=True)
    x = sp.Matrix([x1, x2]); xs = [x1, x2]
    Q, A0, rho0 = R(7,3), R(3,2), R(5,7)
    beta = sp.Matrix([R(2,5),-R(1,3)])
    T = sp.Matrix([[R(1,7),R(2,11)],[R(2,11),-R(1,13)]])
    M = sp.Matrix([[5,1],[1,2]])
    c0 = rho0*A0**4/(2*Q)
    rho_star0 = rho0*A0**3
    logshape = (beta.T*x)[0] + (x.T*T*x)[0]/2
    A = A0*sp.exp(logshape)
    Y = R(17,5)-c0*(beta.T*x)[0]+(x.T*(M-c0*(T+beta*beta.T))*x)[0]/2+(x1**3+2*x1*x2**2)/17
    gradA = sp.Matrix([sp.diff(A,z) for z in xs])
    gradY = sp.Matrix([sp.diff(Y,z) for z in xs])
    at = {x1:0, x2:0, t:0}
    F_particle = gradY+rstar*gradA/(SOURCE_DENOMINATOR*Q)
    fixed_at = {**at,rstar:rho_star0}
    fixed_F0 = F_particle.subs(fixed_at)
    M_implemented = F_particle.jacobian(xs).subs(fixed_at)
    F_physical = F_particle.subs(rstar, rho0*sp.exp(t)*A**DENSITY_VOLUME_POWER)
    H_actual = F_physical.jacobian(xs).subs(at).applyfunc(sp.simplify)
    Ft_actual = sp.diff(F_physical,t).subs(at).applyfunc(sp.simplify)
    H_expected = M+3*c0*beta*beta.T
    eq('action.stationary_source_normalization', fixed_F0, sp.zeros(2,1))
    eq('action.fixed_particle_mass', M_implemented, M)
    eq('action.physical_density_residual_zero', F_physical.subs(at), sp.zeros(2,1))
    eq('action.full_physical_density_jacobian', H_actual, H_expected)
    eq('action.log_density_derivative', Ft_actual, c0*beta)
    eq('action.fixed_particle_rho_star', rho_star0, rho0*A0**3)
    eq('action.rho_E_conversion', A0*rho_star0, rho0*A0**4)
    eq('action.c_rho_value', c0, R(1215,1568))
    eq('action.beta_from_actual_A', gradA.subs(at)/A0, beta)
    eq('action.logA_hessian', sp.hessian(sp.log(A),xs).subs(at), T)
    v1,v2 = sp.symbols('v1 v2',real=True)
    L_time = Q*(v1*v1+v2*v2)-2*Q*Y-rstar*A
    eq('action.kinetic_EL_coefficient', sp.diff(L_time,v1,2), 2*Q)
    EL_stationary = sp.Matrix([-sp.diff(L_time,z)/(2*Q) for z in xs])
    eq('action.implemented_source_matches_variation', F_particle, EL_stationary)
    fixed_W = Y+rho_star0*A/(2*Q)
    physical_W = Y+rho0*sp.exp(t)*A**4/(8*Q)
    eq('action.fixed_particle_potential_hessian', sp.hessian(fixed_W,xs).subs(at), M)
    eq('action.fixed_physical_potential_hessian', sp.hessian(physical_W,xs).subs(at), H_expected)
    record('action.two_hessians_are_distinct', H_expected != M)
    record('positivity.fixed_particle_principal_minors', M[0,0]>0 and M.det()>0, {'first':str(M[0,0]),'det':str(M.det())})
    record('positivity.physical_density_principal_minors', H_expected[0,0]>0 and H_expected.det()>0, {'first':str(H_expected[0,0]),'det':str(H_expected.det())})
    zeta = sp.factor(c0*(beta.T*M.inv()*beta)[0])
    slope_direct = sp.factor((beta.T*(-H_actual.inv()*Ft_actual))[0])
    slope_claim = SUSCEPTIBILITY_SIGN*zeta/(1+3*zeta)
    B_direct = -2*slope_direct
    B_claim = -2*slope_claim
    eq('rank_one.source_slope_matches_contraction', slope_direct, slope_claim)
    eq('rank_one.gravity_slope_matches_contraction', B_direct, B_claim)
    eq('rank_one.inverse_beta', H_expected.inv()*beta, M.inv()*beta/(1+3*zeta))
    eq('rank_one.matrix_inverse', H_expected.inv(), M.inv()-3*c0*M.inv()*beta*beta.T*M.inv()/(1+3*zeta))
    eq('rank_one.invert_B', B_claim/(2-3*B_claim), zeta)
    record('rank_one.distinct_toy_domain', 0<B_direct<R(2,3) and -R(1,3)<slope_direct<0)
    examples['nonlinear_two_field_jet'] = {'Q':str(Q),'A0':str(A0),'rho_J0':str(rho0),'rho_star0':str(rho_star0),'c_rho':str(c0),'beta':str(beta),'M':str(M),'H':str(H_actual),'zeta':str(zeta),'slope_direct':str(slope_direct),'B_direct':str(B_direct),'implicit_tangent':str(-H_actual.inv()*Ft_actual)}
    zz = sp.symbols('zeta',nonnegative=True)
    bb = 2*zz/(1+3*zz)
    eq('domain.exact_upper_gap', R(2,3)-bb, 2/(3*(1+3*zz)))
    eq('domain.inverse_identity', bb/(2-3*bb), zz)
    eq('domain.zero_coupling', 2*0/(1+3*0), 0)
    eq('domain.large_zeta_limit', sp.limit(bb,zz,sp.oo), R(2,3))
    for val in [R(0),R(1,1000),R(7,5),R(10**6)]:
        bval=bb.subs(zz,val)
        record('domain.rational_zeta_'+str(val), 0<=bval<R(2,3),str(bval))
    # General 2x2 identity independently multiplied, not sampled alone.
    m,n,h,b1,b2,cc=sp.symbols('m n h b1 b2 c',real=True)
    MG=sp.Matrix([[m,h],[h,n]]); bg=sp.Matrix([b1,b2]); zg=cc*(bg.T*MG.inv()*bg)[0]
    HG=MG+3*cc*bg*bg.T
    eq('rank_one.general_2x2_multiplication', HG*(MG.inv()*bg/(1+3*zg)),bg)
    eq('rank_one.general_determinant_ratio', HG.det(),MG.det()*(1+3*zg))
    # Nonorthogonal coordinates: covariant Hessian differs from the mass operator.
    Rmap=sp.Matrix([[2,1],[0,R(3,2)]])
    Kp=Rmap.T*Rmap; Mp=Rmap.T*M*Rmap; bp=Rmap.T*beta
    eq('coordinates.contracted_inverse_invariant', c0*(bp.T*Mp.inv()*bp)[0],zeta)
    lam=sp.symbols('lambda')
    eq('coordinates.generalized_mass_spectrum', (Kp.inv()*Mp).charpoly(lam).as_expr(),M.charpoly(lam).as_expr())
    Hp=Mp+3*c0*bp*bp.T
    eq('coordinates.implicit_tangent_transforms', -Hp.inv()*c0*bp,Rmap.inv()*(-H_expected.inv()*c0*beta))
    record('coordinates.ordinary_covariant_eigenvalues_not_invariant', Mp.trace()!=M.trace())
    # Nonlinear coordinate Hessians cancel connection terms only in the total.
    p1,p2=sp.symbols('p1 p2',real=True)
    trans={x1:p1+p1*p1/3,x2:p2+p1*p2/5}; zero_p={p1:0,p2:0}
    WY=fixed_W.subs(trans,simultaneous=True)
    eq('coordinates.total_stationary_nonlinear_hessian',sp.hessian(WY,[p1,p2]).subs(zero_p),M)
    HYp=sp.hessian(Y.subs(trans,simultaneous=True),[p1,p2]).subs(zero_p)
    HAp=sp.hessian(A.subs(trans,simultaneous=True),[p1,p2]).subs(zero_p)
    record('coordinates.potential_alone_connection_nonzero',HYp!=sp.hessian(Y,xs).subs(at))
    eq('coordinates.total_connection_cancellation',HYp+rho_star0*HAp/(2*Q),M)
    # Frozen frame and spectral mass controls.
    MJ_impl=A0**PHYSICAL_MASS_A_POWER*M
    eq('frame.physical_mass_from_dalembertian', A0**2*MJ_impl,M)
    Gbare=A0**2/(8*sp.pi*Q)
    zeta_frame=4*sp.pi*Gbare*rho0*(beta.T*MJ_impl.inv()*beta)[0]
    eq('frame.density_mass_normalization',zeta_frame,zeta)
    O=sp.Matrix([[R(3,5),-R(4,5)],[R(4,5),R(3,5)]])
    eigen_m=sp.diag(2,11); MJ=O*eigen_m*O.T; ME=A0**2*MJ
    weights=[sp.factor((O[:,i].T*beta)[0]**2) for i in range(2)]
    q=(beta.T*beta)[0]; spectral_sum=weights[0]/2+weights[1]/11
    ze=sp.factor(c0*(beta.T*ME.inv()*beta)[0]); be=2*ze/(1+3*ze)
    meff=sp.factor(q/spectral_sum)
    eq('spectrum.orthonormal_eigenvectors',O.T*O,sp.eye(2))
    eq('spectrum.weight_sum',sum(weights),q)
    eq('spectrum.inverse_contraction',spectral_sum,(beta.T*MJ.inv()*beta)[0])
    eq('spectrum.frame_weighted_zeta',ze,4*sp.pi*Gbare*rho0*spectral_sum)
    eq('spectrum.harmonic_mass_identity',meff/(4*sp.pi*Gbare*rho0),q*(2/be-3))
    record('spectrum.harmonic_between_coupled_masses',2<meff<11,str(meff))
    beta_single=R(3,7)*O[:,0]
    ws=[(O[:,i].T*beta_single)[0]**2 for i in range(2)]
    eq('spectrum.uncoupled_weight_zero',ws[1],0)
    eq('spectrum.single_coupled_mass',sum(ws)/(ws[0]/2+ws[1]/11),2)
    eq('spectrum.degenerate_space_invariance',(beta.T*(4*sp.eye(2)).inv()*beta)[0],q/4)
    examples['spectral']={'weights':[str(v) for v in weights],'q':str(q),'masses_squared':['2','11'],'m_eff_squared':str(meff),'B':str(be)}
    # Positive contraction cannot establish the full mass hypothesis.
    N=sp.diag(2,-3); bn=sp.Matrix([R(1,3),R(1,5)]); cn=2
    zn=sp.factor(cn*(bn.T*N.inv()*bn)[0]); Bn=sp.factor(2*zn/(1+3*zn))
    eq('false_converse.distinct_zeta',zn,R(19,225))
    eq('false_converse.distinct_B',Bn,R(19,141))
    record('false_converse.distinct_hidden_instability',0<Bn<R(2,3) and N.det()<0)
    Hn=N+3*cn*bn*bn.T
    record('false_converse.regular_physical_density_jacobian',Hn.det()!=0,str(Hn.det()))
    eq('false_converse.actual_implicit_slope',-2*(bn.T*(-Hn.inv()*cn*bn))[0],Bn)
    bu=sp.Matrix([R(1,3),0]); zu=cn*(bu.T*N.inv()*bu)[0]
    record('false_converse.completely_uncoupled_negative_mode',N[1,1]<0 and 0<2*zu/(1+3*zu)<R(2,3))
    Ns=sp.diag(1,-4); bs=sp.Matrix([R(1,5),R(1,10)])
    eq('false_converse.source_example_arithmetic',(bs.T*Ns.inv()*bs)[0],R(3,80))
    # A local Y,A realizes the distinct indefinite jet; this is not a stable case.
    An=sp.exp((bn.T*x)[0]); Yn=-cn*(bn.T*x)[0]+(x.T*(N-cn*bn*bn.T)*x)[0]/2
    Fn=sp.Matrix([sp.diff(Yn+cn*An,z) for z in xs])
    eq('false_converse.realizable_stationary_jet',Fn.subs(at),sp.zeros(2,1))
    eq('false_converse.realizable_mass_jet',Fn.jacobian(xs).subs(at),N)
    eq('outside_domain.zero_mass_attains_boundary',-2*(-R(1,3)),R(2,3))
    eq('outside_domain.singular_rank_one_denominator',1+3*(-R(1,3)),0)
    eq('outside_domain.zero_density_hides_nonzero_beta',0*(beta.T*M.inv()*beta)[0],0)
    examples['false_converse']={'M':str(N),'beta':str(bn),'c':'2','zeta':str(zn),'B':str(Bn),'H_determinant':str(Hn.det())}
    # Distinct potentials with the same event jet.
    Yalt=Y+R(7,19)*x2**3
    eq('nonselection.same_value',Yalt.subs(at),Y.subs(at))
    eq('nonselection.same_gradient',sp.Matrix([sp.diff(Yalt,z) for z in xs]).subs(at),gradY.subs(at))
    eq('nonselection.same_hessian',sp.hessian(Yalt,xs).subs(at),sp.hessian(Y,xs).subs(at))
    record('nonselection.different_third_jet',sp.diff(Yalt-Y,x2,3)!=0,str(sp.diff(Yalt-Y,x2,3)))
    # Mathematical calibration envelope, with no apparatus interpretation.
    omega=sp.symbols('omega',real=True); qenv=R(3,7)
    gamma=1+qenv*(1+sp.sin(omega*t))/2
    gamma_slope=sp.diff(gamma,t)/gamma
    eq('calibration.distinct_log_slope',gamma_slope.subs(t,0),R(3,17)*omega)
    phase=sp.symbols('phase',real=True); gam_phase=1+qenv*(1+sp.sin(phase))/2
    eq('calibration.lower_endpoint',gam_phase.subs(phase,-sp.pi/2),1)
    eq('calibration.upper_endpoint',gam_phase.subs(phase,sp.pi/2),R(10,7))
    Bbare=R(2,9); Gt=R(7,13)*sp.exp(-Bbare*t); Gcal=gamma*Gt
    reconstructed=-sp.diff(Gcal,t)/Gcal+CALIBRATION_DERIVATIVE_SIGN*gamma_slope
    eq('calibration.log_derivative_sign',reconstructed,Bbare)
    for om in [1,10,1000,-17]:
        eq('calibration.frequency_'+str(om),gamma_slope.subs({t:0,omega:om}),R(3,17)*om)
    record('calibration.unbounded_slope_with_fixed_envelope',sp.limit(gamma_slope.subs(t,0),omega,sp.oo)==sp.oo)
    qrate=R(2,7); Qvar=Q*sp.exp(qrate*t)
    GvaryQ=Gt*Q/Qvar
    eq('outside_domain.varying_Q_extra_derivative',-sp.diff(GvaryQ,t)/GvaryQ-Bbare,qrate)
    examples['calibration']={'q':str(qenv),'range':['1','10/7'],'log_slope_at_reference':'3*omega/17','omega_1000_slope':str(R(3000,17)),'apparatus_solution_claimed':False}
    # SI powers: coordinate ordering (length, mass, time).
    dim_zeta=sp.Matrix([2-SI_LIGHT_SPEED_POWER,0,SI_LIGHT_SPEED_POWER-2])
    eq('SI.zeta_dimensionless',dim_zeta,sp.zeros(3,1))
    cs,gs,rs,mu,qe=sp.symbols('c_light G_SI rho_m mu q',positive=True)
    ze_si=4*sp.pi*gs*rs*qe/(cs**SI_LIGHT_SPEED_POWER*mu**2)
    B_si=2*ze_si/(1+3*ze_si)
    eq('SI.mass_identity',cs**2*mu**2/(4*sp.pi*gs*rs),qe*(2/B_si-3))
    re=sp.symbols('rho_energy',positive=True)
    eq('SI.energy_density_substitution',ze_si.subs(rs,re/cs**2),4*sp.pi*gs*re*qe/(cs**4*mu**2))
    ztest=R(7,1)/5**SI_LIGHT_SPEED_POWER*(R(2,11)/2**2+R(3,13)/7**2)
    eq('SI.distinct_rational_units_control',ztest,R(7,25)*(R(2,11)/4+R(3,13)/49))
    # Saved, independent roots and slopes. No solver or producer artifact access.
    mp.mp.dps=80
    saved=json.loads((unit/'reused/DENSITY_BASELINE_RESULTS_v1.json').read_text())
    slopes=json.loads((unit/'reused/DENSITY_SUSCEPTIBILITY_RESULTS_v1.json').read_text())
    slope_by_label={v['label']:v for v in slopes['numeric']}
    examples['candidate_reuse']=[]
    for case in saved['numeric']:
        for root in case['roots']:
            label=case['label']+'::'+str(root['index']); sr=slope_by_label[label]
            aval=mp.mpf(root['z']); qval=mp.mpf(root['q']); dj=mp.mpf(root['delta_J']); mass=mp.mpf(root['mJ2_over_Hv2']); S=mp.mpf(sr['S_env'])
            gfac=aval**2*dj; B=2/S; zet=gfac*qval/mass
            near('candidate.'+label+'.mass_identity',mass/gfac,qval*(S-3))
            near('candidate.'+label+'.zeta_inverse_B',zet,B/(2-3*B))
            near('candidate.'+label+'.slope',-zet/(1+3*zet),mp.mpf(sr['stationary_log_slope']))
            stable=mass>0
            record('candidate.'+label+'.domain_status',(0<B<mp.mpf(2)/3)==stable,{'B':mp.nstr(B,35),'mass_positive':stable})
            record('candidate.'+label+'.transverse_positive',mp.mpf(root['mJx2_over_Hv2'])>0 and mp.mpf(root['mJy2_over_Hv2'])>0)
            examples['candidate_reuse'].append({'label':label,'B':mp.nstr(B,45),'zeta':mp.nstr(zet,45),'mJ2_over_4piGbare_rho':mp.nstr(mass/gfac,45),'stable_domain':stable,'roots_resolved':False})
    # Exact candidate normalization, without rerunning its thermodynamic/root proof.
    av,delj,hv2,qv,Sv=sp.symbols('A delta_J Hv2 q S',positive=True)
    mrad=qv*av**2*delj*(Sv-3)*hv2
    eq('candidate.exact_scale_elimination',mrad/(av**2*delj*hv2),qv*(Sv-3))
    eq('candidate.exact_B_specialization',qv*(2/(2/Sv)-3),qv*(Sv-3))
    aa,JJ,FF=sp.symbols('a J F',positive=True)
    eq('candidate.action_coupling_norm',(sp.sqrt(aa)/FF)**2/(JJ/FF**2),aa/JJ)
except Exception:
    err=traceback.format_exc()
    record('execution.exception',False,err)
    print(err,file=sys.stderr,flush=True)

result={'scope':'Independent local susceptibility identity, exact synthetic controls and identity-bound reuse of own prior roots; no producer code/results or empirical inputs.','passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'examples':examples,'implementation_constants':{'source_denominator':SOURCE_DENOMINATOR,'density_volume_power':DENSITY_VOLUME_POWER,'physical_mass_A_power':PHYSICAL_MASS_A_POWER,'susceptibility_sign':SUSCEPTIBILITY_SIGN,'calibration_derivative_sign':CALIBRATION_DERIVATIVE_SIGN,'SI_light_speed_power':SI_LIGHT_SPEED_POWER},'versions':{'python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__},'elapsed_seconds':time.perf_counter()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((unit/'sources/DERIVATION_v1.md').read_bytes()).hexdigest(),'hand_derivation_sha256':hashlib.sha256((unit/'HAND_DERIVATION_v1.md').read_bytes()).hexdigest(),'reused_outputs':{n:hashlib.sha256((unit/'reused'/n).read_bytes()).hexdigest() for n in ['DENSITY_BASELINE_RESULTS_v1.json','DENSITY_SUSCEPTIBILITY_RESULTS_v1.json']},'producer_imported':False}
Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'seconds':result['elapsed_seconds'],'result':args.output}),flush=True)
sys.exit(0 if result['failed']==0 else 1)
