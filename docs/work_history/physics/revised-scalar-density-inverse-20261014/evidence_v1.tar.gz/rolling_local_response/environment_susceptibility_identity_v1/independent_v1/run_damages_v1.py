#!/usr/bin/env python3
import concurrent.futures,datetime,difflib,hashlib,json,subprocess,sys
from pathlib import Path
unit=Path(__file__).resolve().parent
source=unit/'check_identity_v1.py'; text=source.read_text(); mutations=[
 ('omit_volume','DENSITY_VOLUME_POWER = 3','DENSITY_VOLUME_POWER = 0','action.full_physical_density_jacobian'),
 ('double_source','SOURCE_DENOMINATOR = 2','SOURCE_DENOMINATOR = 1','action.implemented_source_matches_variation'),
 ('reverse_mass_frame','PHYSICAL_MASS_A_POWER = -2','PHYSICAL_MASS_A_POWER = 2','frame.physical_mass_from_dalembertian'),
 ('reverse_susceptibility','SUSCEPTIBILITY_SIGN = -1','SUSCEPTIBILITY_SIGN = 1','rank_one.source_slope_matches_contraction'),
 ('reverse_calibration_slope','CALIBRATION_DERIVATIVE_SIGN = 1','CALIBRATION_DERIVATIVE_SIGN = -1','calibration.log_derivative_sign'),
 ('omit_SI_c_squared','SI_LIGHT_SPEED_POWER = 2','SI_LIGHT_SPEED_POWER = 0','SI.zeta_dimensionless')]
protocol=[]
for name,old,new,witness in mutations:
 assert text.count(old)==1
 p=unit/'damages'/name;p.mkdir(parents=True,exist_ok=False)
 damaged=text.replace(old,new,1);(p/'check_identity_damaged_v1.py').write_text(damaged)
 (p/'SOURCE.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),damaged.splitlines(True),fromfile='check_identity_v1.py',tofile=name+'/check_identity_damaged_v1.py')))
 protocol.append({'name':name,'old':old,'new':new,'intended_witness':witness,'script':'damages/'+name+'/check_identity_damaged_v1.py','script_sha256':hashlib.sha256(damaged.encode()).hexdigest()})
(unit/'DAMAGE_PROTOCOL_v1.json').write_text(json.dumps({'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_execution':True,'baseline_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'actual_changed_formulas':protocol},indent=2)+'\n')
def run(row):
 name=row['name'];argv=[sys.executable,str(unit/'run_recorded_v1.py'),'--script',row['script'],'--prefix','damages/'+name+'/run']
 proc=subprocess.run(argv,cwd=unit,capture_output=True,check=False)
 p=unit/'damages'/name
 (p/'HARNESS_STDOUT_v1.txt').write_bytes(proc.stdout);(p/'HARNESS_STDERR_v1.txt').write_bytes(proc.stderr)
 command=json.loads((p/'run_COMMAND_v1.json').read_text());result=json.loads((p/'run_RESULTS_v1.json').read_text())
 failed=[r['name'] for r in result['checks'] if not r['passed']]
 return {**row,'command_argv':argv,'harness_exit_code':proc.returncode,'checker_exit_code':command['exit_code'],'passed':result['passed'],'failed':result['failed'],'failed_names':failed,'intended_witness_failed':row['intended_witness'] in failed,'result_sha256':hashlib.sha256((p/'run_RESULTS_v1.json').read_bytes()).hexdigest(),'command_sha256':hashlib.sha256((p/'run_COMMAND_v1.json').read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 rows=list(ex.map(run,protocol))
summary={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executed':len(rows),'all_actual_damages_detected':all(r['checker_exit_code']==1 and r['intended_witness_failed'] for r in rows),'rows':rows}
(unit/'DAMAGE_RESULTS_v1.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
