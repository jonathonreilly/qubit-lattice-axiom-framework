#!/usr/bin/env python3
"""Run exactly one owned checker, retaining streams, argv, timing and hashes."""
import argparse,datetime,hashlib,json,os,platform,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--script',required=True);p.add_argument('--prefix',required=True);a=p.parse_args()
unit=Path(__file__).resolve().parent; script=(unit/a.script).resolve(); prefix=(unit/a.prefix).resolve()
assert unit in script.parents and unit in prefix.parents
prefix.parent.mkdir(parents=True,exist_ok=True)
result=str(prefix)+'_RESULTS_v1.json'; stdout=str(prefix)+'_STDOUT_v1.txt'; stderr=str(prefix)+'_STDERR_v1.txt'; command=str(prefix)+'_COMMAND_v1.json'
for f in [result,stdout,stderr,command]:
 if Path(f).exists():raise RuntimeError('refuse to overwrite '+f)
argv=[sys.executable,str(script),'--unit',str(unit),'--output',result]
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); start=time.perf_counter(); timeout=False
with open(stdout,'wb') as out,open(stderr,'wb') as err:
 try:
  proc=subprocess.run(argv,cwd=unit,stdout=out,stderr=err,timeout=55,check=False)
  code=proc.returncode
 except subprocess.TimeoutExpired:
  code=None;timeout=True

def binding(path):
 pp=Path(path);b=pp.read_bytes();return {'path':str(pp.relative_to(unit)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
record={'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(unit),'exit_code':code,'timeout_55_seconds':timeout,'elapsed_seconds':time.perf_counter()-start,'script':binding(script),'stdout':binding(stdout),'stderr':binding(stderr),'result':binding(result) if Path(result).exists() else None,'python':sys.executable,'runner':binding(__file__),'scope':'Independent owned check; no parent runner invoked.'}
Path(command).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
if Path(result).exists():
 j=json.loads(Path(result).read_text());print(json.dumps({'passed':j['passed'],'failed':j['failed'],'failed_names':[v['name'] for v in j['checks'] if not v['passed']]}))
sys.exit(0)
