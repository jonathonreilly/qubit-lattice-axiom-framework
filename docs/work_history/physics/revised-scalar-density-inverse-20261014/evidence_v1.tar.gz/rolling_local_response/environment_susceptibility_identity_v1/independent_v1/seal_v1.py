#!/usr/bin/env python3
"""Seal this independent evidence directory; never touch parent sources."""
import datetime,hashlib,json,sys
from pathlib import Path
unit=Path(__file__).resolve().parent
for name in ['MANIFEST_v1.json','RECEIPT_v1.json','SEAL_COMMAND_v1.json']:
 if (unit/name).exists():raise RuntimeError('refuse to replace existing seal '+name)
def read(n):return json.loads((unit/n).read_text())
def binding(n):
 p=unit/n;b=p.read_bytes();return {'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
(unit/'SEAL_COMMAND_v1.json').write_text(json.dumps({'started_utc':now,'argv':[sys.executable,*sys.argv],'cwd':str(Path.cwd()),'purpose':'Create the first manifest and receipt without replacing prior outputs. Completion is established by the resulting seal and subsequent read-only verification.','script':binding('seal_v1.py')},indent=2)+'\n')
base=read('baseline_RESULTS_v1.json');damage=read('DAMAGE_RESULTS_v1.json');verification=read('EVIDENCE_VERIFICATION_RESULTS_v1.json');pairs=read('SOURCE_BINDINGS_v1.json')['source_pairs']
assert (base['passed'],base['failed'])==(114,0)
assert (verification['passed'],verification['failed'])==(169,0)
assert damage['executed']==6 and damage['all_actual_damages_detected']
for pair in pairs:
 assert hashlib.sha256(Path(pair['original_path']).read_bytes()).hexdigest()==pair['sha256']
 assert binding(pair['snapshot_path'])['sha256']==pair['sha256']
artifacts=[]
for p in sorted(unit.rglob('*')):
 if p.is_symlink():raise RuntimeError('unexpected symlink '+str(p))
 if p.is_file():
  n=p.relative_to(unit).as_posix()
  if n not in ['MANIFEST_v1.json','RECEIPT_v1.json']:artifacts.append(binding(n))
manifest={'sealed_utc':now,'scope':'All files in this focused independent evidence unit except the manifest and receipt themselves.','artifact_count':len(artifacts),'artifacts':artifacts,'excludes':['MANIFEST_v1.json','RECEIPT_v1.json']}
(unit/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'sealed_utc':now,'type':'focused_independent_mathematical_check','checker':'/root/scalar_energy_check','direct_scientific_author':'/root','unit':str(unit),'status':'evidence sealed; no formal audit or landing authority','conclusion':'Source equations (1)-(9) agree under the stated local positive fixed-particle mass assumptions. No source correction required. General consistency identity, not a unique candidate or state selector.','report':binding('REPORT_v1.md'),'manifest':binding('MANIFEST_v1.json'),'artifact_count':len(artifacts),'source_pair_count':len(pairs),'source_bindings':binding('SOURCE_BINDINGS_v1.json'),'source_pairs':pairs,'final_author_source':binding('sources/DERIVATION_v1.md'),'author_protocol':binding('sources/PROTOCOL_v1.json'),'source_clarification_required':False,'hand_derivation':binding('HAND_DERIVATION_v1.md'),'hand_freeze':binding('HAND_FREEZE_v1.json'),'independent_protocol':binding('CONTROL_PROTOCOL_v1.json'),'new_mathematics':{'passed':base['passed'],'failed':base['failed'],'result':binding('baseline_RESULTS_v1.json'),'script':binding('check_identity_v1.py'),'command':binding('baseline_COMMAND_v1.json'),'reused_root_solves':False},'actual_damages':{'executed':6,'intended_failures_detected':6,'protocol':binding('DAMAGE_PROTOCOL_v1.json'),'result':binding('DAMAGE_RESULTS_v1.json'),'runs':[{'name':r['name'],'passed':r['passed'],'failed':r['failed'],'checker_exit_code':r['checker_exit_code'],'intended_witness':r['intended_witness'],'failed_names':r['failed_names'],'script':binding(r['script']),'result':binding('damages/'+r['name']+'/run_RESULTS_v1.json'),'command':binding('damages/'+r['name']+'/run_COMMAND_v1.json')} for r in damage['rows']]},'mechanical_verification':{'passed':verification['passed'],'failed':verification['failed'],'result':binding('EVIDENCE_VERIFICATION_RESULTS_v1.json'),'script':binding('verify_evidence_v1.py'),'command':binding('EVIDENCE_VERIFICATION_COMMAND_v1.json'),'scope':'Source bytes, actual execution records and selected prior-seal links; not additional mathematical tests.'},'reused_seals':[binding('reused/'+n) for n in ['DENSITY_REPORT_v1.md','DENSITY_MANIFEST_v1.json','DENSITY_RECEIPT_v1.json','DENSITY_BASELINE_RESULTS_v1.json','DENSITY_SUSCEPTIBILITY_RESULTS_v1.json']],'access_history':binding('ACCESS_HISTORY_v1.json'),'failure_log':binding('FAILURE_AND_SCOPE_LOG_v1.md'),'baseline_unexpected_failures':0,'baseline_repair_runs':0,'producer_code_or_results_accessed':False,'historical_access_disclosure':'The reused prior density report/receipt/manifest preserve a metadata-only accidental producer-diff copy after that prior unit science. The diff itself was not accessed or copied in this unit.','limitations':['Local branch near a stated stationary point, not a global branch or time evolution.','Mass is the fixed Einstein-proper particle-density scalar response, not automatically a different apparatus control response.','Positive mass hypothesis concerns prescribed scalars, not coupled fluid/metric stability.','B interval is necessary, not sufficient for multi-field positive mass.','Only one coupling-weighted mass contraction is reconstructed.','G_bare and density need common physical calibration; bounded gamma does not bound its derivative.','No actual body, measured data, empirical success, fundamental scales or unique action/state selected.','Prior roots were reused as exposed synthetic development decimals, without solving or interval certification.'],'operations_excluded':['producer/source modification','prior-seal modification','Git','network','runtime/lock/settings','PR','audit','new agent','other-chat operations']}
(unit/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'artifact_count':len(artifacts),'source_pair_count':len(pairs),'report':binding('REPORT_v1.md'),'manifest':binding('MANIFEST_v1.json'),'receipt':binding('RECEIPT_v1.json')},indent=2))
