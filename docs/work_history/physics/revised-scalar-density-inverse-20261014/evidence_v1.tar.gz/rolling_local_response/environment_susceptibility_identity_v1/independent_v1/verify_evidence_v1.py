#!/usr/bin/env python3
"""Mechanical evidence verification only; does not rerun mathematics."""
import datetime,hashlib,json,sys
from pathlib import Path
unit=Path(__file__).resolve().parent
rows=[]
def check(n,ok,d=None):rows.append({'name':n,'passed':bool(ok),'detail':d})
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(n):return json.loads((unit/n).read_text())
bindings=read('SOURCE_BINDINGS_v1.json')['source_pairs']
for b in bindings:
 live=Path(b['original_path']);snap=unit/b['snapshot_path']
 check('source.live.'+b['snapshot_path'],sha(live)==b['sha256'] and live.stat().st_size==b['bytes'])
 check('source.snapshot.'+b['snapshot_path'],sha(snap)==b['sha256'] and snap.stat().st_size==b['bytes'])
 check('source.byte_pair.'+b['snapshot_path'],live.read_bytes()==snap.read_bytes())
check('source.exact_pair_count',len(bindings)==10)
check('source.primary_expected_hash',sha(unit/'sources/DERIVATION_v1.md')=='fc8d310cef1ae01b8a709067fdb43ee45ecc58ddd217c2b577cdd86a0c10fcba')
hand=read('HAND_FREEZE_v1.json');basecmd=read('baseline_COMMAND_v1.json');base=read('baseline_RESULTS_v1.json')
check('sequence.hand_before_execution',hand['frozen_utc']<basecmd['started_utc'])
for a in hand['artifacts']:check('hand.freeze.'+a['path'],sha(unit/a['path'])==a['sha256'])
check('baseline.counts',base['passed']==114 and base['failed']==0 and len(base['checks'])==114)
check('baseline.actual_exit',basecmd['exit_code']==0 and not basecmd['timeout_55_seconds'])
check('baseline.script_exact',sha(unit/'check_identity_v1.py')==base['script_sha256']==basecmd['script']['sha256'])
check('baseline.source_exact',base['source_sha256']==sha(unit/'sources/DERIVATION_v1.md'))
check('baseline.hand_exact',base['hand_derivation_sha256']==sha(unit/'HAND_DERIVATION_v1.md'))
check('baseline.no_producer_import',base['producer_imported'] is False)
check('baseline.no_exception',not any(c['name']=='execution.exception' for c in base['checks']))
for key in ['script','stdout','stderr','result','runner']:
 b=basecmd[key];check('baseline.command_hash.'+key,sha(unit/b['path'])==b['sha256'] and (unit/b['path']).stat().st_size==b['bytes'])
check('baseline.output_stream_count', '"passed": 114' in (unit/basecmd['stdout']['path']).read_text() and '"failed": 0' in (unit/basecmd['stdout']['path']).read_text())
check('baseline.empty_stderr',(unit/basecmd['stderr']['path']).stat().st_size==0)
prior=read('reused/DENSITY_RECEIPT_v1.json');pm=read('reused/DENSITY_MANIFEST_v1.json')
expected={'DENSITY_REPORT_v1.md':'787afa9af5ec790350b51ef96df1e1e0c935690e92266a5242186b4e8f194dd9','DENSITY_MANIFEST_v1.json':'4277dfc4a1b0bacb8551c8212ba6323343cf51531a15195b437409289a0cc4fd','DENSITY_RECEIPT_v1.json':'e82004e2c5f13849b603a79cf677e63acca3c403a1e2639fb7b0eac72429ec86','DENSITY_BASELINE_RESULTS_v1.json':'41948637c37ab00483b15dc7da5329b78aacb04ec61ef50e1bf36c2c73206991','DENSITY_SUSCEPTIBILITY_RESULTS_v1.json':'01bdb98577358aa94138ed907dd7e3dbd31635db7f26f71a358e974e7619beec'}
for n,h in expected.items():check('reuse.exact_known_seal.'+n,sha(unit/'reused'/n)==h)
check('reuse.receipt_manifest_link',prior['manifest']['sha256']==sha(unit/'reused/DENSITY_MANIFEST_v1.json'))
check('reuse.receipt_report_link',prior['report']['sha256']==sha(unit/'reused/DENSITY_REPORT_v1.md'))
pm_by_name={r['path']:r for r in pm['artifacts']}
for original,copy in [('REPORT_v1.md','DENSITY_REPORT_v1.md'),('BASELINE_RESULTS_v1.json','DENSITY_BASELINE_RESULTS_v1.json'),('SUSCEPTIBILITY_RESULTS_v1.json','DENSITY_SUSCEPTIBILITY_RESULTS_v1.json')]:
 check('reuse.manifest_selected_artifact.'+original,pm_by_name[original]['sha256']==sha(unit/'reused'/copy))
for n,h in base['reused_outputs'].items():check('reuse.execution_binding.'+n,sha(unit/'reused'/n)==h)
check('reuse.no_root_solve_claim',len(base['examples']['candidate_reuse'])==6 and all(v['roots_resolved'] is False for v in base['examples']['candidate_reuse']))
check('reuse.prior_history_preserved',prior['contextual_unintended_pair_count']==1)
protocol=read('DAMAGE_PROTOCOL_v1.json');damage=read('DAMAGE_RESULTS_v1.json');orig=(unit/'check_identity_v1.py').read_text()
check('damages.count',len(damage['rows'])==6 and damage['executed']==6)
check('damages.summary_truth',damage['all_actual_damages_detected'] is True)
check('damages.bound_baseline',protocol['baseline_sha256']==sha(unit/'check_identity_v1.py'))
for d in damage['rows']:
 name=d['name'];p=unit/'damages'/name;j=json.loads((p/'run_RESULTS_v1.json').read_text());cmd=json.loads((p/'run_COMMAND_v1.json').read_text());failed=[x['name'] for x in j['checks'] if not x['passed']]
 check('damage.single_actual_edit.'+name,orig.count(d['old'])==1 and (unit/d['script']).read_text()==orig.replace(d['old'],d['new'],1))
 check('damage.script_hash.'+name,sha(unit/d['script'])==d['script_sha256']==cmd['script']['sha256']==j['script_sha256'])
 check('damage.result_hash.'+name,sha(p/'run_RESULTS_v1.json')==d['result_sha256'])
 check('damage.command_hash.'+name,sha(p/'run_COMMAND_v1.json')==d['command_sha256'])
 check('damage.actual_exit.'+name,cmd['exit_code']==d['checker_exit_code']==1 and not cmd['timeout_55_seconds'])
 check('damage.named_witness.'+name,d['intended_witness'] in failed and d['intended_witness_failed'])
 check('damage.failure_list.'+name,failed==d['failed_names'] and j['passed']==d['passed'] and j['failed']==d['failed'] and len(j['checks'])==114)
 check('damage.no_execution_exception.'+name,'execution.exception' not in failed)
 check('damage.frozen_before_run.'+name,protocol['frozen_utc']<cmd['started_utc'])
 for key in ['script','stdout','stderr','result','runner']:
  b=cmd[key];check('damage.command_hash.'+name+'.'+key,sha(unit/b['path'])==b['sha256'] and (unit/b['path']).stat().st_size==b['bytes'])
 check('damage.source_binding.'+name,j['source_sha256']==base['source_sha256'] and j['hand_derivation_sha256']==base['hand_derivation_sha256'])
 check('damage.no_producer_import.'+name,j['producer_imported'] is False)
report=(unit/'REPORT_v1.md').read_text()
check('report.source_hash',base['source_sha256'] in report)
check('report.counts','114/0' in report and '109 / 5' in report and '106 / 8' in report and '110 / 4' in report)
check('report.no_correction_claim','no equation error or required source clarification' in report)
check('report.probe_prescription_limit','fixed-particle mass in this theorem is not automatically the range' in report)
check('report.nonselection_limit','cannot by itself select the candidate potential' in report)
check('report.no_formal_audit','not a formal audit' in report)
check('report.reuse_history_preserved','historical metadata-only accidental producer-diff copy' in report)
result={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Mechanical source, execution and selected-reuse verification only; no science rerun.','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'script_sha256':sha(__file__),'report_sha256':sha(unit/'REPORT_v1.md')}
out=unit/'EVIDENCE_VERIFICATION_RESULTS_v1.json'
if out.exists():raise RuntimeError('refuse to overwrite prior verification result')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_names':[r['name'] for r in rows if not r['passed']],'result_sha256':sha(out)},indent=2))
sys.exit(0 if result['failed']==0 else 1)
