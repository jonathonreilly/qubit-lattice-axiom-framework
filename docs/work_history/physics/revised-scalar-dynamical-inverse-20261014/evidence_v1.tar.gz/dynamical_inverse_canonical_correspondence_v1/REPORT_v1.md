# Staged correspondence: local density dynamics and finite-window inverse

The staged note and runner correspond to the two previously checked hand results and preserved author implementations. No final-source correction is required. This unit verifies packaging and scope, reusing the independent 119/0 dynamics result and 200/0 weak-inverse result without rerunning their science. The new work is 72/0 source/output correspondence checks, 42/0 lightweight wrapper controls, and 300/0 final evidence-binding checks. Four actually executed wrapper-only damaged copies were rejected.

This is **staged-only correspondence**. No live canonical installation, fresh runner-cache fingerprint, recovery archive, committed five-path delta, PR, or current-main integration is certified by this receipt. Those require the later delivery check. /root remains scientific author; no formal audit or authority/status promotion occurred.

## Exact staged sources and input closure

| Staged artifact | SHA-256 |
|---|---|
| EXPONENTIAL_SCALAR_DYNAMICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md | c66c3366d6ac0f3f371fc5067b18fa39ff7df2670d51d5a7e2add0468684bd50 |
| exponential_scalar_dynamical_inverse_check.py | 18969b27613706909984ff584576371bad7cbe28e27a56f34c3e1b94bd86e55f |
| CANONICAL_LINEAGE_v1.json | 5719f2455ff7871176bbba91af26f8fa457c68f59724247b552165893a2b0727 |
| STAGED_RESULTS_v1.json and identical staged stdout | 36b0b083f4621e521b16c9ada14e27b31b97517381e7fe04fe9be7e24c1d55eb |
| STAGED_RUN_v1.json | 425502f06e9c1a05c8e8c94d73ed7b07ce16d814e163c2799820b61325169c12 |

The full staged note and runner, both original final scientific implementations, both sealed independent reports, and all three canonical premise notes were read. The four AUDIT_INPUT_PATHS entries are exactly the future canonical destination of this staged note plus the complete supplied-action, local-response, and density-inverse notes. Their current premise hashes are:

- Complete supplied action: 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000.
- Local response: b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68.
- Density/action inverse: 40f112537627dd19ea0090a673f355f0d122c52844853798287f55e5b671e3fb.

The supplied action retains kinetic normalization -Q K_AB, and the one-field local coordinate uses -Q(partial chi)^2, hence scalar kinetic coefficient 2Q. The referenced force normalization supplies G_bare=A²/(8pi Q), rho_E=A^4 rho_J and q=|d ln A|_K². The prior density inverse supplies the conditional fixed-particle mass/susceptibility relation M_J²/g_J=2/B-3. These are explicit supplied/reused premises; this packaging does not reconstruct the complete action or rerun the earlier multi-field/thermodynamic/cosmological results. The candidate q<1/3 enters the extra 4/3 growth ceiling, not the generic two-variable determinant. No measured G, density, sound speed, time scale or wave number is acquired here.

No campaign or repository helper module is imported by the staged scientific bodies. Their import closure is standard Python plus SymPy, NumPy, SciPy and mpmath. Constants are separated into DR_* and WI_*; neither body loads the other's mutation globals. The direct declared input inventory and 120-second timeout are recorded in CORRESPONDENCE_RESULTS_v1.json. The dependency-note links and future archive link are staged packaging references, not evidence of an already installed archive or cache.

## Reused independent seals, verified without mutation or rerun

Both complete reports were read and every artifact and live/snapshot pair in their receipts was verified byte for byte:

| Independent unit | Reused science | Verified artifacts / source pairs | Receipt SHA-256 |
|---|---|---|---|
| dynamical_density_response_v1/independent_v1 | Corrected 119/0; original 107/12 retained | 122 / 11 | 6d3d9fc5a8c86ca1b0b9870960d0e27309578e6f410742795e52a0012d5a059a |
| weak_density_inverse_v1/independent_v1 | 200/0 | 58 / 3 | dfd3fb2193e1dffb3b868a44697c051da6ae67dc09e4ee75a2e402dd355b5b31 |

The dynamics report/manifest hashes are 35aab539b2a2870b134c429a9aa295c06c1648b69008975fb79d2ea150c27482 and 4fcc906c11de1d6a54b4a8c0abae61d4ba17fc94938a771131b08f2a6477af52. The weak report/manifest hashes are 5ec68092b15d1a3d93fc334fbf0b32db77b10d5d8fad8d4980221d00c11aa072 and 601d81d277eab425c6b3c4bbacc0c1ab3390a1b85adfe17e77ef52662b0c6c48.

REUSED_SEAL_VERIFICATION_v1.json retains all 180 artifact checks and 14 original source-pair bindings. The original dynamics independent failure and repair were real: one SymPy generator identity, one unsimplified sign predicate and ten small-amplitude ODE accuracy failures, followed by a separately preserved corrected 119/0 run with unchanged model/cases/acceptance thresholds. Its seven actual damages remain distinct from the weak unit's seven actual damages. The old reviewer’s 42/0 source correction confirmation is reused, not counted as a new dynamics run. The primary Bean–Flanagan–Trodden PDF/convention reading is reused through that unchanged seal; this correspondence did not refetch the PDF or import its phenomenology.

Access disclosure is different for this new unit: producer code and recorded results were intentionally read for source correspondence after the blind science seals were complete. Nothing in either old seal was changed or retroactively described as producer-blind work done now.

## Complete proof and computational-body correspondence

The entire dynamics DERIVATION_v3 body, SHA 3e6449a1f10e47105cd29aae6ef0e47a4ea337c1d65500f6f2e582af77430ff4, appears in the canonical note with heading depth increased by one. The entire weak DERIVATION_v1 body, SHA c21ab6c6cd9abf4f9f7f50fd7f8a00a86bdfb7072177e7a91be51f063f397b58, is likewise preserved, with only its relative reference replaced by “the preceding material-dynamics derivation.” Complete-body string comparison verifies that no equation, hypothesis, proof paragraph or limitation was silently dropped.

The new opening connects the derived material response to the conditional inverse; the closing distinguishes original failures, source repairs, original science, new packaging and unresolved empirical assumptions. Its claims agree with the preserved records.

The original final author code hashes are:

- check_response_v2.py: 32986e1edb06b79dc9361e329561ca02af8bf2a668d769fa694e99655e89a910.
- check_weak_inverse_v2.py: 70410be5b74070c5dd5c2bddf7d3ff8bd2b1036bbd57a2d8b0c43e08d87147ba.

Independent AST comparison both reverses the allowed names on the complete function bodies and checks all selected top-level statements as contiguous blocks in the canonical module. Each block has 11 statements. Both transformed hashes match CANONICAL_LINEAGE_v1.json exactly: 6781534b1fae90b6a26b560e4042590ab4bc3a06a47bf70973d97c3a0d56b8f4 for dynamics and 6302dbb534f2a5e9721abb7f1f0ca049875b6ad53832270c5365f42e2b7a7df8 for the weak inverse. Formatting/comment removal and the declared function/global renaming are the only computational-body changes. The builder was read, not executed.

The scientific scope remains correct:

- Particle-number contrast per frozen Einstein proper volume, fixed-particle M² and the actual 2Q kinetic normalization are retained. The p=3 source-control mass is not substituted.
- The quotient p_eff requires nonzero driven beta X and a nonzero bare acoustic denominator, and removes no independent homogeneous fluid mode from the undivided system.
- Real-frequency i0 is confined to the stable bare acoustic resolvent. Full unstable response and b<0 use a growth-aware Laplace/Bromwich contour or finite-time fundamental solution.
- Strict and marginal stable long-wave branches both approach zero, with their distinct k² and k⁴ behavior. The all-k continuum statement establishes no measured material/background validity window; omitted NR corrections can matter near neutrality.
- The optional Jeans model subtracts the background and retains only a leading Newtonian local constraint. It is not a uniform gravitating Minkowski universe or a justification for ignoring Hubble-scale evolution.
- The weak inverse conditions uniqueness on actual feature rank and exact model/calibrations. A constant readout may hide a mode; a two-mode preparation alone does not guarantee rank. No initial phase/amplitude is supplied to the inverse.
- Uniform error, quadrature/sampling, numerical solve, calibration, instrument geometry and model-error requirements remain explicit. Floating displays are not outward error certificates or confidence levels. Negative inferred parameters would challenge the restricted model only with valid error/approximation bounds.
- The reserved wave number remains a same-model synthetic prediction control. No real traces, apparatus likelihood, observational fit, empirical exclusion, stable universe or selected fundamental action is claimed.

## Recorded 225/0 execution, complete output and profile recovery

The parent’s actual staged execution is 99/0 dynamics plus 126/0 weak inverse, totaling 225/0. Its complete stdout is byte-identical to STAGED_RESULTS_v1.json and stderr is empty. The command, runtime, zero exit and actual canonical runner hash are preserved. This is the parent's recorded fresh staged run, not a science run executed by this reviewer.

Every scientific JSON field matches the corresponding original corrected baseline, excluding **only** checker_sha256 because the actual executable bytes differ. Profile hashes are included in this stronger comparison. The original standalone checker identities remain in the source lineage and archived original outputs; canonical output binds the canonical runner.

All eight dynamics profile files and all four weak profile files are byte-identical to their originals. They were also opened with allow_pickle=False and compared key-by-key and array-by-array. The dynamics profiles retain 241 times, direct state, exact reference, energy, squared frequencies, ODE matrix and initial state. The weak profiles retain three 2049-point readout/noisy pairs and the reserved 2049-point profile. Full row outputs also retain the physical-density inverse and single-mode rank check. There was no original saved separate physical/single-mode NPZ to invent during packaging; their saved result rows are preserved as originally emitted.

The full weak RESULT file equals the weak aggregate payload, and captured weak stdout is preserved rather than discarded. COMPLETE_OUTPUT_CORRESPONDENCE_v1.json supplied by the author agrees with the independently performed comparisons.

The numerical repair histories remain distinct and recoverable:

| Author implementation | Original | Corrected | Retained repair |
|---|---:|---:|---|
| Dynamics | 93/6 | 99/0 | Tightened DOP853 rtol and atol only; same cases, equations, sample count and acceptance thresholds |
| Weak inverse | 123/3 | 126/0 | Explicit actual SymPy charpoly generator; known synthetic derivatives moved into the separate double Gaussian crosscheck, preserving the primary derivative-free high-precision inverse |

Both exact repair diffs reproduce from the saved code versions. The weak change is not permission to differentiate unknown noisy measurements. The separately executed 20/0 causal-domain and 8/0 long-wave controls are preserved and reported separately from 225; they were not relabeled as new canonical computations. The author's source corrections, initial hand-note parse failure, original streams/profiles and other retained development records remain available. ORIGINAL_INVENTORY_DISPOSITIONS_v1.json lists 122 original dynamics and 71 original weak files, excluding the independent units because their seals are separately bound. It is an exact recovery inventory, not a claim that a delivery archive already exists.

## New wrapper-only execution and nonvacuous controls

The staged module was loaded from its frozen snapshot, then both scientific functions were replaced by explicit, labeled non-science stubs before invoking main. No scientific body ran. TemporaryDirectory was redirected inside this allowed independent unit, preserving the wrapper's context management and cleanup behavior while avoiding writes elsewhere.

The 42/0 controls exercise explicit profile/output paths, the default temporary path, success and failure aggregation, complete nested unit payloads, captured weak stdout, actual self-hash, isolated dynamics/weak directories, retained requested profiles, temporary cleanup, preexisting-path preservation, mismatched weak return/result status, and propagated exceptions. Existing --out protection occurs after execution; the stub test confirms the file is preserved, without claiming an early preflight rejection.

Four one-edit copies of the actual complete staged runner were frozen and executed with the same stub harness:

| Wrapper damage | Passed / failed | Exit |
|---|---:|---:|
| Drop aggregate failure count | 40 / 2 | 1 |
| Discard full weak payload | 39 / 3 | 1 |
| Discard captured weak stdout | 39 / 3 | 1 |
| Remove weak status consistency assertion | 40 / 2 | 1 |

Full altered scripts, diffs, plans, commands, timestamps, stdout/stderr and all eight case records per run are retained. Expected assertion/RuntimeError scenarios inside the harness are deliberate controls, not unexplained execution failures. These 42 wrapper checks and four wrapper damages are new packaging evidence, not additional scientific experiments.

## Parent staged damages and final binding

The three complete parent-run damaged canonical programs were separately frozen and inspected without rerun. Their actual exits are 1, with force sign 189/36, weak IBP sign 207/18 and weak clock power 206/19. Each is exactly one planned edit to the staged runner, with its exact diff and actual source hash. All 225 rows, failure identities, full streams, aggregate results, subordinate weak results and all 12 profiles per damage remain recoverable. Failures occur only in the intended scientific unit; the other unit's complete scientific payload remains identical to baseline, excluding its actual checker hash.

The new 300/0 final binding check verifies these parent records, all four actual wrapper damages, the stronger full-output/profile-byte correspondence and all 177 live/snapshot pairs. No staged source changed during this check, so no affected-source correction receipt is necessary.

The first broad inventory display was truncated after printing the large staged result; a later combined report display was also truncated. The raw files were preserved, complete JSON was parsed structurally, and both full independent reports were reread separately. These were display/retrieval limitations, not omitted scientific failures. No unexpected correspondence or wrapper-baseline failure occurred.

SOURCE_BINDINGS_FINAL_v1.json, the three initial/additional/late binding records, COMMANDS_v1.json, execution records, complete reports and final manifest/receipt identify all sources and outputs. Earlier seals and parent files remain untouched. The staged result is ready for the author’s installation/cache/archive phase, followed by a separate committed/live delivery mapping. That later phase is outside this receipt.

