from pathlib import Path
import ast,copy,json,hashlib,difflib,re,datetime
import numpy as np
H=Path.cwd()
S=H/'sources'
R=S/'evidence/rolling_local_response'
P=S/'packaging'
N='EXPONENTIAL_SCALAR_DYNAMICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
C='exponential_scalar_dynamical_inverse_check.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jread=lambda p:json.loads(p.read_text())
rows=[]
def ck(name,truth,**detail):rows.append(dict(name=name,passed=bool(truth),**detail))
note=(P/'staged'/N).read_text()
canonical=ast.parse((P/'staged'/C).read_text())
lineage=jread(P/'CANONICAL_LINEAGE_v1.json')
# Independent port comparison: restore scientific bodies to their original names.
canon_functions={x.name:x for x in canonical.body if isinstance(x,ast.FunctionDef)}
ports=[]
for source,unit,target in [(lineage['scientific_sources'][0],'dynamical_density_response_v1','check_dynamics'),(lineage['scientific_sources'][1],'weak_density_inverse_v1','check_weak')]:
 original=R/unit/Path(source['path']).name
 original_tree=ast.parse(original.read_text())
 selected=[n for n in original_tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef))]
 reverse={v:k for k,v in source['renames'].items()}
 class Back(ast.NodeTransformer):
  def visit_Name(self,node):
   node.id=reverse.get(node.id,node.id);return node
  def visit_FunctionDef(self,node):
   node.name=reverse.get(node.name,node.name);return self.generic_visit(node)
 cfun=copy.deepcopy(canon_functions[target])
 restored=Back().visit(cfun)
 original_fun=next(n for n in selected if isinstance(n,ast.FunctionDef))
 ck(unit+'_full_function_ast_identical',ast.dump(restored,include_attributes=False)==ast.dump(original_fun,include_attributes=False))
 ck(unit+'_lineage_original_hash',sha(original)==source['sha256'])
 # Build transformed expected nodes by changing only the approved identifiers.
 expected=copy.deepcopy(selected)
 for node in expected:
  for part in ast.walk(node):
   if isinstance(part,ast.Name):part.id=source['renames'].get(part.id,part.id)
   elif isinstance(part,ast.FunctionDef):part.name=source['renames'].get(part.name,part.name)
 expect_dump=[ast.dump(n,include_attributes=False) for n in expected]
 canon_dump=[ast.dump(n,include_attributes=False) for n in canonical.body]
 starts=[i for i in range(len(canon_dump)-len(expect_dump)+1) if canon_dump[i:i+len(expect_dump)]==expect_dump]
 ck(unit+'_complete_science_block_contiguous',len(starts)==1,canonical_start=starts,statements=len(expected))
 digest=hashlib.sha256(ast.dump(ast.Module(body=expected,type_ignores=[]),include_attributes=False).encode()).hexdigest()
 ck(unit+'_lineage_transformed_ast_hash',digest==source['transformed_ast_sha256'])
 ports.append({'unit':unit,'original_sha256':sha(original),'canonical_function':target,'transformed_ast_sha256':digest,'contiguous_statement_count':len(expected),'canonical_start':starts})
for idx,(unit,version) in enumerate([('dynamical_density_response_v1',3),('weak_density_inverse_v1',1)]):
 hand=R/unit/f'DERIVATION_v{version}.md'
 # Explicitly allowed changes: one heading depth and one relative reference.
 expected='\n'.join('#'+line if line.startswith('#') else line for line in hand.read_text().replace('../dynamical_density_response_v1/DERIVATION_v3.md','the preceding material-dynamics derivation').splitlines())
 ck(unit+'_entire_hand_proof_ported',note.count(expected)==1)
 ck(unit+'_lineage_hand_hash',sha(hand)==lineage['hand_sources'][idx]['sha256'])
ck('staged_note_identity',sha(P/'staged'/N)==lineage['canonical_note']['sha256']=='c66c3366d6ac0f3f371fc5067b18fa39ff7df2670d51d5a7e2add0468684bd50')
ck('staged_runner_identity',sha(P/'staged'/C)==lineage['canonical_runner']['sha256']=='18969b27613706909984ff584576371bad7cbe28e27a56f34c3e1b94bd86e55f')
# Direct declared input closure; staged canonical destination is resolved locally to its snapshot.
assigns={n.targets[0].id:n.value for n in canonical.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
inputs=ast.literal_eval(assigns['AUDIT_INPUT_PATHS'])
expected_inputs=['docs/'+N]+['docs/'+p.name for p in sorted((S/'premises').glob('*.md'))]
ck('exact_direct_input_inventory',len(inputs)==4 and set(inputs)==set(expected_inputs),paths=inputs)
ck('timeout_declaration',ast.literal_eval(assigns['AUDIT_TIMEOUT_SEC'])==120)
imports=[]
for n in canonical.body:
 if isinstance(n,ast.Import):imports.extend(x.name for x in n.names)
 elif isinstance(n,ast.ImportFrom):imports.append(n.module)
ck('no_campaign_or_hidden_helper_imports',set(imports)=={'contextlib','tempfile','io','pathlib','json','hashlib','argparse','sympy','numpy','scipy.linalg','scipy.integrate','datetime','math','mpmath','scipy.special'},imports=imports)
ck('science_global_isolation',all(n in assigns for n in ['DR_FORCE_SIGN','DR_KINETIC_FACTOR','DR_MASS_SHIFT','DR_GRAVITY_SIGN','WI_IBP_SIGN','WI_TIME_POWER','WI_GRAVITY_SIGN','WI_MASS_SHIFT']))
for name in ['check_dynamics','check_weak']:
 loaded={n.id for n in ast.walk(canon_functions[name]) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}
 other='WI_' if name=='check_dynamics' else 'DR_'
 ck(name+'_no_other_block_mutation_globals',not any(x.startswith(other) for x in loaded))
# Recorded staged execution is evidence reuse, not a fresh run.
staged=jread(P/'STAGED_RESULTS_v1.json');run=jread(P/'STAGED_RUN_v1.json')
ck('staged_full_stdout_equals_output',(P/'STAGED_RESULTS_v1.json').read_bytes()==(P/'STAGED_RUN_v1.stdout').read_bytes())
ck('staged_execution_binding',run['exit_code']==0 and run['runner_sha256']==sha(P/'staged'/C) and staged['checker_sha256']==sha(P/'staged'/C))
ck('staged_empty_stderr',(P/'STAGED_RUN_v1.stderr').stat().st_size==0)
ck('staged_225_0',staged['passed']==225 and staged['failed']==0)
ck('staged_unit_count_sum',staged['passed']==sum(v['passed'] for v in staged['units'].values()) and staged['failed']==sum(v['failed'] for v in staged['units'].values()))
for unit,sub,count in [('dynamical_density_response_v1','dynamics',99),('weak_density_inverse_v1','weak_inverse',126)]:
 out=staged['units'][sub]
 ck(sub+'_all_saved_check_rows',len(out['checks'])==count and sum(bool(x['passed']) for x in out['checks'])==count and out['failed']==0)
 original=jread(R/unit/('RESULTS_v2.json' if sub=='dynamics' else 'baseline_v2/RESULTS.json'))
 o=copy.deepcopy(original);s=copy.deepcopy(out);o.pop('checker_sha256',None);s.pop('checker_sha256',None)
 if sub=='dynamics':
  for item in o['synthetic_cases']:item.pop('profile_sha256',None)
  for item in s['synthetic_cases']:item.pop('profile_sha256',None)
 ck(sub+'_all_scientific_output_values_preserved',o==s)
 if sub=='weak_inverse':
  saved=jread(S/'evidence/dynamical_inverse_packaging/staged_profiles_v1/weak_inverse/RESULTS.json')
  ck('weak_saved_result_equals_aggregate',saved==out)
  stdout=jread(R/unit/'STDOUT_v2.txt')
  ck('weak_original_stdout_preserved',json.loads(staged['weak_execution_stdout'])==stdout)
  ck('weak_canonical_self_hash',out['checker_sha256']==sha(P/'staged'/C))
profiles=[]
for sub,unit,original_dir in [('dynamics','dynamical_density_response_v1','profiles_v2'),('weak_inverse','weak_density_inverse_v1','baseline_v2')]:
 stage_dir=S/'evidence/dynamical_inverse_packaging/staged_profiles_v1'/sub
 original_dir=R/unit/original_dir
 for p in sorted(stage_dir.glob('*.npz')):
  original=original_dir/p.name
  with np.load(p,allow_pickle=False) as a,np.load(original,allow_pickle=False) as b:
   exact=set(a.files)==set(b.files) and all(np.array_equal(a[n],b[n],equal_nan=True) for n in a.files)
   finite=all(np.isfinite(a[n]).all() for n in a.files)
   shapes={n:list(a[n].shape) for n in a.files}
  ck(sub+'_'+p.name+'_profile_array_recovery',exact and finite)
  if sub=='dynamics':
   row=next(x for x in staged['units'][sub]['synthetic_cases'] if x['profile']==p.name)
   ck(sub+'_'+p.name+'_profile_hash_binding',sha(p)==row['profile_sha256'])
  profiles.append({'unit':sub,'name':p.name,'staged_sha256':sha(p),'original_sha256':sha(original),'arrays_equal':exact,'finite':finite,'shapes':shapes})
ck('profile_inventory_eight_plus_four',sum(x['unit']=='dynamics' for x in profiles)==8 and sum(x['unit']=='weak_inverse' for x in profiles)==4)
# Preserve the original failed numerical implementations and their narrow repairs.
repairs=[]
for unit,versions,counts in [('dynamical_density_response_v1',['RESULTS_v1.json','RESULTS_v2.json'],[(93,6),(99,0)]),('weak_density_inverse_v1',['baseline_v1/RESULTS.json','baseline_v2/RESULTS.json'],[(123,3),(126,0)])]:
 outcomes=[]
 for file,(passed,failed) in zip(versions,counts):
  out=jread(R/unit/file)
  failures=[r for r in out['checks'] if not r['passed']]
  ck(unit+'_'+file+'_original_counts_preserved',out['passed']==passed and out['failed']==failed and len(failures)==failed)
  outcomes.append({'path':str((R/unit/file).relative_to(H)),'sha256':sha(R/unit/file),'passed':passed,'failed':failed,'failed_checks':failures})
 code1=R/unit/('check_response_v1.py' if unit.startswith('dynamical') else 'check_weak_inverse_v1.py')
 code2=R/unit/('check_response_v2.py' if unit.startswith('dynamical') else 'check_weak_inverse_v2.py')
 actual=''.join(difflib.unified_diff(code1.read_text().splitlines(True),code2.read_text().splitlines(True),fromfile=('v1' if unit.startswith('dynamical') else code1.name),tofile=('v2' if unit.startswith('dynamical') else code2.name)))
 ck(unit+'_exact_preserved_repair_diff',actual==(R/unit/'CHECKER_v1_v2.diff').read_text())
 repairs.append({'unit':unit,'outcomes':outcomes,'repair_record_sha256':sha(R/unit/'NUMERICAL_REPAIR_v2.json'),'diff_sha256':sha(R/unit/'CHECKER_v1_v2.diff')})
for name,count in [('CAUSAL_RESULTS_v1.json',20),('LONG_WAVE_RESULTS_v1.json',8)]:
 out=jread(R/'dynamical_density_response_v1'/name)
 ck(name+'_separate_corrected_scope_controls',out['passed']==count and out['failed']==0)
# Required scientific qualifications, manually read in the complete note as well.
for label,needle in [('causal_growth','Laplace/Bromwich contour to the right'),('literal_quotient','nonzero driven beta X'),('both_no_gap','neither has a uniformly positive long-wave frequency gap'),('continuum_no_window','establishes no actual\nmaterial/background scale window'),('NR_approximation','not an exact relativistic barotropic-fluid theorem'),('background_subtraction','not a solution of\nthe full field equations'),('calibrations','Wavenumber, clock, sound speed and tensor coefficient cR are supplied calibrations.'),('strict_error_margin','eta<1'),('not_outward','not outward interval certificates'),('model_challenge','Extra residual/prediction checks'),('no_actual_data','No density data or apparatus likelihood has been acquired.')]:
 ck('scope_'+label,needle in note)
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Staged source/code/output correspondence; no new scientific execution','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'ports':ports,'profiles':profiles,'repairs':repairs,'direct_inputs':inputs,'code_sha256':sha(Path(__file__))}
print(json.dumps(record,indent=2))
raise SystemExit(bool(record['failed']))

