from pathlib import Path
import copy,difflib,json,hashlib,datetime
import numpy as np
H=Path.cwd();P=H/'sources/packaging';R=H/'sources/evidence/rolling_local_response';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
checks=[]
def ck(name,v,**detail):checks.append(dict(name=name,passed=bool(v),**detail))
base=read(P/'STAGED_RESULTS_v1.json');basecode=P/'staged/exponential_scalar_dynamical_inverse_check.py';btext=basecode.read_text()
# Strengthen earlier array correspondence to exact recorded bytes and every scientific JSON field.
for unit,key,fn in [('dynamical_density_response_v1','dynamics','RESULTS_v2.json'),('weak_density_inverse_v1','weak_inverse','baseline_v2/RESULTS.json')]:
 a=copy.deepcopy(base['units'][key]);b=read(R/unit/fn);a.pop('checker_sha256',None);b.pop('checker_sha256',None)
 ck(key+'_full_json_equal_excluding_only_checker_hash',a==b)
for row in read(H/'CORRESPONDENCE_RESULTS_v1.json')['profiles']:
 ck(row['unit']+'_'+row['name']+'_byte_identical_original',row['staged_sha256']==row['original_sha256'])
parent_summary=read(P/'damages_v1/SUMMARY_v1.json');plan=read(P/'damages_v1/PLAN_v1.json');damages=[]
ck('parent_damage_plan_base_identity',plan['base_sha256']==sha(basecode))
for (name,old,new),rec,expected in zip(plan['cases'],parent_summary,[(189,36),(207,18),(206,19)]):
 folder=P/'damages_v1';script=folder/(name+'.py');result=read(folder/(name+'_results.json'));exe=read(folder/(name+'_execution.json'))
 ck(name+'_one_actual_code_edit',btext.count(old)==1 and script.read_text()==btext.replace(old,new))
 ck(name+'_source_hash_binding',sha(script)==rec['source_sha256']==exe['source_sha256']==result['checker_sha256'])
 delta=''.join(difflib.unified_diff(btext.splitlines(True),script.read_text().splitlines(True),fromfile=basecode.name,tofile=script.name))
 ck(name+'_exact_diff',delta==(folder/(name+'.diff')).read_text())
 ck(name+'_exit_and_failure_counts',rec['exit_code']==exe['exit_code']==1 and (result['passed'],result['failed'])==expected and (rec['passed'],rec['failed'])==expected)
 ck(name+'_full_stdout_output_identity',(folder/(name+'.stdout')).read_bytes()==(folder/(name+'_results.json')).read_bytes() and (folder/(name+'.stderr')).stat().st_size==0)
 all_rows=[(key,row) for key,value in result['units'].items() for row in value['checks']]
 failures=[{'unit':key,**row} for key,row in all_rows if not row['passed']]
 ck(name+'_complete_rows_and_counts',len(all_rows)==225 and len(failures)==result['failed'] and sum(x['passed'] for x in result['units'].values())==result['passed'])
 affected='dynamics' if name=='force_sign' else 'weak_inverse';other='weak_inverse' if affected=='dynamics' else 'dynamics'
 unaffected=copy.deepcopy(result['units'][other]);original=copy.deepcopy(base['units'][other]);unaffected.pop('checker_sha256',None);original.pop('checker_sha256',None)
 ck(name+'_unaffected_unit_exactly_retained',unaffected==original)
 ck(name+'_designated_unit_failed',all(f['unit']==affected for f in failures))
 pdata=[]
 for p in sorted((folder/(name+'_profiles')).rglob('*.npz')):
  with np.load(p,allow_pickle=False) as arrays:finite=all(np.isfinite(arrays[n]).all() for n in arrays.files);shapes={n:list(arrays[n].shape) for n in arrays.files}
  if p.parent.name=='dynamics':
   row=next(x for x in result['units']['dynamics']['synthetic_cases'] if x['profile']==p.name)
   ck(name+'_'+p.name+'_profile_bound',sha(p)==row['profile_sha256'])
  ck(name+'_'+p.parent.name+'_'+p.name+'_full_profile_finite',finite)
  pdata.append({'path':str(p.relative_to(H)),'sha256':sha(p),'shapes':shapes})
 ck(name+'_all_twelve_profiles_retained',len(pdata)==12)
 weak=read(folder/(name+'_profiles/weak_inverse/RESULTS.json'))
 ck(name+'_full_weak_file_in_aggregate',weak==result['units']['weak_inverse'])
 captured=json.loads(result['weak_execution_stdout'])
 ck(name+'_captured_weak_counts_retained',captured['passed']==weak['passed'] and captured['failed']==weak['failed'])
 damages.append({'name':name,'passed':result['passed'],'failed':result['failed'],'source_sha256':sha(script),'result_sha256':sha(folder/(name+'_results.json')),'failed_rows':failures,'profiles':pdata,'execution':exe})
# The four new wrapper damages are separate, and executed no science function.
wr=read(H/'wrapper_damages_v1/RECEIPT_v1.json');wp=read(H/'wrapper_damages_v1/PLAN_v1.json')
ck('wrapper_damage_plan_bound',sha(H/'wrapper_damages_v1/PLAN_v1.json')==wr['plan_sha256'])
ck('wrapper_baseline_42_0',(read(H/'WRAPPER_RESULTS_v1.json')['passed'],read(H/'WRAPPER_RESULTS_v1.json')['failed'])==(42,0))
for plan,rec in zip(wp['mutations'],wr['runs']):
 name=rec['name'];source=H/plan['source_path'];out=read(H/rec['stdout_path'])
 ck(name+'_stub_damage_bound',sha(source)==plan['source_sha256']==rec['source_sha256']==out['target_sha256'] and sha(H/rec['stdout_path'])==rec['stdout_sha256'])
 ck(name+'_stub_actual_rejection',rec['exit']==1 and rec['intended_rejection'] and out['failed']>0 and all(n in rec['failed_checks'] for n in plan['required_failed_checks']))
 ck(name+'_stub_full_records',len(out['cases'])==8 and len(out['checks'])==42)
# Final staged source freeze: preserve all exact original/snapshot pair identities.
pairs=[]
for n in ['SOURCE_BINDINGS_INITIAL_v1.json','SOURCE_BINDINGS_ADDITIONAL_v1.json','SOURCE_BINDINGS_LATE_v1.json']:
 pairs.extend(read(H/n)['source_pairs'])
ck('unique_source_pairs',len({x['original_path'] for x in pairs})==len(pairs))
for i,row in enumerate(pairs):
 live=Path(row['original_path']);snap=H/row['snapshot_path']
 ck('final_source_pair_'+str(i),sha(live)==sha(snap)==row['sha256'] and live.stat().st_size==snap.stat().st_size==row['bytes'])
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Final staged evidence identity and actually executed parent-damage correspondence; no science rerun','passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'source_pairs':pairs,'parent_staged_damages':damages,'code_sha256':sha(Path(__file__))}
print(json.dumps(out,indent=2));raise SystemExit(bool(out['failed']))

