from pathlib import Path
import argparse,contextlib,datetime,hashlib,io,json,sys,tempfile,types
parser=argparse.ArgumentParser()
parser.add_argument('--target',type=Path,required=True)
parser.add_argument('--work',type=Path,required=True)
args=parser.parse_args()
target=args.target.resolve();work=args.work.resolve();work.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[];cases=[]
def ck(name,value,**data):checks.append(dict(name=name,passed=bool(value),**data))
def execute(name,profile_option=True,out_option=True,dfail=0,wfail=0,behavior=None):
 folder=work/name;folder.mkdir()
 module=types.ModuleType('independent_wrapper_target_'+name);module.__file__=str(target)
 exec(compile(target.read_text(),str(target),'exec'),module.__dict__)
 calls=[];temp_paths=[]
 dvalue={'passed':3,'failed':dfail,'checks':[{'name':'d'+str(i),'passed':i<3,'payload':{'matrix':[[i,1],[2,3]],'sentinel':'dynamics full row'}} for i in range(3+dfail)],'synthetic_cases':[{'profile':'profile.stub.txt','nested':[1,2,{'state':'unchanged'}]}],'scope':'NONSCIENCE WRAPPER STUB'}
 wvalue={'passed':5,'failed':wfail,'checks':[{'name':'w'+str(i),'passed':i<5,'payload':{'moments':[i,4,9],'sentinel':'weak full row'}} for i in range(5+wfail)],'cases':[{'M2':'stub','q':'stub','features':[[1,2],[3,4]],'all_extra_fields':'kept'}],'scope':'NONSCIENCE WRAPPER STUB','checker_sha256':'stub identifier, not source provenance'}
 weak_print='stub weak stdout\n{"marker":"all kept"}\n'
 def dynamics(p):
  calls.append({'unit':'dynamics','path':str(p)})
  if behavior=='dynamics_exception':raise RuntimeError('deliberate dynamics stub failure')
  p.mkdir();(p/'profile.stub.txt').write_text('not science data: dynamics\n')
  return dvalue
 def weak(p):
  calls.append({'unit':'weak_inverse','path':str(p)})
  if behavior=='weak_exception':raise RuntimeError('deliberate weak stub failure')
  p.mkdir();(p/'profile.stub.txt').write_text('not science data: weak\n')
  (p/'RESULTS.json').write_text(json.dumps(wvalue,indent=2)+'\n')
  print(weak_print,end='')
  return wfail+1 if behavior=='mismatched_weak_status' else wfail
 module.check_dynamics=dynamics;module.check_weak=weak
 def local_temp(**kw):
  t=tempfile.TemporaryDirectory(dir=folder,**kw);temp_paths.append(t.name);return t
 module.TemporaryDirectory=local_temp
 profiles=folder/'profiles';output=folder/'aggregate.json'
 if behavior=='preexisting_profiles':profiles.mkdir();(profiles/'keep.txt').write_text('preserve profile directory\n')
 if behavior=='preexisting_output':output.write_text('preserve output\n')
 argv=[str(target)]
 if profile_option:argv+=['--profiles',str(profiles)]
 if out_option:argv+=['--out',str(output)]
 original_argv=sys.argv;sys.argv=argv;stdout=io.StringIO();return_value=None;error=None
 try:
  with contextlib.redirect_stdout(stdout):return_value=module.main()
 except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
 finally:sys.argv=original_argv
 stream=stdout.getvalue();(folder/'captured_stdout.txt').write_text(stream)
 parsed=None
 if error is None:
  try:parsed=json.loads(stream)
  except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
 row={'name':name,'argv':argv,'calls':calls,'return_value':return_value,'error':error,'stdout':stream,'temporary_paths':temp_paths,'target_sha256':sha(target),'expected_dynamics':dvalue,'expected_weak':wvalue,'expected_weak_stdout':weak_print}
 (folder/'CASE_RECORD.json').write_text(json.dumps(row,indent=2)+'\n');cases.append(row)
 if behavior in ['preexisting_profiles','preexisting_output','mismatched_weak_status']:
  ck(name+'_raises_assertion',error is not None and error['type']=='AssertionError')
  ck(name+'_no_false_aggregate',stream=='')
  if behavior=='preexisting_profiles':
   ck(name+'_no_science_stub_called',calls==[])
   ck(name+'_existing_data_preserved',(profiles/'keep.txt').read_text()=='preserve profile directory\n')
  elif behavior=='preexisting_output':ck(name+'_existing_data_preserved',output.read_text()=='preserve output\n')
  return
 if behavior in ['dynamics_exception','weak_exception']:
  ck(name+'_propagates_exception',error is not None and error['type']=='RuntimeError')
  ck(name+'_no_false_aggregate',stream=='' and not output.exists())
  return
 ck(name+'_completes',error is None)
 if parsed is None:return
 ck(name+'_aggregate_counts',parsed['passed']==8 and parsed['failed']==dfail+wfail)
 ck(name+'_full_dynamics_preserved',parsed['units']['dynamics']==dvalue)
 ck(name+'_full_weak_preserved',parsed['units']['weak_inverse']==wvalue)
 ck(name+'_weak_stdout_preserved',parsed['weak_execution_stdout']==weak_print)
 ck(name+'_return_tracks_any_failure',return_value==bool(dfail+wfail))
 ck(name+'_canonical_self_hash',parsed['checker_sha256']==sha(target))
 ck(name+'_isolated_children',len(calls)==2 and Path(calls[0]['path']).name=='dynamics' and Path(calls[1]['path']).name=='weak_inverse' and Path(calls[0]['path']).parent==Path(calls[1]['path']).parent)
 if out_option:ck(name+'_exact_output_stream',output.read_text()==stream)
 if profile_option:ck(name+'_retains_requested_profiles',(profiles/'dynamics/profile.stub.txt').is_file() and (profiles/'weak_inverse/profile.stub.txt').is_file())
 else:ck(name+'_temporary_profiles_cleaned',bool(temp_paths) and all(not Path(x).exists() for x in temp_paths))
execute('full_success')
execute('aggregate_failures',dfail=1,wfail=2)
execute('temporary_success',profile_option=False,out_option=False)
execute('preexisting_profiles',behavior='preexisting_profiles')
execute('preexisting_output',behavior='preexisting_output')
execute('mismatched_weak_status',behavior='mismatched_weak_status')
execute('dynamics_exception',behavior='dynamics_exception')
execute('weak_exception',behavior='weak_exception')
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'NEW NONSCIENCE wrapper behavior controls using explicit stubs; no scientific body called','target_path':str(target),'target_sha256':sha(target),'harness_sha256':sha(Path(__file__)),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'cases':cases,'temporary_directory_override':'The canonical tempfile factory is restricted to this allowed independent unit. Its context management and wrapper branch remain exercised.'}
print(json.dumps(out,indent=2))
raise SystemExit(bool(out['failed']))

