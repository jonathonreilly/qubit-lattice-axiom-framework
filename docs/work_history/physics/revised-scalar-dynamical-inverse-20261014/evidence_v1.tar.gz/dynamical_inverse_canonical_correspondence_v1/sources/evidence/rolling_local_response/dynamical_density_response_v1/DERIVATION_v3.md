# Deriving the density constraint from local material dynamics

Personally derived by /root. This is a conditional local nonrelativistic response
calculation, not a self-consistent cosmological or laboratory background. It asks
whether the prescribed p in the preceding action inverse follows from moving
matter. A compressional constitutive law and its sound speed remain inputs.
All later numerical examples will be exposed synthetic development controls.

## 1. Declared limit and independent variables

Use a frozen stationary scalar chi0 and density rhoE=A0 rhoStar0. The scalar
kinetic coefficient is -Q(partial chi)^2, beta=d ln A/d chi at the point, q=beta^2,
and M^2>0 is the fixed-particle Einstein mass squared. Define cR=rhoE/(2Q)>0.
Write X=delta chi and delta=delta nE/nE0=delta rhoStar/rhoStar0. Both are varied;
the scalar does not stipulate the density variation. A0 is constant in this
linearized patch, so all inverse lengths/frequencies transform by 1/A0 into
physical units and cR/A0^2=4 pi Gbare rhoJ in natural units.

We retain the leading nonrelativistic rest-mass source and scalar force. Inertial
mass density is rhoE, the prescribed linear compressional law is deltaP/rhoE=
v_s^2 delta, and 0<=v_s^2<<1. Contributions of pressure/internal energy to the
scalar trace and inertia, their conformal dependence, dissipative transport,
boundary supports, inhomogeneity and expansion are not included. The formulas
are exact for the specified quadratic model and leading order for such matter,
not an exact relativistic barotropic-fluid theorem. A measured sound speed would
be a calibration input; it is not derived from the scalar action.

Continuity and the particle force from -m_J integral A dsE give

 delta_dot+div v=0,
 v_dot=-v_s^2 grad delta-beta grad X-grad Psi.

Scalar variation at fixed particle data before linearization gives

 X_ddot-laplacian X+M^2 X=-cR beta delta.                 (1)

No p has been supplied. The coefficient M^2 includes the A second derivative in
the fixed-particle effective potential. In particular, it is not the p=3 mass.

Initially set Psi=0 (externally frozen metric), so the density equation is

 delta_ddot-v_s^2 laplacian delta=beta laplacian X.       (2)

A quadratic longitudinal displacement model verifies reciprocity. If delta=
-div xi, its kinetic and potential densities are

 L2=Q[X_dot^2-(grad X)^2-M^2 X^2]
       +rhoE |xi_dot|^2/2-rhoE v_s^2(div xi)^2/2
       +rhoE beta X div xi.

It is the rest-particle cross term plus the supplied compressional modulus;
variation gives (1),(2). It does not derive the modulus or neglect corrections
by pretending matter was pressureless at all orders.

## 2. Frequency-dependent density response and coupled poles

For wave number k>0 and Fourier convention exp(i k.x-i omega t), define x=k^2,
y=omega^2, a=x+M^2, b=v_s^2 x and g=cR q. The coupled equations are

 (a-y)X+cR beta delta=0,
 beta x X+(b-y)delta=0.

When b-y is nonzero, the driven density response with zero independent fluid
homogeneous perturbation is

 delta=-beta x X/(b-y),
 p_eff(omega,k):=delta ln rhoStar/delta ln A=-x/(b-y).    (3)

The literal quotient also requires a nonzero driven beta X. At beta=0 the
sectors decouple and this quotient is undefined, rather than a measured p.

For the stable bare acoustic resolvent, the retarded boundary prescription
replaces omega by omega+i0. A full coupled system with an exponentially growing
pole does not have a convergent real-frequency retarded transform. Its causal
initial-value response must instead use a Laplace/Bromwich contour to the right
of all growing poles, or the finite-time fundamental solution. This qualification
also applies when b<0 after the Jeans replacement below. The algebraic harmonic
determinant remains valid. For an initial-value problem the independent fluid
homogeneous solution must be added; division by b-y is not valid at the bare
acoustic pole. Therefore a local constant p is not
inferred from particle conservation. At high frequency p_eff tends to zero;
at zero frequency and v_s^2>0 it is -1/v_s^2, not +3. A constant physical-density
constraint p=3 needs separately controlled matter/geometry or a reservoir.
For dust the zero-frequency division is singular rather than a finite static
response. These statements apply to this freely moving specified material.

The scalar-only response has the frequency-dependent term

 a-y-g x/(b-y),

but the coupled determinant, valid also near b-y=0, is

 (a-y)(b-y)-g x=0.                                     (4)

A real canonical change delta=sqrt(x/cR) D makes the matrix in (X,D) symmetric,
with off-diagonal beta sqrt(cR x). Its two squared frequencies are

 y_+,-=(a+b +/- sqrt((a-b)^2+4g x))/2.                  (5)

For v_s^2>0, both are positive precisely when v_s^2(x+M^2)>g.
Equality gives a neutral mode; below it one coupled mode grows despite M^2>0.
With v_s=0 and g>0 there is a negative mode at each finite nonzero k; this is
scalar-mediated compression in a frozen patch, not proof of fast cosmological
instability. The growth rate gamma satisfies

 gamma^2=-v_s^2 x+g x/(x+M^2+gamma^2)<=g.

For a positive fixed-particle stationary branch, the previous identity supplies
M_J^2/g_J=2/B-3 with g_J=4 pi Gbare rhoJ q. Hence positivity of all k>0 modes in
this frozen-metric model is equivalent to

 B <= 2 v_s^2/(1+3v_s^2),                              (6)

where equality still has a positive frequency squared at each k>0, with the
smaller branch behaving as v_s^2 k^4/M^2 near k=0. In the strict case it
instead begins as (v_s^2-g/M^2) k^2. Both tend to zero as k tends to zero;
neither has a uniformly positive long-wave frequency gap. This uses 0<B<2/3, q>0 and finite masses; beta=0 is separate. It is a
leading nonrelativistic model criterion, not a measured material limit. The
all-k statement is a property of that ideal continuum: it establishes no actual
material/background scale window, and omitted NR corrections can shift a
near-neutral physical stability boundary.

## 3. Include leading tensor gravity without inventing a static universe

A uniform gravitating dust background in Minkowski space is not a solution of
the full field equations. To discuss subregion Jeans response one may retain
only the nonzero-k density perturbation in the leading Newtonian Poisson
constraint and subtract the homogeneous background. This local approximation
requires a domain/scale/time window compatible with the actual background; it
does not justify neglecting expansion at a Hubble-rate instability.

At a scalar stationary point V_E,chi=-rhoE beta. The linear rest-energy change
rhoE(delta+beta X) and scalar-potential change -rhoE beta X cancel in their X
parts. Thus, at this order and with scalar gradients quadratic,

 laplacian Psi=cR delta.

Pressure, metric-volume/time corrections and background curvature are beyond
this leading Newtonian patch. Then the density equation becomes

 delta_ddot+(v_s^2 x-cR)delta=-beta x X,

so (3)-(5) hold with b=v_s^2 x-cR. For M^2>0, v_s^2>0 there is one positive
threshold x_J at which a coupled frequency vanishes:

 v_s^2 x_J^2+[v_s^2 M^2-cR(1+q)]x_J-cR M^2=0,
 x_J=[cR(1+q)-v_s^2 M^2
       +sqrt([v_s^2 M^2-cR(1+q)]^2+4v_s^2 cR M^2)]/(2v_s^2).

The exact defining equation also gives

 cR/v_s^2 < x_J < cR(1+q)/v_s^2                       (7)

for q>0 and M^2>0; the limiting equalities require a decoupling or singular limit.
For x>x_J both frequencies are positive; below it one is negative. This model's
instability has

 gamma^2=cR-v_s^2 x+g x/(x+M^2+gamma^2)
           < cR(1+q) < (4/3)cR                       (8)

for the supplied candidate q<1/3, finite k and M^2>0. Thus the local growing
rate cannot become arbitrarily larger than the tensor-gravity free-fall rate
under these premises. If that rate is comparable to the real background's
expansion/curvature rate, this frozen-patch calculation alone cannot decide
cosmological growth. A pressure-free medium has no finite Jeans wave number;
setting v_s=0 in a formula that divides by v_s^2 is invalid.

## 4. What is eliminated, what remains, and source comparison

The arbitrary constant p is replaced by a derived dispersive response for a
specified free compressional medium, together with its independent initial mode.
It is not universally eliminated for an unspecified laboratory. Preparing a
particular stationary scalar branch, choosing the matter constitutive law,
providing boundaries/supports, selecting initial perturbations, and establishing
a measured scale window remain separate assumptions. The ideal Gbare and B
inverse inputs have still not been measured. No new observational rejection or
statistical confidence level follows from (6)-(8).

As a development-stage convention check, Bean, Flanagan and Trodden,
https://arxiv.org/pdf/0709.1128v2, give particle-number conservation and conformal
force in Eqs.(2.12)-(2.13), and discuss the local Jeans interpretation and limits
of an adiabatic reduction. The mapping is their canonical field phi=sqrt(2Q)chi,
Planck mass squared Q and alpha=ln A, so 2Q alpha_phi^2=q. Their separate dark
sector phenomenology and strong-coupling exclusions are not imported. The
present dispersion and source-control formulas are derived above, not claimed
to discover that known instability mechanism for the first time.

Before execution: independently derive the quadratic Euler-Lagrange system,
canonical symmetry and determinant; test the divided versus undivided pole;
verify roots, static/high-frequency limits, both stability domains, Jeans
threshold and growth ceiling; compare exact matrix exponentials with direct
linear ODE integration on frozen synthetic stable and unstable cases. Preserve
all profiles and failure records. Deliberately altered force sign, kinetic
normalization, scalar mass prescription and gravity sign must trigger failures.
No synthetic example will be used to tune a measured density or coupling.
