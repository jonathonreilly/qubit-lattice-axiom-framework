from pathlib import Path
import sympy as s
import json,hashlib,datetime
rows=[]
def eq(name,e):
 v=s.factor(s.cancel(e));rows.append({'name':name,'passed':v==0,'residual':str(v)})
def ck(name,ok):rows.append({'name':name,'passed':bool(ok)})
t,gap,gamma,omega=s.symbols('t gap gamma omega',positive=True)
G=s.sinh(gamma*t)/gamma
# Retarded Green function for t>0; the unit first derivative supplies the impulse.
eq('unstable_homogeneous_Green',s.diff(G,t,2)-gamma**2*G)
eq('Green_zero_initial_value',G.subs(t,0))
eq('Green_unit_initial_velocity',s.diff(G,t).subs(t,0)-1)
z=gamma+gap
L=(1/(z-gamma)-1/(z+gamma))/(2*gamma)
eq('causal_Laplace_transform',L-1/(z*z-gamma**2))
ck('Bromwich_contour_right_of_growth',z-gamma>0)
ck('real_frequency_no_absolute_decay',gamma>0)
Gs=s.sin(omega*t)/omega
eq('stable_homogeneous_Green',s.diff(Gs,t,2)+omega**2*Gs)
Ls=(1/(gap-s.I*omega)-1/(gap+s.I*omega))/(2*s.I*omega)
eq('stable_Laplace_resolvent',Ls-1/(gap*gap+omega**2))
# A full coupled unstable example has a causal finite-time fundamental matrix
# regardless of its lack of a convergent Fourier transform on the real axis.
A=s.Matrix([[0,1],[4,0]]);I=s.eye(2);fund=s.cosh(2*t)*I+s.sinh(2*t)*A/2
for i in range(2):
 for j in range(2):
  eq('fundamental_ODE_'+str((i,j)),(fund.diff(t)-A*fund)[i,j])
  eq('fundamental_initial_'+str((i,j)),(fund.subs(t,0)-I)[i,j])
zz=2+gap;res=(zz*I-A).inv();pred=(zz*I+A)/(zz*zz-4)
for i in range(2):
 for j in range(2):eq('full_resolvent_'+str((i,j)),(res-pred)[i,j])
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'scope':'Affected causal-transform domain only; no original99-control rerun','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};out=Path(__file__).parent/'CAUSAL_RESULTS_v1.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':r['passed'],'failed':r['failed']}));raise SystemExit(bool(r['failed']))
