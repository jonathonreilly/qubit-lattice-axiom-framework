from pathlib import Path
import sympy as s
import json,hashlib
x,m,g,v=s.symbols('k_squared M_squared g vs_squared',positive=True)
l1=v-g/m;l2=g*(1-v+g/m)/m**2;y=l1*x+l2*x**2
poly=s.expand((x+m-y)*(v*x-y)-g*x)
rows=[]
def eq(n,e):
 z=s.factor(s.cancel(e));rows.append({'name':n,'passed':z==0,'residual':str(z)})
eq('low_k_coefficient_linear',poly.coeff(x,1))
eq('low_k_coefficient_quadratic',poly.coeff(x,2))
eq('threshold_vanishing_linear',l1.subs(g,v*m))
eq('threshold_positive_k4_coefficient',l2.subs(g,v*m)-v/m)
root=(m+(1+v)*x-s.sqrt((m+(1-v)*x)**2+4*g*x))/2
eq('all_cases_zero_long_wave_gap',root.subs(x,0))
eq('root_first_derivative',s.diff(root,x).subs(x,0)-l1)
eq('root_second_derivative',s.diff(root,x,2).subs(x,0)/2-l2)
e=s.symbols('positive_margin',positive=True)
eq('strict_stability_slope',l1.subs(g,m*(v-e))-e)
r={'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'scope':'Affected long-wave source clarification; no repeated99 baseline or20 causal controls','checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};f=Path(__file__).parent/'LONG_WAVE_RESULTS_v1.json';assert not f.exists();f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':r['passed'],'failed':r['failed']}));raise SystemExit(bool(r['failed']))
