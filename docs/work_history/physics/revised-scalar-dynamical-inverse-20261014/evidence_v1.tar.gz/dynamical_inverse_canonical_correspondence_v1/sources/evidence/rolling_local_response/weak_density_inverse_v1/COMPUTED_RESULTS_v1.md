# Finite-history inverse: direct calculation

The frozen synthetic protocol recovered M^2=4 and q=0.2 for three independent amplitude/phase choices without supplying those choices to the inversion. The constant physical-density readout recovers the same coefficients. The single-frequency feature matrix is singular, as proved. At the reserved k=11, parameters inferred only at k=8 predict both coefficients and weak residuals; this is a synthetic prediction control, not empirical validation.

The corrected checker passes126/0. Original123/3 is preserved: one SymPy generator identity and two double Gaussian cancellation errors. The high-precision primary weak integrals and acceptance thresholds did not change; the independent double control now integrates known synthetic derivatives against the lower-order kernels. It is not a method for differentiating experimental data. Four actual altered programs fail18,19,20,20 checks.

The infinity-norm feature conditioning ranges26.38 to474.42. A uniform readout error1e-17 on signals of scale1e-5 gives conservative coefficient certificates; the largest mass-squared bound is0.008546 and the largest q bound0.000224. These assume exact calibrated inputs and controlled integrals; floating quadrature displays are not a certified experimental interval. This stringent error example is not a demonstrated detector capability.

The eliminated premise is knowledge of the initial amplitudes for this restricted identifiable inverse. Excitation rank, material law, fixed background, calibration, single active scalar model and the initial-state origin all remain open.
