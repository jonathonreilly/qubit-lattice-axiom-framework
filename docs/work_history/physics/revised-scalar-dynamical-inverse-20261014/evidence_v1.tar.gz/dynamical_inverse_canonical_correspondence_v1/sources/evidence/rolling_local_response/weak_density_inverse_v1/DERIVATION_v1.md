# Finite-window density inverse without prescribed initial amplitudes

Personally derived by /root. Conditional inverse inside the frozen nonrelativistic scalar/material model of ../dynamical_density_response_v1/DERIVATION_v3.md. It is not a fitted experiment or a fundamental action selection. All constitutive, gravity, geometry, stationarity and approximation premises of that source remain.

## 1. Calibrated inputs and an undivided observable equation

For k>0, x=k^2, cR=rhoE/(2Q)>0, q=beta^2>0, M^2>0, sound-speed squared v_s^2>0 and gravity flag h=0 or1, put a=x+M^2, b=v_s^2 x-h cR, g=cR q. The coupled equations are

    X_ddot+a X=-cR beta delta,
    delta_ddot+b delta=-beta x X.

Delta is the particle-number contrast per frozen Einstein proper volume. The physical density contrast is delta-3 beta X. Because every constant linear combination of these states satisfies the same eliminant, either contrast is eligible in the frozen model. An instrument's varying geometry/readout factor, background or projection must be included before using this fact. Wavenumber, clock, sound speed and tensor coefficient cR are supplied calibrations.

Eliminating X without setting any initial or homogeneous mode to zero gives

    delta^(4)+C2 delta_ddot+C0 delta=0,
    C2=a+b, C0=ab-g x.                                  (1)

The same equation holds for X and a time-independent linear readout of both. This polynomial equation loses no acoustic pole. It is not asserted during cosmological rolling or for a dispersive constitutive law.

## 2. Weak finite-window inversion

Use duration T>0, tau=t/T in[0,1], and readout f(tau). Choose test functions psi_j whose psi,psi',psi'',psi''' vanish at both boundaries. Four or two integrations by parts give

    I4_j+u2 I2_j+u0 I0_j=0,
    Ir_j=integral_0^1 f(tau) psi_j^(r)(tau) d tau,
    u2=T^2 C2, u0=T^4 C0.                              (2)

No derivative of observed f or endpoint initial state is supplied. For two tests let D have rows (I2_j,I0_j), and z have entries -I4_j. If det D!=0, u=D^-1 z. The rank condition concerns actual readout features, not a guaranteed preparation. Then

    M^2=C2-(1+v_s^2)x+h cR,
    q=[(x+M^2)(v_s^2 x-h cR)-C0]/(cR x).                (3)

This requires calibrated nonzero cR x. It does not determine the sign of beta, which changes with scalar orientation. Negative inferred M^2 or q could reject this restricted model only with valid error and approximation bounds. No empirical value is inferred here.

A single exact normal-frequency readout obeys f''=-Omega^2 f in tau, so I2_j=-Omega^2 I0_j for every admissible test. D then has rank at most1 even with unlimited precision or more kernels. Both excitation and readout observability matter. A two-mode history can supply enough information without fitting its unknown phases/amplitudes; this is conditional on the measured rank, not a selected initial state.

## 3. Deterministic error certificate

Suppose |fhat-f|<=epsilon on the window, and Kr_j bounds integral |psi_j^(r)|. Then |Ihat_rj-I_rj|<=epsilon Kr_j. In infinity norm define

    d=epsilon max_j(K2_j+K0_j), e=epsilon max_j K4_j,
    eta=||Dhat^-1||_infinity d.

If Dhat is invertible and eta<1, the true D is invertible and

    ||uhat-u||_infinity
    <= ||Dhat^-1||_infinity (e+d||uhat||_infinity)/(1-eta). (4)

This follows from the Neumann inverse bound and D(u-uhat)=(z-zhat)+(Dhat-D)uhat. The uniform error, exact model and controlled integrals are premises. Instrument drift, finite sampling, quadrature and approximation errors need their own bounds before this describes an experiment. It is not a statistical confidence region or automatically informative.

For bound E in(4), with b,cR,x,T held at their exact calibrated values,

    |Mhat^2-M^2|<=E/T^2,
    |qhat-q|<=[|b|/T^2+1/T^4] E/(cR x).                 (5)

Calibration uncertainty must be propagated separately. For psi=P(tau)cos(w tau), P=tau^4(1-tau)^4, a conservative analytic kernel bound is

    Kr<=sum_(l=0)^r binomial(r,l)|w|^(r-l)
             sum_n |coefficient_n(P^(l))|/(n+1).       (6)

The triangle inequality, bounded sin/cos and integral tau^n=1/(n+1) prove it. For w=0 only l=r contributes. Floating displays of the symbolic envelope are not outward interval certificates.

## 4. Frozen synthetic protocol and empirical separation

Before execution freeze calibration k=8, T=3, cR=1, v_s^2=0.04, M^2=4, q=0.2, h=1 and kernels w=0,8pi. Use three distinct small two-mode amplitude/phase choices and an explicit single-mode failure. Reserve k=11 with new amplitudes as a synthetic prediction control: infer M^2,q at k=8, then check predicted coefficients at k=11. Do not tune the theory with that control. Preserve ill-conditioning or failed inverses if they occur.

Use exact identities, high-precision quadrature, separate double-precision Gaussian quadrature, and a bounded additive sinusoidal readout error. Actual altered integration sign, time scaling, gravity sign and mass prescription must trigger failures. Save full mock readout samples, features, inferred coefficients, conditioning, predicted residuals and failures. Neither calibration nor the reserved synthetic control is an independent empirical test. No density data or apparatus likelihood has been acquired.
