from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib,subprocess,time

PK=Path(__file__).resolve().parent.parent
WT=PK.parents[3]
DEST=Path(__file__).resolve().parent
STAGE=DEST/'staged'
STAGE.mkdir(exist_ok=False)
RR=PK/'rolling_local_response'
NOTE='EXPONENTIAL_SCALAR_DYNAMICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER='exponential_scalar_dynamical_inverse_check.py'
PARENTS=['docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[RR/'dynamical_density_response_v1/check_response_v2.py',RR/'weak_density_inverse_v1/check_weak_inverse_v2.py']
maps=[{'run':'check_dynamics','FORCE_SIGN':'DR_FORCE_SIGN','KINETIC_FACTOR':'DR_KINETIC_FACTOR','MASS_SHIFT':'DR_MASS_SHIFT','GRAVITY_SIGN':'DR_GRAVITY_SIGN'}, {'run':'check_weak','IBP_SIGN':'WI_IBP_SIGN','TIME_POWER':'WI_TIME_POWER','GRAVITY_SIGN':'WI_GRAVITY_SIGN','MASS_SHIFT':'WI_MASS_SHIFT'}]
class Rename(ast.NodeTransformer):
    def __init__(self,mapping):self.mapping=mapping
    def visit_Name(self,node):
        node.id=self.mapping.get(node.id,node.id);return node
    def visit_FunctionDef(self,node):
        node.name=self.mapping.get(node.name,node.name);return self.generic_visit(node)
blocks=[];lineage=[]
for source,mapping in zip(sources,maps):
    original=ast.parse(source.read_text())
    selected=[x for x in original.body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.Assign))]
    tree=ast.fix_missing_locations(Rename(mapping).visit(ast.Module(body=selected,type_ignores=[])))
    body=ast.unparse(tree)+'\n';blocks.append(body)
    lineage.append(dict(path=str(source),sha256=sha(source),renames=mapping,selected_statement_types=['Import','ImportFrom','FunctionDef','Assign'],transformed_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
header='#!/usr/local/bin/python3\n"""Conditional local density dynamics and finite-window inverse; synthetic checks."""\nfrom contextlib import redirect_stdout\nfrom tempfile import TemporaryDirectory\nimport io\nAUDIT_TIMEOUT_SEC=120\nAUDIT_INPUT_PATHS='+repr(['docs/'+NOTE]+PARENTS)+'\n'
footer='''
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--profiles',type=Path)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    def execute(root):
        root.mkdir(parents=True,exist_ok=True)
        dynamics=check_dynamics(root/'dynamics')
        captured=io.StringIO()
        with redirect_stdout(captured):
            failed=check_weak(root/'weak_inverse')
        weak=json.loads((root/'weak_inverse'/'RESULTS.json').read_text())
        assert failed==weak['failed']
        result=dict(passed=dynamics['passed']+weak['passed'],failed=dynamics['failed']+weak['failed'],units=dict(dynamics=dynamics,weak_inverse=weak),weak_execution_stdout=captured.getvalue(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Exact specified local quadratic model and calibrated finite-window inverse; no real-data fit or state/action selection.')
        return result
    if args.profiles is None:
        with TemporaryDirectory(prefix='scalar-density-inverse-') as d:result=execute(Path(d))
    else:
        assert not args.profiles.exists();result=execute(args.profiles)
    text=json.dumps(result,indent=2)+'\\n'
    if args.out:
        assert not args.out.exists();args.out.write_text(text)
    print(text,end='')
    return bool(result['failed'])
if __name__=='__main__':raise SystemExit(main())
'''
(STAGE/RUNNER).write_text(header+'\n'.join(blocks)+footer)
opening='''# Deriving material response and a finite-history scalar inverse

Status: conditional support; specified local material, calibrated synthetic inverse.
Claim type: bounded_theorem. Scientific author: /root.
Primary runner: `scripts/exponential_scalar_dynamical_inverse_check.py`.

Particle conservation and a supplied compressional law replace an arbitrary
constant density response with a frequency-dependent response and its own initial
mode. The undivided two-mode equations then give a finite-window inverse that
eliminates unknown amplitudes and phases when measured features have full rank.
Neither construction selects the material, background, state or fundamental action.

Premises are the [complete supplied action](EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md),
the [local force normalization](EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md),
and the [stationary density/action inverse](EXPONENTIAL_SCALAR_DENSITY_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md).
Actual source controls, a valid scale/time window, and the measurement calibrations
remain open. These are conditional derivations, with no empirical fit or independent
observational test in this block.

'''
hands=[RR/'dynamical_density_response_v1/DERIVATION_v3.md',RR/'weak_density_inverse_v1/DERIVATION_v1.md']
sections=[]
for i,p in enumerate(hands):
    t=p.read_text().replace('../dynamical_density_response_v1/DERIVATION_v3.md','the preceding material-dynamics derivation')
    t='\n'.join('#'+line if line.startswith('#') else line for line in t.splitlines())
    sections.append(t)
closing='''

## Validation and recovery

The canonical runner retains the exact checked proof bodies with only isolated
global/function renaming. It executes99 local-dynamics controls and126 weak-inverse
controls, preserving complete outputs and optional full profiles with `--profiles`.
Original synthetic profiles, failed first executions, their narrow numerical repairs,
20 causal-domain and8 long-wave controls, and actual altered-program probes are in
the [recovery archive](work_history/physics/revised-scalar-dynamical-inverse-20261014/README.txt).

Independent hand implementations use distinct matrices, states, kernels and moment
methods:119 local-response controls and200 finite-window inverse controls, with
seven actual altered-program probes for each. Their full reports, source bindings
and failures remain separate from author output. These counts are checks within
specified models, not separate experiments or formal audit grades.

The first dynamics execution93/6 exposed inadequate absolute resolution for tiny
ODE energies. The repaired execution99/0 retains its cases and acceptance threshold
while tightening integration accuracy. The first weak inverse123/3 preserved a
symbol-identity comparison error and high-derivative double-quadrature cancellation;
its repair126/0 retains the primary derivative-free inverse and uses known analytic
mock derivatives only in a separate synthetic quadrature control. Neither repair
licenses differentiating unknown experimental data. Full original programs, streams,
profiles and exact diffs are recoverable.

A two-mode state is not sufficient by itself: the actual readout or test functions
can annihilate a mode. Extra residual/prediction checks are needed to challenge the
model, and finite sampling, quadrature, solve error and uncertain calibrations require
their own budgets. The reserved wavenumber is a same-model synthetic prediction
control, not a held-out observation. Initial realization, environmental preparation,
constitutive law, absolute scales, and action selection remain unretired assumptions.
'''
(STAGE/NOTE).write_text(opening+'\n\n'.join(sections)+closing)
record=dict(at=datetime.now(timezone.utc).isoformat(),canonical_note=dict(path=NOTE,sha256=sha(STAGE/NOTE)),canonical_runner=dict(path=RUNNER,sha256=sha(STAGE/RUNNER)),scientific_sources=lineage,hand_sources=[dict(path=str(p),sha256=sha(p)) for p in hands],transforms='AST formatting and explicit global/function renaming only in inherited computational bodies. New wrapper controls isolated profiles, captures original weak stdout and aggregates full results.')
(DEST/'CANONICAL_LINEAGE_v1.json').write_text(json.dumps(record,indent=2)+'\n')
cmd=['/usr/local/bin/python3',str(STAGE/RUNNER),'--profiles',str(DEST/'staged_profiles_v1'),'--out',str(DEST/'STAGED_RESULTS_v1.json')]
t=time.time();r=subprocess.run(cmd,capture_output=True,text=True);(DEST/'STAGED_RUN_v1.stdout').write_text(r.stdout);(DEST/'STAGED_RUN_v1.stderr').write_text(r.stderr);(DEST/'STAGED_RUN_v1.json').write_text(json.dumps(dict(command=cmd,at=datetime.now(timezone.utc).isoformat(),elapsed=time.time()-t,exit_code=r.returncode,runner_sha256=sha(STAGE/RUNNER)),indent=2)+'\n');print('STAGED',r.returncode,r.stderr[-1000:])
if r.returncode==0:
    z=json.loads(r.stdout);print(z['passed'],z['failed'])
raise SystemExit(r.returncode)
