# Focused independent check: dynamical density response

The reciprocal scalar/displacement dynamics, coupled determinant, source-controlled frequency response, fixed-metric stability condition, Newtonian Jeans threshold, and candidate growth ceiling agree with an independent derivation within the declared quadratic model. The source is explicit about its leading nonrelativistic rest-source approximation and does not construct a physical stationary background or an observational exclusion.

The original source needed a substantive causal-transform qualification: a growing system's retarded solution cannot generally be obtained as a convergent real-frequency transform by the prescription omega+i0. The author preserved v1 and added v2. The original reviewer also requested the literal response-ratio domain and a precise statement of both long-wave limits; the preserved final v3 includes them. Complete v2/v3 and both exact diffs were read. Their corrected scope is confirmed; no additional coefficient or sign issue was found.

This is a focused independent check, not a formal audit or replacement authorship. /root remains the scientific author. No producer implementation or producer result artifact was read, imported, or run. Disclosed parent counts do not enter this evidence. No observed inputs, fits, Git changes, runtime changes, external messages, or changes to prior sealed evidence were made.

## Exact source and execution identities

The original hand source is sources/DERIVATION_v1.md, SHA256 c78f7be15fe2d1a422b6b555fd5f0dbf56d76bdc7f72594b3ece112c63007d35. Its frozen protocol is sources/PROTOCOL_v1.json, SHA256 b9e369edf98e191cbd8c51e660ea3b609bac2c0afe5f455dd99f360f40cd7867. The complete supplied action and the prior corrected action-inverse hand source are separately frozen; the prior inverse's control count is not rerun or counted here. SOURCE_BINDINGS_FINAL_v1.json records all 11 live/snapshot pairs.

Final source v3 has SHA256 3e6449a1f10e47105cd29aae6ef0e47a4ea337c1d65500f6f2e582af77430ff4. The intermediate v2 is 8b95cd295cfc6fe6f0d643de1946d29fe1c39a487f6456029b262d52c500b51f. All original sources, correction records, and exact diffs remain available under source_correspondence_v3/sources/.

HAND_DERIVATION_v1.md and INDEPENDENT_PROTOCOL_v1.json were written before independent science execution. HAND_IMPLEMENTATION_BINDINGS_v1.json preserves their initial hashes and ordering. The first checker, check_dynamical_v1.py, SHA256 bf305dbf4c190cd9925d87a31dfc6659bf241b2cdb50f6dd1147055b6ca2778a, returned 107 passed / 12 failed at 14:20:11 UTC. Its complete results and failures remain unchanged.

The separate corrected checker, check_dynamical_v2.py, SHA256 e888e1473767034f29d1b757dc9849643f9afb6c3f0792bc2ac00ff069c78dbf, ran from 14:21:26.276597 to 14:21:27.227441 UTC and returned 119 passed / 0 failed. Its output SHA256 is 4ff1777f19338180fba0556ec0805e10056c5ec60adddb23df72ba6e8670c2de. Both versions, protocols, full profile outputs, exact code diff, and diagnosis are retained. The unchanged model/cases/acceptance criteria and the tightened absolute integration tolerance are detailed below.

Seven actual one-edit damaged implementations were then executed. Each exited 1 on its designated identity. The subsequent original-reviewer source correspondence is 42/0 metadata/evidence controls; it reuses the 119/0 scientific result and is not another science run. COMMANDS_v1.json and the run records preserve exact commands, argv, working directories, times, exits, and hashes.

## Independent quadratic derivation

Expanding the point-particle action -m_J A ds_E about a frozen scalar and zero velocity gives inertial density rho_E, scalar force -beta grad X, and no linear drag from dot A: the latter multiplies a first-order velocity and is second order at this background. Conservation of particle labels gives delta=-div xi and delta_dot+div v=0.

The particle-position cross term is -rho_E beta xi.grad X. Integrating its divergence gives +rho_E beta X div xi. The sound-speed term is an independently supplied compressional energy rho_E v_s^2(div xi)^2/2. It is not derived from the scalar action.

Direct Euler derivatives of the real scalar/displacement Lagrangian give

    Xddot - Delta X + M^2 X = -r beta delta,
    deltaddot - v_s^2 Delta delta = beta Delta X,
    r = rho_E/(2Q).

The actual scalar kinetic coefficient is 2Q. The local stationary-potential control independently verifies M^2=(V_E''+rho_* A'')/(2Q), including A''/A=beta^2+beta'. Replacing this by the p=3 coefficient M^2+3r q changes the model and is rejected by the altered-code controls.

In this report z denotes the wave number squared, m=M^2, s=v_s^2, g=r beta^2. In raw variables (X,delta), the mode matrix is

    P = [[z+m, r beta], [z beta, s z]].

The real transformation delta=sqrt(z/r)D gives a symmetric matrix K with off-diagonal beta sqrt(r z); both canonical kinetic terms have coefficient Q. The positive kinetic form means the negative squared frequency is a potential instability, not a kinetic ghost. The determinant and first-order characteristic polynomial were checked independently from these matrices.

The frozen physical rescaling is consistent: squared frequencies and masses divide by A0^2, rho_E=A0^4 rho_J, and r/A0^2=4pi Gbare rho_J. The primary-paper mapping is phi=sqrt(2Q)chi, m_p^2=Q, alpha=ln A, so 2Q alpha_phi^2=q.

## Response, actual poles, and causality

For prescribed harmonic scalar forcing, the density transfer is

    delta = -beta z X/(b-omega^2),    b=s z.

This uses b-omega^2 nonzero and zero independent fluid homogeneous perturbation. The literal ratio p_eff=delta/(beta X) additionally requires a nonzero driven beta X. At beta=0 the sectors decouple; the literal quotient is undefined. A general initial-value solution includes the independent fluid mode. The two forced-fluid controls explicitly demonstrate that omitting it fails nonzero initial data.

At fixed wave number the transfer tends to zero at high frequency. For s>0, its zero-frequency value in the frozen-metric model is -1/s, not +3. Dust has no finite zero-frequency division. Holding physical density fixed remains a separately controlled material/geometry condition; free number conservation does not impose it.

The coupled determinant is

    (a-omega^2)(b-omega^2)-g z,    a=z+m.

The scalar entry of the full inverse matrix is (b-omega^2)/determinant. For g>0 and z>0, the bare acoustic pole omega^2=b is not a coupled pole: the determinant there is -g z and that scalar inverse entry is zero. The two actual squared frequencies are the real eigenvalues of K. Eliminating the density first must not replace this undivided pole analysis.

The causal kernels make the original wording problem concrete. For b>0 the bare kernel is sin(sqrt(b)t)/sqrt(b), for b=0 it is t, and for b<0 it is sinh(sqrt(-b)t)/sqrt(-b), all supported at t>=0. In the unstable case its Laplace transform 1/(sigma^2+b) converges only to the right of the growing pole. A full coupled negative eigenvalue imposes the same requirement even if the bare b was positive. With the source's exp(-i omega t) convention, the corresponding contour is above the growth rates in the omega plane. Real-frequency i0 is appropriate as a boundary prescription for the stable bare resolvent; it is not a convergent retarded transform of the growing full system.

An independent actual integral uses kappa=3/7. At sigma=5/7 the causal hyperbolic-sine transform is 49/16=3.0625, matching quadrature. At sigma=kappa/2, cutoff integrals at t=14,28,56 are approximately 102.0956, 2189.1864, and 886102.1607. They grow rather than approaching the formal rational continuation, which is negative there. Reversing the convergence abscissa in an actual code copy fails two checks. These are causal mathematical controls, not measured response functions.

## Stability and the susceptibility condition

For s>0 and z>0, positivity of the frozen-metric quadratic form is equivalent to

    det K = z [s(z+m)-g] > 0.

Equality is neutral at that particular wave number. If s=0 and g>0, the determinant is negative at every finite nonzero wave number despite m>0. This is scalar-mediated compression in the selected local model.

Positivity at every finite z>0 is equivalent to s m>=g. Using the prior fixed-particle mass identity, the scale factors cancel and m/g=2/B-3. Therefore on the positive stationary branch with 0<B<2/3, q>0, and s>0, the all-mode condition is B<=2s/(1+3s).

The precise low-wave-number behavior matters. Strict stability gives y_minus=(s-g/m)z+O(z^2); equality gives y_minus=(s/m)z^2+O(z^3). Thus both tend to zero. Neither branch has a uniformly positive long-wave frequency gap. This was checked exactly, and final source v3 now states both limits.

The fixed-metric growing root satisfies gamma^2=-s z+g z/(z+m+gamma^2)<g. The source's weaker <=g statement is therefore valid. It neither constructs a global background nor proves that the relevant scale lies within a hydrodynamic/frozen-metric regime.

The all-k statement is about the ideal continuum. It supplies no measured infrared or ultraviolet validity window. A generic small omitted positive correction to g illustrates boundary sensitivity: at s m=g, changing g to g(1+epsilon) gives determinant s z(z-epsilon m), negative for sufficiently small z. This is an exact sensitivity example, not a computed relativistic-fluid correction. Pressure/internal energy, scalar trace corrections, inertia corrections, transport, and boundary physics were not derived here.

## Optional leading Newtonian extension

At a stationary scalar point, the linear scalar part of rest energy rho_E beta X cancels V_E,chi X=-rho_E beta X. To the declared order the source of the subtracted nonzero-k Newtonian Poisson constraint is rho_E delta, giving Delta Psi=r delta. The density block becomes b=s z-r.

This is not a uniform gravitating Minkowski solution. Background subtraction, weak fields, a sufficiently local region, and compatible time/length scales are premises of the optional model. Metric-volume/time corrections, expansion, background curvature, and pressure contributions are outside the supplied truncation.

For s>0 the determinant is

    s z^2 + [s m-r(1+q)]z - r m.

It has exactly one positive root z_J, with r/s<z_J<r(1+q)/s for q,m>0. Below it one frequency is negative; above it the canonical form is positive. Dust has no finite Jeans threshold; the divided s>0 expression cannot be evaluated at s=0.

For a growing mode,

    gamma^2 = r-s z+g z/(z+m+gamma^2) < r(1+q).

The supplied candidate has q<1/3, so gamma^2<(4/3)r. The coefficient and physical-frame normalization are checked. The bound fails to address tachyonic fixed-particle backgrounds with m<=0, which the theorem excludes. A free-fall-scale growth ceiling is not a proof that expansion can be neglected. If the rate is comparable to the actual expansion/curvature rate, a full background perturbation analysis is still needed.

## Numerical controls and actual damages

The six disclosed coupled examples use both signs of beta, positive pressure and dust, frozen metric and subtracted Poisson gravity, and a critical all-k boundary. They are generic quadratic-model parameters, not calibrated states asserted to lie on a selected complete candidate cosmology.

Each profile preserves 137 samples from a direct raw-coordinate DOP853 integration and an independently diagonalized canonical eigenmode fundamental solution. The stable cases run to t=13.25 and unstable cases to t=5.5. Initial raw components are (3e-7,-2e-7,5e-7,7e-8). All six profiles stay below 1.42e-4 in absolute state components. Representative squared frequencies are:

| Case | y_minus | y_plus |
|---|---:|---:|
| frozen stable | 0.01415496979 | 4.04473391910 |
| frozen unstable, positive pressure | -0.02858001655 | 1.39724668322 |
| frozen dust | -0.06506841692 | 1.62550797735 |
| Poisson stable | 0.81457100145 | 24.91181788744 |
| Poisson unstable | -1.24404422564 | 3.16441459602 |
| frozen all-k boundary | 0.000238030322 | 1.45368353831 |

The corrected run's largest profile-scaled error is 1.43e-10 and largest scaled energy error is 1.62e-10. The accepted thresholds remain 4e-8 and 5e-8. These are floating-point checks, not rigorous numerical enclosures.

Two additional 91-sample forced-fluid IVPs use a stable and an unstable bare block, with nonzero independent initial data. They agree with the explicit forced-plus-homogeneous solutions to 6.77e-13 and 2.93e-12. Their unit forcing and larger amplitudes are algebraic Green-function checks only; they are not claimed to stay within a physical small-perturbation approximation. Linearity permits rescaling, but no physical material experiment is inferred.

Every damaged case is an actual separately executed copy of the independent corrected checker with one changed implementation constant. The controls and acceptance criteria remain fixed:

| Alteration | Passed / failed |
|---|---:|
| reversed fluid force | 99 / 20 |
| omitted scalar kinetic factor two | 97 / 22 |
| M0 replaced by M3 | 100 / 19 |
| reversed tensor-gravity sign | 108 / 11 |
| particle-volume power 4 instead of 3 | 118 / 1 |
| reversed density-response sign | 116 / 3 |
| wrong unstable causal abscissa | 117 / 2 |

All seven exited 1 and failed the designated checks. Scripts, exact diffs, full outputs/profiles, stderr, times, exits, and hashes remain under damages/ and DAMAGE_SUMMARY_v1.json. These counts are not added to the successful baseline.

## Preserved failures and original-reviewer correction confirmation

The first independent baseline genuinely returned 107/12; none of it was overwritten. Two failures were checker representation issues. SymPy's characteristic-polynomial generator had the same printed name as the requested real symbol but different assumptions; explicit substitution of the actual generator makes the identity zero. The negative witness had is_negative=None before simplification; its simplified expression is -epsilon^2 m^2 s/4.

The other ten failures were profile/energy accuracy checks. An absolute ODE tolerance of 2e-14 was too loose for components of order 1e-7; normalized errors reached 4.30e-7. INDEPENDENT_PROTOCOL_v2.json tightens only atol to 2e-18, preserving rtol=2e-11, model, cases, initial data, sample count, duration, and comparison thresholds. The same 119 controls then passed. FIRST_RUN_DIAGNOSIS_v1.json, CHECKER_v1_v2.diff, both protocols, and both full outputs preserve this failure/repair history. This is a corrected numerical implementation run, not a relabeled original success.

The full primary-PDF extraction emitted a real rotated-text warning. That warning is retained. Relevant source pages were also rendered and visually read, so extracted text alone was not treated as complete visual content.

The author-source history is distinct from the checker repair. V2 narrows the real-frequency prescription and explicitly states continuum/NR limits. V3 adds the nonzero literal quotient domain and the strict/marginal low-wave-number behavior. The original reviewer read complete v2 and v3 and reproduced both exact full diffs. All displayed original equations remain byte-identical; the new asymptotic prose is supported by the independent exact checks. The 42/0 correspondence controls reuse the original successful independent result without another science run.

## Primary source and bounded conclusion

The supplied Bean–Flanagan–Trodden PDF has SHA256 1815c72e650df38bbcd899c5ac8409494bd1995763e502cab5734694de998d33. Complete pages 2-5,9-10 were extracted, rendered, and visually read. Equation (2.1) fixes the scalar/Planck normalization; (2.4)/(2.6) show the full pressure-trace term; (2.7), (2.12), and (2.13) support the particle-density and conformal-force conventions. The discussions on pages 5,9,10 distinguish local/adiabatic conditions, expansion, and the limits of a fluid description. Their dark-sector observational exclusions and strong-coupling phenomenology are not imported. The current result is a conditional reconstruction of a known local mechanism with its declared response variables, not a claim to discover that mechanism.

Final v3 is consistent within the declared quadratic model. It replaces an assumed local constant p by the dispersive response of a specified moving medium plus its independent initial mode. It does not eliminate the constitutive law, material preparation, supports/boundaries, background matching, validity window, source calibration, or initial conditions. It establishes neither a stable physical universe nor a fast cosmological exclusion or measured confidence level. All original failures and source versions remain available; prior sealed units remain untouched.

