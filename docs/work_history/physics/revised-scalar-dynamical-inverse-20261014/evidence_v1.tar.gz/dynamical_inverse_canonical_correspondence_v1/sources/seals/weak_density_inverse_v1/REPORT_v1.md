# Independent finite-window weak-density inverse check

The hand source is correct within its declared constant-background nonrelativistic scalar/material model. No source correction is required. The new independent execution passed **200 checks, 0 failed**; seven actually executed altered copies were rejected for their intended errors. This is a focused mathematical and numerical check, not a formal audit or an empirical validation. /root remains scientific author.

## Inputs, independence and dispositions

Only these three external hand inputs were read for this unit. Each was copied before the independent executable run; final live bytes still equal the snapshots.

| Input | SHA-256 | Disposition |
|---|---|---|
| weak_density_inverse_v1/DERIVATION_v1.md | c21ab6c6cd9abf4f9f7f50fd7f8a00a86bdfb7072177e7a91be51f063f397b58 | Checked as a conditional inverse; unchanged |
| weak_density_inverse_v1/PROTOCOL_v1.json | 47b95ce15d0e6f3816d96ea41a7764f3ecc2cbd761f3805dda59c3f775c8ae43 | Frozen author plan, not evidence that its later implementation ran |
| dynamical_density_response_v1/DERIVATION_v3.md | 3e6449a1f10e47105cd29aae6ef0e47a4ea337c1d65500f6f2e582af77430ff4 | Coupled local-model premise and its physical limitations; no repeated full-action or background study |

SOURCE_BINDINGS_v1.json and FINAL_SOURCE_CONFIRMATION_v1.json retain the exact absolute original paths, snapshot paths, lengths and hashes. The prerequisite is reused explicitly as the supplied model; this unit does not relabel any old scientific results as new. No producer checker, producer result, grid, empirical data, later source, or source-code oracle was read or run. The author's protocol uses oscillatory kernels, k=8 and a reserved k=11; the independent cases, kernels and moment method below were chosen separately.

HAND_DERIVATION_v1.md and INDEPENDENT_PROTOCOL_v1.json were written before check_weak_inverse_v1.py and its first execution. PRE_RUN_BINDINGS_v1.json binds those exact files before execution. The independent code SHA-256 is 5234512984e1c7a1e65252c445ac96872beaa78497c6a59c28e25d2911a3bda7; the first complete result SHA-256 is 5649ac0cd36a300a2a4dafa093cbebf94f8e8fbcab08795fc7964a205f7da05c. There was no baseline repair or tolerance/case change.

## Independent mathematical derivation

With x=k², r=cR, m=M², s=v_s² and q=beta², the state w=(X,delta) obeys w_ddot+P w=0, where P=[[x+m,r beta],[beta x,sx-hr]]. Its trace is C2 and determinant is C0=(x+m)(sx-hr)-rqx. Cayley-Hamilton gives w^(4)+C2 w_ddot+C0 w=0. Multiplication by any constant row vector gives the readout equation. No acoustic denominator, particular solution, amplitude, phase, or homogeneous mode was removed. For delta, beta x nonzero also reconstructs X from its second derivative, so the eliminant is equivalent to the coupled system with four initial degrees of freedom. For a general readout, the scalar eliminant alone does not guarantee observability of the full state.

The physical contrast delta_J=delta-3 beta X is eligible because this mixing is constant in the frozen model. A time-dependent gain is different: multiplication by 1+epsilon*tau adds epsilon*(4 f'''+2u2 f') to the eliminant. A constant nonzero gain cancels from the exact inverse, while an absolute noise floor changes its conditioning.

The clock conversion is u2=T²C2, u0=T⁴C0. Four integrations by parts have boundary form [f'''psi-f''psi'+f'psi''-fpsi''']; two have [f'psi-fpsi']. With sufficient test-function regularity and the four prescribed endpoint traces zero, both even-order integration signs are positive. Thus I4+u2 I2+u0 I0=0 without observed derivatives or endpoint-state data. The row ordering (I2,I0) and right side -I4 are consistent. Kernels with only third-order endpoint zeros really fail this identity; that failure is exercised below.

For det D nonzero, inversion and the two calibrated reconstruction formulas follow directly. With all calibrations fixed, the perturbations are exactly Delta m=Delta u2/T² and Delta q=[b Delta u2/T²-Delta u0/T⁴]/(rx). These imply the stated conservative component bounds for either sign of b. Under a consistent constant frame scale A, x,r,m scale by A^-2 while T scales by A; u2,u0,q are invariant. Mixing physical and Einstein clocks or wavenumbers without this conversion would not be covered.

The rank qualification is necessary. A one-frequency readout, including arbitrary sine/cosine phase at that frequency, has I2=-Omega²I0 for every admissible kernel. More kernels do not cure that intrinsic rank-one obstruction. Independent controls also use (i) two excited state modes but a constant readout annihilating one eigenvector, and (ii) an even two-mode history about tau=1/2 with an odd second test function, which makes that test row vanish. Therefore two excited modes alone do not guarantee this particular inverse. Rank plus the exact model is the conditional uniqueness premise. Two integrated equations by themselves also do not establish that an arbitrary observed signal satisfies the model; additional residual or prediction checks can challenge that premise.

For DeltaD=Dhat-D and Deltaz=zhat-z, the uniform readout error yields ||DeltaD||inf<=d and ||Deltaz||inf<=e. Factoring D=Dhat*(I-Dhat^-1 DeltaD) gives the strict eta<1 inverse bound. Substitution into D(u-uhat)=(z-zhat)+(Dhat-D)uhat proves the stated E with denominator 1-eta. It is a sufficient conditioning test, not a necessary one. The independent exact controls include 64 rational perturbation corners, an eta=1 example with singular true D, and a diagonal case saturating E=26/21. Replacing 1-eta by 1+eta fails the latter actual test. An approximate numerical solve also needs a bound for its solve residual; the source's ideal exact-integral/exact-solve theorem does not remove that requirement.

Leibniz expansion and the polynomial coefficient triangle envelope prove the proposed K_r bound, including w=0, where only the last derivative term remains. The same envelope bounds the independently chosen polynomial kernels. Exact symbolic checks establish the formula; displayed floating values are not outward-rounded certificates.

## New executable controls and full profiles

The independent kernels are P=tau^4(1-tau)^4 and (2tau-1)P. Analytic features are calculated at 100 decimal digits using the recurrence for integral tau^n exp(lambda*tau), not numerical quadrature. Each state mode is separately checked against both original coupled equations. Composite Simpson integration of saved uniform samples provides a different numerical route at 512 and 1024 panels. The final acceptance tolerances were fixed beforehand: 2e-5 for scaled coefficient error and absolute parameter error. The analytic identity tolerance was 1e-70.

| Case | k; T; r; s; m; beta; h | Readout | cond_inf(D) | 1024-panel scaled u error | 1024-panel max parameter error |
|---|---|---|---:|---:|---:|
| frozen_number | 2; 7/4; 2/3; 1/20; 1; 1/4; 0 | delta | 177.2163 | 6.5221e-8 | 4.1807e-8 |
| poisson_physical | 5/2; 4/3; 1/5; 1/16; 3/2; -2/7; 1 | delta-3 beta X | 25.6705 | 8.5021e-8 | 3.0574e-7 |
| poisson_unstable_mixed | 3/2; 5/6; 3/4; 1/25; 4/3; 1/3; 1 | (5/7)X-(2/3)delta | 11.7403 | 3.9924e-6 | 9.9796e-6 |

The last case has squared frequencies about -0.703736 and 3.627070; the polynomial eliminant and finite-window inverse still work for its growing/decaying branch. This is not a stability claim. The scalar and number contrasts remain small on these synthetic windows: the largest stored absolute X is about 3.47e-4 and the largest absolute delta about 1.02e-4. Small amplitude by itself does not establish any real nonrelativistic material, stationarity, or Poisson validity window.

The preserved 512-panel unstable-case estimates have scaled coefficient error 6.3879e-5 and parameter error 1.5967e-4, larger than the finer-grid acceptance thresholds. The declared test was the 1024-panel result. The common 1025-sample history and both grid estimates are retained, and no threshold, case, or model was adjusted. Simpson convergence is a numerical comparison, not a rigorous quadrature enclosure.

Bounded additive noise is analytically epsilon*cos(7tau+1/3), epsilon=2e-16. The actual analytic noisy-feature changes obey the kernel bounds. The three numerical displays are:

| Case | eta | coefficient bound E | actual max coefficient error | mass-error bound | q-error bound |
|---|---:|---:|---:|---:|---:|
| frozen_number | 1.1751e-5 | 5.2756e-4 | 1.2959e-8 | 1.7227e-4 | 3.4014e-5 |
| poisson_physical | 2.2417e-6 | 9.6589e-5 | 6.2561e-9 | 5.4331e-5 | 3.2734e-5 |
| poisson_unstable_mixed | 4.1339e-6 | 1.2816e-4 | 8.7453e-9 | 1.8454e-4 | 2.2965e-4 |

These conservative bounds and tiny synthetic noise are not an apparatus precision forecast. Sampled double-precision profiles are diagnostic renderings of the analytic functions; they are not used to assert a pointwise certified experimental error. The exact rational norm controls prove the abstract inequality without floating arithmetic, whereas the 100-digit case displays remain numerical illustrations.

The reserved k=7/2, T=5/4 history has new amplitudes and readout (2/9)X+delta. Parameters inferred only from frozen_number predict its weak equation with scaled residual approximately 3.04e-97. It is a synthetic same-model prediction control, not new empirical data or an independently selected initial state. The single-mode, annihilating-readout, and parity cases have normalized determinants about 1.02e-97, 1.02e-97 and 1.39e-93, respectively, consistently with the exact rank arguments.

BASELINE_RESULTS_v1.json retains all 200 individual assertions, feature matrices, inferred coefficients, conditioning, error displays, rational corners and seven complete 1025-point profiles: three main states, three rank-obstruction readouts, and the reserved state. The three main and reserved profiles include the scalar/number components. The damaged runs also retain complete outputs. These are 200 checks, not 200 separate experiments.

## Actually executed failure probes

All seven source copies and exact diffs were frozen in damages_v1/PRE_RUN_DAMAGE_PLAN_v1.json before execution. Each ran as a separate Python process with its own full stdout, stderr, source hash, argv, timing and return code. Required failed identities were verified; no textual or hypothetical damage is counted as an execution.

| Alteration | Passed / failed | Exit | Representative failure |
|---|---:|---:|---|
| Reverse weak second-derivative sign | 176 / 24 | 1 | Weak IBP and full-profile weak equations |
| Replace T² conversion by T | 184 / 16 | 1 | Clock conversion and parameter inverse |
| Replace T⁴ conversion by T² | 185 / 15 | 1 | Fourth-order clock conversion and q inverse |
| Reverse tensor-gravity reconstruction sign | 192 / 8 | 1 | Mass/coupling in Poisson cases |
| Substitute a +3rq source-controlled mass shift | 189 / 11 | 1 | Wrong mass and reserved prediction |
| Reduce kernel endpoint order from four to three | 170 / 30 | 1 | Nonzero third endpoint trace and fourth-order IBP |
| Replace 1-eta by 1+eta | 199 / 1 | 1 | Sharp rational error-bound witness |

No unexpected baseline execution or mathematical-check failure occurred. All deliberately failed copies and the less accurate coarse-grid diagnostics remain. FAILURE_AND_LIMITS_v1.json and damages_v1/DAMAGE_RECEIPT_v1.json identify their dispositions.

## Practical limits and completion

The inverse remains conditional on a constant calibrated local model, a consistent clock/frame, k>0, r>0, q>0, M²>0, sound speed squared positive, a fixed chosen gravity model, adequate readout regularity and actual feature rank. It inherits the prerequisite's nonrelativistic pressure/rest-source, frozen-background and optional Poisson approximations. Its continuum mode equations do not establish a material or cosmological validity window. Uniform readout error, quadrature/finite-sampling control, linear-solve error, uncertain calibrations, varying readout geometry, omitted physics and drift need their own budgets before experimental use. The beta sign is not determined. No background selection, measured calibration, real signal, likelihood, observed exclusion, or complete fundamental action is supplied.

The final three live/snapshot pairs are unchanged. Original science sources and all earlier independent seals were untouched. COMMANDS_v1.json records the actual shell commands; BASELINE_RUN_v1.json and the damage run records bind executions to code and outputs. RESULT_SUMMARY_v1.json records Python and library versions. The final artifact manifest and receipt bind this report, sources, protocols, code, full outputs, failures and provenance. This unit is ready for the parent's bounded source integration; it supplies no formal audit/status promotion.

