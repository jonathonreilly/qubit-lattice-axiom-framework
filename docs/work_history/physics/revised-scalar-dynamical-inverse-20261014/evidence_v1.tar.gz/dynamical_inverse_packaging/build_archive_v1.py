from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'dynamical_inverse_packaging';dest=wt/'docs/work_history/physics/revised-scalar-dynamical-inverse-20261014'
roots=['rolling_local_response/dynamical_density_response_v1','rolling_local_response/weak_density_inverse_v1','dynamical_inverse_canonical_correspondence_v1','dynamical_inverse_packaging']
seal_units=['rolling_local_response/dynamical_density_response_v1/independent_v1','rolling_local_response/weak_density_inverse_v1/independent_v1','dynamical_inverse_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional local material dynamics and finite-window weak inverse, with full source histories and independent checks. No selected action/state/scale or measured likelihood.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for scalar material dynamics and finite-window inverse

Live claim: docs/EXPONENTIAL_SCALAR_DYNAMICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

Particle conservation and a supplied compressional law determine a dispersive
density response, its independent fluid mode and a two-mode determinant. They
do not justify choosing a universal constant source-control p. A derivative-free
finite-window inverse eliminates unknown amplitudes and phases only when actual
measured features have full rank and calibration/model/error premises hold.
Neither a selected state nor material law, environmental geometry or observed
likelihood is derived. The all-k continuum has no demonstrated real scale window.
Real-frequency i0 applies only to a stable bare resolvent; growing coupled systems
need the stated growth-aware Laplace contour or finite-time fundamental solution.

Fresh canonical225/0=99 dynamics+126 inverse, complete JSON equal to staged output.
Eight dynamics and four weak-inverse full original profiles are retained. Source
controls20 causal and8 long-wave are separately preserved, not counted in225.
Independent source119/0 and200/0, each with7 actual damaged-program probes, are
reused through exact seals. Staged72/0 correspondence,42/0 wrapper-stub controls,
and300/0 binding are packaging checks. Four actual wrapper damages are retained;
three full actual parent damages produced189/36,207/18,206/19.

Original dynamics93/6 and inverse123/3 failures, exact fixes, source histories,
commands, streams and profiles remain. Dynamics tightens numerical resolution;
the inverse repairs a symbolic generator and uses known synthetic derivatives
only in a separate quadrature control. It never differentiates measured noisy
input. Reviewer107/12 before119/0 is retained. Later author cache metadata failed
on a PosixPath after the live cache was successfully written; complete output
was recovered from that intact cache without rerunning science. The temporary
wrong cache-helper name and its correction are recorded.

All mock traces are synthetic; the reserved wave number is a same-model prediction
control, not held-out observational data. There is no empirical confidence level,
selected fundamental action, absolute scale or realized cosmological history.
Extract safe regular relative members and verify each manifest size/hash.
Archive-build/commit, delivery and UNIT records follow this archive.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
