#!/usr/local/bin/python3
"""Conditional leading nonrelativistic local matter/scalar dynamics."""
from pathlib import Path
import json,hashlib,argparse
import sympy as s
import numpy as np
from scipy.linalg import expm
from scipy.integrate import solve_ivp

FORCE_SIGN=s.Integer(1)
KINETIC_FACTOR=s.Integer(2)
MASS_SHIFT=s.Integer(3)
GRAVITY_SIGN=s.Integer(1)

def run(output_dir):
    checks=[]
    def eq(name,e):
        v=s.factor(s.cancel(s.together(e)))
        checks.append(dict(name=name,passed=v==0,residual=str(v)))
    def ck(name,ok,detail=None):checks.append(dict(name=name,passed=bool(ok),detail=detail))
    Q,rho,beta,vs,x,m2=s.symbols('Q rho beta vs2 k2 M2',positive=True)
    X,Xt,Xr,Zt,Zr=s.symbols('X Xt Xr Zt Zr',real=True)
    Xtt,Xrr,Ztt,Zrr,Zx=s.symbols('Xtt Xrr Ztt Zrr Zx',real=True)
    c=rho/(KINETIC_FACTOR*Q);q=beta**2;g=c*q
    L=Q*(Xt**2-Xr**2-m2*X**2)+rho*Zt**2/2-rho*vs*Zr**2/2+rho*beta*X*Zr
    # Independent jet Euler-Lagrange derivatives of the frozen 1D model.
    ELX=2*Q*Xtt-2*Q*Xrr-s.diff(L,X)
    ELZ=rho*Ztt-rho*vs*Zrr+rho*beta*Xr
    eq('scalar_EL_and_actual_kinetic',ELX/(2*Q)-(Xtt-Xrr+m2*X-c*beta*Zr))
    eq('fluid_EL_continuity',ELZ/rho-(Ztt-vs*Zrr+beta*Xr))
    eq('cross_derivative_reciprocity',s.diff(L,X,Zr)-rho*beta)
    eq('kinetic_energy_density_normalization',s.diff(L,Xt,2)-2*Q)
    eq('stationary_energy_linear_cancellation',rho*(s.Symbol('delta')+beta*X)-rho*beta*X-rho*s.Symbol('delta'))
    y=s.symbols('omega2',real=True)
    mass=m2+MASS_SHIFT*c*q
    for gravity in [0,1]:
        a=x+mass;b=vs*x-GRAVITY_SIGN*gravity*c
        mat=s.Matrix([[a-y,FORCE_SIGN*c*beta],[beta*x,b-y]])
        det=(x+m2-y)*(vs*x-gravity*rho/(2*Q)-y)-(rho/(2*Q))*q*x
        eq('full_coupled_determinant_'+str(gravity),mat.det()-det)
        canonical=s.diag(1,s.sqrt(x/c))
        M=canonical.inv()*(mat+y*s.eye(2))*canonical
        eq('canonical_symmetry_'+str(gravity),M[0,1]-M[1,0])
        eq('canonical_off_diagonal_'+str(gravity),M[0,1]-beta*s.sqrt(c*x))
        peff=-x/(b-y)
        eq('eliminate_density_response_'+str(gravity),(b-y)*beta*peff+beta*x)
        eq('scalar_schur_complement_'+str(gravity),mat.det()/(b-y)-(a-y-c*q*x/(b-y)))
        eq('acoustic_pole_not_a_coupled_pole_'+str(gravity),mat.det().subs(y,b)+g*x)
        tr=a+b;dis=(a-b)**2+4*g*x
        eq('root_discriminant_'+str(gravity),tr**2-4*mat.det().subs(y,0)-dis)
        yp=(tr+s.sqrt(dis))/2;ym=(tr-s.sqrt(dis))/2
        eq('root_plus_'+str(gravity),mat.det().subs(y,yp))
        eq('root_minus_'+str(gravity),mat.det().subs(y,ym))
        eq('sum_of_roots_'+str(gravity),yp+ym-tr)
        eq('product_of_roots_'+str(gravity),yp*ym-mat.det().subs(y,0))
        gamma2=s.symbols('gamma2',positive=True)
        eq('growth_equation_'+str(gravity),mat.det().subs(y,-gamma2)/(a+gamma2)-(gamma2+vs*x-GRAVITY_SIGN*gravity*c-g*x/(a+gamma2)))
    peff=-x/(vs*x-y)
    eq('high_frequency_particle_density',s.limit(peff,y,s.oo))
    eq('static_compressional_response',peff.subs(y,0)+1/vs)
    ck('static_compressional_response_is_not_three',s.simplify(peff.subs(y,0)-3).is_negative)
    eq('dust_static_division_has_pole',s.limit(vs*peff.subs(y,0),vs,0)+1)
    # Fixed-metric threshold from previous scale-free stationary identity.
    B=s.symbols('B',positive=True)
    bound=2*vs/(1+3*vs)
    eq('all_wavelength_susceptibility_threshold',(vs*(2/B-3)-1)-(1+3*vs)*(bound-B)/B)
    eq('fixed_metric_determinant',((x+m2)*(vs*x)-g*x)/x-(vs*(x+m2)-g))
    eq('threshold_equality_positive_finite_k',(vs*(x+m2)-g).subs(m2,g/vs)-vs*x)
    # Tensor Jeans polynomial and exact bracketing by the two limiting forces.
    P=vs*x**2+(vs*mass-c*(1+q))*x-c*mass
    eq('Jeans_polynomial',P-((x+mass)*(vs*x-GRAVITY_SIGN*c)-g*x))
    eq('Jeans_lower_endpoint',s.factor(P.subs(x,c/vs))+c*c*q/vs)
    eq('Jeans_upper_endpoint',s.factor(P.subs(x,c*(1+q)/vs))-c*mass*q)
    ck('Jeans_lower_endpoint_strict',(-c*c*q/vs).is_negative)
    ck('Jeans_upper_endpoint_strict',(c*m2*q).is_positive)
    ck('Jeans_root_product_negative',(-c*m2/vs).is_negative)
    upper=c*(1+q)
    gamma2=s.symbols('gamma2',positive=True)
    rate=c-vs*x+g*x/(x+m2+gamma2)
    eq('growth_ceiling_positive_remainder',upper-rate-(vs*x+g*(m2+gamma2)/(x+m2+gamma2)))
    ck('strict_growth_ceiling',s.simplify(vs*x+g*(m2+gamma2)/(x+m2+gamma2)).is_positive)
    eps=s.symbols('epsilon',positive=True)
    eq('candidate_q_envelope',(s.Rational(4,3)*c-upper).subs(q,s.Rational(1,3)-eps)-c*eps)
    # Frozen-frame changes preserve all ratios, wave roots and Jeans bounds.
    A=s.symbols('A',positive=True)
    detE=(x+m2-y)*(vs*x-c-y)-c*q*x
    detJ=(x/A**2+m2/A**2-y/A**2)*(vs*x/A**2-c/A**2-y/A**2)-(c/A**2)*q*(x/A**2)
    eq('frame_dispersion_scaling',detJ-detE/A**4)
    # Canonical conservative mechanical energy, including indefinite cases.
    Xd,Dd,D=s.symbols('Xd Dd D',real=True);a=x+m2;b=vs*x-c;off=beta*s.sqrt(c*x)
    energy=Xd**2+Dd**2+a*X**2+b*D**2+2*off*X*D
    edot=s.diff(energy,X)*Xd+s.diff(energy,D)*Dd+s.diff(energy,Xd)*(-a*X-off*D)+s.diff(energy,Dd)*(-b*D-off*X)
    eq('canonical_energy_conservation',edot)

    # Eight independently posed initial-value cases. Exact matrix exponentials
    # are compared to an adaptive Runge-Kutta integration of the first-order ODE.
    cases=[];out=Path(output_dir);out.mkdir(exist_ok=True)
    config=[(0,.01,.2,.05,.4),(0,.04,.2,4.,.3),(0,.04,.2,4.,4.),(0,.01,.2,.05,8.),
            (1,.01,.2,.05,.4),(1,.04,.2,4.,3.),(1,.04,.2,4.,8.),(1,.01,.2,.05,14.)]
    for idx,(grav,cs,qv,mv,kv) in enumerate(config):
        cv=1.;bbeta=np.sqrt(qv);xx=kv*kv
        # Actual implementation constants remain active in these program copies.
        ccode=cv*2/float(KINETIC_FACTOR);masscode=mv+float(MASS_SHIFT)*ccode*qv
        aa=xx+masscode;bb=cs*xx-float(GRAVITY_SIGN)*grav*ccode
        O=np.array([[0,0,1,0],[0,0,0,1],[-aa,-float(FORCE_SIGN)*ccode*bbeta,0,0],[-bbeta*xx,-bb,0,0]],float)
        init=np.array([1.,-.7,.11,-.03])*1e-5
        ts=np.linspace(0,3,241)
        sol=solve_ivp(lambda t,z:O@z,(ts[0],ts[-1]),init,t_eval=ts,method='DOP853',rtol=2e-13,atol=1e-18)
        direct=sol.y.T;reference=np.array([expm(O*t)@init for t in ts])
        err=float(np.max(abs(direct-reference))/(1e-8+np.max(abs(reference))))
        ck('ODE_matrix_exponential_'+str(idx),sol.success and err<2e-8,dict(error=err,solver_message=sol.message))
        truea=xx+mv;trueb=cs*xx-grav*cv
        freq=np.linalg.eigvalsh(np.array([[truea,bbeta*np.sqrt(cv*xx)],[bbeta*np.sqrt(cv*xx),trueb]]))
        predicted=np.array([(truea+trueb-np.sqrt((truea-trueb)**2+4*cv*qv*xx))/2,(truea+trueb+np.sqrt((truea-trueb)**2+4*cv*qv*xx))/2])
        ck('coupled_eigenfrequency_'+str(idx),np.max(abs(freq-predicted))<5e-13,dict(eigenvalues=freq.tolist(),formula=predicted.tolist()))
        ode_ev=np.linalg.eigvals(O)
        ck('ODE_dispersion_roots_'+str(idx),max(min(abs(-ev*ev-f) for ev in ode_ev) for f in freq)<5e-11)
        if grav:
            xj=(cv*(1+qv)-cs*mv+np.sqrt((cs*mv-cv*(1+qv))**2+4*cs*cv*mv))/(2*cs)
            ck('Jeans_threshold_bracket_'+str(idx),cv/cs<xj<cv*(1+qv)/cs,xj)
            ck('Jeans_threshold_classifies_mode_'+str(idx),bool(freq[0]>0)==bool(xx>xj))
        else:
            xj=None;ck('fixed_metric_threshold_classifies_mode_'+str(idx),bool(freq[0]>0)==bool(cs*(xx+mv)>cv*qv))
        gamma_sq=max(0.,-float(freq[0]));ceiling=cv*((1+qv) if grav else qv)
        ck('growth_rate_envelope_'+str(idx),gamma_sq<ceiling,dict(gamma_squared=gamma_sq,ceiling=ceiling))
        dd=np.sqrt(cv/xx)*direct[:,1];ddot=np.sqrt(cv/xx)*direct[:,3]
        terms=np.array([direct[:,2]**2,ddot**2,truea*direct[:,0]**2,trueb*dd**2,2*bbeta*np.sqrt(cv*xx)*direct[:,0]*dd])
        en=terms.sum(axis=0);drift=float(np.max(abs(en-en[0]))/(1e-20+np.max(abs(terms).sum(axis=0))))
        ck('numerical_conservative_energy_'+str(idx),drift<3e-10,drift)
        path=out/('profile_'+str(idx)+'.npz');assert not path.exists();np.savez_compressed(path,t=ts,state=direct,exact_reference=reference,canonical_energy=en,frequency_squared=freq,ode_matrix=O,initial_state=init)
        cases.append(dict(index=idx,gravity=grav,cs_squared=cs,q=qv,M_squared=mv,k=kv,cR=cv,profile=str(path.name),profile_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),frequency_squared=freq.tolist(),Jeans_k_squared=xj,growth_squared=gamma_sq,ODE_error=err,energy_drift=drift))
    return dict(passed=sum(a['passed'] for a in checks),failed=sum(not a['passed'] for a in checks),checks=checks,synthetic_cases=cases,scope='Specified nonrelativistic local material and optional Newtonian patch only; no empirical fit or selected equilibrium/initial state.')

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--output',required=True);a.add_argument('--profiles',required=True);args=a.parse_args()
    result=run(args.profiles);result['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();p=Path(args.output);assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['passed','failed','scope']}))
    for row in result['checks']:
        if not row['passed']:print(json.dumps(row))
    raise SystemExit(bool(result['failed']))
