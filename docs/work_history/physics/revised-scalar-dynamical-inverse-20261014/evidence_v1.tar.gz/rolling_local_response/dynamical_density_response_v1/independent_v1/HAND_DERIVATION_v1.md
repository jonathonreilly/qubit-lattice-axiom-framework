# Blind independent derivation before executable science

This unit checks the parent-authored frozen dynamical-density hand source only.
No producer implementation or output is read, imported, or executed. The parent
retains authorship. Primary Bean/Flanagan/Trodden PDF pp.3-5,9-10 was independently
extracted and visually read; its pressure trace, number current, force and
validity limits are convention/scope checks, not empirical inputs.

## Particle and displacement normalization

Expand the rest-particle action -m A(chi) ds_E about chi0 with zero velocity:
-m A0[1+beta X+(beta^2+beta')X^2/2-v^2/2+Psi], to quadratic order.
At a frozen background the term dot A times v is second order, so the linear
particle force is vdot=-beta grad X-grad Psi. Conserved particle labels yield
delta=-div xi, delta_dot+div v=0. Pressure is a separately supplied linear
compressional energy rhoE s(div xi)^2/2, where s=v_s^2.

Expanding the Lagrangian particle-position coupling gives -rhoE beta xi.grad X;
integrating its divergence gives +rhoE beta X div xi. Combined with the scalar
kinetic coefficient 2Q, the quadratic Lagrangian yields
 Xddot-Delta X+M^2 X=-rhoE beta delta/(2Q)=-r beta delta,
 xiddot=s grad div xi-beta grad X,
 deltaddot-s Delta delta=beta Delta X.
M^2 is the fixed-particle Hessian (VE''+rhoStar A'')/(2Q); replacing it by the
fixed-physical-density coefficient M^2+3r q changes the perturbation problem.
The free displacement kinetic term is positive. A negative coupled frequency
is therefore an instability of the potential quadratic form, not a ghost.

Use z=k_wave^2>0, m=M^2>0, r=rhoE/(2Q)>0, s>=0, beta real,
q=beta^2 and g=r q. The mode equations are qvec_ddot+P qvec=0 with
 P=[[z+m,r beta],[z beta,s z]]
in variables (X,delta). delta=sqrt(z/r) D turns P into the symmetric K with
off-diagonal h=beta sqrt(r z), and turns both kinetic terms into Q times the
squared velocity. The physical-frame squared rates divide by A0^2; since
rhoE=A0^4 rhoJ, r/A0^2=A0^2 rhoJ/(2Q)=4pi Gbare rhoJ.

## Response, independent mode and contour

For harmonic forcing with y=omega^2, the fluid equation gives
 delta=-beta z X/(b-y), b=s z,
provided b-y!=0. A literal p=delta/(beta X) also needs beta X!=0; beta=0 is
decoupled. The driven transfer coefficient is -z/(b-y), with zero independent
fluid homogeneous solution. A general IVP adds that homogeneous solution.

For b>0 the causal kernel is sin(sqrt(b)t)/sqrt(b) for t>=0; b=0 gives t;
b<0 gives sinh(sqrt(-b)t)/sqrt(-b). Its Laplace transform is 1/(sigma^2+b)
only to the right of its growing poles: Re sigma>sqrt(-b) when b<0, and
Re sigma>0 for the undamped stable kernel. A full coupled unstable system also
has growing poles even when its bare b>0. A real-frequency omega+i0 transform
does not exist as an ordinary retarded transform there: with convention
exp(-i omega t), a Bromwich line requires Im omega above all growth rates.
Finite-time causal Green functions remain well-defined.

This is a substantive qualification of v1's general retarded wording, already
reported to the author before code. The source has been preserved and the
author reports a separate correction; its complete corrected text will be
checked later. The algebraic harmonic equations and determinant are unaffected.

The full scalar susceptibility is (b-y)/[(a-y)(b-y)-g z]. At bare y=b the full
determinant is -g z, not zero for q>0; the scalar entry vanishes rather than
having that bare pole. Dividing first can hide this distinction. The two true
squared frequencies are eigenvalues of K:
 (a+b +/- sqrt((a-b)^2+4g z))/2.
An unstable eigenvalue has a causal hyperbolic-sine kernel; no bounded Fourier
response or statistical stationarity is inferred.

## Fixed-metric stability

For s>0, a,b positive at each z>0. Sylvester positivity reduces to
 detK=z[s(z+m)-g]>0.
Thus at a given z both modes are positive iff s(z+m)>g; equality is neutral.
For all finite z>0, positivity is equivalent to s m>=g.
For s=0 and g>0 the determinant is negative at every z>0. beta=0 separates.

On the positive stationary branch,
 m/g=M_J^2/g_J=2F rhoJ'/rhoJ-3=2/B-3.
This follows by substituting the prior independently checked fixed-particle
mass and g_J=q rhoJ/(2F), without repeating the full action inverse.
Therefore all-mode positivity is B<=2s/(1+3s), with 0<B<2/3 and s>0.
At strict inequality yminus=(s-g/m)z+O(z^2); at equality
yminus=(s/m)z^2+O(z^3). Both tend to zero as z tends to zero; no case has a
uniform strictly positive long-wave gap. At equality, arbitrarily small
omitted corrections increasing g create a negative mode at sufficiently small
z. This is a sensitivity illustration, not a derived relativistic correction.

For yminus=-gamma^2<0, eliminating X gives
 gamma^2=-s z+g z/(z+m+gamma^2)<g.
The source's weak <=g bound is valid. It does not make the frozen patch a
cosmological solution or establish a wavelength/time window.

## Leading Poisson extension

At stationarity VE_chi=-rhoE beta. The first-order scalar part of rest energy
rhoE(delta+beta X) cancels VE_chi X, leaving delta rho_total=rhoE delta at this
order. With gradients quadratic and the homogeneous gravitating background
subtracted, leading Newtonian Poisson is Delta Psi=r delta.
This gives b=s z-r. It is an imposed local nonzero-k Newtonian model, not a
uniform Minkowski solution of the full equations.

For s>0, detK=s z^2+[s m-r(1+q)]z-rm. Its constant term is negative, so the
quadratic has one positive root zJ. At that root
 s zJ=r+g zJ/(zJ+m), hence r/s<zJ<r(1+q)/s for q,m>0.
Below it detK<0; above it b>0 and K is positive. s=0 has no finite threshold.
For a growing mode,
 gamma^2=r-s z+g z/(z+m+gamma^2)<r(1+q).
The candidate has q=a/J<1/3, from a=(1-k)(1+3k)/4 and J=1+(1-3a)s0 E>1,
so gamma^2<(4/3)r and the same dimensionless bound holds after dividing by A0^2.

The candidate coupling bound does not imply expansion is negligible. Rates of
order sqrt(r) need an independent background comparison. Pressure/internal
energy corrections affect scalar trace/inertia at the omitted NR order;
near-neutral conclusions can change. Microscopic dispersion, free streaming,
boundaries, reservoirs, finite-volume wave-number cutoffs, metric corrections,
and background inhomogeneity are not supplied. No all-scale material,
relativistic stability, fast cosmological exclusion, or measured calibration
follows.

## Distinct controls chosen before code

Compute Euler derivatives of the real 1+1 scalar/displacement Lagrangian,
particle expansion, canonical similarity/kinetic normalization, resolvent,
pole and root identities. Use exact rational parameters, both signs of beta,
zero coupling and dust edge cases, positive and negative bare b, a stable and
an unstable coupled sector, and the marginal low-wave-number series.

Use a direct raw-coordinate ODE and independently diagonalized symmetric-mode
fundamental solutions for six disclosed off-grid frozen examples. Preserve
every sampled profile and energy diagnostic. Add independent fluid initial
data and a causal forcing control; test that omitting the homogeneous solution
does not solve that IVP. Check the unstable Green kernel with a convergent
Laplace integral above its pole and a divergent finite-cutoff integral below it.

Actual one-edit damaged scripts will reverse the fluid force, omit the kinetic
factor two, replace M0 by M3, reverse gravity, change the particle-volume power,
reverse the response sign, and admit a Laplace contour below the growth rate.
Each is executed against unchanged controls, with errors and outputs retained.

