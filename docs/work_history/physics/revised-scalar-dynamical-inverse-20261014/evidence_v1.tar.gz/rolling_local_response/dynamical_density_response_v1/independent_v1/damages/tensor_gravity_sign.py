from pathlib import Path
import hashlib,json,sys
import sympy as S
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp
mp.mp.dps=60

FLUID_FORCE_SIGN=1
SCALAR_DIVISOR=2
MASS_SHIFT=0
GRAVITY_SIGN=-1
DENSITY_FRAME_POWER=3
PEFF_SIGN=-1
CAUSAL_ABSCISSA_SIGN=1

H=Path.cwd()
rows=[]
def ck(name,value,**data):rows.append(dict(name=name,passed=bool(value),**data))
def eq(name,value):
 v=S.simplify(value);ck(name,v==0,residual=str(v))
t,ell=S.symbols('t ell',real=True)
Q,r,m,z,s=S.symbols('Q r m z s',positive=True)
beta=S.symbols('beta',real=True,nonzero=True)
g=r*beta**2
X=S.Function('X')(t,ell);xi=S.Function('xi')(t,ell)
rho=2*Q*r
L=Q*(S.diff(X,t)**2-S.diff(X,ell)**2-m*X**2)+rho*S.diff(xi,t)**2/2-rho*s*S.diff(xi,ell)**2/2+rho*beta*X*S.diff(xi,ell)
def EL(f):return S.diff(S.diff(L,S.diff(f,t)),t)+S.diff(S.diff(L,S.diff(f,ell)),ell)-S.diff(L,f)
a=z+2*m/SCALAR_DIVISOR+MASS_SHIFT*g
cross=2*r*beta/SCALAR_DIVISOR
f=FLUID_FORCE_SIGN*beta*z
J=S.symbols('J',real=True)
b=s*z-GRAVITY_SIGN*J*r
eq('scalar_Euler_normalization',EL(X)/(2*Q)-(S.diff(X,t,2)-S.diff(X,ell,2)+(2*m/SCALAR_DIVISOR+MASS_SHIFT*g)*X-cross*S.diff(xi,ell)))
eq('displacement_Euler_force',EL(xi)/rho-(S.diff(xi,t,2)-s*S.diff(xi,ell,2)+FLUID_FORCE_SIGN*beta*S.diff(X,ell)))
eq('density_equation_divergence',-S.diff(EL(xi)/rho,ell)-(-S.diff(xi,t,2,ell)+s*S.diff(xi,ell,3)-beta*S.diff(X,ell,2)))
eq('position_to_density_cross_boundary',-rho*beta*xi*S.diff(X,ell)-rho*beta*X*S.diff(xi,ell)+rho*beta*S.diff(xi*X,ell))
eq('scalar_kinetic_Hessian',S.diff(L,S.diff(X,t),2)-2*Q)
eq('fluid_kinetic_Hessian',S.diff(L,S.diff(xi,t),2)-rho)

eps,A0,mpart,xx,vv,beta1=S.symbols('eps A0 mpart xx vv beta1',real=True)
particle=-mpart*A0*S.exp(eps*beta*xx+eps**2*beta1*xx**2/2)*S.sqrt(1-eps**2*vv**2)
quad=S.expand(S.series(particle,eps,0,3).removeO()).coeff(eps,2)
eq('particle_rest_and_inertia_expansion',quad-mpart*A0*(vv**2-(beta**2+beta1)*xx**2)/2)
chi=S.symbols('chi',real=True)
AA=A0*S.exp(beta*chi+beta1*chi**2/2)
VE=-rho*beta*chi+(2*Q*m-rho*(beta**2+beta1))*chi**2/2
eff=VE+rho*AA/A0
eq('stationary_scalar_force',S.diff(eff,chi).subs(chi,0))
derived_mass=S.diff(eff,chi,2).subs(chi,0)/(SCALAR_DIVISOR*Q)+MASS_SHIFT*g
eq('fixed_particle_Hessian_mass',derived_mass-m)
eq('fixed_physical_mass_difference',S.diff(eff,chi,2).subs(chi,0)/(2*Q)+3*g-(m+3*g))

T=S.diag(1,S.sqrt(z/r))
P=S.Matrix([[a,cross],[f,b]])
K=T.inv()*P*T
K0=S.Matrix([[z+m,beta*S.sqrt(r*z)],[beta*S.sqrt(r*z),s*z-J*r]])
for i in range(2):
 for j in range(2):eq(f'canonical_matrix_{i}{j}',K[i,j]-K0[i,j])
eq('canonical_equal_kinetic',rho/(2*z)*(z/r)-Q)
eq('canonical_reciprocity',K[0,1]-K[1,0])
y,lam=S.symbols('y lam',real=True)
det=(P-y*S.eye(2)).det()
target=(z+m-y)*(s*z-J*r-y)-g*z
eq('coupled_determinant',det-target)
A4=S.zeros(4);A4[:2,2:]=S.eye(2);A4[2:,:2]=-P
cp=A4.charpoly(lam)
eq('first_order_characteristic',cp.as_expr().subs(cp.gen,lam)-target.subs(y,-lam**2))
u0,u1,w0,w1=S.symbols('u0 u1 w0 w1',real=True)
eq('quadratic_energy_conservation',(S.Matrix([w0,w1]).T*(K0-K)*S.Matrix([u0,u1]))[0])
disc=(z+m-(s*z-J*r))**2+4*g*z
yp=(z+m+s*z-J*r+S.sqrt(disc))/2
ym=(z+m+s*z-J*r-S.sqrt(disc))/2
eq('root_sum',yp+ym-(z+m+s*z-J*r))
eq('root_product',yp*ym-(K0.det()))
eq('root_substitution_minus',target.subs(y,ym))

# Driven response and exact full resolvent.
peff=PEFF_SIGN*z/(s*z-y)
eq('fluid_driven_equation',beta*z+(s*z-y)*beta*peff)
eq('static_response_sign',peff.subs(y,0)+1/s)
omega=S.symbols('omega',positive=True)
eq('high_frequency_response_limit',S.limit(peff.subs(y,omega**2),omega,S.oo))
eq('high_frequency_response_coefficient',S.limit(omega**2*peff.subs(y,omega**2),omega,S.oo)-z)
ck('dust_static_division_singular',(s*z-y).subs({s:0,y:0})==0)
ck('zero_coupling_literal_ratio_undefined',(beta*xx).subs(beta,0)==0)
resolvent=(P-y*S.eye(2)).inv()
eq('full_scalar_resolvent',resolvent[0,0]-(s*z-J*r-y)/target)
eq('bare_pole_is_not_coupled_pole',det.subs(y,s*z-J*r)+g*z)
eq('full_scalar_zero_at_bare_pole',resolvent[0,0].subs(y,s*z-J*r))

# Physical normalization and primary-source canonical field mapping.
Ap,Qp,rhoJ=S.symbols('Ap Qp rhoJ',positive=True)
rhoStar=rhoJ*Ap**DENSITY_FRAME_POWER
rJ=Ap*rhoStar/(2*Qp*Ap**2)
Gbare=Ap**2/(8*S.pi*Qp)
eq('physical_frame_density_normalization',rJ-4*S.pi*Gbare*rhoJ)
eq('primary_canonical_coupling_mapping',2*Q*(beta/S.sqrt(2*Q))**2-beta**2)

# Exact stability, branch boundary and limiting domains.
fixed=K0.subs(J,0)
eq('fixed_metric_Sylvester_determinant',fixed.det()-z*(s*(z+m)-g))
eq('dust_negative_determinant',fixed.det().subs(s,0)+g*z)
ck('dust_strict_negative',(-g*z).is_negative)
B=S.symbols('B',positive=True)
eq('susceptibility_stability_translation',(s*m-g).subs(m,g*(2/B-3))-g*(2*s-B*(1+3*s))/B)
eq('strict_low_wave_coefficient',S.limit(ym.subs(J,0)/z,z,0)-(s-g/m))
ymcrit=ym.subs(J,0).subs(r,s*m/beta**2)
eq('critical_low_wave_coefficient',S.limit(ymcrit/z**2,z,0)-s/m)
eq('strict_long_wave_limit',S.limit(ym.subs(J,0),z,0))
eq('critical_long_wave_limit',S.limit(ymcrit,z,0))
small=S.symbols('small',positive=True)
near_det=(s*z*(z+m)-g*(1+small)*z).subs(r,s*m/beta**2)
eq('near_neutral_generic_correction_sensitivity',near_det-s*z*(z-small*m))
ck('near_neutral_negative_witness',S.simplify(near_det.subs({z:small*m/2})).is_negative)

# Leading Poisson cancellation, threshold and growth law.
eq('stationary_total_energy_cancellation',rho*(S.symbols('delta')+beta*xx)-rho*beta*xx-rho*S.symbols('delta'))
jeans=K0.subs(J,1).det()
eq('Jeans_polynomial',jeans-(s*z**2+(s*m-r*(1+beta**2))*z-r*m))
root=(r*(1+beta**2)-s*m+S.sqrt((s*m-r*(1+beta**2))**2+4*s*r*m))/(2*s)
eq('Jeans_root_exact',jeans.subs(z,root))
eq('Jeans_lower_bracket',jeans.subs(z,r/s)+g*r/s)
eq('Jeans_upper_bracket',jeans.subs(z,r*(1+beta**2)/s)-g*m)
ck('Jeans_unique_positive_root',(-r*m/s).is_negative)
ck('Jeans_lower_sign',(-g*r/s).is_negative)
ck('Jeans_upper_sign',(g*m).is_positive)
eq('dust_Jeans_no_positive_zero',jeans.subs(s,0)+r*((1+beta**2)*z+m))
grow=S.symbols('grow',positive=True)
growth_eq=grow-J*r+s*z-g*z/(z+m+grow)
eq('growth_equation_from_determinant',(z+m+grow)*growth_eq-target.subs(y,-grow))
eq('growth_ceiling_slack',J*r+g-(J*r-s*z+g*z/(z+m+grow))-(s*z+g*(m+grow)/(z+m+grow)))
ck('growth_slack_positive',(s*z+g*(m+grow)/(z+m+grow)).is_positive)
kc,e,sc=S.symbols('kc e sc',positive=True)
ac=(1-kc)*(1+3*kc)/4
Jc=1+(1-3*ac)*sc*e
eq('candidate_a_cap',S.Rational(1,3)-ac-(1-3*kc)**2/12)
eq('candidate_q_cap_gap',S.Rational(1,3)-ac/Jc-(1-3*ac)*(1+sc*e)/(3*Jc))
for kv,ev in [(S.Rational(1,10),S.Rational(1,9)),(S.Rational(2,7),S.Integer(2)),(S.Rational(1,60),S.Integer(14))]:
 qc=(ac/Jc).subs({kc:kv,e:ev,sc:S.Rational(7,5)})
 ck('candidate_q_interval_'+str(kv),0<qc<S.Rational(1,3))

# Causal kernels and their actual convergence half-plane.
tau=S.symbols('tau',nonnegative=True)
sig=S.symbols('sig',positive=True)
kap=S.Rational(3,7);wb=S.Rational(4,5)
stable_kernel=S.sin(wb*tau)/wb
unstable_kernel=S.sinh(kap*tau)/kap
eq('stable_kernel_ode',S.diff(stable_kernel,tau,2)+wb**2*stable_kernel)
eq('unstable_kernel_ode',S.diff(unstable_kernel,tau,2)-kap**2*unstable_kernel)
for label,ker in [('stable',stable_kernel),('unstable',unstable_kernel)]:
 eq(label+'_kernel_initial_value',ker.subs(tau,0))
 eq(label+'_kernel_initial_derivative',S.diff(ker,tau).subs(tau,0)-1)
eq('stable_Laplace_transform',S.laplace_transform(stable_kernel,tau,sig,noconds=True)-1/(sig**2+wb**2))
lap,abscissa,condition=S.laplace_transform(unstable_kernel,tau,sig,noconds=False)
eq('unstable_Laplace_transform',lap-1/(sig**2-kap**2))
eq('causal_growth_abscissa',CAUSAL_ABSCISSA_SIGN*kap-abscissa)
ck('below_growth_contour_rejected',not bool(kap/2>CAUSAL_ABSCISSA_SIGN*kap))
mpkap=mp.mpf(3)/7;mpgood=mp.mpf(5)/7;mpbad=mpkap/2
integral=mp.quad(lambda tt:mp.exp(-mpgood*tt)*mp.sinh(mpkap*tt)/mpkap,[0,mp.inf])
expected=1/(mpgood**2-mpkap**2)
ck('actual_convergent_Laplace_integral',abs(integral-expected)<mp.mpf('1e-50'),error=str(abs(integral-expected)))
def cutoff(T):
 return ((mp.exp((mpkap-mpbad)*T)-1)/(mpkap-mpbad)-(1-mp.exp(-(mpkap+mpbad)*T))/(mpkap+mpbad))/(2*mpkap)
cuts=[cutoff(mp.mpf(v)) for v in (14,28,56)]
ck('actual_below_pole_divergence_witness',0<cuts[0]<cuts[1]<cuts[2] and cuts[2]>100*cuts[1])
ck('below_pole_formal_rational_not_integral',1/(mpbad**2-mpkap**2)<0 and cuts[-1]>0)

# Independent raw ODE versus symmetric eigenmode fundamental solutions.
protocol=json.loads((H/'INDEPENDENT_PROTOCOL_v2.json').read_text())
def val(v):return float(S.Rational(v))
def rawP(c):
 mm,ss,rr,bb,zz,jj=[c[n] for n in ('m','s','r','beta','z','J')]
 gg=rr*bb*bb
 return np.array([[zz+2*mm/SCALAR_DIVISOR+MASS_SHIFT*gg,2*rr*bb/SCALAR_DIVISOR],[FLUID_FORCE_SIGN*bb*zz,ss*zz-GRAVITY_SIGN*jj*rr]],float)
def oracle(c):
 mm,ss,rr,bb,zz,jj=[c[n] for n in ('m','s','r','beta','z','J')]
 off=bb*np.sqrt(rr*zz)
 return np.array([[zz+mm,off],[off,ss*zz-jj*rr]],float)
def fundamental(eigen,tt):
 if eigen>1e-14:
  w=np.sqrt(eigen);return np.cos(w*tt),np.sin(w*tt)/w,-w*np.sin(w*tt)
 if eigen < -1e-14:
  w=np.sqrt(-eigen);return np.cosh(w*tt),np.sinh(w*tt)/w,w*np.sinh(w*tt)
 return np.ones_like(tt),tt,np.zeros_like(tt)
profiles=[]
for item in protocol['numerical_cases']:
 c={k:(v if k=='name' else (int(v) if k=='J' else val(v))) for k,v in item.items()}
 Kc=oracle(c);eig,V=np.linalg.eigh(Kc);PP=rawP(c);fac=np.sqrt(c['z']/c['r'])
 initial=np.array([float(x) for x in protocol['initial_raw_state']])
 q0=np.array([initial[0],initial[2]/fac]);v0=np.array([initial[1],initial[3]/fac])
 qm=V.T@q0;vm=V.T@v0
 end=13.25 if eig[0]>0 else 5.5
 times=np.linspace(0,end,protocol['profile_samples'])
 mode=np.empty((2,len(times)));modev=np.empty_like(mode)
 for j,ev in enumerate(eig):
  cc,ss,dc=fundamental(ev,times);mode[j]=qm[j]*cc+vm[j]*ss;modev[j]=qm[j]*dc+vm[j]*cc
 exq=V@mode;exv=V@modev
 exact=np.column_stack([exq[0],exv[0],fac*exq[1],fac*exv[1]])
 def rhs(tt,Y):return np.array([Y[1],-PP[0,0]*Y[0]-PP[0,1]*Y[2],Y[3],-PP[1,0]*Y[0]-PP[1,1]*Y[2]])
 sol=solve_ivp(rhs,(0,end),initial,t_eval=times,method='DOP853',rtol=protocol['rtol'],atol=protocol['atol'])
 ck(c['name']+'_ODE_completed',sol.success and sol.t.size==len(times))
 Y=sol.y.T
 scale=max(float(np.max(np.abs(exact))),1e-10);error=float(np.max(np.abs(Y-exact)))/scale
 ck(c['name']+'_full_profile',error<protocol['profile_scaled_tolerance'],scaled_error=error)
 qn=np.column_stack([Y[:,0],Y[:,2]/fac]);vn=np.column_stack([Y[:,1],Y[:,3]/fac])
 pot=np.einsum('ij,jk,ik->i',qn,Kc,qn);kin=np.sum(vn*vn,axis=1);energy=pot+kin
 energy_error=float(np.max(np.abs(energy-energy[0])))/max(float(np.max(np.abs(pot)+kin)),1e-30)
 ck(c['name']+'_energy',energy_error<protocol['energy_scaled_tolerance'],scaled_error=energy_error)
 ck(c['name']+'_linear_amplitude',float(np.max(np.abs(Y)))<.01)
 aa=c['z']+c['m'];bb=c['s']*c['z']-c['J']*c['r'];gg=c['r']*c['beta']**2
 roots=np.array([(aa+bb-np.sqrt((aa-bb)**2+4*gg*c['z']))/2,(aa+bb+np.sqrt((aa-bb)**2+4*gg*c['z']))/2])
 ck(c['name']+'_roots',np.max(np.abs(roots-eig))<2e-13)
 criterion=c['s']*(c['z']+c['m'])>gg if c['J']==0 else np.linalg.det(Kc)>0
 ck(c['name']+'_stability_domain',bool(eig[0]>0)==bool(criterion))
 if eig[0]<0:
  growth=-eig[0];bound=c['J']*c['r']+gg
  ck(c['name']+'_growth_ceiling',growth<bound and (c['J']==0 or growth<4*c['r']/3))
  ck(c['name']+'_growth_equation',abs(growth-(c['J']*c['r']-c['s']*c['z']+gg*c['z']/(c['z']+c['m']+growth)))<3e-14)
 profiles.append({'name':c['name'],'parameters':c,'squared_frequencies':eig.tolist(),'scaled_profile_error':error,'scaled_energy_error':energy_error,'max_abs_state':float(np.max(np.abs(Y))),'times':times.tolist(),'raw_ODE_profile':Y.tolist(),'canonical_eigenmode_profile':exact.tolist(),'energy_profile':energy.tolist(),'solver_nfev':sol.nfev})

# Fluid memory kernel: stable and unstable b, nonzero independent initial data.
forced=[]
for label,bv in [('stable',9/25),('unstable',-9/49)]:
 av=2/7;forcebeta=-2/9;zz=5/8
 times=np.linspace(0,4.75,91)
 if bv>0:w=np.sqrt(bv);cc=np.cos(w*times);sn=np.sin(w*times)/w
 else:w=np.sqrt(-bv);cc=np.cosh(w*times);sn=np.sinh(w*times)/w
 coeff=-forcebeta*zz/(av*av+bv)
 zero=coeff*(np.exp(-av*times)-cc+av*sn)
 d0=1/13;v0=-1/17
 exact=zero+d0*cc+v0*sn
 sol=solve_ivp(lambda tt,Y:[Y[1],-bv*Y[0]-forcebeta*zz*np.exp(-av*tt)],(0,times[-1]),[d0,v0],t_eval=times,method='DOP853',rtol=2e-12,atol=2e-14)
 err=float(np.max(np.abs(sol.y[0]-exact)))
 ck('forced_'+label+'_homogeneous_IVP',sol.success and err<2e-11,error=err)
 ck('forced_'+label+'_homogeneous_cannot_be_dropped',abs(zero[0]-d0)>0.07)
 forced.append({'label':label,'b':bv,'times':times.tolist(),'ODE_delta':sol.y[0].tolist(),'analytic_with_independent_mode':exact.tolist(),'zero_independent_mode':zero.tolist(),'max_error':err})
out={'scope':'Blind independent quadratic material response, conditional fixed patch, no empirical fit or producer code','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'full_profiles':profiles,'forced_fluid_profiles':forced,'causal_integral':{'kappa':str(mpkap),'above_pole_sigma':str(mpgood),'integral':str(integral),'expected':str(expected),'below_pole_sigma':str(mpbad),'cutoff_times':[14,28,56],'partial_integrals':[str(v) for v in cuts]},'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((H/'INDEPENDENT_PROTOCOL_v2.json').read_bytes()).hexdigest(),'libraries':{'sympy':S.__version__,'numpy':np.__version__,'mpmath':mp.__version__}}
print(json.dumps(out,indent=2));raise SystemExit(bool(out['failed']))

