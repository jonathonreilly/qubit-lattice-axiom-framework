from pathlib import Path
import json,subprocess,datetime,hashlib,difflib
H=Path(__file__).resolve().parent
source=(H/'check_dynamical_v2.py').read_text()
out=H/'damages';out.mkdir(exist_ok=False)
cases=[
 ('fluid_force_sign','FLUID_FORCE_SIGN=1','FLUID_FORCE_SIGN=-1','displacement_Euler_force'),
 ('scalar_kinetic_factor','SCALAR_DIVISOR=2','SCALAR_DIVISOR=1','fixed_particle_Hessian_mass'),
 ('M0_replaced_by_M3','MASS_SHIFT=0','MASS_SHIFT=3','fixed_particle_Hessian_mass'),
 ('tensor_gravity_sign','GRAVITY_SIGN=1','GRAVITY_SIGN=-1','canonical_matrix_11'),
 ('particle_volume_power','DENSITY_FRAME_POWER=3','DENSITY_FRAME_POWER=4','physical_frame_density_normalization'),
 ('response_sign','PEFF_SIGN=-1','PEFF_SIGN=1','static_response_sign'),
 ('wrong_causal_abscissa','CAUSAL_ABSCISSA_SIGN=1','CAUSAL_ABSCISSA_SIGN=-1','causal_growth_abscissa')]
(H/'DAMAGE_PROTOCOL_v1.json').open('x').write(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'independent_protocol':'INDEPENDENT_PROTOCOL_v2.json','cases':[{'name':n,'old':o,'new':v,'required_failed_control':r} for n,o,v,r in cases]},indent=2)+'\n')
records=[]
for name,old,new,required in cases:
 assert source.count(old)==1
 changed=source.replace(old,new);p=out/(name+'.py');p.open('x').write(changed)
 (out/(name+'.diff')).open('x').write(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='check_dynamical_v2.py',tofile=p.name)))
 argv=['/usr/local/bin/python3','-B',str(p)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();run=subprocess.run(argv,cwd=H,capture_output=True);end=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (out/(name+'_results.json')).open('xb').write(run.stdout);(out/(name+'_stderr.txt')).open('xb').write(run.stderr)
 try:
  result=json.loads(run.stdout);fails=[v['name'] for v in result['checks'] if not v['passed']]
 except Exception as exc:
  result={'passed':None,'failed':None};fails=[];parse_error=str(exc)
 record={'name':name,'argv':argv,'cwd':str(H),'started_utc':start,'completed_utc':end,'exit_code':run.returncode,'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr).hexdigest(),'passed':result['passed'],'failed':result['failed'],'failed_controls':fails,'required_failed_control':required,'required_failure_observed':required in fails,'intended_rejection':run.returncode==1 and required in fails}
 if result['passed'] is None:record['parse_error']=parse_error
 (out/(name+'_run.json')).open('x').write(json.dumps(record,indent=2)+'\n');records.append(record)
summary={'source_baseline':'119/0; original failed baseline 107/12 retained','actual_damage_count':len(records),'intended_rejections':sum(r['intended_rejection'] for r in records),'records':records}
(H/'DAMAGE_SUMMARY_v1.json').open('x').write(json.dumps(summary,indent=2)+'\n')
print(json.dumps([{'name':r['name'],'passed':r['passed'],'failed':r['failed'],'intended_rejection':r['intended_rejection']} for r in records],indent=2))
raise SystemExit(any(not r['intended_rejection'] for r in records))

