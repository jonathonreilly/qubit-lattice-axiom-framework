from pathlib import Path
import hashlib,json,datetime
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.open('x').write(json.dumps(x,indent=2)+'\n')
assert not (H/'MANIFEST_v1.json').exists() and not (H/'RECEIPT_v1.json').exists()
final=json.loads((H/'FINAL_VERIFICATION_v1.json').read_text());assert final['passed']==125 and final['failed']==0
pairs=json.loads((H/'SOURCE_BINDINGS_FINAL_v1.json').read_text())['source_pairs']
assert len(pairs)==11
for p in pairs:assert sha(Path(p['original_path']))==sha(H/p['snapshot_path'])==p['sha256']
base1=json.loads((H/'BASELINE_RESULTS_v1.json').read_text());base2=json.loads((H/'BASELINE_RESULTS_v2.json').read_text());corr=json.loads((H/'source_correspondence_v3/RESULTS_v3.json').read_text())
assert (base1['passed'],base1['failed'])==(107,12) and (base2['passed'],base2['failed'])==(119,0)
assert (corr['passed'],corr['failed'])==(42,0) and corr['new_science_rerun'] is False
damage=json.loads((H/'DAMAGE_SUMMARY_v1.json').read_text());assert damage['intended_rejections']==damage['actual_damage_count']==7
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
files=[]
for p in sorted(H.rglob('*')):
 if p.is_file():
  assert not p.is_symlink()
  files.append({'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'unit':'dynamical_density_response_v1/independent_v1','sealed_utc':at,'artifact_count':len(files),'artifacts':files,'excluded_self_and_receipt':['MANIFEST_v1.json','RECEIPT_v1.json'],'source_bindings':'SOURCE_BINDINGS_FINAL_v1.json','scope':'Independent derivation, preserved failures, full synthetic profiles, actual damaged copies and final-source correspondence; no formal audit'}
dump(H/'MANIFEST_v1.json',manifest)
receipt={'unit':'dynamical_density_response_v1/independent_v1','reviewer':'/root/local_response_check','scientific_author':'/root','sealed_utc':at,'scope':'Focused blind local quadratic scalar/material response and conditional stability/Jeans check','report':{'path':'REPORT_v1.md','sha256':sha(H/'REPORT_v1.md')},'manifest':{'path':'MANIFEST_v1.json','sha256':sha(H/'MANIFEST_v1.json'),'artifact_count':len(files)},'source_bindings':{'path':'SOURCE_BINDINGS_FINAL_v1.json','sha256':sha(H/'SOURCE_BINDINGS_FINAL_v1.json'),'count':len(pairs)},'source_pairs':pairs,'science':{'original_failed_run':{'path':'BASELINE_RESULTS_v1.json','sha256':sha(H/'BASELINE_RESULTS_v1.json'),'passed':107,'failed':12,'preserved':True},'corrected_run':{'path':'BASELINE_RESULTS_v2.json','sha256':sha(H/'BASELINE_RESULTS_v2.json'),'passed':119,'failed':0},'model_cases_initial_data_acceptance_limits_unchanged':True,'repair':'SymPy generator normalization, simplify negative witness, tighten absolute ODE tolerance only; full diagnosis and code diff preserved','coupled_profiles':{'cases':6,'samples_each':137,'complete_profiles_preserved':True},'forced_fluid_IVPs':{'cases':2,'samples_each':91,'scope':'Algebraic linear Green-function checks; larger forcing amplitudes not physical perturbative claims'},'actual_damaged_copies':7,'damage_failure_counts':[20,22,19,11,1,3,2],'damage_summary':{'path':'DAMAGE_SUMMARY_v1.json','sha256':sha(H/'DAMAGE_SUMMARY_v1.json')},'producer_implementation_or_result_artifact_accessed':False,'prior_science_counts_relabelled':False,'new_empirical_inputs_or_fit':False},'original_reviewer_final_source_confirmation':{'read_complete_v2_and_v3':True,'read_and_reproduced_exact_diffs':True,'final_source_sha256':'3e6449a1f10e47105cd29aae6ef0e47a4ea337c1d65500f6f2e582af77430ff4','original_source_sha256':'c78f7be15fe2d1a422b6b555fd5f0dbf56d76bdc7f72594b3ece112c63007d35','confirmed_corrections':['stable bare i0 versus unstable growth-aware Laplace/finite-time IVP','literal p quotient requires nonzero driven beta X','strict k^2 and boundary k^4 lower modes both tend to zero','all-k continuum establishes no measured material/background window; NR corrections may shift near-neutral boundary'],'displayed_original_equations_unchanged':True,'correspondence_passed':42,'correspondence_failed':0,'new_science_execution_for_correspondence':False,'evidence':{'path':'source_correspondence_v3/RESULTS_v3.json','sha256':sha(H/'source_correspondence_v3/RESULTS_v3.json')}},'final_identity_verification':{'path':'FINAL_VERIFICATION_v1.json','sha256':sha(H/'FINAL_VERIFICATION_v1.json'),'passed':125,'failed':0},'failure_history':{'path':'FAILURES_AND_CORRECTIONS_v1.json','sha256':sha(H/'FAILURES_AND_CORRECTIONS_v1.json')},'primary_pdf':{'path':'sources/Bean_Flanagan_Trodden_0709.1128v2.pdf','sha256':sha(H/'sources/Bean_Flanagan_Trodden_0709.1128v2.pdf'),'pages_visually_read':[2,3,4,5,9,10],'warning_preserved':True,'scope':'Conventions and validity limitations only; no phenomenology imported'},'bounded_conclusion':'Final v3 is mathematically consistent within its specified quadratic and leading NR/optional Newtonian models; no physical stationary universe, calibrated validity window, or cosmological exclusion established','prior_seals_untouched':True,'formal_audit':False,'writes_stop_after_seal':True}
dump(H/'RECEIPT_v1.json',receipt)
for p in files:
 f=H/p['path'];assert sha(f)==p['sha256'] and f.stat().st_size==p['bytes']
for p in pairs:assert sha(Path(p['original_path']))==sha(H/p['snapshot_path'])==p['sha256']
assert sha(H/'MANIFEST_v1.json')==receipt['manifest']['sha256']
print(json.dumps({'sealed':True,'artifacts':len(files),'source_pairs':len(pairs),'report':str(H/'REPORT_v1.md'),'report_sha256':sha(H/'REPORT_v1.md'),'manifest_sha256':sha(H/'MANIFEST_v1.json'),'receipt_sha256':sha(H/'RECEIPT_v1.json'),'science_original':'107/12 retained','science_corrected':'119/0','correspondence':'42/0','final_metadata':'125/0'},indent=2))

