from pathlib import Path
import hashlib,json,difflib,datetime
H=Path(__file__).resolve().parent.parent
C=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.open('x').write(json.dumps(x,indent=2)+'\n')
rows=[]
def ck(name,value,**info):rows.append(dict(name=name,passed=bool(value),**info))
old=H/'sources/DERIVATION_v1.md';mid=C/'sources/DERIVATION_v2.md';new=C/'sources/DERIVATION_v3.md'
for label,p,expected in [('v1',old,'c78f7be15fe2d1a422b6b555fd5f0dbf56d76bdc7f72594b3ece112c63007d35'),('v2',mid,'8b95cd295cfc6fe6f0d643de1946d29fe1c39a487f6456029b262d52c500b51f'),('v3',new,'3e6449a1f10e47105cd29aae6ef0e47a4ea337c1d65500f6f2e582af77430ff4')]:
 ck('expected_source_hash_'+label,sha(p)==expected)
for p0,p1,v0,v1 in [(old,mid,'v1','v2'),(mid,new,'v2','v3')]:
 text0=p0.read_text();text1=p1.read_text()
 actual=''.join(difflib.unified_diff(text0.splitlines(True),text1.splitlines(True),fromfile=v0,tofile=v1))
 ck('exact_full_diff_'+v0+'_'+v1,actual==(C/'sources'/('DERIVATION_'+v0+'_'+v1+'.diff')).read_text())
 ck('displayed_equations_unchanged_'+v0+'_'+v1,[x for x in text0.splitlines() if x.startswith(' ')]==[x for x in text1.splitlines() if x.startswith(' ')])
 (C/('INDEPENDENT_'+v0+'_'+v1+'.diff')).open('x').write(actual)
j2=json.loads((C/'sources/SOURCE_CORRECTION_v2.json').read_text())
j3=json.loads((C/'sources/SOURCE_CORRECTION_v3.json').read_text())
ck('v2_correction_bindings',j2['source_v1_sha256']==sha(old) and j2['source_v2_sha256']==sha(mid) and j2['equations_unchanged'])
ck('v3_correction_bindings',j3['v2_sha256']==sha(mid) and j3['v3_sha256']==sha(new) and j3['original_equations_unchanged'])
base=json.loads((H/'BASELINE_RESULTS_v2.json').read_text())
ck('corrected_independent_119_0',base['passed']==119 and base['failed']==0)
prior=json.loads((H/'BASELINE_RESULTS_v1.json').read_text())
ck('original_failed_107_12_preserved',prior['passed']==107 and prior['failed']==12)
ck('original_v1_exit_failure_preserved',json.loads((H/'BASELINE_RUN_v1.json').read_text())['exit_code']==1)
controls={r['name']:r for r in base['checks']}
for name in ['scalar_Euler_normalization','displacement_Euler_force','fixed_particle_Hessian_mass','canonical_reciprocity','coupled_determinant','full_scalar_resolvent','bare_pole_is_not_coupled_pole','zero_coupling_literal_ratio_undefined','strict_low_wave_coefficient','critical_low_wave_coefficient','strict_long_wave_limit','critical_long_wave_limit','near_neutral_negative_witness','causal_growth_abscissa','below_growth_contour_rejected','actual_convergent_Laplace_integral','actual_below_pole_divergence_witness','forced_stable_homogeneous_IVP','forced_unstable_homogeneous_IVP']:
 ck('reuse_'+name,controls[name]['passed'],science_rerun=False)
source_pairs=json.loads((H/'SOURCE_BINDINGS_v1.json').read_text())['source_pairs']+json.loads((C/'SOURCE_BINDINGS_v3.json').read_text())['source_pairs']
for i,p in enumerate(source_pairs):
 ck('source_pair_'+str(i),sha(Path(p['original_path']))==sha(H/p['snapshot_path'])==p['sha256'] and (H/p['snapshot_path']).stat().st_size==p['bytes'])
dump(H/'SOURCE_BINDINGS_FINAL_v1.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pairs':source_pairs,'all_prior_source_versions_retained':True})
result={'scope':'Narrow original-reviewer source correspondence; independent scientific baseline reused without rerun','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows,'source_pairs':source_pairs,'reviewer':'/root/local_response_check','complete_v2_and_v3_read':True,'exact_diffs_read':True,'corrections_confirmed':['real-frequency i0 confined to stable bare acoustic resolvent; unstable causal IVP uses growth-aware Laplace contour or finite-time solution','all-k statement is ideal continuum and no measured validity window; omitted NR corrections may shift near-neutral boundary','literal p quotient requires beta X!=0; beta=0 decoupled','both low-k modes tend to zero; strict k^2 versus boundary k^4 leading coefficients'],'displayed_equations_unchanged':True,'producer_code_results_accessed':False,'new_science_rerun':False,'reused_baseline':{'path':'BASELINE_RESULTS_v2.json','sha256':sha(H/'BASELINE_RESULTS_v2.json'),'passed':119,'failed':0}}
dump(C/'RESULTS_v3.json',result)
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'source_pairs':len(source_pairs)},indent=2))
raise SystemExit(bool(result['failed']))

