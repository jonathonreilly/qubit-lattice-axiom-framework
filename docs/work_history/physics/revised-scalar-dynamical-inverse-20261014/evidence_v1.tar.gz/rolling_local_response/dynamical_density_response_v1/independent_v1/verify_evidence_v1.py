from pathlib import Path
import hashlib,json,datetime,difflib,struct,ast
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
def ck(name,test,**info):rows.append(dict(name=name,passed=bool(test),**info))
pairs=json.loads((H/'SOURCE_BINDINGS_FINAL_v1.json').read_text())['source_pairs']
ck('eleven_source_pairs',len(pairs)==11)
for i,p in enumerate(pairs):
 ck('source_'+str(i),sha(H/p['snapshot_path'])==sha(Path(p['original_path']))==p['sha256'] and (H/p['snapshot_path']).stat().st_size==p['bytes'])
hand=json.loads((H/'HAND_IMPLEMENTATION_BINDINGS_v1.json').read_text())
for p in hand['files']:
 ck('hand_original_binding_'+p['path'],sha(H/p['path'])==p['sha256'] and (H/p['path']).stat().st_size==p['bytes'])
ck('hand_protocol_before_implementation',hand['files'][0]['mtime_ns']<hand['files'][2]['mtime_ns'] and hand['files'][1]['mtime_ns']<hand['files'][2]['mtime_ns'])
bases=[]
for version,passed,failed,exitcode in [('v1',107,12,1),('v2',119,0,0)]:
 result=json.loads((H/('BASELINE_RESULTS_'+version+'.json')).read_text());run=json.loads((H/('BASELINE_RUN_'+version+'.json')).read_text());code=H/('check_dynamical_'+version+'.py');bases.append(result)
 ck('baseline_'+version+'_code',sha(code)==run['script_sha256']==result['code_sha256'])
 ck('baseline_'+version+'_stdout',sha(H/('BASELINE_RESULTS_'+version+'.json'))==run['stdout_sha256'])
 ck('baseline_'+version+'_stderr',sha(H/('BASELINE_stderr_'+version+'.txt'))==run['stderr_sha256'])
 ck('baseline_'+version+'_actual_counts',result['passed']==passed and result['failed']==failed and len(result['checks'])==119 and sum(not x['passed'] for x in result['checks'])==failed and run['exit_code']==exitcode)
 ck('baseline_'+version+'_six_full_profiles',len(result['full_profiles'])==6 and all(len(p['times'])==len(p['raw_ODE_profile'])==len(p['canonical_eigenmode_profile'])==len(p['energy_profile'])==137 for p in result['full_profiles']))
 ck('baseline_'+version+'_two_full_forced_profiles',len(result['forced_fluid_profiles'])==2 and all(len(p['times'])==len(p['ODE_delta'])==len(p['analytic_with_independent_mode'])==91 for p in result['forced_fluid_profiles']))
 ck('baseline_'+version+'_protocol_hash',result['protocol_sha256']==sha(H/('INDEPENDENT_PROTOCOL_'+version+'.json')))
ck('no_failed_control_removed',[x['name'] for x in bases[0]['checks']]==[x['name'] for x in bases[1]['checks']])
v1=(H/'check_dynamical_v1.py').read_text();v2=(H/'check_dynamical_v2.py').read_text()
expected=v1.replace("eq('first_order_characteristic',A4.charpoly(lam).as_expr()-target.subs(y,-lam**2))","cp=A4.charpoly(lam)\neq('first_order_characteristic',cp.as_expr().subs(cp.gen,lam)-target.subs(y,-lam**2))").replace("near_det.subs({z:small*m/2}).is_negative","S.simplify(near_det.subs({z:small*m/2})).is_negative").replace('INDEPENDENT_PROTOCOL_v1.json','INDEPENDENT_PROTOCOL_v2.json')
ck('only_narrow_checker_repairs',v2==expected)
ck('repair_diff_exact',''.join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile='check_dynamical_v1.py',tofile='check_dynamical_v2.py'))==(H/'CHECKER_v1_v2.diff').read_text())
p1=json.loads((H/'INDEPENDENT_PROTOCOL_v1.json').read_text());p2=json.loads((H/'INDEPENDENT_PROTOCOL_v2.json').read_text());p2check=dict(p2);p2check.pop('repair_lineage');p2check['atol']=p1['atol']
ck('only_atol_changed_in_numerical_protocol',p2check==p1 and p1['atol']==2e-14 and p2['atol']==2e-18)
diag=json.loads((H/'FIRST_RUN_DIAGNOSIS_v1.json').read_text())
ck('symbol_generator_failure_diagnosed',diag['symbols_equal'] is False and diag['explicit_generator_substitution_residual']=='0')
ck('negative_predicate_failure_diagnosed',diag['unsimplified_is_negative'] is None and diag['simplified_is_negative'] is True)
ck('all_twelve_original_failures_listed',len(diag['all_original_failures'])==12)
for profile in bases[1]['full_profiles']:
 ck('final_profile_'+profile['name'],profile['scaled_profile_error']<p2['profile_scaled_tolerance'] and profile['scaled_energy_error']<p2['energy_scaled_tolerance'] and profile['max_abs_state']<.01)
damage_protocol=json.loads((H/'DAMAGE_PROTOCOL_v1.json').read_text())
damage=json.loads((H/'DAMAGE_SUMMARY_v1.json').read_text())
ck('seven_real_damages',damage['actual_damage_count']==damage['intended_rejections']==7 and len(damage['records'])==len(damage_protocol['cases'])==7)
for case,record in zip(damage_protocol['cases'],damage['records']):
 name=case['name'];p=H/'damages'/(name+'.py');r=json.loads((H/'damages'/(name+'_results.json')).read_text());run=json.loads((H/'damages'/(name+'_run.json')).read_text())
 ck(name+'_one_edit',p.read_text()==v2.replace(case['old'],case['new']) and v2.count(case['old'])==1)
 ck(name+'_exact_diff',''.join(difflib.unified_diff(v2.splitlines(True),p.read_text().splitlines(True),fromfile='check_dynamical_v2.py',tofile=p.name))==(H/'damages'/(name+'.diff')).read_text())
 ck(name+'_code_hash',sha(p)==record['script_sha256']==r['code_sha256'])
 ck(name+'_stdout_hash',sha(H/'damages'/(name+'_results.json'))==record['stdout_sha256'])
 ck(name+'_stderr_hash',sha(H/'damages'/(name+'_stderr.txt'))==record['stderr_sha256'])
 ck(name+'_record_exact',run==record)
 fails=[x['name'] for x in r['checks'] if not x['passed']]
 ck(name+'_intended_rejection',record['exit_code']==1 and case['required_failed_control'] in fails and record['failed_controls']==fails)
 ck(name+'_all_119_controls_retained',r['passed']+r['failed']==119 and len(r['checks'])==119 and r['failed']==len(fails))
 ck(name+'_protocol_before_execution',datetime.datetime.fromisoformat(damage_protocol['created_utc'])<datetime.datetime.fromisoformat(record['started_utc']))
C=H/'source_correspondence_v3';corr=json.loads((C/'RESULTS_v3.json').read_text());run=json.loads((C/'RUN_v3.json').read_text())
ck('final_correspondence_42_0',corr['passed']==42 and corr['failed']==0 and all(r['passed'] for r in corr['checks']))
ck('same_original_reviewer_read_final',corr['reviewer']=='/root/local_response_check' and corr['complete_v2_and_v3_read'] and corr['exact_diffs_read'])
ck('correspondence_no_science_rerun',not corr['new_science_rerun'] and corr['reused_baseline']['sha256']==sha(H/'BASELINE_RESULTS_v2.json'))
ck('correspondence_script_hash',sha(C/'check_correspondence_v3.py')==run['script_sha256'])
ck('correspondence_run_output',sha(C/'stdout_v3.txt')==run['stdout_sha256'] and sha(C/'stderr_v3.txt')==run['stderr_sha256'] and run['exit_code']==0)
for page in (2,3,4,5,9,10):
 data=(H/'pdf_pages'/('Bean-'+str(page).zfill(2)+'.png')).read_bytes()
 ck('primary_page_render_'+str(page),data[:8]==b'\x89PNG\r\n\x1a\n' and min(struct.unpack('>II',data[16:24]))>700)
ck('primary_full_extraction_22_pages',len(list((H/'pdf_pages').glob('page_*.txt')))==22)
ck('primary_warning_preserved','Rotated text discovered' in (H/'PDF_RENDER_v1.json').read_text())
imports=[]
for node in ast.walk(ast.parse(v2)):
 if isinstance(node,ast.Import):imports.extend(n.name for n in node.names)
 if isinstance(node,ast.ImportFrom):imports.append(node.module)
ck('independent_import_closure',set(imports)=={'pathlib','hashlib','json','sys','sympy','numpy','mpmath','scipy.integrate'},imports=sorted(set(imports)))
commands=json.loads((H/'COMMANDS_v1.json').read_text())['commands']
ck('exact_command_ledger',len(commands)>=10 and all(x['command'] and x['cwd'] for x in commands))
for name in ['REPORT_v1.md','source_correspondence_v3/REPORT_v3.md','HAND_DERIVATION_v1.md']:
 ck('complete_report_present_'+name,(H/name).stat().st_size>1000)
result={'scope':'Final source/evidence identity verification only, no science rerun','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows}
print(json.dumps(result,indent=2))
raise SystemExit(bool(result['failed']))

