from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent
k=np.geomspace(.02,30,600);x=k*k;q=.2;c=1.;m=.05;v=.01
a=x+m
def lower(grav):
 b=v*x-grav*c
 # Stable product-over-large-root form avoids cancellation near k=0.
 yp=(a+b+np.sqrt((a-b)**2+4*c*q*x))/2
 return (a*b-c*q*x)/yp
fig,axs=plt.subplots(1,2,figsize=(10.4,4.2),layout='constrained')
colors=['#177c9c','#ba4d36']
for grav,label,col in [(0,'Frozen tensor metric',colors[0]),(1,'With local Newtonian gravity',colors[1])]:
 lo=lower(grav);axs[0].plot(k,lo,label=label,c=col,lw=2);axs[1].plot(k,np.sqrt(np.maximum(0,-lo)),label=label,c=col,lw=2)
axs[0].axhline(0,c='#555555',lw=.8);axs[0].set(xscale='log',xlabel=r'$k/\sqrt{c_R}$',ylabel=r'Lower $\omega^2/c_R$',ylim=(-1.3,2.1));axs[1].set(xscale='log',xlabel=r'$k/\sqrt{c_R}$',ylabel=r'Growth rate $\gamma/\sqrt{c_R}$',ylim=(0,1.18))
axs[1].axhline(np.sqrt(q),c=colors[0],ls='--',lw=1,label=r'Frozen ceiling $\sqrt{q}$');axs[1].axhline(np.sqrt(1+q),c=colors[1],ls='--',lw=1,label=r'Gravity ceiling $\sqrt{1+q}$')
for ax in axs:ax.grid(alpha=.18);ax.spines[['top','right']].set_visible(False)
axs[0].legend(fontsize=8,loc='upper left');axs[1].legend(fontsize=8,loc='upper right')
fig.suptitle('Moving matter adds a coupled mode; scalar mass positivity is insufficient',fontsize=12)
fig.supxlabel(r'Synthetic frozen-patch example: $q=0.2$, $v_s^2=0.01$, $M^2/c_R=0.05$. No observational fit.',fontsize=9)
fig.savefig(p/'DYNAMICAL_RESPONSE_v2.png',dpi=180);fig.savefig(p/'DYNAMICAL_RESPONSE_v2.pdf');np.savez_compressed(p/'DYNAMICAL_RESPONSE_DATA_v2.npz',k=k,frozen_lower=lower(0),gravity_lower=lower(1),q=q,cs_squared=v,mass_squared_over_cR=m)
