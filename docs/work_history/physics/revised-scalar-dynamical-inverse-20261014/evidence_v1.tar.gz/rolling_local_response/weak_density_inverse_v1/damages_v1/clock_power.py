#!/usr/local/bin/python3
"""Personal finite-history inverse. Synthetic data; fixed protocol, no fit."""
from pathlib import Path
import argparse, datetime, hashlib, json, math
import mpmath as mp
import numpy as np
import sympy as s
from scipy.special import roots_legendre

IBP_SIGN = 1
TIME_POWER = 1
GRAVITY_SIGN = 1
MASS_SHIFT = 0

def run(out):
    out.mkdir(parents=True, exist_ok=False)
    mp.mp.dps = 65
    checks = []
    def ck(name, passed, detail=None):
        checks.append(dict(name=name, passed=bool(passed), detail=detail))
    def exact(name, expr):
        z=s.simplify(expr);ck(name,z==0,str(z))
    def num(name, value, bound):
        ck(name,abs(value)<bound,dict(error=str(value),bound=str(bound)))
    x,m,c,q,v,h,z,T=s.symbols('x m c q v h z T',positive=True)
    beta=s.symbols('beta',positive=True)
    a=x+m;b=v*x-h*c
    K=s.Matrix([[a,c*beta],[x*beta,b]])
    C2=a+b;C0=a*b-c*q*x
    exact('coupled_characteristic',K.charpoly(z).as_expr().subs(K.charpoly(z).gen,z).subs(beta**2,q)-(z**2-C2*z+C0))
    for i,e in enumerate(K*K-C2*K+(a*b-c*beta**2*x)*s.eye(2)):
        exact('all_readout_eliminant_'+str(i),e)
    mm=C2-(1+v)*x+GRAVITY_SIGN*h*c+MASS_SHIFT*c*q
    qq=((x+mm)*b-C0)/(c*x)
    exact('mass_inverse',mm-m);exact('coupling_inverse',qq-q)
    u2,u0=s.symbols('u2 u0')
    exact('clock_power',T**2*C2/T**TIME_POWER-C2)
    tau=s.symbols('tau',real=True);P=tau**4*(1-tau)**4
    kernels=[];bounds=[]
    for j,w in enumerate([s.S.Zero,8*s.pi]):
        psi=P*s.cos(w*tau)
        for n in range(4):
            for end in [0,1]:exact('kernel_boundary_%s_%s_%s'%(j,n,end),s.diff(psi,tau,n).subs(tau,end))
        funcs={};nums={};kb={}
        for r in [0,2,4]:
            expr=s.diff(psi,tau,r)
            funcs[r]=s.lambdify(tau,expr,'mpmath');nums[r]=s.lambdify(tau,expr,'numpy')
            envelope=0
            for ell in range(r+1):
                poly=s.Poly(s.diff(P,tau,ell),tau)
                coeff_sum=sum(abs(coef)/s.Integer(power[0]+1) for power,coef in poly.terms())
                envelope+=s.binomial(r,ell)*abs(w)**(r-ell)*coeff_sum
            kb[r]=mp.mpf(str(s.N(envelope,70)))
            ck('positive_kernel_bound_%s_%s'%(j,r),kb[r]>0,str(envelope))
        kernels.append((funcs,nums));bounds.append(kb)
    C=mp.mpf(1);V=mp.mpf('.04');M=mp.mpf(4);Q=mp.mpf('.2');H=mp.mpf(1);duration=mp.mpf(3)
    amplitude=mp.mpf('1e-5');epsilon=mp.mpf('1e-17')
    def coeff(k,Mval=M,Qval=Q):
        xx=k*k;aa=xx+Mval;bb=V*xx-H*C
        return aa+bb,aa*bb-C*Qval*xx
    def make(k,A,B,phase,physical=False,single=False):
        xx=k*k;aa=xx+M;bb=V*xx-H*C
        disc=mp.sqrt((aa-bb)**2+4*C*Q*xx)
        ys=[(aa+bb-disc)/2,(aa+bb+disc)/2]
        ck('synthetic_stable_k_'+str(k),all(y>0 for y in ys),[str(y) for y in ys])
        omg=[mp.sqrt(y)*duration for y in ys]
        mult=[1+3*(bb-y)/xx if physical else mp.mpf(1) for y in ys]
        def f(t):return amplitude*(A*mult[0]*mp.cos(omg[0]*t+phase)+(0 if single else B*mult[1]*mp.sin(omg[1]*t+phase)))
        def fn(t,r=0):return float(amplitude)*(float(A*mult[0])*float(omg[0])**r*np.cos(float(omg[0])*t+float(phase)+r*np.pi/2)+(0 if single else float(B*mult[1])*float(omg[1])**r*np.sin(float(omg[1])*t+float(phase)+r*np.pi/2)))
        return f,fn,ys,omg
    grid=[mp.mpf(i)/8 for i in range(9)]
    gx,gw=roots_legendre(256);gx=(gx+1)/2;gw=gw/2
    def features(f,fn,label):
        result=[];double=[]
        for j,(funcs,nums) in enumerate(kernels):
            row={r:mp.quad(lambda t:f(t)*funcs[r](t),grid) for r in [0,2,4]}
            nr={r:float(np.sum(gw*fn(gx,r)*nums[0](gx))) for r in [0,2,4]}
            for r in [0,2,4]:num(label+'.gauss_%s_%s'%(j,r),mp.mpf(nr[r])-row[r],mp.mpf('3e-12')*max(mp.mpf('1e-12'),abs(row[r])))
            result.append(row);double.append(nr)
        return result,double
    def infer(rows,k):
        D=mp.matrix([[IBP_SIGN*r[2],r[0]] for r in rows]);zz=mp.matrix([-r[4] for r in rows]);u=mp.lu_solve(D,zz)
        cc2=u[0]/duration**TIME_POWER;cc0=u[1]/duration**4;xx=k*k
        mass=cc2-(1+V)*xx+GRAVITY_SIGN*H*C+MASS_SHIFT*C*Q
        coupling=((xx+mass)*(V*xx-H*C)-cc0)/(C*xx)
        return D,u,mass,coupling
    norm=lambda mat:max(sum(abs(mat[i,j]) for j in range(mat.cols)) for i in range(mat.rows))
    cases=[];inferred=[]
    choices=[('1','.7','.2'),('.3','-.5','.9'),('2','-1','-.4')]
    for case,choice in enumerate(choices):
        k=mp.mpf(8);A,B,phase=map(mp.mpf,choice);f,fn,ys,omg=make(k,A,B,phase)
        rows,dr=features(f,fn,'case'+str(case));D,u,mass,coupling=infer(rows,k)
        cc2,cc0=coeff(k)
        for j,row in enumerate(rows):num('case%s.weak_equation_%s'%(case,j),row[4]+duration**2*cc2*row[2]+duration**4*cc0*row[0],mp.mpf('1e-55'))
        num('case%s.mass'%case,mass-M,mp.mpf('1e-48'));num('case%s.q'%case,coupling-Q,mp.mpf('1e-48'))
        ck('case%s.rank'%case,abs(mp.det(D))>mp.mpf('1e-30'),str(mp.det(D)))
        fd=lambda t:f(t)+epsilon*mp.sin(13*mp.pi*t)
        fdn=lambda t,r=0:fn(t,r)+float(epsilon)*(13*np.pi)**r*np.sin(13*np.pi*t+r*np.pi/2)
        nr,ndr=features(fd,fdn,'noise'+str(case));Dh,uh,mh,qh=infer(nr,k)
        d=epsilon*max(bb[2]+bb[0] for bb in bounds);e=epsilon*max(bb[4] for bb in bounds)
        ni=norm(Dh**-1);eta=ni*d;E=ni*(e+d*norm(uh))/(1-eta)
        ck('case%s.eta'%case,eta<1,str(eta));ck('case%s.error_certificate'%case,norm(uh-u)<=E,dict(actual=str(norm(uh-u)),bound=str(E)))
        mb=E/duration**2;qb=(abs(V*k*k-H*C)/duration**2+1/duration**4)*E/(C*k*k)
        ck('case%s.mass_certificate'%case,abs(mh-M)<=mb,dict(actual=str(mh-M),bound=str(mb)))
        ck('case%s.q_certificate'%case,abs(qh-Q)<=qb,dict(actual=str(qh-Q),bound=str(qb)))
        ts=np.linspace(0,1,2049);np.savez_compressed(out/('profile_%s.npz'%case),tau=ts,readout=fn(ts),noisy=fdn(ts))
        cases.append(dict(choice=choice,frequencies=[str(y) for y in ys],features=[{str(r):str(row[r]) for r in row} for row in rows],double_features=dr,noisy_features=[{str(r):str(row[r]) for r in row} for row in nr],D=[[str(D[i,j]) for j in range(2)] for i in range(2)],u=[str(vv) for vv in u],mass=str(mass),q=str(coupling),condition_inf=str(norm(D)*norm(D**-1)),eta=str(eta),coefficient_error_bound=str(E),mass_error_bound=str(mb),q_error_bound=str(qb)))
        inferred.append((mass,coupling))
    # A genuinely different readout of the same solution; not new initial state data.
    f,fn,ys,omg=make(mp.mpf(8),mp.mpf(1),mp.mpf('.7'),mp.mpf('.2'),physical=True)
    physical,physical_double=features(f,fn,'physical_density');_,_,mphys,qphys=infer(physical,mp.mpf(8))
    num('physical_density.mass',mphys-M,mp.mpf('1e-48'));num('physical_density.q',qphys-Q,mp.mpf('1e-48'))
    # Structural single-mode failure: test the dependency, never invert it.
    f,fn,ys,omg=make(mp.mpf(8),mp.mpf(1),mp.mpf(0),mp.mpf('.2'),single=True)
    single,sd=features(f,fn,'single_mode');DS=mp.matrix([[r[2],r[0]] for r in single])
    for j,row in enumerate(single):num('single_mode.dependency_'+str(j),row[2]+omg[0]**2*row[0],mp.mpf('1e-55'))
    num('single_mode.relative_det',mp.det(DS)/(norm(DS)**2),mp.mpf('1e-50'))
    # Reserved k=11: use only parameters inferred at k=8, never solve again.
    k=mp.mpf(11);f,fn,ys,omg=make(k,mp.mpf('.6'),mp.mpf('-.8'),mp.mpf('.3'))
    validation,vd=features(f,fn,'reserved');pred2,pred0=coeff(k,*inferred[0]);truth2,truth0=coeff(k)
    num('reserved.C2',pred2-truth2,mp.mpf('1e-48'));num('reserved.C0',pred0-truth0,mp.mpf('1e-45'))
    for j,row in enumerate(validation):num('reserved.weak_residual_'+str(j),row[4]+duration**2*pred2*row[2]+duration**4*pred0*row[0],mp.mpf('1e-50'))
    ts=np.linspace(0,1,2049);np.savez_compressed(out/'reserved_profile.npz',tau=ts,readout=fn(ts))
    result=dict(passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),checks=checks,cases=cases,kernel_bounds=[{str(k):str(v) for k,v in b.items()} for b in bounds],physical_density_inverse=dict(mass=str(mphys),q=str(qphys)),single_mode_relative_det=str(mp.det(DS)/norm(DS)**2),reserved=dict(k='11',predicted_C2=str(pred2),predicted_C0=str(pred0),features=[{str(r):str(row[r]) for r in row} for row in validation]),scope='Synthetic protocol; exact calibrated constant model. Error bound does not certify floating quadrature or an experiment.',checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=result['passed'],failed=result['failed'],cases=[{k:v for k,v in row.items() if k in ['mass','q','condition_inf','eta','mass_error_bound','q_error_bound']} for row in cases]),indent=2))
    return result['failed']

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();raise SystemExit(1 if run(args.out) else 0)
