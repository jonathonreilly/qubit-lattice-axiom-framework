# Independent weak-inverse derivation before executable controls

Inputs are only the frozen weak-inverse hand source/protocol and the complete
prerequisite dynamical DERIVATION_v3. No producer implementation or result
artifact is read. /root remains scientific author.

Write z=k^2, r=cR, s=cs^2, m=M^2, q=beta^2, h=0 or 1. The raw state
w=(X,delta) satisfies wddot+P w=0 with
 P=[[a,r beta],[beta z,b]], a=z+m, b=s z-h r.
Cayley-Hamilton gives P^2-(a+b)P+(ab-r q z)I=0. Because w4=P^2 w and
w2=-P w, every constant linear readout obeys
 f4+C2 f2+C0 f=0, C2=a+b, C0=ab-r q z.
No acoustic denominator was divided out. For delta, nonzero beta z also allows
X=-(deltaddot+b delta)/(beta z), recovering the coupled system and all four
initial degrees of freedom. For a general readout the eliminant is a necessary
identity, not a guarantee that all modes are observable.

The physical rest-density contrast delta_J=delta-3beta X is a constant linear
readout only in the frozen patch. A varying gain/mixing matrix generally adds
derivative terms. For a scalar gain 1+epsilon tau, the eliminant acquires
epsilon(4 f''' + 2u2 f'), generally nonzero. Exact calibration/frame assumptions
are not removed by the weak formulation.

On tau=t/T, f4+T^2 C2 f2+T^4 C0 f=0. For sufficiently regular test functions
(e.g. C4 or W^{4,1} with the needed boundary traces) whose first four traces
psi through psi''' vanish at 0 and 1, integration by parts gives
 int f4 psi = int f psi4 and int f2 psi = int f psi2.
The boundary form is [f'''psi-f''psi'+f'psi''-fpsi'''] and
[f'psi-fpsi']; both vanish. Thus I4+u2 I2+u0 I0=0 without using observed
derivatives or measured endpoint states. The signs are both positive.

For two tests D_j=(I2_j,I0_j), z_j=-I4_j. If D is invertible, the pair
(u2,u0) is unique. The formulas m=u2/T^2-(1+s)z+h r and
q=[(z+m)(s z-h r)-u0/T^4]/(r z) then follow with exact nonzero r z.
A constant nonzero overall gain cancels in the exact inverse, but changes
conditioning relative to an absolute noise floor. beta's sign remains a scalar
orientation convention.

If f''=-Omega^2 f, I2=-Omega^2 I0 for every admissible kernel, even with both
sin/cos phases within that one frequency. The matrix therefore has rank at most
one. A constant instrument readout can annihilate one eigenvector even if both
state modes are excited. Test functions can also lose rank: take
psi1=P=tau^4(1-tau)^4, psi2=(2tau-1)P. A two-mode history even about tau=1/2
makes the second row zero by parity. This explicitly prevents interpreting
two-mode excitation alone as a rank guarantee. Additional kernels do not cure
an intrinsically single-mode readout, though they may cure a poor kernel pair.

Let DeltaD=Dhat-D and Deltaz=zhat-z. Uniform readout error epsilon gives
||DeltaD||inf <= epsilon max_j(K2_j+K0_j)=d,
||Deltaz||inf <= epsilon max_j K4_j=e.
Factor D=Dhat(I-Dhat^{-1}DeltaD). If eta=||Dhat^{-1}||inf d<1,
D is invertible and ||D^{-1}||inf<=||Dhat^{-1}||inf/(1-eta).
Since D(u-uhat)=(z-zhat)+(Dhat-D)uhat,
||u-uhat||inf<=||Dhat^{-1}||inf(e+d||uhat||inf)/(1-eta).
The sign of the perturbation terms is harmless after the norm, but the minus
sign in 1-eta is essential. eta<1 is sufficient, not necessary. At eta=1
an actually singular D can be consistent with an invertible Dhat and the stated
matrix error bound; therefore replacing the strict condition by <=1 is invalid.

This proof assumes exact integrals/linear solve or separately controlled
quadrature and arithmetic residuals. For an approximate solve with residual
rsolve=zhat-Dhat utilde, an additional ||rsolve|| term belongs in the numerator.
No such residual may be silently treated as observed readout error. The source
states the ideal exact inverse and calls for separate computational bounds.

With exact r,z,s,h,T, Delta m=Delta u2/T^2 and
Delta q=[b Delta u2/T^2-Delta u0/T^4]/(r z). The advertised component bounds
follow by a box triangle inequality. They ignore correlation conservatively.
Uncertain calibrations, a rolling frame, or an instrument model require their
own propagation. Under a constant physical frame scale A,
zJ=zE/A^2, rJ=rE/A^2, mJ=mE/A^2, TJ=A TE. Then u2,u0 and q are invariant
and mJ=mE/A^2, so all calibrations must refer to one consistent frame.

For psi=P cos(w tau), Leibniz gives a sum of P^(l) times a bounded sine/cosine
and w^(r-l). Expanding P^(l) in powers of tau and integrating the absolute
coefficient envelope proves the source Kr bound. It is conservative, including
at w=0 where only l=r survives (with the zero-power convention). Floating
evaluations of transcendental norms are not outward interval certificates.

## Prospective distinct controls

Use polynomial kernels P and (2tau-1)P, rather than the author's oscillatory
pair. Compute moments by a closed recurrence for integrals of tau^n exp(lambda
tau), not the producer quadrature. Independently compare with composite Simpson
quadrature on uniform saved profiles. Generate number-density, physical-density,
and another constant mixed readout from full coupled mode histories, including
an unstable mode. Reserve k=7/2 with new amplitudes for one synthetic coefficient
prediction after inference; do not fit to it.

Check explicit single-mode rank failure and a two-mode parity/kernel failure.
Construct an exact constant readout that annihilates one state eigenvector.
Use actual bounded smooth additive readout noise, exact rational matrix-corner
controls for the Neumann bound, a sharp diagonal witness, and an eta=1 singular
counterexample. Check exact parameter-error propagation for either sign of b
and for T above and below 1. Numerical feature/certificate displays remain
illustrations rather than outward certified experimental bounds.

Actually execute damaged copies that reverse the weak second-derivative sign,
alter each time scaling, reverse gravity reconstruction, substitute the wrong
source-controlled mass, use kernels with insufficient endpoint zeros, and
replace 1-eta by 1+eta. Preserve every original failure and output.

