from pathlib import Path
import json,hashlib,itertools
import sympy as S
import numpy as np
import mpmath as mp
mp.mp.dps=100

WEAK_SECOND_SIGN=1
TIME_SECOND_POWER=2
TIME_FOURTH_POWER=4
GRAVITY_SIGN=1
MASS_RESPONSE_SHIFT=3
BOUNDARY_ORDER=4
ERROR_DENOM_SIGN=-1

H=Path.cwd();protocol=json.loads((H/'INDEPENDENT_PROTOCOL_v1.json').read_text())
rows=[]
def ck(name,value,**data):rows.append(dict(name=name,passed=bool(value),**data))
def eq(name,value):
 vv=S.simplify(value);ck(name,vv==0,residual=str(vv))
tau=S.symbols('tau',real=True)
z,r,m,s,T=S.symbols('z r m s T',positive=True)
beta=S.symbols('beta',real=True,nonzero=True);h=S.symbols('h',real=True)
a=z+m;b=s*z-h*r;g=r*beta**2
P=S.Matrix([[a,r*beta],[beta*z,b]]);C2=S.trace(P);C0=P.det()
CH=P*P-C2*P+C0*S.eye(2)
for i in range(2):
 for j in range(2):eq(f'Cayley_Hamilton_{i}{j}',CH[i,j])
l1,l2=S.symbols('l1 l2',real=True)
for i in range(2):eq('general_readout_eliminant_'+str(i),(S.Matrix([[l1,l2]])*CH)[i])
eq('undivided_eliminant_coefficients',C0-((z+m)*(s*z-h*r)-r*beta**2*z))
Pwin=tau**BOUNDARY_ORDER*(1-tau)**BOUNDARY_ORDER
kernels=[S.expand(Pwin),S.expand((2*tau-1)*Pwin)]
for j,psi in enumerate(kernels):
 for order in range(4):
  for endpoint in (0,1):eq(f'boundary_j{j}_r{order}_e{endpoint}',S.diff(psi,tau,order).subs(tau,endpoint))
 ftest=tau**7+2*tau**3-tau
 eq('weak_second_IBP_'+str(j),S.integrate(S.diff(ftest,tau,2)*psi,(tau,0,1))-WEAK_SECOND_SIGN*S.integrate(ftest*S.diff(psi,tau,2),(tau,0,1)))
 eq('weak_fourth_IBP_'+str(j),S.integrate(S.diff(ftest,tau,4)*psi,(tau,0,1))-S.integrate(ftest*S.diff(psi,tau,4),(tau,0,1)))
 eq('fourth_boundary_form_'+str(j),(S.diff(ftest,tau,3)*psi-S.diff(ftest,tau,2)*S.diff(psi,tau)+S.diff(ftest,tau)*S.diff(psi,tau,2)-ftest*S.diff(psi,tau,3)).subs(tau,1)-(S.diff(ftest,tau,3)*psi-S.diff(ftest,tau,2)*S.diff(psi,tau)+S.diff(ftest,tau)*S.diff(psi,tau,2)-ftest*S.diff(psi,tau,3)).subs(tau,0))
u2=T**2*C2;u0=T**4*C0
mraw=u2/T**TIME_SECOND_POWER-(1+s)*z+GRAVITY_SIGN*h*r
qrec=((z+mraw)*b-u0/T**TIME_FOURTH_POWER)/(r*z)
mrec=mraw+MASS_RESPONSE_SHIFT*r*qrec
eq('mass_reconstruction',mrec-m);eq('coupling_reconstruction',qrec-beta**2)
eq('time_second_conversion',T**TIME_SECOND_POWER-T**2)
eq('time_fourth_conversion',T**TIME_FOURTH_POWER-T**4)
gain=S.symbols('gain',nonzero=True);d11,d12,d21,d22,v1,v2=S.symbols('d11 d12 d21 d22 v1 v2')
DD=S.Matrix([[d11,d12],[d21,d22]]);vv=S.Matrix([v1,v2])
for i in range(2):eq('constant_gain_cancels_'+str(i),((gain*DD).inv()*(gain*vv)-DD.inv()*vv)[i])
AA=S.symbols('AA',positive=True)
eq('consistent_frame_u2',(AA*T)**2*C2/AA**2-u2)
eq('consistent_frame_u0',(AA*T)**4*C0/AA**4-u0)
eq('consistent_frame_q',(((z+m)/AA**2)*(b/AA**2)-C0/AA**4)/((r/AA**2)*(z/AA**2))-beta**2)

# A time-varying readout multiplier generally changes the differential operator.
f=S.Function('f')(tau);eps=S.symbols('eps',real=True)
L=lambda expr:S.diff(expr,tau,4)+u2*S.diff(expr,tau,2)+u0*expr
eq('varying_gain_extra_terms',L((1+eps*tau)*f)-(1+eps*tau)*L(f)-eps*(4*S.diff(f,tau,3)+2*u2*S.diff(f,tau)))
ck('varying_gain_not_generic_solution',S.simplify((4*S.diff(S.cos(tau),tau,3)+2*5*S.diff(S.cos(tau),tau)).subs(tau,S.pi/2))!=0)

# Exact kernel-envelope formula, independent of numerical inverse features.
PS=tau**4*(1-tau)**4
def poly_envelope(expr):
 return sum(abs(c)/S.Rational(n[0]+1) for n,c in S.Poly(S.expand(expr),tau).terms())
kernel_controls=[]
for w in [S.Integer(0),-S.Rational(7,3),S.Rational(5,2)]:
 for order in (0,2,4):
  direct=S.diff(PS*S.cos(w*tau),tau,order)
  leibniz=sum(S.binomial(order,l)*S.diff(PS,tau,l)*S.diff(S.cos(w*tau),tau,order-l) for l in range(order+1))
  eq(f'kernel_Leibniz_w{w}_r{order}',direct-leibniz)
  K=sum(S.binomial(order,l)*abs(w)**(order-l)*poly_envelope(S.diff(PS,tau,l)) for l in range(order+1))
  ck(f'kernel_envelope_positive_w{w}_r{order}',K>0)
  if w==0:eq('zero_frequency_only_last_term_r'+str(order),K-poly_envelope(S.diff(PS,tau,order)))
  kernel_controls.append({'w':str(w),'r':order,'exact_bound':str(K)})
eq('kernel_P_integral',S.integrate(PS,(tau,0,1))-S.Rational(1,630))
ck('kernel_K0_conservative',poly_envelope(PS)>S.Rational(1,630))

# Exact infinity-norm perturbation bound, including a sharp witness.
def snorm(A):return max(sum(abs(A[i,j]) for j in range(A.cols)) for i in range(A.rows))
Dhat=S.Matrix([[S.Rational(3,2),-S.Rational(1,3)],[S.Rational(2,5),S.Rational(7,6)]])
uhat=S.Matrix([S.Rational(11,5),-S.Rational(4,7)]);zhat=Dhat*uhat;d=S.Rational(1,80);e=S.Rational(3,100)
invnorm=snorm(Dhat.inv());eta=invnorm*d
E=invnorm*(e+d*snorm(uhat))/(1+ERROR_DENOM_SIGN*eta)
ck('matrix_eta_strictly_below_one',0<eta<1)
corners=[]
for ii,signs in enumerate(itertools.product((-1,1),repeat=6)):
 DeltaD=S.Matrix(2,2,[sg*d/2 for sg in signs[:4]]);Deltaz=S.Matrix([signs[4]*e,signs[5]*e])
 trueD=Dhat-DeltaD;truez=zhat-Deltaz;trueu=trueD.inv()*truez;err=snorm(trueu-uhat)
 ck('rational_error_corner_'+str(ii),err<=E)
 corners.append({'signs':list(signs),'error':str(err),'bound':str(E)})
sd=S.Rational(2,5);se=S.Rational(1,7);suh=S.Matrix([S.Rational(3,2),-S.Rational(1,2)])
sDt=S.diag(1-sd,1);szt=suh+S.Matrix([se,0]);serr=snorm(sDt.inv()*szt-suh)
sbound=(se+sd*snorm(suh))/(1+ERROR_DENOM_SIGN*sd)
ck('sharp_Neumann_bound',serr<=sbound,error=str(serr),bound=str(sbound))
eq('sharp_correct_bound_value',serr-S.Rational(26,21))
ck('eta_equal_one_can_be_singular',(S.eye(2)-S.diag(1,0)).det()==0)
utilde=uhat+S.Matrix([S.Rational(1,1000),0]);residual=zhat-Dhat*utilde
ck('approximate_solve_needs_residual_budget',snorm(utilde-uhat)>0 and snorm(residual)>0 and snorm(utilde-uhat)<=invnorm*snorm(residual))
du2,du0,EE=S.symbols('du2 du0 EE',real=True)
eq('parameter_mass_error',du2/T**TIME_SECOND_POWER-du2/T**2)
eq('parameter_q_error',(b*du2/T**TIME_SECOND_POWER-du0/T**TIME_FOURTH_POWER)/(r*z)-(b*du2/T**2-du0/T**4)/(r*z))
propagation=[]
for tv,bv in [(S.Rational(7,4),S.Rational(1,5)),(S.Rational(2,3),-S.Rational(3,7)),(S.Rational(5,6),S.Integer(0))]:
 ev=S.Rational(1,17);rv=S.Rational(2,3);zv=S.Integer(4)
 dq=(bv*(-ev if bv<0 else ev)/tv**2+ev/tv**4)/(rv*zv)
 bound=(abs(bv)/tv**TIME_SECOND_POWER+1/tv**TIME_FOURTH_POWER)*ev/(rv*zv)
 ck('parameter_box_saturation_'+str(tv),dq<=bound)
 propagation.append({'T':str(tv),'b':str(bv),'actual_q_error':str(dq),'reported_bound':str(bound)})

# Polynomial-exponential moments, calculated by recurrence rather than quadrature.
def mm(v):return mp.mpf(str(S.N(S.Rational(v),110))) if isinstance(v,str) else mp.mpf(v)
poly=[]
for psi in kernels:
 poly.append({order:{int(n[0]):mm(str(c)) for n,c in S.Poly(S.diff(psi,tau,order),tau).terms()} for order in (0,2,4)})
Kbounds=[[mm(str(poly_envelope(S.diff(psi,tau,order)))) for order in (0,2,4)] for psi in kernels]
def exp_moments(ll,nmax):
 if abs(ll)==0:return [mp.mpf(1)/(n+1) for n in range(nmax+1)]
 expo=mp.exp(ll);vals=[mp.expm1(ll)/ll]
 for n in range(1,nmax+1):vals.append(expo/ll-n*vals[-1]/ll)
 return vals
def feature(modes,coeffs):
 degree=max(coeffs);total=mp.mpc(0)
 for cc,ll in modes:
  vv=exp_moments(ll,degree)
  total+=cc*sum(coef*vv[n] for n,coef in coeffs.items())
 return mp.re(total)
def features(modes):
 return [[feature(modes,poly[j][order]) for order in (0,2,4)] for j in range(2)]
def matrix_from(I):
 return mp.matrix([[WEAK_SECOND_SIGN*I[j][1],I[j][0]] for j in range(2)]),mp.matrix([-I[j][2] for j in range(2)])
def norminf(A):return max(sum(abs(A[i,j]) for j in range(A.cols)) for i in range(A.rows))
def evaluate(modes,grid):
 return np.real(sum(complex(cc)*np.exp(complex(ll)*grid) for cc,ll in modes))
def build(item):
 p={key:mm(item[key]) for key in ['k','T','r','cs2','M2','beta']};p['h']=int(item['gravity']);p['x']=p['k']**2;p['q']=p['beta']**2
 p['a']=p['x']+p['M2'];p['b']=p['cs2']*p['x']-p['h']*p['r'];p['g']=p['r']*p['q']
 root=mp.sqrt((p['a']-p['b'])**2+4*p['g']*p['x'])
 p['ys']=[(p['a']+p['b']-root)/2,(p['a']+p['b']+root)/2]
 co=[mm(v) for v in item['mode_coefficients']];amp=mm(protocol['readout_amplitude'])
 number=[];scalar=[]
 for i,yv in enumerate(p['ys']):
  aa,bb=co[2*i:2*i+2]
  if yv>0:
   ll=mp.j*p['T']*mp.sqrt(yv);cp=(aa-mp.j*bb)/2;cm=(aa+mp.j*bb)/2
  else:
   ll=p['T']*mp.sqrt(-yv);cp=(aa+bb)/2;cm=(aa-bb)/2
  for cc,exponent in [(amp*cp,ll),(amp*cm,-ll)]:
   number.append((cc,exponent));scalar.append((-(exponent**2/p['T']**2+p['b'])*cc/(p['beta']*p['x']),exponent))
 readout=item['readout'];lx,ld=(-3*p['beta'],mp.mpf(1)) if readout=='physical' else [mm(x) for x in readout]
 observed=[(lx*xc+ld*dc,ll) for (dc,ll),(xc,_) in zip(number,scalar)]
 return p,number,scalar,observed
def reconstruct(u,p):
 C2h=u[0]/p['T']**TIME_SECOND_POWER;C0h=u[1]/p['T']**TIME_FOURTH_POWER
 mh=C2h-(1+p['cs2'])*p['x']+GRAVITY_SIGN*p['h']*p['r']
 qh=((p['x']+mh)*p['b']-C0h)/(p['r']*p['x'])
 return mh+MASS_RESPONSE_SHIFT*p['r']*qh,qh,C2h,C0h
def serial(value):
 if isinstance(value,mp.matrix):return [[mp.nstr(value[i,j],60) for j in range(value.cols)] for i in range(value.rows)]
 if isinstance(value,(mp.mpf,mp.mpc)):return mp.nstr(value,60)
 return value
def simpson_moments(fvals,grid):
 N=len(grid)-1;weights=np.ones(N+1);weights[1:N:2]=4;weights[2:N:2]=2
 return [[float(np.dot(weights,fvals*np.polynomial.polynomial.polyval(grid,[float(poly[j][order].get(n,0)) for n in range(max(poly[j][order])+1)]))/(3*N)) for order in (0,2,4)] for j in range(2)]
profiles=[];first_state=None
noise_eps=mm(protocol['noise_amplitude'])
noise=[(noise_eps*mp.exp(mp.j/3)/2,mp.j*7),(noise_eps*mp.exp(-mp.j/3)/2,-mp.j*7)]
for item in protocol['cases']:
 name=item['name'];p,number,scalar,observed=build(item);I=features(observed);D,zz=matrix_from(I)
 trueu=mp.matrix([p['T']**2*(p['a']+p['b']),p['T']**4*(p['a']*p['b']-p['g']*p['x'])])
 residual=D*trueu-zz;scale=max(norminf(zz),mp.mpf('1e-50'))
 ck(name+'_weak_identity',norminf(residual)/scale<mp.mpf('1e-70'),scaled_residual=str(norminf(residual)/scale))
 normdet=abs(mp.det(D))/max(norminf(D)**2,mp.mpf('1e-90'))
 ck(name+'_actual_rank',normdet>mp.mpf('1e-60'),normalized_determinant=str(normdet))
 u=mp.lu_solve(D,zz);mh,qh,C2h,C0h=reconstruct(u,p)
 ck(name+'_analytic_coefficients',norminf(u-trueu)/max(1,norminf(trueu))<mp.mpf('1e-70'))
 ck(name+'_parameter_reconstruction',max(abs(mh-p['M2']),abs(qh-p['q']))<mp.mpf('1e-70'))
 for j,((dc,ll),(xc,_)) in enumerate(zip(number,scalar)):
  ck(name+'_full_state_scalar_'+str(j),abs((ll**2/p['T']**2+p['a'])*xc+p['r']*p['beta']*dc)<mp.mpf('1e-70'))
  ck(name+'_full_state_density_'+str(j),abs((ll**2/p['T']**2+p['b'])*dc+p['beta']*p['x']*xc)<mp.mpf('1e-70'))
 Igain=features([(-mp.mpf(7)*cc/3,ll) for cc,ll in observed]);Dg,zg=matrix_from(Igain)
 ck(name+'_constant_gain_inverse',norminf(mp.lu_solve(Dg,zg)-u)<mp.mpf('1e-70'))
 noisy=observed+noise;Ih=features(noisy);Dh,zh=matrix_from(Ih);uh=mp.lu_solve(Dh,zh);mhn,qhn,_,_=reconstruct(uh,p)
 dd=noise_eps*max(K[1]+K[0] for K in Kbounds);ee=noise_eps*max(K[2] for K in Kbounds)
 invh=norminf(Dh**-1);etah=invh*dd
 ck(name+'_feature_error_bounds',all(abs(Ih[j][ii]-I[j][ii])<=noise_eps*Kbounds[j][ii] for j in range(2) for ii in range(3)))
 if etah<1:
  bound=invh*(ee+dd*norminf(uh))/(1+ERROR_DENOM_SIGN*etah)
  ck(name+'_coefficient_error_certificate',norminf(uh-trueu)<=bound)
  mbound=bound/p['T']**TIME_SECOND_POWER
  qbound=(abs(p['b'])/p['T']**TIME_SECOND_POWER+1/p['T']**TIME_FOURTH_POWER)*bound/(p['r']*p['x'])
  ck(name+'_parameter_error_certificate',abs(mhn-p['M2'])<=mbound and abs(qhn-p['q'])<=qbound)
  certificate={'available':True,'eta':str(etah),'E':str(bound),'actual_u_error':str(norminf(uh-trueu)),'mass_bound':str(mbound),'coupling_bound':str(qbound),'actual_mass_error':str(abs(mhn-p['M2'])),'actual_coupling_error':str(abs(qhn-p['q']))}
 else:
  certificate={'available':False,'eta':str(etah),'reason':'sufficient eta<1 test not met; no bound asserted'}
  ck(name+'_certificate_correctly_withheld',etah>=1)
 simpson=[]
 for N in (512,1024):
  grid=np.linspace(0,1,N+1);fvals=evaluate(observed,grid);Is=simpson_moments(fvals,grid)
  Ds=np.array([[WEAK_SECOND_SIGN*rr[1],rr[0]] for rr in Is]);zs=-np.array([rr[2] for rr in Is]);us=np.linalg.solve(Ds,zs)
  error=max(abs(mp.mpf(float(us[i]))-trueu[i]) for i in range(2))/max(1,norminf(trueu))
  mup=mp.matrix([mp.mpf(float(v)) for v in us]);ms,qs,_,_=reconstruct(mup,p);perr=max(abs(ms-p['M2']),abs(qs-p['q']))
  simpson.append({'panels':N,'u':us.tolist(),'scaled_u_error':str(error),'parameter_error':str(perr)})
  if N==1024:
   ck(name+'_Simpson_coefficients',error<mm(protocol['simpson_scaled_coefficient_tolerance']))
   ck(name+'_Simpson_parameters',perr<mm(protocol['simpson_parameter_tolerance']))
 records={'name':name,'parameters':{k:serial(v) for k,v in p.items() if k!='ys'},'squared_frequencies':[str(v) for v in p['ys']],'features':[[str(v) for v in row] for row in I],'D':serial(D),'z_vector':serial(zz),'determinant':str(mp.det(D)),'infinity_condition':str(norminf(D)*norminf(D**-1)),'u_true':serial(trueu),'u_reconstructed':serial(u),'M2_reconstructed':str(mh),'q_reconstructed':str(qh),'noisy_features':[[str(v) for v in row] for row in Ih],'certificate':certificate,'simpson':simpson,'tau':grid.tolist(),'number_profile':evaluate(number,grid).tolist(),'scalar_profile':evaluate(scalar,grid).tolist(),'readout_profile':fvals.tolist(),'noisy_readout_profile':evaluate(noisy,grid).tolist()}
 profiles.append(records)
 if first_state is None:first_state=(item,p,number,scalar,observed,u)

# Explicit rank obstructions: one mode, an annihilating readout, and an even two-mode history.
item,p,number,scalar,observed,u=first_state
single=observed[:2];Is=features(single);Ds,zs=matrix_from(Is);om2=p['T']**2*p['ys'][0]
for j in range(2):ck('single_mode_row_dependence_'+str(j),abs(Is[j][1]+om2*Is[j][0])<mp.mpf('1e-70'))
ck('single_mode_rank_failure',abs(mp.det(Ds))/max(norminf(Ds)**2,mp.mpf('1e-90'))<mp.mpf('1e-70'))
highX=(p['ys'][1]-p['b'])/(p['beta']*p['x'])
annihilated=[(xc-highX*dc,ll) for (dc,ll),(xc,_) in zip(number,scalar)]
ck('both_state_modes_excited',all(abs(c)>0 for c,ll in number))
ck('constant_readout_hides_high_mode',max(abs(cc) for cc,ll in annihilated[2:])<mp.mpf('1e-70'))
Ia=features(annihilated);Da,za=matrix_from(Ia)
ck('annihilated_readout_rank_failure',abs(mp.det(Da))/max(norminf(Da)**2,mp.mpf('1e-90'))<mp.mpf('1e-70'))
even=[]
for idx,yv in enumerate(p['ys']):
 ll=mp.j*p['T']*mp.sqrt(yv);amp=mm(protocol['readout_amplitude'])*(1 if idx==0 else mp.mpf(7)/10)
 even.extend([(amp*mp.exp(-ll/2)/2,ll),(amp*mp.exp(ll/2)/2,-ll)])
Ie=features(even);De,ze=matrix_from(Ie)
ck('two_mode_even_kernel_row_zero',max(abs(v) for v in Ie[1])<mp.mpf('1e-70'))
ck('two_mode_kernel_rank_failure',abs(mp.det(De))/max(norminf(De)**2,mp.mpf('1e-90'))<mp.mpf('1e-70'))
rankprofiles=[];grid=np.linspace(0,1,1025)
for label,modes,mat in [('single_mode',single,Ds),('annihilating_readout',annihilated,Da),('even_two_mode',even,De)]:
 rankprofiles.append({'name':label,'tau':grid.tolist(),'readout':evaluate(modes,grid).tolist(),'D':serial(mat),'normalized_determinant':str(abs(mp.det(mat))/max(norminf(mat)**2,mp.mpf('1e-90')))})

# Reserved synthetic coefficient prediction; no fit to reserved history.
reserved=dict(item);plan=protocol['reserved_prediction']
for key in ['k','T','mode_coefficients','readout']:reserved[key]=plan[key]
rp,rn,rs,rf=build(reserved);RI=features(rf);RD,Rz=matrix_from(RI)
inferred_m,inferred_q,_,_=reconstruct(u,p)
predC2=(1+rp['cs2'])*rp['x']+inferred_m-rp['h']*rp['r']
predC0=(rp['x']+inferred_m)*rp['b']-rp['r']*inferred_q*rp['x']
predU=mp.matrix([rp['T']**2*predC2,rp['T']**4*predC0])
prediction_error=norminf(RD*predU-Rz)/max(norminf(Rz),mp.mpf('1e-50'))
ck('reserved_synthetic_weak_prediction',prediction_error<mp.mpf('1e-70'),scaled_residual=str(prediction_error))
reserve={'calibration':plan,'inferred_from':item['name'],'scaled_prediction_residual':str(prediction_error),'predicted_C2':str(predC2),'predicted_C0':str(predC0),'features':[[str(v) for v in row] for row in RI],'tau':grid.tolist(),'number_profile':evaluate(rn,grid).tolist(),'scalar_profile':evaluate(rs,grid).tolist(),'readout_profile':evaluate(rf,grid).tolist()}
out={'scope':'Blind finite-window weak inverse inside declared frozen NR model; no producer implementation/results or empirical data','passed':sum(v['passed'] for v in rows),'failed':sum(not v['passed'] for v in rows),'checks':rows,'kernel_bounds':kernel_controls,'actual_polynomial_kernel_bounds':[[str(v) for v in row] for row in Kbounds],'rational_perturbation_corners':corners,'sharp_error_witness':{'error':str(serr),'bound':str(sbound)},'parameter_error_controls':propagation,'full_profiles':profiles,'rank_failure_profiles':rankprofiles,'reserved_prediction':reserve,'precision_digits':mp.mp.dps,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((H/'INDEPENDENT_PROTOCOL_v1.json').read_bytes()).hexdigest()}
print(json.dumps(out,indent=2));raise SystemExit(bool(out['failed']))

