from pathlib import Path
import hashlib,json,datetime,sys
H=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((H/name).read_text())
assert not (H/'MANIFEST_v1.json').exists()
assert not (H/'RECEIPT_v1.json').exists()
bindings=read('SOURCE_BINDINGS_v1.json')
for row in bindings['source_pairs']:
 assert sha(Path(row['original_path']))==sha(H/row['snapshot_path'])==row['sha256']
base=read('BASELINE_RESULTS_v1.json');metadata=read('METADATA_VERIFICATION_v1.json');damage=read('damages_v1/DAMAGE_RECEIPT_v1.json')
assert base['passed']==200 and base['failed']==0
assert metadata['passed']==121 and metadata['failed']==0
assert damage['actual_executions']==7 and damage['all_intended_rejections']
artifacts=[]
for p in sorted(H.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file():
  rel=str(p.relative_to(H))
  assert rel not in ['MANIFEST_v1.json','RECEIPT_v1.json']
  artifacts.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest={'schema':'focused-independent-artifact-manifest-v1','created_utc':now,'root':str(H),'immutable_after_seal':True,'scope':'finite-window weak-density inverse; blind independent unit; no formal audit','artifact_count':len(artifacts),'artifacts':artifacts}
mp=H/'MANIFEST_v1.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'schema':'focused-independent-source-bound-receipt-v1','created_utc':now,'reviewer':'/root/local_response_check','scientific_author':'/root','unit_root':str(H),'report_path':'REPORT_v1.md','report_sha256':sha(H/'REPORT_v1.md'),'manifest_path':'MANIFEST_v1.json','manifest_sha256':sha(mp),'artifact_count':len(artifacts),'source_pairs':bindings['source_pairs'],'source_confirmation_path':'FINAL_SOURCE_CONFIRMATION_v1.json','source_confirmation_sha256':sha(H/'FINAL_SOURCE_CONFIRMATION_v1.json'),'source_dispositions':[{'original_path':r['original_path'],'original_sha256':r['sha256'],'snapshot_path':r['snapshot_path'],'disposition':'unchanged; checked or explicitly reused as hand-model premise within report scope'} for r in bindings['source_pairs']],'independent_science':{'passed':200,'failed':0,'code_path':'check_weak_inverse_v1.py','code_sha256':sha(H/'check_weak_inverse_v1.py'),'output_path':'BASELINE_RESULTS_v1.json','output_sha256':sha(H/'BASELINE_RESULTS_v1.json'),'run_path':'BASELINE_RUN_v1.json','run_sha256':sha(H/'BASELINE_RUN_v1.json'),'full_profiles':7,'samples_per_profile':1025},'actual_damaged_copies':{'count':7,'all_intended_rejections':True,'receipt_path':'damages_v1/DAMAGE_RECEIPT_v1.json','receipt_sha256':sha(H/'damages_v1/DAMAGE_RECEIPT_v1.json'),'failed_assertion_counts':[r['failed'] for r in damage['runs']]},'metadata_only_verification':{'passed':121,'failed':0,'path':'METADATA_VERIFICATION_v1.json','sha256':sha(H/'METADATA_VERIFICATION_v1.json')},'failure_history':{'unexpected_baseline_failures':0,'intentional_damaged_failures_preserved':True,'coarse_quadrature_diagnostic_preserved':True,'path':'FAILURE_AND_LIMITS_v1.json','sha256':sha(H/'FAILURE_AND_LIMITS_v1.json')},'producer_code_or_results_accessed':False,'empirical_data_used':False,'source_correction_required':False,'earlier_seals_modified':False,'formal_audit':False,'conclusion':'Conditional algebra, weak-form inverse, rank obstruction and deterministic error bounds hold within the supplied frozen NR model. No empirical calibration or validity window is established.','seal_execution':{'argv':sys.argv,'cwd':str(H),'script_sha256':sha(Path(__file__))},'stop_writes_after_this_seal':True}
rp=H/'RECEIPT_v1.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
for row in artifacts:
 assert sha(H/row['path'])==row['sha256'] and (H/row['path']).stat().st_size==row['bytes']
print(json.dumps({'artifact_count':len(artifacts),'source_pairs':len(bindings['source_pairs']),'report_sha256':receipt['report_sha256'],'manifest_sha256':receipt['manifest_sha256'],'receipt_sha256':sha(rp),'report_path':str(H/'REPORT_v1.md'),'manifest_path':str(mp),'receipt_path':str(rp),'science':[200,0],'metadata':[121,0],'damages':7},indent=2))

