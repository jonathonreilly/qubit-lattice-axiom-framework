from pathlib import Path
import json,hashlib,math,ast,datetime,sys
H=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
def ck(name,truth,**detail):
 rows.append(dict(name=name,passed=bool(truth),**detail))
def load(name):return json.loads((H/name).read_text())
bindings=load('SOURCE_BINDINGS_v1.json')
confirmation=load('FINAL_SOURCE_CONFIRMATION_v1.json')
ck('exactly_three_allowed_source_pairs',len(bindings['source_pairs'])==3)
ck('same_final_pair_paths',[x['original_path'] for x in bindings['source_pairs']]==[x['original_path'] for x in confirmation['source_pairs']])
for i,row in enumerate(bindings['source_pairs']):
 live=Path(row['original_path']);snap=H/row['snapshot_path']
 ck(f'live_source_hash_{i}',sha(live)==row['sha256'])
 ck(f'snapshot_hash_{i}',sha(snap)==row['sha256'])
 ck(f'source_lengths_{i}',live.stat().st_size==snap.stat().st_size==row['bytes'])
 ck(f'final_confirmation_hashes_{i}',confirmation['source_pairs'][i]['unchanged'] and confirmation['source_pairs'][i]['live_sha256']==confirmation['source_pairs'][i]['snapshot_sha256']==row['sha256'])
protocol=load('INDEPENDENT_PROTOCOL_v1.json')
base=load('BASELINE_RESULTS_v1.json');run=load('BASELINE_RUN_v1.json')
ck('baseline_exact_counts',base['passed']==200 and base['failed']==0 and len(base['checks'])==200)
ck('baseline_count_consistency',sum(x['passed'] for x in base['checks'])==base['passed'] and all(x['passed'] for x in base['checks']))
ck('baseline_unique_check_names',len(set(x['name'] for x in base['checks']))==200)
ck('baseline_exit_zero',run['returncode']==0)
ck('baseline_stdout_hash',sha(H/run['stdout_path'])==run['stdout_sha256'])
ck('baseline_stderr_hash',sha(H/run['stderr_path'])==run['stderr_sha256'] and (H/run['stderr_path']).stat().st_size==0)
ck('baseline_code_hash',sha(H/'check_weak_inverse_v1.py')==base['code_sha256']==run['code_sha256'])
ck('baseline_protocol_hash',sha(H/'INDEPENDENT_PROTOCOL_v1.json')==base['protocol_sha256'])
ck('baseline_pre_run_binding_hash',sha(H/'PRE_RUN_BINDINGS_v1.json')==run['pre_run_bindings_sha256'])
for i,row in enumerate(load('PRE_RUN_BINDINGS_v1.json')['files']):
 ck(f'pre_run_file_hash_{i}',sha(H/row['path'])==row['sha256'] and (H/row['path']).stat().st_size==row['bytes'])
tree=ast.parse((H/'check_weak_inverse_v1.py').read_text())
imports=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
 elif isinstance(node,ast.ImportFrom):imports.append(node.module)
ck('independent_code_import_closure',set(imports)=={'pathlib','json','hashlib','itertools','sympy','numpy','mpmath'},imports=imports)
ck('exact_corner_count',len(base['rational_perturbation_corners'])==64)
ck('main_profile_count',len(base['full_profiles'])==3)
ck('rank_profile_count',len(base['rank_failure_profiles'])==3)
ck('cases_match_frozen_protocol',[x['name'] for x in base['full_profiles']]==[x['name'] for x in protocol['cases']])
profiles=[]
for p in base['full_profiles']:profiles.append((p['name'],p,['number_profile','scalar_profile','readout_profile','noisy_readout_profile']))
for p in base['rank_failure_profiles']:profiles.append((p['name'],p,['readout']))
profiles.append(('reserved_prediction',base['reserved_prediction'],['number_profile','scalar_profile','readout_profile']))
for label,p,names in profiles:
 grid=p['tau'];ck(label+'_grid',len(grid)==1025 and grid[0]==0 and grid[-1]==1 and all(grid[i]<grid[i+1] for i in range(1024)))
 ck(label+'_complete_finite_profiles',all(len(p[n])==1025 and all(math.isfinite(y) for y in p[n]) for n in names))
for p in base['full_profiles']:
 ck(p['name']+'_two_grid_diagnostics',[r['panels'] for r in p['simpson']]==[512,1024])
 ck(p['name']+'_stored_certification_caveat',p['certificate']['available'] and float(p['certificate']['eta'])<1 and float(p['certificate']['actual_u_error'])<=float(p['certificate']['E']))
ck('reserved_not_refit',base['reserved_prediction']['inferred_from']==protocol['reserved_prediction']['base_case'] and base['reserved_prediction']['calibration']==protocol['reserved_prediction'])
damage_plan=load('damages_v1/PRE_RUN_DAMAGE_PLAN_v1.json');damage=load('damages_v1/DAMAGE_RECEIPT_v1.json')
ck('damage_plan_binding',sha(H/'damages_v1/PRE_RUN_DAMAGE_PLAN_v1.json')==damage['plan_sha256'])
ck('damage_count_and_rejections',damage['actual_executions']==7 and len(damage['runs'])==7 and damage['all_intended_rejections'])
ck('damage_baseline_binding',damage_plan['baseline_source_sha256']==base['code_sha256'] and damage_plan['baseline_result_sha256']==run['stdout_sha256'])
source=(H/'check_weak_inverse_v1.py').read_text()
for p,r in zip(damage_plan['mutations'],damage['runs']):
 name=p['name'];out=load(r['stdout_path']);failures=[x['name'] for x in out['checks'] if not x['passed']]
 ck(name+'_actual_single_replacement',source.count(p['old'])==1 and (H/p['path']).read_text()==source.replace(p['old'],p['new']))
 ck(name+'_source_binding',sha(H/p['path'])==p['sha256']==r['source_sha256']==out['code_sha256'])
 ck(name+'_diff_binding',sha(H/p['diff_path'])==p['diff_sha256'])
 ck(name+'_run_binding',sha(H/r['run_path'])==r['run_sha256'])
 ck(name+'_stdout_binding',sha(H/r['stdout_path'])==r['stdout_sha256'])
 ck(name+'_stderr_binding',sha(H/r['stderr_path'])==r['stderr_sha256'] and (H/r['stderr_path']).stat().st_size==0)
 ck(name+'_actual_failure',r['returncode']==1 and out['failed']>0 and len(failures)==out['failed'] and r['failed_checks']==failures and r['required_checks_present'] and r['intended_rejection'])
 ck(name+'_required_failure_identity',all(x in failures for x in p['required_failed_checks']))
 ck(name+'_retained_complete_output',len(out['checks'])==200 and len(out['full_profiles'])==3 and len(out['rank_failure_profiles'])==3 and len(out['reserved_prediction']['tau'])==1025)
ck('report_present_and_source_bound',all(x['sha256'] in (H/'REPORT_v1.md').read_text() for x in bindings['source_pairs']))
ck('final_scope_flags',confirmation['producer_code_or_results_read'] is False and confirmation['source_correction_required'] is False)
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Provenance/profile metadata verification only; no science rerun','passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'argv':sys.argv,'code_sha256':sha(Path(__file__))}
print(json.dumps(out,indent=2))
raise SystemExit(bool(out['failed']))

