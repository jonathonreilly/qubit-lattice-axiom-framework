# Staged correspondence protocol

This unit checks packaging, not a new scientific derivation or an audit. The
root agent remains scientific author. The already sealed finite-body result is
reused with all artifact/source hashes checked. Density science remains pending
until its independent final report and seal arrive and are verified.

Frozen before executable correspondence controls:

1. Compare each complete canonical proof body with its frozen source. Only the
   removed top title, nested headings and the separately preserved Part III
   reference repair are allowed.
2. Compare every scientific AST statement and returned scientific expression.
   Allow only local-function packaging, removal of standalone output/file-read
   wrappers, explicit fresh prior argument, and stderr progress routing.
3. Compare every original successful check row and every substantive output
   recursively against the fresh staged output. Keep original failed attempts
   distinct from corrected results. Counts are metadata, not new mathematics.
4. Execute only the unchanged canonical wrapper with replaced sentinel science
   functions. Test fresh root object identity/order, complete result preservation,
   aggregation and exit behavior. Test the extracted progress helper separately.
   These probes do not rerun the 340 science controls.
5. Execute altered copies: stale root input, row truncation, stdout progress and
   a changed scientific coefficient. Require designated correspondence guards
   to fail; retain all changed code, diffs, outputs and exits.
6. Confirm the Einstein proper-volume definition, fixed-metric variation and
   limited stationary/body/thermal scope. Bind the final reference repair in a
   separate version without replacing earlier note snapshots.

One metadata-read failure has already occurred: the inspection command looked
for a row key `ok`, while the producer schema uses `passed`. It occurred after
all 40 second-batch source copies and their binding file were written. The
source freeze succeeded. No source or scientific result changed. The failed
command and KeyError are retained separately; the corrected read only inspected
the schema and existing results.

This unit cannot establish a live canonical cache, delivery archive, commit or
integrated result. Those remain separate later operations.
