# Staged environment-bridge canonical correspondence

The final staged note and runner faithfully retain the finite-body, stationary-density and susceptibility results within their original conditional scope. The density independent seal is now complete and verified. This is **staged-source readiness only**. No live canonical cache, archive, commit, delivery map, integrated result or audit status is certified here. Scientific authorship remains with `/root`.

## Final sources and corrections

| Frozen input | SHA-256 |
| --- | --- |
| Final staged note | 3648502a7d8b9f966d134d97300c53ff2d7eaab5ddb0dc5d8bf7589b2ae3a4a2 |
| Staged runner | cfff062268624def956d92e737349524153932cbc33195e6f415f8719aa5305d |
| Final lineage v3 | 0c757b94b80769c98391e30b8cc250f2d357605cdaab8123ad27222b9e518298 |
| Fresh staged result JSON | d8cb2b2f3dc44808620c4d955c7e9fd7d979e95cd15bc0b364b542c9c8c39731 |
| Reused finite-body receipt | ccec5fd4648165ecfd31042b9c90a5843d5ba8268692df42d2d26f8d989fee88 |
| Reused density receipt | e82004e2c5f13849b603a79cf677e63acca3c403a1e2639fb7b0eac72429ec86 |

The complete staged note, runner, three producer sources, final density proof/addendum and both independent reports were read. The first staged note read is retained separately. This reviewer found one standalone-reference defect: Part III referred to historical DERIVATION_v2.md although Part II ports corrected density v3. The author preserved that note and changed only the reference to “section II of this note.” Exact comparison confirms this single substitution; equations and runner are unchanged. The same reviewer confirms the final correction.

The earlier density-definition finding is retained in source history and the density review: rho_* uses particle number per local **Einstein proper three-volume**, while the Einstein metric is fixed during scalar variation. Literal coordinate number density must be divided by the spatial volume factor. The original density reviewer confirms v3 with a non-unit-volume exact witness. This unit reuses that confirmation and does not repeat its mathematics.

## Proof and implementation correspondence

All three entire proof bodies are text-identical to their frozen source after removing their top titles and nesting headings, with the sole explicit reference substitution above. The final source preserves fixed physical-density uniqueness versus fixed-particle multiple minima, the middle extremum's full-field saddle qualification, local scalar mass normalization and the stationary rather than dynamical meaning of susceptibility.

The canonical scientific statement sequences match the original AST exactly: 54 finite-body statements, 70 density statements and 42 susceptibility statements. Allowed changes are only local function packaging, standalone input/output wrapper removal, a fresh prior argument, and routing the progress print to stderr. Returned scientific expressions also match. No file read/write, source import or global-variable declaration occurs inside these three science functions. Both relevant functions retain the original explicit 80-digit mpmath setting; shared numerical-library state is not being called pure functional isolation.

Every one of the **340 original successful rows** is retained with its unit-name prefix and unchanged pass state, residual and detail. Deep comparisons cover every substantive value, including 160 sphere rows, five volume comparisons, signed geometry and thermal threshold, 54 density samples, all three root records, three susceptibility root diagnostics, four small-A rows and three near-vacuum rows. The original self/prior hashes and scope strings remain in preserved standalone outputs and lineage; the canonical wrapper replaces these metadata fields with canonical scope, unit/aggregate counts and its own source hash. No scientific table is discarded.

Susceptibility receives the exact density result object from the same invocation after the checks list is removed. It does not load RESULTS_v1.json or solve replacement roots. Wrapper-only sentinel execution verifies object identity, root identity, call order, complete nested outputs, seven distinct synthetic rows, prefixed names, counts, file/stdout equality and exit behavior. A separate sentinel failed row verifies that the unchanged wrapper returns exit 1. The progress helper, extracted alone, prints exclusively to stderr while retaining its result row. No full scientific function was executed in these probes.

## Evidence and actual executions

| Work in this unit | Result |
| --- | --- |
| Text, AST, every saved row/table and staged metadata correspondence | 616/0 |
| Wrapper-only success case | 15/0 |
| Wrapper-only seeded failed-row behavior | 15/0 |
| Frozen source and finite-body seal metadata | 272/0 |
| Density seal and access chronology metadata | 180/0 |

These counts are packaging/metadata controls, **not new independent science**. The author’s recorded staged execution ran from 2026-10-14T13:08:05.447789Z to 13:08:06.345905Z, exit 0, with unchanged runner hash and 208+96+36=340 passed controls. Its stdout is byte-identical to its JSON result; eight progress lines are on stderr. The final reference-only note revision was later. This staged run is not a live cache with a complete canonical input fingerprint. The four declared AUDIT_INPUT_PATHS include the eventual live note and three frozen canonical premise notes; live placement and cache binding remain later work.

Four actual altered runner copies were executed against the correspondence/probe harnesses:

| Alteration | Pass/fail | Designated rejection |
| --- | --- | --- |
| Supply stale roots | 3/3 | Fresh density object assertion, absent complete JSON and wrong exit |
| Truncate combined rows | 12/3 | Missing rows, names and aggregate count |
| Return progress to stdout | 14/1 | stderr-only helper guard |
| Replace mass threshold 3 by 2 | 615/1 | Exact scientific AST mismatch |

Each child exited 1. Changed files, exact diffs, commands, timestamps, source/output hashes and complete streams remain. The coefficient mutation was rejected structurally; it was not a new mathematical execution. The actual success and seeded-failure wrappers replace science functions with declared sentinel stubs, so their 15/0 results cannot be represented as repeated 340/0 science.

The reused finite-body unit's **88 artifacts and eight source pairs** were hash/byte verified, including its report and receipt. Its 76/0 independent mathematics and six actual damage results retain their original identities. The newly final density unit's **126 artifacts and 12 source pairs** were verified, along with its 146/0 main, 49/0 susceptibility and 23/0 convention/correspondence result bindings. Those runs and its eight damages were not repeated. Its disclosure remains explicit: after all independent scientific runs, one producer checker diff was accidentally copied and hashed as uninterpreted bytes. It was not displayed, used, imported or executed in that science. The preserved incident's completion timestamps precede the copy; this unit does not claim zero producer-byte access for that later packaging phase.

## Preserved failures and limits

The first source-history metadata read failed with KeyError `ok` because producer rows use `passed`; all 40 preceding source snapshots had already been written. Its exact command and error are retained. The first correspondence run completed 614/2: one wording guard expected a contiguous phrase not used in the note, and one allowed stderr transformation appended the `file` keyword after `flush` while the canonical order is reversed. The corrected guard uses the actual proper-volume wording and the exact canonical keyword order. Original code, failed results and repair diff remain; no source or scientific tolerance was changed. One long diagnostic display was truncated after the complete finite-body report; full frozen files remain and the necessary wrapper boundaries were read separately.

Original producer history is preserved: finite-body 202/3 failures, corrected 205/0 and the later 208/0 with three explicitly added implementation controls; susceptibility v1 was terminated during symbolic normalization without a result count, v2 was 34/1 from an unjustified fixed finite-asymptotic tolerance, and v3 used the exact parameter-dependent remainder at 36/0. These counts are never added together. Earlier author damage summaries remain contextual producer evidence, separate from this unit's actual wrapper damages and the reused independent checks.

Finite-body conclusions require the stated weak frozen response, physical masses/radii, finite profiles and fixed readout; homogeneous-sphere formulas require exterior nonoverlap. Signed geometry does not inherit the positive-geometry ceiling, and positive calibrated gravity remains a premise. The density map does not select a finite pressure-supported body, a global minimum, stable matter/gravity state or observed branch. Susceptibility is an algebraic-family derivative, with fixed-nu endpoint limits, not adiabatic tracking. The supplied action/scales, actual environmental matching, error hierarchy, thermal bath/entropy premises and measured calibration remain conditional. No additional empirical inference is made.

CLAIM_SOURCE_DISPOSITIONS_v1.json records the full source/claim map. SOURCE_BINDINGS_v1 through v5 retain 84 source pairs; the originally read staged note is explicitly superseded and recovered by its preserved version. All other pairs are current at final confirmation. Final validation, manifest and receipt bind these files and the exact commands. Writes are confined to this new correspondence unit; previous seals, author sources, Git, runtime, locks, PRs, audit and authority state are unchanged.
