from pathlib import Path
import ast, copy, hashlib, json, sys

HERE=Path(__file__).resolve().parent
SOURCES=HERE/'sources'
rows=[]
def ck(name,ok,**data): rows.append(dict(name=name,passed=bool(ok),**data))
def read(name): return (SOURCES/name).read_text()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(x): return ast.dump(x,include_attributes=False)
def module(body): return ast.Module(body=body,type_ignores=[])

note=read('final_EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md')
headers=['## I. Finite-body force and readout geometry','## II. Matter-density stationary relation and its ambiguity','## III. Stationary density susceptibility and scalar mass','## Computational scope and preservation']
proofs=['proof_1_DERIVATION_v2.md','proof_3_DERIVATION_v3.md','proof_2_SUSCEPTIBILITY_ADDENDUM_v1.md']
for i,source in enumerate(proofs):
    body='\n'.join(('###'+line[2:] if line.startswith('## ') else line) for line in read(source).splitlines()[1:]).strip()
    if i==2: body=body.replace('distinctions of DERIVATION_v2.md.','distinctions of section II of this note.')
    actual=note.split(headers[i]+'\n',1)[1].split('\n'+headers[i+1],1)[0].strip()
    ck('proof_body_exact_'+str(i+1),actual==body,source=source)
old=read('staged_note_v2.md')
ck('only_narrow_reference_correction',old.replace('distinctions of DERIVATION_v2.md.','distinctions of section II of this note.')==note)
ck('previous_note_preserved',read('history_NOTE_v2.md')==old)
ck('proper_volume_definition_retained','Einstein proper three-volume' in note and 'Einstein metric' in note and 'fixed' in note)

target=Path(sys.argv[1]) if len(sys.argv)>1 else SOURCES/'staged_runner.py'
tree=ast.parse(target.read_text())
funcs={x.name:x for x in tree.body if isinstance(x,ast.FunctionDef)}
source_names=['producer_1_check_finite_body_v3.py','producer_2_check_density_environment_v1.py','producer_3_check_susceptibility_v3.py']
fn_names=['check_finite_body','check_density_environment','check_susceptibility']
source_bodies=[]
expected_outputs=[]
for i,(src,fn_name) in enumerate(zip(source_names,fn_names)):
    body=ast.parse(read(src)).body
    starts=[8,5,4]; ends=[62,75,48]
    scientific=copy.deepcopy(body[starts[i]:ends[i]])
    if i==2:
        scientific=[x for x in scientific if not (isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id in ['p','prior'])]
        eq=next(x for x in scientific if isinstance(x,ast.FunctionDef) and x.name=='eq')
        printed=next(x.value for x in eq.body if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='print')
        printed.keywords.insert(0,ast.keyword(arg='file',value=ast.Attribute(value=ast.Name(id='sys',ctx=ast.Load()),attr='stderr',ctx=ast.Load())))
    fn=funcs[fn_name]
    ck('exact_scientific_AST_'+fn_name,dump(module(scientific))==dump(module(fn.body[:-1])),statements=len(scientific))
    output=body[ends[i]].value
    expected={x.arg:dump(x.value) for x in output.keywords if x.arg not in ['passed','failed','code_sha256','source_sha256','prior_results_sha256','scope']}
    ret=fn.body[-1].value
    actual={k.value:dump(v) for k,v in zip(ret.keys,ret.values)}
    ck('scientific_return_expressions_'+fn_name,actual==expected,keys=list(expected))
    io=[]
    for node in ast.walk(fn):
        if isinstance(node,(ast.Global,ast.Nonlocal,ast.Import,ast.ImportFrom)):io.append(type(node).__name__)
        if isinstance(node,ast.Call):
            name=ast.unparse(node.func)
            if name in ['open','Path','json.loads','json.load'] or name.endswith(('.read_text','.read_bytes','.write_text','.write_bytes')):io.append(name)
    ck('scientific_function_no_file_IO_'+fn_name,not io,violations=io)

staged=json.loads(read('STAGED_RESULTS_v1.json'))
originals=[json.loads(read(x)) for x in ['finite_RESULTS_v3.json','density_RESULTS_v1.json','density_SUSCEPTIBILITY_RESULTS_v3.json']]
units=['finite_body','density_environment','susceptibility']
pos=0
for unit,original in zip(units,originals):
    got=staged['checks'][pos:pos+len(original['checks'])];pos+=len(original['checks'])
    ck('row_count_'+unit,len(got)==len(original['checks']))
    for i,(left,right) in enumerate(zip(original['checks'],got)):
        expected={**left,'name':unit+'::'+left['name']}
        ck('row_exact_'+unit+'_'+str(i),expected==right)
    substantive={k:v for k,v in original.items() if k not in ['passed','failed','checks','code_sha256','source_sha256','prior_results_sha256','scope']}
    ck('all_substantive_values_'+unit,substantive==staged['substantive_outputs'][unit],keys=list(substantive))
    for k,value in substantive.items():
        if isinstance(value,list):
            for i,item in enumerate(value):ck('table_row_exact_'+unit+'_'+k+'_'+str(i),item==staged['substantive_outputs'][unit][k][i])
    ck('unit_count_'+unit,staged['units'][unit]=={k:original[k] for k in ['passed','failed']})
ck('total_rows',pos==len(staged['checks'])==340)
ck('count_all_340',staged['passed']==340 and staged['failed']==0 and all(r['passed'] for r in staged['checks']))
ck('stdout_json_byte_identity',(SOURCES/'STAGED_RESULTS_v1.json').read_bytes()==(SOURCES/'STAGED_stdout_v1.txt').read_bytes())
ck('staged_checker_hash',staged['checker_sha256']==sha(SOURCES/'staged_runner.py'))
ck('finite_source_result_hash',originals[0]['code_sha256']==sha(SOURCES/source_names[0]))
ck('density_source_result_hash',originals[1]['source_sha256']==sha(SOURCES/source_names[1]))
ck('susceptibility_source_result_hash',originals[2]['code_sha256']==sha(SOURCES/source_names[2]))
ck('historical_susceptibility_prior_hash',originals[2]['prior_results_sha256']==sha(SOURCES/'density_RESULTS_v1.json'))
lineage=json.loads(read('CANONICAL_LINEAGE_v3.json'))
ck('final_lineage_note',lineage['staged_note_sha256']==sha(SOURCES/'final_EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'))
ck('final_lineage_runner',lineage['staged_runner_sha256']==sha(SOURCES/'staged_runner.py'))
execution=json.loads(read('STAGED_EXECUTION_v1.json'))
ck('fresh_staged_exit',execution['exit_code']==0)
ck('fresh_staged_execution_hash',execution['source_sha256']==sha(SOURCES/'staged_runner.py'))
ck('failure_finite_v1',[(json.loads(read('finite_RESULTS_v1.json'))[k]) for k in ['passed','failed']]==[202,3])
ck('failure_susceptibility_v2',[(json.loads(read('density_SUSCEPTIBILITY_RESULTS_v2.json'))[k]) for k in ['passed','failed']]==[34,1])
ck('interrupted_v1_no_claimed_count',json.loads(read('density_SUSCEPTIBILITY_INTERRUPTION_v1.json'))['completed_scientific_count'] is None and json.loads(read('density_SUSCEPTIBILITY_EXECUTION_v1.json'))['exit_code']==-15)
expected_progress=['mass_slope_identity','density_slope_definition','stationary_log_susceptibility','weighted_density_decomposition','weighted_density_strict_derivative','slope_above_two_identity','near_vacuum_density_derivative','small_A_density_leading_decomposition']
ck('eight_stderr_progress_lines',read('STAGED_stderr_v1.txt').splitlines()==['CHECK '+n for n in expected_progress])
inp=next(x.value for x in tree.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='AUDIT_INPUT_PATHS')
paths=ast.literal_eval(inp)
ck('declared_four_canonical_inputs',len(paths)==4 and len(set(paths))==4 and all(p.startswith('docs/') for p in paths))
for p in paths[1:]:ck('premise_snapshot_'+p,(SOURCES/Path(p).name).is_file())
res=dict(scope='Staged correspondence only; no new scientific run; density independent dependency awaits separate seal',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,target=str(target),target_sha256=sha(target))
print(json.dumps(res,indent=2))
raise SystemExit(bool(res['failed']))
