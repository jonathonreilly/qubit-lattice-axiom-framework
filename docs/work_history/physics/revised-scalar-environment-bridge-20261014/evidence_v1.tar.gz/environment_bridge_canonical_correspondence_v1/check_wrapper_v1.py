from pathlib import Path
import ast, contextlib, copy, hashlib, io, json, sys, traceback
import sympy as S

source=Path(sys.argv[1]).resolve()
output=Path(sys.argv[2]).resolve()
inject_failure=len(sys.argv)>3 and sys.argv[3]=='inject_failure'
original=ast.parse(source.read_text())
tree=copy.deepcopy(original)
stub_source='''
_probe_trace=[]
_probe_roots=[{'z':'sentinel-0.117','mass':'sentinel-minus'}, {'z':'sentinel-0.713','mass':'sentinel-plus'}]
_probe_density=None
def check_finite_body():
    _probe_trace.append('finite_body')
    return {'checks':[{'name':'f0','passed':not _inject_failure,'detail':'f0-value'}, {'name':'f1','passed':True,'detail':'f1-value'}], 'sphere_grid':[[1,2],[3,4]], 'unusual_payload':{'keep':True}}
def check_density_environment():
    global _probe_density
    _probe_trace.append('density_environment')
    _probe_density={'checks':[{'name':'d'+str(i),'passed':True,'detail':{'i':i}} for i in range(3)],'roots':_probe_roots,'grid':[7,11,19]}
    return _probe_density
def check_susceptibility(prior):
    _probe_trace.append('susceptibility')
    assert prior is _probe_density, 'fresh_density_object_identity'
    assert prior['roots'] is _probe_roots, 'fresh_roots_object_identity'
    assert 'checks' not in prior, 'wrapper_pop_before_susceptibility'
    return {'checks':[{'name':'s0','passed':True},{'name':'s1','passed':True}],'root_diagnostics':prior['roots'],'extra':[{'preserved':23}]}
'''
stubs=ast.parse(stub_source).body
stub_defs={x.name:x for x in stubs if isinstance(x,ast.FunctionDef)}
setup=[x for x in stubs if not isinstance(x,ast.FunctionDef)]
tree.body=[stub_defs.get(x.name,x) if isinstance(x,ast.FunctionDef) else x for x in tree.body]
index=next(i for i,x in enumerate(tree.body) if isinstance(x,ast.FunctionDef))
tree.body[index:index]=setup
ast.fix_missing_locations(tree)
stdout,stderr=io.StringIO(),io.StringIO()
env={'__name__':'__main__','__file__':str(source),'_inject_failure':inject_failure}
saved=sys.argv;sys.argv=[str(source),'--output',str(output)]
exit_code=None;error=None
try:
    with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
        try: exec(compile(tree,str(source),'exec'),env)
        except SystemExit as ex: exit_code=int(ex.code or 0)
        except Exception as ex: error=type(ex).__name__+': '+str(ex)
finally: sys.argv=saved
checks=[]
def ck(name,ok,**detail): checks.append(dict(name=name,passed=bool(ok),**detail))
ck('wrapper_no_exception',error is None,error=error)
ck('wrapper_call_order',env['_probe_trace']==['finite_body','density_environment','susceptibility'])
ck('wrapper_expected_exit',exit_code==int(inject_failure),actual=exit_code)
try: result=json.loads(stdout.getvalue())
except Exception: result=None
ck('wrapper_single_clean_json',result is not None and not stderr.getvalue())
if result is not None:
    ck('wrapper_all_seven_rows',len(result['checks'])==7)
    ck('wrapper_counts',result['passed']==7-int(inject_failure) and result['failed']==int(inject_failure))
    ck('wrapper_all_names',[x['name'] for x in result['checks']]==['finite_body::f0','finite_body::f1','density_environment::d0','density_environment::d1','density_environment::d2','susceptibility::s0','susceptibility::s1'])
    ck('wrapper_all_units',result['units']=={'finite_body':{'passed':2-int(inject_failure),'failed':int(inject_failure)},'density_environment':{'passed':3,'failed':0},'susceptibility':{'passed':2,'failed':0}})
    ck('wrapper_finite_nested_output',result['substantive_outputs']['finite_body']=={'sphere_grid':[[1,2],[3,4]],'unusual_payload':{'keep':True}})
    ck('wrapper_density_nested_output',result['substantive_outputs']['density_environment']=={'roots':env['_probe_roots'],'grid':[7,11,19]})
    ck('wrapper_susceptibility_nested_output',result['substantive_outputs']['susceptibility']=={'root_diagnostics':env['_probe_roots'],'extra':[{'preserved':23}]})
    ck('wrapper_file_matches_stdout',output.read_text()==stdout.getvalue())
    ck('wrapper_own_source_fingerprint',result['checker_sha256']==hashlib.sha256(source.read_bytes()).hexdigest())

# Extract only the original local progress helper. No scientific function runs.
fn=next(x for x in original.body if isinstance(x,ast.FunctionDef) and x.name=='check_susceptibility')
eq=next(x for x in fn.body if isinstance(x,ast.FunctionDef) and x.name=='eq')
helper=ast.Module(body=[copy.deepcopy(eq)],type_ignores=[]);ast.fix_missing_locations(helper)
record=[];out,err=io.StringIO(),io.StringIO();ns={'sys':sys,'S':S,'ck':lambda *x:record.append(x)}
exec(compile(helper,str(source),'exec'),ns)
with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):ns['eq']('sentinel_progress',S.Integer(0))
ck('helper_progress_stderr_only',out.getvalue()=='' and err.getvalue()=='CHECK sentinel_progress\n',stdout=out.getvalue(),stderr=err.getvalue())
ck('helper_result_unchanged',record==[('sentinel_progress',True,'0')])
report={'scope':'Wrapper-only sentinel execution plus extracted progress helper; no producer scientific functions executed','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'inject_failure':inject_failure,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'captured_wrapper_stdout':stdout.getvalue(),'captured_wrapper_stderr':stderr.getvalue(),'wrapper_exception':error}
print(json.dumps(report,indent=2));raise SystemExit(bool(report['failed']))
