from pathlib import Path
import datetime,difflib,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def run(tag,argv,expected):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=HERE,capture_output=True)
    finish=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for suffix,b in [('stdout.json',p.stdout),('stderr.txt',p.stderr)]:
        f=HERE/(tag+'_'+suffix);assert not f.exists();f.write_bytes(b)
    d=json.loads(p.stdout)
    rec={'argv':argv,'cwd':str(HERE),'started_utc':start,'completed_utc':finish,'exit_code':p.returncode,'expected_exit':expected,'script_sha256':sha((HERE/argv[2]).read_bytes()),'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'passed':d['passed'],'failed':d['failed'],'failed_controls':[r['name'] for r in d['checks'] if not r['passed']]}
    f=HERE/(tag+'_RUN.json');assert not f.exists();f.write_text(json.dumps(rec,indent=2)+'\n')
    assert p.returncode==expected,(tag,rec)
    return rec
base=(HERE/'sources/staged_runner.py').read_text()
(HERE/'damages').mkdir(exist_ok=False)
mutations=[
 ('stale_roots',"check_susceptibility(outputs['density_environment'])","check_susceptibility({'roots':[]})",'wrapper_no_exception'),
 ('truncated_rows',"for row in rows])","for row in rows[:1]])",'wrapper_all_seven_rows'),
 ('stdout_progress',"print('CHECK',n,file=sys.stderr,flush=True)","print('CHECK',n,flush=True)",'helper_progress_stderr_only'),
 ('changed_science',"stable_threshold=3","stable_threshold=2",'exact_scientific_AST_check_susceptibility'),
]
records=[]
records.append(run('CORRESPONDENCE_v2',['/usr/local/bin/python3','-B','check_correspondence_v2.py'],0))
records.append(run('WRAPPER_BASELINE_v1',['/usr/local/bin/python3','-B','check_wrapper_v1.py','sources/staged_runner.py','WRAPPER_BASELINE_written.json'],0))
records.append(run('WRAPPER_FAILED_ROW_v1',['/usr/local/bin/python3','-B','check_wrapper_v1.py','sources/staged_runner.py','WRAPPER_FAILED_ROW_written.json','inject_failure'],0))
for name,old,new,required in mutations:
    assert base.count(old)==1,(name,base.count(old))
    damaged=base.replace(old,new)
    path=HERE/'damages'/(name+'.py');path.write_text(damaged)
    (HERE/'damages'/(name+'.diff')).write_text(''.join(difflib.unified_diff(base.splitlines(True),damaged.splitlines(True),fromfile='staged_runner.py',tofile=name+'.py')))
    if name=='changed_science':argv=['/usr/local/bin/python3','-B','check_correspondence_v2.py',str(path)]
    else:argv=['/usr/local/bin/python3','-B','check_wrapper_v1.py',str(path),name+'_written.json']
    rec=run('DAMAGE_'+name,argv,1);assert required in rec['failed_controls'];rec['required_failure']=required;rec['damaged_source_sha256']=sha(path.read_bytes());records.append(rec)
(HERE/'CONTROL_RUN_SUMMARY_v1.json').write_text(json.dumps({'records':records,'no_scientific_rerun':True},indent=2)+'\n')
print(json.dumps([{'argv':r['argv'][2:],'exit':r['exit_code'],'passed':r['passed'],'failed':r['failed'],'failed_controls':r['failed_controls']} for r in records],indent=2))
