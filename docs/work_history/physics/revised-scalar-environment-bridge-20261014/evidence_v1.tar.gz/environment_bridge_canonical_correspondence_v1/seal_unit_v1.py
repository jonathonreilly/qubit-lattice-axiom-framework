from pathlib import Path
import datetime,hashlib,json
H=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':digest(p)}
def write(name,obj):
    p=H/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n')
assert not (H/'MANIFEST_v1.json').exists() and not (H/'RECEIPT_v1.json').exists()
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
pairs=[];checks=[]
def ck(name,v):checks.append({'name':name,'passed':bool(v)})
finalnote=H/'sources/final_EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
for n in range(1,6):
    for row in json.loads((H/f'SOURCE_BINDINGS_v{n}.json').read_text())['source_pairs']:
        snap=H/row['snapshot_path'];live=Path(row['original_path']);r=dict(row)
        ck('snapshot:'+row['snapshot_path'],digest(snap)==row['sha256'] and snap.stat().st_size==row['bytes'])
        if row['snapshot_path']=='sources/staged_note_v2.md':
            r.update(disposition='superseded; original retained by exact preserved staged v2',recovery='sources/history_NOTE_v2.md',current_sha256=digest(live))
            ck('superseded_recovery',digest(H/r['recovery'])==r['sha256'] and digest(live)==digest(finalnote))
        else:
            r.update(disposition='current live/source byte match')
            ck('live:'+row['snapshot_path'],digest(live)==row['sha256'] and live.stat().st_size==row['bytes'])
        pairs.append(r)
ck('84_source_pairs',len(pairs)==84)
ck('final_note_expected',digest(finalnote)=='3648502a7d8b9f966d134d97300c53ff2d7eaab5ddb0dc5d8bf7589b2ae3a4a2')
ck('runner_expected',digest(H/'sources/staged_runner.py')=='cfff062268624def956d92e737349524153932cbc33195e6f415f8719aa5305d')
for name,expected in [('CORRESPONDENCE_v2_stdout.json',(616,0)),('WRAPPER_BASELINE_v1_stdout.json',(15,0)),('WRAPPER_FAILED_ROW_v1_stdout.json',(15,0)),('EVIDENCE_RESULTS_v1.json',(272,0)),('DENSITY_SEAL_RESULTS_v1.json',(180,0)),('CORRESPONDENCE_RESULTS_v1.json',(614,2))]:
    r=json.loads((H/name).read_text());ck('result_counts:'+name,(r['passed'],r['failed'])==expected)
ck('reference_correction_explicit',json.loads((H/'CLAIM_SOURCE_DISPOSITIONS_v1.json').read_text())['canonical_correction']['same_reviewer_confirmed'] is True)
write('FINAL_SOURCE_CONFIRMATION_v1.json',{'at':at,'scope':'Final source and evidence identity; no repeated science','passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'source_pairs':pairs,'original_reviewer':'/root/local_response_check','reference_correction':'confirmed; same source reviewer, one textual alias, unchanged equations/runner','density_convention':'original density reviewer final seal verified; final source v3 corresponds exactly'})
assert all(x['passed'] for x in checks),[x for x in checks if not x['passed']]
artifacts=[]
for p in sorted(H.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();rel=p.relative_to(H);assert '..' not in rel.parts
        if p.name not in ['MANIFEST_v1.json','RECEIPT_v1.json']:artifacts.append(info(p))
manifest={'created_utc':at,'unit':str(H),'artifact_count':len(artifacts),'artifacts':artifacts,'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'immutable_after_seal':True}
write('MANIFEST_v1.json',manifest)
receipt={
 'created_utc':at,'type':'focused staged canonical correspondence; not formal audit or live delivery','checker':'/root/local_response_check','direct_scientific_author':'/root','unit':str(H),
 'report':info(H/'REPORT_v1.md'),'manifest':info(H/'MANIFEST_v1.json'),'artifact_count':len(artifacts),'source_pair_count':len(pairs),'current_source_pairs':83,'superseded_preserved_pairs':1,'source_pairs':pairs,
 'final_note':info(finalnote),'runner':info(H/'sources/staged_runner.py'),'staged_result':info(H/'sources/STAGED_RESULTS_v1.json'),'lineage':info(H/'sources/CANONICAL_LINEAGE_v3.json'),
 'new_science_runs':0,
 'new_correspondence':{'corrected':'616/0','original_preserved':'614/2; two checker guard defects','results':info(H/'CORRESPONDENCE_v2_stdout.json'),'original_result':info(H/'CORRESPONDENCE_RESULTS_v1.json'),'repair':info(H/'CHECKER_REPAIR_v2.json')},
 'new_wrapper_probes':{'baseline':'15/0','seeded_failed_row_behavior':'15/0','science_functions_replaced_by_sentinels':True,'actual_damages':{'stale_roots':'3/3','truncated_rows':'12/3','stdout_progress':'14/1','changed_science_AST_only':'615/1'},'all_four_actual_damages_exit_one':True,'records':info(H/'CONTROL_RUN_SUMMARY_v1.json')},
 'metadata':{'finite_and_sources':'272/0','density':'180/0','final_identity':str(sum(x['passed'] for x in checks))+'/0'},
 'reused_science':{'finite_body':{'report':info(H/'sources/finite_body_REPORT_v1.md'),'receipt':info(H/'sources/finite_body_RECEIPT_v1.json'),'verified_artifacts':88,'verified_source_pairs':8,'science':'76/0 and six damages; no rerun'},'density':{'report':info(H/'sources/density_independent_REPORT_v1.md'),'receipt':info(H/'sources/density_independent_RECEIPT_v1.json'),'verified_artifacts':126,'verified_source_pairs':12,'science':'146/0 main, 49/0 addendum, 23/0 source/volume correspondence; no rerun','producer_diff_copy_disclosure':info(H/'sources/density_independent_ACCESS_INCIDENT_v1.json')}},
 'author_science_result':'Fresh staged 340/0 =208+96+36, not new independent science. Runner execution precedes final reference-only note alias; live input-bound cache remains pending.',
 'preserved_failures':[info(H/'READ_FAILURE_v1.json'),info(H/'CORRESPONDENCE_RESULTS_v1.json'),info(H/'CHECKER_REPAIR_v2.json'),info(H/'sources/finite_FAILURE_REPAIR_v2.json'),info(H/'sources/density_SUSCEPTIBILITY_INTERRUPTION_v1.json'),info(H/'sources/density_SUSCEPTIBILITY_FAILURE_REPAIR_v3.json')],
 'original_reviewer_confirmation':info(H/'FINAL_SOURCE_CONFIRMATION_v1.json'),'claim_dispositions':info(H/'CLAIM_SOURCE_DISPOSITIONS_v1.json'),'commands':info(H/'COMMAND_LOG_v2.json'),'seal_command':['/usr/local/bin/python3','-B','seal_unit_v1.py'],
 'conclusion':'Staged correspondence supported, including final density convention and reference correction. Ready for separate live source/cache and delivery work; no such result is claimed here.',
 'limitations':['No new physical derivation or scientific rerun','Prior producer-diff metadata access incident retained, not erased','No empirical calibration, body/environment solution or tracking theorem','No live canonical cache/archive/delivery or integrated result certified','No audit, authority/status change'],
 'writes_confined_to_unit':True,'prior_seals_modified':False,'author_sources_modified':False,'git_runtime_lock_pr_audit_modified':False,'immutable_after_seal':True
}
write('RECEIPT_v1.json',receipt)
print(json.dumps({'report':info(H/'REPORT_v1.md'),'manifest':info(H/'MANIFEST_v1.json'),'receipt':info(H/'RECEIPT_v1.json'),'artifact_count':len(artifacts),'source_pair_count':len(pairs),'final_identity_controls':str(sum(x['passed'] for x in checks))+'/0'},indent=2))
