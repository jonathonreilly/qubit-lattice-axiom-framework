from pathlib import Path
import sys,json,hashlib,math
import sympy as S
import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss

out=Path(sys.argv[1]);assert not out.exists();checks=[]
def ck(n,v,d=None):checks.append(dict(name=n,passed=bool(v),detail=d))
def eq(n,e):
 v=S.factor(S.simplify(e));ck(n,v==0,str(v))
r,mu,z=S.symbols('r mu z',positive=True)
f=(1+z)*S.exp(-z)
eq('force_from_Yukawa_potential',S.diff(-S.exp(-mu*r)/r,r)-(1+mu*r)*S.exp(-mu*r)/r**2)
eq('pair_force_monotone',S.diff(f,z)+z*S.exp(-z))
eq('pair_force_at_zero',f.subs(z,0)-1)
ck('pair_force_nonnegative',f.is_positive)
t=S.symbols('t',positive=True)
form=3*(z*S.cosh(z)-S.sinh(z))/z**3
primitive=3*(z*t*S.cosh(z*t)-S.sinh(z*t))/z**3
eq('sphere_radial_primitive',S.diff(primitive,t)-3*t*t*S.sinh(z*t)/(z*t))
eq('sphere_formfactor_integral',primitive.subs(t,1)-primitive.subs(t,0)-form)
ck('sphere_massless_limit',S.limit(form,z,0)==1)
eq('stable_sphere_factor',form*S.exp(-z)-3*((z-1)+(z+1)*S.exp(-2*z))/(2*z**3))
kappa,q,I0=S.symbols('kappa q I0',positive=True)
plus=(kappa+1)/2;minus=(kappa-1)/2
eq('signed_kernel_difference',plus-minus-1)
eq('signed_kernel_total_variation',plus+minus-kappa)
cap=1+q*(kappa+1)/2
eq('signed_upper_normalization',cap-(1+q*plus))
eq('signed_lower_normalization',(1-q*(kappa-1)/2)-(1-q*minus))
eta,sigma,lam,L=S.symbols('eta sigma lam L',positive=True)
R=S.Rational(11,4)**S.Rational(1,3)
calcap=(1+eta)*(kappa+7)/6
bare=2*lam**2/(R*sigma**S.Rational(4,3))
product=bare/calcap
eq('universal_geometry_calibration_cap',cap.subs(q,S.Rational(1,3))*(1+eta)-calcap)
eq('joint_thermal_geometry_product',product-12*lam**2/(R*sigma**S.Rational(4,3)*(1+eta)*(kappa+7)))
eq('positive_geometry_recovers_same_background',product.subs(kappa,1)-3*lam**2/(2*R*sigma**S.Rational(4,3)*(1+eta)))
threshold=12/R-7
eq('unit_geometry_threshold',product.subs({lam:1,sigma:1,eta:0,kappa:threshold})-1)
ck('threshold_contains_positive_geometry',threshold>1)

# A concrete signed differential observable, no particular apparatus asserted.
def force_weight(zz):return (1+zz)*math.exp(-zz)
weights=np.array([1.,-.9]);seps=np.array([1.,10.]);ratio=sum(a*force_weight(b) for a,b in zip(weights,seps))/sum(weights)
kap=sum(abs(weights))/abs(sum(weights));qq=.1;gamma=1+qq*ratio
ck('signed_readout_exceeds_point_source_cap',gamma>1+qq,dict(ratio=ratio,gamma=gamma,kappa=kap))
ck('signed_readout_obeys_decomposition',-(kap-1)/2<=ratio<=(kap+1)/2)
ck('signed_geometry_not_positive_geometry',kap>1)

# Stable full sphere factor: each S*exp(-x) is evaluated without overflow.
def scaled_form(x):
 if x==0:return 1.
 if abs(x)<1e-3:
  return math.exp(-x)*(1+x*x/10+x**4/280+x**6/15120)
 return 3*((x-1)+(x+1)*math.exp(-2*x))/(2*x**3)
def complete_factor(x,y,z):
 return scaled_form(x)*scaled_form(y)*(1+z)*math.exp(-(z-x-y))
sphere_grid=[]
for xx in [0.,.0001,.01,.3,1.,5.,20.,100.]:
 for yy in [0.,.02,.7,3.,30.]:
  for gap in [.001,.1,2.,10.]:
   zz=xx+yy+gap;fac=complete_factor(xx,yy,zz)
   ck('nonoverlap_sphere_cap_'+str((xx,yy,gap)),0<=fac<=1+3e-11,fac)
   sphere_grid.append(dict(x=xx,y=yy,z=zz,factor=fac))
for xx in [.01,.1,1.,5.,20.]:
 v,e=quad(lambda t:3*t*t*math.sinh(xx*t)/(xx*t)*math.exp(-xx),0,1,epsabs=1e-13,epsrel=1e-13)
 ck('sphere_source_radial_quadrature_'+str(xx),abs(v-scaled_form(xx))<3e-12,dict(integral=v,closed=scaled_form(xx),error=e))

# Independent integration over test-body volume of the source's exterior force.
# Fixed spherical densities are supplied; this is not a self-consistent body model.
def test_volume(mu,rs,rt,d,n):
 xs,ws=leggauss(n);rad=(xs+1)/2;wr=ws/2
 rr=rt*rad[:,None];cost=xs[None,:]
 distance=np.sqrt(d*d+rr*rr+2*d*rr*cost)
 projection=d+rr*cost
 kernel=3*rad[:,None]**2*wr[:,None]*ws[None,:]/2*projection/distance**3*d*d
 Ssource=scaled_form(mu*rs)*math.exp(mu*rs)
 massive=(1+mu*distance)*np.exp(-mu*distance)
 return float(np.sum(kernel)*1),float(Ssource*np.sum(kernel*massive)),float(np.min(kernel))
volume=[]
for case in [(0.,.4,.3,1.),(1.,.3,.2,1.),(1.,1.2,.5,2.),(1.,2.,3.,5.5),(2.,.1,.9,1.1)]:
 mm,rs,rt,dd=case;expected=complete_factor(mm*rs,mm*rt,mm*dd)
 n40=test_volume(*case,40);n80=test_volume(*case,80)
 ck('sphere_volume_Newton_normalization_'+str(case),abs(n80[0]-1)<3e-11,n80[0])
 ck('sphere_volume_Yukawa_formula_'+str(case),abs(n80[1]-expected)<3e-11,dict(volume=n80[1],formula=expected))
 ck('sphere_volume_resolution_'+str(case),abs(n40[1]-n80[1])<3e-11)
 ck('sphere_volume_positive_kernel_'+str(case),n80[2]>=0)
 volume.append(dict(case=case,n40=n40,n80=n80,expected=expected))
res=dict(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),checks=checks,sphere_grid=sphere_grid,test_volume_quadratures=volume,
 signed_control=dict(ratio=ratio,gamma=gamma,kappa=kap),thermal_geometry_threshold=str(S.N(threshold,25)),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 scope='Conditional finite-body frozen linear response; synthetic geometries, no actual apparatus fit, environment or equilibrium body solution. Thermal input remains separately conditional.')
out.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k not in ['checks','sphere_grid','test_volume_quadratures']}))
for row in checks:
 if not row['passed']:print('FAILED',row)
sys.exit(bool(res['failed']))
