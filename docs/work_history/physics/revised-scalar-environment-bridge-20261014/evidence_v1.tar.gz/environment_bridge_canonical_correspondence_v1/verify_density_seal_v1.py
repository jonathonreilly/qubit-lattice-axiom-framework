from pathlib import Path
import hashlib,json,datetime
H=Path(__file__).resolve().parent;U=H.parent/'rolling_local_response/density_environment_v1/independent_v1'
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,v,**data):rows.append(dict(name=n,passed=bool(v),**data))
r=json.loads((H/'sources/density_independent_RECEIPT_v1.json').read_text())
m=json.loads((H/'sources/density_independent_MANIFEST_v1.json').read_text())
for key in ['report','manifest']:
    a=r[key];p=U/a['path'];ck('receipt_'+key,sha(p)==a['sha256'] and p.stat().st_size==a['bytes'])
ck('126_artifacts',r['artifact_count']==m['artifact_count']==len(m['artifacts'])==126)
for a in m['artifacts']:
    rel=Path(a['path']);p=U/rel
    ck('artifact_'+a['path'],not rel.is_absolute() and '..' not in rel.parts and not p.is_symlink() and sha(p)==a['sha256'] and p.stat().st_size==a['bytes'])
for a in r['source_pairs']:
    snap=U/a['snapshot_path'];p=Path(a['original_path'])
    ck('snapshot_'+a['snapshot_path'],sha(snap)==a['sha256'] and snap.stat().st_size==a['bytes'])
    ck('live_'+a['snapshot_path'],sha(p)==a['sha256'] and p.stat().st_size==a['bytes'])
ck('12_pairs_including_one_disclosed',len(r['source_pairs'])==r['source_pair_count']==12 and r['intended_source_pair_count']==11 and r['contextual_unintended_pair_count']==1)
ck('final_density_corresponds',r['final_author_source']['sha256']==sha(H/'sources/proof_3_DERIVATION_v3.md'))
ck('final_addendum_corresponds',r['final_addendum_source']['sha256']==sha(H/'sources/proof_2_SUSCEPTIBILITY_ADDENDUM_v1.md'))
ck('full_action_binding',sha(H/'sources/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md')=='39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000')
for key,expected in [('main',146),('susceptibility',49),('source_correspondence_and_exact_density_witness',23)]:
    a=r['new_mathematics'][key];b=json.loads((U/a['result']['path']).read_text())
    ck('reused_count_'+key,a['passed']==b['passed']==expected and a['failed']==b['failed']==0)
incident=json.loads((H/'sources/density_independent_ACCESS_INCIDENT_v1.json').read_text())
freeze=datetime.datetime.fromisoformat(incident['freeze_timestamp'])
for a in incident['records']:
    actual=json.loads((U/a['record']).read_text())
    ck('incident_time_'+a['record'],actual['finished_at']==a['finished_at'] and datetime.datetime.fromisoformat(a['finished_at'])<freeze)
ck('access_disclosure_preserved',r['producer_access']['code_bytes_copied_after_main_addendum_and_damage_executions'] is True and r['producer_access']['code_or_results_semantically_read'] is False and r['producer_access']['imported_or_executed'] is False)
for file in ['SOURCE_BINDINGS_v4.json','SOURCE_BINDINGS_v5.json']:
    for a in json.loads((H/file).read_text())['source_pairs']:
        ck('new_snapshot_'+a['snapshot_path'],sha(H/a['snapshot_path'])==a['sha256'])
        ck('new_live_'+a['snapshot_path'],sha(Path(a['original_path']))==a['sha256'])
res=dict(scope='Independent density seal metadata verification only; prior science not rerun',passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,artifacts=126,source_pairs=12)
print(json.dumps(res,indent=2));raise SystemExit(bool(res['failed']))
