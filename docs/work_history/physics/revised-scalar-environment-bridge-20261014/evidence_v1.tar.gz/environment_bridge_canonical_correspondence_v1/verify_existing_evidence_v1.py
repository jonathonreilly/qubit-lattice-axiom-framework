from pathlib import Path
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(name,ok,**kw):checks.append(dict(name=name,passed=bool(ok),**kw))
all_pairs=[]
for file in ['SOURCE_BINDINGS_v1.json','SOURCE_BINDINGS_v2.json','SOURCE_BINDINGS_v3.json']:
    pairs=json.loads((HERE/file).read_text())['source_pairs'];all_pairs.extend(pairs)
    for row in pairs:
        snap=HERE/row['snapshot_path'];live=Path(row['original_path'])
        ck('snapshot_'+row['snapshot_path'],sha(snap)==row['sha256'] and snap.stat().st_size==row['bytes'])
        if row['snapshot_path']=='sources/staged_note_v2.md':
            ck('superseded_note_recovered',sha(HERE/'sources/history_NOTE_v2.md')==row['sha256'])
            ck('superseded_note_current_binding',sha(live)==sha(HERE/'sources/final_EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md'))
        else:ck('live_'+row['snapshot_path'],sha(live)==row['sha256'] and live.stat().st_size==row['bytes'])
receipt=json.loads((HERE/'sources/finite_body_RECEIPT_v1.json').read_text())
manifest=json.loads((HERE/'sources/finite_body_MANIFEST_v1.json').read_text())
unit=HERE.parent/'rolling_local_response/finite_body_calibration_v1/independent_v1'
for key in ['report','manifest']:
    r=receipt[key];p=unit/r['path'];ck('finite_receipt_'+key,sha(p)==r['sha256'] and p.stat().st_size==r['bytes'])
ck('finite_count_88',receipt['artifact_count']==manifest['artifact_count']==len(manifest['artifacts'])==88)
for a in manifest['artifacts']:
    rel=Path(a['path']);ck('finite_artifact_'+a['path'],not rel.is_absolute() and '..' not in rel.parts and sha(unit/rel)==a['sha256'] and (unit/rel).stat().st_size==a['bytes'])
for row in receipt['source_pairs']:
    ck('finite_source_snapshot_'+row['snapshot_path'],sha(unit/row['snapshot_path'])==row['sha256'])
    ck('finite_source_live_'+row['snapshot_path'],sha(Path(row['original_path']))==row['sha256'])
ck('finite_eight_pairs',len(receipt['source_pairs'])==8)
for rname,code in [('finite_RESULTS_v1.json','finite_history_check_finite_body_v1.py'),('finite_RESULTS_v2.json','finite_history_check_finite_body_v2.py'),('density_SUSCEPTIBILITY_RESULTS_v2.json','density_history_check_susceptibility_v2.py')]:
    r=json.loads((HERE/'sources'/rname).read_text());ck('historical_result_code_'+rname,r['code_sha256']==sha(HERE/'sources'/code))
result=dict(scope='Hash and metadata verification only; all prior scientific results reused without rerun',passed=sum(c['passed'] for c in checks),failed=sum(not c['passed'] for c in checks),source_pairs=len(all_pairs),reused_finite_body={'artifacts':88,'source_pairs':8,'receipt_sha256':sha(HERE/'sources/finite_body_RECEIPT_v1.json')},checks=checks)
print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
