from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'environment_bridge_packaging';dest=wt/'docs/work_history/physics/revised-scalar-environment-bridge-20261014'
fb='rolling_local_response/finite_body_calibration_v1'
de='rolling_local_response/density_environment_v1'
roots=[fb,de,'environment_bridge_canonical_correspondence_v1','environment_bridge_packaging']
seal_units=[fb+'/independent_v1',de+'/independent_v1','environment_bridge_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional finite-body readout envelope, prescribed-particle stationary density and local mass/susceptibility; original sources, actual checks and failures and scoped independent evidence. The later general scale-eliminated susceptibility identity is outside this archive.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for the revised scalar environment-bridge milestone

Live claim: docs/EXPONENTIAL_SCALAR_ENVIRONMENT_BRIDGE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

The finite-body integral derives a positive-kernel force ceiling from a supplied
stable weak Yukawa response. A signed readout requires its separate total-variation
bound. Coupling the geometry envelope to the earlier entropy theorem retains all
bath, bounce and positive-calibration premises. No actual apparatus is fitted.

For prescribed nonrelativistic particle density per Einstein proper volume,
variation of the supplied action derives U+delta_* A. A fixed physical density
has one negative-field stationary root at fixed action/scales, but fixed particle
data can have at least two local minima and a full-field saddle. The susceptibility
slope exceeds two, and the radial mass is positive precisely when it exceeds three.
This is a stationary-family statement, not branch preparation or adiabatic tracking.

Fresh canonical340/0 comprises208 finite-body,96 density and36 susceptibility
controls, preserving all original rows and tables. The complete live merged stream
equals the staged stderr followed by staged stdout. runner_cache deliberately
combines the streams; the original parent JSON-only parser failure is preserved
with its repair, and no science rerun was needed. Independent proof controls and
actual altered implementations are separate from packaging/identity checks.

Original finite-body202/3 numerical/CAS failures and subsequent corrections,
the susceptibility CAS stall without a result, and34/1 finite-asymptotic-tolerance
failure remain. The corrected36/0 uses an exact remainder bound. Density proper-
volume and full-field saddle clarifications preserve original versions. The density
independent checker discloses a post-science accidental byte copy/hash of one
producer diff; it was not displayed, interpreted or used in the independent science.

All examples are exposed synthetic development data. The actual environment,
pressure and backreaction, measured force likelihood, state, supplied action and
fundamental scales remain open. This archive excludes later general susceptibility
work; it claims no independent empirical test or derived complete theory.

Extract only safe regular relative members and verify manifest sizes/hashes.
Archive-build/commit and postcommit delivery/UNIT records occur after this archive.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
