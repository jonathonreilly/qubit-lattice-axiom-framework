# Finite-body calibration from positive pair forces

Scientific author /root. Derivation frozen before executable controls. This addresses the remaining laboratory-gravity bridge: actual gravitational measurements use finite source/test bodies and instrument geometries. It asks which point-source ceiling survives such geometry, without treating a laboratory uncertainty as a response-model error. It is a conditional linear response theorem, not a nonlinear environment solution or a fit to a particular gravimeter.

## Supplied linear response and explicit premises

Reuse the action-normalized, locally frozen weak-source response already checked in the campaign: in one common finite scalar background, the potential between two nonrelativistic point masses is

 V(r)=-G_bare m1 m2/r [1+sum_j omega_j exp(-mu_j r)],
 omega_j>=0, sum_j omega_j=q, mu_j>=0,
 q=b^T K^-1 b<1/3, G_bare=C/(8piQ).

The nonnegative omega_j follow from a positive kinetic metric and self-adjoint nonnegative mass matrix in the stated linear regime. Stability, frozen coefficients, universal nonrelativistic scalar charges, weak fields and negligible source backreaction beyond this linearization are premises. Body density profiles must be supplied in physical units. Arbitrary screening, relativistic pressure, strong self-gravity, varying background or negative effective charges lie outside this result.

Differentiating the potential gives the exact pair-force ratio

 F_pair/F_Newton =1+sum_j omega_j f(mu_j r),
 f(z)=(1+z) exp(-z), 0<=f(z)<=1 for z>=0,
 f'(z)=-z exp(-z)<=0.                                      (1)

Let K(x,y) be the Newtonian contribution to a chosen scalar force component or linear instrument readout, including nonnegative mass densities, projection or instrument weights, and 1/r^2. Assume finite integrals, nonzero Newtonian normalization I0=integral K, and body supports separated from coincidence. The calibrated ratio for exactly this measurement model is

 gamma_obs = 1+sum_j omega_j I_j/I0,
 I_j=integral K(x,y) f(mu_j |x-y|).                        (2)

This is a forward prediction after specifying geometry, not a derivation of the experimental calibration method.

## Positive geometry removes the point-source premise

If K has one sign almost everywhere (reverse the readout orientation if needed), equation (1) implies 0<=I_j/I0<=1. Therefore

 1<=gamma_obs<=1+q.                                       (3)

The result holds for finite nonuniform bodies; point particles are unnecessary. For the component of the mutual attractive force along a direction n, it suffices that n.(y-x)>0 for every source/test pair. Supports separated by parallel planes provide this condition. Disjoint spheres with center separation d>R_s+R_t satisfy it along their center axis. Any densities>=0 and finite masses are allowed under the linear-response premises. Coincident/touching singular cases are not needed for the proof.

For homogeneous spheres, Green-function angular integration gives

 gamma_obs=1+sum_j omega_j S(mu_j R_s) S(mu_j R_t)
                        (1+mu_j d) exp(-mu_j d),
 S(z)=3[z cosh(z)-sinh(z)]/z^3, S(0)=1.                   (4)

One way to derive S is to integrate the interior source weight sinh(mu r)/(mu r) against 3r^2/R^3; applying the same convolution to the test sphere gives the second S. Although S(z)>1 for z>0, the COMPLETE force factor in (4) is <=1 for nonoverlapping spheres, as proved directly by the positive pair-force integral. S alone must not be used as a force enhancement. Equation (4) assumes fixed spherical profiles, not body equilibrium derived from the scalar action.

## Signed readouts retain a geometry cost

For a differential or torque-like linear readout K may change sign. Let

 kappa_geom = integral |K| / |I0| >=1.

The general triangle estimate gives |I_j/I0|<=kappa_geom, hence

 |gamma_obs-1|<=q kappa_geom.                              (5)

This is conservative; it need not be tight or imply gamma_obs>0. A physically used positive calibrated G still requires gamma_obs>0. The special upper ceiling1+q cannot be asserted for a signed readout merely because each pair interaction is attractive. For example, two positive force measurements combined with Newtonian weights +1 and -9/10 give I0=1/10. At separations1 and10 and mu=1, I/I0=10[f(1)-(9/10)f(10)]>1. This is an explicit synthetic differential observable, not an identified laboratory apparatus.

If a separately justified response error eta>=0 gives positive gamma_cal<=(1+eta)gamma_obs, a usable upper bound is

 gamma_cal<=(1+eta)(1+q kappa_geom)
             <(1+eta)(1+kappa_geom/3).                    (6)

Laboratory G's statistical uncertainty is not eta. Actual geometry, body response, backgrounds and error terms must be established before applying (6). At a distinct cosmological background, an additional C_local/C_cos factor remains and this same-background relation cannot eliminate it.

## Consequence for the correlated thermal bounce budget

Reusing the separately checked joint total-bath relation P_bare>2 exp(2N)/[R sigma^(4/3)] gives, if positive same-background calibrated gravity satisfies (6),

 P_cal > 2 exp(2N)/[R sigma^(4/3)(1+eta)(1+kappa_geom/3)]. (7)

For positive geometry kappa_geom=1, this reduces to the improved3/(2R) coefficient without any point-source approximation. More generally N>=0, sigma=1, eta=0 and a unit target P_cal<=1 are incompatible when

 kappa_geom <= 3(2/R-1), R=(11/4)^(1/3).                 (8)

Equality is excluded because the bounce/coupling bounds are strict. A larger geometry factor does not construct an escaping history or a successful experimental fit. If eta or entropy are nontrivial their explicit factors remain. This implication depends on the separate joint thermal proof, not on body algebra alone.

## Assumption accounting

Finite source/test size is eliminated as an automatic objection to the weak same-background cap for positive readouts. An unrestricted instrument geometry cannot be eliminated; equation(5) quantifies what signed cancellation costs. The assumed linear background, mass spectrum, physical matter profiles, small-field conditions, and any cosmological-to-local environment identification survive. No candidate action, state, mass scale, entropy source, actual laboratory response or primordial-abundance likelihood is selected. Published CODATA G measurements motivate this issue but are not fitted by these synthetic controls.
