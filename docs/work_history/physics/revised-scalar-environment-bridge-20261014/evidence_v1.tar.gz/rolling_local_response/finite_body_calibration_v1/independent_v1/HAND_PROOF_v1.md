# Independent finite-body geometry proof, before executable controls

The complete new v2 source/protocol and the frozen gravity and joint thermal
reports have been read. No current producer implementation or result file has
been read. Parent-announced counts and source examples are known targets,
not independent evidence. The present check accepts the earlier physical
weak-response normalization as a premise and does not derive nonlinear body
equilibrium, a stable rolling mass spectrum, actual apparatus behavior or the
thermal theorem again.

Let A=sqrt(C) be constant over the local response problem. A physical rest mass
m has Einstein mass A*m, and r_J=A*r_E. The Einstein Newtonian potential
-m_E/(8*pi*Q*r_E) therefore has physical coefficient C/(8*pi*Q) multiplying
m/r_J. A scalar eigenmass in Einstein coordinates corresponds to
mu_J=mu_E/A so that mu_E*r_E=mu_J*r_J. Physical densities and volumes obey
rho_E=A^4*rho_J and dV_E=dV_J/A^3. All masses, radii and mu in the new body
formula must be the physical, common-background ones. Varying profiles with
separation or including gravitational binding energies changes the problem.

For a fixed positive kinetic matrix K and a self-adjoint nonnegative static
mass operator, transform to the K-orthonormal basis. Writing b_hat=K^(-1/2)b
and orthogonally diagonalizing the transformed mass matrix gives squared
source/detector couplings omega_j=(e_j.b_hat)^2>=0. Their sum is
b_hat.b_hat=b^T K^-1 b=q. The diagonal static Green functions are
exp(-mu_j*r)/(4*pi*r). This spectral observation supports the supplied
Yukawa model under its explicit assumptions; it does not prove those
assumptions or neglect of metric/time mixing on an actual rolling background.

For V=-G*m1*m2*(1+sum omega exp(-mu*r))/r, the radial attractive force
magnitude is dV/dr, and differentiating gives

    f(z)=(1+z) exp(-z),    f'(z)=-z exp(-z).

Thus 0<f<=1 at finite z>=0 (zero only as z tends to infinity). For a linear
readout with fixed physical geometry, pair forces superpose with precisely
the same real kernel K(x,y) in its Newtonian and Yukawa channels. Absolute
integrability, finite nonzero I0 and separated supports are required.
If all K have one sign, normalize after reversing orientation as necessary:
K/I0 is a nonnegative unit measure, so its average of each f lies in [0,1].
Then 1<=gamma<=1+q. A common center-axis projection is positive for all
pairs of balls with d>Rs+Rt, since n.(y-x)>=d-Rs-Rt>0. Nonuniform positive
density profiles preserve this argument, but do not preserve the homogeneous
sphere form factor.

For r>R, choose the polar axis along the exterior observation point. The
angular average of the Yukawa kernel for one source shell is obtained by
substitution ell=sqrt(r^2+s^2-2*r*s*z):

    (1/2) integral_-1^1 exp(-mu*ell)/ell dz
      = exp(-mu*r)/r * sinh(mu*s)/(mu*s).

Integrating the uniform shell weight 3*s^2/R^3 gives

    S(mu*R)=3[(mu*R)cosh(mu*R)-sinh(mu*R)]/(mu*R)^3.

The second separated sphere gives the same exterior convolution, hence the
interaction energy is -G*Ms*Mt*S(mu*Rs)*S(mu*Rt)*exp(-mu*d)/d.
Differentiation in d at fixed profiles produces the full force factor
S(mu*Rs)*S(mu*Rt)*(1+mu*d)*exp(-mu*d). No surface or test-body factor can
be dropped. S(z)=1+z^2/10+z^4/280+O(z^6), and S(z)>1 for z>0 because
sinh(t)/t>1. The full force factor is nevertheless <=1 by the positive
pair-force average, not by a bound S<=1. The massless limit is 1. Overlap
invalidates this exterior derivation and the quoted center-axis positivity
argument; treating the exterior expression as an overlap formula can yield
a factor greater than 1 without refuting the actual theorem.

For an independent numerical route, write w=y-x for two uniform ball points.
Their displacement density is V_overlap(|w|)/(Vs*Vt). With separation ell
between two balls, an intersection cap has volume pi*h^2*(R-h/3), obtained
by integrating pi*(R^2-z^2). The intersection-plane coordinate is
a=(ell^2+Rs^2-Rt^2)/(2*ell), so the two caps give

    V_overlap=4*pi*min(Rs,Rt)^3/3                   if ell<=|Rs-Rt|,
    V_overlap=pi*(Rs+Rt-ell)^2
        *[ell^2+2*ell*(Rs+Rt)-3*(Rs-Rt)^2]/(12*ell) otherwise,

up to ell=Rs+Rt. Integrating this isotropic difference distribution gives a
fresh two-dimensional direct force integral, independent of either S factor:

    F_mu/(G*Ms*Mt) = 2*pi/(Vs*Vt) integral ell^2 V_overlap(ell) d ell
      * integral_-1^1 [(d+ell*z)/r^3] (1+mu*r) exp(-mu*r) dz,
    r=sqrt(d^2+ell^2+2*d*ell*z).

The radial integral is split at |Rs-Rt|. The comparison with the homogeneous
sphere answer divides by the Newtonian force G*Ms*Mt/d^2. At mu=0 its
angular integral is 2/d^2, supplying a normalization control. These are
numerical corroborations, not rigorous quadrature error enclosures; convergence
and analytic proof remain distinct.

For signed K and oriented I0>0, put P=integral K_plus/I0 and
M=integral K_minus/I0. Then P-M=1 and P+M=kappa, yielding
P=(kappa+1)/2 and M=(kappa-1)/2. Since every f is between zero and one,

    -M <= I_mu/I0 <= P,
    1-q*(kappa-1)/2 <= gamma <= 1+q*(kappa+1)/2.

The coarser |gamma-1|<=q*kappa also follows. For fixed finite geometry the
tighter bounds need not be attained by one common Yukawa range. Positivity
of the physical pair forces does not imply positivity of their signed
calibration ratio. A finite-body test will combine two positive axial force
readouts with Newtonian-normalized weights +1 and -7/8, giving I0=1/8 and
kappa=15. Use physical homogeneous spheres of radii 1/20 and 3/40, separations
3/4 and 5, and mu=6/5. Assigning the positive weight to the near configuration
should exceed the naive I_mu/I0<=1 ceiling; reversing the range assignment
can make gamma<0 at q=1/4. This latter signed response cannot be used as a
positive measured G. These are synthetic, supplied weights and profiles.

If a positive calibrated ratio obeys gamma_cal<=(1+eta)*gamma_obs with
eta>=0, then gamma_obs must be positive and

    gamma_cal <= (1+eta)[1+q*(kappa+1)/2]
              < (1+eta)*(kappa+7)/6,

using 0<=q<1/3 and kappa>=1. The strict upper envelope holds even at q=0.
A small Newtonian cancellation I0 makes kappa large and can amplify model
errors; the inequality is a separately justified aggregate error premise,
not a consequence of laboratory statistical uncertainty.

Only the already sealed joint thermal result is reused:
P_bare>2*exp(2N)/(R*sigma^(4/3)), with its complete same-bath, strict
Einstein-bounce, entropy and regular-endpoint assumptions. Since positive
P_cal=P_bare/gamma_cal, division by the above positive ceiling gives

    P_cal > 12*exp(2N)/[R*sigma^(4/3)*(1+eta)*(kappa+7)].

At kappa=1 this is 3*exp(2N)/(2R*sigma^(4/3)*(1+eta)). At N>=0,
sigma=1, eta=0 and positive unit target, kappa<=12/R-7 is excluded,
including equality. Larger kappa is absence of this sufficient obstruction,
not a counterhistory. A different cosmological background leaves the ratio
of local and cosmic conformal factors; the geometry proof cannot cancel it.

No consequential source correction is apparent in this hand check. The
supplied fixed-spectrum, common-background, weak/static, fixed-profile,
linear-readout and positive-calibration conditions remain substantive open
application obligations rather than consequences of the geometry theorem.
