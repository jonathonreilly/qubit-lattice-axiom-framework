from pathlib import Path
import argparse
import json
import platform

import mpmath as mp
import numpy as np
import sympy as sp
from numpy.polynomial.legendre import leggauss

HERE=Path.cwd()
PAIR_LINEAR_TERM = 1
TEST_SPHERE_POWER = 1
USE_POSITIVE_CEILING_FOR_SIGNED = True
PHYSICAL_MASS_A_POWER = 1
CALIBRATION_GAMMA_POWER = -1
ALLOW_OVERLAPPING_SPHERES = False
mp.mp.dps=60
parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
args=parser.parse_args()
checks=[]
def check(name,condition,observed,expected,category='exact'):
    checks.append({'name':name,'category':category,'ok':bool(condition),
                   'observed':str(observed),'expected':str(expected)})
def exact(name,expr):
    val=sp.factor(sp.cancel(sp.expand(expr)))
    val=sp.simplify(val)
    check(name,val==0,val,'0 exactly')
def close(name,left,right,atol=2e-12,rtol=2e-10):
    error=abs(float(left)-float(right));tol=atol+rtol*abs(float(right))
    check(name,error<=tol,{'left':str(left),'right':str(right),'absolute_error':error},
          {'absolute_tolerance':tol},'numerical')
def f(z): return (1+PAIR_LINEAR_TERM*z)*mp.exp(-z)
def S(z):
    if not z: return mp.mpf(1)
    return 3*(z*mp.cosh(z)-mp.sinh(z))/z**3
def sphere_factor(rs,rt,d,mu):
    rs,rt,d,mu=map(mp.mpf,map(str,(rs,rt,d,mu)))
    return S(mu*rs)*S(mu*rt)**TEST_SPHERE_POWER*f(mu*d)
def sphere_domain(rs,rt,d):
    return min(rs,rt)>0 and (d>0 if ALLOW_OVERLAPPING_SPHERES else d>rs+rt)
def signed_upper(kappa):
    return sp.Integer(1) if USE_POSITIVE_CEILING_FOR_SIGNED else (kappa+1)/2

z,r,mu,omega=sp.symbols('z r mu omega',positive=True)
potential=-(1+omega*sp.exp(-mu*r))/r
claimed_force=1+omega*(1+PAIR_LINEAR_TERM*mu*r)*sp.exp(-mu*r)
exact('pair_potential_derivative',r**2*sp.diff(potential,r)-claimed_force)
fz=(1+PAIR_LINEAR_TERM*z)*sp.exp(-z)
exact('pair_kernel_derivative',sp.diff(fz,z)+z*sp.exp(-z))
exact('pair_massless_value',fz.subs(z,0)-1)
exact('pair_infinite_range_argument_limit',sp.limit(fz,z,sp.oo))
for value in ['0','0.13','1.7','8.2','85']:
    fv=f(mp.mpf(value))
    check('pair_bounded_'+value,0<=fv<=1,mp.nstr(fv,25),'0<=f<=1','domain')

# A nontrivial K-orthonormal basis, with no inherited gravity code.
Rmat=sp.Matrix([[2,1,0],[0,3,1],[0,0,4]])
K=Rmat.T*Rmat
O=sp.Matrix([[sp.Rational(3,5),-sp.Rational(4,5),0],
             [sp.Rational(4,5),sp.Rational(3,5),0],[0,0,1]])
chat=sp.Matrix([sp.Rational(1,7),sp.Rational(1,5),sp.Rational(1,11)])
b=Rmat.T*chat
V=Rmat.inv()*O
mass_diag=sp.diag(0,sp.Rational(25,9),sp.Rational(121,49))
M=Rmat.T*O*mass_diag*O.T*Rmat
for name,matrix in [('K_orthonormal',V.T*K*V-sp.eye(3)),
                    ('mass_eigenbasis',V.T*M*V-mass_diag),
                    ('symmetric_mass',M-M.T)]:
    check(name,matrix==sp.zeros(3),matrix,'zero matrix')
components=V.T*b; weights=[sp.factor(v*v) for v in components]
qnorm=(b.T*K.inv()*b)[0]
exact('mode_weight_sum',sum(weights)-qnorm)
check('positive_mode_weights',all(v>=0 for v in weights),weights,'all >=0','domain')
check('subcritical_control_norm',0<qnorm<sp.Rational(1,3),qnorm,'0<q<1/3','domain')

# Physical units are local frozen units; no full body theory is assumed.
A,mJ,rJ,rhoJ,volJ,muE=sp.symbols('A m_J r_J rho_J vol_J mu_E',positive=True)
mE=A**PHYSICAL_MASS_A_POWER*mJ;rE=rJ/A
exact('physical_mass_radius_normalization',mE/rE-A**2*mJ/rJ)
exact('physical_density_volume_mass',A**4*rhoJ*(volJ/A**3)-A*rhoJ*volJ)
exact('physical_range_argument',muE*rE-(muE/A)*rJ)

t=sp.symbols('t',positive=True)
Ssym=3*(z*sp.cosh(z)-sp.sinh(z))/z**3
S_integral=3*sp.integrate(t*sp.sinh(z*t)/z,(t,0,1))
exact('sphere_radial_integral',S_integral-Ssym)
exact('sphere_massless_limit',sp.limit(Ssym,z,0)-1)
exact('sphere_small_z_series',sp.series(Ssym,z,0,6).removeO()-1-z**2/10-z**4/280)
rr,ss=sp.symbols('rr ss',positive=True)
shell=(sp.exp(-mu*(rr-ss))-sp.exp(-mu*(rr+ss)))/(2*mu*rr*ss)
exact('exterior_shell_angular_integral',sp.expand(shell.rewrite(sp.exp))-
      sp.expand((sp.exp(-mu*rr)/rr*sp.sinh(mu*ss)/(mu*ss)).rewrite(sp.exp)))
for value in ['0.001','0.7','3.4','15']:
    check('S_above_one_'+value,S(mp.mpf(value))>1,mp.nstr(S(mp.mpf(value)),25),'>1','domain')

# Derive overlap volume from cap integration, not the Yukawa form factor.
Rs,Rt,ell,hcap=sp.symbols('R_s R_t ell h_cap',positive=True)
cap_integral=sp.integrate(sp.pi*(Rs**2-t**2),(t,Rs-hcap,Rs))
exact('spherical_cap_integral',cap_integral-sp.pi*hcap**2*(Rs-hcap/3))
plane=(ell**2+Rs**2-Rt**2)/(2*ell)
h1=Rs-plane;h2=Rt-(ell-plane)
caps=sp.pi*h1**2*(Rs-h1/3)+sp.pi*h2**2*(Rt-h2/3)
overlap_middle=sp.pi*(Rs+Rt-ell)**2*(ell**2+2*ell*(Rs+Rt)-3*(Rs-Rt)**2)/(12*ell)
exact('two_cap_overlap_polynomial',caps-overlap_middle)
norm_overlap=4*sp.pi*(sp.integrate(ell**2*4*sp.pi*Rt**3/3,(ell,0,Rs-Rt))+
              sp.integrate(sp.expand(ell**2*overlap_middle),(ell,Rs-Rt,Rs+Rt)))
exact('relative_ball_distribution_normalization',norm_overlap-(4*sp.pi*Rs**3/3)*(4*sp.pi*Rt**3/3))

def direct_pair_force(rs,rt,d,mu,order):
    # The derivative of the Green function is explicit here and does not call f or S.
    nodes,weights_gl=leggauss(order)
    cuts=[0.0,abs(rs-rt),rs+rt]
    total=0.0
    for lo,hi in zip(cuts,cuts[1:]):
        if hi==lo: continue
        rad=(nodes+1)*(hi-lo)/2+lo;wr=weights_gl*(hi-lo)/2
        if hi<=abs(rs-rt)+1e-15:
            overlap=np.full_like(rad,4*np.pi*min(rs,rt)**3/3)
        else:
            overlap=np.pi*(rs+rt-rad)**2*(rad**2+2*rad*(rs+rt)-3*(rs-rt)**2)/(12*rad)
        dist=np.sqrt(d*d+rad[:,None]**2+2*d*rad[:,None]*nodes[None,:])
        axial=(d+rad[:,None]*nodes[None,:])/dist**3
        direct=axial*(1+mu*dist)*np.exp(-mu*dist)
        angular=direct@weights_gl
        total+=float(np.sum(wr*rad**2*overlap*angular))
    return d*d*2*np.pi*total/((4*np.pi*rs**3/3)*(4*np.pi*rt**3/3))

cases=[(.23,.41,1.07,.8),(.35,.19,.89,2.3),(.17,.28,.82,8.7)]
sphere_controls=[]
for index,(rs,rt,d,mass) in enumerate(cases):
    low=direct_pair_force(rs,rt,d,mass,64)
    high=direct_pair_force(rs,rt,d,mass,128)
    analytic=sphere_factor(rs,rt,d,mass)
    newton=direct_pair_force(rs,rt,d,0,128)
    close(f'sphere_direct_vs_formula_{index}',high,analytic)
    close(f'sphere_quadrature_convergence_{index}',low,high)
    close(f'sphere_Newton_normalization_{index}',newton,1)
    check(f'sphere_complete_factor_bounded_{index}',0<analytic<=1,mp.nstr(analytic,35),'0<factor<=1','domain')
    check(f'sphere_nonoverlap_{index}',sphere_domain(rs,rt,d),[rs,rt,d],'d>Rs+Rt','domain')
    sphere_controls.append({'radii':[rs,rt],'d':d,'mu':mass,'order64':low,'order128':high,
                            'analytic':mp.nstr(analytic,45),'newton_direct':newton})
close('uniform_sphere_massless_formula',sphere_factor(.23,.41,1.07,0),1)
overlap_bad=sphere_factor(1,1,.5,4)
check('overlap_rejected',not sphere_domain(1,1,.5),sphere_domain(1,1,.5),'False','domain')
check('exterior_overlap_misuse_exceeds_one',overlap_bad>1,mp.nstr(overlap_bad,35),'>1 outside admissible exterior domain','domain')

# Positive nonuniform profiles: radial pdf n*t^2*(1-t^2)^p, 0<t<1.
profile_norms={1:sp.Rational(15,2),2:sp.Rational(105,8)}
for exponent,norm in profile_norms.items():
    exact('profile_mass_'+str(exponent),sp.integrate(norm*t**2*(1-t**2)**exponent,(t,0,1))-1)
def profile_S(z,exponent):
    norm=mp.mpf(str(profile_norms[exponent])) if profile_norms[exponent].q==1 else mp.mpf(int(profile_norms[exponent].p))/int(profile_norms[exponent].q)
    def integrand(t):
        weight=norm*t*t*(1-t*t)**exponent
        return weight*(mp.sinh(z*t)/(z*t) if z*t else 1)
    return mp.quad(integrand,[0,1])
profile_factors=[]
for mass in [mp.mpf('0.17'),mp.mpf('1.3'),mp.mpf('4.9')]:
    factor=profile_S(mass*mp.mpf('.23'),1)*profile_S(mass*mp.mpf('.41'),2)*f(mass*mp.mpf('1.07'))
    profile_factors.append(factor)
    check('nonuniform_positive_bound_'+str(mass),0<factor<=1,mp.nstr(factor,35),'0<factor<=1','domain')
profile_weights=[mp.mpf('.04'),mp.mpf('.07'),mp.mpf('.12')]
profile_gamma=1+sum(wv*fv for wv,fv in zip(profile_weights,profile_factors))
check('nonuniform_multimode_gamma',1<=profile_gamma<=1+sum(profile_weights),mp.nstr(profile_gamma,35),'[1,1.23]','domain')

kappa,af,bf,q,eta=sp.symbols('kappa af bf q eta',positive=True)
P=(kappa+1)/2;Mn=(kappa-1)/2;ratio=P*af-Mn*bf
exact('signed_positive_negative_masses',P-Mn-1)
exact('signed_total_variation',P+Mn-kappa)
exact('signed_lower_slack',ratio+Mn-(P*af+Mn*(1-bf)))
exact('signed_upper_slack',P-ratio-(P*(1-af)+Mn*bf))
exact('signed_upper_formula',signed_upper(kappa)-P)
exact('coarse_triangle_contains_tight_upper',kappa-P-Mn)
exact('q_ceiling_strict_gap',(1+eta)*(kappa+7)/6-(1+eta)*(1+q*signed_upper(kappa))-
      (1+eta)*(sp.Rational(1,3)-q)*(kappa+1)/2)

near=sphere_factor(.05,.075,.75,1.2);far=sphere_factor(.05,.075,5,1.2)
near_direct=direct_pair_force(.05,.075,.75,1.2,128)
far_direct=direct_pair_force(.05,.075,5,1.2,128)
close('signed_near_direct_force',near_direct,near)
close('signed_far_direct_force',far_direct,far)
signed_ratio=8*near-7*far
reversed_ratio=8*far-7*near
kap=15;qu=mp.mpf(1)/5
gamma_positive=1+qu*signed_ratio
gamma_negative=1+mp.mpf(1)/4*reversed_ratio
check('finite_signed_exceeds_point_ceiling',signed_ratio>1,mp.nstr(signed_ratio,40),'>1','domain')
check('finite_signed_tight_upper',signed_ratio<=float(signed_upper(kap)),mp.nstr(signed_ratio,40),str(signed_upper(kap)),'domain')
check('finite_signed_tight_lower',reversed_ratio>=-(kap-1)/2,mp.nstr(reversed_ratio,40),'>=-7','domain')
check('finite_positive_calibration_above_1plusq',gamma_positive>1+qu,mp.nstr(gamma_positive,40),'>1.2','domain')
check('finite_signed_negative_calibration_possible',gamma_negative<0,mp.nstr(gamma_negative,40),'<0; not admissible positive calibrated G','domain')
I0=mp.mpf(1)/8;I=near-mp.mpf(7)/8*far
close('readout_orientation_invariant',(-I)/(-I0),I/I0)
close('signed_geometry_kappa',(1+mp.mpf(7)/8)/I0,15)

# Reuse the sealed bare thermal premise only; no new gas mathematics.
Rb,sigma,exp2N,gamma=sp.symbols('R sigma exp2N gamma',positive=True)
bare=2*exp2N/(Rb*sigma**sp.Rational(4,3))
calibrated=bare*gamma**CALIBRATION_GAMMA_POWER
exact('positive_calibration_division',calibrated*gamma-bare)
ceiling=(1+eta)*(1+sp.Rational(1,3)*signed_upper(kappa))
thermal_expected=12*exp2N/(Rb*sigma**sp.Rational(4,3)*(1+eta)*(kappa+7))
exact('geometry_thermal_coefficient',calibrated.subs(gamma,ceiling)-thermal_expected)
exact('positive_geometry_thermal_limit',thermal_expected.subs(kappa,1)-
      3*exp2N/(2*Rb*sigma**sp.Rational(4,3)*(1+eta)))
exact('unit_target_threshold_equality',thermal_expected.subs({kappa:12/Rb-7,exp2N:1,sigma:1,eta:0})-1)
Rnumber=(mp.mpf(11)/4)**(mp.mpf(1)/3)
threshold=12/Rnumber-7
check('threshold_exceeds_one',threshold>1,mp.nstr(threshold,40),'>1','domain')
check('threshold_below_two',threshold<2,mp.nstr(threshold,40),'<2','domain')
check('positive_geometry_unit_obstruction',mp.mpf(3)/(2*Rnumber)>1,
      mp.nstr(mp.mpf(3)/(2*Rnumber),40),'>1','domain')

categories={name:{'pass':sum(row['ok'] for row in checks if row['category']==name),
                  'fail':sum(not row['ok'] for row in checks if row['category']==name)}
            for name in sorted({r['category'] for r in checks})}
out={'pass':sum(row['ok'] for row in checks),'fail':sum(not row['ok'] for row in checks),
     'categories':categories,'checks':checks,'sphere_controls':sphere_controls,
     'signed_finite_body':{'Rs':'.05','Rt':'.075','near_distance':'.75','far_distance':'5','mu':'1.2',
                          'Newtonian_weights':['1','-7/8'],'kappa':15,
                          'near_factor':mp.nstr(near,45),'far_factor':mp.nstr(far,45),
                          'near_direct':near_direct,'far_direct':far_direct,
                          'positive_ratio':mp.nstr(signed_ratio,45),
                          'negative_ratio':mp.nstr(reversed_ratio,45),
                          'gamma_at_q_1_5':mp.nstr(gamma_positive,45),
                          'reversed_gamma_at_q_1_4':mp.nstr(gamma_negative,45)},
     'thermal_threshold':mp.nstr(threshold,45),
     'nonuniform_profile_gamma':mp.nstr(profile_gamma,45),
     'overlap_misuse_value':mp.nstr(overlap_bad,45),
     'versions':{'python':platform.python_version(),'sympy':sp.__version__,'numpy':np.__version__,'mpmath':mp.__version__},
     'scope':'Independent frozen weak-response geometry controls; prior response and thermal proof only reused, not rerun; no observational apparatus or background fit'}
target=HERE/args.output
if target.exists(): raise RuntimeError('refusing output overwrite')
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({key:out[key] for key in ['pass','fail','categories','sphere_controls','signed_finite_body','thermal_threshold','nonuniform_profile_gamma','overlap_misuse_value']},indent=2))
for row in checks:
    if not row['ok']: print('FAILED',row['name'],row['observed'],'EXPECTED',row['expected'])
raise SystemExit(0 if out['fail']==0 else 1)
