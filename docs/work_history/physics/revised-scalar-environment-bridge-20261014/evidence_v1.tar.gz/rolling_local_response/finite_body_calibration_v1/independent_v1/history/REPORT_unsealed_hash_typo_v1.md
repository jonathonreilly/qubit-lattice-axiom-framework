# Independent finite-body calibration geometry check

The v2 geometry theorem and its conditional thermal consequence are supported.
No substantive source correction is required. The one-sign ceiling
1<=gamma<=1+q holds for finite nonuniform densities under the supplied linear
response, fixed-profile and readout hypotheses. The signed bounds are

    1-q*(kappa_geom-1)/2 <= gamma
                         <= 1+q*(kappa_geom+1)/2.

The homogeneous sphere expression requires both source and test form factors
and exterior, nonoverlapping geometry. It is not a general profile formula.
The theorem does not establish that an actual instrument realizes its response,
background, body or error assumptions.

New independent controls completed **76/0**: 31 exact identities, 31 domain
controls and 14 numerical comparisons. All six actually altered scripts exited
1 with their intended failures. Separate evidence validation completed
**169/0 metadata checks**, including the reused joint unit's 79 manifest
artifacts and six source pairs. Old gravity and thermodynamic mathematics was
not rerun or added to the new count. No current producer code or result was
read, imported or executed; the announced parent counts are not evidence here.

## Frozen source and dependency identities

| Source | SHA-256 |
| --- | --- |
| Finite-body DERIVATION_v2.md | e1c3bbf16c43ecfb6fb7f0960fed996402fecb88eb66c44b7f8664261a1f7 |
| Finite-body PROTOCOL_v2.json | 0546079a7659b572a7df4cedb34f111c7f0210c8507ad33143227f1dab7bb955 |
| Reused gravity report | a5e215c83937b274acf401852aebed8ceb8193a63aafa7f1002fe6d3fdacbe84 |
| Reused gravity receipt | fe9c02817299c436eb01006188017b64c4c23aa047ae70b228baeda170e724c2 |
| Joint thermal source | 3ed757fa354fa6ab550d7c4225b62d13d4e3787d7aae0fd730aff9a595aa95e8 |
| Joint independent report | e27c3d014726ac35a947b3d27e460f2b185f2f494d725f0e268ab4f75d881b5f |
| Joint independent receipt | 7210514677660e0142b1378b68cbf20bee856153a10c2701d24aa48a0556cb00 |
| Joint independent manifest | 2d8c1fa37f8a63cec5e60cf083ed3696f1bf6629d2458ee21a4e199904fc92e3 |

SOURCE_BINDINGS_v1.json gives all eight live/snapshot paths and byte counts.
The complete current source/protocol and both reused reports were read. The
hand proof and control protocol were frozen before implementation. The reused
gravity report/receipt binding was checked; its whole earlier unit was not
rehash-verified here. The joint receipt's full listed artifact and source
bindings were hash-verified without importing or rerunning its scientific code.
Its 64/0 result and preserved wrapper failure retain their original identity.
The earlier gravity report likewise retains its original failures and corrections.

## Normalization, pair kernel and positive geometry

The reused physical normalization is G_bare=C/(8*pi*Q). At a frozen common
background A=sqrt(C), physical and Einstein quantities obey m_E=A*m_J,
r_J=A*r_E, rho_E=A^4*rho_J and mu_J=mu_E/A. Thus m_E/r_E=C*m_J/r_J
and the Yukawa argument is unchanged. The new body formulas use physical
masses, physical density profiles, physical radii and the physical inverse
range. Omitting the source-mass rescaling fails an actual exact control.

In a positive kinetic metric, a K-orthonormal diagonalization of the supplied
self-adjoint nonnegative static mass operator gives squared coupling weights
omega_j>=0 whose sum is b^T K^-1 b. A nontrivial nondiagonal metric and rotated
mass basis were checked independently. This is conditional spectral algebra,
not evidence that the candidate's full rolling perturbation operator has those
properties or that metric/time mixing is negligible for real bodies.

Differentiating the stipulated potential gives f(z)=(1+z)exp(-z), with
f'(z)=-z exp(-z), f(0)=1 and limit zero. The attractive force magnitude is
dV/dr. For a real fixed readout with nonzero Newtonian normalization and finite
absolute integrals, one-sign K/I0 is a positive unit measure after orientation
reversal. Its average of every f lies in [0,1], proving the finite-body bound.
The finite-integral assumption is used in its ordinary absolute/Lebesgue sense;
conditionally convergent principal-value readouts are not included.

For center-axis readouts on separated balls, every pair has positive projected
separation at least d-Rs-Rt. This supports the claim for arbitrary nonnegative
profiles under the weak-response assumptions. Finite separation also controls
differentiation under the pair integral. Profiles, weights and background
coefficients remain fixed during that operation. Strong self-gravity, varying
scalar charges, relativistic stress, induced shape changes and nonlinear
screening are not supplied by this argument. Incoming or homogeneous fields
are not fixed by selecting the stipulated sourced Yukawa potential.

## Homogeneous spheres and independent force integration

The exterior angular Green-function integral produces the shell weight
sinh(mu*r)/(mu*r). Its uniform volume average is
S(z)=3[z*cosh(z)-sinh(z)]/z^3. Convolution with the second separated sphere
gives the product of two S factors in the interaction energy; differentiation
at fixed profiles supplies (1+mu*d)exp(-mu*d). The exact massless series is
S(z)=1+z^2/10+z^4/280+O(z^6). Although S>1 for positive z, the complete
factor is bounded by the positive pair-force argument.

A different numerical implementation integrates the physical pair force using
the displacement distribution of two uniform ball points. That distribution
is the geometric overlap volume divided by the product of ball volumes. The
overlap formula was derived from spherical-cap integrals; its normalization
was checked exactly, labeling the larger radius first in the symbolic piecewise
calculation. The numerical code uses min(Rs,Rt) and |Rs-Rt| for either order.
The remaining radial/angular force integral uses neither analytic S factor.

| Rs | Rt | d | mu | Direct force ratio, order 128 | Analytic complete factor |
| --- | --- | --- | --- | --- | --- |
| 0.23 | 0.41 | 1.07 | 0.8 | 0.7997544917706724 | 0.7997544917706721 |
| 0.35 | 0.19 | 0.89 | 2.3 | 0.4275929622010652 | 0.4275929622010633 |
| 0.17 | 0.28 | 0.82 | 8.7 | 0.0139090536266154 | 0.0139090536266151 |

The largest absolute formula discrepancy is 1.84e-15 and the largest difference
between quadrature orders 64 and 128 is 1.61e-15. Newtonian normalization is
within 2.7e-15 of unity. These checks corroborate the exact derivation; the
order comparison is not a rigorous numerical error enclosure or proof over
all radii/ranges. Positive polynomial radial profiles with different source
and test shapes were also normalized and integrated, giving a three-mode
gamma=1.08740255679 at total q=0.23, within [1,1.23].

The exterior formula evaluated at Rs=Rt=1,d=0.5,mu=4 gives about 5.99016.
That is a deliberate misuse outside nonoverlap, not an actual overlap-force
prediction or a counterexample to the theorem. The domain guard rejects it;
an actual copy that admits overlap fails its designated control.

## Signed readouts and the positive-calibration restriction

Orient I0>0 and write the normalized positive and negative masses of K as
P and M. Then P-M=1 and P+M=kappa, so P=(kappa+1)/2 and M=(kappa-1)/2.
For averages af,bf in [0,1], the response P*af-M*bf lies in [-M,P]. Its
distance from either endpoint is a sum of explicitly nonnegative terms.
This proves the tighter signed bounds; the coarse q*kappa bound also follows.
A shared Yukawa range need not attain these independent extrema.

The independent finite-body example uses homogeneous balls Rs=0.05,Rt=0.075,
mu=1.2, and two separately specified axial force configurations d=0.75 and
d=5. Their Newtonian-normalized readout weights are +1 and -7/8, so I0=1/8
and kappa=15. The force factors are 0.773386600004 and 0.0173715761483.
Their direct pair integrals agree with the analytic factors.

Giving the positive weight to the near configuration yields I_mu/I0=6.065491767
and gamma=2.213098353 at q=1/5, exceeding 1+q=1.2. Reversing the two range
assignments gives I_mu/I0=-5.274733591 and gamma=-0.318683398 at q=1/4.
This latter result cannot serve as positive calibrated G. These are linear
combinations of separate force measurements, not a simultaneous four-body
model with cross-interactions omitted. Overall positive masses can be made
small while preserving the ratios; body equilibrium and an actual apparatus
remain unconstructed. No negative physical charges were introduced.

For positive gamma_cal<=(1+eta)*gamma_obs, eta>=0, positivity of gamma_obs
is itself necessary. Substitution and q<1/3 give the strict upper envelope
(1+eta)*(kappa+7)/6. The assumed eta bounds the complete response/readout
approximation; signed cancellation can amplify errors and does not establish
that premise. Laboratory statistical uncertainty supplies no eta. A different
cosmological environment leaves the local/cosmic conformal-factor ratio.

## Thermal consequence, honest reuse and limits

Only the sealed joint premise P_bare>2*exp(2N)/(R*sigma^(4/3)) is reused,
with its same selected total bath, ideal equilibrium matter, entropy ratio,
strict Einstein bounce and regular physical endpoint hypotheses. Division by
the positive calibration ceiling gives exactly

    P_cal > 12*exp(2N)/[R*sigma^(4/3)*(1+eta)*(kappa_geom+7)].

For positive geometry this is the source's 3/(2R) coefficient. With N>=0,
sigma=1, eta=0 and a positive unit target, the inclusive sufficient obstruction
is kappa_geom<=12/R-7=1.565190266043298..., for R=(11/4)^(1/3).
Equality is excluded by the strict lower bound. N retains the reused theorem's
Einstein-radius definition; kappa_geom denotes readout cancellation, not spatial
curvature. Larger kappa only removes this sufficient obstruction. It constructs
neither a thermal history nor a fitted experiment. No new thermodynamics,
background matching, entropy mechanism or empirical exclusion was inferred.

## Actual runs and final source confirmation

check_geometry_v1.py has SHA-256
201956847d1a3bdf5e72ef4ddee2f8c32722fd686744cdba05525265dd0ebf09.
The baseline ran at 2026-10-14T12:43:42.718562Z to 12:43:43.170772Z,
using Python 3.12.8, SymPy 1.14.0, NumPy 2.4.1 and mpmath 1.3.0.
Exact argv, cwd, UTC intervals, code/output hashes and exits are preserved.

| Actual one-edit damage | Pass / fail | Intended failure |
| --- | --- | --- |
| Delete pair-gradient z term | 68 / 8 | potential derivative and direct force |
| Omit test-sphere factor | 71 / 5 | direct sphere and signed-configuration forces |
| Use one-sign ceiling for signed readout | 72 / 4 | signed algebra and explicit finite-body witness |
| Omit physical mass conversion | 75 / 1 | physical normalization |
| Multiply by calibrated gamma | 74 / 2 | positive conversion and thermal coefficient |
| Admit overlap to exterior formula | 75 / 1 | nonoverlap domain |

All six children exited 1. Scripts, exact diffs, complete outputs and required
failed identities are retained. No unexpected checker, tool or evidence failure
occurred in this unit. A preliminary combined dependency read was truncated
in display; the complete joint source/report was then read separately and the
frozen files retain all text. The prior units' actual failures remain preserved
through their original report/receipt lineage, not relabeled as clean reruns.

The same reviewer confirms the v2 author source and protocol are unchanged from
the frozen inputs. SOURCE_CORRESPONDENCE_v1.json maps the complete claim scope.
The manifest binds every new artifact except itself and the receipt; the receipt
binds the manifest, report, sources, failures, executions and dependency reuse.
All new writes are confined to this independent unit. No prior seal, author
source, Git state, runtime/lock, PR, audit, other chat or authority was changed.
