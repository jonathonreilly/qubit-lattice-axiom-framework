from pathlib import Path
import datetime
import difflib
import hashlib
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
source=HERE/'check_geometry_v1.py'
original=source.read_text()
folder=HERE/'damages';folder.mkdir(exist_ok=False)
specs=[
    ('missing_pair_gradient','PAIR_LINEAR_TERM = 1','PAIR_LINEAR_TERM = 0',
     ['pair_potential_derivative','pair_kernel_derivative','sphere_direct_vs_formula_0']),
    ('missing_test_body','TEST_SPHERE_POWER = 1','TEST_SPHERE_POWER = 0',
     ['sphere_direct_vs_formula_0','signed_near_direct_force']),
    ('signed_positive_ceiling','USE_POSITIVE_CEILING_FOR_SIGNED = False','USE_POSITIVE_CEILING_FOR_SIGNED = True',
     ['signed_upper_formula','finite_signed_tight_upper']),
    ('missing_mass_conversion','PHYSICAL_MASS_A_POWER = 1','PHYSICAL_MASS_A_POWER = 0',
     ['physical_mass_radius_normalization']),
    ('calibration_multiply','CALIBRATION_GAMMA_POWER = -1','CALIBRATION_GAMMA_POWER = 1',
     ['positive_calibration_division','geometry_thermal_coefficient']),
    ('overlap_admitted','ALLOW_OVERLAPPING_SPHERES = False','ALLOW_OVERLAPPING_SPHERES = True',
     ['overlap_rejected'])]
plan=[]
for name,old,new,required in specs:
    if original.count(old)!=1: raise RuntimeError('mutation target is not unique: '+name)
    script=folder/(name+'_v1.py');script.write_text(original.replace(old,new))
    diff=folder/(name+'_v1.diff')
    diff.write_text(''.join(difflib.unified_diff(original.splitlines(True),script.read_text().splitlines(True),fromfile=source.name,tofile=str(script.relative_to(HERE)))))
    plan.append({'name':name,'script':str(script.relative_to(HERE)),
                 'sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
                 'diff':str(diff.relative_to(HERE)),'old':old,'new':new,
                 'required_failed_checks':required,'expected_exit':1})
(HERE/'MUTATION_PROTOCOL_v1.json').write_text(json.dumps({
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseline_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'actual_one_edit_damages':plan},indent=2)+'\n')
results=[]
for row in plan:
    label='damage_'+row['name'];output='damages/'+row['name']+'_results_v1.json'
    argv=[sys.executable,'-B','run_logged_v1.py',label,sys.executable,'-B',row['script'],'--output',output]
    process=subprocess.run(argv,cwd=HERE,capture_output=True)
    launch_stdout=folder/(row['name']+'_wrapper_stdout_v1.txt')
    launch_stderr=folder/(row['name']+'_wrapper_stderr_v1.txt')
    launch_stdout.write_bytes(process.stdout);launch_stderr.write_bytes(process.stderr)
    result_path=HERE/output
    data=json.loads(result_path.read_text()) if result_path.exists() else None
    failed=[item['name'] for item in data['checks'] if not item['ok']] if data else []
    intended=process.returncode==1 and set(row['required_failed_checks'])<=set(failed)
    item={**row,'wrapper_argv':argv,'actual_exit':process.returncode,
          'result':output,'record':label+'_run_v1.json',
          'pass':data['pass'] if data else None,'fail':data['fail'] if data else None,
          'failed_checks':failed,'intended_failures_detected':intended,
          'wrapper_stdout':str(launch_stdout.relative_to(HERE)),
          'wrapper_stderr':str(launch_stderr.relative_to(HERE))}
    results.append(item)
    print(json.dumps({'name':row['name'],'exit':process.returncode,
                      'pass':item['pass'],'fail':item['fail'],
                      'intended_failures_detected':intended,'failed_checks':failed}))
(HERE/'MUTATION_RESULTS_v1.json').write_text(json.dumps({
    'runs':results,'all_intended_failures_detected':all(r['intended_failures_detected'] for r in results)},indent=2)+'\n')
raise SystemExit(0 if all(r['intended_failures_detected'] for r in results) else 1)
