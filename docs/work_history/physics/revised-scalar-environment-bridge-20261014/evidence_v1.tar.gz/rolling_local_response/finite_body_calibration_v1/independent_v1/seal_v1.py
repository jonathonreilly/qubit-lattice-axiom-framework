from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((HERE/name).read_text())
def bind(name):
    path=HERE/name
    return {'path':name,'bytes':path.stat().st_size,'sha256':sha(path)}
def write(name,data):
    path=HERE/name
    if path.exists(): raise RuntimeError('refusing overwrite: '+name)
    path.write_text(json.dumps(data,indent=2)+'\n')
for name in ['FINAL_SOURCE_CONFIRMATION_v1.json','FAILURES_v1.json',
             'SEAL_VALIDATION_v1.json','MANIFEST_v1.json','RECEIPT_v1.json']:
    if (HERE/name).exists(): raise RuntimeError('seal output already exists: '+name)
checks=[]
def check(name,condition,details): checks.append({'name':name,'ok':bool(condition),'details':details})
def identity(path,row): return path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
sources=read('SOURCE_BINDINGS_v1.json')['source_pairs']
report_text=(HERE/'REPORT_v1.md').read_text()
for row in sources:
    check('source_pair_'+row['snapshot_path'],identity(Path(row['original_path']),row) and identity(HERE/row['snapshot_path'],row),row)
    check('report_hash_'+row['snapshot_path'],row['sha256'] in report_text,row['sha256'])
base=read('BASELINE_RESULTS_v1.json');mutations=read('MUTATION_RESULTS_v1.json')['runs']
validation=read('EVIDENCE_VALIDATION_v1.json')
check('baseline_76_0',base['pass']==76 and base['fail']==0,base['categories'])
check('evidence_169_0',validation['pass']==169 and validation['fail']==0,{'pass':validation['pass'],'fail':validation['fail']})
check('six_actual_damages',len(mutations)==6 and all(row['intended_failures_detected'] and row['actual_exit']==1 for row in mutations),[{'name':r['name'],'pass':r['pass'],'fail':r['fail'],'exit':r['actual_exit']} for r in mutations])
records=[('baseline_run_v1.json',0),('mutation_batch_run_v1.json',0),('evidence_validation_run_v1.json',0)]+[(r['record'],1) for r in mutations]
for name,expected in records:
    record=read(name)
    check(name+'_exit',record['child_exit_code']==expected,record['child_exit_code'])
    for row in record['scripts']+[record['stdout'],record['stderr']]:
        check(name+'_binding_'+row['path'],identity(HERE/row['path'],row),row)
correction=read('REPORT_DRAFT_CORRECTION_v1.json')
check('preserved_unsealed_report_draft',sha(HERE/correction['original_draft'])==correction['original_sha256'],correction['original_sha256'])
check('corrected_report_binding',sha(HERE/correction['corrected_report'])==correction['corrected_report_sha256'],correction['corrected_report_sha256'])
check('report_correction_matches_source',correction['correct_source_hash']==sources[0]['sha256'],correction['correct_source_hash'])
check('no_symlinks',not any(p.is_symlink() for p in HERE.rglob('*')),'all new artifacts')
if not all(r['ok'] for r in checks):
    write('SEAL_FAILURE_v1.json',{'checks':checks})
    raise RuntimeError('seal identity failure preserved')

now=datetime.datetime.now(datetime.timezone.utc).isoformat()
write('FINAL_SOURCE_CONFIRMATION_v1.json',{
    'created_utc':now,'original_reviewer':'/root/local_response_check',
    'source_pairs':sources,'all_match':True,'author_source_correction_required':False,
    'source_correspondence':bind('SOURCE_CORRESPONDENCE_v1.json'),
    'conclusion':'The complete v2 theorem and conditional thermal substitution are supported under explicit frozen weak-response, geometry and calibration hypotheses. No actual instrument or cosmological application is established.',
    'scope':'Final unchanged-source confirmation, not a formal audit or status promotion'})
write('FAILURES_v1.json',{
    'unexpected_tool_or_checker_failures':[],
    'expected_actual_damaged_runs':mutations,
    'editorial_correction':correction,
    'display_truncation':'Initial combined old-report/receipt output was shortened; full joint source/report was subsequently read separately and all bound source bytes retained.',
    'prior_failure_lineage':'Original gravity and joint thermal reports/receipts retain prior timeouts, corrections and wrapper failures. No prior science was rerun or relabeled.'})
write('SEAL_VALIDATION_v1.json',{'pass':sum(r['ok'] for r in checks),'fail':sum(not r['ok'] for r in checks),'checks':checks,
      'scope':'Final source, artifact and recorded-exit identities only; no new science execution'})
artifacts=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file() and path.name not in ['MANIFEST_v1.json','RECEIPT_v1.json']:
        artifacts.append(bind(str(path.relative_to(HERE))))
write('MANIFEST_v1.json',{'created_utc':now,'unit':str(HERE),'artifact_count':len(artifacts),
      'artifacts':artifacts,'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],
      'immutable_after_seal':True})
receipt={
    'created_utc':now,'type':'focused_independent_finite_body_geometry_check',
    'checker':'/root/local_response_check','direct_scientific_author':'/root',
    'unit':str(HERE),'report':bind('REPORT_v1.md'),'manifest':bind('MANIFEST_v1.json'),
    'artifact_count':len(artifacts),'live_source_pair_count':len(sources),'source_pairs':sources,
    'new_science':{'pass':76,'fail':0,'categories':base['categories'],
                   'result':bind('BASELINE_RESULTS_v1.json'),'command':bind('baseline_run_v1.json')},
    'actual_damaged_copies':mutations,'failure_ledger':bind('FAILURES_v1.json'),
    'unexpected_tool_or_checker_failures':[],
    'editorial_correction':bind('REPORT_DRAFT_CORRECTION_v1.json'),
    'metadata':{'validation_pass':169,'validation_fail':0,
                'validation':bind('EVIDENCE_VALIDATION_v1.json'),
                'seal_pass':len(checks),'seal_fail':0,
                'seal_validation':bind('SEAL_VALIDATION_v1.json'),'science_rerun':False},
    'reused_gravity':{'report':bind('sources/gravity_REPORT_v1.txt'),
                      'receipt':bind('sources/gravity_RECEIPT_v1.json'),
                      'original_count':'81/0 plus separately recorded corrected-source confirmation',
                      'scope':'Physical weak-response normalization and applicability limits only',
                      'full_old_unit_rehashed':False,'science_rerun':False,'added_to_new_count':False},
    'reused_joint_thermal':{'source':bind('sources/joint_DERIVATION_v1.md'),
                           'report':bind('sources/joint_REPORT_v1.md'),
                           'receipt':bind('sources/joint_RECEIPT_v1.json'),
                           'manifest':bind('sources/joint_MANIFEST_v1.json'),
                           'old_science_count':'64/0','artifacts_hash_verified':79,
                           'source_pairs_hash_verified':6,'science_rerun':False,
                           'added_to_new_count':False,
                           'reused_statement':'P_bare>2 exp(2N)/(R sigma^(4/3)), with its complete same-bath, entropy, strict-bounce and endpoint hypotheses'},
    'original_reviewer_final_confirmation':bind('FINAL_SOURCE_CONFIRMATION_v1.json'),
    'commands':bind('COMMANDS_v1.json'),'initial_read_commands':bind('INITIAL_READ_COMMANDS_v1.json'),
    'seal_command':{'argv':[sys.executable,'-B',str(Path(__file__).resolve())],
                    'cwd':str(HERE),'script_sha256':sha(Path(__file__).resolve()),
                    'scope':'Final identity verification and seal serialization; no new science run'},
    'representative_results':{'sphere_controls':base['sphere_controls'],
                              'signed_finite_body':base['signed_finite_body'],
                              'thermal_kappa_threshold':base['thermal_threshold']},
    'bounded_conclusion':'The finite-body one-sign ceiling, separated homogeneous-sphere product, tighter signed bounds and conditional thermal conversion are correct on the stated domain. No author-source amendment is required.',
    'limitations':['Positive self-adjoint static mass spectrum, weak/frozen sourced response and a common finite background are premises, not an established actual body solution.',
                   'Masses, profiles, radii and scalar ranges must use compatible physical units; profiles and real linear readout weights are fixed.',
                   'Homogeneous exterior sphere formula requires d>Rs+Rt; arbitrary positive profiles use the measure bound, not the same S formula.',
                   'Signed cancellation can exceed the point ceiling or produce negative gamma; a positive calibrated response and separately justified aggregate eta remain required.',
                   'Laboratory measurement uncertainty is not eta, and a distinct cosmological background leaves a conformal ratio.',
                   'Thermal result reuses the same selected ideal bath and strict Einstein-bounce theorem; no history, entropy mechanism, apparatus fit or empirical exclusion is constructed.',
                   'Numerical quadrature agreement is corroboration, not a rigorous numerical enclosure or a universal domain proof.'],
    'producer_current_code_results_accessed':False,'writes_confined_to_unit':True,
    'prior_seals_unchanged':True,'git_runtime_settings_pr_audit_or_authority_changed':False,
    'formal_audit':False,'immutable_after_seal':True}
write('RECEIPT_v1.json',receipt)
for row in artifacts:
    if not identity(HERE/row['path'],row): raise RuntimeError('postseal artifact mismatch: '+row['path'])
if sha(HERE/'MANIFEST_v1.json')!=receipt['manifest']['sha256']:
    raise RuntimeError('postseal manifest mismatch')
print(json.dumps({'created_utc':now,'artifact_count':len(artifacts),'source_pairs':len(sources),
      'report':bind('REPORT_v1.md'),'manifest':bind('MANIFEST_v1.json'),'receipt':bind('RECEIPT_v1.json'),
      'seal_metadata_pass':len(checks),'postseal_identity':'all artifacts and receipt-bound manifest verified; no further writes'},indent=2))
