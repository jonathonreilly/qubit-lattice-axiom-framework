from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[6]
checks=[]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((HERE/name).read_text())
def check(name,condition,details): checks.append({'name':name,'ok':bool(condition),'details':details})
def identity(path,row):
    return path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
sources=read('SOURCE_BINDINGS_v1.json')['source_pairs']
for row in sources:
    check('live_'+row['snapshot_path'],identity(Path(row['original_path']),row),row['original_path'])
    check('snapshot_'+row['snapshot_path'],identity(HERE/row['snapshot_path'],row),row['snapshot_path'])
protocol=read('sources/PROTOCOL_v2.json')
check('source_protocol_hash',protocol['source_sha256']==sha(HERE/'sources/DERIVATION_v2.md'),protocol['source_sha256'])
for row in read('HAND_PROTOCOL_FREEZE_v1.json')['artifacts']:
    check('pre_code_'+row['path'],identity(HERE/row['path'],row),row)
helper=read('HAND_PROTOCOL_FREEZE_v1.json')
check('reused_process_helper_identity',sha(Path(helper['process_helper_reused_from']))==helper['process_helper_sha256']==sha(HERE/'run_logged_v1.py'),helper['process_helper_sha256'])
base=read('BASELINE_RESULTS_v1.json')
check('baseline_76_0',base['pass']==76 and base['fail']==0 and all(r['ok'] for r in base['checks']),base['categories'])
mutations=read('MUTATION_RESULTS_v1.json')['runs']
records=[('baseline_run_v1.json',0),('mutation_batch_run_v1.json',0)]
for mutation in mutations:
    records.append((mutation['record'],1))
    result=read(mutation['result'])
    failed=[r['name'] for r in result['checks'] if not r['ok']]
    check('mutation_intended_'+mutation['name'],mutation['actual_exit']==1 and set(mutation['required_failed_checks'])<=set(failed),failed)
    check('mutation_bytes_'+mutation['name'],sha(HERE/mutation['script'])==mutation['sha256'],mutation['sha256'])
    original=(HERE/'check_geometry_v1.py').read_text()
    check('mutation_single_edit_'+mutation['name'],original.count(mutation['old'])==1 and (HERE/mutation['script']).read_text()==original.replace(mutation['old'],mutation['new']),[mutation['old'],mutation['new']])
for name,expected_exit in records:
    row=read(name)
    check(name+'_exit',row['child_exit_code']==expected_exit,row['child_exit_code'])
    for bound in row['scripts']+[row['stdout'],row['stderr']]:
        check(name+'_binding_'+bound['path'],identity(HERE/bound['path'],bound),bound)

gravity=read('sources/gravity_RECEIPT_v1.json')
check('gravity_reused_report',identity(HERE/'sources/gravity_REPORT_v1.txt',gravity['report']),gravity['report'])
joint=read('sources/joint_RECEIPT_v1.json')
check('joint_named_receipt',sha(HERE/'sources/joint_RECEIPT_v1.json')=='7210514677660e0142b1378b68cbf20bee856153a10c2701d24aa48a0556cb00',sha(HERE/'sources/joint_RECEIPT_v1.json'))
check('joint_reused_report',identity(HERE/'sources/joint_REPORT_v1.md',joint['report']),joint['report'])
check('joint_reused_manifest',identity(HERE/'sources/joint_MANIFEST_v1.json',joint['manifest']),joint['manifest'])
check('joint_final_source',sha(HERE/'sources/joint_DERIVATION_v1.md')==joint['final_source_sha256'],joint['final_source_sha256'])
joint_root=Path(next(r['original_path'] for r in sources if r['snapshot_path']=='sources/joint_RECEIPT_v1.json')).parent
manifest=read('sources/joint_MANIFEST_v1.json')
check('joint_manifest_count',len(manifest['artifacts'])==joint['artifact_count']==79,len(manifest['artifacts']))
for bound in manifest['artifacts']:
    rel=Path(bound['path'])
    safe=not rel.is_absolute() and '..' not in rel.parts
    check('joint_artifact_'+bound['path'],safe and identity(joint_root/rel,bound),bound)
for row in joint['source_bindings']:
    check('joint_original_source_'+row['snapshot_path'],identity(ROOT/row['original_path'],row),row['original_path'])
    check('joint_snapshot_source_'+row['snapshot_path'],identity(joint_root/row['snapshot_path'],row),row['snapshot_path'])
check('no_symlinks_in_new_unit',not any(p.is_symlink() for p in HERE.rglob('*')),'new unit only')
out={'pass':sum(r['ok'] for r in checks),'fail':sum(not r['ok'] for r in checks),'checks':checks,
     'reused_joint_artifacts_verified':79,'reused_joint_source_pairs_verified':6,
     'reused_gravity_scope':'report and receipt binding only; no full gravity-unit rehash',
     'scope':'Hash and expected execution verification only; no new geometry, gravity or thermal computation'}
target=HERE/'EVIDENCE_VALIDATION_v1.json'
if target.exists(): raise RuntimeError('refusing overwrite')
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['pass','fail','reused_joint_artifacts_verified','reused_joint_source_pairs_verified','reused_gravity_scope','scope']},indent=2))
for row in checks:
    if not row['ok']: print('FAILED',row['name'],row['details'])
raise SystemExit(0 if not out['fail'] else 1)
