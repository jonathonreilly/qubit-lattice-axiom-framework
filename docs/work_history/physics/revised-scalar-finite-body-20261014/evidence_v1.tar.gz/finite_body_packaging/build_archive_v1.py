from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'finite_body_packaging';dest=wt/'docs/work_history/physics/revised-scalar-finite-body-20261014'
roots=['rolling_local_response/finite_body_excursion_v1','finite_body_canonical_correspondence_v1','finite_body_packaging']
seal_units=['rolling_local_response/finite_body_excursion_v1/independent_v1','rolling_local_response/finite_body_excursion_v1/independent_surface_v1','rolling_local_response/finite_body_excursion_v1/independent_uniqueness_v1','finite_body_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional finite held-body excursion, radial surface force, uniqueness and scalar-only stability. No measured environment or full metric realization.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="Recovery evidence for the finite held-body scalar derivation\n\nLive claim: docs/EXPONENTIAL_SCALAR_FINITE_BODY_BOUNDED_THEOREM_NOTE_2026-10-14.md\nScientific author: /root. Conditional support, no formal audit or main merge.\nArchive SHA256: {sha}\nArchive bytes: {size}\nPayloads: {count} plus RECOVERY_MANIFEST_v1.json\nInternal manifest SHA256: {msha}\n\nThe prescribed flat static source equation supplies field-excursion bounds,\na radial uniform-sphere surface-force bracket, and sufficient uniqueness and\nscalar-only linear stability under a proved convexity criterion. No thin-shell\nfactor, interior density root or observed body charge is selected. The particle\nsource, zero boundary, approximation and inherited action remain premises.\n\nCanonical490/0=220 excursion+172 surface+98 uniqueness. Complete scientific\nresults match the staged source; all54 staged profiles match the original18\nsolutions/Hessian samples/convexity samples byte for byte. The live cache's\n20 temporary input paths are historical after cleanup, with exact recoveries\nin finite_body_packaging/CACHE_TEMP_SOURCE_RECOVERY_v1.json. They are not live\nfiles. Full cache stdout and execution record are included; Git preserves the\nfull cache header. The live cache shares merged stderr/stdout helper semantics.\n\nOriginal independent598/0+22/0 affected excursion,1735/0 surface and641/0\nuniqueness are reused, with5,7,7 actual damaged programs respectively. The\nuniqueness check was independent in method but not fully blind: aggregate98/0\nmetadata exposure is preserved. Staged1524/0 correspondence+266/0 uniqueness\nreuse+141/0 wrapper+821/0 closure are packaging counts. Three actual full\nstaged damages yielded487/3,486/4,486/4. Three altered wrapper controls failed.\n\nFailures remain: NumPy-boolean serialization,216/4 flux mismatch,219/1 mesh\nlimit, the exact rescaling repair, hand-proof decay gap and repair, radial\nqualification, uniqueness metadata exposure, and parent absolute/relative\npath mismatch. The corpus preserves all original versions, profiles, streams,\nsource diffs and checked source inventories. Figure drafts/caption repairs\nand final visual QA are retained. Khoury-Weltman2004 is exposed mechanism\ncontext, not a borrowed shell prescription or an observational fit.\n\nThe bounds normalize to held Einstein source mass, not measured Jordan mass.\nZero surface lower bounds are uninformative. Exterior force can decrease.\nThe scalar stability theorem holds matter and metric fixed, not moving\nmaterial, nonlinear relaxation or a realized Solar environment. Samples do\nnot certify continuum numerical errors. Action, parameters, state and scales\nremain supplied. The later canonical-envelope refinement is not in this unit.\n\nSafe extraction: regular relative members only, verify every manifest hash\nand size. Later build/commit/delivery/UNIT records are outside this archive.\nIndependent source and staged-correspondence identities:\n{refs}\n".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
