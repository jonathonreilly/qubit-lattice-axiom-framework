from pathlib import Path
import json,hashlib,subprocess,datetime,time
wt=Path.cwd(); out=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/finite_history_packaging/canonical_damages_v1';out.mkdir(exist_ok=False)
p=wt/'scripts/exponential_scalar_finite_history_check.py'; src=p.read_text(); (out/'original_source.py').write_text(src)
variants=[
 ('extra_radial_vacuum_force','-2*WQ/(BB*HB)','-2*(WQ+EE*ZZ*Uzero)/(BB*HB)'),
 ('missing_eta_connection','-EE*QQ**2/(DD+EE)',''),
 ('reversed_eta_flow','-2*QQ*EE],HB,hh','2*QQ*EE],HB,hh'),
 ('hidden_cubic_force','-(3+hh)*PP-At*PP**2','PP**3-(3+hh)*PP-At*PP**2'),
 ('missing_finite_metric','B = Binf/(1+eta/d)','B = Binf'),
 ('reversed_potential_gradient','u01=mp.diff(lambda tt:fields(tt)[3],t)','u01=-mp.diff(lambda tt:fields(tt)[3],t)'),
 ('missing_clock_term','hJ=(hE+LD/L-(L-1))/L','hJ=(hE+LD/L)/L'),
 ('wrong_tangent_resolvent','mp.lu_solve(4*mp.eye(4)-MM,forcing)','mp.lu_solve(4*mp.eye(4)+MM,forcing)'),
 ('double_u_potential','+nv*(1+sv)*uu**2/(2*ff**2)','+2*nv*(1+sv)*uu**2/(2*ff**2)')]
records=[]
for name,old,new in variants:
 assert src.count(old)==1,(name,src.count(old))
 d=out/name;d.mkdir(); f=d/'damaged.py';f.write_text(src.replace(old,new));cmd=['/usr/local/bin/python3',str(f)]
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(cmd,cwd=wt,capture_output=True,text=True,timeout=120)
 (d/'stdout.json').write_text(r.stdout);(d/'stderr.txt').write_text(r.stderr)
 try: data=json.loads(r.stdout); counts=data['counts']; failures=[x['name'] for x in data['checks'] if not x['passed']]
 except Exception:counts=None;failures=[]
 rec=dict(name=name,started_at=start,command=cmd,cwd=str(wt),timeout_seconds=120,elapsed_seconds=time.monotonic()-t,source_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),exit_code=r.returncode,counts=counts,failed_witnesses=failures,rejected=bool(r.returncode and counts and counts['failed']))
 (d/'RUN.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec)
 print(name,r.returncode,counts,flush=True)
result=dict(original_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),actual_damages=records,all_rejected=all(x['rejected'] for x in records))
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(not result['all_rejected'])
