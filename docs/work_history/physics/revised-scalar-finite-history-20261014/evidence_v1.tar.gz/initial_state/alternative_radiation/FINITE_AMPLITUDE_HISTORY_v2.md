# Finite amplitude, past regularity and the alternative radiation state

Density convention: rho_phys denotes dimensionful physical density. In the
canonical complete-action note rho_J is dimensionless, with
rho_phys=rho_unit rho_J and Rstar=rho_unit/(2Q Hv^2). Consequently
 y_b^2=rho_phys/(2Q Hv^2)=Rstar rho_J.
The earlier same-symbol usage in this route is clarified here; no density
normalization is inferred from observations.

Direct author /root. Hand derivation frozen before its new checker. The
alternative radiation branch is motivated by an expanding radiation regime;
the exact observed history and measured gravity environment remain open.
This note investigates whether its local limiting attraction supplies the
missing initial state. It assumes the same complete action and ideal
radiation as DERIVATION_v2.md, with 0<k<3-2sqrt(2). Nothing here derives that
action, radiation composition or a rule selecting a past boundary.

Work first in the invariant y=0 chart and one sign of x. Put
eta=1/x^2, theta=2alpha(u-u_x), ell=log|x|, z=log(|x|/(beta_x y_b)),
p=theta', q=ell', d=2(1+k)/3 and l=2/(1+3k). The full, finite-amplitude
metric in this chart is

    A(theta) dtheta^2+B(theta,eta) dell^2,
    A=J/(4a F^2), B=B_infinity(theta)/(1+eta/d),
    B_infinity=(1+s)2k/[3(1+k)F].

Let U0(u) be the full action's part of U independent of x,y:

    U0=3/2+(3/2)s(E-1)^2/F^2+nu(1+s)u^2/(2F^2).

Write Wq=W_x exp(2z-l theta), Z=beta_x^2 exp(2z) and
W=Wq+eta Z U0. Then Hbar=2(C^2+W)/(3-T), T=A p^2+B q^2 and
h=-4C^2/(3Hbar)-T. Here W is U/y_b^2, but its physical ell derivative at
fixed u and radiation is (partial_z-2eta partial_eta)W=2Wq. It is not 2W.
The exact finite-amplitude ideal-radiation flow in this chart is

    theta'=p, z'=q+2+p/F, eta'=-2q eta,
    p'=-(3+h)p-A_theta p^2/(2A)+B_theta q^2/(2A)
       +(l Wq-eta Z U0_theta)/(A Hbar),
    q'=-(3+h)q-(B_theta/B)pq-eta q^2/(d+eta)-2Wq/(B Hbar).

The extra connection term follows from
Gamma^ell_ell,ell=(partial_ell B)/(2B)=eta/(d+eta).
In particular, simply inserting the full potential into the old reduced
ell force would produce an incorrect flow.

At eta=0 the point is (theta,z,p,q)=(0,0,0,-2). Let M be the previously
derived four-dimensional Jacobian and define at that point

    b=B_infinity(0), A0=A(0), r=1/(1+3k), D=3-4b,
    v0=beta_x^2 U0(u_x)/Hbar_x,
    v1=beta_x^2 U0_theta(u_x)/Hbar_x,
    j=(2v0-4b/d)/D.

The first-order finite-amplitude forcing on X=(theta,z,p,q+2) is

    X'=M X+f eta+O((|X|+|eta|)^2),
    f=(0,0,[2r b(1/d-j)-v1]/A0,4v0-6/d).

The full five-dimensional linearization is block triangular with M, f,
zero lower-left row and lower-right entry +4. Including the independently
stable y/x perturbations adds two stable eigenvalues. Thus the ideal point
in the extended seven-state finite-amplitude system is a hyperbolic saddle,
with six stable and one unstable direction. This differs from, and does not
contradict, attraction inside the large-field limiting six-state system.

For a smooth trajectory approaching this point as N goes to minus infinity,
its leading tangent must be

    X=h1 eta+O(eta^2), (4I-M)h1=f.

Since M is Hurwitz, 4I-M is invertible. The local unstable-manifold theorem
would give one smooth local past-bounded branch for each sign chart, up to
time translation, within these supplied equations. The symmetry-invariant
y=0 set contains this unstable direction. This conditional boundary rule
is NOT a derivation of the actual initial state: requiring convergence to
this particular past point is an additional premise, and neither data nor
the action has selected it. More general finite-duration histories retain
homogeneous deviations and need not lie on this curve. Exact manifold
existence/uniqueness is to be checked separately from the tangent algebra.

Moreover, bounded normalized variables do not mean a bounded physical past.
Using y_b^2=1/(beta_x^2 eta exp(2z)) gives along such a branch

    H_E^2/Hv^2 ~ Hbar_x/(beta_x^2 eta),
    rho_phys ~ 2Q Hv^2/(beta_x^2 eta), eta' ~ 4eta.

Einstein and physical proper time to eta=0 are finite, while H_E,H_J and
the radiation density diverge. For a spatially flat FLRW metric the
Kretschmann scalar is 12[H^4+(H^2+dot H)^2]; h tends to -2, so it diverges
as 24H^4, even though the leading Ricci scalar vanishes in a radiation
scaling limit. This route does not supply a nonsingular bounded history or
justify extending the classical action to arbitrarily high curvature.

Finally, eta grows by exp(4 Delta N) to leading order. Combined with the
previous weak-k slow eigenvalue -(16/5)k+O(k^2), one e-fold of slow-component
decay in the constant limiting model takes Delta N~5/(16k), during which
the requisite radiation-density contrast is exp[5/(4k)] to leading order.
This is a conditional asymptotic scaling comparison, not a controlled
full-history extrapolation over that duration or an observed erasure bound.
It emphasizes the need for a finite regime and actual history before local
attraction can be credited with state selection.

No new data, parameter fit or independent empirical test was used. The new
checker must derive the finite metric/forces from the original action,
verify the forcing and +4 eigenvalue, test real damaged equations and keep
all intermediate failures. These claims are presently parent derivations,
not yet independently checked or included in a reviewable science PR.

This version preserves all equations with the explicit density-symbol
translation above. Earlier source versions and execution receipts remain
unchanged; unchanged calculations are reused, not claimed as new runs.
