"""Freeze sources and verify previously sealed evidence; no science rerun."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,sys
H=Path(__file__).resolve().parent
R=H.parents[6]
PK=R/".claude/science/physics-loops/revised-scalar-derivation-24h-20261013"
ALT=PK/"initial_state/alternative_radiation"
OLD=ALT/"finite_history_independent_v1"
PACK=PK/"finite_history_packaging"
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,v):(H/n).write_text(json.dumps(v,indent=2)+"\n")
source_map=[
(R/"docs/EXPONENTIAL_SCALAR_FINITE_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-14.md","canonical_note.md"),
(R/"scripts/exponential_scalar_finite_history_check.py","canonical_runner.py"),
(R/"logs/runner-cache/exponential_scalar_finite_history_check.txt","canonical_cache.txt"),
(R/"docs/EXPONENTIAL_SCALAR_ALTERNATIVE_RADIATION_BOUNDED_THEOREM_NOTE_2026-10-14.md","companion_note.md"),
(R/"docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md","original_action_note.md"),
(R/"scripts/runner_cache.py","runner_cache_implementation.py"),
(R/"docs/ai_methodology/SCIENCE_WORKFLOW.md","SCIENCE_WORKFLOW.md"),
(ALT/"FINITE_AMPLITUDE_HISTORY_v1.md","discovery_v1.md"),
(ALT/"FINITE_AMPLITUDE_HISTORY_v2.md","discovery_v2.md")
]
for n in ["REPORT_v1.txt","HAND_DERIVATION_v1.txt","RECEIPT_v1.json","MANIFEST_v1.json","check_finite_history_v1.py",
"RUN_03_INDEPENDENT_ACTION.json","RUN_03_INDEPENDENT_ACTION.stdout.txt","RUN_05_DENSITY_V2_CORRESPONDENCE.json",
"RUN_05_DENSITY_V2_CORRESPONDENCE.stdout.txt","SOURCE_V1_V2_INDEPENDENT.diff","MUTATION_RECEIPT_v1.json"]:
    source_map.append((OLD/n,"original_independent/"+n))
for n in ["REPORT_v1.txt","RECEIPT_v1.json","MANIFEST_v1.json"]:
    source_map.append((ALT/"independent_v1"/n,"alternative_independent/"+n))
for n in ["PRIMARY_RUN_v1.json","PRIMARY_v1.stdout.json","PRIMARY_v1.stderr.txt","canonical_runner_before_binding_v1.py",
"PRIMARY_RUN_v2.json","PRIMARY_v2.stdout.json","PRIMARY_v2.stderr.txt","CACHE_RUN_v1.json",
"CANONICAL_BINDING_EXTENSION_v2.json","run_canonical_damages_v1.py"]:
    source_map.append((PACK/n,"parent_packaging/"+n))
for p in sorted((PACK/"canonical_damages_v1").rglob("*")):
    if p.is_file():source_map.append((p,"parent_packaging/canonical_damages_v1/"+str(p.relative_to(PACK/"canonical_damages_v1"))))
pairs=[]
for p,n in source_map:
    b=p.read_bytes();snap=H/"sources"/n
    assert not snap.exists(),snap
    snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(b)
    pairs.append({"original_path":str(p),"snapshot":str(snap.relative_to(H)),"sha256":sha(b),"bytes":len(b)})
reused=[]
for p in [OLD/"MANIFEST_v1.json",ALT/"independent_v1/MANIFEST_v1.json",PK/"rolling_local_response/second_rate_independent_v1/MANIFEST_v1.json"]:
    m=json.loads(p.read_text())
    for a in m["artifacts"]:
        b=(p.parent/a["path"]).read_bytes()
        assert sha(b)==a["sha256"] and len(b)==a["bytes"],a
    reused.append({"manifest":str(p),"sha256":sha(p.read_bytes()),"artifact_count":len(m["artifacts"]),"rerun":False})
save("SOURCE_BINDINGS_v1.json",{"at_utc":datetime.now(timezone.utc).isoformat(),"sources":pairs,"source_count":len(pairs),"prior_seals_verified":reused,
"instructions":"Reused previously read origin/ai/execution:AGENTS.md and full supplied SCIENCE_WORKFLOW; read-only mathematical/source correspondence, no formal audit or authority/status promotion.",
"scope":"All new writes in this folder; no Git/network/PR/runtime action. Producer source can be inspected and narrowly tested; prior science outputs are reused without rerun."})
print(json.dumps({"source_count":len(pairs),"prior_seals":reused},indent=2))

