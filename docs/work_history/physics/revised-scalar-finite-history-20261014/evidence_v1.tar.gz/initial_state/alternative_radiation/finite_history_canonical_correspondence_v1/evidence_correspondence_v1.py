"""Source/cache/evidence mapping and original-reviewer confirmation, no science rerun."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,difflib,sys
H=Path(__file__).resolve().parent
R=H.parents[6]
PK=R/".claude/science/physics-loops/revised-scalar-derivation-24h-20261013"
ALT=PK/"initial_state/alternative_radiation";PACK=PK/"finite_history_packaging"
def sha(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text())
def save(p,v):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+"\n")
def snap(p,relative):
    b=p.read_bytes();d=H/relative;assert not d.exists(),d
    d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
    return {"original_path":str(p),"snapshot":relative,"sha256":sha(b),"bytes":len(b)}
rows=[]
def ck(n,ok,d=None):rows.append({"name":n,"passed":bool(ok),"detail":d})
initial=readj(H/"SOURCE_BINDINGS_v1.json")
pairs=initial["sources"].copy()
for a in pairs:ck("frozen_source_"+a["snapshot"],sha((H/a["snapshot"]).read_bytes())==a["sha256"] and len((H/a["snapshot"]).read_bytes())==a["bytes"])
# Read and bind discovery producer evidence only for the canonical historical count.
extra=["check_finite_history_v1.py","FINITE_HISTORY_EXECUTION_v1.json","FINITE_HISTORY_EXECUTION_v1.stdout","FINITE_HISTORY_EXECUTION_v1.stderr",
"finite_history_results_v1/RESULTS.json","PARENT_FINITE_HISTORY_VERIFICATION_v1.json"]
names=["wrong_U0_gradient_sign","omit_finite_connection","wrong_full_ell_potential","wrong_eta_rate"]
for n in names:extra.extend(["FINITE_HISTORY_DAMAGE_"+n+".py","finite_history_mutations_v1/"+n+"/RESULTS.json"])
for n in extra:pairs.append(snap(ALT/n,"sources/discovery_parent/"+n))
pr=readj(ALT/"finite_history_results_v1/RESULTS.json")
ck("discovery_reported_67_0",(pr["passed"],pr["failed"])==(67,0))
ck("discovery_script_hash",pr["script_sha256"]==sha((ALT/"check_finite_history_v1.py").read_bytes()))
ck("discovery_original_source_hash",pr["source_sha256"]==sha((H/"sources/discovery_v1.md").read_bytes()))
for n in names:
    out=readj(ALT/("finite_history_mutations_v1/"+n+"/RESULTS.json"))
    ck("discovery_damage_"+n,out["failed"]>0 and out["script_sha256"]==sha((ALT/("FINITE_HISTORY_DAMAGE_"+n+".py")).read_bytes()),{"pass":out["passed"],"fail":out["failed"]})
old=readj(H/"sources/original_independent/RECEIPT_v1.json")
ck("old_science_reused_167_0",old["original_science"]["passed"]==167 and old["original_science"]["failed"]==0)
ck("old_density_reused_15_0",old["corrected_source_confirmation"]["passed"]==15 and old["corrected_source_confirmation"]["failed"]==0 and old["finding"]["same_checker_confirmed"] is True)
for key in ["original_science","corrected_source_confirmation"]:
    r=old[key]["output"]
    ck("old_result_hash_"+key,sha((H/"sources/original_independent"/r["path"]).read_bytes())==r["sha256"])
# Verify supplied producer primary versions and all nine actual damaged outputs.
for v,script in [(1,"canonical_runner_before_binding_v1.py"),(2,None)]:
    record=readj(H/("sources/parent_packaging/PRIMARY_RUN_v"+str(v)+".json"))
    src=(H/"sources/parent_packaging"/script) if script else H/"sources/canonical_runner.py"
    ck("primary_source_binding_v"+str(v),sha(src.read_bytes())==record["script_sha256"])
    for st in ["stdout","stderr"]:
        path=H/("sources/parent_packaging/PRIMARY_v"+str(v)+"."+st+(".json" if st=="stdout" else ".txt"))
        ck("primary_"+st+"_binding_v"+str(v),sha(path.read_bytes())==record[st+"_sha256"])
    out=readj(H/("sources/parent_packaging/PRIMARY_v"+str(v)+".stdout.json"))
    ck("primary_counts_v"+str(v),out["counts"]=={"passed":83 if v==1 else 132,"failed":0},out["counts"])
damages=readj(H/"sources/parent_packaging/canonical_damages_v1/RESULTS.json")
ck("nine_damage_original_source",damages["original_source_sha256"]==sha((H/"sources/canonical_runner.py").read_bytes()) and len(damages["actual_damages"])==9)
damage_map=[]
for r in damages["actual_damages"]:
    d=H/"sources/parent_packaging/canonical_damages_v1"/r["name"]
    individual=readj(d/"RUN.json");out=readj(d/"stdout.json")
    failed=[x["name"] for x in out["checks"] if not x["passed"]]
    ck("canonical_damage_"+r["name"],r==individual and r["source_sha256"]==sha((d/"damaged.py").read_bytes()) and r["exit_code"]==1 and r["rejected"] is True and out["counts"]==r["counts"] and failed==r["failed_witnesses"] and len(failed)>0,
       {"failed":r["counts"]["failed"],"first_witness":failed[0]})
    diff="".join(difflib.unified_diff((H/"sources/canonical_runner.py").read_text().splitlines(True),(d/"damaged.py").read_text().splitlines(True),fromfile="canonical_runner",tofile=r["name"]))
    diffpath=H/"DAMAGE_DIFFS"/(r["name"]+".diff");diffpath.parent.mkdir(exist_ok=True);assert not diffpath.exists();diffpath.write_text(diff)
    damage_map.append({"name":r["name"],"source_sha256":r["source_sha256"],"failed":len(failed),"diff":str(diffpath.relative_to(H))})
# Original note/cache pair remains historical when the author clarifies the sheet.
def cache_parts(text):
    head,tail=text.split("----- stdout -----\n",1)
    body,err=tail.split("----- stderr -----",1)
    return dict(line.split(": ",1) for line in head.splitlines() if ": " in line),json.loads(body),err
runner=H/"sources/canonical_runner.py"
tr=ast.parse(runner.read_text())
paths=next(ast.literal_eval(n.value) for n in tr.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="AUDIT_INPUT_PATHS" for t in n.targets))
ck("complete_declared_helper_inputs",paths==("docs/EXPONENTIAL_SCALAR_FINITE_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-14.md","docs/EXPONENTIAL_SCALAR_ALTERNATIVE_RADIATION_BOUNDED_THEOREM_NOTE_2026-10-14.md"))
def fingerprint(note,companion):
    digest=hashlib.sha256();digest.update(b"runner-cache-input-fingerprint-v1\0")
    for rel,body in zip(paths,[note,companion]):
        rb=rel.encode();digest.update(len(rb).to_bytes(8,"big"));digest.update(rb);digest.update(len(body).to_bytes(8,"big"));digest.update(body)
    return digest.hexdigest()
comp=(H/"sources/companion_note.md").read_bytes()
oldnote=(H/"sources/canonical_note.md").read_bytes()
oldcache=(H/"sources/canonical_cache.txt").read_text()
head,cacheout,err=cache_parts(oldcache)
ck("original_cache_code_binding",head["runner_sha256"]==sha(runner.read_bytes()))
ck("original_cache_input_fingerprint",head["input_fingerprint_sha256"]==fingerprint(oldnote,comp))
ck("original_cache_fresh_success",head["status"]=="ok" and head["exit_code"]=="0" and cacheout["counts"]=={"passed":132,"failed":0})
ck("original_cache_payload_matches_primary",cacheout==readj(H/"sources/parent_packaging/PRIMARY_v2.stdout.json"))
# Freeze narrowly corrected canonical sources and their preservation/actual-run receipts.
C=H/"corrected_source_v2";C.mkdir(exist_ok=False)
correction_sources=[
(R/paths[0],"sources/NOTE_v2.md"),
(R/"logs/runner-cache/exponential_scalar_finite_history_check.txt","sources/CACHE_v2.txt"),
(PACK/"EXPANDING_SHEET_CORRECTION_v2.json","sources/AUTHOR_CORRECTION_v2.json"),
(PACK/"CACHE_RUN_v2.json","sources/CACHE_RUN_v2.json"),
(PACK/"CANONICAL_NOTE_before_expanding_sheet_v1.md","sources/AUTHOR_PRESERVED_NOTE_v1.md"),
(PACK/"CACHE_before_expanding_sheet_v1.txt","sources/AUTHOR_PRESERVED_CACHE_v1.txt")]
cpairs=[]
for p,n in correction_sources:
    row=snap(p,"corrected_source_v2/"+n);cpairs.append(row);pairs.append(row)
newnote=(C/"sources/NOTE_v2.md").read_bytes();newcache=(C/"sources/CACHE_v2.txt").read_text()
cr=[]
def cck(n,ok,d=None):cr.append({"name":n,"passed":bool(ok),"detail":d})
cck("final_note_supplied_hash",sha(newnote)=="7d5b63f65c5fb71f8a132510071c96b7ad898326991c12abddccf3a86b46a4b9")
cck("final_cache_supplied_hash",sha(newcache.encode())=="3d30245a00870e6dbaad4f518748da0d27f583e6a297be68c41811c8a866d98b")
cck("author_preserved_old_note_exact",oldnote==(C/"sources/AUTHOR_PRESERVED_NOTE_v1.md").read_bytes())
cck("author_preserved_old_cache_exact",oldcache==(C/"sources/AUTHOR_PRESERVED_CACHE_v1.txt").read_text())
old_domain="trace-free radiation in a spatially flat classical homogeneous geometry.\nThese assumptions are not derived from framework primitives or observations."
new_domain="trace-free radiation in a spatially flat classical homogeneous geometry,\nand choose the expanding Einstein sheet H_E>0. These assumptions are not\nderived from framework primitives or observations."
added="\nUse H_E=+Hv*y_b*sqrt(Hbar), with y_b>0. This sheet fixes the physical\ntime orientation of the theorem. Since N_J'=1+p/(2F)>0 locally, H_J>0\nalso. On the contracting sheet the same N->-infinity limit would instead\nbe a physical future boundary; no expanding-state selector is derived here.\n"
text=newnote.decode()
cck("only_two_narrow_prose_changes",text.count(new_domain)==1 and text.count(added)==1 and text.replace(new_domain,old_domain).replace(added,"")==oldnote.decode())
cck("positive_root_and_local_physical_clock_explicit","H_E=+Hv*y_b*sqrt(Hbar)" in text and "H_J>0" in text)
cck("contracting_orientation_and_no_selector_explicit","physical future boundary" in text and "no expanding-state selector is derived" in text)
cck("runner_unchanged",sha((R/"scripts/exponential_scalar_finite_history_check.py").read_bytes())==sha(runner.read_bytes())=="74c6175934d68248493324454c157182f1e0e8c8ac3d6210973120210f64d042")
newhead,newout,newerr=cache_parts(newcache)
cck("final_cache_runner_binding",newhead["runner_sha256"]==sha(runner.read_bytes()))
cck("final_cache_input_fingerprint",newhead["input_fingerprint_sha256"]==fingerprint(newnote,comp),newhead["input_fingerprint_sha256"])
cck("final_cache_actual_success",newhead["status"]=="ok" and newhead["exit_code"]=="0" and newout["counts"]=={"passed":132,"failed":0})
cck("same_physics_payload",newout==cacheout)
cache_record=readj(C/"sources/CACHE_RUN_v2.json")
cck("new_cache_run_receipt",cache_record["cache_sha256"]==sha(newcache.encode()) and cache_record["result"]["status"]=="ok" and cache_record["result"]["exit_code"]==0)
orient=readj(H/"TIME_ORIENTATION_RUN_v1.stdout.txt")
cck("new_independent_orientation_check_eight_zero",orient["pass"]==8 and orient["fail"]==0)
diff="".join(difflib.unified_diff(oldnote.decode().splitlines(True),newnote.decode().splitlines(True),fromfile="frozen_original_note",tofile="corrected_note"))
(C/"SOURCE_V1_V2.diff").write_text(diff)
confirmation={"at_utc":datetime.now(timezone.utc).isoformat(),"original_reviewer":"/root/local_response_check","same_session_confirmation":True,
"pass":sum(x["passed"] for x in cr),"fail":sum(not x["passed"] for x in cr),"checks":cr,
"original_note_sha256":sha(oldnote),"corrected_note_sha256":sha(newnote),"corrected_cache_sha256":sha(newcache.encode()),
"unchanged_runner_sha256":sha(runner.read_bytes()),"source_pairs":cpairs,
"finding":"The squared constraint does not fix physical time orientation. The author has now made expansion an explicit conditional premise and states the contracting-sheet reversal.",
"reused":"The frozen 112/0 focused canonical tests and old 167/0 plus separate 15/0 are reused without new execution. The separately recorded 8/0 sign-sheet controls support the premise clarification.",
"scope":"No equations changed and no expanding-state selector was derived. This is original-reviewer affected-source correspondence, not formal audit."}
save(C/"RECEIPT_v2.json",confirmation)
# Identify current versus superseded source paths explicitly.
current_map={paths[0]:sha(newnote),"logs/runner-cache/exponential_scalar_finite_history_check.txt":sha(newcache.encode())}
for row in pairs:
    actual=Path(row["original_path"]).read_bytes()
    row["live_sha256_at_correspondence"]=sha(actual)
    if sha(actual)!=row["sha256"]:
        rel=str(Path(row["original_path"]).relative_to(R))
        assert rel in current_map and sha(actual)==current_map[rel],row["original_path"]
        row["disposition"]="historical original bytes, superseded by explicitly bound corrected source"
    else:row["disposition"]="live and frozen bytes identical"
save(H/"FINAL_SOURCE_BINDINGS_v1.json",{"at_utc":datetime.now(timezone.utc).isoformat(),"sources":pairs,"source_count":len(pairs),"corrected_source_receipt":"corrected_source_v2/RECEIPT_v2.json"})
receipt={"at_utc":datetime.now(timezone.utc).isoformat(),"pass":sum(x["passed"] for x in rows),"fail":sum(not x["passed"] for x in rows),
"checks":rows,"source_count":len(pairs),"parent_damages":damage_map,
"correction_pass":confirmation["pass"],"correction_fail":confirmation["fail"],
"cache_fingerprint":newhead["input_fingerprint_sha256"],
"scope":"Source, execution-history, cache and recorded-damage correspondence only. Producer full runner and old science were not rerun. Final delivery/archive mapping waits for the author's archive and commit."}
save(H/"EVIDENCE_CORRESPONDENCE_v1.json",receipt)
print(json.dumps({k:v for k,v in receipt.items() if k not in ["checks","parent_damages"]},indent=2));sys.exit(bool(receipt["fail"] or confirmation["fail"]))

