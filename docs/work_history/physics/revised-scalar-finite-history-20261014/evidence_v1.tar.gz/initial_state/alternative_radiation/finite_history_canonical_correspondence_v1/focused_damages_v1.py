"""Execute focused probes on three preserved damaged canonical inputs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
H=Path(__file__).resolve().parent
base=(H/"focused_paths_v1.py").read_text()
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
for name,witness in [("hidden_cubic_force","generic_theta_from_variation"),("double_u_potential","original_action_coefficients_"),("missing_clock_term","generic_Jordan_proper_clock")]:
    target="sources/parent_packaging/canonical_damages_v1/"+name+"/damaged.py"
    code=base.replace('CANONICAL_FILE = "sources/canonical_runner.py"','CANONICAL_FILE = "'+target+'"')
    assert code!=base
    script=H/("probe_"+name+"_v1.py");assert not script.exists();script.write_text(code)
    tag="DAMAGE_"+name+"_RUN_v1"
    cmd=[sys.executable,"-B",str(script)]
    started=datetime.now(timezone.utc).isoformat()
    r=subprocess.run(cmd,cwd=H,capture_output=True,timeout=45)
    (H/(tag+".stdout.txt")).write_bytes(r.stdout);(H/(tag+".stderr.txt")).write_bytes(r.stderr)
    out=json.loads(r.stdout)
    failed=[x["name"] for x in out["checks"] if not x["passed"]]
    rec={"command":cmd,"cwd":str(H),"started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),
    "exit_code":r.returncode,"script_sha256":sha(script.read_bytes()),"canonical_input_sha256":sha((H/target).read_bytes()),
    "stdout":{"path":tag+".stdout.txt","sha256":sha(r.stdout),"bytes":len(r.stdout)},
    "stderr":{"path":tag+".stderr.txt","sha256":sha(r.stderr),"bytes":len(r.stderr)},
    "pass":out["pass"],"fail":out["fail"],"failed":failed,"expected_witness":witness,
    "expected_rejection":r.returncode==1 and any(n.startswith(witness) for n in failed)}
    (H/(tag+".json")).write_text(json.dumps(rec,indent=2)+"\n");rows.append({"name":name,**rec})
receipt={"at_utc":datetime.now(timezone.utc).isoformat(),"controls":rows,"actual_focused_probes":3,
"expected_rejections":sum(x["expected_rejection"] for x in rows),
"scope":"These three new runs execute this focused checker against exact preserved damaged canonical source inputs. They do not re-execute the full parent primary or its nine original damaged runs, or any old sealed independent science."}
(H/"FOCUSED_DAMAGE_RECEIPT_v1.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2));sys.exit(not all(x["expected_rejection"] for x in rows))

