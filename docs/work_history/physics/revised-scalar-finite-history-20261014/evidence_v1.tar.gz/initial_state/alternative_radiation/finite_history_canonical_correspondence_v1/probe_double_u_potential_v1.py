"""Narrow tests of actual canonical AST paths against independent action equations.
Does not import or execute run_checks; original sealed science is not rerun.
"""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,sys
import sympy as s
import mpmath as mp
H=Path(__file__).resolve().parent
CANONICAL_FILE = "sources/parent_packaging/canonical_damages_v1/double_u_potential/damaged.py"
source=H/CANONICAL_FILE
tree=ast.parse(source.read_text())
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="run_checks")
finite=next(n for n in run.body if isinstance(n,ast.FunctionDef) and n.name=="finite_flow")
ksloop=next(n for n in run.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=="ks")
nusloop=next(n for n in ksloop.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=="nus")
field_index=next(i for i,n in enumerate(nusloop.body) if isinstance(n,ast.FunctionDef) and n.name=="fields")
flowdef=next(n for n in nusloop.body if isinstance(n,ast.FunctionDef) and n.name=="flow")
clockdef=next(n for n in run.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="hJ" for t in n.targets))
def compile_nodes(nodes,env):
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(source),"exec"),env)
env={}
compile_nodes([finite],env)
canfinite=env["finite_flow"]
rows=[]
def ck(name,ok,kind="exact",detail=None):rows.append({"name":name,"passed":bool(ok),"kind":kind,"detail":detail})
def zero(name,expr):
    r=s.factor(s.cancel(expr));ck(name,r==0,"exact",str(r))
imports=[a.name for n in tree.body if isinstance(n,ast.Import) for a in n.names]
ck("canonical_import_closure",sorted(imports)==["json","mpmath","sympy","sys"],"structure",imports)
ck("same_helper_in_actual_flow",any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="finite_flow" for n in ast.walk(flowdef)),"structure")
ck("finite_helper_no_external_calls",not any(isinstance(n,ast.Call) for n in ast.walk(finite)),"structure")

# Solve independent lowered Euler-Lagrange equations rather than repeat
# the producer's proposed accelerations as their own expected values.
AA,At,BB,Bt,CC,Wq,U0,U0t,Z,ll,FF,p,q,eta,d=s.symbols("A At B Bt C Wq U0 U0t Z l F p q eta d",nonzero=True)
pd,qd,h,HB=s.symbols("pd qd h HB",nonzero=True)
Wth=-ll*Wq+eta*Z*U0t
Well=2*Wq
Bell=2*eta*BB/(d+eta)
ELtheta=2*AA*pd+(3+h)*2*AA*p+At*p*p-Bt*q*q+2*Wth/HB
ELell=2*BB*qd+(3+h)*2*BB*q+2*Bt*p*q+Bell*q*q+2*Well/HB
refpd=s.solve(ELtheta,pd)[0]
refqd=s.solve(ELell,qd)[0]
T=AA*p*p+BB*q*q
refHB=2*(CC*CC+Wq+eta*Z*U0)/(3-T)
refh=-T-4*CC*CC/(3*refHB)
vals,canHB,canh=canfinite(AA,At,BB,Bt,CC,Wq,U0,U0t,Z,ll,FF,p,q,eta,d)
zero("generic_theta_from_variation",vals[2]-refpd.subs({h:refh,HB:refHB}))
zero("generic_ell_from_variation",vals[3]-refqd.subs({h:refh,HB:refHB}))
zero("generic_constraint_from_energy",canHB-refHB)
zero("generic_h_from_raychaudhuri",canh-refh)
zero("generic_radiation_clock",vals[1]-(q+2+p/FF))
zero("generic_eta_chain",vals[4]+2*q*eta)
zero("generic_theta_velocity",vals[0]-p)

HE,L,LD,hE,Cg=s.symbols("HE L LD hE Cg",positive=True)
clockenv={"HE":HE,"L":L,"LD":LD,"hE":hE,"Cg":Cg,"s":s}
compile_nodes([clockdef],clockenv)
clock=clockenv["hJ"]
HJ=HE*L/s.sqrt(Cg)
actual=(s.diff(HJ,HE)*hE*HE+s.diff(HJ,L)*LD+s.diff(HJ,Cg)*2*(L-1)*Cg)*HE/s.sqrt(Cg)/HJ**2
zero("generic_Jordan_proper_clock",clock-actual)
zero("radiation_Jordan_limit",clock.subs({L:1,LD:0,hE:-2})+2)
clock_fun=s.lambdify((hE,L,LD),clock,"mpmath")

# A local singularity calculation requires the branch theorem already proved;
# this checks correspondence of the physical constants, not a new theorem.
Hv,beta,H0,Cx,e,tau=s.symbols("Hv beta H0 Cx e tau",positive=True)
HEleading=Hv*s.sqrt(H0)/(beta*s.sqrt(e))
dte_de=1/(4*e*HEleading)
te=beta*s.sqrt(e)/(2*Hv*s.sqrt(H0))
tj=s.sqrt(Cx)*te
zero("proper_E_time_coefficient",s.diff(te,e)-dte_de)
zero("proper_J_time_coefficient",s.diff(tj,e)-s.sqrt(Cx)*dte_de)
zero("HJ_time_product",(HEleading/s.sqrt(Cx))*tj-s.Rational(1,2))
zero("physical_curvature_coefficient",24/(2*tau)**4-s.Rational(3,2)/tau**4)

mp.mp.dps=70
tol=mp.mpf("1e-52")
details=[]
def metric_and_potential(u,x,kv,nv):
    a=(1-kv)*(1+3*kv)/4;alpha=mp.sqrt(a)
    ss=(1+kv)/(kv*(1-3*kv));E=mp.exp(2*alpha*u)
    F=1+ss*E;J=1+(1-3*a)*ss*E
    D=1+2*(1+kv)*x*x/3
    Ku=J/F**2;Kx=(1+ss)*4*kv/(9*F*D)
    C=(1+ss)*E/F
    Ubase=mp.mpf(3)/2+3*ss*(E-1)**2/(2*F*F)+nv*(1+ss)*u*u/(2*F*F)
    U=Ubase+kv*x*x*mp.exp(-(1-kv)*u/alpha)/2
    return Ku,Kx,C,U,Ubase,F
for rationalk,rationalnu in [(s.Rational(3,83),s.Rational(2,7)),(s.Rational(7,61),s.Rational(11,5)),(s.Rational(8,49),s.Rational(19,3))]:
    kv=mp.mpf(int(rationalk.p))/int(rationalk.q);nv=mp.mpf(int(rationalnu.p))/int(rationalnu.q)
    # Run only the actual producer coefficient prefix and definitions at
    # independently selected k,nu; this includes their parameter formulas.
    ce={"mp":mp,"ks":str(kv),"nus":str(nv),"finite_flow":canfinite}
    compile_nodes(nusloop.body[:field_index+1]+[flowdef],ce)
    canfields=ce["fields"];canflow=ce["flow"]
    a=(1-kv)*(1+3*kv)/4;alpha=mp.sqrt(a)
    Ebranch=(1-3*kv)/(3*(1+kv));ux=mp.log(Ebranch)/(2*alpha)
    b=2*kv*(1-kv)/((1+kv)*(1-3*kv));cx=(1-kv)/(1+kv)
    hb0=2*cx*cx/(3*(1-2*b));w0=b*hb0
    betasq=2*w0*mp.exp((1-kv)*ux/alpha)/kv
    dval=2*(1+kv)/3
    statebase=[-mp.mpf(3)/50,mp.mpf(1)/70,mp.mpf(1)/40,-mp.mpf(37)/20]
    def canonical_readouts(state):
        tt,zz,pp,qq,ee=state
        av,biv,cv,u0,ff=canfields(tt)
        av1=mp.diff(lambda t:canfields(t)[0],tt)
        bv=biv/(1+ee/ce["dv"])
        bv1=mp.diff(lambda t:canfields(t)[1],tt)/(1+ee/ce["dv"])
        u01=mp.diff(lambda t:canfields(t)[3],tt)
        wq=ce["w0"]*mp.exp(2*zz-ce["lv"]*tt)
        zzfac=ce["betasq"]*mp.exp(2*zz)
        vv,hhbar,hh=canfinite(av,av1,bv,bv1,cv,wq,u0,u01,zzfac,ce["lv"],ff,pp,qq,ee,ce["dv"])
        he=mp.sqrt(hhbar/(ce["betasq"]*ee*mp.exp(2*zz)))
        rate=1+pp/(2*ff);hj=he*rate/mp.sqrt(cv)
        return he,hj,hh,hhbar,cv,ff,rate
    for ev in [mp.mpf(1)/17,mp.mpf(1)/900]:
        for sign in [-1,1]:
            th,zz,pp,qq=statebase;state=statebase+[ev]
            u=ux+th/(2*alpha);x=sign/mp.sqrt(ev)
            Ku,Kx,cv,U,Ubase,ff=metric_and_potential(u,x,kv,nv)
            upr=pp/(2*alpha);xpr=qq*x
            ybsq=x*x/(betasq*mp.exp(2*zz))
            totalT=Ku*upr*upr+Kx*xpr*xpr
            Hnorm=2*(cv*cv*ybsq+U)/(3-totalT)
            hh=-totalT-4*cv*cv*ybsq/(3*Hnorm)
            Kuu=mp.diff(lambda uu:metric_and_potential(uu,x,kv,nv)[0],u)
            Kxu=mp.diff(lambda uu:metric_and_potential(uu,x,kv,nv)[1],u)
            Kxx=mp.diff(lambda xx:metric_and_potential(u,xx,kv,nv)[1],x)
            Uu=mp.diff(lambda uu:metric_and_potential(uu,x,kv,nv)[3],u)
            Ux=mp.diff(lambda xx:metric_and_potential(u,xx,kv,nv)[3],x)
            upp=-(3+hh)*upr-Kuu*upr**2/(2*Ku)+Kxu*xpr**2/(2*Ku)-Uu/(Ku*Hnorm)
            xpp=-(3+hh)*xpr-Kxu*upr*xpr/Kx-Kxx*xpr**2/(2*Kx)-Ux/(Kx*Hnorm)
            Cu=mp.diff(lambda uu:metric_and_potential(uu,x,kv,nv)[2],u)
            reference=mp.matrix([pp,qq+2+Cu*upr/cv,2*alpha*upp,xpp/x-qq**2,-2*qq*ev])
            got=canflow(*state)
            he,hj,hcan,hbar,cc,fc,rate=canonical_readouts(state)
            fn=canfields(th)
            refcoeff=mp.matrix([Ku/(4*a),Kx*x*x*(1+ev/dval),cv,Ubase,ff])
            errors={
            "original_action_coefficients":mp.norm(mp.matrix(fn)-refcoeff)/(1+mp.norm(refcoeff)),
            "original_action_U0_gradient":abs(mp.diff(lambda t:canfields(t)[3],th)-mp.diff(lambda uu:metric_and_potential(uu,x,kv,nv)[4],u)/(2*alpha)),
            "original_coordinate_flow":mp.norm(got-reference)/(1+mp.norm(reference)),
            "original_Friedmann":abs(hbar-Hnorm/ybsq)/(1+abs(Hnorm/ybsq)),
            "original_Raychaudhuri":abs(hcan-hh),
            }
            # Differentiate the complete finite readout along the actual
            # canonical five-state vector field, away from the limiting point.
            dHE=mp.mpf(0);dHJ=mp.mpf(0)
            for j in range(5):
                def component(v,which):
                    st=list(state);st[j]=v
                    return canonical_readouts(st)[which]
                dHE+=mp.diff(lambda v:component(v,0),state[j])*got[j]
                dHJ+=mp.diff(lambda v:component(v,1),state[j])*got[j]
            errors["full_function_energy_derivative"]=abs(dHE/he-hcan)
            Lprime=got[2]/(2*fc)-pp*pp*mp.diff(lambda t:canfields(t)[4],th)/(2*fc*fc)
            physical_direct=he/mp.sqrt(cc)*dHJ/(hj*hj)
            clock_claim=clock_fun(hcan,rate,Lprime)
            errors["full_function_Jordan_clock"]=abs(physical_direct-clock_claim)
            label=str(rationalk)+"_"+str(rationalnu)+"_"+str(sign)+"_"+mp.nstr(ev,8)
            for name,error in errors.items():ck(name+"_"+label,error<tol,"numeric",mp.nstr(error,30))
            ck("finite_physical_domain_"+label,totalT<3 and Hnorm>0 and rate>0,"domain",
               {"T":mp.nstr(totalT,18),"N_J_prime":mp.nstr(rate,18)})
            details.append({"k":str(rationalk),"nu":str(rationalnu),"x_sign":sign,"eta":mp.nstr(ev,25),
                            "max_error":mp.nstr(max(errors.values()),25),"hE":mp.nstr(hcan,25),"hJ":mp.nstr(physical_direct,25)})
r={"at_utc":datetime.now(timezone.utc).isoformat(),"pass":sum(x["passed"] for x in rows),"fail":sum(not x["passed"] for x in rows),
"checks":rows,"pointwise_controls":details,"canonical_input":CANONICAL_FILE,
"canonical_source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
"checker_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
"extracted_functions":["finite_flow","numerical coefficient prefix","fields","flow","hJ assignment"],
"full_primary_runner_executed":False,"old_independent_science_rerun":False,
"scope":"New narrow canonical-path tests; full nonlinear original-coordinate and proper-clock comparisons at twelve finite points, not histories. Prior manifold/hyperbolicity proof and 167/0 plus 15/0 checks reused without rerun."}
print(json.dumps(r,indent=2));sys.exit(bool(r["fail"]))

