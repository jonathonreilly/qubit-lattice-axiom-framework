"""Seal finite-history canonical correspondence and affected-source confirmation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
H=Path(__file__).resolve().parent
R=H.parents[6]
def sha(b):return hashlib.sha256(b).hexdigest()
def readj(p):return json.loads(p.read_text())
def info(p,base=H):return {"path":str(p.relative_to(base)),"sha256":sha(p.read_bytes()),"bytes":len(p.read_bytes())}
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,indent=2)+"\n")
for n in ["REPORT_v1.txt","RECEIPT_v1.json","MANIFEST_v1.json","CLAIM_DISPOSITIONS_v1.json","PRESERVED_FAILURES_v1.json"]:
    assert not (H/n).exists(),n
bindings=readj(H/"FINAL_SOURCE_BINDINGS_v1.json")
for row in bindings["sources"]:
    frozen=(H/row["snapshot"]).read_bytes();current=Path(row["original_path"]).read_bytes()
    assert sha(frozen)==row["sha256"] and len(frozen)==row["bytes"],row
    assert sha(current)==row["live_sha256_at_correspondence"],row
prior=readj(H/"SOURCE_BINDINGS_v1.json")["prior_seals_verified"]
for m in prior:
    p=Path(m["manifest"]);assert sha(p.read_bytes())==m["sha256"]
    for a in readj(p)["artifacts"]:
        b=(p.parent/a["path"]).read_bytes()
        assert sha(b)==a["sha256"] and len(b)==a["bytes"],a
science=readj(H/"FOCUSED_PATHS_RUN_v1.stdout.txt")
orientation=readj(H/"TIME_ORIENTATION_RUN_v1.stdout.txt")
corr=readj(H/"EVIDENCE_CORRESPONDENCE_v1.json")
fix=readj(H/"corrected_source_v2/RECEIPT_v2.json")
damages=readj(H/"FOCUSED_DAMAGE_RECEIPT_v1.json")
assert (science["pass"],science["fail"])==(112,0)
assert (orientation["pass"],orientation["fail"])==(8,0)
assert (corr["pass"],corr["fail"])==(105,0)
assert (fix["pass"],fix["fail"])==(14,0)
assert damages["actual_focused_probes"]==damages["expected_rejections"]==3
runs=[]
for p in sorted(H.glob("*_RUN_v*.json")):
    r=readj(p)
    assert sha(Path(r["command"][-1]).read_bytes())==r["script_sha256"]
    for key in ["stdout","stderr"]:
        b=(H/r[key]["path"]).read_bytes()
        assert sha(b)==r[key]["sha256"] and len(b)==r[key]["bytes"]
    runs.append({"receipt":info(p),**r})
assert len(runs)==9,len(runs)
note_rel="docs/EXPONENTIAL_SCALAR_FINITE_HISTORY_BOUNDED_THEOREM_NOTE_2026-10-14.md"
note=R/note_rel
notehash=sha(note.read_bytes())
assert notehash=="7d5b63f65c5fb71f8a132510071c96b7ad898326991c12abddccf3a86b46a4b9"
def source_by(suffix):
    return next(x for x in bindings["sources"] if x["snapshot"].endswith(suffix))
claims=[
{"claim":"Complete action and conventions","original":source_by("original_action_note.md"),
"disposition":"Explicit conditional import, coefficients retained; not derived framework primitives",
"final_section":"Supplied action, domain and density convention","support":"Original supplied action plus companion note; local inspection and new coefficient comparisons"},
{"claim":"Finite metric, physical gradients and five-state equations","original":source_by("discovery_v2.md"),
"disposition":"Equivalent equations integrated; full three-field metric/determinant also carried from the original independent action proof",
"final_section":"Full finite-amplitude equations","support":"Reused 167/0 action reconstruction and new generic lowered-equation/finite-point pipeline checks"},
{"claim":"Forcing, +4 eigenvalue and unique tangent","original":source_by("original_independent/HAND_DERIVATION_v1.txt"),
"disposition":"Checked result integrated unchanged; plane/normal stability imported explicitly from companion note",
"final_section":"New direction and conditional local past convergence","support":"Reused all-k alternative proof and finite-history result; determinant lower bound uses companion Sx>46/5,Px>0"},
{"claim":"Smooth local unstable manifold and its scope","original":source_by("original_independent/REPORT_v1.txt"),
"disposition":"Source-specific smoothness/hyperbolicity argument integrated; a named local theorem is a mathematical input",
"final_section":"New direction and conditional local past convergence","support":"Original section 3 proof and archived primary theorem access; no new theorem proof or network retrieval"},
{"claim":"Physical clocks, finite time and divergent curvature","original":source_by("original_independent/REPORT_v1.txt"),
"disposition":"Checked conditional result integrated with explicit proper-time coefficients; expansion premise now repaired",
"final_section":"Finite proper time and diverging physical curvature","support":"Original section 4; new finite full-function clock/energy controls and separate eight sign-sheet identities"},
{"claim":"Density-symbol ambiguity","original":source_by("discovery_v1.md"),
"disposition":"Original ambiguous notation preserved only as history; corrected dimensionful rho_phys convention is canonical",
"final_section":"Supplied action, domain and density convention","support":"Original reviewer 15/0 correction confirmation, byte diff and original receipt retained"},
{"claim":"Weak-k contrast","original":source_by("discovery_v2.md"),
"disposition":"Retained solely as leading log asymptotics; relative-error and long finite-history tracking interpretations excluded",
"final_section":"Finite proper time and diverging physical curvature","support":"Reused slow eigenvalue plus eta leading rate; no empirical erasure bound"},
{"claim":"Time orientation of the physical boundary","original":source_by("canonical_note.md"),
"disposition":"Missing explicit branch premise corrected by original author and confirmed by original reviewer",
"final_section":"Supplied action, domain and density convention; Full finite-amplitude equations",
"support":"corrected_source_v2/RECEIPT_v2.json, 14/0 affected-source checks and separate TIME_ORIENTATION_RUN_v1, 8/0"}
]
for c in claims:
    c["original_path"]=c["original"]["original_path"];c["original_sha256"]=c["original"]["sha256"]
    c["original_snapshot"]=c["original"]["snapshot"];del c["original"]
    c["final_path"]=note_rel;c["final_sha256"]=notehash
save(H/"CLAIM_DISPOSITIONS_v1.json",{"scope":"Source/claim mapping only, not the later five-file base-to-head delivery map.","claims":claims})
failures={
"science_unexpected_failures":[],
"setup_failure":{"run":"BOOTSTRAP_RUN_v1.json","exit_code":1,"diagnosis":"Incorrect repository parent depth pointed into .claude; first read failed before source snapshots or science.",
"repair":"bootstrap_v2.py changes only parents[5] to parents[6]. Original failure/script retained with BOOTSTRAP_V1_V2.diff and BOOTSTRAP_CORRECTION_v2.json."},
"lookup_and_display_events":"TOOL_FAILURES_v1.json preserves the nonexistent guessed packaging subdirectory and combined-output truncation; actual packaging was found under the campaign root and complete required material read in bounded chunks.",
"expected_focused_damage_failures":[{"name":x["name"],"passed":x["pass"],"failed":x["fail"],"receipt":"DAMAGE_"+x["name"]+"_RUN_v1.json"} for x in damages["controls"]],
"parent_historical_failures":"The original sealed report preserves earlier retrieval and tool errors. Nine canonical damaged-run failures and four discovery damages were bound from recorded evidence, not rerun or erased.",
"genuine_source_finding":{"id":"physical_past_requires_expanding_sheet","original_note_sha256":"bb344d55f9c8929b4b507d1b6562b9d0dbc944ed75059ffb50c0ce3277d52206",
"corrected_note_sha256":notehash,"correction_receipt":"corrected_source_v2/RECEIPT_v2.json","same_original_reviewer_confirmed":True}
}
save(H/"PRESERVED_FAILURES_v1.json",failures)
now=datetime.now(timezone.utc).isoformat()
report=f"""FINITE-HISTORY CANONICAL SOURCE CORRESPONDENCE
Sealed {now}
Direct scientific author: /root. Original and current independent checker:
 /root/local_response_check. This is focused correspondence, not formal audit.

Conclusion and readiness
The corrected canonical note faithfully carries the checked finite-amplitude
equations, conditional local manifold and physical curvature conclusion.
One consequential missing premise was found and repaired: the physical past
interpretation requires the expanding H_E>0 sheet. The same reviewer confirms
the exact two-passage correction and final cache binding. No equation or runner
changed. This source unit is ready for the author's separate five-file archive/
commit and subsequent recovery/delivery mapping. This report does not claim
that an archive, commit, delivery map, formal audit verdict or approval already
exists.

Final source identities
Note:
 {note_rel}
 SHA256 {notehash}
Runner:
 scripts/exponential_scalar_finite_history_check.py
 SHA256 74c6175934d68248493324454c157182f1e0e8c8ac3d6210973120210f64d042
Fresh final cache:
 logs/runner-cache/exponential_scalar_finite_history_check.txt
 SHA256 3d30245a00870e6dbaad4f518748da0d27f583e6a297be68c41811c8a866d98b
Declared-input fingerprint:
 cd3a156466d75fe942059a7ed4a947e7518ac78d67f4386313dd6888632fd722

The base 494fd01a2b2873db6795d48f34f42d5988a02e85 and branch
codex/revised-scalar-finite-history-20261014 were supplied by the parent.
No Git operation was used to verify or alter that delivery identity here.

Mathematical and physical correspondence
The complete canonical note, runner and cache, full original independent report,
hand proof and density diff, discovery v2 and companion alternative-radiation
note were read. Original 167/0 science and separate 15/0 density clarification
are reused unchanged. The old finite-history 73-artifact seal and alternative
29-artifact seal were verified at entry and sealing. The finished second-rate
68-artifact unit was also verified unchanged.

The action convention is -Q K_AB partial phiA partial phiB-2Q Hv^2 U,
so the scalar force is Hv^2 K^-1 grad U. Ideal radiation is trace-free.
The physical metric and conservation are C gE, dtJ=sqrt(C)dtE and
rho_phys proportional to exp(-4NJ). They imply z'=q+2+p/F.

The finite metric coefficient is B=Binf/(1+eta/d). Physical differentiation
must respect eta=x^-2, giving B_ell=2eta B/(d+eta). The normalized potential
satisfies W_theta=-lWq+eta Z U0_theta and W_ell=2Wq; replacing the latter by
2W adds a false force. Solving the independent lowered Euler-Lagrange
equations gives the canonical generic finite_flow exactly, away from the
equilibrium. Its actual numerical coefficient prefix, fields, flow and clock
assignment were extracted from the frozen source through AST inspection.
Only those definitions were executed; neither run_checks nor the full primary
or original independent science was rerun.

New focused controls passed 112/0: 13 exact, 84 numerical, 12 domain and
3 structural checks. The numerical pipeline was compared with accelerations
reconstructed directly in original (u,x) coordinates, from original metric,
potential and their derivatives. The points are
 (k,nu)=(3/83,2/7),(7/61,11/5),(8/49,19/3),
 eta=1/17 and 1/900, both x signs,
 (theta,z,p,q)=(-3/50,1/70,1/40,-37/20).
All twelve points have T<3, positive Hbar and NJ'>0. At 70 decimal digits,
the largest observed normalized/absolute discrepancy among the 84 numerical
comparisons is 5.216071149404186e-69, below the frozen 1e-52 criterion.
Directional differentiation of the complete finite Friedmann readout along
the actual flow reproduces h. Jordan proper-time differentiation reproduces
hJ=[h+L'/L-(L-1)]/L, L=1+p/(2F). These are finite-point consistency controls,
not history integrations, global error bounds or empirical precision.

The conditional manifold proof is reused, not replaced by sampled eigenvalues
or tangent residuals. At fixed 0<k<3-2sqrt(2), finite nu>0, A0,b,Cx,H0 are
positive and T0=4b<2<3. The complete pulled-back metric and normalized
potential extend smoothly through eta=0 in a sufficiently small open
neighborhood with all displayed denominators nonzero. Negative eta is only
a mathematical extension. Reflection makes w=w'=0 invariant; the previously
checked six stable directions plus eta eigenvalue +4 give a hyperbolic saddle.
The named local smooth unstable-manifold theorem supplies a one-dimensional
local germ, tangent to a vector with nonzero eta component. Uniqueness places
it in the invariant plane. Each positive-eta half is one local orbit per
x-sign chart up to N translation. This is neither global no-return nor
initial-state selection. No uniform neighborhood at parameter endpoints
is inferred.

The old proof gives (4I-M)h1=f and det(4I-M)=400+20Sx+Px>584. The numerical
primary does not independently prove all-k Hurwitz bounds: those load-bearing
facts are explicitly in the companion note, which is a declared cache input.
Its import is visible and bound. The canonical tangent probes remain local
consistency checks.

Along the conditional positive branch eta'=4eta+O(eta^2), so proper time
scales as sqrt(eta); C->Cx>0 and L->1. The correct physical clock gives
HJ~1/(2 Delta tJ), hJ->-2 and
 KJ=12HJ^4[1+(1+hJ)^2]~3/[2(Delta tJ)^4].
Thus physical curvature diverges at finite proper time. Leading Ricci
cancellation does not remove this singularity. The statement concerns this
supplied classical model, not a justified arbitrarily high-curvature extension
or the observed Universe. The weak-k contrast remains a leading logarithmic
comparison only, with no O(1/k) tracking or observed-erasure conclusion.

Genuine correction: time orientation
The first canonical note used H_E squared in the constraint but did not state
its sign. That omission matters: for sign sigma=+/-1,
 H_E=sigma Hv sqrt(H0)/(beta sqrt(eta)),
 tE-t_boundary=sigma beta sqrt(eta)/(2Hv sqrt(H0)).
Both signs give eta'=4eta in N, but eta->0 is physical past only for sigma=+1.
For sigma=-1 it is future. Eight separately recorded exact sign-sheet controls
passed 8/0; the curvature coefficient is unchanged on either sheet.

The author preserved the original note/cache and added only the H_E>0 domain
premise plus positive root and contracting-sheet caveat. Removing those two
new passages exactly recovers the original note. No equation or runner changed.
The corrected source explicitly disclaims deriving an expanding-state selector.
The same original reviewer confirmed this repair in
 corrected_source_v2/RECEIPT_v2.json
 SHA256 7e08f7d9e8769e5deecd8c88dd5d3356b0bff380c7c36ed743ac055b75c1a8a6.
Its 14/0 controls concern affected-source/cache correspondence; they are not
14 new physics results. The 112/0 tests and earlier science are reused.

Original note SHA:
 bb344d55f9c8929b4b507d1b6562b9d0dbc944ed75059ffb50c0ce3277d52206
Original cache SHA:
 2e8045c95b5a905196da83508edf49fb210017564045a8334e38264ef5176b14
Both remain bound as historical snapshots. The final note/cache are separate.

Evidence, helper closure and nonvacuous damage
The runner imports only json, sys, sympy and mpmath. Its mathematical helper
is local; both displayed notes are literal AUDIT_INPUT_PATHS. The ordered
length-prefixed source bytes reproduce the old and final cache fingerprints.
The final cache reports an actual successful 132/0 run against the corrected
note and unchanged runner. Its physics payload equals the earlier 132/0
payload, while the input fingerprint is refreshed. Producer results are
evidence correspondence, not independent science.

105/0 evidence checks bind all frozen sources, original 67/0 producer result,
old 167/0 and 15/0 independent records, original 83/0 canonical result,
expanded 132/0 canonical result and the original nine damaged canonical runs.
The 83/0 source/output are preserved; the 49 added controls comprise
48 coefficient/gradient bindings and one clock identity, not a theorem change.

All nine recorded canonical damaged scripts have source hashes, matching
recorded output counts and intended failed identities. They reject extra
radial vacuum force (13 failures), omitted eta connection (13), reversed
eta rate (25), hidden cubic force (1), missing finite metric (3),
reversed potential gradient (12), missing clock term (1), wrong tangent
resolvent (24), and doubled u potential (48). Their exact source diffs are
in DAMAGE_DIFFS. These nine parent executions were not rerun here.

Three additional actual runs of this focused probe against preserved damaged
canonical inputs were rejected: hidden cubic force (37 failures), doubled
u potential (60), missing clock term (13). Full script/input hashes,
commands, stdout/stderr and expected witnesses are preserved. The old six
independent damaged runs and four discovery damages remain reused records.

Failures and execution history
No unexpected science-control failure or timeout occurred in this unit.
One setup attempt failed before any source snapshot or science because its
repository parent depth was off by one. The failed bootstrap_v1, traceback,
exact one-line diff and successful bootstrap_v2 remain. A guessed packaging
subdirectory was absent; the actual campaign-root directory was then found.
Display truncation was handled by bounded reads. Old retrieval/tool failures
remain untouched in the sealed evidence.

Nine target-process receipts preserve exact argument arrays, cwd, timings,
script hashes, stdout/stderr bytes and exit codes: two bootstrap attempts,
the focused baseline, focused damage driver and three children, orientation
controls, and evidence correspondence. The command pattern is
 python3 -B run_recorded_v1.py RUN_TAG script.py.
The focused damage driver records its exact child commands separately.
The final direct seal command is python3 -B seal_v1.py in this directory;
it verifies bytes and writes receipts without running science.

All 91 source bindings, including explicitly superseded historical paths,
are in FINAL_SOURCE_BINDINGS_v1.json. CLAIM_DISPOSITIONS_v1.json maps eight
claim groups to original sources and the final note. That is a source/claim
map, not a fabricated five-file base-to-head delivery map.

Original independent receipt:
 c74ab0d7c2fdcbd4d302c563e9a5b9b1406c8b6ca58f6dbfb727df016fd5a2af
Original independent manifest:
 d25ff01c1f6d4fce392c202bbf1d255c74ab0c11982f640b285b61bf1ff2ce73
New focused script:
 0ced6c0c4e66a7511e98b98367f9a5ce7089f6d7bd65bd5232b1dd143d8dc877
New focused stdout:
 873633dec6e8738d263ec90c30f2a52548612d82bb851085ee28723fbd91c04a

Scope still open
The action, parameter values, absolute scales, trace-free radiation, flat
homogeneous geometry, expanding sheet and chosen past limit remain premises.
No actual initial state, full history, global continuation, nonsingular
completion, measured gravity/calibration or empirical validation follows.
All new writes are confined to this correspondence folder. No parent source,
old seal, Git state, network, PR, runtime/lock, model or formal audit status
was modified by this checker. Primary scientific authorship remains /root.
"""
(H/"REPORT_v1.txt").write_text(report)
child=H/"corrected_source_v2"
child_entries=[info(p,child) for p in sorted(child.rglob("*")) if p.is_file()]
save(child/"MANIFEST_v2.json",{"sealed_utc":now,"scope":"Original-reviewer affected-source confirmation; unchanged 112/0 and old science reused","artifact_count":len(child_entries),"artifacts":child_entries})
artifacts=[info(p) for p in sorted(H.rglob("*")) if p.is_file()]
receipt={
"sealed_utc":now,"unit":"initial_state/alternative_radiation/finite_history_canonical_correspondence_v1",
"author":"/root","original_and_current_reviewer":"/root/local_response_check",
"scope":"Focused final-source mathematical/evidence correspondence; no formal audit",
"disposition":"Corrected canonical source corresponds to the checked conditional finite-history result; ready for a later separate five-file recovery/delivery mapping after author archive and commit.",
"report":info(H/"REPORT_v1.txt"),"source_bindings":info(H/"FINAL_SOURCE_BINDINGS_v1.json"),"source_count":91,
"claim_dispositions":info(H/"CLAIM_DISPOSITIONS_v1.json"),
"finding":{"id":"physical_past_requires_expanding_sheet","status":"corrected by author and same reviewer confirmed",
"original_note_sha256":"bb344d55f9c8929b4b507d1b6562b9d0dbc944ed75059ffb50c0ce3277d52206",
"final_note_sha256":notehash,"affected_source_receipt":info(child/"RECEIPT_v2.json"),"affected_source_manifest":info(child/"MANIFEST_v2.json")},
"final_sources":{"note_sha256":notehash,"runner_sha256":"74c6175934d68248493324454c157182f1e0e8c8ac3d6210973120210f64d042",
"cache_sha256":"3d30245a00870e6dbaad4f518748da0d27f583e6a297be68c41811c8a866d98b","input_fingerprint_sha256":corr["cache_fingerprint"]},
"new_focused_controls":{"passed":112,"failed":0,"exact":13,"numeric":84,"domain":12,"structure":3,"points":12,"precision_decimal_digits":70,"tolerance":"1e-52","maximum_observed_discrepancy":"5.216071149404186e-69","run":"FOCUSED_PATHS_RUN_v1.json"},
"new_orientation_controls":{"passed":8,"failed":0,"run":"TIME_ORIENTATION_RUN_v1.json"},
"new_evidence_correspondence":{"passed":105,"failed":0,"run":"EVIDENCE_CORRESPONDENCE_RUN_v1.json"},
"affected_source_confirmation":{"passed":14,"failed":0,"same_reviewer":True,"science_rerun":False},
"new_focused_damage_probes":{"count":3,"rejected":3,"receipt":info(H/"FOCUSED_DAMAGE_RECEIPT_v1.json")},
"reused_results":{"original_independent":"167/0; no rerun","original_density_confirmation":"15/0; no rerun",
"parent_discovery":"67/0 and four damages; recorded evidence only","parent_canonical":"83/0 predecessor; 132/0 current and nine damages; recorded evidence only",
"parent_final_cache":"actual refreshed 132/0; not independently replayed","original_independent_receipt_sha256":"c74ab0d7c2fdcbd4d302c563e9a5b9b1406c8b6ca58f6dbfb727df016fd5a2af"},
"prior_seals_verified_unchanged":prior,"preserved_failures":info(H/"PRESERVED_FAILURES_v1.json"),
"recorded_target_subprocess_count":9,"recorded_target_subprocesses":runs,
"seal_command":{"argv":[sys.executable,"-B","seal_v1.py"],"cwd":str(H),"scope":"integrity and receipt packaging only"},
"delivery":{"ready_for_separate_mapping":True,"archive_checked":False,"commit_checked":False,"five_file_delta_checked":False,
"parent_supplied_base":"494fd01a2b2873db6795d48f34f42d5988a02e85","parent_supplied_branch":"codex/revised-scalar-finite-history-20261014"},
"boundaries":{"writes_only":str(H),"old_seals_modified":False,"author_source_modified_by_checker":False,"git_operations":False,"network_operations":False,"pr_operations":False,"formal_audit":False,"full_primary_rerun":False,"old_science_rerun":False},
"artifact_count_excluding_receipt_and_manifest":len(artifacts),"artifacts":artifacts
}
save(H/"RECEIPT_v1.json",receipt)
entries=[info(p) for p in sorted(H.rglob("*")) if p.is_file()]
save(H/"MANIFEST_v1.json",{"sealed_utc":now,"scope":"Frozen canonical finite-history correspondence unit; excludes this manifest itself","artifact_count":len(entries),"artifacts":entries})
for a in entries:assert info(H/a["path"])==a
print(json.dumps({"sealed_utc":now,"artifact_count":len(entries),"source_count":91,"report":info(H/"REPORT_v1.txt"),"receipt":info(H/"RECEIPT_v1.json"),"manifest":info(H/"MANIFEST_v1.json"),"correction_receipt":info(child/"RECEIPT_v2.json")},indent=2))

