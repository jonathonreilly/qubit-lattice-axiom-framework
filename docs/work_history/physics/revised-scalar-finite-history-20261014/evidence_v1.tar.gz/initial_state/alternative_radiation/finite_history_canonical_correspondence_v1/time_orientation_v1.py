"""Narrow sign-sheet control for the canonical physical-past premise."""
from pathlib import Path
import hashlib,json,sys
import sympy as s
H=Path(__file__).resolve().parent
e,beta,Hv,H0,Cx=s.symbols("eta beta Hv H0 Cx",positive=True)
rows=[]
def ck(n,ok,d=None):rows.append({"name":n,"passed":bool(ok),"detail":d})
for sign in [1,-1]:
    HE=sign*Hv*s.sqrt(H0)/(beta*s.sqrt(e))
    time_from_boundary=sign*beta*s.sqrt(e)/(2*Hv*s.sqrt(H0))
    dtde=s.diff(time_from_boundary,e)
    ck("proper_clock_signed_sheet_"+str(sign),s.simplify(HE*dtde-1/(4*e))==0)
    ck("same_N_flow_both_sheets_"+str(sign),s.simplify(1/dtde/HE-4*e)==0)
    ck("physical_orientation_"+str(sign),time_from_boundary>0 if sign==1 else time_from_boundary<0,
       "eta=0 is earlier in proper time" if sign==1 else "eta=0 is later in proper time")
    HJ=HE/s.sqrt(Cx)
    tauJ=s.sqrt(Cx)*time_from_boundary
    ck("curvature_same_on_both_sheets_"+str(sign),s.simplify(24*HJ**4-s.Rational(3,2)/tauJ**4)==0)
r={"pass":sum(x["passed"] for x in rows),"fail":sum(not x["passed"] for x in rows),"checks":rows,
"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
"finding":"The squared Friedmann constraint leaves both H_E signs. The N→−infinity limit is physical past only on the expanding sheet H_E>0; L>0 gives H_J>0 locally. Contracting solutions have the same curvature blow-up in physical future time.",
"scope":"New eight exact orientation controls, separate from the frozen 112/0 canonical-path result and reused old science."}
print(json.dumps(r,indent=2));sys.exit(bool(r["fail"]))

