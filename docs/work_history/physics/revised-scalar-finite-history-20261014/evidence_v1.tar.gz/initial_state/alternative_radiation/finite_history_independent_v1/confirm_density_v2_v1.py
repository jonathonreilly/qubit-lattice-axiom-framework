"""Narrow final-source correspondence; original science is reused, not rerun."""
from pathlib import Path
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=next(p for p in here.parents if (p/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md').is_file())
checks=[]
def yes(name,ok,evidence):checks.append(dict(id=name,ok=bool(ok),evidence=evidence))
rows=json.loads((here/'SOURCE_MANIFEST_v1.json').read_text())['sources']+json.loads((here/'SOURCE_V2_MANIFEST_v1.json').read_text())['sources']
for i,row in enumerate(rows):
    snap=(here/row['snapshot_path']).read_bytes();live=(root/row['original_path']).read_bytes()
    yes(f'source_pair_{i}',snap==live and len(snap)==row['bytes'] and hashlib.sha256(snap).hexdigest()==row['sha256'],row)
v1=(here/'sources/00_FINITE_AMPLITUDE_HISTORY_v1.md').read_text()
v2=(here/'sources/05_FINITE_AMPLITUDE_HISTORY_v2.md').read_text()
prefix='''
Density convention: rho_phys denotes dimensionful physical density. In the
canonical complete-action note rho_J is dimensionless, with
rho_phys=rho_unit rho_J and Rstar=rho_unit/(2Q Hv^2). Consequently
 y_b^2=rho_phys/(2Q Hv^2)=Rstar rho_J.
The earlier same-symbol usage in this route is clarified here; no density
normalization is inferred from observations.
'''
suffix='''
This version preserves all equations with the explicit density-symbol
translation above. Earlier source versions and execution receipts remain
unchanged; unchanged calculations are reused, not claimed as new runs.
'''
yes('density_definition_present_once',v2.count(prefix)==1,prefix)
yes('preservation_statement_present_once',v2.count(suffix)==1,suffix)
restored=v2.replace(prefix,'').replace(suffix,'').replace('    rho_phys ~ 2Q Hv^2/(beta_x^2 eta), eta\' ~ 4eta.','    rho_J ~ 2Q Hv^2/(beta_x^2 eta), eta\' ~ 4eta.')
yes('only_density_translation_and_history_prose_changed',restored==v1,'Remove exactly the two added paragraphs and undo exactly the displayed density symbol; all original bytes then agree.')
data=(here/'RUN_03_INDEPENDENT_ACTION.stdout.txt').read_bytes(); result=json.loads(data)
yes('original_science_output_unchanged',hashlib.sha256(data).hexdigest()=='d917bd5e7958759a50bc891d9a700ecd4df57d64088edce9c68582ca73b475d6' and result['passed']==167 and result['failed']==0,'167/0 retained, no fresh science rerun.')
identity=next(c for c in result['checks'] if c['id']=='density_dimensionful_translation')
yes('corrected_density_maps_to_checked_identity',identity['ok'] and identity['residual']=='0',identity)
yes('original_checker_source_unchanged',hashlib.sha256((here/'check_finite_history_v1.py').read_bytes()).hexdigest()=='f25eda6ea9223823a2c74559811ceb3a455ce91ffe0aefb9dd77695b8d004ed6','Source of original independent computation retained.')
out=dict(scope='Density-symbol correction correspondence only; no science rerun',total=len(checks),passed=sum(c['ok'] for c in checks),failed=sum(not c['ok'] for c in checks),checks=checks)
print(json.dumps(out,indent=2));sys.exit(0 if out['failed']==0 else 1)
